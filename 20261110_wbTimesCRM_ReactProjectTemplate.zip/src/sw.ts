/// <reference lib="webworker" />

import { CacheableResponsePlugin } from "workbox-cacheable-response";
import { ExpirationPlugin } from "workbox-expiration";
import {
  cleanupOutdatedCaches,
  getCacheKeyForURL,
  matchPrecache,
  precacheAndRoute,
  type PrecacheEntry
} from "workbox-precaching";
import { registerRoute, setCatchHandler } from "workbox-routing";
import { StaleWhileRevalidate } from "workbox-strategies";
import {
  getFrontEndUrl,
  invalidateFrontEndUrlCache,
  KUIKA_ENV_CONFIG_MESSAGE_TYPE,
  type KuikaEnvConfig
} from "./shared/utilty/frontend-url";
import { isNetworkOnlyUrl } from "./shared/utilty/network-only-patterns";

declare const self: ServiceWorkerGlobalScope;

const PRECACHE_MANIFEST: (PrecacheEntry | string)[] = self.__WB_MANIFEST;

// Runtime cache names are stable across builds (no build-hash suffix). The
// SW only writes runtime caches for things that aren't precached — the .NET
// /_framework/ files, whose own URLs are content-hashed by the .NET tooling,
// and the assets of OTHER deployments this app embeds (micro apps, widget
// packs). The Workbox precache itself versions internally and rotates on
// each new SW install; nothing here needs to mirror that.
const CACHE_PAGES: string = "kuika-pages";
const CACHE_PUBLIC_ASSETS: string = "kuika-public-assets";
const CACHE_DOTNET_WASM: string = "kuika-dotnet-wasm";
const MAX_PUBLIC_ASSET_CACHE_ENTRIES: number = 200;
// Path relative to the frontend root. Combined with getFrontEndUrl() (the
// same function the app's WASM bridge adapter uses) to produce the deploy-
// correct boot URL for both root and base-path deployments.
const DOTNET_BOOT_JSON_PATH: string = "/wasm/kuika-dotnet-core/browser/_framework/blazor.boot.json";
const RUNTIME_CACHE_BUST_PARAM: string = "__kuika_sw_cache_bust";
const NETWORK_FALLBACK_TIMEOUT_MS: number = 2000;
// index.html is a few KB, and losing the race serves the precached copy — the
// previous deployment's until the new worker takes over (KOA-18772). True
// offline rejects at once, so only a slow-but-live connection waits this long.
const NAVIGATION_NETWORK_TIMEOUT_MS: number = 10000;
const WARMUP_NETWORK_TIMEOUT_MS: number = 30000;
const MAX_PAGE_CACHE_ENTRIES: number = 20;
const MAX_DOTNET_WASM_CACHE_ENTRIES: number = 100;

// Specific asset extensions only — avoid clobbering SPA routes that legally
// contain dots (e.g. /entity.action). Keep this list tight.
const NAVIGATION_DENYLIST_ASSET_RE: RegExp =
  /\.(?:js|css|png|jpe?g|gif|svg|webp|avif|ico|woff2?|ttf|otf|eot|json|webmanifest|wasm|map)(?:\?|$)/i;
const DOTNET_BOOT_JSON_RE: RegExp = /\/_framework\/blazor\.boot\.json(?:\?|$)/i;
const DOTNET_FRAMEWORK_RESOURCE_RE: RegExp = /\.(?:bin|dat|dll|json|js|symbols|wasm)$/i;

// The shared network-only matcher is reused below as the navigation denylist so
// a navigation fallback can never serve index.html in place of an API response.

function waitForNetworkFallback(): Promise<undefined> {
  return new Promise((resolve: (value: undefined) => void): void => {
    self.setTimeout((): void => resolve(undefined), NETWORK_FALLBACK_TIMEOUT_MS);
  });
}

function waitForNavigationNetworkFallback(): Promise<undefined> {
  return new Promise((resolve: (value: undefined) => void): void => {
    self.setTimeout((): void => resolve(undefined), NAVIGATION_NETWORK_TIMEOUT_MS);
  });
}

function waitForWarmupFallback(): Promise<undefined> {
  return new Promise((resolve: (value: undefined) => void): void => {
    self.setTimeout((): void => resolve(undefined), WARMUP_NETWORK_TIMEOUT_MS);
  });
}

function isCacheableRuntimeResponse(response: Response): boolean {
  return response.status === 0 || response.status === 200;
}

function createNetworkRequest(request: Request, bypassHttpCache: boolean): Request {
  if (!bypassHttpCache) return request;

  return new Request(request, { cache: "reload" });
}

function createCacheBustUrl(request: Request): string {
  const url: URL = new URL(request.url);
  url.searchParams.set(RUNTIME_CACHE_BUST_PARAM, Date.now().toString());
  return url.toString();
}

function createCacheBustRequest(request: Request): Request {
  const headers: Headers = new Headers(request.headers);
  headers.delete("if-none-match");
  headers.delete("if-modified-since");
  headers.delete("if-range");

  const requestInit: RequestInit = {
    cache: "no-store",
    credentials: request.credentials,
    headers,
    integrity: request.integrity,
    method: request.method,
    mode: request.mode,
    redirect: request.redirect
  };

  return new Request(createCacheBustUrl(request), requestInit);
}

function createResourceWarmupRequest(resourceUrl: string): Request {
  const url: URL = new URL(resourceUrl);
  url.searchParams.set(RUNTIME_CACHE_BUST_PARAM, Date.now().toString());

  const requestInit: RequestInit = {
    cache: "no-store",
    credentials: "same-origin",
    method: "GET",
    mode: "same-origin",
    redirect: "follow"
  };

  return new Request(url.toString(), requestInit);
}

function createCacheStorageResponse(response: Response): Response {
  const responseInit: ResponseInit = {
    headers: new Headers(response.headers),
    status: response.status,
    statusText: response.statusText
  };

  return new Response(response.body, responseInit);
}

function isObjectValue(value: unknown): value is object {
  return typeof value === "object" && value !== null && !Array.isArray(value);
}

function isDotnetFrameworkResourcePath(value: string): boolean {
  if (/^(?:[a-z]+:)?\/\//i.test(value)) return false;
  return DOTNET_FRAMEWORK_RESOURCE_RE.test(value);
}

function collectDotnetFrameworkResourcePaths(value: unknown, resourcePaths: Set<string>): void {
  if (typeof value === "string") {
    if (isDotnetFrameworkResourcePath(value)) resourcePaths.add(value);
    return;
  }

  if (Array.isArray(value)) {
    for (const item of value) {
      collectDotnetFrameworkResourcePaths(item, resourcePaths);
    }
    return;
  }

  if (!isObjectValue(value)) return;

  const entries: [string, unknown][] = Object.entries(value);
  for (const [key, childValue] of entries) {
    // A real asset is a leaf `filename -> SRI-hash(string)` entry. A key whose
    // value is an object/array is a grouping or VIRTUAL node, not a fetchable
    // file: resources.vfs maps a virtual target name -> { realAssetFile ->
    // hash }, and satelliteResources maps a culture -> { file -> hash }.
    // Collecting such keys made the SW request e.g. _framework/runtimeconfig.bin
    // (a vfs virtual name) -> 404, while the real file is the inner key
    // supportFiles/0_runtimeconfig.bin. Only collect leaf keys; still recurse
    // into groupings to reach their real files.
    if (typeof childValue === "string" && isDotnetFrameworkResourcePath(key)) {
      resourcePaths.add(key);
    }
    collectDotnetFrameworkResourcePaths(childValue, resourcePaths);
  }
}

function createDotnetFrameworkResourceUrl(bootUrl: URL, resourcePath: string): string | undefined {
  const resourceUrl: URL = new URL(resourcePath, bootUrl);
  if (!resourceUrl.pathname.includes("/_framework/")) return undefined;
  return resourceUrl.toString();
}

function isDotnetBootJsonRequest(request: Request): boolean {
  const url: URL = new URL(request.url);
  return DOTNET_BOOT_JSON_RE.test(url.pathname);
}

async function trimCache(cacheName: string, maxEntries: number): Promise<void> {
  const cache: Cache = await caches.open(cacheName);
  const keys: readonly Request[] = await cache.keys();
  const deleteCount: number = keys.length - maxEntries;
  if (deleteCount <= 0) return;

  await Promise.all(keys.slice(0, deleteCount).map((request: Request): Promise<boolean> => cache.delete(request)));
}

async function fetchAndCacheRuntimeResponse(
  request: Request,
  cacheName: string,
  maxEntries: number,
  bypassHttpCache: boolean
): Promise<Response | undefined> {
  const cache: Cache = await caches.open(cacheName);
  const cacheKey: string = request.url;
  const networkRequest: Request = createNetworkRequest(request, bypassHttpCache);
  let response: Response = await fetch(networkRequest);

  if (bypassHttpCache && !isCacheableRuntimeResponse(response)) {
    const cached: Response | undefined = await cache.match(cacheKey);
    if (cached) return cached;

    const cacheBustRequest: Request = createCacheBustRequest(request);
    response = await fetch(cacheBustRequest);
  }

  if (!isCacheableRuntimeResponse(response)) return response;

  const cacheStorageResponse: Response =
    bypassHttpCache && response.status !== 0 ? createCacheStorageResponse(response) : response;
  await cache.put(cacheKey, cacheStorageResponse.clone());
  await trimCache(cacheName, maxEntries);
  return cacheStorageResponse;
}

async function getCachedRuntimeResponse(request: Request, cacheName: string): Promise<Response | undefined> {
  const cache: Cache = await caches.open(cacheName);
  const cacheKey: string = request.url;
  return cache.match(cacheKey);
}

async function cacheDotnetFrameworkResource(resourceUrl: string, cache: Cache): Promise<void> {
  const cached: Response | undefined = await cache.match(resourceUrl);
  if (cached) return;

  const warmupRequest: Request = createResourceWarmupRequest(resourceUrl);
  const response: Response | undefined = await fetchWarmupResponse(warmupRequest);
  if (!response) return;
  if (!isCacheableRuntimeResponse(response)) return;

  const cacheStorageResponse: Response = response.status !== 0 ? createCacheStorageResponse(response) : response;
  await cache.put(resourceUrl, cacheStorageResponse);
}

async function fetchWarmupResponse(request: Request): Promise<Response | undefined> {
  return Promise.race([fetch(request), waitForWarmupFallback()]).catch((): undefined => undefined);
}

// blazor.boot.json's top level carries metadata that is NOT a fetchable file —
// notably `mainAssemblyName`, which under Webcil is the logical assembly
// identity ("X.dll") even though the deployed file is "X.wasm". Only the
// `resources` subtree maps names to real, downloadable files. Harvesting the
// whole document makes the SW request a non-existent X.dll (404). Traverse
// `resources` only; this stays correct for both Webcil (.wasm) and
// non-Webcil (.dll) builds, since their real files live under `resources`.
interface DotnetBootManifest {
  resources?: unknown;
}

async function warmDotnetFrameworkResources(request: Request, response: Response): Promise<void> {
  if (!response.ok) return;

  const bootJson: unknown = await response.json();
  const resourcePaths: Set<string> = new Set<string>();
  const manifestRoot: unknown = isObjectValue(bootJson)
    ? ((bootJson as DotnetBootManifest).resources ?? bootJson)
    : bootJson;
  collectDotnetFrameworkResourcePaths(manifestRoot, resourcePaths);
  resourcePaths.add("dotnet.js");

  const bootUrl: URL = new URL(request.url);
  const resourceUrls: string[] = [];
  for (const resourcePath of resourcePaths) {
    const resourceUrl: string | undefined = createDotnetFrameworkResourceUrl(bootUrl, resourcePath);
    if (resourceUrl) resourceUrls.push(resourceUrl);
  }

  const cache: Cache = await caches.open(CACHE_DOTNET_WASM);
  await Promise.all(
    resourceUrls.map((resourceUrl: string): Promise<void> => {
      return cacheDotnetFrameworkResource(resourceUrl, cache).catch((): void => undefined);
    })
  );
  await trimCache(CACHE_DOTNET_WASM, MAX_DOTNET_WASM_CACHE_ENTRIES);
}

// Best-effort: must not throw or block SW install. Deployments may legitimately
// lack the WASM runtime (404), and cache.put/response.json can throw on quota
// or corrupted payloads. The runtime cache warms lazily on real /_framework/
// requests via NetworkFirst either way.
async function warmDefaultDotnetFrameworkSnapshot(): Promise<void> {
  try {
    const bootUrl: string = `${getFrontEndUrl()}${DOTNET_BOOT_JSON_PATH}`;
    const warmupRequest: Request = createResourceWarmupRequest(bootUrl);
    const response: Response | undefined = await fetchWarmupResponse(warmupRequest);
    if (!response) return;
    if (!isCacheableRuntimeResponse(response)) return;

    const bootResponse: Response = response.status !== 0 ? createCacheStorageResponse(response) : response;
    const cache: Cache = await caches.open(CACHE_DOTNET_WASM);
    await cache.put(bootUrl, bootResponse.clone());
    await warmDotnetFrameworkResources(new Request(bootUrl), bootResponse);
  } catch {
    // see contract above
  }
}

async function getCachedNavigationFallback(request: Request): Promise<Response | undefined> {
  if (PRECACHED_INDEX_HTML_URL) {
    const precached: Response | undefined = await matchPrecache(PRECACHED_INDEX_HTML_URL);
    if (precached) return precached;
  }

  const directMatch: Response | undefined = await caches.match(request);
  if (directMatch) return directMatch;

  const pagesCache: Cache = await caches.open(CACHE_PAGES);
  const pagesKeys: readonly Request[] = await pagesCache.keys();
  for (const key of pagesKeys) {
    const fallback: Response | undefined = await pagesCache.match(key);
    if (fallback) return fallback;
  }

  return undefined;
}

async function handleNetworkFirstRuntimeRequest(
  request: Request,
  cacheName: string,
  maxEntries: number
): Promise<Response> {
  const networkResponsePromise: Promise<Response | undefined> = fetchAndCacheRuntimeResponse(
    request,
    cacheName,
    maxEntries,
    true
  ).catch((): undefined => undefined);

  const networkResponse: Response | undefined = await Promise.race([networkResponsePromise, waitForNetworkFallback()]);
  if (networkResponse) return networkResponse;

  const cached: Response | undefined = await getCachedRuntimeResponse(request, cacheName);
  if (cached) return cached;

  return Response.error();
}

// The .NET boot manifest (blazor.boot.json) is the one runtime resource where
// "stale" does not mean "degraded" — it means the app boots an OLD content-
// hashed wasm set, so [JSExport]s added in a newer build vanish at runtime
// ("X is not a function") deep inside a screen handler. It MUST be
// fresh-or-fail, never silently fresh-or-stale. It is a few KB, so it must
// NOT be subject to the latency race in handleNetworkFirstRuntimeRequest
// (waitForNetworkFallback): a merely-slow — not failed — network must still
// resolve to the fresh manifest. The cached manifest is served ONLY on a
// genuine network failure (true offline), where it is consistent with the
// wasm warmed alongside it.
// Generous, manifest-specific network bound. The shared 2s
// NETWORK_FALLBACK_TIMEOUT_MS is tuned for the large wasm payloads' UX and is
// far too short for the boot manifest: a merely-slow (but live) connection
// loses that race and the SW serves a STALE manifest -> app boots an old
// content-hashed wasm set -> newer [JSExport]s are "not a function" deep in a
// screen. The manifest is only a few KB, so a real connection always delivers
// it well within this window; a genuinely dead/lie-fi connection still falls
// back to the cached manifest at this bound instead of hanging the boot; and
// true offline rejects ~immediately, so cached is served with no perceptible
// wait. Do NOT shrink this back toward NETWORK_FALLBACK_TIMEOUT_MS.
const BOOT_MANIFEST_NETWORK_TIMEOUT_MS: number = 15000;

function waitForBootManifestTimeout(): Promise<undefined> {
  return new Promise((resolve: (value: undefined) => void): void => {
    self.setTimeout((): void => resolve(undefined), BOOT_MANIFEST_NETWORK_TIMEOUT_MS);
  });
}

// Fresh-or-fail manifest handling, shared by the .NET boot manifest and the
// config files of embedded deployments (shouldHandleForeignDeploymentConfigRequest):
// network first under the generous manifest bound, the cached copy only on a
// timed-out or failed network, else hard-fail.
async function handleManifestRequest(request: Request, cacheName: string, maxEntries: number): Promise<Response> {
  const networkResponsePromise: Promise<Response | undefined> = fetchAndCacheRuntimeResponse(
    request,
    cacheName,
    maxEntries,
    true
  ).catch((): undefined => undefined);

  const networkResponse: Response | undefined = await Promise.race([
    networkResponsePromise,
    waitForBootManifestTimeout()
  ]);
  if (networkResponse) return networkResponse;

  // Reached only on a timed-out or failed network: serve the cached manifest
  // (consistent with the assets cached alongside it), else hard-fail.
  const cached: Response | undefined = await getCachedRuntimeResponse(request, cacheName);
  if (cached) return cached;

  return Response.error();
}

const BOOT_MANIFEST_HEAL_MESSAGE: string = "kuika-wasm-stale-reload";

// Background self-heal. A tab can still boot from a STALE cached manifest
// (e.g. a >15s outage during boot that later recovered, or an old SW that
// served stale before this fix shipped). On every boot-manifest request we
// also fetch the manifest fresh (cache-busted; it is a few KB) and compare
// it to what is cached. If it changed, adopt the fresh manifest + its wasm
// and tell every open client to do ONE guarded reload onto the new code —
// so a user is never stranded on a missing [JSExport]. Subsumes the prior
// warmup (it still warms the referenced wasm).
async function healBootManifestIfChanged(request: Request): Promise<void> {
  let freshResponse: Response;
  try {
    freshResponse = await fetch(createCacheBustRequest(request));
  } catch {
    return;
  }
  if (!freshResponse.ok) return;

  const cache: Cache = await caches.open(CACHE_DOTNET_WASM);
  const cachedResponse: Response | undefined = await cache.match(request.url);
  const freshText: string = await freshResponse.clone().text();
  const cachedText: string | undefined = cachedResponse ? await cachedResponse.text() : undefined;

  await cache.put(request.url, createCacheStorageResponse(freshResponse.clone()));
  await warmDotnetFrameworkResources(new Request(request.url), freshResponse.clone());

  if (cachedText !== undefined && cachedText === freshText) return;

  const clientList: readonly Client[] = await self.clients.matchAll({
    type: "window",
    includeUncontrolled: true
  });
  for (const client of clientList) {
    client.postMessage({ type: BOOT_MANIFEST_HEAL_MESSAGE });
  }
}

// index.html points at the hashed bundles, so navigations revalidate it instead
// of taking a possibly stale copy from the HTTP cache (KOA-18772). A 304 when
// unchanged; redirect mode stays "manual". Falls back to the original request
// if a browser refuses to re-wrap a navigation.
function createNavigationNetworkRequest(request: Request): Request {
  try {
    return new Request(request, { cache: "no-cache" });
  } catch {
    return request;
  }
}

async function handleNavigationRequest(request: Request): Promise<Response> {
  const networkResponsePromise: Promise<Response | undefined> = fetchAndCacheRuntimeResponse(
    createNavigationNetworkRequest(request),
    CACHE_PAGES,
    MAX_PAGE_CACHE_ENTRIES,
    false
  ).catch((): undefined => undefined);

  const networkResponse: Response | undefined = await Promise.race([
    networkResponsePromise,
    waitForNavigationNetworkFallback()
  ]);
  if (networkResponse) return networkResponse;

  const fallback: Response | undefined = await getCachedNavigationFallback(request);
  if (fallback) return fallback;

  return Response.error();
}

function shouldHandleNavigationRequest(request: Request): boolean {
  if (request.mode !== "navigate") return false;

  const url: URL = new URL(request.url);
  if (isNetworkOnlyUrl(url)) return false;
  if (/^\/_framework\//.test(url.pathname)) return false;
  return !NAVIGATION_DENYLIST_ASSET_RE.test(url.pathname);
}

function shouldHandleDotnetWasmRequest(request: Request): boolean {
  if (request.method !== "GET") return false;

  const url: URL = new URL(request.url);
  return url.pathname.includes("/_framework/");
}

// The two small files the host reads from ANOTHER deployment it embeds (a
// micro app): `asset-manifest.json`, which names the content-hashed
// main.js/css to inject, and `env-config.json`, which carries that
// deployment's runtime BACKEND_URL. Left to the public-assets
// StaleWhileRevalidate route they are served from the cache FIRST and
// refreshed only in the background — so after the micro app is redeployed the
// first reload (including the one behind the "new version" notice's Refresh)
// still injects the previous bundle and only the second reload picks up the
// new one (KOA-18736); and the loader's own `cache: "no-store"` on
// env-config.json only bypasses the browser's HTTP cache, never this SW. Like
// blazor.boot.json they are a few KB and must be fresh-or-fail: network first
// under the manifest bound, the cached copy only when the network is genuinely
// down.
//
// Files of THIS build stay with the precache: widget packs are copied into the
// build (rsbuild `output.copy` → /widgets/<pack>/asset-manifest.json) and are
// precached under a per-build revision, so they are never stale and must keep
// working offline from the precache — hence the getCacheKeyForURL guard.
function shouldHandleForeignDeploymentConfigRequest(request: Request): boolean {
  if (request.method !== "GET") return false;
  if (request.mode === "navigate") return false;

  const url: URL = new URL(request.url);
  if (isNetworkOnlyUrl(url)) return false;
  if (!url.pathname.endsWith("/asset-manifest.json") && !url.pathname.endsWith("/env-config.json")) return false;

  return getCacheKeyForURL(url.href) === undefined;
}

// Register this explicit fetch listener before Workbox's router. WebKit is
// more fragile around slow/unreachable dev servers than Chromium/Firefox; this
// keeps the two critical NetworkFirst paths independent from Workbox strategy
// internals and returns cached responses after a bounded timeout.
self.addEventListener("fetch", (event: FetchEvent): void => {
  const request: Request = event.request;

  if (shouldHandleNavigationRequest(request)) {
    event.respondWith(handleNavigationRequest(request));
    return;
  }

  if (shouldHandleForeignDeploymentConfigRequest(request)) {
    event.respondWith(handleManifestRequest(request, CACHE_PUBLIC_ASSETS, MAX_PUBLIC_ASSET_CACHE_ENTRIES));
    return;
  }

  if (shouldHandleDotnetWasmRequest(request)) {
    const isBootManifest: boolean = isDotnetBootJsonRequest(request);
    // Boot manifest is fresh-or-fail (no latency race); the heavy
    // content-hashed wasm payloads keep the timeout-bounded NetworkFirst —
    // a fresh manifest guarantees the hashes they resolve to are correct.
    const responsePromise: Promise<Response> = isBootManifest
      ? handleManifestRequest(request, CACHE_DOTNET_WASM, MAX_DOTNET_WASM_CACHE_ENTRIES)
      : handleNetworkFirstRuntimeRequest(request, CACHE_DOTNET_WASM, MAX_DOTNET_WASM_CACHE_ENTRIES);
    event.respondWith(responsePromise);

    if (isBootManifest) {
      event.waitUntil(healBootManifestIfChanged(request).catch((): void => undefined));
    }
  }
});

// Precache the build manifest (injected by Workbox at build time).
// Sourcemaps are excluded in rsbuild.config.ts; index.html is INCLUDED so the
// SW always has an HTML shell available for the offline navigation fallback
// below — even on the very first reload after install when the original load
// was uncontrolled and didn't populate the runtime `pages` cache.
//
// This intentionally keeps Workbox's strict install behavior: if a hashed build
// asset is missing, the new worker fails install and the previous active worker
// keeps serving its known-good cache. Copied public assets are handled by the
// runtime routes below instead of making the precache brittle.
precacheAndRoute(PRECACHE_MANIFEST, {
  // The default `cleanURLs: true` rewrites /foo to /foo/index.html — fine for
  // static-site precaches, harmful for SPAs with hashed bundle names.
  cleanURLs: false
});

// Pull the precached index.html URL out of the manifest so the catch handler
// can serve it via matchPrecache(). The URL carries the assetPrefix that
// rspack/workbox encoded at build time, so we don't have to hard-code it.
const PRECACHED_INDEX_HTML_URL: string | null = (() => {
  for (const entry of PRECACHE_MANIFEST) {
    const url: string = typeof entry === "string" ? entry : entry.url;
    if (/(?:^|\/)index\.html$/i.test(url)) return url;
  }
  return null;
})();

cleanupOutdatedCaches();

// Pathname/extension allowlist — `request.destination` is filled inconsistently
// across engines (Firefox often reports "" for fetch()-loaded assets, Safari
// for some preloads), so a URL-based matcher is more reliable cross-browser.
const PUBLIC_ASSET_RE: RegExp =
  /\/(assets|images|widgets|fonts|locales)\/|\.(?:png|jpe?g|gif|svg|webp|avif|ico|woff2?|ttf|otf|eot|css|json|webmanifest|js)(?:\?|$)/i;

// Content-hashed or rarely changing assets; a stale hit is at worst a slightly
// old image/font. The files for which "stale" means "wrong bundle / wrong
// backend" — an embedded deployment's asset-manifest.json and env-config.json
// — are carved out ahead of this route by the explicit fetch listener
// (shouldHandleForeignDeploymentConfigRequest).
const publicAssetsStrategy: StaleWhileRevalidate = new StaleWhileRevalidate({
  cacheName: CACHE_PUBLIC_ASSETS,
  plugins: [
    // statuses: [0, 200] → keep opaque (cross-origin no-cors) responses too,
    // but never poison the cache with 4xx/5xx. Workbox's default for
    // StaleWhileRevalidate is to cache anything; that's how 404 pages end up
    // sticking around on offline reloads.
    new CacheableResponsePlugin({ statuses: [0, 200] }),
    new ExpirationPlugin({
      maxEntries: MAX_PUBLIC_ASSET_CACHE_ENTRIES,
      maxAgeSeconds: 30 * 24 * 60 * 60,
      // Critical for Safari's ~50 MB cache cap: when the quota is hit,
      // this plugin drops oldest entries instead of leaving the cache wedged.
      purgeOnQuotaError: true
    })
  ]
});

// Skip the "waiting" state so this SW becomes active as soon as install
// completes, without requiring the user to close every tab. Combined with
// clients.claim() in activate below, the new SW takes over the existing tab
// the moment install finishes.
//
// Trade-off: a page loaded against the old build that lazy-imports a chunk
// *after* the new SW takes over will request a hash that isn't in the new
// precache. The deploy pipeline has to keep old hashed chunk files live for
// a grace period (a generic CDN-deploy best practice) for that to be safe.
self.addEventListener("install", (event: ExtendableEvent) => {
  const skipWaitingPromise: Promise<void> = self.skipWaiting();
  const warmupPromise: Promise<void> = warmDefaultDotnetFrameworkSnapshot().catch((): void => undefined);

  event.waitUntil(
    Promise.all([skipWaitingPromise, warmupPromise]).then((): void => {
      return;
    })
  );
});

// /_framework/ (.NET wasm runtime) uses a custom NetworkFirst flow, not
// CacheFirst:
//
// blazor.boot.json contains an integrity (SRI) hash for every wasm/js asset.
// At runtime the .NET loader fetches each file with that hash; the browser
// rejects any response whose body doesn't match. So whatever the SW returns
// for /_framework/blazor.boot.json and /_framework/*.wasm MUST be from the
// same build — a mixed cache (e.g., new boot.json + old wasm) means SRI
// fails and Blazor refuses to start.
//
// CacheFirst would return whatever happened to land in the cache first and
// never refresh until expiration; that's fine until a new .NET build is
// deployed and the cache holds yesterday's bytes against today's hashes.
// NetworkFirst always tries the network first, so a single online page load
// against a fresh deploy refreshes the entire bundle atomically: the loader
// fetches boot.json from network, the .wasm follow from network, all from
// the same server snapshot, all consistent. Offline (network fail), it
// falls back to whatever was cached on the last successful online load —
// which is itself a consistent snapshot, so SRI still passes there too.
//
// NETWORK_FALLBACK_TIMEOUT_MS caps the offline fall-through wait at 2s. The
// explicit fetch listener above is registered before Workbox's public-assets
// route so /_framework/ JS sidecars don't get hijacked by their `.js`
// extension.

registerRoute(({ request, url }: { request: Request; url: URL }): boolean => {
  if (request.method !== "GET") return false;
  if (request.mode === "navigate") return false;
  if (isNetworkOnlyUrl(url)) return false;
  return PUBLIC_ASSET_RE.test(url.pathname);
}, publicAssetsStrategy);

// Offline navigation fallback. NetworkFirst above already tried the network and
// its own pages cache for the exact request URL; this only fires when both
// failed. For an SPA the HTML shell is the same regardless of route, so the
// precached index.html is a valid fallback for any URL — the client-side
// router rehydrates the right screen once JS boots.
//
// This pattern follows the canonical Workbox "offline fallback" recipe
// (https://web.dev/articles/offline-fallback-page,
// https://developer.chrome.com/docs/workbox/managing-fallback-responses):
// precache the HTML shell, then matchPrecache() it from the catch handler.
// matchPrecache resolves the cache key Workbox uses internally, including any
// build-time revision parameter — direct caches.match("/index.html") would
// miss because the precache key is "/agent/index.html?__WB_REVISION__=...".
//
// Without this, hitting Refresh while offline on the very first reload after
// install dead-ends at Response.error() (the original page was uncontrolled,
// so the runtime pages cache is empty), and Chrome shows ERR_INTERNET_DISCONNECTED.
// Firefox happens to fall through to its HTTP cache; Chrome doesn't.
setCatchHandler(async ({ request }: { request: Request }): Promise<Response> => {
  if (request.mode !== "navigate") return Response.error();

  const fallback: Response | undefined = await getCachedNavigationFallback(request);
  return fallback ?? Response.error();
});

// On activate, clean up legacy runtime cache names left over from earlier SW
// revisions (plain unprefixed names; build-hash-suffixed names from the
// previous versioning scheme) so they don't accumulate in users' storage.
const LIVE_RUNTIME_CACHES: ReadonlySet<string> = new Set([CACHE_PAGES, CACHE_PUBLIC_ASSETS, CACHE_DOTNET_WASM]);
const LEGACY_CACHE_NAME_PATTERNS: readonly RegExp[] = [
  // Plain unprefixed names from very early revisions.
  /^(?:pages|public-assets|static-assets|dotnet-wasm)$/,
  // Build-hash-suffixed names from the prior cache-versioning scheme.
  /^kuika-runtime-(?:pages|public-assets|dotnet-wasm)-[a-z0-9]+$/i
];
const shouldDeleteRuntimeCache = (name: string): boolean => {
  if (LIVE_RUNTIME_CACHES.has(name)) return false;
  return LEGACY_CACHE_NAME_PATTERNS.some((re: RegExp): boolean => re.test(name));
};

self.addEventListener("activate", (event: ExtendableEvent) => {
  event.waitUntil(
    (async (): Promise<void> => {
      // Take over already-open tabs (paired with skipWaiting() in install).
      // The user can't be expected to close every tab to pick up a new SW,
      // so the new SW (with its warmed cache) replaces the old SW in-place.
      // Any in-flight fetch the old SW was about to handle is migrated; any
      // future fetch (including the offline reload that prompted this fix)
      // goes through the new SW and hits the warmed entries.
      await self.clients.claim();

      const cacheNames: string[] = await caches.keys();
      await Promise.all(
        cacheNames.filter(shouldDeleteRuntimeCache).map((name: string): Promise<boolean> => caches.delete(name))
      );
    })()
  );
});

// env-config.js runs as a page-side <script> only; the SW learns about
// runtime overrides via postMessage forwarded by the page after register().
interface SwGlobalWithEnv {
  _env_?: KuikaEnvConfig;
}

self.addEventListener("message", (event) => {
  if (event.data === "SKIP_WAITING") {
    self.skipWaiting();
    return;
  }
  if (event.data?.type === KUIKA_ENV_CONFIG_MESSAGE_TYPE && event.data?.env) {
    const g: SwGlobalWithEnv = globalThis as SwGlobalWithEnv;
    const next: KuikaEnvConfig = event.data.env as KuikaEnvConfig;
    const prev: KuikaEnvConfig | undefined = g._env_;
    if (prev?.FRONTEND_URL === next.FRONTEND_URL && prev?.BACKEND_URL === next.BACKEND_URL) return;
    g._env_ = next;
    invalidateFrontEndUrlCache();
  }
});

self.addEventListener("push", (event) => {
  let data: { title?: string; body?: string; data?: string } = {};
  if (event.data) {
    try {
      data = event.data.json();
    } catch {
      data = { title: "Bildirim", body: event.data.text() };
    }
  }

  let extraData = {};
  if (data.data) {
    try {
      extraData = JSON.parse(JSON.parse(data.data));
    } catch {
      /* */
    }
  }

  const baseUrl = new URL(self.registration.scope);

  const title = data.title || "Empty";
  const options: NotificationOptions = {
    body: data.body || "Empty",
    icon: `${baseUrl.href}/favicon.ico`,
    badge: `${baseUrl.href}/favicon.ico`,
    data: {
      extraData
    }
  };

  event.waitUntil(self.registration.showNotification(title, options));
});

self.addEventListener("notificationclick", (event) => {
  event.notification.close();

  const extraData = (
    event.notification.data as {
      extraData?: { screenId?: string; url?: string; parameters?: object };
    }
  )?.extraData;

  // A valid http(s) URL opens in a new tab and returns early, skipping the in-app
  // screen redirect; anything else falls through.
  const externalUrl: string | undefined = extraData?.url?.trim();
  const externalUrlScheme: string = externalUrl?.toLowerCase() ?? "";
  if (externalUrl && (externalUrlScheme.startsWith("http://") || externalUrlScheme.startsWith("https://"))) {
    event.waitUntil(self.clients.openWindow(externalUrl));
    return;
  }

  const params = new URLSearchParams({
    screenId: extraData?.screenId ?? "",
    parameters: JSON.stringify(extraData?.parameters ?? {})
  });

  event.waitUntil(
    self.clients.matchAll({ type: "window", includeUncontrolled: true }).then((clientList) => {
      const baseUrl = new URL(self.registration.scope);
      const redirectUrl = `${baseUrl.href}notificationredirect?${params.toString()}`;

      for (const client of clientList) {
        if ("focus" in client) {
          client.postMessage({ type: "notification-data", extraData });
          return (client as WindowClient).focus();
        }
      }

      if (self.clients.openWindow) {
        return self.clients.openWindow(redirectUrl);
      }
    })
  );
});
