const React = require("react");

// Mock NumberFormat component
const NumberFormat = React.forwardRef(
  ({ customInput, onValueChange, value, onChange, decimalSeparator = ".", thousandSeparator = ",", ...props }, ref) => {
    const InputComponent = customInput || "input";

    const handleChange = (e) => {
      const newValue = e.target.value;

      // Simulate NumberFormat behavior
      const floatValue = parseFloat(newValue.replace(/,/g, "")) || 0;
      const formattedValue = floatValue.toLocaleString("en-US", {
        minimumFractionDigits: 0,
        maximumFractionDigits: 2
      });

      if (onValueChange) {
        onValueChange({
          value: formattedValue,
          floatValue
        });
      }

      if (onChange) {
        onChange(e);
      }
    };

    const displayValue =
      typeof value === "number"
        ? value.toLocaleString("en-US", { minimumFractionDigits: 0, maximumFractionDigits: 2 })
        : value;

    return React.createElement(InputComponent, {
      ...props,
      ref,
      value: displayValue,
      onChange: handleChange,
      "data-testid": "number-format"
    });
  }
);

module.exports = NumberFormat;
module.exports.default = NumberFormat;
