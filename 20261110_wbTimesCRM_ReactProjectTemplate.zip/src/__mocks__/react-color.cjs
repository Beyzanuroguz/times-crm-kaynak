const React = require("react");

// Mock ChromePicker component
const ChromePicker = React.forwardRef(({ color, onChange, styles, ...props }, ref) => {
  React.useImperativeHandle(ref, () => ({
    state: {
      rgb: { r: 255, g: 0, b: 0, a: 1 }
    }
  }));

  return React.createElement(
    "div",
    {
      "data-testid": "mock-chrome-picker",
      "data-color": color,
      onClick: (e) => {
        if (onChange) {
          onChange({ rgb: { r: 255, g: 0, b: 0, a: 1 } }, e);
        }
      },
      ...props
    },
    "ChromePicker"
  );
});

module.exports = {
  ChromePicker
};
