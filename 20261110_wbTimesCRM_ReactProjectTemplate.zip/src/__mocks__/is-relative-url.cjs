module.exports = function isRelativeUrl(url) {
  if (typeof url !== "string") {
    return false;
  }

  // Check if it's a relative URL (doesn't start with protocol or //)
  return !/^[a-z][a-z0-9+.-]*:/i.test(url) && !url.startsWith("//");
};
