// Mock for @fullcalendar/core
module.exports = {
  DateRangeInput: {},
  EventClickArg: {},
  EventSourceInput: {}
};
