// Mock for @fullcalendar/react
const React = require("react");

const MockFullCalendar = (props) => {
  const { initialView, firstDay, displayEventTime, locale, height, dateClick, eventClick, events, customButtons } =
    props;

  return React.createElement(
    "div",
    {
      "data-testid": "full-calendar",
      "data-initial-view": initialView,
      "data-first-day": firstDay,
      "data-display-event-time": displayEventTime,
      "data-locale": locale,
      "data-height": height,
      onClick: () => {
        if (dateClick) {
          dateClick({ dateStr: "2023-12-25" });
        }
      }
    },
    [
      ...(events || []).map((event, index) =>
        React.createElement(
          "div",
          {
            key: index,
            "data-testid": "calendar-event",
            "data-event-id": event.id,
            "data-event-title": event.title,
            "data-event-color": event.color,
            onClick: () => {
              if (eventClick) {
                eventClick({
                  event: {
                    id: event.id,
                    title: event.title,
                    extendedProps: event.extendedProps
                  }
                });
              }
            }
          },
          event.title
        )
      ),
      customButtons &&
        React.createElement(
          "div",
          { "data-testid": "custom-buttons", key: "custom-buttons" },
          Object.keys(customButtons).map((key) =>
            React.createElement(
              "button",
              {
                key,
                "data-testid": `button-${key}`,
                onClick: () => customButtons[key].click()
              },
              customButtons[key].text || key
            )
          )
        )
    ].filter(Boolean)
  );
};

module.exports = MockFullCalendar;
module.exports.default = MockFullCalendar;
