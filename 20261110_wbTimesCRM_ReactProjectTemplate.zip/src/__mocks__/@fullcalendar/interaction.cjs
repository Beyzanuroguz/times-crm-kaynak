// Mock for @fullcalendar/interaction
module.exports = {};
module.exports.default = {};
module.exports.DateClickArg = {};
