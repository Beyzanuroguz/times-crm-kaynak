// Mock for @fullcalendar/multimonth
module.exports = {};
module.exports.default = {};
