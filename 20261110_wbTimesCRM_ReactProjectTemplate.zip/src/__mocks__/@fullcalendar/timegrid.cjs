// Mock for @fullcalendar/timegrid
module.exports = {};
module.exports.default = {};
