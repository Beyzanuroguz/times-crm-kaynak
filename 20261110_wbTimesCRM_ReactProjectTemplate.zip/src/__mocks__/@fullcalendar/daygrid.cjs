// Mock for @fullcalendar/daygrid
module.exports = {};
module.exports.default = {};
