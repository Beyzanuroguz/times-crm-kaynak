// Mock moment.js for testing

// Tracks first-day-of-week per locale so updateLocale/localeData behave faithfully (KOA-17435).
let currentLocale = "en";
const firstDayByLocale = { en: 0 };

const moment = (input, format) => {
  const mockMoment = {
    isValid: () => true,
    format: (fmt) => input || "2023-01-01",
    toDate: () => new Date(input || "2023-01-01"),
    utc: () => mockMoment,
    utcOffset: () => 0,
    locale: () => mockMoment,
    clone: () => mockMoment,
    localeData: () => ({
      longDateFormat: () => "MM/DD/YYYY",
      firstDayOfWeek: () => firstDayByLocale[currentLocale] ?? 0
    }),
    isSame: () => false,
    isBefore: () => false,
    isAfter: () => false,
    add: () => mockMoment,
    subtract: () => mockMoment,
    startOf: () => mockMoment,
    endOf: () => mockMoment,
    day: () => 1,
    month: () => 0,
    year: () => 2023,
    hour: () => 0,
    hours: () => 0,
    minute: () => 0,
    minutes: () => 0,
    second: () => 0,
    seconds: () => 0,
    valueOf: () => new Date(input || "2023-01-01").getTime(),
    toISOString: () => "2023-01-01T00:00:00.000Z",
    toString: () => input || "2023-01-01"
  };
  return mockMoment;
};

// Static methods
moment.locale = (name) => {
  if (name === undefined) {
    return currentLocale;
  }
  currentLocale = name;
  return currentLocale;
};
moment.localeData = (name) => ({
  longDateFormat: () => "MM/DD/YYYY",
  firstDayOfWeek: () => firstDayByLocale[name ?? currentLocale] ?? 0
});
// moment.updateLocale switches the active locale as a side effect, mirroring real moment.
moment.updateLocale = (name, config) => {
  if (config && config.week && typeof config.week.dow === "number") {
    firstDayByLocale[name] = config.week.dow;
  }
  currentLocale = name;
  return moment;
};
moment.utc = () => moment();
moment.now = () => Date.now();
moment.isMoment = (value) => {
  return !!value && typeof value === "object" && typeof value.isValid === "function";
};
moment.isDate = () => false;

module.exports = moment;
