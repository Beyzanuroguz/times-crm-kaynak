// Mock Guid class
class Guid {
  static create() {
    return {
      toString: () => `mock-guid-${Math.random().toString(36).substr(2, 9)}`
    };
  }

  static EMPTY = "empty-guid";

  toString() {
    return "mock-guid-instance";
  }
}

module.exports = { Guid };
