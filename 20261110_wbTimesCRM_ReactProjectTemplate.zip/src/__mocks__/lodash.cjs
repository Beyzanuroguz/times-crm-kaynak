const lodashMock = {
  clone: jest.fn((obj) => ({ ...obj })),
  cloneDeep: jest.fn((obj) => {
    if (obj === undefined || obj === null) return obj;
    try {
      return JSON.parse(JSON.stringify(obj));
    } catch (e) {
      return { ...obj };
    }
  }),
  isEmpty: jest.fn((obj) => obj == null || obj === "" || (typeof obj === "object" && Object.keys(obj).length === 0)),
  isString: jest.fn((obj) => typeof obj === "string"),
  isObject: jest.fn((obj) => obj != null && (typeof obj === "object" || typeof obj === "function")),
  isUndefined: jest.fn((obj) => typeof obj === "undefined"),
  noop: jest.fn(() => {}),
  debounce: jest.fn((func, delay) => {
    let timeoutId;
    const debounced = (...args) => {
      clearTimeout(timeoutId);
      timeoutId = setTimeout(() => func.apply(this, args), delay);
    };
    debounced.cancel = () => clearTimeout(timeoutId);
    return debounced;
  }),
  isEqual: jest.fn((a, b) => a === b),
  get: jest.fn((obj, path, defaultValue) => {
    if (obj == null) return defaultValue;
    const keys = typeof path === "string" ? path.split(".") : path;
    let result = obj;
    for (const key of keys) {
      result = result?.[key];
      if (result === undefined) return defaultValue;
    }
    return result;
  })
};

// For named imports
module.exports = lodashMock;
// For default import
module.exports.default = lodashMock;
// For named exports
module.exports.clone = lodashMock.clone;
module.exports.cloneDeep = lodashMock.cloneDeep;
module.exports.isEmpty = lodashMock.isEmpty;
module.exports.isString = lodashMock.isString;
module.exports.isObject = lodashMock.isObject;
module.exports.isUndefined = lodashMock.isUndefined;
module.exports.noop = lodashMock.noop;
module.exports.debounce = lodashMock.debounce;
module.exports.isEqual = lodashMock.isEqual;
module.exports.get = lodashMock.get;
