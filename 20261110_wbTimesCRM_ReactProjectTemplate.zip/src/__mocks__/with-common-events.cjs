const React = require("react");

// Mock withCommonEvents HOC - just return the component as-is for testing
const withCommonEvents = (WrappedComponent) => {
  const MockedComponent = React.forwardRef((props, ref) => {
    return React.createElement(WrappedComponent, { ...props, ref });
  });

  MockedComponent.displayName = `withCommonEvents(${WrappedComponent.displayName || WrappedComponent.name})`;

  return MockedComponent;
};

module.exports = { default: withCommonEvents };
