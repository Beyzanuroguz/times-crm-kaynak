const React = require("react");

// Mock antd Tag (default export of "antd/es/tag").
// Renders its children as text and, when closable, a close icon carrying the
// `ant-tag-close-icon` class whose click invokes onClose — matching the real
// Tag surface the Date component relies on for multiple-date selection. Like the
// real Tag, a caller's `data-testid` reaches the tag and a custom `closeIcon` is
// rendered inside the close span.
const Tag = React.forwardRef(({ children, closable, onClose, closeIcon, className, ...props }, ref) =>
  React.createElement(
    "span",
    {
      ...props,
      ref,
      "data-testid": props["data-testid"] ?? "antd-tag",
      className: ["ant-tag", className].filter(Boolean).join(" ")
    },
    children,
    closable
      ? React.createElement(
          "span",
          {
            key: "close",
            role: "button",
            "data-testid": "antd-tag-close",
            className: "ant-tag-close-icon",
            onClick: onClose
          },
          closeIcon
        )
      : null
  )
);

module.exports = Tag;
