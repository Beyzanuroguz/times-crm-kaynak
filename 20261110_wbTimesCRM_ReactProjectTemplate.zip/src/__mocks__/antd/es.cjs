const React = require("react");

// Mock Input component
const Input = React.forwardRef(({ children, ...props }, ref) =>
  React.createElement("input", { ...props, ref, "data-testid": "antd-input" }, children)
);

// Add TextArea as a property of Input
Input.TextArea = React.forwardRef(({ children, ...props }, ref) =>
  React.createElement("textarea", { ...props, ref, "data-testid": "antd-input-textarea" }, children)
);

// Mock DatePicker component
const DatePicker = React.forwardRef(({ children, ...props }, ref) =>
  React.createElement(
    "input",
    {
      ...props,
      ref,
      "data-testid": "antd-datepicker",
      placeholder: props.placeholder || "Select date"
    },
    children
  )
);

// Mock TimePicker component
const TimePicker = React.forwardRef(({ children, ...props }, ref) =>
  React.createElement(
    "input",
    {
      ...props,
      ref,
      "data-testid": "antd-timepicker",
      placeholder: props.placeholder || "Select time"
    },
    children
  )
);

// Mock Button component
const Button = React.forwardRef(({ children, ...props }, ref) =>
  React.createElement("button", { ...props, ref, "data-testid": "antd-button" }, children)
);

// Mock Form components
const Form = {
  Item: ({ children, ...props }) => React.createElement("div", { ...props, "data-testid": "antd-form-item" }, children),
  useForm: () => [{ getFieldsValue: () => ({}), setFieldsValue: () => {} }]
};

// Mock Select component
const Select = React.forwardRef(({ children, ...props }, ref) =>
  React.createElement("select", { ...props, ref, "data-testid": "antd-select" }, children)
);

// Add Option as a property of Select
Select.Option = React.forwardRef(({ children, ...props }, ref) =>
  React.createElement("option", { ...props, ref, "data-testid": "antd-select-option" }, children)
);

// Mock Checkbox component
const Checkbox = React.forwardRef(({ children, indeterminate, ...props }, ref) => {
  const inputRef = React.useRef();
  const combinedRef = ref || inputRef;

  React.useEffect(() => {
    if (combinedRef.current) {
      combinedRef.current.indeterminate = Boolean(indeterminate);
    }
  }, [indeterminate, combinedRef]);

  return React.createElement(
    "input",
    {
      ...props,
      ref: combinedRef,
      type: "checkbox",
      "data-testid": "antd-checkbox"
    },
    children
  );
});

// Mock Radio component
const Radio = {
  Group: React.forwardRef(({ children, ...props }, ref) =>
    React.createElement("div", { ...props, ref, "data-testid": "antd-radio-group" }, children)
  )
};

// Mock Popover component
const Popover = React.forwardRef(({ children, content, trigger, ...props }, ref) =>
  React.createElement(
    "div",
    {
      ...props,
      ref,
      "data-testid": "mock-popover",
      "data-trigger": trigger
    },
    React.createElement("div", { "data-testid": "popover-trigger" }, children),
    React.createElement("div", { "data-testid": "popover-content", style: { display: "none" } }, content)
  )
);

// Mock Collapse component
const Collapse = React.forwardRef(({ children, ...props }, ref) =>
  React.createElement("div", { ...props, ref, "data-testid": "antd-collapse" }, children)
);

// Add Panel as a property of Collapse
Collapse.Panel = React.forwardRef(({ children, ...props }, ref) =>
  React.createElement("div", { ...props, ref, "data-testid": "antd-collapse-panel" }, children)
);

// Mock Statistic component
const Statistic = React.forwardRef(({ children, ...props }, ref) =>
  React.createElement("div", { ...props, ref, "data-testid": "antd-statistic" }, children)
);

// Add Countdown as a property of Statistic
Statistic.Countdown = React.forwardRef(({ children, ...props }, ref) =>
  React.createElement("div", { ...props, ref, "data-testid": "antd-statistic-countdown" }, children)
);

// Mock Tooltip component
const Tooltip = React.forwardRef(({ children, title, color, ...props }, ref) =>
  React.createElement("div", { ...props, ref, "data-testid": "antd-tooltip" }, children)
);

// Mock Spin component — renders its children so a spinning wrapper never hides the
// subtree under test.
const Spin = React.forwardRef(({ children, spinning, ...props }, ref) =>
  React.createElement(
    "div",
    { ...props, ref, "data-testid": "antd-spin", "data-spinning": spinning === true ? "true" : "false" },
    children
  )
);

// Mock Breadcrumb component
const Breadcrumb = React.forwardRef(({ children, className, style, separator }, ref) =>
  React.createElement(
    "div",
    { "data-testid": "breadcrumb", className, style, ref },
    separator && React.createElement("span", { "data-testid": "separator" }, separator),
    children
  )
);

// Add Item as a property of Breadcrumb
Breadcrumb.Item = React.forwardRef(({ children, ...props }, ref) =>
  React.createElement("span", { ...props, ref, "data-testid": "breadcrumb-item" }, children)
);

// Mock missing components
const Divider = React.forwardRef(({ children, ...props }, ref) =>
  React.createElement("div", { ...props, ref, "data-testid": "antd-divider" }, children)
);

const InputNumber = React.forwardRef(({ children, ...props }, ref) =>
  React.createElement("input", { ...props, ref, type: "number", "data-testid": "antd-input-number" }, children)
);

const Space = React.forwardRef(({ children, ...props }, ref) =>
  React.createElement("div", { ...props, ref, "data-testid": "antd-space" }, children)
);

const Table = React.forwardRef(({ children, ...props }, ref) =>
  React.createElement("table", { ...props, ref, "data-testid": "antd-table" }, children)
);

const Empty = React.forwardRef(({ children, ...props }, ref) =>
  React.createElement("div", { ...props, ref, "data-testid": "antd-empty" }, children || "No Data")
);

const Row = React.forwardRef(({ children, ...props }, ref) =>
  React.createElement("div", { ...props, ref, "data-testid": "antd-row" }, children)
);

const Col = React.forwardRef(({ children, ...props }, ref) =>
  React.createElement("div", { ...props, ref, "data-testid": "antd-col" }, children)
);

// Mock Avatar component (+ Avatar.Group for the "+N" overflow chip)
const Avatar = React.forwardRef(({ children, src, icon, size, ...props }, ref) =>
  React.createElement(
    "span",
    {
      ...props,
      ref,
      "data-testid": "antd-avatar",
      "data-src": typeof src === "string" ? src : undefined,
      "data-size": size
    },
    children || icon
  )
);

Avatar.Group = ({ children, maxCount, ...props }) =>
  React.createElement("span", { ...props, "data-testid": "antd-avatar-group", "data-max-count": maxCount }, children);

// ConfigProvider context: BaseTable reads the app locale off it (static contextType), so the stub
// must hand React a real Context object — an undefined contextType is a React error.
const ConfigContext = React.createContext({});

const ConfigProvider = ({ children, locale }) =>
  React.createElement(ConfigContext.Provider, { value: { locale } }, children);

// CommonJS exports
module.exports = {
  ConfigContext,
  ConfigProvider,
  Input,
  DatePicker,
  TimePicker,
  Button,
  Form,
  Select,
  Checkbox,
  Radio,
  Popover,
  Collapse,
  Statistic,
  Tooltip,
  Spin,
  Breadcrumb,
  Divider,
  InputNumber,
  Space,
  Table,
  Empty,
  Row,
  Col,
  Avatar
};
