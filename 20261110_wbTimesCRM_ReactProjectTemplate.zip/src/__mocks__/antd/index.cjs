const React = require("react");

// Mock Input component
const Input = React.forwardRef(({ children, ...props }, ref) =>
  React.createElement("input", { ...props, ref, "data-testid": "antd-input" }, children)
);

// Add TextArea as a property of Input
Input.TextArea = React.forwardRef(({ children, ...props }, ref) =>
  React.createElement("textarea", { ...props, ref, "data-testid": "antd-input-textarea" }, children)
);

// Mock DatePicker component
const DatePicker = React.forwardRef(({ children, ...props }, ref) =>
  React.createElement(
    "input",
    {
      ...props,
      ref,
      "data-testid": "antd-datepicker",
      placeholder: props.placeholder || "Select date"
    },
    children
  )
);

// Mock TimePicker component
const TimePicker = React.forwardRef(({ children, ...props }, ref) =>
  React.createElement(
    "input",
    {
      ...props,
      ref,
      "data-testid": "antd-timepicker",
      placeholder: props.placeholder || "Select time"
    },
    children
  )
);

// Mock Button component
const Button = React.forwardRef(({ children, ...props }, ref) =>
  React.createElement("button", { ...props, ref, "data-testid": "antd-button" }, children)
);

// Mock Form components
const Form = {
  Item: ({ children, ...props }) => React.createElement("div", { ...props, "data-testid": "antd-form-item" }, children),
  useForm: () => [{ getFieldsValue: () => ({}), setFieldsValue: () => {} }]
};

// Mock Select component
const Select = React.forwardRef(({ children, ...props }, ref) =>
  React.createElement("select", { ...props, ref, "data-testid": "antd-select" }, children)
);

// Mock Checkbox component
const Checkbox = React.forwardRef(({ children, indeterminate, ...props }, ref) => {
  const inputRef = React.useRef();
  const combinedRef = ref || inputRef;

  React.useEffect(() => {
    if (combinedRef.current) {
      combinedRef.current.indeterminate = Boolean(indeterminate);
    }
  }, [indeterminate, combinedRef]);

  return React.createElement(
    "input",
    {
      ...props,
      ref: combinedRef,
      type: "checkbox",
      "data-testid": "antd-checkbox"
    },
    children
  );
});

// Mock Radio component
const Radio = {
  Group: React.forwardRef(({ children, ...props }, ref) =>
    React.createElement("div", { ...props, ref, "data-testid": "antd-radio-group" }, children)
  )
};

// Mock Popover component
const Popover = React.forwardRef(({ children, content, trigger, ...props }, ref) =>
  React.createElement(
    "div",
    {
      ...props,
      ref,
      "data-testid": "mock-popover",
      "data-trigger": trigger
    },
    React.createElement("div", { "data-testid": "popover-trigger" }, children),
    React.createElement("div", { "data-testid": "popover-content", style: { display: "none" } }, content)
  )
);

// Mock Collapse component
const Collapse = React.forwardRef(({ children, ...props }, ref) =>
  React.createElement("div", { ...props, ref, "data-testid": "antd-collapse" }, children)
);

// Add Panel as a property of Collapse
Collapse.Panel = React.forwardRef(({ children, ...props }, ref) =>
  React.createElement("div", { ...props, ref, "data-testid": "antd-collapse-panel" }, children)
);

// Mock Statistic component
const Statistic = React.forwardRef(({ children, ...props }, ref) =>
  React.createElement("div", { ...props, ref, "data-testid": "antd-statistic" }, children)
);

// Add Countdown as a property of Statistic
Statistic.Countdown = React.forwardRef(({ children, ...props }, ref) =>
  React.createElement("div", { ...props, ref, "data-testid": "antd-statistic-countdown" }, children)
);

// Mock Tooltip component
const Tooltip = React.forwardRef(({ children, title, color, ...props }, ref) =>
  React.createElement("div", { ...props, ref, "data-testid": "antd-tooltip" }, children)
);

// CommonJS exports
module.exports = {
  Input,
  DatePicker,
  TimePicker,
  Button,
  Form,
  Select,
  Checkbox,
  Radio,
  Popover,
  Collapse,
  Statistic,
  Tooltip
};
