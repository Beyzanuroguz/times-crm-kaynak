import "animate.css/animate.min.css";
// import "antd/dist/antd.min.css";
import { GoogleOAuthProvider } from "@react-oauth/google";
import Axios from "axios";
import React from "react";
import "slick-carousel/slick/slick-theme.css";
import "slick-carousel/slick/slick.css";
import { setInterval, setTimeout } from "worker-timers";
import KuikaAuthApp from "./app-types/kuika-auth-app";
import { parseExternalTokenProviderType } from "./auth/external-provider-type";
import { isMfeHandoffToken, readUsernameFromJwt } from "./auth/jwt-utils";
import LocalStorageService from "./auth/local-storage-service";
import { redeemMfeHandoff } from "./auth/mfe-handoff";
import { TwinChatWidget } from "./components/web-components/twin-dashboard/twin-chat-widget";
import { EExternalTokenProviderTypes } from "./models/dto/login.dto";
import { IRouterType } from "./routes/router";
import { ApplicationService } from "./services/application-service";
import HelperService from "./services/helper-service";
import { UserService } from "./services/user-service";
import { KuikaAppManager } from "./shared/utilty/kuika-app-manager";
import { KMainFunctions } from "./shared/utilty/main-functions";
import "./styles/chinese-ruleset.scss";
import "./styles/components/badge.scss";
import "./styles/components/divider.scss";
import "./styles/components/kanban-board.scss";
import "./styles/fonts.scss";
import "./styles/form.scss";
import "./styles/general.scss";
import "./styles/registration.scss";
// bootstrapper-imports-placeholder
// wasm-import-placeholder

export type IAuthType = "MSAL" | "Kuika";
export type IAppMode = "WebComponent" | "WebSite";

export interface IBootStrapperProps {
  authType: IAuthType;
  routerType?: IRouterType;
  tagName?: string;
  external_access_token?: string;
  external_refresh_token?: string;
  external_user?: string;
  // "External1".."External5" — names the customer's CustomExternalTokenValidator
  // slot when the host is not a Kuika app and therefore cannot mint an MFE
  // handoff token. See auth/external-provider-type.ts.
  external_provider_type?: string;
  startingScreen?: string;
  appMode?: IAppMode;
  // Allow only screenInput_* props with specific typing
  [key: `screenInput_${string}`]: unknown;
}

declare let window: any;

export interface IBootstrapperState {
  // session-service-state-placeholder
  isMounted: boolean;
  // True until the MFE auth handoff (or legacy localStorage bootstrap) finishes.
  // Login-state cookies are now scoped per app by name (is_logged_in__<apiHost>),
  // so PrivateRoute no longer mistakes the host's login for ours. This guard still
  // gates routes while an MFE handoff JWT (or a legacy localStorage token) is being
  // redeemed: our own backend has no session yet, so rendering screens early would
  // produce the 401 → refresh 500 → /login bounce.
  mfeHandoffPending: boolean;
  remainingSessionTime: number;
}

export class AppBootstrapper extends React.Component<IBootStrapperProps, IBootstrapperState> {
  // session-service-declaration-placeholder

  private tokenCheckInterval: any = null;

  private isCheckingToken: boolean = false;

  constructor(props: IBootStrapperProps) {
    super(props);
    this.state = {
      isMounted: false,
      mfeHandoffPending: AppBootstrapper.computeMfeHandoffPending(props),
      // Initial value is set to 99999999999 to prevent the session warning modal from showing up on the first render.
      remainingSessionTime: 99999999999
    };

    const clientSecret = HelperService.getClientSecret();
    const clientId = HelperService.getClientId();

    Axios.defaults.headers.common.ClientSecret = clientSecret;
    Axios.defaults.headers.common["X-ClientId"] = clientId;
  }

  // A handoff is needed when this app is embedded as an MFE AND something
  // outside our own backend already authenticated the user — an MFE handoff JWT
  // injected by a new-auth host, a third-party token destined for one of the
  // customer's External1..External5 validators, or a legacy localStorage token
  // left behind by a pre-cookie-auth host. In every case, our own backend has
  // no session yet and we must redeem before letting routes render.
  private static computeMfeHandoffPending(props: IBootStrapperProps): boolean {
    if (props.appMode !== "WebComponent") return false;
    if (typeof window === "undefined") return false;

    // Both host-supplied credentials are checked BEFORE the login-state cookie.
    // That cookie is keyed per API host, not per user, and lives for 30 days, so
    // a session left behind by a previous user of this browser would otherwise
    // suppress the exchange and serve that user's session to whoever the host
    // embeds next. A token the host just handed us always gets redeemed.
    if (props.external_access_token && isMfeHandoffToken(props.external_access_token)) {
      return true;
    }

    const externalProviderType: EExternalTokenProviderTypes | null = parseExternalTokenProviderType(
      props.external_provider_type
    );
    if (props.external_access_token && externalProviderType !== null) {
      return true;
    }

    const alreadyLoggedInOnOurBackend = KuikaAppManager.readLoginStateCookie("is_logged_in") === "1";
    if (alreadyLoggedInOnOurBackend) return false;

    const hasLegacyToken = !!localStorage.getItem("tokenString");
    return hasLegacyToken;
  }

  getProps = () => {
    if (this.props == undefined) return "";
    return JSON.stringify(this.props);
  };

  checkIsTokenExpired = async () => {
    if (this.isCheckingToken) {
      return;
    }

    this.isCheckingToken = true;

    try {
      if (KuikaAppManager.readLoginStateCookie("is_logged_in") !== "1") {
        return;
      }

      if (location.href.includes("/forgotpassword")) {
        return;
      }

      const isSessionValid: boolean = await UserService.GetIsTokenValid();

      if (isSessionValid === false) {
        if (localStorage.getItem("ml") === "tr_TR") {
          KMainFunctions.displayErrorNotification(
            "Oturum süresi doldu veya başka bir tarayıcıdan giriş yapıldı. Giriş sayfasına yönlendiriliyorsunuz.",
            {
              duration: 15000
            }
          );
        } else {
          KMainFunctions.displayErrorNotification(
            "Session expired or user logged in from another tab/browser. Redirecting to login page in 5 seconds",
            {
              duration: 15000
            }
          );
        }

        setTimeout(() => {
          LocalStorageService.clearToken();
          HelperService.gotoLogin();
        }, 5000);
      }
    } catch (error) {
      console.error("Error checking token expiration:", error);
    } finally {
      this.isCheckingToken = false;
    }
  };

  private startTokenExpirationCheck = () => {
    this.clearTokenExpirationCheck();

    this.checkIsTokenExpired();

    this.tokenCheckInterval = setInterval(() => {
      this.checkIsTokenExpired();
    }, 10000);
  };

  private clearTokenExpirationCheck = () => {
    if (this.tokenCheckInterval) {
      clearInterval(this.tokenCheckInterval);
      this.tokenCheckInterval = null;
    }
  };

  async componentDidMount(): Promise<void> {
    // CODE GENERATION FLAGS!!!
    const IS_SAVE_APPLICATION_ENABLED: boolean = true;
    const IS_EXPIRE_OLD_SESSIONS_ENABLED: boolean = false;

    if (this.props.appMode === "WebSite" && IS_SAVE_APPLICATION_ENABLED) {
      await this.handleRequestSaveApplication();
      await ApplicationService.saveAllApplicationsToSessionStorage();
      ApplicationService.injectPreConnectLinks();
    }

    // When mounted as an MFE, redeem whatever auth proof the host gave us on
    // *our* backend before letting the route tree render — see
    // computeMfeHandoffPending. Our own is_logged_in is read per-app
    // (is_logged_in__<apiHost>), so a handoff is pending only when this app's
    // backend has no session yet, regardless of the host's login state.
    if (this.state.mfeHandoffPending) {
      try {
        await this.runMfeAuthHandoff();
      } finally {
        this.setState({ mfeHandoffPending: false });
      }
    }

    this.setKuikaInfo();

    this.setState({ isMounted: true }, () => {
      localStorage.removeItem("isGoogleLoginInProgress");
      localStorage.removeItem("isGoogleLoginAborted");
    });

    // wasm-initialization-placeholder
    // Note: In generated code, this is replaced with actual WASM init

    // session-service-initialization-placeholder

    if (IS_EXPIRE_OLD_SESSIONS_ENABLED) {
      this.startTokenExpirationCheck();
    }
  }

  componentWillUnmount() {
    // session-service-dispose-placeholder

    this.clearTokenExpirationCheck();
  }

  private runMfeAuthHandoff = async (): Promise<void> => {
    // Path 1 — the host injected a token as external_access_token: either a Kuika
    // MFE handoff JWT, or a third-party token destined for the customer's
    // CustomExternalTokenValidator (named by external_provider_type). We never
    // inspect a third-party token here — the backend validator owns that decision
    // and resolves the username from it.
    //
    // The exchange is shared with the /login route's MfeLogin screen (see
    // auth/mfe-handoff.ts), so a redemption started here is awaited rather than
    // re-posted there, and its outcome is what MfeLogin renders. On failure we
    // fall through: PrivateRoute redirects to /login, where MfeLogin surfaces the
    // reason instead of spinning forever.
    const handoffToken = this.props.external_access_token;
    const externalProviderType: EExternalTokenProviderTypes | null = parseExternalTokenProviderType(
      this.props.external_provider_type
    );
    if (handoffToken && (isMfeHandoffToken(handoffToken) || externalProviderType !== null)) {
      await redeemMfeHandoff({
        accessToken: handoffToken,
        refreshToken: this.props.external_refresh_token,
        username: this.props.external_user,
        providerTypeName: this.props.external_provider_type
      });
      return;
    }

    // Path 2 — pre-cookie-auth host: tokens live in shared localStorage.
    // /auth/loginwithtoken resolves the user from the request's username field,
    // not the JWT signature, so pull UserName out of the legacy token (no
    // signature check needed here — the backend issues a fresh session token).
    const legacyAccessToken = localStorage.getItem("tokenString");
    if (!legacyAccessToken) return;
    const legacyRefreshToken = localStorage.getItem("refreshToken");
    const username = readUsernameFromJwt(legacyAccessToken);
    if (!username) return;

    try {
      await UserService.LoginWithExternalToken({
        providerType: EExternalTokenProviderTypes.None,
        username,
        tokenString: legacyAccessToken,
        refreshToken: legacyRefreshToken ?? ""
      });
    } catch {
      // Best-effort fallback. If the legacy token can't be exchanged, regular
      // PrivateRoute redirects to login as before.
    }
  };

  setKuikaInfo() {
    if (this.props === undefined) {
      return;
    }
    if (!window.kuika) {
      window.kuika = {};
    }
    window.kuika.info = {};
    const appName = "wbTimesCRM";
    const workspace = "reslen_01";
    const webComponentTag = "reslen-01-wb-times-crm";
    const frontEndUrl = KuikaAppManager.GetFrontEndSourceUrl();
    const backEndUrl = KuikaAppManager.GetBackendUrl(true);
    const { authType } = this.props;
    const html = String.raw`
      <html>
        <head>
        <script src='%PUBLIC_URL%/assets/kuika-mfe_1_0_0.js'></script>
        <script>
        CreateKuikaMfeApp({frontEndUrl:'${frontEndUrl}'});
        </script>
        </head>
        <body>
          <reslen-01-wb-times-crm></reslen-01-wb-times-crm>
        </body>
      </html>`;
    window.kuika.info.workspace = workspace;
    window.kuika.info.applicationName = appName;
    window.kuika.info.webComponentTag = webComponentTag;
    window.kuika.info.frontEndUrl = frontEndUrl;
    window.kuika.info.backEndUrl = backEndUrl;
    window.kuika.info.authType = authType;
    window.kuika.html = html;
    window.kuika.getModule = () => {
      console.log(window.kuika.html);
    };
  }

  handleRequestSaveApplication = async () => {
    const SAVE_APP_REQUEST_KEY = `SAVE_APP_REQUESTED_${KMainFunctions.virtualDirectoryURL}`;

    const isRequestedBefore: string = sessionStorage.getItem(SAVE_APP_REQUEST_KEY);

    if (isRequestedBefore) {
      return;
    }

    try {
      await ApplicationService.saveApplication();
      sessionStorage.setItem(SAVE_APP_REQUEST_KEY, "true");
    } catch (e) {
      setTimeout(this.handleRequestSaveApplication.bind(this), 10000);
    }
  };

  // session-timeout-methods-placeholder

  updateRemainingSessionTime = (remainingSessionTime: number) => {
    this.setState({ remainingSessionTime });
  };

  private getScreenInputProps = (): Record<string, unknown> => {
    const screenInputProps: Record<string, unknown> = {};
    Object.keys(this.props || {}).forEach((key) => {
      if (key.startsWith("screenInput_")) {
        screenInputProps[key] = this.props[key];
      }
    });
    return screenInputProps;
  };

  public render() {
    // Render nothing until the MFE auth handoff completes. The screen tree
    // (PrivateRoute → starting screen → componentDidMount → API calls) runs
    // synchronously on first render, so any delayed redemption would race the
    // first API call and we'd be back to the 401 → refresh 500 → /login bounce.
    if (this.state.mfeHandoffPending) {
      return null;
    }

    return (
      <GoogleOAuthProvider clientId="GOOGLEKEY">
        <KuikaAuthApp
          authType={this.props.authType}
          routerType={this.props.routerType}
          appMode={this.props.appMode}
          external_user={this.props.external_user}
          external_access_token={this.props.external_access_token}
          external_refresh_token={this.props.external_refresh_token}
          external_provider_type={this.props.external_provider_type}
          startingScreen={this.props.startingScreen}
          {...this.getScreenInputProps()}
        />
        {/* Twin chat: a global floating FAB (bottom-right), mounted once at the app
            root so it persists across screen navigation. Renders nothing unless Twin
            is configured and the user is logged in. */}
        <TwinChatWidget />
        {/* session-service-modal-placeholder */}
      </GoogleOAuthProvider>
    );
  }
}

export default AppBootstrapper;
