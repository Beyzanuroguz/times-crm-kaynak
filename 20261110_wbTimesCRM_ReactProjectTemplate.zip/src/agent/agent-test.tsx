import * as React from "react";

export class AgentTest extends React.Component<any, any> {
  constructor(props: any) {
    super(props);
    this.state = {};
  }

  public render() {
    return <div>test</div>;
  }
}
