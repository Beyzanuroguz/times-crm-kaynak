import { Component, CSSProperties, ReactNode, RefObject, createRef } from "react";
import { ICaptureConfig, captureVideoFrame } from "./capture-helpers";

/**
 * In-repo replacement for react-html5-camera-photo (KOA-17786).
 *
 * Keeps that library's DOM contract — the `.react-html5-camera-photo` root,
 * an always-present <img> that receives the captured data URI, the <video>
 * preview and the `#container-circles` shutter button — because
 * `takePhotoKuikaFunction`, `handleClosePhoto` and the styles in general.scss
 * are all keyed to it. What changes is the capture path: the video is played
 * explicitly (autoplay can be blocked on Android battery/data saver), capture
 * waits until the video has a decodable frame, and solid-black captures are
 * retried while the camera pipeline warms up.
 */

export const FACING_MODES: { ENVIRONMENT: "environment"; USER: "user" } = {
  ENVIRONMENT: "environment",
  USER: "user"
};

export const IMAGE_TYPES: { JPG: "jpg"; PNG: "png" } = {
  JPG: "jpg",
  PNG: "png"
};

export type FacingMode = (typeof FACING_MODES)[keyof typeof FACING_MODES];
export type ImageType = (typeof IMAGE_TYPES)[keyof typeof IMAGE_TYPES];

interface KuikaCameraProps {
  imageType?: ImageType;
  imageCompression?: number;
  isImageMirror?: boolean;
  idealFacingMode?: FacingMode;
  isFullscreen?: boolean;
  onTakePhoto?: (dataUri: string) => void;
  onCameraError?: (error: Error) => void;
}

interface KuikaCameraState {
  dataUri: string;
  isShowVideo: boolean;
  cameraStartError: string;
}

const DEFAULT_JPG_COMPRESSION: number = 0.92;

export class Camera extends Component<KuikaCameraProps, KuikaCameraState> {
  private videoRef: RefObject<HTMLVideoElement> = createRef<HTMLVideoElement>();

  private stream: MediaStream | null = null;

  private isUnmounted: boolean = false;

  private isCapturing: boolean = false;

  constructor(props: KuikaCameraProps) {
    super(props);
    this.state = { dataUri: "", isShowVideo: true, cameraStartError: "" };
  }

  async componentDidMount(): Promise<void> {
    await this.startCamera();
  }

  componentWillUnmount(): void {
    this.isUnmounted = true;
    this.stopCamera();
  }

  private startCamera = async (): Promise<void> => {
    const facingMode: FacingMode = this.props.idealFacingMode ?? FACING_MODES.ENVIRONMENT;
    const constraints: MediaStreamConstraints = { audio: false, video: { facingMode } };
    try {
      const stream: MediaStream = await navigator.mediaDevices.getUserMedia(constraints);
      if (this.isUnmounted) {
        stream.getTracks().forEach((track: MediaStreamTrack) => track.stop());
        return;
      }
      this.stream = stream;
      const video: HTMLVideoElement | null = this.videoRef.current;
      if (!video) {
        return;
      }
      video.srcObject = stream;
      try {
        await video.play();
      } catch {
        // Autoplay may be blocked (e.g. Android battery saver). The shutter
        // tap is a user gesture, so capture retries play() at that point.
      }
    } catch (error) {
      const startError: Error = error instanceof Error ? error : new Error(String(error));
      if (!this.isUnmounted) {
        this.setState({ cameraStartError: `${startError.name} ${startError.message}` });
      }
      if (typeof this.props.onCameraError === "function") {
        this.props.onCameraError(startError);
      }
    }
  };

  private stopCamera = (): void => {
    if (this.stream) {
      this.stream.getTracks().forEach((track: MediaStreamTrack) => track.stop());
      this.stream = null;
    }
    const video: HTMLVideoElement | null = this.videoRef.current;
    if (video) {
      video.srcObject = null;
    }
  };

  private handleTakePhoto = async (): Promise<void> => {
    const video: HTMLVideoElement | null = this.videoRef.current;
    if (!video || this.isCapturing) {
      return;
    }
    this.isCapturing = true;
    try {
      const config: ICaptureConfig = {
        imageType: this.props.imageType ?? IMAGE_TYPES.PNG,
        imageCompression: this.props.imageCompression ?? DEFAULT_JPG_COMPRESSION,
        isImageMirror: this.props.isImageMirror ?? false
      };
      const dataUri: string = await captureVideoFrame(video, config);
      if (this.isUnmounted || dataUri === "") {
        // No decodable frame arrived in time; keep the preview open so the
        // user can tap again instead of delivering a broken image.
        return;
      }
      this.setState({ dataUri, isShowVideo: false });
      if (typeof this.props.onTakePhoto === "function") {
        this.props.onTakePhoto(dataUri);
      }
    } finally {
      this.isCapturing = false;
    }
  };

  private renderError(): ReactNode {
    if (!this.state.cameraStartError) {
      return null;
    }
    return (
      <div className="display-error" id="display-error">
        <h1>Camera error: {this.state.cameraStartError}</h1>
      </div>
    );
  }

  render(): ReactNode {
    const fullscreenClass: string = this.props.isFullscreen ? " react-html5-camera-photo-fullscreen" : "";
    const mirrorTransform: string = this.props.isImageMirror ? "rotateY(180deg)" : "none";
    const videoStyle: CSSProperties = {
      transform: mirrorTransform,
      display: this.state.isShowVideo ? "inline-block" : "none"
    };
    const imageStyle: CSSProperties = { display: this.state.isShowVideo ? "none" : "inline-block" };
    const flashClassName: string = this.state.isShowVideo ? "normal" : "do-transition normal";

    return (
      <div className={`react-html5-camera-photo${fullscreenClass}`}>
        {this.renderError()}
        <div id="white-flash" className={flashClassName}></div>
        <img style={imageStyle} alt="camera" src={this.state.dataUri} />
        <video style={videoStyle} ref={this.videoRef} autoPlay muted playsInline />
        <div id="container-circles">
          <div id="outer-circle" onClick={this.handleTakePhoto}>
            <div id="inner-circle" className={this.state.isShowVideo ? "" : "is-clicked"}></div>
          </div>
        </div>
      </div>
    );
  }
}

export default Camera;
