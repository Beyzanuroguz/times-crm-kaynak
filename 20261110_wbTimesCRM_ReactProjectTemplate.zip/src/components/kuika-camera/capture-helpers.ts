/**
 * Frame-capture helpers for KuikaCameraPhoto (KOA-17786).
 *
 * The previous implementation (react-html5-camera-photo) drew the <video>
 * element onto a canvas without checking that the video was actually playing
 * or had a decodable frame. On Android Chrome the video can legitimately have
 * no current frame at tap time (autoplay blocked by battery/data saver,
 * camera pipeline warm-up), and JPEG-encoding an empty canvas produces a
 * solid black image. These helpers make capture wait for a real frame and
 * retry when the captured frame is effectively black.
 */

export const HAVE_CURRENT_DATA: number = 2;

/** Pixels with every channel below this value count as black. */
const BLACK_CHANNEL_THRESHOLD: number = 12;
/** A frame is "black" when at least this ratio of sampled pixels is black. */
const BLACK_PIXEL_RATIO: number = 0.995;
/** Downscale size used when sampling a captured frame for blackness. */
const SAMPLE_SIZE: number = 16;
/** How many times a black capture is retried before it is accepted as-is. */
const MAX_BLACK_FRAME_RETRIES: number = 3;
/** Upper bound for waiting on playback/frames so capture can never hang. */
const WAIT_FOR_FRAME_TIMEOUT_MS: number = 2000;
const NEXT_FRAME_TIMEOUT_MS: number = 300;
const READY_STATE_POLL_INTERVAL_MS: number = 50;

export interface ICaptureConfig {
  imageType: "jpg" | "png";
  imageCompression: number;
  isImageMirror: boolean;
}

/**
 * True when the RGBA byte array is effectively a solid black frame.
 * Exposed for unit tests.
 */
export function isImageDataBlack(rgba: Uint8ClampedArray): boolean {
  const pixelCount: number = Math.floor(rgba.length / 4);
  if (pixelCount === 0) {
    return true;
  }
  let blackPixels: number = 0;
  for (let i = 0; i < pixelCount; i++) {
    const offset: number = i * 4;
    const r: number = rgba[offset];
    const g: number = rgba[offset + 1];
    const b: number = rgba[offset + 2];
    if (r < BLACK_CHANNEL_THRESHOLD && g < BLACK_CHANNEL_THRESHOLD && b < BLACK_CHANNEL_THRESHOLD) {
      blackPixels++;
    }
  }
  return blackPixels / pixelCount >= BLACK_PIXEL_RATIO;
}

function delay(ms: number): Promise<void> {
  return new Promise((resolve) => {
    setTimeout(resolve, ms);
  });
}

/**
 * Ensures the video is playing and has a decodable frame. Must be called from
 * a user-gesture context (the shutter tap) so that `play()` is permitted even
 * when autoplay was blocked (e.g. Android battery saver).
 */
export async function ensureVideoHasFrame(video: HTMLVideoElement): Promise<void> {
  if (video.paused) {
    try {
      await video.play();
    } catch {
      // play() can still be rejected (e.g. camera revoked); the readyState
      // wait below bounds how long capture stalls in that case.
    }
  }

  const deadline: number = Date.now() + WAIT_FOR_FRAME_TIMEOUT_MS;
  while (Date.now() < deadline) {
    if (video.readyState >= HAVE_CURRENT_DATA && video.videoWidth > 0 && video.videoHeight > 0) {
      return;
    }
    await delay(READY_STATE_POLL_INTERVAL_MS);
  }
}

/**
 * Resolves when the video delivers its next frame. Uses
 * requestVideoFrameCallback where available (Chrome, Safari 15.4+); falls
 * back to a short delay elsewhere. Always resolves within NEXT_FRAME_TIMEOUT_MS.
 */
export function waitForNextFrame(video: HTMLVideoElement): Promise<void> {
  return new Promise((resolve) => {
    let settled: boolean = false;
    const finish = (): void => {
      if (!settled) {
        settled = true;
        clearTimeout(timer);
        resolve();
      }
    };
    const timer: ReturnType<typeof setTimeout> = setTimeout(finish, NEXT_FRAME_TIMEOUT_MS);
    if (typeof video.requestVideoFrameCallback === "function") {
      video.requestVideoFrameCallback(finish);
    }
  });
}

function drawVideoFrame(video: HTMLVideoElement, config: ICaptureConfig): HTMLCanvasElement {
  const canvas: HTMLCanvasElement = document.createElement("canvas");
  canvas.width = video.videoWidth;
  canvas.height = video.videoHeight;
  const context: CanvasRenderingContext2D | null = canvas.getContext("2d");
  if (!context) {
    return canvas;
  }
  if (config.isImageMirror) {
    context.setTransform(-1, 0, 0, 1, canvas.width, 0);
  }
  context.drawImage(video, 0, 0, canvas.width, canvas.height);
  return canvas;
}

function isCanvasBlack(canvas: HTMLCanvasElement): boolean {
  const sampleCanvas: HTMLCanvasElement = document.createElement("canvas");
  sampleCanvas.width = SAMPLE_SIZE;
  sampleCanvas.height = SAMPLE_SIZE;
  const sampleContext: CanvasRenderingContext2D | null = sampleCanvas.getContext("2d");
  if (!sampleContext) {
    return false;
  }
  sampleContext.drawImage(canvas, 0, 0, SAMPLE_SIZE, SAMPLE_SIZE);
  try {
    const imageData: ImageData = sampleContext.getImageData(0, 0, SAMPLE_SIZE, SAMPLE_SIZE);
    return isImageDataBlack(imageData.data);
  } catch {
    // getImageData can throw on tainted canvases; camera frames are never
    // tainted, but never let diagnostics break the capture itself.
    return false;
  }
}

function canvasToDataUri(canvas: HTMLCanvasElement, config: ICaptureConfig): string {
  if (config.imageType === "jpg") {
    return canvas.toDataURL("image/jpeg", config.imageCompression);
  }
  return canvas.toDataURL("image/png");
}

/**
 * Captures the current video frame as a data URI. Waits until the video is
 * actually delivering frames and retries a bounded number of times when the
 * captured frame is solid black (Android camera warm-up), so a covered lens
 * still produces a photo instead of blocking forever.
 */
export async function captureVideoFrame(video: HTMLVideoElement, config: ICaptureConfig): Promise<string> {
  await ensureVideoHasFrame(video);

  let canvas: HTMLCanvasElement = drawVideoFrame(video, config);
  for (let attempt = 0; attempt < MAX_BLACK_FRAME_RETRIES; attempt++) {
    if (canvas.width === 0 || canvas.height === 0 || isCanvasBlack(canvas)) {
      await waitForNextFrame(video);
      canvas = drawVideoFrame(video, config);
    } else {
      break;
    }
  }

  if (canvas.width === 0 || canvas.height === 0) {
    return "";
  }
  return canvasToDataUri(canvas, config);
}
