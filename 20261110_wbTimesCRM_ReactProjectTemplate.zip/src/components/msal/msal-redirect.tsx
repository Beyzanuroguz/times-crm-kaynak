import { readAuthErrorMessage } from "../../auth/auth-error-message";
import { EExternalTokenProviderTypes, IExternalTokenRequest } from "../../models/dto/login.dto";
import HelperService from "../../services/helper-service";
import { UserService } from "../../services/user-service";
import { KuikaAppManager } from "../../shared/utilty/kuika-app-manager";
import { KMainFunctions } from "../../shared/utilty/main-functions";
import { msalConfig } from "./msal-auth-config";

export const MsalRedirect = (props) => {
  const loginWithMsal = (codeParam: string) => {
    const externalTokenRequest: IExternalTokenRequest = {
      providerType: EExternalTokenProviderTypes.AzureAD,
      refreshToken: "",
      tokenString: "",
      username: "",
      redirectUri: window.location.origin + msalConfig.redirectUri,
      externalParameters: { code: codeParam }
    };
    UserService.LoginWithExternalToken(externalTokenRequest).then(
      (res) => {
        if (res && res.status === 200) {
          HelperService.redirectGotoStartingScreen();
        }
      },
      (error: unknown) => {
        // LoginWithExternalToken rejects on failure, so this handler is the only
        // thing standing between a rejected Azure AD exchange and a permanent
        // "Please wait..." screen.
        console.error("MSAL login failed:", error);
        KMainFunctions.displayErrorNotification(readAuthErrorMessage(error));
      }
    );
  };

  if (KuikaAppManager.readLoginStateCookie("is_logged_in") === "1") {
    HelperService.redirectGotoStartingScreen();
    return <></>;
  }

  if (window.location?.search?.length > 1) {
    var codeParam = new URLSearchParams(window.location?.search).get("code");
    if (codeParam && codeParam.length > 0) {
      loginWithMsal(codeParam);
    }
  }

  return <>Please wait...</>;
};
