export const msalConfig = {
  clientId: "@MSALClientId",
  authority: "https://login.microsoftonline.com/common",
  redirectUri: "/msalredirect",
  postLogoutRedirectUri: "/logout",
  scope: "user.read"
};
