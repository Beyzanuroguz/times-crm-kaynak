import { KuikaAppManager } from "../../shared/utilty/kuika-app-manager";
import { ReactSystemFunctions } from "../../shared/utilty/react-system-functions";

export const NotificationRedirect = (props) => {
  const query = new URLSearchParams(window.location.search);
  const screenId = query.get("screenId");
  const parametersStr = query.get("parameters");

  let parameters: any = {};
  try {
    parameters = parametersStr ? JSON.parse(parametersStr) : {};
  } catch (e) {
    console.error(e);
  }

  const path = getPathFromScreenId(screenId, parameters);
  console.log(path);

  // Security: validate redirect URL is same-origin to prevent open redirect / XSS
  try {
    const url = new URL(path, window.location.origin);
    if (url.origin !== window.location.origin) {
      console.error("Redirect blocked: cross-origin URL detected");
      window.location.href = KuikaAppManager.GetFrontEndUrl();
      return null;
    }
    window.location.href = url.href;
  } catch {
    window.location.href = KuikaAppManager.GetFrontEndUrl();
  }

  return null;
};

function getPathFromScreenId(screenId: string | null, parameters: any): string {
  if (!screenId) return KuikaAppManager.GetFrontEndUrl();

  var screenName = ReactSystemFunctions.getScreenNameById(screenId);
  var path = `${KuikaAppManager.GetFrontEndUrl()}/${screenName}`;

  const { screenId: _, ...rest } = parameters;

  const query = new URLSearchParams(rest).toString();
  return query ? `${path}?${query}` : path;
}
