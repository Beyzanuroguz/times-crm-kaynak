import { useCallback, useEffect, useState } from "react";
import {
  forgetMfeHandoff,
  IMfeHandoffRequest,
  IMfeHandoffResult,
  peekMfeHandoff,
  redeemMfeHandoff
} from "../../auth/mfe-handoff";
import { withHistory } from "../../shared/hoc/with-history";
import { KuikaAppManager } from "../../shared/utilty/kuika-app-manager";
import "../../styles/components/mfe-login-error.scss";

interface IMfeLoginFromLocation {
  pathname?: string;
}

/** The slice of KNavigator this screen needs — injected by withHistory. */
export interface IMfeLoginNavigator {
  gotoUrl: (url: string) => void;
  gotoStartingScreen: (screen?: string) => Promise<void> | void;
}

export interface IMfeLoginProps {
  external_user?: string;
  external_access_token?: string;
  external_refresh_token?: string;
  external_provider_type?: string;
  from?: IMfeLoginFromLocation;
  navigator: IMfeLoginNavigator;
}

const MfeLogin = (props: IMfeLoginProps): JSX.Element => {
  const token: string = props.external_access_token ?? "";
  const isTurkish: boolean = localStorage.getItem("ml") === "tr_TR";
  const [errorMessage, setErrorMessage] = useState<string>("");
  const [retryCount, setRetryCount] = useState<number>(0);

  const buildRequest = useCallback(
    (): IMfeHandoffRequest => ({
      accessToken: token,
      refreshToken: props.external_refresh_token,
      username: props.external_user,
      providerTypeName: props.external_provider_type
    }),
    [token, props.external_refresh_token, props.external_user, props.external_provider_type]
  );

  const goToNextScreen = useCallback((): void => {
    const fromPathname: string | undefined = props.from?.pathname;
    if (fromPathname !== undefined && fromPathname.length > 0) {
      props.navigator.gotoUrl(fromPathname);
      return;
    }
    props.navigator.gotoStartingScreen();
  }, [props.from, props.navigator]);

  useEffect(() => {
    if (token.length === 0) return undefined;

    const request: IMfeHandoffRequest = buildRequest();
    let isCancelled: boolean = false;

    // A settled success for THIS token means the bootstrapper (or a sibling
    // instance) already exchanged it. Only then is the login-state cookie proof
    // that the session belongs to the identity the host just handed us: the
    // cookie is keyed per API host, not per user, so trusting it on its own
    // would serve a previous user's session to whoever the host embeds next.
    // If it says we are not logged in, the session went away after redemption —
    // drop the memo so the exchange runs again instead of bouncing off
    // PrivateRoute forever.
    const settled: IMfeHandoffResult | null = peekMfeHandoff(request);
    if (settled?.succeeded === true) {
      const isLoggedIn: boolean = KuikaAppManager.readLoginStateCookie("is_logged_in") === "1";
      if (isLoggedIn) {
        goToNextScreen();
        return undefined;
      }
      forgetMfeHandoff(request);
    }

    const redeem = async (): Promise<void> => {
      // Shared across instances and remounts: an exchange already in flight is
      // awaited rather than re-posted, and its outcome reaches whichever
      // instance is mounted when it settles.
      const result: IMfeHandoffResult = await redeemMfeHandoff(request);
      if (isCancelled) return;
      if (result.succeeded) {
        goToNextScreen();
        return;
      }
      setErrorMessage(result.errorMessage);
    };

    void redeem();

    return () => {
      isCancelled = true;
    };
  }, [token, buildRequest, goToNextScreen, retryCount]);

  const onRetry = useCallback((): void => {
    forgetMfeHandoff(buildRequest());
    setErrorMessage("");
    setRetryCount((previous: number) => previous + 1);
  }, [buildRequest]);

  if (errorMessage.length > 0) {
    return (
      <div className="kuika-mfe-login-error" role="alert">
        <strong>{isTurkish ? "Giriş yapılamadı" : "Sign-in failed"}</strong>
        <div>{errorMessage}</div>
        <button type="button" onClick={onRetry}>
          {isTurkish ? "Tekrar dene" : "Try again"}
        </button>
      </div>
    );
  }

  return (
    <>
      {isTurkish ? "Giriş servisine bağlanılıyor, lütfen bekleyin..." : "Connecting to login service, please wait..."}
    </>
  );
};

const mfeLogin = withHistory(MfeLogin);
export { mfeLogin as MfeLogin };
