// Shared coordinator that keeps fixed-position floating elements (FloatButtons, plus
// a reservation for the Twin chat FAB) from overlapping at the same screen corner.
// Items stack in **DOM document order** (so the visual order follows the design tree
// and updates when DisplayItems are reordered); each keeps its own base offset and is
// only auto-bumped further from the corner when it would collide with the one before
// it. Stacking is vertical, per corner — no shared z-index context, so no z-index
// fight either.

export type FloatCorner = "top left" | "top right" | "bottom left" | "bottom right";

// Vertical gap left between two stacked items.
const STACK_GAP_PX: number = 12;

// The Twin chat FAB's footprint, copied from Twin's own FAB (apps/web/src/mfe/chat:
// `h-14 w-14` = 56px, `bottom-6 right-6` = 24px). Twin pins it bottom-right, so we
// reserve from the bottom edge (0) up to its top edge (24 + 56) — FloatButtons then
// stack above the real FAB regardless of their own offset.
export const TWIN_CHAT_FAB_SIZE_PX: number = 56;
export const TWIN_CHAT_FAB_BOTTOM_PX: number = 24;

interface FloatStackItem {
  id: number;
  corner: FloatCorner;
  // Base distance from the corner's vertical edge (bottom for bottom corners, top for
  // top corners), in px — the element's own offsetY.
  baseOffset: number;
  height: number;
  // DOM node, used to order the stack by document (tree) order. null for a reservation
  // (e.g. the runtime chat FAB), which sorts to the bottom of the corner.
  node: HTMLElement | null;
  // When true, this item is pinned to the very bottom of the corner regardless of tree
  // order (the Twin chat: Twin renders its real FAB at the corner at runtime, so the
  // design-time preview must match — always bottom-most, with other FABs above it).
  anchorBottom: boolean;
  // Called with the computed vertical offset whenever the layout changes. Reservation
  // items omit this — they don't move.
  onLayout?: (offset: number) => void;
}

interface KuikaDesignTimeFlag {
  isDesignTime?: boolean;
}

interface KuikaWindow extends Window {
  kuika?: KuikaDesignTimeFlag;
}

let nextId: number = 1;
const items: FloatStackItem[] = [];

const CORNERS: FloatCorner[] = ["bottom right", "bottom left", "top right", "top left"];

function isDesignTime(): boolean {
  return typeof window !== "undefined" && (window as KuikaWindow).kuika?.isDesignTime === true;
}

// Orders items within a corner: bottom-anchored items (the Twin chat) first (very
// bottom), then flow items by DOM document order so the visual stack follows the
// design tree. Ties fall back to registration order for stability.
function compareStackOrder(a: FloatStackItem, b: FloatStackItem): number {
  if (a.anchorBottom !== b.anchorBottom) {
    return a.anchorBottom ? -1 : 1;
  }
  if (!a.node && !b.node) {
    return a.id - b.id;
  }
  if (!a.node) {
    return -1;
  }
  if (!b.node) {
    return 1;
  }
  const relation: number = a.node.compareDocumentPosition(b.node);
  if (relation & Node.DOCUMENT_POSITION_FOLLOWING) {
    return -1;
  }
  if (relation & Node.DOCUMENT_POSITION_PRECEDING) {
    return 1;
  }
  return a.id - b.id;
}

function recompute(): void {
  for (const corner of CORNERS) {
    const group: FloatStackItem[] = items.filter((i) => i.corner === corner).sort(compareStackOrder);

    // Distance-from-corner of the top edge of the last placed item.
    let placedTopEdge: number = 0;
    for (const item of group) {
      const offset: number =
        placedTopEdge === 0 ? item.baseOffset : Math.max(item.baseOffset, placedTopEdge + STACK_GAP_PX);
      placedTopEdge = offset + item.height;
      if (item.onLayout) {
        item.onLayout(offset);
      }
    }
  }
}

// Design-time only: reordering DisplayItems moves the floating elements' DOM nodes
// without re-registering them, so watch the document for structural changes and
// recompute the stack order. (At runtime the tree is static, so no observer.)
let reorderObserver: MutationObserver | null = null;
let recomputeScheduled: boolean = false;

function scheduleRecompute(): void {
  if (recomputeScheduled) {
    return;
  }
  recomputeScheduled = true;
  requestAnimationFrame((): void => {
    recomputeScheduled = false;
    recompute();
  });
}

function ensureReorderObserver(): void {
  if (reorderObserver || typeof MutationObserver === "undefined" || typeof document === "undefined") {
    return;
  }
  if (!isDesignTime()) {
    return;
  }
  reorderObserver = new MutationObserver((): void => {
    scheduleRecompute();
  });
  // childList/subtree only (not attributes) — our own onLayout writes inline styles,
  // which must not re-trigger the observer.
  reorderObserver.observe(document.body, { childList: true, subtree: true });
}

function teardownReorderObserverIfIdle(): void {
  if (reorderObserver && items.length === 0) {
    reorderObserver.disconnect();
    reorderObserver = null;
  }
}

// Registers a floating element in a corner's stack. Returns an unregister fn. Pass the
// element's DOM `node` so the stack can order by document position; set `anchorBottom`
// to pin it to the very bottom of the corner regardless of tree order (the Twin chat);
// `onLayout` is called immediately (and on any later change) with the computed offset —
// omit it for a non-moving reservation (e.g. the chat FAB), and pass `node: null` too.
export function registerFloatStackItem(
  corner: FloatCorner,
  baseOffset: number,
  height: number,
  node: HTMLElement | null,
  anchorBottom: boolean,
  onLayout?: (offset: number) => void
): () => void {
  const item: FloatStackItem = { id: nextId++, corner, baseOffset, height, node, anchorBottom, onLayout };
  items.push(item);
  ensureReorderObserver();
  recompute();
  return (): void => {
    const idx: number = items.indexOf(item);
    if (idx !== -1) {
      items.splice(idx, 1);
      recompute();
      teardownReorderObserverIfIdle();
    }
  };
}

// Reserves the Twin chat FAB's bottom-right footprint so FloatButtons stack above it.
// The chat FAB itself doesn't move (Twin positions it), so this is a no-op reservation
// occupying the bottom edge up to the FAB's top edge. Returns an unregister fn.
export function reserveTwinChatFabSlot(): () => void {
  return registerFloatStackItem(
    "bottom right",
    0,
    TWIN_CHAT_FAB_BOTTOM_PX + TWIN_CHAT_FAB_SIZE_PX,
    null,
    /* anchorBottom */ true
  );
}
