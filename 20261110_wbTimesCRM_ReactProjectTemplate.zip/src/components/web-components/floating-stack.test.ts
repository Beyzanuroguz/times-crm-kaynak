import { registerFloatStackItem, reserveTwinChatFabSlot } from "./floating-stack";

// The coordinator keeps module-level state; each test cleans up its registrations via
// the returned unregister fns so cases don't bleed into each other. Items registered
// with a null node and anchorBottom=false fall back to registration order (stable).
describe("floating-stack coordinator", () => {
  it("places a lone item at its own base offset", () => {
    let offset: number | null = null;
    const unregister: () => void = registerFloatStackItem("bottom right", 20, 40, null, false, (o: number): void => {
      offset = o;
    });

    expect(offset).toBe(20);
    unregister();
  });

  it("bumps a colliding second item above the first (with a gap)", () => {
    const offsets: Record<string, number> = {};
    const u1: () => void = registerFloatStackItem("bottom right", 20, 40, null, false, (o: number): void => {
      offsets.a = o;
    });
    const u2: () => void = registerFloatStackItem("bottom right", 20, 40, null, false, (o: number): void => {
      offsets.b = o;
    });

    // First stays at 20; second is bumped to 20 + 40 (height) + 12 (gap) = 72.
    expect(offsets.a).toBe(20);
    expect(offsets.b).toBe(72);

    u1();
    u2();
  });

  it("does not bump when items don't overlap", () => {
    const offsets: Record<string, number> = {};
    const u1: () => void = registerFloatStackItem("bottom right", 20, 40, null, false, (o: number): void => {
      offsets.a = o;
    });
    // Base 200 is well clear of the first item's top edge (60), so it keeps its base.
    const u2: () => void = registerFloatStackItem("bottom right", 200, 40, null, false, (o: number): void => {
      offsets.b = o;
    });

    expect(offsets.a).toBe(20);
    expect(offsets.b).toBe(200);

    u1();
    u2();
  });

  it("keeps corners independent", () => {
    const offsets: Record<string, number> = {};
    const u1: () => void = registerFloatStackItem("bottom right", 20, 40, null, false, (o: number): void => {
      offsets.right = o;
    });
    const u2: () => void = registerFloatStackItem("bottom left", 20, 40, null, false, (o: number): void => {
      offsets.left = o;
    });

    // Different corners never collide.
    expect(offsets.right).toBe(20);
    expect(offsets.left).toBe(20);

    u1();
    u2();
  });

  it("orders the stack by DOM document order, not registration order", () => {
    const a: HTMLDivElement = document.createElement("div");
    const b: HTMLDivElement = document.createElement("div");
    const c: HTMLDivElement = document.createElement("div");
    document.body.append(a, b, c); // DOM order: a, b, c

    const offsets: Record<string, number> = {};
    // Register in a scrambled order — the stack must still follow DOM order a, b, c.
    const uc: () => void = registerFloatStackItem("bottom right", 20, 40, c, false, (o: number): void => {
      offsets.c = o;
    });
    const ua: () => void = registerFloatStackItem("bottom right", 20, 40, a, false, (o: number): void => {
      offsets.a = o;
    });
    const ub: () => void = registerFloatStackItem("bottom right", 20, 40, b, false, (o: number): void => {
      offsets.b = o;
    });

    expect(offsets.a).toBe(20); // bottom (first in DOM)
    expect(offsets.b).toBe(72);
    expect(offsets.c).toBe(124); // top (last in DOM)

    ua();
    ub();
    uc();
    a.remove();
    b.remove();
    c.remove();
  });

  it("pins an anchored item to the bottom regardless of DOM order", () => {
    const a: HTMLDivElement = document.createElement("div");
    const b: HTMLDivElement = document.createElement("div");
    document.body.append(a, b); // DOM order: a, b — so a would normally be bottom

    const offsets: Record<string, number> = {};
    // a is a normal flow FAB (first in DOM); b is anchored to the bottom. Anchoring must
    // win: b sits at the bottom and a stacks above it, even though a is earlier in DOM.
    const ua: () => void = registerFloatStackItem("bottom right", 20, 40, a, false, (o: number): void => {
      offsets.a = o;
    });
    const ub: () => void = registerFloatStackItem("bottom right", 24, 56, b, true, (o: number): void => {
      offsets.b = o;
    });

    expect(offsets.b).toBe(24); // anchored → bottom (its own base)
    expect(offsets.a).toBe(92); // flow → above the anchored item (24 + 56 + 12)

    ua();
    ub();
    a.remove();
    b.remove();
  });

  it("stacks a FloatButton above the bottom-anchored Twin chat FAB reservation", () => {
    const unreserve: () => void = reserveTwinChatFabSlot(); // anchored, base 0, height 24 + 56 = 80
    let buttonOffset: number | null = null;
    const unregister: () => void = registerFloatStackItem("bottom right", 20, 40, null, false, (o: number): void => {
      buttonOffset = o;
    });

    // The chat reservation is anchored to the bottom and occupies 0..80, so the button
    // is bumped to 80 + 12 = 92.
    expect(buttonOffset).toBe(92);

    unregister();
    unreserve();
  });

  it("recomputes when an item unregisters", () => {
    const offsets: Record<string, number> = {};
    const u1: () => void = registerFloatStackItem("bottom right", 20, 40, null, false, (o: number): void => {
      offsets.a = o;
    });
    const u2: () => void = registerFloatStackItem("bottom right", 20, 40, null, false, (o: number): void => {
      offsets.b = o;
    });
    const u3: () => void = registerFloatStackItem("bottom right", 20, 40, null, false, (o: number): void => {
      offsets.c = o;
    });

    expect(offsets.c).toBe(124); // 20, 72, 124

    // Remove the middle one → the third should drop down to the second slot.
    u2();
    expect(offsets.c).toBe(72);

    u1();
    u3();
  });
});
