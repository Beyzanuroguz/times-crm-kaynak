export interface CommonProps {
  visibility?: "visible" | "hidden";
  visibilityByAuthorization?: "visible" | "hidden";
  editability?: "enabled" | "disabled";
  rowIndex?: number;
  onClick?: (e: any, rowIndex?: number) => void;
  kuikaRef?: any;
  kDataType?: string;
  showCursorPointer?: boolean;
  className?: string;
  id?: string;
}
