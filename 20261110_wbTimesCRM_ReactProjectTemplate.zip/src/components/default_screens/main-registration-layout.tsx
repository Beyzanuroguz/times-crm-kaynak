import { Layout } from "antd/es";
import newFeaturesContent from "./new-features-content";
import { RegistrationHeader } from "./registration-header";
import welcomeContent from "./welcome-content";

const MainRegistrationLayout = ({ children, content }) => {
  let leftContent: any = "";
  if (content === "newFeatures") {
    leftContent = newFeaturesContent();
  } else if (content === "welcomeContent") {
    leftContent = welcomeContent();
  }
  return (
    <Layout style={{ height: "100vh" }}>
      <Layout style={{ backgroundColor: "#f7f7f7" }}>
        <Layout.Content className="kuika_registrationLayoutContent">
          <Layout.Header style={{ backgroundColor: "#f7f7f7" }}>
            <RegistrationHeader></RegistrationHeader>
          </Layout.Header>
          {leftContent}
        </Layout.Content>
        <div className="kuika_registrationLogoImg">
          <img
            style={{ height: 52, marginTop: 10, float: "left" }}
            className="kuika_loginPageImage"
            alt="kuika"
            src="/imgages/kuikaDesignerLogo.svg"
          ></img>
        </div>
        <Layout.Sider className="kuika_registration_rightSide" style={{ width: "35%" }}>
          {children}
        </Layout.Sider>
      </Layout>
    </Layout>
  );
};

export default MainRegistrationLayout;
