import { Col, Row } from "antd/es";

const welcomeContent = () => {
  return (
    <Row style={{ height: "auto" }}>
      <Col span={24} className="kuika_registration_leftSide">
        <Row>
          <Col xs={24} sm={24} md={24} lg={8} xl={8} xxl={8}>
            <h3 className="kuika_title">
              Welcome to <span> Designer</span>
            </h3>
            <p className="kuika_desc" style={{ maxWidth: 325 }}>
              Design apps using your own or an open source component library with an easy drag and drop interface.
            </p>
          </Col>
          <Col xs={24} sm={24} md={24} lg={16} xl={16} xxl={16} style={{ textAlign: "center" }}>
            <img
              style={{ width: "71%" }}
              className="kuika_loginPageImage"
              alt="kuika"
              src="/images/registrationImg.svg"
            ></img>
          </Col>
        </Row>
        <div style={{ marginTop: 90 }}>
          <div className="kuika_featureCard">
            <div className="kuika_featureImgContainer">
              <svg xmlns="http://www.w3.org/2000/svg" width="132" height="108" viewBox="0 0 132 108">
                <path
                  fill="#1890ff"
                  fillRule="nonzero"
                  d="M60.42 38c-4.722 0-8.564 3.814-8.564 8.5 0 .87.153 1.763.454 2.647.274.808 1.157 1.246 1.973.975.815-.273 1.25-1.149.977-1.959-.195-.576-.29-1.119-.29-1.663 0-2.983 2.446-5.41 5.45-5.41 3.006 0 5.451 2.427 5.451 5.41 0 .544-.094 1.087-.289 1.663-.274.808.163 1.686.98 1.96.164.053.33.078.495.078.651 0 1.259-.408 1.478-1.054.212-.626.32-1.251.383-1.874h7.853v4.636L83 45.727l-6.229-6.182v4.637h-8.117C67.634 40.62 64.333 38 60.42 38zm0 6.182c-1.288 0-2.335 1.038-2.335 2.318v14.923l-4.428-2.227c-.877-.44-1.929-.339-2.7.26-1.181.917-1.283 2.649-.226 3.7l7.543 7.486C59.15 71.51 60.336 72 61.577 72h8.966c2.578 0 4.671-2.077 4.671-4.636v-7.48c0-1.485-1.065-2.765-2.542-3.037L62.757 55v-8.5c0-1.28-1.047-2.318-2.336-2.318z"
                ></path>
              </svg>
            </div>
            <p className="kuika_featureDesc">Any Component. Drag. Drop.</p>
          </div>
          <div className="kuika_featureCard">
            <div className="kuika_featureImgContainer">
              <svg xmlns="http://www.w3.org/2000/svg" width="132" height="108" viewBox="0 0 132 108">
                <path
                  fill="#1890ff"
                  fillRule="nonzero"
                  d="M69.55 36c-.625.003-1.251.239-1.728.706l-9.048 8.86c-.612.6-.956 1.41-.956 2.258v15.978c0 1.767 1.465 3.198 3.273 3.198h14.714c1.308 0 2.49-.761 3.008-1.936l4.922-11.197c.175-.398.265-.828.265-1.261V49.41c0-1.767-1.465-3.198-3.273-3.198H70.334l1.627-7.3c.18-.805-.077-1.645-.678-2.223-.481-.462-1.107-.693-1.732-.69zM49.637 47.812c-.903 0-1.636.716-1.636 1.599V65.4c0 .883.733 1.599 1.636 1.599h3.273c.903 0 1.636-.716 1.636-1.599v-15.99c0-.883-.733-1.6-1.636-1.6h-3.273z"
                />
              </svg>
            </div>
            <p className="kuika_featureDesc">No coding. No mistakes. No unapproved designs.</p>
          </div>
          <div className="kuika_featureCard">
            <div className="kuika_featureImgContainer">
              <svg xmlns="http://www.w3.org/2000/svg" width="132" height="108" viewBox="0 0 132 108">
                <path
                  fill="#1890ff"
                  fillRule="nonzero"
                  d="M52 36c-2.2 0-4 1.753-4 3.895v5.842c0 2.142 1.8 3.895 4 3.895v2.955s0 .94.824.94c.634 0 1.176-.974 1.176-.974l2-2.921h4c2.2 0 4-1.753 4-3.895v-5.842C64 37.753 62.2 36 60 36h-8zm20 0c-2.2 0-4 1.753-4 3.895v5.842c0 2.142 1.8 3.895 4 3.895h4l2 2.92s.542.974 1.176.974c.824 0 .824-.94.824-.94v-2.954c2.2 0 4-1.753 4-3.895v-5.842C84 37.753 82.2 36 80 36h-8zM56 55.474c-2.21 0-4 1.743-4 3.894s1.79 3.895 4 3.895 4-1.744 4-3.895c0-2.15-1.79-3.894-4-3.894zm20 0c-2.21 0-4 1.743-4 3.894s1.79 3.895 4 3.895 4-1.744 4-3.895c0-2.15-1.79-3.894-4-3.894zm-24.004 3.898s-1.882-.103-2.98.966c-.718.697-.92 1.724-.977 2.35-.026.307.237.568.55.54.645-.054 1.697-.255 2.415-.954 1.096-1.069.992-2.902.992-2.902zM56 65.211c-4.37 0-8 1.77-8 4.316v2.5c0 .537.448.973 1 .973h14c.552 0 1-.436 1-.974v-2.499c0-2.547-3.63-4.316-8-4.316zm20 0c-4.37 0-8 1.77-8 4.316v2.5c0 .537.448.973 1 .973h14c.552 0 1-.436 1-.974v-2.499c0-2.547-3.63-4.316-8-4.316z"
                />
              </svg>
            </div>
            <p className="kuika_featureDesc">Collaborate, with history saved.</p>
          </div>
          <div className="kuika_featureCard">
            <div className="kuika_featureImgContainer">
              <svg xmlns="http://www.w3.org/2000/svg" width="132" height="108" viewBox="0 0 132 108">
                <path
                  fill="#1890ff"
                  fillRule="nonzero"
                  d="M48 36c-2.21 0-4 1.79-4 4v24c0 2.21 1.79 4 4 4h10v2c0 1.104.896 2 2 2h12c1.104 0 2-.896 2-2v-2h10c2.21 0 4-1.79 4-4V40c0-2.21-1.79-4-4-4H48zm0 4h36v24H48V40zm6 4c-1.104 0-2 .896-2 2v2c0 1.104.896 2 2 2h8c1.104 0 2-.896 2-2v-2c0-1.104-.896-2-2-2h-8zm16 0c-1.104 0-2 .896-2 2v2c0 1.104.896 2 2 2h8c1.104 0 2-.896 2-2v-2c0-1.104-.896-2-2-2h-8zM54 54c-1.104 0-2 .896-2 2v2c0 1.104.896 2 2 2h8c1.104 0 2-.896 2-2v-2c0-1.104-.896-2-2-2h-8zm16 0c-1.104 0-2 .896-2 2v2c0 1.104.896 2 2 2h8c1.104 0 2-.896 2-2v-2c0-1.104-.896-2-2-2h-8z"
                />
              </svg>
            </div>
            <p className="kuika_featureDesc">All UIs in a single place.</p>
          </div>
        </div>
      </Col>
    </Row>
  );
};

export default welcomeContent;
