import { Menu } from "antd/es";
import React from "react";
import { withHistory } from "../../shared/hoc/with-history";

export interface RegistrationHeaderProps {}

export interface RegistrationHeaderState {}

class RegistrationHeader extends React.PureComponent<RegistrationHeaderProps, RegistrationHeaderState> {
  render() {
    return (
      <>
        <div style={{ marginTop: 36 }}>
          <img
            style={{ height: 52, marginTop: 10, float: "left" }}
            className="kuika_loginPageImage"
            alt="kuika"
            src="/images/kuikaDesignerLogo.svg"
          ></img>
          <Menu
            className="kuika_reg_navBar"
            theme="light"
            mode="horizontal"
            style={{
              backgroundColor: "transparent",
              textAlign: "right",
              display: "none"
            }}
          >
            <Menu.Item>Home</Menu.Item>
            <Menu.Item>Support</Menu.Item>
            <Menu.Item>Contact</Menu.Item>
          </Menu>
        </div>
      </>
    );
  }
}

const registrationHeader = withHistory(RegistrationHeader);
export { registrationHeader as RegistrationHeader };
