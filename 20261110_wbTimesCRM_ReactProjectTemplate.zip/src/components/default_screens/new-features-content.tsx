import { Col, Row } from "antd/es";

const newFeaturesContent = () => {
  return (
    <Row style={{ height: "auto" }}>
      <Col span={24} className="kuika_registration_leftSide">
        <Row>
          <Col xs={24} sm={24} md={24} lg={8} xl={8} xxl={8}>
            <h3 className="kuika_title">
              New Features in <span> Designer</span>
            </h3>
            <p className="kuika_desc" style={{ maxWidth: 264 }}>
              Designing is now euphoric with our even simpler UI and more graceful UX.
            </p>
          </Col>
          <Col xs={24} sm={24} md={24} lg={16} xl={16} xxl={16} style={{ textAlign: "center" }}>
            <img
              style={{ width: "71%" }}
              className="kuika_loginPageImage"
              alt="kuika"
              src="/images/registrationImg.svg"
            ></img>
          </Col>
        </Row>
      </Col>
    </Row>
  );
};

export default newFeaturesContent;
