import { Dashboard } from "./dashboard";
import { ForgotPassword } from "./forgot-password";
import { Login } from "./login";
import { ResetPassword } from "./reset-password";

export { Dashboard, ForgotPassword, Login, ResetPassword };
