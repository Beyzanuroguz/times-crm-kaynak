import * as React from "react";
import { KuikaAppManager } from "../../shared/utilty/kuika-app-manager";

export interface IKuikaInfoState {}

export interface IKuikaInfoProps {}

declare let window: any;

class KuikaInfo extends React.PureComponent<IKuikaInfoProps, IKuikaInfoState> {
  render() {
    const appName = "wbTimesCRM";
    const workspace = "reslen_01";
    const webComponentTag = "reslen-01-wb-times-crm";
    const frontEndUrl = KuikaAppManager.GetFrontEndSourceUrl();
    const backEndUrl = KuikaAppManager.GetBackendUrl(true);
    const kuikaInfoJson = {
      workspace,
      appName,
      frontEndUrl,
      backEndUrl,
      webComponentTag
    };
    var json = JSON.stringify(kuikaInfoJson);
    var blob = new Blob([json], { type: "application/json" });
    var url = URL.createObjectURL(blob);
    window.location = url;
    return <></>;
  }
}

const kuikaInfo = KuikaInfo;
export { kuikaInfo as KuikaInfo };
