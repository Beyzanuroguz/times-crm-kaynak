import "react";

interface ImportMeta {
  webpackHot: {
    readonly accept?: () => void;
  };
}

declare global {
  interface Window {
    kuikaOfflineScreenName?: string;
  }
}

declare module "react" {
  interface HTMLAttributes<T> {
    onPointerEnterCapture?: (e: React.PointerEvent<T>) => void;
    onPointerLeaveCapture?: (e: React.PointerEvent<T>) => void;
  }
  interface RefAttributes<T> {
    onPointerEnterCapture?: (e: React.PointerEvent<T>) => void;
    onPointerLeaveCapture?: (e: React.PointerEvent<T>) => void;
  }
}

// Augment react-router-dom with v5-era APIs still used by sample app code.
// The workspace resolves v6 for hoisting reasons, but this project's package.json
// pins v5.1.2 — at runtime v5 is installed. These declarations keep tsc green.
declare module "react-router-dom" {
  import type { ComponentType, ReactNode } from "react";

  export interface LocationDescriptor {
    pathname?: string;
    search?: string;
    hash?: string;
    state?: unknown;
  }

  export interface RedirectProps {
    to: string | LocationDescriptor;
    push?: boolean;
    from?: string;
    exact?: boolean;
    strict?: boolean;
  }
  export const Redirect: ComponentType<RedirectProps>;

  export interface SwitchProps {
    children?: ReactNode;
    location?: LocationDescriptor;
  }
  export const Switch: ComponentType<SwitchProps>;

  export interface RouteV5RenderProps {
    history: HistoryLike;
    location: LocationDescriptor;
    match: RouteMatchLike;
    staticContext?: unknown;
  }

  export interface RouteMatchLike {
    path: string;
    url: string;
    isExact: boolean;
    params: Record<string, string | undefined>;
  }

  export interface RouteV5Props {
    exact?: boolean;
    path?: string | string[];
    strict?: boolean;
    sensitive?: boolean;
    component?: ComponentType<RouteV5RenderProps>;
    render?: (props: RouteV5RenderProps) => ReactNode;
    children?: ReactNode | ((props: RouteV5RenderProps) => ReactNode);
    location?: LocationDescriptor;
    element?: ReactNode;
  }

  // Shadow v6 Route with a permissive v5-compatible signature so existing
  // sample-app call sites (which predate the v6 upgrade) still type-check.
  export const Route: ComponentType<RouteV5Props>;

  export interface HistoryLike {
    length: number;
    action: string;
    location: LocationDescriptor;
    push: (path: string | LocationDescriptor, state?: unknown) => void;
    replace: (path: string | LocationDescriptor, state?: unknown) => void;
    go: (n: number) => void;
    goBack: () => void;
    goForward: () => void;
    block: (prompt?: boolean | string) => () => void;
    listen: (listener: (location: LocationDescriptor, action: string) => void) => () => void;
  }
  export function useHistory<T extends HistoryLike = HistoryLike>(): T;
}
