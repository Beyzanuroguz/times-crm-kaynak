/// <reference types="react-scripts" />

declare module "@fullcalendar/daygrid" {
  const content: any;
  export default content;
}

declare module "@fullcalendar/timegrid" {
  const content: any;
  export default content;
}

declare module "@fullcalendar/interaction" {
  const content: any;
  export default content;
  export interface DateClickArg {
    date: Date;
    dateStr: string;
    allDay: boolean;
    dayEl: HTMLElement;
    jsEvent: MouseEvent;
    view: any;
  }
}

declare module "@fullcalendar/react" {
  import { Component } from "react";

  export default class FullCalendar extends Component<any> {
    getApi(): any;
  }
}

declare module "@fullcalendar/core/locales-all" {
  const content: any;
  export default content;
}

declare module "@fullcalendar/core" {
  export interface DateRangeInput {
    start?: Date | string;
    end?: Date | string;
  }
  export interface EventClickArg {
    event: {
      id: string;
      title: string;
      extendedProps: any;
    };
  }
  export interface EventSourceInput {}
}
