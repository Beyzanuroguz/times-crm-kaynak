import { Input } from "antd/es";
import { TextAreaRef } from "antd/es/input/TextArea";
import { CSSProperties, Component, KeyboardEvent, createRef } from "react";
import { FrameMessageSender } from "../../components/web-components/kuika-cl-model-runtimes";
import { WritingModeStyles, getWritingModeStyles } from "../utilty/writing-mode-styles";

declare let window: any;

interface TextBoxSize {
  width: number;
  height: number;
}

// Styles the edit input needs when the text flows vertically: the box is sized here rather than by
// antd's `autoSize`, so the browser must not add a scrollbar or a resize handle on top of it.
// `transition: none` is load-bearing — antd's `.ant-input` transitions `all`, and a vertical input is
// born as wide as its column before being sized down to one line's thickness, so the size correction
// would play out as a ~300ms slide on every edit, and every later keystroke would animate too.
const VERTICAL_INPUT_STYLES: CSSProperties = {
  resize: "none",
  overflow: "hidden",
  transition: "none"
};

// Computed styles that decide how much room a piece of text needs. `writing-mode` is the one that
// antd's own measurement drops, which is why the box has to be measured here instead.
const TEXT_SIZING_STYLE_NAMES: string[] = [
  "font-family",
  "font-size",
  "font-weight",
  "font-style",
  "font-variant",
  "line-height",
  "letter-spacing",
  "text-transform",
  "text-indent",
  "writing-mode",
  "text-orientation",
  "box-sizing",
  "padding-top",
  "padding-right",
  "padding-bottom",
  "padding-left",
  "border-top-width",
  "border-right-width",
  "border-bottom-width",
  "border-left-width"
];

let verticalTextSizer: HTMLSpanElement | null = null;

/**
 * Measures the box a textarea needs for vertically flowing text. A textarea has no intrinsic size
 * that follows its value — that is why antd ships `autoSize` — but `autoSize` measures a clone whose
 * writing mode is horizontal, so in a vertical flow it reports the wrong axis and the text ends up
 * clipped. One reused off-screen mirror keeps the writing mode and therefore measures both axes.
 */
const measureVerticalText = (textArea: HTMLTextAreaElement): TextBoxSize => {
  if (!verticalTextSizer) {
    verticalTextSizer = document.createElement("span");
    verticalTextSizer.setAttribute("aria-hidden", "true");
    document.body.appendChild(verticalTextSizer);
  }

  const computed: CSSStyleDeclaration = window.getComputedStyle(textArea);
  const copiedStyles: string = TEXT_SIZING_STYLE_NAMES.map(
    (name: string): string => `${name}:${computed.getPropertyValue(name)}`
  ).join(";");
  verticalTextSizer.setAttribute(
    "style",
    `${copiedStyles};position:absolute;top:-9999px;left:-9999px;visibility:hidden;white-space:pre`
  );
  // The trailing space leaves room for the caret past the last character, and keeps an empty value
  // from collapsing to a box that cannot be clicked into.
  verticalTextSizer.textContent = `${textArea.value} `;

  return { width: verticalTextSizer.offsetWidth, height: verticalTextSizer.offsetHeight };
};

const withDoubleClickEdit = <P, S>(WrappedComponent, propertyName: string) => {
  interface IDoubleClickEditElementState {
    isEditEnabled: boolean;
  }

  // Base input styles - defined once outside the class
  const BASE_INPUT_STYLES: CSSProperties = {
    lineHeight: "unset",
    overflowWrap: "normal"
  };

  class DoubleClickEditElement<P, S> extends Component<P, IDoubleClickEditElementState> {
    editInput = createRef<TextAreaRef>();

    designer: FrameMessageSender;

    // Cache for input styles
    private cachedInputStyles: CSSProperties | null = null;
    private lastStyleRef: any = null;
    private lastWritingMode: string | undefined = undefined;

    constructor(props: any) {
      super(props);
      this.designer = new FrameMessageSender();

      this.state = {
        isEditEnabled: false
      };
    }

    getInputStyles = (): CSSProperties => {
      const style = (this.props as any).style;
      // Text orientation lives on a `writingMode` PROPERTY, not in `style`, so it has to be merged in
      // explicitly — otherwise a vertical Label would flip back to horizontal the moment it is edited.
      // Only the writing-mode based styles are applied: `rotationStyles` would rotate the whole input
      // box, not just its text (see writing-mode-styles.ts).
      const writingMode: string | undefined = (this.props as any).writingMode;

      // Return cached styles if the inputs haven't changed
      if (this.cachedInputStyles && this.lastStyleRef === style && this.lastWritingMode === writingMode) {
        return this.cachedInputStyles;
      }

      this.lastStyleRef = style;
      this.lastWritingMode = writingMode;

      const writingModeStyles: WritingModeStyles = getWritingModeStyles(writingMode);
      this.cachedInputStyles = {
        ...BASE_INPUT_STYLES,
        ...style,
        ...writingModeStyles.flowStyles,
        ...(writingModeStyles.isFlowVertical ? VERTICAL_INPUT_STYLES : {})
      };

      return this.cachedInputStyles;
    };

    private get isFlowVertical(): boolean {
      return getWritingModeStyles((this.props as any).writingMode).isFlowVertical;
    }

    /** Keeps the edit box the size of the text it holds. Only needed in a vertical flow, where
     *  antd's `autoSize` is off because it measures the wrong axis. */
    syncVerticalEditSize = (): void => {
      const textArea: HTMLTextAreaElement | undefined = this.editInput.current?.resizableTextArea?.textArea;
      if (!textArea) return;

      const size: TextBoxSize = measureVerticalText(textArea);
      textArea.style.width = `${size.width}px`;
      textArea.style.height = `${size.height}px`;
    };

    handleElementDoubleClick = (e) => {
      if (e?.detail !== 2) return;

      this.setState({ isEditEnabled: true }, () => {
        this.editInput.current.focus();
        this.editInput.current.resizableTextArea.textArea.select();
        if (this.isFlowVertical) {
          this.syncVerticalEditSize();
        }
      });
    };

    handleInputOnBlur = (shouldSave: boolean = true) => {
      if (shouldSave) {
        this.designer.propertyChangedMessage({
          kuikaId: (this.props as any).kuikaid,
          propertyName,
          value: this.editInput.current.resizableTextArea.textArea.value,
          shouldClosePropertyExpand: true
        });
      }
      this.setState({ isEditEnabled: false });
    };

    handleInputOnKeyDown = (e: KeyboardEvent<HTMLTextAreaElement>) => {
      switch (e.key) {
        case "Enter": {
          e.preventDefault();
          this.editInput.current.blur();
          break;
        }
        case "Escape": {
          this.handleInputOnBlur(false);
          break;
        }
      }
    };

    render() {
      const props = this.props as any;

      if (!window.kuika?.isDesignTime) return <WrappedComponent<P & S> {...(this.props as P)} />;

      if (this.state.isEditEnabled) {
        const isFlowVertical: boolean = this.isFlowVertical;
        return (
          <Input.TextArea
            defaultValue={props[propertyName]}
            ref={this.editInput}
            onKeyDown={this.handleInputOnKeyDown}
            onChange={isFlowVertical ? this.syncVerticalEditSize : undefined}
            onBlur={(e) => this.handleInputOnBlur(e.target.value !== props[propertyName])}
            bordered={false}
            style={this.getInputStyles()}
            autoSize={!isFlowVertical}
            draggable={false}
          />
        );
      }

      return <WrappedComponent<P & S> {...(this.props as P)} onClick={this.handleElementDoubleClick} />;
    }
  }

  return DoubleClickEditElement;
};

export default withDoubleClickEdit;
