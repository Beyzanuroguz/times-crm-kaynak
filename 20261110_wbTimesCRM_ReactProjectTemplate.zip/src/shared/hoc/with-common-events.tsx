import { Component } from "react";
import { CommonProps } from "../../components/web-components/common/common-props";
import {
  ConditionalStylePredicate,
  joinClassNames,
  matchedConditionalStyleClasses,
  NO_ROW
} from "../utilty/conditional-style-classes";

/**
 * KOA-9069 conditional styling. Both props are injected by the code generator or by
 * `TableData`; neither is something a screen author sets.
 */
interface ConditionalStyleProps {
  className?: string;
  /** Set by `TableData` on every child it renders, so a cell is never matched twice. */
  isTableData?: boolean;
  conditionalStyleConditions?: ConditionalStylePredicate[];
}

const withCommonEvents = <P, S>(WrappedComponent) => {
  class CommonEventComponent<P, S> extends Component<P & CommonProps, S> {
    // Cache for disabled style to avoid creating new objects on every render
    private cachedDisabledStyle: any = null;
    private lastStyleRef: any = null;

    constructor(props: any) {
      super(props);
    }

    handleClick = (e: any) => {
      if (this.props.onClick && typeof this.props.onClick === "function") {
        this.props.onClick(e, this.props.rowIndex);
      }
    };

    // Get or create disabled style (memoized)
    private getDisabledStyle = (originalStyle: any): any => {
      // Return cached style if the original style reference hasn't changed
      if (this.cachedDisabledStyle && this.lastStyleRef === originalStyle) {
        return this.cachedDisabledStyle;
      }

      this.lastStyleRef = originalStyle;
      this.cachedDisabledStyle = {
        ...originalStyle,
        pointerEvents: "none",
        opacity: 0.7
      };

      return this.cachedDisabledStyle;
    };

    /**
     * KOA-9069 (QA round 3): a component INSIDE a table gets its `kuika-cond-{i}` classes from
     * `TableData`, which evaluates each predicate against the row it is rendering. Nothing did
     * that for a component outside a table — its conditional styles were emitted as CSS and as
     * predicates and then never applied, so the base style simply won and the panel offered a
     * feature that silently did nothing on every non-table component.
     *
     * Hover and the other states kept working throughout, because those are plain CSS
     * pseudo-classes that need no runtime; only the conditional class needs someone to add it.
     *
     * Recomputed per render rather than cached: a predicate closes over the screen component's
     * state, so the answer changes exactly when that state does — which is also when the new
     * predicate array arrives and this component re-renders.
     */
    private conditionalStyleClassName = (): string | undefined => {
      const props = this.props as P & CommonProps & ConditionalStyleProps;

      // TableData already appended the matched classes for this cell.
      if (props.isTableData === true) {
        return props.className;
      }

      const conditions: ConditionalStylePredicate[] | undefined = props.conditionalStyleConditions;
      if (!Array.isArray(conditions) || conditions.length === 0) {
        return props.className;
      }

      const matched: string[] = matchedConditionalStyleClasses(conditions, NO_ROW);
      if (matched.length === 0) {
        return props.className;
      }

      return joinClassNames(props.className, ...matched);
    };

    render() {
      if (this.props.visibility === "hidden") {
        return <></>;
      }

      const isDisabled = this.props.editability === "disabled";
      const originalStyle = (this.props as any).style;

      // Only compute disabled style if needed and style exists
      const style = isDisabled && originalStyle ? this.getDisabledStyle(originalStyle) : originalStyle;

      const { kuikaTabOrder, ...rest } = this.props as P & CommonProps;

      // After the spread, so the conditional classes land on the resolved className rather
      // than being overwritten by it. Passed only when there is a value: an explicit
      // `className={undefined}` still creates the key on the wrapped component's props, and a
      // component that writes its own class first and spreads its props after it (SiderMenu)
      // would have that class replaced by `undefined`. Without a value the spread above already
      // carries whatever the caller passed.
      const className: string | undefined = this.conditionalStyleClassName();
      const classNameProps: ConditionalStyleProps = className === undefined ? {} : { className };

      const element = (
        <WrappedComponent<P & CommonProps, S>
          {...(rest as P)}
          {...classNameProps}
          style={style}
          onClick={this.handleClick}
          ref={this.props.kuikaRef}
          tabIndex={isDisabled ? -1 : undefined}
          data-disabled={isDisabled || undefined}
        />
      );

      if (kuikaTabOrder === undefined || kuikaTabOrder === null) {
        return element;
      }

      return (
        <div style={{ display: "contents" }} data-kuika-taborder={kuikaTabOrder}>
          {element}
        </div>
      );
    }
  }

  return CommonEventComponent;
};

export default withCommonEvents;
