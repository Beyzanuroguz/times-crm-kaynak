import { CodeResponse, useGoogleLogin } from "@react-oauth/google";
import { useCallback, useMemo } from "react";
import { useHistory } from "react-router-dom";
import { EExternalTokenProviderTypes } from "../../models/dto/login.dto";
import { UserService } from "../../services/user-service";
import { KuikaAppManager } from "../utilty/kuika-app-manager";
import { KMainFunctions } from "../utilty/main-functions";
import { KNavigator } from "./with-history";

const backendUrl = KuikaAppManager.GetBackendUrl();

export const withGoogleLogin = <T extends {} = any>(Component: any) => {
  return (props: any) => {
    const history: any = useHistory();
    // Memoize navigator to avoid creating new instance on every render
    const navigator = useMemo(() => new KNavigator(history), [history]);

    // Memoize callbacks to avoid recreating on every render
    const onSuccess = useCallback(async (response: CodeResponse) => {
      const authWithGoogleResponse = await UserService.AuthenticateWithGoogle(response.code);

      if (authWithGoogleResponse.status !== 200) {
        console.error(authWithGoogleResponse);
        return;
      }

      const jwt = authWithGoogleResponse.data.id_token;
      const userInfo = JSON.parse(atob(jwt.split(".")[1]));
      try {
        await UserService.LoginWithExternalToken({
          providerType: EExternalTokenProviderTypes.Google,
          username: userInfo.email,
          tokenString: jwt,
          refreshToken: null,
          redirectUri: location.origin
        });
      } catch (error) {
        KMainFunctions.exceptionHandler(error);
      }

      localStorage.setItem("isGoogleLoginInProgress", "false");
    }, []);

    const onError = useCallback(() => {
      localStorage.setItem("isGoogleLoginInProgress", "false");
      localStorage.setItem("isGoogleLoginAborted", "true");
    }, []);

    const onNonOAuthError = useCallback((nonOAuthError: { type: string }) => {
      if (nonOAuthError.type === "popup_closed") {
        localStorage.setItem("isGoogleLoginInProgress", "false");
        localStorage.setItem("isGoogleLoginAborted", "true");
      }
    }, []);

    const googleLogin = useGoogleLogin({
      flow: "auth-code",
      onSuccess,
      onError,
      onNonOAuthError
    });

    return <Component {...props} googleLogin={googleLogin} />;
  };
};
