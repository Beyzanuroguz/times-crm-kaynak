import { Form } from "antd/es";
import { useContext } from "react";
import { MasterFormContext } from "../../routes/master-screen-wrapper";

export const withForm = <T extends {} = any>(Component: any) => {
  return (props: any) => {
    const [localForm] = Form.useForm<T>();
    // KOA-18186: parentForm is the enclosing master chrome's form (null outside a
    // master's child scope). handleValidations uses it to clear the master's stale
    // validation errors when this screen's own validation run passes.
    const { form: masterForm, parentForm } = useContext(MasterFormContext);
    const form = masterForm ?? localForm;
    return <Component {...props} form={form} parentForm={parentForm ?? null} />;
  };
};
