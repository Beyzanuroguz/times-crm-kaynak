import * as QueryStringify from "querystringify";
import { useMemo } from "react";
import { ScreenInputHelper } from "../utilty/screen-input-helper";

export const withScreenInput = (Component: any) => {
  return (props: any) => {
    // Memoize screenInputs computation to avoid recreating on every render
    const screenInputs = useMemo(() => {
      const screenInputsByQueryString: Record<string, any> = {};
      let screenInputsByProp: Record<string, any> = {};
      let screenInputsByState: Record<string, any> = {};

      if (props?.location?.search) {
        const obj = QueryStringify.parse(props.location.search);
        const screenName = /[^/]*$/.exec(props.location.pathname)![0];
        for (const key in obj) {
          // Security: prevent prototype pollution from query string keys
          if (key === "__proto__" || key === "constructor" || key === "prototype") continue;
          screenInputsByQueryString[key] = ScreenInputHelper.getScreenInputValue(screenName, key, obj[key]);
        }
      }
      if (props?.screenInputs) {
        screenInputsByProp = props.screenInputs;
      }
      if (props?.location?.state?.screenInputs) {
        screenInputsByState = props.location.state.screenInputs;
      }

      return { ...screenInputsByProp, ...screenInputsByQueryString, ...screenInputsByState };
    }, [props?.location?.search, props?.location?.pathname, props?.location?.state?.screenInputs, props?.screenInputs]);

    return <Component {...props} screenInputs={screenInputs} />;
  };
};
