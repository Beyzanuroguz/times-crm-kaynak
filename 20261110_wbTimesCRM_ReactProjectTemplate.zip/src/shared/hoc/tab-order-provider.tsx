import { Component, ReactNode, RefObject, createRef } from "react";
import { TabOrderContext, collectTabOrderContext, computeNextTabTarget } from "../utilty/tab-order";

interface IKuikaTabOrderProviderProps {
  children?: ReactNode;
}

/**
 * Drives author-defined form tab order (KOA-14072).
 *
 * Each form field with a designer Tab order is wrapped by `withCommonEvents` in a
 * `display:contents` element carrying `data-kuika-taborder`. This provider is
 * rendered once per screen (wrapping the screen's Form) and moves focus through
 * those fields in ascending author order on Tab / Shift+Tab.
 *
 * The keydown listener is attached at the **document** level, not on the wrapper
 * div. That is required so the *first* Tab on a freshly loaded page — when focus is
 * still on document.body, outside the provider's subtree — is intercepted and sent
 * to the lowest-order field, instead of the browser landing on the DOM-first field.
 * A div-scoped listener never sees that body-originated keydown.
 *
 * `computeNextTabTarget` decides everything from the document-wide, scope-grouped
 * field collection: entering the group (focus outside it) → lowest/highest order;
 * within the group → next/previous by author order; at the ends → release to the
 * browser default so focus is never trapped or thrown to the browser chrome. It
 * returns null when the move is not ours, so we only `preventDefault` where the
 * reorder actually matters.
 *
 * Providers nest (master + child). Every provider attaches a document listener and
 * computes the same global result; `defaultPrevented` makes the first one act and
 * the rest bail, so there is no double handling.
 */
export class KuikaTabOrderProvider extends Component<IKuikaTabOrderProviderProps> {
  private readonly containerRef: RefObject<HTMLDivElement> = createRef<HTMLDivElement>();

  componentDidMount(): void {
    document.addEventListener("keydown", this.handleKeyDown);
  }

  componentWillUnmount(): void {
    document.removeEventListener("keydown", this.handleKeyDown);
  }

  private handleKeyDown = (event: KeyboardEvent): void => {
    if (event.key !== "Tab" || event.defaultPrevented) return;
    const container: HTMLDivElement | null = this.containerRef.current;
    if (container === null) return;

    const context: TabOrderContext = collectTabOrderContext(container);
    const target: HTMLElement | null = computeNextTabTarget(
      context.managedByScope,
      context.domFocusables,
      document.activeElement,
      event.shiftKey
    );
    if (target === null) return;

    event.preventDefault();
    target.focus();
  };

  render(): ReactNode {
    // data-kuika-taborder-scope marks this provider's root; groupManagedByScope
    // uses it (via TAB_ORDER_SCOPE_ATTR) to keep each screen's order independent.
    return (
      <div style={{ display: "contents" }} ref={this.containerRef} data-kuika-taborder-scope="">
        {this.props.children}
      </div>
    );
  }
}

export default KuikaTabOrderProvider;
