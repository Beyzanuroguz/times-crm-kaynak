import { useContext } from "react";
import { InlineOverlayNavContext } from "../../routes/master-screen-wrapper";

// KOA-8559: injects the current inline-overlay navigation handle as `inlineOverlayNav`.
// It is non-null only when the screen is rendered inside an inline overlay wrapper
// (drawer/modal/floatingPanel) that published InlineOverlayNavContext — i.e. the
// overlay's own master menu and child screen. Everywhere else (router-level screens,
// or the page behind a maskless FloatPanel) it reads the default null, so a
// NAVIGATE with openAs="currentOverlay" fired from there degrades to a currentPage
// navigate. `ReactSystemFunctions.navigate` reads it from `screen.props.inlineOverlayNav`.
export const withInlineOverlayNav = (Component: any) => {
  return (props: any) => {
    const inlineOverlayNav = useContext(InlineOverlayNavContext);
    return <Component {...props} inlineOverlayNav={inlineOverlayNav} />;
  };
};
