/**
 * Guards for URLs and identifiers that flow into script.src / asset paths.
 *
 * The MFE/widget loaders legitimately load scripts cross-origin (a micro-app is
 * served from its own frontend origin), so a flat host-origin allowlist is wrong.
 * Instead we enforce the invariant that each script must come from the SAME origin
 * as the manifest it was declared in (expectedOrigin), while intentionally-external
 * third-party scripts must at least be https. This blocks javascript:/data: URLs and
 * origin-hijacking via a tampered manifest entry without breaking real micro-apps.
 */

const SAFE_ASSET_ID: RegExp = /^[A-Za-z0-9_.-]+$/;

export interface ScriptUrlPolicy {
  /** Main assets: the resolved script origin must equal this origin. */
  expectedOrigin?: string;
  /** url_3rd_js: cross-origin allowed, but https-only (localhost http tolerated for dev). */
  allowThirdParty?: boolean;
}

function toUrl(src: string): URL {
  return new URL(src, window.location.origin);
}

function isHttp(url: URL): boolean {
  return url.protocol === "http:" || url.protocol === "https:";
}

/**
 * Returns true when `src` is safe to assign to script.src under the given policy.
 */
export function isTrustedScriptUrl(src: string, policy: ScriptUrlPolicy = {}): boolean {
  let url: URL;
  try {
    url = toUrl(src);
  } catch {
    return false;
  }

  if (!isHttp(url)) {
    return false;
  }

  if (policy.expectedOrigin) {
    let expected: string;
    try {
      expected = toUrl(policy.expectedOrigin).origin;
    } catch {
      return false;
    }
    return url.origin === expected;
  }

  if (policy.allowThirdParty) {
    if (url.protocol === "https:") {
      return true;
    }
    return url.hostname === "localhost" || url.hostname === "127.0.0.1";
  }

  return url.origin === window.location.origin;
}

/**
 * Throwing variant of {@link isTrustedScriptUrl} for call sites that treat an
 * untrusted URL as a hard failure.
 */
export function assertTrustedScriptUrl(src: string, policy: ScriptUrlPolicy = {}): void {
  if (!isTrustedScriptUrl(src, policy)) {
    throw new Error(`Refusing to load script from untrusted URL: ${src}`);
  }
}

/**
 * Validates that an identifier used to build an asset path (packId, projectId,
 * componentId) is a plain token and cannot inject path/URL structure.
 */
export function assertSafeAssetId(id: string, label: string): void {
  if (typeof id !== "string" || id.length === 0 || id.includes("..") || !SAFE_ASSET_ID.test(id)) {
    throw new Error(`Invalid ${label}: ${id}`);
  }
}
