const screenInputData = {
  CustomerChangeLog: [{"name":"CustomerId","type":"Guid","cardinality":1,"isExpandedPanel":null}],
	ContactSourceEdit: [{"name":"id","type":"Guid","cardinality":1,"isExpandedPanel":null}],
	NextStepEdit: [{"name":"id","type":"Guid","cardinality":1,"isExpandedPanel":null}],
	UserProfile: [{"name":"UserID","type":"Guid","cardinality":1,"isExpandedPanel":null}],
	MonthlyAllocationcopy: [{"name":"Year","type":"String","cardinality":1,"isExpandedPanel":null}],
	LeadDetailAddNote: [{"name":"LeadId","type":"Guid","cardinality":1,"isExpandedPanel":null},{"name":"LeadCode","type":"String","cardinality":1,"isExpandedPanel":null}],
	LeadAddByExcelcopy: [{"name":"KuserId","type":"Guid","cardinality":1,"isExpandedPanel":null}],
	LeadDetailSalesPerson: [{"name":"LeadId","type":"Guid","cardinality":1,"isExpandedPanel":null}],
	LeadRejectPopUp: [{"name":"LeadId","type":"Guid","cardinality":1,"isExpandedPanel":null}],
	LeadRejectCustomerPopUp: [{"name":"LeadId","type":"Guid","cardinality":1,"isExpandedPanel":null}],
	DistributionDetail: [{"name":"DistributionCode","type":"String","cardinality":1,"isExpandedPanel":null},{"name":"HeaderId","type":"Guid","cardinality":1,"isExpandedPanel":null},{"name":"StatusName","type":"String","cardinality":1,"isExpandedPanel":null}],
	UserRoles: [{"name":"RoleName","type":"String","cardinality":1,"isExpandedPanel":null}],
	DistributionDetailStore: [{"name":"HeaderId","type":"Guid","cardinality":1,"isExpandedPanel":null},{"name":"StoreCode","type":"String","cardinality":1,"isExpandedPanel":null},{"name":"DistributionCode","type":"String","cardinality":1,"isExpandedPanel":null}],
	CreateTransferReceipt: [{"name":"FromWarehouseCode","type":"String","cardinality":1,"isExpandedPanel":null},{"name":"ToWarehouseCode","type":"String","cardinality":1,"isExpandedPanel":null}],
	ReservationReject: [{"name":"ReservationId","type":"Guid","cardinality":1,"isExpandedPanel":null}],
	ReservationPopUp: [{"name":"StoreCode","type":"String","cardinality":1,"isExpandedPanel":null},{"name":"ProductCode","type":"String","cardinality":1,"isExpandedPanel":null},{"name":"LeadId","type":"Guid","cardinality":1,"isExpandedPanel":null}],
	InComingTransferDetail: [{"name":"TransferCode","type":"String","cardinality":1,"isExpandedPanel":null}],
	LeadAddByExcelAI: [{"name":"KUserId","type":"Guid","cardinality":1,"isExpandedPanel":null}],
	ReservationEdit: [{"name":"LeadId","type":"Guid","cardinality":1,"isExpandedPanel":null}],
	CustomerDetailInfo: [{"name":"customerCode","type":"String","cardinality":1,"isExpandedPanel":null},{"name":"CustomerId","type":"Guid","cardinality":1,"isExpandedPanel":null}],
	TransferFisiHazirlama: [{"name":"TransferRequestLineId","type":"Guid","cardinality":1,"isExpandedPanel":null}],
	LeadFileDetail: [{"name":"LeadCode","type":"String","cardinality":1,"isExpandedPanel":null},{"name":"LeadId","type":"Guid","cardinality":1,"isExpandedPanel":null}],
	RoleManagement: [{"name":"UserID","type":"Guid","cardinality":1,"isExpandedPanel":null}],
	AlternativeInfo: [{"name":"ProductId","type":"Guid","cardinality":1,"isExpandedPanel":null},{"name":"KUserId","type":"Guid","cardinality":1,"isExpandedPanel":null}],
	UserEdit: [{"name":"UserID","type":"Guid","cardinality":1,"isExpandedPanel":null}],
	ReferanceCreatePost: [{"name":"CustomerId","type":"Guid","cardinality":1,"isExpandedPanel":null}],
	CustomerDetailPage: [{"name":"customerCode","type":"String","cardinality":1,"isExpandedPanel":null},{"name":"CustomerId","type":"Guid","cardinality":1,"isExpandedPanel":null}],
	KasaRaporuDokumForm: [{"name":"Date","type":"DateTimeOffset","cardinality":1,"isExpandedPanel":null},{"name":"CompanyCode","type":"String","cardinality":1,"isExpandedPanel":null},{"name":"OfficeCode","type":"String","cardinality":1,"isExpandedPanel":null}],
	ProductDistribution: [{"name":"ProductCode","type":"String","cardinality":1,"isExpandedPanel":null},{"name":"HeaderId","type":"Guid","cardinality":1,"isExpandedPanel":null}],
	PopOnayBekleyen: [{"name":"LeadId","type":"Guid","cardinality":1,"isExpandedPanel":null}],
	LeadDetailTemp: [{"name":"LeadId","type":"Guid","cardinality":1,"isExpandedPanel":null}],
	AllLeadPendingDetail: [{"name":"LeadId","type":"Guid","cardinality":1,"isExpandedPanel":null}],
	LeadSatisBasariliPop: [{"name":"LeadSalesDraftId","type":"Guid","cardinality":1,"isExpandedPanel":null}],
	TerminPendingLead: [{"name":"LeadId","type":"Guid","cardinality":1,"isExpandedPanel":null}],
	LeadAdd: [{"name":"CustomerId","type":"Guid","cardinality":1,"isExpandedPanel":null}],
	TalepSatisIslemi: [{"name":"LeadId","type":"Guid","cardinality":1,"isExpandedPanel":null},{"name":"ApprovalId","type":"Guid","cardinality":1,"isExpandedPanel":null},{"name":"SalesLeadDraftId","type":"Guid","cardinality":1,"isExpandedPanel":null}],
	LeadAddTemp: [{"name":"CustomerId","type":"Guid","cardinality":1,"isExpandedPanel":null}],
	SatisBasariliPop: [{"name":"SaleDraftId","type":"Guid","cardinality":1,"isExpandedPanel":null}],
	CustomerUpdatePost: [{"name":"CustomerId","type":"Guid","cardinality":1,"isExpandedPanel":null}],
	UcuncuKisiFaturaOnayDetayi: [{"name":"ApprovalId","type":"Guid","cardinality":1,"isExpandedPanel":null}],
	LeadAlternativeModelAdd: [{"name":"LeadCode","type":"String","cardinality":1,"isExpandedPanel":null},{"name":"LeadId","type":"Guid","cardinality":1,"isExpandedPanel":null}],
	AnnualPortfolioCreationStep1copycopy: [{"name":"Year","type":"String","cardinality":1,"isExpandedPanel":null}],
	TransferFisiDetayi: [{"name":"TransferERPHeaderId","type":"Guid","cardinality":1,"isExpandedPanel":null}],
	PopTerminOnerisiBekleyen: [{"name":"LeadId","type":"Guid","cardinality":1,"isExpandedPanel":null}],
	reservationPopup1: [{"name":"LeadId","type":"Guid","cardinality":1,"isExpandedPanel":null}],
	ApproveLead: [{"name":"LeadId","type":"Guid","cardinality":1,"isExpandedPanel":null}],
	SalesWeb: [{"name":"LeadId","type":"Guid","cardinality":1,"isExpandedPanel":null}],
	reservationPopUp2: [{"name":"LeadId","type":"Guid","cardinality":1,"isExpandedPanel":null}],
	TransferFisKabul: [{"name":"TransferERPHeaderId","type":"Guid","cardinality":1,"isExpandedPanel":null}],
	MusteriOnayPop: [{"name":"CustomerId","type":"Guid","cardinality":1,"isExpandedPanel":null}],
	StockListDetail: [{"name":"ProductCode","type":"String","cardinality":1,"isExpandedPanel":null},{"name":"StoreCode","type":"String","cardinality":1,"isExpandedPanel":null}],
	YearlyAllocationcopy: [{"name":"Year","type":"String","cardinality":1,"isExpandedPanel":null}],
	TransferTalepDetay: [{"name":"TransferRequestHeaderId","type":"Guid","cardinality":1,"isExpandedPanel":null}],
	DistributionPool: [{"name":"ImportHeaderId","type":"Guid","cardinality":1,"isExpandedPanel":null}],
	LeadUpdate: [{"name":"LeadId","type":"Guid","cardinality":1,"isExpandedPanel":null},{"name":"ProductId","type":"Guid","cardinality":1,"isExpandedPanel":null}],
	PopRezervOnayBekleyenPopup: [{"name":"LeadId","type":"Guid","cardinality":1,"isExpandedPanel":null}],
	SatisIslemi: [{"name":"ApprovalId","type":"Guid","cardinality":1,"isExpandedPanel":null},{"name":"SalesDraftId","type":"Guid","cardinality":1,"isExpandedPanel":null}],
	LeadDetail: [{"name":"LeadId","type":"Guid","cardinality":1,"isExpandedPanel":null}],
	ImportListDetail: [{"name":"ImportHeaderId","type":"Guid","cardinality":1,"isExpandedPanel":null}],
	TalepDuzenlemeEkrani: [{"name":"LeadId","type":"Guid","cardinality":1,"isExpandedPanel":null},{"name":"ProductId","type":"Guid","cardinality":1,"isExpandedPanel":null}],
	LeadAddChangeProduct: [{"name":"LeadId","type":"Guid","cardinality":1,"isExpandedPanel":null},{"name":"ProductId","type":"Guid","cardinality":1,"isExpandedPanel":null}],
	LeadProductChange: [{"name":"LeadCode","type":"String","cardinality":1,"isExpandedPanel":null},{"name":"LeadId","type":"Guid","cardinality":1,"isExpandedPanel":null}],
	AllLeadPendingTerminDegis: [{"name":"LeadId","type":"Guid","cardinality":1,"isExpandedPanel":null}],
	reservationPopUp3: [{"name":"LeadId","type":"Guid","cardinality":1,"isExpandedPanel":null}],
	StockListStore: [{"name":"StoreCode","type":"String","cardinality":1,"isExpandedPanel":null},{"name":"StoreName","type":"String","cardinality":1,"isExpandedPanel":null}],
	TalebeAlternatifUrunEkle: [{"name":"LeadCode","type":"String","cardinality":1,"isExpandedPanel":null},{"name":"LeadId","type":"Guid","cardinality":1,"isExpandedPanel":null}]
};

export class ScreenInputHelper {
  public static getScreenInputValue(screenName: string, inputName: string, value: string): any {
    switch (this.getScreenInputType(screenName, inputName)) {
      case "String":
        return value;
      case "Boolean":
        return value.toLowerCase() === "true";
      // TODO
    }

    return value;
  }

  private static getScreenInputType(screenName: string, inputName: string): string {
    const data = screenInputData[screenName]?.find((x) => x.Name === inputName);
    return data?.TypeName ? data.TypeName : "";
  }
}
