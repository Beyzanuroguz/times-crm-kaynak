import {
  applyImageObjectFit,
  inlineCrossOriginImages,
  LIGATURE_ICON_SELECTOR,
  preparePdfCaptureClone,
  rasterizeLigatureIcons,
  resolveSafeCaptureScale
} from "./pdf-capture";

const DATA_URL: string = "data:image/png;base64,ICON";

interface FillTextCall {
  text: string;
  font: string;
  fillStyle: string;
}

let fillTextCalls: FillTextCall[] = [];

// jsdom ships no 2D canvas backend, so getContext() returns null and toDataURL()
// is a stub. Record what would have been painted instead — the assertions here are
// about which glyph is drawn with which font, not about pixel output.
beforeEach(() => {
  fillTextCalls = [];

  HTMLCanvasElement.prototype.getContext = jest.fn(function (this: HTMLCanvasElement) {
    const ctx = {
      font: "",
      fillStyle: "",
      textBaseline: "",
      textAlign: "",
      scale: jest.fn(),
      fillText: jest.fn((text: string) => {
        fillTextCalls.push({ text, font: ctx.font, fillStyle: ctx.fillStyle });
      })
    };
    return ctx as unknown as CanvasRenderingContext2D;
  }) as unknown as typeof HTMLCanvasElement.prototype.getContext;

  HTMLCanvasElement.prototype.toDataURL = jest.fn((): string => DATA_URL);
});

const buildDocument = (body: string): Document => {
  const doc: Document = document.implementation.createHTMLDocument("clone");
  doc.body.innerHTML = body;
  return doc;
};

interface OptionalObjectUrlApi {
  createObjectURL?: unknown;
  revokeObjectURL?: unknown;
}

interface OptionalImageDecode {
  decode?: unknown;
}

interface ImageElementDecodeStub {
  revokeObjectURL: jest.Mock;
  restore: () => void;
}

const putBack = (target: object, key: string, original: unknown): void => {
  if (original === undefined) {
    Reflect.deleteProperty(target, key);
  } else {
    Reflect.set(target, key, original);
  }
};

// jsdom has neither URL.createObjectURL nor HTMLImageElement.decode. Stand both in so the
// <img>-element fallback decoder (the SVG path) can be exercised; `restore` puts jsdom back
// so the fallback stays unreachable for every other test, exactly as it is in jsdom.
const stubImageElementDecode = (
  naturalWidth: number,
  naturalHeight: number,
  fail: boolean = false
): ImageElementDecodeStub => {
  const urlApi: OptionalObjectUrlApi = URL as unknown as OptionalObjectUrlApi;
  const imagePrototype: OptionalImageDecode = HTMLImageElement.prototype as unknown as OptionalImageDecode;
  const originalCreate: unknown = urlApi.createObjectURL;
  const originalRevoke: unknown = urlApi.revokeObjectURL;
  const originalDecode: unknown = imagePrototype.decode;

  const revokeObjectURL: jest.Mock = jest.fn();
  urlApi.createObjectURL = jest.fn((): string => "blob:svg-fallback");
  urlApi.revokeObjectURL = revokeObjectURL;
  imagePrototype.decode = jest.fn(async function (this: HTMLImageElement): Promise<void> {
    if (fail) {
      throw new DOMException("The source image cannot be decoded.", "EncodingError");
    }
    Object.defineProperty(this, "naturalWidth", { value: naturalWidth, configurable: true });
    Object.defineProperty(this, "naturalHeight", { value: naturalHeight, configurable: true });
  });

  const restore = (): void => {
    putBack(URL, "createObjectURL", originalCreate);
    putBack(URL, "revokeObjectURL", originalRevoke);
    putBack(HTMLImageElement.prototype, "decode", originalDecode);
  };
  return { revokeObjectURL, restore };
};

describe("pdf-capture — ligature icons", () => {
  it("replaces a Material ligature icon with a rasterised image and clears the ligature text", () => {
    const doc: Document = buildDocument('<i class="material-icons" style="font-size:48px">home</i>');

    const count: number = rasterizeLigatureIcons(doc);

    const icon: HTMLElement | null = doc.querySelector("i.material-icons");
    const img: HTMLImageElement | null = doc.querySelector("i.material-icons img");
    expect(count).toBe(1);
    expect(icon).not.toBeNull();
    expect(img).not.toBeNull();
    expect(img?.getAttribute("src")).toBe(DATA_URL);
    // The ligature name must be gone, otherwise html2canvas paints it as text.
    expect(icon?.textContent).toBe("");
    expect(fillTextCalls[0].text).toBe("home");
  });

  it("derives the icon font from the class, not from the computed style", () => {
    // The whole defect is that the icon font may fail to resolve at paint time. The
    // rasteriser must not depend on the cloned document resolving the stylesheet, so
    // the family comes from the variant class even when the computed font is a fallback.
    const doc: Document = buildDocument(
      '<i class="material-icons-outlined" style="font-family:Arial;font-size:24px">settings</i>'
    );

    rasterizeLigatureIcons(doc);

    expect(fillTextCalls[0].font).toContain("Material Icons Outlined");
    expect(fillTextCalls[0].font).not.toContain("Arial");
  });

  it("covers every Material variant class", () => {
    const doc: Document = buildDocument(
      [
        '<i class="material-icons">home</i>',
        '<i class="material-icons-outlined">home</i>',
        '<i class="material-icons-round">home</i>',
        '<i class="material-icons-sharp">home</i>',
        '<i class="material-icons-two-tone">home</i>'
      ].join("")
    );

    expect(rasterizeLigatureIcons(doc)).toBe(5);
    expect(fillTextCalls.map((c: FillTextCall): string => c.font.replace(/^\d+px /, ""))).toEqual([
      '"Material Icons"',
      '"Material Icons Outlined"',
      '"Material Icons Round"',
      '"Material Icons Sharp"',
      '"Material Icons Two Tone"'
    ]);
  });

  it("leaves FontAwesome icons untouched", () => {
    // FontAwesome paints a ::before codepoint, not a ligature, and already renders
    // correctly in the PDF — rasterising it would be a regression.
    const doc: Document = buildDocument('<i class="fa-solid fa-check"></i>');

    const count: number = rasterizeLigatureIcons(doc);

    expect(count).toBe(0);
    expect(doc.querySelector("i.fa-solid img")).toBeNull();
    expect(fillTextCalls).toHaveLength(0);
  });

  it("leaves an empty Material icon untouched", () => {
    const doc: Document = buildDocument('<i class="material-icons">   </i>');

    const count: number = rasterizeLigatureIcons(doc);

    expect(count).toBe(0);
    expect(doc.querySelector("i.material-icons img")).toBeNull();
  });

  it("never mutates the live document it was not given", () => {
    document.body.innerHTML = '<i class="material-icons">home</i>';
    const doc: Document = buildDocument('<i class="material-icons">star</i>');

    rasterizeLigatureIcons(doc);

    expect(document.querySelector("i.material-icons")?.textContent).toBe("home");
    expect(document.querySelector("i.material-icons img")).toBeNull();
  });

  it("keeps the icon element so its own box styling survives the swap", () => {
    const doc: Document = buildDocument(
      '<i class="material-icons" style="padding:6px;background-color:rgb(1, 2, 3);font-size:32px">home</i>'
    );

    rasterizeLigatureIcons(doc);

    const icon: HTMLElement | null = doc.querySelector("i.material-icons");
    expect(icon?.style.padding).toBe("6px");
    expect(icon?.style.backgroundColor).toBe("rgb(1, 2, 3)");
    const img: HTMLImageElement | null = doc.querySelector("i.material-icons img");
    expect(img?.style.width).toBe("32px");
    expect(img?.style.height).toBe("32px");
  });

  it("keeps the glyph image inline so a background-filled icon still paints it", () => {
    // KOA-17316 QA round 2: with `display: block` on the glyph image, html2canvas
    // dropped it whenever the icon had a background-color — the PDF showed an empty
    // coloured box. Measured in a real browser: 0 glyph pixels with `block`, ~2900
    // inline. `vertical-align: middle` is equally banned; it grew the captured
    // element by 50%.
    const doc: Document = buildDocument(
      '<i class="material-icons" style="background-color:rgb(245, 220, 77);font-size:48px">home</i>'
    );

    rasterizeLigatureIcons(doc);

    const img: HTMLImageElement | null = doc.querySelector("i.material-icons img");
    expect(img).not.toBeNull();
    expect(img?.style.display).toBe("");
    expect(img?.style.verticalAlign).toBe("");
    // the user's own fill must survive untouched
    expect(doc.querySelector<HTMLElement>("i.material-icons")?.style.backgroundColor).toBe("rgb(245, 220, 77)");
  });

  it("survives an icon whose glyph cannot be rasterised", () => {
    HTMLCanvasElement.prototype.toDataURL = jest.fn((): string => {
      throw new Error("tainted canvas");
    });
    const doc: Document = buildDocument('<i class="material-icons">home</i>');

    expect((): number => rasterizeLigatureIcons(doc)).not.toThrow();
    // Left as-is rather than blanked, so the capture is never made worse than before.
    expect(doc.querySelector("i.material-icons")?.textContent).toBe("home");
  });

  it("exposes a selector that matches only ligature icon elements", () => {
    const doc: Document = buildDocument(
      '<i class="material-icons">a</i><i class="fa-solid fa-check"></i><span class="material-icons">b</span>'
    );

    expect(doc.querySelectorAll(LIGATURE_ICON_SELECTOR)).toHaveLength(1);
  });
});

describe("pdf-capture — cross-origin images", () => {
  const PNG_DATA_URL: string = "data:image/png;base64,SU5MSU5FRA==";
  let fetchMock: jest.Mock;

  beforeEach(() => {
    // jsdom's FileReader works, but it has no fetch and no HTMLImageElement.decode.
    fetchMock = jest.fn(async (): Promise<Response> => {
      return {
        ok: true,
        blob: async (): Promise<Blob> => new Blob(["INLINED"], { type: "image/png" })
      } as unknown as Response;
    });
    globalThis.fetch = fetchMock as unknown as typeof fetch;

    jest.spyOn(FileReader.prototype, "readAsDataURL").mockImplementation(function (this: FileReader): void {
      Object.defineProperty(this, "result", { value: PNG_DATA_URL, configurable: true });
      this.onloadend?.(new ProgressEvent("loadend") as ProgressEvent<FileReader>);
    });
  });

  it("inlines a cross-origin image as a data URL", async () => {
    const doc: Document = buildDocument(
      '<img src="http://cdn.example.com/v1/api/resource/runtime/byid?resourceId=abc" />'
    );

    const count: number = await inlineCrossOriginImages(doc);

    expect(count).toBe(1);
    expect(doc.querySelector("img")!.getAttribute("src")).toBe(PNG_DATA_URL);
  });

  it("rewrites the image IN PLACE — the node html2canvas holds as capture root must survive", async () => {
    // KOA-18534: html2canvas captures `clonedReferenceElement` BEFORE onclone runs and keeps
    // using that object for parseBounds/parseTree. An earlier version swapped the <img> via
    // replaceChild; when the capture target was the image itself, html2canvas measured a
    // detached node and threw "Error parsing CSS component value, unexpected EOF" — every
    // direct-Image export failed. Nested targets only survived because a descendant moved.
    const doc: Document = buildDocument('<img src="http://cdn.example.com/a.png" />');
    const original: HTMLImageElement = doc.querySelector("img")!;

    await inlineCrossOriginImages(doc);

    expect(doc.querySelector("img")).toBe(original);
    expect(original.isConnected).toBe(true);
    expect(original.getAttribute("src")).toBe(PNG_DATA_URL);
    // what html2canvas actually reads: `img.currentSrc || img.src`
    expect(original.currentSrc).toBe(PNG_DATA_URL);
  });

  it("carries the natural size over so the intrinsic-size draw guard passes before decode", async () => {
    // html2canvas skips drawing unless naturalWidth/Height > 0, and a freshly assigned data
    // URL reads 0 until decoded. jsdom never loads images, which exercises the decode fallback.
    (globalThis as unknown as { createImageBitmap: unknown }).createImageBitmap = jest.fn(
      async (): Promise<ImageBitmap> => ({ width: 300, height: 200, close: jest.fn() }) as unknown as ImageBitmap
    );
    const doc: Document = buildDocument('<img src="http://cdn.example.com/a.png" />');
    const img: HTMLImageElement = doc.querySelector("img")!;

    await inlineCrossOriginImages(doc);

    expect(img.naturalWidth).toBe(300);
    expect(img.naturalHeight).toBe(200);
  });

  it("measures an SVG through an <img> when createImageBitmap refuses the bytes", async () => {
    // Chrome rejects SVG blobs with InvalidStateError. The clone's own natural size reads 0
    // here because jsdom never loads images — which is also the real "not yet loaded" case.
    (globalThis as unknown as { createImageBitmap: unknown }).createImageBitmap = jest.fn(async (): Promise<never> => {
      throw new DOMException("The source image could not be decoded.", "InvalidStateError");
    });
    fetchMock.mockImplementation(
      async (): Promise<Response> =>
        ({
          ok: true,
          blob: async (): Promise<Blob> => new Blob(["<svg/>"], { type: "image/svg+xml" })
        }) as unknown as Response
    );
    const stub: ImageElementDecodeStub = stubImageElementDecode(266, 168);
    try {
      const doc: Document = buildDocument(`<img src="https://cdn.example.com/logo.svg" />`);
      expect(await inlineCrossOriginImages(doc)).toBe(1);
      const img: HTMLImageElement = doc.querySelector("img")!;
      expect(img.getAttribute("src")).toBe(PNG_DATA_URL);
      expect(img.naturalWidth).toBe(266);
      expect(img.naturalHeight).toBe(168);
      expect(stub.revokeObjectURL).toHaveBeenCalledWith("blob:svg-fallback");
    } finally {
      stub.restore();
    }
  });

  it("bypasses the poisoned cache entry with cache: reload", async () => {
    // Without this the browser re-serves the CORS-less response the visible <img>
    // cached, which is the entire reason the image was missing from the PDF.
    const doc: Document = buildDocument('<img src="http://cdn.example.com/a.png" />');

    await inlineCrossOriginImages(doc);

    expect(fetchMock).toHaveBeenCalled();
    const init = fetchMock.mock.calls[0][1] as RequestInit;
    expect(init.cache).toBe("reload");
    expect(init.mode).toBe("cors");
  });

  it("leaves same-origin images untouched", async () => {
    // Same-origin images need no CORS at all, so re-downloading them is pure waste.
    const doc: Document = buildDocument('<img src="/images/kuika-logo.svg" />');

    const count: number = await inlineCrossOriginImages(doc);

    expect(count).toBe(0);
    expect(doc.querySelector("img")!.getAttribute("src")).toBe("/images/kuika-logo.svg");
    expect(fetchMock).not.toHaveBeenCalled();
  });

  it("leaves data: and blob: sources untouched", async () => {
    const doc: Document = buildDocument(
      '<img src="data:image/png;base64,AAA" /><img src="blob:http://localhost/1234" />'
    );

    expect(await inlineCrossOriginImages(doc)).toBe(0);
    expect(doc.querySelectorAll("img")[0].getAttribute("src")).toBe("data:image/png;base64,AAA");
    expect(doc.querySelectorAll("img")[1].getAttribute("src")).toBe("blob:http://localhost/1234");
  });

  it("retries with credentials when the anonymous request is rejected", async () => {
    fetchMock
      .mockImplementationOnce(async (): Promise<Response> => {
        throw new TypeError("Failed to fetch");
      })
      .mockImplementationOnce(
        async (): Promise<Response> =>
          ({
            ok: true,
            blob: async (): Promise<Blob> => new Blob(["INLINED"], { type: "image/png" })
          }) as unknown as Response
      );
    const doc: Document = buildDocument('<img src="http://cdn.example.com/a.png" />');

    expect(await inlineCrossOriginImages(doc)).toBe(1);
    expect((fetchMock.mock.calls[0][1] as RequestInit).credentials).toBe("omit");
    expect((fetchMock.mock.calls[1][1] as RequestInit).credentials).toBe("include");
  });

  it("leaves the image alone when the bytes cannot be fetched", async () => {
    fetchMock.mockImplementation(async (): Promise<Response> => {
      throw new TypeError("Failed to fetch");
    });
    const doc: Document = buildDocument('<img src="http://cdn.example.com/a.png" />');

    expect(await inlineCrossOriginImages(doc)).toBe(0);
    expect(doc.querySelector("img")!.getAttribute("src")).toBe("http://cdn.example.com/a.png");
  });

  it("applies both repairs in one pass", async () => {
    const doc: Document = buildDocument('<i class="material-icons">home</i><img src="http://cdn.example.com/a.png" />');

    await preparePdfCaptureClone(doc);

    expect(doc.querySelector("i.material-icons img")).not.toBeNull();
    expect(doc.querySelector("i.material-icons")?.textContent).toBe("");
    expect(doc.querySelectorAll("img")[1].getAttribute("src")).toBe(PNG_DATA_URL);
  });
});

describe("pdf-capture — object-fit", () => {
  const FITTED_DATA_URL: string = "data:image/png;base64,RklUVEVE";
  interface DrawCall {
    dx: number;
    dy: number;
    dw: number;
    dh: number;
  }
  let drawCalls: DrawCall[];
  let drawnSources: unknown[];
  let canvasSizes: string[];

  beforeEach(() => {
    drawCalls = [];
    drawnSources = [];
    canvasSizes = [];

    // jsdom has neither createImageBitmap nor a 2D backend. Record the geometry the
    // code would have painted — these assertions are about fit maths, not pixels.
    globalThis.fetch = jest.fn(
      async (): Promise<Response> =>
        ({ ok: true, blob: async (): Promise<Blob> => new Blob(["SRC"], { type: "image/png" }) }) as unknown as Response
    ) as unknown as typeof fetch;

    (globalThis as unknown as { createImageBitmap: unknown }).createImageBitmap = jest.fn(
      async (): Promise<ImageBitmap> => ({ width: 300, height: 200, close: jest.fn() }) as unknown as ImageBitmap
    );

    HTMLCanvasElement.prototype.getContext = jest.fn(function (this: HTMLCanvasElement) {
      canvasSizes.push(`${this.width}x${this.height}`);
      return {
        scale: jest.fn(),
        drawImage: jest.fn((source: unknown, dx: number, dy: number, dw: number, dh: number) => {
          drawnSources.push(source);
          drawCalls.push({ dx, dy, dw, dh });
        })
      } as unknown as CanvasRenderingContext2D;
    }) as unknown as typeof HTMLCanvasElement.prototype.getContext;

    HTMLCanvasElement.prototype.toDataURL = jest.fn((): string => FITTED_DATA_URL);
  });

  const imgDoc = (style: string): Document => buildDocument(`<img src="/local.png" style="${style}" />`);

  it("letterboxes a contain image so html2canvas's unconditional stretch is 1:1", async () => {
    // 300x200 source into a 120x180 box: contain scale = min(0.4, 0.9) = 0.4 => 120x80,
    // centred vertically (180-80)/2 = 50.
    const doc: Document = imgDoc("width:120px;height:180px;object-fit:contain");

    const count: number = await applyImageObjectFit(doc);

    expect(count).toBe(1);
    expect(drawCalls).toHaveLength(1);
    expect(drawCalls[0].dw).toBeCloseTo(120, 1);
    expect(drawCalls[0].dh).toBeCloseTo(80, 1);
    expect(drawCalls[0].dx).toBeCloseTo(0, 1);
    expect(drawCalls[0].dy).toBeCloseTo(50, 1);
    expect(doc.querySelector("img")!.getAttribute("src")).toBe(FITTED_DATA_URL);
  });

  it("crops a cover image instead of squashing it", async () => {
    // cover scale = max(0.4, 0.9) = 0.9 => 270x180, overflowing horizontally and clipped
    // by the canvas: dx = (120-270)/2 = -75.
    const doc: Document = imgDoc("width:120px;height:180px;object-fit:cover");

    await applyImageObjectFit(doc);

    expect(drawCalls[0].dw).toBeCloseTo(270, 1);
    expect(drawCalls[0].dh).toBeCloseTo(180, 1);
    expect(drawCalls[0].dx).toBeCloseTo(-75, 1);
  });

  it("leaves object-fit: fill alone — stretching is what fill means", async () => {
    const doc: Document = imgDoc("width:120px;height:180px;object-fit:fill");

    expect(await applyImageObjectFit(doc)).toBe(0);
    expect(drawCalls).toHaveLength(0);
    expect(doc.querySelector("img")!.getAttribute("src")).toBe("/local.png");
  });

  it("skips an image whose box already matches the source aspect", async () => {
    // 300x200 into 150x100 is the same 3:2 — re-encoding would only lose quality.
    const doc: Document = imgDoc("width:150px;height:100px;object-fit:contain");

    expect(await applyImageObjectFit(doc)).toBe(0);
    expect(doc.querySelector("img")!.getAttribute("src")).toBe("/local.png");
  });

  it("oversamples so a downscaled image keeps detail at high PDF resolution", async () => {
    // contain draws the 300px-wide source into 120px, so the canvas is oversampled
    // 300/120 = 2.5x => 300x450 rather than a soft 120x180.
    const doc: Document = imgDoc("width:120px;height:180px;object-fit:contain");

    await applyImageObjectFit(doc);

    expect(canvasSizes[0]).toBe("300x450");
  });

  it("keeps the node and shadows the natural size with the composed bitmap so it is not cropped", async () => {
    // The composition is 300x450 (see the oversampling test) while the source is 300x200.
    // html2canvas draws `0,0,naturalWidth,naturalHeight → box`; left at the source size it
    // would paint only the top 200 of the 450 rows. Shadowing only `currentSrc` is NOT enough
    // — measured in the browser for KOA-18534 (object-fit root aspect 1.000 only with this).
    const doc: Document = imgDoc("width:120px;height:180px;object-fit:contain");
    const img: HTMLImageElement = doc.querySelector("img")!;

    await applyImageObjectFit(doc);

    expect(doc.querySelector("img")).toBe(img);
    expect(img.isConnected).toBe(true);
    expect(img.currentSrc).toBe(FITTED_DATA_URL);
    expect(img.naturalWidth).toBe(300);
    expect(img.naturalHeight).toBe(450);
  });

  it("leaves the image untouched when the bitmap cannot be decoded", async () => {
    (globalThis as unknown as { createImageBitmap: unknown }).createImageBitmap = jest.fn(async (): Promise<never> => {
      throw new Error("decode failed");
    });
    const doc: Document = imgDoc("width:120px;height:180px;object-fit:contain");

    expect(await applyImageObjectFit(doc)).toBe(0);
    expect(doc.querySelector("img")!.getAttribute("src")).toBe("/local.png");
  });

  describe("SVG sources", () => {
    // Chrome's createImageBitmap refuses SVG blobs ("InvalidStateError: The source image
    // could not be decoded"), so the composition has to decode through an <img> instead —
    // otherwise the correction is silently skipped and html2canvas stretches the SVG.
    beforeEach(() => {
      (globalThis as unknown as { createImageBitmap: unknown }).createImageBitmap = jest.fn(
        async (): Promise<never> => {
          throw new DOMException("The source image could not be decoded.", "InvalidStateError");
        }
      );
      globalThis.fetch = jest.fn(
        async (): Promise<Response> =>
          ({
            ok: true,
            blob: async (): Promise<Blob> => new Blob(["<svg/>"], { type: "image/svg+xml" })
          }) as unknown as Response
      ) as unknown as typeof fetch;
    });

    it("decodes through an <img> element and letterboxes like any raster", async () => {
      const stub: ImageElementDecodeStub = stubImageElementDecode(266, 168);
      try {
        const doc: Document = imgDoc("width:120px;height:180px;object-fit:contain");
        expect(await applyImageObjectFit(doc)).toBe(1);
        // 266x168 into 120x180: contain scales to 120x75.8 and centres it vertically.
        expect(drawCalls[0].dw).toBeCloseTo(120, 1);
        expect(drawCalls[0].dh).toBeCloseTo(75.8, 1);
        expect(drawCalls[0].dx).toBeCloseTo(0, 1);
        expect(drawCalls[0].dy).toBeCloseTo(52.1, 1);
        expect(drawnSources[0]).toBeInstanceOf(HTMLImageElement);
        expect(canvasSizes[0]).toBe("266x399");
        const img: HTMLImageElement = doc.querySelector("img")!;
        expect(img.getAttribute("src")).toBe(FITTED_DATA_URL);
        expect(img.naturalWidth).toBe(266);
        expect(img.naturalHeight).toBe(399);
        expect(stub.revokeObjectURL).toHaveBeenCalledWith("blob:svg-fallback");
      } finally {
        stub.restore();
      }
    });

    it("releases the object URL and leaves the image alone when the <img> decode fails too", async () => {
      const stub: ImageElementDecodeStub = stubImageElementDecode(0, 0, true);
      try {
        const doc: Document = imgDoc("width:120px;height:180px;object-fit:contain");
        expect(await applyImageObjectFit(doc)).toBe(0);
        expect(doc.querySelector("img")!.getAttribute("src")).toBe("/local.png");
        expect(stub.revokeObjectURL).toHaveBeenCalledWith("blob:svg-fallback");
      } finally {
        stub.restore();
      }
    });
  });
});

describe("pdf-capture — safe capture scale", () => {
  // jsdom reports 0 for layout, so the box is stubbed the way a real target measures.
  const targetOf = (width: number, height: number): Element => {
    const el: HTMLDivElement = document.createElement("div");
    Object.defineProperty(el, "scrollWidth", { value: width, configurable: true });
    Object.defineProperty(el, "scrollHeight", { value: height, configurable: true });
    el.getBoundingClientRect = (): DOMRect => ({ width, height }) as DOMRect;
    return el;
  };

  // Every bound below was measured in Chrome, not guessed: a canvas stays exportable up
  // to 2^28 pixels (16384x16384 works, 19200x14400 does not) and 65535 per side
  // (65535x4000 works, 70000x4000 does not). The budget is 90% of the area cap.
  const AREA_BUDGET: number = Math.floor(268435456 * 0.9);
  // The clamp lands exactly on the budget, so allow a pixel of floating-point slack.
  const AREA_TOLERANCE: number = 1;

  it("does not touch a request that already works", () => {
    // Measured: 1600x332 at 12x is 19200x3984 (76.5 Mpx) and exports fine, so clamping
    // it would be a pure quality regression. An earlier over-cautious guess did exactly
    // that, dropping it to 10.24x.
    expect(resolveSafeCaptureScale(targetOf(1600, 332), 12)).toBe(12);
    expect(resolveSafeCaptureScale(targetOf(800, 600), 7)).toBe(7);
  });

  it("clamps the area overflow that produced the silent failure", () => {
    // Measured: 1600x1200 at 12x is 276.5 Mpx and toDataURL returns "data:," (6 chars),
    // which jsPDF rejects as type 'UNKNOWN' — no file, infinite spinner.
    const scale: number = resolveSafeCaptureScale(targetOf(1600, 1200), 12);

    expect(scale).toBeLessThan(12);
    expect(1600 * scale * (1200 * scale)).toBeLessThanOrEqual(AREA_BUDGET + AREA_TOLERANCE);
    // and still far sharper than dropping all the way to 1x
    expect(scale).toBeGreaterThan(10);
  });

  it("clamps harder as the target grows", () => {
    const scale: number = resolveSafeCaptureScale(targetOf(2400, 2000), 12);

    expect(2400 * scale * (2000 * scale)).toBeLessThanOrEqual(AREA_BUDGET + AREA_TOLERANCE);
    expect(scale).toBeGreaterThan(1);
    expect(scale).toBeLessThan(8);
  });

  it("clamps on the per-side ceiling when area alone would allow more", () => {
    // 6000x100 at 12x is only 86 Mpx (area is fine) but 72000px wide, past 65535.
    const scale: number = resolveSafeCaptureScale(targetOf(6000, 100), 12);

    expect(scale).toBeLessThan(12);
    expect(6000 * scale).toBeLessThanOrEqual(65535);
  });

  it("never returns less than 1, even for an enormous target", () => {
    expect(resolveSafeCaptureScale(targetOf(40000, 40000), 12)).toBe(1);
  });

  it("falls back to the request when the target is missing or unmeasurable", () => {
    expect(resolveSafeCaptureScale(null, 12)).toBe(12);
    expect(resolveSafeCaptureScale(targetOf(0, 0), 12)).toBe(12);
  });

  it("treats a bad requested scale as 1x", () => {
    expect(resolveSafeCaptureScale(targetOf(800, 600), Number.NaN)).toBe(1);
    expect(resolveSafeCaptureScale(targetOf(800, 600), 0)).toBe(1);
  });

  it("uses the larger of bounding rect and scroll size", () => {
    // Overflowing content still lands in the capture, so the wider scroll box must win.
    // 20000px scroll width at 12x would be 240000px, far past the 65535 side ceiling,
    // while the 400px bounding rect alone would look perfectly safe.
    const el: HTMLDivElement = document.createElement("div");
    Object.defineProperty(el, "scrollWidth", { value: 20000, configurable: true });
    Object.defineProperty(el, "scrollHeight", { value: 200, configurable: true });
    el.getBoundingClientRect = (): DOMRect => ({ width: 400, height: 200 }) as DOMRect;

    expect(resolveSafeCaptureScale(el, 12) * 20000).toBeLessThanOrEqual(65535);
  });
});
