// Per-app resolution of the runtime env-config.
//
// `env.sh` materializes the container's env vars into `env-config.js`, which the
// owning page loads as a <script>. That script assigns ONE window-scoped global:
// `window._env_`.
//
// A microapp is not a page. It is this same bundle injected into the HOST's
// document, so `window._env_` belongs to the host:
//
//   * reading it hands the microapp the HOST's BACKEND_URL — the microapp looks
//     overridden by its parent, and
//   * the microapp's own `env-config.js` is never loaded at all, because the MFE
//     loader only injects the JS/CSS listed in the microapp's asset-manifest —
//     so its own BACKEND_URL env var looks completely ignored.
//
// The env-config is therefore resolved per app, never per window:
//
//   page owner (standalone deployment, or the host)
//       → `window._env_`, its own env-config.js
//   embedded microapp
//       → the env-config the MFE loader fetched from THAT microapp's own
//         deployment (`env-config.json`) and registered on its
//         `window.kuika.apps` entry; never the host's `window._env_`.
//
// `window.kuika.apps` is the existing MFE registry: the host pushes one entry per
// embedded microapp, and a microapp finds its own entry by matching the identity
// codegen bakes into both its `conf.json` (applicationName / domainName) and its
// `asset-manifest.json` (appName / workspace).
import confJson from "../json/conf.json";
import type { KuikaEnvConfig } from "./frontend-url";

/** The manifest fields this module reads; the full shape lives in AssetLoaderService. */
interface MfeAppEntryManifest {
  appName?: string;
  workspace?: string;
  backendUrlOverride?: string;
}

interface MfeAppEntryConfig {
  frontEndUrl?: string;
}

/** One entry of the `window.kuika.apps` MFE registry. */
export interface KuikaMfeAppEntry {
  appConfig?: MfeAppEntryConfig;
  manifest?: MfeAppEntryManifest;
  /**
   * The env-config fetched from this microapp's OWN deployment
   * (`<frontEndUrl>/env-config.json`). Absent when that deployment predates the
   * file or publishes no values, in which case the microapp has no env override
   * and falls back to the backend URL codegen baked into its manifest/bundle.
   */
  envConfig?: KuikaEnvConfig;
}

interface KuikaGlobals {
  apps?: KuikaMfeAppEntry[];
}

interface GlobalWithKuika {
  kuika?: KuikaGlobals;
  _env_?: KuikaEnvConfig;
}

function getGlobal(): GlobalWithKuika {
  return globalThis as GlobalWithKuika;
}

let cachedIsEmbedded: boolean | undefined;

/**
 * True when this bundle is running as a microapp inside another app's document.
 *
 * A standalone deployment's `index.html` carries `<div id="{webComponentTag}">`
 * and mounts the website root into it. Embedded, the host's MFE container
 * instead creates a bare `<{webComponentTag}>` custom element (no id) in ITS
 * document. That is the same signal `index.tsx` uses to choose between the
 * website root and the web-component entry, so the two can never disagree.
 *
 * Returns false where there is no document (service worker): a worker is always
 * scoped to its own origin, so `globalThis._env_` is genuinely its own.
 */
export function isEmbeddedAsMicroapp(): boolean {
  if (cachedIsEmbedded !== undefined) return cachedIsEmbedded;

  if (typeof document === "undefined") {
    cachedIsEmbedded = false;
    return cachedIsEmbedded;
  }

  const tag: string = (confJson?.webComponentTag ?? "").trim();
  if (tag.length === 0) {
    cachedIsEmbedded = false;
    return cachedIsEmbedded;
  }

  cachedIsEmbedded = document.getElementById(tag) === null;
  return cachedIsEmbedded;
}

/**
 * This app's own entry in the `window.kuika.apps` registry, or undefined when
 * this bundle owns the page (nothing registered it).
 *
 * Keeps the "last match wins" semantics the inlined lookups in KuikaAppManager
 * have always had: a project deployed twice under the same workspace/app name
 * resolves to the most recently registered deployment.
 */
export function findOwnMfeAppEntry(): KuikaMfeAppEntry | undefined {
  const applicationName: string = (confJson?.applicationName ?? "").trim();
  const domainName: string = (confJson?.domainName ?? "").trim();
  if (applicationName.length === 0 || domainName.length === 0) return undefined;

  const apps: KuikaMfeAppEntry[] | undefined = getGlobal().kuika?.apps;
  if (!apps || apps.length === 0) return undefined;

  let own: KuikaMfeAppEntry | undefined;
  apps.forEach((app: KuikaMfeAppEntry): void => {
    if (app?.manifest?.appName === applicationName && app?.manifest?.workspace === domainName) {
      own = app;
    }
  });
  return own;
}

/**
 * The env-config that belongs to THIS app — the page owner's `window._env_`, or
 * an embedded microapp's own fetched env-config.
 *
 * Never the host's env-config when embedded: a microapp with no per-app
 * env-config resolves to undefined so callers fall through to their own baked
 * defaults instead of inheriting the parent's.
 */
export function getOwnEnvConfig(): KuikaEnvConfig | undefined {
  const embedded: boolean = isEmbeddedAsMicroapp();
  if (!embedded) return getGlobal()._env_;
  return findOwnMfeAppEntry()?.envConfig;
}

/** Test-only: clears the memoized embedding detection. */
export function resetOwnAppEnvCache(): void {
  cachedIsEmbedded = undefined;
}
