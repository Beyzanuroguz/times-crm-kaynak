/**
 * Author-defined form tab order (KOA-14072).
 *
 * Form fields that have a Tab order set in the designer are wrapped by
 * `withCommonEvents` in a `display:contents` element carrying a
 * `data-kuika-taborder` attribute. `KuikaTabOrderProvider` (rendered once per
 * screen) reads those attributes on Tab / Shift+Tab and moves focus accordingly.
 *
 * Positive DOM `tabindex` values are deliberately NOT used: they pollute the
 * page-global tab sequence and let focus escape the form to the browser chrome.
 * Native focusability is untouched — only the traversal order is managed.
 *
 * Model — one document-wide desired tab sequence, with fields grouped by scope:
 *   Walk every focusable in the document in DOM order. A non-managed focusable
 *   keeps its position; a managed slot is filled with the next field by author
 *   order *from that field's own scope*. So each screen's order is independent
 *   (a child screen reused under different masters is unaffected by the master's
 *   numbers), scopes interleave by DOM position, and entering a scope lands on
 *   that scope's lowest order — even when crossing from a master field into a
 *   nested child screen. "Next" is simply the following element in that sequence.
 *
 * This one rule covers every combination uniformly:
 *   - any relationship between author order and DOM order (identity, reverse, permutation),
 *   - entering a group from outside it (lands on the lowest/highest order),
 *   - leaving the highest/lowest order field to the focusable outside the group,
 *   - non-managed focusables interleaved *between* ordered fields (stay reachable),
 *   - master/child (nested) scopes, mixed ordered/unordered, duplicate orders, gaps.
 * We only take over a Tab when the desired next differs from the browser's natural
 * next, so focus is left alone everywhere except where the reorder actually matters.
 *
 * The DOM-querying helpers (`collectTabOrderContext`, `groupManagedByScope`,
 * `resolveFocusable`) are kept separate from the pure selection logic
 * (`computeNextTabTarget`) so the ordering rules can be unit tested without layout.
 */

export interface TabOrderEntry {
  order: number;
  focusable: HTMLElement;
}

export interface TabOrderContext {
  /** Managed fields grouped by scope; each group sorted by author order (ascending). */
  managedByScope: HTMLElement[][];
  /** All eligible focusables in the document, in DOM order (includes the managed ones). */
  domFocusables: HTMLElement[];
}

const FOCUSABLE_SELECTOR: string =
  'input:not([type="hidden"]), select, textarea, button, [href], [contenteditable="true"], [tabindex]';

/** Marks a provider's scope root so each screen's fields can be grouped separately. */
export const TAB_ORDER_SCOPE_ATTR: string = "data-kuika-taborder-scope";

/**
 * Whether an element can currently receive focus for tab-order navigation.
 * Disabled fields (including those disabled dynamically at runtime, which the HoC
 * renders with `tabindex=-1`) and elements inside a `[hidden]` subtree are skipped.
 */
function isFocusable(el: HTMLElement): boolean {
  if ((el as HTMLInputElement).disabled === true) return false;
  if (el.getAttribute("tabindex") === "-1") return false;
  if (el.getAttribute("aria-disabled") === "true") return false;
  if (el.closest("[hidden]") !== null) return false;
  return true;
}

/** Runtime visibility check (no layout box → not tabbable). Browser-only; not exercised by unit tests. */
function isVisible(el: HTMLElement): boolean {
  return el.getClientRects().length > 0;
}

/**
 * Resolve the focusable element for a field wrapper carrying `data-kuika-taborder`.
 * The wrapper is a `display:contents` node, so the focusable control is a
 * descendant; the first focusable descendant in DOM order is used. Defensively
 * handles the wrapper itself being focusable.
 */
export function resolveFocusable(wrapper: HTMLElement): HTMLElement | null {
  if (wrapper.matches(FOCUSABLE_SELECTOR) && isFocusable(wrapper)) {
    return wrapper;
  }
  const descendants: NodeListOf<HTMLElement> = wrapper.querySelectorAll<HTMLElement>(FOCUSABLE_SELECTOR);
  for (let i = 0; i < descendants.length; i++) {
    const candidate: HTMLElement = descendants[i];
    if (isFocusable(candidate)) return candidate;
  }
  return null;
}

/**
 * Group every managed field in the document by its nearest scope, each group sorted
 * by author order (ties keep DOM order, since `querySelectorAll` is DOM-ordered and
 * the sort is stable). No visibility filtering — that is applied by
 * `collectTabOrderContext`. Exposed for unit testing.
 */
export function groupManagedByScope(doc: Document): HTMLElement[][] {
  const wrappers: NodeListOf<HTMLElement> = doc.querySelectorAll<HTMLElement>("[data-kuika-taborder]");
  const groups: Map<Element | null, TabOrderEntry[]> = new Map<Element | null, TabOrderEntry[]>();
  wrappers.forEach((wrapper: HTMLElement): void => {
    const raw: string | null = wrapper.getAttribute("data-kuika-taborder");
    const order: number = raw === null ? Number.NaN : Number(raw);
    if (Number.isNaN(order)) return;
    const focusable: HTMLElement | null = resolveFocusable(wrapper);
    if (focusable === null) return;
    const scope: Element | null = wrapper.closest(`[${TAB_ORDER_SCOPE_ATTR}]`);
    const bucket: TabOrderEntry[] | undefined = groups.get(scope);
    if (bucket === undefined) {
      groups.set(scope, [{ order, focusable }]);
    } else {
      bucket.push({ order, focusable });
    }
  });
  const result: HTMLElement[][] = [];
  groups.forEach((entries: TabOrderEntry[]): void => {
    entries.sort((a: TabOrderEntry, b: TabOrderEntry): number => a.order - b.order);
    result.push(entries.map((e: TabOrderEntry): HTMLElement => e.focusable));
  });
  return result;
}

/** All eligible focusables in the document, in DOM order. */
function collectDomFocusables(doc: Document): HTMLElement[] {
  const all: NodeListOf<HTMLElement> = doc.querySelectorAll<HTMLElement>(FOCUSABLE_SELECTOR);
  const result: HTMLElement[] = [];
  all.forEach((el: HTMLElement): void => {
    if (isFocusable(el) && isVisible(el)) result.push(el);
  });
  return result;
}

/**
 * Collect the document-wide, scope-grouped managed fields and the document-wide
 * focusable sequence. Managed fields are intersected with the visible focusables so
 * the two stay consistent (every managed field is also in `domFocusables`).
 */
export function collectTabOrderContext(container: HTMLElement): TabOrderContext {
  const doc: Document = container.ownerDocument;
  // Cheap gate first: the document-wide focusable scan only matters when there are at
  // least two ordered fields. Most screens have none, and this runs on every Tab.
  if (doc.querySelectorAll("[data-kuika-taborder]").length < 2) {
    return { managedByScope: [], domFocusables: [] };
  }
  const domFocusables: HTMLElement[] = collectDomFocusables(doc);
  const visible: Set<HTMLElement> = new Set<HTMLElement>(domFocusables);
  const managedByScope: HTMLElement[][] = groupManagedByScope(doc)
    .map((group: HTMLElement[]): HTMLElement[] => group.filter((el: HTMLElement): boolean => visible.has(el)))
    .filter((group: HTMLElement[]): boolean => group.length > 0);
  return { managedByScope, domFocusables };
}

/**
 * The desired tab sequence: DOM order with each managed slot replaced by the next
 * field in author order *from that field's own scope*. Non-managed focusables keep
 * their position. Requires every managed field to be present in `domFocusables`.
 */
function buildDesiredSequence(managedByScope: HTMLElement[][], domFocusables: HTMLElement[]): HTMLElement[] {
  const scopeOf: Map<HTMLElement, number> = new Map<HTMLElement, number>();
  managedByScope.forEach((group: HTMLElement[], scopeIndex: number): void => {
    for (const el of group) scopeOf.set(el, scopeIndex);
  });
  const pointers: number[] = managedByScope.map((): number => 0);
  const sequence: HTMLElement[] = [];
  for (const el of domFocusables) {
    const scopeIndex: number | undefined = scopeOf.get(el);
    if (scopeIndex === undefined) {
      sequence.push(el);
    } else if (pointers[scopeIndex] < managedByScope[scopeIndex].length) {
      sequence.push(managedByScope[scopeIndex][pointers[scopeIndex]]);
      pointers[scopeIndex]++;
    }
  }
  return sequence;
}

/** The focusable in `domFocusables` that is, or contains, `active` (handles descendant focus). */
function owningFocusable(active: Element, domFocusables: HTMLElement[]): HTMLElement | null {
  // Prefer the exact element, so a managed control is never mis-resolved to a
  // focusable ancestor that happens to come earlier in DOM order.
  const exactIndex: number = domFocusables.indexOf(active as HTMLElement);
  if (exactIndex !== -1) return domFocusables[exactIndex];
  for (const el of domFocusables) {
    if (el.contains(active)) return el;
  }
  return null;
}

/**
 * Decide where focus should go on Tab / Shift+Tab. Returns the element to focus
 * (the caller calls `preventDefault()` + `focus()`), or `null` to let the browser
 * handle it — either because the desired move equals the browser's natural move, or
 * because focus is genuinely leaving the document.
 */
export function computeNextTabTarget(
  managedByScope: HTMLElement[][],
  domFocusables: HTMLElement[],
  active: Element | null,
  backwards: boolean
): HTMLElement | null {
  const managedCount: number = managedByScope.reduce((n: number, g: HTMLElement[]): number => n + g.length, 0);
  if (managedCount < 2) return null;

  const sequence: HTMLElement[] = buildDesiredSequence(managedByScope, domFocusables);
  if (sequence.length < 2) return null;

  const step: number = backwards ? -1 : 1;
  const owner: HTMLElement | null = active === null ? null : owningFocusable(active, domFocusables);

  if (owner === null) {
    // Focus is outside the focusable set (e.g. document body on the first Tab). If the
    // browser's first/last stop differs from the desired one, redirect; else leave it.
    if (domFocusables.length === 0) return null;
    const desiredEnd: HTMLElement = backwards ? sequence[sequence.length - 1] : sequence[0];
    const naturalEnd: HTMLElement = backwards ? domFocusables[domFocusables.length - 1] : domFocusables[0];
    return desiredEnd === naturalEnd ? null : desiredEnd;
  }

  const naturalNextIndex: number = domFocusables.indexOf(owner) + step;
  const naturalNext: HTMLElement | null =
    naturalNextIndex >= 0 && naturalNextIndex < domFocusables.length ? domFocusables[naturalNextIndex] : null;

  const seqIndex: number = sequence.indexOf(owner);
  const desiredNextIndex: number = seqIndex + step;
  const desiredNext: HTMLElement | null =
    desiredNextIndex >= 0 && desiredNextIndex < sequence.length ? sequence[desiredNextIndex] : null;

  if (desiredNext === null) {
    // End of the desired sequence. If `active` is also at the DOM edge, let focus
    // leave the document; otherwise the order-edge field sits mid-DOM, so releasing
    // would land on a DOM-adjacent field — wrap to the other end of the sequence
    // (emulating the document wrapping back into the group) instead.
    if (naturalNext === null) return null;
    return backwards ? sequence[sequence.length - 1] : sequence[0];
  }

  // Take over only when the reorder actually changes where focus goes.
  return desiredNext === naturalNext ? null : desiredNext;
}
