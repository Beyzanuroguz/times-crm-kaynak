import moment from "moment";
import { buildSpecificDateKeys, isBlockedBySpecificDates, toDayKey } from "./specific-dates";

// The workspace maps `^moment$` to a stub; day-key parsing needs the real library.
jest.mock("moment", () => jest.requireActual("moment/moment.js"));

interface HolidayRow {
  id: number;
  holidayDate: string;
}

describe("specific-dates (KOA-18129)", () => {
  describe("toDayKey", () => {
    it("keeps the wall date of an ISO string regardless of its offset", () => {
      expect(toDayKey("2026-04-23T00:00:00Z")).toBe("2026-04-23");
      expect(toDayKey("2026-04-23T23:30:00-05:00")).toBe("2026-04-23");
      expect(toDayKey("2026-04-23T00:00:00")).toBe("2026-04-23");
      expect(toDayKey("2026-04-23")).toBe("2026-04-23");
    });

    it("accepts the day-first formats a fixed list is typed in", () => {
      expect(toDayKey("23.04.2026")).toBe("2026-04-23");
      expect(toDayKey("19/05/2026")).toBe("2026-05-19");
    });

    it("accepts Date and moment values", () => {
      expect(toDayKey(new Date(2026, 7, 30, 15, 0, 0))).toBe("2026-08-30");
      expect(toDayKey(moment("2026-08-30", "YYYY-MM-DD"))).toBe("2026-08-30");
    });

    it("rejects values that are not dates", () => {
      expect(toDayKey(undefined)).toBeUndefined();
      expect(toDayKey(null)).toBeUndefined();
      expect(toDayKey("")).toBeUndefined();
      expect(toDayKey("   ")).toBeUndefined();
      expect(toDayKey("holiday")).toBeUndefined();
      expect(toDayKey("31.02.2026")).toBeUndefined();
      expect(toDayKey(true)).toBeUndefined();
      expect(toDayKey(Number.NaN)).toBeUndefined();
    });

    it("never treats a number as a date (an Id column would otherwise read as 1970-01-01)", () => {
      expect(toDayKey(1)).toBeUndefined();
      expect(toDayKey(1776902400000)).toBeUndefined();
    });
  });

  describe("buildSpecificDateKeys", () => {
    const rows: HolidayRow[] = [
      { id: 1, holidayDate: "2026-04-23T00:00:00" },
      { id: 2, holidayDate: "2026-05-19T00:00:00" },
      { id: 3, holidayDate: "2026-08-30T00:00:00" }
    ];

    it("reads the configured field of every row", () => {
      const keys: Set<string> | undefined = buildSpecificDateKeys(rows, ["holidayDate"]);
      expect(Array.from(keys ?? [])).toEqual(["2026-04-23", "2026-05-19", "2026-08-30"]);
    });

    it("matches the field name case-insensitively", () => {
      const keys: Set<string> | undefined = buildSpecificDateKeys(rows, ["HolidayDate"]);
      expect(keys?.size).toBe(3);
    });

    it("uses the display field when the key field is an id column", () => {
      const keys: Set<string> | undefined = buildSpecificDateKeys(rows, ["id", "holidayDate"]);
      expect(Array.from(keys ?? [])).toEqual(["2026-04-23", "2026-05-19", "2026-08-30"]);
    });

    it("prefers the first candidate field that holds a date", () => {
      const twoDates: object[] = [{ startDate: "2026-04-23", endDate: "2026-04-25" }];
      expect(Array.from(buildSpecificDateKeys(twoDates, ["endDate", "startDate"]) ?? [])).toEqual(["2026-04-25"]);
    });

    it("falls back to the first date-valued cell when no field is configured", () => {
      const keys: Set<string> | undefined = buildSpecificDateKeys(rows);
      expect(keys?.has("2026-05-19")).toBe(true);
      expect(keys?.size).toBe(3);
      expect(buildSpecificDateKeys(rows, [undefined, ""])?.size).toBe(3);
    });

    it("never falls back to another column once a field is configured", () => {
      const audited: object[] = [
        { id: 1, name: "Cumhuriyet Bayramı", createdAt: "2026-01-02", holidayDate: "2026-10-29" },
        { id: 2, name: "Zafer Bayramı", createdAt: "2026-01-02", holidayDate: null }
      ];
      // Neither configured field holds a date: nothing matches (not the created-at stamp).
      expect(buildSpecificDateKeys(audited, ["id", "name"])?.size).toBe(0);
      // An empty configured cell skips its row instead of reading the created-at stamp.
      expect(Array.from(buildSpecificDateKeys(audited, ["holidayDate"]) ?? [])).toEqual(["2026-10-29"]);
    });

    it("accepts a list of plain date values", () => {
      const keys: Set<string> | undefined = buildSpecificDateKeys(["2026-04-23", new Date(2026, 4, 19)]);
      expect(Array.from(keys ?? [])).toEqual(["2026-04-23", "2026-05-19"]);
    });

    it("skips rows whose value is missing or unparseable", () => {
      const keys: Set<string> | undefined = buildSpecificDateKeys(
        [{ holidayDate: null }, { holidayDate: "n/a" }, { holidayDate: "2026-04-23" }, null],
        ["holidayDate"]
      );
      expect(Array.from(keys ?? [])).toEqual(["2026-04-23"]);
    });

    it("returns undefined when there is no list, meaning no restriction", () => {
      expect(buildSpecificDateKeys(undefined, ["holidayDate"])).toBeUndefined();
      expect(buildSpecificDateKeys(null, ["holidayDate"])).toBeUndefined();
      expect(buildSpecificDateKeys("2026-04-23", ["holidayDate"])).toBeUndefined();
    });
  });

  describe("isBlockedBySpecificDates", () => {
    const keys: Set<string> = new Set<string>(["2026-04-23", "2026-05-19"]);
    const listedDay: moment.Moment = moment("2026-04-23 14:45", "YYYY-MM-DD HH:mm");
    const otherDay: moment.Moment = moment("2026-04-24", "YYYY-MM-DD");

    it("Disable mode blocks only the listed days (the default mode)", () => {
      expect(isBlockedBySpecificDates(listedDay, keys, "Disable")).toBe(true);
      expect(isBlockedBySpecificDates(otherDay, keys, "Disable")).toBe(false);
      expect(isBlockedBySpecificDates(listedDay, keys, undefined)).toBe(true);
    });

    it("Enable mode blocks every day except the listed ones", () => {
      expect(isBlockedBySpecificDates(listedDay, keys, "Enable")).toBe(false);
      expect(isBlockedBySpecificDates(otherDay, keys, "Enable")).toBe(true);
    });

    it("never blocks when the list is absent or empty, in either mode", () => {
      expect(isBlockedBySpecificDates(otherDay, undefined, "Enable")).toBe(false);
      expect(isBlockedBySpecificDates(otherDay, new Set<string>(), "Enable")).toBe(false);
      expect(isBlockedBySpecificDates(listedDay, new Set<string>(), "Disable")).toBe(false);
    });
  });
});
