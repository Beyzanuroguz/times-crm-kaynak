// Amap (AutoNavi) map-data coverage helpers.
//
// An Amap key covers mainland China out of the box; overseas map data (海外地图) is a
// separate entitlement on the key. Without it the tile service answers
// TILE_ACCESS_OVERSEA_FORBIDDEN for zoom >= 9 outside mainland China while still
// authorizing the JSAPI, so the map initializes, draws its DOM overlays (marker, logo)
// and renders its empty grid background — it looks broken rather than empty, and nothing
// is logged. Zoom levels below the limit are served worldwide (coarse basemap).
//
// Hence the two exports here: a mainland default center so an unbound map renders instead
// of showing the grid, and a one-time developer warning when a map is centered where the
// tile service will refuse to answer.
import { outOfChina } from "./coordinate-transform";
import { isAmapWorldMapEnabled } from "./map-provider-config";

/** First zoom level Amap refuses to serve outside mainland China without the overseas entitlement. */
export const AMAP_OVERSEAS_TILE_ZOOM_LIMIT: number = 9;

/** A WGS-84 coordinate pair used as a map center. */
export interface IAmapCenter {
  latitude: number;
  longitude: number;
}

/**
 * Fallback center for an Amap map with no bound coordinate: Tiananmen, Beijing in
 * **WGS-84** — the coordinate system Kuika stores, which `wgs84ToGcj02` shifts to the
 * ~39.90923 / 116.397428 GCJ-02 pair Amap publishes for the same place.
 *
 * Google Maps keeps its own (Istanbul) default; reusing that one for Amap is what made an
 * unbound map render as an empty grid, since it is both outside mainland China and above
 * {@link AMAP_OVERSEAS_TILE_ZOOM_LIMIT} at the default zoom.
 */
export const AMAP_DEFAULT_CENTER: IAmapCenter = { latitude: 39.9075, longitude: 116.3913 };

let hasWarnedAboutCoverage: boolean = false;

/**
 * Logs one developer-facing warning when a map is centered where a mainland-only Amap key
 * serves no tiles, so the empty render is self-explaining. Warns once per page: every tile
 * request in the viewport fails, and the map components re-center on pan/zoom. Silent on
 * World Map projects, whose key is entitled to overseas tiles.
 */
export function warnIfOutsideAmapCoverage(latitude: number, longitude: number, zoom: number): void {
  if (hasWarnedAboutCoverage) return;
  if (zoom < AMAP_OVERSEAS_TILE_ZOOM_LIMIT) return;
  const isWorldMap: boolean = isAmapWorldMapEnabled();
  if (isWorldMap) return;

  const isOverseas: boolean = outOfChina(latitude, longitude);
  if (!isOverseas) return;

  hasWarnedAboutCoverage = true;
  console.warn(
    `Amap: the map is centered at ${latitude},${longitude} (outside mainland China) at zoom ${zoom}. ` +
      `Amap serves no tiles there for zoom >= ${AMAP_OVERSEAS_TILE_ZOOM_LIMIT} unless overseas map data ` +
      "(海外地图) is enabled on the Amap key — the tile service answers TILE_ACCESS_OVERSEA_FORBIDDEN and " +
      "the map renders empty. Center the map in mainland China, zoom out below that level, or enable " +
      "overseas map data on the key."
  );
}

/** Test seam: clears the once-per-page warning latch. */
export function resetAmapCoverageWarningForTests(): void {
  hasWarnedAboutCoverage = false;
}
