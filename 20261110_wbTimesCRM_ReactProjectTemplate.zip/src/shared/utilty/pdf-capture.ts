/**
 * Prepares html2canvas's cloned document for a Component-to-PDF capture. Two
 * independent defects are repaired here, both invisible on screen and both only
 * affecting the capture — see docs/sample-react-app.md.
 *
 * Material icon fonts draw their glyph from a *ligature*: the element's text is the
 * icon name ("home") and the font substitutes it for a single glyph. html2canvas —
 * which backs the Component to PDF action via react-to-pdf — paints text with
 * `ctx.fillText`, so the glyph only survives capture when the ligature shapes exactly
 * as it did on screen. Two things routinely break that:
 *
 *  - a non-zero `letter-spacing` on the icon makes html2canvas paint one grapheme at a
 *    time (see `breakText` in html2canvas), and single letters have no glyph in an icon
 *    font, so the icon disappears;
 *  - if the icon font fails to resolve in the paint context, the ligature name is drawn
 *    as literal text and the PDF shows "home" instead of the icon.
 *
 * FontAwesome is immune because it paints a `::before` codepoint rather than a ligature.
 *
 * Rasterising each ligature into an <img> inside html2canvas's throwaway clone removes
 * the dependency on ligature shaping entirely, so neither failure mode can occur. The
 * live DOM is never touched. NodeTree already does the equivalent for its own export.
 */

const MATERIAL_ICON_FONT_BY_CLASS: Record<string, string> = {
  "material-icons": "Material Icons",
  "material-icons-outlined": "Material Icons Outlined",
  "material-icons-round": "Material Icons Round",
  "material-icons-sharp": "Material Icons Sharp",
  "material-icons-two-tone": "Material Icons Two Tone"
};

export const LIGATURE_ICON_SELECTOR: string = Object.keys(MATERIAL_ICON_FONT_BY_CLASS)
  .map((className: string): string => `i.${className}`)
  .join(", ");

/** Matches `.material-icons { font-size: 24px }` in public/material-icons.min.css. */
const DEFAULT_ICON_FONT_SIZE: number = 24;

/** Rasterise above CSS-pixel size so the glyph stays sharp at higher PDF resolutions. */
const RASTER_SCALE: number = 4;

const resolveFontFamily = (element: Element): string | null => {
  for (const className of Object.keys(MATERIAL_ICON_FONT_BY_CLASS)) {
    if (element.classList.contains(className)) {
      return MATERIAL_ICON_FONT_BY_CLASS[className];
    }
  }
  return null;
};

const resolveFontSize = (computed: CSSStyleDeclaration): number => {
  const parsed: number = parseFloat(computed.fontSize);
  if (!Number.isFinite(parsed) || parsed <= 0) {
    return DEFAULT_ICON_FONT_SIZE;
  }
  return parsed;
};

const renderGlyphDataUrl = (ligature: string, fontFamily: string, fontSize: number, color: string): string | null => {
  // The canvas is created in the *live* document on purpose: that is where the icon
  // font is already loaded, so fillText can shape the ligature. The cloned iframe may
  // not have finished fetching its own copy of the font.
  const canvas: HTMLCanvasElement = document.createElement("canvas");
  const side: number = Math.ceil(fontSize * RASTER_SCALE);
  canvas.width = side;
  canvas.height = side;

  const context: CanvasRenderingContext2D | null = canvas.getContext("2d");
  if (!context) {
    return null;
  }

  context.scale(RASTER_SCALE, RASTER_SCALE);
  context.font = `${fontSize}px "${fontFamily}"`;
  context.fillStyle = color;
  context.textBaseline = "middle";
  context.textAlign = "center";
  context.fillText(ligature, fontSize / 2, fontSize / 2);

  return canvas.toDataURL("image/png");
};

/**
 * Replaces the ligature text of every Material icon in `clonedDocument` with a
 * pre-rendered glyph image. Intended for html2canvas's `onclone` hook — pass the
 * cloned document, never the live one.
 *
 * @returns how many icons were rasterised.
 */
export const rasterizeLigatureIcons = (clonedDocument: Document): number => {
  const icons: NodeListOf<Element> = clonedDocument.querySelectorAll(LIGATURE_ICON_SELECTOR);
  const view: Window = clonedDocument.defaultView ?? window;
  let rasterized: number = 0;

  icons.forEach((icon: Element): void => {
    const ligature: string = (icon.textContent ?? "").trim();
    if (!ligature) {
      return;
    }

    const fontFamily: string | null = resolveFontFamily(icon);
    if (!fontFamily) {
      return;
    }

    const computed: CSSStyleDeclaration = view.getComputedStyle(icon);
    const fontSize: number = resolveFontSize(computed);

    let dataUrl: string | null = null;
    try {
      dataUrl = renderGlyphDataUrl(ligature, fontFamily, fontSize, computed.color || "#000");
    } catch {
      // Rasterising is best-effort: on failure leave the icon exactly as it was so the
      // capture is never worse than before this hook existed.
      dataUrl = null;
    }
    if (!dataUrl) {
      return;
    }

    const image: HTMLImageElement = clonedDocument.createElement("img");
    image.src = dataUrl;
    image.style.width = `${fontSize}px`;
    image.style.height = `${fontSize}px`;
    // The glyph image must stay INLINE. `display: block` here made html2canvas drop it
    // entirely whenever the icon carried a background-color (KOA-17316 QA round 2): a
    // block child of a background-painting inline-block never got painted, leaving an
    // empty coloured box. Inline keeps the box identical (measured: same canvas size,
    // glyph within 1px of the native render) and paints in every case. Do not set
    // `vertical-align: middle` either — on a 48px glyph in a 16px line box that grew
    // the captured element by 50%.
    icon.textContent = "";
    icon.appendChild(image);
    rasterized += 1;
  });

  return rasterized;
};

const isCrossOrigin = (rawSrc: string): boolean => {
  try {
    return new URL(rawSrc, window.location.href).origin !== window.location.origin;
  } catch {
    return false;
  }
};

const blobToDataUrl = (blob: Blob): Promise<string> => {
  return new Promise((resolve, reject) => {
    const reader: FileReader = new FileReader();
    reader.onloadend = (): void => resolve(String(reader.result));
    reader.onerror = (): void => reject(new Error("FileReader failed"));
    reader.readAsDataURL(blob);
  });
};

/** Upper bound on one image fetch, so a stalled request cannot hang the export. */
const IMAGE_FETCH_TIMEOUT_MS: number = 15000;

// `cache: "reload"` is the load-bearing part: it forces a fresh network request and
// bypasses the CORS-less cached entry that the visible <img> left behind.
const fetchImageBytes = async (url: string): Promise<Blob | null> => {
  const attempts: RequestCredentials[] = ["omit", "include"];
  for (const credentials of attempts) {
    const controller: AbortController = new AbortController();
    const timer: ReturnType<typeof setTimeout> = setTimeout((): void => controller.abort(), IMAGE_FETCH_TIMEOUT_MS);
    try {
      const response: Response = await fetch(url, {
        mode: "cors",
        cache: "reload",
        credentials,
        signal: controller.signal
      });
      if (response.ok) {
        return await response.blob();
      }
    } catch {
      // Try the next credentials mode: a CDN answering `ACAO: *` rejects credentialed
      // requests, while an auth-gated Kuika resource needs them.
    } finally {
      clearTimeout(timer);
    }
  }
  return null;
};

interface InlinedBitmap {
  dataUrl: string;
  width: number;
  height: number;
}

/** A decoded image ready for `drawImage`, plus the handle that frees it. */
interface DecodedImage {
  source: CanvasImageSource;
  width: number;
  height: number;
  release: () => void;
}

const decodeWithImageBitmap = async (blob: Blob): Promise<DecodedImage | null> => {
  try {
    const bitmap: ImageBitmap = await createImageBitmap(blob);
    return { source: bitmap, width: bitmap.width, height: bitmap.height, release: (): void => bitmap.close?.() };
  } catch {
    return null;
  }
};

/**
 * Fallback decoder for what `createImageBitmap` refuses. Chrome rejects SVG blobs outright
 * ("InvalidStateError: The source image could not be decoded"), and an uploaded SVG is an
 * ordinary Image source in Kuika — without this the `object-fit` composition below was
 * silently skipped for them and html2canvas stretched the SVG to fill its box. An `<img>`
 * element rasterises SVG without complaint and is itself a `CanvasImageSource`. The object
 * URL lives only until `release()`, so callers must call it once they have drawn.
 */
const decodeWithImageElement = async (blob: Blob): Promise<DecodedImage | null> => {
  if (typeof URL.createObjectURL !== "function" || typeof HTMLImageElement.prototype.decode !== "function") {
    return null;
  }
  const objectUrl: string = URL.createObjectURL(blob);
  const release = (): void => URL.revokeObjectURL(objectUrl);
  try {
    const element: HTMLImageElement = new Image();
    element.src = objectUrl;
    await element.decode();
    if (element.naturalWidth <= 0 || element.naturalHeight <= 0) {
      release();
      return null;
    }
    return { source: element, width: element.naturalWidth, height: element.naturalHeight, release };
  } catch {
    release();
    return null;
  }
};

const decodeImage = async (blob: Blob): Promise<DecodedImage | null> => {
  const viaBitmap: DecodedImage | null = await decodeWithImageBitmap(blob);
  if (viaBitmap) {
    return viaBitmap;
  }
  return decodeWithImageElement(blob);
};

/**
 * Rewrites an image's source IN PLACE — never by swapping the node.
 *
 * html2canvas captures its root reference (`clonedReferenceElement`) before `onclone`
 * runs and keeps using that same object afterwards for `parseBounds` and `parseTree`.
 * An earlier version of this helper replaced the `<img>` via `replaceChild`; when the
 * capture target was the image itself, html2canvas went on measuring the detached
 * original — zero bounds, then a throw — and every such export failed with the
 * "PDF could not be created" notice (surfaced by KOA-17684 QA). Nested targets only
 * survived because a descendant, not the root, was being swapped.
 *
 * `currentSrc`, `naturalWidth` and `naturalHeight` are getter-only on the prototype, so
 * own data properties on the instance shadow them — and those are exactly what
 * html2canvas reads (`img.currentSrc || img.src` in `ImageElementContainer`, and the
 * `intrinsicWidth > 0` guard in `renderReplacedElement`). Shadowing the natural size
 * also frees the draw from the decode race a plain `src` reassignment would introduce:
 * the data URL's own natural size reads as 0 until it has decoded. Dimensions are
 * shadowed only when known; otherwise the live getters stay in place.
 */
const inlineImageSource = (image: HTMLImageElement, bitmap: InlinedBitmap): void => {
  image.removeAttribute("srcset");
  image.setAttribute("src", bitmap.dataUrl);
  Object.defineProperty(image, "currentSrc", { value: bitmap.dataUrl, configurable: true });
  if (bitmap.width > 0 && bitmap.height > 0) {
    Object.defineProperty(image, "naturalWidth", { value: bitmap.width, configurable: true });
    Object.defineProperty(image, "naturalHeight", { value: bitmap.height, configurable: true });
  }
};

/**
 * Inlines cross-origin images in the clone as `data:` URLs.
 *
 * The Image component renders a plain `<img src>` with no `crossOrigin`, so the browser
 * caches that response against a request that carried no `Origin` header and therefore
 * no `Access-Control-Allow-Origin`. html2canvas then re-requests the *same* URL with
 * `crossOrigin="anonymous"` (its `useCORS` mode), is handed that CORS-less cache entry,
 * and the load fails — the image is absent from the PDF while looking perfectly fine on
 * screen. Rewriting the `src` alone is not enough: html2canvas reads
 * `img.currentSrc || img.src` (`ImageElementContainer`), and `currentSrc` is read-only
 * and already points at the original URL. Fetching the bytes ourselves and handing the
 * clone a `data:` URL removes the network — and CORS — from the capture entirely.
 *
 * Only cross-origin sources are touched: same-origin images need no CORS, and
 * `data:` / `blob:` sources are already inline. An image whose bytes cannot be fetched
 * is left untouched, so a capture is never made worse than before.
 *
 * @returns how many images were inlined.
 */
export const inlineCrossOriginImages = async (clonedDocument: Document): Promise<number> => {
  const images: HTMLImageElement[] = Array.from(clonedDocument.querySelectorAll("img"));
  let inlined: number = 0;

  await Promise.all(
    images.map(async (image: HTMLImageElement): Promise<void> => {
      const rawSrc: string = image.getAttribute("src") ?? "";
      if (!rawSrc || rawSrc.startsWith("data:") || rawSrc.startsWith("blob:")) {
        return;
      }
      if (!isCrossOrigin(rawSrc)) {
        return;
      }

      const absolute: string = new URL(rawSrc, window.location.href).toString();
      const blob: Blob | null = await fetchImageBytes(absolute);
      if (!blob) {
        return;
      }

      try {
        const dataUrl: string = await blobToDataUrl(blob);
        // Same bytes the clone already displays, so its natural size carries over; decode
        // only if the clone had not finished loading the original when we got here.
        let width: number = image.naturalWidth;
        let height: number = image.naturalHeight;
        if (width <= 0 || height <= 0) {
          const decoded: DecodedImage | null = await decodeImage(blob);
          width = decoded?.width ?? 0;
          height = decoded?.height ?? 0;
          decoded?.release();
        }
        inlineImageSource(image, { dataUrl, width, height });
        inlined += 1;
      } catch {
        // Leave the original src in place.
      }
    })
  );

  return inlined;
};

interface FitRect {
  dx: number;
  dy: number;
  dw: number;
  dh: number;
}

/** Keeps a re-composed bitmap from exploding on a large box with a huge source. */
const MAX_FIT_CANVAS_PIXELS: number = 4096 * 4096;

/**
 * Where the source bitmap lands inside the destination box for a given `object-fit`.
 * `object-position` is not honoured — the browser default (`50% 50%`) is assumed, which
 * is what the styling panel produces.
 */
const computeFitRect = (fit: string, sourceW: number, sourceH: number, boxW: number, boxH: number): FitRect => {
  let scale: number;
  if (fit === "cover") {
    scale = Math.max(boxW / sourceW, boxH / sourceH);
  } else if (fit === "none") {
    scale = 1;
  } else if (fit === "scale-down") {
    scale = Math.min(1, Math.min(boxW / sourceW, boxH / sourceH));
  } else {
    scale = Math.min(boxW / sourceW, boxH / sourceH);
  }
  const dw: number = sourceW * scale;
  const dh: number = sourceH * scale;
  return { dx: (boxW - dw) / 2, dy: (boxH - dh) / 2, dw, dh };
};

const decodeImageAt = async (src: string): Promise<DecodedImage | null> => {
  try {
    const response: Response = await fetch(src);
    const blob: Blob = await response.blob();
    return await decodeImage(blob);
  } catch {
    return null;
  }
};

const contentBoxSize = (image: HTMLImageElement, computed: CSSStyleDeclaration): FitRect => {
  const padX: number = (parseFloat(computed.paddingLeft) || 0) + (parseFloat(computed.paddingRight) || 0);
  const padY: number = (parseFloat(computed.paddingTop) || 0) + (parseFloat(computed.paddingBottom) || 0);
  const width: number = (image.clientWidth || parseFloat(computed.width) || 0) - padX;
  const height: number = (image.clientHeight || parseFloat(computed.height) || 0) - padY;
  return { dx: 0, dy: 0, dw: width, dh: height };
};

/**
 * Bakes `object-fit` into the bitmap itself.
 *
 * html2canvas has **no** `object-fit` support (the string does not appear anywhere in
 * 1.4.1); `ImageElementContainer` is drawn with a single unconditional
 * `drawImage(image, 0,0, intrinsicW,intrinsicH, box.left,box.top, box.width,box.height)`,
 * i.e. always `fill`. A 300x200 image in a fixed 120x180 box therefore prints stretched —
 * circles become ellipses (KOA-17316 QA round 2). This was always true; it only became
 * visible once images started rendering at all.
 *
 * Rather than resize the element (which would move everything around it), the bitmap is
 * re-composed onto a canvas whose aspect ratio already matches the content box, with the
 * source letterboxed/cropped per the computed `object-fit`. html2canvas's unconditional
 * stretch then becomes a uniform 1:1 scale, so the printed result matches the screen.
 *
 * The canvas is oversampled so a downscaled image keeps its detail at high PDF
 * resolutions — pre-composing at box size alone would soften every image at
 * `Quality = HIGH`/`EXTREME`.
 *
 * @returns how many images were re-composed.
 */
export const applyImageObjectFit = async (clonedDocument: Document): Promise<number> => {
  const view: Window = clonedDocument.defaultView ?? window;
  const images: HTMLImageElement[] = Array.from(clonedDocument.querySelectorAll("img"));
  let adjusted: number = 0;

  await Promise.all(
    images.map(async (image: HTMLImageElement): Promise<void> => {
      const computed: CSSStyleDeclaration = view.getComputedStyle(image);
      const fit: string = computed.objectFit || "fill";
      if (fit === "fill") {
        return;
      }

      const box: FitRect = contentBoxSize(image, computed);
      if (box.dw <= 0 || box.dh <= 0) {
        return;
      }

      const src: string = image.getAttribute("src") ?? "";
      if (!src) {
        return;
      }

      // By the time this runs, cross-origin sources have already been inlined, so every
      // remaining source is same-origin or `data:` and reads back without tainting.
      const decoded: DecodedImage | null = await decodeImageAt(src);
      if (!decoded || !decoded.width || !decoded.height) {
        return;
      }

      const target: FitRect = computeFitRect(fit, decoded.width, decoded.height, box.dw, box.dh);
      // Aspect already matches and nothing is cropped: the default stretch is correct.
      if (Math.abs(target.dw - box.dw) < 0.5 && Math.abs(target.dh - box.dh) < 0.5) {
        decoded.release();
        return;
      }

      let oversample: number = target.dw > 0 ? Math.max(1, decoded.width / target.dw) : 1;
      if (box.dw * box.dh * oversample * oversample > MAX_FIT_CANVAS_PIXELS) {
        oversample = Math.max(1, Math.sqrt(MAX_FIT_CANVAS_PIXELS / (box.dw * box.dh)));
      }

      try {
        const canvas: HTMLCanvasElement = document.createElement("canvas");
        canvas.width = Math.max(1, Math.round(box.dw * oversample));
        canvas.height = Math.max(1, Math.round(box.dh * oversample));
        const context: CanvasRenderingContext2D | null = canvas.getContext("2d");
        if (!context) {
          return;
        }
        context.scale(oversample, oversample);
        context.drawImage(decoded.source, target.dx, target.dy, target.dw, target.dh);
        // The composed bitmap has the BOX's dimensions, not the source's — the natural
        // size must follow it or html2canvas would crop the composition to the old size.
        inlineImageSource(image, {
          dataUrl: canvas.toDataURL("image/png"),
          width: canvas.width,
          height: canvas.height
        });
        adjusted += 1;
      } catch {
        // Leave the image as it was rather than risk losing it entirely.
      } finally {
        decoded.release();
      }
    })
  );

  return adjusted;
};

/**
 * Ceiling on one canvas edge. Measured in Chrome: 65535x4000 still exports, 70000x4000
 * does not.
 */
const MAX_CAPTURE_CANVAS_SIDE: number = 65535;

/**
 * Ceiling on total canvas pixels, 90% of the engines' 2^28 area cap.
 *
 * Measured in Chrome: 16384x16384 (268.4 Mpx, exactly 2^28) still exports; 19200x14400
 * (276.5 Mpx) and 20000x20000 (400 Mpx) do not — `toDataURL()` returns the 6-character
 * string `data:,`. The 10% headroom is for the encoded copy jsPDF makes and for engines
 * that sit slightly below the documented cap; sitting exactly on the boundary is not
 * worth the risk.
 *
 * Do not lower this "to be safe" without measuring: an over-aggressive cap silently
 * degrades exports that work perfectly. An earlier 2^26 guess would have dropped a
 * working 1600x332 capture from 12x to 10.24x for no reason.
 */
const MAX_CAPTURE_CANVAS_PIXELS: number = Math.floor(268435456 * 0.9);

/**
 * Largest capture scale a target can survive, so an oversized request degrades instead
 * of failing.
 *
 * `Resolution.EXTREME` is 12, and it is handed straight to html2canvas as `scale`. On a
 * large target that blows past the browser's canvas area cap; the canvas is then
 * silently unusable, `toDataURL()` returns `data:,`, and jsPDF rejects it with
 * `addImage does not support files of type 'UNKNOWN'` — so the export produces no file
 * at all (KOA-18461, folded into KOA-17316). The same overflow can instead yield an
 * all-black page, which is the same cause wearing a different symptom.
 *
 * Measured at scale 12: a 1600x332 target (76.5 Mpx) exports fine, while 1600x1200
 * (276.5 Mpx) does not — so the trigger is total area, not the requested quality alone.
 * That matches QA's isolation, where the same content exported at HIGH but not EXTREME.
 *
 * Degradation is deliberately silent: the caller asked for maximum quality and gets the
 * maximum *feasible* quality. A warning on an otherwise successful export is noise.
 *
 * @returns the requested scale, or the largest safe one, never below 1.
 */
export const resolveSafeCaptureScale = (target: Element | null, requestedScale: number): number => {
  const requested: number = Number.isFinite(requestedScale) && requestedScale > 0 ? requestedScale : 1;
  if (!target) {
    return requested;
  }

  const rect: DOMRect = target.getBoundingClientRect();
  // Overflowing content still ends up in the capture, so take the larger of the two.
  const width: number = Math.max(rect.width, target.scrollWidth || 0);
  const height: number = Math.max(rect.height, target.scrollHeight || 0);
  if (width <= 0 || height <= 0) {
    return requested;
  }

  const byWidth: number = MAX_CAPTURE_CANVAS_SIDE / width;
  const byHeight: number = MAX_CAPTURE_CANVAS_SIDE / height;
  const byArea: number = Math.sqrt(MAX_CAPTURE_CANVAS_PIXELS / (width * height));
  const safe: number = Math.min(byWidth, byHeight, byArea);

  return Math.max(1, Math.min(requested, safe));
};

/**
 * html2canvas `onclone` hook for both Component-to-PDF entry points. Operates only on
 * the throwaway clone; the live DOM is never modified. html2canvas awaits this hook, so
 * every repair completes before the clone is parsed and rendered.
 *
 * Order matters: images are inlined first so that the `object-fit` pass can read their
 * pixels back without tripping over cross-origin tainting.
 */
export const preparePdfCaptureClone = async (clonedDocument: Document): Promise<void> => {
  rasterizeLigatureIcons(clonedDocument);
  await inlineCrossOriginImages(clonedDocument);
  await applyImageObjectFit(clonedDocument);
};
