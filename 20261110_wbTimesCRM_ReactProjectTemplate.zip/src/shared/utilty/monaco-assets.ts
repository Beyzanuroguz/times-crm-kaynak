/**
 * Output directory (relative to the build root / public path) that the copied
 * `monaco-editor/min/vs` payload is emitted into.
 *
 * Shared between the build config (`rsbuild.config.ts`, which copies the files)
 * and `monaco-loader-config.ts` (which points the AMD loader at them). Keep this
 * module free of imports and side effects — it is loaded by the Node-side build
 * config as well as by the browser bundle.
 */
export const MONACO_VS_PUBLIC_DIR: string = "monaco-editor/vs";
