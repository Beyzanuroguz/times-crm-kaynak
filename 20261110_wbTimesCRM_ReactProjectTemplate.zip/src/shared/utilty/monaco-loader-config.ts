import { loader } from "@monaco-editor/react";
import { MONACO_VS_PUBLIC_DIR } from "./monaco-assets";

/**
 * `@monaco-editor/react` ships a loader that, by default, pulls the Monaco AMD
 * bundle from `https://cdn.jsdelivr.net/npm/monaco-editor@<version>/min/vs`.
 * That breaks every air-gapped / egress-restricted deployment — and every
 * offline or Electron run — because the CDN is unreachable and the editor never
 * mounts.
 *
 * We serve Monaco from the app's own origin instead. `rsbuild.config.ts` copies
 * `monaco-editor/min/vs` (the exact version pinned in package.json) into
 * `MONACO_VS_PUBLIC_DIR` of the build output, and this module points the loader
 * at it. No request ever leaves the deployment.
 *
 * Importing this module has the side effect of configuring the loader, so it
 * must be imported before any editor is mounted (`loader.config` throws once the
 * loader has started initializing Monaco).
 */

// Replaced by rspack with the runtime public path (`__webpack_require__.p`),
// so the path honours whatever `output.assetPrefix` the deployment builds with.
declare const __webpack_public_path__: string;

const resolveMonacoVsPath = (): string => {
  const publicPath: string = typeof __webpack_public_path__ === "string" ? __webpack_public_path__ : "";
  const basePath: string = publicPath.length > 0 ? publicPath : "/";
  const normalizedBasePath: string = basePath.endsWith("/") ? basePath : `${basePath}/`;

  // Absolute URL: the loader injects a <script src> that would otherwise be
  // resolved against the current SPA route rather than the deployment root.
  return new URL(`${normalizedBasePath}${MONACO_VS_PUBLIC_DIR}`, window.location.href).toString();
};

loader.config({ paths: { vs: resolveMonacoVsPath() } });
