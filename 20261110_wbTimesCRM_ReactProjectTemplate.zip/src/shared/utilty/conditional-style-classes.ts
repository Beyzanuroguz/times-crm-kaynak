/**
 * KOA-9069 conditional styling, runtime half.
 *
 * The code generator emits, per component that has conditional styles:
 *   CSS   `.kuika-style-{id}.kuika-cond-{i} { … !important }`  (one rule per style, in order)
 *   props `conditionalStyleConditions={[(rowData) => …, …]}`   (one predicate, same order)
 *
 * Index order is the whole contract between the two halves, which is why the generator emits
 * `() => false` for an unusable condition rather than dropping it — dropping one would shift
 * every later index and silently repoint the remaining styles at the wrong CSS rules.
 *
 * Two callers evaluate the predicates, and the difference is only which row they pass:
 * `TableData` passes the row it is rendering, and `withCommonEvents` passes {@link NO_ROW} for
 * a component that is not inside a table.
 */

export type ConditionalStylePredicate = (rowData: object) => boolean;

/**
 * The argument for a component that has no row — anything outside a table.
 *
 * A screen-scope condition (an action result, a screen input, a default value) reads component
 * state through its own closure and never touches `rowData`, so there is nothing to supply. A
 * condition that *does* read a row field gets `undefined` and resolves to false, which is the
 * right answer: that rule was authored for a row the component does not have.
 *
 * Frozen so a predicate cannot write into the object every other component also receives.
 */
export const NO_ROW: object = Object.freeze({});

/**
 * The `kuika-cond-{i}` classes a component earns for the given row.
 *
 * A predicate that throws counts as unmatched. A condition reads row fields directly, so a row
 * missing the field it names would otherwise take the whole cell down; a style that quietly
 * does not apply is the right failure here.
 */
export const matchedConditionalStyleClasses = (conditions: ConditionalStylePredicate[], rowData: object): string[] => {
  const matched: string[] = [];

  conditions.forEach((condition: ConditionalStylePredicate, index: number): void => {
    if (typeof condition !== "function") {
      return;
    }

    let isMatch: boolean = false;
    try {
      isMatch = condition(rowData) === true;
    } catch {
      isMatch = false;
    }

    if (isMatch) {
      matched.push(`kuika-cond-${index}`);
    }
  });

  return matched;
};

/** Joins class name parts, dropping the empty and undefined ones. */
export const joinClassNames = (...parts: (string | undefined)[]): string =>
  parts.filter((part: string | undefined): part is string => typeof part === "string" && part.length > 0).join(" ");
