import { AxiosResponse } from "axios";
import { Guid } from "guid-typescript";
import isRelativeUrl from "is-relative-url";
import { Store } from "react-notifications-component";
import mimeTypeMappings from "../json/mime-types-mappings.json";
import { BASE_64_REGEX, DEFAULT_IMAGE, OFFLINE_REDIRECT_CANCEL, OFFLINE_RESOURCE_PUBLIC_PREFIX } from "./constants";
import { KuikaAppManager } from "./kuika-app-manager";

interface FileSignature {
  signs: string[];
  mime: string;
}

interface FileSignatures {
  [key: string]: FileSignature;
}

export interface ResolveImageSrcOptions {
  /** Raw style width (e.g. "40px", "100%", 40). Used for server-side resize. */
  width?: string | number;
  /** Raw style height (e.g. "40px", "100%", 40). Used for server-side resize. */
  height?: string | number;
  imageFit?: 0 | 1 | 2;
  placeHolderImage?: string;
  /**
   * Append a `t=<timestamp>` cache-buster to backend image endpoints.
   * Defaults to `true` (matches the Image element). Pass `false` for content
   * rendered many times / re-rendered often (e.g. calendar avatars) so the
   * browser can cache the resized image instead of re-downloading it.
   */
  cacheBust?: boolean;
}

export class KMainFunctions {
  static virtualDirectoryURL: string = "auto"; // Use by code generation

  // Written by Router for this bundle only: a pathname-routed shell and the microapp it embeds
  // share one window.location, so "is there a hash" cannot tell whose route the hash is.
  // Undefined until a Router mounts (tests, bare renders); readers then keep the hash-first path.
  static isHashRouted: boolean | undefined;

  // NOTIFY ACTION DEFAULT DURATIONS
  static NOTIFY_ACTION_DEFAULT_DEFAULT_DURATION = 5;

  static NOTIFY_ACTION_DEFAULT_SUCCESS_DURATION = 5;

  static NOTIFY_ACTION_DEFAULT_INFO_DURATION = 7;

  static NOTIFY_ACTION_DEFAULT_WARNING_DURATION = 15;

  static NOTIFY_ACTION_DEFAULT_ERROR_DURATION = 0;

  static get windowLocationOrigin() {
    let origin = window?.location?.origin;
    if (window?.location?.protocol === "file:") {
      origin = `file://${window.location.pathname}`;
      return origin;
    }
    return KMainFunctions.virtualDirectoryURL === "auto" ? origin : `${origin}${KMainFunctions.virtualDirectoryURL}`;
  }

  static exceptionHandler(e) {
    const msg = e?.response?.data?.message;
    const statusCode = e?.response?.status;

    // Handle offline redirect - show warning only if not already on offline screen
    if (e?.message === OFFLINE_REDIRECT_CANCEL) {
      const currentPath = window.location.pathname.toLowerCase();
      const offlineScreenName = window.kuikaOfflineScreenName?.toLowerCase();

      // Check if already on offline screen (consider virtualDirectory and microApp paths)
      if (offlineScreenName && currentPath.includes(offlineScreenName)) {
        return; // Don't show notification if already on offline screen
      }

      this.displayWarningNotification(
        localStorage.getItem("ml") === "tr_TR"
          ? "Çevrimdışı - çevrimdışı ekranına yönlendiriliyorsunuz"
          : "Offline - redirecting to offline screen",
        { duration: this.NOTIFY_ACTION_DEFAULT_WARNING_DURATION * 1000 }
      );
      return;
    }

    if (statusCode === 503 || statusCode === 422) {
      if (msg) {
        this.displayWarningNotification(msg);
        return;
      }
      if (e?.message) {
        console.error(e.message);
        this.displayWarningNotification(e.message);
        return;
      }
    }

    if (msg) {
      this.displayErrorNotification(msg);
    } else if (e?.message) {
      console.error(e.message);
      this.displayErrorNotification(e.message);
    }
    if (e?.stack) {
      console.error(e.stack);
    }
  }

  static displaySuccessNotification(message, params?) {
    Store.addNotification({
      title: params?.title ?? (localStorage.getItem("ml") === "tr_TR" ? "Başarılı!" : "Success!"),
      message,
      type: "success",
      container: params?.container ? params.container : "bottom-right",
      animationIn: params?.animationIn ? params.animationIn : ["animated", "flipInX"],
      animationOut: params?.animationOut ? params.animationOut : ["animated", "fadeOut"],
      dismiss: {
        duration: params?.duration ? params.duration : this.NOTIFY_ACTION_DEFAULT_SUCCESS_DURATION * 1000,
        pauseOnHover: params?.pauseOnHover ? params.pauseOnHover : true,
        showIcon: params?.showIcon ? params.showIcon : true
      }
    });
  }

  static ignoreKnownConsoleWarns(): void {
    if (!window.location.href.includes("localhost")) {
      const ignoredWarnings: string[] = [
        "[webpack-dev-server",
        "Google Maps JavaScript",
        "allow-scripts and allow-same-origin",
        "It looks like there are several",
        "styled-components",
        "link preload but not used within a few second",
        "react-fast-compare cannot handle circular refs",
        "componentWillReceiveProps has been renamed"
      ];
      const originalConsoleWarns = console.warn;
      console.warn = function (...args) {
        if (args[0] && ignoredWarnings.some((element) => args[0].toString().includes(element))) {
          return;
        }
        originalConsoleWarns.apply(console, args);
      };
    }
  }

  static ignoreKnownConsoleErrors(): void {
    if (!window.location.href.includes("localhost")) {
      const ignoredErrors: string[] = [
        "is deprecated in StrictMode",
        "Invalid DOM property",
        "X-Frame-Options may only be",
        "spell it as lowercase",
        "A valid state object (or null) must be returned",
        "Each child in a list should have a unique",
        "or a non-boolean attribute",
        "Invalid value for prop",
        "is not connected to any Form element.",
        "onResize is not a function",
        "listener to be a function",
        "Unknown event handler property",
        "validateDOMNesting(...)",
        "Failed prop type: Invalid prop"
      ];
      const originalConsoleErrors = console.error;
      console.error = function (...args) {
        if (args[0] && ignoredErrors.some((element) => args[0].toString().includes(element))) {
          return;
        }
        originalConsoleErrors.apply(console, args);
      };
    }
  }

  static displayWarningNotification(message, params?) {
    Store.addNotification({
      title: params?.title ?? (localStorage.getItem("ml") === "tr_TR" ? "Uyarı!" : "Warning!"),
      message,
      type: "warning",
      container: params?.container ? params.container : "bottom-right",
      animationIn: params?.animationIn ? params.animationIn : ["animated", "flipInX"],
      animationOut: params?.animationOut ? params.animationOut : ["animated", "fadeOut"],
      dismiss: {
        duration: params?.duration ? params.duration : this.NOTIFY_ACTION_DEFAULT_WARNING_DURATION * 1000,
        pauseOnHover: params?.pauseOnHover ? params.pauseOnHover : true,
        showIcon: params?.showIcon ? params.showIcon : true
      }
    });
  }

  static displayErrorNotification(message, params?) {
    if (message) {
      Store.addNotification({
        title: params?.title ?? (localStorage.getItem("ml") === "tr_TR" ? "Hata!" : "Error!"),
        message,
        type: "danger",
        container: params?.container ? params.container : "bottom-right",
        animationIn: params?.animationIn ? params.animationIn : ["animated", "flipInX"],
        animationOut: params?.animationOut ? params.animationOut : ["animated", "fadeOut"],
        dismiss: {
          duration: params?.duration ? params.duration : this.NOTIFY_ACTION_DEFAULT_ERROR_DURATION * 1000,
          pauseOnHover: params?.pauseOnHover ? params.pauseOnHover : true,
          showIcon: params?.showIcon ? params.showIcon : true
        }
      });
    }
  }

  static toCamelCase(value: string): string {
    if (!value || (this.isLetter(value[0]) && !this.isUpperCase(value[0]))) {
      return value;
    }

    let prefix = "";
    let chars = value.split("");

    if (!this.isLetter(value[0])) {
      prefix = value[0];
      chars = value.slice(1).split("");
    }

    for (let i = 0; i < chars.length; i++) {
      if (i === 1 && !this.isUpperCase(chars[i])) {
        break;
      }
      const hasNext = i + 1 < chars.length;

      // Stop when next char is already lowercase.
      if (i > 0 && hasNext && !this.isUpperCase(chars[i + 1])) {
        // If the next char is a space, lowercase current char before exiting.
        if (chars[i + 1] === " ") {
          chars[i] = chars[i].toLowerCase();
        }
        break;
      }

      chars[i] = chars[i].toLowerCase();
    }

    return prefix + chars.join("");
  }

  // Static helper method to check if a character is a letter
  private static isLetter(char: string): boolean {
    return /^[a-zA-Z]$/.test(char);
  }

  // Static helper method to check if a character is uppercase
  private static isUpperCase(char: string): boolean {
    if (!this.isLetter(char)) {
      return false;
    }

    return char === char.toUpperCase();
  }

  static IsResStatus2XX(res: AxiosResponse): boolean {
    return !!(res?.status && res.status >= 200 && res.status < 300);
  }

  static getTextAlignAsJustifyContent(value: string) {
    if (value) {
      if (value.includes("center")) return "center";
      if (value.includes("right")) return "flex-end";
      if (value.includes("left")) return "flex-start";
    }
  }

  static setChildWidthAndAlignment(child) {
    const kuikablockstyle = child.getAttribute("kuikablockstyle");
    const componentname = child.getAttribute("kuikacomponentname");
    const childClassName = child.className;
    if (child.parentElement.className?.includes("ant-table-cell") && child.className?.includes("ant-space")) {
      child.style.height = "auto";
    }
    if (
      kuikablockstyle === "2" ||
      componentname === "Date" ||
      childClassName?.includes("kuika_table__wrapper") ||
      childClassName?.includes("ant-form-item-row") ||
      childClassName?.includes("kFormItem") ||
      childClassName?.includes("ant-row") ||
      childClassName?.startsWith("kuikaStepperComponent") ||
      child?.style?.display === "block"
    ) {
      child.style.width = "100%";
    } else {
      child.style.alignSelf = "center";
    }
  }

  static setKFormItemStyles(child) {
    const imageInputs = child.querySelectorAll(".kuika-image-input");
    for (let i = 0; i < imageInputs.length; i++) {
      const imageInput = imageInputs[i];
      const kFormItemParent = imageInput.closest(".kFormItem");
      if (kFormItemParent) {
        kFormItemParent.style.width = "auto";
        kFormItemParent.style.alignSelf = "center";
      }
    }
  }

  static setDisplayBlockForImages(node) {
    const images = node.querySelectorAll("[kuikacomponentname='Image']");
    for (let i = 0; i < images.length; i++) {
      const image = images[i];
      if (image && image.children && image.children[0]) {
        image.children[0].style.display = "block";
      }
    }
  }

  static handleAlignments(node: any, styles: any, isInline?: boolean, elementsDirection?: "horizontal" | "vertical") {
    if (elementsDirection === "vertical" && styles && node && node.style) {
      return node;
    }

    if (styles && styles.alignItems && node && node.style) {
      node.style.display = isInline ? "inline-flex" : "flex";
      node.style.flexWrap = "wrap";
      node.style.placeContent = styles.alignItems;

      if (node.children) {
        for (let i = 0; i < node.children.length; i++) {
          const child = node.children[i];
          if (child) {
            this.setChildWidthAndAlignment(child);
            this.setKFormItemStyles(child);
          }
        }
        this.setDisplayBlockForImages(node);
      }
    }

    if (styles && styles.alignItems && styles.textAlign && node && node.style) {
      const justify = KMainFunctions.getTextAlignAsJustifyContent(styles.textAlign);
      node.style.justifyContent = justify;
    } else if (styles && styles.alignItems && !styles.textAlign && node && node.style) {
      node.style.justifyContent = "flex-start";
    }

    return node;
  }

  static isValidUrl(url: string) {
    if (!url) return false;

    try {
      // eslint-disable-next-line no-new
      new URL(url);
      return true;
    } catch {
      return false;
    }
  }

  static isRelativeUrl(url: string): boolean {
    return isRelativeUrl(url);
  }

  static isBase64(str: string) {
    if (!str) return false;
    return BASE_64_REGEX.test(str);
  }

  public static openBase64Pdf(data: string, warnLandscape: boolean, openAs: "newTab" | "currentPage"): void {
    const base64WithoutPrefix = data.substring("data:application/pdf;base64,".length);
    const bytes = atob(base64WithoutPrefix);
    let { length } = bytes;
    const out = new Uint8Array(length);

    while (length--) {
      out[length] = bytes.charCodeAt(length);
    }

    const url = URL.createObjectURL(new Blob([out], { type: "application/pdf" }));
    KMainFunctions.openUrlPdf(url, openAs);
  }

  public static openUrlPdf(url: string, openAs: "newTab" | "currentPage"): void {
    if (openAs === "currentPage") {
      window.open(url, "_self")?.focus();
      return;
    }

    // openAs === "newTab"
    window.open(url, "_blank")?.focus();
  }

  public static async downloadFile(data: string | Blob, fileName: string): Promise<void> {
    const FileSaver = (await import("file-saver")).default;
    FileSaver.saveAs(data, fileName);
  }

  public static async toBlob(dataUrl: string): Promise<Blob> {
    const response = await fetch(dataUrl);
    return response.blob();
  }

  public static getBase64UrlPrefix(mimeType: string): string {
    return `data:${mimeType};base64,`;
  }

  /**
   * Converts a raw style dimension into an integer pixel size for the backend
   * image-resize params, or `undefined` when the value is not an absolute
   * pixel size. Only bare numbers (`40`) and explicit pixel values (`"40px"`)
   * are real resize targets; percentage and viewport/relative units
   * (`"100%"`, `"50vw"`, `"10vh"`, `"auto"`, ...) are resolved by CSS on the
   * client and must never be sent to the server resizer — otherwise the
   * backend interprets e.g. `"100%"` as `100px` and shrinks the image
   * (KOA-18064). Shared with the Image element so both the resize URL and the
   * on-load height adjustment treat non-pixel units identically.
   */
  public static resolveResizePixels = (value: string | number | undefined): number | undefined => {
    if (value == null) {
      return undefined;
    }
    const raw: string = value.toString().trim();
    // Reject anything that is not a plain number optionally suffixed with "px".
    if (!/^\d+(\.\d+)?(px)?$/i.test(raw)) {
      return undefined;
    }
    const pixels: number = parseInt(raw, 10);
    return Number.isFinite(pixels) && pixels > 0 ? pixels : undefined;
  };

  /**
   * Resolves an arbitrary stored image value into a displayable `src`,
   * supporting plain links, base64/data URIs, uploaded-image backend
   * endpoints (`/image`, `/resource/runtime/byid`) and bare resource GUIDs.
   * This is the single source of truth shared by the Image element and any
   * other component that renders user-provided images (e.g. calendar avatars).
   */
  public static resolveImageSrc = (value: string | undefined, options?: ResolveImageSrcOptions): string => {
    const opts: ResolveImageSrcOptions = options ?? {};
    const backendUrl: string = KuikaAppManager.GetBackendUrl();
    const cacheBust: boolean = opts.cacheBust !== false;

    // Raw dims (px stripped) for the resource-id endpoint, which only honors string sizes.
    const widthForResource: string | number = opts.width != null ? opts.width.toString().replace("px", "") : 0;
    const heightForResource: string | number = opts.height != null ? opts.height.toString().replace("px", "") : 0;
    // Absolute pixel dims for the path-based endpoint, or undefined for
    // percentage / viewport-relative units (those are sized by CSS on the
    // client and must not be sent as a server resize — KOA-18064).
    const widthForEndpoint: number | undefined = KMainFunctions.resolveResizePixels(opts.width);
    const heightForEndpoint: number | undefined = KMainFunctions.resolveResizePixels(opts.height);
    const imageFit: 0 | 1 | 2 = opts.imageFit ?? 0;

    let currentValue: string = DEFAULT_IMAGE;

    if (value && value !== "") {
      if (value.startsWith("http://") || value.startsWith("https://")) {
        return value;
      }
      if (value.startsWith(OFFLINE_RESOURCE_PUBLIC_PREFIX)) {
        // Offline-screen UploadedImages the code generator bundled into public/
        // (see OFFLINE_RESOURCE_PUBLIC_PREFIX). The stored value is app-root-relative,
        // so resolve it against the frontend base URL — otherwise it resolves to the
        // origin root and 404s on apps hosted under a virtual directory (the common
        // Preview/Run case, served at "/{app}/"). getFrontEndUrl() returns
        // origin(+virtualDir) with no trailing slash, and value starts with "/".
        const frontEndUrl: string = KuikaAppManager.GetFrontEndUrl();
        return `${frontEndUrl}${value}`;
      }
      if (value.includes("/image") || value.includes("/resource/runtime/byid")) {
        const url: URL = new URL(backendUrl + value);
        // Only forward absolute pixel sizes to the resizer; a percentage /
        // viewport dimension is left off so the backend returns the full-size
        // image and CSS handles the sizing on the client (KOA-18064).
        if (widthForEndpoint !== undefined) {
          url.searchParams.append("width", widthForEndpoint.toString());
        }
        if (heightForEndpoint !== undefined) {
          url.searchParams.append("height", heightForEndpoint.toString());
        }
        url.searchParams.append("imageFit", imageFit.toString());
        if (cacheBust) {
          url.searchParams.append("t", Date.now().toString());
        }
        currentValue = url.toString();
      } else {
        currentValue = value;
      }
    } else if (opts.placeHolderImage) {
      currentValue = opts.placeHolderImage;
    }

    let guidValue: string = Guid.EMPTY;
    try {
      guidValue = Guid.parse(currentValue).toString();
    } catch {
      guidValue = Guid.EMPTY;
    }

    if (guidValue !== Guid.EMPTY) {
      currentValue = KMainFunctions.getUrlByWithResourceId(
        guidValue,
        widthForResource,
        heightForResource,
        opts.imageFit
      );
    }

    return currentValue;
  };

  public static getUrlByWithResourceId = (
    guid: string,
    width?: string | number,
    height?: string | number,
    imageFit?: 0 | 1 | 2
  ) => {
    const url: URL = new URL(`${KuikaAppManager.GetBackendUrl()}/resource/runtime/byid`);

    url.searchParams.append("resourceId", guid);

    if (width && typeof width === "string" && !width?.includes("%") && !width?.includes("vw")) {
      url.searchParams.append("width", width.toString());
    }

    if (height && typeof height === "string" && !height?.includes("%") && !height?.includes("vh")) {
      url.searchParams.append("height", height.toString());
    }

    if (imageFit) {
      url.searchParams.append("imageFit", imageFit.toString());
    }

    return url.toString();
  };

  public static getExtensionByMimeType(filename: string, mimeType: string): string {
    if (mimeType === "application/octet-stream") {
      const lastDotIndex = filename.lastIndexOf(".");
      if (lastDotIndex !== -1 && lastDotIndex < filename.length - 1) {
        return filename.substring(lastDotIndex + 1);
      }
      return "";
    }

    const extension = mimeTypeMappings[mimeType];

    if (!extension) {
      return "";
    }

    return extension;
  }

  public static generateFilenameForDownloadFile(filename: string, extension: string): string {
    const isExtensionValid: boolean = extension && extension !== "" && extension !== "undefined";
    const isFilenameValid: boolean = filename && filename !== "" && filename !== "undefined";

    if (isFilenameValid && filename.endsWith(`.${extension}`)) {
      return filename;
    }

    if (!isFilenameValid && isExtensionValid) {
      return `${Guid.create().toString()}.${extension}`;
    }

    if (isFilenameValid && !isExtensionValid) {
      return filename;
    }

    if (isFilenameValid && isExtensionValid) {
      return `${filename}.${extension}`;
    }

    return Guid.create().toString();
  }

  public static getIsValidHttpUrl(value: unknown): boolean {
    if (typeof value !== "string") {
      return false;
    }

    let url: URL;

    try {
      url = new URL(value);
    } catch (_) {
      return false;
    }

    return url.protocol === "http:" || url.protocol === "https:";
  }

  static turkishCharsToEnglish(str: string): string {
    return str
      ?.replace("Ğ", "G")
      ?.replace("Ü", "U")
      ?.replace("Ş", "S")
      ?.replace("İ", "I")
      ?.replace("Ö", "O")
      ?.replace("Ç", "C")
      ?.replace("ğ", "g")
      ?.replace("ü", "u")
      ?.replace("ş", "s")
      ?.replace("ı", "i")
      ?.replace("ö", "o")
      ?.replace("ç", "c")
      ?.replace("i̇", "i");
  }

  public static convertBlobToBase64(blob: Blob): Promise<string | ArrayBuffer> {
    const reader = new FileReader();
    reader.readAsDataURL(blob);

    return new Promise((resolve) => {
      reader.onloadend = () => {
        resolve(reader.result);
      };
    });
  }

  public static base64ToUint8Array(base64: string) {
    const binaryString = atob(base64);
    const len = binaryString.length;
    const bytes = new Uint8Array(len);
    for (let i = 0; i < len; i++) {
      bytes[i] = binaryString.charCodeAt(i);
    }
    return bytes;
  }

  private static parseSignature(signStr: string): { offset: number; signature: string } {
    const [offsetStr, signature] = signStr.split(",");
    return {
      offset: parseInt(offsetStr, 10),
      signature: signature.toLowerCase()
    };
  }

  private static isZipSignature(signature: string): boolean {
    return signature.toLowerCase() === "504b0304";
  }

  private static async getZipBasedFileType(bytes: Uint8Array): Promise<string> {
    try {
      const JSZip = (await import("jszip")).default;
      const zip = new JSZip();
      const contents = await zip.loadAsync(bytes);
      const files = Object.keys(contents.files);

      const hasFile = (pattern: string) => files.some((file) => file.startsWith(pattern));
      const hasFileContent = async (filename: string, contentPattern: string) => {
        const file = contents.file(filename);
        if (!file) return false;
        const content = await file.async("text");
        return content.includes(contentPattern);
      };

      if (hasFile("xl/")) {
        return "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet";
      }

      if (hasFile("word/")) {
        return "application/vnd.openxmlformats-officedocument.wordprocessingml.document";
      }

      if (hasFile("ppt/")) {
        return "application/vnd.openxmlformats-officedocument.presentationml.presentation";
      }

      if (hasFile("META-INF/container.xml")) {
        const isEpub = await hasFileContent("META-INF/container.xml", "rootfiles");
        if (isEpub) {
          return "application/epub+zip";
        }
      }

      if (files.some((file) => file.endsWith(".kml"))) {
        return "application/vnd.google-earth.kmz";
      }

      if (hasFile("mimetype")) {
        const mimetypeContent = await contents.file("mimetype")?.async("text");
        if (mimetypeContent) {
          if (mimetypeContent.includes("spreadsheet")) {
            return "application/vnd.oasis.opendocument.spreadsheet";
          }
          if (mimetypeContent.includes("text")) {
            return "application/vnd.oasis.opendocument.text";
          }
          if (mimetypeContent.includes("presentation")) {
            return "application/vnd.oasis.opendocument.presentation";
          }
        }
      }

      return "application/zip";
    } catch (error) {
      console.warn("Error reading ZIP file:", error);
      return "application/zip";
    }
  }

  private static async getFileSignatures(): Promise<FileSignatures> {
    const signatures = await import("../json/file-signatures.json");
    return signatures.default;
  }

  public static async getFileType(base64: string): Promise<string> {
    const bytes = this.base64ToUint8Array(base64);

    const signatures = await this.getFileSignatures();

    const matchSignature = (offset: number, signature: string): boolean => {
      const signatureBytes = signature.match(/.{1,2}/g)?.map((hex) => parseInt(hex, 16)) || [];
      if (offset + signatureBytes.length > bytes.length) return false;

      return signatureBytes.every((byte, i) => bytes[offset + i] === byte);
    };

    for (const [ext, info] of Object.entries(signatures)) {
      for (const signStr of info.signs) {
        const { offset, signature } = this.parseSignature(signStr);

        if (matchSignature(offset, signature)) {
          if (this.isZipSignature(signature)) {
            return this.getZipBasedFileType(bytes);
          }

          return info.mime;
        }
      }
    }

    return "application/octet-stream";
  }

  /**
   * Converts a value to a string suitable for the WASM boundary.
   * Date and moment objects are serialized as ISO 8601 strings
   * so that SQL Server can parse them correctly.
   * Returns null for null/undefined values.
   */
  static toWasmString(value: unknown): string | null {
    if (value == null) return null;
    if (value instanceof Date) return value.toISOString();
    if (typeof value === "object" && typeof (value as any).toISOString === "function") {
      return (value as any).toISOString();
    }
    return String(value);
  }
}
