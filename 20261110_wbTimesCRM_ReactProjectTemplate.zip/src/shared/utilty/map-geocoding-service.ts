// Region-aware geocoding through the generated backend, for Amap projects.
//
// Amap serves the world from two platforms: mainland China from the domestic one (the JSAPI
// plugins in the browser only know this one) and everywhere else from Amap Global Maps. The
// domestic geocoding engine answers 30001 ENGINE_RESPONSE_DATA_ERROR for any non-China address,
// so a browser-side geocode of a Turkish address can never succeed. When the code generator
// emitted MapGeocodingController (AMAP_GEOCODING_BACKEND in env-config), the location actions and
// LocationSearch call it instead; the backend's AMapWebServiceClient picks the platform per request
// and answers in WGS-84, and the Web Service key never reaches the browser.
//
// Every function here returns `undefined` when the backend is not enabled or did not answer, so
// callers can fall back to the JSAPI plugin path (which still works for mainland data).
import { IGeoPoint } from "./coordinate-transform";
import { toCoordinatePair } from "./coordinate-value";
import { KuikaEnvConfig } from "./frontend-url";
import { KuikaAppManager } from "./kuika-app-manager";
import { isAmapProvider } from "./map-provider-config";

interface GlobalWithEnv {
  _env_?: KuikaEnvConfig;
}

/** `GoogleMapsLocation` as the backend serializes it. */
export interface IBackendLocation {
  lat?: number | null;
  lng?: number | null;
}

/** `GoogleMaps_maps_geocode_Result` as the backend serializes it. */
export interface IBackendGeocodeResult {
  location_info?: IBackendLocation | null;
  formatted_address?: string | null;
}

/** `GoogleMapsAddressComponent` — Google's type taxonomy, on both providers. */
export interface IBackendAddressComponent {
  long_name?: string | null;
  short_name?: string | null;
  types?: string[] | null;
}

/** `GoogleMaps_maps_reverse_geocode_Result` as the backend serializes it. */
export interface IBackendReverseGeocodeResult {
  formatted_address?: string | null;
  address_components?: IBackendAddressComponent[] | null;
}

/** `GoogleMapsPlace` as the backend serializes it. */
export interface IBackendPlace {
  name?: string | null;
  formatted_address?: string | null;
  location_info?: IBackendLocation | null;
  place_id?: string | null;
}

interface IBackendSearchPlacesResult {
  places?: IBackendPlace[] | null;
}

/** The address shape the LocationAddressOfCoordinates action returns. */
export interface ILocationAddressData {
  address: string | undefined;
  city: string | undefined;
  state: string | undefined;
  country: string | undefined;
  neighborhood: string | undefined;
  street: string | undefined;
  postalCode: string | undefined;
}

interface IApiResponseLike {
  status?: number;
  data?: unknown;
}

/**
 * ApiRequest reports failures through the screen's spinner; the location actions have no screen,
 * so give it an inert one. Failures still surface through KMainFunctions.exceptionHandler.
 */
const SILENT_SCREEN: { state: { spinnerCount: number }; setState: () => void } = {
  state: { spinnerCount: 0 },
  setState: (): void => undefined
};

/** True when this Amap project's backend carries MapGeocodingController. */
export function isAmapGeocodingBackendEnabled(): boolean {
  const isAmap: boolean = isAmapProvider();
  if (!isAmap) return false;
  const env: KuikaEnvConfig | undefined = (globalThis as GlobalWithEnv)._env_;
  return env?.AMAP_GEOCODING_BACKEND === "true";
}

interface IApiErrorLike {
  response?: IApiResponseLike;
  message?: string;
}

/**
 * Posts to MapGeocodingController. A failed call is logged with its status and body before the
 * caller falls back to the JSAPI plugin — the plugin only knows mainland China, so without this
 * log a backend 401/404/500 would surface as a misleading Amap 30001 in the console.
 */
// Paths are relative to KuikaAppManager.GetBackendUrl(), which already ends in `/v1/api/`
// (the other system-function calls use `documentmanagement/...` the same way).
async function postToBackend<T>(path: string, body: object): Promise<T | undefined> {
  try {
    const response: IApiResponseLike | undefined = (await KuikaAppManager.ApiRequest(
      SILENT_SCREEN,
      path,
      body,
      "post"
    )) as IApiResponseLike | undefined;
    const status: number | undefined = response?.status;
    if (status === undefined || status < 200 || status >= 300 || response?.data === undefined) {
      const failure: IApiErrorLike | undefined = response as IApiErrorLike | undefined;
      console.error(
        `Amap geocoding backend call failed (${path}); falling back to the mainland-only JSAPI plugin.`,
        failure?.response?.status ?? status,
        failure?.response?.data ?? response?.data ?? failure?.message
      );
      return undefined;
    }
    return response.data as T;
  } catch (error) {
    console.error(
      `Amap geocoding backend call threw (${path}); falling back to the mainland-only JSAPI plugin.`,
      error
    );
    return undefined;
  }
}

/** A finite WGS-84 pair from a backend location, or null when absent or the (0, 0) "no match" marker. */
export function toBackendPoint(location: IBackendLocation | null | undefined): IGeoPoint | null {
  const point: IGeoPoint | null = toCoordinatePair(location?.lat, location?.lng);
  if (!point) return null;
  if (point.latitude === 0 && point.longitude === 0) return null;
  return point;
}

/**
 * Forward geocode. `undefined` = backend not enabled / unreachable (caller falls back to the
 * plugin), `null` = the backend answered "no match", otherwise the WGS-84 point.
 */
export async function geocodeAddressViaBackend(address: string): Promise<IGeoPoint | null | undefined> {
  const enabled: boolean = isAmapGeocodingBackendEnabled();
  if (!enabled) return undefined;
  const result: IBackendGeocodeResult | undefined = await postToBackend<IBackendGeocodeResult>("mapgeocoding/geocode", {
    address
  });
  if (result === undefined) return undefined;
  return toBackendPoint(result.location_info);
}

/** Reverse geocode; `undefined` when the backend is not enabled or did not answer. */
export async function reverseGeocodeViaBackend(
  latitude: number,
  longitude: number
): Promise<IBackendReverseGeocodeResult | undefined> {
  const enabled: boolean = isAmapGeocodingBackendEnabled();
  if (!enabled) return undefined;
  return postToBackend<IBackendReverseGeocodeResult>("mapgeocoding/reversegeocode", { latitude, longitude });
}

/** Keyword place search for LocationSearch suggestions; `undefined` when the backend did not answer. */
export async function searchPlacesViaBackend(query: string): Promise<IBackendPlace[] | undefined> {
  const enabled: boolean = isAmapGeocodingBackendEnabled();
  if (!enabled) return undefined;
  const result: IBackendSearchPlacesResult | undefined = await postToBackend<IBackendSearchPlacesResult>(
    "mapgeocoding/searchplaces",
    { query }
  );
  if (result === undefined) return undefined;
  return result.places ?? [];
}

function componentOfType(components: IBackendAddressComponent[], ...types: string[]): string | undefined {
  for (const type of types) {
    const match: IBackendAddressComponent | undefined = components.find(
      (component: IBackendAddressComponent): boolean => (component.types ?? []).includes(type)
    );
    if (match?.long_name) return match.long_name;
  }
  return undefined;
}

/**
 * Maps a backend reverse-geocode result onto the LocationAddressOfCoordinates shape. Same tier
 * assignment as the Amap JSAPI branch (city ← province tier, state ← city tier) so a screen bound
 * to either path sees the same fields.
 */
export function toLocationAddress(result: IBackendReverseGeocodeResult): ILocationAddressData {
  const components: IBackendAddressComponent[] = result.address_components ?? [];
  return {
    address: result.formatted_address || undefined,
    city: componentOfType(components, "administrative_area_level_1"),
    state: componentOfType(components, "locality", "administrative_area_level_2"),
    country: componentOfType(components, "country"),
    neighborhood: componentOfType(components, "sublocality_level_1", "sublocality", "administrative_area_level_4"),
    street: componentOfType(components, "route"),
    postalCode: componentOfType(components, "postal_code")
  };
}
