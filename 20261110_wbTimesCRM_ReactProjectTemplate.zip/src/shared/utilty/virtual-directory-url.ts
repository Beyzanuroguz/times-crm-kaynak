// ReactProjectGenerator.cs string-replaces this constant — do not refactor
// the literal or the trailing comment.
const VIRTUAL_DIRECTORY_URL: string = "auto"; // Use by code generation

export function getVirtualDirectoryUrl(): string {
  return VIRTUAL_DIRECTORY_URL;
}
