// Maps the app's culture to Amap's base-map / search language codes and builds the World Map
// option fragments the Amap components spread into their constructors.
//
// Amap's World Map (世界地图) and multilingual map (多语言地图) are one advanced entitlement on the
// key. When the project opted in (isAmapWorldMapEnabled) the map is created with `showOversea`
// (renders tiles outside mainland China) and `languageCode` (base-map labels), and
// AMap.PlaceSearch / AMap.AutoComplete get the same `languageCode` so results come back in the
// app's language where Amap has data for it. Without the entitlement none of these options are
// passed, so a mainland-only key behaves exactly as before.
import { isAmapWorldMapEnabled } from "./map-provider-config";

/** Base-map languages accepted by AMap.Map `languageCode` (JSAPI 2.0 多语言地图). */
export type AmapLanguageCode =
  | "zh"
  | "zh-Hant"
  | "en"
  | "es"
  | "pt"
  | "fr"
  | "de"
  | "th"
  | "ja"
  | "ko"
  | "ar"
  | "tr"
  | "it"
  | "ru"
  | "ms"
  | "id"
  | "vi";

/** Options merged into `new AMap.Map(container, {...})` for World Map projects. */
export interface IAmapWorldMapOptions {
  showOversea?: boolean;
  languageCode?: AmapLanguageCode;
  logoLanguage?: "zh" | "en";
}

/** Options merged into `new AMap.PlaceSearch({...})` / `new AMap.AutoComplete({...})`. */
export interface IAmapSearchLanguageOptions {
  languageCode?: AmapLanguageCode;
}

const NON_CHINESE_LANGUAGES: readonly AmapLanguageCode[] = [
  "en",
  "es",
  "pt",
  "fr",
  "de",
  "th",
  "ja",
  "ko",
  "ar",
  "tr",
  "it",
  "ru",
  "ms",
  "id",
  "vi"
];

const TRADITIONAL_CHINESE_REGIONS: readonly string[] = ["tw", "hk", "mo"];

/**
 * Resolves a Kuika culture ("tr_TR", "en-US", "zh_TW", "zh-Hant-HK", …) to Amap's language code.
 * Chinese resolves to Simplified unless the script is Hant or the region is TW/HK/MO; any
 * language Amap does not label in falls back to English rather than Amap's own Chinese default.
 */
export function toAmapLanguageCode(culture: string | null | undefined): AmapLanguageCode {
  if (!culture) return "en";

  const parts: string[] = culture.trim().toLowerCase().split(/[-_]/);
  const language: string = parts[0] ?? "";
  const rest: string[] = parts.slice(1);

  if (language === "zh") {
    const isTraditional: boolean = rest.some(
      (part: string): boolean => part === "hant" || TRADITIONAL_CHINESE_REGIONS.includes(part)
    );
    return isTraditional ? "zh-Hant" : "zh";
  }

  const match: AmapLanguageCode | undefined = NON_CHINESE_LANGUAGES.find(
    (code: AmapLanguageCode): boolean => code === language
  );
  return match ?? "en";
}

/**
 * The app's current culture: the "ml" key generated apps keep in localStorage (set at login from
 * the token and by the translation runtime from the project's default language), else the
 * browser language. Storage access is guarded — it throws in some embedded contexts.
 */
export function getAppCulture(): string | null {
  try {
    const stored: string | null = globalThis.localStorage?.getItem("ml") ?? null;
    if (stored) return stored;
  } catch {
    // Storage blocked: fall through to the browser language.
  }
  const browserLanguage: string | undefined = globalThis.navigator?.language;
  return browserLanguage ?? null;
}

/** Amap language code for the app's current culture. */
export function getAmapLanguageCode(): AmapLanguageCode {
  const culture: string | null = getAppCulture();
  return toAmapLanguageCode(culture);
}

/** `showOversea` + label language for World Map projects; empty for mainland-only keys. */
export function getAmapWorldMapOptions(): IAmapWorldMapOptions {
  const isWorldMap: boolean = isAmapWorldMapEnabled();
  if (!isWorldMap) return {};

  const languageCode: AmapLanguageCode = getAmapLanguageCode();
  const isChinese: boolean = languageCode === "zh" || languageCode === "zh-Hant";
  return {
    showOversea: true,
    languageCode,
    logoLanguage: isChinese ? "zh" : "en"
  };
}

/** Result language for the search plugins on World Map projects; empty for mainland-only keys. */
export function getAmapSearchLanguageOptions(): IAmapSearchLanguageOptions {
  const isWorldMap: boolean = isAmapWorldMapEnabled();
  if (!isWorldMap) return {};
  return { languageCode: getAmapLanguageCode() };
}
