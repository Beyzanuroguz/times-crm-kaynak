import moment from "moment";
import {
  dateSearchFormatFromFormatter,
  DEFAULT_DATE_SEARCH_FORMAT,
  DEFAULT_DATE_TIME_SEARCH_FORMAT,
  formatDateValueByFormatter,
  isDateFormatter,
  isMonthFirstDateFormat,
  parseDateValue,
  resolveDateSearchFormat,
  resolveLocaleDateFormat,
  toMomentDateFormat,
  toMomentTimeFormat
} from "./date-value-formatter";
import { ReactSystemFunctions } from "./react-system-functions";

// The workspace maps "moment" to a stub (src/__mocks__/moment.cjs) whose format() echoes the
// input. These tests assert real formatting output, so load the actual implementation — the
// explicit file path sidesteps the "^moment$" moduleNameMapper entry.
jest.mock("moment", () => jest.requireActual("moment/moment.js"));

jest.mock("./react-system-functions", () => ({
  ReactSystemFunctions: {
    getAppDateFormat: jest.fn((): string | null => null),
    getAppTimeFormat: jest.fn((): string | null => null)
  }
}));

const getAppDateFormatMock = ReactSystemFunctions.getAppDateFormat as jest.Mock;
const getAppTimeFormatMock = ReactSystemFunctions.getAppTimeFormat as jest.Mock;

// A local-time ISO string (no timezone suffix) keeps parsing and formatting in the same
// timezone on every machine, so assertions are stable across developer/CI timezones.
const SAMPLE_DATETIME = "2026-07-09T17:55:36";

describe("date-value-formatter", () => {
  beforeEach(() => {
    localStorage.removeItem("ml");
    getAppDateFormatMock.mockReturnValue(null);
    getAppTimeFormatMock.mockReturnValue(null);
  });

  afterEach(() => {
    moment.locale("en");
  });

  describe("isDateFormatter", () => {
    it("accepts every date-family formatter", () => {
      const dateFormatters: string[] = [
        "date",
        "datetime",
        "date-var-1",
        "time",
        "short-date",
        "time-ago",
        "custom date"
      ];
      dateFormatters.forEach((formatter: string) => {
        expect(isDateFormatter(formatter)).toBe(true);
      });
    });

    it("rejects non-date formatters and empty input", () => {
      expect(isDateFormatter("money")).toBe(false);
      expect(isDateFormatter("percent")).toBe(false);
      expect(isDateFormatter("fractional-2")).toBe(false);
      expect(isDateFormatter("")).toBe(false);
      expect(isDateFormatter(undefined)).toBe(false);
      expect(isDateFormatter(null)).toBe(false);
    });
  });

  describe("toMomentDateFormat / toMomentTimeFormat", () => {
    it("converts app format tokens to moment tokens", () => {
      expect(toMomentDateFormat("dd.mm.yyyy")).toBe("DD.MM.YYYY");
      expect(toMomentDateFormat("mm-dd-yyyy")).toBe("MM-DD-YYYY");
      expect(toMomentTimeFormat("hh:mm:ss")).toBe("HH:mm:ss");
      expect(toMomentTimeFormat("hh:mm a")).toBe("HH:mm A");
    });
  });

  describe("parseDateValue", () => {
    it("parses ISO datetime strings", () => {
      const date: moment.Moment | null = parseDateValue(SAMPLE_DATETIME);
      expect(date).not.toBeNull();
      expect(date?.format("YYYY-MM-DD HH:mm:ss")).toBe("2026-07-09 17:55:36");
    });

    it("parses 8/12/14-digit compact stamps", () => {
      expect(parseDateValue("20260709")?.format("YYYY-MM-DD")).toBe("2026-07-09");
      expect(parseDateValue("202607091755")?.format("YYYY-MM-DD HH:mm")).toBe("2026-07-09 17:55");
      expect(parseDateValue("20260709175536")?.format("YYYY-MM-DD HH:mm:ss")).toBe("2026-07-09 17:55:36");
      expect(parseDateValue(20260709)?.format("YYYY-MM-DD")).toBe("2026-07-09");
    });

    it("parses DD.MM.YYYY / DD/MM/YYYY strings with optional time", () => {
      expect(parseDateValue("09.07.2026")?.format("YYYY-MM-DD")).toBe("2026-07-09");
      expect(parseDateValue("09/07/2026 17:55:36")?.format("YYYY-MM-DD HH:mm:ss")).toBe("2026-07-09 17:55:36");
    });

    it("returns null for unparseable values", () => {
      expect(parseDateValue("not a date")).toBeNull();
      expect(parseDateValue(undefined)).toBeNull();
      expect(parseDateValue(null)).toBeNull();
    });
  });

  describe("formatDateValueByFormatter", () => {
    it("returns null for non-date formatters and empty values", () => {
      expect(formatDateValueByFormatter(SAMPLE_DATETIME, "money")).toBeNull();
      expect(formatDateValueByFormatter(SAMPLE_DATETIME, undefined)).toBeNull();
      expect(formatDateValueByFormatter(SAMPLE_DATETIME, null)).toBeNull();
      expect(formatDateValueByFormatter("", "date")).toBeNull();
      expect(formatDateValueByFormatter(undefined, "date")).toBeNull();
      expect(formatDateValueByFormatter(null, "date")).toBeNull();
    });

    it("returns null for unparseable values so callers fall back to the raw value", () => {
      expect(formatDateValueByFormatter("not a date", "date")).toBeNull();
    });

    it("formats with the formatter defaults when no user locale is set", () => {
      expect(formatDateValueByFormatter(SAMPLE_DATETIME, "date")).toBe("09/07/2026");
      expect(formatDateValueByFormatter(SAMPLE_DATETIME, "datetime")).toBe("09/07/2026 17:55:36");
      expect(formatDateValueByFormatter(SAMPLE_DATETIME, "time")).toBe("17:55:36");
      expect(formatDateValueByFormatter(SAMPLE_DATETIME, "date-var-1")).toBe("09:07:2026");
    });

    it("strips the time from a datetime value when the formatter is date-only", () => {
      const formatted: string | null = formatDateValueByFormatter(SAMPLE_DATETIME, "date");
      expect(formatted).not.toBeNull();
      expect(formatted).not.toContain("17");
      expect(formatted).not.toContain(":");
    });

    it("uses the locale's L pattern when a user locale is set and no app format exists", () => {
      localStorage.setItem("ml", "en_US");
      expect(formatDateValueByFormatter(SAMPLE_DATETIME, "date")).toBe("07/09/2026");

      localStorage.setItem("ml", "tr_TR");
      expect(formatDateValueByFormatter(SAMPLE_DATETIME, "date")).toBe("09.07.2026");
    });

    it("prefers the app-level Date/Time Format when configured", () => {
      localStorage.setItem("ml", "en_US");
      getAppDateFormatMock.mockReturnValue("dd-mm-yyyy");
      expect(formatDateValueByFormatter(SAMPLE_DATETIME, "date")).toBe("09-07-2026");

      getAppDateFormatMock.mockReturnValue("dd.mm.yyyy");
      getAppTimeFormatMock.mockReturnValue("hh:mm");
      expect(formatDateValueByFormatter(SAMPLE_DATETIME, "datetime")).toBe("09.07.2026 17:55");
    });

    it("ignores the app format when no user locale is set (Label parity)", () => {
      getAppDateFormatMock.mockReturnValue("dd-mm-yyyy");
      expect(formatDateValueByFormatter(SAMPLE_DATETIME, "date")).toBe("09/07/2026");
    });

    it("formats 'custom date' with the custom pattern and returns null without one", () => {
      expect(formatDateValueByFormatter(SAMPLE_DATETIME, "custom date", "YYYY-MM")).toBe("2026-07");
      expect(formatDateValueByFormatter(SAMPLE_DATETIME, "custom date")).toBeNull();
      expect(formatDateValueByFormatter(SAMPLE_DATETIME, "custom date", "")).toBeNull();
    });

    it("formats 'time-ago' relative to now", () => {
      const formatted: string | null = formatDateValueByFormatter("2020-01-01T00:00:00", "time-ago");
      expect(formatted).not.toBeNull();
      expect(formatted).toMatch(/ago$/);
    });

    it("formats 'short-date' per locale", () => {
      localStorage.setItem("ml", "en_US");
      expect(formatDateValueByFormatter(SAMPLE_DATETIME, "short-date")).toBe("Jul 9th");

      localStorage.setItem("ml", "tr_TR");
      expect(formatDateValueByFormatter(SAMPLE_DATETIME, "short-date")).toBe("9 Temmuz");
    });
  });
  describe("resolveLocaleDateFormat", () => {
    it("returns nothing when no user locale is known, so the picker keeps its ISO fallback", () => {
      expect(resolveLocaleDateFormat(false)).toBe("");
      expect(resolveLocaleDateFormat(true)).toBe("");
    });

    it("prefers the project's configured format over the locale", () => {
      localStorage.setItem("ml", "en_US");
      getAppDateFormatMock.mockReturnValue("dd.mm.yyyy");
      expect(resolveLocaleDateFormat(false)).toBe("DD.MM.YYYY");
    });

    it("falls back to the locale's own convention", () => {
      localStorage.setItem("ml", "en_US");
      expect(resolveLocaleDateFormat(false)).toBe("MM/DD/YYYY");
    });

    it("joins the configured date and time formats for datetime", () => {
      localStorage.setItem("ml", "tr_TR");
      getAppDateFormatMock.mockReturnValue("dd.mm.yyyy");
      getAppTimeFormatMock.mockReturnValue("hh:mm:ss");
      expect(resolveLocaleDateFormat(true)).toBe("DD.MM.YYYY HH:mm:ss");
    });
  });

  describe("resolveDateSearchFormat", () => {
    it("returns the column's own format untouched", () => {
      expect(resolveDateSearchFormat("MM/DD/YYYY", false)).toBe("MM/DD/YYYY");
      getAppDateFormatMock.mockReturnValue("dd.mm.yyyy");
      expect(resolveDateSearchFormat("MM/DD/YYYY", false)).toBe("MM/DD/YYYY");
    });

    it("uses the project's date format even when no locale is known", () => {
      getAppDateFormatMock.mockReturnValue("mm/dd/yyyy");
      expect(resolveDateSearchFormat(undefined, false)).toBe("MM/DD/YYYY");
    });

    it("appends the project's time format for a datetime search", () => {
      getAppDateFormatMock.mockReturnValue("dd/mm/yyyy");
      getAppTimeFormatMock.mockReturnValue("hh:mm:ss");
      expect(resolveDateSearchFormat(undefined, true)).toBe("DD/MM/YYYY HH:mm:ss");
    });

    it("appends a default time part when only the date format is configured", () => {
      getAppDateFormatMock.mockReturnValue("dd/mm/yyyy");
      expect(resolveDateSearchFormat(undefined, true)).toBe("DD/MM/YYYY HH:mm:ss");
    });

    it("falls back to the locale convention when the project configures nothing", () => {
      localStorage.setItem("ml", "en_US");
      expect(resolveDateSearchFormat(undefined, false)).toBe("MM/DD/YYYY");
    });

    it("always answers with an unambiguous format when nothing at all is known", () => {
      expect(resolveDateSearchFormat(undefined, false)).toBe(DEFAULT_DATE_SEARCH_FORMAT);
      expect(resolveDateSearchFormat("", true)).toBe(DEFAULT_DATE_TIME_SEARCH_FORMAT);
    });
  });

  describe("dateSearchFormatFromFormatter", () => {
    it("takes a custom date pattern as it is", () => {
      expect(dateSearchFormatFromFormatter("custom date", "DD.MM.YYYY")).toBe("DD.MM.YYYY");
      expect(dateSearchFormatFromFormatter("custom date", "MM/DD/YYYY")).toBe("MM/DD/YYYY");
      expect(dateSearchFormatFromFormatter("custom date", "YYYY-MM-DD")).toBe("YYYY-MM-DD");
      expect(dateSearchFormatFromFormatter("custom date", "D.M.YY")).toBe("D.M.YY");
    });

    it("keeps only the date part of a pattern that also shows the time or a weekday", () => {
      expect(dateSearchFormatFromFormatter("custom date", "DD.MM.YYYY HH:mm")).toBe("DD.MM.YYYY");
      expect(dateSearchFormatFromFormatter("custom date", "HH:mm:ss DD/MM/YYYY")).toBe("DD/MM/YYYY");
      expect(dateSearchFormatFromFormatter("custom date", "YYYY-MM-DDTHH:mm")).toBe("YYYY-MM-DD");
      expect(dateSearchFormatFromFormatter("custom date", "dddd DD.MM.YYYY")).toBe("DD.MM.YYYY");
      expect(dateSearchFormatFromFormatter("custom date", "[Tarih:] DD.MM.YYYY")).toBe("DD.MM.YYYY");
    });

    it("gives nothing for a pattern a search box cannot write and read back unambiguously", () => {
      expect(dateSearchFormatFromFormatter("custom date", "MMMM Do YYYY")).toBe("");
      expect(dateSearchFormatFromFormatter("custom date", "DD MMMM YYYY")).toBe("");
      expect(dateSearchFormatFromFormatter("custom date", "MMM DD, YYYY")).toBe("");
      expect(dateSearchFormatFromFormatter("custom date", "DD:MM:YYYY")).toBe("");
      expect(dateSearchFormatFromFormatter("custom date", "MM/YYYY")).toBe("");
      expect(dateSearchFormatFromFormatter("custom date", "DD.MM HH:mm YYYY")).toBe("");
      expect(dateSearchFormatFromFormatter("custom date", "DD [de] MM YYYY")).toBe("");
    });

    it("gives nothing for the built-in formatters, which already follow the project and language", () => {
      expect(dateSearchFormatFromFormatter("date", undefined)).toBe("");
      expect(dateSearchFormatFromFormatter("datetime", undefined)).toBe("");
      expect(dateSearchFormatFromFormatter("date-var-1", undefined)).toBe("");
      expect(dateSearchFormatFromFormatter("custom date", "")).toBe("");
      expect(dateSearchFormatFromFormatter(undefined, "DD.MM.YYYY")).toBe("");
    });
  });

  describe("isMonthFirstDateFormat", () => {
    it("recognises a month-first format", () => {
      expect(isMonthFirstDateFormat("MM/DD/YYYY")).toBe(true);
      expect(isMonthFirstDateFormat("M/DD/YYYY HH:mm")).toBe(true);
    });

    it("recognises a day-first format", () => {
      expect(isMonthFirstDateFormat("DD/MM/YYYY")).toBe(false);
      expect(isMonthFirstDateFormat("DD.MM.YYYY HH:mm:ss")).toBe(false);
    });

    it("answers false when the format is missing a day or a month", () => {
      expect(isMonthFirstDateFormat("YYYY")).toBe(false);
      expect(isMonthFirstDateFormat("HH:mm:ss")).toBe(false);
      expect(isMonthFirstDateFormat(undefined)).toBe(false);
      expect(isMonthFirstDateFormat("")).toBe(false);
    });
  });
});
