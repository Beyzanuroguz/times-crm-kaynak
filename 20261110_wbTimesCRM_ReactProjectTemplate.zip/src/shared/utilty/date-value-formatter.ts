import moment from "moment";
import { ReactSystemFunctions } from "./react-system-functions";

// Single source of truth for the date-family display formatters ("date", "datetime", ...).
// Both the Label component (on-screen rendering) and the table Excel export use these
// helpers so an exported cell always matches what the user sees in the table (KOA-17951).

export type DateFormatterName = "datetime" | "date" | "date-var-1" | "time" | "short-date" | "time-ago" | "custom date";

const DATE_FORMATTER_FORMAT_STRINGS: Record<DateFormatterName, string> = {
  datetime: "DD/MM/YYYY HH:mm:ss",
  date: "DD/MM/YYYY",
  "date-var-1": "DD:MM:YYYY",
  time: "HH:mm:ss",
  "short-date": "MMM Do",
  "time-ago": "DD/MM/YYYY HH:mm:ss",
  "custom date": ""
};

const RE_8_DIGITS: RegExp = /^\d{8}$/;
const RE_12_DIGITS: RegExp = /^\d{12}$/;
const RE_14_DIGITS: RegExp = /^\d{14}$/;
const RE_DATE_PREFIX: RegExp = /^\d{2}[./]\d{2}[./]\d{4}/;
const RE_DATE_HM: RegExp = /^\d{2}[./]\d{2}[./]\d{4} \d{2}:\d{2}/;
const RE_DATE_HMS: RegExp = /^\d{2}[./]\d{2}[./]\d{4} \d{2}:\d{2}:\d{2}/;
const RE_DATE_SEP: RegExp = /[./]/g;
const RE_DD: RegExp = /dd/g;
const RE_MM_LOWER: RegExp = /mm/g;
const RE_YYYY: RegExp = /yyyy/g;
const RE_HH: RegExp = /hh/g;
const RE_SS: RegExp = /ss/g;
const RE_A: RegExp = /a/g;

export function isDateFormatter(formatter: string | undefined | null): formatter is DateFormatterName {
  if (!formatter) {
    return false;
  }
  return Object.prototype.hasOwnProperty.call(DATE_FORMATTER_FORMAT_STRINGS, formatter);
}

// Converts the app-level date/time format (e.g. "dd.mm.yyyy" / "hh:mm:ss a") to a moment format string.
export function toMomentDateFormat(appDateFormat: string): string {
  return appDateFormat.replace(RE_DD, "DD").replace(RE_MM_LOWER, "MM").replace(RE_YYYY, "YYYY");
}

export function toMomentTimeFormat(appTimeFormat: string): string {
  return appTimeFormat.replace(RE_HH, "HH").replace(RE_MM_LOWER, "mm").replace(RE_SS, "ss").replace(RE_A, "A");
}

function getUserLocale(): string {
  const mlValue: string = localStorage.getItem("ml") || "";
  return mlValue ? mlValue.split("_")[0] : "";
}

export const DEFAULT_DATE_SEARCH_FORMAT: string = "DD.MM.YYYY";
export const DEFAULT_DATE_TIME_SEARCH_FORMAT: string = "DD.MM.YYYY HH:mm:ss";

export function resolveLocaleDateFormat(isDateTime: boolean): string {
  const userLocale: string = getUserLocale();
  if (!userLocale) {
    return "";
  }

  const appDateFormat: string | null = ReactSystemFunctions.getAppDateFormat();
  const appTimeFormat: string | null = ReactSystemFunctions.getAppTimeFormat();

  if (isDateTime) {
    if (appDateFormat && appTimeFormat) {
      return `${toMomentDateFormat(appDateFormat)} ${toMomentTimeFormat(appTimeFormat)}`;
    }
    return `${moment.localeData(userLocale).longDateFormat("L")} ${moment.localeData(userLocale).longDateFormat("LT")}`;
  }

  if (appDateFormat) {
    return toMomentDateFormat(appDateFormat);
  }
  return moment.localeData(userLocale).longDateFormat("L");
}

export function resolveDateSearchFormat(explicitFormat: string | undefined | null, isDateTime: boolean): string {
  if (explicitFormat) {
    return explicitFormat;
  }

  const appDateFormat: string | null = ReactSystemFunctions.getAppDateFormat();
  if (appDateFormat) {
    const datePart: string = toMomentDateFormat(appDateFormat);
    if (!isDateTime) {
      return datePart;
    }
    const appTimeFormat: string | null = ReactSystemFunctions.getAppTimeFormat();
    if (appTimeFormat) {
      return `${datePart} ${toMomentTimeFormat(appTimeFormat)}`;
    }
    return `${datePart} HH:mm:ss`;
  }

  const localeFormat: string = resolveLocaleDateFormat(isDateTime);
  if (localeFormat) {
    return localeFormat;
  }

  if (isDateTime) {
    return DEFAULT_DATE_TIME_SEARCH_FORMAT;
  }
  return DEFAULT_DATE_SEARCH_FORMAT;
}

export function isMonthFirstDateFormat(format: string | undefined | null): boolean {
  if (!format) {
    return false;
  }
  const monthIndex: number = format.indexOf("M");
  const dayIndex: number = format.indexOf("D");
  if (monthIndex < 0 || dayIndex < 0) {
    return false;
  }
  return monthIndex < dayIndex;
}

// A moment pattern split into tokens: a bracketed literal, a run of one letter ("DD", "YYYY",
// "HH") or any single other character.
const RE_PATTERN_TOKEN: RegExp = /\[[^\]]*\]|([A-Za-z])\1*|[^A-Za-z]/g;
const RE_SEARCHABLE_SEPARATOR: RegExp = /^[./\- ]$/;
const SEARCHABLE_DAY_TOKENS: ReadonlySet<string> = new Set<string>(["D", "DD"]);
const SEARCHABLE_MONTH_TOKENS: ReadonlySet<string> = new Set<string>(["M", "MM"]);
const SEARCHABLE_YEAR_TOKENS: ReadonlySet<string> = new Set<string>(["YY", "YYYY"]);

function isSearchableDateToken(token: string): boolean {
  return SEARCHABLE_DAY_TOKENS.has(token) || SEARCHABLE_MONTH_TOKENS.has(token) || SEARCHABLE_YEAR_TOKENS.has(token);
}

// The date search format a table column takes from the Label that draws its cells, for a
// column without a "DateSearchFormat" of its own — so the filter boxes write a date the way the
// cell shows it (KOA-18397). Only a "custom date" pattern can disagree with the search box:
// "date"/"datetime" Labels already follow the project's Date Format and then the language, the
// chain resolveDateSearchFormat falls back to. Returns the pattern's day-month-year part, with a
// time or weekday around it dropped, or "" when that part is incomplete or holds anything a
// search box cannot write and read back unambiguously: month or weekday names, ordinals,
// literals, ":".
export function dateSearchFormatFromFormatter(
  formatter: string | undefined | null,
  customFormatter: string | undefined | null
): string {
  if (formatter !== "custom date" || !customFormatter) {
    return "";
  }

  const tokens: string[] = customFormatter.match(RE_PATTERN_TOKEN) ?? [];
  const first: number = tokens.findIndex(isSearchableDateToken);
  if (first < 0) {
    return "";
  }
  const last: number = tokens.reduce(
    (found: number, token: string, index: number): number => (isSearchableDateToken(token) ? index : found),
    first
  );
  const datePart: string[] = tokens.slice(first, last + 1);

  const isSearchable: boolean = datePart.every(
    (token: string): boolean => isSearchableDateToken(token) || RE_SEARCHABLE_SEPARATOR.test(token)
  );
  const hasDay: boolean = datePart.some((token: string): boolean => SEARCHABLE_DAY_TOKENS.has(token));
  const hasMonth: boolean = datePart.some((token: string): boolean => SEARCHABLE_MONTH_TOKENS.has(token));
  const hasYear: boolean = datePart.some((token: string): boolean => SEARCHABLE_YEAR_TOKENS.has(token));
  if (!isSearchable || !hasDay || !hasMonth || !hasYear) {
    return "";
  }
  return datePart.join("");
}

// Parses the value shapes the Label component accepts: 8/12/14-digit compact stamps
// ("20260709", "202607091755", "20260709175536"), "DD.MM.YYYY[ HH:mm[:ss]]" strings
// (also with "/" separators), numbers, Date objects and anything `new Date` can handle.
// Returns null when the value cannot be parsed into a valid moment.
export function parseDateValue(value: unknown): moment.Moment | null {
  if (value === null || value === undefined || value === "") {
    return null;
  }
  try {
    let date: moment.Moment;

    if (typeof value === "string" && RE_8_DIGITS.test(value)) {
      const year: string = value.substring(0, 4);
      const month: string = value.substring(4, 6);
      const day: string = value.substring(6, 8);
      date = moment(`${year}-${month}-${day}`);
    } else if (typeof value === "string" && RE_12_DIGITS.test(value)) {
      const year: string = value.substring(0, 4);
      const month: string = value.substring(4, 6);
      const day: string = value.substring(6, 8);
      const hour: string = value.substring(8, 10);
      const minute: string = value.substring(10, 12);
      date = moment(`${year}-${month}-${day}T${hour}:${minute}`);
    } else if (typeof value === "string" && RE_14_DIGITS.test(value)) {
      const year: string = value.substring(0, 4);
      const month: string = value.substring(4, 6);
      const day: string = value.substring(6, 8);
      const hour: string = value.substring(8, 10);
      const minute: string = value.substring(10, 12);
      const second: string = value.substring(12, 14);
      date = moment(`${year}-${month}-${day}T${hour}:${minute}:${second}`);
    } else if (
      typeof value === "string" &&
      (RE_DATE_PREFIX.test(value) || RE_DATE_HM.test(value) || RE_DATE_HMS.test(value))
    ) {
      const [datePart, timePart] = value.split(" ");
      const normalizedDatePart: string = datePart.replace(RE_DATE_SEP, "-");
      const [day, month, year] = normalizedDatePart.split("-");
      let isoDate: string = `${year}-${month}-${day}`;
      if (timePart) {
        isoDate += `T${timePart}`;
      }
      date = moment(isoDate);
    } else if (typeof value === "number") {
      const numericString: string = String(value);
      if (RE_8_DIGITS.test(numericString)) {
        const year: string = numericString.substring(0, 4);
        const month: string = numericString.substring(4, 6);
        const day: string = numericString.substring(6, 8);
        date = moment(`${year}-${month}-${day}`);
      } else if (RE_12_DIGITS.test(numericString)) {
        const year: string = numericString.substring(0, 4);
        const month: string = numericString.substring(4, 6);
        const day: string = numericString.substring(6, 8);
        const hour: string = numericString.substring(8, 10);
        const minute: string = numericString.substring(10, 12);
        date = moment(`${year}-${month}-${day}T${hour}:${minute}`);
      } else if (RE_14_DIGITS.test(numericString)) {
        const year: string = numericString.substring(0, 4);
        const month: string = numericString.substring(4, 6);
        const day: string = numericString.substring(6, 8);
        const hour: string = numericString.substring(8, 10);
        const minute: string = numericString.substring(10, 12);
        const second: string = numericString.substring(12, 14);
        date = moment(`${year}-${month}-${day}T${hour}:${minute}:${second}`);
      } else {
        date = moment(new Date(value));
      }
    } else {
      date = moment(new Date(value as string | number | Date));
    }

    if (!date.isValid()) {
      return null;
    }
    return date;
  } catch {
    return null;
  }
}

// The project-level Date/Time Format settings (when configured) win over the formatter's
// default pattern for "datetime" | "date" | "time" | "short-date" — but only when a user
// locale is known. Returns null when no override applies and the caller should fall back
// to the formatter's default format string.
export function formatDateWithAppOverrides(date: moment.Moment, formatter: string | undefined): string | null {
  const userLocale: string = getUserLocale();

  if (
    !userLocale ||
    (formatter !== "datetime" && formatter !== "date" && formatter !== "time" && formatter !== "short-date")
  ) {
    return null;
  }

  const appDateFormat: string | null = ReactSystemFunctions.getAppDateFormat();
  const appTimeFormat: string | null = ReactSystemFunctions.getAppTimeFormat();

  if (formatter === "datetime") {
    if (appDateFormat && appTimeFormat) {
      return date.format(`${toMomentDateFormat(appDateFormat)} ${toMomentTimeFormat(appTimeFormat)}`);
    }
    return date.format(`${moment.localeData(userLocale).longDateFormat("L")} HH:mm:ss`);
  }
  if (formatter === "date") {
    if (appDateFormat) {
      return date.format(toMomentDateFormat(appDateFormat));
    }
    return date.format(moment.localeData(userLocale).longDateFormat("L"));
  }
  if (formatter === "time") {
    if (appTimeFormat) {
      return date.format(toMomentTimeFormat(appTimeFormat));
    }
    return date.format("HH:mm:ss");
  }
  // short-date
  moment.locale(userLocale);
  if (userLocale.toLowerCase().startsWith("tr")) {
    return date.locale(userLocale).format("D MMMM");
  }
  return date.locale(userLocale).format("MMM Do");
}

// Formats `value` exactly the way a Label with the given date-family formatter renders it.
// Returns null when the formatter is not date-family, the value is empty/unparseable, or a
// "custom date" formatter has no pattern — callers must fall back to their raw value.
export function formatDateValueByFormatter(
  value: unknown,
  formatter: string | undefined | null,
  customFormatter?: string
): string | null {
  if (!isDateFormatter(formatter)) {
    return null;
  }
  if (!value || value.toString().trim() === "") {
    return null;
  }
  if (formatter === "custom date" && (!customFormatter || customFormatter === "")) {
    return null;
  }

  try {
    const date: moment.Moment | null = parseDateValue(value);
    if (!date) {
      return null;
    }

    const overridden: string | null = formatDateWithAppOverrides(date, formatter);
    if (overridden !== null) {
      return overridden;
    }

    let result: string;
    if (formatter === "time-ago") {
      result = date.fromNow();
    } else {
      const formatStr: string =
        formatter === "custom date" ? (customFormatter as string) : DATE_FORMATTER_FORMAT_STRINGS[formatter];
      result = date.format(formatStr);
    }

    if (result.indexOf("Invalid") > -1) {
      return null;
    }
    return result;
  } catch {
    return null;
  }
}
