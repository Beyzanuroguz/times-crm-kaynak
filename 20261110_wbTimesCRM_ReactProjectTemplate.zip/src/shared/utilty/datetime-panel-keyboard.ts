/**
 * In-panel keyboard navigation for the antd DatePicker (showTime) dropdown — KOA-14173.
 *
 * antd/rc-picker 2.5.19 renders the open Date & Time panel with no keyboard reachable
 * time columns (they are plain <ul>s) and no visible focus movement between the date
 * grid, the hour/minute/second columns and the OK button. This helper fills that gap:
 * the picker component keeps real DOM focus on its text input (so rc-picker keeps
 * routing key events to it) and drives a *visible highlight* through the panel's
 * selection areas here, imperatively, on the portal-rendered dropdown.
 *
 * All lookups are defensive: the dropdown is a body portal, only one is open at a
 * time, and every query tolerates a missing/rebuilt DOM by returning empty/false.
 */

const OPEN_DROPDOWN = ".ant-picker-dropdown:not(.ant-picker-dropdown-hidden)";
const DATE_PANEL = ".ant-picker-date-panel";
const TIME_COLUMN = ".ant-picker-time-panel-column";
const OK_BUTTON = ".ant-picker-ok button";
const TIME_CELL = ".ant-picker-time-panel-cell-inner";
const IN_VIEW_DATE_CELL = ".ant-picker-date-panel .ant-picker-cell-in-view";
const DATE_CELL_INNER = ".ant-picker-cell-inner";
const SELECTED_TIME_CELL_CLASS = "ant-picker-time-panel-cell-selected";
const SELECTED_DATE_CELL_CLASS = "ant-picker-cell-selected";
const HIGHLIGHT_CLASS = "kuika-datetime-panel-focus";
const STYLE_ELEMENT_ID = "kuika-datetime-panel-focus-style";
const DATE_GRID_COLUMNS = 7;

export type PanelArrowKey = "up" | "down" | "left" | "right";

interface PanelStop {
  el: HTMLElement;
  kind: "date" | "time" | "ok";
}

const getOpenDropdown = (): HTMLElement | null => {
  if (typeof document === "undefined") {
    return null;
  }
  return document.querySelector<HTMLElement>(OPEN_DROPDOWN);
};

const getStops = (): PanelStop[] => {
  const dropdown: HTMLElement | null = getOpenDropdown();
  if (!dropdown) {
    return [];
  }
  const stops: PanelStop[] = [];
  const datePanel: HTMLElement | null = dropdown.querySelector<HTMLElement>(DATE_PANEL);
  if (datePanel) {
    stops.push({ el: datePanel, kind: "date" });
  }
  dropdown.querySelectorAll<HTMLElement>(TIME_COLUMN).forEach((column: HTMLElement): void => {
    stops.push({ el: column, kind: "time" });
  });
  const okButton: HTMLElement | null = dropdown.querySelector<HTMLElement>(OK_BUTTON);
  if (okButton) {
    stops.push({ el: okButton, kind: "ok" });
  }
  return stops;
};

/** Number of navigable stops in the currently open panel (0 when nothing is open). */
export const getPanelStopCount = (): number => getStops().length;

const ensureStyle = (): void => {
  if (typeof document === "undefined" || document.getElementById(STYLE_ELEMENT_ID)) {
    return;
  }
  const style: HTMLStyleElement = document.createElement("style");
  style.id = STYLE_ELEMENT_ID;
  style.textContent =
    `.${HIGHLIGHT_CLASS}{outline:2px solid #1677ff;outline-offset:-2px;border-radius:6px;}` +
    `.ant-picker-time-panel-column.${HIGHLIGHT_CLASS} .ant-picker-time-panel-cell-selected ` +
    `.ant-picker-time-panel-cell-inner{background:rgba(22,119,255,0.12);}`;
  document.head.appendChild(style);
};

/** Outline the stop at `index`; a negative/out-of-range index clears all highlights. */
export const highlightPanelStop = (index: number): void => {
  ensureStyle();
  const stops: PanelStop[] = getStops();
  stops.forEach((stop: PanelStop, i: number): void => {
    stop.el.classList.toggle(HIGHLIGHT_CLASS, i === index);
  });
};

export const clearPanelHighlight = (): void => {
  getStops().forEach((stop: PanelStop): void => stop.el.classList.remove(HIGHLIGHT_CLASS));
};

const selectCell = (
  cells: HTMLElement[],
  selectedIndex: number,
  targetIndex: number,
  stopIndexToKeep: number
): boolean => {
  const clamped: number = Math.max(0, Math.min(cells.length - 1, targetIndex));
  if (clamped === selectedIndex) {
    return true;
  }
  cells[clamped].click();
  // Re-apply the highlight because clicking a cell can re-render the panel body.
  highlightPanelStop(stopIndexToKeep);
  return true;
};

const dateDelta = (key: PanelArrowKey): number => {
  if (key === "left") {
    return -1;
  }
  if (key === "right") {
    return 1;
  }
  if (key === "up") {
    return -DATE_GRID_COLUMNS;
  }
  return DATE_GRID_COLUMNS;
};

/**
 * Move the selection within the highlighted stop using an arrow key.
 * Time columns respond to up/down; the date grid to all four arrows.
 * Returns false when the stop cannot handle the key (caller leaves it to antd).
 */
export const navigatePanelStop = (index: number, key: PanelArrowKey): boolean => {
  const stops: PanelStop[] = getStops();
  const stop: PanelStop | undefined = stops[index];
  if (!stop) {
    return false;
  }

  if (stop.kind === "time") {
    if (key !== "up" && key !== "down") {
      return false;
    }
    const cells: HTMLElement[] = Array.from(stop.el.querySelectorAll<HTMLElement>(TIME_CELL));
    if (cells.length === 0) {
      return false;
    }
    const selectedIndex: number = cells.findIndex(
      (cell: HTMLElement): boolean => cell.parentElement?.classList.contains(SELECTED_TIME_CELL_CLASS) ?? false
    );
    const base: number = selectedIndex === -1 ? 0 : selectedIndex;
    return selectCell(cells, selectedIndex, base + (key === "down" ? 1 : -1), index);
  }

  if (stop.kind === "date") {
    const dropdown: HTMLElement | null = getOpenDropdown();
    if (!dropdown) {
      return false;
    }
    const cells: HTMLElement[] = Array.from(dropdown.querySelectorAll<HTMLElement>(IN_VIEW_DATE_CELL))
      .map((cell: HTMLElement): HTMLElement | null => cell.querySelector<HTMLElement>(DATE_CELL_INNER))
      .filter((inner: HTMLElement | null): inner is HTMLElement => inner !== null);
    if (cells.length === 0) {
      return false;
    }
    const selectedIndex: number = cells.findIndex(
      (cell: HTMLElement): boolean => cell.parentElement?.classList.contains(SELECTED_DATE_CELL_CLASS) ?? false
    );
    const base: number = selectedIndex === -1 ? 0 : selectedIndex;
    return selectCell(cells, selectedIndex, base + dateDelta(key), index);
  }

  return false;
};

/** Confirm the open panel by clicking its OK button, if one is present. */
export const confirmOpenPanel = (): boolean => {
  const dropdown: HTMLElement | null = getOpenDropdown();
  if (!dropdown) {
    return false;
  }
  const okButton: HTMLElement | null = dropdown.querySelector<HTMLElement>(OK_BUTTON);
  if (!okButton) {
    return false;
  }
  okButton.click();
  return true;
};
