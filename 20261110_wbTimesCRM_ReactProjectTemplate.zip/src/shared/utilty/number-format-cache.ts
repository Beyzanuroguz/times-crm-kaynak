const cache = new Map<string, Intl.NumberFormat>();

export function getCachedNumberFormat(locale: string, options: Intl.NumberFormatOptions): Intl.NumberFormat {
  const key = `${locale}|${options.currency}|${options.minimumFractionDigits}|${options.maximumFractionDigits}`;
  let fmt = cache.get(key);
  if (!fmt) {
    fmt = new Intl.NumberFormat(locale, options);
    cache.set(key, fmt);
  }
  return fmt;
}
