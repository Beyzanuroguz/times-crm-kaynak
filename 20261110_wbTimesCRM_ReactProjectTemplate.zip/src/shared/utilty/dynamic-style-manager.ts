import fastdom from "fastdom";

class DynamicStyleManager {
  public key: string;

  private style: WeakRef<HTMLStyleElement> | null = null;

  private static finalizationRegistry = new FinalizationRegistry((key: string) => {
    fastdom.mutate(() => {
      const styleElement = document?.getElementById(`style_${key}`);
      if (styleElement) {
        document.head.removeChild(styleElement);
      }
    });
  });

  constructor(key: string) {
    this.key = key;
    this.style = null;
    DynamicStyleManager.finalizationRegistry.register(this, key);
  }

  private getStyleSync(): HTMLStyleElement | null {
    return this.style?.deref() || null;
  }

  private ensureStyleExists(): Promise<HTMLStyleElement> {
    return new Promise((resolve) => {
      const existingStyle = this.getStyleSync();
      if (existingStyle) {
        resolve(existingStyle);
        return;
      }

      fastdom.mutate(() => {
        // Double-check in case another operation created it
        let style = this.getStyleSync();
        if (!style) {
          style = document.createElement("style");
          style.id = `style_${this.key}`;
          document.head.appendChild(style);
          this.style = new WeakRef(style);
        }
        resolve(style);
      });
    });
  }

  async removeStyle(): Promise<void> {
    const style = this.getStyleSync();
    if (style) {
      await fastdom.mutate(() => {
        if (style.parentNode) {
          document.head.removeChild(style);
        }
        this.style = null;
      });
    }
  }

  async setDynamicCss(css: string): Promise<void> {
    const style = await this.ensureStyleExists();
    await fastdom.mutate(() => {
      // Security: use textContent instead of innerHTML to prevent XSS via CSS injection
      style.textContent = css;
    });
  }
}

export default DynamicStyleManager;
