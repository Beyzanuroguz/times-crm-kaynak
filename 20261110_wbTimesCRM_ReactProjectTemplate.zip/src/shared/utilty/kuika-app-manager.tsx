import type { FormInstance } from "antd/es/form";
import Axios, { AxiosRequestConfig, AxiosResponse } from "axios";
import { getApiHostKey, readLoginStateCookie } from "../../auth/cookie-utils";
import { IValidationData } from "../../models/dto/validation-data";
import {
  getLocalhostProtocol,
  isCustomProtocol,
  transformUrlForElectron
} from "../../services/electron-bridge-service";
import confJson from "../json/conf.json";
import { getFrontEndUrl, KuikaEnvConfig } from "./frontend-url";
import { KuikaHelper } from "./kuika-react-helper";
import { KMainFunctions } from "./main-functions";
import { findOwnMfeAppEntry, getOwnEnvConfig, KuikaMfeAppEntry } from "./own-app-env";

declare let window: any;

interface IElementScrollOffset {
  el: HTMLElement;
  top: number;
  left: number;
}

interface IMfeScrollSnapshot {
  windowX: number;
  windowY: number;
  elements: IElementScrollOffset[];
}

interface IBodyScrollChain {
  elements: HTMLElement[];
  offset: number;
}

export class KuikaAppManager {
  private static bodyHeightTimerIds = new Map<string, ReturnType<typeof setTimeout>>();
  private static lastMfeBodyMinHeights = new WeakMap<HTMLElement, string>();
  private static mfeSlotResizeObservers = new WeakMap<HTMLElement, ResizeObserver>();

  // Nearest scrollable ancestor of the embedded MFE wrapper, if any. This is
  // only a refinement: when the host screen owns its scroll (e.g. a master-less
  // host screen whose body is `overflow:auto`) that element's clientHeight is
  // the exact slot. It returns null for host topologies that have no scroll
  // container between the wrapper and <body> — most notably a host screen bound
  // to a MASTER layout, where the body lives inside masterRootDI and never gets
  // overflow:auto. That null is exactly the KOA-17247 QA-repro case the
  // viewport-relative fallback below handles.
  private static findMfeScrollableAncestor(mfeWrapper: HTMLElement): HTMLElement | null {
    let cur: HTMLElement | null = mfeWrapper.parentElement;
    while (cur && cur !== document.body) {
      const cs: CSSStyleDeclaration = window.getComputedStyle(cur);
      if (cs.overflowY === "auto" || cs.overflowY === "scroll") {
        return cur;
      }
      cur = cur.parentElement;
    }
    return null;
  }

  // Pixel height of the host slot available to the embedded microapp.
  //
  // Prefers a scrollable host ancestor's clientHeight (the exact slot when the
  // host owns the scroll). Otherwise — the master-layout host case, where no
  // such ancestor exists — it falls back to the viewport height BELOW the
  // microapp's top edge: `innerHeight - wrapperTop`. wrapperTop already sits
  // past the host header and any chrome rendered above the microapp, so this is
  // the real remaining space the host gave the microapp. It deliberately never
  // returns a value measured from the document top (i.e. a 100vh-equivalent),
  // which is what made the inner app over-size itself to the full viewport and
  // produced the duplicate scrollbar + bottom cut-off.
  //
  // Returns null only when nothing measurable exists (defensive; callers then
  // keep their viewport-based formula).
  private static measureMfeSlotHeight(mfeWrapper: HTMLElement): number | null {
    const scrollable: HTMLElement | null = KuikaAppManager.findMfeScrollableAncestor(mfeWrapper);
    if (scrollable && scrollable.clientHeight > 0) {
      return scrollable.clientHeight;
    }
    const wrapperTop: number = mfeWrapper.getBoundingClientRect().top;
    const available: number = window.innerHeight - wrapperTop;
    return available > 0 ? available : null;
  }

  // Element whose resize should re-trigger a measure: the scrollable host
  // ancestor when present, else document.body (covers window resize and host
  // relayout for the viewport-relative path).
  private static getMfeResizeObserveTarget(mfeWrapper: HTMLElement): HTMLElement {
    return KuikaAppManager.findMfeScrollableAncestor(mfeWrapper) ?? document.body;
  }

  private static applyMfeSlotHeight(
    target: HTMLElement,
    mfeWrapper: HTMLElement,
    computeOffset: () => number,
    alsoSetMinHeight: boolean = false
  ): void {
    const apply = (): void => {
      const offset: number = computeOffset();
      const slotHeight: number | null = KuikaAppManager.measureMfeSlotHeight(mfeWrapper);
      // Pathological only: wrapper measured fully off-screen AND no scrollable
      // ancestor. Preserve the pre-fix viewport-based sizing rather than leaving
      // the element unsized — keeps this change strictly no-worse than before.
      const value: string = slotHeight === null ? `calc(100vh - ${offset}px)` : `${Math.max(slotHeight - offset, 0)}px`;
      target.style.height = value;
      target.style.maxHeight = value;
      if (alsoSetMinHeight) {
        target.style.minHeight = value;
      }
    };
    apply();
    const existing: ResizeObserver | undefined = KuikaAppManager.mfeSlotResizeObservers.get(target);
    if (existing) {
      existing.disconnect();
    }
    const observer: ResizeObserver = new ResizeObserver(apply);
    observer.observe(KuikaAppManager.getMfeResizeObserveTarget(mfeWrapper));
    KuikaAppManager.mfeSlotResizeObservers.set(target, observer);
  }

  // A side layout (left/right) normally scrolls vertically when its menu is taller than
  // the viewport, so we give it overflow-y:auto. But when the layout hosts a hamburger
  // menu that is currently collapsed, its toggle is an absolutely-positioned icon that
  // floats OUTSIDE this box. overflow-y:auto forces overflow-x to clip (CSS spec), so if
  // the layout has shrunk to ~0px width (e.g. a column with 0 left/right padding) the
  // toggle gets clipped away and the menu becomes unrecoverable. SiderMenu marks the
  // layout with data-hamburger-collapsed; honour it by keeping overflow visible. KOA-17806.
  private static applyLayoutScrollOverflow(layout: HTMLElement): void {
    if (layout.getAttribute("data-hamburger-collapsed") === "true") {
      layout.style.overflow = "visible";
      layout.style.overflowY = "visible";
    } else {
      layout.style.overflowY = "auto";
    }
  }

  public static addToPageInputVariables(screen: any, paramName: string, val: any) {
    if (!window.kuika) window.kuika = {};
    if (!window.kuika?.navigationScreenInputs) window.kuika.navigationScreenInputs = {};
    window.kuika.navigationScreenInputs[paramName] = val;
  }

  public static increaseServerRequestCount() {
    if (!window.kuika) window.kuika = {};
    if (window.kuika?.serverRequestCount === undefined) window.kuika.serverRequestCount = 0;
    window.kuika.serverRequestCount++;
  }

  public static resetServerRequestCount() {
    if (!window.kuika) window.kuika = {};
    window.kuika.serverRequestCount = 0;
  }

  public static prepareForNavigation() {
    KuikaAppManager.resetServerRequestCount();
    window.kuika.navigationScreenInputs = {} as any;
  }

  static GetBackendUrl(forOnlyInfo = false) {
    // env-config BACKEND_URL, resolved PER APP. `window._env_` belongs to
    // whoever owns the page, so an embedded microapp reads the env-config
    // fetched from its OWN deployment and never inherits the host's — that
    // inheritance is what made a microapp's backend URL look overridden by its
    // parent's while its own BACKEND_URL env var looked ignored. Standalone and
    // host apps are unaffected: for a page owner this IS `window._env_`.
    // See own-app-env.ts.
    const ownEnv: KuikaEnvConfig | undefined = getOwnEnvConfig();
    if (ownEnv?.BACKEND_URL) {
      return ownEnv.BACKEND_URL;
    }

    let backendUrl = "";

    // JSON case
    if (backendUrl === "" && confJson?.backendUrlOverride?.length > 1) {
      backendUrl = confJson.backendUrlOverride;
      if (!backendUrl.endsWith("/v1/api")) {
        backendUrl = `${backendUrl}/v1/api`;
      }
    }

    // Web component case
    const ownMfeApp: KuikaMfeAppEntry | undefined = findOwnMfeAppEntry();
    if (ownMfeApp) {
      const manifestOverride: string = ownMfeApp.manifest?.backendUrlOverride ?? "";
      if (manifestOverride.length > 0) {
        backendUrl = KuikaAppManager.removeTrailingSlash(manifestOverride);
        if (!backendUrl.endsWith("/v1/api")) {
          backendUrl = `${backendUrl}/v1/api`;
        }
      } else {
        backendUrl = KuikaAppManager.getBackendUrlFromFullUrl(ownMfeApp.appConfig?.frontEndUrl ?? "");
      }
    }

    if (backendUrl === "") {
      backendUrl = KuikaAppManager.getBackendUrlFromFullUrl(KMainFunctions.windowLocationOrigin);
    }

    if (backendUrl.indexOf("localhost") > -1 && backendUrl.indexOf("https") === 0) {
      const port = this.getPortFromURL(backendUrl);
      if (port !== undefined && port.length > 0) {
        let difference: number = 0;
        if (forOnlyInfo === false) {
          difference = 200;
        }
        const sslPort = (Number(port) + difference).toString();
        backendUrl = backendUrl.replace(port, sslPort);
      }
    }

    // Report backend URL to Electron main process for microapp resolution
    if (backendUrl && window.electronAPI?.app?.reportBackendUrl) {
      window.electronAPI.app.reportBackendUrl(backendUrl);
    }

    return KuikaAppManager.removeTrailingSlash(backendUrl);
  }

  static getPortFromURL(url: string) {
    const regex = /^(http|https):\/\/[^:/]+(?::(\d+))?/;
    const match = url.match(regex);
    if (match === null || match === undefined) {
      return undefined;
    }
    return match[2] ? match[2] : undefined;
  }

  static IsWebComponent() {
    let result = false;
    // Web component case
    if (
      confJson?.domainName !== undefined &&
      confJson?.applicationName !== undefined &&
      confJson?.applicationName !== "" &&
      window.kuika !== undefined &&
      window.kuika?.apps !== undefined &&
      window.kuika?.apps.length !== undefined &&
      window.kuika?.apps.length > 0
    ) {
      window.kuika?.apps.forEach((app: any) => {
        if (app?.manifest?.appName === confJson.applicationName && app?.manifest?.workspace === confJson?.domainName) {
          result = true;
        }
      });
    }
    return result;
  }

  // Per-app key for the JS-readable login-state cookies (is_logged_in / session_id).
  // The cookie name is suffixed with this so apps sharing one frontend host keep
  // independent login state (see cookie-utils setLoginStateCookie). We key on the
  // app's API host — the same value the CSRF mirror uses — because it is stable per
  // app regardless of navigation (unlike the frontend pathname, which is the screen
  // name on a root-served app). Embedded microapp vs shell each resolve their own
  // backend host here, so their login state stays isolated.
  static getLoginStateCookieKey(): string {
    return getApiHostKey(KuikaAppManager.GetBackendUrl());
  }

  // Reads a login-state cookie (is_logged_in / session_id) scoped to this app.
  // Single entry point so every reader resolves the same per-app key and gets the
  // legacy-bare fallback; never read these via getCookie directly.
  static readLoginStateCookie(baseName: string): string | null {
    return readLoginStateCookie(baseName, KuikaAppManager.getLoginStateCookieKey());
  }

  static GetFrontEndSourceUrl() {
    let result = "";
    // Web component case
    const ownMfeApp: KuikaMfeAppEntry | undefined = findOwnMfeAppEntry();
    if (ownMfeApp?.appConfig?.frontEndUrl) {
      result = KuikaAppManager.removeTrailingSlash(ownMfeApp.appConfig.frontEndUrl);
    }
    if (result === "") {
      result = KuikaAppManager.GetFrontEndUrl();
    }
    result = KuikaAppManager.removeTrailingSlash(result);
    return result;
  }

  static GetFrontEndUrl() {
    return getFrontEndUrl();
  }

  public static getBackendUrlFromFullUrl = (baseUrl: string) => {
    baseUrl = KuikaAppManager.removeTrailingSlash(baseUrl);

    // In Electron with custom protocol, use the actual HTTP URL for backend URL determination
    if (isCustomProtocol(baseUrl)) {
      baseUrl = transformUrlForElectron(baseUrl);
    }

    if (baseUrl.indexOf("localhost") > -1) {
      // Use http: for file: protocol or custom protocols (like Electron's kuika-sample-app:)
      return `${getLocalhostProtocol()}//localhost:25176/v1/api`;
    }
    let kuikaUrls = ["https://localhost", "https://demo.kuika.com", "https://beta.kuika.com", "https://designerdev.kuika.com", "https://designerdev2.kuika.com", "https://alpha.kuika.com", "https://preprod.kuika.com", "https://platform.kuika.com", "https://izzymobility.kuika.com", "https://idata.kuika.com", "https://alpha.kuika.com", "https://designerdev1.kuika.com","https://test.kuika.com","https://test1.kuika.com","https://test2.kuika.com","https://perftest.kuika.com"];
    if (kuikaUrls.indexOf(baseUrl) > -1) return baseUrl + ":25176/v1/api";
    return KuikaAppManager.getApiUrlFromBaseUrl(baseUrl);
  };

  public static getApiUrlFromBaseUrl = (baseUrl: string) => {
    baseUrl = KuikaAppManager.removeTrailingSlash(baseUrl);

    const re = new RegExp("(.*//)([a-zA-Z0-9-]+)(..*)");
    let result = "";
    const isDesignTime = window.kuika && window.kuika.isDesignTime;
    if (isDesignTime === true || baseUrl.indexOf(".kuika.com/") === -1) {
      // Design, UAT, Prod etc. Env.
      result = baseUrl.replace(re, "$1$2api$3/v1/api");
    } else {
      // Kuika Preview Env (Run)
      result = baseUrl.replace(re, "$1$2$3-api/v1/api");
    }
    return result;
  };

  public static removeTrailingSlash(inputString) {
    if (inputString.endsWith("/")) {
      return inputString.slice(0, -1);
    }
    return inputString;
  }

  public static ApiRequest = async (screen: any, requestPath, vars?: any, httpMethod = "post") => {
    try {
      let backendUrl = KuikaAppManager.GetBackendUrl();
      if (!backendUrl.endsWith("/")) backendUrl += "/";
      const url = backendUrl + requestPath;
      const config: AxiosRequestConfig = {
        headers: {
          // @ts-ignore
          projectHash: "116b6160d1e5e3541bacdcf7f4be6e97d46857f187b3196c6916369bd47d47f6" || ""
        }
      };

      if (config && url) {
        KuikaHelper.addExtraHeaderForApiCall(config, url, backendUrl);
      }

      if (httpMethod === "post") {
        const res = await Axios.post<any, AxiosResponse>(url, vars, config);
        return res;
      }
      if (httpMethod === "get") {
        const res = await Axios.get<any, AxiosResponse>(url, config);
        return res;
      }
      if (httpMethod === "put") {
        const res = await Axios.put<any, AxiosResponse>(url, vars, config);
        return res;
      }
      if (httpMethod === "delete") {
        const res = await Axios.delete<any, AxiosResponse>(url, config);
        return res;
      }
      if (httpMethod === "patch") {
        const res = await Axios.patch<any, AxiosResponse>(url, vars, config);
        return res;
      }
    } catch (ex: any) {
      KuikaAppManager.hideSpinner(screen);
      KMainFunctions.exceptionHandler(ex);
      return ex;
    }
  };

  public static showSpinner(screen: any) {
    screen.setState({ spinnerCount: screen.state.spinnerCount + 1 });
  }

  public static hideSpinner(screen: any) {
    screen.setState({ spinnerCount: 0 });
  }

  /**
   * Captures the window and MFE ancestor scroll offsets before an MFE height recalculation (EMR-1).
   * Returns null outside an MFE: there is nothing to protect, and a restore would fight the mobile keyboard's scroll.
   */
  private static saveMfeScrollPositions(): IMfeScrollSnapshot | null {
    const mfeApp: HTMLElement | undefined = window.document.getElementsByClassName("kuika_mfe_app")[0];
    if (!mfeApp) return null;

    const saved: IMfeScrollSnapshot = {
      windowX: window.scrollX,
      windowY: window.scrollY,
      elements: []
    };
    let el: HTMLElement | null = mfeApp;
    while (el) {
      if (el.scrollTop > 0 || el.scrollLeft > 0) {
        saved.elements.push({ el, top: el.scrollTop, left: el.scrollLeft });
      }
      el = el.parentElement;
    }

    return saved;
  }

  private static restoreMfeScrollPositions(saved: IMfeScrollSnapshot | null): void {
    if (!saved) return;
    for (const entry of saved.elements) {
      entry.el.scrollTop = entry.top;
      entry.el.scrollLeft = entry.left;
    }
    if (window.scrollX !== saved.windowX || window.scrollY !== saved.windowY) {
      window.scrollTo(saved.windowX, saved.windowY);
    }
  }

  /**
   * Helper method to calculate and set MFE body height.
   * @param includeMfeLayout - If true, includes MFE layout header/footer heights in the calculation.
   */
  private static calculateMfeBodyHeight(includeMfeLayout: boolean = false): void {
    if (window.kuika.isDesignTime) return;

    const mfeApp = window.document.getElementsByClassName("kuika_mfe_app")[0];
    if (!mfeApp || !(mfeApp instanceof HTMLElement)) return;

    const mfeBody = mfeApp.querySelector('[id$="_body"]');
    if (!(mfeBody instanceof HTMLElement)) return;

    // Inner-scoped chrome: headers/footers INSIDE the MFE wrapper only.
    // When a host slot is found, its clientHeight already accounts for the outer
    // app's chrome — we must subtract only the inner MFE's own chrome.
    const mfeScopedHeaders = mfeApp.querySelectorAll('[id$="_header"]:not([id$="_layout_header"])');
    const mfeScopedFooters = mfeApp.querySelectorAll('[id$="_footer"]:not([id$="_layout_footer"])');
    let innerChromeOffset = 0;
    mfeScopedHeaders.forEach((header: Element) => {
      innerChromeOffset += parseFloat(window.getComputedStyle(header).height) || 0;
    });
    mfeScopedFooters.forEach((footer: Element) => {
      innerChromeOffset += parseFloat(window.getComputedStyle(footer).height) || 0;
    });
    if (includeMfeLayout) {
      const mfeLayoutHeader = mfeApp.querySelector('[id$="_layout_header"]');
      const mfeLayoutFooter = mfeApp.querySelector('[id$="_layout_footer"]');
      if (mfeLayoutHeader) {
        innerChromeOffset += parseFloat(window.getComputedStyle(mfeLayoutHeader).height) || 0;
      }
      if (mfeLayoutFooter) {
        innerChromeOffset += parseFloat(window.getComputedStyle(mfeLayoutFooter).height) || 0;
      }
    }

    mfeBody.style.height = "auto";

    const computeMinHeight = (): string => {
      const slotHeight: number | null = KuikaAppManager.measureMfeSlotHeight(mfeApp);
      if (slotHeight !== null) {
        return `${Math.max(slotHeight - innerChromeOffset, 0)}px`;
      }
      // Viewport fallback: keep original document-wide chrome accounting since
      // there is no measurable slot at all (defensive — reached only when the
      // wrapper has no measurable height and no scrollable ancestor).
      const masterLayoutHeader = window.document.querySelector('[id$="_layout_header"]');
      const masterLayoutFooter = window.document.querySelector('[id$="_layout_footer"]');
      const mlh: number = masterLayoutHeader ? parseFloat(window.getComputedStyle(masterLayoutHeader).height) || 0 : 0;
      const mlf: number = masterLayoutFooter ? parseFloat(window.getComputedStyle(masterLayoutFooter).height) || 0 : 0;
      return `calc(100vh - ${mlh + mlf + innerChromeOffset + 32}px)`;
    };

    const applyMinHeight = (): void => {
      const value: string = computeMinHeight();
      if (value === KuikaAppManager.lastMfeBodyMinHeights.get(mfeBody)) return;
      KuikaAppManager.lastMfeBodyMinHeights.set(mfeBody, value);
      mfeBody.style.minHeight = value;
    };

    applyMinHeight();

    const existing: ResizeObserver | undefined = KuikaAppManager.mfeSlotResizeObservers.get(mfeBody);
    if (existing) {
      existing.disconnect();
    }
    const observer: ResizeObserver = new ResizeObserver(applyMinHeight);
    observer.observe(KuikaAppManager.getMfeResizeObserveTarget(mfeApp));
    KuikaAppManager.mfeSlotResizeObservers.set(mfeBody, observer);
  }

  /**
   * The body and every scroller between it and masterRootDI, with their summed scrollTop (KOA-18849).
   * Rewriting the body height can shrink an outer scroller, and the browser then clamps it — the page jumps to the top.
   */
  private static captureBodyScrollChain(body: HTMLElement): IBodyScrollChain {
    const elements: HTMLElement[] = [];
    let el: HTMLElement | null = body;
    while (el) {
      elements.push(el);
      if (el.id === "masterRootDI") break;
      el = el.parentElement;
    }
    if (elements[elements.length - 1].id !== "masterRootDI") {
      elements.length = 1;
    }
    return { elements, offset: KuikaAppManager.sumScrollTop(elements) };
  }

  private static sumScrollTop(elements: HTMLElement[]): number {
    return elements.reduce((total: number, el: HTMLElement): number => total + el.scrollTop, 0);
  }

  private static restoreBodyScrollChain(chain: IBodyScrollChain): void {
    let lost: number = chain.offset - KuikaAppManager.sumScrollTop(chain.elements);
    for (const el of chain.elements) {
      if (lost < 1) return;
      const before: number = el.scrollTop;
      el.scrollTop = before + lost;
      lost -= el.scrollTop - before;
    }
  }

  public static calculateAndSetBodyHeight(screenName: string, masterScreenName: string) {
    const timerKey = `${screenName}::${masterScreenName || ""}`;
    const pendingTimerId = KuikaAppManager.bodyHeightTimerIds.get(timerKey);
    if (pendingTimerId !== undefined) {
      clearTimeout(pendingTimerId);
    }
    const timerId = setTimeout(() => {
      KuikaAppManager.bodyHeightTimerIds.delete(timerKey);
      if (masterScreenName) {
        masterScreenName = masterScreenName.replace(/\s+/g, "_");
      }
      const hasMaster = masterScreenName && masterScreenName !== "";
      const body = window.document.getElementById(`${screenName}_body`);
      if (!body) return;
      const savedScroll: IMfeScrollSnapshot | null = KuikaAppManager.saveMfeScrollPositions();
      const scrollChain: IBodyScrollChain = KuikaAppManager.captureBodyScrollChain(body);
      let headerHeight: number = 0;
      let footerHeight: number = 0;

      const header = window.document.getElementById(`${screenName}_header`);
      const footer = window.document.getElementById(`${screenName}_footer`);
      // Prevent the flex column wrapper (display:flex; flex-direction:column) from
      // shrinking the header/footer below their user-set heights. Without this the
      // computed height collapses to min-content (~38px = button size) and every
      // downstream calc(100vh - headerHeight) reads the wrong offset.
      if (header && header.style) {
        header.style.flexShrink = "0";
      }
      if (footer && footer.style) {
        footer.style.flexShrink = "0";
      }
      const isHeaderTransparent =
        header &&
        header.style &&
        (header.style.backgroundColor === "transparent" || header.style.backgroundColor === "rgba(0, 0, 0, 0)");
      const isFooterTransparent =
        footer &&
        footer.style &&
        (footer.style.backgroundColor === "transparent" ||
          footer.style.backgroundColor === "rgba(0, 0, 0, 0)" ||
          !footer.style.backgroundColor);
      const mfeWrapper: HTMLElement | null = body.closest(".kuika_mfe_app") as HTMLElement | null;
      const escapeForCssId = (id: string): string => {
        if (typeof CSS !== "undefined" && typeof CSS.escape === "function") {
          return CSS.escape(id);
        }
        return id.replace(/([^a-zA-Z0-9_-])/g, "\\$1");
      };
      const findScoped = (id: string): HTMLElement | null => {
        if (mfeWrapper) {
          return mfeWrapper.querySelector(`#${escapeForCssId(id)}`) as HTMLElement | null;
        }
        return window.document.getElementById(id);
      };

      const layout_header = findScoped(`${masterScreenName.replace("_screen", "")}_layout_header`);
      const layout_footer = findScoped(`${masterScreenName.replace("_screen", "")}_layout_footer`);
      const masterRootDI = findScoped("masterRootDI");

      if (masterRootDI && hasMaster) {
        let headerHeight = layout_header ? parseFloat(window.getComputedStyle(layout_header).height) : 0;
        let footerHeight = layout_footer ? parseFloat(window.getComputedStyle(layout_footer).height) : 0;

        if (mfeWrapper) {
          KuikaAppManager.applyMfeSlotHeight(masterRootDI, mfeWrapper, () => {
            const lh: number = layout_header ? parseFloat(window.getComputedStyle(layout_header).height) || 0 : 0;
            const lf: number = layout_footer ? parseFloat(window.getComputedStyle(layout_footer).height) || 0 : 0;
            return lh + lf;
          });
        } else {
          masterRootDI.style.height = `calc(100vh - ${headerHeight + footerHeight}px)`;
        }
      }
      if (!header && !footer) {
        const layout_header = window.document.getElementById(
          `${masterScreenName.replace("_screen", "")}_layout_header`
        );
        const layout_footer = window.document.getElementById(
          `${masterScreenName.replace("_screen", "")}_layout_footer`
        );
        if (layout_header) {
          const headerStyles = window.getComputedStyle(layout_header);
          const headerPaddingTop = parseFloat(headerStyles.paddingTop) || 0;
          const headerPaddingBottom = parseFloat(headerStyles.paddingBottom) || 0;
          headerHeight = parseFloat(headerStyles.height) + headerPaddingTop + headerPaddingBottom;
        }

        if (layout_footer) {
          const footerStyles = window.getComputedStyle(layout_footer);
          const footerPaddingTop = parseFloat(footerStyles.paddingTop) || 0;
          const footerPaddingBottom = parseFloat(footerStyles.paddingBottom) || 0;
          footerHeight = parseFloat(footerStyles.height) + footerPaddingTop + footerPaddingBottom;
        }
      } else {
        if (header) {
          const headerStyles = window.getComputedStyle(header);
          const headerPaddingTop = parseFloat(headerStyles.paddingTop) || 0;
          const headerPaddingBottom = parseFloat(headerStyles.paddingBottom) || 0;
          headerHeight = parseFloat(headerStyles.height) + headerPaddingTop + headerPaddingBottom;
        }

        if (footer) {
          const footerStyles = window.getComputedStyle(footer);
          const footerPaddingTop = parseFloat(footerStyles.paddingTop) || 0;
          const footerPaddingBottom = parseFloat(footerStyles.paddingBottom) || 0;
          footerHeight = parseFloat(footerStyles.height) + footerPaddingTop + footerPaddingBottom;
        }
      }

      const layout_right = findScoped(`${masterScreenName.replace("_screen", "")}_layout_right`);
      const layout_left = findScoped(`${masterScreenName.replace("_screen", "")}_layout_left`);
      const layout_left_rect = layout_left ? layout_left.getBoundingClientRect() : undefined;
      const layout_right_rect = layout_right ? layout_right.getBoundingClientRect() : undefined;
      const layout_footer_rect = layout_footer ? layout_footer.getBoundingClientRect() : undefined;

      const masterRootDIWrapper = findScoped("masterRootDI_wrapper");
      const isLayoutHeaderInWrapper =
        layout_header && masterRootDIWrapper && layout_header.closest("#masterRootDI_wrapper");
      const isLayoutFooterInWrapper =
        layout_footer && masterRootDIWrapper && layout_footer.closest("#masterRootDI_wrapper");

      if (layout_left && layout_left instanceof HTMLElement) {
        const lhHeight =
          layout_header && !isLayoutHeaderInWrapper
            ? parseFloat(window.getComputedStyle(layout_header).height) || 0
            : 0;
        const lfHeight =
          layout_footer && !isLayoutFooterInWrapper
            ? parseFloat(window.getComputedStyle(layout_footer).height) || 0
            : 0;
        if (mfeWrapper) {
          KuikaAppManager.applyMfeSlotHeight(layout_left, mfeWrapper, () => {
            const h: number =
              layout_header && !isLayoutHeaderInWrapper
                ? parseFloat(window.getComputedStyle(layout_header).height) || 0
                : 0;
            const f: number =
              layout_footer && !isLayoutFooterInWrapper
                ? parseFloat(window.getComputedStyle(layout_footer).height) || 0
                : 0;
            return h + f;
          });
        } else {
          const leftHeight = `calc(100vh - ${lhHeight + lfHeight}px)`;
          layout_left.style.height = leftHeight;
          layout_left.style.maxHeight = leftHeight;
        }
        KuikaAppManager.applyLayoutScrollOverflow(layout_left);
      }

      if (layout_right && layout_right instanceof HTMLElement) {
        const lhHeight =
          layout_header && !isLayoutHeaderInWrapper
            ? parseFloat(window.getComputedStyle(layout_header).height) || 0
            : 0;
        const lfHeight =
          layout_footer && !isLayoutFooterInWrapper
            ? parseFloat(window.getComputedStyle(layout_footer).height) || 0
            : 0;
        if (mfeWrapper) {
          KuikaAppManager.applyMfeSlotHeight(layout_right, mfeWrapper, () => {
            const h: number =
              layout_header && !isLayoutHeaderInWrapper
                ? parseFloat(window.getComputedStyle(layout_header).height) || 0
                : 0;
            const f: number =
              layout_footer && !isLayoutFooterInWrapper
                ? parseFloat(window.getComputedStyle(layout_footer).height) || 0
                : 0;
            return h + f;
          });
        } else {
          const rightHeight = `calc(100vh - ${lhHeight + lfHeight}px)`;
          layout_right.style.height = rightHeight;
          layout_right.style.maxHeight = rightHeight;
        }
        KuikaAppManager.applyLayoutScrollOverflow(layout_right);
      }

      const isChildOfMasterRootDI = (element: HTMLElement) => {
        if (!element) return false;
        if (element.id === "masterRootDI") return true;
        return isChildOfMasterRootDI(element.parentElement);
      };
      const isHeaderExistInMasterDI = isChildOfMasterRootDI(header);
      const isFooterExistInMasterDI = isChildOfMasterRootDI(footer);
      if (header && header.style && isHeaderExistInMasterDI) {
        // Header lives inside masterRootDI, which is already the narrow center
        // column between layout_left and layout_right. Its `100%` therefore
        // resolves to (viewport - left - right) already; subtracting the sidebar
        // widths again double-subtracts and leaves an empty gap on the right.
        header.style.zIndex = 1;
        header.style.width = "100%";
        if (layout_right && layout_right.style) {
          layout_right.style.zIndex = "1";
        }
      }

      if (footer && footer.style && isFooterExistInMasterDI) {
        const leftAndRightLayoutsWidth = layout_left_rect?.width + layout_right_rect?.width;
        footer.style.zIndex = 1;
        footer.style.width = leftAndRightLayoutsWidth > 0 ? `calc(100% - ${leftAndRightLayoutsWidth}px)` : "100%";
        footer.style.bottom = layout_footer && layout_footer_rect ? `${layout_footer_rect.height}px` : "0px";
        if (layout_right && layout_right.style) {
          layout_right.style.zIndex = "1";
        }
      }

      if (body && body.style) {
        const parentModal = body.closest(".ant-modal-body") as HTMLElement | null;
        const parentFloatPanel = body.closest(".kuika-float-panel-content");
        const parentDrawer = body.closest(".ant-drawer-body");
        const drawerWidth = parentDrawer ? parseFloat(window.getComputedStyle(parentDrawer).width) : 0;
        if (parentModal) {
          const modalComputedStyle = window.getComputedStyle(parentModal);
          const modalPadding = parseFloat(modalComputedStyle.padding);
          const inlineHeight = parentModal.style.height;
          const isPercentageHeight = inlineHeight && inlineHeight.includes("%");

          if (isPercentageHeight) {
            const percentValue = parseFloat(inlineHeight);
            body.style.height = `calc(${percentValue}vh - ${headerHeight + footerHeight + modalPadding}px)`;
            body.style.minHeight = `calc(${percentValue}vh - ${headerHeight + footerHeight + modalPadding}px)`;
            body.style.maxHeight = `calc(${percentValue}vh - ${headerHeight + footerHeight + modalPadding}px)`;
          } else {
            const modalHeight = parseFloat(modalComputedStyle.height);
            if (modalHeight > 0) {
              body.style.height = `calc(${modalHeight}px - ${headerHeight + footerHeight + modalPadding}px)`;
              body.style.minHeight = `calc(${modalHeight}px - ${headerHeight + footerHeight + modalPadding}px)`;
              body.style.maxHeight = `calc(${modalHeight}px - ${headerHeight + footerHeight + modalPadding}px)`;
            }
          }
          body.style.overflowY = "auto";
          const modalContent = parentModal.closest(".ant-modal-content") as HTMLElement | null;
          if (modalContent && body.style.backgroundColor) {
            modalContent.style.backgroundColor = body.style.backgroundColor;
          }
          if (layout_footer && parentModal.clientHeight) {
            let topValue = parentModal.clientHeight;
            if (layout_header && layout_header.style && layout_header.style.height) {
              topValue -= parseInt(layout_header.style.height) + 20;
            } else {
              topValue -= 60;
            }
            layout_footer.style.position = "absolute";
            layout_footer.style.top = `${topValue}px`;
            layout_footer.style.width = "100%";
          }
        } else if (parentFloatPanel) {
          const floatPanelComputedStyle = window.getComputedStyle(parentFloatPanel as Element);
          const floatPanelHeight = parseFloat(floatPanelComputedStyle.height);
          const floatPanelPadding = parseFloat(floatPanelComputedStyle.padding);
          const floatPanelHeader = parentFloatPanel.closest(".kuika-float-panel-header");
          const floatPanelHeaderHeight = floatPanelHeader
            ? parseFloat(window.getComputedStyle(floatPanelHeader).height)
            : 0;
          body.style.height = `calc(${floatPanelHeight}px - ${
            headerHeight + footerHeight + floatPanelPadding + floatPanelHeaderHeight
          }px)`;
          body.style.minHeight = `calc(${floatPanelHeight}px - ${
            headerHeight + footerHeight + floatPanelPadding + floatPanelHeaderHeight
          }px)`;
          body.style.maxHeight = `calc(${floatPanelHeight}px - ${
            headerHeight + footerHeight + floatPanelPadding + floatPanelHeaderHeight
          }px)`;
          body.style.overflowY = "auto";
        } else if (isChildOfMasterRootDI(body)) {
          if (footer && footer.style) {
            footer.style.bottom = "0px";

            if (!parentDrawer) {
              footer.style.width = "100%";
              if (isFooterTransparent) {
                footer.style.position = "fixed";
              } else {
                footer.style.position = "sticky";
              }
            } else {
              footer.style.width = `${drawerWidth}px`;
              footer.style.position = isFooterTransparent ? "fixed" : "sticky";
            }
          }
          if (header && header.style && isHeaderTransparent) {
            if (!parentDrawer) {
              header.style.width = "100%";
            } else {
              header.style.width = `${drawerWidth}px`;
            }
            header.style.position = "fixed";
            header.style.top = "0px";
            const currentBodyPaddingTop = parseFloat(window.getComputedStyle(body).paddingTop) || 0;
            if (!parentDrawer) {
              body.style.paddingTop = `${currentBodyPaddingTop + headerHeight}px`;
            } else {
              body.style.paddingTop = `${headerHeight}px`;
            }
          }
          body.style.height = "";
          body.style.minHeight = "";
          body.style.maxHeight = "";
          let currentElement = body;
          const rootDiWrapper = document.getElementById("masterRootDI_wrapper");
          if (rootDiWrapper && body.style) {
            const bodyBg = body.style.backgroundColor;
            if (bodyBg && bodyBg !== "transparent" && bodyBg !== "rgba(0, 0, 0, 0)") {
              rootDiWrapper.style.backgroundColor = bodyBg;
            }
          }
          while (currentElement && currentElement.id !== "masterRootDI") {
            currentElement.style.height = "100%";
            currentElement = currentElement.parentElement;
          }

          KuikaAppManager.calculateMfeBodyHeight(true);
          KuikaAppManager.restoreMfeScrollPositions(savedScroll);
          KuikaAppManager.restoreBodyScrollChain(scrollChain);
          return;
        } else {
          const bodyPaddingTop = parseFloat(window.getComputedStyle(body).paddingTop) || 0;
          const bodyPaddingBottom = parseFloat(window.getComputedStyle(body).paddingBottom) || 0;
          let heightNum = headerHeight + bodyPaddingTop + bodyPaddingBottom;
          if (footer && !isFooterTransparent) {
            heightNum += footerHeight;
          }
          if (parentDrawer) {
            if (mfeWrapper) {
              KuikaAppManager.applyMfeSlotHeight(body, mfeWrapper, () => headerHeight + footerHeight, true);
            } else {
              const heightStr = `calc(100vh - ${headerHeight + footerHeight}px)`;
              body.style.height = heightStr;
              body.style.minHeight = heightStr;
              body.style.maxHeight = heightStr;
            }
            body.style.overflow = "auto";
          } else {
            // Regular screen case body. Body must own the scroll (fixed height +
            // overflow:auto) so the layout = header + body + footer = 100vh always.
            // That keeps the in-flow sticky footer pinned to viewport bottom and the
            // body background covering the full visible area. Only in-flow header/
            // footer are subtracted; transparent ones are position:fixed.
            // offsetHeight = rendered border-box height. headerHeight/footerHeight
            // above add padding on top of getComputedStyle().height, which double-
            // counts when box-sizing: border-box (antd's global default).
            const inflowHeaderHeight = header && !isHeaderTransparent ? header.offsetHeight : 0;
            const inflowFooterHeight = footer && !isFooterTransparent ? footer.offsetHeight : 0;
            const heightOffset = inflowHeaderHeight + inflowFooterHeight;
            if (mfeWrapper) {
              KuikaAppManager.applyMfeSlotHeight(body, mfeWrapper, () => heightOffset, true);
            } else {
              const heightStr = heightOffset > 0 ? `calc(100vh - ${heightOffset}px)` : "100vh";
              body.style.height = heightStr;
              body.style.minHeight = heightStr;
              body.style.maxHeight = heightStr;
            }
            body.style.overflow = "auto";
          }
          if (header && header.style && isHeaderTransparent) {
            header.style.top = "0px";
            if (!parentDrawer) {
              header.style.width = "100%";
            } else {
              header.style.width = `${drawerWidth}px`;
            }
            header.style.position = "fixed";
            header.style.zIndex = 1;
            const currentBodyPaddingTop = parseFloat(window.getComputedStyle(body).paddingTop) || 0;
            if (!parentDrawer) {
              body.style.paddingTop = `${currentBodyPaddingTop + headerHeight}px`;
            } else {
              body.style.paddingTop = `${headerHeight}px`;
            }
          }
          if (footer && footer.style) {
            footer.style.bottom = "0px";
            if (!parentDrawer) {
              footer.style.width = "100%";
            } else {
              footer.style.width = `${drawerWidth}px`;
            }
            if (isFooterTransparent) {
              footer.style.position = "fixed";
              footer.style.zIndex = 1;
              const currentBodyPaddingBottom = parseFloat(window.getComputedStyle(body).paddingBottom) || 0;
              if (!parentDrawer) {
                body.style.paddingBottom = `${currentBodyPaddingBottom + footerHeight}px`;
              } else {
                body.style.paddingBottom = `${footerHeight}px`;
              }
            } else {
              footer.style.position = "sticky";
            }
          }

          KuikaAppManager.calculateMfeBodyHeight(false);
          KuikaAppManager.restoreMfeScrollPositions(savedScroll);
        }
      }
      KuikaAppManager.restoreBodyScrollChain(scrollChain);
    }, 1);
    KuikaAppManager.bodyHeightTimerIds.set(timerKey, timerId);
  }

  public static handleValidations(screen: any, data: IValidationData[], callback?: () => void): boolean {
    const validationsErrorsToRemove = data.filter(
      (x) => x.condition === false || (x.condition === true && x.isValid === true)
    );
    const validationsErrorsToShow = data.filter((x) => x.condition === true && x.isValid === false);
    const hasValidationError = validationsErrorsToShow.length > 0;

    validationsErrorsToRemove.forEach((x) => {
      screen.props.form.setFields([
        {
          name: x.formName,
          errors: []
        }
      ]);
    });

    validationsErrorsToShow.forEach((x) => {
      screen.props.form.setFields([
        {
          name: x.formName,
          errors: [x.message]
        }
      ]);
    });

    // KOA-18186: a screen under a MasterScreen owns only its own form scope (KOA-17999),
    // so this run can never re-evaluate — and therefore never clear — an error the master
    // chrome's form is still showing from an earlier run (e.g. a required master search
    // field kept its red error after the child's save completed successfully). When a run
    // that actually validated something passes, the interaction cycle is complete: clear
    // whatever stale errors the enclosing master scope still displays. The data.length
    // guard matters because EVERY generated handler calls handleValidations (the template
    // always declares `let validations = []`) — without it, PageInit, navigation and other
    // validation-less actions would wipe the master's error as a side effect of any click.
    // One-directional by design — the master scope has no parentForm, so master-triggered
    // runs never touch child fields.
    if (data.length > 0 && !hasValidationError) {
      const parentForm: FormInstance | null = screen.props?.parentForm ?? null;
      if (parentForm) {
        const staleErrorFields = parentForm.getFieldsError().filter((field) => field.errors.length > 0);
        if (staleErrorFields.length > 0) {
          parentForm.setFields(staleErrorFields.map((field) => ({ name: field.name, errors: [] })));
        }
      }
    }

    if (callback) {
      setTimeout(() => {
        callback();
      }, 100);
    }

    if (hasValidationError) {
      this.hideSpinner(screen);
    }
    return hasValidationError;
  }

  public static isPageInitPrevented(): boolean {
    if (!window?.kuika?.pageInitCallers) return false;
    // TODO:TURENC FURKAN, CAGAN bu bölüm Virtual directoryler için ayrı normal hosting için ayrı test edilmeli!
    const hash = window.location.hash?.substring(2);
    const pathname = window.location.pathname?.substring(1);
    const path = pathname?.includes("/") ? pathname.split("/").pop() : pathname;
    if (hash && window.kuika.pageInitCallers[hash] !== undefined && window.kuika.pageInitCallers[hash] === false)
      return true;
    if (path && window.kuika.pageInitCallers[path] !== undefined && window.kuika.pageInitCallers[path] === false)
      return true;
    return false;
  }

  public static setNextRequestAudit(key: string, name: string, source?: string, data?: any) {
    if (!window.kuika) window.kuika = {};
    window.kuika.nextRequestAudit = {
      key,
      name,
      source,
      data
    };
  }

  public static consumeNextRequestAudit() {
    const nextAudit = window.kuika?.nextRequestAudit;
    if (nextAudit) {
      delete window.kuika.nextRequestAudit;
    }
    return nextAudit;
  }
}
