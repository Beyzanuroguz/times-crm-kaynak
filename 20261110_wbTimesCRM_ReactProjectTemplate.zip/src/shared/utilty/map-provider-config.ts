// Runtime map-provider configuration, surfaced through window._env_ by the code
// generator (env-config.js). Apps generated before Amap support have no MAP_PROVIDER,
// so every accessor here defaults to Google Maps — preserving existing behavior.
import { KuikaEnvConfig } from "./frontend-url";

export type MapProvider = "GoogleMaps" | "Amap";

interface GlobalWithEnv {
  _env_?: KuikaEnvConfig;
}

/** Amap runtime credentials resolved from the generated env-config. */
export interface AmapRuntimeConfig {
  key: string;
  securityJsCode: string;
  /** Amap World Map (世界地图): overseas tiles + multilingual labels. Requires the entitlement on the key. */
  worldMapEnabled: boolean;
}

function getEnv(): KuikaEnvConfig | undefined {
  return (globalThis as GlobalWithEnv)._env_;
}

/**
 * localStorage key holding the end user's provider choice (SetMapProvider). The codegen'd
 * index.html loader (ReactProjectGenerator.GoogleMapsProviderChoiceLoader) reads the same key
 * to decide whether to load the Google Maps script — keep both spellings identical.
 */
export const MAP_PROVIDER_STORAGE_KEY: string = "kuika_map_provider";

export function isMapProvider(value: unknown): value is MapProvider {
  return value === "GoogleMaps" || value === "Amap";
}

/**
 * The provider the project selected. Defaults to "GoogleMaps" when unset (older generated
 * apps, or projects that never opted into Amap).
 */
export function getDefaultMapProvider(): MapProvider {
  const provider: string | undefined = getEnv()?.MAP_PROVIDER;
  return provider === "Amap" ? "Amap" : "GoogleMaps";
}

/** True when the app bundles both providers and the end user may pick one (SetMapProvider). */
export function isEndUserMapProviderChoiceEnabled(): boolean {
  return getEnv()?.MAP_PROVIDER_USER_CHOICE === "true";
}

/** True when this build can render the provider: Amap needs its key, Google always loads. */
export function isMapProviderAvailable(provider: MapProvider): boolean {
  if (provider === "Amap") {
    const amapKey: string = getEnv()?.AMAP_KEY ?? "";
    return amapKey !== "";
  }
  return true;
}

function readStoredMapProvider(): MapProvider | null {
  let stored: string | null = null;
  try {
    stored = globalThis.localStorage?.getItem(MAP_PROVIDER_STORAGE_KEY) ?? null;
  } catch {
    // Storage blocked (private mode, sandboxed iframe): fall back to the project default.
    return null;
  }
  return isMapProvider(stored) ? stored : null;
}

/** Persists the end user's choice; the caller reloads so every map surface picks it up. */
export function storeMapProvider(provider: MapProvider): void {
  globalThis.localStorage.setItem(MAP_PROVIDER_STORAGE_KEY, provider);
}

/**
 * The effective map provider: the end user's stored choice when the project allows one and this
 * build can render it, otherwise the project default. A stale choice (choice turned off, or Amap
 * no longer bundled) silently yields the default instead of a blank map.
 */
export function getMapProvider(): MapProvider {
  const defaultProvider: MapProvider = getDefaultMapProvider();
  const isChoiceEnabled: boolean = isEndUserMapProviderChoiceEnabled();
  if (!isChoiceEnabled) return defaultProvider;

  const stored: MapProvider | null = readStoredMapProvider();
  if (stored === null || !isMapProviderAvailable(stored)) return defaultProvider;
  return stored;
}

/** True when the app should render maps and geocode via Amap instead of Google Maps. */
export function isAmapProvider(): boolean {
  const provider: MapProvider = getMapProvider();
  return provider === "Amap";
}

/**
 * The Google Maps JS API key surfaced from the generated config (window._env_), or an
 * empty string when unset. Components should prefer this over any hardcoded literal.
 */
export function getGoogleMapsKey(): string {
  return getEnv()?.GOOGLE_MAPS_KEY ?? "";
}

/**
 * Amap credentials for the JSAPI loader, or null when Amap is not the selected
 * provider or no key was configured.
 */
export function getAmapRuntimeConfig(): AmapRuntimeConfig | null {
  const isAmap: boolean = isAmapProvider();
  if (!isAmap) return null;

  const env: KuikaEnvConfig | undefined = getEnv();
  const key: string = env?.AMAP_KEY ?? "";
  if (!key) return null;

  return {
    key,
    securityJsCode: env?.AMAP_SECURITY_JS_CODE ?? "",
    worldMapEnabled: env?.AMAP_WORLD_MAP === "true"
  };
}

/** True when Amap is the provider and the project enabled the World Map service on its key. */
export function isAmapWorldMapEnabled(): boolean {
  const config: AmapRuntimeConfig | null = getAmapRuntimeConfig();
  return config?.worldMapEnabled === true;
}
