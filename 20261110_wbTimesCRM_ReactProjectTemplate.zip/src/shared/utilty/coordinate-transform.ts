/**
 * Converts between WGS-84 (GPS / global standard) and GCJ-02 (the "Mars" coordinate
 * system mandated inside mainland China and used by Amap / AutoNavi).
 *
 * Kuika stores all coordinates as WGS-84. When the active map provider is Amap, callers
 * must convert WGS-84 -> GCJ-02 before handing coordinates to Amap, and GCJ-02 -> WGS-84
 * when reading coordinates back from Amap. When the provider is Google Maps, no conversion
 * is applied and stored behavior is unchanged.
 *
 * Coordinates outside the GCJ-02 region are returned unchanged (Amap serves WGS-84 there). The
 * region is mainland China + Hong Kong + Macau as a polygon (gcj02-region.ts, generated from
 * Natural Earth); Taiwan and every neighbouring country are outside it. The old bounding-box
 * test is kept only as a fast rejection pre-check — on its own it swept in Mongolia, Korea,
 * western Japan, Southeast Asia, Nepal, northern India and Central Asia, where Amap's World Map
 * serves WGS-84 and the shift would have offset points by up to ~700 m.
 * The forward transform is the standard published GCJ-02 algorithm; the inverse iteratively
 * refines the WGS-84 estimate until the forward transform reproduces the GCJ-02 input, so the
 * round-trip converges to floating-point precision. Byte-identical to the C#
 * (Kuika.Common.Helpers.CoordinateTransform) and Kotlin ports.
 */

import { GCJ02_REGION_RINGS } from "./gcj02-region";

export interface IGeoPoint {
  latitude: number;
  longitude: number;
}

const A: number = 6378245.0;
const EE: number = 0.00669342162296594323;

/** Even-odd ray cast over the hole-free region rings. Same arithmetic in every port. */
function isInsideGcj02Region(latitude: number, longitude: number): boolean {
  let inside: boolean = false;
  for (const ring of GCJ02_REGION_RINGS) {
    const count: number = ring.length / 2;
    let j: number = count - 1;
    for (let i = 0; i < count; i++) {
      const xi: number = ring[2 * i];
      const yi: number = ring[2 * i + 1];
      const xj: number = ring[2 * j];
      const yj: number = ring[2 * j + 1];
      const crosses: boolean = yi > latitude !== yj > latitude;
      if (crosses && longitude < ((xj - xi) * (latitude - yi)) / (yj - yi) + xi) {
        inside = !inside;
      }
      j = i;
    }
  }
  return inside;
}

/** True where Amap serves WGS-84, i.e. outside mainland China + Hong Kong + Macau. */
export function outOfChina(latitude: number, longitude: number): boolean {
  if (longitude < 72.004 || longitude > 137.8347 || latitude < 0.8293 || latitude > 55.8271) {
    return true;
  }
  const inside: boolean = isInsideGcj02Region(latitude, longitude);
  return !inside;
}

function transformLat(x: number, y: number): number {
  let ret: number = -100.0 + 2.0 * x + 3.0 * y + 0.2 * y * y + 0.1 * x * y + 0.2 * Math.sqrt(Math.abs(x));
  ret += ((20.0 * Math.sin(6.0 * x * Math.PI) + 20.0 * Math.sin(2.0 * x * Math.PI)) * 2.0) / 3.0;
  ret += ((20.0 * Math.sin(y * Math.PI) + 40.0 * Math.sin((y / 3.0) * Math.PI)) * 2.0) / 3.0;
  ret += ((160.0 * Math.sin((y / 12.0) * Math.PI) + 320.0 * Math.sin((y * Math.PI) / 30.0)) * 2.0) / 3.0;
  return ret;
}

function transformLng(x: number, y: number): number {
  let ret: number = 300.0 + x + 2.0 * y + 0.1 * x * x + 0.1 * x * y + 0.1 * Math.sqrt(Math.abs(x));
  ret += ((20.0 * Math.sin(6.0 * x * Math.PI) + 20.0 * Math.sin(2.0 * x * Math.PI)) * 2.0) / 3.0;
  ret += ((20.0 * Math.sin(x * Math.PI) + 40.0 * Math.sin((x / 3.0) * Math.PI)) * 2.0) / 3.0;
  ret += ((150.0 * Math.sin((x / 12.0) * Math.PI) + 300.0 * Math.sin((x / 30.0) * Math.PI)) * 2.0) / 3.0;
  return ret;
}

const NOT_A_POINT: IGeoPoint = { latitude: Number.NaN, longitude: Number.NaN };

/** JS callers can hand over strings or NaN; neither must silently pass through as a "coordinate". */
function isFinitePair(latitude: number, longitude: number): boolean {
  return Number.isFinite(latitude) && Number.isFinite(longitude);
}

export function wgs84ToGcj02(latitude: number, longitude: number): IGeoPoint {
  if (!isFinitePair(latitude, longitude)) {
    return NOT_A_POINT;
  }
  if (outOfChina(latitude, longitude)) {
    return { latitude, longitude };
  }

  let dLat: number = transformLat(longitude - 105.0, latitude - 35.0);
  let dLng: number = transformLng(longitude - 105.0, latitude - 35.0);
  const radLat: number = (latitude / 180.0) * Math.PI;
  let magic: number = Math.sin(radLat);
  magic = 1 - EE * magic * magic;
  const sqrtMagic: number = Math.sqrt(magic);
  dLat = (dLat * 180.0) / (((A * (1 - EE)) / (magic * sqrtMagic)) * Math.PI);
  dLng = (dLng * 180.0) / ((A / sqrtMagic) * Math.cos(radLat) * Math.PI);
  return { latitude: latitude + dLat, longitude: longitude + dLng };
}

export function gcj02ToWgs84(latitude: number, longitude: number): IGeoPoint {
  if (!isFinitePair(latitude, longitude)) {
    return NOT_A_POINT;
  }
  if (outOfChina(latitude, longitude)) {
    return { latitude, longitude };
  }

  let wgsLat: number = latitude;
  let wgsLng: number = longitude;
  for (let i = 0; i < 100; i++) {
    const approx: IGeoPoint = wgs84ToGcj02(wgsLat, wgsLng);
    const dLat: number = approx.latitude - latitude;
    const dLng: number = approx.longitude - longitude;
    wgsLat -= dLat;
    wgsLng -= dLng;
    if (Math.abs(dLat) < 1e-11 && Math.abs(dLng) < 1e-11) {
      break;
    }
  }

  return { latitude: wgsLat, longitude: wgsLng };
}
