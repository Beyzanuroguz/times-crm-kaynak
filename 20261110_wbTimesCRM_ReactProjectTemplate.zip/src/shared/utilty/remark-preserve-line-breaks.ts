import type { MDEditorProps } from "@uiw/react-md-editor";
import type { Plugin } from "unified";

/**
 * Minimal structural view of a Markdown AST (mdast) node — only the fields this
 * transform reads or writes. Declared locally so the plugin carries no runtime
 * dependency on the mdast/unist type packages (the imports above are type-only
 * and are erased at build time).
 */
interface MarkdownAstNode {
  type: string;
  value?: string;
  children?: MarkdownAstNode[];
}

/** Preview options accepted by `@uiw/react-md-editor` and forwarded to `@uiw/react-markdown-preview`. */
type PreviewOptions = NonNullable<MDEditorProps["previewOptions"]>;

/** Matches a single line ending (CRLF, CR or LF). */
const LINE_ENDING: RegExp = /\r\n|\r|\n/;

/**
 * Splits a text value on its line endings into an alternating sequence of
 * `text` and `break` nodes, so each soft newline is rendered as a hard `<br>`.
 */
function splitTextOnLineBreaks(value: string): MarkdownAstNode[] {
  const segments: string[] = value.split(LINE_ENDING);
  const nodes: MarkdownAstNode[] = [];
  for (let index = 0; index < segments.length; index++) {
    if (index > 0) {
      nodes.push({ type: "break" });
    }
    nodes.push({ type: "text", value: segments[index] });
  }
  return nodes;
}

/**
 * Recursively rewrites soft newlines inside `text` nodes as `break` nodes. Leaf
 * nodes such as `code` (fenced/indented), `inlineCode` and raw `html` keep their
 * literal content in `value` rather than in child `text` nodes, so their
 * newlines are naturally left untouched.
 */
function convertSoftBreaks(node: MarkdownAstNode): void {
  const children: MarkdownAstNode[] | undefined = node.children;
  if (!children) {
    return;
  }
  for (let index = 0; index < children.length; index++) {
    const child: MarkdownAstNode = children[index];
    const value: string | undefined = child.value;
    if (child.type === "text" && typeof value === "string" && value.includes("\n")) {
      const replacement: MarkdownAstNode[] = splitTextOnLineBreaks(value);
      children.splice(index, 1, ...replacement);
      index += replacement.length - 1;
    } else {
      convertSoftBreaks(child);
    }
  }
}

/**
 * remark plugin that preserves author line breaks in rendered Markdown.
 *
 * Under CommonMark a single newline is a "soft break" that renders as a space,
 * so text authored with single Enter keys collapses onto one line. This plugin
 * rewrites soft breaks as hard `<br>` breaks — the same behaviour as the
 * `remark-breaks` package — while leaving blank-line paragraph breaks intact:
 *   - single Enter  -> `<br>` (stays on the next visual line)
 *   - double Enter  -> new paragraph
 *
 * It operates on the parsed mdast tree, so fenced/inline code and raw HTML are
 * never rewritten. Fixes KOA-17822 (MDEditor/MDViewer dropping line breaks).
 */
export const remarkPreserveLineBreaks: Plugin<[]> = () => {
  return (tree: MarkdownAstNode): void => {
    convertSoftBreaks(tree);
  };
};

/**
 * Merges {@link remarkPreserveLineBreaks} into the caller's `previewOptions`,
 * preserving any remark plugins they already configured.
 */
export function withPreservedLineBreaks(previewOptions?: MDEditorProps["previewOptions"]): PreviewOptions {
  return {
    ...previewOptions,
    remarkPlugins: [...(previewOptions?.remarkPlugins ?? []), remarkPreserveLineBreaks]
  };
}
