import { Console } from "console";
import { BaseReactSystemFunctions, buildWatermarkBody } from "@kuika/runtime";
import type {
  IKuikaApiResponse,
  IParameterReplacementRequest,
  TControlledCopyRequestBody,
  TKuikaHttpMethod,
  TOptionalFlagValue,
  TReplaceParametersValue,
  TWatermarkParamValue
} from "@kuika/runtime";
import { BrowserMultiFormatReader } from "@zxing/library";
import az_AZ from "antd/es/locale/az_AZ";
import bg_BG from "antd/es/locale/bg_BG";
import ca_ES from "antd/es/locale/ca_ES";
import cs_CZ from "antd/es/locale/cs_CZ";
import da_DK from "antd/es/locale/da_DK";
import de_DE from "antd/es/locale/de_DE";
import el_GR from "antd/es/locale/el_GR";
import en_GB from "antd/es/locale/en_GB";
import en_US from "antd/es/locale/en_US";
import es_ES from "antd/es/locale/es_ES";
import et_EE from "antd/es/locale/et_EE";
import fi_FI from "antd/es/locale/fi_FI";
import fr_FR from "antd/es/locale/fr_FR";
import hr_HR from "antd/es/locale/hr_HR";
import hu_HU from "antd/es/locale/hu_HU";
import hy_AM from "antd/es/locale/hy_AM";
import is_IS from "antd/es/locale/is_IS";
import it_IT from "antd/es/locale/it_IT";
import ka_GE from "antd/es/locale/ka_GE";
import kk_KZ from "antd/es/locale/kk_KZ";
import lt_LT from "antd/es/locale/lt_LT";
import lv_LV from "antd/es/locale/lv_LV";
import mk_MK from "antd/es/locale/mk_MK";
import nb_NO from "antd/es/locale/nb_NO";
import nl_NL from "antd/es/locale/nl_NL";
import pl_PL from "antd/es/locale/pl_PL";
import pt_PT from "antd/es/locale/pt_PT";
import ro_RO from "antd/es/locale/ro_RO";
import ru_RU from "antd/es/locale/ru_RU";
import sk_SK from "antd/es/locale/sk_SK";
import sl_SI from "antd/es/locale/sl_SI";
import sr_RS from "antd/es/locale/sr_RS";
import sv_SE from "antd/es/locale/sv_SE";
import tr_TR from "antd/es/locale/tr_TR";
import uk_UA from "antd/es/locale/uk_UA";
import axios from "axios";
import { Guid } from "guid-typescript";
import _ from "lodash";
import moment from "moment";
import querystringify from "querystringify";
import { Store } from "react-notifications-component";
import Swal, { SweetAlertResult } from "sweetalert2";
import { clearTimeout, setTimeout } from "worker-timers";
import LocalStorageService from "../../auth/local-storage-service";
import { isCalendarDateField } from "../../components/web-components/calendar/calendar-date-target";
import {
  getAmbientParameterContext,
  setAmbientParameterContext
} from "../../components/web-components/document/document-parameter-ambient-context";
import { notifyEditorBufferSettled } from "../../components/web-components/document/editor-buffer-settled";
import { authFetch } from "../../components/web-components/document/sdc/utils/dmsApi";
import { isLocationSearchField } from "../../components/web-components/places-autocomplete-input/location-search-value";
import { ICreateUserWithPasswordDto } from "../../models/dto/create-user-with-password";
import { ICreateUserDto } from "../../models/dto/createuser";
import { IImportMappedExcelColumnMapDefinition, IImportMappedExcelParameter } from "../../models/dto/excel";
import { IForgotPasswordDto } from "../../models/dto/forgotpassword.dto";
import { IIyzicoAddressDto, IIyzicoCheckoutFormDto } from "../../models/dto/iyzico.dto";
import { IResetPasswordWithTokenDto } from "../../models/dto/reset-password-with-token";
import { IRestResult } from "../../models/dto/rest-result.dto";
import { ISignupDto } from "../../models/dto/signup.dto";
import { IStripePayment } from "../../models/dto/stripe-payment";
import {
  IStripeCaptureDto,
  IStripeChargePaymentMethodDto,
  IStripeConnectedAccountDto,
  IStripeConnectedAccountOnboardingDto,
  IStripeConnectedAccountPayout,
  IStripeConnectedAccountWithdraw,
  IStripeCreateConnectedAccountDto,
  IStripeDeletePaymentMethodDto,
  IStripePaymentDto,
  IStripeRefundDto,
  IStripeUpdateCustomerDto
} from "../../models/dto/stripe.dto";
import { IUserRoleDto } from "../../models/dto/userrole.dto";
import { ITaskDataParameters, getDictionaryValueByKey } from "../../models/dto/workflow-task.dto";
import { EAccountStatus } from "../../models/enum/auth";
import { ELanguage } from "../../models/enum/language";
// Type-only import (erased at compile time, so no runtime import cycle): the inline
// overlay master wrapper publishes a handle of this shape through InlineOverlayNavContext;
// the withInlineOverlayNav HOC injects it as `screen.props.inlineOverlayNav` for screens
// rendered inside the overlay, driving openAs="currentOverlay" navigation (KOA-8559).
import type { IInlineOverlayNav } from "../../routes/master-screen-wrapper";
import { translationService } from "../../services/_singletons";
import ServerFilesService from "../../services/files-download-service";
import HelperService from "../../services/helper-service";
import { IyzicoService } from "../../services/iyzico-service";
import KuikaCoreWasmBridgeService from "../../services/kuika-core-wasm-bridge-service";
import { LanguageService } from "../../services/language-service";
import NotificationService from "../../services/notification-service";
import OfflineDbPersistenceService from "../../services/offline-db-persistence-service";
import OfflineSyncService from "../../services/offline-sync-service";
import { StripeService } from "../../services/stripe-service";
import { UserService } from "../../services/user-service";
import { WorkflowService } from "../../services/workflow-service";
import { KNavigator } from "../hoc/with-history";
import { OTP_ALGORITHM, OTP_DIGITS, OTP_PERIOD, OTP_SECRET_KEY } from "../json/otp.json";
import { loadAMap } from "./amap-loader";
import { gcj02ToWgs84, IGeoPoint, wgs84ToGcj02 } from "./coordinate-transform";
import { readLngLat, toCoordinatePair } from "./coordinate-value";
import { buildCustomNotificationMessage, buildCustomNotificationStyle } from "./custom-notification-style";
import { KuikaAppManager } from "./kuika-app-manager";
import { KMainFunctions } from "./main-functions";
import {
  geocodeAddressViaBackend,
  IBackendReverseGeocodeResult,
  ILocationAddressData as IBackendLocationAddressData,
  reverseGeocodeViaBackend,
  toLocationAddress
} from "./map-geocoding-service";
import {
  MapProvider,
  getMapProvider as getEffectiveMapProvider,
  isAmapProvider,
  isEndUserMapProviderChoiceEnabled,
  isMapProvider,
  isMapProviderAvailable,
  storeMapProvider
} from "./map-provider-config";
import { preparePdfCaptureClone, resolveSafeCaptureScale } from "./pdf-capture";
import { markExplicitFieldWrite } from "./row-editor-field-writes";



declare let window: Window & { [key: string]: any };
declare let google: any;

// Minimal typings for the untyped Amap Geocoder plugin (not declared by
// @amap/amap-jsapi-types). Used only for provider-aware geocoding below.
interface IAMapLngLat {
  getLng(): number;
  getLat(): number;
}
interface IAMapForwardGeocode {
  location: IAMapLngLat;
}
interface IAMapForwardGeocodeResult {
  geocodes?: IAMapForwardGeocode[];
}
interface IAMapAddressComponent {
  country?: string | string[];
  province?: string | string[];
  city?: string | string[];
  district?: string | string[];
  township?: string | string[];
  street?: string | string[];
}
interface IAMapReGeocode {
  formattedAddress?: string;
  addressComponent?: IAMapAddressComponent;
}
interface IAMapReverseGeocodeResult {
  regeocode?: IAMapReGeocode;
}
interface IAMapGeocoder {
  getLocation(keyword: string, cb: (status: string, result: IAMapForwardGeocodeResult) => void): void;
  getAddress(location: number[], cb: (status: string, result: IAMapReverseGeocodeResult) => void): void;
}
interface IAMapGeocoderNamespace {
  Geocoder: new () => IAMapGeocoder;
}
interface ILocationCoordinatesData {
  latitude: number | undefined;
  longitude: number | undefined;
}
interface ILocationCoordinatesResult {
  data: ILocationCoordinatesData;
}
interface ILocationAddressData {
  address?: string;
  city?: string;
  state?: string;
  country?: string;
  neighborhood?: string;
  street?: string;
  postalCode?: string;
}
interface ILocationAddressResult {
  data: ILocationAddressData;
}

let TOKEN = "";
let USER = "";
let enteredPassword = "";

let watchPositionId: number | null = null;
let watchPositionData: {
  latitude: number;
  longitude: number;
  accuracy: number;
} | null = null;

interface IBarcodeDetectorResult {
  rawValue: string;
  format: string;
}
interface IBarcodeDetector {
  detect(source: HTMLVideoElement): Promise<IBarcodeDetectorResult[]>;
}
interface IBarcodeDetectorCtor {
  new (opts: { formats: string[] }): IBarcodeDetector;
}

interface IBarcodeOverlayHandles {
  overlay: HTMLDivElement;
  video: HTMLVideoElement;
  label: HTMLParagraphElement;
  cancelBtn: HTMLButtonElement;
}

// One entry of a generated lookup table, e.g. getRoleStartingScreenIdList().
interface IGeneratedLookupEntry {
  key: string;
  value: string;
}

export class ReactSystemFunctions extends BaseReactSystemFunctions {
  // Platform hook (see BaseReactSystemFunctions): web stores the active
  // language under the "ml" key in localStorage.
  protected static getStoredLocale(): string | null {
    return localStorage.getItem("ml");
  }

  // Platform hook (see BaseReactSystemFunctions): web publishes the signed document-parameter
  // context on the screen instance (KOA-17254); the shared delivery bodies read it from here.
  protected static ambientParameterContext(screen: unknown): string | undefined {
    return getAmbientParameterContext(screen);
  }

  // Platform hook (see BaseReactSystemFunctions): a commit or discard ended the editing session on
  // sourceVersionId (KOA-18699); the Document element editing it reloads on the version that now holds the content.
  protected static onEditorBufferSettled(sourceVersionId: string, currentVersionId: string): void {
    notifyEditorBufferSettled(sourceVersionId, currentVersionId);
  }

  // Transport seam (RNM-0101). These two bind the shared base to the helpers this target has always
  // used, so a system-function body that lives in the base class behaves on web exactly as it did
  // when it lived here: same URL resolution, same projectHash header, same spinner handling, same
  // notification surface. Call sites elsewhere in this file that still name KuikaAppManager /
  // KMainFunctions directly are unaffected — the hooks are an additional entry point, not a
  // replacement.
  protected static apiRequest(
    screen: unknown,
    requestPath: string,
    vars?: unknown,
    httpMethod: TKuikaHttpMethod = "post"
  ): Promise<IKuikaApiResponse | undefined> {
    return KuikaAppManager.ApiRequest(screen, requestPath, vars, httpMethod);
  }

  protected static exceptionHandler(error: unknown): void {
    KMainFunctions.exceptionHandler(error);
  }

  // Codegen patch points — ReactProjectGenerator string-replaces these bodies
  // with the project's configured formats. The anchor text must stay verbatim,
  // and these must live in THIS file (the generator only patches
  // react-system-functions.tsx), not in the shared base.
  public static getAppDateFormat(): string | null {
    return "";
  }

  public static getAppTimeFormat(): string | null {
    return "";
  }

  public static getDynamicInputDataType(screen: any, componentId: string): string | null {
    const dynamicInputRef = screen[`${componentId}_kuikaTextInputRef`];
    if (
      dynamicInputRef &&
      dynamicInputRef.current &&
      dynamicInputRef.current.props &&
      dynamicInputRef.current.props.dataType
    ) {
      return dynamicInputRef.current.props.dataType;
    }

    return null;
  }

  public static getValueWithDynamicType(screen: any, componentId: string, targetTypeName: string, value: any): any {
    const rawValue = value;

    const dynamicDataType = this.getDynamicInputDataType(screen, `${componentId}_value`);

    const _dynamicDataType = (() => {
      if (
        targetTypeName?.toLowerCase() === "guid" ||
        targetTypeName?.toLowerCase() === "guid?" ||
        targetTypeName?.includes("[]")
      ) {
        return null;
      }
      switch (dynamicDataType) {
        case "String":
          return "string";
        case "Number":
          return "number";
        case "Boolean":
          return "boolean";
        case "DateTimeOffset":
          return "date";
        default:
          return null;
      }
    })();

    if (_dynamicDataType) {
      return this.convertToTypeByName(rawValue, _dynamicDataType);
    }

    if (targetTypeName) {
      return this.convertToTypeByName(rawValue, targetTypeName);
    }

    return rawValue;
  }

  private static toCamelCase = (str: string): string => {
    return str.replace(/^([A-Z])|[\s-](\w)/g, (match, p1, p2) => {
      if (p2) {
        return p2.toUpperCase();
      }

      return p1.toLowerCase();
    });
  };

  private static parseHashUrl(url: string): { pathname: string; hash: string } {
    const hashIndex = url.indexOf("#");
    if (hashIndex === -1) {
      return { pathname: url, hash: "" };
    }
    return {
      pathname: url.substring(0, hashIndex),
      hash: url.substring(hashIndex)
    };
  }

  private static getValueFromPath = (data: object, path: string, index?: number): any => {
    if (!path || !data) return data;

    // Split path and filter based on [selected] marker
    const fields: string[] = path
      .split(".")
      .filter((field: string, idx: number, array: string[]) => {
        const theFieldIndexContainingSelected = array.findIndex((x) => x.includes("[selected]"));

        if (theFieldIndexContainingSelected > -1) {
          return idx > theFieldIndexContainingSelected;
        }

        return true;
      })
      .map((x) => ReactSystemFunctions.toCamelCase(x));

    const value = fields.reduce((prev: any, curr: string) => {
      if (!prev) return "";
      let result = null;

      if (curr.endsWith("[first]")) {
        const field: string = curr.replace("[first]", "");
        result = prev?.[field]?.at?.(0);
      } else if (curr.endsWith("[last]")) {
        const field: string = curr.replace("[last]", "");
        result = prev?.[field]?.at?.(-1);
      } else if (curr.endsWith("[selected]")) {
        const field: string = curr.replace("[selected]", "");
        result = prev?.[field]?.at?.(index ?? 0);
      } else {
        const field: string = curr;
        result = prev?.[field];
      }

      return result;
    }, data);

    return value;
  };

  // public static async listMyTasks(that: any, showPool: any, page: any, pageSize: any, searchKey: any) {
  //   const user = that.props?.context?.userInfo?.username;
  //   if (user === undefined) {
  //     return [];
  //   }
  //   const request = {
  //     user,
  //     app: window.kuika.info.applicationName,
  //     searchKey,
  //     showPool,
  //     page,
  //     pageSize
  //   };
  //   const tasks = await WorkflowService.ListMyTasks(request);
  //   return tasks;
  // }

  // public static async listMyRequests(
  //   that: any,
  //   showCompleted: any,
  //   page: any,
  //   pageSize: any,
  //   processName: any,
  //   searchKey: any
  // ) {
  //   const user = that.props?.context?.userInfo?.username;
  //   if (user === undefined) {
  //     return [];
  //   }
  //   const request = {
  //     user,
  //     app: window.kuika.info.applicationName,
  //     searchKey,
  //     processName,
  //     showCompleted,
  //     page,
  //     pageSize
  //   };
  //   const tasks = await WorkflowService.ListMyRequests(request);
  //   return tasks;
  // }

  // public static async getTaskDetail(stepInstance: string) {
  //   const history = await WorkflowService.GetTaskDetail(stepInstance.toString());
  //   return history;
  // }

  // public static async showHistory(processInstance: string) {
  //   const history = await WorkflowService.ShowWorkflowHistory(processInstance);
  //   return history;
  // }

  // Authentication
  // signup({a0}, {a1}, {a2}, {a3})

  public static async signup(
    _screen: any,
    username: string,
    password: string,
    firstName: string,
    lastName: string,
    confirmEmail?: boolean,
    dontSendEmail?: boolean,
    phoneNumber?: string,
    language?: string
  ) {
    const credientials = {
      username,
      password,
      firstName,
      lastName,
      VerifyEMailAddress: confirmEmail || false,
      dontSendEmail: dontSendEmail || false,
      phoneNumber: phoneNumber || "",
      language: language || ""
    } as ISignupDto;
    LocalStorageService.clearToken();
    window.userInfo = undefined;
    const res = await UserService.SignUp(credientials);
    USER = username;
    enteredPassword = password;
    if (res?.data?.status !== undefined) {
      LocalStorageService.setLoginStatus(res.data.status);
      LocalStorageService.setVerificationUserName(
        res.data.status === EAccountStatus.TwoFactorAuthentication ? username : ""
      );
    }
    return res;
  }

  public static async isVerificationCodeValid(_screen: any, verificationCode: string) {
    TOKEN = verificationCode;
    const loginStatus = LocalStorageService.getLoginStatus();
    if (OTP_SECRET_KEY) {
      const userName = USER || LocalStorageService.getVerificationUserName();
      const otp = await this.generateOTP(userName || "");
      if (otp === verificationCode) {
        return true;
      }
    }
    if (loginStatus === EAccountStatus.TwoFactorAuthentication.toString()) return;

    const res = await UserService.VerifyVerificationCode({
      username: USER,
      verificationCode
    });
    if (KMainFunctions.IsResStatus2XX(res)) {
      LocalStorageService.setVerificationStatus("true");
      return true;
    }
    LocalStorageService.setVerificationStatus("false");
    return false;
  }

  public static async setPasswordWithVerificationCode(
    _screen: any,
    userName: string,
    verificationCode: string,
    newPassword: string,
    language?: string
  ) {
    const res = await UserService.ResetPasswordWithToken({
      UserName: userName,
      newPassword,
      token: verificationCode,
      dontSendEmail: false,
      language: language || ""
    });
    if (KMainFunctions.IsResStatus2XX(res)) {
      LocalStorageService.setResetPasswordStatus(EAccountStatus.Valid);
      return true;
    }

    LocalStorageService.setResetPasswordStatus(EAccountStatus.ForceResetPassword);
    return false;
  }

  public static async encryptedSignin(username: string, password: string) {
    USER = username;
    TOKEN = password;
    enteredPassword = password;
    return this.signin(undefined, username, password, true);
  }

  public static async signin(
    _screen: any,
    username: string,
    password: string,
    isEncrypted: boolean = false
  ): Promise<any> {
    let loginFunction = UserService.Login;
    if (!isEncrypted) {
      USER = username;
      enteredPassword = password;
      TOKEN = password;
    } else {
      loginFunction = UserService.EncryptedLogin;
    }

    await loginFunction({
      username,
      password
    }).then(
      (res) => {
        LocalStorageService.setLoginStatus(res.data?.status?.toString());
        LocalStorageService.setVerificationUserName(
          res.data?.status === EAccountStatus.TwoFactorAuthentication ? username : ""
        );
        return res;
      },
      (error) => {
        if (
          error.message === "Your password has expired" ||
          error.message === "Şifrenizin süresi doldu" ||
          error.message === "Votre mot de passe a expiré"
        ) {
          KMainFunctions.displayWarningNotification(error.message);
          LocalStorageService.setLoginStatus("1");
        }

        if (error.response?.data?.message) {
          alert(error.response.data.message);
          window.location.reload();
        }
      }
    );
    return {};
  }

  public static async SigninWithDelegation(toUserName: string): Promise<any> {
    await UserService.ReLoginWithDelegation({
      ToUserName: toUserName
    }).then(
      (res) => {
        LocalStorageService.setLoginStatus(res.data?.status?.toString());
        return res;
      },
      (error) => {
        if (
          error.message === "Your password has expired" ||
          error.message === "Şifrenizin süresi doldu" ||
          error.message === "Votre mot de passe a expiré"
        ) {
          KMainFunctions.displayWarningNotification(error.message);
          LocalStorageService.setLoginStatus("1");
        }

        if (error.response?.data?.message) {
          alert(error.response.data.message);
          window.location.reload();
        }
      }
    );
    return {};
  }

  public static async ReturnToUserSessionFromDelegation(): Promise<any> {
    await UserService.ReturnToUserSessionFromDelegation().then(
      (res) => {
        LocalStorageService.setLoginStatus(res.data?.status?.toString());
        return res;
      },
      (error) => {
        if (
          error.message === "Your password has expired" ||
          error.message === "Şifrenizin süresi doldu" ||
          error.message === "Votre mot de passe a expiré"
        ) {
          KMainFunctions.displayWarningNotification(error.message);
          LocalStorageService.setLoginStatus("1");
        }

        if (error.response?.data?.message) {
          alert(error.response.data.message);
          window.location.reload();
        }
      }
    );
    return {};
  }

  public static async signinWithVerificationCode(): Promise<any> {
    await UserService.LoginWithVerificationCode({
      username: USER,
      verificationCode: TOKEN
    }).then(
      (res) => {
        if (res.data?.status) LocalStorageService.setLoginStatus(res.data?.status?.toString());
        return res;
      },
      (error) => {
        if (error.response?.data?.message) {
          alert(error.response.data.message);
          window.location.reload();
        }
      }
    );
    return {};
  }

  public static async goToNextScreenAfterSignup(screen: any) {
    const status = LocalStorageService.getLoginStatus();
    if (status == EAccountStatus.ShouldActivated.toString()) {
      screen.props.navigator.goToVerificationCodeScreen();
    } else if (status == EAccountStatus.Valid.toString()) {
      await this.signin(this, USER, enteredPassword);
      this.goToNextScreenAfterLogin(screen);
    }
    return true;
  }

  public static goToNextScreenAfterLogin(screen: any) {
    const status = LocalStorageService.getLoginStatus();
    const uriParams = querystringify.parse(window.location.search) as {
      redirectUri?: string;
    };
    if (status == EAccountStatus.ForceResetPassword.toString()) {
      screen.props.navigator.goToResetPasswordScreen();
    } else if (
      status == EAccountStatus.ShouldActivated.toString() ||
      status == EAccountStatus.TwoFactorAuthentication.toString()
    ) {
      screen.props.navigator.goToVerificationCodeScreen();
    } else if (status == EAccountStatus.Valid.toString() && Object.keys(uriParams).length === 0) {
      screen.props.navigator.gotoStartingScreen();
    } else if (status == EAccountStatus.Valid.toString() && Object.keys(uriParams).length > 0) {
      screen.props.navigator.gotoUrl(uriParams.redirectUri);
    }
    return true;
  }

  public static goToSignInActivity(screen: any) {
    if (LocalStorageService.getResetPasswordStatus() === EAccountStatus.ForceResetPassword.toString()) {
      LocalStorageService.setResetPasswordStatus("");
      return;
    }

    if (LocalStorageService.getResetPasswordStatus() == EAccountStatus.Valid.toString()) {
      LocalStorageService.setResetPasswordStatus("");
      HelperService.gotoLogin();
    } else {
      LocalStorageService.setResetPasswordStatus("");
      LocalStorageService.clearToken();
      window.userInfo = undefined;
      screen.props.navigator.gotoStartingScreen("/");
    }
  }

  public static async goToNextScreenAfterVerifyCode(screen: any) {
    const status = LocalStorageService.getLoginStatus();
    const verificationStatus = LocalStorageService.getVerificationStatus();
    if (status == EAccountStatus.ShouldActivated.toString()) {
      await this.signin(this, USER, enteredPassword);
      this.goToNextScreenAfterLogin(screen);
    } else if (status == EAccountStatus.TwoFactorAuthentication.toString()) {
      await this.signinWithVerificationCode();
      this.goToNextScreenAfterLogin(screen);
    } else if (verificationStatus === "true") {
      screen.props.navigator.goToResetPasswordScreen();
    }
    return true;
  }

  public static goToVerificationCodeActivity(screen: {
    props: { navigator: { goToVerificationCodeScreen: () => void } };
  }) {
    const email = LocalStorageService.getForgotPasswordEmail();
    if (email) screen.props.navigator.goToVerificationCodeScreen();
  }

  public static async forgotPassword(
    _screen: any,
    username: string,
    dontSendEmail?: boolean,
    language?: string
  ): Promise<any> {
    USER = username;
    const credientials = {
      email: username,
      dontSendEmail: dontSendEmail || false,
      language: language || ""
    } as IForgotPasswordDto;

    await UserService.ForgotPassword(credientials);
  }

  // createUser moved to BaseReactSystemFunctions (RNM-0133): its body was a one-line UserService/
  // ServerFilesService call, so the shared seam owns it with the route made explicit.

  // createUserWithPassword moved to BaseReactSystemFunctions (RNM-0133): its body was a one-line UserService/
  // ServerFilesService call, so the shared seam owns it with the route made explicit.

  public static async resetPassword(
    _screen: any,
    newpassword: string,
    dontSendEmail?: boolean,
    language?: string
  ): Promise<void> {
    const credientials = {
      newPassword: newpassword,
      token: TOKEN,
      UserName: USER,
      dontSendEmail: dontSendEmail || false,
      language: language || ""
    } as IResetPasswordWithTokenDto;
    enteredPassword = newpassword;
    const res = await UserService.ResetPassword(credientials);

    if (KMainFunctions.IsResStatus2XX(res)) {
      LocalStorageService.setResetPasswordStatus(EAccountStatus.Valid);
    } else {
      LocalStorageService.setResetPasswordStatus(EAccountStatus.ForceResetPassword);
    }
  }

  // addUserToRole / removeUserFromRole / enableUser / disableUser moved to BaseReactSystemFunctions
  // (RNM-0103). Inherited unchanged — a body of the same name here would shadow the shared one.

  // signin: _signin,
  // signup: _signup,
  // createUser: _createUser,
  // getMyUsername: _getMyUsername,
  // sendResetPasswordMail: _sendResetPasswordMail,
  // resetPassword: _resetPassword,
  // changePassword: _changePassword,
  // logout: _logout,
  // hasRole: _hasRole,
  // hasOneOfRoles: _hasOneOfRoles,

  public static sendResetPasswordMail(_val: string) {
    console.log("TODO!");
  }

  public static value(
    screen: any,
    val: any,
    varName?: string,
    actionName?: string,
    pkFieldName?: string,
    targetField?: string
  ) {
    if (
      actionName &&
      actionName.length > 0 &&
      pkFieldName &&
      pkFieldName.length > 0 &&
      targetField &&
      targetField.length > 0 &&
      pkFieldName !== targetField
    ) {
      // KOA-17603 — Searchable = true makes the generator name the ref
      // `<name>_kuikaAutoCompleteRef` (renderer becomes AutoComplete). Both spellings hold the
      // same KSelectBox and expose getAllData(); accept either, as getSearchValue() already does.
      const selectBoxRef =
        screen[`${val}_kuikaSelectBoxRef`]?.current?.getAllData != undefined
          ? screen[`${val}_kuikaSelectBoxRef`]
          : screen[`${val}_kuikaAutoCompleteRef`];
      if (varName != undefined && selectBoxRef?.current?.getAllData != undefined) {
        const selectBoxOptionsProp = selectBoxRef.current.getAllData();
        if (selectBoxOptionsProp && selectBoxOptionsProp.find) {
          const result = selectBoxOptionsProp.find(
            (x: { [x: string]: any }) => x[pkFieldName] == screen.props.form.getFieldValue(val)
          );
          if (result && result[targetField] !== undefined) return result[targetField];
        }
      } else {
        if (Array.isArray(screen.props.form.getFieldValue(val))) {
          const result = screen.state[actionName]?.filter((x: { [x: string]: any }) =>
            screen.props.form.getFieldValue?.(val)?.includes?.(x?.[pkFieldName])
          );
          if (result && result.length > 0 && result?.[0] && result?.[0]?.[targetField] !== undefined) {
            return result?.map?.((x: { [x: string]: any }) => x?.[targetField]);
          }
        }
        const result = screen.state[actionName]?.find(
          (x: { [x: string]: any }) => x[pkFieldName] == screen.props.form.getFieldValue(val)
        );
        if (result && result[targetField] !== undefined) return result[targetField];
      }
    }
    if (
      varName != undefined &&
      screen[`${val}_kuikaMultiSelectRef`] != undefined &&
      screen[`${val}_kuikaMultiSelectRef`] != null &&
      screen[`${val}_kuikaMultiSelectRef`].current != undefined &&
      screen[`${val}_kuikaMultiSelectRef`].current != null &&
      screen[`${val}_kuikaMultiSelectRef`].current.getAllData != undefined
    ) {
      const selectBoxOptionsProp = screen[`${val}_kuikaMultiSelectRef`].current.getAllData();
      if (selectBoxOptionsProp && selectBoxOptionsProp.find) {
        const result = selectBoxOptionsProp?.filter((x: { [x: string]: any }) =>
          screen.props.form.getFieldValue?.(val)?.includes?.(x?.[pkFieldName])
        );
        if (result && result.length > 0 && result?.[0] && result?.[0]?.[targetField] !== undefined) {
          return result?.map?.((x: { [x: string]: any }) => x?.[targetField]);
        }
      }
    }

    if (
      varName != undefined &&
      screen[`${val}_kuikaNoneRef`] != undefined &&
      screen[`${val}_kuikaNoneRef`] != null &&
      screen[`${val}_kuikaNoneRef`].current != undefined &&
      screen[`${val}_kuikaNoneRef`].current != null
    ) {
      const bigFileUploadRef = screen[`${val}_kuikaNoneRef`].current;
      if (varName == "fileId") return bigFileUploadRef.getLastFileId?.() ?? "";
      if (varName == "fileName") return bigFileUploadRef.getLastFileName?.() ?? "";
      if (varName == "fileIds") return bigFileUploadRef.getFileIds?.() ?? [];
      if (varName == "fileNames") return bigFileUploadRef.getFileNames?.() ?? [];
    }

    if (
      varName != undefined &&
      screen[`${val}_kuikaRecaptchaRef`] != undefined &&
      screen[`${val}_kuikaRecaptchaRef`] != null &&
      screen[`${val}_kuikaRecaptchaRef`].current != undefined &&
      screen[`${val}_kuikaRecaptchaRef`].current != null
    ) {
      if (varName == "token") return screen[`${val}_kuikaRecaptchaRef`].current.state.token;
    }

    if (
      varName != undefined &&
      screen[`${val}_kuikaTableRef`] != undefined &&
      screen[`${val}_kuikaTableRef`] != null &&
      screen[`${val}_kuikaTableRef`].current != undefined &&
      screen[`${val}_kuikaTableRef`].current != null &&
      screen[`${val}_kuikaTableRef`].current.getSelectedRowData != undefined
    ) {
      const currentTableRef = screen[`${val}_kuikaTableRef`].current;

      // Table-level properties belong to the table component itself, not to row data.
      // Resolve them directly from the table ref before nested-table parent row lookup,
      // which only contains column fields and would return undefined for these.
      if (varName.charAt(0) === ".") varName = varName.substr(1);
      if (varName === "k_rowIndex") {
        return currentTableRef.getSelectedIndex();
      }
      if (varName === "k_columnIndex") {
        return currentTableRef.getSelectedColumnIndex();
      }
      if (varName === "selectedValues") {
        return currentTableRef.getSelectedValues();
      }
      if (varName === "selectedCount") {
        // KOA-18124: without this branch the read falls through to the selected ROW data below and
        // yields undefined, which no comparison against 0 can ever satisfy — so a component gated on
        // "selectedCount isNotEqualTo 0" stayed visible after every row was unselected.
        return currentTableRef.getSelectedCount();
      }
      if (varName === "dataSource") {
        return currentTableRef.getDataSource();
      }

      const parentTableId = currentTableRef?.getParentTableIdIfExist();
      const newVal = val.replace(currentTableRef?.props?.id, parentTableId);
      const parentTableRef = this.getParentOfBaseTableElementRef(screen, newVal);

      if (parentTableRef?.current) {
        const dataSourcePath = currentTableRef.props?.dataSourceOriginal?.match(
          /\[datafield:((?:(?!\[datafield:).)*)\]/
        );
        const dataSourcePathValue = dataSourcePath ? dataSourcePath[1] : "";

        const nestedTableRowIdx = parentTableRef.current.getNestedTableSelectedIndex(
          document.getElementById(parentTableId),
          currentTableRef?.props?.id
        );

        if (
          nestedTableRowIdx !== undefined &&
          parentTableRef.current.getSelectedRowData()[dataSourcePathValue] !== undefined &&
          parentTableRef.current.getSelectedRowData()[dataSourcePathValue][nestedTableRowIdx] !== undefined
        ) {
          return parentTableRef.current.getSelectedRowData()[dataSourcePathValue][nestedTableRowIdx][varName];
        }
      }
      const rowData = screen[`${val}_kuikaTableRef`].current.getSelectedRowData();
      if (!rowData) return undefined;
      if (_.isEmpty(varName)) return rowData;
      // Use path resolving for nested fields with modifiers like [first], [last], [selected]
      return varName.includes(".") || varName.includes("[")
        ? ReactSystemFunctions.getValueFromPath(
            rowData,
            varName,
            screen[`${val}_kuikaTableRef`].current.getSelectedIndex()
          )
        : rowData[varName];
    }

    if (
      varName != undefined &&
      screen[`${val}_kuikaKanbanBoardRef`] != undefined &&
      screen[`${val}_kuikaKanbanBoardRef`] != null &&
      screen[`${val}_kuikaKanbanBoardRef`].current != undefined &&
      screen[`${val}_kuikaKanbanBoardRef`].current != null
    ) {
      if (varName === "laneId" || targetField === "k_laneId") {
        return screen[`${val}_kuikaKanbanBoardRef`].current.getLaneId();
      }

      if (varName === "laneTitle" || targetField === "k_laneTitle") {
        return screen[`${val}_kuikaKanbanBoardRef`].current.getLaneTitle();
      }

      if (varName === "laneLabel" || targetField === "k_laneLabel") {
        return screen[`${val}_kuikaKanbanBoardRef`].current.getLaneLabel();
      }

      if (varName === "laneDroppable" || targetField === "k_laneDroppable") {
        return screen[`${val}_kuikaKanbanBoardRef`].current.getLaneDroppable();
      }

      if (varName === "laneIndex" || targetField === "k_laneIndex") {
        return screen[`${val}_kuikaKanbanBoardRef`].current.getLaneIndex();
      }

      if (varName === "laneTargetIndex" || targetField === "k_laneTargetIndex") {
        return screen[`${val}_kuikaKanbanBoardRef`].current.getLaneTargetIndex();
      }

      if (varName === "cardId" || targetField === "k_cardId") {
        return screen[`${val}_kuikaKanbanBoardRef`].current.getCardId();
      }

      if (varName === "cardLaneId" || targetField === "k_cardLaneId") {
        return screen[`${val}_kuikaKanbanBoardRef`].current.getCardLaneId();
      }

      if (varName === "cardTargetLaneId" || targetField === "k_cardTargetLaneId") {
        return screen[`${val}_kuikaKanbanBoardRef`].current.getCardTargetLaneId();
      }

      if (varName === "cardTitle" || targetField === "k_cardTitle") {
        return screen[`${val}_kuikaKanbanBoardRef`].current.getCardTitle();
      }

      if (varName === "cardLabel" || targetField === "k_cardLabel") {
        return screen[`${val}_kuikaKanbanBoardRef`].current.getCardLabel();
      }

      if (varName === "cardSubTitle" || targetField === "k_cardSubTitle") {
        return screen[`${val}_kuikaKanbanBoardRef`].current.getCardSubTitle();
      }

      if (varName === "cardDescription" || targetField === "k_cardDescription") {
        return screen[`${val}_kuikaKanbanBoardRef`].current.getCardDescription();
      }

      if (varName === "cardEscalationText" || targetField === "k_cardEscalationText") {
        return screen[`${val}_kuikaKanbanBoardRef`].current.getCardEscalationText();
      }

      if (varName === "cardDraggable" || targetField === "k_cardDraggable") {
        return screen[`${val}_kuikaKanbanBoardRef`].current.getCardDraggable();
      }

      if (varName === "cardIndex" || targetField === "k_cardIndex") {
        return screen[`${val}_kuikaKanbanBoardRef`].current.getCardIndex();
      }

      if (varName === "cardTargetIndex" || targetField === "k_cardTargetIndex") {
        return screen[`${val}_kuikaKanbanBoardRef`].current.getCardTargetIndex();
      }

      if (varName.charAt(0) === ".") varName = varName.substr(1);

      const keys = varName.split(".");

      // if selected card/lane data requested
      if (keys.length > 1) {
        let value = keys.reduce(
          (obj, key) => obj[key?.replaceAll("?", "")],
          screen[`${val}_kuikaKanbanBoardRef`].current
        );

        return value;
      }

      return (
        screen[`${val}_kuikaKanbanBoardRef`].current.getSelectedData() &&
        screen[`${val}_kuikaKanbanBoardRef`].current.getSelectedData()[varName]
      );
    }

    if (
      varName != undefined &&
      screen[`${val}_kuikaNodeTreeRef`] != undefined &&
      screen[`${val}_kuikaNodeTreeRef`] != null &&
      screen[`${val}_kuikaNodeTreeRef`].current != undefined &&
      screen[`${val}_kuikaNodeTreeRef`].current != null
    ) {
      if (varName.charAt(0) === ".") varName = varName.substr(1);

      const keys = varName.split(".");

      if (keys.length > 1) {
        let value = keys.reduce((obj, key) => obj[key?.replaceAll("?", "")], screen[`${val}_kuikaNodeTreeRef`].current);

        return value;
      }

      return (
        screen[`${val}_kuikaNodeTreeRef`].current.getSelectedData() &&
        screen[`${val}_kuikaNodeTreeRef`].current.getSelectedData()[varName]
      );
    }

    if (
      varName != undefined &&
      screen[`${val}_kuikaGalleryViewRef`] != undefined &&
      screen[`${val}_kuikaGalleryViewRef`] != null &&
      screen[`${val}_kuikaGalleryViewRef`].current != undefined &&
      screen[`${val}_kuikaGalleryViewRef`].current != null &&
      screen[`${val}_kuikaGalleryViewRef`].current.getSelectedRowData != undefined
    ) {
      const currentGalleryRef = screen[`${val}_kuikaGalleryViewRef`].current;

      const parentTableId = currentGalleryRef?.getParentTableIdIfExist?.();
      const newVal = val.replace(currentGalleryRef?.props?.id, parentTableId);

      const parentTableRef = this.getParentOfBaseTableElementRef(screen, newVal);

      if (parentTableRef?.current) {
        const dataSourcePath = currentGalleryRef.props?.dataSourceOriginal?.match(
          /\[datafield:((?:(?!\[datafield:).)*)\]/
        );
        const dataSourcePathValue = dataSourcePath ? dataSourcePath[1] : "";

        const nestedTableRowIdx = parentTableRef.current.getNestedTableSelectedIndex(
          document.getElementById(parentTableId),
          currentGalleryRef?.props?.id
        );

        if (
          nestedTableRowIdx !== undefined &&
          parentTableRef.current.getSelectedRowData()[dataSourcePathValue] !== undefined &&
          parentTableRef.current.getSelectedRowData()[dataSourcePathValue][nestedTableRowIdx] !== undefined
        ) {
          return parentTableRef.current.getSelectedRowData()[dataSourcePathValue][nestedTableRowIdx][varName];
        }
      }

      if (varName.charAt(0) === ".") varName = varName.substr(1);

      if (varName === "k_rowIndex") {
        return screen[`${val}_kuikaGalleryViewRef`].current.getSelectedIndex();
      }

      const rowData = screen[`${val}_kuikaGalleryViewRef`].current.getSelectedRowData();
      if (!rowData) return undefined;
      if (_.isEmpty(varName)) return rowData;
      // Use path resolving for nested fields with modifiers like [first], [last], [selected]
      return varName.includes(".") || varName.includes("[")
        ? ReactSystemFunctions.getValueFromPath(
            rowData,
            varName,
            screen[`${val}_kuikaGalleryViewRef`].current.getSelectedIndex()
          )
        : rowData[varName];
    }
    if (
      varName != undefined &&
      screen[`${val}_kuikaCarouselRef`] != undefined &&
      screen[`${val}_kuikaCarouselRef`] != null &&
      screen[`${val}_kuikaCarouselRef`].current != undefined &&
      screen[`${val}_kuikaCarouselRef`].current != null &&
      screen[`${val}_kuikaCarouselRef`].current.getSelectedRowData != undefined
    ) {
      const currentCarouselRef = screen[`${val}_kuikaCarouselRef`].current;

      const parentTableId = currentCarouselRef?.getParentTableIdIfExist?.();
      const newVal = val.replace(currentCarouselRef?.props?.id, parentTableId);

      const parentTableRef = this.getParentOfBaseTableElementRef(screen, newVal);

      if (parentTableRef?.current) {
        const dataSourcePath = currentCarouselRef.props?.dataSourceOriginal?.match(
          /\[datafield:((?:(?!\[datafield:).)*)\]/
        );
        const dataSourcePathValue = dataSourcePath ? dataSourcePath[1] : "";

        const nestedTableRowIdx = parentTableRef.current.getNestedTableSelectedIndex(
          document.getElementById(parentTableId),
          currentCarouselRef?.props?.id
        );

        if (
          nestedTableRowIdx !== undefined &&
          parentTableRef.current.getSelectedRowData()[dataSourcePathValue] !== undefined &&
          parentTableRef.current.getSelectedRowData()[dataSourcePathValue][nestedTableRowIdx] !== undefined
        ) {
          return parentTableRef.current.getSelectedRowData()[dataSourcePathValue][nestedTableRowIdx][varName];
        }
      }

      if (varName.charAt(0) === ".") varName = varName.substr(1);

      if (varName === "k_rowIndex") {
        return screen[`${val}_kuikaCarouselRef`].current.getSelectedIndex();
      }

      const rowData = screen[`${val}_kuikaCarouselRef`].current.getCarouselCurrentData();
      if (!rowData) return undefined;
      if (_.isEmpty(varName)) return rowData;
      // Use path resolving for nested fields with modifiers like [first], [last], [selected]
      return varName.includes(".") || varName.includes("[")
        ? ReactSystemFunctions.getValueFromPath(
            rowData,
            varName,
            screen[`${val}_kuikaCarouselRef`].current.getSelectedIndex()
          )
        : rowData[varName];
    }
    if (
      varName != undefined &&
      screen[`${val}_kuikaFlexGridRef`] != undefined &&
      screen[`${val}_kuikaFlexGridRef`] != null &&
      screen[`${val}_kuikaFlexGridRef`].current != undefined &&
      screen[`${val}_kuikaFlexGridRef`].current != null &&
      screen[`${val}_kuikaFlexGridRef`].current.getSelectedRowData != undefined
    ) {
      const currentFlexGridRef = screen[`${val}_kuikaFlexGridRef`].current;

      const parentTableId = currentFlexGridRef?.getParentTableIdIfExist?.();
      const newVal = val.replace(currentFlexGridRef?.props?.id, parentTableId);

      const parentTableRef = this.getParentOfBaseTableElementRef(screen, newVal);

      if (parentTableRef?.current) {
        const dataSourcePath = currentFlexGridRef.props?.dataSourceOriginal?.match(
          /\[datafield:((?:(?!\[datafield:).)*)\]/
        );
        const dataSourcePathValue = dataSourcePath ? dataSourcePath[1] : "";

        const nestedTableRowIdx = parentTableRef.current.getNestedTableSelectedIndex(
          document.getElementById(parentTableId),
          currentFlexGridRef?.props?.id
        );

        if (
          nestedTableRowIdx !== undefined &&
          parentTableRef.current.getSelectedRowData()[dataSourcePathValue] !== undefined &&
          parentTableRef.current.getSelectedRowData()[dataSourcePathValue][nestedTableRowIdx] !== undefined
        ) {
          return parentTableRef.current.getSelectedRowData()[dataSourcePathValue][nestedTableRowIdx][varName];
        }
      }

      if (varName.charAt(0) === ".") varName = varName.substr(1);

      if (varName === "k_rowIndex") {
        return screen[`${val}_kuikaFlexGridRef`].current.getSelectedIndex();
      }

      const rowData = screen[`${val}_kuikaFlexGridRef`].current.getSelectedRowData();
      if (!rowData) return undefined;
      if (_.isEmpty(varName)) return rowData;
      // Use path resolving for nested fields with modifiers like [first], [last], [selected]
      return varName.includes(".") || varName.includes("[")
        ? ReactSystemFunctions.getValueFromPath(
            rowData,
            varName,
            screen[`${val}_kuikaFlexGridRef`].current.getSelectedIndex()
          )
        : rowData[varName];
    }
    if (
      varName != undefined &&
      screen[`${val}_kuikaHorizontalTableRef`] != undefined &&
      screen[`${val}_kuikaHorizontalTableRef`] != null &&
      screen[`${val}_kuikaHorizontalTableRef`].current != undefined &&
      screen[`${val}_kuikaHorizontalTableRef`].current != null &&
      screen[`${val}_kuikaHorizontalTableRef`].current.getSelectedRowData != undefined
    ) {
      const currentHorizontalTableRef = screen[`${val}_kuikaHorizontalTableRef`].current;

      const parentTableId = currentHorizontalTableRef?.getParentTableIdIfExist?.();
      const newVal = val.replace(currentHorizontalTableRef?.props?.id, parentTableId);

      const parentTableRef = this.getParentOfBaseTableElementRef(screen, newVal);

      if (parentTableRef?.current) {
        const dataSourcePath = currentHorizontalTableRef.props?.dataSourceOriginal?.match(
          /\[datafield:((?:(?!\[datafield:).)*)\]/
        );
        const dataSourcePathValue = dataSourcePath ? dataSourcePath[1] : "";

        const nestedTableRowIdx = parentTableRef.current.getNestedTableSelectedIndex(
          document.getElementById(parentTableId),
          currentHorizontalTableRef?.props?.id
        );

        if (
          nestedTableRowIdx !== undefined &&
          parentTableRef.current.getSelectedRowData()[dataSourcePathValue] !== undefined &&
          parentTableRef.current.getSelectedRowData()[dataSourcePathValue][nestedTableRowIdx] !== undefined
        ) {
          return parentTableRef.current.getSelectedRowData()[dataSourcePathValue][nestedTableRowIdx][varName];
        }
      }

      if (varName.charAt(0) === ".") varName = varName.substr(1);

      if (varName === "k_rowIndex") {
        return screen[`${val}_kuikaHorizontalTableRef`].current.getSelectedIndex();
      }

      const rowData = screen[`${val}_kuikaHorizontalTableRef`].current.getSelectedRowData();
      if (!rowData) return undefined;
      if (_.isEmpty(varName)) return rowData;
      // Use path resolving for nested fields with modifiers like [first], [last], [selected]
      return varName.includes(".") || varName.includes("[")
        ? ReactSystemFunctions.getValueFromPath(
            rowData,
            varName,
            screen[`${val}_kuikaHorizontalTableRef`].current.getSelectedIndex()
          )
        : rowData[varName];
    }
    if (
      varName != undefined &&
      screen[`${val}_kuikaMarqueeRef`] != undefined &&
      screen[`${val}_kuikaMarqueeRef`] != null &&
      screen[`${val}_kuikaMarqueeRef`].current != undefined &&
      screen[`${val}_kuikaMarqueeRef`].current != null &&
      screen[`${val}_kuikaMarqueeRef`].current.getSelectedRowData != undefined
    ) {
      if (varName.charAt(0) === ".") varName = varName.substr(1);

      if (varName === "k_rowIndex") {
        return screen[`${val}_kuikaMarqueeRef`].current.getSelectedIndex();
      }

      const rowData = screen[`${val}_kuikaMarqueeRef`].current.getSelectedRowData();
      if (!rowData) return undefined;
      // Use path resolving for nested fields with modifiers like [first], [last], [selected]
      return varName.includes(".") || varName.includes("[")
        ? ReactSystemFunctions.getValueFromPath(
            rowData,
            varName,
            screen[`${val}_kuikaMarqueeRef`].current.getSelectedIndex()
          )
        : rowData[varName];
    }
    if (
      varName != undefined &&
      screen[`${val}_kuikaPaginationRef`] != undefined &&
      screen[`${val}_kuikaPaginationRef`] != null
    ) {
      if (
        screen[`${val}_kuikaPaginationRef`].current != undefined &&
        screen[`${val}_kuikaPaginationRef`].current != null &&
        screen[`${val}_kuikaPaginationRef`].current.getCurrentData != undefined
      ) {
        if (varName.charAt(0) === ".") varName = varName.substr(1);
        return (
          screen[`${val}_kuikaPaginationRef`].current.getCurrentData() &&
          screen[`${val}_kuikaPaginationRef`].current.getCurrentData()[varName]
        );
      }
      if (varName === "current") return 1;
      return 10;
    }
    if (
      varName != undefined &&
      screen[`${val}_kuikaSelectBoxRef`] != undefined &&
      screen[`${val}_kuikaSelectBoxRef`] != null &&
      screen[`${val}_kuikaSelectBoxRef`].current != undefined &&
      screen[`${val}_kuikaSelectBoxRef`].current != null &&
      screen[`${val}_kuikaSelectBoxRef`].current.getSearchValue != undefined
    ) {
      if (targetField && targetField.charAt(0) === ".") targetField = targetField.substr(1);
      if (targetField === "k_searchValue") {
        return screen[`${val}_kuikaSelectBoxRef`].current.getSearchValue();
      }
    } else if (
      varName != undefined &&
      screen[`${val}_kuikaMultiSelectRef`] != undefined &&
      screen[`${val}_kuikaMultiSelectRef`] != null &&
      screen[`${val}_kuikaMultiSelectRef`].current != undefined &&
      screen[`${val}_kuikaMultiSelectRef`].current != null &&
      screen[`${val}_kuikaMultiSelectRef`].current.getSearchValue != undefined
    ) {
      if (targetField && targetField.charAt(0) === ".") targetField = targetField.substr(1);
      if (targetField === "k_searchValue") {
        return screen[`${val}_kuikaMultiSelectRef`].current.getSearchValue();
      }
    } else if (
      varName != undefined &&
      screen[`${val}_kuikaAutoCompleteRef`] != undefined &&
      screen[`${val}_kuikaAutoCompleteRef`] != null &&
      screen[`${val}_kuikaAutoCompleteRef`].current != undefined &&
      screen[`${val}_kuikaAutoCompleteRef`].current != null &&
      screen[`${val}_kuikaAutoCompleteRef`].current.getSearchValue != undefined
    ) {
      if (targetField && targetField.charAt(0) === ".") targetField = targetField.substr(1);
      if (targetField === "k_searchValue") {
        return screen[`${val}_kuikaAutoCompleteRef`].current.getSearchValue();
      }
    } else if (
      varName != undefined &&
      screen[`${val}_kuikaGoogleMapsRef`] != undefined &&
      screen[`${val}_kuikaGoogleMapsRef`] != null &&
      screen[`${val}_kuikaGoogleMapsRef`].current != undefined &&
      screen[`${val}_kuikaGoogleMapsRef`].current != null &&
      screen[`${val}_kuikaGoogleMapsRef`].current.getLatValue != undefined
    ) {
      if (targetField && targetField.charAt(0) === ".") targetField = targetField.substr(1);
      // The Maps designators arrive as the picker label ("Latitude"), the `k_` field name
      // ("k_latitude") or the lower-cased prop name ("latitude") depending on the emitter; all
      // three name the same component-level value, not a column of the selected row.
      const mapsDesignator: string = varName.replace(/^\.?k_/, "").toLowerCase();
      if (mapsDesignator === "latitude") {
        return screen[`${val}_kuikaGoogleMapsRef`].current.getLatValue();
      }
      if (mapsDesignator === "longitude") {
        return screen[`${val}_kuikaGoogleMapsRef`].current.getLngValue();
      }
      if (mapsDesignator === "circleradius") {
        return screen[`${val}_kuikaGoogleMapsRef`].current.getCircleRadiusValue?.() ?? "";
      }
      if (varName.charAt(0) === ".") varName = varName.substr(1);
      return (
        screen[`${val}_kuikaGoogleMapsRef`].current.getSelectedRowData() &&
        screen[`${val}_kuikaGoogleMapsRef`].current.getSelectedRowData()[varName]
      );
    } else if (
      varName != undefined &&
      screen[`${val}_kuikaChatRef`] != undefined &&
      screen[`${val}_kuikaChatRef`] != null &&
      screen[`${val}_kuikaChatRef`].current != undefined &&
      screen[`${val}_kuikaChatRef`].current != null &&
      screen[`${val}_kuikaChatRef`].current.getMessage != undefined &&
      screen[`${val}_kuikaChatRef`].current.getCurrentlyEditingMessageId != undefined
    ) {
      if (varName === "message" || targetField === "k_message") {
        return screen[`${val}_kuikaChatRef`].current.getMessage();
      }

      if (varName === "currentlyEditingMessageId" || targetField === "k_currentlyEditingMessageId") {
        return screen[`${val}_kuikaChatRef`].current.getCurrentlyEditingMessageId();
      }

      if (varName === "messageIdToBeDeleted" || targetField === "k_messageIdToBeDeleted") {
        return screen[`${val}_kuikaChatRef`].current.messageIdToBeDeleted;
      }
    } else if (
      varName != undefined &&
      screen[`${val}_kuikaPlacesAutocompleteInputRef`] != undefined &&
      screen[`${val}_kuikaPlacesAutocompleteInputRef`] != null &&
      screen[`${val}_kuikaPlacesAutocompleteInputRef`].current != undefined &&
      screen[`${val}_kuikaPlacesAutocompleteInputRef`].current != null &&
      screen[`${val}_kuikaPlacesAutocompleteInputRef`].current.getLatitude != undefined
    ) {
      // The picker label ("Latitude") and the metadata prop name ("latitude") both reach here
      // depending on which emitter produced the read; the compound "value" falls through to the form.
      const locationField: string = String(varName).toLowerCase();
      if (locationField === "latitude" || targetField === "k_latitude") {
        return screen[`${val}_kuikaPlacesAutocompleteInputRef`].current.getLatitude();
      }
      if (locationField === "longitude" || targetField === "k_longitude") {
        return screen[`${val}_kuikaPlacesAutocompleteInputRef`].current.getLongitude();
      }
      if (locationField === "address" || targetField === "k_address") {
        return screen[`${val}_kuikaPlacesAutocompleteInputRef`].current.getAddress();
      }
    } else if (
      varName != undefined &&
      screen[`${val}_kuikaLocationPickerComponentRef`] &&
      screen[`${val}_kuikaLocationPickerComponentRef`] != undefined &&
      screen[`${val}_kuikaLocationPickerComponentRef`] != null &&
      screen[`${val}_kuikaLocationPickerComponentRef`].current != undefined &&
      screen[`${val}_kuikaLocationPickerComponentRef`].current != null &&
      screen[`${val}_kuikaLocationPickerComponentRef`].current.getLatitude != undefined
    ) {
      if (varName === "Latitude" || targetField === "k_latitude") {
        return screen[`${val}_kuikaLocationPickerComponentRef`].current.getLatitude();
      }
      if (varName === "Longitude" || targetField === "k_longitude") {
        return screen[`${val}_kuikaLocationPickerComponentRef`].current.getLongitude();
      }
    } else if (
      varName != undefined &&
      screen[`${val}_kuikaStepperComponentRef`] &&
      screen[`${val}_kuikaStepperComponentRef`] != undefined &&
      screen[`${val}_kuikaStepperComponentRef`] != null &&
      screen[`${val}_kuikaStepperComponentRef`].current != undefined &&
      screen[`${val}_kuikaStepperComponentRef`].current != null &&
      screen[`${val}_kuikaStepperComponentRef`].current.getIndex != undefined
    ) {
      let index = screen[`${val}_kuikaStepperComponentRef`].current.getIndex();
      if (index === null || index === undefined || index < 0) return;

      return index + 1;
    } else if (
      screen[`${val}_kuikaWebViewRef`] &&
      screen[`${val}_kuikaWebViewRef`] != undefined &&
      screen[`${val}_kuikaWebViewRef`] != null &&
      screen[`${val}_kuikaWebViewRef`].current != undefined &&
      screen[`${val}_kuikaWebViewRef`].current != null &&
      screen[`${val}_kuikaWebViewRef`].current.getUrl != undefined
    ) {
      if (varName === "url" || targetField === "k_url") {
        return screen[`${val}_kuikaWebViewRef`].current.getUrl();
      }
    } else if (
      screen?.[`${val}_kuikaCalendarRef`]?.current != undefined &&
      screen?.[`${val}_kuikaCalendarRef`]?.current != null
    ) {
      if (varName === "panel" || varName === "k_panel" || targetField === "k_panel") {
        return screen[`${val}_kuikaCalendarRef`].current?.getPanel?.();
      }

      if (varName === "currentDate" || varName === "k_currentDate" || targetField === "k_currentDate") {
        return screen[`${val}_kuikaCalendarRef`].current?.getCurrentDate?.();
      }

      if (varName === "currentDay" || varName === "k_currentDay" || targetField === "k_currentDay") {
        return screen[`${val}_kuikaCalendarRef`].current.getCurrentDay?.();
      }

      if (varName === "currentMonth" || varName === "k_currentMonth" || targetField === "k_currentMonth") {
        return screen[`${val}_kuikaCalendarRef`].current.getCurrentMonth?.();
      }

      if (varName === "currentYear" || varName === "k_currentYear" || targetField === "k_currentYear") {
        return screen[`${val}_kuikaCalendarRef`].current.getCurrentYear?.();
      }

      if (
        varName === "currentRangeStart" ||
        varName === "k_currentRangeStart" ||
        targetField === "k_currentRangeStart"
      ) {
        return screen[`${val}_kuikaCalendarRef`].current.getCurrentRangeStart?.();
      }

      if (varName === "currentRangeEnd" || varName === "k_currentRangeEnd" || targetField === "k_currentRangeEnd") {
        return screen[`${val}_kuikaCalendarRef`].current.getCurrentRangeEnd?.();
      }

      if (
        varName === "k_eventId" ||
        varName === "k_currentEvent.k_eventId" ||
        targetField === "k_eventId" ||
        targetField === "k_currentEvent.k_eventId"
      ) {
        return screen[`${val}_kuikaCalendarRef`].current.getCurrentEvent?.()?.id;
      }

      if (
        varName === "k_eventTitle" ||
        varName === "k_currentEvent.k_eventTitle" ||
        targetField === "k_eventTitle" ||
        targetField === "k_currentEvent.k_eventTitle"
      ) {
        return screen[`${val}_kuikaCalendarRef`].current.getCurrentEvent?.()?.title;
      }

      if (
        varName === "k_eventStartDate" ||
        varName === "k_currentEvent.k_eventStartDate" ||
        targetField === "k_eventStartDate" ||
        targetField === "k_currentEvent.k_eventStartDate"
      ) {
        return screen[`${val}_kuikaCalendarRef`].current.getCurrentEvent?.()?.start;
      }

      if (
        varName === "k_eventEndDate" ||
        varName === "k_currentEvent.k_eventEndDate" ||
        targetField === "k_eventEndDate" ||
        targetField === "k_currentEvent.k_eventEndDate"
      ) {
        return screen[`${val}_kuikaCalendarRef`].current.getCurrentEvent?.()?.end;
      }

      if (
        varName === "k_eventColor" ||
        varName === "k_currentEvent.k_eventColor" ||
        targetField === "k_eventColor" ||
        targetField === "k_currentEvent.k_eventColor"
      ) {
        return screen[`${val}_kuikaCalendarRef`].current.getCurrentEvent?.()?.backgroundColor;
      }

      return screen[`${val}_kuikaCalendarRef`].current.getCurrentEvent?.()?.[varName?.toLowerCase()];
    } else if (
      screen[`${val}_kuikaStopwatchRef`] &&
      screen[`${val}_kuikaStopwatchRef`] != undefined &&
      screen[`${val}_kuikaStopwatchRef`] != null &&
      screen[`${val}_kuikaStopwatchRef`].current != undefined &&
      screen[`${val}_kuikaStopwatchRef`].current != null &&
      screen[`${val}_kuikaStopwatchRef`].current.getValue != undefined
    ) {
      return screen[`${val}_kuikaStopwatchRef`].current.getValue();
    } else if (
      screen[`${val}_kuikaTreeRef`] &&
      screen[`${val}_kuikaTreeRef`] != undefined &&
      screen[`${val}_kuikaTreeRef`] != null &&
      screen[`${val}_kuikaTreeRef`].current != undefined &&
      screen[`${val}_kuikaTreeRef`].current != null
    ) {
      if (varName === "checkedKeys" && screen[`${val}_kuikaTreeRef`].current.getCheckedKeys != undefined) {
        return screen[`${val}_kuikaTreeRef`].current.getCheckedKeys();
      }
      if (screen[`${val}_kuikaTreeRef`].current.getSelectedData != undefined) {
        const selectedData = screen[`${val}_kuikaTreeRef`].current.getSelectedData();
        if (targetField && selectedData) {
          return selectedData[targetField];
        }
        if (varName && selectedData) {
          return selectedData[varName];
        }
        if (!varName && screen[`${val}_kuikaTreeRef`].current.getSelectedKey != undefined) {
          return screen[`${val}_kuikaTreeRef`].current.getSelectedKey();
        }
      }
    } else if (
      screen[`${val}_kuikaSiderMenuRef`] &&
      screen[`${val}_kuikaSiderMenuRef`] != undefined &&
      screen[`${val}_kuikaSiderMenuRef`] != null &&
      screen[`${val}_kuikaSiderMenuRef`].current != undefined &&
      screen[`${val}_kuikaSiderMenuRef`].current != null
    ) {
      // KOA-17852: Menu (SiderMenu) reads. The Menu's form value only holds
      // { selectedKey, collapsed, hamburgerCollapsed } — datasource rows and the clicked
      // item's data are only reachable through the component instance.
      const menuRef = screen[`${val}_kuikaSiderMenuRef`].current;
      // Selected-conversion reads emit the row field with a leading dot (".title"),
      // exactly like Table selected reads — strip it before resolving.
      if (varName && varName.charAt(0) === ".") varName = varName.substr(1);
      if ((varName === "selectedKey" || varName === "k_selectedKey") && menuRef.getSelectedKeyValue != undefined) {
        return menuRef.getSelectedKeyValue();
      }
      if (varName === "collapsed" && menuRef.getCollapsed != undefined) {
        return menuRef.getCollapsed();
      }
      if (varName === "hamburgerCollapsed" && menuRef.getHamburgerCollapsed != undefined) {
        return menuRef.getHamburgerCollapsed();
      }
      if (varName === "options" && menuRef.getDataSource != undefined) {
        const menuRows = menuRef.getDataSource();
        if (targetField && targetField.length > 0 && menuRows?.map) {
          // options > First/Last: the emitted `?.at?.(0 | -1)` picks from this field list.
          return menuRows.map((x: { [x: string]: any }) => x?.[targetField]);
        }
        return menuRows;
      }
      if (menuRef.getSelectedData != undefined) {
        // options > Selected: the emitted read passes the row field as varName.
        const selectedData = menuRef.getSelectedData();
        if (targetField && targetField.length > 0 && selectedData) {
          return selectedData[targetField];
        }
        if (varName && selectedData) {
          return selectedData[varName];
        }
      }
    } else if (
      screen[`${val}_kuikaDirectoryRef`] &&
      screen[`${val}_kuikaDirectoryRef`] != undefined &&
      screen[`${val}_kuikaDirectoryRef`] != null &&
      screen[`${val}_kuikaDirectoryRef`].current != undefined &&
      screen[`${val}_kuikaDirectoryRef`].current != null
    ) {
      const varNameLower = varName?.toLowerCase();
      if (varNameLower === "nodeid") return screen[`${val}_kuikaDirectoryRef`].current.getSelectedNodeId();
      if (varNameLower === "nodename") return screen[`${val}_kuikaDirectoryRef`].current.getSelectedNodeName();
      if (varNameLower === "isnodebranch") return screen[`${val}_kuikaDirectoryRef`].current.getSelectedNodeIsBranch();
      if (varNameLower === "selecteddocumentid")
        return screen[`${val}_kuikaDirectoryRef`].current.getSelectedDocumentId();
      if (varNameLower === "selectedfolderid") return screen[`${val}_kuikaDirectoryRef`].current.getSelectedFolderId();
      if (varNameLower === "selecteddocumentname")
        return screen[`${val}_kuikaDirectoryRef`].current.getSelectedDocumentName?.();
      if (varNameLower === "selectedfoldername")
        return screen[`${val}_kuikaDirectoryRef`].current.getSelectedFolderName?.();
      if (varNameLower === "selectednodename") return screen[`${val}_kuikaDirectoryRef`].current.getSelectedNodeName();
      if (varNameLower === "containedfolderid")
        return screen[`${val}_kuikaDirectoryRef`].current.getContainerFolderId?.();
      if (varNameLower === "selectedversionid")
        return screen[`${val}_kuikaDirectoryRef`].current.getSelectedVersionId?.();
      if (varNameLower === "selectednodetype")
        return screen[`${val}_kuikaDirectoryRef`].current.getSelectedNodeType?.();
      if (varNameLower === "selectedvirtualfolder")
        return screen[`${val}_kuikaDirectoryRef`].current.getSelectedVirtualFolder?.();
      if (varNameLower === "selectedlanguage")
        return screen[`${val}_kuikaDirectoryRef`].current.getSelectedLanguage?.();
      if (varNameLower === "selectedisdraft") return screen[`${val}_kuikaDirectoryRef`].current.getSelectedIsDraft?.();
      if (varNameLower === "selectedmimetype")
        return screen[`${val}_kuikaDirectoryRef`].current.getSelectedMimeType?.();
    } else if (screen[`${val}_kuikaDocumentRef`] && screen[`${val}_kuikaDocumentRef`].current) {
      const varNameLower = varName?.toLowerCase();
      if (varNameLower === "versionid") return screen[`${val}_kuikaDocumentRef`].current.getVersionId?.();
      if (varNameLower === "mode") return screen[`${val}_kuikaDocumentRef`].current.getMode?.();
    } else if (screen[`${val}_kuikaDocumentCompareRef`] && screen[`${val}_kuikaDocumentCompareRef`].current) {
      const varNameLower = varName?.toLowerCase();
      if (varNameLower === "leftversionid")
        return screen[`${val}_kuikaDocumentCompareRef`].current.getLeftVersionId?.();
      if (varNameLower === "rightversionid")
        return screen[`${val}_kuikaDocumentCompareRef`].current.getRightVersionId?.();
    } else if (screen[`${val}_kuikaDocumentUploaderRef`] && screen[`${val}_kuikaDocumentUploaderRef`].current) {
      const varNameLower = varName?.toLowerCase();
      if (varNameLower === "currentdocumentid")
        return screen[`${val}_kuikaDocumentUploaderRef`].current.getCurrentDocumentId?.();
      if (varNameLower === "currentversionid")
        return screen[`${val}_kuikaDocumentUploaderRef`].current.getCurrentVersionId?.();
      if (varNameLower === "currentfilename")
        return screen[`${val}_kuikaDocumentUploaderRef`].current.getCurrentFileName?.();
      if (varNameLower === "currentmimetype")
        return screen[`${val}_kuikaDocumentUploaderRef`].current.getCurrentMimeType?.();
    } else if (varName === undefined) return val;

    const formVal = screen.props.form.getFieldValue(val);
    if (formVal == undefined && varName == "checked")
      return screen.props.form.getFieldValue(val.replace("_value", "_checked"));
    if (val.endsWith("_value") && varName == "checked") return formVal ?? false;
    if (formVal != null && val.endsWith("_value") && varName !== "value") {
      // Multiple value component
      return formVal[varName];
    }
    if (formVal != null && val.endsWith("_selectedkey") && varName == "selectedKey") {
      // Menu Component Case!
      return formVal[varName];
    }

    return formVal;
  }

  public static async isFieldVisible(id: string, timeoutMs: number = 2000): Promise<boolean> {
    const start = Date.now();
    const timeout = timeoutMs;
    const checkInterval = 10;
    const selector = `[id~='${id}'],[focusid~='${id}']`;
    let element = document.querySelector(selector);
    if (!element) {
      element = document.querySelector(`[data-id~='${id}']`);
    }

    const isVisible = (el: Element) => {
      const style = window.getComputedStyle(el);
      let visible = style.display !== "none" && style.visibility !== "hidden";
      if (visible && el.id == id) {
        visible = style.opacity !== "0" && parseFloat(style.opacity || "1") > 0.1;
      }
      return visible;
    };
    if (!element) {
      while (Date.now() - start < timeout) {
        const el = document.querySelector(selector);
        if (el && isVisible(el)) {
          return true;
        }

        // Wait a bit before checking again (non-blocking)
        await new Promise<void>((resolve) => setTimeout(resolve, checkInterval));
      }
      return false;
    }
    return isVisible(element);
  }

  public static async navigateToTask(
    screen: any,
    _callback: any,
    StepKey: string,
    fromScreen: string,
    toScreen: string,
    _toUrl: string,
    openAs: string | null,
    navigationKuikaId: string | null,
    _title: string | null,
    _placement: string | null,
    _closable: string | null,
    _width: string | null,
    _height: string | null,
    executePageInitActionsAfterClose: boolean,
    disableSmartExecutePageInit: boolean
  ) {
    var isCallerMicroApp = window.location.hash !== "";
    const stepInfo = (await WorkflowService.GetNavigationParameters(StepKey, isCallerMicroApp)).data;

    if (stepInfo?.canNavigateToTask === false) {
      this.notify(screen, "You are not authorized to claim this task.", "warning", "bottom-right", 3, null, null, null);
      return;
    }

    const screenName =
      stepInfo.screenToNavigate?.length > 0
        ? stepInfo.screenToNavigate
        : (await WorkflowService.GetStepScreen(stepInfo.processId, stepInfo.stepId, stepInfo.appId)).data;

    if (screenName !== "") {
      let calculatedScreenName = screenName;
      let baseUrl = KuikaAppManager.GetFrontEndUrl();
      const urlHasHash = window.location.hash !== "";
      const hasMicroAppScreen = stepInfo.microAppContainingScreen && stepInfo.microAppContainingScreen !== "";
      const webViewUrl = stepInfo.webViewUrl;
      const screenExistsInApp = this.doesScreenExist(screenName);

      if (hasMicroAppScreen) {
        calculatedScreenName = `${stepInfo.microAppContainingScreen}#/${screenName}`;
        if (urlHasHash) {
          const indexOfHash = window.location.href.indexOf(`/${stepInfo.microAppContainingScreen}#`);
          baseUrl = window.location.href.substring(0, indexOfHash);
        }
      } else if (!screenExistsInApp && webViewUrl && webViewUrl !== "") {
        const isSameOriginWithVDir = this.isSameOriginAndVirtualDir(webViewUrl, window.location.href);
        if (!isSameOriginWithVDir) {
          window.open(webViewUrl, "_blank");
          return;
        }
      }
      if (openAs === "newTab" || openAs === "newWindow") {
        window.open(`${baseUrl}/${calculatedScreenName}?workflowStepInstanceId=${StepKey}`, "_blank");
        return;
      }
      if (openAs === "currentPage") {
        if (urlHasHash) {
          const { history } = screen.props.navigator;
          history.push({
            pathname: screenName,
            search: `workflowStepInstanceId=${StepKey}`,
            state: {
              screenInputs: {}
            }
          });
        } else {
          const newPath = `${baseUrl}/${calculatedScreenName}?workflowStepInstanceId=${StepKey}`;
          window.location.assign(newPath);
        }
        return;
      }

      KuikaAppManager.prepareForNavigation();
      KuikaAppManager.addToPageInputVariables(screenName, "workflowStepInstanceId", StepKey);
      screen.setState({ wfScreenName: screenName });
      return this.navigate(
        screen,
        _callback,
        fromScreen,
        screenName,
        _toUrl,
        openAs,
        navigationKuikaId,
        _title,
        _placement,
        _closable,
        _width,
        _height,
        executePageInitActionsAfterClose,
        disableSmartExecutePageInit
      );
    }
    if (stepInfo.webViewUrl && stepInfo.webViewUrl !== "") {
      window.location.replace(stepInfo.webViewUrl);
    }
  }

  public static async loadWorkflowStepInstanceParameters(screen: any, StepKey: string) {
    const stepdata = (await WorkflowService.GetTaskInstanceParameters(StepKey)).data;
    if (stepdata) {
      if (stepdata.showMessage) {
        this.notify(this, stepdata.message, "warning", "bottom-right", 3, null, null, null);
      }
      if (stepdata.redirect) {
        screen.props.navigator.gotoStartingScreen();
      }
      return stepdata;
    }
    return undefined;
  }

  public static getProcessParameterValue(form: any, screenName, diId, propertyName) {
    if (form) {
      const value = form.getFieldValue(`${screenName}_${diId}_${propertyName}`);
      if (value && value !== "") return value;
      return "";
    }
    return "";
  }

  public static getStepDataValue(bag: ITaskDataParameters, key: string) {
    if (bag !== undefined) {
      if (key == "StepInstanceId") return bag.workflowStepInstanceId;
      if (key == "ProcessInstanceId") return bag.processInstance;
      if (key == "showResumeProcessButton") return bag.showResumeProcessButton;
      if (bag.stepData && bag.stepData.length > 0) {
        const data = bag.stepData.find((b) => b.key === key);
        if (data !== undefined) return data.value;
      }
    }
    return "";
  }

  public static postWebKitMessage(scope: any, messageBody) {
    if (window.webkit && window.webkit.messageHandlers && window.webkit.messageHandlers.iosKuikaListener)
      window.webkit.messageHandlers.iosKuikaListener.postMessage(messageBody);
    // {"actionType":"CLOSE_WEBVIEW"}
    else if (window.AndroidKuikaListener) window.AndroidKuikaListener.postMessage(JSON.stringify(messageBody));
    else if (window.parent !== window) {
      // iframe case
      window.parent.postMessage({ source: "kuika", ...messageBody }, "*");
    } else {
      // web component/same window
      window.dispatchEvent(new CustomEvent("kuika-event", { detail: messageBody }));
    }
  }

  // obsolete
  // public static getStepScreenId = (processId, stepId): string => {
  //   const cnf = ProcessConfig.processScreens as IProcessConfigData[];
  //   const screenConfig = cnf.find((s) => s.processId == processId && s.stepId === stepId);
  //   if (screenConfig !== undefined) return screenConfig.screenId;
  //   return undefined;
  // };

  public static getScreenNameById = (screenId: string): string => {
    const screenList = this.getScreenList();
    const screenName = getDictionaryValueByKey(screenList, screenId);
    return screenName;
  };

  public static getScreenNameByActiveUserRoles = (): string => {
    const roleStartingScreenIdList = this.getRoleStartingScreenIdList();
    const userRoles = window?.userInfo?.roles;
    let result = "";
    userRoles?.forEach((role: { name: string }) => {
      const screenId: string = ReactSystemFunctions.findRoleStartingScreenId(roleStartingScreenIdList, role?.name);
      if (screenId !== undefined) {
        const startingScreenName = this.getScreenNameById(screenId);
        if (startingScreenName !== undefined && startingScreenName !== "") {
          result = startingScreenName;
        }
      }
    });
    return result;
  };

  public static getScreenList = () => {
    return [ { key: "e0fed23b-1bbf-4184-a849-87404410355e", value: "ResetPassword"}, { key: "dc5e4515-863c-447d-b295-17d0ff4fe983", value: "ForgotPassword"}, { key: "7fae9885-b7f5-4f7a-a994-0bd9bb79e379", value: "VerificationCode"}, { key: "95565277-5291-4368-8f96-fb774a3585be", value: "CustomerChangeLog"}, { key: "8d2d4e9f-a30f-4270-8ec7-320b9cad976d", value: "ContactSourceEdit"}, { key: "2dd3ff94-b8a6-46fd-a9bd-2f86809a5877", value: "SparePartsBasedReports"}, { key: "ec2af0b6-30af-4b94-be93-943376cf6004", value: "TechnicalServiceReports"}, { key: "543d44d2-d3cb-452c-8255-f84da9f7eed7", value: "ProductLogs"}, { key: "3f25d0f0-aa0c-43b9-9ea1-7edfe4a1236b", value: "NextStepAdd"}, { key: "3882d95c-847c-4740-b311-4e540bf2dad6", value: "NextStepEdit"}, { key: "2b4715b8-2418-4541-8a09-f740dfa7b2cc", value: "NextStepList"}, { key: "f376686f-62b1-45df-8d6e-4a0d5f8a8db2", value: "RoleList"}, { key: "6964aa57-5112-4fbe-88fd-116e88a31d51", value: "UserProfile"}, { key: "9d54dc21-2dfc-4017-a336-245cb6e5a1cd", value: "SettingPanel"}, { key: "a0e87bb8-254e-409c-a8e4-b110023d578f", value: "PolisajBasedReports"}, { key: "3ece616d-41b6-464c-bc43-0c7e9dcc2710", value: "MonthlyAllocationcopy"}, { key: "ebd61f37-5579-469b-bd76-9080db9f7db7", value: "LoomisReports"}, { key: "b4d9f2bc-b430-433b-b198-8462b3aeafac", value: "PurchaseBasedReports"}, { key: "7644944c-b753-497b-a51f-124c7ff2f77e", value: "ImportList"}, { key: "8ef1266a-871c-4198-9eb1-7605ee91341c", value: "LeadDetailAddNote"}, { key: "0ca000c5-f715-4925-8e0f-a43830483983", value: "ProductDetail"}, { key: "c25558b1-d06c-4b6f-97fd-7104fbf7c7cb", value: "ContactSourceList"}, { key: "1987bb85-bc04-408b-b8fe-2effaf6efe0a", value: "ContactSourceAdd"}, { key: "112116a5-3c16-4d4b-8aea-f78779f2754d", value: "RolexMaterialReporting"}, { key: "8e500dbd-5fc3-4976-b304-a798140b8039", value: "TudorBasedReporting"}, { key: "6ef7e309-5ff7-48cc-b4d0-a0e0020d07ac", value: "Signup"}, { key: "1e658766-4c3d-4c11-9a33-3daf2868e69f", value: "RolexOtherProductReporting"}, { key: "6072dc8d-c892-446b-b00b-08635c9302c3", value: "StockDistribution"}, { key: "3489139c-190b-4e87-82ce-117011f2aff8", value: "LeadAddByExcelcopy"}, { key: "26a8a39d-78d8-41b6-bbad-172b9fba1104", value: "ExecutionPlanScreen"}, { key: "d89a0934-d59f-45c2-b795-17db32e92fd2", value: "LeadDetailSalesPerson"}, { key: "f3ea9c70-97fc-4f65-9ccc-23a600954213", value: "LeadRejectPopUp"}, { key: "6eb46649-f7b5-4f7e-9813-25c0aaafb34c", value: "LeadRejectCustomerPopUp"}, { key: "2598232b-5dd1-4b64-99df-2ab6f612618d", value: "TransferDashboard"}, { key: "fb254e9d-61f5-43e5-b0b1-2db615de4cf5", value: "TransferIslemGunlugu"}, { key: "24425bfc-9ee5-4db6-877b-31258b42ea6b", value: "DistributionDetail"}, { key: "1cdf34a1-0313-4190-8548-3363c58b43e0", value: "TransferBekleyenHavuzu"}, { key: "cbc445e5-7713-4089-8f73-354ec2392876", value: "UserRoles"}, { key: "40a4ccb1-f9cd-43bf-bd41-37b7103b5442", value: "ImportLeadMersin"}, { key: "882ca07e-9f0c-4136-83cc-3e2cf0761023", value: "EntegrasyonHata"}, { key: "0ec4cdfe-dcf6-4ddd-a90b-3eb310d8fc35", value: "OrderList"}, { key: "8811eb48-b407-4b2c-9a78-3f15e6a0708f", value: "DistributionDetailStore"}, { key: "cf6d9d7a-423b-484c-ad17-450c58781c00", value: "UrunVeMagazaStokDetay"}, { key: "c14478f1-1222-49a6-8a08-49997b7d4aaf", value: "CreateTransferReceipt"}, { key: "0602e8ec-d90e-47d2-a980-4c478a454c70", value: "ReservationReject"}, { key: "3d364930-7018-4634-82e2-6c038ca71d68", value: "ReservationPopUp"}, { key: "90bec884-026b-4d53-adbb-71c5ead845ed", value: "UserManagementcopy"}, { key: "a75233c0-393d-4071-a60a-76e6c5da2c85", value: "MasterScreenTop"}, { key: "50d317ff-3d2d-4890-bfe3-76f5f15476f8", value: "InComingTransferDetail"}, { key: "78373d37-a0b0-44bd-b482-86bcd22be8dc", value: "LeadAddByExcelAI"}, { key: "cb3a3cdb-cb68-49f3-9b6b-8d0b2e4a461c", value: "ReservationEdit"}, { key: "6449111f-6ca3-46aa-824b-8e928d68f62f", value: "StockListManager"}, { key: "32ad7eb4-95c2-44c8-a391-906a70d9aad9", value: "RolexBasedReporting"}, { key: "8f1ad2e2-bf4b-409c-bdfc-91a111517918", value: "ImportLeadAdana"}, { key: "18f7ef24-6ad9-432c-8ac4-936c91f86b80", value: "TransferRaporlari"}, { key: "9d9a24f8-07e3-40d6-9787-94377a0c71c7", value: "ReservationManagement"}, { key: "db485e8f-db8f-448e-8a75-9583a7901946", value: "CustomerDetailInfo"}, { key: "f3575342-4d2f-4be5-8f7d-9cc839bee755", value: "ReferanceCreateNew"}, { key: "eb3bdc02-d235-4850-97a8-a7ea4891305c", value: "UserCreatecopy"}, { key: "c0e57703-bd2e-4f8b-8a9a-a7f310fe49a4", value: "DupontBasedReporting"}, { key: "efb4604a-6bf9-46e9-a0c9-a8c8518d3400", value: "StockListStoreBase"}, { key: "aedc12a4-5a9e-4588-8258-b1e555d8a857", value: "ImportLeadGaziantep"}, { key: "721f802d-0a22-4cb5-a7fb-b2ae8371be3c", value: "TransferFisiHazirlama"}, { key: "b76ea2a4-29a0-469d-bef5-b87dc9b386a7", value: "RolexFamilyReporting"}, { key: "2e1780e4-e80d-48e0-a08b-baf9bf9d2c6e", value: "LeadList"}, { key: "25557981-b431-450b-9316-becaabc93c6e", value: "LeadFileDetail"}, { key: "ff1b3bfc-ea13-4b27-ac3f-bf9759b98369", value: "DNM0100TransferFisKarti"}, { key: "01d7a7bb-7b9f-46c8-bd38-c1af5174ce5e", value: "RoleManagement"}, { key: "2c81213d-8451-4e0f-a91a-c31b1ecf9297", value: "MontBlancBasedReporting"}, { key: "ca66b3f9-71ac-48be-bad4-d579b3f3db73", value: "AlternativeInfo"}, { key: "286873a6-77ee-48ae-be33-db69e475fe69", value: "UserEdit"}, { key: "064736b7-f803-42f0-9e40-e1642100f60e", value: "ImportLeadAntalyaRolex"}, { key: "5e3c100c-4680-4191-a3b1-e6a9a2a3c09d", value: "TudorFamilyReporting"}, { key: "3854d79d-81aa-4a73-b1dc-eb291274cf95", value: "DNM0100DetailScreen"}, { key: "6e21c5cb-0329-4d9c-8b17-ebed76c64cb1", value: "ReferanceCreatePost"}, { key: "afbb4355-cd9f-44ed-b49c-ed8cbe3d7656", value: "StokVeUrunArama"}, { key: "b7887258-e2a7-4a80-b8b7-eebc7c9e1dcc", value: "CustomerDetailPage"}, { key: "d9303a18-2ce6-4037-8f88-f94c3815e746", value: "AnnualPortfolioList"}, { key: "cd19e42c-6b48-4e2c-baf0-fa1b31d79752", value: "Signin"}, { key: "acb83dad-177b-4bcc-a400-fda7b31a1305", value: "KasaRaporuDokumForm"}, { key: "28ee5ac7-64f3-44fd-b370-fdf0d249207f", value: "RolexDiameterReporting"}, { key: "c6a00e04-1d1e-45eb-a72a-0229b988cf19", value: "ProductDistribution"}, { key: "32788d63-64e9-4d59-91b6-09aea7eba82c", value: "PopOnayBekleyen"}, { key: "6cb39266-5d5e-47d7-98b6-0acb3e3cc680", value: "LeadDetailTemp"}, { key: "15291c8b-8f01-4201-83db-0be74a5c15d9", value: "AllLeadPendingDetail"}, { key: "de7d962c-498a-4466-9818-0e4c6a84b022", value: "TransferFisleri"}, { key: "7fb0f30f-d458-4931-aced-0fe282b484ed", value: "OnayaGonderdigimSatislar"}, { key: "809ec381-ea4a-4878-a541-149635df5dc3", value: "ProductList"}, { key: "2397262f-28dc-47d7-8cbc-16eaa06b2fb5", value: "TransferTalepleri"}, { key: "c101c1b7-5971-406c-877e-18ce9db09e36", value: "LeadSatisBasariliPop"}, { key: "818da49d-c26d-4236-8206-1d67ae13cf4d", value: "DashBoardTempManager"}, { key: "7ec857bf-3368-4103-86d4-20cb01b82d0f", value: "BosekranYusuf"}, { key: "408f71ea-a491-484c-947b-222c2fd7f750", value: "ReportCashNebim"}, { key: "407ff7fb-8e1d-4358-98a6-23252cafb4e3", value: "TerminPendingLead"}, { key: "7db80e0c-4543-46e3-bdfd-288bc3508e18", value: "LeadAdd"}, { key: "96481cd8-cc51-415c-8fb5-2d274fc4f206", value: "TalepSatisIslemi"}, { key: "54eab609-cb28-4754-a264-30454afa33da", value: "LeadAddTemp"}, { key: "dacf93e1-59c5-4b4b-8eaf-322df6fb7e16", value: "SatisBasariliPop"}, { key: "e0c0b0bc-d1be-4499-8236-324792cc3389", value: "DashBoardTempTopManager"}, { key: "2c1b50a6-e4fc-4295-92d5-38cae62a4851", value: "ROLEAUTH"}, { key: "74a8b73b-9aca-4f73-9881-39e6c940cb20", value: "CustomerUpdatePost"}, { key: "8d960c47-0f6c-4ec5-a8db-3a30bbfd8d55", value: "UcuncuKisiFaturaOnayDetayi"}, { key: "29f7bfbe-f138-489a-aab5-3bc49c7d8fcf", value: "TransferBildirimGonderimIzleme"}, { key: "31ee8b62-5a15-4cd4-91c5-3cea4b1f0ffc", value: "NotificationManager"}, { key: "14951b64-af99-4642-a144-3d091d076a1b", value: "LeadAlternativeModelAdd"}, { key: "dc564fcc-e057-4e0b-bb5b-3f738c2992f1", value: "AnnualPortfolioCreationStep1copycopy"}, { key: "d775d00e-910a-4068-b019-43f27b38f508", value: "ReportSalesNebim"}, { key: "ad882a05-ac65-4cc2-afea-4c2282ca9ce4", value: "ApprovedLeadList"}, { key: "1f8d109f-26cc-4fdb-8af7-4fcb74672e7d", value: "TransferFisiDetayi"}, { key: "09874965-a124-428f-b591-5048ddc92580", value: "Deneme2copy"}, { key: "fef38f0e-09ff-4733-ac58-50d73a5f9932", value: "PopTerminOnerisiBekleyen"}, { key: "ddce2084-4157-4c5c-a19a-5137fb26bea0", value: "ReservationPopup1"}, { key: "c0e10e60-0a86-4d6f-9426-62639b6a04ac", value: "Deneme001"}, { key: "344fef9d-42cc-4a9c-a841-63957d60be8b", value: "TaskManagementTopManager"}, { key: "30128a83-20fa-44e5-9b84-6831c5e89575", value: "ApproveLead"}, { key: "0a2b3fc8-7355-47c6-a193-6889e112f583", value: "SalesWeb"}, { key: "49dbcd39-c30e-4a0f-9b0c-695e18904547", value: "ReservationPopUp2"}, { key: "c5f15de4-6a17-485a-b32b-6a25536c040f", value: "TransferFisKabul"}, { key: "a0539d2b-3a71-4081-85a7-6d9dcd1def49", value: "MusteriOnayPop"}, { key: "43c9f758-5447-4db5-af1e-6f61fb36d660", value: "StockListDetail"}, { key: "7bcdca0e-2660-4134-8a0a-72f9ad9efe3c", value: "YearlyStockEntry"}, { key: "5db5471f-cd24-4d36-ac5b-7393479aec3c", value: "CustomerList"}, { key: "4cacb8da-6e11-4391-9dba-764b2c75b2bb", value: "CustomerErpLog"}, { key: "b74fbba4-3537-4cdd-86f8-774e9b8c2f68", value: "YearlyAllocationcopy"}, { key: "0e35f42f-0c10-4dcc-9a5f-7863868b0a89", value: "TransferTalepDetay"}, { key: "ab29225b-1942-46c8-8ff8-78f55bba1d58", value: "ReportInventoryNebim"}, { key: "8f9b5641-e390-4257-9e9c-7a3cc7cde189", value: "CustomerCreatePost"}, { key: "5cca6d25-a3e3-44fd-be02-7f2e2f799d20", value: "DistributionPool"}, { key: "ddfa16d4-073a-4573-a55f-8716667539d4", value: "AllLeadPending"}, { key: "d7a55406-f42a-4ca6-b69c-8c7dbd957db8", value: "LeadUpdate"}, { key: "879184fc-ca05-4264-8654-9aa279f9e557", value: "PopRezervOnayBekleyenPopup"}, { key: "6ea60fb6-60a4-426f-bb75-a29de6900e67", value: "LeftMenu"}, { key: "39ccaf37-0370-4ec8-a1ed-b0dd56e5281b", value: "Kubrabosekran"}, { key: "4752c56e-5628-4f96-a849-b456593b3684", value: "SatisIslemi"}, { key: "192adaf6-0a9c-4496-9767-b96af2adb5f7", value: "LeadDetail"}, { key: "2f71bd76-5b09-4afd-b4ed-bc5d00334c6b", value: "DashBoardTemp"}, { key: "f6752e9c-f537-4466-81af-bca7bdc5ff8e", value: "ImportListDetail"}, { key: "aeacfa91-3bf7-457d-93bc-beb2216de9c4", value: "TalepDuzenlemeEkrani"}, { key: "b535cdc0-a552-4fa2-8c56-c022f9f49ec8", value: "LeadAddChangeProduct"}, { key: "99c1384b-d0c8-4266-bb42-c334f3b1d2b6", value: "LeadProductChange"}, { key: "7aaf4829-03b0-41e6-8610-c6b5281b2205", value: "LeadListTemp"}, { key: "c2edec8e-0150-4bd6-b202-c8fd458aaa13", value: "TaskManagementPerson"}, { key: "9194ff39-c389-470a-96d3-cb571cc7625d", value: "TransferTalepOnay"}, { key: "e81bde3f-0b0f-49f1-897b-cc0e02a88b64", value: "AllLeadPendingTerminDegis"}, { key: "3639aa27-94a2-4767-8304-d2eda89f7aa1", value: "TaskManagementManager"}, { key: "a9cf73c5-a70b-45fa-a208-d890b727c182", value: "ReservationPopUp3"}, { key: "b96b599c-7c1d-416c-8d07-da59c163ee0e", value: "StockListStore"}, { key: "21e70ca9-dfe9-47a8-b1b8-dbf1a9fdbf21", value: "LeadReport"}, { key: "5c954fe9-2309-4309-8ea4-dcadae3c52ee", value: "BildirimPopup"}, { key: "de2db0f6-8542-496f-ab75-dcb677ebc21a", value: "DiscountLimit"}, { key: "8a94d214-83d6-4084-87e0-df24e9ff20b1", value: "AddDiscountLimit"}, { key: "13444d4e-d880-4482-a0d6-e2e79ecbfd89", value: "MasterScreen"}, { key: "f137518b-bd45-4b20-957b-e4214cdecce6", value: "FreeSalesWeb"}, { key: "d7b163f6-7410-4863-8f00-e59c4085892b", value: "Deneme001Workspace"}, { key: "4f58ae93-5f4a-4a11-ac34-e7e6da945849", value: "BildirimlerBekleyenIsler"}, { key: "fd18aa10-74b6-41e2-8b73-ef4e39194c07", value: "TalebeAlternatifUrunEkle"}, { key: "574b992d-3995-42ec-8abe-f0a0592c5ab4", value: "AllCustomerChangeLog"}, { key: "b2a8d27c-3156-4bf0-a5c0-f32e556cd3b3", value: "TransferTalebiOlusturStok"}, { key: "8c74c18f-2864-4b9f-ad45-f4dd4f1a4c0d", value: "UcuncuKisiFaturaOnaylari"}, { key: "291f738f-720f-4812-875f-fd2c68ee1fb5", value: "TransferTalebiOlusturV2"},];
  };

  public static getRoleStartingScreenIdList = () => {
    return [ { key: "TimesYonetici", value: "2c1b50a6-e4fc-4295-92d5-38cae62a4851"}, { key: "TimesUstYonetici", value: "2c1b50a6-e4fc-4295-92d5-38cae62a4851"}, { key: "TimesSatisPersoneli", value: "2c1b50a6-e4fc-4295-92d5-38cae62a4851"}, { key: "TimesMagazaMuduru", value: "2c1b50a6-e4fc-4295-92d5-38cae62a4851"}, { key: "TimesAdmin", value: "2c1b50a6-e4fc-4295-92d5-38cae62a4851"}, { key: "_SystemAdmin", value: "2c1b50a6-e4fc-4295-92d5-38cae62a4851"},];
  };

  private static doesScreenExist = (screenName: string): boolean => {
    if (!screenName) return false;
    const screens = this.getScreenList() || [];
    return screens.some((s: { key?: string; value?: string }) => {
      const keyMatch = s?.key?.toLowerCase() === screenName.toLowerCase();
      const valueMatch = s?.value?.toLowerCase() === screenName.toLowerCase();
      return keyMatch || valueMatch;
    });
  };

  private static originWithVirtualDirectory = (rawUrl: string): string | null => {
    try {
      const parsed = new URL(rawUrl, window.location.href);
      const segments = parsed.pathname.split("/").filter(Boolean);
      const virtualDir = segments.length > 0 ? `/${segments[0]}` : "";
      return `${parsed.origin}${virtualDir}`.toLowerCase();
    } catch (err) {
      return null;
    }
  };

  private static isSameOriginAndVirtualDir = (targetUrl: string, currentUrl: string): boolean => {
    const target = this.originWithVirtualDirectory(targetUrl);
    const current = this.originWithVirtualDirectory(currentUrl);
    return !!target && !!current && target === current;
  };

  // Navigation
  // 0: {name: "fromScreenId", Typename: "String", cardinality: 1, isMandatory: false, ownerClassName: null, …}
  // 1: {name: "toScreenId", Typename: "String", cardinality: 1, isMandatory: false, ownerClassName: null, …}
  // 2: {name: "toUrl", Typename: "String", cardinality: 1, isMandatory: false, ownerClassName: null, …}
  // 3: {name: "openAs", Typename: "String", cardinality: 1, isMandatory: false, ownerClassName: null, …}
  // 4: {name: "navigationKuikaId", Typename: "String", cardinality: 1, isMandatory: false, ownerClassName: null, …}
  public static navigate(
    screen: any,
    _callback: any,
    fromScreen: string,
    toScreen: string,
    _toUrl: string,
    openAs: string | null,
    navigationKuikaId: string | null,
    _title: string | null,
    _placement: string | null,
    _closable: string | null,
    _width: string | null,
    _height: string | null,
    executePageInitActionsAfterClose: boolean,
    disableSmartExecutePageInit: boolean = false
  ): string {
    const { history } = screen.props.navigator;

    let screenInputsQuery = "";
    if (window.kuika?.navigationScreenInputs && !_.isEmpty(window.kuika?.navigationScreenInputs)) {
      screenInputsQuery = querystringify.stringify(window.kuika?.navigationScreenInputs, true);
    }

    if (!window.kuika) window.kuika = {};

    if ((screen.props.navigator as any)?.history?.location?.search?.includes("redirectOnMobile=true")) {
      this.postWebKitMessage(null, {
        actionType: "NAVIGATE",
        openAs: `${openAs}`,
        width: `${_width}`,
        height: `${_height}`,
        placement: `${_placement}`,
        toScreen: `${toScreen}`,
        triggerPageInit: `${executePageInitActionsAfterClose}`,
        disableSmartExecutePageInit: `${disableSmartExecutePageInit}`,
        screenInputs: `${screenInputsQuery}`
      });
      return "";
    }

    // KOA-8559 "Open in Current Overlay": when this navigate is triggered from a screen
    // rendered INSIDE an open drawer/modal/floatingPanel, render the target screen inside
    // that same overlay (swap the inline-mounted master's child, keeping the overlay open
    // and the master chrome mounted) instead of routing the page behind it. The handle is
    // read from the triggering screen's props (injected by withInlineOverlayNav from the
    // overlay's InlineOverlayNavContext), so it is present ONLY for screens actually inside
    // the overlay — a trigger on the page behind (or a maskless FloatPanel background) has
    // no handle. When there's no handle, or the target is not one of that overlay master's
    // children, we degrade to a normal currentPage navigate.
    let effectiveOpenAs: string | null = openAs;
    if (effectiveOpenAs === "currentOverlay") {
      const inlineOverlayNav: IInlineOverlayNav | null | undefined = screen?.props?.inlineOverlayNav;
      const canSwapInOverlay: boolean =
        !!inlineOverlayNav && typeof inlineOverlayNav.canRender === "function" && inlineOverlayNav.canRender(toScreen);
      if (canSwapInOverlay && inlineOverlayNav) {
        const overlayInputs: Record<string, unknown> = { ...(window.kuika?.navigationScreenInputs ?? {}) };
        inlineOverlayNav.push(toScreen, overlayInputs);
        return "";
      }
      effectiveOpenAs = "currentPage";
    }

    switch (effectiveOpenAs) {
      case "currentPage": {
        history.push({
          pathname: toScreen,
          search: screenInputsQuery,
          state: {
            screenInputs: {
              // TODO
            }
          }
        });

        // One-shot handoff from the overlay branch below, which records the screen an
        // overlay was opened from. That screen stays the browser route while the overlay
        // is up, so navigating onto it is a push to the current path and refreshes
        // nothing — hence the reload. Consume the handoff here: left set, it keeps
        // matching on later, unrelated navigations and reloads the page for nothing.
        const overlayOrigin: string | undefined = window.kuika?.navigationComponentMasterScreen;
        delete window.kuika?.navigationComponentMasterScreen;

        if (fromScreen === toScreen || toScreen === overlayOrigin) {
          // Persist any pending debounced offline write BEFORE the hard reload.
          // Otherwise the auto-save timeout scheduled by the preceding save action
          // is destroyed by the reload and the offline write is lost (the save
          // appears not to complete). flushPendingWrites is a no-op when nothing
          // is pending (e.g. online navigations).
          void KuikaCoreWasmBridgeService.getInstance()
            .flushPendingWrites()
            .catch(() => undefined)
            .finally(() => window.location.reload());
        }

        window.kuika.pageInitCallers ??= {};
        window.kuika.pageInitCallers[fromScreen] = executePageInitActionsAfterClose;

        if (typeof screen?.props?.onClose === "function") {
          screen.props.onClose();
        }

        break;
      }

      case "newTab":
      case "newWindow":
        HelperService.redirectToPath(`/${toScreen}${screenInputsQuery}`, {
          openInNewTab: true
        });
        break;

      default:
        window.kuika.disableSmartExecutePageInit ??= {};
        window.kuika.disableSmartExecutePageInit[fromScreen] = disableSmartExecutePageInit ?? false;
        if (!window.kuika?.navigationComponentMasterScreen) window.kuika.navigationComponentMasterScreen = fromScreen;
        else if (
          window.kuika.navigationComponentMasterScreen &&
          fromScreen !== window.kuika.navigationComponentMasterScreen
        ) {
          window.kuika.navigationComponentMasterScreen = fromScreen;
        }
        const obj = {};
        obj[`NavVisible${navigationKuikaId}`] = true;
        screen.setState(obj);
        break;
    }

    return "";
  }

  // GoBack
  public static goBack(
    screen: { props: { onClose: () => void; navigator: KNavigator } },
    triggerParentAppGoBack: boolean = false
  ) {
    if (screen?.props?.onClose) {
      KuikaAppManager.hideSpinner(screen);
      screen.props.onClose();
      return;
    }

    if (triggerParentAppGoBack && this.getIsMicroApp() && window.parentScreen) {
      const parentScreen = window.parentScreen;
      ReactSystemFunctions.goBack(parentScreen);
      return;
    }

    if (screen.props.navigator.goBack) {
      if ((screen.props.navigator as any)?.history?.location?.search?.includes("redirectOnMobile=true")) {
        this.postWebKitMessage(null, { actionType: "GO_BACK" });
      } else {
        const isWebView = window.location !== window.parent.location;
        if (isWebView) {
          const hasHistory = (screen.props.navigator as any)?.history?.action === "PUSH";
          const parentWindow = window.parent;

          if (parentWindow) {
            // This used to search the parent document top-down and close the FIRST
            // .ant-drawer-wrapper-body it found. Drawers are sibling portals under body, so with
            // nested drawers that first match is the OUTERMOST one — closing the drawer that holds
            // the WebView tore down the whole stack. Ownership is resolved from the iframe instead:
            // find our own frame by window identity, then walk up to the overlay containing it.
            const ownFrame: HTMLIFrameElement | undefined = Array.from(
              parentWindow.document.querySelectorAll("iframe")
            ).find((frame: HTMLIFrameElement): boolean => frame.contentWindow === window);
            const owningOverlay: Element | null =
              ownFrame?.closest(".ant-modal-root, .ant-drawer-wrapper-body") ?? null;

            if (owningOverlay) {
              const overlayClose: HTMLElement | null = owningOverlay.querySelector<HTMLElement>(
                ".ant-modal-close, .ant-drawer-close"
              );

              if (overlayClose) {
                if (hasHistory) {
                  screen.props.navigator.goBack();
                } else {
                  overlayClose.click();
                }
              }
            } else {
              screen.props.navigator.goBack();
            }
          }
        } else {
          screen.props.navigator.goBack();
        }
      }
    }
  }

  public static getMyUsername(): string {
    return window?.userInfo?.username;
  }

  public static getMyUserId(): string | undefined {
    return window?.userInfo?.id;
  }

  public static getMyFirstName(): string {
    return window?.userInfo?.firstName;
  }

  public static getMyLastName(): string {
    return window?.userInfo?.lastName;
  }

  public static getMyFullName(): string {
    const f = window?.userInfo?.firstName;
    const l = window?.userInfo?.lastName;
    return f && l ? `${f} ${l}` : f || l;
  }

  public static getMyPhoneNumber(): string {
    return window?.userInfo?.phoneNumber;
  }

  public static getMyRoleNames(): string {
    return window?.userInfo?.roleNames;
  }

  public static getIsMicroApp(): boolean {
    return KuikaAppManager.IsWebComponent();
  }

  public static async logout(): Promise<void> {
    const urlParams = new URLSearchParams(window.location.search);
    const redirectOnMobileValue = urlParams.get("redirectOnMobile");

    if (redirectOnMobileValue === "true") {
      this.postWebKitMessage(null, { actionType: "LOGOUT" });
      return;
    }

    await UserService.Logout();
  }

  public static async signinwithMSAL(): Promise<void> {
    sessionStorage.setItem("msalRedirectionStarted", "loaded");
    HelperService.gotoLogin();
  }

  // Notification
  // sendPushNotificationToUsername: _sendPushNotificationToUsername,
  // sendPushNotificationToApp: _sendPushNotificationToApp,
  public static notify(
    screen: any,
    message: string,
    type: "success" | "danger" | "info" | "default" | "warning" | "custom",
    position:
      | "top-left"
      | "top-right"
      | "top-center"
      | "bottom-left"
      | "bottom-right"
      | "bottom-center"
      | "top"
      | "bottom",
    duration: number,
    backgroundColor: string | null,
    textColor: string | null,
    fontSize: number | null
  ): boolean | undefined {
    if (message === undefined || message === null) message = "";
    if (typeof message === "object") message = JSON.stringify(message);
    else if (typeof message !== "string" && (message as any).toString) message = (message as any).toString();
    if (message) {
      // todo message = ReactSystemFunctions.translateCustomActions(screen.ml, "{actionID}", screen.this.defaultML, message);

      if (duration === null || duration === undefined || duration < 0) {
        switch (type) {
          case "success": {
            duration = KMainFunctions.NOTIFY_ACTION_DEFAULT_SUCCESS_DURATION;
            break;
          }
          case "danger": {
            duration = KMainFunctions.NOTIFY_ACTION_DEFAULT_ERROR_DURATION;
            break;
          }
          case "info": {
            duration = KMainFunctions.NOTIFY_ACTION_DEFAULT_INFO_DURATION;
            break;
          }
          case "warning": {
            duration = KMainFunctions.NOTIFY_ACTION_DEFAULT_WARNING_DURATION;
            break;
          }
          case "default":
          default: {
            duration = KMainFunctions.NOTIFY_ACTION_DEFAULT_DEFAULT_DURATION;
            break;
          }
        }
      }
      if (position === "top") position = "top-center";
      if (position === "bottom") position = "bottom-center";

      const instanceId = Guid.create().toString();

      let customStyle: string | undefined;
      const isCustom: boolean = type === "custom";

      if (isCustom) {
        type = "default";

        const style = document.getElementById("dynamic_style");

        customStyle = buildCustomNotificationStyle(instanceId, backgroundColor);

        style.innerHTML += customStyle;
      }

      setTimeout(() => {
        if (duration < 0) duration = 0;
        if (position === "top") position = "top-center";
        if (position === "bottom") position = "bottom-center";
        if (type === "custom") {
          type = "default";

          setTimeout(
            () => {
              const style = document.getElementById("dynamic_style");
              style.innerHTML = style.innerHTML.replace(customStyle, "");
            },
            duration * 1000 + 1000
          );
        }

        const text: string = message.replace(/&nbsp;/g, "");

        Store.addNotification({
          title: "",
          message: isCustom ? buildCustomNotificationMessage(text, textColor, fontSize) : text,
          type,
          container: position,
          animationIn: [`custom-notification-${instanceId}`, "animated", "flipInX"],
          animationOut: [`custom-notification-${instanceId}`, "animated", "fadeOut"],
          dismiss: {
            duration: duration * 1000,
            pauseOnHover: true,
            showIcon: true
          }
        });
      }, 150);
      return true;
    }
  }

  // Device

  public static printCurrentScreen() {}

  public static getPhotoFromGallery = () =>
    new Promise((resolve, reject) => {
      let listener = false;
      const input = document.createElement("input");
      input.classList.add("kuika-take-photo-gallery");
      input.setAttribute("type", "file");
      input.setAttribute("name", "kuika_photo_take");
      input.style.display = "none";
      input.accept = "image/*,application/pdf";
      listener = true;

      window.addEventListener("focus", () => {
        setTimeout(() => {
          if (listener) {
            listener = false;
            let files = Array.from(input.files);
            if (files.length === 0) {
              resolve("");
            }
          }
        }, 1000);
      });

      input.onchange = () => {
        let files = Array.from(input.files);
        if (files.length === 0) {
          resolve("");
        }

        const [file] = files;

        const reader = new FileReader();
        reader.addEventListener("load", (e) => {
          resolve(e.target.result);
        });
        reader.addEventListener("error", (e) => {
          reject(e.target.error);
        });

        reader.readAsDataURL(file);
      };

      input.click();
    });

  // getPhotosFromGallery: `quality` secilmediginde uygulanan TASIMA siniri. 2048 px en uzun
  // kenar hala ~4 MP -- GS1 metni ve Data Matrix rahat okunur -- ama govdeyi ~1-2 MB'a
  // sabitler. Sinirin altinda kalan foto hic yeniden kodlanmaz (jenerasyon kaybi olmaz).
  private static readonly GALLERY_UNSPECIFIED_MAX_LENGTH: number = 2048;
  private static readonly GALLERY_UNSPECIFIED_MAX_SIZE: number = 4 * 1024 * 1024;

  public static getPhotosFromGallery = (
    editPhoto: boolean,
    quality: string
  ): Promise<{
    data: {
      dataBase64: string;
      name: string;
      size: number;
      fileExtension: string;
    }[];
  }> => {
    return new Promise((resolve) => {
      const input = document.createElement("input");
      input.type = "file";
      input.multiple = true;
      input.accept = "image/*";

      const processImage = async (
        file: File
      ): Promise<{
        dataBase64: string;
        name: string;
        size: number;
        fileExtension: string;
      }> => {
        return new Promise((processResolve) => {
          const img = new Image();
          const reader = new FileReader();

          reader.onload = (e) => {
            img.src = e.target.result as string;
            img.onload = () => {
              // `quality` opsiyonel bir action parametresi; secilmediginde bos string geliyor
              // (`convertToTypeByName("", "string")`). Bos deger asagidaki hicbir dala
              // girmiyordu ve fonksiyon en agresif kucultmeye dusuyordu: maxLength 400 px.
              // Olculdu (3 Agu 2026): 1152x2048 bir ilac kutusu fotosu 225x400'e inince
              // GS1 metni (GTIN/seri/SKT/lot) tamamen okunamaz hale geliyor ve zxing'in
              // Data Matrix okumasi da basarisiz oluyor -- AI action tum alanlari bos
              // donuyor, hicbir hata/uyari uretmeden.
              //
              // Ama "hic kucultme" de tek basina yanlis: guncel bir telefon fotosu 10-50 MB
              // olabiliyor, `input.multiple` ile birden fazla foto AYNI istekte gidiyor ve
              // govde SINIRSIZ buyuyor. Localde gorunmuyor (arada proxy yok, generated app
              // Kestrel'de MaxRequestBodySize = int.MaxValue); deploy edilmis ortamda onde
              // duran nginx govdeyi reddediyor -> HTTP 413, oncesinde dakikalarca bosa upload.
              // Yani foto hem OKUNABILIR hem TASINABILIR olmak zorunda: sinirin altinda hic
              // dokunulmuyor, ustunde olculu kucultuluyor. `original` "hic dokunma" demek
              // isteyenler icin kacis kapisi olarak bozulmadan kaliyor.
              const isUnspecifiedQuality: boolean = !quality || quality === "default";
              const withinTransportBounds: boolean =
                img.width <= ReactSystemFunctions.GALLERY_UNSPECIFIED_MAX_LENGTH &&
                img.height <= ReactSystemFunctions.GALLERY_UNSPECIFIED_MAX_LENGTH &&
                file.size <= ReactSystemFunctions.GALLERY_UNSPECIFIED_MAX_SIZE;

              if (quality === "original" || (isUnspecifiedQuality && withinTransportBounds)) {
                processResolve({
                  dataBase64: e.target.result as string,
                  name: file.name,
                  size: file.size,
                  fileExtension: KMainFunctions.getExtensionByMimeType(file.name, file.type)
                });
                return;
              }

              let maxLength = 400;
              let maxSize = 102410;

              if (isUnspecifiedQuality) {
                maxLength = ReactSystemFunctions.GALLERY_UNSPECIFIED_MAX_LENGTH;
                maxSize = ReactSystemFunctions.GALLERY_UNSPECIFIED_MAX_SIZE;
              } else if (quality === "low") {
                maxLength = 400;
                maxSize = 102410;
              } else if (quality === "medium") {
                maxLength = 800;
                maxSize = 204820;
              } else if (quality === "high") {
                maxLength = 1200;
                maxSize = 409640;
              }

              const canvas = document.createElement("canvas");
              let width = img.width;
              let height = img.height;

              if (width > maxLength || height > maxLength) {
                if (width > height) {
                  height = Math.round((height * maxLength) / width);
                  width = maxLength;
                } else {
                  width = Math.round((width * maxLength) / height);
                  height = maxLength;
                }
              }

              canvas.width = width;
              canvas.height = height;
              const ctx = canvas.getContext("2d", {
                willReadFrequently: true,
                alpha: true
              });
              if (ctx) {
                ctx.clearRect(0, 0, width, height);
                ctx.imageSmoothingQuality = "high";
                ctx.drawImage(img, 0, 0, width, height);
              }

              let compressionQuality = 1.0;
              let dataUrl: string;
              do {
                dataUrl = canvas.toDataURL(file.type || "image/jpeg", compressionQuality);
                const size = Math.round((dataUrl.length - 22) * 0.75);
                if (size > maxSize) {
                  compressionQuality -= 0.1;
                } else {
                  break;
                }
              } while (compressionQuality >= 0.1);

              processResolve({
                dataBase64: dataUrl,
                name: file.name,
                size: Math.round((dataUrl.length - 22) * 0.75),
                fileExtension: KMainFunctions.getExtensionByMimeType(file.name, file.type)
              });
            };
          };
          reader.readAsDataURL(file);
        });
      };

      input.onchange = async () => {
        try {
          const files = Array.from(input.files);
          const filePromises = files.map(processImage);

          const results = await Promise.all(filePromises);
          resolve({ data: results.filter((result) => result !== null) });
        } catch (error) {
          resolve({ data: [] });
        }
      };

      input.oncancel = () => {
        resolve({ data: [] });
      };

      input.click();
    });
  };

  public static uploadFile = () => {
    return new Promise((resolve) => {
      let input = document.createElement("input");
      input.type = "file";
      input.multiple = false;
      input.accept = "*";

      input.onchange = () => {
        let files = Array.from(input.files);
        if (files.length === 0) {
          resolve("");
        }

        const [file] = files;

        const reader = new FileReader();
        reader.addEventListener("load", (e) => {
          resolve(e.target.result);
        });
        reader.addEventListener("error", (e) => {
          KMainFunctions.exceptionHandler(e);
          resolve({});
        });
        reader.readAsDataURL(file);
      };

      input.oncancel = () => {
        resolve({});
      };

      input.click();
    });
  };

  public static uploadFileWithInfo = (fileType?: string) => {
    return new Promise((resolve) => {
      let input = document.createElement("input");
      input.type = "file";
      input.multiple = false;

      input.accept = fileType || "*";

      input.onchange = () => {
        let files = Array.from(input.files);
        if (files.length === 0) {
          resolve({
            data: {}
          });
        }

        const [file] = files;
        var resultObj = {
          data: {}
        } as any;
        resultObj.data.name = file.name;
        resultObj.data.type = file.type;
        resultObj.data.size = file.size;
        const reader = new FileReader();
        reader.addEventListener("load", (e) => {
          resultObj.data.data = e.target.result;
          resolve(resultObj);
        });
        reader.addEventListener("error", (e) => {
          KMainFunctions.exceptionHandler(e);
          resolve({});
        });
        reader.readAsDataURL(file);
      };

      input.oncancel = () => {
        resolve({});
      };

      input.click();
    });
  };

  public static uploadFilesWithInfo = (fileType?: string) => {
    return new Promise((resolve) => {
      let input = document.createElement("input");
      input.type = "file";
      input.multiple = true;

      input.accept = fileType || "*";

      input.onchange = () => {
        let files = Array.from(input.files);
        if (files.length === 0) {
          resolve({
            data: []
          });
          return;
        }

        const results: any[] = [];
        let loadedCount = 0;

        files.forEach((file) => {
          const resultObj: any = {
            name: file.name,
            type: file.type,
            size: file.size,
            data: null
          };
          const reader = new FileReader();
          reader.addEventListener("load", (e) => {
            resultObj.data = e.target.result;
            results.push(resultObj);
            loadedCount++;
            if (loadedCount === files.length) {
              resolve({ data: results });
            }
          });
          reader.addEventListener("error", (e) => {
            KMainFunctions.exceptionHandler(e);
            loadedCount++;
            if (loadedCount === files.length) {
              resolve({ data: results });
            }
          });
          reader.readAsDataURL(file);
        });
      };

      input.oncancel = () => {
        resolve({ data: [] });
      };

      input.click();
    });
  };

  public static takePhotoKuikaFunction = (comp: {
    props: { showPhotoTake: () => void; hidePhotoTake: () => void };
    forceUpdate: () => void;
  }) =>
    new Promise((resolve, _reject) => {
      comp.props.showPhotoTake();
      let isListenerAttached: boolean = false;
      let hasCameraMounted: boolean = false;
      let hasDelivered: boolean = false;
      const mountDeadline: number = Date.now() + 10000;
      const deliverPhoto = (imgNode: HTMLImageElement): void => {
        if (hasDelivered) {
          return;
        }
        hasDelivered = true;
        comp.props.hidePhotoTake();
        comp.forceUpdate();
        resolve(imgNode.src);
      };
      const onPhotoLoaded = (event: Event): void => {
        deliverPhoto(event.target as HTMLImageElement);
      };
      // Attach the load listener as soon as the camera mounts instead of a
      // single 350ms shot — on slow devices the camera can mount later, which
      // previously left the action hanging forever (KOA-17786). The same
      // interval also picks up a photo whose load event fired before the
      // listener attached, detects the camera being closed without a photo,
      // and a mount deadline keeps the action from hanging when the camera
      // never renders at all.
      const watchInterval = setInterval(() => {
        const cameraRoot: Element | undefined = document.getElementsByClassName("react-html5-camera-photo")[0];
        if (cameraRoot) {
          hasCameraMounted = true;
          const imgNode: HTMLImageElement | undefined = cameraRoot.getElementsByTagName("img")[0];
          if (imgNode && !isListenerAttached) {
            imgNode.addEventListener("load", onPhotoLoaded);
            isListenerAttached = true;
          }
          if (imgNode && imgNode.complete && imgNode.src.startsWith("data:")) {
            deliverPhoto(imgNode);
          }
          return;
        }
        if (hasCameraMounted || Date.now() > mountDeadline) {
          clearInterval(watchInterval);
          resolve("");
        }
      }, 100);
    });

  // openInBrowser: _openInBrowser,
  public static openInBrowser(val: unknown, openAs: "current" | "newtab") {
    if (typeof val !== "string") {
      KMainFunctions.displayErrorNotification("Invalid URL");
      return;
    }

    let url: string = val;

    if (!url.startsWith("http://") && !url.startsWith("https://")) {
      url = `https://${url}`;
    }

    if (!KMainFunctions.getIsValidHttpUrl(url)) {
      KMainFunctions.displayErrorNotification(`Invalid URL: "${url}"`);
      return;
    }

    if (openAs === "newtab") {
      setTimeout(() => window.open(url, "_blank").focus(), 100);
    } else {
      setTimeout(() => window.open(url, "_self").focus(), 100);
    }
  }

  public static openInWebView(val: string) {
    let url: string = val;
    if (url === undefined || url === null || url === "") {
      window.open("", "_blank").focus();
      return;
    }

    if (!url.startsWith("http://") && !url.startsWith("https://")) {
      url = `https://${url}`;
    }

    setTimeout(() => window.open(url, "_blank").focus(), 100);
  }

  public static async printPdf(base64: string, screen: any) {
    const hash = window.location.hash || "";
    const isCallerMicroApp = hash !== "";
    const isMobile = /Android|webOS|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini/i.test(navigator.userAgent);

    let base64WithoutPrefix = base64;
    if (base64.startsWith("data:application/pdf;base64,")) {
      base64WithoutPrefix = base64.substring("data:application/pdf;base64,".length);
    }

    const byteCharacters = atob(base64WithoutPrefix);
    const byteNumbers = new Array(byteCharacters.length);
    for (let i = 0; i < byteCharacters.length; i++) {
      byteNumbers[i] = byteCharacters.charCodeAt(i);
    }
    const byteArray = new Uint8Array(byteNumbers);
    const blob = new Blob([byteArray], { type: "application/pdf" });
    const blobUrl = URL.createObjectURL(blob);

    if (isMobile) {
      window.open(blobUrl, "_blank");
      return;
    }

    if (isCallerMicroApp) {
      const pdfDataUrl = base64.startsWith("data:application/pdf;base64,")
        ? base64
        : `data:application/pdf;base64,${base64}`;
      const newWindow = window.open();
      if (newWindow) {
        newWindow.document.write(`<iframe width='100%' height='100%' src='${pdfDataUrl}'></iframe>`);
      }
      return;
    }

    const printJSModule = (await import("print-js")).default;
    printJSModule({
      printable: base64WithoutPrefix,
      type: "pdf",
      base64: true
    });
  }

  public static printExcel(base64: any) {
    console.log("TODO: SYSTEM FUNCTION NOT IMPLEMENTED YET: printExcel");
    console.log(base64);
  }

  // Local Storage
  // addToBag: _addToBag,
  // removeFromBag: _removeFromBag,
  // clearBag: _clearBag,

  // Location

  public static async locationCoordinatesOfAdress(address: string): Promise<any> {
    if (address === undefined || address === "") {
      return { data: { latitude: "0", longitude: "0" } };
    }
    const useAmapForward: boolean = isAmapProvider();
    if (useAmapForward) {
      return await this.locationCoordinatesOfAdressAmap(address);
    }
    if (!this.isDocumentReady()) {
      return new Promise((resolve) => {
        setTimeout(async () => {
          const res = await this.locationCoordinatesOfAdress(address);
          resolve(res);
        }, 100);
      });
    }

    const geocoder = new google.maps.Geocoder();

    try {
      const response = await geocoder.geocode({ address });
      if (response?.results.length > 0) {
        const lat = response.results[0].geometry?.location?.lat();
        const lng = response.results[0].geometry?.location?.lng();
        const result = { data: { latitude: lat, longitude: lng } };
        return result;
      }
    } catch (error) {
      KMainFunctions.exceptionHandler(error);
      return { data: { latitude: undefined, longitude: undefined } };
    }
    // No match: same shape as the failure and Amap paths so `res.data.latitude` never throws.
    return { data: { latitude: undefined, longitude: undefined } };
  }

  public static async locationAdressOfCoordinates(latitude: any, longitude: any): Promise<any> {
    // Inputs are action parameters: numbers, numeric strings, null/"" when a field is empty.
    // Anything that is not a finite pair is "no coordinate" — it must not become (lat, 0) or NaN.
    const point: IGeoPoint | null = toCoordinatePair(latitude, longitude);
    if (!point) {
      return { data: { address: "", city: "", state: "", country: "" } };
    }
    const useAmapReverse: boolean = isAmapProvider();
    if (useAmapReverse) {
      return await this.locationAdressOfCoordinatesAmap(point.latitude, point.longitude);
    }
    if (!this.isDocumentReady()) {
      return new Promise((resolve) => {
        setTimeout(async () => {
          const res = await this.locationAdressOfCoordinates(latitude, longitude);
          resolve(res);
        }, 100);
      });
    }

    const geocoder = new google.maps.Geocoder();

    try {
      const response = await geocoder.geocode({
        location: { lat: Number(latitude), lng: Number(longitude) }
      });

      let city: any;
      let state: any;
      let country: any;
      let address: any;
      let neighborhood: any;
      let street: any;
      let postalCode: any;

      const r = response.results[0];
      if (r) {
        address = r.formatted_address;
        const { address_components } = r;
        if (address_components?.length > 0) {
          for (let i = 0; i < address_components.length; i++) {
            if (address_components[i]?.types?.length > 0) {
              for (let j = 0; j < address_components[i].types.length; j++) {
                if (address_components[i]?.types) {
                  switch (address_components[i].types[j]) {
                    case "administrative_area_level_1":
                      city = address_components[i].long_name;
                      break;
                    case "administrative_area_level_2":
                      state = address_components[i].long_name;
                      break;
                    case "country":
                      country = address_components[i].long_name;
                      break;
                    case "administrative_area_level_4":
                      neighborhood = address_components[i].long_name;
                      break;
                    case "route":
                      street = address_components[i].long_name;
                      break;
                    case "postal_code":
                      postalCode = address_components[i].long_name;
                      break;
                  }
                }
              }
            }
          }
        }
      }
      const result = {
        data: {
          address,
          city,
          state,
          country,
          neighborhood,
          street,
          postalCode
        }
      };
      return result;
    } catch (error) {
      KMainFunctions.exceptionHandler(error);
      return {
        data: {
          address: undefined,
          city: undefined,
          state: undefined,
          country: undefined
        }
      };
    }
  }

  /**
   * Wraps an Amap plugin callback in a promise that always settles. The JSAPI never invokes the
   * callback when the key is over quota, the security code is rejected or the request is lost —
   * Google's SDK returns its own always-settling promise, so without this the action chain after
   * a geocode would hang forever on Amap.
   */
  private static amapCallbackWithTimeout<T>(
    fallback: T,
    run: (resolve: (value: T) => void) => void,
    timeoutMs: number = 10000
  ): Promise<T> {
    return new Promise<T>((resolve) => {
      let settled: boolean = false;
      const settle = (value: T): void => {
        if (settled) return;
        settled = true;
        clearTimeout(timer);
        resolve(value);
      };
      const timer: ReturnType<typeof setTimeout> = setTimeout(() => settle(fallback), timeoutMs);
      try {
        run(settle);
      } catch (error) {
        KMainFunctions.exceptionHandler(error);
        settle(fallback);
      }
    });
  }

  // Amap forward geocoding. Amap returns GCJ-02 coordinates; Kuika stores WGS-84,
  // so the result is converted back with gcj02ToWgs84 before returning.
  private static async locationCoordinatesOfAdressAmap(address: string): Promise<ILocationCoordinatesResult> {
    // Region-aware path first: the backend routes between the mainland and Global Maps
    // platforms; the JSAPI plugin below only knows the mainland engine (30001 for any
    // non-China address). `undefined` means the backend is not emitted / unreachable.
    const viaBackend: IGeoPoint | null | undefined = await geocodeAddressViaBackend(address);
    if (viaBackend !== undefined) {
      if (viaBackend === null) return { data: { latitude: undefined, longitude: undefined } };
      return { data: { latitude: viaBackend.latitude, longitude: viaBackend.longitude } };
    }

    try {
      const amapNamespace: typeof AMap = await loadAMap();
      const geocoder: IAMapGeocoder = new (amapNamespace as unknown as IAMapGeocoderNamespace).Geocoder();
      const noMatch: ILocationCoordinatesResult = { data: { latitude: undefined, longitude: undefined } };
      return await this.amapCallbackWithTimeout<ILocationCoordinatesResult>(noMatch, (resolve) => {
        geocoder.getLocation(address, (status: string, result: IAMapForwardGeocodeResult) => {
          const geocodes: IAMapForwardGeocode[] | undefined = result?.geocodes;
          const gcj: IGeoPoint | null =
            status === "complete" && geocodes && geocodes.length > 0 ? readLngLat(geocodes[0].location) : null;
          if (gcj) {
            const converted: IGeoPoint = gcj02ToWgs84(gcj.latitude, gcj.longitude);
            resolve({ data: { latitude: converted.latitude, longitude: converted.longitude } });
            return;
          }
          resolve(noMatch);
        });
      });
    } catch (error) {
      KMainFunctions.exceptionHandler(error);
      return { data: { latitude: undefined, longitude: undefined } };
    }
  }

  // Amap reverse geocoding. Input coordinates are WGS-84 (Kuika storage) and are
  // converted to GCJ-02 with wgs84ToGcj02 before querying Amap. The Amap address
  // component hierarchy is mapped onto the same shape the Google path returns
  // (province -> city, city -> state) so downstream bindings are unchanged.
  private static async locationAdressOfCoordinatesAmap(
    latitude: number,
    longitude: number
  ): Promise<ILocationAddressResult> {
    // Region-aware path first (see locationCoordinatesOfAdressAmap).
    const viaBackend: IBackendReverseGeocodeResult | undefined = await reverseGeocodeViaBackend(latitude, longitude);
    if (viaBackend !== undefined) {
      const mapped: IBackendLocationAddressData = toLocationAddress(viaBackend);
      return { data: mapped };
    }

    try {
      const amapNamespace: typeof AMap = await loadAMap();
      const geocoder: IAMapGeocoder = new (amapNamespace as unknown as IAMapGeocoderNamespace).Geocoder();
      const gcj: IGeoPoint = wgs84ToGcj02(latitude, longitude);
      const noMatch: ILocationAddressResult = {
        data: { address: undefined, city: undefined, state: undefined, country: undefined }
      };
      return await this.amapCallbackWithTimeout<ILocationAddressResult>(noMatch, (resolve) => {
        geocoder.getAddress([gcj.longitude, gcj.latitude], (status: string, result: IAMapReverseGeocodeResult) => {
          const regeocode: IAMapReGeocode | undefined = result?.regeocode;
          if (status === "complete" && regeocode) {
            const component: IAMapAddressComponent | undefined = regeocode.addressComponent;
            // Amap sends [] instead of a string for tiers that do not apply (e.g. "city" in the
            // direct-administered municipalities); a missing tier is undefined, like Google's path.
            const text = (value: string | string[] | undefined): string | undefined =>
              typeof value === "string" && value !== "" ? value : undefined;
            resolve({
              data: {
                address: regeocode.formattedAddress,
                city: text(component?.province),
                state: text(component?.city),
                country: text(component?.country),
                neighborhood: text(component?.district),
                street: text(component?.street),
                // Amap's JSAPI reverse geocode carries no postcode.
                postalCode: undefined
              }
            });
            return;
          }
          resolve(noMatch);
        });
      });
    } catch (error) {
      KMainFunctions.exceptionHandler(error);
      return { data: { address: undefined, city: undefined, state: undefined, country: undefined } };
    }
  }

  public static async locationGetCurrentCoordinates(): Promise<any> {
    try {
      if (ReactSystemFunctions.isMapWithLiveLocationTrackingPresented()) {
        if (watchPositionId == null) {
          const firstPosition = await this.initializeWatchPositionAndGetFirstPosition();
          return { data: firstPosition };
        }
        return {
          data: watchPositionData ?? {
            accuracy: undefined,
            latitude: undefined,
            longitude: undefined
          }
        };
      }

      if (watchPositionId != null) {
        ReactSystemFunctions.clearWatchPosition();
      }

      const coordinates = await this.locationGetCurrentCoordinatesPromise();
      const result = {
        data: {
          accuracy: coordinates?.coords?.accuracy,
          latitude: coordinates?.coords?.latitude,
          longitude: coordinates?.coords?.longitude
        }
      };
      return result;
    } catch (error) {
      KMainFunctions.exceptionHandler(error);
      return {
        data: {
          accuracy: undefined,
          latitude: undefined,
          longitude: undefined
        }
      };
    }
  }

  static async locationGetCurrentCoordinatesPromise(): Promise<any> {
    return new Promise((resolve, reject) => {
      navigator.geolocation.getCurrentPosition(resolve, reject, {
        enableHighAccuracy: true, // Use high-accuracy mode, if available
        timeout: 10000, // Set a timeout of 10 seconds
        maximumAge: 0 // Force a fresh location
      });
    });
  }

  private static isMapWithLiveLocationTrackingPresented = () => {
    const mapElements = document.getElementsByClassName("kuika_maps_with_live_location");

    if (mapElements && mapElements.length > 0) {
      return true;
    }
    return false;
  };

  private static initializeWatchPositionAndGetFirstPosition = (): Promise<{
    accuracy: number;
    latitude: number;
    longitude: number;
  }> => {
    return new Promise((resolve, reject) => {
      if (!navigator.geolocation) {
        reject(new Error("Geolocation is not supported"));
        return;
      }

      watchPositionId = navigator.geolocation.watchPosition(
        (position) => {
          watchPositionData = position.coords;
          ReactSystemFunctions.dispatchLocationUpdate(position.coords);
          resolve({
            accuracy: position.coords.accuracy,
            latitude: position.coords.latitude,
            longitude: position.coords.longitude
          });
        },
        (error) => {
          reject(error);
        },
        {
          enableHighAccuracy: true,
          timeout: 10000,
          maximumAge: 0
        }
      );
    });
  };

  private static dispatchLocationUpdate = (coords: GeolocationCoordinates) => {
    const event = new CustomEvent("kuika-watch-position-update", {
      detail: {
        latitude: coords.latitude,
        longitude: coords.longitude,
        accuracy: coords.accuracy
      }
    });
    window.dispatchEvent(event);
  };

  private static clearWatchPosition = () => {
    if (navigator.geolocation && watchPositionId !== null) {
      navigator.geolocation.clearWatch(watchPositionId);
      watchPositionId = null;
      watchPositionData = null;
    }
  };

  // UI
  public static changeVisibilityOf(screen: any, stateName: string, isVisible: string, _arg: string = "") {
    const obj = {};
    obj[stateName] = isVisible;
    screen.setState(obj);
  }

  public static toggleVisibilityOf(screen: any, stateName: string) {
    const obj = {};
    let isVisible = screen.state[stateName];
    if (isVisible === "hidden") {
      isVisible = "visible";
    } else {
      isVisible = "hidden";
    }
    obj[stateName] = isVisible;
    screen.setState(obj);
  }

  public static toggleEditabilityOf(screen: any, stateName: string) {
    const obj = {};
    let isVisible = screen.state[stateName];
    if (isVisible === "disabled") {
      isVisible = "enabled";
    } else {
      isVisible = "disabled";
    }
    obj[stateName] = isVisible;
    screen.setState(obj);
  }

  public static changeEnabledOf(screen: any, stateName: string, isEnabled: string) {
    const obj = {};
    obj[stateName] = isEnabled;
    screen.setState(obj);
  }

  // Normalizes antd Collapse onChange payloads (string | string[] | undefined) into the
  // string[] shape the generated isComp{Id}CollapseActiveKeys state variable holds.
  public static normalizeCollapseActiveKeys(activeKey: any): string[] {
    if (activeKey === undefined || activeKey === null || activeKey === "") {
      return [];
    }
    const keys: any[] = Array.isArray(activeKey) ? activeKey : [activeKey];
    return keys.filter((key: any) => key !== undefined && key !== null).map((key: any) => key.toString());
  }

  public static openCollapsePanelOf(screen: any, stateName: string, panelKey: string) {
    const key: string = panelKey?.toString();
    if (!key) {
      return;
    }
    const currentKeys: string[] = ReactSystemFunctions.normalizeCollapseActiveKeys(screen.state[stateName]);
    if (currentKeys.includes(key)) {
      return;
    }
    const obj = {};
    obj[stateName] = [...currentKeys, key];
    screen.setState(obj);
  }

  public static closeCollapsePanelOf(screen: any, stateName: string, panelKey: string) {
    const key: string = panelKey?.toString();
    if (!key) {
      return;
    }
    const currentKeys: string[] = ReactSystemFunctions.normalizeCollapseActiveKeys(screen.state[stateName]);
    if (!currentKeys.includes(key)) {
      return;
    }
    const obj = {};
    obj[stateName] = currentKeys.filter((currentKey: string) => currentKey !== key);
    screen.setState(obj);
  }

  public static toggleCollapsePanelOf(screen: any, stateName: string, panelKey: string) {
    const key: string = panelKey?.toString();
    if (!key) {
      return;
    }
    const currentKeys: string[] = ReactSystemFunctions.normalizeCollapseActiveKeys(screen.state[stateName]);
    const obj = {};
    if (currentKeys.includes(key)) {
      obj[stateName] = currentKeys.filter((currentKey: string) => currentKey !== key);
    } else {
      obj[stateName] = [...currentKeys, key];
    }
    screen.setState(obj);
  }

  // The same role reads "admin" in one project and "ADMIN" in another, because KRole is shared
  // across the workspace. Ids stay exact.
  private static normalizeRoleName(value: string): string {
    return (value ?? "").trim().toLowerCase();
  }

  // The table is keyed by the designer's spelling, the user carries KRole's. On a mismatch the user
  // silently lands on the project default — no error, no log. An empty name matches nothing.
  private static findRoleStartingScreenId(roleStartingScreenIdList: IGeneratedLookupEntry[], roleName: string): string {
    const normalized: string = ReactSystemFunctions.normalizeRoleName(roleName);
    if (normalized.length === 0) {
      return "";
    }
    const match: IGeneratedLookupEntry | undefined = (roleStartingScreenIdList ?? []).find(
      (entry: IGeneratedLookupEntry) => ReactSystemFunctions.normalizeRoleName(entry?.key) === normalized
    );
    return match?.value ?? "";
  }

  public static isPermittedRole(permittedRole: string, role: { id: string; name: string }): boolean {
    if (permittedRole === role?.id) {
      return true;
    }
    const permitted: string = ReactSystemFunctions.normalizeRoleName(permittedRole);
    return permitted.length > 0 && permitted === ReactSystemFunctions.normalizeRoleName(role?.name);
  }

  public static hasAnyRoleName(permittedRoleNames: string[], userRoleNames: string[]): boolean {
    const permitted: string[] = (permittedRoleNames ?? [])
      .map(ReactSystemFunctions.normalizeRoleName)
      .filter((roleName: string) => roleName.length > 0);
    return (userRoleNames ?? []).some((roleName: string) => {
      const normalized: string = ReactSystemFunctions.normalizeRoleName(roleName);
      return normalized.length > 0 && permitted.includes(normalized);
    });
  }

  public static hideIsNotAuthorized(screen: any, stateName: string, roleIds: string[]) {
    const obj = {} as any;
    let isVisible = "hidden";
    const { userInfo } = screen.props.context;
    if (userInfo == null || userInfo == undefined) return isVisible;
    const role =
      userInfo.roles &&
      userInfo.roles.find((r: { id: string; name: string }) =>
        roleIds.find((p) => ReactSystemFunctions.isPermittedRole(p, r))
      );
    if (role || roleIds.length == 0) {
      isVisible = "visible";
    }
    obj[stateName] = isVisible;
    screen.setState(obj);
  }

  public static sendWhatsappMessage(number: string, message: string) {
    const urlParams = new URLSearchParams(window.location.search);
    const redirectOnMobileValue = urlParams.get("redirectOnMobile");

    if (redirectOnMobileValue === "true") {
      this.postWebKitMessage(null, {
        actionType: "SEND_WP_MESSAGE",
        number: `${number}`,
        message: `${message}`
      });
    } else {
      window.open(`https://wa.me/${number}?text=${encodeURIComponent(message)}`);
    }
  }

  public static disableIsNotAuthorized(screen: any, stateName: string, roleIds: string[]) {
    const obj = {} as any;
    let isEnabled = "disabled";
    const { userInfo } = screen.props.context;
    const role = userInfo?.roles?.find((r: { id: string; name: string }) =>
      roleIds.find((p) => ReactSystemFunctions.isPermittedRole(p, r))
    );
    if (role) {
      isEnabled = "enabled";
    }
    obj[stateName] = isEnabled;
    screen.setState(obj);
  }

  public static setValueOf(
    screen: any,
    componentName: any,
    value: any,
    multipleValuePropName?: string | null,
    _pk?: any
  ) {
    if (!screen) return;
    // pagination case start
    if (
      screen[`${componentName}_kuikaPaginationRef`] != undefined ||
      screen[`${componentName}_kuikaPaginationRef`] != null
    ) {
      if (
        screen[`${componentName}_kuikaPaginationRef`].current != undefined &&
        screen[`${componentName}_kuikaPaginationRef`].current != null &&
        screen[`${componentName}_kuikaPaginationRef`].current.setPaginationData != undefined
      ) {
        if (
          multipleValuePropName === "pageSize" &&
          screen[`${componentName}_kuikaPaginationRef`].current.setPageSize != undefined
        ) {
          screen[`${componentName}_kuikaPaginationRef`].current.setPageSize(value);
        } else {
          screen[`${componentName}_kuikaPaginationRef`].current.setPaginationData(value);
        }
      }
    }
    // pagination case end
    if (screen[`${componentName}_kuikaTableRef`] != undefined || screen[`${componentName}_kuikaTableRef`] != null) {
      if (
        screen[`${componentName}_kuikaTableRef`].current != undefined &&
        screen[`${componentName}_kuikaTableRef`].current != null &&
        screen[`${componentName}_kuikaTableRef`].current.setSelectedValues != undefined
      ) {
        if (
          multipleValuePropName === "selectedValues" &&
          screen[`${componentName}_kuikaTableRef`].current.setSelectedValues != undefined
        ) {
          screen[`${componentName}_kuikaTableRef`].current.setSelectedValues(value);
        }
      }
    }
    // MicroApp
    else if (
      screen[`${componentName}_kuikaMicroAppRef`] != undefined ||
      screen[`${componentName}_kuikaMicroAppRef`] != null
    ) {
      if (screen[`${componentName}_kuikaMicroAppRef`].current) {
        screen[`${componentName}_kuikaMicroAppRef`].current.setProjectId?.(value);
      }
    } else if (
      screen[`${componentName}_kuikaChatRef`] != undefined &&
      screen[`${componentName}_kuikaChatRef`] != null &&
      screen[`${componentName}_kuikaChatRef`].current
    ) {
      if (multipleValuePropName === "message" && screen[`${componentName}_kuikaChatRef`].current.setMessage) {
        screen[`${componentName}_kuikaChatRef`].current.setMessage(value);
      }

      if (
        multipleValuePropName === "currentlyEditingMessageId" &&
        screen[`${componentName}_kuikaChatRef`].current.setCurrentlyEditingMessageId
      ) {
        screen[`${componentName}_kuikaChatRef`].current.setCurrentlyEditingMessageId(value);
      }
    } else if (
      screen[`${componentName}_kuikaWebViewRef`] != undefined ||
      screen[`${componentName}_kuikaWebViewRef`] != null
    ) {
      if (screen[`${componentName}_kuikaWebViewRef`].current) {
        if (screen[`${componentName}_kuikaWebViewRef`].current.setUrl) {
          screen[`${componentName}_kuikaWebViewRef`].current.setUrl(value);
        }
      }
    } else if (
      screen[`${componentName}_kuikaCarouselRef`] != undefined ||
      screen[`${componentName}_kuikaCarouselRef`] != null
    ) {
      if (screen[`${componentName}_kuikaCarouselRef`].current) {
        if (screen[`${componentName}_kuikaCarouselRef`].current.setStartingIndex) {
          screen[`${componentName}_kuikaCarouselRef`].current.setStartingIndex(value);
        }
      }
    }
    // Document CASE START
    else if (screen[`${componentName}_kuikaDocumentRef`] != undefined) {
      const ref = screen[`${componentName}_kuikaDocumentRef`];
      // "mode" targets the view/readonly/edit setter; anything else (incl. legacy single-target
      // calls with no propName) targets versionId for backward compatibility.
      const targetsMode: boolean = (multipleValuePropName ?? "").toLowerCase() === "mode";
      const setterName: "setMode" | "setVersionId" = targetsMode ? "setMode" : "setVersionId";
      const applySetter = (): void => {
        ref.current[setterName](value);
      };
      if (ref.current?.[setterName]) {
        applySetter();
      } else {
        // Component not mounted yet — wait for ref to be ready, then call
        const waitForRef = () => {
          if (ref.current?.[setterName]) {
            applySetter();
          } else {
            setTimeout(waitForRef, 50);
          }
        };
        setTimeout(waitForRef, 50);
      }
      return;
    }
    // Document CASE END
    // DocumentCompare CASE START
    else if (screen[`${componentName}_kuikaDocumentCompareRef`] != undefined) {
      const ref = screen[`${componentName}_kuikaDocumentCompareRef`];
      const setter = multipleValuePropName === "rightVersionId" ? "setRightVersionId" : "setLeftVersionId";
      if (ref.current?.[setter]) {
        ref.current[setter](value);
      } else {
        const waitForRef = () => {
          if (ref.current?.[setter]) {
            ref.current[setter](value);
          } else {
            setTimeout(waitForRef, 50);
          }
        };
        setTimeout(waitForRef, 50);
      }
      return;
    }
    // DocumentCompare CASE END
    // Directory CASE START
    else if (screen[`${componentName}_kuikaDirectoryRef`] != undefined) {
      const ref = screen[`${componentName}_kuikaDirectoryRef`];
      // multipleValuePropName comes from the SetValueOf "Prop name to set" dropdown
      // (selectedFolderId / selectedDocumentId / selectedVersionId); default to folder selection.
      let setter = "setSelectedFolderId";
      if (multipleValuePropName === "selectedDocumentId") setter = "setSelectedDocumentId";
      else if (multipleValuePropName === "selectedVersionId") setter = "setSelectedVersionId";
      if (ref.current?.[setter]) {
        ref.current[setter](value);
      } else {
        // Component not mounted yet — wait for the ref to be ready, then call.
        const waitForRef = () => {
          if (ref.current?.[setter]) {
            ref.current[setter](value);
          } else {
            setTimeout(waitForRef, 50);
          }
        };
        setTimeout(waitForRef, 50);
      }
      return;
    }
    // Directory CASE END
    // LocationSearch CASE START
    else if (
      screen[`${componentName}_kuikaPlacesAutocompleteInputRef`] != undefined &&
      screen[`${componentName}_kuikaPlacesAutocompleteInputRef`] != null
    ) {
      // KOA-18575: `address` / `latitude` / `longitude` are separate value props, so a SetValueOf
      // with one of them writes that field alone; the legacy compound `value` still goes through
      // handleChange. The component pushes the result into the Form.Item itself.
      const locationSearch = screen[`${componentName}_kuikaPlacesAutocompleteInputRef`].current;
      if (locationSearch != null) {
        if (isLocationSearchField(multipleValuePropName) && locationSearch.setLocationField) {
          locationSearch.setLocationField(multipleValuePropName, value);
        } else if (locationSearch.handleChange) {
          locationSearch.handleChange(value);
        }
      }
    }
    // LocationSearch CASE END
    else if (
      screen[`${componentName}_kuikaDateRef`] != undefined ||
      screen[`${componentName}_kuikaDateRef`] != null ||
      screen[`${componentName}_kuikaDatePickerRef`] != undefined ||
      screen[`${componentName}_kuikaDatetimeRef`] != undefined
    ) {
      let refText =
        screen[`${componentName}_kuikaDateRef`] != undefined
          ? "_kuikaDateRef"
          : screen[`${componentName}_kuikaDatePickerRef`] !== undefined
            ? "_kuikaDatePickerRef"
            : screen[`${componentName}_kuikaDatetimeRef`] !== undefined
              ? "_kuikaDatetimeRef"
              : "";
      if (screen[`${componentName}${refText}`].current) {
        if (
          screen[`${componentName}${refText}`].current.setDisableBeforeDate &&
          multipleValuePropName === "disablebeforedate"
        ) {
          screen[`${componentName}${refText}`].current.setDisableBeforeDate(value);
          return;
        }
        // KOA-17521: route a bound disableAfterDate to the imperative setter (state-only constraint
        // update). Missing this branch, the call fell through to setFieldsValue below and overwrote
        // the Date's own value — the exact regression reported for disableAfterDate bindings.
        if (
          screen[`${componentName}${refText}`].current.setDisableAfterDate &&
          multipleValuePropName === "disableafterdate"
        ) {
          screen[`${componentName}${refText}`].current.setDisableAfterDate(value);
          return;
        }
        if (
          screen[`${componentName}${refText}`].current.setDisableBeforeTime &&
          multipleValuePropName === "disablebeforetime"
        ) {
          screen[`${componentName}${refText}`].current.setDisableBeforeTime(value);
          return;
        }
        if (
          screen[`${componentName}${refText}`].current.setDisableAfterTime &&
          multipleValuePropName === "disableaftertime"
        ) {
          screen[`${componentName}${refText}`].current.setDisableAfterTime(value);
          return;
        }
      }
      const data = {};
      data[componentName] = value;
      // KOA-18430 — mark the paint so a table-column editor still shows it in every row.
      markExplicitFieldWrite(componentName);
      screen.props.form.setFieldsValue(data);
      return Guid.create().toString();
    } else if (
      screen?.[`${componentName}_kuikaCalendarRef`]?.current != undefined &&
      screen?.[`${componentName}_kuikaCalendarRef`]?.current != null
    ) {
      if (multipleValuePropName === "defaultPanel") {
        screen?.[`${componentName}_kuikaCalendarRef`]?.current?.setPanel(value);
      } else if (isCalendarDateField(multipleValuePropName)) {
        // KOA-18577: a date field navigates the view; before this it was dropped silently.
        screen?.[`${componentName}_kuikaCalendarRef`]?.current?.setDateValue?.(multipleValuePropName, value);
      }
      // _kuikaTextInputRef
    } else if (
      screen?.[`${componentName}_kuikaTextInputRef`]?.current != undefined &&
      screen?.[`${componentName}_kuikaTextInputRef`]?.current != null &&
      multipleValuePropName === "mask"
    ) {
      screen?.[`${componentName}_kuikaTextInputRef`]?.current?.setMask?.(value);
    } else {
      const data = {};
      // "value" is the single-value component's whole field, not a key inside it: the generated
      // component-to-component watcher passes the target prop name, and wrapping a Label's text in
      // `{ value }` rendered "[object Object]" (KOA-18575). Multi-value components with a prop
      // literally named "value" (LocationSearch) are dispatched before this branch.
      if (multipleValuePropName && multipleValuePropName !== "value") {
        const previous = screen.props.form.getFieldValue(componentName);
        // A copy, never the previous value written in place: components keep the field's object
        // as their own state too (the Maps value is BaseTable's state.value), and an in-place
        // write made their previous state already hold the new field, so the change was never
        // detected — SetValueOf on a Maps circleRadius left the circle unchanged (KOA-18838).
        let next = {};
        if (Array.isArray(previous)) {
          next = [...previous];
        } else if (typeof previous === "object" && previous !== null) {
          next = { ...previous };
        }
        next[multipleValuePropName] = value;
        data[componentName] = next;
      } else {
        data[componentName] = value;
      }

      // KOA-18430 — mark the paint so a table-column editor still shows it in every row.
      markExplicitFieldWrite(componentName);
      screen.props.form.setFieldsValue(data);
      return Guid.create().toString();
    }
  }

  public static toggleLeftMenu(screen: any): string {
    screen.setState({ isLeftMenuVisible: !screen.state.isLeftMenuVisible });
    return "";
  }

  // changePassword moved to BaseReactSystemFunctions (RNM-0109).

  public static readFromLocalStorage(key: string) {
    return window.localStorage.getItem(key);
  }

  public static writeToLocalStorage(key: string, value: string) {
    window.localStorage.setItem(key, value);
  }

  public static deleteFromLocalStorage(key: string) {
    window.localStorage.removeItem(key);
  }

  public static readFromSessionStorage(key: string) {
    return window.sessionStorage.getItem(key);
  }

  public static writeToSessionStorage(key: string, value: string) {
    window.sessionStorage.setItem(key, value);
  }

  public static deleteFromSessionStorage(key: string) {
    window.sessionStorage.removeItem(key);
  }

  private static readonly BARCODE_FORMATS = [
    "qr_code",
    "ean_13",
    "ean_8",
    "code_128",
    "code_39",
    "code_93",
    "upc_a",
    "upc_e",
    "itf",
    "pdf417",
    "aztec",
    "data_matrix",
    "codabar"
  ];

  private static readonly CAMERA_CONSTRAINTS: MediaTrackConstraints = {
    facingMode: { ideal: "environment" },
    width: { ideal: 1280 },
    height: { ideal: 720 }
  };

  private static buildBarcodeOverlay = (): IBarcodeOverlayHandles => {
    const overlay = document.createElement("div");
    overlay.style.cssText = [
      "position:fixed",
      "inset:0",
      "z-index:99999",
      "background:rgba(0,0,0,0.92)",
      "display:flex",
      "flex-direction:column",
      "align-items:center",
      "justify-content:center",
      "font-family:sans-serif"
    ].join(";");

    const box = document.createElement("div");
    box.style.cssText = [
      "position:relative",
      "width:min(90vw,400px)",
      "height:min(90vw,400px)",
      "border-radius:12px",
      "overflow:hidden",
      "background:#000",
      "box-shadow:0 0 0 2px #246DFF"
    ].join(";");

    const cornerStyles = [
      "top:0;left:0;border-top:3px solid #246DFF;border-left:3px solid #246DFF",
      "top:0;right:0;border-top:3px solid #246DFF;border-right:3px solid #246DFF",
      "bottom:0;left:0;border-bottom:3px solid #246DFF;border-left:3px solid #246DFF",
      "bottom:0;right:0;border-bottom:3px solid #246DFF;border-right:3px solid #246DFF"
    ];
    cornerStyles.forEach((style) => {
      const corner = document.createElement("div");
      corner.style.cssText = `position:absolute;width:20px;height:20px;z-index:2;${style}`;
      box.appendChild(corner);
    });

    if (!document.getElementById("kuika-scan-style")) {
      const style = document.createElement("style");
      style.id = "kuika-scan-style";
      style.textContent = "@keyframes kuikaScan{0%,100%{top:8px}50%{top:calc(100% - 10px)}}";
      document.head.appendChild(style);
    }
    const scanLine = document.createElement("div");
    scanLine.style.cssText = [
      "position:absolute",
      "left:8px",
      "right:8px",
      "height:2px",
      "background:linear-gradient(90deg,transparent,#246DFF,transparent)",
      "z-index:2",
      "animation:kuikaScan 2s ease-in-out infinite"
    ].join(";");
    box.appendChild(scanLine);

    const video = document.createElement("video");
    video.style.cssText = "width:100%;height:100%;object-fit:cover";
    video.setAttribute("autoplay", "");
    video.setAttribute("muted", "");
    video.setAttribute("playsinline", "");
    box.appendChild(video);

    const label = document.createElement("p");
    label.textContent = translationService.translate("scan_barcode.instruction");
    label.style.cssText = "color:#ccc;font-size:13px;margin:16px 0 0;text-align:center;padding:0 16px";

    const cancelBtn = document.createElement("button");
    cancelBtn.textContent = translationService.translate("common.cancel");
    cancelBtn.style.cssText = [
      "margin-top:20px",
      "padding:10px 32px",
      "border-radius:8px",
      "border:none",
      "background:#333",
      "color:#fff",
      "font-size:14px",
      "cursor:pointer"
    ].join(";");

    overlay.appendChild(box);
    overlay.appendChild(label);
    overlay.appendChild(cancelBtn);
    document.body.appendChild(overlay);

    return { overlay, video, label, cancelBtn };
  };

  private static startNativeDetector = (
    video: HTMLVideoElement,
    onDetect: (value: string) => void,
    onFrame: (id: number) => void
  ): void => {
    const DetectorCtor = window.BarcodeDetector as IBarcodeDetectorCtor;
    const detector = new DetectorCtor({
      formats: ReactSystemFunctions.BARCODE_FORMATS
    });

    const scanFrame = () => {
      if (video.readyState < video.HAVE_CURRENT_DATA) {
        onFrame(requestAnimationFrame(scanFrame));
        return;
      }
      detector
        .detect(video)
        .then((results) => {
          if (results.length > 0) onDetect(results[0].rawValue);
          else onFrame(requestAnimationFrame(scanFrame));
        })
        .catch(() => onFrame(requestAnimationFrame(scanFrame)));
    };

    onFrame(requestAnimationFrame(scanFrame));
  };

  private static startZXingReader = (
    video: HTMLVideoElement,
    onDetect: (value: string) => void,
    onStreamReady: (stream: MediaStream) => void,
    onReaderReady: (reader: BrowserMultiFormatReader) => void,
    onError: (message: string) => void
  ): void => {
    const reader = new BrowserMultiFormatReader();
    onReaderReady(reader);

    reader
      .decodeFromConstraints({ video: ReactSystemFunctions.CAMERA_CONSTRAINTS }, video, (result) => {
        if (result) onDetect(result.getText());
      })
      .then(() => {
        if (video.srcObject instanceof MediaStream) onStreamReady(video.srcObject);
      })
      .catch((error) => onError(error instanceof Error ? error.message : String(error)));
  };

  public static scanBarcode(): Promise<string | undefined> {
    return new Promise((resolve, reject) => {
      const { overlay, video, label, cancelBtn } = ReactSystemFunctions.buildBarcodeOverlay();

      let stream: MediaStream | null = null;
      let rafId: number | null = null;
      let zxingReader: BrowserMultiFormatReader | null = null;
      let settled = false;

      const settle = (value: string | undefined) => {
        if (settled) return;
        settled = true;
        cleanup();
        resolve(value);
      };

      const timeoutId = setTimeout(() => settle(undefined), 120_000);

      const cleanup = () => {
        clearTimeout(timeoutId);
        if (rafId !== null) {
          cancelAnimationFrame(rafId);
          rafId = null;
        }
        if (zxingReader) {
          try {
            zxingReader.reset();
          } catch {
            /* reader already stopped */
          }
          zxingReader = null;
        }
        if (stream) {
          stream.getTracks().forEach((t) => t.stop());
          stream = null;
        }
        if (overlay.parentNode) document.body.removeChild(overlay);
      };

      cancelBtn.addEventListener("click", () => settle(undefined));

      if (window.BarcodeDetector) {
        navigator.mediaDevices
          .getUserMedia({ video: ReactSystemFunctions.CAMERA_CONSTRAINTS })
          .then((s) => {
            stream = s;
            video.srcObject = s;
            return video.play();
          })
          .then(() =>
            ReactSystemFunctions.startNativeDetector(video, settle, (id) => {
              rafId = id;
            })
          )
          .catch((err) => {
            cleanup();
            reject(new Error(`Camera access denied: ${err instanceof Error ? err.message : String(err)}`));
          });
      } else {
        ReactSystemFunctions.startZXingReader(
          video,
          settle,
          (s) => {
            stream = s;
          },
          (reader) => {
            zxingReader = reader;
          },
          (msg) => {
            label.textContent = translationService.translate("scan_barcode.camera_error", undefined, { msg });
            label.style.color = "#f87171";
            setTimeout(() => settle(undefined), 2500);
          }
        );
      }
    });
  }

  // Remaining
  // isValid: _isValid,

  public static validateToken() {}

  public static async downloadFile(data: string | IRestResult, filename?: string): Promise<void> {
    if (!data || data === "") {
      this.notify(undefined, "Invalid file data.", "warning", "bottom-right", 3, null, null, null);
      return;
    }
    if (typeof data === "string" && KMainFunctions.isValidUrl(data)) {
      const blob: Blob = await KMainFunctions.toBlob(data);
      KMainFunctions.downloadFile(
        blob,
        KMainFunctions.generateFilenameForDownloadFile(
          filename,
          KMainFunctions.getExtensionByMimeType(filename, blob.type)
        )
      );
      return;
    }

    if (typeof data === "string" && Guid.parse(data).toString() !== Guid.EMPTY) {
      const url = KMainFunctions.getUrlByWithResourceId(data);
      const blob: Blob = await KMainFunctions.toBlob(url);
      KMainFunctions.downloadFile(
        blob,
        KMainFunctions.generateFilenameForDownloadFile(
          filename,
          KMainFunctions.getExtensionByMimeType(filename, blob.type)
        )
      );
      return;
    }

    if (typeof data === "string" && KMainFunctions.isBase64(data)) {
      const mimeType = await KMainFunctions.getFileType(data);
      const blob = new Blob([KMainFunctions.base64ToUint8Array(data)], {
        type: mimeType
      });
      KMainFunctions.downloadFile(
        blob,
        KMainFunctions.generateFilenameForDownloadFile(
          filename,
          KMainFunctions.getExtensionByMimeType(filename, mimeType)
        )
      );
      return;
    }

    if (typeof data === "string" && KMainFunctions.isRelativeUrl(data)) {
      const backendUrl: string = KuikaAppManager.GetBackendUrl();
      const absoluteUrl: string = data.startsWith("/") ? `${backendUrl}${data}` : `${backendUrl}/${data}`;
      const blob: Blob = await KMainFunctions.toBlob(absoluteUrl);
      KMainFunctions.downloadFile(
        blob,
        KMainFunctions.generateFilenameForDownloadFile(
          filename,
          KMainFunctions.getExtensionByMimeType(filename, blob.type)
        )
      );
      return;
    }

    if (typeof data === "object") {
      const blob: Blob = await KMainFunctions.toBlob(
        `${KMainFunctions.getBase64UrlPrefix(data.mimeType)}${data.content}`
      );
      KMainFunctions.downloadFile(
        blob,
        KMainFunctions.generateFilenameForDownloadFile(
          !!filename && filename !== "" ? filename : data.fileName,
          KMainFunctions.getExtensionByMimeType(!!filename && filename !== "" ? filename : data.fileName, blob.type)
        )
      );
      return;
    }

    this.notify(undefined, "Invalid file data.", "warning", "bottom-right", 3, null, null, null);
    return;
  }

  public static getLanguage(_languages: any, defaultLanguage: string): string {
    let retVal = "";
    const mlFromLocalStorage = localStorage.getItem("ml");
    if (!mlFromLocalStorage) {
      if (defaultLanguage) {
        localStorage.setItem("ml", defaultLanguage);
        retVal = defaultLanguage;
      }
    } else {
      retVal = mlFromLocalStorage;
    }
    return retVal;
  }

  public static toggleMenuCollapse(screen: any, stateName: string) {
    // KOA-17852: this used to write `setFieldsValue(!value)` — a boolean instead of a
    // fields object — so the ToggleMenuCollapse action never updated the form value.
    // Mirror toggleHamburgerMenuCollapse: flip `collapsed` inside the value object.
    const obj = {} as any;
    var tmp = Object.keys(screen.props.form.getFieldsValue()).find((v) => v.includes(stateName));
    var value = screen.props.form.getFieldValue(tmp);
    obj[tmp] = { ...value, collapsed: !value?.collapsed };
    screen.props.form.setFieldsValue(obj);
  }

  public static toggleHamburgerMenuCollapse(screen: any, stateName: string) {
    const obj = {} as any;
    var tmp = Object.keys(screen.props.form.getFieldsValue()).find((v) => v.includes(stateName));
    var value = screen.props.form.getFieldValue(tmp);
    obj[tmp] = { ...value, hamburgerCollapsed: !value.hamburgerCollapsed };
    screen.props.form.setFieldsValue(obj);
  }

  public static setLanguage(_screen: any, culture: string) {
    if (localStorage.getItem("ml") === culture) {
      return;
    }

    // Auth lives in the HttpOnly `access_token`/`refresh_token` cookies, not in
    // localStorage — the JS-readable `is_logged_in` cookie is the only login
    // signal the SPA can observe (same check as isLoggedIn/interceptors). A
    // stale `localStorage.getItem("refreshToken")` here was null for every
    // cookie-authenticated user, so Set Language never reached the server.
    const isAuthenticated: boolean = KuikaAppManager.readLoginStateCookie("is_logged_in") === "1";

    if (isAuthenticated) {
      LanguageService.SaveLanguage(culture).then((res) => {
        if (res && res.status === 200) {
          localStorage.setItem("ml", culture);
          window.location.reload();
        } else {
          console.error("Save language failed", {
            status: res?.status,
            statusText: res?.statusText,
            url: res?.config?.url
          });
          KMainFunctions.displayErrorNotification(
            localStorage.getItem("ml") === "tr_TR"
              ? "Dil değiştirilemedi. Lütfen tekrar deneyin."
              : "Language could not be changed. Please try again."
          );
        }
      });
    } else {
      // Not logged in (e.g. login/public screen): there is no user record to
      // sync to, so persist the choice client-side and reload for the UI.
      localStorage.setItem("ml", culture);
      window.location.reload();
    }
  }

  /**
   * SetMapProvider action: the end user's map provider ("GoogleMaps" | "Amap"). Stored on the device
   * and applied by reloading, because the Google Maps script is only loaded at page start. A no-op
   * (with a warning) when the project does not bundle both providers; an unknown or unbundled value
   * throws instead of silently keeping the current map.
   */
  public static setMapProvider(provider: string): void {
    const isChoiceEnabled: boolean = isEndUserMapProviderChoiceEnabled();
    if (!isChoiceEnabled) {
      console.warn("SetMapProvider ignored: end-user map provider choice is not enabled in this app's configuration.");
      return;
    }
    if (!isMapProvider(provider) || !isMapProviderAvailable(provider)) {
      throw new Error(`SetMapProvider: unknown or unavailable map provider "${provider}". Use "GoogleMaps" or "Amap".`);
    }
    const current: MapProvider = getEffectiveMapProvider();
    if (current === provider) return;

    storeMapProvider(provider);
    window.location.reload();
  }

  /** GetMapProvider action: the effective map provider (the user's choice, else the project default). */
  public static getMapProvider(): MapProvider {
    return getEffectiveMapProvider();
  }

  // getAvailableLanguages moved to BaseReactSystemFunctions (RNM-0161): its body is pure data shaping,
  // so the shared seam owns it and both targets offer the same list.

  /**
   * OpenInMap action: latitude, longitude, pinTitle, drawRoute, stops (the action metadata's five
   * parameters). Amap projects open uri.amap.com — GCJ-02, lng-first, `coordinate=gaode` — as the
   * Android runtime does; Google projects keep the google.com/maps link. Amap's navigation URI
   * takes origin + destination only, so intermediate stops are dropped there (documented).
   */
  public static openInMap(latitude: any, longitude: any, pinTitle?: any, drawRoute?: any, stops?: any): void {
    const point: IGeoPoint | null = toCoordinatePair(latitude, longitude);
    if (!point) return;

    const useAmap: boolean = isAmapProvider();
    if (!useAmap) {
      window.open(`https://www.google.com/maps/@${point.latitude},${point.longitude},12.00z`);
      return;
    }

    const gcj: IGeoPoint = wgs84ToGcj02(point.latitude, point.longitude);
    const name: string = encodeURIComponent(pinTitle === undefined || pinTitle === null ? "" : String(pinTitle));
    const shouldDrawRoute: boolean = drawRoute === true || String(drawRoute).toLowerCase() === "true";
    const common: string = "src=kuika&coordinate=gaode&callnative=1";

    if (shouldDrawRoute) {
      // Only the last stop can be honoured as the destination; Amap's navigation URI has no waypoints.
      const lastStop: IGeoPoint | null = this.lastStopCoordinate(stops);
      const target: IGeoPoint = lastStop ? wgs84ToGcj02(lastStop.latitude, lastStop.longitude) : gcj;
      window.open(
        `https://uri.amap.com/navigation?to=${target.longitude},${target.latitude},${name}&mode=car&policy=1&${common}`
      );
      return;
    }

    window.open(`https://uri.amap.com/marker?position=${gcj.longitude},${gcj.latitude}&name=${name}&${common}`);
  }

  /** The last parsable "lat,lng[,name]" entry of a "|"-separated stops string, or null. */
  private static lastStopCoordinate(stops: unknown): IGeoPoint | null {
    if (typeof stops !== "string" || stops.trim() === "") return null;
    const entries: string[] = stops.split("|").map((entry: string): string => entry.trim());
    for (let i = entries.length - 1; i >= 0; i--) {
      const parts: string[] = entries[i].split(",");
      const point: IGeoPoint | null = toCoordinatePair(parts[0], parts[1]);
      if (point) return point;
    }
    return null;
  }

  public static phoneNumberCall(number: any) {
    window.open(`tel:${number}`);
  }

  public static mailTo(receivers: string, cc?: string, bcc?: string, subject?: string, body?: string) {
    if (!receivers) return;
    let divider = "?";

    let mailToURL = `mailto:${receivers}`;

    if (cc) {
      mailToURL += `${divider}cc=${cc}`;
      divider = "&";
    }

    if (bcc) {
      mailToURL += `${divider}bcc=${bcc}`;
      divider = "&";
    }

    if (subject) {
      mailToURL += `${divider}subject=${subject}`;
      divider = "&";
    }

    if (body) {
      mailToURL += `${divider}body=${body}`;
      divider = "&";
    }

    window.open(mailToURL);
  }
  // validatePhoneNumber: _validatePhoneNumber,
  // validateEmail: _validateEmail,

  // toLocaleString: _toLocaleString,
  // trimRight: _trimRight,
  // toTitleCase: _toTitleCase,
  // substring: _substring,
  // concatenate: _concatenate,

  // registerPopup: _registerPopup,
  // deregisterPopup: _deregisterPopup,

  // attachFile: _attachFile,
  // attachFileUrl: _attachFileUrl,
  // downloadFile: _downloadFile,
  // downloadFileUrl: _downloadFileUrl,

  // scanBarcodeKuikaFunction: _scanBarcodeKuikaFunction,

  // searchOnClientSide: _searchOnClientSide,
  // kuikaSearchOnClientSide: _kuikaSearchOnClientSide,

  // getFromLangPack: _getFromLangPack,
  // setLanguage: _setLanguage,
  // getLanguage: _getLanguage,
  // getAvailableLanguages: _getAvailableLanguages,
  // translate: _translate,
  // translateToStringArray: _translateToStringArray,

  // isNotEmpty: _isNotEmpty,
  // getColorForTableRow: _getColorForTableRow,
  // increment: _increment,
  // and: _and,
  // or: _or,
  // not: _not,

  // base64ToBlob: _base64ToBlob,
  // downloadFile: _downloadFile,
  // authGoogleExternalLogin: _authGoogleExternalLogin,
  public static goToFullScreen(): void {
    const elem: any = document.getElementsByTagName("html")[0];

    const urlParams = new URLSearchParams(window.location.search);
    const redirectOnMobileValue = urlParams.get("redirectOnMobile");

    if (redirectOnMobileValue === "true") {
      this.postWebKitMessage(null, {
        actionType: "GO_TO_FULL_SCREEN"
      });
    } else if (elem.requestFullscreen) {
      elem.requestFullscreen();
    } else if (elem.webkitRequestFullscreen) {
      /* Safari */
      elem.webkitRequestFullscreen();
    } else if (elem.msRequestFullscreen) {
      /* IE11 */
      elem.msRequestFullscreen();
    }
  }

  public static getLocale(): any {
    let mlKey = localStorage.getItem("ml");

    if (!mlKey) {
      mlKey = "en_US";
    }

    switch (mlKey) {
      case "hy_AM":
        return hy_AM;

      case "az_AZ":
        return az_AZ;

      case "bg_BG":
        return bg_BG;

      case "ca_ES":
        return ca_ES;

      case "hr_HR":
        return hr_HR;

      case "cs_CZ":
        return cs_CZ;

      case "da_DK":
        return da_DK;

      case "nl_NL":
        return nl_NL;

      case "en_US":
        return en_US;

      case "en_GB":
        return en_GB;

      case "et_EE":
        return et_EE;

      case "fi_FI":
        return fi_FI;

      case "fr_FR":
        return fr_FR;

      case "ka_GE":
        return ka_GE;

      case "de_DE":
        return de_DE;

      case "el_GR":
        return el_GR;

      case "hu_HU":
        return hu_HU;

      case "is_IS":
        return is_IS;

      case "it_IT":
        return it_IT;

      case "kk_KZ":
        return kk_KZ;

      case "lv_LV":
        return lv_LV;

      case "lt_LT":
        return lt_LT;

      case "mk_MK":
        return mk_MK;

      case "nb_NO":
        return nb_NO;

      case "pl_PL":
        return pl_PL;

      case "pt_PT":
        return pt_PT;

      case "ro_RO":
        return ro_RO;

      case "ru_RU":
        return ru_RU;

      case "sr_RS":
        return sr_RS;

      case "sk_SK":
        return sk_SK;

      case "sl_SI":
        return sl_SI;

      case "es_ES":
        return es_ES;

      case "sv_SE":
        return sv_SE;

      case "tr_TR":
        return tr_TR;

      case "uk_UA":
        return uk_UA;

      default:
        return en_US;
    }
  }

  // updateUserName / updateUserStartingScreen moved to BaseReactSystemFunctions (RNM-0109).

  public static async componentToPDF(targetComponent: string, quality: string, orientation: string, format?: string) {
    // Image output (PNG/JPEG): capture the component as a raster base64 (e.g. to feed a Report Designer
    // image parameter). Only the output format differs from the PDF path below — the capture itself
    // must stay identical, so it goes through the same clone repairs and the same canvas-limit guard
    // (react-to-pdf forwards these straight to html2canvas, which awaits an async `onclone`).
    // Default stays "pdf" so existing usages are unchanged.
    const normalizedFormat: string = (format ?? "pdf").toLowerCase();
    if (normalizedFormat === "png" || normalizedFormat === "jpeg" || normalizedFormat === "jpg") {
      const targetElement: HTMLElement | null = document.getElementById(targetComponent);
      if (!targetElement) return null;
      const html2canvas = (await import("html2canvas")).default;
      const ResolutionForImage = (await import("react-to-pdf")).Resolution;
      try {
        const imageCanvas: HTMLCanvasElement = await html2canvas(targetElement, {
          useCORS: true,
          logging: false,
          scale: resolveSafeCaptureScale(targetElement, ResolutionForImage[quality]),
          onclone: preparePdfCaptureClone
        });
        const mimeType: string = normalizedFormat === "png" ? "image/png" : "image/jpeg";
        return imageCanvas.toDataURL(mimeType, 0.92);
      } catch (error: unknown) {
        // Same reason as the PDF path: rejecting would skip the action chain's hideSpinner.
        ReactSystemFunctions.reportPdfCaptureFailure(error);
        return undefined;
      }
    }

    const generatePDF = (await import("react-to-pdf")).default;
    const Resolution = (await import("react-to-pdf")).Resolution;

    const getTargetElement = () => document.getElementById(targetComponent);
    const options: any = {
      method: "build",
      resolution: resolveSafeCaptureScale(getTargetElement(), Resolution[quality]),
      overrides: {
        pdf: {
          compress: true
        },
        canvas: {
          useCORS: true,
          onclone: preparePdfCaptureClone
        }
      },
      page: {
        orientation: orientation ?? "portrait"
      }
    };
    try {
      var a = await generatePDF(getTargetElement, options);
      var blobValue = a.output("blob");
      return await new Promise((resolve, _) => {
        const reader = new FileReader();
        reader.onloadend = () => resolve(reader.result);
        reader.readAsDataURL(blobValue);
      });
    } catch (error: unknown) {
      // Never reject: the generated action chain has no try/catch, so a rejection skips
      // its KuikaAppManager.hideSpinner(this) and leaves the user on a spinner forever
      // with no message at all (KOA-18461).
      ReactSystemFunctions.reportPdfCaptureFailure(error);
      return undefined;
    }
  }

  private static reportPdfCaptureFailure(error: unknown): void {
    console.error("Component to PDF failed", error);
    KMainFunctions.displayErrorNotification(
      localStorage.getItem("ml") === "tr_TR"
        ? "PDF oluşturulamadı. Ekran çok büyük olabilir; daha düşük bir kalite seçip tekrar deneyin."
        : "The PDF could not be created. The screen may be too large; try again with a lower quality."
    );
  }

  public static async componentToPDFSave(
    targetComponent: string,
    filename: string,
    quality: string,
    orientation: string
  ) {
    const generatePDF = (await import("react-to-pdf")).default;
    const Resolution = (await import("react-to-pdf")).Resolution;

    const urlParams = new URLSearchParams(window.location.search);
    const redirectOnMobileValue = urlParams.get("redirectOnMobile");

    let file = filename;
    if (!file.endsWith(".pdf")) {
      file = `${file}.pdf`;
    }

    const getTargetElement = () => document.getElementById(targetComponent);
    const options: any = {
      filename: file,
      method: "save",
      resolution: resolveSafeCaptureScale(getTargetElement(), Resolution[quality]),
      overrides: {
        pdf: {
          compress: true
        },
        canvas: {
          useCORS: true,
          onclone: preparePdfCaptureClone
        }
      },
      page: {
        orientation: orientation ?? "portrait"
      }
    };
    try {
      const result = await generatePDF(getTargetElement, options);
      if (redirectOnMobileValue && redirectOnMobileValue === "true") {
        const blob = result.output("blob");
        const base64 = await KMainFunctions.convertBlobToBase64(blob);
        this.postWebKitMessage(null, {
          actionType: "DOWNLOAD_BLOB",
          filename: `${file}`,
          base64Str: `${base64}`,
          mimeType: `${blob.type}`
        });
      }
    } catch (error: unknown) {
      // See componentToPDF: resolving instead of rejecting is what lets the generated
      // action chain reach its own hideSpinner.
      ReactSystemFunctions.reportPdfCaptureFailure(error);
    }
  }

  public static scrollTo(elemenetId: string) {
    if (!elemenetId) return;
    const element = window.document.getElementById(elemenetId);
    if (!element) return;
    element.scrollIntoView({ behavior: "smooth" });
  }

  public static setFocusTo(elementId: string) {
    if (!elementId) return;
    const element = window.document.getElementById(elementId);
    const element2: HTMLElement = window.document.querySelector(`[focusId="${elementId}"]`);
    if (!element && !element2) return;
    setTimeout(() => {
      // Use preventScroll to avoid browser auto-scrolling to the focused element,
      // which causes unwanted scroll-to-top in MFE (microapp) context (EMR-1).
      element?.focus({ preventScroll: true });
      element2?.focus({ preventScroll: true });
    }, 0);
  }

  public static openPdf(data: string, warnLandscape: boolean, openAs: "newTab" | "currentPage"): void {
    if (KMainFunctions.isBase64(data) || data.startsWith("data:application/pdf;base64")) {
      KMainFunctions.openBase64Pdf(data, warnLandscape, openAs);
      return;
    }

    if (KMainFunctions.isValidUrl(data)) {
      KMainFunctions.openUrlPdf(data, openAs);
      return;
    }

    const urlParams = new URLSearchParams(window.location.search);
    const redirectOnMobileValue = urlParams.get("redirectOnMobile");

    if (redirectOnMobileValue === "true") {
      this.postWebKitMessage(null, {
        actionType: "GET_REPORT",
        link: `${data}`,
        warnLandscape: `${warnLandscape}`,
        openAs: `${openAs}`
      });
      return;
    }

    this.notify(undefined, "Invalid pdf data.", "warning", "bottom-right", 3, null, null, null);
    return;
  }

  public static async share(data: string): Promise<void> {
    try {
      if (!navigator.share || !data) return;

      let text: string | undefined;
      let files: File[];

      if (
        (data.toLowerCase().startsWith("http://") || data.toLowerCase().startsWith("https://")) &&
        data.indexOf(" ") < 0
      ) {
        if (data.toLowerCase().endsWith(".pdf")) {
          const blob: Blob = await KMainFunctions.toBlob(data);
          files = [new File([blob], `${Guid.create().toString()}.${blob.type.split("/")[1]}`, { type: blob.type })];
        } else {
          text = data;
        }
      } else if (data.startsWith("BEGIN:VCARD") || data.startsWith("VCARD")) {
        const vcfBlob = new Blob([data], { type: "text/vcard" });
        const vcfFile = new File([vcfBlob], "Share.vcf", {
          type: "text/vcard"
        });
        try {
          await navigator.share({ files: [vcfFile] });
        } catch {
          const url = URL.createObjectURL(vcfBlob);
          const a = document.createElement("a");
          a.href = url;
          a.download = "Share.vcf";
          document.body.appendChild(a);
          a.click();
          document.body.removeChild(a);
          URL.revokeObjectURL(url);
        }
        return;
      } else if (data.includes(";base64,")) {
        const blob: Blob = await KMainFunctions.toBlob(data);
        const mimeType = data.split(";base64,")[0].replace("data:", "");
        const ext = mimeType.split("/")[1] || "txt";
        const fileName = `${Guid.create().toString()}.${ext}`;
        files = [new File([blob], fileName, { type: mimeType })];
      } else {
        text = data;
      }
      const shareData: ShareData = {};
      if (text) shareData.text = text;
      if (files?.length) shareData.files = files;
      await navigator.share(shareData);
    } catch (e) {
      KMainFunctions.exceptionHandler(e);
    }
  }

  public static selectLanguage(): string {
    return "";
  }

  public static getVersionInfo(): string {
    return "1.0.0";
  }

  public static getMyNotifications(_username: any, _no: any, _no2: any, _no3: any) {
    console.log("TODO: SYSTEM FUNCTION NOT IMPLEMENTED YET: getMyNotifications");
  }

  public static markAsReadNotification(_username: any, _notificationId: any) {
    console.log("TODO: SYSTEM FUNCTION NOT IMPLEMENTED YET: markAsReadNotification");
  }

  public static async sendPushNotificationToUsername(
    username: string,
    title: string,
    message: string,
    extraData: any
  ): Promise<void> {
    NotificationService.SendPushNotificationToUsername({
      username,
      title,
      message,
      extraData
    });
  }

  public static SendPushNotification(p1, p2, p3) {}

  public static async isLoggedIn() {
    if (KuikaAppManager.readLoginStateCookie("is_logged_in") === "1") {
      const result = await UserService.ValidateToken();
      return KMainFunctions.IsResStatus2XX(result);
    }
    return false;
  }

  // STRIPE ACTIONS START
  public static async stripePayment(amount: string, currency: string, description: string): Promise<IStripePayment> {
    const stripePaymentDto = {
      amount,
      currency,
      description
    } as IStripePaymentDto;
    const res = await StripeService.OneTimePayment(stripePaymentDto);
    if (res.status === 200) {
      return res.data;
    }
    return {} as IStripePayment;
  }

  public static async getPaymentReceiptBase64(paymentIntent: string): Promise<string> {
    const dto = {
      paymentIntent
    } as IStripeCaptureDto;
    const res = await StripeService.GetPaymentReceiptBase64(dto);
    if (res.status === 200) {
      return res.data;
    }
    return {} as any;
  }

  public static async openStripePaymentDrawer(
    screen: any,
    cllbck: any,
    amount: string,
    currency: string,
    description: string,
    applicationFee: string,
    destination: string,
    captureMethod: string,
    paymentType: string,
    supportedPaymentTypes?: string
  ): Promise<any> {
    const stripePaymentDto = {
      amount,
      currency,
      description,
      applicationFeeAmount: applicationFee,
      ConnectedAccount: destination,
      captureMethod,
      supportedPaymentTypes
    } as IStripePaymentDto;
    const endPoint =
      paymentType === "single" ? StripeService.OneTimePayment : StripeService.OneTimePaymentWithDestination;
    const res = await endPoint(stripePaymentDto);
    if (res.status === 200) {
      const response = {};
      screen?.props.showStripeDrawer(res.data, cllbck, screen, false);
      return res.data;
    }
    return "";
  }

  public static async setupIntent(screen: any, cllbck: any, supportedPaymentTypes: string): Promise<any> {
    const stripePaymentDto = {
      supportedPaymentTypes
    } as any;
    const res = await StripeService.SetupIntent(stripePaymentDto);
    if (res.status === 200) {
      const response = {};
      screen?.props.showStripeDrawer(res.data, cllbck, screen, true);
      return res.data;
    }
    return "";
  }

  public static async getConnectedAccountBalance(connectedAccount: string): Promise<any> {
    const stripePaymentDto = {
      connectedAccount
    } as IStripeConnectedAccountDto;
    const res = await StripeService.GetConnectedAccountBalance(stripePaymentDto);
    if (res.status === 200) {
      return res.data;
    }
    return undefined;
  }

  // getConnectedAccountOnboardingLink moved to BaseReactSystemFunctions (RNM-0136). The return location it sends
  // Stripe is now the `clientOrigin` platform hook, overridden below — that address was the only web-specific
  // thing about the body, and the reason the action stayed a documented React Native gap until now.

  /**
   * Platform hook: web's return address is the deployed frontend's own origin, which is what this body always
   * sent. React Native answers with a deep link instead.
   */
  protected static clientOrigin(): string {
    return KMainFunctions.windowLocationOrigin;
  }

  public static async printPDFQZ(
    printerName: string,
    pdfBase64: string,
    pageW: number,
    pageH: number,
    totalHeight: number,
    stickyPaper: boolean,
    onePage: boolean,
    pdfList: any,
    key: string
  ): Promise<boolean> {
    const qz = (await import("qz-tray")).default;
    const { KEYUTIL, KJUR, stob64, hextorstr } = await import("jsrsasign");

    const privateKey = key;

    qz.security.setSignatureAlgorithm("SHA512"); // Since 2.1
    qz.security.setSignaturePromise((toSign: any) => {
      return function (resolve: (arg0: any) => void, reject: (arg0: any) => void) {
        try {
          const pk = KEYUTIL.getKey(privateKey);
          const sig = new KJUR.crypto.Signature({ alg: "SHA512withRSA" }); // Use "SHA1withRSA" for QZ Tray 2.0 and older
          sig.init(pk);
          sig.updateString(toSign);
          const hex = sig.sign();
          resolve(stob64(hextorstr(hex)));
        } catch (err) {
          console.error(err);
          reject(err);
        }
      };
    });

    try {
      const config = qz.configs.create(printerName);
      config.config = {
        orientation: "portrait",
        size: {
          width: pageW,
          height: pageH
        },
        units: "in"
      };

      if (totalHeight == 0) totalHeight = pageH;

      qz.security.setCertificatePromise((resolve: (arg0: string) => void, _reject: any) => {
        resolve(`-----BEGIN CERTIFICATE-----
          MIID4TCCAsmgAwIBAgIUTix9J/qAFmdZj1DlZ32r5UCBQzgwDQYJKoZIhvcNAQEL
          BQAwfzELMAkGA1UEBhMCVFIxCzAJBgNVBAgMAlRSMQswCQYDVQQHDAJUUjEOMAwG
          A1UECgwFSURBVEExDjAMBgNVBAsMBUlEQVRBMRcwFQYDVQQDDA4qLmlkYXRhLmNv
          bS50cjEdMBsGCSqGSIb3DQEJARYOKi5pZGF0YS5jb20udHIwIBcNMjIwNDIwMTQ0
          MDQwWhgPMjA1MzEwMTMxNDQwNDBaMH8xCzAJBgNVBAYTAlRSMQswCQYDVQQIDAJU
          UjELMAkGA1UEBwwCVFIxDjAMBgNVBAoMBUlEQVRBMQ4wDAYDVQQLDAVJREFUQTEX
          MBUGA1UEAwwOKi5pZGF0YS5jb20udHIxHTAbBgkqhkiG9w0BCQEWDiouaWRhdGEu
          Y29tLnRyMIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEA7ksdRHbjfxrB
          tVaskaDR5Zx3JGxsmE5cpbcwRZ0s8H3VkyxKlfSER9tMJs/CGlTtOsmCPgVW5uW9
          qkXOGB0LMFCkM2qfW22hq5eLFunWDicAgkc4rvIgTHbtMR+aM4hxQh4F04OaN5gy
          xFwDAwpKDJ6p43qX/TLzPaM7TUEX7SjYdA38oKjK3SFHzUDrvIKkieySmF12lyGJ
          UMrndN9scgH1DpD6uBHHqwUi7bUMRw2vaFGAXrkaBytfIlB/rzgsPIA0Ir0SfcON
          hK3oOXJe68pIY00AJkbmzp7SgjxGU/lpVhJI/wMRqHjXJ7106avX5h/IqDkfEtjG
          QI004UqriwIDAQABo1MwUTAdBgNVHQ4EFgQU9+kYlFmzC7HX7RGKDZ3KJJj4l8Yw
          HwYDVR0jBBgwFoAU9+kYlFmzC7HX7RGKDZ3KJJj4l8YwDwYDVR0TAQH/BAUwAwEB
          /zANBgkqhkiG9w0BAQsFAAOCAQEAQbRjJC6k5ZFYOgHTAhBsrwsvZ6ukbzEHbBhC
          rbE7NzTYS2QhYMbYM6O0e0jJ57dnEk03V4fXuaKLRVfKAqwFNEZgydwOZ7rZXi6O
          6Pi2IIxN7LHYtYrZwnANaWfUvwbULa439Fh1L5mVbKNpI0qLoC8JSO1gn+7BFv0v
          4AkgeFoEXa2IqlpupGIHFKPNA3M3RGNNFrysDDDKwV+cc2oAmXnxsEPI59sF4D1C
          l71cSa0tP2ZrHiv6PqgYQRSp4Tx2NlohkAmR/cZYmHjWb+jPYb/uVSNQP3ytoo+7
          XO7lMjGj++rQ+cqglSQrz6Tga4XFqseviYcWz11N8r5r6n7qww==
          -----END CERTIFICATE-----
          `);
      });

      if (onePage) {
        qz.websocket.connect().then(() => {
          const base64string = pdfBase64.split(",")[1];
          var printData: any = [];
          printData = pdfBase64.startsWith("^XA")
            ? [pdfBase64]
            : [
                "^XA\n",
                `^MN${stickyPaper ? "Y" : "N"}\n`,
                `^LL${totalHeight * 203.2}\n`,
                {
                  type: "pdf",
                  format: "base64",
                  data: base64string,
                  options: {
                    language: "ZPL",
                    pageHeight: totalHeight * 203.2,
                    pageWidth: pageW * 203.2
                  }
                },
                "^XZ\n"
              ];
          qz.print(config, printData)
            .catch()
            .then(() => {
              qz.websocket.disconnect();
            });
        });
      } else {
        qz.websocket.connect().then(() => {
          pdfList = pdfBase64.split("#####");
          for (const item of pdfList) {
            const base64string = item.split(",")[1];
            var printData: any = [];
            printData = item.startsWith("^XA")
              ? [item]
              : [
                  "^XA\n",
                  `^MN${stickyPaper ? "Y" : "N"}\n`,
                  `^LL${totalHeight * 203.2}\n`,
                  {
                    type: "pdf",
                    format: "base64",
                    data: base64string,
                    options: {
                      language: "ZPL",
                      pageHeight: totalHeight * 203.2,
                      pageWidth: pageW * 203.2
                    }
                  },
                  "^XZ\n"
                ];
            qz.print(config, printData)
              .catch()
              .then(() => {
                qz.websocket.disconnect();
              });
          }
        });
      }
      return true;
    } catch {
      return false;
    }
  }

  public static async generateQrCode(value: any) {
    try {
      const QRCode = (await import("qrcode")).default;
      const qr = await QRCode.toDataURL(value, { errorCorrectionLevel: "H" });
      return qr;
    } catch (err) {
      console.error(err);
      return "";
    }
  }

  public static updateUserRoles(roles: any) {
    if (window.userInfo) {
      window.userInfo.roles = roles;
    }
  }

  public static async generateVcf(
    name: string,
    surname: string,
    email: string,
    mobile: string,
    workPhone: string,
    homePhone: string,
    _gender: string,
    photo: string,
    nickname: string,
    note: string,
    organization: string,
    role: string,
    title: string,
    url: string,
    workUrl: string,
    homeUrl: string
  ): Promise<string> {
    const VCard = (await import("vcard-creator")).default;
    const vCard = new VCard();
    vCard.addName(surname, name);

    if (!_.isEmpty(email)) {
      vCard.addEmail(email);
    }

    if (!_.isEmpty(mobile)) {
      vCard.addPhoneNumber(mobile, "CELL");
    }

    if (!_.isEmpty(workPhone)) {
      vCard.addPhoneNumber(workPhone, "WORK");
    }

    if (!_.isEmpty(homePhone)) {
      vCard.addPhoneNumber(homePhone, "HOME");
    }

    if (!_.isEmpty(photo)) {
      vCard.addPhoto(photo);
    }

    if (!_.isEmpty(nickname)) {
      vCard.addNickname(nickname);
    }

    if (!_.isEmpty(note)) {
      vCard.addNote(note);
    }

    if (!_.isEmpty(organization)) {
      vCard.addCompany(organization);
    }

    if (!_.isEmpty(role)) {
      vCard.addRole(role);
    }

    if (!_.isEmpty(title)) {
      vCard.addJobtitle(title);
    }

    if (!_.isEmpty(url)) {
      vCard.addURL(url);
    }

    if (!_.isEmpty(workUrl)) {
      vCard.addURL(workUrl, "WORK");
    }

    if (!_.isEmpty(homeUrl)) {
      vCard.addURL(homeUrl, "HOME");
    }

    return vCard.toString();
  }

  public static async downloadVcf(
    name: string,
    surname: string,
    email: string,
    mobile: string,
    workPhone: string,
    homePhone: string,
    gender: string,
    photo: string,
    nickname: string,
    note: string,
    organization: string,
    role: string,
    title: string,
    url: string,
    workUrl: string,
    homeUrl: string
  ): Promise<void> {
    const vcfString = await this.generateVcf(
      name,
      surname,
      email,
      mobile,
      workPhone,
      homePhone,
      gender,
      photo,
      nickname,
      note,
      organization,
      role,
      title,
      url,
      workUrl,
      homeUrl
    );

    const blob = new Blob([vcfString], {
      type: "text/vcard"
    });

    const objectUrl = window.URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = objectUrl;
    a.download = `${name}_${surname}.vcf`;
    a.click();
  }

  public static isWeb(): boolean {
    return true;
  }

  public static isIOS(): boolean {
    return false;
  }

  public static isAndroid(): boolean {
    return false;
  }

  // Backend-reachability gate. `navigator.onLine` alone is unreliable —
  // Chrome's DevTools "Network → Offline" preset blocks traffic at the network
  // layer without flipping the API to false, and conversely the OS may report
  // online while the backend / DNS / captive portal is unreachable. So we
  // combine the OS hint with observed Axios traffic: a recent ERR_NETWORK
  // counts as offline until a subsequent successful response.
  //
  // Note for the SW interaction: assets served from the Workbox runtime cache
  // do NOT count as "online" signals. `markNetworkSuccess`/`markNetworkError`
  // are only called from the Axios interceptors, and `/v1/api/*` is in the
  // SW's NETWORK_ONLY list — so these markers reflect actual backend reach.
  private static observedNetworkErrorAt: number = 0;
  private static observedNetworkSuccessAt: number = 0;
  private static readonly OFFLINE_AFTER_ERROR_MS: number = 30_000;
  private static onlineEventsBound: boolean = false;

  private static bindOnlineEvents(): void {
    if (ReactSystemFunctions.onlineEventsBound || typeof window === "undefined") return;
    window.addEventListener("online", () => {
      ReactSystemFunctions.observedNetworkErrorAt = 0;
    });
    window.addEventListener("offline", () => {
      ReactSystemFunctions.observedNetworkErrorAt = Date.now();
    });
    ReactSystemFunctions.onlineEventsBound = true;
  }

  public static async isOnline(): Promise<boolean> {
    ReactSystemFunctions.bindOnlineEvents();
    if (typeof navigator !== "undefined" && !navigator.onLine) {
      return false;
    }
    const errAt: number = ReactSystemFunctions.observedNetworkErrorAt;
    const okAt: number = ReactSystemFunctions.observedNetworkSuccessAt;
    if (errAt > okAt && Date.now() - errAt < ReactSystemFunctions.OFFLINE_AFTER_ERROR_MS) {
      return false;
    }
    return true;
  }

  public static markNetworkSuccess(): void {
    ReactSystemFunctions.observedNetworkSuccessAt = Date.now();
  }

  public static markNetworkError(): void {
    ReactSystemFunctions.observedNetworkErrorAt = Date.now();
  }

  /**
   * Fetch fresh offline database from server.
   * Same as mobile: KtSystemFunctions.fetchOfflineDb() / SwiftSystemFunctions.fetchOfflineDb()
   *
   * Mobile flow:
   * 1. Check unsent records → if any, show warning and return null
   * 2. Call API to fetch database
   * 3. Import database to local storage (KPersister.SaveFile)
   * 4. Return base64 content
   */
  public static async fetchOfflineDb(): Promise<string | null> {
    const syncService = OfflineSyncService.getInstance();
    const wasmService = KuikaCoreWasmBridgeService.getInstance();
    const persistenceService = OfflineDbPersistenceService.getInstance();

    // A fetch replaces the entire local DB, so warn only when there is something to lose:
    // actual unsent local changes. Mirror mobile (KPersister.IsUnsentRecordsAvailable) and the
    // dirty-aware Db_GetPendingChanges — a row is pending only if it is in the dirty table, not
    // merely because it was seeded SentFromMobile = 0 by a previous fetch. Without this gate the
    // confirm fired on every fetch (even right after a push, when nothing is pending) — the
    // "push first" false positive. A first-time fetch has no local DB and nothing to lose.
    // On the durable (OPFS/native) path the DB lives in the file, not IndexedDB — check the engine.
    await wasmService.initialize();
    const hasLocalDb: boolean = wasmService.hasDurablePersistence()
      ? await wasmService.Db_IsInitialized()
      : await persistenceService.hasPersistedDatabase();
    if (hasLocalDb) {
      const hasPendingChanges: boolean = await syncService.hasPendingChanges();
      if (hasPendingChanges) {
        const proceed: boolean = window.confirm(translationService.translate("offline_db.fetch_unsynced_confirm"));
        if (!proceed) {
          return null;
        }
      }
    }

    const loadingId = this.showLoadingNotification(translationService.translate("offline_db.downloading"));

    try {
      // fetchAndImport picks the memory-optimal path: on the browser OPFS path it STREAMS the
      // download straight into the OPFS file (no full-DB buffer → multi-GB capable); otherwise it
      // does the binary byte import.
      const imported = await syncService.fetchAndImport();
      if (imported) {
        // Durable store (OPFS / native) already persisted the DB. Only the IndexedDB fallback
        // (:memory:) needs a whole-DB base64 mirror (which would OOM on large DBs).
        let returnValue = "offline-db-ready";
        if (!wasmService.hasDurablePersistence()) {
          const exported = await wasmService.Db_ExportDatabaseBase64();
          await persistenceService.saveDatabase(exported);
          returnValue = exported;
        }

        this.removeNotification(loadingId);
        this.showResultNotification(translationService.translate("offline_db.download_success"), "success");
        return returnValue;
      }

      this.removeNotification(loadingId);
      this.showResultNotification(translationService.translate("offline_db.download_error"), "danger");
      return null;
    } catch (error) {
      console.error("fetchOfflineDb failed:", error);
      this.removeNotification(loadingId);
      this.showResultNotification(translationService.translate("offline_db.download_error"), "danger");
      return null;
    }
  }

  /**
   * Push local changes to server.
   * Same as mobile: KtSystemFunctions.pushOfflineDb() / SwiftSystemFunctions.pushOfflineDb()
   *
   * Mobile flow:
   * 1. Export unsent records database (GetUnsentRecordsDbBase64)
   * 2. Call API to push database
   * 3. Mark all records as synced (SetSentFromMobileToSent)
   * 4. Return true
   */
  public static async pushOfflineDb(): Promise<boolean> {
    if (!navigator.onLine) {
      this.showResultNotification(translationService.translate("offline_db.push_offline_warning"), "warning");
      return false;
    }

    const syncService = OfflineSyncService.getInstance();
    const wasmService = KuikaCoreWasmBridgeService.getInstance();

    const loadingId = this.showLoadingNotification(translationService.translate("offline_db.uploading"));

    try {
      const result = await syncService.pushChanges();

      if (result.success && result.payload) {
        // CRITICAL: mark synced ONLY the rows that were in the pushed
        // payload. A criteria-based re-scan would also mark rows the user
        // added between export and this call (the push network window) —
        // those would never be sent and silently lost on the next fetch.
        // The exact pushed bytes are returned by pushChanges so the mark
        // and the transmission can never diverge.
        await wasmService.Db_MarkPayloadAsSynced(result.payload);

        this.removeNotification(loadingId);
        this.showResultNotification(translationService.translate("offline_db.upload_success"), "success");
        return true;
      }

      this.removeNotification(loadingId);
      this.showResultNotification(translationService.translate("offline_db.upload_error"), "danger");
      return false;
    } catch (error) {
      console.error("pushOfflineDb failed:", error);
      this.removeNotification(loadingId);
      this.showResultNotification(translationService.translate("offline_db.upload_error"), "danger");
      return false;
    }
  }

  /**
   * Delete local offline database.
   * Same as mobile: KtSystemFunctions.deleteOfflineDb() / SwiftSystemFunctions.deleteOfflineDb()
   */
  public static async deleteOfflineDb(): Promise<boolean> {
    const loadingId = this.showLoadingNotification(translationService.translate("offline_db.deleting"));

    try {
      const syncService = OfflineSyncService.getInstance();
      await syncService.deleteOfflineDatabase();

      this.removeNotification(loadingId);
      this.showResultNotification(translationService.translate("offline_db.delete_success"), "success");
      return true;
    } catch (error) {
      console.error("deleteOfflineDb failed:", error);
      this.removeNotification(loadingId);
      this.showResultNotification(translationService.translate("offline_db.delete_error"), "danger");
      return false;
    }
  }

  private static showLoadingNotification(message: string): string {
    return Store.addNotification({
      message,
      type: "default",
      container: "bottom-right",
      animationIn: ["animated", "fadeIn"],
      animationOut: ["animated", "fadeOut"],
      dismiss: { duration: 0 }
    });
  }

  private static removeNotification(id: string): void {
    if (id) Store.removeNotification(id);
  }

  private static showResultNotification(message: string, type: "success" | "danger" | "warning"): void {
    Store.addNotification({
      message,
      type,
      container: "bottom-right",
      animationIn: ["animated", "fadeIn"],
      animationOut: ["animated", "fadeOut"],
      dismiss: { duration: 3000, pauseOnHover: true, showIcon: true }
    });
  }

  // ARITHMETIC

  // public static concatenate(
  //   arrayOrString1: string | any[] | null | undefined,
  //   arrayOrString2: string | any[] | null | undefined
  // ): any {
  //   const isArr1 = Array.isArray(arrayOrString1);
  //   const isArr2 = Array.isArray(arrayOrString2);

  //   if (isArr1 || isArr2) {
  //     const result: any[] = [];

  //     if (isArr1) result.push(...(arrayOrString1 as any[]));
  //     else if (arrayOrString1 != null) result.push(arrayOrString1);

  //     if (isArr2) result.push(...(arrayOrString2 as any[]));
  //     else if (arrayOrString2 != null) result.push(arrayOrString2);

  //     return result.map((x) => x?.toString?.() ?? "").join("");
  //   }

  //   const s1 = arrayOrString1?.toString() ?? "";
  //   const s2 = arrayOrString2?.toString() ?? "";
  //   return s1 + s2;
  // }

  public static async iyzicoInitializeCheckoutForm(
    screen: any,
    cllbck: any,
    userName: string,
    pricingPlanReferenceCode: string,
    phoneNumber: string,
    identityNumber: string,
    address: string,
    city: string,
    country: string,
    zipCode: string
  ) {
    const ad = {
      address1: address,
      address2: "",
      city,
      country,
      zipCode
    } as IIyzicoAddressDto;
    const u = {
      userName,
      pricingPlanReferenceCode,
      address: ad,
      phoneNumber,
      identityNumber
    } as IIyzicoCheckoutFormDto;
    await IyzicoService.CheckoutForm(u)
      .then((response) => {
        if (response && response.data && response.data.checkoutFormContent) {
          screen?.props.showIyzicoDrawer({ data: response.data }, cllbck, screen);
        } else {
          KuikaAppManager.hideSpinner(screen);
        }
      })
      .catch(() => {
        KuikaAppManager.hideSpinner(screen);
      });
  }

  public static generateLink(screenName?: string, parameters?: { [key: string]: any }) {
    let linkString = window.location.href;

    if (screenName) {
      let lastIndex = linkString.lastIndexOf("/");
      if (lastIndex !== -1) {
        linkString = linkString.substring(0, lastIndex);
        linkString += `/${screenName}`;
      }
    }

    if (Object.keys(parameters).length > 0) {
      linkString += "?";
    }

    let index: number = 0;
    for (const [key, value] of Object.entries(parameters)) {
      const escapedString: string = encodeURIComponent(String(value));
      linkString += `${key}=${escapedString}`;
      if (index < Object.keys(parameters).length - 1) {
        linkString += "&";
      }
      index += 1;
    }

    return linkString;
  }

  public static runUIVisionMacro(stringifiedMacro: string) {
    try {
      const json = JSON.parse(stringifiedMacro);

      const isExtensionLoaded = function () {
        const $root = document.documentElement;
        return !!$root && !!$root.getAttribute("data-kantu");
      };
      const openExternal = function (url) {
        const $el = document.createElement("a");
        $el.setAttribute("target", "_blank");
        $el.setAttribute("href", url);
        $el.style.position = "absolute";
        $el.style.top = "-9999px";
        $el.style.left = "-9999px";
        document.body.appendChild($el);
        $el.click();
        setTimeout(() => {
          $el.remove();
        }, 200);
      };
      const openWebsite = function () {
        openExternal("https://ui.vision/rpa/home/getrpa");
      };
      if (!isExtensionLoaded()) {
        if (confirm("UI.Vision RPA is not installed yet. Do you want to download it now?")) {
          return openWebsite();
        }
      } else {
        return window.dispatchEvent(
          new CustomEvent("kantuSaveAndRunMacro", {
            detail: {
              direct: 1,
              closeRpa: 1,
              json
            }
          })
        );
      }
    } catch (error) {
      KMainFunctions.exceptionHandler(error);
    }
  }

  public static async copyToClipboard(value?: string) {
    try {
      await navigator.clipboard.writeText(value);
    } catch (e) {
      KMainFunctions.exceptionHandler(e);
    }
  }

  public static signinwithgoogle(screen: any): Promise<{}> {
    screen.props.googleLogin();
    localStorage.setItem("isGoogleLoginInProgress", "true");
    localStorage.setItem("isGoogleLoginAborted", "false");

    const previousUser = _.cloneDeep(window.userInfo ?? {});

    return new Promise((resolve, reject) => {
      const interval = setInterval(() => {
        if (localStorage.getItem("isGoogleLoginInProgress") === "false") {
          clearInterval(interval);
          if (localStorage.getItem("isGoogleLoginAborted") === "true") {
            localStorage.removeItem("isGoogleLoginInProgress");
            localStorage.removeItem("isGoogleLoginAborted");
            KuikaAppManager.hideSpinner(screen);
            reject();
          } else {
            resolve({});
          }

          if (previousUser && !_.isEqual(previousUser, window.userInfo)) {
            clearInterval(interval);
            localStorage.removeItem("isGoogleLoginInProgress");
            localStorage.removeItem("isGoogleLoginAborted");
            resolve({});
          }
        }
      }, 200);
    });
  }

  public static getPublicIpAddress(): string {
    try {
      // Send a cross-origin request to get the public IP address
      const request = new XMLHttpRequest();
      request.open("GET", "https://api.ipify.org?format=json", false);
      request.send(null);
      if (request.status === 200) {
        const response = JSON.parse(request.responseText);
        return response.ip;
      }
      return "";
    } catch (error) {
      KMainFunctions.exceptionHandler(error);
      return "";
    }
  }

  public static sendVerificationCode(screen: any) {
    UserService.SendVerificationCode({
      email: USER,
      dontSendEmail: false,
      language: ""
    })
      .then(() => {})
      .catch((e) => {
        KMainFunctions.exceptionHandler(e);
      });

    return "Mail send";
  }

  public static async generateOTP(userName: string) {
    const TOTP = (await import("totp-generator")).TOTP;

    const secret = this.convertToOtpSecret(userName.toLowerCase());

    let algorithm: "SHA-1" | "SHA-256" | "SHA-512" = "SHA-1";

    if (OTP_ALGORITHM === "SHA256") algorithm = "SHA-256";
    else if (OTP_ALGORITHM === "SHA512") algorithm = "SHA-512";

    const generatedOTP = await TOTP.generate(secret, {
      period: OTP_PERIOD,
      digits: OTP_DIGITS,
      algorithm
    });

    return generatedOTP.otp;
  }

  public static generateAuthenticatorAppUri(userName?: string) {
    try {
      const language = localStorage.getItem("ml");
      if (!userName) {
        let message = "";
        switch (language) {
          case "en_US":
            message = "Unable to generate authenticator app (OTP) URI without username.";
            break;

          case "fr_FR":
            message = "Impossible de générer l'URI de l'application d'authentification (OTP) sans nom d'utilisateur.";
            break;

          case "tr_TR":
            message = "Kullanıcı adı olmadan Kimlik Doğrulayıcı (OTP) ugulama URI'yı oluşturulamaz.";
            break;
        }
        throw new Error(message);
      }

      if (!OTP_SECRET_KEY) {
        let message = "Authenticator (OTP) application settings are missing. Please contact your Administrator";
        switch (language) {
          case "en_US":
            message = "Authenticator (OTP) application settings are missing. Please contact your Administrator";
            break;

          case "fr_FR":
            message =
              "Les paramètres de l'application Authentificateur (OTP) sont manquants. Veuillez contacter votre administrateur";
            break;

          case "tr_TR":
            message = "Kimlik Doğrulayıcı (OTP) uygulama ayarları eksik. Lütfen Yöneticinizle iletişime geçin";
            break;
        }
        throw new Error(message);
      }
      const usrName = userName?.toString()?.toLowerCase() ?? "";
      const domainName = this.removeSpecialCharacter(window.kuika?.info?.workspace ?? "");
      const secret = this.convertToOtpSecret(usrName);
      const url = `otpauth://totp/${domainName}:${usrName}?secret=${secret}&issuer=${domainName}&algorithm=${OTP_ALGORITHM}&digits=${OTP_DIGITS}&period=${OTP_PERIOD}`;
      return url;
    } catch (error) {
      KMainFunctions.exceptionHandler(error);
      return "";
    }
  }

  public static convertToOtpSecret(userName: string) {
    const secretKey: string = `${userName.toLowerCase()}${OTP_SECRET_KEY}KUIKAMOBILEKEYKUIKAMOBILEKEY2345KUIKAMOBILEKEYKUIKAMOBILEKEY2345`;
    const secret = this.subString(this.ignoreNonAllowedCharacters4Base32Secret(secretKey), 0, 64);

    return secret ?? "";
  }

  // changeTwoFactorAuthenticationType moved to BaseReactSystemFunctions (RNM-0133): its body was a one-line UserService/
  // ServerFilesService call, so the shared seam owns it with the route made explicit.

  public static importTableConfigs = (screen, tableName, configJSON) => {
    const screenTable = Object.keys(screen).filter((v) => v.includes(tableName));
    const refTable = screenTable.find((v) => v.includes("kuikaTableRef") || v.includes("kuikaPivotTableRef"));
    if (
      screen[refTable] != undefined &&
      screen[refTable] != null &&
      screen[refTable].current != undefined &&
      screen[refTable].current != null &&
      screen[refTable].current.setTableConfigJson != undefined &&
      configJSON != undefined &&
      configJSON != null &&
      configJSON != ""
    ) {
      screen[refTable].current.setTableConfigJson(configJSON);
    }
  };

  public static exportTableConfigs = (screen, tableName) => {
    const screenTable = Object.keys(screen).filter((v) => v.includes(tableName));
    const refTable = screenTable.find((v) => v.includes("kuikaTableRef") || v.includes("kuikaPivotTableRef"));
    if (
      screen[refTable] != undefined &&
      screen[refTable] != null &&
      screen[refTable].current != undefined &&
      screen[refTable].current != null &&
      screen[refTable].current.getTableConfigJson != undefined
    ) {
      return screen[refTable].current.getTableConfigJson();
    }
    return "";
  };

  public static clearTableFilteringConfigs = (screen, tableName) => {
    const screenTable = Object.keys(screen).filter((v) => v.includes(tableName));
    const refTable = screenTable.find((v) => v.includes("kuikaTableRef"));
    if (
      screen[refTable] != undefined &&
      screen[refTable] != null &&
      screen[refTable].current != undefined &&
      screen[refTable].current != null &&
      screen[refTable].current.clearFilterConfigs != undefined
    ) {
      screen[refTable].current.clearFilterConfigs();
    }
  };

  public static resetTableConfigs = (screen, tableName) => {
    const screenTable = Object.keys(screen).filter((v) => v.includes(tableName));
    const refTable = screenTable.find((v) => v.includes("kuikaTableRef") || v.includes("kuikaPivotTableRef"));
    if (
      screen[refTable] != undefined &&
      screen[refTable] != null &&
      screen[refTable].current != undefined &&
      screen[refTable].current != null &&
      screen[refTable].current.resetTableConfigs != undefined
    ) {
      screen[refTable].current.resetTableConfigs();
    }
  };

  public static searchTable = (screen, tableName, searchText) => {
    const screenTable = Object.keys(screen).filter((v) => v.includes(tableName));
    const refTable = screenTable.find((v) => v.includes("kuikaTableRef") || v.includes("kuikaPivotTableRef"));
    if (
      screen[refTable] != undefined &&
      screen[refTable] != null &&
      screen[refTable].current != undefined &&
      screen[refTable].current != null &&
      screen[refTable].current.searchTable != undefined
    ) {
      screen[refTable].current.searchTable(searchText);
    }
  };

  public static exportTable = (screen, tableName) => {
    const screenTable = Object.keys(screen).filter((v) => v.includes(tableName));
    const refTable = screenTable.find((v) => v.includes("kuikaTableRef") || v.includes("kuikaPivotTableRef"));
    if (
      screen[refTable] != undefined &&
      screen[refTable] != null &&
      screen[refTable].current != undefined &&
      screen[refTable].current != null &&
      screen[refTable].current.exportTable != undefined
    ) {
      screen[refTable].current.exportTable();
    }
  };

  public static exportNodeTree = (screen, nodeTreeName) => {
    const screenKeys = Object.keys(screen).filter((v) => v.includes(nodeTreeName));
    const refKey = screenKeys.find((v) => v.includes("kuikaNodeTreeRef"));
    if (
      refKey &&
      screen[refKey] != undefined &&
      screen[refKey] != null &&
      screen[refKey].current != undefined &&
      screen[refKey].current != null &&
      screen[refKey].current.exportNodeTree != undefined
    ) {
      screen[refKey].current.exportNodeTree();
    }
  };

  public static readNFC = () => {
    KMainFunctions.displayWarningNotification("Action ReadNFC is not supported on web.");
    return null;
  };

  public static async downloadFileFromServer(fileid, filename) {
    ServerFilesService.DownloadFile(fileid, filename);
    return "";
  }

  public static async downloadFileFromBucket(keyName, bucketName, fileName, encrypt) {
    ServerFilesService.DownloadFileFromBucket(keyName, bucketName, fileName, encrypt);
    return "";
  }

  // deleteFileFromServer moved to BaseReactSystemFunctions (RNM-0133): its body was a one-line UserService/
  // ServerFilesService call, so the shared seam owns it with the route made explicit.

  public static async deleteFileFromBucket(objectKey: string) {
    return ServerFilesService.DeleteFileFromBucket(objectKey);
  }

  public static isDocumentReady() {
    switch (document.readyState) {
      case "complete":
        return true;
      default:
        return false;
    }
  }

  public static mqttpublish = (client, topic, message, qos, retain = false) => {
    if (!client || !client.connected) {
      console.error("MQTT client is not connected");
      return;
    }

    if (qos === undefined || qos === null) {
      qos = 0;
    }

    qos = Number(qos);

    client.publish(topic, message, { qos, retain }, (error) => {
      if (error) {
        console.error("MQTT publish failed:", error);
      }
    });
  };

  public static mqttsubscribe = async (client, subscribeAction, topic) => {
    return new Promise((resolve, reject) => {
      const mqttTopic = topic;

      if (!client._resubscribeTopics || !client._resubscribeTopics[topic]) {
        client.subscribe(topic, { nl: false }, (err) => {
          if (err) {
            resolve({ isSuccess: false });
          }

          client.on("message", (topic, message) => {
            if (mqttTopic === topic) {
              subscribeAction(message.toString());
            }
          });

          resolve({ isSuccess: true });
        });
      } else {
        resolve({ isSuccess: true });
      }
    });
  };

  public static getMqttClientId(clientName, screenName) {
    var mqttClientId = this.readFromLocalStorage(`${clientName}_${screenName}_MQTT_CLIENT_ID`);
    if (mqttClientId === undefined || mqttClientId === null) {
      mqttClientId = Guid.create().toString();
      this.writeToLocalStorage(`${clientName}_${screenName}_MQTT_CLIENT_ID`, mqttClientId);
    }
    return mqttClientId;
  }

  public static async openImportMappedExcelModal(
    screen: any,
    datasourceId: string,
    tableName: string,
    primaryKey: string,
    mappedColumnsJson: string,
    parametersJson?: string,
    ...paramValues: any[]
  ) {
    const mappedColumns: IImportMappedExcelColumnMapDefinition[] = JSON.parse(mappedColumnsJson);
    const parameterDefinitions: IImportMappedExcelParameter[] = parametersJson ? JSON.parse(parametersJson) : [];

    // Combine parameter metadata with values
    const parameters = parameterDefinitions.map((def, index) => ({
      ...def,
      value: paramValues[index]
    }));

    screen?.props?.showImportMappedExcelModal(datasourceId, tableName, primaryKey, mappedColumns, parameters);

    return new Promise<void>((resolve, reject) => {
      const interval = setInterval(() => {
        if (screen.props.isImportMappedExcelModalVisible === false) {
          clearInterval(interval);
          resolve();
        }
      }, 100);
    });
  }

  public static async VerifyRecaptchaToken(token: string) {
    if (!token) {
      this.notify(null, "Recaptcha token is missing.", "danger", "bottom-right", null, null, null, null);
      return false;
    }

    return true;
  }

  public static async confirmation(
    confirmationMessage: string,
    confirmationFontFamily: string = "Poppins",
    _confirmationHeader: string,
    _icon: "warning" | "trash" | "info" | "question" | "confirmation" | "notification",
    _iconBackgroundColor: string,
    _confirmButtonColor?: string,
    _cancelButtonColor?: string
  ): Promise<boolean> {
    const confirmationHeader = _confirmationHeader || null;
    const icon = _icon || null;
    const iconBackgroundColor = _iconBackgroundColor || "#246dff";
    // Unset means "keep the app's theme colour" — general.scss holds the fallback.
    const confirmButtonColor: string | null = _confirmButtonColor || null;
    const cancelButtonColor: string | null = _cancelButtonColor || null;

    const warningIcon = `<img src="common/alert-triangle.svg" alt="warning" style="width: 40px; height: 40px;" />`;
    const trashIcon = `<img src="common/trash.svg" alt="trash" style="width: 40px; height: 40px;" />`;
    const infoIcon = `<img src="common/info-circle.svg" alt="info" style="width: 40px; height: 40px;" />`;
    const questionIcon = `<img src="common/question-mark.svg" alt="question" style="width: 40px; height: 40px;" />`;
    const confirmationIcon = `<img src="common/check.svg" alt="confirmation" style="width: 40px; height: 40px;" />`;
    const notificationIcon = `<img src="common/bell.svg" alt="notification" style="width: 40px; height: 40px;" />`;

    const iconMap = {
      warning: warningIcon,
      trash: trashIcon,
      info: infoIcon,
      question: questionIcon,
      confirmation: confirmationIcon,
      notification: notificationIcon
    };

    const modalOptions: any = {
      title: confirmationMessage,
      icon: icon ? iconMap[icon] : undefined,
      showCancelButton: true,
      confirmButtonText: translationService.translate("common.confirm", localStorage.getItem("ml") as ELanguage),
      cancelButtonText: translationService.translate("common.cancel", localStorage.getItem("ml") as ELanguage),
      customClass: {
        title: `swal2-font-${confirmationFontFamily.toLowerCase().replaceAll(" ", "-")}`,
        confirmButton: `swal2-font-${confirmationFontFamily.toLowerCase().replaceAll(" ", "-")}`,
        cancelButton: `swal2-font-${confirmationFontFamily.toLowerCase().replaceAll(" ", "-")}`,
        container: `swal2-font-${confirmationFontFamily.toLowerCase().replaceAll(" ", "-")}`
      }
    };

    if (confirmationHeader && confirmationHeader !== "") {
      modalOptions.html = `
        <div style="margin-bottom: 16px;">
          <h3 style="font-size: 28px; margin: 0 0 24px 0;">${confirmationHeader}</h3>
          <p>${confirmationMessage}</p>
        </div>`;
      modalOptions.header = `<div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 24px; width: 100%; border-bottom: 1px solid #DCDFE4; padding-bottom: 12px;">
              <span style="font-size: 12px; font-weight: 700; text-transform: uppercase; margin: 0 12px 0 12px;">${confirmationHeader}</span>
              <div id="swal-close-button" style="cursor: pointer; width: 24px; height: 24px; display: flex; align-items: center; justify-content: center; margin-right: 12px;">
                <svg width="20" height="20" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                  <path d="M18 6L6 18M6 6L18 18" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                </svg>
              </div>
          </div>`;
      delete modalOptions.title;

      modalOptions.didOpen = () => {
        const closeButton = document.getElementById("swal-close-button");
        if (closeButton) {
          closeButton.addEventListener("click", () => Swal.close());
        }
      };
    }

    if (icon) {
      modalOptions.html = modalOptions.html || `<p>${confirmationMessage}</p>`;
      const backgroundColor = iconBackgroundColor || "#246dff";
      const backgroundColor2 = this.lightenColor(backgroundColor, 95);
      const iconContent = iconMap[icon] || icon;
      const gradient = `linear-gradient(37deg, ${backgroundColor} -4.04%, ${backgroundColor2} 68.6%)`;
      modalOptions.html = `
        <div style="display: flex; flex-direction: column; align-items: center; margin-bottom: 16px; width: 400px; border-bottom: 1px solid #DCDFE4; padding-bottom: 12px;">
        ${modalOptions.header || ""}
        <div style="background: ${gradient}; width: 80px; height: 80px; border-radius: 16px; display: flex; align-items: center; justify-content: center; margin-bottom: 24px; box-shadow: 0px 5px 15px 0px rgba(0, 0, 0, 0.12); margin-top: ${
          confirmationHeader ? "0" : "16px"
        };">
            <span>${iconContent}</span>
          </div>
          ${
            confirmationHeader
              ? `<h3 style="font-size: 16px; font-weight: 600; margin: 0 0 16px 0;">${confirmationHeader}</h3>`
              : ""
          }
          <p style="margin: 0; color: #41546E; font-size: 14px; font-weight: 400; padding: 0 12px; marginBottom: ${
            confirmationHeader ? "0" : "16px"
          }">${confirmationMessage}</p>
        </div>`;
      delete modalOptions.title;
      delete modalOptions.icon;
    } else {
      modalOptions.html = `
        <div style="display: flex; flex-direction: column; align-items: center; margin-bottom: 16px; width: 400px; border-bottom: 1px solid #DCDFE4; padding-bottom: 12px;">
        ${modalOptions.header || ""}
          ${
            confirmationHeader
              ? `<h3 style="font-size: 16px; font-weight: 600; margin: 0 0 16px 0;">${confirmationHeader}</h3>`
              : ""
          }
          <p style="margin: 0; color: #41546E; font-size: 14px; font-weight: 400; padding: ${
            !confirmationHeader ? "12px" : "0 12px"
          }; marginBottom: ${confirmationHeader ? "0" : "16px"}">${confirmationMessage}</p>
        </div>`;
      delete modalOptions.title;
      delete modalOptions.icon;
    }

    // Button colours are applied as CSS custom properties on the popup: the
    // .swal2-confirm / .swal2-cancel rules in general.scss carry !important
    // (they have to, to beat SweetAlert's own defaults), which an inline style
    // — what Swal's confirmButtonColor option writes — could never win against.
    if (confirmButtonColor || cancelButtonColor) {
      const previousDidOpen: ((popup: HTMLElement) => void) | undefined = modalOptions.didOpen;
      modalOptions.didOpen = (popup: HTMLElement): void => {
        previousDidOpen?.(popup);
        if (confirmButtonColor) {
          popup.style.setProperty("--kuika-confirm-button-bg", confirmButtonColor);
          popup.style.setProperty("--kuika-confirm-button-color", this.getReadableTextColor(confirmButtonColor));
        }
        if (cancelButtonColor) {
          popup.style.setProperty("--kuika-cancel-button-color", cancelButtonColor);
        }
      };
    }

    // KOA-17800: a confirmation triggered from a keyboard event (e.g. NumberInput
    // OnPressEnter) must not be confirmed by that same physical key press.
    //
    // 1) Open the dialog in a fresh macrotask. The browser runs a key's default action
    //    after the event finishes dispatching — if Swal had already focused the Confirm
    //    button by then, the opening Enter press would click it and the dialog would
    //    self-confirm without any user interaction. Must be the native timer
    //    (module-level setTimeout is the worker-timers one): the point is to yield the
    //    current event-dispatch task on the main thread.
    // 2) While the dialog is pending, swallow auto-repeat Enter keydowns at capture
    //    phase: holding Enter produces repeat keydowns that target the focused Confirm
    //    button and natively click it. A repeat can never be a deliberate confirm —
    //    a real one is a fresh press (repeat === false), which still works.
    const blockRepeatEnter = (event: KeyboardEvent): void => {
      if (event.key === "Enter" && event.repeat) {
        event.preventDefault();
        event.stopPropagation();
      }
    };
    document.addEventListener("keydown", blockRepeatEnter, true);
    try {
      await new Promise<void>((resolve) => {
        window.setTimeout(resolve, 0);
      });
      const result: SweetAlertResult = await Swal.fire(modalOptions);
      return result.isConfirmed;
    } finally {
      document.removeEventListener("keydown", blockRepeatEnter, true);
    }
  }

  /**
   * Black or white, whichever stays readable on `hex`. Keeps a custom confirm
   * button legible when the user picks a light colour; the default #246eff is
   * dark, so existing apps keep their white label.
   */
  private static getReadableTextColor(hex: string): string {
    const normalized: string = hex.replace("#", "");
    const expanded: string =
      normalized.length === 3
        ? `${normalized[0]}${normalized[0]}${normalized[1]}${normalized[1]}${normalized[2]}${normalized[2]}`
        : normalized;

    if (expanded.length !== 6) {
      return "#ffffff";
    }

    const r: number = parseInt(expanded.slice(0, 2), 16);
    const g: number = parseInt(expanded.slice(2, 4), 16);
    const b: number = parseInt(expanded.slice(4, 6), 16);

    if (Number.isNaN(r) || Number.isNaN(g) || Number.isNaN(b)) {
      return "#ffffff";
    }

    // Perceived brightness (ITU-R BT.601), the same weighting browsers use for
    // greyscale conversion.
    const brightness: number = (r * 299 + g * 587 + b * 114) / 1000;
    return brightness > 150 ? "#081f36" : "#ffffff";
  }

  private static lightenColor(hex: string, percent: number): string {
    let r = parseInt(hex.slice(1, 3), 16);
    let g = parseInt(hex.slice(3, 5), 16);
    let b = parseInt(hex.slice(5, 7), 16);

    if (hex.length === 4) {
      r = parseInt(hex[1] + hex[1], 16);
      g = parseInt(hex[2] + hex[2], 16);
      b = parseInt(hex[3] + hex[3], 16);
    }

    r = Math.min(255, Math.round(r + (255 - r) * (percent / 120)));
    g = Math.min(255, Math.round(g + (255 - g) * (percent / 120)));
    b = Math.min(255, Math.round(b + (255 - b) * (percent / 120)));

    return `#${r.toString(16).padStart(2, "0")}${g.toString(16).padStart(2, "0")}${b.toString(16).padStart(2, "0")}`;
  }

  public static getEntityValueFromDynamicForm(screen: any, diId: number) {
    if (!screen) return null;
    if (typeof screen !== "object") return null;

    const dynamicFormKey = Object.keys(screen).find((key) => key.endsWith(`${diId}_value_kuikaDynamicFormRef`));

    if (dynamicFormKey && screen[dynamicFormKey] && screen[dynamicFormKey].current) {
      return screen[dynamicFormKey].current.generateEntityValue();
    }
    return null;
  }

  public static clearDynamicForm(screen: any, diId: number) {
    if (!screen) return null;
    if (typeof screen !== "object") return null;

    const dynamicFormKey = Object.keys(screen).find((key) => key.endsWith(`${diId}_value_kuikaDynamicFormRef`));

    if (dynamicFormKey && screen[dynamicFormKey] && screen[dynamicFormKey].current) {
      screen[dynamicFormKey].current.clearForm();
    }

    return null;
  }

  public static setEntityAttributeValueInDynamicForm(screen: any, diId: number, attributeId: string, value: any) {
    if (!screen) return null;
    if (typeof screen !== "object") return null;

    const dynamicFormKey = Object.keys(screen).find((key) => key.endsWith(`${diId}_value_kuikaDynamicFormRef`));

    if (dynamicFormKey && screen[dynamicFormKey] && screen[dynamicFormKey].current) {
      screen[dynamicFormKey].current.setEntityAttributeValue(attributeId, value);
    }

    return null;
  }

  public static getEntityAttributeValueInDynamicForm(screen: any, diId: number, attributeId: string) {
    if (!screen) return null;
    if (typeof screen !== "object") return null;

    const dynamicFormKey = Object.keys(screen).find((key) => key.endsWith(`${diId}_value_kuikaDynamicFormRef`));

    if (dynamicFormKey && screen[dynamicFormKey] && screen[dynamicFormKey].current) {
      return screen[dynamicFormKey].current.getEntityAttributeValue(attributeId);
    }

    return null;
  }

  public static getIsDynamicFormValid(screen: any, diId: number): boolean {
    if (!screen) return false;
    if (typeof screen !== "object") return false;

    const dynamicFormKey = Object.keys(screen).find((key) => key.endsWith(`${diId}_value_kuikaDynamicFormRef`));

    if (dynamicFormKey && screen[dynamicFormKey] && screen[dynamicFormKey].current) {
      return screen[dynamicFormKey].current.getIsFormValid();
    }

    return false;
  }

  public static getWfPageComponent(screen: any, screenName: string, callback?: any, drawerId?: string) {
    const closeCallback =
      callback ||
      (() => {
        if (drawerId && screen.setState) {
          screen.setState({ [`NavVisible${drawerId}`]: false }, () => {
            if (screen.callCallbackFunction) {
              screen.callCallbackFunction(Number.parseInt(drawerId));
            }
          });
        }
      });
    const props = {
      onClose: closeCallback,
      screenInputs: window.kuika.navigationScreenInputs,
      navigator: screen.props?.navigator,
      form: screen.props?.form,
      context: screen.props?.context
    };
    
  }

  public static toggleLayout(screen: any, position: string): boolean {
    if (!screen || !position) {
      return false;
    }

    const validPositions = ["left", "right", "top", "bottom"];
    if (!validPositions.includes(position.toLowerCase())) {
      return false;
    }

    const pos = position.toLowerCase();
    let targetElementId: string;
    let layoutDiId: number;

    switch (pos) {
      case "left":
        targetElementId = "layout_left";
        layoutDiId = -12;
        break;
      case "right":
        targetElementId = "layout_right";
        layoutDiId = -13;
        break;
      case "top":
        targetElementId = "layout_header";
        layoutDiId = -10;
        break;
      case "bottom":
        targetElementId = "layout_footer";
        layoutDiId = -11;
        break;
      default:
        return false;
    }

    try {
      const matchingElements = document.querySelectorAll(`[id*="${targetElementId}"]`);
      if (!matchingElements?.length) {
        return false;
      }
      const lastIndex = matchingElements.length - 1;
      const targetElement = matchingElements[lastIndex] as HTMLElement;

      const currentVisibility = window.getComputedStyle(targetElement).visibility;
      const isCurrentlyVisible = currentVisibility !== "hidden";

      if (isCurrentlyVisible) {
        targetElement.style.display = "none";
        targetElement.style.width = "0px";
        targetElement.style.height = "0px";
        targetElement.style.overflow = "hidden";
        targetElement.style.visibility = "hidden";
      } else {
        targetElement.style.display = "";
        targetElement.style.width = "";
        targetElement.style.height = "";
        targetElement.style.overflow = "";
        targetElement.style.visibility = "visible";
      }

      return true;
    } catch (error) {
      console.error("Error in toggleLayout:", error);
      return false;
    }
  }

  // Cache Functions
  // pushToCache / fetchFromCache / fetchFromCacheToList / removeFromCache / checkKeyExistence moved
  // to BaseReactSystemFunctions (RNM-0103). They are inherited unchanged — a body of the same name
  // here would shadow the shared one and silently undo the move.

  // refundStripePayment / captureReservedFunds / cancelStripePayment moved to
  // BaseReactSystemFunctions (RNM-0103). Inherited unchanged — a body of the same name here
  // would shadow the shared one.

  

  

  // ── Document Management System Actions ───────────────────────────

  /**
   * GET /v1/api/documentmanagement/tree — Returns a flat node list for the Directory element.
   * Folders are always returned in full; documents are paginated.
   * The X-Total-Documents response header carries the total count for the Pagination element.
   * @param folderId    Optional: returns only the subtree of this folder
   * @param page        Page number (default: 1)
   * @param pageSize    Number of documents per page (default: 50, max: 200)
   * @param searchQuery Search filter by document name (optional)
   */
  // getDocumentTree moved to BaseReactSystemFunctions (RNM-0124): its body was pure transport,
  // so the shared seam owns it and both targets call the same one.

  /**
   * GET /v1/api/documentmanagement/archived-tree — Returns a flat node list of archived documents with their folders.
   * Same shape as getDocumentTree — use with the Directory element.
   * hideEmptyFolders defaults to true (only folders containing archived documents are returned).
   * @param folderId         Optional: returns only the subtree of this folder
   * @param page             Page number (default: 1)
   * @param pageSize         Number of documents per page (default: 50, max: 200)
   * @param searchQuery      Search filter by document name (optional)
   * @param hideEmptyFolders Omit folders with no archived documents (default: true)
   */
  // getArchivedDocumentTree moved to BaseReactSystemFunctions (RNM-0124): its body was pure transport,
  // so the shared seam owns it and both targets call the same one.

  /**
   * GET /v1/api/documentmanagement/folders/tree — Returns a flat folder-only node list.
   * No documents are included. Each node: { id, name, parentId, nodeType: "folder" }.
   * Suitable for folder-picker UIs (e.g. a move-to-folder dialog).
   * @param folderId       Optional: returns only the subtree of this folder
   * @param folderPage     Folder page number (default: 1)
   * @param folderPageSize Number of folders per page (default: 200, max: 1000)
   */
  // getDocumentFolderTree moved to BaseReactSystemFunctions (RNM-0124): its body was pure transport,
  // so the shared seam owns it and both targets call the same one.

  /**
   * GET /v1/api/documentmanagement/folders/{folderId}/documents
   * Returns the paginated list of documents directly inside the given folder (non-recursive).
   * Each node: { id, name, parentId, mimeType, nodeType: "document" }.
   * The X-Total-Documents response header carries the total count for the Pagination element.
   * @param folderId    Required: the folder whose documents to list
   * @param page        Page number (default: 1)
   * @param pageSize    Documents per page (default: 50, max: 200)
   * @param searchQuery Filter by document name (optional)
   */
  // getFolderDocuments moved to BaseReactSystemFunctions (RNM-0124): its body was pure transport,
  // so the shared seam owns it and both targets call the same one.

  /**
   * DELETE /v1/api/documentmanagement/{documentId}/share/{shareId}
   * Revokes (invalidates) a specific share link. Use shareId from getDocumentShares.
   * Requires manage permission on the document.
   * @param documentId Required: document GUID
   * @param shareId    Required: share link GUID to revoke
   */
  // revokeShareLink moved to BaseReactSystemFunctions (RNM-0124): its body was pure transport,
  // so the shared seam owns it and both targets call the same one.

  /**
   * GET /v1/api/documentmanagement/stats — Returns aggregate storage statistics.
   * Result: { totalDocuments, archivedDocuments, totalFolders, totalStorageBytes, documentsByMimeType }
   * @param folderId Optional: limit stats to this folder
   * @param includeSubfolders Optional (default true): when false, only the folder itself is counted (no subtree)
   */
  // getStorageStats moved to BaseReactSystemFunctions (RNM-0124): its body was pure transport,
  // so the shared seam owns it and both targets call the same one.

  /**
   * GET /v1/api/documentmanagement/folders/{folderId}/permissions
   * Lists permission grants on a folder (principalType, principalId, permissionLevel, expiresAt).
   * Requires manage permission on the folder.
   * @param folderId Required: folder GUID
   * @param page     Page number (default: 1)
   * @param pageSize Items per page (default: 100)
   */
  // getFolderPermissions moved to BaseReactSystemFunctions (RNM-0124): its body was pure transport,
  // so the shared seam owns it and both targets call the same one.

  // ── DMS Access Groups (role-independent, scoped-admin) ──

  /** GET accessgroups/tree → flat node list [{ id, name, parentId }] (scoped). Bind to a tree:
   *  datavaluefield=id, datatextfield=name, dataparentfield=parentId. */
  /** GET accessgroups/tree → the access-group hierarchy. */
  // getAccessGroupTree moved to BaseReactSystemFunctions: its body was pure transport, so the shared seam
  // owns it and both targets call the same one.

  /** POST accessgroups → creates a group (root requires DMS admin; sub-group requires managing the parent).
   *  parentId is optional AND nullable: omit / null / empty-string all mean "root group". A screen-bound
   *  parentId is frequently an empty string (cleared field / unselected tree), which must not be sent as ""
   *  (the backend binds it to Guid? and would reject a non-empty non-GUID). Normalize empty/whitespace → null. */
  // createAccessGroup moved to BaseReactSystemFunctions (RNM-0124): its body was pure transport,
  // so the shared seam owns it and both targets call the same one.

  /** PATCH accessgroups/{id} → renames a group. */
  // renameAccessGroup moved to BaseReactSystemFunctions (RNM-0124): its body was pure transport,
  // so the shared seam owns it and both targets call the same one.

  /** DELETE accessgroups/{id} → soft-deletes a group (blocked if it has sub-groups). */
  // deleteAccessGroup moved to BaseReactSystemFunctions (RNM-0124): its body was pure transport,
  // so the shared seam owns it and both targets call the same one.

  /** GET accessgroups/{id}/members → user id list. */
  // getAccessGroupMembers moved to BaseReactSystemFunctions: its body was pure transport, so the shared seam
  // owns it and both targets call the same one.

  /** POST accessgroups/{id}/members → adds a user (idempotent, role-independent). */
  // addAccessGroupMember moved to BaseReactSystemFunctions (RNM-0124): its body was pure transport,
  // so the shared seam owns it and both targets call the same one.

  /** DELETE accessgroups/{id}/members/{userId} → removes a user. */
  // removeAccessGroupMember moved to BaseReactSystemFunctions (RNM-0124): its body was pure transport,
  // so the shared seam owns it and both targets call the same one.

  /** POST accessgroups/{id}/managers → assigns a manager (DMS admin only). */
  // assignAccessGroupManager moved to BaseReactSystemFunctions (RNM-0124): its body was pure transport,
  // so the shared seam owns it and both targets call the same one.

  /** DELETE accessgroups/{id}/managers/{userId} → removes a manager (DMS admin only). */
  // unassignAccessGroupManager moved to BaseReactSystemFunctions (RNM-0124): its body was pure transport,
  // so the shared seam owns it and both targets call the same one.

  /**
   * POST accessgroups/{id}/folder-permissions → grants this access group `permissionLevel` on `folderId`
   * (requires 'manage' on that folder). Single-folder: bind folderId to a folder-picker's selected id
   * (Directory/Tree/Selectbox). To grant several folders, invoke once per folder. The backend body stays a
   * list (folderIds) so a future bulk variant needs no server change; here it is always a single element.
   */
  // grantAccessGroupFolderPermissions moved to BaseReactSystemFunctions (RNM-0124): its body was pure transport,
  // so the shared seam owns it and both targets call the same one.

  /**
   * GET /v1/api/documentmanagement/{documentId}/share
   * Lists active (non-expired) share links for a document.
   * Fields: id, permissionLevel, expiresAt, maxUseCount, useCount, createdAt.
   * ShareToken is intentionally excluded. Requires manage permission.
   * @param documentId Required: document GUID
   * @param page       Page number (default: 1)
   * @param pageSize   Items per page (default: 50)
   */
  // getDocumentShares moved to BaseReactSystemFunctions (RNM-0124): its body was pure transport,
  // so the shared seam owns it and both targets call the same one.

  /**
   * GET /v1/api/documentmanagement/mine
   * Returns non-archived documents uploaded by the current user, newest first.
   * The X-Total-Documents response header carries the total count.
   * @param page          Page number (default: 1)
   * @param pageSize      Documents per page (default: 50, max: 200)
   * @param includeShared When true, also returns documents shared with the user (default: false)
   */
  // getMyDocuments moved to BaseReactSystemFunctions (RNM-0124): its body was pure transport,
  // so the shared seam owns it and both targets call the same one.

  /**
   * GET /v1/api/documentmanagement/folders/{folderId}/subfolders
   * Returns direct child subfolders (one level only, not recursive).
   * Each node: { id, name, parentId, nodeType: "folder" }.
   * The X-Total-Folders response header carries the total count.
   * @param folderId Required: parent folder GUID
   * @param page     Page number (default: 1)
   * @param pageSize Items per page (default: 200)
   */
  // getFolderSubfolders moved to BaseReactSystemFunctions (RNM-0124): its body was pure transport,
  // so the shared seam owns it and both targets call the same one.

  /**
   * GET /v1/api/documentmanagement/{documentId} — Returns metadata for a single document.
   * Fields: id, documentName, mimeType, currentVersion, isArchived, folderId, downloadUrl.
   * @param documentId Required: document GUID
   */
  // getDocumentMetadata moved to BaseReactSystemFunctions (RNM-0124): its body was pure transport,
  // so the shared seam owns it and both targets call the same one.

  /**
   * GET /v1/api/documentmanagement/{documentId}/versions — Returns all versions of a document.
   * Each item: { id, version, contentSize, contentHash, createdAt, createdUserId }.
   * @param documentId Required: document GUID
   */
  // getVersions moved to BaseReactSystemFunctions (RNM-0124): its body was pure transport,
  // so the shared seam owns it and both targets call the same one.

  /**
   * DELETE /v1/api/documentmanagement/folders/{folderId}[?force=true]
   * @param folderId     Required: folder GUID
   * @param forceDelete  When true, recursively soft-deletes all subfolders and documents first.
   *                     When false (default), returns 409 if the folder is not empty.
   */
  // deleteFolder moved to BaseReactSystemFunctions (RNM-0124): its body was pure transport,
  // so the shared seam owns it and both targets call the same one.

  /**
   * PUT /v1/api/documentmanagement/folders/{folderId}/move — Moves a folder under a new parent.
   * Pass null/empty for targetParentId to move to the root level.
   * @param folderId       Required: folder GUID to move
   * @param targetParentId Optional: new parent folder GUID (null = root)
   */
  // moveFolder moved to BaseReactSystemFunctions (RNM-0124): its body was pure transport,
  // so the shared seam owns it and both targets call the same one.

  /**
   * PUT /v1/api/documentmanagement/folders/{folderId}/move-to-parent
   * Moves a folder one level up (to its grandparent). Returns 409 if already at root.
   * @param folderId Required: folder GUID
   */
  // moveFolderToParent moved to BaseReactSystemFunctions (RNM-0124): its body was pure transport,
  // so the shared seam owns it and both targets call the same one.

  /**
   * GET /v1/api/documentmanagement/{documentId}/permissions — Lists permission grants on a document.
   * Each item: { id, principalType, principalId, permissionLevel, expiresAt }.
   * Requires manage permission.
   * @param documentId Required: document GUID
   * @param page       Page number (default: 1)
   * @param pageSize   Items per page (default: 100)
   */
  // getDocumentPermissions moved to BaseReactSystemFunctions (RNM-0124): its body was pure transport,
  // so the shared seam owns it and both targets call the same one.

  /**
   * GET /v1/api/documentmanagement?includeArchived=true — Lists archived documents.
   * The X-Total-Count response header carries the total count for the Pagination element.
   * @param page     Page number (default: 1)
   * @param pageSize Documents per page (default: 50, max: 200)
   */
  // getArchivedDocuments moved to BaseReactSystemFunctions (RNM-0124): its body was pure transport,
  // so the shared seam owns it and both targets call the same one.

  /**
   * POST /v1/api/documentmanagement/{documentId}/duplicate — Duplicates a document into a target folder.
   * The duplicate is fully independent (new encryption key, name gets " (copy)" suffix).
   * Returns the new document metadata.
   * @param documentId     Required: source document GUID
   * @param targetFolderId Optional: destination folder GUID (null = root)
   */
  // duplicateDocument moved to BaseReactSystemFunctions (RNM-0132): the port pipeline fail-closed on it, so it
  // was hand-ported outside the generated block; the shared seam owns it and both targets call it.

  /**
   * GET /v1/api/documentmanagement/search — Searches documents by name across all accessible documents.
   * Excludes archived documents. Sorted by creation date (newest first).
   * The X-Total-Documents response header carries the total count.
   * @param query    Search string (optional — returns all if omitted)
   * @param page     Page number (default: 1)
   * @param pageSize Documents per page (default: 50, max: 200)
   */
  public static async searchDocuments(
    screen: any,
    query?: string,
    page?: number,
    pageSize?: number,
    folderId?: string,
    createdAfter?: string,
    createdBefore?: string,
    createdBy?: string
  ): Promise<any> {
    try {
      const params = new URLSearchParams();
      if (query) params.set("query", query);
      if (page) params.set("page", String(page));
      if (pageSize) params.set("pageSize", String(pageSize));
      if (folderId) params.set("folderId", folderId);
      if (createdAfter) params.set("createdAfter", createdAfter);
      if (createdBefore) params.set("createdBefore", createdBefore);
      if (createdBy) params.set("createdBy", createdBy);
      const qs = params.toString();
      const result = await KuikaAppManager.ApiRequest(
        screen,
        qs ? `documentmanagement/search?${qs}` : "documentmanagement/search",
        undefined,
        "get"
      );
      return result;
    } catch (error) {
      KMainFunctions.exceptionHandler(error);
      return { data: [] };
    }
  }

  /**
   * GET /v1/api/documentmanagement/{documentId}/audit — Returns the audit log for a document.
   * Each item: { action, userId, ipAddress, createdAt, details }.
   * Requires manage permission. The X-Total-Count header carries the total count.
   * @param documentId Required: document GUID
   * @param page       Page number (default: 1)
   * @param pageSize   Items per page (default: 50, max: 200)
   */
  // getDocumentAuditLogs moved to BaseReactSystemFunctions (RNM-0124): its body was pure transport,
  // so the shared seam owns it and both targets call the same one.

  /**
   * GET /v1/api/documentmanagement/shared — Returns documents shared with the current user.
   * "Shared with me" view: documents explicitly granted via permissions, excluding own uploads.
   * The X-Total-Documents response header carries the total count.
   * @param page     Page number (default: 1)
   * @param pageSize Documents per page (default: 50, max: 200)
   */
  // getDocumentsSharedWithMe moved to BaseReactSystemFunctions (RNM-0124): its body was pure transport,
  // so the shared seam owns it and both targets call the same one.

  /**
   * GET /v1/api/documentmanagement/shared-by-me — Returns documents the current user has shared with others.
   * Lists own documents that have at least one active permission grant.
   * The X-Total-Documents response header carries the total count.
   * @param page     Page number (default: 1)
   * @param pageSize Documents per page (default: 50, max: 200)
   */
  // getDocumentsSharedByMe moved to BaseReactSystemFunctions (RNM-0124): its body was pure transport,
  // so the shared seam owns it and both targets call the same one.

  /**
   * GET /v1/api/documentmanagement/recently-modified
   * Returns non-archived documents modified (or created) within the last N days. Sorted by most recently modified first.
   * @param days     Look-back window in days (default: 30)
   * @param page     Page number (default: 1)
   * @param pageSize Documents per page (default: 50, max: 200)
   */
  // getRecentlyModifiedDocuments moved to BaseReactSystemFunctions (RNM-0124): its body was pure transport,
  // so the shared seam owns it and both targets call the same one.

  /**
   * GET /v1/api/documentmanagement/search/advanced — Advanced document search combining all filter parameters.
   * All parameters are optional. The X-Total-Documents header carries the total count.
   * @param query        Name search string (optional)
   * @param folderId     Restrict search to a folder subtree (optional)
   * @param createdAfter ISO date string (optional)
   * @param createdBefore ISO date string (optional)
   * @param createdBy    Creator user GUID (optional)
   * @param page         Page number (default: 1)
   * @param pageSize     Documents per page (default: 50, max: 200)
   */
  // searchDocumentsAdvanced moved to BaseReactSystemFunctions (RNM-0124): its body was pure transport,
  // so the shared seam owns it and both targets call the same one.

  /**
   * GET /v1/api/documentmanagement/{documentId}/activity-summary
   * Returns: totalDownloads, lastDownloadAt, activePermissions, activeShares, totalVersions.
   * Requires manage permission on the document.
   * @param documentId Required: document GUID
   */
  // getDocumentActivitySummary moved to BaseReactSystemFunctions (RNM-0124): its body was pure transport,
  // so the shared seam owns it and both targets call the same one.

  /**
   * GET /v1/api/documentmanagement/folders/{folderId}/stats
   * Returns: folderId, totalDocuments, archivedDocuments, subfolderCount, totalStorageBytes, lastUpdatedAt.
   * @param folderId          Required: folder GUID
   * @param includeSubfolders When true (default), recursively aggregates the entire subtree
   */
  // getFolderStats moved to BaseReactSystemFunctions (RNM-0124): its body was pure transport,
  // so the shared seam owns it and both targets call the same one.

  /**
   * GET /v1/api/documentmanagement/admin/audit — Admin-level paginated audit log across ALL DMS entities.
   * Optional filters: action, userId, from/to date range, entityType.
   * Requires admin/manage role.
   */
  // getAllAuditLogs moved to BaseReactSystemFunctions (RNM-0124): its body was pure transport,
  // so the shared seam owns it and both targets call the same one.

  /**
   * PUT /v1/api/documentmanagement/{documentId}/metadata — Sets (replaces) the free-form JSON metadata on a document.
   * Pass a valid JSON object as a string, e.g. '{"category":"invoice","year":"2026"}'.
   * Requires edit permission on the document.
   * @param documentId Required: document GUID
   * @param metadata   JSON string
   */
  // setDocumentMetadata moved to BaseReactSystemFunctions (RNM-0124): its body was pure transport,
  // so the shared seam owns it and both targets call the same one.

  /** Sets or updates a single metadata key-value pair on a document. Existing metadata is preserved. */
  // setDocumentMetadataField moved to BaseReactSystemFunctions (RNM-0124): its body was pure transport,
  // so the shared seam owns it and both targets call the same one.

  /** Removes a single metadata key from a document. Other fields are preserved. */
  // removeDocumentMetadataField moved to BaseReactSystemFunctions (RNM-0124): its body was pure transport,
  // so the shared seam owns it and both targets call the same one.

  /** Returns the value of a single metadata field from a document by key. */
  // getDocumentMetadataField moved to BaseReactSystemFunctions (RNM-0124): its body was pure transport,
  // so the shared seam owns it and both targets call the same one.

  /**
   * GET /v1/api/documentmanagement/by-metadata?key=&value= — Returns documents where Metadata JSON contains the given key/value pair.
   * Works on flat JSON values only (no nested objects).
   * The X-Total-Documents header carries the total count.
   * @param metadataKey   JSON key to match (e.g. "category")
   * @param metadataValue JSON value to match (e.g. "invoice")
   * @param page          Page number (default: 1)
   * @param pageSize      Documents per page (default: 50, max: 200)
   */
  // getDocumentsByMetadata moved to BaseReactSystemFunctions (RNM-0124): its body was pure transport,
  // so the shared seam owns it and both targets call the same one.

  /**
   * GET /v1/api/documentmanagement/{documentId}/file — Downloads a document to the user's device.
   * Requires at least view permission.
   * @param documentId Required: document GUID
   * @param fileName   Optional: override the filename shown in the browser's save dialog.
   *                   If omitted, uses the filename from the Content-Disposition response header,
   *                   falling back to "document".
   * @param watermark  Optional: if true, the server applies the DMS watermark before streaming.
   *                   Requires watermarkView or higher permission; view-only users are blocked (403).
   */
  public static async downloadDocument(
    screen: any,
    documentId: string,
    versionId?: string,
    fileName?: string,
    watermark?: boolean,
    language?: string,
    convertTo?: string,
    replaceParameters?: TReplaceParametersValue
  ): Promise<void> {
    try {
      const base = KuikaAppManager.GetBackendUrl().replace(/\/$/, "");
      const params = new URLSearchParams();
      if (watermark) params.set("watermark", "true");
      if (convertTo) params.set("convertTo", convertTo);
      ReactSystemFunctions.appendParameterReplacement(
        params,
        ReactSystemFunctions.parameterReplacementFor(screen, replaceParameters)
      );
      const qs = params.toString();
      const pathSegment = versionId
        ? `documentmanagement/versions/${versionId}/file`
        : `documentmanagement/${documentId}/file`;
      const resp = await axios.get(`${base}/${pathSegment}${qs ? `?${qs}` : ""}`, {
        responseType: "blob"
      });

      // Resolve filename: caller prop → Content-Disposition header → fallback
      // RFC 5987: filename*=UTF-8''<percent-encoded> takes priority over filename="<ascii>"
      let resolvedName = fileName?.trim() || undefined;
      if (!resolvedName) {
        const cd: string = resp.headers?.["content-disposition"] ?? "";
        const extMatch = /filename\*=UTF-8''([^;"'\r\n]+)/i.exec(cd);
        const basicMatch = /filename=["']?([^;"'\r\n]+)["']?/i.exec(cd);
        const raw = extMatch?.[1] ?? basicMatch?.[1];
        resolvedName = raw ? decodeURIComponent(raw.trim().replace(/['"]/g, "")) : "document";
      }

      KMainFunctions.downloadFile(resp.data, resolvedName);
    } catch (error) {
      KMainFunctions.exceptionHandler(error);
    }
  }

  /**
   * GET /v1/api/documentmanagement/{documentId}/pdf[?versionId=&language=] — "Download as PDF".
   * Downloads the document converted to PDF whatever its stored format (Office, OpenDocument,
   * RTF, images, plain text; PDFs pass through). Requires at least view permission; a
   * watermarkView user receives the PDF watermarked. Without versionId the latest published
   * version is served — drafts never are.
   * @param documentId        Required: document GUID
   * @param versionId         Optional: a specific version of the document (must belong to it)
   * @param language          Optional: language variant to resolve when versionId is not given
   * @param replaceParameters Optional: true fills the document's <TAG> parameters from the screen's
   *                          Resolve Document Parameters context before conversion (KOA-18476)
   */
  public static async downloadAsPdf(
    screen: any,
    documentId: string,
    versionId?: string,
    language?: string,
    replaceParameters?: TReplaceParametersValue
  ): Promise<void> {
    try {
      const base: string = KuikaAppManager.GetBackendUrl().replace(/\/$/, "");
      const path: string = ReactSystemFunctions.buildDownloadAsPdfPath(
        documentId,
        versionId,
        language,
        ReactSystemFunctions.parameterReplacementFor(screen, replaceParameters)
      );
      const resp = await axios.get(`${base}/${path}`, { responseType: "blob" });
      const contentDisposition: string = resp.headers?.["content-disposition"] ?? "";
      // The server always answers with a PDF, so the fallback extension is not a guess here.
      const fileName: string =
        ReactSystemFunctions.parseContentDispositionFileName(contentDisposition) ?? "document.pdf";
      KMainFunctions.downloadFile(resp.data, fileName);
    } catch (error) {
      KMainFunctions.exceptionHandler(error);
    }
  }

  /**
   * Request path for downloadAsPdf. The query is the shared `documentPdfQuery` — the same one the base64
   * twin (`getAsPdfBase64`, on the shared runtime) sends — so the two routes never drift on how an unbound
   * optional (`""`, KOA-18234) or the parameter-replacement fields reach the wire.
   */
  private static buildDownloadAsPdfPath(
    documentId: string,
    versionId?: string,
    language?: string,
    replacement: IParameterReplacementRequest = {}
  ): string {
    const query: string = ReactSystemFunctions.documentPdfQuery(versionId, language, replacement);
    return `documentmanagement/${encodeURIComponent(documentId)}/pdf${query}`;
  }

  /**
   * POST /v1/api/documentmanagement — Uploads a new document.
   * ⚠️ Maximum 50 MB. Use Chunked Upload for larger files.
   */
  public static async uploadDocument(
    screen: any,
    fileName: string,
    mimeType: string,
    base64Content: string,
    documentName?: string,
    folderId?: string,
    language?: string,
    isDraft?: TOptionalFlagValue,
    documentNumber?: string,
    documentType?: string
  ): Promise<string | null> {
    try {
      const raw = base64Content?.includes(",") ? base64Content.split(",")[1] : base64Content;

      // 50 MB validation — base64 length * 0.75 ≈ actual byte size
      const MAX_BYTES = 50 * 1024 * 1024;
      const estimatedBytes = Math.ceil((raw?.length ?? 0) * 0.75);
      if (estimatedBytes > MAX_BYTES) {
        const mb = Math.round(estimatedBytes / 1024 / 1024);
        throw new Error(
          `File size exceeds the 50 MB limit (estimated: ${mb} MB). Use Chunked Upload for larger files.`
        );
      }

      const bytes = atob(raw);
      const buf = new Uint8Array(bytes.length);
      for (let i = 0; i < bytes.length; i++) buf[i] = bytes.charCodeAt(i);
      const blob = new Blob([buf], { type: mimeType });

      const formData = new FormData();
      formData.append("file", blob, fileName);
      formData.append("documentName", documentName || fileName);
      if (folderId) formData.append("folderId", folderId);
      if (language) formData.append("language", language);
      // A blank optional flag is not supplied, not "" — the [FromForm] bool? binder rejects "" (KOA-18628).
      const draftFlag: boolean | undefined = ReactSystemFunctions.optionalFlag(isDraft);
      if (draftFlag !== undefined) formData.append("isDraft", String(draftFlag));
      if (documentNumber) formData.append("documentNumber", documentNumber);
      if (documentType) formData.append("documentType", documentType);

      return await KuikaAppManager.ApiRequest(screen, "documentmanagement", formData, "post");
    } catch (error) {
      KMainFunctions.exceptionHandler(error);
      return null;
    }
  }

  /** DELETE /v1/api/documentmanagement/{documentId} — Soft delete */
  // deleteDocument moved to BaseReactSystemFunctions (RNM-0124): its body was pure transport,
  // so the shared seam owns it and both targets call the same one.

  /**
   * POST /v1/api/documentmanagement/folders — Creates a new folder.
   * `color` is an optional hex display colour (#RGB / #RRGGBB); empty = default folder colour.
   * @returns axios envelope whose `data` matches CreateResult { folderId }
   */
  // createDocumentFolder moved to BaseReactSystemFunctions (RNM-0124): its body was pure transport,
  // so the shared seam owns it and both targets call the same one.

  /** PUT /v1/api/documentmanagement/{documentId}/move — Moves the document to a folder. folderId=null → root */
  // moveDocument moved to BaseReactSystemFunctions (RNM-0132): the port pipeline fail-closed on it, so it
  // was hand-ported outside the generated block; the shared seam owns it and both targets call it.

  /** PUT /v1/api/documentmanagement/folders/{folderId} — Renames the folder */
  // renameDocumentFolder moved to BaseReactSystemFunctions (RNM-0124): its body was pure transport,
  // so the shared seam owns it and both targets call the same one.

  /**
   * GET /v1/api/documentmanagement/folders/{folderId}/names — Every per-language name of the folder
   * as [{ languageCode, name }], ordered by language code. The default name is not in this list; it
   * comes back as `folderName` from getFolderById. Tree nodes already carry the resolved `name` for
   * the current app language (plus `nameLanguage` / `defaultName`), so this is only for edit dialogs.
   */
  public static async getDocumentFolderNames(screen: any, folderId: string): Promise<any> {
    if (!folderId || folderId === "null" || folderId === "undefined") {
      console.warn("[DMS] getDocumentFolderNames: no folder selected, skipping.");
      return { data: [] };
    }
    try {
      return await KuikaAppManager.ApiRequest(screen, `documentmanagement/folders/${folderId}/names`, undefined, "get");
    } catch (error) {
      KMainFunctions.exceptionHandler(error);
      return { data: [] };
    }
  }

  /**
   * PUT /v1/api/documentmanagement/folders/{folderId}/names/{languageCode} — Sets the folder's name
   * for ONE language (any well-formed tag: "tr", "tr-TR", "de", "zh-Hant-TW"; no fixed list). Other
   * languages are untouched; removing one is removeDocumentFolderName. The Directory element shows
   * the translation to viewers whose app language matches (exact tag first, then the language
   * alone), everyone else keeps seeing the default name.
   */
  public static async setDocumentFolderName(
    screen: any,
    folderId: string,
    languageCode: string,
    name: string
  ): Promise<boolean> {
    if (!folderId || folderId === "null" || folderId === "undefined") {
      console.warn("[DMS] setDocumentFolderName: no folder selected, skipping.");
      return false;
    }
    if (!languageCode || !languageCode.trim()) {
      console.warn("[DMS] setDocumentFolderName: languageCode is required, skipping.");
      return false;
    }
    if (!name || !name.trim()) {
      console.warn(
        "[DMS] setDocumentFolderName: name is required (use removeDocumentFolderName to drop a translation), skipping."
      );
      return false;
    }
    try {
      await KuikaAppManager.ApiRequest(
        screen,
        `documentmanagement/folders/${folderId}/names/${encodeURIComponent(languageCode.trim())}`,
        { name },
        "put"
      );
      return true;
    } catch (error) {
      KMainFunctions.exceptionHandler(error);
      return false;
    }
  }

  /**
   * DELETE /v1/api/documentmanagement/folders/{folderId}/names/{languageCode} — Removes the folder's
   * name for ONE language; viewers of that language fall back to the default name. Succeeds whether
   * or not a translation existed.
   */
  public static async removeDocumentFolderName(screen: any, folderId: string, languageCode: string): Promise<boolean> {
    if (!folderId || folderId === "null" || folderId === "undefined") {
      console.warn("[DMS] removeDocumentFolderName: no folder selected, skipping.");
      return false;
    }
    if (!languageCode || !languageCode.trim()) {
      console.warn("[DMS] removeDocumentFolderName: languageCode is required, skipping.");
      return false;
    }
    try {
      await KuikaAppManager.ApiRequest(
        screen,
        `documentmanagement/folders/${folderId}/names/${encodeURIComponent(languageCode.trim())}`,
        undefined,
        "delete"
      );
      return true;
    } catch (error) {
      KMainFunctions.exceptionHandler(error);
      return false;
    }
  }

  /**
   * PUT /v1/api/documentmanagement/folders/{folderId}/color — Sets the folder's display colour.
   * `color` is hex (#RGB / #RRGGBB, any case); empty/undefined clears it back to the default colour.
   * The Directory element paints the folder icon with the stored colour on the next tree load.
   */
  public static async setDocumentFolderColor(screen: any, folderId: string, color?: string): Promise<boolean> {
    if (!folderId || folderId === "null" || folderId === "undefined") {
      console.warn("[DMS] setDocumentFolderColor: no folder selected, skipping.");
      return false;
    }
    try {
      await KuikaAppManager.ApiRequest(
        screen,
        `documentmanagement/folders/${folderId}/color`,
        { color: color || null },
        "put"
      );
      return true;
    } catch (error) {
      KMainFunctions.exceptionHandler(error);
      return false;
    }
  }

  /**
   * POST /v1/api/documentmanagement/{documentId}/share — Creates a share link.
   * @param expiresInDays  Number of days the link is valid (optional)
   * @returns Axios envelope whose `data` matches ShareLinkResult { url, shareId }
   */
  // createDocumentShareLink moved to BaseReactSystemFunctions (RNM-0132): the port pipeline fail-closed on it, so it
  // was hand-ported outside the generated block; the shared seam owns it and both targets call it.

  /**
   * POST /v1/api/documentmanagement/{documentId}/upload-link — Creates an anonymous upload link
   * with a 6-digit verification code. The recipient enters the code to upload a new version.
   * @param expiresInDays  Number of days the link is valid (optional; backend default applies otherwise)
   * @returns Axios envelope whose `data` matches UploadLinkResult { uploadUrl, uploadLinkId, code, expiresAt }
   */
  public static async createDocumentUploadLink(screen: any, documentId: string, expiresInDays?: number): Promise<any> {
    try {
      const expiresAt = expiresInDays ? new Date(Date.now() + expiresInDays * 24 * 60 * 60 * 1000).toISOString() : null;
      // windowLocationOrigin returns origin + virtualDirectoryURL — i.e. the frontend
      // base URL as deployed (incl. any sub-path). Backend uses this as the link
      // host, since Referer is unreliable behind proxies/CDNs.
      const body: any = {
        expiresAt,
        maxCodeAttempts: null,
        maxUseCount: null,
        clientBaseUrl: KMainFunctions.windowLocationOrigin
      };
      const response: any = await KuikaAppManager.ApiRequest(
        screen,
        `documentmanagement/${documentId}/upload-link`,
        body,
        "post"
      );
      if (response && response.data) {
        response.data = {
          uploadUrl: response.data.uploadUrl,
          uploadLinkId: response.data.id,
          code: response.data.code,
          expiresAt: response.data.expiresAt
        };
      }
      return response;
    } catch (error) {
      KMainFunctions.exceptionHandler(error);
      return { data: { uploadUrl: "", uploadLinkId: "", code: "", expiresAt: null } };
    }
  }

  /**
   * POST /v1/api/documentmanagement/{documentId}/permissions — Grants permission to a user or role.
   * @param principalType  "user" (default) | "role"
   */
  // grantDocumentPermission moved to BaseReactSystemFunctions (RNM-0132): the port pipeline fail-closed on it, so it
  // was hand-ported outside the generated block; the shared seam owns it and both targets call it.

  /** PATCH /v1/api/documentmanagement/{documentId} — Renames the document */
  // renameDocument moved to BaseReactSystemFunctions (RNM-0124): its body was pure transport,
  // so the shared seam owns it and both targets call the same one.

  /**
   * DELETE /v1/api/documentmanagement/{documentId}/permissions/{permissionId}
   * Revokes a permission granted on the document.
   */
  // revokeDocumentPermission moved to BaseReactSystemFunctions (RNM-0124): its body was pure transport,
  // so the shared seam owns it and both targets call the same one.

  /**
   * POST /v1/api/documentmanagement/folders/{folderId}/permissions
   * Grants permission on the folder. permissionLevel: view | edit | manage. principalType: user | role
   */
  // grantFolderPermission moved to BaseReactSystemFunctions (RNM-0124): its body was pure transport,
  // so the shared seam owns it and both targets call the same one.

  /**
   * DELETE /v1/api/documentmanagement/folders/{folderId}/permissions/{permissionId}
   * Revokes a permission granted on the folder.
   */
  // revokeFolderPermission moved to BaseReactSystemFunctions (RNM-0124): its body was pure transport,
  // so the shared seam owns it and both targets call the same one.

  /** POST /v1/api/documentmanagement/{documentId}/archive — Moves the document to the archive */
  // archiveDocument moved to BaseReactSystemFunctions (RNM-0124): its body was pure transport,
  // so the shared seam owns it and both targets call the same one.

  /** POST /v1/api/documentmanagement/{documentId}/unarchive — Removes the document from the archive */
  // unarchiveDocument moved to BaseReactSystemFunctions (RNM-0124): its body was pure transport,
  // so the shared seam owns it and both targets call the same one.

  /** POST /v1/api/documentmanagement/{documentId}/restore — Restores a soft-deleted document */
  // restoreDocument moved to BaseReactSystemFunctions (RNM-0124): its body was pure transport,
  // so the shared seam owns it and both targets call the same one.

  // ── Templates ─────────────────────────────────────────────────────

  // getTemplates moved to BaseReactSystemFunctions (RNM-0124): its body was pure transport,
  // so the shared seam owns it and both targets call the same one.

  // createTemplate moved to BaseReactSystemFunctions (RNM-0124): its body was pure transport,
  // so the shared seam owns it and both targets call the same one.

  // updateTemplate moved to BaseReactSystemFunctions (RNM-0124): its body was pure transport,
  // so the shared seam owns it and both targets call the same one.

  public static async updateTemplateContent(screen: any, templateId: string, base64Content: string): Promise<any> {
    try {
      // Controller route: PUT templates/{templateId}/file with FormFile
      const base = KuikaAppManager.GetBackendUrl().replace(/\/$/, "");
      const blob = base64Content
        ? new Blob([Uint8Array.from(atob(base64Content), (c) => c.charCodeAt(0))])
        : new Blob([]);
      const formData = new FormData();
      formData.append("file", blob, "template.bin");
      const resp = await authFetch(`${base}/documentmanagement/templates/${templateId}/file`, {
        method: "PUT",
        body: formData
      });
      return await resp.json();
    } catch (error) {
      KMainFunctions.exceptionHandler(error);
      return null;
    }
  }

  // deleteTemplate moved to BaseReactSystemFunctions (RNM-0124): its body was pure transport,
  // so the shared seam owns it and both targets call the same one.

  // downloadTemplate moved to BaseReactSystemFunctions (RNM-0124): its body was pure transport,
  // so the shared seam owns it and both targets call the same one.

  // getTemplateCategories moved to BaseReactSystemFunctions (RNM-0124): its body was pure transport,
  // so the shared seam owns it and both targets call the same one.

  // getTemplateMetadata moved to BaseReactSystemFunctions (RNM-0124): its body was pure transport,
  // so the shared seam owns it and both targets call the same one.

  // activateTemplate moved to BaseReactSystemFunctions (RNM-0124): its body was pure transport,
  // so the shared seam owns it and both targets call the same one.

  // deactivateTemplate moved to BaseReactSystemFunctions (RNM-0124): its body was pure transport,
  // so the shared seam owns it and both targets call the same one.

  // createDocumentFromTemplate moved to BaseReactSystemFunctions (RNM-0124): its body was pure transport,
  // so the shared seam owns it and both targets call the same one.

  // ── Tags ─────────────────────────────────────────────────────────

  // addDocumentTag moved to BaseReactSystemFunctions (RNM-0124): its body was pure transport,
  // so the shared seam owns it and both targets call the same one.

  // removeDocumentTag moved to BaseReactSystemFunctions (RNM-0124): its body was pure transport,
  // so the shared seam owns it and both targets call the same one.

  // getDocumentTags moved to BaseReactSystemFunctions (RNM-0124): its body was pure transport,
  // so the shared seam owns it and both targets call the same one.

  // getDocumentsByTag moved to BaseReactSystemFunctions (RNM-0124): its body was pure transport,
  // so the shared seam owns it and both targets call the same one.

  // bulkAddTag moved to BaseReactSystemFunctions (RNM-0101): its body was pure transport, so it now
  // serves both targets from the shared runtime. Inherited — call sites are unchanged.

  // ── Folder Tags ──────────────────────────────────────────────────

  // addFolderTag moved to BaseReactSystemFunctions (RNM-0124): its body was pure transport,
  // so the shared seam owns it and both targets call the same one.

  // removeFolderTag moved to BaseReactSystemFunctions (RNM-0124): its body was pure transport,
  // so the shared seam owns it and both targets call the same one.

  // getFolderTags moved to BaseReactSystemFunctions (RNM-0124): its body was pure transport,
  // so the shared seam owns it and both targets call the same one.

  // getFoldersByTag moved to BaseReactSystemFunctions (RNM-0124): its body was pure transport,
  // so the shared seam owns it and both targets call the same one.

  /** Returns the most-used folder tags (name, group, folderCount). */
  // getFolderTagCloud moved to BaseReactSystemFunctions (RNM-0124): its body was pure transport,
  // so the shared seam owns it and both targets call the same one.

  // ── Versioning & Drafts ──────────────────────────────────────────

  // createVersion moved to BaseReactSystemFunctions (RNM-0124): its body was pure transport,
  // so the shared seam owns it and both targets call the same one.

  // getVersionDetails moved to BaseReactSystemFunctions (RNM-0124): its body was pure transport,
  // so the shared seam owns it and both targets call the same one.

  // downloadVersion moved to BaseReactSystemFunctions (RNM-0124): its body was pure transport,
  // so the shared seam owns it and both targets call the same one.

  /**
   * Updates document properties (name, type, number, metadata) in a single call.
   * Only provided fields are updated — null/undefined fields are left unchanged.
   */
  // updateDocument moved to BaseReactSystemFunctions (RNM-0124): its body was pure transport,
  // so the shared seam owns it and both targets call the same one.

  // getVersionLanguages moved to BaseReactSystemFunctions (RNM-0124): its body was pure transport,
  // so the shared seam owns it and both targets call the same one.

  // addLanguageVariant moved to BaseReactSystemFunctions (RNM-0124): its body was pure transport,
  // so the shared seam owns it and both targets call the same one.

  // setVersionLanguage moved to BaseReactSystemFunctions (RNM-0124): its body was pure transport,
  // so the shared seam owns it and both targets call the same one.

  // createDraft moved to BaseReactSystemFunctions (RNM-0124): its body was pure transport,
  // so the shared seam owns it and both targets call the same one.

  public static async updateDraft(
    screen: any,
    versionId: string,
    base64Content: string,
    changeNote?: string
  ): Promise<any> {
    try {
      const base = KuikaAppManager.GetBackendUrl().replace(/\/$/, "");
      const blob = base64Content
        ? new Blob([Uint8Array.from(atob(base64Content), (c) => c.charCodeAt(0))])
        : new Blob([]);
      const formData = new FormData();
      formData.append("file", blob, "document.bin");
      if (changeNote) formData.append("changeNote", changeNote);
      const resp = await authFetch(`${base}/documentmanagement/versions/${versionId}/content`, {
        method: "PUT",
        body: formData
      });
      return await resp.json();
    } catch (error) {
      KMainFunctions.exceptionHandler(error);
      return null;
    }
  }

  // publishDraft moved to BaseReactSystemFunctions (RNM-0124): its body was pure transport,
  // so the shared seam owns it and both targets call the same one. The commitTempFirst option
  // from master (KOA-18243) is carried on the shared publishDraft in base-react-system-functions.ts.

  // discardDraft moved to BaseReactSystemFunctions (RNM-0124): its body was pure transport,
  // so the shared seam owns it and both targets call the same one.

  // getDrafts moved to BaseReactSystemFunctions (RNM-0124): its body was pure transport,
  // so the shared seam owns it and both targets call the same one.

  // ── Bulk Operations ──────────────────────────────────────────────

  /** Moves all documents in folderId (and subfolders) to targetFolderId. Returns affected count. */
  // bulkMoveDocuments moved to BaseReactSystemFunctions (RNM-0124): its body was pure transport,
  // so the shared seam owns it and both targets call the same one.

  /** Soft-deletes all documents in folderId (and subfolders). Returns affected count. */
  // bulkDeleteDocuments moved to BaseReactSystemFunctions (RNM-0124): its body was pure transport,
  // so the shared seam owns it and both targets call the same one.

  /** Archives all documents in folderId (and subfolders). Returns affected count. */
  // bulkArchiveDocuments moved to BaseReactSystemFunctions (RNM-0124): its body was pure transport,
  // so the shared seam owns it and both targets call the same one.

  // ── Relations ────────────────────────────────────────────────────

  // linkDocuments moved to BaseReactSystemFunctions (RNM-0124): its body was pure transport,
  // so the shared seam owns it and both targets call the same one.

  // unlinkDocuments moved to BaseReactSystemFunctions (RNM-0124): its body was pure transport,
  // so the shared seam owns it and both targets call the same one.

  // getRelatedDocuments moved to BaseReactSystemFunctions (RNM-0124): its body was pure transport,
  // so the shared seam owns it and both targets call the same one.

  // ── Comments ─────────────────────────────────────────────────────

  // getDocumentComments moved to BaseReactSystemFunctions (RNM-0124): its body was pure transport,
  // so the shared seam owns it and both targets call the same one.

  // getDocumentCommentCount moved to BaseReactSystemFunctions (RNM-0124): its body was pure transport,
  // so the shared seam owns it and both targets call the same one.

  // ── Document Parameters ──────────────────────────────────────────

  /**
   * Resolves the document parameters configured in Project Settings and returns a signed parameter
   * context (KOA-17254).
   *
   * `inputs` carries only the supplying actions' INPUTS — a company id, say — keyed by
   * `{ActionName}__{inputName}`. It deliberately never carries values: the backend runs the queries
   * itself, so a caller cannot have a value of their choosing signed into a document.
   *
   * The returned `parameterContext` is published on the screen. The Document element fills the `<TAG>`
   * parameters from it on every view; the delivery actions (download, print, base64, watermarked copy) fill
   * them only when their optional `replaceParameters` is true, because a download with the tags intact is a
   * legitimate ask too. On failure the context is empty rather than absent, which leaves tags literal and
   * visible instead of substituting values of unknown origin.
   */
  /**
   * Signs the document parameter inputs this screen supplies, and publishes the signed context on the screen so
   * every document consumer on it picks the context up on its own.
   *
   * No document is named here on purpose. The viewer, the download and the materialize paths each resolve for the
   * document they are opening, using only the tags that document contains — so a screen supplies its inputs once and
   * never has to trigger resolution per document. Values are never sent, only inputs.
   *
   * Publishing is what removes the last manual step. The context used to be bound by hand from this action's result
   * to each document's `parameterContext` property; that binding has exactly one correct answer, so making it manual
   * only created a step to forget, and forgetting it rendered the document with its `<TAG>` parameters showing. The
   * property remains as an override for the case ambient cannot express: two documents on one screen resolved for
   * two different subjects.
   */
  public static async resolveDocumentParameters(screen: any, inputs: Record<string, string>): Promise<any> {
    try {
      const response = await KuikaAppManager.ApiRequest(
        screen,
        "documentmanagement/parameters/resolve",
        { inputs: inputs ?? {} },
        "post"
      );
      setAmbientParameterContext(screen, response?.data?.parameterContext);
      return response?.data;
    } catch (error) {
      KMainFunctions.exceptionHandler(error);
      // Cleared, not left stale: a failed resolve must not leave a previous subject's context in place for the
      // documents on this screen to render with.
      setAmbientParameterContext(screen, undefined);
      return { parameterContext: "", resolvedCount: 0, unresolvedCount: 0 };
    }
  }

  // ── Thumbnail ────────────────────────────────────────────────────

  // getDocumentThumbnail moved to BaseReactSystemFunctions (RNM-0124): its body was pure transport,
  // so the shared seam owns it and both targets call the same one.

  // setDocumentThumbnail moved to BaseReactSystemFunctions (RNM-0124): its body was pure transport,
  // so the shared seam owns it and both targets call the same one.

  // ── Document Number ──────────────────────────────────────────────

  // setDocumentNumber moved to BaseReactSystemFunctions (RNM-0124): its body was pure transport,
  // so the shared seam owns it and both targets call the same one.

  // ── Compare ──────────────────────────────────────────────────────

  /** Compare two versions. Returns structured diff result. */
  public static async compareVersions(
    screen: any,
    leftVersionId: string,
    rightVersionId: string,
    docxEngine?: string,
    xlsxEngine?: string,
    pdfEngine?: string,
    pptxEngine?: string,
    textEngine?: string
  ): Promise<any> {
    try {
      const body: any = { leftVersionId, rightVersionId };
      if (docxEngine) body.docxEngine = docxEngine;
      if (xlsxEngine) body.xlsxEngine = xlsxEngine;
      if (pdfEngine) body.pdfEngine = pdfEngine;
      if (pptxEngine) body.pptxEngine = pptxEngine;
      if (textEngine) body.textEngine = textEngine;
      return await KuikaAppManager.ApiRequest(screen, "documentmanagement/compare", body, "post");
    } catch (error) {
      KMainFunctions.exceptionHandler(error);
      return null;
    }
  }

  /** Compare two versions and return as downloadable file. */
  public static async compareVersionsAsFile(
    screen: any,
    leftVersionId: string,
    rightVersionId: string,
    docxEngine?: string,
    xlsxEngine?: string,
    pdfEngine?: string,
    pptxEngine?: string,
    textEngine?: string
  ): Promise<any> {
    try {
      const body: any = { leftVersionId, rightVersionId };
      if (docxEngine) body.docxEngine = docxEngine;
      if (xlsxEngine) body.xlsxEngine = xlsxEngine;
      if (pdfEngine) body.pdfEngine = pdfEngine;
      if (pptxEngine) body.pptxEngine = pptxEngine;
      if (textEngine) body.textEngine = textEngine;
      return await KuikaAppManager.ApiRequest(screen, "documentmanagement/compare/as-file", body, "post");
    } catch (error) {
      KMainFunctions.exceptionHandler(error);
      return null;
    }
  }

  // ── Indexing ─────────────────────────────────────────────────────

  // searchDocumentContent moved to BaseReactSystemFunctions (RNM-0124): its body was pure transport,
  // so the shared seam owns it and both targets call the same one.

  // indexUnindexedDocuments moved to BaseReactSystemFunctions (RNM-0124): its body was pure transport,
  // so the shared seam owns it and both targets call the same one.

  // reindexDocument moved to BaseReactSystemFunctions (RNM-0132): the port pipeline fail-closed on it, so it
  // was hand-ported outside the generated block; the shared seam owns it and both targets call it.

  // ── Generic Search Engine ────────────────────────────────────────

  // indexSearchRecord moved to BaseReactSystemFunctions (RNM-0124): its body was pure transport,
  // so the shared seam owns it and both targets call the same one.

  // searchRecords moved to BaseReactSystemFunctions (RNM-0124): its body was pure transport,
  // so the shared seam owns it and both targets call the same one.

  // deleteSearchRecord moved to BaseReactSystemFunctions (RNM-0124): its body was pure transport,
  // so the shared seam owns it and both targets call the same one.

  // deleteSearchIndex moved to BaseReactSystemFunctions (RNM-0124): its body was pure transport,
  // so the shared seam owns it and both targets call the same one.

  // getSearchIndexStats moved to BaseReactSystemFunctions (RNM-0124): its body was pure transport,
  // so the shared seam owns it and both targets call the same one.

  // getSearchEngineHealth moved to BaseReactSystemFunctions (RNM-0124): its body was pure transport,
  // so the shared seam owns it and both targets call the same one.

  // bulkIndexSearchRecords moved to BaseReactSystemFunctions (RNM-0124): its body was pure transport,
  // so the shared seam owns it and both targets call the same one.

  // unifiedSearch moved to BaseReactSystemFunctions (RNM-0124): its body was pure transport,
  // so the shared seam owns it and both targets call the same one.

  // ── Rollback ──────────────────────────────────────────────────────

  // rollbackToVersion moved to BaseReactSystemFunctions (RNM-0124): its body was pure transport,
  // so the shared seam owns it and both targets call the same one.

  // ── Base64 Content ────────────────────────────────────────────────

  /** Returns document content as base64 JSON: { base64Content, mimeType, fileName, contentSize } */
  public static async getDocumentAsBase64(
    screen: any,
    documentId: string,
    language?: string,
    replaceParameters?: TReplaceParametersValue
  ): Promise<any> {
    try {
      const params = new URLSearchParams();
      if (language) params.set("language", language);
      ReactSystemFunctions.appendParameterReplacement(
        params,
        ReactSystemFunctions.parameterReplacementFor(screen, replaceParameters)
      );
      const qs = params.toString();
      const url = qs ? `documentmanagement/${documentId}/base64?${qs}` : `documentmanagement/${documentId}/base64`;
      return await KuikaAppManager.ApiRequest(screen, url, undefined, "get");
    } catch (error) {
      KMainFunctions.exceptionHandler(error);
      return null;
    }
  }

  /** Returns specific version content as base64 JSON: { base64Content, mimeType, fileName, versionId, version, language, contentSize } */
  // getVersionBase64 moved to BaseReactSystemFunctions (RNM-0124): its body was pure transport,
  // so the shared seam owns it and both targets call the same one.

  // ── Trash / Recycle Bin ──────────────────────────────────────────

  // getDeletedDocuments moved to BaseReactSystemFunctions (RNM-0124): its body was pure transport,
  // so the shared seam owns it and both targets call the same one.

  // permanentDeleteDocument moved to BaseReactSystemFunctions (RNM-0124): its body was pure transport,
  // so the shared seam owns it and both targets call the same one.

  // ── Bulk Download ────────────────────────────────────────────────

  /** Downloads all documents in folderId (and subfolders) as a ZIP. */
  public static async bulkDownloadDocuments(screen: any, folderId: string, language?: string): Promise<void> {
    try {
      const base = KuikaAppManager.GetBackendUrl().replace(/\/$/, "");
      const reqBody: any = { folderId };
      if (language) reqBody.language = language;
      const response = await authFetch(`${base}/documentmanagement/bulk/download`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(reqBody)
      });
      if (!response.ok) throw new Error(`Download failed: ${response.status}`);
      const blob = await response.blob();
      const url = URL.createObjectURL(blob);
      const a = document.createElement("a");
      a.href = url;
      a.download = "documents.zip";
      a.click();
      URL.revokeObjectURL(url);
    } catch (error) {
      KMainFunctions.exceptionHandler(error);
    }
  }

  // ── Format Conversion ────────────────────────────────────────────

  public static async convertDocument(
    screen: any,
    documentId: string,
    versionId?: string,
    targetFormat: string = "pdf",
    language?: string,
    returnAsBase64?: boolean
  ): Promise<void> {
    try {
      const base = KuikaAppManager.GetBackendUrl().replace(/\/$/, "");
      const params = new URLSearchParams();
      params.set("targetFormat", targetFormat);
      if (returnAsBase64 !== undefined) params.set("returnAsBase64", String(returnAsBase64));
      const response = await authFetch(`${base}/documentmanagement/${documentId}/convert?${params.toString()}`);
      if (!response.ok) throw new Error(`Conversion failed: ${response.status}`);
      const blob = await response.blob();
      const disposition = response.headers.get("content-disposition");
      const filename = disposition?.match(/filename="?([^"]+)"?/)?.[1] || `document.${targetFormat}`;
      const url = URL.createObjectURL(blob);
      const a = document.createElement("a");
      a.href = url;
      a.download = filename;
      a.click();
      URL.revokeObjectURL(url);
    } catch (error) {
      KMainFunctions.exceptionHandler(error);
    }
  }

  // ── Auto Document Number ─────────────────────────────────────────

  // generateDocumentNumber moved to BaseReactSystemFunctions (RNM-0124): its body was pure transport,
  // so the shared seam owns it and both targets call the same one.

  // ── Dashboard / Reporting ────────────────────────────────────────

  // getDocumentStatusSummary moved to BaseReactSystemFunctions (RNM-0124): its body was pure transport,
  // so the shared seam owns it and both targets call the same one.

  // getStorageGrowth moved to BaseReactSystemFunctions (RNM-0124): its body was pure transport,
  // so the shared seam owns it and both targets call the same one.

  // getStorageByMimeType moved to BaseReactSystemFunctions (RNM-0124): its body was pure transport,
  // so the shared seam owns it and both targets call the same one.

  // getActivityTimeline moved to BaseReactSystemFunctions (RNM-0124): its body was pure transport,
  // so the shared seam owns it and both targets call the same one.

  // getGlobalActivitySummary moved to BaseReactSystemFunctions (RNM-0124): its body was pure transport,
  // so the shared seam owns it and both targets call the same one.

  // getTopActiveUsers moved to BaseReactSystemFunctions (RNM-0124): its body was pure transport,
  // so the shared seam owns it and both targets call the same one.

  // getAllDraftDocuments moved to BaseReactSystemFunctions (RNM-0124): its body was pure transport,
  // so the shared seam owns it and both targets call the same one.

  // getAllCheckedOutDocuments moved to BaseReactSystemFunctions (RNM-0124): its body was pure transport,
  // so the shared seam owns it and both targets call the same one.

  // getExpiringShareLinks moved to BaseReactSystemFunctions (RNM-0124): its body was pure transport,
  // so the shared seam owns it and both targets call the same one.

  // getVersionStatistics moved to BaseReactSystemFunctions (RNM-0124): its body was pure transport,
  // so the shared seam owns it and both targets call the same one.

  // getDocumentIndexingStatus moved to BaseReactSystemFunctions (RNM-0124): its body was pure transport,
  // so the shared seam owns it and both targets call the same one.

  // getLargestDocuments moved to BaseReactSystemFunctions (RNM-0124): its body was pure transport,
  // so the shared seam owns it and both targets call the same one.

  // getOldestUnmodifiedDocuments moved to BaseReactSystemFunctions (RNM-0124): its body was pure transport,
  // so the shared seam owns it and both targets call the same one.

  // ── Compliance & Security Reports ────────────────────────────────

  // getPermissionReport moved to BaseReactSystemFunctions (RNM-0124): its body was pure transport,
  // so the shared seam owns it and both targets call the same one.

  // getAnonymousAccessReport moved to BaseReactSystemFunctions (RNM-0124): its body was pure transport,
  // so the shared seam owns it and both targets call the same one.

  // getFailedAccessAttempts moved to BaseReactSystemFunctions (RNM-0124): its body was pure transport,
  // so the shared seam owns it and both targets call the same one.

  // ── User & Folder Reports ──────────────────────────────────────

  // getUserStorageReport moved to BaseReactSystemFunctions (RNM-0124): its body was pure transport,
  // so the shared seam owns it and both targets call the same one.

  // getMyActivitySummary moved to BaseReactSystemFunctions (RNM-0124): its body was pure transport,
  // so the shared seam owns it and both targets call the same one.

  // getEmptyFolders moved to BaseReactSystemFunctions (RNM-0124): its body was pure transport,
  // so the shared seam owns it and both targets call the same one.

  // ── Tag & Type Reports ─────────────────────────────────────────

  // getTagCloud moved to BaseReactSystemFunctions (RNM-0124): its body was pure transport,
  // so the shared seam owns it and both targets call the same one.

  // getDocumentsByType moved to BaseReactSystemFunctions (RNM-0124): its body was pure transport,
  // so the shared seam owns it and both targets call the same one.

  // ── Temp (Auto-Save Buffer) ─────────────────────────────────────

  // ── Temp Actions — all versionId-first ───────────────────────

  /** Save base64 content to temp buffer. For custom editors or programmatic content. */
  // saveBase64ToTemp moved to BaseReactSystemFunctions (RNM-0124): its body was pure transport,
  // so the shared seam owns it and both targets call the same one.

  /** Trigger OnlyOffice to save current editor content to temp via Command Service. */
  // saveEditorToTemp moved to BaseReactSystemFunctions (RNM-0124): its body was pure transport,
  // so the shared seam owns it and both targets call the same one.

  /** Check if a temp buffer exists for a version. Returns { exists, tempId, lastSavedAt, ... } */
  // getTempStatus moved to BaseReactSystemFunctions (RNM-0124): its body was pure transport,
  // so the shared seam owns it and both targets call the same one.

  /** Get temp content as base64. Returns { base64Content, sourceVersionId, lastSavedAt } */
  // getTempContent moved to BaseReactSystemFunctions (RNM-0124): its body was pure transport,
  // so the shared seam owns it and both targets call the same one.

  /** Discard (delete) temp buffer for a version. */
  // discardTemp moved to BaseReactSystemFunctions (RNM-0124): its body was pure transport,
  // so the shared seam owns it and both targets call the same one.

  /** Publish temp as a new version. Returns { versionId } */
  // publishTempAsNewVersion moved to BaseReactSystemFunctions (RNM-0124): its body was pure transport,
  // so the shared seam owns it and both targets call the same one.

  /** Save temp as draft. Returns { draftId } */
  // saveTempAsDraft moved to BaseReactSystemFunctions (RNM-0124): its body was pure transport,
  // so the shared seam owns it and both targets call the same one.

  // ── Version-first operations (resolve documentId from versionId) ──

  /** Check out document by versionId. Backend resolves documentId. */
  // checkOut moved to BaseReactSystemFunctions (RNM-0124): its body was pure transport,
  // so the shared seam owns it and both targets call the same one.

  /** Undo check out by versionId. */
  // undoCheckOut moved to BaseReactSystemFunctions (RNM-0124): its body was pure transport,
  // so the shared seam owns it and both targets call the same one.

  /** Get checkout status by versionId. Returns { isCheckedOut, checkedOutBy, expiresAt } */
  // getCheckOutStatus moved to BaseReactSystemFunctions (RNM-0124): its body was pure transport,
  // so the shared seam owns it and both targets call the same one.

  /** Convert version to target format. Returns { base64Content, mimeType, fileName } or triggers download. */
  // convertVersion removed — unreliable format conversion, use platform's existing PDF/print tools instead

  /** Print version — fetches file and opens browser print dialog. */
  public static async printVersion(
    screen: any,
    versionId: string,
    convertTo?: string,
    replaceParameters?: TReplaceParametersValue
  ): Promise<void> {
    try {
      const base = KuikaAppManager.GetBackendUrl().replace(/\/$/, "");
      const params = new URLSearchParams();
      if (convertTo) params.set("convertTo", convertTo);
      ReactSystemFunctions.appendParameterReplacement(
        params,
        ReactSystemFunctions.parameterReplacementFor(screen, replaceParameters)
      );
      const qs: string = params.toString();
      const resp = await axios.get(`${base}/documentmanagement/versions/${versionId}/print${qs ? `?${qs}` : ""}`, {
        responseType: "blob"
      });
      const blobUrl = URL.createObjectURL(resp.data);
      const iframe = document.createElement("iframe");
      iframe.style.display = "none";
      iframe.src = blobUrl;
      document.body.appendChild(iframe);
      iframe.onload = () => {
        iframe.contentWindow?.print();
        setTimeout(() => {
          document.body.removeChild(iframe);
          URL.revokeObjectURL(blobUrl);
        }, 5000);
      };
    } catch (error) {
      KMainFunctions.exceptionHandler(error);
    }
  }

  /** Download controlled copy (watermarked) by versionId. */
  public static async downloadWatermarked(
    screen: any,
    versionId: string,
    watermarkText?: TWatermarkParamValue,
    watermarkFontSize?: TWatermarkParamValue,
    watermarkColor?: TWatermarkParamValue,
    watermarkOpacity?: TWatermarkParamValue,
    watermarkPosition?: TWatermarkParamValue,
    watermarkOrientation?: TWatermarkParamValue,
    watermarkDensity?: TWatermarkParamValue,
    replaceParameters?: TReplaceParametersValue
  ): Promise<void> {
    try {
      const base = KuikaAppManager.GetBackendUrl().replace(/\/$/, "");
      const body: TControlledCopyRequestBody = {
        ...buildWatermarkBody({
          watermarkText,
          watermarkFontSize,
          watermarkColor,
          watermarkOpacity,
          watermarkPosition,
          watermarkOrientation,
          watermarkDensity
        }),
        ...ReactSystemFunctions.parameterReplacementFor(screen, replaceParameters)
      };
      const resp = await axios.post(`${base}/documentmanagement/versions/${versionId}/controlled-copy/download`, body, {
        responseType: "blob"
      });
      const contentDisposition: string = resp.headers?.["content-disposition"] ?? "";
      const parsedFileName: string | null = ReactSystemFunctions.parseContentDispositionFileName(contentDisposition);
      // The server streams the watermarked file in its ORIGINAL format (a docx stays a
      // docx) — never assume an extension. When Content-Disposition is unreadable,
      // derive the extension from the response MIME type; a wrong hardcoded extension
      // produces a file the OS cannot open (KOA-18234: docx saved as controlled-copy.pdf).
      const blobMimeType: string = (resp.data as Blob)?.type ?? "";
      const fileName: string =
        parsedFileName ?? `controlled-copy${ReactSystemFunctions.extensionForMimeType(blobMimeType)}`;
      KMainFunctions.downloadFile(resp.data, fileName);
    } catch (error) {
      KMainFunctions.exceptionHandler(error);
    }
  }

  /** Parses the file name out of a Content-Disposition header. Prefers the RFC 5987
   *  `filename*=UTF-8''…` form (correct for non-ASCII names), falls back to `filename=`. */
  private static parseContentDispositionFileName(contentDisposition: string): string | null {
    const utf8Match: RegExpExecArray | null = /filename\*=UTF-8''([^;\r\n]+)/i.exec(contentDisposition);
    if (utf8Match?.[1]) {
      try {
        return decodeURIComponent(utf8Match[1]);
      } catch {
        // malformed percent-encoding — fall through to the plain form
      }
    }
    const plainMatch: RegExpExecArray | null = /filename=["']?([^;"'\r\n]+)["']?/i.exec(contentDisposition);
    return plainMatch?.[1] ?? null;
  }

  /** Maps a response MIME type to a download extension. Empty string when unknown —
   *  a missing extension beats a wrong one. */
  private static extensionForMimeType(mimeType: string): string {
    const knownExtensions: Record<string, string> = {
      "application/pdf": ".pdf",
      "application/vnd.openxmlformats-officedocument.wordprocessingml.document": ".docx",
      "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet": ".xlsx",
      "application/vnd.openxmlformats-officedocument.presentationml.presentation": ".pptx",
      "text/html": ".html",
      "text/plain": ".txt",
      "text/csv": ".csv",
      "text/markdown": ".md",
      "application/json": ".json"
    };
    const normalized: string = mimeType.split(";")[0].trim().toLowerCase();
    return knownExtensions[normalized] ?? "";
  }

  /** Get controlled copy as base64 by versionId. Returns { base64, mimeType, fileName } */
  // getWatermarkedBase64 moved to BaseReactSystemFunctions (RNM-0124): its body was pure transport,
  // so the shared seam owns it and both targets call the same one.

  // ── Checkout (versionId-first) ────────────────────────────────────

  /** Renew checkout lock. Only the user who checked out can renew. */
  // renewCheckOut moved to BaseReactSystemFunctions (RNM-0124): its body was pure transport,
  // so the shared seam owns it and both targets call the same one.

  /** ADMIN: Force release checkout lock regardless of who checked out. */
  // forceUndoCheckOut moved to BaseReactSystemFunctions (RNM-0124): its body was pure transport,
  // so the shared seam owns it and both targets call the same one.

  /** Check in document with new content. Releases lock, creates version or draft. */
  // checkIn moved to BaseReactSystemFunctions (RNM-0124): its body was pure transport,
  // so the shared seam owns it and both targets call the same one.

  // ── Combined Actions (forcesave + commit in one call) ────────────

  /** Editor → temp → new version. Returns { versionId } */
  // publishEditorAsNewVersion moved to BaseReactSystemFunctions (RNM-0124): its body was pure transport,
  // so the shared seam owns it and both targets call the same one.

  /** Editor → temp → draft. Returns { draftId } */
  // saveEditorAsDraft moved to BaseReactSystemFunctions (RNM-0124): its body was pure transport,
  // so the shared seam owns it and both targets call the same one.

  /** Editor → overwrite same version (ADMIN ONLY). Returns { versionId, overwritten } */
  // overwriteVersionFromEditor moved to BaseReactSystemFunctions (RNM-0124): its body was pure transport,
  // so the shared seam owns it and both targets call the same one.

  /** Base64 → new version. Returns { versionId } */
  // publishBase64AsNewVersion moved to BaseReactSystemFunctions (RNM-0124): its body was pure transport,
  // so the shared seam owns it and both targets call the same one.

  /** Base64 → draft. Returns { draftId } */
  // saveBase64AsDraft moved to BaseReactSystemFunctions (RNM-0124): its body was pure transport,
  // so the shared seam owns it and both targets call the same one.

  /** Base64 → overwrite same version (ADMIN ONLY). Returns { versionId, overwritten } */
  // overwriteVersionFromBase64 moved to BaseReactSystemFunctions (RNM-0124): its body was pure transport,
  // so the shared seam owns it and both targets call the same one.

  /** Compare temp content with original version. Returns { originalSize, tempSize, hasChanges } */
  public static async compareWithTemp(screen: any, versionId: string): Promise<any> {
    try {
      return await KuikaAppManager.ApiRequest(
        screen,
        `documentmanagement/temp/compare?versionId=${versionId}`,
        undefined,
        "post"
      );
    } catch (error) {
      KMainFunctions.exceptionHandler(error);
      return null;
    }
  }

  // ── Audit Admin ─────────────────────────────────────────────────

  // getAuditLogStats moved to BaseReactSystemFunctions (RNM-0124): its body was pure transport,
  // so the shared seam owns it and both targets call the same one.

  // exportAuditLogsCsv moved to BaseReactSystemFunctions (RNM-0124): its body was pure transport,
  // so the shared seam owns it and both targets call the same one.

  // purgeAuditLogs moved to BaseReactSystemFunctions (RNM-0124): its body was pure transport,
  // so the shared seam owns it and both targets call the same one.

  // ── Force / Admin Operations ────────────────────────��───────────

  // transferOwnership moved to BaseReactSystemFunctions (RNM-0124): its body was pure transport,
  // so the shared seam owns it and both targets call the same one.

  // permanentDeleteDraft moved to BaseReactSystemFunctions (RNM-0124): its body was pure transport,
  // so the shared seam owns it and both targets call the same one.

  /** Force-releases checkout locks on all documents in folderId (and subfolders). Returns affected count. */
  // bulkForceUndoCheckOut moved to BaseReactSystemFunctions (RNM-0124): its body was pure transport,
  // so the shared seam owns it and both targets call the same one.

  /** Permanently deletes all documents in folderId (and subfolders). Returns affected count. */
  // bulkPermanentDelete moved to BaseReactSystemFunctions (RNM-0124): its body was pure transport,
  // so the shared seam owns it and both targets call the same one.

  /** Unarchives all documents in folderId (and subfolders). Returns affected count. */
  // bulkUnarchiveDocuments moved to BaseReactSystemFunctions (RNM-0124): its body was pure transport,
  // so the shared seam owns it and both targets call the same one.

  /** Restores all soft-deleted documents in folderId (and subfolders). Returns affected count. */
  // bulkRestoreDocuments moved to BaseReactSystemFunctions (RNM-0124): its body was pure transport,
  // so the shared seam owns it and both targets call the same one.

  /** Removes a tag from all documents in folderId (and subfolders). Returns affected count. */
  // bulkRemoveTag moved to BaseReactSystemFunctions (RNM-0124): its body was pure transport,
  // so the shared seam owns it and both targets call the same one.

  /** Sets a single metadata key-value pair on all documents in folderId (and subfolders). Returns affected count. */
  // bulkSetMetadata moved to BaseReactSystemFunctions (RNM-0124): its body was pure transport,
  // so the shared seam owns it and both targets call the same one.

  /** Sets the document type on all documents in folderId (and subfolders). Returns affected count. */
  // bulkSetDocumentType moved to BaseReactSystemFunctions (RNM-0124): its body was pure transport,
  // so the shared seam owns it and both targets call the same one.

  /** Transfers ownership of all documents in folderId (and subfolders) to newOwnerId. Returns affected count. */
  // bulkTransferOwnership moved to BaseReactSystemFunctions (RNM-0124): its body was pure transport,
  // so the shared seam owns it and both targets call the same one.

  // restoreFolder moved to BaseReactSystemFunctions (RNM-0124): its body was pure transport,
  // so the shared seam owns it and both targets call the same one.

  /**
   * Creates a new blank document with a valid skeleton file for the given MIME type.
   * Office formats (docx/xlsx/pptx) get minimal valid OOXML so they open correctly in editors.
   * @param mimeType - MIME type (default: docx). Supported: docx, xlsx, pptx, txt, md, html, json, xml.
   * @param isDraft - true (default) = draft, false = published.
   */
  // createBlankDocument moved to BaseReactSystemFunctions (RNM-0124): its body was pure transport,
  // so the shared seam owns it and both targets call the same one.

  // emptyTrash moved to BaseReactSystemFunctions (RNM-0124): its body was pure transport,
  // so the shared seam owns it and both targets call the same one.

  // ── My Checked Out ─────────────────────────────────────────────

  // getMyCheckedOutDocuments moved to BaseReactSystemFunctions (RNM-0124): its body was pure transport,
  // so the shared seam owns it and both targets call the same one.

  /**
   * GET /v1/api/documentmanagement/versions/{versionId}/document-info
   * Resolves a versionId to its parent document and returns document metadata.
   */
  // getDocumentByVersionId moved to BaseReactSystemFunctions (RNM-0124): its body was pure transport,
  // so the shared seam owns it and both targets call the same one.

  // ── Navigation / Lookup ─────────────────────────────────────────

  // getParentFolderId moved to BaseReactSystemFunctions (RNM-0124): its body was pure transport,
  // so the shared seam owns it and both targets call the same one.

  // getDocumentFolderId moved to BaseReactSystemFunctions (RNM-0124): its body was pure transport,
  // so the shared seam owns it and both targets call the same one.

  /**
   * GET /v1/api/documentmanagement/{documentId}/current-version-id[?language=tr]
   * Returns the versionId of the latest published version. When language is provided,
   * returns the specific language variant. Use to resolve a versionId before SetValueOf on Document element.
   */
  // getLatestVersionId moved to BaseReactSystemFunctions (RNM-0124): its body was pure transport,
  // so the shared seam owns it and both targets call the same one.

  // getFolderPath moved to BaseReactSystemFunctions (RNM-0124): its body was pure transport,
  // so the shared seam owns it and both targets call the same one.

  // getFolderById moved to BaseReactSystemFunctions (RNM-0124): its body was pure transport,
  // so the shared seam owns it and both targets call the same one.

  // getDocumentCount moved to BaseReactSystemFunctions (RNM-0124): its body was pure transport,
  // so the shared seam owns it and both targets call the same one.

  // getFolderCount moved to BaseReactSystemFunctions (RNM-0124): its body was pure transport,
  // so the shared seam owns it and both targets call the same one.

  // documentExists moved to BaseReactSystemFunctions (RNM-0124): its body was pure transport,
  // so the shared seam owns it and both targets call the same one.

  // folderExists moved to BaseReactSystemFunctions (RNM-0124): its body was pure transport,
  // so the shared seam owns it and both targets call the same one.

  // getDocumentIdByNumber moved to BaseReactSystemFunctions (RNM-0124): its body was pure transport,
  // so the shared seam owns it and both targets call the same one.

  // ── Print & Controlled Copy ──────────────────────────────────────

  /**
   * GET document as blob and open the browser print dialog via a hidden iframe.
   * Optionally convert to another format, apply watermark, or select a specific version/language.
   */
  public static async printDocument(
    screen: any,
    documentId: string,
    versionId?: string,
    language?: string,
    convertTo?: string,
    watermark?: boolean,
    replaceParameters?: TReplaceParametersValue
  ): Promise<void> {
    try {
      const base = KuikaAppManager.GetBackendUrl().replace(/\/$/, "");
      const params = new URLSearchParams();
      if (convertTo) params.set("convertTo", convertTo);
      if (watermark) params.set("watermark", "true");
      ReactSystemFunctions.appendParameterReplacement(
        params,
        ReactSystemFunctions.parameterReplacementFor(screen, replaceParameters)
      );
      const qs = params.toString();
      const pathSegment = versionId
        ? `documentmanagement/versions/${versionId}/file`
        : `documentmanagement/${documentId}/file`;
      const resp = await axios.get(`${base}/${pathSegment}${qs ? `?${qs}` : ""}`, {
        responseType: "blob"
      });

      const blob: Blob = resp.data;
      const blobUrl = URL.createObjectURL(blob);
      const iframe = document.createElement("iframe");
      iframe.style.display = "none";
      iframe.src = blobUrl;
      document.body.appendChild(iframe);
      iframe.onload = () => {
        try {
          iframe.contentWindow?.print();
        } finally {
          setTimeout(() => {
            document.body.removeChild(iframe);
            URL.revokeObjectURL(blobUrl);
          }, 1000);
        }
      };
    } catch (error) {
      KMainFunctions.exceptionHandler(error);
    }
  }

  /**
   * POST watermark params, download the controlled copy as a file.
   * Endpoint: /documentmanagement/{documentId}/watermark/download
   */
  public static async downloadControlledCopy(
    screen: any,
    documentId: string,
    versionId?: TWatermarkParamValue,
    language?: TWatermarkParamValue,
    watermarkText: TWatermarkParamValue = "",
    watermarkFontSize?: TWatermarkParamValue,
    watermarkColor?: TWatermarkParamValue,
    watermarkOpacity?: TWatermarkParamValue,
    watermarkPosition?: TWatermarkParamValue,
    watermarkOrientation?: TWatermarkParamValue,
    watermarkDensity?: TWatermarkParamValue,
    replaceParameters?: TReplaceParametersValue
  ): Promise<void> {
    try {
      const base = KuikaAppManager.GetBackendUrl().replace(/\/$/, "");
      // versionId and language are part of the server's WatermarkRequest: forwarding them is what
      // makes those parameters mean anything. The `!= null` guards this replaces let an empty
      // string through into the numeric fields, which the server rejects at binding time.
      const body: TControlledCopyRequestBody = {
        ...buildWatermarkBody({
          versionId,
          language,
          watermarkText,
          watermarkFontSize,
          watermarkColor,
          watermarkOpacity,
          watermarkPosition,
          watermarkOrientation,
          watermarkDensity
        }),
        ...ReactSystemFunctions.parameterReplacementFor(screen, replaceParameters)
      };

      const resp = await axios.post(`${base}/documentmanagement/${documentId}/watermark/download`, body, {
        responseType: "blob"
      });

      // The server streams the controlled copy in the document's ORIGINAL format, so the name and
      // extension come from the response — a hardcoded .pdf produces a file the OS cannot open.
      const contentDisposition: string = resp.headers?.["content-disposition"] ?? "";
      const parsedFileName: string | null = ReactSystemFunctions.parseContentDispositionFileName(contentDisposition);
      const blobMimeType: string = (resp.data as Blob)?.type ?? "";
      const resolvedName: string =
        parsedFileName ?? `controlled-copy${ReactSystemFunctions.extensionForMimeType(blobMimeType)}`;

      KMainFunctions.downloadFile(resp.data, resolvedName);
    } catch (error) {
      KMainFunctions.exceptionHandler(error);
    }
  }

  /**
   * POST watermark params, return the controlled copy as base64.
   * Endpoint: /documentmanagement/{documentId}/watermark/base64
   * @returns { base64: string, mimeType: string, fileName: string } | null
   */
  public static async getControlledCopyAsBase64(
    screen: any,
    documentId: string,
    versionId?: TWatermarkParamValue,
    language?: TWatermarkParamValue,
    watermarkText: TWatermarkParamValue = "",
    watermarkFontSize?: TWatermarkParamValue,
    watermarkColor?: TWatermarkParamValue,
    watermarkOpacity?: TWatermarkParamValue,
    watermarkPosition?: TWatermarkParamValue,
    watermarkOrientation?: TWatermarkParamValue,
    watermarkDensity?: TWatermarkParamValue,
    replaceParameters?: TReplaceParametersValue
  ): Promise<{ base64: string; mimeType: string; fileName: string } | null> {
    try {
      const base = KuikaAppManager.GetBackendUrl().replace(/\/$/, "");
      // versionId and language are part of the server's WatermarkRequest: forwarding them is what
      // makes those parameters mean anything. The `!= null` guards this replaces let an empty
      // string through into the numeric fields, which the server rejects at binding time.
      const body: TControlledCopyRequestBody = {
        ...buildWatermarkBody({
          versionId,
          language,
          watermarkText,
          watermarkFontSize,
          watermarkColor,
          watermarkOpacity,
          watermarkPosition,
          watermarkOrientation,
          watermarkDensity
        }),
        ...ReactSystemFunctions.parameterReplacementFor(screen, replaceParameters)
      };

      const resp = await axios.post(`${base}/documentmanagement/${documentId}/watermark/base64`, body);

      return resp.data ?? null;
    } catch (error) {
      KMainFunctions.exceptionHandler(error);
      return null;
    }
  }

  /**
   * POST watermark params, get blob, open browser print dialog via hidden iframe.
   * Endpoint: /documentmanagement/{documentId}/watermark/print-data
   */
  public static async printControlledCopy(
    screen: any,
    documentId: string,
    versionId?: TWatermarkParamValue,
    language?: TWatermarkParamValue,
    watermarkText: TWatermarkParamValue = "",
    watermarkFontSize?: TWatermarkParamValue,
    watermarkColor?: TWatermarkParamValue,
    watermarkOpacity?: TWatermarkParamValue,
    watermarkPosition?: TWatermarkParamValue,
    watermarkOrientation?: TWatermarkParamValue,
    watermarkDensity?: TWatermarkParamValue,
    replaceParameters?: TReplaceParametersValue
  ): Promise<void> {
    try {
      const base = KuikaAppManager.GetBackendUrl().replace(/\/$/, "");
      // versionId and language are part of the server's WatermarkRequest: forwarding them is what
      // makes those parameters mean anything. The `!= null` guards this replaces let an empty
      // string through into the numeric fields, which the server rejects at binding time.
      const body: TControlledCopyRequestBody = {
        ...buildWatermarkBody({
          versionId,
          language,
          watermarkText,
          watermarkFontSize,
          watermarkColor,
          watermarkOpacity,
          watermarkPosition,
          watermarkOrientation,
          watermarkDensity
        }),
        ...ReactSystemFunctions.parameterReplacementFor(screen, replaceParameters)
      };

      const resp = await axios.post(`${base}/documentmanagement/${documentId}/watermark/print-data`, body, {
        responseType: "blob"
      });

      const blob: Blob = resp.data;
      const blobUrl = URL.createObjectURL(blob);
      const iframe = document.createElement("iframe");
      iframe.style.display = "none";
      iframe.src = blobUrl;
      document.body.appendChild(iframe);
      iframe.onload = () => {
        try {
          iframe.contentWindow?.print();
        } finally {
          setTimeout(() => {
            document.body.removeChild(iframe);
            URL.revokeObjectURL(blobUrl);
          }, 1000);
        }
      };
    } catch (error) {
      KMainFunctions.exceptionHandler(error);
    }
  }

  // ── End Document Management ───────────────────────────────────────

  public static getCurrentUrl = () => {
    return window.location.href;
  };

  public static printTcpl(value: any, printName: any) {
    return false;
  }

  private static getParentOfBaseTableElementRef = (screen, refValue: string) => {
    return (
      screen[`${refValue}_kuikaTableRef`] ||
      screen[`${refValue}_kuikaGalleryViewRef`] ||
      screen[`${refValue}_kuikaCarouselRef`] ||
      screen[`${refValue}_kuikaFlexGridRef`]
    );
  };
}
