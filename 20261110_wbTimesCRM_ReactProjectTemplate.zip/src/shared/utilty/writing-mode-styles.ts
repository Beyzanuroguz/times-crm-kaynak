import { CSSProperties } from "react";

export interface WritingModeStyles {
  /** Box level styles for the element that wraps the text. */
  containerStyles: CSSProperties;
  /**
   * Re-orientation done purely with CSS `writing-mode`. The element keeps a layout box that matches
   * what is painted, so these are safe on ANY element that renders the text — including the
   * design-time double-click edit input.
   */
  flowStyles: CSSProperties;
  /**
   * Re-orientation done with `transform: rotate(...)`. A rotated element still occupies its
   * unrotated layout box, so these are only valid on a text element that `containerStyles` centers.
   * Do not apply them to a full-width input: the input's own box would be rotated, not just its text.
   */
  rotationStyles: CSSProperties;
  /**
   * True when `flowStyles` turns the text flow vertical. In a vertical flow the axes swap — HEIGHT
   * bounds the line length and WIDTH holds the lines — so anything that sizes the box itself
   * (a form control, an auto-growing input) has to measure the other way around.
   */
  isFlowVertical: boolean;
}

// Fresh objects per call: callers merge these into style objects they own, and a shared instance
// would be one stray `Object.assign` away from leaking a style into every text component.
const noWritingModeStyles = (): WritingModeStyles => ({
  containerStyles: {},
  flowStyles: {},
  rotationStyles: {},
  isFlowVertical: false
});

const rotatedWritingModeStyles = (degrees: number): WritingModeStyles => ({
  containerStyles: { display: "flex", alignItems: "center", justifyContent: "center" },
  flowStyles: {},
  rotationStyles: { transform: `rotate(${degrees}deg)`, whiteSpace: "nowrap" },
  isFlowVertical: false
});

/**
 * Single source of truth for the `writingMode` property of text components. Both the rendered text
 * and the design-time edit input read from here, so an orientation can never be applied to one and
 * forgotten on the other.
 *
 * `writingMode` arrives from component metadata, whose option casing differs per component
 * ("Vertical" on the screen Label, "vertical-left" on the report Label), hence the case-insensitive
 * match.
 */
export const getWritingModeStyles = (writingMode: string | undefined): WritingModeStyles => {
  switch (writingMode?.toLowerCase()) {
    case "vertical":
      return {
        containerStyles: {},
        flowStyles: { writingMode: "vertical-rl", textOrientation: "sideways" },
        rotationStyles: {},
        isFlowVertical: true
      };

    case "vertical-left":
      return rotatedWritingModeStyles(-90);

    case "vertical-right":
      return rotatedWritingModeStyles(90);

    default:
      return noWritingModeStyles();
  }
};
