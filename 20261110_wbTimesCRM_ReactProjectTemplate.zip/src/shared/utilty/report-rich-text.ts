// Whitelist sanitizer for report-designer Label rich text. Mirrors the backend C# parser
// (Kuika.Common.ReportDesigner/RichTextRenderer.cs) tag + value grammar EXACTLY so the designer
// canvas preview matches the generated PDF. Used only on the report-designer canvas; it never runs
// for regular screens or generated runtime apps.
//
// Supported tags: b/strong, i/em, u, s/strike/del, br, and span style="color:..;font-size:..".
// Color grammar: #rgb | #rrggbb | rgb(r,g,b) | rgba(r,g,b,a). Font-size grammar: <integer>px.
// Anything outside the grammar is dropped (tag stripped, text kept) so the preview can never show
// styling the PDF won't reproduce.

// Detects whether a value contains a recognized formatting tag. Longest variants first so matching
// does not depend on regex backtracking; a '<' only starts a tag when followed by a letter or '/'.
const MARKUP_PROBE: RegExp = /<\/?(?:strong|strike|span|del|em|br|b|i|u|s)(?=[\s/>])/i;

const ALLOWED_TAGS: ReadonlySet<string> = new Set<string>(["b", "strong", "i", "em", "u", "s", "strike", "del", "br"]);

export function containsReportRichTextMarkup(value: string | undefined | null): boolean {
  return typeof value === "string" && value.length > 0 && MARKUP_PROBE.test(value);
}

export function sanitizeReportRichText(raw: string): string {
  if (!raw) {
    return "";
  }
  const doc: Document = new DOMParser().parseFromString(raw, "text/html");
  return serializeChildren(doc.body);
}

function serializeChildren(node: Node): string {
  let out: string = "";
  node.childNodes.forEach((child: ChildNode): void => {
    out += serializeNode(child);
  });
  return out;
}

function serializeNode(node: Node): string {
  if (node.nodeType === Node.TEXT_NODE) {
    return escapeHtml(node.textContent ?? "");
  }
  if (node.nodeType !== Node.ELEMENT_NODE) {
    return "";
  }

  const element: Element = node as Element;
  const tag: string = element.tagName.toLowerCase();

  // Drop the whole subtree of script/style (content too).
  if (tag === "script" || tag === "style") {
    return "";
  }
  if (tag === "br") {
    return "<br>";
  }
  if (tag === "span") {
    const style: string = sanitizeSpanStyle(element.getAttribute("style"));
    const inner: string = serializeChildren(element);
    return style.length > 0 ? `<span style="${style}">${inner}</span>` : inner;
  }
  if (ALLOWED_TAGS.has(tag)) {
    return `<${tag}>${serializeChildren(element)}</${tag}>`;
  }
  // Non-whitelisted element: strip the tag, keep its (escaped) text content.
  return serializeChildren(element);
}

function sanitizeSpanStyle(style: string | null): string {
  if (!style) {
    return "";
  }
  const declarations: string[] = [];
  for (const declaration of style.split(";")) {
    const colon: number = declaration.indexOf(":");
    if (colon <= 0) {
      continue;
    }
    const prop: string = declaration.slice(0, colon).trim().toLowerCase();
    const val: string = declaration.slice(colon + 1).trim();
    if (prop === "color") {
      const color: string = normalizeColor(val);
      if (color.length > 0) {
        declarations.push(`color:${color}`);
      }
    } else if (prop === "font-size") {
      const size: string = normalizeFontSize(val);
      if (size.length > 0) {
        declarations.push(`font-size:${size}`);
      }
    }
  }
  return declarations.join(";");
}

function normalizeColor(raw: string): string {
  const v: string = raw.trim().toLowerCase();
  if (/^#[0-9a-f]{3}$/.test(v) || /^#[0-9a-f]{6}$/.test(v)) {
    return v;
  }
  // Channels are matched loosely (any digit run) and clamped to 0-255, exactly like the C# parser
  // (RichTextRenderer.ParseRgbTriple), so e.g. rgb(1000,0,0) resolves identically on both sides.
  const match: RegExpMatchArray | null = v.match(/^rgba?\(\s*(\d+)\s*,\s*(\d+)\s*,\s*(\d+)\s*(?:,\s*[\d.]+\s*)?\)$/);
  if (match) {
    const r: number = clampChannel(parseInt(match[1], 10));
    const g: number = clampChannel(parseInt(match[2], 10));
    const b: number = clampChannel(parseInt(match[3], 10));
    return `rgb(${r},${g},${b})`;
  }
  return "";
}

function normalizeFontSize(raw: string): string {
  const v: string = raw.trim().toLowerCase();
  return /^\d+px$/.test(v) ? v : "";
}

function clampChannel(value: number): number {
  if (value < 0) {
    return 0;
  }
  if (value > 255) {
    return 255;
  }
  return value;
}

function escapeHtml(text: string): string {
  return text.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;");
}
