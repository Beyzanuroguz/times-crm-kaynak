// Rebases the bundler's runtime public path onto the location this bundle was
// actually served from. Imported FIRST by src/index.tsx so it runs before any
// dynamic import can execute.
//
// WHY THIS EXISTS
//
// On-demand ("async") chunks are fetched by the bundler runtime, which builds
// their URL from `output.publicPath`. The build bakes that in as a ROOT-RELATIVE
// path — "/" for a root-served app, "/{virtualDirectory}/" otherwise (see
// rsbuild/build-env.ts SERVER_URL). A root-relative path resolves against the
// DOCUMENT's origin, not against the origin the bundle came from. For a
// standalone app those are the same place. For an MFE they are not: an embedded
// microapp runs inside the host shell's document, so every on-demand chunk it
// requests is fetched from the SHELL's origin, where that file does not exist.
//
// The failure is silent. A Kuika frontend is served with `try_files $uri $uri/
// /index.html`, so the shell answers the unknown chunk path with index.html —
// HTTP 200 carrying HTML instead of 404. The dynamic import then fails parsing
// it and the feature dies with no failed request anywhere in the network log.
//
// Entry chunks are NOT affected: the host loads those from the microapp's
// asset-manifest.json and joins the paths onto the microapp's own base URL. Only
// runtime-fetched chunks go through publicPath. That asymmetry is why an
// embedded microapp renders correctly while its file download, PDF export,
// printing, editors and document viewers silently stop working — whichever of
// those the build happened to place in an on-demand chunk rather than sweep into
// the entry group.
//
// SCOPE OF THE REBASE
//
// Standalone resolves to the same host and the same virtual directory as the
// baked-in value, so behavior there is unchanged (absolute instead of
// root-relative, same target). Non-HTTP origins (Electron's file:// and custom
// protocols) are deliberately left on the baked-in value so their resolution is
// untouched. Anything unrecognized falls through to the baked-in value too: this
// module never makes chunk loading worse than it already was.

declare let __webpack_public_path__: string;

// rsbuild emits the entry as `<publicPath>static/js/<name>.js` (default
// output.distPath.js) and on-demand chunks under `<publicPath>static/js/async/`.
// Stripping this segment off the entry's directory yields the deploy root, which
// is what publicPath has to be. If the emitted layout ever stops matching, the
// guard below returns undefined and the baked-in value stays in force.
const ENTRY_DIRECTORY: string = "static/js/";

const HTTP_PROTOCOLS: readonly string[] = ["http://", "https://"];

/**
 * Derives the deploy root from the URL of the currently executing bundle script.
 * Returns undefined when the URL is missing, not HTTP(S), or does not sit in the
 * expected emitted layout — in every one of those cases the caller must leave the
 * build-time public path alone.
 */
export function resolveBundlePublicPath(scriptSrc: string | null | undefined): string | undefined {
  if (!scriptSrc) {
    return undefined;
  }

  const isHttp: boolean = HTTP_PROTOCOLS.some((protocol: string): boolean => scriptSrc.startsWith(protocol));
  if (!isHttp) {
    return undefined;
  }

  const withoutQuery: string = scriptSrc.split("?")[0].split("#")[0];
  const lastSlash: number = withoutQuery.lastIndexOf("/");
  if (lastSlash < 0) {
    return undefined;
  }

  const directory: string = withoutQuery.substring(0, lastSlash + 1);
  if (!directory.endsWith(ENTRY_DIRECTORY)) {
    return undefined;
  }

  return directory.substring(0, directory.length - ENTRY_DIRECTORY.length);
}

/** The src of the script currently executing, or undefined outside a classic script. */
export function getCurrentScriptSrc(): string | undefined {
  // document.currentScript is populated while a classic script executes — which
  // is how both a standalone app and an MFE-injected bundle load. It is null for
  // `type="module"` scripts; those keep the baked-in public path.
  const current: HTMLOrSVGScriptElement | null = typeof document === "undefined" ? null : document.currentScript;
  return current instanceof HTMLScriptElement && current.src.length > 0 ? current.src : undefined;
}

const resolvedPublicPath: string | undefined = resolveBundlePublicPath(getCurrentScriptSrc());

if (resolvedPublicPath !== undefined) {
  __webpack_public_path__ = resolvedPublicPath;
}
