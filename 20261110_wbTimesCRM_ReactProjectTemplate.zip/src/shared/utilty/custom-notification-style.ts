import { createElement, CSSProperties, ReactElement } from "react";

/**
 * Class names react-notifications-component renders inside a notification item.
 *
 * Overrides target the library's own markup, so these must track the installed version:
 * 3.4 renamed every class to an `rnc__` prefix (`notification__close` became
 * `rnc__notification-close-mark`) and a selector left on the old name silently matches
 * nothing (KOA-18715). __tests__/notification-class-overrides.test.tsx renders the real
 * library and fails if any of them stops existing.
 */
export const NOTIFICATION_CLOSE_CLASS: string = "rnc__notification-close-mark";

/**
 * The CSS a `custom` Notify appends to `#dynamic_style` for one notification instance.
 * The same string is later removed from `#dynamic_style` verbatim, so callers must keep it.
 *
 * Only properties that do not change the item's height belong here: the injected class
 * reaches the item after the library has measured it (see buildCustomNotificationMessage).
 */
export function buildCustomNotificationStyle(instanceId: string, backgroundColor: string | null): string {
  return `
          .custom-notification-${instanceId} {
            background-color: ${backgroundColor} !important;
            border-left: unset !important;

            .${NOTIFICATION_CLOSE_CLASS} {
              opacity: 0 !important;
            }
          }
        `
    .replace(" ", "")
    .trim()
    .replace(/(\r\n|\n|\r)/gm, "");
}

/**
 * The message element of a `custom` Notify. Text colour and font size are inline, not in the
 * injected style: the library measures the item height on its first render, before it adds the
 * animationIn classes, so a class-based font size made stacked notifications touch or overlap.
 */
export function buildCustomNotificationMessage(
  text: string,
  textColor: string | null,
  fontSize: number | null
): ReactElement {
  const style: CSSProperties = {
    color: textColor ?? undefined,
    fontSize: fontSize ? `${fontSize}px` : undefined,
    lineHeight: "150%"
  };
  return createElement("div", { style }, text);
}
