import _ from "lodash";
import { TableConfigService } from "../../services/table-config-service";
import { KuikaAppManager } from "./kuika-app-manager";

/** Keeps the transport ignorant of what a component actually stores in its view config. */
export interface ITableViewConfigPersistenceOptions {
  /** The component's own AutoSaveTableConfig gate; nothing is read or written while it is false. */
  isEnabled: () => boolean;
  getScreenId: () => string;
  /** The display-item id; the row key is (KUserId, ScreenId, TableId). */
  getTableId: () => string | undefined;
  /** Serialized payload to store — the component masks or strips whatever it must not persist. */
  readConfigJson: () => string;
  applyConfigJson: (configJson: string) => void;
}

/**
 * Per-user persistence of a component's view config, shared by Table and Pivot Table.
 * It owns the transport only: which side to use, the storage key and the debounce. What goes into
 * the payload — and any masking on the way back in — belongs to the component, whose state shape
 * the two do not agree on.
 * Strict single source: a logged-in user reads and writes the DB only, an anonymous one
 * localStorage only. They never cross-read, so a login cannot contaminate the DB row with a
 * guest layout.
 */
export class TableViewConfigPersistence {
  private readonly options: ITableViewConfigPersistenceOptions;

  private readonly saveDebounced: _.DebouncedFunc<() => void>;

  constructor(options: ITableViewConfigPersistenceOptions, debounceMs: number = 600) {
    this.options = options;
    this.saveDebounced = _.debounce((): void => this.saveNow(), debounceMs);
  }

  load = async (): Promise<void> => {
    const tableId: string | undefined = this.options.getTableId();
    if (!this.options.isEnabled() || !tableId) return;

    let configJson: string = "";
    if (TableViewConfigPersistence.isUserLoggedIn()) {
      configJson = await TableConfigService.getTableConfig(this.options.getScreenId(), tableId);
    } else {
      try {
        configJson = window.localStorage.getItem(this.getStorageKey(tableId)) || "";
      } catch {
        configJson = "";
      }
    }

    if (configJson) {
      this.options.applyConfigJson(configJson);
    }
  };

  /** Collapses rapid changes (resize drags, successive pivot drops) into a single write. */
  scheduleSave = (): void => {
    this.saveDebounced();
  };

  /** Flushes a pending write so a fast navigate-away still captures the last change. */
  flush = (): void => {
    this.saveDebounced.flush?.();
  };

  saveNow = (): void => {
    const tableId: string | undefined = this.options.getTableId();
    if (!this.options.isEnabled() || !tableId) return;

    const configJson: string = this.options.readConfigJson();
    if (TableViewConfigPersistence.isUserLoggedIn()) {
      void TableConfigService.saveTableConfig(this.options.getScreenId(), tableId, configJson);
    } else {
      try {
        window.localStorage.setItem(this.getStorageKey(tableId), configJson);
      } catch {
        // storage unavailable (private mode / quota exceeded); best-effort
      }
    }
  };

  private static isUserLoggedIn = (): boolean => KuikaAppManager.readLoginStateCookie("is_logged_in") === "1";

  private getStorageKey = (tableId: string): string => `kuika_tblcfg_${this.options.getScreenId()}_${tableId}`;
}
