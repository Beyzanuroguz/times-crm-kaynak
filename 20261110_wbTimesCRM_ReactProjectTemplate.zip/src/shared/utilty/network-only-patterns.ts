// URL patterns that the SW must never cache and that runtime code can rely on
// to identify "this URL goes to the backend / dev runtime, not to a cacheable
// asset." Imported by sw.ts (where it's reused as the navigation denylist) and
// available to runtime code that needs the same definition.
//
// Keep this file pure — no `window`/`document` references — so it remains safe
// to import into the ServiceWorkerGlobalScope.
export const NETWORK_ONLY_PATTERNS: readonly RegExp[] = [
  /\/v1\/api(?:\/|$)/, // CoreApi backend
  /\/signal(?:\/|\?|$)/, // SignalR hub
  /\/sockjs-node\//, // dev HMR transport
  /\.hot-update\./, // dev HMR
  /\.map(?:\?|$)/ // sourcemaps
];

export const isNetworkOnlyUrl = (url: URL): boolean =>
  NETWORK_ONLY_PATTERNS.some((re) => re.test(url.pathname + url.search));
