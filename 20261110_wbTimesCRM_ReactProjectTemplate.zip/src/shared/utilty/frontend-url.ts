// Shared between page and service worker. The SW bundle cannot import
// KuikaAppManager (DOM-touching transitive imports), so this module stays
// dependency-light: only the codegen-replaced VIRTUAL_DIRECTORY_URL constant.
import { getVirtualDirectoryUrl } from "./virtual-directory-url";

export interface KuikaEnvConfig {
  FRONTEND_URL?: string;
  BACKEND_URL?: string;
  /** Selected (default) map provider ("GoogleMaps" | "Amap"). Absent → GoogleMaps (backward compatible). */
  MAP_PROVIDER?: string;
  /** "true" when the app bundles both providers and the end user picks one; MAP_PROVIDER is then the default. */
  MAP_PROVIDER_USER_CHOICE?: string;
  /** Google Maps JS API key, surfaced from config so it is not hardcoded in components. */
  GOOGLE_MAPS_KEY?: string;
  /** Amap JSAPI key, present only for Amap projects. */
  AMAP_KEY?: string;
  /** Amap JSAPI 2.0 web security code (window._AMapSecurityConfig.securityJsCode). */
  AMAP_SECURITY_JS_CODE?: string;
  /** "true" when the Amap key carries the World Map entitlement and the project opted in. Absent → mainland-only. */
  AMAP_WORLD_MAP?: string;
  /** "true" when the generated backend carries MapGeocodingController (region-aware Amap geocoding). */
  AMAP_GEOCODING_BACKEND?: string;
}

export const KUIKA_ENV_CONFIG_MESSAGE_TYPE = "kuika-env-config" as const;

export interface KuikaEnvConfigMessage {
  type: typeof KUIKA_ENV_CONFIG_MESSAGE_TYPE;
  env: KuikaEnvConfig;
}

interface LocationLike {
  origin?: string;
  protocol?: string;
  pathname?: string;
}

interface GlobalWithEnv {
  location?: LocationLike;
  _env_?: KuikaEnvConfig;
}

function removeTrailingSlash(value: string): string {
  return value.endsWith("/") ? value.slice(0, -1) : value;
}

let cachedFrontEndUrl: string | undefined;

// Invalidates the memoized result. Called by the SW message handler after a
// fresh env-config arrives; the page never needs it (env-config.js runs
// once before the bundle).
export function invalidateFrontEndUrlCache(): void {
  cachedFrontEndUrl = undefined;
}

export function getFrontEndUrl(): string {
  if (cachedFrontEndUrl !== undefined) return cachedFrontEndUrl;

  const g: GlobalWithEnv = globalThis as GlobalWithEnv;
  const envOverride: string | undefined = g._env_?.FRONTEND_URL;
  if (envOverride) {
    cachedFrontEndUrl = removeTrailingSlash(envOverride);
    return cachedFrontEndUrl;
  }

  const loc: LocationLike | undefined = g.location;
  const origin: string = loc?.origin ?? "";

  if (loc?.protocol === "file:") {
    cachedFrontEndUrl = removeTrailingSlash(`file://${loc.pathname ?? ""}`);
    return cachedFrontEndUrl;
  }

  const virtualDir: string = getVirtualDirectoryUrl();
  const result: string = virtualDir === "auto" ? origin : `${origin}${virtualDir}`;
  cachedFrontEndUrl = removeTrailingSlash(result);
  return cachedFrontEndUrl;
}
