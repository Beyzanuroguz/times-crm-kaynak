import {
  clearPanelHighlight,
  confirmOpenPanel,
  getPanelStopCount,
  highlightPanelStop,
  navigatePanelStop
} from "./datetime-panel-keyboard";

const HIGHLIGHT_CLASS = "kuika-datetime-panel-focus";

interface Fixture {
  dropdown: HTMLElement;
  clicks: string[];
}

// Builds a minimal copy of the antd Date & Time dropdown: a date grid, three time
// columns (hour/minute/second) and an OK button, matching the class names the helper
// queries. Cells record their clicks so navigation can be asserted deterministically.
const buildDropdown = (open: boolean): Fixture => {
  const clicks: string[] = [];
  const dropdown: HTMLElement = document.createElement("div");
  dropdown.className = open ? "ant-picker-dropdown" : "ant-picker-dropdown ant-picker-dropdown-hidden";

  const datePanel: HTMLElement = document.createElement("div");
  datePanel.className = "ant-picker-date-panel";
  for (let day = 1; day <= 14; day++) {
    const cell: HTMLElement = document.createElement("td");
    cell.className =
      day === 8
        ? "ant-picker-cell ant-picker-cell-in-view ant-picker-cell-selected"
        : "ant-picker-cell ant-picker-cell-in-view";
    const inner: HTMLElement = document.createElement("div");
    inner.className = "ant-picker-cell-inner";
    inner.textContent = String(day);
    inner.addEventListener("click", (): void => {
      clicks.push(`date:${day}`);
    });
    cell.appendChild(inner);
    datePanel.appendChild(cell);
  }
  dropdown.appendChild(datePanel);

  const units: string[] = ["hour", "minute", "second"];
  units.forEach((unit: string): void => {
    const column: HTMLElement = document.createElement("ul");
    column.className = "ant-picker-time-panel-column";
    for (let value = 0; value < 6; value++) {
      const li: HTMLElement = document.createElement("li");
      li.className =
        value === 2 ? "ant-picker-time-panel-cell ant-picker-time-panel-cell-selected" : "ant-picker-time-panel-cell";
      const inner: HTMLElement = document.createElement("div");
      inner.className = "ant-picker-time-panel-cell-inner";
      inner.textContent = String(value).padStart(2, "0");
      inner.addEventListener("click", (): void => {
        clicks.push(`${unit}:${value}`);
      });
      li.appendChild(inner);
      column.appendChild(li);
    }
    dropdown.appendChild(column);
  });

  const okWrapper: HTMLElement = document.createElement("li");
  okWrapper.className = "ant-picker-ok";
  const okButton: HTMLElement = document.createElement("button");
  okButton.textContent = "OK";
  okButton.addEventListener("click", (): void => {
    clicks.push("ok");
  });
  okWrapper.appendChild(okButton);
  dropdown.appendChild(okWrapper);

  document.body.appendChild(dropdown);
  return { dropdown, clicks };
};

afterEach((): void => {
  document.body.innerHTML = "";
  document.head.innerHTML = "";
});

describe("datetime-panel-keyboard (KOA-14173)", () => {
  it("counts the panel stops: date grid + 3 time columns + OK", () => {
    buildDropdown(true);
    expect(getPanelStopCount()).toBe(5);
  });

  it("reports no stops when no panel is open", () => {
    buildDropdown(false);
    expect(getPanelStopCount()).toBe(0);
    expect(navigatePanelStop(1, "down")).toBe(false);
    expect(confirmOpenPanel()).toBe(false);
  });

  it("highlights exactly one stop and clears on demand", () => {
    const { dropdown } = buildDropdown(true);
    highlightPanelStop(1); // first time column
    expect(dropdown.querySelectorAll(`.${HIGHLIGHT_CLASS}`)).toHaveLength(1);
    expect(dropdown.querySelectorAll(".ant-picker-time-panel-column")[0].classList.contains(HIGHLIGHT_CLASS)).toBe(
      true
    );

    highlightPanelStop(4); // OK button
    expect(dropdown.querySelector(".ant-picker-ok button")?.classList.contains(HIGHLIGHT_CLASS)).toBe(true);
    expect(dropdown.querySelectorAll(`.${HIGHLIGHT_CLASS}`)).toHaveLength(1);

    clearPanelHighlight();
    expect(dropdown.querySelectorAll(`.${HIGHLIGHT_CLASS}`)).toHaveLength(0);
  });

  it("steps the highlighted time column up/down from the selected cell", () => {
    const { clicks } = buildDropdown(true); // selected cell index = 2 in each column
    expect(navigatePanelStop(1, "down")).toBe(true); // hour column → cell 3
    expect(clicks).toContain("hour:3");

    expect(navigatePanelStop(2, "up")).toBe(true); // minute column → cell 1
    expect(clicks).toContain("minute:1");
  });

  it("ignores left/right on a time column", () => {
    buildDropdown(true);
    expect(navigatePanelStop(1, "left")).toBe(false);
    expect(navigatePanelStop(1, "right")).toBe(false);
  });

  it("navigates the date grid by day and by week", () => {
    const { clicks } = buildDropdown(true); // selected day = 8 (index 7)
    expect(navigatePanelStop(0, "right")).toBe(true); // +1 day → day 9
    expect(clicks).toContain("date:9");

    expect(navigatePanelStop(0, "up")).toBe(true); // -7 days → day 1
    expect(clicks).toContain("date:1");
  });

  it("confirms the panel by clicking OK", () => {
    const { clicks } = buildDropdown(true);
    expect(confirmOpenPanel()).toBe(true);
    expect(clicks).toContain("ok");
  });
});
