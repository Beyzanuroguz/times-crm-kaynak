/**
 * Specific-date restriction for the Date element — KOA-18129.
 *
 * The Date element can be given a list of calendar days (typically the rows of a datasource, e.g.
 * public holidays) plus a mode: "Disable" makes exactly those days unselectable, "Enable" makes
 * them the only selectable days. The list arrives as the raw action result (row objects); plain
 * date values are accepted as well.
 *
 * A row's day is taken from the first configured field that holds a date — the list's key field,
 * then its display field (a typical holiday query keeps its id in the key). With neither field
 * configured it is the row's first date-valued column. A configured field is never second-guessed:
 * a row whose configured fields hold no date is skipped rather than matched on another column,
 * which could be an unrelated date (a created-at stamp).
 *
 * Days are compared as "YYYY-MM-DD" keys. A string is read with its own offset preserved
 * (`parseZone`), so "2026-04-23T00:00:00Z" stays 23 April on a client behind UTC instead of
 * shifting to the 22nd. Numbers are never dates: datasource dates arrive as strings, and an
 * `Id: 1` column read as an epoch would put every row on 1 January 1970.
 */
import moment from "moment";

export type SpecificDatesMode = "Disable" | "Enable";

const DAY_KEY_FORMAT: string = "YYYY-MM-DD";
const FALLBACK_STRING_FORMATS: string[] = ["DD.MM.YYYY", "DD/MM/YYYY", "YYYY/MM/DD"];

const momentToDayKey = (value: moment.Moment): string | undefined => {
  return value.isValid() ? value.format(DAY_KEY_FORMAT) : undefined;
};

const stringToDayKey = (value: string): string | undefined => {
  const trimmed: string = value.trim();
  if (trimmed.length === 0) {
    return undefined;
  }
  const iso: moment.Moment = moment.parseZone(trimmed, moment.ISO_8601, true);
  if (iso.isValid()) {
    return iso.format(DAY_KEY_FORMAT);
  }
  return momentToDayKey(moment(trimmed, FALLBACK_STRING_FORMATS, true));
};

/** Converts one date-like value (string, Date, moment) to its "YYYY-MM-DD" key; anything else yields undefined. */
export const toDayKey = (value: unknown): string | undefined => {
  if (value === null || value === undefined) {
    return undefined;
  }
  if (moment.isMoment(value)) {
    return momentToDayKey(value);
  }
  if (value instanceof Date) {
    return momentToDayKey(moment(value));
  }
  if (typeof value === "string") {
    return stringToDayKey(value);
  }
  return undefined;
};

const readRowField = (row: object, field: string): unknown => {
  if (Object.prototype.hasOwnProperty.call(row, field)) {
    return Reflect.get(row, field);
  }
  // Generated code camel-cases the field name; tolerate a row whose keys kept the column's casing.
  const lowerField: string = field.toLowerCase();
  const matchingKey: string | undefined = Object.keys(row).find((key: string): boolean => {
    return key.toLowerCase() === lowerField;
  });
  return matchingKey === undefined ? undefined : Reflect.get(row, matchingKey);
};

const rowToDayKey = (row: object, fields: string[]): string | undefined => {
  for (const field of fields) {
    const key: string | undefined = toDayKey(readRowField(row, field));
    if (key !== undefined) {
      return key;
    }
  }
  if (fields.length > 0) {
    return undefined;
  }
  for (const cell of Object.values(row)) {
    const key: string | undefined = toDayKey(cell);
    if (key !== undefined) {
      return key;
    }
  }
  return undefined;
};

/**
 * Builds the set of day keys from the bound list, reading each row's `fields` in order (empty
 * names are skipped; none left = the first date-valued column). Returns undefined when there is
 * no list yet (unbound, or the datasource has not answered), which means "no restriction".
 */
export const buildSpecificDateKeys = (items: unknown, fields: (string | undefined)[] = []): Set<string> | undefined => {
  if (!Array.isArray(items)) {
    return undefined;
  }
  const candidateFields: string[] = fields.filter((field: string | undefined): field is string => !!field);
  const keys: Set<string> = new Set<string>();
  for (const item of items) {
    const isRow: boolean =
      item !== null && typeof item === "object" && !moment.isMoment(item) && !(item instanceof Date);
    const key: string | undefined = isRow ? rowToDayKey(item as object, candidateFields) : toDayKey(item);
    if (key !== undefined) {
      keys.add(key);
    }
  }
  return keys;
};

/**
 * Whether `day` is blocked by the specific-date list. An empty list never blocks — in "Enable"
 * mode that would lock the whole calendar whenever the datasource returns no rows.
 */
export const isBlockedBySpecificDates = (
  day: moment.Moment,
  keys: Set<string> | undefined,
  mode: SpecificDatesMode | undefined
): boolean => {
  if (!keys || keys.size === 0 || !day || !day.isValid()) {
    return false;
  }
  const isListed: boolean = keys.has(day.format(DAY_KEY_FORMAT));
  return mode === "Enable" ? !isListed : isListed;
};
