// KOA-18430 — tells a deliberate SetValueOf paint apart from a typed value for the shared form
// field behind a table-column editor.
//
// Every row of a table column renders the same Form.Item name, so one field serves N rows.
// TableData therefore ignores that field for display, otherwise a keystroke in one row is
// painted into every row. But SetValueOf writes the same field, and "set every row's editor
// at once" is a supported authoring pattern that must keep working — so the two writes have
// to be distinguishable, and from rc-field-form's side they are identical.
//
// ReactSystemFunctions.setValueOf marks a paint here; while it is live TableData shows the
// field in every row. BaseTable drops the mark on the first keystroke in a marked editor, so
// as soon as the user types, ownership returns to the row.
//
// The mark is deliberately NOT matched against the value SetValueOf wrote. Codegen routes a
// bound editor's edits through an `onChange` that rewrites this very field with the input's
// DOM value, so the number SetValueOf wrote comes straight back as its formatted string —
// `Object.is(15, "15")` is false, and identity-matching therefore collapsed the paint the
// moment anything normalised the field (KOA-17432 round 2: the paint died on a bound editor
// while surviving on an unbound one, because only bound editors get that onChange). What
// makes a value the row's again is the user typing, and that is tracked on its own.
//
// Deliberately module-level rather than per-form: the writer (a system action) and the reader
// (a cell renderer) have no shared instance, and this module imports nothing, so neither side
// gains a dependency on the other. One entry per field a screen ever SetValueOf's, so the set
// stays the size of a screen's form.
const paintedRowEditorFields: Set<string> = new Set<string>();

export const markExplicitFieldWrite = (fieldName: string): void => {
  if (!fieldName) {
    return;
  }
  paintedRowEditorFields.add(fieldName);
};

/**
 * True while a SetValueOf paint of `fieldName` is still authoritative for every row.
 *
 * `value` is the field's current value, and only its presence is consulted: an unseeded field
 * means the form was rebuilt (the screen was re-entered) and there is nothing to paint, so the
 * row takes its value back rather than every editor rendering empty.
 */
export const isExplicitFieldWrite = (fieldName: string, value: unknown): boolean => {
  if (!fieldName || !paintedRowEditorFields.has(fieldName)) {
    return false;
  }
  return value !== undefined;
};

export const clearExplicitFieldWrite = (fieldName: string): void => {
  if (!fieldName) {
    return;
  }
  paintedRowEditorFields.delete(fieldName);
};

// KOA-18076 round 5 — which marked row editors hold a value the USER put there.
//
// BaseTable already tracks this from `onInputCapture`, which is enough for a typed editor:
// the first keystroke marks the field, and the blur hand-back
// (restoreRowValueForUntouchedEditor) then leaves it alone. A SelectBox never reaches that
// hook — picking an option from the dropdown fires the component's own `onChange` and no DOM
// `input` event at all — so a marked SelectBox cell looked permanently untouched. Clicking
// the row's save button blurs it, the hand-back decided the row still owned the field, and
// the user's pick was overwritten with the row's stored value microseconds before the action
// read it. On a column whose rows are empty that is a `null`, which is exactly the
// "null gidiyor" QA reported.
//
// The signal has to come from the component layer, and the cell and BaseTable share no
// instance, so it lives here next to the paint record it sits beside in the same decision.
// Deliberately NOT reset on unregister/remount: a value the user chose stays theirs until
// they leave the editor (BaseTable clears it on focus, starting a fresh editing session).
const touchedRowEditors: Set<string> = new Set<string>();

export const markRowEditorTouched = (fieldName: string | undefined): void => {
  if (!fieldName) {
    return;
  }
  touchedRowEditors.add(fieldName);
};

export const isRowEditorTouched = (fieldName: string): boolean => {
  if (!fieldName) {
    return false;
  }
  return touchedRowEditors.has(fieldName);
};

export const clearRowEditorTouched = (fieldName: string): void => {
  if (!fieldName) {
    return;
  }
  touchedRowEditors.delete(fieldName);
};
