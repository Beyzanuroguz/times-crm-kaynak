import { IStripeSettings } from "../../models/dto/stripe-settings";

export const STRIPE_SETTINGS = {} as IStripeSettings;

export const BASE_64_REGEX = /^([0-9a-zA-Z+/]{4})*(([0-9a-zA-Z+/]{2}==)|([0-9a-zA-Z+/]{3}=))?$/;

export const DEFAULT_IMAGE =
  "data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iOTAiIGhlaWdodD0iOTAiIHZpZXdCb3g9IjAgMCA5MCA5MCIgZmlsbD0ibm9uZSIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj4KPHJlY3Qgd2lkdGg9IjkwIiBoZWlnaHQ9IjkwIiBmaWxsPSIjRTVFRUZGIi8+CjxwYXRoIGQ9Ik00NS44NDU4IDQzLjI0NEw1MC4xMjE4IDM1LjQ4MzJDNTEuOTE3NyAzMi4yMjM3IDU2LjY2ODcgMzIuNDI4OCA1OC4xNzcgMzUuODMxTDY1LjYzOSA1Mi42NjNDNjcuNjkwOSA1Ny4yOTE0IDY0LjMwMjUgNjIuNSA1OS4yMzk3IDYyLjVIMzEuMjk1NEMyNi4wOTkyIDYyLjUgMjIuNzE0MyA1Ny4wMzgxIDI1LjAyNjggNTIuMzg0OEwyOS41MjQ0IDQzLjMzNDNDMzEuMTkyOSAzOS45NzY4IDM1Ljk1NSAzOS45MDAzIDM3LjczMDUgNDMuMjAyNEMzOS40NjQgNDYuNDI2MyA0NC4wNzk1IDQ2LjQ0OTkgNDUuODQ1OCA0My4yNDRaIiBmaWxsPSIjQjJDQ0ZGIi8+CjxwYXRoIGQ9Ik0zOS41IDMxLjVDMzkuNSAzMy43MDkxIDM3LjcwOTEgMzUuNSAzNS41IDM1LjVDMzMuMjkwOSAzNS41IDMxLjUgMzMuNzA5MSAzMS41IDMxLjVDMzEuNSAyOS4yOTA5IDMzLjI5MDkgMjcuNSAzNS41IDI3LjVDMzcuNzA5MSAyNy41IDM5LjUgMjkuMjkwOSAzOS41IDMxLjVaIiBmaWxsPSIjQjJDQ0ZGIi8+Cjwvc3ZnPgo=";

export const PUSH_NOTIFICATION_PUBLIC_KEY: string = "";

export const OFFLINE_REDIRECT_CANCEL = "OFFLINE_REDIRECT";

// App-root-relative folder (under the generated app's public/) where the code
// generator emits offline-screen UploadedImages as static files. MUST stay in
// sync with the C# ResourceExtensions.OfflineResourcePublicFolder. The stored
// value is "/offline-resources/{id}.{ext}"; it MUST be resolved against the
// frontend base URL (getFrontEndUrl / virtual directory) before use — a bare
// "/offline-resources/..." resolves to the origin root and 404s on any app
// hosted under a virtual directory (e.g. Preview/Run apps served at "/{app}/").
export const OFFLINE_RESOURCE_PUBLIC_PREFIX = "/offline-resources/";
