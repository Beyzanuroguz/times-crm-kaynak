// Normalises coordinates that reach the Amap components from Kuika values. A Map / LocationPicker
// value is whatever the screen put there: numbers from a map click, numeric strings from a
// LocationSearch (`getLatitude()` returns a string) or a form field, and null / "" when cleared.
// Google's renderer coerces all of those on its own; Amap's overlay math does not and throws
// `Invalid Object: Pixel(NaN, NaN)` from deep inside the JSAPI, taking the screen down. Every
// Amap component therefore parses through here before touching the map.
import { IGeoPoint } from "./coordinate-transform";

/** A finite number for a number or numeric string; null for null, undefined, "", NaN or anything else. */
export function toCoordinate(value: unknown): number | null {
  if (typeof value === "number") {
    return Number.isFinite(value) ? value : null;
  }
  if (typeof value === "string") {
    const trimmed: string = value.trim();
    if (trimmed === "") return null;
    const parsed: number = Number(trimmed);
    return Number.isFinite(parsed) ? parsed : null;
  }
  return null;
}

/** Both coordinates as finite numbers, or null when either is missing or unparsable. */
export function toCoordinatePair(latitude: unknown, longitude: unknown): IGeoPoint | null {
  const lat: number | null = toCoordinate(latitude);
  const lng: number | null = toCoordinate(longitude);
  if (lat === null || lng === null) return null;
  return { latitude: lat, longitude: lng };
}

interface ILngLatLike {
  getLat?: () => unknown;
  getLng?: () => unknown;
  lat?: unknown;
  lng?: unknown;
}

/**
 * Reads an Amap `LngLat` — or the plain `{lat, lng}` object some plugin results carry instead —
 * as a finite pair in the datum it was given (GCJ-02 when it came from Amap). Amap's own class
 * exposes both the `getLat()`/`getLng()` methods and the `lat`/`lng` properties; plugin results
 * that were re-hydrated from JSON expose only the properties, so both shapes are accepted.
 */
export function readLngLat(value: unknown): IGeoPoint | null {
  if (!value || typeof value !== "object") return null;
  const candidate: ILngLatLike = value as ILngLatLike;
  const lat: unknown = typeof candidate.getLat === "function" ? candidate.getLat() : candidate.lat;
  const lng: unknown = typeof candidate.getLng === "function" ? candidate.getLng() : candidate.lng;
  return toCoordinatePair(lat, lng);
}

/** Degrees of longitude one Web Mercator pixel spans at `zoom` (256 px tiles). */
export function degreesPerPixel(zoom: number): number {
  return 360 / (256 * Math.pow(2, zoom));
}

/**
 * True when both points exist and lie within `pixels` screen pixels of each other at `zoom`. Used
 * to recognise the autoCenter pan onto the selected marker: the centre a map reports after
 * `setCenter` is snapped to its pixel grid and rounded by the SDK, so it never equals the marker
 * exactly, yet reporting it back as a picker value would replace the selection and un-select the
 * marker. Three pixels is below anything a user could drag on purpose.
 */
export function isWithinPixels(a: IGeoPoint | null, b: IGeoPoint | null, zoom: number, pixels: number = 3): boolean {
  if (a === null || b === null) return false;
  const tolerance: number = degreesPerPixel(Number.isFinite(zoom) ? zoom : 0) * pixels;
  return Math.abs(a.latitude - b.latitude) <= tolerance && Math.abs(a.longitude - b.longitude) <= tolerance;
}
