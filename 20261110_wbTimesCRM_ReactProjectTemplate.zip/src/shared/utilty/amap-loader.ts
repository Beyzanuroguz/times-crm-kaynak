// Loads the Amap (AutoNavi) JSAPI 2.0 on demand for the map runtime. The Amap key
// and web security code come from the generated env-config (window._env_) via
// map-provider-config. Loading is memoized so the JSAPI script + plugins are
// fetched exactly once per page, mirroring how google-map-react bootstraps Google.
import AMapLoader from "@amap/amap-jsapi-loader";
import { AmapRuntimeConfig, getAmapRuntimeConfig } from "./map-provider-config";

interface AMapSecurityConfig {
  securityJsCode?: string;
  serviceHost?: string;
}

interface WindowWithAMapSecurity {
  _AMapSecurityConfig?: AMapSecurityConfig;
}

// Plugins the Kuika map runtime relies on: place search + autocomplete, geocoding,
// driving directions (waypoints), marker clustering, geolocation and the traffic layer.
const AMAP_PLUGINS: string[] = [
  "AMap.AutoComplete",
  "AMap.PlaceSearch",
  "AMap.Geocoder",
  "AMap.Driving",
  "AMap.MarkerCluster",
  "AMap.Geolocation",
  "AMap.TileLayer.Traffic"
];

let loadPromise: Promise<typeof AMap> | null = null;

/**
 * Loads (or returns the in-flight/settled successful load of) the Amap JSAPI. Rejects when Amap
 * is not the effective provider or no key is set — callers should only invoke this after
 * confirming {@link isAmapProvider}. Rejections are never memoized: with end-user provider choice
 * a call made while Google is effective must not poison every later Amap load on the page, and a
 * transient network failure must be retryable.
 */
export function loadAMap(): Promise<typeof AMap> {
  if (loadPromise) return loadPromise;

  const config: AmapRuntimeConfig | null = getAmapRuntimeConfig();
  if (!config) {
    return Promise.reject(new Error("Amap is not the configured map provider or no Amap key is set."));
  }

  // The security code must be present on window before the JSAPI script executes.
  const win: WindowWithAMapSecurity = window as unknown as WindowWithAMapSecurity;
  win._AMapSecurityConfig = { securityJsCode: config.securityJsCode };

  const pending: Promise<typeof AMap> = AMapLoader.load({
    key: config.key,
    version: "2.0",
    plugins: AMAP_PLUGINS
  }) as Promise<typeof AMap>;
  loadPromise = pending;
  pending.catch((): void => {
    if (loadPromise === pending) loadPromise = null;
  });

  return pending;
}
