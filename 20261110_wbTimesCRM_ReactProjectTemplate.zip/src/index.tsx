// CG_FLAG_ELASTIC_APM_IMPORT
/// //////////////////////////////////////////////////////////////////////////////////////
// MUST stay the first import: it rebases the bundler's runtime public path onto
// the location this bundle was served from, and that has to happen before any
// dynamic import runs. See shared/utilty/bundle-public-path.ts for why.
import "./shared/utilty/bundle-public-path";
/// //////////////////////////////////////////////////////////////////////////////////////
import "moment/min/locales";
import { createRoot } from "react-dom/client";
import { AppBootstrapper, IAppMode, IAuthType } from "./bootstrapper";
import { IRouterType } from "./routes/router";
import { initAppUpdateMonitoring } from "./services/app-update-service";
import { isElectron as checkIsElectron } from "./services/electron-bridge-service";
import { KuikaAppManager } from "./shared/utilty/kuika-app-manager";
import { KMainFunctions } from "./shared/utilty/main-functions";
import { ReactSystemFunctions } from "./shared/utilty/react-system-functions";
import WebComponentInit from "./web-component-init";

// Expose React globals for widget bundles
// (window as any).React = React;
// (window as any).ReactDOM = ReactDOM;
// (window as any).ReactJSXRuntime = ReactJSXRuntime;
import { askPermission, registerServiceWorker } from "./services/notification-service";

KMainFunctions.ignoreKnownConsoleErrors();
KMainFunctions.ignoreKnownConsoleWarns();

// CG_FLAG_ELASTIC_APM_INIT

const isElectron: boolean = checkIsElectron();

const owner = document.getElementById("reslen-01-wb-times-crm");
if (owner) {
  // Get or create container element
  let container = document.getElementById("reslen-01-wb-times-crm");
  if (!container) {
    container = document.createElement("div");
    container.id = "reslen-01-wb-times-crm";
    document.body.appendChild(container);
  }

  const root = createRoot(container!);

  const authType: IAuthType = "Kuika";
  // Use HashRouter for Electron to avoid routing issues with custom protocol
  const routerType: IRouterType = isElectron ? "HashRouter" : "BrowserRouter";
  const appMode: IAppMode = "WebSite";

  root.render(<AppBootstrapper authType={authType} routerType={routerType} appMode={appMode} />);

  if ((module as any).hot) {
    (module as any).hot.accept();
  }
} else {
  WebComponentInit();
}

registerServiceWorker();
askPermission();

// Service workers don't work with custom protocols in Electron
if (!isElectron && "serviceWorker" in navigator) {
  navigator.serviceWorker.addEventListener("message", (event) => {
    if (event.data?.type === "kuika-wasm-stale-reload") {
      // The service worker detected this tab booted an outdated WASM set and
      // has already refreshed the cache to the current build. Reload ONCE
      // onto the new code so the user is never stranded on a missing
      // [JSExport]. sessionStorage one-shot prevents a reload loop if
      // something is persistently wrong.
      if (sessionStorage.getItem("kuika-wasm-healed") !== "1") {
        sessionStorage.setItem("kuika-wasm-healed", "1");
        window.location.reload();
      }
      return;
    }
    if (event.data?.type === "notification-data") {
      const { screenId, parameters } = event.data.extraData;

      const path = getPathFromScreenId(screenId, parameters);

      // Security: validate redirect URL is same-origin to prevent open redirect / XSS
      try {
        const url = new URL(path, window.location.origin);
        if (url.origin !== window.location.origin) {
          console.error("Redirect blocked: cross-origin URL detected");
          return;
        }
        window.location.href = url.href;
      } catch {
        console.error("Redirect blocked: invalid URL");
      }
    }
  });

  initAppUpdateMonitoring();
}

function getPathFromScreenId(screenId: string | null, parameters: any): string {
  if (!screenId) return KuikaAppManager.GetFrontEndUrl();

  var screenName = ReactSystemFunctions.getScreenNameById(screenId);
  var path = `${KuikaAppManager.GetFrontEndUrl()}/${screenName}`;

  const { screenId: _, ...rest } = parameters;

  const query = new URLSearchParams(rest).toString();
  return query ? `${path}?${query}` : path;
}

const workspace = "reslen_01";
const app = "wbTimesCRM";
const webComponentTag = "reslen-01-wb-times-crm";
export { app, webComponentTag, workspace };
