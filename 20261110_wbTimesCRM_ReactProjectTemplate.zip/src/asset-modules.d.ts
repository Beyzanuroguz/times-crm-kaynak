// Ambient declarations for side-effect imports of non-TS assets.
// TS 6.0 tightened this: side-effect imports must resolve, even under
// moduleResolution: "node". Rsbuild / rspack handle the actual loading
// at bundle time; these declarations just satisfy the type-checker.
// This file must contain no `import`/`export` statements — any
// top-level import makes the file a module, which turns these
// declarations into module-scoped augmentations instead of globals.

// moment ships no typings for its locale bundle: typesVersions maps every subpath into
// ts3.1-typings/, where only moment.d.ts exists, so the JS at moment/min/locales.js is
// never found by the checker (the bundler resolves it fine).
declare module "moment/min/locales";

declare module "*.css";
declare module "*.scss";
declare module "*.sass";
declare module "*.less";
declare module "moment/min/locales";
