import React from "react";
import { define } from "remount";
import { IAppMode, IAuthType } from "./bootstrapper";
import { IRouterType } from "./routes/router";

const authType: IAuthType = "Kuika";
const routerType: IRouterType = "HashRouter";
const appMode: IAppMode = "WebComponent";

/**
 * The web component's attribute contract, in one place because it is consumed
 * twice and only one of the two is load-bearing: `remount` builds the component's
 * props by reducing over the `attributes` array below, so an attribute missing
 * from it is silently dropped — and dropping `external_provider_type` or
 * `external_access_token` means the auth handoff never happens, with no error
 * anywhere. The `validAttributes` diagnostic is the forgiving one. Keeping them
 * as separate literals let the harmless list drift visibly while the load-bearing
 * one drifted silently.
 */
export const MFE_WEB_COMPONENT_ATTRIBUTES: string[] = [
  "external_user",
  "external_access_token",
  "external_refresh_token",
  "external_provider_type",
  "starting_screen"
];

export default () => {
  const AppBootstrapper = React.lazy(() =>
    import("./bootstrapper").then((module) => ({ default: module.AppBootstrapper }))
  );

  const WebComponent = (props) => {
    const validAttributes = new Set(MFE_WEB_COMPONENT_ATTRIBUTES);

    const { external_user, external_access_token, external_refresh_token, external_provider_type, starting_screen } =
      props;
    const [screenInputProps, setScreenInputProps] = React.useState({});

    React.useEffect(() => {
      const webComponentElement = document.querySelector("reslen-01-wb-times-crm");
      if (!webComponentElement) return;

      const extractedScreenInputs = {};
      const detectedInvalidProps = [];

      Array.from(webComponentElement.attributes).forEach((attr) => {
        const name = attr.name;
        const value = attr.value;

        if (name.startsWith("screeninput_")) {
          const camelCaseName = name.replace(/^screeninput_/, "screenInput_");
          extractedScreenInputs[camelCaseName] = value;
        } else if (!validAttributes.has(name) && !name.startsWith("screeninput_")) {
          detectedInvalidProps.push(name);
        }
      });

      setScreenInputProps(extractedScreenInputs);
    }, []);

    return (
      <AppBootstrapper
        authType={authType}
        routerType={routerType}
        tagName="reslen-01-wb-times-crm"
        external_user={external_user}
        external_access_token={external_access_token}
        external_refresh_token={external_refresh_token}
        external_provider_type={external_provider_type}
        startingScreen={starting_screen}
        appMode={appMode}
        {...screenInputProps}
      />
    );
  };
  define(
    {
      "reslen-01-wb-times-crm": {
        component: WebComponent,
        attributes: MFE_WEB_COMPONENT_ATTRIBUTES
      }
    },
    {
      shadow: false,
      retarget: true,
      quiet: true
    }
  );
};
