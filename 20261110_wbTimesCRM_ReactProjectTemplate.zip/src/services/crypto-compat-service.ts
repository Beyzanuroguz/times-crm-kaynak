import forge from "node-forge";

const subtleAvailable = (() => {
  try {
    return typeof crypto !== "undefined" && !!crypto.subtle;
  } catch {
    return false;
  }
})();

const GCM_TAG_BYTES = 16;

function uint8ToBinaryString(bytes: Uint8Array): string {
  let s = "";
  const chunk = 0x8000;
  for (let i = 0; i < bytes.length; i += chunk) {
    s += String.fromCharCode.apply(null, Array.from(bytes.subarray(i, i + chunk)));
  }
  return s;
}

function binaryStringToUint8(s: string): Uint8Array {
  const out = new Uint8Array(s.length);
  for (let i = 0; i < s.length; i++) out[i] = s.charCodeAt(i) & 0xff;
  return out;
}

function uint8ToBase64(bytes: Uint8Array): string {
  return btoa(uint8ToBinaryString(bytes));
}

function base64ToUint8(b64: string): Uint8Array {
  return binaryStringToUint8(atob(b64));
}

function bytesToHex(bytes: Uint8Array): string {
  let hex = "";
  for (let i = 0; i < bytes.length; i++) hex += bytes[i].toString(16).padStart(2, "0");
  return hex;
}

async function sha256HexWebCrypto(text: string): Promise<string> {
  const buf = await crypto.subtle.digest("SHA-256", new TextEncoder().encode(text));
  return bytesToHex(new Uint8Array(buf));
}

function sha256HexForge(text: string): string {
  const md = forge.md.sha256.create();
  md.update(forge.util.encodeUtf8(text));
  return md.digest().toHex();
}

async function pbkdf2WebCrypto(
  password: Uint8Array,
  salt: Uint8Array,
  iterations: number,
  keyByteLength: number
): Promise<Uint8Array> {
  const keyMaterial = await crypto.subtle.importKey("raw", password as BufferSource, "PBKDF2", false, ["deriveBits"]);
  const bits = await crypto.subtle.deriveBits(
    { name: "PBKDF2", salt: salt as BufferSource, iterations, hash: "SHA-256" },
    keyMaterial,
    keyByteLength * 8
  );
  return new Uint8Array(bits);
}

function pbkdf2Forge(password: Uint8Array, salt: Uint8Array, iterations: number, keyByteLength: number): Uint8Array {
  const dk = forge.pkcs5.pbkdf2(
    uint8ToBinaryString(password),
    uint8ToBinaryString(salt),
    iterations,
    keyByteLength,
    forge.md.sha256.create()
  );
  return binaryStringToUint8(dk);
}

async function aesGcmEncryptWebCrypto(key: Uint8Array, iv: Uint8Array, plaintext: Uint8Array): Promise<Uint8Array> {
  const cryptoKey = await crypto.subtle.importKey("raw", key as BufferSource, { name: "AES-GCM" }, false, ["encrypt"]);
  const ct = await crypto.subtle.encrypt(
    { name: "AES-GCM", iv: iv as BufferSource },
    cryptoKey,
    plaintext as BufferSource
  );
  return new Uint8Array(ct);
}

async function aesGcmDecryptWebCrypto(
  key: Uint8Array,
  iv: Uint8Array,
  ciphertextWithTag: Uint8Array
): Promise<Uint8Array> {
  const cryptoKey = await crypto.subtle.importKey("raw", key as BufferSource, { name: "AES-GCM" }, false, ["decrypt"]);
  const pt = await crypto.subtle.decrypt(
    { name: "AES-GCM", iv: iv as BufferSource },
    cryptoKey,
    ciphertextWithTag as BufferSource
  );
  return new Uint8Array(pt);
}

function aesGcmEncryptForge(key: Uint8Array, iv: Uint8Array, plaintext: Uint8Array): Uint8Array {
  const cipher = forge.cipher.createCipher("AES-GCM", forge.util.createBuffer(uint8ToBinaryString(key)));
  cipher.start({ iv: forge.util.createBuffer(uint8ToBinaryString(iv)), tagLength: GCM_TAG_BYTES * 8 });
  cipher.update(forge.util.createBuffer(uint8ToBinaryString(plaintext)));
  if (!cipher.finish()) throw new Error("AES-GCM encryption failed");
  const ct = binaryStringToUint8(cipher.output.bytes());
  const tag = binaryStringToUint8(cipher.mode.tag.bytes());
  const out = new Uint8Array(ct.length + tag.length);
  out.set(ct);
  out.set(tag, ct.length);
  return out;
}

function aesGcmDecryptForge(key: Uint8Array, iv: Uint8Array, ciphertextWithTag: Uint8Array): Uint8Array {
  if (ciphertextWithTag.length < GCM_TAG_BYTES) throw new Error("AES-GCM ciphertext too short");
  const tag = ciphertextWithTag.subarray(ciphertextWithTag.length - GCM_TAG_BYTES);
  const ct = ciphertextWithTag.subarray(0, ciphertextWithTag.length - GCM_TAG_BYTES);
  const decipher = forge.cipher.createDecipher("AES-GCM", forge.util.createBuffer(uint8ToBinaryString(key)));
  decipher.start({
    iv: forge.util.createBuffer(uint8ToBinaryString(iv)),
    tagLength: GCM_TAG_BYTES * 8,
    tag: forge.util.createBuffer(uint8ToBinaryString(tag))
  });
  decipher.update(forge.util.createBuffer(uint8ToBinaryString(ct)));
  if (!decipher.finish()) throw new Error("AES-GCM authentication failed");
  return binaryStringToUint8(decipher.output.bytes());
}

async function rsaOaepEncryptWebCrypto(spkiBase64: string, plaintext: string): Promise<string> {
  const keyBytes = base64ToUint8(spkiBase64);
  const importedKey = await crypto.subtle.importKey(
    "spki",
    keyBytes as BufferSource,
    { name: "RSA-OAEP", hash: { name: "SHA-256" } },
    false,
    ["encrypt"]
  );
  const ct = await crypto.subtle.encrypt({ name: "RSA-OAEP" }, importedKey, new TextEncoder().encode(plaintext));
  return uint8ToBase64(new Uint8Array(ct));
}

function rsaOaepEncryptForge(spkiBase64: string, plaintext: string): string {
  const derBinary = atob(spkiBase64);
  const asn1 = forge.asn1.fromDer(derBinary);
  const publicKey = forge.pki.publicKeyFromAsn1(asn1) as forge.pki.rsa.PublicKey;
  const ciphertext = publicKey.encrypt(forge.util.encodeUtf8(plaintext), "RSA-OAEP", {
    md: forge.md.sha256.create(),
    mgf1: { md: forge.md.sha256.create() }
  });
  return forge.util.encode64(ciphertext);
}

export const cryptoCompat = {
  isWebCryptoAvailable: (): boolean => subtleAvailable,

  async sha256Hex(text: string): Promise<string> {
    if (subtleAvailable) {
      try {
        return await sha256HexWebCrypto(text);
      } catch {
        // fall through
      }
    }
    return sha256HexForge(text);
  },

  async pbkdf2Sha256(
    password: Uint8Array,
    salt: Uint8Array,
    iterations: number,
    keyByteLength: number
  ): Promise<Uint8Array> {
    if (subtleAvailable) {
      try {
        return await pbkdf2WebCrypto(password, salt, iterations, keyByteLength);
      } catch {
        // fall through
      }
    }
    return pbkdf2Forge(password, salt, iterations, keyByteLength);
  },

  async aesGcmEncrypt(key: Uint8Array, iv: Uint8Array, plaintext: Uint8Array): Promise<Uint8Array> {
    if (subtleAvailable) {
      try {
        return await aesGcmEncryptWebCrypto(key, iv, plaintext);
      } catch {
        // fall through
      }
    }
    return aesGcmEncryptForge(key, iv, plaintext);
  },

  async aesGcmDecrypt(key: Uint8Array, iv: Uint8Array, ciphertextWithTag: Uint8Array): Promise<Uint8Array> {
    if (subtleAvailable) {
      try {
        return await aesGcmDecryptWebCrypto(key, iv, ciphertextWithTag);
      } catch {
        // fall through
      }
    }
    return aesGcmDecryptForge(key, iv, ciphertextWithTag);
  },

  async rsaOaepEncryptSpkiBase64(spkiBase64: string, plaintext: string): Promise<string> {
    if (subtleAvailable) {
      try {
        return await rsaOaepEncryptWebCrypto(spkiBase64, plaintext);
      } catch {
        // fall through
      }
    }
    return rsaOaepEncryptForge(spkiBase64, plaintext);
  },

  randomUUID(): string {
    if (typeof crypto !== "undefined" && typeof crypto.randomUUID === "function") {
      try {
        return crypto.randomUUID();
      } catch {
        // fall through
      }
    }
    const bytes = new Uint8Array(16);
    if (typeof crypto !== "undefined" && typeof crypto.getRandomValues === "function") {
      crypto.getRandomValues(bytes);
    } else {
      for (let i = 0; i < 16; i++) bytes[i] = Math.floor(Math.random() * 256);
    }
    bytes[6] = (bytes[6] & 0x0f) | 0x40;
    bytes[8] = (bytes[8] & 0x3f) | 0x80;
    const hex = bytesToHex(bytes);
    return `${hex.slice(0, 8)}-${hex.slice(8, 12)}-${hex.slice(12, 16)}-${hex.slice(16, 20)}-${hex.slice(20)}`;
  },

  uint8ToBase64,
  base64ToUint8
};
