import Axios, { AxiosResponse } from "axios";
import {
  IExcelFileMetadataRequest,
  IExcelFileMetadataResponse,
  IImportMappedExcelFileRequest,
  IImportMappedExcelRequest,
  IImportMappedExcelResponse
} from "../models/dto/excel";
import { KuikaAppManager } from "../shared/utilty/kuika-app-manager";

class ExcelService {
  private static readonly BACKEND_URL: string = KuikaAppManager.GetBackendUrl();

  public static async ImportMappedExcel(
    request: IImportMappedExcelRequest
  ): Promise<AxiosResponse<IImportMappedExcelResponse>> {
    return Axios.post<IImportMappedExcelRequest, AxiosResponse<IImportMappedExcelResponse>>(
      `${ExcelService.BACKEND_URL}/excel/import`,
      request
    );
  }

  public static async ImportMappedExcelFromFile(
    request: IImportMappedExcelFileRequest
  ): Promise<AxiosResponse<IImportMappedExcelResponse>> {
    return Axios.post<IImportMappedExcelFileRequest, AxiosResponse<IImportMappedExcelResponse>>(
      `${ExcelService.BACKEND_URL}/excel/import-file`,
      request
    );
  }

  public static async GetFileMetadata(
    request: IExcelFileMetadataRequest
  ): Promise<AxiosResponse<IExcelFileMetadataResponse>> {
    return Axios.post<IExcelFileMetadataRequest, AxiosResponse<IExcelFileMetadataResponse>>(
      `${ExcelService.BACKEND_URL}/excel/metadata`,
      request
    );
  }
}

export default ExcelService;
