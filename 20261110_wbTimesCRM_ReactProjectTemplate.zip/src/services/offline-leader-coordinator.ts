/**
 * Multi-tab coordination for the offline OPFS database.
 *
 * WHY: the offline SQLite DB lives in a DEDICATED Web Worker (OPFS `createSyncAccessHandle` is
 * dedicated-worker-only) and OPFS sync access handles are EXCLUSIVE per origin — so only ONE tab may
 * own the worker/DB at a time. To let every tab read/write, exactly one tab is elected LEADER and
 * owns the worker; the others are FOLLOWERS and forward their DB operations to the leader.
 *
 * PRIMITIVES (all dedicated-worker-compatible — deliberately NOT a SharedWorker, which cannot open
 * sync access handles and cannot reliably detect a tab closing):
 *  - Web Locks: leader election + death detection. The leader holds an exclusive lock for its whole
 *    lifetime; when its tab closes the lock auto-releases and a waiting follower is promoted
 *    (migration) — it opens the SAME on-disk OPFS DB and takes over.
 *  - BroadcastChannel: the follower→leader RPC pipe (request/response, correlated by id) plus leader
 *    presence announcements that let followers retry across a migration.
 *
 * The DB payloads that cross the channel are the same semantic operations that cross the worker
 * boundary (Db_* calls, streaming-import chunks, wipe) — never SQL.
 */

/** A single DB operation, transport-agnostic — runs on the leader's worker wherever it originates. */
export interface OfflineRpcRequest {
  kind: "call" | "importBegin" | "importChunk" | "importEnd" | "wipe";
  method?: string;
  args?: readonly unknown[];
  offset?: number;
  chunk?: Uint8Array;
}

/** The result of an {@link OfflineRpcRequest}. */
export interface OfflineRpcResult {
  ok: boolean;
  result?: unknown;
  error?: string;
}

/** Runs a request on THIS tab's local worker. Supplied by the adapter; only invoked when leader. */
export type LeaderExecutor = (request: OfflineRpcRequest) => Promise<OfflineRpcResult>;

/** Spawns + initializes this tab's local worker when it becomes leader. Supplied by the adapter. */
export type PromoteHandler = () => Promise<void>;

type Role = "pending" | "leader" | "follower";

/** BroadcastChannel envelope: follower→leader request. */
interface RpcRequestEnvelope {
  t: "req";
  reqId: string;
  from: string;
  request: OfflineRpcRequest;
}

/** BroadcastChannel envelope: leader→follower response. */
interface RpcResponseEnvelope {
  t: "res";
  reqId: string;
  to: string;
  result: OfflineRpcResult;
}

/** BroadcastChannel envelope: follower asking whether a leader exists. */
interface WhoisEnvelope {
  t: "whois";
  from: string;
}

/** BroadcastChannel envelope: leader announcing it is serving (reply to whois + on promotion). */
interface LeaderPresentEnvelope {
  t: "leader";
  /** Identifies WHICH leader — changes on every migration, so followers can detect a new leader. */
  leaderId: string;
}

type ChannelEnvelope = RpcRequestEnvelope | RpcResponseEnvelope | WhoisEnvelope | LeaderPresentEnvelope;

interface PendingRpc {
  request: OfflineRpcRequest;
  resolve: (result: OfflineRpcResult) => void;
  reject: (reason: Error) => void;
  timer: ReturnType<typeof setTimeout>;
}

const LOCK_NAME = "kuika-offline-db-leader";
const CHANNEL_NAME = "kuika-offline-rpc";
/** How long a follower waits for the leader to answer one RPC before treating it as a lost leader. */
const RPC_TIMEOUT_MS = 15000;
/** How many times a follower re-sends an RPC across a suspected migration before giving up. */
const RPC_MAX_ATTEMPTS = 4;

/**
 * Elects a single leader tab (Web Locks) and routes DB operations to it (BroadcastChannel). The
 * adapter drives it: it supplies how to promote (spawn the worker) and how to execute locally.
 */
export class OfflineLeaderCoordinator {
  private role: Role = "pending";

  private channel: BroadcastChannel | null = null;

  private readonly tabId: string = crypto.randomUUID();

  private executor: LeaderExecutor | null = null;

  private promote: PromoteHandler | null = null;

  private readonly pending: Map<string, PendingRpc> = new Map();

  /** Resolves once this tab's role is known (leader promoted, or a leader confirmed to exist). */
  private roleKnown: Promise<void> | null = null;

  private resolveRoleKnown: (() => void) | null = null;

  /** Resolves the first time ANY leader announces itself (reply to our whois, or a fresh promotion). */
  private leaderSeen: Promise<void> | null = null;

  private resolveLeaderSeen: (() => void) | null = null;

  /** The id of the leader we currently believe serves us; a change signals a migration to react to. */
  private knownLeaderId: string | null = null;

  /** True when a supported environment (Web Locks + BroadcastChannel) — otherwise single-tab only. */
  static isSupported(): boolean {
    return typeof BroadcastChannel !== "undefined" && typeof navigator !== "undefined" && !!navigator.locks;
  }

  /**
   * Begin coordinating. Resolves once this tab knows its role AND (if leader) its worker is ready.
   * `executor` runs a request on the local worker; `promote` spawns + inits that worker.
   */
  async start(executor: LeaderExecutor, promote: PromoteHandler): Promise<void> {
    this.executor = executor;
    this.promote = promote;
    this.channel = new BroadcastChannel(CHANNEL_NAME);
    this.channel.onmessage = (event: MessageEvent<ChannelEnvelope>): void => {
      void this.onChannelMessage(event.data);
    };

    this.roleKnown = new Promise<void>((resolve: () => void): void => {
      this.resolveRoleKnown = resolve;
    });
    this.leaderSeen = new Promise<void>((resolve: () => void): void => {
      this.resolveLeaderSeen = resolve;
    });

    // Hold the leader lock for this tab's whole lifetime. The callback runs when we acquire it —
    // immediately if free (we are the first/only tab), or later when the current leader's tab closes
    // and releases it (migration). We never resolve the inner promise, so the lock is held until the
    // tab is torn down.
    void navigator.locks
      .request(LOCK_NAME, { mode: "exclusive" }, async (): Promise<void> => {
        await this.becomeLeader();
        await new Promise<void>((): void => {
          /* hold the lock until this tab dies */
        });
      })
      .catch((error: unknown): void => {
        const reason: string = error instanceof Error ? error.message : String(error);
        console.warn(`OfflineLeaderCoordinator: leader lock request failed — ${reason}`);
      });

    await this.settleInitialRole();
  }

  isLeader(): boolean {
    return this.role === "leader";
  }

  /**
   * Route one DB operation to wherever the leader is: run it locally when this tab is the leader,
   * otherwise send it to the leader over the channel (retrying across a migration).
   */
  async route(request: OfflineRpcRequest): Promise<OfflineRpcResult> {
    if (this.roleKnown) {
      await this.roleKnown;
    }
    if (this.role === "leader") {
      return this.runLocally(request);
    }
    return this.sendToLeaderWithRetry(request, RPC_MAX_ATTEMPTS);
  }

  // #region Leadership

  private async becomeLeader(): Promise<void> {
    if (this.promote) {
      try {
        await this.promote();
      } catch (error) {
        // Could not start the worker (e.g. OPFS error). Do NOT take leadership: become a follower,
        // resolve roleKnown so start() cannot hang, and rethrow so the Web Lock is released and the
        // next tab can try. We intentionally do not re-request the lock (that would loop forever).
        console.error("OfflineLeaderCoordinator: promote failed, releasing leadership", error);
        if (this.role !== "leader") {
          this.role = "follower";
          this.markRoleKnown();
        }
        throw error instanceof Error ? error : new Error(String(error));
      }
    }
    this.role = "leader";
    this.knownLeaderId = this.tabId;
    // Announce (with our id) so followers detect the (possibly new) leader and re-send lost requests.
    this.postToChannel({ t: "leader", leaderId: this.tabId });
    this.markRoleKnown();
    // We may have been a follower with requests in flight to the now-dead leader — run them locally.
    this.drainPendingLocally();
  }

  /**
   * Decide the initial role. Settle as soon as EITHER we are promoted (we acquired the lock) OR some
   * leader announces itself. We prompt any existing leader with a whois first (in case we missed its
   * original announcement). Crucially there is NO timeout: promoting a leader spawns the .NET worker
   * and can take seconds, so a follower must keep waiting rather than wrongly give up and deadlock.
   */
  private async settleInitialRole(): Promise<void> {
    // Read through explicitly-typed locals: the lock callback can promote us to leader DURING the
    // awaits below, which TS's control-flow narrowing cannot see (it would wrongly narrow `this.role`).
    const roleAtStart: Role = this.role;
    if (roleAtStart === "leader") {
      return;
    }

    const roleKnown: Promise<void> = this.roleKnown ?? Promise.resolve();
    const leaderSeen: Promise<void> = this.leaderSeen ?? Promise.resolve();

    // Ask any live leader to (re)announce; a fresh promotion elsewhere also resolves leaderSeen.
    this.postToChannel({ t: "whois", from: this.tabId });
    await Promise.race([roleKnown, leaderSeen]);

    const settled: Role = this.role;
    if (settled === "leader") {
      return;
    }
    this.role = "follower";
    this.markRoleKnown();
  }

  private markRoleKnown(): void {
    if (this.resolveRoleKnown) {
      this.resolveRoleKnown();
      this.resolveRoleKnown = null;
    }
  }

  // #endregion Leadership

  // #region RPC

  private async runLocally(request: OfflineRpcRequest): Promise<OfflineRpcResult> {
    if (!this.executor) {
      return { ok: false, error: "OfflineLeaderCoordinator: no local executor" };
    }
    return this.executor(request);
  }

  private async sendToLeaderWithRetry(request: OfflineRpcRequest, attempts: number): Promise<OfflineRpcResult> {
    try {
      return await this.sendToLeader(request);
    } catch (error) {
      // A timeout usually means the leader tab closed and a new one is being elected. If WE were just
      // promoted, run it locally; otherwise wait for the new leader's announcement and re-send.
      if (this.role === "leader") {
        return this.runLocally(request);
      }
      if (attempts <= 1) {
        throw error instanceof Error ? error : new Error(String(error));
      }
      await this.delay(200);
      return this.sendToLeaderWithRetry(request, attempts - 1);
    }
  }

  private sendToLeader(request: OfflineRpcRequest): Promise<OfflineRpcResult> {
    const reqId: string = crypto.randomUUID();
    return new Promise<OfflineRpcResult>(
      (resolve: (result: OfflineRpcResult) => void, reject: (reason: Error) => void): void => {
        const timer: ReturnType<typeof setTimeout> = setTimeout((): void => {
          if (this.pending.delete(reqId)) {
            reject(new Error("OfflineLeaderCoordinator: RPC to leader timed out"));
          }
        }, RPC_TIMEOUT_MS);
        this.pending.set(reqId, { request, resolve, reject, timer });
        this.postToChannel({ t: "req", reqId, from: this.tabId, request });
      }
    );
  }

  /** Run every in-flight request on the local worker (used right after WE become the leader). */
  private drainPendingLocally(): void {
    if (this.pending.size === 0) {
      return;
    }
    const entries: [string, PendingRpc][] = [...this.pending.entries()];
    this.pending.clear();
    for (const [, waiting] of entries) {
      clearTimeout(waiting.timer);
      void this.runLocally(waiting.request).then(waiting.resolve, waiting.reject);
    }
  }

  /** Re-send every in-flight request to the (new) leader — used when a migration is detected. */
  private resendPending(): void {
    for (const [reqId, waiting] of this.pending) {
      clearTimeout(waiting.timer);
      waiting.timer = setTimeout((): void => {
        if (this.pending.delete(reqId)) {
          waiting.reject(new Error("OfflineLeaderCoordinator: RPC to leader timed out"));
        }
      }, RPC_TIMEOUT_MS);
      this.postToChannel({ t: "req", reqId, from: this.tabId, request: waiting.request });
    }
  }

  private async onChannelMessage(message: ChannelEnvelope): Promise<void> {
    if (message.t === "req") {
      if (this.role !== "leader") {
        return; // only the leader answers
      }
      const result: OfflineRpcResult = await this.runLocally(message.request);
      this.postToChannel({ t: "res", reqId: message.reqId, to: message.from, result });
      return;
    }

    if (message.t === "res") {
      if (message.to !== this.tabId) {
        return;
      }
      const waiting: PendingRpc | undefined = this.pending.get(message.reqId);
      if (waiting) {
        this.pending.delete(message.reqId);
        clearTimeout(waiting.timer);
        waiting.resolve(message.result);
      }
      return;
    }

    if (message.t === "whois") {
      if (this.role === "leader") {
        this.postToChannel({ t: "leader", leaderId: this.tabId });
      }
      return;
    }

    // message.t === "leader": a leader is present (reply to our whois, or a fresh promotion). It is
    // the signal a follower waits on to settle its role.
    if (this.resolveLeaderSeen) {
      this.resolveLeaderSeen();
      this.resolveLeaderSeen = null;
    }
    // A DIFFERENT leader id means a migration happened — re-send our in-flight requests to the new
    // leader immediately (instead of waiting out the RPC timeout). Gated on the id so a routine
    // re-announcement (another tab's whois) never triggers a spurious re-send / double-execute.
    if (message.leaderId !== this.knownLeaderId) {
      this.knownLeaderId = message.leaderId;
      if (this.role === "follower" && this.pending.size > 0) {
        this.resendPending();
      }
    }
  }

  private postToChannel(message: ChannelEnvelope): void {
    if (this.channel) {
      this.channel.postMessage(message);
    }
  }

  private delay(ms: number): Promise<void> {
    return new Promise<void>((resolve: () => void): void => {
      setTimeout(resolve, ms);
    });
  }

  // #endregion RPC
}
