import { GoogleTokenResponse } from "@kuika/kuika-cl-model";
import Axios, { AxiosResponse } from "axios";
import _ from "lodash";
import {
  deleteCsrfMirrorForUrl,
  deleteLoginStateCookie,
  readLoginStateCookie,
  setLoginStateCookie,
  writeCsrfMirrorForUrl
} from "../auth/cookie-utils";
import LocalStorageService from "../auth/local-storage-service";
import { IChangePasswordDto } from "../models/dto/change-password.dto";
import { ICreateUserWithPasswordDto } from "../models/dto/create-user-with-password";
import { ICreateUserDto } from "../models/dto/createuser";
import { IForgotPasswordDto } from "../models/dto/forgotpassword.dto";
import { IChangeTwoFactorAuthenticationType } from "../models/dto/IChangeTwoFactorAuthenticationType.dto";
import {
  IExternalTokenRequest,
  IIssueMfeTokenResponse,
  ILoginDto,
  IReLoginWithDelegationDto
} from "../models/dto/login.dto";
import { IRegisterDeviceDto } from "../models/dto/register-device.dto";
import { IResetPasswordWithTokenDto } from "../models/dto/reset-password-with-token";
import { ISignupDto } from "../models/dto/signup.dto";
import { IUpdateUserStartingScreen } from "../models/dto/update-user-starting-screen.dto";
import { IUpdateUsernameDto } from "../models/dto/update-username.dto";
import { IUserInfoDto } from "../models/dto/user-info.dto";
import { IUserRoleDto } from "../models/dto/userrole.dto";
import { IVerifyVerificationCodeDto } from "../models/dto/verify-verification-code.dto";
import { CheckResultType } from "../models/enum/auth";
import { KuikaAppManager } from "../shared/utilty/kuika-app-manager";
import { KMainFunctions } from "../shared/utilty/main-functions";
import { ReactSystemFunctions } from "../shared/utilty/react-system-functions";
import { cryptoCompat } from "./crypto-compat-service";
import HelperService from "./helper-service";
import { subscribeUser } from "./notification-service";
import SecureCacheService from "./secure-cache-service";

const backendUrl = KuikaAppManager.GetBackendUrl();
const USER_INFO_CACHE_KEY = "kuika_secure_user_info";
const secureCache = SecureCacheService.getInstance();

declare let window: Window & { userInfo: IUserInfoDto };

export class UserService {
  public static async Login(user: ILoginDto): Promise<AxiosResponse> {
    try {
      const res = await Axios.post<ILoginDto, AxiosResponse>(`${backendUrl}/auth/login`, user);
      const result = UserService.ProcessLoginResult(res);
      return await result;
    } catch (error: any) {
      if (
        error?.response?.data?.message === "Your password has expired" ||
        error?.response?.data?.message === "Şifrenizin süresi doldu" ||
        error?.response?.data?.message === "Votre mot de passe a expiré"
      ) {
        throw new Error(error.response.data.message);
      }

      KMainFunctions.exceptionHandler(error);
      return error;
    }
  }

  public static async ReLoginWithDelegation(
    reLoginWithDelegationDto: IReLoginWithDelegationDto
  ): Promise<AxiosResponse> {
    try {
      const res = await Axios.post<ILoginDto, AxiosResponse>(
        `${backendUrl}/auth/relogin-with-delegation`,
        reLoginWithDelegationDto
      );
      const result = UserService.ProcessLoginResult(res);
      return await result;
    } catch (error: any) {
      if (
        error?.response?.data?.message === "Your password has expired" ||
        error?.response?.data?.message === "Şifrenizin süresi doldu" ||
        error?.response?.data?.message === "Votre mot de passe a expiré"
      ) {
        throw new Error(error.response.data.message);
      }

      KMainFunctions.exceptionHandler(error);
      return error;
    }
  }

  public static async ReturnToUserSessionFromDelegation(): Promise<AxiosResponse> {
    try {
      const res = await Axios.post<ILoginDto, AxiosResponse>(
        `${backendUrl}/auth/return-to-user-session-from-delegation`
      );
      const result = UserService.ProcessLoginResult(res);
      return await result;
    } catch (error: any) {
      if (
        error?.response?.data?.message === "Your password has expired" ||
        error?.response?.data?.message === "Şifrenizin süresi doldu" ||
        error?.response?.data?.message === "Votre mot de passe a expiré"
      ) {
        throw new Error(error.response.data.message);
      }

      KMainFunctions.exceptionHandler(error);
      return error;
    }
  }

  public static async GetRSALoginKey(username: string): Promise<string> {
    try {
      const res = await Axios.get<any, AxiosResponse>(
        `${backendUrl}/auth/rsaloginkey?username=${encodeURIComponent(username)}`
      );
      if (res.status === 200 && res.data.publicKey) {
        return res.data.publicKey;
      }
      throw new Error("Failed to get RSA key");
    } catch (error: any) {
      KMainFunctions.exceptionHandler(error);
      throw error;
    }
  }

  public static async EncryptedLogin(user: ILoginDto): Promise<AxiosResponse> {
    try {
      const publicKey = await UserService.GetRSALoginKey(user.username);

      // RSA-OAEP-SHA256 encrypt the password against the server's SPKI public key.
      // Routes through cryptoCompat so it works on both HTTPS (Web Crypto) and
      // HTTP (node-forge fallback) — see crypto-compat-service.ts.
      const encryptedPasswordBase64 = await cryptoCompat.rsaOaepEncryptSpkiBase64(publicKey, user.password);

      // Send encrypted password
      const encryptedUser = {
        username: user.username,
        password: encryptedPasswordBase64
      };

      const res = await Axios.post<ILoginDto, AxiosResponse>(`${backendUrl}/auth/login`, encryptedUser);
      const result = UserService.ProcessLoginResult(res);
      return await result;
    } catch (error: any) {
      if (
        error?.response?.data?.message === "Your password has expired" ||
        error?.response?.data?.message === "Şifrenizin süresi doldu" ||
        error?.response?.data?.message === "Votre mot de passe a expiré"
      ) {
        throw new Error(error.response.data.message);
      }

      KMainFunctions.exceptionHandler(error);
      return error;
    }
  }

  public static async LoginWithVerificationCode(user: any): Promise<AxiosResponse> {
    try {
      const res = await Axios.post<ILoginDto, AxiosResponse>(`${backendUrl}/auth/loginwithverificationcode`, user);
      LocalStorageService.setVerificationStatus("true");
      LocalStorageService.setVerificationUserName("");
      const result = UserService.ProcessLoginResult(res);
      return await result;
    } catch (error: any) {
      KMainFunctions.exceptionHandler(error);
      return error;
    }
  }

  /**
   * Throws on failure. A login helper that resolves with the error object leaves
   * callers unable to tell success from failure — `res.status` is simply
   * undefined — which is how an MFE handoff could sit on its "please wait"
   * placeholder forever. Callers own the messaging.
   */
  public static async LoginWithExternalToken(externalTokenRequest: IExternalTokenRequest): Promise<AxiosResponse> {
    const res = await Axios.post<ILoginDto, AxiosResponse>(`${backendUrl}/auth/loginwithtoken`, externalTokenRequest);
    return await UserService.ProcessLoginResult(res);
  }

  public static async IssueMfeToken(hostBackendUrl: string): Promise<string | null> {
    try {
      const res = await Axios.post<IIssueMfeTokenResponse, AxiosResponse<IIssueMfeTokenResponse>>(
        `${hostBackendUrl}/auth/issue-mfe-token`,
        {},
        { withCredentials: true }
      );
      if (res?.status === 200 && res.data?.token) {
        return res.data.token;
      }
      return null;
    } catch {
      return null;
    }
  }

  /** Throws on failure — see LoginWithExternalToken. */
  public static async LoginWithMfeToken(mfeToken: string): Promise<AxiosResponse> {
    const res = await Axios.post<ILoginDto, AxiosResponse>(`${backendUrl}/auth/loginwithmfetoken`, {
      token: mfeToken
    });
    return await UserService.ProcessLoginResult(res);
  }

  private static async ProcessLoginResult(res: AxiosResponse<any>): Promise<AxiosResponse> {
    if (res && res.status === 200) {
      if (res.data.status === 2) {
        return res;
      }
      // HttpOnly auth cookies (access_token, refresh_token) are set by the server.
      // JS-readable cookies must be set on the frontend domain so document.cookie
      // can read them — the server-set copies are scoped to the API subdomain and
      // invisible to JS when frontend/backend are on different subdomains.
      const THIRTY_DAYS = 30 * 24 * 60 * 60;
      const loginStateKey: string = KuikaAppManager.getLoginStateCookieKey();
      setLoginStateCookie("is_logged_in", "1", THIRTY_DAYS, loginStateKey);
      if (!readLoginStateCookie("session_id", loginStateKey)) {
        setLoginStateCookie("session_id", cryptoCompat.randomUUID(), THIRTY_DAYS, loginStateKey);
      }
      // csrf_token: backend also sets the same value as a cookie on the API
      // host so it auto-attaches to API requests, AND echoes it in this
      // response body so the SPA can mirror it onto the frontend host. The
      // axios request interceptor reads this frontend-host copy via
      // document.cookie and forwards it as X-CSRF-Token. Without this mirror,
      // document.cookie sees nothing on the frontend domain and the header
      // is never sent → CsrfMiddleware rejects with 403. Mirror is keyed on
      // the login endpoint's API host so a microapp shell talking to several
      // microapp APIs keeps one mirror per API instead of overwriting a
      // single bare cookie at every cross-microapp navigation.
      const csrfToken: string | undefined = res.data?.csrfToken;
      if (csrfToken) {
        writeCsrfMirrorForUrl(res.config?.url, csrfToken, THIRTY_DAYS);
      }
      LocalStorageService.setUserLanguage(res.data);
      LocalStorageService.setLoginStatus(res.data.status);
      if (window.userInfo === undefined) {
        if (res.data.status === 0) {
          const userInfo = await UserService.GetUserInfo();
          if (userInfo?.username) {
            subscribeUser(userInfo.username);
          }
        }
      }

      res.data?.passwordValidationResult?.checkResults?.forEach((result) => {
        if (result.resultType === CheckResultType.Warning) {
          KMainFunctions.displayWarningNotification(result.message);
        }
      });
    }

    return res;
  }

  public static async SignUp(user: ISignupDto): Promise<AxiosResponse> {
    try {
      return await Axios.post<ISignupDto, AxiosResponse>(`${backendUrl}/auth/signup`, user);
    } catch (error: any) {
      KMainFunctions.exceptionHandler(error);
      return error;
    }
  }

  public static async VerifyVerificationCode(obj: IVerifyVerificationCodeDto): Promise<AxiosResponse> {
    try {
      return await Axios.post<IChangePasswordDto, AxiosResponse>(`${backendUrl}/auth/isverificationcodevalid`, obj);
    } catch (error: any) {
      KMainFunctions.exceptionHandler(error);
      return error;
    }
  }

  public static async ResetPasswordWithToken(user: IResetPasswordWithTokenDto): Promise<AxiosResponse> {
    try {
      return await Axios.post<ILoginDto, AxiosResponse>(`${backendUrl}/auth/resetpasswordwithtoken`, user);
    } catch (error: any) {
      KMainFunctions.exceptionHandler(error);
      return error;
    }
  }

  public static async CreateUser(user: ICreateUserDto): Promise<string> {
    try {
      await Axios.post<ICreateUserDto, AxiosResponse>(`${backendUrl}/auth/createuser`, user);
      return "";
    } catch (error: any) {
      KMainFunctions.exceptionHandler(error);
      if (error && error.response && error.response.data) {
        return error.response.data.message;
      }
      return "An error has been occurred. Please try again.";
    }
  }

  public static async CreateUserWithPassword(user: ICreateUserWithPasswordDto): Promise<string> {
    try {
      await Axios.post<ICreateUserWithPasswordDto, AxiosResponse>(`${backendUrl}/auth/createuserwithpassword`, user);
      return "";
    } catch (error: any) {
      KMainFunctions.exceptionHandler(error);
      if (error && error.response && error.response.data) {
        return error.response.data.message;
      }
      return "An error has been occurred. Please try again.";
    }
  }

  public static async ForgotPassword(user: IForgotPasswordDto): Promise<AxiosResponse> {
    try {
      const result = await Axios.post<IForgotPasswordDto, AxiosResponse>(`${backendUrl}/auth/forgotpassword`, user);
      LocalStorageService.setForgotPasswordEmail(user.email);
      return result;
    } catch (error: any) {
      LocalStorageService.setForgotPasswordEmail("");
      KMainFunctions.exceptionHandler(error);
      return error;
    }
  }

  public static async ResetPassword(user: IResetPasswordWithTokenDto): Promise<AxiosResponse> {
    try {
      return await Axios.post<IResetPasswordWithTokenDto, AxiosResponse>(
        `${backendUrl}/auth/resetpasswordwithtoken`,
        user
      );
    } catch (error: any) {
      KMainFunctions.exceptionHandler(error);
      return error;
    }
  }

  public static getEmailToResetPassword(): any {
    return LocalStorageService.getForgotPasswordEmail();
  }

  public static async Logout(): Promise<void> {
    try {
      var request = indexedDB.open("msalDb", 1);
      request.onupgradeneeded = function (event: any) {
        var db = event.target.result;
        var objectStore = db.createObjectStore("logingout", { keyPath: "id" });
        objectStore.add({ id: 1, status: "true" });
      };
      await Axios.post<ILoginDto, AxiosResponse>(`${backendUrl}/auth/logout`, {});
      // Server clears HttpOnly cookies in the response.
      const loginStateKey: string = KuikaAppManager.getLoginStateCookieKey();
      deleteLoginStateCookie("is_logged_in", loginStateKey);
      deleteLoginStateCookie("session_id", loginStateKey);
      deleteCsrfMirrorForUrl(backendUrl);
      LocalStorageService.setLoginStatus(null);
      // Clear cached user info (secure cache)
      secureCache.remove(USER_INFO_CACHE_KEY);
      secureCache.clearKeyCache();
      window.userInfo = undefined;

      // Notify any embedding host (MFE wrapper) so it cascades the logout
      // to its own session. In MFE context the microapp's logout only
      // clears microapp api and shared frontend cookies; without this
      // signal the host stays logged in and bounces redirects to /signin
      // back to the host's starting screen. Stand-alone runs are no-op.
      try {
        window.dispatchEvent(new CustomEvent("kuika-mfe-logout-requested"));
      } catch {
        // CustomEvent unsupported in very old runtimes; ignore.
      }
    } catch (error: any) {
      KMainFunctions.exceptionHandler(error);
    }
  }

  public static async ChangePassword(obj: IChangePasswordDto): Promise<AxiosResponse> {
    try {
      return await Axios.post<IChangePasswordDto, AxiosResponse>(`${backendUrl}/auth/changepassword`, obj);
    } catch (error: any) {
      KMainFunctions.exceptionHandler(error);
      return error;
    }
  }

  public static async GetUserInfo(): Promise<IUserInfoDto> {
    // Return memory cache if available
    if (window?.userInfo?.username) {
      return window.userInfo as IUserInfoDto;
    }

    // Check offline first - use secure cache immediately
    const isOnline: boolean = await ReactSystemFunctions.isOnline();
    if (!isOnline) {
      const cached: IUserInfoDto | null = await secureCache.get<IUserInfoDto>(USER_INFO_CACHE_KEY);
      if (cached) {
        window.userInfo = cached;
        return window.userInfo;
      }
      // No cache available offline - return undefined (don't block)
      return undefined as any;
    }

    try {
      const res: AxiosResponse = await Axios.get<null, AxiosResponse>(`${backendUrl}/auth/userinfo`);
      if (res && res.status === 200) {
        window.userInfo = res.data as IUserInfoDto;
        // Cache successful response securely (encrypted with token-derived key)
        await secureCache.set(USER_INFO_CACHE_KEY, res.data);
      }
    } catch (error) {
      // On error, try secure cache
      const cached = await secureCache.get<IUserInfoDto>(USER_INFO_CACHE_KEY);
      if (cached) {
        window.userInfo = cached;
        return window.userInfo;
      }

      window.userInfo = undefined;

      if (error?.response?.status && error.response.status !== 401 && error.response.status >= 400) {
        const loginStateKey: string = KuikaAppManager.getLoginStateCookieKey();
        deleteLoginStateCookie("is_logged_in", loginStateKey);
        deleteLoginStateCookie("session_id", loginStateKey);
        deleteCsrfMirrorForUrl(backendUrl);
        HelperService.gotoLogin();
      }

      // KMainFunctions.exceptionHandler(error);
      return error;
    }
    return window.userInfo as IUserInfoDto;
  }

  public static async GetUserInfoForce(): Promise<any> {
    // Check offline first - use secure cache immediately
    const isOnline: boolean = await ReactSystemFunctions.isOnline();
    if (!isOnline) {
      const cached = await secureCache.get<IUserInfoDto>(USER_INFO_CACHE_KEY);
      if (cached) {
        window.userInfo = cached;
        return window.userInfo;
      }
      // No cache available offline - return undefined (don't block)
      return undefined;
    }

    try {
      const res = await Axios.get<null, AxiosResponse>(`${backendUrl}/auth/userinfo`);
      if (res && res.status === 200) {
        if (res?.data?.userLogoutMessage?.length > 0) {
          KMainFunctions.displayWarningNotification(res?.data?.userLogoutMessage);
          setTimeout(() => {
            UserService.Logout();
          }, 3000);
          return;
        }
        window.userInfo = res.data;
        LocalStorageService.setCurrentDomain(res.data.lastUsedDomainName);
        // Cache successful response securely (encrypted with token-derived key)
        await secureCache.set(USER_INFO_CACHE_KEY, res.data);
        return window.userInfo;
      }
    } catch (error: any) {
      // On error, try secure cache
      const cached = await secureCache.get<IUserInfoDto>(USER_INFO_CACHE_KEY);
      if (cached) {
        window.userInfo = cached;
        return window.userInfo;
      }

      window.userInfo = undefined;
      KMainFunctions.exceptionHandler(error);
      return error;
    }
  }

  public static async AddUserToRole(obj: IUserRoleDto): Promise<AxiosResponse> {
    try {
      return await Axios.post<IUserRoleDto, AxiosResponse>(`${backendUrl}/authorization/addusertorole`, obj);
    } catch (error: any) {
      KMainFunctions.exceptionHandler(error);
      return error;
    }
  }

  public static async RemoveUserFromRole(obj: IUserRoleDto): Promise<AxiosResponse> {
    try {
      return await Axios.post<IUserRoleDto, AxiosResponse>(`${backendUrl}/authorization/removeuserfromrole`, obj);
    } catch (error: any) {
      KMainFunctions.exceptionHandler(error);
      return error;
    }
  }

  public static async EnableUser(userName: string): Promise<AxiosResponse> {
    try {
      return await Axios.put<null, AxiosResponse>(`${backendUrl}/auth/enableuser`, { email: userName });
    } catch (error: any) {
      KMainFunctions.exceptionHandler(error);
      return error;
    }
  }

  public static async DisableUser(userName: string): Promise<AxiosResponse> {
    try {
      return await Axios.put<null, AxiosResponse>(`${backendUrl}/auth/disableuser`, { email: userName });
    } catch (error: any) {
      KMainFunctions.exceptionHandler(error);
      return error;
    }
  }

  public static async UpdateUserName(obj: IUpdateUsernameDto): Promise<AxiosResponse> {
    try {
      return await Axios.post<null, AxiosResponse>(`${backendUrl}/auth/updateusername`, obj);
    } catch (error: any) {
      KMainFunctions.exceptionHandler(error);
      return error;
    }
  }

  public static async UpdateUserStartingScreen(obj: IUpdateUserStartingScreen): Promise<AxiosResponse> {
    try {
      return await Axios.post<null, AxiosResponse>(`${backendUrl}/auth/updateuserstartingscreen`, obj);
    } catch (error: any) {
      KMainFunctions.exceptionHandler(error);
      return error;
    }
  }

  public static async ValidateToken(): Promise<AxiosResponse> {
    try {
      return await Axios.post<null, AxiosResponse>(`${backendUrl}/auth/validatetoken`);
    } catch (error: any) {
      KMainFunctions.exceptionHandler(error);
      return error;
    }
  }

  public static async AuthenticateWithGoogle(authCode: string): Promise<AxiosResponse<GoogleTokenResponse>> {
    try {
      return await Axios.post<null, AxiosResponse<GoogleTokenResponse>>(`${backendUrl}/auth/authenticatewithgoogle`, {
        authCode,
        redirectUri: location.origin
      });
    } catch (error: any) {
      KMainFunctions.exceptionHandler(error);
      return error;
    }
  }

  public static async SendVerificationCode(obj: IForgotPasswordDto) {
    try {
      return await Axios.post<IForgotPasswordDto, AxiosResponse>(`${backendUrl}/auth/sendverificationcode`, obj);
    } catch (error) {
      KMainFunctions.exceptionHandler(error);
      return error;
    }
  }

  public static async ChangeTwoFactorAuthenticationType(obj: IChangeTwoFactorAuthenticationType) {
    try {
      return await Axios.post<AxiosResponse>(`${backendUrl}/auth/changetwofactorauthenticationtype`, obj);
    } catch (error) {
      KMainFunctions.exceptionHandler(error);
      return error;
    }
  }

  public static async GetIsTokenValid(): Promise<boolean> {
    try {
      const isLoggedIn = readLoginStateCookie("is_logged_in", KuikaAppManager.getLoginStateCookieKey()) === "1";

      if (!isLoggedIn) {
        return false;
      }

      const res = await Axios.post<{ token: string }, AxiosResponse>(
        `${backendUrl}/auth/getistokenvalid`,
        {},
        { withCredentials: true }
      );

      if (res?.data?.isValid === false) {
        return false;
      }
      return true;
    } catch (error: any) {
      return true;
    }
  }

  public static async RegisterDevice(obj: IRegisterDeviceDto) {
    try {
      return await Axios.post<AxiosResponse>(`${backendUrl}/Notification/registerDevice`, obj);
    } catch (error) {
      KMainFunctions.exceptionHandler(error);
      return error;
    }
  }
}
