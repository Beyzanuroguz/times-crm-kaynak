/**
 * Secure cache service using AES-GCM authenticated encryption.
 * Data is encrypted with AES-256-GCM using a key derived from the access token.
 * This prevents users from modifying cached data even if they inspect localStorage.
 *
 * Security features:
 * - AES-256-GCM encryption (authenticated encryption)
 * - Key derived from access token using PBKDF2-SHA256
 * - Random IV for each encryption
 * - Timestamp to detect stale data
 * - Automatic invalidation if token changes
 *
 * Crypto path:
 * - Uses Web Crypto (`crypto.subtle`) when available (HTTPS or localhost)
 * - Falls back to a pure-JS implementation (node-forge) on insecure contexts (HTTP),
 *   keeping the on-disk wire format identical so entries are interchangeable.
 */

import { KuikaAppManager } from "../shared/utilty/kuika-app-manager";
import { cryptoCompat } from "./crypto-compat-service";

interface SecureCacheEntry {
  iv: string; // Base64 encoded IV
  data: string; // Base64 encoded encrypted data (ciphertext || GCM tag)
  ts: number; // Timestamp
  th: string; // Token hash (first 16 chars of token hash for verification)
}

const SALT = new Uint8Array([75, 85, 73, 75, 65, 95, 83, 69, 67, 85, 82, 69, 95, 67, 65, 67, 72, 69]); // "KUIKA_SECURE_CACHE"
const PBKDF2_ITERATIONS = 100000;
const AES_KEY_BYTES = 32; // AES-256

class SecureCacheService {
  private static instance: SecureCacheService;

  private keyCache: Map<string, Uint8Array> = new Map();

  private constructor() {}

  public static getInstance(): SecureCacheService {
    if (!SecureCacheService.instance) {
      SecureCacheService.instance = new SecureCacheService();
    }
    return SecureCacheService.instance;
  }

  /**
   * Derive an encryption key from the access token using PBKDF2-SHA256.
   */
  private async deriveKey(token: string): Promise<Uint8Array> {
    const tokenHash = await this.hashToken(token);
    const cached = this.keyCache.get(tokenHash);
    if (cached) {
      return cached;
    }

    const passwordBytes = new TextEncoder().encode(token);
    const key = await cryptoCompat.pbkdf2Sha256(passwordBytes, SALT, PBKDF2_ITERATIONS, AES_KEY_BYTES);

    this.keyCache.set(tokenHash, key);
    return key;
  }

  /**
   * Hash the token to create a verification string.
   */
  private async hashToken(token: string): Promise<string> {
    const hashHex = await cryptoCompat.sha256Hex(token);
    return hashHex.substring(0, 16);
  }

  /**
   * Encrypt and store data securely.
   */
  public async set<T>(key: string, value: T): Promise<boolean> {
    try {
      const token = KuikaAppManager.readLoginStateCookie("session_id");
      if (!token) {
        return false;
      }

      const aesKey = await this.deriveKey(token);
      const iv = new Uint8Array(12);
      crypto.getRandomValues(iv);
      const plaintext = new TextEncoder().encode(JSON.stringify(value));

      const ciphertext = await cryptoCompat.aesGcmEncrypt(aesKey, iv, plaintext);

      const entry: SecureCacheEntry = {
        iv: cryptoCompat.uint8ToBase64(iv),
        data: cryptoCompat.uint8ToBase64(ciphertext),
        ts: Date.now(),
        th: await this.hashToken(token)
      };

      localStorage.setItem(key, JSON.stringify(entry));
      return true;
    } catch (e) {
      // Encryption failed or localStorage unavailable
      return false;
    }
  }

  /**
   * Retrieve and decrypt data securely.
   * Returns null if data is missing, tampered with, or token has changed.
   */
  public async get<T>(key: string): Promise<T | null> {
    try {
      const token = KuikaAppManager.readLoginStateCookie("session_id");
      if (!token) {
        return null;
      }

      const stored = localStorage.getItem(key);
      if (!stored) {
        return null;
      }

      const entry: SecureCacheEntry = JSON.parse(stored);

      // Verify token hash matches (prevents using old cached data with new token)
      const currentTokenHash = await this.hashToken(token);
      if (entry.th !== currentTokenHash) {
        // Token changed, invalidate cache
        localStorage.removeItem(key);
        return null;
      }

      const aesKey = await this.deriveKey(token);
      const iv = cryptoCompat.base64ToUint8(entry.iv);
      const ciphertext = cryptoCompat.base64ToUint8(entry.data);

      const plaintext = await cryptoCompat.aesGcmDecrypt(aesKey, iv, ciphertext);

      const json = new TextDecoder().decode(plaintext);
      return JSON.parse(json) as T;
    } catch (e) {
      // Decryption failed - data was tampered with or corrupted
      // Remove the invalid entry
      try {
        localStorage.removeItem(key);
      } catch {}
      return null;
    }
  }

  /**
   * Remove cached data.
   */
  public remove(key: string): void {
    try {
      localStorage.removeItem(key);
    } catch {}
  }

  /**
   * Clear the key cache (call on logout).
   */
  public clearKeyCache(): void {
    this.keyCache.clear();
  }
}

export default SecureCacheService;
