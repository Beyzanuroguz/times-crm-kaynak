import Axios, { AxiosResponse } from "axios";
import { OpenAIChatDto } from "../models/dto/openai.dto";
import { KuikaAppManager } from "../shared/utilty/kuika-app-manager";
import { KMainFunctions } from "../shared/utilty/main-functions";

const backendUrl = KuikaAppManager.GetBackendUrl();

export class OpenAIService {
  public static async Chat(request: OpenAIChatDto): Promise<AxiosResponse<string>> {
    try {
      return await Axios.post<null, AxiosResponse>(`${backendUrl}/OpenAI/chat`, request);
    } catch (error: any) {
      KMainFunctions.exceptionHandler(error);
      return error;
    }
  }
}
