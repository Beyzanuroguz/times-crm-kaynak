import Axios from "axios";
import { KuikaAppManager } from "../shared/utilty/kuika-app-manager";

interface ITableConfigResponse {
  configJson?: string;
  ConfigJson?: string;
}

// Per-user table view-preference persistence (column order/visibility/width, filter, sort, search).
// Backed by the KTableConfig system table via the generated TableConfigController. Auth/CSRF ride the
// global axios interceptors (HttpOnly cookies), so no per-call headers are needed. All failures are
// swallowed to "" / no-op: persistence must never break table rendering.
//
// GetBackendUrl() is resolved lazily inside each method (not at module load): base-table imports this
// service, so a module-load side effect would run before window.location is ready in some test/SSR
// contexts (and it's cheap to resolve per call).
export class TableConfigService {
  public static async getTableConfig(screenId: string, tableId: string): Promise<string> {
    try {
      const backendUrl = KuikaAppManager.GetBackendUrl();
      const url = `${backendUrl}/TableConfig/gettableconfig?screenId=${encodeURIComponent(
        screenId
      )}&tableId=${encodeURIComponent(tableId)}`;
      const response = await Axios.get<ITableConfigResponse>(url);
      return response?.data?.configJson ?? response?.data?.ConfigJson ?? "";
    } catch {
      return "";
    }
  }

  public static async saveTableConfig(screenId: string, tableId: string, configJson: string): Promise<void> {
    try {
      const backendUrl = KuikaAppManager.GetBackendUrl();
      await Axios.post(`${backendUrl}/TableConfig/savetableconfig`, {
        screenId,
        tableId,
        configJson
      });
    } catch {
      // best-effort; a failed save must not surface to the user
    }
  }
}
