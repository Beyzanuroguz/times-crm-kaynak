import Axios, { AxiosResponse } from "axios";
import { KuikaAppManager } from "../shared/utilty/kuika-app-manager";
import { KMainFunctions } from "../shared/utilty/main-functions";

const backendUrl = KuikaAppManager.GetBackendUrl();

class ServerFilesService {
  public static async DownloadFile(fileId: string, filename): Promise<AxiosResponse<string>> {
    const data = {
      fileId // Update with the actual file name
    };
    try {
      const res = await Axios.post<null, AxiosResponse>(`${backendUrl}/resource/download`, data, {
        responseType: "blob" // important for handling binary data
      });
      KMainFunctions.downloadFile(res.data, filename);
    } catch (error: any) {
      if (error.response && error.response.data instanceof Blob) {
        try {
          const text = await error.response.data.text();
          const json = JSON.parse(text);

          KMainFunctions.exceptionHandler(json);
          return json;
        } catch (e) {
          KMainFunctions.displayWarningNotification("Failed to parse error");
        }
      }
      KMainFunctions.exceptionHandler(error);
      return error;
    }
  }

  public static async DownloadFileFromBucket(
    keyName: string,
    bucketName: string,
    fileName: string,
    encrypt: boolean
  ): Promise<AxiosResponse<string>> {
    const data = {
      keyName,
      bucketName,
      fileName,
      encrypt
    };
    try {
      const res = await Axios.post<null, AxiosResponse>(`${backendUrl}/resource/downloadFromBucket`, data);
      KMainFunctions.downloadFile(res.data, fileName);
    } catch (error: any) {
      if (error.response && error.response.data instanceof Blob) {
        try {
          const text = await error.response.data.text();
          const json = JSON.parse(text);

          KMainFunctions.exceptionHandler(json);
          return json;
        } catch (e) {
          KMainFunctions.displayWarningNotification("Failed to parse error");
        }
      }
      KMainFunctions.exceptionHandler(error);
      return error;
    }
  }

  public static async DeleteFile(fileId: string): Promise<AxiosResponse<string>> {
    const data = {
      fileId // Update with the actual file name
    };
    try {
      const res = await Axios.post<null, AxiosResponse>(`${backendUrl}/resource/delete`, data);
      return res.data;
    } catch (error: any) {
      KMainFunctions.exceptionHandler(error);
      return error;
    }
  }

  // Deletes a file previously uploaded to the project-configured bucket
  // (e.g. via BigFileUpload in bucket mode). Provider and encryption are
  // resolved server-side; only the object key returned at upload time is sent.
  public static async DeleteFileFromBucket(objectKey: string): Promise<void> {
    const data = {
      objectKey
    };
    try {
      await Axios.post<null, AxiosResponse>(`${backendUrl}/resource/deleteFromBucket`, data);
    } catch (error) {
      KMainFunctions.exceptionHandler(error);
    }
  }
}

export default ServerFilesService;
