/**
 * Bridge service for Kuika Core WASM module.
 * Uses adapter pattern to support both browser and Electron environments.
 *
 * In browser: Uses .NET browser-wasm with [JSExport] for direct JavaScript interop.
 * In Electron: Uses IPC to communicate with node-wasm running in main process.
 *
 * Database is imported/exported as a complete unit - no schema generation.
 */

import { isElectron } from "./electron-bridge-service";
import { IKuikaCoreWasmBridgeAdapter } from "./kuika-core-wasm-bridge-adapter";
import { BrowserBridgeAdapter } from "./kuika-core-wasm-browser-bridge-adapter";
import { ElectronIpcBridgeAdapter } from "./kuika-core-wasm-electron-ipc-bridge-adapter";
import OfflineDbPersistenceService from "./offline-db-persistence-service";

class KuikaCoreWasmBridgeService {
  private static instance: KuikaCoreWasmBridgeService | null = null;

  private adapter: IKuikaCoreWasmBridgeAdapter;

  private autoSaveTimeout: ReturnType<typeof setTimeout> | null = null;

  private static readonly AUTO_SAVE_DELAY_MS = 1000; // 1 second debounce

  private constructor() {
    if (window?.location?.href?.endsWith("/agent")) {
      return;
    }

    if (isElectron()) {
      console.log("KuikaCoreWasmBridgeService: Using Electron IPC adapter");
      this.adapter = new ElectronIpcBridgeAdapter();
    } else {
      console.log("KuikaCoreWasmBridgeService: Using Browser adapter");
      this.adapter = new BrowserBridgeAdapter();
      // Best-effort safety net: if the tab is hidden/closing while a debounced
      // write is still pending, flush it so the offline write is not lost. The
      // deterministic flush before in-app reloads lives in ReactSystemFunctions.navigate.
      if (typeof window !== "undefined") {
        window.addEventListener("visibilitychange", () => {
          if (document.visibilityState === "hidden") void this.flushPendingWrites();
        });
        window.addEventListener("pagehide", () => {
          void this.flushPendingWrites();
        });
      }
    }
  }

  /**
   * Get the singleton instance of the service.
   */
  static getInstance(): KuikaCoreWasmBridgeService {
    if (!KuikaCoreWasmBridgeService.instance) {
      KuikaCoreWasmBridgeService.instance = new KuikaCoreWasmBridgeService();
    }
    return KuikaCoreWasmBridgeService.instance;
  }

  /**
   * Initialize the WASM runtime. This is called automatically when needed.
   * Can be called explicitly for eager initialization.
   */
  async initialize(): Promise<void> {
    return this.adapter.initialize();
  }

  /**
   * Check if the WASM runtime is initialized.
   */
  getIsInitialized(): boolean {
    return this.adapter.getIsInitialized();
  }

  /**
   * Get the current adapter type.
   */
  getAdapterType(): "browser" | "electron" {
    return this.adapter.getAdapterType();
  }

  /**
   * Whether the engine persists the DB durably itself (OPFS pool on web / native file on Electron).
   * When true, callers skip the whole-DB base64 → IndexedDB mirror and open the durable store
   * directly. Only meaningful after initialize() (reflects the worker's OPFS mount result).
   */
  hasDurablePersistence(): boolean {
    return this.adapter.hasDurablePersistence();
  }

  /** Whether the downloaded DB can be streamed straight into the durable store (browser OPFS). */
  supportsStreamingImport(): boolean {
    return this.adapter.supportsStreamingImport();
  }

  /** Streaming import: begin a fresh write of the DB file. */
  async importStreamBegin(): Promise<void> {
    return this.adapter.importStreamBegin();
  }

  /** Streaming import: write one downloaded chunk at the given byte offset. */
  async importStreamChunk(offset: number, chunk: Uint8Array): Promise<void> {
    return this.adapter.importStreamChunk(offset, chunk);
  }

  /** Streaming import: finalize the file, reopen the engine, reset sync flags. */
  async importStreamEnd(): Promise<void> {
    return this.adapter.importStreamEnd();
  }

  /**
   * Permanently delete the durable offline store (browser OPFS pool / Electron native DB) and reset
   * the engine. Cancels any pending debounced auto-save first so a stale timer cannot resurrect the
   * IndexedDB mirror after the purge.
   */
  async purgeDurableStore(): Promise<void> {
    if (this.autoSaveTimeout) {
      clearTimeout(this.autoSaveTimeout);
      this.autoSaveTimeout = null;
    }
    return this.adapter.purgeDurableStore();
  }

  /**
   * Run the WASM module with default args (for backward compatibility).
   */
  async run(): Promise<void> {
    await this.Ping();
  }

  // Core methods

  /**
   * Add two numbers using the WASM module.
   */
  async Add(a: number, b: number): Promise<number> {
    return this.adapter.Add(a, b);
  }

  /**
   * Ping the WASM module to verify it's working.
   */
  async Ping(): Promise<string> {
    return this.adapter.Ping();
  }

  // Database lifecycle methods

  /**
   * Initialize the SQLite database connection (without any schema).
   * Use Db_ImportDatabaseBase64 to load actual data.
   */
  async Db_Initialize(): Promise<void> {
    return this.adapter.Db_Initialize();
  }

  /**
   * Ensure the database is initialized before performing offline operations.
   * This is called automatically by generated offline functions.
   *
   * Flow:
   * 1. Check if already initialized (has data) - if so, return
   * 2. Try to load from IndexedDB (persisted data from previous session)
   * 3. If no persisted data, do nothing - caller must use fetchOfflineDb first
   */
  async ensureDbInitialized(): Promise<void> {
    // initialize() mounts OPFS + sets the DB path in the worker; must run before hasDurablePersistence.
    await this.initialize();

    const isInitialized = await this.Db_IsInitialized();
    if (isInitialized) {
      return;
    }

    // Durable store (OPFS pool / native file): just open it — the file itself holds prior-session
    // data. No IndexedDB base64 mirror to load (that path would OOM on large DBs).
    if (this.hasDurablePersistence()) {
      console.log("KuikaCoreWasmBridgeService: durable store — opening DB file directly");
      await this.Db_Initialize();
      return;
    }

    console.log("KuikaCoreWasmBridgeService: Database not initialized, checking IndexedDB fallback...");

    // Fallback (browser :memory:, e.g. incognito): load the IndexedDB base64 mirror.
    const persistenceService = OfflineDbPersistenceService.getInstance();
    const persistedData = await persistenceService.loadDatabase();

    if (persistedData) {
      console.log("KuikaCoreWasmBridgeService: Found persisted data, importing...");
      try {
        await this.Db_ImportDatabaseBase64(persistedData);
        console.log("KuikaCoreWasmBridgeService: Database imported from persistence");
        return;
      } catch (error) {
        console.warn("KuikaCoreWasmBridgeService: Failed to import persisted data", error);
      }
    }

    // No persisted data available - fetchOfflineDb must be called first
    console.warn(
      "KuikaCoreWasmBridgeService: No offline database available. Call fetchOfflineDb to download data from server."
    );
  }

  /**
   * Check if the database is initialized.
   */
  async Db_IsInitialized(): Promise<boolean> {
    return this.adapter.Db_IsInitialized();
  }

  /**
   * Close the database connection.
   */
  async Db_Close(): Promise<void> {
    return this.adapter.Db_Close();
  }

  /**
   * Save the current database state to persistent storage (IndexedDB/file).
   * Call this after making changes to ensure data survives page refresh.
   */
  async saveToStorage(): Promise<void> {
    const isInitialized = await this.Db_IsInitialized();
    if (!isInitialized) {
      console.warn("KuikaCoreWasmBridgeService: Cannot save - database not initialized");
      return;
    }

    // Durable store (OPFS pool / native file): each write already lands in the file — a whole-DB
    // base64 export here is pure waste (and OOMs on large DBs, the very thing OPFS removed).
    if (this.hasDurablePersistence()) {
      return;
    }

    try {
      const base64Data = await this.Db_ExportDatabaseBase64();
      const persistenceService = OfflineDbPersistenceService.getInstance();
      await persistenceService.saveDatabase(base64Data);
      console.log("KuikaCoreWasmBridgeService: Database saved to storage");
    } catch (error) {
      console.error("KuikaCoreWasmBridgeService: Failed to save database to storage", error);
      throw error;
    }
  }

  /**
   * Schedule a debounced auto-save to persistent storage.
   * Multiple calls within the debounce window will only trigger one save.
   * Skipped for Electron since native uses file-based SQLite with automatic persistence.
   */
  private scheduleAutoSave(): void {
    // Skip when the engine persists durably by itself: Electron (native file) OR browser OPFS —
    // each write is already on disk, so there is nothing to mirror (and no full-DB base64 export).
    if (isElectron() || this.hasDurablePersistence()) {
      return;
    }

    // Clear existing timeout
    if (this.autoSaveTimeout) {
      clearTimeout(this.autoSaveTimeout);
    }

    // Schedule new save
    this.autoSaveTimeout = setTimeout(async () => {
      this.autoSaveTimeout = null;
      try {
        await this.saveToStorage();
      } catch (error) {
        console.error("KuikaCoreWasmBridgeService: Auto-save failed", error);
      }
    }, KuikaCoreWasmBridgeService.AUTO_SAVE_DELAY_MS);
  }

  /**
   * Immediately persist any pending debounced write to storage.
   *
   * Writes (Insert/Upsert/Delete) only schedule a debounced auto-save
   * (AUTO_SAVE_DELAY_MS later). A hard page reload — e.g. the
   * navigate("currentPage") that runs window.location.reload() right after a
   * save — destroys that pending timeout before it fires, so the offline write
   * would never reach IndexedDB and is lost on the next load. Call this before
   * any such reload/unload to flush the pending write synchronously-awaited.
   * No-op when there is no pending write (cheap to call on every navigation).
   */
  async flushPendingWrites(): Promise<void> {
    if (!this.autoSaveTimeout) {
      return;
    }
    clearTimeout(this.autoSaveTimeout);
    this.autoSaveTimeout = null;
    try {
      await this.saveToStorage();
    } catch (error) {
      console.error("KuikaCoreWasmBridgeService: flushPendingWrites failed", error);
    }
  }

  // Database import/export methods

  /**
   * Export the entire database as a base64-encoded string.
   */
  async Db_ExportDatabaseBase64(): Promise<string> {
    return this.adapter.Db_ExportDatabaseBase64();
  }

  /**
   * Import a database from a base64-encoded string.
   * This replaces the entire database content.
   * @param base64Data Base64-encoded SQLite database file
   */
  async Db_ImportDatabaseBase64(base64Data: string): Promise<void> {
    return this.adapter.Db_ImportDatabaseBase64(base64Data);
  }

  // Sync methods

  /**
   * Get all records that haven't been synced (SentFromMobile = 0).
   * Returns JSON with table names and their pending records.
   */
  async Db_GetPendingChanges(): Promise<string> {
    return this.adapter.Db_GetPendingChanges();
  }

  /**
   * Mark records as synced (SentFromMobile = 1).
   * @param tableRecordsJson JSON object with table names and record IDs
   */
  async Db_MarkAsSynced(tableRecordsJson: string): Promise<void> {
    return this.adapter.Db_MarkAsSynced(tableRecordsJson);
  }

  /**
   * Get the OfflineTableSettings JSON from KuikaDbInfo table.
   */
  async Db_GetOfflineTableSettings(): Promise<string> {
    return this.adapter.Db_GetOfflineTableSettings();
  }

  /**
   * Export only unsent records matching WillSendRecordsCriteria as base64.
   * Creates a filtered copy with only records that should be synced.
   */
  async Db_GetUnsentRecordsBase64(): Promise<string> {
    return this.adapter.Db_GetUnsentRecordsBase64();
  }

  /**
   * Mark records as synced using WillSendRecordsCriteria from KuikaDbInfo.
   * Only marks records matching the criteria for each table.
   */
  async Db_MarkAsSyncedWithCriteria(): Promise<void> {
    return this.adapter.Db_MarkAsSyncedWithCriteria();
  }

  /**
   * Mark synced exactly the rows contained in the given exported payload —
   * the correct counterpart to Db_GetUnsentRecordsBase64. Pass back the same
   * base64 that was POSTed so rows added during the push network window are
   * not marked synced without being sent (silent offline data loss).
   */
  async Db_MarkPayloadAsSynced(payloadBase64: string): Promise<void> {
    return this.adapter.Db_MarkPayloadAsSynced(payloadBase64);
  }

  // Device metadata methods

  /**
   * Import a database and reset SentFromMobile for editable tables.
   * Use this after fetching fresh data from API to allow re-sync.
   */
  async Db_ImportDatabaseBase64WithReset(base64Data: string): Promise<void> {
    return this.adapter.Db_ImportDatabaseBase64WithReset(base64Data);
  }

  /**
   * Import a database from raw bytes (binary fetch transport) and reset SentFromMobile for editable
   * tables. Avoids holding a multi-hundred-MB base64 string on the client (JS string size limit).
   */
  async Db_ImportDatabaseBytesWithReset(bytes: Uint8Array): Promise<void> {
    return this.adapter.Db_ImportDatabaseBytesWithReset(bytes);
  }

  /**
   * Update device metadata in KuikaDbInfo table.
   * Used to track device identity for sync operations.
   */
  async Db_UpdateDeviceMetadata(
    deviceId: string | null,
    deviceName: string | null,
    bundleId: string | null,
    projectName: string | null
  ): Promise<void> {
    return this.adapter.Db_UpdateDeviceMetadata(deviceId, deviceName, bundleId, projectName);
  }

  /**
   * Get device metadata from KuikaDbInfo table as JSON.
   */
  async Db_GetDeviceMetadata(): Promise<string> {
    return this.adapter.Db_GetDeviceMetadata();
  }

  // table-service-methods-placeholder
}

export default KuikaCoreWasmBridgeService;

/**
 * Singleton instance of the WASM bridge service.
 * Used by generated offline screen code.
 */
export const kuikaCoreWasmBridgeService = KuikaCoreWasmBridgeService.getInstance();
