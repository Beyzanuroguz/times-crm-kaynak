/**
 * Electron IPC Native Bridge Adapter.
 * Uses IPC to communicate with the main process which runs native AOT .NET.
 */

import { IKuikaCoreWasmBridgeAdapter } from "./kuika-core-wasm-bridge-adapter";

declare let window: any;

interface KuikaCoreNativeResult {
  success: boolean;
  result?: unknown;
  error?: string;
}

interface KuikaCoreNativeAPI {
  initialize: () => Promise<KuikaCoreNativeResult>;
  invoke: (method: string, args: unknown[]) => Promise<KuikaCoreNativeResult>;
}

export class ElectronIpcBridgeAdapter implements IKuikaCoreWasmBridgeAdapter {
  private isInitialized = false;

  /**
   * Tracks whether the database has been initialized with data.
   * Set to true when data is imported (Db_ImportDatabaseBase64 / Db_ImportDatabaseBase64WithReset).
   * For Electron, also checked via native HasData on first call.
   */
  private isDbInitialized = false;
  private hasCheckedNative = false;

  private get nativeApi(): KuikaCoreNativeAPI {
    const api = window.electronAPI?.kuikaCoreNative;
    if (!api) {
      throw new Error("Electron Native API not available. Make sure you're running in Electron.");
    }
    return api;
  }

  async initialize(): Promise<void> {
    if (this.isInitialized) {
      return;
    }

    console.log("ElectronIpcBridgeAdapter: Initializing via IPC...");

    const result = await this.nativeApi.initialize();

    if (!result.success) {
      throw new Error(result.error || "Native initialization failed");
    }

    this.isInitialized = true;
    console.log("ElectronIpcBridgeAdapter: Initialized successfully");
  }

  getIsInitialized(): boolean {
    return this.isInitialized;
  }

  getAdapterType(): "browser" | "electron" {
    return "electron";
  }

  /** Electron persists via its native file-based SQLite (kuika_offline.db) — always durable. */
  hasDurablePersistence(): boolean {
    return true;
  }

  /** Electron imports via native file I/O, not the browser OPFS stream path. */
  supportsStreamingImport(): boolean {
    return false;
  }

  async importStreamBegin(): Promise<void> {
    throw new Error("Streaming import is not used on Electron (native file import).");
  }

  async importStreamChunk(): Promise<void> {
    throw new Error("Streaming import is not used on Electron (native file import).");
  }

  async importStreamEnd(): Promise<void> {
    throw new Error("Streaming import is not used on Electron (native file import).");
  }

  /**
   * Electron closes the native SQLite connection so the file handle is released. The native
   * `kuika_offline.db` file itself is overwritten wholesale on the next fetch (import-with-reset);
   * there is no lingering OPFS pool to clear as on the browser path. Removing the file outright
   * would require a dedicated native command, which the current native surface does not expose.
   */
  async purgeDurableStore(): Promise<void> {
    await this.initialize();
    const isInitialized: boolean = await this.Db_IsInitialized();
    if (isInitialized) {
      await this.Db_Close();
    }
  }

  private async invokeNative<T>(method: string, ...args: unknown[]): Promise<T> {
    const result = await this.nativeApi.invoke(method, args);
    if (!result.success) {
      throw new Error(result.error || `Native ${method} failed`);
    }
    return result.result as T;
  }

  // Core methods
  async Add(a: number, b: number): Promise<number> {
    await this.initialize();
    return this.invokeNative<number>("add", a, b);
  }

  async Ping(): Promise<string> {
    await this.initialize();
    return this.invokeNative<string>("ping");
  }

  // Database lifecycle methods
  async Db_Initialize(): Promise<void> {
    await this.initialize();
    await this.invokeNative<void>("db_initialize");
    this.isDbInitialized = true;
  }

  async Db_IsInitialized(): Promise<boolean> {
    await this.initialize();
    // If already confirmed via import, return immediately
    if (this.isDbInitialized) return true;
    // Check native HasData once (covers app restart where file-based DB already has data
    // from a previous session's fetchOfflineDb)
    if (!this.hasCheckedNative) {
      this.hasCheckedNative = true;
      // Native returns string "True"/"False" from C# bool.ToString()
      const result = await this.invokeNative<string>("db_isinitialized");
      if (String(result).toLowerCase() === "true") {
        this.isDbInitialized = true;
      }
    }
    return this.isDbInitialized;
  }

  async Db_Close(): Promise<void> {
    await this.initialize();
    await this.invokeNative<void>("db_close");
    this.isDbInitialized = false;
  }

  // Database import/export methods
  async Db_ExportDatabaseBase64(): Promise<string> {
    await this.initialize();
    return this.invokeNative<string>("db_exportdatabasebase64");
  }

  async Db_ImportDatabaseBase64(base64Data: string): Promise<void> {
    await this.initialize();
    await this.invokeNative<void>("db_importdatabasebase64", base64Data);
    this.isDbInitialized = true;
  }

  // Sync methods
  async Db_GetPendingChanges(): Promise<string> {
    await this.initialize();
    return this.invokeNative<string>("db_getpendingchanges");
  }

  async Db_MarkAsSynced(tableRecordsJson: string): Promise<void> {
    await this.initialize();
    await this.invokeNative<void>("db_markassynced", tableRecordsJson);
  }

  async Db_GetOfflineTableSettings(): Promise<string> {
    await this.initialize();
    return this.invokeNative<string>("db_getofflinetablesettings");
  }

  async Db_GetUnsentRecordsBase64(): Promise<string> {
    await this.initialize();
    return this.invokeNative<string>("db_getunsentrecordsbase64");
  }

  async Db_MarkAsSyncedWithCriteria(): Promise<void> {
    await this.initialize();
    await this.invokeNative<void>("db_markassyncedwithcriteria");
  }

  async Db_MarkPayloadAsSynced(payloadBase64: string): Promise<void> {
    await this.initialize();
    await this.invokeNative<void>("db_markpayloadassynced", payloadBase64);
  }

  // Device metadata methods
  async Db_ImportDatabaseBase64WithReset(base64Data: string): Promise<void> {
    await this.initialize();
    await this.invokeNative<void>("db_importdatabasebase64withreset", base64Data);
    this.isDbInitialized = true;
  }

  async Db_ImportDatabaseBytesWithReset(bytes: Uint8Array): Promise<void> {
    await this.initialize();
    // The Electron native process consumes base64 over IPC. Convert here (chunked, to avoid the
    // call-stack limit of String.fromCharCode on large arrays). Desktop memory is not as constrained
    // as a browser tab, so the base64 string is acceptable on this path.
    let binary = "";
    const chunkSize = 0x8000;
    for (let i = 0; i < bytes.length; i += chunkSize) {
      binary += String.fromCharCode(...bytes.subarray(i, i + chunkSize));
    }
    const base64Data: string = btoa(binary);
    await this.invokeNative<void>("db_importdatabasebase64withreset", base64Data);
    this.isDbInitialized = true;
  }

  async Db_UpdateDeviceMetadata(
    deviceId: string | null,
    deviceName: string | null,
    bundleId: string | null,
    projectName: string | null
  ): Promise<void> {
    await this.initialize();
    await this.invokeNative<void>("db_updatedevicemetadata", deviceId, deviceName, bundleId, projectName);
  }

  async Db_GetDeviceMetadata(): Promise<string> {
    await this.initialize();
    return this.invokeNative<string>("db_getdevicemetadata");
  }

  // table-electron-adapter-methods-placeholder
}
