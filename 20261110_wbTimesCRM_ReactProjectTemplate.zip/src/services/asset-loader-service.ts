import { KuikaWidgetRegistry, WidgetPackManifest } from "../components/web-components/widget-renderer/types";
import { KuikaEnvConfig } from "../shared/utilty/frontend-url";
import { KuikaAppManager } from "../shared/utilty/kuika-app-manager";
import { KuikaMfeAppEntry } from "../shared/utilty/own-app-env";
import { assertSafeAssetId, assertTrustedScriptUrl, ScriptUrlPolicy } from "../shared/utilty/trusted-asset-url";

/**
 * MFE app manifest structure.
 */
export interface MfeManifest {
  webComponentTag: string;
  /**
   * Microapp identity, written by codegen into BOTH asset-manifest.json and the
   * bundle's conf.json (applicationName / domainName). The microapp's own bundle
   * matches on these to find its entry in the `window.kuika.apps` registry —
   * that is how it resolves its own backend URL and env-config instead of the
   * host page's. Optional for backward compatibility with older manifests.
   */
  appName?: string;
  workspace?: string;
  /**
   * Authoritative backend URL for the microapp, written by codegen at deploy
   * time. The host's MFE container reads this directly during auth handoff so
   * it never has to guess the API host from the frontend URL — works for any
   * topology (Kuika SaaS, self-hosted single-tenant, custom domains, etc.).
   * Optional for backward compatibility with manifests generated before this
   * field was introduced.
   */
  backendUrlOverride?: string;
  /**
   * The routes the microapp serves, read from its own router at build time
   * (microapp-route-paths.ts) — lowercased, no trailing slash. The host's MFE
   * container honors a deep-link hash only when it names one of these, so a
   * reload that left a NESTED microapp's route in the shared hash does not boot
   * this microapp onto its NoMatch404. Optional for backward compatibility:
   * without it every route-shaped hash is honored, as before.
   */
  routes?: string[];
  entryFiles: {
    /** Legacy support */
    app?: {
      js: string[];
      css: string[];
      ico?: string[];
      url_3rd_js?: string[];
    };
    /** New support */
    index?: {
      js: string[];
      css: string[];
      ico?: string[];
      url_3rd_js?: string[];
    };
  };
}

/**
 * Static service for loading widget pack and MFE assets (JS, CSS, manifests).
 * Handles caching, deduplication of requests, and proper loading order.
 */
export class AssetLoaderService {
  private static readonly DESIGN_MODE_ORIGIN = "http://localhost:3002";

  /** Cache for widget manifests to prevent redundant network requests */
  private static readonly manifestCache = new Map<string, WidgetPackManifest>();

  /** Cache for in-flight manifest fetch promises to prevent duplicate concurrent requests */
  private static readonly manifestFetchPromises = new Map<string, Promise<WidgetPackManifest>>();

  /** Cache for in-flight component loading promises to prevent duplicate concurrent loads */
  private static readonly loadingPromises = new Map<string, Promise<WidgetPackManifest>>();

  /** Set of already loaded widget components */
  private static readonly loadedComponents = new Set<string>();

  /** Cache for MFE manifests */
  private static readonly mfeManifestCache = new Map<string, MfeManifest>();

  /** Cache for in-flight MFE manifest fetch promises */
  private static readonly mfeFetchPromises = new Map<string, Promise<MfeManifest>>();

  /** Set of already loaded MFE apps */
  private static readonly loadedMfeApps = new Set<string>();

  /**
   * Cache for per-microapp env-configs. An `undefined` VALUE is a cached
   * negative — that deployment publishes no usable env-config — and must not be
   * confused with a missing key, which means "not fetched yet".
   */
  private static readonly mfeEnvConfigCache = new Map<string, KuikaEnvConfig | undefined>();

  /** Cache for in-flight microapp env-config fetch promises */
  private static readonly mfeEnvConfigFetchPromises = new Map<string, Promise<KuikaEnvConfig | undefined>>();

  /**
   * Returns the origin to use for loading widget assets.
   * In design time, uses localhost:3002; otherwise uses GetFrontEndSourceUrl for proper MFE/web component support.
   */
  private static getWidgetOrigin(): string {
    if (window.kuika?.isDesignTime) {
      return this.DESIGN_MODE_ORIGIN;
    }
    return KuikaAppManager.GetFrontEndSourceUrl();
  }

  /**
   * Gets the entry files from a manifest for a specific component.
   * Falls back to 'index' or 'app' for legacy single-bundle packs.
   */
  private static getEntryFiles(manifest: WidgetPackManifest, componentId?: string) {
    if (componentId && manifest.entryFiles?.[componentId]) {
      return manifest.entryFiles[componentId];
    }
    return manifest.entryFiles?.index ?? manifest.entryFiles?.app;
  }

  /**
   * Returns the base path for a widget pack's assets.
   */
  public static getWidgetPackBasePath(packId: string): string {
    // Security: packId becomes a URL path segment; reject anything but a plain token.
    assertSafeAssetId(packId, "packId");
    const origin = this.getWidgetOrigin();
    return `${origin}/widgets/${packId}/`;
  }

  /**
   * Fetches and parses the asset-manifest.json for a widget pack.
   * Uses caching to prevent redundant network requests.
   */
  public static async fetchWidgetPackManifest(packId: string): Promise<WidgetPackManifest> {
    const cached = this.manifestCache.get(packId);
    if (cached) {
      return cached;
    }

    const existingFetch = this.manifestFetchPromises.get(packId);
    if (existingFetch) {
      return existingFetch;
    }

    const fetchPromise = (async () => {
      const basePath = this.getWidgetPackBasePath(packId);
      const manifestUrl = `${basePath}asset-manifest.json`;

      // no-store: the manifest names the content-hashed bundle to inject, so a
      // copy the browser's HTTP cache kept from a previous deployment would
      // load the old bundle. Under the service worker the request is served
      // fresh-or-fail anyway (sw.ts); this covers uncontrolled loads — hard
      // reload, first load after site data was cleared, SW blocked by policy.
      const response = await fetch(manifestUrl, { cache: "no-store" });
      if (!response.ok) {
        throw new Error(`Failed to fetch widget manifest: ${response.status} ${response.statusText}`);
      }

      const manifest: WidgetPackManifest = await response.json();
      this.manifestCache.set(packId, manifest);

      return manifest;
    })();

    this.manifestFetchPromises.set(packId, fetchPromise);

    try {
      return await fetchPromise;
    } finally {
      this.manifestFetchPromises.delete(packId);
    }
  }

  /**
   * Creates a script element and waits for it to load.
   * @param src - The script URL
   * @param isModule - If true, loads the script as an ES module (type="module")
   */
  public static loadScript(src: string, isModule: boolean = false, policy: ScriptUrlPolicy = {}): Promise<void> {
    return new Promise((resolve, reject) => {
      // Security: only assign trusted URLs to script.src (Client DOM Code Injection).
      try {
        assertTrustedScriptUrl(src, policy);
      } catch (err) {
        reject(err instanceof Error ? err : new Error(String(err)));
        return;
      }

      const existingScript = document.querySelector(`script[src="${src}"]`);
      if (existingScript) {
        resolve();
        return;
      }

      const script = document.createElement("script");
      script.async = true;
      script.crossOrigin = "anonymous";
      script.referrerPolicy = "no-referrer";
      script.src = src;

      if (isModule) {
        script.type = "module";
      }

      script.onload = () => resolve();
      script.onerror = () => reject(new Error(`Failed to load script: ${src}`));

      document.head.appendChild(script);
    });
  }

  /**
   * Creates a link element for CSS and waits for it to load.
   */
  public static loadStylesheet(href: string): Promise<void> {
    return new Promise((resolve, reject) => {
      const existingLink = document.querySelector(`link[href="${href}"]`);
      if (existingLink) {
        resolve();
        return;
      }

      const link = document.createElement("link");
      link.rel = "stylesheet";
      link.href = href;

      link.onload = () => resolve();
      link.onerror = () => reject(new Error(`Failed to load stylesheet: ${href}`));

      document.head.appendChild(link);
    });
  }

  /**
   * Loads all JS and CSS assets for a widget pack or specific component.
   */
  public static async loadWidgetPackAssets(
    packId: string,
    manifest: WidgetPackManifest,
    componentId?: string
  ): Promise<void> {
    const basePath = this.getWidgetPackBasePath(packId);
    const entryFiles = this.getEntryFiles(manifest, componentId);

    if (!entryFiles) {
      throw new Error(`No entry files found in widget manifest for ${packId}${componentId ? `/${componentId}` : ""}`);
    }

    const isModule = manifest.scriptType === "module";

    const cssPromises = (entryFiles.css || []).map((file) => this.loadStylesheet(`${basePath}${file}`));

    const widgetOrigin: string = new URL(basePath, window.location.origin).origin;
    for (const file of entryFiles.js || []) {
      await this.loadScript(`${basePath}${file}`, isModule, { expectedOrigin: widgetOrigin });
    }

    await Promise.all(cssPromises);
  }

  /**
   * Checks if a widget component has already been loaded.
   */
  public static isWidgetComponentLoaded(packId: string, componentId?: string): boolean {
    const key = componentId ? `${packId}/${componentId}` : packId;
    return this.loadedComponents.has(key);
  }

  /**
   * Marks a widget component as loaded.
   */
  public static markWidgetComponentLoaded(packId: string, componentId?: string): void {
    const key = componentId ? `${packId}/${componentId}` : packId;
    this.loadedComponents.add(key);
  }

  /**
   * Waits for the widget registry to become available after scripts load.
   */
  public static waitForWidgetRegistry(packId: string, timeout: number = 10000): Promise<KuikaWidgetRegistry> {
    return new Promise((resolve, reject) => {
      const startTime = Date.now();

      const check = () => {
        const registry = window.kuikaWidgetRegistry?.[packId];
        if (registry) {
          resolve(registry);
          return;
        }

        if (Date.now() - startTime > timeout) {
          reject(new Error(`Timeout waiting for widget registry: ${packId}`));
          return;
        }

        setTimeout(check, 50);
      };

      check();
    });
  }

  /**
   * Loads a specific widget component from a pack.
   * Only loads the assets needed for that component.
   * Handles caching and prevents duplicate loading.
   */
  public static async loadWidgetComponent(packId: string, componentId: string): Promise<WidgetPackManifest> {
    const cacheKey = `${packId}/${componentId}`;

    if (this.isWidgetComponentLoaded(packId, componentId)) {
      return this.fetchWidgetPackManifest(packId);
    }

    const existingPromise = this.loadingPromises.get(cacheKey);
    if (existingPromise) {
      return existingPromise;
    }

    const loadingPromise = (async () => {
      try {
        const manifest = await this.fetchWidgetPackManifest(packId);
        await this.loadWidgetPackAssets(packId, manifest, componentId);
        await this.waitForWidgetRegistry(packId);
        this.markWidgetComponentLoaded(packId, componentId);
        return manifest;
      } finally {
        this.loadingPromises.delete(cacheKey);
      }
    })();

    this.loadingPromises.set(cacheKey, loadingPromise);
    return loadingPromise;
  }

  // ==================== MFE Loading Methods ====================

  /**
   * Normalizes a frontend URL to ensure it ends with a trailing slash.
   */
  public static normalizeFrontEndUrl(url: string): string {
    if (!url) return url;
    let normalized = url;
    if (normalized.endsWith("/") || normalized.endsWith("\\")) {
      normalized = normalized.slice(0, -1);
    }
    return `${normalized}/`;
  }

  /**
   * Gets the entry files from an MFE manifest.
   * Falls back to 'app' for legacy manifests.
   */
  private static getMfeEntryFiles(manifest: MfeManifest) {
    return manifest?.entryFiles?.index ?? manifest?.entryFiles?.app;
  }

  /**
   * Fetches and caches an MFE manifest from the given frontend URL.
   */
  public static async fetchMfeManifest(frontEndUrl: string): Promise<MfeManifest> {
    const normalizedUrl = this.normalizeFrontEndUrl(frontEndUrl);

    const cached = this.mfeManifestCache.get(normalizedUrl);
    if (cached) {
      return cached;
    }

    const existingFetch = this.mfeFetchPromises.get(normalizedUrl);
    if (existingFetch) {
      return existingFetch;
    }

    const fetchPromise = (async () => {
      const manifestUrl = `${normalizedUrl}asset-manifest.json`;
      // no-store for the same reason as env-config.json below: a manifest the
      // browser's HTTP cache kept from a previous deployment would inject the
      // old bundle on an uncontrolled load (hard reload, first load after site
      // data was cleared, SW blocked by policy). Under the service worker the
      // request is served fresh-or-fail regardless (sw.ts, KOA-18736).
      const response = await fetch(manifestUrl, { cache: "no-store" });

      if (!response.ok) {
        throw new Error(`Failed to fetch MFE manifest: ${response.status} ${response.statusText}`);
      }

      const manifest: MfeManifest = await response.json();
      this.mfeManifestCache.set(normalizedUrl, manifest);

      return manifest;
    })();

    this.mfeFetchPromises.set(normalizedUrl, fetchPromise);

    try {
      return await fetchPromise;
    } finally {
      this.mfeFetchPromises.delete(normalizedUrl);
    }
  }

  /**
   * Fetches a microapp's OWN runtime env-config from its own deployment.
   *
   * `env-config.js` is a <script> that assigns the single window-scoped
   * `window._env_`, so only the app that owns the document can consume it —
   * loading it here would overwrite the host's. `env.sh` therefore mirrors the
   * same values into a sibling `env-config.json`, which is safe to fetch and
   * hand to exactly one app.
   *
   * Resolves to undefined whenever no env-config can be trusted (deployment
   * predates the file, network error, or the SPA fallback answering with
   * index.html — nginx's `try_files ... /index.html` can turn a missing file
   * into a 200, so the content type and the parsed shape are both verified).
   * Undefined means "this microapp published no env override", never "use the
   * host's".
   */
  public static async fetchMfeEnvConfig(frontEndUrl: string): Promise<KuikaEnvConfig | undefined> {
    const normalizedUrl: string = this.normalizeFrontEndUrl(frontEndUrl);

    if (this.mfeEnvConfigCache.has(normalizedUrl)) {
      return this.mfeEnvConfigCache.get(normalizedUrl);
    }

    const existingFetch: Promise<KuikaEnvConfig | undefined> | undefined =
      this.mfeEnvConfigFetchPromises.get(normalizedUrl);
    if (existingFetch) {
      return existingFetch;
    }

    const fetchPromise: Promise<KuikaEnvConfig | undefined> = (async (): Promise<KuikaEnvConfig | undefined> => {
      let env: KuikaEnvConfig | undefined;
      try {
        // no-store: env-config.json is written at container start, so a cached
        // copy from a previous deployment would pin a stale BACKEND_URL.
        const response: Response = await fetch(`${normalizedUrl}env-config.json`, { cache: "no-store" });
        if (response.ok) {
          const body: string = await response.text();
          env = this.parseMfeEnvConfig(response.headers.get("content-type"), body);
        }
      } catch {
        env = undefined;
      }
      this.mfeEnvConfigCache.set(normalizedUrl, env);
      return env;
    })();

    this.mfeEnvConfigFetchPromises.set(normalizedUrl, fetchPromise);

    try {
      return await fetchPromise;
    } finally {
      this.mfeEnvConfigFetchPromises.delete(normalizedUrl);
    }
  }

  private static parseMfeEnvConfig(contentType: string | null, body: string): KuikaEnvConfig | undefined {
    if (!contentType || !contentType.toLowerCase().includes("json")) return undefined;
    try {
      const parsed: unknown = JSON.parse(body);
      if (typeof parsed !== "object" || parsed === null || Array.isArray(parsed)) return undefined;
      return parsed as KuikaEnvConfig;
    } catch {
      return undefined;
    }
  }

  /**
   * Registers a microapp in the `window.kuika.apps` registry (manifest + the
   * env-config fetched from that microapp's own deployment).
   *
   * MUST run before the microapp's bundles are injected: the microapp resolves
   * its own backend URL out of this registry, and code that runs at module-init
   * time (e.g. a service caching GetBackendUrl() in a static field) reads it in
   * the same tick its script executes. Registering afterwards left that window
   * open and the microapp silently fell back to the host's configuration.
   */
  public static async registerMfeApp(frontEndUrl: string, manifest: MfeManifest): Promise<void> {
    const normalizedUrl: string = this.normalizeFrontEndUrl(frontEndUrl);
    const envConfig: KuikaEnvConfig | undefined = await this.fetchMfeEnvConfig(normalizedUrl);

    if (window.kuika === undefined) {
      window.kuika = {};
    }
    if (window.kuika.apps === undefined) {
      window.kuika.apps = [];
    }

    const apps: KuikaMfeAppEntry[] = window.kuika.apps;
    const existing: KuikaMfeAppEntry | undefined = apps.find(
      (app: KuikaMfeAppEntry): boolean => app?.appConfig?.frontEndUrl === normalizedUrl
    );

    if (existing) {
      existing.manifest = manifest;
      existing.envConfig = envConfig;
      return;
    }

    apps.push({ appConfig: { frontEndUrl: normalizedUrl }, manifest, envConfig });
  }

  /**
   * Loads a link element (for icons, apple-touch-icon, etc.).
   */
  public static loadLink(href: string, rel: string, type?: string): Promise<void> {
    return new Promise((resolve) => {
      const existingLink = document.querySelector(`link[href="${href}"][rel="${rel}"]`);
      if (existingLink) {
        resolve();
        return;
      }

      const link = document.createElement("link");
      link.rel = rel;
      link.href = href;
      if (type) {
        link.type = type;
      }

      link.onload = () => resolve();
      link.onerror = () => resolve(); // Don't fail on icon load errors

      document.head.appendChild(link);
    });
  }

  /**
   * Loads all assets for an MFE app from a manifest.
   */
  public static async loadMfeAssets(
    frontEndUrl: string,
    manifest: MfeManifest,
    isModule: boolean = false,
    loadCss: boolean = true
  ): Promise<void> {
    const normalizedUrl = this.normalizeFrontEndUrl(frontEndUrl);
    const entryFiles = this.getMfeEntryFiles(manifest);

    if (!entryFiles) {
      throw new Error(`No entry files found in MFE manifest for ${frontEndUrl}`);
    }

    // Load CSS files (non-blocking). Skipped when loadCss is false — e.g. a
    // shadow-DOM-mounted MFE loads its stylesheets INTO its shadow root instead
    // (see getMfeStylesheetUrls + loadStylesheetIntoRoot), so the MFE's CSS never
    // leaks into the host document and isolation is preserved.
    const cssPromises = loadCss
      ? (entryFiles.css || []).map((file) => this.loadStylesheet(`${normalizedUrl}${file}`))
      : [];

    // Load JS files in order (they may depend on each other). isModule loads the
    // entry bundle as <script type="module"> — required for ESM bundles (e.g. a
    // Vite-built MFE that uses import.meta), which throw "import.meta may only
    // appear in a module" when injected as a classic script. JS always loads into
    // document.head: a custom-element definition is document-global and upgrades
    // instances inside any shadow tree.
    const mfeOrigin: string = new URL(normalizedUrl, window.location.origin).origin;
    for (const file of entryFiles.js || []) {
      await this.loadScript(`${normalizedUrl}${file}`, isModule, { expectedOrigin: mfeOrigin });
    }

    // Load 3rd party JS URLs (intentionally cross-origin — https-only).
    for (const url of entryFiles.url_3rd_js || []) {
      await this.loadScript(url, false, { allowThirdParty: true });
    }

    // Load icons (fire-and-forget — icon link elements like apple-touch-icon
    // may never fire onload/onerror in non-Safari browsers, so we must not await them)
    (entryFiles.ico || []).forEach((file) => {
      this.loadLink(`${normalizedUrl}${file}`, "icon", "image/png");
      this.loadLink(`${normalizedUrl}${file}`, "apple-touch-icon");
    });

    // Wait for CSS only
    await Promise.all(cssPromises);
  }

  /**
   * Checks if an MFE app has already been loaded.
   */
  public static isMfeAppLoaded(frontEndUrl: string): boolean {
    const normalizedUrl = this.normalizeFrontEndUrl(frontEndUrl);
    return this.loadedMfeApps.has(normalizedUrl);
  }

  /**
   * Marks an MFE app as loaded.
   */
  public static markMfeAppLoaded(frontEndUrl: string): void {
    const normalizedUrl = this.normalizeFrontEndUrl(frontEndUrl);
    this.loadedMfeApps.add(normalizedUrl);
  }

  /**
   * Loads an MFE app from a frontend URL.
   * Handles manifest fetching, asset loading, and caching.
   * Returns the manifest if successful.
   */
  public static async loadMfeApp(
    frontEndUrl: string,
    isModule: boolean = false,
    loadCss: boolean = true
  ): Promise<MfeManifest> {
    const normalizedUrl = this.normalizeFrontEndUrl(frontEndUrl);

    // If already loaded, just return cached manifest
    if (this.isMfeAppLoaded(normalizedUrl)) {
      return this.fetchMfeManifest(normalizedUrl);
    }

    const manifest = await this.fetchMfeManifest(normalizedUrl);

    if (!manifest.webComponentTag) {
      throw new Error(`MFE manifest missing webComponentTag for ${frontEndUrl}`);
    }

    // Registry first, bundles second — see registerMfeApp. The microapp reads
    // its own identity, backend URL and env-config out of this registry as its
    // scripts execute.
    await this.registerMfeApp(normalizedUrl, manifest);
    await this.loadMfeAssets(normalizedUrl, manifest, isModule, loadCss);
    this.markMfeAppLoaded(normalizedUrl);

    return manifest;
  }

  /**
   * Returns the absolute URLs of an MFE manifest's stylesheets. Use this to load
   * an MFE's CSS into a shadow root (with loadStylesheetIntoRoot) when the MFE is
   * mounted in shadow DOM and its assets were loaded with loadCss=false.
   */
  public static getMfeStylesheetUrls(frontEndUrl: string, manifest: MfeManifest): string[] {
    const normalizedUrl = this.normalizeFrontEndUrl(frontEndUrl);
    const entryFiles = this.getMfeEntryFiles(manifest);
    return (entryFiles?.css || []).map((file) => `${normalizedUrl}${file}`);
  }

  /**
   * Loads a stylesheet into a shadow root (not document.head) so it applies only
   * within that shadow tree. Deduplicated per root.
   */
  public static loadStylesheetIntoRoot(href: string, root: ShadowRoot): Promise<void> {
    return new Promise((resolve, reject) => {
      const existingLink = root.querySelector(`link[href="${href}"]`);
      if (existingLink) {
        resolve();
        return;
      }

      const link = document.createElement("link");
      link.rel = "stylesheet";
      link.href = href;

      link.onload = () => resolve();
      link.onerror = () => reject(new Error(`Failed to load stylesheet: ${href}`));

      root.appendChild(link);
    });
  }
}
