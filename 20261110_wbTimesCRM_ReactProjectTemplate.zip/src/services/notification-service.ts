import Axios, { AxiosResponse } from "axios";
import { IRegisterDeviceDto } from "../models/dto/register-device.dto";
import { PUSH_NOTIFICATION_PUBLIC_KEY } from "../shared/utilty/constants";
import { KuikaAppManager } from "../shared/utilty/kuika-app-manager";
import { KMainFunctions } from "../shared/utilty/main-functions";
import { UserService } from "./user-service";

const backendUrl: string = KuikaAppManager.GetBackendUrl();

interface ISendPushNotificationToUsernamePayload {
  username: string;
  title: string;
  message: string;
  extraData?: object;
}

interface IAskPermissionOptions {
  signal?: AbortSignal;
}

type ServiceWorkerScriptStatus = "available" | "missing" | "unreachable";

class NotificationService {
  public static async SendPushNotificationToUsername(
    payload: ISendPushNotificationToUsernamePayload
  ): Promise<AxiosResponse | Error> {
    try {
      return await Axios.post<null, AxiosResponse>(`${backendUrl}/notification/sendtouser`, {
        ...payload,
        extraData: payload.extraData ? JSON.stringify(payload.extraData) : undefined
      });
    } catch (error: unknown) {
      KMainFunctions.exceptionHandler(error);
      return normalizeError(error);
    }
  }
}

function normalizeError(error: unknown): Error {
  if (error instanceof Error) return error;
  return new Error(String(error));
}

async function getServiceWorkerScriptStatus(swUrl: string): Promise<ServiceWorkerScriptStatus> {
  try {
    const response: Response = await fetch(swUrl, {
      cache: "no-store",
      method: "HEAD"
    });
    if (response.ok) return "available";
    if (response.status === 404) return "missing";
    return "unreachable";
  } catch {
    return "unreachable";
  }
}

async function unregisterServiceWorkers(): Promise<void> {
  try {
    const registrations: readonly ServiceWorkerRegistration[] = await navigator.serviceWorker.getRegistrations();
    await Promise.all(
      registrations.map((registration: ServiceWorkerRegistration): Promise<boolean> => registration.unregister())
    );
  } catch {
    // best-effort
  }
}

export async function registerServiceWorker(): Promise<ServiceWorkerRegistration | undefined> {
  // Service Workers only work with http:, https:, or localhost
  // Skip registration for custom protocols (e.g., kuika:// in Electron)
  const protocol: string = window.location.protocol;
  if (protocol !== "http:" && protocol !== "https:") {
    console.info("Service Worker registration skipped: unsupported protocol", protocol);
    return;
  }

  if (!("serviceWorker" in navigator)) {
    console.warn("Service Worker is not supported.");
    return;
  }

  const swUrl: string = `${KuikaAppManager.GetFrontEndUrl()}/sw.js`;

  // In normal dev-server mode no sw.js is emitted (InjectManifest is disabled).
  // Unregister any stale SW from a previous session to prevent cached assets
  // from fighting HMR. Only do that on a real 404; if sw.js is unreachable
  // because the browser is offline or the dev server is restarting, keep the
  // current worker so offline reloads continue to be controlled.
  if (process.env.DEV_SERVER === "true") {
    const scriptStatus: ServiceWorkerScriptStatus = await getServiceWorkerScriptStatus(swUrl);
    if (scriptStatus === "missing") {
      await unregisterServiceWorkers();
      return;
    }
    if (scriptStatus === "unreachable") return;
  }

  try {
    const registration: ServiceWorkerRegistration = await navigator.serviceWorker.register(swUrl);
    return registration;
  } catch (error) {
    console.error("Service Worker registration failed", error);
  }
}

function waitForFirstUserGesture(signal?: AbortSignal): Promise<void> {
  return new Promise((resolve, reject) => {
    if (signal?.aborted) return reject(new DOMException("Aborted", "AbortError"));

    const onAbort: () => void = () => {
      cleanup();
      reject(new DOMException("Aborted", "AbortError"));
    };

    const handler: () => void = () => {
      cleanup();
      resolve();
    };

    const cleanup: () => void = () => {
      window.removeEventListener("pointerdown", handler, true);
      window.removeEventListener("keydown", handler, true);
      window.removeEventListener("touchstart", handler, true);
      signal?.removeEventListener("abort", onAbort);
    };

    window.addEventListener("pointerdown", handler, true);
    window.addEventListener("keydown", handler, true);
    window.addEventListener("touchstart", handler, true);
    signal?.addEventListener("abort", onAbort);
  });
}

let inFlight: Promise<NotificationPermission> | null = null;

export async function askPermission(options?: IAskPermissionOptions): Promise<NotificationPermission | undefined> {
  if (PUSH_NOTIFICATION_PUBLIC_KEY === "") {
    return undefined;
  }

  if (!("Notification" in window)) {
    throw new Error("Notifications bu tarayıcıda desteklenmiyor");
  }

  if (inFlight) return inFlight;

  inFlight = (async (): Promise<NotificationPermission> => {
    const current: NotificationPermission = Notification.permission;

    if (current === "granted") return current;

    if (current === "denied") {
      throw new Error("Push Notification izni kapalı (site settings'ten açılmalı)");
    }

    await waitForFirstUserGesture(options?.signal);

    const permission: NotificationPermission = await Notification.requestPermission();
    if (permission !== "granted") {
      throw new Error("Push Notification izni verilmedi");
    }
    return permission;
  })();

  try {
    return await inFlight;
  } finally {
    inFlight = null;
  }
}

export async function subscribeUser(username: string): Promise<void> {
  if (PUSH_NOTIFICATION_PUBLIC_KEY !== "") {
    const registration: ServiceWorkerRegistration = await navigator.serviceWorker.ready;
    let subscription: PushSubscription | null = await registration.pushManager.getSubscription();

    if (!subscription) {
      subscription = await registration.pushManager.subscribe({
        userVisibleOnly: true,
        applicationServerKey: urlBase64ToUint8Array(PUSH_NOTIFICATION_PUBLIC_KEY) as BufferSource
      });
    }

    const payload: IRegisterDeviceDto = {
      deviceId: subscription.endpoint,
      registrationId: arrayBufferToBase64Url(subscription.getKey("p256dh")),
      appBundleId: arrayBufferToBase64Url(subscription.getKey("auth")),
      userName: username,
      deviceType: 0,
      publicKey: PUSH_NOTIFICATION_PUBLIC_KEY
    };

    void UserService.RegisterDevice(payload);
  }
}

function urlBase64ToUint8Array(base64String: string): Uint8Array<ArrayBuffer> {
  const padding: string = "=".repeat((4 - (base64String.length % 4)) % 4);
  const base64: string = (base64String + padding).replace(/-/g, "+").replace(/_/g, "/");
  const rawData: string = window.atob(base64);
  const outputArray: Uint8Array<ArrayBuffer> = new Uint8Array(rawData.length);
  for (let i = 0; i < rawData.length; ++i) {
    outputArray[i] = rawData.charCodeAt(i);
  }
  return outputArray;
}

function arrayBufferToBase64Url(buffer: ArrayBuffer | null): string {
  if (!buffer) return "";

  const bytes: Uint8Array<ArrayBuffer> = new Uint8Array(buffer);
  let binary: string = "";
  bytes.forEach((byte: number): void => {
    binary += String.fromCharCode(byte);
  });
  return btoa(binary).replace(/\+/g, "-").replace(/\//g, "_").replace(/=+$/, "");
}

export default NotificationService;
