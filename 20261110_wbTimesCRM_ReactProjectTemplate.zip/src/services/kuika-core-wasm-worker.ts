/**
 * Dedicated Web Worker hosting the .NET browser-wasm runtime.
 *
 * WHY a dedicated Worker: the offline SQLite DB lives in OPFS (paged, off the main heap) to avoid
 * the whole-DB-in-linear-memory ceiling, and the OPFS pool relies on
 * `FileSystemFileHandle.createSyncAccessHandle()` — available ONLY inside dedicated Web Workers
 * (not the main thread, not SharedWorkers, not Service Workers). A SharedWorker cannot open sync
 * access handles and would silently fall back to :memory:/IndexedDB. Hence: dedicated worker.
 *
 * MULTI-TAB: OPFS sync access handles are exclusive per origin, so only ONE dedicated worker may own
 * the DB at a time. Cross-tab sharing is coordinated one level up (a leader tab owns this worker;
 * followers reach it via Web Locks + BroadcastChannel) — never by moving the DB into a SharedWorker.
 *
 * The offline SQLite DB is backed by an OPFS handle pool (sahpool) mounted at OPFS_MOUNT_DIR;
 * the .NET SQLite engine opens its file there so storage is paged to disk (working-set in RAM).
 *
 * SECURITY: only semantic method names (Db_*, {Table}_*, Query_*) and their data/bytes cross
 * this boundary — never SQL. SQL is authored and executed inside the .NET runtime.
 */

import {
  EmscriptenFS,
  initPool,
  mountPool,
  OPFS_POOL_DIR,
  OpfsHandlePool,
  removeOpfsPoolDir
} from "./kuika-core-wasm-opfs-pool";

/** Request: initialize the runtime, loading dotnet.js from the served framework URL. */
interface WorkerInitRequest {
  type: "init";
  id: number;
  wasmBaseUrl: string;
}

/** Request: invoke a [JSExport] method by name with its arguments. */
interface WorkerCallRequest {
  type: "call";
  id: number;
  method: string;
  args: readonly unknown[];
}

/** Streaming import: close the DB and start a fresh write of the OPFS DB file. */
interface WorkerImportBeginRequest {
  type: "importBegin";
  id: number;
}

/** Streaming import: write one downloaded chunk straight into the OPFS DB file at `offset`. */
interface WorkerImportChunkRequest {
  type: "importChunk";
  id: number;
  offset: number;
  chunk: Uint8Array;
}

/** Streaming import: finalize the OPFS file, reopen the engine on it, reset SentFromMobile. */
interface WorkerImportEndRequest {
  type: "importEnd";
  id: number;
}

/** Wipe: close the engine, release the OPFS pool handles, and delete the pool directory. */
interface WorkerWipeRequest {
  type: "wipe";
  id: number;
}

type WorkerRequest =
  | WorkerInitRequest
  | WorkerCallRequest
  | WorkerImportBeginRequest
  | WorkerImportChunkRequest
  | WorkerImportEndRequest
  | WorkerWipeRequest;

/** Response for any request, correlated by `id`. */
interface WorkerResponse {
  id: number;
  ok: boolean;
  result?: unknown;
  error?: string;
  /** Set on the init response: whether the OPFS pool mounted (durable) or we fell back to :memory:. */
  opfsActive?: boolean;
}

/** The KuikaCore [JSExport] surface as seen from JS: a map of callable methods. */
type KuikaCoreExportMethods = Record<string, (...args: unknown[]) => unknown>;

interface DotnetAssemblyExports {
  KuikaCoreExports: KuikaCoreExportMethods;
}

interface DotnetModule {
  FS: EmscriptenFS;
}

interface DotnetRuntime {
  getAssemblyExports: (assemblyName: string) => Promise<DotnetAssemblyExports>;
  Module?: DotnetModule;
  instance?: { Module?: DotnetModule };
  getDotnetRuntime?: (id: number) => { Module?: DotnetModule } | undefined;
}

interface DotnetApi {
  dotnet: {
    create: () => Promise<DotnetRuntime>;
  };
}

/** OPFS mount point exposed to the .NET SQLite engine (OPFS_POOL_DIR lives in the pool module). */
const OPFS_MOUNT_DIR = "/pool";
const OPFS_DB_FILE = "kuika_offline.db";
const OPFS_POOL_SIZE = 8;

function resolveModule(runtime: DotnetRuntime): DotnetModule | undefined {
  if (runtime.Module) {
    return runtime.Module;
  }
  if (runtime.instance?.Module) {
    return runtime.instance.Module;
  }
  if (typeof runtime.getDotnetRuntime === "function") {
    return runtime.getDotnetRuntime(0)?.Module;
  }
  return undefined;
}

/**
 * The channel we post responses back on. `handleRequest` only needs `postMessage`; this indirection
 * keeps the handler independent of the worker global so it stays easy to reason about and test.
 */
interface ResponsePort {
  postMessage(message: WorkerResponse): void;
}

/** Minimal dedicated-worker global surface (avoids the "WebWorker" lib, which conflicts with DOM). */
interface WorkerGlobalScopeLike {
  addEventListener: (type: "message", listener: (event: MessageEvent<WorkerRequest>) => void) => void;
  postMessage: (message: WorkerResponse) => void;
}

const workerScope: WorkerGlobalScopeLike = self as unknown as WorkerGlobalScopeLike;

// Singletons for this dedicated worker: one runtime + one OPFS pool. Only one dedicated worker owns
// the DB at a time (sync access handles are exclusive per origin); cross-tab coordination lives in
// the adapter (leader tab + Web Locks + BroadcastChannel), not here.
let exportsPromise: Promise<KuikaCoreExportMethods> | null = null;
let pool: OpfsHandlePool | null = null;
let opfsActive = false;
/** The emscripten FS of the .NET runtime, kept so `wipe` can unmount + remount a fresh pool. */
let fsRef: EmscriptenFS | null = null;

async function initExports(wasmBaseUrl: string): Promise<KuikaCoreExportMethods> {
  const dotnetUrl: string = `${wasmBaseUrl}/_framework/dotnet.js`;
  const dotnetModule: DotnetApi = (await import(/* webpackIgnore: true */ dotnetUrl)) as DotnetApi;
  const runtime: DotnetRuntime = await dotnetModule.dotnet.create();

  // Mount the OPFS handle pool BEFORE any [JSExport] runs, so the .NET SQLite engine can open
  // its file at OPFS_MOUNT_DIR. If OPFS is unavailable (e.g. some incognito modes), we skip the
  // mount and the engine falls back to its default path — see Phase 3 for explicit fallback.
  const moduleObject: DotnetModule | undefined = resolveModule(runtime);
  const fs: EmscriptenFS | undefined = moduleObject?.FS;
  if (fs) {
    fsRef = fs;
    // OPFS can be unavailable (some incognito modes) or the sync handles can be locked by another
    // tab's worker (they are exclusive per origin — the single-writer limitation). In either case
    // fall back to :memory: instead of crashing; persistence then reverts to the IndexedDB mirror
    // (the caller keys off opfsActive via hasDurablePersistence()).
    try {
      pool = await initPool(OPFS_POOL_DIR, OPFS_POOL_SIZE);
      mountPool(fs, OPFS_MOUNT_DIR, pool);
      opfsActive = true;
    } catch (poolError) {
      const reason: string = poolError instanceof Error ? poolError.message : String(poolError);
      console.warn(`KuikaCore worker: OPFS unavailable, falling back to :memory: — ${reason}`);
    }
  }

  const assembly: DotnetAssemblyExports = await runtime.getAssemblyExports("KuikaCoreWasm.Browser");
  const exports: KuikaCoreExportMethods = assembly.KuikaCoreExports;

  // Point the .NET SQLite engine at the OPFS-backed file (before any open/import). Only when the
  // pool actually mounted; otherwise the engine keeps its default (:memory:) path.
  if (opfsActive && typeof exports.Db_SetDatabasePath === "function") {
    exports.Db_SetDatabasePath(`${OPFS_MOUNT_DIR}/${OPFS_DB_FILE}`);
  }

  return exports;
}

/**
 * Delete the durable DB and leave a fresh, empty pool mounted on the SAME runtime. Used by `wipe`:
 * rather than tearing down the whole .NET runtime, we detach the pool, release its handles, remove
 * the `.kuika-opfs` directory, then rebuild an empty pool and re-point the engine at it. The engine
 * is left closed; the next `ensureDbInitialized` opens a fresh empty DB (until the next fetch
 * repopulates it). No-op on the :memory: fallback (no pool was ever mounted).
 */
async function remountFreshPool(exports: KuikaCoreExportMethods): Promise<void> {
  if (!fsRef) {
    return;
  }
  try {
    fsRef.unmount(OPFS_MOUNT_DIR);
  } catch {
    /* not mounted (e.g. :memory: fallback) */
  }
  if (pool) {
    pool.closeAll();
    pool = null;
  }
  opfsActive = false;
  try {
    await removeOpfsPoolDir(OPFS_POOL_DIR);
  } catch {
    /* directory may not exist (never fetched / already wiped) */
  }
  pool = await initPool(OPFS_POOL_DIR, OPFS_POOL_SIZE);
  mountPool(fsRef, OPFS_MOUNT_DIR, pool);
  opfsActive = true;
  if (typeof exports.Db_SetDatabasePath === "function") {
    exports.Db_SetDatabasePath(`${OPFS_MOUNT_DIR}/${OPFS_DB_FILE}`);
  }
}

/**
 * Handle one request from the owning tab and post the correlated response back. Messages are
 * processed one at a time by the single-threaded worker, so DB access is naturally serialized.
 */
async function handleRequest(port: ResponsePort, request: WorkerRequest): Promise<void> {
  try {
    if (request.type === "init") {
      // Idempotent: boot the runtime + pool once; a redundant init just awaits it and reads back the
      // opfsActive flag. Never re-create the runtime (a second create would clash in one scope).
      if (!exportsPromise) {
        exportsPromise = initExports(request.wasmBaseUrl);
      }
      await exportsPromise;
      port.postMessage({ id: request.id, ok: true, opfsActive });
      return;
    }

    // Wipe: delete the durable offline DB. Closes the engine, releases the OPFS pool's sync access
    // handles, removes the `.kuika-opfs` directory, then re-mounts a fresh empty pool on the same
    // runtime. Runs even before init so an orphaned directory from a prior session is cleared.
    if (request.type === "wipe") {
      if (exportsPromise) {
        try {
          const wipeExports: KuikaCoreExportMethods = await exportsPromise;
          if (typeof wipeExports.Db_Close === "function") {
            wipeExports.Db_Close();
          }
          await remountFreshPool(wipeExports);
        } catch {
          /* best-effort: leave the store cleared even if the remount hiccups */
        }
      } else {
        if (pool) {
          pool.closeAll();
          pool = null;
        }
        opfsActive = false;
        try {
          await removeOpfsPoolDir(OPFS_POOL_DIR);
        } catch {
          /* directory may not exist (never fetched / already wiped) */
        }
      }
      port.postMessage({ id: request.id, ok: true });
      return;
    }

    if (!exportsPromise) {
      throw new Error("KuikaCore worker received a call before initialization");
    }

    // Streaming import: download chunks are written straight into the OPFS DB file — no full DB
    // buffer, no WASM byte[]. Requires the OPFS pool (never used on the :memory: fallback path).
    if (request.type === "importBegin" || request.type === "importChunk" || request.type === "importEnd") {
      if (!pool) {
        throw new Error("Streaming import requires the OPFS pool (unavailable)");
      }
      const streamExports: KuikaCoreExportMethods = await exportsPromise;
      if (request.type === "importBegin") {
        if (typeof streamExports.Db_Close === "function") {
          streamExports.Db_Close();
        }
        pool.beginWrite(OPFS_DB_FILE);
      } else if (request.type === "importChunk") {
        pool.writeChunk(OPFS_DB_FILE, request.offset, request.chunk);
      } else {
        pool.endWrite(OPFS_DB_FILE);
        if (typeof streamExports.Db_OpenExistingWithReset === "function") {
          streamExports.Db_OpenExistingWithReset();
        }
      }
      port.postMessage({ id: request.id, ok: true });
      return;
    }

    const exports: KuikaCoreExportMethods = await exportsPromise;
    const fn: ((...args: unknown[]) => unknown) | undefined = exports[request.method];
    if (typeof fn !== "function") {
      throw new Error(`KuikaCore worker: unknown export "${request.method}"`);
    }
    const result: unknown = fn(...request.args);
    port.postMessage({ id: request.id, ok: true, result });
  } catch (error) {
    const message: string = error instanceof Error ? error.message : String(error);
    port.postMessage({ id: request.id, ok: false, error: message });
  }
}

// Dedicated Worker: respond over the worker global itself. Every message from the owning tab is
// dispatched to handleRequest, which posts the correlated response back.
//
// MUST be addEventListener, NEVER `self.onmessage = …`. The .NET 10 loader decides how to boot by
// probing the worker global when dotnet.js is first evaluated (runtime `loader/globals.ts`):
// `if (typeof importScripts === "function" && !globalThis.onmessage) globalThis.dotnetSidecar = true`.
// With `onmessage` already assigned it concludes it is NOT the worker's main script but an emscripten
// pthread-style helper hosted by someone else, and `dotnet.create()` then never resolves — no error,
// no console output, all `_framework` assets downloaded. That was the preprod "Fetch Offline DB
// spinner forever" bug: `init` never got its reply, the leader tab's promote() hung, and every other
// tab waited on it. `addEventListener` leaves the `onmessage` property null, so the loader takes the
// sidecar (= we are the main script) path. Verified live against the deployed runtime.
const selfPort: ResponsePort = {
  postMessage: (message: WorkerResponse): void => workerScope.postMessage(message)
};
workerScope.addEventListener("message", (event: MessageEvent<WorkerRequest>): void => {
  void handleRequest(selfPort, event.data);
});
