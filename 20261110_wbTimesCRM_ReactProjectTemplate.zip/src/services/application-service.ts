import Axios, { AxiosResponse } from "axios";
import { IApplicationInfo } from "../models/dto/application.dto";
import { EApplicationType, ISaveApplicationRequestDTO } from "../models/dto/save-application-request.dto";
import { KuikaAppManager } from "../shared/utilty/kuika-app-manager";
import { KMainFunctions } from "../shared/utilty/main-functions";

const backendUrl = KuikaAppManager.GetBackendUrl();
const projectId = "0e8ecb48-8c52-463c-5db5-08de3ec441b1";
const projectName = "wbTimesCRM";

export class ApplicationService {
  private static readonly MICRO_APP_PROJECT_IDS: string[] = [];

  public static async saveApplication() {
    const virtualDirectoryURL: string = "auto"; // Use by code generation
    return Axios.post<ISaveApplicationRequestDTO, AxiosResponse<any>>(`${backendUrl}/application`, {
      projectId,
      applicationType: EApplicationType.Frontend,
      applicationName: projectName,
      baseUrl: KMainFunctions.windowLocationOrigin,
      description: `${projectName} application frontend`
    });
  }

  public static async getAllApplications(): Promise<IApplicationInfo[]> {
    const promises: Promise<IApplicationInfo>[] = [];
    const existingApplications: IApplicationInfo[] = ApplicationService.getAllApplicationsFromSessionStorage() ?? [];

    const projectIdsNotInStorage: string[] = this.MICRO_APP_PROJECT_IDS.filter(
      (projectId: string) =>
        !existingApplications.some(
          (app) => app?.projectId && projectId && app?.projectId?.toLowerCase() === projectId?.toLowerCase()
        )
    );

    projectIdsNotInStorage.forEach((projectId: string) => {
      promises.push(ApplicationService.getApplication(projectId, EApplicationType.Frontend));
    });

    // const applications: IApplicationInfo[] = await Promise.all(promises);
    const results = await Promise.allSettled(promises);
    const applications = results
      .filter((result) => result.status === "fulfilled")
      .map((result) => (result as PromiseFulfilledResult<IApplicationInfo>).value);

    return [...applications, ...existingApplications];
  }

  public static async getApplication(projectId: string, applicationType: EApplicationType): Promise<IApplicationInfo> {
    const url: URL = new URL(`${backendUrl}/application`);
    url.searchParams.append("projectid", projectId);
    url.searchParams.append("applicationtype", applicationType.toString());
    let response = await Axios.get<IApplicationInfo>(url.toString());

    if (response.status === 200) {
      return response.data;
    }

    throw new Error("Failed to get application");
  }

  public static injectPreConnectLinks = () => {
    const APPS_TO_BE_PRECONNECTED: string[] = [];

    if (APPS_TO_BE_PRECONNECTED.length === 0) {
      return;
    }

    const applications = this.getAllApplicationsFromSessionStorage() || [];

    if (applications.length === 0) {
      return;
    }

    const head: HTMLHeadElement = document.getElementsByTagName("head")[0];
    const preconnectLinks: NodeListOf<HTMLLinkElement> = head.querySelectorAll("link[rel='preconnect']");
    const preconnectLinksHref: string[] = Array.from(preconnectLinks).map((link) => link.href);

    applications.forEach((app) => {
      if (APPS_TO_BE_PRECONNECTED.includes(app.baseUrl) && !preconnectLinksHref.includes(app.baseUrl)) {
        const link = document.createElement("link");
        link.rel = "preconnect";
        link.href = app.baseUrl;
        head.appendChild(link);
      }
    });
  };

  public static saveAllApplicationsToSessionStorage = async () => {
    let response = await ApplicationService.getAllApplications();
    response = response.filter((app) => app !== null && typeof app === "object");
    sessionStorage.setItem("all-applications", JSON.stringify(response));
  };

  public static getAllApplicationsFromSessionStorageRaw = (): string | null => {
    const allApplications: string | null = sessionStorage.getItem("all-applications");
    if (!allApplications) {
      return null;
    }
    return allApplications;
  };

  public static getAllApplicationsFromSessionStorage = (): IApplicationInfo[] | null => {
    const applications: string = ApplicationService.getAllApplicationsFromSessionStorageRaw();

    if (!applications || typeof applications !== "string") {
      return null;
    }

    const parsedApplications = JSON.parse(applications);

    if (!Array.isArray(parsedApplications)) {
      return null;
    }

    return parsedApplications.filter((app) => app !== null && typeof app === "object");
  };
}
