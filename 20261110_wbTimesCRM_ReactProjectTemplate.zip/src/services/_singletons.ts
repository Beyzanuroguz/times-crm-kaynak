import KuikaCoreWasmBridgeService from "./kuika-core-wasm-bridge-service";
import TranslationService from "./translation-service";

// TODO: Ilyas: Injection container
// TODO: Ilyas: inject() function and @inject() decorator

export const translationService = new TranslationService();
export const kuikaCoreWasmBridgeService = KuikaCoreWasmBridgeService.getInstance();
