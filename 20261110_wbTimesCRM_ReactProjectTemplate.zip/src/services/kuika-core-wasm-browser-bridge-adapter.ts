/**
 * Browser WASM Bridge Adapter.
 *
 * Hosts the .NET browser-wasm runtime inside a DEDICATED Web Worker (see kuika-core-wasm-worker.ts)
 * so the offline SQLite engine can back its storage with OPFS (paged, off the main heap) — removing
 * the whole-DB-in-linear-memory ceiling.
 *
 * MUST be a dedicated Worker: the OPFS pool relies on `FileSystemFileHandle.createSyncAccessHandle()`,
 * available ONLY inside dedicated Web Workers (never SharedWorkers / the main thread). Because OPFS
 * sync access handles are exclusive per origin, only ONE tab may own the worker at a time.
 *
 * MULTI-TAB: to let every tab read/write, one tab is elected LEADER (owns the worker) and the others
 * are FOLLOWERS that forward operations to it — see {@link OfflineLeaderCoordinator} (Web Locks +
 * BroadcastChannel). When Web Locks / BroadcastChannel are unavailable we degrade to a single-tab
 * local worker. Either way this adapter routes each op through {@link route}: the leader runs it on
 * its {@link LocalWorkerClient}; a follower sends it to the leader.
 *
 * The public surface (IKuikaCoreWasmBridgeAdapter) is unchanged and already async, so callers are
 * unaffected. SECURITY: only semantic method names + their data/bytes cross the boundary — never SQL.
 */

import { KuikaAppManager } from "../shared/utilty/kuika-app-manager";
import { IKuikaCoreWasmBridgeAdapter } from "./kuika-core-wasm-bridge-adapter";
import { OfflineLeaderCoordinator, OfflineRpcRequest, OfflineRpcResult } from "./offline-leader-coordinator";

/** A worker call awaiting its response, keyed by correlation id. */
interface PendingCall {
  resolve: (value: unknown) => void;
  reject: (reason: Error) => void;
}

/** Shape of every message the worker posts back. */
interface WorkerResponse {
  id: number;
  ok: boolean;
  result?: unknown;
  error?: string;
  /** Present on the init response: whether the OPFS pool mounted (durable storage). */
  opfsActive?: boolean;
}

/** Messages the client posts to the dedicated worker (correlation id added per send). */
interface WorkerCallMessage {
  type: "call";
  id: number;
  method: string;
  args: readonly unknown[];
}

interface WorkerImportBeginMessage {
  type: "importBegin";
  id: number;
}

interface WorkerImportChunkMessage {
  type: "importChunk";
  id: number;
  offset: number;
  chunk: Uint8Array;
}

interface WorkerImportEndMessage {
  type: "importEnd";
  id: number;
}

interface WorkerWipeMessage {
  type: "wipe";
  id: number;
}

type WorkerOutboundMessage =
  | WorkerCallMessage
  | WorkerImportBeginMessage
  | WorkerImportChunkMessage
  | WorkerImportEndMessage
  | WorkerWipeMessage;

/** Longest a held import session may block other ops before the mutex is force-released (deadlock guard). */
const IMPORT_SESSION_WATCHDOG_MS = 120000;

/**
 * Owns THIS tab's dedicated worker and serializes every operation against it. Only the LEADER tab
 * has one. Serialization matters across tabs: the worker processes messages one at a time, but a
 * streaming import spans several messages (begin → chunk* → end) during which the DB is closed, so a
 * concurrent `call` from another tab would hit a closed DB. We therefore hold an internal mutex for
 * the whole import session and run every other op under the same mutex.
 */
class LocalWorkerClient {
  private worker: Worker | null = null;

  private nextCallId = 1;

  private opfsActiveFlag = false;

  private readonly pending: Map<number, PendingCall> = new Map();

  private mutexTail: Promise<void> = Promise.resolve();

  private importRelease: (() => void) | null = null;

  private importWatchdog: ReturnType<typeof setTimeout> | null = null;

  /** Spawn the worker and initialize the runtime. Returns whether OPFS mounted (durable storage). */
  async start(wasmBaseUrl: string): Promise<boolean> {
    if (this.worker) {
      return this.opfsActiveFlag;
    }
    const worker: Worker = new Worker(new URL("./kuika-core-wasm-worker.ts", import.meta.url), {
      type: "module"
    });
    worker.onmessage = (event: MessageEvent): void => this.onMessage(event.data as WorkerResponse);
    worker.onerror = (event: ErrorEvent): void => this.onError(event);
    this.worker = worker;

    const initId: number = this.nextCallId++;
    await new Promise<void>((resolve: () => void, reject: (reason: Error) => void): void => {
      this.pending.set(initId, { resolve: (): void => resolve(), reject });
      worker.postMessage({ type: "init", id: initId, wasmBaseUrl });
    });
    return this.opfsActiveFlag;
  }

  /** Run one request against the worker, serialized (import sessions hold the mutex begin→end). */
  async execute(request: OfflineRpcRequest): Promise<OfflineRpcResult> {
    if (request.kind === "importBegin") {
      return this.executeImportBegin(request);
    }
    if (request.kind === "importChunk" || request.kind === "importEnd") {
      return this.executeImportStep(request);
    }
    return this.executeNormal(request);
  }

  private async executeNormal(request: OfflineRpcRequest): Promise<OfflineRpcResult> {
    const release: () => void = await this.acquire();
    try {
      return await this.dispatch(request);
    } catch (error) {
      return this.toErrorResult(error);
    } finally {
      release();
    }
  }

  private async executeImportBegin(request: OfflineRpcRequest): Promise<OfflineRpcResult> {
    const release: () => void = await this.acquire();
    this.importRelease = release;
    this.armImportWatchdog();
    try {
      return await this.dispatch(request);
    } catch (error) {
      this.releaseImport();
      return this.toErrorResult(error);
    }
  }

  private async executeImportStep(request: OfflineRpcRequest): Promise<OfflineRpcResult> {
    this.armImportWatchdog();
    try {
      const result: OfflineRpcResult = await this.dispatch(request);
      if (request.kind === "importEnd") {
        this.releaseImport();
      }
      return result;
    } catch (error) {
      // Never leave the mutex held on a broken import — that would deadlock every later op.
      this.releaseImport();
      return this.toErrorResult(error);
    }
  }

  private async dispatch(request: OfflineRpcRequest): Promise<OfflineRpcResult> {
    if (request.kind === "call") {
      const method: string = request.method ?? "";
      const result: unknown = await this.post({ type: "call", id: 0, method, args: request.args ?? [] });
      return { ok: true, result };
    }
    if (request.kind === "importBegin") {
      await this.post({ type: "importBegin", id: 0 });
      return { ok: true };
    }
    if (request.kind === "importChunk") {
      const chunk: Uint8Array = request.chunk ?? new Uint8Array(0);
      await this.post({ type: "importChunk", id: 0, offset: request.offset ?? 0, chunk }, [chunk.buffer]);
      return { ok: true };
    }
    if (request.kind === "importEnd") {
      await this.post({ type: "importEnd", id: 0 });
      return { ok: true };
    }
    // request.kind === "wipe"
    await this.post({ type: "wipe", id: 0 });
    return { ok: true };
  }

  private post(message: WorkerOutboundMessage, transfer?: Transferable[]): Promise<unknown> {
    const worker: Worker | null = this.worker;
    if (!worker) {
      return Promise.reject(new Error("KuikaCore worker not available"));
    }
    const id: number = this.nextCallId++;
    const outbound: WorkerOutboundMessage = { ...message, id };
    return new Promise<unknown>((resolve: (value: unknown) => void, reject: (reason: Error) => void): void => {
      this.pending.set(id, { resolve, reject });
      if (transfer) {
        worker.postMessage(outbound, transfer);
      } else {
        worker.postMessage(outbound);
      }
    });
  }

  private onMessage(response: WorkerResponse): void {
    if (typeof response.opfsActive === "boolean") {
      this.opfsActiveFlag = response.opfsActive;
    }
    const call: PendingCall | undefined = this.pending.get(response.id);
    if (!call) {
      return;
    }
    this.pending.delete(response.id);
    if (response.ok) {
      call.resolve(response.result);
    } else {
      call.reject(new Error(response.error ?? "KuikaCore worker call failed"));
    }
  }

  private onError(event: ErrorEvent): void {
    const error: Error = new Error(`KuikaCore worker error: ${event.message}`);
    for (const call of this.pending.values()) {
      call.reject(error);
    }
    this.pending.clear();
    this.releaseImport();
  }

  // #region Mutex + import session

  private acquire(): Promise<() => void> {
    let release: () => void = (): void => {};
    const gate: Promise<void> = new Promise<void>((resolve: () => void): void => {
      release = resolve;
    });
    const previous: Promise<void> = this.mutexTail;
    this.mutexTail = previous.then((): Promise<void> => gate);
    return previous.then((): (() => void) => release);
  }

  private armImportWatchdog(): void {
    if (this.importWatchdog) {
      clearTimeout(this.importWatchdog);
    }
    this.importWatchdog = setTimeout((): void => {
      console.warn("LocalWorkerClient: import session watchdog fired — releasing the mutex");
      this.releaseImport();
    }, IMPORT_SESSION_WATCHDOG_MS);
  }

  private releaseImport(): void {
    if (this.importWatchdog) {
      clearTimeout(this.importWatchdog);
      this.importWatchdog = null;
    }
    if (this.importRelease) {
      this.importRelease();
      this.importRelease = null;
    }
  }

  private toErrorResult(error: unknown): OfflineRpcResult {
    return { ok: false, error: error instanceof Error ? error.message : String(error) };
  }

  // #endregion Mutex + import session
}

export class BrowserBridgeAdapter implements IKuikaCoreWasmBridgeAdapter {
  private initPromise: Promise<void> | null = null;

  private isInitialized = false;

  private opfsActive = false;

  private readonly local: LocalWorkerClient = new LocalWorkerClient();

  /** Set only in multi-tab mode; null when we degrade to a single-tab local worker. */
  private coordinator: OfflineLeaderCoordinator | null = null;

  async initialize(): Promise<void> {
    if (this.isInitialized) {
      return;
    }
    if (this.initPromise) {
      return this.initPromise;
    }
    this.initPromise = this.doInitialize();
    await this.initPromise;
  }

  private async doInitialize(): Promise<void> {
    try {
      const wasmBaseUrl: string = `${KuikaAppManager.GetFrontEndUrl()}/wasm/kuika-dotnet-core/browser`;

      if (!OfflineLeaderCoordinator.isSupported()) {
        // Single-tab fallback (no Web Locks / BroadcastChannel): just own the worker directly.
        console.log("BrowserBridgeAdapter: single-tab mode — starting local worker");
        this.opfsActive = await this.local.start(wasmBaseUrl);
        this.isInitialized = true;
        return;
      }

      console.log("BrowserBridgeAdapter: multi-tab mode — electing leader");
      const coordinator: OfflineLeaderCoordinator = new OfflineLeaderCoordinator();
      this.coordinator = coordinator;
      await coordinator.start(
        (request: OfflineRpcRequest): Promise<OfflineRpcResult> => this.local.execute(request),
        async (): Promise<void> => {
          this.opfsActive = await this.local.start(wasmBaseUrl);
        }
      );

      if (coordinator.isLeader()) {
        console.log("BrowserBridgeAdapter: this tab is the offline LEADER");
      } else {
        // Follower: it never persists locally — the leader owns the durable store. So report durable
        // (skip the base64/IndexedDB mirror) and streaming-capable; both go to the leader's OPFS pool.
        // (The only case this is "wrong" is a :memory: leader in incognito — an already-degraded path.)
        this.opfsActive = true;
        console.log("BrowserBridgeAdapter: this tab is an offline FOLLOWER");
      }

      this.isInitialized = true;
    } catch (error) {
      this.initPromise = null;
      this.coordinator = null;
      console.error("BrowserBridgeAdapter: Failed to initialize", error);
      throw error;
    }
  }

  /** Route one op to the leader's worker: locally when we are (or became) the leader, else via RPC. */
  private async route(request: OfflineRpcRequest): Promise<OfflineRpcResult> {
    await this.initialize();
    if (this.coordinator) {
      return this.coordinator.route(request);
    }
    return this.local.execute(request);
  }

  /**
   * Forward a [JSExport] method call by name. Generated table/query adapter methods (injected at the
   * placeholder below) call this too.
   */
  private async invoke<TResult>(method: string, args: readonly unknown[]): Promise<TResult> {
    const result: OfflineRpcResult = await this.route({ kind: "call", method, args });
    if (!result.ok) {
      throw new Error(result.error ?? "KuikaCore worker call failed");
    }
    return result.result as TResult;
  }

  getIsInitialized(): boolean {
    return this.isInitialized;
  }

  getAdapterType(): "browser" | "electron" {
    return "browser";
  }

  /**
   * True when the engine persists the DB durably by itself (OPFS pool mounted) — callers then skip
   * the whole-DB base64 → IndexedDB mirror. False on the :memory: fallback (incognito / OPFS
   * unavailable). For a follower this reflects the LEADER's worker (learned during init).
   */
  hasDurablePersistence(): boolean {
    return this.opfsActive;
  }

  supportsStreamingImport(): boolean {
    // Streaming writes go to the OPFS pool; only valid when OPFS actually mounted (leader's pool).
    return this.opfsActive;
  }

  // Core methods
  async Add(a: number, b: number): Promise<number> {
    return this.invoke<number>("Add", [a, b]);
  }

  async Ping(): Promise<string> {
    return this.invoke<string>("Ping", []);
  }

  // Database lifecycle methods
  async Db_Initialize(): Promise<void> {
    return this.invoke<void>("Db_Initialize", []);
  }

  async Db_IsInitialized(): Promise<boolean> {
    return this.invoke<boolean>("Db_IsInitialized", []);
  }

  async Db_Close(): Promise<void> {
    return this.invoke<void>("Db_Close", []);
  }

  // Database import/export methods
  async Db_ExportDatabaseBase64(): Promise<string> {
    return this.invoke<string>("Db_ExportDatabaseBase64", []);
  }

  async Db_ImportDatabaseBase64(base64Data: string): Promise<void> {
    return this.invoke<void>("Db_ImportDatabaseBase64", [base64Data]);
  }

  // Sync methods
  async Db_GetPendingChanges(): Promise<string> {
    return this.invoke<string>("Db_GetPendingChanges", []);
  }

  async Db_MarkAsSynced(tableRecordsJson: string): Promise<void> {
    return this.invoke<void>("Db_MarkAsSynced", [tableRecordsJson]);
  }

  async Db_GetOfflineTableSettings(): Promise<string> {
    return this.invoke<string>("Db_GetOfflineTableSettings", []);
  }

  async Db_GetUnsentRecordsBase64(): Promise<string> {
    return this.invoke<string>("Db_GetUnsentRecordsBase64", []);
  }

  async Db_MarkAsSyncedWithCriteria(): Promise<void> {
    return this.invoke<void>("Db_MarkAsSyncedWithCriteria", []);
  }

  async Db_MarkPayloadAsSynced(payloadBase64: string): Promise<void> {
    return this.invoke<void>("Db_MarkPayloadAsSynced", [payloadBase64]);
  }

  // Device metadata methods
  async Db_ImportDatabaseBase64WithReset(base64Data: string): Promise<void> {
    return this.invoke<void>("Db_ImportDatabaseBase64WithReset", [base64Data]);
  }

  async Db_ImportDatabaseBytesWithReset(bytes: Uint8Array): Promise<void> {
    return this.invoke<void>("Db_ImportDatabaseBytesWithReset", [bytes]);
  }

  async Db_UpdateDeviceMetadata(
    deviceId: string | null,
    deviceName: string | null,
    bundleId: string | null,
    projectName: string | null
  ): Promise<void> {
    return this.invoke<void>("Db_UpdateDeviceMetadata", [deviceId, deviceName, bundleId, projectName]);
  }

  async Db_GetDeviceMetadata(): Promise<string> {
    return this.invoke<string>("Db_GetDeviceMetadata", []);
  }

  // Streaming import — write the downloaded DB straight into the OPFS file, chunk-by-chunk, so no
  // full DB buffer is ever held. On a follower these route to the leader over the channel (the chunk
  // is copied, not transferred — acceptable for the rare full re-fetch); on the leader they run
  // locally with zero-copy transfer.
  async importStreamBegin(): Promise<void> {
    const result: OfflineRpcResult = await this.route({ kind: "importBegin" });
    this.throwIfFailed(result, "importStreamBegin");
  }

  async importStreamChunk(offset: number, chunk: Uint8Array): Promise<void> {
    const result: OfflineRpcResult = await this.route({ kind: "importChunk", offset, chunk });
    this.throwIfFailed(result, "importStreamChunk");
  }

  async importStreamEnd(): Promise<void> {
    const result: OfflineRpcResult = await this.route({ kind: "importEnd" });
    this.throwIfFailed(result, "importStreamEnd");
  }

  /**
   * Permanently delete the OPFS-backed offline database. Routed to the leader (it owns the exclusive
   * sync access handles): it closes the engine, releases its handles, removes the `.kuika-opfs`
   * directory, and re-mounts a fresh empty pool on the same runtime (no terminate).
   */
  async purgeDurableStore(): Promise<void> {
    const result: OfflineRpcResult = await this.route({ kind: "wipe" });
    this.throwIfFailed(result, "purgeDurableStore");
  }

  private throwIfFailed(result: OfflineRpcResult, op: string): void {
    if (!result.ok) {
      throw new Error(result.error ?? `KuikaCore worker ${op} failed`);
    }
  }

  // table-browser-adapter-methods-placeholder
}
