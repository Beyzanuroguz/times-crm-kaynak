/**
 * WASM method signatures exposed by KuikaCore (sync version).
 * Single source of truth - matches .NET [JSExport] naming (PascalCase).
 * Used directly by browser-wasm exports.
 *
 * Database is imported/exported as a complete unit - no schema generation.
 */
export interface IKuikaCoreWasmMethods {
  // Core methods
  Add(a: number, b: number): number;
  Ping(): string;

  // Database lifecycle methods
  Db_Initialize(): void;
  Db_IsInitialized(): boolean;
  Db_Close(): void;

  // Database import/export methods
  Db_ExportDatabaseBase64(): string;
  Db_ImportDatabaseBase64(base64Data: string): void;

  // Sync methods
  Db_GetPendingChanges(): string;
  Db_MarkAsSynced(tableRecordsJson: string): void;
  Db_GetOfflineTableSettings(): string;
  Db_GetUnsentRecordsBase64(): string;
  Db_MarkAsSyncedWithCriteria(): void;
  Db_MarkPayloadAsSynced(payloadBase64: string): void;

  // Device metadata methods
  Db_ImportDatabaseBase64WithReset(base64Data: string): void;
  Db_ImportDatabaseBytesWithReset(bytes: Uint8Array): void;
  Db_UpdateDeviceMetadata(
    deviceId: string | null,
    deviceName: string | null,
    bundleId: string | null,
    projectName: string | null
  ): void;
  Db_GetDeviceMetadata(): string;

  // table-interface-methods-placeholder
}

/**
 * Async version of WASM methods for adapters.
 * Derived from IKuikaCoreWasmMethods - wraps return types in Promise.
 */
export type IKuikaCoreWasmMethodsAsync = {
  [K in keyof IKuikaCoreWasmMethods]: (
    ...args: Parameters<IKuikaCoreWasmMethods[K]>
  ) => Promise<ReturnType<IKuikaCoreWasmMethods[K]>>;
};

/**
 * Interface for WASM bridge adapters.
 * Allows switching between browser and Electron implementations.
 */
export interface IKuikaCoreWasmBridgeAdapter extends IKuikaCoreWasmMethodsAsync {
  /**
   * Initialize the WASM runtime.
   */
  initialize(): Promise<void>;

  /**
   * Check if the WASM runtime is initialized.
   */
  getIsInitialized(): boolean;

  /**
   * Get the adapter type.
   */
  getAdapterType(): "browser" | "electron";

  /**
   * Whether the engine persists the DB durably on its own (OPFS pool on web / native file on
   * Electron). When true, callers skip the whole-DB base64 → IndexedDB mirror. False only on the
   * browser :memory: fallback (incognito / OPFS locked), where IndexedDB persistence is used.
   */
  hasDurablePersistence(): boolean;

  /**
   * Whether streaming import (write the downloaded DB straight into the durable store chunk-by-chunk,
   * no full buffer) is supported. True on the browser OPFS path; false elsewhere (Electron uses its
   * native file import; the :memory: fallback uses the byte import).
   */
  supportsStreamingImport(): boolean;

  /** Streaming import: begin a fresh write of the DB file (engine closed, target truncated). */
  importStreamBegin(): Promise<void>;

  /** Streaming import: write one downloaded chunk at the given byte offset. */
  importStreamChunk(offset: number, chunk: Uint8Array): Promise<void>;

  /** Streaming import: finalize the file, reopen the engine on it, and reset sync flags. */
  importStreamEnd(): Promise<void>;

  /**
   * Permanently delete the durable offline store and leave the adapter in a clean, uninitialized
   * state. On the browser OPFS path this closes the engine, releases the pool's sync access handles,
   * removes the `.kuika-opfs` directory, and terminates the worker (so a later fetch re-creates a
   * fresh, empty pool). On Electron it closes the native SQLite DB. Callers still clear the
   * IndexedDB base64 mirror separately (only ever written on the browser `:memory:` fallback).
   */
  purgeDurableStore(): Promise<void>;
}
