import { KuikaAppManager } from "../shared/utilty/kuika-app-manager";
import { ReactSystemFunctions } from "../shared/utilty/react-system-functions";

export interface IRedirectToOptions {
  openInNewTab: boolean;
}

declare let window: any;

class HelperService {
  static getClientSecret(): string {
    return "f91c40f65c017db7cbb5b6b2a77ff736d62b3251b69df2b1b5ffe13971ad22aa";
  }

  static getClientId(): string {
    let appKey = "default";
    try {
      const backEndUrl = KuikaAppManager.GetBackendUrl(true) || "";
      const frontEndUrl = KuikaAppManager.GetFrontEndUrl() || "";
      appKey = `${frontEndUrl}|${backEndUrl}`.toLowerCase();
    } catch (_) {
      // ignore
    }

    const STORAGE_KEY = `kuika_client_id${appKey}`;

    try {
      const existing = localStorage.getItem(STORAGE_KEY);
      if (existing && existing.trim().length > 0) return existing;

      const newId = HelperService.generateUuidV4();
      localStorage.setItem(STORAGE_KEY, newId);
      return newId;
    } catch (_) {
      return HelperService.generateUuidV4();
    }
  }

  private static generateUuidV4(): string {
    const c: any = (globalThis as any).crypto;
    if (c?.randomUUID) return c.randomUUID();

    const bytes = new Uint8Array(16);
    if (c?.getRandomValues) c.getRandomValues(bytes);
    else for (let i = 0; i < 16; i++) bytes[i] = Math.floor(Math.random() * 256);

    bytes[6] = (bytes[6] & 0x0f) | 0x40;
    bytes[8] = (bytes[8] & 0x3f) | 0x80;

    const hex = [...bytes].map((b) => b.toString(16).padStart(2, "0")).join("");
    return `${hex.slice(0, 8)}-${hex.slice(8, 12)}-${hex.slice(12, 16)}-${hex.slice(16, 20)}-${hex.slice(20)}`;
  }

  static redirectGotoStartingScreen = async (screen?: string) => {
    let screenName: string = ReactSystemFunctions.getScreenNameByActiveUserRoles();

    if (
      (screenName === "" || screenName === undefined) &&
      window.userInfo?.startingScreenId &&
      window.userInfo.startingScreenId.length > 0
    ) {
      screenName = ReactSystemFunctions.getScreenNameById(window.userInfo.startingScreenId);
    }

    if (screenName === "" || screenName === undefined) {
      HelperService.redirectToPath(screen ?? "/ROLEAUTH");
    } else {
      HelperService.redirectToPath(`/${screenName}`);
    }
  };

  static getIsInLoginPage(): boolean {
    return window.location.pathname.includes("/signin");
  }

  // Builds the "?redirectUri=..." query that the login screen reads after a
  // successful sign-in (ReactSystemFunctions.goToNextScreenAfterLogin) to send
  // the user back to the page they originally requested. Returns "" when there
  // is nothing meaningful to preserve (no target, or the app root). Shared by
  // gotoLogin (interceptor path) and PrivateRoute (route-guard path) so both
  // producers emit a byte-identical query the read side can consume.
  static buildLoginRedirectQuery(redirectUri?: string): string {
    if (!redirectUri || redirectUri.trim() === "") {
      return "";
    }
    const frontEnd: URL = new URL(KuikaAppManager.GetFrontEndUrl());
    const basePath: string = frontEnd.pathname;
    let relativeUri: string = redirectUri;
    // Strip the deployment base path (virtual directory) prefix so the stored
    // value is router-relative — react-router re-applies the base path on
    // navigation. A "/" base path has no meaningful prefix and anchoring the
    // strip to the start avoids dropping the target's own leading slash.
    if (basePath !== "/" && relativeUri.startsWith(basePath)) {
      relativeUri = relativeUri.slice(basePath.length);
    }
    if (relativeUri === "" || relativeUri === "/") {
      return "";
    }
    if (!relativeUri.startsWith("/")) {
      relativeUri = "/" + relativeUri;
    }
    return `?redirectUri=${encodeURIComponent(relativeUri)}`;
  }

  static gotoLogin(redirectUri?: string) {
    const query: string = HelperService.buildLoginRedirectQuery(redirectUri);
    HelperService.redirectToPath("/signin" + query);
  }

  static redirectToPath(path: string, options?: IRedirectToOptions): void {
    const isWebComponent = KuikaAppManager.IsWebComponent();

    if (isWebComponent) {
      const url = new URL(window.location.href);
      url.hash = path;
      HelperService.redirectToFullUrl(url.toString(), options);
    } else {
      const frontEndUrl = KuikaAppManager.GetFrontEndUrl();
      HelperService.redirectToFullUrl(`${frontEndUrl}${path}`, options);
    }
  }

  static redirectToFullUrl(url: string, options?: IRedirectToOptions): void {
    if (options?.openInNewTab) {
      window.open(url, "_blank", "noopener,noreferrer");
    } else {
      window.location.replace(url);
    }
  }
}

export default HelperService;
