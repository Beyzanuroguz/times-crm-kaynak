/**
 * Offline Database Sync Service
 *
 * Handles synchronization between the local SQLite database and the backend:
 * - fetchOfflineDb: Download fresh database from server
 * - pushOfflineDb: Upload local changes to server
 *
 * Sync flow:
 * 1. Check for pending local changes (SentFromMobile = 0)
 * 2. If online, push local changes to server
 * 3. Fetch fresh database from server
 * 4. Import fetched database into local SQLite
 */

import Axios from "axios";
import { KuikaAppManager } from "../shared/utilty/kuika-app-manager";
import { transformUrlForElectron } from "./electron-bridge-service";
import KuikaCoreWasmBridgeService from "./kuika-core-wasm-bridge-service";
import OfflineDbPersistenceService from "./offline-db-persistence-service";

export interface SyncResult {
  success: boolean;
  error?: string;
  pushedChanges?: boolean;
  fetchedData?: boolean;
}

export interface SyncOptions {
  /** Force sync even if no pending changes */
  forceFetch?: boolean;
}

export interface FetchDataResult {
  success: boolean;
  /** Raw SQLite database bytes downloaded from the server (binary transport, no base64). */
  data?: Uint8Array;
  error?: string;
}

export interface PushResult {
  success: boolean;
  error?: string;
  /**
   * The exact base64 payload that was POSTed to the server. The caller must
   * mark synced against THIS payload (Db_MarkPayloadAsSynced), not re-scan
   * the DB, so rows added during the push network window are not marked
   * synced without being sent.
   */
  payload?: string;
}

/**
 * Offline database sync service.
 */
class OfflineSyncService {
  private static instance: OfflineSyncService | null = null;

  private isSyncing = false;

  private constructor() {}

  /**
   * Get the singleton instance.
   */
  static getInstance(): OfflineSyncService {
    if (!OfflineSyncService.instance) {
      OfflineSyncService.instance = new OfflineSyncService();
    }
    return OfflineSyncService.instance;
  }

  /**
   * Check if a sync operation is in progress.
   */
  getIsSyncing(): boolean {
    return this.isSyncing;
  }

  /**
   * Perform a full sync operation:
   * 1. Push local changes to server
   * 2. Fetch fresh data from server
   * 3. Import into local database
   * 4. Persist to storage
   */
  async sync(options: SyncOptions = {}): Promise<SyncResult> {
    if (this.isSyncing) {
      return { success: false, error: "Sync already in progress" };
    }

    this.isSyncing = true;
    const result: SyncResult = { success: false };

    try {
      const wasmService = KuikaCoreWasmBridgeService.getInstance();
      const persistenceService = OfflineDbPersistenceService.getInstance();

      // Ensure WASM is initialized
      await wasmService.initialize();

      // Check if database is initialized
      const isDbInitialized = await wasmService.Db_IsInitialized();
      if (!isDbInitialized) {
        console.log("OfflineSyncService: Database not initialized, initializing...");
        await wasmService.ensureDbInitialized();
      }

      // Step 1: Push local changes if any
      const pendingChangesJson = await wasmService.Db_GetPendingChanges();
      const pendingChanges = JSON.parse(pendingChangesJson);
      const hasPendingChanges = Object.keys(pendingChanges).length > 0;

      if (hasPendingChanges) {
        console.log("OfflineSyncService: Found pending changes, pushing to server");
        const pushResult = await this.pushChanges(options);
        result.pushedChanges = pushResult.success;

        if (pushResult.success && pushResult.payload) {
          // Mark synced EXACTLY the rows that were in the pushed payload.
          // A criteria-based re-scan here would also mark rows added during
          // the push network window — they'd never be sent and be lost.
          await wasmService.Db_MarkPayloadAsSynced(pushResult.payload);
          console.log("OfflineSyncService: Marked pushed payload rows as synced");
        } else {
          console.warn("OfflineSyncService: Failed to push changes", pushResult.error);
        }
      }

      // Step 2: Fetch fresh data from server (if requested or no local data). fetchAndImport picks
      // the memory-optimal path: streaming straight into OPFS on the browser, byte import otherwise.
      if (options.forceFetch || !hasPendingChanges) {
        console.log("OfflineSyncService: Fetching fresh data from server");
        result.fetchedData = await this.fetchAndImport(options);
      }

      // Step 3: Persist to storage. With a durable store (OPFS / native file) the DB is already
      // persisted — we must NOT call Db_ExportDatabaseBase64 (it would materialize the whole DB as
      // a base64 string in WASM, the very OOM we removed).
      if (wasmService.hasDurablePersistence()) {
        console.log("OfflineSyncService: Durable OPFS/native store — no base64 mirror needed");
      } else {
        const exportedData = await wasmService.Db_ExportDatabaseBase64();
        await persistenceService.saveDatabase(exportedData);
        console.log("OfflineSyncService: Persisted database to storage (base64 mirror)");
      }

      result.success = true;
    } catch (error) {
      console.error("OfflineSyncService: Sync failed", error);
      result.error = error instanceof Error ? error.message : "Unknown error";
    } finally {
      this.isSyncing = false;
    }

    return result;
  }

  /**
   * Push local changes to the server.
   */
  async pushChanges(options: SyncOptions = {}): Promise<PushResult> {
    try {
      const wasmService = KuikaCoreWasmBridgeService.getInstance();

      // Ensure the WASM runtime and the offline DB (from IndexedDB) are loaded before
      // reading unsent records. On a fresh page load nothing has triggered initialization
      // yet, so Db_GetUnsentRecordsBase64 would throw "Database not initialized".
      await wasmService.initialize();
      await wasmService.ensureDbInitialized();
      const isDbReady: boolean = await wasmService.Db_IsInitialized();
      if (!isDbReady) {
        return {
          success: false,
          error: "Offline database not available. Fetch the offline database first."
        };
      }

      // Export only unsent records matching criteria (matches iOS/Android behavior)
      const base64Data: string = await wasmService.Db_GetUnsentRecordsBase64();

      // Build API URL using proper backend URL
      const url = `${this.getBackendUrl()}/offlinedb/pushOfflineDb`;

      // Use Axios so interceptors handle auth token, refresh, and offline detection
      await Axios.post(url, { content: base64Data });

      console.log("OfflineSyncService: Successfully pushed changes to server");
      // Return the exact bytes sent so the caller marks synced only what was
      // actually transmitted (Db_MarkPayloadAsSynced), not a fresh DB re-scan.
      return { success: true, payload: base64Data };
    } catch (error) {
      const errorMessage = error instanceof Error ? error.message : "Unknown error";
      console.error("OfflineSyncService: Push failed", error);
      return { success: false, error: errorMessage };
    }
  }

  /**
   * Fetch fresh data from the server.
   *
   * The endpoint streams the SQLite database as raw bytes (application/octet-stream), not a base64
   * JSON envelope: a large offline DB would otherwise exceed the JS/.NET string size limit and OOM on
   * both server and client. We download it as an ArrayBuffer and import the bytes directly.
   */
  async fetchData(options: SyncOptions = {}): Promise<FetchDataResult> {
    try {
      // Build API URL using proper backend URL
      const url = `${this.getBackendUrl()}/offlinedb/fetchOfflineDb`;

      // Use Axios so interceptors handle auth token, refresh, and offline detection
      const response = await Axios.get(url, { responseType: "arraybuffer" });

      const buffer = response.data as ArrayBuffer;
      if (!buffer || buffer.byteLength === 0) {
        return { success: false, error: "No data returned from server" };
      }

      console.log("OfflineSyncService: Successfully fetched data from server");
      return { success: true, data: new Uint8Array(buffer) };
    } catch (error) {
      const errorMessage = error instanceof Error ? error.message : "Unknown error";
      console.error("OfflineSyncService: Fetch failed", error);
      return { success: false, error: errorMessage };
    }
  }

  /**
   * Fetch the offline DB from the server and import it, picking the memory-optimal path:
   * - Browser + OPFS: STREAM the download straight into the OPFS file, chunk-by-chunk (no full-DB
   *   buffer, no WASM byte[]) — supports multi-GB DBs, quota permitting.
   * - Otherwise (Electron / :memory: fallback): binary fetch → Db_ImportDatabaseBytesWithReset.
   * Returns true when data was imported.
   */
  async fetchAndImport(options: SyncOptions = {}): Promise<boolean> {
    const wasmService = KuikaCoreWasmBridgeService.getInstance();
    await wasmService.initialize();

    if (wasmService.supportsStreamingImport()) {
      const bytesWritten = await this.streamFetchImport();
      if (bytesWritten > 0) {
        await this.updateDeviceMetadata();
        console.log(`OfflineSyncService: Streamed ${bytesWritten} bytes into OPFS`);
        return true;
      }
      return false;
    }

    const fetchResult = await this.fetchData(options);
    if (fetchResult.success && fetchResult.data) {
      await wasmService.Db_ImportDatabaseBytesWithReset(fetchResult.data);
      await this.updateDeviceMetadata();
      return true;
    }
    if (!fetchResult.success) {
      console.warn("OfflineSyncService: Failed to fetch data", fetchResult.error);
    }
    return false;
  }

  /**
   * Import the offline DB into the durable OPFS store WITHOUT ever holding a full DB copy in WASM
   * linear memory: the proven Axios byte fetch (auth interceptors) gives us the exact SQLite bytes,
   * then we hand them to the worker in chunks that are written straight to the OPFS file (no C#
   * byte[]). This removes the ~2 GB WASM byte[] import ceiling; the remaining bound is the
   * main-thread ArrayBuffer from the fetch. (A fully streamed authenticated download — for >2 GB —
   * is a separate follow-up; a raw fetch() must replicate every auth/domain interceptor header, so
   * we deliberately reuse Axios here for correctness.) Returns the number of bytes written.
   */
  private async streamFetchImport(): Promise<number> {
    const wasmService = KuikaCoreWasmBridgeService.getInstance();

    const fetchResult = await this.fetchData();
    if (!fetchResult.success || !fetchResult.data) {
      console.warn("OfflineSyncService: Failed to fetch data for streaming import", fetchResult.error);
      return 0;
    }
    const bytes: Uint8Array = fetchResult.data;

    const CHUNK_SIZE = 8 * 1024 * 1024; // 8 MB per postMessage to the worker
    await wasmService.importStreamBegin();
    let offset = 0;
    try {
      while (offset < bytes.byteLength) {
        const end: number = Math.min(offset + CHUNK_SIZE, bytes.byteLength);
        // slice() copies into its own buffer so the chunk can be transferred without detaching the
        // shared source buffer.
        const chunk: Uint8Array = bytes.slice(offset, end);
        await wasmService.importStreamChunk(offset, chunk);
        offset = end;
      }
      await wasmService.importStreamEnd();
    } catch (error) {
      // Finalize so the engine reopens on whatever landed; caller treats a throw as failure.
      try {
        await wasmService.importStreamEnd();
      } catch {
        /* ignore */
      }
      throw error;
    }
    return offset;
  }

  /**
   * Initialize local database from persisted storage.
   * Call this on app startup to restore the previous database state.
   */
  async initializeFromStorage(): Promise<boolean> {
    try {
      const wasmService = KuikaCoreWasmBridgeService.getInstance();
      const persistenceService = OfflineDbPersistenceService.getInstance();

      // Initialize services. wasmService.initialize() mounts OPFS + sets the DB path in the worker.
      await wasmService.initialize();

      // Durable store (OPFS pool / native file): open the existing file directly. Do NOT read the
      // IndexedDB mirror (it may hold stale pre-OPFS data, and a large export/import would OOM).
      if (wasmService.hasDurablePersistence()) {
        await wasmService.Db_Initialize();
        const hasData = await wasmService.Db_IsInitialized();
        if (hasData) {
          await this.updateDeviceMetadata();
        }
        console.log(`OfflineSyncService: Opened durable DB (hasData=${hasData})`);
        return hasData;
      }

      // Fallback (browser :memory:, e.g. incognito): restore from the IndexedDB base64 mirror.
      await persistenceService.initialize();
      const persistedData = await persistenceService.loadDatabase();

      if (persistedData) {
        console.log("OfflineSyncService: Found persisted database, importing");
        await wasmService.Db_ImportDatabaseBase64(persistedData);

        // Update device metadata after restore
        await this.updateDeviceMetadata();
        return true;
      }
      console.log("OfflineSyncService: No persisted database found, initializing empty database");
      await wasmService.Db_Initialize();
      return false;
    } catch (error) {
      console.error("OfflineSyncService: Failed to initialize from storage", error);
      return false;
    }
  }

  /**
   * Persist current database state to storage.
   * Call this before app closes or goes to background.
   */
  async persistToStorage(): Promise<boolean> {
    try {
      const wasmService = KuikaCoreWasmBridgeService.getInstance();
      const persistenceService = OfflineDbPersistenceService.getInstance();

      // Check if database is initialized
      const isInitialized = await wasmService.Db_IsInitialized();
      if (!isInitialized) {
        console.log("OfflineSyncService: Database not initialized, nothing to persist");
        return true;
      }

      // Durable OPFS/native store persists the DB itself — skip the whole-DB base64 export.
      if (!wasmService.hasDurablePersistence()) {
        const base64Data = await wasmService.Db_ExportDatabaseBase64();
        await persistenceService.saveDatabase(base64Data);
        console.log("OfflineSyncService: Persisted database to storage (base64 mirror)");
      }
      return true;
    } catch (error) {
      console.error("OfflineSyncService: Failed to persist to storage", error);
      return false;
    }
  }

  /**
   * Check if there are pending changes that haven't been synced.
   */
  async hasPendingChanges(): Promise<boolean> {
    try {
      const wasmService = KuikaCoreWasmBridgeService.getInstance();

      const isInitialized = await wasmService.Db_IsInitialized();
      if (!isInitialized) {
        return false;
      }

      const pendingChangesJson = await wasmService.Db_GetPendingChanges();
      const pendingChanges = JSON.parse(pendingChangesJson);

      return Object.keys(pendingChanges).length > 0;
    } catch (error) {
      console.error("OfflineSyncService: Failed to check pending changes", error);
      return false;
    }
  }

  /**
   * Delete the offline database (local and persisted).
   */
  async deleteOfflineDatabase(): Promise<void> {
    try {
      const wasmService = KuikaCoreWasmBridgeService.getInstance();
      const persistenceService = OfflineDbPersistenceService.getInstance();

      // Purge the durable store. On the browser OPFS path this closes the engine, releases the pool's
      // sync access handles, removes the `.kuika-opfs` directory, and terminates the worker; on
      // Electron it closes the native DB. Without this the OPFS pool files (kpool_*) survive forever
      // and cannot be cleared from DevTools.
      await wasmService.purgeDurableStore();

      // Also clear the IndexedDB base64 mirror (only ever written on the browser `:memory:` fallback).
      await persistenceService.deleteDatabase();

      console.log("OfflineSyncService: Deleted offline database");
    } catch (error) {
      console.error("OfflineSyncService: Failed to delete offline database", error);
      throw error;
    }
  }

  // #region Private Methods

  private getBackendUrl(): string {
    // Use the configured backend URL (same pattern as other services)
    let url = KuikaAppManager.GetBackendUrl();
    // Transform URL for Electron environment
    url = transformUrlForElectron(url);
    // Remove trailing slash
    return url.replace(/\/$/, "");
  }

  /**
   * Update device metadata in KuikaDbInfo after importing a new database.
   * This ensures the device is properly identified for sync operations.
   */
  private async updateDeviceMetadata(): Promise<void> {
    try {
      const wasmService = KuikaCoreWasmBridgeService.getInstance();

      // Get or generate device ID
      const deviceId = this.getOrCreateDeviceId();

      // Get device name from user agent
      const deviceName = navigator.userAgent;

      // Get bundle ID from hostname/origin
      const bundleId = window.location.hostname || window.location.origin;

      // Update metadata in database
      await wasmService.Db_UpdateDeviceMetadata(deviceId, deviceName, bundleId, null);

      console.log("OfflineSyncService: Updated device metadata");
    } catch (error) {
      console.warn("OfflineSyncService: Failed to update device metadata", error);
    }
  }

  /**
   * Get or create a persistent device ID.
   * Stored in localStorage to persist across sessions.
   */
  private getOrCreateDeviceId(): string {
    const storageKey = "kuika_offline_device_id";

    // Try to get existing device ID
    let deviceId = localStorage.getItem(storageKey);

    if (!deviceId) {
      // Generate a new UUID-like device ID
      deviceId = this.generateUuid();
      localStorage.setItem(storageKey, deviceId);
      console.log("OfflineSyncService: Generated new device ID:", deviceId);
    }

    return deviceId;
  }

  /**
   * Generate a UUID v4 string.
   */
  private generateUuid(): string {
    // Use crypto.randomUUID if available (modern browsers)
    if (typeof crypto !== "undefined" && crypto.randomUUID) {
      return crypto.randomUUID();
    }

    // Fallback for older browsers
    return "xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx".replace(/[xy]/g, (c) => {
      const r = (Math.random() * 16) | 0;
      const v = c === "x" ? r : (r & 0x3) | 0x8;
      return v.toString(16);
    });
  }

  // #endregion Private Methods
}

export default OfflineSyncService;
