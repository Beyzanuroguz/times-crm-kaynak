import Axios, { AxiosResponse } from "axios";
import { KuikaAppManager } from "../shared/utilty/kuika-app-manager";

interface ITwinEmbedTokenResponse {
  embedToken: string | null;
  identifyJwt: string | null;
}

export interface ITwinEmbedCredentials {
  // Tenant access secret (kE_…). Origin-locked, publishable — passed as `embed-token`.
  embedToken: string | null;
  // Optional per-user identity JWT (HS256, server-minted, short-lived). Passed as
  // `identify-jwt` when present; null → anonymous shared embed identity. The identity
  // SECRET that signs it never leaves the backend.
  identifyJwt: string | null;
}

export class TwinService {
  // Fetches the Twin embed credentials for the current authenticated user. Both values
  // are derived server-side (the embed token is stored encrypted; the identify JWT is
  // freshly signed from the encrypted identity secret) and delivered here at runtime,
  // only to logged-in users — never baked into the client bundle.
  //
  // Uses the app's default Axios (not a bare instance) so the request carries the
  // session cookies, the X-CSRF-Token header, and the X-App-Base-Path the backend
  // requires on POST — without them the CSRF middleware rejects the call with 403.
  // The default interceptors also auto-recover a stale 401/403 via refresh + retry.
  // Returns nulls on any failure (caller fails closed).
  public static async GetTwinEmbedCredentials(
    backendUrl: string = KuikaAppManager.GetBackendUrl()
  ): Promise<ITwinEmbedCredentials> {
    try {
      const res: AxiosResponse<ITwinEmbedTokenResponse> = await Axios.post<
        ITwinEmbedTokenResponse,
        AxiosResponse<ITwinEmbedTokenResponse>
      >(`${backendUrl}/auth/twin-embed-token`, {}, { withCredentials: true });

      if (res?.status === 200 && res.data?.embedToken) {
        return { embedToken: res.data.embedToken, identifyJwt: res.data.identifyJwt ?? null };
      }
      return { embedToken: null, identifyJwt: null };
    } catch {
      return { embedToken: null, identifyJwt: null };
    }
  }
}
