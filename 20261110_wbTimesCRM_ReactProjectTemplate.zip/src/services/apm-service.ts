import { ApmBase, init as initApm } from "@elastic/apm-rum";
import apmConfig from "../shared/json/apm.json";

let apm: ApmBase | null = null;

export interface IApmConfig {
  isConfigAvailable: boolean;
  serverUrl: string;
  serviceName: string;
  environment?: string;
  transactionSampleRate?: number;
  captureBody?: string;
  logLevel?: string;
}

export function initializeApm(): ApmBase | null {
  const config = apmConfig as IApmConfig;

  if (!config.isConfigAvailable || !config.serverUrl || !config.serviceName) {
    return null;
  }

  try {
    apm = initApm({
      serviceName: config.serviceName,
      serverUrl: config.serverUrl,
      environment: config.environment || "production",
      transactionSampleRate: config.transactionSampleRate ?? 1.0,
      logLevel: (config.logLevel as "trace" | "debug" | "info" | "warn" | "error") || "info",
      distributedTracingOrigins: ["*"]
    });

    return apm;
  } catch (error) {
    console.error("Failed to initialize Elastic APM:", error);
    return null;
  }
}

export function getApm(): ApmBase | null {
  return apm;
}

export default { initializeApm, getApm };
