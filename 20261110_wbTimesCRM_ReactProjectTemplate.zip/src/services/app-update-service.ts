import React from "react";
import { Store } from "react-notifications-component";
import {
  KUIKA_ENV_CONFIG_MESSAGE_TYPE,
  type KuikaEnvConfig,
  type KuikaEnvConfigMessage
} from "../shared/utilty/frontend-url";
import { KuikaAppManager } from "../shared/utilty/kuika-app-manager";
import "../styles/components/app-update-bar.scss";

let waitingServiceWorker: ServiceWorker | null = null;
let onUpdateAvailableCallback: (() => void) | null = null;

/**
 * Register a callback to be notified when a new app version is available
 */
export function onUpdateAvailable(callback: () => void) {
  onUpdateAvailableCallback = callback;
  // If update is already waiting, call immediately
  if (waitingServiceWorker) {
    callback();
  }
}

/**
 * Apply the pending update - activates the new service worker and reloads the page
 */
export function applyUpdate(): void {
  if (!waitingServiceWorker) return;

  // Ask the worker to skip waiting and reload once it is in charge. In Chrome
  // `controllerchange` fires only after the new SW calls `clients.claim()`;
  // Firefox fires it when the old SW becomes redundant via skipWaiting. If
  // neither arrives by the time skipWaiting + activate would have completed
  // on a healthy SW, force the reload — the navigation goes through the
  // registration's active worker, which by then is the new one.
  //
  // Since KOA-17234 the worker skip-waits on install and claims on activate,
  // so it is usually already in charge when the user clicks: the event fired
  // before the click and the 1.5s fallback is what reloads. That wait is kept
  // as is (KOA-18736 only added the button's busy state so the click is seen
  // to react); shortcutting it is a behaviour change left for its own ticket.
  let reloaded: boolean = false;
  const reloadOnce: () => void = () => {
    if (reloaded) return;
    reloaded = true;
    window.location.reload();
  };

  navigator.serviceWorker.addEventListener("controllerchange", reloadOnce, { once: true });
  waitingServiceWorker.postMessage("SKIP_WAITING");

  const fallbackReloadDelayMs: number = 1500;
  window.setTimeout(reloadOnce, fallbackReloadDelayMs);
}

const UPDATE_NOTIFICATION_ID: string = "kuika-app-update";

// Whether the update strip is currently on screen. A second deploy landing
// while the first strip is still up must not stack a twin: the strip already
// says "new version available" and applyUpdate() always targets the newest
// waiting worker, so the existing strip stays and simply applies the latest.
let updateBarVisible: boolean = false;

function createRefreshIcon(): React.ReactElement {
  return React.createElement(
    "svg",
    {
      viewBox: "0 0 24 24",
      fill: "none",
      stroke: "currentColor",
      strokeWidth: 2,
      strokeLinecap: "round",
      strokeLinejoin: "round",
      "aria-hidden": "true",
      focusable: "false"
    },
    React.createElement("polyline", { points: "23 4 23 10 17 10" }),
    React.createElement("polyline", { points: "1 20 1 14 7 14" }),
    React.createElement("path", { d: "M3.51 9a9 9 0 0 1 14.85-3.36L23 10M1 14l4.64 4.36A9 9 0 0 0 20.49 15" })
  );
}

// Clicking Refresh takes the strip down at once and schedules the reload,
// which lands within 1.5s (see applyUpdate). The old toast closed on the
// click as well, so this keeps the visible reaction the user had before
// (KOA-18736). Removal also clears `updateBarVisible` through onRemoval.
function onRefreshClick(): void {
  applyUpdate();
  Store.removeNotification(UPDATE_NOTIFICATION_ID);
}

const UPDATE_BAR_CLASS: string = "kuika-app-update-bar";
const UPDATE_BAR_APP_ATTRIBUTE: string = "data-kuika-app-url";

// This bundle's own strip, by the app URL it was raised for. A host page can
// run several bundles (the host plus embedded micro apps), each with its own
// copy of this module and its own notification layer, so a class lookup alone
// could mistake another bundle's strip for ours.
function isOwnUpdateBarInDocument(): boolean {
  const appUrl: string = KuikaAppManager.GetFrontEndUrl();
  const bars: Element[] = Array.from(document.querySelectorAll(`.${UPDATE_BAR_CLASS}`));
  return bars.some((bar: Element): boolean => bar.getAttribute(UPDATE_BAR_APP_ATTRIBUTE) === appUrl);
}

/**
 * Re-raise the pending "new version" notice if it is not on screen.
 *
 * The notification layer of an embedded micro app lives inside the micro app
 * component, i.e. only while the user is on a screen that shows it. A notice
 * raised while the user was on a host screen had nowhere to render and was
 * lost — and it is raised once per installed worker, so it never came back
 * (KOA-18736). The app root calls this whenever its notification layer mounts.
 */
export function reshowPendingUpdateNotice(): void {
  if (!waitingServiceWorker) return;
  if (isOwnUpdateBarInDocument()) return;

  updateBarVisible = false;
  showUpdateNotification();
}

// Browser-info-bar style strip (styles/components/app-update-bar.scss).
function createUpdateBar(isTurkish: boolean): React.ReactElement {
  const title: string = isTurkish ? "Yeni uygulama sürümü mevcut." : "A new version of the app is available.";
  const hint: string = isTurkish
    ? "Güncel sürüme geçmek için sayfayı yenileyin."
    : "Refresh the page to switch to the latest version.";

  return React.createElement(
    "div",
    { className: UPDATE_BAR_CLASS, role: "status", [UPDATE_BAR_APP_ATTRIBUTE]: KuikaAppManager.GetFrontEndUrl() },
    React.createElement(
      "span",
      { className: "kuika-app-update-bar__icon", "aria-hidden": "true" },
      createRefreshIcon()
    ),
    React.createElement(
      "div",
      { className: "kuika-app-update-bar__text" },
      React.createElement("span", { className: "kuika-app-update-bar__title" }, title),
      React.createElement("span", { className: "kuika-app-update-bar__hint" }, hint)
    ),
    React.createElement(
      "button",
      { type: "button", className: "kuika-app-update-bar__refresh", onClick: onRefreshClick },
      isTurkish ? "Yenile" : "Refresh"
    )
  );
}

function showUpdateNotification(): void {
  if (updateBarVisible) return;

  const isTurkish: boolean = localStorage.getItem("ml") === "tr_TR";

  // Full-width strip at the top of the viewport (`top-full`), like a browser
  // info bar, so it is never hidden behind a footer or a floating chat button
  // in the bottom-right corner. It has no close control: it stays until the
  // user clicks Refresh, which takes it down. The library defaults
  // `click`/`touch` to true, which closed the notice on any click (or swipe)
  // and — since it is shown once per installed worker — left the user
  // believing it never appeared.
  Store.addNotification({
    id: UPDATE_NOTIFICATION_ID,
    content: createUpdateBar(isTurkish),
    container: "top-full",
    insert: "top",
    animationIn: ["animated", "slideInDown", "faster"],
    animationOut: ["animated", "fadeOut", "faster"],
    dismiss: {
      duration: 0,
      click: false,
      touch: false
    },
    onRemoval: (): void => {
      updateBarVisible = false;
    }
  });
  updateBarVisible = true;
}

function notifyUpdateAvailable(worker: ServiceWorker) {
  if (waitingServiceWorker === worker) return;

  waitingServiceWorker = worker;
  showUpdateNotification();
  if (onUpdateAvailableCallback) {
    onUpdateAvailableCallback();
  }
}

// update() rejects with InvalidStateError once the registration is gone; a failed
// sw.js fetch rejects with TypeError and is worth retrying.
function isDeadRegistrationError(error: unknown): boolean {
  return error instanceof DOMException && error.name === "InvalidStateError";
}

function waitForPageSettled(): Promise<void> {
  return new Promise((resolve) => {
    function afterLoad() {
      setTimeout(resolve, 5000);
    }
    if (document.readyState === "complete") {
      afterLoad();
    } else {
      window.addEventListener("load", afterLoad, { once: true });
    }
  });
}

/**
 * Initialize app update monitoring via service worker
 */
export async function initAppUpdateMonitoring() {
  // Service Workers only work with http:, https:, or localhost
  // Skip for custom protocols (e.g., kuika:// in Electron)
  const protocol = window.location.protocol;
  if (protocol !== "http:" && protocol !== "https:") {
    return;
  }

  if (!("serviceWorker" in navigator)) {
    return;
  }

  // In dev server mode no sw.js is emitted — skip update monitoring entirely.
  if (process.env.DEV_SERVER === "true") {
    return;
  }

  try {
    const swUrl = `${KuikaAppManager.GetFrontEndUrl()}/sw.js`;

    // Idempotent: if the SW is already registered with the same scriptURL, the
    // browser returns the existing registration and triggers an update check.
    //
    // We deliberately do NOT unregister-and-reregister when controller is null.
    // controller-null with no installing/waiting worker is the spec-mandated
    // state on every hard reload (Shift+Reload) and on every load with
    // DevTools "Bypass for network"/"Update on reload" enabled. Calling
    // unregister() in that case (a) doesn't actually free the SW in Chromium
    // until every controlled client closes (workbox#1687, "SW resurrection"),
    // (b) leaves Firefox in a degraded state per workbox#1783, and
    // (c) on Safari produces empty caches because the new install begins
    // before the old cache is reclaimed. The page just won't be SW-controlled
    // for that load — which is what the user asked for by hard-reloading.
    const registration = await navigator.serviceWorker.register(swUrl);

    void forwardEnvConfigToServiceWorker(registration);

    // The page enters its "background phase" once it has fully settled (loaded
    // + a short grace period). Whether an installed worker is allowed to toast
    // hinges entirely on which phase its install STARTED in:
    //
    //  - A worker already pending at open, or whose install starts before the
    //    page settles, was already the current version at the moment the user
    //    opened the app. The classic case is a freshly (re)published preview:
    //    the previous build's service worker still controls this scope — a
    //    registration survives even with every tab closed — so opening a new
    //    build is detected as an "update" the instant the page loads. There is
    //    no live older session to protect, so we adopt the new worker silently
    //    (no toast).
    //
    //  - Only a worker whose install starts AFTER the page has settled is a
    //    genuine deploy landing during a live session. The user has been on the
    //    old bundle for a while and must not have it yanked out from under them,
    //    so that one — and only that one — surfaces the "new version" toast.
    //
    // The phase is captured at install START (init / updatefound), never at
    // install END. The install can take many seconds — the SW warms the .NET
    // wasm snapshot during install — so keying off the end time would
    // misclassify a slow open-time install as a background update and wrongly
    // toast on first preview open.
    let settled: boolean = false;

    const handleInstalledWorker = (worker: ServiceWorker, startedInBackgroundPhase: boolean): void => {
      const hasController: boolean = navigator.serviceWorker.controller !== null;
      // First install (no controller) and open-time updates (preview-stale
      // leftovers) are both adopted silently; only a genuine in-session deploy
      // toasts. SKIP_WAITING is harmless when the SW already self-skip-waits.
      if (!hasController || !startedInBackgroundPhase) {
        worker.postMessage("SKIP_WAITING");
        return;
      }

      notifyUpdateAvailable(worker);
    };

    // Workers already installed/installing at open started before this page —
    // open-time by definition, so they never toast.
    if (registration.waiting) {
      handleInstalledWorker(registration.waiting, false);
    }
    if (registration.installing) {
      const installingWorker = registration.installing;
      installingWorker.addEventListener("statechange", () => {
        if (installingWorker.state === "installed") {
          handleInstalledWorker(installingWorker, false);
        }
      });
    }

    registration.addEventListener("updatefound", () => {
      const newWorker = registration.installing;
      if (!newWorker) return;
      // Capture the phase NOW, when the install starts — not when it finishes.
      const startedInBackgroundPhase: boolean = settled;
      newWorker.addEventListener("statechange", () => {
        if (newWorker.state === "installed") {
          handleInstalledWorker(newWorker, startedInBackgroundPhase);
        }
      });
    });

    // From here on the page is settled: an update whose install starts now is a
    // genuine background deploy and is allowed to toast.
    await waitForPageSettled();
    settled = true;

    // Update checks are network-bound. Calling registration.update() while
    // offline triggers a failing fetch for sw.js; if a previous attempt also
    // managed to start an install before going offline, that install can fail
    // its precache fetch pass (workbox precacheAndRoute is all-or-nothing) and
    // wedge the previously-good precache via cleanupOutdatedCaches. Skip the
    // call when the user-visible online state says we can't usefully run it.
    //
    // update() can also reject. Only a dead registration stops polling. A failed
    // sw.js fetch (typically the deploy itself, while the server restarts) keeps
    // polling, otherwise tabs open across a deploy never see the update strip
    // (KOA-18772). Failures are logged once per streak.
    let updateIntervalId: ReturnType<typeof setInterval> | null = null;
    let updateChecksAlive: boolean = true;
    let updateFailureLogged: boolean = false;

    const stopUpdateChecks: () => void = (): void => {
      updateChecksAlive = false;
      if (updateIntervalId !== null) {
        clearInterval(updateIntervalId);
        updateIntervalId = null;
      }
    };

    const triggerUpdateCheck: () => Promise<void> = async (): Promise<void> => {
      if (!updateChecksAlive) return;
      const browserOnline: boolean = typeof navigator === "undefined" ? true : navigator.onLine;
      if (!browserOnline) return;
      try {
        await registration.update();
        updateFailureLogged = false;
      } catch (error: unknown) {
        if (isDeadRegistrationError(error)) {
          console.warn("[sw-update] registration is gone, stopping further checks", error);
          stopUpdateChecks();
          return;
        }
        if (!updateFailureLogged) {
          console.warn("[sw-update] update check failed, will retry", error);
          updateFailureLogged = true;
        }
      }
    };

    updateIntervalId = setInterval(triggerUpdateCheck, 60 * 1000);

    document.addEventListener("visibilitychange", () => {
      if (document.visibilityState === "visible") {
        void triggerUpdateCheck();
      }
    });
  } catch (error) {
    console.error("App update monitoring initialization failed", error);
  }
}

interface WindowWithEnv {
  _env_?: KuikaEnvConfig;
}

// Re-sent on every page load so a redeploy with a different env-config refreshes
// the SW too (the SW persists across loads).
async function forwardEnvConfigToServiceWorker(registration: ServiceWorkerRegistration): Promise<void> {
  const env: KuikaEnvConfig | undefined = (window as WindowWithEnv)._env_;
  if (!env) return;

  const message: KuikaEnvConfigMessage = { type: KUIKA_ENV_CONFIG_MESSAGE_TYPE, env };

  const post = (worker: ServiceWorker | null): boolean => {
    if (!worker) return false;
    try {
      worker.postMessage(message);
      return true;
    } catch {
      return false;
    }
  };

  if (post(navigator.serviceWorker.controller)) return;
  if (post(registration.active)) return;
  if (post(registration.waiting)) return;

  const installing: ServiceWorker | null = registration.installing;
  if (!installing) return;

  // Remove the listener on first usable state OR on redundant — otherwise it
  // leaks for the lifetime of a SW that never reaches activated (e.g. install
  // rejected, or replaced by a newer registration).
  const onChange: () => void = (): void => {
    const state: ServiceWorkerState = installing.state;
    if (state === "installed" || state === "activated") {
      post(installing);
      installing.removeEventListener("statechange", onChange);
    } else if (state === "redundant") {
      installing.removeEventListener("statechange", onChange);
    }
  };
  installing.addEventListener("statechange", onChange);
}
