declare let window: any;

/**
 * Service for handling Electron-specific functionality.
 * Provides a bridge between the React app and Electron's main process.
 */

/**
 * Check if the app is running in Electron
 */
export function isElectron(): boolean {
  return (
    navigator.userAgent.toLowerCase().includes("electron") || !["http:", "https:"].includes(window.location.protocol)
  );
}

/**
 * Check if running with a custom protocol (not http/https/file)
 */
export function isCustomProtocol(url?: string): boolean {
  const checkUrl = url || window.location.origin;
  return !checkUrl.startsWith("http://") && !checkUrl.startsWith("https://") && !checkUrl.startsWith("file:");
}

/**
 * Get the base URL from Electron API (the actual HTTP backend URL)
 * Returns null if not running in Electron or baseUrl is not available
 */
export function getElectronBaseUrl(): string | null {
  return window.electronAPI?.baseUrl || null;
}

/**
 * Get the appropriate protocol for localhost URLs.
 * Returns 'http:' for custom protocols (Electron) or file: protocol,
 * otherwise returns the current window protocol.
 */
export function getLocalhostProtocol(): string {
  const protocol = window.location.protocol;
  return protocol.startsWith("http") ? protocol : "http:";
}

/**
 * Transform a URL for backend API calls when running in Electron.
 * If the URL is a custom protocol, replaces it with the actual HTTP baseUrl from Electron.
 * @param baseUrl - The URL to transform
 * @returns The transformed URL suitable for backend API calls
 */
export function transformUrlForElectron(baseUrl: string): string {
  if (isCustomProtocol(baseUrl) && window.electronAPI?.baseUrl) {
    return window.electronAPI.baseUrl.replace(/\/$/, "");
  }
  return baseUrl;
}
