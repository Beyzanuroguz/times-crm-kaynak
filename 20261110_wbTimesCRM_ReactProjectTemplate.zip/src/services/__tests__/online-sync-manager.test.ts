// Mock react-notifications-component store
const mockAddNotification = jest.fn().mockReturnValue("mock-notification-id");
const mockRemoveNotification = jest.fn();

jest.mock("react-notifications-component", () => ({
  Store: {
    addNotification: (...args: any[]) => mockAddNotification(...args),
    removeNotification: (...args: any[]) => mockRemoveNotification(...args)
  }
}));

import OnlineSyncManager from "../online-sync-manager";

// Mock OfflineSyncService
const mockOfflineSyncService = {
  getIsSyncing: jest.fn(),
  hasPendingChanges: jest.fn(),
  sync: jest.fn()
};

jest.mock("../offline-sync-service", () => ({
  __esModule: true,
  default: {
    getInstance: jest.fn(() => mockOfflineSyncService)
  }
}));

// Mock cookie-utils
const mockGetCookie = jest.fn();
jest.mock("../../auth/cookie-utils", () => ({
  getCookie: (...args: any[]) => mockGetCookie(...args)
}));

// Login state is now read via KuikaAppManager.readLoginStateCookie (per-app scoped);
// delegate it to the same mockGetCookie so existing is_logged_in toggles still apply.
jest.mock("../../shared/utilty/kuika-app-manager", () => ({
  KuikaAppManager: {
    readLoginStateCookie: (name: string) => mockGetCookie(name)
  }
}));

// Mock KMainFunctions
const mockDisplaySuccessNotification = jest.fn();
const mockDisplayWarningNotification = jest.fn();

jest.mock("../../shared/utilty/main-functions", () => ({
  KMainFunctions: {
    displaySuccessNotification: (...args: any[]) => mockDisplaySuccessNotification(...args),
    displayWarningNotification: (...args: any[]) => mockDisplayWarningNotification(...args)
  }
}));

// Mock window events
const mockAddEventListener = jest.fn();
const mockRemoveEventListener = jest.fn();
const mockDispatchEvent = jest.fn();

describe("OnlineSyncManager", () => {
  let manager: OnlineSyncManager;
  let originalAddEventListener: typeof window.addEventListener;
  let originalRemoveEventListener: typeof window.removeEventListener;
  let originalDispatchEvent: typeof window.dispatchEvent;
  let onlineHandler: ((event: Event) => void) | null = null;
  let offlineHandler: ((event: Event) => void) | null = null;

  beforeEach(() => {
    jest.clearAllMocks();
    jest.useFakeTimers();

    // Reset singleton
    (OnlineSyncManager as any).instance = null;

    // Save original window methods
    originalAddEventListener = window.addEventListener;
    originalRemoveEventListener = window.removeEventListener;
    originalDispatchEvent = window.dispatchEvent;

    // Reset handlers
    onlineHandler = null;
    offlineHandler = null;

    // Mock window.addEventListener to capture handlers
    window.addEventListener = jest.fn((event: string, handler: EventListenerOrEventListenerObject) => {
      if (event === "online") {
        onlineHandler = handler as (event: Event) => void;
      } else if (event === "offline") {
        offlineHandler = handler as (event: Event) => void;
      }
      mockAddEventListener(event, handler);
    }) as any;

    window.removeEventListener = jest.fn((event: string, handler: EventListenerOrEventListenerObject) => {
      mockRemoveEventListener(event, handler);
    }) as any;

    window.dispatchEvent = jest.fn((event: Event) => {
      mockDispatchEvent(event);
      return true;
    }) as any;

    // Default mock implementations
    mockOfflineSyncService.getIsSyncing.mockReturnValue(false);
    mockOfflineSyncService.hasPendingChanges.mockResolvedValue(true);
    mockOfflineSyncService.sync.mockResolvedValue({ success: true });
    // Simulate user is logged in via cookie
    mockGetCookie.mockImplementation((name: string) => {
      if (name === "is_logged_in") return "1";
      return null;
    });

    manager = OnlineSyncManager.getInstance();
  });

  afterEach(() => {
    // Clean up listeners if manager was started
    if (manager) {
      manager.stopListening();
    }

    // Restore original window methods
    window.addEventListener = originalAddEventListener;
    window.removeEventListener = originalRemoveEventListener;
    window.dispatchEvent = originalDispatchEvent;

    jest.useRealTimers();
  });

  describe("getInstance", () => {
    it("should return the same instance when called multiple times", () => {
      const instance1 = OnlineSyncManager.getInstance();
      const instance2 = OnlineSyncManager.getInstance();

      expect(instance1).toBe(instance2);
    });
  });

  describe("startListening", () => {
    it("should add online and offline event listeners", () => {
      manager.startListening();

      expect(mockAddEventListener).toHaveBeenCalledWith("online", expect.any(Function));
      expect(mockAddEventListener).toHaveBeenCalledWith("offline", expect.any(Function));
    });

    it("should not add duplicate listeners when called twice", () => {
      manager.startListening();
      manager.startListening();

      // Should only be called once for each event type
      const onlineCalls = mockAddEventListener.mock.calls.filter(([event]) => event === "online");
      const offlineCalls = mockAddEventListener.mock.calls.filter(([event]) => event === "offline");

      expect(onlineCalls).toHaveLength(1);
      expect(offlineCalls).toHaveLength(1);
    });
  });

  describe("stopListening", () => {
    it("should remove online and offline event listeners", () => {
      manager.startListening();
      manager.stopListening();

      expect(mockRemoveEventListener).toHaveBeenCalledWith("online", expect.any(Function));
      expect(mockRemoveEventListener).toHaveBeenCalledWith("offline", expect.any(Function));
    });

    it("should clear pending debounce timeout", async () => {
      manager.startListening();

      // Simulate going offline then online
      offlineHandler?.(new Event("offline"));
      onlineHandler?.(new Event("online"));

      // Stop listening before debounce completes
      manager.stopListening();

      // Fast forward past debounce time
      jest.advanceTimersByTime(3000);

      // Sync should not have been called
      expect(mockOfflineSyncService.sync).not.toHaveBeenCalled();
    });
  });

  describe("debounce behavior", () => {
    it("should not call sync immediately when online event fires", async () => {
      manager.startListening();

      // Simulate going offline first
      offlineHandler?.(new Event("offline"));

      // Then going online
      onlineHandler?.(new Event("online"));

      // Sync should not be called immediately
      expect(mockOfflineSyncService.sync).not.toHaveBeenCalled();
    });

    it("should call sync after 2 second debounce", async () => {
      manager.startListening();

      // Simulate going offline first
      offlineHandler?.(new Event("offline"));

      // Then going online
      onlineHandler?.(new Event("online"));

      // Advance timers by 2 seconds
      jest.advanceTimersByTime(2000);

      // Allow promises to resolve
      await Promise.resolve();

      expect(mockOfflineSyncService.sync).toHaveBeenCalled();
    });

    it("should reset debounce if online event fires again within 2 seconds", async () => {
      manager.startListening();

      // Simulate going offline first
      offlineHandler?.(new Event("offline"));

      // Go online
      onlineHandler?.(new Event("online"));

      // Advance 1 second (not enough)
      jest.advanceTimersByTime(1000);

      // Go online again (should reset debounce)
      onlineHandler?.(new Event("online"));

      // Advance another 1 second (2 total from start, but only 1 since reset)
      jest.advanceTimersByTime(1000);

      // Sync should not be called yet
      expect(mockOfflineSyncService.sync).not.toHaveBeenCalled();

      // Advance the remaining 1 second
      jest.advanceTimersByTime(1000);
      await Promise.resolve();

      // Now sync should be called
      expect(mockOfflineSyncService.sync).toHaveBeenCalledTimes(1);
    });
  });

  describe("offline event handling", () => {
    it("should set wasOffline flag when offline event fires", async () => {
      manager.startListening();

      // Initially not offline - online event should not trigger sync
      onlineHandler?.(new Event("online"));
      jest.advanceTimersByTime(2000);
      await Promise.resolve();

      // Sync should not be called because wasOffline was false
      expect(mockOfflineSyncService.sync).not.toHaveBeenCalled();
    });

    it("should cancel pending sync when going offline", async () => {
      manager.startListening();

      // Go offline then online
      offlineHandler?.(new Event("offline"));
      onlineHandler?.(new Event("online"));

      // Go offline again before debounce completes
      jest.advanceTimersByTime(1000);
      offlineHandler?.(new Event("offline"));

      // Advance past original debounce time
      jest.advanceTimersByTime(2000);
      await Promise.resolve();

      // Sync should not have been called
      expect(mockOfflineSyncService.sync).not.toHaveBeenCalled();
    });
  });

  describe("sync conditions", () => {
    it("should skip sync if not previously offline", async () => {
      manager.startListening();

      // Go online without going offline first
      onlineHandler?.(new Event("online"));
      jest.advanceTimersByTime(2000);
      await Promise.resolve();

      expect(mockOfflineSyncService.sync).not.toHaveBeenCalled();
    });

    it("should skip sync if not logged in", async () => {
      mockGetCookie.mockImplementation((name: string) => {
        if (name === "is_logged_in") return null;
        return null;
      });
      manager.startListening();

      // Go offline then online
      offlineHandler?.(new Event("offline"));
      onlineHandler?.(new Event("online"));
      jest.advanceTimersByTime(2000);
      await Promise.resolve();

      expect(mockOfflineSyncService.sync).not.toHaveBeenCalled();
    });

    it("should skip sync if already syncing", async () => {
      mockOfflineSyncService.getIsSyncing.mockReturnValue(true);
      manager.startListening();

      // Go offline then online
      offlineHandler?.(new Event("offline"));
      onlineHandler?.(new Event("online"));
      jest.advanceTimersByTime(2000);
      await Promise.resolve();

      expect(mockOfflineSyncService.sync).not.toHaveBeenCalled();
    });

    it("should skip sync if no pending changes", async () => {
      mockOfflineSyncService.hasPendingChanges.mockResolvedValue(false);
      manager.startListening();

      // Go offline then online
      offlineHandler?.(new Event("offline"));
      onlineHandler?.(new Event("online"));
      jest.advanceTimersByTime(2000);
      await Promise.resolve();

      expect(mockOfflineSyncService.sync).not.toHaveBeenCalled();
    });
  });

  describe("successful sync flow", () => {
    it("should dispatch sync-start event when sync begins", async () => {
      manager.startListening();

      offlineHandler?.(new Event("offline"));
      onlineHandler?.(new Event("online"));
      jest.advanceTimersByTime(2000);
      await Promise.resolve();

      expect(mockDispatchEvent).toHaveBeenCalledWith(
        expect.objectContaining({
          type: "{WEBCOMPONENTTAG}-sync-start"
        })
      );
    });

    it("should dispatch sync-success event when sync succeeds", async () => {
      manager.startListening();

      offlineHandler?.(new Event("offline"));
      onlineHandler?.(new Event("online"));
      jest.advanceTimersByTime(2000);
      await Promise.resolve();
      // Allow async operations to complete
      await Promise.resolve();

      expect(mockDispatchEvent).toHaveBeenCalledWith(
        expect.objectContaining({
          type: "{WEBCOMPONENTTAG}-sync-success"
        })
      );
    });

    it("should dispatch navigate-home event when sync succeeds", async () => {
      manager.startListening();

      offlineHandler?.(new Event("offline"));
      onlineHandler?.(new Event("online"));
      jest.advanceTimersByTime(2000);
      await Promise.resolve();
      await Promise.resolve();

      expect(mockDispatchEvent).toHaveBeenCalledWith(
        expect.objectContaining({
          type: "{WEBCOMPONENTTAG}-navigate-home"
        })
      );
    });

    it("should show success notification in English when sync succeeds", async () => {
      localStorage.setItem("ml", "en_US");
      manager.startListening();

      offlineHandler?.(new Event("offline"));
      onlineHandler?.(new Event("online"));
      jest.advanceTimersByTime(2000);
      await Promise.resolve();
      await Promise.resolve();

      expect(mockDisplaySuccessNotification).toHaveBeenCalledWith(
        expect.stringContaining("synced"),
        expect.any(Object)
      );
    });

    it("should show success notification in Turkish when language is tr_TR", async () => {
      localStorage.setItem("ml", "tr_TR");
      manager.startListening();

      offlineHandler?.(new Event("offline"));
      onlineHandler?.(new Event("online"));
      jest.advanceTimersByTime(2000);
      await Promise.resolve();
      await Promise.resolve();

      expect(mockDisplaySuccessNotification).toHaveBeenCalledWith(
        expect.stringContaining("senkron"),
        expect.any(Object)
      );
    });

    it("should reset wasOffline flag after successful sync", async () => {
      manager.startListening();

      // First cycle: offline -> online -> sync
      offlineHandler?.(new Event("offline"));
      onlineHandler?.(new Event("online"));
      jest.advanceTimersByTime(2000);
      await Promise.resolve();
      await Promise.resolve();

      expect(mockOfflineSyncService.sync).toHaveBeenCalledTimes(1);

      // Second cycle: online without offline should not trigger sync
      jest.clearAllMocks();
      onlineHandler?.(new Event("online"));
      jest.advanceTimersByTime(2000);
      await Promise.resolve();

      expect(mockOfflineSyncService.sync).not.toHaveBeenCalled();
    });
  });

  describe("failed sync flow", () => {
    it("should dispatch sync-error event when sync fails", async () => {
      mockOfflineSyncService.sync.mockResolvedValue({ success: false, error: "Network error" });
      manager.startListening();

      offlineHandler?.(new Event("offline"));
      onlineHandler?.(new Event("online"));
      jest.advanceTimersByTime(2000);
      await Promise.resolve();
      await Promise.resolve();

      expect(mockDispatchEvent).toHaveBeenCalledWith(
        expect.objectContaining({
          type: "{WEBCOMPONENTTAG}-sync-error"
        })
      );
    });

    it("should show warning notification when sync fails", async () => {
      mockOfflineSyncService.sync.mockResolvedValue({ success: false, error: "Network error" });
      manager.startListening();

      offlineHandler?.(new Event("offline"));
      onlineHandler?.(new Event("online"));
      jest.advanceTimersByTime(2000);
      await Promise.resolve();
      await Promise.resolve();

      expect(mockDisplayWarningNotification).toHaveBeenCalled();
    });

    it("should not dispatch navigate-home event when sync fails", async () => {
      mockOfflineSyncService.sync.mockResolvedValue({ success: false, error: "Network error" });
      manager.startListening();

      offlineHandler?.(new Event("offline"));
      onlineHandler?.(new Event("online"));
      jest.advanceTimersByTime(2000);
      await Promise.resolve();
      await Promise.resolve();

      const navigateHomeEvents = mockDispatchEvent.mock.calls.filter(
        ([event]) => event.type === "{WEBCOMPONENTTAG}-navigate-home"
      );
      expect(navigateHomeEvents).toHaveLength(0);
    });

    it("should not reset wasOffline flag when sync fails", async () => {
      mockOfflineSyncService.sync.mockResolvedValue({ success: false, error: "Network error" });
      manager.startListening();

      // First cycle: offline -> online -> failed sync
      offlineHandler?.(new Event("offline"));
      onlineHandler?.(new Event("online"));
      jest.advanceTimersByTime(2000);
      await Promise.resolve();
      await Promise.resolve();

      // Second cycle: online should still trigger sync because wasOffline wasn't reset
      jest.clearAllMocks();
      mockOfflineSyncService.sync.mockResolvedValue({ success: true });
      onlineHandler?.(new Event("online"));
      jest.advanceTimersByTime(2000);
      await Promise.resolve();

      expect(mockOfflineSyncService.sync).toHaveBeenCalled();
    });
  });

  describe("sync exception handling", () => {
    it("should handle sync throwing an exception", async () => {
      mockOfflineSyncService.sync.mockRejectedValue(new Error("Unexpected error"));
      manager.startListening();

      offlineHandler?.(new Event("offline"));
      onlineHandler?.(new Event("online"));
      jest.advanceTimersByTime(2000);
      await Promise.resolve();
      await Promise.resolve();

      // Should dispatch error event
      expect(mockDispatchEvent).toHaveBeenCalledWith(
        expect.objectContaining({
          type: "{WEBCOMPONENTTAG}-sync-error"
        })
      );
    });
  });
});
