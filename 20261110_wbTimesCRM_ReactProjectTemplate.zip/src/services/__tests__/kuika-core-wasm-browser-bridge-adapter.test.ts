import { BrowserBridgeAdapter } from "../kuika-core-wasm-browser-bridge-adapter";

// The adapter hosts the .NET runtime in a Web Worker and forwards every call by postMessage.
// These tests mock the Worker so we can assert the message protocol + response handling without a
// real runtime. (jsdom has no Worker; we install a controllable fake.)

jest.mock("../../shared/utilty/kuika-app-manager", () => ({
  KuikaAppManager: { GetFrontEndUrl: jest.fn(() => "http://localhost:3000") }
}));

interface PostedMessage {
  type: string;
  id: number;
  method?: string;
  args?: readonly unknown[];
  offset?: number;
  chunk?: Uint8Array;
}

interface WorkerResponseData {
  id: number;
  ok: boolean;
  result?: unknown;
  error?: string;
  opfsActive?: boolean;
}

// Canned results returned for each forwarded [JSExport] "call" method.
const methodResults: Map<string, unknown> = new Map();
// Whether the mocked worker reports OPFS as active on init.
let mockOpfsActive = true;

class MockWorker {
  onmessage: ((event: { data: WorkerResponseData }) => void) | null = null;

  onerror: ((event: unknown) => void) | null = null;

  static posted: PostedMessage[] = [];

  postMessage(message: PostedMessage): void {
    MockWorker.posted.push(message);
    // Respond on a microtask so the adapter has registered its pending resolver first.
    Promise.resolve().then(() => {
      if (!this.onmessage) {
        return;
      }
      if (message.type === "init") {
        this.onmessage({ data: { id: message.id, ok: true, opfsActive: mockOpfsActive } });
      } else if (message.type === "call") {
        this.onmessage({ data: { id: message.id, ok: true, result: methodResults.get(message.method ?? "") } });
      } else {
        // importBegin / importChunk / importEnd control messages.
        this.onmessage({ data: { id: message.id, ok: true } });
      }
    });
  }

  terminate(): void {}
}

describe("BrowserBridgeAdapter (worker-backed)", () => {
  let adapter: BrowserBridgeAdapter;

  beforeAll(() => {
    (globalThis as unknown as { Worker: typeof MockWorker }).Worker = MockWorker;
  });

  beforeEach(() => {
    jest.clearAllMocks();
    methodResults.clear();
    mockOpfsActive = true;
    MockWorker.posted = [];
    adapter = new BrowserBridgeAdapter();
  });

  const lastCall = (): PostedMessage | undefined => [...MockWorker.posted].reverse().find((m) => m.type === "call");

  describe("getAdapterType", () => {
    it('returns "browser"', () => {
      expect(adapter.getAdapterType()).toBe("browser");
    });
  });

  describe("initialize", () => {
    it("is not initialized before initialize()", () => {
      expect(adapter.getIsInitialized()).toBe(false);
    });

    it("creates the worker and posts an init message", async () => {
      await adapter.initialize();
      expect(adapter.getIsInitialized()).toBe(true);
      expect(MockWorker.posted.some((m) => m.type === "init")).toBe(true);
    });

    it("does not reinitialize when already initialized", async () => {
      await adapter.initialize();
      const initCount = MockWorker.posted.filter((m) => m.type === "init").length;
      await adapter.initialize();
      expect(MockWorker.posted.filter((m) => m.type === "init").length).toBe(initCount);
    });

    it("reports durable persistence + streaming support from the init opfsActive flag", async () => {
      mockOpfsActive = true;
      await adapter.initialize();
      expect(adapter.hasDurablePersistence()).toBe(true);
      expect(adapter.supportsStreamingImport()).toBe(true);
    });

    it("falls back to non-durable when OPFS did not mount", async () => {
      mockOpfsActive = false;
      await adapter.initialize();
      expect(adapter.hasDurablePersistence()).toBe(false);
      expect(adapter.supportsStreamingImport()).toBe(false);
    });
  });

  describe("core methods forward by name and return the worker result", () => {
    it("Add posts {method:'Add', args:[a,b]} and resolves the result", async () => {
      methodResults.set("Add", 8);
      const result = await adapter.Add(3, 5);
      expect(result).toBe(8);
      expect(lastCall()).toMatchObject({ type: "call", method: "Add", args: [3, 5] });
    });

    it("Ping resolves the worker result", async () => {
      methodResults.set("Ping", "Pong from KuikaCore!");
      const result = await adapter.Ping();
      expect(result).toBe("Pong from KuikaCore!");
      expect(lastCall()?.method).toBe("Ping");
    });
  });

  describe("database lifecycle + sync methods forward correctly", () => {
    it("Db_IsInitialized returns the worker result", async () => {
      methodResults.set("Db_IsInitialized", true);
      expect(await adapter.Db_IsInitialized()).toBe(true);
      expect(lastCall()?.method).toBe("Db_IsInitialized");
    });

    it("Db_ExportDatabaseBase64 returns the worker result", async () => {
      methodResults.set("Db_ExportDatabaseBase64", "SGVsbG8=");
      expect(await adapter.Db_ExportDatabaseBase64()).toBe("SGVsbG8=");
    });

    it("Db_ImportDatabaseBase64 forwards its argument", async () => {
      await adapter.Db_ImportDatabaseBase64("SGVsbG8=");
      expect(lastCall()).toMatchObject({ method: "Db_ImportDatabaseBase64", args: ["SGVsbG8="] });
    });

    it("Db_MarkPayloadAsSynced forwards its argument", async () => {
      await adapter.Db_MarkPayloadAsSynced("UEFZTE9BRA==");
      expect(lastCall()).toMatchObject({ method: "Db_MarkPayloadAsSynced", args: ["UEFZTE9BRA=="] });
    });

    it("Db_UpdateDeviceMetadata forwards all arguments", async () => {
      await adapter.Db_UpdateDeviceMetadata("device-1", "My Device", "com.example.app", "TestProject");
      expect(lastCall()?.args).toEqual(["device-1", "My Device", "com.example.app", "TestProject"]);
    });
  });

  describe("error propagation", () => {
    it("rejects when the worker reports an error", async () => {
      const original = MockWorker.prototype.postMessage;
      // Respond ok for init but with an error for the actual call.
      MockWorker.prototype.postMessage = function postMessage(message: PostedMessage): void {
        Promise.resolve().then(() => {
          if (!this.onmessage) {
            return;
          }
          if (message.type === "init") {
            this.onmessage({ data: { id: message.id, ok: true, opfsActive: true } });
          } else {
            this.onmessage({ data: { id: message.id, ok: false, error: "boom" } });
          }
        });
      };
      try {
        const failing = new BrowserBridgeAdapter();
        await expect(failing.Ping()).rejects.toThrow("boom");
      } finally {
        MockWorker.prototype.postMessage = original;
      }
    });
  });

  describe("streaming import", () => {
    it("posts importBegin / importChunk / importEnd control messages", async () => {
      await adapter.importStreamBegin();
      await adapter.importStreamChunk(0, Uint8Array.from([1, 2, 3]));
      await adapter.importStreamEnd();
      const types = MockWorker.posted.map((m) => m.type);
      expect(types).toContain("importBegin");
      expect(types).toContain("importChunk");
      expect(types).toContain("importEnd");
    });
  });

  describe("purgeDurableStore", () => {
    it("posts a wipe message and keeps the adapter usable (no terminate)", async () => {
      await adapter.initialize();
      await adapter.purgeDurableStore();
      expect(MockWorker.posted.some((m) => m.type === "wipe")).toBe(true);
      // A follow-up call still works: the worker re-mounted a fresh pool rather than dying.
      methodResults.set("Ping", "alive");
      expect(await adapter.Ping()).toBe("alive");
    });
  });
});
