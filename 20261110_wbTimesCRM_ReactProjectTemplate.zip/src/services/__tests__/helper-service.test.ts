// Tests for HelperService.buildLoginRedirectQuery — the single source of truth
// for the "?redirectUri=..." query that both the axios 401 interceptor and the
// PrivateRoute route-guard attach when sending an unauthenticated user to the
// login screen. ReactSystemFunctions.goToNextScreenAfterLogin reads this query
// after sign-in to restore the originally-requested URL, so the query must be
// byte-identical regardless of which producer built it.
//
// kuika-app-manager and react-system-functions are mocked to avoid pulling the
// whole runtime into a focused unit test; only GetFrontEndUrl is exercised.

const getFrontEndUrlMock: jest.Mock = jest.fn();

jest.mock("../../shared/utilty/kuika-app-manager", () => ({
  __esModule: true,
  KuikaAppManager: {
    GetFrontEndUrl: (): string => getFrontEndUrlMock()
  }
}));

jest.mock("../../shared/utilty/react-system-functions", () => ({
  __esModule: true,
  ReactSystemFunctions: {}
}));

import HelperService from "../helper-service";

describe("HelperService.buildLoginRedirectQuery", () => {
  beforeEach(() => {
    getFrontEndUrlMock.mockReturnValue("https://app.kuika.com");
  });

  it("returns an empty string when no redirectUri is provided", () => {
    expect(HelperService.buildLoginRedirectQuery()).toBe("");
    expect(HelperService.buildLoginRedirectQuery("")).toBe("");
    expect(HelperService.buildLoginRedirectQuery("   ")).toBe("");
  });

  it("returns an empty string when the target is the app root", () => {
    expect(HelperService.buildLoginRedirectQuery("/")).toBe("");
  });

  it("encodes a simple protected path", () => {
    expect(HelperService.buildLoginRedirectQuery("/dashboard")).toBe("?redirectUri=%2Fdashboard");
  });

  it("preserves and encodes search params and hash", () => {
    const result: string = HelperService.buildLoginRedirectQuery("/orders?id=42&tab=items#summary");
    expect(result).toBe("?redirectUri=%2Forders%3Fid%3D42%26tab%3Ditems%23summary");
    // Round-trips back to the original path the read side will navigate to.
    const decoded: string = decodeURIComponent(result.replace("?redirectUri=", ""));
    expect(decoded).toBe("/orders?id=42&tab=items#summary");
  });

  it("strips the front-end base path so the stored URL is router-relative", () => {
    getFrontEndUrlMock.mockReturnValue("https://app.kuika.com/myapp");
    expect(HelperService.buildLoginRedirectQuery("/myapp/reports")).toBe("?redirectUri=%2Freports");
  });

  it("keeps a microapp hash route intact while stripping the base path", () => {
    // The MicroApp host screen routes on the pathname, the embedded microapp on the
    // hash. Losing either half sends the user to the microapp's starting screen
    // after login instead of the screen they deep-linked to (KOA-17683).
    getFrontEndUrlMock.mockReturnValue("https://app.kuika.com/kuiktest22");
    const result: string = HelperService.buildLoginRedirectQuery(
      "/kuiktest22/MicroAppScreen#/visibilitycondition?ProjectID=50e3c304"
    );
    const decoded: string = decodeURIComponent(result.replace("?redirectUri=", ""));
    expect(decoded).toBe("/MicroAppScreen#/visibilitycondition?ProjectID=50e3c304");
  });

  it("returns empty when the target equals the front-end base path (root within base)", () => {
    getFrontEndUrlMock.mockReturnValue("https://app.kuika.com/myapp");
    expect(HelperService.buildLoginRedirectQuery("/myapp/")).toBe("");
  });
});
