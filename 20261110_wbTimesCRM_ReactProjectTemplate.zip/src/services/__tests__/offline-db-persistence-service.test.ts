import OfflineDbPersistenceService from "../offline-db-persistence-service";

// Mock isElectron
let mockIsElectron = false;
jest.mock("../electron-bridge-service", () => ({
  isElectron: jest.fn(() => mockIsElectron)
}));

// Mock IndexedDB
const mockIndexedDB = {
  open: jest.fn(),
  deleteDatabase: jest.fn()
};

// Mock IDBDatabase
const mockStore = {
  put: jest.fn(),
  get: jest.fn(),
  delete: jest.fn()
};

const mockTransaction = {
  objectStore: jest.fn(() => mockStore)
};

const mockDb = {
  transaction: jest.fn(() => mockTransaction),
  objectStoreNames: {
    contains: jest.fn(() => false)
  },
  createObjectStore: jest.fn()
};

// Mock Electron file API
const mockElectronFile = {
  read: jest.fn(),
  write: jest.fn()
};

describe("OfflineDbPersistenceService", () => {
  let service: OfflineDbPersistenceService;

  beforeEach(() => {
    jest.clearAllMocks();
    mockIsElectron = false;

    // Reset singleton
    (OfflineDbPersistenceService as any).instance = null;

    // Setup IndexedDB mock
    (global as any).indexedDB = mockIndexedDB;

    // Setup window.electronAPI mock
    (window as any).electronAPI = {
      file: mockElectronFile
    };
  });

  afterEach(() => {
    delete (global as any).indexedDB;
    delete (window as any).electronAPI;
  });

  describe("getInstance", () => {
    it("should return the same instance when called multiple times", () => {
      const instance1 = OfflineDbPersistenceService.getInstance();
      const instance2 = OfflineDbPersistenceService.getInstance();

      expect(instance1).toBe(instance2);
    });
  });

  describe("when running in browser", () => {
    beforeEach(() => {
      mockIsElectron = false;
      service = OfflineDbPersistenceService.getInstance();
    });

    describe("initialize", () => {
      it("should initialize IndexedDB", async () => {
        // Setup IndexedDB open success
        mockIndexedDB.open.mockImplementation(() => {
          const request = {
            onerror: null as (() => void) | null,
            onsuccess: null as (() => void) | null,
            onupgradeneeded: null as ((event: { target: { result: typeof mockDb } }) => void) | null,
            result: mockDb,
            error: null
          };

          // Simulate async success
          setTimeout(() => {
            if (request.onsuccess) request.onsuccess();
          }, 0);

          return request;
        });

        await service.initialize();

        expect(mockIndexedDB.open).toHaveBeenCalledWith("kuika-offline-db", 1);
      });

      it("should not reinitialize if already initialized", async () => {
        // First initialization
        mockIndexedDB.open.mockImplementation(() => {
          const request = {
            onerror: null as (() => void) | null,
            onsuccess: null as (() => void) | null,
            onupgradeneeded: null as ((event: { target: { result: typeof mockDb } }) => void) | null,
            result: mockDb,
            error: null
          };
          setTimeout(() => {
            if (request.onsuccess) request.onsuccess();
          }, 0);
          return request;
        });

        await service.initialize();
        await service.initialize();

        expect(mockIndexedDB.open).toHaveBeenCalledTimes(1);
      });
    });

    describe("saveDatabase", () => {
      it("should save data to IndexedDB", async () => {
        // Setup
        const testData = "SGVsbG8gV29ybGQ=";
        mockIndexedDB.open.mockImplementation(() => {
          const request = {
            onerror: null as (() => void) | null,
            onsuccess: null as (() => void) | null,
            onupgradeneeded: null as ((event: { target: { result: typeof mockDb } }) => void) | null,
            result: mockDb,
            error: null
          };
          setTimeout(() => {
            if (request.onsuccess) request.onsuccess();
          }, 0);
          return request;
        });

        mockStore.put.mockImplementation(() => {
          const request = {
            onerror: null as (() => void) | null,
            onsuccess: null as (() => void) | null,
            error: null
          };
          setTimeout(() => {
            if (request.onsuccess) request.onsuccess();
          }, 0);
          return request;
        });

        await service.initialize();
        await service.saveDatabase(testData);

        expect(mockDb.transaction).toHaveBeenCalledWith(["database"], "readwrite");
        expect(mockStore.put).toHaveBeenCalledWith(testData, "sqlite-data");
      });
    });

    describe("loadDatabase", () => {
      it("should load data from IndexedDB", async () => {
        const testData = "SGVsbG8gV29ybGQ=";

        mockIndexedDB.open.mockImplementation(() => {
          const request = {
            onerror: null as (() => void) | null,
            onsuccess: null as (() => void) | null,
            onupgradeneeded: null as ((event: { target: { result: typeof mockDb } }) => void) | null,
            result: mockDb,
            error: null
          };
          setTimeout(() => {
            if (request.onsuccess) request.onsuccess();
          }, 0);
          return request;
        });

        mockStore.get.mockImplementation(() => {
          const request = {
            onerror: null as (() => void) | null,
            onsuccess: null as (() => void) | null,
            result: testData,
            error: null
          };
          setTimeout(() => {
            if (request.onsuccess) request.onsuccess();
          }, 0);
          return request;
        });

        await service.initialize();
        const result = await service.loadDatabase();

        expect(result).toBe(testData);
        expect(mockDb.transaction).toHaveBeenCalledWith(["database"], "readonly");
      });

      it("should return null if no data found", async () => {
        mockIndexedDB.open.mockImplementation(() => {
          const request = {
            onerror: null as (() => void) | null,
            onsuccess: null as (() => void) | null,
            onupgradeneeded: null as ((event: { target: { result: typeof mockDb } }) => void) | null,
            result: mockDb,
            error: null
          };
          setTimeout(() => {
            if (request.onsuccess) request.onsuccess();
          }, 0);
          return request;
        });

        mockStore.get.mockImplementation(() => {
          const request = {
            onerror: null as (() => void) | null,
            onsuccess: null as (() => void) | null,
            result: undefined,
            error: null
          };
          setTimeout(() => {
            if (request.onsuccess) request.onsuccess();
          }, 0);
          return request;
        });

        await service.initialize();
        const result = await service.loadDatabase();

        expect(result).toBeNull();
      });
    });

    describe("deleteDatabase", () => {
      it("should delete data from IndexedDB", async () => {
        mockIndexedDB.open.mockImplementation(() => {
          const request = {
            onerror: null as (() => void) | null,
            onsuccess: null as (() => void) | null,
            onupgradeneeded: null as ((event: { target: { result: typeof mockDb } }) => void) | null,
            result: mockDb,
            error: null
          };
          setTimeout(() => {
            if (request.onsuccess) request.onsuccess();
          }, 0);
          return request;
        });

        mockStore.delete.mockImplementation(() => {
          const request = {
            onerror: null as (() => void) | null,
            onsuccess: null as (() => void) | null,
            error: null
          };
          setTimeout(() => {
            if (request.onsuccess) request.onsuccess();
          }, 0);
          return request;
        });

        await service.initialize();
        await service.deleteDatabase();

        expect(mockStore.delete).toHaveBeenCalledWith("sqlite-data");
      });
    });

    describe("hasPersistedDatabase", () => {
      it("should return true when data exists", async () => {
        mockIndexedDB.open.mockImplementation(() => {
          const request = {
            onerror: null as (() => void) | null,
            onsuccess: null as (() => void) | null,
            onupgradeneeded: null as ((event: { target: { result: typeof mockDb } }) => void) | null,
            result: mockDb,
            error: null
          };
          setTimeout(() => {
            if (request.onsuccess) request.onsuccess();
          }, 0);
          return request;
        });

        mockStore.get.mockImplementation(() => {
          const request = {
            onerror: null as (() => void) | null,
            onsuccess: null as (() => void) | null,
            result: "some-data",
            error: null
          };
          setTimeout(() => {
            if (request.onsuccess) request.onsuccess();
          }, 0);
          return request;
        });

        await service.initialize();
        const result = await service.hasPersistedDatabase();

        expect(result).toBe(true);
      });

      it("should return false when no data exists", async () => {
        mockIndexedDB.open.mockImplementation(() => {
          const request = {
            onerror: null as (() => void) | null,
            onsuccess: null as (() => void) | null,
            onupgradeneeded: null as ((event: { target: { result: typeof mockDb } }) => void) | null,
            result: mockDb,
            error: null
          };
          setTimeout(() => {
            if (request.onsuccess) request.onsuccess();
          }, 0);
          return request;
        });

        mockStore.get.mockImplementation(() => {
          const request = {
            onerror: null as (() => void) | null,
            onsuccess: null as (() => void) | null,
            result: undefined,
            error: null
          };
          setTimeout(() => {
            if (request.onsuccess) request.onsuccess();
          }, 0);
          return request;
        });

        await service.initialize();
        const result = await service.hasPersistedDatabase();

        expect(result).toBe(false);
      });
    });
  });

  describe("when running in Electron", () => {
    beforeEach(() => {
      mockIsElectron = true;
      // Reset singleton to pick up new isElectron value
      (OfflineDbPersistenceService as any).instance = null;
      service = OfflineDbPersistenceService.getInstance();
    });

    describe("initialize", () => {
      it("should not initialize IndexedDB in Electron", async () => {
        await service.initialize();

        expect(mockIndexedDB.open).not.toHaveBeenCalled();
      });
    });

    describe("saveDatabase", () => {
      it("should be a no-op in Electron (native handles persistence)", async () => {
        const testData = "SGVsbG8gV29ybGQ=";

        await service.initialize();
        await service.saveDatabase(testData);

        // No file or IndexedDB operations should occur
        expect(mockElectronFile.write).not.toHaveBeenCalled();
        expect(mockDb.transaction).not.toHaveBeenCalled();
      });
    });

    describe("loadDatabase", () => {
      it("should return null in Electron (native handles persistence)", async () => {
        await service.initialize();
        const result = await service.loadDatabase();

        expect(result).toBeNull();
        expect(mockElectronFile.read).not.toHaveBeenCalled();
      });
    });

    describe("deleteDatabase", () => {
      it("should be a no-op in Electron (native manages its own file)", async () => {
        await service.initialize();
        await service.deleteDatabase();

        expect(mockElectronFile.write).not.toHaveBeenCalled();
        expect(mockDb.transaction).not.toHaveBeenCalled();
      });
    });

    describe("hasPersistedDatabase", () => {
      it("should return false in Electron (native manages persistence)", async () => {
        await service.initialize();
        const result = await service.hasPersistedDatabase();

        expect(result).toBe(false);
      });
    });
  });
});
