// Mock the adapters before importing the service
// Note: Table-specific methods (like Orders_Insert, Customers_SelectAll) are generated
// dynamically by WasmBridgeAdapterGenerator based on project's offline tables.
// These tests only verify the static/core methods. Generated methods would be tested
// in integration tests for specific projects.
const mockBrowserAdapter = {
  initialize: jest.fn(),
  getIsInitialized: jest.fn(),
  Add: jest.fn(),
  Ping: jest.fn(),
  Db_Initialize: jest.fn(),
  Db_IsInitialized: jest.fn(),
  Db_Close: jest.fn(),
  Db_ExportDatabaseBase64: jest.fn(),
  Db_ImportDatabaseBase64: jest.fn(),
  Db_GetPendingChanges: jest.fn(),
  Db_MarkAsSynced: jest.fn(),
  Db_GetOfflineTableSettings: jest.fn(),
  Db_GetUnsentRecordsBase64: jest.fn(),
  Db_MarkAsSyncedWithCriteria: jest.fn(),
  Db_MarkPayloadAsSynced: jest.fn(),
  Db_ImportDatabaseBase64WithReset: jest.fn(),
  Db_UpdateDeviceMetadata: jest.fn(),
  Db_GetDeviceMetadata: jest.fn(),
  getAdapterType: jest.fn().mockReturnValue("browser")
};

const mockElectronAdapter = {
  initialize: jest.fn(),
  getIsInitialized: jest.fn(),
  Add: jest.fn(),
  Ping: jest.fn(),
  Db_Initialize: jest.fn(),
  Db_IsInitialized: jest.fn(),
  Db_Close: jest.fn(),
  Db_ExportDatabaseBase64: jest.fn(),
  Db_ImportDatabaseBase64: jest.fn(),
  Db_GetPendingChanges: jest.fn(),
  Db_MarkAsSynced: jest.fn(),
  Db_GetOfflineTableSettings: jest.fn(),
  Db_GetUnsentRecordsBase64: jest.fn(),
  Db_MarkAsSyncedWithCriteria: jest.fn(),
  Db_MarkPayloadAsSynced: jest.fn(),
  Db_ImportDatabaseBase64WithReset: jest.fn(),
  Db_UpdateDeviceMetadata: jest.fn(),
  Db_GetDeviceMetadata: jest.fn(),
  getAdapterType: jest.fn().mockReturnValue("electron")
};

jest.mock("../kuika-core-wasm-browser-bridge-adapter", () => ({
  BrowserBridgeAdapter: jest.fn().mockImplementation(() => mockBrowserAdapter)
}));

jest.mock("../kuika-core-wasm-electron-ipc-bridge-adapter", () => ({
  ElectronIpcBridgeAdapter: jest.fn().mockImplementation(() => mockElectronAdapter)
}));

// Mock isElectron function
let mockIsElectron = false;
jest.mock("../electron-bridge-service", () => ({
  isElectron: jest.fn(() => mockIsElectron),
  transformUrlForElectron: jest.fn((url: string) => url),
  isCustomProtocol: jest.fn(() => false),
  getElectronBaseUrl: jest.fn(() => null)
}));

// Mock LocalStorageService
jest.mock("../../auth/local-storage-service", () => ({
  __esModule: true,
  default: {
    getAccessToken: jest.fn(() => "mock-token"),
    getRefreshToken: jest.fn(() => null),
    setToken: jest.fn(),
    clearToken: jest.fn()
  }
}));

// Mock KuikaAppManager
jest.mock("../../shared/utilty/kuika-app-manager", () => ({
  KuikaAppManager: {
    GetBackendUrl: jest.fn(() => "http://localhost:3000"),
    getBackendUrlFromFullUrl: jest.fn(() => "http://localhost:3000")
  }
}));

describe("KuikaCoreWasmBridgeService", () => {
  beforeEach(() => {
    jest.clearAllMocks();
    // Reset the singleton instance before each test
    jest.resetModules();
    mockIsElectron = false;
  });

  describe("when running in browser", () => {
    let KuikaCoreWasmBridgeService: any;

    beforeEach(() => {
      mockIsElectron = false;
      // Re-import to get fresh instance with correct environment detection
      KuikaCoreWasmBridgeService = require("../kuika-core-wasm-bridge-service").default;
    });

    it("should use BrowserBridgeAdapter", () => {
      const service = KuikaCoreWasmBridgeService.getInstance();

      expect(service.getAdapterType()).toBe("browser");
    });

    it("should delegate initialize to adapter", async () => {
      mockBrowserAdapter.initialize.mockResolvedValue(undefined);
      const service = KuikaCoreWasmBridgeService.getInstance();

      await service.initialize();

      expect(mockBrowserAdapter.initialize).toHaveBeenCalled();
    });

    it("should delegate getIsInitialized to adapter", () => {
      mockBrowserAdapter.getIsInitialized.mockReturnValue(true);
      const service = KuikaCoreWasmBridgeService.getInstance();

      const result = service.getIsInitialized();

      expect(mockBrowserAdapter.getIsInitialized).toHaveBeenCalled();
      expect(result).toBe(true);
    });

    it("should delegate Add to adapter", async () => {
      mockBrowserAdapter.Add.mockResolvedValue(8);
      const service = KuikaCoreWasmBridgeService.getInstance();

      const result = await service.Add(3, 5);

      expect(mockBrowserAdapter.Add).toHaveBeenCalledWith(3, 5);
      expect(result).toBe(8);
    });

    it("should delegate Ping to adapter", async () => {
      mockBrowserAdapter.Ping.mockResolvedValue("Pong!");
      const service = KuikaCoreWasmBridgeService.getInstance();

      const result = await service.Ping();

      expect(mockBrowserAdapter.Ping).toHaveBeenCalled();
      expect(result).toBe("Pong!");
    });

    it("should call Ping when run is called", async () => {
      mockBrowserAdapter.Ping.mockResolvedValue("Pong!");
      const service = KuikaCoreWasmBridgeService.getInstance();

      await service.run();

      expect(mockBrowserAdapter.Ping).toHaveBeenCalled();
    });

    // Database lifecycle methods
    describe("database lifecycle methods", () => {
      it("should delegate Db_Initialize to adapter", async () => {
        mockBrowserAdapter.Db_Initialize.mockResolvedValue(undefined);
        const service = KuikaCoreWasmBridgeService.getInstance();

        await service.Db_Initialize();

        expect(mockBrowserAdapter.Db_Initialize).toHaveBeenCalled();
      });

      it("should delegate Db_IsInitialized to adapter", async () => {
        mockBrowserAdapter.Db_IsInitialized.mockResolvedValue(true);
        const service = KuikaCoreWasmBridgeService.getInstance();

        const result = await service.Db_IsInitialized();

        expect(mockBrowserAdapter.Db_IsInitialized).toHaveBeenCalled();
        expect(result).toBe(true);
      });

      it("should delegate Db_Close to adapter", async () => {
        mockBrowserAdapter.Db_Close.mockResolvedValue(undefined);
        const service = KuikaCoreWasmBridgeService.getInstance();

        await service.Db_Close();

        expect(mockBrowserAdapter.Db_Close).toHaveBeenCalled();
      });
    });

    // Database import/export methods
    describe("database import/export methods", () => {
      it("should delegate Db_ExportDatabaseBase64 to adapter", async () => {
        const base64Data = "SGVsbG8gV29ybGQ=";
        mockBrowserAdapter.Db_ExportDatabaseBase64.mockResolvedValue(base64Data);
        const service = KuikaCoreWasmBridgeService.getInstance();

        const result = await service.Db_ExportDatabaseBase64();

        expect(mockBrowserAdapter.Db_ExportDatabaseBase64).toHaveBeenCalled();
        expect(result).toBe(base64Data);
      });

      it("should delegate Db_ImportDatabaseBase64 to adapter", async () => {
        const base64Data = "SGVsbG8gV29ybGQ=";
        mockBrowserAdapter.Db_ImportDatabaseBase64.mockResolvedValue(undefined);
        const service = KuikaCoreWasmBridgeService.getInstance();

        await service.Db_ImportDatabaseBase64(base64Data);

        expect(mockBrowserAdapter.Db_ImportDatabaseBase64).toHaveBeenCalledWith(base64Data);
      });
    });

    // Sync methods
    describe("sync methods", () => {
      it("should delegate Db_GetPendingChanges to adapter", async () => {
        const pendingJson = '{"Orders":[{"Id":"1"}]}';
        mockBrowserAdapter.Db_GetPendingChanges.mockResolvedValue(pendingJson);
        const service = KuikaCoreWasmBridgeService.getInstance();

        const result = await service.Db_GetPendingChanges();

        expect(mockBrowserAdapter.Db_GetPendingChanges).toHaveBeenCalled();
        expect(result).toBe(pendingJson);
      });

      it("should delegate Db_MarkAsSynced to adapter", async () => {
        const tableRecordsJson = '{"Orders":["1","2"]}';
        mockBrowserAdapter.Db_MarkAsSynced.mockResolvedValue(undefined);
        const service = KuikaCoreWasmBridgeService.getInstance();

        await service.Db_MarkAsSynced(tableRecordsJson);

        expect(mockBrowserAdapter.Db_MarkAsSynced).toHaveBeenCalledWith(tableRecordsJson);
      });
    });

    // Device metadata methods
    describe("device metadata methods", () => {
      it("should delegate Db_ImportDatabaseBase64WithReset to adapter", async () => {
        const base64Data = "SGVsbG8gV29ybGQ=";
        mockBrowserAdapter.Db_ImportDatabaseBase64WithReset.mockResolvedValue(undefined);
        const service = KuikaCoreWasmBridgeService.getInstance();

        await service.Db_ImportDatabaseBase64WithReset(base64Data);

        expect(mockBrowserAdapter.Db_ImportDatabaseBase64WithReset).toHaveBeenCalledWith(base64Data);
      });

      it("should delegate Db_UpdateDeviceMetadata to adapter", async () => {
        mockBrowserAdapter.Db_UpdateDeviceMetadata.mockResolvedValue(undefined);
        const service = KuikaCoreWasmBridgeService.getInstance();

        await service.Db_UpdateDeviceMetadata("device-1", "My Device", "com.example.app", "TestProject");

        expect(mockBrowserAdapter.Db_UpdateDeviceMetadata).toHaveBeenCalledWith(
          "device-1",
          "My Device",
          "com.example.app",
          "TestProject"
        );
      });

      it("should delegate Db_GetDeviceMetadata to adapter", async () => {
        const metadataJson = '{"deviceId":"device-1","deviceName":"My Device"}';
        mockBrowserAdapter.Db_GetDeviceMetadata.mockResolvedValue(metadataJson);
        const service = KuikaCoreWasmBridgeService.getInstance();

        const result = await service.Db_GetDeviceMetadata();

        expect(mockBrowserAdapter.Db_GetDeviceMetadata).toHaveBeenCalled();
        expect(result).toBe(metadataJson);
      });
    });

    // Note: Table-specific methods (Orders_*, Customers_*) are generated dynamically
    // based on project configuration. They would be tested in project-specific integration tests.
  });

  describe("when running in Electron", () => {
    let KuikaCoreWasmBridgeService: any;

    beforeEach(() => {
      mockIsElectron = true;
      jest.resetModules();

      // Re-mock with isElectron returning true
      jest.doMock("../electron-bridge-service", () => ({
        isElectron: jest.fn(() => true),
        transformUrlForElectron: jest.fn((url: string) => url),
        isCustomProtocol: jest.fn(() => false),
        getElectronBaseUrl: jest.fn(() => null)
      }));

      // Re-mock LocalStorageService and KuikaAppManager
      jest.doMock("../../auth/local-storage-service", () => ({
        __esModule: true,
        default: {
          getAccessToken: jest.fn(() => "mock-token"),
          getRefreshToken: jest.fn(() => null),
          setToken: jest.fn(),
          clearToken: jest.fn()
        }
      }));

      jest.doMock("../../shared/utilty/kuika-app-manager", () => ({
        KuikaAppManager: {
          GetBackendUrl: jest.fn(() => "http://localhost:3000"),
          getBackendUrlFromFullUrl: jest.fn(() => "http://localhost:3000")
        }
      }));

      KuikaCoreWasmBridgeService = require("../kuika-core-wasm-bridge-service").default;
    });

    it("should use ElectronIpcBridgeAdapter", () => {
      const service = KuikaCoreWasmBridgeService.getInstance();

      expect(service.getAdapterType()).toBe("electron");
    });

    it("should delegate initialize to adapter", async () => {
      mockElectronAdapter.initialize.mockResolvedValue(undefined);
      const service = KuikaCoreWasmBridgeService.getInstance();

      await service.initialize();

      expect(mockElectronAdapter.initialize).toHaveBeenCalled();
    });

    it("should delegate Add to adapter", async () => {
      mockElectronAdapter.Add.mockResolvedValue(15);
      const service = KuikaCoreWasmBridgeService.getInstance();

      const result = await service.Add(7, 8);

      expect(mockElectronAdapter.Add).toHaveBeenCalledWith(7, 8);
      expect(result).toBe(15);
    });

    it("should delegate Ping to adapter", async () => {
      mockElectronAdapter.Ping.mockResolvedValue("Pong from Electron!");
      const service = KuikaCoreWasmBridgeService.getInstance();

      const result = await service.Ping();

      expect(mockElectronAdapter.Ping).toHaveBeenCalled();
      expect(result).toBe("Pong from Electron!");
    });

    it("should delegate Db_Initialize to adapter", async () => {
      mockElectronAdapter.Db_Initialize.mockResolvedValue(undefined);
      const service = KuikaCoreWasmBridgeService.getInstance();

      await service.Db_Initialize();

      expect(mockElectronAdapter.Db_Initialize).toHaveBeenCalled();
    });
  });

  describe("singleton pattern", () => {
    let KuikaCoreWasmBridgeService: any;

    beforeEach(() => {
      mockIsElectron = false;
      jest.resetModules();

      // Re-mock dependencies after resetModules
      jest.doMock("../electron-bridge-service", () => ({
        isElectron: jest.fn(() => false),
        transformUrlForElectron: jest.fn((url: string) => url),
        isCustomProtocol: jest.fn(() => false),
        getElectronBaseUrl: jest.fn(() => null)
      }));

      jest.doMock("../../auth/local-storage-service", () => ({
        __esModule: true,
        default: {
          getAccessToken: jest.fn(() => "mock-token"),
          getRefreshToken: jest.fn(() => null),
          setToken: jest.fn(),
          clearToken: jest.fn()
        }
      }));

      jest.doMock("../../shared/utilty/kuika-app-manager", () => ({
        KuikaAppManager: {
          GetBackendUrl: jest.fn(() => "http://localhost:3000"),
          getBackendUrlFromFullUrl: jest.fn(() => "http://localhost:3000")
        }
      }));

      KuikaCoreWasmBridgeService = require("../kuika-core-wasm-bridge-service").default;
    });

    it("should return the same instance when getInstance is called multiple times", () => {
      const instance1 = KuikaCoreWasmBridgeService.getInstance();
      const instance2 = KuikaCoreWasmBridgeService.getInstance();

      expect(instance1).toBe(instance2);
    });
  });
});
