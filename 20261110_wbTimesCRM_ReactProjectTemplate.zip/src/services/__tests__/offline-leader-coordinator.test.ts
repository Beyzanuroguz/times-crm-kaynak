import { OfflineLeaderCoordinator, OfflineRpcRequest, OfflineRpcResult } from "../offline-leader-coordinator";

// The coordinator relies on two browser primitives jsdom does not implement: BroadcastChannel (a
// per-origin bus) and navigator.locks (Web Locks). We install controllable fakes so leader election,
// follower→leader RPC, and leader-death migration can be exercised deterministically in Node.

interface ChannelListener {
  onmessage: ((event: { data: unknown }) => void) | null;
}

const buses: Map<string, Set<FakeBroadcastChannel>> = new Map();

class FakeBroadcastChannel implements ChannelListener {
  onmessage: ((event: { data: unknown }) => void) | null = null;

  constructor(public readonly name: string) {
    const set: Set<FakeBroadcastChannel> = buses.get(name) ?? new Set<FakeBroadcastChannel>();
    set.add(this);
    buses.set(name, set);
  }

  postMessage(data: unknown): void {
    const set: Set<FakeBroadcastChannel> | undefined = buses.get(this.name);
    if (!set) {
      return;
    }
    for (const channel of set) {
      if (channel !== this) {
        // BroadcastChannel delivers asynchronously and never to the sender.
        const target: FakeBroadcastChannel = channel;
        void Promise.resolve().then((): void => {
          if (target.onmessage) {
            target.onmessage({ data });
          }
        });
      }
    }
  }

  close(): void {
    buses.get(this.name)?.delete(this);
  }
}

interface LockRequestOptions {
  mode: "exclusive" | "shared";
}
type LockCallback = () => Promise<void>;

/** Minimal exclusive Web Lock: one holder at a time, FIFO queue, plus a test-only forceRelease. */
class FakeLockManager {
  private held = false;

  private readonly queue: (() => void)[] = [];

  request(_name: string, _options: LockRequestOptions, callback: LockCallback): Promise<void> {
    const grant = (): void => {
      this.held = true;
      // The callback holds the lock by returning a promise that never resolves; on the rare settle we
      // release. Real tab-close is simulated by forceRelease().
      void callback().then((): void => this.releaseAndAdvance());
    };
    if (!this.held) {
      grant();
    } else {
      this.queue.push(grant);
    }
    // Real request() resolves when the lock is released; the coordinator ignores it, so resolve now.
    return Promise.resolve();
  }

  /** Simulate the current holder's tab closing: release and grant the next waiter. */
  forceRelease(): void {
    this.releaseAndAdvance();
  }

  private releaseAndAdvance(): void {
    this.held = false;
    const next: (() => void) | undefined = this.queue.shift();
    if (next) {
      this.held = true;
      next();
    }
  }
}

const flush = (): Promise<void> =>
  new Promise<void>((resolve: () => void): void => {
    setTimeout(resolve, 0);
  });

interface CryptoLike {
  randomUUID?: () => string;
}

describe("OfflineLeaderCoordinator", () => {
  let lockManager: FakeLockManager;
  let originalBroadcast: unknown;
  let originalLocks: unknown;

  beforeEach(() => {
    buses.clear();
    lockManager = new FakeLockManager();

    originalBroadcast = (globalThis as unknown as { BroadcastChannel?: unknown }).BroadcastChannel;
    (globalThis as unknown as { BroadcastChannel: unknown }).BroadcastChannel = FakeBroadcastChannel;

    const nav: { locks?: unknown } = globalThis.navigator as unknown as { locks?: unknown };
    originalLocks = nav.locks;
    nav.locks = lockManager;

    const cryptoObj: CryptoLike = (globalThis.crypto as unknown as CryptoLike) ?? ({} as CryptoLike);
    if (!cryptoObj.randomUUID) {
      let counter = 0;
      cryptoObj.randomUUID = (): string => `uuid-${counter++}`;
      (globalThis as unknown as { crypto: CryptoLike }).crypto = cryptoObj;
    }
  });

  afterEach(() => {
    (globalThis as unknown as { BroadcastChannel: unknown }).BroadcastChannel = originalBroadcast;
    (globalThis.navigator as unknown as { locks: unknown }).locks = originalLocks;
  });

  it("is supported once BroadcastChannel + navigator.locks exist", () => {
    expect(OfflineLeaderCoordinator.isSupported()).toBe(true);
  });

  it("makes the first tab the leader and runs ops locally", async () => {
    const execute = jest.fn(async (request: OfflineRpcRequest): Promise<OfflineRpcResult> => ({
      ok: true,
      result: `L:${request.method}`
    }));
    const promote = jest.fn(async (): Promise<void> => {});

    const leader = new OfflineLeaderCoordinator();
    await leader.start(execute, promote);

    expect(leader.isLeader()).toBe(true);
    expect(promote).toHaveBeenCalledTimes(1);

    const result: OfflineRpcResult = await leader.route({ kind: "call", method: "Ping" });
    expect(result).toEqual({ ok: true, result: "L:Ping" });
    expect(execute).toHaveBeenCalledWith({ kind: "call", method: "Ping" });
  });

  it("makes a second tab a follower that routes to the leader", async () => {
    const leaderExecute = jest.fn(async (request: OfflineRpcRequest): Promise<OfflineRpcResult> => ({
      ok: true,
      result: `A:${request.method}`
    }));
    const leader = new OfflineLeaderCoordinator();
    await leader.start(leaderExecute, async (): Promise<void> => {});

    const followerExecute = jest.fn();
    const follower = new OfflineLeaderCoordinator();
    await follower.start(followerExecute, async (): Promise<void> => {});

    expect(follower.isLeader()).toBe(false);

    const result: OfflineRpcResult = await follower.route({ kind: "call", method: "Get" });
    expect(result).toEqual({ ok: true, result: "A:Get" });
    // The follower never touched a local worker; the leader executed the op.
    expect(followerExecute).not.toHaveBeenCalled();
    expect(leaderExecute).toHaveBeenCalledWith({ kind: "call", method: "Get" });
  });

  it("resends in-flight requests to the new leader after a migration", async () => {
    const leaderExecute = jest.fn(async (request: OfflineRpcRequest): Promise<OfflineRpcResult> => ({
      ok: true,
      result: `A:${request.method}`
    }));
    const leader = new OfflineLeaderCoordinator();
    await leader.start(leaderExecute, async (): Promise<void> => {});

    const followerExecute = jest.fn(async (request: OfflineRpcRequest): Promise<OfflineRpcResult> => ({
      ok: true,
      result: `B:${request.method}`
    }));
    const follower = new OfflineLeaderCoordinator();
    await follower.start(followerExecute, async (): Promise<void> => {});

    // A third tab that will become the new leader after A dies.
    const takeoverExecute = jest.fn(async (request: OfflineRpcRequest): Promise<OfflineRpcResult> => ({
      ok: true,
      result: `C:${request.method}`
    }));
    const takeover = new OfflineLeaderCoordinator();
    await takeover.start(takeoverExecute, async (): Promise<void> => {});

    // Issue a request from the follower, then kill the leader before it can answer.
    leaderExecute.mockImplementation((): Promise<OfflineRpcResult> => new Promise<OfflineRpcResult>((): void => {}));
    const inFlight: Promise<OfflineRpcResult> = follower.route({ kind: "call", method: "Q" });
    lockManager.forceRelease();
    await flush();
    await flush();

    const result: OfflineRpcResult = await inFlight;
    // Whoever won the lock (B or C) answered — never the dead A.
    expect(["B:Q", "C:Q"]).toContain(result.result);
  });

  it("promotes a follower when the leader tab closes (migration)", async () => {
    const leaderExecute = jest.fn(async (request: OfflineRpcRequest): Promise<OfflineRpcResult> => ({
      ok: true,
      result: `A:${request.method}`
    }));
    const leader = new OfflineLeaderCoordinator();
    await leader.start(leaderExecute, async (): Promise<void> => {});

    const followerExecute = jest.fn(async (request: OfflineRpcRequest): Promise<OfflineRpcResult> => ({
      ok: true,
      result: `B:${request.method}`
    }));
    const promoteFollower = jest.fn(async (): Promise<void> => {});
    const follower = new OfflineLeaderCoordinator();
    await follower.start(followerExecute, promoteFollower);
    expect(follower.isLeader()).toBe(false);

    // The leader tab closes → its lock releases → the follower is promoted.
    lockManager.forceRelease();
    await flush();
    await flush();

    expect(promoteFollower).toHaveBeenCalledTimes(1);
    expect(follower.isLeader()).toBe(true);

    const result: OfflineRpcResult = await follower.route({ kind: "call", method: "Z" });
    expect(result).toEqual({ ok: true, result: "B:Z" });
  });
});
