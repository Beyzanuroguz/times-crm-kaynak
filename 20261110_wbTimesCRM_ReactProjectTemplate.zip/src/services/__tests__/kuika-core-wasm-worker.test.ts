/**
 * The offline WASM worker's message wiring.
 *
 * The .NET loader (dotnet.js, `loader/globals.ts`) probes the worker global when it is first
 * evaluated: `if (typeof importScripts === "function" && !globalThis.onmessage) dotnetSidecar = true`.
 * A worker that has already ASSIGNED `self.onmessage` is taken for an emscripten helper hosted by
 * someone else, and `dotnet.create()` then never resolves — silently, with every asset downloaded.
 * That is exactly what the leader tab did on preprod ("Fetch Offline DB" spinner forever, nothing in
 * network or console). The worker must therefore subscribe with `addEventListener` and leave the
 * `onmessage` property untouched. These tests pin that invariant and the request/response wiring
 * built on it, in jsdom where `self` is the window.
 */

interface WorkerResponseLike {
  id: number;
  ok: boolean;
  error?: string;
}

type MessageListener = (event: { data: unknown }) => void;

interface WorkerScopeForTest {
  onmessage: unknown;
  postMessage: jest.Mock;
  addEventListener: (type: string, listener: MessageListener) => void;
}

const flush = (): Promise<void> =>
  new Promise<void>((resolve: () => void): void => {
    setTimeout(resolve, 0);
  });

describe("kuika-core-wasm-worker message wiring", () => {
  const scope: WorkerScopeForTest = self as unknown as WorkerScopeForTest;
  let originalPostMessage: unknown;
  let originalAddEventListener: WorkerScopeForTest["addEventListener"];
  const registered: Map<string, MessageListener> = new Map();

  beforeAll(async () => {
    originalPostMessage = scope.postMessage;
    originalAddEventListener = scope.addEventListener;
    // Capture the listener the module registers instead of relying on jsdom's MessageEvent
    // dispatch, and replace the global's postMessage (jsdom's window variant needs a
    // targetOrigin) with a spy — both before the module installs its wiring.
    scope.addEventListener = (type: string, listener: MessageListener): void => {
      registered.set(type, listener);
    };
    scope.postMessage = jest.fn();
    await import("../kuika-core-wasm-worker");
  });

  afterAll(() => {
    (scope as unknown as { postMessage: unknown }).postMessage = originalPostMessage;
    scope.addEventListener = originalAddEventListener;
  });

  it("never assigns self.onmessage, so dotnet.js boots as the worker's main script (sidecar)", () => {
    expect(scope.onmessage).toBeNull();
    expect(registered.has("message")).toBe(true);
  });

  it("still receives requests through addEventListener and answers by correlation id", async () => {
    const listener: MessageListener | undefined = registered.get("message");
    expect(listener).toBeDefined();
    listener?.({ data: { type: "call", id: 7, method: "Ping", args: [] } });
    await flush();

    expect(scope.postMessage).toHaveBeenCalledTimes(1);
    const response: WorkerResponseLike = scope.postMessage.mock.calls[0][0] as WorkerResponseLike;
    expect(response.id).toBe(7);
    expect(response.ok).toBe(false);
    expect(response.error).toMatch(/before initialization/);
  });
});
