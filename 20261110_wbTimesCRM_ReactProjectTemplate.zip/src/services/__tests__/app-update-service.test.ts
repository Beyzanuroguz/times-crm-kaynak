import { fireEvent, render, type RenderResult } from "@testing-library/react";
import type { ReactElement } from "react";

const mockAddNotification = jest.fn().mockReturnValue("mock-notification-id");
const mockRemoveNotification = jest.fn();

jest.mock("react-notifications-component", () => ({
  Store: {
    addNotification: (...args: unknown[]) => mockAddNotification(...args),
    removeNotification: (...args: unknown[]) => mockRemoveNotification(...args)
  }
}));

jest.mock("../../shared/utilty/kuika-app-manager", () => ({
  KuikaAppManager: {
    GetFrontEndUrl: (): string => "https://app.example.test"
  }
}));

jest.mock("../../shared/utilty/frontend-url", () => ({
  KUIKA_ENV_CONFIG_MESSAGE_TYPE: "kuika-env-config"
}));

// Imported once, not re-required per test: a `jest.resetModules()` would hand
// the service a second copy of React, whose hooks then run inside testing-
// library's react-dom and crash. Its module state is reset in afterEach by
// invoking the notification's `onRemoval` callback instead.
import { initAppUpdateMonitoring, reshowPendingUpdateNotice } from "../app-update-service";

type Listener = () => void;

class FakeEventTarget {
  private readonly listeners: Map<string, Listener[]> = new Map();

  addEventListener(type: string, listener: Listener): void {
    const existing: Listener[] = this.listeners.get(type) ?? [];
    existing.push(listener);
    this.listeners.set(type, existing);
  }

  removeEventListener(type: string, listener: Listener): void {
    const existing: Listener[] = this.listeners.get(type) ?? [];
    this.listeners.set(
      type,
      existing.filter((candidate: Listener): boolean => candidate !== listener)
    );
  }

  dispatch(type: string): void {
    const existing: Listener[] = this.listeners.get(type) ?? [];
    for (const listener of [...existing]) {
      listener();
    }
  }
}

class FakeServiceWorker extends FakeEventTarget {
  state: string = "installing";
  readonly postMessage: jest.Mock = jest.fn();

  setState(state: string): void {
    this.state = state;
    this.dispatch("statechange");
  }
}

class FakeRegistration extends FakeEventTarget {
  installing: FakeServiceWorker | null = null;
  waiting: FakeServiceWorker | null = null;
  active: FakeServiceWorker | null = null;
  readonly update: jest.Mock = jest.fn().mockResolvedValue(undefined);
}

interface NotificationDismiss {
  duration: number;
  click?: boolean;
  touch?: boolean;
}

interface NotificationCall {
  id?: string;
  container: string;
  content?: ReactElement;
  dismiss: NotificationDismiss;
  onRemoval?: () => void;
}

const UPDATE_NOTIFICATION_ID: string = "kuika-app-update";
const PAGE_SETTLE_GRACE_MS: number = 5000;
const FALLBACK_RELOAD_DELAY_MS: number = 1500;

// jsdom's location.reload is read-only, so the whole object is swapped for the
// test and the real descriptor is restored afterwards.
const realLocationDescriptor: PropertyDescriptor | undefined = Object.getOwnPropertyDescriptor(window, "location");
const reloadMock: jest.Mock = jest.fn();

async function flushMicrotasks(): Promise<void> {
  for (let i = 0; i < 10; i++) {
    await Promise.resolve();
  }
}

async function bootMonitoring(registration: FakeRegistration): Promise<void> {
  Object.defineProperty(navigator, "serviceWorker", {
    configurable: true,
    value: {
      controller: {},
      register: jest.fn().mockResolvedValue(registration),
      addEventListener: jest.fn()
    }
  });
  Object.defineProperty(document, "readyState", { configurable: true, value: "complete" });

  initAppUpdateMonitoring();
  await flushMicrotasks();
}

async function settlePage(): Promise<void> {
  jest.advanceTimersByTime(PAGE_SETTLE_GRACE_MS);
  await flushMicrotasks();
}

function installNewWorker(registration: FakeRegistration): FakeServiceWorker {
  const worker: FakeServiceWorker = new FakeServiceWorker();
  registration.installing = worker;
  registration.dispatch("updatefound");
  worker.setState("installed");
  return worker;
}

function lastNotificationCall(): NotificationCall {
  const calls: unknown[][] = mockAddNotification.mock.calls;
  return calls[calls.length - 1][0] as NotificationCall;
}

function renderStrip(call: NotificationCall): RenderResult {
  if (!call.content) {
    throw new Error("update notification has no custom content");
  }
  return render(call.content);
}

describe("app-update-service update strip", () => {
  beforeEach(() => {
    jest.useFakeTimers();
    localStorage.clear();
    Object.defineProperty(window, "location", {
      configurable: true,
      value: { protocol: "http:", reload: reloadMock }
    });
  });

  afterEach(() => {
    // Clear the service's "strip visible" flag the way the library would on removal,
    // so the next test can show a strip again.
    const calls: unknown[][] = mockAddNotification.mock.calls;
    if (calls.length > 0) {
      const lastCall: NotificationCall = calls[calls.length - 1][0] as NotificationCall;
      lastCall.onRemoval?.();
    }
    jest.useRealTimers();
    if (realLocationDescriptor) {
      Object.defineProperty(window, "location", realLocationDescriptor);
    }
  });

  it("shows a full-width top strip with custom content and no way to dismiss it", async () => {
    const registration: FakeRegistration = new FakeRegistration();
    await bootMonitoring(registration);
    await settlePage();

    installNewWorker(registration);

    expect(mockAddNotification).toHaveBeenCalledTimes(1);
    const call: NotificationCall = lastNotificationCall();
    expect(call.id).toBe(UPDATE_NOTIFICATION_ID);
    expect(call.container).toBe("top-full");
    expect(call.dismiss).toEqual(expect.objectContaining({ duration: 0, click: false, touch: false }));

    const strip: RenderResult = renderStrip(call);
    expect(strip.getByRole("status")).toHaveClass("kuika-app-update-bar");
    expect(strip.getByText("A new version of the app is available.")).toBeInTheDocument();
    expect(strip.getByRole("button", { name: "Refresh" })).toBeInTheDocument();
    // Refresh is the only control: there is no close button, the strip stays until reload.
    expect(strip.getAllByRole("button")).toHaveLength(1);
  });

  it("localises the strip to Turkish from the stored language", async () => {
    localStorage.setItem("ml", "tr_TR");
    const registration: FakeRegistration = new FakeRegistration();
    await bootMonitoring(registration);
    await settlePage();

    installNewWorker(registration);

    const strip: RenderResult = renderStrip(lastNotificationCall());
    expect(strip.getByText("Yeni uygulama sürümü mevcut.")).toBeInTheDocument();
    expect(strip.getByRole("button", { name: "Yenile" })).toBeInTheDocument();
  });

  it("takes the strip down on Refresh and keeps the SKIP_WAITING + 1.5s fallback path", async () => {
    const registration: FakeRegistration = new FakeRegistration();
    await bootMonitoring(registration);
    await settlePage();

    const worker: FakeServiceWorker = installNewWorker(registration);
    // The SW skip-waits on install and claims on activate, so by the time the
    // user clicks it is normally already the active worker. The click still
    // takes the unchanged path: no immediate reload, the fallback timer does it.
    worker.setState("activated");
    const strip: RenderResult = renderStrip(lastNotificationCall());

    fireEvent.click(strip.getByRole("button", { name: "Refresh" }));

    expect(mockRemoveNotification).toHaveBeenCalledWith(UPDATE_NOTIFICATION_ID);
    expect(worker.postMessage).toHaveBeenCalledWith("SKIP_WAITING");
    expect(reloadMock).not.toHaveBeenCalled();

    jest.advanceTimersByTime(FALLBACK_RELOAD_DELAY_MS);
    expect(reloadMock).toHaveBeenCalledTimes(1);
  });

  it("keeps a single strip across back-to-back deploys and applies the newest worker", async () => {
    const registration: FakeRegistration = new FakeRegistration();
    await bootMonitoring(registration);
    await settlePage();

    const firstWorker: FakeServiceWorker = installNewWorker(registration);
    const secondWorker: FakeServiceWorker = installNewWorker(registration);

    expect(mockAddNotification).toHaveBeenCalledTimes(1);

    const strip: RenderResult = renderStrip(lastNotificationCall());
    fireEvent.click(strip.getByRole("button", { name: "Refresh" }));
    expect(secondWorker.postMessage).toHaveBeenCalledWith("SKIP_WAITING");
    expect(firstWorker.postMessage).not.toHaveBeenCalledWith("SKIP_WAITING");
  });

  it("shows the strip again for a later deploy once the previous one was dismissed", async () => {
    const registration: FakeRegistration = new FakeRegistration();
    await bootMonitoring(registration);
    await settlePage();

    installNewWorker(registration);
    const firstCall: NotificationCall = lastNotificationCall();
    firstCall.onRemoval?.();

    installNewWorker(registration);

    expect(mockAddNotification).toHaveBeenCalledTimes(2);
  });

  it("adopts silently (no strip) when the install starts before the page settles", async () => {
    const registration: FakeRegistration = new FakeRegistration();
    await bootMonitoring(registration);

    const worker: FakeServiceWorker = installNewWorker(registration);

    expect(mockAddNotification).not.toHaveBeenCalled();
    expect(worker.postMessage).toHaveBeenCalledWith("SKIP_WAITING");
  });

  describe("periodic update checks", () => {
    const UPDATE_CHECK_INTERVAL_MS: number = 60 * 1000;
    let warnSpy: jest.SpyInstance;

    beforeEach(() => {
      warnSpy = jest.spyOn(console, "warn").mockImplementation((): void => undefined);
    });

    afterEach(() => {
      warnSpy.mockRestore();
    });

    async function runNextUpdateCheck(): Promise<void> {
      jest.advanceTimersByTime(UPDATE_CHECK_INTERVAL_MS);
      await flushMicrotasks();
    }

    it("keeps checking after sw.js is unreachable during a deploy", async () => {
      const registration: FakeRegistration = new FakeRegistration();
      registration.update
        .mockRejectedValueOnce(new TypeError("Failed to update a ServiceWorker: 502"))
        .mockResolvedValue(undefined);
      await bootMonitoring(registration);
      await settlePage();

      await runNextUpdateCheck();
      await runNextUpdateCheck();

      expect(registration.update).toHaveBeenCalledTimes(2);
    });

    it("logs a failure streak once and again after a success", async () => {
      const registration: FakeRegistration = new FakeRegistration();
      const failure: TypeError = new TypeError("Failed to fetch");
      registration.update
        .mockRejectedValueOnce(failure)
        .mockRejectedValueOnce(failure)
        .mockResolvedValueOnce(undefined)
        .mockRejectedValueOnce(failure);
      await bootMonitoring(registration);
      await settlePage();

      await runNextUpdateCheck();
      await runNextUpdateCheck();
      expect(warnSpy).toHaveBeenCalledTimes(1);

      await runNextUpdateCheck();
      await runNextUpdateCheck();
      expect(warnSpy).toHaveBeenCalledTimes(2);
    });

    it("stops checking once the registration is gone", async () => {
      const registration: FakeRegistration = new FakeRegistration();
      registration.update.mockRejectedValue(new DOMException("registration uninstalled", "InvalidStateError"));
      await bootMonitoring(registration);
      await settlePage();

      await runNextUpdateCheck();
      await runNextUpdateCheck();

      expect(registration.update).toHaveBeenCalledTimes(1);
    });
  });

  describe("reshowPendingUpdateNotice (notification layer re-mount)", () => {
    it("does nothing when no update is pending", async () => {
      // The shared module keeps the worker from earlier tests pending, so use a
      // fresh copy that has never seen an install. Nothing is rendered here, so
      // the second React copy that comes with it is harmless.
      await jest.isolateModulesAsync(async (): Promise<void> => {
        const fresh: typeof import("../app-update-service") = await import("../app-update-service");
        fresh.reshowPendingUpdateNotice();
      });

      expect(mockAddNotification).not.toHaveBeenCalled();
    });

    it("re-raises the pending notice when this bundle's strip is not in the document", async () => {
      const registration: FakeRegistration = new FakeRegistration();
      await bootMonitoring(registration);
      await settlePage();
      installNewWorker(registration);
      expect(mockAddNotification).toHaveBeenCalledTimes(1);

      // The strip was never rendered: the (micro app) notification layer was
      // unmounted when the notice was raised.
      reshowPendingUpdateNotice();

      expect(mockAddNotification).toHaveBeenCalledTimes(2);
      expect(lastNotificationCall().id).toBe(UPDATE_NOTIFICATION_ID);
    });

    it("leaves the notice alone when this bundle's strip is already in the document", async () => {
      const registration: FakeRegistration = new FakeRegistration();
      await bootMonitoring(registration);
      await settlePage();
      installNewWorker(registration);
      const strip: RenderResult = renderStrip(lastNotificationCall());
      expect(strip.getByRole("status")).toHaveAttribute("data-kuika-app-url", "https://app.example.test");

      reshowPendingUpdateNotice();

      expect(mockAddNotification).toHaveBeenCalledTimes(1);
    });

    it("ignores another bundle's strip when deciding to re-raise", async () => {
      const registration: FakeRegistration = new FakeRegistration();
      await bootMonitoring(registration);
      await settlePage();
      installNewWorker(registration);

      // A host page can show the HOST bundle's strip while this (micro app)
      // bundle's own notice is still pending.
      const foreignStrip: HTMLDivElement = document.createElement("div");
      foreignStrip.className = "kuika-app-update-bar";
      foreignStrip.setAttribute("data-kuika-app-url", "https://other-app.example.test");
      document.body.appendChild(foreignStrip);
      try {
        reshowPendingUpdateNotice();
        expect(mockAddNotification).toHaveBeenCalledTimes(2);
      } finally {
        foreignStrip.remove();
      }
    });
  });
});
