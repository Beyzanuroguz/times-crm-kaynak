import { ElectronIpcBridgeAdapter } from "../kuika-core-wasm-electron-ipc-bridge-adapter";

describe("ElectronIpcBridgeAdapter", () => {
  let adapter: ElectronIpcBridgeAdapter;
  let mockKuikaCoreNative: any;

  beforeEach(() => {
    jest.clearAllMocks();

    // Setup mock for window.electronAPI.kuikaCoreNative with generic invoke
    mockKuikaCoreNative = {
      initialize: jest.fn(),
      invoke: jest.fn()
    };

    // Setup window mock with electronAPI
    (window as any).electronAPI = {
      kuikaCoreNative: mockKuikaCoreNative
    };

    adapter = new ElectronIpcBridgeAdapter();
  });

  afterEach(() => {
    // Clean up window mock
    delete (window as any).electronAPI;
  });

  describe("getAdapterType", () => {
    it('should return "electron"', () => {
      expect(adapter.getAdapterType()).toBe("electron");
    });
  });

  describe("getIsInitialized", () => {
    it("should return false initially", () => {
      expect(adapter.getIsInitialized()).toBe(false);
    });

    it("should return true after successful initialization", async () => {
      mockKuikaCoreNative.initialize.mockResolvedValue({ success: true });

      await adapter.initialize();

      expect(adapter.getIsInitialized()).toBe(true);
    });
  });

  describe("initialize", () => {
    it("should call electronAPI.kuikaCoreNative.initialize", async () => {
      mockKuikaCoreNative.initialize.mockResolvedValue({ success: true });

      await adapter.initialize();

      expect(mockKuikaCoreNative.initialize).toHaveBeenCalled();
    });

    it("should not reinitialize if already initialized", async () => {
      mockKuikaCoreNative.initialize.mockResolvedValue({ success: true });

      await adapter.initialize();
      await adapter.initialize();

      expect(mockKuikaCoreNative.initialize).toHaveBeenCalledTimes(1);
    });

    it("should throw error when initialization fails", async () => {
      mockKuikaCoreNative.initialize.mockResolvedValue({
        success: false,
        error: "Native not available"
      });

      await expect(adapter.initialize()).rejects.toThrow("Native not available");
    });

    it("should throw generic error when initialization fails without message", async () => {
      mockKuikaCoreNative.initialize.mockResolvedValue({ success: false });

      await expect(adapter.initialize()).rejects.toThrow("Native initialization failed");
    });

    it("should throw error when electronAPI is not available", async () => {
      delete (window as any).electronAPI;

      const testAdapter = new ElectronIpcBridgeAdapter();

      await expect(testAdapter.initialize()).rejects.toThrow(
        "Electron Native API not available. Make sure you're running in Electron."
      );
    });

    it("should throw error when kuikaCoreNative is not available", async () => {
      (window as any).electronAPI = {};

      const testAdapter = new ElectronIpcBridgeAdapter();

      await expect(testAdapter.initialize()).rejects.toThrow(
        "Electron Native API not available. Make sure you're running in Electron."
      );
    });
  });

  describe("Add", () => {
    beforeEach(async () => {
      mockKuikaCoreNative.initialize.mockResolvedValue({ success: true });
      await adapter.initialize();
      jest.clearAllMocks();
    });

    it("should call invoke with 'add' method and correct arguments", async () => {
      mockKuikaCoreNative.invoke.mockResolvedValue({ success: true, result: 8 });

      const result = await adapter.Add(3, 5);

      expect(mockKuikaCoreNative.invoke).toHaveBeenCalledWith("add", [3, 5]);
      expect(result).toBe(8);
    });

    it("should throw error when add fails", async () => {
      mockKuikaCoreNative.invoke.mockResolvedValue({
        success: false,
        error: "Add operation failed"
      });

      await expect(adapter.Add(1, 2)).rejects.toThrow("Add operation failed");
    });

    it("should throw generic error when add fails without message", async () => {
      mockKuikaCoreNative.invoke.mockResolvedValue({ success: false });

      await expect(adapter.Add(1, 2)).rejects.toThrow("Native add failed");
    });

    it("should auto-initialize if not initialized", async () => {
      const freshAdapter = new ElectronIpcBridgeAdapter();
      mockKuikaCoreNative.initialize.mockResolvedValue({ success: true });
      mockKuikaCoreNative.invoke.mockResolvedValue({ success: true, result: 10 });

      const result = await freshAdapter.Add(4, 6);

      expect(mockKuikaCoreNative.initialize).toHaveBeenCalled();
      expect(result).toBe(10);
    });
  });

  describe("Ping", () => {
    beforeEach(async () => {
      mockKuikaCoreNative.initialize.mockResolvedValue({ success: true });
      await adapter.initialize();
      jest.clearAllMocks();
    });

    it("should call invoke with 'ping' method", async () => {
      mockKuikaCoreNative.invoke.mockResolvedValue({
        success: true,
        result: "Pong from KuikaCore!"
      });

      const result = await adapter.Ping();

      expect(mockKuikaCoreNative.invoke).toHaveBeenCalledWith("ping", []);
      expect(result).toBe("Pong from KuikaCore!");
    });

    it("should throw error when ping fails", async () => {
      mockKuikaCoreNative.invoke.mockResolvedValue({
        success: false,
        error: "Ping operation failed"
      });

      await expect(adapter.Ping()).rejects.toThrow("Ping operation failed");
    });

    it("should throw generic error when ping fails without message", async () => {
      mockKuikaCoreNative.invoke.mockResolvedValue({ success: false });

      await expect(adapter.Ping()).rejects.toThrow("Native ping failed");
    });

    it("should auto-initialize if not initialized", async () => {
      const freshAdapter = new ElectronIpcBridgeAdapter();
      mockKuikaCoreNative.initialize.mockResolvedValue({ success: true });
      mockKuikaCoreNative.invoke.mockResolvedValue({
        success: true,
        result: "Pong!"
      });

      const result = await freshAdapter.Ping();

      expect(mockKuikaCoreNative.initialize).toHaveBeenCalled();
      expect(result).toBe("Pong!");
    });
  });

  // Database lifecycle methods
  describe("Database lifecycle methods", () => {
    beforeEach(async () => {
      mockKuikaCoreNative.initialize.mockResolvedValue({ success: true });
      await adapter.initialize();
      jest.clearAllMocks();
    });

    it("should call Db_Initialize correctly", async () => {
      mockKuikaCoreNative.invoke.mockResolvedValue({ success: true, result: "Database initialized" });

      await adapter.Db_Initialize();

      expect(mockKuikaCoreNative.invoke).toHaveBeenCalledWith("db_initialize", []);
    });

    it("should return false from Db_IsInitialized before Db_Initialize is called", async () => {
      // Native returns C# bool.ToString() → "False" string
      mockKuikaCoreNative.invoke.mockResolvedValue({ success: true, result: "False" });

      const result = await adapter.Db_IsInitialized();

      // Checks native HasData once on first call
      expect(mockKuikaCoreNative.invoke).toHaveBeenCalledWith("db_isinitialized", []);
      expect(result).toBe(false);
    });

    it("should return true from Db_IsInitialized after Db_Initialize is called", async () => {
      mockKuikaCoreNative.invoke.mockResolvedValue({ success: true, result: "" });

      await adapter.Db_Initialize();
      const result = await adapter.Db_IsInitialized();

      expect(result).toBe(true);
    });

    it("should call Db_Close correctly", async () => {
      mockKuikaCoreNative.invoke.mockResolvedValue({ success: true, result: "Database closed" });

      await adapter.Db_Close();

      expect(mockKuikaCoreNative.invoke).toHaveBeenCalledWith("db_close", []);
    });
  });

  // Database import/export methods
  describe("Database import/export methods", () => {
    beforeEach(async () => {
      mockKuikaCoreNative.initialize.mockResolvedValue({ success: true });
      await adapter.initialize();
      jest.clearAllMocks();
    });

    it("should call Db_ExportDatabaseBase64 correctly", async () => {
      const base64Data = "SGVsbG8gV29ybGQ=";
      mockKuikaCoreNative.invoke.mockResolvedValue({ success: true, result: base64Data });

      const result = await adapter.Db_ExportDatabaseBase64();

      expect(mockKuikaCoreNative.invoke).toHaveBeenCalledWith("db_exportdatabasebase64", []);
      expect(result).toBe(base64Data);
    });

    it("should call Db_ImportDatabaseBase64 correctly", async () => {
      const base64Data = "SGVsbG8gV29ybGQ=";
      mockKuikaCoreNative.invoke.mockResolvedValue({ success: true, result: "Database imported" });

      await adapter.Db_ImportDatabaseBase64(base64Data);

      expect(mockKuikaCoreNative.invoke).toHaveBeenCalledWith("db_importdatabasebase64", [base64Data]);
    });
  });

  // Sync methods
  describe("Sync methods", () => {
    beforeEach(async () => {
      mockKuikaCoreNative.initialize.mockResolvedValue({ success: true });
      await adapter.initialize();
      jest.clearAllMocks();
    });

    it("should call Db_GetPendingChanges correctly", async () => {
      const pendingJson = '{"Orders":[{"Id":"1"}]}';
      mockKuikaCoreNative.invoke.mockResolvedValue({ success: true, result: pendingJson });

      const result = await adapter.Db_GetPendingChanges();

      expect(mockKuikaCoreNative.invoke).toHaveBeenCalledWith("db_getpendingchanges", []);
      expect(result).toBe(pendingJson);
    });

    it("should call Db_MarkAsSynced correctly", async () => {
      const tableRecordsJson = '{"Orders":["1","2"]}';
      mockKuikaCoreNative.invoke.mockResolvedValue({ success: true, result: "Records marked as synced" });

      await adapter.Db_MarkAsSynced(tableRecordsJson);

      expect(mockKuikaCoreNative.invoke).toHaveBeenCalledWith("db_markassynced", [tableRecordsJson]);
    });
  });

  // Device metadata methods
  describe("Device metadata methods", () => {
    beforeEach(async () => {
      mockKuikaCoreNative.initialize.mockResolvedValue({ success: true });
      await adapter.initialize();
      jest.clearAllMocks();
    });

    it("should call Db_ImportDatabaseBase64WithReset correctly", async () => {
      const base64Data = "SGVsbG8gV29ybGQ=";
      mockKuikaCoreNative.invoke.mockResolvedValue({ success: true, result: "Database imported with reset" });

      await adapter.Db_ImportDatabaseBase64WithReset(base64Data);

      expect(mockKuikaCoreNative.invoke).toHaveBeenCalledWith("db_importdatabasebase64withreset", [base64Data]);
    });

    it("should call Db_UpdateDeviceMetadata correctly", async () => {
      mockKuikaCoreNative.invoke.mockResolvedValue({ success: true, result: "Metadata updated" });

      await adapter.Db_UpdateDeviceMetadata("device-1", "My Device", "com.example.app", "TestProject");

      expect(mockKuikaCoreNative.invoke).toHaveBeenCalledWith("db_updatedevicemetadata", [
        "device-1",
        "My Device",
        "com.example.app",
        "TestProject"
      ]);
    });

    it("should call Db_GetDeviceMetadata correctly", async () => {
      const metadataJson = '{"deviceId":"device-1","deviceName":"My Device"}';
      mockKuikaCoreNative.invoke.mockResolvedValue({ success: true, result: metadataJson });

      const result = await adapter.Db_GetDeviceMetadata();

      expect(mockKuikaCoreNative.invoke).toHaveBeenCalledWith("db_getdevicemetadata", []);
      expect(result).toBe(metadataJson);
    });
  });

  // Note: Table-specific methods (Orders_*, Customers_*) are generated dynamically
  // based on project configuration. They would be tested in project-specific integration tests.
});
