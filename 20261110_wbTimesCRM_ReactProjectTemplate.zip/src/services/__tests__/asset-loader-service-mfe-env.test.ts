import { KuikaMfeAppEntry } from "../../shared/utilty/own-app-env";
import { AssetLoaderService, MfeManifest } from "../asset-loader-service";

jest.mock("../../shared/utilty/kuika-app-manager", () => ({
  KuikaAppManager: {
    GetFrontEndSourceUrl: jest.fn(() => "https://host.example")
  }
}));

interface CacheHolder {
  mfeEnvConfigCache: Map<string, unknown>;
  mfeManifestCache: Map<string, MfeManifest>;
  loadedMfeApps: Set<string>;
}

const caches: CacheHolder = AssetLoaderService as unknown as CacheHolder;

const MICROAPP_URL = "https://micro.example/";

const manifest: MfeManifest = {
  webComponentTag: "micro-app-tag",
  appName: "microApp",
  workspace: "microWorkspace",
  backendUrlOverride: "https://baked-api.example/v1/api",
  entryFiles: { index: { js: ["static/js/index.js"], css: [] } }
};

interface FetchResponseInit {
  ok: boolean;
  contentType?: string;
  body?: string;
}

const respondWith = (init: FetchResponseInit): void => {
  global.fetch = jest.fn().mockResolvedValue({
    ok: init.ok,
    headers: {
      get: (name: string): string | null => (name.toLowerCase() === "content-type" ? (init.contentType ?? null) : null)
    },
    text: async (): Promise<string> => init.body ?? ""
  }) as unknown as typeof fetch;
};

const registeredApps = (): KuikaMfeAppEntry[] =>
  (window as unknown as { kuika?: { apps?: KuikaMfeAppEntry[] } }).kuika?.apps ?? [];

beforeEach(() => {
  caches.mfeEnvConfigCache.clear();
  caches.mfeManifestCache.clear();
  caches.loadedMfeApps.clear();
  delete (window as unknown as { kuika?: unknown }).kuika;
  jest.clearAllMocks();
});

describe("fetchMfeManifest", () => {
  it("bypasses the browser HTTP cache so an uncontrolled load cannot inject a previous deployment's bundle", async () => {
    global.fetch = jest.fn().mockResolvedValue({
      ok: true,
      json: async (): Promise<MfeManifest> => manifest
    }) as unknown as typeof fetch;

    const fetched: MfeManifest = await AssetLoaderService.fetchMfeManifest(MICROAPP_URL);

    expect(fetched.appName).toBe("microApp");
    expect(global.fetch).toHaveBeenCalledWith(`${MICROAPP_URL}asset-manifest.json`, { cache: "no-store" });
  });
});

describe("fetchMfeEnvConfig", () => {
  it("reads the microapp's own env-config", async () => {
    respondWith({
      ok: true,
      contentType: "application/json",
      body: '{"BACKEND_URL":"https://micro-pod-api.example/v1/api"}'
    });

    const env = await AssetLoaderService.fetchMfeEnvConfig(MICROAPP_URL);

    expect(env?.BACKEND_URL).toBe("https://micro-pod-api.example/v1/api");
    expect(global.fetch).toHaveBeenCalledWith(`${MICROAPP_URL}env-config.json`, { cache: "no-store" });
  });

  // nginx's `try_files $uri $uri/ /index.html` turns a missing file into a 200
  // serving the SPA shell. Treating that as config would silently produce an
  // env-config with no BACKEND_URL and mask the real "deployment predates the
  // file" case.
  it("rejects the SPA shell that a missing file falls through to", async () => {
    respondWith({ ok: true, contentType: "text/html", body: "<!doctype html><html></html>" });
    await expect(AssetLoaderService.fetchMfeEnvConfig(MICROAPP_URL)).resolves.toBeUndefined();
  });

  it("rejects a JSON body that is not an object", async () => {
    respondWith({ ok: true, contentType: "application/json", body: '["BACKEND_URL"]' });
    await expect(AssetLoaderService.fetchMfeEnvConfig(MICROAPP_URL)).resolves.toBeUndefined();
  });

  it("rejects malformed JSON", async () => {
    respondWith({ ok: true, contentType: "application/json", body: "{not json" });
    await expect(AssetLoaderService.fetchMfeEnvConfig(MICROAPP_URL)).resolves.toBeUndefined();
  });

  it("resolves undefined for a deployment that publishes no env-config", async () => {
    respondWith({ ok: false });
    await expect(AssetLoaderService.fetchMfeEnvConfig(MICROAPP_URL)).resolves.toBeUndefined();
  });

  it("resolves undefined when the request fails outright", async () => {
    global.fetch = jest.fn().mockRejectedValue(new Error("network down")) as unknown as typeof fetch;
    await expect(AssetLoaderService.fetchMfeEnvConfig(MICROAPP_URL)).resolves.toBeUndefined();
  });

  it("caches the negative result instead of refetching", async () => {
    respondWith({ ok: false });

    await AssetLoaderService.fetchMfeEnvConfig(MICROAPP_URL);
    await AssetLoaderService.fetchMfeEnvConfig(MICROAPP_URL);

    expect(global.fetch).toHaveBeenCalledTimes(1);
  });
});

describe("registerMfeApp", () => {
  it("registers the manifest together with the microapp's own env-config", async () => {
    respondWith({
      ok: true,
      contentType: "application/json",
      body: '{"BACKEND_URL":"https://micro-pod-api.example/v1/api"}'
    });

    await AssetLoaderService.registerMfeApp(MICROAPP_URL, manifest);

    const apps: KuikaMfeAppEntry[] = registeredApps();
    expect(apps).toHaveLength(1);
    expect(apps[0].appConfig?.frontEndUrl).toBe(MICROAPP_URL);
    expect(apps[0].manifest?.appName).toBe("microApp");
    expect(apps[0].envConfig?.BACKEND_URL).toBe("https://micro-pod-api.example/v1/api");
  });

  it("updates the existing entry instead of duplicating it", async () => {
    respondWith({ ok: false });

    await AssetLoaderService.registerMfeApp(MICROAPP_URL, manifest);
    await AssetLoaderService.registerMfeApp(MICROAPP_URL, {
      ...manifest,
      backendUrlOverride: "https://redeployed-api.example/v1/api"
    });

    const apps: KuikaMfeAppEntry[] = registeredApps();
    expect(apps).toHaveLength(1);
    expect(apps[0].manifest?.backendUrlOverride).toBe("https://redeployed-api.example/v1/api");
  });
});

describe("loadMfeApp ordering", () => {
  // The microapp resolves its own backend URL out of window.kuika.apps as its
  // scripts execute — anything reading GetBackendUrl() at module-init time reads
  // it in the same tick. Registering after injection left that window open and
  // the microapp fell back to the host's configuration.
  it("registers the app in window.kuika.apps BEFORE injecting its bundles", async () => {
    const order: string[] = [];

    jest.spyOn(AssetLoaderService, "fetchMfeManifest").mockResolvedValue(manifest);
    jest.spyOn(AssetLoaderService, "fetchMfeEnvConfig").mockImplementation(async () => {
      order.push("env-config");
      return { BACKEND_URL: "https://micro-pod-api.example/v1/api" };
    });
    jest.spyOn(AssetLoaderService, "loadMfeAssets").mockImplementation(async () => {
      order.push("assets");
      // Whatever the microapp's bundle reads at module init must already be here.
      expect(registeredApps()[0]?.envConfig?.BACKEND_URL).toBe("https://micro-pod-api.example/v1/api");
    });

    await AssetLoaderService.loadMfeApp(MICROAPP_URL);

    expect(order).toEqual(["env-config", "assets"]);
    jest.restoreAllMocks();
  });
});
