/**
 * Tests for crypto-compat-service: verify the Web Crypto path and the
 * node-forge fallback path produce interchangeable ciphertexts and identical
 * deterministic outputs (PBKDF2 / SHA-256), so generated apps deployed over
 * HTTP keep working without breaking entries written under HTTPS.
 */

// jsdom 22 ships TextEncoder/TextDecoder, but older jsdom builds don't —
// pull the Node polyfills into the global so test code can use them directly.
import { TextEncoder as NodeTextEncoder, TextDecoder as NodeTextDecoder } from "util";
if (typeof (globalThis as { TextEncoder?: unknown }).TextEncoder === "undefined") {
  (globalThis as unknown as { TextEncoder: typeof NodeTextEncoder }).TextEncoder = NodeTextEncoder;
}
if (typeof (globalThis as { TextDecoder?: unknown }).TextDecoder === "undefined") {
  (globalThis as unknown as { TextDecoder: typeof NodeTextDecoder }).TextDecoder = NodeTextDecoder;
}

// jsdom does not expose crypto.subtle. Polyfill from Node's webcrypto
// implementation so the Web Crypto path is testable side-by-side with the
// node-forge fallback.
if (typeof globalThis.crypto === "undefined" || typeof globalThis.crypto.subtle === "undefined") {
  // eslint-disable-next-line @typescript-eslint/no-var-requires
  const { webcrypto } = require("node:crypto");
  Object.defineProperty(globalThis, "crypto", {
    value: webcrypto,
    configurable: true
  });
}

const FIXED_SALT = new Uint8Array([1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16]);
const FIXED_KEY = new Uint8Array(32).map((_, i) => (i * 7) & 0xff);
const FIXED_IV = new Uint8Array([0xa1, 0xa2, 0xa3, 0xa4, 0xa5, 0xa6, 0xa7, 0xa8, 0xa9, 0xaa, 0xab, 0xac]);

function loadCompat(opts: { withSubtle: boolean }) {
  let mod: typeof import("../crypto-compat-service");
  jest.isolateModules(() => {
    if (!opts.withSubtle) {
      const original = globalThis.crypto;
      const stub = {
        getRandomValues: original.getRandomValues.bind(original),
        randomUUID: original.randomUUID?.bind(original)
      };
      Object.defineProperty(globalThis, "crypto", {
        value: stub,
        configurable: true
      });
      mod = require("../crypto-compat-service");
      Object.defineProperty(globalThis, "crypto", {
        value: original,
        configurable: true
      });
    } else {
      mod = require("../crypto-compat-service");
    }
  });
  return mod!;
}

describe("crypto-compat-service", () => {
  describe("with Web Crypto available", () => {
    const { cryptoCompat } = loadCompat({ withSubtle: true });

    it("reports Web Crypto as available", () => {
      expect(cryptoCompat.isWebCryptoAvailable()).toBe(true);
    });

    it("AES-GCM encrypt/decrypt round-trip", async () => {
      const plaintext = new TextEncoder().encode("hello kuika");
      const ct = await cryptoCompat.aesGcmEncrypt(FIXED_KEY, FIXED_IV, plaintext);
      expect(ct.length).toBe(plaintext.length + 16); // ciphertext || 16-byte GCM tag
      const pt = await cryptoCompat.aesGcmDecrypt(FIXED_KEY, FIXED_IV, ct);
      expect(new TextDecoder().decode(pt)).toBe("hello kuika");
    });

    it("randomUUID returns a v4-shaped UUID", () => {
      const u = cryptoCompat.randomUUID();
      expect(u).toMatch(/^[0-9a-f]{8}-[0-9a-f]{4}-4[0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/);
    });
  });

  describe("with Web Crypto unavailable (node-forge fallback)", () => {
    const { cryptoCompat } = loadCompat({ withSubtle: false });

    it("reports Web Crypto as unavailable", () => {
      expect(cryptoCompat.isWebCryptoAvailable()).toBe(false);
    });

    it("AES-GCM encrypt/decrypt round-trip", async () => {
      const plaintext = new TextEncoder().encode("kuika http path");
      const ct = await cryptoCompat.aesGcmEncrypt(FIXED_KEY, FIXED_IV, plaintext);
      expect(ct.length).toBe(plaintext.length + 16);
      const pt = await cryptoCompat.aesGcmDecrypt(FIXED_KEY, FIXED_IV, ct);
      expect(new TextDecoder().decode(pt)).toBe("kuika http path");
    });

    it("randomUUID returns a v4-shaped UUID", () => {
      const u = cryptoCompat.randomUUID();
      expect(u).toMatch(/^[0-9a-f]{8}-[0-9a-f]{4}-4[0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/);
    });
  });

  describe("cross-compat between Web Crypto and node-forge", () => {
    const subtle = loadCompat({ withSubtle: true }).cryptoCompat;
    const fallback = loadCompat({ withSubtle: false }).cryptoCompat;

    it("SHA-256 is identical across paths", async () => {
      const a = await subtle.sha256Hex("kuika sample");
      const b = await fallback.sha256Hex("kuika sample");
      expect(a).toBe(b);
      expect(a).toMatch(/^[0-9a-f]{64}$/);
    });

    it("PBKDF2-SHA256 is identical across paths", async () => {
      const passwd = new TextEncoder().encode("p4ssw0rd");
      const a = await subtle.pbkdf2Sha256(passwd, FIXED_SALT, 1000, 32);
      const b = await fallback.pbkdf2Sha256(passwd, FIXED_SALT, 1000, 32);
      expect(Buffer.from(a).toString("hex")).toBe(Buffer.from(b).toString("hex"));
    });

    it("Web-Crypto-encrypted ciphertext decrypts under fallback", async () => {
      const plaintext = new TextEncoder().encode("interop A → B");
      const ct = await subtle.aesGcmEncrypt(FIXED_KEY, FIXED_IV, plaintext);
      const pt = await fallback.aesGcmDecrypt(FIXED_KEY, FIXED_IV, ct);
      expect(new TextDecoder().decode(pt)).toBe("interop A → B");
    });

    it("fallback-encrypted ciphertext decrypts under Web Crypto", async () => {
      const plaintext = new TextEncoder().encode("interop B → A");
      const ct = await fallback.aesGcmEncrypt(FIXED_KEY, FIXED_IV, plaintext);
      const pt = await subtle.aesGcmDecrypt(FIXED_KEY, FIXED_IV, ct);
      expect(new TextDecoder().decode(pt)).toBe("interop B → A");
    });

    it("AES-GCM auth tag rejects tampered ciphertext", async () => {
      const plaintext = new TextEncoder().encode("integrity check");
      const ct = await fallback.aesGcmEncrypt(FIXED_KEY, FIXED_IV, plaintext);
      ct[0] ^= 0x01;
      await expect(fallback.aesGcmDecrypt(FIXED_KEY, FIXED_IV, ct)).rejects.toThrow();
    });
  });
});
