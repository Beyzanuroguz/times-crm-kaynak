import Axios from "axios";
import OfflineSyncService from "../offline-sync-service";

// Mock KuikaAppManager
jest.mock("../../shared/utilty/kuika-app-manager", () => ({
  KuikaAppManager: {
    GetBackendUrl: jest.fn(() => "http://localhost:3000")
  }
}));

// Mock electron-bridge-service
jest.mock("../electron-bridge-service", () => ({
  isElectron: jest.fn(() => false),
  isCustomProtocol: jest.fn(() => false),
  transformUrlForElectron: jest.fn((url) => url)
}));

// Mock KuikaCoreWasmBridgeService
const mockWasmService = {
  initialize: jest.fn(),
  ensureDbInitialized: jest.fn(),
  Db_Initialize: jest.fn(),
  Db_IsInitialized: jest.fn(),
  Db_GetPendingChanges: jest.fn(),
  Db_MarkAsSynced: jest.fn(),
  Db_ExportDatabaseBase64: jest.fn(),
  Db_ImportDatabaseBase64: jest.fn(),
  Db_Close: jest.fn(),
  Db_GetOfflineTableSettings: jest.fn(),
  Db_GetUnsentRecordsBase64: jest.fn(),
  Db_MarkAsSyncedWithCriteria: jest.fn(),
  Db_MarkPayloadAsSynced: jest.fn(),
  Db_ImportDatabaseBase64WithReset: jest.fn(),
  Db_ImportDatabaseBytesWithReset: jest.fn(),
  Db_UpdateDeviceMetadata: jest.fn(),
  Db_GetDeviceMetadata: jest.fn(),
  hasDurablePersistence: jest.fn(),
  supportsStreamingImport: jest.fn(),
  importStreamBegin: jest.fn(),
  importStreamChunk: jest.fn(),
  importStreamEnd: jest.fn(),
  purgeDurableStore: jest.fn()
};

jest.mock("../kuika-core-wasm-bridge-service", () => ({
  __esModule: true,
  default: {
    getInstance: jest.fn(() => mockWasmService)
  }
}));

// Mock OfflineDbPersistenceService
const mockPersistenceService = {
  initialize: jest.fn(),
  saveDatabase: jest.fn(),
  loadDatabase: jest.fn(),
  deleteDatabase: jest.fn()
};

jest.mock("../offline-db-persistence-service", () => ({
  __esModule: true,
  default: {
    getInstance: jest.fn(() => mockPersistenceService)
  }
}));

// Mock Axios
jest.mock("axios");
const mockAxios = Axios as jest.Mocked<typeof Axios>;

// Mock window.location
const mockLocation = {
  origin: "http://localhost:3000"
};
Object.defineProperty(window, "location", {
  value: mockLocation,
  writable: true
});

describe("OfflineSyncService", () => {
  let service: OfflineSyncService;

  beforeEach(() => {
    jest.clearAllMocks();

    // Reset singleton
    (OfflineSyncService as any).instance = null;
    service = OfflineSyncService.getInstance();

    // Default mock implementations
    mockWasmService.initialize.mockResolvedValue(undefined);
    mockWasmService.ensureDbInitialized.mockResolvedValue(undefined);
    mockWasmService.Db_IsInitialized.mockResolvedValue(true);
    mockWasmService.Db_GetPendingChanges.mockResolvedValue("{}");
    mockWasmService.Db_ExportDatabaseBase64.mockResolvedValue("SGVsbG8gV29ybGQ=");
    mockWasmService.Db_GetUnsentRecordsBase64.mockResolvedValue("SGVsbG8gV29ybGQ=");
    mockWasmService.Db_MarkAsSyncedWithCriteria.mockResolvedValue(undefined);
    mockWasmService.Db_MarkPayloadAsSynced.mockResolvedValue(undefined);
    mockWasmService.Db_ImportDatabaseBase64WithReset.mockResolvedValue(undefined);
    mockWasmService.Db_ImportDatabaseBytesWithReset.mockResolvedValue(undefined);
    mockWasmService.Db_UpdateDeviceMetadata.mockResolvedValue(undefined);
    // Default to the IndexedDB-fallback path (no durable store) so existing base64-mirror
    // assertions hold; durable-path tests override this to true.
    mockWasmService.hasDurablePersistence.mockReturnValue(false);
    // Default to the non-streaming (byte import) path so fetch tests exercise the Axios byte fetch.
    mockWasmService.supportsStreamingImport.mockReturnValue(false);
    mockWasmService.importStreamBegin.mockResolvedValue(undefined);
    mockWasmService.importStreamChunk.mockResolvedValue(undefined);
    mockWasmService.importStreamEnd.mockResolvedValue(undefined);
    mockWasmService.purgeDurableStore.mockResolvedValue(undefined);
    mockPersistenceService.initialize.mockResolvedValue(undefined);
    mockPersistenceService.saveDatabase.mockResolvedValue(undefined);
  });

  describe("getInstance", () => {
    it("should return the same instance when called multiple times", () => {
      const instance1 = OfflineSyncService.getInstance();
      const instance2 = OfflineSyncService.getInstance();

      expect(instance1).toBe(instance2);
    });
  });

  describe("getIsSyncing", () => {
    it("should return false initially", () => {
      expect(service.getIsSyncing()).toBe(false);
    });
  });

  describe("sync", () => {
    it("should return error if already syncing", async () => {
      // Start a sync that will take some time
      mockWasmService.initialize.mockImplementation(() => new Promise((resolve) => setTimeout(resolve, 100)));

      const syncPromise1 = service.sync();
      const result2 = await service.sync();

      expect(result2.success).toBe(false);
      expect(result2.error).toBe("Sync already in progress");

      await syncPromise1;
    });

    it("should initialize database if not initialized", async () => {
      mockWasmService.Db_IsInitialized.mockResolvedValue(false);
      mockAxios.get.mockResolvedValue({ data: { content: "dGVzdA==" } });

      await service.sync({ forceFetch: true });

      expect(mockWasmService.ensureDbInitialized).toHaveBeenCalled();
    });

    it("should push changes when pending changes exist", async () => {
      mockWasmService.Db_GetPendingChanges.mockResolvedValue(
        JSON.stringify({
          Orders: [{ Id: "order-1" }, { Id: "order-2" }]
        })
      );
      mockAxios.post.mockResolvedValue({ data: {} });

      const result = await service.sync();

      expect(result.success).toBe(true);
      expect(result.pushedChanges).toBe(true);
      expect(mockAxios.post).toHaveBeenCalledWith(
        expect.stringContaining("/offlinedb/pushOfflineDb"),
        expect.objectContaining({ content: expect.any(String) })
      );
    });

    it("should mark synced exactly the pushed payload, not a DB re-scan", async () => {
      mockWasmService.Db_GetPendingChanges.mockResolvedValue(
        JSON.stringify({
          Orders: [{ Id: "order-1" }],
          Customers: [{ Id: "customer-1" }]
        })
      );
      mockWasmService.Db_GetUnsentRecordsBase64.mockResolvedValue("UFVTSEVELVBBWUxPQUQ=");
      mockAxios.post.mockResolvedValue({ data: {} });

      await service.sync();

      // The synced-mark must be scoped to the exact bytes that were POSTed.
      // A criteria-based re-scan would also mark rows added during the push
      // network window — never sent, silently lost on next fetch.
      expect(mockWasmService.Db_MarkPayloadAsSynced).toHaveBeenCalledWith("UFVTSEVELVBBWUxPQUQ=");
      expect(mockWasmService.Db_MarkAsSyncedWithCriteria).not.toHaveBeenCalled();
    });

    it("should fetch data when forceFetch is true", async () => {
      // Binary fetch transport: the endpoint streams raw SQLite bytes (ArrayBuffer), not base64 JSON.
      mockAxios.get.mockResolvedValue({ data: Uint8Array.from([102, 101, 116, 99, 104]).buffer });

      const result = await service.sync({ forceFetch: true });

      expect(result.success).toBe(true);
      expect(result.fetchedData).toBe(true);
      // Service imports the downloaded bytes directly (no base64 string on the client).
      expect(mockWasmService.Db_ImportDatabaseBytesWithReset).toHaveBeenCalled();
    });

    it("should persist database after sync", async () => {
      mockAxios.get.mockResolvedValue({ data: Uint8Array.from([116, 101, 115, 116]).buffer });

      await service.sync({ forceFetch: true });

      expect(mockPersistenceService.saveDatabase).toHaveBeenCalledWith("SGVsbG8gV29ybGQ=");
    });

    it("should NOT export a base64 mirror after sync when storage is durable (OPFS/native)", async () => {
      mockWasmService.hasDurablePersistence.mockReturnValue(true);
      mockAxios.get.mockResolvedValue({ data: Uint8Array.from([116, 101, 115, 116]).buffer });

      const result = await service.sync({ forceFetch: true });

      expect(result.success).toBe(true);
      // The import already persisted the DB to OPFS; no whole-DB base64 export/save (the OOM path).
      expect(mockWasmService.Db_ExportDatabaseBase64).not.toHaveBeenCalled();
      expect(mockPersistenceService.saveDatabase).not.toHaveBeenCalled();
    });

    it("should handle sync errors gracefully", async () => {
      mockWasmService.initialize.mockRejectedValue(new Error("WASM init failed"));

      const result = await service.sync();

      expect(result.success).toBe(false);
      expect(result.error).toBe("WASM init failed");
    });
  });

  describe("pushChanges", () => {
    it("should push database to server via Axios", async () => {
      mockAxios.post.mockResolvedValue({ data: {} });

      const result = await service.pushChanges();

      expect(result.success).toBe(true);
      expect(mockAxios.post).toHaveBeenCalledWith("http://localhost:3000/offlinedb/pushOfflineDb", {
        content: "SGVsbG8gV29ybGQ="
      });
    });

    it("should use configured backend URL from KuikaAppManager", async () => {
      mockAxios.post.mockResolvedValue({ data: {} });

      await service.pushChanges({});

      expect(mockAxios.post).toHaveBeenCalledWith("http://localhost:3000/offlinedb/pushOfflineDb", expect.any(Object));
    });

    it("should handle push failure", async () => {
      mockAxios.post.mockRejectedValue(new Error("Request failed with status code 500"));

      const result = await service.pushChanges();

      expect(result.success).toBe(false);
      expect(result.error).toContain("500");
    });

    it("should handle network errors", async () => {
      mockAxios.post.mockRejectedValue(new Error("Network error"));

      const result = await service.pushChanges();

      expect(result.success).toBe(false);
      expect(result.error).toBe("Network error");
    });
  });

  describe("fetchData", () => {
    it("should fetch database from server via Axios as binary", async () => {
      const buffer = Uint8Array.from([102, 101, 116, 99, 104]).buffer;
      mockAxios.get.mockResolvedValue({ data: buffer });

      const result = await service.fetchData();

      expect(result.success).toBe(true);
      expect(result.data).toBeInstanceOf(Uint8Array);
      expect(result.data && Array.from(result.data)).toEqual(Array.from(new Uint8Array(buffer)));
      // Downloaded as an ArrayBuffer (binary transport), not a base64 JSON envelope.
      expect(mockAxios.get).toHaveBeenCalledWith("http://localhost:3000/offlinedb/fetchOfflineDb", {
        responseType: "arraybuffer"
      });
    });

    it("should handle empty response", async () => {
      mockAxios.get.mockResolvedValue({ data: new ArrayBuffer(0) });

      const result = await service.fetchData();

      expect(result.success).toBe(false);
      expect(result.error).toBe("No data returned from server");
    });

    it("should handle fetch failure", async () => {
      mockAxios.get.mockRejectedValue(new Error("Request failed with status code 404"));

      const result = await service.fetchData();

      expect(result.success).toBe(false);
      expect(result.error).toContain("404");
    });
  });

  describe("fetchAndImport (streaming)", () => {
    it("chunks the fetched bytes into OPFS when streaming is supported", async () => {
      mockWasmService.supportsStreamingImport.mockReturnValue(true);
      // fetchData uses the (proven, authed) Axios byte fetch; streaming then chunks those bytes.
      mockAxios.get.mockResolvedValue({ data: Uint8Array.from([1, 2, 3, 4, 5]).buffer });

      const result = await service.fetchAndImport();

      expect(result).toBe(true);
      expect(mockWasmService.importStreamBegin).toHaveBeenCalledTimes(1);
      // 5 bytes fits in one 8 MB chunk.
      expect(mockWasmService.importStreamChunk).toHaveBeenCalledTimes(1);
      expect(mockWasmService.importStreamEnd).toHaveBeenCalledTimes(1);
      // The streaming path must NOT materialize a full byte[] import through WASM.
      expect(mockWasmService.Db_ImportDatabaseBytesWithReset).not.toHaveBeenCalled();
    });
  });

  describe("initializeFromStorage", () => {
    it("should import database from storage", async () => {
      mockPersistenceService.loadDatabase.mockResolvedValue("c3RvcmVkLWRhdGE=");

      const result = await service.initializeFromStorage();

      expect(result).toBe(true);
      expect(mockWasmService.initialize).toHaveBeenCalled();
      expect(mockPersistenceService.initialize).toHaveBeenCalled();
      expect(mockWasmService.Db_ImportDatabaseBase64).toHaveBeenCalledWith("c3RvcmVkLWRhdGE=");
    });

    it("should return false if no persisted database", async () => {
      mockPersistenceService.loadDatabase.mockResolvedValue(null);

      const result = await service.initializeFromStorage();

      expect(result).toBe(false);
      expect(mockWasmService.Db_ImportDatabaseBase64).not.toHaveBeenCalled();
    });

    it("should open the durable store directly without reading the IndexedDB mirror", async () => {
      mockWasmService.hasDurablePersistence.mockReturnValue(true);
      mockWasmService.Db_IsInitialized.mockResolvedValue(true);
      mockWasmService.Db_Initialize.mockResolvedValue(undefined);

      const result = await service.initializeFromStorage();

      expect(result).toBe(true);
      // OPFS/native file is opened directly; the IndexedDB base64 mirror is never read/imported.
      expect(mockWasmService.Db_Initialize).toHaveBeenCalled();
      expect(mockPersistenceService.loadDatabase).not.toHaveBeenCalled();
      expect(mockWasmService.Db_ImportDatabaseBase64).not.toHaveBeenCalled();
    });

    it("should handle initialization errors", async () => {
      mockWasmService.initialize.mockRejectedValue(new Error("Init failed"));

      const result = await service.initializeFromStorage();

      expect(result).toBe(false);
    });
  });

  describe("persistToStorage", () => {
    it("should export and save database", async () => {
      const result = await service.persistToStorage();

      expect(result).toBe(true);
      expect(mockWasmService.Db_ExportDatabaseBase64).toHaveBeenCalled();
      expect(mockPersistenceService.saveDatabase).toHaveBeenCalledWith("SGVsbG8gV29ybGQ=");
    });

    it("should return true if database not initialized", async () => {
      mockWasmService.Db_IsInitialized.mockResolvedValue(false);

      const result = await service.persistToStorage();

      expect(result).toBe(true);
      expect(mockWasmService.Db_ExportDatabaseBase64).not.toHaveBeenCalled();
    });

    it("should skip the base64 mirror when storage is durable (OPFS/native)", async () => {
      mockWasmService.hasDurablePersistence.mockReturnValue(true);

      const result = await service.persistToStorage();

      expect(result).toBe(true);
      // Durable store persists the DB itself — no whole-DB base64 export (the OOM path we removed).
      expect(mockWasmService.Db_ExportDatabaseBase64).not.toHaveBeenCalled();
      expect(mockPersistenceService.saveDatabase).not.toHaveBeenCalled();
    });

    it("should handle persist errors", async () => {
      mockPersistenceService.saveDatabase.mockRejectedValue(new Error("Save failed"));

      const result = await service.persistToStorage();

      expect(result).toBe(false);
    });
  });

  describe("hasPendingChanges", () => {
    it("should return true when pending changes exist", async () => {
      mockWasmService.Db_GetPendingChanges.mockResolvedValue(JSON.stringify({ Orders: [{ Id: "1" }] }));

      const result = await service.hasPendingChanges();

      expect(result).toBe(true);
    });

    it("should return false when no pending changes", async () => {
      mockWasmService.Db_GetPendingChanges.mockResolvedValue("{}");

      const result = await service.hasPendingChanges();

      expect(result).toBe(false);
    });

    it("should return false if database not initialized", async () => {
      mockWasmService.Db_IsInitialized.mockResolvedValue(false);

      const result = await service.hasPendingChanges();

      expect(result).toBe(false);
    });

    it("should handle errors gracefully", async () => {
      mockWasmService.Db_GetPendingChanges.mockRejectedValue(new Error("Failed"));

      const result = await service.hasPendingChanges();

      expect(result).toBe(false);
    });
  });

  describe("deleteOfflineDatabase", () => {
    it("should purge the durable store and delete the IndexedDB mirror", async () => {
      await service.deleteOfflineDatabase();

      expect(mockWasmService.purgeDurableStore).toHaveBeenCalled();
      expect(mockPersistenceService.deleteDatabase).toHaveBeenCalled();
    });

    it("should throw if purging the durable store fails", async () => {
      mockWasmService.purgeDurableStore.mockRejectedValue(new Error("Purge failed"));

      await expect(service.deleteOfflineDatabase()).rejects.toThrow("Purge failed");
      expect(mockPersistenceService.deleteDatabase).not.toHaveBeenCalled();
    });

    it("should throw on IndexedDB delete errors", async () => {
      mockPersistenceService.deleteDatabase.mockRejectedValue(new Error("Delete failed"));

      await expect(service.deleteOfflineDatabase()).rejects.toThrow("Delete failed");
    });
  });
});
