/**
 * Offline Database Persistence Service
 *
 * Handles persisting the SQLite database to storage:
 * - Browser: IndexedDB (required — WASM runs in-memory, needs persistence across page reloads)
 * - Electron: No-op (native executable uses file-based SQLite at kuika_offline.db, persists automatically)
 *
 * The database is stored as a base64-encoded string.
 */

import { isElectron } from "./electron-bridge-service";

// This service is the IndexedDB base64 FALLBACK store, used only when the engine does NOT persist
// the DB itself. Durability is decided dynamically at runtime by the WASM bridge adapter
// (`hasDurablePersistence()`): true for Electron (native file) and for the browser when the OPFS
// pool mounted; false only on the browser :memory: fallback (incognito / OPFS locked). Callers
// gate their whole-DB base64 export + these save/load calls on that flag, so on the durable path
// this service is never invoked. Electron still short-circuits here as a second guard.

// IndexedDB configuration
const INDEXEDDB_NAME = "kuika-offline-db";
const INDEXEDDB_VERSION = 1;
const INDEXEDDB_STORE = "database";
const INDEXEDDB_KEY = "sqlite-data";

/**
 * Persistence service for offline database storage.
 */
class OfflineDbPersistenceService {
  private static instance: OfflineDbPersistenceService | null = null;

  private db: IDBDatabase | null = null;

  private isInitialized = false;

  private constructor() {}

  /**
   * Get the singleton instance.
   */
  static getInstance(): OfflineDbPersistenceService {
    if (!OfflineDbPersistenceService.instance) {
      OfflineDbPersistenceService.instance = new OfflineDbPersistenceService();
    }
    return OfflineDbPersistenceService.instance;
  }

  /**
   * Initialize the persistence layer.
   */
  async initialize(): Promise<void> {
    if (this.isInitialized) return;

    if (isElectron()) {
      // Electron: native executable uses file-based SQLite; nothing to mirror.
      console.log("OfflineDbPersistenceService: Electron — native handles persistence, skipping");
    } else {
      // Browser IndexedDB fallback (only reached when OPFS is unavailable and the caller opts in).
      console.log("OfflineDbPersistenceService: Using IndexedDB storage");
      await this.initIndexedDB();
    }

    this.isInitialized = true;
  }

  /**
   * Save the database to persistent storage.
   * No-op for Electron (native persists via file-based SQLite).
   * @param base64Data Base64-encoded database content
   */
  async saveDatabase(base64Data: string): Promise<void> {
    if (!this.isInitialized) {
      await this.initialize();
    }

    if (isElectron()) {
      // Native executable persists to kuika_offline.db automatically.
      return;
    }
    await this.saveToIndexedDB(base64Data);
  }

  /**
   * Load the database from persistent storage.
   * Returns null for Electron (native loads from its own file-based SQLite).
   * @returns Base64-encoded database content, or null if not found
   */
  async loadDatabase(): Promise<string | null> {
    if (!this.isInitialized) {
      await this.initialize();
    }

    if (isElectron()) {
      // Native executable loads from kuika_offline.db automatically.
      return null;
    }
    try {
      return await this.loadFromIndexedDB();
    } catch {
      // IndexedDB store may not exist yet (fetchOfflineDb never called)
      return null;
    }
  }

  /**
   * Delete the persisted database.
   * No-op for Electron (managed by native executable).
   */
  async deleteDatabase(): Promise<void> {
    if (!this.isInitialized) {
      await this.initialize();
    }

    if (isElectron()) {
      // Native executable manages its own database file.
      return;
    }
    await this.deleteFromIndexedDB();
  }

  /**
   * Check if a persisted database exists.
   * Returns false for Electron (native manages its own persistence).
   */
  async hasPersistedDatabase(): Promise<boolean> {
    if (isElectron()) {
      return false;
    }
    const data = await this.loadDatabase();
    return data !== null && data.length > 0;
  }

  // #region IndexedDB Methods

  private async initIndexedDB(): Promise<void> {
    return new Promise((resolve, reject) => {
      const request = indexedDB.open(INDEXEDDB_NAME, INDEXEDDB_VERSION);

      request.onerror = () => {
        console.error("OfflineDbPersistenceService: IndexedDB open error", request.error);
        reject(request.error);
      };

      request.onsuccess = () => {
        this.db = request.result;
        console.log("OfflineDbPersistenceService: IndexedDB opened successfully");
        resolve();
      };

      request.onupgradeneeded = (event) => {
        const db = (event.target as IDBOpenDBRequest).result;

        // Create object store if it doesn't exist
        if (!db.objectStoreNames.contains(INDEXEDDB_STORE)) {
          db.createObjectStore(INDEXEDDB_STORE);
          console.log("OfflineDbPersistenceService: Created IndexedDB store");
        }
      };
    });
  }

  private async saveToIndexedDB(base64Data: string): Promise<void> {
    if (!this.db) {
      throw new Error("IndexedDB not initialized");
    }

    return new Promise((resolve, reject) => {
      const transaction = this.db!.transaction([INDEXEDDB_STORE], "readwrite");
      const store = transaction.objectStore(INDEXEDDB_STORE);

      const request = store.put(base64Data, INDEXEDDB_KEY);

      request.onerror = () => {
        console.error("OfflineDbPersistenceService: IndexedDB save error", request.error);
        reject(request.error);
      };

      request.onsuccess = () => {
        console.log(`OfflineDbPersistenceService: Saved database to IndexedDB (${base64Data.length} chars)`);
        resolve();
      };
    });
  }

  private async loadFromIndexedDB(): Promise<string | null> {
    if (!this.db) {
      throw new Error("IndexedDB not initialized");
    }

    return new Promise((resolve, reject) => {
      const transaction = this.db!.transaction([INDEXEDDB_STORE], "readonly");
      const store = transaction.objectStore(INDEXEDDB_STORE);

      const request = store.get(INDEXEDDB_KEY);

      request.onerror = () => {
        console.error("OfflineDbPersistenceService: IndexedDB load error", request.error);
        reject(request.error);
      };

      request.onsuccess = () => {
        const result = request.result as string | undefined;
        if (result) {
          console.log(`OfflineDbPersistenceService: Loaded database from IndexedDB (${result.length} chars)`);
        } else {
          console.log("OfflineDbPersistenceService: No database found in IndexedDB");
        }
        resolve(result || null);
      };
    });
  }

  private async deleteFromIndexedDB(): Promise<void> {
    if (!this.db) {
      throw new Error("IndexedDB not initialized");
    }

    return new Promise((resolve, reject) => {
      const transaction = this.db!.transaction([INDEXEDDB_STORE], "readwrite");
      const store = transaction.objectStore(INDEXEDDB_STORE);

      const request = store.delete(INDEXEDDB_KEY);

      request.onerror = () => {
        console.error("OfflineDbPersistenceService: IndexedDB delete error", request.error);
        reject(request.error);
      };

      request.onsuccess = () => {
        console.log("OfflineDbPersistenceService: Deleted database from IndexedDB");
        resolve();
      };
    });
  }

  // #endregion IndexedDB Methods

  // Electron does not need renderer-side persistence.
  // The native executable uses a file-based SQLite database (kuika_offline.db)
  // that persists automatically across process invocations.
}

export default OfflineDbPersistenceService;
