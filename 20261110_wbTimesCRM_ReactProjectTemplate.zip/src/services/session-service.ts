import { Guid } from "guid-typescript";
import _ from "lodash";
import { AppBootstrapper } from "../bootstrapper";
import { KuikaAppManager } from "../shared/utilty/kuika-app-manager";
import HelperService from "./helper-service";
import { UserService } from "./user-service";

const ONE_SECOND = 1000;

export enum ESessionTimeoutEventType {
  RESET_INACTIVITY_COUNTDOWN = 0,
  LOGGED_OUT = 1,
  NEW_INSTANCE_JOINED = 2
}

export interface IResetCountdownMessage {
  instance: string;
  type: ESessionTimeoutEventType;
  timestamp?: number;
  remainingTime?: number;
}

export interface ISessionServiceConstructor {
  bootstrapper: AppBootstrapper;
  inactivityThresholdAsSeconds: number;
  logoutWarningThreshold: number;
  persistSessionAcrossPageReloads: boolean;
}

class SessionService {
  private readonly bootstrapper: AppBootstrapper;

  private readonly inactivityThresholdAsSeconds: number;

  private readonly logoutWarningThresholdAsSeconds: number;

  private readonly persistSessionAcrossPageReloads: boolean;

  private readonly uniqueInstanceIdentifier: Guid = Guid.create();

  private broadcast: BroadcastChannel | null = null;

  private intervalId: number | null = null;

  private lastActivityTimestamp: number = 0;

  private warningDisplayed: boolean = false;

  private isLoggingOut: boolean = false;

  private boundHandleUserActivity: (e: Event) => void;

  private boundHandleTouchStart: (e: TouchEvent) => void;

  private boundHandleTouchMove: (e: TouchEvent) => void;

  private boundHandleTouchEnd: (e: TouchEvent) => void;

  private boundHandleBroadcastMessage: (e: MessageEvent) => void;

  private activityDebounceTimeout: number | null = null;

  private readonly ACTIVITY_DEBOUNCE_MS = 300;

  private readonly LAST_ACTIVITY_KEY = "SESSION_LAST_ACTIVITY_TIME";

  private previousLoginState: boolean = false;

  constructor(options: ISessionServiceConstructor) {
    this.bootstrapper = options.bootstrapper;
    this.inactivityThresholdAsSeconds = options.inactivityThresholdAsSeconds;
    this.logoutWarningThresholdAsSeconds = options.logoutWarningThreshold;
    this.persistSessionAcrossPageReloads = options.persistSessionAcrossPageReloads;

    this.boundHandleUserActivity = this.handleUserActivity.bind(this);
    this.boundHandleTouchStart = this.handleTouchStart.bind(this);
    this.boundHandleTouchMove = this.handleTouchMove.bind(this);
    this.boundHandleTouchEnd = this.handleTouchEnd.bind(this);
    this.boundHandleBroadcastMessage = this.handleBroadcastMessage.bind(this);

    this.previousLoginState = SessionService.getIsConsideredLoggedIn();
    this.initializeSession();
  }

  /*
   * We'll use this to check if a user is logged in based on token presence
   * */
  static getIsConsideredLoggedIn(): boolean {
    return KuikaAppManager.readLoginStateCookie("is_logged_in") === "1";
  }

  /**
   * Initialize the session state, including checking localStorage
   * for previous activity timestamp if continuing sessions across page loads
   */
  private initializeSession(): void {
    try {
      if (this.persistSessionAcrossPageReloads) {
        const storedTimestamp: string | null = localStorage.getItem(this.LAST_ACTIVITY_KEY);

        if (storedTimestamp) {
          const parsedTimestamp: number = parseInt(storedTimestamp, 10);

          if (!isNaN(parsedTimestamp) && parsedTimestamp > 0) {
            const currentTime: number = Date.now();
            const elapsedSeconds: number = (currentTime - parsedTimestamp) / 1000;

            if (elapsedSeconds >= this.inactivityThresholdAsSeconds) {
              this.logout();
              this.resetActivityTimestamp();
              return;
            }

            this.lastActivityTimestamp = parsedTimestamp;
            return;
          }
        }
      }

      this.resetActivityTimestamp();
    } catch (error) {
      console.error("Error accessing localStorage:", error);
      this.resetActivityTimestamp();
    }
  }

  /**
   * Calculate the current remaining session time in seconds
   */
  private getRemainingSessionTimeInSeconds(): number {
    const elapsedSeconds = (Date.now() - this.lastActivityTimestamp) / 1000;
    const remainingSeconds = Math.max(0, this.inactivityThresholdAsSeconds - elapsedSeconds);
    return Math.floor(remainingSeconds);
  }

  /**
   * Update the remaining session time in the bootstrapper
   */
  private updateRemainingSessionTime(): void {
    if (!SessionService.getIsConsideredLoggedIn()) {
      this.resetActivityTimestamp();
      return;
    }

    const remainingSeconds = this.getRemainingSessionTimeInSeconds();
    console.log("Session remaining time:", remainingSeconds, "seconds");

    if (this.bootstrapper?.state?.isMounted) {
      this.bootstrapper.updateRemainingSessionTime(remainingSeconds);
    }

    const shouldShowWarning =
      this.logoutWarningThresholdAsSeconds > 0 && remainingSeconds <= this.logoutWarningThresholdAsSeconds;

    if (shouldShowWarning && !this.warningDisplayed) {
      this.warningDisplayed = true;
    } else if (!shouldShowWarning && this.warningDisplayed) {
      this.warningDisplayed = false;
    }
  }

  /**
   * Reset the activity timestamp to the current time
   */
  private resetActivityTimestamp(): void {
    this.lastActivityTimestamp = Date.now();
    this.warningDisplayed = false;

    try {
      if (this.persistSessionAcrossPageReloads) {
        localStorage.setItem(this.LAST_ACTIVITY_KEY, this.lastActivityTimestamp.toString());
      } else {
        localStorage.removeItem(this.LAST_ACTIVITY_KEY);
      }
    } catch (error) {
      console.error("Error updating localStorage:", error);
    }
  }

  /**
   * Handle user activity events with debouncing
   */
  private handleUserActivity(e: Event, skipBroadcast: boolean = false): void {
    if (!SessionService.getIsConsideredLoggedIn() || this.isLoggingOut) {
      return;
    }

    if (this.warningDisplayed) {
      return;
    }

    if (this.activityDebounceTimeout !== null) {
      window.clearTimeout(this.activityDebounceTimeout);
    }

    this.activityDebounceTimeout = window.setTimeout(() => {
      this.resetActivityTimestamp();
      this.activityDebounceTimeout = null;

      if (!skipBroadcast) {
        this.broadcastMessage({
          instance: this.uniqueInstanceIdentifier.toString(),
          type: ESessionTimeoutEventType.RESET_INACTIVITY_COUNTDOWN,
          timestamp: this.lastActivityTimestamp,
          remainingTime: this.inactivityThresholdAsSeconds // Full reset so use max time
        });
      }
    }, this.ACTIVITY_DEBOUNCE_MS);
  }

  /**
   * Touch event handlers that track touch state
   */
  private handleTouchStart(e: TouchEvent): void {
    this.handleUserActivity(e);
  }

  private handleTouchMove(e: TouchEvent): void {
    this.handleUserActivity(e);
  }

  private handleTouchEnd(e: TouchEvent): void {
    this.handleUserActivity(e);
  }

  /**
   * Check session state periodically and handle timeouts
   */
  private checkSessionState(): void {
    const currentLoginState = SessionService.getIsConsideredLoggedIn();

    if (currentLoginState && !this.previousLoginState) {
      this.resetActivityTimestamp();
      this.broadcastMessage({
        instance: this.uniqueInstanceIdentifier.toString(),
        type: ESessionTimeoutEventType.RESET_INACTIVITY_COUNTDOWN,
        timestamp: this.lastActivityTimestamp,
        remainingTime: this.inactivityThresholdAsSeconds
      });
    }
    this.previousLoginState = currentLoginState;

    if (!currentLoginState || this.isLoggingOut) {
      this.updateRemainingSessionTime();
      return;
    }

    const remainingSeconds = this.getRemainingSessionTimeInSeconds();
    this.updateRemainingSessionTime(); // Update UI with actual remaining time

    if (remainingSeconds % 5 === 0) {
      this.broadcastMessage({
        instance: this.uniqueInstanceIdentifier.toString(),
        type: ESessionTimeoutEventType.RESET_INACTIVITY_COUNTDOWN,
        timestamp: this.lastActivityTimestamp,
        remainingTime: remainingSeconds
      });
    }

    if (remainingSeconds <= 0) {
      this.logout();
    }
  }

  /**
   * Handle broadcast messages from other tabs
   */
  private handleBroadcastMessage(e: MessageEvent): void {
    const message: IResetCountdownMessage = e.data;

    if (message.instance === this.uniqueInstanceIdentifier.toString()) {
      return;
    }

    switch (message.type) {
      case ESessionTimeoutEventType.NEW_INSTANCE_JOINED:
        this.broadcastMessage({
          instance: this.uniqueInstanceIdentifier.toString(),
          type: ESessionTimeoutEventType.RESET_INACTIVITY_COUNTDOWN,
          timestamp: this.lastActivityTimestamp,
          remainingTime: this.getRemainingSessionTimeInSeconds()
        });
        break;

      case ESessionTimeoutEventType.RESET_INACTIVITY_COUNTDOWN:
        if (this.warningDisplayed) {
          return;
        }

        let shouldUpdate = false;

        if (message.remainingTime !== undefined) {
          const ourRemainingTime = this.getRemainingSessionTimeInSeconds();

          if (Math.abs(ourRemainingTime - message.remainingTime) > 2) {
            const adjustedTimestamp = Date.now() - (this.inactivityThresholdAsSeconds - message.remainingTime) * 1000;
            this.lastActivityTimestamp = adjustedTimestamp;
            shouldUpdate = true;
          }
        } else if (message.timestamp && message.timestamp > this.lastActivityTimestamp) {
          this.lastActivityTimestamp = message.timestamp;
          shouldUpdate = true;
        }

        if (shouldUpdate) {
          try {
            if (this.persistSessionAcrossPageReloads) {
              localStorage.setItem(this.LAST_ACTIVITY_KEY, this.lastActivityTimestamp.toString());
            }
          } catch (error) {
            console.error("Error updating localStorage:", error);
          }
        }
        break;

      case ESessionTimeoutEventType.LOGGED_OUT:
        this.logout(false);
        break;
    }
  }

  /**
   * Broadcast a message to other tabs
   */
  private broadcastMessage(message: IResetCountdownMessage): void {
    if (this.broadcast) {
      this.broadcast.postMessage(message);
    }
  }

  /**
   * Public method to reset the session when user explicitly continues
   */
  public onClickContinue(): void {
    this.warningDisplayed = false;
    this.resetActivityTimestamp();
    this.broadcastMessage({
      instance: this.uniqueInstanceIdentifier.toString(),
      type: ESessionTimeoutEventType.RESET_INACTIVITY_COUNTDOWN,
      timestamp: this.lastActivityTimestamp,
      remainingTime: this.inactivityThresholdAsSeconds
    });
  }

  /**
   * Handle user logout, optionally broadcasting to other tabs
   */
  public async logout(broadcastToOtherTabs: boolean = true): Promise<void> {
    if (this.isLoggingOut) {
      return;
    }

    this.isLoggingOut = true;

    try {
      if (broadcastToOtherTabs) {
        this.broadcastMessage({
          instance: this.uniqueInstanceIdentifier.toString(),
          type: ESessionTimeoutEventType.LOGGED_OUT
        });

        await new Promise((resolve) => setTimeout(resolve, 50));
      }
      this.resetActivityTimestamp();
      await UserService.Logout();

      try {
        localStorage.removeItem(this.LAST_ACTIVITY_KEY);
      } catch (error) {
        console.error("Error clearing localStorage:", error);
      }

      HelperService.gotoLogin();
    } finally {
      this.isLoggingOut = false;
      this.resetActivityTimestamp();
    }
  }

  /**
   * Register all event listeners and start the session monitoring
   */
  public registerEventListeners(): void {
    this.destroyEventListeners();

    document.addEventListener("mousemove", this.boundHandleUserActivity);
    document.addEventListener("focus", this.boundHandleUserActivity);
    document.addEventListener("keypress", this.boundHandleUserActivity);
    document.addEventListener("touchstart", this.boundHandleTouchStart);
    document.addEventListener("touchmove", this.boundHandleTouchMove);
    document.addEventListener("touchend", this.boundHandleTouchEnd);
    window.addEventListener("scroll", this.boundHandleUserActivity);

    this.intervalId = window.setInterval(() => {
      this.checkSessionState();
    }, ONE_SECOND);

    if (typeof BroadcastChannel !== "undefined") {
      try {
        this.broadcast = new BroadcastChannel("session-channel");
        this.broadcast.addEventListener("message", this.boundHandleBroadcastMessage);

        this.broadcastMessage({
          instance: this.uniqueInstanceIdentifier.toString(),
          type: ESessionTimeoutEventType.NEW_INSTANCE_JOINED
        });
      } catch (error) {
        console.error("Error setting up BroadcastChannel:", error);
        this.broadcast = null;
      }
    }

    this.updateRemainingSessionTime();
  }

  /**
   * Remove all event listeners and clean up resources
   */
  public destroyEventListeners(): void {
    document.removeEventListener("mousemove", this.boundHandleUserActivity);
    document.removeEventListener("focus", this.boundHandleUserActivity);
    document.removeEventListener("keypress", this.boundHandleUserActivity);
    document.removeEventListener("touchstart", this.boundHandleTouchStart);
    document.removeEventListener("touchmove", this.boundHandleTouchMove);
    document.removeEventListener("touchend", this.boundHandleTouchEnd);
    window.removeEventListener("scroll", this.boundHandleUserActivity);

    if (this.intervalId !== null) {
      window.clearInterval(this.intervalId);
      this.intervalId = null;
    }

    if (this.activityDebounceTimeout !== null) {
      window.clearTimeout(this.activityDebounceTimeout);
      this.activityDebounceTimeout = null;
    }

    if (this.broadcast) {
      this.broadcast.removeEventListener("message", this.boundHandleBroadcastMessage);
      this.broadcast.close();
      this.broadcast = null;
    }
  }

  public onClickLogout(broadcast: boolean = true): Promise<void> {
    return this.logout(broadcast);
  }
}

export default SessionService;
