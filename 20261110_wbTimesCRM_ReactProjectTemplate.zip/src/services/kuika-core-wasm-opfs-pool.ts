/**
 * sahpool-style OPFS backend for the .NET (emscripten) classic FS running inside the WASM worker.
 *
 * Pre-opens a POOL of OPFS synchronous access handles ONCE (async), then maps SQLite's logical
 * files (the DB + its "-journal"/"-wal"/temp files, created synchronously mid-transaction) onto
 * free pool slots. This supports full-durability journal modes (DELETE/TRUNCATE) — chosen over
 * journal_mode=MEMORY so a crash mid-transaction still leaves a consistent DB.
 *
 * Header-free: OPFS sync access handles are worker-only + synchronous, so no pthreads /
 * SharedArrayBuffer / COOP-COEP are needed. This backend moves ONLY raw file bytes at byte
 * offsets — it never sees SQL.
 *
 * Physical file layout: [HEADER_SIZE header][data...]. The header records {inUse, logicalName,
 * logicalSize}, so the logical→physical mapping is rebuilt from disk on reload.
 *
 * Empirically validated in the Phase 0/2 spike (browser, header-free): 435 MB DB → 34 MB heap;
 * real rollback journal; persistence across worker restart. See docs plan.
 */

/** Minimal shape of the OPFS FileSystemSyncAccessHandle we rely on (worker-only, synchronous). */
interface OpfsSyncAccessHandle {
  read(buffer: Uint8Array, options: { at: number }): number;
  write(buffer: Uint8Array, options: { at: number }): number;
  getSize(): number;
  truncate(newSize: number): void;
  flush(): void;
  close(): void;
}

/** Minimal emscripten node shape we attach behavior to. */
interface EmscriptenNode {
  id: number;
  mode: number;
  node_ops: EmscriptenNodeOps;
  stream_ops?: EmscriptenStreamOps;
  slotIdx?: number;
}

interface EmscriptenStream {
  node: EmscriptenNode;
  position: number;
}

interface EmscriptenStat {
  dev: number;
  ino: number;
  mode: number;
  nlink: number;
  uid: number;
  gid: number;
  rdev: number;
  size: number;
  atime: Date;
  mtime: Date;
  ctime: Date;
  blksize: number;
  blocks: number;
}

interface EmscriptenSetattr {
  size?: number;
}

interface EmscriptenNodeOps {
  getattr(node: EmscriptenNode): EmscriptenStat;
  setattr(node: EmscriptenNode, attr: EmscriptenSetattr): void;
  lookup?(parent: EmscriptenNode, name: string): EmscriptenNode;
  mknod?(parent: EmscriptenNode, name: string, mode: number, dev: number): EmscriptenNode;
  unlink?(parent: EmscriptenNode, name: string): void;
  rename?(oldNode: EmscriptenNode, newDir: EmscriptenNode, newName: string): void;
  readdir?(node: EmscriptenNode): string[];
}

interface EmscriptenStreamOps {
  read(stream: EmscriptenStream, buffer: Uint8Array, offset: number, length: number, position: number): number;
  write(stream: EmscriptenStream, buffer: Uint8Array, offset: number, length: number, position: number): number;
  llseek(stream: EmscriptenStream, offset: number, whence: number): number;
  flush?(stream: EmscriptenStream): void;
}

interface EmscriptenFileSystemType {
  mount(mount: unknown): EmscriptenNode;
  createNode(parent: EmscriptenNode | null, name: string, mode: number, dev: number): EmscriptenNode;
}

/** The subset of emscripten `Module.FS` we use. */
export interface EmscriptenFS {
  mkdir(path: string): void;
  mount(type: EmscriptenFileSystemType, opts: unknown, mountpoint: string): void;
  unmount(mountpoint: string): void;
  createNode(parent: EmscriptenNode | null, name: string, mode: number, dev: number): EmscriptenNode;
  isDir(mode: number): boolean;
  ErrnoError: new (errno: number) => Error;
}

interface PoolSlot {
  handle: OpfsSyncAccessHandle;
  inUse: boolean;
  name: string;
  size: number;
}

export interface OpfsHandlePool {
  slots: PoolSlot[];
  nameToSlot: Map<string, number>;
  writeHeader(idx: number): void;
  acquire(name: string): number;
  release(name: string): void;
  /** Start a fresh write for a logical file (acquire + truncate to empty). For streaming import. */
  beginWrite(name: string): void;
  /** Write a chunk at a logical byte offset (header-relative handled internally). No full buffer. */
  writeChunk(name: string, offset: number, chunk: Uint8Array): void;
  /** Finalize a streamed write (persist size header + flush). */
  endWrite(name: string): void;
  /**
   * Close every slot's OPFS sync access handle, releasing the per-origin exclusive locks. Call this
   * before removing the pool directory (removeOpfsPoolDir) — OPFS refuses to delete a file that
   * still has an open sync access handle. The pool is unusable afterwards; re-init to use it again.
   */
  closeAll(): void;
}

/** OPFS pool directory name (per-origin). Owned here so the worker and the bridge adapter agree. */
export const OPFS_POOL_DIR = ".kuika-opfs";

const HEADER_SIZE = 512;
const FLAG_OFFSET = 0;
const SIZE_OFFSET = 4;
const NAMELEN_OFFSET = 8;
const NAME_OFFSET = 16;

interface OpfsDirectoryHandle {
  getDirectoryHandle(name: string, options: { create: boolean }): Promise<OpfsDirectoryHandle>;
  getFileHandle(name: string, options: { create: boolean }): Promise<OpfsFileHandle>;
  removeEntry(name: string, options: { recursive: boolean }): Promise<void>;
}

interface OpfsFileHandle {
  createSyncAccessHandle(): Promise<OpfsSyncAccessHandle>;
}

interface StorageManagerWithOpfs {
  getDirectory(): Promise<OpfsDirectoryHandle>;
}

/** Open (or create) the pool and rebuild the logical→slot map from on-disk headers. Async, once. */
export async function initPool(dirName: string, poolSize: number): Promise<OpfsHandlePool> {
  const storage: StorageManagerWithOpfs = navigator.storage as unknown as StorageManagerWithOpfs;
  const root: OpfsDirectoryHandle = await storage.getDirectory();
  const dir: OpfsDirectoryHandle = await root.getDirectoryHandle(dirName, { create: true });
  const slots: PoolSlot[] = [];
  const nameToSlot: Map<string, number> = new Map();
  const encoder: TextEncoder = new TextEncoder();
  const decoder: TextDecoder = new TextDecoder();

  for (let i = 0; i < poolSize; i++) {
    const fileHandle: OpfsFileHandle = await dir.getFileHandle(`kpool_${i}`, { create: true });
    const handle: OpfsSyncAccessHandle = await fileHandle.createSyncAccessHandle();
    const header: Uint8Array = new Uint8Array(HEADER_SIZE);
    if (handle.getSize() >= HEADER_SIZE) {
      handle.read(header, { at: 0 });
    }
    const view: DataView = new DataView(header.buffer);
    const inUse: boolean = header[FLAG_OFFSET] === 1;
    const size: number = view.getUint32(SIZE_OFFSET, true);
    const nameLen: number = view.getUint16(NAMELEN_OFFSET, true);
    const name: string =
      inUse && nameLen > 0 ? decoder.decode(header.subarray(NAME_OFFSET, NAME_OFFSET + nameLen)) : "";
    slots.push({ handle, inUse, name, size });
    if (inUse && name) {
      nameToSlot.set(name, i);
    }
  }

  const writeHeader = (idx: number): void => {
    const slot: PoolSlot = slots[idx];
    const header: Uint8Array = new Uint8Array(HEADER_SIZE);
    const view: DataView = new DataView(header.buffer);
    header[FLAG_OFFSET] = slot.inUse ? 1 : 0;
    view.setUint32(SIZE_OFFSET, slot.size >>> 0, true);
    const nameBytes: Uint8Array = encoder.encode(slot.name);
    view.setUint16(NAMELEN_OFFSET, nameBytes.length, true);
    header.set(nameBytes.subarray(0, HEADER_SIZE - NAME_OFFSET), NAME_OFFSET);
    slot.handle.write(header, { at: 0 });
  };

  const acquire = (name: string): number => {
    const existing: number | undefined = nameToSlot.get(name);
    if (existing !== undefined) {
      return existing;
    }
    const idx: number = slots.findIndex((s: PoolSlot): boolean => !s.inUse);
    if (idx < 0) {
      throw new Error("OPFS pool exhausted (increase poolSize)");
    }
    const slot: PoolSlot = slots[idx];
    slot.inUse = true;
    slot.name = name;
    slot.size = 0;
    slot.handle.truncate(HEADER_SIZE);
    writeHeader(idx);
    nameToSlot.set(name, idx);
    return idx;
  };

  const release = (name: string): void => {
    const idx: number | undefined = nameToSlot.get(name);
    if (idx === undefined) {
      return;
    }
    const slot: PoolSlot = slots[idx];
    slot.inUse = false;
    slot.name = "";
    slot.size = 0;
    slot.handle.truncate(HEADER_SIZE);
    writeHeader(idx);
    nameToSlot.delete(name);
  };

  const beginWrite = (name: string): void => {
    const idx: number = acquire(name);
    const slot: PoolSlot = slots[idx];
    slot.handle.truncate(HEADER_SIZE);
    slot.size = 0;
    writeHeader(idx);
  };

  const writeChunk = (name: string, offset: number, chunk: Uint8Array): void => {
    const idx: number | undefined = nameToSlot.get(name);
    if (idx === undefined) {
      throw new Error(`OPFS pool: writeChunk for unknown file "${name}"`);
    }
    const slot: PoolSlot = slots[idx];
    slot.handle.write(chunk, { at: HEADER_SIZE + offset });
    const end: number = offset + chunk.byteLength;
    if (end > slot.size) {
      slot.size = end;
    }
  };

  const endWrite = (name: string): void => {
    const idx: number | undefined = nameToSlot.get(name);
    if (idx === undefined) {
      return;
    }
    writeHeader(idx);
    slots[idx].handle.flush();
  };

  const closeAll = (): void => {
    for (const slot of slots) {
      try {
        slot.handle.close();
      } catch {
        /* best-effort: a handle may already be closed */
      }
    }
    nameToSlot.clear();
  };

  return { slots, nameToSlot, writeHeader, acquire, release, beginWrite, writeChunk, endWrite, closeAll };
}

/**
 * Remove the entire OPFS pool directory (all `kpool_*` files) for this origin. The caller MUST have
 * closed the pool's sync access handles first (see {@link OpfsHandlePool.closeAll}) — OPFS refuses
 * to remove a file that still has an open sync access handle (`NoModificationAllowedError`).
 * Rejects if the directory does not exist; callers that treat "already gone" as success should
 * catch. Works on both the main thread and inside a worker (both expose `navigator.storage`).
 */
export async function removeOpfsPoolDir(dirName: string): Promise<void> {
  const storage: StorageManagerWithOpfs = navigator.storage as unknown as StorageManagerWithOpfs;
  const root: OpfsDirectoryHandle = await storage.getDirectory();
  await root.removeEntry(dirName, { recursive: true });
}

/**
 * Mount the pool at `mountDir` in the given emscripten FS. Logical files under it are backed by
 * pool slots, acquired on create and released on delete.
 */
export function mountPool(fs: EmscriptenFS, mountDir: string, pool: OpfsHandlePool): void {
  const ENOENT = 44;
  const EINVAL = 28;

  const buildStat = (node: EmscriptenNode, mode: number, size: number): EmscriptenStat => {
    const now: Date = new Date();
    return {
      dev: 1,
      ino: node.id,
      mode,
      nlink: 1,
      uid: 0,
      gid: 0,
      rdev: 0,
      size,
      atime: now,
      mtime: now,
      ctime: now,
      blksize: 4096,
      blocks: Math.ceil(size / 4096)
    };
  };

  const streamOps: EmscriptenStreamOps = {
    read(stream: EmscriptenStream, buffer: Uint8Array, offset: number, length: number, position: number): number {
      const slot: PoolSlot = pool.slots[stream.node.slotIdx as number];
      return slot.handle.read(buffer.subarray(offset, offset + length), { at: HEADER_SIZE + position });
    },
    write(stream: EmscriptenStream, buffer: Uint8Array, offset: number, length: number, position: number): number {
      const idx: number = stream.node.slotIdx as number;
      const slot: PoolSlot = pool.slots[idx];
      const written: number = slot.handle.write(buffer.subarray(offset, offset + length), {
        at: HEADER_SIZE + position
      });
      const end: number = position + written;
      if (end > slot.size) {
        slot.size = end;
        pool.writeHeader(idx);
      }
      return written;
    },
    llseek(stream: EmscriptenStream, offset: number, whence: number): number {
      let pos: number = offset;
      if (whence === 1) {
        pos += stream.position;
      } else if (whence === 2) {
        pos += pool.slots[stream.node.slotIdx as number].size;
      }
      if (pos < 0) {
        throw new fs.ErrnoError(EINVAL);
      }
      return pos;
    },
    flush(stream: EmscriptenStream): void {
      try {
        pool.slots[stream.node.slotIdx as number].handle.flush();
      } catch {
        /* best-effort durability */
      }
    }
  };

  const fileNodeOps: EmscriptenNodeOps = {
    getattr(node: EmscriptenNode): EmscriptenStat {
      return buildStat(node, 0o100000 | 0o666, pool.slots[node.slotIdx as number].size);
    },
    setattr(node: EmscriptenNode, attr: EmscriptenSetattr): void {
      if (attr.size !== undefined) {
        const idx: number = node.slotIdx as number;
        const slot: PoolSlot = pool.slots[idx];
        slot.handle.truncate(HEADER_SIZE + attr.size);
        slot.size = attr.size;
        pool.writeHeader(idx);
      }
    }
  };

  const makeFileNode = (parent: EmscriptenNode, name: string, mode: number, slotIdx: number): EmscriptenNode => {
    const node: EmscriptenNode = poolFs.createNode(parent, name, mode, 0);
    node.slotIdx = slotIdx;
    return node;
  };

  const dirNodeOps: EmscriptenNodeOps = {
    getattr(node: EmscriptenNode): EmscriptenStat {
      return buildStat(node, 0o040000 | 0o777, 4096);
    },
    setattr(): void {},
    lookup(parent: EmscriptenNode, name: string): EmscriptenNode {
      const idx: number | undefined = pool.nameToSlot.get(name);
      if (idx === undefined) {
        throw new fs.ErrnoError(ENOENT);
      }
      return makeFileNode(parent, name, 0o100000 | 0o666, idx);
    },
    mknod(parent: EmscriptenNode, name: string, mode: number): EmscriptenNode {
      return makeFileNode(parent, name, mode, pool.acquire(name));
    },
    unlink(_parent: EmscriptenNode, name: string): void {
      pool.release(name);
    },
    rename(): void {
      throw new fs.ErrnoError(EINVAL);
    },
    readdir(): string[] {
      return [".", "..", ...pool.nameToSlot.keys()];
    }
  };

  const poolFs: EmscriptenFileSystemType = {
    mount(): EmscriptenNode {
      return poolFs.createNode(null, "/", 0o040000 | 0o777, 0);
    },
    createNode(parent: EmscriptenNode | null, name: string, mode: number, dev: number): EmscriptenNode {
      const node: EmscriptenNode = fs.createNode(parent, name, mode, dev);
      node.node_ops = fs.isDir(node.mode) ? dirNodeOps : fileNodeOps;
      if (!fs.isDir(node.mode)) {
        node.stream_ops = streamOps;
      }
      return node;
    }
  };

  // Idempotent: on a post-wipe remount the mountpoint node already exists (unmount detaches the
  // filesystem but leaves the directory), so a second mkdir would throw EEXIST.
  try {
    fs.mkdir(mountDir);
  } catch {
    /* mountpoint already exists (remount) */
  }
  fs.mount(poolFs, {}, mountDir);
}
