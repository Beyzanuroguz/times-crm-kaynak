export enum ELanguage {
  EN = "en_US",
  FR = "fr_FR",
  TR = "tr_TR"
}
