export enum Visibility {
  Visible = 1,
  Hidden = 2
}
