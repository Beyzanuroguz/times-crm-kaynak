export enum LeftPanelType {
  None = 0,
  Component = 1,
  DisplayItemTree = 2,
  Screens = 3,
  Code = 4,
  Datasources = 5,
  ComponentTree = 6,
  CodeTree = 7,
  ImageLibrary = 8
}

export enum RightPanelType {
  None = 0,
  Properties = 1,
  Styling = 2,
  Documents = 3,
  Comments = 4,
  History = 5
}
