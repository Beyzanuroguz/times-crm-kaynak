export enum EDatasourceType {
  ManagedDb = 0,
  CustomDb = 1,
  RestApi = 2,
  CSharpFunctions = 3,
  SystemCSFunctions = 4,
  SystemJSFunctions = 5
}

export enum ECardinality {
  One,
  Cardinality
}

export enum EStatementTypes {
  None = -1,
  CustomExecuteReader = 0,
  CustomExecuteNonQuery = 1,
  Save = 2,
  Delete = 3,
  Select = 5
}
