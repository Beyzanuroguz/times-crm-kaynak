export enum CommentMode {
  SelectedDisplayItem = 1,
  Screen = 2,
  All = 3
}
