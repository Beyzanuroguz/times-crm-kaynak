export enum StylingMode {
  Default = 1,
  Screen = 2
}
