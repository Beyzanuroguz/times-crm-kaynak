export interface IUpdateUserStartingScreen {
  userName: string;
  startingScreenId: string;
}
