export interface IStripeSettings {
  publishKey: string;
  secretKey: string;
  webhookSecret: string;
}
