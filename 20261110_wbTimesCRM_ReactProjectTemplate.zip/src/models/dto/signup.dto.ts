export interface ISignupDto {
  username: string;
  password: string;
  firstName: string;
  lastName: string;
  VerifyEMailAddress: boolean;
  dontSendEmail?: boolean;
  phoneNumber?: string;
}
