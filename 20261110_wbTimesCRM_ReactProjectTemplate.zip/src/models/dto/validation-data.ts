export interface IValidationData {
  isValid: boolean;
  condition: boolean;
  message: string;
  formName: string;
}
