export interface IUpdateUsernameDto {
  userName: string;
  newUserName: string;
  dontSendEmail?: boolean;
}
