export interface IMqttResult {
  isSuccess: boolean;
  message: string;
}
