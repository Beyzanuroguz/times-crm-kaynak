export interface ICreateUserWithPasswordDto {
  username: string;
  password: string;
  firstName: string;
  lastName: string;
  dontSendEmail?: boolean;
  phoneNumber?: string;
}
