export interface IResetPasswordWithTokenDto {
  newPassword: string;
  token: string;
  UserName: string;
  dontSendEmail: boolean;
  language: string;
}
