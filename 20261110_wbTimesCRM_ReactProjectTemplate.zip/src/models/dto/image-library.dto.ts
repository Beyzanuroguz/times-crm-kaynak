export enum EResourceTypes {
  UNKNOWN = 0,
  JPG = 1,
  PNG = 2,
  SVG = 3,
  JSON = 4
}

export interface IImageLibraryDto {
  id: string;
  fileName: string;
  resourceType: EResourceTypes;
  content: string;
}
