export interface IChangePasswordDto {
  currentpassword: string;
  newpassword: string;
  newpasswordConfirm: string;
  dontSendEmail?: boolean;
}
