export interface IRestResult {
  content: string;
  isAttachment: boolean;
  fileName: string;
  mimeType: string;
}
