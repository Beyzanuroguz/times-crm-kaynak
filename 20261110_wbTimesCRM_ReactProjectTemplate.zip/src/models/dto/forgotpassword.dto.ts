export interface IForgotPasswordDto {
  email: string;
  dontSendEmail?: boolean;
  language?: string;
}
