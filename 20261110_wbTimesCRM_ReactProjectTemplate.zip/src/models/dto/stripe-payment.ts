export interface IStripePayment {
  clientSecret: string;
  stripeCustomerId: string;
  ephemeralSecret: string;
}

export interface IStripeSetupIntent {
  clientSecret: string;
}
