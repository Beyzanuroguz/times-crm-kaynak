export interface IImportMappedExcelParameter {
  id: string;
  name: string;
  type: string;
  value?: any;
}

export interface IImportMappedExcelColumnMapDefinition {
  isEnabled: boolean;
  source: string;
  alias: string;
  primaryKey: string | null;
  defaultValue?: string | null;
}

export interface IImportMappedExcelColumnMap extends IImportMappedExcelColumnMapDefinition {
  target?: string;
}

export interface IImportMappedExcelRequest {
  datasourceId: string;
  tableName: string;
  primaryKey: string;
  mappedColumns: IImportMappedExcelColumnMap[];
  columns: string[];
  data: object[];
  language: string;
  parameters?: IImportMappedExcelParameter[];
}

export interface IImportMappedExcelFileRequest {
  datasourceId: string;
  tableName: string;
  primaryKey: string;
  mappedColumns: IImportMappedExcelColumnMap[];
  sheetName: string;
  fileBase64: string;
  language: string;
  parameters?: IImportMappedExcelParameter[];
}

export interface IExcelFileMetadataRequest {
  fileBase64: string;
  sheetName?: string;
}

export interface IExcelFileMetadataResponse {
  sheetNames: string[];
  columns: string[];
}

export enum ImportMappedExcelStatus {
  Success,
  Error,
  PartialSuccess,
  Queued
}

export interface IImportMappedExcelResponse {
  status: ImportMappedExcelStatus;
  errorCount: number;
  successCount: number;
  totalCount: number;
  rowsInserted: number;
  rowsUpdated: number;
  erroredRows: object[];
  rowsWithValidationErrors: object[];
}
