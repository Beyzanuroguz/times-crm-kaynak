export interface IUserDto {
  id: string;
  roleIds: string[];
  lastName: string;
  firstName: string;
  username: string;
  domainId: string;
}
