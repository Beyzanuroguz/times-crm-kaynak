enum EAuthenticationType {
  MailAuthentication = 0,
  AuthenticatorApp = 1,
  NoTwoFactorAuthentication = 2
}

export interface IChangeTwoFactorAuthenticationType {
  authenticationType: EAuthenticationType;
}
