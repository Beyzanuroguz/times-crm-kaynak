import { EApplicationType } from "./save-application-request.dto";

export interface IApplicationInfo {
  id: string;
  projectId: string;
  applicationType: EApplicationType;
  baseUrl: string;
  pingUrl: string;
  description: string;
  createAt: Date;
  updateAt: Date;
  roleIds: string[];
}
