export interface IResetPasswordDto {
  newPassword: string;
  token: string;
}
