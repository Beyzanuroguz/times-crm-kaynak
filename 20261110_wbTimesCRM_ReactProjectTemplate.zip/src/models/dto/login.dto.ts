import { CheckResultType } from "../enum/auth";

export interface ILoginDto {
  username: string;
  password: string;
}

export interface IReLoginWithDelegationDto {
  ToUserName: string;
}

export interface IExternalTokenRequest {
  providerType: EExternalTokenProviderTypes;
  username: string;
  tokenString: string;
  refreshToken: string;
  redirectUri?: string;
  claims?: Record<string, string>;
  externalParameters?: Record<string, string>;
}

export interface IIssueMfeTokenResponse {
  token: string;
}

/**
 * Mirrors Kuika.Common.Enums.EExternalTokenProviderTypes. The numeric values are
 * the wire format for /auth/loginwithtoken — they must stay identical to the C#
 * enum and must never be renumbered.
 *
 * External1..External5 are the customer-implemented slots: a
 * CustomExternalTokenValidatorProvider datasource generates an
 * IExternalTokenValidator whose TokenProviderType is one of these, and the
 * backend routes matching requests to it.
 */
export enum EExternalTokenProviderTypes {
  None = 0,
  AzureAD = 1,
  Google = 2,
  Apple = 3,
  Facebook = 4,
  External1 = 5,
  External2 = 6,
  External3 = 7,
  External4 = 8,
  External5 = 9
}

export interface ICheckResult {
  resultType: CheckResultType;
  message: string;
}

export interface ILoginResponse {
  /** UUID */
  id: string;
  username: string;
  firstName: string;
  lastName: string;
  tokenString: string;
  refreshToken: string;
  language: string | null;
  forceResetPassword: boolean;
  passwordValidationResult?: {
    checkResults: ICheckResult[];
    hasWarnings: boolean;
    hasErrors: boolean;
    errors: string;
    warnings: string;
  };
}
