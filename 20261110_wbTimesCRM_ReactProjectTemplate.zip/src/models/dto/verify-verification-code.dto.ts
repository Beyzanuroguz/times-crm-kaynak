export interface IVerifyVerificationCodeDto {
  username: string;
  verificationCode: string;
}
