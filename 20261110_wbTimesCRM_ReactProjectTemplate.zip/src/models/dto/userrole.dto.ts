export interface IUserRoleDto {
  userName: string;
  roleName: string;
}
