export interface IStripePaymentDto {
  amount: string;
  currency: string;
  description: string;
  applicationFee?: string;
  ConnectedAccount?: string;
  captureMethod?: string;
  supportedPaymentTypes?: string;
}

export interface IStripeRefundDto {
  paymentIntent: string;
  reason: string;
  amount: string;
}

export interface IStripeCaptureDto {
  paymentIntent: string;
  amount: string;
}

export interface IStripeUpdateCustomerDto {
  email: string;
  name: string;
  phone: string;
  description: string;
}
export interface IStripeChargePaymentMethodDto {
  paymentmethod: string;
  currency: string;
  amount: string;
  stripeCustomerId: string;
  description: string;
  paymenttype: string;
  feeamount: string;
  destination: string;
}
export interface IStripeDeletePaymentMethodDto {
  paymentmethod: string;
}
export interface IStripeConnectedAccountDto {
  connectedAccount: string;
}
export interface IStripeConnectedAccountOnboardingDto {
  connectedAccount: string;
  returnLocation: string;
}

export interface IStripeCreateConnectedAccountDto {
  type: string;
  country: string;
  email: string;
}

export interface IStripeConnectedAccountWithdraw {
  amount: string;
  connectedAccount: string;
  currency: string;
}

export interface IStripeConnectedAccountPayout {
  amount: string;
  connectedAccount: string;
  currency: string;
}
export interface IStripeCancelPaymentDto {
  paymentIntent: string;
}

export interface IStripeListCustomerPaymentMethodsByIdDto {
  stripeCustomerId: string;
}
