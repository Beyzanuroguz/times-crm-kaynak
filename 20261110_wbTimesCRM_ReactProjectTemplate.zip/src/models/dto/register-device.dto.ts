export interface IRegisterDeviceDto {
  deviceId: string;
  registrationId: string;
  appBundleId: string;
  userName: string;
  deviceType: number;
  publicKey?: string;
}
