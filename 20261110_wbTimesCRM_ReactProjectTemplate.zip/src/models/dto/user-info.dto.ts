export interface IUserInfoDto {
  id: string;
  firstName: string;
  lastName: string;
  username: string;
  roles: RoleItem[];
}

export interface RoleItem {
  id: string;
  name: string;
}
