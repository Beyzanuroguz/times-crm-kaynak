export interface ICreateUserDto {
  username: string;
  firstName: string;
  lastName: string;
  dontSendEmail?: boolean;
  phoneNumber?: string;
  roleNames?: string;
}
