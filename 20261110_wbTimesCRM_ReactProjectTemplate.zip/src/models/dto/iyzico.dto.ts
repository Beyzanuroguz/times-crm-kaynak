export interface IIyzicoCheckoutFormDto {
  userName: string;
  pricingPlanReferenceCode: string;
  address: IIyzicoAddressDto;
  phoneNumber: string;
  identityNumber: string;
}

export interface IIyzicoAddressDto {
  address1: string;
  address2: string;
  city: string;
  country: string;
  zipCode: string;
  contactName: string;
}

export interface IIyzicoCheckoutFormResponseDto {
  checkoutFormContent: string;
  conversationId: string;
  errorMessage: string;
  locale: string;
  status: string;
  statusCode: number;
  systemTime: number;
  token: string;
  tokenExpireTime: number;
}
