import { Space } from "antd/es";
import { Guid } from "guid-typescript";
import _ from "lodash";
import React, { PureComponent, ReactNode } from "react";
import isEqual from "react-fast-compare";
import { CommonProps } from "../../components/web-components/common-props";
import withCommonEvents from "../../shared/hoc/with-common-events";
import DynamicStyleManager from "../../shared/utilty/dynamic-style-manager";

interface SpacerProps {
  children?: ReactNode;
  style: any;
  size?: number | string;
  direction: string;
}

interface SpacerState {}

class Spacer extends PureComponent<SpacerProps & CommonProps, SpacerState> {
  private uniqueKey = Guid.create();

  private style = new DynamicStyleManager(`spacer_${this.uniqueKey}`);

  constructor(props: SpacerProps) {
    super(props);
    this.state = {};
  }

  componentDidMount() {
    this.setDynamicStyle();
  }

  componentDidUpdate(prevProps: SpacerProps) {
    if (!isEqual(prevProps, this.props)) {
      this.setDynamicStyle();
    }
  }

  componentWillUnmount() {
    this.style.removeStyle();
  }

  getProps = () => {
    const props: any = _.clone(this.props);
    if (props.children) {
      delete props.children;
    }
    if (props.style) {
      delete props.style;
    }
    if (props.size < 0) props.size = 0;
    return props;
  };

  getStyleProp = () => {
    let style: any = {};

    if (this.props.style) {
      style = _.clone(this.props.style);
    }
    style.height = "100%";
    style.width = this.props.children ? "max-content" : "100%";
    return style;
  };

  setDynamicStyle = () => {
    this.style.setDynamicCss(this.getDynamicCss());
  };

  getDynamicCss = (): string => {
    const className: string = this.getClassName();
    if (!className || className.length === 0) {
      return "";
    }
    let result = "";

    const { size }: any = this.props;
    if (size && size < 0) {
      if (this.props.direction === "vertical") {
        result += `.${className.trim()}>.ant-space-item:not(:first-of-type) {
          margin-top: ${size}px !important;
        }`;
      } else {
        result += `.${className.trim()}>.ant-space-item:not(:first-of-type) {
          margin-left: ${size}px !important;
        }`;
      }
    }
    return result;
  };

  getClassName = () => {
    let result = "";
    if (this.props.className) {
      result = this.props.className;
    }
    if (!this.uniqueKey) {
      return result;
    }
    result = `${result} kspace_${this.uniqueKey.toString().substring(0, 8)}`;
    return result;
  };

  render(): ReactNode {
    return (
      <>
        <Space className={this.getClassName()} style={this.getStyleProp()} {...this.getProps()}>
          {React.Children.map(this.props.children, (child: any) => {
            if (child?.props?.visibility === "hidden" || child?.props?.children?.props?.visibility === "hidden") {
              return null;
            }
            return <>{child}</>;
          })}
        </Space>
      </>
    );
  }
}

const spacer = withCommonEvents(Spacer);
export { spacer as Spacer };
