// Activates the global `AMap` namespace (and `window.AMap`) declared by
// @amap/amap-jsapi-types. The package augments the global scope from inside a
// module, so a single reference here makes the AMap JSAPI types available across
// the app without adding it to compilerOptions.types (which would disable the
// automatic inclusion of every other @types package).
/// <reference types="@amap/amap-jsapi-types" />

// World Map (世界地图) / multilingual map (多语言地图) options of JSAPI 2.0 are not declared by
// @amap/amap-jsapi-types 0.0.15. This is a script file, so the namespace merges into the global
// `AMap` the package declares. Values are built by shared/utilty/amap-language.ts.
declare namespace AMap {
  interface MapOptions {
    /** Render tiles outside mainland China. Needs the World Map entitlement on the key. */
    showOversea?: boolean;
    /** Base-map label language: zh (default), zh-Hant, en, es, pt, fr, de, th, ja, ko, ar, tr, it, ru, ms, id, vi. */
    languageCode?: string;
    /** Amap logo language: zh (default) or en. */
    logoLanguage?: string;
  }
}
