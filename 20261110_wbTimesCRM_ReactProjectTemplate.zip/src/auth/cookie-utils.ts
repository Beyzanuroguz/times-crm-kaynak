export function getCookie(name: string): string | null {
  const match = document.cookie.match(new RegExp(`(?:^|;\\s*)${name}=([^;]*)`));
  return match ? decodeURIComponent(match[1]) : null;
}

export function setCookie(name: string, value: string, maxAgeSeconds: number): void {
  const secure = window.location.protocol === "https:" ? "; Secure" : "";
  document.cookie = `${name}=${encodeURIComponent(value)}; path=/; SameSite=Lax; max-age=${maxAgeSeconds}${secure}`;
}

export function deleteCookie(name: string): void {
  const secure = window.location.protocol === "https:" ? "; Secure" : "";
  document.cookie = `${name}=; expires=Thu, 01 Jan 1970 00:00:00 GMT; path=/; SameSite=Lax${secure}`;
}

// Login-state cookies (is_logged_in / session_id) are scoped per app by NAME, the
// same way the CSRF mirror is (see getApiHostKey below): the cookie name is
// suffixed with the app's API host so that on a frontend host shared across apps
// one app's logout doesn't wipe another's login state. Path stays "/" because the
// browser only exposes a cookie to a page whose URL path is under the cookie's
// path — so the path attribute can only carry the frontend pathname, which is the
// screen name on a root-served app and changes with navigation. The API host is
// stable per app regardless of navigation, so it goes in the NAME, not the path.
// The caller passes the key (see KuikaAppManager.getLoginStateCookieKey) — this
// file stays a pure document.cookie primitive with no app-manager dependency.
function loginStateCookieName(baseName: string, key: string): string {
  return key ? `${baseName}__${key}` : baseName;
}

// Reads this app's scoped cookie, falling back to the legacy bare cookie written
// before per-app scoping so an active session isn't logged out on deploy. Once a
// scoped cookie exists for this app it takes precedence; the bare one is cleared
// on the next logout.
export function readLoginStateCookie(baseName: string, key: string): string | null {
  if (key) {
    const scoped: string | null = getCookie(loginStateCookieName(baseName, key));
    if (scoped !== null) return scoped;
  }
  return getCookie(baseName);
}

export function setLoginStateCookie(baseName: string, value: string, maxAgeSeconds: number, key: string): void {
  const secure: string = window.location.protocol === "https:" ? "; Secure" : "";
  document.cookie = `${loginStateCookieName(baseName, key)}=${encodeURIComponent(value)}; path=/; SameSite=Lax; max-age=${maxAgeSeconds}${secure}`;
}

export function deleteLoginStateCookie(baseName: string, key: string): void {
  const secure: string = window.location.protocol === "https:" ? "; Secure" : "";
  document.cookie = `${loginStateCookieName(baseName, key)}=; expires=Thu, 01 Jan 1970 00:00:00 GMT; path=/; SameSite=Lax${secure}`;
  // Also clear any legacy bare cookie written before per-app scoping, so a stale
  // "/" value can't keep this app looking logged in after a version upgrade. The
  // bare cookie was shared across apps, so this is the one place per-app delete is
  // intentionally broad — but it self-heals: the next login on each app mints its
  // own scoped cookie and the bare one is never written again.
  if (key) {
    document.cookie = `${baseName}=; expires=Thu, 01 Jan 1970 00:00:00 GMT; path=/; SameSite=Lax${secure}`;
  }
}

// CSRF mirror cookies are per-API-host. Each microapp API issues its own
// csrf_token cookie on its own host; the SPA can't read those cross-origin
// cookies, so the login/refresh response body echoes the value and the SPA
// writes a mirror on its own host. With multiple API hosts in play (microapp
// shell that talks to N microapp APIs), a single generic mirror name would
// be overwritten by each successive login and the next request to a
// different API would carry the wrong token — CsrfMiddleware then rejects
// with 403. Suffix the cookie name with the API host so each mirror is
// independent and the request interceptor can pick the right one per URL.
const CSRF_COOKIE_PREFIX: string = "csrf_token__";

// Extracts the stable per-app key of an API URL, shared by both the CSRF mirror
// and the login-state cookies (is_logged_in / session_id). Returns "" for a
// missing/unparseable URL, in which case callers fall back to the bare name.
//
// The key is the API host PLUS any path prefix before the /v1/api base. Most
// deployments give each app its own host (Kuika SaaS: every project gets its own
// `<ws>-<project>-api` subdomain), so the prefix is empty and the key is the bare
// host — identical to before, no regression. But custom-domain / self-hosted
// deployments path-route several app backends under ONE API host
// (https://api.example.com/v1/api for the shell, .../microappapi/v1/api for a
// microapp). There the host alone collides the shell and the microapp onto a
// single mirror / login-state cookie; since they have independent sessions, one
// value can never match both and the microapp 403s on every request. Including
// the path prefix gives each path-routed app its own key, mirroring what distinct
// subdomains do for SaaS. (Pairs with the backend setting the csrf_token cookie's
// Path to the app's PathBase so the cookie the browser attaches is per-app too.)
export function getApiHostKey(url: string | undefined): string {
  if (!url) return "";
  try {
    const host: string = new URL(url, window.location.origin).host;
    const basePath: string = getApiBasePath(url);
    // Strip "/" so the prefix is a legal cookie-name fragment (cookie names
    // can't contain "/"): "/microappapi" -> "_microappapi".
    return basePath ? `${host}${basePath.replace(/\//g, "_")}` : host;
  } catch {
    return "";
  }
}

// The path prefix before the /v1/api base of an API URL ("/microappapi" for
// https://api.example.com/microappapi/v1/api/...; "" for a root-served app like
// https://api.example.com/v1/api/...). The SPA sends this to the backend as the
// X-App-Base-Path header on each request: the backend can't see the prefix when a
// reverse proxy strips it before forwarding, so the SPA — which built the URL and
// knows the prefix — supplies it. The backend scopes the session cookies' Path to
// it (see Kuika.Common CookieTokenHelper) so a path-routed microapp's csrf_token /
// access_token don't overwrite a sibling's on the shared API host. The browser
// then attaches each app's cookie only to that app's requests (it sees the full,
// pre-strip URL path), so two path-routed apps coexist without the proxy having to
// forward the prefix as PathBase.
export function getApiBasePath(url: string | undefined): string {
  if (!url) return "";
  try {
    const parsed: URL = new URL(url, window.location.origin);
    const apiBaseIdx: number = parsed.pathname.indexOf("/v1/api");
    return apiBaseIdx > 0 ? parsed.pathname.substring(0, apiBaseIdx) : "";
  } catch {
    return "";
  }
}

export function readCsrfMirrorForUrl(url: string | undefined): string | null {
  const host: string = getApiHostKey(url);
  if (host) {
    const scoped: string | null = getCookie(`${CSRF_COOKIE_PREFIX}${host}`);
    if (scoped) return scoped;
  }
  // Pre-fix sessions still carry the legacy bare csrf_token cookie. Read
  // it as a fallback so an active session isn't stranded after deploy; the
  // next login/refresh writes a properly host-scoped mirror that then takes
  // precedence, and the bare cookie is never read again once that exists.
  return getCookie("csrf_token");
}

export function writeCsrfMirrorForUrl(url: string | undefined, value: string, maxAgeSeconds: number): void {
  const host: string = getApiHostKey(url);
  if (!host) return;
  setCookie(`${CSRF_COOKIE_PREFIX}${host}`, value, maxAgeSeconds);
}

export function deleteCsrfMirrorForUrl(url: string | undefined): void {
  // Delete ONLY this API host's mirror, not every app's. The frontend host is
  // shared across apps, so a blanket wipe of all csrf_token__* on one app's
  // logout would strip a sibling that is still logged in → it then sends no
  // X-CSRF-Token header and gets a 403. The legacy bare csrf_token is left
  // alone (shared, no longer written, and never read once a mirror exists).
  const host: string = getApiHostKey(url);
  if (host) {
    deleteCookie(`${CSRF_COOKIE_PREFIX}${host}`);
  }
}
