import { EExternalTokenProviderTypes } from "../models/dto/login.dto";

/**
 * Resolves the `external_provider_type` MFE attribute to an external token
 * provider.
 *
 * Only the customer-implemented External1..External5 slots are accepted. The
 * built-in providers (Google, AzureAD, Apple, Facebook) each have their own
 * dedicated login flow and are deliberately NOT reachable through a host-supplied
 * attribute, and `None` is rejected by the backend on the anonymous
 * /auth/loginwithtoken endpoint, so neither is a valid value here.
 *
 * The attribute is untrusted host input, so the lookup is a `Map`, not an object
 * literal: a plain object resolves inherited keys, so `"__proto__"` would return
 * `Object.prototype` and `"constructor"` a function — both non-`undefined`, both
 * passing a naive presence check and travelling on as a bogus provider type. A
 * `Map` has no prototype chain, and the result is additionally narrowed to a
 * number before it is accepted.
 */
const EXTERNAL_PROVIDER_TYPES_BY_NAME: Map<string, EExternalTokenProviderTypes> = new Map([
  ["external1", EExternalTokenProviderTypes.External1],
  ["external2", EExternalTokenProviderTypes.External2],
  ["external3", EExternalTokenProviderTypes.External3],
  ["external4", EExternalTokenProviderTypes.External4],
  ["external5", EExternalTokenProviderTypes.External5]
]);

export const EXTERNAL_PROVIDER_TYPE_NAMES: readonly string[] = [
  "External1",
  "External2",
  "External3",
  "External4",
  "External5"
];

export const parseExternalTokenProviderType = (
  value: string | null | undefined
): EExternalTokenProviderTypes | null => {
  if (typeof value !== "string") return null;
  // `toLowerCase` (not `toLocaleLowerCase`) — locale-independent, so a Turkish
  // system locale cannot turn "External1" into "externȧl1".
  const normalized: string = value.trim().toLowerCase();
  if (normalized.length === 0) return null;
  const providerType: EExternalTokenProviderTypes | undefined = EXTERNAL_PROVIDER_TYPES_BY_NAME.get(normalized);
  return typeof providerType === "number" ? providerType : null;
};
