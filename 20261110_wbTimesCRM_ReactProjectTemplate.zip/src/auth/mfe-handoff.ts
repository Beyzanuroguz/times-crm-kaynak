import { EExternalTokenProviderTypes, IExternalTokenRequest } from "../models/dto/login.dto";
import { UserService } from "../services/user-service";
import { readAuthErrorMessage } from "./auth-error-message";
import { EXTERNAL_PROVIDER_TYPE_NAMES, parseExternalTokenProviderType } from "./external-provider-type";
import { isMfeHandoffToken } from "./jwt-utils";

export interface IMfeHandoffRequest {
  accessToken: string;
  refreshToken?: string;
  username?: string;
  providerTypeName?: string;
}

export interface IMfeHandoffResult {
  succeeded: boolean;
  errorMessage: string;
}

/**
 * Single owner of the MFE credential exchange, shared by every consumer:
 * `AppBootstrapper.runMfeAuthHandoff` (which redeems before routes render) and
 * the `/login` route's `MfeLogin` screen, across any number of component
 * instances and remounts.
 *
 * It is keyed by token + provider slot and memoizes the *promise*, not the fact
 * that a call happened. Memoizing "a call happened" is subtly broken: a remount
 * while the request is in flight orphans the result (the new instance sees
 * "pending" and waits forever, the old instance's handler is cancelled), two
 * `<kuika-mfe-app>` elements on one page starve each other, and the bootstrapper
 * and the login screen each post the same token. Awaiting a shared promise gives
 * every consumer the same outcome exactly once.
 *
 * Never rejects — the outcome is the return value, so a consumer cannot forget to
 * catch. Call `forgetMfeHandoff` to allow a deliberate retry after a failure.
 */
const attempts: Map<string, Promise<IMfeHandoffResult>> = new Map();
const outcomes: Map<string, IMfeHandoffResult> = new Map();

// Length-prefixed, so no pair of (slot, token) values can be arranged to collide
// on one key. Both parts come from host-controlled attributes; a plain separator
// would let a crafted slot name borrow another token's memo entry.
const buildKey = (request: IMfeHandoffRequest): string => {
  const providerTypeName: string = request.providerTypeName ?? "";
  return `${providerTypeName.length}:${providerTypeName}:${request.accessToken}`;
};

const buildMissingProviderTypeMessage = (): string => {
  const isTurkish: boolean = localStorage.getItem("ml") === "tr_TR";
  const slots: string = EXTERNAL_PROVIDER_TYPE_NAMES.join(", ");
  if (isTurkish) {
    return `Bu token bir Kuika MFE handoff token'ı değil. Host uygulamanın external_provider_type niteliğini ${slots} değerlerinden biri olarak vermesi ve projede eşleşen bir Custom External Token Validator datasource'unun tanımlı olması gerekir.`;
  }
  return `This token is not a Kuika MFE handoff token. The host application must set the external_provider_type attribute to one of ${slots}, matching a Custom External Token Validator datasource defined in this project.`;
};

const runHandoff = async (request: IMfeHandoffRequest): Promise<IMfeHandoffResult> => {
  try {
    if (isMfeHandoffToken(request.accessToken)) {
      // Kuika host: a short-lived handoff JWT minted by /auth/issue-mfe-token.
      await UserService.LoginWithMfeToken(request.accessToken);
      return { succeeded: true, errorMessage: "" };
    }

    // Third-party host: the token belongs to the customer's own identity
    // provider, so the host must name the CustomExternalTokenValidator slot that
    // knows how to verify it. Without one the backend has no validator to route
    // to and rejects the request, so fail here with a message that says what to
    // configure rather than posting a request that can only fail.
    const providerType: EExternalTokenProviderTypes | null = parseExternalTokenProviderType(request.providerTypeName);
    if (providerType === null) {
      return { succeeded: false, errorMessage: buildMissingProviderTypeMessage() };
    }

    const externalTokenRequest: IExternalTokenRequest = {
      providerType,
      refreshToken: request.refreshToken ?? "",
      tokenString: request.accessToken,
      username: request.username ?? ""
    };
    await UserService.LoginWithExternalToken(externalTokenRequest);
    return { succeeded: true, errorMessage: "" };
  } catch (error: unknown) {
    const errorMessage: string = readAuthErrorMessage(error);
    // Log the derived message only. The axios error carries `config.data`, which
    // is the request body — including the host's raw access token.
    console.error("MFE login handoff failed:", errorMessage);
    return { succeeded: false, errorMessage };
  }
};

export const redeemMfeHandoff = (request: IMfeHandoffRequest): Promise<IMfeHandoffResult> => {
  const key: string = buildKey(request);
  const existing: Promise<IMfeHandoffResult> | undefined = attempts.get(key);
  if (existing !== undefined) return existing;

  const attempt: Promise<IMfeHandoffResult> = runHandoff(request).then((result: IMfeHandoffResult) => {
    outcomes.set(key, result);
    return result;
  });
  attempts.set(key, attempt);
  return attempt;
};

/** Settled outcome for this exact (slot, token), or null while pending / unseen. */
export const peekMfeHandoff = (request: IMfeHandoffRequest): IMfeHandoffResult | null =>
  outcomes.get(buildKey(request)) ?? null;

/** Drops the memo so the next `redeemMfeHandoff` re-posts. Used for explicit retry. */
export const forgetMfeHandoff = (request: IMfeHandoffRequest): void => {
  const key: string = buildKey(request);
  attempts.delete(key);
  outcomes.delete(key);
};

/** Test seam — module state outlives a component tree by design. */
export const resetMfeHandoffState = (): void => {
  attempts.clear();
  outcomes.clear();
};
