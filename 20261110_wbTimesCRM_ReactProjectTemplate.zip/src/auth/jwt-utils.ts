/**
 * JWT helpers used to inspect tokens received from the host shell during the
 * MFE handoff. Decoding never validates the signature — the backend re-checks
 * every token. These helpers exist only to dispatch frontend code paths.
 */

export interface IJwtPayload {
  [claim: string]: unknown;
}

export const tryDecodeJwtPayload = (token: string | null | undefined): IJwtPayload | null => {
  if (!token || typeof token !== "string") return null;
  try {
    const parts = token.split(".");
    if (parts.length !== 3) return null;
    const base64 = parts[1].replace(/-/g, "+").replace(/_/g, "/");
    const padded = base64 + "=".repeat((4 - (base64.length % 4)) % 4);
    const json = atob(padded);
    return JSON.parse(json) as IJwtPayload;
  } catch {
    return null;
  }
};

export const isMfeHandoffToken = (token: string | null | undefined): boolean => {
  const payload = tryDecodeJwtPayload(token);
  return !!payload && payload["Mfe"] === "1";
};

export const readUsernameFromJwt = (token: string | null | undefined): string | null => {
  const payload = tryDecodeJwtPayload(token);
  if (!payload) return null;
  const username = payload["UserName"];
  return typeof username === "string" && username.length > 0 ? username : null;
};
