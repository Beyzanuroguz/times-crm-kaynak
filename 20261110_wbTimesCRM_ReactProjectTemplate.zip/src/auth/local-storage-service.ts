import { ApplicationService } from "../services/application-service";
import { KuikaAppManager } from "../shared/utilty/kuika-app-manager";
import { deleteLoginStateCookie } from "./cookie-utils";

declare let window: any;

const LocalStorageService = (() => {
  let _service: any;
  function _getService(this: {
    getService: () => any;
    setToken: (tokenObj: any) => void;
    getAccessToken: () => string | null;
    getRefreshToken: () => string | null;
    clearToken: () => void;
  }) {
    if (!_service) {
      _service = this;
      return _service;
    }
    return _service;
  }
  function _setToken(tokenObj: any) {
    // Tokens are now set by the server as HttpOnly cookies.
    // No-op for token storage.
  }

  function _setVerificationStatus(status: any) {
    localStorage.setItem("isVerificationValid", status);
  }
  function _getVerificationStatus() {
    return localStorage.getItem("isVerificationValid");
  }

  function _setResetPasswordStatus(status) {
    localStorage.setItem("reset_pw_status", status);
  }

  function _getResetPasswordStatus() {
    return localStorage.getItem("reset_pw_status");
  }

  function _setLoginStatus(status: any) {
    localStorage.setItem("login_status", status);
  }
  function _getLoginStatus() {
    return localStorage.getItem("login_status");
  }
  function _setUserLanguage(tokenObj: any) {
    if (tokenObj.language) {
      localStorage.setItem("ml", tokenObj.language);
    }
  }
  function _getUserLanguage() {
    return localStorage.getItem("ml");
  }
  function _setForgotPasswordEmail(email: string) {
    localStorage.setItem("forgotPasswordEmail", email);
  }
  function _setCurrentDomain(domainName: string) {
    // localStorage.setItem("currentDomain", domainName);
    window.currentDomain = domainName;
    // window.currentDomain = "Kuika";
  }
  function _getForgotPasswordEmail() {
    return localStorage.getItem("forgotPasswordEmail");
  }
  function _getAccessToken() {
    // Cannot read HttpOnly cookie. Use KuikaAppManager.readLoginStateCookie("is_logged_in") to check login state.
    return null;
  }
  function _getRefreshToken() {
    // Cannot read HttpOnly cookie. Use KuikaAppManager.readLoginStateCookie("is_logged_in") to check login state.
    return null;
  }
  function _getCurrentDomain() {
    // window.currentDomain = "Kuika";
    // return "Kuika";
    return window.currentDomain;
    // return localStorage.getItem("currentDomain");
  }

  function _setVerificationUserName(userName) {
    localStorage.setItem("verificationUserName", userName);
  }

  function _getVerificationUserName() {
    return localStorage.getItem("verificationUserName");
  }

  function _clearSessionStorage() {
    const applications: string | null = ApplicationService.getAllApplicationsFromSessionStorageRaw();

    sessionStorage.clear();

    if (applications) {
      sessionStorage.setItem("all-applications", applications);
    }
  }

  function _clearToken() {
    // Tokens are now cleared by the server via Set-Cookie headers.
    // Clear the client-readable is_logged_in cookie.
    const loginStateKey = KuikaAppManager.getLoginStateCookieKey();
    deleteLoginStateCookie("is_logged_in", loginStateKey);
    deleteLoginStateCookie("session_id", loginStateKey);
    localStorage.removeItem("forgotPasswordEmail");
    localStorage.removeItem("verificationUserName");
    _clearSessionStorage();
  }

  return {
    getService: _getService,
    setToken: _setToken,
    setCurrentDomain: _setCurrentDomain,
    getAccessToken: _getAccessToken,
    getRefreshToken: _getRefreshToken,
    clearSessionStorage: _clearSessionStorage,
    clearToken: _clearToken,
    setForgotPasswordEmail: _setForgotPasswordEmail,
    getForgotPasswordEmail: _getForgotPasswordEmail,
    getCurrentDomain: _getCurrentDomain,
    setUserLanguage: _setUserLanguage,
    getUserLanguage: _getUserLanguage,
    setLoginStatus: _setLoginStatus,
    getLoginStatus: _getLoginStatus,
    getVerificationStatus: _getVerificationStatus,
    setVerificationStatus: _setVerificationStatus,
    setResetPasswordStatus: _setResetPasswordStatus,
    getResetPasswordStatus: _getResetPasswordStatus,
    setVerificationUserName: _setVerificationUserName,
    getVerificationUserName: _getVerificationUserName
  };
})();
export default LocalStorageService;
