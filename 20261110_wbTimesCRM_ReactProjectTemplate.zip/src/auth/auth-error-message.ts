interface IAuthErrorResponseData {
  message?: string;
}

interface IAuthErrorResponse {
  status?: number;
  data?: IAuthErrorResponseData;
}

interface IAuthError {
  message?: string;
  response?: IAuthErrorResponse;
}

const asAuthError = (error: unknown): IAuthError | null => {
  if (typeof error !== "object" || error === null) return null;
  return error as IAuthError;
};

/**
 * Derives a message a user can act on from a failed auth call.
 *
 * Backend auth failures do not always carry a body (a KException surfaces as a
 * bare 500), so falling back to the status code matters: "please wait forever"
 * with nothing on screen is the failure mode this exists to prevent.
 */
export const readAuthErrorMessage = (error: unknown): string => {
  const isTurkish: boolean = localStorage.getItem("ml") === "tr_TR";
  const authError: IAuthError | null = asAuthError(error);

  const backendMessage: string | undefined = authError?.response?.data?.message;
  if (backendMessage && backendMessage.length > 0) return backendMessage;

  const statusCode: number | undefined = authError?.response?.status;
  if (statusCode !== undefined) {
    return isTurkish
      ? `Giriş servisi ${statusCode} hatası döndü.`
      : `The login service responded with HTTP ${statusCode}.`;
  }

  const rawMessage: string | undefined = authError?.message;
  if (rawMessage && rawMessage.length > 0) return rawMessage;

  return isTurkish ? "Giriş servisine ulaşılamadı." : "The login service could not be reached.";
};
