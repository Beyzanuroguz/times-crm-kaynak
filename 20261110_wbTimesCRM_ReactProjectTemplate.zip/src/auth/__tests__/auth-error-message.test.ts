import { readAuthErrorMessage } from "../auth-error-message";

describe("readAuthErrorMessage", () => {
  afterEach(() => {
    localStorage.clear();
  });

  it("prefers the backend message when there is one", () => {
    const error = {
      message: "Request failed with status code 400",
      response: { status: 400, data: { message: "User is locked" } }
    };
    expect(readAuthErrorMessage(error)).toBe("User is locked");
  });

  it("falls back to the status code — a bare 500 must not read as silence", () => {
    const error = { message: "Request failed with status code 500", response: { status: 500, data: {} } };
    expect(readAuthErrorMessage(error)).toBe("The login service responded with HTTP 500.");
  });

  it("falls back to the raw error message when there is no response", () => {
    expect(readAuthErrorMessage(new Error("Network Error"))).toBe("Network Error");
  });

  it("always produces something for unusable errors", () => {
    expect(readAuthErrorMessage(undefined)).toBe("The login service could not be reached.");
    expect(readAuthErrorMessage(null)).toBe("The login service could not be reached.");
    expect(readAuthErrorMessage("boom")).toBe("The login service could not be reached.");
  });

  it("localizes the generated messages, but never the backend's own", () => {
    localStorage.setItem("ml", "tr_TR");
    expect(readAuthErrorMessage({ response: { status: 500 } })).toBe("Giriş servisi 500 hatası döndü.");
    expect(readAuthErrorMessage(undefined)).toBe("Giriş servisine ulaşılamadı.");
    expect(readAuthErrorMessage({ response: { status: 400, data: { message: "User is locked" } } })).toBe(
      "User is locked"
    );
  });
});
