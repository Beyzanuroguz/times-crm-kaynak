// Tests for auth/interceptors.ts. The module registers handlers as a side
// effect of import, so we mock axios.interceptors.response.use ahead of import
// and capture the registered error handler. Each test drives the captured
// handler directly with a synthetic 401 error.

interface RegisteredHandlers {
  success: ((response: unknown) => unknown) | undefined;
  error: (error: unknown) => Promise<unknown>;
}

interface RegisteredRequestHandlers {
  success: (config: unknown) => Promise<unknown> | unknown;
  error: ((error: unknown) => unknown) | undefined;
}

const responseRegistrations: RegisteredHandlers[] = [];
const requestRegistrations: RegisteredRequestHandlers[] = [];

const refreshPostMock: jest.Mock = jest.fn();
const replayPostMock: jest.Mock = jest.fn();

jest.mock("axios", () => {
  // Calling axios as a function (axios(originalRequest)) replays the request.
  const callable: jest.Mock & {
    defaults: { withCredentials: boolean };
    interceptors: { request: { use: jest.Mock }; response: { use: jest.Mock } };
    isCancel: jest.Mock;
    post: jest.Mock;
    CancelToken: { source: jest.Mock };
  } = Object.assign(
    jest.fn((config: { url?: string; data?: unknown }) => replayPostMock(config?.url ?? "", config?.data)),
    {
      defaults: { withCredentials: false },
      interceptors: {
        request: {
          use: jest.fn(
            (
              success: (config: unknown) => Promise<unknown> | unknown,
              error: ((error: unknown) => unknown) | undefined
            ) => {
              requestRegistrations.push({ success, error });
            }
          )
        },
        response: {
          use: jest.fn(
            (success: ((response: unknown) => unknown) | undefined, error: (error: unknown) => Promise<unknown>) => {
              responseRegistrations.push({ success, error });
            }
          )
        }
      },
      isCancel: jest.fn((_e: unknown) => false),
      post: refreshPostMock,
      CancelToken: { source: jest.fn(() => ({ cancel: jest.fn(), token: {} })) }
    }
  );
  return { __esModule: true, default: callable };
});

const getCookieMock: jest.Mock = jest.fn((name: string) => (name === "is_logged_in" ? "1" : null));
const readLoginStateCookieMock: jest.Mock = jest.fn((name: string) => (name === "is_logged_in" ? "1" : null));
const readCsrfMirrorForUrlMock: jest.Mock = jest.fn();
const writeCsrfMirrorForUrlMock: jest.Mock = jest.fn();
const deleteCsrfMirrorForUrlMock: jest.Mock = jest.fn();
jest.mock("../cookie-utils", () => ({
  getCookie: (name: string) => getCookieMock(name),
  deleteCookie: jest.fn(),
  setCookie: jest.fn(),
  setLoginStateCookie: jest.fn(),
  deleteLoginStateCookie: jest.fn(),
  readLoginStateCookie: (name: string) => readLoginStateCookieMock(name),
  readCsrfMirrorForUrl: (url: string | undefined) => readCsrfMirrorForUrlMock(url),
  writeCsrfMirrorForUrl: (url: string | undefined, value: string, maxAge: number) =>
    writeCsrfMirrorForUrlMock(url, value, maxAge),
  deleteCsrfMirrorForUrl: (url: string | undefined) => deleteCsrfMirrorForUrlMock(url),
  // Pure URL parsing, no document.cookie dependency — use the real extraction
  // so the X-App-Base-Path header assertions exercise the actual logic.
  getApiBasePath: (url: string | undefined): string => {
    if (!url) return "";
    try {
      const pathname: string = new URL(url, "http://spa.example.com").pathname;
      const idx: number = pathname.indexOf("/v1/api");
      return idx > 0 ? pathname.substring(0, idx) : "";
    } catch {
      return "";
    }
  }
}));

const gotoLoginMock: jest.Mock = jest.fn();
jest.mock("../../services/helper-service", () => ({
  __esModule: true,
  default: { gotoLogin: gotoLoginMock, getIsInLoginPage: jest.fn(() => false) }
}));

const getLoginStatusMock: jest.Mock = jest.fn(() => null);
jest.mock("../local-storage-service", () => ({
  __esModule: true,
  default: { getService: jest.fn(() => ({})), getLoginStatus: () => getLoginStatusMock() }
}));

jest.mock("../../shared/utilty/kuika-app-manager", () => ({
  KuikaAppManager: {
    GetBackendUrl: jest.fn(() => "http://localhost:3772"),
    getLoginStateCookieKey: jest.fn(() => "localhost:3772"),
    readLoginStateCookie: jest.fn(() => "1"),
    consumeNextRequestAudit: jest.fn(() => null)
  }
}));

jest.mock("../../shared/utilty/react-system-functions", () => ({
  ReactSystemFunctions: {
    isOnline: jest.fn(async () => true),
    markNetworkError: jest.fn(),
    markNetworkSuccess: jest.fn()
  }
}));

jest.mock("../../shared/utilty/constants", () => ({ OFFLINE_REDIRECT_CANCEL: "OFFLINE_REDIRECT_CANCEL" }));

interface FakeAxiosError {
  config: { url: string; _retry?: boolean; __retryCount?: number };
  response: { status: number };
}

const buildError = (url: string, status: number): FakeAxiosError => ({
  config: { url },
  response: { status }
});

const HANG_SENTINEL: unique symbol = Symbol("hang");

const waitForCompletion = async (promise: Promise<unknown>): Promise<unknown | typeof HANG_SENTINEL> => {
  return Promise.race([
    promise.then((value: unknown) => value).catch((err: unknown) => err),
    new Promise<typeof HANG_SENTINEL>((resolve) => setTimeout(() => resolve(HANG_SENTINEL), 250))
  ]);
};

describe("auth/interceptors — refresh failure catch handler", () => {
  let refreshHandler: (error: unknown) => Promise<unknown>;

  beforeEach(() => {
    // Reload the module fresh per test so module-level state
    // (isTokenRefreshing, failedQueue) doesn't leak across tests.
    jest.resetModules();
    responseRegistrations.length = 0;
    refreshPostMock.mockReset();
    replayPostMock.mockReset();
    gotoLoginMock.mockReset();
    getLoginStatusMock.mockReset();
    getLoginStatusMock.mockReturnValue(null);
    require("../interceptors");
    expect(responseRegistrations.length).toBeGreaterThanOrEqual(2);
    refreshHandler = responseRegistrations[1].error;
  });

  // Bug 3 — once a refresh attempt fails, the .catch block redirects to
  // login but never resets the module-level isTokenRefreshing flag (nor
  // rejects the failedQueue). Any subsequent 401 that lands before the
  // navigation completes — common in MFE hosts where gotoLogin no-ops, or
  // when the user is already on the login page — gets funnelled into a
  // queue that is never resolved or rejected. The desired behaviour: the
  // second 401 must complete (resolve or reject) instead of hanging
  // indefinitely.
  it("a 401 that arrives after a failed refresh must not hang indefinitely", async () => {
    refreshPostMock.mockRejectedValueOnce({
      response: { status: 401 },
      config: { url: "http://localhost:3772/auth/refreshtoken" }
    });

    await refreshHandler(buildError("http://localhost:3772/api/some-endpoint", 401)).catch((err: unknown) => err);
    expect(refreshPostMock).toHaveBeenCalledTimes(1);
    expect(gotoLoginMock).toHaveBeenCalled();

    // A parallel 401 (e.g. another request that was already in flight) lands.
    // Whatever the policy is — re-attempt refresh, or fail fast — the call
    // must complete in bounded time. Currently it sits in failedQueue forever.
    const secondCall: Promise<unknown> = refreshHandler(buildError("http://localhost:3772/api/some-endpoint", 401));

    const result: unknown | typeof HANG_SENTINEL = await waitForCompletion(secondCall);

    expect(result).not.toBe(HANG_SENTINEL);
  });

  // Same-shape leak as the .catch path, just via a different doorway. If
  // /auth/refreshtoken responds with anything 2xx-but-not-200 (a 204 from a
  // misbehaving proxy, a 302 from an auth gateway, etc.) the original .then
  // code only handled the status===200 success — anything else was an
  // implicit fallthrough that never drained failedQueue and never redirected
  // the user. Symptom: blank screen, sibling 401s hanging forever, no
  // /signin redirect to recover. Assert: a non-200 refresh response invokes
  // the same logout/redirect path as a thrown rejection.
  it("non-200 2xx refresh response must redirect to login (not silently fall through)", async () => {
    refreshPostMock.mockResolvedValueOnce({ status: 204, data: {} });

    await refreshHandler(buildError("http://localhost:3772/api/some-endpoint", 401)).catch((err: unknown) => err);

    expect(refreshPostMock).toHaveBeenCalledTimes(1);
    expect(gotoLoginMock).toHaveBeenCalled();

    const secondCall: Promise<unknown> = refreshHandler(buildError("http://localhost:3772/api/some-endpoint", 401));
    const result: unknown | typeof HANG_SENTINEL = await waitForCompletion(secondCall);

    expect(result).not.toBe(HANG_SENTINEL);
    expect(refreshPostMock).toHaveBeenCalledTimes(2);
  });

  it("refresh endpoint 401 must not queue behind the in-progress refresh request", async () => {
    refreshPostMock.mockImplementationOnce(() => new Promise<unknown>(() => undefined));

    const pendingRefresh: Promise<unknown> = refreshHandler(
      buildError("http://localhost:3772/api/some-endpoint", 401)
    ).catch((err: unknown) => err);
    void pendingRefresh;

    const refreshEndpointFailure: Promise<unknown> = refreshHandler(
      buildError("http://localhost:3772/auth/refreshtoken", 401)
    );
    const result: unknown | typeof HANG_SENTINEL = await waitForCompletion(refreshEndpointFailure);

    expect(result).not.toBe(HANG_SENTINEL);
  });

  // KOA-17893 — during a partial-auth sub-flow (2FA verification / account
  // activation) the backend issued only a flagged access_token and NO
  // refresh_token. A 401/403 from a background request (e.g. saveApplication)
  // must be rejected outright: attempting refresh (which 400s) then redirecting
  // bounces the user off the VerificationCode screen before they can enter the
  // emailed code, producing an infinite SignIn<->VerificationCode loop.
  it("does not refresh or redirect on a 401 while 2FA verification is pending", async () => {
    getLoginStatusMock.mockReturnValue("3"); // EAccountStatus.TwoFactorAuthentication

    const result: unknown | typeof HANG_SENTINEL = await waitForCompletion(
      refreshHandler(buildError("http://localhost:3772/v1/api/application", 401))
    );

    expect(refreshPostMock).not.toHaveBeenCalled();
    expect(gotoLoginMock).not.toHaveBeenCalled();
    expect(result).not.toBe(HANG_SENTINEL);
  });

  it("does not refresh or redirect on a CSRF 403 while 2FA verification is pending", async () => {
    getLoginStatusMock.mockReturnValue("3"); // EAccountStatus.TwoFactorAuthentication

    const result: unknown | typeof HANG_SENTINEL = await waitForCompletion(
      refreshHandler(buildError("http://localhost:3772/v1/api/application", 403))
    );

    expect(refreshPostMock).not.toHaveBeenCalled();
    expect(gotoLoginMock).not.toHaveBeenCalled();
    expect(result).not.toBe(HANG_SENTINEL);
  });

  it("does not refresh or redirect while account activation is pending", async () => {
    getLoginStatusMock.mockReturnValue("2"); // EAccountStatus.ShouldActivated

    await waitForCompletion(refreshHandler(buildError("http://localhost:3772/v1/api/application", 401)));

    expect(refreshPostMock).not.toHaveBeenCalled();
    expect(gotoLoginMock).not.toHaveBeenCalled();
  });

  it("still refreshes on a 401 once the session is fully valid (no sub-flow)", async () => {
    getLoginStatusMock.mockReturnValue("0"); // EAccountStatus.Valid
    refreshPostMock.mockResolvedValueOnce({ status: 200, data: { token: "t", csrfToken: "c" } });

    await refreshHandler(buildError("http://localhost:3772/api/some-endpoint", 401)).catch((e: unknown) => e);

    expect(refreshPostMock).toHaveBeenCalledTimes(1);
  });
});

interface FakeRequestConfig {
  headers: Record<string, unknown>;
  withCredentials?: boolean;
  url?: string;
}

describe("auth/interceptors — request CSRF header", () => {
  let requestHandler: (config: unknown) => Promise<unknown> | unknown;

  beforeEach(() => {
    jest.resetModules();
    responseRegistrations.length = 0;
    requestRegistrations.length = 0;
    refreshPostMock.mockReset();
    replayPostMock.mockReset();
    gotoLoginMock.mockReset();
    getCookieMock.mockReset();
    readLoginStateCookieMock.mockReset();
    readLoginStateCookieMock.mockImplementation((name: string) => (name === "is_logged_in" ? "1" : null));
    readCsrfMirrorForUrlMock.mockReset();
    writeCsrfMirrorForUrlMock.mockReset();
    deleteCsrfMirrorForUrlMock.mockReset();
    require("../interceptors");
    expect(requestRegistrations.length).toBeGreaterThanOrEqual(1);
    requestHandler = requestRegistrations[0].success;
  });

  // Mirror present for this request's API host → header gets echoed. This is
  // the half the SPA owns in the double-submit pattern. CsrfMiddleware on the
  // backend verifies the two halves match.
  it("attaches X-CSRF-Token header when a mirror cookie exists for the request's API host", async () => {
    readCsrfMirrorForUrlMock.mockImplementation((url: string) =>
      url === "http://api.example.com/foo" ? "abc-123" : null
    );

    const config: FakeRequestConfig = { headers: {}, url: "http://api.example.com/foo" };
    const result = (await requestHandler(config)) as FakeRequestConfig;

    expect(result.headers["X-CSRF-Token"]).toBe("abc-123");
  });

  // No CSRF mirror (anonymous session, fresh tab, or mobile/Bearer flow) →
  // omit the header. Sending an empty value would force CsrfMiddleware to
  // 403 on the very first state-changing request before refresh can heal it.
  it("omits X-CSRF-Token header when no mirror cookie exists", async () => {
    readCsrfMirrorForUrlMock.mockImplementation((_url: string) => null);

    const config: FakeRequestConfig = { headers: {}, url: "http://api.example.com/foo" };
    const result = (await requestHandler(config)) as FakeRequestConfig;

    expect(result.headers["X-CSRF-Token"]).toBeUndefined();
  });

  // withCredentials must stay true so the browser actually attaches the
  // session cookies on cross-site fetches. Same property that broke the
  // vadenpartner.com → partnerapi.sisyatech.com flow before this change.
  it("sets withCredentials so cross-site cookies are sent", async () => {
    readCsrfMirrorForUrlMock.mockImplementation((_url: string) => null);

    const config: FakeRequestConfig = { headers: {}, url: "http://api.example.com/foo" };
    const result = (await requestHandler(config)) as FakeRequestConfig;

    expect(result.withCredentials).toBe(true);
  });

  // Microapp shell talks to several microapp APIs. Each API has its own
  // csrf_token cookie on its own host and its own mirror on the SPA host. The
  // bug this guards against: a single bare mirror cookie would be overwritten
  // by each successive microapp login, so the next request to a DIFFERENT
  // microapp API carries the wrong token value and CsrfMiddleware 403s. The
  // interceptor must pick the mirror that matches the request's API host.
  it("picks the correct per-host mirror when SPA talks to multiple microapp APIs", async () => {
    readCsrfMirrorForUrlMock.mockImplementation((url: string): string | null => {
      const host: string = new URL(url, "http://spa.example.com").host;
      if (host === "khrshell-api.example.com") return "khrshell-token";
      if (host === "kwebozluk-api.example.com") return "kwebozluk-token";
      return null;
    });

    const khrshellConfig: FakeRequestConfig = {
      headers: {},
      url: "http://khrshell-api.example.com/v1/api/auth/issue-mfe-token"
    };
    const kwebozlukConfig: FakeRequestConfig = {
      headers: {},
      url: "http://kwebozluk-api.example.com/v1/api/OzlukList/OzlukListPageInit"
    };

    const khrshellResult = (await requestHandler(khrshellConfig)) as FakeRequestConfig;
    const kwebozlukResult = (await requestHandler(kwebozlukConfig)) as FakeRequestConfig;

    expect(khrshellResult.headers["X-CSRF-Token"]).toBe("khrshell-token");
    expect(kwebozlukResult.headers["X-CSRF-Token"]).toBe("kwebozluk-token");
  });

  // Path-routed microapp on a shared API host: the SPA tells the backend its
  // path prefix so the backend can scope the session cookies' Path to it.
  it("sends X-App-Base-Path for a path-routed microapp URL", async () => {
    readCsrfMirrorForUrlMock.mockImplementation((_url: string) => null);
    const config: FakeRequestConfig = { headers: {}, url: "https://api.example.com/microappapi/v1/api/x" };
    const result = (await requestHandler(config)) as FakeRequestConfig;
    expect(result.headers["X-App-Base-Path"]).toBe("/microappapi");
  });

  // Root-served / subdomain-routed app: no prefix → header omitted → backend
  // keeps cookies at "/", unchanged.
  it("omits X-App-Base-Path for a root-served URL", async () => {
    readCsrfMirrorForUrlMock.mockImplementation((_url: string) => null);
    const config: FakeRequestConfig = { headers: {}, url: "https://api.example.com/v1/api/x" };
    const result = (await requestHandler(config)) as FakeRequestConfig;
    expect(result.headers["X-App-Base-Path"]).toBeUndefined();
  });
});

interface FakeCsrf403 {
  config: { url: string; _retry?: boolean; _csrfRetry?: boolean };
  response: { status: number; headers?: Record<string, string>; data?: unknown };
}

const buildCsrf403 = (url: string, headers: Record<string, string>, data: unknown): FakeCsrf403 => ({
  config: { url },
  response: { status: 403, headers, data }
});

describe("auth/interceptors — CSRF 403 self-heal", () => {
  const ENDPOINT: string = "http://localhost:3772/api/HomePagePageInit";
  const REFRESH_URL: string = "http://localhost:3772/auth/refreshtoken";
  let refreshHandler: (error: unknown) => Promise<unknown>;

  beforeEach(() => {
    jest.resetModules();
    responseRegistrations.length = 0;
    refreshPostMock.mockReset();
    replayPostMock.mockReset();
    gotoLoginMock.mockReset();
    getCookieMock.mockReset();
    getCookieMock.mockImplementation((name: string) => (name === "is_logged_in" ? "1" : null));
    readLoginStateCookieMock.mockReset();
    readLoginStateCookieMock.mockImplementation((name: string) => (name === "is_logged_in" ? "1" : null));
    writeCsrfMirrorForUrlMock.mockReset();
    replayPostMock.mockResolvedValue("replayed");
    require("../interceptors");
    refreshHandler = responseRegistrations[1].error;
  });

  // The core fix: a stale csrf mirror makes the backend 403 with the
  // X-Csrf-Mismatch marker. A valid access_token never trips the 401 path, so
  // this branch must run one refresh (which rotates csrf + rewrites the mirror)
  // and replay the request — otherwise every request is stuck.
  it("marker-tagged 403 triggers one refresh, rewrites the mirror, and replays", async () => {
    refreshPostMock.mockResolvedValueOnce({ status: 200, data: { csrfToken: "new-csrf", token: "new-token" } });

    const result: unknown = await refreshHandler(buildCsrf403(ENDPOINT, { "x-csrf-mismatch": "1" }, ""));

    expect(refreshPostMock).toHaveBeenCalledTimes(1);
    expect(writeCsrfMirrorForUrlMock).toHaveBeenCalledWith(REFRESH_URL, "new-csrf", expect.any(Number));
    expect(replayPostMock).toHaveBeenCalledTimes(1);
    expect(result).toBe("replayed");
  });

  // Fallback heuristic: if the marker header isn't readable (e.g. CORS expose
  // not applied) an empty-body 403 is still the CsrfMiddleware rejection, so it
  // must self-heal too.
  it("empty-body 403 without the marker still self-heals", async () => {
    refreshPostMock.mockResolvedValueOnce({ status: 200, data: { csrfToken: "new-csrf", token: "new-token" } });

    const result: unknown = await refreshHandler(buildCsrf403(ENDPOINT, {}, ""));

    expect(refreshPostMock).toHaveBeenCalledTimes(1);
    expect(replayPostMock).toHaveBeenCalledTimes(1);
    expect(result).toBe("replayed");
  });

  // Authorization Forbid()/permission 403s carry a JSON body and no marker.
  // These are NOT recoverable by refresh and must propagate untouched.
  it("403 with a JSON body and no marker is not retried", async () => {
    const error: FakeCsrf403 = buildCsrf403(ENDPOINT, {}, { message: "Forbidden" });

    const result: unknown = await refreshHandler(error).catch((e: unknown) => e);

    expect(refreshPostMock).not.toHaveBeenCalled();
    expect(replayPostMock).not.toHaveBeenCalled();
    expect(result).toBe(error);
  });

  // Bounded: after one refresh+replay, the same request hitting 403 again
  // (genuine CSRF rejection) must not loop into a second refresh.
  it("a second 403 for the same request is not retried again", async () => {
    refreshPostMock.mockResolvedValueOnce({ status: 200, data: { csrfToken: "new-csrf", token: "new-token" } });

    const error: FakeCsrf403 = buildCsrf403(ENDPOINT, { "x-csrf-mismatch": "1" }, "");
    await refreshHandler(error);
    // _csrfRetry is now set on the shared config object.
    const result: unknown = await waitForCompletion(refreshHandler(error).catch((e: unknown) => e));

    expect(refreshPostMock).toHaveBeenCalledTimes(1);
    expect(result).toBe(error);
  });
});
