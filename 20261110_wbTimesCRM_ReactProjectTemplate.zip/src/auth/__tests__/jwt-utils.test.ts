import { isMfeHandoffToken, readUsernameFromJwt, tryDecodeJwtPayload } from "../jwt-utils";

const buildJwt = (payload: Record<string, unknown>): string => {
  const header = btoa(JSON.stringify({ alg: "HS256", typ: "JWT" }));
  const body = btoa(JSON.stringify(payload));
  return `${header}.${body}.signature-not-validated-on-frontend`;
};

const buildUrlSafeJwt = (payload: Record<string, unknown>): string => {
  const header = btoa(JSON.stringify({ alg: "HS256", typ: "JWT" }))
    .replace(/\+/g, "-")
    .replace(/\//g, "_");
  const body = btoa(JSON.stringify(payload)).replace(/\+/g, "-").replace(/\//g, "_").replace(/=+$/, "");
  return `${header}.${body}.signature`;
};

describe("jwt-utils", () => {
  describe("tryDecodeJwtPayload", () => {
    it("decodes a standard base64 JWT payload", () => {
      const token = buildJwt({ UserName: "alice", Mfe: "1" });
      expect(tryDecodeJwtPayload(token)).toEqual({ UserName: "alice", Mfe: "1" });
    });

    it("decodes a base64url JWT payload (no padding, '-' / '_')", () => {
      const token = buildUrlSafeJwt({ UserName: "bob>?", Mfe: "1" });
      expect(tryDecodeJwtPayload(token)).toEqual({ UserName: "bob>?", Mfe: "1" });
    });

    it("returns null for malformed tokens", () => {
      expect(tryDecodeJwtPayload("not-a-jwt")).toBeNull();
      expect(tryDecodeJwtPayload("a.b")).toBeNull();
      expect(tryDecodeJwtPayload("")).toBeNull();
      expect(tryDecodeJwtPayload(null)).toBeNull();
      expect(tryDecodeJwtPayload(undefined)).toBeNull();
    });

    it("returns null when the payload section is not JSON", () => {
      const header = btoa(JSON.stringify({ alg: "HS256" }));
      const body = btoa("not-json");
      const token = `${header}.${body}.sig`;
      expect(tryDecodeJwtPayload(token)).toBeNull();
    });
  });

  describe("isMfeHandoffToken", () => {
    it("returns true when the Mfe claim is exactly '1'", () => {
      expect(isMfeHandoffToken(buildJwt({ Mfe: "1" }))).toBe(true);
    });

    it("returns false when the Mfe claim is missing", () => {
      expect(isMfeHandoffToken(buildJwt({ UserName: "alice" }))).toBe(false);
    });

    it("returns false when the Mfe claim is anything other than '1'", () => {
      expect(isMfeHandoffToken(buildJwt({ Mfe: "true" }))).toBe(false);
      expect(isMfeHandoffToken(buildJwt({ Mfe: 1 }))).toBe(false);
      expect(isMfeHandoffToken(buildJwt({ Mfe: "0" }))).toBe(false);
    });

    it("returns false for non-tokens", () => {
      expect(isMfeHandoffToken("")).toBe(false);
      expect(isMfeHandoffToken(null)).toBe(false);
      expect(isMfeHandoffToken("garbage")).toBe(false);
    });
  });

  describe("readUsernameFromJwt", () => {
    it("returns the UserName claim when present and non-empty", () => {
      expect(readUsernameFromJwt(buildJwt({ UserName: "alice" }))).toBe("alice");
    });

    it("returns null when UserName claim is missing or empty", () => {
      expect(readUsernameFromJwt(buildJwt({ UserName: "" }))).toBeNull();
      expect(readUsernameFromJwt(buildJwt({ Other: "x" }))).toBeNull();
    });

    it("returns null when the claim is not a string", () => {
      expect(readUsernameFromJwt(buildJwt({ UserName: 123 }))).toBeNull();
    });

    it("returns null for malformed tokens", () => {
      expect(readUsernameFromJwt("not-a-jwt")).toBeNull();
      expect(readUsernameFromJwt(null)).toBeNull();
    });
  });
});
