import {
  deleteCsrfMirrorForUrl,
  deleteLoginStateCookie,
  getApiBasePath,
  getApiHostKey,
  readCsrfMirrorForUrl,
  readLoginStateCookie,
  setLoginStateCookie,
  writeCsrfMirrorForUrl
} from "../cookie-utils";

const TEST_API: string = "https://workspace-test-api.kuika.io/v1/api/auth/login";
const WF_API: string = "https://workspace-testwfapp-api.kuika.io/v1/api/auth/login";

describe("cookie-utils", () => {
  let written: string[];
  let jar: string;

  beforeEach(() => {
    written = [];
    jar = "";
    Object.defineProperty(document, "cookie", {
      configurable: true,
      get: (): string => jar,
      set: (value: string): void => {
        written.push(value);
      }
    });
  });

  describe("CSRF mirror (per-API-host)", () => {
    it("writes a host-scoped mirror name derived from the request URL", () => {
      writeCsrfMirrorForUrl(TEST_API, "abc", 100);
      expect(written[0]).toContain("csrf_token__workspace-test-api.kuika.io=abc");
    });

    it("does nothing when the URL is missing", () => {
      writeCsrfMirrorForUrl(undefined, "abc", 100);
      expect(written).toHaveLength(0);
    });

    it("reads the host-scoped mirror for the request URL", () => {
      jar = "csrf_token__workspace-test-api.kuika.io=tok-test; csrf_token__workspace-testwfapp-api.kuika.io=tok-wf";
      expect(readCsrfMirrorForUrl(TEST_API)).toBe("tok-test");
      expect(readCsrfMirrorForUrl(WF_API)).toBe("tok-wf");
    });

    it("falls back to the legacy bare csrf_token when no host mirror exists", () => {
      jar = "csrf_token=legacy";
      expect(readCsrfMirrorForUrl(TEST_API)).toBe("legacy");
    });

    it("deletes ONLY the given API host's mirror, leaving siblings intact", () => {
      deleteCsrfMirrorForUrl(WF_API);
      expect(written).toHaveLength(1);
      expect(written[0]).toContain("csrf_token__workspace-testwfapp-api.kuika.io=");
      expect(written[0]).toContain("expires=Thu, 01 Jan 1970");
      expect(written[0]).not.toContain("workspace-test-api.kuika.io");
      expect(written.join("")).not.toMatch(/(?:^|;\s*)csrf_token=/);
    });

    it("does nothing when the URL is missing", () => {
      deleteCsrfMirrorForUrl(undefined);
      expect(written).toHaveLength(0);
    });
  });

  describe("login-state cookies (per-app by name, key passed by caller)", () => {
    const HOST_A: string = "workspace-test-api.kuika.io";
    const HOST_B: string = "workspace-testwfapp-api.kuika.io";

    it("setLoginStateCookie suffixes the name with the key and stays at root path", () => {
      setLoginStateCookie("is_logged_in", "1", 100, HOST_A);
      expect(written[0]).toContain(`is_logged_in__${HOST_A}=1`);
      expect(written[0]).toContain("path=/;");
    });

    it("setLoginStateCookie writes a bare name when the key is empty", () => {
      setLoginStateCookie("is_logged_in", "1", 100, "");
      expect(written[0]).toContain("is_logged_in=1");
      expect(written[0]).not.toContain("is_logged_in__");
      expect(written[0]).toContain("path=/;");
    });

    it("deleteLoginStateCookie clears this app's scoped cookie and the legacy bare cookie, both at root", () => {
      deleteLoginStateCookie("session_id", HOST_A);
      expect(written).toHaveLength(2);
      expect(written[0]).toContain(`session_id__${HOST_A}=`);
      expect(written[0]).toContain("path=/;");
      expect(written[1]).toMatch(/(?:^|;|\s)session_id=/);
      expect(written[1]).toContain("path=/;");
      // Must not touch a sibling app's scoped cookie.
      expect(written.join("")).not.toContain(HOST_B);
    });

    it("deleteLoginStateCookie clears only the bare cookie when the key is empty", () => {
      deleteLoginStateCookie("session_id", "");
      expect(written).toHaveLength(1);
      expect(written[0]).not.toContain("session_id__");
      expect(written[0]).toContain("path=/;");
    });

    it("readLoginStateCookie returns this app's scoped value, isolated from siblings", () => {
      jar = `is_logged_in__${HOST_A}=1; is_logged_in__${HOST_B}=0`;
      expect(readLoginStateCookie("is_logged_in", HOST_A)).toBe("1");
      expect(readLoginStateCookie("is_logged_in", HOST_B)).toBe("0");
    });

    it("readLoginStateCookie falls back to the legacy bare cookie when no scoped one exists", () => {
      jar = "is_logged_in=1";
      expect(readLoginStateCookie("is_logged_in", HOST_A)).toBe("1");
    });

    it("readLoginStateCookie prefers the scoped cookie over the legacy bare one", () => {
      jar = `is_logged_in=0; is_logged_in__${HOST_A}=1`;
      expect(readLoginStateCookie("is_logged_in", HOST_A)).toBe("1");
    });
  });

  // Custom-domain / self-hosted deployments path-route several app backends under
  // ONE API host. Host-only keying collided the shell and the microapp onto a
  // single mirror, so the microapp 403'd on every request. The key now includes
  // the path prefix before /v1/api so each path-routed app is isolated.
  describe("path-routed microapps (shared API host, distinct path prefix)", () => {
    const SHELL: string = "https://api.example.com/v1/api/auth/login";
    const MICRO: string = "https://api.example.com/microappapi/v1/api/auth/login";

    it("subdomain-routed apps key on the bare host (no prefix) — unchanged from before", () => {
      expect(getApiHostKey("https://ws-proj-api.kuika.io/v1/api/auth/login")).toBe("ws-proj-api.kuika.io");
    });

    it('path-routed app keys on host + path prefix ("/" stripped to a legal name fragment)', () => {
      expect(getApiHostKey(SHELL)).toBe("api.example.com");
      expect(getApiHostKey(MICRO)).toBe("api.example.com_microappapi");
    });

    it("writes distinct mirror cookies for shell vs microapp on the same host", () => {
      writeCsrfMirrorForUrl(SHELL, "shell-tok", 100);
      writeCsrfMirrorForUrl(MICRO, "micro-tok", 100);
      expect(written[0]).toContain("csrf_token__api.example.com=shell-tok");
      expect(written[1]).toContain("csrf_token__api.example.com_microappapi=micro-tok");
    });

    it("reads the correct per-app mirror for shell vs microapp on the same host", () => {
      jar = "csrf_token__api.example.com=shell-tok; csrf_token__api.example.com_microappapi=micro-tok";
      expect(readCsrfMirrorForUrl(SHELL)).toBe("shell-tok");
      expect(readCsrfMirrorForUrl(MICRO)).toBe("micro-tok");
    });

    it("getApiBasePath returns the raw prefix before /v1/api (the X-App-Base-Path value)", () => {
      expect(getApiBasePath(SHELL)).toBe("");
      expect(getApiBasePath(MICRO)).toBe("/microappapi");
      expect(getApiBasePath("https://ws-proj-api.kuika.io/v1/api/auth/login")).toBe("");
      expect(getApiBasePath(undefined)).toBe("");
    });
  });
});
