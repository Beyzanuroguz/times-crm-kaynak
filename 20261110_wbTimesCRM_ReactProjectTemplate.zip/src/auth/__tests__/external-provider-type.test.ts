import { EExternalTokenProviderTypes } from "../../models/dto/login.dto";
import { EXTERNAL_PROVIDER_TYPE_NAMES, parseExternalTokenProviderType } from "../external-provider-type";

describe("parseExternalTokenProviderType", () => {
  it("maps every External slot to its enum value", () => {
    expect(parseExternalTokenProviderType("External1")).toBe(EExternalTokenProviderTypes.External1);
    expect(parseExternalTokenProviderType("External2")).toBe(EExternalTokenProviderTypes.External2);
    expect(parseExternalTokenProviderType("External3")).toBe(EExternalTokenProviderTypes.External3);
    expect(parseExternalTokenProviderType("External4")).toBe(EExternalTokenProviderTypes.External4);
    expect(parseExternalTokenProviderType("External5")).toBe(EExternalTokenProviderTypes.External5);
  });

  it("accepts any casing and surrounding whitespace", () => {
    expect(parseExternalTokenProviderType("external1")).toBe(EExternalTokenProviderTypes.External1);
    expect(parseExternalTokenProviderType("EXTERNAL3")).toBe(EExternalTokenProviderTypes.External3);
    expect(parseExternalTokenProviderType("  External2  ")).toBe(EExternalTokenProviderTypes.External2);
  });

  it("rejects the built-in providers — those have their own login flows", () => {
    expect(parseExternalTokenProviderType("Google")).toBeNull();
    expect(parseExternalTokenProviderType("AzureAD")).toBeNull();
    expect(parseExternalTokenProviderType("Apple")).toBeNull();
    expect(parseExternalTokenProviderType("Facebook")).toBeNull();
    expect(parseExternalTokenProviderType("None")).toBeNull();
  });

  it("never coerces a numeric attribute into a provider slot", () => {
    expect(parseExternalTokenProviderType("5")).toBeNull();
    expect(parseExternalTokenProviderType("0")).toBeNull();
    expect(parseExternalTokenProviderType("2")).toBeNull();
  });

  it("does not resolve inherited object keys", () => {
    // A plain-object lookup returns Object.prototype for "__proto__" and a
    // function for "constructor" — both non-undefined, so a naive presence check
    // lets them through as a bogus provider type.
    expect(parseExternalTokenProviderType("__proto__")).toBeNull();
    expect(parseExternalTokenProviderType("constructor")).toBeNull();
    expect(parseExternalTokenProviderType("toString")).toBeNull();
    expect(parseExternalTokenProviderType("hasOwnProperty")).toBeNull();
    expect(parseExternalTokenProviderType("valueOf")).toBeNull();
  });

  it("returns null for absent or unknown values", () => {
    expect(parseExternalTokenProviderType(undefined)).toBeNull();
    expect(parseExternalTokenProviderType(null)).toBeNull();
    expect(parseExternalTokenProviderType("")).toBeNull();
    expect(parseExternalTokenProviderType("   ")).toBeNull();
    expect(parseExternalTokenProviderType("External6")).toBeNull();
    expect(parseExternalTokenProviderType("External1; DROP TABLE")).toBeNull();
  });

  it("exposes the accepted names for user-facing messages", () => {
    expect(EXTERNAL_PROVIDER_TYPE_NAMES).toEqual(["External1", "External2", "External3", "External4", "External5"]);
    EXTERNAL_PROVIDER_TYPE_NAMES.forEach((name: string) => {
      expect(parseExternalTokenProviderType(name)).not.toBeNull();
    });
  });
});
