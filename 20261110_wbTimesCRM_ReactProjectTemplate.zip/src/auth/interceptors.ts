import axios, { type AxiosRequestConfig, type InternalAxiosRequestConfig } from "axios";
import { EAccountStatus } from "../models/enum/auth";
import HelperService from "../services/helper-service";
import { OFFLINE_REDIRECT_CANCEL } from "../shared/utilty/constants";
import { KuikaAppManager } from "../shared/utilty/kuika-app-manager";
import { ReactSystemFunctions } from "../shared/utilty/react-system-functions";
import {
  deleteCsrfMirrorForUrl,
  deleteLoginStateCookie,
  getApiBasePath,
  readCsrfMirrorForUrl,
  readLoginStateCookie,
  writeCsrfMirrorForUrl
} from "./cookie-utils";
import LocalStorageService from "./local-storage-service";

const isNetworkLevelError = (error: { response?: unknown; code?: string; message?: string }): boolean =>
  !error.response &&
  (error.code === "ERR_NETWORK" ||
    error.code === "ERR_INTERNET_DISCONNECTED" ||
    error.code === "ECONNREFUSED" ||
    error.message === "Network Error");

declare const window: any;

axios.defaults.withCredentials = true;

// KOA-17775 — preserve precision of large Int64 values in API responses.
// axios's default transformResponse runs native JSON.parse, which rounds any integer
// beyond Number.MAX_SAFE_INTEGER (e.g. a backend int64 9600017533270597 → ...596)
// before any binding/display code runs. Replace it with a big-integer-aware parse.
// Non-string bodies (blob/arraybuffer) and explicit text responses are left untouched.
axios.defaults.transformResponse = [
  function preserveBigIntegers(this: InternalAxiosRequestConfig | undefined, data: unknown): unknown {
    if (typeof data !== "string") return data;
    if (this?.responseType === "text") return data;
    return ReactSystemFunctions.parseJsonPreservingBigIntegers(data);
  }
];

const backendUrl = KuikaAppManager.GetBackendUrl();
let isTokenRefreshing = false;
const localStorageService = LocalStorageService.getService();

interface FailedQueueItem {
  resolve: (token: string | null) => void;
  reject: (error: unknown) => void;
}

interface AuthRetryConfig extends AxiosRequestConfig {
  _retry?: boolean;
  _csrfRetry?: boolean;
  __retryCount?: number;
}

interface CsrfErrorResponse {
  status: number;
  headers?: Record<string, string>;
  data?: unknown;
}

interface RefreshFailureRedirectOptions {
  redirectUri?: string;
  skipWhenAlreadyOnLogin?: boolean;
}

let failedQueue: FailedQueueItem[] = [];

const MAX_RETRIES: number = 3;
const RETRY_DELAY: number = 10000;



axios.interceptors.response.use(undefined, async (error) => {
  // Skip if request was cancelled (e.g., offline redirect)
  if (axios.isCancel(error) || !error.config) {
    return Promise.reject(error);
  }

  // Skip retry for rate limiting responses
  if (error.response && error.response.status === 429) {
    return Promise.reject(error);
  }

  const config = error.config;
  config.__retryCount = config.__retryCount || 0;
  const isNetworkError = isNetworkLevelError(error);
  if (isNetworkError) {
    ReactSystemFunctions.markNetworkError();
  }

  // Fail fast when offline so callers fall back to their caches instead of
  // burning 30s on retries. `isOnline()` reflects observed traffic, not just
  // navigator.onLine, so DevTools-Offline + ERR_INTERNET_DISCONNECTED counts.
  const isOnline: boolean = await ReactSystemFunctions.isOnline();
  if (!isOnline) {
    
    return Promise.reject(error);
  }

  if (isNetworkError && (MAX_RETRIES === -1 || config.__retryCount < MAX_RETRIES)) {
    config.__retryCount += 1;

    console.log(`Retrying request (${config.__retryCount}/${MAX_RETRIES}): ${config.url}`, {
      method: config.method,
      errorCode: error.code,
      errorMessage: error.message
    });

    await new Promise((resolve) => setTimeout(resolve, RETRY_DELAY));

    return axios(config);
  }

  return Promise.reject(error);
});

const processQueue = (error: unknown, token: string | null = null): void => {
  failedQueue.forEach((promise) => {
    if (error) {
      promise.reject(error);
    } else {
      promise.resolve(token);
    }
  });
  failedQueue = [];
};

const isRefreshTokenRequest = (config: AuthRetryConfig | undefined): boolean => {
  return config?.url?.includes("refreshtoken") === true;
};

// True while a partial-auth sub-flow is in progress: the user has passed
// username/password but the session is not yet complete because 2FA
// verification (or account activation) is still pending. In this window the
// backend issued only a flagged access_token and NO refresh_token, so a
// 401/403 from a background request (e.g. saveApplication) must NOT trigger the
// refresh -> redirect recovery below: the refresh can't succeed (no
// refresh_token) and the redirect would bounce the user off the
// VerificationCode screen before they can enter the emailed code, producing an
// infinite SignIn <-> VerificationCode loop (KOA-17893). The session is
// completed by /auth/loginwithverificationcode, after which the login status is
// no longer partial and normal recovery resumes. Keyed on the stored login
// status rather than the URL path, because the login/verification screens can
// be named freely per project (e.g. "signin"), so HelperService
// .getIsInLoginPage()'s "/login" substring check does not reliably apply here.
const isInAuthSubFlow = (): boolean => {
  const loginStatus: string | null = LocalStorageService.getLoginStatus();
  return (
    loginStatus === EAccountStatus.TwoFactorAuthentication.toString() ||
    loginStatus === EAccountStatus.ShouldActivated.toString()
  );
};

const clearRefreshStateAndRedirect = (error: unknown, options: RefreshFailureRedirectOptions = {}): Promise<never> => {
  isTokenRefreshing = false;
  processQueue(error);
  const loginStateKey: string = KuikaAppManager.getLoginStateCookieKey();
  deleteLoginStateCookie("is_logged_in", loginStateKey);
  deleteLoginStateCookie("session_id", loginStateKey);
  deleteCsrfMirrorForUrl(backendUrl);
  window.userInfo = undefined;

  if (options.skipWhenAlreadyOnLogin === true && HelperService.getIsInLoginPage()) {
    return Promise.reject(error);
  }

  if (options.redirectUri !== undefined) {
    HelperService.gotoLogin(options.redirectUri);
  } else {
    HelperService.gotoLogin();
  }

  return Promise.reject(error);
};

// Refresh the session once, then replay the original request. Shared by the
// 401 (access token expired) and the CSRF-403 (stale csrf mirror) recovery
// paths: both are fixed by /auth/refreshtoken, which rotates the auth cookies
// AND the csrf_token, returns the new csrfToken in the body, and lets us
// rewrite the host-scoped mirror so the replayed request carries a matching
// X-CSRF-Token. Concurrent failures coalesce onto a single refresh via
// isTokenRefreshing + failedQueue.
const refreshAndRetry = (originalRequest: AuthRetryConfig): Promise<unknown> => {
  if (isTokenRefreshing === false) {
    isTokenRefreshing = true;
    const isLoggedIn: boolean = readLoginStateCookie("is_logged_in", KuikaAppManager.getLoginStateCookieKey()) === "1";

    if (!isLoggedIn) {
      const redirectUri: string =
        window.location.pathname +
        window.location.search +
        (window.location.hash != undefined ? window.location.hash : "");
      return clearRefreshStateAndRedirect(new Error("No active login cookie"), {
        redirectUri,
        skipWhenAlreadyOnLogin: true
      });
    }

    return axios
      .post(`${backendUrl}/auth/refreshtoken`, {}, { withCredentials: true })
      .then((res) => {
        isTokenRefreshing = false;
        if (res && res.status === 200) {
          // Server rotates the HttpOnly auth cookies + the csrf_token cookie on
          // the API host automatically. The csrf_token mirror on the frontend
          // host has to be re-written here — when SPA and API live on
          // different subdomains, document.cookie can't see the API-host
          // cookie, so without this write the next request still carries the
          // pre-refresh CSRF value in the header while the server side has
          // already rotated. CsrfMiddleware then rejects with 403 even
          // though refresh succeeded. Mirror is keyed on the refresh
          // endpoint's host so multi-microapp setups keep one mirror per API.
          const newCsrfToken: string | undefined = res.data?.csrfToken;
          if (newCsrfToken) {
            const THIRTY_DAYS: number = 30 * 24 * 60 * 60;
            writeCsrfMirrorForUrl(`${backendUrl}/auth/refreshtoken`, newCsrfToken, THIRTY_DAYS);
          }
          processQueue(null, res.data.token);
          return axios(originalRequest);
        }

        // Anything 2xx-but-not-200 (e.g. 204 from a proxy, 302 from an
        // auth gateway) means the refresh didn't yield usable tokens.
        const refreshError = new Error("Refresh token endpoint returned non-200");
        return clearRefreshStateAndRedirect(refreshError);
      })
      .catch((e) => clearRefreshStateAndRedirect(e));
  }

  return new Promise<string | null>((resolve, reject) => {
    failedQueue.push({ resolve, reject });
  })
    .then(() => {
      // Cookie is sent automatically — no need to set Authorization header
      return axios(originalRequest);
    })
    .catch((err) => {
      return Promise.reject(err);
    });
};

// A 403 from CsrfMiddleware (missing/mismatched X-CSRF-Token) is recoverable:
// a refresh re-syncs the csrf_token cookie and the mirror. Distinguish it from
// authorization Forbid()/permission 403s — which must NOT trigger a refresh —
// by the X-Csrf-Mismatch marker header the backend sets (exposed via CORS).
// Fall back to the empty-body heuristic: CsrfMiddleware is the only source of
// an empty-body 403 in the generated pipeline, so if the marker isn't readable
// (e.g. CORS expose not applied) an empty 403 is still treated as CSRF, while
// permission 403s carry a JSON body and are left alone.
const isCsrfMismatch = (response: CsrfErrorResponse | undefined): boolean => {
  if (!response || response.status !== 403) {
    return false;
  }
  if (response.headers?.["x-csrf-mismatch"] === "1") {
    return true;
  }
  const data: unknown = response.data;
  if (data === undefined || data === null || data === "") {
    return true;
  }
  if (typeof data === "object" && data !== null && Object.keys(data).length === 0) {
    return true;
  }
  return false;
};

// Add a request interceptor
axios.interceptors.request.use(
  async (config) => {
    

    const urlItems = document.location.pathname.substring(1).split(/\//);
    config.withCredentials = true;
    const language = localStorage.getItem("ml");
    if (language && language.length) {
      config.headers.cultureName = language;
    }
    // CSRF token: echo the non-HttpOnly csrf_token cookie in the X-CSRF-Token
    // header on every request. The backend CsrfMiddleware compares the two
    // and rejects state-changing cookie-auth requests where they don't match,
    // which is what blocks a cross-site attacker who can force the cookie to
    // be sent but cannot read its value to put in the header.
    //
    // Mirror lookup is per API host: a microapp shell that talks to several
    // microapp APIs has one csrf_token cookie per API on each API's own host,
    // and one mirror per API on the SPA host. Reading by request URL ensures
    // the header value matches the cookie value that the browser actually
    // attaches to this request.
    const csrfToken: string | null = readCsrfMirrorForUrl(config.url);
    if (csrfToken) {
      config.headers["X-CSRF-Token"] = csrfToken;
    }
    // Tell the backend this app's path prefix so it can scope the session
    // cookies' Path to it (path-routed microapps share ONE API host; without
    // per-path cookies the shell and microapp overwrite each other's csrf_token
    // and the microapp 403s). Empty for root-served / subdomain-routed apps, so
    // the header is omitted and cookies stay at "/". See cookie-utils.getApiBasePath.
    const apiBasePath: string = getApiBasePath(config.url);
    if (apiBasePath) {
      config.headers["X-App-Base-Path"] = apiBasePath;
    }
    // Domain headers
    if (urlItems[0] && urlItems[0] !== "") {
      config.headers.domainName = urlItems[0];
    }
    if (window.kuika && window.kuika?.project && window.kuika?.project.domainId) {
      config.headers.domainId = window.kuika?.project.domainId;
    }
    const nextAudit = KuikaAppManager.consumeNextRequestAudit();
    if (nextAudit?.key) {
      config.headers["x-audit-key"] = nextAudit.key;
      config.headers["x-audit-name"] = nextAudit.name;
      if (nextAudit.source) {
        config.headers["x-audit-source"] = nextAudit.source;
      }
      if (nextAudit.data !== undefined) {
        config.headers["x-audit-data"] = JSON.stringify(nextAudit.data);
      }
    }
    return config;
  },
  (error) => {
    Promise.reject(error);
  }
);

// Add a response interceptor
axios.interceptors.response.use(
  async (response) => {
    ReactSystemFunctions.markNetworkSuccess();
    return response;
  },
  async (error) => {
    const originalRequest: AuthRetryConfig | undefined = error.config;

    if (!error.response) {
      return Promise.reject(error);
    }

    if (!originalRequest) {
      return Promise.reject(error);
    }

    // See isInAuthSubFlow: during 2FA verification / account activation the
    // session is only partial and cannot be recovered via refresh. Skip all
    // auth-recovery (refresh + redirect) so the user stays on the
    // VerificationCode screen and can complete the flow (KOA-17893).
    if (isInAuthSubFlow()) {
      return Promise.reject(error);
    }

    if (isRefreshTokenRequest(originalRequest)) {
      if (isTokenRefreshing === false) {
        const loginStateKey: string = KuikaAppManager.getLoginStateCookieKey();
        deleteLoginStateCookie("is_logged_in", loginStateKey);
        deleteLoginStateCookie("session_id", loginStateKey);
        deleteCsrfMirrorForUrl(backendUrl);
        window.userInfo = undefined;
        HelperService.gotoLogin();
      }
      return Promise.reject(error);
    }

    // A 401 from a login endpoint is the answer, not an expired session: there is
    // no session to refresh yet. Sending it through refreshAndRetry would swap the
    // real reason ("Invalid external token", "External token validation is not
    // implemented") for "No active login cookie", clear this app's login-state
    // cookies, and redirect — which, for an app embedded as a web component,
    // rewrites the *host page's* URL. Rejecting here leaves the caller's own error
    // handling intact.
    const loginEndpoints: string[] = [
      `${backendUrl}/auth/login`,
      `${backendUrl}/auth/loginwithtoken`,
      `${backendUrl}/auth/loginwithmfetoken`
    ];
    if (error.response.status === 401 && loginEndpoints.includes(originalRequest.url)) {
      return Promise.reject(error);
    }

    if (error.response.status === 401 && !originalRequest._retry) {
      originalRequest._retry = true;
      return refreshAndRetry(originalRequest);
    }

    // Stale csrf mirror → CsrfMiddleware 403. A valid access_token never trips
    // the 401 path above, so without this the user is stuck on every request.
    // One bounded refresh re-syncs the csrf_token + mirror; the replayed
    // request then carries a matching X-CSRF-Token. A second 403 (genuine CSRF
    // rejection) is not retried.
    if (isCsrfMismatch(error.response) && !originalRequest._csrfRetry) {
      originalRequest._csrfRetry = true;
      return refreshAndRetry(originalRequest);
    }

    return Promise.reject(error);
  }
);
