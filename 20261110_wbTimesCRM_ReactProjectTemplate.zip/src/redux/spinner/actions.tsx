import { HIDE_SPINNER, SHOW_SPINNER, SpinnerActionTypes } from "./types";

export const hideSpinner = (): SpinnerActionTypes => {
  return {
    type: HIDE_SPINNER,
    meta: {
      params: {}
    }
  };
};

export const showSpinner = (): SpinnerActionTypes => {
  return {
    type: SHOW_SPINNER,
    meta: {
      params: {}
    }
  };
};

export type SpinnerActionType = typeof hideSpinner | typeof showSpinner;
