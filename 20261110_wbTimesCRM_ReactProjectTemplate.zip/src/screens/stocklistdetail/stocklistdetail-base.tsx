import React from "react";
import Axios, { AxiosResponse } from "axios";
import { KuikaAppManager } from "../../shared/utilty/kuika-app-manager";
import { ReactSystemFunctions } from "../../shared/utilty/react-system-functions";
import { KNavigator } from "../../shared/hoc/with-history";
import { KContext } from "../../shared/hoc/with-context";
import { useLocation } from "react-router-dom";
import { FormInstance } from "antd/es/form";
import { Guid } from "guid-typescript";
import Swal from "sweetalert2";
import { KMainFunctions } from "../../shared/utilty/main-functions";
import moment from "moment";
import { IValidationData } from "../../models/dto/validation-data";
import { IStripePayment } from "../../models/dto/stripe-payment";
import { IUserInfoDto } from "../../models/dto/user-info.dto";
import { UserService } from "../../services/user-service";
import { kuikaCoreWasmBridgeService } from "../../services/_singletons";
import _ from "lodash";
import mqtt, { MqttClient } from "mqtt";
import { IMqttResult } from "../../models/dto/mqtt.dto";
import { MasterScreen_ScreenContext } from "../masterscreen/masterscreen-context";

declare let window: any;

export interface IStockListDetail_ScreenProps {
  navigator: KNavigator;
  form: FormInstance<any>;
  googleLogin: any;
  screenInputs: any;
  context: KContext;
  initialValues: any;
  children: any;
}

export interface IStockListDetail_ScreenState {
    isSpinnerVisible: boolean;
    isPageVisible: boolean;
	isLeftMenuVisible: boolean;
    spinnerCount: number;
    selectedLanguage: string;
    isPageInitLoaded: false;
    isPageRecurringLoaded: false;
	TM_UserRoleByUserId: any[];
	TM_UserRoleByUserId_dummy: any[];
	TM_GetProductDetailByStoreAndProduct: any[];
	TM_GetProductDetailByStoreAndProduct_dummy: any[];
	TM_GetAvailableLeadsForReservation: any[];
	TM_GetAvailableLeadsForReservation_dummy: any[];
	TM_GetReservedLeadsByStoreCode: any[];
	TM_GetReservedLeadsByStoreCode_dummy: any[];
	TM_GetReserveShowByProductCode: any[];
	TM_GetReserveShowByProductCode_dummy: any[];
	GoBack: any;
	GoBack_dummy: any;
	NAVIGATE: any;
	NAVIGATE_dummy: any;
	isComp975402Visible: 'visible' | 'hidden';
	isComp3848Visible: 'visible' | 'hidden';
	isComp830942Visible: 'visible' | 'hidden';
	isComp880448Visible: 'visible' | 'hidden';
	isComp444172Visible: 'visible' | 'hidden';
	isComp651584Visible: 'visible' | 'hidden';
	isComp874315Visible: 'visible' | 'hidden';
	isComp810345Visible: 'visible' | 'hidden';
	isComp949352Visible: 'visible' | 'hidden';
	isComp260929Enabled: 'enabled' | 'disabled';
	isComp467475Enabled: 'enabled' | 'disabled';
	isComp404140Enabled: 'enabled' | 'disabled';

}

export class StockListDetail_ScreenBase extends React.PureComponent<IStockListDetail_ScreenProps, any> {
    static contextType = MasterScreen_ScreenContext;
    declare context: React.ContextType<typeof MasterScreen_ScreenContext>;
	stocklistdetail_894993_value_kuikaTableRef: React.RefObject<any>;
	stocklistdetail_999335_value_kuikaTableRef: React.RefObject<any>;
    ml=[{"Id":"d5a61d2b-bd60-485f-86e2-661e9ed4e486","Name":"en_US","ShortName":"English","IsDefault":true,"LanguagePhrases":[]},{"Id":"62e6b72c-fd44-4431-824d-570801d66c0a","Name":"FixedValues","ShortName":"FixedValues","LanguagePhrases":[{"Id":942103,"PropertyName":"label","Value":"Geri Dön"},{"Id":583151,"PropertyName":"value","Value":"Model"},{"Id":418759,"PropertyName":"value","Value":"Kadran"},{"Id":113577,"PropertyName":"value","Value":"Bilezik"},{"Id":365729,"PropertyName":"value","Value":"Kategori"},{"Id":669568,"PropertyName":"value","Value":"Ofis"},{"Id":573181,"PropertyName":"value","Value":"Toplam Stok"},{"Id":205253,"PropertyName":"value","Value":"Rezerve Edilmiş"},{"Id":549268,"PropertyName":"value","Value":"Müsait Stok"},{"Id":861779,"PropertyName":"value","Value":"Yeni Ürün Rezervesi"},{"Id":988953,"PropertyName":"placeholder","Value":"Müşteri adı veya telefon numarası ile arama..."},{"Id":368223,"PropertyName":"value","Value":"[datafield:leadcode]"},{"Id":126798,"PropertyName":"value","Value":"Talep Tarihi :"},{"Id":857570,"PropertyName":"value","Value":"[datafield:taleptarihi]"},{"Id":444172,"PropertyName":"value","Value":"[datafield:processname]"},{"Id":35732,"PropertyName":"value","Value":"Müşteri Bilgileri"},{"Id":420803,"PropertyName":"value","Value":"[datafield:musteri]"},{"Id":526721,"PropertyName":"value","Value":"[datafield:email]"},{"Id":353471,"PropertyName":"value","Value":"[datafield:telefon]"},{"Id":424137,"PropertyName":"value","Value":"Termin Tarihi :"},{"Id":308725,"PropertyName":"value","Value":"[datafield:termintarihi]"},{"Id":289133,"PropertyName":"label","Value":"Rezerve Et"},{"Id":549834,"PropertyName":"value","Value":"Mevcut Rezerve Ürün"},{"Id":251951,"PropertyName":"placeholder","Value":"Müşteri adı veya telefon numarası ile arama..."},{"Id":845834,"PropertyName":"value","Value":"[datafield:leadcode]"},{"Id":874315,"PropertyName":"value","Value":"[datafield:processname]"},{"Id":337740,"PropertyName":"value","Value":"Rezerve onaylandı teslim edilebilir."},{"Id":368235,"PropertyName":"value","Value":"Rezerve onay bekliyor"},{"Id":755125,"PropertyName":"value","Value":"Müşteri Bilgileri"},{"Id":79893,"PropertyName":"value","Value":"[datafield:musteri]"},{"Id":579282,"PropertyName":"value","Value":"[datafield:email]"},{"Id":130566,"PropertyName":"value","Value":"[datafield:telefon]"},{"Id":37728,"PropertyName":"value","Value":"Rezervasyon Bilgileri"},{"Id":821018,"PropertyName":"value","Value":"Rezerve Notu :"},{"Id":486975,"PropertyName":"value","Value":"[datafield:rezervnotu]"},{"Id":704195,"PropertyName":"value","Value":"[datafield:reservedby]"},{"Id":829266,"PropertyName":"value","Value":"-"},{"Id":149671,"PropertyName":"value","Value":"[datafield:rezervbaslangic]"},{"Id":467475,"PropertyName":"label","Value":"Düzenle"},{"Id":404140,"PropertyName":"label","Value":"Satışı Gerçekleştir"}]}]
    defaultML = "en_US"
    
    screenHash = ""
    

    private _prevMasterPageInitLoaded: boolean = false;
    private _prevMasterPageRecurringLoaded: boolean = false;
    private _prevShouldTriggerPageInit: boolean = false;
    constructor(props) {
        super(props);
		this.stocklistdetail_988953_value_kuikaTextInputRef = React.createRef();
		this.stocklistdetail_894993_value_kuikaTableRef = React.createRef();
		this.stocklistdetail_251951_value_kuikaTextInputRef = React.createRef();
		this.stocklistdetail_999335_value_kuikaTableRef = React.createRef();

        this.state = {
            isSpinnerVisible: false,
            isPageVisible: false,
            isLeftMenuVisible: false,
            spinnerCount: 0,
            selectedLanguage: "",
            isPageInitLoaded: false,
            isPageRecurringLoaded: false,
            	        TM_UserRoleByUserId: [],
	        TM_GetProductDetailByStoreAndProduct: [],
	        TM_GetAvailableLeadsForReservation: [],
	        TM_GetReservedLeadsByStoreCode: [],
	        TM_GetReserveShowByProductCode: [],
	        GoBack: "",
	        NAVIGATE: "",
	        isComp975402Visible: 'hidden',
	        isComp3848Visible: 'hidden',
	        isComp830942Visible: 'hidden',
	        isComp880448Visible: 'hidden',
	        isComp444172Visible: 'hidden',
	        isComp651584Visible: 'hidden',
	        isComp874315Visible: 'hidden',
	        isComp810345Visible: 'hidden',
	        isComp949352Visible: 'hidden',
	        isComp260929Enabled: 'disabled',
	        isComp467475Enabled: 'disabled',
	        isComp404140Enabled: 'disabled',

        }

        this.state.isPageVisible = true;
        
    }

    async componentDidMount() {

        if (KuikaAppManager.isPageInitPrevented()) {
            KuikaAppManager.calculateAndSetBodyHeight("stocklistdetail", "masterscreen_screen");
            return;
        }
        this.context.registerCallbackFunction(this.callCallbackFunction.bind(this));
        
        ReactSystemFunctions.validateToken()
        this.fillFormInitValues();
        if (false){
            await this.StockListDetailPageInit();
        } else if (this.context?.isMasterPageInitLoaded) { this._prevMasterPageInitLoaded = true; await this.StockListDetailPageInit(); }
        
        
        
        KuikaAppManager.calculateAndSetBodyHeight("stocklistdetail", "masterscreen_screen");

        if (ReactSystemFunctions.getIsMicroApp() === false) {
           window.parentScreen = this;
        }
    }

    componentWillUnmount() {
        
        
        

        if (ReactSystemFunctions.getIsMicroApp() === false) {
           window.parentScreen = null;
        }
    }

    

        
    componentDidUpdate= async (prevProps, prevState) => {
		KuikaAppManager.calculateAndSetBodyHeight("stocklistdetail", "masterscreen_screen"    );
        if (prevProps?.location?.search !== (this.props as any)?.location?.search) {
			await this.StockListDetailPageInit();
		}

        		if (this._prevMasterPageInitLoaded !== this.context.isMasterPageInitLoaded && this.context.isMasterPageInitLoaded === true) {this._prevMasterPageInitLoaded = this.context.isMasterPageInitLoaded;await this.StockListDetailPageInit()}


        if (ReactSystemFunctions.getIsMicroApp() === false) {
            for (const key in prevState) {
                if (key.startsWith('NavVisible') && prevState[key] === true && this.state[key] === false) {
                    window.parentScreen = this;
                    break;
                }
            }
        }
	}

    fillFormInitValues() {
        this.props.form?.setFieldsValue({
});

    }

      setPageInitLoaded = (value: boolean) => {
        this.setState({ isPageInitLoaded: value });
      }

      setPageRecurringLoaded = (value: boolean) => {
        this.setState({ isPageRecurringLoaded: value });
      }

      clearFieldValidation = (changedValues: any) => {
        const fieldName = Object.keys(changedValues)[0];
        if (fieldName) {
          this.props.form?.setFields([
            {
              name: fieldName,
              errors: []
            }
          ]);
        }
      };

      

    StockListDetailPageInit = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


	if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }

        let localVar = {
			UserID_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.getMyUserId(), "Guid"),
			StoreCode_1: ReactSystemFunctions.convertToTypeByName(this.props.screenInputs.StoreCode ?? this.props.screenInputs.storecode, "string"),
			ProductCode_1: ReactSystemFunctions.convertToTypeByName(this.props.screenInputs.ProductCode ?? this.props.screenInputs.productcode, "string"),
			StoreCode_2: ReactSystemFunctions.convertToTypeByName(this.props.screenInputs.StoreCode ?? this.props.screenInputs.storecode, "string"),
			ProductId_2: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, (stateVars.TM_GetProductDetailByStoreAndProduct !== undefined ? (stateVars.TM_GetProductDetailByStoreAndProduct?.length > 0 ? stateVars.TM_GetProductDetailByStoreAndProduct[0].productId : null) : (this.state.TM_GetProductDetailByStoreAndProduct?.length > 0 ? this.state.TM_GetProductDetailByStoreAndProduct[0].productId : null))), "Guid"),
			SearchText_2: ReactSystemFunctions.convertToTypeByName(null, "string"),
			StoreCode_3: ReactSystemFunctions.convertToTypeByName(this.props.screenInputs.StoreCode ?? this.props.screenInputs.storecode, "string"),
			ProductId_3: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, (stateVars.TM_GetProductDetailByStoreAndProduct !== undefined ? (stateVars.TM_GetProductDetailByStoreAndProduct?.length > 0 ? stateVars.TM_GetProductDetailByStoreAndProduct[0].productId : null) : (this.state.TM_GetProductDetailByStoreAndProduct?.length > 0 ? this.state.TM_GetProductDetailByStoreAndProduct[0].productId : null))), "Guid"),
			SearchText_3: ReactSystemFunctions.convertToTypeByName(null, "string"),
			UserRole_4: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, (stateVars.TM_UserRoleByUserId !== undefined ? (stateVars.TM_UserRoleByUserId?.length > 0 ? stateVars.TM_UserRoleByUserId[0].roleNames : null) : (this.state.TM_UserRoleByUserId?.length > 0 ? this.state.TM_UserRoleByUserId[0].roleNames : null))), "string"),
			ProductCode_4: ReactSystemFunctions.convertToTypeByName(this.props.screenInputs.ProductCode ?? this.props.screenInputs.productcode, "string")
        }

	KuikaAppManager.showSpinner(this);
	
        if (true) {
        KuikaAppManager.showSpinner(this);
        }
        let result = await KuikaAppManager.ApiRequest(this, "StockListDetail/StockListDetailPageInit", localVar)
        if (!KMainFunctions.IsResStatus2XX(result)) return true;

		stateVars.TM_UserRoleByUserId = result?.data.tM_UserRoleByUserId;
		stateVars.TM_GetProductDetailByStoreAndProduct = result?.data.tM_GetProductDetailByStoreAndProduct;
		formVars.stocklistdetail_738501_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetProductDetailByStoreAndProduct !== undefined ? (stateVars.TM_GetProductDetailByStoreAndProduct?.length > 0 ? stateVars.TM_GetProductDetailByStoreAndProduct[0].productName : null) : (this.state.TM_GetProductDetailByStoreAndProduct?.length > 0 ? this.state.TM_GetProductDetailByStoreAndProduct[0].productName : null)));
		formVars.stocklistdetail_532179_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetProductDetailByStoreAndProduct !== undefined ? (stateVars.TM_GetProductDetailByStoreAndProduct?.length > 0 ? stateVars.TM_GetProductDetailByStoreAndProduct[0].referance : null) : (this.state.TM_GetProductDetailByStoreAndProduct?.length > 0 ? this.state.TM_GetProductDetailByStoreAndProduct[0].referance : null)));
		formVars.stocklistdetail_550721_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetProductDetailByStoreAndProduct !== undefined ? (stateVars.TM_GetProductDetailByStoreAndProduct?.length > 0 ? stateVars.TM_GetProductDetailByStoreAndProduct[0].dial : null) : (this.state.TM_GetProductDetailByStoreAndProduct?.length > 0 ? this.state.TM_GetProductDetailByStoreAndProduct[0].dial : null)));
		formVars.stocklistdetail_343920_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetProductDetailByStoreAndProduct !== undefined ? (stateVars.TM_GetProductDetailByStoreAndProduct?.length > 0 ? stateVars.TM_GetProductDetailByStoreAndProduct[0].bracelet : null) : (this.state.TM_GetProductDetailByStoreAndProduct?.length > 0 ? this.state.TM_GetProductDetailByStoreAndProduct[0].bracelet : null)));
		formVars.stocklistdetail_975402_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetProductDetailByStoreAndProduct !== undefined ? (stateVars.TM_GetProductDetailByStoreAndProduct?.length > 0 ? stateVars.TM_GetProductDetailByStoreAndProduct[0].categoryName : null) : (this.state.TM_GetProductDetailByStoreAndProduct?.length > 0 ? this.state.TM_GetProductDetailByStoreAndProduct[0].categoryName : null)));
		formVars.stocklistdetail_3848_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetProductDetailByStoreAndProduct !== undefined ? (stateVars.TM_GetProductDetailByStoreAndProduct?.length > 0 ? stateVars.TM_GetProductDetailByStoreAndProduct[0].categoryName : null) : (this.state.TM_GetProductDetailByStoreAndProduct?.length > 0 ? this.state.TM_GetProductDetailByStoreAndProduct[0].categoryName : null)));
		formVars.stocklistdetail_830942_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetProductDetailByStoreAndProduct !== undefined ? (stateVars.TM_GetProductDetailByStoreAndProduct?.length > 0 ? stateVars.TM_GetProductDetailByStoreAndProduct[0].categoryName : null) : (this.state.TM_GetProductDetailByStoreAndProduct?.length > 0 ? this.state.TM_GetProductDetailByStoreAndProduct[0].categoryName : null)));
		formVars.stocklistdetail_880448_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetProductDetailByStoreAndProduct !== undefined ? (stateVars.TM_GetProductDetailByStoreAndProduct?.length > 0 ? stateVars.TM_GetProductDetailByStoreAndProduct[0].categoryName : null) : (this.state.TM_GetProductDetailByStoreAndProduct?.length > 0 ? this.state.TM_GetProductDetailByStoreAndProduct[0].categoryName : null)));
		formVars.stocklistdetail_912798_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetProductDetailByStoreAndProduct !== undefined ? (stateVars.TM_GetProductDetailByStoreAndProduct?.length > 0 ? stateVars.TM_GetProductDetailByStoreAndProduct[0].ofis : null) : (this.state.TM_GetProductDetailByStoreAndProduct?.length > 0 ? this.state.TM_GetProductDetailByStoreAndProduct[0].ofis : null)));
		formVars.stocklistdetail_167067_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetProductDetailByStoreAndProduct !== undefined ? (stateVars.TM_GetProductDetailByStoreAndProduct?.length > 0 ? stateVars.TM_GetProductDetailByStoreAndProduct[0].toplamStok : null) : (this.state.TM_GetProductDetailByStoreAndProduct?.length > 0 ? this.state.TM_GetProductDetailByStoreAndProduct[0].toplamStok : null)));
		formVars.stocklistdetail_945391_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetProductDetailByStoreAndProduct !== undefined ? (stateVars.TM_GetProductDetailByStoreAndProduct?.length > 0 ? stateVars.TM_GetProductDetailByStoreAndProduct[0].rezerveStok : null) : (this.state.TM_GetProductDetailByStoreAndProduct?.length > 0 ? this.state.TM_GetProductDetailByStoreAndProduct[0].rezerveStok : null)));
		formVars.stocklistdetail_656839_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetProductDetailByStoreAndProduct !== undefined ? (stateVars.TM_GetProductDetailByStoreAndProduct?.length > 0 ? stateVars.TM_GetProductDetailByStoreAndProduct[0].musaitStok : null) : (this.state.TM_GetProductDetailByStoreAndProduct?.length > 0 ? this.state.TM_GetProductDetailByStoreAndProduct[0].musaitStok : null)));
		stateVars.isComp975402Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.toString(this, (stateVars.TM_GetProductDetailByStoreAndProduct !== undefined ? (stateVars.TM_GetProductDetailByStoreAndProduct?.length > 0 ? stateVars.TM_GetProductDetailByStoreAndProduct[0].categoryName : null) : (this.state.TM_GetProductDetailByStoreAndProduct?.length > 0 ? this.state.TM_GetProductDetailByStoreAndProduct[0].categoryName : null))), ReactSystemFunctions.convertToTypeByName("Kategori 3", "string"))) === true ? "visible" : "hidden")
		stateVars.isComp3848Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.toString(this, (stateVars.TM_GetProductDetailByStoreAndProduct !== undefined ? (stateVars.TM_GetProductDetailByStoreAndProduct?.length > 0 ? stateVars.TM_GetProductDetailByStoreAndProduct[0].categoryName : null) : (this.state.TM_GetProductDetailByStoreAndProduct?.length > 0 ? this.state.TM_GetProductDetailByStoreAndProduct[0].categoryName : null))), ReactSystemFunctions.convertToTypeByName("Kategori 2", "string"))) === true ? "visible" : "hidden")
		stateVars.isComp830942Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.toString(this, (stateVars.TM_GetProductDetailByStoreAndProduct !== undefined ? (stateVars.TM_GetProductDetailByStoreAndProduct?.length > 0 ? stateVars.TM_GetProductDetailByStoreAndProduct[0].categoryName : null) : (this.state.TM_GetProductDetailByStoreAndProduct?.length > 0 ? this.state.TM_GetProductDetailByStoreAndProduct[0].categoryName : null))), ReactSystemFunctions.convertToTypeByName("Kategori 1", "string"))) === true ? "visible" : "hidden")
		stateVars.isComp880448Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.toString(this, (stateVars.TM_GetProductDetailByStoreAndProduct !== undefined ? (stateVars.TM_GetProductDetailByStoreAndProduct?.length > 0 ? stateVars.TM_GetProductDetailByStoreAndProduct[0].categoryName : null) : (this.state.TM_GetProductDetailByStoreAndProduct?.length > 0 ? this.state.TM_GetProductDetailByStoreAndProduct[0].categoryName : null))), ReactSystemFunctions.convertToTypeByName("DEFAULT", "string"))) === true ? "visible" : "hidden")
		stateVars.isComp260929Enabled = ((ReactSystemFunctions.isNotEqualTo(ReactSystemFunctions.value(this, (stateVars.TM_GetProductDetailByStoreAndProduct !== undefined ? (stateVars.TM_GetProductDetailByStoreAndProduct?.length > 0 ? stateVars.TM_GetProductDetailByStoreAndProduct[0].musaitStok : null) : (this.state.TM_GetProductDetailByStoreAndProduct?.length > 0 ? this.state.TM_GetProductDetailByStoreAndProduct[0].musaitStok : null))), ReactSystemFunctions.convertToTypeByName("0", "string"))) === true ? "enabled" : "disabled")
		stateVars.TM_GetAvailableLeadsForReservation = result?.data.tM_GetAvailableLeadsForReservation;
		
		stateVars.TM_GetReservedLeadsByStoreCode = result?.data.tM_GetReservedLeadsByStoreCode;
		
		stateVars.TM_GetReserveShowByProductCode = result?.data.tM_GetReserveShowByProductCode;
		this.props.form?.setFieldsValue(formVars);
		
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.StockListDetailPageInit1_();
                  resolve();
                });
          })



        
        KuikaAppManager.hideSpinner(this);
        return isErrorOccurred;
    }
	StockListDetailPageInit1_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


	if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }

			formVars.stocklistdetail_738501_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetProductDetailByStoreAndProduct !== undefined ? (stateVars.TM_GetProductDetailByStoreAndProduct?.length > 0 ? stateVars.TM_GetProductDetailByStoreAndProduct[0].productName : null) : (this.state.TM_GetProductDetailByStoreAndProduct?.length > 0 ? this.state.TM_GetProductDetailByStoreAndProduct[0].productName : null)));

			formVars.stocklistdetail_532179_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetProductDetailByStoreAndProduct !== undefined ? (stateVars.TM_GetProductDetailByStoreAndProduct?.length > 0 ? stateVars.TM_GetProductDetailByStoreAndProduct[0].referance : null) : (this.state.TM_GetProductDetailByStoreAndProduct?.length > 0 ? this.state.TM_GetProductDetailByStoreAndProduct[0].referance : null)));

			formVars.stocklistdetail_550721_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetProductDetailByStoreAndProduct !== undefined ? (stateVars.TM_GetProductDetailByStoreAndProduct?.length > 0 ? stateVars.TM_GetProductDetailByStoreAndProduct[0].dial : null) : (this.state.TM_GetProductDetailByStoreAndProduct?.length > 0 ? this.state.TM_GetProductDetailByStoreAndProduct[0].dial : null)));

			formVars.stocklistdetail_343920_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetProductDetailByStoreAndProduct !== undefined ? (stateVars.TM_GetProductDetailByStoreAndProduct?.length > 0 ? stateVars.TM_GetProductDetailByStoreAndProduct[0].bracelet : null) : (this.state.TM_GetProductDetailByStoreAndProduct?.length > 0 ? this.state.TM_GetProductDetailByStoreAndProduct[0].bracelet : null)));

			formVars.stocklistdetail_975402_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetProductDetailByStoreAndProduct !== undefined ? (stateVars.TM_GetProductDetailByStoreAndProduct?.length > 0 ? stateVars.TM_GetProductDetailByStoreAndProduct[0].categoryName : null) : (this.state.TM_GetProductDetailByStoreAndProduct?.length > 0 ? this.state.TM_GetProductDetailByStoreAndProduct[0].categoryName : null)));

			stateVars.isComp975402Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.toString(this, (stateVars.TM_GetProductDetailByStoreAndProduct !== undefined ? (stateVars.TM_GetProductDetailByStoreAndProduct?.length > 0 ? stateVars.TM_GetProductDetailByStoreAndProduct[0].categoryName : null) : (this.state.TM_GetProductDetailByStoreAndProduct?.length > 0 ? this.state.TM_GetProductDetailByStoreAndProduct[0].categoryName : null))), ReactSystemFunctions.convertToTypeByName("Kategori 3", "string"))) === true ? "visible" : "hidden")
			formVars.stocklistdetail_3848_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetProductDetailByStoreAndProduct !== undefined ? (stateVars.TM_GetProductDetailByStoreAndProduct?.length > 0 ? stateVars.TM_GetProductDetailByStoreAndProduct[0].categoryName : null) : (this.state.TM_GetProductDetailByStoreAndProduct?.length > 0 ? this.state.TM_GetProductDetailByStoreAndProduct[0].categoryName : null)));

			stateVars.isComp3848Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.toString(this, (stateVars.TM_GetProductDetailByStoreAndProduct !== undefined ? (stateVars.TM_GetProductDetailByStoreAndProduct?.length > 0 ? stateVars.TM_GetProductDetailByStoreAndProduct[0].categoryName : null) : (this.state.TM_GetProductDetailByStoreAndProduct?.length > 0 ? this.state.TM_GetProductDetailByStoreAndProduct[0].categoryName : null))), ReactSystemFunctions.convertToTypeByName("Kategori 2", "string"))) === true ? "visible" : "hidden")
			formVars.stocklistdetail_830942_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetProductDetailByStoreAndProduct !== undefined ? (stateVars.TM_GetProductDetailByStoreAndProduct?.length > 0 ? stateVars.TM_GetProductDetailByStoreAndProduct[0].categoryName : null) : (this.state.TM_GetProductDetailByStoreAndProduct?.length > 0 ? this.state.TM_GetProductDetailByStoreAndProduct[0].categoryName : null)));

			stateVars.isComp830942Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.toString(this, (stateVars.TM_GetProductDetailByStoreAndProduct !== undefined ? (stateVars.TM_GetProductDetailByStoreAndProduct?.length > 0 ? stateVars.TM_GetProductDetailByStoreAndProduct[0].categoryName : null) : (this.state.TM_GetProductDetailByStoreAndProduct?.length > 0 ? this.state.TM_GetProductDetailByStoreAndProduct[0].categoryName : null))), ReactSystemFunctions.convertToTypeByName("Kategori 1", "string"))) === true ? "visible" : "hidden")
			formVars.stocklistdetail_880448_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetProductDetailByStoreAndProduct !== undefined ? (stateVars.TM_GetProductDetailByStoreAndProduct?.length > 0 ? stateVars.TM_GetProductDetailByStoreAndProduct[0].categoryName : null) : (this.state.TM_GetProductDetailByStoreAndProduct?.length > 0 ? this.state.TM_GetProductDetailByStoreAndProduct[0].categoryName : null)));

			stateVars.isComp880448Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.toString(this, (stateVars.TM_GetProductDetailByStoreAndProduct !== undefined ? (stateVars.TM_GetProductDetailByStoreAndProduct?.length > 0 ? stateVars.TM_GetProductDetailByStoreAndProduct[0].categoryName : null) : (this.state.TM_GetProductDetailByStoreAndProduct?.length > 0 ? this.state.TM_GetProductDetailByStoreAndProduct[0].categoryName : null))), ReactSystemFunctions.convertToTypeByName("DEFAULT", "string"))) === true ? "visible" : "hidden")
			formVars.stocklistdetail_912798_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetProductDetailByStoreAndProduct !== undefined ? (stateVars.TM_GetProductDetailByStoreAndProduct?.length > 0 ? stateVars.TM_GetProductDetailByStoreAndProduct[0].ofis : null) : (this.state.TM_GetProductDetailByStoreAndProduct?.length > 0 ? this.state.TM_GetProductDetailByStoreAndProduct[0].ofis : null)));

			formVars.stocklistdetail_167067_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetProductDetailByStoreAndProduct !== undefined ? (stateVars.TM_GetProductDetailByStoreAndProduct?.length > 0 ? stateVars.TM_GetProductDetailByStoreAndProduct[0].toplamStok : null) : (this.state.TM_GetProductDetailByStoreAndProduct?.length > 0 ? this.state.TM_GetProductDetailByStoreAndProduct[0].toplamStok : null)));

			formVars.stocklistdetail_945391_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetProductDetailByStoreAndProduct !== undefined ? (stateVars.TM_GetProductDetailByStoreAndProduct?.length > 0 ? stateVars.TM_GetProductDetailByStoreAndProduct[0].rezerveStok : null) : (this.state.TM_GetProductDetailByStoreAndProduct?.length > 0 ? this.state.TM_GetProductDetailByStoreAndProduct[0].rezerveStok : null)));

			formVars.stocklistdetail_656839_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetProductDetailByStoreAndProduct !== undefined ? (stateVars.TM_GetProductDetailByStoreAndProduct?.length > 0 ? stateVars.TM_GetProductDetailByStoreAndProduct[0].musaitStok : null) : (this.state.TM_GetProductDetailByStoreAndProduct?.length > 0 ? this.state.TM_GetProductDetailByStoreAndProduct[0].musaitStok : null)));

			
			stateVars.dataSource_894993 = stateVars.TM_GetAvailableLeadsForReservation ?? this.state.TM_GetAvailableLeadsForReservation;
			stateVars.isComp260929Enabled = ((ReactSystemFunctions.isNotEqualTo(ReactSystemFunctions.value(this, (stateVars.TM_GetProductDetailByStoreAndProduct !== undefined ? (stateVars.TM_GetProductDetailByStoreAndProduct?.length > 0 ? stateVars.TM_GetProductDetailByStoreAndProduct[0].musaitStok : null) : (this.state.TM_GetProductDetailByStoreAndProduct?.length > 0 ? this.state.TM_GetProductDetailByStoreAndProduct[0].musaitStok : null))), ReactSystemFunctions.convertToTypeByName("0", "string"))) === true ? "enabled" : "disabled")
			formVars.stocklistdetail_368223_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetReservedLeadsByStoreCode !== undefined ? (stateVars.TM_GetReservedLeadsByStoreCode?.length > 0 ? stateVars.TM_GetReservedLeadsByStoreCode[0].leadCode : null) : (this.state.TM_GetReservedLeadsByStoreCode?.length > 0 ? this.state.TM_GetReservedLeadsByStoreCode[0].leadCode : null)));

			formVars.stocklistdetail_158038_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetProductDetailByStoreAndProduct !== undefined ? (stateVars.TM_GetProductDetailByStoreAndProduct?.length > 0 ? stateVars.TM_GetProductDetailByStoreAndProduct[0].productName : null) : (this.state.TM_GetProductDetailByStoreAndProduct?.length > 0 ? this.state.TM_GetProductDetailByStoreAndProduct[0].productName : null)));

			stateVars.isComp444172Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, "stocklistdetail_894993_value", "processName"), ReactSystemFunctions.convertToTypeByName("Onaylandı", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp651584Visible = ((ReactSystemFunctions.isNotEmpty(ReactSystemFunctions.value(this, "stocklistdetail_894993_value", "terminTarihi"), ReactSystemFunctions.convertToTypeByName("True", "string"))) === true ? "visible" : "hidden")
			
			stateVars.dataSource_999335 = stateVars.TM_GetReservedLeadsByStoreCode ?? this.state.TM_GetReservedLeadsByStoreCode;
			formVars.stocklistdetail_845834_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetReservedLeadsByStoreCode !== undefined ? (stateVars.TM_GetReservedLeadsByStoreCode?.length > 0 ? stateVars.TM_GetReservedLeadsByStoreCode[0].leadCode : null) : (this.state.TM_GetReservedLeadsByStoreCode?.length > 0 ? this.state.TM_GetReservedLeadsByStoreCode[0].leadCode : null)));

			formVars.stocklistdetail_108598_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetProductDetailByStoreAndProduct !== undefined ? (stateVars.TM_GetProductDetailByStoreAndProduct?.length > 0 ? stateVars.TM_GetProductDetailByStoreAndProduct[0].productName : null) : (this.state.TM_GetProductDetailByStoreAndProduct?.length > 0 ? this.state.TM_GetProductDetailByStoreAndProduct[0].productName : null)));

			stateVars.isComp874315Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, "stocklistdetail_999335_value", "processName"), ReactSystemFunctions.convertToTypeByName("Teslim Bekliyor", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp810345Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, "stocklistdetail_999335_value", "reserveStatus"), ReactSystemFunctions.convertToTypeByName("1", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp949352Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, "stocklistdetail_999335_value", "reserveStatus"), ReactSystemFunctions.convertToTypeByName("0", "string"))) === true ? "visible" : "hidden")
			formVars.stocklistdetail_79893_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetReservedLeadsByStoreCode !== undefined ? (stateVars.TM_GetReservedLeadsByStoreCode?.length > 0 ? stateVars.TM_GetReservedLeadsByStoreCode[0].musteri : null) : (this.state.TM_GetReservedLeadsByStoreCode?.length > 0 ? this.state.TM_GetReservedLeadsByStoreCode[0].musteri : null)));

			formVars.stocklistdetail_579282_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetReservedLeadsByStoreCode !== undefined ? (stateVars.TM_GetReservedLeadsByStoreCode?.length > 0 ? stateVars.TM_GetReservedLeadsByStoreCode[0].email : null) : (this.state.TM_GetReservedLeadsByStoreCode?.length > 0 ? this.state.TM_GetReservedLeadsByStoreCode[0].email : null)));

			formVars.stocklistdetail_130566_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetReservedLeadsByStoreCode !== undefined ? (stateVars.TM_GetReservedLeadsByStoreCode?.length > 0 ? stateVars.TM_GetReservedLeadsByStoreCode[0].telefon : null) : (this.state.TM_GetReservedLeadsByStoreCode?.length > 0 ? this.state.TM_GetReservedLeadsByStoreCode[0].telefon : null)));

			formVars.stocklistdetail_704195_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetReservedLeadsByStoreCode !== undefined ? (stateVars.TM_GetReservedLeadsByStoreCode?.length > 0 ? stateVars.TM_GetReservedLeadsByStoreCode[0].reservedBy : null) : (this.state.TM_GetReservedLeadsByStoreCode?.length > 0 ? this.state.TM_GetReservedLeadsByStoreCode[0].reservedBy : null)));

			formVars.stocklistdetail_149671_value = ReactSystemFunctions.value(this, (stateVars.TM_GetReservedLeadsByStoreCode !== undefined ? (stateVars.TM_GetReservedLeadsByStoreCode?.length > 0 ? stateVars.TM_GetReservedLeadsByStoreCode[0].rezervBaslangic : null) : (this.state.TM_GetReservedLeadsByStoreCode?.length > 0 ? this.state.TM_GetReservedLeadsByStoreCode[0].rezervBaslangic : null)));

			stateVars.isComp467475Enabled = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, "stocklistdetail_999335_value", "reserveStatus"), ReactSystemFunctions.convertToTypeByName("0", "string"))) === true ? "enabled" : "disabled")
			stateVars.isComp404140Enabled = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, "stocklistdetail_999335_value", "reserveStatus"), ReactSystemFunctions.convertToTypeByName("1", "string"))) === true ? "enabled" : "disabled")

	this.props.form?.setFieldsValue(formVars);
	this.setState(stateVars);
	KuikaAppManager.hideSpinner(this);

            this.setPageInitLoaded(true);
            return isErrorOccurred;
        }




		StockListDetailComponent_942103_onClick = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
KuikaAppManager.showSpinner(this);

				stateVars.GoBack = await ReactSystemFunctions.goBack(this, false);

		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

            
            return isErrorOccurred;
        }


    StockListDetailComponent_988953_onChange = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
		KuikaAppManager.increaseServerRequestCount();

        let localVar = {
				StoreCode_0: ReactSystemFunctions.convertToTypeByName(this.props.screenInputs.StoreCode ?? this.props.screenInputs.storecode, "string"),
				ProductId_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, (stateVars.TM_GetProductDetailByStoreAndProduct !== undefined ? (stateVars.TM_GetProductDetailByStoreAndProduct?.length > 0 ? stateVars.TM_GetProductDetailByStoreAndProduct[0].productId : null) : (this.state.TM_GetProductDetailByStoreAndProduct?.length > 0 ? this.state.TM_GetProductDetailByStoreAndProduct[0].productId : null))), "Guid"),
				SearchText_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "stocklistdetail_988953_value", "value", "", "", "")), "string")
        }

		KuikaAppManager.showSpinner(this);
		
        if (true) {
        KuikaAppManager.showSpinner(this);
        }
        let result = await KuikaAppManager.ApiRequest(this, "StockListDetail/StockListDetailComponent_988953_onChange", localVar)
        if (!KMainFunctions.IsResStatus2XX(result)) return true;

			stateVars.TM_GetAvailableLeadsForReservation = result?.data.tM_GetAvailableLeadsForReservation;
			
			this.props.form?.setFieldsValue(formVars);
			
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.StockListDetailComponent_988953_onChange1_();
                  resolve();
                });
          })



        
        KuikaAppManager.hideSpinner(this);
        return isErrorOccurred;
    }
		StockListDetailComponent_988953_onChange1_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }

				
				stateVars.dataSource_894993 = stateVars.TM_GetAvailableLeadsForReservation ?? this.state.TM_GetAvailableLeadsForReservation;

		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

            
            return isErrorOccurred;
        }




		StockListDetailComponent_289133_onClick = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
KuikaAppManager.showSpinner(this);

					KuikaAppManager.prepareForNavigation();
						KuikaAppManager.addToPageInputVariables("ReservationPopUp", "StoreCode", ReactSystemFunctions.convertToTypeByName(this.props.screenInputs.StoreCode ?? this.props.screenInputs.storecode, "string"));
						KuikaAppManager.addToPageInputVariables("ReservationPopUp", "ProductCode", ReactSystemFunctions.convertToTypeByName(this.props.screenInputs.ProductCode ?? this.props.screenInputs.productcode, "string"));
						KuikaAppManager.addToPageInputVariables("ReservationPopUp", "LeadId", ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, "stocklistdetail_894993_value", "id"), "Guid"));

				stateVars.NAVIGATE = await ReactSystemFunctions.navigate(this, undefined, "StockListDetail", "ReservationPopUp", "", "9924ef5f-4b84-4200-b624-8d76348c7686", "468381", null, null, "true", "800px", "70vh", true, false);

		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

            
            return isErrorOccurred;
        }


		StockListDetailComponent_467475_onClick = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
KuikaAppManager.showSpinner(this);

					KuikaAppManager.prepareForNavigation();
						KuikaAppManager.addToPageInputVariables("ReservationEdit", "LeadId", ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, "stocklistdetail_999335_value", "id"), "Guid"));

				stateVars.NAVIGATE = await ReactSystemFunctions.navigate(this, undefined, "StockListDetail", "ReservationEdit", "", "7d969ddf-5801-4eb6-b92b-12be35bdd565", "330002", null, "right", "true", "60%", "100vh", true, false);

		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

            
            return isErrorOccurred;
        }




    async callCallbackFunction(diId: number, isFromMaster: boolean = false) {
        let isErrorOccurred = false;
		let pageInitCallerNavDiIDs = [468381, 330002] as number[];
		if (isFromMaster || pageInitCallerNavDiIDs.indexOf(diId) > -1) {
			await this.StockListDetailPageInit();
		}

    }


}
