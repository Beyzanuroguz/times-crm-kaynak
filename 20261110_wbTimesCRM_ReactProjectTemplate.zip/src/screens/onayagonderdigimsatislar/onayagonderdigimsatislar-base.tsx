import React from "react";
import Axios, { AxiosResponse } from "axios";
import { KuikaAppManager } from "../../shared/utilty/kuika-app-manager";
import { ReactSystemFunctions } from "../../shared/utilty/react-system-functions";
import { KNavigator } from "../../shared/hoc/with-history";
import { KContext } from "../../shared/hoc/with-context";
import { useLocation } from "react-router-dom";
import { FormInstance } from "antd/es/form";
import { Guid } from "guid-typescript";
import Swal from "sweetalert2";
import { KMainFunctions } from "../../shared/utilty/main-functions";
import moment from "moment";
import { IValidationData } from "../../models/dto/validation-data";
import { IStripePayment } from "../../models/dto/stripe-payment";
import { IUserInfoDto } from "../../models/dto/user-info.dto";
import { UserService } from "../../services/user-service";
import { kuikaCoreWasmBridgeService } from "../../services/_singletons";
import _ from "lodash";
import mqtt, { MqttClient } from "mqtt";
import { IMqttResult } from "../../models/dto/mqtt.dto";
import { MasterScreen_ScreenContext } from "../masterscreen/masterscreen-context";

declare let window: any;

export interface IOnayaGonderdigimSatislar_ScreenProps {
  navigator: KNavigator;
  form: FormInstance<any>;
  googleLogin: any;
  screenInputs: any;
  context: KContext;
  initialValues: any;
  children: any;
}

export interface IOnayaGonderdigimSatislar_ScreenState {
    isSpinnerVisible: boolean;
    isPageVisible: boolean;
	isLeftMenuVisible: boolean;
    spinnerCount: number;
    selectedLanguage: string;
    isPageInitLoaded: false;
    isPageRecurringLoaded: false;
	TM_GetMyThirdPartyInvoiceSales: any[];
	TM_GetMyThirdPartyInvoiceSales_dummy: any[];
	NAVIGATE: any;
	NAVIGATE_dummy: any;
	isComp106558236Visible: 'visible' | 'hidden';

}

export class OnayaGonderdigimSatislar_ScreenBase extends React.PureComponent<IOnayaGonderdigimSatislar_ScreenProps, any> {
    static contextType = MasterScreen_ScreenContext;
    declare context: React.ContextType<typeof MasterScreen_ScreenContext>;
	onayagonderdigimsatislar_339088756_value_kuikaTableRef: React.RefObject<any>;
	onayagonderdigimsatislar_2100738641_value_kuikaDatetimeRef: React.RefObject<any>;
    ml=[{"Id":"d5a61d2b-bd60-485f-86e2-661e9ed4e486","Name":"en_US","ShortName":"English","IsDefault":true,"LanguagePhrases":[]},{"Id":"22b05fdc-cc7b-4749-8f29-2124dbb4689b","Name":"FixedValues","ShortName":"FixedValues","LanguagePhrases":[{"Id":1945683125,"PropertyName":"value","Value":"SATIŞ ONAY TAKİBİ"},{"Id":1540358581,"PropertyName":"value","Value":"Onaya Gönderdiğim Satışlar"},{"Id":1974964990,"PropertyName":"value","Value":"3. kişi adına faturalandırma talebi oluşturduğunuz satışları takip edin ve onaylanan satışlara kaldığınız yerden devam edin."},{"Id":1713149365,"PropertyName":"value","Value":"3. Kişi Faturalandırma"},{"Id":762182732,"PropertyName":"value","Value":"Onay bekleyen satışlar faturalandırılamaz. Yönetici onayından sonra Satışı Aç butonunu kullanarak satış ekranına dönebilir ve işlemi tamamlayabilirsiniz."},{"Id":1358636888,"PropertyName":"value","Value":"Onay Taleplerim"},{"Id":2035074983,"PropertyName":"value","Value":"Taleplerin güncel durumunu ve yönetici kararını buradan görüntüleyebilirsiniz."},{"Id":339088756,"PropertyName":"nodatafoundmessage","Value":"Henüz onay talebiniz bulunmuyor"},{"Id":993152119,"PropertyName":"title","Value":"Talep Tarihi"},{"Id":914533543,"PropertyName":"value","Value":"[datafield:requestedat]"},{"Id":2100738641,"PropertyName":"placeholder","Value":"Select Date Time..."},{"Id":1867265085,"PropertyName":"title","Value":"Fatura Edilecek Kişi / Şirket"},{"Id":775749109,"PropertyName":"value","Value":"[datafield:thirdpartyfullname]"},{"Id":467975767,"PropertyName":"placeholder","Value":"Type here..."},{"Id":161835240,"PropertyName":"title","Value":"Asıl Müşteri"},{"Id":779844779,"PropertyName":"value","Value":"[datafield:originalcustomerfullname]"},{"Id":1617374724,"PropertyName":"placeholder","Value":"Type here..."},{"Id":1546921560,"PropertyName":"title","Value":"Mağaza"},{"Id":819192080,"PropertyName":"value","Value":"[datafield:storename]"},{"Id":168084462,"PropertyName":"placeholder","Value":"Type here..."},{"Id":643590294,"PropertyName":"title","Value":"Satış Tutarı"},{"Id":847217348,"PropertyName":"value","Value":"[datafield:totalamounteur]"},{"Id":1851061153,"PropertyName":"placeholder","Value":"15"},{"Id":100655611,"PropertyName":"title","Value":"Para Birimi"},{"Id":450729218,"PropertyName":"value","Value":"[datafield:currencycode]"},{"Id":403781109,"PropertyName":"placeholder","Value":"Type here..."},{"Id":134300360,"PropertyName":"title","Value":"Durum"},{"Id":569141880,"PropertyName":"value","Value":"[datafield:approvalstatustext]"},{"Id":1530491075,"PropertyName":"placeholder","Value":"Type here..."},{"Id":1817399740,"PropertyName":"title","Value":"Yönetici Açıklaması"},{"Id":1231740142,"PropertyName":"value","Value":"[datafield:decisionnote]"},{"Id":1364601182,"PropertyName":"placeholder","Value":"Type here..."},{"Id":1184826033,"PropertyName":"title","Value":"İşlem"},{"Id":106558236,"PropertyName":"label","Value":"Satışı Aç"}]}]
    defaultML = "en_US"
    
    screenHash = ""
    

    private _prevMasterPageInitLoaded: boolean = false;
    private _prevMasterPageRecurringLoaded: boolean = false;
    private _prevShouldTriggerPageInit: boolean = false;
    constructor(props) {
        super(props);
		this.onayagonderdigimsatislar_339088756_value_kuikaTableRef = React.createRef();
		this.onayagonderdigimsatislar_2100738641_value_kuikaDatetimeRef = React.createRef();
		this.onayagonderdigimsatislar_467975767_value_kuikaTextInputRef = React.createRef();
		this.onayagonderdigimsatislar_1617374724_value_kuikaTextInputRef = React.createRef();
		this.onayagonderdigimsatislar_168084462_value_kuikaTextInputRef = React.createRef();
		this.onayagonderdigimsatislar_403781109_value_kuikaTextInputRef = React.createRef();
		this.onayagonderdigimsatislar_1530491075_value_kuikaTextInputRef = React.createRef();
		this.onayagonderdigimsatislar_1364601182_value_kuikaTextInputRef = React.createRef();

        this.state = {
            isSpinnerVisible: false,
            isPageVisible: false,
            isLeftMenuVisible: false,
            spinnerCount: 0,
            selectedLanguage: "",
            isPageInitLoaded: false,
            isPageRecurringLoaded: false,
            	        TM_GetMyThirdPartyInvoiceSales: [],
	        NAVIGATE: "",
	        isComp106558236Visible: 'hidden',

        }

        this.state.isPageVisible = true;
        
    }

    async componentDidMount() {

        if (KuikaAppManager.isPageInitPrevented()) {
            KuikaAppManager.calculateAndSetBodyHeight("onayagonderdigimsatislar", "masterscreen_screen");
            return;
        }
        this.context.registerCallbackFunction(this.callCallbackFunction.bind(this));
        
        ReactSystemFunctions.validateToken()
        this.fillFormInitValues();
        if (false){
            await this.OnayaGonderdigimSatislarPageInit();
        } else if (this.context?.isMasterPageInitLoaded) { this._prevMasterPageInitLoaded = true; await this.OnayaGonderdigimSatislarPageInit(); }
        
        
        
        KuikaAppManager.calculateAndSetBodyHeight("onayagonderdigimsatislar", "masterscreen_screen");

        if (ReactSystemFunctions.getIsMicroApp() === false) {
           window.parentScreen = this;
        }
    }

    componentWillUnmount() {
        
        
        

        if (ReactSystemFunctions.getIsMicroApp() === false) {
           window.parentScreen = null;
        }
    }

    

        
    componentDidUpdate= async (prevProps, prevState) => {
		KuikaAppManager.calculateAndSetBodyHeight("onayagonderdigimsatislar", "masterscreen_screen"    );
        if (prevProps?.location?.search !== (this.props as any)?.location?.search) {
			await this.OnayaGonderdigimSatislarPageInit();
		}

        		if (this._prevMasterPageInitLoaded !== this.context.isMasterPageInitLoaded && this.context.isMasterPageInitLoaded === true) {this._prevMasterPageInitLoaded = this.context.isMasterPageInitLoaded;await this.OnayaGonderdigimSatislarPageInit()}


        if (ReactSystemFunctions.getIsMicroApp() === false) {
            for (const key in prevState) {
                if (key.startsWith('NavVisible') && prevState[key] === true && this.state[key] === false) {
                    window.parentScreen = this;
                    break;
                }
            }
        }
	}

    fillFormInitValues() {
        this.props.form?.setFieldsValue({
});

    }

      setPageInitLoaded = (value: boolean) => {
        this.setState({ isPageInitLoaded: value });
      }

      setPageRecurringLoaded = (value: boolean) => {
        this.setState({ isPageRecurringLoaded: value });
      }

      clearFieldValidation = (changedValues: any) => {
        const fieldName = Object.keys(changedValues)[0];
        if (fieldName) {
          this.props.form?.setFields([
            {
              name: fieldName,
              errors: []
            }
          ]);
        }
      };

      

    OnayaGonderdigimSatislarPageInit = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


	if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }

        let localVar = {
			CurrentUserId_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.getMyUserId(), "Guid")
        }

	KuikaAppManager.showSpinner(this);
	
        if (true) {
        KuikaAppManager.showSpinner(this);
        }
        let result = await KuikaAppManager.ApiRequest(this, "OnayaGonderdigimSatislar/OnayaGonderdigimSatislarPageInit", localVar)
        if (!KMainFunctions.IsResStatus2XX(result)) return true;

		stateVars.TM_GetMyThirdPartyInvoiceSales = result?.data.tM_GetMyThirdPartyInvoiceSales;
		
		this.props.form?.setFieldsValue(formVars);
		
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.OnayaGonderdigimSatislarPageInit1_();
                  resolve();
                });
          })



        
        KuikaAppManager.hideSpinner(this);
        return isErrorOccurred;
    }
	OnayaGonderdigimSatislarPageInit1_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


	if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }

			
			stateVars.dataSource_339088756 = stateVars.TM_GetMyThirdPartyInvoiceSales ?? this.state.TM_GetMyThirdPartyInvoiceSales;
			stateVars.isComp106558236Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, "onayagonderdigimsatislar_339088756_value", "canOpen"), ReactSystemFunctions.convertToTypeByName("True", "string"))) === true ? "visible" : "hidden")

	this.props.form?.setFieldsValue(formVars);
	this.setState(stateVars);
	KuikaAppManager.hideSpinner(this);

            this.setPageInitLoaded(true);
            return isErrorOccurred;
        }




		OnayaGonderdigimSatislarComponent_106558236_onClick = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
if (ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, "onayagonderdigimsatislar_339088756_value", "saleFlowType"), "DIRECT")) {
            KuikaAppManager.showSpinner(this);

const __currentPath = (window.location.hash ? window.location.hash.replace(/^#/, '').split('?')[0] : window.location.pathname.split('?')[0]).toLowerCase();
if (__currentPath !== "/satisislemi") {
  this.context.setMasterPageInitLoaded(false);
  this.context.setMasterPageRecurringLoaded(false);
  this.context.setShouldTriggerPageInit(true);
}
					KuikaAppManager.prepareForNavigation();
						KuikaAppManager.addToPageInputVariables("SatisIslemi", "ApprovalId", ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, "onayagonderdigimsatislar_339088756_value", "approvalId"), "Guid"));
						KuikaAppManager.addToPageInputVariables("SatisIslemi", "SalesDraftId", ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, "onayagonderdigimsatislar_339088756_value", "salesDraftId"), "Guid"));

				stateVars.NAVIGATE = await ReactSystemFunctions.navigate(this, this.OnayaGonderdigimSatislarComponent_106558236_onClick1_, "OnayaGonderdigimSatislar", "SatisIslemi", "", "currentPage", null, null, null, null, null, null, true, false);

		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

        } else {
            
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.OnayaGonderdigimSatislarComponent_106558236_onClick1_();
                  resolve();
                });
          })
        }

            
            return isErrorOccurred;
        }
		OnayaGonderdigimSatislarComponent_106558236_onClick1_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
if (ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, "onayagonderdigimsatislar_339088756_value", "saleFlowType"), "LEAD")) {
            KuikaAppManager.showSpinner(this);

					KuikaAppManager.prepareForNavigation();
						KuikaAppManager.addToPageInputVariables("TalepSatisIslemi", "LeadId", ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, "onayagonderdigimsatislar_339088756_value", "leadId"), "Guid"));
						KuikaAppManager.addToPageInputVariables("TalepSatisIslemi", "ApprovalId", ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, "onayagonderdigimsatislar_339088756_value", "approvalId"), "Guid"));
						KuikaAppManager.addToPageInputVariables("TalepSatisIslemi", "SalesLeadDraftId", ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, "onayagonderdigimsatislar_339088756_value", "salesLeadDraftId"), "Guid"));

				stateVars.NAVIGATE = await ReactSystemFunctions.navigate(this, undefined, "OnayaGonderdigimSatislar", "TalepSatisIslemi", "", "currentPage", null, null, null, null, null, null, true, false);

		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

        } else {
            KuikaAppManager.hideSpinner(this);
        }

            
            return isErrorOccurred;
        }





    async callCallbackFunction(diId: number, isFromMaster: boolean = false) {
        let isErrorOccurred = false;
		let pageInitCallerNavDiIDs = [, ] as number[];
		if (isFromMaster || pageInitCallerNavDiIDs.indexOf(diId) > -1) {
			await this.OnayaGonderdigimSatislarPageInit();
		}

    }


}
