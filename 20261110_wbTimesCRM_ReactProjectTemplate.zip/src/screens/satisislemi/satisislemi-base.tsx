import React from "react";
import Axios, { AxiosResponse } from "axios";
import { KuikaAppManager } from "../../shared/utilty/kuika-app-manager";
import { ReactSystemFunctions } from "../../shared/utilty/react-system-functions";
import { KNavigator } from "../../shared/hoc/with-history";
import { KContext } from "../../shared/hoc/with-context";
import { useLocation } from "react-router-dom";
import { FormInstance } from "antd/es/form";
import { Guid } from "guid-typescript";
import Swal from "sweetalert2";
import { KMainFunctions } from "../../shared/utilty/main-functions";
import moment from "moment";
import { IValidationData } from "../../models/dto/validation-data";
import { IStripePayment } from "../../models/dto/stripe-payment";
import { IUserInfoDto } from "../../models/dto/user-info.dto";
import { UserService } from "../../services/user-service";
import { kuikaCoreWasmBridgeService } from "../../services/_singletons";
import _ from "lodash";
import mqtt, { MqttClient } from "mqtt";
import { IMqttResult } from "../../models/dto/mqtt.dto";
import { MasterScreen_ScreenContext } from "../masterscreen/masterscreen-context";

declare let window: any;

export interface ISatisIslemi_ScreenProps {
  navigator: KNavigator;
  form: FormInstance<any>;
  googleLogin: any;
  screenInputs: any;
  context: KContext;
  initialValues: any;
  children: any;
}

export interface ISatisIslemi_ScreenState {
    isSpinnerVisible: boolean;
    isPageVisible: boolean;
	isLeftMenuVisible: boolean;
    spinnerCount: number;
    selectedLanguage: string;
    isPageInitLoaded: false;
    isPageRecurringLoaded: false;
	TM_StoreGetList: any[];
	TM_StoreGetList_dummy: any[];
	TM_GetCustomerByName: any[];
	TM_GetCustomerByName_dummy: any[];
	TS_GetStoreUsers: any[];
	TS_GetStoreUsers_dummy: any[];
	GetSalesPersonByStore: any[];
	GetSalesPersonByStore_dummy: any[];
	TM_GetSalesExchangesRate: any[];
	TM_GetSalesExchangesRate_dummy: any[];
	GetTMUserId: any[];
	GetTMUserId_dummy: any[];
	TM_GetThirdPartySalesDraftForResume: any[];
	TM_GetThirdPartySalesDraftForResume_dummy: any[];
	SetValueOf: any;
	SetValueOf_dummy: any;
	TMGetSalesProductDraft: any[];
	TMGetSalesProductDraft_dummy: any[];
	TMSalesPaymentList: any[];
	TMSalesPaymentList_dummy: any[];
	TMSalesSummary: any[];
	TMSalesSummary_dummy: any[];
	TM_GetSelectedCustomerSaleInfo: any[];
	TM_GetSelectedCustomerSaleInfo_dummy: any[];
	TM_GetCustomerById: any[];
	TM_GetCustomerById_dummy: any[];
	TM_CheckCustomerVerificationPopup: any[];
	TM_CheckCustomerVerificationPopup_dummy: any[];
	NAVIGATE: any;
	NAVIGATE_dummy: any;
	TM_GetThirdPartyInvoiceCustomerList: any[];
	TM_GetThirdPartyInvoiceCustomerList_dummy: any[];
	TM_GetCountry: any[];
	TM_GetCountry_dummy: any[];
	TM_GetCitySql: any[];
	TM_GetCitySql_dummy: any[];
	TM_GetDistrict: any[];
	TM_GetDistrict_dummy: any[];
	TMSalesDraftCreate: any[];
	TMSalesDraftCreate_dummy: any[];
	TM_CreateThirdPartyInvoiceApprovalDraft: any[];
	TM_CreateThirdPartyInvoiceApprovalDraft_dummy: any[];
	Notify: boolean;
	Notify_dummy: boolean;
	ChangeEnabledOf: any;
	ChangeEnabledOf_dummy: any;
	Connect: any;
	Connect_dummy: any;
	Kuika_ItemInfoLive: any[];
	Kuika_ItemInfoLive_dummy: any[];
	TMSalesDraftAddProduct: any[];
	TMSalesDraftAddProduct_dummy: any[];
	TMIskontoAddSales: any[];
	TMIskontoAddSales_dummy: any[];
	TMSalesProductDelete: any[];
	TMSalesProductDelete_dummy: any[];
	TMSalesPaymentType: any[];
	TMSalesPaymentType_dummy: any[];
	TMAddSalesPayment: any[];
	TMAddSalesPayment_dummy: any[];
	TMSalesUpdatePayment: any[];
	TMSalesUpdatePayment_dummy: any[];
	TMSalesPaymentCompletedLine: any[];
	TMSalesPaymentCompletedLine_dummy: any[];
	TMSalesPaymentDeleted: any[];
	TMSalesPaymentDeleted_dummy: any[];
	ChangeVisibilityOf: string;
	ChangeVisibilityOf_dummy: string;
	TM_SubmitThirdPartyInvoiceApproval: any[];
	TM_SubmitThirdPartyInvoiceApproval_dummy: any[];
	PostDirectSalesDraftList: any[];
	PostDirectSalesDraftList_dummy: any[];
	PostDirectSalesDraftDetail: any[];
	PostDirectSalesDraftDetail_dummy: any[];
	PostDirectSalesDraftPayment: any[];
	PostDirectSalesDraftPayment_dummy: any[];
	DirectSend: any;
	DirectSend_dummy: any;
	SendMail: any;
	SendMail_dummy: any;
	isComp761489Visible: 'visible' | 'hidden';
	isComp832389Visible: 'visible' | 'hidden';
	isComp566086Visible: 'visible' | 'hidden';
	isComp69886Visible: 'visible' | 'hidden';
	isComp629609Visible: 'visible' | 'hidden';
	isComp581875571Visible: 'visible' | 'hidden';
	isComp170159Visible: 'visible' | 'hidden';
	isComp833620Visible: 'visible' | 'hidden';
	isComp434522991Visible: 'visible' | 'hidden';
	isComp1383831790Visible: 'visible' | 'hidden';
	isComp252425Visible: 'visible' | 'hidden';
	isComp719632801Visible: 'visible' | 'hidden';
	isComp725080941Visible: 'visible' | 'hidden';
	isComp376527Visible: 'visible' | 'hidden';
	isComp91851Visible: 'visible' | 'hidden';
	isComp625854Visible: 'visible' | 'hidden';
	isComp15169Visible: 'visible' | 'hidden';
	isComp759176Visible: 'visible' | 'hidden';
	isComp281463Visible: 'visible' | 'hidden';
	isComp176363Visible: 'visible' | 'hidden';
	isComp832389Enabled: 'enabled' | 'disabled';
	isComp684346Enabled: 'enabled' | 'disabled';
	isComp126358Enabled: 'enabled' | 'disabled';
	isComp863666Enabled: 'enabled' | 'disabled';
	isComp1112812883Enabled: 'enabled' | 'disabled';
	isComp761489Enabled: 'enabled' | 'disabled';

}

export class SatisIslemi_ScreenBase extends React.PureComponent<ISatisIslemi_ScreenProps, any> {
    static contextType = MasterScreen_ScreenContext;
    declare context: React.ContextType<typeof MasterScreen_ScreenContext>;
	satisislemi_516749_value_kuikaAutoCompleteRef: React.RefObject<any>;
	satisislemi_36693_value_kuikaAutoCompleteRef: React.RefObject<any>;
	satisislemi_961229_value_kuikaAutoCompleteRef: React.RefObject<any>;
	satisislemi_400617_value_kuikaSelectBoxRef: React.RefObject<any>;
	satisislemi_403854_value_kuikaDateRef: React.RefObject<any>;
	satisislemi_141674_value_kuikaDateRef: React.RefObject<any>;
	satisislemi_675484_value_kuikaSelectBoxRef: React.RefObject<any>;
	satisislemi_1278099362_value_kuikaAutoCompleteRef: React.RefObject<any>;
	satisislemi_971887955_value_kuikaSelectBoxRef: React.RefObject<any>;
	satisislemi_1090044654_value_kuikaAutoCompleteRef: React.RefObject<any>;
	satisislemi_578279381_value_kuikaAutoCompleteRef: React.RefObject<any>;
	satisislemi_1084844233_value_kuikaAutoCompleteRef: React.RefObject<any>;
	satisislemi_41607_value_kuikaTableRef: React.RefObject<any>;
	satisislemi_987644_value_kuikaFlexGridRef: React.RefObject<any>;
	satisislemi_831595_value_kuikaAutoCompleteRef: React.RefObject<any>;
	satisislemi_859085_value_kuikaAutoCompleteRef: React.RefObject<any>;
	satisislemi_1364999695_value_kuikaAutoCompleteRef: React.RefObject<any>;
	satisislemi_466892_value_kuikaTableRef: React.RefObject<any>;
    ml=[{"Id":"d5a61d2b-bd60-485f-86e2-661e9ed4e486","Name":"en_US","ShortName":"English","IsDefault":true,"LanguagePhrases":[]},{"Id":"3f158070-1c79-4f8f-8ed0-5bd237e95a22","Name":"FixedValues","ShortName":"FixedValues","LanguagePhrases":[{"Id":181309,"PropertyName":"value","Value":"Satış İşlemi"},{"Id":145071,"PropertyName":"value","Value":"1. Fatura Bilgisi"},{"Id":333111,"PropertyName":"value","Value":"Fatura tipi seçilmeden ürün ekleme alanı kullanılamaz."},{"Id":516749,"PropertyName":"placeholder","Value":"Satış yapılan mağazayı seçiniz"},{"Id":36693,"PropertyName":"placeholder","Value":"Satış personeli seçiniz"},{"Id":961229,"PropertyName":"placeholder","Value":"Müşteri Seçiniz"},{"Id":937792,"PropertyName":"label","Value":"Müşteri Ekle"},{"Id":1554435159,"PropertyName":"value","Value":"Müşteri Bilgileri"},{"Id":1645098966,"PropertyName":"value","Value":"Seçilen müşterinin doğrulanmış bilgileri"},{"Id":1871886692,"PropertyName":"label","Value":"Düzenle"},{"Id":1373669610,"PropertyName":"value","Value":"Müşteri Adı Soyadı"},{"Id":1870629242,"PropertyName":"value","Value":"Telefon"},{"Id":1316721391,"PropertyName":"value","Value":"E-posta"},{"Id":18242901,"PropertyName":"value","Value":"TC / Pasaport No"},{"Id":271591514,"PropertyName":"value","Value":"Lokasyon"},{"Id":1076076313,"PropertyName":"value","Value":"Alışveriş Var mı?"},{"Id":400617,"PropertyName":"placeholder","Value":"Fatura tipi seçiniz"},{"Id":708806,"PropertyName":"placeholder","Value":"Oturum İzni Numarası"},{"Id":403854,"PropertyName":"placeholder","Value":"Oturum Başlangıç Tarihi"},{"Id":141674,"PropertyName":"placeholder","Value":"Oturum Bitiş Tarihi"},{"Id":286649,"PropertyName":"label","Value":"3. Kişiye Faturalandıracağım"},{"Id":290953,"PropertyName":"value","Value":"3. Kişi Bilgi Kaynağı"},{"Id":675484,"PropertyName":"placeholder","Value":"3. Kişi bilgi kaynağı"},{"Id":1182143128,"PropertyName":"value","Value":"Fatura Kesilecek Müşteri"},{"Id":1278099362,"PropertyName":"placeholder","Value":"Müşteri seçiniz"},{"Id":2009228926,"PropertyName":"value","Value":"Fatura Alıcısı Tipi"},{"Id":971887955,"PropertyName":"placeholder","Value":"Fatura alıcısı tipi"},{"Id":96567452,"PropertyName":"value","Value":"Ad"},{"Id":1826185521,"PropertyName":"placeholder","Value":"Ad"},{"Id":2054016472,"PropertyName":"value","Value":"Soyad"},{"Id":1003513911,"PropertyName":"placeholder","Value":"Soyad"},{"Id":1679654806,"PropertyName":"value","Value":"T.C. /Kimlik No"},{"Id":1464483161,"PropertyName":"placeholder","Value":"TC"},{"Id":1433073097,"PropertyName":"value","Value":"Şirket/Unvan"},{"Id":428413438,"PropertyName":"placeholder","Value":"Şirket / Unvan"},{"Id":203857741,"PropertyName":"value","Value":"Vergi Numarası"},{"Id":1393703318,"PropertyName":"placeholder","Value":"Vergi Numarası"},{"Id":308657192,"PropertyName":"value","Value":"Vergi Dairesi Kodu"},{"Id":2006075834,"PropertyName":"placeholder","Value":"Vergi Dairesi Kodu"},{"Id":795416414,"PropertyName":"value","Value":"Ülke*"},{"Id":1090044654,"PropertyName":"placeholder","Value":"Ülke"},{"Id":121250038,"PropertyName":"value","Value":"İl*"},{"Id":578279381,"PropertyName":"placeholder","Value":"İl"},{"Id":252768447,"PropertyName":"value","Value":"İlçe*"},{"Id":1084844233,"PropertyName":"placeholder","Value":"İlçe"},{"Id":369991958,"PropertyName":"value","Value":"Adres"},{"Id":1694362615,"PropertyName":"placeholder","Value":"Adres"},{"Id":555308,"PropertyName":"label","Value":"Devam Et"},{"Id":372930,"PropertyName":"value","Value":"2. Ürün Ekle"},{"Id":520024,"PropertyName":"value","Value":"Lead üzerindeki ürünü ekleyiniz ayrıca saat dışında harici ürün de ekleyebilirsiniz."},{"Id":878977,"PropertyName":"placeholder","Value":"Barkod veya seri numarası giriniz"},{"Id":10440,"PropertyName":"label","Value":"Ürün Ekle"},{"Id":428899,"PropertyName":"title","Value":"Seri No/Barkod"},{"Id":625854,"PropertyName":"value","Value":"[datafield:serino]"},{"Id":15169,"PropertyName":"value","Value":"[datafield:barcode]"},{"Id":257771,"PropertyName":"title","Value":"Product Name"},{"Id":465866,"PropertyName":"value","Value":"[datafield:productname]"},{"Id":623815,"PropertyName":"title","Value":"Fiyat"},{"Id":714962,"PropertyName":"value","Value":"[datafield:unitpriceeur]"},{"Id":58451,"PropertyName":"title","Value":"İskonto Oranı"},{"Id":161776,"PropertyName":"value","Value":"[datafield:discountrate]"},{"Id":863666,"PropertyName":"placeholder","Value":"15"},{"Id":794306,"PropertyName":"title","Value":"İndirim Tutarı"},{"Id":700671,"PropertyName":"value","Value":"[datafield:discountamount]"},{"Id":101174,"PropertyName":"title","Value":"Toplam Tutar"},{"Id":409435,"PropertyName":"value","Value":"[datafield:linetotaleur]"},{"Id":244475,"PropertyName":"value","Value":"3. Tahsilat Ekle"},{"Id":352042,"PropertyName":"value","Value":"Tek veya parçalı tahsilat girişine uygundur."},{"Id":987644,"PropertyName":"nodatafoundmessage","Value":"No data found."},{"Id":789376,"PropertyName":"value","Value":"[datafield:currencycode]"},{"Id":728526,"PropertyName":"value","Value":"[datafield:rate]"},{"Id":831595,"PropertyName":"placeholder","Value":"Tahsilat Tipi"},{"Id":859085,"PropertyName":"placeholder","Value":"Tahsilat Bilgisi"},{"Id":1364999695,"PropertyName":"placeholder","Value":"Döviz"},{"Id":358141,"PropertyName":"label","Value":"Tahsilat Ekle"},{"Id":647637,"PropertyName":"title","Value":"Tip"},{"Id":370523,"PropertyName":"value","Value":"[datafield:tipadi]"},{"Id":270805,"PropertyName":"title","Value":"Döviz"},{"Id":780309,"PropertyName":"value","Value":"[datafield:doviz]"},{"Id":1219070899,"PropertyName":"title","Value":"Bilgi"},{"Id":646678993,"PropertyName":"value","Value":"[datafield:curraccdescription]"},{"Id":766295,"PropertyName":"title","Value":"Tutar"},{"Id":455308,"PropertyName":"value","Value":"[datafield:tutar]"},{"Id":343657,"PropertyName":"placeholder","Value":"15"},{"Id":607353,"PropertyName":"title","Value":"EUR Karşılığı"},{"Id":522369,"PropertyName":"value","Value":"[datafield:eurkarsiligi]"},{"Id":219734,"PropertyName":"value","Value":"Tahsil Edilen:"},{"Id":291992,"PropertyName":"value","Value":"Kalan:"},{"Id":413915,"PropertyName":"value","Value":"Sepet Özeti"},{"Id":978568,"PropertyName":"value","Value":"Satış onayı için gerekli toplamlar sağ alanda sürekli görünür kalır."},{"Id":735430,"PropertyName":"value","Value":"Mağaza"},{"Id":752532,"PropertyName":"value","Value":"Personel"},{"Id":153027,"PropertyName":"value","Value":"Müşteri"},{"Id":427916,"PropertyName":"value","Value":"Ürün Adedi"},{"Id":809772,"PropertyName":"value","Value":"Ara Toplam"},{"Id":515479,"PropertyName":"value","Value":"Toplam İndirim"},{"Id":944039,"PropertyName":"value","Value":"Genel Toplam"},{"Id":834307,"PropertyName":"value","Value":"Tahsil Edilen"},{"Id":748548,"PropertyName":"value","Value":"Kalan Tutar"},{"Id":1112812883,"PropertyName":"label","Value":"Tutarı Kontrol Et"},{"Id":761489,"PropertyName":"label","Value":"Satışı Onayla"},{"Id":167957,"PropertyName":"value","Value":"Satışı tamamlamak için fatura tipi seçilmeli, ürün eklenmeli ve kalan tutar sıfırlanmalıdır."},{"Id":176363,"PropertyName":"placeholder","Value":"Type here..."}]}]
    defaultML = "en_US"
    
    screenHash = ""
    

    private _prevMasterPageInitLoaded: boolean = false;
    private _prevMasterPageRecurringLoaded: boolean = false;
    private _prevShouldTriggerPageInit: boolean = false;
    constructor(props) {
        super(props);
		this.satisislemi_516749_value_kuikaAutoCompleteRef = React.createRef();
		this.satisislemi_36693_value_kuikaAutoCompleteRef = React.createRef();
		this.satisislemi_961229_value_kuikaAutoCompleteRef = React.createRef();
		this.satisislemi_400617_value_kuikaSelectBoxRef = React.createRef();
		this.satisislemi_708806_value_kuikaTextInputRef = React.createRef();
		this.satisislemi_403854_value_kuikaDateRef = React.createRef();
		this.satisislemi_141674_value_kuikaDateRef = React.createRef();
		this.satisislemi_675484_value_kuikaSelectBoxRef = React.createRef();
		this.satisislemi_1278099362_value_kuikaAutoCompleteRef = React.createRef();
		this.satisislemi_971887955_value_kuikaSelectBoxRef = React.createRef();
		this.satisislemi_1826185521_value_kuikaTextInputRef = React.createRef();
		this.satisislemi_1003513911_value_kuikaTextInputRef = React.createRef();
		this.satisislemi_1464483161_value_kuikaTextInputRef = React.createRef();
		this.satisislemi_428413438_value_kuikaTextInputRef = React.createRef();
		this.satisislemi_1393703318_value_kuikaTextInputRef = React.createRef();
		this.satisislemi_2006075834_value_kuikaTextInputRef = React.createRef();
		this.satisislemi_1090044654_value_kuikaAutoCompleteRef = React.createRef();
		this.satisislemi_578279381_value_kuikaAutoCompleteRef = React.createRef();
		this.satisislemi_1084844233_value_kuikaAutoCompleteRef = React.createRef();
		this.satisislemi_878977_value_kuikaTextInputRef = React.createRef();
		this.satisislemi_41607_value_kuikaTableRef = React.createRef();
		this.satisislemi_987644_value_kuikaFlexGridRef = React.createRef();
		this.satisislemi_831595_value_kuikaAutoCompleteRef = React.createRef();
		this.satisislemi_859085_value_kuikaAutoCompleteRef = React.createRef();
		this.satisislemi_1364999695_value_kuikaAutoCompleteRef = React.createRef();
		this.satisislemi_466892_value_kuikaTableRef = React.createRef();
		this.satisislemi_176363_value_kuikaTextInputRef = React.createRef();

        this.state = {
            isSpinnerVisible: false,
            isPageVisible: false,
            isLeftMenuVisible: false,
            spinnerCount: 0,
            selectedLanguage: "",
            isPageInitLoaded: false,
            isPageRecurringLoaded: false,
            	        TM_StoreGetList: [],
	        TM_GetCustomerByName: [],
	        TS_GetStoreUsers: [],
	        GetSalesPersonByStore: [],
	        TM_GetSalesExchangesRate: [],
	        GetTMUserId: [],
	        TM_GetThirdPartySalesDraftForResume: [],
	        SetValueOf: "",
	        TMGetSalesProductDraft: [],
	        TMSalesPaymentList: [],
	        TMSalesSummary: [],
	        TM_GetSelectedCustomerSaleInfo: [],
	        TM_GetCustomerById: [],
	        TM_CheckCustomerVerificationPopup: [],
	        NAVIGATE: "",
	        TM_GetThirdPartyInvoiceCustomerList: [],
	        TM_GetCountry: [],
	        TM_GetCitySql: [],
	        TM_GetDistrict: [],
	        TMSalesDraftCreate: [],
	        TM_CreateThirdPartyInvoiceApprovalDraft: [],
	        Notify: false,
	        ChangeEnabledOf: "",
	        Connect: "",
	        Kuika_ItemInfoLive: [],
	        TMSalesDraftAddProduct: [],
	        TMIskontoAddSales: [],
	        TMSalesProductDelete: [],
	        TMSalesPaymentType: [],
	        TMAddSalesPayment: [],
	        TMSalesUpdatePayment: [],
	        TMSalesPaymentCompletedLine: [],
	        TMSalesPaymentDeleted: [],
	        ChangeVisibilityOf: "",
	        TM_SubmitThirdPartyInvoiceApproval: [],
	        PostDirectSalesDraftList: [],
	        PostDirectSalesDraftDetail: [],
	        PostDirectSalesDraftPayment: [],
	        DirectSend: "",
	        SendMail: "",
	        dataSource_400617: [{"key":"1","text":"Standart Fatura"},{"key":"2","text":"Tax Free Fatura"}],
	        dataSource_675484: [{"key":"CUSTOMER","text":"Müşteri listesinden seç"},{"key":"MANUAL","text":"Müşteri kartı oluşturmadan manuel gir"}],
	        dataSource_971887955: [{"key":"PERSON","text":"Gerçek Kişi"},{"key":"COMPANY","text":"Tüzel Firma"}],
	        dataSource_831595: [{"key":"1","text":"Nakit"},{"key":"2","text":"Kredi Kartı"},{"key":"4","text":"Banka"}],
	        dataSource_1364999695: [{"key":"TRY","text":"TRY"},{"key":"EUR","text":"EUR"},{"key":"USD","text":"USD"},{"key":"GBP","text":"GBP"},{"key":"CHF","text":"CHF"}],
	        isComp761489Visible: 'hidden',
	        isComp832389Visible: 'hidden',
	        isComp566086Visible: 'hidden',
	        isComp69886Visible: 'hidden',
	        isComp629609Visible: 'hidden',
	        isComp581875571Visible: 'hidden',
	        isComp170159Visible: 'hidden',
	        isComp833620Visible: 'hidden',
	        isComp434522991Visible: 'hidden',
	        isComp1383831790Visible: 'hidden',
	        isComp252425Visible: 'hidden',
	        isComp719632801Visible: 'hidden',
	        isComp725080941Visible: 'hidden',
	        isComp376527Visible: 'hidden',
	        isComp91851Visible: 'hidden',
	        isComp625854Visible: 'hidden',
	        isComp15169Visible: 'hidden',
	        isComp759176Visible: 'hidden',
	        isComp281463Visible: 'hidden',
	        isComp176363Visible: 'hidden',
	        isComp832389Enabled: 'enabled',
	        isComp684346Enabled: 'disabled',
	        isComp126358Enabled: 'disabled',
	        isComp863666Enabled: 'disabled',
	        isComp1112812883Enabled: 'disabled',
	        isComp761489Enabled: 'disabled',

        }

        this.state.isPageVisible = true;
        
    }

    async componentDidMount() {

        if (KuikaAppManager.isPageInitPrevented()) {
            KuikaAppManager.calculateAndSetBodyHeight("satisislemi", "masterscreen_screen");
            return;
        }
        this.context.registerCallbackFunction(this.callCallbackFunction.bind(this));
        
        ReactSystemFunctions.validateToken()
        this.fillFormInitValues();
        if (false){
            await this.SatisIslemiPageInit();
        } else if (this.context?.isMasterPageInitLoaded) { this._prevMasterPageInitLoaded = true; await this.SatisIslemiPageInit(); }
        
        
        
        KuikaAppManager.calculateAndSetBodyHeight("satisislemi", "masterscreen_screen");

        if (ReactSystemFunctions.getIsMicroApp() === false) {
           window.parentScreen = this;
        }
    }

    componentWillUnmount() {
        
        
        

        if (ReactSystemFunctions.getIsMicroApp() === false) {
           window.parentScreen = null;
        }
    }

    

        
    componentDidUpdate= async (prevProps, prevState) => {
		KuikaAppManager.calculateAndSetBodyHeight("satisislemi", "masterscreen_screen"    );
        if (prevProps?.location?.search !== (this.props as any)?.location?.search) {
			await this.SatisIslemiPageInit();
		}

        		if (this._prevMasterPageInitLoaded !== this.context.isMasterPageInitLoaded && this.context.isMasterPageInitLoaded === true) {this._prevMasterPageInitLoaded = this.context.isMasterPageInitLoaded;await this.SatisIslemiPageInit()}


        if (ReactSystemFunctions.getIsMicroApp() === false) {
            for (const key in prevState) {
                if (key.startsWith('NavVisible') && prevState[key] === true && this.state[key] === false) {
                    window.parentScreen = this;
                    break;
                }
            }
        }
	}

    fillFormInitValues() {
        this.props.form?.setFieldsValue({
satisislemi_516749_value: this.state.TS_GetStoreUsers?.at?.(0)?.storeID ?? undefined,
satisislemi_36693_value: this.state.GetSalesPersonByStore?.at?.(0)?.kuserID ?? undefined,
satisislemi_961229_value: this.state.TM_GetSelectedCustomerSaleInfo?.at?.(0)?.customerId ?? undefined,
satisislemi_286649_checked: false
});

    }

      setPageInitLoaded = (value: boolean) => {
        this.setState({ isPageInitLoaded: value });
      }

      setPageRecurringLoaded = (value: boolean) => {
        this.setState({ isPageRecurringLoaded: value });
      }

      clearFieldValidation = (changedValues: any) => {
        const fieldName = Object.keys(changedValues)[0];
        if (fieldName) {
          this.props.form?.setFields([
            {
              name: fieldName,
              errors: []
            }
          ]);
        }
      };

      

    SatisIslemiPageInit = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


	if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }

        let localVar = {
			KUserId_2: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.getMyUserId(), "Guid"),
			StoreId_3: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, (stateVars.TS_GetStoreUsers !== undefined ? (stateVars.TS_GetStoreUsers?.length > 0 ? stateVars.TS_GetStoreUsers[0].storeID : null) : (this.state.TS_GetStoreUsers?.length > 0 ? this.state.TS_GetStoreUsers[0].storeID : null))), "Guid"),
			KUserId_5: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.getMyUserId(), "Guid")
        }

	KuikaAppManager.showSpinner(this);
	
        if (true) {
        KuikaAppManager.showSpinner(this);
        }
        let result = await KuikaAppManager.ApiRequest(this, "SatisIslemi/SatisIslemiPageInit", localVar)
        if (!KMainFunctions.IsResStatus2XX(result)) return true;

		stateVars.TM_StoreGetList = result?.data.tM_StoreGetList;
		
		formVars.satisislemi_516749_value = (stateVars.TS_GetStoreUsers !== undefined ? (stateVars.TS_GetStoreUsers?.length > 0 ? stateVars.TS_GetStoreUsers[0].storeID : null) : (this.state.TS_GetStoreUsers?.length > 0 ? this.state.TS_GetStoreUsers[0].storeID : null));
		formVars.satisislemi_516749_options = stateVars.TM_StoreGetList;
		stateVars.TM_GetCustomerByName = result?.data.tM_GetCustomerByName;
		
		formVars.satisislemi_961229_options = stateVars.TM_GetCustomerByName;
		stateVars.TS_GetStoreUsers = result?.data.tS_GetStoreUsers;
		formVars.satisislemi_516749_value = (stateVars.TS_GetStoreUsers !== undefined ? (stateVars.TS_GetStoreUsers?.length > 0 ? stateVars.TS_GetStoreUsers[0].storeID : null) : (this.state.TS_GetStoreUsers?.length > 0 ? this.state.TS_GetStoreUsers[0].storeID : null));
		formVars.satisislemi_516749_options = stateVars.TM_StoreGetList;
		stateVars.GetSalesPersonByStore = result?.data.getSalesPersonByStore;
		
		formVars.satisislemi_36693_value = (stateVars.GetSalesPersonByStore !== undefined ? (stateVars.GetSalesPersonByStore?.length > 0 ? stateVars.GetSalesPersonByStore[0].kuserID : null) : (this.state.GetSalesPersonByStore?.length > 0 ? this.state.GetSalesPersonByStore[0].kuserID : null));
		formVars.satisislemi_36693_options = stateVars.GetSalesPersonByStore;
		stateVars.TM_GetSalesExchangesRate = result?.data.tM_GetSalesExchangesRate;
		
		stateVars.GetTMUserId = result?.data.getTMUserId;
		this.props.form?.setFieldsValue(formVars);
		
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.SatisIslemiPageInit1_();
                  resolve();
                });
          })



        
        KuikaAppManager.hideSpinner(this);
        return isErrorOccurred;
    }
    SatisIslemiPageInit1_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


	if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }

        let localVar = {
			CurrentUserId_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.getMyUserId(), "Guid"),
			ApprovalId_0: ReactSystemFunctions.convertToTypeByName(this.props.screenInputs.ApprovalId ?? this.props.screenInputs.approvalid, "Guid"),
			SalesDraftId_0: ReactSystemFunctions.convertToTypeByName(this.props.screenInputs.SalesDraftId ?? this.props.screenInputs.salesdraftid, "Guid")
        }

if ((ReactSystemFunctions.isNotEmpty(this.props.screenInputs.ApprovalId ?? this.props.screenInputs.approvalid, ReactSystemFunctions.convertToTypeByName("True", "string")) && ReactSystemFunctions.isNotEmpty(this.props.screenInputs.SalesDraftId ?? this.props.screenInputs.salesdraftid, ReactSystemFunctions.convertToTypeByName("True", "string")))) {
            	
        if (true) {
        KuikaAppManager.showSpinner(this);
        }
        let result = await KuikaAppManager.ApiRequest(this, "SatisIslemi/SatisIslemiPageInit1_", localVar)
        if (!KMainFunctions.IsResStatus2XX(result)) return true;

		stateVars.TM_GetThirdPartySalesDraftForResume = result?.data.tM_GetThirdPartySalesDraftForResume;
		this.props.form?.setFieldsValue(formVars);
		
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.SatisIslemiPageInit2_();
                  resolve();
                });
          })

        } else {
            
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.SatisIslemiPageInit2_();
                  resolve();
                });
          })
        }


        
        KuikaAppManager.hideSpinner(this);
        return isErrorOccurred;
    }
	SatisIslemiPageInit2_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


	if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
if (ReactSystemFunctions.isNotEmpty(ReactSystemFunctions.value(this, (stateVars.TM_GetThirdPartySalesDraftForResume !== undefined ? (stateVars.TM_GetThirdPartySalesDraftForResume?.length > 0 ? stateVars.TM_GetThirdPartySalesDraftForResume[0].salesDraftId : null) : (this.state.TM_GetThirdPartySalesDraftForResume?.length > 0 ? this.state.TM_GetThirdPartySalesDraftForResume[0].salesDraftId : null))), true)) {
            
			stateVars.SetValueOf = await ReactSystemFunctions.setValueOf(this, ReactSystemFunctions.convertToTypeByName("satisislemi_176363_value", "string"), ReactSystemFunctions.toString(this, (stateVars.TM_GetThirdPartySalesDraftForResume !== undefined ? (stateVars.TM_GetThirdPartySalesDraftForResume?.length > 0 ? stateVars.TM_GetThirdPartySalesDraftForResume[0].salesDraftId : null) : (this.state.TM_GetThirdPartySalesDraftForResume?.length > 0 ? this.state.TM_GetThirdPartySalesDraftForResume[0].salesDraftId : null))), null, false);

	this.props.form?.setFieldsValue(formVars);
	
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.SatisIslemiPageInit3_();
                  resolve();
                });
          })

        } else {
            
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.SatisIslemiPageInit3_();
                  resolve();
                });
          })
        }

            
            return isErrorOccurred;
        }
    SatisIslemiPageInit3_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


	if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }

        let localVar = {
			SalesDraftId_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toGuid(this, ReactSystemFunctions.value(this, "satisislemi_176363_value", "value", "", "", "")), "Guid")
        }

if (ReactSystemFunctions.isNotEmpty(ReactSystemFunctions.value(this, (stateVars.TM_GetThirdPartySalesDraftForResume !== undefined ? (stateVars.TM_GetThirdPartySalesDraftForResume?.length > 0 ? stateVars.TM_GetThirdPartySalesDraftForResume[0].salesDraftId : null) : (this.state.TM_GetThirdPartySalesDraftForResume?.length > 0 ? this.state.TM_GetThirdPartySalesDraftForResume[0].salesDraftId : null))), ReactSystemFunctions.convertToTypeByName("True", "string"))) {
            	
        if (true) {
        KuikaAppManager.showSpinner(this);
        }
        let result = await KuikaAppManager.ApiRequest(this, "SatisIslemi/SatisIslemiPageInit3_", localVar)
        if (!KMainFunctions.IsResStatus2XX(result)) return true;

		stateVars.TMGetSalesProductDraft = result?.data.tmGetSalesProductDraft;
		
		stateVars.isComp759176Visible = ((ReactSystemFunctions.isNotEmpty(ReactSystemFunctions.value(this, (stateVars.TMGetSalesProductDraft !== undefined ? (stateVars.TMGetSalesProductDraft?.length > 0 ? stateVars.TMGetSalesProductDraft[0].id : null) : (this.state.TMGetSalesProductDraft?.length > 0 ? this.state.TMGetSalesProductDraft[0].id : null))), ReactSystemFunctions.convertToTypeByName("True", "string"))) === true ? "visible" : "hidden")
		this.props.form?.setFieldsValue(formVars);
		
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.SatisIslemiPageInit4_();
                  resolve();
                });
          })

        } else {
            
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.SatisIslemiPageInit4_();
                  resolve();
                });
          })
        }


        
        KuikaAppManager.hideSpinner(this);
        return isErrorOccurred;
    }
    SatisIslemiPageInit4_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


	if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }

        let localVar = {
			SalesDraftId_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toGuid(this, ReactSystemFunctions.value(this, "satisislemi_176363_value", "value", "", "", "")), "Guid")
        }

if (ReactSystemFunctions.isNotEmpty(ReactSystemFunctions.value(this, (stateVars.TM_GetThirdPartySalesDraftForResume !== undefined ? (stateVars.TM_GetThirdPartySalesDraftForResume?.length > 0 ? stateVars.TM_GetThirdPartySalesDraftForResume[stateVars.TM_GetThirdPartySalesDraftForResume.length - 1].salesDraftId : null) : (this.state.TM_GetThirdPartySalesDraftForResume?.length > 0 ? this.state.TM_GetThirdPartySalesDraftForResume[this.state.TM_GetThirdPartySalesDraftForResume.length - 1].salesDraftId : null))), ReactSystemFunctions.convertToTypeByName("True", "string"))) {
            	
        if (true) {
        KuikaAppManager.showSpinner(this);
        }
        let result = await KuikaAppManager.ApiRequest(this, "SatisIslemi/SatisIslemiPageInit4_", localVar)
        if (!KMainFunctions.IsResStatus2XX(result)) return true;

		stateVars.TMSalesPaymentList = result?.data.tmSalesPaymentList;
		
		formVars.satisislemi_100771_value = ReactSystemFunctions.toString(this, (stateVars.TMSalesPaymentList !== undefined ? (stateVars.TMSalesPaymentList?.length > 0 ? stateVars.TMSalesPaymentList[0].collectedTotalEUR : null) : (this.state.TMSalesPaymentList?.length > 0 ? this.state.TMSalesPaymentList[0].collectedTotalEUR : null)));
		formVars.satisislemi_653586_value = ReactSystemFunctions.toString(this, (stateVars.TMSalesPaymentList !== undefined ? (stateVars.TMSalesPaymentList?.length > 0 ? stateVars.TMSalesPaymentList[0].remainingEUR : null) : (this.state.TMSalesPaymentList?.length > 0 ? this.state.TMSalesPaymentList[0].remainingEUR : null)));
		stateVars.isComp1112812883Enabled = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, (stateVars.TMSalesPaymentList !== undefined ? (stateVars.TMSalesPaymentList?.length > 0 ? stateVars.TMSalesPaymentList[0].remainingEUR : null) : (this.state.TMSalesPaymentList?.length > 0 ? this.state.TMSalesPaymentList[0].remainingEUR : null))), ReactSystemFunctions.convertToTypeByName("0", "string"))) === true ? "enabled" : "disabled")
		stateVars.isComp761489Enabled = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, (stateVars.TMSalesPaymentList !== undefined ? (stateVars.TMSalesPaymentList?.length > 0 ? stateVars.TMSalesPaymentList[0].remainingEUR : null) : (this.state.TMSalesPaymentList?.length > 0 ? this.state.TMSalesPaymentList[0].remainingEUR : null))), ReactSystemFunctions.convertToTypeByName("0", "string"))) === true ? "enabled" : "disabled")
		this.props.form?.setFieldsValue(formVars);
		
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.SatisIslemiPageInit5_();
                  resolve();
                });
          })

        } else {
            
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.SatisIslemiPageInit5_();
                  resolve();
                });
          })
        }


        
        KuikaAppManager.hideSpinner(this);
        return isErrorOccurred;
    }
    SatisIslemiPageInit5_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


	if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }

        let localVar = {
			DraftId_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toGuid(this, ReactSystemFunctions.value(this, "satisislemi_176363_value", "value", "", "", "")), "Guid")
        }

if (ReactSystemFunctions.isNotEmpty(ReactSystemFunctions.value(this, (stateVars.TM_GetThirdPartySalesDraftForResume !== undefined ? (stateVars.TM_GetThirdPartySalesDraftForResume?.length > 0 ? stateVars.TM_GetThirdPartySalesDraftForResume[0].salesDraftId : null) : (this.state.TM_GetThirdPartySalesDraftForResume?.length > 0 ? this.state.TM_GetThirdPartySalesDraftForResume[0].salesDraftId : null))), ReactSystemFunctions.convertToTypeByName("True", "string"))) {
            	
        if (true) {
        KuikaAppManager.showSpinner(this);
        }
        let result = await KuikaAppManager.ApiRequest(this, "SatisIslemi/SatisIslemiPageInit5_", localVar)
        if (!KMainFunctions.IsResStatus2XX(result)) return true;

		stateVars.TMSalesSummary = result?.data.tmSalesSummary;
		formVars.satisislemi_706355_value = ReactSystemFunctions.toString(this, (stateVars.TMSalesSummary !== undefined ? (stateVars.TMSalesSummary?.length > 0 ? stateVars.TMSalesSummary[0].magaza : null) : (this.state.TMSalesSummary?.length > 0 ? this.state.TMSalesSummary[0].magaza : null)));
		formVars.satisislemi_957854_value = ReactSystemFunctions.toString(this, (stateVars.TMSalesSummary !== undefined ? (stateVars.TMSalesSummary?.length > 0 ? stateVars.TMSalesSummary[0].personelAdi : null) : (this.state.TMSalesSummary?.length > 0 ? this.state.TMSalesSummary[0].personelAdi : null)));
		formVars.satisislemi_687658_value = ReactSystemFunctions.toString(this, (stateVars.TMSalesSummary !== undefined ? (stateVars.TMSalesSummary?.length > 0 ? stateVars.TMSalesSummary[0].musteriAdi : null) : (this.state.TMSalesSummary?.length > 0 ? this.state.TMSalesSummary[0].musteriAdi : null)));
		formVars.satisislemi_489530_value = ReactSystemFunctions.toString(this, (stateVars.TMSalesSummary !== undefined ? (stateVars.TMSalesSummary?.length > 0 ? stateVars.TMSalesSummary[0].urunAdedi : null) : (this.state.TMSalesSummary?.length > 0 ? this.state.TMSalesSummary[0].urunAdedi : null)));
		formVars.satisislemi_34076_value = ReactSystemFunctions.toString(this, (stateVars.TMSalesSummary !== undefined ? (stateVars.TMSalesSummary?.length > 0 ? stateVars.TMSalesSummary[0].araToplam : null) : (this.state.TMSalesSummary?.length > 0 ? this.state.TMSalesSummary[0].araToplam : null)));
		formVars.satisislemi_94614_value = ReactSystemFunctions.toString(this, (stateVars.TMSalesSummary !== undefined ? (stateVars.TMSalesSummary?.length > 0 ? stateVars.TMSalesSummary[0].iskontoTutari : null) : (this.state.TMSalesSummary?.length > 0 ? this.state.TMSalesSummary[0].iskontoTutari : null)));
		formVars.satisislemi_28476_value = ReactSystemFunctions.toString(this, (stateVars.TMSalesSummary !== undefined ? (stateVars.TMSalesSummary?.length > 0 ? stateVars.TMSalesSummary[0].genelToplam : null) : (this.state.TMSalesSummary?.length > 0 ? this.state.TMSalesSummary[0].genelToplam : null)));
		formVars.satisislemi_646001_value = ReactSystemFunctions.toString(this, (stateVars.TMSalesSummary !== undefined ? (stateVars.TMSalesSummary?.length > 0 ? stateVars.TMSalesSummary[0].tahsilEdilen : null) : (this.state.TMSalesSummary?.length > 0 ? this.state.TMSalesSummary[0].tahsilEdilen : null)));
		formVars.satisislemi_804074_value = ReactSystemFunctions.toString(this, (stateVars.TMSalesSummary !== undefined ? (stateVars.TMSalesSummary?.length > 0 ? stateVars.TMSalesSummary[0].kalanTutar : null) : (this.state.TMSalesSummary?.length > 0 ? this.state.TMSalesSummary[0].kalanTutar : null)));
		this.props.form?.setFieldsValue(formVars);
		
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.SatisIslemiPageInit6_();
                  resolve();
                });
          })

        } else {
            
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.SatisIslemiPageInit6_();
                  resolve();
                });
          })
        }


        
        KuikaAppManager.hideSpinner(this);
        return isErrorOccurred;
    }
    SatisIslemiPageInit6_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


	if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }

        let localVar = {
			CustomerId_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, (stateVars.TM_GetThirdPartySalesDraftForResume !== undefined ? (stateVars.TM_GetThirdPartySalesDraftForResume?.length > 0 ? stateVars.TM_GetThirdPartySalesDraftForResume[0].customerId : null) : (this.state.TM_GetThirdPartySalesDraftForResume?.length > 0 ? this.state.TM_GetThirdPartySalesDraftForResume[0].customerId : null))), "Guid")
        }

if (ReactSystemFunctions.isNotEmpty(ReactSystemFunctions.value(this, (stateVars.TM_GetThirdPartySalesDraftForResume !== undefined ? (stateVars.TM_GetThirdPartySalesDraftForResume?.length > 0 ? stateVars.TM_GetThirdPartySalesDraftForResume[0].salesDraftId : null) : (this.state.TM_GetThirdPartySalesDraftForResume?.length > 0 ? this.state.TM_GetThirdPartySalesDraftForResume[0].salesDraftId : null))), ReactSystemFunctions.convertToTypeByName("True", "string"))) {
            	
        if (true) {
        KuikaAppManager.showSpinner(this);
        }
        let result = await KuikaAppManager.ApiRequest(this, "SatisIslemi/SatisIslemiPageInit6_", localVar)
        if (!KMainFunctions.IsResStatus2XX(result)) return true;

		stateVars.TM_GetSelectedCustomerSaleInfo = result?.data.tM_GetSelectedCustomerSaleInfo;
		formVars.satisislemi_961229_value = (stateVars.TM_GetSelectedCustomerSaleInfo !== undefined ? (stateVars.TM_GetSelectedCustomerSaleInfo?.length > 0 ? stateVars.TM_GetSelectedCustomerSaleInfo[0].customerId : null) : (this.state.TM_GetSelectedCustomerSaleInfo?.length > 0 ? this.state.TM_GetSelectedCustomerSaleInfo[0].customerId : null));
		formVars.satisislemi_482972253_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetSelectedCustomerSaleInfo !== undefined ? (stateVars.TM_GetSelectedCustomerSaleInfo?.length > 0 ? stateVars.TM_GetSelectedCustomerSaleInfo[0].customerFullName : null) : (this.state.TM_GetSelectedCustomerSaleInfo?.length > 0 ? this.state.TM_GetSelectedCustomerSaleInfo[0].customerFullName : null)));
		formVars.satisislemi_475914658_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetSelectedCustomerSaleInfo !== undefined ? (stateVars.TM_GetSelectedCustomerSaleInfo?.length > 0 ? stateVars.TM_GetSelectedCustomerSaleInfo[0].phoneNumber : null) : (this.state.TM_GetSelectedCustomerSaleInfo?.length > 0 ? this.state.TM_GetSelectedCustomerSaleInfo[0].phoneNumber : null)));
		formVars.satisislemi_788067546_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetSelectedCustomerSaleInfo !== undefined ? (stateVars.TM_GetSelectedCustomerSaleInfo?.length > 0 ? stateVars.TM_GetSelectedCustomerSaleInfo[0].emailAddress : null) : (this.state.TM_GetSelectedCustomerSaleInfo?.length > 0 ? this.state.TM_GetSelectedCustomerSaleInfo[0].emailAddress : null)));
		formVars.satisislemi_814342869_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetSelectedCustomerSaleInfo !== undefined ? (stateVars.TM_GetSelectedCustomerSaleInfo?.length > 0 ? stateVars.TM_GetSelectedCustomerSaleInfo[0].identityOrPassportNumber : null) : (this.state.TM_GetSelectedCustomerSaleInfo?.length > 0 ? this.state.TM_GetSelectedCustomerSaleInfo[0].identityOrPassportNumber : null)));
		formVars.satisislemi_1027814808_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetSelectedCustomerSaleInfo !== undefined ? (stateVars.TM_GetSelectedCustomerSaleInfo?.length > 0 ? stateVars.TM_GetSelectedCustomerSaleInfo[0].location : null) : (this.state.TM_GetSelectedCustomerSaleInfo?.length > 0 ? this.state.TM_GetSelectedCustomerSaleInfo[0].location : null)));
		formVars.satisislemi_581875571_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetSelectedCustomerSaleInfo !== undefined ? (stateVars.TM_GetSelectedCustomerSaleInfo?.length > 0 ? stateVars.TM_GetSelectedCustomerSaleInfo[0].shoppingStatusText : null) : (this.state.TM_GetSelectedCustomerSaleInfo?.length > 0 ? this.state.TM_GetSelectedCustomerSaleInfo[0].shoppingStatusText : null)));
		this.props.form?.setFieldsValue(formVars);
		
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.SatisIslemiPageInit7_();
                  resolve();
                });
          })

        } else {
            
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.SatisIslemiPageInit7_();
                  resolve();
                });
          })
        }


        
        KuikaAppManager.hideSpinner(this);
        return isErrorOccurred;
    }
	SatisIslemiPageInit7_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


	if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
if (ReactSystemFunctions.isNotEmpty(ReactSystemFunctions.value(this, (stateVars.TM_GetThirdPartySalesDraftForResume !== undefined ? (stateVars.TM_GetThirdPartySalesDraftForResume?.length > 0 ? stateVars.TM_GetThirdPartySalesDraftForResume[0].salesDraftId : null) : (this.state.TM_GetThirdPartySalesDraftForResume?.length > 0 ? this.state.TM_GetThirdPartySalesDraftForResume[0].salesDraftId : null))), true)) {
            
			stateVars.SetValueOf = await ReactSystemFunctions.setValueOf(this, ReactSystemFunctions.convertToTypeByName("satisislemi_286649_checked", "string"), true, null, false);

	this.props.form?.setFieldsValue(formVars);
	
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.SatisIslemiPageInit8_();
                  resolve();
                });
          })

        } else {
            
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.SatisIslemiPageInit8_();
                  resolve();
                });
          })
        }

            
            return isErrorOccurred;
        }
	SatisIslemiPageInit8_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


	if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }

			stateVars.isComp832389Visible = ((ReactSystemFunctions.isEmpty(this.props.screenInputs.SalesDraftId ?? this.props.screenInputs.salesdraftid, true)) === true ? "visible" : "hidden")
			stateVars.isComp566086Visible = ((ReactSystemFunctions.contains(ReactSystemFunctions.getMyRoleNames(), "TimesUstYonetici")) === true ? "visible" : "hidden")
			formVars.satisislemi_516749_value = ReactSystemFunctions.toString(this, (stateVars.TS_GetStoreUsers !== undefined ? (stateVars.TS_GetStoreUsers?.length > 0 ? stateVars.TS_GetStoreUsers[0].storeID : null) : (this.state.TS_GetStoreUsers?.length > 0 ? this.state.TS_GetStoreUsers[0].storeID : null)));

			
			stateVars.dataSource_516749 = stateVars.TM_StoreGetList ?? this.state.TM_StoreGetList;
			stateVars.dataSource_516749 = stateVars.TM_StoreGetList ?? this.state.TM_StoreGetList;
			stateVars.isComp69886Visible = (((ReactSystemFunctions.contains(ReactSystemFunctions.getMyRoleNames(), "TimesUstYonetici") || ReactSystemFunctions.contains(ReactSystemFunctions.getMyRoleNames(), "TimesMagazaMuduru"))) === true ? "visible" : "hidden")
			formVars.satisislemi_36693_value = ReactSystemFunctions.toString(this, (stateVars.GetSalesPersonByStore !== undefined ? (stateVars.GetSalesPersonByStore?.length > 0 ? stateVars.GetSalesPersonByStore[0].kuserID : null) : (this.state.GetSalesPersonByStore?.length > 0 ? this.state.GetSalesPersonByStore[0].kuserID : null)));

			formVars.satisislemi_36693_value = ReactSystemFunctions.toString(this, (stateVars.GetSalesPersonByStore !== undefined ? (stateVars.GetSalesPersonByStore?.length > 0 ? stateVars.GetSalesPersonByStore[0].kuserID : null) : (this.state.GetSalesPersonByStore?.length > 0 ? this.state.GetSalesPersonByStore[0].kuserID : null)));

			stateVars.dataSource_36693 = stateVars.GetSalesPersonByStore ?? this.state.GetSalesPersonByStore;
			stateVars.dataSource_36693 = stateVars.GetSalesPersonByStore ?? this.state.GetSalesPersonByStore;

	this.props.form?.setFieldsValue(formVars);
	
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.SatisIslemiPageInit9_();
                  resolve();
                });
          })

            
            return isErrorOccurred;
        }
	SatisIslemiPageInit9_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


	if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
if (ReactSystemFunctions.isNotEmpty(ReactSystemFunctions.value(this, (stateVars.TM_GetThirdPartySalesDraftForResume !== undefined ? (stateVars.TM_GetThirdPartySalesDraftForResume?.length > 0 ? stateVars.TM_GetThirdPartySalesDraftForResume[0].salesDraftId : null) : (this.state.TM_GetThirdPartySalesDraftForResume?.length > 0 ? this.state.TM_GetThirdPartySalesDraftForResume[0].salesDraftId : null))), true)) {
            
			formVars.satisislemi_961229_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetSelectedCustomerSaleInfo !== undefined ? (stateVars.TM_GetSelectedCustomerSaleInfo?.length > 0 ? stateVars.TM_GetSelectedCustomerSaleInfo[0].customerId : null) : (this.state.TM_GetSelectedCustomerSaleInfo?.length > 0 ? this.state.TM_GetSelectedCustomerSaleInfo[0].customerId : null)));


	this.props.form?.setFieldsValue(formVars);
	
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.SatisIslemiPageInit10_();
                  resolve();
                });
          })

        } else {
            
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.SatisIslemiPageInit10_();
                  resolve();
                });
          })
        }

            
            return isErrorOccurred;
        }
	SatisIslemiPageInit10_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


	if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }

			
			stateVars.dataSource_961229 = stateVars.TM_GetCustomerByName ?? this.state.TM_GetCustomerByName;
			stateVars.dataSource_961229 = stateVars.TM_GetCustomerByName ?? this.state.TM_GetCustomerByName;
			stateVars.isComp629609Visible = ((ReactSystemFunctions.isNotEmpty(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "satisislemi_961229_value", "value", "TM_GetCustomerByName", "id", "id")), true)) === true ? "visible" : "hidden")

	this.props.form?.setFieldsValue(formVars);
	
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.SatisIslemiPageInit11_();
                  resolve();
                });
          })

            
            return isErrorOccurred;
        }
	SatisIslemiPageInit11_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


	if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
if (ReactSystemFunctions.isNotEmpty(ReactSystemFunctions.value(this, (stateVars.TM_GetThirdPartySalesDraftForResume !== undefined ? (stateVars.TM_GetThirdPartySalesDraftForResume?.length > 0 ? stateVars.TM_GetThirdPartySalesDraftForResume[0].salesDraftId : null) : (this.state.TM_GetThirdPartySalesDraftForResume?.length > 0 ? this.state.TM_GetThirdPartySalesDraftForResume[0].salesDraftId : null))), true)) {
            
			formVars.satisislemi_482972253_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetSelectedCustomerSaleInfo !== undefined ? (stateVars.TM_GetSelectedCustomerSaleInfo?.length > 0 ? stateVars.TM_GetSelectedCustomerSaleInfo[0].customerFullName : null) : (this.state.TM_GetSelectedCustomerSaleInfo?.length > 0 ? this.state.TM_GetSelectedCustomerSaleInfo[0].customerFullName : null)));


	this.props.form?.setFieldsValue(formVars);
	
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.SatisIslemiPageInit12_();
                  resolve();
                });
          })

        } else {
            
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.SatisIslemiPageInit12_();
                  resolve();
                });
          })
        }

            
            return isErrorOccurred;
        }
	SatisIslemiPageInit12_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


	if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
if (ReactSystemFunctions.isNotEmpty(ReactSystemFunctions.value(this, (stateVars.TM_GetThirdPartySalesDraftForResume !== undefined ? (stateVars.TM_GetThirdPartySalesDraftForResume?.length > 0 ? stateVars.TM_GetThirdPartySalesDraftForResume[0].salesDraftId : null) : (this.state.TM_GetThirdPartySalesDraftForResume?.length > 0 ? this.state.TM_GetThirdPartySalesDraftForResume[0].salesDraftId : null))), true)) {
            
			formVars.satisislemi_475914658_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetSelectedCustomerSaleInfo !== undefined ? (stateVars.TM_GetSelectedCustomerSaleInfo?.length > 0 ? stateVars.TM_GetSelectedCustomerSaleInfo[0].phoneNumber : null) : (this.state.TM_GetSelectedCustomerSaleInfo?.length > 0 ? this.state.TM_GetSelectedCustomerSaleInfo[0].phoneNumber : null)));


	this.props.form?.setFieldsValue(formVars);
	
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.SatisIslemiPageInit13_();
                  resolve();
                });
          })

        } else {
            
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.SatisIslemiPageInit13_();
                  resolve();
                });
          })
        }

            
            return isErrorOccurred;
        }
	SatisIslemiPageInit13_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


	if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
if (ReactSystemFunctions.isNotEmpty(ReactSystemFunctions.value(this, (stateVars.TM_GetThirdPartySalesDraftForResume !== undefined ? (stateVars.TM_GetThirdPartySalesDraftForResume?.length > 0 ? stateVars.TM_GetThirdPartySalesDraftForResume[0].salesDraftId : null) : (this.state.TM_GetThirdPartySalesDraftForResume?.length > 0 ? this.state.TM_GetThirdPartySalesDraftForResume[0].salesDraftId : null))), true)) {
            
			formVars.satisislemi_788067546_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetSelectedCustomerSaleInfo !== undefined ? (stateVars.TM_GetSelectedCustomerSaleInfo?.length > 0 ? stateVars.TM_GetSelectedCustomerSaleInfo[0].emailAddress : null) : (this.state.TM_GetSelectedCustomerSaleInfo?.length > 0 ? this.state.TM_GetSelectedCustomerSaleInfo[0].emailAddress : null)));


	this.props.form?.setFieldsValue(formVars);
	
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.SatisIslemiPageInit14_();
                  resolve();
                });
          })

        } else {
            
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.SatisIslemiPageInit14_();
                  resolve();
                });
          })
        }

            
            return isErrorOccurred;
        }
	SatisIslemiPageInit14_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


	if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
if (ReactSystemFunctions.isNotEmpty(ReactSystemFunctions.value(this, (stateVars.TM_GetThirdPartySalesDraftForResume !== undefined ? (stateVars.TM_GetThirdPartySalesDraftForResume?.length > 0 ? stateVars.TM_GetThirdPartySalesDraftForResume[0].salesDraftId : null) : (this.state.TM_GetThirdPartySalesDraftForResume?.length > 0 ? this.state.TM_GetThirdPartySalesDraftForResume[0].salesDraftId : null))), true)) {
            
			formVars.satisislemi_814342869_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetSelectedCustomerSaleInfo !== undefined ? (stateVars.TM_GetSelectedCustomerSaleInfo?.length > 0 ? stateVars.TM_GetSelectedCustomerSaleInfo[0].identityOrPassportNumber : null) : (this.state.TM_GetSelectedCustomerSaleInfo?.length > 0 ? this.state.TM_GetSelectedCustomerSaleInfo[0].identityOrPassportNumber : null)));


	this.props.form?.setFieldsValue(formVars);
	
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.SatisIslemiPageInit15_();
                  resolve();
                });
          })

        } else {
            
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.SatisIslemiPageInit15_();
                  resolve();
                });
          })
        }

            
            return isErrorOccurred;
        }
	SatisIslemiPageInit15_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


	if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
if (ReactSystemFunctions.isNotEmpty(ReactSystemFunctions.value(this, (stateVars.TM_GetThirdPartySalesDraftForResume !== undefined ? (stateVars.TM_GetThirdPartySalesDraftForResume?.length > 0 ? stateVars.TM_GetThirdPartySalesDraftForResume[0].salesDraftId : null) : (this.state.TM_GetThirdPartySalesDraftForResume?.length > 0 ? this.state.TM_GetThirdPartySalesDraftForResume[0].salesDraftId : null))), true)) {
            
			formVars.satisislemi_1027814808_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetSelectedCustomerSaleInfo !== undefined ? (stateVars.TM_GetSelectedCustomerSaleInfo?.length > 0 ? stateVars.TM_GetSelectedCustomerSaleInfo[0].location : null) : (this.state.TM_GetSelectedCustomerSaleInfo?.length > 0 ? this.state.TM_GetSelectedCustomerSaleInfo[0].location : null)));


	this.props.form?.setFieldsValue(formVars);
	
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.SatisIslemiPageInit16_();
                  resolve();
                });
          })

        } else {
            
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.SatisIslemiPageInit16_();
                  resolve();
                });
          })
        }

            
            return isErrorOccurred;
        }
	SatisIslemiPageInit16_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


	if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
if (ReactSystemFunctions.isNotEmpty(ReactSystemFunctions.value(this, (stateVars.TM_GetThirdPartySalesDraftForResume !== undefined ? (stateVars.TM_GetThirdPartySalesDraftForResume?.length > 0 ? stateVars.TM_GetThirdPartySalesDraftForResume[0].salesDraftId : null) : (this.state.TM_GetThirdPartySalesDraftForResume?.length > 0 ? this.state.TM_GetThirdPartySalesDraftForResume[0].salesDraftId : null))), true)) {
            
			formVars.satisislemi_581875571_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetSelectedCustomerSaleInfo !== undefined ? (stateVars.TM_GetSelectedCustomerSaleInfo?.length > 0 ? stateVars.TM_GetSelectedCustomerSaleInfo[0].shoppingStatusText : null) : (this.state.TM_GetSelectedCustomerSaleInfo?.length > 0 ? this.state.TM_GetSelectedCustomerSaleInfo[0].shoppingStatusText : null)));


	this.props.form?.setFieldsValue(formVars);
	
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.SatisIslemiPageInit17_();
                  resolve();
                });
          })

        } else {
            
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.SatisIslemiPageInit17_();
                  resolve();
                });
          })
        }

            
            return isErrorOccurred;
        }
	SatisIslemiPageInit17_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


	if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }

			stateVars.isComp581875571Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, (stateVars.TM_GetCustomerById !== undefined ? (stateVars.TM_GetCustomerById?.length > 0 ? stateVars.TM_GetCustomerById[0].isShopping : null) : (this.state.TM_GetCustomerById?.length > 0 ? this.state.TM_GetCustomerById[0].isShopping : null))), true)) === true ? "visible" : "hidden")
			stateVars.isComp170159Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "satisislemi_400617_value", "value", "", "key", "")), "2")) === true ? "visible" : "hidden")
			stateVars.isComp833620Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "satisislemi_286649_checked", "checked", "", "", "")), true)) === true ? "visible" : "hidden")
			stateVars.isComp434522991Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "satisislemi_675484_value", "value", "", "key", "")), "CUSTOMER")) === true ? "visible" : "hidden")
			stateVars.isComp1383831790Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "satisislemi_675484_value", "value", "", "key", "")), "CUSTOMER")) === true ? "visible" : "hidden")
			stateVars.isComp252425Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "satisislemi_675484_value", "value", "", "key", "")), "MANUAL")) === true ? "visible" : "hidden")
			stateVars.isComp719632801Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "satisislemi_971887955_value", "value", "", "key", "")), "PERSON")) === true ? "visible" : "hidden")
			stateVars.isComp725080941Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "satisislemi_971887955_value", "value", "", "key", "")), "COMPANY")) === true ? "visible" : "hidden")
			stateVars.isComp376527Visible = ((ReactSystemFunctions.isNotEmpty(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "satisislemi_971887955_value", "value", "", "key", "")), true)) === true ? "visible" : "hidden")
			stateVars.isComp91851Visible = ((ReactSystemFunctions.isNotEmpty(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "satisislemi_971887955_value", "value", "", "key", "")), true)) === true ? "visible" : "hidden")
			stateVars.isComp684346Enabled = ((ReactSystemFunctions.isNotEmpty(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "satisislemi_176363_value", "value", "", "", "")), true)) === true ? "enabled" : "disabled")

	this.props.form?.setFieldsValue(formVars);
	
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.SatisIslemiPageInit18_();
                  resolve();
                });
          })

            
            return isErrorOccurred;
        }
	SatisIslemiPageInit18_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


	if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
if (ReactSystemFunctions.isNotEmpty(ReactSystemFunctions.value(this, (stateVars.TM_GetThirdPartySalesDraftForResume !== undefined ? (stateVars.TM_GetThirdPartySalesDraftForResume?.length > 0 ? stateVars.TM_GetThirdPartySalesDraftForResume[0].salesDraftId : null) : (this.state.TM_GetThirdPartySalesDraftForResume?.length > 0 ? this.state.TM_GetThirdPartySalesDraftForResume[0].salesDraftId : null))), true)) {
            
			

	this.props.form?.setFieldsValue(formVars);
	
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.SatisIslemiPageInit19_();
                  resolve();
                });
          })

        } else {
            
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.SatisIslemiPageInit19_();
                  resolve();
                });
          })
        }

            
            return isErrorOccurred;
        }
	SatisIslemiPageInit19_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


	if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
if (ReactSystemFunctions.isNotEmpty(ReactSystemFunctions.value(this, (stateVars.TM_GetThirdPartySalesDraftForResume !== undefined ? (stateVars.TM_GetThirdPartySalesDraftForResume?.length > 0 ? stateVars.TM_GetThirdPartySalesDraftForResume[0].salesDraftId : null) : (this.state.TM_GetThirdPartySalesDraftForResume?.length > 0 ? this.state.TM_GetThirdPartySalesDraftForResume[0].salesDraftId : null))), true)) {
            
			stateVars.dataSource_41607 = stateVars.TMGetSalesProductDraft ?? this.state.TMGetSalesProductDraft;

	this.props.form?.setFieldsValue(formVars);
	
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.SatisIslemiPageInit20_();
                  resolve();
                });
          })

        } else {
            
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.SatisIslemiPageInit20_();
                  resolve();
                });
          })
        }

            
            return isErrorOccurred;
        }
	SatisIslemiPageInit20_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


	if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }

			stateVars.isComp625854Visible = ((ReactSystemFunctions.isEmpty(ReactSystemFunctions.value(this, "satisislemi_41607_value", "barcode"), true)) === true ? "visible" : "hidden")
			stateVars.isComp15169Visible = ((ReactSystemFunctions.isNotEmpty(ReactSystemFunctions.value(this, "satisislemi_41607_value", "barcode"), true)) === true ? "visible" : "hidden")
			stateVars.isComp759176Visible = ((ReactSystemFunctions.isNotEmpty(ReactSystemFunctions.value(this, (stateVars.TMGetSalesProductDraft !== undefined ? (stateVars.TMGetSalesProductDraft?.length > 0 ? stateVars.TMGetSalesProductDraft[0].id : null) : (this.state.TMGetSalesProductDraft?.length > 0 ? this.state.TMGetSalesProductDraft[0].id : null))), true)) === true ? "visible" : "hidden")
			
			stateVars.dataSource_987644 = stateVars.TM_GetSalesExchangesRate ?? this.state.TM_GetSalesExchangesRate;
			stateVars.isComp281463Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "satisislemi_831595_value", "value", "", "key", "")), "2")) === true ? "visible" : "hidden")

	this.props.form?.setFieldsValue(formVars);
	
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.SatisIslemiPageInit21_();
                  resolve();
                });
          })

            
            return isErrorOccurred;
        }
	SatisIslemiPageInit21_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


	if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
if (ReactSystemFunctions.isNotEmpty(ReactSystemFunctions.value(this, (stateVars.TM_GetThirdPartySalesDraftForResume !== undefined ? (stateVars.TM_GetThirdPartySalesDraftForResume?.length > 0 ? stateVars.TM_GetThirdPartySalesDraftForResume[stateVars.TM_GetThirdPartySalesDraftForResume.length - 1].salesDraftId : null) : (this.state.TM_GetThirdPartySalesDraftForResume?.length > 0 ? this.state.TM_GetThirdPartySalesDraftForResume[this.state.TM_GetThirdPartySalesDraftForResume.length - 1].salesDraftId : null))), true)) {
            
			

	this.props.form?.setFieldsValue(formVars);
	
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.SatisIslemiPageInit22_();
                  resolve();
                });
          })

        } else {
            
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.SatisIslemiPageInit22_();
                  resolve();
                });
          })
        }

            
            return isErrorOccurred;
        }
	SatisIslemiPageInit22_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


	if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
if (ReactSystemFunctions.isNotEmpty(ReactSystemFunctions.value(this, (stateVars.TM_GetThirdPartySalesDraftForResume !== undefined ? (stateVars.TM_GetThirdPartySalesDraftForResume?.length > 0 ? stateVars.TM_GetThirdPartySalesDraftForResume[stateVars.TM_GetThirdPartySalesDraftForResume.length - 1].salesDraftId : null) : (this.state.TM_GetThirdPartySalesDraftForResume?.length > 0 ? this.state.TM_GetThirdPartySalesDraftForResume[this.state.TM_GetThirdPartySalesDraftForResume.length - 1].salesDraftId : null))), true)) {
            
			stateVars.dataSource_466892 = stateVars.TMSalesPaymentList ?? this.state.TMSalesPaymentList;

	this.props.form?.setFieldsValue(formVars);
	
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.SatisIslemiPageInit23_();
                  resolve();
                });
          })

        } else {
            
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.SatisIslemiPageInit23_();
                  resolve();
                });
          })
        }

            
            return isErrorOccurred;
        }
	SatisIslemiPageInit23_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


	if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
if (ReactSystemFunctions.isNotEmpty(ReactSystemFunctions.value(this, (stateVars.TM_GetThirdPartySalesDraftForResume !== undefined ? (stateVars.TM_GetThirdPartySalesDraftForResume?.length > 0 ? stateVars.TM_GetThirdPartySalesDraftForResume[stateVars.TM_GetThirdPartySalesDraftForResume.length - 1].salesDraftId : null) : (this.state.TM_GetThirdPartySalesDraftForResume?.length > 0 ? this.state.TM_GetThirdPartySalesDraftForResume[this.state.TM_GetThirdPartySalesDraftForResume.length - 1].salesDraftId : null))), true)) {
            
			formVars.satisislemi_100771_value = ReactSystemFunctions.toString(this, (stateVars.TMSalesPaymentList !== undefined ? (stateVars.TMSalesPaymentList?.length > 0 ? stateVars.TMSalesPaymentList[0].collectedTotalEUR : null) : (this.state.TMSalesPaymentList?.length > 0 ? this.state.TMSalesPaymentList[0].collectedTotalEUR : null)));


	this.props.form?.setFieldsValue(formVars);
	
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.SatisIslemiPageInit24_();
                  resolve();
                });
          })

        } else {
            
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.SatisIslemiPageInit24_();
                  resolve();
                });
          })
        }

            
            return isErrorOccurred;
        }
	SatisIslemiPageInit24_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


	if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
if (ReactSystemFunctions.isNotEmpty(ReactSystemFunctions.value(this, (stateVars.TM_GetThirdPartySalesDraftForResume !== undefined ? (stateVars.TM_GetThirdPartySalesDraftForResume?.length > 0 ? stateVars.TM_GetThirdPartySalesDraftForResume[stateVars.TM_GetThirdPartySalesDraftForResume.length - 1].salesDraftId : null) : (this.state.TM_GetThirdPartySalesDraftForResume?.length > 0 ? this.state.TM_GetThirdPartySalesDraftForResume[this.state.TM_GetThirdPartySalesDraftForResume.length - 1].salesDraftId : null))), true)) {
            
			formVars.satisislemi_653586_value = ReactSystemFunctions.toString(this, (stateVars.TMSalesPaymentList !== undefined ? (stateVars.TMSalesPaymentList?.length > 0 ? stateVars.TMSalesPaymentList[0].remainingEUR : null) : (this.state.TMSalesPaymentList?.length > 0 ? this.state.TMSalesPaymentList[0].remainingEUR : null)));


	this.props.form?.setFieldsValue(formVars);
	
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.SatisIslemiPageInit25_();
                  resolve();
                });
          })

        } else {
            
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.SatisIslemiPageInit25_();
                  resolve();
                });
          })
        }

            
            return isErrorOccurred;
        }
	SatisIslemiPageInit25_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


	if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
if (ReactSystemFunctions.isNotEmpty(ReactSystemFunctions.value(this, (stateVars.TM_GetThirdPartySalesDraftForResume !== undefined ? (stateVars.TM_GetThirdPartySalesDraftForResume?.length > 0 ? stateVars.TM_GetThirdPartySalesDraftForResume[0].salesDraftId : null) : (this.state.TM_GetThirdPartySalesDraftForResume?.length > 0 ? this.state.TM_GetThirdPartySalesDraftForResume[0].salesDraftId : null))), true)) {
            
			formVars.satisislemi_706355_value = ReactSystemFunctions.toString(this, (stateVars.TMSalesSummary !== undefined ? (stateVars.TMSalesSummary?.length > 0 ? stateVars.TMSalesSummary[0].magaza : null) : (this.state.TMSalesSummary?.length > 0 ? this.state.TMSalesSummary[0].magaza : null)));


	this.props.form?.setFieldsValue(formVars);
	
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.SatisIslemiPageInit26_();
                  resolve();
                });
          })

        } else {
            
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.SatisIslemiPageInit26_();
                  resolve();
                });
          })
        }

            
            return isErrorOccurred;
        }
	SatisIslemiPageInit26_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


	if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
if (ReactSystemFunctions.isNotEmpty(ReactSystemFunctions.value(this, (stateVars.TM_GetThirdPartySalesDraftForResume !== undefined ? (stateVars.TM_GetThirdPartySalesDraftForResume?.length > 0 ? stateVars.TM_GetThirdPartySalesDraftForResume[0].salesDraftId : null) : (this.state.TM_GetThirdPartySalesDraftForResume?.length > 0 ? this.state.TM_GetThirdPartySalesDraftForResume[0].salesDraftId : null))), true)) {
            
			formVars.satisislemi_957854_value = ReactSystemFunctions.toString(this, (stateVars.TMSalesSummary !== undefined ? (stateVars.TMSalesSummary?.length > 0 ? stateVars.TMSalesSummary[0].personelAdi : null) : (this.state.TMSalesSummary?.length > 0 ? this.state.TMSalesSummary[0].personelAdi : null)));


	this.props.form?.setFieldsValue(formVars);
	
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.SatisIslemiPageInit27_();
                  resolve();
                });
          })

        } else {
            
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.SatisIslemiPageInit27_();
                  resolve();
                });
          })
        }

            
            return isErrorOccurred;
        }
	SatisIslemiPageInit27_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


	if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
if (ReactSystemFunctions.isNotEmpty(ReactSystemFunctions.value(this, (stateVars.TM_GetThirdPartySalesDraftForResume !== undefined ? (stateVars.TM_GetThirdPartySalesDraftForResume?.length > 0 ? stateVars.TM_GetThirdPartySalesDraftForResume[0].salesDraftId : null) : (this.state.TM_GetThirdPartySalesDraftForResume?.length > 0 ? this.state.TM_GetThirdPartySalesDraftForResume[0].salesDraftId : null))), true)) {
            
			formVars.satisislemi_687658_value = ReactSystemFunctions.toString(this, (stateVars.TMSalesSummary !== undefined ? (stateVars.TMSalesSummary?.length > 0 ? stateVars.TMSalesSummary[0].musteriAdi : null) : (this.state.TMSalesSummary?.length > 0 ? this.state.TMSalesSummary[0].musteriAdi : null)));


	this.props.form?.setFieldsValue(formVars);
	
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.SatisIslemiPageInit28_();
                  resolve();
                });
          })

        } else {
            
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.SatisIslemiPageInit28_();
                  resolve();
                });
          })
        }

            
            return isErrorOccurred;
        }
	SatisIslemiPageInit28_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


	if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
if (ReactSystemFunctions.isNotEmpty(ReactSystemFunctions.value(this, (stateVars.TM_GetThirdPartySalesDraftForResume !== undefined ? (stateVars.TM_GetThirdPartySalesDraftForResume?.length > 0 ? stateVars.TM_GetThirdPartySalesDraftForResume[0].salesDraftId : null) : (this.state.TM_GetThirdPartySalesDraftForResume?.length > 0 ? this.state.TM_GetThirdPartySalesDraftForResume[0].salesDraftId : null))), true)) {
            
			formVars.satisislemi_489530_value = ReactSystemFunctions.toString(this, (stateVars.TMSalesSummary !== undefined ? (stateVars.TMSalesSummary?.length > 0 ? stateVars.TMSalesSummary[0].urunAdedi : null) : (this.state.TMSalesSummary?.length > 0 ? this.state.TMSalesSummary[0].urunAdedi : null)));


	this.props.form?.setFieldsValue(formVars);
	
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.SatisIslemiPageInit29_();
                  resolve();
                });
          })

        } else {
            
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.SatisIslemiPageInit29_();
                  resolve();
                });
          })
        }

            
            return isErrorOccurred;
        }
	SatisIslemiPageInit29_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


	if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
if (ReactSystemFunctions.isNotEmpty(ReactSystemFunctions.value(this, (stateVars.TM_GetThirdPartySalesDraftForResume !== undefined ? (stateVars.TM_GetThirdPartySalesDraftForResume?.length > 0 ? stateVars.TM_GetThirdPartySalesDraftForResume[0].salesDraftId : null) : (this.state.TM_GetThirdPartySalesDraftForResume?.length > 0 ? this.state.TM_GetThirdPartySalesDraftForResume[0].salesDraftId : null))), true)) {
            
			formVars.satisislemi_34076_value = ReactSystemFunctions.toString(this, (stateVars.TMSalesSummary !== undefined ? (stateVars.TMSalesSummary?.length > 0 ? stateVars.TMSalesSummary[0].araToplam : null) : (this.state.TMSalesSummary?.length > 0 ? this.state.TMSalesSummary[0].araToplam : null)));


	this.props.form?.setFieldsValue(formVars);
	
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.SatisIslemiPageInit30_();
                  resolve();
                });
          })

        } else {
            
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.SatisIslemiPageInit30_();
                  resolve();
                });
          })
        }

            
            return isErrorOccurred;
        }
	SatisIslemiPageInit30_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


	if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
if (ReactSystemFunctions.isNotEmpty(ReactSystemFunctions.value(this, (stateVars.TM_GetThirdPartySalesDraftForResume !== undefined ? (stateVars.TM_GetThirdPartySalesDraftForResume?.length > 0 ? stateVars.TM_GetThirdPartySalesDraftForResume[0].salesDraftId : null) : (this.state.TM_GetThirdPartySalesDraftForResume?.length > 0 ? this.state.TM_GetThirdPartySalesDraftForResume[0].salesDraftId : null))), true)) {
            
			formVars.satisislemi_94614_value = ReactSystemFunctions.toString(this, (stateVars.TMSalesSummary !== undefined ? (stateVars.TMSalesSummary?.length > 0 ? stateVars.TMSalesSummary[0].iskontoTutari : null) : (this.state.TMSalesSummary?.length > 0 ? this.state.TMSalesSummary[0].iskontoTutari : null)));


	this.props.form?.setFieldsValue(formVars);
	
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.SatisIslemiPageInit31_();
                  resolve();
                });
          })

        } else {
            
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.SatisIslemiPageInit31_();
                  resolve();
                });
          })
        }

            
            return isErrorOccurred;
        }
	SatisIslemiPageInit31_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


	if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
if (ReactSystemFunctions.isNotEmpty(ReactSystemFunctions.value(this, (stateVars.TM_GetThirdPartySalesDraftForResume !== undefined ? (stateVars.TM_GetThirdPartySalesDraftForResume?.length > 0 ? stateVars.TM_GetThirdPartySalesDraftForResume[0].salesDraftId : null) : (this.state.TM_GetThirdPartySalesDraftForResume?.length > 0 ? this.state.TM_GetThirdPartySalesDraftForResume[0].salesDraftId : null))), true)) {
            
			formVars.satisislemi_28476_value = ReactSystemFunctions.toString(this, (stateVars.TMSalesSummary !== undefined ? (stateVars.TMSalesSummary?.length > 0 ? stateVars.TMSalesSummary[0].genelToplam : null) : (this.state.TMSalesSummary?.length > 0 ? this.state.TMSalesSummary[0].genelToplam : null)));


	this.props.form?.setFieldsValue(formVars);
	
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.SatisIslemiPageInit32_();
                  resolve();
                });
          })

        } else {
            
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.SatisIslemiPageInit32_();
                  resolve();
                });
          })
        }

            
            return isErrorOccurred;
        }
	SatisIslemiPageInit32_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


	if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
if (ReactSystemFunctions.isNotEmpty(ReactSystemFunctions.value(this, (stateVars.TM_GetThirdPartySalesDraftForResume !== undefined ? (stateVars.TM_GetThirdPartySalesDraftForResume?.length > 0 ? stateVars.TM_GetThirdPartySalesDraftForResume[0].salesDraftId : null) : (this.state.TM_GetThirdPartySalesDraftForResume?.length > 0 ? this.state.TM_GetThirdPartySalesDraftForResume[0].salesDraftId : null))), true)) {
            
			formVars.satisislemi_646001_value = ReactSystemFunctions.toString(this, (stateVars.TMSalesSummary !== undefined ? (stateVars.TMSalesSummary?.length > 0 ? stateVars.TMSalesSummary[0].tahsilEdilen : null) : (this.state.TMSalesSummary?.length > 0 ? this.state.TMSalesSummary[0].tahsilEdilen : null)));


	this.props.form?.setFieldsValue(formVars);
	
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.SatisIslemiPageInit33_();
                  resolve();
                });
          })

        } else {
            
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.SatisIslemiPageInit33_();
                  resolve();
                });
          })
        }

            
            return isErrorOccurred;
        }
	SatisIslemiPageInit33_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


	if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
if (ReactSystemFunctions.isNotEmpty(ReactSystemFunctions.value(this, (stateVars.TM_GetThirdPartySalesDraftForResume !== undefined ? (stateVars.TM_GetThirdPartySalesDraftForResume?.length > 0 ? stateVars.TM_GetThirdPartySalesDraftForResume[0].salesDraftId : null) : (this.state.TM_GetThirdPartySalesDraftForResume?.length > 0 ? this.state.TM_GetThirdPartySalesDraftForResume[0].salesDraftId : null))), true)) {
            
			formVars.satisislemi_804074_value = ReactSystemFunctions.toString(this, (stateVars.TMSalesSummary !== undefined ? (stateVars.TMSalesSummary?.length > 0 ? stateVars.TMSalesSummary[0].kalanTutar : null) : (this.state.TMSalesSummary?.length > 0 ? this.state.TMSalesSummary[0].kalanTutar : null)));


	this.props.form?.setFieldsValue(formVars);
	
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.SatisIslemiPageInit34_();
                  resolve();
                });
          })

        } else {
            
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.SatisIslemiPageInit34_();
                  resolve();
                });
          })
        }

            
            return isErrorOccurred;
        }
	SatisIslemiPageInit34_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


	if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }

			stateVars.isComp1112812883Enabled = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, (stateVars.TMSalesPaymentList !== undefined ? (stateVars.TMSalesPaymentList?.length > 0 ? stateVars.TMSalesPaymentList[0].remainingEUR : null) : (this.state.TMSalesPaymentList?.length > 0 ? this.state.TMSalesPaymentList[0].remainingEUR : null))), "0")) === true ? "enabled" : "disabled")
			stateVars.isComp761489Enabled = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, (stateVars.TMSalesPaymentList !== undefined ? (stateVars.TMSalesPaymentList?.length > 0 ? stateVars.TMSalesPaymentList[0].remainingEUR : null) : (this.state.TMSalesPaymentList?.length > 0 ? this.state.TMSalesPaymentList[0].remainingEUR : null))), "0")) === true ? "enabled" : "disabled")

	this.props.form?.setFieldsValue(formVars);
	this.setState(stateVars);
	KuikaAppManager.hideSpinner(this);

            this.setPageInitLoaded(true);
            return isErrorOccurred;
        }










































    SatisIslemiComponent_516749_onChange = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
		KuikaAppManager.increaseServerRequestCount();

        let localVar = {
				StoreId_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "satisislemi_516749_value", "value", "TM_StoreGetList", "id", "id")), "Guid")
        }

		KuikaAppManager.showSpinner(this);
		
        if (true) {
        KuikaAppManager.showSpinner(this);
        }
        let result = await KuikaAppManager.ApiRequest(this, "SatisIslemi/SatisIslemiComponent_516749_onChange", localVar)
        if (!KMainFunctions.IsResStatus2XX(result)) return true;

			stateVars.GetSalesPersonByStore = result?.data.getSalesPersonByStore;
			
			formVars.satisislemi_36693_value = (stateVars.GetSalesPersonByStore !== undefined ? (stateVars.GetSalesPersonByStore?.length > 0 ? stateVars.GetSalesPersonByStore[0].kuserID : null) : (this.state.GetSalesPersonByStore?.length > 0 ? this.state.GetSalesPersonByStore[0].kuserID : null));
			formVars.satisislemi_36693_options = stateVars.GetSalesPersonByStore;
			this.props.form?.setFieldsValue(formVars);
			
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.SatisIslemiComponent_516749_onChange1_();
                  resolve();
                });
          })



        
        KuikaAppManager.hideSpinner(this);
        return isErrorOccurred;
    }
		SatisIslemiComponent_516749_onChange1_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }

				formVars.satisislemi_36693_value = ReactSystemFunctions.toString(this, (stateVars.GetSalesPersonByStore !== undefined ? (stateVars.GetSalesPersonByStore?.length > 0 ? stateVars.GetSalesPersonByStore[0].kuserID : null) : (this.state.GetSalesPersonByStore?.length > 0 ? this.state.GetSalesPersonByStore[0].kuserID : null)));

				formVars.satisislemi_36693_value = ReactSystemFunctions.toString(this, (stateVars.GetSalesPersonByStore !== undefined ? (stateVars.GetSalesPersonByStore?.length > 0 ? stateVars.GetSalesPersonByStore[0].kuserID : null) : (this.state.GetSalesPersonByStore?.length > 0 ? this.state.GetSalesPersonByStore[0].kuserID : null)));

				stateVars.dataSource_36693 = stateVars.GetSalesPersonByStore ?? this.state.GetSalesPersonByStore;
				stateVars.dataSource_36693 = stateVars.GetSalesPersonByStore ?? this.state.GetSalesPersonByStore;

		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

            
            return isErrorOccurred;
        }




    SatisIslemiComponent_961229_onChange = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
		KuikaAppManager.increaseServerRequestCount();

        let localVar = {
				CustomerId_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "satisislemi_961229_value", "value", "TM_GetCustomerByName", "id", "id")), "Guid"),
				CustomerId_1: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "satisislemi_961229_value", "value", "TM_GetCustomerByName", "id", "id")), "Guid"),
				CustomerId_2: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "satisislemi_961229_value", "value", "TM_GetCustomerByName", "id", "id")), "Guid")
        }

		KuikaAppManager.showSpinner(this);
		
        if (true) {
        KuikaAppManager.showSpinner(this);
        }
        let result = await KuikaAppManager.ApiRequest(this, "SatisIslemi/SatisIslemiComponent_961229_onChange", localVar)
        if (!KMainFunctions.IsResStatus2XX(result)) return true;

			stateVars.TM_GetCustomerById = result?.data.tM_GetCustomerById;
			stateVars.isComp581875571Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, (stateVars.TM_GetCustomerById !== undefined ? (stateVars.TM_GetCustomerById?.length > 0 ? stateVars.TM_GetCustomerById[0].isShopping : null) : (this.state.TM_GetCustomerById?.length > 0 ? this.state.TM_GetCustomerById[0].isShopping : null))), ReactSystemFunctions.convertToTypeByName("True", "string"))) === true ? "visible" : "hidden")
			stateVars.TM_GetSelectedCustomerSaleInfo = result?.data.tM_GetSelectedCustomerSaleInfo;
			formVars.satisislemi_961229_value = (stateVars.TM_GetSelectedCustomerSaleInfo !== undefined ? (stateVars.TM_GetSelectedCustomerSaleInfo?.length > 0 ? stateVars.TM_GetSelectedCustomerSaleInfo[0].customerId : null) : (this.state.TM_GetSelectedCustomerSaleInfo?.length > 0 ? this.state.TM_GetSelectedCustomerSaleInfo[0].customerId : null));
			formVars.satisislemi_482972253_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetSelectedCustomerSaleInfo !== undefined ? (stateVars.TM_GetSelectedCustomerSaleInfo?.length > 0 ? stateVars.TM_GetSelectedCustomerSaleInfo[0].customerFullName : null) : (this.state.TM_GetSelectedCustomerSaleInfo?.length > 0 ? this.state.TM_GetSelectedCustomerSaleInfo[0].customerFullName : null)));
			formVars.satisislemi_475914658_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetSelectedCustomerSaleInfo !== undefined ? (stateVars.TM_GetSelectedCustomerSaleInfo?.length > 0 ? stateVars.TM_GetSelectedCustomerSaleInfo[0].phoneNumber : null) : (this.state.TM_GetSelectedCustomerSaleInfo?.length > 0 ? this.state.TM_GetSelectedCustomerSaleInfo[0].phoneNumber : null)));
			formVars.satisislemi_788067546_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetSelectedCustomerSaleInfo !== undefined ? (stateVars.TM_GetSelectedCustomerSaleInfo?.length > 0 ? stateVars.TM_GetSelectedCustomerSaleInfo[0].emailAddress : null) : (this.state.TM_GetSelectedCustomerSaleInfo?.length > 0 ? this.state.TM_GetSelectedCustomerSaleInfo[0].emailAddress : null)));
			formVars.satisislemi_814342869_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetSelectedCustomerSaleInfo !== undefined ? (stateVars.TM_GetSelectedCustomerSaleInfo?.length > 0 ? stateVars.TM_GetSelectedCustomerSaleInfo[0].identityOrPassportNumber : null) : (this.state.TM_GetSelectedCustomerSaleInfo?.length > 0 ? this.state.TM_GetSelectedCustomerSaleInfo[0].identityOrPassportNumber : null)));
			formVars.satisislemi_1027814808_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetSelectedCustomerSaleInfo !== undefined ? (stateVars.TM_GetSelectedCustomerSaleInfo?.length > 0 ? stateVars.TM_GetSelectedCustomerSaleInfo[0].location : null) : (this.state.TM_GetSelectedCustomerSaleInfo?.length > 0 ? this.state.TM_GetSelectedCustomerSaleInfo[0].location : null)));
			formVars.satisislemi_581875571_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetSelectedCustomerSaleInfo !== undefined ? (stateVars.TM_GetSelectedCustomerSaleInfo?.length > 0 ? stateVars.TM_GetSelectedCustomerSaleInfo[0].shoppingStatusText : null) : (this.state.TM_GetSelectedCustomerSaleInfo?.length > 0 ? this.state.TM_GetSelectedCustomerSaleInfo[0].shoppingStatusText : null)));
			stateVars.TM_CheckCustomerVerificationPopup = result?.data.tM_CheckCustomerVerificationPopup;
			this.props.form?.setFieldsValue(formVars);
			
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.SatisIslemiComponent_961229_onChange1_();
                  resolve();
                });
          })



        
        KuikaAppManager.hideSpinner(this);
        return isErrorOccurred;
    }
		SatisIslemiComponent_961229_onChange1_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
if (ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, (stateVars.TM_CheckCustomerVerificationPopup !== undefined ? (stateVars.TM_CheckCustomerVerificationPopup?.length > 0 ? stateVars.TM_CheckCustomerVerificationPopup[0].openPopup : null) : (this.state.TM_CheckCustomerVerificationPopup?.length > 0 ? this.state.TM_CheckCustomerVerificationPopup[0].openPopup : null))), true)) {
            
					KuikaAppManager.prepareForNavigation();
						KuikaAppManager.addToPageInputVariables("MusteriOnayPop", "CustomerId", ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "satisislemi_961229_value", "value", "TM_GetCustomerByName", "id", "id")), "Guid"));

				stateVars.NAVIGATE = await ReactSystemFunctions.navigate(this, this.SatisIslemiComponent_961229_onChange2_, "SatisIslemi", "MusteriOnayPop", "", "9924ef5f-4b84-4200-b624-8d76348c7686", "1890294612", null, null, "False", "80%", "90%", false, false);

		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

        } else {
            
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.SatisIslemiComponent_961229_onChange2_();
                  resolve();
                });
          })
        }

            
            return isErrorOccurred;
        }
		SatisIslemiComponent_961229_onChange2_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
KuikaAppManager.showSpinner(this);

				formVars.satisislemi_961229_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetSelectedCustomerSaleInfo !== undefined ? (stateVars.TM_GetSelectedCustomerSaleInfo?.length > 0 ? stateVars.TM_GetSelectedCustomerSaleInfo[0].customerId : null) : (this.state.TM_GetSelectedCustomerSaleInfo?.length > 0 ? this.state.TM_GetSelectedCustomerSaleInfo[0].customerId : null)));

				stateVars.isComp629609Visible = ((ReactSystemFunctions.isNotEmpty(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "satisislemi_961229_value", "value", "TM_GetCustomerByName", "id", "id")), true)) === true ? "visible" : "hidden")
				formVars.satisislemi_482972253_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetSelectedCustomerSaleInfo !== undefined ? (stateVars.TM_GetSelectedCustomerSaleInfo?.length > 0 ? stateVars.TM_GetSelectedCustomerSaleInfo[0].customerFullName : null) : (this.state.TM_GetSelectedCustomerSaleInfo?.length > 0 ? this.state.TM_GetSelectedCustomerSaleInfo[0].customerFullName : null)));

				formVars.satisislemi_475914658_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetSelectedCustomerSaleInfo !== undefined ? (stateVars.TM_GetSelectedCustomerSaleInfo?.length > 0 ? stateVars.TM_GetSelectedCustomerSaleInfo[0].phoneNumber : null) : (this.state.TM_GetSelectedCustomerSaleInfo?.length > 0 ? this.state.TM_GetSelectedCustomerSaleInfo[0].phoneNumber : null)));

				formVars.satisislemi_788067546_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetSelectedCustomerSaleInfo !== undefined ? (stateVars.TM_GetSelectedCustomerSaleInfo?.length > 0 ? stateVars.TM_GetSelectedCustomerSaleInfo[0].emailAddress : null) : (this.state.TM_GetSelectedCustomerSaleInfo?.length > 0 ? this.state.TM_GetSelectedCustomerSaleInfo[0].emailAddress : null)));

				formVars.satisislemi_814342869_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetSelectedCustomerSaleInfo !== undefined ? (stateVars.TM_GetSelectedCustomerSaleInfo?.length > 0 ? stateVars.TM_GetSelectedCustomerSaleInfo[0].identityOrPassportNumber : null) : (this.state.TM_GetSelectedCustomerSaleInfo?.length > 0 ? this.state.TM_GetSelectedCustomerSaleInfo[0].identityOrPassportNumber : null)));

				formVars.satisislemi_1027814808_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetSelectedCustomerSaleInfo !== undefined ? (stateVars.TM_GetSelectedCustomerSaleInfo?.length > 0 ? stateVars.TM_GetSelectedCustomerSaleInfo[0].location : null) : (this.state.TM_GetSelectedCustomerSaleInfo?.length > 0 ? this.state.TM_GetSelectedCustomerSaleInfo[0].location : null)));

				formVars.satisislemi_581875571_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetSelectedCustomerSaleInfo !== undefined ? (stateVars.TM_GetSelectedCustomerSaleInfo?.length > 0 ? stateVars.TM_GetSelectedCustomerSaleInfo[0].shoppingStatusText : null) : (this.state.TM_GetSelectedCustomerSaleInfo?.length > 0 ? this.state.TM_GetSelectedCustomerSaleInfo[0].shoppingStatusText : null)));


		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

            
            return isErrorOccurred;
        }





		SatisIslemiComponent_937792_onClick = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
KuikaAppManager.showSpinner(this);

					KuikaAppManager.prepareForNavigation();

				stateVars.NAVIGATE = await ReactSystemFunctions.navigate(this, undefined, "SatisIslemi", "CustomerCreatePost", "", "7d969ddf-5801-4eb6-b92b-12be35bdd565", "394010", null, "right", "true", "80%", "100vh", true, false);

		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

            
            return isErrorOccurred;
        }


		SatisIslemiComponent_1871886692_onClick = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
KuikaAppManager.showSpinner(this);

					KuikaAppManager.prepareForNavigation();
						KuikaAppManager.addToPageInputVariables("CustomerUpdatePost", "CustomerId", ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "satisislemi_961229_value", "value", "TM_GetCustomerByName", "id", "id")), "Guid"));

				stateVars.NAVIGATE = await ReactSystemFunctions.navigate(this, undefined, "SatisIslemi", "CustomerUpdatePost", "", "7d969ddf-5801-4eb6-b92b-12be35bdd565", "1375005592", null, "right", "true", "80%", "100vh", true, false);

		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

            
            return isErrorOccurred;
        }


    SatisIslemiComponent_286649_onChange = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
		KuikaAppManager.increaseServerRequestCount();

        let localVar = {
        }

		KuikaAppManager.showSpinner(this);
		
        if (true) {
        KuikaAppManager.showSpinner(this);
        }
        let result = await KuikaAppManager.ApiRequest(this, "SatisIslemi/SatisIslemiComponent_286649_onChange", localVar)
        if (!KMainFunctions.IsResStatus2XX(result)) return true;

			stateVars.TM_GetThirdPartyInvoiceCustomerList = result?.data.tM_GetThirdPartyInvoiceCustomerList;
			
			formVars.satisislemi_1278099362_options = stateVars.TM_GetThirdPartyInvoiceCustomerList;
			this.props.form?.setFieldsValue(formVars);
			
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.SatisIslemiComponent_286649_onChange1_();
                  resolve();
                });
          })



        
        KuikaAppManager.hideSpinner(this);
        return isErrorOccurred;
    }
		SatisIslemiComponent_286649_onChange1_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }

				stateVars.isComp833620Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "satisislemi_286649_checked", "checked", "", "", "")), true)) === true ? "visible" : "hidden")
				
				stateVars.dataSource_1278099362 = stateVars.TM_GetThirdPartyInvoiceCustomerList ?? this.state.TM_GetThirdPartyInvoiceCustomerList;
				stateVars.dataSource_1278099362 = stateVars.TM_GetThirdPartyInvoiceCustomerList ?? this.state.TM_GetThirdPartyInvoiceCustomerList;

		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

            
            return isErrorOccurred;
        }




    SatisIslemiComponent_675484_onChange = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
		KuikaAppManager.increaseServerRequestCount();

        let localVar = {
        }

		KuikaAppManager.showSpinner(this);
		
        if (true) {
        KuikaAppManager.showSpinner(this);
        }
        let result = await KuikaAppManager.ApiRequest(this, "SatisIslemi/SatisIslemiComponent_675484_onChange", localVar)
        if (!KMainFunctions.IsResStatus2XX(result)) return true;

			stateVars.TM_GetCountry = result?.data.tM_GetCountry;
			
			formVars.satisislemi_1090044654_options = stateVars.TM_GetCountry;
			this.props.form?.setFieldsValue(formVars);
			
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.SatisIslemiComponent_675484_onChange1_();
                  resolve();
                });
          })



        
        KuikaAppManager.hideSpinner(this);
        return isErrorOccurred;
    }
		SatisIslemiComponent_675484_onChange1_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }

				stateVars.isComp434522991Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "satisislemi_675484_value", "value", "", "key", "")), "CUSTOMER")) === true ? "visible" : "hidden")
				stateVars.isComp1383831790Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "satisislemi_675484_value", "value", "", "key", "")), "CUSTOMER")) === true ? "visible" : "hidden")
				stateVars.isComp252425Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "satisislemi_675484_value", "value", "", "key", "")), "MANUAL")) === true ? "visible" : "hidden")
				
				stateVars.dataSource_1090044654 = stateVars.TM_GetCountry ?? this.state.TM_GetCountry;
				stateVars.dataSource_1090044654 = stateVars.TM_GetCountry ?? this.state.TM_GetCountry;

		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

            
            return isErrorOccurred;
        }




    SatisIslemiComponent_1090044654_onChange = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
		KuikaAppManager.increaseServerRequestCount();

        let localVar = {
				CountryCode_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "satisislemi_1090044654_value", "value", "TM_GetCountry", "countryCode", "countryCode")), "string")
        }

		KuikaAppManager.showSpinner(this);
		
        if (true) {
        KuikaAppManager.showSpinner(this);
        }
        let result = await KuikaAppManager.ApiRequest(this, "SatisIslemi/SatisIslemiComponent_1090044654_onChange", localVar)
        if (!KMainFunctions.IsResStatus2XX(result)) return true;

			stateVars.TM_GetCitySql = result?.data.tM_GetCitySql;
			
			formVars.satisislemi_578279381_options = stateVars.TM_GetCitySql;
			this.props.form?.setFieldsValue(formVars);
			
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.SatisIslemiComponent_1090044654_onChange1_();
                  resolve();
                });
          })



        
        KuikaAppManager.hideSpinner(this);
        return isErrorOccurred;
    }
		SatisIslemiComponent_1090044654_onChange1_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }

				
				stateVars.dataSource_578279381 = stateVars.TM_GetCitySql ?? this.state.TM_GetCitySql;
				stateVars.dataSource_578279381 = stateVars.TM_GetCitySql ?? this.state.TM_GetCitySql;

		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

            
            return isErrorOccurred;
        }




    SatisIslemiComponent_578279381_onChange = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
		KuikaAppManager.increaseServerRequestCount();

        let localVar = {
				CityCode_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "satisislemi_578279381_value", "value", "TM_GetCitySql", "cityCode", "cityCode")), "string")
        }

		KuikaAppManager.showSpinner(this);
		
        if (true) {
        KuikaAppManager.showSpinner(this);
        }
        let result = await KuikaAppManager.ApiRequest(this, "SatisIslemi/SatisIslemiComponent_578279381_onChange", localVar)
        if (!KMainFunctions.IsResStatus2XX(result)) return true;

			stateVars.TM_GetDistrict = result?.data.tM_GetDistrict;
			
			formVars.satisislemi_1084844233_options = stateVars.TM_GetDistrict;
			this.props.form?.setFieldsValue(formVars);
			
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.SatisIslemiComponent_578279381_onChange1_();
                  resolve();
                });
          })



        
        KuikaAppManager.hideSpinner(this);
        return isErrorOccurred;
    }
		SatisIslemiComponent_578279381_onChange1_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }

				
				stateVars.dataSource_1084844233 = stateVars.TM_GetDistrict ?? this.state.TM_GetDistrict;
				stateVars.dataSource_1084844233 = stateVars.TM_GetDistrict ?? this.state.TM_GetDistrict;

		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

            
            return isErrorOccurred;
        }




    SatisIslemiComponent_555308_onClick = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
		KuikaAppManager.increaseServerRequestCount();

        let localVar = {
				SalesPersonTMUserId_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "satisislemi_36693_value", "value", "GetSalesPersonByStore", "kuserID", "id")), "Guid"),
				KUserId_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.getMyUserId(), "Guid"),
				InvoiceType_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toInteger(this, ReactSystemFunctions.value(this, "satisislemi_400617_value", "value", "", "key", "")), "number"),
				TaxFreeOturuNo_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "satisislemi_708806_value", "value", "", "", "")), "string"),
				TaxFreeBaslangic_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "satisislemi_403854_value", "value", "", "", "")), "Date"),
				TaxFreeBitis_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "satisislemi_141674_value", "value", "", "", "")), "Date"),
				CustomerId_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "satisislemi_961229_value", "value", "TM_GetCustomerByName", "id", "id")), "Guid"),
				IsEInvoiceApi_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, (stateVars.TM_GetCustomerById !== undefined ? (stateVars.TM_GetCustomerById?.length > 0 ? stateVars.TM_GetCustomerById[0].isEInvoice : null) : (this.state.TM_GetCustomerById?.length > 0 ? this.state.TM_GetCustomerById[0].isEInvoice : null))), "boolean"),
				StoreCode_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "satisislemi_36693_value", "value", "GetSalesPersonByStore", "kuserID", "storeCode")), "string")
        }

		KuikaAppManager.showSpinner(this);
		
        if (true) {
        KuikaAppManager.showSpinner(this);
        }
        let result = await KuikaAppManager.ApiRequest(this, "SatisIslemi/SatisIslemiComponent_555308_onClick", localVar)
        if (!KMainFunctions.IsResStatus2XX(result)) return true;

			stateVars.TMSalesDraftCreate = result?.data.tmSalesDraftCreate;
			this.props.form?.setFieldsValue(formVars);
			
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.SatisIslemiComponent_555308_onClick1_();
                  resolve();
                });
          })



        
        KuikaAppManager.hideSpinner(this);
        return isErrorOccurred;
    }
    SatisIslemiComponent_555308_onClick1_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
		KuikaAppManager.increaseServerRequestCount();

        let localVar = {
				IsThirdPartyInvoice_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "satisislemi_286649_checked", "checked", "", "", "")), "boolean"),
				SalesDraftId_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, (stateVars.TMSalesDraftCreate !== undefined ? (stateVars.TMSalesDraftCreate?.length > 0 ? stateVars.TMSalesDraftCreate[0].draftId : null) : (this.state.TMSalesDraftCreate?.length > 0 ? this.state.TMSalesDraftCreate[0].draftId : null))), "Guid"),
				CurrentUserId_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.getMyUserId(), "Guid"),
				ThirdPartySourceType_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "satisislemi_675484_value", "value", "", "key", "")), "string"),
				ThirdPartyCustomerId_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "satisislemi_1278099362_value", "value", "TM_GetThirdPartyInvoiceCustomerList", "id", "id")), "Guid"),
				ThirdPartyPersonType_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "satisislemi_971887955_value", "value", "", "key", "")), "string"),
				ThirdPartyFirstName_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "satisislemi_1826185521_value", "value", "", "", "")), "string"),
				ThirdPartyLastName_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "satisislemi_1003513911_value", "value", "", "", "")), "string"),
				ThirdPartyIdentityNumber_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "satisislemi_1464483161_value", "value", "", "", "")), "string"),
				ThirdPartyCompanyName_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "satisislemi_428413438_value", "value", "", "", "")), "string"),
				ThirdPartyTaxNumber_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "satisislemi_1393703318_value", "value", "", "", "")), "string"),
				ThirdPartyTaxOfficeCode_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "satisislemi_2006075834_value", "value", "", "", "")), "string"),
				ThirdPartyAddress_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "satisislemi_1694362615_value", "value", "", "", "")), "string"),
				ThirdPartyCountryCode_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "satisislemi_1090044654_value", "value", "TM_GetCountry", "countryCode", "countryCode")), "string"),
				ThirdPartyCityCode_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "satisislemi_578279381_value", "value", "TM_GetCitySql", "cityCode", "cityCode")), "string"),
				ThirdPartyDistrictCode_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "satisislemi_1084844233_value", "value", "TM_GetDistrict", "districtCode", "districtCode")), "string")
        }

if ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, (stateVars.TMSalesDraftCreate !== undefined ? (stateVars.TMSalesDraftCreate?.length > 0 ? stateVars.TMSalesDraftCreate[0].success : null) : (this.state.TMSalesDraftCreate?.length > 0 ? this.state.TMSalesDraftCreate[0].success : null))), ReactSystemFunctions.convertToTypeByName("1", "string")) && ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "satisislemi_286649_checked", "checked", "", "", "")), ReactSystemFunctions.convertToTypeByName("True", "string")))) {
            		
        if (true) {
        KuikaAppManager.showSpinner(this);
        }
        let result = await KuikaAppManager.ApiRequest(this, "SatisIslemi/SatisIslemiComponent_555308_onClick1_", localVar)
        if (!KMainFunctions.IsResStatus2XX(result)) return true;

			stateVars.TM_CreateThirdPartyInvoiceApprovalDraft = result?.data.tM_CreateThirdPartyInvoiceApprovalDraft;
			this.props.form?.setFieldsValue(formVars);
			
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.SatisIslemiComponent_555308_onClick2_();
                  resolve();
                });
          })

        } else {
            
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.SatisIslemiComponent_555308_onClick2_();
                  resolve();
                });
          })
        }


        
        KuikaAppManager.hideSpinner(this);
        return isErrorOccurred;
    }
		SatisIslemiComponent_555308_onClick2_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
if (ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, (stateVars.TMSalesDraftCreate !== undefined ? (stateVars.TMSalesDraftCreate?.length > 0 ? stateVars.TMSalesDraftCreate[0].success : null) : (this.state.TMSalesDraftCreate?.length > 0 ? this.state.TMSalesDraftCreate[0].success : null))), "1")) {
            
				stateVars.SetValueOf = await ReactSystemFunctions.setValueOf(this, ReactSystemFunctions.convertToTypeByName("satisislemi_176363_value", "string"), ReactSystemFunctions.toString(this, (stateVars.TMSalesDraftCreate !== undefined ? (stateVars.TMSalesDraftCreate?.length > 0 ? stateVars.TMSalesDraftCreate[0].draftId : null) : (this.state.TMSalesDraftCreate?.length > 0 ? this.state.TMSalesDraftCreate[0].draftId : null))), null, false);

		this.props.form?.setFieldsValue(formVars);
		
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.SatisIslemiComponent_555308_onClick3_();
                  resolve();
                });
          })

        } else {
            
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.SatisIslemiComponent_555308_onClick3_();
                  resolve();
                });
          })
        }

            
            return isErrorOccurred;
        }
    SatisIslemiComponent_555308_onClick3_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
		KuikaAppManager.increaseServerRequestCount();

        let localVar = {
				DraftId_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toGuid(this, ReactSystemFunctions.value(this, "satisislemi_176363_value", "value", "", "", "")), "Guid")
        }

		
        if (true) {
        KuikaAppManager.showSpinner(this);
        }
        let result = await KuikaAppManager.ApiRequest(this, "SatisIslemi/SatisIslemiComponent_555308_onClick3_", localVar)
        if (!KMainFunctions.IsResStatus2XX(result)) return true;

			stateVars.TMSalesSummary = result?.data.tmSalesSummary;
			formVars.satisislemi_706355_value = ReactSystemFunctions.toString(this, (stateVars.TMSalesSummary !== undefined ? (stateVars.TMSalesSummary?.length > 0 ? stateVars.TMSalesSummary[0].magaza : null) : (this.state.TMSalesSummary?.length > 0 ? this.state.TMSalesSummary[0].magaza : null)));
			formVars.satisislemi_957854_value = ReactSystemFunctions.toString(this, (stateVars.TMSalesSummary !== undefined ? (stateVars.TMSalesSummary?.length > 0 ? stateVars.TMSalesSummary[0].personelAdi : null) : (this.state.TMSalesSummary?.length > 0 ? this.state.TMSalesSummary[0].personelAdi : null)));
			formVars.satisislemi_687658_value = ReactSystemFunctions.toString(this, (stateVars.TMSalesSummary !== undefined ? (stateVars.TMSalesSummary?.length > 0 ? stateVars.TMSalesSummary[0].musteriAdi : null) : (this.state.TMSalesSummary?.length > 0 ? this.state.TMSalesSummary[0].musteriAdi : null)));
			formVars.satisislemi_489530_value = ReactSystemFunctions.toString(this, (stateVars.TMSalesSummary !== undefined ? (stateVars.TMSalesSummary?.length > 0 ? stateVars.TMSalesSummary[0].urunAdedi : null) : (this.state.TMSalesSummary?.length > 0 ? this.state.TMSalesSummary[0].urunAdedi : null)));
			formVars.satisislemi_34076_value = ReactSystemFunctions.toString(this, (stateVars.TMSalesSummary !== undefined ? (stateVars.TMSalesSummary?.length > 0 ? stateVars.TMSalesSummary[0].araToplam : null) : (this.state.TMSalesSummary?.length > 0 ? this.state.TMSalesSummary[0].araToplam : null)));
			formVars.satisislemi_94614_value = ReactSystemFunctions.toString(this, (stateVars.TMSalesSummary !== undefined ? (stateVars.TMSalesSummary?.length > 0 ? stateVars.TMSalesSummary[0].iskontoTutari : null) : (this.state.TMSalesSummary?.length > 0 ? this.state.TMSalesSummary[0].iskontoTutari : null)));
			formVars.satisislemi_28476_value = ReactSystemFunctions.toString(this, (stateVars.TMSalesSummary !== undefined ? (stateVars.TMSalesSummary?.length > 0 ? stateVars.TMSalesSummary[0].genelToplam : null) : (this.state.TMSalesSummary?.length > 0 ? this.state.TMSalesSummary[0].genelToplam : null)));
			formVars.satisislemi_646001_value = ReactSystemFunctions.toString(this, (stateVars.TMSalesSummary !== undefined ? (stateVars.TMSalesSummary?.length > 0 ? stateVars.TMSalesSummary[0].tahsilEdilen : null) : (this.state.TMSalesSummary?.length > 0 ? this.state.TMSalesSummary[0].tahsilEdilen : null)));
			formVars.satisislemi_804074_value = ReactSystemFunctions.toString(this, (stateVars.TMSalesSummary !== undefined ? (stateVars.TMSalesSummary?.length > 0 ? stateVars.TMSalesSummary[0].kalanTutar : null) : (this.state.TMSalesSummary?.length > 0 ? this.state.TMSalesSummary[0].kalanTutar : null)));
			this.props.form?.setFieldsValue(formVars);
			
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.SatisIslemiComponent_555308_onClick4_();
                  resolve();
                });
          })



        
        KuikaAppManager.hideSpinner(this);
        return isErrorOccurred;
    }
		SatisIslemiComponent_555308_onClick4_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }

				stateVars.Notify = await ReactSystemFunctions.notify(this, ReactSystemFunctions.toString(this, (stateVars.TMSalesDraftCreate !== undefined ? (stateVars.TMSalesDraftCreate?.length > 0 ? stateVars.TMSalesDraftCreate[0].message : null) : (this.state.TMSalesDraftCreate?.length > 0 ? this.state.TMSalesDraftCreate[0].message : null))), ReactSystemFunctions.convertToTypeByName("default", "string"), ReactSystemFunctions.convertToTypeByName("top-center", "string"), 3, ReactSystemFunctions.convertToTypeByName("", "string"), ReactSystemFunctions.convertToTypeByName("", "string"), 0);

		this.props.form?.setFieldsValue(formVars);
		
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.SatisIslemiComponent_555308_onClick5_();
                  resolve();
                });
          })

            
            return isErrorOccurred;
        }
		SatisIslemiComponent_555308_onClick5_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
if (ReactSystemFunctions.isEmpty(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "satisislemi_400617_value", "value", "", "key", "")), true)) {
            
				stateVars.Notify = await ReactSystemFunctions.notify(this, ReactSystemFunctions.translateCustomActions(this.ml,"f00670dc_191b_e045_3fd0_f4450cf0bf1f_notify",this.defaultML,"Fatura tipini seçmeden devam edemezsiniz!" ), ReactSystemFunctions.convertToTypeByName("default", "string"), ReactSystemFunctions.convertToTypeByName("bottom-right", "string"), 3, ReactSystemFunctions.convertToTypeByName("", "string"), ReactSystemFunctions.convertToTypeByName("", "string"), 0);

		this.props.form?.setFieldsValue(formVars);
		
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.SatisIslemiComponent_555308_onClick6_();
                  resolve();
                });
          })

        } else {
            
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.SatisIslemiComponent_555308_onClick6_();
                  resolve();
                });
          })
        }

            
            return isErrorOccurred;
        }
		SatisIslemiComponent_555308_onClick6_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }

				stateVars.Notify = await ReactSystemFunctions.notify(this, ReactSystemFunctions.toString(this, (stateVars.TM_CreateThirdPartyInvoiceApprovalDraft !== undefined ? (stateVars.TM_CreateThirdPartyInvoiceApprovalDraft?.length > 0 ? stateVars.TM_CreateThirdPartyInvoiceApprovalDraft[0].message : null) : (this.state.TM_CreateThirdPartyInvoiceApprovalDraft?.length > 0 ? this.state.TM_CreateThirdPartyInvoiceApprovalDraft[0].message : null))), ReactSystemFunctions.convertToTypeByName("default", "string"), ReactSystemFunctions.convertToTypeByName("bottom-right", "string"), 3, ReactSystemFunctions.convertToTypeByName("", "string"), ReactSystemFunctions.convertToTypeByName("", "string"), 0);

		this.props.form?.setFieldsValue(formVars);
		
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.SatisIslemiComponent_555308_onClick7_();
                  resolve();
                });
          })

            
            return isErrorOccurred;
        }
		SatisIslemiComponent_555308_onClick7_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
if (ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, (stateVars.TMSalesDraftCreate !== undefined ? (stateVars.TMSalesDraftCreate?.length > 0 ? stateVars.TMSalesDraftCreate[0].success : null) : (this.state.TMSalesDraftCreate?.length > 0 ? this.state.TMSalesDraftCreate[0].success : null))), "1")) {
            
				stateVars.ChangeEnabledOf = await ReactSystemFunctions.changeEnabledOf(this, ReactSystemFunctions.convertToTypeByName("isComp832389Enabled", "string"), ReactSystemFunctions.convertToTypeByName("disabled", "string"));

		this.props.form?.setFieldsValue(formVars);
		
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.SatisIslemiComponent_555308_onClick8_();
                  resolve();
                });
          })

        } else {
            
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.SatisIslemiComponent_555308_onClick8_();
                  resolve();
                });
          })
        }

            
            return isErrorOccurred;
        }
		SatisIslemiComponent_555308_onClick8_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
if (ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, (stateVars.TMSalesDraftCreate !== undefined ? (stateVars.TMSalesDraftCreate?.length > 0 ? stateVars.TMSalesDraftCreate[0].success : null) : (this.state.TMSalesDraftCreate?.length > 0 ? this.state.TMSalesDraftCreate[0].success : null))), "1")) {
            
				stateVars.ChangeEnabledOf = await ReactSystemFunctions.changeEnabledOf(this, ReactSystemFunctions.convertToTypeByName("isComp684346Enabled", "string"), ReactSystemFunctions.convertToTypeByName("enabled", "string"));

		this.props.form?.setFieldsValue(formVars);
		
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.SatisIslemiComponent_555308_onClick9_();
                  resolve();
                });
          })

        } else {
            
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.SatisIslemiComponent_555308_onClick9_();
                  resolve();
                });
          })
        }

            
            return isErrorOccurred;
        }
		SatisIslemiComponent_555308_onClick9_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }

				formVars.satisislemi_706355_value = ReactSystemFunctions.toString(this, (stateVars.TMSalesSummary !== undefined ? (stateVars.TMSalesSummary?.length > 0 ? stateVars.TMSalesSummary[0].magaza : null) : (this.state.TMSalesSummary?.length > 0 ? this.state.TMSalesSummary[0].magaza : null)));

				formVars.satisislemi_957854_value = ReactSystemFunctions.toString(this, (stateVars.TMSalesSummary !== undefined ? (stateVars.TMSalesSummary?.length > 0 ? stateVars.TMSalesSummary[0].personelAdi : null) : (this.state.TMSalesSummary?.length > 0 ? this.state.TMSalesSummary[0].personelAdi : null)));

				formVars.satisislemi_687658_value = ReactSystemFunctions.toString(this, (stateVars.TMSalesSummary !== undefined ? (stateVars.TMSalesSummary?.length > 0 ? stateVars.TMSalesSummary[0].musteriAdi : null) : (this.state.TMSalesSummary?.length > 0 ? this.state.TMSalesSummary[0].musteriAdi : null)));

				formVars.satisislemi_489530_value = ReactSystemFunctions.toString(this, (stateVars.TMSalesSummary !== undefined ? (stateVars.TMSalesSummary?.length > 0 ? stateVars.TMSalesSummary[0].urunAdedi : null) : (this.state.TMSalesSummary?.length > 0 ? this.state.TMSalesSummary[0].urunAdedi : null)));

				formVars.satisislemi_34076_value = ReactSystemFunctions.toString(this, (stateVars.TMSalesSummary !== undefined ? (stateVars.TMSalesSummary?.length > 0 ? stateVars.TMSalesSummary[0].araToplam : null) : (this.state.TMSalesSummary?.length > 0 ? this.state.TMSalesSummary[0].araToplam : null)));

				formVars.satisislemi_94614_value = ReactSystemFunctions.toString(this, (stateVars.TMSalesSummary !== undefined ? (stateVars.TMSalesSummary?.length > 0 ? stateVars.TMSalesSummary[0].iskontoTutari : null) : (this.state.TMSalesSummary?.length > 0 ? this.state.TMSalesSummary[0].iskontoTutari : null)));

				formVars.satisislemi_28476_value = ReactSystemFunctions.toString(this, (stateVars.TMSalesSummary !== undefined ? (stateVars.TMSalesSummary?.length > 0 ? stateVars.TMSalesSummary[0].genelToplam : null) : (this.state.TMSalesSummary?.length > 0 ? this.state.TMSalesSummary[0].genelToplam : null)));

				formVars.satisislemi_646001_value = ReactSystemFunctions.toString(this, (stateVars.TMSalesSummary !== undefined ? (stateVars.TMSalesSummary?.length > 0 ? stateVars.TMSalesSummary[0].tahsilEdilen : null) : (this.state.TMSalesSummary?.length > 0 ? this.state.TMSalesSummary[0].tahsilEdilen : null)));

				formVars.satisislemi_804074_value = ReactSystemFunctions.toString(this, (stateVars.TMSalesSummary !== undefined ? (stateVars.TMSalesSummary?.length > 0 ? stateVars.TMSalesSummary[0].kalanTutar : null) : (this.state.TMSalesSummary?.length > 0 ? this.state.TMSalesSummary[0].kalanTutar : null)));


		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

            
            return isErrorOccurred;
        }














    SatisIslemiComponent_10440_onClick = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
		KuikaAppManager.increaseServerRequestCount();

        let localVar = {
				usedCode_1: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "satisislemi_878977_value", "value", "", "", "")), "string"),
				wareHouseCode_1: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "satisislemi_36693_value", "value", "GetSalesPersonByStore", "kuserID", "wareHouseCode")), "string")
        }

		KuikaAppManager.showSpinner(this);
		
        if (true) {
        KuikaAppManager.showSpinner(this);
        }
        let result = await KuikaAppManager.ApiRequest(this, "SatisIslemi/SatisIslemiComponent_10440_onClick", localVar)
        if (!KMainFunctions.IsResStatus2XX(result)) return true;

			stateVars.Kuika_ItemInfoLive = result?.data.kuika_ItemInfoLive;
			this.props.form?.setFieldsValue(formVars);
			
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.SatisIslemiComponent_10440_onClick1_();
                  resolve();
                });
          })



        
        KuikaAppManager.hideSpinner(this);
        return isErrorOccurred;
    }
    SatisIslemiComponent_10440_onClick1_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
		KuikaAppManager.increaseServerRequestCount();

        let localVar = {
				ProductCode_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, (stateVars.Kuika_ItemInfoLive !== undefined ? (stateVars.Kuika_ItemInfoLive?.length > 0 ? stateVars.Kuika_ItemInfoLive[0].itemCode : null) : (this.state.Kuika_ItemInfoLive?.length > 0 ? this.state.Kuika_ItemInfoLive[0].itemCode : null))), "string"),
				SalesDraftId_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toGuid(this, ReactSystemFunctions.value(this, "satisislemi_176363_value", "value", "", "", "")), "Guid"),
				SeriNo_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, (stateVars.Kuika_ItemInfoLive !== undefined ? (stateVars.Kuika_ItemInfoLive?.length > 0 ? stateVars.Kuika_ItemInfoLive[0].itemSerialNumber : null) : (this.state.Kuika_ItemInfoLive?.length > 0 ? this.state.Kuika_ItemInfoLive[0].itemSerialNumber : null))), "string"),
				Barcode_0: ReactSystemFunctions.convertToTypeByName("", "string"),
				Price_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, (stateVars.Kuika_ItemInfoLive !== undefined ? (stateVars.Kuika_ItemInfoLive?.length > 0 ? stateVars.Kuika_ItemInfoLive[0].price : null) : (this.state.Kuika_ItemInfoLive?.length > 0 ? this.state.Kuika_ItemInfoLive[0].price : null))), "number"),
				ProductName_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, (stateVars.Kuika_ItemInfoLive !== undefined ? (stateVars.Kuika_ItemInfoLive?.length > 0 ? stateVars.Kuika_ItemInfoLive[0].itemDescription : null) : (this.state.Kuika_ItemInfoLive?.length > 0 ? this.state.Kuika_ItemInfoLive[0].itemDescription : null))), "string"),
				UseSerialNumber_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, (stateVars.Kuika_ItemInfoLive !== undefined ? (stateVars.Kuika_ItemInfoLive?.length > 0 ? stateVars.Kuika_ItemInfoLive[0].useSerialNumber : null) : (this.state.Kuika_ItemInfoLive?.length > 0 ? this.state.Kuika_ItemInfoLive[0].useSerialNumber : null))), "string")
        }

if (ReactSystemFunctions.isEmpty(ReactSystemFunctions.toString(this, (stateVars.Kuika_ItemInfoLive !== undefined ? (stateVars.Kuika_ItemInfoLive?.length > 0 ? stateVars.Kuika_ItemInfoLive[0].barcode : null) : (this.state.Kuika_ItemInfoLive?.length > 0 ? this.state.Kuika_ItemInfoLive[0].barcode : null))), ReactSystemFunctions.convertToTypeByName("True", "string"))) {
            		
        if (true) {
        KuikaAppManager.showSpinner(this);
        }
        let result = await KuikaAppManager.ApiRequest(this, "SatisIslemi/SatisIslemiComponent_10440_onClick1_", localVar)
        if (!KMainFunctions.IsResStatus2XX(result)) return true;

			stateVars.TMSalesDraftAddProduct = result?.data.tmSalesDraftAddProduct;
			this.props.form?.setFieldsValue(formVars);
			
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.SatisIslemiComponent_10440_onClick2_();
                  resolve();
                });
          })

        } else {
            
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.SatisIslemiComponent_10440_onClick2_();
                  resolve();
                });
          })
        }


        
        KuikaAppManager.hideSpinner(this);
        return isErrorOccurred;
    }
    SatisIslemiComponent_10440_onClick2_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
		KuikaAppManager.increaseServerRequestCount();

        let localVar = {
				ProductCode_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, (stateVars.Kuika_ItemInfoLive !== undefined ? (stateVars.Kuika_ItemInfoLive?.length > 0 ? stateVars.Kuika_ItemInfoLive[0].itemCode : null) : (this.state.Kuika_ItemInfoLive?.length > 0 ? this.state.Kuika_ItemInfoLive[0].itemCode : null))), "string"),
				SalesDraftId_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toGuid(this, ReactSystemFunctions.value(this, "satisislemi_176363_value", "value", "", "", "")), "Guid"),
				SeriNo_0: ReactSystemFunctions.convertToTypeByName("", "string"),
				Barcode_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, (stateVars.Kuika_ItemInfoLive !== undefined ? (stateVars.Kuika_ItemInfoLive?.length > 0 ? stateVars.Kuika_ItemInfoLive[0].barcode : null) : (this.state.Kuika_ItemInfoLive?.length > 0 ? this.state.Kuika_ItemInfoLive[0].barcode : null))), "string"),
				Price_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, (stateVars.Kuika_ItemInfoLive !== undefined ? (stateVars.Kuika_ItemInfoLive?.length > 0 ? stateVars.Kuika_ItemInfoLive[0].price : null) : (this.state.Kuika_ItemInfoLive?.length > 0 ? this.state.Kuika_ItemInfoLive[0].price : null))), "number"),
				ProductName_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, (stateVars.Kuika_ItemInfoLive !== undefined ? (stateVars.Kuika_ItemInfoLive?.length > 0 ? stateVars.Kuika_ItemInfoLive[0].itemDescription : null) : (this.state.Kuika_ItemInfoLive?.length > 0 ? this.state.Kuika_ItemInfoLive[0].itemDescription : null))), "string"),
				UseSerialNumber_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, (stateVars.Kuika_ItemInfoLive !== undefined ? (stateVars.Kuika_ItemInfoLive?.length > 0 ? stateVars.Kuika_ItemInfoLive[0].useSerialNumber : null) : (this.state.Kuika_ItemInfoLive?.length > 0 ? this.state.Kuika_ItemInfoLive[0].useSerialNumber : null))), "string")
        }

if (ReactSystemFunctions.isNotEmpty(ReactSystemFunctions.toString(this, (stateVars.Kuika_ItemInfoLive !== undefined ? (stateVars.Kuika_ItemInfoLive?.length > 0 ? stateVars.Kuika_ItemInfoLive[0].barcode : null) : (this.state.Kuika_ItemInfoLive?.length > 0 ? this.state.Kuika_ItemInfoLive[0].barcode : null))), ReactSystemFunctions.convertToTypeByName("True", "string"))) {
            		
        if (true) {
        KuikaAppManager.showSpinner(this);
        }
        let result = await KuikaAppManager.ApiRequest(this, "SatisIslemi/SatisIslemiComponent_10440_onClick2_", localVar)
        if (!KMainFunctions.IsResStatus2XX(result)) return true;

			stateVars.TMSalesDraftAddProduct = result?.data.tmSalesDraftAddProduct;
			this.props.form?.setFieldsValue(formVars);
			
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.SatisIslemiComponent_10440_onClick3_();
                  resolve();
                });
          })

        } else {
            
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.SatisIslemiComponent_10440_onClick3_();
                  resolve();
                });
          })
        }


        
        KuikaAppManager.hideSpinner(this);
        return isErrorOccurred;
    }
    SatisIslemiComponent_10440_onClick3_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
		KuikaAppManager.increaseServerRequestCount();

        let localVar = {
				SalesDraftId_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toGuid(this, ReactSystemFunctions.value(this, "satisislemi_176363_value", "value", "", "", "")), "Guid"),
				DraftId_1: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toGuid(this, ReactSystemFunctions.value(this, "satisislemi_176363_value", "value", "", "", "")), "Guid"),
				SalesDraftId_2: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toGuid(this, ReactSystemFunctions.value(this, "satisislemi_176363_value", "value", "", "", "")), "Guid")
        }

		
        if (true) {
        KuikaAppManager.showSpinner(this);
        }
        let result = await KuikaAppManager.ApiRequest(this, "SatisIslemi/SatisIslemiComponent_10440_onClick3_", localVar)
        if (!KMainFunctions.IsResStatus2XX(result)) return true;

			stateVars.TMGetSalesProductDraft = result?.data.tmGetSalesProductDraft;
			
			stateVars.isComp759176Visible = ((ReactSystemFunctions.isNotEmpty(ReactSystemFunctions.value(this, (stateVars.TMGetSalesProductDraft !== undefined ? (stateVars.TMGetSalesProductDraft?.length > 0 ? stateVars.TMGetSalesProductDraft[0].id : null) : (this.state.TMGetSalesProductDraft?.length > 0 ? this.state.TMGetSalesProductDraft[0].id : null))), ReactSystemFunctions.convertToTypeByName("True", "string"))) === true ? "visible" : "hidden")
			stateVars.TMSalesSummary = result?.data.tmSalesSummary;
			formVars.satisislemi_706355_value = ReactSystemFunctions.toString(this, (stateVars.TMSalesSummary !== undefined ? (stateVars.TMSalesSummary?.length > 0 ? stateVars.TMSalesSummary[0].magaza : null) : (this.state.TMSalesSummary?.length > 0 ? this.state.TMSalesSummary[0].magaza : null)));
			formVars.satisislemi_957854_value = ReactSystemFunctions.toString(this, (stateVars.TMSalesSummary !== undefined ? (stateVars.TMSalesSummary?.length > 0 ? stateVars.TMSalesSummary[0].personelAdi : null) : (this.state.TMSalesSummary?.length > 0 ? this.state.TMSalesSummary[0].personelAdi : null)));
			formVars.satisislemi_687658_value = ReactSystemFunctions.toString(this, (stateVars.TMSalesSummary !== undefined ? (stateVars.TMSalesSummary?.length > 0 ? stateVars.TMSalesSummary[0].musteriAdi : null) : (this.state.TMSalesSummary?.length > 0 ? this.state.TMSalesSummary[0].musteriAdi : null)));
			formVars.satisislemi_489530_value = ReactSystemFunctions.toString(this, (stateVars.TMSalesSummary !== undefined ? (stateVars.TMSalesSummary?.length > 0 ? stateVars.TMSalesSummary[0].urunAdedi : null) : (this.state.TMSalesSummary?.length > 0 ? this.state.TMSalesSummary[0].urunAdedi : null)));
			formVars.satisislemi_34076_value = ReactSystemFunctions.toString(this, (stateVars.TMSalesSummary !== undefined ? (stateVars.TMSalesSummary?.length > 0 ? stateVars.TMSalesSummary[0].araToplam : null) : (this.state.TMSalesSummary?.length > 0 ? this.state.TMSalesSummary[0].araToplam : null)));
			formVars.satisislemi_94614_value = ReactSystemFunctions.toString(this, (stateVars.TMSalesSummary !== undefined ? (stateVars.TMSalesSummary?.length > 0 ? stateVars.TMSalesSummary[0].iskontoTutari : null) : (this.state.TMSalesSummary?.length > 0 ? this.state.TMSalesSummary[0].iskontoTutari : null)));
			formVars.satisislemi_28476_value = ReactSystemFunctions.toString(this, (stateVars.TMSalesSummary !== undefined ? (stateVars.TMSalesSummary?.length > 0 ? stateVars.TMSalesSummary[0].genelToplam : null) : (this.state.TMSalesSummary?.length > 0 ? this.state.TMSalesSummary[0].genelToplam : null)));
			formVars.satisislemi_646001_value = ReactSystemFunctions.toString(this, (stateVars.TMSalesSummary !== undefined ? (stateVars.TMSalesSummary?.length > 0 ? stateVars.TMSalesSummary[0].tahsilEdilen : null) : (this.state.TMSalesSummary?.length > 0 ? this.state.TMSalesSummary[0].tahsilEdilen : null)));
			formVars.satisislemi_804074_value = ReactSystemFunctions.toString(this, (stateVars.TMSalesSummary !== undefined ? (stateVars.TMSalesSummary?.length > 0 ? stateVars.TMSalesSummary[0].kalanTutar : null) : (this.state.TMSalesSummary?.length > 0 ? this.state.TMSalesSummary[0].kalanTutar : null)));
			stateVars.TMSalesPaymentList = result?.data.tmSalesPaymentList;
			
			formVars.satisislemi_100771_value = ReactSystemFunctions.toString(this, (stateVars.TMSalesPaymentList !== undefined ? (stateVars.TMSalesPaymentList?.length > 0 ? stateVars.TMSalesPaymentList[0].collectedTotalEUR : null) : (this.state.TMSalesPaymentList?.length > 0 ? this.state.TMSalesPaymentList[0].collectedTotalEUR : null)));
			formVars.satisislemi_653586_value = ReactSystemFunctions.toString(this, (stateVars.TMSalesPaymentList !== undefined ? (stateVars.TMSalesPaymentList?.length > 0 ? stateVars.TMSalesPaymentList[0].remainingEUR : null) : (this.state.TMSalesPaymentList?.length > 0 ? this.state.TMSalesPaymentList[0].remainingEUR : null)));
			stateVars.isComp1112812883Enabled = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, (stateVars.TMSalesPaymentList !== undefined ? (stateVars.TMSalesPaymentList?.length > 0 ? stateVars.TMSalesPaymentList[0].remainingEUR : null) : (this.state.TMSalesPaymentList?.length > 0 ? this.state.TMSalesPaymentList[0].remainingEUR : null))), ReactSystemFunctions.convertToTypeByName("0", "string"))) === true ? "enabled" : "disabled")
			stateVars.isComp761489Enabled = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, (stateVars.TMSalesPaymentList !== undefined ? (stateVars.TMSalesPaymentList?.length > 0 ? stateVars.TMSalesPaymentList[0].remainingEUR : null) : (this.state.TMSalesPaymentList?.length > 0 ? this.state.TMSalesPaymentList[0].remainingEUR : null))), ReactSystemFunctions.convertToTypeByName("0", "string"))) === true ? "enabled" : "disabled")
			this.props.form?.setFieldsValue(formVars);
			
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.SatisIslemiComponent_10440_onClick4_();
                  resolve();
                });
          })



        
        KuikaAppManager.hideSpinner(this);
        return isErrorOccurred;
    }
		SatisIslemiComponent_10440_onClick4_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }

				stateVars.Notify = await ReactSystemFunctions.notify(this, ReactSystemFunctions.toString(this, (stateVars.TMSalesDraftAddProduct !== undefined ? (stateVars.TMSalesDraftAddProduct?.length > 0 ? stateVars.TMSalesDraftAddProduct[0].message : null) : (this.state.TMSalesDraftAddProduct?.length > 0 ? this.state.TMSalesDraftAddProduct[0].message : null))), ReactSystemFunctions.convertToTypeByName("default", "string"), ReactSystemFunctions.convertToTypeByName("bottom-right", "string"), 3, ReactSystemFunctions.convertToTypeByName("", "string"), ReactSystemFunctions.convertToTypeByName("", "string"), 0);
				stateVars.SetValueOf = await ReactSystemFunctions.setValueOf(this, ReactSystemFunctions.convertToTypeByName("satisislemi_878977_value", "string"), "", null, false);
				
				stateVars.dataSource_41607 = stateVars.TMGetSalesProductDraft ?? this.state.TMGetSalesProductDraft;
				
				stateVars.dataSource_466892 = stateVars.TMSalesPaymentList ?? this.state.TMSalesPaymentList;
				formVars.satisislemi_100771_value = ReactSystemFunctions.toString(this, (stateVars.TMSalesPaymentList !== undefined ? (stateVars.TMSalesPaymentList?.length > 0 ? stateVars.TMSalesPaymentList[0].collectedTotalEUR : null) : (this.state.TMSalesPaymentList?.length > 0 ? this.state.TMSalesPaymentList[0].collectedTotalEUR : null)));

				formVars.satisislemi_653586_value = ReactSystemFunctions.toString(this, (stateVars.TMSalesPaymentList !== undefined ? (stateVars.TMSalesPaymentList?.length > 0 ? stateVars.TMSalesPaymentList[0].remainingEUR : null) : (this.state.TMSalesPaymentList?.length > 0 ? this.state.TMSalesPaymentList[0].remainingEUR : null)));

				formVars.satisislemi_706355_value = ReactSystemFunctions.toString(this, (stateVars.TMSalesSummary !== undefined ? (stateVars.TMSalesSummary?.length > 0 ? stateVars.TMSalesSummary[0].magaza : null) : (this.state.TMSalesSummary?.length > 0 ? this.state.TMSalesSummary[0].magaza : null)));

				formVars.satisislemi_957854_value = ReactSystemFunctions.toString(this, (stateVars.TMSalesSummary !== undefined ? (stateVars.TMSalesSummary?.length > 0 ? stateVars.TMSalesSummary[0].personelAdi : null) : (this.state.TMSalesSummary?.length > 0 ? this.state.TMSalesSummary[0].personelAdi : null)));

				formVars.satisislemi_687658_value = ReactSystemFunctions.toString(this, (stateVars.TMSalesSummary !== undefined ? (stateVars.TMSalesSummary?.length > 0 ? stateVars.TMSalesSummary[0].musteriAdi : null) : (this.state.TMSalesSummary?.length > 0 ? this.state.TMSalesSummary[0].musteriAdi : null)));

				formVars.satisislemi_489530_value = ReactSystemFunctions.toString(this, (stateVars.TMSalesSummary !== undefined ? (stateVars.TMSalesSummary?.length > 0 ? stateVars.TMSalesSummary[0].urunAdedi : null) : (this.state.TMSalesSummary?.length > 0 ? this.state.TMSalesSummary[0].urunAdedi : null)));

				formVars.satisislemi_34076_value = ReactSystemFunctions.toString(this, (stateVars.TMSalesSummary !== undefined ? (stateVars.TMSalesSummary?.length > 0 ? stateVars.TMSalesSummary[0].araToplam : null) : (this.state.TMSalesSummary?.length > 0 ? this.state.TMSalesSummary[0].araToplam : null)));

				formVars.satisislemi_94614_value = ReactSystemFunctions.toString(this, (stateVars.TMSalesSummary !== undefined ? (stateVars.TMSalesSummary?.length > 0 ? stateVars.TMSalesSummary[0].iskontoTutari : null) : (this.state.TMSalesSummary?.length > 0 ? this.state.TMSalesSummary[0].iskontoTutari : null)));

				formVars.satisislemi_28476_value = ReactSystemFunctions.toString(this, (stateVars.TMSalesSummary !== undefined ? (stateVars.TMSalesSummary?.length > 0 ? stateVars.TMSalesSummary[0].genelToplam : null) : (this.state.TMSalesSummary?.length > 0 ? this.state.TMSalesSummary[0].genelToplam : null)));

				formVars.satisislemi_646001_value = ReactSystemFunctions.toString(this, (stateVars.TMSalesSummary !== undefined ? (stateVars.TMSalesSummary?.length > 0 ? stateVars.TMSalesSummary[0].tahsilEdilen : null) : (this.state.TMSalesSummary?.length > 0 ? this.state.TMSalesSummary[0].tahsilEdilen : null)));

				formVars.satisislemi_804074_value = ReactSystemFunctions.toString(this, (stateVars.TMSalesSummary !== undefined ? (stateVars.TMSalesSummary?.length > 0 ? stateVars.TMSalesSummary[0].kalanTutar : null) : (this.state.TMSalesSummary?.length > 0 ? this.state.TMSalesSummary[0].kalanTutar : null)));


		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

            
            return isErrorOccurred;
        }










    SatisIslemiComponent_863666_onBlur = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
		KuikaAppManager.increaseServerRequestCount();

        let localVar = {
				DraftDetailId_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, "satisislemi_41607_value", "id"), "Guid"),
				DiscountRate_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "Table_41607_discountRate", "value", "", "", "")), "number"),
				SalesDraftId_1: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toGuid(this, ReactSystemFunctions.value(this, "satisislemi_176363_value", "value", "", "", "")), "Guid"),
				DraftId_2: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toGuid(this, ReactSystemFunctions.value(this, "satisislemi_176363_value", "value", "", "", "")), "Guid"),
				SalesDraftId_3: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toGuid(this, ReactSystemFunctions.value(this, "satisislemi_176363_value", "value", "", "", "")), "Guid")
        }

		KuikaAppManager.showSpinner(this);
		
        if (true) {
        KuikaAppManager.showSpinner(this);
        }
        let result = await KuikaAppManager.ApiRequest(this, "SatisIslemi/SatisIslemiComponent_863666_onBlur", localVar)
        if (!KMainFunctions.IsResStatus2XX(result)) return true;

			stateVars.TMIskontoAddSales = result?.data.tmIskontoAddSales;
			stateVars.TMGetSalesProductDraft = result?.data.tmGetSalesProductDraft;
			
			stateVars.isComp759176Visible = ((ReactSystemFunctions.isNotEmpty(ReactSystemFunctions.value(this, (stateVars.TMGetSalesProductDraft !== undefined ? (stateVars.TMGetSalesProductDraft?.length > 0 ? stateVars.TMGetSalesProductDraft[0].id : null) : (this.state.TMGetSalesProductDraft?.length > 0 ? this.state.TMGetSalesProductDraft[0].id : null))), ReactSystemFunctions.convertToTypeByName("True", "string"))) === true ? "visible" : "hidden")
			stateVars.TMSalesSummary = result?.data.tmSalesSummary;
			formVars.satisislemi_706355_value = ReactSystemFunctions.toString(this, (stateVars.TMSalesSummary !== undefined ? (stateVars.TMSalesSummary?.length > 0 ? stateVars.TMSalesSummary[0].magaza : null) : (this.state.TMSalesSummary?.length > 0 ? this.state.TMSalesSummary[0].magaza : null)));
			formVars.satisislemi_957854_value = ReactSystemFunctions.toString(this, (stateVars.TMSalesSummary !== undefined ? (stateVars.TMSalesSummary?.length > 0 ? stateVars.TMSalesSummary[0].personelAdi : null) : (this.state.TMSalesSummary?.length > 0 ? this.state.TMSalesSummary[0].personelAdi : null)));
			formVars.satisislemi_687658_value = ReactSystemFunctions.toString(this, (stateVars.TMSalesSummary !== undefined ? (stateVars.TMSalesSummary?.length > 0 ? stateVars.TMSalesSummary[0].musteriAdi : null) : (this.state.TMSalesSummary?.length > 0 ? this.state.TMSalesSummary[0].musteriAdi : null)));
			formVars.satisislemi_489530_value = ReactSystemFunctions.toString(this, (stateVars.TMSalesSummary !== undefined ? (stateVars.TMSalesSummary?.length > 0 ? stateVars.TMSalesSummary[0].urunAdedi : null) : (this.state.TMSalesSummary?.length > 0 ? this.state.TMSalesSummary[0].urunAdedi : null)));
			formVars.satisislemi_34076_value = ReactSystemFunctions.toString(this, (stateVars.TMSalesSummary !== undefined ? (stateVars.TMSalesSummary?.length > 0 ? stateVars.TMSalesSummary[0].araToplam : null) : (this.state.TMSalesSummary?.length > 0 ? this.state.TMSalesSummary[0].araToplam : null)));
			formVars.satisislemi_94614_value = ReactSystemFunctions.toString(this, (stateVars.TMSalesSummary !== undefined ? (stateVars.TMSalesSummary?.length > 0 ? stateVars.TMSalesSummary[0].iskontoTutari : null) : (this.state.TMSalesSummary?.length > 0 ? this.state.TMSalesSummary[0].iskontoTutari : null)));
			formVars.satisislemi_28476_value = ReactSystemFunctions.toString(this, (stateVars.TMSalesSummary !== undefined ? (stateVars.TMSalesSummary?.length > 0 ? stateVars.TMSalesSummary[0].genelToplam : null) : (this.state.TMSalesSummary?.length > 0 ? this.state.TMSalesSummary[0].genelToplam : null)));
			formVars.satisislemi_646001_value = ReactSystemFunctions.toString(this, (stateVars.TMSalesSummary !== undefined ? (stateVars.TMSalesSummary?.length > 0 ? stateVars.TMSalesSummary[0].tahsilEdilen : null) : (this.state.TMSalesSummary?.length > 0 ? this.state.TMSalesSummary[0].tahsilEdilen : null)));
			formVars.satisislemi_804074_value = ReactSystemFunctions.toString(this, (stateVars.TMSalesSummary !== undefined ? (stateVars.TMSalesSummary?.length > 0 ? stateVars.TMSalesSummary[0].kalanTutar : null) : (this.state.TMSalesSummary?.length > 0 ? this.state.TMSalesSummary[0].kalanTutar : null)));
			stateVars.TMSalesPaymentList = result?.data.tmSalesPaymentList;
			
			formVars.satisislemi_100771_value = ReactSystemFunctions.toString(this, (stateVars.TMSalesPaymentList !== undefined ? (stateVars.TMSalesPaymentList?.length > 0 ? stateVars.TMSalesPaymentList[0].collectedTotalEUR : null) : (this.state.TMSalesPaymentList?.length > 0 ? this.state.TMSalesPaymentList[0].collectedTotalEUR : null)));
			formVars.satisislemi_653586_value = ReactSystemFunctions.toString(this, (stateVars.TMSalesPaymentList !== undefined ? (stateVars.TMSalesPaymentList?.length > 0 ? stateVars.TMSalesPaymentList[0].remainingEUR : null) : (this.state.TMSalesPaymentList?.length > 0 ? this.state.TMSalesPaymentList[0].remainingEUR : null)));
			stateVars.isComp1112812883Enabled = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, (stateVars.TMSalesPaymentList !== undefined ? (stateVars.TMSalesPaymentList?.length > 0 ? stateVars.TMSalesPaymentList[0].remainingEUR : null) : (this.state.TMSalesPaymentList?.length > 0 ? this.state.TMSalesPaymentList[0].remainingEUR : null))), ReactSystemFunctions.convertToTypeByName("0", "string"))) === true ? "enabled" : "disabled")
			stateVars.isComp761489Enabled = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, (stateVars.TMSalesPaymentList !== undefined ? (stateVars.TMSalesPaymentList?.length > 0 ? stateVars.TMSalesPaymentList[0].remainingEUR : null) : (this.state.TMSalesPaymentList?.length > 0 ? this.state.TMSalesPaymentList[0].remainingEUR : null))), ReactSystemFunctions.convertToTypeByName("0", "string"))) === true ? "enabled" : "disabled")
			this.props.form?.setFieldsValue(formVars);
			
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.SatisIslemiComponent_863666_onBlur1_();
                  resolve();
                });
          })



        
        KuikaAppManager.hideSpinner(this);
        return isErrorOccurred;
    }
		SatisIslemiComponent_863666_onBlur1_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }

				stateVars.Notify = await ReactSystemFunctions.notify(this, ReactSystemFunctions.toString(this, (stateVars.TMIskontoAddSales !== undefined ? (stateVars.TMIskontoAddSales?.length > 0 ? stateVars.TMIskontoAddSales[0].message : null) : (this.state.TMIskontoAddSales?.length > 0 ? this.state.TMIskontoAddSales[0].message : null))), ReactSystemFunctions.convertToTypeByName("default", "string"), ReactSystemFunctions.convertToTypeByName("bottom-right", "string"), 3, ReactSystemFunctions.convertToTypeByName("", "string"), ReactSystemFunctions.convertToTypeByName("", "string"), 0);
				
				stateVars.dataSource_41607 = stateVars.TMGetSalesProductDraft ?? this.state.TMGetSalesProductDraft;
				
				stateVars.dataSource_466892 = stateVars.TMSalesPaymentList ?? this.state.TMSalesPaymentList;
				formVars.satisislemi_100771_value = ReactSystemFunctions.toString(this, (stateVars.TMSalesPaymentList !== undefined ? (stateVars.TMSalesPaymentList?.length > 0 ? stateVars.TMSalesPaymentList[0].collectedTotalEUR : null) : (this.state.TMSalesPaymentList?.length > 0 ? this.state.TMSalesPaymentList[0].collectedTotalEUR : null)));

				formVars.satisislemi_653586_value = ReactSystemFunctions.toString(this, (stateVars.TMSalesPaymentList !== undefined ? (stateVars.TMSalesPaymentList?.length > 0 ? stateVars.TMSalesPaymentList[0].remainingEUR : null) : (this.state.TMSalesPaymentList?.length > 0 ? this.state.TMSalesPaymentList[0].remainingEUR : null)));

				formVars.satisislemi_706355_value = ReactSystemFunctions.toString(this, (stateVars.TMSalesSummary !== undefined ? (stateVars.TMSalesSummary?.length > 0 ? stateVars.TMSalesSummary[0].magaza : null) : (this.state.TMSalesSummary?.length > 0 ? this.state.TMSalesSummary[0].magaza : null)));

				formVars.satisislemi_957854_value = ReactSystemFunctions.toString(this, (stateVars.TMSalesSummary !== undefined ? (stateVars.TMSalesSummary?.length > 0 ? stateVars.TMSalesSummary[0].personelAdi : null) : (this.state.TMSalesSummary?.length > 0 ? this.state.TMSalesSummary[0].personelAdi : null)));

				formVars.satisislemi_687658_value = ReactSystemFunctions.toString(this, (stateVars.TMSalesSummary !== undefined ? (stateVars.TMSalesSummary?.length > 0 ? stateVars.TMSalesSummary[0].musteriAdi : null) : (this.state.TMSalesSummary?.length > 0 ? this.state.TMSalesSummary[0].musteriAdi : null)));

				formVars.satisislemi_489530_value = ReactSystemFunctions.toString(this, (stateVars.TMSalesSummary !== undefined ? (stateVars.TMSalesSummary?.length > 0 ? stateVars.TMSalesSummary[0].urunAdedi : null) : (this.state.TMSalesSummary?.length > 0 ? this.state.TMSalesSummary[0].urunAdedi : null)));

				formVars.satisislemi_34076_value = ReactSystemFunctions.toString(this, (stateVars.TMSalesSummary !== undefined ? (stateVars.TMSalesSummary?.length > 0 ? stateVars.TMSalesSummary[0].araToplam : null) : (this.state.TMSalesSummary?.length > 0 ? this.state.TMSalesSummary[0].araToplam : null)));

				formVars.satisislemi_94614_value = ReactSystemFunctions.toString(this, (stateVars.TMSalesSummary !== undefined ? (stateVars.TMSalesSummary?.length > 0 ? stateVars.TMSalesSummary[0].iskontoTutari : null) : (this.state.TMSalesSummary?.length > 0 ? this.state.TMSalesSummary[0].iskontoTutari : null)));

				formVars.satisislemi_28476_value = ReactSystemFunctions.toString(this, (stateVars.TMSalesSummary !== undefined ? (stateVars.TMSalesSummary?.length > 0 ? stateVars.TMSalesSummary[0].genelToplam : null) : (this.state.TMSalesSummary?.length > 0 ? this.state.TMSalesSummary[0].genelToplam : null)));

				formVars.satisislemi_646001_value = ReactSystemFunctions.toString(this, (stateVars.TMSalesSummary !== undefined ? (stateVars.TMSalesSummary?.length > 0 ? stateVars.TMSalesSummary[0].tahsilEdilen : null) : (this.state.TMSalesSummary?.length > 0 ? this.state.TMSalesSummary[0].tahsilEdilen : null)));

				formVars.satisislemi_804074_value = ReactSystemFunctions.toString(this, (stateVars.TMSalesSummary !== undefined ? (stateVars.TMSalesSummary?.length > 0 ? stateVars.TMSalesSummary[0].kalanTutar : null) : (this.state.TMSalesSummary?.length > 0 ? this.state.TMSalesSummary[0].kalanTutar : null)));


		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

            
            return isErrorOccurred;
        }




    SatisIslemiComponent_752398_onClick = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
		KuikaAppManager.increaseServerRequestCount();

        let localVar = {
				DraftDetailId_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, "satisislemi_41607_value", "id"), "Guid"),
				SalesDraftId_1: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toGuid(this, ReactSystemFunctions.value(this, "satisislemi_176363_value", "value", "", "", "")), "Guid"),
				DraftId_2: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toGuid(this, ReactSystemFunctions.value(this, "satisislemi_176363_value", "value", "", "", "")), "Guid"),
				SalesDraftId_3: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toGuid(this, ReactSystemFunctions.value(this, "satisislemi_176363_value", "value", "", "", "")), "Guid")
        }

		KuikaAppManager.showSpinner(this);
		
        if (true) {
        KuikaAppManager.showSpinner(this);
        }
        let result = await KuikaAppManager.ApiRequest(this, "SatisIslemi/SatisIslemiComponent_752398_onClick", localVar)
        if (!KMainFunctions.IsResStatus2XX(result)) return true;

			stateVars.TMSalesProductDelete = result?.data.tmSalesProductDelete;
			stateVars.TMGetSalesProductDraft = result?.data.tmGetSalesProductDraft;
			
			stateVars.isComp759176Visible = ((ReactSystemFunctions.isNotEmpty(ReactSystemFunctions.value(this, (stateVars.TMGetSalesProductDraft !== undefined ? (stateVars.TMGetSalesProductDraft?.length > 0 ? stateVars.TMGetSalesProductDraft[0].id : null) : (this.state.TMGetSalesProductDraft?.length > 0 ? this.state.TMGetSalesProductDraft[0].id : null))), ReactSystemFunctions.convertToTypeByName("True", "string"))) === true ? "visible" : "hidden")
			stateVars.TMSalesSummary = result?.data.tmSalesSummary;
			formVars.satisislemi_706355_value = ReactSystemFunctions.toString(this, (stateVars.TMSalesSummary !== undefined ? (stateVars.TMSalesSummary?.length > 0 ? stateVars.TMSalesSummary[0].magaza : null) : (this.state.TMSalesSummary?.length > 0 ? this.state.TMSalesSummary[0].magaza : null)));
			formVars.satisislemi_957854_value = ReactSystemFunctions.toString(this, (stateVars.TMSalesSummary !== undefined ? (stateVars.TMSalesSummary?.length > 0 ? stateVars.TMSalesSummary[0].personelAdi : null) : (this.state.TMSalesSummary?.length > 0 ? this.state.TMSalesSummary[0].personelAdi : null)));
			formVars.satisislemi_687658_value = ReactSystemFunctions.toString(this, (stateVars.TMSalesSummary !== undefined ? (stateVars.TMSalesSummary?.length > 0 ? stateVars.TMSalesSummary[0].musteriAdi : null) : (this.state.TMSalesSummary?.length > 0 ? this.state.TMSalesSummary[0].musteriAdi : null)));
			formVars.satisislemi_489530_value = ReactSystemFunctions.toString(this, (stateVars.TMSalesSummary !== undefined ? (stateVars.TMSalesSummary?.length > 0 ? stateVars.TMSalesSummary[0].urunAdedi : null) : (this.state.TMSalesSummary?.length > 0 ? this.state.TMSalesSummary[0].urunAdedi : null)));
			formVars.satisislemi_34076_value = ReactSystemFunctions.toString(this, (stateVars.TMSalesSummary !== undefined ? (stateVars.TMSalesSummary?.length > 0 ? stateVars.TMSalesSummary[0].araToplam : null) : (this.state.TMSalesSummary?.length > 0 ? this.state.TMSalesSummary[0].araToplam : null)));
			formVars.satisislemi_94614_value = ReactSystemFunctions.toString(this, (stateVars.TMSalesSummary !== undefined ? (stateVars.TMSalesSummary?.length > 0 ? stateVars.TMSalesSummary[0].iskontoTutari : null) : (this.state.TMSalesSummary?.length > 0 ? this.state.TMSalesSummary[0].iskontoTutari : null)));
			formVars.satisislemi_28476_value = ReactSystemFunctions.toString(this, (stateVars.TMSalesSummary !== undefined ? (stateVars.TMSalesSummary?.length > 0 ? stateVars.TMSalesSummary[0].genelToplam : null) : (this.state.TMSalesSummary?.length > 0 ? this.state.TMSalesSummary[0].genelToplam : null)));
			formVars.satisislemi_646001_value = ReactSystemFunctions.toString(this, (stateVars.TMSalesSummary !== undefined ? (stateVars.TMSalesSummary?.length > 0 ? stateVars.TMSalesSummary[0].tahsilEdilen : null) : (this.state.TMSalesSummary?.length > 0 ? this.state.TMSalesSummary[0].tahsilEdilen : null)));
			formVars.satisislemi_804074_value = ReactSystemFunctions.toString(this, (stateVars.TMSalesSummary !== undefined ? (stateVars.TMSalesSummary?.length > 0 ? stateVars.TMSalesSummary[0].kalanTutar : null) : (this.state.TMSalesSummary?.length > 0 ? this.state.TMSalesSummary[0].kalanTutar : null)));
			stateVars.TMSalesPaymentList = result?.data.tmSalesPaymentList;
			
			formVars.satisislemi_100771_value = ReactSystemFunctions.toString(this, (stateVars.TMSalesPaymentList !== undefined ? (stateVars.TMSalesPaymentList?.length > 0 ? stateVars.TMSalesPaymentList[0].collectedTotalEUR : null) : (this.state.TMSalesPaymentList?.length > 0 ? this.state.TMSalesPaymentList[0].collectedTotalEUR : null)));
			formVars.satisislemi_653586_value = ReactSystemFunctions.toString(this, (stateVars.TMSalesPaymentList !== undefined ? (stateVars.TMSalesPaymentList?.length > 0 ? stateVars.TMSalesPaymentList[0].remainingEUR : null) : (this.state.TMSalesPaymentList?.length > 0 ? this.state.TMSalesPaymentList[0].remainingEUR : null)));
			stateVars.isComp1112812883Enabled = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, (stateVars.TMSalesPaymentList !== undefined ? (stateVars.TMSalesPaymentList?.length > 0 ? stateVars.TMSalesPaymentList[0].remainingEUR : null) : (this.state.TMSalesPaymentList?.length > 0 ? this.state.TMSalesPaymentList[0].remainingEUR : null))), ReactSystemFunctions.convertToTypeByName("0", "string"))) === true ? "enabled" : "disabled")
			stateVars.isComp761489Enabled = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, (stateVars.TMSalesPaymentList !== undefined ? (stateVars.TMSalesPaymentList?.length > 0 ? stateVars.TMSalesPaymentList[0].remainingEUR : null) : (this.state.TMSalesPaymentList?.length > 0 ? this.state.TMSalesPaymentList[0].remainingEUR : null))), ReactSystemFunctions.convertToTypeByName("0", "string"))) === true ? "enabled" : "disabled")
			this.props.form?.setFieldsValue(formVars);
			
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.SatisIslemiComponent_752398_onClick1_();
                  resolve();
                });
          })



        
        KuikaAppManager.hideSpinner(this);
        return isErrorOccurred;
    }
		SatisIslemiComponent_752398_onClick1_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }

				stateVars.Notify = await ReactSystemFunctions.notify(this, ReactSystemFunctions.toString(this, (stateVars.TMSalesProductDelete !== undefined ? (stateVars.TMSalesProductDelete?.length > 0 ? stateVars.TMSalesProductDelete[0].message : null) : (this.state.TMSalesProductDelete?.length > 0 ? this.state.TMSalesProductDelete[0].message : null))), ReactSystemFunctions.convertToTypeByName("default", "string"), ReactSystemFunctions.convertToTypeByName("top-center", "string"), 3, ReactSystemFunctions.convertToTypeByName("", "string"), ReactSystemFunctions.convertToTypeByName("", "string"), 0);
				
				stateVars.dataSource_41607 = stateVars.TMGetSalesProductDraft ?? this.state.TMGetSalesProductDraft;
				
				stateVars.dataSource_466892 = stateVars.TMSalesPaymentList ?? this.state.TMSalesPaymentList;
				formVars.satisislemi_100771_value = ReactSystemFunctions.toString(this, (stateVars.TMSalesPaymentList !== undefined ? (stateVars.TMSalesPaymentList?.length > 0 ? stateVars.TMSalesPaymentList[0].collectedTotalEUR : null) : (this.state.TMSalesPaymentList?.length > 0 ? this.state.TMSalesPaymentList[0].collectedTotalEUR : null)));

				formVars.satisislemi_653586_value = ReactSystemFunctions.toString(this, (stateVars.TMSalesPaymentList !== undefined ? (stateVars.TMSalesPaymentList?.length > 0 ? stateVars.TMSalesPaymentList[0].remainingEUR : null) : (this.state.TMSalesPaymentList?.length > 0 ? this.state.TMSalesPaymentList[0].remainingEUR : null)));

				formVars.satisislemi_706355_value = ReactSystemFunctions.toString(this, (stateVars.TMSalesSummary !== undefined ? (stateVars.TMSalesSummary?.length > 0 ? stateVars.TMSalesSummary[0].magaza : null) : (this.state.TMSalesSummary?.length > 0 ? this.state.TMSalesSummary[0].magaza : null)));

				formVars.satisislemi_957854_value = ReactSystemFunctions.toString(this, (stateVars.TMSalesSummary !== undefined ? (stateVars.TMSalesSummary?.length > 0 ? stateVars.TMSalesSummary[0].personelAdi : null) : (this.state.TMSalesSummary?.length > 0 ? this.state.TMSalesSummary[0].personelAdi : null)));

				formVars.satisislemi_687658_value = ReactSystemFunctions.toString(this, (stateVars.TMSalesSummary !== undefined ? (stateVars.TMSalesSummary?.length > 0 ? stateVars.TMSalesSummary[0].musteriAdi : null) : (this.state.TMSalesSummary?.length > 0 ? this.state.TMSalesSummary[0].musteriAdi : null)));

				formVars.satisislemi_489530_value = ReactSystemFunctions.toString(this, (stateVars.TMSalesSummary !== undefined ? (stateVars.TMSalesSummary?.length > 0 ? stateVars.TMSalesSummary[0].urunAdedi : null) : (this.state.TMSalesSummary?.length > 0 ? this.state.TMSalesSummary[0].urunAdedi : null)));

				formVars.satisislemi_34076_value = ReactSystemFunctions.toString(this, (stateVars.TMSalesSummary !== undefined ? (stateVars.TMSalesSummary?.length > 0 ? stateVars.TMSalesSummary[0].araToplam : null) : (this.state.TMSalesSummary?.length > 0 ? this.state.TMSalesSummary[0].araToplam : null)));

				formVars.satisislemi_94614_value = ReactSystemFunctions.toString(this, (stateVars.TMSalesSummary !== undefined ? (stateVars.TMSalesSummary?.length > 0 ? stateVars.TMSalesSummary[0].iskontoTutari : null) : (this.state.TMSalesSummary?.length > 0 ? this.state.TMSalesSummary[0].iskontoTutari : null)));

				formVars.satisislemi_28476_value = ReactSystemFunctions.toString(this, (stateVars.TMSalesSummary !== undefined ? (stateVars.TMSalesSummary?.length > 0 ? stateVars.TMSalesSummary[0].genelToplam : null) : (this.state.TMSalesSummary?.length > 0 ? this.state.TMSalesSummary[0].genelToplam : null)));

				formVars.satisislemi_646001_value = ReactSystemFunctions.toString(this, (stateVars.TMSalesSummary !== undefined ? (stateVars.TMSalesSummary?.length > 0 ? stateVars.TMSalesSummary[0].tahsilEdilen : null) : (this.state.TMSalesSummary?.length > 0 ? this.state.TMSalesSummary[0].tahsilEdilen : null)));

				formVars.satisislemi_804074_value = ReactSystemFunctions.toString(this, (stateVars.TMSalesSummary !== undefined ? (stateVars.TMSalesSummary?.length > 0 ? stateVars.TMSalesSummary[0].kalanTutar : null) : (this.state.TMSalesSummary?.length > 0 ? this.state.TMSalesSummary[0].kalanTutar : null)));


		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

            
            return isErrorOccurred;
        }




    SatisIslemiComponent_831595_onChange = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
		KuikaAppManager.increaseServerRequestCount();

        let localVar = {
				PaymentType_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toInteger(this, ReactSystemFunctions.value(this, "satisislemi_831595_value", "value", "", "key", "")), "number"),
				OfficeCode_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "satisislemi_36693_value", "value", "GetSalesPersonByStore", "kuserID", "officeCode")), "string")
        }

		KuikaAppManager.showSpinner(this);
		
        if (true) {
        KuikaAppManager.showSpinner(this);
        }
        let result = await KuikaAppManager.ApiRequest(this, "SatisIslemi/SatisIslemiComponent_831595_onChange", localVar)
        if (!KMainFunctions.IsResStatus2XX(result)) return true;

			stateVars.TMSalesPaymentType = result?.data.tmSalesPaymentType;
			
			formVars.satisislemi_859085_options = stateVars.TMSalesPaymentType;
			this.props.form?.setFieldsValue(formVars);
			
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.SatisIslemiComponent_831595_onChange1_();
                  resolve();
                });
          })



        
        KuikaAppManager.hideSpinner(this);
        return isErrorOccurred;
    }
		SatisIslemiComponent_831595_onChange1_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }

				
				stateVars.dataSource_859085 = stateVars.TMSalesPaymentType ?? this.state.TMSalesPaymentType;
				stateVars.dataSource_859085 = stateVars.TMSalesPaymentType ?? this.state.TMSalesPaymentType;
				stateVars.isComp281463Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "satisislemi_831595_value", "value", "", "key", "")), ReactSystemFunctions.convertToTypeByName("2", "string"))) === true ? "visible" : "hidden")

		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

            
            return isErrorOccurred;
        }




    SatisIslemiComponent_358141_onClick = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
		KuikaAppManager.increaseServerRequestCount();

        let localVar = {
				PaymentType_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "satisislemi_859085_value", "value", "TMSalesPaymentType", "id", "paymentType")), "string"),
				CurrencyCode_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "satisislemi_859085_value", "value", "TMSalesPaymentType", "id", "currencyCode")), "string"),
				SalesDraftId_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toGuid(this, ReactSystemFunctions.value(this, "satisislemi_176363_value", "value", "", "", "")), "Guid"),
				CurrencyId_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "satisislemi_859085_value", "value", "TMSalesPaymentType", "id", "id")), "Guid"),
				Doviz_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "satisislemi_1364999695_value", "value", "", "key", "")), "string"),
				PaymentTypeDesc_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "satisislemi_859085_value", "value", "TMSalesPaymentType", "id", "paymentTypeDesc")), "string"),
				DraftId_1: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toGuid(this, ReactSystemFunctions.value(this, "satisislemi_176363_value", "value", "", "", "")), "Guid"),
				SalesDraftId_2: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toGuid(this, ReactSystemFunctions.value(this, "satisislemi_176363_value", "value", "", "", "")), "Guid")
        }

		KuikaAppManager.showSpinner(this);
		
        if (true) {
        KuikaAppManager.showSpinner(this);
        }
        let result = await KuikaAppManager.ApiRequest(this, "SatisIslemi/SatisIslemiComponent_358141_onClick", localVar)
        if (!KMainFunctions.IsResStatus2XX(result)) return true;

			stateVars.TMAddSalesPayment = result?.data.tmAddSalesPayment;
			stateVars.TMSalesSummary = result?.data.tmSalesSummary;
			formVars.satisislemi_706355_value = ReactSystemFunctions.toString(this, (stateVars.TMSalesSummary !== undefined ? (stateVars.TMSalesSummary?.length > 0 ? stateVars.TMSalesSummary[0].magaza : null) : (this.state.TMSalesSummary?.length > 0 ? this.state.TMSalesSummary[0].magaza : null)));
			formVars.satisislemi_957854_value = ReactSystemFunctions.toString(this, (stateVars.TMSalesSummary !== undefined ? (stateVars.TMSalesSummary?.length > 0 ? stateVars.TMSalesSummary[0].personelAdi : null) : (this.state.TMSalesSummary?.length > 0 ? this.state.TMSalesSummary[0].personelAdi : null)));
			formVars.satisislemi_687658_value = ReactSystemFunctions.toString(this, (stateVars.TMSalesSummary !== undefined ? (stateVars.TMSalesSummary?.length > 0 ? stateVars.TMSalesSummary[0].musteriAdi : null) : (this.state.TMSalesSummary?.length > 0 ? this.state.TMSalesSummary[0].musteriAdi : null)));
			formVars.satisislemi_489530_value = ReactSystemFunctions.toString(this, (stateVars.TMSalesSummary !== undefined ? (stateVars.TMSalesSummary?.length > 0 ? stateVars.TMSalesSummary[0].urunAdedi : null) : (this.state.TMSalesSummary?.length > 0 ? this.state.TMSalesSummary[0].urunAdedi : null)));
			formVars.satisislemi_34076_value = ReactSystemFunctions.toString(this, (stateVars.TMSalesSummary !== undefined ? (stateVars.TMSalesSummary?.length > 0 ? stateVars.TMSalesSummary[0].araToplam : null) : (this.state.TMSalesSummary?.length > 0 ? this.state.TMSalesSummary[0].araToplam : null)));
			formVars.satisislemi_94614_value = ReactSystemFunctions.toString(this, (stateVars.TMSalesSummary !== undefined ? (stateVars.TMSalesSummary?.length > 0 ? stateVars.TMSalesSummary[0].iskontoTutari : null) : (this.state.TMSalesSummary?.length > 0 ? this.state.TMSalesSummary[0].iskontoTutari : null)));
			formVars.satisislemi_28476_value = ReactSystemFunctions.toString(this, (stateVars.TMSalesSummary !== undefined ? (stateVars.TMSalesSummary?.length > 0 ? stateVars.TMSalesSummary[0].genelToplam : null) : (this.state.TMSalesSummary?.length > 0 ? this.state.TMSalesSummary[0].genelToplam : null)));
			formVars.satisislemi_646001_value = ReactSystemFunctions.toString(this, (stateVars.TMSalesSummary !== undefined ? (stateVars.TMSalesSummary?.length > 0 ? stateVars.TMSalesSummary[0].tahsilEdilen : null) : (this.state.TMSalesSummary?.length > 0 ? this.state.TMSalesSummary[0].tahsilEdilen : null)));
			formVars.satisislemi_804074_value = ReactSystemFunctions.toString(this, (stateVars.TMSalesSummary !== undefined ? (stateVars.TMSalesSummary?.length > 0 ? stateVars.TMSalesSummary[0].kalanTutar : null) : (this.state.TMSalesSummary?.length > 0 ? this.state.TMSalesSummary[0].kalanTutar : null)));
			stateVars.TMSalesPaymentList = result?.data.tmSalesPaymentList;
			
			formVars.satisislemi_100771_value = ReactSystemFunctions.toString(this, (stateVars.TMSalesPaymentList !== undefined ? (stateVars.TMSalesPaymentList?.length > 0 ? stateVars.TMSalesPaymentList[0].collectedTotalEUR : null) : (this.state.TMSalesPaymentList?.length > 0 ? this.state.TMSalesPaymentList[0].collectedTotalEUR : null)));
			formVars.satisislemi_653586_value = ReactSystemFunctions.toString(this, (stateVars.TMSalesPaymentList !== undefined ? (stateVars.TMSalesPaymentList?.length > 0 ? stateVars.TMSalesPaymentList[0].remainingEUR : null) : (this.state.TMSalesPaymentList?.length > 0 ? this.state.TMSalesPaymentList[0].remainingEUR : null)));
			stateVars.isComp1112812883Enabled = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, (stateVars.TMSalesPaymentList !== undefined ? (stateVars.TMSalesPaymentList?.length > 0 ? stateVars.TMSalesPaymentList[0].remainingEUR : null) : (this.state.TMSalesPaymentList?.length > 0 ? this.state.TMSalesPaymentList[0].remainingEUR : null))), ReactSystemFunctions.convertToTypeByName("0", "string"))) === true ? "enabled" : "disabled")
			stateVars.isComp761489Enabled = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, (stateVars.TMSalesPaymentList !== undefined ? (stateVars.TMSalesPaymentList?.length > 0 ? stateVars.TMSalesPaymentList[0].remainingEUR : null) : (this.state.TMSalesPaymentList?.length > 0 ? this.state.TMSalesPaymentList[0].remainingEUR : null))), ReactSystemFunctions.convertToTypeByName("0", "string"))) === true ? "enabled" : "disabled")
			this.props.form?.setFieldsValue(formVars);
			
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.SatisIslemiComponent_358141_onClick1_();
                  resolve();
                });
          })



        
        KuikaAppManager.hideSpinner(this);
        return isErrorOccurred;
    }
		SatisIslemiComponent_358141_onClick1_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }

				stateVars.SetValueOf = await ReactSystemFunctions.setValueOf(this, ReactSystemFunctions.convertToTypeByName("satisislemi_831595_value", "string"), "", null, "Key");
				stateVars.SetValueOf = await ReactSystemFunctions.setValueOf(this, ReactSystemFunctions.convertToTypeByName("satisislemi_859085_value", "string"), "", null, "Id");
				
				stateVars.dataSource_466892 = stateVars.TMSalesPaymentList ?? this.state.TMSalesPaymentList;
				formVars.satisislemi_100771_value = ReactSystemFunctions.toString(this, (stateVars.TMSalesPaymentList !== undefined ? (stateVars.TMSalesPaymentList?.length > 0 ? stateVars.TMSalesPaymentList[0].collectedTotalEUR : null) : (this.state.TMSalesPaymentList?.length > 0 ? this.state.TMSalesPaymentList[0].collectedTotalEUR : null)));

				formVars.satisislemi_653586_value = ReactSystemFunctions.toString(this, (stateVars.TMSalesPaymentList !== undefined ? (stateVars.TMSalesPaymentList?.length > 0 ? stateVars.TMSalesPaymentList[0].remainingEUR : null) : (this.state.TMSalesPaymentList?.length > 0 ? this.state.TMSalesPaymentList[0].remainingEUR : null)));

				formVars.satisislemi_706355_value = ReactSystemFunctions.toString(this, (stateVars.TMSalesSummary !== undefined ? (stateVars.TMSalesSummary?.length > 0 ? stateVars.TMSalesSummary[0].magaza : null) : (this.state.TMSalesSummary?.length > 0 ? this.state.TMSalesSummary[0].magaza : null)));

				formVars.satisislemi_957854_value = ReactSystemFunctions.toString(this, (stateVars.TMSalesSummary !== undefined ? (stateVars.TMSalesSummary?.length > 0 ? stateVars.TMSalesSummary[0].personelAdi : null) : (this.state.TMSalesSummary?.length > 0 ? this.state.TMSalesSummary[0].personelAdi : null)));

				formVars.satisislemi_687658_value = ReactSystemFunctions.toString(this, (stateVars.TMSalesSummary !== undefined ? (stateVars.TMSalesSummary?.length > 0 ? stateVars.TMSalesSummary[0].musteriAdi : null) : (this.state.TMSalesSummary?.length > 0 ? this.state.TMSalesSummary[0].musteriAdi : null)));

				formVars.satisislemi_489530_value = ReactSystemFunctions.toString(this, (stateVars.TMSalesSummary !== undefined ? (stateVars.TMSalesSummary?.length > 0 ? stateVars.TMSalesSummary[0].urunAdedi : null) : (this.state.TMSalesSummary?.length > 0 ? this.state.TMSalesSummary[0].urunAdedi : null)));

				formVars.satisislemi_34076_value = ReactSystemFunctions.toString(this, (stateVars.TMSalesSummary !== undefined ? (stateVars.TMSalesSummary?.length > 0 ? stateVars.TMSalesSummary[0].araToplam : null) : (this.state.TMSalesSummary?.length > 0 ? this.state.TMSalesSummary[0].araToplam : null)));

				formVars.satisislemi_94614_value = ReactSystemFunctions.toString(this, (stateVars.TMSalesSummary !== undefined ? (stateVars.TMSalesSummary?.length > 0 ? stateVars.TMSalesSummary[0].iskontoTutari : null) : (this.state.TMSalesSummary?.length > 0 ? this.state.TMSalesSummary[0].iskontoTutari : null)));

				formVars.satisislemi_28476_value = ReactSystemFunctions.toString(this, (stateVars.TMSalesSummary !== undefined ? (stateVars.TMSalesSummary?.length > 0 ? stateVars.TMSalesSummary[0].genelToplam : null) : (this.state.TMSalesSummary?.length > 0 ? this.state.TMSalesSummary[0].genelToplam : null)));

				formVars.satisislemi_646001_value = ReactSystemFunctions.toString(this, (stateVars.TMSalesSummary !== undefined ? (stateVars.TMSalesSummary?.length > 0 ? stateVars.TMSalesSummary[0].tahsilEdilen : null) : (this.state.TMSalesSummary?.length > 0 ? this.state.TMSalesSummary[0].tahsilEdilen : null)));

				formVars.satisislemi_804074_value = ReactSystemFunctions.toString(this, (stateVars.TMSalesSummary !== undefined ? (stateVars.TMSalesSummary?.length > 0 ? stateVars.TMSalesSummary[0].kalanTutar : null) : (this.state.TMSalesSummary?.length > 0 ? this.state.TMSalesSummary[0].kalanTutar : null)));


		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

            
            return isErrorOccurred;
        }




    SatisIslemiComponent_343657_onBlur = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
		KuikaAppManager.increaseServerRequestCount();

        let localVar = {
				PaymentId_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, "satisislemi_466892_value", "paymentId"), "Guid"),
				Amount_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "Table_466892_tutar", "value", "", "", "")), "number"),
				SalesDraftId_1: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toGuid(this, ReactSystemFunctions.value(this, "satisislemi_176363_value", "value", "", "", "")), "Guid"),
				DraftId_2: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toGuid(this, ReactSystemFunctions.value(this, "satisislemi_176363_value", "value", "", "", "")), "Guid")
        }

		KuikaAppManager.showSpinner(this);
		
        if (true) {
        KuikaAppManager.showSpinner(this);
        }
        let result = await KuikaAppManager.ApiRequest(this, "SatisIslemi/SatisIslemiComponent_343657_onBlur", localVar)
        if (!KMainFunctions.IsResStatus2XX(result)) return true;

			stateVars.TMSalesUpdatePayment = result?.data.tmSalesUpdatePayment;
			stateVars.TMSalesPaymentList = result?.data.tmSalesPaymentList;
			
			formVars.satisislemi_100771_value = ReactSystemFunctions.toString(this, (stateVars.TMSalesPaymentList !== undefined ? (stateVars.TMSalesPaymentList?.length > 0 ? stateVars.TMSalesPaymentList[0].collectedTotalEUR : null) : (this.state.TMSalesPaymentList?.length > 0 ? this.state.TMSalesPaymentList[0].collectedTotalEUR : null)));
			formVars.satisislemi_653586_value = ReactSystemFunctions.toString(this, (stateVars.TMSalesPaymentList !== undefined ? (stateVars.TMSalesPaymentList?.length > 0 ? stateVars.TMSalesPaymentList[0].remainingEUR : null) : (this.state.TMSalesPaymentList?.length > 0 ? this.state.TMSalesPaymentList[0].remainingEUR : null)));
			stateVars.isComp1112812883Enabled = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, (stateVars.TMSalesPaymentList !== undefined ? (stateVars.TMSalesPaymentList?.length > 0 ? stateVars.TMSalesPaymentList[0].remainingEUR : null) : (this.state.TMSalesPaymentList?.length > 0 ? this.state.TMSalesPaymentList[0].remainingEUR : null))), ReactSystemFunctions.convertToTypeByName("0", "string"))) === true ? "enabled" : "disabled")
			stateVars.isComp761489Enabled = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, (stateVars.TMSalesPaymentList !== undefined ? (stateVars.TMSalesPaymentList?.length > 0 ? stateVars.TMSalesPaymentList[0].remainingEUR : null) : (this.state.TMSalesPaymentList?.length > 0 ? this.state.TMSalesPaymentList[0].remainingEUR : null))), ReactSystemFunctions.convertToTypeByName("0", "string"))) === true ? "enabled" : "disabled")
			stateVars.TMSalesSummary = result?.data.tmSalesSummary;
			formVars.satisislemi_706355_value = ReactSystemFunctions.toString(this, (stateVars.TMSalesSummary !== undefined ? (stateVars.TMSalesSummary?.length > 0 ? stateVars.TMSalesSummary[0].magaza : null) : (this.state.TMSalesSummary?.length > 0 ? this.state.TMSalesSummary[0].magaza : null)));
			formVars.satisislemi_957854_value = ReactSystemFunctions.toString(this, (stateVars.TMSalesSummary !== undefined ? (stateVars.TMSalesSummary?.length > 0 ? stateVars.TMSalesSummary[0].personelAdi : null) : (this.state.TMSalesSummary?.length > 0 ? this.state.TMSalesSummary[0].personelAdi : null)));
			formVars.satisislemi_687658_value = ReactSystemFunctions.toString(this, (stateVars.TMSalesSummary !== undefined ? (stateVars.TMSalesSummary?.length > 0 ? stateVars.TMSalesSummary[0].musteriAdi : null) : (this.state.TMSalesSummary?.length > 0 ? this.state.TMSalesSummary[0].musteriAdi : null)));
			formVars.satisislemi_489530_value = ReactSystemFunctions.toString(this, (stateVars.TMSalesSummary !== undefined ? (stateVars.TMSalesSummary?.length > 0 ? stateVars.TMSalesSummary[0].urunAdedi : null) : (this.state.TMSalesSummary?.length > 0 ? this.state.TMSalesSummary[0].urunAdedi : null)));
			formVars.satisislemi_34076_value = ReactSystemFunctions.toString(this, (stateVars.TMSalesSummary !== undefined ? (stateVars.TMSalesSummary?.length > 0 ? stateVars.TMSalesSummary[0].araToplam : null) : (this.state.TMSalesSummary?.length > 0 ? this.state.TMSalesSummary[0].araToplam : null)));
			formVars.satisislemi_94614_value = ReactSystemFunctions.toString(this, (stateVars.TMSalesSummary !== undefined ? (stateVars.TMSalesSummary?.length > 0 ? stateVars.TMSalesSummary[0].iskontoTutari : null) : (this.state.TMSalesSummary?.length > 0 ? this.state.TMSalesSummary[0].iskontoTutari : null)));
			formVars.satisislemi_28476_value = ReactSystemFunctions.toString(this, (stateVars.TMSalesSummary !== undefined ? (stateVars.TMSalesSummary?.length > 0 ? stateVars.TMSalesSummary[0].genelToplam : null) : (this.state.TMSalesSummary?.length > 0 ? this.state.TMSalesSummary[0].genelToplam : null)));
			formVars.satisislemi_646001_value = ReactSystemFunctions.toString(this, (stateVars.TMSalesSummary !== undefined ? (stateVars.TMSalesSummary?.length > 0 ? stateVars.TMSalesSummary[0].tahsilEdilen : null) : (this.state.TMSalesSummary?.length > 0 ? this.state.TMSalesSummary[0].tahsilEdilen : null)));
			formVars.satisislemi_804074_value = ReactSystemFunctions.toString(this, (stateVars.TMSalesSummary !== undefined ? (stateVars.TMSalesSummary?.length > 0 ? stateVars.TMSalesSummary[0].kalanTutar : null) : (this.state.TMSalesSummary?.length > 0 ? this.state.TMSalesSummary[0].kalanTutar : null)));
			this.props.form?.setFieldsValue(formVars);
			
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.SatisIslemiComponent_343657_onBlur1_();
                  resolve();
                });
          })



        
        KuikaAppManager.hideSpinner(this);
        return isErrorOccurred;
    }
		SatisIslemiComponent_343657_onBlur1_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }

				stateVars.Notify = await ReactSystemFunctions.notify(this, ReactSystemFunctions.toString(this, (stateVars.TMSalesUpdatePayment !== undefined ? (stateVars.TMSalesUpdatePayment?.length > 0 ? stateVars.TMSalesUpdatePayment[0].message : null) : (this.state.TMSalesUpdatePayment?.length > 0 ? this.state.TMSalesUpdatePayment[0].message : null))), ReactSystemFunctions.convertToTypeByName("default", "string"), ReactSystemFunctions.convertToTypeByName("bottom-right", "string"), 3, ReactSystemFunctions.convertToTypeByName("", "string"), ReactSystemFunctions.convertToTypeByName("", "string"), 0);
				
				stateVars.dataSource_466892 = stateVars.TMSalesPaymentList ?? this.state.TMSalesPaymentList;
				formVars.satisislemi_100771_value = ReactSystemFunctions.toString(this, (stateVars.TMSalesPaymentList !== undefined ? (stateVars.TMSalesPaymentList?.length > 0 ? stateVars.TMSalesPaymentList[0].collectedTotalEUR : null) : (this.state.TMSalesPaymentList?.length > 0 ? this.state.TMSalesPaymentList[0].collectedTotalEUR : null)));

				formVars.satisislemi_653586_value = ReactSystemFunctions.toString(this, (stateVars.TMSalesPaymentList !== undefined ? (stateVars.TMSalesPaymentList?.length > 0 ? stateVars.TMSalesPaymentList[0].remainingEUR : null) : (this.state.TMSalesPaymentList?.length > 0 ? this.state.TMSalesPaymentList[0].remainingEUR : null)));

				formVars.satisislemi_706355_value = ReactSystemFunctions.toString(this, (stateVars.TMSalesSummary !== undefined ? (stateVars.TMSalesSummary?.length > 0 ? stateVars.TMSalesSummary[0].magaza : null) : (this.state.TMSalesSummary?.length > 0 ? this.state.TMSalesSummary[0].magaza : null)));

				formVars.satisislemi_957854_value = ReactSystemFunctions.toString(this, (stateVars.TMSalesSummary !== undefined ? (stateVars.TMSalesSummary?.length > 0 ? stateVars.TMSalesSummary[0].personelAdi : null) : (this.state.TMSalesSummary?.length > 0 ? this.state.TMSalesSummary[0].personelAdi : null)));

				formVars.satisislemi_687658_value = ReactSystemFunctions.toString(this, (stateVars.TMSalesSummary !== undefined ? (stateVars.TMSalesSummary?.length > 0 ? stateVars.TMSalesSummary[0].musteriAdi : null) : (this.state.TMSalesSummary?.length > 0 ? this.state.TMSalesSummary[0].musteriAdi : null)));

				formVars.satisislemi_489530_value = ReactSystemFunctions.toString(this, (stateVars.TMSalesSummary !== undefined ? (stateVars.TMSalesSummary?.length > 0 ? stateVars.TMSalesSummary[0].urunAdedi : null) : (this.state.TMSalesSummary?.length > 0 ? this.state.TMSalesSummary[0].urunAdedi : null)));

				formVars.satisislemi_34076_value = ReactSystemFunctions.toString(this, (stateVars.TMSalesSummary !== undefined ? (stateVars.TMSalesSummary?.length > 0 ? stateVars.TMSalesSummary[0].araToplam : null) : (this.state.TMSalesSummary?.length > 0 ? this.state.TMSalesSummary[0].araToplam : null)));

				formVars.satisislemi_94614_value = ReactSystemFunctions.toString(this, (stateVars.TMSalesSummary !== undefined ? (stateVars.TMSalesSummary?.length > 0 ? stateVars.TMSalesSummary[0].iskontoTutari : null) : (this.state.TMSalesSummary?.length > 0 ? this.state.TMSalesSummary[0].iskontoTutari : null)));

				formVars.satisislemi_28476_value = ReactSystemFunctions.toString(this, (stateVars.TMSalesSummary !== undefined ? (stateVars.TMSalesSummary?.length > 0 ? stateVars.TMSalesSummary[0].genelToplam : null) : (this.state.TMSalesSummary?.length > 0 ? this.state.TMSalesSummary[0].genelToplam : null)));

				formVars.satisislemi_646001_value = ReactSystemFunctions.toString(this, (stateVars.TMSalesSummary !== undefined ? (stateVars.TMSalesSummary?.length > 0 ? stateVars.TMSalesSummary[0].tahsilEdilen : null) : (this.state.TMSalesSummary?.length > 0 ? this.state.TMSalesSummary[0].tahsilEdilen : null)));

				formVars.satisislemi_804074_value = ReactSystemFunctions.toString(this, (stateVars.TMSalesSummary !== undefined ? (stateVars.TMSalesSummary?.length > 0 ? stateVars.TMSalesSummary[0].kalanTutar : null) : (this.state.TMSalesSummary?.length > 0 ? this.state.TMSalesSummary[0].kalanTutar : null)));


		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

            
            return isErrorOccurred;
        }




    SatisIslemiComponent_515400_onClick = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
		KuikaAppManager.increaseServerRequestCount();

        let localVar = {
				PaymentId_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, "satisislemi_466892_value", "paymentId"), "Guid"),
				SalesDraftId_1: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toGuid(this, ReactSystemFunctions.value(this, "satisislemi_176363_value", "value", "", "", "")), "Guid"),
				DraftId_2: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toGuid(this, ReactSystemFunctions.value(this, "satisislemi_176363_value", "value", "", "", "")), "Guid")
        }

		KuikaAppManager.showSpinner(this);
		
        if (true) {
        KuikaAppManager.showSpinner(this);
        }
        let result = await KuikaAppManager.ApiRequest(this, "SatisIslemi/SatisIslemiComponent_515400_onClick", localVar)
        if (!KMainFunctions.IsResStatus2XX(result)) return true;

			stateVars.TMSalesPaymentCompletedLine = result?.data.tmSalesPaymentCompletedLine;
			stateVars.TMSalesPaymentList = result?.data.tmSalesPaymentList;
			
			formVars.satisislemi_100771_value = ReactSystemFunctions.toString(this, (stateVars.TMSalesPaymentList !== undefined ? (stateVars.TMSalesPaymentList?.length > 0 ? stateVars.TMSalesPaymentList[0].collectedTotalEUR : null) : (this.state.TMSalesPaymentList?.length > 0 ? this.state.TMSalesPaymentList[0].collectedTotalEUR : null)));
			formVars.satisislemi_653586_value = ReactSystemFunctions.toString(this, (stateVars.TMSalesPaymentList !== undefined ? (stateVars.TMSalesPaymentList?.length > 0 ? stateVars.TMSalesPaymentList[0].remainingEUR : null) : (this.state.TMSalesPaymentList?.length > 0 ? this.state.TMSalesPaymentList[0].remainingEUR : null)));
			stateVars.isComp1112812883Enabled = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, (stateVars.TMSalesPaymentList !== undefined ? (stateVars.TMSalesPaymentList?.length > 0 ? stateVars.TMSalesPaymentList[0].remainingEUR : null) : (this.state.TMSalesPaymentList?.length > 0 ? this.state.TMSalesPaymentList[0].remainingEUR : null))), ReactSystemFunctions.convertToTypeByName("0", "string"))) === true ? "enabled" : "disabled")
			stateVars.isComp761489Enabled = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, (stateVars.TMSalesPaymentList !== undefined ? (stateVars.TMSalesPaymentList?.length > 0 ? stateVars.TMSalesPaymentList[0].remainingEUR : null) : (this.state.TMSalesPaymentList?.length > 0 ? this.state.TMSalesPaymentList[0].remainingEUR : null))), ReactSystemFunctions.convertToTypeByName("0", "string"))) === true ? "enabled" : "disabled")
			stateVars.TMSalesSummary = result?.data.tmSalesSummary;
			formVars.satisislemi_706355_value = ReactSystemFunctions.toString(this, (stateVars.TMSalesSummary !== undefined ? (stateVars.TMSalesSummary?.length > 0 ? stateVars.TMSalesSummary[0].magaza : null) : (this.state.TMSalesSummary?.length > 0 ? this.state.TMSalesSummary[0].magaza : null)));
			formVars.satisislemi_957854_value = ReactSystemFunctions.toString(this, (stateVars.TMSalesSummary !== undefined ? (stateVars.TMSalesSummary?.length > 0 ? stateVars.TMSalesSummary[0].personelAdi : null) : (this.state.TMSalesSummary?.length > 0 ? this.state.TMSalesSummary[0].personelAdi : null)));
			formVars.satisislemi_687658_value = ReactSystemFunctions.toString(this, (stateVars.TMSalesSummary !== undefined ? (stateVars.TMSalesSummary?.length > 0 ? stateVars.TMSalesSummary[0].musteriAdi : null) : (this.state.TMSalesSummary?.length > 0 ? this.state.TMSalesSummary[0].musteriAdi : null)));
			formVars.satisislemi_489530_value = ReactSystemFunctions.toString(this, (stateVars.TMSalesSummary !== undefined ? (stateVars.TMSalesSummary?.length > 0 ? stateVars.TMSalesSummary[0].urunAdedi : null) : (this.state.TMSalesSummary?.length > 0 ? this.state.TMSalesSummary[0].urunAdedi : null)));
			formVars.satisislemi_34076_value = ReactSystemFunctions.toString(this, (stateVars.TMSalesSummary !== undefined ? (stateVars.TMSalesSummary?.length > 0 ? stateVars.TMSalesSummary[0].araToplam : null) : (this.state.TMSalesSummary?.length > 0 ? this.state.TMSalesSummary[0].araToplam : null)));
			formVars.satisislemi_94614_value = ReactSystemFunctions.toString(this, (stateVars.TMSalesSummary !== undefined ? (stateVars.TMSalesSummary?.length > 0 ? stateVars.TMSalesSummary[0].iskontoTutari : null) : (this.state.TMSalesSummary?.length > 0 ? this.state.TMSalesSummary[0].iskontoTutari : null)));
			formVars.satisislemi_28476_value = ReactSystemFunctions.toString(this, (stateVars.TMSalesSummary !== undefined ? (stateVars.TMSalesSummary?.length > 0 ? stateVars.TMSalesSummary[0].genelToplam : null) : (this.state.TMSalesSummary?.length > 0 ? this.state.TMSalesSummary[0].genelToplam : null)));
			formVars.satisislemi_646001_value = ReactSystemFunctions.toString(this, (stateVars.TMSalesSummary !== undefined ? (stateVars.TMSalesSummary?.length > 0 ? stateVars.TMSalesSummary[0].tahsilEdilen : null) : (this.state.TMSalesSummary?.length > 0 ? this.state.TMSalesSummary[0].tahsilEdilen : null)));
			formVars.satisislemi_804074_value = ReactSystemFunctions.toString(this, (stateVars.TMSalesSummary !== undefined ? (stateVars.TMSalesSummary?.length > 0 ? stateVars.TMSalesSummary[0].kalanTutar : null) : (this.state.TMSalesSummary?.length > 0 ? this.state.TMSalesSummary[0].kalanTutar : null)));
			this.props.form?.setFieldsValue(formVars);
			
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.SatisIslemiComponent_515400_onClick1_();
                  resolve();
                });
          })



        
        KuikaAppManager.hideSpinner(this);
        return isErrorOccurred;
    }
		SatisIslemiComponent_515400_onClick1_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }

				stateVars.Notify = await ReactSystemFunctions.notify(this, ReactSystemFunctions.toString(this, (stateVars.TMSalesPaymentCompletedLine !== undefined ? (stateVars.TMSalesPaymentCompletedLine?.length > 0 ? stateVars.TMSalesPaymentCompletedLine[0].resultMessage : null) : (this.state.TMSalesPaymentCompletedLine?.length > 0 ? this.state.TMSalesPaymentCompletedLine[0].resultMessage : null))), ReactSystemFunctions.convertToTypeByName("default", "string"), ReactSystemFunctions.convertToTypeByName("top-center", "string"), 3, ReactSystemFunctions.convertToTypeByName("", "string"), ReactSystemFunctions.convertToTypeByName("", "string"), 0);
				
				stateVars.dataSource_466892 = stateVars.TMSalesPaymentList ?? this.state.TMSalesPaymentList;
				formVars.satisislemi_100771_value = ReactSystemFunctions.toString(this, (stateVars.TMSalesPaymentList !== undefined ? (stateVars.TMSalesPaymentList?.length > 0 ? stateVars.TMSalesPaymentList[0].collectedTotalEUR : null) : (this.state.TMSalesPaymentList?.length > 0 ? this.state.TMSalesPaymentList[0].collectedTotalEUR : null)));

				formVars.satisislemi_653586_value = ReactSystemFunctions.toString(this, (stateVars.TMSalesPaymentList !== undefined ? (stateVars.TMSalesPaymentList?.length > 0 ? stateVars.TMSalesPaymentList[0].remainingEUR : null) : (this.state.TMSalesPaymentList?.length > 0 ? this.state.TMSalesPaymentList[0].remainingEUR : null)));

				formVars.satisislemi_706355_value = ReactSystemFunctions.toString(this, (stateVars.TMSalesSummary !== undefined ? (stateVars.TMSalesSummary?.length > 0 ? stateVars.TMSalesSummary[0].magaza : null) : (this.state.TMSalesSummary?.length > 0 ? this.state.TMSalesSummary[0].magaza : null)));

				formVars.satisislemi_957854_value = ReactSystemFunctions.toString(this, (stateVars.TMSalesSummary !== undefined ? (stateVars.TMSalesSummary?.length > 0 ? stateVars.TMSalesSummary[0].personelAdi : null) : (this.state.TMSalesSummary?.length > 0 ? this.state.TMSalesSummary[0].personelAdi : null)));

				formVars.satisislemi_687658_value = ReactSystemFunctions.toString(this, (stateVars.TMSalesSummary !== undefined ? (stateVars.TMSalesSummary?.length > 0 ? stateVars.TMSalesSummary[0].musteriAdi : null) : (this.state.TMSalesSummary?.length > 0 ? this.state.TMSalesSummary[0].musteriAdi : null)));

				formVars.satisislemi_489530_value = ReactSystemFunctions.toString(this, (stateVars.TMSalesSummary !== undefined ? (stateVars.TMSalesSummary?.length > 0 ? stateVars.TMSalesSummary[0].urunAdedi : null) : (this.state.TMSalesSummary?.length > 0 ? this.state.TMSalesSummary[0].urunAdedi : null)));

				formVars.satisislemi_34076_value = ReactSystemFunctions.toString(this, (stateVars.TMSalesSummary !== undefined ? (stateVars.TMSalesSummary?.length > 0 ? stateVars.TMSalesSummary[0].araToplam : null) : (this.state.TMSalesSummary?.length > 0 ? this.state.TMSalesSummary[0].araToplam : null)));

				formVars.satisislemi_94614_value = ReactSystemFunctions.toString(this, (stateVars.TMSalesSummary !== undefined ? (stateVars.TMSalesSummary?.length > 0 ? stateVars.TMSalesSummary[0].iskontoTutari : null) : (this.state.TMSalesSummary?.length > 0 ? this.state.TMSalesSummary[0].iskontoTutari : null)));

				formVars.satisislemi_28476_value = ReactSystemFunctions.toString(this, (stateVars.TMSalesSummary !== undefined ? (stateVars.TMSalesSummary?.length > 0 ? stateVars.TMSalesSummary[0].genelToplam : null) : (this.state.TMSalesSummary?.length > 0 ? this.state.TMSalesSummary[0].genelToplam : null)));

				formVars.satisislemi_646001_value = ReactSystemFunctions.toString(this, (stateVars.TMSalesSummary !== undefined ? (stateVars.TMSalesSummary?.length > 0 ? stateVars.TMSalesSummary[0].tahsilEdilen : null) : (this.state.TMSalesSummary?.length > 0 ? this.state.TMSalesSummary[0].tahsilEdilen : null)));

				formVars.satisislemi_804074_value = ReactSystemFunctions.toString(this, (stateVars.TMSalesSummary !== undefined ? (stateVars.TMSalesSummary?.length > 0 ? stateVars.TMSalesSummary[0].kalanTutar : null) : (this.state.TMSalesSummary?.length > 0 ? this.state.TMSalesSummary[0].kalanTutar : null)));


		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

            
            return isErrorOccurred;
        }




    SatisIslemiComponent_354056_onClick = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
		KuikaAppManager.increaseServerRequestCount();

        let localVar = {
				PaymentId_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, "satisislemi_466892_value", "paymentId"), "Guid"),
				SalesDraftId_1: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toGuid(this, ReactSystemFunctions.value(this, "satisislemi_176363_value", "value", "", "", "")), "Guid"),
				DraftId_2: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toGuid(this, ReactSystemFunctions.value(this, "satisislemi_176363_value", "value", "", "", "")), "Guid")
        }

		KuikaAppManager.showSpinner(this);
		
        if (true) {
        KuikaAppManager.showSpinner(this);
        }
        let result = await KuikaAppManager.ApiRequest(this, "SatisIslemi/SatisIslemiComponent_354056_onClick", localVar)
        if (!KMainFunctions.IsResStatus2XX(result)) return true;

			stateVars.TMSalesPaymentDeleted = result?.data.tmSalesPaymentDeleted;
			stateVars.TMSalesPaymentList = result?.data.tmSalesPaymentList;
			
			formVars.satisislemi_100771_value = ReactSystemFunctions.toString(this, (stateVars.TMSalesPaymentList !== undefined ? (stateVars.TMSalesPaymentList?.length > 0 ? stateVars.TMSalesPaymentList[0].collectedTotalEUR : null) : (this.state.TMSalesPaymentList?.length > 0 ? this.state.TMSalesPaymentList[0].collectedTotalEUR : null)));
			formVars.satisislemi_653586_value = ReactSystemFunctions.toString(this, (stateVars.TMSalesPaymentList !== undefined ? (stateVars.TMSalesPaymentList?.length > 0 ? stateVars.TMSalesPaymentList[0].remainingEUR : null) : (this.state.TMSalesPaymentList?.length > 0 ? this.state.TMSalesPaymentList[0].remainingEUR : null)));
			stateVars.isComp1112812883Enabled = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, (stateVars.TMSalesPaymentList !== undefined ? (stateVars.TMSalesPaymentList?.length > 0 ? stateVars.TMSalesPaymentList[0].remainingEUR : null) : (this.state.TMSalesPaymentList?.length > 0 ? this.state.TMSalesPaymentList[0].remainingEUR : null))), ReactSystemFunctions.convertToTypeByName("0", "string"))) === true ? "enabled" : "disabled")
			stateVars.isComp761489Enabled = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, (stateVars.TMSalesPaymentList !== undefined ? (stateVars.TMSalesPaymentList?.length > 0 ? stateVars.TMSalesPaymentList[0].remainingEUR : null) : (this.state.TMSalesPaymentList?.length > 0 ? this.state.TMSalesPaymentList[0].remainingEUR : null))), ReactSystemFunctions.convertToTypeByName("0", "string"))) === true ? "enabled" : "disabled")
			stateVars.TMSalesSummary = result?.data.tmSalesSummary;
			formVars.satisislemi_706355_value = ReactSystemFunctions.toString(this, (stateVars.TMSalesSummary !== undefined ? (stateVars.TMSalesSummary?.length > 0 ? stateVars.TMSalesSummary[0].magaza : null) : (this.state.TMSalesSummary?.length > 0 ? this.state.TMSalesSummary[0].magaza : null)));
			formVars.satisislemi_957854_value = ReactSystemFunctions.toString(this, (stateVars.TMSalesSummary !== undefined ? (stateVars.TMSalesSummary?.length > 0 ? stateVars.TMSalesSummary[0].personelAdi : null) : (this.state.TMSalesSummary?.length > 0 ? this.state.TMSalesSummary[0].personelAdi : null)));
			formVars.satisislemi_687658_value = ReactSystemFunctions.toString(this, (stateVars.TMSalesSummary !== undefined ? (stateVars.TMSalesSummary?.length > 0 ? stateVars.TMSalesSummary[0].musteriAdi : null) : (this.state.TMSalesSummary?.length > 0 ? this.state.TMSalesSummary[0].musteriAdi : null)));
			formVars.satisislemi_489530_value = ReactSystemFunctions.toString(this, (stateVars.TMSalesSummary !== undefined ? (stateVars.TMSalesSummary?.length > 0 ? stateVars.TMSalesSummary[0].urunAdedi : null) : (this.state.TMSalesSummary?.length > 0 ? this.state.TMSalesSummary[0].urunAdedi : null)));
			formVars.satisislemi_34076_value = ReactSystemFunctions.toString(this, (stateVars.TMSalesSummary !== undefined ? (stateVars.TMSalesSummary?.length > 0 ? stateVars.TMSalesSummary[0].araToplam : null) : (this.state.TMSalesSummary?.length > 0 ? this.state.TMSalesSummary[0].araToplam : null)));
			formVars.satisislemi_94614_value = ReactSystemFunctions.toString(this, (stateVars.TMSalesSummary !== undefined ? (stateVars.TMSalesSummary?.length > 0 ? stateVars.TMSalesSummary[0].iskontoTutari : null) : (this.state.TMSalesSummary?.length > 0 ? this.state.TMSalesSummary[0].iskontoTutari : null)));
			formVars.satisislemi_28476_value = ReactSystemFunctions.toString(this, (stateVars.TMSalesSummary !== undefined ? (stateVars.TMSalesSummary?.length > 0 ? stateVars.TMSalesSummary[0].genelToplam : null) : (this.state.TMSalesSummary?.length > 0 ? this.state.TMSalesSummary[0].genelToplam : null)));
			formVars.satisislemi_646001_value = ReactSystemFunctions.toString(this, (stateVars.TMSalesSummary !== undefined ? (stateVars.TMSalesSummary?.length > 0 ? stateVars.TMSalesSummary[0].tahsilEdilen : null) : (this.state.TMSalesSummary?.length > 0 ? this.state.TMSalesSummary[0].tahsilEdilen : null)));
			formVars.satisislemi_804074_value = ReactSystemFunctions.toString(this, (stateVars.TMSalesSummary !== undefined ? (stateVars.TMSalesSummary?.length > 0 ? stateVars.TMSalesSummary[0].kalanTutar : null) : (this.state.TMSalesSummary?.length > 0 ? this.state.TMSalesSummary[0].kalanTutar : null)));
			this.props.form?.setFieldsValue(formVars);
			
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.SatisIslemiComponent_354056_onClick1_();
                  resolve();
                });
          })



        
        KuikaAppManager.hideSpinner(this);
        return isErrorOccurred;
    }
		SatisIslemiComponent_354056_onClick1_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }

				stateVars.Notify = await ReactSystemFunctions.notify(this, ReactSystemFunctions.toString(this, (stateVars.TMSalesPaymentDeleted !== undefined ? (stateVars.TMSalesPaymentDeleted?.length > 0 ? stateVars.TMSalesPaymentDeleted[0].message : null) : (this.state.TMSalesPaymentDeleted?.length > 0 ? this.state.TMSalesPaymentDeleted[0].message : null))), ReactSystemFunctions.convertToTypeByName("default", "string"), ReactSystemFunctions.convertToTypeByName("bottom-right", "string"), 3, ReactSystemFunctions.convertToTypeByName("", "string"), ReactSystemFunctions.convertToTypeByName("", "string"), 0);
				
				stateVars.dataSource_466892 = stateVars.TMSalesPaymentList ?? this.state.TMSalesPaymentList;
				formVars.satisislemi_100771_value = ReactSystemFunctions.toString(this, (stateVars.TMSalesPaymentList !== undefined ? (stateVars.TMSalesPaymentList?.length > 0 ? stateVars.TMSalesPaymentList[0].collectedTotalEUR : null) : (this.state.TMSalesPaymentList?.length > 0 ? this.state.TMSalesPaymentList[0].collectedTotalEUR : null)));

				formVars.satisislemi_653586_value = ReactSystemFunctions.toString(this, (stateVars.TMSalesPaymentList !== undefined ? (stateVars.TMSalesPaymentList?.length > 0 ? stateVars.TMSalesPaymentList[0].remainingEUR : null) : (this.state.TMSalesPaymentList?.length > 0 ? this.state.TMSalesPaymentList[0].remainingEUR : null)));

				formVars.satisislemi_706355_value = ReactSystemFunctions.toString(this, (stateVars.TMSalesSummary !== undefined ? (stateVars.TMSalesSummary?.length > 0 ? stateVars.TMSalesSummary[0].magaza : null) : (this.state.TMSalesSummary?.length > 0 ? this.state.TMSalesSummary[0].magaza : null)));

				formVars.satisislemi_957854_value = ReactSystemFunctions.toString(this, (stateVars.TMSalesSummary !== undefined ? (stateVars.TMSalesSummary?.length > 0 ? stateVars.TMSalesSummary[0].personelAdi : null) : (this.state.TMSalesSummary?.length > 0 ? this.state.TMSalesSummary[0].personelAdi : null)));

				formVars.satisislemi_687658_value = ReactSystemFunctions.toString(this, (stateVars.TMSalesSummary !== undefined ? (stateVars.TMSalesSummary?.length > 0 ? stateVars.TMSalesSummary[0].musteriAdi : null) : (this.state.TMSalesSummary?.length > 0 ? this.state.TMSalesSummary[0].musteriAdi : null)));

				formVars.satisislemi_489530_value = ReactSystemFunctions.toString(this, (stateVars.TMSalesSummary !== undefined ? (stateVars.TMSalesSummary?.length > 0 ? stateVars.TMSalesSummary[0].urunAdedi : null) : (this.state.TMSalesSummary?.length > 0 ? this.state.TMSalesSummary[0].urunAdedi : null)));

				formVars.satisislemi_34076_value = ReactSystemFunctions.toString(this, (stateVars.TMSalesSummary !== undefined ? (stateVars.TMSalesSummary?.length > 0 ? stateVars.TMSalesSummary[0].araToplam : null) : (this.state.TMSalesSummary?.length > 0 ? this.state.TMSalesSummary[0].araToplam : null)));

				formVars.satisislemi_94614_value = ReactSystemFunctions.toString(this, (stateVars.TMSalesSummary !== undefined ? (stateVars.TMSalesSummary?.length > 0 ? stateVars.TMSalesSummary[0].iskontoTutari : null) : (this.state.TMSalesSummary?.length > 0 ? this.state.TMSalesSummary[0].iskontoTutari : null)));

				formVars.satisislemi_28476_value = ReactSystemFunctions.toString(this, (stateVars.TMSalesSummary !== undefined ? (stateVars.TMSalesSummary?.length > 0 ? stateVars.TMSalesSummary[0].genelToplam : null) : (this.state.TMSalesSummary?.length > 0 ? this.state.TMSalesSummary[0].genelToplam : null)));

				formVars.satisislemi_646001_value = ReactSystemFunctions.toString(this, (stateVars.TMSalesSummary !== undefined ? (stateVars.TMSalesSummary?.length > 0 ? stateVars.TMSalesSummary[0].tahsilEdilen : null) : (this.state.TMSalesSummary?.length > 0 ? this.state.TMSalesSummary[0].tahsilEdilen : null)));

				formVars.satisislemi_804074_value = ReactSystemFunctions.toString(this, (stateVars.TMSalesSummary !== undefined ? (stateVars.TMSalesSummary?.length > 0 ? stateVars.TMSalesSummary[0].kalanTutar : null) : (this.state.TMSalesSummary?.length > 0 ? this.state.TMSalesSummary[0].kalanTutar : null)));


		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

            
            return isErrorOccurred;
        }




		SatisIslemiComponent_1112812883_onClick = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
if (ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, (stateVars.TMSalesPaymentList !== undefined ? (stateVars.TMSalesPaymentList?.length > 0 ? stateVars.TMSalesPaymentList[0].remainingEUR : null) : (this.state.TMSalesPaymentList?.length > 0 ? this.state.TMSalesPaymentList[0].remainingEUR : null))), "0")) {
            KuikaAppManager.showSpinner(this);

				stateVars.ChangeVisibilityOf = await ReactSystemFunctions.changeVisibilityOf(this, ReactSystemFunctions.convertToTypeByName("isComp761489Visible", "string"), ReactSystemFunctions.convertToTypeByName("visible", "string"));

		this.props.form?.setFieldsValue(formVars);
		
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.SatisIslemiComponent_1112812883_onClick1_();
                  resolve();
                });
          })

        } else {
            
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.SatisIslemiComponent_1112812883_onClick1_();
                  resolve();
                });
          })
        }

            
            return isErrorOccurred;
        }
		SatisIslemiComponent_1112812883_onClick1_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
if (ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, (stateVars.TMSalesPaymentList !== undefined ? (stateVars.TMSalesPaymentList?.length > 0 ? stateVars.TMSalesPaymentList[0].remainingEUR : null) : (this.state.TMSalesPaymentList?.length > 0 ? this.state.TMSalesPaymentList[0].remainingEUR : null))), "0")) {
            
				stateVars.Notify = await ReactSystemFunctions.notify(this, ReactSystemFunctions.translateCustomActions(this.ml,"8cedb00a_59e8_54c4_69b1_aa3d44bceb47_notify",this.defaultML,"Kalan tutar bulunmamaktadır!" ), ReactSystemFunctions.convertToTypeByName("success", "string"), ReactSystemFunctions.convertToTypeByName("bottom-right", "string"), 2, ReactSystemFunctions.convertToTypeByName("", "string"), ReactSystemFunctions.convertToTypeByName("", "string"), 0);

		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

        } else {
            KuikaAppManager.hideSpinner(this);
        }

            
            return isErrorOccurred;
        }



    SatisIslemiComponent_761489_onClick = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
		KuikaAppManager.increaseServerRequestCount();

        let localVar = {
				SalesDraftId_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toGuid(this, ReactSystemFunctions.value(this, "satisislemi_176363_value", "value", "", "", "")), "Guid"),
				CurrentUserId_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.getMyUserId(), "Guid"),
				DraftId_1: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toGuid(this, ReactSystemFunctions.value(this, "satisislemi_176363_value", "value", "", "", "")), "Guid"),
				DraftId_2: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toGuid(this, ReactSystemFunctions.value(this, "satisislemi_176363_value", "value", "", "", "")), "Guid"),
				DraftId_3: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toGuid(this, ReactSystemFunctions.value(this, "satisislemi_176363_value", "value", "", "", "")), "Guid")
        }

		KuikaAppManager.showSpinner(this);
		
        if (true) {
        KuikaAppManager.showSpinner(this);
        }
        let result = await KuikaAppManager.ApiRequest(this, "SatisIslemi/SatisIslemiComponent_761489_onClick", localVar)
        if (!KMainFunctions.IsResStatus2XX(result)) return true;

			stateVars.TM_SubmitThirdPartyInvoiceApproval = result?.data.tM_SubmitThirdPartyInvoiceApproval;
			stateVars.PostDirectSalesDraftList = result?.data.postDirectSalesDraftList;
			stateVars.PostDirectSalesDraftDetail = result?.data.postDirectSalesDraftDetail;
			stateVars.PostDirectSalesDraftPayment = result?.data.postDirectSalesDraftPayment;
			this.props.form?.setFieldsValue(formVars);
			
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.SatisIslemiComponent_761489_onClick1_();
                  resolve();
                });
          })



        
        KuikaAppManager.hideSpinner(this);
        return isErrorOccurred;
    }
    SatisIslemiComponent_761489_onClick1_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
		KuikaAppManager.increaseServerRequestCount();

        let localVar = {
				customerCode_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, (stateVars.PostDirectSalesDraftList !== undefined ? (stateVars.PostDirectSalesDraftList?.length > 0 ? stateVars.PostDirectSalesDraftList[0].customerCode : null) : (this.state.PostDirectSalesDraftList?.length > 0 ? this.state.PostDirectSalesDraftList[0].customerCode : null))), "string"),
				officeCode_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, (stateVars.PostDirectSalesDraftList !== undefined ? (stateVars.PostDirectSalesDraftList?.length > 0 ? stateVars.PostDirectSalesDraftList[0].officeCode : null) : (this.state.PostDirectSalesDraftList?.length > 0 ? this.state.PostDirectSalesDraftList[0].officeCode : null))), "string"),
				storeCode_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, (stateVars.PostDirectSalesDraftList !== undefined ? (stateVars.PostDirectSalesDraftList?.length > 0 ? stateVars.PostDirectSalesDraftList[0].storeCode : null) : (this.state.PostDirectSalesDraftList?.length > 0 ? this.state.PostDirectSalesDraftList[0].storeCode : null))), "string"),
				warehouseCode_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, (stateVars.PostDirectSalesDraftList !== undefined ? (stateVars.PostDirectSalesDraftList?.length > 0 ? stateVars.PostDirectSalesDraftList[0].wareHouseCode : null) : (this.state.PostDirectSalesDraftList?.length > 0 ? this.state.PostDirectSalesDraftList[0].wareHouseCode : null))), "string"),
				billingAddressId_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, (stateVars.PostDirectSalesDraftList !== undefined ? (stateVars.PostDirectSalesDraftList?.length > 0 ? stateVars.PostDirectSalesDraftList[0].billingAddressId : null) : (this.state.PostDirectSalesDraftList?.length > 0 ? this.state.PostDirectSalesDraftList[0].billingAddressId : null))), "string"),
				shippingAddressId_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, (stateVars.PostDirectSalesDraftList !== undefined ? (stateVars.PostDirectSalesDraftList?.length > 0 ? stateVars.PostDirectSalesDraftList[0].shippingAddressId : null) : (this.state.PostDirectSalesDraftList?.length > 0 ? this.state.PostDirectSalesDraftList[0].shippingAddressId : null))), "string"),
				exchangeRate_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, (stateVars.PostDirectSalesDraftList !== undefined ? (stateVars.PostDirectSalesDraftList?.length > 0 ? stateVars.PostDirectSalesDraftList[0].exchangeRate : null) : (this.state.PostDirectSalesDraftList?.length > 0 ? this.state.PostDirectSalesDraftList[0].exchangeRate : null))), "number"),
				lines_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, this.state.PostDirectSalesDraftDetail), "any[]"),
				lines_ItemCode_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, this.state.PostDirectSalesDraftDetail?.productCode), "string"),
				lines_ProductSerialNumber_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, this.state.PostDirectSalesDraftDetail?.seriNo), "string"),
				lines_UseSerialNumber_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, this.state.PostDirectSalesDraftDetail?.useSerialNumber), "string"),
				lines_Qty1_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, this.state.PostDirectSalesDraftDetail?.qty1), "number"),
				lines_PriceVI_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, this.state.PostDirectSalesDraftDetail?.unitPriceEUR), "number"),
				lines_LDisRate1_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, this.state.PostDirectSalesDraftDetail?.discountRate), "number"),
				lines_SalespersonCode_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, (stateVars.PostDirectSalesDraftList !== undefined ? (stateVars.PostDirectSalesDraftList?.length > 0 ? stateVars.PostDirectSalesDraftList[0].erpsalespersoncode : null) : (this.state.PostDirectSalesDraftList?.length > 0 ? this.state.PostDirectSalesDraftList[0].erpsalespersoncode : null))), "string"),
				payments_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, this.state.PostDirectSalesDraftPayment), "any[]"),
				payments_PaymentType_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toInteger(this, this.state.PostDirectSalesDraftPayment?.paymentType), "number"),
				payments_Code_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, this.state.PostDirectSalesDraftPayment?.currAccCode), "string"),
				payments_Amount_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, this.state.PostDirectSalesDraftPayment?.amount), "number"),
				payments_CurrencyCode_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, this.state.PostDirectSalesDraftPayment?.currencyCode), "string"),
				payments_ExchangeRate_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, this.state.PostDirectSalesDraftPayment?.rateUsed), "number"),
				draftId_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toGuid(this, ReactSystemFunctions.value(this, "satisislemi_176363_value", "value", "", "", "")), "Guid"),
				invoiceType_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, (stateVars.PostDirectSalesDraftList !== undefined ? (stateVars.PostDirectSalesDraftList?.length > 0 ? stateVars.PostDirectSalesDraftList[0].invoiceType : null) : (this.state.PostDirectSalesDraftList?.length > 0 ? this.state.PostDirectSalesDraftList[0].invoiceType : null))), "number"),
				description_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, (stateVars.PostDirectSalesDraftList !== undefined ? (stateVars.PostDirectSalesDraftList?.length > 0 ? stateVars.PostDirectSalesDraftList[0].taxFreeDescription : null) : (this.state.PostDirectSalesDraftList?.length > 0 ? this.state.PostDirectSalesDraftList[0].taxFreeDescription : null))), "string")
        }

if (ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, (stateVars.TM_SubmitThirdPartyInvoiceApproval !== undefined ? (stateVars.TM_SubmitThirdPartyInvoiceApproval?.length > 0 ? stateVars.TM_SubmitThirdPartyInvoiceApproval[0].canInvoice : null) : (this.state.TM_SubmitThirdPartyInvoiceApproval?.length > 0 ? this.state.TM_SubmitThirdPartyInvoiceApproval[0].canInvoice : null))), ReactSystemFunctions.convertToTypeByName("True", "string"))) {
            		
        if (true) {
        KuikaAppManager.showSpinner(this);
        }
        let result = await KuikaAppManager.ApiRequest(this, "SatisIslemi/SatisIslemiComponent_761489_onClick1_", localVar)
        if (!KMainFunctions.IsResStatus2XX(result)) return true;

			stateVars.DirectSend = result?.data.directSend;
			this.props.form?.setFieldsValue(formVars);
			
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.SatisIslemiComponent_761489_onClick2_();
                  resolve();
                });
          })

        } else {
            
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.SatisIslemiComponent_761489_onClick2_();
                  resolve();
                });
          })
        }


        
        KuikaAppManager.hideSpinner(this);
        return isErrorOccurred;
    }
		SatisIslemiComponent_761489_onClick2_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }

				stateVars.Notify = await ReactSystemFunctions.notify(this, ReactSystemFunctions.toString(this, this.state.DirectSend?.responseMessage), ReactSystemFunctions.convertToTypeByName("default", "string"), ReactSystemFunctions.convertToTypeByName("top-center", "string"), 3, ReactSystemFunctions.convertToTypeByName("", "string"), ReactSystemFunctions.convertToTypeByName("", "string"), 0);

		this.props.form?.setFieldsValue(formVars);
		
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.SatisIslemiComponent_761489_onClick3_();
                  resolve();
                });
          })

            
            return isErrorOccurred;
        }
		SatisIslemiComponent_761489_onClick3_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
if (ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, (stateVars.TM_SubmitThirdPartyInvoiceApproval !== undefined ? (stateVars.TM_SubmitThirdPartyInvoiceApproval?.length > 0 ? stateVars.TM_SubmitThirdPartyInvoiceApproval[0].canInvoice : null) : (this.state.TM_SubmitThirdPartyInvoiceApproval?.length > 0 ? this.state.TM_SubmitThirdPartyInvoiceApproval[0].canInvoice : null))), false)) {
            
				stateVars.Notify = await ReactSystemFunctions.notify(this, ReactSystemFunctions.toString(this, (stateVars.TM_SubmitThirdPartyInvoiceApproval !== undefined ? (stateVars.TM_SubmitThirdPartyInvoiceApproval?.length > 0 ? stateVars.TM_SubmitThirdPartyInvoiceApproval[0].message : null) : (this.state.TM_SubmitThirdPartyInvoiceApproval?.length > 0 ? this.state.TM_SubmitThirdPartyInvoiceApproval[0].message : null))), ReactSystemFunctions.convertToTypeByName("default", "string"), ReactSystemFunctions.convertToTypeByName("bottom-right", "string"), 3, ReactSystemFunctions.convertToTypeByName("", "string"), ReactSystemFunctions.convertToTypeByName("", "string"), 0);

		this.props.form?.setFieldsValue(formVars);
		
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.SatisIslemiComponent_761489_onClick4_();
                  resolve();
                });
          })

        } else {
            
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.SatisIslemiComponent_761489_onClick4_();
                  resolve();
                });
          })
        }

            
            return isErrorOccurred;
        }
		SatisIslemiComponent_761489_onClick4_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
if (ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, this.state.DirectSend?.isSuccess), "1")) {
            
const __currentPath = (window.location.hash ? window.location.hash.replace(/^#/, '').split('?')[0] : window.location.pathname.split('?')[0]).toLowerCase();
if (__currentPath !== "/satisbasarilipop") {
  this.context.setMasterPageInitLoaded(false);
  this.context.setMasterPageRecurringLoaded(false);
  this.context.setShouldTriggerPageInit(true);
}
					KuikaAppManager.prepareForNavigation();
						KuikaAppManager.addToPageInputVariables("SatisBasariliPop", "SaleDraftId", ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, (stateVars.PostDirectSalesDraftList !== undefined ? (stateVars.PostDirectSalesDraftList?.length > 0 ? stateVars.PostDirectSalesDraftList[0].id : null) : (this.state.PostDirectSalesDraftList?.length > 0 ? this.state.PostDirectSalesDraftList[0].id : null))), "Guid"));

				stateVars.NAVIGATE = await ReactSystemFunctions.navigate(this, this.SatisIslemiComponent_761489_onClick5_, "SatisIslemi", "SatisBasariliPop", "", "currentPage", null, null, null, null, null, null, true, false);

		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

        } else {
            
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.SatisIslemiComponent_761489_onClick5_();
                  resolve();
                });
          })
        }

            
            return isErrorOccurred;
        }
    SatisIslemiComponent_761489_onClick5_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
		KuikaAppManager.increaseServerRequestCount();

        let localVar = {
				templateId_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.convertToTypeByName("fecaea35-1baf-47cc-d88d-08df22b2240d", "string"), "string"),
				receivers_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, (stateVars.TM_SubmitThirdPartyInvoiceApproval !== undefined ? (stateVars.TM_SubmitThirdPartyInvoiceApproval?.length > 0 ? stateVars.TM_SubmitThirdPartyInvoiceApproval[0].approverEmail : null) : (this.state.TM_SubmitThirdPartyInvoiceApproval?.length > 0 ? this.state.TM_SubmitThirdPartyInvoiceApproval[0].approverEmail : null))), "string"),
				subject_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.convertToTypeByName("Onayınız Gerekiyor | 3. Kişi Adına Faturalandırma", "string"), "string"),
				sender_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.convertToTypeByName("", "string"), "string"),
				cc_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.convertToTypeByName("", "string"), "string"),
				bcc_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.convertToTypeByName("", "string"), "string"),
				language_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.convertToTypeByName("", "string"), "string"),
				ApproverFullName_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, (stateVars.TM_SubmitThirdPartyInvoiceApproval !== undefined ? (stateVars.TM_SubmitThirdPartyInvoiceApproval?.length > 0 ? stateVars.TM_SubmitThirdPartyInvoiceApproval[0].approverFullName : null) : (this.state.TM_SubmitThirdPartyInvoiceApproval?.length > 0 ? this.state.TM_SubmitThirdPartyInvoiceApproval[0].approverFullName : null))), "string"),
				RequestedByFullName_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, (stateVars.TM_SubmitThirdPartyInvoiceApproval !== undefined ? (stateVars.TM_SubmitThirdPartyInvoiceApproval?.length > 0 ? stateVars.TM_SubmitThirdPartyInvoiceApproval[0].requestedByFullName : null) : (this.state.TM_SubmitThirdPartyInvoiceApproval?.length > 0 ? this.state.TM_SubmitThirdPartyInvoiceApproval[0].requestedByFullName : null))), "string"),
				ApprovalStatusText_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, (stateVars.TM_SubmitThirdPartyInvoiceApproval !== undefined ? (stateVars.TM_SubmitThirdPartyInvoiceApproval?.length > 0 ? stateVars.TM_SubmitThirdPartyInvoiceApproval[0].approvalStatusText : null) : (this.state.TM_SubmitThirdPartyInvoiceApproval?.length > 0 ? this.state.TM_SubmitThirdPartyInvoiceApproval[0].approvalStatusText : null))), "string"),
				SalesDraftId_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, (stateVars.TM_SubmitThirdPartyInvoiceApproval !== undefined ? (stateVars.TM_SubmitThirdPartyInvoiceApproval?.length > 0 ? stateVars.TM_SubmitThirdPartyInvoiceApproval[0].salesDraftId : null) : (this.state.TM_SubmitThirdPartyInvoiceApproval?.length > 0 ? this.state.TM_SubmitThirdPartyInvoiceApproval[0].salesDraftId : null))), "string"),
				OriginalCustomerFullName_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, (stateVars.TM_SubmitThirdPartyInvoiceApproval !== undefined ? (stateVars.TM_SubmitThirdPartyInvoiceApproval?.length > 0 ? stateVars.TM_SubmitThirdPartyInvoiceApproval[0].originalCustomerFullName : null) : (this.state.TM_SubmitThirdPartyInvoiceApproval?.length > 0 ? this.state.TM_SubmitThirdPartyInvoiceApproval[0].originalCustomerFullName : null))), "string"),
				OriginalCustomerCode_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, (stateVars.TM_SubmitThirdPartyInvoiceApproval !== undefined ? (stateVars.TM_SubmitThirdPartyInvoiceApproval?.length > 0 ? stateVars.TM_SubmitThirdPartyInvoiceApproval[0].originalCustomerCode : null) : (this.state.TM_SubmitThirdPartyInvoiceApproval?.length > 0 ? this.state.TM_SubmitThirdPartyInvoiceApproval[0].originalCustomerCode : null))), "string"),
				StoreName_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, (stateVars.TM_SubmitThirdPartyInvoiceApproval !== undefined ? (stateVars.TM_SubmitThirdPartyInvoiceApproval?.length > 0 ? stateVars.TM_SubmitThirdPartyInvoiceApproval[0].storeName : null) : (this.state.TM_SubmitThirdPartyInvoiceApproval?.length > 0 ? this.state.TM_SubmitThirdPartyInvoiceApproval[0].storeName : null))), "string"),
				TotalAmountEUR_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, (stateVars.TM_SubmitThirdPartyInvoiceApproval !== undefined ? (stateVars.TM_SubmitThirdPartyInvoiceApproval?.length > 0 ? stateVars.TM_SubmitThirdPartyInvoiceApproval[0].totalAmountEUR : null) : (this.state.TM_SubmitThirdPartyInvoiceApproval?.length > 0 ? this.state.TM_SubmitThirdPartyInvoiceApproval[0].totalAmountEUR : null))), "string"),
				CurrencyCode_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, (stateVars.TM_SubmitThirdPartyInvoiceApproval !== undefined ? (stateVars.TM_SubmitThirdPartyInvoiceApproval?.length > 0 ? stateVars.TM_SubmitThirdPartyInvoiceApproval[0].currencyCode : null) : (this.state.TM_SubmitThirdPartyInvoiceApproval?.length > 0 ? this.state.TM_SubmitThirdPartyInvoiceApproval[0].currencyCode : null))), "string"),
				SourceTypeText_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, (stateVars.TM_SubmitThirdPartyInvoiceApproval !== undefined ? (stateVars.TM_SubmitThirdPartyInvoiceApproval?.length > 0 ? stateVars.TM_SubmitThirdPartyInvoiceApproval[0].sourceTypeText : null) : (this.state.TM_SubmitThirdPartyInvoiceApproval?.length > 0 ? this.state.TM_SubmitThirdPartyInvoiceApproval[0].sourceTypeText : null))), "string"),
				ThirdPartyFullName_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, (stateVars.TM_SubmitThirdPartyInvoiceApproval !== undefined ? (stateVars.TM_SubmitThirdPartyInvoiceApproval?.length > 0 ? stateVars.TM_SubmitThirdPartyInvoiceApproval[0].thirdPartyFullName : null) : (this.state.TM_SubmitThirdPartyInvoiceApproval?.length > 0 ? this.state.TM_SubmitThirdPartyInvoiceApproval[0].thirdPartyFullName : null))), "string"),
				ThirdPartyCustomerCode_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, (stateVars.TM_SubmitThirdPartyInvoiceApproval !== undefined ? (stateVars.TM_SubmitThirdPartyInvoiceApproval?.length > 0 ? stateVars.TM_SubmitThirdPartyInvoiceApproval[0].thirdPartyCustomerCode : null) : (this.state.TM_SubmitThirdPartyInvoiceApproval?.length > 0 ? this.state.TM_SubmitThirdPartyInvoiceApproval[0].thirdPartyCustomerCode : null))), "string"),
				CompanyName_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, (stateVars.TM_SubmitThirdPartyInvoiceApproval !== undefined ? (stateVars.TM_SubmitThirdPartyInvoiceApproval?.length > 0 ? stateVars.TM_SubmitThirdPartyInvoiceApproval[0].companyName : null) : (this.state.TM_SubmitThirdPartyInvoiceApproval?.length > 0 ? this.state.TM_SubmitThirdPartyInvoiceApproval[0].companyName : null))), "string"),
				TaxNumber_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, (stateVars.TM_SubmitThirdPartyInvoiceApproval !== undefined ? (stateVars.TM_SubmitThirdPartyInvoiceApproval?.length > 0 ? stateVars.TM_SubmitThirdPartyInvoiceApproval[0].taxNumber : null) : (this.state.TM_SubmitThirdPartyInvoiceApproval?.length > 0 ? this.state.TM_SubmitThirdPartyInvoiceApproval[0].taxNumber : null))), "string"),
				IdentityNumber_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, (stateVars.TM_SubmitThirdPartyInvoiceApproval !== undefined ? (stateVars.TM_SubmitThirdPartyInvoiceApproval?.length > 0 ? stateVars.TM_SubmitThirdPartyInvoiceApproval[0].identityNumber : null) : (this.state.TM_SubmitThirdPartyInvoiceApproval?.length > 0 ? this.state.TM_SubmitThirdPartyInvoiceApproval[0].identityNumber : null))), "string"),
				Address_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, (stateVars.TM_SubmitThirdPartyInvoiceApproval !== undefined ? (stateVars.TM_SubmitThirdPartyInvoiceApproval?.length > 0 ? stateVars.TM_SubmitThirdPartyInvoiceApproval[0].address : null) : (this.state.TM_SubmitThirdPartyInvoiceApproval?.length > 0 ? this.state.TM_SubmitThirdPartyInvoiceApproval[0].address : null))), "string"),
				ApprovalPageUrl_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, (stateVars.TM_SubmitThirdPartyInvoiceApproval !== undefined ? (stateVars.TM_SubmitThirdPartyInvoiceApproval?.length > 0 ? stateVars.TM_SubmitThirdPartyInvoiceApproval[0].approvalPageUrl : null) : (this.state.TM_SubmitThirdPartyInvoiceApproval?.length > 0 ? this.state.TM_SubmitThirdPartyInvoiceApproval[0].approvalPageUrl : null))), "string")
        }

if (ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, (stateVars.TM_SubmitThirdPartyInvoiceApproval !== undefined ? (stateVars.TM_SubmitThirdPartyInvoiceApproval?.length > 0 ? stateVars.TM_SubmitThirdPartyInvoiceApproval[0].shouldSendMail : null) : (this.state.TM_SubmitThirdPartyInvoiceApproval?.length > 0 ? this.state.TM_SubmitThirdPartyInvoiceApproval[0].shouldSendMail : null))), ReactSystemFunctions.convertToTypeByName("True", "string"))) {
            		
        if (true) {
        KuikaAppManager.showSpinner(this);
        }
        let result = await KuikaAppManager.ApiRequest(this, "SatisIslemi/SatisIslemiComponent_761489_onClick5_", localVar)
        if (!KMainFunctions.IsResStatus2XX(result)) return true;

			stateVars.SendMail = result?.data.sendMail;
			this.props.form?.setFieldsValue(formVars);
			
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.SatisIslemiComponent_761489_onClick6_();
                  resolve();
                });
          })

        } else {
            
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.SatisIslemiComponent_761489_onClick6_();
                  resolve();
                });
          })
        }


        
        KuikaAppManager.hideSpinner(this);
        return isErrorOccurred;
    }
		SatisIslemiComponent_761489_onClick6_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
if (ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, (stateVars.TM_SubmitThirdPartyInvoiceApproval !== undefined ? (stateVars.TM_SubmitThirdPartyInvoiceApproval?.length > 0 ? stateVars.TM_SubmitThirdPartyInvoiceApproval[0].canInvoice : null) : (this.state.TM_SubmitThirdPartyInvoiceApproval?.length > 0 ? this.state.TM_SubmitThirdPartyInvoiceApproval[0].canInvoice : null))), false)) {
            
const __currentPath = (window.location.hash ? window.location.hash.replace(/^#/, '').split('?')[0] : window.location.pathname.split('?')[0]).toLowerCase();
if (__currentPath !== "/onayagonderdigimsatislar") {
  this.context.setMasterPageInitLoaded(false);
  this.context.setMasterPageRecurringLoaded(false);
  this.context.setShouldTriggerPageInit(true);
}
					KuikaAppManager.prepareForNavigation();

				stateVars.NAVIGATE = await ReactSystemFunctions.navigate(this, undefined, "SatisIslemi", "OnayaGonderdigimSatislar", "", "currentPage", null, null, null, null, null, null, true, false);

		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

        } else {
            KuikaAppManager.hideSpinner(this);
        }

            
            return isErrorOccurred;
        }











		SatisIslemiComponent_400617_onChange = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
KuikaAppManager.showSpinner(this);

				stateVars.isComp170159Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "satisislemi_400617_value", "value", "", "key", "")), "2")) === true ? "visible" : "hidden")

		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

            
            return isErrorOccurred;
        }


		SatisIslemiComponent_971887955_onChange = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
KuikaAppManager.showSpinner(this);

				stateVars.isComp719632801Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "satisislemi_971887955_value", "value", "", "key", "")), "PERSON")) === true ? "visible" : "hidden")
				stateVars.isComp725080941Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "satisislemi_971887955_value", "value", "", "key", "")), "COMPANY")) === true ? "visible" : "hidden")
				stateVars.isComp376527Visible = ((ReactSystemFunctions.isNotEmpty(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "satisislemi_971887955_value", "value", "", "key", "")), true)) === true ? "visible" : "hidden")
				stateVars.isComp91851Visible = ((ReactSystemFunctions.isNotEmpty(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "satisislemi_971887955_value", "value", "", "key", "")), true)) === true ? "visible" : "hidden")

		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

            
            return isErrorOccurred;
        }


		SatisIslemiComponent_176363_onChange = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
KuikaAppManager.showSpinner(this);

				stateVars.isComp684346Enabled = ((ReactSystemFunctions.isNotEmpty(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "satisislemi_176363_value", "value", "", "", "")), true)) === true ? "enabled" : "disabled")

		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

            
            return isErrorOccurred;
        }




    async callCallbackFunction(diId: number, isFromMaster: boolean = false) {
        let isErrorOccurred = false;
		let pageInitCallerNavDiIDs = [394010, 1375005592, , ] as number[];
		if (isFromMaster || pageInitCallerNavDiIDs.indexOf(diId) > -1) {
			await this.SatisIslemiPageInit();
		}
		if (diId == 1890294612) {
			isErrorOccurred = await this.SatisIslemiComponent_961229_onChange2_();
            if (isErrorOccurred) return true;
		}

    }


}
