import React from "react";
import Axios, { AxiosResponse } from "axios";
import { KuikaAppManager } from "../../shared/utilty/kuika-app-manager";
import { ReactSystemFunctions } from "../../shared/utilty/react-system-functions";
import { KNavigator } from "../../shared/hoc/with-history";
import { KContext } from "../../shared/hoc/with-context";
import { useLocation } from "react-router-dom";
import { FormInstance } from "antd/es/form";
import { Guid } from "guid-typescript";
import Swal from "sweetalert2";
import { KMainFunctions } from "../../shared/utilty/main-functions";
import moment from "moment";
import { IValidationData } from "../../models/dto/validation-data";
import { IStripePayment } from "../../models/dto/stripe-payment";
import { IUserInfoDto } from "../../models/dto/user-info.dto";
import { UserService } from "../../services/user-service";
import { kuikaCoreWasmBridgeService } from "../../services/_singletons";
import _ from "lodash";
import mqtt, { MqttClient } from "mqtt";
import { IMqttResult } from "../../models/dto/mqtt.dto";
import { MasterScreen_ScreenContext } from "../masterscreen/masterscreen-context";

declare let window: any;

export interface ITudorFamilyReporting_ScreenProps {
  navigator: KNavigator;
  form: FormInstance<any>;
  googleLogin: any;
  screenInputs: any;
  context: KContext;
  initialValues: any;
  children: any;
}

export interface ITudorFamilyReporting_ScreenState {
    isSpinnerVisible: boolean;
    isPageVisible: boolean;
	isLeftMenuVisible: boolean;
    spinnerCount: number;
    selectedLanguage: string;
    isPageInitLoaded: false;
    isPageRecurringLoaded: false;
	KuikaY_RolexTudorFamilyStoreSalesMatrix: any[];
	KuikaY_RolexTudorFamilyStoreSalesMatrix_dummy: any[];
	KuikaY_GetFamilyByBrandProductGroup: any[];
	KuikaY_GetFamilyByBrandProductGroup_dummy: any[];
	NAVIGATE: any;
	NAVIGATE_dummy: any;
	ExportExcel: any;
	ExportExcel_dummy: any;
	KuikaY_RolexTudorFamilyStoreSalesMatrixMonthly: any[];
	KuikaY_RolexTudorFamilyStoreSalesMatrixMonthly_dummy: any[];
	ChangeVisibilityOf: string;
	ChangeVisibilityOf_dummy: string;
	isComp659846Visible: 'visible' | 'hidden';
	isComp167279Visible: 'visible' | 'hidden';
	isComp603305Visible: 'visible' | 'hidden';
	isComp489672Visible: 'visible' | 'hidden';

}

export class TudorFamilyReporting_ScreenBase extends React.PureComponent<ITudorFamilyReporting_ScreenProps, any> {
    static contextType = MasterScreen_ScreenContext;
    declare context: React.ContextType<typeof MasterScreen_ScreenContext>;
	tudorfamilyreporting_427582_value_kuikaAutoCompleteRef: React.RefObject<any>;
	tudorfamilyreporting_683437_value_kuikaTableRef: React.RefObject<any>;
	tudorfamilyreporting_912226_value_kuikaAutoCompleteRef: React.RefObject<any>;
	tudorfamilyreporting_879274_value_kuikaAutoCompleteRef: React.RefObject<any>;
	tudorfamilyreporting_341491_value_kuikaTableRef: React.RefObject<any>;
    ml=[{"Id":"d5a61d2b-bd60-485f-86e2-661e9ed4e486","Name":"en_US","ShortName":"English","IsDefault":true,"LanguagePhrases":[]},{"Id":"366ba152-d613-4083-b403-2c9a89f08c7f","Name":"FixedValues","ShortName":"FixedValues","LanguagePhrases":[{"Id":910240,"PropertyName":"value","Value":"Marka Bazlı Raporlama"},{"Id":869891,"PropertyName":"value","Value":"Mağaza satış performanslarını karşılaştırmalı olarak analiz edin."},{"Id":966304,"PropertyName":"label","Value":"Rolex"},{"Id":547280,"PropertyName":"label","Value":"Tudor"},{"Id":288892,"PropertyName":"label","Value":"Mont Blanc"},{"Id":343617,"PropertyName":"label","Value":"Dupont"},{"Id":126713,"PropertyName":"value","Value":"Analiz Tipi"},{"Id":248363,"PropertyName":"value","Value":"Genel Satış"},{"Id":640909,"PropertyName":"value","Value":"Family Bazlı"},{"Id":761907,"PropertyName":"value","Value":"Toplam Satış Adedi"},{"Id":526193,"PropertyName":"value","Value":"1,247"},{"Id":314567,"PropertyName":"value","Value":"+18.5%"},{"Id":604619,"PropertyName":"value","Value":"-18.5%"},{"Id":100879,"PropertyName":"value","Value":"Toplam Ciro"},{"Id":333171,"PropertyName":"value","Value":"₺42.5M"},{"Id":970632,"PropertyName":"value","Value":"+18.5%"},{"Id":240423,"PropertyName":"value","Value":"-18.5%"},{"Id":590055,"PropertyName":"value","Value":"Geçen Yıla Göre Artış"},{"Id":536252,"PropertyName":"value","Value":"+32.8%"},{"Id":223482,"PropertyName":"value","Value":"Yıllık Büyüme"},{"Id":149372,"PropertyName":"value","Value":"En Güçlü Mağaza"},{"Id":102679,"PropertyName":"value","Value":"Adana"},{"Id":53190,"PropertyName":"value","Value":"₺8.2M Ciro"},{"Id":175225,"PropertyName":"value","Value":"En Çok Satan Family"},{"Id":716024,"PropertyName":"value","Value":"Submariner"},{"Id":936850,"PropertyName":"value","Value":"342 Adet"},{"Id":383957,"PropertyName":"value","Value":"En Çok Satan Material"},{"Id":241482,"PropertyName":"value","Value":"Yellow Gold"},{"Id":792428,"PropertyName":"value","Value":"₺12.4M Ciro"},{"Id":794076,"PropertyName":"value","Value":"Tudor-"},{"Id":516932,"PropertyName":"value","Value":"-Family Bazlı Satış Özet Görünüm"},{"Id":68154,"PropertyName":"placeholder","Value":"Select Year..."},{"Id":427582,"PropertyName":"placeholder","Value":"Tümü"},{"Id":190069,"PropertyName":"title","Value":"Family"},{"Id":201695,"PropertyName":"value","Value":"[datafield:family]"},{"Id":501554,"PropertyName":"title","Value":"Adana Times"},{"Id":442729,"PropertyName":"value","Value":"[datafield:adana]"},{"Id":994821,"PropertyName":"title","Value":"Antalya Tudor Boutique Times"},{"Id":834603,"PropertyName":"value","Value":"[datafield:antalya]"},{"Id":86842,"PropertyName":"title","Value":"Gaziantep Times"},{"Id":645093,"PropertyName":"value","Value":"[datafield:gaziantep]"},{"Id":735084,"PropertyName":"title","Value":"Mersin Rolex Boutique Times"},{"Id":953597,"PropertyName":"value","Value":"[datafield:mersinmağaza]"},{"Id":960830,"PropertyName":"title","Value":"Toplam"},{"Id":119727,"PropertyName":"value","Value":"[datafield:toplam]"},{"Id":272820,"PropertyName":"value","Value":"Tudor-"},{"Id":311300,"PropertyName":"value","Value":"-"},{"Id":141955,"PropertyName":"value","Value":".Ay"},{"Id":874648,"PropertyName":"value","Value":"-Family Bazlı Yıllık Satış Görünüm"},{"Id":956516,"PropertyName":"value","Value":"Yıl"},{"Id":273334,"PropertyName":"placeholder","Value":"Select Year..."},{"Id":358277,"PropertyName":"value","Value":"Ay"},{"Id":912226,"PropertyName":"placeholder","Value":"Ay"},{"Id":124157,"PropertyName":"value","Value":"Family"},{"Id":879274,"PropertyName":"placeholder","Value":"Tümü"},{"Id":290366,"PropertyName":"label","Value":"Çalıştır"},{"Id":1085,"PropertyName":"title","Value":"Family"},{"Id":344121,"PropertyName":"value","Value":"[datafield:family]"},{"Id":583545,"PropertyName":"title","Value":"Adana Times"},{"Id":32279,"PropertyName":"value","Value":"[datafield:adana]"},{"Id":137148,"PropertyName":"title","Value":"Antalya Tudor Boutique"},{"Id":516676,"PropertyName":"value","Value":"[datafield:antalya]"},{"Id":143481,"PropertyName":"title","Value":"Gaziantep Times"},{"Id":517515,"PropertyName":"value","Value":"[datafield:gaziantep]"},{"Id":788037,"PropertyName":"title","Value":"Mersin Rolex Boutique Times"},{"Id":286254,"PropertyName":"value","Value":"[datafield:mersinmagaza]"},{"Id":70300,"PropertyName":"title","Value":"Toplam"},{"Id":984678,"PropertyName":"value","Value":"[datafield:toplam]"},{"Id":40845,"PropertyName":"value","Value":"Aylık Family Bazlı Satış Raporlarını Görmek için Raporu Çalıştırınız."}]}]
    defaultML = "en_US"
    
    screenHash = ""
    

    private _prevMasterPageInitLoaded: boolean = false;
    private _prevMasterPageRecurringLoaded: boolean = false;
    private _prevShouldTriggerPageInit: boolean = false;
    constructor(props) {
        super(props);
		this.tudorfamilyreporting_427582_value_kuikaAutoCompleteRef = React.createRef();
		this.tudorfamilyreporting_683437_value_kuikaTableRef = React.createRef();
		this.tudorfamilyreporting_912226_value_kuikaAutoCompleteRef = React.createRef();
		this.tudorfamilyreporting_879274_value_kuikaAutoCompleteRef = React.createRef();
		this.tudorfamilyreporting_341491_value_kuikaTableRef = React.createRef();

        this.state = {
            isSpinnerVisible: false,
            isPageVisible: false,
            isLeftMenuVisible: false,
            spinnerCount: 0,
            selectedLanguage: "",
            isPageInitLoaded: false,
            isPageRecurringLoaded: false,
            	        KuikaY_RolexTudorFamilyStoreSalesMatrix: [],
	        KuikaY_GetFamilyByBrandProductGroup: [],
	        NAVIGATE: "",
	        ExportExcel: "",
	        KuikaY_RolexTudorFamilyStoreSalesMatrixMonthly: [],
	        ChangeVisibilityOf: "",
	        dataSource_912226: [{"key":"1","text":"Ocak"},{"key":"2","text":"Şubat"},{"key":"3","text":"Mart"},{"key":"4","text":"Nisan"},{"key":"5","text":"Mayıs"},{"key":"6","text":"Haziran"},{"key":"7","text":"Temmuz"},{"key":"8","text":"Ağustos"},{"key":"9","text":"Eylül"},{"key":"10","text":"Ekim"},{"key":"11","text":"Kasım"},{"key":"12","text":"Aralık"}],
	        isComp659846Visible: 'hidden',
	        isComp167279Visible: 'hidden',
	        isComp603305Visible: 'hidden',
	        isComp489672Visible: 'hidden',

        }

        this.state.isPageVisible = true;
        
    }

    async componentDidMount() {

        if (KuikaAppManager.isPageInitPrevented()) {
            KuikaAppManager.calculateAndSetBodyHeight("tudorfamilyreporting", "masterscreen_screen");
            return;
        }
        this.context.registerCallbackFunction(this.callCallbackFunction.bind(this));
        
        ReactSystemFunctions.validateToken()
        this.fillFormInitValues();
        if (false){
            await this.TudorFamilyReportingPageInit();
        } else if (this.context?.isMasterPageInitLoaded) { this._prevMasterPageInitLoaded = true; await this.TudorFamilyReportingPageInit(); }
        
        
        
        KuikaAppManager.calculateAndSetBodyHeight("tudorfamilyreporting", "masterscreen_screen");

        if (ReactSystemFunctions.getIsMicroApp() === false) {
           window.parentScreen = this;
        }
    }

    componentWillUnmount() {
        
        
        

        if (ReactSystemFunctions.getIsMicroApp() === false) {
           window.parentScreen = null;
        }
    }

    

        
    componentDidUpdate= async (prevProps, prevState) => {
		KuikaAppManager.calculateAndSetBodyHeight("tudorfamilyreporting", "masterscreen_screen"    );
        if (prevProps?.location?.search !== (this.props as any)?.location?.search) {
			await this.TudorFamilyReportingPageInit();
		}

        		if (this._prevMasterPageInitLoaded !== this.context.isMasterPageInitLoaded && this.context.isMasterPageInitLoaded === true) {this._prevMasterPageInitLoaded = this.context.isMasterPageInitLoaded;await this.TudorFamilyReportingPageInit()}


        if (ReactSystemFunctions.getIsMicroApp() === false) {
            for (const key in prevState) {
                if (key.startsWith('NavVisible') && prevState[key] === true && this.state[key] === false) {
                    window.parentScreen = this;
                    break;
                }
            }
        }
	}

    fillFormInitValues() {
        this.props.form?.setFieldsValue({
});

    }

      setPageInitLoaded = (value: boolean) => {
        this.setState({ isPageInitLoaded: value });
      }

      setPageRecurringLoaded = (value: boolean) => {
        this.setState({ isPageRecurringLoaded: value });
      }

      clearFieldValidation = (changedValues: any) => {
        const fieldName = Object.keys(changedValues)[0];
        if (fieldName) {
          this.props.form?.setFields([
            {
              name: fieldName,
              errors: []
            }
          ]);
        }
      };

      

    TudorFamilyReportingPageInit = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


	if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }

        let localVar = {
			Brand_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.convertToTypeByName("Tudor", "string"), "string"),
			ProductGroup_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.convertToTypeByName("Kol saati", "string"), "string"),
			Family_0: ReactSystemFunctions.convertToTypeByName("", "string"),
			Year_0: ReactSystemFunctions.convertToTypeByName(2026, "number"),
			Marka_1: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.convertToTypeByName("Tudor", "string"), "string"),
			UrunGrubu_1: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.convertToTypeByName("Kol saati", "string"), "string")
        }

	KuikaAppManager.showSpinner(this);
	
        if (true) {
        KuikaAppManager.showSpinner(this);
        }
        let result = await KuikaAppManager.ApiRequest(this, "TudorFamilyReporting/TudorFamilyReportingPageInit", localVar)
        if (!KMainFunctions.IsResStatus2XX(result)) return true;

		stateVars.KuikaY_RolexTudorFamilyStoreSalesMatrix = result?.data.kuikaY_RolexTudorFamilyStoreSalesMatrix;
		
		stateVars.KuikaY_GetFamilyByBrandProductGroup = result?.data.kuikaY_GetFamilyByBrandProductGroup;
		
		formVars.tudorfamilyreporting_427582_options = stateVars.KuikaY_GetFamilyByBrandProductGroup;
		
		formVars.tudorfamilyreporting_879274_options = stateVars.KuikaY_GetFamilyByBrandProductGroup;
		this.props.form?.setFieldsValue(formVars);
		
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.TudorFamilyReportingPageInit1_();
                  resolve();
                });
          })



        
        KuikaAppManager.hideSpinner(this);
        return isErrorOccurred;
    }
	TudorFamilyReportingPageInit1_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


	if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }

			ReactSystemFunctions.setValueOf(this, "tudorfamilyreporting_153743_toString", ReactSystemFunctions.value(this, "tudorfamilyreporting_68154_value", "value"), "value");

			
			stateVars.dataSource_427582 = stateVars.KuikaY_GetFamilyByBrandProductGroup ?? this.state.KuikaY_GetFamilyByBrandProductGroup;
			stateVars.dataSource_427582 = stateVars.KuikaY_GetFamilyByBrandProductGroup ?? this.state.KuikaY_GetFamilyByBrandProductGroup;
			
			stateVars.dataSource_683437 = stateVars.KuikaY_RolexTudorFamilyStoreSalesMatrix ?? this.state.KuikaY_RolexTudorFamilyStoreSalesMatrix;
			ReactSystemFunctions.setValueOf(this, "tudorfamilyreporting_511795_toString", ReactSystemFunctions.value(this, "tudorfamilyreporting_273334_value", "value"), "value");

			ReactSystemFunctions.setValueOf(this, "tudorfamilyreporting_201811_value", ReactSystemFunctions.value(this, "tudorfamilyreporting_912226_value", "value"), "value");

			
			stateVars.dataSource_879274 = stateVars.KuikaY_GetFamilyByBrandProductGroup ?? this.state.KuikaY_GetFamilyByBrandProductGroup;
			stateVars.dataSource_879274 = stateVars.KuikaY_GetFamilyByBrandProductGroup ?? this.state.KuikaY_GetFamilyByBrandProductGroup;
			stateVars.isComp489672Visible = ((ReactSystemFunctions.isEmpty(ReactSystemFunctions.value(this, (stateVars.KuikaY_RolexTudorFamilyStoreSalesMatrixMonthly !== undefined ? (stateVars.KuikaY_RolexTudorFamilyStoreSalesMatrixMonthly?.length > 0 ? stateVars.KuikaY_RolexTudorFamilyStoreSalesMatrixMonthly[0].toplam : null) : (this.state.KuikaY_RolexTudorFamilyStoreSalesMatrixMonthly?.length > 0 ? this.state.KuikaY_RolexTudorFamilyStoreSalesMatrixMonthly[0].toplam : null))), ReactSystemFunctions.convertToTypeByName("True", "string"))) === true ? "visible" : "hidden")

	this.props.form?.setFieldsValue(formVars);
	this.setState(stateVars);
	KuikaAppManager.hideSpinner(this);

            this.setPageInitLoaded(true);
            return isErrorOccurred;
        }




		TudorFamilyReportingComponent_966304_onClick = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
KuikaAppManager.showSpinner(this);

const __currentPath = (window.location.hash ? window.location.hash.replace(/^#/, '').split('?')[0] : window.location.pathname.split('?')[0]).toLowerCase();
if (__currentPath !== "/rolexbasedreporting") {
  this.context.setMasterPageInitLoaded(false);
  this.context.setMasterPageRecurringLoaded(false);
  this.context.setShouldTriggerPageInit(true);
}
					KuikaAppManager.prepareForNavigation();

				stateVars.NAVIGATE = await ReactSystemFunctions.navigate(this, undefined, "TudorFamilyReporting", "RolexBasedReporting", "", "currentPage", null, null, null, null, null, null, true, false);

		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

            
            return isErrorOccurred;
        }


		TudorFamilyReportingComponent_288892_onClick = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
KuikaAppManager.showSpinner(this);

const __currentPath = (window.location.hash ? window.location.hash.replace(/^#/, '').split('?')[0] : window.location.pathname.split('?')[0]).toLowerCase();
if (__currentPath !== "/montblancbasedreporting") {
  this.context.setMasterPageInitLoaded(false);
  this.context.setMasterPageRecurringLoaded(false);
  this.context.setShouldTriggerPageInit(true);
}
					KuikaAppManager.prepareForNavigation();

				stateVars.NAVIGATE = await ReactSystemFunctions.navigate(this, undefined, "TudorFamilyReporting", "MontBlancBasedReporting", "", "currentPage", null, null, null, null, null, null, true, false);

		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

            
            return isErrorOccurred;
        }


		TudorFamilyReportingComponent_343617_onClick = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
KuikaAppManager.showSpinner(this);

const __currentPath = (window.location.hash ? window.location.hash.replace(/^#/, '').split('?')[0] : window.location.pathname.split('?')[0]).toLowerCase();
if (__currentPath !== "/dupontbasedreporting") {
  this.context.setMasterPageInitLoaded(false);
  this.context.setMasterPageRecurringLoaded(false);
  this.context.setShouldTriggerPageInit(true);
}
					KuikaAppManager.prepareForNavigation();

				stateVars.NAVIGATE = await ReactSystemFunctions.navigate(this, undefined, "TudorFamilyReporting", "DupontBasedReporting", "", "currentPage", null, null, null, null, null, null, true, false);

		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

            
            return isErrorOccurred;
        }


		TudorFamilyReportingComponent_377465_onClick = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
KuikaAppManager.showSpinner(this);

const __currentPath = (window.location.hash ? window.location.hash.replace(/^#/, '').split('?')[0] : window.location.pathname.split('?')[0]).toLowerCase();
if (__currentPath !== "/tudorbasedreporting") {
  this.context.setMasterPageInitLoaded(false);
  this.context.setMasterPageRecurringLoaded(false);
  this.context.setShouldTriggerPageInit(true);
}
					KuikaAppManager.prepareForNavigation();

				stateVars.NAVIGATE = await ReactSystemFunctions.navigate(this, undefined, "TudorFamilyReporting", "TudorBasedReporting", "", "currentPage", null, null, null, null, null, null, true, false);

		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

            
            return isErrorOccurred;
        }


		TudorFamilyReportingComponent_68154_onChange = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
KuikaAppManager.showSpinner(this);

				ReactSystemFunctions.setValueOf(this, "tudorfamilyreporting_153743_toString", ReactSystemFunctions.value(this, "tudorfamilyreporting_68154_value", "value"), "value");


		this.props.form?.setFieldsValue(formVars);
		
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.TudorFamilyReportingComponent_68154_onChange1_();
                  resolve();
                });
          })

            
            return isErrorOccurred;
        }
    TudorFamilyReportingComponent_68154_onChange1_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
		KuikaAppManager.increaseServerRequestCount();

        let localVar = {
				Brand_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.convertToTypeByName("Tudor", "string"), "string"),
				ProductGroup_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.convertToTypeByName("Kol saati", "string"), "string"),
				Family_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "tudorfamilyreporting_427582_value", "value", "KuikaY_GetFamilyByBrandProductGroup", "familyCode", "code")), "string"),
				Year_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "tudorfamilyreporting_68154_value", "value", "", "", "")), "number")
        }

		
        if (true) {
        KuikaAppManager.showSpinner(this);
        }
        let result = await KuikaAppManager.ApiRequest(this, "TudorFamilyReporting/TudorFamilyReportingComponent_68154_onChange1_", localVar)
        if (!KMainFunctions.IsResStatus2XX(result)) return true;

			stateVars.KuikaY_RolexTudorFamilyStoreSalesMatrix = result?.data.kuikaY_RolexTudorFamilyStoreSalesMatrix;
			
			this.props.form?.setFieldsValue(formVars);
			
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.TudorFamilyReportingComponent_68154_onChange2_();
                  resolve();
                });
          })



        
        KuikaAppManager.hideSpinner(this);
        return isErrorOccurred;
    }
		TudorFamilyReportingComponent_68154_onChange2_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }

				
				stateVars.dataSource_683437 = stateVars.KuikaY_RolexTudorFamilyStoreSalesMatrix ?? this.state.KuikaY_RolexTudorFamilyStoreSalesMatrix;

		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

            
            return isErrorOccurred;
        }





    TudorFamilyReportingComponent_427582_onChange = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
		KuikaAppManager.increaseServerRequestCount();

        let localVar = {
				Brand_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.convertToTypeByName("Tudor", "string"), "string"),
				ProductGroup_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.convertToTypeByName("Kol saati", "string"), "string"),
				Family_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "tudorfamilyreporting_427582_value", "value", "KuikaY_GetFamilyByBrandProductGroup", "familyCode", "code")), "string"),
				Year_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "tudorfamilyreporting_68154_value", "value", "", "", "")), "number")
        }

		KuikaAppManager.showSpinner(this);
		
        if (true) {
        KuikaAppManager.showSpinner(this);
        }
        let result = await KuikaAppManager.ApiRequest(this, "TudorFamilyReporting/TudorFamilyReportingComponent_427582_onChange", localVar)
        if (!KMainFunctions.IsResStatus2XX(result)) return true;

			stateVars.KuikaY_RolexTudorFamilyStoreSalesMatrix = result?.data.kuikaY_RolexTudorFamilyStoreSalesMatrix;
			
			this.props.form?.setFieldsValue(formVars);
			
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.TudorFamilyReportingComponent_427582_onChange1_();
                  resolve();
                });
          })



        
        KuikaAppManager.hideSpinner(this);
        return isErrorOccurred;
    }
		TudorFamilyReportingComponent_427582_onChange1_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }

				
				stateVars.dataSource_683437 = stateVars.KuikaY_RolexTudorFamilyStoreSalesMatrix ?? this.state.KuikaY_RolexTudorFamilyStoreSalesMatrix;

		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

            
            return isErrorOccurred;
        }




    TudorFamilyReportingComponent_947403_onClick = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
		KuikaAppManager.increaseServerRequestCount();

        let localVar = {
				value_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, this.state.KuikaY_RolexTudorFamilyStoreSalesMatrix), "any"),
				header_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.convertToTypeByName("Tudor Family Bazlı Yıllık Satış Raporu", "string"), "string"),
				footer_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "tudorfamilyreporting_68154_value", "value", "", "", "")), "string"),
				columns_0: ReactSystemFunctions.convertToTypeByName("", "string")
        }

		KuikaAppManager.showSpinner(this);
		
        if (true) {
        KuikaAppManager.showSpinner(this);
        }
        let result = await KuikaAppManager.ApiRequest(this, "TudorFamilyReporting/TudorFamilyReportingComponent_947403_onClick", localVar)
        if (!KMainFunctions.IsResStatus2XX(result)) return true;

			stateVars.ExportExcel = result?.data.exportExcel;
			ReactSystemFunctions.downloadFile(result?.data?.exportExcel);
			this.props.form?.setFieldsValue(formVars);
			this.setState(stateVars);
			KuikaAppManager.hideSpinner(this);



        this.setPageInitLoaded(true);
        KuikaAppManager.hideSpinner(this);
        return isErrorOccurred;
    }



    TudorFamilyReportingComponent_722182_onClick = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
		KuikaAppManager.increaseServerRequestCount();

        let localVar = {
				value_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, this.state.KuikaY_RolexTudorFamilyStoreSalesMatrixMonthly), "any"),
				header_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.convertToTypeByName("Tudor Family Bazlı Yıllık-Aylık Satış Raporu", "string"), "string"),
				footer_0: ReactSystemFunctions.convertToTypeByName("", "string"),
				columns_0: ReactSystemFunctions.convertToTypeByName("", "string")
        }

		KuikaAppManager.showSpinner(this);
		
        if (true) {
        KuikaAppManager.showSpinner(this);
        }
        let result = await KuikaAppManager.ApiRequest(this, "TudorFamilyReporting/TudorFamilyReportingComponent_722182_onClick", localVar)
        if (!KMainFunctions.IsResStatus2XX(result)) return true;

			stateVars.ExportExcel = result?.data.exportExcel;
			ReactSystemFunctions.downloadFile(result?.data?.exportExcel);
			this.props.form?.setFieldsValue(formVars);
			this.setState(stateVars);
			KuikaAppManager.hideSpinner(this);



        this.setPageInitLoaded(true);
        KuikaAppManager.hideSpinner(this);
        return isErrorOccurred;
    }



    TudorFamilyReportingComponent_290366_onClick = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
		KuikaAppManager.increaseServerRequestCount();

        let localVar = {
				Brand_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.convertToTypeByName("Tudor", "string"), "string"),
				ProductGroup_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.convertToTypeByName("Kol saati", "string"), "string"),
				Family_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "tudorfamilyreporting_879274_value", "value", "KuikaY_GetFamilyByBrandProductGroup", "familyCode", "code")), "string"),
				Year_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "tudorfamilyreporting_273334_value", "value", "", "", "")), "number"),
				Month_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toInteger(this, ReactSystemFunctions.value(this, "tudorfamilyreporting_912226_value", "value", "", "key", "")), "number")
        }

		KuikaAppManager.showSpinner(this);
		
        if (true) {
        KuikaAppManager.showSpinner(this);
        }
        let result = await KuikaAppManager.ApiRequest(this, "TudorFamilyReporting/TudorFamilyReportingComponent_290366_onClick", localVar)
        if (!KMainFunctions.IsResStatus2XX(result)) return true;

			stateVars.KuikaY_RolexTudorFamilyStoreSalesMatrixMonthly = result?.data.kuikaY_RolexTudorFamilyStoreSalesMatrixMonthly;
			
			stateVars.isComp489672Visible = ((ReactSystemFunctions.isEmpty(ReactSystemFunctions.value(this, (stateVars.KuikaY_RolexTudorFamilyStoreSalesMatrixMonthly !== undefined ? (stateVars.KuikaY_RolexTudorFamilyStoreSalesMatrixMonthly?.length > 0 ? stateVars.KuikaY_RolexTudorFamilyStoreSalesMatrixMonthly[0].toplam : null) : (this.state.KuikaY_RolexTudorFamilyStoreSalesMatrixMonthly?.length > 0 ? this.state.KuikaY_RolexTudorFamilyStoreSalesMatrixMonthly[0].toplam : null))), ReactSystemFunctions.convertToTypeByName("True", "string"))) === true ? "visible" : "hidden")
			this.props.form?.setFieldsValue(formVars);
			
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.TudorFamilyReportingComponent_290366_onClick1_();
                  resolve();
                });
          })



        
        KuikaAppManager.hideSpinner(this);
        return isErrorOccurred;
    }
		TudorFamilyReportingComponent_290366_onClick1_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }

				stateVars.ChangeVisibilityOf = await ReactSystemFunctions.changeVisibilityOf(this, ReactSystemFunctions.convertToTypeByName("isComp659846Visible", "string"), ReactSystemFunctions.convertToTypeByName("visible", "string"));
				
				stateVars.dataSource_341491 = stateVars.KuikaY_RolexTudorFamilyStoreSalesMatrixMonthly ?? this.state.KuikaY_RolexTudorFamilyStoreSalesMatrixMonthly;

		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

            
            return isErrorOccurred;
        }




		TudorFamilyReportingComponent_273334_onChange = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
KuikaAppManager.showSpinner(this);

				ReactSystemFunctions.setValueOf(this, "tudorfamilyreporting_511795_toString", ReactSystemFunctions.value(this, "tudorfamilyreporting_273334_value", "value"), "value");


		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

            
            return isErrorOccurred;
        }


		TudorFamilyReportingComponent_912226_onChange = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
KuikaAppManager.showSpinner(this);

				ReactSystemFunctions.setValueOf(this, "tudorfamilyreporting_201811_value", ReactSystemFunctions.value(this, "tudorfamilyreporting_912226_value", "value"), "value");


		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

            
            return isErrorOccurred;
        }




    async callCallbackFunction(diId: number, isFromMaster: boolean = false) {
        let isErrorOccurred = false;
		let pageInitCallerNavDiIDs = [, , , ] as number[];
		if (isFromMaster || pageInitCallerNavDiIDs.indexOf(diId) > -1) {
			await this.TudorFamilyReportingPageInit();
		}

    }


}
