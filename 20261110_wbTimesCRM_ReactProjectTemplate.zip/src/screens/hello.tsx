import * as React from "react";

export interface ILoginState {}

export interface ILoginProps {}

export class Login extends React.PureComponent<ILoginProps, ILoginState> {
  constructor(props) {
    super(props);
    this.state = {};
  }

  render() {
    return <></>;
  }
}
