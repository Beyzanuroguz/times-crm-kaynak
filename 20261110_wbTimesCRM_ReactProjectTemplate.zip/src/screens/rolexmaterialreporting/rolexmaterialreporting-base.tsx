import React from "react";
import Axios, { AxiosResponse } from "axios";
import { KuikaAppManager } from "../../shared/utilty/kuika-app-manager";
import { ReactSystemFunctions } from "../../shared/utilty/react-system-functions";
import { KNavigator } from "../../shared/hoc/with-history";
import { KContext } from "../../shared/hoc/with-context";
import { useLocation } from "react-router-dom";
import { FormInstance } from "antd/es/form";
import { Guid } from "guid-typescript";
import Swal from "sweetalert2";
import { KMainFunctions } from "../../shared/utilty/main-functions";
import moment from "moment";
import { IValidationData } from "../../models/dto/validation-data";
import { IStripePayment } from "../../models/dto/stripe-payment";
import { IUserInfoDto } from "../../models/dto/user-info.dto";
import { UserService } from "../../services/user-service";
import { kuikaCoreWasmBridgeService } from "../../services/_singletons";
import _ from "lodash";
import mqtt, { MqttClient } from "mqtt";
import { IMqttResult } from "../../models/dto/mqtt.dto";
import { MasterScreen_ScreenContext } from "../masterscreen/masterscreen-context";

declare let window: any;

export interface IRolexMaterialReporting_ScreenProps {
  navigator: KNavigator;
  form: FormInstance<any>;
  googleLogin: any;
  screenInputs: any;
  context: KContext;
  initialValues: any;
  children: any;
}

export interface IRolexMaterialReporting_ScreenState {
    isSpinnerVisible: boolean;
    isPageVisible: boolean;
	isLeftMenuVisible: boolean;
    spinnerCount: number;
    selectedLanguage: string;
    isPageInitLoaded: false;
    isPageRecurringLoaded: false;
	KuikaY_RolexTudorMaterialStoreSalesMatrix: any[];
	KuikaY_RolexTudorMaterialStoreSalesMatrix_dummy: any[];
	KuikaY_GetMaterialByBrandProductGroup: any[];
	KuikaY_GetMaterialByBrandProductGroup_dummy: any[];
	NAVIGATE: any;
	NAVIGATE_dummy: any;
	ExportExcel: any;
	ExportExcel_dummy: any;
	KuikaY_RolexTudorMaterialStoreSalesMatrixMonthly: any[];
	KuikaY_RolexTudorMaterialStoreSalesMatrixMonthly_dummy: any[];
	ChangeVisibilityOf: string;
	ChangeVisibilityOf_dummy: string;
	isComp747023Visible: 'visible' | 'hidden';
	isComp127285Visible: 'visible' | 'hidden';
	isComp813480Visible: 'visible' | 'hidden';

}

export class RolexMaterialReporting_ScreenBase extends React.PureComponent<IRolexMaterialReporting_ScreenProps, any> {
    static contextType = MasterScreen_ScreenContext;
    declare context: React.ContextType<typeof MasterScreen_ScreenContext>;
	rolexmaterialreporting_222625_value_kuikaAutoCompleteRef: React.RefObject<any>;
	rolexmaterialreporting_891206_value_kuikaTableRef: React.RefObject<any>;
	rolexmaterialreporting_840303_value_kuikaAutoCompleteRef: React.RefObject<any>;
	rolexmaterialreporting_53058_value_kuikaAutoCompleteRef: React.RefObject<any>;
	rolexmaterialreporting_110595_value_kuikaTableRef: React.RefObject<any>;
    ml=[{"Id":"d5a61d2b-bd60-485f-86e2-661e9ed4e486","Name":"en_US","ShortName":"English","IsDefault":true,"LanguagePhrases":[]},{"Id":"bbba104d-bf69-41f8-a659-e24cc45da4e3","Name":"FixedValues","ShortName":"FixedValues","LanguagePhrases":[{"Id":910240,"PropertyName":"value","Value":"Marka Bazlı Raporlama"},{"Id":869891,"PropertyName":"value","Value":"Mağaza satış performanslarını karşılaştırmalı olarak analiz edin."},{"Id":770605,"PropertyName":"label","Value":"Rolex"},{"Id":640192,"PropertyName":"label","Value":"Tudor"},{"Id":231151,"PropertyName":"label","Value":"Mont Blanc"},{"Id":276443,"PropertyName":"label","Value":"Dupont"},{"Id":126713,"PropertyName":"value","Value":"Analiz Tipi"},{"Id":248363,"PropertyName":"value","Value":"Genel Satış"},{"Id":640909,"PropertyName":"value","Value":"Family Bazlı"},{"Id":774535,"PropertyName":"value","Value":"Material Bazlı"},{"Id":359129,"PropertyName":"value","Value":"Diameter Bazlı"},{"Id":384797,"PropertyName":"value","Value":"Ürün Grubu Bazlı"},{"Id":370568,"PropertyName":"value","Value":"Toplam Satış Adedi"},{"Id":705203,"PropertyName":"value","Value":"1,247"},{"Id":350741,"PropertyName":"value","Value":"+18.5%"},{"Id":195117,"PropertyName":"value","Value":"-18.5%"},{"Id":832261,"PropertyName":"value","Value":"Toplam Ciro"},{"Id":641079,"PropertyName":"value","Value":"₺42.5M"},{"Id":820798,"PropertyName":"value","Value":"+18.5%"},{"Id":231988,"PropertyName":"value","Value":"-18.5%"},{"Id":286882,"PropertyName":"value","Value":"Geçen Yıla Göre Artış"},{"Id":653869,"PropertyName":"value","Value":"+32.8%"},{"Id":780876,"PropertyName":"value","Value":"Yıllık Büyüme"},{"Id":285506,"PropertyName":"value","Value":"En Güçlü Mağaza"},{"Id":34647,"PropertyName":"value","Value":"Adana"},{"Id":699232,"PropertyName":"value","Value":"₺8.2M Ciro"},{"Id":70281,"PropertyName":"value","Value":"En Çok Satan Family"},{"Id":297426,"PropertyName":"value","Value":"Submariner"},{"Id":925271,"PropertyName":"value","Value":"342 Adet"},{"Id":236950,"PropertyName":"value","Value":"En Çok Satan Material"},{"Id":749302,"PropertyName":"value","Value":"Yellow Gold"},{"Id":251093,"PropertyName":"value","Value":"₺12.4M Ciro"},{"Id":251515,"PropertyName":"value","Value":"Rolex-"},{"Id":902159,"PropertyName":"value","Value":"-Material Bazlı Yıllık Satış Görünüm"},{"Id":258916,"PropertyName":"placeholder","Value":"Select Year..."},{"Id":222625,"PropertyName":"placeholder","Value":"Tümü"},{"Id":559278,"PropertyName":"title","Value":"Material"},{"Id":869925,"PropertyName":"value","Value":"[datafield:material]"},{"Id":593943,"PropertyName":"title","Value":"Adana Times"},{"Id":889839,"PropertyName":"value","Value":"[datafield:adana]"},{"Id":901829,"PropertyName":"title","Value":"Antalya Rolex Boutique Times"},{"Id":173083,"PropertyName":"value","Value":"[datafield:antalya]"},{"Id":542739,"PropertyName":"title","Value":"Gaziantep Times"},{"Id":413085,"PropertyName":"value","Value":"[datafield:gaziantep]"},{"Id":304862,"PropertyName":"title","Value":"Mersin Rolex Boutique Times"},{"Id":792732,"PropertyName":"value","Value":"[datafield:mersinmagaza]"},{"Id":602912,"PropertyName":"title","Value":"Toplam"},{"Id":548521,"PropertyName":"value","Value":"[datafield:toplam]"},{"Id":781922,"PropertyName":"value","Value":"Rolex-"},{"Id":992988,"PropertyName":"value","Value":"-"},{"Id":818396,"PropertyName":"value","Value":".Ay"},{"Id":188261,"PropertyName":"value","Value":"-Material Bazlı Aylık Satış Görünüm"},{"Id":709540,"PropertyName":"value","Value":"Yıl"},{"Id":10879,"PropertyName":"placeholder","Value":"Select Year..."},{"Id":19171,"PropertyName":"value","Value":"Ay"},{"Id":840303,"PropertyName":"placeholder","Value":"Ay"},{"Id":418081,"PropertyName":"value","Value":"Materials"},{"Id":53058,"PropertyName":"placeholder","Value":"Tümü"},{"Id":544786,"PropertyName":"label","Value":"Çalıştır"},{"Id":49274,"PropertyName":"title","Value":"Material"},{"Id":244750,"PropertyName":"value","Value":"[datafield:material]"},{"Id":42888,"PropertyName":"title","Value":"Adana Times"},{"Id":930003,"PropertyName":"value","Value":"[datafield:adana]"},{"Id":196574,"PropertyName":"title","Value":"Antalya Rolex Boutique Times"},{"Id":608449,"PropertyName":"value","Value":"[datafield:antalya]"},{"Id":165562,"PropertyName":"title","Value":"Gaziantep Times"},{"Id":683364,"PropertyName":"value","Value":"[datafield:gaziantep]"},{"Id":583768,"PropertyName":"title","Value":"Mersin Rolex Boutique Times"},{"Id":315935,"PropertyName":"value","Value":"[datafield:mersinmagaza]"},{"Id":637192,"PropertyName":"title","Value":"Toplam"},{"Id":672218,"PropertyName":"value","Value":"[datafield:toplam]"}]}]
    defaultML = "en_US"
    
    screenHash = ""
    

    private _prevMasterPageInitLoaded: boolean = false;
    private _prevMasterPageRecurringLoaded: boolean = false;
    private _prevShouldTriggerPageInit: boolean = false;
    constructor(props) {
        super(props);
		this.rolexmaterialreporting_222625_value_kuikaAutoCompleteRef = React.createRef();
		this.rolexmaterialreporting_891206_value_kuikaTableRef = React.createRef();
		this.rolexmaterialreporting_840303_value_kuikaAutoCompleteRef = React.createRef();
		this.rolexmaterialreporting_53058_value_kuikaAutoCompleteRef = React.createRef();
		this.rolexmaterialreporting_110595_value_kuikaTableRef = React.createRef();

        this.state = {
            isSpinnerVisible: false,
            isPageVisible: false,
            isLeftMenuVisible: false,
            spinnerCount: 0,
            selectedLanguage: "",
            isPageInitLoaded: false,
            isPageRecurringLoaded: false,
            	        KuikaY_RolexTudorMaterialStoreSalesMatrix: [],
	        KuikaY_GetMaterialByBrandProductGroup: [],
	        NAVIGATE: "",
	        ExportExcel: "",
	        KuikaY_RolexTudorMaterialStoreSalesMatrixMonthly: [],
	        ChangeVisibilityOf: "",
	        dataSource_840303: [{"key":"1","text":"Ocak"},{"key":"2","text":"Şubat"},{"key":"3","text":"Mart"},{"key":"4","text":"Nisan"},{"key":"5","text":"Mayıs"},{"key":"6","text":"Haziran"},{"key":"7","text":"Temmuz"},{"key":"8","text":"Ağustos"},{"key":"9","text":"Eylül"},{"key":"10","text":"Ekim"},{"key":"11","text":"Kasım"},{"key":"12","text":"Aralık"}],
	        isComp747023Visible: 'hidden',
	        isComp127285Visible: 'hidden',
	        isComp813480Visible: 'hidden',

        }

        this.state.isPageVisible = true;
        
    }

    async componentDidMount() {

        if (KuikaAppManager.isPageInitPrevented()) {
            KuikaAppManager.calculateAndSetBodyHeight("rolexmaterialreporting", "masterscreen_screen");
            return;
        }
        this.context.registerCallbackFunction(this.callCallbackFunction.bind(this));
        
        ReactSystemFunctions.validateToken()
        this.fillFormInitValues();
        if (false){
            await this.RolexMaterialReportingPageInit();
        } else if (this.context?.isMasterPageInitLoaded) { this._prevMasterPageInitLoaded = true; await this.RolexMaterialReportingPageInit(); }
        
        
        
        KuikaAppManager.calculateAndSetBodyHeight("rolexmaterialreporting", "masterscreen_screen");

        if (ReactSystemFunctions.getIsMicroApp() === false) {
           window.parentScreen = this;
        }
    }

    componentWillUnmount() {
        
        
        

        if (ReactSystemFunctions.getIsMicroApp() === false) {
           window.parentScreen = null;
        }
    }

    

        
    componentDidUpdate= async (prevProps, prevState) => {
		KuikaAppManager.calculateAndSetBodyHeight("rolexmaterialreporting", "masterscreen_screen"    );
        if (prevProps?.location?.search !== (this.props as any)?.location?.search) {
			await this.RolexMaterialReportingPageInit();
		}

        		if (this._prevMasterPageInitLoaded !== this.context.isMasterPageInitLoaded && this.context.isMasterPageInitLoaded === true) {this._prevMasterPageInitLoaded = this.context.isMasterPageInitLoaded;await this.RolexMaterialReportingPageInit()}


        if (ReactSystemFunctions.getIsMicroApp() === false) {
            for (const key in prevState) {
                if (key.startsWith('NavVisible') && prevState[key] === true && this.state[key] === false) {
                    window.parentScreen = this;
                    break;
                }
            }
        }
	}

    fillFormInitValues() {
        this.props.form?.setFieldsValue({
});

    }

      setPageInitLoaded = (value: boolean) => {
        this.setState({ isPageInitLoaded: value });
      }

      setPageRecurringLoaded = (value: boolean) => {
        this.setState({ isPageRecurringLoaded: value });
      }

      clearFieldValidation = (changedValues: any) => {
        const fieldName = Object.keys(changedValues)[0];
        if (fieldName) {
          this.props.form?.setFields([
            {
              name: fieldName,
              errors: []
            }
          ]);
        }
      };

      

    RolexMaterialReportingPageInit = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


	if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }

        let localVar = {
			Brand_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.convertToTypeByName("Rolex", "string"), "string"),
			ProductGroup_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.convertToTypeByName("Kol saati", "string"), "string"),
			Material_0: ReactSystemFunctions.convertToTypeByName("", "string"),
			Year_0: ReactSystemFunctions.convertToTypeByName(2026, "number"),
			Brand_1: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.convertToTypeByName("Rolex", "string"), "string"),
			ProductGroup_1: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.convertToTypeByName("Kol saati", "string"), "string")
        }

	KuikaAppManager.showSpinner(this);
	
        if (true) {
        KuikaAppManager.showSpinner(this);
        }
        let result = await KuikaAppManager.ApiRequest(this, "RolexMaterialReporting/RolexMaterialReportingPageInit", localVar)
        if (!KMainFunctions.IsResStatus2XX(result)) return true;

		stateVars.KuikaY_RolexTudorMaterialStoreSalesMatrix = result?.data.kuikaY_RolexTudorMaterialStoreSalesMatrix;
		
		stateVars.KuikaY_GetMaterialByBrandProductGroup = result?.data.kuikaY_GetMaterialByBrandProductGroup;
		
		formVars.rolexmaterialreporting_222625_options = stateVars.KuikaY_GetMaterialByBrandProductGroup;
		
		formVars.rolexmaterialreporting_53058_options = stateVars.KuikaY_GetMaterialByBrandProductGroup;
		this.props.form?.setFieldsValue(formVars);
		
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.RolexMaterialReportingPageInit1_();
                  resolve();
                });
          })



        
        KuikaAppManager.hideSpinner(this);
        return isErrorOccurred;
    }
	RolexMaterialReportingPageInit1_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


	if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }

			ReactSystemFunctions.setValueOf(this, "rolexmaterialreporting_887414_toString", ReactSystemFunctions.value(this, "rolexmaterialreporting_258916_value", "value"), "value");

			
			stateVars.dataSource_222625 = stateVars.KuikaY_GetMaterialByBrandProductGroup ?? this.state.KuikaY_GetMaterialByBrandProductGroup;
			stateVars.dataSource_222625 = stateVars.KuikaY_GetMaterialByBrandProductGroup ?? this.state.KuikaY_GetMaterialByBrandProductGroup;
			
			stateVars.dataSource_891206 = stateVars.KuikaY_RolexTudorMaterialStoreSalesMatrix ?? this.state.KuikaY_RolexTudorMaterialStoreSalesMatrix;
			ReactSystemFunctions.setValueOf(this, "rolexmaterialreporting_289711_toString", ReactSystemFunctions.value(this, "rolexmaterialreporting_10879_value", "value"), "value");

			ReactSystemFunctions.setValueOf(this, "rolexmaterialreporting_860279_value", ReactSystemFunctions.value(this, "rolexmaterialreporting_840303_value", "value"), "value");

			
			stateVars.dataSource_53058 = stateVars.KuikaY_GetMaterialByBrandProductGroup ?? this.state.KuikaY_GetMaterialByBrandProductGroup;
			stateVars.dataSource_53058 = stateVars.KuikaY_GetMaterialByBrandProductGroup ?? this.state.KuikaY_GetMaterialByBrandProductGroup;

	this.props.form?.setFieldsValue(formVars);
	this.setState(stateVars);
	KuikaAppManager.hideSpinner(this);

            this.setPageInitLoaded(true);
            return isErrorOccurred;
        }




		RolexMaterialReportingComponent_640192_onClick = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
KuikaAppManager.showSpinner(this);

const __currentPath = (window.location.hash ? window.location.hash.replace(/^#/, '').split('?')[0] : window.location.pathname.split('?')[0]).toLowerCase();
if (__currentPath !== "/tudorbasedreporting") {
  this.context.setMasterPageInitLoaded(false);
  this.context.setMasterPageRecurringLoaded(false);
  this.context.setShouldTriggerPageInit(true);
}
					KuikaAppManager.prepareForNavigation();

				stateVars.NAVIGATE = await ReactSystemFunctions.navigate(this, undefined, "RolexMaterialReporting", "TudorBasedReporting", "", "currentPage", null, null, null, null, null, null, true, false);

		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

            
            return isErrorOccurred;
        }


		RolexMaterialReportingComponent_231151_onClick = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
KuikaAppManager.showSpinner(this);

const __currentPath = (window.location.hash ? window.location.hash.replace(/^#/, '').split('?')[0] : window.location.pathname.split('?')[0]).toLowerCase();
if (__currentPath !== "/montblancbasedreporting") {
  this.context.setMasterPageInitLoaded(false);
  this.context.setMasterPageRecurringLoaded(false);
  this.context.setShouldTriggerPageInit(true);
}
					KuikaAppManager.prepareForNavigation();

				stateVars.NAVIGATE = await ReactSystemFunctions.navigate(this, undefined, "RolexMaterialReporting", "MontBlancBasedReporting", "", "currentPage", null, null, null, null, null, null, true, false);

		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

            
            return isErrorOccurred;
        }


		RolexMaterialReportingComponent_276443_onClick = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
KuikaAppManager.showSpinner(this);

const __currentPath = (window.location.hash ? window.location.hash.replace(/^#/, '').split('?')[0] : window.location.pathname.split('?')[0]).toLowerCase();
if (__currentPath !== "/dupontbasedreporting") {
  this.context.setMasterPageInitLoaded(false);
  this.context.setMasterPageRecurringLoaded(false);
  this.context.setShouldTriggerPageInit(true);
}
					KuikaAppManager.prepareForNavigation();

				stateVars.NAVIGATE = await ReactSystemFunctions.navigate(this, undefined, "RolexMaterialReporting", "DupontBasedReporting", "", "currentPage", null, null, null, null, null, null, true, false);

		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

            
            return isErrorOccurred;
        }


		RolexMaterialReportingComponent_377465_onClick = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
KuikaAppManager.showSpinner(this);

const __currentPath = (window.location.hash ? window.location.hash.replace(/^#/, '').split('?')[0] : window.location.pathname.split('?')[0]).toLowerCase();
if (__currentPath !== "/rolexbasedreporting") {
  this.context.setMasterPageInitLoaded(false);
  this.context.setMasterPageRecurringLoaded(false);
  this.context.setShouldTriggerPageInit(true);
}
					KuikaAppManager.prepareForNavigation();

				stateVars.NAVIGATE = await ReactSystemFunctions.navigate(this, undefined, "RolexMaterialReporting", "RolexBasedReporting", "", "currentPage", null, null, null, null, null, null, true, false);

		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

            
            return isErrorOccurred;
        }


		RolexMaterialReportingComponent_948064_onClick = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
KuikaAppManager.showSpinner(this);

const __currentPath = (window.location.hash ? window.location.hash.replace(/^#/, '').split('?')[0] : window.location.pathname.split('?')[0]).toLowerCase();
if (__currentPath !== "/rolexfamilyreporting") {
  this.context.setMasterPageInitLoaded(false);
  this.context.setMasterPageRecurringLoaded(false);
  this.context.setShouldTriggerPageInit(true);
}
					KuikaAppManager.prepareForNavigation();

				stateVars.NAVIGATE = await ReactSystemFunctions.navigate(this, undefined, "RolexMaterialReporting", "RolexFamilyReporting", "", "currentPage", null, null, null, null, null, null, true, false);

		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

            
            return isErrorOccurred;
        }


		RolexMaterialReportingComponent_885746_onClick = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
KuikaAppManager.showSpinner(this);

const __currentPath = (window.location.hash ? window.location.hash.replace(/^#/, '').split('?')[0] : window.location.pathname.split('?')[0]).toLowerCase();
if (__currentPath !== "/rolexdiameterreporting") {
  this.context.setMasterPageInitLoaded(false);
  this.context.setMasterPageRecurringLoaded(false);
  this.context.setShouldTriggerPageInit(true);
}
					KuikaAppManager.prepareForNavigation();

				stateVars.NAVIGATE = await ReactSystemFunctions.navigate(this, undefined, "RolexMaterialReporting", "RolexDiameterReporting", "", "currentPage", null, null, null, null, null, null, true, false);

		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

            
            return isErrorOccurred;
        }


		RolexMaterialReportingComponent_206592_onClick = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
KuikaAppManager.showSpinner(this);

const __currentPath = (window.location.hash ? window.location.hash.replace(/^#/, '').split('?')[0] : window.location.pathname.split('?')[0]).toLowerCase();
if (__currentPath !== "/rolexotherproductreporting") {
  this.context.setMasterPageInitLoaded(false);
  this.context.setMasterPageRecurringLoaded(false);
  this.context.setShouldTriggerPageInit(true);
}
					KuikaAppManager.prepareForNavigation();

				stateVars.NAVIGATE = await ReactSystemFunctions.navigate(this, undefined, "RolexMaterialReporting", "RolexOtherProductReporting", "", "currentPage", null, null, null, null, null, null, true, false);

		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

            
            return isErrorOccurred;
        }


		RolexMaterialReportingComponent_258916_onChange = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
KuikaAppManager.showSpinner(this);

				ReactSystemFunctions.setValueOf(this, "rolexmaterialreporting_887414_toString", ReactSystemFunctions.value(this, "rolexmaterialreporting_258916_value", "value"), "value");


		this.props.form?.setFieldsValue(formVars);
		
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.RolexMaterialReportingComponent_258916_onChange1_();
                  resolve();
                });
          })

            
            return isErrorOccurred;
        }
    RolexMaterialReportingComponent_258916_onChange1_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
		KuikaAppManager.increaseServerRequestCount();

        let localVar = {
				Brand_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.convertToTypeByName("Rolex", "string"), "string"),
				ProductGroup_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.convertToTypeByName("Kol saati", "string"), "string"),
				Material_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "rolexmaterialreporting_222625_value", "value", "KuikaY_GetMaterialByBrandProductGroup", "code", "code")), "string"),
				Year_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "rolexmaterialreporting_258916_value", "value", "", "", "")), "number")
        }

		
        if (true) {
        KuikaAppManager.showSpinner(this);
        }
        let result = await KuikaAppManager.ApiRequest(this, "RolexMaterialReporting/RolexMaterialReportingComponent_258916_onChange1_", localVar)
        if (!KMainFunctions.IsResStatus2XX(result)) return true;

			stateVars.KuikaY_RolexTudorMaterialStoreSalesMatrix = result?.data.kuikaY_RolexTudorMaterialStoreSalesMatrix;
			
			this.props.form?.setFieldsValue(formVars);
			
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.RolexMaterialReportingComponent_258916_onChange2_();
                  resolve();
                });
          })



        
        KuikaAppManager.hideSpinner(this);
        return isErrorOccurred;
    }
		RolexMaterialReportingComponent_258916_onChange2_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }

				
				stateVars.dataSource_891206 = stateVars.KuikaY_RolexTudorMaterialStoreSalesMatrix ?? this.state.KuikaY_RolexTudorMaterialStoreSalesMatrix;

		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

            
            return isErrorOccurred;
        }





    RolexMaterialReportingComponent_222625_onChange = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
		KuikaAppManager.increaseServerRequestCount();

        let localVar = {
				Brand_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.convertToTypeByName("Rolex", "string"), "string"),
				ProductGroup_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.convertToTypeByName("Kol saati", "string"), "string"),
				Material_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "rolexmaterialreporting_222625_value", "value", "KuikaY_GetMaterialByBrandProductGroup", "code", "code")), "string"),
				Year_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "rolexmaterialreporting_258916_value", "value", "", "", "")), "number")
        }

		KuikaAppManager.showSpinner(this);
		
        if (true) {
        KuikaAppManager.showSpinner(this);
        }
        let result = await KuikaAppManager.ApiRequest(this, "RolexMaterialReporting/RolexMaterialReportingComponent_222625_onChange", localVar)
        if (!KMainFunctions.IsResStatus2XX(result)) return true;

			stateVars.KuikaY_RolexTudorMaterialStoreSalesMatrix = result?.data.kuikaY_RolexTudorMaterialStoreSalesMatrix;
			
			this.props.form?.setFieldsValue(formVars);
			
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.RolexMaterialReportingComponent_222625_onChange1_();
                  resolve();
                });
          })



        
        KuikaAppManager.hideSpinner(this);
        return isErrorOccurred;
    }
		RolexMaterialReportingComponent_222625_onChange1_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }

				
				stateVars.dataSource_891206 = stateVars.KuikaY_RolexTudorMaterialStoreSalesMatrix ?? this.state.KuikaY_RolexTudorMaterialStoreSalesMatrix;

		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

            
            return isErrorOccurred;
        }




    RolexMaterialReportingComponent_129721_onClick = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
		KuikaAppManager.increaseServerRequestCount();

        let localVar = {
				value_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, this.state.KuikaY_RolexTudorMaterialStoreSalesMatrix), "any"),
				header_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.convertToTypeByName("Rolex Yıllık Material Bazlı Satış Raporu", "string"), "string"),
				footer_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "rolexmaterialreporting_258916_value", "value", "", "", "")), "string"),
				columns_0: ReactSystemFunctions.convertToTypeByName("", "string")
        }

		KuikaAppManager.showSpinner(this);
		
        if (true) {
        KuikaAppManager.showSpinner(this);
        }
        let result = await KuikaAppManager.ApiRequest(this, "RolexMaterialReporting/RolexMaterialReportingComponent_129721_onClick", localVar)
        if (!KMainFunctions.IsResStatus2XX(result)) return true;

			stateVars.ExportExcel = result?.data.exportExcel;
			ReactSystemFunctions.downloadFile(result?.data?.exportExcel);
			this.props.form?.setFieldsValue(formVars);
			this.setState(stateVars);
			KuikaAppManager.hideSpinner(this);



        this.setPageInitLoaded(true);
        KuikaAppManager.hideSpinner(this);
        return isErrorOccurred;
    }



    RolexMaterialReportingComponent_793218_onClick = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
		KuikaAppManager.increaseServerRequestCount();

        let localVar = {
				value_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, this.state.KuikaY_RolexTudorMaterialStoreSalesMatrixMonthly), "any"),
				header_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.convertToTypeByName("Rolex Material Bazlı Aylık Satış Raporu", "string"), "string"),
				footer_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "rolexmaterialreporting_10879_value", "value", "", "", "")), "string"),
				columns_0: ReactSystemFunctions.convertToTypeByName("", "string")
        }

		KuikaAppManager.showSpinner(this);
		
        if (true) {
        KuikaAppManager.showSpinner(this);
        }
        let result = await KuikaAppManager.ApiRequest(this, "RolexMaterialReporting/RolexMaterialReportingComponent_793218_onClick", localVar)
        if (!KMainFunctions.IsResStatus2XX(result)) return true;

			stateVars.ExportExcel = result?.data.exportExcel;
			ReactSystemFunctions.downloadFile(result?.data?.exportExcel);
			this.props.form?.setFieldsValue(formVars);
			this.setState(stateVars);
			KuikaAppManager.hideSpinner(this);



        this.setPageInitLoaded(true);
        KuikaAppManager.hideSpinner(this);
        return isErrorOccurred;
    }



    RolexMaterialReportingComponent_544786_onClick = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
		KuikaAppManager.increaseServerRequestCount();

        let localVar = {
				Brand_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.convertToTypeByName("Rolex", "string"), "string"),
				ProductGroup_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.convertToTypeByName("Kol saati", "string"), "string"),
				Material_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "rolexmaterialreporting_53058_value", "value", "KuikaY_GetMaterialByBrandProductGroup", "code", "code")), "string"),
				Year_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "rolexmaterialreporting_10879_value", "value", "", "", "")), "number"),
				Month_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toInteger(this, ReactSystemFunctions.value(this, "rolexmaterialreporting_840303_value", "value", "", "key", "")), "number")
        }

		KuikaAppManager.showSpinner(this);
		
        if (true) {
        KuikaAppManager.showSpinner(this);
        }
        let result = await KuikaAppManager.ApiRequest(this, "RolexMaterialReporting/RolexMaterialReportingComponent_544786_onClick", localVar)
        if (!KMainFunctions.IsResStatus2XX(result)) return true;

			stateVars.KuikaY_RolexTudorMaterialStoreSalesMatrixMonthly = result?.data.kuikaY_RolexTudorMaterialStoreSalesMatrixMonthly;
			
			this.props.form?.setFieldsValue(formVars);
			
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.RolexMaterialReportingComponent_544786_onClick1_();
                  resolve();
                });
          })



        
        KuikaAppManager.hideSpinner(this);
        return isErrorOccurred;
    }
		RolexMaterialReportingComponent_544786_onClick1_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }

				stateVars.ChangeVisibilityOf = await ReactSystemFunctions.changeVisibilityOf(this, ReactSystemFunctions.convertToTypeByName("isComp747023Visible", "string"), ReactSystemFunctions.convertToTypeByName("visible", "string"));
				
				stateVars.dataSource_110595 = stateVars.KuikaY_RolexTudorMaterialStoreSalesMatrixMonthly ?? this.state.KuikaY_RolexTudorMaterialStoreSalesMatrixMonthly;

		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

            
            return isErrorOccurred;
        }




		RolexMaterialReportingComponent_10879_onChange = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
KuikaAppManager.showSpinner(this);

				ReactSystemFunctions.setValueOf(this, "rolexmaterialreporting_289711_toString", ReactSystemFunctions.value(this, "rolexmaterialreporting_10879_value", "value"), "value");


		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

            
            return isErrorOccurred;
        }


		RolexMaterialReportingComponent_840303_onChange = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
KuikaAppManager.showSpinner(this);

				ReactSystemFunctions.setValueOf(this, "rolexmaterialreporting_860279_value", ReactSystemFunctions.value(this, "rolexmaterialreporting_840303_value", "value"), "value");


		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

            
            return isErrorOccurred;
        }




    async callCallbackFunction(diId: number, isFromMaster: boolean = false) {
        let isErrorOccurred = false;
		let pageInitCallerNavDiIDs = [, , , , , , ] as number[];
		if (isFromMaster || pageInitCallerNavDiIDs.indexOf(diId) > -1) {
			await this.RolexMaterialReportingPageInit();
		}

    }


}
