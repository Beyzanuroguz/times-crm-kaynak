import React from "react";
import Axios, { AxiosResponse } from "axios";
import { KuikaAppManager } from "../../shared/utilty/kuika-app-manager";
import { ReactSystemFunctions } from "../../shared/utilty/react-system-functions";
import { KNavigator } from "../../shared/hoc/with-history";
import { KContext } from "../../shared/hoc/with-context";
import { useLocation } from "react-router-dom";
import { FormInstance } from "antd/es/form";
import { Guid } from "guid-typescript";
import Swal from "sweetalert2";
import { KMainFunctions } from "../../shared/utilty/main-functions";
import moment from "moment";
import { IValidationData } from "../../models/dto/validation-data";
import { IStripePayment } from "../../models/dto/stripe-payment";
import { IUserInfoDto } from "../../models/dto/user-info.dto";
import { UserService } from "../../services/user-service";
import { kuikaCoreWasmBridgeService } from "../../services/_singletons";
import _ from "lodash";
import mqtt, { MqttClient } from "mqtt";
import { IMqttResult } from "../../models/dto/mqtt.dto";


declare let window: any;

export interface ICustomerCreatePost_ScreenProps {
  navigator: KNavigator;
  form: FormInstance<any>;
  googleLogin: any;
  screenInputs: any;
  context: KContext;
  initialValues: any;
  children: any;
}

export interface ICustomerCreatePost_ScreenState {
    isSpinnerVisible: boolean;
    isPageVisible: boolean;
	isLeftMenuVisible: boolean;
    spinnerCount: number;
    selectedLanguage: string;
    isPageInitLoaded: false;
    isPageRecurringLoaded: false;
	Kuika_CurrAccAttribute: any[];
	Kuika_CurrAccAttribute_dummy: any[];
	TM_GetCountry: any[];
	TM_GetCountry_dummy: any[];
	SirketTipi: any[];
	SirketTipi_dummy: any[];
	GoBack: any;
	GoBack_dummy: any;
	SetValueOf: any;
	SetValueOf_dummy: any;
	ChangeEnabledOf: any;
	ChangeEnabledOf_dummy: any;
	IfThenElse: boolean;
	IfThenElse_dummy: boolean;
	TM_GetCitySql: any[];
	TM_GetCitySql_dummy: any[];
	TM_GetDistrict: any[];
	TM_GetDistrict_dummy: any[];
	GetTaxOffices: any[];
	GetTaxOffices_dummy: any[];
	GetPersonalInfoForCustomerCreate: any[];
	GetPersonalInfoForCustomerCreate_dummy: any[];
	CreateCustomer: any;
	CreateCustomer_dummy: any;
	Notify: boolean;
	Notify_dummy: boolean;
	isComp385781Visible: 'visible' | 'hidden';
	isComp224367Visible: 'visible' | 'hidden';
	isComp542911Visible: 'visible' | 'hidden';
	isComp602371Visible: 'visible' | 'hidden';
	isComp107316Enabled: 'enabled' | 'disabled';

}

export class CustomerCreatePost_ScreenBase extends React.PureComponent<ICustomerCreatePost_ScreenProps, any> {

	customercreatepost_586416_value_kuikaAutoCompleteRef: React.RefObject<any>;
	customercreatepost_79960_value_kuikaSelectBoxRef: React.RefObject<any>;
	customercreatepost_358368378_value_kuikaSelectBoxRef: React.RefObject<any>;
	customercreatepost_941270_value_kuikaAutoCompleteRef: React.RefObject<any>;
	customercreatepost_846303_value_kuikaAutoCompleteRef: React.RefObject<any>;
	customercreatepost_469746_value_kuikaAutoCompleteRef: React.RefObject<any>;
	customercreatepost_22683_value_kuikaAutoCompleteRef: React.RefObject<any>;
	customercreatepost_811888_value_kuikaAutoCompleteRef: React.RefObject<any>;
	customercreatepost_174356_value_kuikaDateRef: React.RefObject<any>;
	customercreatepost_585027_value_kuikaAutoCompleteRef: React.RefObject<any>;
	customercreatepost_560950_value_kuikaDateRef: React.RefObject<any>;
    ml=[{"Id":"d5a61d2b-bd60-485f-86e2-661e9ed4e486","Name":"en_US","ShortName":"English","IsDefault":true,"LanguagePhrases":[]},{"Id":"078f4d26-a82a-4490-90d7-b74eda0ed3c6","Name":"FixedValues","ShortName":"FixedValues","LanguagePhrases":[{"Id":432253,"PropertyName":"value","Value":"Yeni Müşteri"},{"Id":586924,"PropertyName":"value","Value":"Genel Bilgiler"},{"Id":307657,"PropertyName":"value","Value":"Ad*"},{"Id":627602,"PropertyName":"placeholder","Value":"Ad"},{"Id":952551,"PropertyName":"value","Value":"Soyad*"},{"Id":44548,"PropertyName":"placeholder","Value":"Soyad"},{"Id":29863,"PropertyName":"value","Value":"Telefon Numarası*"},{"Id":53933,"PropertyName":"placeholder","Value":"0(xxx) xxx xx xx"},{"Id":789292,"PropertyName":"value","Value":"Email*"},{"Id":196298,"PropertyName":"placeholder","Value":"name@domainname.com"},{"Id":696940,"PropertyName":"value","Value":"Müşteri Tipi*"},{"Id":586416,"PropertyName":"placeholder","Value":"Müşteri Tipi"},{"Id":1651163412,"PropertyName":"value","Value":"E-Dünya Süreci"},{"Id":1162766069,"PropertyName":"value","Value":"Şirket Statüsü"},{"Id":455250,"PropertyName":"value","Value":"Adres Bilgileri"},{"Id":719200,"PropertyName":"value","Value":"Ülke*"},{"Id":941270,"PropertyName":"placeholder","Value":"Ülke"},{"Id":521978,"PropertyName":"value","Value":"İl*"},{"Id":846303,"PropertyName":"placeholder","Value":"İl"},{"Id":435698,"PropertyName":"value","Value":"İlçe*"},{"Id":469746,"PropertyName":"placeholder","Value":"İlçe"},{"Id":836456,"PropertyName":"value","Value":"Adres"},{"Id":697352,"PropertyName":"placeholder","Value":"Adres"},{"Id":755533,"PropertyName":"value","Value":"İnfo"},{"Id":402247,"PropertyName":"placeholder","Value":"İnfo"},{"Id":812192,"PropertyName":"value","Value":"Kişisel Bilgiler"},{"Id":47456,"PropertyName":"value","Value":"TC Kimlik Numarası*"},{"Id":107316,"PropertyName":"placeholder","Value":"TC Kimlik Numarası"},{"Id":911272,"PropertyName":"value","Value":"Vergi Numarası"},{"Id":442968,"PropertyName":"placeholder","Value":"Vergi Numarası"},{"Id":2031587911,"PropertyName":"value","Value":"Vergi Dairesi"},{"Id":22683,"PropertyName":"placeholder","Value":"Vergi Dairesi"},{"Id":530644,"PropertyName":"value","Value":"Cinsiyet"},{"Id":811888,"PropertyName":"placeholder","Value":"Cinsiyet"},{"Id":138597,"PropertyName":"value","Value":"Doğum Tarihi"},{"Id":174356,"PropertyName":"placeholder","Value":"Doğum Tarihi"},{"Id":480794,"PropertyName":"value","Value":"Pasaport Ülkesi"},{"Id":585027,"PropertyName":"placeholder","Value":"Pasaport Ülkesi"},{"Id":992182,"PropertyName":"value","Value":"Pasaport No"},{"Id":391058,"PropertyName":"placeholder","Value":"Pasaport Numarası"},{"Id":500037,"PropertyName":"value","Value":"Pasaport Veriliş Tarihi"},{"Id":560950,"PropertyName":"placeholder","Value":"Pasaport Veriliş Tarihi"},{"Id":429393,"PropertyName":"value","Value":"Referans Bilgileri"},{"Id":493657,"PropertyName":"value","Value":"Ad"},{"Id":950260,"PropertyName":"placeholder","Value":"Ad"},{"Id":703099,"PropertyName":"value","Value":"Soyad"},{"Id":521685,"PropertyName":"placeholder","Value":"Soyad"},{"Id":897228,"PropertyName":"value","Value":"Telefon Numarası"},{"Id":552519,"PropertyName":"placeholder","Value":"0(xxx) xxx xx xx"},{"Id":83373,"PropertyName":"value","Value":"TC Kimlik Numarası"},{"Id":450360,"PropertyName":"placeholder","Value":"TC Kimlik Numarası"},{"Id":163827,"PropertyName":"label","Value":"Vazgeç"},{"Id":42731,"PropertyName":"label","Value":"Oluştur"}]}]
    defaultML = "en_US"
    
    screenHash = ""
    


    constructor(props) {
        super(props);
		this.customercreatepost_627602_value_kuikaTextInputRef = React.createRef();
		this.customercreatepost_44548_value_kuikaTextInputRef = React.createRef();
		this.customercreatepost_53933_value_kuikaTextInputRef = React.createRef();
		this.customercreatepost_586416_value_kuikaAutoCompleteRef = React.createRef();
		this.customercreatepost_79960_value_kuikaSelectBoxRef = React.createRef();
		this.customercreatepost_358368378_value_kuikaSelectBoxRef = React.createRef();
		this.customercreatepost_941270_value_kuikaAutoCompleteRef = React.createRef();
		this.customercreatepost_846303_value_kuikaAutoCompleteRef = React.createRef();
		this.customercreatepost_469746_value_kuikaAutoCompleteRef = React.createRef();
		this.customercreatepost_107316_value_kuikaTextInputRef = React.createRef();
		this.customercreatepost_442968_value_kuikaTextInputRef = React.createRef();
		this.customercreatepost_22683_value_kuikaAutoCompleteRef = React.createRef();
		this.customercreatepost_811888_value_kuikaAutoCompleteRef = React.createRef();
		this.customercreatepost_174356_value_kuikaDateRef = React.createRef();
		this.customercreatepost_585027_value_kuikaAutoCompleteRef = React.createRef();
		this.customercreatepost_391058_value_kuikaTextInputRef = React.createRef();
		this.customercreatepost_560950_value_kuikaDateRef = React.createRef();
		this.customercreatepost_950260_value_kuikaTextInputRef = React.createRef();
		this.customercreatepost_521685_value_kuikaTextInputRef = React.createRef();
		this.customercreatepost_552519_value_kuikaTextInputRef = React.createRef();
		this.customercreatepost_450360_value_kuikaTextInputRef = React.createRef();

        this.state = {
            isSpinnerVisible: false,
            isPageVisible: false,
            isLeftMenuVisible: false,
            spinnerCount: 0,
            selectedLanguage: "",
            isPageInitLoaded: false,
            isPageRecurringLoaded: false,
            	        Kuika_CurrAccAttribute: [],
	        TM_GetCountry: [],
	        SirketTipi: [],
	        GoBack: "",
	        IfThenElse: false,
	        TM_GetCitySql: [],
	        TM_GetDistrict: [],
	        GetTaxOffices: [],
	        GetPersonalInfoForCustomerCreate: [],
	        CreateCustomer: "",
	        Notify: false,
	        dataSource_79960: [{"key":"0","text":"E-Arşive Tabiidir"},{"key":"1","text":"E-Faturaya Tabiidir"}],
	        dataSource_811888: [{"key":"1","text":"Erkek"},{"key":"2","text":"Kadın"}],
	        isComp385781Visible: 'hidden',
	        isComp224367Visible: 'hidden',
	        isComp542911Visible: 'hidden',
	        isComp602371Visible: 'hidden',
	        isComp107316Enabled: 'enabled',

        }

        this.CheckPageAuthorization(this.state);

        
    }

    async componentDidMount() {

        if (KuikaAppManager.isPageInitPrevented()) {
            KuikaAppManager.calculateAndSetBodyHeight("customercreatepost", "");
            return;
        }
        
        
        ReactSystemFunctions.validateToken()
        this.fillFormInitValues();
        if (true){
            await this.CustomerCreatePostPageInit();
        }
        
        
        
        KuikaAppManager.calculateAndSetBodyHeight("customercreatepost", "");

        if (ReactSystemFunctions.getIsMicroApp() === false) {
           window.parentScreen = this;
        }
    }

    componentWillUnmount() {
        
        
        

        if (ReactSystemFunctions.getIsMicroApp() === false) {
           window.parentScreen = null;
        }
    }

    
              CheckPageAuthorization = async (state) => {
                KuikaAppManager.showSpinner(this);
                if (_.isEmpty(window.userInfo)) {
                  await UserService.GetUserInfoForce();
                }
                const permittedRoleNames: string[] = ["TimesYonetici","TimesUstYonetici","TimesSatisPersoneli","TimesMagazaMuduru","TimesAdmin",];
                const userInfo = window.userInfo as IUserInfoDto;
                const userRoleNames = userInfo.roles.map((role) => role.name);
                if (!ReactSystemFunctions.hasAnyRoleName(permittedRoleNames, userRoleNames)) {
                  await ReactSystemFunctions.goBack(this);

                  const language = localStorage.getItem("ml");
                  let permissonErrorMessageText = "You do not have permission to access this page.";
                  if (language === "tr_TR") {
                    permissonErrorMessageText = "Bu sayfaya erişim yetkiniz yok.";
                  } else if (language === "fr_FR") {
                    permissonErrorMessageText = "Vous n'avez pas la permission d'accéder à cette page.";
                  } else if (language === "de_DE") {
                    permissonErrorMessageText = "Sie haben keine Berechtigung, auf diese Seite zuzugreifen.";
                  } else if (language === "es_ES") {
                    permissonErrorMessageText = "No tienes permiso para acceder a esta página.";
                  }

                  KMainFunctions.displayErrorNotification(permissonErrorMessageText);
                  state.isPageVisible = false;
                  KuikaAppManager.hideSpinner(this);
                  return;
                }
                state.isPageVisible = true;
                KuikaAppManager.hideSpinner(this);
              };
        

        
    componentDidUpdate= async (prevProps, prevState) => {
		KuikaAppManager.calculateAndSetBodyHeight("customercreatepost", ""    );
        if (prevProps?.location?.search !== (this.props as any)?.location?.search) {
			await this.CustomerCreatePostPageInit();
		}

        

        if (ReactSystemFunctions.getIsMicroApp() === false) {
            for (const key in prevState) {
                if (key.startsWith('NavVisible') && prevState[key] === true && this.state[key] === false) {
                    window.parentScreen = this;
                    break;
                }
            }
        }
	}

    fillFormInitValues() {
        this.props.form?.setFieldsValue({
});

    }

      setPageInitLoaded = (value: boolean) => {
        this.setState({ isPageInitLoaded: value });
      }

      setPageRecurringLoaded = (value: boolean) => {
        this.setState({ isPageRecurringLoaded: value });
      }

      clearFieldValidation = (changedValues: any) => {
        const fieldName = Object.keys(changedValues)[0];
        if (fieldName) {
          this.props.form?.setFields([
            {
              name: fieldName,
              errors: []
            }
          ]);
        }
      };

      

    CustomerCreatePostPageInit = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


	if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }

        let localVar = {
        }

	KuikaAppManager.showSpinner(this);
	
        if (true) {
        KuikaAppManager.showSpinner(this);
        }
        let result = await KuikaAppManager.ApiRequest(this, "CustomerCreatePost/CustomerCreatePostPageInit", localVar)
        if (!KMainFunctions.IsResStatus2XX(result)) return true;

		stateVars.Kuika_CurrAccAttribute = result?.data.kuika_CurrAccAttribute;
		
		formVars.customercreatepost_586416_options = stateVars.Kuika_CurrAccAttribute;
		stateVars.TM_GetCountry = result?.data.tM_GetCountry;
		
		formVars.customercreatepost_941270_options = stateVars.TM_GetCountry;
		
		formVars.customercreatepost_585027_options = stateVars.TM_GetCountry;
		stateVars.SirketTipi = result?.data.sirketTipi;
		
		formVars.customercreatepost_358368378_options = stateVars.SirketTipi;
		this.props.form?.setFieldsValue(formVars);
		
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.CustomerCreatePostPageInit1_();
                  resolve();
                });
          })



        
        KuikaAppManager.hideSpinner(this);
        return isErrorOccurred;
    }
	CustomerCreatePostPageInit1_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


	if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }

			
			stateVars.dataSource_586416 = stateVars.Kuika_CurrAccAttribute ?? this.state.Kuika_CurrAccAttribute;
			stateVars.dataSource_586416 = stateVars.Kuika_CurrAccAttribute ?? this.state.Kuika_CurrAccAttribute;
			
			stateVars.dataSource_358368378 = stateVars.SirketTipi ?? this.state.SirketTipi;
			stateVars.dataSource_358368378 = stateVars.SirketTipi ?? this.state.SirketTipi;
			
			stateVars.dataSource_941270 = stateVars.TM_GetCountry ?? this.state.TM_GetCountry;
			stateVars.dataSource_941270 = stateVars.TM_GetCountry ?? this.state.TM_GetCountry;
			
			stateVars.dataSource_585027 = stateVars.TM_GetCountry ?? this.state.TM_GetCountry;
			stateVars.dataSource_585027 = stateVars.TM_GetCountry ?? this.state.TM_GetCountry;

	this.props.form?.setFieldsValue(formVars);
	this.setState(stateVars);
	KuikaAppManager.hideSpinner(this);

            this.setPageInitLoaded(true);
            return isErrorOccurred;
        }




		CustomerCreatePostComponent_158561_onClick = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
KuikaAppManager.showSpinner(this);

				stateVars.GoBack = await ReactSystemFunctions.goBack(this, false);

		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

            
            return isErrorOccurred;
        }


		CustomerCreatePostComponent_358368378_onChange_if0 = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
KuikaAppManager.showSpinner(this);

				stateVars.SetValueOf = await ReactSystemFunctions.setValueOf(this, ReactSystemFunctions.convertToTypeByName("customercreatepost_107316_value", "string"), ReactSystemFunctions.convertToTypeByName("11111111111", "string"), null, false);
				stateVars.ChangeEnabledOf = await ReactSystemFunctions.changeEnabledOf(this, ReactSystemFunctions.convertToTypeByName("isComp107316Enabled", "string"), ReactSystemFunctions.convertToTypeByName("enabled", "string"));

		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);

            
            return isErrorOccurred;
        }


		CustomerCreatePostComponent_358368378_onChange_else0 = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
KuikaAppManager.showSpinner(this);

				stateVars.SetValueOf = await ReactSystemFunctions.setValueOf(this, ReactSystemFunctions.convertToTypeByName("customercreatepost_107316_value", "string"), "", null, false);
				stateVars.ChangeEnabledOf = await ReactSystemFunctions.changeEnabledOf(this, ReactSystemFunctions.convertToTypeByName("isComp107316Enabled", "string"), ReactSystemFunctions.convertToTypeByName("disabled", "string"));

		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);

            
            return isErrorOccurred;
        }


		CustomerCreatePostComponent_358368378_onChange = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
if (ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "customercreatepost_358368378_value", "value", "SirketTipi", "key", "key")), "1")) {
            isErrorOccurred = await this.CustomerCreatePostComponent_358368378_onChange_if0();
                if (isErrorOccurred) return true;
        } else {
            isErrorOccurred = await this.CustomerCreatePostComponent_358368378_onChange_else0();
                if (isErrorOccurred) return true;
        }
KuikaAppManager.showSpinner(this);


		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

            
            return isErrorOccurred;
        }


    CustomerCreatePostComponent_941270_onChange = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;

			validations.push({ 
				isValid: ReactSystemFunctions.isNotEmpty(ReactSystemFunctions.value(this, "customercreatepost_941270_value", "value", "TM_GetCountry", "countryCode", ""), null),
				message: "Bu alan boş bırakılamaz !",
				formName: "customercreatepost_941270_value",
				condition: true
			} as IValidationData);

validations.forEach((validation) => {
            if (validation.message === "Geçerli bir mail adresi giriniz.") {
                validation.message = ReactSystemFunctions.getEmailValidationMessage()
            }
        })

		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
		KuikaAppManager.increaseServerRequestCount();

        let localVar = {
				CountryCode_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "customercreatepost_941270_value", "value", "TM_GetCountry", "countryCode", "countryCode")), "string")
        }

		KuikaAppManager.showSpinner(this);
		
        if (true) {
        KuikaAppManager.showSpinner(this);
        }
        let result = await KuikaAppManager.ApiRequest(this, "CustomerCreatePost/CustomerCreatePostComponent_941270_onChange", localVar)
        if (!KMainFunctions.IsResStatus2XX(result)) return true;

			stateVars.TM_GetCitySql = result?.data.tM_GetCitySql;
			
			formVars.customercreatepost_846303_options = stateVars.TM_GetCitySql;
			this.props.form?.setFieldsValue(formVars);
			
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.CustomerCreatePostComponent_941270_onChange1_();
                  resolve();
                });
          })



        
        KuikaAppManager.hideSpinner(this);
        return isErrorOccurred;
    }
		CustomerCreatePostComponent_941270_onChange1_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }

				
				stateVars.dataSource_846303 = stateVars.TM_GetCitySql ?? this.state.TM_GetCitySql;
				stateVars.dataSource_846303 = stateVars.TM_GetCitySql ?? this.state.TM_GetCitySql;

		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

            
            return isErrorOccurred;
        }




    CustomerCreatePostComponent_846303_onChange = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;

			validations.push({ 
				isValid: ReactSystemFunctions.isNotEmpty(ReactSystemFunctions.value(this, "customercreatepost_846303_value", "value", "TM_GetCitySql", "cityCode", ""), null),
				message: "Bu alan boş bırakılamaz !",
				formName: "customercreatepost_846303_value",
				condition: true
			} as IValidationData);

validations.forEach((validation) => {
            if (validation.message === "Geçerli bir mail adresi giriniz.") {
                validation.message = ReactSystemFunctions.getEmailValidationMessage()
            }
        })

		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
		KuikaAppManager.increaseServerRequestCount();

        let localVar = {
				CityCode_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "customercreatepost_846303_value", "value", "TM_GetCitySql", "cityCode", "cityCode")), "string"),
				cityCode_1: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "customercreatepost_846303_value", "value", "TM_GetCitySql", "cityCode", "cityCode")), "string")
        }

		KuikaAppManager.showSpinner(this);
		
        if (true) {
        KuikaAppManager.showSpinner(this);
        }
        let result = await KuikaAppManager.ApiRequest(this, "CustomerCreatePost/CustomerCreatePostComponent_846303_onChange", localVar)
        if (!KMainFunctions.IsResStatus2XX(result)) return true;

			stateVars.TM_GetDistrict = result?.data.tM_GetDistrict;
			
			formVars.customercreatepost_469746_options = stateVars.TM_GetDistrict;
			stateVars.GetTaxOffices = result?.data.getTaxOffices;
			
			formVars.customercreatepost_22683_options = stateVars.GetTaxOffices;
			this.props.form?.setFieldsValue(formVars);
			
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.CustomerCreatePostComponent_846303_onChange1_();
                  resolve();
                });
          })



        
        KuikaAppManager.hideSpinner(this);
        return isErrorOccurred;
    }
		CustomerCreatePostComponent_846303_onChange1_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }

				
				stateVars.dataSource_469746 = stateVars.TM_GetDistrict ?? this.state.TM_GetDistrict;
				stateVars.dataSource_469746 = stateVars.TM_GetDistrict ?? this.state.TM_GetDistrict;
				
				stateVars.dataSource_22683 = stateVars.GetTaxOffices ?? this.state.GetTaxOffices;
				stateVars.dataSource_22683 = stateVars.GetTaxOffices ?? this.state.GetTaxOffices;

		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

            
            return isErrorOccurred;
        }




		CustomerCreatePostComponent_163827_onClick = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
KuikaAppManager.showSpinner(this);

				stateVars.GoBack = await ReactSystemFunctions.goBack(this, false);

		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

            
            return isErrorOccurred;
        }


    CustomerCreatePostComponent_42731_onClick = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;

			validations.push({ 
				isValid: ReactSystemFunctions.isNotEmpty(ReactSystemFunctions.value(this, "customercreatepost_627602_value", "value", "", "", ""), null),
				message: "Bu alan boş bırakılamaz !",
				formName: "customercreatepost_627602_value",
				condition: true
			} as IValidationData);

validations.forEach((validation) => {
            if (validation.message === "Geçerli bir mail adresi giriniz.") {
                validation.message = ReactSystemFunctions.getEmailValidationMessage()
            }
        })
			validations.push({ 
				isValid: ReactSystemFunctions.isNotEmpty(ReactSystemFunctions.value(this, "customercreatepost_44548_value", "value", "", "", ""), null),
				message: "Bu alan boş bırakılamaz !",
				formName: "customercreatepost_44548_value",
				condition: true
			} as IValidationData);

validations.forEach((validation) => {
            if (validation.message === "Geçerli bir mail adresi giriniz.") {
                validation.message = ReactSystemFunctions.getEmailValidationMessage()
            }
        })
			validations.push({ 
				isValid: ReactSystemFunctions.isNotEmpty(ReactSystemFunctions.value(this, "customercreatepost_196298_value", "value", "", "", ""), null),
				message: "Bu alan boş bırakılamaz !",
				formName: "customercreatepost_196298_value",
				condition: true
			} as IValidationData);

validations.forEach((validation) => {
            if (validation.message === "Geçerli bir mail adresi giriniz.") {
                validation.message = ReactSystemFunctions.getEmailValidationMessage()
            }
        })
			validations.push({ 
				isValid: ReactSystemFunctions.isValidEmail(ReactSystemFunctions.value(this, "customercreatepost_196298_value", "value", "", "", ""), null),
				message: "Geçerli bir mail adresi giriniz.",
				formName: "customercreatepost_196298_value",
				condition: true
			} as IValidationData);

validations.forEach((validation) => {
            if (validation.message === "Geçerli bir mail adresi giriniz.") {
                validation.message = ReactSystemFunctions.getEmailValidationMessage()
            }
        })
			validations.push({ 
				isValid: ReactSystemFunctions.isNotEmpty(ReactSystemFunctions.value(this, "customercreatepost_586416_value", "value", "Kuika_CurrAccAttribute", "customerAtt02", ""), null),
				message: "Bu alan boş bırakılamaz !",
				formName: "customercreatepost_586416_value",
				condition: true
			} as IValidationData);

validations.forEach((validation) => {
            if (validation.message === "Geçerli bir mail adresi giriniz.") {
                validation.message = ReactSystemFunctions.getEmailValidationMessage()
            }
        })
			validations.push({ 
				isValid: ReactSystemFunctions.isNotEmpty(ReactSystemFunctions.value(this, "customercreatepost_941270_value", "value", "TM_GetCountry", "countryCode", ""), null),
				message: "Bu alan boş bırakılamaz !",
				formName: "customercreatepost_941270_value",
				condition: true
			} as IValidationData);

validations.forEach((validation) => {
            if (validation.message === "Geçerli bir mail adresi giriniz.") {
                validation.message = ReactSystemFunctions.getEmailValidationMessage()
            }
        })
			validations.push({ 
				isValid: ReactSystemFunctions.isNotEmpty(ReactSystemFunctions.value(this, "customercreatepost_846303_value", "value", "TM_GetCitySql", "cityCode", ""), null),
				message: "Bu alan boş bırakılamaz !",
				formName: "customercreatepost_846303_value",
				condition: true
			} as IValidationData);

validations.forEach((validation) => {
            if (validation.message === "Geçerli bir mail adresi giriniz.") {
                validation.message = ReactSystemFunctions.getEmailValidationMessage()
            }
        })
			validations.push({ 
				isValid: ReactSystemFunctions.isNotEmpty(ReactSystemFunctions.value(this, "customercreatepost_469746_value", "value", "TM_GetDistrict", "districtCode", ""), null),
				message: "Bu alan boş bırakılamaz !",
				formName: "customercreatepost_469746_value",
				condition: true
			} as IValidationData);

validations.forEach((validation) => {
            if (validation.message === "Geçerli bir mail adresi giriniz.") {
                validation.message = ReactSystemFunctions.getEmailValidationMessage()
            }
        })
			validations.push({ 
				isValid: ReactSystemFunctions.isNotEmpty(ReactSystemFunctions.value(this, "customercreatepost_107316_value", "value", "", "", ""), null),
				message: "Bu alan boş bırakılamaz !",
				formName: "customercreatepost_107316_value",
				condition: ReactSystemFunctions.isNotEqualTo(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "customercreatepost_358368378_value", "value", "SirketTipi", "key", "")), ReactSystemFunctions.convertToTypeByName("0", "string"))
			} as IValidationData);

validations.forEach((validation) => {
            if (validation.message === "Geçerli bir mail adresi giriniz.") {
                validation.message = ReactSystemFunctions.getEmailValidationMessage()
            }
        })
			validations.push({ 
				isValid: ReactSystemFunctions.isNotEmpty(ReactSystemFunctions.value(this, "customercreatepost_402247_value", "value", "", "", ""), null),
				message: "Bu alan zorunludur!",
				formName: "customercreatepost_402247_value",
				condition: true
			} as IValidationData);

validations.forEach((validation) => {
            if (validation.message === "Geçerli bir mail adresi giriniz.") {
                validation.message = ReactSystemFunctions.getEmailValidationMessage()
            }
        })

		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
		KuikaAppManager.increaseServerRequestCount();

        let localVar = {
				KUserId_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.getMyUserId(), "Guid"),
				officeCode_1: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, (stateVars.GetPersonalInfoForCustomerCreate !== undefined ? (stateVars.GetPersonalInfoForCustomerCreate?.length > 0 ? stateVars.GetPersonalInfoForCustomerCreate[0].officeCode : null) : (this.state.GetPersonalInfoForCustomerCreate?.length > 0 ? this.state.GetPersonalInfoForCustomerCreate[0].officeCode : null))), "string"),
				ad_1: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "customercreatepost_627602_value", "value", "", "", "")), "string"),
				soyad_1: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "customercreatepost_44548_value", "value", "", "", "")), "string"),
				telefon_1: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "customercreatepost_53933_value", "value", "", "", "")), "string"),
				email_1: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "customercreatepost_196298_value", "value", "", "", "")), "string"),
				musteriTipi2_1: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "customercreatepost_586416_value", "value", "Kuika_CurrAccAttribute", "customerAtt02", "customerAtt02")), "string"),
				ulke_1: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "customercreatepost_941270_value", "value", "TM_GetCountry", "countryCode", "countryCode")), "string"),
				il_1: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "customercreatepost_846303_value", "value", "TM_GetCitySql", "cityCode", "cityCode")), "string"),
				ilce_1: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "customercreatepost_469746_value", "value", "TM_GetDistrict", "districtCode", "districtCode")), "string"),
				adres_1: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "customercreatepost_697352_value", "value", "", "", "")), "string"),
				tcKimlikNo_1: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "customercreatepost_107316_value", "value", "", "", "")), "string"),
				vergiNo_1: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "customercreatepost_442968_value", "value", "", "", "")), "string"),
				vergiDairesiKodu_1: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "customercreatepost_22683_value", "value", "GetTaxOffices", "taxOfficeCode", "taxOfficeCode")), "string"),
				vergiDairesiAdi_1: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "customercreatepost_22683_value", "value", "GetTaxOffices", "taxOfficeCode", "taxOfficeDescription")), "string"),
				cinsiyet_1: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toInteger(this, ReactSystemFunctions.value(this, "customercreatepost_811888_value", "value", "", "key", "")), "number"),
				dogumTarihi_1: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "customercreatepost_174356_value", "value", "", "", "")), "Date"),
				dogumYeri_1: ReactSystemFunctions.convertToTypeByName("", "string"),
				pasaportUlke_1: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "customercreatepost_585027_value", "value", "TM_GetCountry", "countryName", "countryCode")), "string"),
				pasaportNo_1: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "customercreatepost_391058_value", "value", "", "", "")), "string"),
				pasaportTarihi_1: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "customercreatepost_560950_value", "value", "", "", "")), "Date"),
				refAd_1: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "customercreatepost_950260_value", "value", "", "", "")), "string"),
				refSoyad_1: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "customercreatepost_521685_value", "value", "", "", "")), "string"),
				refTC_1: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "customercreatepost_450360_value", "value", "", "", "")), "string"),
				info_1: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "customercreatepost_402247_value", "value", "", "", "")), "string"),
				isIndividualAcc_1: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toBoolean(this, ReactSystemFunctions.value(this, "customercreatepost_358368378_value", "value", "SirketTipi", "key", "key")), "boolean"),
				isSubjectToEInvoice_1: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toBoolean(this, ReactSystemFunctions.value(this, "customercreatepost_79960_value", "value", "", "key", "")), "boolean")
        }

		KuikaAppManager.showSpinner(this);
		
        if (true) {
        KuikaAppManager.showSpinner(this);
        }
        let result = await KuikaAppManager.ApiRequest(this, "CustomerCreatePost/CustomerCreatePostComponent_42731_onClick", localVar)
        if (!KMainFunctions.IsResStatus2XX(result)) return true;

			stateVars.GetPersonalInfoForCustomerCreate = result?.data.getPersonalInfoForCustomerCreate;
			stateVars.CreateCustomer = result?.data.createCustomer;
			this.props.form?.setFieldsValue(formVars);
			
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.CustomerCreatePostComponent_42731_onClick1_();
                  resolve();
                });
          })



        
        KuikaAppManager.hideSpinner(this);
        return isErrorOccurred;
    }
		CustomerCreatePostComponent_42731_onClick1_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }

				stateVars.Notify = await ReactSystemFunctions.notify(this, ReactSystemFunctions.toString(this, this.state.CreateCustomer?.responseMessage), ReactSystemFunctions.convertToTypeByName("default", "string"), ReactSystemFunctions.convertToTypeByName("bottom-right", "string"), 2, ReactSystemFunctions.convertToTypeByName("", "string"), ReactSystemFunctions.convertToTypeByName("", "string"), 0);

		this.props.form?.setFieldsValue(formVars);
		
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.CustomerCreatePostComponent_42731_onClick2_();
                  resolve();
                });
          })

            
            return isErrorOccurred;
        }
		CustomerCreatePostComponent_42731_onClick2_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
if (ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, this.state.CreateCustomer?.isSuccess), "1")) {
            
				stateVars.GoBack = await ReactSystemFunctions.goBack(this, false);

		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

        } else {
            KuikaAppManager.hideSpinner(this);
        }

            
            return isErrorOccurred;
        }







    async callCallbackFunction(diId: number, isFromMaster: boolean = false) {
        let isErrorOccurred = false;
		let pageInitCallerNavDiIDs = [] as number[];
		if (isFromMaster || pageInitCallerNavDiIDs.indexOf(diId) > -1) {
			await this.CustomerCreatePostPageInit();
		}

    }


}
