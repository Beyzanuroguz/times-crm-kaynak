import React from "react";
import Axios, { AxiosResponse } from "axios";
import { KuikaAppManager } from "../../shared/utilty/kuika-app-manager";
import { ReactSystemFunctions } from "../../shared/utilty/react-system-functions";
import { KNavigator } from "../../shared/hoc/with-history";
import { KContext } from "../../shared/hoc/with-context";
import { useLocation } from "react-router-dom";
import { FormInstance } from "antd/es/form";
import { Guid } from "guid-typescript";
import Swal from "sweetalert2";
import { KMainFunctions } from "../../shared/utilty/main-functions";
import moment from "moment";
import { IValidationData } from "../../models/dto/validation-data";
import { IStripePayment } from "../../models/dto/stripe-payment";
import { IUserInfoDto } from "../../models/dto/user-info.dto";
import { UserService } from "../../services/user-service";
import { kuikaCoreWasmBridgeService } from "../../services/_singletons";
import _ from "lodash";
import mqtt, { MqttClient } from "mqtt";
import { IMqttResult } from "../../models/dto/mqtt.dto";
import { MasterScreen_ScreenContext } from "../masterscreen/masterscreen-context";

declare let window: any;

export interface IAnnualPortfolioCreationStep1copycopy_ScreenProps {
  navigator: KNavigator;
  form: FormInstance<any>;
  googleLogin: any;
  screenInputs: any;
  context: KContext;
  initialValues: any;
  children: any;
}

export interface IAnnualPortfolioCreationStep1copycopy_ScreenState {
    isSpinnerVisible: boolean;
    isPageVisible: boolean;
	isLeftMenuVisible: boolean;
    spinnerCount: number;
    selectedLanguage: string;
    isPageInitLoaded: false;
    isPageRecurringLoaded: false;
	TM_GetYearlyStockByType: any[];
	TM_GetYearlyStockByType_dummy: any[];
	ListProductWithQty: any[];
	ListProductWithQty_dummy: any[];
	TM_TotalVerifyExcel: any[];
	TM_TotalVerifyExcel_dummy: any[];
	GoBack: any;
	GoBack_dummy: any;
	NAVIGATE: any;
	NAVIGATE_dummy: any;
	TM_UpdateTotalProductAnnualObj: number;
	TM_UpdateTotalProductAnnualObj_dummy: number;
	TriggerEvent: string;
	TriggerEvent_dummy: string;
	TM_ProductAnnualUpdate: number;
	TM_ProductAnnualUpdate_dummy: number;
	isComp953065Visible: 'visible' | 'hidden';

}

export class AnnualPortfolioCreationStep1copycopy_ScreenBase extends React.PureComponent<IAnnualPortfolioCreationStep1copycopy_ScreenProps, any> {
    static contextType = MasterScreen_ScreenContext;
    declare context: React.ContextType<typeof MasterScreen_ScreenContext>;
	annualportfoliocreationstep1copycopy_545766_value_kuikaTableRef: React.RefObject<any>;
	annualportfoliocreationstep1copycopy_694844_value_kuikaSelectBoxRef: React.RefObject<any>;
	annualportfoliocreationstep1copycopy_340793_value_kuikaTableRef: React.RefObject<any>;
    ml=[{"Id":"d5a61d2b-bd60-485f-86e2-661e9ed4e486","Name":"en_US","ShortName":"English","IsDefault":true,"LanguagePhrases":[]},{"Id":"52ae24f4-85e6-45b1-8a47-5675ddff29b8","Name":"FixedValues","ShortName":"FixedValues","LanguagePhrases":[{"Id":671117,"PropertyName":"value","Value":"Yıllık Ürün Bazlı Kota Dağılımı"},{"Id":350805,"PropertyName":"value","Value":"Her saat modeli için mağazalara tanımlanan yıllık sipariş kotalarını görüntüleyin ve düzenleyin"},{"Id":283503,"PropertyName":"label","Value":"Geri"},{"Id":999521,"PropertyName":"label","Value":"Mağaza Bazlı Dağıtım"},{"Id":903896,"PropertyName":"title","Value":"Total Objective Kota"},{"Id":844278,"PropertyName":"value","Value":"[datafield:objective]"},{"Id":411875,"PropertyName":"placeholder","Value":"15"},{"Id":655801,"PropertyName":"title","Value":"Total Non-Objective Kota"},{"Id":917467,"PropertyName":"value","Value":"[datafield:objectivedisinda]"},{"Id":308052,"PropertyName":"placeholder","Value":"15"},{"Id":490280,"PropertyName":"value","Value":"Toplam Objective Kota"},{"Id":350744,"PropertyName":"value","Value":"Kalan Objective Kota"},{"Id":596938,"PropertyName":"value","Value":"Toplam Objective Dışında Kota"},{"Id":898529,"PropertyName":"value","Value":"Kalan Objective Dışında Kota"},{"Id":949357,"PropertyName":"value","Value":"Modele Göre Arama"},{"Id":694844,"PropertyName":"placeholder","Value":"Referans"},{"Id":868123,"PropertyName":"title","Value":"Saat Referans Kodu"},{"Id":503017,"PropertyName":"value","Value":"[datafield:refno]"},{"Id":3026,"PropertyName":"title","Value":"Objective"},{"Id":209909,"PropertyName":"value","Value":"[datafield:objectivetotalstock]"},{"Id":700137,"PropertyName":"placeholder","Value":"0"},{"Id":395419,"PropertyName":"title","Value":"Objective Değil"},{"Id":100901,"PropertyName":"placeholder","Value":"0"}]}]
    defaultML = "en_US"
    
    screenHash = ""
    

    private _prevMasterPageInitLoaded: boolean = false;
    private _prevMasterPageRecurringLoaded: boolean = false;
    private _prevShouldTriggerPageInit: boolean = false;
    constructor(props) {
        super(props);
		this.annualportfoliocreationstep1copycopy_545766_value_kuikaTableRef = React.createRef();
		this.annualportfoliocreationstep1copycopy_694844_value_kuikaSelectBoxRef = React.createRef();
		this.annualportfoliocreationstep1copycopy_340793_value_kuikaTableRef = React.createRef();

        this.state = {
            isSpinnerVisible: false,
            isPageVisible: false,
            isLeftMenuVisible: false,
            spinnerCount: 0,
            selectedLanguage: "",
            isPageInitLoaded: false,
            isPageRecurringLoaded: false,
            	        TM_GetYearlyStockByType: [],
	        ListProductWithQty: [],
	        TM_TotalVerifyExcel: [],
	        GoBack: "",
	        NAVIGATE: "",
	        TM_UpdateTotalProductAnnualObj: 0,
	        TriggerEvent: "",
	        TM_ProductAnnualUpdate: 0,
	        isComp953065Visible: 'hidden',

        }

        this.state.isPageVisible = true;
        
    }

    async componentDidMount() {

        if (KuikaAppManager.isPageInitPrevented()) {
            KuikaAppManager.calculateAndSetBodyHeight("annualportfoliocreationstep1copycopy", "masterscreen_screen");
            return;
        }
        this.context.registerCallbackFunction(this.callCallbackFunction.bind(this));
        
        ReactSystemFunctions.validateToken()
        this.fillFormInitValues();
        if (false){
            await this.AnnualPortfolioCreationStep1copycopyPageInit();
        } else if (this.context?.isMasterPageInitLoaded) { this._prevMasterPageInitLoaded = true; await this.AnnualPortfolioCreationStep1copycopyPageInit(); }
        
        
        
        KuikaAppManager.calculateAndSetBodyHeight("annualportfoliocreationstep1copycopy", "masterscreen_screen");

        if (ReactSystemFunctions.getIsMicroApp() === false) {
           window.parentScreen = this;
        }
    }

    componentWillUnmount() {
        
        
        

        if (ReactSystemFunctions.getIsMicroApp() === false) {
           window.parentScreen = null;
        }
    }

    

        
    componentDidUpdate= async (prevProps, prevState) => {
		KuikaAppManager.calculateAndSetBodyHeight("annualportfoliocreationstep1copycopy", "masterscreen_screen"    );
        if (prevProps?.location?.search !== (this.props as any)?.location?.search) {
			await this.AnnualPortfolioCreationStep1copycopyPageInit();
		}

        		if (this._prevMasterPageInitLoaded !== this.context.isMasterPageInitLoaded && this.context.isMasterPageInitLoaded === true) {this._prevMasterPageInitLoaded = this.context.isMasterPageInitLoaded;await this.AnnualPortfolioCreationStep1copycopyPageInit()}


        if (ReactSystemFunctions.getIsMicroApp() === false) {
            for (const key in prevState) {
                if (key.startsWith('NavVisible') && prevState[key] === true && this.state[key] === false) {
                    window.parentScreen = this;
                    break;
                }
            }
        }
	}

    fillFormInitValues() {
        this.props.form?.setFieldsValue({
});

    }

      setPageInitLoaded = (value: boolean) => {
        this.setState({ isPageInitLoaded: value });
      }

      setPageRecurringLoaded = (value: boolean) => {
        this.setState({ isPageRecurringLoaded: value });
      }

      clearFieldValidation = (changedValues: any) => {
        const fieldName = Object.keys(changedValues)[0];
        if (fieldName) {
          this.props.form?.setFields([
            {
              name: fieldName,
              errors: []
            }
          ]);
        }
      };

      

    AnnualPortfolioCreationStep1copycopyPageInit = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


	if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }

        let localVar = {
			Year_0: ReactSystemFunctions.convertToTypeByName(this.props.screenInputs.Year ?? this.props.screenInputs.year, "string"),
			Yearn_1: ReactSystemFunctions.convertToTypeByName(this.props.screenInputs.Year ?? this.props.screenInputs.year, "string"),
			RefNo_1: ReactSystemFunctions.convertToTypeByName(null, "string"),
			Year_2: ReactSystemFunctions.convertToTypeByName(this.props.screenInputs.Year ?? this.props.screenInputs.year, "string")
        }

	KuikaAppManager.showSpinner(this);
	
        if (true) {
        KuikaAppManager.showSpinner(this);
        }
        let result = await KuikaAppManager.ApiRequest(this, "AnnualPortfolioCreationStep1copycopy/AnnualPortfolioCreationStep1copycopyPageInit", localVar)
        if (!KMainFunctions.IsResStatus2XX(result)) return true;

		stateVars.TM_GetYearlyStockByType = result?.data.tM_GetYearlyStockByType;
		formVars.annualportfoliocreationstep1copycopy_290954_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetYearlyStockByType !== undefined ? (stateVars.TM_GetYearlyStockByType?.length > 0 ? stateVars.TM_GetYearlyStockByType[0].objectiveTotalStock : null) : (this.state.TM_GetYearlyStockByType?.length > 0 ? this.state.TM_GetYearlyStockByType[0].objectiveTotalStock : null)));
		formVars.annualportfoliocreationstep1copycopy_667325_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetYearlyStockByType !== undefined ? (stateVars.TM_GetYearlyStockByType?.length > 0 ? stateVars.TM_GetYearlyStockByType[0].objectiveRemainingStock : null) : (this.state.TM_GetYearlyStockByType?.length > 0 ? this.state.TM_GetYearlyStockByType[0].objectiveRemainingStock : null)));
		formVars.annualportfoliocreationstep1copycopy_578325_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetYearlyStockByType !== undefined ? (stateVars.TM_GetYearlyStockByType?.length > 0 ? stateVars.TM_GetYearlyStockByType[0].nonObjectiveTotalStock : null) : (this.state.TM_GetYearlyStockByType?.length > 0 ? this.state.TM_GetYearlyStockByType[0].nonObjectiveTotalStock : null)));
		formVars.annualportfoliocreationstep1copycopy_757790_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetYearlyStockByType !== undefined ? (stateVars.TM_GetYearlyStockByType?.length > 0 ? stateVars.TM_GetYearlyStockByType[0].nonObjectiveRemainingStock : null) : (this.state.TM_GetYearlyStockByType?.length > 0 ? this.state.TM_GetYearlyStockByType[0].nonObjectiveRemainingStock : null)));
		stateVars.ListProductWithQty = result?.data.listProductWithQty;
		
		formVars.annualportfoliocreationstep1copycopy_694844_options = stateVars.ListProductWithQty;
		
		stateVars.TM_TotalVerifyExcel = result?.data.tM_TotalVerifyExcel;
		
		this.props.form?.setFieldsValue(formVars);
		
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.AnnualPortfolioCreationStep1copycopyPageInit1_();
                  resolve();
                });
          })



        
        KuikaAppManager.hideSpinner(this);
        return isErrorOccurred;
    }
	AnnualPortfolioCreationStep1copycopyPageInit1_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


	if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }

			
			stateVars.dataSource_545766 = stateVars.TM_TotalVerifyExcel ?? this.state.TM_TotalVerifyExcel;
			formVars.annualportfoliocreationstep1copycopy_290954_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetYearlyStockByType !== undefined ? (stateVars.TM_GetYearlyStockByType?.length > 0 ? stateVars.TM_GetYearlyStockByType[0].objectiveTotalStock : null) : (this.state.TM_GetYearlyStockByType?.length > 0 ? this.state.TM_GetYearlyStockByType[0].objectiveTotalStock : null)));

			formVars.annualportfoliocreationstep1copycopy_667325_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetYearlyStockByType !== undefined ? (stateVars.TM_GetYearlyStockByType?.length > 0 ? stateVars.TM_GetYearlyStockByType[0].objectiveRemainingStock : null) : (this.state.TM_GetYearlyStockByType?.length > 0 ? this.state.TM_GetYearlyStockByType[0].objectiveRemainingStock : null)));

			formVars.annualportfoliocreationstep1copycopy_578325_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetYearlyStockByType !== undefined ? (stateVars.TM_GetYearlyStockByType?.length > 0 ? stateVars.TM_GetYearlyStockByType[0].nonObjectiveTotalStock : null) : (this.state.TM_GetYearlyStockByType?.length > 0 ? this.state.TM_GetYearlyStockByType[0].nonObjectiveTotalStock : null)));

			formVars.annualportfoliocreationstep1copycopy_757790_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetYearlyStockByType !== undefined ? (stateVars.TM_GetYearlyStockByType?.length > 0 ? stateVars.TM_GetYearlyStockByType[0].nonObjectiveRemainingStock : null) : (this.state.TM_GetYearlyStockByType?.length > 0 ? this.state.TM_GetYearlyStockByType[0].nonObjectiveRemainingStock : null)));

			
			stateVars.dataSource_694844 = stateVars.ListProductWithQty ?? this.state.ListProductWithQty;
			stateVars.dataSource_694844 = stateVars.ListProductWithQty ?? this.state.ListProductWithQty;
			
			stateVars.dataSource_340793 = stateVars.ListProductWithQty ?? this.state.ListProductWithQty;

	this.props.form?.setFieldsValue(formVars);
	this.setState(stateVars);
	KuikaAppManager.hideSpinner(this);

            this.setPageInitLoaded(true);
            return isErrorOccurred;
        }




		AnnualPortfolioCreationStep1copycopyComponent_283503_onClick = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
KuikaAppManager.showSpinner(this);

				stateVars.GoBack = await ReactSystemFunctions.goBack(this, false);

		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

            
            return isErrorOccurred;
        }


		AnnualPortfolioCreationStep1copycopyComponent_999521_onClick = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
KuikaAppManager.showSpinner(this);

const __currentPath = (window.location.hash ? window.location.hash.replace(/^#/, '').split('?')[0] : window.location.pathname.split('?')[0]).toLowerCase();
if (__currentPath !== "/yearlyallocationcopy") {
  this.context.setMasterPageInitLoaded(false);
  this.context.setMasterPageRecurringLoaded(false);
  this.context.setShouldTriggerPageInit(true);
}
					KuikaAppManager.prepareForNavigation();
						KuikaAppManager.addToPageInputVariables("YearlyAllocationcopy", "Year", ReactSystemFunctions.convertToTypeByName(this.props.screenInputs.Year ?? this.props.screenInputs.year, "string"));

				stateVars.NAVIGATE = await ReactSystemFunctions.navigate(this, undefined, "AnnualPortfolioCreationStep1copycopy", "YearlyAllocationcopy", "", "currentPage", null, null, null, null, null, null, true, false);

		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

            
            return isErrorOccurred;
        }


    AnnualPortfolioCreationStep1copycopyComponent_411875_onBlur = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
		KuikaAppManager.increaseServerRequestCount();

        let localVar = {
				Objective_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "Table_545766_objective", "value", "", "", "")), "number"),
				NonObjective_0: ReactSystemFunctions.convertToTypeByName(null, "number"),
				Year_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, "annualportfoliocreationstep1copycopy_545766_value", "yearn"), "string")
        }

		KuikaAppManager.showSpinner(this);
		
        if (true) {
        KuikaAppManager.showSpinner(this);
        }
        let result = await KuikaAppManager.ApiRequest(this, "AnnualPortfolioCreationStep1copycopy/AnnualPortfolioCreationStep1copycopyComponent_411875_onBlur", localVar)
        if (!KMainFunctions.IsResStatus2XX(result)) return true;

			stateVars.TM_UpdateTotalProductAnnualObj = result?.data.tM_UpdateTotalProductAnnualObj;
			this.props.form?.setFieldsValue(formVars);
			
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.AnnualPortfolioCreationStep1copycopyComponent_411875_onBlur1_();
                  resolve();
                });
          })



        
        KuikaAppManager.hideSpinner(this);
        return isErrorOccurred;
    }
		AnnualPortfolioCreationStep1copycopyComponent_411875_onBlur1_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }

				await this.AnnualPortfolioCreationStep1copycopyPageInit();
				

		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

            
            return isErrorOccurred;
        }




    AnnualPortfolioCreationStep1copycopyComponent_308052_onBlur = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
		KuikaAppManager.increaseServerRequestCount();

        let localVar = {
				Objective_0: ReactSystemFunctions.convertToTypeByName(null, "number"),
				NonObjective_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "Table_545766_objectiveDisinda", "value", "", "", "")), "number"),
				Year_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, "annualportfoliocreationstep1copycopy_545766_value", "yearn"), "string")
        }

		KuikaAppManager.showSpinner(this);
		
        if (true) {
        KuikaAppManager.showSpinner(this);
        }
        let result = await KuikaAppManager.ApiRequest(this, "AnnualPortfolioCreationStep1copycopy/AnnualPortfolioCreationStep1copycopyComponent_308052_onBlur", localVar)
        if (!KMainFunctions.IsResStatus2XX(result)) return true;

			stateVars.TM_UpdateTotalProductAnnualObj = result?.data.tM_UpdateTotalProductAnnualObj;
			this.props.form?.setFieldsValue(formVars);
			
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.AnnualPortfolioCreationStep1copycopyComponent_308052_onBlur1_();
                  resolve();
                });
          })



        
        KuikaAppManager.hideSpinner(this);
        return isErrorOccurred;
    }
		AnnualPortfolioCreationStep1copycopyComponent_308052_onBlur1_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }

				await this.AnnualPortfolioCreationStep1copycopyPageInit();
				

		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

            
            return isErrorOccurred;
        }




    AnnualPortfolioCreationStep1copycopyComponent_694844_onChange = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
		KuikaAppManager.increaseServerRequestCount();

        let localVar = {
				Yearn_0: ReactSystemFunctions.convertToTypeByName(this.props.screenInputs.Year ?? this.props.screenInputs.year, "string"),
				RefNo_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "annualportfoliocreationstep1copycopy_694844_value", "value", "ListProductWithQty", "refNo", "refNo")), "string")
        }

		KuikaAppManager.showSpinner(this);
if (ReactSystemFunctions.isNotEmpty(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "annualportfoliocreationstep1copycopy_694844_value", "value", "ListProductWithQty", "refNo", "refNo")), ReactSystemFunctions.convertToTypeByName("True", "string"))) {
            		
        if (true) {
        KuikaAppManager.showSpinner(this);
        }
        let result = await KuikaAppManager.ApiRequest(this, "AnnualPortfolioCreationStep1copycopy/AnnualPortfolioCreationStep1copycopyComponent_694844_onChange", localVar)
        if (!KMainFunctions.IsResStatus2XX(result)) return true;

			stateVars.ListProductWithQty = result?.data.listProductWithQty;
			
			formVars.annualportfoliocreationstep1copycopy_694844_options = stateVars.ListProductWithQty;
			
			this.props.form?.setFieldsValue(formVars);
			
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.AnnualPortfolioCreationStep1copycopyComponent_694844_onChange1_();
                  resolve();
                });
          })

        } else {
            
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.AnnualPortfolioCreationStep1copycopyComponent_694844_onChange1_();
                  resolve();
                });
          })
        }


        
        KuikaAppManager.hideSpinner(this);
        return isErrorOccurred;
    }
    AnnualPortfolioCreationStep1copycopyComponent_694844_onChange1_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
		KuikaAppManager.increaseServerRequestCount();

        let localVar = {
				Yearn_0: ReactSystemFunctions.convertToTypeByName(this.props.screenInputs.Year ?? this.props.screenInputs.year, "string"),
				RefNo_0: ReactSystemFunctions.convertToTypeByName(null, "string")
        }

if (ReactSystemFunctions.isEmpty(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "annualportfoliocreationstep1copycopy_694844_value", "value", "ListProductWithQty", "refNo", "refNo")), ReactSystemFunctions.convertToTypeByName("True", "string"))) {
            		
        if (true) {
        KuikaAppManager.showSpinner(this);
        }
        let result = await KuikaAppManager.ApiRequest(this, "AnnualPortfolioCreationStep1copycopy/AnnualPortfolioCreationStep1copycopyComponent_694844_onChange1_", localVar)
        if (!KMainFunctions.IsResStatus2XX(result)) return true;

			stateVars.ListProductWithQty = result?.data.listProductWithQty;
			
			formVars.annualportfoliocreationstep1copycopy_694844_options = stateVars.ListProductWithQty;
			
			this.props.form?.setFieldsValue(formVars);
			
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.AnnualPortfolioCreationStep1copycopyComponent_694844_onChange2_();
                  resolve();
                });
          })

        } else {
            
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.AnnualPortfolioCreationStep1copycopyComponent_694844_onChange2_();
                  resolve();
                });
          })
        }


        
        KuikaAppManager.hideSpinner(this);
        return isErrorOccurred;
    }
		AnnualPortfolioCreationStep1copycopyComponent_694844_onChange2_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
if (ReactSystemFunctions.isNotEmpty(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "annualportfoliocreationstep1copycopy_694844_value", "value", "ListProductWithQty", "refNo", "refNo")), ReactSystemFunctions.convertToTypeByName("True", "string"))) {
            
				

		this.props.form?.setFieldsValue(formVars);
		
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.AnnualPortfolioCreationStep1copycopyComponent_694844_onChange3_();
                  resolve();
                });
          })

        } else {
            
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.AnnualPortfolioCreationStep1copycopyComponent_694844_onChange3_();
                  resolve();
                });
          })
        }

            
            return isErrorOccurred;
        }
		AnnualPortfolioCreationStep1copycopyComponent_694844_onChange3_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
if (ReactSystemFunctions.isNotEmpty(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "annualportfoliocreationstep1copycopy_694844_value", "value", "ListProductWithQty", "refNo", "refNo")), ReactSystemFunctions.convertToTypeByName("True", "string"))) {
            
				stateVars.dataSource_694844 = stateVars.ListProductWithQty ?? this.state.ListProductWithQty;

		this.props.form?.setFieldsValue(formVars);
		
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.AnnualPortfolioCreationStep1copycopyComponent_694844_onChange4_();
                  resolve();
                });
          })

        } else {
            
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.AnnualPortfolioCreationStep1copycopyComponent_694844_onChange4_();
                  resolve();
                });
          })
        }

            
            return isErrorOccurred;
        }
		AnnualPortfolioCreationStep1copycopyComponent_694844_onChange4_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
if (ReactSystemFunctions.isNotEmpty(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "annualportfoliocreationstep1copycopy_694844_value", "value", "ListProductWithQty", "refNo", "refNo")), ReactSystemFunctions.convertToTypeByName("True", "string"))) {
            
				stateVars.dataSource_694844 = stateVars.ListProductWithQty ?? this.state.ListProductWithQty;

		this.props.form?.setFieldsValue(formVars);
		
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.AnnualPortfolioCreationStep1copycopyComponent_694844_onChange5_();
                  resolve();
                });
          })

        } else {
            
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.AnnualPortfolioCreationStep1copycopyComponent_694844_onChange5_();
                  resolve();
                });
          })
        }

            
            return isErrorOccurred;
        }
		AnnualPortfolioCreationStep1copycopyComponent_694844_onChange5_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
if (ReactSystemFunctions.isNotEmpty(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "annualportfoliocreationstep1copycopy_694844_value", "value", "ListProductWithQty", "refNo", "refNo")), ReactSystemFunctions.convertToTypeByName("True", "string"))) {
            
				

		this.props.form?.setFieldsValue(formVars);
		
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.AnnualPortfolioCreationStep1copycopyComponent_694844_onChange6_();
                  resolve();
                });
          })

        } else {
            
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.AnnualPortfolioCreationStep1copycopyComponent_694844_onChange6_();
                  resolve();
                });
          })
        }

            
            return isErrorOccurred;
        }
		AnnualPortfolioCreationStep1copycopyComponent_694844_onChange6_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
if (ReactSystemFunctions.isNotEmpty(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "annualportfoliocreationstep1copycopy_694844_value", "value", "ListProductWithQty", "refNo", "refNo")), ReactSystemFunctions.convertToTypeByName("True", "string"))) {
            
				stateVars.dataSource_340793 = stateVars.ListProductWithQty ?? this.state.ListProductWithQty;

		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

        } else {
            KuikaAppManager.hideSpinner(this);
        }

            
            return isErrorOccurred;
        }










    AnnualPortfolioCreationStep1copycopyComponent_700137_onBlur = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
		KuikaAppManager.increaseServerRequestCount();

        let localVar = {
				Objective_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "Table_340793_objectiveTotalStock", "value", "", "", "")), "number"),
				NonObjective_0: ReactSystemFunctions.convertToTypeByName(null, "number"),
				RefNo_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, "annualportfoliocreationstep1copycopy_340793_value", "refNo"), "string"),
				Yearn_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, "annualportfoliocreationstep1copycopy_340793_value", "yearn"), "string")
        }

		KuikaAppManager.showSpinner(this);
		
        if (true) {
        KuikaAppManager.showSpinner(this);
        }
        let result = await KuikaAppManager.ApiRequest(this, "AnnualPortfolioCreationStep1copycopy/AnnualPortfolioCreationStep1copycopyComponent_700137_onBlur", localVar)
        if (!KMainFunctions.IsResStatus2XX(result)) return true;

			stateVars.TM_ProductAnnualUpdate = result?.data.tM_ProductAnnualUpdate;
			this.props.form?.setFieldsValue(formVars);
			
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.AnnualPortfolioCreationStep1copycopyComponent_700137_onBlur1_();
                  resolve();
                });
          })



        
        KuikaAppManager.hideSpinner(this);
        return isErrorOccurred;
    }
		AnnualPortfolioCreationStep1copycopyComponent_700137_onBlur1_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }

				await this.AnnualPortfolioCreationStep1copycopyPageInit();
				

		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

            
            return isErrorOccurred;
        }




    AnnualPortfolioCreationStep1copycopyComponent_100901_onBlur = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
		KuikaAppManager.increaseServerRequestCount();

        let localVar = {
				Objective_0: ReactSystemFunctions.convertToTypeByName(null, "number"),
				NonObjective_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "annualportfoliocreationstep1copycopy_100901_value", "value", "", "", "")), "number"),
				RefNo_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, "annualportfoliocreationstep1copycopy_340793_value", "refNo"), "string"),
				Yearn_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, "annualportfoliocreationstep1copycopy_340793_value", "yearn"), "string")
        }

		KuikaAppManager.showSpinner(this);
		
        if (true) {
        KuikaAppManager.showSpinner(this);
        }
        let result = await KuikaAppManager.ApiRequest(this, "AnnualPortfolioCreationStep1copycopy/AnnualPortfolioCreationStep1copycopyComponent_100901_onBlur", localVar)
        if (!KMainFunctions.IsResStatus2XX(result)) return true;

			stateVars.TM_ProductAnnualUpdate = result?.data.tM_ProductAnnualUpdate;
			this.props.form?.setFieldsValue(formVars);
			
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.AnnualPortfolioCreationStep1copycopyComponent_100901_onBlur1_();
                  resolve();
                });
          })



        
        KuikaAppManager.hideSpinner(this);
        return isErrorOccurred;
    }
		AnnualPortfolioCreationStep1copycopyComponent_100901_onBlur1_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }

				await this.AnnualPortfolioCreationStep1copycopyPageInit();
				

		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

            
            return isErrorOccurred;
        }






    async callCallbackFunction(diId: number, isFromMaster: boolean = false) {
        let isErrorOccurred = false;
		let pageInitCallerNavDiIDs = [] as number[];
		if (isFromMaster || pageInitCallerNavDiIDs.indexOf(diId) > -1) {
			await this.AnnualPortfolioCreationStep1copycopyPageInit();
		}

    }


}
