import React from "react";
import Axios, { AxiosResponse } from "axios";
import { KuikaAppManager } from "../../shared/utilty/kuika-app-manager";
import { ReactSystemFunctions } from "../../shared/utilty/react-system-functions";
import { KNavigator } from "../../shared/hoc/with-history";
import { KContext } from "../../shared/hoc/with-context";
import { useLocation } from "react-router-dom";
import { FormInstance } from "antd/es/form";
import { Guid } from "guid-typescript";
import Swal from "sweetalert2";
import { KMainFunctions } from "../../shared/utilty/main-functions";
import moment from "moment";
import { IValidationData } from "../../models/dto/validation-data";
import { IStripePayment } from "../../models/dto/stripe-payment";
import { IUserInfoDto } from "../../models/dto/user-info.dto";
import { UserService } from "../../services/user-service";
import { kuikaCoreWasmBridgeService } from "../../services/_singletons";
import _ from "lodash";
import mqtt, { MqttClient } from "mqtt";
import { IMqttResult } from "../../models/dto/mqtt.dto";


declare let window: any;

export interface IEntegrasyonHata_ScreenProps {
  navigator: KNavigator;
  form: FormInstance<any>;
  googleLogin: any;
  screenInputs: any;
  context: KContext;
  initialValues: any;
  children: any;
}

export interface IEntegrasyonHata_ScreenState {
    isSpinnerVisible: boolean;
    isPageVisible: boolean;
	isLeftMenuVisible: boolean;
    spinnerCount: number;
    selectedLanguage: string;
    isPageInitLoaded: false;
    isPageRecurringLoaded: false;

}

export class EntegrasyonHata_ScreenBase extends React.PureComponent<IEntegrasyonHata_ScreenProps, any> {

	entegrasyonhata_285876_value_kuikaAutoCompleteRef: React.RefObject<any>;
	entegrasyonhata_29458_value_kuikaAutoCompleteRef: React.RefObject<any>;
	entegrasyonhata_162268_value_kuikaAutoCompleteRef: React.RefObject<any>;
	entegrasyonhata_573115_value_kuikaSelectBoxRef: React.RefObject<any>;
	entegrasyonhata_178468_value_kuikaTableRef: React.RefObject<any>;
	entegrasyonhata_475501_value_kuikaPaginationRef: React.RefObject<any>;
	entegrasyonhata_379202_value_kuikaTableRef: React.RefObject<any>;
    ml=[{"Id":"d5a61d2b-bd60-485f-86e2-661e9ed4e486","Name":"en_US","ShortName":"English","IsDefault":true,"LanguagePhrases":[]},{"Id":"fec90414-4323-4cf8-9ee0-d4b6a1330372","Name":"FixedValues","ShortName":"FixedValues","LanguagePhrases":[{"Id":867868,"PropertyName":"value","Value":"Entegrasyon Hata Kuyruğu"},{"Id":535486,"PropertyName":"label","Value":"Yenile"},{"Id":996221,"PropertyName":"value","Value":"Nebim transfer ve kabul işlemlerindeki hataları görüntüleyin ve yeniden deneyin."},{"Id":594039,"PropertyName":"tab","Value":"Transfer Hataları 7"},{"Id":61187,"PropertyName":"placeholder","Value":"İşlem veya Fiş No"},{"Id":285876,"PropertyName":"placeholder","Value":"Hata Türü"},{"Id":29458,"PropertyName":"placeholder","Value":"Gönderen"},{"Id":162268,"PropertyName":"placeholder","Value":"Alıcı"},{"Id":573115,"PropertyName":"placeholder","Value":"Deneme Sayısı"},{"Id":688627,"PropertyName":"startDatePlaceholder","Value":"Başlangıç"},{"Id":688627,"PropertyName":"endDatePlaceholder","Value":"Bitiş"},{"Id":657296,"PropertyName":"label","Value":"Ara"},{"Id":787618,"PropertyName":"label","Value":"Temizle"},{"Id":481260,"PropertyName":"title","Value":"Hazırlık/İşlem No"},{"Id":153028,"PropertyName":"value","Value":"TRF-2024-10482"},{"Id":307834,"PropertyName":"title","Value":"Gönderen"},{"Id":111263,"PropertyName":"value","Value":"Nebim"},{"Id":583010,"PropertyName":"title","Value":"Alıcı"},{"Id":325864,"PropertyName":"value","Value":"ERP Merkezi"},{"Id":733177,"PropertyName":"title","Value":"Talep Sayısı"},{"Id":365500,"PropertyName":"value","Value":"18"},{"Id":176487,"PropertyName":"title","Value":"Ürün Adedi"},{"Id":18011,"PropertyName":"value","Value":"246"},{"Id":415980,"PropertyName":"title","Value":"Kargo Firması"},{"Id":29807,"PropertyName":"value","Value":"Yurtiçi Kargo"},{"Id":556136,"PropertyName":"title","Value":"Son Hata"},{"Id":939293,"PropertyName":"value","Value":"Nebim servisine ulaşılamadı"},{"Id":133164,"PropertyName":"title","Value":"Deneme Sayısı"},{"Id":164824,"PropertyName":"value","Value":"4"},{"Id":54492,"PropertyName":"title","Value":"Son Deneme"},{"Id":86931,"PropertyName":"value","Value":"18.06.2024 14:32"},{"Id":409116,"PropertyName":"title","Value":"Önem"},{"Id":621322,"PropertyName":"title","Value":"İşlemler"},{"Id":151587,"PropertyName":"label","Value":"Detay"},{"Id":656877,"PropertyName":"label","Value":"Tekrar Dene"},{"Id":772695,"PropertyName":"tab","Value":"Kabul Hataları 2"},{"Id":392955,"PropertyName":"title","Value":"Fiş No"},{"Id":786321,"PropertyName":"value","Value":"KBL-2024-2081"},{"Id":767007,"PropertyName":"title","Value":"Gönderen"},{"Id":113532,"PropertyName":"value","Value":"Merkez Depo"},{"Id":683653,"PropertyName":"title","Value":"Alıcı"},{"Id":377935,"PropertyName":"value","Value":"Nebim"},{"Id":588841,"PropertyName":"title","Value":"Kabul Özeti"},{"Id":78644,"PropertyName":"value","Value":"12 ürün bekliyor"},{"Id":492527,"PropertyName":"title","Value":"Son Hata"},{"Id":705301,"PropertyName":"value","Value":"Seri numarası doğrulanamadı"},{"Id":656874,"PropertyName":"title","Value":"Deneme Sayısı"},{"Id":378931,"PropertyName":"value","Value":"2"},{"Id":939633,"PropertyName":"title","Value":"Son Deneme"},{"Id":232647,"PropertyName":"value","Value":"18.06.2024 13:08"},{"Id":73527,"PropertyName":"title","Value":"Önem"},{"Id":749746,"PropertyName":"title","Value":"İşlemler"},{"Id":15900,"PropertyName":"label","Value":"Detay"},{"Id":702989,"PropertyName":"label","Value":"Tekrar Dene"},{"Id":112991,"PropertyName":"value","Value":"Entegrasyon İşlemini Yeniden Dene"},{"Id":474620,"PropertyName":"value","Value":"TRF-2024-10482 — Nebim servisine ulaşılamadı"},{"Id":364512,"PropertyName":"label","Value":"Vazgeç"},{"Id":397305,"PropertyName":"label","Value":"Tekrar Dene"}]}]
    defaultML = "en_US"
    
    screenHash = ""
    


    constructor(props) {
        super(props);
		this.entegrasyonhata_61187_value_kuikaTextInputRef = React.createRef();
		this.entegrasyonhata_285876_value_kuikaAutoCompleteRef = React.createRef();
		this.entegrasyonhata_29458_value_kuikaAutoCompleteRef = React.createRef();
		this.entegrasyonhata_162268_value_kuikaAutoCompleteRef = React.createRef();
		this.entegrasyonhata_573115_value_kuikaSelectBoxRef = React.createRef();
		this.entegrasyonhata_178468_value_kuikaTableRef = React.createRef();
		this.entegrasyonhata_475501_value_kuikaPaginationRef = React.createRef();
		this.entegrasyonhata_379202_value_kuikaTableRef = React.createRef();

        this.state = {
            isSpinnerVisible: false,
            isPageVisible: false,
            isLeftMenuVisible: false,
            spinnerCount: 0,
            selectedLanguage: "",
            isPageInitLoaded: false,
            isPageRecurringLoaded: false,
            	        dataSource_285876: [{"key":"service","text":"Servis hatası"},{"key":"validation","text":"Doğrulama hatası"},{"key":"timeout","text":"Zaman aşımı"}],
	        dataSource_29458: [{"key":"nebim","text":"Nebim"},{"key":"depo","text":"Merkez Depo"}],
	        dataSource_162268: [{"key":"erp","text":"ERP Merkezi"},{"key":"magaza","text":"Mağaza Ağı"}],
	        dataSource_573115: [{"key":"1-2","text":"1-2"},{"key":"3-plus","text":"3 ve üzeri"}],

        }

        this.state.isPageVisible = true;
        
    }

    async componentDidMount() {

        if (KuikaAppManager.isPageInitPrevented()) {
            KuikaAppManager.calculateAndSetBodyHeight("entegrasyonhata", "");
            return;
        }
        
        
        ReactSystemFunctions.validateToken()
        this.fillFormInitValues();
        if (true){
            
        }
        
        
        
        KuikaAppManager.calculateAndSetBodyHeight("entegrasyonhata", "");

        if (ReactSystemFunctions.getIsMicroApp() === false) {
           window.parentScreen = this;
        }
    }

    componentWillUnmount() {
        
        
        

        if (ReactSystemFunctions.getIsMicroApp() === false) {
           window.parentScreen = null;
        }
    }

    

        
    componentDidUpdate= async (prevProps, prevState) => {
		KuikaAppManager.calculateAndSetBodyHeight("entegrasyonhata", ""    );
        if (prevProps?.location?.search !== (this.props as any)?.location?.search) {
			
		}

        

        if (ReactSystemFunctions.getIsMicroApp() === false) {
            for (const key in prevState) {
                if (key.startsWith('NavVisible') && prevState[key] === true && this.state[key] === false) {
                    window.parentScreen = this;
                    break;
                }
            }
        }
	}

    fillFormInitValues() {
        this.props.form?.setFieldsValue({
});

    }

      setPageInitLoaded = (value: boolean) => {
        this.setState({ isPageInitLoaded: value });
      }

      setPageRecurringLoaded = (value: boolean) => {
        this.setState({ isPageRecurringLoaded: value });
      }

      clearFieldValidation = (changedValues: any) => {
        const fieldName = Object.keys(changedValues)[0];
        if (fieldName) {
          this.props.form?.setFields([
            {
              name: fieldName,
              errors: []
            }
          ]);
        }
      };

        checkTabErrors = () => {
    document.querySelectorAll(".rc-tabs-tab").forEach((tab) => {
      (tab as HTMLElement).style.color = "";
    });

    const tabPanes = document.querySelectorAll(".rc-tabs-tabpane");
    const tabs = document.querySelectorAll(".rc-tabs-tab");

    tabPanes.forEach((tabPane, index) => {
      const uniquePaneId = `rc-tabs-tabpane-${index}`;
      if (!tabPane.hasAttribute("id")) {
        tabPane.setAttribute("id", uniquePaneId); 
      }

      const uniqueTabId = `rc-tabs-tab-${index}`;
      if (tabs[index]) {
        if (!tabs[index].hasAttribute("id")) {
          tabs[index].setAttribute("id", uniqueTabId); 
        }
        tabs[index].setAttribute("aria-controls", uniquePaneId);
      }
    });

    const errorElements = document.querySelectorAll(".rc-tabs .ant-form-item-explain-error");

    const tabsWithErrors = new Set<string>();

    errorElements.forEach((errorElement) => {
      const tabPane = errorElement.closest(".rc-tabs-tabpane");
      if (tabPane && tabPane.id) {
        tabsWithErrors.add(tabPane.id);
      }
    });

    tabsWithErrors.forEach((tabPaneId) => {
      const tab = document.querySelector(`.rc-tabs-tab[aria-controls="${tabPaneId}"]`);
      if (tab) {
        (tab as HTMLElement).style.color = "red"; 
      }
    });
  };




    async callCallbackFunction(diId: number, isFromMaster: boolean = false) {
        let isErrorOccurred = false;

    }


}
