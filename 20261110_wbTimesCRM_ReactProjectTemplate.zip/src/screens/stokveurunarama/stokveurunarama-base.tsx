import React from "react";
import Axios, { AxiosResponse } from "axios";
import { KuikaAppManager } from "../../shared/utilty/kuika-app-manager";
import { ReactSystemFunctions } from "../../shared/utilty/react-system-functions";
import { KNavigator } from "../../shared/hoc/with-history";
import { KContext } from "../../shared/hoc/with-context";
import { useLocation } from "react-router-dom";
import { FormInstance } from "antd/es/form";
import { Guid } from "guid-typescript";
import Swal from "sweetalert2";
import { KMainFunctions } from "../../shared/utilty/main-functions";
import moment from "moment";
import { IValidationData } from "../../models/dto/validation-data";
import { IStripePayment } from "../../models/dto/stripe-payment";
import { IUserInfoDto } from "../../models/dto/user-info.dto";
import { UserService } from "../../services/user-service";
import { kuikaCoreWasmBridgeService } from "../../services/_singletons";
import _ from "lodash";
import mqtt, { MqttClient } from "mqtt";
import { IMqttResult } from "../../models/dto/mqtt.dto";
import { MasterScreen_ScreenContext } from "../masterscreen/masterscreen-context";

declare let window: any;

export interface IStokVeUrunArama_ScreenProps {
  navigator: KNavigator;
  form: FormInstance<any>;
  googleLogin: any;
  screenInputs: any;
  context: KContext;
  initialValues: any;
  children: any;
}

export interface IStokVeUrunArama_ScreenState {
    isSpinnerVisible: boolean;
    isPageVisible: boolean;
	isLeftMenuVisible: boolean;
    spinnerCount: number;
    selectedLanguage: string;
    isPageInitLoaded: false;
    isPageRecurringLoaded: false;

}

export class StokVeUrunArama_ScreenBase extends React.PureComponent<IStokVeUrunArama_ScreenProps, any> {
    static contextType = MasterScreen_ScreenContext;
    declare context: React.ContextType<typeof MasterScreen_ScreenContext>;
	stokveurunarama_662916_value_kuikaAutoCompleteRef: React.RefObject<any>;
	stokveurunarama_964207_value_kuikaAutoCompleteRef: React.RefObject<any>;
	stokveurunarama_34427_value_kuikaAutoCompleteRef: React.RefObject<any>;
	stokveurunarama_881131_value_kuikaTableRef: React.RefObject<any>;
	stokveurunarama_236401_value_kuikaPaginationRef: React.RefObject<any>;
    ml=[{"Id":"d5a61d2b-bd60-485f-86e2-661e9ed4e486","Name":"en_US","ShortName":"English","IsDefault":true,"LanguagePhrases":[]},{"Id":"2c80f054-d533-4b75-8e65-e67483eac0de","Name":"FixedValues","ShortName":"FixedValues","LanguagePhrases":[{"Id":275657,"PropertyName":"value","Value":"Stok ve Ürün Arama"},{"Id":84731,"PropertyName":"value","Value":"Ürünlerin mağazalardaki güncel stok ve müsaitlik durumlarını karşılaştırın."},{"Id":560076,"PropertyName":"label","Value":"Merkeze Talep Aç"},{"Id":248563,"PropertyName":"placeholder","Value":"Ürün Kodu veya Ürün Adı"},{"Id":662916,"PropertyName":"placeholder","Value":"Marka"},{"Id":964207,"PropertyName":"placeholder","Value":"Kategori"},{"Id":34427,"PropertyName":"placeholder","Value":"Mağaza"},{"Id":540560,"PropertyName":"value","Value":"Yalnız Müsait Stoğu Olanlar"},{"Id":337524,"PropertyName":"label","Value":"Ara"},{"Id":789193,"PropertyName":"label","Value":"Temizle"},{"Id":716433,"PropertyName":"value","Value":"Son stok güncelleme: 06.08.2026 16:30"},{"Id":71343,"PropertyName":"value","Value":"Stok kolonları: Adana Times · Gaziantep Times · Mersin Times · İstanbul Times"},{"Id":852909,"PropertyName":"title","Value":"Ürün Kodu"},{"Id":884180,"PropertyName":"value","Value":"126711"},{"Id":73014,"PropertyName":"title","Value":"Ürün Adı"},{"Id":404971,"PropertyName":"value","Value":"Rolex Submariner Date"},{"Id":835449,"PropertyName":"title","Value":"Marka"},{"Id":22020,"PropertyName":"value","Value":"Rolex"},{"Id":899251,"PropertyName":"title","Value":"Kategori"},{"Id":23422,"PropertyName":"value","Value":"Saat"},{"Id":938073,"PropertyName":"title","Value":"Adana Times"},{"Id":443191,"PropertyName":"value","Value":"Kendi Mağazam"},{"Id":83947,"PropertyName":"value","Value":"4"},{"Id":693362,"PropertyName":"title","Value":"Gaziantep Times"},{"Id":332494,"PropertyName":"value","Value":"1"},{"Id":827769,"PropertyName":"title","Value":"Mersin Times"},{"Id":357202,"PropertyName":"value","Value":"2"},{"Id":20035,"PropertyName":"title","Value":"Antalya Times"},{"Id":172620,"PropertyName":"value","Value":"0"},{"Id":329963,"PropertyName":"title","Value":"Toplam Mağaza Stoğu"},{"Id":824383,"PropertyName":"value","Value":"7"},{"Id":221458,"PropertyName":"title","Value":"Son Güncelleme"},{"Id":518236,"PropertyName":"value","Value":"06.08.2026 16:28"},{"Id":372759,"PropertyName":"title","Value":"İşlemler"},{"Id":550561,"PropertyName":"label","Value":"Ürün Detayı"},{"Id":333202,"PropertyName":"value","Value":"48 kayıttan 1–25 arası gösteriliyor"}]}]
    defaultML = "en_US"
    
    screenHash = ""
    

    private _prevMasterPageInitLoaded: boolean = false;
    private _prevMasterPageRecurringLoaded: boolean = false;
    private _prevShouldTriggerPageInit: boolean = false;
    constructor(props) {
        super(props);
		this.stokveurunarama_248563_value_kuikaTextInputRef = React.createRef();
		this.stokveurunarama_662916_value_kuikaAutoCompleteRef = React.createRef();
		this.stokveurunarama_964207_value_kuikaAutoCompleteRef = React.createRef();
		this.stokveurunarama_34427_value_kuikaAutoCompleteRef = React.createRef();
		this.stokveurunarama_881131_value_kuikaTableRef = React.createRef();
		this.stokveurunarama_236401_value_kuikaPaginationRef = React.createRef();

        this.state = {
            isSpinnerVisible: false,
            isPageVisible: false,
            isLeftMenuVisible: false,
            spinnerCount: 0,
            selectedLanguage: "",
            isPageInitLoaded: false,
            isPageRecurringLoaded: false,
            	        dataSource_662916: [{"key":"rolex","text":"Rolex"},{"key":"tudor","text":"Tudor"},{"key":"omega","text":"Omega"}],
	        dataSource_964207: [{"key":"saat","text":"Saat"},{"key":"aksesuar","text":"Aksesuar"},{"key":"takı","text":"Takı"}],
	        dataSource_34427: [{"key":"adana","text":"Adana Times"},{"key":"gaziantep","text":"Gaziantep Times"},{"key":"mersin","text":"Mersin Times"},{"key":"istanbul","text":"İstanbul Times"}],

        }

        this.state.isPageVisible = true;
        
    }

    async componentDidMount() {

        if (KuikaAppManager.isPageInitPrevented()) {
            KuikaAppManager.calculateAndSetBodyHeight("stokveurunarama", "masterscreen_screen");
            return;
        }
        this.context.registerCallbackFunction(this.callCallbackFunction.bind(this));
        
        ReactSystemFunctions.validateToken()
        this.fillFormInitValues();
        if (false){
            
        }
        
        
        
        KuikaAppManager.calculateAndSetBodyHeight("stokveurunarama", "masterscreen_screen");

        if (ReactSystemFunctions.getIsMicroApp() === false) {
           window.parentScreen = this;
        }
    }

    componentWillUnmount() {
        
        
        

        if (ReactSystemFunctions.getIsMicroApp() === false) {
           window.parentScreen = null;
        }
    }

    

        
    componentDidUpdate= async (prevProps, prevState) => {
		KuikaAppManager.calculateAndSetBodyHeight("stokveurunarama", "masterscreen_screen"    );
        if (prevProps?.location?.search !== (this.props as any)?.location?.search) {
			
		}

        

        if (ReactSystemFunctions.getIsMicroApp() === false) {
            for (const key in prevState) {
                if (key.startsWith('NavVisible') && prevState[key] === true && this.state[key] === false) {
                    window.parentScreen = this;
                    break;
                }
            }
        }
	}

    fillFormInitValues() {
        this.props.form?.setFieldsValue({
});

    }

      setPageInitLoaded = (value: boolean) => {
        this.setState({ isPageInitLoaded: value });
      }

      setPageRecurringLoaded = (value: boolean) => {
        this.setState({ isPageRecurringLoaded: value });
      }

      clearFieldValidation = (changedValues: any) => {
        const fieldName = Object.keys(changedValues)[0];
        if (fieldName) {
          this.props.form?.setFields([
            {
              name: fieldName,
              errors: []
            }
          ]);
        }
      };

      




    async callCallbackFunction(diId: number, isFromMaster: boolean = false) {
        let isErrorOccurred = false;

    }


}
