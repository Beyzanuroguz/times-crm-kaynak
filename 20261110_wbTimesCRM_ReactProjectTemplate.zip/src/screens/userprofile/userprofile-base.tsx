import React from "react";
import Axios, { AxiosResponse } from "axios";
import { KuikaAppManager } from "../../shared/utilty/kuika-app-manager";
import { ReactSystemFunctions } from "../../shared/utilty/react-system-functions";
import { KNavigator } from "../../shared/hoc/with-history";
import { KContext } from "../../shared/hoc/with-context";
import { useLocation } from "react-router-dom";
import { FormInstance } from "antd/es/form";
import { Guid } from "guid-typescript";
import Swal from "sweetalert2";
import { KMainFunctions } from "../../shared/utilty/main-functions";
import moment from "moment";
import { IValidationData } from "../../models/dto/validation-data";
import { IStripePayment } from "../../models/dto/stripe-payment";
import { IUserInfoDto } from "../../models/dto/user-info.dto";
import { UserService } from "../../services/user-service";
import { kuikaCoreWasmBridgeService } from "../../services/_singletons";
import _ from "lodash";
import mqtt, { MqttClient } from "mqtt";
import { IMqttResult } from "../../models/dto/mqtt.dto";
import { MasterScreen_ScreenContext } from "../masterscreen/masterscreen-context";

declare let window: any;

export interface IUserProfile_ScreenProps {
  navigator: KNavigator;
  form: FormInstance<any>;
  googleLogin: any;
  screenInputs: any;
  context: KContext;
  initialValues: any;
  children: any;
}

export interface IUserProfile_ScreenState {
    isSpinnerVisible: boolean;
    isPageVisible: boolean;
	isLeftMenuVisible: boolean;
    spinnerCount: number;
    selectedLanguage: string;
    isPageInitLoaded: false;
    isPageRecurringLoaded: false;
	TM_GetRoleUserById: any[];
	TM_GetRoleUserById_dummy: any[];
	TM_UserRoleByUserId: any[];
	TM_UserRoleByUserId_dummy: any[];
	GoBack: any;
	GoBack_dummy: any;
	isComp157195Visible: 'visible' | 'hidden';
	isComp495529Visible: 'visible' | 'hidden';
	isComp969199Visible: 'visible' | 'hidden';
	isComp320119Visible: 'visible' | 'hidden';
	isComp230302Visible: 'visible' | 'hidden';
	isComp218744Enabled: 'enabled' | 'disabled';
	isComp115721Enabled: 'enabled' | 'disabled';
	isComp66935Enabled: 'enabled' | 'disabled';
	isComp84340Enabled: 'enabled' | 'disabled';
	isComp867661Enabled: 'enabled' | 'disabled';

}

export class UserProfile_ScreenBase extends React.PureComponent<IUserProfile_ScreenProps, any> {
    static contextType = MasterScreen_ScreenContext;
    declare context: React.ContextType<typeof MasterScreen_ScreenContext>;

    ml=[{"Id":"d5a61d2b-bd60-485f-86e2-661e9ed4e486","Name":"en_US","ShortName":"English","IsDefault":true,"LanguagePhrases":[]},{"Id":"751242e5-cc8d-4d19-8bfb-c7119fca9cf8","Name":"FixedValues","ShortName":"FixedValues","LanguagePhrases":[{"Id":369667,"PropertyName":"value","Value":"Genel Bilgiler"},{"Id":157195,"PropertyName":"value","Value":"Aktif"},{"Id":495529,"PropertyName":"value","Value":"Pasif"},{"Id":840014,"PropertyName":"value","Value":"Çalışan Kodu"},{"Id":218744,"PropertyName":"placeholder","Value":"Type here..."},{"Id":201225,"PropertyName":"value","Value":"Ad-Soyad"},{"Id":115721,"PropertyName":"placeholder","Value":"Type here..."},{"Id":595047,"PropertyName":"value","Value":"Kullanıcı Adı"},{"Id":66935,"PropertyName":"placeholder","Value":"Type here..."},{"Id":594324,"PropertyName":"value","Value":"Ofis Kodu"},{"Id":84340,"PropertyName":"placeholder","Value":"Type here..."},{"Id":950441,"PropertyName":"value","Value":"Ofis Adı"},{"Id":867661,"PropertyName":"placeholder","Value":"Type here..."}]}]
    defaultML = "en_US"
    
    screenHash = ""
    

    private _prevMasterPageInitLoaded: boolean = false;
    private _prevMasterPageRecurringLoaded: boolean = false;
    private _prevShouldTriggerPageInit: boolean = false;
    constructor(props) {
        super(props);
		this.userprofile_218744_value_kuikaTextInputRef = React.createRef();
		this.userprofile_115721_value_kuikaTextInputRef = React.createRef();
		this.userprofile_66935_value_kuikaTextInputRef = React.createRef();
		this.userprofile_84340_value_kuikaTextInputRef = React.createRef();
		this.userprofile_867661_value_kuikaTextInputRef = React.createRef();

        this.state = {
            isSpinnerVisible: false,
            isPageVisible: false,
            isLeftMenuVisible: false,
            spinnerCount: 0,
            selectedLanguage: "",
            isPageInitLoaded: false,
            isPageRecurringLoaded: false,
            	        TM_GetRoleUserById: [],
	        TM_UserRoleByUserId: [],
	        GoBack: "",
	        isComp157195Visible: 'hidden',
	        isComp495529Visible: 'hidden',
	        isComp969199Visible: 'hidden',
	        isComp320119Visible: 'hidden',
	        isComp230302Visible: 'hidden',
	        isComp218744Enabled: 'disabled',
	        isComp115721Enabled: 'disabled',
	        isComp66935Enabled: 'disabled',
	        isComp84340Enabled: 'disabled',
	        isComp867661Enabled: 'disabled',

        }

        this.state.isPageVisible = true;
        
    }

    async componentDidMount() {

        if (KuikaAppManager.isPageInitPrevented()) {
            KuikaAppManager.calculateAndSetBodyHeight("userprofile", "masterscreen_screen");
            return;
        }
        this.context.registerCallbackFunction(this.callCallbackFunction.bind(this));
        
        ReactSystemFunctions.validateToken()
        this.fillFormInitValues();
        if (false){
            await this.UserProfilePageInit();
        } else if (this.context?.isMasterPageInitLoaded) { this._prevMasterPageInitLoaded = true; await this.UserProfilePageInit(); }
        
        
        
        KuikaAppManager.calculateAndSetBodyHeight("userprofile", "masterscreen_screen");

        if (ReactSystemFunctions.getIsMicroApp() === false) {
           window.parentScreen = this;
        }
    }

    componentWillUnmount() {
        
        
        

        if (ReactSystemFunctions.getIsMicroApp() === false) {
           window.parentScreen = null;
        }
    }

    

        
    componentDidUpdate= async (prevProps, prevState) => {
		KuikaAppManager.calculateAndSetBodyHeight("userprofile", "masterscreen_screen"    );
        if (prevProps?.location?.search !== (this.props as any)?.location?.search) {
			await this.UserProfilePageInit();
		}

        		if (this._prevMasterPageInitLoaded !== this.context.isMasterPageInitLoaded && this.context.isMasterPageInitLoaded === true) {this._prevMasterPageInitLoaded = this.context.isMasterPageInitLoaded;await this.UserProfilePageInit()}


        if (ReactSystemFunctions.getIsMicroApp() === false) {
            for (const key in prevState) {
                if (key.startsWith('NavVisible') && prevState[key] === true && this.state[key] === false) {
                    window.parentScreen = this;
                    break;
                }
            }
        }
	}

    fillFormInitValues() {
        this.props.form?.setFieldsValue({
});

    }

      setPageInitLoaded = (value: boolean) => {
        this.setState({ isPageInitLoaded: value });
      }

      setPageRecurringLoaded = (value: boolean) => {
        this.setState({ isPageRecurringLoaded: value });
      }

      clearFieldValidation = (changedValues: any) => {
        const fieldName = Object.keys(changedValues)[0];
        if (fieldName) {
          this.props.form?.setFields([
            {
              name: fieldName,
              errors: []
            }
          ]);
        }
      };

      

    UserProfilePageInit = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


	if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }

        let localVar = {
			Id_0: ReactSystemFunctions.convertToTypeByName(this.props.screenInputs.UserID ?? this.props.screenInputs.userid, "Guid"),
			UserID_1: ReactSystemFunctions.convertToTypeByName(this.props.screenInputs.UserID ?? this.props.screenInputs.userid, "Guid")
        }

	KuikaAppManager.showSpinner(this);
	
        if (true) {
        KuikaAppManager.showSpinner(this);
        }
        let result = await KuikaAppManager.ApiRequest(this, "UserProfile/UserProfilePageInit", localVar)
        if (!KMainFunctions.IsResStatus2XX(result)) return true;

		stateVars.TM_GetRoleUserById = result?.data.tM_GetRoleUserById;
		formVars.userprofile_218744_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetRoleUserById !== undefined ? (stateVars.TM_GetRoleUserById?.length > 0 ? stateVars.TM_GetRoleUserById[0].salesPersonCode : null) : (this.state.TM_GetRoleUserById?.length > 0 ? this.state.TM_GetRoleUserById[0].salesPersonCode : null)));
		formVars.userprofile_115721_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetRoleUserById !== undefined ? (stateVars.TM_GetRoleUserById?.length > 0 ? stateVars.TM_GetRoleUserById[0].fullName : null) : (this.state.TM_GetRoleUserById?.length > 0 ? this.state.TM_GetRoleUserById[0].fullName : null)));
		formVars.userprofile_66935_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetRoleUserById !== undefined ? (stateVars.TM_GetRoleUserById?.length > 0 ? stateVars.TM_GetRoleUserById[0].userName : null) : (this.state.TM_GetRoleUserById?.length > 0 ? this.state.TM_GetRoleUserById[0].userName : null)));
		formVars.userprofile_84340_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetRoleUserById !== undefined ? (stateVars.TM_GetRoleUserById?.length > 0 ? stateVars.TM_GetRoleUserById[0].officeCode : null) : (this.state.TM_GetRoleUserById?.length > 0 ? this.state.TM_GetRoleUserById[0].officeCode : null)));
		formVars.userprofile_867661_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetRoleUserById !== undefined ? (stateVars.TM_GetRoleUserById?.length > 0 ? stateVars.TM_GetRoleUserById[0].officeDescription : null) : (this.state.TM_GetRoleUserById?.length > 0 ? this.state.TM_GetRoleUserById[0].officeDescription : null)));
		stateVars.isComp157195Visible = ((ReactSystemFunctions.isNotEqualTo(ReactSystemFunctions.toString(this, (stateVars.TM_GetRoleUserById !== undefined ? (stateVars.TM_GetRoleUserById?.length > 0 ? stateVars.TM_GetRoleUserById[0].roleName : null) : (this.state.TM_GetRoleUserById?.length > 0 ? this.state.TM_GetRoleUserById[0].roleName : null))), ReactSystemFunctions.convertToTypeByName("Rol Yok", "string"))) === true ? "visible" : "hidden")
		stateVars.isComp495529Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.toString(this, (stateVars.TM_GetRoleUserById !== undefined ? (stateVars.TM_GetRoleUserById?.length > 0 ? stateVars.TM_GetRoleUserById[0].roleName : null) : (this.state.TM_GetRoleUserById?.length > 0 ? this.state.TM_GetRoleUserById[0].roleName : null))), ReactSystemFunctions.convertToTypeByName("Rol Yok", "string"))) === true ? "visible" : "hidden")
		stateVars.isComp969199Visible = ((ReactSystemFunctions.isNotEmpty(ReactSystemFunctions.toString(this, (stateVars.TM_GetRoleUserById !== undefined ? (stateVars.TM_GetRoleUserById?.length > 0 ? stateVars.TM_GetRoleUserById[0].storeDescription : null) : (this.state.TM_GetRoleUserById?.length > 0 ? this.state.TM_GetRoleUserById[0].storeDescription : null))), ReactSystemFunctions.convertToTypeByName("True", "string"))) === true ? "visible" : "hidden")
		stateVars.isComp320119Visible = ((ReactSystemFunctions.isNotEmpty(ReactSystemFunctions.toString(this, (stateVars.TM_GetRoleUserById !== undefined ? (stateVars.TM_GetRoleUserById?.length > 0 ? stateVars.TM_GetRoleUserById[0].storeDescription : null) : (this.state.TM_GetRoleUserById?.length > 0 ? this.state.TM_GetRoleUserById[0].storeDescription : null))), ReactSystemFunctions.convertToTypeByName("True", "string"))) === true ? "visible" : "hidden")
		stateVars.isComp230302Visible = ((ReactSystemFunctions.isNotEmpty(ReactSystemFunctions.toString(this, (stateVars.TM_GetRoleUserById !== undefined ? (stateVars.TM_GetRoleUserById?.length > 0 ? stateVars.TM_GetRoleUserById[0].storeDescription : null) : (this.state.TM_GetRoleUserById?.length > 0 ? this.state.TM_GetRoleUserById[0].storeDescription : null))), ReactSystemFunctions.convertToTypeByName("True", "string"))) === true ? "visible" : "hidden")
		stateVars.TM_UserRoleByUserId = result?.data.tM_UserRoleByUserId;
		formVars.userprofile_646297_value = ReactSystemFunctions.toString(this, (stateVars.TM_UserRoleByUserId !== undefined ? (stateVars.TM_UserRoleByUserId?.length > 0 ? stateVars.TM_UserRoleByUserId[0].roleNames : null) : (this.state.TM_UserRoleByUserId?.length > 0 ? this.state.TM_UserRoleByUserId[0].roleNames : null)));
		this.props.form?.setFieldsValue(formVars);
		
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.UserProfilePageInit1_();
                  resolve();
                });
          })



        
        KuikaAppManager.hideSpinner(this);
        return isErrorOccurred;
    }
	UserProfilePageInit1_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


	if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }

			stateVars.isComp157195Visible = ((ReactSystemFunctions.isNotEqualTo(ReactSystemFunctions.toString(this, (stateVars.TM_GetRoleUserById !== undefined ? (stateVars.TM_GetRoleUserById?.length > 0 ? stateVars.TM_GetRoleUserById[0].roleName : null) : (this.state.TM_GetRoleUserById?.length > 0 ? this.state.TM_GetRoleUserById[0].roleName : null))), ReactSystemFunctions.convertToTypeByName("Rol Yok", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp495529Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.toString(this, (stateVars.TM_GetRoleUserById !== undefined ? (stateVars.TM_GetRoleUserById?.length > 0 ? stateVars.TM_GetRoleUserById[0].roleName : null) : (this.state.TM_GetRoleUserById?.length > 0 ? this.state.TM_GetRoleUserById[0].roleName : null))), ReactSystemFunctions.convertToTypeByName("Rol Yok", "string"))) === true ? "visible" : "hidden")
			formVars.userprofile_646297_value = ReactSystemFunctions.toString(this, (stateVars.TM_UserRoleByUserId !== undefined ? (stateVars.TM_UserRoleByUserId?.length > 0 ? stateVars.TM_UserRoleByUserId[0].roleNames : null) : (this.state.TM_UserRoleByUserId?.length > 0 ? this.state.TM_UserRoleByUserId[0].roleNames : null)));

			stateVars.isComp969199Visible = ((ReactSystemFunctions.isNotEmpty(ReactSystemFunctions.toString(this, (stateVars.TM_GetRoleUserById !== undefined ? (stateVars.TM_GetRoleUserById?.length > 0 ? stateVars.TM_GetRoleUserById[0].storeDescription : null) : (this.state.TM_GetRoleUserById?.length > 0 ? this.state.TM_GetRoleUserById[0].storeDescription : null))), ReactSystemFunctions.convertToTypeByName("True", "string"))) === true ? "visible" : "hidden")
			formVars.userprofile_218744_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetRoleUserById !== undefined ? (stateVars.TM_GetRoleUserById?.length > 0 ? stateVars.TM_GetRoleUserById[0].salesPersonCode : null) : (this.state.TM_GetRoleUserById?.length > 0 ? this.state.TM_GetRoleUserById[0].salesPersonCode : null)));

			formVars.userprofile_115721_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetRoleUserById !== undefined ? (stateVars.TM_GetRoleUserById?.length > 0 ? stateVars.TM_GetRoleUserById[0].fullName : null) : (this.state.TM_GetRoleUserById?.length > 0 ? this.state.TM_GetRoleUserById[0].fullName : null)));

			formVars.userprofile_66935_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetRoleUserById !== undefined ? (stateVars.TM_GetRoleUserById?.length > 0 ? stateVars.TM_GetRoleUserById[0].userName : null) : (this.state.TM_GetRoleUserById?.length > 0 ? this.state.TM_GetRoleUserById[0].userName : null)));

			stateVars.isComp320119Visible = ((ReactSystemFunctions.isNotEmpty(ReactSystemFunctions.toString(this, (stateVars.TM_GetRoleUserById !== undefined ? (stateVars.TM_GetRoleUserById?.length > 0 ? stateVars.TM_GetRoleUserById[0].storeDescription : null) : (this.state.TM_GetRoleUserById?.length > 0 ? this.state.TM_GetRoleUserById[0].storeDescription : null))), ReactSystemFunctions.convertToTypeByName("True", "string"))) === true ? "visible" : "hidden")
			formVars.userprofile_84340_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetRoleUserById !== undefined ? (stateVars.TM_GetRoleUserById?.length > 0 ? stateVars.TM_GetRoleUserById[0].officeCode : null) : (this.state.TM_GetRoleUserById?.length > 0 ? this.state.TM_GetRoleUserById[0].officeCode : null)));

			stateVars.isComp230302Visible = ((ReactSystemFunctions.isNotEmpty(ReactSystemFunctions.toString(this, (stateVars.TM_GetRoleUserById !== undefined ? (stateVars.TM_GetRoleUserById?.length > 0 ? stateVars.TM_GetRoleUserById[0].storeDescription : null) : (this.state.TM_GetRoleUserById?.length > 0 ? this.state.TM_GetRoleUserById[0].storeDescription : null))), ReactSystemFunctions.convertToTypeByName("True", "string"))) === true ? "visible" : "hidden")
			formVars.userprofile_867661_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetRoleUserById !== undefined ? (stateVars.TM_GetRoleUserById?.length > 0 ? stateVars.TM_GetRoleUserById[0].officeDescription : null) : (this.state.TM_GetRoleUserById?.length > 0 ? this.state.TM_GetRoleUserById[0].officeDescription : null)));


	this.props.form?.setFieldsValue(formVars);
	this.setState(stateVars);
	KuikaAppManager.hideSpinner(this);

            this.setPageInitLoaded(true);
            return isErrorOccurred;
        }




		UserProfileComponent_420149_onClick = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
KuikaAppManager.showSpinner(this);

				stateVars.GoBack = await ReactSystemFunctions.goBack(this, false);

		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

            
            return isErrorOccurred;
        }




    async callCallbackFunction(diId: number, isFromMaster: boolean = false) {
        let isErrorOccurred = false;
		let pageInitCallerNavDiIDs = [] as number[];
		if (isFromMaster || pageInitCallerNavDiIDs.indexOf(diId) > -1) {
			await this.UserProfilePageInit();
		}

    }


}
