import React from "react";
import Axios, { AxiosResponse } from "axios";
import { KuikaAppManager } from "../../shared/utilty/kuika-app-manager";
import { ReactSystemFunctions } from "../../shared/utilty/react-system-functions";
import { KNavigator } from "../../shared/hoc/with-history";
import { KContext } from "../../shared/hoc/with-context";
import { useLocation } from "react-router-dom";
import { FormInstance } from "antd/es/form";
import { Guid } from "guid-typescript";
import Swal from "sweetalert2";
import { KMainFunctions } from "../../shared/utilty/main-functions";
import moment from "moment";
import { IValidationData } from "../../models/dto/validation-data";
import { IStripePayment } from "../../models/dto/stripe-payment";
import { IUserInfoDto } from "../../models/dto/user-info.dto";
import { UserService } from "../../services/user-service";
import { kuikaCoreWasmBridgeService } from "../../services/_singletons";
import _ from "lodash";
import mqtt, { MqttClient } from "mqtt";
import { IMqttResult } from "../../models/dto/mqtt.dto";
import { MasterScreen_ScreenContext } from "../masterscreen/masterscreen-context";

declare let window: any;

export interface ITransferBekleyenHavuzu_ScreenProps {
  navigator: KNavigator;
  form: FormInstance<any>;
  googleLogin: any;
  screenInputs: any;
  context: KContext;
  initialValues: any;
  children: any;
}

export interface ITransferBekleyenHavuzu_ScreenState {
    isSpinnerVisible: boolean;
    isPageVisible: boolean;
	isLeftMenuVisible: boolean;
    spinnerCount: number;
    selectedLanguage: string;
    isPageInitLoaded: false;
    isPageRecurringLoaded: false;

}

export class TransferBekleyenHavuzu_ScreenBase extends React.PureComponent<ITransferBekleyenHavuzu_ScreenProps, any> {
    static contextType = MasterScreen_ScreenContext;
    declare context: React.ContextType<typeof MasterScreen_ScreenContext>;
	transferbekleyenhavuzu_113664_value_kuikaAutoCompleteRef: React.RefObject<any>;
	transferbekleyenhavuzu_819096_value_kuikaAutoCompleteRef: React.RefObject<any>;
	transferbekleyenhavuzu_117999_value_kuikaTableRef: React.RefObject<any>;
    ml=[{"Id":"d5a61d2b-bd60-485f-86e2-661e9ed4e486","Name":"en_US","ShortName":"English","IsDefault":true,"LanguagePhrases":[]},{"Id":"49c9d061-4e7c-43dc-8e8a-48b75340ed58","Name":"FixedValues","ShortName":"FixedValues","LanguagePhrases":[{"Id":379721,"PropertyName":"value","Value":"Transfer Bekleyen Havuzu"},{"Id":664141,"PropertyName":"value","Value":"Onaylanan talepleri mağaza rotasına göre gruplayın ve transfer fişine hazırlayın."},{"Id":542723,"PropertyName":"label","Value":"Yenile"},{"Id":187900,"PropertyName":"value","Value":"Talep No"},{"Id":717009,"PropertyName":"placeholder","Value":"Talep numarası girin"},{"Id":266158,"PropertyName":"value","Value":"Gönderen Mağaza"},{"Id":113664,"PropertyName":"placeholder","Value":"Gönderen mağaza seçin"},{"Id":560402,"PropertyName":"value","Value":"Alıcı Mağaza"},{"Id":819096,"PropertyName":"placeholder","Value":"Alıcı mağaza seçin"},{"Id":740676,"PropertyName":"value","Value":"Ürün Kodu veya Ürün Adı"},{"Id":357744,"PropertyName":"placeholder","Value":"Kod veya ürün adı yazın"},{"Id":308747,"PropertyName":"value","Value":"Onay Tarihi"},{"Id":526292,"PropertyName":"startDatePlaceholder","Value":"Başlangıç"},{"Id":526292,"PropertyName":"endDatePlaceholder","Value":"Bitiş"},{"Id":454001,"PropertyName":"label","Value":"Ara"},{"Id":578686,"PropertyName":"label","Value":"Temizle"},{"Id":567428,"PropertyName":"header","Value":"Mersin Times → Adana Times  ·  4 Talep  ·  7 Adet  ·  En eski: 5 gün"},{"Id":163657,"PropertyName":"label","Value":"Tümünü Seç"},{"Id":243172,"PropertyName":"label","Value":"Seçimi Temizle"},{"Id":839311,"PropertyName":"value","Value":"0 talep seçildi"},{"Id":502978,"PropertyName":"value","Value":"Bekleme"},{"Id":620644,"PropertyName":"value","Value":"5 gün"},{"Id":507163,"PropertyName":"title","Value":"Talep No"},{"Id":187925,"PropertyName":"value","Value":"label"},{"Id":848403,"PropertyName":"title","Value":"Alıcı"},{"Id":407780,"PropertyName":"value","Value":"label"},{"Id":956914,"PropertyName":"title","Value":"Gönderen"},{"Id":847167,"PropertyName":"value","Value":"label"},{"Id":276032,"PropertyName":"title","Value":"Ürün"},{"Id":275215,"PropertyName":"value","Value":"label"},{"Id":810541,"PropertyName":"title","Value":"Talep Miktarı"},{"Id":588161,"PropertyName":"value","Value":"label"},{"Id":164545,"PropertyName":"title","Value":"Onay Tarihi"},{"Id":677097,"PropertyName":"value","Value":"label"},{"Id":9429,"PropertyName":"title","Value":"Bekleme Süresi"},{"Id":313741,"PropertyName":"value","Value":"label"},{"Id":330870,"PropertyName":"title","Value":"İşlemler"},{"Id":691281,"PropertyName":"label","Value":"Detay"},{"Id":790717,"PropertyName":"value","Value":"Gönderen: Mersin Times"},{"Id":948543,"PropertyName":"value","Value":"Alıcı: Adana Times"},{"Id":277818,"PropertyName":"value","Value":"Seçilen Talep: 2"},{"Id":133111,"PropertyName":"value","Value":"Toplam Ürün: 4 adet"},{"Id":736033,"PropertyName":"label","Value":"Seçimi Temizle"},{"Id":133377,"PropertyName":"label","Value":"Transfer Fişi Hazırla"},{"Id":655431,"PropertyName":"header","Value":"Antalya Times → Adana Times  ·  2 Talep  ·  3 Adet  ·  En eski: 2 gün"},{"Id":475411,"PropertyName":"value","Value":"Bekleme"},{"Id":797243,"PropertyName":"value","Value":"2 gün"},{"Id":905493,"PropertyName":"header","Value":"Adana Times → Gaziantep Times  ·  3 Talep  ·  5 Adet  ·  En eski: 8 gün"},{"Id":262742,"PropertyName":"value","Value":"Bekleme"},{"Id":33792,"PropertyName":"value","Value":"8 gün"}]}]
    defaultML = "en_US"
    
    screenHash = ""
    

    private _prevMasterPageInitLoaded: boolean = false;
    private _prevMasterPageRecurringLoaded: boolean = false;
    private _prevShouldTriggerPageInit: boolean = false;
    constructor(props) {
        super(props);
		this.transferbekleyenhavuzu_717009_value_kuikaTextInputRef = React.createRef();
		this.transferbekleyenhavuzu_113664_value_kuikaAutoCompleteRef = React.createRef();
		this.transferbekleyenhavuzu_819096_value_kuikaAutoCompleteRef = React.createRef();
		this.transferbekleyenhavuzu_357744_value_kuikaTextInputRef = React.createRef();
		this.transferbekleyenhavuzu_117999_value_kuikaTableRef = React.createRef();

        this.state = {
            isSpinnerVisible: false,
            isPageVisible: false,
            isLeftMenuVisible: false,
            spinnerCount: 0,
            selectedLanguage: "",
            isPageInitLoaded: false,
            isPageRecurringLoaded: false,
            	        dataSource_113664: [{"key":"mersin","text":"Mersin Times"},{"key":"antalya","text":"Antalya Times"},{"key":"adana","text":"Adana Times"}],
	        dataSource_819096: [{"key":"adana","text":"Adana Times"},{"key":"gaziantep","text":"Gaziantep Times"},{"key":"mersin","text":"Mersin Times"}],

        }

        this.state.isPageVisible = true;
        
    }

    async componentDidMount() {

        if (KuikaAppManager.isPageInitPrevented()) {
            KuikaAppManager.calculateAndSetBodyHeight("transferbekleyenhavuzu", "masterscreen_screen");
            return;
        }
        this.context.registerCallbackFunction(this.callCallbackFunction.bind(this));
        
        ReactSystemFunctions.validateToken()
        this.fillFormInitValues();
        if (false){
            
        }
        
        
        
        KuikaAppManager.calculateAndSetBodyHeight("transferbekleyenhavuzu", "masterscreen_screen");

        if (ReactSystemFunctions.getIsMicroApp() === false) {
           window.parentScreen = this;
        }
    }

    componentWillUnmount() {
        
        
        

        if (ReactSystemFunctions.getIsMicroApp() === false) {
           window.parentScreen = null;
        }
    }

    

        
    componentDidUpdate= async (prevProps, prevState) => {
		KuikaAppManager.calculateAndSetBodyHeight("transferbekleyenhavuzu", "masterscreen_screen"    );
        if (prevProps?.location?.search !== (this.props as any)?.location?.search) {
			
		}

        

        if (ReactSystemFunctions.getIsMicroApp() === false) {
            for (const key in prevState) {
                if (key.startsWith('NavVisible') && prevState[key] === true && this.state[key] === false) {
                    window.parentScreen = this;
                    break;
                }
            }
        }
	}

    fillFormInitValues() {
        this.props.form?.setFieldsValue({
});

    }

      setPageInitLoaded = (value: boolean) => {
        this.setState({ isPageInitLoaded: value });
      }

      setPageRecurringLoaded = (value: boolean) => {
        this.setState({ isPageRecurringLoaded: value });
      }

      clearFieldValidation = (changedValues: any) => {
        const fieldName = Object.keys(changedValues)[0];
        if (fieldName) {
          this.props.form?.setFields([
            {
              name: fieldName,
              errors: []
            }
          ]);
        }
      };

      




    async callCallbackFunction(diId: number, isFromMaster: boolean = false) {
        let isErrorOccurred = false;

    }


}
