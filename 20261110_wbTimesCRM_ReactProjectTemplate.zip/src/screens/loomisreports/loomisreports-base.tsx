import React from "react";
import Axios, { AxiosResponse } from "axios";
import { KuikaAppManager } from "../../shared/utilty/kuika-app-manager";
import { ReactSystemFunctions } from "../../shared/utilty/react-system-functions";
import { KNavigator } from "../../shared/hoc/with-history";
import { KContext } from "../../shared/hoc/with-context";
import { useLocation } from "react-router-dom";
import { FormInstance } from "antd/es/form";
import { Guid } from "guid-typescript";
import Swal from "sweetalert2";
import { KMainFunctions } from "../../shared/utilty/main-functions";
import moment from "moment";
import { IValidationData } from "../../models/dto/validation-data";
import { IStripePayment } from "../../models/dto/stripe-payment";
import { IUserInfoDto } from "../../models/dto/user-info.dto";
import { UserService } from "../../services/user-service";
import { kuikaCoreWasmBridgeService } from "../../services/_singletons";
import _ from "lodash";
import mqtt, { MqttClient } from "mqtt";
import { IMqttResult } from "../../models/dto/mqtt.dto";
import { MasterScreen_ScreenContext } from "../masterscreen/masterscreen-context";

declare let window: any;

export interface ILoomisReports_ScreenProps {
  navigator: KNavigator;
  form: FormInstance<any>;
  googleLogin: any;
  screenInputs: any;
  context: KContext;
  initialValues: any;
  children: any;
}

export interface ILoomisReports_ScreenState {
    isSpinnerVisible: boolean;
    isPageVisible: boolean;
	isLeftMenuVisible: boolean;
    spinnerCount: number;
    selectedLanguage: string;
    isPageInitLoaded: false;
    isPageRecurringLoaded: false;

}

export class LoomisReports_ScreenBase extends React.PureComponent<ILoomisReports_ScreenProps, any> {
    static contextType = MasterScreen_ScreenContext;
    declare context: React.ContextType<typeof MasterScreen_ScreenContext>;
	loomisreports_390370_value_kuikaTableRef: React.RefObject<any>;
	loomisreports_824346_value_kuikaGalleryViewRef: React.RefObject<any>;
	loomisreports_426992_value_kuikaTableRef: React.RefObject<any>;
    ml=[{"Id":"d5a61d2b-bd60-485f-86e2-661e9ed4e486","Name":"en_US","ShortName":"English","IsDefault":true,"LanguagePhrases":[]},{"Id":"7b28a526-ec8f-471c-91e3-b1c3bce9e156","Name":"FixedValues","ShortName":"FixedValues","LanguagePhrases":[{"Id":910240,"PropertyName":"value","Value":"Loomis Raporları"},{"Id":869891,"PropertyName":"value","Value":"Servis operasyon yönetimi ve bakım süreçleri"},{"Id":728536,"PropertyName":"value","Value":"2025 Loomis Özet Görünüm"},{"Id":691585,"PropertyName":"title","Value":"Mağaza"},{"Id":158532,"PropertyName":"value","Value":"Adana"},{"Id":939883,"PropertyName":"title","Value":"Ocak"},{"Id":311253,"PropertyName":"value","Value":"label"},{"Id":291688,"PropertyName":"title","Value":"Şubat"},{"Id":847475,"PropertyName":"value","Value":"label"},{"Id":334016,"PropertyName":"title","Value":"Mart"},{"Id":985530,"PropertyName":"value","Value":"label"},{"Id":389443,"PropertyName":"title","Value":"Nisan"},{"Id":654404,"PropertyName":"value","Value":"label"},{"Id":38336,"PropertyName":"title","Value":"Mayıs"},{"Id":974849,"PropertyName":"value","Value":"label"},{"Id":611269,"PropertyName":"title","Value":"Haziran"},{"Id":149634,"PropertyName":"value","Value":"label"},{"Id":921949,"PropertyName":"title","Value":"Temmuz"},{"Id":41637,"PropertyName":"value","Value":"label"},{"Id":520163,"PropertyName":"title","Value":"Ağustos"},{"Id":186117,"PropertyName":"value","Value":"label"},{"Id":56238,"PropertyName":"title","Value":"Eylül"},{"Id":498459,"PropertyName":"value","Value":"label"},{"Id":716515,"PropertyName":"title","Value":"Ekim"},{"Id":71926,"PropertyName":"value","Value":"label"},{"Id":499659,"PropertyName":"title","Value":"Kasım"},{"Id":883864,"PropertyName":"value","Value":"label"},{"Id":913924,"PropertyName":"title","Value":"Aralık"},{"Id":922906,"PropertyName":"value","Value":"label"},{"Id":339583,"PropertyName":"value","Value":"Aylık Loomis Raporları"},{"Id":824346,"PropertyName":"nodatafoundmessage","Value":"No data found."},{"Id":384301,"PropertyName":"value","Value":"Ocak 2026"},{"Id":865822,"PropertyName":"title","Value":"Mağaza"},{"Id":991309,"PropertyName":"value","Value":"Adana"},{"Id":933672,"PropertyName":"title","Value":"2025"},{"Id":132800,"PropertyName":"value","Value":"10"},{"Id":40159,"PropertyName":"title","Value":"2026"},{"Id":367047,"PropertyName":"value","Value":"14"},{"Id":699642,"PropertyName":"title","Value":"Değişim"},{"Id":42928,"PropertyName":"value","Value":"+40%"},{"Id":486906,"PropertyName":"value","Value":"-20%"}]}]
    defaultML = "en_US"
    
    screenHash = ""
    

    private _prevMasterPageInitLoaded: boolean = false;
    private _prevMasterPageRecurringLoaded: boolean = false;
    private _prevShouldTriggerPageInit: boolean = false;
    constructor(props) {
        super(props);
		this.loomisreports_390370_value_kuikaTableRef = React.createRef();
		this.loomisreports_824346_value_kuikaGalleryViewRef = React.createRef();
		this.loomisreports_426992_value_kuikaTableRef = React.createRef();

        this.state = {
            isSpinnerVisible: false,
            isPageVisible: false,
            isLeftMenuVisible: false,
            spinnerCount: 0,
            selectedLanguage: "",
            isPageInitLoaded: false,
            isPageRecurringLoaded: false,
            
        }

        this.state.isPageVisible = true;
        
    }

    async componentDidMount() {

        if (KuikaAppManager.isPageInitPrevented()) {
            KuikaAppManager.calculateAndSetBodyHeight("loomisreports", "masterscreen_screen");
            return;
        }
        this.context.registerCallbackFunction(this.callCallbackFunction.bind(this));
        
        ReactSystemFunctions.validateToken()
        this.fillFormInitValues();
        if (false){
            
        }
        
        
        
        KuikaAppManager.calculateAndSetBodyHeight("loomisreports", "masterscreen_screen");

        if (ReactSystemFunctions.getIsMicroApp() === false) {
           window.parentScreen = this;
        }
    }

    componentWillUnmount() {
        
        
        

        if (ReactSystemFunctions.getIsMicroApp() === false) {
           window.parentScreen = null;
        }
    }

    

        
    componentDidUpdate= async (prevProps, prevState) => {
		KuikaAppManager.calculateAndSetBodyHeight("loomisreports", "masterscreen_screen"    );
        if (prevProps?.location?.search !== (this.props as any)?.location?.search) {
			
		}

        

        if (ReactSystemFunctions.getIsMicroApp() === false) {
            for (const key in prevState) {
                if (key.startsWith('NavVisible') && prevState[key] === true && this.state[key] === false) {
                    window.parentScreen = this;
                    break;
                }
            }
        }
	}

    fillFormInitValues() {
        this.props.form?.setFieldsValue({
});

    }

      setPageInitLoaded = (value: boolean) => {
        this.setState({ isPageInitLoaded: value });
      }

      setPageRecurringLoaded = (value: boolean) => {
        this.setState({ isPageRecurringLoaded: value });
      }

      clearFieldValidation = (changedValues: any) => {
        const fieldName = Object.keys(changedValues)[0];
        if (fieldName) {
          this.props.form?.setFields([
            {
              name: fieldName,
              errors: []
            }
          ]);
        }
      };

      




    async callCallbackFunction(diId: number, isFromMaster: boolean = false) {
        let isErrorOccurred = false;

    }


}
