import * as React from "react";
import { MasterScreenWrapper } from "../../routes/master-screen-wrapper";
import { MasterScreenTop_Screen } from "./masterscreentop";
import { MasterScreenTop_ScreenProvider } from "./masterscreentop-context";

// Inline mount of the master, used by drawer / modal / floatingPanel NAVIGATE targets.
// It mounts inside an already-routed (already-authenticated) parent screen, so the
// privateRouteReady auth gate that the router-level wrapper uses is irrelevant here —
// `forceReady` short-circuits it so master always renders inside the drawer/modal/panel.
//
// KOA-8559: this inline wrapper doubles as an "Open in Current Overlay" host. While it is
// mounted it publishes InlineOverlayNavContext to its own subtree (see MasterScreenWrapper).
// A NAVIGATE with openAs="currentOverlay" fired from inside it (master menu or child) and
// targeting one of this master's child screens swaps the overlay's visible child to that
// screen via renderOverlayScreen — keeping the overlay open and the master chrome / shared
// form mounted — instead of routing the page behind it.
export class MasterScreenTop_Screen_InlineWrapper extends MasterScreenWrapper {
    protected get anonymousPaths(): string[] { return []; }
    protected get forceReady(): boolean { return true; }
    protected get MasterComponent(): React.ComponentType<{ children?: React.ReactNode }> { return MasterScreenTop_Screen; }
    protected get MasterProvider(): React.ComponentType<{ children?: React.ReactNode }> { return MasterScreenTop_ScreenProvider; }
    protected get overlayScreenNames(): string[] | null { return []; }
    protected renderOverlayScreen(screenName: string, screenInputs: Record<string, unknown>, onClose: () => void): React.ReactNode {
        switch (screenName.toLowerCase()) {

            default:
                return null;
        }
    }
    protected renderSwitchWrapper(): React.ReactNode { return this.props.children ?? null; }
}
