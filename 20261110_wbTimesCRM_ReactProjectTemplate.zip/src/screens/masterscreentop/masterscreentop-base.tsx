import React from "react";
import Axios, { AxiosResponse } from "axios";
import { KuikaAppManager } from "../../shared/utilty/kuika-app-manager";
import { ReactSystemFunctions } from "../../shared/utilty/react-system-functions";
import { KNavigator } from "../../shared/hoc/with-history";
import { KContext } from "../../shared/hoc/with-context";
import { useLocation } from "react-router-dom";
import { FormInstance } from "antd/es/form";
import { Guid } from "guid-typescript";
import Swal from "sweetalert2";
import { KMainFunctions } from "../../shared/utilty/main-functions";
import moment from "moment";
import { IValidationData } from "../../models/dto/validation-data";
import { IStripePayment } from "../../models/dto/stripe-payment";
import { IUserInfoDto } from "../../models/dto/user-info.dto";
import { UserService } from "../../services/user-service";
import { kuikaCoreWasmBridgeService } from "../../services/_singletons";
import _ from "lodash";
import mqtt, { MqttClient } from "mqtt";
import { IMqttResult } from "../../models/dto/mqtt.dto";
import { MasterScreenTop_ScreenContext } from "./masterscreentop-context";

declare let window: any;

export interface IMasterScreenTop_ScreenProps {
  navigator: KNavigator;
  form: FormInstance<any>;
  googleLogin: any;
  screenInputs: any;
  context: KContext;
  initialValues: any;
  children: any;
}

export interface IMasterScreenTop_ScreenState {
    isSpinnerVisible: boolean;
    isPageVisible: boolean;
	isLeftMenuVisible: boolean;
    spinnerCount: number;
    selectedLanguage: string;
    isPageInitLoaded: false;
    isPageRecurringLoaded: false;
	TM_GetUserStoreInfo: any[];
	TM_GetUserStoreInfo_dummy: any[];
	TM_UserRoleByUserId: any[];
	TM_UserRoleByUserId_dummy: any[];
	NAVIGATE: any;
	NAVIGATE_dummy: any;
	Logout: boolean;
	Logout_dummy: boolean;
	goToSignInActivity: any;
	goToSignInActivity_dummy: any;
	isComp369365Visible: 'visible' | 'hidden';
	isCompmasterscreentop_369365AuthorizationVisible: 'visible' | 'hidden';
	isCompmasterscreentop_243392AuthorizationVisible: 'visible' | 'hidden';
	isCompmasterscreentop_459138AuthorizationVisible: 'visible' | 'hidden';
	isCompmasterscreentop_453824AuthorizationVisible: 'visible' | 'hidden';
	isCompmasterscreentop_545276AuthorizationVisible: 'visible' | 'hidden';
	isCompmasterscreentop_601132AuthorizationVisible: 'visible' | 'hidden';
	isCompmasterscreentop_140599AuthorizationVisible: 'visible' | 'hidden';
	isCompmasterscreentop_979769AuthorizationVisible: 'visible' | 'hidden';
	isCompmasterscreentop_732429AuthorizationVisible: 'visible' | 'hidden';
	isCompmasterscreentop_484693AuthorizationVisible: 'visible' | 'hidden';

}

export class MasterScreenTop_ScreenBase extends React.PureComponent<IMasterScreenTop_ScreenProps, any> {
    static contextType = MasterScreenTop_ScreenContext;
    declare context: React.ContextType<typeof MasterScreenTop_ScreenContext>;
	masterscreentop_752466_value_kuikaSiderMenuRef: React.RefObject<any>;
	masterscreentop_584050_value_kuikaSiderMenuRef: React.RefObject<any>;
	masterscreentop_945484_value_kuikaSiderMenuRef: React.RefObject<any>;
	masterscreentop_375797_value_kuikaSiderMenuRef: React.RefObject<any>;
    ml=[{"Id":"d5a61d2b-bd60-485f-86e2-661e9ed4e486","Name":"en_US","ShortName":"English","IsDefault":true,"LanguagePhrases":[]},{"Id":"1fe4820e-e046-41e8-b779-91f0d8f0211f","Name":"FixedValues","ShortName":"FixedValues","LanguagePhrases":[{"Id":914246,"PropertyName":"value","Value":"label"},{"Id":116286,"PropertyName":"label","Value":"Sub Menu"},{"Id":467573,"PropertyName":"label","Value":"Menu Item"},{"Id":209623,"PropertyName":"label","Value":"Sub Menu"},{"Id":350840,"PropertyName":"label","Value":"Menu Item"},{"Id":535636,"PropertyName":"label","Value":"Menu Item"},{"Id":4947,"PropertyName":"label","Value":"Menu Item"},{"Id":515892,"PropertyName":"label","Value":"Sub Menu"},{"Id":838847,"PropertyName":"label","Value":"Menu Item"},{"Id":71440,"PropertyName":"label","Value":"Sub Menu"},{"Id":228276,"PropertyName":"label","Value":"Menu Item"},{"Id":588521,"PropertyName":"label","Value":"Menu Item"},{"Id":280036,"PropertyName":"label","Value":"Menu Item"},{"Id":205290,"PropertyName":"label","Value":"Sub Menu"},{"Id":414431,"PropertyName":"label","Value":"Menu Item"},{"Id":736598,"PropertyName":"label","Value":"Sub Menu"},{"Id":722617,"PropertyName":"label","Value":"Menu Item"},{"Id":555280,"PropertyName":"label","Value":"Menu Item"},{"Id":216085,"PropertyName":"label","Value":"Menu Item"},{"Id":52456,"PropertyName":"value","Value":"Times"},{"Id":369365,"PropertyName":"label","Value":"Anasayfa"},{"Id":243392,"PropertyName":"label","Value":"Ürün Talepleri"},{"Id":459138,"PropertyName":"label","Value":"Talep Listesi"},{"Id":453824,"PropertyName":"label","Value":"Yeni Talep"},{"Id":545276,"PropertyName":"label","Value":"Dağıtım & Teslimat"},{"Id":601132,"PropertyName":"label","Value":"Teslimat Yönetimi"},{"Id":140599,"PropertyName":"label","Value":"Dağıtım Yönetimi"},{"Id":979769,"PropertyName":"label","Value":"Portföy Yönetimi"},{"Id":732429,"PropertyName":"label","Value":"Portföy Listeleme"},{"Id":484693,"PropertyName":"label","Value":"Çıkış Yap"}]}]
    defaultML = "en_US"
    
    screenHash = ""
    

    private _prevMasterPageInitLoaded: boolean = false;
    private _prevMasterPageRecurringLoaded: boolean = false;
    private _prevShouldTriggerPageInit: boolean = false;
    constructor(props) {
        super(props);
		this.masterscreentop_752466_value_kuikaSiderMenuRef = React.createRef();
		this.masterscreentop_584050_value_kuikaSiderMenuRef = React.createRef();
		this.masterscreentop_945484_value_kuikaSiderMenuRef = React.createRef();
		this.masterscreentop_375797_value_kuikaSiderMenuRef = React.createRef();

        this.state = {
            isSpinnerVisible: false,
            isPageVisible: false,
            isLeftMenuVisible: false,
            spinnerCount: 0,
            selectedLanguage: "",
            isPageInitLoaded: false,
            isPageRecurringLoaded: false,
            	        TM_GetUserStoreInfo: [],
	        TM_UserRoleByUserId: [],
	        NAVIGATE: "",
	        Logout: false,
	        goToSignInActivity: "",
	        isComp369365Visible: 'hidden',
	        isCompmasterscreentop_369365AuthorizationVisible: 'visible',
	        isCompmasterscreentop_243392AuthorizationVisible: 'visible',
	        isCompmasterscreentop_459138AuthorizationVisible: 'visible',
	        isCompmasterscreentop_453824AuthorizationVisible: 'visible',
	        isCompmasterscreentop_545276AuthorizationVisible: 'visible',
	        isCompmasterscreentop_601132AuthorizationVisible: 'visible',
	        isCompmasterscreentop_140599AuthorizationVisible: 'visible',
	        isCompmasterscreentop_979769AuthorizationVisible: 'visible',
	        isCompmasterscreentop_732429AuthorizationVisible: 'visible',
	        isCompmasterscreentop_484693AuthorizationVisible: 'visible',

        }

        this.state.isPageVisible = true;
        
    }

    async componentDidMount() {

        if (KuikaAppManager.isPageInitPrevented()) {
            KuikaAppManager.calculateAndSetBodyHeight("masterscreentop", "");
            return;
        }
        
        
        
        this.fillFormInitValues();
        try {
        if (true){
            await this.MasterScreenTopPageInit();
        }
        } finally { this.context.setMasterPageInitLoaded(true); }
        ReactSystemFunctions.hideIsNotAuthorized(this, "isCompmasterscreentop_369365AuthorizationVisible", ["b4bfd39c-ac02-f442-c899-7a2374a45b47","70de6cfc-6087-6059-59b4-0b5a8527af6b","TimesSatisPersoneli","TimesMagazaMuduru"]);
ReactSystemFunctions.hideIsNotAuthorized(this, "isCompmasterscreentop_243392AuthorizationVisible", ["cdb536b0-6297-155f-d446-8453d8a60304","4da1f213-c8e4-0b50-5c84-02fd13f1a622","b4bfd39c-ac02-f442-c899-7a2374a45b47","70de6cfc-6087-6059-59b4-0b5a8527af6b","TimesYonetici","TimesUstYonetici","TimesSatisPersoneli","TimesMagazaMuduru"]);
ReactSystemFunctions.hideIsNotAuthorized(this, "isCompmasterscreentop_459138AuthorizationVisible", ["cdb536b0-6297-155f-d446-8453d8a60304","4da1f213-c8e4-0b50-5c84-02fd13f1a622","b4bfd39c-ac02-f442-c899-7a2374a45b47","70de6cfc-6087-6059-59b4-0b5a8527af6b","TimesYonetici","TimesUstYonetici","TimesSatisPersoneli","TimesMagazaMuduru"]);
ReactSystemFunctions.hideIsNotAuthorized(this, "isCompmasterscreentop_453824AuthorizationVisible", ["cdb536b0-6297-155f-d446-8453d8a60304","4da1f213-c8e4-0b50-5c84-02fd13f1a622","b4bfd39c-ac02-f442-c899-7a2374a45b47","70de6cfc-6087-6059-59b4-0b5a8527af6b","TimesYonetici","TimesUstYonetici","TimesSatisPersoneli","TimesMagazaMuduru"]);
ReactSystemFunctions.hideIsNotAuthorized(this, "isCompmasterscreentop_545276AuthorizationVisible", ["cdb536b0-6297-155f-d446-8453d8a60304","4da1f213-c8e4-0b50-5c84-02fd13f1a622","TimesYonetici","TimesUstYonetici"]);
ReactSystemFunctions.hideIsNotAuthorized(this, "isCompmasterscreentop_601132AuthorizationVisible", ["cdb536b0-6297-155f-d446-8453d8a60304","4da1f213-c8e4-0b50-5c84-02fd13f1a622","TimesYonetici","TimesUstYonetici"]);
ReactSystemFunctions.hideIsNotAuthorized(this, "isCompmasterscreentop_140599AuthorizationVisible", ["cdb536b0-6297-155f-d446-8453d8a60304","4da1f213-c8e4-0b50-5c84-02fd13f1a622","TimesYonetici","TimesUstYonetici"]);
ReactSystemFunctions.hideIsNotAuthorized(this, "isCompmasterscreentop_979769AuthorizationVisible", ["cdb536b0-6297-155f-d446-8453d8a60304","4da1f213-c8e4-0b50-5c84-02fd13f1a622","TimesYonetici","TimesUstYonetici"]);
ReactSystemFunctions.hideIsNotAuthorized(this, "isCompmasterscreentop_732429AuthorizationVisible", ["cdb536b0-6297-155f-d446-8453d8a60304","4da1f213-c8e4-0b50-5c84-02fd13f1a622","TimesYonetici","TimesUstYonetici"]);
ReactSystemFunctions.hideIsNotAuthorized(this, "isCompmasterscreentop_484693AuthorizationVisible", ["cdb536b0-6297-155f-d446-8453d8a60304","4da1f213-c8e4-0b50-5c84-02fd13f1a622","b4bfd39c-ac02-f442-c899-7a2374a45b47","70de6cfc-6087-6059-59b4-0b5a8527af6b","c4e882ef-977d-f613-7694-230ac83919d2","TimesYonetici","TimesUstYonetici","TimesSatisPersoneli","TimesMagazaMuduru","TimesAdmin"]);

        
        
        KuikaAppManager.calculateAndSetBodyHeight("masterscreentop", "");

        if (ReactSystemFunctions.getIsMicroApp() === false) {
           window.parentScreen = this;
        }
    }

    componentWillUnmount() {
        
        
        

        if (ReactSystemFunctions.getIsMicroApp() === false) {
           window.parentScreen = null;
        }
    }

    

        
    componentDidUpdate= async (prevProps, prevState) => {
		KuikaAppManager.calculateAndSetBodyHeight("masterscreentop", ""    );
        if (prevProps?.location?.search !== (this.props as any)?.location?.search) {
			await this.MasterScreenTopPageInit();
		}

        		if (this._prevShouldTriggerPageInit !== this.context.shouldTriggerPageInit && this.context.shouldTriggerPageInit === true) {this._prevShouldTriggerPageInit = this.context.shouldTriggerPageInit;this._prevMasterPageInitLoaded = false; this.MasterScreenTopPageInit().finally(() => { this.context.setMasterPageInitLoaded(true); });this.context.setShouldTriggerPageInit(false);this._prevShouldTriggerPageInit = false;}


        if (ReactSystemFunctions.getIsMicroApp() === false) {
            for (const key in prevState) {
                if (key.startsWith('NavVisible') && prevState[key] === true && this.state[key] === false) {
                    window.parentScreen = this;
                    break;
                }
            }
        }
	}

    fillFormInitValues() {
        this.props.form?.setFieldsValue({
});

    }

      setPageInitLoaded = (value: boolean) => {
        this.setState({ isPageInitLoaded: value });
      }

      setPageRecurringLoaded = (value: boolean) => {
        this.setState({ isPageRecurringLoaded: value });
      }

      clearFieldValidation = (changedValues: any) => {
        const fieldName = Object.keys(changedValues)[0];
        if (fieldName) {
          this.props.form?.setFields([
            {
              name: fieldName,
              errors: []
            }
          ]);
        }
      };

      

    MasterScreenTopPageInit = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


	if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }

        let localVar = {
			UserId_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.getMyUserId(), "Guid"),
			UserID_1: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.getMyUserId(), "Guid")
        }

	KuikaAppManager.showSpinner(this);
	
        if (true) {
        KuikaAppManager.showSpinner(this);
        }
        let result = await KuikaAppManager.ApiRequest(this, "MasterScreenTop/MasterScreenTopPageInit", localVar)
        if (!KMainFunctions.IsResStatus2XX(result)) return true;

		stateVars.TM_GetUserStoreInfo = result?.data.tM_GetUserStoreInfo;
		formVars.masterscreentop_7398_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetUserStoreInfo !== undefined ? (stateVars.TM_GetUserStoreInfo?.length > 0 ? stateVars.TM_GetUserStoreInfo[0].subeAdi : null) : (this.state.TM_GetUserStoreInfo?.length > 0 ? this.state.TM_GetUserStoreInfo[0].subeAdi : null)));
		stateVars.TM_UserRoleByUserId = result?.data.tM_UserRoleByUserId;
		formVars.masterscreentop_708276_value = ReactSystemFunctions.toString(this, (stateVars.TM_UserRoleByUserId !== undefined ? (stateVars.TM_UserRoleByUserId?.length > 0 ? stateVars.TM_UserRoleByUserId[0].roleNames : null) : (this.state.TM_UserRoleByUserId?.length > 0 ? this.state.TM_UserRoleByUserId[0].roleNames : null)));
		this.props.form?.setFieldsValue(formVars);
		
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.MasterScreenTopPageInit1_();
                  resolve();
                });
          })



        
        KuikaAppManager.hideSpinner(this);
        return isErrorOccurred;
    }
	MasterScreenTopPageInit1_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


	if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }

			formVars.masterscreentop_7398_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetUserStoreInfo !== undefined ? (stateVars.TM_GetUserStoreInfo?.length > 0 ? stateVars.TM_GetUserStoreInfo[0].subeAdi : null) : (this.state.TM_GetUserStoreInfo?.length > 0 ? this.state.TM_GetUserStoreInfo[0].subeAdi : null)));

			formVars.masterscreentop_708276_value = ReactSystemFunctions.toString(this, (stateVars.TM_UserRoleByUserId !== undefined ? (stateVars.TM_UserRoleByUserId?.length > 0 ? stateVars.TM_UserRoleByUserId[0].roleNames : null) : (this.state.TM_UserRoleByUserId?.length > 0 ? this.state.TM_UserRoleByUserId[0].roleNames : null)));


	this.props.form?.setFieldsValue(formVars);
	this.setState(stateVars);
	KuikaAppManager.hideSpinner(this);

            this.context.setMasterPageInitLoaded(true);
            return isErrorOccurred;
        }




		MasterScreenTopComponent_693093_onClick = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
KuikaAppManager.showSpinner(this);

					KuikaAppManager.prepareForNavigation();

				stateVars.NAVIGATE = await ReactSystemFunctions.navigate(this, undefined, "MasterScreenTop", "SettingPanel", "", "c9a7c7da-0306-4861-bdfa-6754fc0d829c", "608779", null, null, null, "720px", "600px", true, false);

		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

            
            return isErrorOccurred;
        }


		MasterScreenTopComponent_376907_onClick = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
if (ReactSystemFunctions.contains(ReactSystemFunctions.getMyRoleNames(), "TimesUstYonetici")) {
            KuikaAppManager.showSpinner(this);

					KuikaAppManager.prepareForNavigation();

				stateVars.NAVIGATE = await ReactSystemFunctions.navigate(this, undefined, "MasterScreenTop", "NotificationManager", "", "currentPage", null, null, null, null, null, null, true, false);

		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

        } else {
            KuikaAppManager.hideSpinner(this);
        }

            
            return isErrorOccurred;
        }


		MasterScreenTopComponent_459138_onClick = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
KuikaAppManager.showSpinner(this);

					KuikaAppManager.prepareForNavigation();

				stateVars.NAVIGATE = await ReactSystemFunctions.navigate(this, undefined, "MasterScreenTop", "LeadList", "", "currentPage", null, null, null, null, null, null, true, false);

		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

            
            return isErrorOccurred;
        }


		MasterScreenTopComponent_732429_onClick = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
KuikaAppManager.showSpinner(this);

					KuikaAppManager.prepareForNavigation();

				stateVars.NAVIGATE = await ReactSystemFunctions.navigate(this, undefined, "MasterScreenTop", "AnnualPortfolioList", "", "currentPage", null, null, null, null, null, null, true, false);

		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

            
            return isErrorOccurred;
        }


		MasterScreenTopComponent_484693_onClick = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
KuikaAppManager.showSpinner(this);
		KuikaAppManager.increaseServerRequestCount();

				stateVars.Logout = await ReactSystemFunctions.logout();
				stateVars.tmpBoolResult = await ReactSystemFunctions.goToSignInActivity(this);

		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

            
            return isErrorOccurred;
        }




    async callCallbackFunction(diId: number, isFromMaster: boolean = false) {
        let isErrorOccurred = false;
		let pageInitCallerNavDiIDs = [608779, , , ] as number[];
		if (isFromMaster || pageInitCallerNavDiIDs.indexOf(diId) > -1) {
			await this.MasterScreenTopPageInit();
		}
		this.context?.callCallbackFunction?.(diId, true);

    }


}
