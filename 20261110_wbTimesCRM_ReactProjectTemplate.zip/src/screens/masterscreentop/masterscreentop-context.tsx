import React from "react";

export interface IMasterScreenTop_ScreenContext {
    isMasterPageInitLoaded: boolean;
    setMasterPageInitLoaded: (value: boolean) => void;
    isMasterPageRecurringLoaded: boolean;
    setMasterPageRecurringLoaded: (value: boolean) => void;
    shouldTriggerPageInit: boolean;
    setShouldTriggerPageInit: (value: boolean) => void;
    callCallbackFunction: ((diId: number, isFromMaster?: boolean) => Promise<boolean>) | null;
    registerCallbackFunction: (fn: (diId: number, isFromMaster?: boolean) => Promise<boolean>) => void;
}

const defaultContext: IMasterScreenTop_ScreenContext = {
    isMasterPageInitLoaded: false,
    setMasterPageInitLoaded: () => {},
    isMasterPageRecurringLoaded: false,
    setMasterPageRecurringLoaded: () => {},
    shouldTriggerPageInit: false,
    setShouldTriggerPageInit: () => {},
    callCallbackFunction: null,
    registerCallbackFunction: () => {},
};

export const MasterScreenTop_ScreenContext = React.createContext<IMasterScreenTop_ScreenContext>(defaultContext);

interface IMasterScreenTop_ScreenProviderState {
    isMasterPageInitLoaded: boolean;
    isMasterPageRecurringLoaded: boolean;
    shouldTriggerPageInit: boolean;
}

export class MasterScreenTop_ScreenProvider extends React.Component<any, IMasterScreenTop_ScreenProviderState> {
    private _registeredCallbackFn: ((diId: number, isFromMaster?: boolean) => Promise<boolean>) | null = null;

    constructor(props: any) {
        super(props);
        this.state = {
            isMasterPageInitLoaded: false,
            isMasterPageRecurringLoaded: false,
            shouldTriggerPageInit: false,
        };
    }

    setMasterPageInitLoaded = (value: boolean): void => {
        this.setState({ isMasterPageInitLoaded: value });
    };

    setMasterPageRecurringLoaded = (value: boolean): void => {
        this.setState({ isMasterPageRecurringLoaded: value });
    };

    setShouldTriggerPageInit = (value: boolean): void => {
        this.setState({ shouldTriggerPageInit: value });
    };

    registerCallbackFunction = (fn: (diId: number, isFromMaster?: boolean) => Promise<boolean>): void => {
        this._registeredCallbackFn = fn;
    };

    callCallbackFunction = async (diId: number, isFromMaster: boolean = false): Promise<boolean> => {
        if (this._registeredCallbackFn) {
            return await this._registeredCallbackFn(diId, isFromMaster);
        }
        return false;
    };

    render() {
        return (
            <MasterScreenTop_ScreenContext.Provider
                value={{
                    isMasterPageInitLoaded: this.state.isMasterPageInitLoaded,
                    setMasterPageInitLoaded: this.setMasterPageInitLoaded,
                    isMasterPageRecurringLoaded: this.state.isMasterPageRecurringLoaded,
                    setMasterPageRecurringLoaded: this.setMasterPageRecurringLoaded,
                    shouldTriggerPageInit: this.state.shouldTriggerPageInit,
                    setShouldTriggerPageInit: this.setShouldTriggerPageInit,
                    callCallbackFunction: this.callCallbackFunction,
                    registerCallbackFunction: this.registerCallbackFunction,
                }}
            >
                {this.props.children}
            </MasterScreenTop_ScreenContext.Provider>
        );
    }
}
