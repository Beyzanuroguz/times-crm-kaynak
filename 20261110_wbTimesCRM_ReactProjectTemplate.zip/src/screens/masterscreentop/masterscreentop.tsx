import * as React from "react";
import { MasterScreenTop_ScreenBase } from "./masterscreentop-base";
import { Spacer, KPassword, KSteps, KStep, KLabel, KNumericbox, KButton, KToggle, KCheckbox, KMonthPicker, KDatatimePicker, KRating, KSelectBox, KMultiSelect, KTextarea, KTextbox, KFileDownload, KFilePicker, KLanguageSelect, KLocationSelect, KLocationDisplay, KLocationPicker, KSignature, KIcon, KMDEditor, KMDViewer, KRadio, KRadioGroup, KCalendar, KIFrame, KAvatarMenu, KAvatarMenuItem, KSpace, KSlider, KRadioButton, KThumbnail } from "../../kuika";
import { PaUserTasks, PaInteractionButtons, MfeContainer, TwinChatLive, TwinCustomDashboardLive, TextArea, WebView, Icon, Label, Signature, HorizontalStack, VerticalStack, LanguageSelector, MDViewer, QRRenderer, BarcodeRenderer, Divider, MDEditor, Button, Rating, Percent, Currency, NumberInput, BarcodeInput, Password, TextInput, Image, Email, AreaChart, BarChart, DonutChart, GaugeChart, LineChart, PieChart, Header, Footer, Switch, Url, CountDown, ProgressCircle, ProgressBar, CollapsePanel, Collapse, Slider, KAreaChart, KBarChart, KDonutChart, KGaugeChart, KLineChart, KPieChart, KFooter, KHeader, KRow, KCol, KTab, KTabItem, KTable, KTableHeader, KTableRow, KTableColumn, KGallery, KPagination, KDrawer, KModal, KVideo, KCarousel, KFlexGrid, KPanel, KDropDown, KDropDownItem, KContentMenu, KContentMenuItem, GoogleMaps, GoogleMapsMarker, GoogleMapsMarkerPopup, KContentMenuPanel, KBadge, Badge, RangeSlider, Checkbox, Chat, RangeDate, RangeDateTime, Stopwatch, PlacesAutocompleteInput, CronMaker, SingleSelect, MultiSelect, AutoComplete, StripeCard, PaymentElementStripe, CountUp, Tree, KDatePicker, YearPicker, Tooltip, Calendar, LayoutHeader, LayoutFooter, LayoutLeft, LayoutRight, LocationPicker, Timeline, Stepper, StepperItem, Menu, MenuItem, SubMenu, RadialChart, MixedChart, MixedChartLineItem, MixedChartPointItem, MixedChartBarItem, ChartLabel, KanbanBoard, ProcessAutomation, RadioGroup, BigFileUpload, PivotTable, ColorPicker, Marquee, KanbanBoardCard, KanbanBoardLane, KanbanBoardLaneHeader, Recaptcha, RadarChart, KRadarChart, DynamicInput, DynamicForm, Breadcrumb, FloatButton, FloatPanel, NodeTree, NodeTreeNode, KWidgetRenderer, Directory, Document, DocumentUploader, DocumentCompare, Splitter, SplitterPanel, KuikaEditableCell } from "../../components/web-components";
import { Drawer, Form, Spin, Typography } from "antd/es";
import { withGoogleLogin } from "../../shared/hoc/with-google-login";
import { withHistory } from "../../shared/hoc/with-history";
import { KuikaTabOrderProvider } from "../../shared/hoc/tab-order-provider";
import { withForm } from "../../shared/hoc/with-form";
import { withScreenInput } from "../../shared/hoc/with-screen-input";
import { withContext } from "../../shared/hoc/with-context";
import { withInlineOverlayNav } from "../../shared/hoc/with-inline-overlay-nav";
import { KuikaAppManager } from "../../shared/utilty/kuika-app-manager";
import { ReactSystemFunctions } from "../../shared/utilty/react-system-functions";
import { showPhotoTake, hidePhotoTake, showStripeDrawer, hideStripeDrawer,showIyzicoDrawer, hideIyzicoDrawer, showImportMappedExcelModal, hideImportMappedExcelModal } from "../../redux/modals/actions";
import { AppState} from "../../redux/root-reducer";
import { connect } from "react-redux";
import moment from "moment";


import { SettingPanel_Screen } from "../settingpanel/settingpanel";
import { InlineFormScope } from "../../routes/master-screen-wrapper";


declare let window: any;
const { Title, Paragraph, Text, Link } = Typography;
const menuMap = [
    { key: "459138", screenName: "LeadList", params: {  }, isStartingScreen: false },
    { key: "732429", screenName: "AnnualPortfolioList", params: {  }, isStartingScreen: false }
];

class MasterScreenTop_Screen extends MasterScreenTop_ScreenBase
{
    render() {
        if (this.state.isPageVisible === false) {return (<></>);}
        return (
            <>
              
                <Spin spinning={this.state.spinnerCount > 0 || !this.context?.isMasterPageInitLoaded}>
                    <KuikaTabOrderProvider>
                    
                    <Form form={this.props.form} name="basic"
                        initialValues={
                            {masterscreentop_752466_value: { collapsed: (false), selectedKey: ("") },
							masterscreentop_584050_value: { collapsed: (false), selectedKey: ("") },
							masterscreentop_945484_value: { collapsed: (false), selectedKey: ("") },
							masterscreentop_102724_value: null,
							masterscreentop_375797_value: { collapsed: (false), selectedKey: ("") }
}
                        } onValuesChange={(changedValues, allValues) => {this.clearFieldValidation(changedValues);}}>
                        <div style={{} as any}><LayoutHeader key='-10' data-testid="LayoutHeader" id="Minus10" id="masterscreentop_layout_header" layoutPosition={1} style={{"borderStyle":"solid","borderTopWidth":0,"borderRightWidth":0,"borderBottomWidth":0,"borderLeftWidth":0,"backgroundColor":"rgba(255, 255, 255, 1)","backgroundRepeat":"no-repeat","backgroundSize":"contain","backgroundPosition":"left","paddingTop":0,"paddingRight":0,"paddingBottom":0,"paddingLeft":0,"minHeight":"60px","fontFamily":"Poppins","fontWeight":400,"fontSize":"15px","color":"rgba(68, 68, 68, 1)"} as any}><KRow key='42808' data-testid="Row1" id="42808" align="top" justify="start" horizontalGutter={0} verticalGutter={0} style={{"borderStyle":"solid","borderTopWidth":0,"borderRightWidth":0,"borderBottomWidth":0,"borderLeftWidth":0,"paddingTop":8,"paddingRight":8,"paddingBottom":8,"paddingLeft":8,"alignItems":"center","textAlign":"-webkit-left","fontFamily":"Poppins","fontWeight":400,"fontSize":"15px","color":"rgba(68, 68, 68, 1)"} as any}><KCol key='253202' data-testid="Col1_0" id="253202" xs={12} sm={12} md={12} lg={12} xl={12} xxl={12} order={0} pull={0} push={0} style={{"borderStyle":"solid","borderTopWidth":0,"borderRightWidth":0,"borderBottomWidth":0,"borderLeftWidth":0,"paddingTop":8,"paddingRight":8,"paddingBottom":8,"paddingLeft":8,"alignItems":"center","textAlign":"-webkit-left","fontFamily":"Poppins","fontWeight":400,"fontSize":"15px","color":"rgba(68, 68, 68, 1)"} as any}><Label key='52456' data-testid="Label3" id="52456" value={ReactSystemFunctions.translate(this.ml, 52456, "value",this.defaultML)} writingMode="horizontal" style={{"borderStyle":"solid","borderTopWidth":0,"borderRightWidth":0,"borderBottomWidth":0,"borderLeftWidth":0,"paddingTop":0,"paddingRight":0,"paddingBottom":0,"paddingLeft":0,"alignItems":"center","textAlign":"-webkit-left","display":"block","fontFamily":"Montserrat","fontWeight":400,"fontSize":"26px","color":"rgba(68, 68, 68, 1)"} as any}></Label><Label key='7398' data-testid="Label5" id="7398" value={this.state.TM_GetUserStoreInfo?.at?.(0)?.subeAdi ?? undefined} writingMode="horizontal" style={{"borderStyle":"solid","borderTopWidth":0,"borderRightWidth":0,"borderBottomWidth":0,"borderLeftWidth":0,"paddingTop":0,"paddingRight":0,"paddingBottom":0,"paddingLeft":0,"alignItems":"center","textAlign":"-webkit-left","display":"block","fontFamily":"Poppins","fontWeight":400,"fontSize":"14px","color":"rgba(155, 155, 155, 1)","lineHeight":"20px"} as any}></Label></KCol><KCol key='553847' data-testid="Col1_1" id="553847" xs={12} sm={12} md={12} lg={12} xl={12} xxl={12} order={0} pull={0} push={0} style={{"borderStyle":"solid","borderTopWidth":0,"borderRightWidth":0,"borderBottomWidth":0,"borderLeftWidth":0,"paddingTop":8,"paddingRight":8,"paddingBottom":8,"paddingLeft":8,"alignItems":"center","textAlign":"-webkit-right","fontFamily":"Poppins","fontWeight":400,"fontSize":"15px","color":"rgba(68, 68, 68, 1)"} as any}><HorizontalStack key='400317' data-testid="HorizontalStack1" id="400317" direction="horizontal" size={6} overflowX="auto" style={{"borderStyle":"solid","borderTopWidth":0,"borderRightWidth":0,"borderBottomWidth":0,"borderLeftWidth":0,"paddingTop":0,"paddingRight":0,"paddingBottom":0,"paddingLeft":0,"alignItems":"center","fontFamily":"Poppins","fontWeight":400,"fontSize":"15px","color":"rgba(68, 68, 68, 1)"} as any}><Icon key='693093' data-testid="Icon2" id="693093" onClick={ (e?: any) => { if(e && e.stopPropagation) e.stopPropagation();this.MasterScreenTopComponent_693093_onClick()} } showCursorPointer iconName="manage_accounts" hoverText="Sistem Ayarları" iconLibrary="material" style={{"borderTopLeftRadius":8,"borderTopRightRadius":8,"borderBottomRightRadius":8,"borderBottomLeftRadius":8,"borderTopWidth":2,"borderRightWidth":2,"borderBottomWidth":2,"borderLeftWidth":2,"borderColor":"rgba(42, 91, 63, 1)","borderStyle":"solid","paddingTop":2,"paddingRight":2,"paddingBottom":2,"paddingLeft":2,"fontFamily":"Poppins","fontWeight":500,"fontSize":"24px","color":"rgba(42, 91, 63, 1)","letterSpacing":"1px"} as any}></Icon><Icon key='376907' data-testid="Icon1" id="376907" onClick={ (e?: any) => { if(e && e.stopPropagation) e.stopPropagation();this.MasterScreenTopComponent_376907_onClick()} } showCursorPointer iconName="notifications_active" iconLibrary="material" style={{"borderStyle":"solid","borderTopWidth":0,"borderRightWidth":0,"borderBottomWidth":0,"borderLeftWidth":0,"paddingTop":0,"paddingRight":0,"paddingBottom":0,"paddingLeft":0,"alignItems":"center","textAlign":"-webkit-left","display":"inline","fontFamily":"Poppins","fontWeight":500,"fontSize":"24px","color":"rgba(155, 155, 155, 1)","letterSpacing":"1px"} as any}></Icon>
<Form.Item className='kFormItem' name='masterscreentop_102724_value' ><Image key='102724' data-testid="Image1" id="102724" zoomOnClick={false} imageFit="fit" style={{"borderTopLeftRadius":200,"borderTopRightRadius":200,"borderBottomRightRadius":200,"borderBottomLeftRadius":200,"borderStyle":"solid","borderTopWidth":0,"borderRightWidth":0,"borderBottomWidth":0,"borderLeftWidth":0,"paddingTop":0,"paddingRight":0,"paddingBottom":0,"paddingLeft":0,"width":"32px","height":"32px","alignItems":"center","textAlign":"-webkit-left","display":"inline","fontFamily":"Poppins","fontWeight":400,"fontSize":"15px","color":"rgba(68, 68, 68, 1)"} as any}></Image></Form.Item>
<VerticalStack key='823942' data-testid="VerticalStack1" id="823942" direction="vertical" size={1} style={{"borderStyle":"solid","borderTopWidth":0,"borderRightWidth":0,"borderBottomWidth":0,"borderLeftWidth":0,"paddingTop":0,"paddingRight":0,"paddingBottom":0,"paddingLeft":0,"fontFamily":"Poppins","fontWeight":400,"fontSize":"15px","color":"rgba(68, 68, 68, 1)"} as any}><Label key='993649' data-testid="Label2" id="993649" value={ReactSystemFunctions.getMyFullName()} writingMode="horizontal" style={{"borderStyle":"solid","borderTopWidth":0,"borderRightWidth":0,"borderBottomWidth":0,"borderLeftWidth":0,"paddingTop":0,"paddingRight":0,"paddingBottom":0,"paddingLeft":0,"alignItems":"center","textAlign":"-webkit-left","display":"inline","fontFamily":"Poppins","fontWeight":400,"fontSize":"15px","color":"rgba(68, 68, 68, 1)"} as any}></Label><Label key='708276' data-testid="Label4" id="708276" value={this.state.TM_UserRoleByUserId?.at?.(0)?.roleNames ?? undefined} writingMode="horizontal" style={{"borderStyle":"solid","borderTopWidth":0,"borderRightWidth":0,"borderBottomWidth":0,"borderLeftWidth":0,"paddingTop":0,"paddingRight":0,"paddingBottom":0,"paddingLeft":0,"alignItems":"center","textAlign":"-webkit-left","display":"inline","fontFamily":"Poppins","fontWeight":400,"fontSize":"14px","color":"rgba(155, 155, 155, 1)","lineHeight":"20px"} as any}></Label></VerticalStack></HorizontalStack></KCol></KRow></LayoutHeader><div style={{"display":"flex"} as any}><div id='masterRootDI_wrapper' style={{"flex":"auto","background":"#f0f2f5","minWidth":0} as any}><div style={{"display":"flex"} as any}><div id='masterRootDI' style={{"flex":"auto","overflow":"hidden","maxWidth":"100vw","width":0,"position":"relative","height":"calc(100vh - 66px)"} as any}><>{this.props.children}</></div></div></div></div><FloatPanel key='608779' data-testid="FloatPanel1" id="608779" position="top right" onClose={() => { this.setState({NavVisible608779: false}, () => { this.callCallbackFunction(608779) })}} visible={this.state.NavVisible608779} width="720px" height="600px" offsetX={12} offsetY={80} hideCloseButton={false} children={this.state.NavVisible608779 && <InlineFormScope><SettingPanel_Screen onClose={() => { this.setState({ NavVisible608779: false }, () => { this.callCallbackFunction(608779) }) }} screenInputs={window.kuika.navigationScreenInputs} navigator={this.props.navigator} form={this.props.form} context={this.props.context} /></InlineFormScope>} style={{"borderStyle":"solid","borderTopWidth":0,"borderRightWidth":0,"borderBottomWidth":0,"borderLeftWidth":0,"paddingTop":0,"paddingRight":0,"paddingBottom":0,"paddingLeft":0,"fontFamily":"Poppins","fontWeight":400,"fontSize":"15px","color":"rgba(68, 68, 68, 1)"} as any}></FloatPanel></div>
                    </Form>
                    </KuikaTabOrderProvider>
                </Spin>
              
            </>
        );
    }
}

const mapStateToProps = (state: AppState) => {
    return {
        spinnerCount: state.spinnerReducer.spinnerCount,
        photoTakeVisible: state.photoTakeReducer.visible,
        isImportMappedExcelModalVisible: state.importMappedExcelModalReducer.visible
    };
  }
  const mapDispatchToProps = dispatch => ({
    showPhotoTake: () => dispatch(showPhotoTake()),
    hidePhotoTake: () => dispatch(hidePhotoTake()),
    showStripeDrawer: (data,callback,that,future) => dispatch(showStripeDrawer(data,callback,that,future)),
    hideStripeDrawer: (data,callback,that) => dispatch(hideStripeDrawer(data,callback,that)),
    showIyzicoDrawer: (data,callback,that) => dispatch(showIyzicoDrawer(data,callback,that)),
    hideIyzicoDrawer: (data,callback,that) => dispatch(hideIyzicoDrawer(data,callback,that)),
    showImportMappedExcelModal: (dsId, tableName, primaryKey, columnMapping, parameters) => dispatch(showImportMappedExcelModal(dsId, tableName, primaryKey, columnMapping, parameters)),
    hideImportMappedExcelModal: () => dispatch(hideImportMappedExcelModal())
  });
const tmp = withGoogleLogin(withContext(withScreenInput(withForm(withHistory(withInlineOverlayNav(connect(mapStateToProps, mapDispatchToProps)(MasterScreenTop_Screen)))))));
export { tmp as MasterScreenTop_Screen };
//export default tmp;
//export { tmp as MasterScreenTop_Screen };

