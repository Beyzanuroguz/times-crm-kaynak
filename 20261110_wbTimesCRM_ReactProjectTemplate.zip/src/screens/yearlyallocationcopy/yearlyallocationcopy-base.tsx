import React from "react";
import Axios, { AxiosResponse } from "axios";
import { KuikaAppManager } from "../../shared/utilty/kuika-app-manager";
import { ReactSystemFunctions } from "../../shared/utilty/react-system-functions";
import { KNavigator } from "../../shared/hoc/with-history";
import { KContext } from "../../shared/hoc/with-context";
import { useLocation } from "react-router-dom";
import { FormInstance } from "antd/es/form";
import { Guid } from "guid-typescript";
import Swal from "sweetalert2";
import { KMainFunctions } from "../../shared/utilty/main-functions";
import moment from "moment";
import { IValidationData } from "../../models/dto/validation-data";
import { IStripePayment } from "../../models/dto/stripe-payment";
import { IUserInfoDto } from "../../models/dto/user-info.dto";
import { UserService } from "../../services/user-service";
import { kuikaCoreWasmBridgeService } from "../../services/_singletons";
import _ from "lodash";
import mqtt, { MqttClient } from "mqtt";
import { IMqttResult } from "../../models/dto/mqtt.dto";
import { MasterScreen_ScreenContext } from "../masterscreen/masterscreen-context";

declare let window: any;

export interface IYearlyAllocationcopy_ScreenProps {
  navigator: KNavigator;
  form: FormInstance<any>;
  googleLogin: any;
  screenInputs: any;
  context: KContext;
  initialValues: any;
  children: any;
}

export interface IYearlyAllocationcopy_ScreenState {
    isSpinnerVisible: boolean;
    isPageVisible: boolean;
	isLeftMenuVisible: boolean;
    spinnerCount: number;
    selectedLanguage: string;
    isPageInitLoaded: false;
    isPageRecurringLoaded: false;
	TM_TotalVerifyExcel: any[];
	TM_TotalVerifyExcel_dummy: any[];
	Action1: any[];
	Action1_dummy: any[];
	TM_GetAnnualProductReferences: any[];
	TM_GetAnnualProductReferences_dummy: any[];
	TM_YearlyStockControlByStore: any[];
	TM_YearlyStockControlByStore_dummy: any[];
	TM_GetYearlyStockByType: any[];
	TM_GetYearlyStockByType_dummy: any[];
	GoBack: any;
	GoBack_dummy: any;
	NAVIGATE: any;
	NAVIGATE_dummy: any;
	TM_StoreAnnualTotalUpdate: number;
	TM_StoreAnnualTotalUpdate_dummy: number;
	TriggerEvent: string;
	TriggerEvent_dummy: string;
	Action2: number;
	Action2_dummy: number;
	isComp359636Visible: 'visible' | 'hidden';
	isComp94314Visible: 'visible' | 'hidden';
	isComp950574Visible: 'visible' | 'hidden';
	isComp215116Visible: 'visible' | 'hidden';
	isComp313770Visible: 'visible' | 'hidden';
	isComp123120Visible: 'visible' | 'hidden';

}

export class YearlyAllocationcopy_ScreenBase extends React.PureComponent<IYearlyAllocationcopy_ScreenProps, any> {
    static contextType = MasterScreen_ScreenContext;
    declare context: React.ContextType<typeof MasterScreen_ScreenContext>;
	yearlyallocationcopy_586612_value_kuikaTableRef: React.RefObject<any>;
	yearlyallocationcopy_831638_value_kuikaAutoCompleteRef: React.RefObject<any>;
	yearlyallocationcopy_427664_value_kuikaTableRef: React.RefObject<any>;
	yearlyallocationcopy_448499_value_kuikaTableRef: React.RefObject<any>;
    ml=[{"Id":"d5a61d2b-bd60-485f-86e2-661e9ed4e486","Name":"en_US","ShortName":"English","IsDefault":true,"LanguagePhrases":[]},{"Id":"0b7a8d3e-7da7-4ba4-8d21-546125ca9368","Name":"FixedValues","ShortName":"FixedValues","LanguagePhrases":[{"Id":812352,"PropertyName":"value","Value":"Yıllık Mağaza Bazlı Kota Dağıtımı"},{"Id":626659,"PropertyName":"value","Value":"Tanımlanan yıllık ürün kotalarını mağazalara dağıtın ve yönetin."},{"Id":108036,"PropertyName":"label","Value":"Geri"},{"Id":401242,"PropertyName":"label","Value":"Aylık Devam Et"},{"Id":795031,"PropertyName":"value","Value":"Toplam Objective Kota"},{"Id":757871,"PropertyName":"value","Value":"Kalan Objective Kota"},{"Id":405390,"PropertyName":"value","Value":"Toplam Objective Dışında Kota"},{"Id":49133,"PropertyName":"value","Value":"Kalan Objective Dışında Kota"},{"Id":889762,"PropertyName":"value","Value":"Mağaza Bazlı Toplam Kota"},{"Id":474795,"PropertyName":"title","Value":"Total Adana"},{"Id":347601,"PropertyName":"value","Value":"[datafield:adana]"},{"Id":542065,"PropertyName":"title","Value":"Total Antalya"},{"Id":210324,"PropertyName":"value","Value":"[datafield:antalya]"},{"Id":520234,"PropertyName":"placeholder","Value":"15"},{"Id":878746,"PropertyName":"title","Value":"Total Gaziantep"},{"Id":961862,"PropertyName":"value","Value":"[datafield:gaziantep]"},{"Id":574472,"PropertyName":"title","Value":"Total Mersin"},{"Id":273040,"PropertyName":"value","Value":"[datafield:mersin]"},{"Id":181547,"PropertyName":"title","Value":"Total Merkez"},{"Id":964657,"PropertyName":"value","Value":"[datafield:merkez]"},{"Id":394520,"PropertyName":"value","Value":"Referansa Göre Arama"},{"Id":831638,"PropertyName":"placeholder","Value":"Referansa göre arama..."},{"Id":386984,"PropertyName":"title","Value":"Title"},{"Id":146913,"PropertyName":"value","Value":"[datafield:storename]"},{"Id":313540,"PropertyName":"value","Value":"[datafield:message]"},{"Id":110437,"PropertyName":"value","Value":"Referansa Göre Yıllık Mağaza Bazlı Toplam Kota"},{"Id":917638,"PropertyName":"title","Value":"Referans"},{"Id":450391,"PropertyName":"value","Value":"[datafield:urunkodu]"},{"Id":980344,"PropertyName":"title","Value":"Yıllık Toplam"},{"Id":931249,"PropertyName":"value","Value":"[datafield:yıllıktahsismiktarı]"},{"Id":313673,"PropertyName":"title","Value":"Kalan"},{"Id":522983,"PropertyName":"value","Value":"[datafield:kalanstok]"},{"Id":979489,"PropertyName":"title","Value":"Adana"},{"Id":171380,"PropertyName":"placeholder","Value":"0"},{"Id":679960,"PropertyName":"title","Value":"Antalya"},{"Id":979362,"PropertyName":"placeholder","Value":"0"},{"Id":888027,"PropertyName":"title","Value":"Gaziantep"},{"Id":946036,"PropertyName":"placeholder","Value":"0"},{"Id":595844,"PropertyName":"title","Value":"Mersin"},{"Id":498350,"PropertyName":"placeholder","Value":"0"},{"Id":347819,"PropertyName":"title","Value":"Merkez"},{"Id":571122,"PropertyName":"placeholder","Value":"0"},{"Id":997314,"PropertyName":"title","Value":"Statü"}]}]
    defaultML = "en_US"
    
    screenHash = ""
    

    private _prevMasterPageInitLoaded: boolean = false;
    private _prevMasterPageRecurringLoaded: boolean = false;
    private _prevShouldTriggerPageInit: boolean = false;
    constructor(props) {
        super(props);
		this.yearlyallocationcopy_586612_value_kuikaTableRef = React.createRef();
		this.yearlyallocationcopy_831638_value_kuikaAutoCompleteRef = React.createRef();
		this.yearlyallocationcopy_427664_value_kuikaTableRef = React.createRef();
		this.yearlyallocationcopy_448499_value_kuikaTableRef = React.createRef();

        this.state = {
            isSpinnerVisible: false,
            isPageVisible: false,
            isLeftMenuVisible: false,
            spinnerCount: 0,
            selectedLanguage: "",
            isPageInitLoaded: false,
            isPageRecurringLoaded: false,
            	        TM_TotalVerifyExcel: [],
	        Action1: [],
	        TM_GetAnnualProductReferences: [],
	        TM_YearlyStockControlByStore: [],
	        TM_GetYearlyStockByType: [],
	        GoBack: "",
	        NAVIGATE: "",
	        TM_StoreAnnualTotalUpdate: 0,
	        TriggerEvent: "",
	        Action2: 0,
	        isComp359636Visible: 'hidden',
	        isComp94314Visible: 'hidden',
	        isComp950574Visible: 'hidden',
	        isComp215116Visible: 'hidden',
	        isComp313770Visible: 'hidden',
	        isComp123120Visible: 'hidden',

        }

        this.state.isPageVisible = true;
        
    }

    async componentDidMount() {

        if (KuikaAppManager.isPageInitPrevented()) {
            KuikaAppManager.calculateAndSetBodyHeight("yearlyallocationcopy", "masterscreen_screen");
            return;
        }
        this.context.registerCallbackFunction(this.callCallbackFunction.bind(this));
        
        ReactSystemFunctions.validateToken()
        this.fillFormInitValues();
        if (false){
            await this.YearlyAllocationcopyPageInit();
        } else if (this.context?.isMasterPageInitLoaded) { this._prevMasterPageInitLoaded = true; await this.YearlyAllocationcopyPageInit(); }
        
        
        
        KuikaAppManager.calculateAndSetBodyHeight("yearlyallocationcopy", "masterscreen_screen");

        if (ReactSystemFunctions.getIsMicroApp() === false) {
           window.parentScreen = this;
        }
    }

    componentWillUnmount() {
        
        
        

        if (ReactSystemFunctions.getIsMicroApp() === false) {
           window.parentScreen = null;
        }
    }

    

        
    componentDidUpdate= async (prevProps, prevState) => {
		KuikaAppManager.calculateAndSetBodyHeight("yearlyallocationcopy", "masterscreen_screen"    );
        if (prevProps?.location?.search !== (this.props as any)?.location?.search) {
			await this.YearlyAllocationcopyPageInit();
		}

        		if (this._prevMasterPageInitLoaded !== this.context.isMasterPageInitLoaded && this.context.isMasterPageInitLoaded === true) {this._prevMasterPageInitLoaded = this.context.isMasterPageInitLoaded;await this.YearlyAllocationcopyPageInit()}


        if (ReactSystemFunctions.getIsMicroApp() === false) {
            for (const key in prevState) {
                if (key.startsWith('NavVisible') && prevState[key] === true && this.state[key] === false) {
                    window.parentScreen = this;
                    break;
                }
            }
        }
	}

    fillFormInitValues() {
        this.props.form?.setFieldsValue({
});

    }

      setPageInitLoaded = (value: boolean) => {
        this.setState({ isPageInitLoaded: value });
      }

      setPageRecurringLoaded = (value: boolean) => {
        this.setState({ isPageRecurringLoaded: value });
      }

      clearFieldValidation = (changedValues: any) => {
        const fieldName = Object.keys(changedValues)[0];
        if (fieldName) {
          this.props.form?.setFields([
            {
              name: fieldName,
              errors: []
            }
          ]);
        }
      };

      

    YearlyAllocationcopyPageInit = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


	if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }

        let localVar = {
			Year_0: ReactSystemFunctions.convertToTypeByName(this.props.screenInputs.Year ?? this.props.screenInputs.year, "string"),
			Yearn_1: ReactSystemFunctions.convertToTypeByName(this.props.screenInputs.Year ?? this.props.screenInputs.year, "string"),
			RefNo_1: ReactSystemFunctions.convertToTypeByName(null, "string"),
			Yearn_2: ReactSystemFunctions.convertToTypeByName(this.props.screenInputs.Year ?? this.props.screenInputs.year, "string"),
			Year_3: ReactSystemFunctions.convertToTypeByName(this.props.screenInputs.Year ?? this.props.screenInputs.year, "string"),
			Year_4: ReactSystemFunctions.convertToTypeByName(this.props.screenInputs.Year ?? this.props.screenInputs.year, "string")
        }

	KuikaAppManager.showSpinner(this);
	
        if (true) {
        KuikaAppManager.showSpinner(this);
        }
        let result = await KuikaAppManager.ApiRequest(this, "YearlyAllocationcopy/YearlyAllocationcopyPageInit", localVar)
        if (!KMainFunctions.IsResStatus2XX(result)) return true;

		stateVars.TM_TotalVerifyExcel = result?.data.tM_TotalVerifyExcel;
		
		formVars.yearlyallocationcopy_473070_value = ReactSystemFunctions.toString(this, (stateVars.TM_TotalVerifyExcel !== undefined ? (stateVars.TM_TotalVerifyExcel?.length > 0 ? stateVars.TM_TotalVerifyExcel[0].kotaDurumu : null) : (this.state.TM_TotalVerifyExcel?.length > 0 ? this.state.TM_TotalVerifyExcel[0].kotaDurumu : null)));
		stateVars.isComp359636Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, (stateVars.TM_TotalVerifyExcel !== undefined ? (stateVars.TM_TotalVerifyExcel?.length > 0 ? stateVars.TM_TotalVerifyExcel[0].result : null) : (this.state.TM_TotalVerifyExcel?.length > 0 ? this.state.TM_TotalVerifyExcel[0].result : null))), ReactSystemFunctions.convertToTypeByName("1", "string"))) === true ? "visible" : "hidden")
		stateVars.Action1 = result?.data.action1;
		
		stateVars.TM_GetAnnualProductReferences = result?.data.tM_GetAnnualProductReferences;
		
		formVars.yearlyallocationcopy_831638_options = stateVars.TM_GetAnnualProductReferences;
		stateVars.TM_YearlyStockControlByStore = result?.data.tM_YearlyStockControlByStore;
		
		stateVars.isComp950574Visible = ((ReactSystemFunctions.isNotEmpty(ReactSystemFunctions.toString(this, (stateVars.TM_YearlyStockControlByStore !== undefined ? (stateVars.TM_YearlyStockControlByStore?.length > 0 ? stateVars.TM_YearlyStockControlByStore[0].storeName : null) : (this.state.TM_YearlyStockControlByStore?.length > 0 ? this.state.TM_YearlyStockControlByStore[0].storeName : null))), ReactSystemFunctions.convertToTypeByName("True", "string"))) === true ? "visible" : "hidden")
		stateVars.isComp215116Visible = ((ReactSystemFunctions.isNotEmpty(ReactSystemFunctions.toString(this, (stateVars.TM_YearlyStockControlByStore !== undefined ? (stateVars.TM_YearlyStockControlByStore?.length > 0 ? stateVars.TM_YearlyStockControlByStore[0].message : null) : (this.state.TM_YearlyStockControlByStore?.length > 0 ? this.state.TM_YearlyStockControlByStore[0].message : null))), ReactSystemFunctions.convertToTypeByName("True", "string"))) === true ? "visible" : "hidden")
		stateVars.TM_GetYearlyStockByType = result?.data.tM_GetYearlyStockByType;
		formVars.yearlyallocationcopy_778239_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetYearlyStockByType !== undefined ? (stateVars.TM_GetYearlyStockByType?.length > 0 ? stateVars.TM_GetYearlyStockByType[0].objectiveTotalStock : null) : (this.state.TM_GetYearlyStockByType?.length > 0 ? this.state.TM_GetYearlyStockByType[0].objectiveTotalStock : null)));
		formVars.yearlyallocationcopy_53578_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetYearlyStockByType !== undefined ? (stateVars.TM_GetYearlyStockByType?.length > 0 ? stateVars.TM_GetYearlyStockByType[0].objectiveRemainingStock : null) : (this.state.TM_GetYearlyStockByType?.length > 0 ? this.state.TM_GetYearlyStockByType[0].objectiveRemainingStock : null)));
		formVars.yearlyallocationcopy_251721_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetYearlyStockByType !== undefined ? (stateVars.TM_GetYearlyStockByType?.length > 0 ? stateVars.TM_GetYearlyStockByType[0].nonObjectiveTotalStock : null) : (this.state.TM_GetYearlyStockByType?.length > 0 ? this.state.TM_GetYearlyStockByType[0].nonObjectiveTotalStock : null)));
		formVars.yearlyallocationcopy_825869_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetYearlyStockByType !== undefined ? (stateVars.TM_GetYearlyStockByType?.length > 0 ? stateVars.TM_GetYearlyStockByType[0].nonObjectiveRemainingStock : null) : (this.state.TM_GetYearlyStockByType?.length > 0 ? this.state.TM_GetYearlyStockByType[0].nonObjectiveRemainingStock : null)));
		this.props.form?.setFieldsValue(formVars);
		
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.YearlyAllocationcopyPageInit1_();
                  resolve();
                });
          })



        
        KuikaAppManager.hideSpinner(this);
        return isErrorOccurred;
    }
	YearlyAllocationcopyPageInit1_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


	if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }

			formVars.yearlyallocationcopy_778239_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetYearlyStockByType !== undefined ? (stateVars.TM_GetYearlyStockByType?.length > 0 ? stateVars.TM_GetYearlyStockByType[0].objectiveTotalStock : null) : (this.state.TM_GetYearlyStockByType?.length > 0 ? this.state.TM_GetYearlyStockByType[0].objectiveTotalStock : null)));

			formVars.yearlyallocationcopy_53578_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetYearlyStockByType !== undefined ? (stateVars.TM_GetYearlyStockByType?.length > 0 ? stateVars.TM_GetYearlyStockByType[0].objectiveRemainingStock : null) : (this.state.TM_GetYearlyStockByType?.length > 0 ? this.state.TM_GetYearlyStockByType[0].objectiveRemainingStock : null)));

			formVars.yearlyallocationcopy_251721_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetYearlyStockByType !== undefined ? (stateVars.TM_GetYearlyStockByType?.length > 0 ? stateVars.TM_GetYearlyStockByType[0].nonObjectiveTotalStock : null) : (this.state.TM_GetYearlyStockByType?.length > 0 ? this.state.TM_GetYearlyStockByType[0].nonObjectiveTotalStock : null)));

			formVars.yearlyallocationcopy_825869_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetYearlyStockByType !== undefined ? (stateVars.TM_GetYearlyStockByType?.length > 0 ? stateVars.TM_GetYearlyStockByType[0].nonObjectiveRemainingStock : null) : (this.state.TM_GetYearlyStockByType?.length > 0 ? this.state.TM_GetYearlyStockByType[0].nonObjectiveRemainingStock : null)));

			stateVars.isComp359636Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, (stateVars.TM_TotalVerifyExcel !== undefined ? (stateVars.TM_TotalVerifyExcel?.length > 0 ? stateVars.TM_TotalVerifyExcel[0].result : null) : (this.state.TM_TotalVerifyExcel?.length > 0 ? this.state.TM_TotalVerifyExcel[0].result : null))), ReactSystemFunctions.convertToTypeByName("1", "string"))) === true ? "visible" : "hidden")
			formVars.yearlyallocationcopy_473070_value = ReactSystemFunctions.toString(this, (stateVars.TM_TotalVerifyExcel !== undefined ? (stateVars.TM_TotalVerifyExcel?.length > 0 ? stateVars.TM_TotalVerifyExcel[0].kotaDurumu : null) : (this.state.TM_TotalVerifyExcel?.length > 0 ? this.state.TM_TotalVerifyExcel[0].kotaDurumu : null)));

			
			stateVars.dataSource_586612 = stateVars.TM_TotalVerifyExcel ?? this.state.TM_TotalVerifyExcel;
			
			stateVars.dataSource_831638 = stateVars.TM_GetAnnualProductReferences ?? this.state.TM_GetAnnualProductReferences;
			stateVars.dataSource_831638 = stateVars.TM_GetAnnualProductReferences ?? this.state.TM_GetAnnualProductReferences;
			stateVars.isComp950574Visible = ((ReactSystemFunctions.isNotEmpty(ReactSystemFunctions.toString(this, (stateVars.TM_YearlyStockControlByStore !== undefined ? (stateVars.TM_YearlyStockControlByStore?.length > 0 ? stateVars.TM_YearlyStockControlByStore[0].storeName : null) : (this.state.TM_YearlyStockControlByStore?.length > 0 ? this.state.TM_YearlyStockControlByStore[0].storeName : null))), ReactSystemFunctions.convertToTypeByName("True", "string"))) === true ? "visible" : "hidden")
			
			stateVars.dataSource_427664 = stateVars.TM_YearlyStockControlByStore ?? this.state.TM_YearlyStockControlByStore;
			stateVars.isComp215116Visible = ((ReactSystemFunctions.isNotEmpty(ReactSystemFunctions.toString(this, (stateVars.TM_YearlyStockControlByStore !== undefined ? (stateVars.TM_YearlyStockControlByStore?.length > 0 ? stateVars.TM_YearlyStockControlByStore[0].message : null) : (this.state.TM_YearlyStockControlByStore?.length > 0 ? this.state.TM_YearlyStockControlByStore[0].message : null))), ReactSystemFunctions.convertToTypeByName("True", "string"))) === true ? "visible" : "hidden")
			formVars.yearlyallocationcopy_313540_value = ReactSystemFunctions.toString(this, (stateVars.TM_YearlyStockControlByStore !== undefined ? (stateVars.TM_YearlyStockControlByStore?.length > 0 ? stateVars.TM_YearlyStockControlByStore[0].message : null) : (this.state.TM_YearlyStockControlByStore?.length > 0 ? this.state.TM_YearlyStockControlByStore[0].message : null)));

			
			stateVars.dataSource_448499 = stateVars.Action1 ?? this.state.Action1;
			stateVars.isComp313770Visible = ((ReactSystemFunctions.isGreaterOrEqual(ReactSystemFunctions.value(this, "yearlyallocationcopy_448499_value", "kalanStok"), ReactSystemFunctions.convertToTypeByName("0", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp123120Visible = ((ReactSystemFunctions.isLessThan(ReactSystemFunctions.value(this, "yearlyallocationcopy_448499_value", "kalanStok"), ReactSystemFunctions.convertToTypeByName("0", "string"))) === true ? "visible" : "hidden")

	this.props.form?.setFieldsValue(formVars);
	this.setState(stateVars);
	KuikaAppManager.hideSpinner(this);

            this.setPageInitLoaded(true);
            return isErrorOccurred;
        }




		YearlyAllocationcopyComponent_108036_onClick = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
KuikaAppManager.showSpinner(this);

				stateVars.GoBack = await ReactSystemFunctions.goBack(this, false);

		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

            
            return isErrorOccurred;
        }


		YearlyAllocationcopyComponent_401242_onClick = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
KuikaAppManager.showSpinner(this);

const __currentPath = (window.location.hash ? window.location.hash.replace(/^#/, '').split('?')[0] : window.location.pathname.split('?')[0]).toLowerCase();
if (__currentPath !== "/monthlyallocationcopy") {
  this.context.setMasterPageInitLoaded(false);
  this.context.setMasterPageRecurringLoaded(false);
  this.context.setShouldTriggerPageInit(true);
}
					KuikaAppManager.prepareForNavigation();
						KuikaAppManager.addToPageInputVariables("MonthlyAllocationcopy", "Year", ReactSystemFunctions.convertToTypeByName(this.props.screenInputs.Year ?? this.props.screenInputs.year, "string"));

				stateVars.NAVIGATE = await ReactSystemFunctions.navigate(this, undefined, "YearlyAllocationcopy", "MonthlyAllocationcopy", "", "currentPage", null, null, null, null, null, null, true, false);

		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

            
            return isErrorOccurred;
        }


    YearlyAllocationcopyComponent_762005_onBlur = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
		KuikaAppManager.increaseServerRequestCount();

        let localVar = {
				StoreName_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.convertToTypeByName("Adana", "string"), "string"),
				Value_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "Table_586612_adana", "value", "", "", "")), "number"),
				Year_0: ReactSystemFunctions.convertToTypeByName(this.props.screenInputs.Year ?? this.props.screenInputs.year, "string")
        }

		KuikaAppManager.showSpinner(this);
		
        if (true) {
        KuikaAppManager.showSpinner(this);
        }
        let result = await KuikaAppManager.ApiRequest(this, "YearlyAllocationcopy/YearlyAllocationcopyComponent_762005_onBlur", localVar)
        if (!KMainFunctions.IsResStatus2XX(result)) return true;

			stateVars.TM_StoreAnnualTotalUpdate = result?.data.tM_StoreAnnualTotalUpdate;
			this.props.form?.setFieldsValue(formVars);
			
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.YearlyAllocationcopyComponent_762005_onBlur1_();
                  resolve();
                });
          })



        
        KuikaAppManager.hideSpinner(this);
        return isErrorOccurred;
    }
		YearlyAllocationcopyComponent_762005_onBlur1_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }

				await this.YearlyAllocationcopyPageInit();
				

		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

            
            return isErrorOccurred;
        }




    YearlyAllocationcopyComponent_520234_onBlur = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
		KuikaAppManager.increaseServerRequestCount();

        let localVar = {
				StoreName_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.convertToTypeByName("Antalya", "string"), "string"),
				Value_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "Table_586612_antalya", "value", "", "", "")), "number"),
				Year_0: ReactSystemFunctions.convertToTypeByName(this.props.screenInputs.Year ?? this.props.screenInputs.year, "string")
        }

		KuikaAppManager.showSpinner(this);
		
        if (true) {
        KuikaAppManager.showSpinner(this);
        }
        let result = await KuikaAppManager.ApiRequest(this, "YearlyAllocationcopy/YearlyAllocationcopyComponent_520234_onBlur", localVar)
        if (!KMainFunctions.IsResStatus2XX(result)) return true;

			stateVars.TM_StoreAnnualTotalUpdate = result?.data.tM_StoreAnnualTotalUpdate;
			this.props.form?.setFieldsValue(formVars);
			
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.YearlyAllocationcopyComponent_520234_onBlur1_();
                  resolve();
                });
          })



        
        KuikaAppManager.hideSpinner(this);
        return isErrorOccurred;
    }
		YearlyAllocationcopyComponent_520234_onBlur1_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }

				await this.YearlyAllocationcopyPageInit();
				

		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

            
            return isErrorOccurred;
        }




    YearlyAllocationcopyComponent_914243_onBlur = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
		KuikaAppManager.increaseServerRequestCount();

        let localVar = {
				StoreName_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.convertToTypeByName("Gaziantep", "string"), "string"),
				Value_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "Table_586612_gaziantep", "value", "", "", "")), "number"),
				Year_0: ReactSystemFunctions.convertToTypeByName(this.props.screenInputs.Year ?? this.props.screenInputs.year, "string")
        }

		KuikaAppManager.showSpinner(this);
		
        if (true) {
        KuikaAppManager.showSpinner(this);
        }
        let result = await KuikaAppManager.ApiRequest(this, "YearlyAllocationcopy/YearlyAllocationcopyComponent_914243_onBlur", localVar)
        if (!KMainFunctions.IsResStatus2XX(result)) return true;

			stateVars.TM_StoreAnnualTotalUpdate = result?.data.tM_StoreAnnualTotalUpdate;
			this.props.form?.setFieldsValue(formVars);
			
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.YearlyAllocationcopyComponent_914243_onBlur1_();
                  resolve();
                });
          })



        
        KuikaAppManager.hideSpinner(this);
        return isErrorOccurred;
    }
		YearlyAllocationcopyComponent_914243_onBlur1_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }

				await this.YearlyAllocationcopyPageInit();
				

		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

            
            return isErrorOccurred;
        }




    YearlyAllocationcopyComponent_804414_onBlur = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
		KuikaAppManager.increaseServerRequestCount();

        let localVar = {
				StoreName_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.convertToTypeByName("Mersin", "string"), "string"),
				Value_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "Table_586612_mersin", "value", "", "", "")), "number"),
				Year_0: ReactSystemFunctions.convertToTypeByName(this.props.screenInputs.Year ?? this.props.screenInputs.year, "string")
        }

		KuikaAppManager.showSpinner(this);
		
        if (true) {
        KuikaAppManager.showSpinner(this);
        }
        let result = await KuikaAppManager.ApiRequest(this, "YearlyAllocationcopy/YearlyAllocationcopyComponent_804414_onBlur", localVar)
        if (!KMainFunctions.IsResStatus2XX(result)) return true;

			stateVars.TM_StoreAnnualTotalUpdate = result?.data.tM_StoreAnnualTotalUpdate;
			this.props.form?.setFieldsValue(formVars);
			
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.YearlyAllocationcopyComponent_804414_onBlur1_();
                  resolve();
                });
          })



        
        KuikaAppManager.hideSpinner(this);
        return isErrorOccurred;
    }
		YearlyAllocationcopyComponent_804414_onBlur1_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }

				await this.YearlyAllocationcopyPageInit();
				

		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

            
            return isErrorOccurred;
        }




    YearlyAllocationcopyComponent_474310_onBlur = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
		KuikaAppManager.increaseServerRequestCount();

        let localVar = {
				StoreName_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.convertToTypeByName("Merkez", "string"), "string"),
				Value_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "Table_586612_merkez", "value", "", "", "")), "number"),
				Year_0: ReactSystemFunctions.convertToTypeByName(this.props.screenInputs.Year ?? this.props.screenInputs.year, "string")
        }

		KuikaAppManager.showSpinner(this);
		
        if (true) {
        KuikaAppManager.showSpinner(this);
        }
        let result = await KuikaAppManager.ApiRequest(this, "YearlyAllocationcopy/YearlyAllocationcopyComponent_474310_onBlur", localVar)
        if (!KMainFunctions.IsResStatus2XX(result)) return true;

			stateVars.TM_StoreAnnualTotalUpdate = result?.data.tM_StoreAnnualTotalUpdate;
			this.props.form?.setFieldsValue(formVars);
			
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.YearlyAllocationcopyComponent_474310_onBlur1_();
                  resolve();
                });
          })



        
        KuikaAppManager.hideSpinner(this);
        return isErrorOccurred;
    }
		YearlyAllocationcopyComponent_474310_onBlur1_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }

				await this.YearlyAllocationcopyPageInit();
				

		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

            
            return isErrorOccurred;
        }




    YearlyAllocationcopyComponent_831638_onChange = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
		KuikaAppManager.increaseServerRequestCount();

        let localVar = {
				Yearn_0: ReactSystemFunctions.convertToTypeByName(this.props.screenInputs.Year ?? this.props.screenInputs.year, "string"),
				RefNo_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "yearlyallocationcopy_831638_value", "value", "TM_GetAnnualProductReferences", "refNo", "refNo")), "string")
        }

		KuikaAppManager.showSpinner(this);
if (ReactSystemFunctions.isNotEmpty(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "yearlyallocationcopy_831638_value", "value", "TM_GetAnnualProductReferences", "refNo", "refNo")), ReactSystemFunctions.convertToTypeByName("True", "string"))) {
            		
        if (true) {
        KuikaAppManager.showSpinner(this);
        }
        let result = await KuikaAppManager.ApiRequest(this, "YearlyAllocationcopy/YearlyAllocationcopyComponent_831638_onChange", localVar)
        if (!KMainFunctions.IsResStatus2XX(result)) return true;

			stateVars.Action1 = result?.data.action1;
			
			this.props.form?.setFieldsValue(formVars);
			
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.YearlyAllocationcopyComponent_831638_onChange1_();
                  resolve();
                });
          })

        } else {
            
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.YearlyAllocationcopyComponent_831638_onChange1_();
                  resolve();
                });
          })
        }


        
        KuikaAppManager.hideSpinner(this);
        return isErrorOccurred;
    }
    YearlyAllocationcopyComponent_831638_onChange1_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
		KuikaAppManager.increaseServerRequestCount();

        let localVar = {
				Yearn_0: ReactSystemFunctions.convertToTypeByName(this.props.screenInputs.Year ?? this.props.screenInputs.year, "string"),
				RefNo_0: ReactSystemFunctions.convertToTypeByName(null, "string")
        }

if (ReactSystemFunctions.isEmpty(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "yearlyallocationcopy_831638_value", "value", "TM_GetAnnualProductReferences", "refNo", "refNo")), ReactSystemFunctions.convertToTypeByName("True", "string"))) {
            		
        if (true) {
        KuikaAppManager.showSpinner(this);
        }
        let result = await KuikaAppManager.ApiRequest(this, "YearlyAllocationcopy/YearlyAllocationcopyComponent_831638_onChange1_", localVar)
        if (!KMainFunctions.IsResStatus2XX(result)) return true;

			stateVars.Action1 = result?.data.action1;
			
			this.props.form?.setFieldsValue(formVars);
			
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.YearlyAllocationcopyComponent_831638_onChange2_();
                  resolve();
                });
          })

        } else {
            
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.YearlyAllocationcopyComponent_831638_onChange2_();
                  resolve();
                });
          })
        }


        
        KuikaAppManager.hideSpinner(this);
        return isErrorOccurred;
    }
		YearlyAllocationcopyComponent_831638_onChange2_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
if (ReactSystemFunctions.isNotEmpty(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "yearlyallocationcopy_831638_value", "value", "TM_GetAnnualProductReferences", "refNo", "refNo")), ReactSystemFunctions.convertToTypeByName("True", "string"))) {
            
				

		this.props.form?.setFieldsValue(formVars);
		
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.YearlyAllocationcopyComponent_831638_onChange3_();
                  resolve();
                });
          })

        } else {
            
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.YearlyAllocationcopyComponent_831638_onChange3_();
                  resolve();
                });
          })
        }

            
            return isErrorOccurred;
        }
		YearlyAllocationcopyComponent_831638_onChange3_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
if (ReactSystemFunctions.isNotEmpty(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "yearlyallocationcopy_831638_value", "value", "TM_GetAnnualProductReferences", "refNo", "refNo")), ReactSystemFunctions.convertToTypeByName("True", "string"))) {
            
				stateVars.dataSource_448499 = stateVars.Action1 ?? this.state.Action1;

		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

        } else {
            KuikaAppManager.hideSpinner(this);
        }

            
            return isErrorOccurred;
        }







    YearlyAllocationcopyComponent_171380_onBlur = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
		KuikaAppManager.increaseServerRequestCount();

        let localVar = {
				StoreName_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.convertToTypeByName("Adana", "string"), "string"),
				RefNo_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, "yearlyallocationcopy_448499_value", "urunKodu"), "string"),
				Year_0: ReactSystemFunctions.convertToTypeByName(this.props.screenInputs.Year ?? this.props.screenInputs.year, "string"),
				UsedStock_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "yearlyallocationcopy_171380_value", "value", "", "", "")), "number")
        }

		KuikaAppManager.showSpinner(this);
		
        if (true) {
        KuikaAppManager.showSpinner(this);
        }
        let result = await KuikaAppManager.ApiRequest(this, "YearlyAllocationcopy/YearlyAllocationcopyComponent_171380_onBlur", localVar)
        if (!KMainFunctions.IsResStatus2XX(result)) return true;

			stateVars.Action2 = result?.data.action2;
			this.props.form?.setFieldsValue(formVars);
			
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.YearlyAllocationcopyComponent_171380_onBlur1_();
                  resolve();
                });
          })



        
        KuikaAppManager.hideSpinner(this);
        return isErrorOccurred;
    }
		YearlyAllocationcopyComponent_171380_onBlur1_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }

				await this.YearlyAllocationcopyPageInit();
				

		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

            
            return isErrorOccurred;
        }




    YearlyAllocationcopyComponent_979362_onBlur = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
		KuikaAppManager.increaseServerRequestCount();

        let localVar = {
				StoreName_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.convertToTypeByName("Antalya", "string"), "string"),
				RefNo_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, "yearlyallocationcopy_448499_value", "urunKodu"), "string"),
				Year_0: ReactSystemFunctions.convertToTypeByName(this.props.screenInputs.Year ?? this.props.screenInputs.year, "string"),
				UsedStock_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "yearlyallocationcopy_979362_value", "value", "", "", "")), "number")
        }

		KuikaAppManager.showSpinner(this);
		
        if (true) {
        KuikaAppManager.showSpinner(this);
        }
        let result = await KuikaAppManager.ApiRequest(this, "YearlyAllocationcopy/YearlyAllocationcopyComponent_979362_onBlur", localVar)
        if (!KMainFunctions.IsResStatus2XX(result)) return true;

			stateVars.Action2 = result?.data.action2;
			this.props.form?.setFieldsValue(formVars);
			
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.YearlyAllocationcopyComponent_979362_onBlur1_();
                  resolve();
                });
          })



        
        KuikaAppManager.hideSpinner(this);
        return isErrorOccurred;
    }
		YearlyAllocationcopyComponent_979362_onBlur1_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }

				await this.YearlyAllocationcopyPageInit();
				

		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

            
            return isErrorOccurred;
        }




    YearlyAllocationcopyComponent_946036_onBlur = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
		KuikaAppManager.increaseServerRequestCount();

        let localVar = {
				StoreName_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.convertToTypeByName("Gaziantep", "string"), "string"),
				RefNo_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, "yearlyallocationcopy_448499_value", "urunKodu"), "string"),
				Year_0: ReactSystemFunctions.convertToTypeByName(this.props.screenInputs.Year ?? this.props.screenInputs.year, "string"),
				UsedStock_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "yearlyallocationcopy_946036_value", "value", "", "", "")), "number")
        }

		KuikaAppManager.showSpinner(this);
		
        if (true) {
        KuikaAppManager.showSpinner(this);
        }
        let result = await KuikaAppManager.ApiRequest(this, "YearlyAllocationcopy/YearlyAllocationcopyComponent_946036_onBlur", localVar)
        if (!KMainFunctions.IsResStatus2XX(result)) return true;

			stateVars.Action2 = result?.data.action2;
			this.props.form?.setFieldsValue(formVars);
			
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.YearlyAllocationcopyComponent_946036_onBlur1_();
                  resolve();
                });
          })



        
        KuikaAppManager.hideSpinner(this);
        return isErrorOccurred;
    }
		YearlyAllocationcopyComponent_946036_onBlur1_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }

				await this.YearlyAllocationcopyPageInit();
				

		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

            
            return isErrorOccurred;
        }




    YearlyAllocationcopyComponent_498350_onBlur = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
		KuikaAppManager.increaseServerRequestCount();

        let localVar = {
				StoreName_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.convertToTypeByName("Mersin", "string"), "string"),
				RefNo_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, "yearlyallocationcopy_448499_value", "urunKodu"), "string"),
				Year_0: ReactSystemFunctions.convertToTypeByName(this.props.screenInputs.Year ?? this.props.screenInputs.year, "string"),
				UsedStock_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "yearlyallocationcopy_171380_value", "value", "", "", "")), "number")
        }

		KuikaAppManager.showSpinner(this);
		
        if (true) {
        KuikaAppManager.showSpinner(this);
        }
        let result = await KuikaAppManager.ApiRequest(this, "YearlyAllocationcopy/YearlyAllocationcopyComponent_498350_onBlur", localVar)
        if (!KMainFunctions.IsResStatus2XX(result)) return true;

			stateVars.Action2 = result?.data.action2;
			this.props.form?.setFieldsValue(formVars);
			
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.YearlyAllocationcopyComponent_498350_onBlur1_();
                  resolve();
                });
          })



        
        KuikaAppManager.hideSpinner(this);
        return isErrorOccurred;
    }
		YearlyAllocationcopyComponent_498350_onBlur1_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }

				await this.YearlyAllocationcopyPageInit();
				

		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

            
            return isErrorOccurred;
        }




    YearlyAllocationcopyComponent_571122_onBlur = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
		KuikaAppManager.increaseServerRequestCount();

        let localVar = {
				StoreName_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.convertToTypeByName("Merkez", "string"), "string"),
				RefNo_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, "yearlyallocationcopy_448499_value", "urunKodu"), "string"),
				Year_0: ReactSystemFunctions.convertToTypeByName(this.props.screenInputs.Year ?? this.props.screenInputs.year, "string"),
				UsedStock_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "yearlyallocationcopy_571122_value", "value", "", "", "")), "number")
        }

		KuikaAppManager.showSpinner(this);
		
        if (true) {
        KuikaAppManager.showSpinner(this);
        }
        let result = await KuikaAppManager.ApiRequest(this, "YearlyAllocationcopy/YearlyAllocationcopyComponent_571122_onBlur", localVar)
        if (!KMainFunctions.IsResStatus2XX(result)) return true;

			stateVars.Action2 = result?.data.action2;
			this.props.form?.setFieldsValue(formVars);
			
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.YearlyAllocationcopyComponent_571122_onBlur1_();
                  resolve();
                });
          })



        
        KuikaAppManager.hideSpinner(this);
        return isErrorOccurred;
    }
		YearlyAllocationcopyComponent_571122_onBlur1_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }

				await this.YearlyAllocationcopyPageInit();
				

		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

            
            return isErrorOccurred;
        }






    async callCallbackFunction(diId: number, isFromMaster: boolean = false) {
        let isErrorOccurred = false;
		let pageInitCallerNavDiIDs = [] as number[];
		if (isFromMaster || pageInitCallerNavDiIDs.indexOf(diId) > -1) {
			await this.YearlyAllocationcopyPageInit();
		}

    }


}
