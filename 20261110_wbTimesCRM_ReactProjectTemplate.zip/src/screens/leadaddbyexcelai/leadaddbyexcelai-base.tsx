import React from "react";
import Axios, { AxiosResponse } from "axios";
import { KuikaAppManager } from "../../shared/utilty/kuika-app-manager";
import { ReactSystemFunctions } from "../../shared/utilty/react-system-functions";
import { KNavigator } from "../../shared/hoc/with-history";
import { KContext } from "../../shared/hoc/with-context";
import { useLocation } from "react-router-dom";
import { FormInstance } from "antd/es/form";
import { Guid } from "guid-typescript";
import Swal from "sweetalert2";
import { KMainFunctions } from "../../shared/utilty/main-functions";
import moment from "moment";
import { IValidationData } from "../../models/dto/validation-data";
import { IStripePayment } from "../../models/dto/stripe-payment";
import { IUserInfoDto } from "../../models/dto/user-info.dto";
import { UserService } from "../../services/user-service";
import { kuikaCoreWasmBridgeService } from "../../services/_singletons";
import _ from "lodash";
import mqtt, { MqttClient } from "mqtt";
import { IMqttResult } from "../../models/dto/mqtt.dto";
import { MasterScreen_ScreenContext } from "../masterscreen/masterscreen-context";

declare let window: any;

export interface ILeadAddByExcelAI_ScreenProps {
  navigator: KNavigator;
  form: FormInstance<any>;
  googleLogin: any;
  screenInputs: any;
  context: KContext;
  initialValues: any;
  children: any;
}

export interface ILeadAddByExcelAI_ScreenState {
    isSpinnerVisible: boolean;
    isPageVisible: boolean;
	isLeftMenuVisible: boolean;
    spinnerCount: number;
    selectedLanguage: string;
    isPageInitLoaded: false;
    isPageRecurringLoaded: false;
	TM_GetProductBrand: any[];
	TM_GetProductBrand_dummy: any[];
	TM_GetCustomerByName: any[];
	TM_GetCustomerByName_dummy: any[];
	TM_GetLeadStatus: any[];
	TM_GetLeadStatus_dummy: any[];
	TM_StoreGetList: any[];
	TM_StoreGetList_dummy: any[];
	TS_GetStoreUsers: any[];
	TS_GetStoreUsers_dummy: any[];
	TM_GetLeadNextSteps: any[];
	TM_GetLeadNextSteps_dummy: any[];
	TM_GetAllContactSource: any[];
	TM_GetAllContactSource_dummy: any[];
	GetLeadProcessForExcel: any[];
	GetLeadProcessForExcel_dummy: any[];
	TM_GetAppUser: any[];
	TM_GetAppUser_dummy: any[];
	GetSalesPersonByStore: any[];
	GetSalesPersonByStore_dummy: any[];
	SYSTEMGetId: any[];
	SYSTEMGetId_dummy: any[];
	NAVIGATE: any;
	NAVIGATE_dummy: any;
	TM_GetCustomerById: any[];
	TM_GetCustomerById_dummy: any[];
	TM_GetReferanceByCurrAccCode: any[];
	TM_GetReferanceByCurrAccCode_dummy: any[];
	TM_GetReferenceCustomerById: any[];
	TM_GetReferenceCustomerById_dummy: any[];
	SetValueOf: any;
	SetValueOf_dummy: any;
	ChangeVisibilityOf: string;
	ChangeVisibilityOf_dummy: string;
	TM_GetProductReferance: any[];
	TM_GetProductReferance_dummy: any[];
	TM_GetProductDial: any[];
	TM_GetProductDial_dummy: any[];
	TM_GetProductBracelet: any[];
	TM_GetProductBracelet_dummy: any[];
	TM_GetProduct: any[];
	TM_GetProduct_dummy: any[];
	LeadAddExcel: any[];
	LeadAddExcel_dummy: any[];
	Notify: boolean;
	Notify_dummy: boolean;
	GoBack: any;
	GoBack_dummy: any;
	isComp612838Visible: 'visible' | 'hidden';
	isComp713885Visible: 'visible' | 'hidden';
	isComp572255Visible: 'visible' | 'hidden';
	isComp582991Visible: 'visible' | 'hidden';
	isComp297847Visible: 'visible' | 'hidden';
	isComp102553Visible: 'visible' | 'hidden';
	isComp189761Visible: 'visible' | 'hidden';
	isComp297930Visible: 'visible' | 'hidden';
	isComp222316Visible: 'visible' | 'hidden';
	isComp331261Visible: 'visible' | 'hidden';
	isComp584916Visible: 'visible' | 'hidden';
	isComp797949Visible: 'visible' | 'hidden';
	isComp484797Visible: 'visible' | 'hidden';
	isComp795672Visible: 'visible' | 'hidden';
	isComp980874Visible: 'visible' | 'hidden';
	isComp684975Visible: 'visible' | 'hidden';
	isComp981281Enabled: 'enabled' | 'disabled';

}

export class LeadAddByExcelAI_ScreenBase extends React.PureComponent<ILeadAddByExcelAI_ScreenProps, any> {
    static contextType = MasterScreen_ScreenContext;
    declare context: React.ContextType<typeof MasterScreen_ScreenContext>;
	leadaddbyexcelai_237650_value_kuikaDateRef: React.RefObject<any>;
	leadaddbyexcelai_981281_value_kuikaAutoCompleteRef: React.RefObject<any>;
	leadaddbyexcelai_991992_value_kuikaAutoCompleteRef: React.RefObject<any>;
	leadaddbyexcelai_598679_value_kuikaAutoCompleteRef: React.RefObject<any>;
	leadaddbyexcelai_537845_value_kuikaAutoCompleteRef: React.RefObject<any>;
	leadaddbyexcelai_221998_value_kuikaAutoCompleteRef: React.RefObject<any>;
	leadaddbyexcelai_428403_value_kuikaAutoCompleteRef: React.RefObject<any>;
	leadaddbyexcelai_888506_value_kuikaAutoCompleteRef: React.RefObject<any>;
	leadaddbyexcelai_709894_value_kuikaAutoCompleteRef: React.RefObject<any>;
	leadaddbyexcelai_806227_value_kuikaAutoCompleteRef: React.RefObject<any>;
	leadaddbyexcelai_980478_value_kuikaAutoCompleteRef: React.RefObject<any>;
	leadaddbyexcelai_145272_value_kuikaAutoCompleteRef: React.RefObject<any>;
	leadaddbyexcelai_894616_value_kuikaAutoCompleteRef: React.RefObject<any>;
	leadaddbyexcelai_224565_value_kuikaAutoCompleteRef: React.RefObject<any>;
	leadaddbyexcelai_201361_value_kuikaAutoCompleteRef: React.RefObject<any>;
	leadaddbyexcelai_276724_value_kuikaAutoCompleteRef: React.RefObject<any>;
    ml=[{"Id":"d5a61d2b-bd60-485f-86e2-661e9ed4e486","Name":"en_US","ShortName":"English","IsDefault":true,"LanguagePhrases":[]},{"Id":"c62958df-5463-4e50-9992-234e7ac38d11","Name":"FixedValues","ShortName":"FixedValues","LanguagePhrases":[{"Id":887158,"PropertyName":"value","Value":"Geciken Lead Giriş Ekranı"},{"Id":521466,"PropertyName":"value","Value":"Gecikmiş leadlerinizi tek ekranda oluşturun."},{"Id":488457,"PropertyName":"value","Value":"Genel Bilgiler"},{"Id":913766,"PropertyName":"value","Value":"Oluşturulma Tarihi"},{"Id":237650,"PropertyName":"placeholder","Value":"Oluşturulma Tarihi Giriniz..."},{"Id":188004,"PropertyName":"value","Value":"Oluşturan Kişi"},{"Id":981281,"PropertyName":"placeholder","Value":"Oluşturan Kişiyi Seçiniz..."},{"Id":489684,"PropertyName":"value","Value":"Açılan Mağaza"},{"Id":991992,"PropertyName":"placeholder","Value":"Açılan Mağazayı Seçiniz..."},{"Id":55040,"PropertyName":"value","Value":"Satış Personeli"},{"Id":598679,"PropertyName":"placeholder","Value":"Satış Personeli Seçiniz..."},{"Id":819542,"PropertyName":"value","Value":"Müşteri Bilgileri"},{"Id":999939,"PropertyName":"label","Value":"Hızlı Müşteri Oluştur"},{"Id":966558,"PropertyName":"value","Value":"Müşteri"},{"Id":537845,"PropertyName":"placeholder","Value":"Müşteri Seçiniz..."},{"Id":349369,"PropertyName":"value","Value":"Müşteri Bilgileri"},{"Id":495488,"PropertyName":"value","Value":"Müşteri Adı"},{"Id":774123,"PropertyName":"value","Value":"TC"},{"Id":802329,"PropertyName":"value","Value":"Telefon No"},{"Id":146701,"PropertyName":"value","Value":"E-mail"},{"Id":235306,"PropertyName":"value","Value":"Lokasyon"},{"Id":782256,"PropertyName":"value","Value":"Alışveriş Var Mı?"},{"Id":189761,"PropertyName":"value","Value":"Var"},{"Id":297930,"PropertyName":"value","Value":"Yok"},{"Id":766712,"PropertyName":"value","Value":"Referans Bilgileri"},{"Id":344615,"PropertyName":"label","Value":"Hızlı Referans Oluştur"},{"Id":703267,"PropertyName":"value","Value":"Referans(Varsa)"},{"Id":221998,"PropertyName":"placeholder","Value":"Referans Seçiniz..."},{"Id":570775,"PropertyName":"value","Value":"Referans Bilgileri"},{"Id":207720,"PropertyName":"value","Value":"Referans Adı"},{"Id":46203,"PropertyName":"value","Value":"Referans Soyadı"},{"Id":473556,"PropertyName":"value","Value":"TC / Pasaport No"},{"Id":207290,"PropertyName":"value","Value":"Telefon"},{"Id":55119,"PropertyName":"value","Value":"Ürün Bilgileri"},{"Id":15677,"PropertyName":"value","Value":"Marka"},{"Id":428403,"PropertyName":"placeholder","Value":"Marka"},{"Id":934920,"PropertyName":"value","Value":"Referans"},{"Id":888506,"PropertyName":"placeholder","Value":"Referans"},{"Id":486989,"PropertyName":"value","Value":"Kadran"},{"Id":709894,"PropertyName":"placeholder","Value":"Kadran"},{"Id":635776,"PropertyName":"value","Value":"Bilezik"},{"Id":806227,"PropertyName":"placeholder","Value":"Bilezik"},{"Id":154461,"PropertyName":"value","Value":"Ürün Bilgileri"},{"Id":595957,"PropertyName":"value","Value":"Ürün Adı"},{"Id":740106,"PropertyName":"value","Value":"Kategori"},{"Id":980874,"PropertyName":"value","Value":"DEFAULT"},{"Id":893362,"PropertyName":"value","Value":"Lead Bilgileri"},{"Id":845277,"PropertyName":"value","Value":"Lead Durumu"},{"Id":980478,"PropertyName":"placeholder","Value":"Lead Durumu"},{"Id":803781,"PropertyName":"value","Value":"Sonraki Adım"},{"Id":145272,"PropertyName":"placeholder","Value":"Sonraki Adım"},{"Id":324204,"PropertyName":"value","Value":"İletişim Kaynağı"},{"Id":894616,"PropertyName":"placeholder","Value":"İletişim Kaynağı Seçiniz"},{"Id":916863,"PropertyName":"value","Value":"Talep Notu"},{"Id":715637,"PropertyName":"placeholder","Value":"Talep Notu"},{"Id":514829,"PropertyName":"value","Value":"Termin Tarihi Bulunuyor İse Seçiniz"},{"Id":224565,"PropertyName":"placeholder","Value":"Yıl"},{"Id":201361,"PropertyName":"placeholder","Value":"Ay"},{"Id":200927,"PropertyName":"value","Value":"Lead'in Anlık Sürecini Seçiniz"},{"Id":276724,"PropertyName":"placeholder","Value":"Lead Sürecini Seçiniz"},{"Id":556512,"PropertyName":"value","Value":"İşlem Aksiyonları"},{"Id":601667,"PropertyName":"label","Value":"Vazgeç"},{"Id":615093,"PropertyName":"label","Value":"Lead Oluştur"}]}]
    defaultML = "en_US"
    
    screenHash = ""
    

    private _prevMasterPageInitLoaded: boolean = false;
    private _prevMasterPageRecurringLoaded: boolean = false;
    private _prevShouldTriggerPageInit: boolean = false;
    constructor(props) {
        super(props);
		this.leadaddbyexcelai_237650_value_kuikaDateRef = React.createRef();
		this.leadaddbyexcelai_981281_value_kuikaAutoCompleteRef = React.createRef();
		this.leadaddbyexcelai_991992_value_kuikaAutoCompleteRef = React.createRef();
		this.leadaddbyexcelai_598679_value_kuikaAutoCompleteRef = React.createRef();
		this.leadaddbyexcelai_537845_value_kuikaAutoCompleteRef = React.createRef();
		this.leadaddbyexcelai_221998_value_kuikaAutoCompleteRef = React.createRef();
		this.leadaddbyexcelai_428403_value_kuikaAutoCompleteRef = React.createRef();
		this.leadaddbyexcelai_888506_value_kuikaAutoCompleteRef = React.createRef();
		this.leadaddbyexcelai_709894_value_kuikaAutoCompleteRef = React.createRef();
		this.leadaddbyexcelai_806227_value_kuikaAutoCompleteRef = React.createRef();
		this.leadaddbyexcelai_980478_value_kuikaAutoCompleteRef = React.createRef();
		this.leadaddbyexcelai_145272_value_kuikaAutoCompleteRef = React.createRef();
		this.leadaddbyexcelai_894616_value_kuikaAutoCompleteRef = React.createRef();
		this.leadaddbyexcelai_224565_value_kuikaAutoCompleteRef = React.createRef();
		this.leadaddbyexcelai_201361_value_kuikaAutoCompleteRef = React.createRef();
		this.leadaddbyexcelai_276724_value_kuikaAutoCompleteRef = React.createRef();

        this.state = {
            isSpinnerVisible: false,
            isPageVisible: false,
            isLeftMenuVisible: false,
            spinnerCount: 0,
            selectedLanguage: "",
            isPageInitLoaded: false,
            isPageRecurringLoaded: false,
            	        TM_GetProductBrand: [],
	        TM_GetCustomerByName: [],
	        TM_GetLeadStatus: [],
	        TM_StoreGetList: [],
	        TS_GetStoreUsers: [],
	        TM_GetLeadNextSteps: [],
	        TM_GetAllContactSource: [],
	        GetLeadProcessForExcel: [],
	        TM_GetAppUser: [],
	        GetSalesPersonByStore: [],
	        SYSTEMGetId: [],
	        NAVIGATE: "",
	        TM_GetCustomerById: [],
	        TM_GetReferanceByCurrAccCode: [],
	        TM_GetReferenceCustomerById: [],
	        SetValueOf: "",
	        ChangeVisibilityOf: "",
	        TM_GetProductReferance: [],
	        TM_GetProductDial: [],
	        TM_GetProductBracelet: [],
	        TM_GetProduct: [],
	        LeadAddExcel: [],
	        Notify: false,
	        GoBack: "",
	        dataSource_224565: [{"key":"2025","text":"2025"},{"key":"2026","text":"2026"},{"key":"2027","text":"2027"},{"key":"2028","text":"2028"},{"key":"2029","text":"2029"},{"key":"2030","text":"2030"},{"key":"2031","text":"2031"},{"key":"2032","text":"2032"},{"key":"2033","text":"2033"},{"key":"2034","text":"2034"},{"key":"2035","text":"2035"}],
	        dataSource_201361: [{"key":"1","text":"Ocak"},{"key":"2","text":"Şubat"},{"key":"3","text":"Mart"},{"key":"4","text":"Nisan"},{"key":"5","text":"Mayıs"},{"key":"6","text":"Haziran"},{"key":"7","text":"Temmuz"},{"key":"8","text":"Ağustos"},{"key":"9","text":"Eylül"},{"key":"10","text":"Ekim"},{"key":"11","text":"Kasım"},{"key":"12","text":"Aralık"}],
	        isComp612838Visible: 'hidden',
	        isComp713885Visible: 'hidden',
	        isComp572255Visible: 'hidden',
	        isComp582991Visible: 'hidden',
	        isComp297847Visible: 'hidden',
	        isComp102553Visible: 'hidden',
	        isComp189761Visible: 'hidden',
	        isComp297930Visible: 'hidden',
	        isComp222316Visible: 'hidden',
	        isComp331261Visible: 'hidden',
	        isComp584916Visible: 'hidden',
	        isComp797949Visible: 'hidden',
	        isComp484797Visible: 'hidden',
	        isComp795672Visible: 'hidden',
	        isComp980874Visible: 'hidden',
	        isComp684975Visible: 'hidden',
	        isComp981281Enabled: 'disabled',

        }

        this.state.isPageVisible = true;
        
    }

    async componentDidMount() {

        if (KuikaAppManager.isPageInitPrevented()) {
            KuikaAppManager.calculateAndSetBodyHeight("leadaddbyexcelai", "masterscreen_screen");
            return;
        }
        this.context.registerCallbackFunction(this.callCallbackFunction.bind(this));
        
        ReactSystemFunctions.validateToken()
        this.fillFormInitValues();
        if (false){
            await this.LeadAddByExcelAIPageInit();
        } else if (this.context?.isMasterPageInitLoaded) { this._prevMasterPageInitLoaded = true; await this.LeadAddByExcelAIPageInit(); }
        
        
        
        KuikaAppManager.calculateAndSetBodyHeight("leadaddbyexcelai", "masterscreen_screen");

        if (ReactSystemFunctions.getIsMicroApp() === false) {
           window.parentScreen = this;
        }
    }

    componentWillUnmount() {
        
        
        

        if (ReactSystemFunctions.getIsMicroApp() === false) {
           window.parentScreen = null;
        }
    }

    

        
    componentDidUpdate= async (prevProps, prevState) => {
		KuikaAppManager.calculateAndSetBodyHeight("leadaddbyexcelai", "masterscreen_screen"    );
        if (prevProps?.location?.search !== (this.props as any)?.location?.search) {
			await this.LeadAddByExcelAIPageInit();
		}

        		if (this._prevMasterPageInitLoaded !== this.context.isMasterPageInitLoaded && this.context.isMasterPageInitLoaded === true) {this._prevMasterPageInitLoaded = this.context.isMasterPageInitLoaded;await this.LeadAddByExcelAIPageInit()}


        if (ReactSystemFunctions.getIsMicroApp() === false) {
            for (const key in prevState) {
                if (key.startsWith('NavVisible') && prevState[key] === true && this.state[key] === false) {
                    window.parentScreen = this;
                    break;
                }
            }
        }
	}

    fillFormInitValues() {
        this.props.form?.setFieldsValue({
});

    }

      setPageInitLoaded = (value: boolean) => {
        this.setState({ isPageInitLoaded: value });
      }

      setPageRecurringLoaded = (value: boolean) => {
        this.setState({ isPageRecurringLoaded: value });
      }

      clearFieldValidation = (changedValues: any) => {
        const fieldName = Object.keys(changedValues)[0];
        if (fieldName) {
          this.props.form?.setFields([
            {
              name: fieldName,
              errors: []
            }
          ]);
        }
      };

      

    LeadAddByExcelAIPageInit = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


	if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }

        let localVar = {
			KUserId_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.getMyUserId(), "Guid"),
			KUserId_4: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.getMyUserId(), "Guid"),
			StoreId_9: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, (stateVars.TS_GetStoreUsers !== undefined ? (stateVars.TS_GetStoreUsers?.length > 0 ? stateVars.TS_GetStoreUsers[0].storeID : null) : (this.state.TS_GetStoreUsers?.length > 0 ? this.state.TS_GetStoreUsers[0].storeID : null))), "Guid")
        }

	KuikaAppManager.showSpinner(this);
	
        if (true) {
        KuikaAppManager.showSpinner(this);
        }
        let result = await KuikaAppManager.ApiRequest(this, "LeadAddByExcelAI/LeadAddByExcelAIPageInit", localVar)
        if (!KMainFunctions.IsResStatus2XX(result)) return true;

		stateVars.TM_GetProductBrand = result?.data.tM_GetProductBrand;
		
		formVars.leadaddbyexcelai_428403_options = stateVars.TM_GetProductBrand;
		stateVars.TM_GetCustomerByName = result?.data.tM_GetCustomerByName;
		
		formVars.leadaddbyexcelai_537845_options = stateVars.TM_GetCustomerByName;
		stateVars.TM_GetLeadStatus = result?.data.tM_GetLeadStatus;
		
		formVars.leadaddbyexcelai_980478_options = stateVars.TM_GetLeadStatus;
		stateVars.TM_StoreGetList = result?.data.tM_StoreGetList;
		
		formVars.leadaddbyexcelai_991992_options = stateVars.TM_StoreGetList;
		stateVars.TS_GetStoreUsers = result?.data.tS_GetStoreUsers;
		stateVars.TM_GetLeadNextSteps = result?.data.tM_GetLeadNextSteps;
		
		formVars.leadaddbyexcelai_145272_options = stateVars.TM_GetLeadNextSteps;
		stateVars.TM_GetAllContactSource = result?.data.tM_GetAllContactSource;
		
		formVars.leadaddbyexcelai_894616_options = stateVars.TM_GetAllContactSource;
		stateVars.GetLeadProcessForExcel = result?.data.getLeadProcessForExcel;
		
		formVars.leadaddbyexcelai_276724_options = stateVars.GetLeadProcessForExcel;
		stateVars.TM_GetAppUser = result?.data.tM_GetAppUser;
		
		formVars.leadaddbyexcelai_981281_value = (stateVars.SYSTEMGetId !== undefined ? (stateVars.SYSTEMGetId?.length > 0 ? stateVars.SYSTEMGetId[0].kUserId : null) : (this.state.SYSTEMGetId?.length > 0 ? this.state.SYSTEMGetId[0].kUserId : null));
		formVars.leadaddbyexcelai_981281_options = stateVars.TM_GetAppUser;
		stateVars.GetSalesPersonByStore = result?.data.getSalesPersonByStore;
		
		formVars.leadaddbyexcelai_598679_options = stateVars.GetSalesPersonByStore;
		stateVars.SYSTEMGetId = result?.data.systemGetId;
		formVars.leadaddbyexcelai_981281_value = (stateVars.SYSTEMGetId !== undefined ? (stateVars.SYSTEMGetId?.length > 0 ? stateVars.SYSTEMGetId[0].kUserId : null) : (this.state.SYSTEMGetId?.length > 0 ? this.state.SYSTEMGetId[0].kUserId : null));
		formVars.leadaddbyexcelai_981281_options = stateVars.TM_GetAppUser;
		this.props.form?.setFieldsValue(formVars);
		
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.LeadAddByExcelAIPageInit1_();
                  resolve();
                });
          })



        
        KuikaAppManager.hideSpinner(this);
        return isErrorOccurred;
    }
	LeadAddByExcelAIPageInit1_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


	if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }

			stateVars.isComp713885Visible = ((ReactSystemFunctions.contains(ReactSystemFunctions.getMyRoleNames(), ReactSystemFunctions.convertToTypeByName("TimesAdmin", "string"))) === true ? "visible" : "hidden")
			formVars.leadaddbyexcelai_981281_value = ReactSystemFunctions.toString(this, (stateVars.SYSTEMGetId !== undefined ? (stateVars.SYSTEMGetId?.length > 0 ? stateVars.SYSTEMGetId[0].kUserId : null) : (this.state.SYSTEMGetId?.length > 0 ? this.state.SYSTEMGetId[0].kUserId : null)));

			
			stateVars.dataSource_981281 = stateVars.TM_GetAppUser ?? this.state.TM_GetAppUser;
			stateVars.dataSource_981281 = stateVars.TM_GetAppUser ?? this.state.TM_GetAppUser;
			stateVars.isComp572255Visible = (((ReactSystemFunctions.contains(ReactSystemFunctions.getMyRoleNames(), ReactSystemFunctions.convertToTypeByName("TimesYonetici", "string")) || ReactSystemFunctions.contains(ReactSystemFunctions.getMyRoleNames(), ReactSystemFunctions.convertToTypeByName("TimesUstYonetici", "string")))) === true ? "visible" : "hidden")
			
			stateVars.dataSource_991992 = stateVars.TM_StoreGetList ?? this.state.TM_StoreGetList;
			stateVars.dataSource_991992 = stateVars.TM_StoreGetList ?? this.state.TM_StoreGetList;
			stateVars.isComp582991Visible = (((ReactSystemFunctions.contains(ReactSystemFunctions.getMyRoleNames(), ReactSystemFunctions.convertToTypeByName("TimesYonetici", "string")) || ReactSystemFunctions.contains(ReactSystemFunctions.getMyRoleNames(), ReactSystemFunctions.convertToTypeByName("TimesUstYonetici", "string")) || ReactSystemFunctions.contains(ReactSystemFunctions.getMyRoleNames(), ReactSystemFunctions.convertToTypeByName("TimesMagazaMuduru", "string")))) === true ? "visible" : "hidden")
			
			stateVars.dataSource_598679 = stateVars.GetSalesPersonByStore ?? this.state.GetSalesPersonByStore;
			stateVars.dataSource_598679 = stateVars.GetSalesPersonByStore ?? this.state.GetSalesPersonByStore;
			
			stateVars.dataSource_537845 = stateVars.TM_GetCustomerByName ?? this.state.TM_GetCustomerByName;
			stateVars.dataSource_537845 = stateVars.TM_GetCustomerByName ?? this.state.TM_GetCustomerByName;
			stateVars.isComp297847Visible = ((ReactSystemFunctions.isNotEmpty(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "leadaddbyexcelai_537845_value", "value", "TM_GetCustomerByName", "id", "id")), ReactSystemFunctions.convertToTypeByName("True", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp102553Visible = ((ReactSystemFunctions.isNotEmpty(ReactSystemFunctions.toString(this, (stateVars.TM_GetCustomerById !== undefined ? (stateVars.TM_GetCustomerById?.length > 0 ? stateVars.TM_GetCustomerById[0].tcKimlikNo : null) : (this.state.TM_GetCustomerById?.length > 0 ? this.state.TM_GetCustomerById[0].tcKimlikNo : null))), ReactSystemFunctions.convertToTypeByName("True", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp189761Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, (stateVars.TM_GetCustomerById !== undefined ? (stateVars.TM_GetCustomerById?.length > 0 ? stateVars.TM_GetCustomerById[0].isShopping : null) : (this.state.TM_GetCustomerById?.length > 0 ? this.state.TM_GetCustomerById[0].isShopping : null))), ReactSystemFunctions.convertToTypeByName("True", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp297930Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, (stateVars.TM_GetCustomerById !== undefined ? (stateVars.TM_GetCustomerById?.length > 0 ? stateVars.TM_GetCustomerById[0].isShopping : null) : (this.state.TM_GetCustomerById?.length > 0 ? this.state.TM_GetCustomerById[0].isShopping : null))), ReactSystemFunctions.convertToTypeByName("False", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp222316Visible = ((ReactSystemFunctions.isNotEmpty(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "leadaddbyexcelai_221998_value", "value", "TM_GetReferanceByCurrAccCode", "id", "id")), ReactSystemFunctions.convertToTypeByName("True", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp797949Visible = ((ReactSystemFunctions.isNotEmpty(ReactSystemFunctions.toString(this, (stateVars.TM_GetReferenceCustomerById !== undefined ? (stateVars.TM_GetReferenceCustomerById?.length > 0 ? stateVars.TM_GetReferenceCustomerById[0].referenceNationalID : null) : (this.state.TM_GetReferenceCustomerById?.length > 0 ? this.state.TM_GetReferenceCustomerById[0].referenceNationalID : null))), ReactSystemFunctions.convertToTypeByName("True", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp484797Visible = ((ReactSystemFunctions.isNotEmpty(ReactSystemFunctions.toString(this, (stateVars.TM_GetReferenceCustomerById !== undefined ? (stateVars.TM_GetReferenceCustomerById?.length > 0 ? stateVars.TM_GetReferenceCustomerById[0].referencePhone : null) : (this.state.TM_GetReferenceCustomerById?.length > 0 ? this.state.TM_GetReferenceCustomerById[0].referencePhone : null))), ReactSystemFunctions.convertToTypeByName("True", "string"))) === true ? "visible" : "hidden")
			
			stateVars.dataSource_428403 = stateVars.TM_GetProductBrand ?? this.state.TM_GetProductBrand;
			stateVars.dataSource_428403 = stateVars.TM_GetProductBrand ?? this.state.TM_GetProductBrand;
			stateVars.isComp612838Visible = ((ReactSystemFunctions.isNotEmpty(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "leadaddbyexcelai_806227_value", "value", "TM_GetProductBracelet", "bracelet", "bracelet")), ReactSystemFunctions.convertToTypeByName("True", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp795672Visible = ((ReactSystemFunctions.isNotEmpty(ReactSystemFunctions.toString(this, (stateVars.TM_GetProduct !== undefined ? (stateVars.TM_GetProduct?.length > 0 ? stateVars.TM_GetProduct[0].categoryName : null) : (this.state.TM_GetProduct?.length > 0 ? this.state.TM_GetProduct[0].categoryName : null))), ReactSystemFunctions.convertToTypeByName("True", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp980874Visible = ((ReactSystemFunctions.isEmpty(ReactSystemFunctions.toString(this, (stateVars.TM_GetProduct !== undefined ? (stateVars.TM_GetProduct?.length > 0 ? stateVars.TM_GetProduct[0].categoryName : null) : (this.state.TM_GetProduct?.length > 0 ? this.state.TM_GetProduct[0].categoryName : null))), ReactSystemFunctions.convertToTypeByName("True", "string"))) === true ? "visible" : "hidden")
			
			stateVars.dataSource_980478 = stateVars.TM_GetLeadStatus ?? this.state.TM_GetLeadStatus;
			stateVars.dataSource_980478 = stateVars.TM_GetLeadStatus ?? this.state.TM_GetLeadStatus;
			
			stateVars.dataSource_145272 = stateVars.TM_GetLeadNextSteps ?? this.state.TM_GetLeadNextSteps;
			stateVars.dataSource_145272 = stateVars.TM_GetLeadNextSteps ?? this.state.TM_GetLeadNextSteps;
			
			stateVars.dataSource_894616 = stateVars.TM_GetAllContactSource ?? this.state.TM_GetAllContactSource;
			stateVars.dataSource_894616 = stateVars.TM_GetAllContactSource ?? this.state.TM_GetAllContactSource;
			
			stateVars.dataSource_276724 = stateVars.GetLeadProcessForExcel ?? this.state.GetLeadProcessForExcel;
			stateVars.dataSource_276724 = stateVars.GetLeadProcessForExcel ?? this.state.GetLeadProcessForExcel;

	this.props.form?.setFieldsValue(formVars);
	this.setState(stateVars);
	KuikaAppManager.hideSpinner(this);

            this.setPageInitLoaded(true);
            return isErrorOccurred;
        }




    LeadAddByExcelAIComponent_991992_onChange = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;

			validations.push({ 
				isValid: ReactSystemFunctions.isNotEmpty(ReactSystemFunctions.value(this, "leadaddbyexcelai_991992_value", "value", "TM_StoreGetList", "id", "id"), null),
				message: "Bu alan boş bırakılamaz!",
				formName: "leadaddbyexcelai_991992_value",
				condition: ReactSystemFunctions.contains(ReactSystemFunctions.getMyRoleNames(), ReactSystemFunctions.convertToTypeByName("TimesUstYonetici", "string"))
			} as IValidationData);

validations.forEach((validation) => {
            if (validation.message === "Geçerli bir mail adresi giriniz.") {
                validation.message = ReactSystemFunctions.getEmailValidationMessage()
            }
        })

		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
		KuikaAppManager.increaseServerRequestCount();

        let localVar = {
				StoreId_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "leadaddbyexcelai_991992_value", "value", "TM_StoreGetList", "id", "id")), "Guid")
        }

		KuikaAppManager.showSpinner(this);
		
        if (true) {
        KuikaAppManager.showSpinner(this);
        }
        let result = await KuikaAppManager.ApiRequest(this, "LeadAddByExcelAI/LeadAddByExcelAIComponent_991992_onChange", localVar)
        if (!KMainFunctions.IsResStatus2XX(result)) return true;

			stateVars.GetSalesPersonByStore = result?.data.getSalesPersonByStore;
			
			formVars.leadaddbyexcelai_598679_options = stateVars.GetSalesPersonByStore;
			this.props.form?.setFieldsValue(formVars);
			
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.LeadAddByExcelAIComponent_991992_onChange1_();
                  resolve();
                });
          })



        
        KuikaAppManager.hideSpinner(this);
        return isErrorOccurred;
    }
		LeadAddByExcelAIComponent_991992_onChange1_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }

				
				stateVars.dataSource_598679 = stateVars.GetSalesPersonByStore ?? this.state.GetSalesPersonByStore;
				stateVars.dataSource_598679 = stateVars.GetSalesPersonByStore ?? this.state.GetSalesPersonByStore;

		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

            
            return isErrorOccurred;
        }




    LeadAddByExcelAIComponent_598679_onChange = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;

			validations.push({ 
				isValid: ReactSystemFunctions.isNotEmpty(ReactSystemFunctions.value(this, "leadaddbyexcelai_598679_value", "value", "GetSalesPersonByStore", "kuserID", "id"), null),
				message: "Bu alan boş bırakılamaz !",
				formName: "leadaddbyexcelai_598679_value",
				condition: ReactSystemFunctions.contains(ReactSystemFunctions.getMyRoleNames(), ReactSystemFunctions.convertToTypeByName("TimesMagazaMuduru", "string"))
			} as IValidationData);

validations.forEach((validation) => {
            if (validation.message === "Geçerli bir mail adresi giriniz.") {
                validation.message = ReactSystemFunctions.getEmailValidationMessage()
            }
        })

		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
		KuikaAppManager.increaseServerRequestCount();

        let localVar = {
				KUserId_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "leadaddbyexcelai_598679_value", "value", "GetSalesPersonByStore", "kuserID", "kuserID")), "Guid")
        }

		KuikaAppManager.showSpinner(this);
		
        if (true) {
        KuikaAppManager.showSpinner(this);
        }
        let result = await KuikaAppManager.ApiRequest(this, "LeadAddByExcelAI/LeadAddByExcelAIComponent_598679_onChange", localVar)
        if (!KMainFunctions.IsResStatus2XX(result)) return true;

			stateVars.TM_GetProductBrand = result?.data.tM_GetProductBrand;
			
			formVars.leadaddbyexcelai_428403_options = stateVars.TM_GetProductBrand;
			this.props.form?.setFieldsValue(formVars);
			
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.LeadAddByExcelAIComponent_598679_onChange1_();
                  resolve();
                });
          })



        
        KuikaAppManager.hideSpinner(this);
        return isErrorOccurred;
    }
		LeadAddByExcelAIComponent_598679_onChange1_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }

				
				stateVars.dataSource_428403 = stateVars.TM_GetProductBrand ?? this.state.TM_GetProductBrand;
				stateVars.dataSource_428403 = stateVars.TM_GetProductBrand ?? this.state.TM_GetProductBrand;

		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

            
            return isErrorOccurred;
        }




		LeadAddByExcelAIComponent_999939_onClick = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
KuikaAppManager.showSpinner(this);

					KuikaAppManager.prepareForNavigation();

				stateVars.NAVIGATE = await ReactSystemFunctions.navigate(this, undefined, "LeadAddByExcelAI", "CustomerCreatePost", "", "7d969ddf-5801-4eb6-b92b-12be35bdd565", "91672", null, "right", "true", "90%", "100vh", true, false);

		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

            
            return isErrorOccurred;
        }


    LeadAddByExcelAIComponent_537845_onChange = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;

			validations.push({ 
				isValid: ReactSystemFunctions.isNotEmpty(ReactSystemFunctions.value(this, "leadaddbyexcelai_537845_value", "value", "TM_GetCustomerByName", "id", "id"), null),
				message: "Bu alan boş bırakılamaz!",
				formName: "leadaddbyexcelai_537845_value",
				condition: true
			} as IValidationData);

validations.forEach((validation) => {
            if (validation.message === "Geçerli bir mail adresi giriniz.") {
                validation.message = ReactSystemFunctions.getEmailValidationMessage()
            }
        })

		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
		KuikaAppManager.increaseServerRequestCount();

        let localVar = {
				CustomerId_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "leadaddbyexcelai_537845_value", "value", "TM_GetCustomerByName", "id", "id")), "Guid"),
				CurrAccCode_1: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, (stateVars.TM_GetCustomerById !== undefined ? (stateVars.TM_GetCustomerById?.length > 0 ? stateVars.TM_GetCustomerById[0].currAccCode : null) : (this.state.TM_GetCustomerById?.length > 0 ? this.state.TM_GetCustomerById[0].currAccCode : null))), "string")
        }

		KuikaAppManager.showSpinner(this);
		
        if (true) {
        KuikaAppManager.showSpinner(this);
        }
        let result = await KuikaAppManager.ApiRequest(this, "LeadAddByExcelAI/LeadAddByExcelAIComponent_537845_onChange", localVar)
        if (!KMainFunctions.IsResStatus2XX(result)) return true;

			stateVars.TM_GetCustomerById = result?.data.tM_GetCustomerById;
			formVars.leadaddbyexcelai_446494_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetCustomerById !== undefined ? (stateVars.TM_GetCustomerById?.length > 0 ? stateVars.TM_GetCustomerById[0].adSoyad : null) : (this.state.TM_GetCustomerById?.length > 0 ? this.state.TM_GetCustomerById[0].adSoyad : null)));
			formVars.leadaddbyexcelai_102553_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetCustomerById !== undefined ? (stateVars.TM_GetCustomerById?.length > 0 ? stateVars.TM_GetCustomerById[0].tcKimlikNo : null) : (this.state.TM_GetCustomerById?.length > 0 ? this.state.TM_GetCustomerById[0].tcKimlikNo : null)));
			formVars.leadaddbyexcelai_807863_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetCustomerById !== undefined ? (stateVars.TM_GetCustomerById?.length > 0 ? stateVars.TM_GetCustomerById[0].telefonNo : null) : (this.state.TM_GetCustomerById?.length > 0 ? this.state.TM_GetCustomerById[0].telefonNo : null)));
			formVars.leadaddbyexcelai_865059_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetCustomerById !== undefined ? (stateVars.TM_GetCustomerById?.length > 0 ? stateVars.TM_GetCustomerById[0].email : null) : (this.state.TM_GetCustomerById?.length > 0 ? this.state.TM_GetCustomerById[0].email : null)));
			formVars.leadaddbyexcelai_451510_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetCustomerById !== undefined ? (stateVars.TM_GetCustomerById?.length > 0 ? stateVars.TM_GetCustomerById[0].sehir : null) : (this.state.TM_GetCustomerById?.length > 0 ? this.state.TM_GetCustomerById[0].sehir : null)));
			stateVars.isComp102553Visible = ((ReactSystemFunctions.isNotEmpty(ReactSystemFunctions.toString(this, (stateVars.TM_GetCustomerById !== undefined ? (stateVars.TM_GetCustomerById?.length > 0 ? stateVars.TM_GetCustomerById[0].tcKimlikNo : null) : (this.state.TM_GetCustomerById?.length > 0 ? this.state.TM_GetCustomerById[0].tcKimlikNo : null))), ReactSystemFunctions.convertToTypeByName("True", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp189761Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, (stateVars.TM_GetCustomerById !== undefined ? (stateVars.TM_GetCustomerById?.length > 0 ? stateVars.TM_GetCustomerById[0].isShopping : null) : (this.state.TM_GetCustomerById?.length > 0 ? this.state.TM_GetCustomerById[0].isShopping : null))), ReactSystemFunctions.convertToTypeByName("True", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp297930Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, (stateVars.TM_GetCustomerById !== undefined ? (stateVars.TM_GetCustomerById?.length > 0 ? stateVars.TM_GetCustomerById[0].isShopping : null) : (this.state.TM_GetCustomerById?.length > 0 ? this.state.TM_GetCustomerById[0].isShopping : null))), ReactSystemFunctions.convertToTypeByName("False", "string"))) === true ? "visible" : "hidden")
			stateVars.TM_GetReferanceByCurrAccCode = result?.data.tM_GetReferanceByCurrAccCode;
			
			formVars.leadaddbyexcelai_221998_options = stateVars.TM_GetReferanceByCurrAccCode;
			this.props.form?.setFieldsValue(formVars);
			
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.LeadAddByExcelAIComponent_537845_onChange1_();
                  resolve();
                });
          })



        
        KuikaAppManager.hideSpinner(this);
        return isErrorOccurred;
    }
		LeadAddByExcelAIComponent_537845_onChange1_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }

				stateVars.isComp297847Visible = ((ReactSystemFunctions.isNotEmpty(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "leadaddbyexcelai_537845_value", "value", "TM_GetCustomerByName", "id", "id")), ReactSystemFunctions.convertToTypeByName("True", "string"))) === true ? "visible" : "hidden")
				formVars.leadaddbyexcelai_446494_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetCustomerById !== undefined ? (stateVars.TM_GetCustomerById?.length > 0 ? stateVars.TM_GetCustomerById[0].adSoyad : null) : (this.state.TM_GetCustomerById?.length > 0 ? this.state.TM_GetCustomerById[0].adSoyad : null)));

				formVars.leadaddbyexcelai_102553_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetCustomerById !== undefined ? (stateVars.TM_GetCustomerById?.length > 0 ? stateVars.TM_GetCustomerById[0].tcKimlikNo : null) : (this.state.TM_GetCustomerById?.length > 0 ? this.state.TM_GetCustomerById[0].tcKimlikNo : null)));

				formVars.leadaddbyexcelai_807863_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetCustomerById !== undefined ? (stateVars.TM_GetCustomerById?.length > 0 ? stateVars.TM_GetCustomerById[0].telefonNo : null) : (this.state.TM_GetCustomerById?.length > 0 ? this.state.TM_GetCustomerById[0].telefonNo : null)));

				formVars.leadaddbyexcelai_865059_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetCustomerById !== undefined ? (stateVars.TM_GetCustomerById?.length > 0 ? stateVars.TM_GetCustomerById[0].email : null) : (this.state.TM_GetCustomerById?.length > 0 ? this.state.TM_GetCustomerById[0].email : null)));

				formVars.leadaddbyexcelai_451510_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetCustomerById !== undefined ? (stateVars.TM_GetCustomerById?.length > 0 ? stateVars.TM_GetCustomerById[0].sehir : null) : (this.state.TM_GetCustomerById?.length > 0 ? this.state.TM_GetCustomerById[0].sehir : null)));

				
				stateVars.dataSource_221998 = stateVars.TM_GetReferanceByCurrAccCode ?? this.state.TM_GetReferanceByCurrAccCode;
				stateVars.dataSource_221998 = stateVars.TM_GetReferanceByCurrAccCode ?? this.state.TM_GetReferanceByCurrAccCode;

		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

            
            return isErrorOccurred;
        }




    LeadAddByExcelAIComponent_890441_onClick = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;

			validations.push({ 
				isValid: ReactSystemFunctions.isNotEmpty(ReactSystemFunctions.value(this, "leadaddbyexcelai_537845_value", "value", "TM_GetCustomerByName", "id", "id"), null),
				message: "Bu alan boş bırakılamaz!",
				formName: "leadaddbyexcelai_537845_value",
				condition: true
			} as IValidationData);

validations.forEach((validation) => {
            if (validation.message === "Geçerli bir mail adresi giriniz.") {
                validation.message = ReactSystemFunctions.getEmailValidationMessage()
            }
        })

		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
		KuikaAppManager.increaseServerRequestCount();

        let localVar = {
				CustomerId_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "leadaddbyexcelai_537845_value", "value", "TM_GetCustomerByName", "id", "id")), "Guid")
        }

		KuikaAppManager.showSpinner(this);
		
        if (true) {
        KuikaAppManager.showSpinner(this);
        }
        let result = await KuikaAppManager.ApiRequest(this, "LeadAddByExcelAI/LeadAddByExcelAIComponent_890441_onClick", localVar)
        if (!KMainFunctions.IsResStatus2XX(result)) return true;

			stateVars.TM_GetCustomerById = result?.data.tM_GetCustomerById;
			formVars.leadaddbyexcelai_446494_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetCustomerById !== undefined ? (stateVars.TM_GetCustomerById?.length > 0 ? stateVars.TM_GetCustomerById[0].adSoyad : null) : (this.state.TM_GetCustomerById?.length > 0 ? this.state.TM_GetCustomerById[0].adSoyad : null)));
			formVars.leadaddbyexcelai_102553_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetCustomerById !== undefined ? (stateVars.TM_GetCustomerById?.length > 0 ? stateVars.TM_GetCustomerById[0].tcKimlikNo : null) : (this.state.TM_GetCustomerById?.length > 0 ? this.state.TM_GetCustomerById[0].tcKimlikNo : null)));
			formVars.leadaddbyexcelai_807863_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetCustomerById !== undefined ? (stateVars.TM_GetCustomerById?.length > 0 ? stateVars.TM_GetCustomerById[0].telefonNo : null) : (this.state.TM_GetCustomerById?.length > 0 ? this.state.TM_GetCustomerById[0].telefonNo : null)));
			formVars.leadaddbyexcelai_865059_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetCustomerById !== undefined ? (stateVars.TM_GetCustomerById?.length > 0 ? stateVars.TM_GetCustomerById[0].email : null) : (this.state.TM_GetCustomerById?.length > 0 ? this.state.TM_GetCustomerById[0].email : null)));
			formVars.leadaddbyexcelai_451510_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetCustomerById !== undefined ? (stateVars.TM_GetCustomerById?.length > 0 ? stateVars.TM_GetCustomerById[0].sehir : null) : (this.state.TM_GetCustomerById?.length > 0 ? this.state.TM_GetCustomerById[0].sehir : null)));
			stateVars.isComp102553Visible = ((ReactSystemFunctions.isNotEmpty(ReactSystemFunctions.toString(this, (stateVars.TM_GetCustomerById !== undefined ? (stateVars.TM_GetCustomerById?.length > 0 ? stateVars.TM_GetCustomerById[0].tcKimlikNo : null) : (this.state.TM_GetCustomerById?.length > 0 ? this.state.TM_GetCustomerById[0].tcKimlikNo : null))), ReactSystemFunctions.convertToTypeByName("True", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp189761Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, (stateVars.TM_GetCustomerById !== undefined ? (stateVars.TM_GetCustomerById?.length > 0 ? stateVars.TM_GetCustomerById[0].isShopping : null) : (this.state.TM_GetCustomerById?.length > 0 ? this.state.TM_GetCustomerById[0].isShopping : null))), ReactSystemFunctions.convertToTypeByName("True", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp297930Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, (stateVars.TM_GetCustomerById !== undefined ? (stateVars.TM_GetCustomerById?.length > 0 ? stateVars.TM_GetCustomerById[0].isShopping : null) : (this.state.TM_GetCustomerById?.length > 0 ? this.state.TM_GetCustomerById[0].isShopping : null))), ReactSystemFunctions.convertToTypeByName("False", "string"))) === true ? "visible" : "hidden")
			this.props.form?.setFieldsValue(formVars);
			
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.LeadAddByExcelAIComponent_890441_onClick1_();
                  resolve();
                });
          })



        
        KuikaAppManager.hideSpinner(this);
        return isErrorOccurred;
    }
		LeadAddByExcelAIComponent_890441_onClick1_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }

					KuikaAppManager.prepareForNavigation();
						KuikaAppManager.addToPageInputVariables("CustomerDetailInfo", "customerCode", ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, (stateVars.TM_GetCustomerById !== undefined ? (stateVars.TM_GetCustomerById?.length > 0 ? stateVars.TM_GetCustomerById[0].currAccCode : null) : (this.state.TM_GetCustomerById?.length > 0 ? this.state.TM_GetCustomerById[0].currAccCode : null))), "string"));
						KuikaAppManager.addToPageInputVariables("CustomerDetailInfo", "CustomerId", ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, (stateVars.TM_GetCustomerById !== undefined ? (stateVars.TM_GetCustomerById?.length > 0 ? stateVars.TM_GetCustomerById[0].customerId : null) : (this.state.TM_GetCustomerById?.length > 0 ? this.state.TM_GetCustomerById[0].customerId : null))), "Guid"));

				stateVars.NAVIGATE = await ReactSystemFunctions.navigate(this, this.LeadAddByExcelAIComponent_890441_onClick2_, "LeadAddByExcelAI", "CustomerDetailInfo", "", "currentPage", null, null, null, null, null, null, true, false);

		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

            
            return isErrorOccurred;
        }
		LeadAddByExcelAIComponent_890441_onClick2_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
KuikaAppManager.showSpinner(this);

				formVars.leadaddbyexcelai_446494_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetCustomerById !== undefined ? (stateVars.TM_GetCustomerById?.length > 0 ? stateVars.TM_GetCustomerById[0].adSoyad : null) : (this.state.TM_GetCustomerById?.length > 0 ? this.state.TM_GetCustomerById[0].adSoyad : null)));

				formVars.leadaddbyexcelai_102553_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetCustomerById !== undefined ? (stateVars.TM_GetCustomerById?.length > 0 ? stateVars.TM_GetCustomerById[0].tcKimlikNo : null) : (this.state.TM_GetCustomerById?.length > 0 ? this.state.TM_GetCustomerById[0].tcKimlikNo : null)));

				formVars.leadaddbyexcelai_807863_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetCustomerById !== undefined ? (stateVars.TM_GetCustomerById?.length > 0 ? stateVars.TM_GetCustomerById[0].telefonNo : null) : (this.state.TM_GetCustomerById?.length > 0 ? this.state.TM_GetCustomerById[0].telefonNo : null)));

				formVars.leadaddbyexcelai_865059_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetCustomerById !== undefined ? (stateVars.TM_GetCustomerById?.length > 0 ? stateVars.TM_GetCustomerById[0].email : null) : (this.state.TM_GetCustomerById?.length > 0 ? this.state.TM_GetCustomerById[0].email : null)));

				formVars.leadaddbyexcelai_451510_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetCustomerById !== undefined ? (stateVars.TM_GetCustomerById?.length > 0 ? stateVars.TM_GetCustomerById[0].sehir : null) : (this.state.TM_GetCustomerById?.length > 0 ? this.state.TM_GetCustomerById[0].sehir : null)));


		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

            
            return isErrorOccurred;
        }





    LeadAddByExcelAIComponent_749072_onClick = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;

			validations.push({ 
				isValid: ReactSystemFunctions.isNotEmpty(ReactSystemFunctions.value(this, "leadaddbyexcelai_537845_value", "value", "TM_GetCustomerByName", "id", "id"), null),
				message: "Bu alan boş bırakılamaz!",
				formName: "leadaddbyexcelai_537845_value",
				condition: true
			} as IValidationData);

validations.forEach((validation) => {
            if (validation.message === "Geçerli bir mail adresi giriniz.") {
                validation.message = ReactSystemFunctions.getEmailValidationMessage()
            }
        })

		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
		KuikaAppManager.increaseServerRequestCount();

        let localVar = {
				CustomerId_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "leadaddbyexcelai_537845_value", "value", "TM_GetCustomerByName", "id", "id")), "Guid")
        }

		KuikaAppManager.showSpinner(this);
		
        if (true) {
        KuikaAppManager.showSpinner(this);
        }
        let result = await KuikaAppManager.ApiRequest(this, "LeadAddByExcelAI/LeadAddByExcelAIComponent_749072_onClick", localVar)
        if (!KMainFunctions.IsResStatus2XX(result)) return true;

			stateVars.TM_GetCustomerById = result?.data.tM_GetCustomerById;
			formVars.leadaddbyexcelai_446494_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetCustomerById !== undefined ? (stateVars.TM_GetCustomerById?.length > 0 ? stateVars.TM_GetCustomerById[0].adSoyad : null) : (this.state.TM_GetCustomerById?.length > 0 ? this.state.TM_GetCustomerById[0].adSoyad : null)));
			formVars.leadaddbyexcelai_102553_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetCustomerById !== undefined ? (stateVars.TM_GetCustomerById?.length > 0 ? stateVars.TM_GetCustomerById[0].tcKimlikNo : null) : (this.state.TM_GetCustomerById?.length > 0 ? this.state.TM_GetCustomerById[0].tcKimlikNo : null)));
			formVars.leadaddbyexcelai_807863_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetCustomerById !== undefined ? (stateVars.TM_GetCustomerById?.length > 0 ? stateVars.TM_GetCustomerById[0].telefonNo : null) : (this.state.TM_GetCustomerById?.length > 0 ? this.state.TM_GetCustomerById[0].telefonNo : null)));
			formVars.leadaddbyexcelai_865059_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetCustomerById !== undefined ? (stateVars.TM_GetCustomerById?.length > 0 ? stateVars.TM_GetCustomerById[0].email : null) : (this.state.TM_GetCustomerById?.length > 0 ? this.state.TM_GetCustomerById[0].email : null)));
			formVars.leadaddbyexcelai_451510_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetCustomerById !== undefined ? (stateVars.TM_GetCustomerById?.length > 0 ? stateVars.TM_GetCustomerById[0].sehir : null) : (this.state.TM_GetCustomerById?.length > 0 ? this.state.TM_GetCustomerById[0].sehir : null)));
			stateVars.isComp102553Visible = ((ReactSystemFunctions.isNotEmpty(ReactSystemFunctions.toString(this, (stateVars.TM_GetCustomerById !== undefined ? (stateVars.TM_GetCustomerById?.length > 0 ? stateVars.TM_GetCustomerById[0].tcKimlikNo : null) : (this.state.TM_GetCustomerById?.length > 0 ? this.state.TM_GetCustomerById[0].tcKimlikNo : null))), ReactSystemFunctions.convertToTypeByName("True", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp189761Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, (stateVars.TM_GetCustomerById !== undefined ? (stateVars.TM_GetCustomerById?.length > 0 ? stateVars.TM_GetCustomerById[0].isShopping : null) : (this.state.TM_GetCustomerById?.length > 0 ? this.state.TM_GetCustomerById[0].isShopping : null))), ReactSystemFunctions.convertToTypeByName("True", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp297930Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, (stateVars.TM_GetCustomerById !== undefined ? (stateVars.TM_GetCustomerById?.length > 0 ? stateVars.TM_GetCustomerById[0].isShopping : null) : (this.state.TM_GetCustomerById?.length > 0 ? this.state.TM_GetCustomerById[0].isShopping : null))), ReactSystemFunctions.convertToTypeByName("False", "string"))) === true ? "visible" : "hidden")
			this.props.form?.setFieldsValue(formVars);
			
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.LeadAddByExcelAIComponent_749072_onClick1_();
                  resolve();
                });
          })



        
        KuikaAppManager.hideSpinner(this);
        return isErrorOccurred;
    }
		LeadAddByExcelAIComponent_749072_onClick1_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }

					KuikaAppManager.prepareForNavigation();
						KuikaAppManager.addToPageInputVariables("CustomerUpdatePost", "CustomerId", ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, (stateVars.TM_GetCustomerById !== undefined ? (stateVars.TM_GetCustomerById?.length > 0 ? stateVars.TM_GetCustomerById[0].customerId : null) : (this.state.TM_GetCustomerById?.length > 0 ? this.state.TM_GetCustomerById[0].customerId : null))), "Guid"));

				stateVars.NAVIGATE = await ReactSystemFunctions.navigate(this, this.LeadAddByExcelAIComponent_749072_onClick2_, "LeadAddByExcelAI", "CustomerUpdatePost", "", "currentPage", null, null, null, null, null, null, true, false);

		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

            
            return isErrorOccurred;
        }
		LeadAddByExcelAIComponent_749072_onClick2_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
KuikaAppManager.showSpinner(this);

				formVars.leadaddbyexcelai_446494_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetCustomerById !== undefined ? (stateVars.TM_GetCustomerById?.length > 0 ? stateVars.TM_GetCustomerById[0].adSoyad : null) : (this.state.TM_GetCustomerById?.length > 0 ? this.state.TM_GetCustomerById[0].adSoyad : null)));

				formVars.leadaddbyexcelai_102553_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetCustomerById !== undefined ? (stateVars.TM_GetCustomerById?.length > 0 ? stateVars.TM_GetCustomerById[0].tcKimlikNo : null) : (this.state.TM_GetCustomerById?.length > 0 ? this.state.TM_GetCustomerById[0].tcKimlikNo : null)));

				formVars.leadaddbyexcelai_807863_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetCustomerById !== undefined ? (stateVars.TM_GetCustomerById?.length > 0 ? stateVars.TM_GetCustomerById[0].telefonNo : null) : (this.state.TM_GetCustomerById?.length > 0 ? this.state.TM_GetCustomerById[0].telefonNo : null)));

				formVars.leadaddbyexcelai_865059_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetCustomerById !== undefined ? (stateVars.TM_GetCustomerById?.length > 0 ? stateVars.TM_GetCustomerById[0].email : null) : (this.state.TM_GetCustomerById?.length > 0 ? this.state.TM_GetCustomerById[0].email : null)));

				formVars.leadaddbyexcelai_451510_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetCustomerById !== undefined ? (stateVars.TM_GetCustomerById?.length > 0 ? stateVars.TM_GetCustomerById[0].sehir : null) : (this.state.TM_GetCustomerById?.length > 0 ? this.state.TM_GetCustomerById[0].sehir : null)));


		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

            
            return isErrorOccurred;
        }





		LeadAddByExcelAIComponent_344615_onClick = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
KuikaAppManager.showSpinner(this);

					KuikaAppManager.prepareForNavigation();
						KuikaAppManager.addToPageInputVariables("ReferanceCreatePost", "CustomerId", ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "leadaddbyexcelai_537845_value", "value", "TM_GetCustomerByName", "id", "id")), "Guid"));

				stateVars.NAVIGATE = await ReactSystemFunctions.navigate(this, undefined, "LeadAddByExcelAI", "ReferanceCreatePost", "", "currentPage", null, null, null, null, null, null, true, false);

		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

            
            return isErrorOccurred;
        }


    LeadAddByExcelAIComponent_221998_onChange = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
		KuikaAppManager.increaseServerRequestCount();

        let localVar = {
				Id_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "leadaddbyexcelai_221998_value", "value", "TM_GetReferanceByCurrAccCode", "id", "id")), "Guid")
        }

		KuikaAppManager.showSpinner(this);
		
        if (true) {
        KuikaAppManager.showSpinner(this);
        }
        let result = await KuikaAppManager.ApiRequest(this, "LeadAddByExcelAI/LeadAddByExcelAIComponent_221998_onChange", localVar)
        if (!KMainFunctions.IsResStatus2XX(result)) return true;

			stateVars.TM_GetReferenceCustomerById = result?.data.tM_GetReferenceCustomerById;
			formVars.leadaddbyexcelai_461641_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetReferenceCustomerById !== undefined ? (stateVars.TM_GetReferenceCustomerById?.length > 0 ? stateVars.TM_GetReferenceCustomerById[0].referenceName : null) : (this.state.TM_GetReferenceCustomerById?.length > 0 ? this.state.TM_GetReferenceCustomerById[0].referenceName : null)));
			formVars.leadaddbyexcelai_577711_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetReferenceCustomerById !== undefined ? (stateVars.TM_GetReferenceCustomerById?.length > 0 ? stateVars.TM_GetReferenceCustomerById[0].referenceLastName : null) : (this.state.TM_GetReferenceCustomerById?.length > 0 ? this.state.TM_GetReferenceCustomerById[0].referenceLastName : null)));
			formVars.leadaddbyexcelai_194484_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetReferenceCustomerById !== undefined ? (stateVars.TM_GetReferenceCustomerById?.length > 0 ? stateVars.TM_GetReferenceCustomerById[0].referenceNationalID : null) : (this.state.TM_GetReferenceCustomerById?.length > 0 ? this.state.TM_GetReferenceCustomerById[0].referenceNationalID : null)));
			formVars.leadaddbyexcelai_919060_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetReferenceCustomerById !== undefined ? (stateVars.TM_GetReferenceCustomerById?.length > 0 ? stateVars.TM_GetReferenceCustomerById[0].referencePhone : null) : (this.state.TM_GetReferenceCustomerById?.length > 0 ? this.state.TM_GetReferenceCustomerById[0].referencePhone : null)));
			stateVars.isComp797949Visible = ((ReactSystemFunctions.isNotEmpty(ReactSystemFunctions.toString(this, (stateVars.TM_GetReferenceCustomerById !== undefined ? (stateVars.TM_GetReferenceCustomerById?.length > 0 ? stateVars.TM_GetReferenceCustomerById[0].referenceNationalID : null) : (this.state.TM_GetReferenceCustomerById?.length > 0 ? this.state.TM_GetReferenceCustomerById[0].referenceNationalID : null))), ReactSystemFunctions.convertToTypeByName("True", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp484797Visible = ((ReactSystemFunctions.isNotEmpty(ReactSystemFunctions.toString(this, (stateVars.TM_GetReferenceCustomerById !== undefined ? (stateVars.TM_GetReferenceCustomerById?.length > 0 ? stateVars.TM_GetReferenceCustomerById[0].referencePhone : null) : (this.state.TM_GetReferenceCustomerById?.length > 0 ? this.state.TM_GetReferenceCustomerById[0].referencePhone : null))), ReactSystemFunctions.convertToTypeByName("True", "string"))) === true ? "visible" : "hidden")
			this.props.form?.setFieldsValue(formVars);
			
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.LeadAddByExcelAIComponent_221998_onChange1_();
                  resolve();
                });
          })



        
        KuikaAppManager.hideSpinner(this);
        return isErrorOccurred;
    }
		LeadAddByExcelAIComponent_221998_onChange1_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }

				stateVars.isComp222316Visible = ((ReactSystemFunctions.isNotEmpty(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "leadaddbyexcelai_221998_value", "value", "TM_GetReferanceByCurrAccCode", "id", "id")), ReactSystemFunctions.convertToTypeByName("True", "string"))) === true ? "visible" : "hidden")
				formVars.leadaddbyexcelai_461641_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetReferenceCustomerById !== undefined ? (stateVars.TM_GetReferenceCustomerById?.length > 0 ? stateVars.TM_GetReferenceCustomerById[0].referenceName : null) : (this.state.TM_GetReferenceCustomerById?.length > 0 ? this.state.TM_GetReferenceCustomerById[0].referenceName : null)));

				formVars.leadaddbyexcelai_577711_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetReferenceCustomerById !== undefined ? (stateVars.TM_GetReferenceCustomerById?.length > 0 ? stateVars.TM_GetReferenceCustomerById[0].referenceLastName : null) : (this.state.TM_GetReferenceCustomerById?.length > 0 ? this.state.TM_GetReferenceCustomerById[0].referenceLastName : null)));

				formVars.leadaddbyexcelai_194484_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetReferenceCustomerById !== undefined ? (stateVars.TM_GetReferenceCustomerById?.length > 0 ? stateVars.TM_GetReferenceCustomerById[0].referenceNationalID : null) : (this.state.TM_GetReferenceCustomerById?.length > 0 ? this.state.TM_GetReferenceCustomerById[0].referenceNationalID : null)));

				formVars.leadaddbyexcelai_919060_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetReferenceCustomerById !== undefined ? (stateVars.TM_GetReferenceCustomerById?.length > 0 ? stateVars.TM_GetReferenceCustomerById[0].referencePhone : null) : (this.state.TM_GetReferenceCustomerById?.length > 0 ? this.state.TM_GetReferenceCustomerById[0].referencePhone : null)));


		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

            
            return isErrorOccurred;
        }




		LeadAddByExcelAIComponent_428403_onChange = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
KuikaAppManager.showSpinner(this);

				stateVars.SetValueOf = await ReactSystemFunctions.setValueOf(this, ReactSystemFunctions.convertToTypeByName("leadaddbyexcelai_888506_value", "string"), "", null, "Referance");
				stateVars.SetValueOf = await ReactSystemFunctions.setValueOf(this, ReactSystemFunctions.convertToTypeByName("leadaddbyexcelai_709894_value", "string"), "", null, "Dial");
				stateVars.SetValueOf = await ReactSystemFunctions.setValueOf(this, ReactSystemFunctions.convertToTypeByName("leadaddbyexcelai_806227_value", "string"), "", null, "Bracelet");
				stateVars.ChangeVisibilityOf = await ReactSystemFunctions.changeVisibilityOf(this, ReactSystemFunctions.convertToTypeByName("isComp612838Visible", "string"), ReactSystemFunctions.convertToTypeByName("hidden", "string"));

		this.props.form?.setFieldsValue(formVars);
		
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.LeadAddByExcelAIComponent_428403_onChange1_();
                  resolve();
                });
          })

            
            return isErrorOccurred;
        }
    LeadAddByExcelAIComponent_428403_onChange1_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
		KuikaAppManager.increaseServerRequestCount();

        let localVar = {
				BrandName_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "leadaddbyexcelai_428403_value", "value", "TM_GetProductBrand", "brand", "brand")), "string")
        }

		
        if (true) {
        KuikaAppManager.showSpinner(this);
        }
        let result = await KuikaAppManager.ApiRequest(this, "LeadAddByExcelAI/LeadAddByExcelAIComponent_428403_onChange1_", localVar)
        if (!KMainFunctions.IsResStatus2XX(result)) return true;

			stateVars.TM_GetProductReferance = result?.data.tM_GetProductReferance;
			
			formVars.leadaddbyexcelai_888506_options = stateVars.TM_GetProductReferance;
			this.props.form?.setFieldsValue(formVars);
			
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.LeadAddByExcelAIComponent_428403_onChange2_();
                  resolve();
                });
          })



        
        KuikaAppManager.hideSpinner(this);
        return isErrorOccurred;
    }
		LeadAddByExcelAIComponent_428403_onChange2_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }

				
				stateVars.dataSource_888506 = stateVars.TM_GetProductReferance ?? this.state.TM_GetProductReferance;
				stateVars.dataSource_888506 = stateVars.TM_GetProductReferance ?? this.state.TM_GetProductReferance;

		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

            
            return isErrorOccurred;
        }





		LeadAddByExcelAIComponent_888506_onChange = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
KuikaAppManager.showSpinner(this);

				stateVars.SetValueOf = await ReactSystemFunctions.setValueOf(this, ReactSystemFunctions.convertToTypeByName("leadaddbyexcelai_709894_value", "string"), "", null, "Dial");
				stateVars.SetValueOf = await ReactSystemFunctions.setValueOf(this, ReactSystemFunctions.convertToTypeByName("leadaddbyexcelai_806227_value", "string"), "", null, "Bracelet");
				stateVars.ChangeVisibilityOf = await ReactSystemFunctions.changeVisibilityOf(this, ReactSystemFunctions.convertToTypeByName("isComp612838Visible", "string"), ReactSystemFunctions.convertToTypeByName("hidden", "string"));

		this.props.form?.setFieldsValue(formVars);
		
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.LeadAddByExcelAIComponent_888506_onChange1_();
                  resolve();
                });
          })

            
            return isErrorOccurred;
        }
    LeadAddByExcelAIComponent_888506_onChange1_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;

			validations.push({ 
				isValid: ReactSystemFunctions.isNotEmpty(ReactSystemFunctions.value(this, "leadaddbyexcelai_888506_value", "value", "TM_GetProductReferance", "referance", "referance"), null),
				message: "Bu alan boş bırakılamaz!",
				formName: "leadaddbyexcelai_888506_value",
				condition: true
			} as IValidationData);

validations.forEach((validation) => {
            if (validation.message === "Geçerli bir mail adresi giriniz.") {
                validation.message = ReactSystemFunctions.getEmailValidationMessage()
            }
        })

		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
		KuikaAppManager.increaseServerRequestCount();

        let localVar = {
				Brand_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "leadaddbyexcelai_428403_value", "value", "TM_GetProductBrand", "brand", "brand")), "string"),
				Referance_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "leadaddbyexcelai_888506_value", "value", "TM_GetProductReferance", "referance", "referance")), "string")
        }

		
        if (true) {
        KuikaAppManager.showSpinner(this);
        }
        let result = await KuikaAppManager.ApiRequest(this, "LeadAddByExcelAI/LeadAddByExcelAIComponent_888506_onChange1_", localVar)
        if (!KMainFunctions.IsResStatus2XX(result)) return true;

			stateVars.TM_GetProductDial = result?.data.tM_GetProductDial;
			
			formVars.leadaddbyexcelai_709894_options = stateVars.TM_GetProductDial;
			this.props.form?.setFieldsValue(formVars);
			
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.LeadAddByExcelAIComponent_888506_onChange2_();
                  resolve();
                });
          })



        
        KuikaAppManager.hideSpinner(this);
        return isErrorOccurred;
    }
		LeadAddByExcelAIComponent_888506_onChange2_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }

				
				stateVars.dataSource_709894 = stateVars.TM_GetProductDial ?? this.state.TM_GetProductDial;
				stateVars.dataSource_709894 = stateVars.TM_GetProductDial ?? this.state.TM_GetProductDial;

		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

            
            return isErrorOccurred;
        }





		LeadAddByExcelAIComponent_709894_onChange = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
KuikaAppManager.showSpinner(this);

				stateVars.SetValueOf = await ReactSystemFunctions.setValueOf(this, ReactSystemFunctions.convertToTypeByName("leadaddbyexcelai_806227_value", "string"), "", null, "Bracelet");
				stateVars.ChangeVisibilityOf = await ReactSystemFunctions.changeVisibilityOf(this, ReactSystemFunctions.convertToTypeByName("isComp612838Visible", "string"), ReactSystemFunctions.convertToTypeByName("hidden", "string"));

		this.props.form?.setFieldsValue(formVars);
		
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.LeadAddByExcelAIComponent_709894_onChange1_();
                  resolve();
                });
          })

            
            return isErrorOccurred;
        }
    LeadAddByExcelAIComponent_709894_onChange1_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;

			validations.push({ 
				isValid: ReactSystemFunctions.isNotEmpty(ReactSystemFunctions.value(this, "leadaddbyexcelai_888506_value", "value", "TM_GetProductReferance", "referance", "referance"), null),
				message: "Bu alan boş bırakılamaz!",
				formName: "leadaddbyexcelai_888506_value",
				condition: true
			} as IValidationData);

validations.forEach((validation) => {
            if (validation.message === "Geçerli bir mail adresi giriniz.") {
                validation.message = ReactSystemFunctions.getEmailValidationMessage()
            }
        })
			validations.push({ 
				isValid: ReactSystemFunctions.isNotEmpty(ReactSystemFunctions.value(this, "leadaddbyexcelai_709894_value", "value", "TM_GetProductDial", "dial", "dial"), null),
				message: "Bu alan boş bırakılamaz!",
				formName: "leadaddbyexcelai_709894_value",
				condition: true
			} as IValidationData);

validations.forEach((validation) => {
            if (validation.message === "Geçerli bir mail adresi giriniz.") {
                validation.message = ReactSystemFunctions.getEmailValidationMessage()
            }
        })

		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
		KuikaAppManager.increaseServerRequestCount();

        let localVar = {
				Brand_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "leadaddbyexcelai_428403_value", "value", "TM_GetProductBrand", "brand", "brand")), "string"),
				Referance_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "leadaddbyexcelai_888506_value", "value", "TM_GetProductReferance", "referance", "referance")), "string"),
				Dial_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "leadaddbyexcelai_709894_value", "value", "TM_GetProductDial", "dial", "dial")), "string")
        }

		
        if (true) {
        KuikaAppManager.showSpinner(this);
        }
        let result = await KuikaAppManager.ApiRequest(this, "LeadAddByExcelAI/LeadAddByExcelAIComponent_709894_onChange1_", localVar)
        if (!KMainFunctions.IsResStatus2XX(result)) return true;

			stateVars.TM_GetProductBracelet = result?.data.tM_GetProductBracelet;
			
			formVars.leadaddbyexcelai_806227_options = stateVars.TM_GetProductBracelet;
			this.props.form?.setFieldsValue(formVars);
			
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.LeadAddByExcelAIComponent_709894_onChange2_();
                  resolve();
                });
          })



        
        KuikaAppManager.hideSpinner(this);
        return isErrorOccurred;
    }
		LeadAddByExcelAIComponent_709894_onChange2_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }

				
				stateVars.dataSource_806227 = stateVars.TM_GetProductBracelet ?? this.state.TM_GetProductBracelet;
				stateVars.dataSource_806227 = stateVars.TM_GetProductBracelet ?? this.state.TM_GetProductBracelet;

		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

            
            return isErrorOccurred;
        }





    LeadAddByExcelAIComponent_806227_onChange = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;

			validations.push({ 
				isValid: ReactSystemFunctions.isNotEmpty(ReactSystemFunctions.value(this, "leadaddbyexcelai_888506_value", "value", "TM_GetProductReferance", "referance", "referance"), null),
				message: "Bu alan boş bırakılamaz!",
				formName: "leadaddbyexcelai_888506_value",
				condition: true
			} as IValidationData);

validations.forEach((validation) => {
            if (validation.message === "Geçerli bir mail adresi giriniz.") {
                validation.message = ReactSystemFunctions.getEmailValidationMessage()
            }
        })
			validations.push({ 
				isValid: ReactSystemFunctions.isNotEmpty(ReactSystemFunctions.value(this, "leadaddbyexcelai_709894_value", "value", "TM_GetProductDial", "dial", "dial"), null),
				message: "Bu alan boş bırakılamaz!",
				formName: "leadaddbyexcelai_709894_value",
				condition: true
			} as IValidationData);

validations.forEach((validation) => {
            if (validation.message === "Geçerli bir mail adresi giriniz.") {
                validation.message = ReactSystemFunctions.getEmailValidationMessage()
            }
        })
			validations.push({ 
				isValid: ReactSystemFunctions.isNotEmpty(ReactSystemFunctions.value(this, "leadaddbyexcelai_806227_value", "value", "TM_GetProductBracelet", "bracelet", "bracelet"), null),
				message: "Bu alan boş bırakılamaz!",
				formName: "leadaddbyexcelai_806227_value",
				condition: true
			} as IValidationData);

validations.forEach((validation) => {
            if (validation.message === "Geçerli bir mail adresi giriniz.") {
                validation.message = ReactSystemFunctions.getEmailValidationMessage()
            }
        })

		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
		KuikaAppManager.increaseServerRequestCount();

        let localVar = {
				Brand_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "leadaddbyexcelai_428403_value", "value", "TM_GetProductBrand", "brand", "brand")), "string"),
				Referance_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "leadaddbyexcelai_888506_value", "value", "TM_GetProductReferance", "referance", "referance")), "string"),
				Dial_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "leadaddbyexcelai_709894_value", "value", "TM_GetProductDial", "dial", "dial")), "string"),
				Bracelet_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "leadaddbyexcelai_806227_value", "value", "TM_GetProductBracelet", "bracelet", "bracelet")), "string")
        }

		KuikaAppManager.showSpinner(this);
		
        if (true) {
        KuikaAppManager.showSpinner(this);
        }
        let result = await KuikaAppManager.ApiRequest(this, "LeadAddByExcelAI/LeadAddByExcelAIComponent_806227_onChange", localVar)
        if (!KMainFunctions.IsResStatus2XX(result)) return true;

			stateVars.TM_GetProduct = result?.data.tM_GetProduct;
			formVars.leadaddbyexcelai_134089_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetProduct !== undefined ? (stateVars.TM_GetProduct?.length > 0 ? stateVars.TM_GetProduct[0].referance : null) : (this.state.TM_GetProduct?.length > 0 ? this.state.TM_GetProduct[0].referance : null)));
			formVars.leadaddbyexcelai_795672_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetProduct !== undefined ? (stateVars.TM_GetProduct?.length > 0 ? stateVars.TM_GetProduct[0].categoryName : null) : (this.state.TM_GetProduct?.length > 0 ? this.state.TM_GetProduct[0].categoryName : null)));
			stateVars.isComp795672Visible = ((ReactSystemFunctions.isNotEmpty(ReactSystemFunctions.toString(this, (stateVars.TM_GetProduct !== undefined ? (stateVars.TM_GetProduct?.length > 0 ? stateVars.TM_GetProduct[0].categoryName : null) : (this.state.TM_GetProduct?.length > 0 ? this.state.TM_GetProduct[0].categoryName : null))), ReactSystemFunctions.convertToTypeByName("True", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp980874Visible = ((ReactSystemFunctions.isEmpty(ReactSystemFunctions.toString(this, (stateVars.TM_GetProduct !== undefined ? (stateVars.TM_GetProduct?.length > 0 ? stateVars.TM_GetProduct[0].categoryName : null) : (this.state.TM_GetProduct?.length > 0 ? this.state.TM_GetProduct[0].categoryName : null))), ReactSystemFunctions.convertToTypeByName("True", "string"))) === true ? "visible" : "hidden")
			this.props.form?.setFieldsValue(formVars);
			
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.LeadAddByExcelAIComponent_806227_onChange1_();
                  resolve();
                });
          })



        
        KuikaAppManager.hideSpinner(this);
        return isErrorOccurred;
    }
		LeadAddByExcelAIComponent_806227_onChange1_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }

				stateVars.isComp612838Visible = ((ReactSystemFunctions.isNotEmpty(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "leadaddbyexcelai_806227_value", "value", "TM_GetProductBracelet", "bracelet", "bracelet")), ReactSystemFunctions.convertToTypeByName("True", "string"))) === true ? "visible" : "hidden")
				formVars.leadaddbyexcelai_134089_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetProduct !== undefined ? (stateVars.TM_GetProduct?.length > 0 ? stateVars.TM_GetProduct[0].referance : null) : (this.state.TM_GetProduct?.length > 0 ? this.state.TM_GetProduct[0].referance : null)));

				formVars.leadaddbyexcelai_795672_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetProduct !== undefined ? (stateVars.TM_GetProduct?.length > 0 ? stateVars.TM_GetProduct[0].categoryName : null) : (this.state.TM_GetProduct?.length > 0 ? this.state.TM_GetProduct[0].categoryName : null)));


		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

            
            return isErrorOccurred;
        }




    LeadAddByExcelAIComponent_615093_onClick = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;

			validations.push({ 
				isValid: ReactSystemFunctions.isNotEmpty(ReactSystemFunctions.value(this, "leadaddbyexcelai_276724_value", "value", "GetLeadProcessForExcel", "id", "id"), null),
				message: "Bu alan boş bırakılamaz!",
				formName: "leadaddbyexcelai_276724_value",
				condition: true
			} as IValidationData);

validations.forEach((validation) => {
            if (validation.message === "Geçerli bir mail adresi giriniz.") {
                validation.message = ReactSystemFunctions.getEmailValidationMessage()
            }
        })
			validations.push({ 
				isValid: ReactSystemFunctions.isNotEmpty(ReactSystemFunctions.value(this, "leadaddbyexcelai_980478_value", "value", "TM_GetLeadStatus", "id", "id"), null),
				message: "Bu alan boş bırakılamaz!",
				formName: "leadaddbyexcelai_980478_value",
				condition: true
			} as IValidationData);

validations.forEach((validation) => {
            if (validation.message === "Geçerli bir mail adresi giriniz.") {
                validation.message = ReactSystemFunctions.getEmailValidationMessage()
            }
        })
			validations.push({ 
				isValid: ReactSystemFunctions.isNotEmpty(ReactSystemFunctions.value(this, "leadaddbyexcelai_991992_value", "value", "TM_StoreGetList", "id", "id"), null),
				message: "Bu alan boş bırakılamaz!",
				formName: "leadaddbyexcelai_991992_value",
				condition: ReactSystemFunctions.contains(ReactSystemFunctions.getMyRoleNames(), ReactSystemFunctions.convertToTypeByName("TimesUstYonetici", "string"))
			} as IValidationData);

validations.forEach((validation) => {
            if (validation.message === "Geçerli bir mail adresi giriniz.") {
                validation.message = ReactSystemFunctions.getEmailValidationMessage()
            }
        })
			validations.push({ 
				isValid: ReactSystemFunctions.isNotEmpty(ReactSystemFunctions.value(this, "leadaddbyexcelai_598679_value", "value", "GetSalesPersonByStore", "kuserID", "id"), null),
				message: "Bu alan boş bırakılamaz !",
				formName: "leadaddbyexcelai_598679_value",
				condition: ReactSystemFunctions.contains(ReactSystemFunctions.getMyRoleNames(), ReactSystemFunctions.convertToTypeByName("TimesMagazaMuduru", "string"))
			} as IValidationData);

validations.forEach((validation) => {
            if (validation.message === "Geçerli bir mail adresi giriniz.") {
                validation.message = ReactSystemFunctions.getEmailValidationMessage()
            }
        })
			validations.push({ 
				isValid: ReactSystemFunctions.isNotEmpty(ReactSystemFunctions.value(this, "leadaddbyexcelai_537845_value", "value", "TM_GetCustomerByName", "id", "id"), null),
				message: "Bu alan boş bırakılamaz!",
				formName: "leadaddbyexcelai_537845_value",
				condition: true
			} as IValidationData);

validations.forEach((validation) => {
            if (validation.message === "Geçerli bir mail adresi giriniz.") {
                validation.message = ReactSystemFunctions.getEmailValidationMessage()
            }
        })

		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
		KuikaAppManager.increaseServerRequestCount();

        let localVar = {
				ProcessId_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "leadaddbyexcelai_276724_value", "value", "GetLeadProcessForExcel", "id", "id")), "Guid"),
				Year_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toInteger(this, ReactSystemFunctions.value(this, "leadaddbyexcelai_224565_value", "value", "", "key", "")), "number"),
				Month_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toInteger(this, ReactSystemFunctions.value(this, "leadaddbyexcelai_201361_value", "value", "", "key", "")), "number"),
				CreatedAt_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "leadaddbyexcelai_237650_value", "value", "", "", "")), "Date"),
				ReferenceID_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "leadaddbyexcelai_221998_value", "value", "TM_GetReferanceByCurrAccCode", "id", "id")), "Guid"),
				Brand_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "leadaddbyexcelai_428403_value", "value", "TM_GetProductBrand", "brand", "brand")), "string"),
				StatuId_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "leadaddbyexcelai_980478_value", "value", "TM_GetLeadStatus", "id", "id")), "Guid"),
				NextStepId_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "leadaddbyexcelai_145272_value", "value", "TM_GetLeadNextSteps", "id", "id")), "Guid"),
				ProductId_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, (stateVars.TM_GetProduct !== undefined ? (stateVars.TM_GetProduct?.length > 0 ? stateVars.TM_GetProduct[0].id : null) : (this.state.TM_GetProduct?.length > 0 ? this.state.TM_GetProduct[0].id : null))), "Guid"),
				ContactResourceId_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "leadaddbyexcelai_894616_value", "value", "TM_GetAllContactSource", "id", "id")), "Guid"),
				KUserId_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.getMyUserId(), "Guid"),
				StoreId_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "leadaddbyexcelai_991992_value", "value", "TM_StoreGetList", "id", "id")), "Guid"),
				SalesPersonKUserId_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "leadaddbyexcelai_598679_value", "value", "GetSalesPersonByStore", "kuserID", "kuserID")), "Guid"),
				CreatedBy_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "leadaddbyexcelai_981281_value", "value", "TM_GetAppUser", "kUserId", "kUserId")), "Guid"),
				CustomerId_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "leadaddbyexcelai_537845_value", "value", "TM_GetCustomerByName", "id", "id")), "Guid"),
				LeadNote_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "leadaddbyexcelai_715637_value", "value", "", "", "")), "string"),
				SessionCode_0: ReactSystemFunctions.convertToTypeByName("", "string")
        }

		KuikaAppManager.showSpinner(this);
if ((ReactSystemFunctions.contains(ReactSystemFunctions.getMyRoleNames(), ReactSystemFunctions.convertToTypeByName("TimesYonetici", "string")) || ReactSystemFunctions.contains(ReactSystemFunctions.getMyRoleNames(), ReactSystemFunctions.convertToTypeByName("TimesUstYonetici", "string")))) {
            		
        if (true) {
        KuikaAppManager.showSpinner(this);
        }
        let result = await KuikaAppManager.ApiRequest(this, "LeadAddByExcelAI/LeadAddByExcelAIComponent_615093_onClick", localVar)
        if (!KMainFunctions.IsResStatus2XX(result)) return true;

			stateVars.LeadAddExcel = result?.data.leadAddExcel;
			this.props.form?.setFieldsValue(formVars);
			
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.LeadAddByExcelAIComponent_615093_onClick1_();
                  resolve();
                });
          })

        } else {
            
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.LeadAddByExcelAIComponent_615093_onClick1_();
                  resolve();
                });
          })
        }


        
        KuikaAppManager.hideSpinner(this);
        return isErrorOccurred;
    }
    LeadAddByExcelAIComponent_615093_onClick1_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;

			validations.push({ 
				isValid: ReactSystemFunctions.isNotEmpty(ReactSystemFunctions.value(this, "leadaddbyexcelai_276724_value", "value", "GetLeadProcessForExcel", "id", "id"), null),
				message: "Bu alan boş bırakılamaz!",
				formName: "leadaddbyexcelai_276724_value",
				condition: true
			} as IValidationData);

validations.forEach((validation) => {
            if (validation.message === "Geçerli bir mail adresi giriniz.") {
                validation.message = ReactSystemFunctions.getEmailValidationMessage()
            }
        })
			validations.push({ 
				isValid: ReactSystemFunctions.isNotEmpty(ReactSystemFunctions.value(this, "leadaddbyexcelai_980478_value", "value", "TM_GetLeadStatus", "id", "id"), null),
				message: "Bu alan boş bırakılamaz!",
				formName: "leadaddbyexcelai_980478_value",
				condition: true
			} as IValidationData);

validations.forEach((validation) => {
            if (validation.message === "Geçerli bir mail adresi giriniz.") {
                validation.message = ReactSystemFunctions.getEmailValidationMessage()
            }
        })
			validations.push({ 
				isValid: ReactSystemFunctions.isNotEmpty(ReactSystemFunctions.value(this, "leadaddbyexcelai_598679_value", "value", "GetSalesPersonByStore", "kuserID", "id"), null),
				message: "Bu alan boş bırakılamaz !",
				formName: "leadaddbyexcelai_598679_value",
				condition: ReactSystemFunctions.contains(ReactSystemFunctions.getMyRoleNames(), ReactSystemFunctions.convertToTypeByName("TimesMagazaMuduru", "string"))
			} as IValidationData);

validations.forEach((validation) => {
            if (validation.message === "Geçerli bir mail adresi giriniz.") {
                validation.message = ReactSystemFunctions.getEmailValidationMessage()
            }
        })
			validations.push({ 
				isValid: ReactSystemFunctions.isNotEmpty(ReactSystemFunctions.value(this, "leadaddbyexcelai_537845_value", "value", "TM_GetCustomerByName", "id", "id"), null),
				message: "Bu alan boş bırakılamaz!",
				formName: "leadaddbyexcelai_537845_value",
				condition: true
			} as IValidationData);

validations.forEach((validation) => {
            if (validation.message === "Geçerli bir mail adresi giriniz.") {
                validation.message = ReactSystemFunctions.getEmailValidationMessage()
            }
        })

		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
		KuikaAppManager.increaseServerRequestCount();

        let localVar = {
				ProcessId_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "leadaddbyexcelai_276724_value", "value", "GetLeadProcessForExcel", "id", "id")), "Guid"),
				Year_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toInteger(this, ReactSystemFunctions.value(this, "leadaddbyexcelai_224565_value", "value", "", "key", "")), "number"),
				Month_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toInteger(this, ReactSystemFunctions.value(this, "leadaddbyexcelai_201361_value", "value", "", "key", "")), "number"),
				CreatedAt_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "leadaddbyexcelai_237650_value", "value", "", "", "")), "Date"),
				ReferenceID_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "leadaddbyexcelai_221998_value", "value", "TM_GetReferanceByCurrAccCode", "id", "id")), "Guid"),
				Brand_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "leadaddbyexcelai_428403_value", "value", "TM_GetProductBrand", "brand", "brand")), "string"),
				StatuId_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "leadaddbyexcelai_980478_value", "value", "TM_GetLeadStatus", "id", "id")), "Guid"),
				NextStepId_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "leadaddbyexcelai_145272_value", "value", "TM_GetLeadNextSteps", "id", "id")), "Guid"),
				ProductId_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, (stateVars.TM_GetProduct !== undefined ? (stateVars.TM_GetProduct?.length > 0 ? stateVars.TM_GetProduct[0].id : null) : (this.state.TM_GetProduct?.length > 0 ? this.state.TM_GetProduct[0].id : null))), "Guid"),
				ContactResourceId_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "leadaddbyexcelai_894616_value", "value", "TM_GetAllContactSource", "id", "id")), "Guid"),
				KUserId_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.getMyUserId(), "Guid"),
				StoreId_0: ReactSystemFunctions.convertToTypeByName(null, "Guid"),
				SalesPersonKUserId_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "leadaddbyexcelai_598679_value", "value", "GetSalesPersonByStore", "kuserID", "kuserID")), "Guid"),
				CreatedBy_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "leadaddbyexcelai_981281_value", "value", "TM_GetAppUser", "kUserId", "kUserId")), "Guid"),
				CustomerId_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "leadaddbyexcelai_537845_value", "value", "TM_GetCustomerByName", "id", "id")), "Guid"),
				LeadNote_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "leadaddbyexcelai_715637_value", "value", "", "", "")), "string"),
				SessionCode_0: ReactSystemFunctions.convertToTypeByName("", "string")
        }

if (ReactSystemFunctions.contains(ReactSystemFunctions.getMyRoleNames(), ReactSystemFunctions.convertToTypeByName("TimesMagazaMuduru", "string"))) {
            		
        if (true) {
        KuikaAppManager.showSpinner(this);
        }
        let result = await KuikaAppManager.ApiRequest(this, "LeadAddByExcelAI/LeadAddByExcelAIComponent_615093_onClick1_", localVar)
        if (!KMainFunctions.IsResStatus2XX(result)) return true;

			stateVars.LeadAddExcel = result?.data.leadAddExcel;
			this.props.form?.setFieldsValue(formVars);
			
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.LeadAddByExcelAIComponent_615093_onClick2_();
                  resolve();
                });
          })

        } else {
            
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.LeadAddByExcelAIComponent_615093_onClick2_();
                  resolve();
                });
          })
        }


        
        KuikaAppManager.hideSpinner(this);
        return isErrorOccurred;
    }
    LeadAddByExcelAIComponent_615093_onClick2_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;

			validations.push({ 
				isValid: ReactSystemFunctions.isNotEmpty(ReactSystemFunctions.value(this, "leadaddbyexcelai_276724_value", "value", "GetLeadProcessForExcel", "id", "id"), null),
				message: "Bu alan boş bırakılamaz!",
				formName: "leadaddbyexcelai_276724_value",
				condition: true
			} as IValidationData);

validations.forEach((validation) => {
            if (validation.message === "Geçerli bir mail adresi giriniz.") {
                validation.message = ReactSystemFunctions.getEmailValidationMessage()
            }
        })
			validations.push({ 
				isValid: ReactSystemFunctions.isNotEmpty(ReactSystemFunctions.value(this, "leadaddbyexcelai_980478_value", "value", "TM_GetLeadStatus", "id", "id"), null),
				message: "Bu alan boş bırakılamaz!",
				formName: "leadaddbyexcelai_980478_value",
				condition: true
			} as IValidationData);

validations.forEach((validation) => {
            if (validation.message === "Geçerli bir mail adresi giriniz.") {
                validation.message = ReactSystemFunctions.getEmailValidationMessage()
            }
        })
			validations.push({ 
				isValid: ReactSystemFunctions.isNotEmpty(ReactSystemFunctions.value(this, "leadaddbyexcelai_537845_value", "value", "TM_GetCustomerByName", "id", "id"), null),
				message: "Bu alan boş bırakılamaz!",
				formName: "leadaddbyexcelai_537845_value",
				condition: true
			} as IValidationData);

validations.forEach((validation) => {
            if (validation.message === "Geçerli bir mail adresi giriniz.") {
                validation.message = ReactSystemFunctions.getEmailValidationMessage()
            }
        })

		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
		KuikaAppManager.increaseServerRequestCount();

        let localVar = {
				ProcessId_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "leadaddbyexcelai_276724_value", "value", "GetLeadProcessForExcel", "id", "id")), "Guid"),
				Year_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toInteger(this, ReactSystemFunctions.value(this, "leadaddbyexcelai_224565_value", "value", "", "key", "")), "number"),
				Month_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toInteger(this, ReactSystemFunctions.value(this, "leadaddbyexcelai_201361_value", "value", "", "key", "")), "number"),
				CreatedAt_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "leadaddbyexcelai_237650_value", "value", "", "", "")), "Date"),
				ReferenceID_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "leadaddbyexcelai_221998_value", "value", "TM_GetReferanceByCurrAccCode", "id", "id")), "Guid"),
				Brand_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "leadaddbyexcelai_428403_value", "value", "TM_GetProductBrand", "brand", "brand")), "string"),
				StatuId_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "leadaddbyexcelai_980478_value", "value", "TM_GetLeadStatus", "id", "id")), "Guid"),
				NextStepId_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "leadaddbyexcelai_145272_value", "value", "TM_GetLeadNextSteps", "id", "id")), "Guid"),
				ProductId_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, (stateVars.TM_GetProduct !== undefined ? (stateVars.TM_GetProduct?.length > 0 ? stateVars.TM_GetProduct[0].id : null) : (this.state.TM_GetProduct?.length > 0 ? this.state.TM_GetProduct[0].id : null))), "Guid"),
				ContactResourceId_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "leadaddbyexcelai_894616_value", "value", "TM_GetAllContactSource", "id", "id")), "Guid"),
				KUserId_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.getMyUserId(), "Guid"),
				StoreId_0: ReactSystemFunctions.convertToTypeByName(null, "Guid"),
				SalesPersonKUserId_0: ReactSystemFunctions.convertToTypeByName(null, "Guid"),
				CreatedBy_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "leadaddbyexcelai_981281_value", "value", "TM_GetAppUser", "kUserId", "kUserId")), "Guid"),
				CustomerId_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "leadaddbyexcelai_537845_value", "value", "TM_GetCustomerByName", "id", "id")), "Guid"),
				LeadNote_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "leadaddbyexcelai_715637_value", "value", "", "", "")), "string"),
				SessionCode_0: ReactSystemFunctions.convertToTypeByName("", "string")
        }

if (ReactSystemFunctions.contains(ReactSystemFunctions.getMyRoleNames(), ReactSystemFunctions.convertToTypeByName("TimesSatisPersoneli", "string"))) {
            		
        if (true) {
        KuikaAppManager.showSpinner(this);
        }
        let result = await KuikaAppManager.ApiRequest(this, "LeadAddByExcelAI/LeadAddByExcelAIComponent_615093_onClick2_", localVar)
        if (!KMainFunctions.IsResStatus2XX(result)) return true;

			stateVars.LeadAddExcel = result?.data.leadAddExcel;
			this.props.form?.setFieldsValue(formVars);
			
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.LeadAddByExcelAIComponent_615093_onClick3_();
                  resolve();
                });
          })

        } else {
            
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.LeadAddByExcelAIComponent_615093_onClick3_();
                  resolve();
                });
          })
        }


        
        KuikaAppManager.hideSpinner(this);
        return isErrorOccurred;
    }
		LeadAddByExcelAIComponent_615093_onClick3_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }

				stateVars.Notify = await ReactSystemFunctions.notify(this, ReactSystemFunctions.toString(this, (stateVars.LeadAddExcel !== undefined ? (stateVars.LeadAddExcel?.length > 0 ? stateVars.LeadAddExcel[0].message : null) : (this.state.LeadAddExcel?.length > 0 ? this.state.LeadAddExcel[0].message : null))), ReactSystemFunctions.convertToTypeByName("default", "string"), ReactSystemFunctions.convertToTypeByName("top-center", "string"), 2, ReactSystemFunctions.convertToTypeByName("", "string"), ReactSystemFunctions.convertToTypeByName("", "string"), 0);

		this.props.form?.setFieldsValue(formVars);
		
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.LeadAddByExcelAIComponent_615093_onClick4_();
                  resolve();
                });
          })

            
            return isErrorOccurred;
        }
		LeadAddByExcelAIComponent_615093_onClick4_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
if (ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, (stateVars.LeadAddExcel !== undefined ? (stateVars.LeadAddExcel?.length > 0 ? stateVars.LeadAddExcel[0].isSuccess : null) : (this.state.LeadAddExcel?.length > 0 ? this.state.LeadAddExcel[0].isSuccess : null))), true)) {
            
				stateVars.GoBack = await ReactSystemFunctions.goBack(this, false);

		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

        } else {
            KuikaAppManager.hideSpinner(this);
        }

            
            return isErrorOccurred;
        }











    async callCallbackFunction(diId: number, isFromMaster: boolean = false) {
        let isErrorOccurred = false;
		let pageInitCallerNavDiIDs = [91672, , , ] as number[];
		if (isFromMaster || pageInitCallerNavDiIDs.indexOf(diId) > -1) {
			await this.LeadAddByExcelAIPageInit();
		}

    }


}
