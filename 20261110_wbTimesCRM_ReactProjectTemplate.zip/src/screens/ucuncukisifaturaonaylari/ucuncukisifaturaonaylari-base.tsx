import React from "react";
import Axios, { AxiosResponse } from "axios";
import { KuikaAppManager } from "../../shared/utilty/kuika-app-manager";
import { ReactSystemFunctions } from "../../shared/utilty/react-system-functions";
import { KNavigator } from "../../shared/hoc/with-history";
import { KContext } from "../../shared/hoc/with-context";
import { useLocation } from "react-router-dom";
import { FormInstance } from "antd/es/form";
import { Guid } from "guid-typescript";
import Swal from "sweetalert2";
import { KMainFunctions } from "../../shared/utilty/main-functions";
import moment from "moment";
import { IValidationData } from "../../models/dto/validation-data";
import { IStripePayment } from "../../models/dto/stripe-payment";
import { IUserInfoDto } from "../../models/dto/user-info.dto";
import { UserService } from "../../services/user-service";
import { kuikaCoreWasmBridgeService } from "../../services/_singletons";
import _ from "lodash";
import mqtt, { MqttClient } from "mqtt";
import { IMqttResult } from "../../models/dto/mqtt.dto";
import { MasterScreen_ScreenContext } from "../masterscreen/masterscreen-context";

declare let window: any;

export interface IUcuncuKisiFaturaOnaylari_ScreenProps {
  navigator: KNavigator;
  form: FormInstance<any>;
  googleLogin: any;
  screenInputs: any;
  context: KContext;
  initialValues: any;
  children: any;
}

export interface IUcuncuKisiFaturaOnaylari_ScreenState {
    isSpinnerVisible: boolean;
    isPageVisible: boolean;
	isLeftMenuVisible: boolean;
    spinnerCount: number;
    selectedLanguage: string;
    isPageInitLoaded: false;
    isPageRecurringLoaded: false;
	TM_GetPendingThirdPartyInvoiceApprovals: any[];
	TM_GetPendingThirdPartyInvoiceApprovals_dummy: any[];
	NAVIGATE: any;
	NAVIGATE_dummy: any;
	isComp1462538534Visible: 'visible' | 'hidden';

}

export class UcuncuKisiFaturaOnaylari_ScreenBase extends React.PureComponent<IUcuncuKisiFaturaOnaylari_ScreenProps, any> {
    static contextType = MasterScreen_ScreenContext;
    declare context: React.ContextType<typeof MasterScreen_ScreenContext>;
	ucuncukisifaturaonaylari_22328338_value_kuikaTableRef: React.RefObject<any>;
    ml=[{"Id":"d5a61d2b-bd60-485f-86e2-661e9ed4e486","Name":"en_US","ShortName":"English","IsDefault":true,"LanguagePhrases":[]},{"Id":"6257b610-91d0-423a-aa0c-4aba4cd2df78","Name":"FixedValues","ShortName":"FixedValues","LanguagePhrases":[{"Id":833608855,"PropertyName":"value","Value":"3. Kişi Fatura Onayları"},{"Id":964581461,"PropertyName":"value","Value":"Satış personelleri tarafından gönderilen 3. kişi adına faturalandırma taleplerini inceleyin ve sonuçlandırın."},{"Id":2005543627,"PropertyName":"value","Value":"Yönetici Onayı"},{"Id":1178313619,"PropertyName":"value","Value":"Bekleyen talepler onaylanmadan satış faturası oluşturulamaz. Verilen kararlar kullanıcı ve zaman bilgisiyle kayıt altına alınır."},{"Id":1600821227,"PropertyName":"value","Value":"Bekleyen Onay Talepleri"},{"Id":14224224,"PropertyName":"value","Value":"İncelemek istediğiniz talebin sağındaki İncele butonunu kullanın."},{"Id":22328338,"PropertyName":"nodatafoundmessage","Value":"Bekleyen onay talebi bulunmuyor"},{"Id":2042152332,"PropertyName":"title","Value":"Talep Tarihi"},{"Id":987958174,"PropertyName":"value","Value":"[datafield:requestedat]"},{"Id":528534976,"PropertyName":"title","Value":"Fatura Edilecek Kişi / Şirket"},{"Id":910635711,"PropertyName":"value","Value":"[datafield:thirdpartyfullname]"},{"Id":514933487,"PropertyName":"title","Value":"Tür"},{"Id":1202547326,"PropertyName":"value","Value":"[datafield:persontype]"},{"Id":1163915756,"PropertyName":"title","Value":"Talep Eden"},{"Id":215949508,"PropertyName":"value","Value":"[datafield:requestedbyfullname]"},{"Id":1311581096,"PropertyName":"title","Value":"Mağaza"},{"Id":1334702688,"PropertyName":"value","Value":"[datafield:storename]"},{"Id":229781254,"PropertyName":"title","Value":"Satış Tutarı"},{"Id":302734069,"PropertyName":"value","Value":"[datafield:totalamounteur]"},{"Id":714786738,"PropertyName":"title","Value":"Para Birimi"},{"Id":1887115334,"PropertyName":"value","Value":"[datafield:currencycode]"},{"Id":373587348,"PropertyName":"title","Value":"Durum"},{"Id":1916281874,"PropertyName":"value","Value":"[datafield:approvalstatustext]"},{"Id":1075345007,"PropertyName":"title","Value":"İşlem"},{"Id":635321182,"PropertyName":"label","Value":"İncele"},{"Id":1492635237,"PropertyName":"value","Value":"Bekleyen onay talebi bulunmuyor"},{"Id":196580483,"PropertyName":"value","Value":"Yeni bir talep gönderildiğinde burada görüntülenecektir."}]}]
    defaultML = "en_US"
    
    screenHash = ""
    

    private _prevMasterPageInitLoaded: boolean = false;
    private _prevMasterPageRecurringLoaded: boolean = false;
    private _prevShouldTriggerPageInit: boolean = false;
    constructor(props) {
        super(props);
		this.ucuncukisifaturaonaylari_22328338_value_kuikaTableRef = React.createRef();

        this.state = {
            isSpinnerVisible: false,
            isPageVisible: false,
            isLeftMenuVisible: false,
            spinnerCount: 0,
            selectedLanguage: "",
            isPageInitLoaded: false,
            isPageRecurringLoaded: false,
            	        TM_GetPendingThirdPartyInvoiceApprovals: [],
	        NAVIGATE: "",
	        isComp1462538534Visible: 'hidden',

        }

        this.state.isPageVisible = true;
        
    }

    async componentDidMount() {

        if (KuikaAppManager.isPageInitPrevented()) {
            KuikaAppManager.calculateAndSetBodyHeight("ucuncukisifaturaonaylari", "masterscreen_screen");
            return;
        }
        this.context.registerCallbackFunction(this.callCallbackFunction.bind(this));
        
        ReactSystemFunctions.validateToken()
        this.fillFormInitValues();
        if (false){
            await this.UcuncuKisiFaturaOnaylariPageInit();
        } else if (this.context?.isMasterPageInitLoaded) { this._prevMasterPageInitLoaded = true; await this.UcuncuKisiFaturaOnaylariPageInit(); }
        
        
        
        KuikaAppManager.calculateAndSetBodyHeight("ucuncukisifaturaonaylari", "masterscreen_screen");

        if (ReactSystemFunctions.getIsMicroApp() === false) {
           window.parentScreen = this;
        }
    }

    componentWillUnmount() {
        
        
        

        if (ReactSystemFunctions.getIsMicroApp() === false) {
           window.parentScreen = null;
        }
    }

    

        
    componentDidUpdate= async (prevProps, prevState) => {
		KuikaAppManager.calculateAndSetBodyHeight("ucuncukisifaturaonaylari", "masterscreen_screen"    );
        if (prevProps?.location?.search !== (this.props as any)?.location?.search) {
			await this.UcuncuKisiFaturaOnaylariPageInit();
		}

        		if (this._prevMasterPageInitLoaded !== this.context.isMasterPageInitLoaded && this.context.isMasterPageInitLoaded === true) {this._prevMasterPageInitLoaded = this.context.isMasterPageInitLoaded;await this.UcuncuKisiFaturaOnaylariPageInit()}


        if (ReactSystemFunctions.getIsMicroApp() === false) {
            for (const key in prevState) {
                if (key.startsWith('NavVisible') && prevState[key] === true && this.state[key] === false) {
                    window.parentScreen = this;
                    break;
                }
            }
        }
	}

    fillFormInitValues() {
        this.props.form?.setFieldsValue({
});

    }

      setPageInitLoaded = (value: boolean) => {
        this.setState({ isPageInitLoaded: value });
      }

      setPageRecurringLoaded = (value: boolean) => {
        this.setState({ isPageRecurringLoaded: value });
      }

      clearFieldValidation = (changedValues: any) => {
        const fieldName = Object.keys(changedValues)[0];
        if (fieldName) {
          this.props.form?.setFields([
            {
              name: fieldName,
              errors: []
            }
          ]);
        }
      };

      

    UcuncuKisiFaturaOnaylariPageInit = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


	if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }

        let localVar = {
			CurrentUserId_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.getMyUserId(), "Guid")
        }

	KuikaAppManager.showSpinner(this);
	
        if (true) {
        KuikaAppManager.showSpinner(this);
        }
        let result = await KuikaAppManager.ApiRequest(this, "UcuncuKisiFaturaOnaylari/UcuncuKisiFaturaOnaylariPageInit", localVar)
        if (!KMainFunctions.IsResStatus2XX(result)) return true;

		stateVars.TM_GetPendingThirdPartyInvoiceApprovals = result?.data.tM_GetPendingThirdPartyInvoiceApprovals;
		
		stateVars.isComp1462538534Visible = ((ReactSystemFunctions.isEmpty(ReactSystemFunctions.value(this, (stateVars.TM_GetPendingThirdPartyInvoiceApprovals !== undefined ? (stateVars.TM_GetPendingThirdPartyInvoiceApprovals?.length > 0 ? stateVars.TM_GetPendingThirdPartyInvoiceApprovals[0].approvalId : null) : (this.state.TM_GetPendingThirdPartyInvoiceApprovals?.length > 0 ? this.state.TM_GetPendingThirdPartyInvoiceApprovals[0].approvalId : null))), ReactSystemFunctions.convertToTypeByName("True", "string"))) === true ? "visible" : "hidden")
		this.props.form?.setFieldsValue(formVars);
		
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.UcuncuKisiFaturaOnaylariPageInit1_();
                  resolve();
                });
          })



        
        KuikaAppManager.hideSpinner(this);
        return isErrorOccurred;
    }
	UcuncuKisiFaturaOnaylariPageInit1_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


	if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }

			
			stateVars.dataSource_22328338 = stateVars.TM_GetPendingThirdPartyInvoiceApprovals ?? this.state.TM_GetPendingThirdPartyInvoiceApprovals;
			stateVars.isComp1462538534Visible = ((ReactSystemFunctions.isEmpty(ReactSystemFunctions.value(this, (stateVars.TM_GetPendingThirdPartyInvoiceApprovals !== undefined ? (stateVars.TM_GetPendingThirdPartyInvoiceApprovals?.length > 0 ? stateVars.TM_GetPendingThirdPartyInvoiceApprovals[0].approvalId : null) : (this.state.TM_GetPendingThirdPartyInvoiceApprovals?.length > 0 ? this.state.TM_GetPendingThirdPartyInvoiceApprovals[0].approvalId : null))), ReactSystemFunctions.convertToTypeByName("True", "string"))) === true ? "visible" : "hidden")

	this.props.form?.setFieldsValue(formVars);
	this.setState(stateVars);
	KuikaAppManager.hideSpinner(this);

            this.setPageInitLoaded(true);
            return isErrorOccurred;
        }




		UcuncuKisiFaturaOnaylariComponent_635321182_onClick = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
KuikaAppManager.showSpinner(this);

					KuikaAppManager.prepareForNavigation();
						KuikaAppManager.addToPageInputVariables("UcuncuKisiFaturaOnayDetayi", "ApprovalId", ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, "ucuncukisifaturaonaylari_22328338_value", "approvalId"), "Guid"));

				stateVars.NAVIGATE = await ReactSystemFunctions.navigate(this, undefined, "UcuncuKisiFaturaOnaylari", "UcuncuKisiFaturaOnayDetayi", "", "7d969ddf-5801-4eb6-b92b-12be35bdd565", "767737143", null, "right", "true", "90%", "100vh", false, false);

		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

            
            return isErrorOccurred;
        }




    async callCallbackFunction(diId: number, isFromMaster: boolean = false) {
        let isErrorOccurred = false;
		let pageInitCallerNavDiIDs = [] as number[];
		if (isFromMaster || pageInitCallerNavDiIDs.indexOf(diId) > -1) {
			await this.UcuncuKisiFaturaOnaylariPageInit();
		}

    }


}
