import React from "react";
import Axios, { AxiosResponse } from "axios";
import { KuikaAppManager } from "../../shared/utilty/kuika-app-manager";
import { ReactSystemFunctions } from "../../shared/utilty/react-system-functions";
import { KNavigator } from "../../shared/hoc/with-history";
import { KContext } from "../../shared/hoc/with-context";
import { useLocation } from "react-router-dom";
import { FormInstance } from "antd/es/form";
import { Guid } from "guid-typescript";
import Swal from "sweetalert2";
import { KMainFunctions } from "../../shared/utilty/main-functions";
import moment from "moment";
import { IValidationData } from "../../models/dto/validation-data";
import { IStripePayment } from "../../models/dto/stripe-payment";
import { IUserInfoDto } from "../../models/dto/user-info.dto";
import { UserService } from "../../services/user-service";
import { kuikaCoreWasmBridgeService } from "../../services/_singletons";
import _ from "lodash";
import mqtt, { MqttClient } from "mqtt";
import { IMqttResult } from "../../models/dto/mqtt.dto";


declare let window: any;

export interface IDNM0100DetailScreen_ScreenProps {
  navigator: KNavigator;
  form: FormInstance<any>;
  googleLogin: any;
  screenInputs: any;
  context: KContext;
  initialValues: any;
  children: any;
}

export interface IDNM0100DetailScreen_ScreenState {
    isSpinnerVisible: boolean;
    isPageVisible: boolean;
	isLeftMenuVisible: boolean;
    spinnerCount: number;
    selectedLanguage: string;
    isPageInitLoaded: false;
    isPageRecurringLoaded: false;

}

export class DNM0100DetailScreen_ScreenBase extends React.PureComponent<IDNM0100DetailScreen_ScreenProps, any> {


    ml=[{"Id":"d5a61d2b-bd60-485f-86e2-661e9ed4e486","Name":"en_US","ShortName":"English","IsDefault":true,"LanguagePhrases":[]},{"Id":"5c95a773-8a32-4746-adb5-5ab1b1d1146c","Name":"FixedValues","ShortName":"FixedValues","LanguagePhrases":[{"Id":168301,"PropertyName":"value","Value":"Ürün"},{"Id":752562,"PropertyName":"value","Value":"Transfer Fişi"},{"Id":496157,"PropertyName":"value","Value":"İşlem Geçmişi"},{"Id":558211,"PropertyName":"value","Value":"Teslim Edildi"},{"Id":876717,"PropertyName":"value","Value":"Depo Sorumlusu · DELIVERED"},{"Id":953078,"PropertyName":"value","Value":"Ürün Times Gaziantep mağazasına teslim edildi."},{"Id":639220,"PropertyName":"value","Value":"11 Ağu 2026 · 15:40"},{"Id":252621,"PropertyName":"value","Value":"Sevkiyat Bekliyor"},{"Id":237859,"PropertyName":"value","Value":"Depo Sorumlusu · DELIVERY_PENDING"},{"Id":312333,"PropertyName":"value","Value":"TRF-2026-000345 numaralı transfer fişine dahil edildi."},{"Id":813386,"PropertyName":"value","Value":"11 Ağu 2026 · 14:55"},{"Id":938347,"PropertyName":"value","Value":"Onaylandı"},{"Id":880635,"PropertyName":"value","Value":"Mağaza Müdürü (MM) · APPROVED"},{"Id":888436,"PropertyName":"value","Value":"11 Ağu 2026 · 14:32"},{"Id":470150,"PropertyName":"value","Value":"Onay Bekliyor"},{"Id":648333,"PropertyName":"value","Value":"Sistem · PENDING"},{"Id":416639,"PropertyName":"value","Value":"Önerilen termin: 12 Ağustos 2026"},{"Id":562604,"PropertyName":"value","Value":"11 Ağu 2026 · 14:15"},{"Id":317000,"PropertyName":"value","Value":"Talep Oluşturuldu"},{"Id":950500,"PropertyName":"value","Value":"Satış Danışmanı (SP) · CREATED"},{"Id":230661,"PropertyName":"value","Value":"11 Ağu 2026 · 13:48"}]}]
    defaultML = "en_US"
    
    screenHash = ""
    


    constructor(props) {
        super(props);


        this.state = {
            isSpinnerVisible: false,
            isPageVisible: false,
            isLeftMenuVisible: false,
            spinnerCount: 0,
            selectedLanguage: "",
            isPageInitLoaded: false,
            isPageRecurringLoaded: false,
            
        }

        this.state.isPageVisible = true;
        
    }

    async componentDidMount() {

        if (KuikaAppManager.isPageInitPrevented()) {
            KuikaAppManager.calculateAndSetBodyHeight("dnm0100detailscreen", "");
            return;
        }
        
        
        ReactSystemFunctions.validateToken()
        this.fillFormInitValues();
        if (true){
            
        }
        
        
        
        KuikaAppManager.calculateAndSetBodyHeight("dnm0100detailscreen", "");

        if (ReactSystemFunctions.getIsMicroApp() === false) {
           window.parentScreen = this;
        }
    }

    componentWillUnmount() {
        
        
        

        if (ReactSystemFunctions.getIsMicroApp() === false) {
           window.parentScreen = null;
        }
    }

    

        
    componentDidUpdate= async (prevProps, prevState) => {
		KuikaAppManager.calculateAndSetBodyHeight("dnm0100detailscreen", ""    );
        if (prevProps?.location?.search !== (this.props as any)?.location?.search) {
			
		}

        

        if (ReactSystemFunctions.getIsMicroApp() === false) {
            for (const key in prevState) {
                if (key.startsWith('NavVisible') && prevState[key] === true && this.state[key] === false) {
                    window.parentScreen = this;
                    break;
                }
            }
        }
	}

    fillFormInitValues() {
        this.props.form?.setFieldsValue({
});

    }

      setPageInitLoaded = (value: boolean) => {
        this.setState({ isPageInitLoaded: value });
      }

      setPageRecurringLoaded = (value: boolean) => {
        this.setState({ isPageRecurringLoaded: value });
      }

      clearFieldValidation = (changedValues: any) => {
        const fieldName = Object.keys(changedValues)[0];
        if (fieldName) {
          this.props.form?.setFields([
            {
              name: fieldName,
              errors: []
            }
          ]);
        }
      };

      




    async callCallbackFunction(diId: number, isFromMaster: boolean = false) {
        let isErrorOccurred = false;

    }


}
