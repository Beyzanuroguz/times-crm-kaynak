import React from "react";
import Axios, { AxiosResponse } from "axios";
import { KuikaAppManager } from "../../shared/utilty/kuika-app-manager";
import { ReactSystemFunctions } from "../../shared/utilty/react-system-functions";
import { KNavigator } from "../../shared/hoc/with-history";
import { KContext } from "../../shared/hoc/with-context";
import { useLocation } from "react-router-dom";
import { FormInstance } from "antd/es/form";
import { Guid } from "guid-typescript";
import Swal from "sweetalert2";
import { KMainFunctions } from "../../shared/utilty/main-functions";
import moment from "moment";
import { IValidationData } from "../../models/dto/validation-data";
import { IStripePayment } from "../../models/dto/stripe-payment";
import { IUserInfoDto } from "../../models/dto/user-info.dto";
import { UserService } from "../../services/user-service";
import { kuikaCoreWasmBridgeService } from "../../services/_singletons";
import _ from "lodash";
import mqtt, { MqttClient } from "mqtt";
import { IMqttResult } from "../../models/dto/mqtt.dto";
import { MasterScreen_ScreenContext } from "../masterscreen/masterscreen-context";

declare let window: any;

export interface IReportInventoryNebim_ScreenProps {
  navigator: KNavigator;
  form: FormInstance<any>;
  googleLogin: any;
  screenInputs: any;
  context: KContext;
  initialValues: any;
  children: any;
}

export interface IReportInventoryNebim_ScreenState {
    isSpinnerVisible: boolean;
    isPageVisible: boolean;
	isLeftMenuVisible: boolean;
    spinnerCount: number;
    selectedLanguage: string;
    isPageInitLoaded: false;
    isPageRecurringLoaded: false;
	Connect: any;
	Connect_dummy: any;
	TM_StoreGetList: any[];
	TM_StoreGetList_dummy: any[];
	IsUstYonetici: any[];
	IsUstYonetici_dummy: any[];
	Kuika_EnvanterRaporu: any[];
	Kuika_EnvanterRaporu_dummy: any[];
	SetValueOf: any;
	SetValueOf_dummy: any;
	ExportExcel: any;
	ExportExcel_dummy: any;
	isComp1683022437Visible: 'visible' | 'hidden';
	isComp2047596013Visible: 'visible' | 'hidden';
	isComp933120042Visible: 'visible' | 'hidden';

}

export class ReportInventoryNebim_ScreenBase extends React.PureComponent<IReportInventoryNebim_ScreenProps, any> {
    static contextType = MasterScreen_ScreenContext;
    declare context: React.ContextType<typeof MasterScreen_ScreenContext>;
	reportinventorynebim_1441536341_value_kuikaTableRef: React.RefObject<any>;
    ml=[{"Id":"d5a61d2b-bd60-485f-86e2-661e9ed4e486","Name":"en_US","ShortName":"English","IsDefault":true,"LanguagePhrases":[]},{"Id":"ad12a540-2ab0-4a71-9f99-51d00116570d","Name":"FixedValues","ShortName":"FixedValues","LanguagePhrases":[{"Id":354658722,"PropertyName":"value","Value":"Nebim Envanter Raporu"},{"Id":1886367881,"PropertyName":"value","Value":"Envanter verilerini mağaza ve ürün kriterlerine göre filtreleyin."},{"Id":1368291981,"PropertyName":"value","Value":"Rapor Filtreleri"},{"Id":1315839238,"PropertyName":"value","Value":"Mağaza"},{"Id":114699,"PropertyName":"placeholder","Value":"Mağaza"},{"Id":1318706920,"PropertyName":"value","Value":"Ürün Grubu"},{"Id":923312,"PropertyName":"placeholder","Value":"Ürün Grubu"},{"Id":982347766,"PropertyName":"value","Value":"Marka"},{"Id":121483,"PropertyName":"placeholder","Value":"Marka"},{"Id":1603875421,"PropertyName":"label","Value":"Temizle"},{"Id":2136600364,"PropertyName":"label","Value":"Filtrele"},{"Id":1200159101,"PropertyName":"value","Value":"Envanter Detayları"},{"Id":1858399784,"PropertyName":"label","Value":"Excel'e Aktar"},{"Id":1441536341,"PropertyName":"nodatafoundmessage","Value":"Satış detayı bulunamadı"},{"Id":627822244,"PropertyName":"title","Value":"Marka"},{"Id":1177730266,"PropertyName":"value","Value":"[datafield:marka]"},{"Id":1179745739,"PropertyName":"title","Value":"Ürün Grubu"},{"Id":1183655991,"PropertyName":"value","Value":"[datafield:urungrubu]"},{"Id":1577533499,"PropertyName":"title","Value":"Ürün Kodu"},{"Id":579008046,"PropertyName":"value","Value":"[datafield:urunkodu]"},{"Id":1468608996,"PropertyName":"title","Value":"Ürün Adı"},{"Id":963832544,"PropertyName":"value","Value":"[datafield:urunadi]"},{"Id":1067773309,"PropertyName":"title","Value":"Seri Numarası"},{"Id":1826120772,"PropertyName":"value","Value":"[datafield:serinumarasi]"},{"Id":743703379,"PropertyName":"title","Value":"RMC Barkod"},{"Id":1815391859,"PropertyName":"value","Value":"[datafield:rmcbarkod]"},{"Id":256989687,"PropertyName":"title","Value":"Alış Tarihi"},{"Id":627991207,"PropertyName":"value","Value":"[datafield:alistarihi]"},{"Id":2091583219,"PropertyName":"title","Value":"Fiyat"},{"Id":983534935,"PropertyName":"value","Value":"[datafield:fiyat]"},{"Id":918862344,"PropertyName":"title","Value":"Miktar"},{"Id":361911339,"PropertyName":"value","Value":"[datafield:miktar]"},{"Id":80042237,"PropertyName":"title","Value":"Ofis Kodu"},{"Id":1268513248,"PropertyName":"value","Value":"[datafield:ofiskodu]"},{"Id":708998887,"PropertyName":"title","Value":"Ofis Adı"},{"Id":121473086,"PropertyName":"value","Value":"[datafield:ofisadi]"},{"Id":869710554,"PropertyName":"title","Value":"Mağaza Kodu"},{"Id":389164462,"PropertyName":"value","Value":"[datafield:magazakodu]"},{"Id":1975533148,"PropertyName":"title","Value":"Mağaza Adı"},{"Id":1617114717,"PropertyName":"value","Value":"[datafield:magazaadi]"},{"Id":1350884668,"PropertyName":"title","Value":"Depo Kodu"},{"Id":1266668751,"PropertyName":"value","Value":"[datafield:depokodu]"},{"Id":134636694,"PropertyName":"title","Value":"Depo Adı"},{"Id":1845485255,"PropertyName":"value","Value":"[datafield:depoadi]"}]}]
    defaultML = "en_US"
    
    screenHash = ""
    

    private _prevMasterPageInitLoaded: boolean = false;
    private _prevMasterPageRecurringLoaded: boolean = false;
    private _prevShouldTriggerPageInit: boolean = false;
    constructor(props) {
        super(props);
		this.reportinventorynebim_1441536341_value_kuikaTableRef = React.createRef();

        this.state = {
            isSpinnerVisible: false,
            isPageVisible: false,
            isLeftMenuVisible: false,
            spinnerCount: 0,
            selectedLanguage: "",
            isPageInitLoaded: false,
            isPageRecurringLoaded: false,
            	        Connect: "",
	        TM_StoreGetList: [],
	        IsUstYonetici: [],
	        Kuika_EnvanterRaporu: [],
	        SetValueOf: "",
	        ExportExcel: "",
	        isComp1683022437Visible: 'hidden',
	        isComp2047596013Visible: 'hidden',
	        isComp933120042Visible: 'hidden',

        }

        this.state.isPageVisible = true;
        
    }

    async componentDidMount() {

        if (KuikaAppManager.isPageInitPrevented()) {
            KuikaAppManager.calculateAndSetBodyHeight("reportinventorynebim", "masterscreen_screen");
            return;
        }
        this.context.registerCallbackFunction(this.callCallbackFunction.bind(this));
        
        ReactSystemFunctions.validateToken()
        this.fillFormInitValues();
        if (false){
            await this.ReportInventoryNebimPageInit();
        } else if (this.context?.isMasterPageInitLoaded) { this._prevMasterPageInitLoaded = true; await this.ReportInventoryNebimPageInit(); }
        
        
        
        KuikaAppManager.calculateAndSetBodyHeight("reportinventorynebim", "masterscreen_screen");

        if (ReactSystemFunctions.getIsMicroApp() === false) {
           window.parentScreen = this;
        }
    }

    componentWillUnmount() {
        
        
        

        if (ReactSystemFunctions.getIsMicroApp() === false) {
           window.parentScreen = null;
        }
    }

    

        
    componentDidUpdate= async (prevProps, prevState) => {
		KuikaAppManager.calculateAndSetBodyHeight("reportinventorynebim", "masterscreen_screen"    );
        if (prevProps?.location?.search !== (this.props as any)?.location?.search) {
			await this.ReportInventoryNebimPageInit();
		}

        		if (this._prevMasterPageInitLoaded !== this.context.isMasterPageInitLoaded && this.context.isMasterPageInitLoaded === true) {this._prevMasterPageInitLoaded = this.context.isMasterPageInitLoaded;await this.ReportInventoryNebimPageInit()}


        if (ReactSystemFunctions.getIsMicroApp() === false) {
            for (const key in prevState) {
                if (key.startsWith('NavVisible') && prevState[key] === true && this.state[key] === false) {
                    window.parentScreen = this;
                    break;
                }
            }
        }
	}

    fillFormInitValues() {
        this.props.form?.setFieldsValue({
});

    }

      setPageInitLoaded = (value: boolean) => {
        this.setState({ isPageInitLoaded: value });
      }

      setPageRecurringLoaded = (value: boolean) => {
        this.setState({ isPageRecurringLoaded: value });
      }

      clearFieldValidation = (changedValues: any) => {
        const fieldName = Object.keys(changedValues)[0];
        if (fieldName) {
          this.props.form?.setFields([
            {
              name: fieldName,
              errors: []
            }
          ]);
        }
      };

      

    ReportInventoryNebimPageInit = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


	if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }

        let localVar = {
			KUserId_2: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.getMyUserId(), "Guid"),
			IsUstYonetici_3: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toBoolean(this, (stateVars.IsUstYonetici !== undefined ? (stateVars.IsUstYonetici?.length > 0 ? stateVars.IsUstYonetici[0].isUstYonetici : null) : (this.state.IsUstYonetici?.length > 0 ? this.state.IsUstYonetici[0].isUstYonetici : null))), "boolean"),
			StoreCodes_3: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "reportinventorynebim_114699_value", "value", "TM_StoreGetList", "storeCode", "storeCode")), "string"),
			Markalar_3: ReactSystemFunctions.convertToTypeByName(null, "string"),
			UrunGruplari_3: ReactSystemFunctions.convertToTypeByName(null, "string")
        }

	KuikaAppManager.showSpinner(this);
	
        if (true) {
        KuikaAppManager.showSpinner(this);
        }
        let result = await KuikaAppManager.ApiRequest(this, "ReportInventoryNebim/ReportInventoryNebimPageInit", localVar)
        if (!KMainFunctions.IsResStatus2XX(result)) return true;

		stateVars.TM_StoreGetList = result?.data.tM_StoreGetList;
		
		formVars.reportinventorynebim_114699_options = stateVars.TM_StoreGetList;
		stateVars.IsUstYonetici = result?.data.isUstYonetici;
		stateVars.Kuika_EnvanterRaporu = result?.data.kuika_EnvanterRaporu;
		
		this.props.form?.setFieldsValue(formVars);
		
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.ReportInventoryNebimPageInit1_();
                  resolve();
                });
          })



        
        KuikaAppManager.hideSpinner(this);
        return isErrorOccurred;
    }
	ReportInventoryNebimPageInit1_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


	if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }

			
			stateVars.dataSource_114699 = stateVars.TM_StoreGetList ?? this.state.TM_StoreGetList;
			stateVars.dataSource_114699 = stateVars.TM_StoreGetList ?? this.state.TM_StoreGetList;
			
			stateVars.dataSource_1441536341 = stateVars.Kuika_EnvanterRaporu ?? this.state.Kuika_EnvanterRaporu;

	this.props.form?.setFieldsValue(formVars);
	this.setState(stateVars);
	KuikaAppManager.hideSpinner(this);

            this.setPageInitLoaded(true);
            return isErrorOccurred;
        }




    ReportInventoryNebimComponent_114699_onChange = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
		KuikaAppManager.increaseServerRequestCount();

        let localVar = {
				IsUstYonetici_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toBoolean(this, (stateVars.IsUstYonetici !== undefined ? (stateVars.IsUstYonetici?.length > 0 ? stateVars.IsUstYonetici[0].isUstYonetici : null) : (this.state.IsUstYonetici?.length > 0 ? this.state.IsUstYonetici[0].isUstYonetici : null))), "boolean"),
				StoreCodes_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "reportinventorynebim_114699_value", "value", "TM_StoreGetList", "storeCode", "storeCode")), "string"),
				Markalar_0: ReactSystemFunctions.convertToTypeByName(null, "string"),
				UrunGruplari_0: ReactSystemFunctions.convertToTypeByName(null, "string")
        }

		KuikaAppManager.showSpinner(this);
		
        if (true) {
        KuikaAppManager.showSpinner(this);
        }
        let result = await KuikaAppManager.ApiRequest(this, "ReportInventoryNebim/ReportInventoryNebimComponent_114699_onChange", localVar)
        if (!KMainFunctions.IsResStatus2XX(result)) return true;

			stateVars.Kuika_EnvanterRaporu = result?.data.kuika_EnvanterRaporu;
			
			this.props.form?.setFieldsValue(formVars);
			
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.ReportInventoryNebimComponent_114699_onChange1_();
                  resolve();
                });
          })



        
        KuikaAppManager.hideSpinner(this);
        return isErrorOccurred;
    }
		ReportInventoryNebimComponent_114699_onChange1_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }

				
				stateVars.dataSource_1441536341 = stateVars.Kuika_EnvanterRaporu ?? this.state.Kuika_EnvanterRaporu;

		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

            
            return isErrorOccurred;
        }




		ReportInventoryNebimComponent_1603875421_onClick = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
KuikaAppManager.showSpinner(this);

				stateVars.SetValueOf = await ReactSystemFunctions.setValueOf(this, ReactSystemFunctions.convertToTypeByName("reportinventorynebim_114699_value", "string"), null, null, false);

		this.props.form?.setFieldsValue(formVars);
		
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.ReportInventoryNebimComponent_1603875421_onClick1_();
                  resolve();
                });
          })

            
            return isErrorOccurred;
        }
    ReportInventoryNebimComponent_1603875421_onClick1_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
		KuikaAppManager.increaseServerRequestCount();

        let localVar = {
				IsUstYonetici_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toBoolean(this, (stateVars.IsUstYonetici !== undefined ? (stateVars.IsUstYonetici?.length > 0 ? stateVars.IsUstYonetici[0].isUstYonetici : null) : (this.state.IsUstYonetici?.length > 0 ? this.state.IsUstYonetici[0].isUstYonetici : null))), "boolean"),
				StoreCodes_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "reportinventorynebim_114699_value", "value", "TM_StoreGetList", "storeCode", "storeCode")), "string"),
				Markalar_0: ReactSystemFunctions.convertToTypeByName(null, "string"),
				UrunGruplari_0: ReactSystemFunctions.convertToTypeByName(null, "string")
        }

		
        if (true) {
        KuikaAppManager.showSpinner(this);
        }
        let result = await KuikaAppManager.ApiRequest(this, "ReportInventoryNebim/ReportInventoryNebimComponent_1603875421_onClick1_", localVar)
        if (!KMainFunctions.IsResStatus2XX(result)) return true;

			stateVars.Kuika_EnvanterRaporu = result?.data.kuika_EnvanterRaporu;
			
			this.props.form?.setFieldsValue(formVars);
			
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.ReportInventoryNebimComponent_1603875421_onClick2_();
                  resolve();
                });
          })



        
        KuikaAppManager.hideSpinner(this);
        return isErrorOccurred;
    }
		ReportInventoryNebimComponent_1603875421_onClick2_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }

				
				stateVars.dataSource_1441536341 = stateVars.Kuika_EnvanterRaporu ?? this.state.Kuika_EnvanterRaporu;

		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

            
            return isErrorOccurred;
        }





    ReportInventoryNebimComponent_2136600364_onClick = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
		KuikaAppManager.increaseServerRequestCount();

        let localVar = {
				IsUstYonetici_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toBoolean(this, (stateVars.IsUstYonetici !== undefined ? (stateVars.IsUstYonetici?.length > 0 ? stateVars.IsUstYonetici[0].isUstYonetici : null) : (this.state.IsUstYonetici?.length > 0 ? this.state.IsUstYonetici[0].isUstYonetici : null))), "boolean"),
				StoreCodes_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "reportinventorynebim_114699_value", "value", "TM_StoreGetList", "storeCode", "storeCode")), "string"),
				Markalar_0: ReactSystemFunctions.convertToTypeByName(null, "string"),
				UrunGruplari_0: ReactSystemFunctions.convertToTypeByName(null, "string")
        }

		KuikaAppManager.showSpinner(this);
		
        if (true) {
        KuikaAppManager.showSpinner(this);
        }
        let result = await KuikaAppManager.ApiRequest(this, "ReportInventoryNebim/ReportInventoryNebimComponent_2136600364_onClick", localVar)
        if (!KMainFunctions.IsResStatus2XX(result)) return true;

			stateVars.Kuika_EnvanterRaporu = result?.data.kuika_EnvanterRaporu;
			
			this.props.form?.setFieldsValue(formVars);
			
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.ReportInventoryNebimComponent_2136600364_onClick1_();
                  resolve();
                });
          })



        
        KuikaAppManager.hideSpinner(this);
        return isErrorOccurred;
    }
		ReportInventoryNebimComponent_2136600364_onClick1_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }

				
				stateVars.dataSource_1441536341 = stateVars.Kuika_EnvanterRaporu ?? this.state.Kuika_EnvanterRaporu;

		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

            
            return isErrorOccurred;
        }




    ReportInventoryNebimComponent_1858399784_onClick = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
		KuikaAppManager.increaseServerRequestCount();

        let localVar = {
				value_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, this.state.Kuika_EnvanterRaporu), "any"),
				header_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.convertToTypeByName("Envanter Raporu", "string"), "string"),
				footer_0: ReactSystemFunctions.convertToTypeByName("", "string"),
				columns_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.convertToTypeByName("OfisAdi,MagazaAdi,DepoAdi,Marka,UrunGrubu,UrunKodu,UrunAdi,SeriNumarasi,RmcBarkod,Miktar,AlisTarihi,AlisParaBirimi,Fiyat,Prim", "string"), "string")
        }

		KuikaAppManager.showSpinner(this);
		
        if (true) {
        KuikaAppManager.showSpinner(this);
        }
        let result = await KuikaAppManager.ApiRequest(this, "ReportInventoryNebim/ReportInventoryNebimComponent_1858399784_onClick", localVar)
        if (!KMainFunctions.IsResStatus2XX(result)) return true;

			stateVars.ExportExcel = result?.data.exportExcel;
			ReactSystemFunctions.downloadFile(result?.data?.exportExcel);
			this.props.form?.setFieldsValue(formVars);
			this.setState(stateVars);
			KuikaAppManager.hideSpinner(this);



        this.setPageInitLoaded(true);
        KuikaAppManager.hideSpinner(this);
        return isErrorOccurred;
    }





    async callCallbackFunction(diId: number, isFromMaster: boolean = false) {
        let isErrorOccurred = false;
		let pageInitCallerNavDiIDs = [] as number[];
		if (isFromMaster || pageInitCallerNavDiIDs.indexOf(diId) > -1) {
			await this.ReportInventoryNebimPageInit();
		}

    }


}
