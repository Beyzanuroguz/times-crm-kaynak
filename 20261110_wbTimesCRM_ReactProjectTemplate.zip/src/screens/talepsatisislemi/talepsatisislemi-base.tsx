import React from "react";
import Axios, { AxiosResponse } from "axios";
import { KuikaAppManager } from "../../shared/utilty/kuika-app-manager";
import { ReactSystemFunctions } from "../../shared/utilty/react-system-functions";
import { KNavigator } from "../../shared/hoc/with-history";
import { KContext } from "../../shared/hoc/with-context";
import { useLocation } from "react-router-dom";
import { FormInstance } from "antd/es/form";
import { Guid } from "guid-typescript";
import Swal from "sweetalert2";
import { KMainFunctions } from "../../shared/utilty/main-functions";
import moment from "moment";
import { IValidationData } from "../../models/dto/validation-data";
import { IStripePayment } from "../../models/dto/stripe-payment";
import { IUserInfoDto } from "../../models/dto/user-info.dto";
import { UserService } from "../../services/user-service";
import { kuikaCoreWasmBridgeService } from "../../services/_singletons";
import _ from "lodash";
import mqtt, { MqttClient } from "mqtt";
import { IMqttResult } from "../../models/dto/mqtt.dto";


declare let window: any;

export interface ITalepSatisIslemi_ScreenProps {
  navigator: KNavigator;
  form: FormInstance<any>;
  googleLogin: any;
  screenInputs: any;
  context: KContext;
  initialValues: any;
  children: any;
}

export interface ITalepSatisIslemi_ScreenState {
    isSpinnerVisible: boolean;
    isPageVisible: boolean;
	isLeftMenuVisible: boolean;
    spinnerCount: number;
    selectedLanguage: string;
    isPageInitLoaded: false;
    isPageRecurringLoaded: false;
	TM_GetLeadById: any[];
	TM_GetLeadById_dummy: any[];
	TM_GetSalesLeadById: any[];
	TM_GetSalesLeadById_dummy: any[];
	TM_GetMergeableSalesLeadsWeb: any[];
	TM_GetMergeableSalesLeadsWeb_dummy: any[];
	TM_GetCustomerById: any[];
	TM_GetCustomerById_dummy: any[];
	TM_StoreGetList: any[];
	TM_StoreGetList_dummy: any[];
	TM_GetCustomerByName: any[];
	TM_GetCustomerByName_dummy: any[];
	TS_GetStoreUsers: any[];
	TS_GetStoreUsers_dummy: any[];
	GetSalesPersonByStore: any[];
	GetSalesPersonByStore_dummy: any[];
	TM_GetSalesExchangesRate: any[];
	TM_GetSalesExchangesRate_dummy: any[];
	TM_CheckCustomerVerificationPopup: any[];
	TM_CheckCustomerVerificationPopup_dummy: any[];
	TM_GetThirdPartyInvoiceLeadDraftForResume: any[];
	TM_GetThirdPartyInvoiceLeadDraftForResume_dummy: any[];
	SetValueOf: any;
	SetValueOf_dummy: any;
	GetSalesLeadProduct: any[];
	GetSalesLeadProduct_dummy: any[];
	TMSalesLeadPaymentList: any[];
	TMSalesLeadPaymentList_dummy: any[];
	TMSalesLeadSummary: any[];
	TMSalesLeadSummary_dummy: any[];
	TM_GetThirdPartyInvoiceCustomerList: any[];
	TM_GetThirdPartyInvoiceCustomerList_dummy: any[];
	NAVIGATE: any;
	NAVIGATE_dummy: any;
	TM_GetCountry: any[];
	TM_GetCountry_dummy: any[];
	TM_GetCitySql: any[];
	TM_GetCitySql_dummy: any[];
	TM_GetDistrict: any[];
	TM_GetDistrict_dummy: any[];
	TMSalesLeadDraftCreate: any[];
	TMSalesLeadDraftCreate_dummy: any[];
	TM_SaveSalesDraftLeadSelectionWeb: any[];
	TM_SaveSalesDraftLeadSelectionWeb_dummy: any[];
	TM_CreateThirdPartyInvoiceLeadApprovalDraft: any[];
	TM_CreateThirdPartyInvoiceLeadApprovalDraft_dummy: any[];
	Notify: boolean;
	Notify_dummy: boolean;
	ChangeEnabledOf: any;
	ChangeEnabledOf_dummy: any;
	ChangeVisibilityOf: string;
	ChangeVisibilityOf_dummy: string;
	Connect: any;
	Connect_dummy: any;
	Kuika_ItemInfoLive: any[];
	Kuika_ItemInfoLive_dummy: any[];
	TMSalesLeadDraftAddProduct: any[];
	TMSalesLeadDraftAddProduct_dummy: any[];
	TMSalesLeadAddProductDistinctWatch: any[];
	TMSalesLeadAddProductDistinctWatch_dummy: any[];
	TMIskontoAdd: any[];
	TMIskontoAdd_dummy: any[];
	TMSalesLeadProductDelete: any[];
	TMSalesLeadProductDelete_dummy: any[];
	TMSalesPaymentType: any[];
	TMSalesPaymentType_dummy: any[];
	TMAddSalesLeadPayment: any[];
	TMAddSalesLeadPayment_dummy: any[];
	TMSalesLeadUpdatePayment: any[];
	TMSalesLeadUpdatePayment_dummy: any[];
	TMSalesLeadPaymentCompletedLine: any[];
	TMSalesLeadPaymentCompletedLine_dummy: any[];
	TMSalesLeadPaymentDeleted: any[];
	TMSalesLeadPaymentDeleted_dummy: any[];
	TM_SubmitThirdPartyInvoiceLeadApproval: any[];
	TM_SubmitThirdPartyInvoiceLeadApproval_dummy: any[];
	TM_GetSalesDraftForPost: any[];
	TM_GetSalesDraftForPost_dummy: any[];
	TM_GetSalesDraftDetailForPost: any[];
	TM_GetSalesDraftDetailForPost_dummy: any[];
	TM_GetSalesDraftPaymentForPost: any[];
	TM_GetSalesDraftPaymentForPost_dummy: any[];
	Send: any;
	Send_dummy: any;
	SendMail: any;
	SendMail_dummy: any;
	isComp347901Visible: 'visible' | 'hidden';
	isComp731364Visible: 'visible' | 'hidden';
	isComp761489Visible: 'visible' | 'hidden';
	isComp832389Visible: 'visible' | 'hidden';
	isComp170159Visible: 'visible' | 'hidden';
	isComp1499380460Visible: 'visible' | 'hidden';
	isComp287429939Visible: 'visible' | 'hidden';
	isComp234425777Visible: 'visible' | 'hidden';
	isComp1371997784Visible: 'visible' | 'hidden';
	isComp1649913896Visible: 'visible' | 'hidden';
	isComp1720847430Visible: 'visible' | 'hidden';
	isComp61094802Visible: 'visible' | 'hidden';
	isComp1289654211Visible: 'visible' | 'hidden';
	isComp487685649Visible: 'visible' | 'hidden';
	isComp842760Visible: 'visible' | 'hidden';
	isComp890073Visible: 'visible' | 'hidden';
	isComp540835Visible: 'visible' | 'hidden';
	isComp625854Visible: 'visible' | 'hidden';
	isComp203199Visible: 'visible' | 'hidden';
	isComp759176Visible: 'visible' | 'hidden';
	isComp281463Visible: 'visible' | 'hidden';
	isComp194593Visible: 'visible' | 'hidden';
	isComp496031Visible: 'visible' | 'hidden';
	isComp337380Visible: 'visible' | 'hidden';
	isComp832389Enabled: 'enabled' | 'disabled';
	isComp684346Enabled: 'enabled' | 'disabled';
	isComp1417478211Enabled: 'enabled' | 'disabled';
	isComp863666Enabled: 'enabled' | 'disabled';
	isComp1894128536Enabled: 'enabled' | 'disabled';
	isComp761489Enabled: 'enabled' | 'disabled';

}

export class TalepSatisIslemi_ScreenBase extends React.PureComponent<ITalepSatisIslemi_ScreenProps, any> {

	talepsatisislemi_516749_value_kuikaSelectBoxRef: React.RefObject<any>;
	talepsatisislemi_403854_value_kuikaDateRef: React.RefObject<any>;
	talepsatisislemi_141674_value_kuikaDateRef: React.RefObject<any>;
	talepsatisislemi_1342936662_value_kuikaSelectBoxRef: React.RefObject<any>;
	talepsatisislemi_227383778_value_kuikaAutoCompleteRef: React.RefObject<any>;
	talepsatisislemi_1685705311_value_kuikaSelectBoxRef: React.RefObject<any>;
	talepsatisislemi_761478296_value_kuikaAutoCompleteRef: React.RefObject<any>;
	talepsatisislemi_1161020887_value_kuikaAutoCompleteRef: React.RefObject<any>;
	talepsatisislemi_852869243_value_kuikaAutoCompleteRef: React.RefObject<any>;
	talepsatisislemi_41607_value_kuikaTableRef: React.RefObject<any>;
	talepsatisislemi_987644_value_kuikaFlexGridRef: React.RefObject<any>;
	talepsatisislemi_831595_value_kuikaSelectBoxRef: React.RefObject<any>;
	talepsatisislemi_859085_value_kuikaSelectBoxRef: React.RefObject<any>;
	talepsatisislemi_682853634_value_kuikaAutoCompleteRef: React.RefObject<any>;
	talepsatisislemi_466892_value_kuikaTableRef: React.RefObject<any>;
    ml=[{"Id":"d5a61d2b-bd60-485f-86e2-661e9ed4e486","Name":"en_US","ShortName":"English","IsDefault":true,"LanguagePhrases":[]},{"Id":"f7dd8554-13e6-473c-8599-1f5d3594bafe","Name":"FixedValues","ShortName":"FixedValues","LanguagePhrases":[{"Id":181309,"PropertyName":"value","Value":"Talep Satış İşlemi"},{"Id":213232,"PropertyName":"value","Value":"Müşteri Adı"},{"Id":601609,"PropertyName":"value","Value":"Müşteri Telefon Numarası"},{"Id":871576,"PropertyName":"value","Value":"Ürün Adı"},{"Id":117604,"PropertyName":"value","Value":"Lead Numarası"},{"Id":790988,"PropertyName":"value","Value":"Lead Durumu"},{"Id":170706,"PropertyName":"value","Value":"Lead Termin Tarihi"},{"Id":145071,"PropertyName":"value","Value":"1. Fatura Bilgisi"},{"Id":333111,"PropertyName":"value","Value":"Fatura tipi seçilmeden ürün ekleme alanı kullanılamaz."},{"Id":516749,"PropertyName":"placeholder","Value":"Fatura tipi seçiniz"},{"Id":708806,"PropertyName":"placeholder","Value":"Oturum İzni Numarası"},{"Id":403854,"PropertyName":"placeholder","Value":"Oturum Başlangıç Tarihi"},{"Id":141674,"PropertyName":"placeholder","Value":"Oturum Bitiş Tarihi"},{"Id":1790998325,"PropertyName":"label","Value":"Birden Fazla Lead Faturalandıracağım"},{"Id":694044,"PropertyName":"placeholder","Value":"Uygun leadleri seçin"},{"Id":1299000195,"PropertyName":"label","Value":"3. Kişiye Faturalandıracağım"},{"Id":921394308,"PropertyName":"value","Value":"3. Kişi Bilgi Kaynağı"},{"Id":1342936662,"PropertyName":"placeholder","Value":"3. Kişi bilgi kaynağı"},{"Id":1436383101,"PropertyName":"value","Value":"Fatura Kesilecek Müşteri"},{"Id":227383778,"PropertyName":"placeholder","Value":"Müşteri seçiniz"},{"Id":378444328,"PropertyName":"value","Value":"Fatura Alıcısı Tipi"},{"Id":1685705311,"PropertyName":"placeholder","Value":"Fatura alıcısı tipi"},{"Id":1057534804,"PropertyName":"value","Value":"Ad"},{"Id":1617736699,"PropertyName":"placeholder","Value":"Ad"},{"Id":906763487,"PropertyName":"value","Value":"Soyad"},{"Id":508462469,"PropertyName":"placeholder","Value":"Soyad"},{"Id":1654660376,"PropertyName":"value","Value":"T.C. /Kimlik No"},{"Id":2079690263,"PropertyName":"placeholder","Value":"TC"},{"Id":50039868,"PropertyName":"value","Value":"Şirket/Unvan"},{"Id":1359451170,"PropertyName":"placeholder","Value":"Şirket / Unvan"},{"Id":302936329,"PropertyName":"value","Value":"Vergi Numarası"},{"Id":1670324057,"PropertyName":"placeholder","Value":"Vergi Numarası"},{"Id":36958369,"PropertyName":"value","Value":"Vergi Dairesi Kodu"},{"Id":668385102,"PropertyName":"placeholder","Value":"Vergi Dairesi Kodu"},{"Id":1485607704,"PropertyName":"value","Value":"Ülke*"},{"Id":761478296,"PropertyName":"placeholder","Value":"Ülke"},{"Id":887916472,"PropertyName":"value","Value":"İl*"},{"Id":1161020887,"PropertyName":"placeholder","Value":"İl"},{"Id":2021221569,"PropertyName":"value","Value":"İlçe*"},{"Id":852869243,"PropertyName":"placeholder","Value":"İlçe"},{"Id":1253960145,"PropertyName":"value","Value":"Adres"},{"Id":1475165764,"PropertyName":"placeholder","Value":"Adres"},{"Id":555308,"PropertyName":"label","Value":"Devam Et"},{"Id":372930,"PropertyName":"value","Value":"2. Ürün Ekle"},{"Id":520024,"PropertyName":"value","Value":"Lead üzerindeki ürünü ekleyiniz ayrıca saat dışında harici ürün de ekleyebilirsiniz."},{"Id":807578,"PropertyName":"value","Value":"Harici Ürün Ekle"},{"Id":878977,"PropertyName":"placeholder","Value":"Barkod veya seri numarası giriniz"},{"Id":10440,"PropertyName":"label","Value":"Ürün Ekle"},{"Id":660424,"PropertyName":"placeholder","Value":"Ek ürün barkod veya seri numarası giriniz"},{"Id":356498,"PropertyName":"label","Value":"Ek Ürün Ekle"},{"Id":587452,"PropertyName":"value","Value":"Lütfen fatura tipini seçiniz."},{"Id":998194,"PropertyName":"value","Value":"Ürün barkod / seri numarası giriniz."},{"Id":58289,"PropertyName":"value","Value":"Bu ürün zaten sepete eklenmiş."},{"Id":602536,"PropertyName":"value","Value":"Ürün bulunamadı."},{"Id":428899,"PropertyName":"title","Value":"Seri No"},{"Id":625854,"PropertyName":"value","Value":"[datafield:serino]"},{"Id":203199,"PropertyName":"value","Value":"[datafield:barcode]"},{"Id":257771,"PropertyName":"title","Value":"Product Name"},{"Id":465866,"PropertyName":"value","Value":"[datafield:productname]"},{"Id":623815,"PropertyName":"title","Value":"Fiyat"},{"Id":714962,"PropertyName":"value","Value":"[datafield:unitpriceeur]"},{"Id":58451,"PropertyName":"title","Value":"İskonto Oranı"},{"Id":161776,"PropertyName":"value","Value":"[datafield:discountrate]"},{"Id":863666,"PropertyName":"placeholder","Value":"15"},{"Id":794306,"PropertyName":"title","Value":"İndirim Tutarı"},{"Id":700671,"PropertyName":"value","Value":"[datafield:discountamount]"},{"Id":101174,"PropertyName":"title","Value":"Toplam Tutar"},{"Id":409435,"PropertyName":"value","Value":"[datafield:linetotaleur]"},{"Id":244475,"PropertyName":"value","Value":"3. Tahsilat Ekle"},{"Id":352042,"PropertyName":"value","Value":"Tek veya parçalı tahsilat girişine uygundur."},{"Id":987644,"PropertyName":"nodatafoundmessage","Value":"No data found."},{"Id":789376,"PropertyName":"value","Value":"[datafield:currencycode]"},{"Id":728526,"PropertyName":"value","Value":"[datafield:rate]"},{"Id":831595,"PropertyName":"placeholder","Value":"Tahsilat Tipi"},{"Id":859085,"PropertyName":"placeholder","Value":"Tahsilat Bilgisi"},{"Id":682853634,"PropertyName":"placeholder","Value":"Döviz"},{"Id":358141,"PropertyName":"label","Value":"Tahsilat Ekle"},{"Id":942888,"PropertyName":"value","Value":"Tahsilat tutarı 0’dan büyük olmalıdır."},{"Id":826143,"PropertyName":"value","Value":"Tahsilat tutarı kalan tutarı aşamaz."},{"Id":53189,"PropertyName":"value","Value":"Satışı tamamlamak için kalan tutar 0 olmalıdır."},{"Id":647637,"PropertyName":"title","Value":"Tip"},{"Id":370523,"PropertyName":"value","Value":"[datafield:tipadi]"},{"Id":270805,"PropertyName":"title","Value":"Döviz"},{"Id":780309,"PropertyName":"value","Value":"[datafield:doviz]"},{"Id":1566119835,"PropertyName":"title","Value":"Bilgi"},{"Id":753169594,"PropertyName":"value","Value":"[datafield:curraccdescription]"},{"Id":766295,"PropertyName":"title","Value":"Tutar"},{"Id":455308,"PropertyName":"value","Value":"[datafield:tutar]"},{"Id":343657,"PropertyName":"placeholder","Value":"15"},{"Id":607353,"PropertyName":"title","Value":"EUR Karşılığı"},{"Id":522369,"PropertyName":"value","Value":"[datafield:eurkarsiligi]"},{"Id":219734,"PropertyName":"value","Value":"Tahsil Edilen:"},{"Id":291992,"PropertyName":"value","Value":"Kalan:"},{"Id":413915,"PropertyName":"value","Value":"Sepet Özeti"},{"Id":978568,"PropertyName":"value","Value":"Satış onayı için gerekli toplamlar sağ alanda sürekli görünür kalır."},{"Id":735430,"PropertyName":"value","Value":"Ürün Adedi"},{"Id":752532,"PropertyName":"value","Value":"Ara Toplam"},{"Id":515479,"PropertyName":"value","Value":"Toplam İndirim"},{"Id":944039,"PropertyName":"value","Value":"Genel Toplam"},{"Id":834307,"PropertyName":"value","Value":"Tahsil Edilen"},{"Id":748548,"PropertyName":"value","Value":"Kalan Tutar"},{"Id":1894128536,"PropertyName":"label","Value":"Tutarı Kontrol Et"},{"Id":761489,"PropertyName":"label","Value":"Satışı Onayla"},{"Id":167957,"PropertyName":"value","Value":"Satışı tamamlamak için fatura tipi seçilmeli, ürün eklenmeli ve kalan tutar sıfırlanmalıdır."},{"Id":337380,"PropertyName":"placeholder","Value":"Type here..."}]}]
    defaultML = "en_US"
    
    screenHash = ""
    


    constructor(props) {
        super(props);
		this.talepsatisislemi_516749_value_kuikaSelectBoxRef = React.createRef();
		this.talepsatisislemi_708806_value_kuikaTextInputRef = React.createRef();
		this.talepsatisislemi_403854_value_kuikaDateRef = React.createRef();
		this.talepsatisislemi_141674_value_kuikaDateRef = React.createRef();
		this.talepsatisislemi_1342936662_value_kuikaSelectBoxRef = React.createRef();
		this.talepsatisislemi_227383778_value_kuikaAutoCompleteRef = React.createRef();
		this.talepsatisislemi_1685705311_value_kuikaSelectBoxRef = React.createRef();
		this.talepsatisislemi_1617736699_value_kuikaTextInputRef = React.createRef();
		this.talepsatisislemi_508462469_value_kuikaTextInputRef = React.createRef();
		this.talepsatisislemi_2079690263_value_kuikaTextInputRef = React.createRef();
		this.talepsatisislemi_1359451170_value_kuikaTextInputRef = React.createRef();
		this.talepsatisislemi_1670324057_value_kuikaTextInputRef = React.createRef();
		this.talepsatisislemi_668385102_value_kuikaTextInputRef = React.createRef();
		this.talepsatisislemi_761478296_value_kuikaAutoCompleteRef = React.createRef();
		this.talepsatisislemi_1161020887_value_kuikaAutoCompleteRef = React.createRef();
		this.talepsatisislemi_852869243_value_kuikaAutoCompleteRef = React.createRef();
		this.talepsatisislemi_878977_value_kuikaTextInputRef = React.createRef();
		this.talepsatisislemi_660424_value_kuikaTextInputRef = React.createRef();
		this.talepsatisislemi_41607_value_kuikaTableRef = React.createRef();
		this.talepsatisislemi_987644_value_kuikaFlexGridRef = React.createRef();
		this.talepsatisislemi_831595_value_kuikaSelectBoxRef = React.createRef();
		this.talepsatisislemi_859085_value_kuikaSelectBoxRef = React.createRef();
		this.talepsatisislemi_682853634_value_kuikaAutoCompleteRef = React.createRef();
		this.talepsatisislemi_466892_value_kuikaTableRef = React.createRef();
		this.talepsatisislemi_337380_value_kuikaTextInputRef = React.createRef();

        this.state = {
            isSpinnerVisible: false,
            isPageVisible: false,
            isLeftMenuVisible: false,
            spinnerCount: 0,
            selectedLanguage: "",
            isPageInitLoaded: false,
            isPageRecurringLoaded: false,
            	        TM_GetLeadById: [],
	        TM_GetSalesLeadById: [],
	        TM_GetMergeableSalesLeadsWeb: [],
	        TM_GetCustomerById: [],
	        TM_StoreGetList: [],
	        TM_GetCustomerByName: [],
	        TS_GetStoreUsers: [],
	        GetSalesPersonByStore: [],
	        TM_GetSalesExchangesRate: [],
	        TM_CheckCustomerVerificationPopup: [],
	        TM_GetThirdPartyInvoiceLeadDraftForResume: [],
	        SetValueOf: "",
	        GetSalesLeadProduct: [],
	        TMSalesLeadPaymentList: [],
	        TMSalesLeadSummary: [],
	        TM_GetThirdPartyInvoiceCustomerList: [],
	        NAVIGATE: "",
	        TM_GetCountry: [],
	        TM_GetCitySql: [],
	        TM_GetDistrict: [],
	        TMSalesLeadDraftCreate: [],
	        TM_SaveSalesDraftLeadSelectionWeb: [],
	        TM_CreateThirdPartyInvoiceLeadApprovalDraft: [],
	        Notify: false,
	        ChangeEnabledOf: "",
	        ChangeVisibilityOf: "",
	        Connect: "",
	        Kuika_ItemInfoLive: [],
	        TMSalesLeadDraftAddProduct: [],
	        TMSalesLeadAddProductDistinctWatch: [],
	        TMIskontoAdd: [],
	        TMSalesLeadProductDelete: [],
	        TMSalesPaymentType: [],
	        TMAddSalesLeadPayment: [],
	        TMSalesLeadUpdatePayment: [],
	        TMSalesLeadPaymentCompletedLine: [],
	        TMSalesLeadPaymentDeleted: [],
	        TM_SubmitThirdPartyInvoiceLeadApproval: [],
	        TM_GetSalesDraftForPost: [],
	        TM_GetSalesDraftDetailForPost: [],
	        TM_GetSalesDraftPaymentForPost: [],
	        Send: "",
	        SendMail: "",
	        dataSource_516749: [{"key":"1","text":"Standart Fatura"},{"key":"2","text":"Tax Free Fatura"}],
	        dataSource_1342936662: [{"key":"CUSTOMER","text":"Müşteri listesinden seç"},{"key":"MANUAL","text":"Müşteri kartı oluşturmadan manuel gir"}],
	        dataSource_1685705311: [{"key":"PERSON","text":"Gerçek Kişi"},{"key":"COMPANY","text":"Tüzel Firma"}],
	        dataSource_831595: [{"key":"1","text":"Nakit"},{"key":"2","text":"Kredi Kartı"},{"key":"4","text":"Banka"}],
	        dataSource_682853634: [{"key":"TRY","text":"TRY"},{"key":"EUR","text":"EUR"},{"key":"USD","text":"USD"},{"key":"GBP","text":"GBP"},{"key":"CHF","text":"CHF"}],
	        isComp347901Visible: 'hidden',
	        isComp731364Visible: 'visible',
	        isComp761489Visible: 'hidden',
	        isComp832389Visible: 'hidden',
	        isComp170159Visible: 'hidden',
	        isComp1499380460Visible: 'hidden',
	        isComp287429939Visible: 'hidden',
	        isComp234425777Visible: 'hidden',
	        isComp1371997784Visible: 'hidden',
	        isComp1649913896Visible: 'hidden',
	        isComp1720847430Visible: 'hidden',
	        isComp61094802Visible: 'hidden',
	        isComp1289654211Visible: 'hidden',
	        isComp487685649Visible: 'hidden',
	        isComp842760Visible: 'hidden',
	        isComp890073Visible: 'hidden',
	        isComp540835Visible: 'hidden',
	        isComp625854Visible: 'hidden',
	        isComp203199Visible: 'hidden',
	        isComp759176Visible: 'hidden',
	        isComp281463Visible: 'hidden',
	        isComp194593Visible: 'hidden',
	        isComp496031Visible: 'hidden',
	        isComp337380Visible: 'hidden',
	        isComp832389Enabled: 'enabled',
	        isComp684346Enabled: 'disabled',
	        isComp1417478211Enabled: 'disabled',
	        isComp863666Enabled: 'disabled',
	        isComp1894128536Enabled: 'disabled',
	        isComp761489Enabled: 'disabled',

        }

        this.state.isPageVisible = true;
        
    }

    async componentDidMount() {

        if (KuikaAppManager.isPageInitPrevented()) {
            KuikaAppManager.calculateAndSetBodyHeight("talepsatisislemi", "");
            return;
        }
        
        
        ReactSystemFunctions.validateToken()
        this.fillFormInitValues();
        if (true){
            await this.TalepSatisIslemiPageInit();
        }
        
        
        
        KuikaAppManager.calculateAndSetBodyHeight("talepsatisislemi", "");

        if (ReactSystemFunctions.getIsMicroApp() === false) {
           window.parentScreen = this;
        }
    }

    componentWillUnmount() {
        
        
        

        if (ReactSystemFunctions.getIsMicroApp() === false) {
           window.parentScreen = null;
        }
    }

    

        
    componentDidUpdate= async (prevProps, prevState) => {
		KuikaAppManager.calculateAndSetBodyHeight("talepsatisislemi", ""    );
        if (prevProps?.location?.search !== (this.props as any)?.location?.search) {
			await this.TalepSatisIslemiPageInit();
		}

        

        if (ReactSystemFunctions.getIsMicroApp() === false) {
            for (const key in prevState) {
                if (key.startsWith('NavVisible') && prevState[key] === true && this.state[key] === false) {
                    window.parentScreen = this;
                    break;
                }
            }
        }
	}

    fillFormInitValues() {
        this.props.form?.setFieldsValue({
talepsatisislemi_1790998325_checked: false,
talepsatisislemi_1299000195_checked: false,
talepsatisislemi_373821_value: false
});

    }

      setPageInitLoaded = (value: boolean) => {
        this.setState({ isPageInitLoaded: value });
      }

      setPageRecurringLoaded = (value: boolean) => {
        this.setState({ isPageRecurringLoaded: value });
      }

      clearFieldValidation = (changedValues: any) => {
        const fieldName = Object.keys(changedValues)[0];
        if (fieldName) {
          this.props.form?.setFields([
            {
              name: fieldName,
              errors: []
            }
          ]);
        }
      };

      

    TalepSatisIslemiPageInit = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


	if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }

        let localVar = {
			LeadId_0: ReactSystemFunctions.convertToTypeByName(this.props.screenInputs.LeadId ?? this.props.screenInputs.leadid, "Guid"),
			LeadId_1: ReactSystemFunctions.convertToTypeByName(this.props.screenInputs.LeadId ?? this.props.screenInputs.leadid, "Guid"),
			LeadId_2: ReactSystemFunctions.convertToTypeByName(this.props.screenInputs.LeadId ?? this.props.screenInputs.leadid, "Guid"),
			CustomerId_3: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, (stateVars.TM_GetSalesLeadById !== undefined ? (stateVars.TM_GetSalesLeadById?.length > 0 ? stateVars.TM_GetSalesLeadById[0].customerId : null) : (this.state.TM_GetSalesLeadById?.length > 0 ? this.state.TM_GetSalesLeadById[0].customerId : null))), "Guid"),
			KUserId_6: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.getMyUserId(), "Guid"),
			StoreId_7: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, (stateVars.TS_GetStoreUsers !== undefined ? (stateVars.TS_GetStoreUsers?.length > 0 ? stateVars.TS_GetStoreUsers[0].storeID : null) : (this.state.TS_GetStoreUsers?.length > 0 ? this.state.TS_GetStoreUsers[0].storeID : null))), "Guid"),
			CustomerId_9: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, (stateVars.TM_GetLeadById !== undefined ? (stateVars.TM_GetLeadById?.length > 0 ? stateVars.TM_GetLeadById[0].customerId : null) : (this.state.TM_GetLeadById?.length > 0 ? this.state.TM_GetLeadById[0].customerId : null))), "Guid")
        }

	KuikaAppManager.showSpinner(this);
	
        if (true) {
        KuikaAppManager.showSpinner(this);
        }
        let result = await KuikaAppManager.ApiRequest(this, "TalepSatisIslemi/TalepSatisIslemiPageInit", localVar)
        if (!KMainFunctions.IsResStatus2XX(result)) return true;

		stateVars.TM_GetLeadById = result?.data.tM_GetLeadById;
		formVars.talepsatisislemi_227199_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadById !== undefined ? (stateVars.TM_GetLeadById?.length > 0 ? stateVars.TM_GetLeadById[0].musteriAdi : null) : (this.state.TM_GetLeadById?.length > 0 ? this.state.TM_GetLeadById[0].musteriAdi : null)));
		formVars.talepsatisislemi_867471_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadById !== undefined ? (stateVars.TM_GetLeadById?.length > 0 ? stateVars.TM_GetLeadById[0].telefonNo : null) : (this.state.TM_GetLeadById?.length > 0 ? this.state.TM_GetLeadById[0].telefonNo : null)));
		formVars.talepsatisislemi_776728_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadById !== undefined ? (stateVars.TM_GetLeadById?.length > 0 ? stateVars.TM_GetLeadById[0].urunAdi : null) : (this.state.TM_GetLeadById?.length > 0 ? this.state.TM_GetLeadById[0].urunAdi : null)));
		formVars.talepsatisislemi_430401_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadById !== undefined ? (stateVars.TM_GetLeadById?.length > 0 ? stateVars.TM_GetLeadById[0].leadCode : null) : (this.state.TM_GetLeadById?.length > 0 ? this.state.TM_GetLeadById[0].leadCode : null)));
		formVars.talepsatisislemi_170676_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadById !== undefined ? (stateVars.TM_GetLeadById?.length > 0 ? stateVars.TM_GetLeadById[0].processName : null) : (this.state.TM_GetLeadById?.length > 0 ? this.state.TM_GetLeadById[0].processName : null)));
		formVars.talepsatisislemi_850125_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadById !== undefined ? (stateVars.TM_GetLeadById?.length > 0 ? stateVars.TM_GetLeadById[0].terminTarihi : null) : (this.state.TM_GetLeadById?.length > 0 ? this.state.TM_GetLeadById[0].terminTarihi : null)));
		stateVars.TM_GetSalesLeadById = result?.data.tM_GetSalesLeadById;
		stateVars.TM_GetMergeableSalesLeadsWeb = result?.data.tM_GetMergeableSalesLeadsWeb;
		
		formVars.talepsatisislemi_694044_options = stateVars.TM_GetMergeableSalesLeadsWeb;
		stateVars.TM_GetCustomerById = result?.data.tM_GetCustomerById;
		stateVars.TM_StoreGetList = result?.data.tM_StoreGetList;
		stateVars.TM_GetCustomerByName = result?.data.tM_GetCustomerByName;
		stateVars.TS_GetStoreUsers = result?.data.tS_GetStoreUsers;
		stateVars.GetSalesPersonByStore = result?.data.getSalesPersonByStore;
		stateVars.TM_GetSalesExchangesRate = result?.data.tM_GetSalesExchangesRate;
		
		stateVars.TM_CheckCustomerVerificationPopup = result?.data.tM_CheckCustomerVerificationPopup;
		this.props.form?.setFieldsValue(formVars);
		
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.TalepSatisIslemiPageInit1_();
                  resolve();
                });
          })



        
        KuikaAppManager.hideSpinner(this);
        return isErrorOccurred;
    }
    TalepSatisIslemiPageInit1_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


	if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }

        let localVar = {
			CurrentUserId_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.getMyUserId(), "Guid"),
			LeadId_0: ReactSystemFunctions.convertToTypeByName(this.props.screenInputs.LeadId ?? this.props.screenInputs.leadid, "Guid"),
			ApprovalId_0: ReactSystemFunctions.convertToTypeByName(this.props.screenInputs.ApprovalId ?? this.props.screenInputs.approvalid, "Guid"),
			SalesLeadDraftId_0: ReactSystemFunctions.convertToTypeByName(this.props.screenInputs.SalesLeadDraftId ?? this.props.screenInputs.salesleaddraftid, "Guid")
        }

if (ReactSystemFunctions.isNotEmpty(this.props.screenInputs.SalesLeadDraftId ?? this.props.screenInputs.salesleaddraftid, ReactSystemFunctions.convertToTypeByName("True", "string"))) {
            	
        if (true) {
        KuikaAppManager.showSpinner(this);
        }
        let result = await KuikaAppManager.ApiRequest(this, "TalepSatisIslemi/TalepSatisIslemiPageInit1_", localVar)
        if (!KMainFunctions.IsResStatus2XX(result)) return true;

		stateVars.TM_GetThirdPartyInvoiceLeadDraftForResume = result?.data.tM_GetThirdPartyInvoiceLeadDraftForResume;
		this.props.form?.setFieldsValue(formVars);
		
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.TalepSatisIslemiPageInit2_();
                  resolve();
                });
          })

        } else {
            
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.TalepSatisIslemiPageInit2_();
                  resolve();
                });
          })
        }


        
        KuikaAppManager.hideSpinner(this);
        return isErrorOccurred;
    }
	TalepSatisIslemiPageInit2_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


	if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
if (ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, (stateVars.TM_GetThirdPartyInvoiceLeadDraftForResume !== undefined ? (stateVars.TM_GetThirdPartyInvoiceLeadDraftForResume?.length > 0 ? stateVars.TM_GetThirdPartyInvoiceLeadDraftForResume[0].canOpen : null) : (this.state.TM_GetThirdPartyInvoiceLeadDraftForResume?.length > 0 ? this.state.TM_GetThirdPartyInvoiceLeadDraftForResume[0].canOpen : null))), true)) {
            
			stateVars.SetValueOf = await ReactSystemFunctions.setValueOf(this, ReactSystemFunctions.convertToTypeByName("talepsatisislemi_337380_value", "string"), ReactSystemFunctions.toString(this, (stateVars.TM_GetThirdPartyInvoiceLeadDraftForResume !== undefined ? (stateVars.TM_GetThirdPartyInvoiceLeadDraftForResume?.length > 0 ? stateVars.TM_GetThirdPartyInvoiceLeadDraftForResume[0].salesLeadDraftId : null) : (this.state.TM_GetThirdPartyInvoiceLeadDraftForResume?.length > 0 ? this.state.TM_GetThirdPartyInvoiceLeadDraftForResume[0].salesLeadDraftId : null))), null, false);

	this.props.form?.setFieldsValue(formVars);
	
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.TalepSatisIslemiPageInit3_();
                  resolve();
                });
          })

        } else {
            
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.TalepSatisIslemiPageInit3_();
                  resolve();
                });
          })
        }

            
            return isErrorOccurred;
        }
    TalepSatisIslemiPageInit3_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


	if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }

        let localVar = {
			SalesDraftId_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toGuid(this, ReactSystemFunctions.value(this, "talepsatisislemi_337380_value", "value", "", "", "")), "Guid")
        }

if (ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, (stateVars.TM_GetThirdPartyInvoiceLeadDraftForResume !== undefined ? (stateVars.TM_GetThirdPartyInvoiceLeadDraftForResume?.length > 0 ? stateVars.TM_GetThirdPartyInvoiceLeadDraftForResume[0].canOpen : null) : (this.state.TM_GetThirdPartyInvoiceLeadDraftForResume?.length > 0 ? this.state.TM_GetThirdPartyInvoiceLeadDraftForResume[0].canOpen : null))), ReactSystemFunctions.convertToTypeByName("True", "string"))) {
            	
        if (true) {
        KuikaAppManager.showSpinner(this);
        }
        let result = await KuikaAppManager.ApiRequest(this, "TalepSatisIslemi/TalepSatisIslemiPageInit3_", localVar)
        if (!KMainFunctions.IsResStatus2XX(result)) return true;

		stateVars.GetSalesLeadProduct = result?.data.getSalesLeadProduct;
		
		stateVars.isComp759176Visible = ((ReactSystemFunctions.isNotEmpty(ReactSystemFunctions.value(this, (stateVars.GetSalesLeadProduct !== undefined ? (stateVars.GetSalesLeadProduct?.length > 0 ? stateVars.GetSalesLeadProduct[0].id : null) : (this.state.GetSalesLeadProduct?.length > 0 ? this.state.GetSalesLeadProduct[0].id : null))), ReactSystemFunctions.convertToTypeByName("True", "string"))) === true ? "visible" : "hidden")
		this.props.form?.setFieldsValue(formVars);
		
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.TalepSatisIslemiPageInit4_();
                  resolve();
                });
          })

        } else {
            
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.TalepSatisIslemiPageInit4_();
                  resolve();
                });
          })
        }


        
        KuikaAppManager.hideSpinner(this);
        return isErrorOccurred;
    }
    TalepSatisIslemiPageInit4_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


	if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }

        let localVar = {
			SalesDraftId_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toGuid(this, ReactSystemFunctions.value(this, "talepsatisislemi_337380_value", "value", "", "", "")), "Guid")
        }

if (ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, (stateVars.TM_GetThirdPartyInvoiceLeadDraftForResume !== undefined ? (stateVars.TM_GetThirdPartyInvoiceLeadDraftForResume?.length > 0 ? stateVars.TM_GetThirdPartyInvoiceLeadDraftForResume[0].canOpen : null) : (this.state.TM_GetThirdPartyInvoiceLeadDraftForResume?.length > 0 ? this.state.TM_GetThirdPartyInvoiceLeadDraftForResume[0].canOpen : null))), ReactSystemFunctions.convertToTypeByName("True", "string"))) {
            	
        if (true) {
        KuikaAppManager.showSpinner(this);
        }
        let result = await KuikaAppManager.ApiRequest(this, "TalepSatisIslemi/TalepSatisIslemiPageInit4_", localVar)
        if (!KMainFunctions.IsResStatus2XX(result)) return true;

		stateVars.TMSalesLeadPaymentList = result?.data.tmSalesLeadPaymentList;
		
		formVars.talepsatisislemi_100771_value = ReactSystemFunctions.toString(this, (stateVars.TMSalesLeadPaymentList !== undefined ? (stateVars.TMSalesLeadPaymentList?.length > 0 ? stateVars.TMSalesLeadPaymentList[0].collectedTotalEUR : null) : (this.state.TMSalesLeadPaymentList?.length > 0 ? this.state.TMSalesLeadPaymentList[0].collectedTotalEUR : null)));
		formVars.talepsatisislemi_653586_value = ReactSystemFunctions.toString(this, (stateVars.TMSalesLeadPaymentList !== undefined ? (stateVars.TMSalesLeadPaymentList?.length > 0 ? stateVars.TMSalesLeadPaymentList[0].remainingEUR : null) : (this.state.TMSalesLeadPaymentList?.length > 0 ? this.state.TMSalesLeadPaymentList[0].remainingEUR : null)));
		stateVars.isComp1894128536Enabled = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, (stateVars.TMSalesLeadPaymentList !== undefined ? (stateVars.TMSalesLeadPaymentList?.length > 0 ? stateVars.TMSalesLeadPaymentList[0].remainingEUR : null) : (this.state.TMSalesLeadPaymentList?.length > 0 ? this.state.TMSalesLeadPaymentList[0].remainingEUR : null))), ReactSystemFunctions.convertToTypeByName("0", "string"))) === true ? "enabled" : "disabled")
		stateVars.isComp761489Enabled = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, (stateVars.TMSalesLeadPaymentList !== undefined ? (stateVars.TMSalesLeadPaymentList?.length > 0 ? stateVars.TMSalesLeadPaymentList[0].remainingEUR : null) : (this.state.TMSalesLeadPaymentList?.length > 0 ? this.state.TMSalesLeadPaymentList[0].remainingEUR : null))), ReactSystemFunctions.convertToTypeByName("0", "string"))) === true ? "enabled" : "disabled")
		this.props.form?.setFieldsValue(formVars);
		
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.TalepSatisIslemiPageInit5_();
                  resolve();
                });
          })

        } else {
            
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.TalepSatisIslemiPageInit5_();
                  resolve();
                });
          })
        }


        
        KuikaAppManager.hideSpinner(this);
        return isErrorOccurred;
    }
    TalepSatisIslemiPageInit5_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


	if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }

        let localVar = {
			SalesDraftId_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toGuid(this, ReactSystemFunctions.value(this, "talepsatisislemi_337380_value", "value", "", "", "")), "Guid")
        }

if (ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, (stateVars.TM_GetThirdPartyInvoiceLeadDraftForResume !== undefined ? (stateVars.TM_GetThirdPartyInvoiceLeadDraftForResume?.length > 0 ? stateVars.TM_GetThirdPartyInvoiceLeadDraftForResume[0].canOpen : null) : (this.state.TM_GetThirdPartyInvoiceLeadDraftForResume?.length > 0 ? this.state.TM_GetThirdPartyInvoiceLeadDraftForResume[0].canOpen : null))), ReactSystemFunctions.convertToTypeByName("True", "string"))) {
            	
        if (true) {
        KuikaAppManager.showSpinner(this);
        }
        let result = await KuikaAppManager.ApiRequest(this, "TalepSatisIslemi/TalepSatisIslemiPageInit5_", localVar)
        if (!KMainFunctions.IsResStatus2XX(result)) return true;

		stateVars.TMSalesLeadSummary = result?.data.tmSalesLeadSummary;
		formVars.talepsatisislemi_706355_value = ReactSystemFunctions.toString(this, (stateVars.TMSalesLeadSummary !== undefined ? (stateVars.TMSalesLeadSummary?.length > 0 ? stateVars.TMSalesLeadSummary[0].urunAdedi : null) : (this.state.TMSalesLeadSummary?.length > 0 ? this.state.TMSalesLeadSummary[0].urunAdedi : null)));
		formVars.talepsatisislemi_957854_value = ReactSystemFunctions.toString(this, (stateVars.TMSalesLeadSummary !== undefined ? (stateVars.TMSalesLeadSummary?.length > 0 ? stateVars.TMSalesLeadSummary[0].araToplam : null) : (this.state.TMSalesLeadSummary?.length > 0 ? this.state.TMSalesLeadSummary[0].araToplam : null)));
		formVars.talepsatisislemi_94614_value = ReactSystemFunctions.toString(this, (stateVars.TMSalesLeadSummary !== undefined ? (stateVars.TMSalesLeadSummary?.length > 0 ? stateVars.TMSalesLeadSummary[0].iskontoTutari : null) : (this.state.TMSalesLeadSummary?.length > 0 ? this.state.TMSalesLeadSummary[0].iskontoTutari : null)));
		formVars.talepsatisislemi_28476_value = ReactSystemFunctions.toString(this, (stateVars.TMSalesLeadSummary !== undefined ? (stateVars.TMSalesLeadSummary?.length > 0 ? stateVars.TMSalesLeadSummary[0].genelToplam : null) : (this.state.TMSalesLeadSummary?.length > 0 ? this.state.TMSalesLeadSummary[0].genelToplam : null)));
		formVars.talepsatisislemi_646001_value = ReactSystemFunctions.toString(this, (stateVars.TMSalesLeadSummary !== undefined ? (stateVars.TMSalesLeadSummary?.length > 0 ? stateVars.TMSalesLeadSummary[0].tahsilEdilen : null) : (this.state.TMSalesLeadSummary?.length > 0 ? this.state.TMSalesLeadSummary[0].tahsilEdilen : null)));
		formVars.talepsatisislemi_804074_value = ReactSystemFunctions.toString(this, (stateVars.TMSalesLeadSummary !== undefined ? (stateVars.TMSalesLeadSummary?.length > 0 ? stateVars.TMSalesLeadSummary[0].kalanTutar : null) : (this.state.TMSalesLeadSummary?.length > 0 ? this.state.TMSalesLeadSummary[0].kalanTutar : null)));
		this.props.form?.setFieldsValue(formVars);
		
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.TalepSatisIslemiPageInit6_();
                  resolve();
                });
          })

        } else {
            
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.TalepSatisIslemiPageInit6_();
                  resolve();
                });
          })
        }


        
        KuikaAppManager.hideSpinner(this);
        return isErrorOccurred;
    }
    TalepSatisIslemiPageInit6_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


	if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }

        let localVar = {
        }

	
        if (true) {
        KuikaAppManager.showSpinner(this);
        }
        let result = await KuikaAppManager.ApiRequest(this, "TalepSatisIslemi/TalepSatisIslemiPageInit6_", localVar)
        if (!KMainFunctions.IsResStatus2XX(result)) return true;

		stateVars.TM_GetThirdPartyInvoiceCustomerList = result?.data.tM_GetThirdPartyInvoiceCustomerList;
		
		formVars.talepsatisislemi_227383778_options = stateVars.TM_GetThirdPartyInvoiceCustomerList;
		this.props.form?.setFieldsValue(formVars);
		
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.TalepSatisIslemiPageInit7_();
                  resolve();
                });
          })



        
        KuikaAppManager.hideSpinner(this);
        return isErrorOccurred;
    }
	TalepSatisIslemiPageInit7_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


	if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }

			formVars.talepsatisislemi_227199_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadById !== undefined ? (stateVars.TM_GetLeadById?.length > 0 ? stateVars.TM_GetLeadById[0].musteriAdi : null) : (this.state.TM_GetLeadById?.length > 0 ? this.state.TM_GetLeadById[0].musteriAdi : null)));

			formVars.talepsatisislemi_867471_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadById !== undefined ? (stateVars.TM_GetLeadById?.length > 0 ? stateVars.TM_GetLeadById[0].telefonNo : null) : (this.state.TM_GetLeadById?.length > 0 ? this.state.TM_GetLeadById[0].telefonNo : null)));

			formVars.talepsatisislemi_776728_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadById !== undefined ? (stateVars.TM_GetLeadById?.length > 0 ? stateVars.TM_GetLeadById[0].urunAdi : null) : (this.state.TM_GetLeadById?.length > 0 ? this.state.TM_GetLeadById[0].urunAdi : null)));

			formVars.talepsatisislemi_430401_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadById !== undefined ? (stateVars.TM_GetLeadById?.length > 0 ? stateVars.TM_GetLeadById[0].leadCode : null) : (this.state.TM_GetLeadById?.length > 0 ? this.state.TM_GetLeadById[0].leadCode : null)));

			formVars.talepsatisislemi_170676_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadById !== undefined ? (stateVars.TM_GetLeadById?.length > 0 ? stateVars.TM_GetLeadById[0].processName : null) : (this.state.TM_GetLeadById?.length > 0 ? this.state.TM_GetLeadById[0].processName : null)));

			formVars.talepsatisislemi_850125_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadById !== undefined ? (stateVars.TM_GetLeadById?.length > 0 ? stateVars.TM_GetLeadById[0].terminTarihi : null) : (this.state.TM_GetLeadById?.length > 0 ? this.state.TM_GetLeadById[0].terminTarihi : null)));

			stateVars.isComp832389Visible = ((ReactSystemFunctions.isEmpty(this.props.screenInputs.SalesLeadDraftId ?? this.props.screenInputs.salesleaddraftid, ReactSystemFunctions.convertToTypeByName("True", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp170159Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "talepsatisislemi_516749_value", "value", "", "key", "")), ReactSystemFunctions.convertToTypeByName("2", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp1499380460Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "talepsatisislemi_1790998325_checked", "checked", "", "", "")), ReactSystemFunctions.convertToTypeByName("True", "string"))) === true ? "visible" : "hidden")
			
			stateVars.dataSource_694044 = stateVars.TM_GetMergeableSalesLeadsWeb ?? this.state.TM_GetMergeableSalesLeadsWeb;
			stateVars.dataSource_694044 = stateVars.TM_GetMergeableSalesLeadsWeb ?? this.state.TM_GetMergeableSalesLeadsWeb;
			stateVars.isComp287429939Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "talepsatisislemi_1299000195_checked", "checked", "", "", "")), ReactSystemFunctions.convertToTypeByName("True", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp234425777Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "talepsatisislemi_1342936662_value", "value", "", "key", "")), ReactSystemFunctions.convertToTypeByName("CUSTOMER", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp1371997784Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "talepsatisislemi_1342936662_value", "value", "", "key", "")), ReactSystemFunctions.convertToTypeByName("CUSTOMER", "string"))) === true ? "visible" : "hidden")
			
			stateVars.dataSource_227383778 = stateVars.TM_GetThirdPartyInvoiceCustomerList ?? this.state.TM_GetThirdPartyInvoiceCustomerList;
			stateVars.dataSource_227383778 = stateVars.TM_GetThirdPartyInvoiceCustomerList ?? this.state.TM_GetThirdPartyInvoiceCustomerList;
			stateVars.isComp1649913896Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "talepsatisislemi_1342936662_value", "value", "", "key", "")), ReactSystemFunctions.convertToTypeByName("MANUAL", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp1720847430Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "talepsatisislemi_1685705311_value", "value", "", "key", "")), ReactSystemFunctions.convertToTypeByName("PERSON", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp61094802Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "talepsatisislemi_1685705311_value", "value", "", "key", "")), ReactSystemFunctions.convertToTypeByName("COMPANY", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp1289654211Visible = ((ReactSystemFunctions.isNotEmpty(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "talepsatisislemi_1685705311_value", "value", "", "key", "")), ReactSystemFunctions.convertToTypeByName("True", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp487685649Visible = ((ReactSystemFunctions.isNotEmpty(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "talepsatisislemi_1685705311_value", "value", "", "key", "")), ReactSystemFunctions.convertToTypeByName("True", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp684346Enabled = ((ReactSystemFunctions.isNotEmpty(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "talepsatisislemi_337380_value", "value", "", "", "")), ReactSystemFunctions.convertToTypeByName("True", "string"))) === true ? "enabled" : "disabled")

	this.props.form?.setFieldsValue(formVars);
	
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.TalepSatisIslemiPageInit8_();
                  resolve();
                });
          })

            
            return isErrorOccurred;
        }
	TalepSatisIslemiPageInit8_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


	if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
if (ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, (stateVars.TM_GetThirdPartyInvoiceLeadDraftForResume !== undefined ? (stateVars.TM_GetThirdPartyInvoiceLeadDraftForResume?.length > 0 ? stateVars.TM_GetThirdPartyInvoiceLeadDraftForResume[0].canOpen : null) : (this.state.TM_GetThirdPartyInvoiceLeadDraftForResume?.length > 0 ? this.state.TM_GetThirdPartyInvoiceLeadDraftForResume[0].canOpen : null))), ReactSystemFunctions.convertToTypeByName("True", "string"))) {
            
			

	this.props.form?.setFieldsValue(formVars);
	
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.TalepSatisIslemiPageInit9_();
                  resolve();
                });
          })

        } else {
            
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.TalepSatisIslemiPageInit9_();
                  resolve();
                });
          })
        }

            
            return isErrorOccurred;
        }
	TalepSatisIslemiPageInit9_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


	if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
if (ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, (stateVars.TM_GetThirdPartyInvoiceLeadDraftForResume !== undefined ? (stateVars.TM_GetThirdPartyInvoiceLeadDraftForResume?.length > 0 ? stateVars.TM_GetThirdPartyInvoiceLeadDraftForResume[0].canOpen : null) : (this.state.TM_GetThirdPartyInvoiceLeadDraftForResume?.length > 0 ? this.state.TM_GetThirdPartyInvoiceLeadDraftForResume[0].canOpen : null))), ReactSystemFunctions.convertToTypeByName("True", "string"))) {
            
			stateVars.dataSource_41607 = stateVars.GetSalesLeadProduct ?? this.state.GetSalesLeadProduct;

	this.props.form?.setFieldsValue(formVars);
	
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.TalepSatisIslemiPageInit10_();
                  resolve();
                });
          })

        } else {
            
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.TalepSatisIslemiPageInit10_();
                  resolve();
                });
          })
        }

            
            return isErrorOccurred;
        }
	TalepSatisIslemiPageInit10_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


	if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }

			stateVars.isComp625854Visible = ((ReactSystemFunctions.isEmpty(ReactSystemFunctions.value(this, "talepsatisislemi_41607_value", "barcode"), ReactSystemFunctions.convertToTypeByName("True", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp203199Visible = ((ReactSystemFunctions.isNotEmpty(ReactSystemFunctions.value(this, "talepsatisislemi_41607_value", "barcode"), ReactSystemFunctions.convertToTypeByName("True", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp759176Visible = ((ReactSystemFunctions.isNotEmpty(ReactSystemFunctions.value(this, (stateVars.GetSalesLeadProduct !== undefined ? (stateVars.GetSalesLeadProduct?.length > 0 ? stateVars.GetSalesLeadProduct[0].id : null) : (this.state.GetSalesLeadProduct?.length > 0 ? this.state.GetSalesLeadProduct[0].id : null))), ReactSystemFunctions.convertToTypeByName("True", "string"))) === true ? "visible" : "hidden")
			
			stateVars.dataSource_987644 = stateVars.TM_GetSalesExchangesRate ?? this.state.TM_GetSalesExchangesRate;
			stateVars.isComp281463Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "talepsatisislemi_831595_value", "value", "", "key", "")), ReactSystemFunctions.convertToTypeByName("2", "string"))) === true ? "visible" : "hidden")

	this.props.form?.setFieldsValue(formVars);
	
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.TalepSatisIslemiPageInit11_();
                  resolve();
                });
          })

            
            return isErrorOccurred;
        }
	TalepSatisIslemiPageInit11_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


	if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
if (ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, (stateVars.TM_GetThirdPartyInvoiceLeadDraftForResume !== undefined ? (stateVars.TM_GetThirdPartyInvoiceLeadDraftForResume?.length > 0 ? stateVars.TM_GetThirdPartyInvoiceLeadDraftForResume[0].canOpen : null) : (this.state.TM_GetThirdPartyInvoiceLeadDraftForResume?.length > 0 ? this.state.TM_GetThirdPartyInvoiceLeadDraftForResume[0].canOpen : null))), ReactSystemFunctions.convertToTypeByName("True", "string"))) {
            
			

	this.props.form?.setFieldsValue(formVars);
	
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.TalepSatisIslemiPageInit12_();
                  resolve();
                });
          })

        } else {
            
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.TalepSatisIslemiPageInit12_();
                  resolve();
                });
          })
        }

            
            return isErrorOccurred;
        }
	TalepSatisIslemiPageInit12_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


	if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
if (ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, (stateVars.TM_GetThirdPartyInvoiceLeadDraftForResume !== undefined ? (stateVars.TM_GetThirdPartyInvoiceLeadDraftForResume?.length > 0 ? stateVars.TM_GetThirdPartyInvoiceLeadDraftForResume[0].canOpen : null) : (this.state.TM_GetThirdPartyInvoiceLeadDraftForResume?.length > 0 ? this.state.TM_GetThirdPartyInvoiceLeadDraftForResume[0].canOpen : null))), ReactSystemFunctions.convertToTypeByName("True", "string"))) {
            
			stateVars.dataSource_466892 = stateVars.TMSalesLeadPaymentList ?? this.state.TMSalesLeadPaymentList;

	this.props.form?.setFieldsValue(formVars);
	
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.TalepSatisIslemiPageInit13_();
                  resolve();
                });
          })

        } else {
            
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.TalepSatisIslemiPageInit13_();
                  resolve();
                });
          })
        }

            
            return isErrorOccurred;
        }
	TalepSatisIslemiPageInit13_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


	if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
if (ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, (stateVars.TM_GetThirdPartyInvoiceLeadDraftForResume !== undefined ? (stateVars.TM_GetThirdPartyInvoiceLeadDraftForResume?.length > 0 ? stateVars.TM_GetThirdPartyInvoiceLeadDraftForResume[0].canOpen : null) : (this.state.TM_GetThirdPartyInvoiceLeadDraftForResume?.length > 0 ? this.state.TM_GetThirdPartyInvoiceLeadDraftForResume[0].canOpen : null))), ReactSystemFunctions.convertToTypeByName("True", "string"))) {
            
			formVars.talepsatisislemi_100771_value = ReactSystemFunctions.toString(this, (stateVars.TMSalesLeadPaymentList !== undefined ? (stateVars.TMSalesLeadPaymentList?.length > 0 ? stateVars.TMSalesLeadPaymentList[0].collectedTotalEUR : null) : (this.state.TMSalesLeadPaymentList?.length > 0 ? this.state.TMSalesLeadPaymentList[0].collectedTotalEUR : null)));


	this.props.form?.setFieldsValue(formVars);
	
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.TalepSatisIslemiPageInit14_();
                  resolve();
                });
          })

        } else {
            
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.TalepSatisIslemiPageInit14_();
                  resolve();
                });
          })
        }

            
            return isErrorOccurred;
        }
	TalepSatisIslemiPageInit14_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


	if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
if (ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, (stateVars.TM_GetThirdPartyInvoiceLeadDraftForResume !== undefined ? (stateVars.TM_GetThirdPartyInvoiceLeadDraftForResume?.length > 0 ? stateVars.TM_GetThirdPartyInvoiceLeadDraftForResume[0].canOpen : null) : (this.state.TM_GetThirdPartyInvoiceLeadDraftForResume?.length > 0 ? this.state.TM_GetThirdPartyInvoiceLeadDraftForResume[0].canOpen : null))), ReactSystemFunctions.convertToTypeByName("True", "string"))) {
            
			formVars.talepsatisislemi_653586_value = ReactSystemFunctions.toString(this, (stateVars.TMSalesLeadPaymentList !== undefined ? (stateVars.TMSalesLeadPaymentList?.length > 0 ? stateVars.TMSalesLeadPaymentList[0].remainingEUR : null) : (this.state.TMSalesLeadPaymentList?.length > 0 ? this.state.TMSalesLeadPaymentList[0].remainingEUR : null)));


	this.props.form?.setFieldsValue(formVars);
	
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.TalepSatisIslemiPageInit15_();
                  resolve();
                });
          })

        } else {
            
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.TalepSatisIslemiPageInit15_();
                  resolve();
                });
          })
        }

            
            return isErrorOccurred;
        }
	TalepSatisIslemiPageInit15_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


	if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
if (ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, (stateVars.TM_GetThirdPartyInvoiceLeadDraftForResume !== undefined ? (stateVars.TM_GetThirdPartyInvoiceLeadDraftForResume?.length > 0 ? stateVars.TM_GetThirdPartyInvoiceLeadDraftForResume[0].canOpen : null) : (this.state.TM_GetThirdPartyInvoiceLeadDraftForResume?.length > 0 ? this.state.TM_GetThirdPartyInvoiceLeadDraftForResume[0].canOpen : null))), ReactSystemFunctions.convertToTypeByName("True", "string"))) {
            
			formVars.talepsatisislemi_706355_value = ReactSystemFunctions.toString(this, (stateVars.TMSalesLeadSummary !== undefined ? (stateVars.TMSalesLeadSummary?.length > 0 ? stateVars.TMSalesLeadSummary[0].urunAdedi : null) : (this.state.TMSalesLeadSummary?.length > 0 ? this.state.TMSalesLeadSummary[0].urunAdedi : null)));


	this.props.form?.setFieldsValue(formVars);
	
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.TalepSatisIslemiPageInit16_();
                  resolve();
                });
          })

        } else {
            
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.TalepSatisIslemiPageInit16_();
                  resolve();
                });
          })
        }

            
            return isErrorOccurred;
        }
	TalepSatisIslemiPageInit16_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


	if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
if (ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, (stateVars.TM_GetThirdPartyInvoiceLeadDraftForResume !== undefined ? (stateVars.TM_GetThirdPartyInvoiceLeadDraftForResume?.length > 0 ? stateVars.TM_GetThirdPartyInvoiceLeadDraftForResume[0].canOpen : null) : (this.state.TM_GetThirdPartyInvoiceLeadDraftForResume?.length > 0 ? this.state.TM_GetThirdPartyInvoiceLeadDraftForResume[0].canOpen : null))), ReactSystemFunctions.convertToTypeByName("True", "string"))) {
            
			formVars.talepsatisislemi_957854_value = ReactSystemFunctions.toString(this, (stateVars.TMSalesLeadSummary !== undefined ? (stateVars.TMSalesLeadSummary?.length > 0 ? stateVars.TMSalesLeadSummary[0].araToplam : null) : (this.state.TMSalesLeadSummary?.length > 0 ? this.state.TMSalesLeadSummary[0].araToplam : null)));


	this.props.form?.setFieldsValue(formVars);
	
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.TalepSatisIslemiPageInit17_();
                  resolve();
                });
          })

        } else {
            
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.TalepSatisIslemiPageInit17_();
                  resolve();
                });
          })
        }

            
            return isErrorOccurred;
        }
	TalepSatisIslemiPageInit17_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


	if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
if (ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, (stateVars.TM_GetThirdPartyInvoiceLeadDraftForResume !== undefined ? (stateVars.TM_GetThirdPartyInvoiceLeadDraftForResume?.length > 0 ? stateVars.TM_GetThirdPartyInvoiceLeadDraftForResume[0].canOpen : null) : (this.state.TM_GetThirdPartyInvoiceLeadDraftForResume?.length > 0 ? this.state.TM_GetThirdPartyInvoiceLeadDraftForResume[0].canOpen : null))), ReactSystemFunctions.convertToTypeByName("True", "string"))) {
            
			formVars.talepsatisislemi_94614_value = ReactSystemFunctions.toString(this, (stateVars.TMSalesLeadSummary !== undefined ? (stateVars.TMSalesLeadSummary?.length > 0 ? stateVars.TMSalesLeadSummary[0].iskontoTutari : null) : (this.state.TMSalesLeadSummary?.length > 0 ? this.state.TMSalesLeadSummary[0].iskontoTutari : null)));


	this.props.form?.setFieldsValue(formVars);
	
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.TalepSatisIslemiPageInit18_();
                  resolve();
                });
          })

        } else {
            
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.TalepSatisIslemiPageInit18_();
                  resolve();
                });
          })
        }

            
            return isErrorOccurred;
        }
	TalepSatisIslemiPageInit18_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


	if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
if (ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, (stateVars.TM_GetThirdPartyInvoiceLeadDraftForResume !== undefined ? (stateVars.TM_GetThirdPartyInvoiceLeadDraftForResume?.length > 0 ? stateVars.TM_GetThirdPartyInvoiceLeadDraftForResume[0].canOpen : null) : (this.state.TM_GetThirdPartyInvoiceLeadDraftForResume?.length > 0 ? this.state.TM_GetThirdPartyInvoiceLeadDraftForResume[0].canOpen : null))), ReactSystemFunctions.convertToTypeByName("True", "string"))) {
            
			formVars.talepsatisislemi_28476_value = ReactSystemFunctions.toString(this, (stateVars.TMSalesLeadSummary !== undefined ? (stateVars.TMSalesLeadSummary?.length > 0 ? stateVars.TMSalesLeadSummary[0].genelToplam : null) : (this.state.TMSalesLeadSummary?.length > 0 ? this.state.TMSalesLeadSummary[0].genelToplam : null)));


	this.props.form?.setFieldsValue(formVars);
	
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.TalepSatisIslemiPageInit19_();
                  resolve();
                });
          })

        } else {
            
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.TalepSatisIslemiPageInit19_();
                  resolve();
                });
          })
        }

            
            return isErrorOccurred;
        }
	TalepSatisIslemiPageInit19_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


	if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
if (ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, (stateVars.TM_GetThirdPartyInvoiceLeadDraftForResume !== undefined ? (stateVars.TM_GetThirdPartyInvoiceLeadDraftForResume?.length > 0 ? stateVars.TM_GetThirdPartyInvoiceLeadDraftForResume[0].canOpen : null) : (this.state.TM_GetThirdPartyInvoiceLeadDraftForResume?.length > 0 ? this.state.TM_GetThirdPartyInvoiceLeadDraftForResume[0].canOpen : null))), ReactSystemFunctions.convertToTypeByName("True", "string"))) {
            
			formVars.talepsatisislemi_646001_value = ReactSystemFunctions.toString(this, (stateVars.TMSalesLeadSummary !== undefined ? (stateVars.TMSalesLeadSummary?.length > 0 ? stateVars.TMSalesLeadSummary[0].tahsilEdilen : null) : (this.state.TMSalesLeadSummary?.length > 0 ? this.state.TMSalesLeadSummary[0].tahsilEdilen : null)));


	this.props.form?.setFieldsValue(formVars);
	
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.TalepSatisIslemiPageInit20_();
                  resolve();
                });
          })

        } else {
            
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.TalepSatisIslemiPageInit20_();
                  resolve();
                });
          })
        }

            
            return isErrorOccurred;
        }
	TalepSatisIslemiPageInit20_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


	if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
if (ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, (stateVars.TM_GetThirdPartyInvoiceLeadDraftForResume !== undefined ? (stateVars.TM_GetThirdPartyInvoiceLeadDraftForResume?.length > 0 ? stateVars.TM_GetThirdPartyInvoiceLeadDraftForResume[0].canOpen : null) : (this.state.TM_GetThirdPartyInvoiceLeadDraftForResume?.length > 0 ? this.state.TM_GetThirdPartyInvoiceLeadDraftForResume[0].canOpen : null))), ReactSystemFunctions.convertToTypeByName("True", "string"))) {
            
			formVars.talepsatisislemi_804074_value = ReactSystemFunctions.toString(this, (stateVars.TMSalesLeadSummary !== undefined ? (stateVars.TMSalesLeadSummary?.length > 0 ? stateVars.TMSalesLeadSummary[0].kalanTutar : null) : (this.state.TMSalesLeadSummary?.length > 0 ? this.state.TMSalesLeadSummary[0].kalanTutar : null)));


	this.props.form?.setFieldsValue(formVars);
	
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.TalepSatisIslemiPageInit21_();
                  resolve();
                });
          })

        } else {
            
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.TalepSatisIslemiPageInit21_();
                  resolve();
                });
          })
        }

            
            return isErrorOccurred;
        }
	TalepSatisIslemiPageInit21_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


	if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }

			stateVars.isComp1894128536Enabled = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, (stateVars.TMSalesLeadPaymentList !== undefined ? (stateVars.TMSalesLeadPaymentList?.length > 0 ? stateVars.TMSalesLeadPaymentList[0].remainingEUR : null) : (this.state.TMSalesLeadPaymentList?.length > 0 ? this.state.TMSalesLeadPaymentList[0].remainingEUR : null))), ReactSystemFunctions.convertToTypeByName("0", "string"))) === true ? "enabled" : "disabled")
			stateVars.isComp761489Enabled = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, (stateVars.TMSalesLeadPaymentList !== undefined ? (stateVars.TMSalesLeadPaymentList?.length > 0 ? stateVars.TMSalesLeadPaymentList[0].remainingEUR : null) : (this.state.TMSalesLeadPaymentList?.length > 0 ? this.state.TMSalesLeadPaymentList[0].remainingEUR : null))), ReactSystemFunctions.convertToTypeByName("0", "string"))) === true ? "enabled" : "disabled")

	this.props.form?.setFieldsValue(formVars);
	this.setState(stateVars);
	KuikaAppManager.hideSpinner(this);

            this.setPageInitLoaded(true);
            return isErrorOccurred;
        }





























		TalepSatisIslemiComponent_516749_onBlur = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
if (ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, (stateVars.TM_CheckCustomerVerificationPopup !== undefined ? (stateVars.TM_CheckCustomerVerificationPopup?.length > 0 ? stateVars.TM_CheckCustomerVerificationPopup[0].openPopup : null) : (this.state.TM_CheckCustomerVerificationPopup?.length > 0 ? this.state.TM_CheckCustomerVerificationPopup[0].openPopup : null))), true)) {
            KuikaAppManager.showSpinner(this);

					KuikaAppManager.prepareForNavigation();
						KuikaAppManager.addToPageInputVariables("MusteriOnayPop", "CustomerId", ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, (stateVars.TM_GetSalesLeadById !== undefined ? (stateVars.TM_GetSalesLeadById?.length > 0 ? stateVars.TM_GetSalesLeadById[0].customerId : null) : (this.state.TM_GetSalesLeadById?.length > 0 ? this.state.TM_GetSalesLeadById[0].customerId : null))), "Guid"));

				stateVars.NAVIGATE = await ReactSystemFunctions.navigate(this, undefined, "TalepSatisIslemi", "MusteriOnayPop", "", "9924ef5f-4b84-4200-b624-8d76348c7686", "1530726317", null, null, "False", "80%", "90%", false, false);

		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

        } else {
            KuikaAppManager.hideSpinner(this);
        }

            
            return isErrorOccurred;
        }


		TalepSatisIslemiComponent_1790998325_onChange = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
if (ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "talepsatisislemi_1790998325_checked", "checked", "", "", "")), false)) {
            KuikaAppManager.showSpinner(this);

				stateVars.SetValueOf = await ReactSystemFunctions.setValueOf(this, ReactSystemFunctions.convertToTypeByName("talepsatisislemi_694044_value", "string"), "", null, false);

		this.props.form?.setFieldsValue(formVars);
		
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.TalepSatisIslemiComponent_1790998325_onChange1_();
                  resolve();
                });
          })

        } else {
            
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.TalepSatisIslemiComponent_1790998325_onChange1_();
                  resolve();
                });
          })
        }

            
            return isErrorOccurred;
        }
		TalepSatisIslemiComponent_1790998325_onChange1_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }

				stateVars.isComp1499380460Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "talepsatisislemi_1790998325_checked", "checked", "", "", "")), true)) === true ? "visible" : "hidden")

		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

            
            return isErrorOccurred;
        }



    TalepSatisIslemiComponent_1342936662_onChange = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
		KuikaAppManager.increaseServerRequestCount();

        let localVar = {
        }

		KuikaAppManager.showSpinner(this);
		
        if (true) {
        KuikaAppManager.showSpinner(this);
        }
        let result = await KuikaAppManager.ApiRequest(this, "TalepSatisIslemi/TalepSatisIslemiComponent_1342936662_onChange", localVar)
        if (!KMainFunctions.IsResStatus2XX(result)) return true;

			stateVars.TM_GetCountry = result?.data.tM_GetCountry;
			
			formVars.talepsatisislemi_761478296_options = stateVars.TM_GetCountry;
			this.props.form?.setFieldsValue(formVars);
			
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.TalepSatisIslemiComponent_1342936662_onChange1_();
                  resolve();
                });
          })



        
        KuikaAppManager.hideSpinner(this);
        return isErrorOccurred;
    }
		TalepSatisIslemiComponent_1342936662_onChange1_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }

				stateVars.isComp234425777Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "talepsatisislemi_1342936662_value", "value", "", "key", "")), "CUSTOMER")) === true ? "visible" : "hidden")
				stateVars.isComp1371997784Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "talepsatisislemi_1342936662_value", "value", "", "key", "")), "CUSTOMER")) === true ? "visible" : "hidden")
				stateVars.isComp1649913896Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "talepsatisislemi_1342936662_value", "value", "", "key", "")), "MANUAL")) === true ? "visible" : "hidden")
				
				stateVars.dataSource_761478296 = stateVars.TM_GetCountry ?? this.state.TM_GetCountry;
				stateVars.dataSource_761478296 = stateVars.TM_GetCountry ?? this.state.TM_GetCountry;

		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

            
            return isErrorOccurred;
        }




    TalepSatisIslemiComponent_761478296_onChange = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
		KuikaAppManager.increaseServerRequestCount();

        let localVar = {
				CountryCode_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "talepsatisislemi_761478296_value", "value", "TM_GetCountry", "countryCode", "countryCode")), "string")
        }

		KuikaAppManager.showSpinner(this);
		
        if (true) {
        KuikaAppManager.showSpinner(this);
        }
        let result = await KuikaAppManager.ApiRequest(this, "TalepSatisIslemi/TalepSatisIslemiComponent_761478296_onChange", localVar)
        if (!KMainFunctions.IsResStatus2XX(result)) return true;

			stateVars.TM_GetCitySql = result?.data.tM_GetCitySql;
			
			formVars.talepsatisislemi_1161020887_options = stateVars.TM_GetCitySql;
			this.props.form?.setFieldsValue(formVars);
			
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.TalepSatisIslemiComponent_761478296_onChange1_();
                  resolve();
                });
          })



        
        KuikaAppManager.hideSpinner(this);
        return isErrorOccurred;
    }
		TalepSatisIslemiComponent_761478296_onChange1_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }

				
				stateVars.dataSource_1161020887 = stateVars.TM_GetCitySql ?? this.state.TM_GetCitySql;
				stateVars.dataSource_1161020887 = stateVars.TM_GetCitySql ?? this.state.TM_GetCitySql;

		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

            
            return isErrorOccurred;
        }




    TalepSatisIslemiComponent_1161020887_onChange = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
		KuikaAppManager.increaseServerRequestCount();

        let localVar = {
				CityCode_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "talepsatisislemi_1161020887_value", "value", "TM_GetCitySql", "cityCode", "cityCode")), "string")
        }

		KuikaAppManager.showSpinner(this);
		
        if (true) {
        KuikaAppManager.showSpinner(this);
        }
        let result = await KuikaAppManager.ApiRequest(this, "TalepSatisIslemi/TalepSatisIslemiComponent_1161020887_onChange", localVar)
        if (!KMainFunctions.IsResStatus2XX(result)) return true;

			stateVars.TM_GetDistrict = result?.data.tM_GetDistrict;
			
			formVars.talepsatisislemi_852869243_options = stateVars.TM_GetDistrict;
			this.props.form?.setFieldsValue(formVars);
			
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.TalepSatisIslemiComponent_1161020887_onChange1_();
                  resolve();
                });
          })



        
        KuikaAppManager.hideSpinner(this);
        return isErrorOccurred;
    }
		TalepSatisIslemiComponent_1161020887_onChange1_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }

				
				stateVars.dataSource_852869243 = stateVars.TM_GetDistrict ?? this.state.TM_GetDistrict;
				stateVars.dataSource_852869243 = stateVars.TM_GetDistrict ?? this.state.TM_GetDistrict;

		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

            
            return isErrorOccurred;
        }




    TalepSatisIslemiComponent_555308_onClick = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
		KuikaAppManager.increaseServerRequestCount();

        let localVar = {
				InvoiceType_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toInteger(this, ReactSystemFunctions.value(this, "talepsatisislemi_516749_value", "value", "", "key", "")), "number"),
				TaxFreeOturuNo_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "talepsatisislemi_708806_value", "value", "", "", "")), "string"),
				TaxFreeBaslangic_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "talepsatisislemi_403854_value", "value", "", "", "")), "Date"),
				TaxFreeBitis_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "talepsatisislemi_141674_value", "value", "", "", "")), "Date"),
				CustomerId_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, (stateVars.TM_GetSalesLeadById !== undefined ? (stateVars.TM_GetSalesLeadById?.length > 0 ? stateVars.TM_GetSalesLeadById[0].customerId : null) : (this.state.TM_GetSalesLeadById?.length > 0 ? this.state.TM_GetSalesLeadById[0].customerId : null))), "Guid"),
				IsEInvoiceApi_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, (stateVars.TM_GetCustomerById !== undefined ? (stateVars.TM_GetCustomerById?.length > 0 ? stateVars.TM_GetCustomerById[0].isEInvoice : null) : (this.state.TM_GetCustomerById?.length > 0 ? this.state.TM_GetCustomerById[0].isEInvoice : null))), "boolean"),
				KUserID_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.getMyUserId(), "Guid"),
				LeadId_0: ReactSystemFunctions.convertToTypeByName(this.props.screenInputs.LeadId ?? this.props.screenInputs.leadid, "Guid"),
				SalesPersonTMUserId_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, (stateVars.TM_GetSalesLeadById !== undefined ? (stateVars.TM_GetSalesLeadById?.length > 0 ? stateVars.TM_GetSalesLeadById[0].tmUserId : null) : (this.state.TM_GetSalesLeadById?.length > 0 ? this.state.TM_GetSalesLeadById[0].tmUserId : null))), "Guid"),
				StoreCode_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, (stateVars.TM_GetSalesLeadById !== undefined ? (stateVars.TM_GetSalesLeadById?.length > 0 ? stateVars.TM_GetSalesLeadById[0].storeCode : null) : (this.state.TM_GetSalesLeadById?.length > 0 ? this.state.TM_GetSalesLeadById[0].storeCode : null))), "string")
        }

		KuikaAppManager.showSpinner(this);
		
        if (true) {
        KuikaAppManager.showSpinner(this);
        }
        let result = await KuikaAppManager.ApiRequest(this, "TalepSatisIslemi/TalepSatisIslemiComponent_555308_onClick", localVar)
        if (!KMainFunctions.IsResStatus2XX(result)) return true;

			stateVars.TMSalesLeadDraftCreate = result?.data.tmSalesLeadDraftCreate;
			this.props.form?.setFieldsValue(formVars);
			
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.TalepSatisIslemiComponent_555308_onClick1_();
                  resolve();
                });
          })



        
        KuikaAppManager.hideSpinner(this);
        return isErrorOccurred;
    }
		TalepSatisIslemiComponent_555308_onClick1_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
if (ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, (stateVars.TMSalesLeadDraftCreate !== undefined ? (stateVars.TMSalesLeadDraftCreate?.length > 0 ? stateVars.TMSalesLeadDraftCreate[0].success : null) : (this.state.TMSalesLeadDraftCreate?.length > 0 ? this.state.TMSalesLeadDraftCreate[0].success : null))), "1")) {
            
				stateVars.SetValueOf = await ReactSystemFunctions.setValueOf(this, ReactSystemFunctions.convertToTypeByName("talepsatisislemi_337380_value", "string"), ReactSystemFunctions.toString(this, (stateVars.TMSalesLeadDraftCreate !== undefined ? (stateVars.TMSalesLeadDraftCreate?.length > 0 ? stateVars.TMSalesLeadDraftCreate[0].draftId : null) : (this.state.TMSalesLeadDraftCreate?.length > 0 ? this.state.TMSalesLeadDraftCreate[0].draftId : null))), null, false);

		this.props.form?.setFieldsValue(formVars);
		
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.TalepSatisIslemiComponent_555308_onClick2_();
                  resolve();
                });
          })

        } else {
            
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.TalepSatisIslemiComponent_555308_onClick2_();
                  resolve();
                });
          })
        }

            
            return isErrorOccurred;
        }
    TalepSatisIslemiComponent_555308_onClick2_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
		KuikaAppManager.increaseServerRequestCount();

        let localVar = {
				IsMultiLead_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "talepsatisislemi_1790998325_checked", "checked", "", "", "")), "boolean"),
				SelectedLeadIds_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "talepsatisislemi_694044_value", "value", "TM_GetMergeableSalesLeadsWeb", "leadId", "leadId")), "string"),
				PrimaryLeadId_0: ReactSystemFunctions.convertToTypeByName(this.props.screenInputs.LeadId ?? this.props.screenInputs.leadid, "Guid"),
				SalesDraftId_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, (stateVars.TMSalesLeadDraftCreate !== undefined ? (stateVars.TMSalesLeadDraftCreate?.length > 0 ? stateVars.TMSalesLeadDraftCreate[0].draftId : null) : (this.state.TMSalesLeadDraftCreate?.length > 0 ? this.state.TMSalesLeadDraftCreate[0].draftId : null))), "Guid"),
				CurrentUserId_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.getMyUserId(), "Guid")
        }

if (ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, (stateVars.TMSalesLeadDraftCreate !== undefined ? (stateVars.TMSalesLeadDraftCreate?.length > 0 ? stateVars.TMSalesLeadDraftCreate[0].success : null) : (this.state.TMSalesLeadDraftCreate?.length > 0 ? this.state.TMSalesLeadDraftCreate[0].success : null))), ReactSystemFunctions.convertToTypeByName("1", "string"))) {
            		
        if (true) {
        KuikaAppManager.showSpinner(this);
        }
        let result = await KuikaAppManager.ApiRequest(this, "TalepSatisIslemi/TalepSatisIslemiComponent_555308_onClick2_", localVar)
        if (!KMainFunctions.IsResStatus2XX(result)) return true;

			stateVars.TM_SaveSalesDraftLeadSelectionWeb = result?.data.tM_SaveSalesDraftLeadSelectionWeb;
			this.props.form?.setFieldsValue(formVars);
			
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.TalepSatisIslemiComponent_555308_onClick3_();
                  resolve();
                });
          })

        } else {
            
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.TalepSatisIslemiComponent_555308_onClick3_();
                  resolve();
                });
          })
        }


        
        KuikaAppManager.hideSpinner(this);
        return isErrorOccurred;
    }
    TalepSatisIslemiComponent_555308_onClick3_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
		KuikaAppManager.increaseServerRequestCount();

        let localVar = {
				SourceType_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "talepsatisislemi_1342936662_value", "value", "", "key", "")), "string"),
				PersonType_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "talepsatisislemi_1685705311_value", "value", "", "key", "")), "string"),
				SalesLeadDraftId_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, (stateVars.TMSalesLeadDraftCreate !== undefined ? (stateVars.TMSalesLeadDraftCreate?.length > 0 ? stateVars.TMSalesLeadDraftCreate[0].draftId : null) : (this.state.TMSalesLeadDraftCreate?.length > 0 ? this.state.TMSalesLeadDraftCreate[0].draftId : null))), "Guid"),
				CurrentUserId_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.getMyUserId(), "Guid"),
				ThirdPartyCustomerId_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "talepsatisislemi_227383778_value", "value", "TM_GetThirdPartyInvoiceCustomerList", "id", "id")), "Guid"),
				FirstName_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "talepsatisislemi_1617736699_value", "value", "", "", "")), "string"),
				LastName_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "talepsatisislemi_508462469_value", "value", "", "", "")), "string"),
				IdentityNumber_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "talepsatisislemi_2079690263_value", "value", "", "", "")), "string"),
				CompanyName_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "talepsatisislemi_1359451170_value", "value", "", "", "")), "string"),
				TaxNumber_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "talepsatisislemi_1670324057_value", "value", "", "", "")), "string"),
				TaxOfficeCode_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "talepsatisislemi_668385102_value", "value", "", "", "")), "string"),
				Address_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "talepsatisislemi_1475165764_value", "value", "", "", "")), "string"),
				CountryCode_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "talepsatisislemi_761478296_value", "value", "TM_GetCountry", "countryCode", "countryCode")), "string"),
				StateCode_0: ReactSystemFunctions.convertToTypeByName("", "string"),
				CityCode_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "talepsatisislemi_1161020887_value", "value", "TM_GetCitySql", "cityCode", "cityCode")), "string"),
				DistrictCode_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "talepsatisislemi_852869243_value", "value", "TM_GetDistrict", "districtCode", "districtCode")), "string")
        }

if ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "talepsatisislemi_1299000195_checked", "checked", "", "", "")), ReactSystemFunctions.convertToTypeByName("True", "string")) && ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, (stateVars.TMSalesLeadDraftCreate !== undefined ? (stateVars.TMSalesLeadDraftCreate?.length > 0 ? stateVars.TMSalesLeadDraftCreate[0].success : null) : (this.state.TMSalesLeadDraftCreate?.length > 0 ? this.state.TMSalesLeadDraftCreate[0].success : null))), ReactSystemFunctions.convertToTypeByName("1", "string")))) {
            		
        if (true) {
        KuikaAppManager.showSpinner(this);
        }
        let result = await KuikaAppManager.ApiRequest(this, "TalepSatisIslemi/TalepSatisIslemiComponent_555308_onClick3_", localVar)
        if (!KMainFunctions.IsResStatus2XX(result)) return true;

			stateVars.TM_CreateThirdPartyInvoiceLeadApprovalDraft = result?.data.tM_CreateThirdPartyInvoiceLeadApprovalDraft;
			this.props.form?.setFieldsValue(formVars);
			
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.TalepSatisIslemiComponent_555308_onClick4_();
                  resolve();
                });
          })

        } else {
            
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.TalepSatisIslemiComponent_555308_onClick4_();
                  resolve();
                });
          })
        }


        
        KuikaAppManager.hideSpinner(this);
        return isErrorOccurred;
    }
		TalepSatisIslemiComponent_555308_onClick4_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }

				stateVars.Notify = await ReactSystemFunctions.notify(this, ReactSystemFunctions.toString(this, (stateVars.TMSalesLeadDraftCreate !== undefined ? (stateVars.TMSalesLeadDraftCreate?.length > 0 ? stateVars.TMSalesLeadDraftCreate[0].message : null) : (this.state.TMSalesLeadDraftCreate?.length > 0 ? this.state.TMSalesLeadDraftCreate[0].message : null))), ReactSystemFunctions.convertToTypeByName("default", "string"), ReactSystemFunctions.convertToTypeByName("bottom-right", "string"), 3, ReactSystemFunctions.convertToTypeByName("", "string"), ReactSystemFunctions.convertToTypeByName("", "string"), 0);
				stateVars.Notify = await ReactSystemFunctions.notify(this, ReactSystemFunctions.toString(this, (stateVars.TM_CreateThirdPartyInvoiceLeadApprovalDraft !== undefined ? (stateVars.TM_CreateThirdPartyInvoiceLeadApprovalDraft?.length > 0 ? stateVars.TM_CreateThirdPartyInvoiceLeadApprovalDraft[0].message : null) : (this.state.TM_CreateThirdPartyInvoiceLeadApprovalDraft?.length > 0 ? this.state.TM_CreateThirdPartyInvoiceLeadApprovalDraft[0].message : null))), ReactSystemFunctions.convertToTypeByName("default", "string"), ReactSystemFunctions.convertToTypeByName("bottom-right", "string"), 3, ReactSystemFunctions.convertToTypeByName("", "string"), ReactSystemFunctions.convertToTypeByName("", "string"), 0);

		this.props.form?.setFieldsValue(formVars);
		
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.TalepSatisIslemiComponent_555308_onClick5_();
                  resolve();
                });
          })

            
            return isErrorOccurred;
        }
		TalepSatisIslemiComponent_555308_onClick5_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
if (ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "talepsatisislemi_1790998325_checked", "checked", "", "", "")), true)) {
            
				stateVars.Notify = await ReactSystemFunctions.notify(this, ReactSystemFunctions.toString(this, (stateVars.TM_SaveSalesDraftLeadSelectionWeb !== undefined ? (stateVars.TM_SaveSalesDraftLeadSelectionWeb?.length > 0 ? stateVars.TM_SaveSalesDraftLeadSelectionWeb[0].message : null) : (this.state.TM_SaveSalesDraftLeadSelectionWeb?.length > 0 ? this.state.TM_SaveSalesDraftLeadSelectionWeb[0].message : null))), ReactSystemFunctions.convertToTypeByName("default", "string"), ReactSystemFunctions.convertToTypeByName("bottom-right", "string"), 3, ReactSystemFunctions.convertToTypeByName("", "string"), ReactSystemFunctions.convertToTypeByName("", "string"), 0);

		this.props.form?.setFieldsValue(formVars);
		
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.TalepSatisIslemiComponent_555308_onClick6_();
                  resolve();
                });
          })

        } else {
            
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.TalepSatisIslemiComponent_555308_onClick6_();
                  resolve();
                });
          })
        }

            
            return isErrorOccurred;
        }
		TalepSatisIslemiComponent_555308_onClick6_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
if (ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, (stateVars.TMSalesLeadDraftCreate !== undefined ? (stateVars.TMSalesLeadDraftCreate?.length > 0 ? stateVars.TMSalesLeadDraftCreate[0].success : null) : (this.state.TMSalesLeadDraftCreate?.length > 0 ? this.state.TMSalesLeadDraftCreate[0].success : null))), "1")) {
            
				stateVars.ChangeEnabledOf = await ReactSystemFunctions.changeEnabledOf(this, ReactSystemFunctions.convertToTypeByName("isComp832389Enabled", "string"), ReactSystemFunctions.convertToTypeByName("disabled", "string"));

		this.props.form?.setFieldsValue(formVars);
		
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.TalepSatisIslemiComponent_555308_onClick7_();
                  resolve();
                });
          })

        } else {
            
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.TalepSatisIslemiComponent_555308_onClick7_();
                  resolve();
                });
          })
        }

            
            return isErrorOccurred;
        }
		TalepSatisIslemiComponent_555308_onClick7_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
if (ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, (stateVars.TMSalesLeadDraftCreate !== undefined ? (stateVars.TMSalesLeadDraftCreate?.length > 0 ? stateVars.TMSalesLeadDraftCreate[0].success : null) : (this.state.TMSalesLeadDraftCreate?.length > 0 ? this.state.TMSalesLeadDraftCreate[0].success : null))), "1")) {
            
				stateVars.ChangeEnabledOf = await ReactSystemFunctions.changeEnabledOf(this, ReactSystemFunctions.convertToTypeByName("isComp684346Enabled", "string"), ReactSystemFunctions.convertToTypeByName("enabled", "string"));

		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

        } else {
            KuikaAppManager.hideSpinner(this);
        }

            
            return isErrorOccurred;
        }












		TalepSatisIslemiComponent_373821_onChange = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
if (ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "talepsatisislemi_373821_value", "value", "", "", "")), true)) {
            KuikaAppManager.showSpinner(this);

				stateVars.ChangeVisibilityOf = await ReactSystemFunctions.changeVisibilityOf(this, ReactSystemFunctions.convertToTypeByName("isComp347901Visible", "string"), ReactSystemFunctions.convertToTypeByName("visible", "string"));

		this.props.form?.setFieldsValue(formVars);
		
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.TalepSatisIslemiComponent_373821_onChange1_();
                  resolve();
                });
          })

        } else {
            
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.TalepSatisIslemiComponent_373821_onChange1_();
                  resolve();
                });
          })
        }

            
            return isErrorOccurred;
        }
		TalepSatisIslemiComponent_373821_onChange1_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
if (ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "talepsatisislemi_373821_value", "value", "", "", "")), true)) {
            
				stateVars.ChangeVisibilityOf = await ReactSystemFunctions.changeVisibilityOf(this, ReactSystemFunctions.convertToTypeByName("isComp731364Visible", "string"), ReactSystemFunctions.convertToTypeByName("hidden", "string"));

		this.props.form?.setFieldsValue(formVars);
		
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.TalepSatisIslemiComponent_373821_onChange2_();
                  resolve();
                });
          })

        } else {
            
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.TalepSatisIslemiComponent_373821_onChange2_();
                  resolve();
                });
          })
        }

            
            return isErrorOccurred;
        }
		TalepSatisIslemiComponent_373821_onChange2_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
if (ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "talepsatisislemi_373821_value", "value", "", "", "")), false)) {
            
				stateVars.ChangeVisibilityOf = await ReactSystemFunctions.changeVisibilityOf(this, ReactSystemFunctions.convertToTypeByName("isComp347901Visible", "string"), ReactSystemFunctions.convertToTypeByName("hidden", "string"));

		this.props.form?.setFieldsValue(formVars);
		
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.TalepSatisIslemiComponent_373821_onChange3_();
                  resolve();
                });
          })

        } else {
            
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.TalepSatisIslemiComponent_373821_onChange3_();
                  resolve();
                });
          })
        }

            
            return isErrorOccurred;
        }
		TalepSatisIslemiComponent_373821_onChange3_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
if (ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "talepsatisislemi_373821_value", "value", "", "", "")), false)) {
            
				stateVars.ChangeVisibilityOf = await ReactSystemFunctions.changeVisibilityOf(this, ReactSystemFunctions.convertToTypeByName("isComp731364Visible", "string"), ReactSystemFunctions.convertToTypeByName("visible", "string"));

		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

        } else {
            KuikaAppManager.hideSpinner(this);
        }

            
            return isErrorOccurred;
        }





    TalepSatisIslemiComponent_10440_onClick = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
		KuikaAppManager.increaseServerRequestCount();

        let localVar = {
				usedCode_1: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "talepsatisislemi_878977_value", "value", "", "", "")), "string"),
				wareHouseCode_1: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, (stateVars.TM_GetSalesLeadById !== undefined ? (stateVars.TM_GetSalesLeadById?.length > 0 ? stateVars.TM_GetSalesLeadById[0].wareHouseCode : null) : (this.state.TM_GetSalesLeadById?.length > 0 ? this.state.TM_GetSalesLeadById[0].wareHouseCode : null))), "string"),
				ProductCode_2: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, (stateVars.Kuika_ItemInfoLive !== undefined ? (stateVars.Kuika_ItemInfoLive?.length > 0 ? stateVars.Kuika_ItemInfoLive[0].itemCode : null) : (this.state.Kuika_ItemInfoLive?.length > 0 ? this.state.Kuika_ItemInfoLive[0].itemCode : null))), "string"),
				SalesDraftId_2: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toGuid(this, ReactSystemFunctions.value(this, "talepsatisislemi_337380_value", "value", "", "", "")), "Guid"),
				SeriNo_2: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, (stateVars.Kuika_ItemInfoLive !== undefined ? (stateVars.Kuika_ItemInfoLive?.length > 0 ? stateVars.Kuika_ItemInfoLive[0].itemSerialNumber : null) : (this.state.Kuika_ItemInfoLive?.length > 0 ? this.state.Kuika_ItemInfoLive[0].itemSerialNumber : null))), "string"),
				ProductName_2: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, (stateVars.Kuika_ItemInfoLive !== undefined ? (stateVars.Kuika_ItemInfoLive?.length > 0 ? stateVars.Kuika_ItemInfoLive[0].itemDescription : null) : (this.state.Kuika_ItemInfoLive?.length > 0 ? this.state.Kuika_ItemInfoLive[0].itemDescription : null))), "string"),
				Barcode_2: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, (stateVars.Kuika_ItemInfoLive !== undefined ? (stateVars.Kuika_ItemInfoLive?.length > 0 ? stateVars.Kuika_ItemInfoLive[0].barcode : null) : (this.state.Kuika_ItemInfoLive?.length > 0 ? this.state.Kuika_ItemInfoLive[0].barcode : null))), "string"),
				UserSerialNumber_2: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, (stateVars.Kuika_ItemInfoLive !== undefined ? (stateVars.Kuika_ItemInfoLive?.length > 0 ? stateVars.Kuika_ItemInfoLive[0].useSerialNumber : null) : (this.state.Kuika_ItemInfoLive?.length > 0 ? this.state.Kuika_ItemInfoLive[0].useSerialNumber : null))), "string"),
				Price_2: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, (stateVars.Kuika_ItemInfoLive !== undefined ? (stateVars.Kuika_ItemInfoLive?.length > 0 ? stateVars.Kuika_ItemInfoLive[0].price : null) : (this.state.Kuika_ItemInfoLive?.length > 0 ? this.state.Kuika_ItemInfoLive[0].price : null))), "number"),
				SalesDraftId_3: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toGuid(this, ReactSystemFunctions.value(this, "talepsatisislemi_337380_value", "value", "", "", "")), "Guid")
        }

		KuikaAppManager.showSpinner(this);
		
        if (true) {
        KuikaAppManager.showSpinner(this);
        }
        let result = await KuikaAppManager.ApiRequest(this, "TalepSatisIslemi/TalepSatisIslemiComponent_10440_onClick", localVar)
        if (!KMainFunctions.IsResStatus2XX(result)) return true;

			stateVars.Kuika_ItemInfoLive = result?.data.kuika_ItemInfoLive;
			stateVars.TMSalesLeadDraftAddProduct = result?.data.tmSalesLeadDraftAddProduct;
			stateVars.GetSalesLeadProduct = result?.data.getSalesLeadProduct;
			
			stateVars.isComp759176Visible = ((ReactSystemFunctions.isNotEmpty(ReactSystemFunctions.value(this, (stateVars.GetSalesLeadProduct !== undefined ? (stateVars.GetSalesLeadProduct?.length > 0 ? stateVars.GetSalesLeadProduct[0].id : null) : (this.state.GetSalesLeadProduct?.length > 0 ? this.state.GetSalesLeadProduct[0].id : null))), ReactSystemFunctions.convertToTypeByName("True", "string"))) === true ? "visible" : "hidden")
			this.props.form?.setFieldsValue(formVars);
			
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.TalepSatisIslemiComponent_10440_onClick1_();
                  resolve();
                });
          })



        
        KuikaAppManager.hideSpinner(this);
        return isErrorOccurred;
    }
    TalepSatisIslemiComponent_10440_onClick1_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
		KuikaAppManager.increaseServerRequestCount();

        let localVar = {
				SalesDraftId_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toGuid(this, ReactSystemFunctions.value(this, "talepsatisislemi_337380_value", "value", "", "", "")), "Guid")
        }

if (ReactSystemFunctions.isNotEmpty(ReactSystemFunctions.value(this, (stateVars.TMSalesLeadDraftCreate !== undefined ? (stateVars.TMSalesLeadDraftCreate?.length > 0 ? stateVars.TMSalesLeadDraftCreate[0].draftId : null) : (this.state.TMSalesLeadDraftCreate?.length > 0 ? this.state.TMSalesLeadDraftCreate[0].draftId : null))), ReactSystemFunctions.convertToTypeByName("True", "string"))) {
            		
        if (true) {
        KuikaAppManager.showSpinner(this);
        }
        let result = await KuikaAppManager.ApiRequest(this, "TalepSatisIslemi/TalepSatisIslemiComponent_10440_onClick1_", localVar)
        if (!KMainFunctions.IsResStatus2XX(result)) return true;

			stateVars.TMSalesLeadPaymentList = result?.data.tmSalesLeadPaymentList;
			
			formVars.talepsatisislemi_100771_value = ReactSystemFunctions.toString(this, (stateVars.TMSalesLeadPaymentList !== undefined ? (stateVars.TMSalesLeadPaymentList?.length > 0 ? stateVars.TMSalesLeadPaymentList[0].collectedTotalEUR : null) : (this.state.TMSalesLeadPaymentList?.length > 0 ? this.state.TMSalesLeadPaymentList[0].collectedTotalEUR : null)));
			formVars.talepsatisislemi_653586_value = ReactSystemFunctions.toString(this, (stateVars.TMSalesLeadPaymentList !== undefined ? (stateVars.TMSalesLeadPaymentList?.length > 0 ? stateVars.TMSalesLeadPaymentList[0].remainingEUR : null) : (this.state.TMSalesLeadPaymentList?.length > 0 ? this.state.TMSalesLeadPaymentList[0].remainingEUR : null)));
			stateVars.isComp1894128536Enabled = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, (stateVars.TMSalesLeadPaymentList !== undefined ? (stateVars.TMSalesLeadPaymentList?.length > 0 ? stateVars.TMSalesLeadPaymentList[0].remainingEUR : null) : (this.state.TMSalesLeadPaymentList?.length > 0 ? this.state.TMSalesLeadPaymentList[0].remainingEUR : null))), ReactSystemFunctions.convertToTypeByName("0", "string"))) === true ? "enabled" : "disabled")
			stateVars.isComp761489Enabled = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, (stateVars.TMSalesLeadPaymentList !== undefined ? (stateVars.TMSalesLeadPaymentList?.length > 0 ? stateVars.TMSalesLeadPaymentList[0].remainingEUR : null) : (this.state.TMSalesLeadPaymentList?.length > 0 ? this.state.TMSalesLeadPaymentList[0].remainingEUR : null))), ReactSystemFunctions.convertToTypeByName("0", "string"))) === true ? "enabled" : "disabled")
			this.props.form?.setFieldsValue(formVars);
			
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.TalepSatisIslemiComponent_10440_onClick2_();
                  resolve();
                });
          })

        } else {
            
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.TalepSatisIslemiComponent_10440_onClick2_();
                  resolve();
                });
          })
        }


        
        KuikaAppManager.hideSpinner(this);
        return isErrorOccurred;
    }
    TalepSatisIslemiComponent_10440_onClick2_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
		KuikaAppManager.increaseServerRequestCount();

        let localVar = {
				SalesDraftId_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toGuid(this, ReactSystemFunctions.value(this, "talepsatisislemi_337380_value", "value", "", "", "")), "Guid")
        }

		
        if (true) {
        KuikaAppManager.showSpinner(this);
        }
        let result = await KuikaAppManager.ApiRequest(this, "TalepSatisIslemi/TalepSatisIslemiComponent_10440_onClick2_", localVar)
        if (!KMainFunctions.IsResStatus2XX(result)) return true;

			stateVars.TMSalesLeadSummary = result?.data.tmSalesLeadSummary;
			formVars.talepsatisislemi_706355_value = ReactSystemFunctions.toString(this, (stateVars.TMSalesLeadSummary !== undefined ? (stateVars.TMSalesLeadSummary?.length > 0 ? stateVars.TMSalesLeadSummary[0].urunAdedi : null) : (this.state.TMSalesLeadSummary?.length > 0 ? this.state.TMSalesLeadSummary[0].urunAdedi : null)));
			formVars.talepsatisislemi_957854_value = ReactSystemFunctions.toString(this, (stateVars.TMSalesLeadSummary !== undefined ? (stateVars.TMSalesLeadSummary?.length > 0 ? stateVars.TMSalesLeadSummary[0].araToplam : null) : (this.state.TMSalesLeadSummary?.length > 0 ? this.state.TMSalesLeadSummary[0].araToplam : null)));
			formVars.talepsatisislemi_94614_value = ReactSystemFunctions.toString(this, (stateVars.TMSalesLeadSummary !== undefined ? (stateVars.TMSalesLeadSummary?.length > 0 ? stateVars.TMSalesLeadSummary[0].iskontoTutari : null) : (this.state.TMSalesLeadSummary?.length > 0 ? this.state.TMSalesLeadSummary[0].iskontoTutari : null)));
			formVars.talepsatisislemi_28476_value = ReactSystemFunctions.toString(this, (stateVars.TMSalesLeadSummary !== undefined ? (stateVars.TMSalesLeadSummary?.length > 0 ? stateVars.TMSalesLeadSummary[0].genelToplam : null) : (this.state.TMSalesLeadSummary?.length > 0 ? this.state.TMSalesLeadSummary[0].genelToplam : null)));
			formVars.talepsatisislemi_646001_value = ReactSystemFunctions.toString(this, (stateVars.TMSalesLeadSummary !== undefined ? (stateVars.TMSalesLeadSummary?.length > 0 ? stateVars.TMSalesLeadSummary[0].tahsilEdilen : null) : (this.state.TMSalesLeadSummary?.length > 0 ? this.state.TMSalesLeadSummary[0].tahsilEdilen : null)));
			formVars.talepsatisislemi_804074_value = ReactSystemFunctions.toString(this, (stateVars.TMSalesLeadSummary !== undefined ? (stateVars.TMSalesLeadSummary?.length > 0 ? stateVars.TMSalesLeadSummary[0].kalanTutar : null) : (this.state.TMSalesLeadSummary?.length > 0 ? this.state.TMSalesLeadSummary[0].kalanTutar : null)));
			this.props.form?.setFieldsValue(formVars);
			
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.TalepSatisIslemiComponent_10440_onClick3_();
                  resolve();
                });
          })



        
        KuikaAppManager.hideSpinner(this);
        return isErrorOccurred;
    }
		TalepSatisIslemiComponent_10440_onClick3_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }

				stateVars.Notify = await ReactSystemFunctions.notify(this, ReactSystemFunctions.toString(this, (stateVars.TMSalesLeadDraftAddProduct !== undefined ? (stateVars.TMSalesLeadDraftAddProduct?.length > 0 ? stateVars.TMSalesLeadDraftAddProduct[0].message : null) : (this.state.TMSalesLeadDraftAddProduct?.length > 0 ? this.state.TMSalesLeadDraftAddProduct[0].message : null))), ReactSystemFunctions.convertToTypeByName("default", "string"), ReactSystemFunctions.convertToTypeByName("bottom-right", "string"), 3, ReactSystemFunctions.convertToTypeByName("", "string"), ReactSystemFunctions.convertToTypeByName("", "string"), 0);
				stateVars.SetValueOf = await ReactSystemFunctions.setValueOf(this, ReactSystemFunctions.convertToTypeByName("talepsatisislemi_878977_value", "string"), "", null, false);
				
				stateVars.dataSource_41607 = stateVars.GetSalesLeadProduct ?? this.state.GetSalesLeadProduct;

		this.props.form?.setFieldsValue(formVars);
		
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.TalepSatisIslemiComponent_10440_onClick4_();
                  resolve();
                });
          })

            
            return isErrorOccurred;
        }
		TalepSatisIslemiComponent_10440_onClick4_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
if (ReactSystemFunctions.isNotEmpty(ReactSystemFunctions.value(this, (stateVars.TMSalesLeadDraftCreate !== undefined ? (stateVars.TMSalesLeadDraftCreate?.length > 0 ? stateVars.TMSalesLeadDraftCreate[0].draftId : null) : (this.state.TMSalesLeadDraftCreate?.length > 0 ? this.state.TMSalesLeadDraftCreate[0].draftId : null))), true)) {
            
				

		this.props.form?.setFieldsValue(formVars);
		
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.TalepSatisIslemiComponent_10440_onClick5_();
                  resolve();
                });
          })

        } else {
            
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.TalepSatisIslemiComponent_10440_onClick5_();
                  resolve();
                });
          })
        }

            
            return isErrorOccurred;
        }
		TalepSatisIslemiComponent_10440_onClick5_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
if (ReactSystemFunctions.isNotEmpty(ReactSystemFunctions.value(this, (stateVars.TMSalesLeadDraftCreate !== undefined ? (stateVars.TMSalesLeadDraftCreate?.length > 0 ? stateVars.TMSalesLeadDraftCreate[0].draftId : null) : (this.state.TMSalesLeadDraftCreate?.length > 0 ? this.state.TMSalesLeadDraftCreate[0].draftId : null))), true)) {
            
				stateVars.dataSource_466892 = stateVars.TMSalesLeadPaymentList ?? this.state.TMSalesLeadPaymentList;

		this.props.form?.setFieldsValue(formVars);
		
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.TalepSatisIslemiComponent_10440_onClick6_();
                  resolve();
                });
          })

        } else {
            
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.TalepSatisIslemiComponent_10440_onClick6_();
                  resolve();
                });
          })
        }

            
            return isErrorOccurred;
        }
		TalepSatisIslemiComponent_10440_onClick6_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
if (ReactSystemFunctions.isNotEmpty(ReactSystemFunctions.value(this, (stateVars.TMSalesLeadDraftCreate !== undefined ? (stateVars.TMSalesLeadDraftCreate?.length > 0 ? stateVars.TMSalesLeadDraftCreate[0].draftId : null) : (this.state.TMSalesLeadDraftCreate?.length > 0 ? this.state.TMSalesLeadDraftCreate[0].draftId : null))), true)) {
            
				formVars.talepsatisislemi_100771_value = ReactSystemFunctions.toString(this, (stateVars.TMSalesLeadPaymentList !== undefined ? (stateVars.TMSalesLeadPaymentList?.length > 0 ? stateVars.TMSalesLeadPaymentList[0].collectedTotalEUR : null) : (this.state.TMSalesLeadPaymentList?.length > 0 ? this.state.TMSalesLeadPaymentList[0].collectedTotalEUR : null)));


		this.props.form?.setFieldsValue(formVars);
		
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.TalepSatisIslemiComponent_10440_onClick7_();
                  resolve();
                });
          })

        } else {
            
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.TalepSatisIslemiComponent_10440_onClick7_();
                  resolve();
                });
          })
        }

            
            return isErrorOccurred;
        }
		TalepSatisIslemiComponent_10440_onClick7_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
if (ReactSystemFunctions.isNotEmpty(ReactSystemFunctions.value(this, (stateVars.TMSalesLeadDraftCreate !== undefined ? (stateVars.TMSalesLeadDraftCreate?.length > 0 ? stateVars.TMSalesLeadDraftCreate[0].draftId : null) : (this.state.TMSalesLeadDraftCreate?.length > 0 ? this.state.TMSalesLeadDraftCreate[0].draftId : null))), true)) {
            
				formVars.talepsatisislemi_653586_value = ReactSystemFunctions.toString(this, (stateVars.TMSalesLeadPaymentList !== undefined ? (stateVars.TMSalesLeadPaymentList?.length > 0 ? stateVars.TMSalesLeadPaymentList[0].remainingEUR : null) : (this.state.TMSalesLeadPaymentList?.length > 0 ? this.state.TMSalesLeadPaymentList[0].remainingEUR : null)));


		this.props.form?.setFieldsValue(formVars);
		
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.TalepSatisIslemiComponent_10440_onClick8_();
                  resolve();
                });
          })

        } else {
            
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.TalepSatisIslemiComponent_10440_onClick8_();
                  resolve();
                });
          })
        }

            
            return isErrorOccurred;
        }
		TalepSatisIslemiComponent_10440_onClick8_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }

				formVars.talepsatisislemi_706355_value = ReactSystemFunctions.toString(this, (stateVars.TMSalesLeadSummary !== undefined ? (stateVars.TMSalesLeadSummary?.length > 0 ? stateVars.TMSalesLeadSummary[0].urunAdedi : null) : (this.state.TMSalesLeadSummary?.length > 0 ? this.state.TMSalesLeadSummary[0].urunAdedi : null)));

				formVars.talepsatisislemi_957854_value = ReactSystemFunctions.toString(this, (stateVars.TMSalesLeadSummary !== undefined ? (stateVars.TMSalesLeadSummary?.length > 0 ? stateVars.TMSalesLeadSummary[0].araToplam : null) : (this.state.TMSalesLeadSummary?.length > 0 ? this.state.TMSalesLeadSummary[0].araToplam : null)));

				formVars.talepsatisislemi_94614_value = ReactSystemFunctions.toString(this, (stateVars.TMSalesLeadSummary !== undefined ? (stateVars.TMSalesLeadSummary?.length > 0 ? stateVars.TMSalesLeadSummary[0].iskontoTutari : null) : (this.state.TMSalesLeadSummary?.length > 0 ? this.state.TMSalesLeadSummary[0].iskontoTutari : null)));

				formVars.talepsatisislemi_28476_value = ReactSystemFunctions.toString(this, (stateVars.TMSalesLeadSummary !== undefined ? (stateVars.TMSalesLeadSummary?.length > 0 ? stateVars.TMSalesLeadSummary[0].genelToplam : null) : (this.state.TMSalesLeadSummary?.length > 0 ? this.state.TMSalesLeadSummary[0].genelToplam : null)));

				formVars.talepsatisislemi_646001_value = ReactSystemFunctions.toString(this, (stateVars.TMSalesLeadSummary !== undefined ? (stateVars.TMSalesLeadSummary?.length > 0 ? stateVars.TMSalesLeadSummary[0].tahsilEdilen : null) : (this.state.TMSalesLeadSummary?.length > 0 ? this.state.TMSalesLeadSummary[0].tahsilEdilen : null)));

				formVars.talepsatisislemi_804074_value = ReactSystemFunctions.toString(this, (stateVars.TMSalesLeadSummary !== undefined ? (stateVars.TMSalesLeadSummary?.length > 0 ? stateVars.TMSalesLeadSummary[0].kalanTutar : null) : (this.state.TMSalesLeadSummary?.length > 0 ? this.state.TMSalesLeadSummary[0].kalanTutar : null)));


		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

            
            return isErrorOccurred;
        }













    TalepSatisIslemiComponent_356498_onClick = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
		KuikaAppManager.increaseServerRequestCount();

        let localVar = {
				usedCode_1: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "talepsatisislemi_660424_value", "value", "", "", "")), "string"),
				wareHouseCode_1: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, (stateVars.TM_GetSalesLeadById !== undefined ? (stateVars.TM_GetSalesLeadById?.length > 0 ? stateVars.TM_GetSalesLeadById[0].wareHouseCode : null) : (this.state.TM_GetSalesLeadById?.length > 0 ? this.state.TM_GetSalesLeadById[0].wareHouseCode : null))), "string"),
				ProductCode_2: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, (stateVars.Kuika_ItemInfoLive !== undefined ? (stateVars.Kuika_ItemInfoLive?.length > 0 ? stateVars.Kuika_ItemInfoLive[0].itemCode : null) : (this.state.Kuika_ItemInfoLive?.length > 0 ? this.state.Kuika_ItemInfoLive[0].itemCode : null))), "string"),
				SalesDraftId_2: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toGuid(this, ReactSystemFunctions.value(this, "talepsatisislemi_337380_value", "value", "", "", "")), "Guid"),
				SeriNo_2: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, (stateVars.Kuika_ItemInfoLive !== undefined ? (stateVars.Kuika_ItemInfoLive?.length > 0 ? stateVars.Kuika_ItemInfoLive[0].itemSerialNumber : null) : (this.state.Kuika_ItemInfoLive?.length > 0 ? this.state.Kuika_ItemInfoLive[0].itemSerialNumber : null))), "string"),
				ProductName_2: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, (stateVars.Kuika_ItemInfoLive !== undefined ? (stateVars.Kuika_ItemInfoLive?.length > 0 ? stateVars.Kuika_ItemInfoLive[0].itemDescription : null) : (this.state.Kuika_ItemInfoLive?.length > 0 ? this.state.Kuika_ItemInfoLive[0].itemDescription : null))), "string"),
				Barcode_2: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, (stateVars.Kuika_ItemInfoLive !== undefined ? (stateVars.Kuika_ItemInfoLive?.length > 0 ? stateVars.Kuika_ItemInfoLive[0].barcode : null) : (this.state.Kuika_ItemInfoLive?.length > 0 ? this.state.Kuika_ItemInfoLive[0].barcode : null))), "string"),
				UserSerialNumber_2: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, (stateVars.Kuika_ItemInfoLive !== undefined ? (stateVars.Kuika_ItemInfoLive?.length > 0 ? stateVars.Kuika_ItemInfoLive[0].useSerialNumber : null) : (this.state.Kuika_ItemInfoLive?.length > 0 ? this.state.Kuika_ItemInfoLive[0].useSerialNumber : null))), "string"),
				Price_2: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, (stateVars.Kuika_ItemInfoLive !== undefined ? (stateVars.Kuika_ItemInfoLive?.length > 0 ? stateVars.Kuika_ItemInfoLive[0].price : null) : (this.state.Kuika_ItemInfoLive?.length > 0 ? this.state.Kuika_ItemInfoLive[0].price : null))), "number"),
				SalesDraftId_3: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toGuid(this, ReactSystemFunctions.value(this, "talepsatisislemi_337380_value", "value", "", "", "")), "Guid")
        }

		KuikaAppManager.showSpinner(this);
		
        if (true) {
        KuikaAppManager.showSpinner(this);
        }
        let result = await KuikaAppManager.ApiRequest(this, "TalepSatisIslemi/TalepSatisIslemiComponent_356498_onClick", localVar)
        if (!KMainFunctions.IsResStatus2XX(result)) return true;

			stateVars.Kuika_ItemInfoLive = result?.data.kuika_ItemInfoLive;
			stateVars.TMSalesLeadAddProductDistinctWatch = result?.data.tmSalesLeadAddProductDistinctWatch;
			stateVars.GetSalesLeadProduct = result?.data.getSalesLeadProduct;
			
			stateVars.isComp759176Visible = ((ReactSystemFunctions.isNotEmpty(ReactSystemFunctions.value(this, (stateVars.GetSalesLeadProduct !== undefined ? (stateVars.GetSalesLeadProduct?.length > 0 ? stateVars.GetSalesLeadProduct[0].id : null) : (this.state.GetSalesLeadProduct?.length > 0 ? this.state.GetSalesLeadProduct[0].id : null))), ReactSystemFunctions.convertToTypeByName("True", "string"))) === true ? "visible" : "hidden")
			this.props.form?.setFieldsValue(formVars);
			
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.TalepSatisIslemiComponent_356498_onClick1_();
                  resolve();
                });
          })



        
        KuikaAppManager.hideSpinner(this);
        return isErrorOccurred;
    }
    TalepSatisIslemiComponent_356498_onClick1_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
		KuikaAppManager.increaseServerRequestCount();

        let localVar = {
				SalesDraftId_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toGuid(this, ReactSystemFunctions.value(this, "talepsatisislemi_337380_value", "value", "", "", "")), "Guid")
        }

if (ReactSystemFunctions.isNotEmpty(ReactSystemFunctions.value(this, (stateVars.TMSalesLeadDraftCreate !== undefined ? (stateVars.TMSalesLeadDraftCreate?.length > 0 ? stateVars.TMSalesLeadDraftCreate[0].draftId : null) : (this.state.TMSalesLeadDraftCreate?.length > 0 ? this.state.TMSalesLeadDraftCreate[0].draftId : null))), ReactSystemFunctions.convertToTypeByName("True", "string"))) {
            		
        if (true) {
        KuikaAppManager.showSpinner(this);
        }
        let result = await KuikaAppManager.ApiRequest(this, "TalepSatisIslemi/TalepSatisIslemiComponent_356498_onClick1_", localVar)
        if (!KMainFunctions.IsResStatus2XX(result)) return true;

			stateVars.TMSalesLeadPaymentList = result?.data.tmSalesLeadPaymentList;
			
			formVars.talepsatisislemi_100771_value = ReactSystemFunctions.toString(this, (stateVars.TMSalesLeadPaymentList !== undefined ? (stateVars.TMSalesLeadPaymentList?.length > 0 ? stateVars.TMSalesLeadPaymentList[0].collectedTotalEUR : null) : (this.state.TMSalesLeadPaymentList?.length > 0 ? this.state.TMSalesLeadPaymentList[0].collectedTotalEUR : null)));
			formVars.talepsatisislemi_653586_value = ReactSystemFunctions.toString(this, (stateVars.TMSalesLeadPaymentList !== undefined ? (stateVars.TMSalesLeadPaymentList?.length > 0 ? stateVars.TMSalesLeadPaymentList[0].remainingEUR : null) : (this.state.TMSalesLeadPaymentList?.length > 0 ? this.state.TMSalesLeadPaymentList[0].remainingEUR : null)));
			stateVars.isComp1894128536Enabled = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, (stateVars.TMSalesLeadPaymentList !== undefined ? (stateVars.TMSalesLeadPaymentList?.length > 0 ? stateVars.TMSalesLeadPaymentList[0].remainingEUR : null) : (this.state.TMSalesLeadPaymentList?.length > 0 ? this.state.TMSalesLeadPaymentList[0].remainingEUR : null))), ReactSystemFunctions.convertToTypeByName("0", "string"))) === true ? "enabled" : "disabled")
			stateVars.isComp761489Enabled = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, (stateVars.TMSalesLeadPaymentList !== undefined ? (stateVars.TMSalesLeadPaymentList?.length > 0 ? stateVars.TMSalesLeadPaymentList[0].remainingEUR : null) : (this.state.TMSalesLeadPaymentList?.length > 0 ? this.state.TMSalesLeadPaymentList[0].remainingEUR : null))), ReactSystemFunctions.convertToTypeByName("0", "string"))) === true ? "enabled" : "disabled")
			this.props.form?.setFieldsValue(formVars);
			
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.TalepSatisIslemiComponent_356498_onClick2_();
                  resolve();
                });
          })

        } else {
            
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.TalepSatisIslemiComponent_356498_onClick2_();
                  resolve();
                });
          })
        }


        
        KuikaAppManager.hideSpinner(this);
        return isErrorOccurred;
    }
    TalepSatisIslemiComponent_356498_onClick2_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
		KuikaAppManager.increaseServerRequestCount();

        let localVar = {
				SalesDraftId_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toGuid(this, ReactSystemFunctions.value(this, "talepsatisislemi_337380_value", "value", "", "", "")), "Guid")
        }

		
        if (true) {
        KuikaAppManager.showSpinner(this);
        }
        let result = await KuikaAppManager.ApiRequest(this, "TalepSatisIslemi/TalepSatisIslemiComponent_356498_onClick2_", localVar)
        if (!KMainFunctions.IsResStatus2XX(result)) return true;

			stateVars.TMSalesLeadSummary = result?.data.tmSalesLeadSummary;
			formVars.talepsatisislemi_706355_value = ReactSystemFunctions.toString(this, (stateVars.TMSalesLeadSummary !== undefined ? (stateVars.TMSalesLeadSummary?.length > 0 ? stateVars.TMSalesLeadSummary[0].urunAdedi : null) : (this.state.TMSalesLeadSummary?.length > 0 ? this.state.TMSalesLeadSummary[0].urunAdedi : null)));
			formVars.talepsatisislemi_957854_value = ReactSystemFunctions.toString(this, (stateVars.TMSalesLeadSummary !== undefined ? (stateVars.TMSalesLeadSummary?.length > 0 ? stateVars.TMSalesLeadSummary[0].araToplam : null) : (this.state.TMSalesLeadSummary?.length > 0 ? this.state.TMSalesLeadSummary[0].araToplam : null)));
			formVars.talepsatisislemi_94614_value = ReactSystemFunctions.toString(this, (stateVars.TMSalesLeadSummary !== undefined ? (stateVars.TMSalesLeadSummary?.length > 0 ? stateVars.TMSalesLeadSummary[0].iskontoTutari : null) : (this.state.TMSalesLeadSummary?.length > 0 ? this.state.TMSalesLeadSummary[0].iskontoTutari : null)));
			formVars.talepsatisislemi_28476_value = ReactSystemFunctions.toString(this, (stateVars.TMSalesLeadSummary !== undefined ? (stateVars.TMSalesLeadSummary?.length > 0 ? stateVars.TMSalesLeadSummary[0].genelToplam : null) : (this.state.TMSalesLeadSummary?.length > 0 ? this.state.TMSalesLeadSummary[0].genelToplam : null)));
			formVars.talepsatisislemi_646001_value = ReactSystemFunctions.toString(this, (stateVars.TMSalesLeadSummary !== undefined ? (stateVars.TMSalesLeadSummary?.length > 0 ? stateVars.TMSalesLeadSummary[0].tahsilEdilen : null) : (this.state.TMSalesLeadSummary?.length > 0 ? this.state.TMSalesLeadSummary[0].tahsilEdilen : null)));
			formVars.talepsatisislemi_804074_value = ReactSystemFunctions.toString(this, (stateVars.TMSalesLeadSummary !== undefined ? (stateVars.TMSalesLeadSummary?.length > 0 ? stateVars.TMSalesLeadSummary[0].kalanTutar : null) : (this.state.TMSalesLeadSummary?.length > 0 ? this.state.TMSalesLeadSummary[0].kalanTutar : null)));
			this.props.form?.setFieldsValue(formVars);
			
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.TalepSatisIslemiComponent_356498_onClick3_();
                  resolve();
                });
          })



        
        KuikaAppManager.hideSpinner(this);
        return isErrorOccurred;
    }
		TalepSatisIslemiComponent_356498_onClick3_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }

				stateVars.SetValueOf = await ReactSystemFunctions.setValueOf(this, ReactSystemFunctions.convertToTypeByName("talepsatisislemi_660424_value", "string"), "", null, false);
				stateVars.Notify = await ReactSystemFunctions.notify(this, ReactSystemFunctions.toString(this, (stateVars.TMSalesLeadAddProductDistinctWatch !== undefined ? (stateVars.TMSalesLeadAddProductDistinctWatch?.length > 0 ? stateVars.TMSalesLeadAddProductDistinctWatch[0].message : null) : (this.state.TMSalesLeadAddProductDistinctWatch?.length > 0 ? this.state.TMSalesLeadAddProductDistinctWatch[0].message : null))), ReactSystemFunctions.convertToTypeByName("default", "string"), ReactSystemFunctions.convertToTypeByName("bottom-right", "string"), 3, ReactSystemFunctions.convertToTypeByName("", "string"), ReactSystemFunctions.convertToTypeByName("", "string"), 0);
				
				stateVars.dataSource_41607 = stateVars.GetSalesLeadProduct ?? this.state.GetSalesLeadProduct;

		this.props.form?.setFieldsValue(formVars);
		
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.TalepSatisIslemiComponent_356498_onClick4_();
                  resolve();
                });
          })

            
            return isErrorOccurred;
        }
		TalepSatisIslemiComponent_356498_onClick4_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
if (ReactSystemFunctions.isNotEmpty(ReactSystemFunctions.value(this, (stateVars.TMSalesLeadDraftCreate !== undefined ? (stateVars.TMSalesLeadDraftCreate?.length > 0 ? stateVars.TMSalesLeadDraftCreate[0].draftId : null) : (this.state.TMSalesLeadDraftCreate?.length > 0 ? this.state.TMSalesLeadDraftCreate[0].draftId : null))), true)) {
            
				

		this.props.form?.setFieldsValue(formVars);
		
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.TalepSatisIslemiComponent_356498_onClick5_();
                  resolve();
                });
          })

        } else {
            
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.TalepSatisIslemiComponent_356498_onClick5_();
                  resolve();
                });
          })
        }

            
            return isErrorOccurred;
        }
		TalepSatisIslemiComponent_356498_onClick5_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
if (ReactSystemFunctions.isNotEmpty(ReactSystemFunctions.value(this, (stateVars.TMSalesLeadDraftCreate !== undefined ? (stateVars.TMSalesLeadDraftCreate?.length > 0 ? stateVars.TMSalesLeadDraftCreate[0].draftId : null) : (this.state.TMSalesLeadDraftCreate?.length > 0 ? this.state.TMSalesLeadDraftCreate[0].draftId : null))), true)) {
            
				stateVars.dataSource_466892 = stateVars.TMSalesLeadPaymentList ?? this.state.TMSalesLeadPaymentList;

		this.props.form?.setFieldsValue(formVars);
		
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.TalepSatisIslemiComponent_356498_onClick6_();
                  resolve();
                });
          })

        } else {
            
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.TalepSatisIslemiComponent_356498_onClick6_();
                  resolve();
                });
          })
        }

            
            return isErrorOccurred;
        }
		TalepSatisIslemiComponent_356498_onClick6_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
if (ReactSystemFunctions.isNotEmpty(ReactSystemFunctions.value(this, (stateVars.TMSalesLeadDraftCreate !== undefined ? (stateVars.TMSalesLeadDraftCreate?.length > 0 ? stateVars.TMSalesLeadDraftCreate[0].draftId : null) : (this.state.TMSalesLeadDraftCreate?.length > 0 ? this.state.TMSalesLeadDraftCreate[0].draftId : null))), true)) {
            
				formVars.talepsatisislemi_100771_value = ReactSystemFunctions.toString(this, (stateVars.TMSalesLeadPaymentList !== undefined ? (stateVars.TMSalesLeadPaymentList?.length > 0 ? stateVars.TMSalesLeadPaymentList[0].collectedTotalEUR : null) : (this.state.TMSalesLeadPaymentList?.length > 0 ? this.state.TMSalesLeadPaymentList[0].collectedTotalEUR : null)));


		this.props.form?.setFieldsValue(formVars);
		
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.TalepSatisIslemiComponent_356498_onClick7_();
                  resolve();
                });
          })

        } else {
            
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.TalepSatisIslemiComponent_356498_onClick7_();
                  resolve();
                });
          })
        }

            
            return isErrorOccurred;
        }
		TalepSatisIslemiComponent_356498_onClick7_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
if (ReactSystemFunctions.isNotEmpty(ReactSystemFunctions.value(this, (stateVars.TMSalesLeadDraftCreate !== undefined ? (stateVars.TMSalesLeadDraftCreate?.length > 0 ? stateVars.TMSalesLeadDraftCreate[0].draftId : null) : (this.state.TMSalesLeadDraftCreate?.length > 0 ? this.state.TMSalesLeadDraftCreate[0].draftId : null))), true)) {
            
				formVars.talepsatisislemi_653586_value = ReactSystemFunctions.toString(this, (stateVars.TMSalesLeadPaymentList !== undefined ? (stateVars.TMSalesLeadPaymentList?.length > 0 ? stateVars.TMSalesLeadPaymentList[0].remainingEUR : null) : (this.state.TMSalesLeadPaymentList?.length > 0 ? this.state.TMSalesLeadPaymentList[0].remainingEUR : null)));


		this.props.form?.setFieldsValue(formVars);
		
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.TalepSatisIslemiComponent_356498_onClick8_();
                  resolve();
                });
          })

        } else {
            
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.TalepSatisIslemiComponent_356498_onClick8_();
                  resolve();
                });
          })
        }

            
            return isErrorOccurred;
        }
		TalepSatisIslemiComponent_356498_onClick8_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }

				formVars.talepsatisislemi_706355_value = ReactSystemFunctions.toString(this, (stateVars.TMSalesLeadSummary !== undefined ? (stateVars.TMSalesLeadSummary?.length > 0 ? stateVars.TMSalesLeadSummary[0].urunAdedi : null) : (this.state.TMSalesLeadSummary?.length > 0 ? this.state.TMSalesLeadSummary[0].urunAdedi : null)));

				formVars.talepsatisislemi_957854_value = ReactSystemFunctions.toString(this, (stateVars.TMSalesLeadSummary !== undefined ? (stateVars.TMSalesLeadSummary?.length > 0 ? stateVars.TMSalesLeadSummary[0].araToplam : null) : (this.state.TMSalesLeadSummary?.length > 0 ? this.state.TMSalesLeadSummary[0].araToplam : null)));

				formVars.talepsatisislemi_94614_value = ReactSystemFunctions.toString(this, (stateVars.TMSalesLeadSummary !== undefined ? (stateVars.TMSalesLeadSummary?.length > 0 ? stateVars.TMSalesLeadSummary[0].iskontoTutari : null) : (this.state.TMSalesLeadSummary?.length > 0 ? this.state.TMSalesLeadSummary[0].iskontoTutari : null)));

				formVars.talepsatisislemi_28476_value = ReactSystemFunctions.toString(this, (stateVars.TMSalesLeadSummary !== undefined ? (stateVars.TMSalesLeadSummary?.length > 0 ? stateVars.TMSalesLeadSummary[0].genelToplam : null) : (this.state.TMSalesLeadSummary?.length > 0 ? this.state.TMSalesLeadSummary[0].genelToplam : null)));

				formVars.talepsatisislemi_646001_value = ReactSystemFunctions.toString(this, (stateVars.TMSalesLeadSummary !== undefined ? (stateVars.TMSalesLeadSummary?.length > 0 ? stateVars.TMSalesLeadSummary[0].tahsilEdilen : null) : (this.state.TMSalesLeadSummary?.length > 0 ? this.state.TMSalesLeadSummary[0].tahsilEdilen : null)));

				formVars.talepsatisislemi_804074_value = ReactSystemFunctions.toString(this, (stateVars.TMSalesLeadSummary !== undefined ? (stateVars.TMSalesLeadSummary?.length > 0 ? stateVars.TMSalesLeadSummary[0].kalanTutar : null) : (this.state.TMSalesLeadSummary?.length > 0 ? this.state.TMSalesLeadSummary[0].kalanTutar : null)));


		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

            
            return isErrorOccurred;
        }













    TalepSatisIslemiComponent_863666_onBlur = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
		KuikaAppManager.increaseServerRequestCount();

        let localVar = {
				DraftDetailId_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, "talepsatisislemi_41607_value", "id"), "Guid"),
				DiscountRate_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "Table_41607_discountRate", "value", "", "", "")), "number"),
				SalesDraftId_1: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toGuid(this, ReactSystemFunctions.value(this, "talepsatisislemi_337380_value", "value", "", "", "")), "Guid"),
				SalesDraftId_2: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toGuid(this, ReactSystemFunctions.value(this, "talepsatisislemi_337380_value", "value", "", "", "")), "Guid"),
				SalesDraftId_3: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toGuid(this, ReactSystemFunctions.value(this, "talepsatisislemi_337380_value", "value", "", "", "")), "Guid")
        }

		KuikaAppManager.showSpinner(this);
		
        if (true) {
        KuikaAppManager.showSpinner(this);
        }
        let result = await KuikaAppManager.ApiRequest(this, "TalepSatisIslemi/TalepSatisIslemiComponent_863666_onBlur", localVar)
        if (!KMainFunctions.IsResStatus2XX(result)) return true;

			stateVars.TMIskontoAdd = result?.data.tmIskontoAdd;
			stateVars.GetSalesLeadProduct = result?.data.getSalesLeadProduct;
			
			stateVars.isComp759176Visible = ((ReactSystemFunctions.isNotEmpty(ReactSystemFunctions.value(this, (stateVars.GetSalesLeadProduct !== undefined ? (stateVars.GetSalesLeadProduct?.length > 0 ? stateVars.GetSalesLeadProduct[0].id : null) : (this.state.GetSalesLeadProduct?.length > 0 ? this.state.GetSalesLeadProduct[0].id : null))), ReactSystemFunctions.convertToTypeByName("True", "string"))) === true ? "visible" : "hidden")
			stateVars.TMSalesLeadPaymentList = result?.data.tmSalesLeadPaymentList;
			
			formVars.talepsatisislemi_100771_value = ReactSystemFunctions.toString(this, (stateVars.TMSalesLeadPaymentList !== undefined ? (stateVars.TMSalesLeadPaymentList?.length > 0 ? stateVars.TMSalesLeadPaymentList[0].collectedTotalEUR : null) : (this.state.TMSalesLeadPaymentList?.length > 0 ? this.state.TMSalesLeadPaymentList[0].collectedTotalEUR : null)));
			formVars.talepsatisislemi_653586_value = ReactSystemFunctions.toString(this, (stateVars.TMSalesLeadPaymentList !== undefined ? (stateVars.TMSalesLeadPaymentList?.length > 0 ? stateVars.TMSalesLeadPaymentList[0].remainingEUR : null) : (this.state.TMSalesLeadPaymentList?.length > 0 ? this.state.TMSalesLeadPaymentList[0].remainingEUR : null)));
			stateVars.isComp1894128536Enabled = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, (stateVars.TMSalesLeadPaymentList !== undefined ? (stateVars.TMSalesLeadPaymentList?.length > 0 ? stateVars.TMSalesLeadPaymentList[0].remainingEUR : null) : (this.state.TMSalesLeadPaymentList?.length > 0 ? this.state.TMSalesLeadPaymentList[0].remainingEUR : null))), ReactSystemFunctions.convertToTypeByName("0", "string"))) === true ? "enabled" : "disabled")
			stateVars.isComp761489Enabled = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, (stateVars.TMSalesLeadPaymentList !== undefined ? (stateVars.TMSalesLeadPaymentList?.length > 0 ? stateVars.TMSalesLeadPaymentList[0].remainingEUR : null) : (this.state.TMSalesLeadPaymentList?.length > 0 ? this.state.TMSalesLeadPaymentList[0].remainingEUR : null))), ReactSystemFunctions.convertToTypeByName("0", "string"))) === true ? "enabled" : "disabled")
			stateVars.TMSalesLeadSummary = result?.data.tmSalesLeadSummary;
			formVars.talepsatisislemi_706355_value = ReactSystemFunctions.toString(this, (stateVars.TMSalesLeadSummary !== undefined ? (stateVars.TMSalesLeadSummary?.length > 0 ? stateVars.TMSalesLeadSummary[0].urunAdedi : null) : (this.state.TMSalesLeadSummary?.length > 0 ? this.state.TMSalesLeadSummary[0].urunAdedi : null)));
			formVars.talepsatisislemi_957854_value = ReactSystemFunctions.toString(this, (stateVars.TMSalesLeadSummary !== undefined ? (stateVars.TMSalesLeadSummary?.length > 0 ? stateVars.TMSalesLeadSummary[0].araToplam : null) : (this.state.TMSalesLeadSummary?.length > 0 ? this.state.TMSalesLeadSummary[0].araToplam : null)));
			formVars.talepsatisislemi_94614_value = ReactSystemFunctions.toString(this, (stateVars.TMSalesLeadSummary !== undefined ? (stateVars.TMSalesLeadSummary?.length > 0 ? stateVars.TMSalesLeadSummary[0].iskontoTutari : null) : (this.state.TMSalesLeadSummary?.length > 0 ? this.state.TMSalesLeadSummary[0].iskontoTutari : null)));
			formVars.talepsatisislemi_28476_value = ReactSystemFunctions.toString(this, (stateVars.TMSalesLeadSummary !== undefined ? (stateVars.TMSalesLeadSummary?.length > 0 ? stateVars.TMSalesLeadSummary[0].genelToplam : null) : (this.state.TMSalesLeadSummary?.length > 0 ? this.state.TMSalesLeadSummary[0].genelToplam : null)));
			formVars.talepsatisislemi_646001_value = ReactSystemFunctions.toString(this, (stateVars.TMSalesLeadSummary !== undefined ? (stateVars.TMSalesLeadSummary?.length > 0 ? stateVars.TMSalesLeadSummary[0].tahsilEdilen : null) : (this.state.TMSalesLeadSummary?.length > 0 ? this.state.TMSalesLeadSummary[0].tahsilEdilen : null)));
			formVars.talepsatisislemi_804074_value = ReactSystemFunctions.toString(this, (stateVars.TMSalesLeadSummary !== undefined ? (stateVars.TMSalesLeadSummary?.length > 0 ? stateVars.TMSalesLeadSummary[0].kalanTutar : null) : (this.state.TMSalesLeadSummary?.length > 0 ? this.state.TMSalesLeadSummary[0].kalanTutar : null)));
			this.props.form?.setFieldsValue(formVars);
			
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.TalepSatisIslemiComponent_863666_onBlur1_();
                  resolve();
                });
          })



        
        KuikaAppManager.hideSpinner(this);
        return isErrorOccurred;
    }
		TalepSatisIslemiComponent_863666_onBlur1_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }

				stateVars.Notify = await ReactSystemFunctions.notify(this, ReactSystemFunctions.toString(this, (stateVars.TMIskontoAdd !== undefined ? (stateVars.TMIskontoAdd?.length > 0 ? stateVars.TMIskontoAdd[0].message : null) : (this.state.TMIskontoAdd?.length > 0 ? this.state.TMIskontoAdd[0].message : null))), ReactSystemFunctions.convertToTypeByName("default", "string"), ReactSystemFunctions.convertToTypeByName("bottom-right", "string"), 2, ReactSystemFunctions.convertToTypeByName("", "string"), ReactSystemFunctions.convertToTypeByName("", "string"), 0);
				
				stateVars.dataSource_41607 = stateVars.GetSalesLeadProduct ?? this.state.GetSalesLeadProduct;
				
				stateVars.dataSource_466892 = stateVars.TMSalesLeadPaymentList ?? this.state.TMSalesLeadPaymentList;
				formVars.talepsatisislemi_100771_value = ReactSystemFunctions.toString(this, (stateVars.TMSalesLeadPaymentList !== undefined ? (stateVars.TMSalesLeadPaymentList?.length > 0 ? stateVars.TMSalesLeadPaymentList[0].collectedTotalEUR : null) : (this.state.TMSalesLeadPaymentList?.length > 0 ? this.state.TMSalesLeadPaymentList[0].collectedTotalEUR : null)));

				formVars.talepsatisislemi_653586_value = ReactSystemFunctions.toString(this, (stateVars.TMSalesLeadPaymentList !== undefined ? (stateVars.TMSalesLeadPaymentList?.length > 0 ? stateVars.TMSalesLeadPaymentList[0].remainingEUR : null) : (this.state.TMSalesLeadPaymentList?.length > 0 ? this.state.TMSalesLeadPaymentList[0].remainingEUR : null)));

				formVars.talepsatisislemi_706355_value = ReactSystemFunctions.toString(this, (stateVars.TMSalesLeadSummary !== undefined ? (stateVars.TMSalesLeadSummary?.length > 0 ? stateVars.TMSalesLeadSummary[0].urunAdedi : null) : (this.state.TMSalesLeadSummary?.length > 0 ? this.state.TMSalesLeadSummary[0].urunAdedi : null)));

				formVars.talepsatisislemi_957854_value = ReactSystemFunctions.toString(this, (stateVars.TMSalesLeadSummary !== undefined ? (stateVars.TMSalesLeadSummary?.length > 0 ? stateVars.TMSalesLeadSummary[0].araToplam : null) : (this.state.TMSalesLeadSummary?.length > 0 ? this.state.TMSalesLeadSummary[0].araToplam : null)));

				formVars.talepsatisislemi_94614_value = ReactSystemFunctions.toString(this, (stateVars.TMSalesLeadSummary !== undefined ? (stateVars.TMSalesLeadSummary?.length > 0 ? stateVars.TMSalesLeadSummary[0].iskontoTutari : null) : (this.state.TMSalesLeadSummary?.length > 0 ? this.state.TMSalesLeadSummary[0].iskontoTutari : null)));

				formVars.talepsatisislemi_28476_value = ReactSystemFunctions.toString(this, (stateVars.TMSalesLeadSummary !== undefined ? (stateVars.TMSalesLeadSummary?.length > 0 ? stateVars.TMSalesLeadSummary[0].genelToplam : null) : (this.state.TMSalesLeadSummary?.length > 0 ? this.state.TMSalesLeadSummary[0].genelToplam : null)));

				formVars.talepsatisislemi_646001_value = ReactSystemFunctions.toString(this, (stateVars.TMSalesLeadSummary !== undefined ? (stateVars.TMSalesLeadSummary?.length > 0 ? stateVars.TMSalesLeadSummary[0].tahsilEdilen : null) : (this.state.TMSalesLeadSummary?.length > 0 ? this.state.TMSalesLeadSummary[0].tahsilEdilen : null)));

				formVars.talepsatisislemi_804074_value = ReactSystemFunctions.toString(this, (stateVars.TMSalesLeadSummary !== undefined ? (stateVars.TMSalesLeadSummary?.length > 0 ? stateVars.TMSalesLeadSummary[0].kalanTutar : null) : (this.state.TMSalesLeadSummary?.length > 0 ? this.state.TMSalesLeadSummary[0].kalanTutar : null)));


		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

            
            return isErrorOccurred;
        }




    TalepSatisIslemiComponent_752398_onClick = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
		KuikaAppManager.increaseServerRequestCount();

        let localVar = {
				DraftDetailId_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, "talepsatisislemi_41607_value", "id"), "Guid"),
				SalesDraftId_1: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toGuid(this, ReactSystemFunctions.value(this, "talepsatisislemi_337380_value", "value", "", "", "")), "Guid"),
				SalesDraftId_2: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toGuid(this, ReactSystemFunctions.value(this, "talepsatisislemi_337380_value", "value", "", "", "")), "Guid")
        }

		KuikaAppManager.showSpinner(this);
		
        if (true) {
        KuikaAppManager.showSpinner(this);
        }
        let result = await KuikaAppManager.ApiRequest(this, "TalepSatisIslemi/TalepSatisIslemiComponent_752398_onClick", localVar)
        if (!KMainFunctions.IsResStatus2XX(result)) return true;

			stateVars.TMSalesLeadProductDelete = result?.data.tmSalesLeadProductDelete;
			stateVars.GetSalesLeadProduct = result?.data.getSalesLeadProduct;
			
			stateVars.isComp759176Visible = ((ReactSystemFunctions.isNotEmpty(ReactSystemFunctions.value(this, (stateVars.GetSalesLeadProduct !== undefined ? (stateVars.GetSalesLeadProduct?.length > 0 ? stateVars.GetSalesLeadProduct[0].id : null) : (this.state.GetSalesLeadProduct?.length > 0 ? this.state.GetSalesLeadProduct[0].id : null))), ReactSystemFunctions.convertToTypeByName("True", "string"))) === true ? "visible" : "hidden")
			stateVars.TMSalesLeadPaymentList = result?.data.tmSalesLeadPaymentList;
			
			formVars.talepsatisislemi_100771_value = ReactSystemFunctions.toString(this, (stateVars.TMSalesLeadPaymentList !== undefined ? (stateVars.TMSalesLeadPaymentList?.length > 0 ? stateVars.TMSalesLeadPaymentList[0].collectedTotalEUR : null) : (this.state.TMSalesLeadPaymentList?.length > 0 ? this.state.TMSalesLeadPaymentList[0].collectedTotalEUR : null)));
			formVars.talepsatisislemi_653586_value = ReactSystemFunctions.toString(this, (stateVars.TMSalesLeadPaymentList !== undefined ? (stateVars.TMSalesLeadPaymentList?.length > 0 ? stateVars.TMSalesLeadPaymentList[0].remainingEUR : null) : (this.state.TMSalesLeadPaymentList?.length > 0 ? this.state.TMSalesLeadPaymentList[0].remainingEUR : null)));
			stateVars.isComp1894128536Enabled = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, (stateVars.TMSalesLeadPaymentList !== undefined ? (stateVars.TMSalesLeadPaymentList?.length > 0 ? stateVars.TMSalesLeadPaymentList[0].remainingEUR : null) : (this.state.TMSalesLeadPaymentList?.length > 0 ? this.state.TMSalesLeadPaymentList[0].remainingEUR : null))), ReactSystemFunctions.convertToTypeByName("0", "string"))) === true ? "enabled" : "disabled")
			stateVars.isComp761489Enabled = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, (stateVars.TMSalesLeadPaymentList !== undefined ? (stateVars.TMSalesLeadPaymentList?.length > 0 ? stateVars.TMSalesLeadPaymentList[0].remainingEUR : null) : (this.state.TMSalesLeadPaymentList?.length > 0 ? this.state.TMSalesLeadPaymentList[0].remainingEUR : null))), ReactSystemFunctions.convertToTypeByName("0", "string"))) === true ? "enabled" : "disabled")
			this.props.form?.setFieldsValue(formVars);
			
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.TalepSatisIslemiComponent_752398_onClick1_();
                  resolve();
                });
          })



        
        KuikaAppManager.hideSpinner(this);
        return isErrorOccurred;
    }
		TalepSatisIslemiComponent_752398_onClick1_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }

				stateVars.Notify = await ReactSystemFunctions.notify(this, ReactSystemFunctions.toString(this, (stateVars.TMSalesLeadProductDelete !== undefined ? (stateVars.TMSalesLeadProductDelete?.length > 0 ? stateVars.TMSalesLeadProductDelete[0].message : null) : (this.state.TMSalesLeadProductDelete?.length > 0 ? this.state.TMSalesLeadProductDelete[0].message : null))), ReactSystemFunctions.convertToTypeByName("default", "string"), ReactSystemFunctions.convertToTypeByName("bottom-right", "string"), 2, ReactSystemFunctions.convertToTypeByName("", "string"), ReactSystemFunctions.convertToTypeByName("", "string"), 0);

		this.props.form?.setFieldsValue(formVars);
		
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.TalepSatisIslemiComponent_752398_onClick2_();
                  resolve();
                });
          })

            
            return isErrorOccurred;
        }
    TalepSatisIslemiComponent_752398_onClick2_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
		KuikaAppManager.increaseServerRequestCount();

        let localVar = {
				SalesDraftId_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toGuid(this, ReactSystemFunctions.value(this, "talepsatisislemi_337380_value", "value", "", "", "")), "Guid")
        }

		
        if (true) {
        KuikaAppManager.showSpinner(this);
        }
        let result = await KuikaAppManager.ApiRequest(this, "TalepSatisIslemi/TalepSatisIslemiComponent_752398_onClick2_", localVar)
        if (!KMainFunctions.IsResStatus2XX(result)) return true;

			stateVars.TMSalesLeadSummary = result?.data.tmSalesLeadSummary;
			formVars.talepsatisislemi_706355_value = ReactSystemFunctions.toString(this, (stateVars.TMSalesLeadSummary !== undefined ? (stateVars.TMSalesLeadSummary?.length > 0 ? stateVars.TMSalesLeadSummary[0].urunAdedi : null) : (this.state.TMSalesLeadSummary?.length > 0 ? this.state.TMSalesLeadSummary[0].urunAdedi : null)));
			formVars.talepsatisislemi_957854_value = ReactSystemFunctions.toString(this, (stateVars.TMSalesLeadSummary !== undefined ? (stateVars.TMSalesLeadSummary?.length > 0 ? stateVars.TMSalesLeadSummary[0].araToplam : null) : (this.state.TMSalesLeadSummary?.length > 0 ? this.state.TMSalesLeadSummary[0].araToplam : null)));
			formVars.talepsatisislemi_94614_value = ReactSystemFunctions.toString(this, (stateVars.TMSalesLeadSummary !== undefined ? (stateVars.TMSalesLeadSummary?.length > 0 ? stateVars.TMSalesLeadSummary[0].iskontoTutari : null) : (this.state.TMSalesLeadSummary?.length > 0 ? this.state.TMSalesLeadSummary[0].iskontoTutari : null)));
			formVars.talepsatisislemi_28476_value = ReactSystemFunctions.toString(this, (stateVars.TMSalesLeadSummary !== undefined ? (stateVars.TMSalesLeadSummary?.length > 0 ? stateVars.TMSalesLeadSummary[0].genelToplam : null) : (this.state.TMSalesLeadSummary?.length > 0 ? this.state.TMSalesLeadSummary[0].genelToplam : null)));
			formVars.talepsatisislemi_646001_value = ReactSystemFunctions.toString(this, (stateVars.TMSalesLeadSummary !== undefined ? (stateVars.TMSalesLeadSummary?.length > 0 ? stateVars.TMSalesLeadSummary[0].tahsilEdilen : null) : (this.state.TMSalesLeadSummary?.length > 0 ? this.state.TMSalesLeadSummary[0].tahsilEdilen : null)));
			formVars.talepsatisislemi_804074_value = ReactSystemFunctions.toString(this, (stateVars.TMSalesLeadSummary !== undefined ? (stateVars.TMSalesLeadSummary?.length > 0 ? stateVars.TMSalesLeadSummary[0].kalanTutar : null) : (this.state.TMSalesLeadSummary?.length > 0 ? this.state.TMSalesLeadSummary[0].kalanTutar : null)));
			this.props.form?.setFieldsValue(formVars);
			
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.TalepSatisIslemiComponent_752398_onClick3_();
                  resolve();
                });
          })



        
        KuikaAppManager.hideSpinner(this);
        return isErrorOccurred;
    }
		TalepSatisIslemiComponent_752398_onClick3_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }

				
				stateVars.dataSource_41607 = stateVars.GetSalesLeadProduct ?? this.state.GetSalesLeadProduct;
				
				stateVars.dataSource_466892 = stateVars.TMSalesLeadPaymentList ?? this.state.TMSalesLeadPaymentList;
				formVars.talepsatisislemi_100771_value = ReactSystemFunctions.toString(this, (stateVars.TMSalesLeadPaymentList !== undefined ? (stateVars.TMSalesLeadPaymentList?.length > 0 ? stateVars.TMSalesLeadPaymentList[0].collectedTotalEUR : null) : (this.state.TMSalesLeadPaymentList?.length > 0 ? this.state.TMSalesLeadPaymentList[0].collectedTotalEUR : null)));

				formVars.talepsatisislemi_653586_value = ReactSystemFunctions.toString(this, (stateVars.TMSalesLeadPaymentList !== undefined ? (stateVars.TMSalesLeadPaymentList?.length > 0 ? stateVars.TMSalesLeadPaymentList[0].remainingEUR : null) : (this.state.TMSalesLeadPaymentList?.length > 0 ? this.state.TMSalesLeadPaymentList[0].remainingEUR : null)));

				formVars.talepsatisislemi_706355_value = ReactSystemFunctions.toString(this, (stateVars.TMSalesLeadSummary !== undefined ? (stateVars.TMSalesLeadSummary?.length > 0 ? stateVars.TMSalesLeadSummary[0].urunAdedi : null) : (this.state.TMSalesLeadSummary?.length > 0 ? this.state.TMSalesLeadSummary[0].urunAdedi : null)));

				formVars.talepsatisislemi_957854_value = ReactSystemFunctions.toString(this, (stateVars.TMSalesLeadSummary !== undefined ? (stateVars.TMSalesLeadSummary?.length > 0 ? stateVars.TMSalesLeadSummary[0].araToplam : null) : (this.state.TMSalesLeadSummary?.length > 0 ? this.state.TMSalesLeadSummary[0].araToplam : null)));

				formVars.talepsatisislemi_94614_value = ReactSystemFunctions.toString(this, (stateVars.TMSalesLeadSummary !== undefined ? (stateVars.TMSalesLeadSummary?.length > 0 ? stateVars.TMSalesLeadSummary[0].iskontoTutari : null) : (this.state.TMSalesLeadSummary?.length > 0 ? this.state.TMSalesLeadSummary[0].iskontoTutari : null)));

				formVars.talepsatisislemi_28476_value = ReactSystemFunctions.toString(this, (stateVars.TMSalesLeadSummary !== undefined ? (stateVars.TMSalesLeadSummary?.length > 0 ? stateVars.TMSalesLeadSummary[0].genelToplam : null) : (this.state.TMSalesLeadSummary?.length > 0 ? this.state.TMSalesLeadSummary[0].genelToplam : null)));

				formVars.talepsatisislemi_646001_value = ReactSystemFunctions.toString(this, (stateVars.TMSalesLeadSummary !== undefined ? (stateVars.TMSalesLeadSummary?.length > 0 ? stateVars.TMSalesLeadSummary[0].tahsilEdilen : null) : (this.state.TMSalesLeadSummary?.length > 0 ? this.state.TMSalesLeadSummary[0].tahsilEdilen : null)));

				formVars.talepsatisislemi_804074_value = ReactSystemFunctions.toString(this, (stateVars.TMSalesLeadSummary !== undefined ? (stateVars.TMSalesLeadSummary?.length > 0 ? stateVars.TMSalesLeadSummary[0].kalanTutar : null) : (this.state.TMSalesLeadSummary?.length > 0 ? this.state.TMSalesLeadSummary[0].kalanTutar : null)));


		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

            
            return isErrorOccurred;
        }







    TalepSatisIslemiComponent_831595_onChange = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
		KuikaAppManager.increaseServerRequestCount();

        let localVar = {
				PaymentType_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toInteger(this, ReactSystemFunctions.value(this, "talepsatisislemi_831595_value", "value", "", "key", "")), "number"),
				OfficeCode_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, (stateVars.TM_GetSalesLeadById !== undefined ? (stateVars.TM_GetSalesLeadById?.length > 0 ? stateVars.TM_GetSalesLeadById[0].officeCode : null) : (this.state.TM_GetSalesLeadById?.length > 0 ? this.state.TM_GetSalesLeadById[0].officeCode : null))), "string")
        }

		KuikaAppManager.showSpinner(this);
		
        if (true) {
        KuikaAppManager.showSpinner(this);
        }
        let result = await KuikaAppManager.ApiRequest(this, "TalepSatisIslemi/TalepSatisIslemiComponent_831595_onChange", localVar)
        if (!KMainFunctions.IsResStatus2XX(result)) return true;

			stateVars.TMSalesPaymentType = result?.data.tmSalesPaymentType;
			
			formVars.talepsatisislemi_859085_options = stateVars.TMSalesPaymentType;
			this.props.form?.setFieldsValue(formVars);
			
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.TalepSatisIslemiComponent_831595_onChange1_();
                  resolve();
                });
          })



        
        KuikaAppManager.hideSpinner(this);
        return isErrorOccurred;
    }
		TalepSatisIslemiComponent_831595_onChange1_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }

				
				stateVars.dataSource_859085 = stateVars.TMSalesPaymentType ?? this.state.TMSalesPaymentType;
				stateVars.dataSource_859085 = stateVars.TMSalesPaymentType ?? this.state.TMSalesPaymentType;
				stateVars.isComp281463Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "talepsatisislemi_831595_value", "value", "", "key", "")), ReactSystemFunctions.convertToTypeByName("2", "string"))) === true ? "visible" : "hidden")

		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

            
            return isErrorOccurred;
        }




    TalepSatisIslemiComponent_358141_onClick = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
		KuikaAppManager.increaseServerRequestCount();

        let localVar = {
				PaymentType_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "talepsatisislemi_859085_value", "value", "TMSalesPaymentType", "id", "paymentType")), "string"),
				CurrencyCode_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "talepsatisislemi_859085_value", "value", "TMSalesPaymentType", "id", "currencyCode")), "string"),
				SalesDraftId_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toGuid(this, ReactSystemFunctions.value(this, "talepsatisislemi_337380_value", "value", "", "", "")), "Guid"),
				CurrencyId_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "talepsatisislemi_859085_value", "value", "TMSalesPaymentType", "id", "id")), "Guid"),
				Doviz_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "talepsatisislemi_682853634_value", "value", "", "key", "")), "string"),
				PaymentTypeDesc_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "talepsatisislemi_859085_value", "value", "TMSalesPaymentType", "id", "paymentTypeDesc")), "string")
        }

		KuikaAppManager.showSpinner(this);
		
        if (true) {
        KuikaAppManager.showSpinner(this);
        }
        let result = await KuikaAppManager.ApiRequest(this, "TalepSatisIslemi/TalepSatisIslemiComponent_358141_onClick", localVar)
        if (!KMainFunctions.IsResStatus2XX(result)) return true;

			stateVars.TMAddSalesLeadPayment = result?.data.tmAddSalesLeadPayment;
			this.props.form?.setFieldsValue(formVars);
			
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.TalepSatisIslemiComponent_358141_onClick1_();
                  resolve();
                });
          })



        
        KuikaAppManager.hideSpinner(this);
        return isErrorOccurred;
    }
    TalepSatisIslemiComponent_358141_onClick1_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
		KuikaAppManager.increaseServerRequestCount();

        let localVar = {
				SalesDraftId_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toGuid(this, ReactSystemFunctions.value(this, "talepsatisislemi_337380_value", "value", "", "", "")), "Guid")
        }

if (ReactSystemFunctions.isNotEmpty(ReactSystemFunctions.value(this, (stateVars.TMSalesLeadDraftCreate !== undefined ? (stateVars.TMSalesLeadDraftCreate?.length > 0 ? stateVars.TMSalesLeadDraftCreate[0].draftId : null) : (this.state.TMSalesLeadDraftCreate?.length > 0 ? this.state.TMSalesLeadDraftCreate[0].draftId : null))), ReactSystemFunctions.convertToTypeByName("True", "string"))) {
            		
        if (true) {
        KuikaAppManager.showSpinner(this);
        }
        let result = await KuikaAppManager.ApiRequest(this, "TalepSatisIslemi/TalepSatisIslemiComponent_358141_onClick1_", localVar)
        if (!KMainFunctions.IsResStatus2XX(result)) return true;

			stateVars.TMSalesLeadPaymentList = result?.data.tmSalesLeadPaymentList;
			
			formVars.talepsatisislemi_100771_value = ReactSystemFunctions.toString(this, (stateVars.TMSalesLeadPaymentList !== undefined ? (stateVars.TMSalesLeadPaymentList?.length > 0 ? stateVars.TMSalesLeadPaymentList[0].collectedTotalEUR : null) : (this.state.TMSalesLeadPaymentList?.length > 0 ? this.state.TMSalesLeadPaymentList[0].collectedTotalEUR : null)));
			formVars.talepsatisislemi_653586_value = ReactSystemFunctions.toString(this, (stateVars.TMSalesLeadPaymentList !== undefined ? (stateVars.TMSalesLeadPaymentList?.length > 0 ? stateVars.TMSalesLeadPaymentList[0].remainingEUR : null) : (this.state.TMSalesLeadPaymentList?.length > 0 ? this.state.TMSalesLeadPaymentList[0].remainingEUR : null)));
			stateVars.isComp1894128536Enabled = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, (stateVars.TMSalesLeadPaymentList !== undefined ? (stateVars.TMSalesLeadPaymentList?.length > 0 ? stateVars.TMSalesLeadPaymentList[0].remainingEUR : null) : (this.state.TMSalesLeadPaymentList?.length > 0 ? this.state.TMSalesLeadPaymentList[0].remainingEUR : null))), ReactSystemFunctions.convertToTypeByName("0", "string"))) === true ? "enabled" : "disabled")
			stateVars.isComp761489Enabled = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, (stateVars.TMSalesLeadPaymentList !== undefined ? (stateVars.TMSalesLeadPaymentList?.length > 0 ? stateVars.TMSalesLeadPaymentList[0].remainingEUR : null) : (this.state.TMSalesLeadPaymentList?.length > 0 ? this.state.TMSalesLeadPaymentList[0].remainingEUR : null))), ReactSystemFunctions.convertToTypeByName("0", "string"))) === true ? "enabled" : "disabled")
			this.props.form?.setFieldsValue(formVars);
			
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.TalepSatisIslemiComponent_358141_onClick2_();
                  resolve();
                });
          })

        } else {
            
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.TalepSatisIslemiComponent_358141_onClick2_();
                  resolve();
                });
          })
        }


        
        KuikaAppManager.hideSpinner(this);
        return isErrorOccurred;
    }
    TalepSatisIslemiComponent_358141_onClick2_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
		KuikaAppManager.increaseServerRequestCount();

        let localVar = {
				SalesDraftId_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toGuid(this, ReactSystemFunctions.value(this, "talepsatisislemi_337380_value", "value", "", "", "")), "Guid")
        }

		
        if (true) {
        KuikaAppManager.showSpinner(this);
        }
        let result = await KuikaAppManager.ApiRequest(this, "TalepSatisIslemi/TalepSatisIslemiComponent_358141_onClick2_", localVar)
        if (!KMainFunctions.IsResStatus2XX(result)) return true;

			stateVars.TMSalesLeadSummary = result?.data.tmSalesLeadSummary;
			formVars.talepsatisislemi_706355_value = ReactSystemFunctions.toString(this, (stateVars.TMSalesLeadSummary !== undefined ? (stateVars.TMSalesLeadSummary?.length > 0 ? stateVars.TMSalesLeadSummary[0].urunAdedi : null) : (this.state.TMSalesLeadSummary?.length > 0 ? this.state.TMSalesLeadSummary[0].urunAdedi : null)));
			formVars.talepsatisislemi_957854_value = ReactSystemFunctions.toString(this, (stateVars.TMSalesLeadSummary !== undefined ? (stateVars.TMSalesLeadSummary?.length > 0 ? stateVars.TMSalesLeadSummary[0].araToplam : null) : (this.state.TMSalesLeadSummary?.length > 0 ? this.state.TMSalesLeadSummary[0].araToplam : null)));
			formVars.talepsatisislemi_94614_value = ReactSystemFunctions.toString(this, (stateVars.TMSalesLeadSummary !== undefined ? (stateVars.TMSalesLeadSummary?.length > 0 ? stateVars.TMSalesLeadSummary[0].iskontoTutari : null) : (this.state.TMSalesLeadSummary?.length > 0 ? this.state.TMSalesLeadSummary[0].iskontoTutari : null)));
			formVars.talepsatisislemi_28476_value = ReactSystemFunctions.toString(this, (stateVars.TMSalesLeadSummary !== undefined ? (stateVars.TMSalesLeadSummary?.length > 0 ? stateVars.TMSalesLeadSummary[0].genelToplam : null) : (this.state.TMSalesLeadSummary?.length > 0 ? this.state.TMSalesLeadSummary[0].genelToplam : null)));
			formVars.talepsatisislemi_646001_value = ReactSystemFunctions.toString(this, (stateVars.TMSalesLeadSummary !== undefined ? (stateVars.TMSalesLeadSummary?.length > 0 ? stateVars.TMSalesLeadSummary[0].tahsilEdilen : null) : (this.state.TMSalesLeadSummary?.length > 0 ? this.state.TMSalesLeadSummary[0].tahsilEdilen : null)));
			formVars.talepsatisislemi_804074_value = ReactSystemFunctions.toString(this, (stateVars.TMSalesLeadSummary !== undefined ? (stateVars.TMSalesLeadSummary?.length > 0 ? stateVars.TMSalesLeadSummary[0].kalanTutar : null) : (this.state.TMSalesLeadSummary?.length > 0 ? this.state.TMSalesLeadSummary[0].kalanTutar : null)));
			this.props.form?.setFieldsValue(formVars);
			
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.TalepSatisIslemiComponent_358141_onClick3_();
                  resolve();
                });
          })



        
        KuikaAppManager.hideSpinner(this);
        return isErrorOccurred;
    }
		TalepSatisIslemiComponent_358141_onClick3_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }

				stateVars.Notify = await ReactSystemFunctions.notify(this, ReactSystemFunctions.toString(this, (stateVars.TMAddSalesLeadPayment !== undefined ? (stateVars.TMAddSalesLeadPayment?.length > 0 ? stateVars.TMAddSalesLeadPayment[0].message : null) : (this.state.TMAddSalesLeadPayment?.length > 0 ? this.state.TMAddSalesLeadPayment[0].message : null))), ReactSystemFunctions.convertToTypeByName("default", "string"), ReactSystemFunctions.convertToTypeByName("bottom-right", "string"), 3, ReactSystemFunctions.convertToTypeByName("", "string"), ReactSystemFunctions.convertToTypeByName("", "string"), 0);
				stateVars.SetValueOf = await ReactSystemFunctions.setValueOf(this, ReactSystemFunctions.convertToTypeByName("talepsatisislemi_831595_value", "string"), "", null, "Key");
				stateVars.SetValueOf = await ReactSystemFunctions.setValueOf(this, ReactSystemFunctions.convertToTypeByName("talepsatisislemi_859085_value", "string"), "", null, "Id");

		this.props.form?.setFieldsValue(formVars);
		
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.TalepSatisIslemiComponent_358141_onClick4_();
                  resolve();
                });
          })

            
            return isErrorOccurred;
        }
		TalepSatisIslemiComponent_358141_onClick4_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
if (ReactSystemFunctions.isNotEmpty(ReactSystemFunctions.value(this, (stateVars.TMSalesLeadDraftCreate !== undefined ? (stateVars.TMSalesLeadDraftCreate?.length > 0 ? stateVars.TMSalesLeadDraftCreate[0].draftId : null) : (this.state.TMSalesLeadDraftCreate?.length > 0 ? this.state.TMSalesLeadDraftCreate[0].draftId : null))), true)) {
            
				

		this.props.form?.setFieldsValue(formVars);
		
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.TalepSatisIslemiComponent_358141_onClick5_();
                  resolve();
                });
          })

        } else {
            
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.TalepSatisIslemiComponent_358141_onClick5_();
                  resolve();
                });
          })
        }

            
            return isErrorOccurred;
        }
		TalepSatisIslemiComponent_358141_onClick5_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
if (ReactSystemFunctions.isNotEmpty(ReactSystemFunctions.value(this, (stateVars.TMSalesLeadDraftCreate !== undefined ? (stateVars.TMSalesLeadDraftCreate?.length > 0 ? stateVars.TMSalesLeadDraftCreate[0].draftId : null) : (this.state.TMSalesLeadDraftCreate?.length > 0 ? this.state.TMSalesLeadDraftCreate[0].draftId : null))), true)) {
            
				stateVars.dataSource_466892 = stateVars.TMSalesLeadPaymentList ?? this.state.TMSalesLeadPaymentList;

		this.props.form?.setFieldsValue(formVars);
		
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.TalepSatisIslemiComponent_358141_onClick6_();
                  resolve();
                });
          })

        } else {
            
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.TalepSatisIslemiComponent_358141_onClick6_();
                  resolve();
                });
          })
        }

            
            return isErrorOccurred;
        }
		TalepSatisIslemiComponent_358141_onClick6_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
if (ReactSystemFunctions.isNotEmpty(ReactSystemFunctions.value(this, (stateVars.TMSalesLeadDraftCreate !== undefined ? (stateVars.TMSalesLeadDraftCreate?.length > 0 ? stateVars.TMSalesLeadDraftCreate[0].draftId : null) : (this.state.TMSalesLeadDraftCreate?.length > 0 ? this.state.TMSalesLeadDraftCreate[0].draftId : null))), true)) {
            
				formVars.talepsatisislemi_100771_value = ReactSystemFunctions.toString(this, (stateVars.TMSalesLeadPaymentList !== undefined ? (stateVars.TMSalesLeadPaymentList?.length > 0 ? stateVars.TMSalesLeadPaymentList[0].collectedTotalEUR : null) : (this.state.TMSalesLeadPaymentList?.length > 0 ? this.state.TMSalesLeadPaymentList[0].collectedTotalEUR : null)));


		this.props.form?.setFieldsValue(formVars);
		
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.TalepSatisIslemiComponent_358141_onClick7_();
                  resolve();
                });
          })

        } else {
            
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.TalepSatisIslemiComponent_358141_onClick7_();
                  resolve();
                });
          })
        }

            
            return isErrorOccurred;
        }
		TalepSatisIslemiComponent_358141_onClick7_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
if (ReactSystemFunctions.isNotEmpty(ReactSystemFunctions.value(this, (stateVars.TMSalesLeadDraftCreate !== undefined ? (stateVars.TMSalesLeadDraftCreate?.length > 0 ? stateVars.TMSalesLeadDraftCreate[0].draftId : null) : (this.state.TMSalesLeadDraftCreate?.length > 0 ? this.state.TMSalesLeadDraftCreate[0].draftId : null))), true)) {
            
				formVars.talepsatisislemi_653586_value = ReactSystemFunctions.toString(this, (stateVars.TMSalesLeadPaymentList !== undefined ? (stateVars.TMSalesLeadPaymentList?.length > 0 ? stateVars.TMSalesLeadPaymentList[0].remainingEUR : null) : (this.state.TMSalesLeadPaymentList?.length > 0 ? this.state.TMSalesLeadPaymentList[0].remainingEUR : null)));


		this.props.form?.setFieldsValue(formVars);
		
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.TalepSatisIslemiComponent_358141_onClick8_();
                  resolve();
                });
          })

        } else {
            
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.TalepSatisIslemiComponent_358141_onClick8_();
                  resolve();
                });
          })
        }

            
            return isErrorOccurred;
        }
		TalepSatisIslemiComponent_358141_onClick8_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }

				formVars.talepsatisislemi_706355_value = ReactSystemFunctions.toString(this, (stateVars.TMSalesLeadSummary !== undefined ? (stateVars.TMSalesLeadSummary?.length > 0 ? stateVars.TMSalesLeadSummary[0].urunAdedi : null) : (this.state.TMSalesLeadSummary?.length > 0 ? this.state.TMSalesLeadSummary[0].urunAdedi : null)));

				formVars.talepsatisislemi_957854_value = ReactSystemFunctions.toString(this, (stateVars.TMSalesLeadSummary !== undefined ? (stateVars.TMSalesLeadSummary?.length > 0 ? stateVars.TMSalesLeadSummary[0].araToplam : null) : (this.state.TMSalesLeadSummary?.length > 0 ? this.state.TMSalesLeadSummary[0].araToplam : null)));

				formVars.talepsatisislemi_94614_value = ReactSystemFunctions.toString(this, (stateVars.TMSalesLeadSummary !== undefined ? (stateVars.TMSalesLeadSummary?.length > 0 ? stateVars.TMSalesLeadSummary[0].iskontoTutari : null) : (this.state.TMSalesLeadSummary?.length > 0 ? this.state.TMSalesLeadSummary[0].iskontoTutari : null)));

				formVars.talepsatisislemi_28476_value = ReactSystemFunctions.toString(this, (stateVars.TMSalesLeadSummary !== undefined ? (stateVars.TMSalesLeadSummary?.length > 0 ? stateVars.TMSalesLeadSummary[0].genelToplam : null) : (this.state.TMSalesLeadSummary?.length > 0 ? this.state.TMSalesLeadSummary[0].genelToplam : null)));

				formVars.talepsatisislemi_646001_value = ReactSystemFunctions.toString(this, (stateVars.TMSalesLeadSummary !== undefined ? (stateVars.TMSalesLeadSummary?.length > 0 ? stateVars.TMSalesLeadSummary[0].tahsilEdilen : null) : (this.state.TMSalesLeadSummary?.length > 0 ? this.state.TMSalesLeadSummary[0].tahsilEdilen : null)));

				formVars.talepsatisislemi_804074_value = ReactSystemFunctions.toString(this, (stateVars.TMSalesLeadSummary !== undefined ? (stateVars.TMSalesLeadSummary?.length > 0 ? stateVars.TMSalesLeadSummary[0].kalanTutar : null) : (this.state.TMSalesLeadSummary?.length > 0 ? this.state.TMSalesLeadSummary[0].kalanTutar : null)));


		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

            
            return isErrorOccurred;
        }













    TalepSatisIslemiComponent_343657_onBlur = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
		KuikaAppManager.increaseServerRequestCount();

        let localVar = {
				PaymentId_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, "talepsatisislemi_466892_value", "paymentId"), "Guid"),
				Amount_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "Table_466892_tutar", "value", "", "", "")), "number"),
				SalesDraftId_1: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toGuid(this, ReactSystemFunctions.value(this, "talepsatisislemi_337380_value", "value", "", "", "")), "Guid"),
				SalesDraftId_2: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toGuid(this, ReactSystemFunctions.value(this, "talepsatisislemi_337380_value", "value", "", "", "")), "Guid")
        }

		KuikaAppManager.showSpinner(this);
		
        if (true) {
        KuikaAppManager.showSpinner(this);
        }
        let result = await KuikaAppManager.ApiRequest(this, "TalepSatisIslemi/TalepSatisIslemiComponent_343657_onBlur", localVar)
        if (!KMainFunctions.IsResStatus2XX(result)) return true;

			stateVars.TMSalesLeadUpdatePayment = result?.data.tmSalesLeadUpdatePayment;
			stateVars.TMSalesLeadPaymentList = result?.data.tmSalesLeadPaymentList;
			
			formVars.talepsatisislemi_100771_value = ReactSystemFunctions.toString(this, (stateVars.TMSalesLeadPaymentList !== undefined ? (stateVars.TMSalesLeadPaymentList?.length > 0 ? stateVars.TMSalesLeadPaymentList[0].collectedTotalEUR : null) : (this.state.TMSalesLeadPaymentList?.length > 0 ? this.state.TMSalesLeadPaymentList[0].collectedTotalEUR : null)));
			formVars.talepsatisislemi_653586_value = ReactSystemFunctions.toString(this, (stateVars.TMSalesLeadPaymentList !== undefined ? (stateVars.TMSalesLeadPaymentList?.length > 0 ? stateVars.TMSalesLeadPaymentList[0].remainingEUR : null) : (this.state.TMSalesLeadPaymentList?.length > 0 ? this.state.TMSalesLeadPaymentList[0].remainingEUR : null)));
			stateVars.isComp1894128536Enabled = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, (stateVars.TMSalesLeadPaymentList !== undefined ? (stateVars.TMSalesLeadPaymentList?.length > 0 ? stateVars.TMSalesLeadPaymentList[0].remainingEUR : null) : (this.state.TMSalesLeadPaymentList?.length > 0 ? this.state.TMSalesLeadPaymentList[0].remainingEUR : null))), ReactSystemFunctions.convertToTypeByName("0", "string"))) === true ? "enabled" : "disabled")
			stateVars.isComp761489Enabled = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, (stateVars.TMSalesLeadPaymentList !== undefined ? (stateVars.TMSalesLeadPaymentList?.length > 0 ? stateVars.TMSalesLeadPaymentList[0].remainingEUR : null) : (this.state.TMSalesLeadPaymentList?.length > 0 ? this.state.TMSalesLeadPaymentList[0].remainingEUR : null))), ReactSystemFunctions.convertToTypeByName("0", "string"))) === true ? "enabled" : "disabled")
			stateVars.TMSalesLeadSummary = result?.data.tmSalesLeadSummary;
			formVars.talepsatisislemi_706355_value = ReactSystemFunctions.toString(this, (stateVars.TMSalesLeadSummary !== undefined ? (stateVars.TMSalesLeadSummary?.length > 0 ? stateVars.TMSalesLeadSummary[0].urunAdedi : null) : (this.state.TMSalesLeadSummary?.length > 0 ? this.state.TMSalesLeadSummary[0].urunAdedi : null)));
			formVars.talepsatisislemi_957854_value = ReactSystemFunctions.toString(this, (stateVars.TMSalesLeadSummary !== undefined ? (stateVars.TMSalesLeadSummary?.length > 0 ? stateVars.TMSalesLeadSummary[0].araToplam : null) : (this.state.TMSalesLeadSummary?.length > 0 ? this.state.TMSalesLeadSummary[0].araToplam : null)));
			formVars.talepsatisislemi_94614_value = ReactSystemFunctions.toString(this, (stateVars.TMSalesLeadSummary !== undefined ? (stateVars.TMSalesLeadSummary?.length > 0 ? stateVars.TMSalesLeadSummary[0].iskontoTutari : null) : (this.state.TMSalesLeadSummary?.length > 0 ? this.state.TMSalesLeadSummary[0].iskontoTutari : null)));
			formVars.talepsatisislemi_28476_value = ReactSystemFunctions.toString(this, (stateVars.TMSalesLeadSummary !== undefined ? (stateVars.TMSalesLeadSummary?.length > 0 ? stateVars.TMSalesLeadSummary[0].genelToplam : null) : (this.state.TMSalesLeadSummary?.length > 0 ? this.state.TMSalesLeadSummary[0].genelToplam : null)));
			formVars.talepsatisislemi_646001_value = ReactSystemFunctions.toString(this, (stateVars.TMSalesLeadSummary !== undefined ? (stateVars.TMSalesLeadSummary?.length > 0 ? stateVars.TMSalesLeadSummary[0].tahsilEdilen : null) : (this.state.TMSalesLeadSummary?.length > 0 ? this.state.TMSalesLeadSummary[0].tahsilEdilen : null)));
			formVars.talepsatisislemi_804074_value = ReactSystemFunctions.toString(this, (stateVars.TMSalesLeadSummary !== undefined ? (stateVars.TMSalesLeadSummary?.length > 0 ? stateVars.TMSalesLeadSummary[0].kalanTutar : null) : (this.state.TMSalesLeadSummary?.length > 0 ? this.state.TMSalesLeadSummary[0].kalanTutar : null)));
			this.props.form?.setFieldsValue(formVars);
			
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.TalepSatisIslemiComponent_343657_onBlur1_();
                  resolve();
                });
          })



        
        KuikaAppManager.hideSpinner(this);
        return isErrorOccurred;
    }
		TalepSatisIslemiComponent_343657_onBlur1_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }

				stateVars.Notify = await ReactSystemFunctions.notify(this, ReactSystemFunctions.toString(this, (stateVars.TMSalesLeadUpdatePayment !== undefined ? (stateVars.TMSalesLeadUpdatePayment?.length > 0 ? stateVars.TMSalesLeadUpdatePayment[0].message : null) : (this.state.TMSalesLeadUpdatePayment?.length > 0 ? this.state.TMSalesLeadUpdatePayment[0].message : null))), ReactSystemFunctions.convertToTypeByName("default", "string"), ReactSystemFunctions.convertToTypeByName("bottom-right", "string"), 3, ReactSystemFunctions.convertToTypeByName("", "string"), ReactSystemFunctions.convertToTypeByName("", "string"), 0);
				
				stateVars.dataSource_466892 = stateVars.TMSalesLeadPaymentList ?? this.state.TMSalesLeadPaymentList;
				formVars.talepsatisislemi_100771_value = ReactSystemFunctions.toString(this, (stateVars.TMSalesLeadPaymentList !== undefined ? (stateVars.TMSalesLeadPaymentList?.length > 0 ? stateVars.TMSalesLeadPaymentList[0].collectedTotalEUR : null) : (this.state.TMSalesLeadPaymentList?.length > 0 ? this.state.TMSalesLeadPaymentList[0].collectedTotalEUR : null)));

				formVars.talepsatisislemi_653586_value = ReactSystemFunctions.toString(this, (stateVars.TMSalesLeadPaymentList !== undefined ? (stateVars.TMSalesLeadPaymentList?.length > 0 ? stateVars.TMSalesLeadPaymentList[0].remainingEUR : null) : (this.state.TMSalesLeadPaymentList?.length > 0 ? this.state.TMSalesLeadPaymentList[0].remainingEUR : null)));

				formVars.talepsatisislemi_706355_value = ReactSystemFunctions.toString(this, (stateVars.TMSalesLeadSummary !== undefined ? (stateVars.TMSalesLeadSummary?.length > 0 ? stateVars.TMSalesLeadSummary[0].urunAdedi : null) : (this.state.TMSalesLeadSummary?.length > 0 ? this.state.TMSalesLeadSummary[0].urunAdedi : null)));

				formVars.talepsatisislemi_957854_value = ReactSystemFunctions.toString(this, (stateVars.TMSalesLeadSummary !== undefined ? (stateVars.TMSalesLeadSummary?.length > 0 ? stateVars.TMSalesLeadSummary[0].araToplam : null) : (this.state.TMSalesLeadSummary?.length > 0 ? this.state.TMSalesLeadSummary[0].araToplam : null)));

				formVars.talepsatisislemi_94614_value = ReactSystemFunctions.toString(this, (stateVars.TMSalesLeadSummary !== undefined ? (stateVars.TMSalesLeadSummary?.length > 0 ? stateVars.TMSalesLeadSummary[0].iskontoTutari : null) : (this.state.TMSalesLeadSummary?.length > 0 ? this.state.TMSalesLeadSummary[0].iskontoTutari : null)));

				formVars.talepsatisislemi_28476_value = ReactSystemFunctions.toString(this, (stateVars.TMSalesLeadSummary !== undefined ? (stateVars.TMSalesLeadSummary?.length > 0 ? stateVars.TMSalesLeadSummary[0].genelToplam : null) : (this.state.TMSalesLeadSummary?.length > 0 ? this.state.TMSalesLeadSummary[0].genelToplam : null)));

				formVars.talepsatisislemi_646001_value = ReactSystemFunctions.toString(this, (stateVars.TMSalesLeadSummary !== undefined ? (stateVars.TMSalesLeadSummary?.length > 0 ? stateVars.TMSalesLeadSummary[0].tahsilEdilen : null) : (this.state.TMSalesLeadSummary?.length > 0 ? this.state.TMSalesLeadSummary[0].tahsilEdilen : null)));

				formVars.talepsatisislemi_804074_value = ReactSystemFunctions.toString(this, (stateVars.TMSalesLeadSummary !== undefined ? (stateVars.TMSalesLeadSummary?.length > 0 ? stateVars.TMSalesLeadSummary[0].kalanTutar : null) : (this.state.TMSalesLeadSummary?.length > 0 ? this.state.TMSalesLeadSummary[0].kalanTutar : null)));


		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

            
            return isErrorOccurred;
        }




    TalepSatisIslemiComponent_515400_onClick = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
		KuikaAppManager.increaseServerRequestCount();

        let localVar = {
				PaymentId_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, "talepsatisislemi_466892_value", "paymentId"), "Guid")
        }

		KuikaAppManager.showSpinner(this);
		
        if (true) {
        KuikaAppManager.showSpinner(this);
        }
        let result = await KuikaAppManager.ApiRequest(this, "TalepSatisIslemi/TalepSatisIslemiComponent_515400_onClick", localVar)
        if (!KMainFunctions.IsResStatus2XX(result)) return true;

			stateVars.TMSalesLeadPaymentCompletedLine = result?.data.tmSalesLeadPaymentCompletedLine;
			this.props.form?.setFieldsValue(formVars);
			
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.TalepSatisIslemiComponent_515400_onClick1_();
                  resolve();
                });
          })



        
        KuikaAppManager.hideSpinner(this);
        return isErrorOccurred;
    }
		TalepSatisIslemiComponent_515400_onClick1_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }

				stateVars.Notify = await ReactSystemFunctions.notify(this, ReactSystemFunctions.toString(this, (stateVars.TMSalesLeadPaymentCompletedLine !== undefined ? (stateVars.TMSalesLeadPaymentCompletedLine?.length > 0 ? stateVars.TMSalesLeadPaymentCompletedLine[0].resultMessage : null) : (this.state.TMSalesLeadPaymentCompletedLine?.length > 0 ? this.state.TMSalesLeadPaymentCompletedLine[0].resultMessage : null))), ReactSystemFunctions.convertToTypeByName("default", "string"), ReactSystemFunctions.convertToTypeByName("bottom-right", "string"), 3, ReactSystemFunctions.convertToTypeByName("", "string"), ReactSystemFunctions.convertToTypeByName("", "string"), 0);

		this.props.form?.setFieldsValue(formVars);
		
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.TalepSatisIslemiComponent_515400_onClick2_();
                  resolve();
                });
          })

            
            return isErrorOccurred;
        }
    TalepSatisIslemiComponent_515400_onClick2_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
		KuikaAppManager.increaseServerRequestCount();

        let localVar = {
				SalesDraftId_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toGuid(this, ReactSystemFunctions.value(this, "talepsatisislemi_337380_value", "value", "", "", "")), "Guid")
        }

if (ReactSystemFunctions.isNotEmpty(ReactSystemFunctions.value(this, (stateVars.TMSalesLeadDraftCreate !== undefined ? (stateVars.TMSalesLeadDraftCreate?.length > 0 ? stateVars.TMSalesLeadDraftCreate[0].draftId : null) : (this.state.TMSalesLeadDraftCreate?.length > 0 ? this.state.TMSalesLeadDraftCreate[0].draftId : null))), ReactSystemFunctions.convertToTypeByName("True", "string"))) {
            		
        if (true) {
        KuikaAppManager.showSpinner(this);
        }
        let result = await KuikaAppManager.ApiRequest(this, "TalepSatisIslemi/TalepSatisIslemiComponent_515400_onClick2_", localVar)
        if (!KMainFunctions.IsResStatus2XX(result)) return true;

			stateVars.TMSalesLeadPaymentList = result?.data.tmSalesLeadPaymentList;
			
			formVars.talepsatisislemi_100771_value = ReactSystemFunctions.toString(this, (stateVars.TMSalesLeadPaymentList !== undefined ? (stateVars.TMSalesLeadPaymentList?.length > 0 ? stateVars.TMSalesLeadPaymentList[0].collectedTotalEUR : null) : (this.state.TMSalesLeadPaymentList?.length > 0 ? this.state.TMSalesLeadPaymentList[0].collectedTotalEUR : null)));
			formVars.talepsatisislemi_653586_value = ReactSystemFunctions.toString(this, (stateVars.TMSalesLeadPaymentList !== undefined ? (stateVars.TMSalesLeadPaymentList?.length > 0 ? stateVars.TMSalesLeadPaymentList[0].remainingEUR : null) : (this.state.TMSalesLeadPaymentList?.length > 0 ? this.state.TMSalesLeadPaymentList[0].remainingEUR : null)));
			stateVars.isComp1894128536Enabled = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, (stateVars.TMSalesLeadPaymentList !== undefined ? (stateVars.TMSalesLeadPaymentList?.length > 0 ? stateVars.TMSalesLeadPaymentList[0].remainingEUR : null) : (this.state.TMSalesLeadPaymentList?.length > 0 ? this.state.TMSalesLeadPaymentList[0].remainingEUR : null))), ReactSystemFunctions.convertToTypeByName("0", "string"))) === true ? "enabled" : "disabled")
			stateVars.isComp761489Enabled = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, (stateVars.TMSalesLeadPaymentList !== undefined ? (stateVars.TMSalesLeadPaymentList?.length > 0 ? stateVars.TMSalesLeadPaymentList[0].remainingEUR : null) : (this.state.TMSalesLeadPaymentList?.length > 0 ? this.state.TMSalesLeadPaymentList[0].remainingEUR : null))), ReactSystemFunctions.convertToTypeByName("0", "string"))) === true ? "enabled" : "disabled")
			this.props.form?.setFieldsValue(formVars);
			
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.TalepSatisIslemiComponent_515400_onClick3_();
                  resolve();
                });
          })

        } else {
            
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.TalepSatisIslemiComponent_515400_onClick3_();
                  resolve();
                });
          })
        }


        
        KuikaAppManager.hideSpinner(this);
        return isErrorOccurred;
    }
    TalepSatisIslemiComponent_515400_onClick3_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
		KuikaAppManager.increaseServerRequestCount();

        let localVar = {
				SalesDraftId_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toGuid(this, ReactSystemFunctions.value(this, "talepsatisislemi_337380_value", "value", "", "", "")), "Guid")
        }

		
        if (true) {
        KuikaAppManager.showSpinner(this);
        }
        let result = await KuikaAppManager.ApiRequest(this, "TalepSatisIslemi/TalepSatisIslemiComponent_515400_onClick3_", localVar)
        if (!KMainFunctions.IsResStatus2XX(result)) return true;

			stateVars.TMSalesLeadSummary = result?.data.tmSalesLeadSummary;
			formVars.talepsatisislemi_706355_value = ReactSystemFunctions.toString(this, (stateVars.TMSalesLeadSummary !== undefined ? (stateVars.TMSalesLeadSummary?.length > 0 ? stateVars.TMSalesLeadSummary[0].urunAdedi : null) : (this.state.TMSalesLeadSummary?.length > 0 ? this.state.TMSalesLeadSummary[0].urunAdedi : null)));
			formVars.talepsatisislemi_957854_value = ReactSystemFunctions.toString(this, (stateVars.TMSalesLeadSummary !== undefined ? (stateVars.TMSalesLeadSummary?.length > 0 ? stateVars.TMSalesLeadSummary[0].araToplam : null) : (this.state.TMSalesLeadSummary?.length > 0 ? this.state.TMSalesLeadSummary[0].araToplam : null)));
			formVars.talepsatisislemi_94614_value = ReactSystemFunctions.toString(this, (stateVars.TMSalesLeadSummary !== undefined ? (stateVars.TMSalesLeadSummary?.length > 0 ? stateVars.TMSalesLeadSummary[0].iskontoTutari : null) : (this.state.TMSalesLeadSummary?.length > 0 ? this.state.TMSalesLeadSummary[0].iskontoTutari : null)));
			formVars.talepsatisislemi_28476_value = ReactSystemFunctions.toString(this, (stateVars.TMSalesLeadSummary !== undefined ? (stateVars.TMSalesLeadSummary?.length > 0 ? stateVars.TMSalesLeadSummary[0].genelToplam : null) : (this.state.TMSalesLeadSummary?.length > 0 ? this.state.TMSalesLeadSummary[0].genelToplam : null)));
			formVars.talepsatisislemi_646001_value = ReactSystemFunctions.toString(this, (stateVars.TMSalesLeadSummary !== undefined ? (stateVars.TMSalesLeadSummary?.length > 0 ? stateVars.TMSalesLeadSummary[0].tahsilEdilen : null) : (this.state.TMSalesLeadSummary?.length > 0 ? this.state.TMSalesLeadSummary[0].tahsilEdilen : null)));
			formVars.talepsatisislemi_804074_value = ReactSystemFunctions.toString(this, (stateVars.TMSalesLeadSummary !== undefined ? (stateVars.TMSalesLeadSummary?.length > 0 ? stateVars.TMSalesLeadSummary[0].kalanTutar : null) : (this.state.TMSalesLeadSummary?.length > 0 ? this.state.TMSalesLeadSummary[0].kalanTutar : null)));
			this.props.form?.setFieldsValue(formVars);
			
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.TalepSatisIslemiComponent_515400_onClick4_();
                  resolve();
                });
          })



        
        KuikaAppManager.hideSpinner(this);
        return isErrorOccurred;
    }
		TalepSatisIslemiComponent_515400_onClick4_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
if (ReactSystemFunctions.isNotEmpty(ReactSystemFunctions.value(this, (stateVars.TMSalesLeadDraftCreate !== undefined ? (stateVars.TMSalesLeadDraftCreate?.length > 0 ? stateVars.TMSalesLeadDraftCreate[0].draftId : null) : (this.state.TMSalesLeadDraftCreate?.length > 0 ? this.state.TMSalesLeadDraftCreate[0].draftId : null))), ReactSystemFunctions.convertToTypeByName("True", "string"))) {
            
				

		this.props.form?.setFieldsValue(formVars);
		
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.TalepSatisIslemiComponent_515400_onClick5_();
                  resolve();
                });
          })

        } else {
            
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.TalepSatisIslemiComponent_515400_onClick5_();
                  resolve();
                });
          })
        }

            
            return isErrorOccurred;
        }
		TalepSatisIslemiComponent_515400_onClick5_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
if (ReactSystemFunctions.isNotEmpty(ReactSystemFunctions.value(this, (stateVars.TMSalesLeadDraftCreate !== undefined ? (stateVars.TMSalesLeadDraftCreate?.length > 0 ? stateVars.TMSalesLeadDraftCreate[0].draftId : null) : (this.state.TMSalesLeadDraftCreate?.length > 0 ? this.state.TMSalesLeadDraftCreate[0].draftId : null))), ReactSystemFunctions.convertToTypeByName("True", "string"))) {
            
				stateVars.dataSource_466892 = stateVars.TMSalesLeadPaymentList ?? this.state.TMSalesLeadPaymentList;

		this.props.form?.setFieldsValue(formVars);
		
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.TalepSatisIslemiComponent_515400_onClick6_();
                  resolve();
                });
          })

        } else {
            
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.TalepSatisIslemiComponent_515400_onClick6_();
                  resolve();
                });
          })
        }

            
            return isErrorOccurred;
        }
		TalepSatisIslemiComponent_515400_onClick6_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
if (ReactSystemFunctions.isNotEmpty(ReactSystemFunctions.value(this, (stateVars.TMSalesLeadDraftCreate !== undefined ? (stateVars.TMSalesLeadDraftCreate?.length > 0 ? stateVars.TMSalesLeadDraftCreate[0].draftId : null) : (this.state.TMSalesLeadDraftCreate?.length > 0 ? this.state.TMSalesLeadDraftCreate[0].draftId : null))), ReactSystemFunctions.convertToTypeByName("True", "string"))) {
            
				formVars.talepsatisislemi_100771_value = ReactSystemFunctions.toString(this, (stateVars.TMSalesLeadPaymentList !== undefined ? (stateVars.TMSalesLeadPaymentList?.length > 0 ? stateVars.TMSalesLeadPaymentList[0].collectedTotalEUR : null) : (this.state.TMSalesLeadPaymentList?.length > 0 ? this.state.TMSalesLeadPaymentList[0].collectedTotalEUR : null)));


		this.props.form?.setFieldsValue(formVars);
		
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.TalepSatisIslemiComponent_515400_onClick7_();
                  resolve();
                });
          })

        } else {
            
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.TalepSatisIslemiComponent_515400_onClick7_();
                  resolve();
                });
          })
        }

            
            return isErrorOccurred;
        }
		TalepSatisIslemiComponent_515400_onClick7_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
if (ReactSystemFunctions.isNotEmpty(ReactSystemFunctions.value(this, (stateVars.TMSalesLeadDraftCreate !== undefined ? (stateVars.TMSalesLeadDraftCreate?.length > 0 ? stateVars.TMSalesLeadDraftCreate[0].draftId : null) : (this.state.TMSalesLeadDraftCreate?.length > 0 ? this.state.TMSalesLeadDraftCreate[0].draftId : null))), ReactSystemFunctions.convertToTypeByName("True", "string"))) {
            
				formVars.talepsatisislemi_653586_value = ReactSystemFunctions.toString(this, (stateVars.TMSalesLeadPaymentList !== undefined ? (stateVars.TMSalesLeadPaymentList?.length > 0 ? stateVars.TMSalesLeadPaymentList[0].remainingEUR : null) : (this.state.TMSalesLeadPaymentList?.length > 0 ? this.state.TMSalesLeadPaymentList[0].remainingEUR : null)));


		this.props.form?.setFieldsValue(formVars);
		
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.TalepSatisIslemiComponent_515400_onClick8_();
                  resolve();
                });
          })

        } else {
            
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.TalepSatisIslemiComponent_515400_onClick8_();
                  resolve();
                });
          })
        }

            
            return isErrorOccurred;
        }
		TalepSatisIslemiComponent_515400_onClick8_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }

				formVars.talepsatisislemi_706355_value = ReactSystemFunctions.toString(this, (stateVars.TMSalesLeadSummary !== undefined ? (stateVars.TMSalesLeadSummary?.length > 0 ? stateVars.TMSalesLeadSummary[0].urunAdedi : null) : (this.state.TMSalesLeadSummary?.length > 0 ? this.state.TMSalesLeadSummary[0].urunAdedi : null)));

				formVars.talepsatisislemi_957854_value = ReactSystemFunctions.toString(this, (stateVars.TMSalesLeadSummary !== undefined ? (stateVars.TMSalesLeadSummary?.length > 0 ? stateVars.TMSalesLeadSummary[0].araToplam : null) : (this.state.TMSalesLeadSummary?.length > 0 ? this.state.TMSalesLeadSummary[0].araToplam : null)));

				formVars.talepsatisislemi_94614_value = ReactSystemFunctions.toString(this, (stateVars.TMSalesLeadSummary !== undefined ? (stateVars.TMSalesLeadSummary?.length > 0 ? stateVars.TMSalesLeadSummary[0].iskontoTutari : null) : (this.state.TMSalesLeadSummary?.length > 0 ? this.state.TMSalesLeadSummary[0].iskontoTutari : null)));

				formVars.talepsatisislemi_28476_value = ReactSystemFunctions.toString(this, (stateVars.TMSalesLeadSummary !== undefined ? (stateVars.TMSalesLeadSummary?.length > 0 ? stateVars.TMSalesLeadSummary[0].genelToplam : null) : (this.state.TMSalesLeadSummary?.length > 0 ? this.state.TMSalesLeadSummary[0].genelToplam : null)));

				formVars.talepsatisislemi_646001_value = ReactSystemFunctions.toString(this, (stateVars.TMSalesLeadSummary !== undefined ? (stateVars.TMSalesLeadSummary?.length > 0 ? stateVars.TMSalesLeadSummary[0].tahsilEdilen : null) : (this.state.TMSalesLeadSummary?.length > 0 ? this.state.TMSalesLeadSummary[0].tahsilEdilen : null)));

				formVars.talepsatisislemi_804074_value = ReactSystemFunctions.toString(this, (stateVars.TMSalesLeadSummary !== undefined ? (stateVars.TMSalesLeadSummary?.length > 0 ? stateVars.TMSalesLeadSummary[0].kalanTutar : null) : (this.state.TMSalesLeadSummary?.length > 0 ? this.state.TMSalesLeadSummary[0].kalanTutar : null)));


		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

            
            return isErrorOccurred;
        }













    TalepSatisIslemiComponent_354056_onClick = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
		KuikaAppManager.increaseServerRequestCount();

        let localVar = {
				PaymentId_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, "talepsatisislemi_466892_value", "paymentId"), "Guid")
        }

		KuikaAppManager.showSpinner(this);
		
        if (true) {
        KuikaAppManager.showSpinner(this);
        }
        let result = await KuikaAppManager.ApiRequest(this, "TalepSatisIslemi/TalepSatisIslemiComponent_354056_onClick", localVar)
        if (!KMainFunctions.IsResStatus2XX(result)) return true;

			stateVars.TMSalesLeadPaymentDeleted = result?.data.tmSalesLeadPaymentDeleted;
			this.props.form?.setFieldsValue(formVars);
			
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.TalepSatisIslemiComponent_354056_onClick1_();
                  resolve();
                });
          })



        
        KuikaAppManager.hideSpinner(this);
        return isErrorOccurred;
    }
		TalepSatisIslemiComponent_354056_onClick1_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }

				stateVars.Notify = await ReactSystemFunctions.notify(this, ReactSystemFunctions.toString(this, (stateVars.TMSalesLeadPaymentDeleted !== undefined ? (stateVars.TMSalesLeadPaymentDeleted?.length > 0 ? stateVars.TMSalesLeadPaymentDeleted[0].message : null) : (this.state.TMSalesLeadPaymentDeleted?.length > 0 ? this.state.TMSalesLeadPaymentDeleted[0].message : null))), ReactSystemFunctions.convertToTypeByName("default", "string"), ReactSystemFunctions.convertToTypeByName("bottom-right", "string"), 3, ReactSystemFunctions.convertToTypeByName("", "string"), ReactSystemFunctions.convertToTypeByName("", "string"), 0);

		this.props.form?.setFieldsValue(formVars);
		
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.TalepSatisIslemiComponent_354056_onClick2_();
                  resolve();
                });
          })

            
            return isErrorOccurred;
        }
    TalepSatisIslemiComponent_354056_onClick2_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
		KuikaAppManager.increaseServerRequestCount();

        let localVar = {
				SalesDraftId_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toGuid(this, ReactSystemFunctions.value(this, "talepsatisislemi_337380_value", "value", "", "", "")), "Guid")
        }

if (ReactSystemFunctions.isNotEmpty(ReactSystemFunctions.value(this, (stateVars.TMSalesLeadDraftCreate !== undefined ? (stateVars.TMSalesLeadDraftCreate?.length > 0 ? stateVars.TMSalesLeadDraftCreate[0].draftId : null) : (this.state.TMSalesLeadDraftCreate?.length > 0 ? this.state.TMSalesLeadDraftCreate[0].draftId : null))), ReactSystemFunctions.convertToTypeByName("True", "string"))) {
            		
        if (true) {
        KuikaAppManager.showSpinner(this);
        }
        let result = await KuikaAppManager.ApiRequest(this, "TalepSatisIslemi/TalepSatisIslemiComponent_354056_onClick2_", localVar)
        if (!KMainFunctions.IsResStatus2XX(result)) return true;

			stateVars.TMSalesLeadPaymentList = result?.data.tmSalesLeadPaymentList;
			
			formVars.talepsatisislemi_100771_value = ReactSystemFunctions.toString(this, (stateVars.TMSalesLeadPaymentList !== undefined ? (stateVars.TMSalesLeadPaymentList?.length > 0 ? stateVars.TMSalesLeadPaymentList[0].collectedTotalEUR : null) : (this.state.TMSalesLeadPaymentList?.length > 0 ? this.state.TMSalesLeadPaymentList[0].collectedTotalEUR : null)));
			formVars.talepsatisislemi_653586_value = ReactSystemFunctions.toString(this, (stateVars.TMSalesLeadPaymentList !== undefined ? (stateVars.TMSalesLeadPaymentList?.length > 0 ? stateVars.TMSalesLeadPaymentList[0].remainingEUR : null) : (this.state.TMSalesLeadPaymentList?.length > 0 ? this.state.TMSalesLeadPaymentList[0].remainingEUR : null)));
			stateVars.isComp1894128536Enabled = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, (stateVars.TMSalesLeadPaymentList !== undefined ? (stateVars.TMSalesLeadPaymentList?.length > 0 ? stateVars.TMSalesLeadPaymentList[0].remainingEUR : null) : (this.state.TMSalesLeadPaymentList?.length > 0 ? this.state.TMSalesLeadPaymentList[0].remainingEUR : null))), ReactSystemFunctions.convertToTypeByName("0", "string"))) === true ? "enabled" : "disabled")
			stateVars.isComp761489Enabled = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, (stateVars.TMSalesLeadPaymentList !== undefined ? (stateVars.TMSalesLeadPaymentList?.length > 0 ? stateVars.TMSalesLeadPaymentList[0].remainingEUR : null) : (this.state.TMSalesLeadPaymentList?.length > 0 ? this.state.TMSalesLeadPaymentList[0].remainingEUR : null))), ReactSystemFunctions.convertToTypeByName("0", "string"))) === true ? "enabled" : "disabled")
			this.props.form?.setFieldsValue(formVars);
			
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.TalepSatisIslemiComponent_354056_onClick3_();
                  resolve();
                });
          })

        } else {
            
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.TalepSatisIslemiComponent_354056_onClick3_();
                  resolve();
                });
          })
        }


        
        KuikaAppManager.hideSpinner(this);
        return isErrorOccurred;
    }
    TalepSatisIslemiComponent_354056_onClick3_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
		KuikaAppManager.increaseServerRequestCount();

        let localVar = {
				SalesDraftId_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toGuid(this, ReactSystemFunctions.value(this, "talepsatisislemi_337380_value", "value", "", "", "")), "Guid")
        }

		
        if (true) {
        KuikaAppManager.showSpinner(this);
        }
        let result = await KuikaAppManager.ApiRequest(this, "TalepSatisIslemi/TalepSatisIslemiComponent_354056_onClick3_", localVar)
        if (!KMainFunctions.IsResStatus2XX(result)) return true;

			stateVars.TMSalesLeadSummary = result?.data.tmSalesLeadSummary;
			formVars.talepsatisislemi_706355_value = ReactSystemFunctions.toString(this, (stateVars.TMSalesLeadSummary !== undefined ? (stateVars.TMSalesLeadSummary?.length > 0 ? stateVars.TMSalesLeadSummary[0].urunAdedi : null) : (this.state.TMSalesLeadSummary?.length > 0 ? this.state.TMSalesLeadSummary[0].urunAdedi : null)));
			formVars.talepsatisislemi_957854_value = ReactSystemFunctions.toString(this, (stateVars.TMSalesLeadSummary !== undefined ? (stateVars.TMSalesLeadSummary?.length > 0 ? stateVars.TMSalesLeadSummary[0].araToplam : null) : (this.state.TMSalesLeadSummary?.length > 0 ? this.state.TMSalesLeadSummary[0].araToplam : null)));
			formVars.talepsatisislemi_94614_value = ReactSystemFunctions.toString(this, (stateVars.TMSalesLeadSummary !== undefined ? (stateVars.TMSalesLeadSummary?.length > 0 ? stateVars.TMSalesLeadSummary[0].iskontoTutari : null) : (this.state.TMSalesLeadSummary?.length > 0 ? this.state.TMSalesLeadSummary[0].iskontoTutari : null)));
			formVars.talepsatisislemi_28476_value = ReactSystemFunctions.toString(this, (stateVars.TMSalesLeadSummary !== undefined ? (stateVars.TMSalesLeadSummary?.length > 0 ? stateVars.TMSalesLeadSummary[0].genelToplam : null) : (this.state.TMSalesLeadSummary?.length > 0 ? this.state.TMSalesLeadSummary[0].genelToplam : null)));
			formVars.talepsatisislemi_646001_value = ReactSystemFunctions.toString(this, (stateVars.TMSalesLeadSummary !== undefined ? (stateVars.TMSalesLeadSummary?.length > 0 ? stateVars.TMSalesLeadSummary[0].tahsilEdilen : null) : (this.state.TMSalesLeadSummary?.length > 0 ? this.state.TMSalesLeadSummary[0].tahsilEdilen : null)));
			formVars.talepsatisislemi_804074_value = ReactSystemFunctions.toString(this, (stateVars.TMSalesLeadSummary !== undefined ? (stateVars.TMSalesLeadSummary?.length > 0 ? stateVars.TMSalesLeadSummary[0].kalanTutar : null) : (this.state.TMSalesLeadSummary?.length > 0 ? this.state.TMSalesLeadSummary[0].kalanTutar : null)));
			this.props.form?.setFieldsValue(formVars);
			
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.TalepSatisIslemiComponent_354056_onClick4_();
                  resolve();
                });
          })



        
        KuikaAppManager.hideSpinner(this);
        return isErrorOccurred;
    }
		TalepSatisIslemiComponent_354056_onClick4_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
if (ReactSystemFunctions.isNotEmpty(ReactSystemFunctions.value(this, (stateVars.TMSalesLeadDraftCreate !== undefined ? (stateVars.TMSalesLeadDraftCreate?.length > 0 ? stateVars.TMSalesLeadDraftCreate[0].draftId : null) : (this.state.TMSalesLeadDraftCreate?.length > 0 ? this.state.TMSalesLeadDraftCreate[0].draftId : null))), ReactSystemFunctions.convertToTypeByName("True", "string"))) {
            
				

		this.props.form?.setFieldsValue(formVars);
		
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.TalepSatisIslemiComponent_354056_onClick5_();
                  resolve();
                });
          })

        } else {
            
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.TalepSatisIslemiComponent_354056_onClick5_();
                  resolve();
                });
          })
        }

            
            return isErrorOccurred;
        }
		TalepSatisIslemiComponent_354056_onClick5_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
if (ReactSystemFunctions.isNotEmpty(ReactSystemFunctions.value(this, (stateVars.TMSalesLeadDraftCreate !== undefined ? (stateVars.TMSalesLeadDraftCreate?.length > 0 ? stateVars.TMSalesLeadDraftCreate[0].draftId : null) : (this.state.TMSalesLeadDraftCreate?.length > 0 ? this.state.TMSalesLeadDraftCreate[0].draftId : null))), ReactSystemFunctions.convertToTypeByName("True", "string"))) {
            
				stateVars.dataSource_466892 = stateVars.TMSalesLeadPaymentList ?? this.state.TMSalesLeadPaymentList;

		this.props.form?.setFieldsValue(formVars);
		
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.TalepSatisIslemiComponent_354056_onClick6_();
                  resolve();
                });
          })

        } else {
            
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.TalepSatisIslemiComponent_354056_onClick6_();
                  resolve();
                });
          })
        }

            
            return isErrorOccurred;
        }
		TalepSatisIslemiComponent_354056_onClick6_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
if (ReactSystemFunctions.isNotEmpty(ReactSystemFunctions.value(this, (stateVars.TMSalesLeadDraftCreate !== undefined ? (stateVars.TMSalesLeadDraftCreate?.length > 0 ? stateVars.TMSalesLeadDraftCreate[0].draftId : null) : (this.state.TMSalesLeadDraftCreate?.length > 0 ? this.state.TMSalesLeadDraftCreate[0].draftId : null))), ReactSystemFunctions.convertToTypeByName("True", "string"))) {
            
				formVars.talepsatisislemi_100771_value = ReactSystemFunctions.toString(this, (stateVars.TMSalesLeadPaymentList !== undefined ? (stateVars.TMSalesLeadPaymentList?.length > 0 ? stateVars.TMSalesLeadPaymentList[0].collectedTotalEUR : null) : (this.state.TMSalesLeadPaymentList?.length > 0 ? this.state.TMSalesLeadPaymentList[0].collectedTotalEUR : null)));


		this.props.form?.setFieldsValue(formVars);
		
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.TalepSatisIslemiComponent_354056_onClick7_();
                  resolve();
                });
          })

        } else {
            
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.TalepSatisIslemiComponent_354056_onClick7_();
                  resolve();
                });
          })
        }

            
            return isErrorOccurred;
        }
		TalepSatisIslemiComponent_354056_onClick7_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
if (ReactSystemFunctions.isNotEmpty(ReactSystemFunctions.value(this, (stateVars.TMSalesLeadDraftCreate !== undefined ? (stateVars.TMSalesLeadDraftCreate?.length > 0 ? stateVars.TMSalesLeadDraftCreate[0].draftId : null) : (this.state.TMSalesLeadDraftCreate?.length > 0 ? this.state.TMSalesLeadDraftCreate[0].draftId : null))), ReactSystemFunctions.convertToTypeByName("True", "string"))) {
            
				formVars.talepsatisislemi_653586_value = ReactSystemFunctions.toString(this, (stateVars.TMSalesLeadPaymentList !== undefined ? (stateVars.TMSalesLeadPaymentList?.length > 0 ? stateVars.TMSalesLeadPaymentList[0].remainingEUR : null) : (this.state.TMSalesLeadPaymentList?.length > 0 ? this.state.TMSalesLeadPaymentList[0].remainingEUR : null)));


		this.props.form?.setFieldsValue(formVars);
		
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.TalepSatisIslemiComponent_354056_onClick8_();
                  resolve();
                });
          })

        } else {
            
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.TalepSatisIslemiComponent_354056_onClick8_();
                  resolve();
                });
          })
        }

            
            return isErrorOccurred;
        }
		TalepSatisIslemiComponent_354056_onClick8_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }

				formVars.talepsatisislemi_706355_value = ReactSystemFunctions.toString(this, (stateVars.TMSalesLeadSummary !== undefined ? (stateVars.TMSalesLeadSummary?.length > 0 ? stateVars.TMSalesLeadSummary[0].urunAdedi : null) : (this.state.TMSalesLeadSummary?.length > 0 ? this.state.TMSalesLeadSummary[0].urunAdedi : null)));

				formVars.talepsatisislemi_957854_value = ReactSystemFunctions.toString(this, (stateVars.TMSalesLeadSummary !== undefined ? (stateVars.TMSalesLeadSummary?.length > 0 ? stateVars.TMSalesLeadSummary[0].araToplam : null) : (this.state.TMSalesLeadSummary?.length > 0 ? this.state.TMSalesLeadSummary[0].araToplam : null)));

				formVars.talepsatisislemi_94614_value = ReactSystemFunctions.toString(this, (stateVars.TMSalesLeadSummary !== undefined ? (stateVars.TMSalesLeadSummary?.length > 0 ? stateVars.TMSalesLeadSummary[0].iskontoTutari : null) : (this.state.TMSalesLeadSummary?.length > 0 ? this.state.TMSalesLeadSummary[0].iskontoTutari : null)));

				formVars.talepsatisislemi_28476_value = ReactSystemFunctions.toString(this, (stateVars.TMSalesLeadSummary !== undefined ? (stateVars.TMSalesLeadSummary?.length > 0 ? stateVars.TMSalesLeadSummary[0].genelToplam : null) : (this.state.TMSalesLeadSummary?.length > 0 ? this.state.TMSalesLeadSummary[0].genelToplam : null)));

				formVars.talepsatisislemi_646001_value = ReactSystemFunctions.toString(this, (stateVars.TMSalesLeadSummary !== undefined ? (stateVars.TMSalesLeadSummary?.length > 0 ? stateVars.TMSalesLeadSummary[0].tahsilEdilen : null) : (this.state.TMSalesLeadSummary?.length > 0 ? this.state.TMSalesLeadSummary[0].tahsilEdilen : null)));

				formVars.talepsatisislemi_804074_value = ReactSystemFunctions.toString(this, (stateVars.TMSalesLeadSummary !== undefined ? (stateVars.TMSalesLeadSummary?.length > 0 ? stateVars.TMSalesLeadSummary[0].kalanTutar : null) : (this.state.TMSalesLeadSummary?.length > 0 ? this.state.TMSalesLeadSummary[0].kalanTutar : null)));


		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

            
            return isErrorOccurred;
        }













		TalepSatisIslemiComponent_1894128536_onClick = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
if (ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, (stateVars.TMSalesLeadPaymentList !== undefined ? (stateVars.TMSalesLeadPaymentList?.length > 0 ? stateVars.TMSalesLeadPaymentList[0].remainingEUR : null) : (this.state.TMSalesLeadPaymentList?.length > 0 ? this.state.TMSalesLeadPaymentList[0].remainingEUR : null))), "0")) {
            KuikaAppManager.showSpinner(this);

				stateVars.ChangeVisibilityOf = await ReactSystemFunctions.changeVisibilityOf(this, ReactSystemFunctions.convertToTypeByName("isComp761489Visible", "string"), ReactSystemFunctions.convertToTypeByName("visible", "string"));

		this.props.form?.setFieldsValue(formVars);
		
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.TalepSatisIslemiComponent_1894128536_onClick1_();
                  resolve();
                });
          })

        } else {
            
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.TalepSatisIslemiComponent_1894128536_onClick1_();
                  resolve();
                });
          })
        }

            
            return isErrorOccurred;
        }
		TalepSatisIslemiComponent_1894128536_onClick1_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
if (ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, (stateVars.TMSalesLeadPaymentList !== undefined ? (stateVars.TMSalesLeadPaymentList?.length > 0 ? stateVars.TMSalesLeadPaymentList[0].remainingEUR : null) : (this.state.TMSalesLeadPaymentList?.length > 0 ? this.state.TMSalesLeadPaymentList[0].remainingEUR : null))), "0")) {
            
				stateVars.Notify = await ReactSystemFunctions.notify(this, ReactSystemFunctions.translateCustomActions(this.ml,"9f40dc53_1e62_b346_1bc2_ac7a4add9659_notify",this.defaultML,"Kalan tutar bulunmamaktadır!" ), ReactSystemFunctions.convertToTypeByName("success", "string"), ReactSystemFunctions.convertToTypeByName("bottom-right", "string"), 2, ReactSystemFunctions.convertToTypeByName("", "string"), ReactSystemFunctions.convertToTypeByName("", "string"), 0);

		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

        } else {
            KuikaAppManager.hideSpinner(this);
        }

            
            return isErrorOccurred;
        }



    TalepSatisIslemiComponent_761489_onClick = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
		KuikaAppManager.increaseServerRequestCount();

        let localVar = {
				SalesLeadDraftId_1: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toGuid(this, ReactSystemFunctions.value(this, "talepsatisislemi_337380_value", "value", "", "", "")), "Guid"),
				CurrentUserId_1: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.getMyUserId(), "Guid"),
				DraftId_2: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toGuid(this, ReactSystemFunctions.value(this, "talepsatisislemi_337380_value", "value", "", "", "")), "Guid"),
				DraftId_3: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toGuid(this, ReactSystemFunctions.value(this, "talepsatisislemi_337380_value", "value", "", "", "")), "Guid"),
				DraftId_4: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toGuid(this, ReactSystemFunctions.value(this, "talepsatisislemi_337380_value", "value", "", "", "")), "Guid")
        }

		KuikaAppManager.showSpinner(this);
		
        if (true) {
        KuikaAppManager.showSpinner(this);
        }
        let result = await KuikaAppManager.ApiRequest(this, "TalepSatisIslemi/TalepSatisIslemiComponent_761489_onClick", localVar)
        if (!KMainFunctions.IsResStatus2XX(result)) return true;

			stateVars.TM_SubmitThirdPartyInvoiceLeadApproval = result?.data.tM_SubmitThirdPartyInvoiceLeadApproval;
			stateVars.TM_GetSalesDraftForPost = result?.data.tM_GetSalesDraftForPost;
			stateVars.TM_GetSalesDraftDetailForPost = result?.data.tM_GetSalesDraftDetailForPost;
			stateVars.TM_GetSalesDraftPaymentForPost = result?.data.tM_GetSalesDraftPaymentForPost;
			this.props.form?.setFieldsValue(formVars);
			
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.TalepSatisIslemiComponent_761489_onClick1_();
                  resolve();
                });
          })



        
        KuikaAppManager.hideSpinner(this);
        return isErrorOccurred;
    }
    TalepSatisIslemiComponent_761489_onClick1_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
		KuikaAppManager.increaseServerRequestCount();

        let localVar = {
				customerCode_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, (stateVars.TM_GetSalesDraftForPost !== undefined ? (stateVars.TM_GetSalesDraftForPost?.length > 0 ? stateVars.TM_GetSalesDraftForPost[0].customerCode : null) : (this.state.TM_GetSalesDraftForPost?.length > 0 ? this.state.TM_GetSalesDraftForPost[0].customerCode : null))), "string"),
				officeCode_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, (stateVars.TM_GetSalesDraftForPost !== undefined ? (stateVars.TM_GetSalesDraftForPost?.length > 0 ? stateVars.TM_GetSalesDraftForPost[0].officeCode : null) : (this.state.TM_GetSalesDraftForPost?.length > 0 ? this.state.TM_GetSalesDraftForPost[0].officeCode : null))), "string"),
				storeCode_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, (stateVars.TM_GetSalesDraftForPost !== undefined ? (stateVars.TM_GetSalesDraftForPost?.length > 0 ? stateVars.TM_GetSalesDraftForPost[0].storeCode : null) : (this.state.TM_GetSalesDraftForPost?.length > 0 ? this.state.TM_GetSalesDraftForPost[0].storeCode : null))), "string"),
				warehouseCode_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, (stateVars.TM_GetSalesDraftForPost !== undefined ? (stateVars.TM_GetSalesDraftForPost?.length > 0 ? stateVars.TM_GetSalesDraftForPost[0].wareHouseCode : null) : (this.state.TM_GetSalesDraftForPost?.length > 0 ? this.state.TM_GetSalesDraftForPost[0].wareHouseCode : null))), "string"),
				billingAddressId_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, (stateVars.TM_GetSalesDraftForPost !== undefined ? (stateVars.TM_GetSalesDraftForPost?.length > 0 ? stateVars.TM_GetSalesDraftForPost[0].postalAddressID : null) : (this.state.TM_GetSalesDraftForPost?.length > 0 ? this.state.TM_GetSalesDraftForPost[0].postalAddressID : null))), "string"),
				shippingAddressId_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, (stateVars.TM_GetSalesDraftForPost !== undefined ? (stateVars.TM_GetSalesDraftForPost?.length > 0 ? stateVars.TM_GetSalesDraftForPost[0].postalAddressID : null) : (this.state.TM_GetSalesDraftForPost?.length > 0 ? this.state.TM_GetSalesDraftForPost[0].postalAddressID : null))), "string"),
				exchangeRate_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, (stateVars.TM_GetSalesDraftForPost !== undefined ? (stateVars.TM_GetSalesDraftForPost?.length > 0 ? stateVars.TM_GetSalesDraftForPost[0].exchangeRate : null) : (this.state.TM_GetSalesDraftForPost?.length > 0 ? this.state.TM_GetSalesDraftForPost[0].exchangeRate : null))), "number"),
				lines_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, this.state.TM_GetSalesDraftDetailForPost), "any[]"),
				lines_ItemCode_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, this.state.TM_GetSalesDraftDetailForPost?.productCode), "string"),
				lines_ProductSerialNumber_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, this.state.TM_GetSalesDraftDetailForPost?.seriNo), "string"),
				lines_UseSerialNumber_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, this.state.TM_GetSalesDraftDetailForPost?.useSerialNumber), "string"),
				lines_Qty1_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, this.state.TM_GetSalesDraftDetailForPost?.qty1), "number"),
				lines_PriceVI_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, this.state.TM_GetSalesDraftDetailForPost?.unitPriceEUR), "number"),
				lines_LDisRate1_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, this.state.TM_GetSalesDraftDetailForPost?.discountRate), "number"),
				lines_SalespersonCode_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, this.state.TM_GetSalesDraftDetailForPost?.salesPersonCode), "string"),
				payments_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, this.state.TM_GetSalesDraftPaymentForPost), "any[]"),
				payments_PaymentType_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toInteger(this, this.state.TM_GetSalesDraftPaymentForPost?.paymentType), "number"),
				payments_Code_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, this.state.TM_GetSalesDraftPaymentForPost?.currAccCode), "string"),
				payments_Amount_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, this.state.TM_GetSalesDraftPaymentForPost?.amount), "number"),
				payments_CurrencyCode_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, this.state.TM_GetSalesDraftPaymentForPost?.currencyCode), "string"),
				payments_ExchangeRate_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, this.state.TM_GetSalesDraftPaymentForPost?.rateUsed), "number"),
				leadId_0: ReactSystemFunctions.convertToTypeByName(this.props.screenInputs.LeadId ?? this.props.screenInputs.leadid, "Guid"),
				draftId_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toGuid(this, ReactSystemFunctions.value(this, "talepsatisislemi_337380_value", "value", "", "", "")), "Guid"),
				userId_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.getMyUserId(), "Guid"),
				invoiceType_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, (stateVars.TM_GetSalesDraftForPost !== undefined ? (stateVars.TM_GetSalesDraftForPost?.length > 0 ? stateVars.TM_GetSalesDraftForPost[0].invoiceType : null) : (this.state.TM_GetSalesDraftForPost?.length > 0 ? this.state.TM_GetSalesDraftForPost[0].invoiceType : null))), "number"),
				description_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, (stateVars.TM_GetSalesDraftForPost !== undefined ? (stateVars.TM_GetSalesDraftForPost?.length > 0 ? stateVars.TM_GetSalesDraftForPost[0].taxFreeDescription : null) : (this.state.TM_GetSalesDraftForPost?.length > 0 ? this.state.TM_GetSalesDraftForPost[0].taxFreeDescription : null))), "string")
        }

if (ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, (stateVars.TM_SubmitThirdPartyInvoiceLeadApproval !== undefined ? (stateVars.TM_SubmitThirdPartyInvoiceLeadApproval?.length > 0 ? stateVars.TM_SubmitThirdPartyInvoiceLeadApproval[0].canInvoice : null) : (this.state.TM_SubmitThirdPartyInvoiceLeadApproval?.length > 0 ? this.state.TM_SubmitThirdPartyInvoiceLeadApproval[0].canInvoice : null))), ReactSystemFunctions.convertToTypeByName("True", "string"))) {
            		
        if (true) {
        KuikaAppManager.showSpinner(this);
        }
        let result = await KuikaAppManager.ApiRequest(this, "TalepSatisIslemi/TalepSatisIslemiComponent_761489_onClick1_", localVar)
        if (!KMainFunctions.IsResStatus2XX(result)) return true;

			stateVars.Send = result?.data.send;
			this.props.form?.setFieldsValue(formVars);
			
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.TalepSatisIslemiComponent_761489_onClick2_();
                  resolve();
                });
          })

        } else {
            
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.TalepSatisIslemiComponent_761489_onClick2_();
                  resolve();
                });
          })
        }


        
        KuikaAppManager.hideSpinner(this);
        return isErrorOccurred;
    }
    TalepSatisIslemiComponent_761489_onClick2_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
		KuikaAppManager.increaseServerRequestCount();

        let localVar = {
				templateId_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.convertToTypeByName("fecaea35-1baf-47cc-d88d-08df22b2240d", "string"), "string"),
				receivers_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, (stateVars.TM_SubmitThirdPartyInvoiceLeadApproval !== undefined ? (stateVars.TM_SubmitThirdPartyInvoiceLeadApproval?.length > 0 ? stateVars.TM_SubmitThirdPartyInvoiceLeadApproval[0].approverEmail : null) : (this.state.TM_SubmitThirdPartyInvoiceLeadApproval?.length > 0 ? this.state.TM_SubmitThirdPartyInvoiceLeadApproval[0].approverEmail : null))), "string"),
				subject_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.convertToTypeByName("Onayınız Gerekiyor | 3. Kişi Adına Faturalandırma", "string"), "string"),
				sender_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.convertToTypeByName("", "string"), "string"),
				cc_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.convertToTypeByName("", "string"), "string"),
				bcc_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.convertToTypeByName("", "string"), "string"),
				language_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.convertToTypeByName("", "string"), "string"),
				ApproverFullName_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, (stateVars.TM_SubmitThirdPartyInvoiceLeadApproval !== undefined ? (stateVars.TM_SubmitThirdPartyInvoiceLeadApproval?.length > 0 ? stateVars.TM_SubmitThirdPartyInvoiceLeadApproval[0].approverFullName : null) : (this.state.TM_SubmitThirdPartyInvoiceLeadApproval?.length > 0 ? this.state.TM_SubmitThirdPartyInvoiceLeadApproval[0].approverFullName : null))), "string"),
				RequestedByFullName_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, (stateVars.TM_SubmitThirdPartyInvoiceLeadApproval !== undefined ? (stateVars.TM_SubmitThirdPartyInvoiceLeadApproval?.length > 0 ? stateVars.TM_SubmitThirdPartyInvoiceLeadApproval[0].requestedByFullName : null) : (this.state.TM_SubmitThirdPartyInvoiceLeadApproval?.length > 0 ? this.state.TM_SubmitThirdPartyInvoiceLeadApproval[0].requestedByFullName : null))), "string"),
				ApprovalStatusText_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, (stateVars.TM_SubmitThirdPartyInvoiceLeadApproval !== undefined ? (stateVars.TM_SubmitThirdPartyInvoiceLeadApproval?.length > 0 ? stateVars.TM_SubmitThirdPartyInvoiceLeadApproval[0].approvalStatusText : null) : (this.state.TM_SubmitThirdPartyInvoiceLeadApproval?.length > 0 ? this.state.TM_SubmitThirdPartyInvoiceLeadApproval[0].approvalStatusText : null))), "string"),
				SalesDraftId_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "talepsatisislemi_337380_value", "value", "", "", "")), "string"),
				OriginalCustomerFullName_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, (stateVars.TM_SubmitThirdPartyInvoiceLeadApproval !== undefined ? (stateVars.TM_SubmitThirdPartyInvoiceLeadApproval?.length > 0 ? stateVars.TM_SubmitThirdPartyInvoiceLeadApproval[0].originalCustomerFullName : null) : (this.state.TM_SubmitThirdPartyInvoiceLeadApproval?.length > 0 ? this.state.TM_SubmitThirdPartyInvoiceLeadApproval[0].originalCustomerFullName : null))), "string"),
				OriginalCustomerCode_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, (stateVars.TM_SubmitThirdPartyInvoiceLeadApproval !== undefined ? (stateVars.TM_SubmitThirdPartyInvoiceLeadApproval?.length > 0 ? stateVars.TM_SubmitThirdPartyInvoiceLeadApproval[0].originalCustomerCode : null) : (this.state.TM_SubmitThirdPartyInvoiceLeadApproval?.length > 0 ? this.state.TM_SubmitThirdPartyInvoiceLeadApproval[0].originalCustomerCode : null))), "string"),
				StoreName_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, (stateVars.TM_SubmitThirdPartyInvoiceLeadApproval !== undefined ? (stateVars.TM_SubmitThirdPartyInvoiceLeadApproval?.length > 0 ? stateVars.TM_SubmitThirdPartyInvoiceLeadApproval[0].storeName : null) : (this.state.TM_SubmitThirdPartyInvoiceLeadApproval?.length > 0 ? this.state.TM_SubmitThirdPartyInvoiceLeadApproval[0].storeName : null))), "string"),
				TotalAmountEUR_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, (stateVars.TM_SubmitThirdPartyInvoiceLeadApproval !== undefined ? (stateVars.TM_SubmitThirdPartyInvoiceLeadApproval?.length > 0 ? stateVars.TM_SubmitThirdPartyInvoiceLeadApproval[0].totalAmountEUR : null) : (this.state.TM_SubmitThirdPartyInvoiceLeadApproval?.length > 0 ? this.state.TM_SubmitThirdPartyInvoiceLeadApproval[0].totalAmountEUR : null))), "string"),
				CurrencyCode_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, (stateVars.TM_SubmitThirdPartyInvoiceLeadApproval !== undefined ? (stateVars.TM_SubmitThirdPartyInvoiceLeadApproval?.length > 0 ? stateVars.TM_SubmitThirdPartyInvoiceLeadApproval[0].currencyCode : null) : (this.state.TM_SubmitThirdPartyInvoiceLeadApproval?.length > 0 ? this.state.TM_SubmitThirdPartyInvoiceLeadApproval[0].currencyCode : null))), "string"),
				SourceTypeText_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, (stateVars.TM_SubmitThirdPartyInvoiceLeadApproval !== undefined ? (stateVars.TM_SubmitThirdPartyInvoiceLeadApproval?.length > 0 ? stateVars.TM_SubmitThirdPartyInvoiceLeadApproval[0].sourceTypeText : null) : (this.state.TM_SubmitThirdPartyInvoiceLeadApproval?.length > 0 ? this.state.TM_SubmitThirdPartyInvoiceLeadApproval[0].sourceTypeText : null))), "string"),
				ThirdPartyFullName_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, (stateVars.TM_SubmitThirdPartyInvoiceLeadApproval !== undefined ? (stateVars.TM_SubmitThirdPartyInvoiceLeadApproval?.length > 0 ? stateVars.TM_SubmitThirdPartyInvoiceLeadApproval[0].thirdPartyFullName : null) : (this.state.TM_SubmitThirdPartyInvoiceLeadApproval?.length > 0 ? this.state.TM_SubmitThirdPartyInvoiceLeadApproval[0].thirdPartyFullName : null))), "string"),
				ThirdPartyCustomerCode_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, (stateVars.TM_SubmitThirdPartyInvoiceLeadApproval !== undefined ? (stateVars.TM_SubmitThirdPartyInvoiceLeadApproval?.length > 0 ? stateVars.TM_SubmitThirdPartyInvoiceLeadApproval[0].thirdPartyCustomerCode : null) : (this.state.TM_SubmitThirdPartyInvoiceLeadApproval?.length > 0 ? this.state.TM_SubmitThirdPartyInvoiceLeadApproval[0].thirdPartyCustomerCode : null))), "string"),
				CompanyName_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, (stateVars.TM_SubmitThirdPartyInvoiceLeadApproval !== undefined ? (stateVars.TM_SubmitThirdPartyInvoiceLeadApproval?.length > 0 ? stateVars.TM_SubmitThirdPartyInvoiceLeadApproval[0].companyName : null) : (this.state.TM_SubmitThirdPartyInvoiceLeadApproval?.length > 0 ? this.state.TM_SubmitThirdPartyInvoiceLeadApproval[0].companyName : null))), "string"),
				TaxNumber_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, (stateVars.TM_SubmitThirdPartyInvoiceLeadApproval !== undefined ? (stateVars.TM_SubmitThirdPartyInvoiceLeadApproval?.length > 0 ? stateVars.TM_SubmitThirdPartyInvoiceLeadApproval[0].taxNumber : null) : (this.state.TM_SubmitThirdPartyInvoiceLeadApproval?.length > 0 ? this.state.TM_SubmitThirdPartyInvoiceLeadApproval[0].taxNumber : null))), "string"),
				IdentityNumber_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, (stateVars.TM_SubmitThirdPartyInvoiceLeadApproval !== undefined ? (stateVars.TM_SubmitThirdPartyInvoiceLeadApproval?.length > 0 ? stateVars.TM_SubmitThirdPartyInvoiceLeadApproval[0].identityNumber : null) : (this.state.TM_SubmitThirdPartyInvoiceLeadApproval?.length > 0 ? this.state.TM_SubmitThirdPartyInvoiceLeadApproval[0].identityNumber : null))), "string"),
				Address_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, (stateVars.TM_SubmitThirdPartyInvoiceLeadApproval !== undefined ? (stateVars.TM_SubmitThirdPartyInvoiceLeadApproval?.length > 0 ? stateVars.TM_SubmitThirdPartyInvoiceLeadApproval[0].address : null) : (this.state.TM_SubmitThirdPartyInvoiceLeadApproval?.length > 0 ? this.state.TM_SubmitThirdPartyInvoiceLeadApproval[0].address : null))), "string"),
				ApprovalPageUrl_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, (stateVars.TM_SubmitThirdPartyInvoiceLeadApproval !== undefined ? (stateVars.TM_SubmitThirdPartyInvoiceLeadApproval?.length > 0 ? stateVars.TM_SubmitThirdPartyInvoiceLeadApproval[0].approvalPageUrl : null) : (this.state.TM_SubmitThirdPartyInvoiceLeadApproval?.length > 0 ? this.state.TM_SubmitThirdPartyInvoiceLeadApproval[0].approvalPageUrl : null))), "string")
        }

if (ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, (stateVars.TM_SubmitThirdPartyInvoiceLeadApproval !== undefined ? (stateVars.TM_SubmitThirdPartyInvoiceLeadApproval?.length > 0 ? stateVars.TM_SubmitThirdPartyInvoiceLeadApproval[0].shouldSendMail : null) : (this.state.TM_SubmitThirdPartyInvoiceLeadApproval?.length > 0 ? this.state.TM_SubmitThirdPartyInvoiceLeadApproval[0].shouldSendMail : null))), ReactSystemFunctions.convertToTypeByName("True", "string"))) {
            		
        if (true) {
        KuikaAppManager.showSpinner(this);
        }
        let result = await KuikaAppManager.ApiRequest(this, "TalepSatisIslemi/TalepSatisIslemiComponent_761489_onClick2_", localVar)
        if (!KMainFunctions.IsResStatus2XX(result)) return true;

			stateVars.SendMail = result?.data.sendMail;
			this.props.form?.setFieldsValue(formVars);
			
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.TalepSatisIslemiComponent_761489_onClick3_();
                  resolve();
                });
          })

        } else {
            
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.TalepSatisIslemiComponent_761489_onClick3_();
                  resolve();
                });
          })
        }


        
        KuikaAppManager.hideSpinner(this);
        return isErrorOccurred;
    }
		TalepSatisIslemiComponent_761489_onClick3_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }

				stateVars.Notify = await ReactSystemFunctions.notify(this, ReactSystemFunctions.toString(this, this.state.Send?.responseMessage), ReactSystemFunctions.convertToTypeByName("default", "string"), ReactSystemFunctions.convertToTypeByName("bottom-right", "string"), 3, ReactSystemFunctions.convertToTypeByName("", "string"), ReactSystemFunctions.convertToTypeByName("", "string"), 0);
				stateVars.Notify = await ReactSystemFunctions.notify(this, ReactSystemFunctions.toString(this, (stateVars.TM_SubmitThirdPartyInvoiceLeadApproval !== undefined ? (stateVars.TM_SubmitThirdPartyInvoiceLeadApproval?.length > 0 ? stateVars.TM_SubmitThirdPartyInvoiceLeadApproval[0].message : null) : (this.state.TM_SubmitThirdPartyInvoiceLeadApproval?.length > 0 ? this.state.TM_SubmitThirdPartyInvoiceLeadApproval[0].message : null))), ReactSystemFunctions.convertToTypeByName("default", "string"), ReactSystemFunctions.convertToTypeByName("bottom-right", "string"), 3, ReactSystemFunctions.convertToTypeByName("", "string"), ReactSystemFunctions.convertToTypeByName("", "string"), 0);

		this.props.form?.setFieldsValue(formVars);
		
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.TalepSatisIslemiComponent_761489_onClick4_();
                  resolve();
                });
          })

            
            return isErrorOccurred;
        }
		TalepSatisIslemiComponent_761489_onClick4_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
if (ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, this.state.Send?.isSuccess), "1")) {
            
					KuikaAppManager.prepareForNavigation();
						KuikaAppManager.addToPageInputVariables("LeadSatisBasariliPop", "LeadSalesDraftId", ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, (stateVars.TM_GetSalesDraftForPost !== undefined ? (stateVars.TM_GetSalesDraftForPost?.length > 0 ? stateVars.TM_GetSalesDraftForPost[0].id : null) : (this.state.TM_GetSalesDraftForPost?.length > 0 ? this.state.TM_GetSalesDraftForPost[0].id : null))), "Guid"));

				stateVars.NAVIGATE = await ReactSystemFunctions.navigate(this, this.TalepSatisIslemiComponent_761489_onClick5_, "TalepSatisIslemi", "LeadSatisBasariliPop", "", "currentPage", null, null, null, null, null, null, true, false);

		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

        } else {
            
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.TalepSatisIslemiComponent_761489_onClick5_();
                  resolve();
                });
          })
        }

            
            return isErrorOccurred;
        }
		TalepSatisIslemiComponent_761489_onClick5_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
if (ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, (stateVars.TM_SubmitThirdPartyInvoiceLeadApproval !== undefined ? (stateVars.TM_SubmitThirdPartyInvoiceLeadApproval?.length > 0 ? stateVars.TM_SubmitThirdPartyInvoiceLeadApproval[0].canInvoice : null) : (this.state.TM_SubmitThirdPartyInvoiceLeadApproval?.length > 0 ? this.state.TM_SubmitThirdPartyInvoiceLeadApproval[0].canInvoice : null))), false)) {
            KuikaAppManager.showSpinner(this);

					KuikaAppManager.prepareForNavigation();

				stateVars.NAVIGATE = await ReactSystemFunctions.navigate(this, undefined, "TalepSatisIslemi", "OnayaGonderdigimSatislar", "", "currentPage", null, null, null, null, null, null, true, false);

		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

        } else {
            KuikaAppManager.hideSpinner(this);
        }

            
            return isErrorOccurred;
        }










		TalepSatisIslemiComponent_516749_onChange = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
KuikaAppManager.showSpinner(this);

				stateVars.isComp170159Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "talepsatisislemi_516749_value", "value", "", "key", "")), "2")) === true ? "visible" : "hidden")

		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

            
            return isErrorOccurred;
        }


		TalepSatisIslemiComponent_1299000195_onChange = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
KuikaAppManager.showSpinner(this);

				stateVars.isComp287429939Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "talepsatisislemi_1299000195_checked", "checked", "", "", "")), true)) === true ? "visible" : "hidden")

		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

            
            return isErrorOccurred;
        }


		TalepSatisIslemiComponent_1685705311_onChange = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
KuikaAppManager.showSpinner(this);

				stateVars.isComp1720847430Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "talepsatisislemi_1685705311_value", "value", "", "key", "")), "PERSON")) === true ? "visible" : "hidden")
				stateVars.isComp61094802Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "talepsatisislemi_1685705311_value", "value", "", "key", "")), "COMPANY")) === true ? "visible" : "hidden")
				stateVars.isComp1289654211Visible = ((ReactSystemFunctions.isNotEmpty(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "talepsatisislemi_1685705311_value", "value", "", "key", "")), true)) === true ? "visible" : "hidden")
				stateVars.isComp487685649Visible = ((ReactSystemFunctions.isNotEmpty(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "talepsatisislemi_1685705311_value", "value", "", "key", "")), true)) === true ? "visible" : "hidden")

		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

            
            return isErrorOccurred;
        }


		TalepSatisIslemiComponent_337380_onChange = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
KuikaAppManager.showSpinner(this);

				stateVars.isComp684346Enabled = ((ReactSystemFunctions.isNotEmpty(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "talepsatisislemi_337380_value", "value", "", "", "")), true)) === true ? "enabled" : "disabled")

		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

            
            return isErrorOccurred;
        }




    async callCallbackFunction(diId: number, isFromMaster: boolean = false) {
        let isErrorOccurred = false;
		let pageInitCallerNavDiIDs = [, ] as number[];
		if (isFromMaster || pageInitCallerNavDiIDs.indexOf(diId) > -1) {
			await this.TalepSatisIslemiPageInit();
		}

    }


}
