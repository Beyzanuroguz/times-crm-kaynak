import React from "react";
import Axios, { AxiosResponse } from "axios";
import { KuikaAppManager } from "../../shared/utilty/kuika-app-manager";
import { ReactSystemFunctions } from "../../shared/utilty/react-system-functions";
import { KNavigator } from "../../shared/hoc/with-history";
import { KContext } from "../../shared/hoc/with-context";
import { useLocation } from "react-router-dom";
import { FormInstance } from "antd/es/form";
import { Guid } from "guid-typescript";
import Swal from "sweetalert2";
import { KMainFunctions } from "../../shared/utilty/main-functions";
import moment from "moment";
import { IValidationData } from "../../models/dto/validation-data";
import { IStripePayment } from "../../models/dto/stripe-payment";
import { IUserInfoDto } from "../../models/dto/user-info.dto";
import { UserService } from "../../services/user-service";
import { kuikaCoreWasmBridgeService } from "../../services/_singletons";
import _ from "lodash";
import mqtt, { MqttClient } from "mqtt";
import { IMqttResult } from "../../models/dto/mqtt.dto";
import { MasterScreen_ScreenContext } from "../masterscreen/masterscreen-context";

declare let window: any;

export interface IMontBlancBasedReporting_ScreenProps {
  navigator: KNavigator;
  form: FormInstance<any>;
  googleLogin: any;
  screenInputs: any;
  context: KContext;
  initialValues: any;
  children: any;
}

export interface IMontBlancBasedReporting_ScreenState {
    isSpinnerVisible: boolean;
    isPageVisible: boolean;
	isLeftMenuVisible: boolean;
    spinnerCount: number;
    selectedLanguage: string;
    isPageInitLoaded: false;
    isPageRecurringLoaded: false;
	KuikaY_MonthlyStoreSalesReport: any[];
	KuikaY_MonthlyStoreSalesReport_dummy: any[];
	KuikaY_GetProductGroupsByBrand: any[];
	KuikaY_GetProductGroupsByBrand_dummy: any[];
	Kuika_ReportProductSales: any[];
	Kuika_ReportProductSales_dummy: any[];
	KuikaY_MontBlancAylikSatisKarsilastirma: any[];
	KuikaY_MontBlancAylikSatisKarsilastirma_dummy: any[];
	NAVIGATE: any;
	NAVIGATE_dummy: any;
	ExportExcel: any;
	ExportExcel_dummy: any;
	isComp209508Visible: 'visible' | 'hidden';
	isComp479325Visible: 'visible' | 'hidden';
	isComp483040Visible: 'visible' | 'hidden';
	isComp467053Visible: 'visible' | 'hidden';
	isComp85453Visible: 'visible' | 'hidden';
	isComp243475Visible: 'visible' | 'hidden';
	isComp655623Visible: 'visible' | 'hidden';
	isComp10207Visible: 'visible' | 'hidden';
	isComp862930Visible: 'visible' | 'hidden';
	isComp61795Visible: 'visible' | 'hidden';
	isComp516985Visible: 'visible' | 'hidden';
	isComp510423Visible: 'visible' | 'hidden';
	isComp782468Visible: 'visible' | 'hidden';
	isComp547590Visible: 'visible' | 'hidden';
	isComp644641Visible: 'visible' | 'hidden';
	isComp553499Visible: 'visible' | 'hidden';
	isComp579271Visible: 'visible' | 'hidden';
	isComp972772Visible: 'visible' | 'hidden';
	isComp394513Visible: 'visible' | 'hidden';
	isComp808797Visible: 'visible' | 'hidden';
	isComp647560Visible: 'visible' | 'hidden';
	isComp500376Visible: 'visible' | 'hidden';
	isComp548762Visible: 'visible' | 'hidden';
	isComp427864Visible: 'visible' | 'hidden';
	isComp368667Visible: 'visible' | 'hidden';
	isComp351992Visible: 'visible' | 'hidden';
	isComp742085Visible: 'visible' | 'hidden';
	isComp29797Visible: 'visible' | 'hidden';

}

export class MontBlancBasedReporting_ScreenBase extends React.PureComponent<IMontBlancBasedReporting_ScreenProps, any> {
    static contextType = MasterScreen_ScreenContext;
    declare context: React.ContextType<typeof MasterScreen_ScreenContext>;
	montblancbasedreporting_540654_value_kuikaAutoCompleteRef: React.RefObject<any>;
	montblancbasedreporting_739514_value_kuikaAutoCompleteRef: React.RefObject<any>;
	montblancbasedreporting_893983_value_kuikaTableRef: React.RefObject<any>;
	montblancbasedreporting_784292_value_kuikaTableRef: React.RefObject<any>;
	montblancbasedreporting_176274_value_kuikaTableRef: React.RefObject<any>;
	montblancbasedreporting_307852_value_kuikaTableRef: React.RefObject<any>;
	montblancbasedreporting_360771_value_kuikaTableRef: React.RefObject<any>;
	montblancbasedreporting_414298_value_kuikaTableRef: React.RefObject<any>;
	montblancbasedreporting_905708_value_kuikaTableRef: React.RefObject<any>;
	montblancbasedreporting_534055_value_kuikaTableRef: React.RefObject<any>;
	montblancbasedreporting_829642_value_kuikaTableRef: React.RefObject<any>;
	montblancbasedreporting_918728_value_kuikaTableRef: React.RefObject<any>;
	montblancbasedreporting_415490_value_kuikaTableRef: React.RefObject<any>;
	montblancbasedreporting_457709_value_kuikaTableRef: React.RefObject<any>;
	montblancbasedreporting_759335_value_kuikaTableRef: React.RefObject<any>;
    ml=[{"Id":"d5a61d2b-bd60-485f-86e2-661e9ed4e486","Name":"en_US","ShortName":"English","IsDefault":true,"LanguagePhrases":[]},{"Id":"fffc9327-bcc1-447f-afd4-c2ac80003415","Name":"FixedValues","ShortName":"FixedValues","LanguagePhrases":[{"Id":910240,"PropertyName":"value","Value":"Marka Bazlı Raporlama"},{"Id":869891,"PropertyName":"value","Value":"Mağaza satış performanslarını karşılaştırmalı olarak analiz edin."},{"Id":747637,"PropertyName":"label","Value":"Rolex"},{"Id":751032,"PropertyName":"label","Value":"Tudor"},{"Id":75005,"PropertyName":"label","Value":"Mont Blanc"},{"Id":18803,"PropertyName":"label","Value":"Dupont"},{"Id":126713,"PropertyName":"value","Value":"Analiz Tipi"},{"Id":248363,"PropertyName":"value","Value":"Genel Satış"},{"Id":677300,"PropertyName":"value","Value":"Mont Blanc-"},{"Id":573994,"PropertyName":"value","Value":"-Mağaza Bazlı Satış Özet Görünüm"},{"Id":237307,"PropertyName":"value","Value":"Yıl"},{"Id":149507,"PropertyName":"placeholder","Value":"Select Year..."},{"Id":314890,"PropertyName":"value","Value":"Ürün Grubu"},{"Id":540654,"PropertyName":"placeholder","Value":"Tümü"},{"Id":37878,"PropertyName":"value","Value":"Toplam Satış Adedi"},{"Id":833488,"PropertyName":"value","Value":"+18.5%"},{"Id":232881,"PropertyName":"value","Value":"-18.5%"},{"Id":48790,"PropertyName":"value","Value":"Bu Ayın Satış Adeti"},{"Id":793158,"PropertyName":"value","Value":"+18.5%"},{"Id":268030,"PropertyName":"value","Value":"-18.5%"},{"Id":609778,"PropertyName":"value","Value":"Geçen Yıla Göre Artış"},{"Id":134804,"PropertyName":"value","Value":"Yıllık Büyüme"},{"Id":833729,"PropertyName":"value","Value":"En Güçlü Mağaza"},{"Id":111309,"PropertyName":"value","Value":"En Çok Satan Family"},{"Id":316216,"PropertyName":"value","Value":"En Çok Satan Material"},{"Id":149762,"PropertyName":"value","Value":"Mont Blanc-"},{"Id":344996,"PropertyName":"value","Value":"-Mağaza Bazlı Satış Özet Görünüm"},{"Id":426975,"PropertyName":"value","Value":"Yıl"},{"Id":25286,"PropertyName":"placeholder","Value":"Select Year..."},{"Id":542140,"PropertyName":"value","Value":"Ürün Grubu"},{"Id":739514,"PropertyName":"placeholder","Value":"Tümü"},{"Id":721379,"PropertyName":"title","Value":"Mağaza"},{"Id":62374,"PropertyName":"value","Value":"[datafield:magaza]"},{"Id":650524,"PropertyName":"title","Value":"Ocak"},{"Id":82099,"PropertyName":"value","Value":"[datafield:ocak]"},{"Id":617500,"PropertyName":"title","Value":"Şubat"},{"Id":325336,"PropertyName":"value","Value":"[datafield:subat]"},{"Id":12539,"PropertyName":"title","Value":"Mart"},{"Id":120352,"PropertyName":"value","Value":"[datafield:mart]"},{"Id":279215,"PropertyName":"title","Value":"Nisan"},{"Id":199347,"PropertyName":"value","Value":"[datafield:nisan]"},{"Id":320849,"PropertyName":"title","Value":"Mayıs"},{"Id":165579,"PropertyName":"value","Value":"[datafield:mayis]"},{"Id":232430,"PropertyName":"title","Value":"Haziran"},{"Id":612285,"PropertyName":"value","Value":"[datafield:haziran]"},{"Id":336475,"PropertyName":"title","Value":"Temmuz"},{"Id":176653,"PropertyName":"value","Value":"[datafield:temmuz]"},{"Id":384771,"PropertyName":"title","Value":"Ağustos"},{"Id":30049,"PropertyName":"value","Value":"[datafield:agustos]"},{"Id":176644,"PropertyName":"title","Value":"Eylül"},{"Id":849638,"PropertyName":"value","Value":"[datafield:eylul]"},{"Id":992766,"PropertyName":"title","Value":"Ekim"},{"Id":890223,"PropertyName":"value","Value":"[datafield:ekim]"},{"Id":393458,"PropertyName":"title","Value":"Kasım"},{"Id":468050,"PropertyName":"value","Value":"[datafield:kasim]"},{"Id":312645,"PropertyName":"title","Value":"Aralık"},{"Id":423743,"PropertyName":"value","Value":"[datafield:aralik]"},{"Id":102746,"PropertyName":"title","Value":"Toplam"},{"Id":815910,"PropertyName":"value","Value":"[datafield:toplam]"},{"Id":30443,"PropertyName":"value","Value":"Aylık Satış Raporları - Mont Blanc"},{"Id":782720,"PropertyName":"value","Value":"Yıl 1"},{"Id":625329,"PropertyName":"placeholder","Value":"Select Year..."},{"Id":833803,"PropertyName":"value","Value":"Yıl 2"},{"Id":996749,"PropertyName":"placeholder","Value":"Select Year..."},{"Id":148344,"PropertyName":"label","Value":"Çalıştır"},{"Id":774441,"PropertyName":"value","Value":"Ocak/"},{"Id":559394,"PropertyName":"value","Value":"-"},{"Id":522937,"PropertyName":"title","Value":"Mağaza"},{"Id":800019,"PropertyName":"value","Value":"[datafield:magaza]"},{"Id":711726,"PropertyName":"value","Value":"[datafield:ocakadet2025]"},{"Id":725473,"PropertyName":"value","Value":"[datafield:ocakadet2026]"},{"Id":356960,"PropertyName":"title","Value":"Değişim"},{"Id":85453,"PropertyName":"value","Value":"[datafield:ocakadetdegisim]"},{"Id":243475,"PropertyName":"value","Value":"[datafield:ocakadetdegisim]"},{"Id":675472,"PropertyName":"value","Value":"Şubat/"},{"Id":6204,"PropertyName":"value","Value":"-"},{"Id":908510,"PropertyName":"title","Value":"Mağaza"},{"Id":898400,"PropertyName":"value","Value":"[datafield:magaza]"},{"Id":458590,"PropertyName":"value","Value":"[datafield:subatadet2025]"},{"Id":709000,"PropertyName":"value","Value":"[datafield:subatadet2026]"},{"Id":562223,"PropertyName":"title","Value":"Değişim"},{"Id":655623,"PropertyName":"value","Value":"[datafield:subatadetdegisim]"},{"Id":10207,"PropertyName":"value","Value":"[datafield:subatadetdegisim]"},{"Id":687359,"PropertyName":"value","Value":"Mart/"},{"Id":616196,"PropertyName":"value","Value":"-"},{"Id":894723,"PropertyName":"title","Value":"Mağaza"},{"Id":325531,"PropertyName":"value","Value":"[datafield:magaza]"},{"Id":693760,"PropertyName":"value","Value":"[datafield:martadet2025]"},{"Id":121360,"PropertyName":"value","Value":"[datafield:martadet2026]"},{"Id":848690,"PropertyName":"title","Value":"Değişim"},{"Id":862930,"PropertyName":"value","Value":"[datafield:martadetdegisim]"},{"Id":61795,"PropertyName":"value","Value":"[datafield:martadetdegisim]"},{"Id":166324,"PropertyName":"value","Value":"Nisan/"},{"Id":71153,"PropertyName":"value","Value":"-"},{"Id":866038,"PropertyName":"title","Value":"Mağaza"},{"Id":29640,"PropertyName":"value","Value":"[datafield:magaza]"},{"Id":566947,"PropertyName":"value","Value":"[datafield:nisanadet2025]"},{"Id":156696,"PropertyName":"value","Value":"[datafield:nisanadet2026]"},{"Id":673043,"PropertyName":"title","Value":"Değişim"},{"Id":516985,"PropertyName":"value","Value":"[datafield:nisanadetdegisim]"},{"Id":510423,"PropertyName":"value","Value":"[datafield:nisanadetdegisim]"},{"Id":844700,"PropertyName":"value","Value":"Mayıs/"},{"Id":529248,"PropertyName":"value","Value":"-"},{"Id":640605,"PropertyName":"title","Value":"Mağaza"},{"Id":838030,"PropertyName":"value","Value":"[datafield:magaza]"},{"Id":36139,"PropertyName":"value","Value":"[datafield:mayisadet2025]"},{"Id":715349,"PropertyName":"value","Value":"[datafield:mayisadet2026]"},{"Id":318972,"PropertyName":"title","Value":"Değişim"},{"Id":782468,"PropertyName":"value","Value":"[datafield:mayisadetdegisim]"},{"Id":547590,"PropertyName":"value","Value":"[datafield:mayisadetdegisim]"},{"Id":333927,"PropertyName":"value","Value":"Haziran/"},{"Id":550003,"PropertyName":"value","Value":"-"},{"Id":75827,"PropertyName":"title","Value":"Mağaza"},{"Id":63262,"PropertyName":"value","Value":"[datafield:magaza]"},{"Id":9591,"PropertyName":"value","Value":"[datafield:haziranadet2025]"},{"Id":526987,"PropertyName":"value","Value":"[datafield:haziranadet2026]"},{"Id":904636,"PropertyName":"title","Value":"Değişim"},{"Id":644641,"PropertyName":"value","Value":"[datafield:haziranadetdegisim]"},{"Id":553499,"PropertyName":"value","Value":"[datafield:haziranadetdegisim]"},{"Id":936163,"PropertyName":"value","Value":"Temmuz/"},{"Id":730078,"PropertyName":"value","Value":"-"},{"Id":144116,"PropertyName":"title","Value":"Mağaza"},{"Id":586893,"PropertyName":"value","Value":"[datafield:magaza]"},{"Id":892895,"PropertyName":"value","Value":"[datafield:temmuzadet2025]"},{"Id":646336,"PropertyName":"value","Value":"[datafield:temmuzadet2026]"},{"Id":187739,"PropertyName":"title","Value":"Değişim"},{"Id":579271,"PropertyName":"value","Value":"[datafield:temmuzadetdegisim]"},{"Id":972772,"PropertyName":"value","Value":"[datafield:temmuzadetdegisim]"},{"Id":828993,"PropertyName":"value","Value":"Ağustos/"},{"Id":343982,"PropertyName":"value","Value":"-"},{"Id":213625,"PropertyName":"title","Value":"Mağaza"},{"Id":478125,"PropertyName":"value","Value":"[datafield:magaza]"},{"Id":163763,"PropertyName":"value","Value":"[datafield:agustosadet2025]"},{"Id":173441,"PropertyName":"value","Value":"[datafield:agustosadet2026]"},{"Id":41920,"PropertyName":"title","Value":"Değişim"},{"Id":394513,"PropertyName":"value","Value":"[datafield:agustosadetdegisim]"},{"Id":808797,"PropertyName":"value","Value":"[datafield:agustosadetdegisim]"},{"Id":437295,"PropertyName":"value","Value":"Eylül/"},{"Id":567404,"PropertyName":"value","Value":"-"},{"Id":430988,"PropertyName":"title","Value":"Mağaza"},{"Id":768686,"PropertyName":"value","Value":"[datafield:magaza]"},{"Id":821748,"PropertyName":"value","Value":"[datafield:eyluladet2025]"},{"Id":973675,"PropertyName":"value","Value":"[datafield:eyluladet2026]"},{"Id":11590,"PropertyName":"title","Value":"Değişim"},{"Id":647560,"PropertyName":"value","Value":"[datafield:eyluladetdegisim]"},{"Id":500376,"PropertyName":"value","Value":"[datafield:eyluladetdegisim]"},{"Id":57816,"PropertyName":"value","Value":"Ekim/"},{"Id":18232,"PropertyName":"value","Value":"-"},{"Id":240935,"PropertyName":"title","Value":"Mağaza"},{"Id":798505,"PropertyName":"value","Value":"[datafield:magaza]"},{"Id":642718,"PropertyName":"value","Value":"[datafield:ekimadet2025]"},{"Id":448168,"PropertyName":"value","Value":"[datafield:ekimadet2026]"},{"Id":516197,"PropertyName":"title","Value":"Değişim"},{"Id":548762,"PropertyName":"value","Value":"[datafield:ekimadetdegisim]"},{"Id":427864,"PropertyName":"value","Value":"[datafield:ekimadetdegisim]"},{"Id":767190,"PropertyName":"value","Value":"Kasım/"},{"Id":100120,"PropertyName":"value","Value":"-"},{"Id":255344,"PropertyName":"title","Value":"Mağaza"},{"Id":195509,"PropertyName":"value","Value":"[datafield:magaza]"},{"Id":514347,"PropertyName":"value","Value":"[datafield:kasimadet2025]"},{"Id":283191,"PropertyName":"value","Value":"[datafield:kasimadet2026]"},{"Id":526432,"PropertyName":"title","Value":"Değişim"},{"Id":368667,"PropertyName":"value","Value":"[datafield:kasimadetdegisim]"},{"Id":351992,"PropertyName":"value","Value":"[datafield:kasimadetdegisim]"},{"Id":890782,"PropertyName":"value","Value":"Aralık/"},{"Id":279470,"PropertyName":"value","Value":"-"},{"Id":737085,"PropertyName":"title","Value":"Mağaza"},{"Id":707243,"PropertyName":"value","Value":"[datafield:magaza]"},{"Id":901209,"PropertyName":"value","Value":"[datafield:aralikadet2025]"},{"Id":192757,"PropertyName":"value","Value":"[datafield:aralikadet2026]"},{"Id":79107,"PropertyName":"title","Value":"Değişim"},{"Id":742085,"PropertyName":"value","Value":"[datafield:aralikadetdegisim]"},{"Id":29797,"PropertyName":"value","Value":"[datafield:aralikadetdegisim]"}]}]
    defaultML = "en_US"
    
    screenHash = ""
    

    private _prevMasterPageInitLoaded: boolean = false;
    private _prevMasterPageRecurringLoaded: boolean = false;
    private _prevShouldTriggerPageInit: boolean = false;
    constructor(props) {
        super(props);
		this.montblancbasedreporting_540654_value_kuikaAutoCompleteRef = React.createRef();
		this.montblancbasedreporting_739514_value_kuikaAutoCompleteRef = React.createRef();
		this.montblancbasedreporting_893983_value_kuikaTableRef = React.createRef();
		this.montblancbasedreporting_784292_value_kuikaTableRef = React.createRef();
		this.montblancbasedreporting_176274_value_kuikaTableRef = React.createRef();
		this.montblancbasedreporting_307852_value_kuikaTableRef = React.createRef();
		this.montblancbasedreporting_360771_value_kuikaTableRef = React.createRef();
		this.montblancbasedreporting_414298_value_kuikaTableRef = React.createRef();
		this.montblancbasedreporting_905708_value_kuikaTableRef = React.createRef();
		this.montblancbasedreporting_534055_value_kuikaTableRef = React.createRef();
		this.montblancbasedreporting_829642_value_kuikaTableRef = React.createRef();
		this.montblancbasedreporting_918728_value_kuikaTableRef = React.createRef();
		this.montblancbasedreporting_415490_value_kuikaTableRef = React.createRef();
		this.montblancbasedreporting_457709_value_kuikaTableRef = React.createRef();
		this.montblancbasedreporting_759335_value_kuikaTableRef = React.createRef();

        this.state = {
            isSpinnerVisible: false,
            isPageVisible: false,
            isLeftMenuVisible: false,
            spinnerCount: 0,
            selectedLanguage: "",
            isPageInitLoaded: false,
            isPageRecurringLoaded: false,
            	        KuikaY_MonthlyStoreSalesReport: [],
	        KuikaY_GetProductGroupsByBrand: [],
	        Kuika_ReportProductSales: [],
	        KuikaY_MontBlancAylikSatisKarsilastirma: [],
	        NAVIGATE: "",
	        ExportExcel: "",
	        isComp209508Visible: 'hidden',
	        isComp479325Visible: 'hidden',
	        isComp483040Visible: 'hidden',
	        isComp467053Visible: 'hidden',
	        isComp85453Visible: 'hidden',
	        isComp243475Visible: 'hidden',
	        isComp655623Visible: 'hidden',
	        isComp10207Visible: 'hidden',
	        isComp862930Visible: 'hidden',
	        isComp61795Visible: 'hidden',
	        isComp516985Visible: 'hidden',
	        isComp510423Visible: 'hidden',
	        isComp782468Visible: 'hidden',
	        isComp547590Visible: 'hidden',
	        isComp644641Visible: 'hidden',
	        isComp553499Visible: 'hidden',
	        isComp579271Visible: 'hidden',
	        isComp972772Visible: 'hidden',
	        isComp394513Visible: 'hidden',
	        isComp808797Visible: 'hidden',
	        isComp647560Visible: 'hidden',
	        isComp500376Visible: 'hidden',
	        isComp548762Visible: 'hidden',
	        isComp427864Visible: 'hidden',
	        isComp368667Visible: 'hidden',
	        isComp351992Visible: 'hidden',
	        isComp742085Visible: 'hidden',
	        isComp29797Visible: 'hidden',

        }

        this.state.isPageVisible = true;
        
    }

    async componentDidMount() {

        if (KuikaAppManager.isPageInitPrevented()) {
            KuikaAppManager.calculateAndSetBodyHeight("montblancbasedreporting", "masterscreen_screen");
            return;
        }
        this.context.registerCallbackFunction(this.callCallbackFunction.bind(this));
        
        ReactSystemFunctions.validateToken()
        this.fillFormInitValues();
        if (false){
            await this.MontBlancBasedReportingPageInit();
        } else if (this.context?.isMasterPageInitLoaded) { this._prevMasterPageInitLoaded = true; await this.MontBlancBasedReportingPageInit(); }
        
        
        
        KuikaAppManager.calculateAndSetBodyHeight("montblancbasedreporting", "masterscreen_screen");

        if (ReactSystemFunctions.getIsMicroApp() === false) {
           window.parentScreen = this;
        }
    }

    componentWillUnmount() {
        
        
        

        if (ReactSystemFunctions.getIsMicroApp() === false) {
           window.parentScreen = null;
        }
    }

    

        
    componentDidUpdate= async (prevProps, prevState) => {
		KuikaAppManager.calculateAndSetBodyHeight("montblancbasedreporting", "masterscreen_screen"    );
        if (prevProps?.location?.search !== (this.props as any)?.location?.search) {
			await this.MontBlancBasedReportingPageInit();
		}

        		if (this._prevMasterPageInitLoaded !== this.context.isMasterPageInitLoaded && this.context.isMasterPageInitLoaded === true) {this._prevMasterPageInitLoaded = this.context.isMasterPageInitLoaded;await this.MontBlancBasedReportingPageInit()}


        if (ReactSystemFunctions.getIsMicroApp() === false) {
            for (const key in prevState) {
                if (key.startsWith('NavVisible') && prevState[key] === true && this.state[key] === false) {
                    window.parentScreen = this;
                    break;
                }
            }
        }
	}

    fillFormInitValues() {
        this.props.form?.setFieldsValue({
});

    }

      setPageInitLoaded = (value: boolean) => {
        this.setState({ isPageInitLoaded: value });
      }

      setPageRecurringLoaded = (value: boolean) => {
        this.setState({ isPageRecurringLoaded: value });
      }

      clearFieldValidation = (changedValues: any) => {
        const fieldName = Object.keys(changedValues)[0];
        if (fieldName) {
          this.props.form?.setFields([
            {
              name: fieldName,
              errors: []
            }
          ]);
        }
      };

      

    MontBlancBasedReportingPageInit = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


	if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }

        let localVar = {
			Brand_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.convertToTypeByName("Mont Blanc", "string"), "string"),
			ProductGroup_0: ReactSystemFunctions.convertToTypeByName("", "string"),
			Year_0: ReactSystemFunctions.convertToTypeByName(2026, "number"),
			Brand_1: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.convertToTypeByName("Mont Blanc", "string"), "string"),
			Marka_2: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.convertToTypeByName("Mont Blanc", "string"), "string"),
			UrunGrubu_2: ReactSystemFunctions.convertToTypeByName("", "string"),
			Year_2: ReactSystemFunctions.convertToTypeByName(2026, "number"),
			Year1_3: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "montblancbasedreporting_625329_value", "value", "", "", "")), "number"),
			Year2_3: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "montblancbasedreporting_996749_value", "value", "", "", "")), "number")
        }

	KuikaAppManager.showSpinner(this);
	
        if (true) {
        KuikaAppManager.showSpinner(this);
        }
        let result = await KuikaAppManager.ApiRequest(this, "MontBlancBasedReporting/MontBlancBasedReportingPageInit", localVar)
        if (!KMainFunctions.IsResStatus2XX(result)) return true;

		stateVars.KuikaY_MonthlyStoreSalesReport = result?.data.kuikaY_MonthlyStoreSalesReport;
		
		stateVars.KuikaY_GetProductGroupsByBrand = result?.data.kuikaY_GetProductGroupsByBrand;
		
		formVars.montblancbasedreporting_540654_options = stateVars.KuikaY_GetProductGroupsByBrand;
		
		formVars.montblancbasedreporting_739514_options = stateVars.KuikaY_GetProductGroupsByBrand;
		stateVars.Kuika_ReportProductSales = result?.data.kuika_ReportProductSales;
		formVars.montblancbasedreporting_142273_value = ReactSystemFunctions.toString(this, (stateVars.Kuika_ReportProductSales !== undefined ? (stateVars.Kuika_ReportProductSales?.length > 0 ? stateVars.Kuika_ReportProductSales[0].toplamSatisAdedi : null) : (this.state.Kuika_ReportProductSales?.length > 0 ? this.state.Kuika_ReportProductSales[0].toplamSatisAdedi : null)));
		formVars.montblancbasedreporting_862873_value = ReactSystemFunctions.toString(this, (stateVars.Kuika_ReportProductSales !== undefined ? (stateVars.Kuika_ReportProductSales?.length > 0 ? stateVars.Kuika_ReportProductSales[0].bulundugumuzAySatisAdedi : null) : (this.state.Kuika_ReportProductSales?.length > 0 ? this.state.Kuika_ReportProductSales[0].bulundugumuzAySatisAdedi : null)));
		formVars.montblancbasedreporting_442377_value = ReactSystemFunctions.toString(this, (stateVars.Kuika_ReportProductSales !== undefined ? (stateVars.Kuika_ReportProductSales?.length > 0 ? stateVars.Kuika_ReportProductSales[0].gecenYilaGoreArtisYuzde : null) : (this.state.Kuika_ReportProductSales?.length > 0 ? this.state.Kuika_ReportProductSales[0].gecenYilaGoreArtisYuzde : null)));
		formVars.montblancbasedreporting_49365_value = ReactSystemFunctions.toString(this, (stateVars.Kuika_ReportProductSales !== undefined ? (stateVars.Kuika_ReportProductSales?.length > 0 ? stateVars.Kuika_ReportProductSales[0].enGucluMagazaDesc : null) : (this.state.Kuika_ReportProductSales?.length > 0 ? this.state.Kuika_ReportProductSales[0].enGucluMagazaDesc : null)));
		formVars.montblancbasedreporting_689773_value = ReactSystemFunctions.toString(this, (stateVars.Kuika_ReportProductSales !== undefined ? (stateVars.Kuika_ReportProductSales?.length > 0 ? stateVars.Kuika_ReportProductSales[0].enGucluMagazaCiro : null) : (this.state.Kuika_ReportProductSales?.length > 0 ? this.state.Kuika_ReportProductSales[0].enGucluMagazaCiro : null)));
		formVars.montblancbasedreporting_662229_value = ReactSystemFunctions.toString(this, (stateVars.Kuika_ReportProductSales !== undefined ? (stateVars.Kuika_ReportProductSales?.length > 0 ? stateVars.Kuika_ReportProductSales[0].enCokSatanFamily : null) : (this.state.Kuika_ReportProductSales?.length > 0 ? this.state.Kuika_ReportProductSales[0].enCokSatanFamily : null)));
		formVars.montblancbasedreporting_825140_value = ReactSystemFunctions.toString(this, (stateVars.Kuika_ReportProductSales !== undefined ? (stateVars.Kuika_ReportProductSales?.length > 0 ? stateVars.Kuika_ReportProductSales[0].enCokSatanFamilyAdet : null) : (this.state.Kuika_ReportProductSales?.length > 0 ? this.state.Kuika_ReportProductSales[0].enCokSatanFamilyAdet : null)));
		formVars.montblancbasedreporting_51555_value = ReactSystemFunctions.toString(this, (stateVars.Kuika_ReportProductSales !== undefined ? (stateVars.Kuika_ReportProductSales?.length > 0 ? stateVars.Kuika_ReportProductSales[0].enCokSatanMaterial : null) : (this.state.Kuika_ReportProductSales?.length > 0 ? this.state.Kuika_ReportProductSales[0].enCokSatanMaterial : null)));
		formVars.montblancbasedreporting_816749_value = ReactSystemFunctions.toString(this, (stateVars.Kuika_ReportProductSales !== undefined ? (stateVars.Kuika_ReportProductSales?.length > 0 ? stateVars.Kuika_ReportProductSales[0].enCokSatanMaterialCiro : null) : (this.state.Kuika_ReportProductSales?.length > 0 ? this.state.Kuika_ReportProductSales[0].enCokSatanMaterialCiro : null)));
		stateVars.KuikaY_MontBlancAylikSatisKarsilastirma = result?.data.kuikaY_MontBlancAylikSatisKarsilastirma;
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		this.props.form?.setFieldsValue(formVars);
		
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.MontBlancBasedReportingPageInit1_();
                  resolve();
                });
          })



        
        KuikaAppManager.hideSpinner(this);
        return isErrorOccurred;
    }
	MontBlancBasedReportingPageInit1_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


	if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }

			ReactSystemFunctions.setValueOf(this, "montblancbasedreporting_282961_toString", ReactSystemFunctions.value(this, "montblancbasedreporting_149507_value", "value"), "value");

			
			stateVars.dataSource_540654 = stateVars.KuikaY_GetProductGroupsByBrand ?? this.state.KuikaY_GetProductGroupsByBrand;
			stateVars.dataSource_540654 = stateVars.KuikaY_GetProductGroupsByBrand ?? this.state.KuikaY_GetProductGroupsByBrand;
			formVars.montblancbasedreporting_142273_value = ReactSystemFunctions.toString(this, (stateVars.Kuika_ReportProductSales !== undefined ? (stateVars.Kuika_ReportProductSales?.length > 0 ? stateVars.Kuika_ReportProductSales[0].toplamSatisAdedi : null) : (this.state.Kuika_ReportProductSales?.length > 0 ? this.state.Kuika_ReportProductSales[0].toplamSatisAdedi : null)));

			formVars.montblancbasedreporting_862873_value = ReactSystemFunctions.toString(this, (stateVars.Kuika_ReportProductSales !== undefined ? (stateVars.Kuika_ReportProductSales?.length > 0 ? stateVars.Kuika_ReportProductSales[0].bulundugumuzAySatisAdedi : null) : (this.state.Kuika_ReportProductSales?.length > 0 ? this.state.Kuika_ReportProductSales[0].bulundugumuzAySatisAdedi : null)));

			formVars.montblancbasedreporting_442377_value = ReactSystemFunctions.toString(this, (stateVars.Kuika_ReportProductSales !== undefined ? (stateVars.Kuika_ReportProductSales?.length > 0 ? stateVars.Kuika_ReportProductSales[0].gecenYilaGoreArtisYuzde : null) : (this.state.Kuika_ReportProductSales?.length > 0 ? this.state.Kuika_ReportProductSales[0].gecenYilaGoreArtisYuzde : null)));

			formVars.montblancbasedreporting_49365_value = ReactSystemFunctions.toString(this, (stateVars.Kuika_ReportProductSales !== undefined ? (stateVars.Kuika_ReportProductSales?.length > 0 ? stateVars.Kuika_ReportProductSales[0].enGucluMagazaDesc : null) : (this.state.Kuika_ReportProductSales?.length > 0 ? this.state.Kuika_ReportProductSales[0].enGucluMagazaDesc : null)));

			formVars.montblancbasedreporting_689773_value = ReactSystemFunctions.toString(this, (stateVars.Kuika_ReportProductSales !== undefined ? (stateVars.Kuika_ReportProductSales?.length > 0 ? stateVars.Kuika_ReportProductSales[0].enGucluMagazaCiro : null) : (this.state.Kuika_ReportProductSales?.length > 0 ? this.state.Kuika_ReportProductSales[0].enGucluMagazaCiro : null)));

			formVars.montblancbasedreporting_662229_value = ReactSystemFunctions.toString(this, (stateVars.Kuika_ReportProductSales !== undefined ? (stateVars.Kuika_ReportProductSales?.length > 0 ? stateVars.Kuika_ReportProductSales[0].enCokSatanFamily : null) : (this.state.Kuika_ReportProductSales?.length > 0 ? this.state.Kuika_ReportProductSales[0].enCokSatanFamily : null)));

			formVars.montblancbasedreporting_825140_value = ReactSystemFunctions.toString(this, (stateVars.Kuika_ReportProductSales !== undefined ? (stateVars.Kuika_ReportProductSales?.length > 0 ? stateVars.Kuika_ReportProductSales[0].enCokSatanFamilyAdet : null) : (this.state.Kuika_ReportProductSales?.length > 0 ? this.state.Kuika_ReportProductSales[0].enCokSatanFamilyAdet : null)));

			formVars.montblancbasedreporting_51555_value = ReactSystemFunctions.toString(this, (stateVars.Kuika_ReportProductSales !== undefined ? (stateVars.Kuika_ReportProductSales?.length > 0 ? stateVars.Kuika_ReportProductSales[0].enCokSatanMaterial : null) : (this.state.Kuika_ReportProductSales?.length > 0 ? this.state.Kuika_ReportProductSales[0].enCokSatanMaterial : null)));

			formVars.montblancbasedreporting_816749_value = ReactSystemFunctions.toString(this, (stateVars.Kuika_ReportProductSales !== undefined ? (stateVars.Kuika_ReportProductSales?.length > 0 ? stateVars.Kuika_ReportProductSales[0].enCokSatanMaterialCiro : null) : (this.state.Kuika_ReportProductSales?.length > 0 ? this.state.Kuika_ReportProductSales[0].enCokSatanMaterialCiro : null)));

			ReactSystemFunctions.setValueOf(this, "montblancbasedreporting_406126_toString", ReactSystemFunctions.value(this, "montblancbasedreporting_25286_value", "value"), "value");

			
			stateVars.dataSource_739514 = stateVars.KuikaY_GetProductGroupsByBrand ?? this.state.KuikaY_GetProductGroupsByBrand;
			stateVars.dataSource_739514 = stateVars.KuikaY_GetProductGroupsByBrand ?? this.state.KuikaY_GetProductGroupsByBrand;
			
			stateVars.dataSource_893983 = stateVars.KuikaY_MonthlyStoreSalesReport ?? this.state.KuikaY_MonthlyStoreSalesReport;
			ReactSystemFunctions.setValueOf(this, "montblancbasedreporting_882679_toString", ReactSystemFunctions.value(this, "montblancbasedreporting_625329_value", "value"), "value");

			ReactSystemFunctions.setValueOf(this, "montblancbasedreporting_300162_toString", ReactSystemFunctions.value(this, "montblancbasedreporting_996749_value", "value"), "value");

			
			stateVars.dataSource_784292 = stateVars.KuikaY_MontBlancAylikSatisKarsilastirma ?? this.state.KuikaY_MontBlancAylikSatisKarsilastirma;
			
			
			stateVars.isComp85453Visible = ((ReactSystemFunctions.isGreaterOrEqual(ReactSystemFunctions.value(this, "montblancbasedreporting_784292_value", "ocakAdetDegisim"), ReactSystemFunctions.convertToTypeByName("0", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp243475Visible = ((ReactSystemFunctions.isLessThan(ReactSystemFunctions.value(this, "montblancbasedreporting_784292_value", "ocakAdetDegisim"), ReactSystemFunctions.convertToTypeByName("0", "string"))) === true ? "visible" : "hidden")
			
			stateVars.dataSource_805621 = stateVars.KuikaY_MontBlancAylikSatisKarsilastirma ?? this.state.KuikaY_MontBlancAylikSatisKarsilastirma;
			ReactSystemFunctions.setValueOf(this, "montblancbasedreporting_167195_toString", ReactSystemFunctions.value(this, "montblancbasedreporting_625329_value", "value"), "value");

			ReactSystemFunctions.setValueOf(this, "montblancbasedreporting_500608_toString", ReactSystemFunctions.value(this, "montblancbasedreporting_996749_value", "value"), "value");

			
			stateVars.dataSource_176274 = stateVars.KuikaY_MontBlancAylikSatisKarsilastirma ?? this.state.KuikaY_MontBlancAylikSatisKarsilastirma;
			
			
			stateVars.isComp655623Visible = ((ReactSystemFunctions.isGreaterOrEqual(ReactSystemFunctions.value(this, "montblancbasedreporting_176274_value", "subatAdetDegisim"), ReactSystemFunctions.convertToTypeByName("0", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp10207Visible = ((ReactSystemFunctions.isLessThan(ReactSystemFunctions.value(this, "montblancbasedreporting_176274_value", "subatAdetDegisim"), ReactSystemFunctions.convertToTypeByName("0", "string"))) === true ? "visible" : "hidden")
			
			stateVars.dataSource_570835 = stateVars.KuikaY_MontBlancAylikSatisKarsilastirma ?? this.state.KuikaY_MontBlancAylikSatisKarsilastirma;
			ReactSystemFunctions.setValueOf(this, "montblancbasedreporting_719512_toString", ReactSystemFunctions.value(this, "montblancbasedreporting_625329_value", "value"), "value");

			ReactSystemFunctions.setValueOf(this, "montblancbasedreporting_432510_toString", ReactSystemFunctions.value(this, "montblancbasedreporting_996749_value", "value"), "value");

			
			stateVars.dataSource_307852 = stateVars.KuikaY_MontBlancAylikSatisKarsilastirma ?? this.state.KuikaY_MontBlancAylikSatisKarsilastirma;
			
			
			stateVars.isComp862930Visible = ((ReactSystemFunctions.isGreaterOrEqual(ReactSystemFunctions.value(this, "montblancbasedreporting_307852_value", "martAdetDegisim"), ReactSystemFunctions.convertToTypeByName("0", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp61795Visible = ((ReactSystemFunctions.isLessThan(ReactSystemFunctions.value(this, "montblancbasedreporting_307852_value", "martAdetDegisim"), ReactSystemFunctions.convertToTypeByName("0", "string"))) === true ? "visible" : "hidden")
			
			stateVars.dataSource_687109 = stateVars.KuikaY_MontBlancAylikSatisKarsilastirma ?? this.state.KuikaY_MontBlancAylikSatisKarsilastirma;
			ReactSystemFunctions.setValueOf(this, "montblancbasedreporting_613320_toString", ReactSystemFunctions.value(this, "montblancbasedreporting_625329_value", "value"), "value");

			ReactSystemFunctions.setValueOf(this, "montblancbasedreporting_650687_toString", ReactSystemFunctions.value(this, "montblancbasedreporting_996749_value", "value"), "value");

			
			stateVars.dataSource_360771 = stateVars.KuikaY_MontBlancAylikSatisKarsilastirma ?? this.state.KuikaY_MontBlancAylikSatisKarsilastirma;
			
			
			stateVars.isComp516985Visible = ((ReactSystemFunctions.isGreaterOrEqual(ReactSystemFunctions.value(this, "montblancbasedreporting_360771_value", "nisanAdetDegisim"), ReactSystemFunctions.convertToTypeByName("0", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp510423Visible = ((ReactSystemFunctions.isLessThan(ReactSystemFunctions.value(this, "montblancbasedreporting_360771_value", "nisanAdetDegisim"), ReactSystemFunctions.convertToTypeByName("0", "string"))) === true ? "visible" : "hidden")
			
			stateVars.dataSource_997649 = stateVars.KuikaY_MontBlancAylikSatisKarsilastirma ?? this.state.KuikaY_MontBlancAylikSatisKarsilastirma;
			ReactSystemFunctions.setValueOf(this, "montblancbasedreporting_897218_toString", ReactSystemFunctions.value(this, "montblancbasedreporting_625329_value", "value"), "value");

			ReactSystemFunctions.setValueOf(this, "montblancbasedreporting_85132_toString", ReactSystemFunctions.value(this, "montblancbasedreporting_996749_value", "value"), "value");

			
			stateVars.dataSource_414298 = stateVars.KuikaY_MontBlancAylikSatisKarsilastirma ?? this.state.KuikaY_MontBlancAylikSatisKarsilastirma;
			
			
			stateVars.isComp782468Visible = ((ReactSystemFunctions.isGreaterOrEqual(ReactSystemFunctions.value(this, "montblancbasedreporting_414298_value", "mayisAdetDegisim"), ReactSystemFunctions.convertToTypeByName("0", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp547590Visible = ((ReactSystemFunctions.isLessThan(ReactSystemFunctions.value(this, "montblancbasedreporting_414298_value", "mayisAdetDegisim"), ReactSystemFunctions.convertToTypeByName("0", "string"))) === true ? "visible" : "hidden")
			
			stateVars.dataSource_457615 = stateVars.KuikaY_MontBlancAylikSatisKarsilastirma ?? this.state.KuikaY_MontBlancAylikSatisKarsilastirma;
			ReactSystemFunctions.setValueOf(this, "montblancbasedreporting_11901_toString", ReactSystemFunctions.value(this, "montblancbasedreporting_625329_value", "value"), "value");

			ReactSystemFunctions.setValueOf(this, "montblancbasedreporting_419343_toString", ReactSystemFunctions.value(this, "montblancbasedreporting_996749_value", "value"), "value");

			
			stateVars.dataSource_905708 = stateVars.KuikaY_MontBlancAylikSatisKarsilastirma ?? this.state.KuikaY_MontBlancAylikSatisKarsilastirma;
			
			
			stateVars.isComp644641Visible = ((ReactSystemFunctions.isGreaterOrEqual(ReactSystemFunctions.value(this, "montblancbasedreporting_905708_value", "haziranAdetDegisim"), ReactSystemFunctions.convertToTypeByName("0", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp553499Visible = ((ReactSystemFunctions.isLessThan(ReactSystemFunctions.value(this, "montblancbasedreporting_905708_value", "haziranAdetDegisim"), ReactSystemFunctions.convertToTypeByName("0", "string"))) === true ? "visible" : "hidden")
			
			stateVars.dataSource_575662 = stateVars.KuikaY_MontBlancAylikSatisKarsilastirma ?? this.state.KuikaY_MontBlancAylikSatisKarsilastirma;
			ReactSystemFunctions.setValueOf(this, "montblancbasedreporting_40814_toString", ReactSystemFunctions.value(this, "montblancbasedreporting_625329_value", "value"), "value");

			ReactSystemFunctions.setValueOf(this, "montblancbasedreporting_912493_toString", ReactSystemFunctions.value(this, "montblancbasedreporting_996749_value", "value"), "value");

			
			stateVars.dataSource_534055 = stateVars.KuikaY_MontBlancAylikSatisKarsilastirma ?? this.state.KuikaY_MontBlancAylikSatisKarsilastirma;
			
			
			stateVars.isComp579271Visible = ((ReactSystemFunctions.isGreaterOrEqual(ReactSystemFunctions.value(this, "montblancbasedreporting_534055_value", "temmuzAdetDegisim"), ReactSystemFunctions.convertToTypeByName("0", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp972772Visible = ((ReactSystemFunctions.isLessThan(ReactSystemFunctions.value(this, "montblancbasedreporting_534055_value", "temmuzAdetDegisim"), ReactSystemFunctions.convertToTypeByName("0", "string"))) === true ? "visible" : "hidden")
			
			stateVars.dataSource_834601 = stateVars.KuikaY_MontBlancAylikSatisKarsilastirma ?? this.state.KuikaY_MontBlancAylikSatisKarsilastirma;
			ReactSystemFunctions.setValueOf(this, "montblancbasedreporting_513932_toString", ReactSystemFunctions.value(this, "montblancbasedreporting_625329_value", "value"), "value");

			ReactSystemFunctions.setValueOf(this, "montblancbasedreporting_688898_toString", ReactSystemFunctions.value(this, "montblancbasedreporting_996749_value", "value"), "value");

			
			stateVars.dataSource_829642 = stateVars.KuikaY_MontBlancAylikSatisKarsilastirma ?? this.state.KuikaY_MontBlancAylikSatisKarsilastirma;
			
			
			stateVars.isComp394513Visible = ((ReactSystemFunctions.isGreaterOrEqual(ReactSystemFunctions.value(this, "montblancbasedreporting_829642_value", "agustosAdetDegisim"), ReactSystemFunctions.convertToTypeByName("0", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp808797Visible = ((ReactSystemFunctions.isLessThan(ReactSystemFunctions.value(this, "montblancbasedreporting_829642_value", "agustosAdetDegisim"), ReactSystemFunctions.convertToTypeByName("0", "string"))) === true ? "visible" : "hidden")
			
			stateVars.dataSource_185636 = stateVars.KuikaY_MontBlancAylikSatisKarsilastirma ?? this.state.KuikaY_MontBlancAylikSatisKarsilastirma;
			ReactSystemFunctions.setValueOf(this, "montblancbasedreporting_572095_toString", ReactSystemFunctions.value(this, "montblancbasedreporting_625329_value", "value"), "value");

			ReactSystemFunctions.setValueOf(this, "montblancbasedreporting_356185_toString", ReactSystemFunctions.value(this, "montblancbasedreporting_996749_value", "value"), "value");

			
			stateVars.dataSource_918728 = stateVars.KuikaY_MontBlancAylikSatisKarsilastirma ?? this.state.KuikaY_MontBlancAylikSatisKarsilastirma;
			
			
			stateVars.isComp647560Visible = ((ReactSystemFunctions.isGreaterOrEqual(ReactSystemFunctions.value(this, "montblancbasedreporting_918728_value", "eylulAdetDegisim"), ReactSystemFunctions.convertToTypeByName("0", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp500376Visible = ((ReactSystemFunctions.isLessThan(ReactSystemFunctions.value(this, "montblancbasedreporting_918728_value", "eylulAdetDegisim"), ReactSystemFunctions.convertToTypeByName("0", "string"))) === true ? "visible" : "hidden")
			
			stateVars.dataSource_588600 = stateVars.KuikaY_MontBlancAylikSatisKarsilastirma ?? this.state.KuikaY_MontBlancAylikSatisKarsilastirma;
			ReactSystemFunctions.setValueOf(this, "montblancbasedreporting_242269_toString", ReactSystemFunctions.value(this, "montblancbasedreporting_625329_value", "value"), "value");

			ReactSystemFunctions.setValueOf(this, "montblancbasedreporting_64323_toString", ReactSystemFunctions.value(this, "montblancbasedreporting_996749_value", "value"), "value");

			
			stateVars.dataSource_415490 = stateVars.KuikaY_MontBlancAylikSatisKarsilastirma ?? this.state.KuikaY_MontBlancAylikSatisKarsilastirma;
			
			
			stateVars.isComp548762Visible = ((ReactSystemFunctions.isGreaterOrEqual(ReactSystemFunctions.value(this, "montblancbasedreporting_415490_value", "ekimAdetDegisim"), ReactSystemFunctions.convertToTypeByName("0", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp427864Visible = ((ReactSystemFunctions.isLessThan(ReactSystemFunctions.value(this, "montblancbasedreporting_415490_value", "ekimAdetDegisim"), ReactSystemFunctions.convertToTypeByName("0", "string"))) === true ? "visible" : "hidden")
			
			stateVars.dataSource_436585 = stateVars.KuikaY_MontBlancAylikSatisKarsilastirma ?? this.state.KuikaY_MontBlancAylikSatisKarsilastirma;
			ReactSystemFunctions.setValueOf(this, "montblancbasedreporting_977769_toString", ReactSystemFunctions.value(this, "montblancbasedreporting_625329_value", "value"), "value");

			ReactSystemFunctions.setValueOf(this, "montblancbasedreporting_371613_toString", ReactSystemFunctions.value(this, "montblancbasedreporting_996749_value", "value"), "value");

			
			stateVars.dataSource_457709 = stateVars.KuikaY_MontBlancAylikSatisKarsilastirma ?? this.state.KuikaY_MontBlancAylikSatisKarsilastirma;
			
			
			stateVars.isComp368667Visible = ((ReactSystemFunctions.isGreaterOrEqual(ReactSystemFunctions.value(this, "montblancbasedreporting_457709_value", "kasimAdetDegisim"), ReactSystemFunctions.convertToTypeByName("0", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp351992Visible = ((ReactSystemFunctions.isLessThan(ReactSystemFunctions.value(this, "montblancbasedreporting_457709_value", "kasimAdetDegisim"), ReactSystemFunctions.convertToTypeByName("0", "string"))) === true ? "visible" : "hidden")
			
			stateVars.dataSource_742109 = stateVars.KuikaY_MontBlancAylikSatisKarsilastirma ?? this.state.KuikaY_MontBlancAylikSatisKarsilastirma;
			ReactSystemFunctions.setValueOf(this, "montblancbasedreporting_913824_toString", ReactSystemFunctions.value(this, "montblancbasedreporting_625329_value", "value"), "value");

			ReactSystemFunctions.setValueOf(this, "montblancbasedreporting_437822_toString", ReactSystemFunctions.value(this, "montblancbasedreporting_996749_value", "value"), "value");

			
			stateVars.dataSource_759335 = stateVars.KuikaY_MontBlancAylikSatisKarsilastirma ?? this.state.KuikaY_MontBlancAylikSatisKarsilastirma;
			
			
			stateVars.isComp742085Visible = ((ReactSystemFunctions.isGreaterOrEqual(ReactSystemFunctions.value(this, "montblancbasedreporting_759335_value", "aralikAdetDegisim"), ReactSystemFunctions.convertToTypeByName("0", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp29797Visible = ((ReactSystemFunctions.isLessThan(ReactSystemFunctions.value(this, "montblancbasedreporting_759335_value", "aralikAdetDegisim"), ReactSystemFunctions.convertToTypeByName("0", "string"))) === true ? "visible" : "hidden")
			
			stateVars.dataSource_547260 = stateVars.KuikaY_MontBlancAylikSatisKarsilastirma ?? this.state.KuikaY_MontBlancAylikSatisKarsilastirma;

	this.props.form?.setFieldsValue(formVars);
	this.setState(stateVars);
	KuikaAppManager.hideSpinner(this);

            this.setPageInitLoaded(true);
            return isErrorOccurred;
        }




		MontBlancBasedReportingComponent_747637_onClick = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
KuikaAppManager.showSpinner(this);

const __currentPath = (window.location.hash ? window.location.hash.replace(/^#/, '').split('?')[0] : window.location.pathname.split('?')[0]).toLowerCase();
if (__currentPath !== "/rolexbasedreporting") {
  this.context.setMasterPageInitLoaded(false);
  this.context.setMasterPageRecurringLoaded(false);
  this.context.setShouldTriggerPageInit(true);
}
					KuikaAppManager.prepareForNavigation();

				stateVars.NAVIGATE = await ReactSystemFunctions.navigate(this, undefined, "MontBlancBasedReporting", "RolexBasedReporting", "", "currentPage", null, null, null, null, null, null, true, false);

		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

            
            return isErrorOccurred;
        }


		MontBlancBasedReportingComponent_751032_onClick = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
KuikaAppManager.showSpinner(this);

const __currentPath = (window.location.hash ? window.location.hash.replace(/^#/, '').split('?')[0] : window.location.pathname.split('?')[0]).toLowerCase();
if (__currentPath !== "/tudorbasedreporting") {
  this.context.setMasterPageInitLoaded(false);
  this.context.setMasterPageRecurringLoaded(false);
  this.context.setShouldTriggerPageInit(true);
}
					KuikaAppManager.prepareForNavigation();

				stateVars.NAVIGATE = await ReactSystemFunctions.navigate(this, undefined, "MontBlancBasedReporting", "TudorBasedReporting", "", "currentPage", null, null, null, null, null, null, true, false);

		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

            
            return isErrorOccurred;
        }


		MontBlancBasedReportingComponent_18803_onClick = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
KuikaAppManager.showSpinner(this);

const __currentPath = (window.location.hash ? window.location.hash.replace(/^#/, '').split('?')[0] : window.location.pathname.split('?')[0]).toLowerCase();
if (__currentPath !== "/dupontbasedreporting") {
  this.context.setMasterPageInitLoaded(false);
  this.context.setMasterPageRecurringLoaded(false);
  this.context.setShouldTriggerPageInit(true);
}
					KuikaAppManager.prepareForNavigation();

				stateVars.NAVIGATE = await ReactSystemFunctions.navigate(this, undefined, "MontBlancBasedReporting", "DupontBasedReporting", "", "currentPage", null, null, null, null, null, null, true, false);

		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

            
            return isErrorOccurred;
        }


		MontBlancBasedReportingComponent_149507_onChange = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
KuikaAppManager.showSpinner(this);

				ReactSystemFunctions.setValueOf(this, "montblancbasedreporting_282961_toString", ReactSystemFunctions.value(this, "montblancbasedreporting_149507_value", "value"), "value");


		this.props.form?.setFieldsValue(formVars);
		
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.MontBlancBasedReportingComponent_149507_onChange1_();
                  resolve();
                });
          })

            
            return isErrorOccurred;
        }
    MontBlancBasedReportingComponent_149507_onChange1_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
		KuikaAppManager.increaseServerRequestCount();

        let localVar = {
				Marka_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.convertToTypeByName("Mont Blanc", "string"), "string"),
				UrunGrubu_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "montblancbasedreporting_540654_value", "value", "KuikaY_GetProductGroupsByBrand", "productGroup", "productGroup")), "string"),
				Year_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "montblancbasedreporting_149507_value", "value", "", "", "")), "number")
        }

		
        if (true) {
        KuikaAppManager.showSpinner(this);
        }
        let result = await KuikaAppManager.ApiRequest(this, "MontBlancBasedReporting/MontBlancBasedReportingComponent_149507_onChange1_", localVar)
        if (!KMainFunctions.IsResStatus2XX(result)) return true;

			stateVars.Kuika_ReportProductSales = result?.data.kuika_ReportProductSales;
			formVars.montblancbasedreporting_142273_value = ReactSystemFunctions.toString(this, (stateVars.Kuika_ReportProductSales !== undefined ? (stateVars.Kuika_ReportProductSales?.length > 0 ? stateVars.Kuika_ReportProductSales[0].toplamSatisAdedi : null) : (this.state.Kuika_ReportProductSales?.length > 0 ? this.state.Kuika_ReportProductSales[0].toplamSatisAdedi : null)));
			formVars.montblancbasedreporting_862873_value = ReactSystemFunctions.toString(this, (stateVars.Kuika_ReportProductSales !== undefined ? (stateVars.Kuika_ReportProductSales?.length > 0 ? stateVars.Kuika_ReportProductSales[0].bulundugumuzAySatisAdedi : null) : (this.state.Kuika_ReportProductSales?.length > 0 ? this.state.Kuika_ReportProductSales[0].bulundugumuzAySatisAdedi : null)));
			formVars.montblancbasedreporting_442377_value = ReactSystemFunctions.toString(this, (stateVars.Kuika_ReportProductSales !== undefined ? (stateVars.Kuika_ReportProductSales?.length > 0 ? stateVars.Kuika_ReportProductSales[0].gecenYilaGoreArtisYuzde : null) : (this.state.Kuika_ReportProductSales?.length > 0 ? this.state.Kuika_ReportProductSales[0].gecenYilaGoreArtisYuzde : null)));
			formVars.montblancbasedreporting_49365_value = ReactSystemFunctions.toString(this, (stateVars.Kuika_ReportProductSales !== undefined ? (stateVars.Kuika_ReportProductSales?.length > 0 ? stateVars.Kuika_ReportProductSales[0].enGucluMagazaDesc : null) : (this.state.Kuika_ReportProductSales?.length > 0 ? this.state.Kuika_ReportProductSales[0].enGucluMagazaDesc : null)));
			formVars.montblancbasedreporting_689773_value = ReactSystemFunctions.toString(this, (stateVars.Kuika_ReportProductSales !== undefined ? (stateVars.Kuika_ReportProductSales?.length > 0 ? stateVars.Kuika_ReportProductSales[0].enGucluMagazaCiro : null) : (this.state.Kuika_ReportProductSales?.length > 0 ? this.state.Kuika_ReportProductSales[0].enGucluMagazaCiro : null)));
			formVars.montblancbasedreporting_662229_value = ReactSystemFunctions.toString(this, (stateVars.Kuika_ReportProductSales !== undefined ? (stateVars.Kuika_ReportProductSales?.length > 0 ? stateVars.Kuika_ReportProductSales[0].enCokSatanFamily : null) : (this.state.Kuika_ReportProductSales?.length > 0 ? this.state.Kuika_ReportProductSales[0].enCokSatanFamily : null)));
			formVars.montblancbasedreporting_825140_value = ReactSystemFunctions.toString(this, (stateVars.Kuika_ReportProductSales !== undefined ? (stateVars.Kuika_ReportProductSales?.length > 0 ? stateVars.Kuika_ReportProductSales[0].enCokSatanFamilyAdet : null) : (this.state.Kuika_ReportProductSales?.length > 0 ? this.state.Kuika_ReportProductSales[0].enCokSatanFamilyAdet : null)));
			formVars.montblancbasedreporting_51555_value = ReactSystemFunctions.toString(this, (stateVars.Kuika_ReportProductSales !== undefined ? (stateVars.Kuika_ReportProductSales?.length > 0 ? stateVars.Kuika_ReportProductSales[0].enCokSatanMaterial : null) : (this.state.Kuika_ReportProductSales?.length > 0 ? this.state.Kuika_ReportProductSales[0].enCokSatanMaterial : null)));
			formVars.montblancbasedreporting_816749_value = ReactSystemFunctions.toString(this, (stateVars.Kuika_ReportProductSales !== undefined ? (stateVars.Kuika_ReportProductSales?.length > 0 ? stateVars.Kuika_ReportProductSales[0].enCokSatanMaterialCiro : null) : (this.state.Kuika_ReportProductSales?.length > 0 ? this.state.Kuika_ReportProductSales[0].enCokSatanMaterialCiro : null)));
			this.props.form?.setFieldsValue(formVars);
			
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.MontBlancBasedReportingComponent_149507_onChange2_();
                  resolve();
                });
          })



        
        KuikaAppManager.hideSpinner(this);
        return isErrorOccurred;
    }
		MontBlancBasedReportingComponent_149507_onChange2_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }

				formVars.montblancbasedreporting_142273_value = ReactSystemFunctions.toString(this, (stateVars.Kuika_ReportProductSales !== undefined ? (stateVars.Kuika_ReportProductSales?.length > 0 ? stateVars.Kuika_ReportProductSales[0].toplamSatisAdedi : null) : (this.state.Kuika_ReportProductSales?.length > 0 ? this.state.Kuika_ReportProductSales[0].toplamSatisAdedi : null)));

				formVars.montblancbasedreporting_862873_value = ReactSystemFunctions.toString(this, (stateVars.Kuika_ReportProductSales !== undefined ? (stateVars.Kuika_ReportProductSales?.length > 0 ? stateVars.Kuika_ReportProductSales[0].bulundugumuzAySatisAdedi : null) : (this.state.Kuika_ReportProductSales?.length > 0 ? this.state.Kuika_ReportProductSales[0].bulundugumuzAySatisAdedi : null)));

				formVars.montblancbasedreporting_442377_value = ReactSystemFunctions.toString(this, (stateVars.Kuika_ReportProductSales !== undefined ? (stateVars.Kuika_ReportProductSales?.length > 0 ? stateVars.Kuika_ReportProductSales[0].gecenYilaGoreArtisYuzde : null) : (this.state.Kuika_ReportProductSales?.length > 0 ? this.state.Kuika_ReportProductSales[0].gecenYilaGoreArtisYuzde : null)));

				formVars.montblancbasedreporting_49365_value = ReactSystemFunctions.toString(this, (stateVars.Kuika_ReportProductSales !== undefined ? (stateVars.Kuika_ReportProductSales?.length > 0 ? stateVars.Kuika_ReportProductSales[0].enGucluMagazaDesc : null) : (this.state.Kuika_ReportProductSales?.length > 0 ? this.state.Kuika_ReportProductSales[0].enGucluMagazaDesc : null)));

				formVars.montblancbasedreporting_689773_value = ReactSystemFunctions.toString(this, (stateVars.Kuika_ReportProductSales !== undefined ? (stateVars.Kuika_ReportProductSales?.length > 0 ? stateVars.Kuika_ReportProductSales[0].enGucluMagazaCiro : null) : (this.state.Kuika_ReportProductSales?.length > 0 ? this.state.Kuika_ReportProductSales[0].enGucluMagazaCiro : null)));

				formVars.montblancbasedreporting_662229_value = ReactSystemFunctions.toString(this, (stateVars.Kuika_ReportProductSales !== undefined ? (stateVars.Kuika_ReportProductSales?.length > 0 ? stateVars.Kuika_ReportProductSales[0].enCokSatanFamily : null) : (this.state.Kuika_ReportProductSales?.length > 0 ? this.state.Kuika_ReportProductSales[0].enCokSatanFamily : null)));

				formVars.montblancbasedreporting_825140_value = ReactSystemFunctions.toString(this, (stateVars.Kuika_ReportProductSales !== undefined ? (stateVars.Kuika_ReportProductSales?.length > 0 ? stateVars.Kuika_ReportProductSales[0].enCokSatanFamilyAdet : null) : (this.state.Kuika_ReportProductSales?.length > 0 ? this.state.Kuika_ReportProductSales[0].enCokSatanFamilyAdet : null)));

				formVars.montblancbasedreporting_51555_value = ReactSystemFunctions.toString(this, (stateVars.Kuika_ReportProductSales !== undefined ? (stateVars.Kuika_ReportProductSales?.length > 0 ? stateVars.Kuika_ReportProductSales[0].enCokSatanMaterial : null) : (this.state.Kuika_ReportProductSales?.length > 0 ? this.state.Kuika_ReportProductSales[0].enCokSatanMaterial : null)));

				formVars.montblancbasedreporting_816749_value = ReactSystemFunctions.toString(this, (stateVars.Kuika_ReportProductSales !== undefined ? (stateVars.Kuika_ReportProductSales?.length > 0 ? stateVars.Kuika_ReportProductSales[0].enCokSatanMaterialCiro : null) : (this.state.Kuika_ReportProductSales?.length > 0 ? this.state.Kuika_ReportProductSales[0].enCokSatanMaterialCiro : null)));


		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

            
            return isErrorOccurred;
        }





    MontBlancBasedReportingComponent_540654_onChange = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
		KuikaAppManager.increaseServerRequestCount();

        let localVar = {
				Marka_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.convertToTypeByName("Mont Blanc", "string"), "string"),
				UrunGrubu_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "montblancbasedreporting_540654_value", "value", "KuikaY_GetProductGroupsByBrand", "productGroup", "productGroup")), "string"),
				Year_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "montblancbasedreporting_149507_value", "value", "", "", "")), "number")
        }

		KuikaAppManager.showSpinner(this);
		
        if (true) {
        KuikaAppManager.showSpinner(this);
        }
        let result = await KuikaAppManager.ApiRequest(this, "MontBlancBasedReporting/MontBlancBasedReportingComponent_540654_onChange", localVar)
        if (!KMainFunctions.IsResStatus2XX(result)) return true;

			stateVars.Kuika_ReportProductSales = result?.data.kuika_ReportProductSales;
			formVars.montblancbasedreporting_142273_value = ReactSystemFunctions.toString(this, (stateVars.Kuika_ReportProductSales !== undefined ? (stateVars.Kuika_ReportProductSales?.length > 0 ? stateVars.Kuika_ReportProductSales[0].toplamSatisAdedi : null) : (this.state.Kuika_ReportProductSales?.length > 0 ? this.state.Kuika_ReportProductSales[0].toplamSatisAdedi : null)));
			formVars.montblancbasedreporting_862873_value = ReactSystemFunctions.toString(this, (stateVars.Kuika_ReportProductSales !== undefined ? (stateVars.Kuika_ReportProductSales?.length > 0 ? stateVars.Kuika_ReportProductSales[0].bulundugumuzAySatisAdedi : null) : (this.state.Kuika_ReportProductSales?.length > 0 ? this.state.Kuika_ReportProductSales[0].bulundugumuzAySatisAdedi : null)));
			formVars.montblancbasedreporting_442377_value = ReactSystemFunctions.toString(this, (stateVars.Kuika_ReportProductSales !== undefined ? (stateVars.Kuika_ReportProductSales?.length > 0 ? stateVars.Kuika_ReportProductSales[0].gecenYilaGoreArtisYuzde : null) : (this.state.Kuika_ReportProductSales?.length > 0 ? this.state.Kuika_ReportProductSales[0].gecenYilaGoreArtisYuzde : null)));
			formVars.montblancbasedreporting_49365_value = ReactSystemFunctions.toString(this, (stateVars.Kuika_ReportProductSales !== undefined ? (stateVars.Kuika_ReportProductSales?.length > 0 ? stateVars.Kuika_ReportProductSales[0].enGucluMagazaDesc : null) : (this.state.Kuika_ReportProductSales?.length > 0 ? this.state.Kuika_ReportProductSales[0].enGucluMagazaDesc : null)));
			formVars.montblancbasedreporting_689773_value = ReactSystemFunctions.toString(this, (stateVars.Kuika_ReportProductSales !== undefined ? (stateVars.Kuika_ReportProductSales?.length > 0 ? stateVars.Kuika_ReportProductSales[0].enGucluMagazaCiro : null) : (this.state.Kuika_ReportProductSales?.length > 0 ? this.state.Kuika_ReportProductSales[0].enGucluMagazaCiro : null)));
			formVars.montblancbasedreporting_662229_value = ReactSystemFunctions.toString(this, (stateVars.Kuika_ReportProductSales !== undefined ? (stateVars.Kuika_ReportProductSales?.length > 0 ? stateVars.Kuika_ReportProductSales[0].enCokSatanFamily : null) : (this.state.Kuika_ReportProductSales?.length > 0 ? this.state.Kuika_ReportProductSales[0].enCokSatanFamily : null)));
			formVars.montblancbasedreporting_825140_value = ReactSystemFunctions.toString(this, (stateVars.Kuika_ReportProductSales !== undefined ? (stateVars.Kuika_ReportProductSales?.length > 0 ? stateVars.Kuika_ReportProductSales[0].enCokSatanFamilyAdet : null) : (this.state.Kuika_ReportProductSales?.length > 0 ? this.state.Kuika_ReportProductSales[0].enCokSatanFamilyAdet : null)));
			formVars.montblancbasedreporting_51555_value = ReactSystemFunctions.toString(this, (stateVars.Kuika_ReportProductSales !== undefined ? (stateVars.Kuika_ReportProductSales?.length > 0 ? stateVars.Kuika_ReportProductSales[0].enCokSatanMaterial : null) : (this.state.Kuika_ReportProductSales?.length > 0 ? this.state.Kuika_ReportProductSales[0].enCokSatanMaterial : null)));
			formVars.montblancbasedreporting_816749_value = ReactSystemFunctions.toString(this, (stateVars.Kuika_ReportProductSales !== undefined ? (stateVars.Kuika_ReportProductSales?.length > 0 ? stateVars.Kuika_ReportProductSales[0].enCokSatanMaterialCiro : null) : (this.state.Kuika_ReportProductSales?.length > 0 ? this.state.Kuika_ReportProductSales[0].enCokSatanMaterialCiro : null)));
			this.props.form?.setFieldsValue(formVars);
			
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.MontBlancBasedReportingComponent_540654_onChange1_();
                  resolve();
                });
          })



        
        KuikaAppManager.hideSpinner(this);
        return isErrorOccurred;
    }
		MontBlancBasedReportingComponent_540654_onChange1_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }

				formVars.montblancbasedreporting_142273_value = ReactSystemFunctions.toString(this, (stateVars.Kuika_ReportProductSales !== undefined ? (stateVars.Kuika_ReportProductSales?.length > 0 ? stateVars.Kuika_ReportProductSales[0].toplamSatisAdedi : null) : (this.state.Kuika_ReportProductSales?.length > 0 ? this.state.Kuika_ReportProductSales[0].toplamSatisAdedi : null)));

				formVars.montblancbasedreporting_862873_value = ReactSystemFunctions.toString(this, (stateVars.Kuika_ReportProductSales !== undefined ? (stateVars.Kuika_ReportProductSales?.length > 0 ? stateVars.Kuika_ReportProductSales[0].bulundugumuzAySatisAdedi : null) : (this.state.Kuika_ReportProductSales?.length > 0 ? this.state.Kuika_ReportProductSales[0].bulundugumuzAySatisAdedi : null)));

				formVars.montblancbasedreporting_442377_value = ReactSystemFunctions.toString(this, (stateVars.Kuika_ReportProductSales !== undefined ? (stateVars.Kuika_ReportProductSales?.length > 0 ? stateVars.Kuika_ReportProductSales[0].gecenYilaGoreArtisYuzde : null) : (this.state.Kuika_ReportProductSales?.length > 0 ? this.state.Kuika_ReportProductSales[0].gecenYilaGoreArtisYuzde : null)));

				formVars.montblancbasedreporting_49365_value = ReactSystemFunctions.toString(this, (stateVars.Kuika_ReportProductSales !== undefined ? (stateVars.Kuika_ReportProductSales?.length > 0 ? stateVars.Kuika_ReportProductSales[0].enGucluMagazaDesc : null) : (this.state.Kuika_ReportProductSales?.length > 0 ? this.state.Kuika_ReportProductSales[0].enGucluMagazaDesc : null)));

				formVars.montblancbasedreporting_689773_value = ReactSystemFunctions.toString(this, (stateVars.Kuika_ReportProductSales !== undefined ? (stateVars.Kuika_ReportProductSales?.length > 0 ? stateVars.Kuika_ReportProductSales[0].enGucluMagazaCiro : null) : (this.state.Kuika_ReportProductSales?.length > 0 ? this.state.Kuika_ReportProductSales[0].enGucluMagazaCiro : null)));

				formVars.montblancbasedreporting_662229_value = ReactSystemFunctions.toString(this, (stateVars.Kuika_ReportProductSales !== undefined ? (stateVars.Kuika_ReportProductSales?.length > 0 ? stateVars.Kuika_ReportProductSales[0].enCokSatanFamily : null) : (this.state.Kuika_ReportProductSales?.length > 0 ? this.state.Kuika_ReportProductSales[0].enCokSatanFamily : null)));

				formVars.montblancbasedreporting_825140_value = ReactSystemFunctions.toString(this, (stateVars.Kuika_ReportProductSales !== undefined ? (stateVars.Kuika_ReportProductSales?.length > 0 ? stateVars.Kuika_ReportProductSales[0].enCokSatanFamilyAdet : null) : (this.state.Kuika_ReportProductSales?.length > 0 ? this.state.Kuika_ReportProductSales[0].enCokSatanFamilyAdet : null)));

				formVars.montblancbasedreporting_51555_value = ReactSystemFunctions.toString(this, (stateVars.Kuika_ReportProductSales !== undefined ? (stateVars.Kuika_ReportProductSales?.length > 0 ? stateVars.Kuika_ReportProductSales[0].enCokSatanMaterial : null) : (this.state.Kuika_ReportProductSales?.length > 0 ? this.state.Kuika_ReportProductSales[0].enCokSatanMaterial : null)));

				formVars.montblancbasedreporting_816749_value = ReactSystemFunctions.toString(this, (stateVars.Kuika_ReportProductSales !== undefined ? (stateVars.Kuika_ReportProductSales?.length > 0 ? stateVars.Kuika_ReportProductSales[0].enCokSatanMaterialCiro : null) : (this.state.Kuika_ReportProductSales?.length > 0 ? this.state.Kuika_ReportProductSales[0].enCokSatanMaterialCiro : null)));


		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

            
            return isErrorOccurred;
        }




		MontBlancBasedReportingComponent_25286_onChange = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
KuikaAppManager.showSpinner(this);

				ReactSystemFunctions.setValueOf(this, "montblancbasedreporting_406126_toString", ReactSystemFunctions.value(this, "montblancbasedreporting_25286_value", "value"), "value");


		this.props.form?.setFieldsValue(formVars);
		
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.MontBlancBasedReportingComponent_25286_onChange1_();
                  resolve();
                });
          })

            
            return isErrorOccurred;
        }
    MontBlancBasedReportingComponent_25286_onChange1_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
		KuikaAppManager.increaseServerRequestCount();

        let localVar = {
				Brand_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.convertToTypeByName("Mont Blanc", "string"), "string"),
				ProductGroup_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "montblancbasedreporting_739514_value", "value", "KuikaY_GetProductGroupsByBrand", "productGroup", "productGroup")), "string"),
				Year_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "montblancbasedreporting_25286_value", "value", "", "", "")), "number")
        }

		
        if (true) {
        KuikaAppManager.showSpinner(this);
        }
        let result = await KuikaAppManager.ApiRequest(this, "MontBlancBasedReporting/MontBlancBasedReportingComponent_25286_onChange1_", localVar)
        if (!KMainFunctions.IsResStatus2XX(result)) return true;

			stateVars.KuikaY_MonthlyStoreSalesReport = result?.data.kuikaY_MonthlyStoreSalesReport;
			
			this.props.form?.setFieldsValue(formVars);
			
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.MontBlancBasedReportingComponent_25286_onChange2_();
                  resolve();
                });
          })



        
        KuikaAppManager.hideSpinner(this);
        return isErrorOccurred;
    }
		MontBlancBasedReportingComponent_25286_onChange2_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }

				
				stateVars.dataSource_893983 = stateVars.KuikaY_MonthlyStoreSalesReport ?? this.state.KuikaY_MonthlyStoreSalesReport;

		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

            
            return isErrorOccurred;
        }





    MontBlancBasedReportingComponent_739514_onChange = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
		KuikaAppManager.increaseServerRequestCount();

        let localVar = {
				Brand_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.convertToTypeByName("Mont Blanc", "string"), "string"),
				ProductGroup_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "montblancbasedreporting_739514_value", "value", "KuikaY_GetProductGroupsByBrand", "productGroup", "productGroup")), "string"),
				Year_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "montblancbasedreporting_25286_value", "value", "", "", "")), "number")
        }

		KuikaAppManager.showSpinner(this);
		
        if (true) {
        KuikaAppManager.showSpinner(this);
        }
        let result = await KuikaAppManager.ApiRequest(this, "MontBlancBasedReporting/MontBlancBasedReportingComponent_739514_onChange", localVar)
        if (!KMainFunctions.IsResStatus2XX(result)) return true;

			stateVars.KuikaY_MonthlyStoreSalesReport = result?.data.kuikaY_MonthlyStoreSalesReport;
			
			this.props.form?.setFieldsValue(formVars);
			
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.MontBlancBasedReportingComponent_739514_onChange1_();
                  resolve();
                });
          })



        
        KuikaAppManager.hideSpinner(this);
        return isErrorOccurred;
    }
		MontBlancBasedReportingComponent_739514_onChange1_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }

				
				stateVars.dataSource_893983 = stateVars.KuikaY_MonthlyStoreSalesReport ?? this.state.KuikaY_MonthlyStoreSalesReport;

		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

            
            return isErrorOccurred;
        }




    MontBlancBasedReportingComponent_130404_onClick = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
		KuikaAppManager.increaseServerRequestCount();

        let localVar = {
				value_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, this.state.KuikaY_MonthlyStoreSalesReport), "any"),
				header_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.convertToTypeByName("Mont Blanc Yıllık Mağaza Bazlı Rapor", "string"), "string"),
				footer_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "montblancbasedreporting_25286_value", "value", "", "", "")), "string"),
				columns_0: ReactSystemFunctions.convertToTypeByName("", "string")
        }

		KuikaAppManager.showSpinner(this);
		
        if (true) {
        KuikaAppManager.showSpinner(this);
        }
        let result = await KuikaAppManager.ApiRequest(this, "MontBlancBasedReporting/MontBlancBasedReportingComponent_130404_onClick", localVar)
        if (!KMainFunctions.IsResStatus2XX(result)) return true;

			stateVars.ExportExcel = result?.data.exportExcel;
			ReactSystemFunctions.downloadFile(result?.data?.exportExcel);
			this.props.form?.setFieldsValue(formVars);
			this.setState(stateVars);
			KuikaAppManager.hideSpinner(this);



        this.setPageInitLoaded(true);
        KuikaAppManager.hideSpinner(this);
        return isErrorOccurred;
    }



    MontBlancBasedReportingComponent_148344_onClick = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
		KuikaAppManager.increaseServerRequestCount();

        let localVar = {
				Year1_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "montblancbasedreporting_625329_value", "value", "", "", "")), "number"),
				Year2_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "montblancbasedreporting_996749_value", "value", "", "", "")), "number")
        }

		KuikaAppManager.showSpinner(this);
		
        if (true) {
        KuikaAppManager.showSpinner(this);
        }
        let result = await KuikaAppManager.ApiRequest(this, "MontBlancBasedReporting/MontBlancBasedReportingComponent_148344_onClick", localVar)
        if (!KMainFunctions.IsResStatus2XX(result)) return true;

			stateVars.KuikaY_MontBlancAylikSatisKarsilastirma = result?.data.kuikaY_MontBlancAylikSatisKarsilastirma;
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			this.props.form?.setFieldsValue(formVars);
			
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.MontBlancBasedReportingComponent_148344_onClick1_();
                  resolve();
                });
          })



        
        KuikaAppManager.hideSpinner(this);
        return isErrorOccurred;
    }
		MontBlancBasedReportingComponent_148344_onClick1_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }

				
				stateVars.dataSource_784292 = stateVars.KuikaY_MontBlancAylikSatisKarsilastirma ?? this.state.KuikaY_MontBlancAylikSatisKarsilastirma;
				
				stateVars.dataSource_805621 = stateVars.KuikaY_MontBlancAylikSatisKarsilastirma ?? this.state.KuikaY_MontBlancAylikSatisKarsilastirma;
				
				stateVars.dataSource_176274 = stateVars.KuikaY_MontBlancAylikSatisKarsilastirma ?? this.state.KuikaY_MontBlancAylikSatisKarsilastirma;
				
				stateVars.dataSource_570835 = stateVars.KuikaY_MontBlancAylikSatisKarsilastirma ?? this.state.KuikaY_MontBlancAylikSatisKarsilastirma;
				
				stateVars.dataSource_307852 = stateVars.KuikaY_MontBlancAylikSatisKarsilastirma ?? this.state.KuikaY_MontBlancAylikSatisKarsilastirma;
				
				stateVars.dataSource_687109 = stateVars.KuikaY_MontBlancAylikSatisKarsilastirma ?? this.state.KuikaY_MontBlancAylikSatisKarsilastirma;
				
				stateVars.dataSource_360771 = stateVars.KuikaY_MontBlancAylikSatisKarsilastirma ?? this.state.KuikaY_MontBlancAylikSatisKarsilastirma;
				
				stateVars.dataSource_997649 = stateVars.KuikaY_MontBlancAylikSatisKarsilastirma ?? this.state.KuikaY_MontBlancAylikSatisKarsilastirma;
				
				stateVars.dataSource_414298 = stateVars.KuikaY_MontBlancAylikSatisKarsilastirma ?? this.state.KuikaY_MontBlancAylikSatisKarsilastirma;
				
				stateVars.dataSource_457615 = stateVars.KuikaY_MontBlancAylikSatisKarsilastirma ?? this.state.KuikaY_MontBlancAylikSatisKarsilastirma;
				
				stateVars.dataSource_905708 = stateVars.KuikaY_MontBlancAylikSatisKarsilastirma ?? this.state.KuikaY_MontBlancAylikSatisKarsilastirma;
				
				stateVars.dataSource_575662 = stateVars.KuikaY_MontBlancAylikSatisKarsilastirma ?? this.state.KuikaY_MontBlancAylikSatisKarsilastirma;
				
				stateVars.dataSource_534055 = stateVars.KuikaY_MontBlancAylikSatisKarsilastirma ?? this.state.KuikaY_MontBlancAylikSatisKarsilastirma;
				
				stateVars.dataSource_834601 = stateVars.KuikaY_MontBlancAylikSatisKarsilastirma ?? this.state.KuikaY_MontBlancAylikSatisKarsilastirma;
				
				stateVars.dataSource_829642 = stateVars.KuikaY_MontBlancAylikSatisKarsilastirma ?? this.state.KuikaY_MontBlancAylikSatisKarsilastirma;
				
				stateVars.dataSource_185636 = stateVars.KuikaY_MontBlancAylikSatisKarsilastirma ?? this.state.KuikaY_MontBlancAylikSatisKarsilastirma;
				
				stateVars.dataSource_918728 = stateVars.KuikaY_MontBlancAylikSatisKarsilastirma ?? this.state.KuikaY_MontBlancAylikSatisKarsilastirma;
				
				stateVars.dataSource_588600 = stateVars.KuikaY_MontBlancAylikSatisKarsilastirma ?? this.state.KuikaY_MontBlancAylikSatisKarsilastirma;
				
				stateVars.dataSource_415490 = stateVars.KuikaY_MontBlancAylikSatisKarsilastirma ?? this.state.KuikaY_MontBlancAylikSatisKarsilastirma;
				
				stateVars.dataSource_436585 = stateVars.KuikaY_MontBlancAylikSatisKarsilastirma ?? this.state.KuikaY_MontBlancAylikSatisKarsilastirma;
				
				stateVars.dataSource_457709 = stateVars.KuikaY_MontBlancAylikSatisKarsilastirma ?? this.state.KuikaY_MontBlancAylikSatisKarsilastirma;
				
				stateVars.dataSource_742109 = stateVars.KuikaY_MontBlancAylikSatisKarsilastirma ?? this.state.KuikaY_MontBlancAylikSatisKarsilastirma;
				
				stateVars.dataSource_759335 = stateVars.KuikaY_MontBlancAylikSatisKarsilastirma ?? this.state.KuikaY_MontBlancAylikSatisKarsilastirma;
				
				stateVars.dataSource_547260 = stateVars.KuikaY_MontBlancAylikSatisKarsilastirma ?? this.state.KuikaY_MontBlancAylikSatisKarsilastirma;

		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

            
            return isErrorOccurred;
        }




    MontBlancBasedReportingComponent_257313_onClick = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
		KuikaAppManager.increaseServerRequestCount();

        let localVar = {
				value_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, this.state.KuikaY_MontBlancAylikSatisKarsilastirma), "any"),
				header_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.convertToTypeByName("Mont Blanc Yıl Karşılaştırmalı Satış Raporu", "string"), "string"),
				footer_0: ReactSystemFunctions.convertToTypeByName("", "string"),
				columns_0: ReactSystemFunctions.convertToTypeByName("", "string")
        }

		KuikaAppManager.showSpinner(this);
		
        if (true) {
        KuikaAppManager.showSpinner(this);
        }
        let result = await KuikaAppManager.ApiRequest(this, "MontBlancBasedReporting/MontBlancBasedReportingComponent_257313_onClick", localVar)
        if (!KMainFunctions.IsResStatus2XX(result)) return true;

			stateVars.ExportExcel = result?.data.exportExcel;
			ReactSystemFunctions.downloadFile(result?.data?.exportExcel);
			this.props.form?.setFieldsValue(formVars);
			this.setState(stateVars);
			KuikaAppManager.hideSpinner(this);



        this.setPageInitLoaded(true);
        KuikaAppManager.hideSpinner(this);
        return isErrorOccurred;
    }



    MontBlancBasedReportingComponent_605126_onClick = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
		KuikaAppManager.increaseServerRequestCount();

        let localVar = {
				value_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, this.state.KuikaY_MontBlancAylikSatisKarsilastirma), "any"),
				header_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.convertToTypeByName("Karşılaştırmalı Mont Blanc Ocak Ayı Satış Raporu", "string"), "string"),
				footer_0: ReactSystemFunctions.convertToTypeByName("", "string"),
				columns_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.convertToTypeByName("Magaza,OcakAdet2025,OcakAdet2026,OcakAdetDegisim,OcakTL2025,OcakTL2026,OcakTLDegisim,OcakEUR2025,OcakEUR2026", "string"), "string")
        }

		KuikaAppManager.showSpinner(this);
		
        if (true) {
        KuikaAppManager.showSpinner(this);
        }
        let result = await KuikaAppManager.ApiRequest(this, "MontBlancBasedReporting/MontBlancBasedReportingComponent_605126_onClick", localVar)
        if (!KMainFunctions.IsResStatus2XX(result)) return true;

			stateVars.ExportExcel = result?.data.exportExcel;
			ReactSystemFunctions.downloadFile(result?.data?.exportExcel);
			this.props.form?.setFieldsValue(formVars);
			this.setState(stateVars);
			KuikaAppManager.hideSpinner(this);



        this.setPageInitLoaded(true);
        KuikaAppManager.hideSpinner(this);
        return isErrorOccurred;
    }



    MontBlancBasedReportingComponent_305217_onClick = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
		KuikaAppManager.increaseServerRequestCount();

        let localVar = {
				value_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, this.state.KuikaY_MontBlancAylikSatisKarsilastirma), "any"),
				header_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.convertToTypeByName("Karşılaştırmalı Mont Blanc Şubat Ayı Satış Raporu", "string"), "string"),
				footer_0: ReactSystemFunctions.convertToTypeByName("", "string"),
				columns_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.convertToTypeByName("Magaza,SubatAdet2025,SubatAdet2026,SubatAdetDegisim,SubatTL2025,SubatTL2026,SubatTLDegisim,SubatEUR2025,SubatEUR2026", "string"), "string")
        }

		KuikaAppManager.showSpinner(this);
		
        if (true) {
        KuikaAppManager.showSpinner(this);
        }
        let result = await KuikaAppManager.ApiRequest(this, "MontBlancBasedReporting/MontBlancBasedReportingComponent_305217_onClick", localVar)
        if (!KMainFunctions.IsResStatus2XX(result)) return true;

			stateVars.ExportExcel = result?.data.exportExcel;
			ReactSystemFunctions.downloadFile(result?.data?.exportExcel);
			this.props.form?.setFieldsValue(formVars);
			this.setState(stateVars);
			KuikaAppManager.hideSpinner(this);



        this.setPageInitLoaded(true);
        KuikaAppManager.hideSpinner(this);
        return isErrorOccurred;
    }



    MontBlancBasedReportingComponent_149097_onClick = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
		KuikaAppManager.increaseServerRequestCount();

        let localVar = {
				value_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, this.state.KuikaY_MontBlancAylikSatisKarsilastirma), "any"),
				header_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.convertToTypeByName("Karşılaştırmalı Mont Blanc Mart Ayı Satış Raporu", "string"), "string"),
				footer_0: ReactSystemFunctions.convertToTypeByName("", "string"),
				columns_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.convertToTypeByName("Magaza,MartAdet2025,MartAdet2026,MartAdetDegisim,MartTL2025,MartTL2026,MartTLDegisim,MartEUR2025,MartEUR2026", "string"), "string")
        }

		KuikaAppManager.showSpinner(this);
		
        if (true) {
        KuikaAppManager.showSpinner(this);
        }
        let result = await KuikaAppManager.ApiRequest(this, "MontBlancBasedReporting/MontBlancBasedReportingComponent_149097_onClick", localVar)
        if (!KMainFunctions.IsResStatus2XX(result)) return true;

			stateVars.ExportExcel = result?.data.exportExcel;
			ReactSystemFunctions.downloadFile(result?.data?.exportExcel);
			this.props.form?.setFieldsValue(formVars);
			this.setState(stateVars);
			KuikaAppManager.hideSpinner(this);



        this.setPageInitLoaded(true);
        KuikaAppManager.hideSpinner(this);
        return isErrorOccurred;
    }



    MontBlancBasedReportingComponent_38496_onClick = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
		KuikaAppManager.increaseServerRequestCount();

        let localVar = {
				value_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, this.state.KuikaY_MontBlancAylikSatisKarsilastirma), "any"),
				header_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.convertToTypeByName("Karşılaştırmalı Mont Blanc Nisan Ayı Satış Raporu", "string"), "string"),
				footer_0: ReactSystemFunctions.convertToTypeByName("", "string"),
				columns_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.convertToTypeByName("Magaza,NisanAdet2025,NisanAdet2026,NisanAdetDegisim,NisanTL2025,NisanTL2026,NisanTLDegisim,NisanEUR2025,NisanEUR2026", "string"), "string")
        }

		KuikaAppManager.showSpinner(this);
		
        if (true) {
        KuikaAppManager.showSpinner(this);
        }
        let result = await KuikaAppManager.ApiRequest(this, "MontBlancBasedReporting/MontBlancBasedReportingComponent_38496_onClick", localVar)
        if (!KMainFunctions.IsResStatus2XX(result)) return true;

			stateVars.ExportExcel = result?.data.exportExcel;
			ReactSystemFunctions.downloadFile(result?.data?.exportExcel);
			this.props.form?.setFieldsValue(formVars);
			this.setState(stateVars);
			KuikaAppManager.hideSpinner(this);



        this.setPageInitLoaded(true);
        KuikaAppManager.hideSpinner(this);
        return isErrorOccurred;
    }



    MontBlancBasedReportingComponent_588198_onClick = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
		KuikaAppManager.increaseServerRequestCount();

        let localVar = {
				value_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, this.state.KuikaY_MontBlancAylikSatisKarsilastirma), "any"),
				header_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.convertToTypeByName("Karşılaştırmalı Mont Blanc Mayıs Ayı Satış Raporu", "string"), "string"),
				footer_0: ReactSystemFunctions.convertToTypeByName("", "string"),
				columns_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.convertToTypeByName("Magaza,MayisAdet2025,MayisAdet2026,MayisAdetDegisim,MayisTL2025,MayisTL2026,MayisTLDegisim,MayisEUR2025,MayisEUR2026", "string"), "string")
        }

		KuikaAppManager.showSpinner(this);
		
        if (true) {
        KuikaAppManager.showSpinner(this);
        }
        let result = await KuikaAppManager.ApiRequest(this, "MontBlancBasedReporting/MontBlancBasedReportingComponent_588198_onClick", localVar)
        if (!KMainFunctions.IsResStatus2XX(result)) return true;

			stateVars.ExportExcel = result?.data.exportExcel;
			ReactSystemFunctions.downloadFile(result?.data?.exportExcel);
			this.props.form?.setFieldsValue(formVars);
			this.setState(stateVars);
			KuikaAppManager.hideSpinner(this);



        this.setPageInitLoaded(true);
        KuikaAppManager.hideSpinner(this);
        return isErrorOccurred;
    }



    MontBlancBasedReportingComponent_188067_onClick = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
		KuikaAppManager.increaseServerRequestCount();

        let localVar = {
				value_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, this.state.KuikaY_MontBlancAylikSatisKarsilastirma), "any"),
				header_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.convertToTypeByName("Karşılaştırmalı Mont Blanc Haziran Ayı Satış Raporu", "string"), "string"),
				footer_0: ReactSystemFunctions.convertToTypeByName("", "string"),
				columns_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.convertToTypeByName("Magaza,HaziranAdet2025,HaziranAdet2026,HaziranAdetDegisim,HaziranTL2025,HaziranTL2026,HaziranTLDegisim,HaziranEUR2025,HaziranEUR2026", "string"), "string")
        }

		KuikaAppManager.showSpinner(this);
		
        if (true) {
        KuikaAppManager.showSpinner(this);
        }
        let result = await KuikaAppManager.ApiRequest(this, "MontBlancBasedReporting/MontBlancBasedReportingComponent_188067_onClick", localVar)
        if (!KMainFunctions.IsResStatus2XX(result)) return true;

			stateVars.ExportExcel = result?.data.exportExcel;
			ReactSystemFunctions.downloadFile(result?.data?.exportExcel);
			this.props.form?.setFieldsValue(formVars);
			this.setState(stateVars);
			KuikaAppManager.hideSpinner(this);



        this.setPageInitLoaded(true);
        KuikaAppManager.hideSpinner(this);
        return isErrorOccurred;
    }



    MontBlancBasedReportingComponent_281301_onClick = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
		KuikaAppManager.increaseServerRequestCount();

        let localVar = {
				value_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, this.state.KuikaY_MontBlancAylikSatisKarsilastirma), "any"),
				header_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.convertToTypeByName("Karşılaştırmalı Mont Blanc Temmuz Ayı Satış Raporu", "string"), "string"),
				footer_0: ReactSystemFunctions.convertToTypeByName("", "string"),
				columns_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.convertToTypeByName("Magaza,TemmuzAdet2025,TemmuzAdet2026,TemmuzAdetDegisim,TemmuzTL2025,TemmuzTL2026,TemmuzTLDegisim,TemmuzEUR2025,TemmuzEUR2026", "string"), "string")
        }

		KuikaAppManager.showSpinner(this);
		
        if (true) {
        KuikaAppManager.showSpinner(this);
        }
        let result = await KuikaAppManager.ApiRequest(this, "MontBlancBasedReporting/MontBlancBasedReportingComponent_281301_onClick", localVar)
        if (!KMainFunctions.IsResStatus2XX(result)) return true;

			stateVars.ExportExcel = result?.data.exportExcel;
			ReactSystemFunctions.downloadFile(result?.data?.exportExcel);
			this.props.form?.setFieldsValue(formVars);
			this.setState(stateVars);
			KuikaAppManager.hideSpinner(this);



        this.setPageInitLoaded(true);
        KuikaAppManager.hideSpinner(this);
        return isErrorOccurred;
    }



    MontBlancBasedReportingComponent_305112_onClick = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
		KuikaAppManager.increaseServerRequestCount();

        let localVar = {
				value_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, this.state.KuikaY_MontBlancAylikSatisKarsilastirma), "any"),
				header_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.convertToTypeByName("Karşılaştırmalı Mont Blanc Ağustos Ayı Satış Raporu", "string"), "string"),
				footer_0: ReactSystemFunctions.convertToTypeByName("", "string"),
				columns_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.convertToTypeByName("Magaza,AgustosAdet2025,AgustosAdet2026,AgustosAdetDegisim,AgustosTL2025,AgustosTL2026,AgustosTLDegisim,AgustosEUR2025,AgustosEUR2026", "string"), "string")
        }

		KuikaAppManager.showSpinner(this);
		
        if (true) {
        KuikaAppManager.showSpinner(this);
        }
        let result = await KuikaAppManager.ApiRequest(this, "MontBlancBasedReporting/MontBlancBasedReportingComponent_305112_onClick", localVar)
        if (!KMainFunctions.IsResStatus2XX(result)) return true;

			stateVars.ExportExcel = result?.data.exportExcel;
			ReactSystemFunctions.downloadFile(result?.data?.exportExcel);
			this.props.form?.setFieldsValue(formVars);
			this.setState(stateVars);
			KuikaAppManager.hideSpinner(this);



        this.setPageInitLoaded(true);
        KuikaAppManager.hideSpinner(this);
        return isErrorOccurred;
    }



    MontBlancBasedReportingComponent_219469_onClick = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
		KuikaAppManager.increaseServerRequestCount();

        let localVar = {
				value_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, this.state.KuikaY_MontBlancAylikSatisKarsilastirma), "any"),
				header_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.convertToTypeByName("Karşılaştırmalı Mont Blanc Eylül Ayı Satış Raporu", "string"), "string"),
				footer_0: ReactSystemFunctions.convertToTypeByName("", "string"),
				columns_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.convertToTypeByName("Magaza,EylulAdet2025,EylulAdet2026,EylulAdetDegisim,EylulTL2025,EylulTL2026,EylulTLDegisim,EylulEUR2025,EylulEUR2026", "string"), "string")
        }

		KuikaAppManager.showSpinner(this);
		
        if (true) {
        KuikaAppManager.showSpinner(this);
        }
        let result = await KuikaAppManager.ApiRequest(this, "MontBlancBasedReporting/MontBlancBasedReportingComponent_219469_onClick", localVar)
        if (!KMainFunctions.IsResStatus2XX(result)) return true;

			stateVars.ExportExcel = result?.data.exportExcel;
			ReactSystemFunctions.downloadFile(result?.data?.exportExcel);
			this.props.form?.setFieldsValue(formVars);
			this.setState(stateVars);
			KuikaAppManager.hideSpinner(this);



        this.setPageInitLoaded(true);
        KuikaAppManager.hideSpinner(this);
        return isErrorOccurred;
    }



    MontBlancBasedReportingComponent_176146_onClick = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
		KuikaAppManager.increaseServerRequestCount();

        let localVar = {
				value_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, this.state.KuikaY_MontBlancAylikSatisKarsilastirma), "any"),
				header_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.convertToTypeByName("Karşılaştırmalı Mont Blanc Ekim Ayı Satış Raporu", "string"), "string"),
				footer_0: ReactSystemFunctions.convertToTypeByName("", "string"),
				columns_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.convertToTypeByName("Magaza,EkimAdet2025,EkimAdet2026,EkimAdetDegisim,EkimTL2025,EkimTL2026,EkimTLDegisim,EkimEUR2025,EkimEUR2026", "string"), "string")
        }

		KuikaAppManager.showSpinner(this);
		
        if (true) {
        KuikaAppManager.showSpinner(this);
        }
        let result = await KuikaAppManager.ApiRequest(this, "MontBlancBasedReporting/MontBlancBasedReportingComponent_176146_onClick", localVar)
        if (!KMainFunctions.IsResStatus2XX(result)) return true;

			stateVars.ExportExcel = result?.data.exportExcel;
			ReactSystemFunctions.downloadFile(result?.data?.exportExcel);
			this.props.form?.setFieldsValue(formVars);
			this.setState(stateVars);
			KuikaAppManager.hideSpinner(this);



        this.setPageInitLoaded(true);
        KuikaAppManager.hideSpinner(this);
        return isErrorOccurred;
    }



    MontBlancBasedReportingComponent_828823_onClick = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
		KuikaAppManager.increaseServerRequestCount();

        let localVar = {
				value_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, this.state.KuikaY_MontBlancAylikSatisKarsilastirma), "any"),
				header_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.convertToTypeByName("Karşılaştırmalı Mont Blanc Kasım Ayı Satış Raporu", "string"), "string"),
				footer_0: ReactSystemFunctions.convertToTypeByName("", "string"),
				columns_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.convertToTypeByName("Magaza,KasimAdet2025,KasimAdet2026,KasimAdetDegisim,KasimTL2025,KasimTL2026,KasimTLDegisim,KasimEUR2025,KasimEUR2026", "string"), "string")
        }

		KuikaAppManager.showSpinner(this);
		
        if (true) {
        KuikaAppManager.showSpinner(this);
        }
        let result = await KuikaAppManager.ApiRequest(this, "MontBlancBasedReporting/MontBlancBasedReportingComponent_828823_onClick", localVar)
        if (!KMainFunctions.IsResStatus2XX(result)) return true;

			stateVars.ExportExcel = result?.data.exportExcel;
			ReactSystemFunctions.downloadFile(result?.data?.exportExcel);
			this.props.form?.setFieldsValue(formVars);
			this.setState(stateVars);
			KuikaAppManager.hideSpinner(this);



        this.setPageInitLoaded(true);
        KuikaAppManager.hideSpinner(this);
        return isErrorOccurred;
    }



    MontBlancBasedReportingComponent_445219_onClick = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
		KuikaAppManager.increaseServerRequestCount();

        let localVar = {
				value_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, this.state.KuikaY_MontBlancAylikSatisKarsilastirma), "any"),
				header_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.convertToTypeByName("Karşılaştırmalı Mont Blanc Aralık Ayı Satış Raporu", "string"), "string"),
				footer_0: ReactSystemFunctions.convertToTypeByName("", "string"),
				columns_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.convertToTypeByName("Magaza,AralikAdet2025,AralikAdet2026,AralikAdetDegisim,AralikTL2025,AralikTL2026,AralikTLDegisim,AralikEUR2025,AralikEUR2026", "string"), "string")
        }

		KuikaAppManager.showSpinner(this);
		
        if (true) {
        KuikaAppManager.showSpinner(this);
        }
        let result = await KuikaAppManager.ApiRequest(this, "MontBlancBasedReporting/MontBlancBasedReportingComponent_445219_onClick", localVar)
        if (!KMainFunctions.IsResStatus2XX(result)) return true;

			stateVars.ExportExcel = result?.data.exportExcel;
			ReactSystemFunctions.downloadFile(result?.data?.exportExcel);
			this.props.form?.setFieldsValue(formVars);
			this.setState(stateVars);
			KuikaAppManager.hideSpinner(this);



        this.setPageInitLoaded(true);
        KuikaAppManager.hideSpinner(this);
        return isErrorOccurred;
    }



		MontBlancBasedReportingComponent_625329_onChange = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
KuikaAppManager.showSpinner(this);

				
				ReactSystemFunctions.setValueOf(this, "montblancbasedreporting_913824_toString", ReactSystemFunctions.value(this, "montblancbasedreporting_625329_value", "value"), "value");

				
				ReactSystemFunctions.setValueOf(this, "montblancbasedreporting_977769_toString", ReactSystemFunctions.value(this, "montblancbasedreporting_625329_value", "value"), "value");

				
				ReactSystemFunctions.setValueOf(this, "montblancbasedreporting_242269_toString", ReactSystemFunctions.value(this, "montblancbasedreporting_625329_value", "value"), "value");

				
				ReactSystemFunctions.setValueOf(this, "montblancbasedreporting_572095_toString", ReactSystemFunctions.value(this, "montblancbasedreporting_625329_value", "value"), "value");

				
				ReactSystemFunctions.setValueOf(this, "montblancbasedreporting_513932_toString", ReactSystemFunctions.value(this, "montblancbasedreporting_625329_value", "value"), "value");

				
				ReactSystemFunctions.setValueOf(this, "montblancbasedreporting_40814_toString", ReactSystemFunctions.value(this, "montblancbasedreporting_625329_value", "value"), "value");

				
				ReactSystemFunctions.setValueOf(this, "montblancbasedreporting_11901_toString", ReactSystemFunctions.value(this, "montblancbasedreporting_625329_value", "value"), "value");

				
				ReactSystemFunctions.setValueOf(this, "montblancbasedreporting_897218_toString", ReactSystemFunctions.value(this, "montblancbasedreporting_625329_value", "value"), "value");

				
				ReactSystemFunctions.setValueOf(this, "montblancbasedreporting_613320_toString", ReactSystemFunctions.value(this, "montblancbasedreporting_625329_value", "value"), "value");

				
				ReactSystemFunctions.setValueOf(this, "montblancbasedreporting_719512_toString", ReactSystemFunctions.value(this, "montblancbasedreporting_625329_value", "value"), "value");

				
				ReactSystemFunctions.setValueOf(this, "montblancbasedreporting_167195_toString", ReactSystemFunctions.value(this, "montblancbasedreporting_625329_value", "value"), "value");

				
				ReactSystemFunctions.setValueOf(this, "montblancbasedreporting_882679_toString", ReactSystemFunctions.value(this, "montblancbasedreporting_625329_value", "value"), "value");


		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

            
            return isErrorOccurred;
        }


		MontBlancBasedReportingComponent_996749_onChange = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
KuikaAppManager.showSpinner(this);

				
				ReactSystemFunctions.setValueOf(this, "montblancbasedreporting_437822_toString", ReactSystemFunctions.value(this, "montblancbasedreporting_996749_value", "value"), "value");

				
				ReactSystemFunctions.setValueOf(this, "montblancbasedreporting_371613_toString", ReactSystemFunctions.value(this, "montblancbasedreporting_996749_value", "value"), "value");

				
				ReactSystemFunctions.setValueOf(this, "montblancbasedreporting_64323_toString", ReactSystemFunctions.value(this, "montblancbasedreporting_996749_value", "value"), "value");

				
				ReactSystemFunctions.setValueOf(this, "montblancbasedreporting_356185_toString", ReactSystemFunctions.value(this, "montblancbasedreporting_996749_value", "value"), "value");

				
				ReactSystemFunctions.setValueOf(this, "montblancbasedreporting_688898_toString", ReactSystemFunctions.value(this, "montblancbasedreporting_996749_value", "value"), "value");

				
				ReactSystemFunctions.setValueOf(this, "montblancbasedreporting_912493_toString", ReactSystemFunctions.value(this, "montblancbasedreporting_996749_value", "value"), "value");

				
				ReactSystemFunctions.setValueOf(this, "montblancbasedreporting_419343_toString", ReactSystemFunctions.value(this, "montblancbasedreporting_996749_value", "value"), "value");

				
				ReactSystemFunctions.setValueOf(this, "montblancbasedreporting_85132_toString", ReactSystemFunctions.value(this, "montblancbasedreporting_996749_value", "value"), "value");

				
				ReactSystemFunctions.setValueOf(this, "montblancbasedreporting_650687_toString", ReactSystemFunctions.value(this, "montblancbasedreporting_996749_value", "value"), "value");

				
				ReactSystemFunctions.setValueOf(this, "montblancbasedreporting_432510_toString", ReactSystemFunctions.value(this, "montblancbasedreporting_996749_value", "value"), "value");

				
				ReactSystemFunctions.setValueOf(this, "montblancbasedreporting_500608_toString", ReactSystemFunctions.value(this, "montblancbasedreporting_996749_value", "value"), "value");

				
				ReactSystemFunctions.setValueOf(this, "montblancbasedreporting_300162_toString", ReactSystemFunctions.value(this, "montblancbasedreporting_996749_value", "value"), "value");


		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

            
            return isErrorOccurred;
        }




    async callCallbackFunction(diId: number, isFromMaster: boolean = false) {
        let isErrorOccurred = false;
		let pageInitCallerNavDiIDs = [, , ] as number[];
		if (isFromMaster || pageInitCallerNavDiIDs.indexOf(diId) > -1) {
			await this.MontBlancBasedReportingPageInit();
		}

    }


}
