import React from "react";
import Axios, { AxiosResponse } from "axios";
import { KuikaAppManager } from "../../shared/utilty/kuika-app-manager";
import { ReactSystemFunctions } from "../../shared/utilty/react-system-functions";
import { KNavigator } from "../../shared/hoc/with-history";
import { KContext } from "../../shared/hoc/with-context";
import { useLocation } from "react-router-dom";
import { FormInstance } from "antd/es/form";
import { Guid } from "guid-typescript";
import Swal from "sweetalert2";
import { KMainFunctions } from "../../shared/utilty/main-functions";
import moment from "moment";
import { IValidationData } from "../../models/dto/validation-data";
import { IStripePayment } from "../../models/dto/stripe-payment";
import { IUserInfoDto } from "../../models/dto/user-info.dto";
import { UserService } from "../../services/user-service";
import { kuikaCoreWasmBridgeService } from "../../services/_singletons";
import _ from "lodash";
import mqtt, { MqttClient } from "mqtt";
import { IMqttResult } from "../../models/dto/mqtt.dto";


declare let window: any;

export interface ILeadDetailTemp_ScreenProps {
  navigator: KNavigator;
  form: FormInstance<any>;
  googleLogin: any;
  screenInputs: any;
  context: KContext;
  initialValues: any;
  children: any;
}

export interface ILeadDetailTemp_ScreenState {
    isSpinnerVisible: boolean;
    isPageVisible: boolean;
	isLeftMenuVisible: boolean;
    spinnerCount: number;
    selectedLanguage: string;
    isPageInitLoaded: false;
    isPageRecurringLoaded: false;
	TM_UserRoleByUserId: any[];
	TM_UserRoleByUserId_dummy: any[];
	TM_ShowButton: any[];
	TM_ShowButton_dummy: any[];
	TMApproveLeadAndReservation: any[];
	TMApproveLeadAndReservation_dummy: any[];
	TM_GetLeadStatus: any[];
	TM_GetLeadStatus_dummy: any[];
	TM_CheckLeadApprovalPermission: any[];
	TM_CheckLeadApprovalPermission_dummy: any[];
	TM_GetLeadById: any[];
	TM_GetLeadById_dummy: any[];
	TM_GetReserveEditShow: any[];
	TM_GetReserveEditShow_dummy: any[];
	GetLeadNotes: any[];
	GetLeadNotes_dummy: any[];
	TM_GetLeadNoteFileCounts: any[];
	TM_GetLeadNoteFileCounts_dummy: any[];
	TM_GetLeadLogById: any[];
	TM_GetLeadLogById_dummy: any[];
	TM_GetLeadAlternativeModel: any[];
	TM_GetLeadAlternativeModel_dummy: any[];
	TM_GetLeadLogStatu: any[];
	TM_GetLeadLogStatu_dummy: any[];
	GoBack: any;
	GoBack_dummy: any;
	NAVIGATE: any;
	NAVIGATE_dummy: any;
	TM_LeadNoteDelete: any[];
	TM_LeadNoteDelete_dummy: any[];
	Notify: boolean;
	Notify_dummy: boolean;
	TriggerEvent: string;
	TriggerEvent_dummy: string;
	DownloadFile: any;
	DownloadFile_dummy: any;
	isComp36328Visible: 'visible' | 'hidden';
	isComp748568Visible: 'visible' | 'hidden';
	isComp170155Visible: 'visible' | 'hidden';
	isComp216308Visible: 'visible' | 'hidden';
	isComp659656Visible: 'visible' | 'hidden';
	isComp835987Visible: 'visible' | 'hidden';
	isComp483112Visible: 'visible' | 'hidden';
	isComp828004Visible: 'visible' | 'hidden';
	isComp44587Visible: 'visible' | 'hidden';
	isComp7937Visible: 'visible' | 'hidden';
	isComp170642Visible: 'visible' | 'hidden';
	isComp201879Visible: 'visible' | 'hidden';
	isComp566330Visible: 'visible' | 'hidden';
	isComp845662Visible: 'visible' | 'hidden';
	isComp874015Visible: 'visible' | 'hidden';
	isComp190939Visible: 'visible' | 'hidden';
	isComp161533Visible: 'visible' | 'hidden';
	isComp459206Visible: 'visible' | 'hidden';
	isComp901181Visible: 'visible' | 'hidden';
	isComp430984Visible: 'visible' | 'hidden';
	isComp795139Visible: 'visible' | 'hidden';
	isComp645253Visible: 'visible' | 'hidden';
	isComp115165Visible: 'visible' | 'hidden';
	isComp768832Visible: 'visible' | 'hidden';
	isComp599506Visible: 'visible' | 'hidden';
	isComp999529Visible: 'visible' | 'hidden';
	isComp325540Visible: 'visible' | 'hidden';
	isComp361732Visible: 'visible' | 'hidden';
	isComp557236Visible: 'visible' | 'hidden';
	isComp850874Visible: 'visible' | 'hidden';
	isComp463829Visible: 'visible' | 'hidden';
	isComp1999Visible: 'visible' | 'hidden';
	isComp624559Visible: 'visible' | 'hidden';
	isComp332184Visible: 'visible' | 'hidden';
	isComp796102Visible: 'visible' | 'hidden';
	isComp158975Visible: 'visible' | 'hidden';
	isComp927510Visible: 'visible' | 'hidden';

}

export class LeadDetailTemp_ScreenBase extends React.PureComponent<ILeadDetailTemp_ScreenProps, any> {

	leaddetailtemp_135379_value_kuikaTableRef: React.RefObject<any>;
	leaddetailtemp_811809_value_kuikaGalleryViewRef: React.RefObject<any>;
	leaddetailtemp_577683_value_kuikaTableRef: React.RefObject<any>;
	leaddetailtemp_256215_value_kuikaAutoCompleteRef: React.RefObject<any>;
	leaddetailtemp_424782_value_kuikaTableRef: React.RefObject<any>;
    ml=[{"Id":"d5a61d2b-bd60-485f-86e2-661e9ed4e486","Name":"en_US","ShortName":"English","IsDefault":true,"LanguagePhrases":[]},{"Id":"ded9ee37-e0c1-431f-b6e8-40a7053e1df9","Name":"FixedValues","ShortName":"FixedValues","LanguagePhrases":[{"Id":970539,"PropertyName":"value","Value":"Talep Detay Ekranı"},{"Id":583664,"PropertyName":"value","Value":"İşlem Paneli"},{"Id":987613,"PropertyName":"value","Value":"Talep üzerinde uygulanabilecek aksiyonlar"},{"Id":748568,"PropertyName":"label","Value":"Termin Ver ve Onayla"},{"Id":170155,"PropertyName":"label","Value":"Onayla ve Rezerve Et"},{"Id":216308,"PropertyName":"label","Value":"Termin Önerisi Ver ve Onaya Gönder"},{"Id":659656,"PropertyName":"label","Value":"Satış Yap ve Teslim Et"},{"Id":835987,"PropertyName":"label","Value":"Rezerveyi Düzenle"},{"Id":483112,"PropertyName":"label","Value":"Rezerv Talebini Onayla"},{"Id":44587,"PropertyName":"label","Value":"Müşteri İstemedi"},{"Id":7937,"PropertyName":"label","Value":"Talebi Reddet"},{"Id":170582,"PropertyName":"value","Value":"Talep Bilgileri"},{"Id":140409,"PropertyName":"label","Value":"Talep İşlemleri"},{"Id":170642,"PropertyName":"label","Value":"Düzenle"},{"Id":201879,"PropertyName":"label","Value":"Ürün Değiştir & Talebi Kapat"},{"Id":978689,"PropertyName":"value","Value":"Müşteri Bilgileri"},{"Id":615426,"PropertyName":"value","Value":"Müşteri Adı"},{"Id":612014,"PropertyName":"value","Value":"Telefon No"},{"Id":226012,"PropertyName":"value","Value":"Mail"},{"Id":852615,"PropertyName":"value","Value":"Şehir / Lokasyon"},{"Id":166279,"PropertyName":"value","Value":"Müşteri Info"},{"Id":312473,"PropertyName":"value","Value":"Müşteri Referansı"},{"Id":624202,"PropertyName":"value","Value":"Müşteri Referansı Telefon No"},{"Id":638685,"PropertyName":"value","Value":"Talep Bilgileri"},{"Id":131553,"PropertyName":"value","Value":"Talep Durumu"},{"Id":877905,"PropertyName":"value","Value":"Termin Tarihi"},{"Id":701412,"PropertyName":"value","Value":"Reddedilme Notu"},{"Id":611995,"PropertyName":"value","Value":"Talep Oluşturma Tarihi"},{"Id":716771,"PropertyName":"value","Value":"Son Statü Değişikliği"},{"Id":728187,"PropertyName":"value","Value":"Takip Durumu"},{"Id":874840,"PropertyName":"value","Value":"Sonraki Adım"},{"Id":353895,"PropertyName":"value","Value":"İletişim Kaynağı"},{"Id":325362,"PropertyName":"value","Value":"Ürün Bilgileri"},{"Id":346673,"PropertyName":"value","Value":"Ürün Adı"},{"Id":639555,"PropertyName":"value","Value":"Marka"},{"Id":100777,"PropertyName":"value","Value":"Model"},{"Id":5715,"PropertyName":"value","Value":"Kadran"},{"Id":470916,"PropertyName":"value","Value":"Bilezik"},{"Id":725959,"PropertyName":"value","Value":"Kategori"},{"Id":612024,"PropertyName":"value","Value":"Personel Bilgisi"},{"Id":774244,"PropertyName":"value","Value":"Satış Personeli"},{"Id":997272,"PropertyName":"value","Value":"Mağaza"},{"Id":548781,"PropertyName":"value","Value":"Rezerve Durumu"},{"Id":999529,"PropertyName":"value","Value":"Evet"},{"Id":325540,"PropertyName":"value","Value":"Hayır"},{"Id":361732,"PropertyName":"value","Value":"Onay Bekliyor"},{"Id":244008,"PropertyName":"value","Value":"Talep Notu"},{"Id":698916,"PropertyName":"value","Value":"Satış Bilgisi"},{"Id":850693,"PropertyName":"value","Value":"Sunulan Alternatif Modeller"},{"Id":870985,"PropertyName":"value","Value":"Talep için önerilen alternatif ürünler"},{"Id":507691,"PropertyName":"label","Value":"Ekle / Sil"},{"Id":981930,"PropertyName":"title","Value":"Ürün Adı"},{"Id":110898,"PropertyName":"value","Value":"[datafield:productname]"},{"Id":302502,"PropertyName":"title","Value":"Kategori"},{"Id":850874,"PropertyName":"value","Value":"[datafield:categoryname]"},{"Id":463829,"PropertyName":"value","Value":"[datafield:categoryname]"},{"Id":1999,"PropertyName":"value","Value":"[datafield:categoryname]"},{"Id":624559,"PropertyName":"value","Value":"[datafield:categoryname]"},{"Id":266166,"PropertyName":"value","Value":"Bu talep için alternatif model eklenmemiş."},{"Id":301297,"PropertyName":"value","Value":"Alternatif ürün eklendiğinde burada sade liste görünümüyle gösterilecektir."},{"Id":908517,"PropertyName":"tab","Value":"Talep Notları"},{"Id":68749,"PropertyName":"label","Value":"Dosyaları Görüntüle"},{"Id":736090,"PropertyName":"label","Value":"Not Ekle"},{"Id":811809,"PropertyName":"nodatafoundmessage","Value":"No data found."},{"Id":383238,"PropertyName":"value","Value":"[datafield:createdbyname]"},{"Id":674274,"PropertyName":"value","Value":"[datafield:rolename]"},{"Id":832523,"PropertyName":"value","Value":"[datafield:createdattext]"},{"Id":796102,"PropertyName":"label","Value":"Düzenle"},{"Id":436307,"PropertyName":"label","Value":"Sil"},{"Id":473941,"PropertyName":"value","Value":"[datafield:note]"},{"Id":545518,"PropertyName":"value","Value":"Eklenen Dosyalar"},{"Id":883130,"PropertyName":"value","Value":"[datafield:filecount]"},{"Id":964927,"PropertyName":"title","Value":"Title"},{"Id":645501,"PropertyName":"tab","Value":"Log Kayıtları"},{"Id":256215,"PropertyName":"placeholder","Value":"Değiştirilen Alan"},{"Id":760282,"PropertyName":"placeholder","Value":"Değişiklik Yapan Kullanıcı"},{"Id":67677,"PropertyName":"startDatePlaceholder","Value":"Başlangıç Tarihi"},{"Id":67677,"PropertyName":"endDatePlaceholder","Value":"Bitiş Tarihi"},{"Id":162894,"PropertyName":"title","Value":"Değiştirilen Alan"},{"Id":425575,"PropertyName":"value","Value":"[datafield:columnname]"},{"Id":589646,"PropertyName":"title","Value":"Not "},{"Id":305593,"PropertyName":"value","Value":"[datafield:note]"},{"Id":408180,"PropertyName":"title","Value":"Eski Değer"},{"Id":377281,"PropertyName":"value","Value":"[datafield:oldvalue]"},{"Id":448161,"PropertyName":"title","Value":"Yeni Değer"},{"Id":55098,"PropertyName":"value","Value":"[datafield:newvalue]"},{"Id":193603,"PropertyName":"title","Value":"Değişlik Yapan Kullanıcı"},{"Id":605138,"PropertyName":"value","Value":"[datafield:username]"},{"Id":906178,"PropertyName":"title","Value":"Değişiklik Tarihi"},{"Id":328141,"PropertyName":"value","Value":"[datafield:logdate]"},{"Id":551397,"PropertyName":"value","Value":"Satış Başarıyla Tamamlandı"},{"Id":353850,"PropertyName":"value","Value":"Lead satışı başarıyla tamamlandı. Satış bilgileri sisteme kaydedildi."},{"Id":840265,"PropertyName":"value","Value":"Satış işlemi başarıyla gerçekleştirildi."},{"Id":171032,"PropertyName":"value","Value":"Satış Özeti"},{"Id":302236,"PropertyName":"value","Value":"Müşteri"},{"Id":983707,"PropertyName":"value","Value":"Ayşe Yılmaz"},{"Id":182034,"PropertyName":"value","Value":"Satış Tarihi"},{"Id":719245,"PropertyName":"value","Value":"24.05.2025"},{"Id":883294,"PropertyName":"value","Value":"Mağaza"},{"Id":867391,"PropertyName":"value","Value":"Merkez Mağaza"},{"Id":255118,"PropertyName":"value","Value":"Satış Personeli"},{"Id":939517,"PropertyName":"value","Value":"Mehmet Kaya"},{"Id":276586,"PropertyName":"value","Value":"Ürün"},{"Id":759044,"PropertyName":"value","Value":"Premium Paket"},{"Id":339138,"PropertyName":"value","Value":"Adet"},{"Id":181360,"PropertyName":"value","Value":"1"},{"Id":751488,"PropertyName":"value","Value":"Toplam Tutar"},{"Id":726515,"PropertyName":"value","Value":"12.500,00"},{"Id":286903,"PropertyName":"value","Value":"Para Birimi"},{"Id":647808,"PropertyName":"value","Value":"TRY"},{"Id":478020,"PropertyName":"value","Value":"Ödeme Tipi"},{"Id":247679,"PropertyName":"value","Value":"Kredi Kartı"},{"Id":682826,"PropertyName":"value","Value":"Fatura/Belge No"},{"Id":739932,"PropertyName":"value","Value":"INV-2025-00482"},{"Id":988348,"PropertyName":"value","Value":"Sonraki İşlem"},{"Id":577798,"PropertyName":"value","Value":"Satış Listesine Git"},{"Id":148825,"PropertyName":"value","Value":"Tamamlanan satışları görüntüleyin"},{"Id":466553,"PropertyName":"value","Value":"Yeni Satış Yap"},{"Id":558832,"PropertyName":"value","Value":"Yeni bir lead satışı başlatın"}]}]
    defaultML = "en_US"
    
    screenHash = ""
    


    constructor(props) {
        super(props);
		this.leaddetailtemp_135379_value_kuikaTableRef = React.createRef();
		this.leaddetailtemp_811809_value_kuikaGalleryViewRef = React.createRef();
		this.leaddetailtemp_577683_value_kuikaTableRef = React.createRef();
		this.leaddetailtemp_256215_value_kuikaAutoCompleteRef = React.createRef();
		this.leaddetailtemp_760282_value_kuikaTextInputRef = React.createRef();
		this.leaddetailtemp_424782_value_kuikaTableRef = React.createRef();

        this.state = {
            isSpinnerVisible: false,
            isPageVisible: false,
            isLeftMenuVisible: false,
            spinnerCount: 0,
            selectedLanguage: "",
            isPageInitLoaded: false,
            isPageRecurringLoaded: false,
            	        TM_UserRoleByUserId: [],
	        TM_ShowButton: [],
	        TMApproveLeadAndReservation: [],
	        TM_GetLeadStatus: [],
	        TM_CheckLeadApprovalPermission: [],
	        TM_GetLeadById: [],
	        TM_GetReserveEditShow: [],
	        GetLeadNotes: [],
	        TM_GetLeadNoteFileCounts: [],
	        TM_GetLeadLogById: [],
	        TM_GetLeadAlternativeModel: [],
	        TM_GetLeadLogStatu: [],
	        GoBack: "",
	        NAVIGATE: "",
	        TM_LeadNoteDelete: [],
	        Notify: false,
	        TriggerEvent: "",
	        DownloadFile: "",
	        isComp36328Visible: 'hidden',
	        isComp748568Visible: 'hidden',
	        isComp170155Visible: 'hidden',
	        isComp216308Visible: 'hidden',
	        isComp659656Visible: 'hidden',
	        isComp835987Visible: 'hidden',
	        isComp483112Visible: 'hidden',
	        isComp828004Visible: 'hidden',
	        isComp44587Visible: 'hidden',
	        isComp7937Visible: 'hidden',
	        isComp170642Visible: 'hidden',
	        isComp201879Visible: 'hidden',
	        isComp566330Visible: 'hidden',
	        isComp845662Visible: 'hidden',
	        isComp874015Visible: 'hidden',
	        isComp190939Visible: 'hidden',
	        isComp161533Visible: 'hidden',
	        isComp459206Visible: 'hidden',
	        isComp901181Visible: 'hidden',
	        isComp430984Visible: 'hidden',
	        isComp795139Visible: 'hidden',
	        isComp645253Visible: 'hidden',
	        isComp115165Visible: 'hidden',
	        isComp768832Visible: 'hidden',
	        isComp599506Visible: 'hidden',
	        isComp999529Visible: 'hidden',
	        isComp325540Visible: 'hidden',
	        isComp361732Visible: 'hidden',
	        isComp557236Visible: 'hidden',
	        isComp850874Visible: 'hidden',
	        isComp463829Visible: 'hidden',
	        isComp1999Visible: 'hidden',
	        isComp624559Visible: 'hidden',
	        isComp332184Visible: 'hidden',
	        isComp796102Visible: 'hidden',
	        isComp158975Visible: 'hidden',
	        isComp927510Visible: 'hidden',

        }

        this.state.isPageVisible = true;
        
    }

    async componentDidMount() {

        if (KuikaAppManager.isPageInitPrevented()) {
            KuikaAppManager.calculateAndSetBodyHeight("leaddetailtemp", "");
            return;
        }
        
        
        ReactSystemFunctions.validateToken()
        this.fillFormInitValues();
        if (true){
            await this.LeadDetailTempPageInit();
        }
        
        
        
        KuikaAppManager.calculateAndSetBodyHeight("leaddetailtemp", "");

        if (ReactSystemFunctions.getIsMicroApp() === false) {
           window.parentScreen = this;
        }
    }

    componentWillUnmount() {
        
        
        

        if (ReactSystemFunctions.getIsMicroApp() === false) {
           window.parentScreen = null;
        }
    }

    

        
    componentDidUpdate= async (prevProps, prevState) => {
		KuikaAppManager.calculateAndSetBodyHeight("leaddetailtemp", ""    );
        if (prevProps?.location?.search !== (this.props as any)?.location?.search) {
			await this.LeadDetailTempPageInit();
		}

        

        if (ReactSystemFunctions.getIsMicroApp() === false) {
            for (const key in prevState) {
                if (key.startsWith('NavVisible') && prevState[key] === true && this.state[key] === false) {
                    window.parentScreen = this;
                    break;
                }
            }
        }
	}

    fillFormInitValues() {
        this.props.form?.setFieldsValue({
});

    }

      setPageInitLoaded = (value: boolean) => {
        this.setState({ isPageInitLoaded: value });
      }

      setPageRecurringLoaded = (value: boolean) => {
        this.setState({ isPageRecurringLoaded: value });
      }

      clearFieldValidation = (changedValues: any) => {
        const fieldName = Object.keys(changedValues)[0];
        if (fieldName) {
          this.props.form?.setFields([
            {
              name: fieldName,
              errors: []
            }
          ]);
        }
      };

        checkTabErrors = () => {
    document.querySelectorAll(".rc-tabs-tab").forEach((tab) => {
      (tab as HTMLElement).style.color = "";
    });

    const tabPanes = document.querySelectorAll(".rc-tabs-tabpane");
    const tabs = document.querySelectorAll(".rc-tabs-tab");

    tabPanes.forEach((tabPane, index) => {
      const uniquePaneId = `rc-tabs-tabpane-${index}`;
      if (!tabPane.hasAttribute("id")) {
        tabPane.setAttribute("id", uniquePaneId); 
      }

      const uniqueTabId = `rc-tabs-tab-${index}`;
      if (tabs[index]) {
        if (!tabs[index].hasAttribute("id")) {
          tabs[index].setAttribute("id", uniqueTabId); 
        }
        tabs[index].setAttribute("aria-controls", uniquePaneId);
      }
    });

    const errorElements = document.querySelectorAll(".rc-tabs .ant-form-item-explain-error");

    const tabsWithErrors = new Set<string>();

    errorElements.forEach((errorElement) => {
      const tabPane = errorElement.closest(".rc-tabs-tabpane");
      if (tabPane && tabPane.id) {
        tabsWithErrors.add(tabPane.id);
      }
    });

    tabsWithErrors.forEach((tabPaneId) => {
      const tab = document.querySelector(`.rc-tabs-tab[aria-controls="${tabPaneId}"]`);
      if (tab) {
        (tab as HTMLElement).style.color = "red"; 
      }
    });
  };

    LeadDetailTempPageInit = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


	if (KuikaAppManager.handleValidations(this, validations, this.checkTabErrors))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }

        let localVar = {
			UserID_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.getMyUserId(), "Guid"),
			LeadId_1: ReactSystemFunctions.convertToTypeByName(this.props.screenInputs.LeadId ?? this.props.screenInputs.leadid, "Guid"),
			UserId_1: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.getMyUserId(), "Guid"),
			UserId_2: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.getMyUserId(), "Guid"),
			LeadId_2: ReactSystemFunctions.convertToTypeByName(this.props.screenInputs.LeadId ?? this.props.screenInputs.leadid, "Guid"),
			IncomingUserRole_4: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, (stateVars.TM_UserRoleByUserId !== undefined ? (stateVars.TM_UserRoleByUserId?.length > 0 ? stateVars.TM_UserRoleByUserId[0].role : null) : (this.state.TM_UserRoleByUserId?.length > 0 ? this.state.TM_UserRoleByUserId[0].role : null))), "string"),
			IncomingLeadId_4: ReactSystemFunctions.convertToTypeByName(this.props.screenInputs.LeadId ?? this.props.screenInputs.leadid, "Guid"),
			LeadId_5: ReactSystemFunctions.convertToTypeByName(this.props.screenInputs.LeadId ?? this.props.screenInputs.leadid, "Guid"),
			UserRole_6: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, (stateVars.TM_UserRoleByUserId !== undefined ? (stateVars.TM_UserRoleByUserId?.length > 0 ? stateVars.TM_UserRoleByUserId[0].roleNames : null) : (this.state.TM_UserRoleByUserId?.length > 0 ? this.state.TM_UserRoleByUserId[0].roleNames : null))), "string"),
			LeadId_6: ReactSystemFunctions.convertToTypeByName(this.props.screenInputs.LeadId ?? this.props.screenInputs.leadid, "Guid"),
			leadId_7: ReactSystemFunctions.convertToTypeByName(this.props.screenInputs.LeadId ?? this.props.screenInputs.leadid, "string"),
			LeadId_8: ReactSystemFunctions.convertToTypeByName(this.props.screenInputs.LeadId ?? this.props.screenInputs.leadid, "Guid"),
			LeadId_9: ReactSystemFunctions.convertToTypeByName(this.props.screenInputs.LeadId ?? this.props.screenInputs.leadid, "Guid"),
			ColumnName_9: ReactSystemFunctions.convertToTypeByName(null, "string"),
			UserName_9: ReactSystemFunctions.convertToTypeByName(null, "string"),
			StartDate_9: ReactSystemFunctions.convertToTypeByName(null, "Date"),
			EndDate_9: ReactSystemFunctions.convertToTypeByName(null, "Date"),
			LeadId_10: ReactSystemFunctions.convertToTypeByName(this.props.screenInputs.LeadId ?? this.props.screenInputs.leadid, "Guid"),
			LeadId_11: ReactSystemFunctions.convertToTypeByName(this.props.screenInputs.LeadId ?? this.props.screenInputs.leadid, "Guid")
        }

	KuikaAppManager.showSpinner(this);
	
        if (true) {
        KuikaAppManager.showSpinner(this);
        }
        let result = await KuikaAppManager.ApiRequest(this, "LeadDetailTemp/LeadDetailTempPageInit", localVar)
        if (!KMainFunctions.IsResStatus2XX(result)) return true;

		stateVars.TM_UserRoleByUserId = result?.data.tM_UserRoleByUserId;
		stateVars.TM_ShowButton = result?.data.tM_ShowButton;
		formVars.leaddetailtemp_828004_label = ReactSystemFunctions.toString(this, (stateVars.TM_ShowButton !== undefined ? (stateVars.TM_ShowButton?.length > 0 ? stateVars.TM_ShowButton[0].reserveName : null) : (this.state.TM_ShowButton?.length > 0 ? this.state.TM_ShowButton[0].reserveName : null)));
		stateVars.isComp36328Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, (stateVars.TM_ShowButton !== undefined ? (stateVars.TM_ShowButton?.length > 0 ? stateVars.TM_ShowButton[0].hideActionPanel : null) : (this.state.TM_ShowButton?.length > 0 ? this.state.TM_ShowButton[0].hideActionPanel : null))), ReactSystemFunctions.convertToTypeByName("False", "string"))) === true ? "visible" : "hidden")
		stateVars.isComp748568Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, (stateVars.TM_ShowButton !== undefined ? (stateVars.TM_ShowButton?.length > 0 ? stateVars.TM_ShowButton[0].terminOnayShow : null) : (this.state.TM_ShowButton?.length > 0 ? this.state.TM_ShowButton[0].terminOnayShow : null))), ReactSystemFunctions.convertToTypeByName("True", "string"))) === true ? "visible" : "hidden")
		stateVars.isComp216308Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, (stateVars.TM_ShowButton !== undefined ? (stateVars.TM_ShowButton?.length > 0 ? stateVars.TM_ShowButton[0].terminVerOnayaGonderShow : null) : (this.state.TM_ShowButton?.length > 0 ? this.state.TM_ShowButton[0].terminVerOnayaGonderShow : null))), ReactSystemFunctions.convertToTypeByName("True", "string"))) === true ? "visible" : "hidden")
		stateVars.isComp659656Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, (stateVars.TM_ShowButton !== undefined ? (stateVars.TM_ShowButton?.length > 0 ? stateVars.TM_ShowButton[0].deliverAndSaleShow : null) : (this.state.TM_ShowButton?.length > 0 ? this.state.TM_ShowButton[0].deliverAndSaleShow : null))), ReactSystemFunctions.convertToTypeByName("True", "string"))) === true ? "visible" : "hidden")
		stateVars.isComp835987Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, (stateVars.TM_ShowButton !== undefined ? (stateVars.TM_ShowButton?.length > 0 ? stateVars.TM_ShowButton[0].reserveEditCancelShow : null) : (this.state.TM_ShowButton?.length > 0 ? this.state.TM_ShowButton[0].reserveEditCancelShow : null))), ReactSystemFunctions.convertToTypeByName("True", "string"))) === true ? "visible" : "hidden")
		stateVars.isComp483112Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, (stateVars.TM_ShowButton !== undefined ? (stateVars.TM_ShowButton?.length > 0 ? stateVars.TM_ShowButton[0].approveReservationShow : null) : (this.state.TM_ShowButton?.length > 0 ? this.state.TM_ShowButton[0].approveReservationShow : null))), ReactSystemFunctions.convertToTypeByName("True", "string"))) === true ? "visible" : "hidden")
		stateVars.isComp828004Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, (stateVars.TM_ShowButton !== undefined ? (stateVars.TM_ShowButton?.length > 0 ? stateVars.TM_ShowButton[0].reserveProductShow : null) : (this.state.TM_ShowButton?.length > 0 ? this.state.TM_ShowButton[0].reserveProductShow : null))), ReactSystemFunctions.convertToTypeByName("True", "string"))) === true ? "visible" : "hidden")
		stateVars.isComp44587Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, (stateVars.TM_ShowButton !== undefined ? (stateVars.TM_ShowButton?.length > 0 ? stateVars.TM_ShowButton[0].customerDeclinedShow : null) : (this.state.TM_ShowButton?.length > 0 ? this.state.TM_ShowButton[0].customerDeclinedShow : null))), ReactSystemFunctions.convertToTypeByName("True", "string"))) === true ? "visible" : "hidden")
		stateVars.isComp7937Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, (stateVars.TM_ShowButton !== undefined ? (stateVars.TM_ShowButton?.length > 0 ? stateVars.TM_ShowButton[0].rejectShow : null) : (this.state.TM_ShowButton?.length > 0 ? this.state.TM_ShowButton[0].rejectShow : null))), ReactSystemFunctions.convertToTypeByName("True", "string"))) === true ? "visible" : "hidden")
		stateVars.isComp170642Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, (stateVars.TM_ShowButton !== undefined ? (stateVars.TM_ShowButton?.length > 0 ? stateVars.TM_ShowButton[0].leadEditShow : null) : (this.state.TM_ShowButton?.length > 0 ? this.state.TM_ShowButton[0].leadEditShow : null))), ReactSystemFunctions.convertToTypeByName("True", "string"))) === true ? "visible" : "hidden")
		stateVars.TMApproveLeadAndReservation = result?.data.tmApproveLeadAndReservation;
		stateVars.isComp170155Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, (stateVars.TMApproveLeadAndReservation !== undefined ? (stateVars.TMApproveLeadAndReservation?.length > 0 ? stateVars.TMApproveLeadAndReservation[0].approveAndReserveShow : null) : (this.state.TMApproveLeadAndReservation?.length > 0 ? this.state.TMApproveLeadAndReservation[0].approveAndReserveShow : null))), ReactSystemFunctions.convertToTypeByName("True", "string"))) === true ? "visible" : "hidden")
		stateVars.TM_GetLeadStatus = result?.data.tM_GetLeadStatus;
		stateVars.TM_CheckLeadApprovalPermission = result?.data.tM_CheckLeadApprovalPermission;
		stateVars.TM_GetLeadById = result?.data.tM_GetLeadById;
		formVars.leaddetailtemp_500764_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadById !== undefined ? (stateVars.TM_GetLeadById?.length > 0 ? stateVars.TM_GetLeadById[0].leadCode : null) : (this.state.TM_GetLeadById?.length > 0 ? this.state.TM_GetLeadById[0].leadCode : null)));
		formVars.leaddetailtemp_855497_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadById !== undefined ? (stateVars.TM_GetLeadById?.length > 0 ? stateVars.TM_GetLeadById[0].musteriAdi : null) : (this.state.TM_GetLeadById?.length > 0 ? this.state.TM_GetLeadById[0].musteriAdi : null)));
		formVars.leaddetailtemp_863568_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadById !== undefined ? (stateVars.TM_GetLeadById?.length > 0 ? stateVars.TM_GetLeadById[0].telefonNo : null) : (this.state.TM_GetLeadById?.length > 0 ? this.state.TM_GetLeadById[0].telefonNo : null)));
		formVars.leaddetailtemp_442814_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadById !== undefined ? (stateVars.TM_GetLeadById?.length > 0 ? stateVars.TM_GetLeadById[0].musteriMail : null) : (this.state.TM_GetLeadById?.length > 0 ? this.state.TM_GetLeadById[0].musteriMail : null)));
		formVars.leaddetailtemp_342092_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadById !== undefined ? (stateVars.TM_GetLeadById?.length > 0 ? stateVars.TM_GetLeadById[0].lokasyon : null) : (this.state.TM_GetLeadById?.length > 0 ? this.state.TM_GetLeadById[0].lokasyon : null)));
		formVars.leaddetailtemp_693152_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadById !== undefined ? (stateVars.TM_GetLeadById?.length > 0 ? stateVars.TM_GetLeadById[0].musteriInfo : null) : (this.state.TM_GetLeadById?.length > 0 ? this.state.TM_GetLeadById[0].musteriInfo : null)));
		formVars.leaddetailtemp_911481_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadById !== undefined ? (stateVars.TM_GetLeadById?.length > 0 ? stateVars.TM_GetLeadById[0].referansAdi : null) : (this.state.TM_GetLeadById?.length > 0 ? this.state.TM_GetLeadById[0].referansAdi : null)));
		formVars.leaddetailtemp_343042_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadById !== undefined ? (stateVars.TM_GetLeadById?.length > 0 ? stateVars.TM_GetLeadById[0].referansTelefonNo : null) : (this.state.TM_GetLeadById?.length > 0 ? this.state.TM_GetLeadById[0].referansTelefonNo : null)));
		formVars.leaddetailtemp_874015_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadById !== undefined ? (stateVars.TM_GetLeadById?.length > 0 ? stateVars.TM_GetLeadById[0].processName : null) : (this.state.TM_GetLeadById?.length > 0 ? this.state.TM_GetLeadById[0].processName : null)));
		formVars.leaddetailtemp_190939_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadById !== undefined ? (stateVars.TM_GetLeadById?.length > 0 ? stateVars.TM_GetLeadById[0].processName : null) : (this.state.TM_GetLeadById?.length > 0 ? this.state.TM_GetLeadById[0].processName : null)));
		formVars.leaddetailtemp_161533_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadById !== undefined ? (stateVars.TM_GetLeadById?.length > 0 ? stateVars.TM_GetLeadById[0].processName : null) : (this.state.TM_GetLeadById?.length > 0 ? this.state.TM_GetLeadById[0].processName : null)));
		formVars.leaddetailtemp_459206_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadById !== undefined ? (stateVars.TM_GetLeadById?.length > 0 ? stateVars.TM_GetLeadById[0].processName : null) : (this.state.TM_GetLeadById?.length > 0 ? this.state.TM_GetLeadById[0].processName : null)));
		formVars.leaddetailtemp_901181_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadById !== undefined ? (stateVars.TM_GetLeadById?.length > 0 ? stateVars.TM_GetLeadById[0].processName : null) : (this.state.TM_GetLeadById?.length > 0 ? this.state.TM_GetLeadById[0].processName : null)));
		formVars.leaddetailtemp_127684_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadById !== undefined ? (stateVars.TM_GetLeadById?.length > 0 ? stateVars.TM_GetLeadById[0].terminTarihi : null) : (this.state.TM_GetLeadById?.length > 0 ? this.state.TM_GetLeadById[0].terminTarihi : null)));
		formVars.leaddetailtemp_853190_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadById !== undefined ? (stateVars.TM_GetLeadById?.length > 0 ? stateVars.TM_GetLeadById[0].redNotu : null) : (this.state.TM_GetLeadById?.length > 0 ? this.state.TM_GetLeadById[0].redNotu : null)));
		formVars.leaddetailtemp_65962_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadById !== undefined ? (stateVars.TM_GetLeadById?.length > 0 ? stateVars.TM_GetLeadById[0].talepOlusturmaTarihi : null) : (this.state.TM_GetLeadById?.length > 0 ? this.state.TM_GetLeadById[0].talepOlusturmaTarihi : null)));
		formVars.leaddetailtemp_468322_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadById !== undefined ? (stateVars.TM_GetLeadById?.length > 0 ? stateVars.TM_GetLeadById[0].sonStatuDegisikligi : null) : (this.state.TM_GetLeadById?.length > 0 ? this.state.TM_GetLeadById[0].sonStatuDegisikligi : null)));
		formVars.leaddetailtemp_430984_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadById !== undefined ? (stateVars.TM_GetLeadById?.length > 0 ? stateVars.TM_GetLeadById[0].takipDurumu : null) : (this.state.TM_GetLeadById?.length > 0 ? this.state.TM_GetLeadById[0].takipDurumu : null)));
		formVars.leaddetailtemp_795139_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadById !== undefined ? (stateVars.TM_GetLeadById?.length > 0 ? stateVars.TM_GetLeadById[0].takipDurumu : null) : (this.state.TM_GetLeadById?.length > 0 ? this.state.TM_GetLeadById[0].takipDurumu : null)));
		formVars.leaddetailtemp_380670_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadById !== undefined ? (stateVars.TM_GetLeadById?.length > 0 ? stateVars.TM_GetLeadById[0].sonrakiAdim : null) : (this.state.TM_GetLeadById?.length > 0 ? this.state.TM_GetLeadById[0].sonrakiAdim : null)));
		formVars.leaddetailtemp_294758_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadById !== undefined ? (stateVars.TM_GetLeadById?.length > 0 ? stateVars.TM_GetLeadById[0].iletisimKaynagi : null) : (this.state.TM_GetLeadById?.length > 0 ? this.state.TM_GetLeadById[0].iletisimKaynagi : null)));
		formVars.leaddetailtemp_283397_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadById !== undefined ? (stateVars.TM_GetLeadById?.length > 0 ? stateVars.TM_GetLeadById[0].urunAdi : null) : (this.state.TM_GetLeadById?.length > 0 ? this.state.TM_GetLeadById[0].urunAdi : null)));
		formVars.leaddetailtemp_51409_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadById !== undefined ? (stateVars.TM_GetLeadById?.length > 0 ? stateVars.TM_GetLeadById[0].brand : null) : (this.state.TM_GetLeadById?.length > 0 ? this.state.TM_GetLeadById[0].brand : null)));
		formVars.leaddetailtemp_44085_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadById !== undefined ? (stateVars.TM_GetLeadById?.length > 0 ? stateVars.TM_GetLeadById[0].referans : null) : (this.state.TM_GetLeadById?.length > 0 ? this.state.TM_GetLeadById[0].referans : null)));
		formVars.leaddetailtemp_654046_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadById !== undefined ? (stateVars.TM_GetLeadById?.length > 0 ? stateVars.TM_GetLeadById[0].kadran : null) : (this.state.TM_GetLeadById?.length > 0 ? this.state.TM_GetLeadById[0].kadran : null)));
		formVars.leaddetailtemp_475763_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadById !== undefined ? (stateVars.TM_GetLeadById?.length > 0 ? stateVars.TM_GetLeadById[0].bilezik : null) : (this.state.TM_GetLeadById?.length > 0 ? this.state.TM_GetLeadById[0].bilezik : null)));
		formVars.leaddetailtemp_645253_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadById !== undefined ? (stateVars.TM_GetLeadById?.length > 0 ? stateVars.TM_GetLeadById[0].categoryName : null) : (this.state.TM_GetLeadById?.length > 0 ? this.state.TM_GetLeadById[0].categoryName : null)));
		formVars.leaddetailtemp_115165_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadById !== undefined ? (stateVars.TM_GetLeadById?.length > 0 ? stateVars.TM_GetLeadById[0].categoryName : null) : (this.state.TM_GetLeadById?.length > 0 ? this.state.TM_GetLeadById[0].categoryName : null)));
		formVars.leaddetailtemp_768832_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadById !== undefined ? (stateVars.TM_GetLeadById?.length > 0 ? stateVars.TM_GetLeadById[0].categoryName : null) : (this.state.TM_GetLeadById?.length > 0 ? this.state.TM_GetLeadById[0].categoryName : null)));
		formVars.leaddetailtemp_599506_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadById !== undefined ? (stateVars.TM_GetLeadById?.length > 0 ? stateVars.TM_GetLeadById[0].categoryName : null) : (this.state.TM_GetLeadById?.length > 0 ? this.state.TM_GetLeadById[0].categoryName : null)));
		formVars.leaddetailtemp_990492_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadById !== undefined ? (stateVars.TM_GetLeadById?.length > 0 ? stateVars.TM_GetLeadById[0].satisPersoneli : null) : (this.state.TM_GetLeadById?.length > 0 ? this.state.TM_GetLeadById[0].satisPersoneli : null)));
		formVars.leaddetailtemp_723250_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadById !== undefined ? (stateVars.TM_GetLeadById?.length > 0 ? stateVars.TM_GetLeadById[0].magaza : null) : (this.state.TM_GetLeadById?.length > 0 ? this.state.TM_GetLeadById[0].magaza : null)));
		formVars.leaddetailtemp_92030_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadById !== undefined ? (stateVars.TM_GetLeadById?.length > 0 ? stateVars.TM_GetLeadById[0].talepNotu : null) : (this.state.TM_GetLeadById?.length > 0 ? this.state.TM_GetLeadById[0].talepNotu : null)));
		stateVars.isComp201879Visible = ((ReactSystemFunctions.isNotEqualTo(ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadById !== undefined ? (stateVars.TM_GetLeadById?.length > 0 ? stateVars.TM_GetLeadById[0].processCode : null) : (this.state.TM_GetLeadById?.length > 0 ? this.state.TM_GetLeadById[0].processCode : null))), ReactSystemFunctions.convertToTypeByName("DELIVERED", "string"))) === true ? "visible" : "hidden")
		stateVars.isComp845662Visible = ((ReactSystemFunctions.isNotEmpty(ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadById !== undefined ? (stateVars.TM_GetLeadById?.length > 0 ? stateVars.TM_GetLeadById[0].referansAdi : null) : (this.state.TM_GetLeadById?.length > 0 ? this.state.TM_GetLeadById[0].referansAdi : null))), ReactSystemFunctions.convertToTypeByName("True", "string"))) === true ? "visible" : "hidden")
		stateVars.isComp874015Visible = (((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadById !== undefined ? (stateVars.TM_GetLeadById?.length > 0 ? stateVars.TM_GetLeadById[0].processCode : null) : (this.state.TM_GetLeadById?.length > 0 ? this.state.TM_GetLeadById[0].processCode : null))), ReactSystemFunctions.convertToTypeByName("PENDING", "string")) || ReactSystemFunctions.isEqualTo(ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadById !== undefined ? (stateVars.TM_GetLeadById?.length > 0 ? stateVars.TM_GetLeadById[0].processCode : null) : (this.state.TM_GetLeadById?.length > 0 ? this.state.TM_GetLeadById[0].processCode : null))), ReactSystemFunctions.convertToTypeByName("TERMIN_PENDING", "string")) || ReactSystemFunctions.isEqualTo(ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadById !== undefined ? (stateVars.TM_GetLeadById?.length > 0 ? stateVars.TM_GetLeadById[0].processCode : null) : (this.state.TM_GetLeadById?.length > 0 ? this.state.TM_GetLeadById[0].processCode : null))), ReactSystemFunctions.convertToTypeByName("DELIVERY_PENDING", "string")))) === true ? "visible" : "hidden")
		stateVars.isComp190939Visible = (((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadById !== undefined ? (stateVars.TM_GetLeadById?.length > 0 ? stateVars.TM_GetLeadById[0].processCode : null) : (this.state.TM_GetLeadById?.length > 0 ? this.state.TM_GetLeadById[0].processCode : null))), ReactSystemFunctions.convertToTypeByName("CUSTOMER_DECLINED", "string")) || ReactSystemFunctions.isEqualTo(ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadById !== undefined ? (stateVars.TM_GetLeadById?.length > 0 ? stateVars.TM_GetLeadById[0].processCode : null) : (this.state.TM_GetLeadById?.length > 0 ? this.state.TM_GetLeadById[0].processCode : null))), ReactSystemFunctions.convertToTypeByName("REJECTED", "string")))) === true ? "visible" : "hidden")
		stateVars.isComp161533Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadById !== undefined ? (stateVars.TM_GetLeadById?.length > 0 ? stateVars.TM_GetLeadById[0].processCode : null) : (this.state.TM_GetLeadById?.length > 0 ? this.state.TM_GetLeadById[0].processCode : null))), ReactSystemFunctions.convertToTypeByName("DELIVERED", "string"))) === true ? "visible" : "hidden")
		stateVars.isComp459206Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadById !== undefined ? (stateVars.TM_GetLeadById?.length > 0 ? stateVars.TM_GetLeadById[0].processCode : null) : (this.state.TM_GetLeadById?.length > 0 ? this.state.TM_GetLeadById[0].processCode : null))), ReactSystemFunctions.convertToTypeByName("CLOSED", "string"))) === true ? "visible" : "hidden")
		stateVars.isComp901181Visible = (((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadById !== undefined ? (stateVars.TM_GetLeadById?.length > 0 ? stateVars.TM_GetLeadById[0].processCode : null) : (this.state.TM_GetLeadById?.length > 0 ? this.state.TM_GetLeadById[0].processCode : null))), ReactSystemFunctions.convertToTypeByName("APPROVED", "string")) || ReactSystemFunctions.isEqualTo(ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadById !== undefined ? (stateVars.TM_GetLeadById?.length > 0 ? stateVars.TM_GetLeadById[0].processCode : null) : (this.state.TM_GetLeadById?.length > 0 ? this.state.TM_GetLeadById[0].processCode : null))), ReactSystemFunctions.convertToTypeByName("CREATED", "string")))) === true ? "visible" : "hidden")
		stateVars.isComp430984Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadById !== undefined ? (stateVars.TM_GetLeadById?.length > 0 ? stateVars.TM_GetLeadById[0].takipDurumu : null) : (this.state.TM_GetLeadById?.length > 0 ? this.state.TM_GetLeadById[0].takipDurumu : null))), ReactSystemFunctions.convertToTypeByName("Takip ediliyor", "string"))) === true ? "visible" : "hidden")
		stateVars.isComp795139Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadById !== undefined ? (stateVars.TM_GetLeadById?.length > 0 ? stateVars.TM_GetLeadById[0].takipDurumu : null) : (this.state.TM_GetLeadById?.length > 0 ? this.state.TM_GetLeadById[0].takipDurumu : null))), ReactSystemFunctions.convertToTypeByName("2. Takip", "string"))) === true ? "visible" : "hidden")
		stateVars.isComp645253Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadById !== undefined ? (stateVars.TM_GetLeadById?.length > 0 ? stateVars.TM_GetLeadById[0].categoryName : null) : (this.state.TM_GetLeadById?.length > 0 ? this.state.TM_GetLeadById[0].categoryName : null))), ReactSystemFunctions.convertToTypeByName("Kategori 2", "string"))) === true ? "visible" : "hidden")
		stateVars.isComp115165Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadById !== undefined ? (stateVars.TM_GetLeadById?.length > 0 ? stateVars.TM_GetLeadById[0].categoryName : null) : (this.state.TM_GetLeadById?.length > 0 ? this.state.TM_GetLeadById[0].categoryName : null))), ReactSystemFunctions.convertToTypeByName("Kategori 1", "string"))) === true ? "visible" : "hidden")
		stateVars.isComp768832Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadById !== undefined ? (stateVars.TM_GetLeadById?.length > 0 ? stateVars.TM_GetLeadById[0].categoryName : null) : (this.state.TM_GetLeadById?.length > 0 ? this.state.TM_GetLeadById[0].categoryName : null))), ReactSystemFunctions.convertToTypeByName("DEFAULT", "string"))) === true ? "visible" : "hidden")
		stateVars.isComp599506Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadById !== undefined ? (stateVars.TM_GetLeadById?.length > 0 ? stateVars.TM_GetLeadById[0].categoryName : null) : (this.state.TM_GetLeadById?.length > 0 ? this.state.TM_GetLeadById[0].categoryName : null))), ReactSystemFunctions.convertToTypeByName("Kategori 3", "string"))) === true ? "visible" : "hidden")
		stateVars.isComp999529Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadById !== undefined ? (stateVars.TM_GetLeadById?.length > 0 ? stateVars.TM_GetLeadById[0].rezervDurumu : null) : (this.state.TM_GetLeadById?.length > 0 ? this.state.TM_GetLeadById[0].rezervDurumu : null))), ReactSystemFunctions.convertToTypeByName("Evet", "string"))) === true ? "visible" : "hidden")
		stateVars.isComp325540Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadById !== undefined ? (stateVars.TM_GetLeadById?.length > 0 ? stateVars.TM_GetLeadById[0].rezervDurumu : null) : (this.state.TM_GetLeadById?.length > 0 ? this.state.TM_GetLeadById[0].rezervDurumu : null))), ReactSystemFunctions.convertToTypeByName("Hayır", "string"))) === true ? "visible" : "hidden")
		stateVars.isComp361732Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadById !== undefined ? (stateVars.TM_GetLeadById?.length > 0 ? stateVars.TM_GetLeadById[0].rezervDurumu : null) : (this.state.TM_GetLeadById?.length > 0 ? this.state.TM_GetLeadById[0].rezervDurumu : null))), ReactSystemFunctions.convertToTypeByName("Onay Bekliyor", "string"))) === true ? "visible" : "hidden")
		stateVars.TM_GetReserveEditShow = result?.data.tM_GetReserveEditShow;
		stateVars.GetLeadNotes = result?.data.getLeadNotes;
		
		stateVars.TM_GetLeadNoteFileCounts = result?.data.tM_GetLeadNoteFileCounts;
		stateVars.TM_GetLeadLogById = result?.data.tM_GetLeadLogById;
		
		stateVars.TM_GetLeadAlternativeModel = result?.data.tM_GetLeadAlternativeModel;
		
		stateVars.isComp557236Visible = ((ReactSystemFunctions.isNotEmpty(ReactSystemFunctions.value(this, (stateVars.TM_GetLeadAlternativeModel !== undefined ? (stateVars.TM_GetLeadAlternativeModel?.length > 0 ? stateVars.TM_GetLeadAlternativeModel[0].alternativeModelId : null) : (this.state.TM_GetLeadAlternativeModel?.length > 0 ? this.state.TM_GetLeadAlternativeModel[0].alternativeModelId : null))), ReactSystemFunctions.convertToTypeByName("True", "string"))) === true ? "visible" : "hidden")
		stateVars.isComp332184Visible = ((ReactSystemFunctions.isEmpty(ReactSystemFunctions.value(this, (stateVars.TM_GetLeadAlternativeModel !== undefined ? (stateVars.TM_GetLeadAlternativeModel?.length > 0 ? stateVars.TM_GetLeadAlternativeModel[0].alternativeModelId : null) : (this.state.TM_GetLeadAlternativeModel?.length > 0 ? this.state.TM_GetLeadAlternativeModel[0].alternativeModelId : null))), ReactSystemFunctions.convertToTypeByName("True", "string"))) === true ? "visible" : "hidden")
		stateVars.TM_GetLeadLogStatu = result?.data.tM_GetLeadLogStatu;
		this.props.form?.setFieldsValue(formVars);
		
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.LeadDetailTempPageInit1_();
                  resolve();
                });
          })



        
        KuikaAppManager.hideSpinner(this);
        return isErrorOccurred;
    }
	LeadDetailTempPageInit1_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


	if (KuikaAppManager.handleValidations(this, validations, this.checkTabErrors))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }

			formVars.leaddetailtemp_500764_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadById !== undefined ? (stateVars.TM_GetLeadById?.length > 0 ? stateVars.TM_GetLeadById[0].leadCode : null) : (this.state.TM_GetLeadById?.length > 0 ? this.state.TM_GetLeadById[0].leadCode : null)));

			stateVars.isComp36328Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, (stateVars.TM_ShowButton !== undefined ? (stateVars.TM_ShowButton?.length > 0 ? stateVars.TM_ShowButton[0].hideActionPanel : null) : (this.state.TM_ShowButton?.length > 0 ? this.state.TM_ShowButton[0].hideActionPanel : null))), ReactSystemFunctions.convertToTypeByName("False", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp748568Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, (stateVars.TM_ShowButton !== undefined ? (stateVars.TM_ShowButton?.length > 0 ? stateVars.TM_ShowButton[0].terminOnayShow : null) : (this.state.TM_ShowButton?.length > 0 ? this.state.TM_ShowButton[0].terminOnayShow : null))), ReactSystemFunctions.convertToTypeByName("True", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp170155Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, (stateVars.TMApproveLeadAndReservation !== undefined ? (stateVars.TMApproveLeadAndReservation?.length > 0 ? stateVars.TMApproveLeadAndReservation[0].approveAndReserveShow : null) : (this.state.TMApproveLeadAndReservation?.length > 0 ? this.state.TMApproveLeadAndReservation[0].approveAndReserveShow : null))), ReactSystemFunctions.convertToTypeByName("True", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp216308Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, (stateVars.TM_ShowButton !== undefined ? (stateVars.TM_ShowButton?.length > 0 ? stateVars.TM_ShowButton[0].terminVerOnayaGonderShow : null) : (this.state.TM_ShowButton?.length > 0 ? this.state.TM_ShowButton[0].terminVerOnayaGonderShow : null))), ReactSystemFunctions.convertToTypeByName("True", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp659656Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, (stateVars.TM_ShowButton !== undefined ? (stateVars.TM_ShowButton?.length > 0 ? stateVars.TM_ShowButton[0].deliverAndSaleShow : null) : (this.state.TM_ShowButton?.length > 0 ? this.state.TM_ShowButton[0].deliverAndSaleShow : null))), ReactSystemFunctions.convertToTypeByName("True", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp835987Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, (stateVars.TM_ShowButton !== undefined ? (stateVars.TM_ShowButton?.length > 0 ? stateVars.TM_ShowButton[0].reserveEditCancelShow : null) : (this.state.TM_ShowButton?.length > 0 ? this.state.TM_ShowButton[0].reserveEditCancelShow : null))), ReactSystemFunctions.convertToTypeByName("True", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp483112Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, (stateVars.TM_ShowButton !== undefined ? (stateVars.TM_ShowButton?.length > 0 ? stateVars.TM_ShowButton[0].approveReservationShow : null) : (this.state.TM_ShowButton?.length > 0 ? this.state.TM_ShowButton[0].approveReservationShow : null))), ReactSystemFunctions.convertToTypeByName("True", "string"))) === true ? "visible" : "hidden")
			formVars.leaddetailtemp_828004_label = ReactSystemFunctions.toString(this, (stateVars.TM_ShowButton !== undefined ? (stateVars.TM_ShowButton?.length > 0 ? stateVars.TM_ShowButton[0].reserveName : null) : (this.state.TM_ShowButton?.length > 0 ? this.state.TM_ShowButton[0].reserveName : null)));

			stateVars.isComp828004Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, (stateVars.TM_ShowButton !== undefined ? (stateVars.TM_ShowButton?.length > 0 ? stateVars.TM_ShowButton[0].reserveProductShow : null) : (this.state.TM_ShowButton?.length > 0 ? this.state.TM_ShowButton[0].reserveProductShow : null))), ReactSystemFunctions.convertToTypeByName("True", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp44587Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, (stateVars.TM_ShowButton !== undefined ? (stateVars.TM_ShowButton?.length > 0 ? stateVars.TM_ShowButton[0].customerDeclinedShow : null) : (this.state.TM_ShowButton?.length > 0 ? this.state.TM_ShowButton[0].customerDeclinedShow : null))), ReactSystemFunctions.convertToTypeByName("True", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp7937Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, (stateVars.TM_ShowButton !== undefined ? (stateVars.TM_ShowButton?.length > 0 ? stateVars.TM_ShowButton[0].rejectShow : null) : (this.state.TM_ShowButton?.length > 0 ? this.state.TM_ShowButton[0].rejectShow : null))), ReactSystemFunctions.convertToTypeByName("True", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp170642Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, (stateVars.TM_ShowButton !== undefined ? (stateVars.TM_ShowButton?.length > 0 ? stateVars.TM_ShowButton[0].leadEditShow : null) : (this.state.TM_ShowButton?.length > 0 ? this.state.TM_ShowButton[0].leadEditShow : null))), ReactSystemFunctions.convertToTypeByName("True", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp201879Visible = ((ReactSystemFunctions.isNotEqualTo(ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadById !== undefined ? (stateVars.TM_GetLeadById?.length > 0 ? stateVars.TM_GetLeadById[0].processCode : null) : (this.state.TM_GetLeadById?.length > 0 ? this.state.TM_GetLeadById[0].processCode : null))), ReactSystemFunctions.convertToTypeByName("DELIVERED", "string"))) === true ? "visible" : "hidden")
			formVars.leaddetailtemp_855497_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadById !== undefined ? (stateVars.TM_GetLeadById?.length > 0 ? stateVars.TM_GetLeadById[0].musteriAdi : null) : (this.state.TM_GetLeadById?.length > 0 ? this.state.TM_GetLeadById[0].musteriAdi : null)));

			formVars.leaddetailtemp_863568_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadById !== undefined ? (stateVars.TM_GetLeadById?.length > 0 ? stateVars.TM_GetLeadById[0].telefonNo : null) : (this.state.TM_GetLeadById?.length > 0 ? this.state.TM_GetLeadById[0].telefonNo : null)));

			formVars.leaddetailtemp_442814_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadById !== undefined ? (stateVars.TM_GetLeadById?.length > 0 ? stateVars.TM_GetLeadById[0].musteriMail : null) : (this.state.TM_GetLeadById?.length > 0 ? this.state.TM_GetLeadById[0].musteriMail : null)));

			formVars.leaddetailtemp_342092_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadById !== undefined ? (stateVars.TM_GetLeadById?.length > 0 ? stateVars.TM_GetLeadById[0].lokasyon : null) : (this.state.TM_GetLeadById?.length > 0 ? this.state.TM_GetLeadById[0].lokasyon : null)));

			formVars.leaddetailtemp_693152_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadById !== undefined ? (stateVars.TM_GetLeadById?.length > 0 ? stateVars.TM_GetLeadById[0].musteriInfo : null) : (this.state.TM_GetLeadById?.length > 0 ? this.state.TM_GetLeadById[0].musteriInfo : null)));

			stateVars.isComp845662Visible = ((ReactSystemFunctions.isNotEmpty(ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadById !== undefined ? (stateVars.TM_GetLeadById?.length > 0 ? stateVars.TM_GetLeadById[0].referansAdi : null) : (this.state.TM_GetLeadById?.length > 0 ? this.state.TM_GetLeadById[0].referansAdi : null))), ReactSystemFunctions.convertToTypeByName("True", "string"))) === true ? "visible" : "hidden")
			formVars.leaddetailtemp_911481_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadById !== undefined ? (stateVars.TM_GetLeadById?.length > 0 ? stateVars.TM_GetLeadById[0].referansAdi : null) : (this.state.TM_GetLeadById?.length > 0 ? this.state.TM_GetLeadById[0].referansAdi : null)));

			formVars.leaddetailtemp_343042_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadById !== undefined ? (stateVars.TM_GetLeadById?.length > 0 ? stateVars.TM_GetLeadById[0].referansTelefonNo : null) : (this.state.TM_GetLeadById?.length > 0 ? this.state.TM_GetLeadById[0].referansTelefonNo : null)));

			formVars.leaddetailtemp_874015_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadById !== undefined ? (stateVars.TM_GetLeadById?.length > 0 ? stateVars.TM_GetLeadById[0].processName : null) : (this.state.TM_GetLeadById?.length > 0 ? this.state.TM_GetLeadById[0].processName : null)));

			stateVars.isComp874015Visible = (((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadById !== undefined ? (stateVars.TM_GetLeadById?.length > 0 ? stateVars.TM_GetLeadById[0].processCode : null) : (this.state.TM_GetLeadById?.length > 0 ? this.state.TM_GetLeadById[0].processCode : null))), ReactSystemFunctions.convertToTypeByName("PENDING", "string")) || ReactSystemFunctions.isEqualTo(ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadById !== undefined ? (stateVars.TM_GetLeadById?.length > 0 ? stateVars.TM_GetLeadById[0].processCode : null) : (this.state.TM_GetLeadById?.length > 0 ? this.state.TM_GetLeadById[0].processCode : null))), ReactSystemFunctions.convertToTypeByName("TERMIN_PENDING", "string")) || ReactSystemFunctions.isEqualTo(ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadById !== undefined ? (stateVars.TM_GetLeadById?.length > 0 ? stateVars.TM_GetLeadById[0].processCode : null) : (this.state.TM_GetLeadById?.length > 0 ? this.state.TM_GetLeadById[0].processCode : null))), ReactSystemFunctions.convertToTypeByName("DELIVERY_PENDING", "string")))) === true ? "visible" : "hidden")
			formVars.leaddetailtemp_190939_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadById !== undefined ? (stateVars.TM_GetLeadById?.length > 0 ? stateVars.TM_GetLeadById[0].processName : null) : (this.state.TM_GetLeadById?.length > 0 ? this.state.TM_GetLeadById[0].processName : null)));

			stateVars.isComp190939Visible = (((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadById !== undefined ? (stateVars.TM_GetLeadById?.length > 0 ? stateVars.TM_GetLeadById[0].processCode : null) : (this.state.TM_GetLeadById?.length > 0 ? this.state.TM_GetLeadById[0].processCode : null))), ReactSystemFunctions.convertToTypeByName("CUSTOMER_DECLINED", "string")) || ReactSystemFunctions.isEqualTo(ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadById !== undefined ? (stateVars.TM_GetLeadById?.length > 0 ? stateVars.TM_GetLeadById[0].processCode : null) : (this.state.TM_GetLeadById?.length > 0 ? this.state.TM_GetLeadById[0].processCode : null))), ReactSystemFunctions.convertToTypeByName("REJECTED", "string")))) === true ? "visible" : "hidden")
			formVars.leaddetailtemp_161533_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadById !== undefined ? (stateVars.TM_GetLeadById?.length > 0 ? stateVars.TM_GetLeadById[0].processName : null) : (this.state.TM_GetLeadById?.length > 0 ? this.state.TM_GetLeadById[0].processName : null)));

			stateVars.isComp161533Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadById !== undefined ? (stateVars.TM_GetLeadById?.length > 0 ? stateVars.TM_GetLeadById[0].processCode : null) : (this.state.TM_GetLeadById?.length > 0 ? this.state.TM_GetLeadById[0].processCode : null))), ReactSystemFunctions.convertToTypeByName("DELIVERED", "string"))) === true ? "visible" : "hidden")
			formVars.leaddetailtemp_459206_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadById !== undefined ? (stateVars.TM_GetLeadById?.length > 0 ? stateVars.TM_GetLeadById[0].processName : null) : (this.state.TM_GetLeadById?.length > 0 ? this.state.TM_GetLeadById[0].processName : null)));

			stateVars.isComp459206Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadById !== undefined ? (stateVars.TM_GetLeadById?.length > 0 ? stateVars.TM_GetLeadById[0].processCode : null) : (this.state.TM_GetLeadById?.length > 0 ? this.state.TM_GetLeadById[0].processCode : null))), ReactSystemFunctions.convertToTypeByName("CLOSED", "string"))) === true ? "visible" : "hidden")
			formVars.leaddetailtemp_901181_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadById !== undefined ? (stateVars.TM_GetLeadById?.length > 0 ? stateVars.TM_GetLeadById[0].processName : null) : (this.state.TM_GetLeadById?.length > 0 ? this.state.TM_GetLeadById[0].processName : null)));

			stateVars.isComp901181Visible = (((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadById !== undefined ? (stateVars.TM_GetLeadById?.length > 0 ? stateVars.TM_GetLeadById[0].processCode : null) : (this.state.TM_GetLeadById?.length > 0 ? this.state.TM_GetLeadById[0].processCode : null))), ReactSystemFunctions.convertToTypeByName("APPROVED", "string")) || ReactSystemFunctions.isEqualTo(ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadById !== undefined ? (stateVars.TM_GetLeadById?.length > 0 ? stateVars.TM_GetLeadById[0].processCode : null) : (this.state.TM_GetLeadById?.length > 0 ? this.state.TM_GetLeadById[0].processCode : null))), ReactSystemFunctions.convertToTypeByName("CREATED", "string")))) === true ? "visible" : "hidden")
			formVars.leaddetailtemp_127684_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadById !== undefined ? (stateVars.TM_GetLeadById?.length > 0 ? stateVars.TM_GetLeadById[0].terminTarihi : null) : (this.state.TM_GetLeadById?.length > 0 ? this.state.TM_GetLeadById[0].terminTarihi : null)));

			formVars.leaddetailtemp_853190_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadById !== undefined ? (stateVars.TM_GetLeadById?.length > 0 ? stateVars.TM_GetLeadById[0].redNotu : null) : (this.state.TM_GetLeadById?.length > 0 ? this.state.TM_GetLeadById[0].redNotu : null)));

			formVars.leaddetailtemp_65962_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadById !== undefined ? (stateVars.TM_GetLeadById?.length > 0 ? stateVars.TM_GetLeadById[0].talepOlusturmaTarihi : null) : (this.state.TM_GetLeadById?.length > 0 ? this.state.TM_GetLeadById[0].talepOlusturmaTarihi : null)));

			formVars.leaddetailtemp_468322_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadById !== undefined ? (stateVars.TM_GetLeadById?.length > 0 ? stateVars.TM_GetLeadById[0].sonStatuDegisikligi : null) : (this.state.TM_GetLeadById?.length > 0 ? this.state.TM_GetLeadById[0].sonStatuDegisikligi : null)));

			formVars.leaddetailtemp_430984_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadById !== undefined ? (stateVars.TM_GetLeadById?.length > 0 ? stateVars.TM_GetLeadById[0].takipDurumu : null) : (this.state.TM_GetLeadById?.length > 0 ? this.state.TM_GetLeadById[0].takipDurumu : null)));

			stateVars.isComp430984Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadById !== undefined ? (stateVars.TM_GetLeadById?.length > 0 ? stateVars.TM_GetLeadById[0].takipDurumu : null) : (this.state.TM_GetLeadById?.length > 0 ? this.state.TM_GetLeadById[0].takipDurumu : null))), ReactSystemFunctions.convertToTypeByName("Takip ediliyor", "string"))) === true ? "visible" : "hidden")
			formVars.leaddetailtemp_795139_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadById !== undefined ? (stateVars.TM_GetLeadById?.length > 0 ? stateVars.TM_GetLeadById[0].takipDurumu : null) : (this.state.TM_GetLeadById?.length > 0 ? this.state.TM_GetLeadById[0].takipDurumu : null)));

			stateVars.isComp795139Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadById !== undefined ? (stateVars.TM_GetLeadById?.length > 0 ? stateVars.TM_GetLeadById[0].takipDurumu : null) : (this.state.TM_GetLeadById?.length > 0 ? this.state.TM_GetLeadById[0].takipDurumu : null))), ReactSystemFunctions.convertToTypeByName("2. Takip", "string"))) === true ? "visible" : "hidden")
			formVars.leaddetailtemp_380670_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadById !== undefined ? (stateVars.TM_GetLeadById?.length > 0 ? stateVars.TM_GetLeadById[0].sonrakiAdim : null) : (this.state.TM_GetLeadById?.length > 0 ? this.state.TM_GetLeadById[0].sonrakiAdim : null)));

			formVars.leaddetailtemp_294758_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadById !== undefined ? (stateVars.TM_GetLeadById?.length > 0 ? stateVars.TM_GetLeadById[0].iletisimKaynagi : null) : (this.state.TM_GetLeadById?.length > 0 ? this.state.TM_GetLeadById[0].iletisimKaynagi : null)));

			formVars.leaddetailtemp_283397_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadById !== undefined ? (stateVars.TM_GetLeadById?.length > 0 ? stateVars.TM_GetLeadById[0].urunAdi : null) : (this.state.TM_GetLeadById?.length > 0 ? this.state.TM_GetLeadById[0].urunAdi : null)));

			formVars.leaddetailtemp_51409_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadById !== undefined ? (stateVars.TM_GetLeadById?.length > 0 ? stateVars.TM_GetLeadById[0].brand : null) : (this.state.TM_GetLeadById?.length > 0 ? this.state.TM_GetLeadById[0].brand : null)));

			formVars.leaddetailtemp_44085_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadById !== undefined ? (stateVars.TM_GetLeadById?.length > 0 ? stateVars.TM_GetLeadById[0].referans : null) : (this.state.TM_GetLeadById?.length > 0 ? this.state.TM_GetLeadById[0].referans : null)));

			formVars.leaddetailtemp_654046_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadById !== undefined ? (stateVars.TM_GetLeadById?.length > 0 ? stateVars.TM_GetLeadById[0].kadran : null) : (this.state.TM_GetLeadById?.length > 0 ? this.state.TM_GetLeadById[0].kadran : null)));

			formVars.leaddetailtemp_475763_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadById !== undefined ? (stateVars.TM_GetLeadById?.length > 0 ? stateVars.TM_GetLeadById[0].bilezik : null) : (this.state.TM_GetLeadById?.length > 0 ? this.state.TM_GetLeadById[0].bilezik : null)));

			formVars.leaddetailtemp_645253_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadById !== undefined ? (stateVars.TM_GetLeadById?.length > 0 ? stateVars.TM_GetLeadById[0].categoryName : null) : (this.state.TM_GetLeadById?.length > 0 ? this.state.TM_GetLeadById[0].categoryName : null)));

			stateVars.isComp645253Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadById !== undefined ? (stateVars.TM_GetLeadById?.length > 0 ? stateVars.TM_GetLeadById[0].categoryName : null) : (this.state.TM_GetLeadById?.length > 0 ? this.state.TM_GetLeadById[0].categoryName : null))), ReactSystemFunctions.convertToTypeByName("Kategori 2", "string"))) === true ? "visible" : "hidden")
			formVars.leaddetailtemp_115165_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadById !== undefined ? (stateVars.TM_GetLeadById?.length > 0 ? stateVars.TM_GetLeadById[0].categoryName : null) : (this.state.TM_GetLeadById?.length > 0 ? this.state.TM_GetLeadById[0].categoryName : null)));

			stateVars.isComp115165Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadById !== undefined ? (stateVars.TM_GetLeadById?.length > 0 ? stateVars.TM_GetLeadById[0].categoryName : null) : (this.state.TM_GetLeadById?.length > 0 ? this.state.TM_GetLeadById[0].categoryName : null))), ReactSystemFunctions.convertToTypeByName("Kategori 1", "string"))) === true ? "visible" : "hidden")
			formVars.leaddetailtemp_768832_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadById !== undefined ? (stateVars.TM_GetLeadById?.length > 0 ? stateVars.TM_GetLeadById[0].categoryName : null) : (this.state.TM_GetLeadById?.length > 0 ? this.state.TM_GetLeadById[0].categoryName : null)));

			stateVars.isComp768832Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadById !== undefined ? (stateVars.TM_GetLeadById?.length > 0 ? stateVars.TM_GetLeadById[0].categoryName : null) : (this.state.TM_GetLeadById?.length > 0 ? this.state.TM_GetLeadById[0].categoryName : null))), ReactSystemFunctions.convertToTypeByName("DEFAULT", "string"))) === true ? "visible" : "hidden")
			formVars.leaddetailtemp_599506_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadById !== undefined ? (stateVars.TM_GetLeadById?.length > 0 ? stateVars.TM_GetLeadById[0].categoryName : null) : (this.state.TM_GetLeadById?.length > 0 ? this.state.TM_GetLeadById[0].categoryName : null)));

			stateVars.isComp599506Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadById !== undefined ? (stateVars.TM_GetLeadById?.length > 0 ? stateVars.TM_GetLeadById[0].categoryName : null) : (this.state.TM_GetLeadById?.length > 0 ? this.state.TM_GetLeadById[0].categoryName : null))), ReactSystemFunctions.convertToTypeByName("Kategori 3", "string"))) === true ? "visible" : "hidden")
			formVars.leaddetailtemp_990492_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadById !== undefined ? (stateVars.TM_GetLeadById?.length > 0 ? stateVars.TM_GetLeadById[0].satisPersoneli : null) : (this.state.TM_GetLeadById?.length > 0 ? this.state.TM_GetLeadById[0].satisPersoneli : null)));

			formVars.leaddetailtemp_723250_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadById !== undefined ? (stateVars.TM_GetLeadById?.length > 0 ? stateVars.TM_GetLeadById[0].magaza : null) : (this.state.TM_GetLeadById?.length > 0 ? this.state.TM_GetLeadById[0].magaza : null)));

			stateVars.isComp999529Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadById !== undefined ? (stateVars.TM_GetLeadById?.length > 0 ? stateVars.TM_GetLeadById[0].rezervDurumu : null) : (this.state.TM_GetLeadById?.length > 0 ? this.state.TM_GetLeadById[0].rezervDurumu : null))), ReactSystemFunctions.convertToTypeByName("Evet", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp325540Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadById !== undefined ? (stateVars.TM_GetLeadById?.length > 0 ? stateVars.TM_GetLeadById[0].rezervDurumu : null) : (this.state.TM_GetLeadById?.length > 0 ? this.state.TM_GetLeadById[0].rezervDurumu : null))), ReactSystemFunctions.convertToTypeByName("Hayır", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp361732Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadById !== undefined ? (stateVars.TM_GetLeadById?.length > 0 ? stateVars.TM_GetLeadById[0].rezervDurumu : null) : (this.state.TM_GetLeadById?.length > 0 ? this.state.TM_GetLeadById[0].rezervDurumu : null))), ReactSystemFunctions.convertToTypeByName("Onay Bekliyor", "string"))) === true ? "visible" : "hidden")
			formVars.leaddetailtemp_92030_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadById !== undefined ? (stateVars.TM_GetLeadById?.length > 0 ? stateVars.TM_GetLeadById[0].talepNotu : null) : (this.state.TM_GetLeadById?.length > 0 ? this.state.TM_GetLeadById[0].talepNotu : null)));

			stateVars.isComp557236Visible = ((ReactSystemFunctions.isNotEmpty(ReactSystemFunctions.value(this, (stateVars.TM_GetLeadAlternativeModel !== undefined ? (stateVars.TM_GetLeadAlternativeModel?.length > 0 ? stateVars.TM_GetLeadAlternativeModel[0].alternativeModelId : null) : (this.state.TM_GetLeadAlternativeModel?.length > 0 ? this.state.TM_GetLeadAlternativeModel[0].alternativeModelId : null))), ReactSystemFunctions.convertToTypeByName("True", "string"))) === true ? "visible" : "hidden")
			
			stateVars.dataSource_135379 = stateVars.TM_GetLeadAlternativeModel ?? this.state.TM_GetLeadAlternativeModel;
			stateVars.isComp850874Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, "leaddetailtemp_135379_value", "categoryName"), ReactSystemFunctions.convertToTypeByName("Kategori 2", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp463829Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, "leaddetailtemp_135379_value", "categoryName"), ReactSystemFunctions.convertToTypeByName("Kategori 1", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp1999Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, "leaddetailtemp_135379_value", "categoryName"), ReactSystemFunctions.convertToTypeByName("DEFAULT", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp624559Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, "leaddetailtemp_135379_value", "categoryName"), ReactSystemFunctions.convertToTypeByName("Kategori 3", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp332184Visible = ((ReactSystemFunctions.isEmpty(ReactSystemFunctions.value(this, (stateVars.TM_GetLeadAlternativeModel !== undefined ? (stateVars.TM_GetLeadAlternativeModel?.length > 0 ? stateVars.TM_GetLeadAlternativeModel[0].alternativeModelId : null) : (this.state.TM_GetLeadAlternativeModel?.length > 0 ? this.state.TM_GetLeadAlternativeModel[0].alternativeModelId : null))), ReactSystemFunctions.convertToTypeByName("True", "string"))) === true ? "visible" : "hidden")
			
			stateVars.dataSource_811809 = stateVars.GetLeadNotes ?? this.state.GetLeadNotes;
			stateVars.isComp158975Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, "leaddetailtemp_811809_value", "hasFiles"), ReactSystemFunctions.convertToTypeByName("True", "string"))) === true ? "visible" : "hidden")
			
			
			
			stateVars.dataSource_424782 = stateVars.TM_GetLeadLogById ?? this.state.TM_GetLeadLogById;

	this.props.form?.setFieldsValue(formVars);
	this.setState(stateVars);
	KuikaAppManager.hideSpinner(this);

            this.setPageInitLoaded(true);
            return isErrorOccurred;
        }




		LeadDetailTempComponent_102385_onClick = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations, this.checkTabErrors))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
KuikaAppManager.showSpinner(this);

				stateVars.GoBack = await ReactSystemFunctions.goBack(this, false);

		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

            
            return isErrorOccurred;
        }


		LeadDetailTempComponent_748568_onClick = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations, this.checkTabErrors))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
KuikaAppManager.showSpinner(this);

					KuikaAppManager.prepareForNavigation();
						KuikaAppManager.addToPageInputVariables("PopOnayBekleyen", "LeadId", ReactSystemFunctions.convertToTypeByName(this.props.screenInputs.LeadId ?? this.props.screenInputs.leadid, "Guid"));

				stateVars.NAVIGATE = await ReactSystemFunctions.navigate(this, undefined, "LeadDetailTemp", "PopOnayBekleyen", "", "7d969ddf-5801-4eb6-b92b-12be35bdd565", "288028", null, "right", "true", "70vw", "100vh", true, false);

		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

            
            return isErrorOccurred;
        }


		LeadDetailTempComponent_170155_onClick = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations, this.checkTabErrors))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
KuikaAppManager.showSpinner(this);

					KuikaAppManager.prepareForNavigation();
						KuikaAppManager.addToPageInputVariables("reservationPopUp3", "LeadId", ReactSystemFunctions.convertToTypeByName(this.props.screenInputs.LeadId ?? this.props.screenInputs.leadid, "Guid"));

				stateVars.NAVIGATE = await ReactSystemFunctions.navigate(this, undefined, "LeadDetailTemp", "reservationPopUp3", "", "currentPage", null, null, null, null, null, null, true, false);

		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

            
            return isErrorOccurred;
        }


		LeadDetailTempComponent_216308_onClick = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations, this.checkTabErrors))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
KuikaAppManager.showSpinner(this);

					KuikaAppManager.prepareForNavigation();
						KuikaAppManager.addToPageInputVariables("PopTerminOnerisiBekleyen", "LeadId", ReactSystemFunctions.convertToTypeByName(this.props.screenInputs.LeadId ?? this.props.screenInputs.leadid, "Guid"));

				stateVars.NAVIGATE = await ReactSystemFunctions.navigate(this, undefined, "LeadDetailTemp", "PopTerminOnerisiBekleyen", "", "currentPage", null, null, null, null, null, null, true, false);

		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

            
            return isErrorOccurred;
        }


		LeadDetailTempComponent_659656_onClick = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations, this.checkTabErrors))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
KuikaAppManager.showSpinner(this);

					KuikaAppManager.prepareForNavigation();
						KuikaAppManager.addToPageInputVariables("TalepSatisIslemi", "LeadId", ReactSystemFunctions.convertToTypeByName(this.props.screenInputs.LeadId ?? this.props.screenInputs.leadid, "Guid"));
						KuikaAppManager.addToPageInputVariables("TalepSatisIslemi", "ApprovalId", ReactSystemFunctions.convertToTypeByName(null, "Guid"));
						KuikaAppManager.addToPageInputVariables("TalepSatisIslemi", "SalesLeadDraftId", ReactSystemFunctions.convertToTypeByName(null, "Guid"));

				stateVars.NAVIGATE = await ReactSystemFunctions.navigate(this, undefined, "LeadDetailTemp", "TalepSatisIslemi", "", "7d969ddf-5801-4eb6-b92b-12be35bdd565", "26874", null, "right", "true", "70vw", "100vh", true, false);

		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

            
            return isErrorOccurred;
        }


		LeadDetailTempComponent_835987_onClick = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations, this.checkTabErrors))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
KuikaAppManager.showSpinner(this);

					KuikaAppManager.prepareForNavigation();
						KuikaAppManager.addToPageInputVariables("ReservationEdit", "LeadId", ReactSystemFunctions.convertToTypeByName(this.props.screenInputs.LeadId ?? this.props.screenInputs.leadid, "Guid"));

				stateVars.NAVIGATE = await ReactSystemFunctions.navigate(this, undefined, "LeadDetailTemp", "ReservationEdit", "", "7d969ddf-5801-4eb6-b92b-12be35bdd565", "635261", null, "right", "true", "70vw", "100vh", true, false);

		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

            
            return isErrorOccurred;
        }


		LeadDetailTempComponent_483112_onClick = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations, this.checkTabErrors))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
KuikaAppManager.showSpinner(this);

					KuikaAppManager.prepareForNavigation();
						KuikaAppManager.addToPageInputVariables("PopRezervOnayBekleyenPopup", "LeadId", ReactSystemFunctions.convertToTypeByName(this.props.screenInputs.LeadId ?? this.props.screenInputs.leadid, "Guid"));

				stateVars.NAVIGATE = await ReactSystemFunctions.navigate(this, undefined, "LeadDetailTemp", "PopRezervOnayBekleyenPopup", "", "currentPage", null, null, null, null, null, null, true, false);

		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

            
            return isErrorOccurred;
        }


		LeadDetailTempComponent_828004_onClick = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations, this.checkTabErrors))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
if (ReactSystemFunctions.isEqualTo(ReactSystemFunctions.toString(this, (stateVars.TM_ShowButton !== undefined ? (stateVars.TM_ShowButton?.length > 0 ? stateVars.TM_ShowButton[0].reserveName : null) : (this.state.TM_ShowButton?.length > 0 ? this.state.TM_ShowButton[0].reserveName : null))), "Rezerve Talebi Oluştur")) {
            KuikaAppManager.showSpinner(this);

					KuikaAppManager.prepareForNavigation();
						KuikaAppManager.addToPageInputVariables("reservationPopup1", "LeadId", ReactSystemFunctions.convertToTypeByName(this.props.screenInputs.LeadId ?? this.props.screenInputs.leadid, "Guid"));

				stateVars.NAVIGATE = await ReactSystemFunctions.navigate(this, this.LeadDetailTempComponent_828004_onClick1_, "LeadDetailTemp", "reservationPopup1", "", "currentPage", null, null, null, null, null, null, true, false);

		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

        } else {
            
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.LeadDetailTempComponent_828004_onClick1_();
                  resolve();
                });
          })
        }

            
            return isErrorOccurred;
        }
		LeadDetailTempComponent_828004_onClick1_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations, this.checkTabErrors))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
if (ReactSystemFunctions.isEqualTo(ReactSystemFunctions.toString(this, (stateVars.TM_ShowButton !== undefined ? (stateVars.TM_ShowButton?.length > 0 ? stateVars.TM_ShowButton[0].reserveName : null) : (this.state.TM_ShowButton?.length > 0 ? this.state.TM_ShowButton[0].reserveName : null))), "Rezerve Oluştur")) {
            KuikaAppManager.showSpinner(this);

					KuikaAppManager.prepareForNavigation();
						KuikaAppManager.addToPageInputVariables("reservationPopUp2", "LeadId", ReactSystemFunctions.convertToTypeByName(this.props.screenInputs.LeadId ?? this.props.screenInputs.leadid, "Guid"));

				stateVars.NAVIGATE = await ReactSystemFunctions.navigate(this, undefined, "LeadDetailTemp", "reservationPopUp2", "", "currentPage", null, null, null, null, null, null, true, false);

		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

        } else {
            KuikaAppManager.hideSpinner(this);
        }

            
            return isErrorOccurred;
        }



		LeadDetailTempComponent_44587_onClick = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations, this.checkTabErrors))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
KuikaAppManager.showSpinner(this);

					KuikaAppManager.prepareForNavigation();
						KuikaAppManager.addToPageInputVariables("LeadRejectCustomerPopUp", "LeadId", ReactSystemFunctions.convertToTypeByName(this.props.screenInputs.LeadId ?? this.props.screenInputs.leadid, "Guid"));

				stateVars.NAVIGATE = await ReactSystemFunctions.navigate(this, undefined, "LeadDetailTemp", "LeadRejectCustomerPopUp", "", "7d969ddf-5801-4eb6-b92b-12be35bdd565", "610962", null, "right", "true", "50vw", "100vh", true, false);

		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

            
            return isErrorOccurred;
        }


		LeadDetailTempComponent_7937_onClick = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations, this.checkTabErrors))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
KuikaAppManager.showSpinner(this);

					KuikaAppManager.prepareForNavigation();
						KuikaAppManager.addToPageInputVariables("LeadRejectPopUp", "LeadId", ReactSystemFunctions.convertToTypeByName(this.props.screenInputs.LeadId ?? this.props.screenInputs.leadid, "Guid"));

				stateVars.NAVIGATE = await ReactSystemFunctions.navigate(this, undefined, "LeadDetailTemp", "LeadRejectPopUp", "", "7d969ddf-5801-4eb6-b92b-12be35bdd565", "77840", null, "right", "true", "50vw", "100vh", true, false);

		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

            
            return isErrorOccurred;
        }


		LeadDetailTempComponent_170642_onClick = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations, this.checkTabErrors))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
KuikaAppManager.showSpinner(this);

					KuikaAppManager.prepareForNavigation();
						KuikaAppManager.addToPageInputVariables("TalepDuzenlemeEkrani", "LeadId", ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, (stateVars.TM_GetLeadById !== undefined ? (stateVars.TM_GetLeadById?.length > 0 ? stateVars.TM_GetLeadById[0].leadId : null) : (this.state.TM_GetLeadById?.length > 0 ? this.state.TM_GetLeadById[0].leadId : null))), "Guid"));
						KuikaAppManager.addToPageInputVariables("TalepDuzenlemeEkrani", "ProductId", ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, (stateVars.TM_GetLeadById !== undefined ? (stateVars.TM_GetLeadById?.length > 0 ? stateVars.TM_GetLeadById[0].productId : null) : (this.state.TM_GetLeadById?.length > 0 ? this.state.TM_GetLeadById[0].productId : null))), "Guid"));

				stateVars.NAVIGATE = await ReactSystemFunctions.navigate(this, undefined, "LeadDetailTemp", "TalepDuzenlemeEkrani", "", "7d969ddf-5801-4eb6-b92b-12be35bdd565", "14359", null, "right", "true", "60vw", "100vh", true, false);

		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

            
            return isErrorOccurred;
        }


		LeadDetailTempComponent_201879_onClick = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations, this.checkTabErrors))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
KuikaAppManager.showSpinner(this);

					KuikaAppManager.prepareForNavigation();
						KuikaAppManager.addToPageInputVariables("LeadProductChange", "LeadCode", ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadById !== undefined ? (stateVars.TM_GetLeadById?.length > 0 ? stateVars.TM_GetLeadById[0].leadCode : null) : (this.state.TM_GetLeadById?.length > 0 ? this.state.TM_GetLeadById[0].leadCode : null))), "string"));
						KuikaAppManager.addToPageInputVariables("LeadProductChange", "LeadId", ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, (stateVars.TM_GetLeadById !== undefined ? (stateVars.TM_GetLeadById?.length > 0 ? stateVars.TM_GetLeadById[0].leadId : null) : (this.state.TM_GetLeadById?.length > 0 ? this.state.TM_GetLeadById[0].leadId : null))), "Guid"));

				stateVars.NAVIGATE = await ReactSystemFunctions.navigate(this, undefined, "LeadDetailTemp", "LeadProductChange", "", "7d969ddf-5801-4eb6-b92b-12be35bdd565", "225717", null, "right", "true", "60vw", "100vh", true, false);

		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

            
            return isErrorOccurred;
        }


		LeadDetailTempComponent_921392_onClick = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations, this.checkTabErrors))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
KuikaAppManager.showSpinner(this);

					KuikaAppManager.prepareForNavigation();
						KuikaAppManager.addToPageInputVariables("CustomerDetailPage", "customerCode", ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadById !== undefined ? (stateVars.TM_GetLeadById?.length > 0 ? stateVars.TM_GetLeadById[0].currAccCode : null) : (this.state.TM_GetLeadById?.length > 0 ? this.state.TM_GetLeadById[0].currAccCode : null))), "string"));
						KuikaAppManager.addToPageInputVariables("CustomerDetailPage", "CustomerId", ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, (stateVars.TM_GetLeadById !== undefined ? (stateVars.TM_GetLeadById?.length > 0 ? stateVars.TM_GetLeadById[0].customerId : null) : (this.state.TM_GetLeadById?.length > 0 ? this.state.TM_GetLeadById[0].customerId : null))), "Guid"));

				stateVars.NAVIGATE = await ReactSystemFunctions.navigate(this, undefined, "LeadDetailTemp", "CustomerDetailPage", "", "7d969ddf-5801-4eb6-b92b-12be35bdd565", "180086", null, "right", "true", "60vw", "100vh", true, false);

		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

            
            return isErrorOccurred;
        }


		LeadDetailTempComponent_566330_onClick = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations, this.checkTabErrors))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
KuikaAppManager.showSpinner(this);

					KuikaAppManager.prepareForNavigation();
						KuikaAppManager.addToPageInputVariables("CustomerUpdatePost", "CustomerId", ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, (stateVars.TM_GetLeadById !== undefined ? (stateVars.TM_GetLeadById?.length > 0 ? stateVars.TM_GetLeadById[0].customerId : null) : (this.state.TM_GetLeadById?.length > 0 ? this.state.TM_GetLeadById[0].customerId : null))), "Guid"));

				stateVars.NAVIGATE = await ReactSystemFunctions.navigate(this, undefined, "LeadDetailTemp", "CustomerUpdatePost", "", "7d969ddf-5801-4eb6-b92b-12be35bdd565", "302731", null, "right", "true", "60vw", "100vh", true, false);

		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

            
            return isErrorOccurred;
        }


		LeadDetailTempComponent_507691_onClick = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations, this.checkTabErrors))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
KuikaAppManager.showSpinner(this);

					KuikaAppManager.prepareForNavigation();
						KuikaAppManager.addToPageInputVariables("TalebeAlternatifUrunEkle", "LeadCode", ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadById !== undefined ? (stateVars.TM_GetLeadById?.length > 0 ? stateVars.TM_GetLeadById[0].leadCode : null) : (this.state.TM_GetLeadById?.length > 0 ? this.state.TM_GetLeadById[0].leadCode : null))), "string"));
						KuikaAppManager.addToPageInputVariables("TalebeAlternatifUrunEkle", "LeadId", ReactSystemFunctions.convertToTypeByName(this.props.screenInputs.LeadId ?? this.props.screenInputs.leadid, "Guid"));

				stateVars.NAVIGATE = await ReactSystemFunctions.navigate(this, undefined, "LeadDetailTemp", "TalebeAlternatifUrunEkle", "", "7d969ddf-5801-4eb6-b92b-12be35bdd565", "286130", null, "right", "true", "60%", "100vh", true, false);

		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

            
            return isErrorOccurred;
        }


		LeadDetailTempComponent_68749_onClick = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations, this.checkTabErrors))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
KuikaAppManager.showSpinner(this);

					KuikaAppManager.prepareForNavigation();
						KuikaAppManager.addToPageInputVariables("LeadFileDetail", "LeadCode", ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadById !== undefined ? (stateVars.TM_GetLeadById?.length > 0 ? stateVars.TM_GetLeadById[0].leadCode : null) : (this.state.TM_GetLeadById?.length > 0 ? this.state.TM_GetLeadById[0].leadCode : null))), "string"));
						KuikaAppManager.addToPageInputVariables("LeadFileDetail", "LeadId", ReactSystemFunctions.convertToTypeByName(this.props.screenInputs.LeadId ?? this.props.screenInputs.leadid, "Guid"));

				stateVars.NAVIGATE = await ReactSystemFunctions.navigate(this, undefined, "LeadDetailTemp", "LeadFileDetail", "", "7d969ddf-5801-4eb6-b92b-12be35bdd565", "844090", null, "right", "true", "60%", "100vh", true, false);

		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

            
            return isErrorOccurred;
        }


		LeadDetailTempComponent_736090_onClick = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations, this.checkTabErrors))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
KuikaAppManager.showSpinner(this);

					KuikaAppManager.prepareForNavigation();
						KuikaAppManager.addToPageInputVariables("LeadDetailAddNote", "LeadId", ReactSystemFunctions.convertToTypeByName(this.props.screenInputs.LeadId ?? this.props.screenInputs.leadid, "Guid"));
						KuikaAppManager.addToPageInputVariables("LeadDetailAddNote", "LeadCode", ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadById !== undefined ? (stateVars.TM_GetLeadById?.length > 0 ? stateVars.TM_GetLeadById[0].leadCode : null) : (this.state.TM_GetLeadById?.length > 0 ? this.state.TM_GetLeadById[0].leadCode : null))), "string"));

				stateVars.NAVIGATE = await ReactSystemFunctions.navigate(this, undefined, "LeadDetailTemp", "LeadDetailAddNote", "", "7d969ddf-5801-4eb6-b92b-12be35bdd565", "894753", null, "right", "true", "60%", "100vh", true, false);

		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

            
            return isErrorOccurred;
        }


    LeadDetailTempComponent_436307_onClick = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations, this.checkTabErrors))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
		KuikaAppManager.increaseServerRequestCount();

        let localVar = {
				UserId_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.getMyUserId(), "Guid"),
				NoteId_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, "leaddetailtemp_811809_value", "noteId"), "Guid")
        }

		KuikaAppManager.showSpinner(this);

            stateVars.Confirm = await ReactSystemFunctions.confirmation(
                ReactSystemFunctions.translateCustomActions(this.ml,"ceb5b30c_012a_427e_78ca_894671906591_confirmation",this.defaultML,"Notu silmek istediğinizden emin misiniz ?" ),
                "poppins",
                "Uyarı",
                "confirmation",
                "#246dff",
                "",
                ""
            );

            if (stateVars.Confirm)
            {
                		
        if (true) {
        KuikaAppManager.showSpinner(this);
        }
        let result = await KuikaAppManager.ApiRequest(this, "LeadDetailTemp/LeadDetailTempComponent_436307_onClick", localVar)
        if (!KMainFunctions.IsResStatus2XX(result)) return true;

			stateVars.TM_LeadNoteDelete = result?.data.tM_LeadNoteDelete;
			this.props.form?.setFieldsValue(formVars);
			
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.LeadDetailTempComponent_436307_onClick1_();
                  resolve();
                });
          })

            }
            else
            {
                KuikaAppManager.hideSpinner(this);
            }


        
        KuikaAppManager.hideSpinner(this);
        return isErrorOccurred;
    }
		LeadDetailTempComponent_436307_onClick1_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations, this.checkTabErrors))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }

				stateVars.Notify = await ReactSystemFunctions.notify(this, ReactSystemFunctions.toString(this, (stateVars.TM_LeadNoteDelete !== undefined ? (stateVars.TM_LeadNoteDelete?.length > 0 ? stateVars.TM_LeadNoteDelete[0].message : null) : (this.state.TM_LeadNoteDelete?.length > 0 ? this.state.TM_LeadNoteDelete[0].message : null))), ReactSystemFunctions.convertToTypeByName("default", "string"), ReactSystemFunctions.convertToTypeByName("top-center", "string"), 3, ReactSystemFunctions.convertToTypeByName("", "string"), ReactSystemFunctions.convertToTypeByName("", "string"), 0);

		this.props.form?.setFieldsValue(formVars);
		
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.LeadDetailTempComponent_436307_onClick2_();
                  resolve();
                });
          })

            
            return isErrorOccurred;
        }
		LeadDetailTempComponent_436307_onClick2_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations, this.checkTabErrors))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
if (ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, (stateVars.TM_LeadNoteDelete !== undefined ? (stateVars.TM_LeadNoteDelete?.length > 0 ? stateVars.TM_LeadNoteDelete[0].success : null) : (this.state.TM_LeadNoteDelete?.length > 0 ? this.state.TM_LeadNoteDelete[0].success : null))), "1")) {
            
				await this.LeadDetailTempPageInit();
				

		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

        } else {
            KuikaAppManager.hideSpinner(this);
        }

            
            return isErrorOccurred;
        }





		LeadDetailTempComponent_555027_onClick = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations, this.checkTabErrors))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
KuikaAppManager.showSpinner(this);

				stateVars.DownloadFile = await ReactSystemFunctions.downloadFile(ReactSystemFunctions.value(this, "leaddetailtemp_577683_value", "fileData"), ReactSystemFunctions.value(this, "leaddetailtemp_577683_value", "fileName"));

		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

            
            return isErrorOccurred;
        }


    LeadDetailTempComponent_256215_onChange = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations, this.checkTabErrors))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
		KuikaAppManager.increaseServerRequestCount();

        let localVar = {
				LeadId_0: ReactSystemFunctions.convertToTypeByName(this.props.screenInputs.LeadId ?? this.props.screenInputs.leadid, "Guid"),
				ColumnName_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "leaddetailtemp_256215_value", "value", "", "", "")), "string"),
				UserName_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "leaddetailtemp_760282_value", "value", "", "", "")), "string"),
				StartDate_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "leaddetailtemp_67677_value", "startValue", "", "", "")), "Date"),
				EndDate_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "leaddetailtemp_67677_value", "endValue", "", "", "")), "Date")
        }

		KuikaAppManager.showSpinner(this);
		
        if (true) {
        KuikaAppManager.showSpinner(this);
        }
        let result = await KuikaAppManager.ApiRequest(this, "LeadDetailTemp/LeadDetailTempComponent_256215_onChange", localVar)
        if (!KMainFunctions.IsResStatus2XX(result)) return true;

			stateVars.TM_GetLeadLogById = result?.data.tM_GetLeadLogById;
			
			this.props.form?.setFieldsValue(formVars);
			
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.LeadDetailTempComponent_256215_onChange1_();
                  resolve();
                });
          })



        
        KuikaAppManager.hideSpinner(this);
        return isErrorOccurred;
    }
		LeadDetailTempComponent_256215_onChange1_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations, this.checkTabErrors))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }

				
				stateVars.dataSource_424782 = stateVars.TM_GetLeadLogById ?? this.state.TM_GetLeadLogById;

		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

            
            return isErrorOccurred;
        }




    LeadDetailTempComponent_760282_onChange = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations, this.checkTabErrors))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
		KuikaAppManager.increaseServerRequestCount();

        let localVar = {
				LeadId_0: ReactSystemFunctions.convertToTypeByName(this.props.screenInputs.LeadId ?? this.props.screenInputs.leadid, "Guid"),
				ColumnName_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "leaddetailtemp_256215_value", "value", "", "", "")), "string"),
				UserName_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "leaddetailtemp_760282_value", "value", "", "", "")), "string"),
				StartDate_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "leaddetailtemp_67677_value", "startValue", "", "", "")), "Date"),
				EndDate_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "leaddetailtemp_67677_value", "endValue", "", "", "")), "Date")
        }

		KuikaAppManager.showSpinner(this);
		
        if (true) {
        KuikaAppManager.showSpinner(this);
        }
        let result = await KuikaAppManager.ApiRequest(this, "LeadDetailTemp/LeadDetailTempComponent_760282_onChange", localVar)
        if (!KMainFunctions.IsResStatus2XX(result)) return true;

			stateVars.TM_GetLeadLogById = result?.data.tM_GetLeadLogById;
			
			this.props.form?.setFieldsValue(formVars);
			
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.LeadDetailTempComponent_760282_onChange1_();
                  resolve();
                });
          })



        
        KuikaAppManager.hideSpinner(this);
        return isErrorOccurred;
    }
		LeadDetailTempComponent_760282_onChange1_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations, this.checkTabErrors))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }

				
				stateVars.dataSource_424782 = stateVars.TM_GetLeadLogById ?? this.state.TM_GetLeadLogById;

		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

            
            return isErrorOccurred;
        }




    LeadDetailTempComponent_67677_onChange = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations, this.checkTabErrors))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
		KuikaAppManager.increaseServerRequestCount();

        let localVar = {
				LeadId_0: ReactSystemFunctions.convertToTypeByName(this.props.screenInputs.LeadId ?? this.props.screenInputs.leadid, "Guid"),
				ColumnName_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "leaddetailtemp_256215_value", "value", "", "", "")), "string"),
				UserName_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "leaddetailtemp_760282_value", "value", "", "", "")), "string"),
				StartDate_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "leaddetailtemp_67677_value", "startValue", "", "", "")), "Date"),
				EndDate_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "leaddetailtemp_67677_value", "endValue", "", "", "")), "Date")
        }

		KuikaAppManager.showSpinner(this);
		
        if (true) {
        KuikaAppManager.showSpinner(this);
        }
        let result = await KuikaAppManager.ApiRequest(this, "LeadDetailTemp/LeadDetailTempComponent_67677_onChange", localVar)
        if (!KMainFunctions.IsResStatus2XX(result)) return true;

			stateVars.TM_GetLeadLogById = result?.data.tM_GetLeadLogById;
			
			this.props.form?.setFieldsValue(formVars);
			
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.LeadDetailTempComponent_67677_onChange1_();
                  resolve();
                });
          })



        
        KuikaAppManager.hideSpinner(this);
        return isErrorOccurred;
    }
		LeadDetailTempComponent_67677_onChange1_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations, this.checkTabErrors))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }

				
				stateVars.dataSource_424782 = stateVars.TM_GetLeadLogById ?? this.state.TM_GetLeadLogById;

		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

            
            return isErrorOccurred;
        }




		LeadDetailTempComponent_77840_onClick = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations, this.checkTabErrors))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
KuikaAppManager.showSpinner(this);

					KuikaAppManager.prepareForNavigation();
						KuikaAppManager.addToPageInputVariables("LeadRejectCustomerPopUp", "LeadId", ReactSystemFunctions.convertToTypeByName(this.props.screenInputs.LeadId ?? this.props.screenInputs.leadid, "Guid"));

				stateVars.NAVIGATE = await ReactSystemFunctions.navigate(this, undefined, "LeadDetailTemp", "LeadRejectCustomerPopUp", "", "7d969ddf-5801-4eb6-b92b-12be35bdd565", "610962", null, "right", "true", "50vw", "100vh", true, false);

		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

            
            return isErrorOccurred;
        }


		LeadDetailTempComponent_610962_onClick = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations, this.checkTabErrors))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
KuikaAppManager.showSpinner(this);

					KuikaAppManager.prepareForNavigation();
						KuikaAppManager.addToPageInputVariables("ReservationPopUp", "StoreCode", ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadById !== undefined ? (stateVars.TM_GetLeadById?.length > 0 ? stateVars.TM_GetLeadById[0].storeCode : null) : (this.state.TM_GetLeadById?.length > 0 ? this.state.TM_GetLeadById[0].storeCode : null))), "string"));
						KuikaAppManager.addToPageInputVariables("ReservationPopUp", "ProductCode", ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadById !== undefined ? (stateVars.TM_GetLeadById?.length > 0 ? stateVars.TM_GetLeadById[0].productCode : null) : (this.state.TM_GetLeadById?.length > 0 ? this.state.TM_GetLeadById[0].productCode : null))), "string"));
						KuikaAppManager.addToPageInputVariables("ReservationPopUp", "LeadId", ReactSystemFunctions.convertToTypeByName(this.props.screenInputs.LeadId ?? this.props.screenInputs.leadid, "Guid"));

				stateVars.NAVIGATE = await ReactSystemFunctions.navigate(this, undefined, "LeadDetailTemp", "ReservationPopUp", "", "7d969ddf-5801-4eb6-b92b-12be35bdd565", "157929", null, "right", "true", "70vw", "100vh", true, false);

		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

            
            return isErrorOccurred;
        }


		LeadDetailTempComponent_635261_onClick = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations, this.checkTabErrors))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
KuikaAppManager.showSpinner(this);

					KuikaAppManager.prepareForNavigation();
						KuikaAppManager.addToPageInputVariables("SalesWeb", "LeadId", ReactSystemFunctions.convertToTypeByName(this.props.screenInputs.LeadId ?? this.props.screenInputs.leadid, "Guid"));

				stateVars.NAVIGATE = await ReactSystemFunctions.navigate(this, undefined, "LeadDetailTemp", "SalesWeb", "", "7d969ddf-5801-4eb6-b92b-12be35bdd565", "26874", null, "right", "true", "70vw", "100vh", true, false);

		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

            
            return isErrorOccurred;
        }


		LeadDetailTempComponent_274624_onClick = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations, this.checkTabErrors))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
KuikaAppManager.showSpinner(this);

					KuikaAppManager.prepareForNavigation();
						KuikaAppManager.addToPageInputVariables("ApproveLead", "LeadId", ReactSystemFunctions.convertToTypeByName(this.props.screenInputs.LeadId ?? this.props.screenInputs.leadid, "Guid"));

				stateVars.NAVIGATE = await ReactSystemFunctions.navigate(this, undefined, "LeadDetailTemp", "ApproveLead", "", "7d969ddf-5801-4eb6-b92b-12be35bdd565", "918852", null, "right", "true", "70vw", "100vh", true, false);

		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

            
            return isErrorOccurred;
        }


		LeadDetailTempComponent_933648_onChange = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations, this.checkTabErrors))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
KuikaAppManager.showSpinner(this);

				

		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

            
            return isErrorOccurred;
        }


		LeadDetailTempComponent_442178_onChange = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations, this.checkTabErrors))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
KuikaAppManager.showSpinner(this);

				

		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

            
            return isErrorOccurred;
        }




    async callCallbackFunction(diId: number, isFromMaster: boolean = false) {
        let isErrorOccurred = false;
		let pageInitCallerNavDiIDs = [288028, , , 26874, 635261, , 610962, 77840, 14359, 225717, 180086, 302731, 286130, 844090, 894753, 610962, 157929, 26874, 918852] as number[];
		if (isFromMaster || pageInitCallerNavDiIDs.indexOf(diId) > -1) {
			await this.LeadDetailTempPageInit();
		}

    }


}
