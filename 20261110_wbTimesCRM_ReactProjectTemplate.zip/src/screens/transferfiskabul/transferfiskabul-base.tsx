import React from "react";
import Axios, { AxiosResponse } from "axios";
import { KuikaAppManager } from "../../shared/utilty/kuika-app-manager";
import { ReactSystemFunctions } from "../../shared/utilty/react-system-functions";
import { KNavigator } from "../../shared/hoc/with-history";
import { KContext } from "../../shared/hoc/with-context";
import { useLocation } from "react-router-dom";
import { FormInstance } from "antd/es/form";
import { Guid } from "guid-typescript";
import Swal from "sweetalert2";
import { KMainFunctions } from "../../shared/utilty/main-functions";
import moment from "moment";
import { IValidationData } from "../../models/dto/validation-data";
import { IStripePayment } from "../../models/dto/stripe-payment";
import { IUserInfoDto } from "../../models/dto/user-info.dto";
import { UserService } from "../../services/user-service";
import { kuikaCoreWasmBridgeService } from "../../services/_singletons";
import _ from "lodash";
import mqtt, { MqttClient } from "mqtt";
import { IMqttResult } from "../../models/dto/mqtt.dto";


declare let window: any;

export interface ITransferFisKabul_ScreenProps {
  navigator: KNavigator;
  form: FormInstance<any>;
  googleLogin: any;
  screenInputs: any;
  context: KContext;
  initialValues: any;
  children: any;
}

export interface ITransferFisKabul_ScreenState {
    isSpinnerVisible: boolean;
    isPageVisible: boolean;
	isLeftMenuVisible: boolean;
    spinnerCount: number;
    selectedLanguage: string;
    isPageInitLoaded: false;
    isPageRecurringLoaded: false;
	TM_GetTransferAcceptanceDetail: any[];
	TM_GetTransferAcceptanceDetail_dummy: any[];
	TM_GetTransferAcceptanceSummary: any[];
	TM_GetTransferAcceptanceSummary_dummy: any[];
	TM_GetTransferERPDetail: any[];
	TM_GetTransferERPDetail_dummy: any[];
	GoBack: any;
	GoBack_dummy: any;
	TM_CheckTransferAcceptanceSerial: any[];
	TM_CheckTransferAcceptanceSerial_dummy: any[];
	TM_UpdateTransferAcceptanceLine: any[];
	TM_UpdateTransferAcceptanceLine_dummy: any[];
	Notify: boolean;
	Notify_dummy: boolean;
	IfThenElse: boolean;
	IfThenElse_dummy: boolean;
	ApproveTransfer: any;
	ApproveTransfer_dummy: any;
	TM_TransferOppositeApprovalAfterSql: any[];
	TM_TransferOppositeApprovalAfterSql_dummy: any[];
	TM_CompleteTransferAcceptance: any[];
	TM_CompleteTransferAcceptance_dummy: any[];
	NAVIGATE: any;
	NAVIGATE_dummy: any;
	isComp404099Visible: 'visible' | 'hidden';
	isComp432789Visible: 'visible' | 'hidden';
	isComp405096Visible: 'visible' | 'hidden';
	isComp626790Visible: 'visible' | 'hidden';
	isComp733329Visible: 'visible' | 'hidden';
	isComp666981Visible: 'visible' | 'hidden';
	isComp645799Visible: 'visible' | 'hidden';
	isComp25041Visible: 'visible' | 'hidden';
	isComp970632Visible: 'visible' | 'hidden';
	isComp700837Visible: 'visible' | 'hidden';
	isComp688569Visible: 'visible' | 'hidden';
	isComp342644Visible: 'visible' | 'hidden';
	isComp829509Visible: 'visible' | 'hidden';
	isComp176210Enabled: 'enabled' | 'disabled';

}

export class TransferFisKabul_ScreenBase extends React.PureComponent<ITransferFisKabul_ScreenProps, any> {

	transferfiskabul_711400_value_kuikaTableRef: React.RefObject<any>;
    ml=[{"Id":"d5a61d2b-bd60-485f-86e2-661e9ed4e486","Name":"en_US","ShortName":"English","IsDefault":true,"LanguagePhrases":[]},{"Id":"841845b7-f365-441e-9946-2262a3f38177","Name":"FixedValues","ShortName":"FixedValues","LanguagePhrases":[{"Id":419570,"PropertyName":"label","Value":"Fiş Detayına Dön"},{"Id":56222,"PropertyName":"value","Value":"Transfer Kabul İşlemi"},{"Id":404099,"PropertyName":"value","Value":"Kabul İşleminde"},{"Id":458561,"PropertyName":"value","Value":"Gelen ürünleri seri numaralarıyla kontrol ederek kabul işlemini tamamlayın."},{"Id":311219,"PropertyName":"value","Value":"Gönderen"},{"Id":738964,"PropertyName":"value","Value":"Alıcı"},{"Id":14627,"PropertyName":"value","Value":"Kargo Firması"},{"Id":774273,"PropertyName":"value","Value":"Yurtiçi Kargo"},{"Id":554490,"PropertyName":"value","Value":"Takip Numarası"},{"Id":156193,"PropertyName":"value","Value":"YK123456789"},{"Id":287766,"PropertyName":"value","Value":"Toplam Ürün"},{"Id":176475,"PropertyName":"value","Value":"Kontrol İlerlemesi"},{"Id":1293661644,"PropertyName":"value","Value":"/"},{"Id":1765858535,"PropertyName":"value","Value":"/"},{"Id":953816,"PropertyName":"value","Value":"ürün kontrol edildi"},{"Id":487112,"PropertyName":"value","Value":"Kabul Edildi "},{"Id":626790,"PropertyName":"value","Value":"Kabul Edildi 2"},{"Id":636898147,"PropertyName":"value","Value":"Eksik "},{"Id":733329,"PropertyName":"value","Value":"Eksik 1"},{"Id":1646694277,"PropertyName":"value","Value":"Yanlış Ürün "},{"Id":666981,"PropertyName":"value","Value":"Yanlış Ürün 0"},{"Id":1511171,"PropertyName":"value","Value":"Bekleyen"},{"Id":645799,"PropertyName":"value","Value":"Bekleyen 1"},{"Id":329622,"PropertyName":"value","Value":"Ürün ve Seri Kontrolü"},{"Id":899358,"PropertyName":"title","Value":"Sıra"},{"Id":84320,"PropertyName":"value","Value":"[datafield:sortorder]"},{"Id":970707,"PropertyName":"title","Value":"Ürün Kodu"},{"Id":945208,"PropertyName":"value","Value":"[datafield:productcode]"},{"Id":105412,"PropertyName":"title","Value":"Ürün Adı"},{"Id":261730,"PropertyName":"value","Value":"[datafield:productname]"},{"Id":986224,"PropertyName":"title","Value":"Beklenen Seri Numarası"},{"Id":366039,"PropertyName":"value","Value":"[datafield:serialnumber]"},{"Id":486746,"PropertyName":"title","Value":"Okutulan/Girilen Seri"},{"Id":530645,"PropertyName":"placeholder","Value":"Seri numarası girin"},{"Id":771534,"PropertyName":"title","Value":"Kabul Sonucu"},{"Id":44164,"PropertyName":"value","Value":"[datafield:acceptancestatuscode]"},{"Id":697233,"PropertyName":"title","Value":"Açıklama"},{"Id":40855,"PropertyName":"value","Value":"[datafield:acceptancereason]"},{"Id":869261,"PropertyName":"title","Value":"İşlemler"},{"Id":25041,"PropertyName":"label","Value":"Kontrol Et"},{"Id":970632,"PropertyName":"label","Value":"Eksik"},{"Id":700837,"PropertyName":"label","Value":"Yanlış Ürün"},{"Id":588229,"PropertyName":"value","Value":"Kabul Edildi 2 · Eksik 1 · Yanlış Ürün 0 · Bekleyen 1"},{"Id":65803,"PropertyName":"value","Value":"Sorunlu Kabul"},{"Id":342644,"PropertyName":"label","Value":"Fiş Detayına Dön"},{"Id":829509,"PropertyName":"label","Value":"Kontrolü Kaydet"},{"Id":176210,"PropertyName":"label","Value":"Kabulü Tamamla"}]}]
    defaultML = "en_US"
    
    screenHash = ""
    


    constructor(props) {
        super(props);
		this.transferfiskabul_711400_value_kuikaTableRef = React.createRef();
		this.transferfiskabul_530645_value_kuikaTextInputRef = React.createRef();

        this.state = {
            isSpinnerVisible: false,
            isPageVisible: false,
            isLeftMenuVisible: false,
            spinnerCount: 0,
            selectedLanguage: "",
            isPageInitLoaded: false,
            isPageRecurringLoaded: false,
            	        TM_GetTransferAcceptanceDetail: [],
	        TM_GetTransferAcceptanceSummary: [],
	        TM_GetTransferERPDetail: [],
	        GoBack: "",
	        TM_CheckTransferAcceptanceSerial: [],
	        IfThenElse: false,
	        TM_UpdateTransferAcceptanceLine: [],
	        ApproveTransfer: "",
	        TM_TransferOppositeApprovalAfterSql: [],
	        TM_CompleteTransferAcceptance: [],
	        Notify: false,
	        NAVIGATE: "",
	        isComp404099Visible: 'hidden',
	        isComp432789Visible: 'hidden',
	        isComp405096Visible: 'hidden',
	        isComp626790Visible: 'hidden',
	        isComp733329Visible: 'hidden',
	        isComp666981Visible: 'hidden',
	        isComp645799Visible: 'hidden',
	        isComp25041Visible: 'hidden',
	        isComp970632Visible: 'hidden',
	        isComp700837Visible: 'hidden',
	        isComp688569Visible: 'hidden',
	        isComp342644Visible: 'hidden',
	        isComp829509Visible: 'hidden',
	        isComp176210Enabled: 'disabled',

        }

        this.state.isPageVisible = true;
        
    }

    async componentDidMount() {

        if (KuikaAppManager.isPageInitPrevented()) {
            KuikaAppManager.calculateAndSetBodyHeight("transferfiskabul", "");
            return;
        }
        
        
        ReactSystemFunctions.validateToken()
        this.fillFormInitValues();
        if (true){
            await this.TransferFisKabulPageInit();
        }
        
        
        
        KuikaAppManager.calculateAndSetBodyHeight("transferfiskabul", "");

        if (ReactSystemFunctions.getIsMicroApp() === false) {
           window.parentScreen = this;
        }
    }

    componentWillUnmount() {
        
        
        

        if (ReactSystemFunctions.getIsMicroApp() === false) {
           window.parentScreen = null;
        }
    }

    

        
    componentDidUpdate= async (prevProps, prevState) => {
		KuikaAppManager.calculateAndSetBodyHeight("transferfiskabul", ""    );
        if (prevProps?.location?.search !== (this.props as any)?.location?.search) {
			await this.TransferFisKabulPageInit();
		}

        

        if (ReactSystemFunctions.getIsMicroApp() === false) {
            for (const key in prevState) {
                if (key.startsWith('NavVisible') && prevState[key] === true && this.state[key] === false) {
                    window.parentScreen = this;
                    break;
                }
            }
        }
	}

    fillFormInitValues() {
        this.props.form?.setFieldsValue({
});

    }

      setPageInitLoaded = (value: boolean) => {
        this.setState({ isPageInitLoaded: value });
      }

      setPageRecurringLoaded = (value: boolean) => {
        this.setState({ isPageRecurringLoaded: value });
      }

      clearFieldValidation = (changedValues: any) => {
        const fieldName = Object.keys(changedValues)[0];
        if (fieldName) {
          this.props.form?.setFields([
            {
              name: fieldName,
              errors: []
            }
          ]);
        }
      };

      

    TransferFisKabulPageInit = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


	if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }

        let localVar = {
			CurrentUsername_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.getMyUsername(), "string"),
			TransferERPHeaderId_0: ReactSystemFunctions.convertToTypeByName(this.props.screenInputs.TransferERPHeaderId ?? this.props.screenInputs.transfererpheaderid, "Guid"),
			TransferRequestHeaderId_1: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, (stateVars.TM_GetTransferAcceptanceDetail !== undefined ? (stateVars.TM_GetTransferAcceptanceDetail?.length > 0 ? stateVars.TM_GetTransferAcceptanceDetail[0].transferRequestHeaderId : null) : (this.state.TM_GetTransferAcceptanceDetail?.length > 0 ? this.state.TM_GetTransferAcceptanceDetail[0].transferRequestHeaderId : null))), "Guid"),
			CurrentUsername_2: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.getMyUsername(), "string"),
			TransferERPHeaderId_2: ReactSystemFunctions.convertToTypeByName(this.props.screenInputs.TransferERPHeaderId ?? this.props.screenInputs.transfererpheaderid, "Guid")
        }

	KuikaAppManager.showSpinner(this);
	
        if (true) {
        KuikaAppManager.showSpinner(this);
        }
        let result = await KuikaAppManager.ApiRequest(this, "TransferFisKabul/TransferFisKabulPageInit", localVar)
        if (!KMainFunctions.IsResStatus2XX(result)) return true;

		stateVars.TM_GetTransferAcceptanceDetail = result?.data.tM_GetTransferAcceptanceDetail;
		
		formVars.transferfiskabul_917606_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetTransferAcceptanceDetail !== undefined ? (stateVars.TM_GetTransferAcceptanceDetail?.length > 0 ? stateVars.TM_GetTransferAcceptanceDetail[0].transferERPNumber : null) : (this.state.TM_GetTransferAcceptanceDetail?.length > 0 ? this.state.TM_GetTransferAcceptanceDetail[0].transferERPNumber : null)));
		formVars.transferfiskabul_512483_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetTransferAcceptanceDetail !== undefined ? (stateVars.TM_GetTransferAcceptanceDetail?.length > 0 ? stateVars.TM_GetTransferAcceptanceDetail[0].sourceStoreName : null) : (this.state.TM_GetTransferAcceptanceDetail?.length > 0 ? this.state.TM_GetTransferAcceptanceDetail[0].sourceStoreName : null)));
		formVars.transferfiskabul_83446_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetTransferAcceptanceDetail !== undefined ? (stateVars.TM_GetTransferAcceptanceDetail?.length > 0 ? stateVars.TM_GetTransferAcceptanceDetail[0].destinationStoreName : null) : (this.state.TM_GetTransferAcceptanceDetail?.length > 0 ? this.state.TM_GetTransferAcceptanceDetail[0].destinationStoreName : null)));
		stateVars.isComp176210Enabled = (((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, (stateVars.TM_GetTransferAcceptanceDetail !== undefined ? (stateVars.TM_GetTransferAcceptanceDetail?.length > 0 ? stateVars.TM_GetTransferAcceptanceDetail[0].canManageAcceptance : null) : (this.state.TM_GetTransferAcceptanceDetail?.length > 0 ? this.state.TM_GetTransferAcceptanceDetail[0].canManageAcceptance : null))), ReactSystemFunctions.convertToTypeByName("True", "string")) && ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, (stateVars.TM_GetTransferAcceptanceSummary !== undefined ? (stateVars.TM_GetTransferAcceptanceSummary?.length > 0 ? stateVars.TM_GetTransferAcceptanceSummary[0].pendingCount : null) : (this.state.TM_GetTransferAcceptanceSummary?.length > 0 ? this.state.TM_GetTransferAcceptanceSummary[0].pendingCount : null))), ReactSystemFunctions.convertToTypeByName("0", "string")))) === true ? "enabled" : "disabled")
		stateVars.TM_GetTransferAcceptanceSummary = result?.data.tM_GetTransferAcceptanceSummary;
		formVars.transferfiskabul_468843_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetTransferAcceptanceSummary !== undefined ? (stateVars.TM_GetTransferAcceptanceSummary?.length > 0 ? stateVars.TM_GetTransferAcceptanceSummary[0].totalProductCount : null) : (this.state.TM_GetTransferAcceptanceSummary?.length > 0 ? this.state.TM_GetTransferAcceptanceSummary[0].totalProductCount : null)));
		formVars.transferfiskabul_393217_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetTransferAcceptanceSummary !== undefined ? (stateVars.TM_GetTransferAcceptanceSummary?.length > 0 ? stateVars.TM_GetTransferAcceptanceSummary[0].checkedCount : null) : (this.state.TM_GetTransferAcceptanceSummary?.length > 0 ? this.state.TM_GetTransferAcceptanceSummary[0].checkedCount : null)));
		formVars.transferfiskabul_1925711325_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetTransferAcceptanceSummary !== undefined ? (stateVars.TM_GetTransferAcceptanceSummary?.length > 0 ? stateVars.TM_GetTransferAcceptanceSummary[0].totalProductCount : null) : (this.state.TM_GetTransferAcceptanceSummary?.length > 0 ? this.state.TM_GetTransferAcceptanceSummary[0].totalProductCount : null)));
		formVars.transferfiskabul_123938614_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetTransferAcceptanceSummary !== undefined ? (stateVars.TM_GetTransferAcceptanceSummary?.length > 0 ? stateVars.TM_GetTransferAcceptanceSummary[0].checkedCount : null) : (this.state.TM_GetTransferAcceptanceSummary?.length > 0 ? this.state.TM_GetTransferAcceptanceSummary[0].checkedCount : null)));
		formVars.transferfiskabul_1618579563_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetTransferAcceptanceSummary !== undefined ? (stateVars.TM_GetTransferAcceptanceSummary?.length > 0 ? stateVars.TM_GetTransferAcceptanceSummary[0].totalProductCount : null) : (this.state.TM_GetTransferAcceptanceSummary?.length > 0 ? this.state.TM_GetTransferAcceptanceSummary[0].totalProductCount : null)));
		formVars.transferfiskabul_303602_percent = ReactSystemFunctions.value(this, (stateVars.TM_GetTransferAcceptanceSummary !== undefined ? (stateVars.TM_GetTransferAcceptanceSummary?.length > 0 ? stateVars.TM_GetTransferAcceptanceSummary[stateVars.TM_GetTransferAcceptanceSummary.length - 1].progressPercent : null) : (this.state.TM_GetTransferAcceptanceSummary?.length > 0 ? this.state.TM_GetTransferAcceptanceSummary[this.state.TM_GetTransferAcceptanceSummary.length - 1].progressPercent : null)));
		formVars.transferfiskabul_906419956_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetTransferAcceptanceSummary !== undefined ? (stateVars.TM_GetTransferAcceptanceSummary?.length > 0 ? stateVars.TM_GetTransferAcceptanceSummary[0].acceptedCount : null) : (this.state.TM_GetTransferAcceptanceSummary?.length > 0 ? this.state.TM_GetTransferAcceptanceSummary[0].acceptedCount : null)));
		formVars.transferfiskabul_1752305274_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetTransferAcceptanceSummary !== undefined ? (stateVars.TM_GetTransferAcceptanceSummary?.length > 0 ? stateVars.TM_GetTransferAcceptanceSummary[0].missingCount : null) : (this.state.TM_GetTransferAcceptanceSummary?.length > 0 ? this.state.TM_GetTransferAcceptanceSummary[0].missingCount : null)));
		formVars.transferfiskabul_1059519956_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetTransferAcceptanceSummary !== undefined ? (stateVars.TM_GetTransferAcceptanceSummary?.length > 0 ? stateVars.TM_GetTransferAcceptanceSummary[0].wrongProductCount : null) : (this.state.TM_GetTransferAcceptanceSummary?.length > 0 ? this.state.TM_GetTransferAcceptanceSummary[0].wrongProductCount : null)));
		formVars.transferfiskabul_1407718925_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetTransferAcceptanceSummary !== undefined ? (stateVars.TM_GetTransferAcceptanceSummary?.length > 0 ? stateVars.TM_GetTransferAcceptanceSummary[0].pendingCount : null) : (this.state.TM_GetTransferAcceptanceSummary?.length > 0 ? this.state.TM_GetTransferAcceptanceSummary[0].pendingCount : null)));
		stateVars.isComp176210Enabled = (((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, (stateVars.TM_GetTransferAcceptanceDetail !== undefined ? (stateVars.TM_GetTransferAcceptanceDetail?.length > 0 ? stateVars.TM_GetTransferAcceptanceDetail[0].canManageAcceptance : null) : (this.state.TM_GetTransferAcceptanceDetail?.length > 0 ? this.state.TM_GetTransferAcceptanceDetail[0].canManageAcceptance : null))), ReactSystemFunctions.convertToTypeByName("True", "string")) && ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, (stateVars.TM_GetTransferAcceptanceSummary !== undefined ? (stateVars.TM_GetTransferAcceptanceSummary?.length > 0 ? stateVars.TM_GetTransferAcceptanceSummary[0].pendingCount : null) : (this.state.TM_GetTransferAcceptanceSummary?.length > 0 ? this.state.TM_GetTransferAcceptanceSummary[0].pendingCount : null))), ReactSystemFunctions.convertToTypeByName("0", "string")))) === true ? "enabled" : "disabled")
		stateVars.TM_GetTransferERPDetail = result?.data.tM_GetTransferERPDetail;
		this.props.form?.setFieldsValue(formVars);
		
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.TransferFisKabulPageInit1_();
                  resolve();
                });
          })



        
        KuikaAppManager.hideSpinner(this);
        return isErrorOccurred;
    }
	TransferFisKabulPageInit1_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


	if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }

			formVars.transferfiskabul_917606_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetTransferAcceptanceDetail !== undefined ? (stateVars.TM_GetTransferAcceptanceDetail?.length > 0 ? stateVars.TM_GetTransferAcceptanceDetail[0].transferERPNumber : null) : (this.state.TM_GetTransferAcceptanceDetail?.length > 0 ? this.state.TM_GetTransferAcceptanceDetail[0].transferERPNumber : null)));

			formVars.transferfiskabul_512483_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetTransferAcceptanceDetail !== undefined ? (stateVars.TM_GetTransferAcceptanceDetail?.length > 0 ? stateVars.TM_GetTransferAcceptanceDetail[0].sourceStoreName : null) : (this.state.TM_GetTransferAcceptanceDetail?.length > 0 ? this.state.TM_GetTransferAcceptanceDetail[0].sourceStoreName : null)));

			formVars.transferfiskabul_83446_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetTransferAcceptanceDetail !== undefined ? (stateVars.TM_GetTransferAcceptanceDetail?.length > 0 ? stateVars.TM_GetTransferAcceptanceDetail[0].destinationStoreName : null) : (this.state.TM_GetTransferAcceptanceDetail?.length > 0 ? this.state.TM_GetTransferAcceptanceDetail[0].destinationStoreName : null)));

			formVars.transferfiskabul_468843_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetTransferAcceptanceSummary !== undefined ? (stateVars.TM_GetTransferAcceptanceSummary?.length > 0 ? stateVars.TM_GetTransferAcceptanceSummary[0].totalProductCount : null) : (this.state.TM_GetTransferAcceptanceSummary?.length > 0 ? this.state.TM_GetTransferAcceptanceSummary[0].totalProductCount : null)));

			formVars.transferfiskabul_393217_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetTransferAcceptanceSummary !== undefined ? (stateVars.TM_GetTransferAcceptanceSummary?.length > 0 ? stateVars.TM_GetTransferAcceptanceSummary[0].checkedCount : null) : (this.state.TM_GetTransferAcceptanceSummary?.length > 0 ? this.state.TM_GetTransferAcceptanceSummary[0].checkedCount : null)));

			formVars.transferfiskabul_1925711325_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetTransferAcceptanceSummary !== undefined ? (stateVars.TM_GetTransferAcceptanceSummary?.length > 0 ? stateVars.TM_GetTransferAcceptanceSummary[0].totalProductCount : null) : (this.state.TM_GetTransferAcceptanceSummary?.length > 0 ? this.state.TM_GetTransferAcceptanceSummary[0].totalProductCount : null)));

			formVars.transferfiskabul_123938614_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetTransferAcceptanceSummary !== undefined ? (stateVars.TM_GetTransferAcceptanceSummary?.length > 0 ? stateVars.TM_GetTransferAcceptanceSummary[0].checkedCount : null) : (this.state.TM_GetTransferAcceptanceSummary?.length > 0 ? this.state.TM_GetTransferAcceptanceSummary[0].checkedCount : null)));

			formVars.transferfiskabul_1618579563_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetTransferAcceptanceSummary !== undefined ? (stateVars.TM_GetTransferAcceptanceSummary?.length > 0 ? stateVars.TM_GetTransferAcceptanceSummary[0].totalProductCount : null) : (this.state.TM_GetTransferAcceptanceSummary?.length > 0 ? this.state.TM_GetTransferAcceptanceSummary[0].totalProductCount : null)));

			formVars.transferfiskabul_303602_percent = ReactSystemFunctions.value(this, (stateVars.TM_GetTransferAcceptanceSummary !== undefined ? (stateVars.TM_GetTransferAcceptanceSummary?.length > 0 ? stateVars.TM_GetTransferAcceptanceSummary[stateVars.TM_GetTransferAcceptanceSummary.length - 1].progressPercent : null) : (this.state.TM_GetTransferAcceptanceSummary?.length > 0 ? this.state.TM_GetTransferAcceptanceSummary[this.state.TM_GetTransferAcceptanceSummary.length - 1].progressPercent : null)));

			formVars.transferfiskabul_906419956_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetTransferAcceptanceSummary !== undefined ? (stateVars.TM_GetTransferAcceptanceSummary?.length > 0 ? stateVars.TM_GetTransferAcceptanceSummary[0].acceptedCount : null) : (this.state.TM_GetTransferAcceptanceSummary?.length > 0 ? this.state.TM_GetTransferAcceptanceSummary[0].acceptedCount : null)));

			formVars.transferfiskabul_1752305274_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetTransferAcceptanceSummary !== undefined ? (stateVars.TM_GetTransferAcceptanceSummary?.length > 0 ? stateVars.TM_GetTransferAcceptanceSummary[0].missingCount : null) : (this.state.TM_GetTransferAcceptanceSummary?.length > 0 ? this.state.TM_GetTransferAcceptanceSummary[0].missingCount : null)));

			formVars.transferfiskabul_1059519956_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetTransferAcceptanceSummary !== undefined ? (stateVars.TM_GetTransferAcceptanceSummary?.length > 0 ? stateVars.TM_GetTransferAcceptanceSummary[0].wrongProductCount : null) : (this.state.TM_GetTransferAcceptanceSummary?.length > 0 ? this.state.TM_GetTransferAcceptanceSummary[0].wrongProductCount : null)));

			formVars.transferfiskabul_1407718925_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetTransferAcceptanceSummary !== undefined ? (stateVars.TM_GetTransferAcceptanceSummary?.length > 0 ? stateVars.TM_GetTransferAcceptanceSummary[0].pendingCount : null) : (this.state.TM_GetTransferAcceptanceSummary?.length > 0 ? this.state.TM_GetTransferAcceptanceSummary[0].pendingCount : null)));

			
			stateVars.dataSource_711400 = stateVars.TM_GetTransferAcceptanceDetail ?? this.state.TM_GetTransferAcceptanceDetail;
			stateVars.isComp25041Visible = (((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, "transferfiskabul_711400_value", "lineStatusCode"), ReactSystemFunctions.convertToTypeByName("IN_TRANSIT", "string")) && ReactSystemFunctions.isNotEqualTo(ReactSystemFunctions.value(this, "transferfiskabul_711400_value", "acceptanceStatusCode"), ReactSystemFunctions.convertToTypeByName("ACCEPTED", "string")) && ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, "transferfiskabul_711400_value", "canManageAcceptance"), ReactSystemFunctions.convertToTypeByName("True", "string")))) === true ? "visible" : "hidden")
			stateVars.isComp176210Enabled = (((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, (stateVars.TM_GetTransferAcceptanceDetail !== undefined ? (stateVars.TM_GetTransferAcceptanceDetail?.length > 0 ? stateVars.TM_GetTransferAcceptanceDetail[0].canManageAcceptance : null) : (this.state.TM_GetTransferAcceptanceDetail?.length > 0 ? this.state.TM_GetTransferAcceptanceDetail[0].canManageAcceptance : null))), ReactSystemFunctions.convertToTypeByName("True", "string")) && ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, (stateVars.TM_GetTransferAcceptanceSummary !== undefined ? (stateVars.TM_GetTransferAcceptanceSummary?.length > 0 ? stateVars.TM_GetTransferAcceptanceSummary[0].pendingCount : null) : (this.state.TM_GetTransferAcceptanceSummary?.length > 0 ? this.state.TM_GetTransferAcceptanceSummary[0].pendingCount : null))), ReactSystemFunctions.convertToTypeByName("0", "string")))) === true ? "enabled" : "disabled")

	this.props.form?.setFieldsValue(formVars);
	this.setState(stateVars);
	KuikaAppManager.hideSpinner(this);

            this.setPageInitLoaded(true);
            return isErrorOccurred;
        }




		TransferFisKabulComponent_419570_onClick = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
KuikaAppManager.showSpinner(this);

				stateVars.GoBack = await ReactSystemFunctions.goBack(this, false);

		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

            
            return isErrorOccurred;
        }


    TransferFisKabulComponent_25041_onClick = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
		KuikaAppManager.increaseServerRequestCount();

        let localVar = {
				ScannedSerialNumber_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, "transferfiskabul_711400_value", "scannedSerialNumber"), "string"),
				TransferERPLineId_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, "transferfiskabul_711400_value", "transferERPLineId"), "Guid")
        }

		KuikaAppManager.showSpinner(this);
		
        if (true) {
        KuikaAppManager.showSpinner(this);
        }
        let result = await KuikaAppManager.ApiRequest(this, "TransferFisKabul/TransferFisKabulComponent_25041_onClick", localVar)
        if (!KMainFunctions.IsResStatus2XX(result)) return true;

			stateVars.TM_CheckTransferAcceptanceSerial = result?.data.tM_CheckTransferAcceptanceSerial;
			this.props.form?.setFieldsValue(formVars);
			
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.TransferFisKabulComponent_25041_onClick1_();
                  resolve();
                });
          })



        
        KuikaAppManager.hideSpinner(this);
        return isErrorOccurred;
    }
    TransferFisKabulComponent_25041_onClick_if1 = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
		KuikaAppManager.increaseServerRequestCount();

        let localVar = {
				CurrentUsername_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.getMyUsername(), "string"),
				AcceptanceStatusCode_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.convertToTypeByName("ACCEPTED", "string"), "string"),
				AcceptanceReason_0: ReactSystemFunctions.convertToTypeByName("", "string"),
				ScannedSerialNumber_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, "transferfiskabul_711400_value", "scannedSerialNumber"), "string"),
				TransferERPLineId_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, "transferfiskabul_711400_value", "transferERPLineId"), "Guid"),
				CurrentUsername_1: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.getMyUsername(), "string"),
				TransferERPHeaderId_1: ReactSystemFunctions.convertToTypeByName(this.props.screenInputs.TransferERPHeaderId ?? this.props.screenInputs.transfererpheaderid, "Guid")
        }

		KuikaAppManager.showSpinner(this);
		
        if (true) {
        KuikaAppManager.showSpinner(this);
        }
        let result = await KuikaAppManager.ApiRequest(this, "TransferFisKabul/TransferFisKabulComponent_25041_onClick_if1", localVar)
        if (!KMainFunctions.IsResStatus2XX(result)) return true;

			stateVars.TM_UpdateTransferAcceptanceLine = result?.data.tM_UpdateTransferAcceptanceLine;
			stateVars.TM_GetTransferAcceptanceDetail = result?.data.tM_GetTransferAcceptanceDetail;
			
			formVars.transferfiskabul_917606_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetTransferAcceptanceDetail !== undefined ? (stateVars.TM_GetTransferAcceptanceDetail?.length > 0 ? stateVars.TM_GetTransferAcceptanceDetail[0].transferERPNumber : null) : (this.state.TM_GetTransferAcceptanceDetail?.length > 0 ? this.state.TM_GetTransferAcceptanceDetail[0].transferERPNumber : null)));
			formVars.transferfiskabul_512483_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetTransferAcceptanceDetail !== undefined ? (stateVars.TM_GetTransferAcceptanceDetail?.length > 0 ? stateVars.TM_GetTransferAcceptanceDetail[0].sourceStoreName : null) : (this.state.TM_GetTransferAcceptanceDetail?.length > 0 ? this.state.TM_GetTransferAcceptanceDetail[0].sourceStoreName : null)));
			formVars.transferfiskabul_83446_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetTransferAcceptanceDetail !== undefined ? (stateVars.TM_GetTransferAcceptanceDetail?.length > 0 ? stateVars.TM_GetTransferAcceptanceDetail[0].destinationStoreName : null) : (this.state.TM_GetTransferAcceptanceDetail?.length > 0 ? this.state.TM_GetTransferAcceptanceDetail[0].destinationStoreName : null)));
			stateVars.isComp176210Enabled = (((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, (stateVars.TM_GetTransferAcceptanceDetail !== undefined ? (stateVars.TM_GetTransferAcceptanceDetail?.length > 0 ? stateVars.TM_GetTransferAcceptanceDetail[0].canManageAcceptance : null) : (this.state.TM_GetTransferAcceptanceDetail?.length > 0 ? this.state.TM_GetTransferAcceptanceDetail[0].canManageAcceptance : null))), ReactSystemFunctions.convertToTypeByName("True", "string")) && ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, (stateVars.TM_GetTransferAcceptanceSummary !== undefined ? (stateVars.TM_GetTransferAcceptanceSummary?.length > 0 ? stateVars.TM_GetTransferAcceptanceSummary[0].pendingCount : null) : (this.state.TM_GetTransferAcceptanceSummary?.length > 0 ? this.state.TM_GetTransferAcceptanceSummary[0].pendingCount : null))), ReactSystemFunctions.convertToTypeByName("0", "string")))) === true ? "enabled" : "disabled")
			this.props.form?.setFieldsValue(formVars);
			
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.TransferFisKabulComponent_25041_onClick_if11_();
                  resolve();
                });
          })



        
        KuikaAppManager.hideSpinner(this);
        return isErrorOccurred;
    }
		TransferFisKabulComponent_25041_onClick_if11_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }

				formVars.transferfiskabul_917606_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetTransferAcceptanceDetail !== undefined ? (stateVars.TM_GetTransferAcceptanceDetail?.length > 0 ? stateVars.TM_GetTransferAcceptanceDetail[0].transferERPNumber : null) : (this.state.TM_GetTransferAcceptanceDetail?.length > 0 ? this.state.TM_GetTransferAcceptanceDetail[0].transferERPNumber : null)));

				formVars.transferfiskabul_512483_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetTransferAcceptanceDetail !== undefined ? (stateVars.TM_GetTransferAcceptanceDetail?.length > 0 ? stateVars.TM_GetTransferAcceptanceDetail[0].sourceStoreName : null) : (this.state.TM_GetTransferAcceptanceDetail?.length > 0 ? this.state.TM_GetTransferAcceptanceDetail[0].sourceStoreName : null)));

				formVars.transferfiskabul_83446_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetTransferAcceptanceDetail !== undefined ? (stateVars.TM_GetTransferAcceptanceDetail?.length > 0 ? stateVars.TM_GetTransferAcceptanceDetail[0].destinationStoreName : null) : (this.state.TM_GetTransferAcceptanceDetail?.length > 0 ? this.state.TM_GetTransferAcceptanceDetail[0].destinationStoreName : null)));

				
				stateVars.dataSource_711400 = stateVars.TM_GetTransferAcceptanceDetail ?? this.state.TM_GetTransferAcceptanceDetail;

		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);

            
            return isErrorOccurred;
        }




		TransferFisKabulComponent_25041_onClick_else1 = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
KuikaAppManager.showSpinner(this);

				stateVars.Notify = await ReactSystemFunctions.notify(this, ReactSystemFunctions.toString(this, (stateVars.TM_CheckTransferAcceptanceSerial !== undefined ? (stateVars.TM_CheckTransferAcceptanceSerial?.length > 0 ? stateVars.TM_CheckTransferAcceptanceSerial[0].message : null) : (this.state.TM_CheckTransferAcceptanceSerial?.length > 0 ? this.state.TM_CheckTransferAcceptanceSerial[0].message : null))), ReactSystemFunctions.convertToTypeByName("danger", "string"), ReactSystemFunctions.convertToTypeByName("bottom-right", "string"), 3, ReactSystemFunctions.convertToTypeByName("", "string"), ReactSystemFunctions.convertToTypeByName("", "string"), 0);

		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);

            
            return isErrorOccurred;
        }


		TransferFisKabulComponent_25041_onClick1_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
if (ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, (stateVars.TM_CheckTransferAcceptanceSerial !== undefined ? (stateVars.TM_CheckTransferAcceptanceSerial?.length > 0 ? stateVars.TM_CheckTransferAcceptanceSerial[0].isMatch : null) : (this.state.TM_CheckTransferAcceptanceSerial?.length > 0 ? this.state.TM_CheckTransferAcceptanceSerial[0].isMatch : null))), true)) {
            isErrorOccurred = await this.TransferFisKabulComponent_25041_onClick_if1();
                if (isErrorOccurred) return true;
        } else {
            isErrorOccurred = await this.TransferFisKabulComponent_25041_onClick_else1();
                if (isErrorOccurred) return true;
        }


		this.props.form?.setFieldsValue(formVars);
		
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.TransferFisKabulComponent_25041_onClick2_();
                  resolve();
                });
          })

            
            return isErrorOccurred;
        }
    TransferFisKabulComponent_25041_onClick2_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
		KuikaAppManager.increaseServerRequestCount();

        let localVar = {
				TransferRequestHeaderId_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, (stateVars.TM_GetTransferAcceptanceDetail !== undefined ? (stateVars.TM_GetTransferAcceptanceDetail?.length > 0 ? stateVars.TM_GetTransferAcceptanceDetail[0].transferRequestHeaderId : null) : (this.state.TM_GetTransferAcceptanceDetail?.length > 0 ? this.state.TM_GetTransferAcceptanceDetail[0].transferRequestHeaderId : null))), "Guid")
        }

		
        if (true) {
        KuikaAppManager.showSpinner(this);
        }
        let result = await KuikaAppManager.ApiRequest(this, "TransferFisKabul/TransferFisKabulComponent_25041_onClick2_", localVar)
        if (!KMainFunctions.IsResStatus2XX(result)) return true;

			stateVars.TM_GetTransferAcceptanceSummary = result?.data.tM_GetTransferAcceptanceSummary;
			formVars.transferfiskabul_468843_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetTransferAcceptanceSummary !== undefined ? (stateVars.TM_GetTransferAcceptanceSummary?.length > 0 ? stateVars.TM_GetTransferAcceptanceSummary[0].totalProductCount : null) : (this.state.TM_GetTransferAcceptanceSummary?.length > 0 ? this.state.TM_GetTransferAcceptanceSummary[0].totalProductCount : null)));
			formVars.transferfiskabul_393217_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetTransferAcceptanceSummary !== undefined ? (stateVars.TM_GetTransferAcceptanceSummary?.length > 0 ? stateVars.TM_GetTransferAcceptanceSummary[0].checkedCount : null) : (this.state.TM_GetTransferAcceptanceSummary?.length > 0 ? this.state.TM_GetTransferAcceptanceSummary[0].checkedCount : null)));
			formVars.transferfiskabul_1925711325_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetTransferAcceptanceSummary !== undefined ? (stateVars.TM_GetTransferAcceptanceSummary?.length > 0 ? stateVars.TM_GetTransferAcceptanceSummary[0].totalProductCount : null) : (this.state.TM_GetTransferAcceptanceSummary?.length > 0 ? this.state.TM_GetTransferAcceptanceSummary[0].totalProductCount : null)));
			formVars.transferfiskabul_123938614_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetTransferAcceptanceSummary !== undefined ? (stateVars.TM_GetTransferAcceptanceSummary?.length > 0 ? stateVars.TM_GetTransferAcceptanceSummary[0].checkedCount : null) : (this.state.TM_GetTransferAcceptanceSummary?.length > 0 ? this.state.TM_GetTransferAcceptanceSummary[0].checkedCount : null)));
			formVars.transferfiskabul_1618579563_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetTransferAcceptanceSummary !== undefined ? (stateVars.TM_GetTransferAcceptanceSummary?.length > 0 ? stateVars.TM_GetTransferAcceptanceSummary[0].totalProductCount : null) : (this.state.TM_GetTransferAcceptanceSummary?.length > 0 ? this.state.TM_GetTransferAcceptanceSummary[0].totalProductCount : null)));
			formVars.transferfiskabul_303602_percent = ReactSystemFunctions.value(this, (stateVars.TM_GetTransferAcceptanceSummary !== undefined ? (stateVars.TM_GetTransferAcceptanceSummary?.length > 0 ? stateVars.TM_GetTransferAcceptanceSummary[stateVars.TM_GetTransferAcceptanceSummary.length - 1].progressPercent : null) : (this.state.TM_GetTransferAcceptanceSummary?.length > 0 ? this.state.TM_GetTransferAcceptanceSummary[this.state.TM_GetTransferAcceptanceSummary.length - 1].progressPercent : null)));
			formVars.transferfiskabul_906419956_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetTransferAcceptanceSummary !== undefined ? (stateVars.TM_GetTransferAcceptanceSummary?.length > 0 ? stateVars.TM_GetTransferAcceptanceSummary[0].acceptedCount : null) : (this.state.TM_GetTransferAcceptanceSummary?.length > 0 ? this.state.TM_GetTransferAcceptanceSummary[0].acceptedCount : null)));
			formVars.transferfiskabul_1752305274_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetTransferAcceptanceSummary !== undefined ? (stateVars.TM_GetTransferAcceptanceSummary?.length > 0 ? stateVars.TM_GetTransferAcceptanceSummary[0].missingCount : null) : (this.state.TM_GetTransferAcceptanceSummary?.length > 0 ? this.state.TM_GetTransferAcceptanceSummary[0].missingCount : null)));
			formVars.transferfiskabul_1059519956_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetTransferAcceptanceSummary !== undefined ? (stateVars.TM_GetTransferAcceptanceSummary?.length > 0 ? stateVars.TM_GetTransferAcceptanceSummary[0].wrongProductCount : null) : (this.state.TM_GetTransferAcceptanceSummary?.length > 0 ? this.state.TM_GetTransferAcceptanceSummary[0].wrongProductCount : null)));
			formVars.transferfiskabul_1407718925_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetTransferAcceptanceSummary !== undefined ? (stateVars.TM_GetTransferAcceptanceSummary?.length > 0 ? stateVars.TM_GetTransferAcceptanceSummary[0].pendingCount : null) : (this.state.TM_GetTransferAcceptanceSummary?.length > 0 ? this.state.TM_GetTransferAcceptanceSummary[0].pendingCount : null)));
			stateVars.isComp176210Enabled = (((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, (stateVars.TM_GetTransferAcceptanceDetail !== undefined ? (stateVars.TM_GetTransferAcceptanceDetail?.length > 0 ? stateVars.TM_GetTransferAcceptanceDetail[0].canManageAcceptance : null) : (this.state.TM_GetTransferAcceptanceDetail?.length > 0 ? this.state.TM_GetTransferAcceptanceDetail[0].canManageAcceptance : null))), ReactSystemFunctions.convertToTypeByName("True", "string")) && ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, (stateVars.TM_GetTransferAcceptanceSummary !== undefined ? (stateVars.TM_GetTransferAcceptanceSummary?.length > 0 ? stateVars.TM_GetTransferAcceptanceSummary[0].pendingCount : null) : (this.state.TM_GetTransferAcceptanceSummary?.length > 0 ? this.state.TM_GetTransferAcceptanceSummary[0].pendingCount : null))), ReactSystemFunctions.convertToTypeByName("0", "string")))) === true ? "enabled" : "disabled")
			this.props.form?.setFieldsValue(formVars);
			
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.TransferFisKabulComponent_25041_onClick3_();
                  resolve();
                });
          })



        
        KuikaAppManager.hideSpinner(this);
        return isErrorOccurred;
    }
		TransferFisKabulComponent_25041_onClick3_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }

				formVars.transferfiskabul_468843_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetTransferAcceptanceSummary !== undefined ? (stateVars.TM_GetTransferAcceptanceSummary?.length > 0 ? stateVars.TM_GetTransferAcceptanceSummary[0].totalProductCount : null) : (this.state.TM_GetTransferAcceptanceSummary?.length > 0 ? this.state.TM_GetTransferAcceptanceSummary[0].totalProductCount : null)));

				formVars.transferfiskabul_393217_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetTransferAcceptanceSummary !== undefined ? (stateVars.TM_GetTransferAcceptanceSummary?.length > 0 ? stateVars.TM_GetTransferAcceptanceSummary[0].checkedCount : null) : (this.state.TM_GetTransferAcceptanceSummary?.length > 0 ? this.state.TM_GetTransferAcceptanceSummary[0].checkedCount : null)));

				formVars.transferfiskabul_1925711325_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetTransferAcceptanceSummary !== undefined ? (stateVars.TM_GetTransferAcceptanceSummary?.length > 0 ? stateVars.TM_GetTransferAcceptanceSummary[0].totalProductCount : null) : (this.state.TM_GetTransferAcceptanceSummary?.length > 0 ? this.state.TM_GetTransferAcceptanceSummary[0].totalProductCount : null)));

				formVars.transferfiskabul_123938614_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetTransferAcceptanceSummary !== undefined ? (stateVars.TM_GetTransferAcceptanceSummary?.length > 0 ? stateVars.TM_GetTransferAcceptanceSummary[0].checkedCount : null) : (this.state.TM_GetTransferAcceptanceSummary?.length > 0 ? this.state.TM_GetTransferAcceptanceSummary[0].checkedCount : null)));

				formVars.transferfiskabul_1618579563_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetTransferAcceptanceSummary !== undefined ? (stateVars.TM_GetTransferAcceptanceSummary?.length > 0 ? stateVars.TM_GetTransferAcceptanceSummary[0].totalProductCount : null) : (this.state.TM_GetTransferAcceptanceSummary?.length > 0 ? this.state.TM_GetTransferAcceptanceSummary[0].totalProductCount : null)));

				formVars.transferfiskabul_303602_percent = ReactSystemFunctions.value(this, (stateVars.TM_GetTransferAcceptanceSummary !== undefined ? (stateVars.TM_GetTransferAcceptanceSummary?.length > 0 ? stateVars.TM_GetTransferAcceptanceSummary[stateVars.TM_GetTransferAcceptanceSummary.length - 1].progressPercent : null) : (this.state.TM_GetTransferAcceptanceSummary?.length > 0 ? this.state.TM_GetTransferAcceptanceSummary[this.state.TM_GetTransferAcceptanceSummary.length - 1].progressPercent : null)));

				formVars.transferfiskabul_906419956_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetTransferAcceptanceSummary !== undefined ? (stateVars.TM_GetTransferAcceptanceSummary?.length > 0 ? stateVars.TM_GetTransferAcceptanceSummary[0].acceptedCount : null) : (this.state.TM_GetTransferAcceptanceSummary?.length > 0 ? this.state.TM_GetTransferAcceptanceSummary[0].acceptedCount : null)));

				formVars.transferfiskabul_1752305274_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetTransferAcceptanceSummary !== undefined ? (stateVars.TM_GetTransferAcceptanceSummary?.length > 0 ? stateVars.TM_GetTransferAcceptanceSummary[0].missingCount : null) : (this.state.TM_GetTransferAcceptanceSummary?.length > 0 ? this.state.TM_GetTransferAcceptanceSummary[0].missingCount : null)));

				formVars.transferfiskabul_1059519956_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetTransferAcceptanceSummary !== undefined ? (stateVars.TM_GetTransferAcceptanceSummary?.length > 0 ? stateVars.TM_GetTransferAcceptanceSummary[0].wrongProductCount : null) : (this.state.TM_GetTransferAcceptanceSummary?.length > 0 ? this.state.TM_GetTransferAcceptanceSummary[0].wrongProductCount : null)));

				formVars.transferfiskabul_1407718925_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetTransferAcceptanceSummary !== undefined ? (stateVars.TM_GetTransferAcceptanceSummary?.length > 0 ? stateVars.TM_GetTransferAcceptanceSummary[0].pendingCount : null) : (this.state.TM_GetTransferAcceptanceSummary?.length > 0 ? this.state.TM_GetTransferAcceptanceSummary[0].pendingCount : null)));


		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

            
            return isErrorOccurred;
        }







    TransferFisKabulComponent_970632_onClick = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
		KuikaAppManager.increaseServerRequestCount();

        let localVar = {
				CurrentUsername_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.getMyUsername(), "string"),
				AcceptanceStatusCode_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.convertToTypeByName("MISSING", "string"), "string"),
				AcceptanceReason_0: ReactSystemFunctions.convertToTypeByName("", "string"),
				ScannedSerialNumber_0: ReactSystemFunctions.convertToTypeByName("", "string"),
				TransferERPLineId_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, "transferfiskabul_711400_value", "transferERPLineId"), "Guid"),
				CurrentUsername_1: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.getMyUsername(), "string"),
				TransferERPHeaderId_1: ReactSystemFunctions.convertToTypeByName(this.props.screenInputs.TransferERPHeaderId ?? this.props.screenInputs.transfererpheaderid, "Guid"),
				TransferRequestHeaderId_2: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, (stateVars.TM_GetTransferAcceptanceDetail !== undefined ? (stateVars.TM_GetTransferAcceptanceDetail?.length > 0 ? stateVars.TM_GetTransferAcceptanceDetail[0].transferRequestHeaderId : null) : (this.state.TM_GetTransferAcceptanceDetail?.length > 0 ? this.state.TM_GetTransferAcceptanceDetail[0].transferRequestHeaderId : null))), "Guid")
        }

		KuikaAppManager.showSpinner(this);
		
        if (true) {
        KuikaAppManager.showSpinner(this);
        }
        let result = await KuikaAppManager.ApiRequest(this, "TransferFisKabul/TransferFisKabulComponent_970632_onClick", localVar)
        if (!KMainFunctions.IsResStatus2XX(result)) return true;

			stateVars.TM_UpdateTransferAcceptanceLine = result?.data.tM_UpdateTransferAcceptanceLine;
			stateVars.TM_GetTransferAcceptanceDetail = result?.data.tM_GetTransferAcceptanceDetail;
			
			formVars.transferfiskabul_917606_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetTransferAcceptanceDetail !== undefined ? (stateVars.TM_GetTransferAcceptanceDetail?.length > 0 ? stateVars.TM_GetTransferAcceptanceDetail[0].transferERPNumber : null) : (this.state.TM_GetTransferAcceptanceDetail?.length > 0 ? this.state.TM_GetTransferAcceptanceDetail[0].transferERPNumber : null)));
			formVars.transferfiskabul_512483_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetTransferAcceptanceDetail !== undefined ? (stateVars.TM_GetTransferAcceptanceDetail?.length > 0 ? stateVars.TM_GetTransferAcceptanceDetail[0].sourceStoreName : null) : (this.state.TM_GetTransferAcceptanceDetail?.length > 0 ? this.state.TM_GetTransferAcceptanceDetail[0].sourceStoreName : null)));
			formVars.transferfiskabul_83446_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetTransferAcceptanceDetail !== undefined ? (stateVars.TM_GetTransferAcceptanceDetail?.length > 0 ? stateVars.TM_GetTransferAcceptanceDetail[0].destinationStoreName : null) : (this.state.TM_GetTransferAcceptanceDetail?.length > 0 ? this.state.TM_GetTransferAcceptanceDetail[0].destinationStoreName : null)));
			stateVars.isComp176210Enabled = (((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, (stateVars.TM_GetTransferAcceptanceDetail !== undefined ? (stateVars.TM_GetTransferAcceptanceDetail?.length > 0 ? stateVars.TM_GetTransferAcceptanceDetail[0].canManageAcceptance : null) : (this.state.TM_GetTransferAcceptanceDetail?.length > 0 ? this.state.TM_GetTransferAcceptanceDetail[0].canManageAcceptance : null))), ReactSystemFunctions.convertToTypeByName("True", "string")) && ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, (stateVars.TM_GetTransferAcceptanceSummary !== undefined ? (stateVars.TM_GetTransferAcceptanceSummary?.length > 0 ? stateVars.TM_GetTransferAcceptanceSummary[0].pendingCount : null) : (this.state.TM_GetTransferAcceptanceSummary?.length > 0 ? this.state.TM_GetTransferAcceptanceSummary[0].pendingCount : null))), ReactSystemFunctions.convertToTypeByName("0", "string")))) === true ? "enabled" : "disabled")
			stateVars.TM_GetTransferAcceptanceSummary = result?.data.tM_GetTransferAcceptanceSummary;
			formVars.transferfiskabul_468843_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetTransferAcceptanceSummary !== undefined ? (stateVars.TM_GetTransferAcceptanceSummary?.length > 0 ? stateVars.TM_GetTransferAcceptanceSummary[0].totalProductCount : null) : (this.state.TM_GetTransferAcceptanceSummary?.length > 0 ? this.state.TM_GetTransferAcceptanceSummary[0].totalProductCount : null)));
			formVars.transferfiskabul_393217_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetTransferAcceptanceSummary !== undefined ? (stateVars.TM_GetTransferAcceptanceSummary?.length > 0 ? stateVars.TM_GetTransferAcceptanceSummary[0].checkedCount : null) : (this.state.TM_GetTransferAcceptanceSummary?.length > 0 ? this.state.TM_GetTransferAcceptanceSummary[0].checkedCount : null)));
			formVars.transferfiskabul_1925711325_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetTransferAcceptanceSummary !== undefined ? (stateVars.TM_GetTransferAcceptanceSummary?.length > 0 ? stateVars.TM_GetTransferAcceptanceSummary[0].totalProductCount : null) : (this.state.TM_GetTransferAcceptanceSummary?.length > 0 ? this.state.TM_GetTransferAcceptanceSummary[0].totalProductCount : null)));
			formVars.transferfiskabul_123938614_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetTransferAcceptanceSummary !== undefined ? (stateVars.TM_GetTransferAcceptanceSummary?.length > 0 ? stateVars.TM_GetTransferAcceptanceSummary[0].checkedCount : null) : (this.state.TM_GetTransferAcceptanceSummary?.length > 0 ? this.state.TM_GetTransferAcceptanceSummary[0].checkedCount : null)));
			formVars.transferfiskabul_1618579563_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetTransferAcceptanceSummary !== undefined ? (stateVars.TM_GetTransferAcceptanceSummary?.length > 0 ? stateVars.TM_GetTransferAcceptanceSummary[0].totalProductCount : null) : (this.state.TM_GetTransferAcceptanceSummary?.length > 0 ? this.state.TM_GetTransferAcceptanceSummary[0].totalProductCount : null)));
			formVars.transferfiskabul_303602_percent = ReactSystemFunctions.value(this, (stateVars.TM_GetTransferAcceptanceSummary !== undefined ? (stateVars.TM_GetTransferAcceptanceSummary?.length > 0 ? stateVars.TM_GetTransferAcceptanceSummary[stateVars.TM_GetTransferAcceptanceSummary.length - 1].progressPercent : null) : (this.state.TM_GetTransferAcceptanceSummary?.length > 0 ? this.state.TM_GetTransferAcceptanceSummary[this.state.TM_GetTransferAcceptanceSummary.length - 1].progressPercent : null)));
			formVars.transferfiskabul_906419956_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetTransferAcceptanceSummary !== undefined ? (stateVars.TM_GetTransferAcceptanceSummary?.length > 0 ? stateVars.TM_GetTransferAcceptanceSummary[0].acceptedCount : null) : (this.state.TM_GetTransferAcceptanceSummary?.length > 0 ? this.state.TM_GetTransferAcceptanceSummary[0].acceptedCount : null)));
			formVars.transferfiskabul_1752305274_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetTransferAcceptanceSummary !== undefined ? (stateVars.TM_GetTransferAcceptanceSummary?.length > 0 ? stateVars.TM_GetTransferAcceptanceSummary[0].missingCount : null) : (this.state.TM_GetTransferAcceptanceSummary?.length > 0 ? this.state.TM_GetTransferAcceptanceSummary[0].missingCount : null)));
			formVars.transferfiskabul_1059519956_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetTransferAcceptanceSummary !== undefined ? (stateVars.TM_GetTransferAcceptanceSummary?.length > 0 ? stateVars.TM_GetTransferAcceptanceSummary[0].wrongProductCount : null) : (this.state.TM_GetTransferAcceptanceSummary?.length > 0 ? this.state.TM_GetTransferAcceptanceSummary[0].wrongProductCount : null)));
			formVars.transferfiskabul_1407718925_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetTransferAcceptanceSummary !== undefined ? (stateVars.TM_GetTransferAcceptanceSummary?.length > 0 ? stateVars.TM_GetTransferAcceptanceSummary[0].pendingCount : null) : (this.state.TM_GetTransferAcceptanceSummary?.length > 0 ? this.state.TM_GetTransferAcceptanceSummary[0].pendingCount : null)));
			stateVars.isComp176210Enabled = (((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, (stateVars.TM_GetTransferAcceptanceDetail !== undefined ? (stateVars.TM_GetTransferAcceptanceDetail?.length > 0 ? stateVars.TM_GetTransferAcceptanceDetail[0].canManageAcceptance : null) : (this.state.TM_GetTransferAcceptanceDetail?.length > 0 ? this.state.TM_GetTransferAcceptanceDetail[0].canManageAcceptance : null))), ReactSystemFunctions.convertToTypeByName("True", "string")) && ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, (stateVars.TM_GetTransferAcceptanceSummary !== undefined ? (stateVars.TM_GetTransferAcceptanceSummary?.length > 0 ? stateVars.TM_GetTransferAcceptanceSummary[0].pendingCount : null) : (this.state.TM_GetTransferAcceptanceSummary?.length > 0 ? this.state.TM_GetTransferAcceptanceSummary[0].pendingCount : null))), ReactSystemFunctions.convertToTypeByName("0", "string")))) === true ? "enabled" : "disabled")
			this.props.form?.setFieldsValue(formVars);
			
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.TransferFisKabulComponent_970632_onClick1_();
                  resolve();
                });
          })



        
        KuikaAppManager.hideSpinner(this);
        return isErrorOccurred;
    }
		TransferFisKabulComponent_970632_onClick1_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }

				formVars.transferfiskabul_917606_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetTransferAcceptanceDetail !== undefined ? (stateVars.TM_GetTransferAcceptanceDetail?.length > 0 ? stateVars.TM_GetTransferAcceptanceDetail[0].transferERPNumber : null) : (this.state.TM_GetTransferAcceptanceDetail?.length > 0 ? this.state.TM_GetTransferAcceptanceDetail[0].transferERPNumber : null)));

				formVars.transferfiskabul_512483_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetTransferAcceptanceDetail !== undefined ? (stateVars.TM_GetTransferAcceptanceDetail?.length > 0 ? stateVars.TM_GetTransferAcceptanceDetail[0].sourceStoreName : null) : (this.state.TM_GetTransferAcceptanceDetail?.length > 0 ? this.state.TM_GetTransferAcceptanceDetail[0].sourceStoreName : null)));

				formVars.transferfiskabul_83446_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetTransferAcceptanceDetail !== undefined ? (stateVars.TM_GetTransferAcceptanceDetail?.length > 0 ? stateVars.TM_GetTransferAcceptanceDetail[0].destinationStoreName : null) : (this.state.TM_GetTransferAcceptanceDetail?.length > 0 ? this.state.TM_GetTransferAcceptanceDetail[0].destinationStoreName : null)));

				formVars.transferfiskabul_468843_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetTransferAcceptanceSummary !== undefined ? (stateVars.TM_GetTransferAcceptanceSummary?.length > 0 ? stateVars.TM_GetTransferAcceptanceSummary[0].totalProductCount : null) : (this.state.TM_GetTransferAcceptanceSummary?.length > 0 ? this.state.TM_GetTransferAcceptanceSummary[0].totalProductCount : null)));

				formVars.transferfiskabul_393217_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetTransferAcceptanceSummary !== undefined ? (stateVars.TM_GetTransferAcceptanceSummary?.length > 0 ? stateVars.TM_GetTransferAcceptanceSummary[0].checkedCount : null) : (this.state.TM_GetTransferAcceptanceSummary?.length > 0 ? this.state.TM_GetTransferAcceptanceSummary[0].checkedCount : null)));

				formVars.transferfiskabul_1925711325_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetTransferAcceptanceSummary !== undefined ? (stateVars.TM_GetTransferAcceptanceSummary?.length > 0 ? stateVars.TM_GetTransferAcceptanceSummary[0].totalProductCount : null) : (this.state.TM_GetTransferAcceptanceSummary?.length > 0 ? this.state.TM_GetTransferAcceptanceSummary[0].totalProductCount : null)));

				formVars.transferfiskabul_123938614_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetTransferAcceptanceSummary !== undefined ? (stateVars.TM_GetTransferAcceptanceSummary?.length > 0 ? stateVars.TM_GetTransferAcceptanceSummary[0].checkedCount : null) : (this.state.TM_GetTransferAcceptanceSummary?.length > 0 ? this.state.TM_GetTransferAcceptanceSummary[0].checkedCount : null)));

				formVars.transferfiskabul_1618579563_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetTransferAcceptanceSummary !== undefined ? (stateVars.TM_GetTransferAcceptanceSummary?.length > 0 ? stateVars.TM_GetTransferAcceptanceSummary[0].totalProductCount : null) : (this.state.TM_GetTransferAcceptanceSummary?.length > 0 ? this.state.TM_GetTransferAcceptanceSummary[0].totalProductCount : null)));

				formVars.transferfiskabul_303602_percent = ReactSystemFunctions.value(this, (stateVars.TM_GetTransferAcceptanceSummary !== undefined ? (stateVars.TM_GetTransferAcceptanceSummary?.length > 0 ? stateVars.TM_GetTransferAcceptanceSummary[stateVars.TM_GetTransferAcceptanceSummary.length - 1].progressPercent : null) : (this.state.TM_GetTransferAcceptanceSummary?.length > 0 ? this.state.TM_GetTransferAcceptanceSummary[this.state.TM_GetTransferAcceptanceSummary.length - 1].progressPercent : null)));

				formVars.transferfiskabul_906419956_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetTransferAcceptanceSummary !== undefined ? (stateVars.TM_GetTransferAcceptanceSummary?.length > 0 ? stateVars.TM_GetTransferAcceptanceSummary[0].acceptedCount : null) : (this.state.TM_GetTransferAcceptanceSummary?.length > 0 ? this.state.TM_GetTransferAcceptanceSummary[0].acceptedCount : null)));

				formVars.transferfiskabul_1752305274_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetTransferAcceptanceSummary !== undefined ? (stateVars.TM_GetTransferAcceptanceSummary?.length > 0 ? stateVars.TM_GetTransferAcceptanceSummary[0].missingCount : null) : (this.state.TM_GetTransferAcceptanceSummary?.length > 0 ? this.state.TM_GetTransferAcceptanceSummary[0].missingCount : null)));

				formVars.transferfiskabul_1059519956_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetTransferAcceptanceSummary !== undefined ? (stateVars.TM_GetTransferAcceptanceSummary?.length > 0 ? stateVars.TM_GetTransferAcceptanceSummary[0].wrongProductCount : null) : (this.state.TM_GetTransferAcceptanceSummary?.length > 0 ? this.state.TM_GetTransferAcceptanceSummary[0].wrongProductCount : null)));

				formVars.transferfiskabul_1407718925_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetTransferAcceptanceSummary !== undefined ? (stateVars.TM_GetTransferAcceptanceSummary?.length > 0 ? stateVars.TM_GetTransferAcceptanceSummary[0].pendingCount : null) : (this.state.TM_GetTransferAcceptanceSummary?.length > 0 ? this.state.TM_GetTransferAcceptanceSummary[0].pendingCount : null)));

				
				stateVars.dataSource_711400 = stateVars.TM_GetTransferAcceptanceDetail ?? this.state.TM_GetTransferAcceptanceDetail;

		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

            
            return isErrorOccurred;
        }




    TransferFisKabulComponent_700837_onClick = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
		KuikaAppManager.increaseServerRequestCount();

        let localVar = {
				CurrentUsername_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.getMyUsername(), "string"),
				AcceptanceStatusCode_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.convertToTypeByName("WRONG_PRODUCT", "string"), "string"),
				AcceptanceReason_0: ReactSystemFunctions.convertToTypeByName("", "string"),
				ScannedSerialNumber_0: ReactSystemFunctions.convertToTypeByName("", "string"),
				TransferERPLineId_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, "transferfiskabul_711400_value", "transferERPLineId"), "Guid"),
				CurrentUsername_1: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.getMyUsername(), "string"),
				TransferERPHeaderId_1: ReactSystemFunctions.convertToTypeByName(this.props.screenInputs.TransferERPHeaderId ?? this.props.screenInputs.transfererpheaderid, "Guid"),
				TransferRequestHeaderId_2: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, (stateVars.TM_GetTransferAcceptanceDetail !== undefined ? (stateVars.TM_GetTransferAcceptanceDetail?.length > 0 ? stateVars.TM_GetTransferAcceptanceDetail[0].transferRequestHeaderId : null) : (this.state.TM_GetTransferAcceptanceDetail?.length > 0 ? this.state.TM_GetTransferAcceptanceDetail[0].transferRequestHeaderId : null))), "Guid")
        }

		KuikaAppManager.showSpinner(this);
		
        if (true) {
        KuikaAppManager.showSpinner(this);
        }
        let result = await KuikaAppManager.ApiRequest(this, "TransferFisKabul/TransferFisKabulComponent_700837_onClick", localVar)
        if (!KMainFunctions.IsResStatus2XX(result)) return true;

			stateVars.TM_UpdateTransferAcceptanceLine = result?.data.tM_UpdateTransferAcceptanceLine;
			stateVars.TM_GetTransferAcceptanceDetail = result?.data.tM_GetTransferAcceptanceDetail;
			
			formVars.transferfiskabul_917606_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetTransferAcceptanceDetail !== undefined ? (stateVars.TM_GetTransferAcceptanceDetail?.length > 0 ? stateVars.TM_GetTransferAcceptanceDetail[0].transferERPNumber : null) : (this.state.TM_GetTransferAcceptanceDetail?.length > 0 ? this.state.TM_GetTransferAcceptanceDetail[0].transferERPNumber : null)));
			formVars.transferfiskabul_512483_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetTransferAcceptanceDetail !== undefined ? (stateVars.TM_GetTransferAcceptanceDetail?.length > 0 ? stateVars.TM_GetTransferAcceptanceDetail[0].sourceStoreName : null) : (this.state.TM_GetTransferAcceptanceDetail?.length > 0 ? this.state.TM_GetTransferAcceptanceDetail[0].sourceStoreName : null)));
			formVars.transferfiskabul_83446_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetTransferAcceptanceDetail !== undefined ? (stateVars.TM_GetTransferAcceptanceDetail?.length > 0 ? stateVars.TM_GetTransferAcceptanceDetail[0].destinationStoreName : null) : (this.state.TM_GetTransferAcceptanceDetail?.length > 0 ? this.state.TM_GetTransferAcceptanceDetail[0].destinationStoreName : null)));
			stateVars.isComp176210Enabled = (((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, (stateVars.TM_GetTransferAcceptanceDetail !== undefined ? (stateVars.TM_GetTransferAcceptanceDetail?.length > 0 ? stateVars.TM_GetTransferAcceptanceDetail[0].canManageAcceptance : null) : (this.state.TM_GetTransferAcceptanceDetail?.length > 0 ? this.state.TM_GetTransferAcceptanceDetail[0].canManageAcceptance : null))), ReactSystemFunctions.convertToTypeByName("True", "string")) && ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, (stateVars.TM_GetTransferAcceptanceSummary !== undefined ? (stateVars.TM_GetTransferAcceptanceSummary?.length > 0 ? stateVars.TM_GetTransferAcceptanceSummary[0].pendingCount : null) : (this.state.TM_GetTransferAcceptanceSummary?.length > 0 ? this.state.TM_GetTransferAcceptanceSummary[0].pendingCount : null))), ReactSystemFunctions.convertToTypeByName("0", "string")))) === true ? "enabled" : "disabled")
			stateVars.TM_GetTransferAcceptanceSummary = result?.data.tM_GetTransferAcceptanceSummary;
			formVars.transferfiskabul_468843_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetTransferAcceptanceSummary !== undefined ? (stateVars.TM_GetTransferAcceptanceSummary?.length > 0 ? stateVars.TM_GetTransferAcceptanceSummary[0].totalProductCount : null) : (this.state.TM_GetTransferAcceptanceSummary?.length > 0 ? this.state.TM_GetTransferAcceptanceSummary[0].totalProductCount : null)));
			formVars.transferfiskabul_393217_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetTransferAcceptanceSummary !== undefined ? (stateVars.TM_GetTransferAcceptanceSummary?.length > 0 ? stateVars.TM_GetTransferAcceptanceSummary[0].checkedCount : null) : (this.state.TM_GetTransferAcceptanceSummary?.length > 0 ? this.state.TM_GetTransferAcceptanceSummary[0].checkedCount : null)));
			formVars.transferfiskabul_1925711325_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetTransferAcceptanceSummary !== undefined ? (stateVars.TM_GetTransferAcceptanceSummary?.length > 0 ? stateVars.TM_GetTransferAcceptanceSummary[0].totalProductCount : null) : (this.state.TM_GetTransferAcceptanceSummary?.length > 0 ? this.state.TM_GetTransferAcceptanceSummary[0].totalProductCount : null)));
			formVars.transferfiskabul_123938614_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetTransferAcceptanceSummary !== undefined ? (stateVars.TM_GetTransferAcceptanceSummary?.length > 0 ? stateVars.TM_GetTransferAcceptanceSummary[0].checkedCount : null) : (this.state.TM_GetTransferAcceptanceSummary?.length > 0 ? this.state.TM_GetTransferAcceptanceSummary[0].checkedCount : null)));
			formVars.transferfiskabul_1618579563_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetTransferAcceptanceSummary !== undefined ? (stateVars.TM_GetTransferAcceptanceSummary?.length > 0 ? stateVars.TM_GetTransferAcceptanceSummary[0].totalProductCount : null) : (this.state.TM_GetTransferAcceptanceSummary?.length > 0 ? this.state.TM_GetTransferAcceptanceSummary[0].totalProductCount : null)));
			formVars.transferfiskabul_303602_percent = ReactSystemFunctions.value(this, (stateVars.TM_GetTransferAcceptanceSummary !== undefined ? (stateVars.TM_GetTransferAcceptanceSummary?.length > 0 ? stateVars.TM_GetTransferAcceptanceSummary[stateVars.TM_GetTransferAcceptanceSummary.length - 1].progressPercent : null) : (this.state.TM_GetTransferAcceptanceSummary?.length > 0 ? this.state.TM_GetTransferAcceptanceSummary[this.state.TM_GetTransferAcceptanceSummary.length - 1].progressPercent : null)));
			formVars.transferfiskabul_906419956_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetTransferAcceptanceSummary !== undefined ? (stateVars.TM_GetTransferAcceptanceSummary?.length > 0 ? stateVars.TM_GetTransferAcceptanceSummary[0].acceptedCount : null) : (this.state.TM_GetTransferAcceptanceSummary?.length > 0 ? this.state.TM_GetTransferAcceptanceSummary[0].acceptedCount : null)));
			formVars.transferfiskabul_1752305274_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetTransferAcceptanceSummary !== undefined ? (stateVars.TM_GetTransferAcceptanceSummary?.length > 0 ? stateVars.TM_GetTransferAcceptanceSummary[0].missingCount : null) : (this.state.TM_GetTransferAcceptanceSummary?.length > 0 ? this.state.TM_GetTransferAcceptanceSummary[0].missingCount : null)));
			formVars.transferfiskabul_1059519956_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetTransferAcceptanceSummary !== undefined ? (stateVars.TM_GetTransferAcceptanceSummary?.length > 0 ? stateVars.TM_GetTransferAcceptanceSummary[0].wrongProductCount : null) : (this.state.TM_GetTransferAcceptanceSummary?.length > 0 ? this.state.TM_GetTransferAcceptanceSummary[0].wrongProductCount : null)));
			formVars.transferfiskabul_1407718925_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetTransferAcceptanceSummary !== undefined ? (stateVars.TM_GetTransferAcceptanceSummary?.length > 0 ? stateVars.TM_GetTransferAcceptanceSummary[0].pendingCount : null) : (this.state.TM_GetTransferAcceptanceSummary?.length > 0 ? this.state.TM_GetTransferAcceptanceSummary[0].pendingCount : null)));
			stateVars.isComp176210Enabled = (((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, (stateVars.TM_GetTransferAcceptanceDetail !== undefined ? (stateVars.TM_GetTransferAcceptanceDetail?.length > 0 ? stateVars.TM_GetTransferAcceptanceDetail[0].canManageAcceptance : null) : (this.state.TM_GetTransferAcceptanceDetail?.length > 0 ? this.state.TM_GetTransferAcceptanceDetail[0].canManageAcceptance : null))), ReactSystemFunctions.convertToTypeByName("True", "string")) && ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, (stateVars.TM_GetTransferAcceptanceSummary !== undefined ? (stateVars.TM_GetTransferAcceptanceSummary?.length > 0 ? stateVars.TM_GetTransferAcceptanceSummary[0].pendingCount : null) : (this.state.TM_GetTransferAcceptanceSummary?.length > 0 ? this.state.TM_GetTransferAcceptanceSummary[0].pendingCount : null))), ReactSystemFunctions.convertToTypeByName("0", "string")))) === true ? "enabled" : "disabled")
			this.props.form?.setFieldsValue(formVars);
			
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.TransferFisKabulComponent_700837_onClick1_();
                  resolve();
                });
          })



        
        KuikaAppManager.hideSpinner(this);
        return isErrorOccurred;
    }
		TransferFisKabulComponent_700837_onClick1_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }

				formVars.transferfiskabul_917606_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetTransferAcceptanceDetail !== undefined ? (stateVars.TM_GetTransferAcceptanceDetail?.length > 0 ? stateVars.TM_GetTransferAcceptanceDetail[0].transferERPNumber : null) : (this.state.TM_GetTransferAcceptanceDetail?.length > 0 ? this.state.TM_GetTransferAcceptanceDetail[0].transferERPNumber : null)));

				formVars.transferfiskabul_512483_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetTransferAcceptanceDetail !== undefined ? (stateVars.TM_GetTransferAcceptanceDetail?.length > 0 ? stateVars.TM_GetTransferAcceptanceDetail[0].sourceStoreName : null) : (this.state.TM_GetTransferAcceptanceDetail?.length > 0 ? this.state.TM_GetTransferAcceptanceDetail[0].sourceStoreName : null)));

				formVars.transferfiskabul_83446_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetTransferAcceptanceDetail !== undefined ? (stateVars.TM_GetTransferAcceptanceDetail?.length > 0 ? stateVars.TM_GetTransferAcceptanceDetail[0].destinationStoreName : null) : (this.state.TM_GetTransferAcceptanceDetail?.length > 0 ? this.state.TM_GetTransferAcceptanceDetail[0].destinationStoreName : null)));

				formVars.transferfiskabul_468843_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetTransferAcceptanceSummary !== undefined ? (stateVars.TM_GetTransferAcceptanceSummary?.length > 0 ? stateVars.TM_GetTransferAcceptanceSummary[0].totalProductCount : null) : (this.state.TM_GetTransferAcceptanceSummary?.length > 0 ? this.state.TM_GetTransferAcceptanceSummary[0].totalProductCount : null)));

				formVars.transferfiskabul_393217_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetTransferAcceptanceSummary !== undefined ? (stateVars.TM_GetTransferAcceptanceSummary?.length > 0 ? stateVars.TM_GetTransferAcceptanceSummary[0].checkedCount : null) : (this.state.TM_GetTransferAcceptanceSummary?.length > 0 ? this.state.TM_GetTransferAcceptanceSummary[0].checkedCount : null)));

				formVars.transferfiskabul_1925711325_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetTransferAcceptanceSummary !== undefined ? (stateVars.TM_GetTransferAcceptanceSummary?.length > 0 ? stateVars.TM_GetTransferAcceptanceSummary[0].totalProductCount : null) : (this.state.TM_GetTransferAcceptanceSummary?.length > 0 ? this.state.TM_GetTransferAcceptanceSummary[0].totalProductCount : null)));

				formVars.transferfiskabul_123938614_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetTransferAcceptanceSummary !== undefined ? (stateVars.TM_GetTransferAcceptanceSummary?.length > 0 ? stateVars.TM_GetTransferAcceptanceSummary[0].checkedCount : null) : (this.state.TM_GetTransferAcceptanceSummary?.length > 0 ? this.state.TM_GetTransferAcceptanceSummary[0].checkedCount : null)));

				formVars.transferfiskabul_1618579563_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetTransferAcceptanceSummary !== undefined ? (stateVars.TM_GetTransferAcceptanceSummary?.length > 0 ? stateVars.TM_GetTransferAcceptanceSummary[0].totalProductCount : null) : (this.state.TM_GetTransferAcceptanceSummary?.length > 0 ? this.state.TM_GetTransferAcceptanceSummary[0].totalProductCount : null)));

				formVars.transferfiskabul_303602_percent = ReactSystemFunctions.value(this, (stateVars.TM_GetTransferAcceptanceSummary !== undefined ? (stateVars.TM_GetTransferAcceptanceSummary?.length > 0 ? stateVars.TM_GetTransferAcceptanceSummary[stateVars.TM_GetTransferAcceptanceSummary.length - 1].progressPercent : null) : (this.state.TM_GetTransferAcceptanceSummary?.length > 0 ? this.state.TM_GetTransferAcceptanceSummary[this.state.TM_GetTransferAcceptanceSummary.length - 1].progressPercent : null)));

				formVars.transferfiskabul_906419956_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetTransferAcceptanceSummary !== undefined ? (stateVars.TM_GetTransferAcceptanceSummary?.length > 0 ? stateVars.TM_GetTransferAcceptanceSummary[0].acceptedCount : null) : (this.state.TM_GetTransferAcceptanceSummary?.length > 0 ? this.state.TM_GetTransferAcceptanceSummary[0].acceptedCount : null)));

				formVars.transferfiskabul_1752305274_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetTransferAcceptanceSummary !== undefined ? (stateVars.TM_GetTransferAcceptanceSummary?.length > 0 ? stateVars.TM_GetTransferAcceptanceSummary[0].missingCount : null) : (this.state.TM_GetTransferAcceptanceSummary?.length > 0 ? this.state.TM_GetTransferAcceptanceSummary[0].missingCount : null)));

				formVars.transferfiskabul_1059519956_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetTransferAcceptanceSummary !== undefined ? (stateVars.TM_GetTransferAcceptanceSummary?.length > 0 ? stateVars.TM_GetTransferAcceptanceSummary[0].wrongProductCount : null) : (this.state.TM_GetTransferAcceptanceSummary?.length > 0 ? this.state.TM_GetTransferAcceptanceSummary[0].wrongProductCount : null)));

				formVars.transferfiskabul_1407718925_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetTransferAcceptanceSummary !== undefined ? (stateVars.TM_GetTransferAcceptanceSummary?.length > 0 ? stateVars.TM_GetTransferAcceptanceSummary[0].pendingCount : null) : (this.state.TM_GetTransferAcceptanceSummary?.length > 0 ? this.state.TM_GetTransferAcceptanceSummary[0].pendingCount : null)));

				
				stateVars.dataSource_711400 = stateVars.TM_GetTransferAcceptanceDetail ?? this.state.TM_GetTransferAcceptanceDetail;

		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

            
            return isErrorOccurred;
        }




    TransferFisKabulComponent_176210_onClick = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
		KuikaAppManager.increaseServerRequestCount();

        let localVar = {
				shipmentHeaderId_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, (stateVars.TM_GetTransferERPDetail !== undefined ? (stateVars.TM_GetTransferERPDetail?.length > 0 ? stateVars.TM_GetTransferERPDetail[0].nebimShipmentHeaderId : null) : (this.state.TM_GetTransferERPDetail?.length > 0 ? this.state.TM_GetTransferERPDetail[0].nebimShipmentHeaderId : null))), "string"),
				CurrentUsername_1: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.getMyUsername(), "string"),
				IsSuccess_1: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, stateVars.ApproveTransfer?.isSuccess), "number"),
				ResponseMessage_1: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, stateVars.ApproveTransfer?.responseMessage), "string"),
				ShipmentHeaderID_1: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, (stateVars.TM_GetTransferERPDetail !== undefined ? (stateVars.TM_GetTransferERPDetail?.length > 0 ? stateVars.TM_GetTransferERPDetail[0].nebimShipmentHeaderId : null) : (this.state.TM_GetTransferERPDetail?.length > 0 ? this.state.TM_GetTransferERPDetail[0].nebimShipmentHeaderId : null))), "string"),
				Request_1: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, stateVars.ApproveTransfer?.request), "string"),
				Response_1: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, stateVars.ApproveTransfer?.response), "string"),
				TransferERPHeaderId_1: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, (stateVars.TM_GetTransferERPDetail !== undefined ? (stateVars.TM_GetTransferERPDetail?.length > 0 ? stateVars.TM_GetTransferERPDetail[0].transferERPHeaderId : null) : (this.state.TM_GetTransferERPDetail?.length > 0 ? this.state.TM_GetTransferERPDetail[0].transferERPHeaderId : null))), "Guid"),
				TransferRequestHeaderId_1: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, (stateVars.TM_GetTransferERPDetail !== undefined ? (stateVars.TM_GetTransferERPDetail?.length > 0 ? stateVars.TM_GetTransferERPDetail[0].transferRequestHeaderId : null) : (this.state.TM_GetTransferERPDetail?.length > 0 ? this.state.TM_GetTransferERPDetail[0].transferRequestHeaderId : null))), "Guid"),
				TransferRequestLineId_1: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, (stateVars.TM_GetTransferERPDetail !== undefined ? (stateVars.TM_GetTransferERPDetail?.length > 0 ? stateVars.TM_GetTransferERPDetail[0].transferRequestLineId : null) : (this.state.TM_GetTransferERPDetail?.length > 0 ? this.state.TM_GetTransferERPDetail[0].transferRequestLineId : null))), "Guid")
        }

		KuikaAppManager.showSpinner(this);
		
        if (true) {
        KuikaAppManager.showSpinner(this);
        }
        let result = await KuikaAppManager.ApiRequest(this, "TransferFisKabul/TransferFisKabulComponent_176210_onClick", localVar)
        if (!KMainFunctions.IsResStatus2XX(result)) return true;

			stateVars.ApproveTransfer = result?.data.approveTransfer;
			stateVars.TM_TransferOppositeApprovalAfterSql = result?.data.tM_TransferOppositeApprovalAfterSql;
			this.props.form?.setFieldsValue(formVars);
			
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.TransferFisKabulComponent_176210_onClick1_();
                  resolve();
                });
          })



        
        KuikaAppManager.hideSpinner(this);
        return isErrorOccurred;
    }
    TransferFisKabulComponent_176210_onClick1_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
		KuikaAppManager.increaseServerRequestCount();

        let localVar = {
				CurrentUsername_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.getMyUsername(), "string"),
				TransferRequestHeaderId_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, (stateVars.TM_GetTransferAcceptanceDetail !== undefined ? (stateVars.TM_GetTransferAcceptanceDetail?.length > 0 ? stateVars.TM_GetTransferAcceptanceDetail[0].transferRequestHeaderId : null) : (this.state.TM_GetTransferAcceptanceDetail?.length > 0 ? this.state.TM_GetTransferAcceptanceDetail[0].transferRequestHeaderId : null))), "Guid")
        }

if (ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, this.state.ApproveTransfer?.isSuccess), ReactSystemFunctions.convertToTypeByName("1", "string"))) {
            		
        if (true) {
        KuikaAppManager.showSpinner(this);
        }
        let result = await KuikaAppManager.ApiRequest(this, "TransferFisKabul/TransferFisKabulComponent_176210_onClick1_", localVar)
        if (!KMainFunctions.IsResStatus2XX(result)) return true;

			stateVars.TM_CompleteTransferAcceptance = result?.data.tM_CompleteTransferAcceptance;
			this.props.form?.setFieldsValue(formVars);
			
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.TransferFisKabulComponent_176210_onClick2_();
                  resolve();
                });
          })

        } else {
            
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.TransferFisKabulComponent_176210_onClick2_();
                  resolve();
                });
          })
        }


        
        KuikaAppManager.hideSpinner(this);
        return isErrorOccurred;
    }
    TransferFisKabulComponent_176210_onClick2_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
		KuikaAppManager.increaseServerRequestCount();

        let localVar = {
				CurrentUsername_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.getMyUsername(), "string"),
				TransferERPHeaderId_0: ReactSystemFunctions.convertToTypeByName(this.props.screenInputs.TransferERPHeaderId ?? this.props.screenInputs.transfererpheaderid, "Guid")
        }

if (ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, this.state.ApproveTransfer?.isSuccess), ReactSystemFunctions.convertToTypeByName("1", "string"))) {
            		
        if (true) {
        KuikaAppManager.showSpinner(this);
        }
        let result = await KuikaAppManager.ApiRequest(this, "TransferFisKabul/TransferFisKabulComponent_176210_onClick2_", localVar)
        if (!KMainFunctions.IsResStatus2XX(result)) return true;

			stateVars.TM_GetTransferAcceptanceDetail = result?.data.tM_GetTransferAcceptanceDetail;
			
			formVars.transferfiskabul_917606_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetTransferAcceptanceDetail !== undefined ? (stateVars.TM_GetTransferAcceptanceDetail?.length > 0 ? stateVars.TM_GetTransferAcceptanceDetail[0].transferERPNumber : null) : (this.state.TM_GetTransferAcceptanceDetail?.length > 0 ? this.state.TM_GetTransferAcceptanceDetail[0].transferERPNumber : null)));
			formVars.transferfiskabul_512483_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetTransferAcceptanceDetail !== undefined ? (stateVars.TM_GetTransferAcceptanceDetail?.length > 0 ? stateVars.TM_GetTransferAcceptanceDetail[0].sourceStoreName : null) : (this.state.TM_GetTransferAcceptanceDetail?.length > 0 ? this.state.TM_GetTransferAcceptanceDetail[0].sourceStoreName : null)));
			formVars.transferfiskabul_83446_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetTransferAcceptanceDetail !== undefined ? (stateVars.TM_GetTransferAcceptanceDetail?.length > 0 ? stateVars.TM_GetTransferAcceptanceDetail[0].destinationStoreName : null) : (this.state.TM_GetTransferAcceptanceDetail?.length > 0 ? this.state.TM_GetTransferAcceptanceDetail[0].destinationStoreName : null)));
			stateVars.isComp176210Enabled = (((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, (stateVars.TM_GetTransferAcceptanceDetail !== undefined ? (stateVars.TM_GetTransferAcceptanceDetail?.length > 0 ? stateVars.TM_GetTransferAcceptanceDetail[0].canManageAcceptance : null) : (this.state.TM_GetTransferAcceptanceDetail?.length > 0 ? this.state.TM_GetTransferAcceptanceDetail[0].canManageAcceptance : null))), ReactSystemFunctions.convertToTypeByName("True", "string")) && ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, (stateVars.TM_GetTransferAcceptanceSummary !== undefined ? (stateVars.TM_GetTransferAcceptanceSummary?.length > 0 ? stateVars.TM_GetTransferAcceptanceSummary[0].pendingCount : null) : (this.state.TM_GetTransferAcceptanceSummary?.length > 0 ? this.state.TM_GetTransferAcceptanceSummary[0].pendingCount : null))), ReactSystemFunctions.convertToTypeByName("0", "string")))) === true ? "enabled" : "disabled")
			this.props.form?.setFieldsValue(formVars);
			
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.TransferFisKabulComponent_176210_onClick3_();
                  resolve();
                });
          })

        } else {
            
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.TransferFisKabulComponent_176210_onClick3_();
                  resolve();
                });
          })
        }


        
        KuikaAppManager.hideSpinner(this);
        return isErrorOccurred;
    }
		TransferFisKabulComponent_176210_onClick3_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }

				stateVars.Notify = await ReactSystemFunctions.notify(this, ReactSystemFunctions.toString(this, this.state.ApproveTransfer?.responseMessage), ReactSystemFunctions.convertToTypeByName("default", "string"), ReactSystemFunctions.convertToTypeByName("bottom-right", "string"), 3, ReactSystemFunctions.convertToTypeByName("", "string"), ReactSystemFunctions.convertToTypeByName("", "string"), 0);
				stateVars.Notify = await ReactSystemFunctions.notify(this, ReactSystemFunctions.toString(this, (stateVars.TM_CompleteTransferAcceptance !== undefined ? (stateVars.TM_CompleteTransferAcceptance?.length > 0 ? stateVars.TM_CompleteTransferAcceptance[0].message : null) : (this.state.TM_CompleteTransferAcceptance?.length > 0 ? this.state.TM_CompleteTransferAcceptance[0].message : null))), ReactSystemFunctions.convertToTypeByName("default", "string"), ReactSystemFunctions.convertToTypeByName("bottom-right", "string"), 3, ReactSystemFunctions.convertToTypeByName("", "string"), ReactSystemFunctions.convertToTypeByName("", "string"), 0);

		this.props.form?.setFieldsValue(formVars);
		
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.TransferFisKabulComponent_176210_onClick4_();
                  resolve();
                });
          })

            
            return isErrorOccurred;
        }
		TransferFisKabulComponent_176210_onClick4_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
if (ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, this.state.ApproveTransfer?.isSuccess), "1")) {
            
					KuikaAppManager.prepareForNavigation();
						KuikaAppManager.addToPageInputVariables("TransferFisiDetayi", "TransferERPHeaderId", ReactSystemFunctions.convertToTypeByName(this.props.screenInputs.TransferERPHeaderId ?? this.props.screenInputs.transfererpheaderid, "Guid"));

				stateVars.NAVIGATE = await ReactSystemFunctions.navigate(this, this.TransferFisKabulComponent_176210_onClick5_, "TransferFisKabul", "TransferFisiDetayi", "", "currentPage", null, null, null, null, null, null, true, false);

		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

        } else {
            
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.TransferFisKabulComponent_176210_onClick5_();
                  resolve();
                });
          })
        }

            
            return isErrorOccurred;
        }
		TransferFisKabulComponent_176210_onClick5_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
if (ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, this.state.ApproveTransfer?.isSuccess), "1")) {
            KuikaAppManager.showSpinner(this);

				formVars.transferfiskabul_917606_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetTransferAcceptanceDetail !== undefined ? (stateVars.TM_GetTransferAcceptanceDetail?.length > 0 ? stateVars.TM_GetTransferAcceptanceDetail[0].transferERPNumber : null) : (this.state.TM_GetTransferAcceptanceDetail?.length > 0 ? this.state.TM_GetTransferAcceptanceDetail[0].transferERPNumber : null)));


		this.props.form?.setFieldsValue(formVars);
		
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.TransferFisKabulComponent_176210_onClick6_();
                  resolve();
                });
          })

        } else {
            
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.TransferFisKabulComponent_176210_onClick6_();
                  resolve();
                });
          })
        }

            
            return isErrorOccurred;
        }
		TransferFisKabulComponent_176210_onClick6_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
if (ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, this.state.ApproveTransfer?.isSuccess), "1")) {
            
				formVars.transferfiskabul_512483_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetTransferAcceptanceDetail !== undefined ? (stateVars.TM_GetTransferAcceptanceDetail?.length > 0 ? stateVars.TM_GetTransferAcceptanceDetail[0].sourceStoreName : null) : (this.state.TM_GetTransferAcceptanceDetail?.length > 0 ? this.state.TM_GetTransferAcceptanceDetail[0].sourceStoreName : null)));


		this.props.form?.setFieldsValue(formVars);
		
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.TransferFisKabulComponent_176210_onClick7_();
                  resolve();
                });
          })

        } else {
            
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.TransferFisKabulComponent_176210_onClick7_();
                  resolve();
                });
          })
        }

            
            return isErrorOccurred;
        }
		TransferFisKabulComponent_176210_onClick7_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
if (ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, this.state.ApproveTransfer?.isSuccess), "1")) {
            
				formVars.transferfiskabul_83446_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetTransferAcceptanceDetail !== undefined ? (stateVars.TM_GetTransferAcceptanceDetail?.length > 0 ? stateVars.TM_GetTransferAcceptanceDetail[0].destinationStoreName : null) : (this.state.TM_GetTransferAcceptanceDetail?.length > 0 ? this.state.TM_GetTransferAcceptanceDetail[0].destinationStoreName : null)));


		this.props.form?.setFieldsValue(formVars);
		
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.TransferFisKabulComponent_176210_onClick8_();
                  resolve();
                });
          })

        } else {
            
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.TransferFisKabulComponent_176210_onClick8_();
                  resolve();
                });
          })
        }

            
            return isErrorOccurred;
        }
		TransferFisKabulComponent_176210_onClick8_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
if (ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, this.state.ApproveTransfer?.isSuccess), "1")) {
            
				

		this.props.form?.setFieldsValue(formVars);
		
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.TransferFisKabulComponent_176210_onClick9_();
                  resolve();
                });
          })

        } else {
            
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.TransferFisKabulComponent_176210_onClick9_();
                  resolve();
                });
          })
        }

            
            return isErrorOccurred;
        }
		TransferFisKabulComponent_176210_onClick9_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
if (ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, this.state.ApproveTransfer?.isSuccess), "1")) {
            
				stateVars.dataSource_711400 = stateVars.TM_GetTransferAcceptanceDetail ?? this.state.TM_GetTransferAcceptanceDetail;

		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

        } else {
            KuikaAppManager.hideSpinner(this);
        }

            
            return isErrorOccurred;
        }
















    async callCallbackFunction(diId: number, isFromMaster: boolean = false) {
        let isErrorOccurred = false;
		let pageInitCallerNavDiIDs = [] as number[];
		if (isFromMaster || pageInitCallerNavDiIDs.indexOf(diId) > -1) {
			await this.TransferFisKabulPageInit();
		}

    }


}
