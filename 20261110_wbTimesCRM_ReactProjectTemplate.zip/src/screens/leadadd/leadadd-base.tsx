import React from "react";
import Axios, { AxiosResponse } from "axios";
import { KuikaAppManager } from "../../shared/utilty/kuika-app-manager";
import { ReactSystemFunctions } from "../../shared/utilty/react-system-functions";
import { KNavigator } from "../../shared/hoc/with-history";
import { KContext } from "../../shared/hoc/with-context";
import { useLocation } from "react-router-dom";
import { FormInstance } from "antd/es/form";
import { Guid } from "guid-typescript";
import Swal from "sweetalert2";
import { KMainFunctions } from "../../shared/utilty/main-functions";
import moment from "moment";
import { IValidationData } from "../../models/dto/validation-data";
import { IStripePayment } from "../../models/dto/stripe-payment";
import { IUserInfoDto } from "../../models/dto/user-info.dto";
import { UserService } from "../../services/user-service";
import { kuikaCoreWasmBridgeService } from "../../services/_singletons";
import _ from "lodash";
import mqtt, { MqttClient } from "mqtt";
import { IMqttResult } from "../../models/dto/mqtt.dto";
import { MasterScreen_ScreenContext } from "../masterscreen/masterscreen-context";

declare let window: any;

export interface ILeadAdd_ScreenProps {
  navigator: KNavigator;
  form: FormInstance<any>;
  googleLogin: any;
  screenInputs: any;
  context: KContext;
  initialValues: any;
  children: any;
}

export interface ILeadAdd_ScreenState {
    isSpinnerVisible: boolean;
    isPageVisible: boolean;
	isLeftMenuVisible: boolean;
    spinnerCount: number;
    selectedLanguage: string;
    isPageInitLoaded: false;
    isPageRecurringLoaded: false;
	GoBack: any;
	GoBack_dummy: any;
	TM_CreateLead: any[];
	TM_CreateLead_dummy: any[];
	Notify: boolean;
	Notify_dummy: boolean;
	NAVIGATE: any;
	NAVIGATE_dummy: any;
	TM_GetProductBrand: any[];
	TM_GetProductBrand_dummy: any[];
	TS_GetStoreUsers: any[];
	TS_GetStoreUsers_dummy: any[];
	GetKUserById: any[];
	GetKUserById_dummy: any[];
	TM_GetCustomerByName: any[];
	TM_GetCustomerByName_dummy: any[];
	TM_GetLeadStatus: any[];
	TM_GetLeadStatus_dummy: any[];
	TM_StoreGetList: any[];
	TM_StoreGetList_dummy: any[];
	GetSalesPersonByStore: any[];
	GetSalesPersonByStore_dummy: any[];
	TM_GetLeadNextSteps: any[];
	TM_GetLeadNextSteps_dummy: any[];
	TM_GetAllContactSource: any[];
	TM_GetAllContactSource_dummy: any[];
	TM_LeadAltModelTemp_GenerateSessionCode: any[];
	TM_LeadAltModelTemp_GenerateSessionCode_dummy: any[];
	TM_GetProductBrandAlternatif: any[];
	TM_GetProductBrandAlternatif_dummy: any[];
	TM_GetCustomerByIdAddLead: any[];
	TM_GetCustomerByIdAddLead_dummy: any[];
	TM_GetCustomerById: any[];
	TM_GetCustomerById_dummy: any[];
	TM_GetReferanceByCurrAccCode: any[];
	TM_GetReferanceByCurrAccCode_dummy: any[];
	TM_GetReferenceCustomerById: any[];
	TM_GetReferenceCustomerById_dummy: any[];
	TM_GetProductReferance: any[];
	TM_GetProductReferance_dummy: any[];
	SetValueOf: any;
	SetValueOf_dummy: any;
	ChangeVisibilityOf: string;
	ChangeVisibilityOf_dummy: string;
	TM_GetProductDial: any[];
	TM_GetProductDial_dummy: any[];
	TM_GetProductBracelet: any[];
	TM_GetProductBracelet_dummy: any[];
	TM_GetProduct: any[];
	TM_GetProduct_dummy: any[];
	TM_LeadCheckCustomerProduct: any[];
	TM_LeadCheckCustomerProduct_dummy: any[];
	TM_LeadAltModelTemp_ListBySession: any[];
	TM_LeadAltModelTemp_ListBySession_dummy: any[];
	TM_GetProductReferanceAlternatif: any[];
	TM_GetProductReferanceAlternatif_dummy: any[];
	TM_GetProductDialAlternatif: any[];
	TM_GetProductDialAlternatif_dummy: any[];
	TM_GetProductBraceletAlternatif: any[];
	TM_GetProductBraceletAlternatif_dummy: any[];
	TM_GetProductForAltModel: any[];
	TM_GetProductForAltModel_dummy: any[];
	TM_LeadAltModelTemp_Insert: any[];
	TM_LeadAltModelTemp_Insert_dummy: any[];
	TM_LeadAltModelTemp_Delete: any[];
	TM_LeadAltModelTemp_Delete_dummy: any[];
	isComp528620Visible: 'visible' | 'hidden';
	isComp542957Visible: 'visible' | 'hidden';
	isComp124116Visible: 'visible' | 'hidden';
	isComp260108Visible: 'visible' | 'hidden';
	isComp703665Visible: 'visible' | 'hidden';
	isComp639898Visible: 'visible' | 'hidden';
	isComp910984Visible: 'visible' | 'hidden';
	isComp513936Visible: 'visible' | 'hidden';
	isComp366434Visible: 'visible' | 'hidden';
	isComp683308Visible: 'visible' | 'hidden';
	isComp315555Visible: 'visible' | 'hidden';
	isComp630051Visible: 'visible' | 'hidden';
	isComp205465Visible: 'visible' | 'hidden';
	isComp875547Visible: 'visible' | 'hidden';
	isComp36755Visible: 'visible' | 'hidden';
	isComp561793Visible: 'visible' | 'hidden';
	isComp357309Visible: 'visible' | 'hidden';
	isComp907885Visible: 'visible' | 'hidden';
	isComp498343Visible: 'visible' | 'hidden';
	isComp575180Visible: 'visible' | 'hidden';
	isComp624657Visible: 'visible' | 'hidden';
	isComp690321Visible: 'visible' | 'hidden';
	isComp283519Visible: 'visible' | 'hidden';

}

export class LeadAdd_ScreenBase extends React.PureComponent<ILeadAdd_ScreenProps, any> {
    static contextType = MasterScreen_ScreenContext;
    declare context: React.ContextType<typeof MasterScreen_ScreenContext>;
	leadadd_8232_value_kuikaAutoCompleteRef: React.RefObject<any>;
	leadadd_572982_value_kuikaAutoCompleteRef: React.RefObject<any>;
	leadadd_999965_value_kuikaAutoCompleteRef: React.RefObject<any>;
	leadadd_931332_value_kuikaAutoCompleteRef: React.RefObject<any>;
	leadadd_468567_value_kuikaAutoCompleteRef: React.RefObject<any>;
	leadadd_984_value_kuikaAutoCompleteRef: React.RefObject<any>;
	leadadd_340910_value_kuikaAutoCompleteRef: React.RefObject<any>;
	leadadd_4804_value_kuikaAutoCompleteRef: React.RefObject<any>;
	leadadd_964461_value_kuikaAutoCompleteRef: React.RefObject<any>;
	leadadd_680481_value_kuikaAutoCompleteRef: React.RefObject<any>;
	leadadd_748311_value_kuikaAutoCompleteRef: React.RefObject<any>;
	leadadd_228188_value_kuikaAutoCompleteRef: React.RefObject<any>;
	leadadd_622242_value_kuikaAutoCompleteRef: React.RefObject<any>;
	leadadd_174761_value_kuikaAutoCompleteRef: React.RefObject<any>;
	leadadd_273530_value_kuikaAutoCompleteRef: React.RefObject<any>;
	leadadd_674923_value_kuikaTableRef: React.RefObject<any>;
    ml=[{"Id":"d5a61d2b-bd60-485f-86e2-661e9ed4e486","Name":"en_US","ShortName":"English","IsDefault":true,"LanguagePhrases":[]},{"Id":"a0f52a23-4f9f-4dfb-ae71-6c359335d460","Name":"FixedValues","ShortName":"FixedValues","LanguagePhrases":[{"Id":357364,"PropertyName":"label","Value":"Vazgeç"},{"Id":795234,"PropertyName":"label","Value":"Oluştur"},{"Id":356299,"PropertyName":"value","Value":"Talep Oluştur"},{"Id":409623,"PropertyName":"value","Value":"Yeni ürün talebi oluşturunuz."},{"Id":842208,"PropertyName":"value","Value":"Ürün Talebi"},{"Id":117846,"PropertyName":"value","Value":"Açılan Mağaza"},{"Id":8232,"PropertyName":"placeholder","Value":"Açılan Mağazayı Seçiniz..."},{"Id":717797,"PropertyName":"value","Value":"Satış Personeli"},{"Id":572982,"PropertyName":"placeholder","Value":"Satış Personeli Seçiniz..."},{"Id":955907,"PropertyName":"value","Value":"Müşteri"},{"Id":999965,"PropertyName":"placeholder","Value":"Müşteri Seçiniz..."},{"Id":471429,"PropertyName":"label","Value":"Hızlı Müşteri Oluştur"},{"Id":469991,"PropertyName":"value","Value":"Müşteri Bilgileri"},{"Id":128369,"PropertyName":"value","Value":"Müşteri Adı"},{"Id":374082,"PropertyName":"value","Value":"TC"},{"Id":742668,"PropertyName":"value","Value":"Telefon No"},{"Id":84281,"PropertyName":"value","Value":"E-mail"},{"Id":636915,"PropertyName":"value","Value":"Lokasyon"},{"Id":808974,"PropertyName":"value","Value":"Alışveriş Var Mı?"},{"Id":315555,"PropertyName":"value","Value":"Var"},{"Id":630051,"PropertyName":"value","Value":"Yok"},{"Id":841865,"PropertyName":"value","Value":"Referans(Varsa)"},{"Id":931332,"PropertyName":"placeholder","Value":"Referans Seçiniz..."},{"Id":407641,"PropertyName":"label","Value":"Hızlı Referans Oluştur"},{"Id":828382,"PropertyName":"value","Value":"Referans Bilgileri"},{"Id":952706,"PropertyName":"value","Value":"Referans Adı"},{"Id":768576,"PropertyName":"value","Value":"Referans Soyadı"},{"Id":569464,"PropertyName":"value","Value":"TC / Pasaport No"},{"Id":782414,"PropertyName":"value","Value":"Telefon"},{"Id":803677,"PropertyName":"value","Value":"Marka"},{"Id":468567,"PropertyName":"placeholder","Value":"Marka"},{"Id":915901,"PropertyName":"value","Value":"Referans"},{"Id":984,"PropertyName":"placeholder","Value":"Referans"},{"Id":635278,"PropertyName":"value","Value":"Kadran"},{"Id":340910,"PropertyName":"placeholder","Value":"Kadran"},{"Id":340433,"PropertyName":"value","Value":"Bilezik"},{"Id":4804,"PropertyName":"placeholder","Value":"Bilezik"},{"Id":347401,"PropertyName":"value","Value":"Ürün Bilgileri"},{"Id":149286,"PropertyName":"value","Value":"Ürün Adı"},{"Id":402688,"PropertyName":"value","Value":"Kategori"},{"Id":575180,"PropertyName":"value","Value":"DEFAULT"},{"Id":834243,"PropertyName":"value","Value":"Lead Durumu"},{"Id":964461,"PropertyName":"placeholder","Value":"Lead Durumu"},{"Id":989904,"PropertyName":"value","Value":"Sonraki Adım"},{"Id":680481,"PropertyName":"placeholder","Value":"Sonraki Adım"},{"Id":800892,"PropertyName":"value","Value":"İletişim Kaynağı"},{"Id":748311,"PropertyName":"placeholder","Value":"İletişim Kaynağı Seçiniz"},{"Id":807665,"PropertyName":"value","Value":"Talep Notu"},{"Id":10950,"PropertyName":"placeholder","Value":"Talep Notu"},{"Id":939924,"PropertyName":"value","Value":"Alternatif Model Öner"},{"Id":584123,"PropertyName":"value","Value":"Marka"},{"Id":228188,"PropertyName":"placeholder","Value":"Marka"},{"Id":585710,"PropertyName":"value","Value":"Referans"},{"Id":622242,"PropertyName":"placeholder","Value":"Referans"},{"Id":766760,"PropertyName":"value","Value":"Kadran"},{"Id":174761,"PropertyName":"placeholder","Value":"Kadran"},{"Id":488827,"PropertyName":"value","Value":"Bilezik"},{"Id":273530,"PropertyName":"placeholder","Value":"Bilezik"},{"Id":281129,"PropertyName":"label","Value":"Ekle"},{"Id":954161,"PropertyName":"value","Value":"Sunulan Alternatif Modelller"},{"Id":284203,"PropertyName":"title","Value":"Ürün Adı"},{"Id":493578,"PropertyName":"value","Value":"[datafield:productname]"},{"Id":844100,"PropertyName":"title","Value":"Kategori"},{"Id":624657,"PropertyName":"value","Value":"[datafield:categoryname]"},{"Id":690321,"PropertyName":"value","Value":"DEFAULT"},{"Id":513887,"PropertyName":"value","Value":"Dikkat! Açık Talep Mevcut"},{"Id":954883,"PropertyName":"value","Value":"Bu müşterinin aynı ürün için açık bir talebi bulunmaktadır. Devam etmeden önce lütfen kontrol ediniz."}]}]
    defaultML = "en_US"
    
    screenHash = ""
    

    private _prevMasterPageInitLoaded: boolean = false;
    private _prevMasterPageRecurringLoaded: boolean = false;
    private _prevShouldTriggerPageInit: boolean = false;
    constructor(props) {
        super(props);
		this.leadadd_8232_value_kuikaAutoCompleteRef = React.createRef();
		this.leadadd_572982_value_kuikaAutoCompleteRef = React.createRef();
		this.leadadd_999965_value_kuikaAutoCompleteRef = React.createRef();
		this.leadadd_931332_value_kuikaAutoCompleteRef = React.createRef();
		this.leadadd_468567_value_kuikaAutoCompleteRef = React.createRef();
		this.leadadd_984_value_kuikaAutoCompleteRef = React.createRef();
		this.leadadd_340910_value_kuikaAutoCompleteRef = React.createRef();
		this.leadadd_4804_value_kuikaAutoCompleteRef = React.createRef();
		this.leadadd_964461_value_kuikaAutoCompleteRef = React.createRef();
		this.leadadd_680481_value_kuikaAutoCompleteRef = React.createRef();
		this.leadadd_748311_value_kuikaAutoCompleteRef = React.createRef();
		this.leadadd_228188_value_kuikaAutoCompleteRef = React.createRef();
		this.leadadd_622242_value_kuikaAutoCompleteRef = React.createRef();
		this.leadadd_174761_value_kuikaAutoCompleteRef = React.createRef();
		this.leadadd_273530_value_kuikaAutoCompleteRef = React.createRef();
		this.leadadd_674923_value_kuikaTableRef = React.createRef();

        this.state = {
            isSpinnerVisible: false,
            isPageVisible: false,
            isLeftMenuVisible: false,
            spinnerCount: 0,
            selectedLanguage: "",
            isPageInitLoaded: false,
            isPageRecurringLoaded: false,
            	        GoBack: "",
	        TM_CreateLead: [],
	        Notify: false,
	        NAVIGATE: "",
	        TM_GetProductBrand: [],
	        TS_GetStoreUsers: [],
	        GetKUserById: [],
	        TM_GetCustomerByName: [],
	        TM_GetLeadStatus: [],
	        TM_StoreGetList: [],
	        GetSalesPersonByStore: [],
	        TM_GetLeadNextSteps: [],
	        TM_GetAllContactSource: [],
	        TM_LeadAltModelTemp_GenerateSessionCode: [],
	        TM_GetProductBrandAlternatif: [],
	        TM_GetCustomerByIdAddLead: [],
	        TM_GetCustomerById: [],
	        TM_GetReferanceByCurrAccCode: [],
	        TM_GetReferenceCustomerById: [],
	        TM_GetProductReferance: [],
	        SetValueOf: "",
	        ChangeVisibilityOf: "",
	        TM_GetProductDial: [],
	        TM_GetProductBracelet: [],
	        TM_GetProduct: [],
	        TM_LeadCheckCustomerProduct: [],
	        TM_LeadAltModelTemp_ListBySession: [],
	        TM_GetProductReferanceAlternatif: [],
	        TM_GetProductDialAlternatif: [],
	        TM_GetProductBraceletAlternatif: [],
	        TM_GetProductForAltModel: [],
	        TM_LeadAltModelTemp_Insert: [],
	        TM_LeadAltModelTemp_Delete: [],
	        isComp528620Visible: 'hidden',
	        isComp542957Visible: 'hidden',
	        isComp124116Visible: 'visible',
	        isComp260108Visible: 'hidden',
	        isComp703665Visible: 'hidden',
	        isComp639898Visible: 'hidden',
	        isComp910984Visible: 'hidden',
	        isComp513936Visible: 'hidden',
	        isComp366434Visible: 'hidden',
	        isComp683308Visible: 'hidden',
	        isComp315555Visible: 'hidden',
	        isComp630051Visible: 'hidden',
	        isComp205465Visible: 'hidden',
	        isComp875547Visible: 'hidden',
	        isComp36755Visible: 'hidden',
	        isComp561793Visible: 'hidden',
	        isComp357309Visible: 'hidden',
	        isComp907885Visible: 'hidden',
	        isComp498343Visible: 'hidden',
	        isComp575180Visible: 'hidden',
	        isComp624657Visible: 'hidden',
	        isComp690321Visible: 'hidden',
	        isComp283519Visible: 'hidden',

        }

        this.CheckPageAuthorization(this.state);

        
    }

    async componentDidMount() {

        if (KuikaAppManager.isPageInitPrevented()) {
            KuikaAppManager.calculateAndSetBodyHeight("leadadd", "masterscreen_screen");
            return;
        }
        this.context.registerCallbackFunction(this.callCallbackFunction.bind(this));
        
        ReactSystemFunctions.validateToken()
        this.fillFormInitValues();
        if (false){
            await this.LeadAddPageInit();
        } else if (this.context?.isMasterPageInitLoaded) { this._prevMasterPageInitLoaded = true; await this.LeadAddPageInit(); }
        
        
        
        KuikaAppManager.calculateAndSetBodyHeight("leadadd", "masterscreen_screen");

        if (ReactSystemFunctions.getIsMicroApp() === false) {
           window.parentScreen = this;
        }
    }

    componentWillUnmount() {
        
        
        

        if (ReactSystemFunctions.getIsMicroApp() === false) {
           window.parentScreen = null;
        }
    }

    
              CheckPageAuthorization = async (state) => {
                KuikaAppManager.showSpinner(this);
                if (_.isEmpty(window.userInfo)) {
                  await UserService.GetUserInfoForce();
                }
                const permittedRoleNames: string[] = ["TimesYonetici","TimesUstYonetici","TimesSatisPersoneli","TimesMagazaMuduru",];
                const userInfo = window.userInfo as IUserInfoDto;
                const userRoleNames = userInfo.roles.map((role) => role.name);
                if (!ReactSystemFunctions.hasAnyRoleName(permittedRoleNames, userRoleNames)) {
                  await ReactSystemFunctions.goBack(this);

                  const language = localStorage.getItem("ml");
                  let permissonErrorMessageText = "You do not have permission to access this page.";
                  if (language === "tr_TR") {
                    permissonErrorMessageText = "Bu sayfaya erişim yetkiniz yok.";
                  } else if (language === "fr_FR") {
                    permissonErrorMessageText = "Vous n'avez pas la permission d'accéder à cette page.";
                  } else if (language === "de_DE") {
                    permissonErrorMessageText = "Sie haben keine Berechtigung, auf diese Seite zuzugreifen.";
                  } else if (language === "es_ES") {
                    permissonErrorMessageText = "No tienes permiso para acceder a esta página.";
                  }

                  KMainFunctions.displayErrorNotification(permissonErrorMessageText);
                  state.isPageVisible = false;
                  KuikaAppManager.hideSpinner(this);
                  return;
                }
                state.isPageVisible = true;
                KuikaAppManager.hideSpinner(this);
              };
        

        
    componentDidUpdate= async (prevProps, prevState) => {
		KuikaAppManager.calculateAndSetBodyHeight("leadadd", "masterscreen_screen"    );
        if (prevProps?.location?.search !== (this.props as any)?.location?.search) {
			await this.LeadAddPageInit();
		}

        		if (this._prevMasterPageInitLoaded !== this.context.isMasterPageInitLoaded && this.context.isMasterPageInitLoaded === true) {this._prevMasterPageInitLoaded = this.context.isMasterPageInitLoaded;await this.LeadAddPageInit()}


        if (ReactSystemFunctions.getIsMicroApp() === false) {
            for (const key in prevState) {
                if (key.startsWith('NavVisible') && prevState[key] === true && this.state[key] === false) {
                    window.parentScreen = this;
                    break;
                }
            }
        }
	}

    fillFormInitValues() {
        this.props.form?.setFieldsValue({
leadadd_999965_value: this.state.TM_GetCustomerByIdAddLead?.at?.(0)?.id ?? undefined
});

    }

      setPageInitLoaded = (value: boolean) => {
        this.setState({ isPageInitLoaded: value });
      }

      setPageRecurringLoaded = (value: boolean) => {
        this.setState({ isPageRecurringLoaded: value });
      }

      clearFieldValidation = (changedValues: any) => {
        const fieldName = Object.keys(changedValues)[0];
        if (fieldName) {
          this.props.form?.setFields([
            {
              name: fieldName,
              errors: []
            }
          ]);
        }
      };

      

    LeadAddPageInit = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


	if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }

        let localVar = {
			KUserId_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.getMyUserId(), "Guid"),
			KUserId_1: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.getMyUserId(), "Guid"),
			Id_2: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.getMyUserId(), "Guid"),
			StoreId_6: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, (stateVars.TS_GetStoreUsers !== undefined ? (stateVars.TS_GetStoreUsers?.length > 0 ? stateVars.TS_GetStoreUsers[0].storeID : null) : (this.state.TS_GetStoreUsers?.length > 0 ? this.state.TS_GetStoreUsers[0].storeID : null))), "Guid"),
			KUserId_10: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.getMyUserId(), "Guid"),
			Id_11: ReactSystemFunctions.convertToTypeByName(this.props.screenInputs.CustomerId ?? this.props.screenInputs.customerid, "Guid"),
			CustomerId_12: ReactSystemFunctions.convertToTypeByName(this.props.screenInputs.CustomerId ?? this.props.screenInputs.customerid, "Guid")
        }

	KuikaAppManager.showSpinner(this);
	
        if (true) {
        KuikaAppManager.showSpinner(this);
        }
        let result = await KuikaAppManager.ApiRequest(this, "LeadAdd/LeadAddPageInit", localVar)
        if (!KMainFunctions.IsResStatus2XX(result)) return true;

		stateVars.TM_GetProductBrand = result?.data.tM_GetProductBrand;
		
		formVars.leadadd_468567_options = stateVars.TM_GetProductBrand;
		stateVars.TS_GetStoreUsers = result?.data.tS_GetStoreUsers;
		stateVars.GetKUserById = result?.data.getKUserById;
		stateVars.TM_GetCustomerByName = result?.data.tM_GetCustomerByName;
		
		formVars.leadadd_999965_value = (stateVars.TM_GetCustomerByIdAddLead !== undefined ? (stateVars.TM_GetCustomerByIdAddLead?.length > 0 ? stateVars.TM_GetCustomerByIdAddLead[0].id : null) : (this.state.TM_GetCustomerByIdAddLead?.length > 0 ? this.state.TM_GetCustomerByIdAddLead[0].id : null));
		formVars.leadadd_999965_options = stateVars.TM_GetCustomerByName;
		stateVars.TM_GetLeadStatus = result?.data.tM_GetLeadStatus;
		
		formVars.leadadd_964461_options = stateVars.TM_GetLeadStatus;
		stateVars.TM_StoreGetList = result?.data.tM_StoreGetList;
		
		formVars.leadadd_8232_options = stateVars.TM_StoreGetList;
		stateVars.GetSalesPersonByStore = result?.data.getSalesPersonByStore;
		
		formVars.leadadd_572982_options = stateVars.GetSalesPersonByStore;
		stateVars.TM_GetLeadNextSteps = result?.data.tM_GetLeadNextSteps;
		
		formVars.leadadd_680481_options = stateVars.TM_GetLeadNextSteps;
		stateVars.TM_GetAllContactSource = result?.data.tM_GetAllContactSource;
		
		formVars.leadadd_748311_options = stateVars.TM_GetAllContactSource;
		stateVars.TM_LeadAltModelTemp_GenerateSessionCode = result?.data.tM_LeadAltModelTemp_GenerateSessionCode;
		stateVars.TM_GetProductBrandAlternatif = result?.data.tM_GetProductBrandAlternatif;
		
		formVars.leadadd_228188_options = stateVars.TM_GetProductBrandAlternatif;
		stateVars.TM_GetCustomerByIdAddLead = result?.data.tM_GetCustomerByIdAddLead;
		formVars.leadadd_999965_value = (stateVars.TM_GetCustomerByIdAddLead !== undefined ? (stateVars.TM_GetCustomerByIdAddLead?.length > 0 ? stateVars.TM_GetCustomerByIdAddLead[0].id : null) : (this.state.TM_GetCustomerByIdAddLead?.length > 0 ? this.state.TM_GetCustomerByIdAddLead[0].id : null));
		formVars.leadadd_999965_options = stateVars.TM_GetCustomerByName;
		stateVars.TM_GetCustomerById = result?.data.tM_GetCustomerById;
		formVars.leadadd_410287_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetCustomerById !== undefined ? (stateVars.TM_GetCustomerById?.length > 0 ? stateVars.TM_GetCustomerById[0].adSoyad : null) : (this.state.TM_GetCustomerById?.length > 0 ? this.state.TM_GetCustomerById[0].adSoyad : null)));
		formVars.leadadd_683308_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetCustomerById !== undefined ? (stateVars.TM_GetCustomerById?.length > 0 ? stateVars.TM_GetCustomerById[0].tcKimlikNo : null) : (this.state.TM_GetCustomerById?.length > 0 ? this.state.TM_GetCustomerById[0].tcKimlikNo : null)));
		formVars.leadadd_381076_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetCustomerById !== undefined ? (stateVars.TM_GetCustomerById?.length > 0 ? stateVars.TM_GetCustomerById[0].telefonNo : null) : (this.state.TM_GetCustomerById?.length > 0 ? this.state.TM_GetCustomerById[0].telefonNo : null)));
		formVars.leadadd_496941_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetCustomerById !== undefined ? (stateVars.TM_GetCustomerById?.length > 0 ? stateVars.TM_GetCustomerById[0].email : null) : (this.state.TM_GetCustomerById?.length > 0 ? this.state.TM_GetCustomerById[0].email : null)));
		formVars.leadadd_826540_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetCustomerById !== undefined ? (stateVars.TM_GetCustomerById?.length > 0 ? stateVars.TM_GetCustomerById[0].sehir : null) : (this.state.TM_GetCustomerById?.length > 0 ? this.state.TM_GetCustomerById[0].sehir : null)));
		stateVars.isComp683308Visible = ((ReactSystemFunctions.isNotEmpty(ReactSystemFunctions.toString(this, (stateVars.TM_GetCustomerById !== undefined ? (stateVars.TM_GetCustomerById?.length > 0 ? stateVars.TM_GetCustomerById[0].tcKimlikNo : null) : (this.state.TM_GetCustomerById?.length > 0 ? this.state.TM_GetCustomerById[0].tcKimlikNo : null))), ReactSystemFunctions.convertToTypeByName("True", "string"))) === true ? "visible" : "hidden")
		stateVars.isComp315555Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, (stateVars.TM_GetCustomerById !== undefined ? (stateVars.TM_GetCustomerById?.length > 0 ? stateVars.TM_GetCustomerById[0].isShopping : null) : (this.state.TM_GetCustomerById?.length > 0 ? this.state.TM_GetCustomerById[0].isShopping : null))), ReactSystemFunctions.convertToTypeByName("True", "string"))) === true ? "visible" : "hidden")
		stateVars.isComp630051Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, (stateVars.TM_GetCustomerById !== undefined ? (stateVars.TM_GetCustomerById?.length > 0 ? stateVars.TM_GetCustomerById[0].isShopping : null) : (this.state.TM_GetCustomerById?.length > 0 ? this.state.TM_GetCustomerById[0].isShopping : null))), ReactSystemFunctions.convertToTypeByName("False", "string"))) === true ? "visible" : "hidden")
		this.props.form?.setFieldsValue(formVars);
		
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.LeadAddPageInit1_();
                  resolve();
                });
          })



        
        KuikaAppManager.hideSpinner(this);
        return isErrorOccurred;
    }
	LeadAddPageInit1_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


	if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }

			stateVars.isComp703665Visible = (((ReactSystemFunctions.contains(ReactSystemFunctions.getMyRoleNames(), ReactSystemFunctions.convertToTypeByName("TimesUstYonetici", "string")) || ReactSystemFunctions.contains(ReactSystemFunctions.getMyRoleNames(), ReactSystemFunctions.convertToTypeByName("TimesYonetici", "string")))) === true ? "visible" : "hidden")
			
			stateVars.dataSource_8232 = stateVars.TM_StoreGetList ?? this.state.TM_StoreGetList;
			stateVars.dataSource_8232 = stateVars.TM_StoreGetList ?? this.state.TM_StoreGetList;
			stateVars.isComp639898Visible = (((ReactSystemFunctions.contains(ReactSystemFunctions.getMyRoleNames(), ReactSystemFunctions.convertToTypeByName("TimesUstYonetici", "string")) || ReactSystemFunctions.contains(ReactSystemFunctions.getMyRoleNames(), ReactSystemFunctions.convertToTypeByName("TimesMagazaMuduru", "string")))) === true ? "visible" : "hidden")
			
			stateVars.dataSource_572982 = stateVars.GetSalesPersonByStore ?? this.state.GetSalesPersonByStore;
			stateVars.dataSource_572982 = stateVars.GetSalesPersonByStore ?? this.state.GetSalesPersonByStore;
			formVars.leadadd_999965_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetCustomerByIdAddLead !== undefined ? (stateVars.TM_GetCustomerByIdAddLead?.length > 0 ? stateVars.TM_GetCustomerByIdAddLead[0].id : null) : (this.state.TM_GetCustomerByIdAddLead?.length > 0 ? this.state.TM_GetCustomerByIdAddLead[0].id : null)));

			
			stateVars.dataSource_999965 = stateVars.TM_GetCustomerByName ?? this.state.TM_GetCustomerByName;
			stateVars.dataSource_999965 = stateVars.TM_GetCustomerByName ?? this.state.TM_GetCustomerByName;
			stateVars.isComp910984Visible = ((ReactSystemFunctions.isNotEmpty(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "leadadd_999965_value", "value", "TM_GetCustomerByName", "id", "id")), ReactSystemFunctions.convertToTypeByName("True", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp513936Visible = ((ReactSystemFunctions.isNotEmpty(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "leadadd_999965_value", "value", "TM_GetCustomerByName", "id", "id")), ReactSystemFunctions.convertToTypeByName("True", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp366434Visible = ((ReactSystemFunctions.isNotEmpty(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "leadadd_999965_value", "value", "TM_GetCustomerByName", "id", "id")), ReactSystemFunctions.convertToTypeByName("True", "string"))) === true ? "visible" : "hidden")
			formVars.leadadd_410287_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetCustomerById !== undefined ? (stateVars.TM_GetCustomerById?.length > 0 ? stateVars.TM_GetCustomerById[0].adSoyad : null) : (this.state.TM_GetCustomerById?.length > 0 ? this.state.TM_GetCustomerById[0].adSoyad : null)));

			formVars.leadadd_683308_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetCustomerById !== undefined ? (stateVars.TM_GetCustomerById?.length > 0 ? stateVars.TM_GetCustomerById[0].tcKimlikNo : null) : (this.state.TM_GetCustomerById?.length > 0 ? this.state.TM_GetCustomerById[0].tcKimlikNo : null)));

			stateVars.isComp683308Visible = ((ReactSystemFunctions.isNotEmpty(ReactSystemFunctions.toString(this, (stateVars.TM_GetCustomerById !== undefined ? (stateVars.TM_GetCustomerById?.length > 0 ? stateVars.TM_GetCustomerById[0].tcKimlikNo : null) : (this.state.TM_GetCustomerById?.length > 0 ? this.state.TM_GetCustomerById[0].tcKimlikNo : null))), ReactSystemFunctions.convertToTypeByName("True", "string"))) === true ? "visible" : "hidden")
			formVars.leadadd_381076_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetCustomerById !== undefined ? (stateVars.TM_GetCustomerById?.length > 0 ? stateVars.TM_GetCustomerById[0].telefonNo : null) : (this.state.TM_GetCustomerById?.length > 0 ? this.state.TM_GetCustomerById[0].telefonNo : null)));

			formVars.leadadd_496941_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetCustomerById !== undefined ? (stateVars.TM_GetCustomerById?.length > 0 ? stateVars.TM_GetCustomerById[0].email : null) : (this.state.TM_GetCustomerById?.length > 0 ? this.state.TM_GetCustomerById[0].email : null)));

			formVars.leadadd_826540_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetCustomerById !== undefined ? (stateVars.TM_GetCustomerById?.length > 0 ? stateVars.TM_GetCustomerById[0].sehir : null) : (this.state.TM_GetCustomerById?.length > 0 ? this.state.TM_GetCustomerById[0].sehir : null)));

			stateVars.isComp315555Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, (stateVars.TM_GetCustomerById !== undefined ? (stateVars.TM_GetCustomerById?.length > 0 ? stateVars.TM_GetCustomerById[0].isShopping : null) : (this.state.TM_GetCustomerById?.length > 0 ? this.state.TM_GetCustomerById[0].isShopping : null))), ReactSystemFunctions.convertToTypeByName("True", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp630051Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, (stateVars.TM_GetCustomerById !== undefined ? (stateVars.TM_GetCustomerById?.length > 0 ? stateVars.TM_GetCustomerById[0].isShopping : null) : (this.state.TM_GetCustomerById?.length > 0 ? this.state.TM_GetCustomerById[0].isShopping : null))), ReactSystemFunctions.convertToTypeByName("False", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp205465Visible = ((ReactSystemFunctions.isNotEmpty(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "leadadd_999965_value", "value", "TM_GetCustomerByName", "id", "id")), ReactSystemFunctions.convertToTypeByName("True", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp875547Visible = ((ReactSystemFunctions.isNotEmpty(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "leadadd_931332_value", "value", "TM_GetReferanceByCurrAccCode", "id", "contactID")), ReactSystemFunctions.convertToTypeByName("True", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp357309Visible = ((ReactSystemFunctions.isNotEmpty(ReactSystemFunctions.toString(this, (stateVars.TM_GetReferenceCustomerById !== undefined ? (stateVars.TM_GetReferenceCustomerById?.length > 0 ? stateVars.TM_GetReferenceCustomerById[0].referenceNationalID : null) : (this.state.TM_GetReferenceCustomerById?.length > 0 ? this.state.TM_GetReferenceCustomerById[0].referenceNationalID : null))), ReactSystemFunctions.convertToTypeByName("True", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp907885Visible = ((ReactSystemFunctions.isNotEmpty(ReactSystemFunctions.toString(this, (stateVars.TM_GetReferenceCustomerById !== undefined ? (stateVars.TM_GetReferenceCustomerById?.length > 0 ? stateVars.TM_GetReferenceCustomerById[0].referencePhone : null) : (this.state.TM_GetReferenceCustomerById?.length > 0 ? this.state.TM_GetReferenceCustomerById[0].referencePhone : null))), ReactSystemFunctions.convertToTypeByName("True", "string"))) === true ? "visible" : "hidden")
			
			stateVars.dataSource_468567 = stateVars.TM_GetProductBrand ?? this.state.TM_GetProductBrand;
			stateVars.dataSource_468567 = stateVars.TM_GetProductBrand ?? this.state.TM_GetProductBrand;
			stateVars.isComp528620Visible = ((ReactSystemFunctions.isNotEmpty(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "leadadd_4804_value", "value", "TM_GetProductBracelet", "bracelet", "bracelet")), ReactSystemFunctions.convertToTypeByName("True", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp498343Visible = ((ReactSystemFunctions.isNotEmpty(ReactSystemFunctions.toString(this, (stateVars.TM_GetProduct !== undefined ? (stateVars.TM_GetProduct?.length > 0 ? stateVars.TM_GetProduct[0].categoryName : null) : (this.state.TM_GetProduct?.length > 0 ? this.state.TM_GetProduct[0].categoryName : null))), ReactSystemFunctions.convertToTypeByName("True", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp575180Visible = ((ReactSystemFunctions.isEmpty(ReactSystemFunctions.toString(this, (stateVars.TM_GetProduct !== undefined ? (stateVars.TM_GetProduct?.length > 0 ? stateVars.TM_GetProduct[0].categoryName : null) : (this.state.TM_GetProduct?.length > 0 ? this.state.TM_GetProduct[0].categoryName : null))), ReactSystemFunctions.convertToTypeByName("True", "string"))) === true ? "visible" : "hidden")
			
			stateVars.dataSource_964461 = stateVars.TM_GetLeadStatus ?? this.state.TM_GetLeadStatus;
			stateVars.dataSource_964461 = stateVars.TM_GetLeadStatus ?? this.state.TM_GetLeadStatus;
			
			stateVars.dataSource_680481 = stateVars.TM_GetLeadNextSteps ?? this.state.TM_GetLeadNextSteps;
			stateVars.dataSource_680481 = stateVars.TM_GetLeadNextSteps ?? this.state.TM_GetLeadNextSteps;
			
			stateVars.dataSource_748311 = stateVars.TM_GetAllContactSource ?? this.state.TM_GetAllContactSource;
			stateVars.dataSource_748311 = stateVars.TM_GetAllContactSource ?? this.state.TM_GetAllContactSource;
			
			stateVars.dataSource_228188 = stateVars.TM_GetProductBrandAlternatif ?? this.state.TM_GetProductBrandAlternatif;
			stateVars.dataSource_228188 = stateVars.TM_GetProductBrandAlternatif ?? this.state.TM_GetProductBrandAlternatif;
			stateVars.isComp624657Visible = ((ReactSystemFunctions.isNotEmpty(ReactSystemFunctions.value(this, "leadadd_674923_value", "categoryName"), ReactSystemFunctions.convertToTypeByName("True", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp690321Visible = ((ReactSystemFunctions.isEmpty(ReactSystemFunctions.value(this, "leadadd_674923_value", "categoryName"), ReactSystemFunctions.convertToTypeByName("True", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp283519Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, (stateVars.TM_LeadCheckCustomerProduct !== undefined ? (stateVars.TM_LeadCheckCustomerProduct?.length > 0 ? stateVars.TM_LeadCheckCustomerProduct[0].leadExists : null) : (this.state.TM_LeadCheckCustomerProduct?.length > 0 ? this.state.TM_LeadCheckCustomerProduct[0].leadExists : null))), ReactSystemFunctions.convertToTypeByName("True", "string"))) === true ? "visible" : "hidden")

	this.props.form?.setFieldsValue(formVars);
	this.setState(stateVars);
	KuikaAppManager.hideSpinner(this);

            this.setPageInitLoaded(true);
            return isErrorOccurred;
        }




		LeadAddComponent_357364_onClick = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
KuikaAppManager.showSpinner(this);

				stateVars.GoBack = await ReactSystemFunctions.goBack(this, false);

		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

            
            return isErrorOccurred;
        }


    LeadAddComponent_795234_onClick = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;

			validations.push({ 
				isValid: ReactSystemFunctions.isNotEmpty(ReactSystemFunctions.value(this, "leadadd_572982_value", "value", "GetSalesPersonByStore", "kuserID", ""), null),
				message: "Bu alan boş bırakılamaz !",
				formName: "leadadd_572982_value",
				condition: ReactSystemFunctions.contains(ReactSystemFunctions.getMyRoleNames(), "TimesMagazaMuduru")
			} as IValidationData);

validations.forEach((validation) => {
            if (validation.message === "Geçerli bir mail adresi giriniz.") {
                validation.message = ReactSystemFunctions.getEmailValidationMessage()
            }
        })
			validations.push({ 
				isValid: ReactSystemFunctions.isNotEmpty(ReactSystemFunctions.value(this, "leadadd_964461_value", "value", "TM_GetLeadStatus", "id", ""), null),
				message: "Bu alan boş bırakılamaz!",
				formName: "leadadd_964461_value",
				condition: true
			} as IValidationData);

validations.forEach((validation) => {
            if (validation.message === "Geçerli bir mail adresi giriniz.") {
                validation.message = ReactSystemFunctions.getEmailValidationMessage()
            }
        })
			validations.push({ 
				isValid: ReactSystemFunctions.isNotEmpty(ReactSystemFunctions.value(this, "leadadd_964461_value", "value", "TM_GetLeadStatus", "id", ""), null),
				message: "Bu Alan Boş Bırakılamaz!",
				formName: "leadadd_680481_value",
				condition: true
			} as IValidationData);

validations.forEach((validation) => {
            if (validation.message === "Geçerli bir mail adresi giriniz.") {
                validation.message = ReactSystemFunctions.getEmailValidationMessage()
            }
        })
			validations.push({ 
				isValid: ReactSystemFunctions.isNotEmpty(ReactSystemFunctions.value(this, "leadadd_8232_value", "value", "TM_StoreGetList", "id", ""), null),
				message: "Bu alan boş bırakılamaz!",
				formName: "leadadd_8232_value",
				condition: ReactSystemFunctions.contains(ReactSystemFunctions.getMyRoleNames(), ReactSystemFunctions.convertToTypeByName("TimesUstYonetici", "string"))
			} as IValidationData);

validations.forEach((validation) => {
            if (validation.message === "Geçerli bir mail adresi giriniz.") {
                validation.message = ReactSystemFunctions.getEmailValidationMessage()
            }
        })
			validations.push({ 
				isValid: ReactSystemFunctions.isNotEmpty(ReactSystemFunctions.value(this, "leadadd_999965_value", "value", "TM_GetCustomerByName", "id", "id"), null),
				message: "Bu alan boş bırakılamaz!",
				formName: "leadadd_999965_value",
				condition: true
			} as IValidationData);

validations.forEach((validation) => {
            if (validation.message === "Geçerli bir mail adresi giriniz.") {
                validation.message = ReactSystemFunctions.getEmailValidationMessage()
            }
        })

		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
		KuikaAppManager.increaseServerRequestCount();

        let localVar = {
				SalesPersonKUserId_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "leadadd_572982_value", "value", "GetSalesPersonByStore", "kuserID", "kuserID")), "Guid"),
				CreatedBy_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.getMyUserId(), "Guid"),
				Brand_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "leadadd_468567_value", "value", "TM_GetProductBrand", "brand", "brand")), "string"),
				StatuId_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "leadadd_964461_value", "value", "TM_GetLeadStatus", "id", "id")), "Guid"),
				NextStepId_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "leadadd_680481_value", "value", "TM_GetLeadNextSteps", "id", "id")), "Guid"),
				StoreId_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "leadadd_8232_value", "value", "TM_StoreGetList", "id", "id")), "Guid"),
				ContactResourceId_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "leadadd_748311_value", "value", "TM_GetAllContactSource", "id", "id")), "Guid"),
				ProductId_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, (stateVars.TM_GetProduct !== undefined ? (stateVars.TM_GetProduct?.length > 0 ? stateVars.TM_GetProduct[0].id : null) : (this.state.TM_GetProduct?.length > 0 ? this.state.TM_GetProduct[0].id : null))), "Guid"),
				CustomerId_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "leadadd_999965_value", "value", "TM_GetCustomerByName", "id", "id")), "Guid"),
				LeadNote_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "leadadd_10950_value", "value", "", "", "")), "string"),
				ReferencePersonID_0: ReactSystemFunctions.convertToTypeByName(null, "Guid"),
				SessionCode_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, (stateVars.TM_LeadAltModelTemp_GenerateSessionCode !== undefined ? (stateVars.TM_LeadAltModelTemp_GenerateSessionCode?.length > 0 ? stateVars.TM_LeadAltModelTemp_GenerateSessionCode[0].sessionCode : null) : (this.state.TM_LeadAltModelTemp_GenerateSessionCode?.length > 0 ? this.state.TM_LeadAltModelTemp_GenerateSessionCode[0].sessionCode : null))), "string")
        }

		KuikaAppManager.showSpinner(this);
if ((ReactSystemFunctions.contains(ReactSystemFunctions.getMyRoleNames(), ReactSystemFunctions.convertToTypeByName("TimesYonetici", "string")) || ReactSystemFunctions.contains(ReactSystemFunctions.getMyRoleNames(), ReactSystemFunctions.convertToTypeByName("TimesUstYonetici", "string")))) {
            		
        if (true) {
        KuikaAppManager.showSpinner(this);
        }
        let result = await KuikaAppManager.ApiRequest(this, "LeadAdd/LeadAddComponent_795234_onClick", localVar)
        if (!KMainFunctions.IsResStatus2XX(result)) return true;

			stateVars.TM_CreateLead = result?.data.tM_CreateLead;
			this.props.form?.setFieldsValue(formVars);
			
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.LeadAddComponent_795234_onClick1_();
                  resolve();
                });
          })

        } else {
            
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.LeadAddComponent_795234_onClick1_();
                  resolve();
                });
          })
        }


        
        KuikaAppManager.hideSpinner(this);
        return isErrorOccurred;
    }
    LeadAddComponent_795234_onClick1_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;

			validations.push({ 
				isValid: ReactSystemFunctions.isNotEmpty(ReactSystemFunctions.value(this, "leadadd_572982_value", "value", "GetSalesPersonByStore", "kuserID", ""), null),
				message: "Bu alan boş bırakılamaz !",
				formName: "leadadd_572982_value",
				condition: ReactSystemFunctions.contains(ReactSystemFunctions.getMyRoleNames(), ReactSystemFunctions.convertToTypeByName("TimesMagazaMuduru", "string"))
			} as IValidationData);

validations.forEach((validation) => {
            if (validation.message === "Geçerli bir mail adresi giriniz.") {
                validation.message = ReactSystemFunctions.getEmailValidationMessage()
            }
        })
			validations.push({ 
				isValid: ReactSystemFunctions.isNotEmpty(ReactSystemFunctions.value(this, "leadadd_964461_value", "value", "TM_GetLeadStatus", "id", ""), null),
				message: "Bu alan boş bırakılamaz!",
				formName: "leadadd_964461_value",
				condition: true
			} as IValidationData);

validations.forEach((validation) => {
            if (validation.message === "Geçerli bir mail adresi giriniz.") {
                validation.message = ReactSystemFunctions.getEmailValidationMessage()
            }
        })
			validations.push({ 
				isValid: ReactSystemFunctions.isNotEmpty(ReactSystemFunctions.value(this, "leadadd_964461_value", "value", "TM_GetLeadStatus", "id", ""), null),
				message: "Bu Alan Boş Bırakılamaz!",
				formName: "leadadd_680481_value",
				condition: true
			} as IValidationData);

validations.forEach((validation) => {
            if (validation.message === "Geçerli bir mail adresi giriniz.") {
                validation.message = ReactSystemFunctions.getEmailValidationMessage()
            }
        })
			validations.push({ 
				isValid: ReactSystemFunctions.isNotEmpty(ReactSystemFunctions.value(this, "leadadd_999965_value", "value", "TM_GetCustomerByName", "id", "id"), null),
				message: "Bu alan boş bırakılamaz!",
				formName: "leadadd_999965_value",
				condition: true
			} as IValidationData);

validations.forEach((validation) => {
            if (validation.message === "Geçerli bir mail adresi giriniz.") {
                validation.message = ReactSystemFunctions.getEmailValidationMessage()
            }
        })

		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
		KuikaAppManager.increaseServerRequestCount();

        let localVar = {
				SalesPersonKUserId_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "leadadd_572982_value", "value", "GetSalesPersonByStore", "kuserID", "kuserID")), "Guid"),
				CreatedBy_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.getMyUserId(), "Guid"),
				Brand_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "leadadd_468567_value", "value", "TM_GetProductBrand", "brand", "brand")), "string"),
				StatuId_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "leadadd_964461_value", "value", "TM_GetLeadStatus", "id", "id")), "Guid"),
				NextStepId_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "leadadd_680481_value", "value", "TM_GetLeadNextSteps", "id", "id")), "Guid"),
				StoreId_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, (stateVars.TS_GetStoreUsers !== undefined ? (stateVars.TS_GetStoreUsers?.length > 0 ? stateVars.TS_GetStoreUsers[0].storeID : null) : (this.state.TS_GetStoreUsers?.length > 0 ? this.state.TS_GetStoreUsers[0].storeID : null))), "Guid"),
				ContactResourceId_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "leadadd_748311_value", "value", "TM_GetAllContactSource", "id", "id")), "Guid"),
				ProductId_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, (stateVars.TM_GetProduct !== undefined ? (stateVars.TM_GetProduct?.length > 0 ? stateVars.TM_GetProduct[0].id : null) : (this.state.TM_GetProduct?.length > 0 ? this.state.TM_GetProduct[0].id : null))), "Guid"),
				CustomerId_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "leadadd_999965_value", "value", "TM_GetCustomerByName", "id", "id")), "Guid"),
				LeadNote_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "leadadd_10950_value", "value", "", "", "")), "string"),
				ReferencePersonID_0: ReactSystemFunctions.convertToTypeByName(null, "Guid"),
				SessionCode_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, (stateVars.TM_LeadAltModelTemp_GenerateSessionCode !== undefined ? (stateVars.TM_LeadAltModelTemp_GenerateSessionCode?.length > 0 ? stateVars.TM_LeadAltModelTemp_GenerateSessionCode[0].sessionCode : null) : (this.state.TM_LeadAltModelTemp_GenerateSessionCode?.length > 0 ? this.state.TM_LeadAltModelTemp_GenerateSessionCode[0].sessionCode : null))), "string")
        }

if (ReactSystemFunctions.contains(ReactSystemFunctions.getMyRoleNames(), ReactSystemFunctions.convertToTypeByName("TimesMagazaMuduru", "string"))) {
            		
        if (true) {
        KuikaAppManager.showSpinner(this);
        }
        let result = await KuikaAppManager.ApiRequest(this, "LeadAdd/LeadAddComponent_795234_onClick1_", localVar)
        if (!KMainFunctions.IsResStatus2XX(result)) return true;

			stateVars.TM_CreateLead = result?.data.tM_CreateLead;
			this.props.form?.setFieldsValue(formVars);
			
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.LeadAddComponent_795234_onClick2_();
                  resolve();
                });
          })

        } else {
            
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.LeadAddComponent_795234_onClick2_();
                  resolve();
                });
          })
        }


        
        KuikaAppManager.hideSpinner(this);
        return isErrorOccurred;
    }
    LeadAddComponent_795234_onClick2_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;

			validations.push({ 
				isValid: ReactSystemFunctions.isNotEmpty(ReactSystemFunctions.value(this, "leadadd_964461_value", "value", "TM_GetLeadStatus", "id", ""), null),
				message: "Bu alan boş bırakılamaz!",
				formName: "leadadd_964461_value",
				condition: true
			} as IValidationData);

validations.forEach((validation) => {
            if (validation.message === "Geçerli bir mail adresi giriniz.") {
                validation.message = ReactSystemFunctions.getEmailValidationMessage()
            }
        })
			validations.push({ 
				isValid: ReactSystemFunctions.isNotEmpty(ReactSystemFunctions.value(this, "leadadd_964461_value", "value", "TM_GetLeadStatus", "id", ""), null),
				message: "Bu Alan Boş Bırakılamaz!",
				formName: "leadadd_680481_value",
				condition: true
			} as IValidationData);

validations.forEach((validation) => {
            if (validation.message === "Geçerli bir mail adresi giriniz.") {
                validation.message = ReactSystemFunctions.getEmailValidationMessage()
            }
        })
			validations.push({ 
				isValid: ReactSystemFunctions.isNotEmpty(ReactSystemFunctions.value(this, "leadadd_999965_value", "value", "TM_GetCustomerByName", "id", "id"), null),
				message: "Bu alan boş bırakılamaz!",
				formName: "leadadd_999965_value",
				condition: true
			} as IValidationData);

validations.forEach((validation) => {
            if (validation.message === "Geçerli bir mail adresi giriniz.") {
                validation.message = ReactSystemFunctions.getEmailValidationMessage()
            }
        })

		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
		KuikaAppManager.increaseServerRequestCount();

        let localVar = {
				SalesPersonKUserId_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.getMyUserId(), "Guid"),
				CreatedBy_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.getMyUserId(), "Guid"),
				Brand_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "leadadd_468567_value", "value", "TM_GetProductBrand", "brand", "brand")), "string"),
				StatuId_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "leadadd_964461_value", "value", "TM_GetLeadStatus", "id", "id")), "Guid"),
				NextStepId_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "leadadd_680481_value", "value", "TM_GetLeadNextSteps", "id", "id")), "Guid"),
				StoreId_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, (stateVars.TS_GetStoreUsers !== undefined ? (stateVars.TS_GetStoreUsers?.length > 0 ? stateVars.TS_GetStoreUsers[0].storeID : null) : (this.state.TS_GetStoreUsers?.length > 0 ? this.state.TS_GetStoreUsers[0].storeID : null))), "Guid"),
				ContactResourceId_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "leadadd_748311_value", "value", "TM_GetAllContactSource", "id", "id")), "Guid"),
				ProductId_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, (stateVars.TM_GetProduct !== undefined ? (stateVars.TM_GetProduct?.length > 0 ? stateVars.TM_GetProduct[0].id : null) : (this.state.TM_GetProduct?.length > 0 ? this.state.TM_GetProduct[0].id : null))), "Guid"),
				CustomerId_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "leadadd_999965_value", "value", "TM_GetCustomerByName", "id", "id")), "Guid"),
				LeadNote_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "leadadd_10950_value", "value", "", "", "")), "string"),
				ReferencePersonID_0: ReactSystemFunctions.convertToTypeByName(null, "Guid"),
				SessionCode_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, (stateVars.TM_LeadAltModelTemp_GenerateSessionCode !== undefined ? (stateVars.TM_LeadAltModelTemp_GenerateSessionCode?.length > 0 ? stateVars.TM_LeadAltModelTemp_GenerateSessionCode[0].sessionCode : null) : (this.state.TM_LeadAltModelTemp_GenerateSessionCode?.length > 0 ? this.state.TM_LeadAltModelTemp_GenerateSessionCode[0].sessionCode : null))), "string")
        }

if (ReactSystemFunctions.contains(ReactSystemFunctions.getMyRoleNames(), ReactSystemFunctions.convertToTypeByName("TimesSatisPersoneli", "string"))) {
            		
        if (true) {
        KuikaAppManager.showSpinner(this);
        }
        let result = await KuikaAppManager.ApiRequest(this, "LeadAdd/LeadAddComponent_795234_onClick2_", localVar)
        if (!KMainFunctions.IsResStatus2XX(result)) return true;

			stateVars.TM_CreateLead = result?.data.tM_CreateLead;
			this.props.form?.setFieldsValue(formVars);
			
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.LeadAddComponent_795234_onClick3_();
                  resolve();
                });
          })

        } else {
            
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.LeadAddComponent_795234_onClick3_();
                  resolve();
                });
          })
        }


        
        KuikaAppManager.hideSpinner(this);
        return isErrorOccurred;
    }
		LeadAddComponent_795234_onClick3_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }

				stateVars.Notify = await ReactSystemFunctions.notify(this, ReactSystemFunctions.toString(this, (stateVars.TM_CreateLead !== undefined ? (stateVars.TM_CreateLead?.length > 0 ? stateVars.TM_CreateLead[0].message : null) : (this.state.TM_CreateLead?.length > 0 ? this.state.TM_CreateLead[0].message : null))), ReactSystemFunctions.convertToTypeByName("default", "string"), ReactSystemFunctions.convertToTypeByName("top-center", "string"), 2, ReactSystemFunctions.convertToTypeByName("", "string"), ReactSystemFunctions.convertToTypeByName("", "string"), 0);
const __currentPath = (window.location.hash ? window.location.hash.replace(/^#/, '').split('?')[0] : window.location.pathname.split('?')[0]).toLowerCase();
if (__currentPath !== "/leadlisttemp") {
  this.context.setMasterPageInitLoaded(false);
  this.context.setMasterPageRecurringLoaded(false);
  this.context.setShouldTriggerPageInit(true);
}
					KuikaAppManager.prepareForNavigation();

				stateVars.NAVIGATE = await ReactSystemFunctions.navigate(this, undefined, "LeadAdd", "LeadListTemp", "", "currentPage", null, null, null, null, null, null, true, false);

		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

            
            return isErrorOccurred;
        }








    LeadAddComponent_8232_onChange = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;

			validations.push({ 
				isValid: ReactSystemFunctions.isNotEmpty(ReactSystemFunctions.value(this, "leadadd_8232_value", "value", "TM_StoreGetList", "id", ""), null),
				message: "Bu alan boş bırakılamaz!",
				formName: "leadadd_8232_value",
				condition: ReactSystemFunctions.contains(ReactSystemFunctions.getMyRoleNames(), "TimesUstYonetici")
			} as IValidationData);

validations.forEach((validation) => {
            if (validation.message === "Geçerli bir mail adresi giriniz.") {
                validation.message = ReactSystemFunctions.getEmailValidationMessage()
            }
        })

		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
		KuikaAppManager.increaseServerRequestCount();

        let localVar = {
				StoreId_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "leadadd_8232_value", "value", "TM_StoreGetList", "id", "id")), "Guid")
        }

		KuikaAppManager.showSpinner(this);
		
        if (true) {
        KuikaAppManager.showSpinner(this);
        }
        let result = await KuikaAppManager.ApiRequest(this, "LeadAdd/LeadAddComponent_8232_onChange", localVar)
        if (!KMainFunctions.IsResStatus2XX(result)) return true;

			stateVars.GetSalesPersonByStore = result?.data.getSalesPersonByStore;
			
			formVars.leadadd_572982_options = stateVars.GetSalesPersonByStore;
			this.props.form?.setFieldsValue(formVars);
			
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.LeadAddComponent_8232_onChange1_();
                  resolve();
                });
          })



        
        KuikaAppManager.hideSpinner(this);
        return isErrorOccurred;
    }
		LeadAddComponent_8232_onChange1_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }

				
				stateVars.dataSource_572982 = stateVars.GetSalesPersonByStore ?? this.state.GetSalesPersonByStore;
				stateVars.dataSource_572982 = stateVars.GetSalesPersonByStore ?? this.state.GetSalesPersonByStore;

		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

            
            return isErrorOccurred;
        }




    LeadAddComponent_572982_onChange = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;

			validations.push({ 
				isValid: ReactSystemFunctions.isNotEmpty(ReactSystemFunctions.value(this, "leadadd_572982_value", "value", "GetSalesPersonByStore", "kuserID", ""), null),
				message: "Bu alan boş bırakılamaz !",
				formName: "leadadd_572982_value",
				condition: ReactSystemFunctions.contains(ReactSystemFunctions.getMyRoleNames(), ReactSystemFunctions.convertToTypeByName("TimesMagazaMuduru", "string"))
			} as IValidationData);

validations.forEach((validation) => {
            if (validation.message === "Geçerli bir mail adresi giriniz.") {
                validation.message = ReactSystemFunctions.getEmailValidationMessage()
            }
        })

		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
		KuikaAppManager.increaseServerRequestCount();

        let localVar = {
				KUserId_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "leadadd_572982_value", "value", "GetSalesPersonByStore", "kuserID", "kuserID")), "Guid"),
				KUserId_1: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "leadadd_572982_value", "value", "GetSalesPersonByStore", "kuserID", "kuserID")), "Guid")
        }

		KuikaAppManager.showSpinner(this);
		
        if (true) {
        KuikaAppManager.showSpinner(this);
        }
        let result = await KuikaAppManager.ApiRequest(this, "LeadAdd/LeadAddComponent_572982_onChange", localVar)
        if (!KMainFunctions.IsResStatus2XX(result)) return true;

			stateVars.TM_GetProductBrand = result?.data.tM_GetProductBrand;
			
			formVars.leadadd_468567_options = stateVars.TM_GetProductBrand;
			stateVars.TM_GetProductBrandAlternatif = result?.data.tM_GetProductBrandAlternatif;
			
			formVars.leadadd_228188_options = stateVars.TM_GetProductBrandAlternatif;
			this.props.form?.setFieldsValue(formVars);
			
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.LeadAddComponent_572982_onChange1_();
                  resolve();
                });
          })



        
        KuikaAppManager.hideSpinner(this);
        return isErrorOccurred;
    }
		LeadAddComponent_572982_onChange1_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }

				
				stateVars.dataSource_468567 = stateVars.TM_GetProductBrand ?? this.state.TM_GetProductBrand;
				stateVars.dataSource_468567 = stateVars.TM_GetProductBrand ?? this.state.TM_GetProductBrand;
				
				stateVars.dataSource_228188 = stateVars.TM_GetProductBrandAlternatif ?? this.state.TM_GetProductBrandAlternatif;
				stateVars.dataSource_228188 = stateVars.TM_GetProductBrandAlternatif ?? this.state.TM_GetProductBrandAlternatif;

		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

            
            return isErrorOccurred;
        }




    LeadAddComponent_999965_onChange = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;

			validations.push({ 
				isValid: ReactSystemFunctions.isNotEmpty(ReactSystemFunctions.value(this, "leadadd_999965_value", "value", "TM_GetCustomerByName", "id", "id"), null),
				message: "Bu alan boş bırakılamaz!",
				formName: "leadadd_999965_value",
				condition: true
			} as IValidationData);

validations.forEach((validation) => {
            if (validation.message === "Geçerli bir mail adresi giriniz.") {
                validation.message = ReactSystemFunctions.getEmailValidationMessage()
            }
        })

		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
		KuikaAppManager.increaseServerRequestCount();

        let localVar = {
				CustomerId_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "leadadd_999965_value", "value", "TM_GetCustomerByName", "id", "id")), "Guid"),
				CurrAccCode_1: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, (stateVars.TM_GetCustomerById !== undefined ? (stateVars.TM_GetCustomerById?.length > 0 ? stateVars.TM_GetCustomerById[0].currAccCode : null) : (this.state.TM_GetCustomerById?.length > 0 ? this.state.TM_GetCustomerById[0].currAccCode : null))), "string")
        }

		KuikaAppManager.showSpinner(this);
		
        if (true) {
        KuikaAppManager.showSpinner(this);
        }
        let result = await KuikaAppManager.ApiRequest(this, "LeadAdd/LeadAddComponent_999965_onChange", localVar)
        if (!KMainFunctions.IsResStatus2XX(result)) return true;

			stateVars.TM_GetCustomerById = result?.data.tM_GetCustomerById;
			formVars.leadadd_410287_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetCustomerById !== undefined ? (stateVars.TM_GetCustomerById?.length > 0 ? stateVars.TM_GetCustomerById[0].adSoyad : null) : (this.state.TM_GetCustomerById?.length > 0 ? this.state.TM_GetCustomerById[0].adSoyad : null)));
			formVars.leadadd_683308_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetCustomerById !== undefined ? (stateVars.TM_GetCustomerById?.length > 0 ? stateVars.TM_GetCustomerById[0].tcKimlikNo : null) : (this.state.TM_GetCustomerById?.length > 0 ? this.state.TM_GetCustomerById[0].tcKimlikNo : null)));
			formVars.leadadd_381076_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetCustomerById !== undefined ? (stateVars.TM_GetCustomerById?.length > 0 ? stateVars.TM_GetCustomerById[0].telefonNo : null) : (this.state.TM_GetCustomerById?.length > 0 ? this.state.TM_GetCustomerById[0].telefonNo : null)));
			formVars.leadadd_496941_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetCustomerById !== undefined ? (stateVars.TM_GetCustomerById?.length > 0 ? stateVars.TM_GetCustomerById[0].email : null) : (this.state.TM_GetCustomerById?.length > 0 ? this.state.TM_GetCustomerById[0].email : null)));
			formVars.leadadd_826540_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetCustomerById !== undefined ? (stateVars.TM_GetCustomerById?.length > 0 ? stateVars.TM_GetCustomerById[0].sehir : null) : (this.state.TM_GetCustomerById?.length > 0 ? this.state.TM_GetCustomerById[0].sehir : null)));
			stateVars.isComp683308Visible = ((ReactSystemFunctions.isNotEmpty(ReactSystemFunctions.toString(this, (stateVars.TM_GetCustomerById !== undefined ? (stateVars.TM_GetCustomerById?.length > 0 ? stateVars.TM_GetCustomerById[0].tcKimlikNo : null) : (this.state.TM_GetCustomerById?.length > 0 ? this.state.TM_GetCustomerById[0].tcKimlikNo : null))), ReactSystemFunctions.convertToTypeByName("True", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp315555Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, (stateVars.TM_GetCustomerById !== undefined ? (stateVars.TM_GetCustomerById?.length > 0 ? stateVars.TM_GetCustomerById[0].isShopping : null) : (this.state.TM_GetCustomerById?.length > 0 ? this.state.TM_GetCustomerById[0].isShopping : null))), ReactSystemFunctions.convertToTypeByName("True", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp630051Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, (stateVars.TM_GetCustomerById !== undefined ? (stateVars.TM_GetCustomerById?.length > 0 ? stateVars.TM_GetCustomerById[0].isShopping : null) : (this.state.TM_GetCustomerById?.length > 0 ? this.state.TM_GetCustomerById[0].isShopping : null))), ReactSystemFunctions.convertToTypeByName("False", "string"))) === true ? "visible" : "hidden")
			stateVars.TM_GetReferanceByCurrAccCode = result?.data.tM_GetReferanceByCurrAccCode;
			
			formVars.leadadd_931332_options = stateVars.TM_GetReferanceByCurrAccCode;
			this.props.form?.setFieldsValue(formVars);
			
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.LeadAddComponent_999965_onChange1_();
                  resolve();
                });
          })



        
        KuikaAppManager.hideSpinner(this);
        return isErrorOccurred;
    }
		LeadAddComponent_999965_onChange1_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }

				stateVars.isComp910984Visible = ((ReactSystemFunctions.isNotEmpty(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "leadadd_999965_value", "value", "TM_GetCustomerByName", "id", "id")), ReactSystemFunctions.convertToTypeByName("True", "string"))) === true ? "visible" : "hidden")
				stateVars.isComp513936Visible = ((ReactSystemFunctions.isNotEmpty(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "leadadd_999965_value", "value", "TM_GetCustomerByName", "id", "id")), ReactSystemFunctions.convertToTypeByName("True", "string"))) === true ? "visible" : "hidden")
				stateVars.isComp366434Visible = ((ReactSystemFunctions.isNotEmpty(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "leadadd_999965_value", "value", "TM_GetCustomerByName", "id", "id")), ReactSystemFunctions.convertToTypeByName("True", "string"))) === true ? "visible" : "hidden")
				formVars.leadadd_410287_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetCustomerById !== undefined ? (stateVars.TM_GetCustomerById?.length > 0 ? stateVars.TM_GetCustomerById[0].adSoyad : null) : (this.state.TM_GetCustomerById?.length > 0 ? this.state.TM_GetCustomerById[0].adSoyad : null)));

				formVars.leadadd_683308_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetCustomerById !== undefined ? (stateVars.TM_GetCustomerById?.length > 0 ? stateVars.TM_GetCustomerById[0].tcKimlikNo : null) : (this.state.TM_GetCustomerById?.length > 0 ? this.state.TM_GetCustomerById[0].tcKimlikNo : null)));

				formVars.leadadd_381076_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetCustomerById !== undefined ? (stateVars.TM_GetCustomerById?.length > 0 ? stateVars.TM_GetCustomerById[0].telefonNo : null) : (this.state.TM_GetCustomerById?.length > 0 ? this.state.TM_GetCustomerById[0].telefonNo : null)));

				formVars.leadadd_496941_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetCustomerById !== undefined ? (stateVars.TM_GetCustomerById?.length > 0 ? stateVars.TM_GetCustomerById[0].email : null) : (this.state.TM_GetCustomerById?.length > 0 ? this.state.TM_GetCustomerById[0].email : null)));

				formVars.leadadd_826540_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetCustomerById !== undefined ? (stateVars.TM_GetCustomerById?.length > 0 ? stateVars.TM_GetCustomerById[0].sehir : null) : (this.state.TM_GetCustomerById?.length > 0 ? this.state.TM_GetCustomerById[0].sehir : null)));

				
				stateVars.dataSource_931332 = stateVars.TM_GetReferanceByCurrAccCode ?? this.state.TM_GetReferanceByCurrAccCode;
				stateVars.dataSource_931332 = stateVars.TM_GetReferanceByCurrAccCode ?? this.state.TM_GetReferanceByCurrAccCode;
				stateVars.isComp205465Visible = ((ReactSystemFunctions.isNotEmpty(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "leadadd_999965_value", "value", "TM_GetCustomerByName", "id", "id")), ReactSystemFunctions.convertToTypeByName("True", "string"))) === true ? "visible" : "hidden")

		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

            
            return isErrorOccurred;
        }




		LeadAddComponent_471429_onClick = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
KuikaAppManager.showSpinner(this);

					KuikaAppManager.prepareForNavigation();

				stateVars.NAVIGATE = await ReactSystemFunctions.navigate(this, undefined, "LeadAdd", "CustomerCreatePost", "", "7d969ddf-5801-4eb6-b92b-12be35bdd565", "772195", null, "right", "true", "80%", "100vh", true, false);

		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

            
            return isErrorOccurred;
        }


    LeadAddComponent_513936_onClick = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;

			validations.push({ 
				isValid: ReactSystemFunctions.isNotEmpty(ReactSystemFunctions.value(this, "leadadd_999965_value", "value", "TM_GetCustomerByName", "id", "id"), null),
				message: "Bu alan boş bırakılamaz!",
				formName: "leadadd_999965_value",
				condition: true
			} as IValidationData);

validations.forEach((validation) => {
            if (validation.message === "Geçerli bir mail adresi giriniz.") {
                validation.message = ReactSystemFunctions.getEmailValidationMessage()
            }
        })

		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
		KuikaAppManager.increaseServerRequestCount();

        let localVar = {
				CustomerId_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "leadadd_999965_value", "value", "TM_GetCustomerByName", "id", "id")), "Guid")
        }

		KuikaAppManager.showSpinner(this);
		
        if (true) {
        KuikaAppManager.showSpinner(this);
        }
        let result = await KuikaAppManager.ApiRequest(this, "LeadAdd/LeadAddComponent_513936_onClick", localVar)
        if (!KMainFunctions.IsResStatus2XX(result)) return true;

			stateVars.TM_GetCustomerById = result?.data.tM_GetCustomerById;
			formVars.leadadd_410287_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetCustomerById !== undefined ? (stateVars.TM_GetCustomerById?.length > 0 ? stateVars.TM_GetCustomerById[0].adSoyad : null) : (this.state.TM_GetCustomerById?.length > 0 ? this.state.TM_GetCustomerById[0].adSoyad : null)));
			formVars.leadadd_683308_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetCustomerById !== undefined ? (stateVars.TM_GetCustomerById?.length > 0 ? stateVars.TM_GetCustomerById[0].tcKimlikNo : null) : (this.state.TM_GetCustomerById?.length > 0 ? this.state.TM_GetCustomerById[0].tcKimlikNo : null)));
			formVars.leadadd_381076_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetCustomerById !== undefined ? (stateVars.TM_GetCustomerById?.length > 0 ? stateVars.TM_GetCustomerById[0].telefonNo : null) : (this.state.TM_GetCustomerById?.length > 0 ? this.state.TM_GetCustomerById[0].telefonNo : null)));
			formVars.leadadd_496941_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetCustomerById !== undefined ? (stateVars.TM_GetCustomerById?.length > 0 ? stateVars.TM_GetCustomerById[0].email : null) : (this.state.TM_GetCustomerById?.length > 0 ? this.state.TM_GetCustomerById[0].email : null)));
			formVars.leadadd_826540_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetCustomerById !== undefined ? (stateVars.TM_GetCustomerById?.length > 0 ? stateVars.TM_GetCustomerById[0].sehir : null) : (this.state.TM_GetCustomerById?.length > 0 ? this.state.TM_GetCustomerById[0].sehir : null)));
			stateVars.isComp683308Visible = ((ReactSystemFunctions.isNotEmpty(ReactSystemFunctions.toString(this, (stateVars.TM_GetCustomerById !== undefined ? (stateVars.TM_GetCustomerById?.length > 0 ? stateVars.TM_GetCustomerById[0].tcKimlikNo : null) : (this.state.TM_GetCustomerById?.length > 0 ? this.state.TM_GetCustomerById[0].tcKimlikNo : null))), ReactSystemFunctions.convertToTypeByName("True", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp315555Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, (stateVars.TM_GetCustomerById !== undefined ? (stateVars.TM_GetCustomerById?.length > 0 ? stateVars.TM_GetCustomerById[0].isShopping : null) : (this.state.TM_GetCustomerById?.length > 0 ? this.state.TM_GetCustomerById[0].isShopping : null))), ReactSystemFunctions.convertToTypeByName("True", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp630051Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, (stateVars.TM_GetCustomerById !== undefined ? (stateVars.TM_GetCustomerById?.length > 0 ? stateVars.TM_GetCustomerById[0].isShopping : null) : (this.state.TM_GetCustomerById?.length > 0 ? this.state.TM_GetCustomerById[0].isShopping : null))), ReactSystemFunctions.convertToTypeByName("False", "string"))) === true ? "visible" : "hidden")
			this.props.form?.setFieldsValue(formVars);
			
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.LeadAddComponent_513936_onClick1_();
                  resolve();
                });
          })



        
        KuikaAppManager.hideSpinner(this);
        return isErrorOccurred;
    }
		LeadAddComponent_513936_onClick1_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }

					KuikaAppManager.prepareForNavigation();
						KuikaAppManager.addToPageInputVariables("CustomerDetailInfo", "customerCode", ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, (stateVars.TM_GetCustomerById !== undefined ? (stateVars.TM_GetCustomerById?.length > 0 ? stateVars.TM_GetCustomerById[0].currAccCode : null) : (this.state.TM_GetCustomerById?.length > 0 ? this.state.TM_GetCustomerById[0].currAccCode : null))), "string"));
						KuikaAppManager.addToPageInputVariables("CustomerDetailInfo", "CustomerId", ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, (stateVars.TM_GetCustomerById !== undefined ? (stateVars.TM_GetCustomerById?.length > 0 ? stateVars.TM_GetCustomerById[0].customerId : null) : (this.state.TM_GetCustomerById?.length > 0 ? this.state.TM_GetCustomerById[0].customerId : null))), "Guid"));

				stateVars.NAVIGATE = await ReactSystemFunctions.navigate(this, this.LeadAddComponent_513936_onClick2_, "LeadAdd", "CustomerDetailInfo", "", "7d969ddf-5801-4eb6-b92b-12be35bdd565", "627617", null, "right", "true", "80%", "100vh", true, false);

		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

            
            return isErrorOccurred;
        }
		LeadAddComponent_513936_onClick2_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
KuikaAppManager.showSpinner(this);

				formVars.leadadd_410287_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetCustomerById !== undefined ? (stateVars.TM_GetCustomerById?.length > 0 ? stateVars.TM_GetCustomerById[0].adSoyad : null) : (this.state.TM_GetCustomerById?.length > 0 ? this.state.TM_GetCustomerById[0].adSoyad : null)));

				formVars.leadadd_683308_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetCustomerById !== undefined ? (stateVars.TM_GetCustomerById?.length > 0 ? stateVars.TM_GetCustomerById[0].tcKimlikNo : null) : (this.state.TM_GetCustomerById?.length > 0 ? this.state.TM_GetCustomerById[0].tcKimlikNo : null)));

				formVars.leadadd_381076_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetCustomerById !== undefined ? (stateVars.TM_GetCustomerById?.length > 0 ? stateVars.TM_GetCustomerById[0].telefonNo : null) : (this.state.TM_GetCustomerById?.length > 0 ? this.state.TM_GetCustomerById[0].telefonNo : null)));

				formVars.leadadd_496941_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetCustomerById !== undefined ? (stateVars.TM_GetCustomerById?.length > 0 ? stateVars.TM_GetCustomerById[0].email : null) : (this.state.TM_GetCustomerById?.length > 0 ? this.state.TM_GetCustomerById[0].email : null)));

				formVars.leadadd_826540_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetCustomerById !== undefined ? (stateVars.TM_GetCustomerById?.length > 0 ? stateVars.TM_GetCustomerById[0].sehir : null) : (this.state.TM_GetCustomerById?.length > 0 ? this.state.TM_GetCustomerById[0].sehir : null)));


		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

            
            return isErrorOccurred;
        }





    LeadAddComponent_366434_onClick = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;

			validations.push({ 
				isValid: ReactSystemFunctions.isNotEmpty(ReactSystemFunctions.value(this, "leadadd_999965_value", "value", "TM_GetCustomerByName", "id", "id"), null),
				message: "Bu alan boş bırakılamaz!",
				formName: "leadadd_999965_value",
				condition: true
			} as IValidationData);

validations.forEach((validation) => {
            if (validation.message === "Geçerli bir mail adresi giriniz.") {
                validation.message = ReactSystemFunctions.getEmailValidationMessage()
            }
        })

		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
		KuikaAppManager.increaseServerRequestCount();

        let localVar = {
				CustomerId_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "leadadd_999965_value", "value", "TM_GetCustomerByName", "id", "id")), "Guid")
        }

		KuikaAppManager.showSpinner(this);
		
        if (true) {
        KuikaAppManager.showSpinner(this);
        }
        let result = await KuikaAppManager.ApiRequest(this, "LeadAdd/LeadAddComponent_366434_onClick", localVar)
        if (!KMainFunctions.IsResStatus2XX(result)) return true;

			stateVars.TM_GetCustomerById = result?.data.tM_GetCustomerById;
			formVars.leadadd_410287_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetCustomerById !== undefined ? (stateVars.TM_GetCustomerById?.length > 0 ? stateVars.TM_GetCustomerById[0].adSoyad : null) : (this.state.TM_GetCustomerById?.length > 0 ? this.state.TM_GetCustomerById[0].adSoyad : null)));
			formVars.leadadd_683308_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetCustomerById !== undefined ? (stateVars.TM_GetCustomerById?.length > 0 ? stateVars.TM_GetCustomerById[0].tcKimlikNo : null) : (this.state.TM_GetCustomerById?.length > 0 ? this.state.TM_GetCustomerById[0].tcKimlikNo : null)));
			formVars.leadadd_381076_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetCustomerById !== undefined ? (stateVars.TM_GetCustomerById?.length > 0 ? stateVars.TM_GetCustomerById[0].telefonNo : null) : (this.state.TM_GetCustomerById?.length > 0 ? this.state.TM_GetCustomerById[0].telefonNo : null)));
			formVars.leadadd_496941_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetCustomerById !== undefined ? (stateVars.TM_GetCustomerById?.length > 0 ? stateVars.TM_GetCustomerById[0].email : null) : (this.state.TM_GetCustomerById?.length > 0 ? this.state.TM_GetCustomerById[0].email : null)));
			formVars.leadadd_826540_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetCustomerById !== undefined ? (stateVars.TM_GetCustomerById?.length > 0 ? stateVars.TM_GetCustomerById[0].sehir : null) : (this.state.TM_GetCustomerById?.length > 0 ? this.state.TM_GetCustomerById[0].sehir : null)));
			stateVars.isComp683308Visible = ((ReactSystemFunctions.isNotEmpty(ReactSystemFunctions.toString(this, (stateVars.TM_GetCustomerById !== undefined ? (stateVars.TM_GetCustomerById?.length > 0 ? stateVars.TM_GetCustomerById[0].tcKimlikNo : null) : (this.state.TM_GetCustomerById?.length > 0 ? this.state.TM_GetCustomerById[0].tcKimlikNo : null))), ReactSystemFunctions.convertToTypeByName("True", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp315555Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, (stateVars.TM_GetCustomerById !== undefined ? (stateVars.TM_GetCustomerById?.length > 0 ? stateVars.TM_GetCustomerById[0].isShopping : null) : (this.state.TM_GetCustomerById?.length > 0 ? this.state.TM_GetCustomerById[0].isShopping : null))), ReactSystemFunctions.convertToTypeByName("True", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp630051Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, (stateVars.TM_GetCustomerById !== undefined ? (stateVars.TM_GetCustomerById?.length > 0 ? stateVars.TM_GetCustomerById[0].isShopping : null) : (this.state.TM_GetCustomerById?.length > 0 ? this.state.TM_GetCustomerById[0].isShopping : null))), ReactSystemFunctions.convertToTypeByName("False", "string"))) === true ? "visible" : "hidden")
			this.props.form?.setFieldsValue(formVars);
			
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.LeadAddComponent_366434_onClick1_();
                  resolve();
                });
          })



        
        KuikaAppManager.hideSpinner(this);
        return isErrorOccurred;
    }
		LeadAddComponent_366434_onClick1_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }

					KuikaAppManager.prepareForNavigation();
						KuikaAppManager.addToPageInputVariables("CustomerUpdatePost", "CustomerId", ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, (stateVars.TM_GetCustomerById !== undefined ? (stateVars.TM_GetCustomerById?.length > 0 ? stateVars.TM_GetCustomerById[0].customerId : null) : (this.state.TM_GetCustomerById?.length > 0 ? this.state.TM_GetCustomerById[0].customerId : null))), "Guid"));

				stateVars.NAVIGATE = await ReactSystemFunctions.navigate(this, this.LeadAddComponent_366434_onClick2_, "LeadAdd", "CustomerUpdatePost", "", "7d969ddf-5801-4eb6-b92b-12be35bdd565", "837957", null, "right", "true", "80%", "100vh", true, false);

		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

            
            return isErrorOccurred;
        }
		LeadAddComponent_366434_onClick2_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
KuikaAppManager.showSpinner(this);

				formVars.leadadd_410287_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetCustomerById !== undefined ? (stateVars.TM_GetCustomerById?.length > 0 ? stateVars.TM_GetCustomerById[0].adSoyad : null) : (this.state.TM_GetCustomerById?.length > 0 ? this.state.TM_GetCustomerById[0].adSoyad : null)));

				formVars.leadadd_683308_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetCustomerById !== undefined ? (stateVars.TM_GetCustomerById?.length > 0 ? stateVars.TM_GetCustomerById[0].tcKimlikNo : null) : (this.state.TM_GetCustomerById?.length > 0 ? this.state.TM_GetCustomerById[0].tcKimlikNo : null)));

				formVars.leadadd_381076_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetCustomerById !== undefined ? (stateVars.TM_GetCustomerById?.length > 0 ? stateVars.TM_GetCustomerById[0].telefonNo : null) : (this.state.TM_GetCustomerById?.length > 0 ? this.state.TM_GetCustomerById[0].telefonNo : null)));

				formVars.leadadd_496941_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetCustomerById !== undefined ? (stateVars.TM_GetCustomerById?.length > 0 ? stateVars.TM_GetCustomerById[0].email : null) : (this.state.TM_GetCustomerById?.length > 0 ? this.state.TM_GetCustomerById[0].email : null)));

				formVars.leadadd_826540_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetCustomerById !== undefined ? (stateVars.TM_GetCustomerById?.length > 0 ? stateVars.TM_GetCustomerById[0].sehir : null) : (this.state.TM_GetCustomerById?.length > 0 ? this.state.TM_GetCustomerById[0].sehir : null)));


		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

            
            return isErrorOccurred;
        }





    LeadAddComponent_931332_onChange = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
		KuikaAppManager.increaseServerRequestCount();

        let localVar = {
				Id_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "leadadd_931332_value", "value", "TM_GetReferanceByCurrAccCode", "id", "id")), "Guid")
        }

		KuikaAppManager.showSpinner(this);
		
        if (true) {
        KuikaAppManager.showSpinner(this);
        }
        let result = await KuikaAppManager.ApiRequest(this, "LeadAdd/LeadAddComponent_931332_onChange", localVar)
        if (!KMainFunctions.IsResStatus2XX(result)) return true;

			stateVars.TM_GetReferenceCustomerById = result?.data.tM_GetReferenceCustomerById;
			formVars.leadadd_667900_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetReferenceCustomerById !== undefined ? (stateVars.TM_GetReferenceCustomerById?.length > 0 ? stateVars.TM_GetReferenceCustomerById[0].referenceName : null) : (this.state.TM_GetReferenceCustomerById?.length > 0 ? this.state.TM_GetReferenceCustomerById[0].referenceName : null)));
			formVars.leadadd_729604_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetReferenceCustomerById !== undefined ? (stateVars.TM_GetReferenceCustomerById?.length > 0 ? stateVars.TM_GetReferenceCustomerById[0].referenceLastName : null) : (this.state.TM_GetReferenceCustomerById?.length > 0 ? this.state.TM_GetReferenceCustomerById[0].referenceLastName : null)));
			formVars.leadadd_513812_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetReferenceCustomerById !== undefined ? (stateVars.TM_GetReferenceCustomerById?.length > 0 ? stateVars.TM_GetReferenceCustomerById[0].referenceNationalID : null) : (this.state.TM_GetReferenceCustomerById?.length > 0 ? this.state.TM_GetReferenceCustomerById[0].referenceNationalID : null)));
			formVars.leadadd_293890_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetReferenceCustomerById !== undefined ? (stateVars.TM_GetReferenceCustomerById?.length > 0 ? stateVars.TM_GetReferenceCustomerById[0].referencePhone : null) : (this.state.TM_GetReferenceCustomerById?.length > 0 ? this.state.TM_GetReferenceCustomerById[0].referencePhone : null)));
			stateVars.isComp357309Visible = ((ReactSystemFunctions.isNotEmpty(ReactSystemFunctions.toString(this, (stateVars.TM_GetReferenceCustomerById !== undefined ? (stateVars.TM_GetReferenceCustomerById?.length > 0 ? stateVars.TM_GetReferenceCustomerById[0].referenceNationalID : null) : (this.state.TM_GetReferenceCustomerById?.length > 0 ? this.state.TM_GetReferenceCustomerById[0].referenceNationalID : null))), ReactSystemFunctions.convertToTypeByName("True", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp907885Visible = ((ReactSystemFunctions.isNotEmpty(ReactSystemFunctions.toString(this, (stateVars.TM_GetReferenceCustomerById !== undefined ? (stateVars.TM_GetReferenceCustomerById?.length > 0 ? stateVars.TM_GetReferenceCustomerById[0].referencePhone : null) : (this.state.TM_GetReferenceCustomerById?.length > 0 ? this.state.TM_GetReferenceCustomerById[0].referencePhone : null))), ReactSystemFunctions.convertToTypeByName("True", "string"))) === true ? "visible" : "hidden")
			this.props.form?.setFieldsValue(formVars);
			
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.LeadAddComponent_931332_onChange1_();
                  resolve();
                });
          })



        
        KuikaAppManager.hideSpinner(this);
        return isErrorOccurred;
    }
		LeadAddComponent_931332_onChange1_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }

				stateVars.isComp875547Visible = ((ReactSystemFunctions.isNotEmpty(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "leadadd_931332_value", "value", "TM_GetReferanceByCurrAccCode", "id", "contactID")), ReactSystemFunctions.convertToTypeByName("True", "string"))) === true ? "visible" : "hidden")
				formVars.leadadd_667900_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetReferenceCustomerById !== undefined ? (stateVars.TM_GetReferenceCustomerById?.length > 0 ? stateVars.TM_GetReferenceCustomerById[0].referenceName : null) : (this.state.TM_GetReferenceCustomerById?.length > 0 ? this.state.TM_GetReferenceCustomerById[0].referenceName : null)));

				formVars.leadadd_729604_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetReferenceCustomerById !== undefined ? (stateVars.TM_GetReferenceCustomerById?.length > 0 ? stateVars.TM_GetReferenceCustomerById[0].referenceLastName : null) : (this.state.TM_GetReferenceCustomerById?.length > 0 ? this.state.TM_GetReferenceCustomerById[0].referenceLastName : null)));

				formVars.leadadd_513812_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetReferenceCustomerById !== undefined ? (stateVars.TM_GetReferenceCustomerById?.length > 0 ? stateVars.TM_GetReferenceCustomerById[0].referenceNationalID : null) : (this.state.TM_GetReferenceCustomerById?.length > 0 ? this.state.TM_GetReferenceCustomerById[0].referenceNationalID : null)));

				formVars.leadadd_293890_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetReferenceCustomerById !== undefined ? (stateVars.TM_GetReferenceCustomerById?.length > 0 ? stateVars.TM_GetReferenceCustomerById[0].referencePhone : null) : (this.state.TM_GetReferenceCustomerById?.length > 0 ? this.state.TM_GetReferenceCustomerById[0].referencePhone : null)));


		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

            
            return isErrorOccurred;
        }




		LeadAddComponent_407641_onClick = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
KuikaAppManager.showSpinner(this);

					KuikaAppManager.prepareForNavigation();
						KuikaAppManager.addToPageInputVariables("ReferanceCreatePost", "CustomerId", ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "leadadd_999965_value", "value", "TM_GetCustomerByName", "id", "id")), "Guid"));

				stateVars.NAVIGATE = await ReactSystemFunctions.navigate(this, undefined, "LeadAdd", "ReferanceCreatePost", "", "7d969ddf-5801-4eb6-b92b-12be35bdd565", "62029", null, "right", "true", "80%", "100vh", true, false);

		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

            
            return isErrorOccurred;
        }


    LeadAddComponent_36755_onClick = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
		KuikaAppManager.increaseServerRequestCount();

        let localVar = {
				CurrAccCode_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "leadadd_931332_value", "value", "TM_GetReferanceByCurrAccCode", "id", "currAccCode")), "string")
        }

		KuikaAppManager.showSpinner(this);
		
        if (true) {
        KuikaAppManager.showSpinner(this);
        }
        let result = await KuikaAppManager.ApiRequest(this, "LeadAdd/LeadAddComponent_36755_onClick", localVar)
        if (!KMainFunctions.IsResStatus2XX(result)) return true;

			stateVars.TM_GetReferanceByCurrAccCode = result?.data.tM_GetReferanceByCurrAccCode;
			
			formVars.leadadd_931332_options = stateVars.TM_GetReferanceByCurrAccCode;
			this.props.form?.setFieldsValue(formVars);
			
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.LeadAddComponent_36755_onClick1_();
                  resolve();
                });
          })



        
        KuikaAppManager.hideSpinner(this);
        return isErrorOccurred;
    }
		LeadAddComponent_36755_onClick1_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }

					KuikaAppManager.prepareForNavigation();
						KuikaAppManager.addToPageInputVariables("CustomerDetailInfo", "customerCode", ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, (stateVars.TM_GetReferanceByCurrAccCode !== undefined ? (stateVars.TM_GetReferanceByCurrAccCode?.length > 0 ? stateVars.TM_GetReferanceByCurrAccCode[0].currAccCode : null) : (this.state.TM_GetReferanceByCurrAccCode?.length > 0 ? this.state.TM_GetReferanceByCurrAccCode[0].currAccCode : null))), "string"));
						KuikaAppManager.addToPageInputVariables("CustomerDetailInfo", "CustomerId", ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, (stateVars.TM_GetReferanceByCurrAccCode !== undefined ? (stateVars.TM_GetReferanceByCurrAccCode?.length > 0 ? stateVars.TM_GetReferanceByCurrAccCode[0].customerId : null) : (this.state.TM_GetReferanceByCurrAccCode?.length > 0 ? this.state.TM_GetReferanceByCurrAccCode[0].customerId : null))), "Guid"));

				stateVars.NAVIGATE = await ReactSystemFunctions.navigate(this, this.LeadAddComponent_36755_onClick2_, "LeadAdd", "CustomerDetailInfo", "", "7d969ddf-5801-4eb6-b92b-12be35bdd565", "966643", null, "right", "true", "80%", "100vh", true, false);

		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

            
            return isErrorOccurred;
        }
		LeadAddComponent_36755_onClick2_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
KuikaAppManager.showSpinner(this);

				
				stateVars.dataSource_931332 = stateVars.TM_GetReferanceByCurrAccCode ?? this.state.TM_GetReferanceByCurrAccCode;
				stateVars.dataSource_931332 = stateVars.TM_GetReferanceByCurrAccCode ?? this.state.TM_GetReferanceByCurrAccCode;

		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

            
            return isErrorOccurred;
        }





    LeadAddComponent_561793_onClick = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
		KuikaAppManager.increaseServerRequestCount();

        let localVar = {
				CurrAccCode_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "leadadd_931332_value", "value", "TM_GetReferanceByCurrAccCode", "id", "currAccCode")), "string")
        }

		KuikaAppManager.showSpinner(this);
		
        if (true) {
        KuikaAppManager.showSpinner(this);
        }
        let result = await KuikaAppManager.ApiRequest(this, "LeadAdd/LeadAddComponent_561793_onClick", localVar)
        if (!KMainFunctions.IsResStatus2XX(result)) return true;

			stateVars.TM_GetReferanceByCurrAccCode = result?.data.tM_GetReferanceByCurrAccCode;
			
			formVars.leadadd_931332_options = stateVars.TM_GetReferanceByCurrAccCode;
			this.props.form?.setFieldsValue(formVars);
			
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.LeadAddComponent_561793_onClick1_();
                  resolve();
                });
          })



        
        KuikaAppManager.hideSpinner(this);
        return isErrorOccurred;
    }
		LeadAddComponent_561793_onClick1_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }

					KuikaAppManager.prepareForNavigation();
						KuikaAppManager.addToPageInputVariables("CustomerDetailPage", "customerCode", ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, (stateVars.TM_GetReferanceByCurrAccCode !== undefined ? (stateVars.TM_GetReferanceByCurrAccCode?.length > 0 ? stateVars.TM_GetReferanceByCurrAccCode[0].currAccCode : null) : (this.state.TM_GetReferanceByCurrAccCode?.length > 0 ? this.state.TM_GetReferanceByCurrAccCode[0].currAccCode : null))), "string"));
						KuikaAppManager.addToPageInputVariables("CustomerDetailPage", "CustomerId", ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, (stateVars.TM_GetReferanceByCurrAccCode !== undefined ? (stateVars.TM_GetReferanceByCurrAccCode?.length > 0 ? stateVars.TM_GetReferanceByCurrAccCode[0].customerId : null) : (this.state.TM_GetReferanceByCurrAccCode?.length > 0 ? this.state.TM_GetReferanceByCurrAccCode[0].customerId : null))), "Guid"));

				stateVars.NAVIGATE = await ReactSystemFunctions.navigate(this, this.LeadAddComponent_561793_onClick2_, "LeadAdd", "CustomerDetailPage", "", "7d969ddf-5801-4eb6-b92b-12be35bdd565", "276990", null, "right", "true", "80%", "100vh", true, false);

		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

            
            return isErrorOccurred;
        }
		LeadAddComponent_561793_onClick2_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
KuikaAppManager.showSpinner(this);

				
				stateVars.dataSource_931332 = stateVars.TM_GetReferanceByCurrAccCode ?? this.state.TM_GetReferanceByCurrAccCode;
				stateVars.dataSource_931332 = stateVars.TM_GetReferanceByCurrAccCode ?? this.state.TM_GetReferanceByCurrAccCode;

		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

            
            return isErrorOccurred;
        }





    LeadAddComponent_468567_onChange = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
		KuikaAppManager.increaseServerRequestCount();

        let localVar = {
				BrandName_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "leadadd_468567_value", "value", "TM_GetProductBrand", "brand", "brand")), "string")
        }

		KuikaAppManager.showSpinner(this);
		
        if (true) {
        KuikaAppManager.showSpinner(this);
        }
        let result = await KuikaAppManager.ApiRequest(this, "LeadAdd/LeadAddComponent_468567_onChange", localVar)
        if (!KMainFunctions.IsResStatus2XX(result)) return true;

			stateVars.TM_GetProductReferance = result?.data.tM_GetProductReferance;
			
			formVars.leadadd_984_options = stateVars.TM_GetProductReferance;
			this.props.form?.setFieldsValue(formVars);
			
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.LeadAddComponent_468567_onChange1_();
                  resolve();
                });
          })



        
        KuikaAppManager.hideSpinner(this);
        return isErrorOccurred;
    }
		LeadAddComponent_468567_onChange1_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }

				stateVars.SetValueOf = await ReactSystemFunctions.setValueOf(this, ReactSystemFunctions.convertToTypeByName("leadadd_984_value", "string"), "", null, "Referance");
				stateVars.SetValueOf = await ReactSystemFunctions.setValueOf(this, ReactSystemFunctions.convertToTypeByName("leadadd_340910_value", "string"), "", null, "Dial");
				stateVars.SetValueOf = await ReactSystemFunctions.setValueOf(this, ReactSystemFunctions.convertToTypeByName("leadadd_4804_value", "string"), "", null, "Bracelet");

		this.props.form?.setFieldsValue(formVars);
		
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.LeadAddComponent_468567_onChange2_();
                  resolve();
                });
          })

            
            return isErrorOccurred;
        }
		LeadAddComponent_468567_onChange2_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
if (ReactSystemFunctions.isEmpty(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "leadadd_4804_value", "value", "TM_GetProductBracelet", "bracelet", "bracelet")), true)) {
            
				stateVars.ChangeVisibilityOf = await ReactSystemFunctions.changeVisibilityOf(this, ReactSystemFunctions.convertToTypeByName("isComp528620Visible", "string"), ReactSystemFunctions.convertToTypeByName("hidden", "string"));

		this.props.form?.setFieldsValue(formVars);
		
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.LeadAddComponent_468567_onChange3_();
                  resolve();
                });
          })

        } else {
            
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.LeadAddComponent_468567_onChange3_();
                  resolve();
                });
          })
        }

            
            return isErrorOccurred;
        }
		LeadAddComponent_468567_onChange3_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }

				
				stateVars.dataSource_984 = stateVars.TM_GetProductReferance ?? this.state.TM_GetProductReferance;
				stateVars.dataSource_984 = stateVars.TM_GetProductReferance ?? this.state.TM_GetProductReferance;

		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

            
            return isErrorOccurred;
        }






    LeadAddComponent_984_onChange = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;

			validations.push({ 
				isValid: ReactSystemFunctions.isNotEmpty(ReactSystemFunctions.value(this, "leadadd_984_value", "value", "TM_GetProductReferance", "referance", "referance"), null),
				message: "Bu alan boş bırakılamaz!",
				formName: "leadadd_984_value",
				condition: true
			} as IValidationData);

validations.forEach((validation) => {
            if (validation.message === "Geçerli bir mail adresi giriniz.") {
                validation.message = ReactSystemFunctions.getEmailValidationMessage()
            }
        })

		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
		KuikaAppManager.increaseServerRequestCount();

        let localVar = {
				Brand_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "leadadd_468567_value", "value", "TM_GetProductBrand", "brand", "brand")), "string"),
				Referance_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "leadadd_984_value", "value", "TM_GetProductReferance", "referance", "referance")), "string")
        }

		KuikaAppManager.showSpinner(this);
		
        if (true) {
        KuikaAppManager.showSpinner(this);
        }
        let result = await KuikaAppManager.ApiRequest(this, "LeadAdd/LeadAddComponent_984_onChange", localVar)
        if (!KMainFunctions.IsResStatus2XX(result)) return true;

			stateVars.TM_GetProductDial = result?.data.tM_GetProductDial;
			
			formVars.leadadd_340910_options = stateVars.TM_GetProductDial;
			this.props.form?.setFieldsValue(formVars);
			
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.LeadAddComponent_984_onChange1_();
                  resolve();
                });
          })



        
        KuikaAppManager.hideSpinner(this);
        return isErrorOccurred;
    }
		LeadAddComponent_984_onChange1_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
if (ReactSystemFunctions.isEmpty(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "leadadd_4804_value", "value", "TM_GetProductBracelet", "bracelet", "bracelet")), true)) {
            
				stateVars.ChangeVisibilityOf = await ReactSystemFunctions.changeVisibilityOf(this, ReactSystemFunctions.convertToTypeByName("isComp528620Visible", "string"), ReactSystemFunctions.convertToTypeByName("hidden", "string"));

		this.props.form?.setFieldsValue(formVars);
		
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.LeadAddComponent_984_onChange2_();
                  resolve();
                });
          })

        } else {
            
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.LeadAddComponent_984_onChange2_();
                  resolve();
                });
          })
        }

            
            return isErrorOccurred;
        }
		LeadAddComponent_984_onChange2_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }

				stateVars.SetValueOf = await ReactSystemFunctions.setValueOf(this, ReactSystemFunctions.convertToTypeByName("leadadd_340910_value", "string"), "", null, "Dial");
				stateVars.SetValueOf = await ReactSystemFunctions.setValueOf(this, ReactSystemFunctions.convertToTypeByName("leadadd_4804_value", "string"), "", null, "Bracelet");
				
				stateVars.dataSource_340910 = stateVars.TM_GetProductDial ?? this.state.TM_GetProductDial;
				stateVars.dataSource_340910 = stateVars.TM_GetProductDial ?? this.state.TM_GetProductDial;

		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

            
            return isErrorOccurred;
        }





    LeadAddComponent_340910_onChange = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;

			validations.push({ 
				isValid: ReactSystemFunctions.isNotEmpty(ReactSystemFunctions.value(this, "leadadd_984_value", "value", "TM_GetProductReferance", "referance", "referance"), null),
				message: "Bu alan boş bırakılamaz!",
				formName: "leadadd_984_value",
				condition: true
			} as IValidationData);

validations.forEach((validation) => {
            if (validation.message === "Geçerli bir mail adresi giriniz.") {
                validation.message = ReactSystemFunctions.getEmailValidationMessage()
            }
        })
			validations.push({ 
				isValid: ReactSystemFunctions.isNotEmpty(ReactSystemFunctions.value(this, "leadadd_340910_value", "value", "TM_GetProductDial", "dial", "dial"), null),
				message: "Bu alan boş bırakılamaz!",
				formName: "leadadd_340910_value",
				condition: true
			} as IValidationData);

validations.forEach((validation) => {
            if (validation.message === "Geçerli bir mail adresi giriniz.") {
                validation.message = ReactSystemFunctions.getEmailValidationMessage()
            }
        })

		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
		KuikaAppManager.increaseServerRequestCount();

        let localVar = {
				Brand_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "leadadd_468567_value", "value", "TM_GetProductBrand", "brand", "brand")), "string"),
				Referance_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "leadadd_984_value", "value", "TM_GetProductReferance", "referance", "referance")), "string"),
				Dial_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "leadadd_340910_value", "value", "TM_GetProductDial", "dial", "dial")), "string")
        }

		KuikaAppManager.showSpinner(this);
		
        if (true) {
        KuikaAppManager.showSpinner(this);
        }
        let result = await KuikaAppManager.ApiRequest(this, "LeadAdd/LeadAddComponent_340910_onChange", localVar)
        if (!KMainFunctions.IsResStatus2XX(result)) return true;

			stateVars.TM_GetProductBracelet = result?.data.tM_GetProductBracelet;
			
			formVars.leadadd_4804_options = stateVars.TM_GetProductBracelet;
			this.props.form?.setFieldsValue(formVars);
			
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.LeadAddComponent_340910_onChange1_();
                  resolve();
                });
          })



        
        KuikaAppManager.hideSpinner(this);
        return isErrorOccurred;
    }
		LeadAddComponent_340910_onChange1_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
if (ReactSystemFunctions.isEmpty(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "leadadd_4804_value", "value", "TM_GetProductBracelet", "bracelet", "bracelet")), true)) {
            
				stateVars.ChangeVisibilityOf = await ReactSystemFunctions.changeVisibilityOf(this, ReactSystemFunctions.convertToTypeByName("isComp528620Visible", "string"), ReactSystemFunctions.convertToTypeByName("hidden", "string"));

		this.props.form?.setFieldsValue(formVars);
		
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.LeadAddComponent_340910_onChange2_();
                  resolve();
                });
          })

        } else {
            
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.LeadAddComponent_340910_onChange2_();
                  resolve();
                });
          })
        }

            
            return isErrorOccurred;
        }
		LeadAddComponent_340910_onChange2_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }

				stateVars.SetValueOf = await ReactSystemFunctions.setValueOf(this, ReactSystemFunctions.convertToTypeByName("leadadd_4804_value", "string"), "", null, "Bracelet");
				
				stateVars.dataSource_4804 = stateVars.TM_GetProductBracelet ?? this.state.TM_GetProductBracelet;
				stateVars.dataSource_4804 = stateVars.TM_GetProductBracelet ?? this.state.TM_GetProductBracelet;

		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

            
            return isErrorOccurred;
        }





    LeadAddComponent_4804_onChange = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;

			validations.push({ 
				isValid: ReactSystemFunctions.isNotEmpty(ReactSystemFunctions.value(this, "leadadd_984_value", "value", "TM_GetProductReferance", "referance", "referance"), null),
				message: "Bu alan boş bırakılamaz!",
				formName: "leadadd_984_value",
				condition: true
			} as IValidationData);

validations.forEach((validation) => {
            if (validation.message === "Geçerli bir mail adresi giriniz.") {
                validation.message = ReactSystemFunctions.getEmailValidationMessage()
            }
        })
			validations.push({ 
				isValid: ReactSystemFunctions.isNotEmpty(ReactSystemFunctions.value(this, "leadadd_340910_value", "value", "TM_GetProductDial", "dial", "dial"), null),
				message: "Bu alan boş bırakılamaz!",
				formName: "leadadd_340910_value",
				condition: true
			} as IValidationData);

validations.forEach((validation) => {
            if (validation.message === "Geçerli bir mail adresi giriniz.") {
                validation.message = ReactSystemFunctions.getEmailValidationMessage()
            }
        })
			validations.push({ 
				isValid: ReactSystemFunctions.isNotEmpty(ReactSystemFunctions.value(this, "leadadd_4804_value", "value", "TM_GetProductBracelet", "bracelet", "bracelet"), null),
				message: "Bu alan boş bırakılamaz!",
				formName: "leadadd_4804_value",
				condition: true
			} as IValidationData);

validations.forEach((validation) => {
            if (validation.message === "Geçerli bir mail adresi giriniz.") {
                validation.message = ReactSystemFunctions.getEmailValidationMessage()
            }
        })

		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
		KuikaAppManager.increaseServerRequestCount();

        let localVar = {
				Brand_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "leadadd_468567_value", "value", "TM_GetProductBrand", "brand", "brand")), "string"),
				Referance_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "leadadd_984_value", "value", "TM_GetProductReferance", "referance", "referance")), "string"),
				Dial_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "leadadd_340910_value", "value", "TM_GetProductDial", "dial", "dial")), "string"),
				Bracelet_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "leadadd_4804_value", "value", "TM_GetProductBracelet", "bracelet", "bracelet")), "string")
        }

		KuikaAppManager.showSpinner(this);
		
        if (true) {
        KuikaAppManager.showSpinner(this);
        }
        let result = await KuikaAppManager.ApiRequest(this, "LeadAdd/LeadAddComponent_4804_onChange", localVar)
        if (!KMainFunctions.IsResStatus2XX(result)) return true;

			stateVars.TM_GetProduct = result?.data.tM_GetProduct;
			formVars.leadadd_782562_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetProduct !== undefined ? (stateVars.TM_GetProduct?.length > 0 ? stateVars.TM_GetProduct[0].referance : null) : (this.state.TM_GetProduct?.length > 0 ? this.state.TM_GetProduct[0].referance : null)));
			formVars.leadadd_498343_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetProduct !== undefined ? (stateVars.TM_GetProduct?.length > 0 ? stateVars.TM_GetProduct[0].categoryName : null) : (this.state.TM_GetProduct?.length > 0 ? this.state.TM_GetProduct[0].categoryName : null)));
			stateVars.isComp498343Visible = ((ReactSystemFunctions.isNotEmpty(ReactSystemFunctions.toString(this, (stateVars.TM_GetProduct !== undefined ? (stateVars.TM_GetProduct?.length > 0 ? stateVars.TM_GetProduct[0].categoryName : null) : (this.state.TM_GetProduct?.length > 0 ? this.state.TM_GetProduct[0].categoryName : null))), ReactSystemFunctions.convertToTypeByName("True", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp575180Visible = ((ReactSystemFunctions.isEmpty(ReactSystemFunctions.toString(this, (stateVars.TM_GetProduct !== undefined ? (stateVars.TM_GetProduct?.length > 0 ? stateVars.TM_GetProduct[0].categoryName : null) : (this.state.TM_GetProduct?.length > 0 ? this.state.TM_GetProduct[0].categoryName : null))), ReactSystemFunctions.convertToTypeByName("True", "string"))) === true ? "visible" : "hidden")
			this.props.form?.setFieldsValue(formVars);
			
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.LeadAddComponent_4804_onChange1_();
                  resolve();
                });
          })



        
        KuikaAppManager.hideSpinner(this);
        return isErrorOccurred;
    }
		LeadAddComponent_4804_onChange1_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
if (ReactSystemFunctions.isEmpty(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "leadadd_4804_value", "value", "TM_GetProductBracelet", "bracelet", "bracelet")), true)) {
            
				stateVars.ChangeVisibilityOf = await ReactSystemFunctions.changeVisibilityOf(this, ReactSystemFunctions.convertToTypeByName("isComp528620Visible", "string"), ReactSystemFunctions.convertToTypeByName("hidden", "string"));

		this.props.form?.setFieldsValue(formVars);
		
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.LeadAddComponent_4804_onChange2_();
                  resolve();
                });
          })

        } else {
            
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.LeadAddComponent_4804_onChange2_();
                  resolve();
                });
          })
        }

            
            return isErrorOccurred;
        }
    LeadAddComponent_4804_onChange2_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;

			validations.push({ 
				isValid: ReactSystemFunctions.isNotEmpty(ReactSystemFunctions.value(this, "leadadd_999965_value", "value", "TM_GetCustomerByName", "id", "id"), null),
				message: "Bu alan boş bırakılamaz!",
				formName: "leadadd_999965_value",
				condition: true
			} as IValidationData);

validations.forEach((validation) => {
            if (validation.message === "Geçerli bir mail adresi giriniz.") {
                validation.message = ReactSystemFunctions.getEmailValidationMessage()
            }
        })

		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
		KuikaAppManager.increaseServerRequestCount();

        let localVar = {
				CustomerId_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "leadadd_999965_value", "value", "TM_GetCustomerByName", "id", "id")), "Guid")
        }

		
        if (true) {
        KuikaAppManager.showSpinner(this);
        }
        let result = await KuikaAppManager.ApiRequest(this, "LeadAdd/LeadAddComponent_4804_onChange2_", localVar)
        if (!KMainFunctions.IsResStatus2XX(result)) return true;

			stateVars.TM_LeadCheckCustomerProduct = result?.data.tM_LeadCheckCustomerProduct;
			stateVars.isComp283519Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, (stateVars.TM_LeadCheckCustomerProduct !== undefined ? (stateVars.TM_LeadCheckCustomerProduct?.length > 0 ? stateVars.TM_LeadCheckCustomerProduct[0].leadExists : null) : (this.state.TM_LeadCheckCustomerProduct?.length > 0 ? this.state.TM_LeadCheckCustomerProduct[0].leadExists : null))), ReactSystemFunctions.convertToTypeByName("True", "string"))) === true ? "visible" : "hidden")
			this.props.form?.setFieldsValue(formVars);
			
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.LeadAddComponent_4804_onChange3_();
                  resolve();
                });
          })



        
        KuikaAppManager.hideSpinner(this);
        return isErrorOccurred;
    }
		LeadAddComponent_4804_onChange3_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }

				stateVars.isComp528620Visible = ((ReactSystemFunctions.isNotEmpty(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "leadadd_4804_value", "value", "TM_GetProductBracelet", "bracelet", "bracelet")), ReactSystemFunctions.convertToTypeByName("True", "string"))) === true ? "visible" : "hidden")
				formVars.leadadd_782562_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetProduct !== undefined ? (stateVars.TM_GetProduct?.length > 0 ? stateVars.TM_GetProduct[0].referance : null) : (this.state.TM_GetProduct?.length > 0 ? this.state.TM_GetProduct[0].referance : null)));

				formVars.leadadd_498343_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetProduct !== undefined ? (stateVars.TM_GetProduct?.length > 0 ? stateVars.TM_GetProduct[0].categoryName : null) : (this.state.TM_GetProduct?.length > 0 ? this.state.TM_GetProduct[0].categoryName : null)));


		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

            
            return isErrorOccurred;
        }







		LeadAddComponent_433970_onClick = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
KuikaAppManager.showSpinner(this);

					KuikaAppManager.prepareForNavigation();

				stateVars.NAVIGATE = await ReactSystemFunctions.navigate(this, undefined, "LeadAdd", "ContactSourceAdd", "", "7d969ddf-5801-4eb6-b92b-12be35bdd565", "539902", null, "right", "true", "60%", "100vh", true, false);

		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

            
            return isErrorOccurred;
        }


    LeadAddComponent_124116_onClick = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
		KuikaAppManager.increaseServerRequestCount();

        let localVar = {
				SessionCode_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, (stateVars.TM_LeadAltModelTemp_GenerateSessionCode !== undefined ? (stateVars.TM_LeadAltModelTemp_GenerateSessionCode?.length > 0 ? stateVars.TM_LeadAltModelTemp_GenerateSessionCode[0].sessionCode : null) : (this.state.TM_LeadAltModelTemp_GenerateSessionCode?.length > 0 ? this.state.TM_LeadAltModelTemp_GenerateSessionCode[0].sessionCode : null))), "string")
        }

		KuikaAppManager.showSpinner(this);
		
        if (true) {
        KuikaAppManager.showSpinner(this);
        }
        let result = await KuikaAppManager.ApiRequest(this, "LeadAdd/LeadAddComponent_124116_onClick", localVar)
        if (!KMainFunctions.IsResStatus2XX(result)) return true;

			stateVars.TM_LeadAltModelTemp_ListBySession = result?.data.tM_LeadAltModelTemp_ListBySession;
			
			this.props.form?.setFieldsValue(formVars);
			
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.LeadAddComponent_124116_onClick1_();
                  resolve();
                });
          })



        
        KuikaAppManager.hideSpinner(this);
        return isErrorOccurred;
    }
		LeadAddComponent_124116_onClick1_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }

				stateVars.ChangeVisibilityOf = await ReactSystemFunctions.changeVisibilityOf(this, ReactSystemFunctions.convertToTypeByName("isComp542957Visible", "string"), ReactSystemFunctions.convertToTypeByName("visible", "string"));
				stateVars.ChangeVisibilityOf = await ReactSystemFunctions.changeVisibilityOf(this, ReactSystemFunctions.convertToTypeByName("isComp124116Visible", "string"), ReactSystemFunctions.convertToTypeByName("hidden", "string"));
				stateVars.ChangeVisibilityOf = await ReactSystemFunctions.changeVisibilityOf(this, ReactSystemFunctions.convertToTypeByName("isComp260108Visible", "string"), ReactSystemFunctions.convertToTypeByName("visible", "string"));
				
				stateVars.dataSource_674923 = stateVars.TM_LeadAltModelTemp_ListBySession ?? this.state.TM_LeadAltModelTemp_ListBySession;

		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

            
            return isErrorOccurred;
        }




    LeadAddComponent_228188_onChange = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
		KuikaAppManager.increaseServerRequestCount();

        let localVar = {
				BrandName_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "leadadd_228188_value", "value", "TM_GetProductBrandAlternatif", "brand", "brand")), "string")
        }

		KuikaAppManager.showSpinner(this);
		
        if (true) {
        KuikaAppManager.showSpinner(this);
        }
        let result = await KuikaAppManager.ApiRequest(this, "LeadAdd/LeadAddComponent_228188_onChange", localVar)
        if (!KMainFunctions.IsResStatus2XX(result)) return true;

			stateVars.TM_GetProductReferanceAlternatif = result?.data.tM_GetProductReferanceAlternatif;
			
			formVars.leadadd_622242_options = stateVars.TM_GetProductReferanceAlternatif;
			this.props.form?.setFieldsValue(formVars);
			
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.LeadAddComponent_228188_onChange1_();
                  resolve();
                });
          })



        
        KuikaAppManager.hideSpinner(this);
        return isErrorOccurred;
    }
		LeadAddComponent_228188_onChange1_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }

				
				stateVars.dataSource_622242 = stateVars.TM_GetProductReferanceAlternatif ?? this.state.TM_GetProductReferanceAlternatif;
				stateVars.dataSource_622242 = stateVars.TM_GetProductReferanceAlternatif ?? this.state.TM_GetProductReferanceAlternatif;

		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

            
            return isErrorOccurred;
        }




    LeadAddComponent_622242_onChange = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;

			validations.push({ 
				isValid: ReactSystemFunctions.isNotEmpty(ReactSystemFunctions.value(this, "leadadd_984_value", "value", "TM_GetProductReferance", "referance", "referance"), null),
				message: "Bu alan boş bırakılamaz!",
				formName: "leadadd_622242_value",
				condition: true
			} as IValidationData);

validations.forEach((validation) => {
            if (validation.message === "Geçerli bir mail adresi giriniz.") {
                validation.message = ReactSystemFunctions.getEmailValidationMessage()
            }
        })

		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
		KuikaAppManager.increaseServerRequestCount();

        let localVar = {
				Brand_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "leadadd_228188_value", "value", "TM_GetProductBrandAlternatif", "brand", "brand")), "string"),
				Referance_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "leadadd_622242_value", "value", "TM_GetProductReferanceAlternatif", "referance", "referance")), "string")
        }

		KuikaAppManager.showSpinner(this);
		
        if (true) {
        KuikaAppManager.showSpinner(this);
        }
        let result = await KuikaAppManager.ApiRequest(this, "LeadAdd/LeadAddComponent_622242_onChange", localVar)
        if (!KMainFunctions.IsResStatus2XX(result)) return true;

			stateVars.TM_GetProductDialAlternatif = result?.data.tM_GetProductDialAlternatif;
			
			formVars.leadadd_174761_options = stateVars.TM_GetProductDialAlternatif;
			this.props.form?.setFieldsValue(formVars);
			
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.LeadAddComponent_622242_onChange1_();
                  resolve();
                });
          })



        
        KuikaAppManager.hideSpinner(this);
        return isErrorOccurred;
    }
		LeadAddComponent_622242_onChange1_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }

				
				stateVars.dataSource_174761 = stateVars.TM_GetProductDialAlternatif ?? this.state.TM_GetProductDialAlternatif;
				stateVars.dataSource_174761 = stateVars.TM_GetProductDialAlternatif ?? this.state.TM_GetProductDialAlternatif;

		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

            
            return isErrorOccurred;
        }




    LeadAddComponent_174761_onChange = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;

			validations.push({ 
				isValid: ReactSystemFunctions.isNotEmpty(ReactSystemFunctions.value(this, "leadadd_984_value", "value", "TM_GetProductReferance", "referance", "referance"), null),
				message: "Bu alan boş bırakılamaz!",
				formName: "leadadd_622242_value",
				condition: true
			} as IValidationData);

validations.forEach((validation) => {
            if (validation.message === "Geçerli bir mail adresi giriniz.") {
                validation.message = ReactSystemFunctions.getEmailValidationMessage()
            }
        })
			validations.push({ 
				isValid: ReactSystemFunctions.isNotEmpty(ReactSystemFunctions.value(this, "leadadd_340910_value", "value", "TM_GetProductDial", "dial", "dial"), null),
				message: "Bu alan boş bırakılamaz!",
				formName: "leadadd_174761_value",
				condition: true
			} as IValidationData);

validations.forEach((validation) => {
            if (validation.message === "Geçerli bir mail adresi giriniz.") {
                validation.message = ReactSystemFunctions.getEmailValidationMessage()
            }
        })

		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
		KuikaAppManager.increaseServerRequestCount();

        let localVar = {
				Brand_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "leadadd_228188_value", "value", "TM_GetProductBrandAlternatif", "brand", "brand")), "string"),
				Referance_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "leadadd_622242_value", "value", "TM_GetProductReferanceAlternatif", "referance", "referance")), "string"),
				Dial_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "leadadd_174761_value", "value", "TM_GetProductDialAlternatif", "dial", "dial")), "string")
        }

		KuikaAppManager.showSpinner(this);
		
        if (true) {
        KuikaAppManager.showSpinner(this);
        }
        let result = await KuikaAppManager.ApiRequest(this, "LeadAdd/LeadAddComponent_174761_onChange", localVar)
        if (!KMainFunctions.IsResStatus2XX(result)) return true;

			stateVars.TM_GetProductBraceletAlternatif = result?.data.tM_GetProductBraceletAlternatif;
			
			formVars.leadadd_273530_options = stateVars.TM_GetProductBraceletAlternatif;
			this.props.form?.setFieldsValue(formVars);
			
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.LeadAddComponent_174761_onChange1_();
                  resolve();
                });
          })



        
        KuikaAppManager.hideSpinner(this);
        return isErrorOccurred;
    }
		LeadAddComponent_174761_onChange1_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }

				
				stateVars.dataSource_273530 = stateVars.TM_GetProductBraceletAlternatif ?? this.state.TM_GetProductBraceletAlternatif;
				stateVars.dataSource_273530 = stateVars.TM_GetProductBraceletAlternatif ?? this.state.TM_GetProductBraceletAlternatif;

		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

            
            return isErrorOccurred;
        }




    LeadAddComponent_273530_onChange = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;

			validations.push({ 
				isValid: ReactSystemFunctions.isNotEmpty(ReactSystemFunctions.value(this, "leadadd_984_value", "value", "TM_GetProductReferance", "referance", "referance"), null),
				message: "Bu alan boş bırakılamaz!",
				formName: "leadadd_622242_value",
				condition: true
			} as IValidationData);

validations.forEach((validation) => {
            if (validation.message === "Geçerli bir mail adresi giriniz.") {
                validation.message = ReactSystemFunctions.getEmailValidationMessage()
            }
        })
			validations.push({ 
				isValid: ReactSystemFunctions.isNotEmpty(ReactSystemFunctions.value(this, "leadadd_340910_value", "value", "TM_GetProductDial", "dial", "dial"), null),
				message: "Bu alan boş bırakılamaz!",
				formName: "leadadd_174761_value",
				condition: true
			} as IValidationData);

validations.forEach((validation) => {
            if (validation.message === "Geçerli bir mail adresi giriniz.") {
                validation.message = ReactSystemFunctions.getEmailValidationMessage()
            }
        })

		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
		KuikaAppManager.increaseServerRequestCount();

        let localVar = {
				Brand_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "leadadd_228188_value", "value", "TM_GetProductBrandAlternatif", "brand", "brand")), "string"),
				Referance_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "leadadd_622242_value", "value", "TM_GetProductReferanceAlternatif", "referance", "referance")), "string"),
				Dial_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "leadadd_174761_value", "value", "TM_GetProductDialAlternatif", "dial", "dial")), "string"),
				Bracelet_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "leadadd_273530_value", "value", "TM_GetProductBraceletAlternatif", "bracelet", "bracelet")), "string")
        }

		KuikaAppManager.showSpinner(this);
		
        if (true) {
        KuikaAppManager.showSpinner(this);
        }
        let result = await KuikaAppManager.ApiRequest(this, "LeadAdd/LeadAddComponent_273530_onChange", localVar)
        if (!KMainFunctions.IsResStatus2XX(result)) return true;

			stateVars.TM_GetProductForAltModel = result?.data.tM_GetProductForAltModel;
			this.props.form?.setFieldsValue(formVars);
			this.setState(stateVars);
			KuikaAppManager.hideSpinner(this);



        this.setPageInitLoaded(true);
        KuikaAppManager.hideSpinner(this);
        return isErrorOccurred;
    }



    LeadAddComponent_281129_onClick = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
		KuikaAppManager.increaseServerRequestCount();

        let localVar = {
				ProductId_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, (stateVars.TM_GetProduct !== undefined ? (stateVars.TM_GetProduct?.length > 0 ? stateVars.TM_GetProduct[0].id : null) : (this.state.TM_GetProduct?.length > 0 ? this.state.TM_GetProduct[0].id : null))), "Guid"),
				SelectedProductId_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, (stateVars.TM_GetProductForAltModel !== undefined ? (stateVars.TM_GetProductForAltModel?.length > 0 ? stateVars.TM_GetProductForAltModel[0].id : null) : (this.state.TM_GetProductForAltModel?.length > 0 ? this.state.TM_GetProductForAltModel[0].id : null))), "Guid"),
				SessionCode_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, (stateVars.TM_LeadAltModelTemp_GenerateSessionCode !== undefined ? (stateVars.TM_LeadAltModelTemp_GenerateSessionCode?.length > 0 ? stateVars.TM_LeadAltModelTemp_GenerateSessionCode[0].sessionCode : null) : (this.state.TM_LeadAltModelTemp_GenerateSessionCode?.length > 0 ? this.state.TM_LeadAltModelTemp_GenerateSessionCode[0].sessionCode : null))), "string")
        }

		KuikaAppManager.showSpinner(this);
		
        if (true) {
        KuikaAppManager.showSpinner(this);
        }
        let result = await KuikaAppManager.ApiRequest(this, "LeadAdd/LeadAddComponent_281129_onClick", localVar)
        if (!KMainFunctions.IsResStatus2XX(result)) return true;

			stateVars.TM_LeadAltModelTemp_Insert = result?.data.tM_LeadAltModelTemp_Insert;
			this.props.form?.setFieldsValue(formVars);
			
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.LeadAddComponent_281129_onClick1_();
                  resolve();
                });
          })



        
        KuikaAppManager.hideSpinner(this);
        return isErrorOccurred;
    }
		LeadAddComponent_281129_onClick1_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }

				stateVars.Notify = await ReactSystemFunctions.notify(this, ReactSystemFunctions.toString(this, (stateVars.TM_LeadAltModelTemp_Insert !== undefined ? (stateVars.TM_LeadAltModelTemp_Insert?.length > 0 ? stateVars.TM_LeadAltModelTemp_Insert[0].message : null) : (this.state.TM_LeadAltModelTemp_Insert?.length > 0 ? this.state.TM_LeadAltModelTemp_Insert[0].message : null))), ReactSystemFunctions.convertToTypeByName("default", "string"), ReactSystemFunctions.convertToTypeByName("top-center", "string"), 3, ReactSystemFunctions.convertToTypeByName("", "string"), ReactSystemFunctions.convertToTypeByName("", "string"), 0);

		this.props.form?.setFieldsValue(formVars);
		
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.LeadAddComponent_281129_onClick2_();
                  resolve();
                });
          })

            
            return isErrorOccurred;
        }
    LeadAddComponent_281129_onClick2_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
		KuikaAppManager.increaseServerRequestCount();

        let localVar = {
				SessionCode_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, (stateVars.TM_LeadAltModelTemp_GenerateSessionCode !== undefined ? (stateVars.TM_LeadAltModelTemp_GenerateSessionCode?.length > 0 ? stateVars.TM_LeadAltModelTemp_GenerateSessionCode[0].sessionCode : null) : (this.state.TM_LeadAltModelTemp_GenerateSessionCode?.length > 0 ? this.state.TM_LeadAltModelTemp_GenerateSessionCode[0].sessionCode : null))), "string")
        }

		
        if (true) {
        KuikaAppManager.showSpinner(this);
        }
        let result = await KuikaAppManager.ApiRequest(this, "LeadAdd/LeadAddComponent_281129_onClick2_", localVar)
        if (!KMainFunctions.IsResStatus2XX(result)) return true;

			stateVars.TM_LeadAltModelTemp_ListBySession = result?.data.tM_LeadAltModelTemp_ListBySession;
			
			this.props.form?.setFieldsValue(formVars);
			
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.LeadAddComponent_281129_onClick3_();
                  resolve();
                });
          })



        
        KuikaAppManager.hideSpinner(this);
        return isErrorOccurred;
    }
		LeadAddComponent_281129_onClick3_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }

				stateVars.SetValueOf = await ReactSystemFunctions.setValueOf(this, ReactSystemFunctions.convertToTypeByName("leadadd_228188_value", "string"), "", null, "Brand");
				stateVars.SetValueOf = await ReactSystemFunctions.setValueOf(this, ReactSystemFunctions.convertToTypeByName("leadadd_622242_value", "string"), "", null, "Referance");
				stateVars.SetValueOf = await ReactSystemFunctions.setValueOf(this, ReactSystemFunctions.convertToTypeByName("leadadd_174761_value", "string"), "", null, "Dial");
				stateVars.SetValueOf = await ReactSystemFunctions.setValueOf(this, ReactSystemFunctions.convertToTypeByName("leadadd_273530_value", "string"), "", null, "Bracelet");
				
				stateVars.dataSource_674923 = stateVars.TM_LeadAltModelTemp_ListBySession ?? this.state.TM_LeadAltModelTemp_ListBySession;

		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

            
            return isErrorOccurred;
        }







		LeadAddComponent_947787_onClick = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
KuikaAppManager.showSpinner(this);

					KuikaAppManager.prepareForNavigation();
						KuikaAppManager.addToPageInputVariables("AlternativeInfo", "ProductId", ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, "leadadd_674923_value", "productId"), "Guid"));
						KuikaAppManager.addToPageInputVariables("AlternativeInfo", "KUserId", ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "leadadd_572982_value", "value", "GetSalesPersonByStore", "kuserID", "kuserID")), "Guid"));

				stateVars.NAVIGATE = await ReactSystemFunctions.navigate(this, undefined, "LeadAdd", "AlternativeInfo", "", "9924ef5f-4b84-4200-b624-8d76348c7686", "271368", null, null, "true", "800px", "600px", true, false);

		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

            
            return isErrorOccurred;
        }


    LeadAddComponent_194647_onClick = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
		KuikaAppManager.increaseServerRequestCount();

        let localVar = {
				Id_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, "leadadd_674923_value", "id"), "Guid"),
				SessionCode_1: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, (stateVars.TM_LeadAltModelTemp_GenerateSessionCode !== undefined ? (stateVars.TM_LeadAltModelTemp_GenerateSessionCode?.length > 0 ? stateVars.TM_LeadAltModelTemp_GenerateSessionCode[0].sessionCode : null) : (this.state.TM_LeadAltModelTemp_GenerateSessionCode?.length > 0 ? this.state.TM_LeadAltModelTemp_GenerateSessionCode[0].sessionCode : null))), "string")
        }

		KuikaAppManager.showSpinner(this);
		
        if (true) {
        KuikaAppManager.showSpinner(this);
        }
        let result = await KuikaAppManager.ApiRequest(this, "LeadAdd/LeadAddComponent_194647_onClick", localVar)
        if (!KMainFunctions.IsResStatus2XX(result)) return true;

			stateVars.TM_LeadAltModelTemp_Delete = result?.data.tM_LeadAltModelTemp_Delete;
			stateVars.TM_LeadAltModelTemp_ListBySession = result?.data.tM_LeadAltModelTemp_ListBySession;
			
			this.props.form?.setFieldsValue(formVars);
			
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.LeadAddComponent_194647_onClick1_();
                  resolve();
                });
          })



        
        KuikaAppManager.hideSpinner(this);
        return isErrorOccurred;
    }
		LeadAddComponent_194647_onClick1_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }

				
				stateVars.dataSource_674923 = stateVars.TM_LeadAltModelTemp_ListBySession ?? this.state.TM_LeadAltModelTemp_ListBySession;

		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

            
            return isErrorOccurred;
        }






    async callCallbackFunction(diId: number, isFromMaster: boolean = false) {
        let isErrorOccurred = false;
		let pageInitCallerNavDiIDs = [, 772195, 627617, 837957, 62029, 966643, 276990, 539902, 271368] as number[];
		if (isFromMaster || pageInitCallerNavDiIDs.indexOf(diId) > -1) {
			await this.LeadAddPageInit();
		}
		if (diId == 627617) {
			isErrorOccurred = await this.LeadAddComponent_513936_onClick2_();
            if (isErrorOccurred) return true;
		}
		else if (diId == 837957) {
			isErrorOccurred = await this.LeadAddComponent_366434_onClick2_();
            if (isErrorOccurred) return true;
		}
		else if (diId == 966643) {
			isErrorOccurred = await this.LeadAddComponent_36755_onClick2_();
            if (isErrorOccurred) return true;
		}
		else if (diId == 276990) {
			isErrorOccurred = await this.LeadAddComponent_561793_onClick2_();
            if (isErrorOccurred) return true;
		}

    }


}
