import React from "react";
import Axios, { AxiosResponse } from "axios";
import { KuikaAppManager } from "../../shared/utilty/kuika-app-manager";
import { ReactSystemFunctions } from "../../shared/utilty/react-system-functions";
import { KNavigator } from "../../shared/hoc/with-history";
import { KContext } from "../../shared/hoc/with-context";
import { useLocation } from "react-router-dom";
import { FormInstance } from "antd/es/form";
import { Guid } from "guid-typescript";
import Swal from "sweetalert2";
import { KMainFunctions } from "../../shared/utilty/main-functions";
import moment from "moment";
import { IValidationData } from "../../models/dto/validation-data";
import { IStripePayment } from "../../models/dto/stripe-payment";
import { IUserInfoDto } from "../../models/dto/user-info.dto";
import { UserService } from "../../services/user-service";
import { kuikaCoreWasmBridgeService } from "../../services/_singletons";
import _ from "lodash";
import mqtt, { MqttClient } from "mqtt";
import { IMqttResult } from "../../models/dto/mqtt.dto";


declare let window: any;

export interface ILeadSatisBasariliPop_ScreenProps {
  navigator: KNavigator;
  form: FormInstance<any>;
  googleLogin: any;
  screenInputs: any;
  context: KContext;
  initialValues: any;
  children: any;
}

export interface ILeadSatisBasariliPop_ScreenState {
    isSpinnerVisible: boolean;
    isPageVisible: boolean;
	isLeftMenuVisible: boolean;
    spinnerCount: number;
    selectedLanguage: string;
    isPageInitLoaded: false;
    isPageRecurringLoaded: false;
	GetLeadSalesBasariliInfo: any[];
	GetLeadSalesBasariliInfo_dummy: any[];
	NAVIGATE: any;
	NAVIGATE_dummy: any;
	isComp1624831940Visible: 'visible' | 'hidden';
	isComp2071655830Visible: 'visible' | 'hidden';

}

export class LeadSatisBasariliPop_ScreenBase extends React.PureComponent<ILeadSatisBasariliPop_ScreenProps, any> {


    ml=[{"Id":"d5a61d2b-bd60-485f-86e2-661e9ed4e486","Name":"en_US","ShortName":"English","IsDefault":true,"LanguagePhrases":[]},{"Id":"4640d1e5-7b96-4363-bf56-0e11737cea43","Name":"FixedValues","ShortName":"FixedValues","LanguagePhrases":[{"Id":1464280073,"PropertyName":"value","Value":"Lead Satışı Başarılı"},{"Id":150693422,"PropertyName":"value","Value":"Lead satış işlemi başarıyla tamamlandı. Satış bilgilerini aşağıdaki özetten kontrol edebilirsiniz."},{"Id":157639078,"PropertyName":"value","Value":"Satış Özeti"},{"Id":148855528,"PropertyName":"value","Value":"Lead No"},{"Id":444879238,"PropertyName":"value","Value":"Fatura Referans Numarası"},{"Id":1974506418,"PropertyName":"value","Value":"Satış Tarihi"},{"Id":128090051,"PropertyName":"value","Value":"Müşteri Adı"},{"Id":1426672541,"PropertyName":"value","Value":"Telefon No"},{"Id":792700714,"PropertyName":"value","Value":"Mağaza"},{"Id":1110097394,"PropertyName":"value","Value":"Satış Personeli"},{"Id":1411141032,"PropertyName":"value","Value":"Ürün"},{"Id":533312990,"PropertyName":"value","Value":"Seri No"},{"Id":1195515943,"PropertyName":"value","Value":"Satış Tutarı"},{"Id":502394895,"PropertyName":"value","Value":"Ödeme Tipi"},{"Id":2088640715,"PropertyName":"value","Value":"Satışı Yapıldı"},{"Id":789708537,"PropertyName":"value","Value":"Sonraki İşlem"},{"Id":1312360352,"PropertyName":"value","Value":"Devam etmek istediğiniz işlemi seçin"},{"Id":1862245640,"PropertyName":"value","Value":"Lead Listesine Git"},{"Id":1893903215,"PropertyName":"value","Value":"Lead kayıtlarının bulunduğu listeye dönün."},{"Id":119554912,"PropertyName":"value","Value":"Lead Listesine Git"},{"Id":2037796391,"PropertyName":"value","Value":"Lead Detayına Git"},{"Id":182805989,"PropertyName":"value","Value":"Lead kaydının detaylarını görüntüleyin."},{"Id":187291811,"PropertyName":"value","Value":"Lead Detayına Git"},{"Id":399275916,"PropertyName":"value","Value":"Yeni Lead Oluştur"},{"Id":957046250,"PropertyName":"value","Value":"Yeni bir lead oluşturun."},{"Id":1656636431,"PropertyName":"value","Value":"Yeni Lead Oluştur"},{"Id":825636954,"PropertyName":"value","Value":"Satış Detayına Git"},{"Id":1302994555,"PropertyName":"value","Value":"İşlem kalemlerini ve ayrıntıları inceleyin."},{"Id":1958127360,"PropertyName":"value","Value":"Fatura Görüntüle"}]}]
    defaultML = "en_US"
    
    screenHash = ""
    


    constructor(props) {
        super(props);


        this.state = {
            isSpinnerVisible: false,
            isPageVisible: false,
            isLeftMenuVisible: false,
            spinnerCount: 0,
            selectedLanguage: "",
            isPageInitLoaded: false,
            isPageRecurringLoaded: false,
            	        GetLeadSalesBasariliInfo: [],
	        NAVIGATE: "",
	        isComp1624831940Visible: 'hidden',
	        isComp2071655830Visible: 'hidden',

        }

        this.state.isPageVisible = true;
        
    }

    async componentDidMount() {

        if (KuikaAppManager.isPageInitPrevented()) {
            KuikaAppManager.calculateAndSetBodyHeight("leadsatisbasarilipop", "");
            return;
        }
        
        
        ReactSystemFunctions.validateToken()
        this.fillFormInitValues();
        if (true){
            await this.LeadSatisBasariliPopPageInit();
        }
        
        
        
        KuikaAppManager.calculateAndSetBodyHeight("leadsatisbasarilipop", "");

        if (ReactSystemFunctions.getIsMicroApp() === false) {
           window.parentScreen = this;
        }
    }

    componentWillUnmount() {
        
        
        

        if (ReactSystemFunctions.getIsMicroApp() === false) {
           window.parentScreen = null;
        }
    }

    

        
    componentDidUpdate= async (prevProps, prevState) => {
		KuikaAppManager.calculateAndSetBodyHeight("leadsatisbasarilipop", ""    );
        if (prevProps?.location?.search !== (this.props as any)?.location?.search) {
			await this.LeadSatisBasariliPopPageInit();
		}

        

        if (ReactSystemFunctions.getIsMicroApp() === false) {
            for (const key in prevState) {
                if (key.startsWith('NavVisible') && prevState[key] === true && this.state[key] === false) {
                    window.parentScreen = this;
                    break;
                }
            }
        }
	}

    fillFormInitValues() {
        this.props.form?.setFieldsValue({
});

    }

      setPageInitLoaded = (value: boolean) => {
        this.setState({ isPageInitLoaded: value });
      }

      setPageRecurringLoaded = (value: boolean) => {
        this.setState({ isPageRecurringLoaded: value });
      }

      clearFieldValidation = (changedValues: any) => {
        const fieldName = Object.keys(changedValues)[0];
        if (fieldName) {
          this.props.form?.setFields([
            {
              name: fieldName,
              errors: []
            }
          ]);
        }
      };

      

    LeadSatisBasariliPopPageInit = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


	if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }

        let localVar = {
			SalesDraftId_0: ReactSystemFunctions.convertToTypeByName(this.props.screenInputs.LeadSalesDraftId ?? this.props.screenInputs.leadsalesdraftid, "Guid")
        }

	KuikaAppManager.showSpinner(this);
	
        if (true) {
        KuikaAppManager.showSpinner(this);
        }
        let result = await KuikaAppManager.ApiRequest(this, "LeadSatisBasariliPop/LeadSatisBasariliPopPageInit", localVar)
        if (!KMainFunctions.IsResStatus2XX(result)) return true;

		stateVars.GetLeadSalesBasariliInfo = result?.data.getLeadSalesBasariliInfo;
		formVars.leadsatisbasarilipop_760599532_value = ReactSystemFunctions.toString(this, (stateVars.GetLeadSalesBasariliInfo !== undefined ? (stateVars.GetLeadSalesBasariliInfo?.length > 0 ? stateVars.GetLeadSalesBasariliInfo[0].leadNo : null) : (this.state.GetLeadSalesBasariliInfo?.length > 0 ? this.state.GetLeadSalesBasariliInfo[0].leadNo : null)));
		formVars.leadsatisbasarilipop_715777753_value = ReactSystemFunctions.toString(this, (stateVars.GetLeadSalesBasariliInfo !== undefined ? (stateVars.GetLeadSalesBasariliInfo?.length > 0 ? stateVars.GetLeadSalesBasariliInfo[0].faturaRefNo : null) : (this.state.GetLeadSalesBasariliInfo?.length > 0 ? this.state.GetLeadSalesBasariliInfo[0].faturaRefNo : null)));
		formVars.leadsatisbasarilipop_1963460610_value = ReactSystemFunctions.value(this, (stateVars.GetLeadSalesBasariliInfo !== undefined ? (stateVars.GetLeadSalesBasariliInfo?.length > 0 ? stateVars.GetLeadSalesBasariliInfo[0].satisTarihi : null) : (this.state.GetLeadSalesBasariliInfo?.length > 0 ? this.state.GetLeadSalesBasariliInfo[0].satisTarihi : null)));
		formVars.leadsatisbasarilipop_1663532574_value = ReactSystemFunctions.toString(this, (stateVars.GetLeadSalesBasariliInfo !== undefined ? (stateVars.GetLeadSalesBasariliInfo?.length > 0 ? stateVars.GetLeadSalesBasariliInfo[0].musteriAdi : null) : (this.state.GetLeadSalesBasariliInfo?.length > 0 ? this.state.GetLeadSalesBasariliInfo[0].musteriAdi : null)));
		formVars.leadsatisbasarilipop_1313311321_value = ReactSystemFunctions.toString(this, (stateVars.GetLeadSalesBasariliInfo !== undefined ? (stateVars.GetLeadSalesBasariliInfo?.length > 0 ? stateVars.GetLeadSalesBasariliInfo[0].telefonNo : null) : (this.state.GetLeadSalesBasariliInfo?.length > 0 ? this.state.GetLeadSalesBasariliInfo[0].telefonNo : null)));
		formVars.leadsatisbasarilipop_611972309_value = ReactSystemFunctions.toString(this, (stateVars.GetLeadSalesBasariliInfo !== undefined ? (stateVars.GetLeadSalesBasariliInfo?.length > 0 ? stateVars.GetLeadSalesBasariliInfo[0].magaza : null) : (this.state.GetLeadSalesBasariliInfo?.length > 0 ? this.state.GetLeadSalesBasariliInfo[0].magaza : null)));
		formVars.leadsatisbasarilipop_1811362294_value = ReactSystemFunctions.toString(this, (stateVars.GetLeadSalesBasariliInfo !== undefined ? (stateVars.GetLeadSalesBasariliInfo?.length > 0 ? stateVars.GetLeadSalesBasariliInfo[0].satisPersoneli : null) : (this.state.GetLeadSalesBasariliInfo?.length > 0 ? this.state.GetLeadSalesBasariliInfo[0].satisPersoneli : null)));
		formVars.leadsatisbasarilipop_1374771077_value = ReactSystemFunctions.toString(this, (stateVars.GetLeadSalesBasariliInfo !== undefined ? (stateVars.GetLeadSalesBasariliInfo?.length > 0 ? stateVars.GetLeadSalesBasariliInfo[0].urun : null) : (this.state.GetLeadSalesBasariliInfo?.length > 0 ? this.state.GetLeadSalesBasariliInfo[0].urun : null)));
		formVars.leadsatisbasarilipop_1881949650_value = ReactSystemFunctions.toString(this, (stateVars.GetLeadSalesBasariliInfo !== undefined ? (stateVars.GetLeadSalesBasariliInfo?.length > 0 ? stateVars.GetLeadSalesBasariliInfo[0].seriNo : null) : (this.state.GetLeadSalesBasariliInfo?.length > 0 ? this.state.GetLeadSalesBasariliInfo[0].seriNo : null)));
		formVars.leadsatisbasarilipop_896027886_value = ReactSystemFunctions.toString(this, (stateVars.GetLeadSalesBasariliInfo !== undefined ? (stateVars.GetLeadSalesBasariliInfo?.length > 0 ? stateVars.GetLeadSalesBasariliInfo[0].satisTutari : null) : (this.state.GetLeadSalesBasariliInfo?.length > 0 ? this.state.GetLeadSalesBasariliInfo[0].satisTutari : null)));
		formVars.leadsatisbasarilipop_973633072_value = ReactSystemFunctions.toString(this, (stateVars.GetLeadSalesBasariliInfo !== undefined ? (stateVars.GetLeadSalesBasariliInfo?.length > 0 ? stateVars.GetLeadSalesBasariliInfo[0].odemeTipi : null) : (this.state.GetLeadSalesBasariliInfo?.length > 0 ? this.state.GetLeadSalesBasariliInfo[0].odemeTipi : null)));
		stateVars.isComp1624831940Visible = ((ReactSystemFunctions.isNotEmpty(ReactSystemFunctions.toString(this, (stateVars.GetLeadSalesBasariliInfo !== undefined ? (stateVars.GetLeadSalesBasariliInfo?.length > 0 ? stateVars.GetLeadSalesBasariliInfo[0].telefonNo : null) : (this.state.GetLeadSalesBasariliInfo?.length > 0 ? this.state.GetLeadSalesBasariliInfo[0].telefonNo : null))), ReactSystemFunctions.convertToTypeByName("True", "string"))) === true ? "visible" : "hidden")
		this.props.form?.setFieldsValue(formVars);
		
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.LeadSatisBasariliPopPageInit1_();
                  resolve();
                });
          })



        
        KuikaAppManager.hideSpinner(this);
        return isErrorOccurred;
    }
	LeadSatisBasariliPopPageInit1_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


	if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }

			formVars.leadsatisbasarilipop_760599532_value = ReactSystemFunctions.toString(this, (stateVars.GetLeadSalesBasariliInfo !== undefined ? (stateVars.GetLeadSalesBasariliInfo?.length > 0 ? stateVars.GetLeadSalesBasariliInfo[0].leadNo : null) : (this.state.GetLeadSalesBasariliInfo?.length > 0 ? this.state.GetLeadSalesBasariliInfo[0].leadNo : null)));

			formVars.leadsatisbasarilipop_715777753_value = ReactSystemFunctions.toString(this, (stateVars.GetLeadSalesBasariliInfo !== undefined ? (stateVars.GetLeadSalesBasariliInfo?.length > 0 ? stateVars.GetLeadSalesBasariliInfo[0].faturaRefNo : null) : (this.state.GetLeadSalesBasariliInfo?.length > 0 ? this.state.GetLeadSalesBasariliInfo[0].faturaRefNo : null)));

			formVars.leadsatisbasarilipop_1963460610_value = ReactSystemFunctions.value(this, (stateVars.GetLeadSalesBasariliInfo !== undefined ? (stateVars.GetLeadSalesBasariliInfo?.length > 0 ? stateVars.GetLeadSalesBasariliInfo[0].satisTarihi : null) : (this.state.GetLeadSalesBasariliInfo?.length > 0 ? this.state.GetLeadSalesBasariliInfo[0].satisTarihi : null)));

			formVars.leadsatisbasarilipop_1663532574_value = ReactSystemFunctions.toString(this, (stateVars.GetLeadSalesBasariliInfo !== undefined ? (stateVars.GetLeadSalesBasariliInfo?.length > 0 ? stateVars.GetLeadSalesBasariliInfo[0].musteriAdi : null) : (this.state.GetLeadSalesBasariliInfo?.length > 0 ? this.state.GetLeadSalesBasariliInfo[0].musteriAdi : null)));

			stateVars.isComp1624831940Visible = ((ReactSystemFunctions.isNotEmpty(ReactSystemFunctions.toString(this, (stateVars.GetLeadSalesBasariliInfo !== undefined ? (stateVars.GetLeadSalesBasariliInfo?.length > 0 ? stateVars.GetLeadSalesBasariliInfo[0].telefonNo : null) : (this.state.GetLeadSalesBasariliInfo?.length > 0 ? this.state.GetLeadSalesBasariliInfo[0].telefonNo : null))), ReactSystemFunctions.convertToTypeByName("True", "string"))) === true ? "visible" : "hidden")
			formVars.leadsatisbasarilipop_1313311321_value = ReactSystemFunctions.toString(this, (stateVars.GetLeadSalesBasariliInfo !== undefined ? (stateVars.GetLeadSalesBasariliInfo?.length > 0 ? stateVars.GetLeadSalesBasariliInfo[0].telefonNo : null) : (this.state.GetLeadSalesBasariliInfo?.length > 0 ? this.state.GetLeadSalesBasariliInfo[0].telefonNo : null)));

			formVars.leadsatisbasarilipop_611972309_value = ReactSystemFunctions.toString(this, (stateVars.GetLeadSalesBasariliInfo !== undefined ? (stateVars.GetLeadSalesBasariliInfo?.length > 0 ? stateVars.GetLeadSalesBasariliInfo[0].magaza : null) : (this.state.GetLeadSalesBasariliInfo?.length > 0 ? this.state.GetLeadSalesBasariliInfo[0].magaza : null)));

			formVars.leadsatisbasarilipop_1811362294_value = ReactSystemFunctions.toString(this, (stateVars.GetLeadSalesBasariliInfo !== undefined ? (stateVars.GetLeadSalesBasariliInfo?.length > 0 ? stateVars.GetLeadSalesBasariliInfo[0].satisPersoneli : null) : (this.state.GetLeadSalesBasariliInfo?.length > 0 ? this.state.GetLeadSalesBasariliInfo[0].satisPersoneli : null)));

			formVars.leadsatisbasarilipop_1374771077_value = ReactSystemFunctions.toString(this, (stateVars.GetLeadSalesBasariliInfo !== undefined ? (stateVars.GetLeadSalesBasariliInfo?.length > 0 ? stateVars.GetLeadSalesBasariliInfo[0].urun : null) : (this.state.GetLeadSalesBasariliInfo?.length > 0 ? this.state.GetLeadSalesBasariliInfo[0].urun : null)));

			formVars.leadsatisbasarilipop_1881949650_value = ReactSystemFunctions.toString(this, (stateVars.GetLeadSalesBasariliInfo !== undefined ? (stateVars.GetLeadSalesBasariliInfo?.length > 0 ? stateVars.GetLeadSalesBasariliInfo[0].seriNo : null) : (this.state.GetLeadSalesBasariliInfo?.length > 0 ? this.state.GetLeadSalesBasariliInfo[0].seriNo : null)));

			formVars.leadsatisbasarilipop_896027886_value = ReactSystemFunctions.toString(this, (stateVars.GetLeadSalesBasariliInfo !== undefined ? (stateVars.GetLeadSalesBasariliInfo?.length > 0 ? stateVars.GetLeadSalesBasariliInfo[0].satisTutari : null) : (this.state.GetLeadSalesBasariliInfo?.length > 0 ? this.state.GetLeadSalesBasariliInfo[0].satisTutari : null)));

			formVars.leadsatisbasarilipop_973633072_value = ReactSystemFunctions.toString(this, (stateVars.GetLeadSalesBasariliInfo !== undefined ? (stateVars.GetLeadSalesBasariliInfo?.length > 0 ? stateVars.GetLeadSalesBasariliInfo[0].odemeTipi : null) : (this.state.GetLeadSalesBasariliInfo?.length > 0 ? this.state.GetLeadSalesBasariliInfo[0].odemeTipi : null)));


	this.props.form?.setFieldsValue(formVars);
	this.setState(stateVars);
	KuikaAppManager.hideSpinner(this);

            this.setPageInitLoaded(true);
            return isErrorOccurred;
        }




		LeadSatisBasariliPopComponent_119554912_onClick = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
KuikaAppManager.showSpinner(this);

					KuikaAppManager.prepareForNavigation();

				stateVars.NAVIGATE = await ReactSystemFunctions.navigate(this, undefined, "LeadSatisBasariliPop", "LeadListTemp", "", "currentPage", null, null, null, null, null, null, true, false);

		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

            
            return isErrorOccurred;
        }


		LeadSatisBasariliPopComponent_187291811_onClick = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
KuikaAppManager.showSpinner(this);

					KuikaAppManager.prepareForNavigation();
						KuikaAppManager.addToPageInputVariables("LeadDetailTemp", "LeadId", ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, (stateVars.GetLeadSalesBasariliInfo !== undefined ? (stateVars.GetLeadSalesBasariliInfo?.length > 0 ? stateVars.GetLeadSalesBasariliInfo[0].leadId : null) : (this.state.GetLeadSalesBasariliInfo?.length > 0 ? this.state.GetLeadSalesBasariliInfo[0].leadId : null))), "Guid"));

				stateVars.NAVIGATE = await ReactSystemFunctions.navigate(this, undefined, "LeadSatisBasariliPop", "LeadDetailTemp", "", "currentPage", null, null, null, null, null, null, true, false);

		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

            
            return isErrorOccurred;
        }


		LeadSatisBasariliPopComponent_1656636431_onClick = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
KuikaAppManager.showSpinner(this);

					KuikaAppManager.prepareForNavigation();
						KuikaAppManager.addToPageInputVariables("LeadAddTemp", "CustomerId", ReactSystemFunctions.convertToTypeByName("00000000-0000-0000-0000-000000000000", "Guid"));

				stateVars.NAVIGATE = await ReactSystemFunctions.navigate(this, undefined, "LeadSatisBasariliPop", "LeadAddTemp", "", "currentPage", null, null, null, null, null, null, true, false);

		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

            
            return isErrorOccurred;
        }




    async callCallbackFunction(diId: number, isFromMaster: boolean = false) {
        let isErrorOccurred = false;
		let pageInitCallerNavDiIDs = [, , ] as number[];
		if (isFromMaster || pageInitCallerNavDiIDs.indexOf(diId) > -1) {
			await this.LeadSatisBasariliPopPageInit();
		}

    }


}
