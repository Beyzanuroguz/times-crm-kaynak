import React from "react";
import Axios, { AxiosResponse } from "axios";
import { KuikaAppManager } from "../../shared/utilty/kuika-app-manager";
import { ReactSystemFunctions } from "../../shared/utilty/react-system-functions";
import { KNavigator } from "../../shared/hoc/with-history";
import { KContext } from "../../shared/hoc/with-context";
import { useLocation } from "react-router-dom";
import { FormInstance } from "antd/es/form";
import { Guid } from "guid-typescript";
import Swal from "sweetalert2";
import { KMainFunctions } from "../../shared/utilty/main-functions";
import moment from "moment";
import { IValidationData } from "../../models/dto/validation-data";
import { IStripePayment } from "../../models/dto/stripe-payment";
import { IUserInfoDto } from "../../models/dto/user-info.dto";
import { UserService } from "../../services/user-service";
import { kuikaCoreWasmBridgeService } from "../../services/_singletons";
import _ from "lodash";
import mqtt, { MqttClient } from "mqtt";
import { IMqttResult } from "../../models/dto/mqtt.dto";


declare let window: any;

export interface ITransferDashboard_ScreenProps {
  navigator: KNavigator;
  form: FormInstance<any>;
  googleLogin: any;
  screenInputs: any;
  context: KContext;
  initialValues: any;
  children: any;
}

export interface ITransferDashboard_ScreenState {
    isSpinnerVisible: boolean;
    isPageVisible: boolean;
	isLeftMenuVisible: boolean;
    spinnerCount: number;
    selectedLanguage: string;
    isPageInitLoaded: false;
    isPageRecurringLoaded: false;

}

export class TransferDashboard_ScreenBase extends React.PureComponent<ITransferDashboard_ScreenProps, any> {

	transferdashboard_902354_value_kuikaSelectBoxRef: React.RefObject<any>;
	transferdashboard_467498_value_kuikaAutoCompleteRef: React.RefObject<any>;
	transferdashboard_315440_value_kuikaAutoCompleteRef: React.RefObject<any>;
	transferdashboard_945526_value_kuikaAutoCompleteRef: React.RefObject<any>;
	transferdashboard_318368_value_kuikaAutoCompleteRef: React.RefObject<any>;
	transferdashboard_590304_value_kuikaTableRef: React.RefObject<any>;
	transferdashboard_228053_value_kuikaTableRef: React.RefObject<any>;
    ml=[{"Id":"d5a61d2b-bd60-485f-86e2-661e9ed4e486","Name":"en_US","ShortName":"English","IsDefault":true,"LanguagePhrases":[]},{"Id":"cc236087-c1bb-452c-81a1-de999a7d1e32","Name":"FixedValues","ShortName":"FixedValues","LanguagePhrases":[{"Id":870153,"PropertyName":"value","Value":"Transfer Dashboard"},{"Id":395029,"PropertyName":"value","Value":"Transfer taleplerini, sevk süreçlerini ve mağaza performansını takip edin."},{"Id":880575,"PropertyName":"value","Value":"Son güncelleme: 06.08.2026 21:00"},{"Id":74583,"PropertyName":"label","Value":"Yenile"},{"Id":365091,"PropertyName":"value","Value":"Filtreler"},{"Id":902354,"PropertyName":"placeholder","Value":"Son 30 Gün"},{"Id":467498,"PropertyName":"placeholder","Value":"Mağaza"},{"Id":315440,"PropertyName":"placeholder","Value":"Talep Türü"},{"Id":945526,"PropertyName":"placeholder","Value":"Marka"},{"Id":318368,"PropertyName":"placeholder","Value":"Ürün/Kategori"},{"Id":124516,"PropertyName":"label","Value":"Uygula"},{"Id":128098,"PropertyName":"label","Value":"Temizle"},{"Id":798262,"PropertyName":"value","Value":"Onay Bekleyen"},{"Id":94020,"PropertyName":"value","Value":"12"},{"Id":588168,"PropertyName":"value","Value":"Transfer Bekleyen"},{"Id":902076,"PropertyName":"value","Value":"18"},{"Id":130869,"PropertyName":"value","Value":"Yoldaki Fişler"},{"Id":315328,"PropertyName":"value","Value":"9"},{"Id":619845,"PropertyName":"value","Value":"Kabul İşleminde"},{"Id":409750,"PropertyName":"value","Value":"3"},{"Id":489346,"PropertyName":"value","Value":"Transfer Edilen"},{"Id":670046,"PropertyName":"value","Value":"86"},{"Id":636902,"PropertyName":"value","Value":"Sorunlu Kabul"},{"Id":794004,"PropertyName":"value","Value":"4"},{"Id":754732,"PropertyName":"value","Value":"Aktif Entegrasyon Hatası"},{"Id":932518,"PropertyName":"value","Value":"2"},{"Id":295057,"PropertyName":"value","Value":"Talep Durum Dağılımı"},{"Id":900287,"PropertyName":"value","Value":"Transfer Durumu"},{"Id":593413,"PropertyName":"value","Value":"Mağazalar Arası Transfer Matrisi"},{"Id":214732,"PropertyName":"title","Value":"Mağaza"},{"Id":418350,"PropertyName":"value","Value":"Adana"},{"Id":82066,"PropertyName":"title","Value":"Adana"},{"Id":93510,"PropertyName":"value","Value":"—"},{"Id":410400,"PropertyName":"title","Value":"Mersin"},{"Id":735833,"PropertyName":"value","Value":"14"},{"Id":576330,"PropertyName":"title","Value":"Antalya"},{"Id":497962,"PropertyName":"value","Value":"8"},{"Id":91147,"PropertyName":"title","Value":"Gaziantep"},{"Id":345980,"PropertyName":"value","Value":"5"},{"Id":679706,"PropertyName":"title","Value":"Merkez"},{"Id":295494,"PropertyName":"value","Value":"22"},{"Id":765576,"PropertyName":"value","Value":"En Çok Talep Edilen Ürünler"},{"Id":944089,"PropertyName":"value","Value":"Ürün kodu ve adına göre talep / transfer miktarı"},{"Id":562945,"PropertyName":"value","Value":"Süre Metrikleri"},{"Id":725150,"PropertyName":"value","Value":"Ortalama Onay Süresi"},{"Id":460393,"PropertyName":"value","Value":"6 saat"},{"Id":14327,"PropertyName":"value","Value":"Ortalama Transfer Bekleme Süresi"},{"Id":744878,"PropertyName":"value","Value":"2.4 gün"},{"Id":730846,"PropertyName":"value","Value":"Ortalama Kabul Süresi"},{"Id":103592,"PropertyName":"value","Value":"9 saat"},{"Id":465016,"PropertyName":"value","Value":"Mağaza Performansı"},{"Id":217196,"PropertyName":"title","Value":"Mağaza"},{"Id":815491,"PropertyName":"value","Value":"Adana"},{"Id":321498,"PropertyName":"title","Value":"Gelen Talep"},{"Id":702933,"PropertyName":"value","Value":"42"},{"Id":770622,"PropertyName":"title","Value":"Giden Talep"},{"Id":20243,"PropertyName":"value","Value":"36"},{"Id":164547,"PropertyName":"title","Value":"Onaylanan"},{"Id":348037,"PropertyName":"value","Value":"31"},{"Id":193571,"PropertyName":"title","Value":"Reddedilen"},{"Id":814481,"PropertyName":"value","Value":"5"},{"Id":280176,"PropertyName":"title","Value":"Transfer Edilen Ürün"},{"Id":101753,"PropertyName":"value","Value":"128"},{"Id":550058,"PropertyName":"title","Value":"Ortalama Onay Süresi"},{"Id":82319,"PropertyName":"value","Value":"5.4 saat"},{"Id":487202,"PropertyName":"title","Value":"Ortalama Transfer Süresi"},{"Id":420601,"PropertyName":"value","Value":"2.1 gün"},{"Id":915537,"PropertyName":"value","Value":"Sorunlu Kabul Özeti"},{"Id":594287,"PropertyName":"value","Value":"Sorunlu Fiş"},{"Id":541742,"PropertyName":"value","Value":"4"},{"Id":390223,"PropertyName":"value","Value":"Eksik Ürün"},{"Id":746039,"PropertyName":"value","Value":"3"},{"Id":14665,"PropertyName":"value","Value":"Yanlış Ürün"},{"Id":541444,"PropertyName":"value","Value":"2"},{"Id":149714,"PropertyName":"label","Value":"Sorunlu Kabulleri Gör"}]}]
    defaultML = "en_US"
    
    screenHash = ""
    


    constructor(props) {
        super(props);
		this.transferdashboard_902354_value_kuikaSelectBoxRef = React.createRef();
		this.transferdashboard_467498_value_kuikaAutoCompleteRef = React.createRef();
		this.transferdashboard_315440_value_kuikaAutoCompleteRef = React.createRef();
		this.transferdashboard_945526_value_kuikaAutoCompleteRef = React.createRef();
		this.transferdashboard_318368_value_kuikaAutoCompleteRef = React.createRef();
		this.transferdashboard_590304_value_kuikaTableRef = React.createRef();
		this.transferdashboard_228053_value_kuikaTableRef = React.createRef();

        this.state = {
            isSpinnerVisible: false,
            isPageVisible: false,
            isLeftMenuVisible: false,
            spinnerCount: 0,
            selectedLanguage: "",
            isPageInitLoaded: false,
            isPageRecurringLoaded: false,
            	        dataSource_902354: [{"key":"30","text":"Son 30 Gün"},{"key":"7","text":"Son 7 Gün"},{"key":"90","text":"Son 90 Gün"}],
	        dataSource_467498: [{"key":"adana","text":"Adana"},{"key":"mersin","text":"Mersin"},{"key":"antalya","text":"Antalya"},{"key":"merkez","text":"Merkez"}],
	        dataSource_315440: [{"key":"magaza","text":"Mağazalar Arası"},{"key":"merkez","text":"Merkez Transferi"},{"key":"iade","text":"İade Transferi"}],
	        dataSource_945526: [{"key":"times","text":"TIMES"},{"key":"north","text":"North"},{"key":"urban","text":"Urban"}],
	        dataSource_318368: [{"key":"ayakkabi","text":"Ayakkabı"},{"key":"tekstil","text":"Tekstil"},{"key":"aksesuar","text":"Aksesuar"}],

        }

        this.state.isPageVisible = true;
        
    }

    async componentDidMount() {

        if (KuikaAppManager.isPageInitPrevented()) {
            KuikaAppManager.calculateAndSetBodyHeight("transferdashboard", "");
            return;
        }
        
        
        ReactSystemFunctions.validateToken()
        this.fillFormInitValues();
        if (true){
            
        }
        
        
        
        KuikaAppManager.calculateAndSetBodyHeight("transferdashboard", "");

        if (ReactSystemFunctions.getIsMicroApp() === false) {
           window.parentScreen = this;
        }
    }

    componentWillUnmount() {
        
        
        

        if (ReactSystemFunctions.getIsMicroApp() === false) {
           window.parentScreen = null;
        }
    }

    

        
    componentDidUpdate= async (prevProps, prevState) => {
		KuikaAppManager.calculateAndSetBodyHeight("transferdashboard", ""    );
        if (prevProps?.location?.search !== (this.props as any)?.location?.search) {
			
		}

        

        if (ReactSystemFunctions.getIsMicroApp() === false) {
            for (const key in prevState) {
                if (key.startsWith('NavVisible') && prevState[key] === true && this.state[key] === false) {
                    window.parentScreen = this;
                    break;
                }
            }
        }
	}

    fillFormInitValues() {
        this.props.form?.setFieldsValue({
});

    }

      setPageInitLoaded = (value: boolean) => {
        this.setState({ isPageInitLoaded: value });
      }

      setPageRecurringLoaded = (value: boolean) => {
        this.setState({ isPageRecurringLoaded: value });
      }

      clearFieldValidation = (changedValues: any) => {
        const fieldName = Object.keys(changedValues)[0];
        if (fieldName) {
          this.props.form?.setFields([
            {
              name: fieldName,
              errors: []
            }
          ]);
        }
      };

      




    async callCallbackFunction(diId: number, isFromMaster: boolean = false) {
        let isErrorOccurred = false;

    }


}
