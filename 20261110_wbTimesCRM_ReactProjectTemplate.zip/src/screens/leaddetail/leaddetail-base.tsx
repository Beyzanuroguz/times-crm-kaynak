import React from "react";
import Axios, { AxiosResponse } from "axios";
import { KuikaAppManager } from "../../shared/utilty/kuika-app-manager";
import { ReactSystemFunctions } from "../../shared/utilty/react-system-functions";
import { KNavigator } from "../../shared/hoc/with-history";
import { KContext } from "../../shared/hoc/with-context";
import { useLocation } from "react-router-dom";
import { FormInstance } from "antd/es/form";
import { Guid } from "guid-typescript";
import Swal from "sweetalert2";
import { KMainFunctions } from "../../shared/utilty/main-functions";
import moment from "moment";
import { IValidationData } from "../../models/dto/validation-data";
import { IStripePayment } from "../../models/dto/stripe-payment";
import { IUserInfoDto } from "../../models/dto/user-info.dto";
import { UserService } from "../../services/user-service";
import { kuikaCoreWasmBridgeService } from "../../services/_singletons";
import _ from "lodash";
import mqtt, { MqttClient } from "mqtt";
import { IMqttResult } from "../../models/dto/mqtt.dto";


declare let window: any;

export interface ILeadDetail_ScreenProps {
  navigator: KNavigator;
  form: FormInstance<any>;
  googleLogin: any;
  screenInputs: any;
  context: KContext;
  initialValues: any;
  children: any;
}

export interface ILeadDetail_ScreenState {
    isSpinnerVisible: boolean;
    isPageVisible: boolean;
	isLeftMenuVisible: boolean;
    spinnerCount: number;
    selectedLanguage: string;
    isPageInitLoaded: false;
    isPageRecurringLoaded: false;
	TM_UserRoleByUserId: any[];
	TM_UserRoleByUserId_dummy: any[];
	TM_ShowButton: any[];
	TM_ShowButton_dummy: any[];
	TM_GetLeadStatus: any[];
	TM_GetLeadStatus_dummy: any[];
	TM_CheckLeadApprovalPermission: any[];
	TM_CheckLeadApprovalPermission_dummy: any[];
	TM_GetLeadById: any[];
	TM_GetLeadById_dummy: any[];
	TM_GetReserveEditShow: any[];
	TM_GetReserveEditShow_dummy: any[];
	GetLeadNotes: any[];
	GetLeadNotes_dummy: any[];
	TM_GetLeadNoteFileCounts: any[];
	TM_GetLeadNoteFileCounts_dummy: any[];
	TM_GetLeadLogById: any[];
	TM_GetLeadLogById_dummy: any[];
	TM_GetLeadAlternativeModel: any[];
	TM_GetLeadAlternativeModel_dummy: any[];
	TM_GetLeadLogStatu: any[];
	TM_GetLeadLogStatu_dummy: any[];
	GoBack: any;
	GoBack_dummy: any;
	NAVIGATE: any;
	NAVIGATE_dummy: any;
	TM_LeadNoteDelete: any[];
	TM_LeadNoteDelete_dummy: any[];
	Notify: boolean;
	Notify_dummy: boolean;
	TriggerEvent: string;
	TriggerEvent_dummy: string;
	DownloadFile: any;
	DownloadFile_dummy: any;
	ChangeVisibilityOf: string;
	ChangeVisibilityOf_dummy: string;
	isComp725875Visible: 'visible' | 'hidden';
	isComp423129Visible: 'visible' | 'hidden';
	isComp158835Visible: 'visible' | 'hidden';
	isComp113633Visible: 'visible' | 'hidden';
	isComp628783Visible: 'visible' | 'hidden';
	isComp695136Visible: 'visible' | 'hidden';
	isComp348866Visible: 'visible' | 'hidden';
	isComp646823Visible: 'visible' | 'hidden';
	isComp21278Visible: 'visible' | 'hidden';
	isComp308454Visible: 'visible' | 'hidden';
	isComp754898Visible: 'visible' | 'hidden';
	isComp694742Visible: 'visible' | 'hidden';
	isComp630305Visible: 'visible' | 'hidden';
	isComp526661Visible: 'visible' | 'hidden';
	isComp964177Visible: 'visible' | 'hidden';
	isComp585616Visible: 'visible' | 'hidden';
	isComp157435Visible: 'visible' | 'hidden';
	isComp990588Visible: 'visible' | 'hidden';
	isComp27222Visible: 'visible' | 'hidden';
	isComp70283Visible: 'visible' | 'hidden';
	isComp582491Visible: 'visible' | 'hidden';
	isComp508683Visible: 'visible' | 'hidden';
	isComp45102Visible: 'visible' | 'hidden';
	isComp728206Visible: 'visible' | 'hidden';
	isComp528442Visible: 'visible' | 'hidden';
	isComp287076Visible: 'visible' | 'hidden';
	isComp478356Visible: 'visible' | 'hidden';
	isComp368573Visible: 'visible' | 'hidden';
	isComp352135Visible: 'visible' | 'hidden';
	isComp163814Visible: 'visible' | 'hidden';
	isComp208093Visible: 'visible' | 'hidden';
	isComp845003Visible: 'visible' | 'hidden';
	isComp962400Visible: 'visible' | 'hidden';
	isComp412413Visible: 'visible' | 'hidden';
	isComp598484Visible: 'visible' | 'hidden';
	isComp879058Visible: 'visible' | 'hidden';
	isComp837569Visible: 'visible' | 'hidden';
	isComp955133Visible: 'visible' | 'hidden';
	isComp604430Visible: 'visible' | 'hidden';
	isComp838701Visible: 'visible' | 'hidden';
	isComp41121Visible: 'visible' | 'hidden';
	isComp794263Visible: 'visible' | 'hidden';

}

export class LeadDetail_ScreenBase extends React.PureComponent<ILeadDetail_ScreenProps, any> {

	leaddetail_987199_value_kuikaTableRef: React.RefObject<any>;
	leaddetail_219536_value_kuikaGalleryViewRef: React.RefObject<any>;
	leaddetail_810974_value_kuikaTableRef: React.RefObject<any>;
	leaddetail_148531_value_kuikaSelectBoxRef: React.RefObject<any>;
	leaddetail_764439_value_kuikaTableRef: React.RefObject<any>;
    ml=[{"Id":"d5a61d2b-bd60-485f-86e2-661e9ed4e486","Name":"en_US","ShortName":"English","IsDefault":true,"LanguagePhrases":[]},{"Id":"37274902-f368-47b6-ae3a-182be668163e","Name":"FixedValues","ShortName":"FixedValues","LanguagePhrases":[{"Id":902678,"PropertyName":"value","Value":"Talep Detay Ekranı"},{"Id":252065,"PropertyName":"value","Value":"İşlem Paneli"},{"Id":628783,"PropertyName":"label","Value":"Satış Yap ve Teslim Et"},{"Id":348866,"PropertyName":"label","Value":"Rezerveyi Düzenle"},{"Id":646823,"PropertyName":"label","Value":"Termin Ver ve Onayla"},{"Id":21278,"PropertyName":"label","Value":"Termin Ver ve Onaya Gönder"},{"Id":308454,"PropertyName":"label","Value":"Talebi Reddet"},{"Id":754898,"PropertyName":"label","Value":"Müşteri İstemedi"},{"Id":250318,"PropertyName":"value","Value":"Talep Bilgileri"},{"Id":630305,"PropertyName":"label","Value":"Düzenle"},{"Id":526661,"PropertyName":"label","Value":"Ürün Değiştir & Talebi Kapat"},{"Id":544730,"PropertyName":"value","Value":"Müşteri Bilgileri"},{"Id":897959,"PropertyName":"value","Value":"Müşteri Adı"},{"Id":604438,"PropertyName":"value","Value":"Telefon No"},{"Id":534702,"PropertyName":"value","Value":"Mail"},{"Id":725734,"PropertyName":"value","Value":"Şehir/Lokasyon"},{"Id":909219,"PropertyName":"value","Value":"Müşteri İnfo"},{"Id":282588,"PropertyName":"value","Value":"Ürün Bilgileri"},{"Id":64057,"PropertyName":"value","Value":"Ürün Adı"},{"Id":207783,"PropertyName":"value","Value":"Marka"},{"Id":303132,"PropertyName":"value","Value":"Referans"},{"Id":179106,"PropertyName":"value","Value":"Kadran"},{"Id":424611,"PropertyName":"value","Value":"Bilezik"},{"Id":342439,"PropertyName":"value","Value":"Talep Bilgileri"},{"Id":684347,"PropertyName":"value","Value":"Talep Durum"},{"Id":219597,"PropertyName":"value","Value":"Reddedilme Notu"},{"Id":870212,"PropertyName":"value","Value":"Talep Oluşturma Tarihi"},{"Id":422584,"PropertyName":"value","Value":"Termin Tarihi"},{"Id":43580,"PropertyName":"value","Value":"Takip Durumu"},{"Id":443237,"PropertyName":"value","Value":"Sonraki Adım"},{"Id":566178,"PropertyName":"value","Value":"Son Statü Değişikliği"},{"Id":546196,"PropertyName":"value","Value":"Personel Bilgisi"},{"Id":41063,"PropertyName":"value","Value":"Mağaza"},{"Id":990464,"PropertyName":"value","Value":"Satış Personeli"},{"Id":702090,"PropertyName":"value","Value":"Talep Notu"},{"Id":275758,"PropertyName":"value","Value":"Rezerve Durumu"},{"Id":163814,"PropertyName":"value","Value":"Evet"},{"Id":208093,"PropertyName":"value","Value":"Onay Bekliyor"},{"Id":845003,"PropertyName":"value","Value":"Hayır"},{"Id":556339,"PropertyName":"value","Value":"Rezerve Eden Kişi"},{"Id":753774,"PropertyName":"value","Value":"Rezerve Notu"},{"Id":994343,"PropertyName":"value","Value":"Sunulan Alternatif Modelller"},{"Id":879058,"PropertyName":"label","Value":"Ekle/Sil"},{"Id":709426,"PropertyName":"title","Value":"Ürün Adı"},{"Id":345539,"PropertyName":"value","Value":"[datafield:productname]"},{"Id":352161,"PropertyName":"title","Value":"Kategori"},{"Id":837569,"PropertyName":"value","Value":"[datafield:categoryname]"},{"Id":955133,"PropertyName":"value","Value":"[datafield:categoryname]"},{"Id":604430,"PropertyName":"value","Value":"[datafield:categoryname]"},{"Id":838701,"PropertyName":"value","Value":"[datafield:categoryname]"},{"Id":43115,"PropertyName":"tab","Value":"Talep Notları"},{"Id":793824,"PropertyName":"value","Value":"Not"},{"Id":192246,"PropertyName":"value","Value":"Dosya"},{"Id":343465,"PropertyName":"label","Value":"Dosyaları Görüntüle"},{"Id":78330,"PropertyName":"label","Value":"Not Ekle"},{"Id":219536,"PropertyName":"nodatafoundmessage","Value":"No data found."},{"Id":7912,"PropertyName":"value","Value":"[datafield:createdbyname]"},{"Id":650686,"PropertyName":"value","Value":"[datafield:rolename]"},{"Id":221927,"PropertyName":"value","Value":"[datafield:createdattext]"},{"Id":394715,"PropertyName":"value","Value":"[datafield:note]"},{"Id":770210,"PropertyName":"value","Value":"Eklenen Dosyalar"},{"Id":725168,"PropertyName":"value","Value":"[datafield:filecount]"},{"Id":126381,"PropertyName":"title","Value":"Title"},{"Id":614654,"PropertyName":"tab","Value":"Log Kayıtları"},{"Id":525648,"PropertyName":"value","Value":"Tüm Kayıtlar"},{"Id":518194,"PropertyName":"value","Value":"Değiştirilen Alan"},{"Id":148531,"PropertyName":"placeholder","Value":"Değiştirilen Alan"},{"Id":644420,"PropertyName":"value","Value":"Değişiklik Yapan Kullanıcı"},{"Id":710951,"PropertyName":"placeholder","Value":"Değişiklik Yapan Kullanıcı"},{"Id":681996,"PropertyName":"value","Value":"Değişiklik Tarihi"},{"Id":185424,"PropertyName":"startDatePlaceholder","Value":"Başlangıç Tarihi"},{"Id":185424,"PropertyName":"endDatePlaceholder","Value":"Bitiş Tarihi"},{"Id":421143,"PropertyName":"title","Value":"Değiştirilen Alan"},{"Id":324364,"PropertyName":"value","Value":"[datafield:columnname]"},{"Id":658694,"PropertyName":"title","Value":"Not "},{"Id":268544,"PropertyName":"value","Value":"[datafield:note]"},{"Id":224870,"PropertyName":"title","Value":"Eski Değer"},{"Id":11728,"PropertyName":"value","Value":"[datafield:oldvalue]"},{"Id":712378,"PropertyName":"title","Value":"Yeni Değer"},{"Id":326577,"PropertyName":"value","Value":"[datafield:newvalue]"},{"Id":296912,"PropertyName":"title","Value":"Değişlik Yapan Kullanıcı"},{"Id":719900,"PropertyName":"value","Value":"[datafield:username]"},{"Id":227718,"PropertyName":"title","Value":"Değişiklik Tarihi"},{"Id":980798,"PropertyName":"value","Value":"[datafield:logdate]"}]}]
    defaultML = "en_US"
    
    screenHash = ""
    


    constructor(props) {
        super(props);
		this.leaddetail_987199_value_kuikaTableRef = React.createRef();
		this.leaddetail_219536_value_kuikaGalleryViewRef = React.createRef();
		this.leaddetail_810974_value_kuikaTableRef = React.createRef();
		this.leaddetail_148531_value_kuikaSelectBoxRef = React.createRef();
		this.leaddetail_710951_value_kuikaTextInputRef = React.createRef();
		this.leaddetail_764439_value_kuikaTableRef = React.createRef();

        this.state = {
            isSpinnerVisible: false,
            isPageVisible: false,
            isLeftMenuVisible: false,
            spinnerCount: 0,
            selectedLanguage: "",
            isPageInitLoaded: false,
            isPageRecurringLoaded: false,
            	        TM_UserRoleByUserId: [],
	        TM_ShowButton: [],
	        TM_GetLeadStatus: [],
	        TM_CheckLeadApprovalPermission: [],
	        TM_GetLeadById: [],
	        TM_GetReserveEditShow: [],
	        GetLeadNotes: [],
	        TM_GetLeadNoteFileCounts: [],
	        TM_GetLeadLogById: [],
	        TM_GetLeadAlternativeModel: [],
	        TM_GetLeadLogStatu: [],
	        GoBack: "",
	        NAVIGATE: "",
	        TM_LeadNoteDelete: [],
	        Notify: false,
	        TriggerEvent: "",
	        DownloadFile: "",
	        ChangeVisibilityOf: "",
	        isComp725875Visible: 'visible',
	        isComp423129Visible: 'visible',
	        isComp158835Visible: 'hidden',
	        isComp113633Visible: 'hidden',
	        isComp628783Visible: 'hidden',
	        isComp695136Visible: 'hidden',
	        isComp348866Visible: 'hidden',
	        isComp646823Visible: 'hidden',
	        isComp21278Visible: 'hidden',
	        isComp308454Visible: 'hidden',
	        isComp754898Visible: 'hidden',
	        isComp694742Visible: 'hidden',
	        isComp630305Visible: 'hidden',
	        isComp526661Visible: 'hidden',
	        isComp964177Visible: 'hidden',
	        isComp585616Visible: 'hidden',
	        isComp157435Visible: 'hidden',
	        isComp990588Visible: 'hidden',
	        isComp27222Visible: 'hidden',
	        isComp70283Visible: 'hidden',
	        isComp582491Visible: 'hidden',
	        isComp508683Visible: 'hidden',
	        isComp45102Visible: 'hidden',
	        isComp728206Visible: 'hidden',
	        isComp528442Visible: 'hidden',
	        isComp287076Visible: 'hidden',
	        isComp478356Visible: 'hidden',
	        isComp368573Visible: 'hidden',
	        isComp352135Visible: 'hidden',
	        isComp163814Visible: 'hidden',
	        isComp208093Visible: 'hidden',
	        isComp845003Visible: 'hidden',
	        isComp962400Visible: 'hidden',
	        isComp412413Visible: 'hidden',
	        isComp598484Visible: 'hidden',
	        isComp879058Visible: 'hidden',
	        isComp837569Visible: 'hidden',
	        isComp955133Visible: 'hidden',
	        isComp604430Visible: 'hidden',
	        isComp838701Visible: 'hidden',
	        isComp41121Visible: 'hidden',
	        isComp794263Visible: 'hidden',

        }

        this.CheckPageAuthorization(this.state);

        
    }

    async componentDidMount() {

        if (KuikaAppManager.isPageInitPrevented()) {
            KuikaAppManager.calculateAndSetBodyHeight("leaddetail", "");
            return;
        }
        
        
        ReactSystemFunctions.validateToken()
        this.fillFormInitValues();
        if (true){
            await this.LeadDetailPageInit();
        }
        
        
        
        KuikaAppManager.calculateAndSetBodyHeight("leaddetail", "");

        if (ReactSystemFunctions.getIsMicroApp() === false) {
           window.parentScreen = this;
        }
    }

    componentWillUnmount() {
        
        
        

        if (ReactSystemFunctions.getIsMicroApp() === false) {
           window.parentScreen = null;
        }
    }

    
              CheckPageAuthorization = async (state) => {
                KuikaAppManager.showSpinner(this);
                if (_.isEmpty(window.userInfo)) {
                  await UserService.GetUserInfoForce();
                }
                const permittedRoleNames: string[] = ["TimesYonetici","TimesUstYonetici","TimesSatisPersoneli","TimesMagazaMuduru",];
                const userInfo = window.userInfo as IUserInfoDto;
                const userRoleNames = userInfo.roles.map((role) => role.name);
                if (!ReactSystemFunctions.hasAnyRoleName(permittedRoleNames, userRoleNames)) {
                  await ReactSystemFunctions.goBack(this);

                  const language = localStorage.getItem("ml");
                  let permissonErrorMessageText = "You do not have permission to access this page.";
                  if (language === "tr_TR") {
                    permissonErrorMessageText = "Bu sayfaya erişim yetkiniz yok.";
                  } else if (language === "fr_FR") {
                    permissonErrorMessageText = "Vous n'avez pas la permission d'accéder à cette page.";
                  } else if (language === "de_DE") {
                    permissonErrorMessageText = "Sie haben keine Berechtigung, auf diese Seite zuzugreifen.";
                  } else if (language === "es_ES") {
                    permissonErrorMessageText = "No tienes permiso para acceder a esta página.";
                  }

                  KMainFunctions.displayErrorNotification(permissonErrorMessageText);
                  state.isPageVisible = false;
                  KuikaAppManager.hideSpinner(this);
                  return;
                }
                state.isPageVisible = true;
                KuikaAppManager.hideSpinner(this);
              };
        

        
    componentDidUpdate= async (prevProps, prevState) => {
		KuikaAppManager.calculateAndSetBodyHeight("leaddetail", ""    );
        if (prevProps?.location?.search !== (this.props as any)?.location?.search) {
			await this.LeadDetailPageInit();
		}

        

        if (ReactSystemFunctions.getIsMicroApp() === false) {
            for (const key in prevState) {
                if (key.startsWith('NavVisible') && prevState[key] === true && this.state[key] === false) {
                    window.parentScreen = this;
                    break;
                }
            }
        }
	}

    fillFormInitValues() {
        this.props.form?.setFieldsValue({
});

    }

      setPageInitLoaded = (value: boolean) => {
        this.setState({ isPageInitLoaded: value });
      }

      setPageRecurringLoaded = (value: boolean) => {
        this.setState({ isPageRecurringLoaded: value });
      }

      clearFieldValidation = (changedValues: any) => {
        const fieldName = Object.keys(changedValues)[0];
        if (fieldName) {
          this.props.form?.setFields([
            {
              name: fieldName,
              errors: []
            }
          ]);
        }
      };

        checkTabErrors = () => {
    document.querySelectorAll(".rc-tabs-tab").forEach((tab) => {
      (tab as HTMLElement).style.color = "";
    });

    const tabPanes = document.querySelectorAll(".rc-tabs-tabpane");
    const tabs = document.querySelectorAll(".rc-tabs-tab");

    tabPanes.forEach((tabPane, index) => {
      const uniquePaneId = `rc-tabs-tabpane-${index}`;
      if (!tabPane.hasAttribute("id")) {
        tabPane.setAttribute("id", uniquePaneId); 
      }

      const uniqueTabId = `rc-tabs-tab-${index}`;
      if (tabs[index]) {
        if (!tabs[index].hasAttribute("id")) {
          tabs[index].setAttribute("id", uniqueTabId); 
        }
        tabs[index].setAttribute("aria-controls", uniquePaneId);
      }
    });

    const errorElements = document.querySelectorAll(".rc-tabs .ant-form-item-explain-error");

    const tabsWithErrors = new Set<string>();

    errorElements.forEach((errorElement) => {
      const tabPane = errorElement.closest(".rc-tabs-tabpane");
      if (tabPane && tabPane.id) {
        tabsWithErrors.add(tabPane.id);
      }
    });

    tabsWithErrors.forEach((tabPaneId) => {
      const tab = document.querySelector(`.rc-tabs-tab[aria-controls="${tabPaneId}"]`);
      if (tab) {
        (tab as HTMLElement).style.color = "red"; 
      }
    });
  };

    LeadDetailPageInit = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


	if (KuikaAppManager.handleValidations(this, validations, this.checkTabErrors))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }

        let localVar = {
			UserID_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.getMyUserId(), "Guid"),
			LeadId_1: ReactSystemFunctions.convertToTypeByName(this.props.screenInputs.LeadId ?? this.props.screenInputs.leadid, "Guid"),
			UserId_1: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.getMyUserId(), "Guid"),
			IncomingUserRole_3: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, (stateVars.TM_UserRoleByUserId !== undefined ? (stateVars.TM_UserRoleByUserId?.length > 0 ? stateVars.TM_UserRoleByUserId[0].role : null) : (this.state.TM_UserRoleByUserId?.length > 0 ? this.state.TM_UserRoleByUserId[0].role : null))), "string"),
			IncomingLeadId_3: ReactSystemFunctions.convertToTypeByName(this.props.screenInputs.LeadId ?? this.props.screenInputs.leadid, "Guid"),
			LeadId_4: ReactSystemFunctions.convertToTypeByName(this.props.screenInputs.LeadId ?? this.props.screenInputs.leadid, "Guid"),
			UserRole_5: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, (stateVars.TM_UserRoleByUserId !== undefined ? (stateVars.TM_UserRoleByUserId?.length > 0 ? stateVars.TM_UserRoleByUserId[0].roleNames : null) : (this.state.TM_UserRoleByUserId?.length > 0 ? this.state.TM_UserRoleByUserId[0].roleNames : null))), "string"),
			LeadId_5: ReactSystemFunctions.convertToTypeByName(this.props.screenInputs.LeadId ?? this.props.screenInputs.leadid, "Guid"),
			leadId_6: ReactSystemFunctions.convertToTypeByName(this.props.screenInputs.LeadId ?? this.props.screenInputs.leadid, "string"),
			LeadId_7: ReactSystemFunctions.convertToTypeByName(this.props.screenInputs.LeadId ?? this.props.screenInputs.leadid, "Guid"),
			LeadId_8: ReactSystemFunctions.convertToTypeByName(this.props.screenInputs.LeadId ?? this.props.screenInputs.leadid, "Guid"),
			ColumnName_8: ReactSystemFunctions.convertToTypeByName(null, "string"),
			UserName_8: ReactSystemFunctions.convertToTypeByName(null, "string"),
			StartDate_8: ReactSystemFunctions.convertToTypeByName(null, "Date"),
			EndDate_8: ReactSystemFunctions.convertToTypeByName(null, "Date"),
			LeadId_9: ReactSystemFunctions.convertToTypeByName(this.props.screenInputs.LeadId ?? this.props.screenInputs.leadid, "Guid"),
			LeadId_10: ReactSystemFunctions.convertToTypeByName(this.props.screenInputs.LeadId ?? this.props.screenInputs.leadid, "Guid")
        }

	KuikaAppManager.showSpinner(this);
	
        if (true) {
        KuikaAppManager.showSpinner(this);
        }
        let result = await KuikaAppManager.ApiRequest(this, "LeadDetail/LeadDetailPageInit", localVar)
        if (!KMainFunctions.IsResStatus2XX(result)) return true;

		stateVars.TM_UserRoleByUserId = result?.data.tM_UserRoleByUserId;
		stateVars.TM_ShowButton = result?.data.tM_ShowButton;
		formVars.leaddetail_695136_label = ReactSystemFunctions.toString(this, (stateVars.TM_ShowButton !== undefined ? (stateVars.TM_ShowButton?.length > 0 ? stateVars.TM_ShowButton[0].reserveName : null) : (this.state.TM_ShowButton?.length > 0 ? this.state.TM_ShowButton[0].reserveName : null)));
		stateVars.isComp113633Visible = ((ReactSystemFunctions.isNotEqualTo(ReactSystemFunctions.value(this, (stateVars.TM_ShowButton !== undefined ? (stateVars.TM_ShowButton?.length > 0 ? stateVars.TM_ShowButton[0].noAction : null) : (this.state.TM_ShowButton?.length > 0 ? this.state.TM_ShowButton[0].noAction : null))), ReactSystemFunctions.convertToTypeByName("True", "string"))) === true ? "visible" : "hidden")
		stateVars.isComp628783Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, (stateVars.TM_ShowButton !== undefined ? (stateVars.TM_ShowButton?.length > 0 ? stateVars.TM_ShowButton[0].deliverAndSaleShow : null) : (this.state.TM_ShowButton?.length > 0 ? this.state.TM_ShowButton[0].deliverAndSaleShow : null))), ReactSystemFunctions.convertToTypeByName("True", "string"))) === true ? "visible" : "hidden")
		stateVars.isComp695136Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, (stateVars.TM_ShowButton !== undefined ? (stateVars.TM_ShowButton?.length > 0 ? stateVars.TM_ShowButton[0].reserveProductShow : null) : (this.state.TM_ShowButton?.length > 0 ? this.state.TM_ShowButton[0].reserveProductShow : null))), ReactSystemFunctions.convertToTypeByName("True", "string"))) === true ? "visible" : "hidden")
		stateVars.isComp348866Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, (stateVars.TM_ShowButton !== undefined ? (stateVars.TM_ShowButton?.length > 0 ? stateVars.TM_ShowButton[0].reserveEditCancelShow : null) : (this.state.TM_ShowButton?.length > 0 ? this.state.TM_ShowButton[0].reserveEditCancelShow : null))), ReactSystemFunctions.convertToTypeByName("True", "string"))) === true ? "visible" : "hidden")
		stateVars.isComp646823Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, (stateVars.TM_ShowButton !== undefined ? (stateVars.TM_ShowButton?.length > 0 ? stateVars.TM_ShowButton[0].terminOnayShow : null) : (this.state.TM_ShowButton?.length > 0 ? this.state.TM_ShowButton[0].terminOnayShow : null))), ReactSystemFunctions.convertToTypeByName("True", "string"))) === true ? "visible" : "hidden")
		stateVars.isComp21278Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, (stateVars.TM_ShowButton !== undefined ? (stateVars.TM_ShowButton?.length > 0 ? stateVars.TM_ShowButton[0].terminVerOnayaGonderShow : null) : (this.state.TM_ShowButton?.length > 0 ? this.state.TM_ShowButton[0].terminVerOnayaGonderShow : null))), ReactSystemFunctions.convertToTypeByName("True", "string"))) === true ? "visible" : "hidden")
		stateVars.isComp308454Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, (stateVars.TM_ShowButton !== undefined ? (stateVars.TM_ShowButton?.length > 0 ? stateVars.TM_ShowButton[0].rejectShow : null) : (this.state.TM_ShowButton?.length > 0 ? this.state.TM_ShowButton[0].rejectShow : null))), ReactSystemFunctions.convertToTypeByName("True", "string"))) === true ? "visible" : "hidden")
		stateVars.isComp754898Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, (stateVars.TM_ShowButton !== undefined ? (stateVars.TM_ShowButton?.length > 0 ? stateVars.TM_ShowButton[0].customerDeclinedShow : null) : (this.state.TM_ShowButton?.length > 0 ? this.state.TM_ShowButton[0].customerDeclinedShow : null))), ReactSystemFunctions.convertToTypeByName("True", "string"))) === true ? "visible" : "hidden")
		stateVars.isComp694742Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, (stateVars.TM_ShowButton !== undefined ? (stateVars.TM_ShowButton?.length > 0 ? stateVars.TM_ShowButton[0].leadEditShow : null) : (this.state.TM_ShowButton?.length > 0 ? this.state.TM_ShowButton[0].leadEditShow : null))), ReactSystemFunctions.convertToTypeByName("True", "string"))) === true ? "visible" : "hidden")
		stateVars.isComp630305Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, (stateVars.TM_ShowButton !== undefined ? (stateVars.TM_ShowButton?.length > 0 ? stateVars.TM_ShowButton[0].leadEditShow : null) : (this.state.TM_ShowButton?.length > 0 ? this.state.TM_ShowButton[0].leadEditShow : null))), ReactSystemFunctions.convertToTypeByName("True", "string"))) === true ? "visible" : "hidden")
		stateVars.isComp526661Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, (stateVars.TM_ShowButton !== undefined ? (stateVars.TM_ShowButton?.length > 0 ? stateVars.TM_ShowButton[0].leadEditShow : null) : (this.state.TM_ShowButton?.length > 0 ? this.state.TM_ShowButton[0].leadEditShow : null))), ReactSystemFunctions.convertToTypeByName("True", "string"))) === true ? "visible" : "hidden")
		stateVars.isComp879058Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, (stateVars.TM_ShowButton !== undefined ? (stateVars.TM_ShowButton?.length > 0 ? stateVars.TM_ShowButton[0].leadEditShow : null) : (this.state.TM_ShowButton?.length > 0 ? this.state.TM_ShowButton[0].leadEditShow : null))), ReactSystemFunctions.convertToTypeByName("True", "string"))) === true ? "visible" : "hidden")
		stateVars.TM_GetLeadStatus = result?.data.tM_GetLeadStatus;
		stateVars.TM_CheckLeadApprovalPermission = result?.data.tM_CheckLeadApprovalPermission;
		stateVars.TM_GetLeadById = result?.data.tM_GetLeadById;
		formVars.leaddetail_877041_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadById !== undefined ? (stateVars.TM_GetLeadById?.length > 0 ? stateVars.TM_GetLeadById[0].leadCode : null) : (this.state.TM_GetLeadById?.length > 0 ? this.state.TM_GetLeadById[0].leadCode : null)));
		formVars.leaddetail_591206_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadById !== undefined ? (stateVars.TM_GetLeadById?.length > 0 ? stateVars.TM_GetLeadById[0].musteriAdi : null) : (this.state.TM_GetLeadById?.length > 0 ? this.state.TM_GetLeadById[0].musteriAdi : null)));
		formVars.leaddetail_955526_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadById !== undefined ? (stateVars.TM_GetLeadById?.length > 0 ? stateVars.TM_GetLeadById[0].telefonNo : null) : (this.state.TM_GetLeadById?.length > 0 ? this.state.TM_GetLeadById[0].telefonNo : null)));
		formVars.leaddetail_219622_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadById !== undefined ? (stateVars.TM_GetLeadById?.length > 0 ? stateVars.TM_GetLeadById[0].musteriMail : null) : (this.state.TM_GetLeadById?.length > 0 ? this.state.TM_GetLeadById[0].musteriMail : null)));
		formVars.leaddetail_512142_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadById !== undefined ? (stateVars.TM_GetLeadById?.length > 0 ? stateVars.TM_GetLeadById[0].lokasyon : null) : (this.state.TM_GetLeadById?.length > 0 ? this.state.TM_GetLeadById[0].lokasyon : null)));
		formVars.leaddetail_281068_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadById !== undefined ? (stateVars.TM_GetLeadById?.length > 0 ? stateVars.TM_GetLeadById[0].musteriInfo : null) : (this.state.TM_GetLeadById?.length > 0 ? this.state.TM_GetLeadById[0].musteriInfo : null)));
		formVars.leaddetail_964177_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadById !== undefined ? (stateVars.TM_GetLeadById?.length > 0 ? stateVars.TM_GetLeadById[0].categoryName : null) : (this.state.TM_GetLeadById?.length > 0 ? this.state.TM_GetLeadById[0].categoryName : null)));
		formVars.leaddetail_585616_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadById !== undefined ? (stateVars.TM_GetLeadById?.length > 0 ? stateVars.TM_GetLeadById[0].categoryName : null) : (this.state.TM_GetLeadById?.length > 0 ? this.state.TM_GetLeadById[0].categoryName : null)));
		formVars.leaddetail_157435_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadById !== undefined ? (stateVars.TM_GetLeadById?.length > 0 ? stateVars.TM_GetLeadById[0].categoryName : null) : (this.state.TM_GetLeadById?.length > 0 ? this.state.TM_GetLeadById[0].categoryName : null)));
		formVars.leaddetail_990588_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadById !== undefined ? (stateVars.TM_GetLeadById?.length > 0 ? stateVars.TM_GetLeadById[0].categoryName : null) : (this.state.TM_GetLeadById?.length > 0 ? this.state.TM_GetLeadById[0].categoryName : null)));
		formVars.leaddetail_698324_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadById !== undefined ? (stateVars.TM_GetLeadById?.length > 0 ? stateVars.TM_GetLeadById[0].urunAdi : null) : (this.state.TM_GetLeadById?.length > 0 ? this.state.TM_GetLeadById[0].urunAdi : null)));
		formVars.leaddetail_551820_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadById !== undefined ? (stateVars.TM_GetLeadById?.length > 0 ? stateVars.TM_GetLeadById[0].brand : null) : (this.state.TM_GetLeadById?.length > 0 ? this.state.TM_GetLeadById[0].brand : null)));
		formVars.leaddetail_618041_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadById !== undefined ? (stateVars.TM_GetLeadById?.length > 0 ? stateVars.TM_GetLeadById[0].referans : null) : (this.state.TM_GetLeadById?.length > 0 ? this.state.TM_GetLeadById[0].referans : null)));
		formVars.leaddetail_658454_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadById !== undefined ? (stateVars.TM_GetLeadById?.length > 0 ? stateVars.TM_GetLeadById[0].kadran : null) : (this.state.TM_GetLeadById?.length > 0 ? this.state.TM_GetLeadById[0].kadran : null)));
		formVars.leaddetail_103691_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadById !== undefined ? (stateVars.TM_GetLeadById?.length > 0 ? stateVars.TM_GetLeadById[0].bilezik : null) : (this.state.TM_GetLeadById?.length > 0 ? this.state.TM_GetLeadById[0].bilezik : null)));
		formVars.leaddetail_27222_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadById !== undefined ? (stateVars.TM_GetLeadById?.length > 0 ? stateVars.TM_GetLeadById[0].processName : null) : (this.state.TM_GetLeadById?.length > 0 ? this.state.TM_GetLeadById[0].processName : null)));
		formVars.leaddetail_70283_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadById !== undefined ? (stateVars.TM_GetLeadById?.length > 0 ? stateVars.TM_GetLeadById[0].processName : null) : (this.state.TM_GetLeadById?.length > 0 ? this.state.TM_GetLeadById[0].processName : null)));
		formVars.leaddetail_582491_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadById !== undefined ? (stateVars.TM_GetLeadById?.length > 0 ? stateVars.TM_GetLeadById[0].processName : null) : (this.state.TM_GetLeadById?.length > 0 ? this.state.TM_GetLeadById[0].processName : null)));
		formVars.leaddetail_508683_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadById !== undefined ? (stateVars.TM_GetLeadById?.length > 0 ? stateVars.TM_GetLeadById[0].processName : null) : (this.state.TM_GetLeadById?.length > 0 ? this.state.TM_GetLeadById[0].processName : null)));
		formVars.leaddetail_45102_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadById !== undefined ? (stateVars.TM_GetLeadById?.length > 0 ? stateVars.TM_GetLeadById[0].processName : null) : (this.state.TM_GetLeadById?.length > 0 ? this.state.TM_GetLeadById[0].processName : null)));
		formVars.leaddetail_728206_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadById !== undefined ? (stateVars.TM_GetLeadById?.length > 0 ? stateVars.TM_GetLeadById[0].processName : null) : (this.state.TM_GetLeadById?.length > 0 ? this.state.TM_GetLeadById[0].processName : null)));
		formVars.leaddetail_68167_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadById !== undefined ? (stateVars.TM_GetLeadById?.length > 0 ? stateVars.TM_GetLeadById[0].redNotu : null) : (this.state.TM_GetLeadById?.length > 0 ? this.state.TM_GetLeadById[0].redNotu : null)));
		formVars.leaddetail_68167_tooltip = ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadById !== undefined ? (stateVars.TM_GetLeadById?.length > 0 ? stateVars.TM_GetLeadById[0].redNotu : null) : (this.state.TM_GetLeadById?.length > 0 ? this.state.TM_GetLeadById[0].redNotu : null)));
		formVars.leaddetail_774906_value = ReactSystemFunctions.value(this, (stateVars.TM_GetLeadById !== undefined ? (stateVars.TM_GetLeadById?.length > 0 ? stateVars.TM_GetLeadById[0].talepOlusturmaTarihi : null) : (this.state.TM_GetLeadById?.length > 0 ? this.state.TM_GetLeadById[0].talepOlusturmaTarihi : null)));
		formVars.leaddetail_444131_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadById !== undefined ? (stateVars.TM_GetLeadById?.length > 0 ? stateVars.TM_GetLeadById[0].terminTarihi : null) : (this.state.TM_GetLeadById?.length > 0 ? this.state.TM_GetLeadById[0].terminTarihi : null)));
		formVars.leaddetail_287076_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadById !== undefined ? (stateVars.TM_GetLeadById?.length > 0 ? stateVars.TM_GetLeadById[0].takipDurumu : null) : (this.state.TM_GetLeadById?.length > 0 ? this.state.TM_GetLeadById[0].takipDurumu : null)));
		formVars.leaddetail_478356_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadById !== undefined ? (stateVars.TM_GetLeadById?.length > 0 ? stateVars.TM_GetLeadById[0].takipDurumu : null) : (this.state.TM_GetLeadById?.length > 0 ? this.state.TM_GetLeadById[0].takipDurumu : null)));
		formVars.leaddetail_205725_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadById !== undefined ? (stateVars.TM_GetLeadById?.length > 0 ? stateVars.TM_GetLeadById[0].sonrakiAdim : null) : (this.state.TM_GetLeadById?.length > 0 ? this.state.TM_GetLeadById[0].sonrakiAdim : null)));
		formVars.leaddetail_758981_value = ReactSystemFunctions.value(this, (stateVars.TM_GetLeadById !== undefined ? (stateVars.TM_GetLeadById?.length > 0 ? stateVars.TM_GetLeadById[0].sonStatuDegisikligi : null) : (this.state.TM_GetLeadById?.length > 0 ? this.state.TM_GetLeadById[0].sonStatuDegisikligi : null)));
		formVars.leaddetail_275913_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadById !== undefined ? (stateVars.TM_GetLeadById?.length > 0 ? stateVars.TM_GetLeadById[0].magaza : null) : (this.state.TM_GetLeadById?.length > 0 ? this.state.TM_GetLeadById[0].magaza : null)));
		formVars.leaddetail_835532_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadById !== undefined ? (stateVars.TM_GetLeadById?.length > 0 ? stateVars.TM_GetLeadById[0].satisPersoneli : null) : (this.state.TM_GetLeadById?.length > 0 ? this.state.TM_GetLeadById[0].satisPersoneli : null)));
		formVars.leaddetail_71130_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadById !== undefined ? (stateVars.TM_GetLeadById?.length > 0 ? stateVars.TM_GetLeadById[0].talepNotu : null) : (this.state.TM_GetLeadById?.length > 0 ? this.state.TM_GetLeadById[0].talepNotu : null)));
		formVars.leaddetail_9381_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadById !== undefined ? (stateVars.TM_GetLeadById?.length > 0 ? stateVars.TM_GetLeadById[0].rezerveEdenKisi : null) : (this.state.TM_GetLeadById?.length > 0 ? this.state.TM_GetLeadById[0].rezerveEdenKisi : null)));
		formVars.leaddetail_18846_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadById !== undefined ? (stateVars.TM_GetLeadById?.length > 0 ? stateVars.TM_GetLeadById[0].redNotu : null) : (this.state.TM_GetLeadById?.length > 0 ? this.state.TM_GetLeadById[0].redNotu : null)));
		stateVars.isComp964177Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadById !== undefined ? (stateVars.TM_GetLeadById?.length > 0 ? stateVars.TM_GetLeadById[0].categoryName : null) : (this.state.TM_GetLeadById?.length > 0 ? this.state.TM_GetLeadById[0].categoryName : null))), ReactSystemFunctions.convertToTypeByName("Kategori 3", "string"))) === true ? "visible" : "hidden")
		stateVars.isComp585616Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadById !== undefined ? (stateVars.TM_GetLeadById?.length > 0 ? stateVars.TM_GetLeadById[0].categoryName : null) : (this.state.TM_GetLeadById?.length > 0 ? this.state.TM_GetLeadById[0].categoryName : null))), ReactSystemFunctions.convertToTypeByName("Kategori 2", "string"))) === true ? "visible" : "hidden")
		stateVars.isComp157435Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadById !== undefined ? (stateVars.TM_GetLeadById?.length > 0 ? stateVars.TM_GetLeadById[0].categoryName : null) : (this.state.TM_GetLeadById?.length > 0 ? this.state.TM_GetLeadById[0].categoryName : null))), ReactSystemFunctions.convertToTypeByName("Kategori 1", "string"))) === true ? "visible" : "hidden")
		stateVars.isComp990588Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadById !== undefined ? (stateVars.TM_GetLeadById?.length > 0 ? stateVars.TM_GetLeadById[0].categoryName : null) : (this.state.TM_GetLeadById?.length > 0 ? this.state.TM_GetLeadById[0].categoryName : null))), ReactSystemFunctions.convertToTypeByName("DEFAULT", "string"))) === true ? "visible" : "hidden")
		stateVars.isComp27222Visible = (((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadById !== undefined ? (stateVars.TM_GetLeadById?.length > 0 ? stateVars.TM_GetLeadById[0].processCode : null) : (this.state.TM_GetLeadById?.length > 0 ? this.state.TM_GetLeadById[0].processCode : null))), ReactSystemFunctions.convertToTypeByName("CREATED", "string")) || ReactSystemFunctions.isEqualTo(ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadById !== undefined ? (stateVars.TM_GetLeadById?.length > 0 ? stateVars.TM_GetLeadById[0].processCode : null) : (this.state.TM_GetLeadById?.length > 0 ? this.state.TM_GetLeadById[0].processCode : null))), ReactSystemFunctions.convertToTypeByName("APPROVED", "string")))) === true ? "visible" : "hidden")
		stateVars.isComp70283Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadById !== undefined ? (stateVars.TM_GetLeadById?.length > 0 ? stateVars.TM_GetLeadById[0].processCode : null) : (this.state.TM_GetLeadById?.length > 0 ? this.state.TM_GetLeadById[0].processCode : null))), ReactSystemFunctions.convertToTypeByName("REJECTED", "string"))) === true ? "visible" : "hidden")
		stateVars.isComp582491Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadById !== undefined ? (stateVars.TM_GetLeadById?.length > 0 ? stateVars.TM_GetLeadById[0].processCode : null) : (this.state.TM_GetLeadById?.length > 0 ? this.state.TM_GetLeadById[0].processCode : null))), ReactSystemFunctions.convertToTypeByName("CUSTOMER_DECLINED", "string"))) === true ? "visible" : "hidden")
		stateVars.isComp508683Visible = (((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadById !== undefined ? (stateVars.TM_GetLeadById?.length > 0 ? stateVars.TM_GetLeadById[0].processCode : null) : (this.state.TM_GetLeadById?.length > 0 ? this.state.TM_GetLeadById[0].processCode : null))), ReactSystemFunctions.convertToTypeByName("PENDING", "string")) || ReactSystemFunctions.isEqualTo(ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadById !== undefined ? (stateVars.TM_GetLeadById?.length > 0 ? stateVars.TM_GetLeadById[0].processCode : null) : (this.state.TM_GetLeadById?.length > 0 ? this.state.TM_GetLeadById[0].processCode : null))), ReactSystemFunctions.convertToTypeByName("TERMIN_PENDING", "string")) || ReactSystemFunctions.isEqualTo(ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadById !== undefined ? (stateVars.TM_GetLeadById?.length > 0 ? stateVars.TM_GetLeadById[0].processCode : null) : (this.state.TM_GetLeadById?.length > 0 ? this.state.TM_GetLeadById[0].processCode : null))), ReactSystemFunctions.convertToTypeByName("DELIVERY_PENDING", "string")))) === true ? "visible" : "hidden")
		stateVars.isComp45102Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadById !== undefined ? (stateVars.TM_GetLeadById?.length > 0 ? stateVars.TM_GetLeadById[0].processCode : null) : (this.state.TM_GetLeadById?.length > 0 ? this.state.TM_GetLeadById[0].processCode : null))), ReactSystemFunctions.convertToTypeByName("DELIVERED", "string"))) === true ? "visible" : "hidden")
		stateVars.isComp728206Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadById !== undefined ? (stateVars.TM_GetLeadById?.length > 0 ? stateVars.TM_GetLeadById[0].processCode : null) : (this.state.TM_GetLeadById?.length > 0 ? this.state.TM_GetLeadById[0].processCode : null))), ReactSystemFunctions.convertToTypeByName("CLOSED", "string"))) === true ? "visible" : "hidden")
		stateVars.isComp528442Visible = ((ReactSystemFunctions.isNotEmpty(ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadById !== undefined ? (stateVars.TM_GetLeadById?.length > 0 ? stateVars.TM_GetLeadById[0].redNotu : null) : (this.state.TM_GetLeadById?.length > 0 ? this.state.TM_GetLeadById[0].redNotu : null))), ReactSystemFunctions.convertToTypeByName("True", "string"))) === true ? "visible" : "hidden")
		stateVars.isComp287076Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadById !== undefined ? (stateVars.TM_GetLeadById?.length > 0 ? stateVars.TM_GetLeadById[0].takipDurumu : null) : (this.state.TM_GetLeadById?.length > 0 ? this.state.TM_GetLeadById[0].takipDurumu : null))), ReactSystemFunctions.convertToTypeByName("Takip ediliyor", "string"))) === true ? "visible" : "hidden")
		stateVars.isComp478356Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadById !== undefined ? (stateVars.TM_GetLeadById?.length > 0 ? stateVars.TM_GetLeadById[0].takipDurumu : null) : (this.state.TM_GetLeadById?.length > 0 ? this.state.TM_GetLeadById[0].takipDurumu : null))), ReactSystemFunctions.convertToTypeByName("2. Takip", "string"))) === true ? "visible" : "hidden")
		stateVars.isComp368573Visible = ((ReactSystemFunctions.isNotEmpty(ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadById !== undefined ? (stateVars.TM_GetLeadById?.length > 0 ? stateVars.TM_GetLeadById[0].sonStatuDegisikligi : null) : (this.state.TM_GetLeadById?.length > 0 ? this.state.TM_GetLeadById[0].sonStatuDegisikligi : null))), ReactSystemFunctions.convertToTypeByName("True", "string"))) === true ? "visible" : "hidden")
		stateVars.isComp352135Visible = ((ReactSystemFunctions.isNotEmpty(ReactSystemFunctions.value(this, (stateVars.TM_GetLeadById !== undefined ? (stateVars.TM_GetLeadById?.length > 0 ? stateVars.TM_GetLeadById[0].sonStatuDegisikligi : null) : (this.state.TM_GetLeadById?.length > 0 ? this.state.TM_GetLeadById[0].sonStatuDegisikligi : null))), ReactSystemFunctions.convertToTypeByName("True", "string"))) === true ? "visible" : "hidden")
		stateVars.isComp163814Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadById !== undefined ? (stateVars.TM_GetLeadById?.length > 0 ? stateVars.TM_GetLeadById[0].rezervDurumu : null) : (this.state.TM_GetLeadById?.length > 0 ? this.state.TM_GetLeadById[0].rezervDurumu : null))), ReactSystemFunctions.convertToTypeByName("Evet", "string"))) === true ? "visible" : "hidden")
		stateVars.isComp208093Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadById !== undefined ? (stateVars.TM_GetLeadById?.length > 0 ? stateVars.TM_GetLeadById[0].rezervDurumu : null) : (this.state.TM_GetLeadById?.length > 0 ? this.state.TM_GetLeadById[0].rezervDurumu : null))), ReactSystemFunctions.convertToTypeByName("Onay Bekliyor", "string"))) === true ? "visible" : "hidden")
		stateVars.isComp845003Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadById !== undefined ? (stateVars.TM_GetLeadById?.length > 0 ? stateVars.TM_GetLeadById[0].rezervDurumu : null) : (this.state.TM_GetLeadById?.length > 0 ? this.state.TM_GetLeadById[0].rezervDurumu : null))), ReactSystemFunctions.convertToTypeByName("Hayır", "string"))) === true ? "visible" : "hidden")
		stateVars.isComp962400Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, (stateVars.TM_GetLeadById !== undefined ? (stateVars.TM_GetLeadById?.length > 0 ? stateVars.TM_GetLeadById[0].hasApprovedReservation : null) : (this.state.TM_GetLeadById?.length > 0 ? this.state.TM_GetLeadById[0].hasApprovedReservation : null))), ReactSystemFunctions.convertToTypeByName("1", "string"))) === true ? "visible" : "hidden")
		stateVars.isComp412413Visible = ((ReactSystemFunctions.isNotEmpty(ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadById !== undefined ? (stateVars.TM_GetLeadById?.length > 0 ? stateVars.TM_GetLeadById[0].redNotu : null) : (this.state.TM_GetLeadById?.length > 0 ? this.state.TM_GetLeadById[0].redNotu : null))), ReactSystemFunctions.convertToTypeByName("True", "string"))) === true ? "visible" : "hidden")
		stateVars.isComp598484Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, (stateVars.TM_GetLeadById !== undefined ? (stateVars.TM_GetLeadById?.length > 0 ? stateVars.TM_GetLeadById[0].hasApprovedReservation : null) : (this.state.TM_GetLeadById?.length > 0 ? this.state.TM_GetLeadById[0].hasApprovedReservation : null))), ReactSystemFunctions.convertToTypeByName("1", "string"))) === true ? "visible" : "hidden")
		stateVars.TM_GetReserveEditShow = result?.data.tM_GetReserveEditShow;
		stateVars.GetLeadNotes = result?.data.getLeadNotes;
		
		stateVars.TM_GetLeadNoteFileCounts = result?.data.tM_GetLeadNoteFileCounts;
		formVars.leaddetail_252641_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadNoteFileCounts !== undefined ? (stateVars.TM_GetLeadNoteFileCounts?.length > 0 ? stateVars.TM_GetLeadNoteFileCounts[0].noteCount : null) : (this.state.TM_GetLeadNoteFileCounts?.length > 0 ? this.state.TM_GetLeadNoteFileCounts[0].noteCount : null)));
		formVars.leaddetail_536327_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadNoteFileCounts !== undefined ? (stateVars.TM_GetLeadNoteFileCounts?.length > 0 ? stateVars.TM_GetLeadNoteFileCounts[0].fileCount : null) : (this.state.TM_GetLeadNoteFileCounts?.length > 0 ? this.state.TM_GetLeadNoteFileCounts[0].fileCount : null)));
		stateVars.TM_GetLeadLogById = result?.data.tM_GetLeadLogById;
		
		stateVars.TM_GetLeadAlternativeModel = result?.data.tM_GetLeadAlternativeModel;
		
		stateVars.TM_GetLeadLogStatu = result?.data.tM_GetLeadLogStatu;
		
		formVars.leaddetail_148531_options = stateVars.TM_GetLeadLogStatu;
		this.props.form?.setFieldsValue(formVars);
		
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.LeadDetailPageInit1_();
                  resolve();
                });
          })



        
        KuikaAppManager.hideSpinner(this);
        return isErrorOccurred;
    }
	LeadDetailPageInit1_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


	if (KuikaAppManager.handleValidations(this, validations, this.checkTabErrors))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }

			formVars.leaddetail_877041_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadById !== undefined ? (stateVars.TM_GetLeadById?.length > 0 ? stateVars.TM_GetLeadById[0].leadCode : null) : (this.state.TM_GetLeadById?.length > 0 ? this.state.TM_GetLeadById[0].leadCode : null)));

			stateVars.isComp113633Visible = ((ReactSystemFunctions.isNotEqualTo(ReactSystemFunctions.value(this, (stateVars.TM_ShowButton !== undefined ? (stateVars.TM_ShowButton?.length > 0 ? stateVars.TM_ShowButton[0].noAction : null) : (this.state.TM_ShowButton?.length > 0 ? this.state.TM_ShowButton[0].noAction : null))), ReactSystemFunctions.convertToTypeByName("True", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp628783Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, (stateVars.TM_ShowButton !== undefined ? (stateVars.TM_ShowButton?.length > 0 ? stateVars.TM_ShowButton[0].deliverAndSaleShow : null) : (this.state.TM_ShowButton?.length > 0 ? this.state.TM_ShowButton[0].deliverAndSaleShow : null))), ReactSystemFunctions.convertToTypeByName("True", "string"))) === true ? "visible" : "hidden")
			formVars.leaddetail_695136_label = ReactSystemFunctions.toString(this, (stateVars.TM_ShowButton !== undefined ? (stateVars.TM_ShowButton?.length > 0 ? stateVars.TM_ShowButton[0].reserveName : null) : (this.state.TM_ShowButton?.length > 0 ? this.state.TM_ShowButton[0].reserveName : null)));

			stateVars.isComp695136Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, (stateVars.TM_ShowButton !== undefined ? (stateVars.TM_ShowButton?.length > 0 ? stateVars.TM_ShowButton[0].reserveProductShow : null) : (this.state.TM_ShowButton?.length > 0 ? this.state.TM_ShowButton[0].reserveProductShow : null))), ReactSystemFunctions.convertToTypeByName("True", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp348866Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, (stateVars.TM_ShowButton !== undefined ? (stateVars.TM_ShowButton?.length > 0 ? stateVars.TM_ShowButton[0].reserveEditCancelShow : null) : (this.state.TM_ShowButton?.length > 0 ? this.state.TM_ShowButton[0].reserveEditCancelShow : null))), ReactSystemFunctions.convertToTypeByName("True", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp646823Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, (stateVars.TM_ShowButton !== undefined ? (stateVars.TM_ShowButton?.length > 0 ? stateVars.TM_ShowButton[0].terminOnayShow : null) : (this.state.TM_ShowButton?.length > 0 ? this.state.TM_ShowButton[0].terminOnayShow : null))), ReactSystemFunctions.convertToTypeByName("True", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp21278Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, (stateVars.TM_ShowButton !== undefined ? (stateVars.TM_ShowButton?.length > 0 ? stateVars.TM_ShowButton[0].terminVerOnayaGonderShow : null) : (this.state.TM_ShowButton?.length > 0 ? this.state.TM_ShowButton[0].terminVerOnayaGonderShow : null))), ReactSystemFunctions.convertToTypeByName("True", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp308454Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, (stateVars.TM_ShowButton !== undefined ? (stateVars.TM_ShowButton?.length > 0 ? stateVars.TM_ShowButton[0].rejectShow : null) : (this.state.TM_ShowButton?.length > 0 ? this.state.TM_ShowButton[0].rejectShow : null))), ReactSystemFunctions.convertToTypeByName("True", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp754898Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, (stateVars.TM_ShowButton !== undefined ? (stateVars.TM_ShowButton?.length > 0 ? stateVars.TM_ShowButton[0].customerDeclinedShow : null) : (this.state.TM_ShowButton?.length > 0 ? this.state.TM_ShowButton[0].customerDeclinedShow : null))), ReactSystemFunctions.convertToTypeByName("True", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp694742Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, (stateVars.TM_ShowButton !== undefined ? (stateVars.TM_ShowButton?.length > 0 ? stateVars.TM_ShowButton[0].leadEditShow : null) : (this.state.TM_ShowButton?.length > 0 ? this.state.TM_ShowButton[0].leadEditShow : null))), ReactSystemFunctions.convertToTypeByName("True", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp630305Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, (stateVars.TM_ShowButton !== undefined ? (stateVars.TM_ShowButton?.length > 0 ? stateVars.TM_ShowButton[0].leadEditShow : null) : (this.state.TM_ShowButton?.length > 0 ? this.state.TM_ShowButton[0].leadEditShow : null))), ReactSystemFunctions.convertToTypeByName("True", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp526661Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, (stateVars.TM_ShowButton !== undefined ? (stateVars.TM_ShowButton?.length > 0 ? stateVars.TM_ShowButton[0].leadEditShow : null) : (this.state.TM_ShowButton?.length > 0 ? this.state.TM_ShowButton[0].leadEditShow : null))), ReactSystemFunctions.convertToTypeByName("True", "string"))) === true ? "visible" : "hidden")
			formVars.leaddetail_591206_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadById !== undefined ? (stateVars.TM_GetLeadById?.length > 0 ? stateVars.TM_GetLeadById[0].musteriAdi : null) : (this.state.TM_GetLeadById?.length > 0 ? this.state.TM_GetLeadById[0].musteriAdi : null)));

			formVars.leaddetail_955526_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadById !== undefined ? (stateVars.TM_GetLeadById?.length > 0 ? stateVars.TM_GetLeadById[0].telefonNo : null) : (this.state.TM_GetLeadById?.length > 0 ? this.state.TM_GetLeadById[0].telefonNo : null)));

			formVars.leaddetail_219622_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadById !== undefined ? (stateVars.TM_GetLeadById?.length > 0 ? stateVars.TM_GetLeadById[0].musteriMail : null) : (this.state.TM_GetLeadById?.length > 0 ? this.state.TM_GetLeadById[0].musteriMail : null)));

			formVars.leaddetail_512142_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadById !== undefined ? (stateVars.TM_GetLeadById?.length > 0 ? stateVars.TM_GetLeadById[0].lokasyon : null) : (this.state.TM_GetLeadById?.length > 0 ? this.state.TM_GetLeadById[0].lokasyon : null)));

			formVars.leaddetail_281068_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadById !== undefined ? (stateVars.TM_GetLeadById?.length > 0 ? stateVars.TM_GetLeadById[0].musteriInfo : null) : (this.state.TM_GetLeadById?.length > 0 ? this.state.TM_GetLeadById[0].musteriInfo : null)));

			formVars.leaddetail_964177_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadById !== undefined ? (stateVars.TM_GetLeadById?.length > 0 ? stateVars.TM_GetLeadById[0].categoryName : null) : (this.state.TM_GetLeadById?.length > 0 ? this.state.TM_GetLeadById[0].categoryName : null)));

			stateVars.isComp964177Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadById !== undefined ? (stateVars.TM_GetLeadById?.length > 0 ? stateVars.TM_GetLeadById[0].categoryName : null) : (this.state.TM_GetLeadById?.length > 0 ? this.state.TM_GetLeadById[0].categoryName : null))), ReactSystemFunctions.convertToTypeByName("Kategori 3", "string"))) === true ? "visible" : "hidden")
			formVars.leaddetail_585616_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadById !== undefined ? (stateVars.TM_GetLeadById?.length > 0 ? stateVars.TM_GetLeadById[0].categoryName : null) : (this.state.TM_GetLeadById?.length > 0 ? this.state.TM_GetLeadById[0].categoryName : null)));

			stateVars.isComp585616Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadById !== undefined ? (stateVars.TM_GetLeadById?.length > 0 ? stateVars.TM_GetLeadById[0].categoryName : null) : (this.state.TM_GetLeadById?.length > 0 ? this.state.TM_GetLeadById[0].categoryName : null))), ReactSystemFunctions.convertToTypeByName("Kategori 2", "string"))) === true ? "visible" : "hidden")
			formVars.leaddetail_157435_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadById !== undefined ? (stateVars.TM_GetLeadById?.length > 0 ? stateVars.TM_GetLeadById[0].categoryName : null) : (this.state.TM_GetLeadById?.length > 0 ? this.state.TM_GetLeadById[0].categoryName : null)));

			stateVars.isComp157435Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadById !== undefined ? (stateVars.TM_GetLeadById?.length > 0 ? stateVars.TM_GetLeadById[0].categoryName : null) : (this.state.TM_GetLeadById?.length > 0 ? this.state.TM_GetLeadById[0].categoryName : null))), ReactSystemFunctions.convertToTypeByName("Kategori 1", "string"))) === true ? "visible" : "hidden")
			formVars.leaddetail_990588_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadById !== undefined ? (stateVars.TM_GetLeadById?.length > 0 ? stateVars.TM_GetLeadById[0].categoryName : null) : (this.state.TM_GetLeadById?.length > 0 ? this.state.TM_GetLeadById[0].categoryName : null)));

			stateVars.isComp990588Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadById !== undefined ? (stateVars.TM_GetLeadById?.length > 0 ? stateVars.TM_GetLeadById[0].categoryName : null) : (this.state.TM_GetLeadById?.length > 0 ? this.state.TM_GetLeadById[0].categoryName : null))), ReactSystemFunctions.convertToTypeByName("DEFAULT", "string"))) === true ? "visible" : "hidden")
			formVars.leaddetail_698324_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadById !== undefined ? (stateVars.TM_GetLeadById?.length > 0 ? stateVars.TM_GetLeadById[0].urunAdi : null) : (this.state.TM_GetLeadById?.length > 0 ? this.state.TM_GetLeadById[0].urunAdi : null)));

			formVars.leaddetail_551820_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadById !== undefined ? (stateVars.TM_GetLeadById?.length > 0 ? stateVars.TM_GetLeadById[0].brand : null) : (this.state.TM_GetLeadById?.length > 0 ? this.state.TM_GetLeadById[0].brand : null)));

			formVars.leaddetail_618041_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadById !== undefined ? (stateVars.TM_GetLeadById?.length > 0 ? stateVars.TM_GetLeadById[0].referans : null) : (this.state.TM_GetLeadById?.length > 0 ? this.state.TM_GetLeadById[0].referans : null)));

			formVars.leaddetail_658454_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadById !== undefined ? (stateVars.TM_GetLeadById?.length > 0 ? stateVars.TM_GetLeadById[0].kadran : null) : (this.state.TM_GetLeadById?.length > 0 ? this.state.TM_GetLeadById[0].kadran : null)));

			formVars.leaddetail_103691_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadById !== undefined ? (stateVars.TM_GetLeadById?.length > 0 ? stateVars.TM_GetLeadById[0].bilezik : null) : (this.state.TM_GetLeadById?.length > 0 ? this.state.TM_GetLeadById[0].bilezik : null)));

			formVars.leaddetail_27222_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadById !== undefined ? (stateVars.TM_GetLeadById?.length > 0 ? stateVars.TM_GetLeadById[0].processName : null) : (this.state.TM_GetLeadById?.length > 0 ? this.state.TM_GetLeadById[0].processName : null)));

			stateVars.isComp27222Visible = (((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadById !== undefined ? (stateVars.TM_GetLeadById?.length > 0 ? stateVars.TM_GetLeadById[0].processCode : null) : (this.state.TM_GetLeadById?.length > 0 ? this.state.TM_GetLeadById[0].processCode : null))), ReactSystemFunctions.convertToTypeByName("CREATED", "string")) || ReactSystemFunctions.isEqualTo(ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadById !== undefined ? (stateVars.TM_GetLeadById?.length > 0 ? stateVars.TM_GetLeadById[0].processCode : null) : (this.state.TM_GetLeadById?.length > 0 ? this.state.TM_GetLeadById[0].processCode : null))), ReactSystemFunctions.convertToTypeByName("APPROVED", "string")))) === true ? "visible" : "hidden")
			formVars.leaddetail_70283_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadById !== undefined ? (stateVars.TM_GetLeadById?.length > 0 ? stateVars.TM_GetLeadById[0].processName : null) : (this.state.TM_GetLeadById?.length > 0 ? this.state.TM_GetLeadById[0].processName : null)));

			stateVars.isComp70283Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadById !== undefined ? (stateVars.TM_GetLeadById?.length > 0 ? stateVars.TM_GetLeadById[0].processCode : null) : (this.state.TM_GetLeadById?.length > 0 ? this.state.TM_GetLeadById[0].processCode : null))), ReactSystemFunctions.convertToTypeByName("REJECTED", "string"))) === true ? "visible" : "hidden")
			formVars.leaddetail_582491_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadById !== undefined ? (stateVars.TM_GetLeadById?.length > 0 ? stateVars.TM_GetLeadById[0].processName : null) : (this.state.TM_GetLeadById?.length > 0 ? this.state.TM_GetLeadById[0].processName : null)));

			stateVars.isComp582491Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadById !== undefined ? (stateVars.TM_GetLeadById?.length > 0 ? stateVars.TM_GetLeadById[0].processCode : null) : (this.state.TM_GetLeadById?.length > 0 ? this.state.TM_GetLeadById[0].processCode : null))), ReactSystemFunctions.convertToTypeByName("CUSTOMER_DECLINED", "string"))) === true ? "visible" : "hidden")
			formVars.leaddetail_508683_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadById !== undefined ? (stateVars.TM_GetLeadById?.length > 0 ? stateVars.TM_GetLeadById[0].processName : null) : (this.state.TM_GetLeadById?.length > 0 ? this.state.TM_GetLeadById[0].processName : null)));

			stateVars.isComp508683Visible = (((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadById !== undefined ? (stateVars.TM_GetLeadById?.length > 0 ? stateVars.TM_GetLeadById[0].processCode : null) : (this.state.TM_GetLeadById?.length > 0 ? this.state.TM_GetLeadById[0].processCode : null))), ReactSystemFunctions.convertToTypeByName("PENDING", "string")) || ReactSystemFunctions.isEqualTo(ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadById !== undefined ? (stateVars.TM_GetLeadById?.length > 0 ? stateVars.TM_GetLeadById[0].processCode : null) : (this.state.TM_GetLeadById?.length > 0 ? this.state.TM_GetLeadById[0].processCode : null))), ReactSystemFunctions.convertToTypeByName("TERMIN_PENDING", "string")) || ReactSystemFunctions.isEqualTo(ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadById !== undefined ? (stateVars.TM_GetLeadById?.length > 0 ? stateVars.TM_GetLeadById[0].processCode : null) : (this.state.TM_GetLeadById?.length > 0 ? this.state.TM_GetLeadById[0].processCode : null))), ReactSystemFunctions.convertToTypeByName("DELIVERY_PENDING", "string")))) === true ? "visible" : "hidden")
			formVars.leaddetail_45102_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadById !== undefined ? (stateVars.TM_GetLeadById?.length > 0 ? stateVars.TM_GetLeadById[0].processName : null) : (this.state.TM_GetLeadById?.length > 0 ? this.state.TM_GetLeadById[0].processName : null)));

			stateVars.isComp45102Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadById !== undefined ? (stateVars.TM_GetLeadById?.length > 0 ? stateVars.TM_GetLeadById[0].processCode : null) : (this.state.TM_GetLeadById?.length > 0 ? this.state.TM_GetLeadById[0].processCode : null))), ReactSystemFunctions.convertToTypeByName("DELIVERED", "string"))) === true ? "visible" : "hidden")
			formVars.leaddetail_728206_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadById !== undefined ? (stateVars.TM_GetLeadById?.length > 0 ? stateVars.TM_GetLeadById[0].processName : null) : (this.state.TM_GetLeadById?.length > 0 ? this.state.TM_GetLeadById[0].processName : null)));

			stateVars.isComp728206Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadById !== undefined ? (stateVars.TM_GetLeadById?.length > 0 ? stateVars.TM_GetLeadById[0].processCode : null) : (this.state.TM_GetLeadById?.length > 0 ? this.state.TM_GetLeadById[0].processCode : null))), ReactSystemFunctions.convertToTypeByName("CLOSED", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp528442Visible = ((ReactSystemFunctions.isNotEmpty(ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadById !== undefined ? (stateVars.TM_GetLeadById?.length > 0 ? stateVars.TM_GetLeadById[0].redNotu : null) : (this.state.TM_GetLeadById?.length > 0 ? this.state.TM_GetLeadById[0].redNotu : null))), ReactSystemFunctions.convertToTypeByName("True", "string"))) === true ? "visible" : "hidden")
			formVars.leaddetail_68167_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadById !== undefined ? (stateVars.TM_GetLeadById?.length > 0 ? stateVars.TM_GetLeadById[0].redNotu : null) : (this.state.TM_GetLeadById?.length > 0 ? this.state.TM_GetLeadById[0].redNotu : null)));
formVars.leaddetail_68167_tooltip = ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadById !== undefined ? (stateVars.TM_GetLeadById?.length > 0 ? stateVars.TM_GetLeadById[0].redNotu : null) : (this.state.TM_GetLeadById?.length > 0 ? this.state.TM_GetLeadById[0].redNotu : null)));

			formVars.leaddetail_68167_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadById !== undefined ? (stateVars.TM_GetLeadById?.length > 0 ? stateVars.TM_GetLeadById[0].redNotu : null) : (this.state.TM_GetLeadById?.length > 0 ? this.state.TM_GetLeadById[0].redNotu : null)));
formVars.leaddetail_68167_tooltip = ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadById !== undefined ? (stateVars.TM_GetLeadById?.length > 0 ? stateVars.TM_GetLeadById[0].redNotu : null) : (this.state.TM_GetLeadById?.length > 0 ? this.state.TM_GetLeadById[0].redNotu : null)));

			formVars.leaddetail_774906_value = ReactSystemFunctions.value(this, (stateVars.TM_GetLeadById !== undefined ? (stateVars.TM_GetLeadById?.length > 0 ? stateVars.TM_GetLeadById[0].talepOlusturmaTarihi : null) : (this.state.TM_GetLeadById?.length > 0 ? this.state.TM_GetLeadById[0].talepOlusturmaTarihi : null)));

			formVars.leaddetail_444131_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadById !== undefined ? (stateVars.TM_GetLeadById?.length > 0 ? stateVars.TM_GetLeadById[0].terminTarihi : null) : (this.state.TM_GetLeadById?.length > 0 ? this.state.TM_GetLeadById[0].terminTarihi : null)));

			formVars.leaddetail_287076_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadById !== undefined ? (stateVars.TM_GetLeadById?.length > 0 ? stateVars.TM_GetLeadById[0].takipDurumu : null) : (this.state.TM_GetLeadById?.length > 0 ? this.state.TM_GetLeadById[0].takipDurumu : null)));

			stateVars.isComp287076Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadById !== undefined ? (stateVars.TM_GetLeadById?.length > 0 ? stateVars.TM_GetLeadById[0].takipDurumu : null) : (this.state.TM_GetLeadById?.length > 0 ? this.state.TM_GetLeadById[0].takipDurumu : null))), ReactSystemFunctions.convertToTypeByName("Takip ediliyor", "string"))) === true ? "visible" : "hidden")
			formVars.leaddetail_478356_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadById !== undefined ? (stateVars.TM_GetLeadById?.length > 0 ? stateVars.TM_GetLeadById[0].takipDurumu : null) : (this.state.TM_GetLeadById?.length > 0 ? this.state.TM_GetLeadById[0].takipDurumu : null)));

			stateVars.isComp478356Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadById !== undefined ? (stateVars.TM_GetLeadById?.length > 0 ? stateVars.TM_GetLeadById[0].takipDurumu : null) : (this.state.TM_GetLeadById?.length > 0 ? this.state.TM_GetLeadById[0].takipDurumu : null))), ReactSystemFunctions.convertToTypeByName("2. Takip", "string"))) === true ? "visible" : "hidden")
			formVars.leaddetail_205725_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadById !== undefined ? (stateVars.TM_GetLeadById?.length > 0 ? stateVars.TM_GetLeadById[0].sonrakiAdim : null) : (this.state.TM_GetLeadById?.length > 0 ? this.state.TM_GetLeadById[0].sonrakiAdim : null)));

			stateVars.isComp368573Visible = ((ReactSystemFunctions.isNotEmpty(ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadById !== undefined ? (stateVars.TM_GetLeadById?.length > 0 ? stateVars.TM_GetLeadById[0].sonStatuDegisikligi : null) : (this.state.TM_GetLeadById?.length > 0 ? this.state.TM_GetLeadById[0].sonStatuDegisikligi : null))), ReactSystemFunctions.convertToTypeByName("True", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp352135Visible = ((ReactSystemFunctions.isNotEmpty(ReactSystemFunctions.value(this, (stateVars.TM_GetLeadById !== undefined ? (stateVars.TM_GetLeadById?.length > 0 ? stateVars.TM_GetLeadById[0].sonStatuDegisikligi : null) : (this.state.TM_GetLeadById?.length > 0 ? this.state.TM_GetLeadById[0].sonStatuDegisikligi : null))), ReactSystemFunctions.convertToTypeByName("True", "string"))) === true ? "visible" : "hidden")
			formVars.leaddetail_758981_value = ReactSystemFunctions.value(this, (stateVars.TM_GetLeadById !== undefined ? (stateVars.TM_GetLeadById?.length > 0 ? stateVars.TM_GetLeadById[0].sonStatuDegisikligi : null) : (this.state.TM_GetLeadById?.length > 0 ? this.state.TM_GetLeadById[0].sonStatuDegisikligi : null)));

			formVars.leaddetail_275913_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadById !== undefined ? (stateVars.TM_GetLeadById?.length > 0 ? stateVars.TM_GetLeadById[0].magaza : null) : (this.state.TM_GetLeadById?.length > 0 ? this.state.TM_GetLeadById[0].magaza : null)));

			formVars.leaddetail_835532_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadById !== undefined ? (stateVars.TM_GetLeadById?.length > 0 ? stateVars.TM_GetLeadById[0].satisPersoneli : null) : (this.state.TM_GetLeadById?.length > 0 ? this.state.TM_GetLeadById[0].satisPersoneli : null)));

			formVars.leaddetail_71130_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadById !== undefined ? (stateVars.TM_GetLeadById?.length > 0 ? stateVars.TM_GetLeadById[0].talepNotu : null) : (this.state.TM_GetLeadById?.length > 0 ? this.state.TM_GetLeadById[0].talepNotu : null)));

			stateVars.isComp163814Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadById !== undefined ? (stateVars.TM_GetLeadById?.length > 0 ? stateVars.TM_GetLeadById[0].rezervDurumu : null) : (this.state.TM_GetLeadById?.length > 0 ? this.state.TM_GetLeadById[0].rezervDurumu : null))), ReactSystemFunctions.convertToTypeByName("Evet", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp208093Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadById !== undefined ? (stateVars.TM_GetLeadById?.length > 0 ? stateVars.TM_GetLeadById[0].rezervDurumu : null) : (this.state.TM_GetLeadById?.length > 0 ? this.state.TM_GetLeadById[0].rezervDurumu : null))), ReactSystemFunctions.convertToTypeByName("Onay Bekliyor", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp845003Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadById !== undefined ? (stateVars.TM_GetLeadById?.length > 0 ? stateVars.TM_GetLeadById[0].rezervDurumu : null) : (this.state.TM_GetLeadById?.length > 0 ? this.state.TM_GetLeadById[0].rezervDurumu : null))), ReactSystemFunctions.convertToTypeByName("Hayır", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp962400Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, (stateVars.TM_GetLeadById !== undefined ? (stateVars.TM_GetLeadById?.length > 0 ? stateVars.TM_GetLeadById[0].hasApprovedReservation : null) : (this.state.TM_GetLeadById?.length > 0 ? this.state.TM_GetLeadById[0].hasApprovedReservation : null))), ReactSystemFunctions.convertToTypeByName("1", "string"))) === true ? "visible" : "hidden")
			formVars.leaddetail_9381_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadById !== undefined ? (stateVars.TM_GetLeadById?.length > 0 ? stateVars.TM_GetLeadById[0].rezerveEdenKisi : null) : (this.state.TM_GetLeadById?.length > 0 ? this.state.TM_GetLeadById[0].rezerveEdenKisi : null)));

			stateVars.isComp412413Visible = ((ReactSystemFunctions.isNotEmpty(ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadById !== undefined ? (stateVars.TM_GetLeadById?.length > 0 ? stateVars.TM_GetLeadById[0].redNotu : null) : (this.state.TM_GetLeadById?.length > 0 ? this.state.TM_GetLeadById[0].redNotu : null))), ReactSystemFunctions.convertToTypeByName("True", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp598484Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, (stateVars.TM_GetLeadById !== undefined ? (stateVars.TM_GetLeadById?.length > 0 ? stateVars.TM_GetLeadById[0].hasApprovedReservation : null) : (this.state.TM_GetLeadById?.length > 0 ? this.state.TM_GetLeadById[0].hasApprovedReservation : null))), ReactSystemFunctions.convertToTypeByName("1", "string"))) === true ? "visible" : "hidden")
			formVars.leaddetail_18846_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadById !== undefined ? (stateVars.TM_GetLeadById?.length > 0 ? stateVars.TM_GetLeadById[0].redNotu : null) : (this.state.TM_GetLeadById?.length > 0 ? this.state.TM_GetLeadById[0].redNotu : null)));

			stateVars.isComp879058Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, (stateVars.TM_ShowButton !== undefined ? (stateVars.TM_ShowButton?.length > 0 ? stateVars.TM_ShowButton[0].leadEditShow : null) : (this.state.TM_ShowButton?.length > 0 ? this.state.TM_ShowButton[0].leadEditShow : null))), ReactSystemFunctions.convertToTypeByName("True", "string"))) === true ? "visible" : "hidden")
			
			stateVars.dataSource_987199 = stateVars.TM_GetLeadAlternativeModel ?? this.state.TM_GetLeadAlternativeModel;
			stateVars.isComp837569Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, "leaddetail_987199_value", "categoryName"), ReactSystemFunctions.convertToTypeByName("Kategori 3", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp955133Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, "leaddetail_987199_value", "categoryName"), ReactSystemFunctions.convertToTypeByName("Kategori 2", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp604430Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, "leaddetail_987199_value", "categoryName"), ReactSystemFunctions.convertToTypeByName("Kategori 1", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp838701Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, "leaddetail_987199_value", "categoryName"), ReactSystemFunctions.convertToTypeByName("DEFAULT", "string"))) === true ? "visible" : "hidden")
			formVars.leaddetail_252641_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadNoteFileCounts !== undefined ? (stateVars.TM_GetLeadNoteFileCounts?.length > 0 ? stateVars.TM_GetLeadNoteFileCounts[0].noteCount : null) : (this.state.TM_GetLeadNoteFileCounts?.length > 0 ? this.state.TM_GetLeadNoteFileCounts[0].noteCount : null)));

			formVars.leaddetail_536327_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadNoteFileCounts !== undefined ? (stateVars.TM_GetLeadNoteFileCounts?.length > 0 ? stateVars.TM_GetLeadNoteFileCounts[0].fileCount : null) : (this.state.TM_GetLeadNoteFileCounts?.length > 0 ? this.state.TM_GetLeadNoteFileCounts[0].fileCount : null)));

			
			stateVars.dataSource_219536 = stateVars.GetLeadNotes ?? this.state.GetLeadNotes;
			stateVars.isComp41121Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.getMyFullName(), ReactSystemFunctions.value(this, "leaddetail_219536_value", "createdByName"))) === true ? "visible" : "hidden")
			stateVars.isComp794263Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, "leaddetail_219536_value", "hasFiles"), ReactSystemFunctions.convertToTypeByName("True", "string"))) === true ? "visible" : "hidden")
			
			
			
			stateVars.dataSource_148531 = stateVars.TM_GetLeadLogStatu ?? this.state.TM_GetLeadLogStatu;
			stateVars.dataSource_148531 = stateVars.TM_GetLeadLogStatu ?? this.state.TM_GetLeadLogStatu;
			
			stateVars.dataSource_764439 = stateVars.TM_GetLeadLogById ?? this.state.TM_GetLeadLogById;

	this.props.form?.setFieldsValue(formVars);
	this.setState(stateVars);
	KuikaAppManager.hideSpinner(this);

            this.setPageInitLoaded(true);
            return isErrorOccurred;
        }




		LeadDetailComponent_5757_onClick = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations, this.checkTabErrors))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
KuikaAppManager.showSpinner(this);

				stateVars.GoBack = await ReactSystemFunctions.goBack(this, false);

		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

            
            return isErrorOccurred;
        }


		LeadDetailComponent_628783_onClick = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations, this.checkTabErrors))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
KuikaAppManager.showSpinner(this);

					KuikaAppManager.prepareForNavigation();
						KuikaAppManager.addToPageInputVariables("SalesWeb", "LeadId", ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, (stateVars.TM_GetLeadById !== undefined ? (stateVars.TM_GetLeadById?.length > 0 ? stateVars.TM_GetLeadById[0].leadId : null) : (this.state.TM_GetLeadById?.length > 0 ? this.state.TM_GetLeadById[0].leadId : null))), "Guid"));

				stateVars.NAVIGATE = await ReactSystemFunctions.navigate(this, undefined, "LeadDetail", "SalesWeb", "", "currentPage", null, null, null, null, null, null, true, false);

		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

            
            return isErrorOccurred;
        }


		LeadDetailComponent_695136_onClick = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations, this.checkTabErrors))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
KuikaAppManager.showSpinner(this);

					KuikaAppManager.prepareForNavigation();
						KuikaAppManager.addToPageInputVariables("ReservationPopUp", "StoreCode", ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadById !== undefined ? (stateVars.TM_GetLeadById?.length > 0 ? stateVars.TM_GetLeadById[0].storeCode : null) : (this.state.TM_GetLeadById?.length > 0 ? this.state.TM_GetLeadById[0].storeCode : null))), "string"));
						KuikaAppManager.addToPageInputVariables("ReservationPopUp", "ProductCode", ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadById !== undefined ? (stateVars.TM_GetLeadById?.length > 0 ? stateVars.TM_GetLeadById[0].productCode : null) : (this.state.TM_GetLeadById?.length > 0 ? this.state.TM_GetLeadById[0].productCode : null))), "string"));
						KuikaAppManager.addToPageInputVariables("ReservationPopUp", "LeadId", ReactSystemFunctions.convertToTypeByName(this.props.screenInputs.LeadId ?? this.props.screenInputs.leadid, "Guid"));

				stateVars.NAVIGATE = await ReactSystemFunctions.navigate(this, undefined, "LeadDetail", "ReservationPopUp", "", "9924ef5f-4b84-4200-b624-8d76348c7686", "999526", null, null, "true", "800px", "70vh", true, false);

		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

            
            return isErrorOccurred;
        }


		LeadDetailComponent_348866_onClick = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations, this.checkTabErrors))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
KuikaAppManager.showSpinner(this);

					KuikaAppManager.prepareForNavigation();
						KuikaAppManager.addToPageInputVariables("ReservationEdit", "LeadId", ReactSystemFunctions.convertToTypeByName(this.props.screenInputs.LeadId ?? this.props.screenInputs.leadid, "Guid"));

				stateVars.NAVIGATE = await ReactSystemFunctions.navigate(this, undefined, "LeadDetail", "ReservationEdit", "", "7d969ddf-5801-4eb6-b92b-12be35bdd565", "293274", null, null, null, null, null, true, false);

		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

            
            return isErrorOccurred;
        }


		LeadDetailComponent_646823_onClick = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations, this.checkTabErrors))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
KuikaAppManager.showSpinner(this);

					KuikaAppManager.prepareForNavigation();
						KuikaAppManager.addToPageInputVariables("ApproveLead", "LeadId", ReactSystemFunctions.convertToTypeByName(this.props.screenInputs.LeadId ?? this.props.screenInputs.leadid, "Guid"));

				stateVars.NAVIGATE = await ReactSystemFunctions.navigate(this, undefined, "LeadDetail", "ApproveLead", "", "currentPage", null, null, null, null, null, null, true, false);

		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

            
            return isErrorOccurred;
        }


		LeadDetailComponent_21278_onClick = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations, this.checkTabErrors))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
KuikaAppManager.showSpinner(this);

					KuikaAppManager.prepareForNavigation();
						KuikaAppManager.addToPageInputVariables("TerminPendingLead", "LeadId", ReactSystemFunctions.convertToTypeByName(this.props.screenInputs.LeadId ?? this.props.screenInputs.leadid, "Guid"));

				stateVars.NAVIGATE = await ReactSystemFunctions.navigate(this, undefined, "LeadDetail", "TerminPendingLead", "", "currentPage", null, null, null, null, null, null, true, false);

		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

            
            return isErrorOccurred;
        }


		LeadDetailComponent_308454_onClick = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations, this.checkTabErrors))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
KuikaAppManager.showSpinner(this);

					KuikaAppManager.prepareForNavigation();
						KuikaAppManager.addToPageInputVariables("LeadRejectPopUp", "LeadId", ReactSystemFunctions.convertToTypeByName(this.props.screenInputs.LeadId ?? this.props.screenInputs.leadid, "Guid"));

				stateVars.NAVIGATE = await ReactSystemFunctions.navigate(this, undefined, "LeadDetail", "LeadRejectPopUp", "", "9924ef5f-4b84-4200-b624-8d76348c7686", "897956", null, null, "true", "800px", "70vh", true, false);

		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

            
            return isErrorOccurred;
        }


		LeadDetailComponent_754898_onClick = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations, this.checkTabErrors))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
KuikaAppManager.showSpinner(this);

					KuikaAppManager.prepareForNavigation();
						KuikaAppManager.addToPageInputVariables("LeadRejectCustomerPopUp", "LeadId", ReactSystemFunctions.convertToTypeByName(this.props.screenInputs.LeadId ?? this.props.screenInputs.leadid, "Guid"));

				stateVars.NAVIGATE = await ReactSystemFunctions.navigate(this, undefined, "LeadDetail", "LeadRejectCustomerPopUp", "", "9924ef5f-4b84-4200-b624-8d76348c7686", "81031", null, null, "true", "800px", "70vh", true, false);

		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

            
            return isErrorOccurred;
        }


		LeadDetailComponent_630305_onClick = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations, this.checkTabErrors))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
KuikaAppManager.showSpinner(this);

					KuikaAppManager.prepareForNavigation();
						KuikaAppManager.addToPageInputVariables("LeadUpdate", "LeadId", ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, (stateVars.TM_GetLeadById !== undefined ? (stateVars.TM_GetLeadById?.length > 0 ? stateVars.TM_GetLeadById[0].leadId : null) : (this.state.TM_GetLeadById?.length > 0 ? this.state.TM_GetLeadById[0].leadId : null))), "Guid"));
						KuikaAppManager.addToPageInputVariables("LeadUpdate", "ProductId", ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, (stateVars.TM_GetLeadById !== undefined ? (stateVars.TM_GetLeadById?.length > 0 ? stateVars.TM_GetLeadById[0].productId : null) : (this.state.TM_GetLeadById?.length > 0 ? this.state.TM_GetLeadById[0].productId : null))), "Guid"));

				stateVars.NAVIGATE = await ReactSystemFunctions.navigate(this, undefined, "LeadDetail", "LeadUpdate", "", "7d969ddf-5801-4eb6-b92b-12be35bdd565", "191307", null, "right", "true", "60vw", "100vh", true, false);

		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

            
            return isErrorOccurred;
        }


		LeadDetailComponent_526661_onClick = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations, this.checkTabErrors))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
KuikaAppManager.showSpinner(this);

					KuikaAppManager.prepareForNavigation();
						KuikaAppManager.addToPageInputVariables("LeadProductChange", "LeadCode", ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadById !== undefined ? (stateVars.TM_GetLeadById?.length > 0 ? stateVars.TM_GetLeadById[0].leadCode : null) : (this.state.TM_GetLeadById?.length > 0 ? this.state.TM_GetLeadById[0].leadCode : null))), "string"));
						KuikaAppManager.addToPageInputVariables("LeadProductChange", "LeadId", ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, (stateVars.TM_GetLeadById !== undefined ? (stateVars.TM_GetLeadById?.length > 0 ? stateVars.TM_GetLeadById[0].leadId : null) : (this.state.TM_GetLeadById?.length > 0 ? this.state.TM_GetLeadById[0].leadId : null))), "Guid"));

				stateVars.NAVIGATE = await ReactSystemFunctions.navigate(this, undefined, "LeadDetail", "LeadProductChange", "", "7d969ddf-5801-4eb6-b92b-12be35bdd565", "423975", null, "right", "true", "60vw", "100vh", true, false);

		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

            
            return isErrorOccurred;
        }


		LeadDetailComponent_940366_onClick = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations, this.checkTabErrors))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
KuikaAppManager.showSpinner(this);

					KuikaAppManager.prepareForNavigation();
						KuikaAppManager.addToPageInputVariables("CustomerDetailPage", "customerCode", ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadById !== undefined ? (stateVars.TM_GetLeadById?.length > 0 ? stateVars.TM_GetLeadById[0].currAccCode : null) : (this.state.TM_GetLeadById?.length > 0 ? this.state.TM_GetLeadById[0].currAccCode : null))), "string"));
						KuikaAppManager.addToPageInputVariables("CustomerDetailPage", "CustomerId", ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, (stateVars.TM_GetLeadById !== undefined ? (stateVars.TM_GetLeadById?.length > 0 ? stateVars.TM_GetLeadById[0].customerId : null) : (this.state.TM_GetLeadById?.length > 0 ? this.state.TM_GetLeadById[0].customerId : null))), "Guid"));

				stateVars.NAVIGATE = await ReactSystemFunctions.navigate(this, undefined, "LeadDetail", "CustomerDetailPage", "", "7d969ddf-5801-4eb6-b92b-12be35bdd565", "899644", null, "right", "true", "60vw", "100vh", true, false);

		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

            
            return isErrorOccurred;
        }


		LeadDetailComponent_807819_onClick = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations, this.checkTabErrors))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
KuikaAppManager.showSpinner(this);

					KuikaAppManager.prepareForNavigation();
						KuikaAppManager.addToPageInputVariables("CustomerUpdatePost", "CustomerId", ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, (stateVars.TM_GetLeadById !== undefined ? (stateVars.TM_GetLeadById?.length > 0 ? stateVars.TM_GetLeadById[0].customerId : null) : (this.state.TM_GetLeadById?.length > 0 ? this.state.TM_GetLeadById[0].customerId : null))), "Guid"));

				stateVars.NAVIGATE = await ReactSystemFunctions.navigate(this, undefined, "LeadDetail", "CustomerUpdatePost", "", "7d969ddf-5801-4eb6-b92b-12be35bdd565", "785947", null, "right", "true", "60%", "100vh", true, false);

		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

            
            return isErrorOccurred;
        }


		LeadDetailComponent_879058_onClick = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations, this.checkTabErrors))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
KuikaAppManager.showSpinner(this);

					KuikaAppManager.prepareForNavigation();
						KuikaAppManager.addToPageInputVariables("LeadAlternativeModelAdd", "LeadCode", ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadById !== undefined ? (stateVars.TM_GetLeadById?.length > 0 ? stateVars.TM_GetLeadById[0].leadCode : null) : (this.state.TM_GetLeadById?.length > 0 ? this.state.TM_GetLeadById[0].leadCode : null))), "string"));
						KuikaAppManager.addToPageInputVariables("LeadAlternativeModelAdd", "LeadId", ReactSystemFunctions.convertToTypeByName(this.props.screenInputs.LeadId ?? this.props.screenInputs.leadid, "Guid"));

				stateVars.NAVIGATE = await ReactSystemFunctions.navigate(this, undefined, "LeadDetail", "LeadAlternativeModelAdd", "", "7d969ddf-5801-4eb6-b92b-12be35bdd565", "200813", null, "right", "true", "60%", "100vh", true, false);

		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

            
            return isErrorOccurred;
        }


		LeadDetailComponent_343465_onClick = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations, this.checkTabErrors))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
KuikaAppManager.showSpinner(this);

					KuikaAppManager.prepareForNavigation();
						KuikaAppManager.addToPageInputVariables("LeadFileDetail", "LeadCode", ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadById !== undefined ? (stateVars.TM_GetLeadById?.length > 0 ? stateVars.TM_GetLeadById[0].leadCode : null) : (this.state.TM_GetLeadById?.length > 0 ? this.state.TM_GetLeadById[0].leadCode : null))), "string"));
						KuikaAppManager.addToPageInputVariables("LeadFileDetail", "LeadId", ReactSystemFunctions.convertToTypeByName(this.props.screenInputs.LeadId ?? this.props.screenInputs.leadid, "Guid"));

				stateVars.NAVIGATE = await ReactSystemFunctions.navigate(this, undefined, "LeadDetail", "LeadFileDetail", "", "7d969ddf-5801-4eb6-b92b-12be35bdd565", "880666", null, "right", "true", "60%", "100vh", true, false);

		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

            
            return isErrorOccurred;
        }


		LeadDetailComponent_78330_onClick = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations, this.checkTabErrors))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
KuikaAppManager.showSpinner(this);

					KuikaAppManager.prepareForNavigation();
						KuikaAppManager.addToPageInputVariables("LeadDetailAddNote", "LeadId", ReactSystemFunctions.convertToTypeByName(this.props.screenInputs.LeadId ?? this.props.screenInputs.leadid, "Guid"));
						KuikaAppManager.addToPageInputVariables("LeadDetailAddNote", "LeadCode", ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadById !== undefined ? (stateVars.TM_GetLeadById?.length > 0 ? stateVars.TM_GetLeadById[0].leadCode : null) : (this.state.TM_GetLeadById?.length > 0 ? this.state.TM_GetLeadById[0].leadCode : null))), "string"));

				stateVars.NAVIGATE = await ReactSystemFunctions.navigate(this, undefined, "LeadDetail", "LeadDetailAddNote", "", "7d969ddf-5801-4eb6-b92b-12be35bdd565", "78724", null, "right", "true", "60%", "100vh", true, false);

		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

            
            return isErrorOccurred;
        }


    LeadDetailComponent_41121_onClick = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations, this.checkTabErrors))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
		KuikaAppManager.increaseServerRequestCount();

        let localVar = {
				UserId_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.getMyUserId(), "Guid"),
				NoteId_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, "leaddetail_219536_value", "noteId"), "Guid")
        }

		KuikaAppManager.showSpinner(this);

            stateVars.Confirm = await ReactSystemFunctions.confirmation(
                ReactSystemFunctions.translateCustomActions(this.ml,"7c5566b1_979c_3d1b_432d_52627cf28c9c_confirmation",this.defaultML,"Notu silmek istediğinizden emin misiniz ?" ),
                "poppins",
                "Uyarı",
                "confirmation",
                "#246dff",
                "",
                ""
            );

            if (stateVars.Confirm)
            {
                		
        if (true) {
        KuikaAppManager.showSpinner(this);
        }
        let result = await KuikaAppManager.ApiRequest(this, "LeadDetail/LeadDetailComponent_41121_onClick", localVar)
        if (!KMainFunctions.IsResStatus2XX(result)) return true;

			stateVars.TM_LeadNoteDelete = result?.data.tM_LeadNoteDelete;
			this.props.form?.setFieldsValue(formVars);
			
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.LeadDetailComponent_41121_onClick1_();
                  resolve();
                });
          })

            }
            else
            {
                KuikaAppManager.hideSpinner(this);
            }


        
        KuikaAppManager.hideSpinner(this);
        return isErrorOccurred;
    }
		LeadDetailComponent_41121_onClick1_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations, this.checkTabErrors))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }

				stateVars.Notify = await ReactSystemFunctions.notify(this, ReactSystemFunctions.toString(this, (stateVars.TM_LeadNoteDelete !== undefined ? (stateVars.TM_LeadNoteDelete?.length > 0 ? stateVars.TM_LeadNoteDelete[0].message : null) : (this.state.TM_LeadNoteDelete?.length > 0 ? this.state.TM_LeadNoteDelete[0].message : null))), ReactSystemFunctions.convertToTypeByName("default", "string"), ReactSystemFunctions.convertToTypeByName("top-center", "string"), 3, ReactSystemFunctions.convertToTypeByName("", "string"), ReactSystemFunctions.convertToTypeByName("", "string"), 0);

		this.props.form?.setFieldsValue(formVars);
		
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.LeadDetailComponent_41121_onClick2_();
                  resolve();
                });
          })

            
            return isErrorOccurred;
        }
		LeadDetailComponent_41121_onClick2_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations, this.checkTabErrors))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
if (ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, (stateVars.TM_LeadNoteDelete !== undefined ? (stateVars.TM_LeadNoteDelete?.length > 0 ? stateVars.TM_LeadNoteDelete[0].success : null) : (this.state.TM_LeadNoteDelete?.length > 0 ? this.state.TM_LeadNoteDelete[0].success : null))), "1")) {
            
				await this.LeadDetailPageInit();
				

		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

        } else {
            KuikaAppManager.hideSpinner(this);
        }

            
            return isErrorOccurred;
        }





		LeadDetailComponent_606525_onClick = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations, this.checkTabErrors))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
KuikaAppManager.showSpinner(this);

				stateVars.DownloadFile = await ReactSystemFunctions.downloadFile(ReactSystemFunctions.value(this, "leaddetail_810974_value", "fileData"), ReactSystemFunctions.value(this, "leaddetail_810974_value", "fileName"));

		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

            
            return isErrorOccurred;
        }


		LeadDetailComponent_423129_onClick = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations, this.checkTabErrors))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
KuikaAppManager.showSpinner(this);

				stateVars.ChangeVisibilityOf = await ReactSystemFunctions.changeVisibilityOf(this, ReactSystemFunctions.convertToTypeByName("isComp725875Visible", "string"), ReactSystemFunctions.convertToTypeByName("hidden", "string"));
				stateVars.ChangeVisibilityOf = await ReactSystemFunctions.changeVisibilityOf(this, ReactSystemFunctions.convertToTypeByName("isComp423129Visible", "string"), ReactSystemFunctions.convertToTypeByName("hidden", "string"));
				stateVars.ChangeVisibilityOf = await ReactSystemFunctions.changeVisibilityOf(this, ReactSystemFunctions.convertToTypeByName("isComp158835Visible", "string"), ReactSystemFunctions.convertToTypeByName("visible", "string"));

		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

            
            return isErrorOccurred;
        }


		LeadDetailComponent_158835_onClick = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations, this.checkTabErrors))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
KuikaAppManager.showSpinner(this);

				stateVars.ChangeVisibilityOf = await ReactSystemFunctions.changeVisibilityOf(this, ReactSystemFunctions.convertToTypeByName("isComp725875Visible", "string"), ReactSystemFunctions.convertToTypeByName("visible", "string"));
				stateVars.ChangeVisibilityOf = await ReactSystemFunctions.changeVisibilityOf(this, ReactSystemFunctions.convertToTypeByName("isComp158835Visible", "string"), ReactSystemFunctions.convertToTypeByName("visible", "string"));
				stateVars.ChangeVisibilityOf = await ReactSystemFunctions.changeVisibilityOf(this, ReactSystemFunctions.convertToTypeByName("isComp423129Visible", "string"), ReactSystemFunctions.convertToTypeByName("hidden", "string"));

		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

            
            return isErrorOccurred;
        }


    LeadDetailComponent_148531_onChange = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations, this.checkTabErrors))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
		KuikaAppManager.increaseServerRequestCount();

        let localVar = {
				LeadId_0: ReactSystemFunctions.convertToTypeByName(this.props.screenInputs.LeadId ?? this.props.screenInputs.leadid, "Guid"),
				ColumnName_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "leaddetail_148531_value", "value", "TM_GetLeadLogStatu", "value", "value")), "string"),
				UserName_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "leaddetail_710951_value", "value", "", "", "")), "string"),
				StartDate_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "leaddetail_185424_value", "startValue", "", "", "")), "Date"),
				EndDate_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "leaddetail_185424_value", "endValue", "", "", "")), "Date")
        }

		KuikaAppManager.showSpinner(this);
		
        if (true) {
        KuikaAppManager.showSpinner(this);
        }
        let result = await KuikaAppManager.ApiRequest(this, "LeadDetail/LeadDetailComponent_148531_onChange", localVar)
        if (!KMainFunctions.IsResStatus2XX(result)) return true;

			stateVars.TM_GetLeadLogById = result?.data.tM_GetLeadLogById;
			
			this.props.form?.setFieldsValue(formVars);
			
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.LeadDetailComponent_148531_onChange1_();
                  resolve();
                });
          })



        
        KuikaAppManager.hideSpinner(this);
        return isErrorOccurred;
    }
		LeadDetailComponent_148531_onChange1_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations, this.checkTabErrors))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }

				
				stateVars.dataSource_764439 = stateVars.TM_GetLeadLogById ?? this.state.TM_GetLeadLogById;

		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

            
            return isErrorOccurred;
        }




    LeadDetailComponent_710951_onChange = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations, this.checkTabErrors))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
		KuikaAppManager.increaseServerRequestCount();

        let localVar = {
				LeadId_0: ReactSystemFunctions.convertToTypeByName(this.props.screenInputs.LeadId ?? this.props.screenInputs.leadid, "Guid"),
				ColumnName_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "leaddetail_148531_value", "value", "TM_GetLeadLogStatu", "value", "value")), "string"),
				UserName_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "leaddetail_710951_value", "value", "", "", "")), "string"),
				StartDate_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "leaddetail_185424_value", "startValue", "", "", "")), "Date"),
				EndDate_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "leaddetail_185424_value", "endValue", "", "", "")), "Date")
        }

		KuikaAppManager.showSpinner(this);
		
        if (true) {
        KuikaAppManager.showSpinner(this);
        }
        let result = await KuikaAppManager.ApiRequest(this, "LeadDetail/LeadDetailComponent_710951_onChange", localVar)
        if (!KMainFunctions.IsResStatus2XX(result)) return true;

			stateVars.TM_GetLeadLogById = result?.data.tM_GetLeadLogById;
			
			this.props.form?.setFieldsValue(formVars);
			
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.LeadDetailComponent_710951_onChange1_();
                  resolve();
                });
          })



        
        KuikaAppManager.hideSpinner(this);
        return isErrorOccurred;
    }
		LeadDetailComponent_710951_onChange1_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations, this.checkTabErrors))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }

				
				stateVars.dataSource_764439 = stateVars.TM_GetLeadLogById ?? this.state.TM_GetLeadLogById;

		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

            
            return isErrorOccurred;
        }




    LeadDetailComponent_185424_onChange = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations, this.checkTabErrors))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
		KuikaAppManager.increaseServerRequestCount();

        let localVar = {
				LeadId_0: ReactSystemFunctions.convertToTypeByName(this.props.screenInputs.LeadId ?? this.props.screenInputs.leadid, "Guid"),
				ColumnName_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "leaddetail_148531_value", "value", "TM_GetLeadLogStatu", "value", "value")), "string"),
				UserName_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "leaddetail_710951_value", "value", "", "", "")), "string"),
				StartDate_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "leaddetail_185424_value", "startValue", "", "", "")), "Date"),
				EndDate_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "leaddetail_185424_value", "endValue", "", "", "")), "Date")
        }

		KuikaAppManager.showSpinner(this);
		
        if (true) {
        KuikaAppManager.showSpinner(this);
        }
        let result = await KuikaAppManager.ApiRequest(this, "LeadDetail/LeadDetailComponent_185424_onChange", localVar)
        if (!KMainFunctions.IsResStatus2XX(result)) return true;

			stateVars.TM_GetLeadLogById = result?.data.tM_GetLeadLogById;
			
			this.props.form?.setFieldsValue(formVars);
			
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.LeadDetailComponent_185424_onChange1_();
                  resolve();
                });
          })



        
        KuikaAppManager.hideSpinner(this);
        return isErrorOccurred;
    }
		LeadDetailComponent_185424_onChange1_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations, this.checkTabErrors))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }

				
				stateVars.dataSource_764439 = stateVars.TM_GetLeadLogById ?? this.state.TM_GetLeadLogById;

		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

            
            return isErrorOccurred;
        }




		LeadDetailComponent_54565_onChange = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations, this.checkTabErrors))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
KuikaAppManager.showSpinner(this);

				

		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

            
            return isErrorOccurred;
        }


		LeadDetailComponent_648114_onChange = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations, this.checkTabErrors))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
KuikaAppManager.showSpinner(this);

				

		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

            
            return isErrorOccurred;
        }




    async callCallbackFunction(diId: number, isFromMaster: boolean = false) {
        let isErrorOccurred = false;
		let pageInitCallerNavDiIDs = [, 999526, 293274, , , 897956, 81031, 191307, 423975, 899644, 785947, 200813, 880666, 78724] as number[];
		if (isFromMaster || pageInitCallerNavDiIDs.indexOf(diId) > -1) {
			await this.LeadDetailPageInit();
		}

    }


}
