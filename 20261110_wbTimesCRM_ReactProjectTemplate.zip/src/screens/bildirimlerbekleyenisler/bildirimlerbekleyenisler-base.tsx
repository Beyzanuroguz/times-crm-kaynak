import React from "react";
import Axios, { AxiosResponse } from "axios";
import { KuikaAppManager } from "../../shared/utilty/kuika-app-manager";
import { ReactSystemFunctions } from "../../shared/utilty/react-system-functions";
import { KNavigator } from "../../shared/hoc/with-history";
import { KContext } from "../../shared/hoc/with-context";
import { useLocation } from "react-router-dom";
import { FormInstance } from "antd/es/form";
import { Guid } from "guid-typescript";
import Swal from "sweetalert2";
import { KMainFunctions } from "../../shared/utilty/main-functions";
import moment from "moment";
import { IValidationData } from "../../models/dto/validation-data";
import { IStripePayment } from "../../models/dto/stripe-payment";
import { IUserInfoDto } from "../../models/dto/user-info.dto";
import { UserService } from "../../services/user-service";
import { kuikaCoreWasmBridgeService } from "../../services/_singletons";
import _ from "lodash";
import mqtt, { MqttClient } from "mqtt";
import { IMqttResult } from "../../models/dto/mqtt.dto";


declare let window: any;

export interface IBildirimlerBekleyenIsler_ScreenProps {
  navigator: KNavigator;
  form: FormInstance<any>;
  googleLogin: any;
  screenInputs: any;
  context: KContext;
  initialValues: any;
  children: any;
}

export interface IBildirimlerBekleyenIsler_ScreenState {
    isSpinnerVisible: boolean;
    isPageVisible: boolean;
	isLeftMenuVisible: boolean;
    spinnerCount: number;
    selectedLanguage: string;
    isPageInitLoaded: false;
    isPageRecurringLoaded: false;

}

export class BildirimlerBekleyenIsler_ScreenBase extends React.PureComponent<IBildirimlerBekleyenIsler_ScreenProps, any> {

	bildirimlerbekleyenisler_721450_value_kuikaAutoCompleteRef: React.RefObject<any>;
	bildirimlerbekleyenisler_583616_value_kuikaAutoCompleteRef: React.RefObject<any>;
	bildirimlerbekleyenisler_321365_value_kuikaTableRef: React.RefObject<any>;
	bildirimlerbekleyenisler_644440_value_kuikaGalleryViewRef: React.RefObject<any>;
	bildirimlerbekleyenisler_669778_value_kuikaTableRef: React.RefObject<any>;
	bildirimlerbekleyenisler_865540_value_kuikaPaginationRef: React.RefObject<any>;
	bildirimlerbekleyenisler_576761_value_kuikaGalleryViewRef: React.RefObject<any>;
    ml=[{"Id":"d5a61d2b-bd60-485f-86e2-661e9ed4e486","Name":"en_US","ShortName":"English","IsDefault":true,"LanguagePhrases":[]},{"Id":"50ee6f67-45b8-42c4-a7db-f40ad237544d","Name":"FixedValues","ShortName":"FixedValues","LanguagePhrases":[{"Id":348533,"PropertyName":"value","Value":"Bildirimler ve Bekleyen İşler"},{"Id":44590,"PropertyName":"value","Value":"Aksiyon bekleyen transfer işlerinizi ve süreç bildirimlerini takip edin."},{"Id":8587,"PropertyName":"label","Value":"Yenile"},{"Id":362662,"PropertyName":"tab","Value":"Bekleyen İşler 8"},{"Id":687327,"PropertyName":"placeholder","Value":"İş Türü"},{"Id":456400,"PropertyName":"placeholder","Value":"Talep veya Fiş No"},{"Id":721450,"PropertyName":"placeholder","Value":"Mağaza"},{"Id":927721,"PropertyName":"startDatePlaceholder","Value":"Başlangıç tarihi"},{"Id":927721,"PropertyName":"endDatePlaceholder","Value":"Bitiş tarihi"},{"Id":583616,"PropertyName":"placeholder","Value":"Bekleme Süresi"},{"Id":290987,"PropertyName":"label","Value":"Ara"},{"Id":895240,"PropertyName":"label","Value":"Temizle"},{"Id":453359,"PropertyName":"title","Value":"İş Tipi"},{"Id":289750,"PropertyName":"value","Value":"Onay Bekleyen Talep"},{"Id":603272,"PropertyName":"title","Value":"Talep/Fiş No"},{"Id":731206,"PropertyName":"value","Value":"TRF-2024-0081"},{"Id":622703,"PropertyName":"title","Value":"Gönderen"},{"Id":363245,"PropertyName":"value","Value":"Adana"},{"Id":153995,"PropertyName":"title","Value":"Alıcı"},{"Id":573842,"PropertyName":"value","Value":"Mersin"},{"Id":591353,"PropertyName":"title","Value":"Açıklama"},{"Id":818650,"PropertyName":"value","Value":"Merkez mağaza sevkiyat onayı"},{"Id":630762,"PropertyName":"title","Value":"Oluşturma Tarihi"},{"Id":446663,"PropertyName":"value","Value":"18.06.2024 09:40"},{"Id":738609,"PropertyName":"title","Value":"Bekleme Süresi"},{"Id":553943,"PropertyName":"title","Value":"İşlemler"},{"Id":668624,"PropertyName":"label","Value":"Onaya Git"},{"Id":220462,"PropertyName":"value","Value":"8 kayıttan 1–8 arası gösteriliyor"},{"Id":119856,"PropertyName":"tab","Value":"Bildirimler 24"},{"Id":521776,"PropertyName":"value","Value":"Yalnız Okunmamışlar"},{"Id":33347,"PropertyName":"label","Value":"Tümünü Okundu İşaretle"},{"Id":644440,"PropertyName":"nodatafoundmessage","Value":"No data found."},{"Id":963311,"PropertyName":"value","Value":"Transfer kabul süresi yaklaşıyor"},{"Id":37260,"PropertyName":"value","Value":"TRF-2024-0081 için kabul işlemi bekleniyor."},{"Id":75903,"PropertyName":"value","Value":"TRF-2024-0081"},{"Id":948094,"PropertyName":"value","Value":"18.06.2024"},{"Id":169827,"PropertyName":"label","Value":"Detaya Git"},{"Id":779108,"PropertyName":"label","Value":"Okundu İşaretle"},{"Id":397416,"PropertyName":"value","Value":"Bekleyen İşler"},{"Id":272283,"PropertyName":"title","Value":"İş Tipi"},{"Id":559729,"PropertyName":"value","Value":"Onay Bekleyen Talep"},{"Id":906258,"PropertyName":"title","Value":"Talep/Fiş No"},{"Id":529285,"PropertyName":"value","Value":"TRF-2024-0081"},{"Id":301431,"PropertyName":"title","Value":"Gönderen"},{"Id":252566,"PropertyName":"value","Value":"Adana"},{"Id":799740,"PropertyName":"title","Value":"Alıcı"},{"Id":509442,"PropertyName":"value","Value":"Mersin"},{"Id":387521,"PropertyName":"title","Value":"Açıklama"},{"Id":585882,"PropertyName":"value","Value":"Merkez mağaza sevkiyat onayı"},{"Id":272781,"PropertyName":"title","Value":"Oluşturma Tarihi"},{"Id":107679,"PropertyName":"value","Value":"18.06.2024 09:40"},{"Id":108012,"PropertyName":"title","Value":"Bekleme Süresi"},{"Id":671884,"PropertyName":"title","Value":"İşlemler"},{"Id":862588,"PropertyName":"label","Value":"Onaya Git"},{"Id":355169,"PropertyName":"value","Value":"8 kayıttan 1–8 arası gösteriliyor"},{"Id":619602,"PropertyName":"value","Value":"Bildirimler"},{"Id":576761,"PropertyName":"nodatafoundmessage","Value":"No data found."},{"Id":758085,"PropertyName":"value","Value":"Transfer kabul süresi yaklaşıyor"},{"Id":476223,"PropertyName":"value","Value":"TRF-2024-0081 için kabul işlemi bekleniyor."},{"Id":13672,"PropertyName":"value","Value":"18.06.2024"}]}]
    defaultML = "en_US"
    
    screenHash = ""
    


    constructor(props) {
        super(props);
		this.bildirimlerbekleyenisler_456400_value_kuikaTextInputRef = React.createRef();
		this.bildirimlerbekleyenisler_721450_value_kuikaAutoCompleteRef = React.createRef();
		this.bildirimlerbekleyenisler_583616_value_kuikaAutoCompleteRef = React.createRef();
		this.bildirimlerbekleyenisler_321365_value_kuikaTableRef = React.createRef();
		this.bildirimlerbekleyenisler_644440_value_kuikaGalleryViewRef = React.createRef();
		this.bildirimlerbekleyenisler_669778_value_kuikaTableRef = React.createRef();
		this.bildirimlerbekleyenisler_865540_value_kuikaPaginationRef = React.createRef();
		this.bildirimlerbekleyenisler_576761_value_kuikaGalleryViewRef = React.createRef();

        this.state = {
            isSpinnerVisible: false,
            isPageVisible: false,
            isLeftMenuVisible: false,
            spinnerCount: 0,
            selectedLanguage: "",
            isPageInitLoaded: false,
            isPageRecurringLoaded: false,
            	        dataSource_687327: [{"key":"approval","text":"Onay Bekleyen Talep"},{"key":"transfer","text":"Transfer Fişi Hazırlama"},{"key":"acceptance","text":"Kabul Bekleyen Fiş"},{"key":"issue","text":"Sorunlu Kabul İncelemesi"}],
	        dataSource_721450: [{"key":"adana","text":"Adana"},{"key":"mersin","text":"Mersin"},{"key":"antalya","text":"Antalya"},{"key":"gaziantep","text":"Gaziantep"},{"key":"merkez","text":"Merkez"}],
	        dataSource_583616: [{"key":"2","text":"2 gün"},{"key":"5","text":"5 gün"},{"key":"8","text":"8 gün"}],

        }

        this.state.isPageVisible = true;
        
    }

    async componentDidMount() {

        if (KuikaAppManager.isPageInitPrevented()) {
            KuikaAppManager.calculateAndSetBodyHeight("bildirimlerbekleyenisler", "");
            return;
        }
        
        
        ReactSystemFunctions.validateToken()
        this.fillFormInitValues();
        if (true){
            
        }
        
        
        
        KuikaAppManager.calculateAndSetBodyHeight("bildirimlerbekleyenisler", "");

        if (ReactSystemFunctions.getIsMicroApp() === false) {
           window.parentScreen = this;
        }
    }

    componentWillUnmount() {
        
        
        

        if (ReactSystemFunctions.getIsMicroApp() === false) {
           window.parentScreen = null;
        }
    }

    

        
    componentDidUpdate= async (prevProps, prevState) => {
		KuikaAppManager.calculateAndSetBodyHeight("bildirimlerbekleyenisler", ""    );
        if (prevProps?.location?.search !== (this.props as any)?.location?.search) {
			
		}

        

        if (ReactSystemFunctions.getIsMicroApp() === false) {
            for (const key in prevState) {
                if (key.startsWith('NavVisible') && prevState[key] === true && this.state[key] === false) {
                    window.parentScreen = this;
                    break;
                }
            }
        }
	}

    fillFormInitValues() {
        this.props.form?.setFieldsValue({
bildirimlerbekleyenisler_117355_value: false
});

    }

      setPageInitLoaded = (value: boolean) => {
        this.setState({ isPageInitLoaded: value });
      }

      setPageRecurringLoaded = (value: boolean) => {
        this.setState({ isPageRecurringLoaded: value });
      }

      clearFieldValidation = (changedValues: any) => {
        const fieldName = Object.keys(changedValues)[0];
        if (fieldName) {
          this.props.form?.setFields([
            {
              name: fieldName,
              errors: []
            }
          ]);
        }
      };

        checkTabErrors = () => {
    document.querySelectorAll(".rc-tabs-tab").forEach((tab) => {
      (tab as HTMLElement).style.color = "";
    });

    const tabPanes = document.querySelectorAll(".rc-tabs-tabpane");
    const tabs = document.querySelectorAll(".rc-tabs-tab");

    tabPanes.forEach((tabPane, index) => {
      const uniquePaneId = `rc-tabs-tabpane-${index}`;
      if (!tabPane.hasAttribute("id")) {
        tabPane.setAttribute("id", uniquePaneId); 
      }

      const uniqueTabId = `rc-tabs-tab-${index}`;
      if (tabs[index]) {
        if (!tabs[index].hasAttribute("id")) {
          tabs[index].setAttribute("id", uniqueTabId); 
        }
        tabs[index].setAttribute("aria-controls", uniquePaneId);
      }
    });

    const errorElements = document.querySelectorAll(".rc-tabs .ant-form-item-explain-error");

    const tabsWithErrors = new Set<string>();

    errorElements.forEach((errorElement) => {
      const tabPane = errorElement.closest(".rc-tabs-tabpane");
      if (tabPane && tabPane.id) {
        tabsWithErrors.add(tabPane.id);
      }
    });

    tabsWithErrors.forEach((tabPaneId) => {
      const tab = document.querySelector(`.rc-tabs-tab[aria-controls="${tabPaneId}"]`);
      if (tab) {
        (tab as HTMLElement).style.color = "red"; 
      }
    });
  };




    async callCallbackFunction(diId: number, isFromMaster: boolean = false) {
        let isErrorOccurred = false;

    }


}
