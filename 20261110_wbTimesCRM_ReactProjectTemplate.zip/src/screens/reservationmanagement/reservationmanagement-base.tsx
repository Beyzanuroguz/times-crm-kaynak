import React from "react";
import Axios, { AxiosResponse } from "axios";
import { KuikaAppManager } from "../../shared/utilty/kuika-app-manager";
import { ReactSystemFunctions } from "../../shared/utilty/react-system-functions";
import { KNavigator } from "../../shared/hoc/with-history";
import { KContext } from "../../shared/hoc/with-context";
import { useLocation } from "react-router-dom";
import { FormInstance } from "antd/es/form";
import { Guid } from "guid-typescript";
import Swal from "sweetalert2";
import { KMainFunctions } from "../../shared/utilty/main-functions";
import moment from "moment";
import { IValidationData } from "../../models/dto/validation-data";
import { IStripePayment } from "../../models/dto/stripe-payment";
import { IUserInfoDto } from "../../models/dto/user-info.dto";
import { UserService } from "../../services/user-service";
import { kuikaCoreWasmBridgeService } from "../../services/_singletons";
import _ from "lodash";
import mqtt, { MqttClient } from "mqtt";
import { IMqttResult } from "../../models/dto/mqtt.dto";
import { MasterScreen_ScreenContext } from "../masterscreen/masterscreen-context";

declare let window: any;

export interface IReservationManagement_ScreenProps {
  navigator: KNavigator;
  form: FormInstance<any>;
  googleLogin: any;
  screenInputs: any;
  context: KContext;
  initialValues: any;
  children: any;
}

export interface IReservationManagement_ScreenState {
    isSpinnerVisible: boolean;
    isPageVisible: boolean;
	isLeftMenuVisible: boolean;
    spinnerCount: number;
    selectedLanguage: string;
    isPageInitLoaded: false;
    isPageRecurringLoaded: false;
	TM_GetReservationApprovalList: any[];
	TM_GetReservationApprovalList_dummy: any[];
	TM_GetApprovedActiveReservations: any[];
	TM_GetApprovedActiveReservations_dummy: any[];
	TM_GetRejectedReservations: any[];
	TM_GetRejectedReservations_dummy: any[];
	TM_ReservationApproved: any[];
	TM_ReservationApproved_dummy: any[];
	Notify: boolean;
	Notify_dummy: boolean;
	TriggerEvent: string;
	TriggerEvent_dummy: string;
	NAVIGATE: any;
	NAVIGATE_dummy: any;

}

export class ReservationManagement_ScreenBase extends React.PureComponent<IReservationManagement_ScreenProps, any> {
    static contextType = MasterScreen_ScreenContext;
    declare context: React.ContextType<typeof MasterScreen_ScreenContext>;
	reservationmanagement_366308_value_kuikaTableRef: React.RefObject<any>;
	reservationmanagement_668817_value_kuikaTableRef: React.RefObject<any>;
	reservationmanagement_375954_value_kuikaTableRef: React.RefObject<any>;
    ml=[{"Id":"d5a61d2b-bd60-485f-86e2-661e9ed4e486","Name":"en_US","ShortName":"English","IsDefault":true,"LanguagePhrases":[]},{"Id":"7ce88f5c-4014-4c49-afb0-ba495a5c9acd","Name":"FixedValues","ShortName":"FixedValues","LanguagePhrases":[{"Id":247591,"PropertyName":"value","Value":"Rezerve Yönetimi"},{"Id":11808,"PropertyName":"value","Value":"Rezerve taleplerini inceleyin ve yönetin"},{"Id":527303,"PropertyName":"tab","Value":"Onay Bekleyen Rezerveler"},{"Id":149709,"PropertyName":"title","Value":"Talep Numarası"},{"Id":426073,"PropertyName":"value","Value":"[datafield:leadcode]"},{"Id":20816,"PropertyName":"title","Value":"Mağaza"},{"Id":99528,"PropertyName":"value","Value":"[datafield:magaza]"},{"Id":925631,"PropertyName":"title","Value":"Ürün"},{"Id":624786,"PropertyName":"value","Value":"[datafield:urunadi]"},{"Id":656886,"PropertyName":"title","Value":"Müşteri Ad-Soyad"},{"Id":117686,"PropertyName":"value","Value":"[datafield:musteriadi]"},{"Id":764401,"PropertyName":"title","Value":"Mail"},{"Id":690209,"PropertyName":"value","Value":"[datafield:mail]"},{"Id":362717,"PropertyName":"title","Value":"Telefon No"},{"Id":17333,"PropertyName":"value","Value":"[datafield:telefon]"},{"Id":309583,"PropertyName":"title","Value":"Rezerve Oluşturan Kişi"},{"Id":631617,"PropertyName":"value","Value":"[datafield:rezerveedenkisi]"},{"Id":319875,"PropertyName":"title","Value":"Rezerve Notu"},{"Id":155493,"PropertyName":"value","Value":"[datafield:rezervnotu]"},{"Id":493729,"PropertyName":"title","Value":"Rezerve Tarihi"},{"Id":722129,"PropertyName":"value","Value":"[datafield:rezervtarihi]"},{"Id":637077,"PropertyName":"label","Value":"Onayla"},{"Id":348030,"PropertyName":"label","Value":"Reddet"},{"Id":274979,"PropertyName":"tab","Value":"Onaylanan Aktif Rezerveler"},{"Id":207375,"PropertyName":"title","Value":"Talep Numarası"},{"Id":679905,"PropertyName":"value","Value":"[datafield:leadcode]"},{"Id":511819,"PropertyName":"title","Value":"Mağaza"},{"Id":966808,"PropertyName":"value","Value":"[datafield:storedesc]"},{"Id":283821,"PropertyName":"title","Value":"Ürün"},{"Id":214321,"PropertyName":"value","Value":"[datafield:productname]"},{"Id":176220,"PropertyName":"title","Value":"Müşteri Ad-Soyad"},{"Id":304004,"PropertyName":"value","Value":"[datafield:musteriadi]"},{"Id":248041,"PropertyName":"title","Value":"Mail"},{"Id":814498,"PropertyName":"value","Value":"[datafield:email]"},{"Id":294776,"PropertyName":"title","Value":"Telefon No"},{"Id":573943,"PropertyName":"value","Value":"[datafield:tel]"},{"Id":466688,"PropertyName":"title","Value":"Rezerve Oluşturan Kişi"},{"Id":586884,"PropertyName":"value","Value":"[datafield:rezerveedenkisi]"},{"Id":412686,"PropertyName":"title","Value":"Rezerve Notu"},{"Id":424312,"PropertyName":"value","Value":"[datafield:rezervnotu]"},{"Id":763494,"PropertyName":"title","Value":"Rezerve Tarihi"},{"Id":925707,"PropertyName":"value","Value":"[datafield:rezervtarihi]"},{"Id":930061,"PropertyName":"tab","Value":"Reddedilen Rezerveler"},{"Id":140120,"PropertyName":"title","Value":"Talep Numarası"},{"Id":790492,"PropertyName":"value","Value":"[datafield:leadcode]"},{"Id":244237,"PropertyName":"title","Value":"Mağaza"},{"Id":494850,"PropertyName":"value","Value":"[datafield:storedesc]"},{"Id":271990,"PropertyName":"title","Value":"Ürün"},{"Id":603960,"PropertyName":"value","Value":"[datafield:productname]"},{"Id":760155,"PropertyName":"title","Value":"Müşteri Ad-Soyad"},{"Id":105754,"PropertyName":"value","Value":"[datafield:musteriadi]"},{"Id":439720,"PropertyName":"title","Value":"Mail"},{"Id":394486,"PropertyName":"value","Value":"[datafield:email]"},{"Id":322980,"PropertyName":"title","Value":"Telefon No"},{"Id":631812,"PropertyName":"value","Value":"[datafield:tel]"},{"Id":613005,"PropertyName":"title","Value":"Rezerve Oluşturan Kişi"},{"Id":248072,"PropertyName":"value","Value":"[datafield:rezerveedenkisi]"},{"Id":614746,"PropertyName":"title","Value":"Rezerve Notu"},{"Id":979375,"PropertyName":"value","Value":"[datafield:rezervnotu]"},{"Id":192064,"PropertyName":"title","Value":"Rezerve Tarihi"},{"Id":283021,"PropertyName":"value","Value":"[datafield:rezervtarihi]"}]}]
    defaultML = "en_US"
    
    screenHash = ""
    

    private _prevMasterPageInitLoaded: boolean = false;
    private _prevMasterPageRecurringLoaded: boolean = false;
    private _prevShouldTriggerPageInit: boolean = false;
    constructor(props) {
        super(props);
		this.reservationmanagement_366308_value_kuikaTableRef = React.createRef();
		this.reservationmanagement_668817_value_kuikaTableRef = React.createRef();
		this.reservationmanagement_375954_value_kuikaTableRef = React.createRef();

        this.state = {
            isSpinnerVisible: false,
            isPageVisible: false,
            isLeftMenuVisible: false,
            spinnerCount: 0,
            selectedLanguage: "",
            isPageInitLoaded: false,
            isPageRecurringLoaded: false,
            	        TM_GetReservationApprovalList: [],
	        TM_GetApprovedActiveReservations: [],
	        TM_GetRejectedReservations: [],
	        TM_ReservationApproved: [],
	        Notify: false,
	        TriggerEvent: "",
	        NAVIGATE: "",

        }

        this.state.isPageVisible = true;
        
    }

    async componentDidMount() {

        if (KuikaAppManager.isPageInitPrevented()) {
            KuikaAppManager.calculateAndSetBodyHeight("reservationmanagement", "masterscreen_screen");
            return;
        }
        this.context.registerCallbackFunction(this.callCallbackFunction.bind(this));
        
        ReactSystemFunctions.validateToken()
        this.fillFormInitValues();
        if (false){
            await this.ReservationManagementPageInit();
        } else if (this.context?.isMasterPageInitLoaded) { this._prevMasterPageInitLoaded = true; await this.ReservationManagementPageInit(); }
        
        
        
        KuikaAppManager.calculateAndSetBodyHeight("reservationmanagement", "masterscreen_screen");

        if (ReactSystemFunctions.getIsMicroApp() === false) {
           window.parentScreen = this;
        }
    }

    componentWillUnmount() {
        
        
        

        if (ReactSystemFunctions.getIsMicroApp() === false) {
           window.parentScreen = null;
        }
    }

    

        
    componentDidUpdate= async (prevProps, prevState) => {
		KuikaAppManager.calculateAndSetBodyHeight("reservationmanagement", "masterscreen_screen"    );
        if (prevProps?.location?.search !== (this.props as any)?.location?.search) {
			await this.ReservationManagementPageInit();
		}

        		if (this._prevMasterPageInitLoaded !== this.context.isMasterPageInitLoaded && this.context.isMasterPageInitLoaded === true) {this._prevMasterPageInitLoaded = this.context.isMasterPageInitLoaded;await this.ReservationManagementPageInit()}


        if (ReactSystemFunctions.getIsMicroApp() === false) {
            for (const key in prevState) {
                if (key.startsWith('NavVisible') && prevState[key] === true && this.state[key] === false) {
                    window.parentScreen = this;
                    break;
                }
            }
        }
	}

    fillFormInitValues() {
        this.props.form?.setFieldsValue({
});

    }

      setPageInitLoaded = (value: boolean) => {
        this.setState({ isPageInitLoaded: value });
      }

      setPageRecurringLoaded = (value: boolean) => {
        this.setState({ isPageRecurringLoaded: value });
      }

      clearFieldValidation = (changedValues: any) => {
        const fieldName = Object.keys(changedValues)[0];
        if (fieldName) {
          this.props.form?.setFields([
            {
              name: fieldName,
              errors: []
            }
          ]);
        }
      };

        checkTabErrors = () => {
    document.querySelectorAll(".rc-tabs-tab").forEach((tab) => {
      (tab as HTMLElement).style.color = "";
    });

    const tabPanes = document.querySelectorAll(".rc-tabs-tabpane");
    const tabs = document.querySelectorAll(".rc-tabs-tab");

    tabPanes.forEach((tabPane, index) => {
      const uniquePaneId = `rc-tabs-tabpane-${index}`;
      if (!tabPane.hasAttribute("id")) {
        tabPane.setAttribute("id", uniquePaneId); 
      }

      const uniqueTabId = `rc-tabs-tab-${index}`;
      if (tabs[index]) {
        if (!tabs[index].hasAttribute("id")) {
          tabs[index].setAttribute("id", uniqueTabId); 
        }
        tabs[index].setAttribute("aria-controls", uniquePaneId);
      }
    });

    const errorElements = document.querySelectorAll(".rc-tabs .ant-form-item-explain-error");

    const tabsWithErrors = new Set<string>();

    errorElements.forEach((errorElement) => {
      const tabPane = errorElement.closest(".rc-tabs-tabpane");
      if (tabPane && tabPane.id) {
        tabsWithErrors.add(tabPane.id);
      }
    });

    tabsWithErrors.forEach((tabPaneId) => {
      const tab = document.querySelector(`.rc-tabs-tab[aria-controls="${tabPaneId}"]`);
      if (tab) {
        (tab as HTMLElement).style.color = "red"; 
      }
    });
  };

    ReservationManagementPageInit = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


	if (KuikaAppManager.handleValidations(this, validations, this.checkTabErrors))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }

        let localVar = {
			UserId_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.getMyUserId(), "Guid"),
			UserId_1: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.getMyUserId(), "Guid"),
			UserId_2: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.getMyUserId(), "Guid")
        }

	KuikaAppManager.showSpinner(this);
	
        if (true) {
        KuikaAppManager.showSpinner(this);
        }
        let result = await KuikaAppManager.ApiRequest(this, "ReservationManagement/ReservationManagementPageInit", localVar)
        if (!KMainFunctions.IsResStatus2XX(result)) return true;

		stateVars.TM_GetReservationApprovalList = result?.data.tM_GetReservationApprovalList;
		
		stateVars.TM_GetApprovedActiveReservations = result?.data.tM_GetApprovedActiveReservations;
		
		stateVars.TM_GetRejectedReservations = result?.data.tM_GetRejectedReservations;
		
		this.props.form?.setFieldsValue(formVars);
		
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.ReservationManagementPageInit1_();
                  resolve();
                });
          })



        
        KuikaAppManager.hideSpinner(this);
        return isErrorOccurred;
    }
	ReservationManagementPageInit1_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


	if (KuikaAppManager.handleValidations(this, validations, this.checkTabErrors))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }

			
			stateVars.dataSource_366308 = stateVars.TM_GetReservationApprovalList ?? this.state.TM_GetReservationApprovalList;
			
			stateVars.dataSource_668817 = stateVars.TM_GetApprovedActiveReservations ?? this.state.TM_GetApprovedActiveReservations;
			
			stateVars.dataSource_375954 = stateVars.TM_GetRejectedReservations ?? this.state.TM_GetRejectedReservations;

	this.props.form?.setFieldsValue(formVars);
	this.setState(stateVars);
	KuikaAppManager.hideSpinner(this);

            this.setPageInitLoaded(true);
            return isErrorOccurred;
        }




    ReservationManagementComponent_637077_onClick = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations, this.checkTabErrors))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
		KuikaAppManager.increaseServerRequestCount();

        let localVar = {
				ReservationId_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, "reservationmanagement_366308_value", "reservationId"), "Guid"),
				UserId_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.getMyUserId(), "Guid")
        }

		KuikaAppManager.showSpinner(this);
		
        if (true) {
        KuikaAppManager.showSpinner(this);
        }
        let result = await KuikaAppManager.ApiRequest(this, "ReservationManagement/ReservationManagementComponent_637077_onClick", localVar)
        if (!KMainFunctions.IsResStatus2XX(result)) return true;

			stateVars.TM_ReservationApproved = result?.data.tM_ReservationApproved;
			this.props.form?.setFieldsValue(formVars);
			
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.ReservationManagementComponent_637077_onClick1_();
                  resolve();
                });
          })



        
        KuikaAppManager.hideSpinner(this);
        return isErrorOccurred;
    }
		ReservationManagementComponent_637077_onClick1_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations, this.checkTabErrors))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }

				stateVars.Notify = await ReactSystemFunctions.notify(this, ReactSystemFunctions.toString(this, (stateVars.TM_ReservationApproved !== undefined ? (stateVars.TM_ReservationApproved?.length > 0 ? stateVars.TM_ReservationApproved[0].message : null) : (this.state.TM_ReservationApproved?.length > 0 ? this.state.TM_ReservationApproved[0].message : null))), ReactSystemFunctions.convertToTypeByName("default", "string"), ReactSystemFunctions.convertToTypeByName("top-center", "string"), 3, ReactSystemFunctions.convertToTypeByName("", "string"), ReactSystemFunctions.convertToTypeByName("", "string"), 0);

		this.props.form?.setFieldsValue(formVars);
		
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.ReservationManagementComponent_637077_onClick2_();
                  resolve();
                });
          })

            
            return isErrorOccurred;
        }
		ReservationManagementComponent_637077_onClick2_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations, this.checkTabErrors))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
if (ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, (stateVars.TM_ReservationApproved !== undefined ? (stateVars.TM_ReservationApproved?.length > 0 ? stateVars.TM_ReservationApproved[0].success : null) : (this.state.TM_ReservationApproved?.length > 0 ? this.state.TM_ReservationApproved[0].success : null))), "1")) {
            
				await this.ReservationManagementPageInit();
				

		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

        } else {
            KuikaAppManager.hideSpinner(this);
        }

            
            return isErrorOccurred;
        }





		ReservationManagementComponent_348030_onClick = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations, this.checkTabErrors))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
KuikaAppManager.showSpinner(this);

					KuikaAppManager.prepareForNavigation();
						KuikaAppManager.addToPageInputVariables("ReservationReject", "ReservationId", ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.getMyUserId(), "Guid"));

				stateVars.NAVIGATE = await ReactSystemFunctions.navigate(this, undefined, "ReservationManagement", "ReservationReject", "", "9924ef5f-4b84-4200-b624-8d76348c7686", "528108", null, null, "true", "800px", "70vh", true, false);

		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

            
            return isErrorOccurred;
        }




    async callCallbackFunction(diId: number, isFromMaster: boolean = false) {
        let isErrorOccurred = false;
		let pageInitCallerNavDiIDs = [528108] as number[];
		if (isFromMaster || pageInitCallerNavDiIDs.indexOf(diId) > -1) {
			await this.ReservationManagementPageInit();
		}

    }


}
