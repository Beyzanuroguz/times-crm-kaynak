import React from "react";
import Axios, { AxiosResponse } from "axios";
import { KuikaAppManager } from "../../shared/utilty/kuika-app-manager";
import { ReactSystemFunctions } from "../../shared/utilty/react-system-functions";
import { KNavigator } from "../../shared/hoc/with-history";
import { KContext } from "../../shared/hoc/with-context";
import { useLocation } from "react-router-dom";
import { FormInstance } from "antd/es/form";
import { Guid } from "guid-typescript";
import Swal from "sweetalert2";
import { KMainFunctions } from "../../shared/utilty/main-functions";
import moment from "moment";
import { IValidationData } from "../../models/dto/validation-data";
import { IStripePayment } from "../../models/dto/stripe-payment";
import { IUserInfoDto } from "../../models/dto/user-info.dto";
import { UserService } from "../../services/user-service";
import { kuikaCoreWasmBridgeService } from "../../services/_singletons";
import _ from "lodash";
import mqtt, { MqttClient } from "mqtt";
import { IMqttResult } from "../../models/dto/mqtt.dto";
import { MasterScreen_ScreenContext } from "../masterscreen/masterscreen-context";

declare let window: any;

export interface IFreeSalesWeb_ScreenProps {
  navigator: KNavigator;
  form: FormInstance<any>;
  googleLogin: any;
  screenInputs: any;
  context: KContext;
  initialValues: any;
  children: any;
}

export interface IFreeSalesWeb_ScreenState {
    isSpinnerVisible: boolean;
    isPageVisible: boolean;
	isLeftMenuVisible: boolean;
    spinnerCount: number;
    selectedLanguage: string;
    isPageInitLoaded: false;
    isPageRecurringLoaded: false;
	TM_StoreGetList: any[];
	TM_StoreGetList_dummy: any[];
	TM_GetCustomerByName: any[];
	TM_GetCustomerByName_dummy: any[];
	TS_GetStoreUsers: any[];
	TS_GetStoreUsers_dummy: any[];
	GetSalesPersonByStore: any[];
	GetSalesPersonByStore_dummy: any[];
	TM_GetCustomerById: any[];
	TM_GetCustomerById_dummy: any[];
	TMSalesDraftCreate: any[];
	TMSalesDraftCreate_dummy: any[];
	Notify: boolean;
	Notify_dummy: boolean;
	ChangeEnabledOf: any;
	ChangeEnabledOf_dummy: any;
	ChangeVisibilityOf: string;
	ChangeVisibilityOf_dummy: string;
	Kuika_ItemInfoLive: any[];
	Kuika_ItemInfoLive_dummy: any[];
	TMSalesDraftAddProduct: any[];
	TMSalesDraftAddProduct_dummy: any[];
	GetSalesProduct: any[];
	GetSalesProduct_dummy: any[];
	TMSalesPaymentList: any[];
	TMSalesPaymentList_dummy: any[];
	SetValueOf: any;
	SetValueOf_dummy: any;
	TMIskontoAddSales: any[];
	TMIskontoAddSales_dummy: any[];
	TMSalesProductDelete: any[];
	TMSalesProductDelete_dummy: any[];
	TMSalesPaymentType: any[];
	TMSalesPaymentType_dummy: any[];
	TMAddSalesPayment: any[];
	TMAddSalesPayment_dummy: any[];
	TMSalesPaymentCompletedLine: any[];
	TMSalesPaymentCompletedLine_dummy: any[];
	TMSalesPaymentDeleted: any[];
	TMSalesPaymentDeleted_dummy: any[];
	TM_GetDirectSalesDraftForPost: any[];
	TM_GetDirectSalesDraftForPost_dummy: any[];
	TM_GetDirectSalesDraftDetailForPost: any[];
	TM_GetDirectSalesDraftDetailForPost_dummy: any[];
	TM_GetDirectSalesDraftPaymentForPost: any[];
	TM_GetDirectSalesDraftPaymentForPost_dummy: any[];
	isComp417391Visible: 'visible' | 'hidden';
	isComp661091Visible: 'visible' | 'hidden';
	isComp134236Visible: 'visible' | 'hidden';
	isComp636437Visible: 'visible' | 'hidden';
	isComp61838Visible: 'visible' | 'hidden';
	isComp47770Visible: 'visible' | 'hidden';
	isComp884643Visible: 'visible' | 'hidden';
	isComp262981Visible: 'visible' | 'hidden';
	isComp492901Visible: 'visible' | 'hidden';
	isComp126493Visible: 'visible' | 'hidden';
	isComp110781Visible: 'visible' | 'hidden';
	isComp170951Visible: 'visible' | 'hidden';
	isComp701913Visible: 'visible' | 'hidden';
	isComp516757Visible: 'visible' | 'hidden';
	isComp73196Enabled: 'enabled' | 'disabled';

}

export class FreeSalesWeb_ScreenBase extends React.PureComponent<IFreeSalesWeb_ScreenProps, any> {
    static contextType = MasterScreen_ScreenContext;
    declare context: React.ContextType<typeof MasterScreen_ScreenContext>;
	freesalesweb_89837_value_kuikaAutoCompleteRef: React.RefObject<any>;
	freesalesweb_471458_value_kuikaAutoCompleteRef: React.RefObject<any>;
	freesalesweb_560284_value_kuikaAutoCompleteRef: React.RefObject<any>;
	freesalesweb_911320_value_kuikaAutoCompleteRef: React.RefObject<any>;
	freesalesweb_115957_value_kuikaDateRef: React.RefObject<any>;
	freesalesweb_667342_value_kuikaDateRef: React.RefObject<any>;
	freesalesweb_829773_value_kuikaTableRef: React.RefObject<any>;
	freesalesweb_661922_value_kuikaSelectBoxRef: React.RefObject<any>;
	freesalesweb_692281_value_kuikaSelectBoxRef: React.RefObject<any>;
	freesalesweb_546168_value_kuikaTableRef: React.RefObject<any>;
    ml=[{"Id":"d5a61d2b-bd60-485f-86e2-661e9ed4e486","Name":"en_US","ShortName":"English","IsDefault":true,"LanguagePhrases":[]},{"Id":"e0fa9875-919d-45da-a0bb-402cdff0a7b0","Name":"FixedValues","ShortName":"FixedValues","LanguagePhrases":[{"Id":917375,"PropertyName":"value","Value":"Satış"},{"Id":971308,"PropertyName":"value","Value":"Rolex ve Tudor dışındaki ürünleri kolayca satın"},{"Id":132540,"PropertyName":"value","Value":"Satış Bilgileri"},{"Id":138999,"PropertyName":"value","Value":"Satış Yapılan Mağaza"},{"Id":89837,"PropertyName":"placeholder","Value":"Satış Yapılan Mağazayı Seçiniz"},{"Id":870844,"PropertyName":"value","Value":"Satış Personeli"},{"Id":471458,"PropertyName":"placeholder","Value":"Satış Personeli Seçiniz"},{"Id":340033,"PropertyName":"value","Value":"Müşteri"},{"Id":560284,"PropertyName":"placeholder","Value":"Müşteri Seçiniz"},{"Id":651583,"PropertyName":"value","Value":"Müşteri Bilgileri"},{"Id":862092,"PropertyName":"value","Value":"Müşteri Adı"},{"Id":853753,"PropertyName":"value","Value":"TC"},{"Id":543950,"PropertyName":"value","Value":"Telefon No"},{"Id":65584,"PropertyName":"value","Value":"E-mail"},{"Id":41923,"PropertyName":"value","Value":"Lokasyon"},{"Id":474931,"PropertyName":"value","Value":"Alışveriş Var Mı?"},{"Id":884643,"PropertyName":"value","Value":"Var"},{"Id":262981,"PropertyName":"value","Value":"Yok"},{"Id":72259,"PropertyName":"value","Value":"E-Fatura Bilgisi"},{"Id":492901,"PropertyName":"value","Value":"Müşteri mükellef kayıtlı değildir."},{"Id":126493,"PropertyName":"value","Value":"Müşteri mükellef kayıtlıdır."},{"Id":304608,"PropertyName":"value","Value":"Fatura Tipi"},{"Id":911320,"PropertyName":"placeholder","Value":"Fatura Tipi Seçiniz"},{"Id":507540,"PropertyName":"value","Value":"Oturum İzni No:"},{"Id":691987,"PropertyName":"placeholder","Value":"Oturum İzni Numarası"},{"Id":355047,"PropertyName":"value","Value":"Oturum Baş. Tarihi"},{"Id":115957,"PropertyName":"placeholder","Value":"Başlangıç Tarihi"},{"Id":376821,"PropertyName":"value","Value":"Oturum Bit. Tarihi"},{"Id":667342,"PropertyName":"placeholder","Value":"Bitiş Tarihi"},{"Id":662297,"PropertyName":"label","Value":"Devam Et"},{"Id":208848,"PropertyName":"value","Value":"Ürün Bilgileri"},{"Id":771402,"PropertyName":"value","Value":"Ürün SeriNo-Barkod"},{"Id":514927,"PropertyName":"placeholder","Value":"Ürünün Seri veya Barkod Numarasını Giriniz"},{"Id":853840,"PropertyName":"label","Value":"Ürün Ekle"},{"Id":471531,"PropertyName":"title","Value":"Seri No - Barcode"},{"Id":187673,"PropertyName":"value","Value":"[datafield:serino]"},{"Id":388009,"PropertyName":"value","Value":"[datafield:barcode]"},{"Id":421709,"PropertyName":"title","Value":"Product Name"},{"Id":94519,"PropertyName":"value","Value":"[datafield:productname]"},{"Id":640147,"PropertyName":"title","Value":"Fiyat"},{"Id":469415,"PropertyName":"value","Value":"[datafield:unitpriceeur]"},{"Id":917192,"PropertyName":"title","Value":"İskonto Oranı"},{"Id":458281,"PropertyName":"value","Value":"[datafield:discountrate]"},{"Id":544273,"PropertyName":"placeholder","Value":"15"},{"Id":174221,"PropertyName":"title","Value":"İndirim Tutarı"},{"Id":34858,"PropertyName":"value","Value":"[datafield:discountamount]"},{"Id":596520,"PropertyName":"title","Value":"Toplam Tutar"},{"Id":658876,"PropertyName":"value","Value":"[datafield:linetotaleur]"},{"Id":729098,"PropertyName":"value","Value":"Toplam Ürün:"},{"Id":24262,"PropertyName":"value","Value":"Toplam Tutar:"},{"Id":143823,"PropertyName":"value","Value":"Tahsilat"},{"Id":661922,"PropertyName":"placeholder","Value":"Tahsilat Tipi"},{"Id":692281,"PropertyName":"placeholder","Value":"Döviz Tipi"},{"Id":408749,"PropertyName":"label","Value":"Tahsilat Ekle"},{"Id":41514,"PropertyName":"title","Value":"Tip"},{"Id":758780,"PropertyName":"value","Value":"[datafield:tipadi]"},{"Id":845134,"PropertyName":"title","Value":"Döviz"},{"Id":459977,"PropertyName":"value","Value":"[datafield:doviz]"},{"Id":176546,"PropertyName":"title","Value":"Tutar"},{"Id":744759,"PropertyName":"value","Value":"[datafield:tutar]"},{"Id":817208,"PropertyName":"placeholder","Value":"15"},{"Id":345057,"PropertyName":"title","Value":"EUR Karşılığı"},{"Id":789537,"PropertyName":"value","Value":"[datafield:eurkarsiligi]"},{"Id":980798,"PropertyName":"value","Value":"Tahsil Edilen:"},{"Id":865971,"PropertyName":"value","Value":"Kalan:"},{"Id":519542,"PropertyName":"label","Value":"Satışı Onayla"}]}]
    defaultML = "en_US"
    
    screenHash = ""
    

    private _prevMasterPageInitLoaded: boolean = false;
    private _prevMasterPageRecurringLoaded: boolean = false;
    private _prevShouldTriggerPageInit: boolean = false;
    constructor(props) {
        super(props);
		this.freesalesweb_89837_value_kuikaAutoCompleteRef = React.createRef();
		this.freesalesweb_471458_value_kuikaAutoCompleteRef = React.createRef();
		this.freesalesweb_560284_value_kuikaAutoCompleteRef = React.createRef();
		this.freesalesweb_911320_value_kuikaAutoCompleteRef = React.createRef();
		this.freesalesweb_691987_value_kuikaTextInputRef = React.createRef();
		this.freesalesweb_115957_value_kuikaDateRef = React.createRef();
		this.freesalesweb_667342_value_kuikaDateRef = React.createRef();
		this.freesalesweb_514927_value_kuikaTextInputRef = React.createRef();
		this.freesalesweb_829773_value_kuikaTableRef = React.createRef();
		this.freesalesweb_661922_value_kuikaSelectBoxRef = React.createRef();
		this.freesalesweb_692281_value_kuikaSelectBoxRef = React.createRef();
		this.freesalesweb_546168_value_kuikaTableRef = React.createRef();

        this.state = {
            isSpinnerVisible: false,
            isPageVisible: false,
            isLeftMenuVisible: false,
            spinnerCount: 0,
            selectedLanguage: "",
            isPageInitLoaded: false,
            isPageRecurringLoaded: false,
            	        TM_StoreGetList: [],
	        TM_GetCustomerByName: [],
	        TS_GetStoreUsers: [],
	        GetSalesPersonByStore: [],
	        TM_GetCustomerById: [],
	        TMSalesDraftCreate: [],
	        Notify: false,
	        ChangeEnabledOf: "",
	        ChangeVisibilityOf: "",
	        Kuika_ItemInfoLive: [],
	        TMSalesDraftAddProduct: [],
	        GetSalesProduct: [],
	        TMSalesPaymentList: [],
	        SetValueOf: "",
	        TMIskontoAddSales: [],
	        TMSalesProductDelete: [],
	        TMSalesPaymentType: [],
	        TMAddSalesPayment: [],
	        TMSalesPaymentCompletedLine: [],
	        TMSalesPaymentDeleted: [],
	        TM_GetDirectSalesDraftForPost: [],
	        TM_GetDirectSalesDraftDetailForPost: [],
	        TM_GetDirectSalesDraftPaymentForPost: [],
	        dataSource_911320: [{"key":"1","text":"Standart Fatura"},{"key":"2","text":"Tax Free Fatura"}],
	        dataSource_661922: [{"key":"1","text":"Nakit"},{"key":"2","text":"Kredi Kartı"},{"key":"4","text":"Banka"}],
	        isComp417391Visible: 'hidden',
	        isComp661091Visible: 'hidden',
	        isComp134236Visible: 'hidden',
	        isComp636437Visible: 'hidden',
	        isComp61838Visible: 'hidden',
	        isComp47770Visible: 'hidden',
	        isComp884643Visible: 'hidden',
	        isComp262981Visible: 'hidden',
	        isComp492901Visible: 'hidden',
	        isComp126493Visible: 'hidden',
	        isComp110781Visible: 'hidden',
	        isComp170951Visible: 'hidden',
	        isComp701913Visible: 'hidden',
	        isComp516757Visible: 'hidden',
	        isComp73196Enabled: 'enabled',

        }

        this.CheckPageAuthorization(this.state);

        
    }

    async componentDidMount() {

        if (KuikaAppManager.isPageInitPrevented()) {
            KuikaAppManager.calculateAndSetBodyHeight("freesalesweb", "masterscreen_screen");
            return;
        }
        this.context.registerCallbackFunction(this.callCallbackFunction.bind(this));
        
        ReactSystemFunctions.validateToken()
        this.fillFormInitValues();
        if (false){
            await this.FreeSalesWebPageInit();
        } else if (this.context?.isMasterPageInitLoaded) { this._prevMasterPageInitLoaded = true; await this.FreeSalesWebPageInit(); }
        
        
        
        KuikaAppManager.calculateAndSetBodyHeight("freesalesweb", "masterscreen_screen");

        if (ReactSystemFunctions.getIsMicroApp() === false) {
           window.parentScreen = this;
        }
    }

    componentWillUnmount() {
        
        
        

        if (ReactSystemFunctions.getIsMicroApp() === false) {
           window.parentScreen = null;
        }
    }

    
              CheckPageAuthorization = async (state) => {
                KuikaAppManager.showSpinner(this);
                if (_.isEmpty(window.userInfo)) {
                  await UserService.GetUserInfoForce();
                }
                const permittedRoleNames: string[] = ["TimesUstYonetici","TimesSatisPersoneli","TimesMagazaMuduru",];
                const userInfo = window.userInfo as IUserInfoDto;
                const userRoleNames = userInfo.roles.map((role) => role.name);
                if (!ReactSystemFunctions.hasAnyRoleName(permittedRoleNames, userRoleNames)) {
                  await ReactSystemFunctions.goBack(this);

                  const language = localStorage.getItem("ml");
                  let permissonErrorMessageText = "You do not have permission to access this page.";
                  if (language === "tr_TR") {
                    permissonErrorMessageText = "Bu sayfaya erişim yetkiniz yok.";
                  } else if (language === "fr_FR") {
                    permissonErrorMessageText = "Vous n'avez pas la permission d'accéder à cette page.";
                  } else if (language === "de_DE") {
                    permissonErrorMessageText = "Sie haben keine Berechtigung, auf diese Seite zuzugreifen.";
                  } else if (language === "es_ES") {
                    permissonErrorMessageText = "No tienes permiso para acceder a esta página.";
                  }

                  KMainFunctions.displayErrorNotification(permissonErrorMessageText);
                  state.isPageVisible = false;
                  KuikaAppManager.hideSpinner(this);
                  return;
                }
                state.isPageVisible = true;
                KuikaAppManager.hideSpinner(this);
              };
        

        
    componentDidUpdate= async (prevProps, prevState) => {
		KuikaAppManager.calculateAndSetBodyHeight("freesalesweb", "masterscreen_screen"    );
        if (prevProps?.location?.search !== (this.props as any)?.location?.search) {
			await this.FreeSalesWebPageInit();
		}

        		if (this._prevMasterPageInitLoaded !== this.context.isMasterPageInitLoaded && this.context.isMasterPageInitLoaded === true) {this._prevMasterPageInitLoaded = this.context.isMasterPageInitLoaded;await this.FreeSalesWebPageInit()}


        if (ReactSystemFunctions.getIsMicroApp() === false) {
            for (const key in prevState) {
                if (key.startsWith('NavVisible') && prevState[key] === true && this.state[key] === false) {
                    window.parentScreen = this;
                    break;
                }
            }
        }
	}

    fillFormInitValues() {
        this.props.form?.setFieldsValue({
freesalesweb_89837_value: this.state.TS_GetStoreUsers?.at?.(0)?.storeID ?? undefined,
freesalesweb_471458_value: this.state.GetSalesPersonByStore?.at?.(0)?.kuserID ?? undefined,
freesalesweb_115957_value: moment().format("YYYY-MM-DDTHH:mm:ss"),
freesalesweb_667342_value: moment().format("YYYY-MM-DDTHH:mm:ss")
});

    }

      setPageInitLoaded = (value: boolean) => {
        this.setState({ isPageInitLoaded: value });
      }

      setPageRecurringLoaded = (value: boolean) => {
        this.setState({ isPageRecurringLoaded: value });
      }

      clearFieldValidation = (changedValues: any) => {
        const fieldName = Object.keys(changedValues)[0];
        if (fieldName) {
          this.props.form?.setFields([
            {
              name: fieldName,
              errors: []
            }
          ]);
        }
      };

      

    FreeSalesWebPageInit = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


	if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }

        let localVar = {
			KUserId_2: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.getMyUserId(), "Guid"),
			StoreId_3: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, (stateVars.TS_GetStoreUsers !== undefined ? (stateVars.TS_GetStoreUsers?.length > 0 ? stateVars.TS_GetStoreUsers[0].storeID : null) : (this.state.TS_GetStoreUsers?.length > 0 ? this.state.TS_GetStoreUsers[0].storeID : null))), "Guid")
        }

	KuikaAppManager.showSpinner(this);
	
        if (true) {
        KuikaAppManager.showSpinner(this);
        }
        let result = await KuikaAppManager.ApiRequest(this, "FreeSalesWeb/FreeSalesWebPageInit", localVar)
        if (!KMainFunctions.IsResStatus2XX(result)) return true;

		stateVars.TM_StoreGetList = result?.data.tM_StoreGetList;
		
		formVars.freesalesweb_89837_value = (stateVars.TS_GetStoreUsers !== undefined ? (stateVars.TS_GetStoreUsers?.length > 0 ? stateVars.TS_GetStoreUsers[0].storeID : null) : (this.state.TS_GetStoreUsers?.length > 0 ? this.state.TS_GetStoreUsers[0].storeID : null));
		formVars.freesalesweb_89837_options = stateVars.TM_StoreGetList;
		stateVars.TM_GetCustomerByName = result?.data.tM_GetCustomerByName;
		
		formVars.freesalesweb_560284_options = stateVars.TM_GetCustomerByName;
		stateVars.TS_GetStoreUsers = result?.data.tS_GetStoreUsers;
		formVars.freesalesweb_89837_value = (stateVars.TS_GetStoreUsers !== undefined ? (stateVars.TS_GetStoreUsers?.length > 0 ? stateVars.TS_GetStoreUsers[0].storeID : null) : (this.state.TS_GetStoreUsers?.length > 0 ? this.state.TS_GetStoreUsers[0].storeID : null));
		formVars.freesalesweb_89837_options = stateVars.TM_StoreGetList;
		stateVars.GetSalesPersonByStore = result?.data.getSalesPersonByStore;
		
		formVars.freesalesweb_471458_value = (stateVars.GetSalesPersonByStore !== undefined ? (stateVars.GetSalesPersonByStore?.length > 0 ? stateVars.GetSalesPersonByStore[0].kuserID : null) : (this.state.GetSalesPersonByStore?.length > 0 ? this.state.GetSalesPersonByStore[0].kuserID : null));
		formVars.freesalesweb_471458_options = stateVars.GetSalesPersonByStore;
		this.props.form?.setFieldsValue(formVars);
		
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.FreeSalesWebPageInit1_();
                  resolve();
                });
          })



        
        KuikaAppManager.hideSpinner(this);
        return isErrorOccurred;
    }
	FreeSalesWebPageInit1_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


	if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }

			stateVars.isComp661091Visible = ((ReactSystemFunctions.contains(ReactSystemFunctions.getMyRoleNames(), ReactSystemFunctions.convertToTypeByName("TimesUstYonetici", "string"))) === true ? "visible" : "hidden")
			formVars.freesalesweb_89837_value = ReactSystemFunctions.toString(this, (stateVars.TS_GetStoreUsers !== undefined ? (stateVars.TS_GetStoreUsers?.length > 0 ? stateVars.TS_GetStoreUsers[0].storeID : null) : (this.state.TS_GetStoreUsers?.length > 0 ? this.state.TS_GetStoreUsers[0].storeID : null)));

			
			stateVars.dataSource_89837 = stateVars.TM_StoreGetList ?? this.state.TM_StoreGetList;
			stateVars.dataSource_89837 = stateVars.TM_StoreGetList ?? this.state.TM_StoreGetList;
			stateVars.isComp134236Visible = (((ReactSystemFunctions.contains(ReactSystemFunctions.getMyRoleNames(), ReactSystemFunctions.convertToTypeByName("TimesMagazaMuduru", "string")) || ReactSystemFunctions.contains(ReactSystemFunctions.getMyRoleNames(), ReactSystemFunctions.convertToTypeByName("TimesUstYonetici", "string")))) === true ? "visible" : "hidden")
			formVars.freesalesweb_471458_value = ReactSystemFunctions.toString(this, (stateVars.GetSalesPersonByStore !== undefined ? (stateVars.GetSalesPersonByStore?.length > 0 ? stateVars.GetSalesPersonByStore[0].kuserID : null) : (this.state.GetSalesPersonByStore?.length > 0 ? this.state.GetSalesPersonByStore[0].kuserID : null)));

			formVars.freesalesweb_471458_value = ReactSystemFunctions.toString(this, (stateVars.GetSalesPersonByStore !== undefined ? (stateVars.GetSalesPersonByStore?.length > 0 ? stateVars.GetSalesPersonByStore[0].kuserID : null) : (this.state.GetSalesPersonByStore?.length > 0 ? this.state.GetSalesPersonByStore[0].kuserID : null)));

			stateVars.dataSource_471458 = stateVars.GetSalesPersonByStore ?? this.state.GetSalesPersonByStore;
			stateVars.dataSource_471458 = stateVars.GetSalesPersonByStore ?? this.state.GetSalesPersonByStore;
			
			stateVars.dataSource_560284 = stateVars.TM_GetCustomerByName ?? this.state.TM_GetCustomerByName;
			stateVars.dataSource_560284 = stateVars.TM_GetCustomerByName ?? this.state.TM_GetCustomerByName;
			stateVars.isComp636437Visible = ((ReactSystemFunctions.isNotEmpty(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "freesalesweb_560284_value", "value", "TM_GetCustomerByName", "id", "id")), ReactSystemFunctions.convertToTypeByName("True", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp884643Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, (stateVars.TM_GetCustomerById !== undefined ? (stateVars.TM_GetCustomerById?.length > 0 ? stateVars.TM_GetCustomerById[0].isShopping : null) : (this.state.TM_GetCustomerById?.length > 0 ? this.state.TM_GetCustomerById[0].isShopping : null))), ReactSystemFunctions.convertToTypeByName("True", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp262981Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, (stateVars.TM_GetCustomerById !== undefined ? (stateVars.TM_GetCustomerById?.length > 0 ? stateVars.TM_GetCustomerById[0].isShopping : null) : (this.state.TM_GetCustomerById?.length > 0 ? this.state.TM_GetCustomerById[0].isShopping : null))), ReactSystemFunctions.convertToTypeByName("False", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp492901Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, (stateVars.TM_GetCustomerById !== undefined ? (stateVars.TM_GetCustomerById?.length > 0 ? stateVars.TM_GetCustomerById[0].isEInvoice : null) : (this.state.TM_GetCustomerById?.length > 0 ? this.state.TM_GetCustomerById[0].isEInvoice : null))), ReactSystemFunctions.convertToTypeByName("False", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp126493Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, (stateVars.TM_GetCustomerById !== undefined ? (stateVars.TM_GetCustomerById?.length > 0 ? stateVars.TM_GetCustomerById[0].isEInvoice : null) : (this.state.TM_GetCustomerById?.length > 0 ? this.state.TM_GetCustomerById[0].isEInvoice : null))), ReactSystemFunctions.convertToTypeByName("True", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp110781Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "freesalesweb_911320_value", "value", "", "key", "")), ReactSystemFunctions.convertToTypeByName("2", "string"))) === true ? "visible" : "hidden")
			ReactSystemFunctions.setValueOf(this, "freesalesweb_667342_value", ReactSystemFunctions.value(this, "freesalesweb_115957_value", "value"), "disablebeforedate");

			stateVars.isComp170951Visible = (((ReactSystemFunctions.isNotEmpty(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "freesalesweb_560284_value", "value", "TM_GetCustomerByName", "id", "id")), ReactSystemFunctions.convertToTypeByName("True", "string")) && ReactSystemFunctions.isNotEmpty(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "freesalesweb_911320_value", "value", "", "key", "")), ReactSystemFunctions.convertToTypeByName("True", "string")))) === true ? "visible" : "hidden")
			stateVars.isComp701913Visible = ((ReactSystemFunctions.isNotEmpty(ReactSystemFunctions.value(this, (stateVars.GetSalesProduct !== undefined ? (stateVars.GetSalesProduct?.length > 0 ? stateVars.GetSalesProduct[0].id : null) : (this.state.GetSalesProduct?.length > 0 ? this.state.GetSalesProduct[0].id : null))), ReactSystemFunctions.convertToTypeByName("True", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp516757Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, (stateVars.TMSalesPaymentList !== undefined ? (stateVars.TMSalesPaymentList?.length > 0 ? stateVars.TMSalesPaymentList[0].remainingEUR : null) : (this.state.TMSalesPaymentList?.length > 0 ? this.state.TMSalesPaymentList[0].remainingEUR : null))), ReactSystemFunctions.convertToTypeByName("0", "string"))) === true ? "visible" : "hidden")

	this.props.form?.setFieldsValue(formVars);
	this.setState(stateVars);
	KuikaAppManager.hideSpinner(this);

            this.setPageInitLoaded(true);
            return isErrorOccurred;
        }




    FreeSalesWebComponent_89837_onChange = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
		KuikaAppManager.increaseServerRequestCount();

        let localVar = {
				StoreId_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "freesalesweb_89837_value", "value", "TM_StoreGetList", "id", "id")), "Guid")
        }

		KuikaAppManager.showSpinner(this);
		
        if (true) {
        KuikaAppManager.showSpinner(this);
        }
        let result = await KuikaAppManager.ApiRequest(this, "FreeSalesWeb/FreeSalesWebComponent_89837_onChange", localVar)
        if (!KMainFunctions.IsResStatus2XX(result)) return true;

			stateVars.GetSalesPersonByStore = result?.data.getSalesPersonByStore;
			
			formVars.freesalesweb_471458_value = (stateVars.GetSalesPersonByStore !== undefined ? (stateVars.GetSalesPersonByStore?.length > 0 ? stateVars.GetSalesPersonByStore[0].kuserID : null) : (this.state.GetSalesPersonByStore?.length > 0 ? this.state.GetSalesPersonByStore[0].kuserID : null));
			formVars.freesalesweb_471458_options = stateVars.GetSalesPersonByStore;
			this.props.form?.setFieldsValue(formVars);
			
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.FreeSalesWebComponent_89837_onChange1_();
                  resolve();
                });
          })



        
        KuikaAppManager.hideSpinner(this);
        return isErrorOccurred;
    }
		FreeSalesWebComponent_89837_onChange1_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }

				formVars.freesalesweb_471458_value = ReactSystemFunctions.toString(this, (stateVars.GetSalesPersonByStore !== undefined ? (stateVars.GetSalesPersonByStore?.length > 0 ? stateVars.GetSalesPersonByStore[0].kuserID : null) : (this.state.GetSalesPersonByStore?.length > 0 ? this.state.GetSalesPersonByStore[0].kuserID : null)));

				formVars.freesalesweb_471458_value = ReactSystemFunctions.toString(this, (stateVars.GetSalesPersonByStore !== undefined ? (stateVars.GetSalesPersonByStore?.length > 0 ? stateVars.GetSalesPersonByStore[0].kuserID : null) : (this.state.GetSalesPersonByStore?.length > 0 ? this.state.GetSalesPersonByStore[0].kuserID : null)));

				stateVars.dataSource_471458 = stateVars.GetSalesPersonByStore ?? this.state.GetSalesPersonByStore;
				stateVars.dataSource_471458 = stateVars.GetSalesPersonByStore ?? this.state.GetSalesPersonByStore;

		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

            
            return isErrorOccurred;
        }




    FreeSalesWebComponent_560284_onChange = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
		KuikaAppManager.increaseServerRequestCount();

        let localVar = {
				CustomerId_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "freesalesweb_560284_value", "value", "TM_GetCustomerByName", "id", "id")), "Guid")
        }

		KuikaAppManager.showSpinner(this);
		
        if (true) {
        KuikaAppManager.showSpinner(this);
        }
        let result = await KuikaAppManager.ApiRequest(this, "FreeSalesWeb/FreeSalesWebComponent_560284_onChange", localVar)
        if (!KMainFunctions.IsResStatus2XX(result)) return true;

			stateVars.TM_GetCustomerById = result?.data.tM_GetCustomerById;
			formVars.freesalesweb_291650_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetCustomerById !== undefined ? (stateVars.TM_GetCustomerById?.length > 0 ? stateVars.TM_GetCustomerById[0].adSoyad : null) : (this.state.TM_GetCustomerById?.length > 0 ? this.state.TM_GetCustomerById[0].adSoyad : null)));
			formVars.freesalesweb_308396_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetCustomerById !== undefined ? (stateVars.TM_GetCustomerById?.length > 0 ? stateVars.TM_GetCustomerById[0].tcKimlikNo : null) : (this.state.TM_GetCustomerById?.length > 0 ? this.state.TM_GetCustomerById[0].tcKimlikNo : null)));
			formVars.freesalesweb_336874_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetCustomerById !== undefined ? (stateVars.TM_GetCustomerById?.length > 0 ? stateVars.TM_GetCustomerById[0].telefonNo : null) : (this.state.TM_GetCustomerById?.length > 0 ? this.state.TM_GetCustomerById[0].telefonNo : null)));
			formVars.freesalesweb_244674_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetCustomerById !== undefined ? (stateVars.TM_GetCustomerById?.length > 0 ? stateVars.TM_GetCustomerById[0].email : null) : (this.state.TM_GetCustomerById?.length > 0 ? this.state.TM_GetCustomerById[0].email : null)));
			formVars.freesalesweb_527586_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetCustomerById !== undefined ? (stateVars.TM_GetCustomerById?.length > 0 ? stateVars.TM_GetCustomerById[0].sehir : null) : (this.state.TM_GetCustomerById?.length > 0 ? this.state.TM_GetCustomerById[0].sehir : null)));
			stateVars.isComp884643Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, (stateVars.TM_GetCustomerById !== undefined ? (stateVars.TM_GetCustomerById?.length > 0 ? stateVars.TM_GetCustomerById[0].isShopping : null) : (this.state.TM_GetCustomerById?.length > 0 ? this.state.TM_GetCustomerById[0].isShopping : null))), ReactSystemFunctions.convertToTypeByName("True", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp262981Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, (stateVars.TM_GetCustomerById !== undefined ? (stateVars.TM_GetCustomerById?.length > 0 ? stateVars.TM_GetCustomerById[0].isShopping : null) : (this.state.TM_GetCustomerById?.length > 0 ? this.state.TM_GetCustomerById[0].isShopping : null))), ReactSystemFunctions.convertToTypeByName("False", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp492901Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, (stateVars.TM_GetCustomerById !== undefined ? (stateVars.TM_GetCustomerById?.length > 0 ? stateVars.TM_GetCustomerById[0].isEInvoice : null) : (this.state.TM_GetCustomerById?.length > 0 ? this.state.TM_GetCustomerById[0].isEInvoice : null))), ReactSystemFunctions.convertToTypeByName("False", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp126493Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, (stateVars.TM_GetCustomerById !== undefined ? (stateVars.TM_GetCustomerById?.length > 0 ? stateVars.TM_GetCustomerById[0].isEInvoice : null) : (this.state.TM_GetCustomerById?.length > 0 ? this.state.TM_GetCustomerById[0].isEInvoice : null))), ReactSystemFunctions.convertToTypeByName("True", "string"))) === true ? "visible" : "hidden")
			this.props.form?.setFieldsValue(formVars);
			
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.FreeSalesWebComponent_560284_onChange1_();
                  resolve();
                });
          })



        
        KuikaAppManager.hideSpinner(this);
        return isErrorOccurred;
    }
		FreeSalesWebComponent_560284_onChange1_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }

				stateVars.isComp636437Visible = ((ReactSystemFunctions.isNotEmpty(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "freesalesweb_560284_value", "value", "TM_GetCustomerByName", "id", "id")), ReactSystemFunctions.convertToTypeByName("True", "string"))) === true ? "visible" : "hidden")
				formVars.freesalesweb_291650_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetCustomerById !== undefined ? (stateVars.TM_GetCustomerById?.length > 0 ? stateVars.TM_GetCustomerById[0].adSoyad : null) : (this.state.TM_GetCustomerById?.length > 0 ? this.state.TM_GetCustomerById[0].adSoyad : null)));

				formVars.freesalesweb_308396_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetCustomerById !== undefined ? (stateVars.TM_GetCustomerById?.length > 0 ? stateVars.TM_GetCustomerById[0].tcKimlikNo : null) : (this.state.TM_GetCustomerById?.length > 0 ? this.state.TM_GetCustomerById[0].tcKimlikNo : null)));

				formVars.freesalesweb_336874_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetCustomerById !== undefined ? (stateVars.TM_GetCustomerById?.length > 0 ? stateVars.TM_GetCustomerById[0].telefonNo : null) : (this.state.TM_GetCustomerById?.length > 0 ? this.state.TM_GetCustomerById[0].telefonNo : null)));

				formVars.freesalesweb_244674_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetCustomerById !== undefined ? (stateVars.TM_GetCustomerById?.length > 0 ? stateVars.TM_GetCustomerById[0].email : null) : (this.state.TM_GetCustomerById?.length > 0 ? this.state.TM_GetCustomerById[0].email : null)));

				formVars.freesalesweb_527586_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetCustomerById !== undefined ? (stateVars.TM_GetCustomerById?.length > 0 ? stateVars.TM_GetCustomerById[0].sehir : null) : (this.state.TM_GetCustomerById?.length > 0 ? this.state.TM_GetCustomerById[0].sehir : null)));

				stateVars.isComp170951Visible = (((ReactSystemFunctions.isNotEmpty(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "freesalesweb_560284_value", "value", "TM_GetCustomerByName", "id", "id")), ReactSystemFunctions.convertToTypeByName("True", "string")) && ReactSystemFunctions.isNotEmpty(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "freesalesweb_911320_value", "value", "", "key", "")), ReactSystemFunctions.convertToTypeByName("True", "string")))) === true ? "visible" : "hidden")

		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

            
            return isErrorOccurred;
        }




    FreeSalesWebComponent_662297_onClick = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
		KuikaAppManager.increaseServerRequestCount();

        let localVar = {
				SalesPersonTMUserId_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "freesalesweb_471458_value", "value", "GetSalesPersonByStore", "kuserID", "id")), "Guid"),
				KUserId_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.getMyUserId(), "Guid"),
				InvoiceType_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toInteger(this, ReactSystemFunctions.value(this, "freesalesweb_911320_value", "value", "", "key", "")), "number"),
				TaxFreeOturuNo_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "freesalesweb_691987_value", "value", "", "", "")), "string"),
				TaxFreeBaslangic_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "freesalesweb_115957_value", "value", "", "", "")), "Date"),
				TaxFreeBitis_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "freesalesweb_667342_value", "value", "", "", "")), "Date"),
				CustomerId_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "freesalesweb_560284_value", "value", "TM_GetCustomerByName", "id", "id")), "Guid"),
				IsEInvoiceApi_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, (stateVars.TM_GetCustomerById !== undefined ? (stateVars.TM_GetCustomerById?.length > 0 ? stateVars.TM_GetCustomerById[0].isEInvoice : null) : (this.state.TM_GetCustomerById?.length > 0 ? this.state.TM_GetCustomerById[0].isEInvoice : null))), "boolean"),
				StoreCode_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "freesalesweb_471458_value", "value", "GetSalesPersonByStore", "kuserID", "storeID")), "string")
        }

		KuikaAppManager.showSpinner(this);
		
        if (true) {
        KuikaAppManager.showSpinner(this);
        }
        let result = await KuikaAppManager.ApiRequest(this, "FreeSalesWeb/FreeSalesWebComponent_662297_onClick", localVar)
        if (!KMainFunctions.IsResStatus2XX(result)) return true;

			stateVars.TMSalesDraftCreate = result?.data.tmSalesDraftCreate;
			this.props.form?.setFieldsValue(formVars);
			
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.FreeSalesWebComponent_662297_onClick1_();
                  resolve();
                });
          })



        
        KuikaAppManager.hideSpinner(this);
        return isErrorOccurred;
    }
		FreeSalesWebComponent_662297_onClick1_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }

				stateVars.Notify = await ReactSystemFunctions.notify(this, ReactSystemFunctions.toString(this, (stateVars.TMSalesDraftCreate !== undefined ? (stateVars.TMSalesDraftCreate?.length > 0 ? stateVars.TMSalesDraftCreate[0].message : null) : (this.state.TMSalesDraftCreate?.length > 0 ? this.state.TMSalesDraftCreate[0].message : null))), ReactSystemFunctions.convertToTypeByName("default", "string"), ReactSystemFunctions.convertToTypeByName("bottom-right", "string"), 3, ReactSystemFunctions.convertToTypeByName("", "string"), ReactSystemFunctions.convertToTypeByName("", "string"), 0);

		this.props.form?.setFieldsValue(formVars);
		
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.FreeSalesWebComponent_662297_onClick2_();
                  resolve();
                });
          })

            
            return isErrorOccurred;
        }
		FreeSalesWebComponent_662297_onClick2_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
if (ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, (stateVars.TMSalesDraftCreate !== undefined ? (stateVars.TMSalesDraftCreate?.length > 0 ? stateVars.TMSalesDraftCreate[0].success : null) : (this.state.TMSalesDraftCreate?.length > 0 ? this.state.TMSalesDraftCreate[0].success : null))), "1")) {
            
				stateVars.ChangeEnabledOf = await ReactSystemFunctions.changeEnabledOf(this, ReactSystemFunctions.convertToTypeByName("isComp73196Enabled", "string"), ReactSystemFunctions.convertToTypeByName("disabled", "string"));

		this.props.form?.setFieldsValue(formVars);
		
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.FreeSalesWebComponent_662297_onClick3_();
                  resolve();
                });
          })

        } else {
            
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.FreeSalesWebComponent_662297_onClick3_();
                  resolve();
                });
          })
        }

            
            return isErrorOccurred;
        }
		FreeSalesWebComponent_662297_onClick3_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
if (ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, (stateVars.TMSalesDraftCreate !== undefined ? (stateVars.TMSalesDraftCreate?.length > 0 ? stateVars.TMSalesDraftCreate[0].success : null) : (this.state.TMSalesDraftCreate?.length > 0 ? this.state.TMSalesDraftCreate[0].success : null))), "1")) {
            
				stateVars.ChangeVisibilityOf = await ReactSystemFunctions.changeVisibilityOf(this, ReactSystemFunctions.convertToTypeByName("isComp417391Visible", "string"), ReactSystemFunctions.convertToTypeByName("visible", "string"));

		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

        } else {
            KuikaAppManager.hideSpinner(this);
        }

            
            return isErrorOccurred;
        }






    FreeSalesWebComponent_853840_onClick = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
		KuikaAppManager.increaseServerRequestCount();

        let localVar = {
				usedCode_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "freesalesweb_514927_value", "value", "", "", "")), "string"),
				wareHouseCode_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "freesalesweb_471458_value", "value", "GetSalesPersonByStore", "kuserID", "wareHouseCode")), "string"),
				ProductCode_1: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, (stateVars.Kuika_ItemInfoLive !== undefined ? (stateVars.Kuika_ItemInfoLive?.length > 0 ? stateVars.Kuika_ItemInfoLive[0].itemCode : null) : (this.state.Kuika_ItemInfoLive?.length > 0 ? this.state.Kuika_ItemInfoLive[0].itemCode : null))), "string"),
				SalesDraftId_1: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, (stateVars.TMSalesDraftCreate !== undefined ? (stateVars.TMSalesDraftCreate?.length > 0 ? stateVars.TMSalesDraftCreate[0].draftId : null) : (this.state.TMSalesDraftCreate?.length > 0 ? this.state.TMSalesDraftCreate[0].draftId : null))), "Guid"),
				SeriNo_1: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, (stateVars.Kuika_ItemInfoLive !== undefined ? (stateVars.Kuika_ItemInfoLive?.length > 0 ? stateVars.Kuika_ItemInfoLive[0].itemSerialNumber : null) : (this.state.Kuika_ItemInfoLive?.length > 0 ? this.state.Kuika_ItemInfoLive[0].itemSerialNumber : null))), "string"),
				Barcode_1: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, (stateVars.Kuika_ItemInfoLive !== undefined ? (stateVars.Kuika_ItemInfoLive?.length > 0 ? stateVars.Kuika_ItemInfoLive[0].barcode : null) : (this.state.Kuika_ItemInfoLive?.length > 0 ? this.state.Kuika_ItemInfoLive[0].barcode : null))), "string"),
				Price_1: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, (stateVars.Kuika_ItemInfoLive !== undefined ? (stateVars.Kuika_ItemInfoLive?.length > 0 ? stateVars.Kuika_ItemInfoLive[0].price : null) : (this.state.Kuika_ItemInfoLive?.length > 0 ? this.state.Kuika_ItemInfoLive[0].price : null))), "number"),
				ProductName_1: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, (stateVars.Kuika_ItemInfoLive !== undefined ? (stateVars.Kuika_ItemInfoLive?.length > 0 ? stateVars.Kuika_ItemInfoLive[stateVars.Kuika_ItemInfoLive.length - 1].itemDescription : null) : (this.state.Kuika_ItemInfoLive?.length > 0 ? this.state.Kuika_ItemInfoLive[this.state.Kuika_ItemInfoLive.length - 1].itemDescription : null))), "string"),
				UseSerialNumber_1: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, (stateVars.Kuika_ItemInfoLive !== undefined ? (stateVars.Kuika_ItemInfoLive?.length > 0 ? stateVars.Kuika_ItemInfoLive[0].useSerialNumber : null) : (this.state.Kuika_ItemInfoLive?.length > 0 ? this.state.Kuika_ItemInfoLive[0].useSerialNumber : null))), "string"),
				SalesDraftId_2: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, (stateVars.TMSalesDraftCreate !== undefined ? (stateVars.TMSalesDraftCreate?.length > 0 ? stateVars.TMSalesDraftCreate[0].draftId : null) : (this.state.TMSalesDraftCreate?.length > 0 ? this.state.TMSalesDraftCreate[0].draftId : null))), "Guid"),
				SalesDraftId_3: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, (stateVars.TMSalesDraftCreate !== undefined ? (stateVars.TMSalesDraftCreate?.length > 0 ? stateVars.TMSalesDraftCreate[0].draftId : null) : (this.state.TMSalesDraftCreate?.length > 0 ? this.state.TMSalesDraftCreate[0].draftId : null))), "Guid")
        }

		KuikaAppManager.showSpinner(this);
		
        if (true) {
        KuikaAppManager.showSpinner(this);
        }
        let result = await KuikaAppManager.ApiRequest(this, "FreeSalesWeb/FreeSalesWebComponent_853840_onClick", localVar)
        if (!KMainFunctions.IsResStatus2XX(result)) return true;

			stateVars.Kuika_ItemInfoLive = result?.data.kuika_ItemInfoLive;
			stateVars.TMSalesDraftAddProduct = result?.data.tmSalesDraftAddProduct;
			stateVars.GetSalesProduct = result?.data.getSalesProduct;
			
			formVars.freesalesweb_540666_value = ReactSystemFunctions.toString(this, (stateVars.GetSalesProduct !== undefined ? (stateVars.GetSalesProduct?.length > 0 ? stateVars.GetSalesProduct[0].totalProductCount : null) : (this.state.GetSalesProduct?.length > 0 ? this.state.GetSalesProduct[0].totalProductCount : null)));
			formVars.freesalesweb_945611_value = ReactSystemFunctions.toString(this, (stateVars.GetSalesProduct !== undefined ? (stateVars.GetSalesProduct?.length > 0 ? stateVars.GetSalesProduct[0].totalAmountEUR : null) : (this.state.GetSalesProduct?.length > 0 ? this.state.GetSalesProduct[0].totalAmountEUR : null)));
			stateVars.isComp701913Visible = ((ReactSystemFunctions.isNotEmpty(ReactSystemFunctions.value(this, (stateVars.GetSalesProduct !== undefined ? (stateVars.GetSalesProduct?.length > 0 ? stateVars.GetSalesProduct[0].id : null) : (this.state.GetSalesProduct?.length > 0 ? this.state.GetSalesProduct[0].id : null))), ReactSystemFunctions.convertToTypeByName("True", "string"))) === true ? "visible" : "hidden")
			stateVars.TMSalesPaymentList = result?.data.tmSalesPaymentList;
			
			formVars.freesalesweb_806958_value = ReactSystemFunctions.toString(this, (stateVars.TMSalesPaymentList !== undefined ? (stateVars.TMSalesPaymentList?.length > 0 ? stateVars.TMSalesPaymentList[0].collectedTotalEUR : null) : (this.state.TMSalesPaymentList?.length > 0 ? this.state.TMSalesPaymentList[0].collectedTotalEUR : null)));
			formVars.freesalesweb_308158_value = ReactSystemFunctions.toString(this, (stateVars.TMSalesPaymentList !== undefined ? (stateVars.TMSalesPaymentList?.length > 0 ? stateVars.TMSalesPaymentList[0].remainingEUR : null) : (this.state.TMSalesPaymentList?.length > 0 ? this.state.TMSalesPaymentList[0].remainingEUR : null)));
			stateVars.isComp516757Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, (stateVars.TMSalesPaymentList !== undefined ? (stateVars.TMSalesPaymentList?.length > 0 ? stateVars.TMSalesPaymentList[0].remainingEUR : null) : (this.state.TMSalesPaymentList?.length > 0 ? this.state.TMSalesPaymentList[0].remainingEUR : null))), ReactSystemFunctions.convertToTypeByName("0", "string"))) === true ? "visible" : "hidden")
			this.props.form?.setFieldsValue(formVars);
			
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.FreeSalesWebComponent_853840_onClick1_();
                  resolve();
                });
          })



        
        KuikaAppManager.hideSpinner(this);
        return isErrorOccurred;
    }
		FreeSalesWebComponent_853840_onClick1_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }

				stateVars.Notify = await ReactSystemFunctions.notify(this, ReactSystemFunctions.toString(this, (stateVars.TMSalesDraftAddProduct !== undefined ? (stateVars.TMSalesDraftAddProduct?.length > 0 ? stateVars.TMSalesDraftAddProduct[0].message : null) : (this.state.TMSalesDraftAddProduct?.length > 0 ? this.state.TMSalesDraftAddProduct[0].message : null))), ReactSystemFunctions.convertToTypeByName("default", "string"), ReactSystemFunctions.convertToTypeByName("bottom-right", "string"), 2, ReactSystemFunctions.convertToTypeByName("", "string"), ReactSystemFunctions.convertToTypeByName("", "string"), 0);

		this.props.form?.setFieldsValue(formVars);
		
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.FreeSalesWebComponent_853840_onClick2_();
                  resolve();
                });
          })

            
            return isErrorOccurred;
        }
		FreeSalesWebComponent_853840_onClick2_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
if (ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, (stateVars.TMSalesDraftAddProduct !== undefined ? (stateVars.TMSalesDraftAddProduct?.length > 0 ? stateVars.TMSalesDraftAddProduct[0].success : null) : (this.state.TMSalesDraftAddProduct?.length > 0 ? this.state.TMSalesDraftAddProduct[0].success : null))), "1")) {
            
				stateVars.SetValueOf = await ReactSystemFunctions.setValueOf(this, ReactSystemFunctions.convertToTypeByName("freesalesweb_514927_value", "string"), "", null, false);

		this.props.form?.setFieldsValue(formVars);
		
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.FreeSalesWebComponent_853840_onClick3_();
                  resolve();
                });
          })

        } else {
            
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.FreeSalesWebComponent_853840_onClick3_();
                  resolve();
                });
          })
        }

            
            return isErrorOccurred;
        }
		FreeSalesWebComponent_853840_onClick3_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }

				
				stateVars.dataSource_829773 = stateVars.GetSalesProduct ?? this.state.GetSalesProduct;
				formVars.freesalesweb_540666_value = ReactSystemFunctions.toString(this, (stateVars.GetSalesProduct !== undefined ? (stateVars.GetSalesProduct?.length > 0 ? stateVars.GetSalesProduct[0].totalProductCount : null) : (this.state.GetSalesProduct?.length > 0 ? this.state.GetSalesProduct[0].totalProductCount : null)));

				formVars.freesalesweb_945611_value = ReactSystemFunctions.toString(this, (stateVars.GetSalesProduct !== undefined ? (stateVars.GetSalesProduct?.length > 0 ? stateVars.GetSalesProduct[0].totalAmountEUR : null) : (this.state.GetSalesProduct?.length > 0 ? this.state.GetSalesProduct[0].totalAmountEUR : null)));

				
				stateVars.dataSource_546168 = stateVars.TMSalesPaymentList ?? this.state.TMSalesPaymentList;
				formVars.freesalesweb_806958_value = ReactSystemFunctions.toString(this, (stateVars.TMSalesPaymentList !== undefined ? (stateVars.TMSalesPaymentList?.length > 0 ? stateVars.TMSalesPaymentList[0].collectedTotalEUR : null) : (this.state.TMSalesPaymentList?.length > 0 ? this.state.TMSalesPaymentList[0].collectedTotalEUR : null)));

				formVars.freesalesweb_308158_value = ReactSystemFunctions.toString(this, (stateVars.TMSalesPaymentList !== undefined ? (stateVars.TMSalesPaymentList?.length > 0 ? stateVars.TMSalesPaymentList[0].remainingEUR : null) : (this.state.TMSalesPaymentList?.length > 0 ? this.state.TMSalesPaymentList[0].remainingEUR : null)));


		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

            
            return isErrorOccurred;
        }






    FreeSalesWebComponent_544273_onBlur = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
		KuikaAppManager.increaseServerRequestCount();

        let localVar = {
				DraftDetailId_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, "freesalesweb_829773_value", "id"), "Guid"),
				DiscountRate_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "Table_829773_discountRate", "value", "", "", "")), "number"),
				SalesDraftId_1: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, (stateVars.TMSalesDraftCreate !== undefined ? (stateVars.TMSalesDraftCreate?.length > 0 ? stateVars.TMSalesDraftCreate[0].draftId : null) : (this.state.TMSalesDraftCreate?.length > 0 ? this.state.TMSalesDraftCreate[0].draftId : null))), "Guid"),
				SalesDraftId_2: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, (stateVars.TMSalesDraftCreate !== undefined ? (stateVars.TMSalesDraftCreate?.length > 0 ? stateVars.TMSalesDraftCreate[0].draftId : null) : (this.state.TMSalesDraftCreate?.length > 0 ? this.state.TMSalesDraftCreate[0].draftId : null))), "Guid")
        }

		KuikaAppManager.showSpinner(this);
		
        if (true) {
        KuikaAppManager.showSpinner(this);
        }
        let result = await KuikaAppManager.ApiRequest(this, "FreeSalesWeb/FreeSalesWebComponent_544273_onBlur", localVar)
        if (!KMainFunctions.IsResStatus2XX(result)) return true;

			stateVars.TMIskontoAddSales = result?.data.tmIskontoAddSales;
			stateVars.GetSalesProduct = result?.data.getSalesProduct;
			
			formVars.freesalesweb_540666_value = ReactSystemFunctions.toString(this, (stateVars.GetSalesProduct !== undefined ? (stateVars.GetSalesProduct?.length > 0 ? stateVars.GetSalesProduct[0].totalProductCount : null) : (this.state.GetSalesProduct?.length > 0 ? this.state.GetSalesProduct[0].totalProductCount : null)));
			formVars.freesalesweb_945611_value = ReactSystemFunctions.toString(this, (stateVars.GetSalesProduct !== undefined ? (stateVars.GetSalesProduct?.length > 0 ? stateVars.GetSalesProduct[0].totalAmountEUR : null) : (this.state.GetSalesProduct?.length > 0 ? this.state.GetSalesProduct[0].totalAmountEUR : null)));
			stateVars.isComp701913Visible = ((ReactSystemFunctions.isNotEmpty(ReactSystemFunctions.value(this, (stateVars.GetSalesProduct !== undefined ? (stateVars.GetSalesProduct?.length > 0 ? stateVars.GetSalesProduct[0].id : null) : (this.state.GetSalesProduct?.length > 0 ? this.state.GetSalesProduct[0].id : null))), ReactSystemFunctions.convertToTypeByName("True", "string"))) === true ? "visible" : "hidden")
			stateVars.TMSalesPaymentList = result?.data.tmSalesPaymentList;
			
			formVars.freesalesweb_806958_value = ReactSystemFunctions.toString(this, (stateVars.TMSalesPaymentList !== undefined ? (stateVars.TMSalesPaymentList?.length > 0 ? stateVars.TMSalesPaymentList[0].collectedTotalEUR : null) : (this.state.TMSalesPaymentList?.length > 0 ? this.state.TMSalesPaymentList[0].collectedTotalEUR : null)));
			formVars.freesalesweb_308158_value = ReactSystemFunctions.toString(this, (stateVars.TMSalesPaymentList !== undefined ? (stateVars.TMSalesPaymentList?.length > 0 ? stateVars.TMSalesPaymentList[0].remainingEUR : null) : (this.state.TMSalesPaymentList?.length > 0 ? this.state.TMSalesPaymentList[0].remainingEUR : null)));
			stateVars.isComp516757Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, (stateVars.TMSalesPaymentList !== undefined ? (stateVars.TMSalesPaymentList?.length > 0 ? stateVars.TMSalesPaymentList[0].remainingEUR : null) : (this.state.TMSalesPaymentList?.length > 0 ? this.state.TMSalesPaymentList[0].remainingEUR : null))), ReactSystemFunctions.convertToTypeByName("0", "string"))) === true ? "visible" : "hidden")
			this.props.form?.setFieldsValue(formVars);
			
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.FreeSalesWebComponent_544273_onBlur1_();
                  resolve();
                });
          })



        
        KuikaAppManager.hideSpinner(this);
        return isErrorOccurred;
    }
		FreeSalesWebComponent_544273_onBlur1_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }

				stateVars.Notify = await ReactSystemFunctions.notify(this, ReactSystemFunctions.toString(this, (stateVars.TMIskontoAddSales !== undefined ? (stateVars.TMIskontoAddSales?.length > 0 ? stateVars.TMIskontoAddSales[0].message : null) : (this.state.TMIskontoAddSales?.length > 0 ? this.state.TMIskontoAddSales[0].message : null))), ReactSystemFunctions.convertToTypeByName("default", "string"), ReactSystemFunctions.convertToTypeByName("bottom-right", "string"), 2, ReactSystemFunctions.convertToTypeByName("", "string"), ReactSystemFunctions.convertToTypeByName("", "string"), 0);
				
				stateVars.dataSource_829773 = stateVars.GetSalesProduct ?? this.state.GetSalesProduct;
				formVars.freesalesweb_540666_value = ReactSystemFunctions.toString(this, (stateVars.GetSalesProduct !== undefined ? (stateVars.GetSalesProduct?.length > 0 ? stateVars.GetSalesProduct[0].totalProductCount : null) : (this.state.GetSalesProduct?.length > 0 ? this.state.GetSalesProduct[0].totalProductCount : null)));

				formVars.freesalesweb_945611_value = ReactSystemFunctions.toString(this, (stateVars.GetSalesProduct !== undefined ? (stateVars.GetSalesProduct?.length > 0 ? stateVars.GetSalesProduct[0].totalAmountEUR : null) : (this.state.GetSalesProduct?.length > 0 ? this.state.GetSalesProduct[0].totalAmountEUR : null)));

				
				stateVars.dataSource_546168 = stateVars.TMSalesPaymentList ?? this.state.TMSalesPaymentList;
				formVars.freesalesweb_806958_value = ReactSystemFunctions.toString(this, (stateVars.TMSalesPaymentList !== undefined ? (stateVars.TMSalesPaymentList?.length > 0 ? stateVars.TMSalesPaymentList[0].collectedTotalEUR : null) : (this.state.TMSalesPaymentList?.length > 0 ? this.state.TMSalesPaymentList[0].collectedTotalEUR : null)));

				formVars.freesalesweb_308158_value = ReactSystemFunctions.toString(this, (stateVars.TMSalesPaymentList !== undefined ? (stateVars.TMSalesPaymentList?.length > 0 ? stateVars.TMSalesPaymentList[0].remainingEUR : null) : (this.state.TMSalesPaymentList?.length > 0 ? this.state.TMSalesPaymentList[0].remainingEUR : null)));


		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

            
            return isErrorOccurred;
        }




    FreeSalesWebComponent_730700_onClick = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
		KuikaAppManager.increaseServerRequestCount();

        let localVar = {
				DraftDetailId_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, "freesalesweb_829773_value", "id"), "Guid"),
				SalesDraftId_1: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, (stateVars.TMSalesDraftCreate !== undefined ? (stateVars.TMSalesDraftCreate?.length > 0 ? stateVars.TMSalesDraftCreate[0].draftId : null) : (this.state.TMSalesDraftCreate?.length > 0 ? this.state.TMSalesDraftCreate[0].draftId : null))), "Guid"),
				SalesDraftId_2: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, (stateVars.TMSalesDraftCreate !== undefined ? (stateVars.TMSalesDraftCreate?.length > 0 ? stateVars.TMSalesDraftCreate[0].draftId : null) : (this.state.TMSalesDraftCreate?.length > 0 ? this.state.TMSalesDraftCreate[0].draftId : null))), "Guid")
        }

		KuikaAppManager.showSpinner(this);

            stateVars.Confirm = await ReactSystemFunctions.confirmation(
                ReactSystemFunctions.translateCustomActions(this.ml,"e349ebad_4ddc_0bb9_6ffe_830b271e784d_confirmation",this.defaultML,"Ürünü silmek istiyor musunuz?" ),
                "calibri",
                "Bilgi",
                "question",
                "#246dff",
                "",
                ""
            );

            if (stateVars.Confirm)
            {
                		
        if (true) {
        KuikaAppManager.showSpinner(this);
        }
        let result = await KuikaAppManager.ApiRequest(this, "FreeSalesWeb/FreeSalesWebComponent_730700_onClick", localVar)
        if (!KMainFunctions.IsResStatus2XX(result)) return true;

			stateVars.TMSalesProductDelete = result?.data.tmSalesProductDelete;
			stateVars.GetSalesProduct = result?.data.getSalesProduct;
			
			formVars.freesalesweb_540666_value = ReactSystemFunctions.toString(this, (stateVars.GetSalesProduct !== undefined ? (stateVars.GetSalesProduct?.length > 0 ? stateVars.GetSalesProduct[0].totalProductCount : null) : (this.state.GetSalesProduct?.length > 0 ? this.state.GetSalesProduct[0].totalProductCount : null)));
			formVars.freesalesweb_945611_value = ReactSystemFunctions.toString(this, (stateVars.GetSalesProduct !== undefined ? (stateVars.GetSalesProduct?.length > 0 ? stateVars.GetSalesProduct[0].totalAmountEUR : null) : (this.state.GetSalesProduct?.length > 0 ? this.state.GetSalesProduct[0].totalAmountEUR : null)));
			stateVars.isComp701913Visible = ((ReactSystemFunctions.isNotEmpty(ReactSystemFunctions.value(this, (stateVars.GetSalesProduct !== undefined ? (stateVars.GetSalesProduct?.length > 0 ? stateVars.GetSalesProduct[0].id : null) : (this.state.GetSalesProduct?.length > 0 ? this.state.GetSalesProduct[0].id : null))), ReactSystemFunctions.convertToTypeByName("True", "string"))) === true ? "visible" : "hidden")
			stateVars.TMSalesPaymentList = result?.data.tmSalesPaymentList;
			
			formVars.freesalesweb_806958_value = ReactSystemFunctions.toString(this, (stateVars.TMSalesPaymentList !== undefined ? (stateVars.TMSalesPaymentList?.length > 0 ? stateVars.TMSalesPaymentList[0].collectedTotalEUR : null) : (this.state.TMSalesPaymentList?.length > 0 ? this.state.TMSalesPaymentList[0].collectedTotalEUR : null)));
			formVars.freesalesweb_308158_value = ReactSystemFunctions.toString(this, (stateVars.TMSalesPaymentList !== undefined ? (stateVars.TMSalesPaymentList?.length > 0 ? stateVars.TMSalesPaymentList[0].remainingEUR : null) : (this.state.TMSalesPaymentList?.length > 0 ? this.state.TMSalesPaymentList[0].remainingEUR : null)));
			stateVars.isComp516757Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, (stateVars.TMSalesPaymentList !== undefined ? (stateVars.TMSalesPaymentList?.length > 0 ? stateVars.TMSalesPaymentList[0].remainingEUR : null) : (this.state.TMSalesPaymentList?.length > 0 ? this.state.TMSalesPaymentList[0].remainingEUR : null))), ReactSystemFunctions.convertToTypeByName("0", "string"))) === true ? "visible" : "hidden")
			this.props.form?.setFieldsValue(formVars);
			
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.FreeSalesWebComponent_730700_onClick1_();
                  resolve();
                });
          })

            }
            else
            {
                KuikaAppManager.hideSpinner(this);
            }


        
        KuikaAppManager.hideSpinner(this);
        return isErrorOccurred;
    }
		FreeSalesWebComponent_730700_onClick1_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }

				stateVars.Notify = await ReactSystemFunctions.notify(this, ReactSystemFunctions.toString(this, (stateVars.TMSalesProductDelete !== undefined ? (stateVars.TMSalesProductDelete?.length > 0 ? stateVars.TMSalesProductDelete[0].message : null) : (this.state.TMSalesProductDelete?.length > 0 ? this.state.TMSalesProductDelete[0].message : null))), ReactSystemFunctions.convertToTypeByName("default", "string"), ReactSystemFunctions.convertToTypeByName("bottom-right", "string"), 2, ReactSystemFunctions.convertToTypeByName("", "string"), ReactSystemFunctions.convertToTypeByName("", "string"), 0);
				
				stateVars.dataSource_829773 = stateVars.GetSalesProduct ?? this.state.GetSalesProduct;
				formVars.freesalesweb_540666_value = ReactSystemFunctions.toString(this, (stateVars.GetSalesProduct !== undefined ? (stateVars.GetSalesProduct?.length > 0 ? stateVars.GetSalesProduct[0].totalProductCount : null) : (this.state.GetSalesProduct?.length > 0 ? this.state.GetSalesProduct[0].totalProductCount : null)));

				formVars.freesalesweb_945611_value = ReactSystemFunctions.toString(this, (stateVars.GetSalesProduct !== undefined ? (stateVars.GetSalesProduct?.length > 0 ? stateVars.GetSalesProduct[0].totalAmountEUR : null) : (this.state.GetSalesProduct?.length > 0 ? this.state.GetSalesProduct[0].totalAmountEUR : null)));

				
				stateVars.dataSource_546168 = stateVars.TMSalesPaymentList ?? this.state.TMSalesPaymentList;
				formVars.freesalesweb_806958_value = ReactSystemFunctions.toString(this, (stateVars.TMSalesPaymentList !== undefined ? (stateVars.TMSalesPaymentList?.length > 0 ? stateVars.TMSalesPaymentList[0].collectedTotalEUR : null) : (this.state.TMSalesPaymentList?.length > 0 ? this.state.TMSalesPaymentList[0].collectedTotalEUR : null)));

				formVars.freesalesweb_308158_value = ReactSystemFunctions.toString(this, (stateVars.TMSalesPaymentList !== undefined ? (stateVars.TMSalesPaymentList?.length > 0 ? stateVars.TMSalesPaymentList[0].remainingEUR : null) : (this.state.TMSalesPaymentList?.length > 0 ? this.state.TMSalesPaymentList[0].remainingEUR : null)));


		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

            
            return isErrorOccurred;
        }




    FreeSalesWebComponent_661922_onChange = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
		KuikaAppManager.increaseServerRequestCount();

        let localVar = {
				PaymentType_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toInteger(this, ReactSystemFunctions.value(this, "freesalesweb_661922_value", "value", "", "key", "")), "number"),
				OfficeCode_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "freesalesweb_471458_value", "value", "GetSalesPersonByStore", "kuserID", "officeCode")), "string")
        }

		KuikaAppManager.showSpinner(this);
		
        if (true) {
        KuikaAppManager.showSpinner(this);
        }
        let result = await KuikaAppManager.ApiRequest(this, "FreeSalesWeb/FreeSalesWebComponent_661922_onChange", localVar)
        if (!KMainFunctions.IsResStatus2XX(result)) return true;

			stateVars.TMSalesPaymentType = result?.data.tmSalesPaymentType;
			
			formVars.freesalesweb_692281_options = stateVars.TMSalesPaymentType;
			this.props.form?.setFieldsValue(formVars);
			
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.FreeSalesWebComponent_661922_onChange1_();
                  resolve();
                });
          })



        
        KuikaAppManager.hideSpinner(this);
        return isErrorOccurred;
    }
		FreeSalesWebComponent_661922_onChange1_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }

				
				stateVars.dataSource_692281 = stateVars.TMSalesPaymentType ?? this.state.TMSalesPaymentType;
				stateVars.dataSource_692281 = stateVars.TMSalesPaymentType ?? this.state.TMSalesPaymentType;

		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

            
            return isErrorOccurred;
        }




    FreeSalesWebComponent_408749_onClick = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
		KuikaAppManager.increaseServerRequestCount();

        let localVar = {
				PaymentType_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "freesalesweb_692281_value", "value", "TMSalesPaymentType", "id", "paymentType")), "string"),
				CurrencyCode_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "freesalesweb_692281_value", "value", "TMSalesPaymentType", "id", "currencyCode")), "string"),
				SalesDraftId_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, (stateVars.TMSalesDraftCreate !== undefined ? (stateVars.TMSalesDraftCreate?.length > 0 ? stateVars.TMSalesDraftCreate[0].draftId : null) : (this.state.TMSalesDraftCreate?.length > 0 ? this.state.TMSalesDraftCreate[0].draftId : null))), "Guid"),
				CurrencyId_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "freesalesweb_692281_value", "value", "TMSalesPaymentType", "id", "id")), "Guid"),
				Doviz_0: ReactSystemFunctions.convertToTypeByName("", "string"),
				PaymentTypeDesc_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "freesalesweb_692281_value", "value", "TMSalesPaymentType", "id", "paymentTypeDesc")), "string"),
				SalesDraftId_1: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, (stateVars.TMSalesDraftCreate !== undefined ? (stateVars.TMSalesDraftCreate?.length > 0 ? stateVars.TMSalesDraftCreate[0].draftId : null) : (this.state.TMSalesDraftCreate?.length > 0 ? this.state.TMSalesDraftCreate[0].draftId : null))), "Guid")
        }

		KuikaAppManager.showSpinner(this);
		
        if (true) {
        KuikaAppManager.showSpinner(this);
        }
        let result = await KuikaAppManager.ApiRequest(this, "FreeSalesWeb/FreeSalesWebComponent_408749_onClick", localVar)
        if (!KMainFunctions.IsResStatus2XX(result)) return true;

			stateVars.TMAddSalesPayment = result?.data.tmAddSalesPayment;
			stateVars.TMSalesPaymentList = result?.data.tmSalesPaymentList;
			
			formVars.freesalesweb_806958_value = ReactSystemFunctions.toString(this, (stateVars.TMSalesPaymentList !== undefined ? (stateVars.TMSalesPaymentList?.length > 0 ? stateVars.TMSalesPaymentList[0].collectedTotalEUR : null) : (this.state.TMSalesPaymentList?.length > 0 ? this.state.TMSalesPaymentList[0].collectedTotalEUR : null)));
			formVars.freesalesweb_308158_value = ReactSystemFunctions.toString(this, (stateVars.TMSalesPaymentList !== undefined ? (stateVars.TMSalesPaymentList?.length > 0 ? stateVars.TMSalesPaymentList[0].remainingEUR : null) : (this.state.TMSalesPaymentList?.length > 0 ? this.state.TMSalesPaymentList[0].remainingEUR : null)));
			stateVars.isComp516757Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, (stateVars.TMSalesPaymentList !== undefined ? (stateVars.TMSalesPaymentList?.length > 0 ? stateVars.TMSalesPaymentList[0].remainingEUR : null) : (this.state.TMSalesPaymentList?.length > 0 ? this.state.TMSalesPaymentList[0].remainingEUR : null))), ReactSystemFunctions.convertToTypeByName("0", "string"))) === true ? "visible" : "hidden")
			this.props.form?.setFieldsValue(formVars);
			
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.FreeSalesWebComponent_408749_onClick1_();
                  resolve();
                });
          })



        
        KuikaAppManager.hideSpinner(this);
        return isErrorOccurred;
    }
		FreeSalesWebComponent_408749_onClick1_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }

				stateVars.Notify = await ReactSystemFunctions.notify(this, ReactSystemFunctions.toString(this, (stateVars.TMAddSalesPayment !== undefined ? (stateVars.TMAddSalesPayment?.length > 0 ? stateVars.TMAddSalesPayment[0].message : null) : (this.state.TMAddSalesPayment?.length > 0 ? this.state.TMAddSalesPayment[0].message : null))), ReactSystemFunctions.convertToTypeByName("default", "string"), ReactSystemFunctions.convertToTypeByName("bottom-right", "string"), 2, ReactSystemFunctions.convertToTypeByName("", "string"), ReactSystemFunctions.convertToTypeByName("", "string"), 0);
				stateVars.SetValueOf = await ReactSystemFunctions.setValueOf(this, ReactSystemFunctions.convertToTypeByName("freesalesweb_661922_value", "string"), "", null, "Key");
				stateVars.SetValueOf = await ReactSystemFunctions.setValueOf(this, ReactSystemFunctions.convertToTypeByName("freesalesweb_692281_value", "string"), "", null, "Id");
				
				stateVars.dataSource_546168 = stateVars.TMSalesPaymentList ?? this.state.TMSalesPaymentList;
				formVars.freesalesweb_806958_value = ReactSystemFunctions.toString(this, (stateVars.TMSalesPaymentList !== undefined ? (stateVars.TMSalesPaymentList?.length > 0 ? stateVars.TMSalesPaymentList[0].collectedTotalEUR : null) : (this.state.TMSalesPaymentList?.length > 0 ? this.state.TMSalesPaymentList[0].collectedTotalEUR : null)));

				formVars.freesalesweb_308158_value = ReactSystemFunctions.toString(this, (stateVars.TMSalesPaymentList !== undefined ? (stateVars.TMSalesPaymentList?.length > 0 ? stateVars.TMSalesPaymentList[0].remainingEUR : null) : (this.state.TMSalesPaymentList?.length > 0 ? this.state.TMSalesPaymentList[0].remainingEUR : null)));


		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

            
            return isErrorOccurred;
        }




    FreeSalesWebComponent_389463_onClick = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
		KuikaAppManager.increaseServerRequestCount();

        let localVar = {
				PaymentId_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, "freesalesweb_546168_value", "paymentId"), "Guid"),
				SalesDraftId_1: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, (stateVars.TMSalesDraftCreate !== undefined ? (stateVars.TMSalesDraftCreate?.length > 0 ? stateVars.TMSalesDraftCreate[0].draftId : null) : (this.state.TMSalesDraftCreate?.length > 0 ? this.state.TMSalesDraftCreate[0].draftId : null))), "Guid")
        }

		KuikaAppManager.showSpinner(this);
		
        if (true) {
        KuikaAppManager.showSpinner(this);
        }
        let result = await KuikaAppManager.ApiRequest(this, "FreeSalesWeb/FreeSalesWebComponent_389463_onClick", localVar)
        if (!KMainFunctions.IsResStatus2XX(result)) return true;

			stateVars.TMSalesPaymentCompletedLine = result?.data.tmSalesPaymentCompletedLine;
			stateVars.TMSalesPaymentList = result?.data.tmSalesPaymentList;
			
			formVars.freesalesweb_806958_value = ReactSystemFunctions.toString(this, (stateVars.TMSalesPaymentList !== undefined ? (stateVars.TMSalesPaymentList?.length > 0 ? stateVars.TMSalesPaymentList[0].collectedTotalEUR : null) : (this.state.TMSalesPaymentList?.length > 0 ? this.state.TMSalesPaymentList[0].collectedTotalEUR : null)));
			formVars.freesalesweb_308158_value = ReactSystemFunctions.toString(this, (stateVars.TMSalesPaymentList !== undefined ? (stateVars.TMSalesPaymentList?.length > 0 ? stateVars.TMSalesPaymentList[0].remainingEUR : null) : (this.state.TMSalesPaymentList?.length > 0 ? this.state.TMSalesPaymentList[0].remainingEUR : null)));
			stateVars.isComp516757Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, (stateVars.TMSalesPaymentList !== undefined ? (stateVars.TMSalesPaymentList?.length > 0 ? stateVars.TMSalesPaymentList[0].remainingEUR : null) : (this.state.TMSalesPaymentList?.length > 0 ? this.state.TMSalesPaymentList[0].remainingEUR : null))), ReactSystemFunctions.convertToTypeByName("0", "string"))) === true ? "visible" : "hidden")
			this.props.form?.setFieldsValue(formVars);
			
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.FreeSalesWebComponent_389463_onClick1_();
                  resolve();
                });
          })



        
        KuikaAppManager.hideSpinner(this);
        return isErrorOccurred;
    }
		FreeSalesWebComponent_389463_onClick1_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }

				stateVars.Notify = await ReactSystemFunctions.notify(this, ReactSystemFunctions.toString(this, (stateVars.TMSalesPaymentCompletedLine !== undefined ? (stateVars.TMSalesPaymentCompletedLine?.length > 0 ? stateVars.TMSalesPaymentCompletedLine[0].resultMessage : null) : (this.state.TMSalesPaymentCompletedLine?.length > 0 ? this.state.TMSalesPaymentCompletedLine[0].resultMessage : null))), ReactSystemFunctions.convertToTypeByName("default", "string"), ReactSystemFunctions.convertToTypeByName("bottom-right", "string"), 2, ReactSystemFunctions.convertToTypeByName("", "string"), ReactSystemFunctions.convertToTypeByName("", "string"), 0);
				
				stateVars.dataSource_546168 = stateVars.TMSalesPaymentList ?? this.state.TMSalesPaymentList;
				formVars.freesalesweb_806958_value = ReactSystemFunctions.toString(this, (stateVars.TMSalesPaymentList !== undefined ? (stateVars.TMSalesPaymentList?.length > 0 ? stateVars.TMSalesPaymentList[0].collectedTotalEUR : null) : (this.state.TMSalesPaymentList?.length > 0 ? this.state.TMSalesPaymentList[0].collectedTotalEUR : null)));

				formVars.freesalesweb_308158_value = ReactSystemFunctions.toString(this, (stateVars.TMSalesPaymentList !== undefined ? (stateVars.TMSalesPaymentList?.length > 0 ? stateVars.TMSalesPaymentList[0].remainingEUR : null) : (this.state.TMSalesPaymentList?.length > 0 ? this.state.TMSalesPaymentList[0].remainingEUR : null)));


		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

            
            return isErrorOccurred;
        }




    FreeSalesWebComponent_594622_onClick = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
		KuikaAppManager.increaseServerRequestCount();

        let localVar = {
				PaymentId_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, "freesalesweb_546168_value", "paymentId"), "Guid"),
				SalesDraftId_1: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, (stateVars.TMSalesDraftCreate !== undefined ? (stateVars.TMSalesDraftCreate?.length > 0 ? stateVars.TMSalesDraftCreate[0].draftId : null) : (this.state.TMSalesDraftCreate?.length > 0 ? this.state.TMSalesDraftCreate[0].draftId : null))), "Guid")
        }

		KuikaAppManager.showSpinner(this);

            stateVars.Confirm = await ReactSystemFunctions.confirmation(
                ReactSystemFunctions.translateCustomActions(this.ml,"62c43e89_3a75_7b70_d9c2_fe43543a25fa_confirmation",this.defaultML,"Silmek istediğinize emin misiniz?" ),
                "calibri",
                "Bilgi",
                "question",
                "#246dff",
                "",
                ""
            );

            if (stateVars.Confirm)
            {
                		
        if (true) {
        KuikaAppManager.showSpinner(this);
        }
        let result = await KuikaAppManager.ApiRequest(this, "FreeSalesWeb/FreeSalesWebComponent_594622_onClick", localVar)
        if (!KMainFunctions.IsResStatus2XX(result)) return true;

			stateVars.TMSalesPaymentDeleted = result?.data.tmSalesPaymentDeleted;
			stateVars.TMSalesPaymentList = result?.data.tmSalesPaymentList;
			
			formVars.freesalesweb_806958_value = ReactSystemFunctions.toString(this, (stateVars.TMSalesPaymentList !== undefined ? (stateVars.TMSalesPaymentList?.length > 0 ? stateVars.TMSalesPaymentList[0].collectedTotalEUR : null) : (this.state.TMSalesPaymentList?.length > 0 ? this.state.TMSalesPaymentList[0].collectedTotalEUR : null)));
			formVars.freesalesweb_308158_value = ReactSystemFunctions.toString(this, (stateVars.TMSalesPaymentList !== undefined ? (stateVars.TMSalesPaymentList?.length > 0 ? stateVars.TMSalesPaymentList[0].remainingEUR : null) : (this.state.TMSalesPaymentList?.length > 0 ? this.state.TMSalesPaymentList[0].remainingEUR : null)));
			stateVars.isComp516757Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, (stateVars.TMSalesPaymentList !== undefined ? (stateVars.TMSalesPaymentList?.length > 0 ? stateVars.TMSalesPaymentList[0].remainingEUR : null) : (this.state.TMSalesPaymentList?.length > 0 ? this.state.TMSalesPaymentList[0].remainingEUR : null))), ReactSystemFunctions.convertToTypeByName("0", "string"))) === true ? "visible" : "hidden")
			this.props.form?.setFieldsValue(formVars);
			
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.FreeSalesWebComponent_594622_onClick1_();
                  resolve();
                });
          })

            }
            else
            {
                KuikaAppManager.hideSpinner(this);
            }


        
        KuikaAppManager.hideSpinner(this);
        return isErrorOccurred;
    }
		FreeSalesWebComponent_594622_onClick1_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }

				stateVars.Notify = await ReactSystemFunctions.notify(this, ReactSystemFunctions.toString(this, (stateVars.TMSalesPaymentDeleted !== undefined ? (stateVars.TMSalesPaymentDeleted?.length > 0 ? stateVars.TMSalesPaymentDeleted[0].message : null) : (this.state.TMSalesPaymentDeleted?.length > 0 ? this.state.TMSalesPaymentDeleted[0].message : null))), ReactSystemFunctions.convertToTypeByName("default", "string"), ReactSystemFunctions.convertToTypeByName("bottom-right", "string"), 2, ReactSystemFunctions.convertToTypeByName("", "string"), ReactSystemFunctions.convertToTypeByName("", "string"), 0);
				
				stateVars.dataSource_546168 = stateVars.TMSalesPaymentList ?? this.state.TMSalesPaymentList;
				formVars.freesalesweb_806958_value = ReactSystemFunctions.toString(this, (stateVars.TMSalesPaymentList !== undefined ? (stateVars.TMSalesPaymentList?.length > 0 ? stateVars.TMSalesPaymentList[0].collectedTotalEUR : null) : (this.state.TMSalesPaymentList?.length > 0 ? this.state.TMSalesPaymentList[0].collectedTotalEUR : null)));

				formVars.freesalesweb_308158_value = ReactSystemFunctions.toString(this, (stateVars.TMSalesPaymentList !== undefined ? (stateVars.TMSalesPaymentList?.length > 0 ? stateVars.TMSalesPaymentList[0].remainingEUR : null) : (this.state.TMSalesPaymentList?.length > 0 ? this.state.TMSalesPaymentList[0].remainingEUR : null)));


		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

            
            return isErrorOccurred;
        }




    FreeSalesWebComponent_519542_onClick = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
		KuikaAppManager.increaseServerRequestCount();

        let localVar = {
				DraftId_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, (stateVars.TMSalesDraftCreate !== undefined ? (stateVars.TMSalesDraftCreate?.length > 0 ? stateVars.TMSalesDraftCreate[0].draftId : null) : (this.state.TMSalesDraftCreate?.length > 0 ? this.state.TMSalesDraftCreate[0].draftId : null))), "Guid"),
				DraftId_1: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, (stateVars.TMSalesDraftCreate !== undefined ? (stateVars.TMSalesDraftCreate?.length > 0 ? stateVars.TMSalesDraftCreate[0].draftId : null) : (this.state.TMSalesDraftCreate?.length > 0 ? this.state.TMSalesDraftCreate[0].draftId : null))), "Guid"),
				DraftId_2: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, (stateVars.TMSalesDraftCreate !== undefined ? (stateVars.TMSalesDraftCreate?.length > 0 ? stateVars.TMSalesDraftCreate[0].draftId : null) : (this.state.TMSalesDraftCreate?.length > 0 ? this.state.TMSalesDraftCreate[0].draftId : null))), "Guid")
        }

		KuikaAppManager.showSpinner(this);
		
        if (true) {
        KuikaAppManager.showSpinner(this);
        }
        let result = await KuikaAppManager.ApiRequest(this, "FreeSalesWeb/FreeSalesWebComponent_519542_onClick", localVar)
        if (!KMainFunctions.IsResStatus2XX(result)) return true;

			stateVars.TM_GetDirectSalesDraftForPost = result?.data.tM_GetDirectSalesDraftForPost;
			stateVars.TM_GetDirectSalesDraftDetailForPost = result?.data.tM_GetDirectSalesDraftDetailForPost;
			stateVars.TM_GetDirectSalesDraftPaymentForPost = result?.data.tM_GetDirectSalesDraftPaymentForPost;
			this.props.form?.setFieldsValue(formVars);
			this.setState(stateVars);
			KuikaAppManager.hideSpinner(this);



        this.setPageInitLoaded(true);
        KuikaAppManager.hideSpinner(this);
        return isErrorOccurred;
    }



		FreeSalesWebComponent_911320_onChange = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
KuikaAppManager.showSpinner(this);

				stateVars.isComp110781Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "freesalesweb_911320_value", "value", "", "key", "")), ReactSystemFunctions.convertToTypeByName("2", "string"))) === true ? "visible" : "hidden")
				stateVars.isComp170951Visible = (((ReactSystemFunctions.isNotEmpty(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "freesalesweb_560284_value", "value", "TM_GetCustomerByName", "id", "id")), ReactSystemFunctions.convertToTypeByName("True", "string")) && ReactSystemFunctions.isNotEmpty(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "freesalesweb_911320_value", "value", "", "key", "")), ReactSystemFunctions.convertToTypeByName("True", "string")))) === true ? "visible" : "hidden")

		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

            
            return isErrorOccurred;
        }


		FreeSalesWebComponent_115957_onChange = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
KuikaAppManager.showSpinner(this);

				ReactSystemFunctions.setValueOf(this, "freesalesweb_667342_value", ReactSystemFunctions.value(this, "freesalesweb_115957_value", "value"), "disablebeforedate");


		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

            
            return isErrorOccurred;
        }




    async callCallbackFunction(diId: number, isFromMaster: boolean = false) {
        let isErrorOccurred = false;
		let pageInitCallerNavDiIDs = [] as number[];
		if (isFromMaster || pageInitCallerNavDiIDs.indexOf(diId) > -1) {
			await this.FreeSalesWebPageInit();
		}

    }


}
