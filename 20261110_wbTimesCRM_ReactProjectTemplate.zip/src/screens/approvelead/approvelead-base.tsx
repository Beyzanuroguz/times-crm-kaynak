import React from "react";
import Axios, { AxiosResponse } from "axios";
import { KuikaAppManager } from "../../shared/utilty/kuika-app-manager";
import { ReactSystemFunctions } from "../../shared/utilty/react-system-functions";
import { KNavigator } from "../../shared/hoc/with-history";
import { KContext } from "../../shared/hoc/with-context";
import { useLocation } from "react-router-dom";
import { FormInstance } from "antd/es/form";
import { Guid } from "guid-typescript";
import Swal from "sweetalert2";
import { KMainFunctions } from "../../shared/utilty/main-functions";
import moment from "moment";
import { IValidationData } from "../../models/dto/validation-data";
import { IStripePayment } from "../../models/dto/stripe-payment";
import { IUserInfoDto } from "../../models/dto/user-info.dto";
import { UserService } from "../../services/user-service";
import { kuikaCoreWasmBridgeService } from "../../services/_singletons";
import _ from "lodash";
import mqtt, { MqttClient } from "mqtt";
import { IMqttResult } from "../../models/dto/mqtt.dto";


declare let window: any;

export interface IApproveLead_ScreenProps {
  navigator: KNavigator;
  form: FormInstance<any>;
  googleLogin: any;
  screenInputs: any;
  context: KContext;
  initialValues: any;
  children: any;
}

export interface IApproveLead_ScreenState {
    isSpinnerVisible: boolean;
    isPageVisible: boolean;
	isLeftMenuVisible: boolean;
    spinnerCount: number;
    selectedLanguage: string;
    isPageInitLoaded: false;
    isPageRecurringLoaded: false;
	TM_GetLeadById: any[];
	TM_GetLeadById_dummy: any[];
	TM_GetProductById: any[];
	TM_GetProductById_dummy: any[];
	TM_GetProductLeadHistory: any[];
	TM_GetProductLeadHistory_dummy: any[];
	TM_GetCustomerLeadHistory: any[];
	TM_GetCustomerLeadHistory_dummy: any[];
	TM_GetEstimatedDateByYearMonth: any[];
	TM_GetEstimatedDateByYearMonth_dummy: any[];
	TM_LeadCheckCustomerProduct: any[];
	TM_LeadCheckCustomerProduct_dummy: any[];
	TMLeadSuggestion: any[];
	TMLeadSuggestion_dummy: any[];
	NAVIGATE: any;
	NAVIGATE_dummy: any;
	ChangeVisibilityOf: string;
	ChangeVisibilityOf_dummy: string;
	TM_CreateLeadApproveLog: any[];
	TM_CreateLeadApproveLog_dummy: any[];
	Notify: boolean;
	Notify_dummy: boolean;
	GoBack: any;
	GoBack_dummy: any;
	isComp815552Visible: 'visible' | 'hidden';
	isComp978479Visible: 'visible' | 'hidden';
	isComp296286Visible: 'visible' | 'hidden';
	isComp657542Visible: 'visible' | 'hidden';
	isComp258408Visible: 'visible' | 'hidden';
	isComp812280Visible: 'visible' | 'hidden';
	isComp616857Visible: 'visible' | 'hidden';
	isComp521955Visible: 'visible' | 'hidden';
	isComp260039Visible: 'visible' | 'hidden';
	isComp380484Visible: 'visible' | 'hidden';
	isComp58148Visible: 'visible' | 'hidden';
	isComp931151Visible: 'visible' | 'hidden';
	isComp93515Visible: 'visible' | 'hidden';
	isComp34170Visible: 'visible' | 'hidden';
	isComp504771Visible: 'visible' | 'hidden';
	isComp506199Visible: 'visible' | 'hidden';
	isComp287327Visible: 'visible' | 'hidden';
	isComp760071Visible: 'visible' | 'hidden';
	isComp744003Visible: 'visible' | 'hidden';
	isComp710304Visible: 'visible' | 'hidden';
	isComp490394Visible: 'visible' | 'hidden';
	isComp929834Visible: 'visible' | 'hidden';
	isComp677828Visible: 'visible' | 'hidden';
	isComp113424Visible: 'visible' | 'hidden';
	isComp399539Visible: 'visible' | 'hidden';
	isComp754674Visible: 'visible' | 'hidden';
	isComp152758Visible: 'visible' | 'hidden';
	isComp119069Visible: 'visible' | 'hidden';
	isComp280572Visible: 'visible' | 'hidden';
	isComp93103Visible: 'visible' | 'hidden';
	isComp635267Visible: 'visible' | 'hidden';
	isComp543686Visible: 'visible' | 'hidden';
	isComp165648Visible: 'visible' | 'hidden';

}

export class ApproveLead_ScreenBase extends React.PureComponent<IApproveLead_ScreenProps, any> {

	approvelead_970463_value_kuikaTableRef: React.RefObject<any>;
	approvelead_439626_value_kuikaTableRef: React.RefObject<any>;
	approvelead_273338_value_kuikaSelectBoxRef: React.RefObject<any>;
	approvelead_87086_value_kuikaSelectBoxRef: React.RefObject<any>;
    ml=[{"Id":"d5a61d2b-bd60-485f-86e2-661e9ed4e486","Name":"en_US","ShortName":"English","IsDefault":true,"LanguagePhrases":[]},{"Id":"4944702a-1b6b-4046-a8ae-5d097a6e9c08","Name":"FixedValues","ShortName":"FixedValues","LanguagePhrases":[{"Id":636484,"PropertyName":"value","Value":"Talep Onayla"},{"Id":519156,"PropertyName":"value","Value":"Talep Bilgileri"},{"Id":72184,"PropertyName":"value","Value":"Talep Numarası"},{"Id":290304,"PropertyName":"value","Value":"Talep Tarihi"},{"Id":534971,"PropertyName":"value","Value":"Mağaza"},{"Id":3871,"PropertyName":"value","Value":"Ürün"},{"Id":746305,"PropertyName":"value","Value":"Müşteri"},{"Id":904342,"PropertyName":"value","Value":"Müşteri Telefon No"},{"Id":218628,"PropertyName":"value","Value":"Müşteri İnfo"},{"Id":285579,"PropertyName":"value","Value":"Alışveriş Var Mı ?"},{"Id":616857,"PropertyName":"value","Value":"Evet"},{"Id":521955,"PropertyName":"value","Value":"Hayır"},{"Id":46376,"PropertyName":"value","Value":"Model"},{"Id":380484,"PropertyName":"value","Value":"-"},{"Id":638024,"PropertyName":"value","Value":"Referans Notu"},{"Id":490188,"PropertyName":"value","Value":"Bu Ürüne Ait Geçmiş Talepler"},{"Id":970463,"PropertyName":"nodatafoundmessage","Value":"Bu ürüne ait geçmiş talep bulunmamaktadır."},{"Id":296681,"PropertyName":"title","Value":"Talep Kodu"},{"Id":427073,"PropertyName":"value","Value":"[datafield:leadcode]"},{"Id":491508,"PropertyName":"title","Value":"Talep Tarihi"},{"Id":14671,"PropertyName":"value","Value":"[datafield:talepolusturmatarihi]"},{"Id":683905,"PropertyName":"title","Value":"Müşteri"},{"Id":432843,"PropertyName":"value","Value":"[datafield:musteri]"},{"Id":906581,"PropertyName":"title","Value":"Lokasyon"},{"Id":262478,"PropertyName":"value","Value":"[datafield:cityname]"},{"Id":120149,"PropertyName":"title","Value":"Mağaza"},{"Id":317724,"PropertyName":"value","Value":"[datafield:magaza]"},{"Id":754678,"PropertyName":"title","Value":"Lead Durumu"},{"Id":58148,"PropertyName":"value","Value":"[datafield:leaddurumu]"},{"Id":931151,"PropertyName":"value","Value":"[datafield:leaddurumu]"},{"Id":699419,"PropertyName":"title","Value":"Onay Durumu"},{"Id":93515,"PropertyName":"value","Value":"[datafield:processname]"},{"Id":34170,"PropertyName":"value","Value":"[datafield:processname]"},{"Id":504771,"PropertyName":"value","Value":"[datafield:processname]"},{"Id":506199,"PropertyName":"value","Value":"[datafield:processname]"},{"Id":287327,"PropertyName":"value","Value":"[datafield:processname]"},{"Id":760071,"PropertyName":"value","Value":"[datafield:processname]"},{"Id":744003,"PropertyName":"value","Value":"Red Notu"},{"Id":710304,"PropertyName":"value","Value":"[datafield:leadrejectednote]"},{"Id":140429,"PropertyName":"title","Value":"Termin Süresi"},{"Id":841282,"PropertyName":"value","Value":"[datafield:estimateddate]"},{"Id":329626,"PropertyName":"title","Value":"Lead'e Git"},{"Id":476603,"PropertyName":"value","Value":"Bu Müşteriye Ait Geçmiş Talepler"},{"Id":439626,"PropertyName":"nodatafoundmessage","Value":"Bu müşteriye ait geçmiş talep bulunmamaktadır."},{"Id":362947,"PropertyName":"title","Value":"Talep Kodu"},{"Id":672831,"PropertyName":"value","Value":"[datafield:talepkodu]"},{"Id":422452,"PropertyName":"title","Value":"Talep Tarihi"},{"Id":494756,"PropertyName":"value","Value":"[datafield:talepolusturmatarihi]"},{"Id":418928,"PropertyName":"title","Value":"Model"},{"Id":919528,"PropertyName":"value","Value":"[datafield:productrefno]"},{"Id":521818,"PropertyName":"title","Value":"Mağaza"},{"Id":420464,"PropertyName":"value","Value":"[datafield:magaza]"},{"Id":969297,"PropertyName":"title","Value":"Lead Durumu"},{"Id":490394,"PropertyName":"value","Value":"[datafield:leaddurumu]"},{"Id":929834,"PropertyName":"value","Value":"[datafield:leaddurumu]"},{"Id":763125,"PropertyName":"title","Value":"Onay Durumu"},{"Id":677828,"PropertyName":"value","Value":"[datafield:processname]"},{"Id":113424,"PropertyName":"value","Value":"[datafield:processname]"},{"Id":399539,"PropertyName":"value","Value":"[datafield:processname]"},{"Id":754674,"PropertyName":"value","Value":"[datafield:processname]"},{"Id":152758,"PropertyName":"value","Value":"[datafield:processname]"},{"Id":119069,"PropertyName":"value","Value":"[datafield:processname]"},{"Id":280572,"PropertyName":"value","Value":"Red Notu"},{"Id":93103,"PropertyName":"value","Value":"[datafield:leadrejectednote]"},{"Id":702219,"PropertyName":"title","Value":"Termin Süresi"},{"Id":23366,"PropertyName":"value","Value":"[datafield:estimateddate]"},{"Id":515751,"PropertyName":"title","Value":"Lead'e Git"},{"Id":940388,"PropertyName":"value","Value":"Dikkat! Açık Talep Mevcut"},{"Id":584731,"PropertyName":"value","Value":"Bu müşterinin açık bir talebi bulunmaktadır. Devam etmeden önce lütfen kontrol ediniz."},{"Id":668878,"PropertyName":"value","Value":"Tahmini Teslimat Belirle"},{"Id":273338,"PropertyName":"placeholder","Value":"Yıl"},{"Id":87086,"PropertyName":"placeholder","Value":"Ay"},{"Id":121781,"PropertyName":"label","Value":"Talebi Onayla"},{"Id":988256,"PropertyName":"label","Value":"Talebi Reddet"}]}]
    defaultML = "en_US"
    
    screenHash = ""
    


    constructor(props) {
        super(props);
		this.approvelead_970463_value_kuikaTableRef = React.createRef();
		this.approvelead_439626_value_kuikaTableRef = React.createRef();
		this.approvelead_273338_value_kuikaSelectBoxRef = React.createRef();
		this.approvelead_87086_value_kuikaSelectBoxRef = React.createRef();

        this.state = {
            isSpinnerVisible: false,
            isPageVisible: false,
            isLeftMenuVisible: false,
            spinnerCount: 0,
            selectedLanguage: "",
            isPageInitLoaded: false,
            isPageRecurringLoaded: false,
            	        TM_GetLeadById: [],
	        TM_GetProductById: [],
	        TM_GetProductLeadHistory: [],
	        TM_GetCustomerLeadHistory: [],
	        TM_GetEstimatedDateByYearMonth: [],
	        TM_LeadCheckCustomerProduct: [],
	        TMLeadSuggestion: [],
	        NAVIGATE: "",
	        ChangeVisibilityOf: "",
	        TM_CreateLeadApproveLog: [],
	        Notify: false,
	        GoBack: "",
	        dataSource_273338: [{"key":"2026","text":"2026"},{"key":"2027","text":"2027"},{"key":"2028","text":"2028"},{"key":"2029","text":"2029"},{"key":"2030","text":"2030"},{"key":"2031","text":"2031"},{"key":"2032","text":"2032"},{"key":"2033","text":"2033"},{"key":"2034","text":"2034"},{"key":"2035","text":"2035"},{"key":"2036","text":"2036"}],
	        dataSource_87086: [{"key":"1","text":"Ocak"},{"key":"2","text":"Şubat"},{"key":"3","text":"Mart"},{"key":"4","text":"Nisan"},{"key":"5","text":"Mayıs"},{"key":"6","text":"Haziran"},{"key":"7","text":"Temmuz"},{"key":"8","text":"Ağustos"},{"key":"9","text":"Eylül"},{"key":"10","text":"Ekim"},{"key":"11","text":"Kasım"},{"key":"12","text":"Aralık"}],
	        isComp815552Visible: 'visible',
	        isComp978479Visible: 'hidden',
	        isComp296286Visible: 'visible',
	        isComp657542Visible: 'visible',
	        isComp258408Visible: 'visible',
	        isComp812280Visible: 'hidden',
	        isComp616857Visible: 'hidden',
	        isComp521955Visible: 'hidden',
	        isComp260039Visible: 'hidden',
	        isComp380484Visible: 'hidden',
	        isComp58148Visible: 'hidden',
	        isComp931151Visible: 'hidden',
	        isComp93515Visible: 'hidden',
	        isComp34170Visible: 'hidden',
	        isComp504771Visible: 'hidden',
	        isComp506199Visible: 'hidden',
	        isComp287327Visible: 'hidden',
	        isComp760071Visible: 'hidden',
	        isComp744003Visible: 'hidden',
	        isComp710304Visible: 'hidden',
	        isComp490394Visible: 'hidden',
	        isComp929834Visible: 'hidden',
	        isComp677828Visible: 'hidden',
	        isComp113424Visible: 'hidden',
	        isComp399539Visible: 'hidden',
	        isComp754674Visible: 'hidden',
	        isComp152758Visible: 'hidden',
	        isComp119069Visible: 'hidden',
	        isComp280572Visible: 'hidden',
	        isComp93103Visible: 'hidden',
	        isComp635267Visible: 'hidden',
	        isComp543686Visible: 'hidden',
	        isComp165648Visible: 'hidden',

        }

        this.CheckPageAuthorization(this.state);

        
    }

    async componentDidMount() {

        if (KuikaAppManager.isPageInitPrevented()) {
            KuikaAppManager.calculateAndSetBodyHeight("approvelead", "");
            return;
        }
        
        
        ReactSystemFunctions.validateToken()
        this.fillFormInitValues();
        if (true){
            await this.ApproveLeadPageInit();
        }
        
        
        
        KuikaAppManager.calculateAndSetBodyHeight("approvelead", "");

        if (ReactSystemFunctions.getIsMicroApp() === false) {
           window.parentScreen = this;
        }
    }

    componentWillUnmount() {
        
        
        

        if (ReactSystemFunctions.getIsMicroApp() === false) {
           window.parentScreen = null;
        }
    }

    
              CheckPageAuthorization = async (state) => {
                KuikaAppManager.showSpinner(this);
                if (_.isEmpty(window.userInfo)) {
                  await UserService.GetUserInfoForce();
                }
                const permittedRoleNames: string[] = ["TimesYonetici","TimesUstYonetici","TimesMagazaMuduru",];
                const userInfo = window.userInfo as IUserInfoDto;
                const userRoleNames = userInfo.roles.map((role) => role.name);
                if (!ReactSystemFunctions.hasAnyRoleName(permittedRoleNames, userRoleNames)) {
                  await ReactSystemFunctions.goBack(this);

                  const language = localStorage.getItem("ml");
                  let permissonErrorMessageText = "You do not have permission to access this page.";
                  if (language === "tr_TR") {
                    permissonErrorMessageText = "Bu sayfaya erişim yetkiniz yok.";
                  } else if (language === "fr_FR") {
                    permissonErrorMessageText = "Vous n'avez pas la permission d'accéder à cette page.";
                  } else if (language === "de_DE") {
                    permissonErrorMessageText = "Sie haben keine Berechtigung, auf diese Seite zuzugreifen.";
                  } else if (language === "es_ES") {
                    permissonErrorMessageText = "No tienes permiso para acceder a esta página.";
                  }

                  KMainFunctions.displayErrorNotification(permissonErrorMessageText);
                  state.isPageVisible = false;
                  KuikaAppManager.hideSpinner(this);
                  return;
                }
                state.isPageVisible = true;
                KuikaAppManager.hideSpinner(this);
              };
        

        
    componentDidUpdate= async (prevProps, prevState) => {
		KuikaAppManager.calculateAndSetBodyHeight("approvelead", ""    );
        if (prevProps?.location?.search !== (this.props as any)?.location?.search) {
			await this.ApproveLeadPageInit();
		}

        

        if (ReactSystemFunctions.getIsMicroApp() === false) {
            for (const key in prevState) {
                if (key.startsWith('NavVisible') && prevState[key] === true && this.state[key] === false) {
                    window.parentScreen = this;
                    break;
                }
            }
        }
	}

    fillFormInitValues() {
        this.props.form?.setFieldsValue({
approvelead_273338_value: this.state.TM_GetLeadById?.at?.(0)?.terminYil ?? undefined,
approvelead_87086_value: this.state.TM_GetLeadById?.at?.(0)?.terminAyValue ?? undefined
});

    }

      setPageInitLoaded = (value: boolean) => {
        this.setState({ isPageInitLoaded: value });
      }

      setPageRecurringLoaded = (value: boolean) => {
        this.setState({ isPageRecurringLoaded: value });
      }

      clearFieldValidation = (changedValues: any) => {
        const fieldName = Object.keys(changedValues)[0];
        if (fieldName) {
          this.props.form?.setFields([
            {
              name: fieldName,
              errors: []
            }
          ]);
        }
      };

      

    ApproveLeadPageInit = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


	if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }

        let localVar = {
			LeadId_0: ReactSystemFunctions.convertToTypeByName(this.props.screenInputs.LeadId ?? this.props.screenInputs.leadid, "Guid"),
			ProductId_1: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, (stateVars.TM_GetLeadById !== undefined ? (stateVars.TM_GetLeadById?.length > 0 ? stateVars.TM_GetLeadById[0].productId : null) : (this.state.TM_GetLeadById?.length > 0 ? this.state.TM_GetLeadById[0].productId : null))), "Guid"),
			ProductId_2: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, (stateVars.TM_GetLeadById !== undefined ? (stateVars.TM_GetLeadById?.length > 0 ? stateVars.TM_GetLeadById[0].productId : null) : (this.state.TM_GetLeadById?.length > 0 ? this.state.TM_GetLeadById[0].productId : null))), "Guid"),
			LeadId_2: ReactSystemFunctions.convertToTypeByName(this.props.screenInputs.LeadId ?? this.props.screenInputs.leadid, "Guid"),
			CustomerId_3: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, (stateVars.TM_GetLeadById !== undefined ? (stateVars.TM_GetLeadById?.length > 0 ? stateVars.TM_GetLeadById[0].customerId : null) : (this.state.TM_GetLeadById?.length > 0 ? this.state.TM_GetLeadById[0].customerId : null))), "Guid"),
			LeadId_3: ReactSystemFunctions.convertToTypeByName(this.props.screenInputs.LeadId ?? this.props.screenInputs.leadid, "Guid"),
			InputYear_4: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toInteger(this, ReactSystemFunctions.value(this, "approvelead_273338_value", "value", "", "key", "")), "number"),
			InputMonth_4: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toInteger(this, ReactSystemFunctions.value(this, "approvelead_87086_value", "value", "", "key", "")), "number"),
			CustomerId_5: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, (stateVars.TM_GetLeadById !== undefined ? (stateVars.TM_GetLeadById?.length > 0 ? stateVars.TM_GetLeadById[0].customerId : null) : (this.state.TM_GetLeadById?.length > 0 ? this.state.TM_GetLeadById[0].customerId : null))), "Guid"),
			LeadId_6: ReactSystemFunctions.convertToTypeByName(this.props.screenInputs.LeadId ?? this.props.screenInputs.leadid, "Guid")
        }

	KuikaAppManager.showSpinner(this);
	
        if (true) {
        KuikaAppManager.showSpinner(this);
        }
        let result = await KuikaAppManager.ApiRequest(this, "ApproveLead/ApproveLeadPageInit", localVar)
        if (!KMainFunctions.IsResStatus2XX(result)) return true;

		stateVars.TM_GetLeadById = result?.data.tM_GetLeadById;
		formVars.approvelead_844808_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadById !== undefined ? (stateVars.TM_GetLeadById?.length > 0 ? stateVars.TM_GetLeadById[0].leadCode : null) : (this.state.TM_GetLeadById?.length > 0 ? this.state.TM_GetLeadById[0].leadCode : null)));
		formVars.approvelead_530144_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadById !== undefined ? (stateVars.TM_GetLeadById?.length > 0 ? stateVars.TM_GetLeadById[0].talepOlusturmaTarihi : null) : (this.state.TM_GetLeadById?.length > 0 ? this.state.TM_GetLeadById[0].talepOlusturmaTarihi : null)));
		formVars.approvelead_837508_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadById !== undefined ? (stateVars.TM_GetLeadById?.length > 0 ? stateVars.TM_GetLeadById[0].magaza : null) : (this.state.TM_GetLeadById?.length > 0 ? this.state.TM_GetLeadById[0].magaza : null)));
		formVars.approvelead_226243_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadById !== undefined ? (stateVars.TM_GetLeadById?.length > 0 ? stateVars.TM_GetLeadById[0].urunAdi : null) : (this.state.TM_GetLeadById?.length > 0 ? this.state.TM_GetLeadById[0].urunAdi : null)));
		formVars.approvelead_889084_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadById !== undefined ? (stateVars.TM_GetLeadById?.length > 0 ? stateVars.TM_GetLeadById[0].musteriAdi : null) : (this.state.TM_GetLeadById?.length > 0 ? this.state.TM_GetLeadById[0].musteriAdi : null)));
		formVars.approvelead_323303_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadById !== undefined ? (stateVars.TM_GetLeadById?.length > 0 ? stateVars.TM_GetLeadById[0].telefonNo : null) : (this.state.TM_GetLeadById?.length > 0 ? this.state.TM_GetLeadById[0].telefonNo : null)));
		formVars.approvelead_946275_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadById !== undefined ? (stateVars.TM_GetLeadById?.length > 0 ? stateVars.TM_GetLeadById[0].musteriInfo : null) : (this.state.TM_GetLeadById?.length > 0 ? this.state.TM_GetLeadById[0].musteriInfo : null)));
		formVars.approvelead_260039_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadById !== undefined ? (stateVars.TM_GetLeadById?.length > 0 ? stateVars.TM_GetLeadById[0].referansAdi : null) : (this.state.TM_GetLeadById?.length > 0 ? this.state.TM_GetLeadById[0].referansAdi : null)));
		formVars.approvelead_31979_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadById !== undefined ? (stateVars.TM_GetLeadById?.length > 0 ? stateVars.TM_GetLeadById[0].referansNote : null) : (this.state.TM_GetLeadById?.length > 0 ? this.state.TM_GetLeadById[0].referansNote : null)));
		formVars.approvelead_295697_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadById !== undefined ? (stateVars.TM_GetLeadById?.length > 0 ? stateVars.TM_GetLeadById[0].urunAdi : null) : (this.state.TM_GetLeadById?.length > 0 ? this.state.TM_GetLeadById[0].urunAdi : null)));
		formVars.approvelead_308186_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadById !== undefined ? (stateVars.TM_GetLeadById?.length > 0 ? stateVars.TM_GetLeadById[0].musteriAdi : null) : (this.state.TM_GetLeadById?.length > 0 ? this.state.TM_GetLeadById[0].musteriAdi : null)));
		formVars.approvelead_273338_value = (stateVars.TM_GetLeadById !== undefined ? (stateVars.TM_GetLeadById?.length > 0 ? stateVars.TM_GetLeadById[0].terminYil : null) : (this.state.TM_GetLeadById?.length > 0 ? this.state.TM_GetLeadById[0].terminYil : null));
		formVars.approvelead_87086_value = (stateVars.TM_GetLeadById !== undefined ? (stateVars.TM_GetLeadById?.length > 0 ? stateVars.TM_GetLeadById[0].terminAyValue : null) : (this.state.TM_GetLeadById?.length > 0 ? this.state.TM_GetLeadById[0].terminAyValue : null));
		stateVars.isComp616857Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, (stateVars.TM_GetLeadById !== undefined ? (stateVars.TM_GetLeadById?.length > 0 ? stateVars.TM_GetLeadById[0].alisverisYaptiMi : null) : (this.state.TM_GetLeadById?.length > 0 ? this.state.TM_GetLeadById[0].alisverisYaptiMi : null))), ReactSystemFunctions.convertToTypeByName("True", "string"))) === true ? "visible" : "hidden")
		stateVars.isComp521955Visible = ((ReactSystemFunctions.isNotEqualTo(ReactSystemFunctions.value(this, (stateVars.TM_GetLeadById !== undefined ? (stateVars.TM_GetLeadById?.length > 0 ? stateVars.TM_GetLeadById[0].alisverisYaptiMi : null) : (this.state.TM_GetLeadById?.length > 0 ? this.state.TM_GetLeadById[0].alisverisYaptiMi : null))), ReactSystemFunctions.convertToTypeByName("True", "string"))) === true ? "visible" : "hidden")
		stateVars.isComp260039Visible = ((ReactSystemFunctions.isNotEmpty(ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadById !== undefined ? (stateVars.TM_GetLeadById?.length > 0 ? stateVars.TM_GetLeadById[0].referansAdi : null) : (this.state.TM_GetLeadById?.length > 0 ? this.state.TM_GetLeadById[0].referansAdi : null))), ReactSystemFunctions.convertToTypeByName("True", "string"))) === true ? "visible" : "hidden")
		stateVars.isComp380484Visible = ((ReactSystemFunctions.isEmpty(ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadById !== undefined ? (stateVars.TM_GetLeadById?.length > 0 ? stateVars.TM_GetLeadById[0].referansAdi : null) : (this.state.TM_GetLeadById?.length > 0 ? this.state.TM_GetLeadById[0].referansAdi : null))), ReactSystemFunctions.convertToTypeByName("True", "string"))) === true ? "visible" : "hidden")
		stateVars.TM_GetProductById = result?.data.tM_GetProductById;
		stateVars.TM_GetProductLeadHistory = result?.data.tM_GetProductLeadHistory;
		
		stateVars.TM_GetCustomerLeadHistory = result?.data.tM_GetCustomerLeadHistory;
		
		stateVars.TM_GetEstimatedDateByYearMonth = result?.data.tM_GetEstimatedDateByYearMonth;
		stateVars.TM_LeadCheckCustomerProduct = result?.data.tM_LeadCheckCustomerProduct;
		stateVars.isComp543686Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, (stateVars.TM_LeadCheckCustomerProduct !== undefined ? (stateVars.TM_LeadCheckCustomerProduct?.length > 0 ? stateVars.TM_LeadCheckCustomerProduct[0].leadExists : null) : (this.state.TM_LeadCheckCustomerProduct?.length > 0 ? this.state.TM_LeadCheckCustomerProduct[0].leadExists : null))), ReactSystemFunctions.convertToTypeByName("True", "string"))) === true ? "visible" : "hidden")
		stateVars.TMLeadSuggestion = result?.data.tmLeadSuggestion;
		formVars.approvelead_809951_value = ReactSystemFunctions.toString(this, (stateVars.TMLeadSuggestion !== undefined ? (stateVars.TMLeadSuggestion?.length > 0 ? stateVars.TMLeadSuggestion[0].terminOneriText : null) : (this.state.TMLeadSuggestion?.length > 0 ? this.state.TMLeadSuggestion[0].terminOneriText : null)));
		stateVars.isComp165648Visible = ((ReactSystemFunctions.isNotEmpty(ReactSystemFunctions.toString(this, (stateVars.TMLeadSuggestion !== undefined ? (stateVars.TMLeadSuggestion?.length > 0 ? stateVars.TMLeadSuggestion[0].terminOneriText : null) : (this.state.TMLeadSuggestion?.length > 0 ? this.state.TMLeadSuggestion[0].terminOneriText : null))), ReactSystemFunctions.convertToTypeByName("True", "string"))) === true ? "visible" : "hidden")
		this.props.form?.setFieldsValue(formVars);
		
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.ApproveLeadPageInit1_();
                  resolve();
                });
          })



        
        KuikaAppManager.hideSpinner(this);
        return isErrorOccurred;
    }
	ApproveLeadPageInit1_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


	if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }

			formVars.approvelead_844808_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadById !== undefined ? (stateVars.TM_GetLeadById?.length > 0 ? stateVars.TM_GetLeadById[0].leadCode : null) : (this.state.TM_GetLeadById?.length > 0 ? this.state.TM_GetLeadById[0].leadCode : null)));

			formVars.approvelead_530144_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadById !== undefined ? (stateVars.TM_GetLeadById?.length > 0 ? stateVars.TM_GetLeadById[0].talepOlusturmaTarihi : null) : (this.state.TM_GetLeadById?.length > 0 ? this.state.TM_GetLeadById[0].talepOlusturmaTarihi : null)));

			formVars.approvelead_837508_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadById !== undefined ? (stateVars.TM_GetLeadById?.length > 0 ? stateVars.TM_GetLeadById[0].magaza : null) : (this.state.TM_GetLeadById?.length > 0 ? this.state.TM_GetLeadById[0].magaza : null)));

			formVars.approvelead_226243_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadById !== undefined ? (stateVars.TM_GetLeadById?.length > 0 ? stateVars.TM_GetLeadById[0].urunAdi : null) : (this.state.TM_GetLeadById?.length > 0 ? this.state.TM_GetLeadById[0].urunAdi : null)));

			formVars.approvelead_889084_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadById !== undefined ? (stateVars.TM_GetLeadById?.length > 0 ? stateVars.TM_GetLeadById[0].musteriAdi : null) : (this.state.TM_GetLeadById?.length > 0 ? this.state.TM_GetLeadById[0].musteriAdi : null)));

			formVars.approvelead_323303_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadById !== undefined ? (stateVars.TM_GetLeadById?.length > 0 ? stateVars.TM_GetLeadById[0].telefonNo : null) : (this.state.TM_GetLeadById?.length > 0 ? this.state.TM_GetLeadById[0].telefonNo : null)));

			formVars.approvelead_946275_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadById !== undefined ? (stateVars.TM_GetLeadById?.length > 0 ? stateVars.TM_GetLeadById[0].musteriInfo : null) : (this.state.TM_GetLeadById?.length > 0 ? this.state.TM_GetLeadById[0].musteriInfo : null)));

			stateVars.isComp616857Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, (stateVars.TM_GetLeadById !== undefined ? (stateVars.TM_GetLeadById?.length > 0 ? stateVars.TM_GetLeadById[0].alisverisYaptiMi : null) : (this.state.TM_GetLeadById?.length > 0 ? this.state.TM_GetLeadById[0].alisverisYaptiMi : null))), ReactSystemFunctions.convertToTypeByName("True", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp521955Visible = ((ReactSystemFunctions.isNotEqualTo(ReactSystemFunctions.value(this, (stateVars.TM_GetLeadById !== undefined ? (stateVars.TM_GetLeadById?.length > 0 ? stateVars.TM_GetLeadById[0].alisverisYaptiMi : null) : (this.state.TM_GetLeadById?.length > 0 ? this.state.TM_GetLeadById[0].alisverisYaptiMi : null))), ReactSystemFunctions.convertToTypeByName("True", "string"))) === true ? "visible" : "hidden")
			formVars.approvelead_260039_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadById !== undefined ? (stateVars.TM_GetLeadById?.length > 0 ? stateVars.TM_GetLeadById[0].referansAdi : null) : (this.state.TM_GetLeadById?.length > 0 ? this.state.TM_GetLeadById[0].referansAdi : null)));

			stateVars.isComp260039Visible = ((ReactSystemFunctions.isNotEmpty(ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadById !== undefined ? (stateVars.TM_GetLeadById?.length > 0 ? stateVars.TM_GetLeadById[0].referansAdi : null) : (this.state.TM_GetLeadById?.length > 0 ? this.state.TM_GetLeadById[0].referansAdi : null))), ReactSystemFunctions.convertToTypeByName("True", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp380484Visible = ((ReactSystemFunctions.isEmpty(ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadById !== undefined ? (stateVars.TM_GetLeadById?.length > 0 ? stateVars.TM_GetLeadById[0].referansAdi : null) : (this.state.TM_GetLeadById?.length > 0 ? this.state.TM_GetLeadById[0].referansAdi : null))), ReactSystemFunctions.convertToTypeByName("True", "string"))) === true ? "visible" : "hidden")
			formVars.approvelead_31979_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadById !== undefined ? (stateVars.TM_GetLeadById?.length > 0 ? stateVars.TM_GetLeadById[0].referansNote : null) : (this.state.TM_GetLeadById?.length > 0 ? this.state.TM_GetLeadById[0].referansNote : null)));

			formVars.approvelead_295697_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadById !== undefined ? (stateVars.TM_GetLeadById?.length > 0 ? stateVars.TM_GetLeadById[0].urunAdi : null) : (this.state.TM_GetLeadById?.length > 0 ? this.state.TM_GetLeadById[0].urunAdi : null)));

			
			stateVars.dataSource_970463 = stateVars.TM_GetProductLeadHistory ?? this.state.TM_GetProductLeadHistory;
			stateVars.isComp58148Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, "approvelead_970463_value", "leadDurumu"), ReactSystemFunctions.convertToTypeByName("2. Takip", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp931151Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, "approvelead_970463_value", "leadDurumu"), ReactSystemFunctions.convertToTypeByName("Takip ediliyor", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp93515Visible = (((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, "approvelead_970463_value", "processName"), ReactSystemFunctions.convertToTypeByName("Onaylandı", "string")) || ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, "approvelead_970463_value", "processName"), ReactSystemFunctions.convertToTypeByName("Oluşturuldu", "string")))) === true ? "visible" : "hidden")
			stateVars.isComp34170Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, "approvelead_970463_value", "processName"), ReactSystemFunctions.convertToTypeByName("Reddedildi", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp504771Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, "approvelead_970463_value", "processCode"), ReactSystemFunctions.convertToTypeByName("CUSTOMER_DECLINED", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp506199Visible = (((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, "approvelead_970463_value", "processName"), ReactSystemFunctions.convertToTypeByName("Onay Bekliyor", "string")) || ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, "approvelead_970463_value", "processName"), ReactSystemFunctions.convertToTypeByName("Termin Bekliyor", "string")) || ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, "approvelead_970463_value", "processName"), ReactSystemFunctions.convertToTypeByName("Satış Bekliyor", "string")))) === true ? "visible" : "hidden")
			stateVars.isComp287327Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, "approvelead_970463_value", "processCode"), ReactSystemFunctions.convertToTypeByName("DELIVERED", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp760071Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, "approvelead_970463_value", "processName"), ReactSystemFunctions.convertToTypeByName("Kapatıldı", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp744003Visible = ((ReactSystemFunctions.isNotEmpty(ReactSystemFunctions.value(this, "approvelead_970463_value", "leadRejectedNote"), ReactSystemFunctions.convertToTypeByName("True", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp710304Visible = ((ReactSystemFunctions.isNotEmpty(ReactSystemFunctions.value(this, "approvelead_970463_value", "leadRejectedNote"), ReactSystemFunctions.convertToTypeByName("True", "string"))) === true ? "visible" : "hidden")
			
			formVars.approvelead_308186_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadById !== undefined ? (stateVars.TM_GetLeadById?.length > 0 ? stateVars.TM_GetLeadById[0].musteriAdi : null) : (this.state.TM_GetLeadById?.length > 0 ? this.state.TM_GetLeadById[0].musteriAdi : null)));

			
			stateVars.dataSource_439626 = stateVars.TM_GetCustomerLeadHistory ?? this.state.TM_GetCustomerLeadHistory;
			stateVars.isComp490394Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, "approvelead_439626_value", "leadDurumu"), ReactSystemFunctions.convertToTypeByName("2. Takip", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp929834Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, "approvelead_439626_value", "leadDurumu"), ReactSystemFunctions.convertToTypeByName("Takip ediliyor", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp677828Visible = (((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, "approvelead_439626_value", "processName"), ReactSystemFunctions.convertToTypeByName("Onaylandı", "string")) || ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, "approvelead_439626_value", "processName"), ReactSystemFunctions.convertToTypeByName("Oluşturuldu", "string")))) === true ? "visible" : "hidden")
			stateVars.isComp113424Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, "approvelead_439626_value", "processName"), ReactSystemFunctions.convertToTypeByName("Reddedildi", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp399539Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, "approvelead_439626_value", "processCode"), ReactSystemFunctions.convertToTypeByName("CUSTOMER_DECLINED", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp754674Visible = (((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, "approvelead_439626_value", "processName"), ReactSystemFunctions.convertToTypeByName("Onay Bekliyor", "string")) || ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, "approvelead_439626_value", "processName"), ReactSystemFunctions.convertToTypeByName("Termin Bekliyor", "string")) || ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, "approvelead_439626_value", "processName"), ReactSystemFunctions.convertToTypeByName("Satış Bekliyor", "string")))) === true ? "visible" : "hidden")
			stateVars.isComp152758Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, "approvelead_439626_value", "processCode"), ReactSystemFunctions.convertToTypeByName("DELIVERED", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp119069Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, "approvelead_439626_value", "processName"), ReactSystemFunctions.convertToTypeByName("Kapatıldı", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp280572Visible = ((ReactSystemFunctions.isNotEmpty(ReactSystemFunctions.value(this, "approvelead_439626_value", "leadRejectedNote"), ReactSystemFunctions.convertToTypeByName("True", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp93103Visible = ((ReactSystemFunctions.isNotEmpty(ReactSystemFunctions.value(this, "approvelead_439626_value", "leadRejectedNote"), ReactSystemFunctions.convertToTypeByName("True", "string"))) === true ? "visible" : "hidden")
			
			stateVars.isComp635267Visible = ((ReactSystemFunctions.isEmpty(ReactSystemFunctions.value(this, "approvelead_439626_value", "estimatedDate"), ReactSystemFunctions.convertToTypeByName("True", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp543686Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, (stateVars.TM_LeadCheckCustomerProduct !== undefined ? (stateVars.TM_LeadCheckCustomerProduct?.length > 0 ? stateVars.TM_LeadCheckCustomerProduct[0].leadExists : null) : (this.state.TM_LeadCheckCustomerProduct?.length > 0 ? this.state.TM_LeadCheckCustomerProduct[0].leadExists : null))), ReactSystemFunctions.convertToTypeByName("True", "string"))) === true ? "visible" : "hidden")
			formVars.approvelead_273338_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadById !== undefined ? (stateVars.TM_GetLeadById?.length > 0 ? stateVars.TM_GetLeadById[0].terminYil : null) : (this.state.TM_GetLeadById?.length > 0 ? this.state.TM_GetLeadById[0].terminYil : null)));

			formVars.approvelead_87086_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadById !== undefined ? (stateVars.TM_GetLeadById?.length > 0 ? stateVars.TM_GetLeadById[0].terminAyValue : null) : (this.state.TM_GetLeadById?.length > 0 ? this.state.TM_GetLeadById[0].terminAyValue : null)));

			stateVars.isComp165648Visible = ((ReactSystemFunctions.isNotEmpty(ReactSystemFunctions.toString(this, (stateVars.TMLeadSuggestion !== undefined ? (stateVars.TMLeadSuggestion?.length > 0 ? stateVars.TMLeadSuggestion[0].terminOneriText : null) : (this.state.TMLeadSuggestion?.length > 0 ? this.state.TMLeadSuggestion[0].terminOneriText : null))), ReactSystemFunctions.convertToTypeByName("True", "string"))) === true ? "visible" : "hidden")
			formVars.approvelead_809951_value = ReactSystemFunctions.toString(this, (stateVars.TMLeadSuggestion !== undefined ? (stateVars.TMLeadSuggestion?.length > 0 ? stateVars.TMLeadSuggestion[0].terminOneriText : null) : (this.state.TMLeadSuggestion?.length > 0 ? this.state.TMLeadSuggestion[0].terminOneriText : null)));


	this.props.form?.setFieldsValue(formVars);
	this.setState(stateVars);
	KuikaAppManager.hideSpinner(this);

            this.setPageInitLoaded(true);
            return isErrorOccurred;
        }




		ApproveLeadComponent_833286_onClick = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
KuikaAppManager.showSpinner(this);

					KuikaAppManager.prepareForNavigation();

				stateVars.NAVIGATE = await ReactSystemFunctions.navigate(this, undefined, "ApproveLead", "LeadList", "", "currentPage", null, null, null, null, null, null, true, false);

		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

            
            return isErrorOccurred;
        }


		ApproveLeadComponent_978479_onClick = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
KuikaAppManager.showSpinner(this);

				stateVars.ChangeVisibilityOf = await ReactSystemFunctions.changeVisibilityOf(this, ReactSystemFunctions.convertToTypeByName("isComp815552Visible", "string"), ReactSystemFunctions.convertToTypeByName("hidden", "string"));
				stateVars.ChangeVisibilityOf = await ReactSystemFunctions.changeVisibilityOf(this, ReactSystemFunctions.convertToTypeByName("isComp978479Visible", "string"), ReactSystemFunctions.convertToTypeByName("hidden", "string"));
				stateVars.ChangeVisibilityOf = await ReactSystemFunctions.changeVisibilityOf(this, ReactSystemFunctions.convertToTypeByName("isComp296286Visible", "string"), ReactSystemFunctions.convertToTypeByName("visible", "string"));

		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

            
            return isErrorOccurred;
        }


		ApproveLeadComponent_296286_onClick = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
KuikaAppManager.showSpinner(this);

				stateVars.ChangeVisibilityOf = await ReactSystemFunctions.changeVisibilityOf(this, ReactSystemFunctions.convertToTypeByName("isComp815552Visible", "string"), ReactSystemFunctions.convertToTypeByName("visible", "string"));
				stateVars.ChangeVisibilityOf = await ReactSystemFunctions.changeVisibilityOf(this, ReactSystemFunctions.convertToTypeByName("isComp978479Visible", "string"), ReactSystemFunctions.convertToTypeByName("visible", "string"));
				stateVars.ChangeVisibilityOf = await ReactSystemFunctions.changeVisibilityOf(this, ReactSystemFunctions.convertToTypeByName("isComp296286Visible", "string"), ReactSystemFunctions.convertToTypeByName("hidden", "string"));

		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

            
            return isErrorOccurred;
        }


		ApproveLeadComponent_562686_onClick = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
KuikaAppManager.showSpinner(this);

					KuikaAppManager.prepareForNavigation();
						KuikaAppManager.addToPageInputVariables("LeadDetail", "LeadId", ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, "approvelead_970463_value", "leadId"), "Guid"));

				stateVars.NAVIGATE = await ReactSystemFunctions.navigate(this, undefined, "ApproveLead", "LeadDetail", "", "currentPage", null, null, null, null, null, null, true, false);

		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

            
            return isErrorOccurred;
        }


		ApproveLeadComponent_812280_onClick = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
KuikaAppManager.showSpinner(this);

				stateVars.ChangeVisibilityOf = await ReactSystemFunctions.changeVisibilityOf(this, ReactSystemFunctions.convertToTypeByName("isComp657542Visible", "string"), ReactSystemFunctions.convertToTypeByName("hidden", "string"));
				stateVars.ChangeVisibilityOf = await ReactSystemFunctions.changeVisibilityOf(this, ReactSystemFunctions.convertToTypeByName("isComp258408Visible", "string"), ReactSystemFunctions.convertToTypeByName("visible", "string"));
				stateVars.ChangeVisibilityOf = await ReactSystemFunctions.changeVisibilityOf(this, ReactSystemFunctions.convertToTypeByName("isComp812280Visible", "string"), ReactSystemFunctions.convertToTypeByName("hidden", "string"));

		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

            
            return isErrorOccurred;
        }


		ApproveLeadComponent_258408_onClick = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
KuikaAppManager.showSpinner(this);

				stateVars.ChangeVisibilityOf = await ReactSystemFunctions.changeVisibilityOf(this, ReactSystemFunctions.convertToTypeByName("isComp657542Visible", "string"), ReactSystemFunctions.convertToTypeByName("visible", "string"));
				stateVars.ChangeVisibilityOf = await ReactSystemFunctions.changeVisibilityOf(this, ReactSystemFunctions.convertToTypeByName("isComp258408Visible", "string"), ReactSystemFunctions.convertToTypeByName("hidden", "string"));
				stateVars.ChangeVisibilityOf = await ReactSystemFunctions.changeVisibilityOf(this, ReactSystemFunctions.convertToTypeByName("isComp812280Visible", "string"), ReactSystemFunctions.convertToTypeByName("visible", "string"));

		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

            
            return isErrorOccurred;
        }


		ApproveLeadComponent_295050_onClick = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
KuikaAppManager.showSpinner(this);

					KuikaAppManager.prepareForNavigation();
						KuikaAppManager.addToPageInputVariables("LeadDetail", "LeadId", ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, "approvelead_439626_value", "leadId"), "Guid"));

				stateVars.NAVIGATE = await ReactSystemFunctions.navigate(this, undefined, "ApproveLead", "LeadDetail", "", "currentPage", null, null, null, null, null, null, true, false);

		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

            
            return isErrorOccurred;
        }


    ApproveLeadComponent_121781_onClick = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
		KuikaAppManager.increaseServerRequestCount();

        let localVar = {
				EstimatedYear_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toInteger(this, ReactSystemFunctions.value(this, "approvelead_273338_value", "value", "", "key", "")), "number"),
				EstimatedMonth_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toInteger(this, ReactSystemFunctions.value(this, "approvelead_87086_value", "value", "", "key", "")), "number"),
				LeadId_0: ReactSystemFunctions.convertToTypeByName(this.props.screenInputs.LeadId ?? this.props.screenInputs.leadid, "Guid"),
				UserId_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.getMyUserId(), "Guid")
        }

		KuikaAppManager.showSpinner(this);
if ((ReactSystemFunctions.isNotEmpty(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "approvelead_273338_value", "value", "", "key", "")), ReactSystemFunctions.convertToTypeByName("True", "string")) && ReactSystemFunctions.isNotEmpty(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "approvelead_87086_value", "value", "", "key", "")), ReactSystemFunctions.convertToTypeByName("True", "string")))) {
            		
        if (true) {
        KuikaAppManager.showSpinner(this);
        }
        let result = await KuikaAppManager.ApiRequest(this, "ApproveLead/ApproveLeadComponent_121781_onClick", localVar)
        if (!KMainFunctions.IsResStatus2XX(result)) return true;

			stateVars.TM_CreateLeadApproveLog = result?.data.tM_CreateLeadApproveLog;
			this.props.form?.setFieldsValue(formVars);
			
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.ApproveLeadComponent_121781_onClick1_();
                  resolve();
                });
          })

        } else {
            
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.ApproveLeadComponent_121781_onClick1_();
                  resolve();
                });
          })
        }


        
        KuikaAppManager.hideSpinner(this);
        return isErrorOccurred;
    }
		ApproveLeadComponent_121781_onClick1_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
if (ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, (stateVars.TM_CreateLeadApproveLog !== undefined ? (stateVars.TM_CreateLeadApproveLog?.length > 0 ? stateVars.TM_CreateLeadApproveLog[0].success : null) : (this.state.TM_CreateLeadApproveLog?.length > 0 ? this.state.TM_CreateLeadApproveLog[0].success : null))), "1")) {
            
				stateVars.Notify = await ReactSystemFunctions.notify(this, ReactSystemFunctions.toString(this, (stateVars.TM_CreateLeadApproveLog !== undefined ? (stateVars.TM_CreateLeadApproveLog?.length > 0 ? stateVars.TM_CreateLeadApproveLog[0].message : null) : (this.state.TM_CreateLeadApproveLog?.length > 0 ? this.state.TM_CreateLeadApproveLog[0].message : null))), ReactSystemFunctions.convertToTypeByName("success", "string"), ReactSystemFunctions.convertToTypeByName("top-center", "string"), 2, ReactSystemFunctions.convertToTypeByName("", "string"), ReactSystemFunctions.convertToTypeByName("", "string"), 0);

		this.props.form?.setFieldsValue(formVars);
		
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.ApproveLeadComponent_121781_onClick2_();
                  resolve();
                });
          })

        } else {
            
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.ApproveLeadComponent_121781_onClick2_();
                  resolve();
                });
          })
        }

            
            return isErrorOccurred;
        }
		ApproveLeadComponent_121781_onClick2_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
if (ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, (stateVars.TM_CreateLeadApproveLog !== undefined ? (stateVars.TM_CreateLeadApproveLog?.length > 0 ? stateVars.TM_CreateLeadApproveLog[0].success : null) : (this.state.TM_CreateLeadApproveLog?.length > 0 ? this.state.TM_CreateLeadApproveLog[0].success : null))), "1")) {
            
				stateVars.GoBack = await ReactSystemFunctions.goBack(this, false);

		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

        } else {
            KuikaAppManager.hideSpinner(this);
        }

            
            return isErrorOccurred;
        }





		ApproveLeadComponent_988256_onClick = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
KuikaAppManager.showSpinner(this);

					KuikaAppManager.prepareForNavigation();
						KuikaAppManager.addToPageInputVariables("LeadRejectPopUp", "LeadId", ReactSystemFunctions.convertToTypeByName(this.props.screenInputs.LeadId ?? this.props.screenInputs.leadid, "Guid"));

				stateVars.NAVIGATE = await ReactSystemFunctions.navigate(this, undefined, "ApproveLead", "LeadRejectPopUp", "", "9924ef5f-4b84-4200-b624-8d76348c7686", "910808", null, null, "true", "800px", "70vh", true, false);

		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

            
            return isErrorOccurred;
        }


		ApproveLeadComponent_710304_onChange = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
KuikaAppManager.showSpinner(this);

				

		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

            
            return isErrorOccurred;
        }


		ApproveLeadComponent_93103_onChange = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
KuikaAppManager.showSpinner(this);

				

		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

            
            return isErrorOccurred;
        }




    async callCallbackFunction(diId: number, isFromMaster: boolean = false) {
        let isErrorOccurred = false;
		let pageInitCallerNavDiIDs = [, , , 910808] as number[];
		if (isFromMaster || pageInitCallerNavDiIDs.indexOf(diId) > -1) {
			await this.ApproveLeadPageInit();
		}

    }


}
