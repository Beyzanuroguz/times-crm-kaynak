import React from "react";
import Axios, { AxiosResponse } from "axios";
import { KuikaAppManager } from "../../shared/utilty/kuika-app-manager";
import { ReactSystemFunctions } from "../../shared/utilty/react-system-functions";
import { KNavigator } from "../../shared/hoc/with-history";
import { KContext } from "../../shared/hoc/with-context";
import { useLocation } from "react-router-dom";
import { FormInstance } from "antd/es/form";
import { Guid } from "guid-typescript";
import Swal from "sweetalert2";
import { KMainFunctions } from "../../shared/utilty/main-functions";
import moment from "moment";
import { IValidationData } from "../../models/dto/validation-data";
import { IStripePayment } from "../../models/dto/stripe-payment";
import { IUserInfoDto } from "../../models/dto/user-info.dto";
import { UserService } from "../../services/user-service";
import { kuikaCoreWasmBridgeService } from "../../services/_singletons";
import _ from "lodash";
import mqtt, { MqttClient } from "mqtt";
import { IMqttResult } from "../../models/dto/mqtt.dto";


declare let window: any;

export interface IImportLeadAntalyaRolex_ScreenProps {
  navigator: KNavigator;
  form: FormInstance<any>;
  googleLogin: any;
  screenInputs: any;
  context: KContext;
  initialValues: any;
  children: any;
}

export interface IImportLeadAntalyaRolex_ScreenState {
    isSpinnerVisible: boolean;
    isPageVisible: boolean;
	isLeftMenuVisible: boolean;
    spinnerCount: number;
    selectedLanguage: string;
    isPageInitLoaded: false;
    isPageRecurringLoaded: false;
	UploadFile: any[];
	UploadFile_dummy: any[];
	ImportExcelBase64: string;
	ImportExcelBase64_dummy: string;
	ImportAntalyaRolexCustomerCount: any[];
	ImportAntalyaRolexCustomerCount_dummy: any[];
	ImportLeadAntalyaRolexList: any[];
	ImportLeadAntalyaRolexList_dummy: any[];
	ImportCustomer2: string;
	ImportCustomer2_dummy: string;
	Notify: boolean;
	Notify_dummy: boolean;
	ForEach2: ImportLeadAntalyaRolexList;
	ForEach2_dummy: ImportLeadAntalyaRolexList;

}

export class ImportLeadAntalyaRolex_ScreenBase extends React.PureComponent<IImportLeadAntalyaRolex_ScreenProps, any> {

	importleadantalyarolex_568047_value_kuikaTableRef: React.RefObject<any>;
    ml=[{"Id":"d5a61d2b-bd60-485f-86e2-661e9ed4e486","Name":"en_US","ShortName":"English","IsDefault":true,"LanguagePhrases":[]},{"Id":"c3dffabc-d147-4432-a9fc-8e8874114196","Name":"FixedValues","ShortName":"FixedValues","LanguagePhrases":[{"Id":960361,"PropertyName":"label","Value":"Müşterileri ve Leadleri içe aktar"},{"Id":775546,"PropertyName":"label","Value":"Müşteri Farklarını Listele"},{"Id":241765,"PropertyName":"title","Value":"Durum"},{"Id":267977,"PropertyName":"value","Value":"[datafield:durum]"},{"Id":41552,"PropertyName":"title","Value":"Adet"},{"Id":709851,"PropertyName":"value","Value":"[datafield:adet]"},{"Id":930674,"PropertyName":"label","Value":"Müşterileri Listele"},{"Id":903244,"PropertyName":"label","Value":"Müşterileri Post Et"}]}]
    defaultML = "en_US"
    
    screenHash = ""
    
	ForEach2: any[];


    constructor(props) {
        super(props);
		this.importleadantalyarolex_568047_value_kuikaTableRef = React.createRef();

        this.state = {
            isSpinnerVisible: false,
            isPageVisible: false,
            isLeftMenuVisible: false,
            spinnerCount: 0,
            selectedLanguage: "",
            isPageInitLoaded: false,
            isPageRecurringLoaded: false,
            	        UploadFile: [],
	        ImportExcelBase64: "",
	        ImportAntalyaRolexCustomerCount: [],
	        ImportLeadAntalyaRolexList: [],
	        ForEach: false,

        }

        this.state.isPageVisible = true;
        
    }

    async componentDidMount() {

        if (KuikaAppManager.isPageInitPrevented()) {
            KuikaAppManager.calculateAndSetBodyHeight("importleadantalyarolex", "");
            return;
        }
        
        
        ReactSystemFunctions.validateToken()
        this.fillFormInitValues();
        if (true){
            
        }
        
        
        
        KuikaAppManager.calculateAndSetBodyHeight("importleadantalyarolex", "");

        if (ReactSystemFunctions.getIsMicroApp() === false) {
           window.parentScreen = this;
        }
    }

    componentWillUnmount() {
        
        
        

        if (ReactSystemFunctions.getIsMicroApp() === false) {
           window.parentScreen = null;
        }
    }

    

        
    componentDidUpdate= async (prevProps, prevState) => {
		KuikaAppManager.calculateAndSetBodyHeight("importleadantalyarolex", ""    );
        if (prevProps?.location?.search !== (this.props as any)?.location?.search) {
			
		}

        

        if (ReactSystemFunctions.getIsMicroApp() === false) {
            for (const key in prevState) {
                if (key.startsWith('NavVisible') && prevState[key] === true && this.state[key] === false) {
                    window.parentScreen = this;
                    break;
                }
            }
        }
	}

    fillFormInitValues() {
        this.props.form?.setFieldsValue({
});

    }

      setPageInitLoaded = (value: boolean) => {
        this.setState({ isPageInitLoaded: value });
      }

      setPageRecurringLoaded = (value: boolean) => {
        this.setState({ isPageRecurringLoaded: value });
      }

      clearFieldValidation = (changedValues: any) => {
        const fieldName = Object.keys(changedValues)[0];
        if (fieldName) {
          this.props.form?.setFields([
            {
              name: fieldName,
              errors: []
            }
          ]);
        }
      };

      


		ImportLeadAntalyaRolexComponent_960361_onClick = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
KuikaAppManager.showSpinner(this);

				stateVars.UploadFile = (await ReactSystemFunctions.uploadFilesWithInfo(ReactSystemFunctions.convertToTypeByName(".xlsx", "string")) as any).data;

		this.props.form?.setFieldsValue(formVars);
		
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.ImportLeadAntalyaRolexComponent_960361_onClick1_();
                  resolve();
                });
          })

            
            return isErrorOccurred;
        }
    ImportLeadAntalyaRolexComponent_960361_onClick1_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
		KuikaAppManager.increaseServerRequestCount();

        let localVar = {
				excelBase64_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, (stateVars.UploadFile !== undefined ? (stateVars.UploadFile?.length > 0 ? stateVars.UploadFile[0].data : null) : (this.state.UploadFile?.length > 0 ? this.state.UploadFile[0].data : null))), "string"),
				tableName_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.convertToTypeByName("ImportLeadAntalyaRolex", "string"), "string"),
				primaryKeyName_0: ReactSystemFunctions.convertToTypeByName("", "string")
        }

		
        if (true) {
        KuikaAppManager.showSpinner(this);
        }
        let result = await KuikaAppManager.ApiRequest(this, "ImportLeadAntalyaRolex/ImportLeadAntalyaRolexComponent_960361_onClick1_", localVar)
        if (!KMainFunctions.IsResStatus2XX(result)) return true;

			stateVars.ImportExcelBase64 = result?.data.importExcelBase64;
			this.props.form?.setFieldsValue(formVars);
			this.setState(stateVars);
			KuikaAppManager.hideSpinner(this);



        this.setPageInitLoaded(true);
        KuikaAppManager.hideSpinner(this);
        return isErrorOccurred;
    }




    ImportLeadAntalyaRolexComponent_775546_onClick = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
		KuikaAppManager.increaseServerRequestCount();

        let localVar = {
        }

		KuikaAppManager.showSpinner(this);
		
        if (true) {
        KuikaAppManager.showSpinner(this);
        }
        let result = await KuikaAppManager.ApiRequest(this, "ImportLeadAntalyaRolex/ImportLeadAntalyaRolexComponent_775546_onClick", localVar)
        if (!KMainFunctions.IsResStatus2XX(result)) return true;

			stateVars.ImportAntalyaRolexCustomerCount = result?.data.importAntalyaRolexCustomerCount;
			
			this.props.form?.setFieldsValue(formVars);
			
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.ImportLeadAntalyaRolexComponent_775546_onClick1_();
                  resolve();
                });
          })



        
        KuikaAppManager.hideSpinner(this);
        return isErrorOccurred;
    }
		ImportLeadAntalyaRolexComponent_775546_onClick1_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }

				
				stateVars.dataSource_568047 = stateVars.ImportAntalyaRolexCustomerCount ?? this.state.ImportAntalyaRolexCustomerCount;

		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

            
            return isErrorOccurred;
        }




    ImportLeadAntalyaRolexComponent_903244_onClick = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
		KuikaAppManager.increaseServerRequestCount();

        let localVar = {
        }

		KuikaAppManager.showSpinner(this);
		
        if (true) {
        KuikaAppManager.showSpinner(this);
        }
        let result = await KuikaAppManager.ApiRequest(this, "ImportLeadAntalyaRolex/ImportLeadAntalyaRolexComponent_903244_onClick", localVar)
        if (!KMainFunctions.IsResStatus2XX(result)) return true;

			stateVars.ImportLeadAntalyaRolexList = result?.data.importLeadAntalyaRolexList;
			this.props.form?.setFieldsValue(formVars);
			
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.ImportLeadAntalyaRolexComponent_903244_onClick1_();
                  resolve();
                });
          })



        
        KuikaAppManager.hideSpinner(this);
        return isErrorOccurred;
    }
    ImportLeadAntalyaRolexComponent_903244_onClick_foreach1 = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
		KuikaAppManager.increaseServerRequestCount();

        let localVar = {
				ad_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, this.ForEach2?.name), "string"),
				soyad_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, (stateVars.ImportLeadAntalyaRolexList !== undefined ? (stateVars.ImportLeadAntalyaRolexList?.length > 0 ? stateVars.ImportLeadAntalyaRolexList[0].lastName : null) : (this.state.ImportLeadAntalyaRolexList?.length > 0 ? this.state.ImportLeadAntalyaRolexList[0].lastName : null))), "string"),
				telefon_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, (stateVars.ImportLeadAntalyaRolexList !== undefined ? (stateVars.ImportLeadAntalyaRolexList?.length > 0 ? stateVars.ImportLeadAntalyaRolexList[0].irtibat_Numaras_ : null) : (this.state.ImportLeadAntalyaRolexList?.length > 0 ? this.state.ImportLeadAntalyaRolexList[0].irtibat_Numaras_ : null))), "string"),
				email_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, (stateVars.ImportLeadAntalyaRolexList !== undefined ? (stateVars.ImportLeadAntalyaRolexList?.length > 0 ? stateVars.ImportLeadAntalyaRolexList[0].e_Mail_Adresi : null) : (this.state.ImportLeadAntalyaRolexList?.length > 0 ? this.state.ImportLeadAntalyaRolexList[0].e_Mail_Adresi : null))), "string"),
				tcKimlikNo_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.convertToTypeByName("11111111111", "string"), "string"),
				lokasyon_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, (stateVars.ImportLeadAntalyaRolexList !== undefined ? (stateVars.ImportLeadAntalyaRolexList?.length > 0 ? stateVars.ImportLeadAntalyaRolexList[0].lokasyon : null) : (this.state.ImportLeadAntalyaRolexList?.length > 0 ? this.state.ImportLeadAntalyaRolexList[0].lokasyon : null))), "string"),
				musteriInfo_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, (stateVars.ImportLeadAntalyaRolexList !== undefined ? (stateVars.ImportLeadAntalyaRolexList?.length > 0 ? stateVars.ImportLeadAntalyaRolexList[0].musteri_info : null) : (this.state.ImportLeadAntalyaRolexList?.length > 0 ? this.state.ImportLeadAntalyaRolexList[0].musteri_info : null))), "string"),
				matchType_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, (stateVars.ImportLeadAntalyaRolexList !== undefined ? (stateVars.ImportLeadAntalyaRolexList?.length > 0 ? stateVars.ImportLeadAntalyaRolexList[0].matchType : null) : (this.state.ImportLeadAntalyaRolexList?.length > 0 ? this.state.ImportLeadAntalyaRolexList[0].matchType : null))), "string"),
				customerId_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, (stateVars.ImportLeadAntalyaRolexList !== undefined ? (stateVars.ImportLeadAntalyaRolexList?.length > 0 ? stateVars.ImportLeadAntalyaRolexList[0].customerId : null) : (this.state.ImportLeadAntalyaRolexList?.length > 0 ? this.state.ImportLeadAntalyaRolexList[0].customerId : null))), "Guid"),
				currAccCode_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, (stateVars.ImportLeadAntalyaRolexList !== undefined ? (stateVars.ImportLeadAntalyaRolexList?.length > 0 ? stateVars.ImportLeadAntalyaRolexList[0].currAccCode : null) : (this.state.ImportLeadAntalyaRolexList?.length > 0 ? this.state.ImportLeadAntalyaRolexList[0].currAccCode : null))), "string"),
				sourceType_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.convertToTypeByName("ExcelAntalyaRolexOto", "string"), "string"),
				createdBy_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.getMyUserId(), "Guid")
        }

		KuikaAppManager.showSpinner(this);
		
        if (true) {
        KuikaAppManager.showSpinner(this);
        }
        let result = await KuikaAppManager.ApiRequest(this, "ImportLeadAntalyaRolex/ImportLeadAntalyaRolexComponent_903244_onClick_foreach1", localVar)
        if (!KMainFunctions.IsResStatus2XX(result)) return true;

			stateVars.ImportCustomer2 = result?.data.importCustomer2;
			this.props.form?.setFieldsValue(formVars);
			
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.ImportLeadAntalyaRolexComponent_903244_onClick_foreach11_();
                  resolve();
                });
          })



        
        KuikaAppManager.hideSpinner(this);
        return isErrorOccurred;
    }
		ImportLeadAntalyaRolexComponent_903244_onClick_foreach11_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }

				stateVars.Notify = await ReactSystemFunctions.notify(this, ReactSystemFunctions.toString(this, this.state.ImportCustomer2), ReactSystemFunctions.convertToTypeByName("default", "string"), ReactSystemFunctions.convertToTypeByName("bottom-right", "string"), 2, ReactSystemFunctions.convertToTypeByName("", "string"), ReactSystemFunctions.convertToTypeByName("", "string"), 0);

		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

            
            return isErrorOccurred;
        }




		ImportLeadAntalyaRolexComponent_903244_onClick1_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }

        if(ReactSystemFunctions.value(this, this.state.ImportLeadAntalyaRolexList)?.length) {
            for (let item of ReactSystemFunctions.value(this, this.state.ImportLeadAntalyaRolexList)) {
                this.ForEach2 = item;
                await this.ImportLeadAntalyaRolexComponent_903244_onClick_foreach1();
            }
        }


		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

            
            return isErrorOccurred;
        }






    async callCallbackFunction(diId: number, isFromMaster: boolean = false) {
        let isErrorOccurred = false;

    }


}
