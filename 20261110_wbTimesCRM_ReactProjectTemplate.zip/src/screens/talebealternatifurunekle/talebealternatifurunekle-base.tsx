import React from "react";
import Axios, { AxiosResponse } from "axios";
import { KuikaAppManager } from "../../shared/utilty/kuika-app-manager";
import { ReactSystemFunctions } from "../../shared/utilty/react-system-functions";
import { KNavigator } from "../../shared/hoc/with-history";
import { KContext } from "../../shared/hoc/with-context";
import { useLocation } from "react-router-dom";
import { FormInstance } from "antd/es/form";
import { Guid } from "guid-typescript";
import Swal from "sweetalert2";
import { KMainFunctions } from "../../shared/utilty/main-functions";
import moment from "moment";
import { IValidationData } from "../../models/dto/validation-data";
import { IStripePayment } from "../../models/dto/stripe-payment";
import { IUserInfoDto } from "../../models/dto/user-info.dto";
import { UserService } from "../../services/user-service";
import { kuikaCoreWasmBridgeService } from "../../services/_singletons";
import _ from "lodash";
import mqtt, { MqttClient } from "mqtt";
import { IMqttResult } from "../../models/dto/mqtt.dto";


declare let window: any;

export interface ITalebeAlternatifUrunEkle_ScreenProps {
  navigator: KNavigator;
  form: FormInstance<any>;
  googleLogin: any;
  screenInputs: any;
  context: KContext;
  initialValues: any;
  children: any;
}

export interface ITalebeAlternatifUrunEkle_ScreenState {
    isSpinnerVisible: boolean;
    isPageVisible: boolean;
	isLeftMenuVisible: boolean;
    spinnerCount: number;
    selectedLanguage: string;
    isPageInitLoaded: false;
    isPageRecurringLoaded: false;
	TM_GetLeadAlternativeModel: any[];
	TM_GetLeadAlternativeModel_dummy: any[];
	TM_GetProductBrandAlternatif: any[];
	TM_GetProductBrandAlternatif_dummy: any[];
	GoBack: any;
	GoBack_dummy: any;
	TM_GetProductReferanceAlternatif: any[];
	TM_GetProductReferanceAlternatif_dummy: any[];
	SetValueOf: any;
	SetValueOf_dummy: any;
	TM_GetProductDialAlternatif: any[];
	TM_GetProductDialAlternatif_dummy: any[];
	TM_GetProductBraceletAlternatif: any[];
	TM_GetProductBraceletAlternatif_dummy: any[];
	TM_GetProductForAltModel: any[];
	TM_GetProductForAltModel_dummy: any[];
	GetAlternativeProductStockByLeadAndProductId: any[];
	GetAlternativeProductStockByLeadAndProductId_dummy: any[];
	GetAltrenativeProductStockInfoByProductId: any[];
	GetAltrenativeProductStockInfoByProductId_dummy: any[];
	TM_InsertLeadAlternativeModel: any[];
	TM_InsertLeadAlternativeModel_dummy: any[];
	Notify: boolean;
	Notify_dummy: boolean;
	TM_DeleteLeadAlternativeModel: any[];
	TM_DeleteLeadAlternativeModel_dummy: any[];
	isComp821230Visible: 'visible' | 'hidden';
	isComp4777Visible: 'visible' | 'hidden';
	isComp425110Visible: 'visible' | 'hidden';
	isComp836699Visible: 'visible' | 'hidden';
	isComp196080Visible: 'visible' | 'hidden';
	isComp793217Visible: 'visible' | 'hidden';
	isComp466478Visible: 'visible' | 'hidden';
	isComp946312Visible: 'visible' | 'hidden';
	isComp698453Visible: 'visible' | 'hidden';
	isComp669205Visible: 'visible' | 'hidden';
	isComp159985Visible: 'visible' | 'hidden';
	isComp505914Visible: 'visible' | 'hidden';
	isComp976246Visible: 'visible' | 'hidden';
	isComp15399Visible: 'visible' | 'hidden';
	isComp758790Visible: 'visible' | 'hidden';
	isComp520035Visible: 'visible' | 'hidden';
	isComp296305Visible: 'visible' | 'hidden';
	isComp284606Visible: 'visible' | 'hidden';
	isComp398259Visible: 'visible' | 'hidden';
	isComp413110Visible: 'visible' | 'hidden';
	isComp283102Visible: 'visible' | 'hidden';
	isComp581418Visible: 'visible' | 'hidden';
	isComp994808Visible: 'visible' | 'hidden';

}

export class TalebeAlternatifUrunEkle_ScreenBase extends React.PureComponent<ITalebeAlternatifUrunEkle_ScreenProps, any> {

	talebealternatifurunekle_375056_value_kuikaAutoCompleteRef: React.RefObject<any>;
	talebealternatifurunekle_452629_value_kuikaAutoCompleteRef: React.RefObject<any>;
	talebealternatifurunekle_570898_value_kuikaAutoCompleteRef: React.RefObject<any>;
	talebealternatifurunekle_523925_value_kuikaAutoCompleteRef: React.RefObject<any>;
	talebealternatifurunekle_469879_value_kuikaTableRef: React.RefObject<any>;
	talebealternatifurunekle_976246_value_kuikaTableRef: React.RefObject<any>;
    ml=[{"Id":"d5a61d2b-bd60-485f-86e2-661e9ed4e486","Name":"en_US","ShortName":"English","IsDefault":true,"LanguagePhrases":[]},{"Id":"642913e7-a733-46c9-a915-3dc75a947f04","Name":"FixedValues","ShortName":"FixedValues","LanguagePhrases":[{"Id":560035,"PropertyName":"label","Value":"Geri Dön"},{"Id":998945,"PropertyName":"value","Value":"Talebe Alternatif Ürün Ekle"},{"Id":921812,"PropertyName":"value","Value":"Mevcut talep için müşteriye sunulabilecek alternatif ürün veya referans modeli seçin."},{"Id":575906,"PropertyName":"value","Value":"Alternatif Ürün Seçimi"},{"Id":416845,"PropertyName":"value","Value":"Ürün özelliklerine göre arama yapın ve uygun alternatif modeli seçin."},{"Id":375056,"PropertyName":"placeholder","Value":"Marka seçin"},{"Id":452629,"PropertyName":"placeholder","Value":"Model seçin"},{"Id":570898,"PropertyName":"placeholder","Value":"Kadran seçin"},{"Id":523925,"PropertyName":"placeholder","Value":"Bilezik seçin"},{"Id":986401,"PropertyName":"label","Value":"Alternatif Ürünü Ekle"},{"Id":166427,"PropertyName":"value","Value":"Mevcut Mağaza ve Mağaza Bazlı Stok Bilgisi"},{"Id":660807,"PropertyName":"value","Value":"Eklenecek Alternatif Ürünün Mağaza Bazlı Stok Bilgisi"},{"Id":156299,"PropertyName":"value","Value":"Ürün Adı"},{"Id":981955,"PropertyName":"value","Value":"Marka"},{"Id":803933,"PropertyName":"value","Value":"Model"},{"Id":770683,"PropertyName":"value","Value":"Kadran"},{"Id":855151,"PropertyName":"value","Value":"Bilezik"},{"Id":474577,"PropertyName":"value","Value":"Stok Durumu"},{"Id":793217,"PropertyName":"value","Value":"Stokta Var"},{"Id":466478,"PropertyName":"value","Value":"Stok Müsait"},{"Id":946312,"PropertyName":"value","Value":"Stokta Yok"},{"Id":698453,"PropertyName":"value","Value":"Stok Müsait Değil"},{"Id":592811,"PropertyName":"value","Value":"Aktif Lead Var mı?"},{"Id":669205,"PropertyName":"value","Value":"Var"},{"Id":159985,"PropertyName":"value","Value":"Yok"},{"Id":801107,"PropertyName":"title","Value":"Mağaza"},{"Id":640814,"PropertyName":"value","Value":"[datafield:storedesc]"},{"Id":90720,"PropertyName":"title","Value":"Toplam Stok"},{"Id":591661,"PropertyName":"value","Value":"[datafield:totalstock]"},{"Id":561079,"PropertyName":"title","Value":"Müsait Stok(Rezerve Edilmemiş)"},{"Id":637718,"PropertyName":"value","Value":"[datafield:availablestock]"},{"Id":845126,"PropertyName":"value","Value":"Seçilen Alternatif Ürün"},{"Id":943265,"PropertyName":"value","Value":"Seçim sonrası eklenecek alternatif ürün özeti"},{"Id":650083,"PropertyName":"value","Value":"Henüz alternatif ürün seçilmedi."},{"Id":927161,"PropertyName":"title","Value":"Title"},{"Id":882163,"PropertyName":"value","Value":"Ürün Adı"},{"Id":96176,"PropertyName":"value","Value":"[datafield:productname]"},{"Id":871890,"PropertyName":"value","Value":"Marka"},{"Id":51852,"PropertyName":"value","Value":"[datafield:brand]"},{"Id":802773,"PropertyName":"value","Value":"Model"},{"Id":352750,"PropertyName":"value","Value":"[datafield:referance]"},{"Id":549968,"PropertyName":"value","Value":"Kadran"},{"Id":348344,"PropertyName":"value","Value":"[datafield:dial]"},{"Id":178124,"PropertyName":"value","Value":"Bilezik"},{"Id":936648,"PropertyName":"value","Value":"[datafield:bracelet]"},{"Id":15399,"PropertyName":"value","Value":"[datafield:categoryname]"},{"Id":758790,"PropertyName":"value","Value":"[datafield:categoryname]"},{"Id":520035,"PropertyName":"value","Value":"[datafield:categoryname]"},{"Id":296305,"PropertyName":"value","Value":"[datafield:categoryname]"},{"Id":152139,"PropertyName":"value","Value":"Stok Durumu"},{"Id":284606,"PropertyName":"value","Value":"Stokta Var"},{"Id":398259,"PropertyName":"value","Value":"Stok Müsait"},{"Id":413110,"PropertyName":"value","Value":"Stokta Yok"},{"Id":283102,"PropertyName":"value","Value":"Stok Müsait Değil"},{"Id":757971,"PropertyName":"value","Value":"Aktif Lead Var mı?"},{"Id":581418,"PropertyName":"value","Value":"Var"},{"Id":994808,"PropertyName":"value","Value":"Yok"}]}]
    defaultML = "en_US"
    
    screenHash = ""
    


    constructor(props) {
        super(props);
		this.talebealternatifurunekle_375056_value_kuikaAutoCompleteRef = React.createRef();
		this.talebealternatifurunekle_452629_value_kuikaAutoCompleteRef = React.createRef();
		this.talebealternatifurunekle_570898_value_kuikaAutoCompleteRef = React.createRef();
		this.talebealternatifurunekle_523925_value_kuikaAutoCompleteRef = React.createRef();
		this.talebealternatifurunekle_469879_value_kuikaTableRef = React.createRef();
		this.talebealternatifurunekle_976246_value_kuikaTableRef = React.createRef();

        this.state = {
            isSpinnerVisible: false,
            isPageVisible: false,
            isLeftMenuVisible: false,
            spinnerCount: 0,
            selectedLanguage: "",
            isPageInitLoaded: false,
            isPageRecurringLoaded: false,
            	        TM_GetLeadAlternativeModel: [],
	        TM_GetProductBrandAlternatif: [],
	        GoBack: "",
	        TM_GetProductReferanceAlternatif: [],
	        SetValueOf: "",
	        TM_GetProductDialAlternatif: [],
	        TM_GetProductBraceletAlternatif: [],
	        TM_GetProductForAltModel: [],
	        GetAlternativeProductStockByLeadAndProductId: [],
	        GetAltrenativeProductStockInfoByProductId: [],
	        TM_InsertLeadAlternativeModel: [],
	        Notify: false,
	        TM_DeleteLeadAlternativeModel: [],
	        isComp821230Visible: 'hidden',
	        isComp4777Visible: 'hidden',
	        isComp425110Visible: 'hidden',
	        isComp836699Visible: 'hidden',
	        isComp196080Visible: 'hidden',
	        isComp793217Visible: 'hidden',
	        isComp466478Visible: 'hidden',
	        isComp946312Visible: 'hidden',
	        isComp698453Visible: 'hidden',
	        isComp669205Visible: 'hidden',
	        isComp159985Visible: 'hidden',
	        isComp505914Visible: 'hidden',
	        isComp976246Visible: 'hidden',
	        isComp15399Visible: 'hidden',
	        isComp758790Visible: 'hidden',
	        isComp520035Visible: 'hidden',
	        isComp296305Visible: 'hidden',
	        isComp284606Visible: 'hidden',
	        isComp398259Visible: 'hidden',
	        isComp413110Visible: 'hidden',
	        isComp283102Visible: 'hidden',
	        isComp581418Visible: 'hidden',
	        isComp994808Visible: 'hidden',

        }

        this.state.isPageVisible = true;
        
    }

    async componentDidMount() {

        if (KuikaAppManager.isPageInitPrevented()) {
            KuikaAppManager.calculateAndSetBodyHeight("talebealternatifurunekle", "");
            return;
        }
        
        
        ReactSystemFunctions.validateToken()
        this.fillFormInitValues();
        if (true){
            await this.TalebeAlternatifUrunEklePageInit();
        }
        
        
        
        KuikaAppManager.calculateAndSetBodyHeight("talebealternatifurunekle", "");

        if (ReactSystemFunctions.getIsMicroApp() === false) {
           window.parentScreen = this;
        }
    }

    componentWillUnmount() {
        
        
        

        if (ReactSystemFunctions.getIsMicroApp() === false) {
           window.parentScreen = null;
        }
    }

    

        
    componentDidUpdate= async (prevProps, prevState) => {
		KuikaAppManager.calculateAndSetBodyHeight("talebealternatifurunekle", ""    );
        if (prevProps?.location?.search !== (this.props as any)?.location?.search) {
			await this.TalebeAlternatifUrunEklePageInit();
		}

        

        if (ReactSystemFunctions.getIsMicroApp() === false) {
            for (const key in prevState) {
                if (key.startsWith('NavVisible') && prevState[key] === true && this.state[key] === false) {
                    window.parentScreen = this;
                    break;
                }
            }
        }
	}

    fillFormInitValues() {
        this.props.form?.setFieldsValue({
});

    }

      setPageInitLoaded = (value: boolean) => {
        this.setState({ isPageInitLoaded: value });
      }

      setPageRecurringLoaded = (value: boolean) => {
        this.setState({ isPageRecurringLoaded: value });
      }

      clearFieldValidation = (changedValues: any) => {
        const fieldName = Object.keys(changedValues)[0];
        if (fieldName) {
          this.props.form?.setFields([
            {
              name: fieldName,
              errors: []
            }
          ]);
        }
      };

      

    TalebeAlternatifUrunEklePageInit = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


	if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }

        let localVar = {
			LeadId_0: ReactSystemFunctions.convertToTypeByName(this.props.screenInputs.LeadId ?? this.props.screenInputs.leadid, "Guid"),
			KUserId_1: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.getMyUserId(), "Guid")
        }

	KuikaAppManager.showSpinner(this);
	
        if (true) {
        KuikaAppManager.showSpinner(this);
        }
        let result = await KuikaAppManager.ApiRequest(this, "TalebeAlternatifUrunEkle/TalebeAlternatifUrunEklePageInit", localVar)
        if (!KMainFunctions.IsResStatus2XX(result)) return true;

		stateVars.TM_GetLeadAlternativeModel = result?.data.tM_GetLeadAlternativeModel;
		
		stateVars.isComp505914Visible = ((ReactSystemFunctions.isEmpty(ReactSystemFunctions.value(this, (stateVars.TM_GetLeadAlternativeModel !== undefined ? (stateVars.TM_GetLeadAlternativeModel?.length > 0 ? stateVars.TM_GetLeadAlternativeModel[0].productId : null) : (this.state.TM_GetLeadAlternativeModel?.length > 0 ? this.state.TM_GetLeadAlternativeModel[0].productId : null))), ReactSystemFunctions.convertToTypeByName("True", "string"))) === true ? "visible" : "hidden")
		stateVars.isComp976246Visible = ((ReactSystemFunctions.isNotEmpty(ReactSystemFunctions.value(this, (stateVars.TM_GetLeadAlternativeModel !== undefined ? (stateVars.TM_GetLeadAlternativeModel?.length > 0 ? stateVars.TM_GetLeadAlternativeModel[0].productId : null) : (this.state.TM_GetLeadAlternativeModel?.length > 0 ? this.state.TM_GetLeadAlternativeModel[0].productId : null))), ReactSystemFunctions.convertToTypeByName("True", "string"))) === true ? "visible" : "hidden")
		stateVars.TM_GetProductBrandAlternatif = result?.data.tM_GetProductBrandAlternatif;
		
		formVars.talebealternatifurunekle_375056_options = stateVars.TM_GetProductBrandAlternatif;
		this.props.form?.setFieldsValue(formVars);
		
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.TalebeAlternatifUrunEklePageInit1_();
                  resolve();
                });
          })



        
        KuikaAppManager.hideSpinner(this);
        return isErrorOccurred;
    }
	TalebeAlternatifUrunEklePageInit1_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


	if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }

			
			stateVars.dataSource_375056 = stateVars.TM_GetProductBrandAlternatif ?? this.state.TM_GetProductBrandAlternatif;
			stateVars.dataSource_375056 = stateVars.TM_GetProductBrandAlternatif ?? this.state.TM_GetProductBrandAlternatif;
			stateVars.isComp821230Visible = ((ReactSystemFunctions.isNotEmpty(ReactSystemFunctions.value(this, (stateVars.GetAlternativeProductStockByLeadAndProductId !== undefined ? (stateVars.GetAlternativeProductStockByLeadAndProductId?.length > 0 ? stateVars.GetAlternativeProductStockByLeadAndProductId[0].productId : null) : (this.state.GetAlternativeProductStockByLeadAndProductId?.length > 0 ? this.state.GetAlternativeProductStockByLeadAndProductId[0].productId : null))), ReactSystemFunctions.convertToTypeByName("True", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp4777Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.toString(this, (stateVars.GetAlternativeProductStockByLeadAndProductId !== undefined ? (stateVars.GetAlternativeProductStockByLeadAndProductId?.length > 0 ? stateVars.GetAlternativeProductStockByLeadAndProductId[0].categoryName : null) : (this.state.GetAlternativeProductStockByLeadAndProductId?.length > 0 ? this.state.GetAlternativeProductStockByLeadAndProductId[0].categoryName : null))), ReactSystemFunctions.convertToTypeByName("Kategori 2", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp425110Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.toString(this, (stateVars.GetAlternativeProductStockByLeadAndProductId !== undefined ? (stateVars.GetAlternativeProductStockByLeadAndProductId?.length > 0 ? stateVars.GetAlternativeProductStockByLeadAndProductId[0].categoryName : null) : (this.state.GetAlternativeProductStockByLeadAndProductId?.length > 0 ? this.state.GetAlternativeProductStockByLeadAndProductId[0].categoryName : null))), ReactSystemFunctions.convertToTypeByName("Kategori 1", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp836699Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.toString(this, (stateVars.GetAlternativeProductStockByLeadAndProductId !== undefined ? (stateVars.GetAlternativeProductStockByLeadAndProductId?.length > 0 ? stateVars.GetAlternativeProductStockByLeadAndProductId[0].categoryName : null) : (this.state.GetAlternativeProductStockByLeadAndProductId?.length > 0 ? this.state.GetAlternativeProductStockByLeadAndProductId[0].categoryName : null))), ReactSystemFunctions.convertToTypeByName("DEFAULT", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp196080Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.toString(this, (stateVars.GetAlternativeProductStockByLeadAndProductId !== undefined ? (stateVars.GetAlternativeProductStockByLeadAndProductId?.length > 0 ? stateVars.GetAlternativeProductStockByLeadAndProductId[0].categoryName : null) : (this.state.GetAlternativeProductStockByLeadAndProductId?.length > 0 ? this.state.GetAlternativeProductStockByLeadAndProductId[0].categoryName : null))), ReactSystemFunctions.convertToTypeByName("Kategori 3", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp793217Visible = ((ReactSystemFunctions.isGreaterThan(ReactSystemFunctions.value(this, (stateVars.GetAlternativeProductStockByLeadAndProductId !== undefined ? (stateVars.GetAlternativeProductStockByLeadAndProductId?.length > 0 ? stateVars.GetAlternativeProductStockByLeadAndProductId[0].totalStock : null) : (this.state.GetAlternativeProductStockByLeadAndProductId?.length > 0 ? this.state.GetAlternativeProductStockByLeadAndProductId[0].totalStock : null))), ReactSystemFunctions.convertToTypeByName("0", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp466478Visible = ((ReactSystemFunctions.isGreaterThan(ReactSystemFunctions.value(this, (stateVars.GetAlternativeProductStockByLeadAndProductId !== undefined ? (stateVars.GetAlternativeProductStockByLeadAndProductId?.length > 0 ? stateVars.GetAlternativeProductStockByLeadAndProductId[0].availableStock : null) : (this.state.GetAlternativeProductStockByLeadAndProductId?.length > 0 ? this.state.GetAlternativeProductStockByLeadAndProductId[0].availableStock : null))), ReactSystemFunctions.convertToTypeByName("0", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp946312Visible = ((ReactSystemFunctions.isLessThan(ReactSystemFunctions.value(this, (stateVars.GetAlternativeProductStockByLeadAndProductId !== undefined ? (stateVars.GetAlternativeProductStockByLeadAndProductId?.length > 0 ? stateVars.GetAlternativeProductStockByLeadAndProductId[0].totalStock : null) : (this.state.GetAlternativeProductStockByLeadAndProductId?.length > 0 ? this.state.GetAlternativeProductStockByLeadAndProductId[0].totalStock : null))), ReactSystemFunctions.convertToTypeByName("1", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp698453Visible = ((ReactSystemFunctions.isLessThan(ReactSystemFunctions.value(this, (stateVars.GetAlternativeProductStockByLeadAndProductId !== undefined ? (stateVars.GetAlternativeProductStockByLeadAndProductId?.length > 0 ? stateVars.GetAlternativeProductStockByLeadAndProductId[0].availableStock : null) : (this.state.GetAlternativeProductStockByLeadAndProductId?.length > 0 ? this.state.GetAlternativeProductStockByLeadAndProductId[0].availableStock : null))), ReactSystemFunctions.convertToTypeByName("1", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp669205Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, (stateVars.GetAlternativeProductStockByLeadAndProductId !== undefined ? (stateVars.GetAlternativeProductStockByLeadAndProductId?.length > 0 ? stateVars.GetAlternativeProductStockByLeadAndProductId[0].hasActiveLead : null) : (this.state.GetAlternativeProductStockByLeadAndProductId?.length > 0 ? this.state.GetAlternativeProductStockByLeadAndProductId[0].hasActiveLead : null))), ReactSystemFunctions.convertToTypeByName("True", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp159985Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, (stateVars.GetAlternativeProductStockByLeadAndProductId !== undefined ? (stateVars.GetAlternativeProductStockByLeadAndProductId?.length > 0 ? stateVars.GetAlternativeProductStockByLeadAndProductId[0].hasActiveLead : null) : (this.state.GetAlternativeProductStockByLeadAndProductId?.length > 0 ? this.state.GetAlternativeProductStockByLeadAndProductId[0].hasActiveLead : null))), ReactSystemFunctions.convertToTypeByName("False", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp505914Visible = ((ReactSystemFunctions.isEmpty(ReactSystemFunctions.value(this, (stateVars.TM_GetLeadAlternativeModel !== undefined ? (stateVars.TM_GetLeadAlternativeModel?.length > 0 ? stateVars.TM_GetLeadAlternativeModel[0].productId : null) : (this.state.TM_GetLeadAlternativeModel?.length > 0 ? this.state.TM_GetLeadAlternativeModel[0].productId : null))), ReactSystemFunctions.convertToTypeByName("True", "string"))) === true ? "visible" : "hidden")
			
			stateVars.dataSource_976246 = stateVars.TM_GetLeadAlternativeModel ?? this.state.TM_GetLeadAlternativeModel;
			stateVars.isComp976246Visible = ((ReactSystemFunctions.isNotEmpty(ReactSystemFunctions.value(this, (stateVars.TM_GetLeadAlternativeModel !== undefined ? (stateVars.TM_GetLeadAlternativeModel?.length > 0 ? stateVars.TM_GetLeadAlternativeModel[0].productId : null) : (this.state.TM_GetLeadAlternativeModel?.length > 0 ? this.state.TM_GetLeadAlternativeModel[0].productId : null))), ReactSystemFunctions.convertToTypeByName("True", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp15399Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, "talebealternatifurunekle_976246_value", "categoryName"), ReactSystemFunctions.convertToTypeByName("Kategori 2", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp758790Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, "talebealternatifurunekle_976246_value", "categoryName"), ReactSystemFunctions.convertToTypeByName("Kategori 1", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp520035Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, "talebealternatifurunekle_976246_value", "categoryName"), ReactSystemFunctions.convertToTypeByName("DEFAULT", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp296305Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, "talebealternatifurunekle_976246_value", "categoryName"), ReactSystemFunctions.convertToTypeByName("Kategori 3", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp284606Visible = ((ReactSystemFunctions.isGreaterThan(ReactSystemFunctions.value(this, "talebealternatifurunekle_976246_value", "totalStock"), ReactSystemFunctions.convertToTypeByName("0", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp398259Visible = ((ReactSystemFunctions.isGreaterThan(ReactSystemFunctions.value(this, "talebealternatifurunekle_976246_value", "availableStock"), ReactSystemFunctions.convertToTypeByName("0", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp413110Visible = ((ReactSystemFunctions.isLessThan(ReactSystemFunctions.value(this, "talebealternatifurunekle_976246_value", "totalStock"), ReactSystemFunctions.convertToTypeByName("1", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp283102Visible = ((ReactSystemFunctions.isLessThan(ReactSystemFunctions.value(this, "talebealternatifurunekle_976246_value", "availableStock"), ReactSystemFunctions.convertToTypeByName("1", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp581418Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, "talebealternatifurunekle_976246_value", "hasActiveLead"), ReactSystemFunctions.convertToTypeByName("True", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp994808Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, "talebealternatifurunekle_976246_value", "hasActiveLead"), ReactSystemFunctions.convertToTypeByName("False", "string"))) === true ? "visible" : "hidden")

	this.props.form?.setFieldsValue(formVars);
	this.setState(stateVars);
	KuikaAppManager.hideSpinner(this);

            this.setPageInitLoaded(true);
            return isErrorOccurred;
        }




		TalebeAlternatifUrunEkleComponent_560035_onClick = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
KuikaAppManager.showSpinner(this);

				stateVars.GoBack = await ReactSystemFunctions.goBack(this, false);

		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

            
            return isErrorOccurred;
        }


    TalebeAlternatifUrunEkleComponent_375056_onChange = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
		KuikaAppManager.increaseServerRequestCount();

        let localVar = {
				BrandName_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "talebealternatifurunekle_375056_value", "value", "TM_GetProductBrandAlternatif", "brand", "brand")), "string")
        }

		KuikaAppManager.showSpinner(this);
		
        if (true) {
        KuikaAppManager.showSpinner(this);
        }
        let result = await KuikaAppManager.ApiRequest(this, "TalebeAlternatifUrunEkle/TalebeAlternatifUrunEkleComponent_375056_onChange", localVar)
        if (!KMainFunctions.IsResStatus2XX(result)) return true;

			stateVars.TM_GetProductReferanceAlternatif = result?.data.tM_GetProductReferanceAlternatif;
			
			formVars.talebealternatifurunekle_452629_options = stateVars.TM_GetProductReferanceAlternatif;
			this.props.form?.setFieldsValue(formVars);
			
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.TalebeAlternatifUrunEkleComponent_375056_onChange1_();
                  resolve();
                });
          })



        
        KuikaAppManager.hideSpinner(this);
        return isErrorOccurred;
    }
		TalebeAlternatifUrunEkleComponent_375056_onChange1_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }

				stateVars.SetValueOf = await ReactSystemFunctions.setValueOf(this, ReactSystemFunctions.convertToTypeByName("talebealternatifurunekle_452629_value", "string"), "", null, "Id");
				stateVars.SetValueOf = await ReactSystemFunctions.setValueOf(this, ReactSystemFunctions.convertToTypeByName("talebealternatifurunekle_570898_value", "string"), "", null, "Dial");
				stateVars.SetValueOf = await ReactSystemFunctions.setValueOf(this, ReactSystemFunctions.convertToTypeByName("talebealternatifurunekle_523925_value", "string"), "", null, "Bracelet");
				
				stateVars.dataSource_452629 = stateVars.TM_GetProductReferanceAlternatif ?? this.state.TM_GetProductReferanceAlternatif;
				stateVars.dataSource_452629 = stateVars.TM_GetProductReferanceAlternatif ?? this.state.TM_GetProductReferanceAlternatif;

		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

            
            return isErrorOccurred;
        }




    TalebeAlternatifUrunEkleComponent_452629_onChange = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
		KuikaAppManager.increaseServerRequestCount();

        let localVar = {
				Brand_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "talebealternatifurunekle_375056_value", "value", "TM_GetProductBrandAlternatif", "brand", "brand")), "string"),
				Referance_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "talebealternatifurunekle_452629_value", "value", "TM_GetProductReferanceAlternatif", "id", "referance")), "string")
        }

		KuikaAppManager.showSpinner(this);
		
        if (true) {
        KuikaAppManager.showSpinner(this);
        }
        let result = await KuikaAppManager.ApiRequest(this, "TalebeAlternatifUrunEkle/TalebeAlternatifUrunEkleComponent_452629_onChange", localVar)
        if (!KMainFunctions.IsResStatus2XX(result)) return true;

			stateVars.TM_GetProductDialAlternatif = result?.data.tM_GetProductDialAlternatif;
			
			formVars.talebealternatifurunekle_570898_options = stateVars.TM_GetProductDialAlternatif;
			this.props.form?.setFieldsValue(formVars);
			
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.TalebeAlternatifUrunEkleComponent_452629_onChange1_();
                  resolve();
                });
          })



        
        KuikaAppManager.hideSpinner(this);
        return isErrorOccurred;
    }
		TalebeAlternatifUrunEkleComponent_452629_onChange1_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }

				stateVars.SetValueOf = await ReactSystemFunctions.setValueOf(this, ReactSystemFunctions.convertToTypeByName("talebealternatifurunekle_570898_value", "string"), "", null, "Dial");
				stateVars.SetValueOf = await ReactSystemFunctions.setValueOf(this, ReactSystemFunctions.convertToTypeByName("talebealternatifurunekle_523925_value", "string"), "", null, "Bracelet");
				
				stateVars.dataSource_570898 = stateVars.TM_GetProductDialAlternatif ?? this.state.TM_GetProductDialAlternatif;
				stateVars.dataSource_570898 = stateVars.TM_GetProductDialAlternatif ?? this.state.TM_GetProductDialAlternatif;

		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

            
            return isErrorOccurred;
        }




    TalebeAlternatifUrunEkleComponent_570898_onChange = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
		KuikaAppManager.increaseServerRequestCount();

        let localVar = {
				Brand_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "talebealternatifurunekle_375056_value", "value", "TM_GetProductBrandAlternatif", "brand", "brand")), "string"),
				Referance_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "talebealternatifurunekle_452629_value", "value", "TM_GetProductReferanceAlternatif", "id", "referance")), "string"),
				Dial_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "talebealternatifurunekle_570898_value", "value", "TM_GetProductDialAlternatif", "dial", "dial")), "string")
        }

		KuikaAppManager.showSpinner(this);
		
        if (true) {
        KuikaAppManager.showSpinner(this);
        }
        let result = await KuikaAppManager.ApiRequest(this, "TalebeAlternatifUrunEkle/TalebeAlternatifUrunEkleComponent_570898_onChange", localVar)
        if (!KMainFunctions.IsResStatus2XX(result)) return true;

			stateVars.TM_GetProductBraceletAlternatif = result?.data.tM_GetProductBraceletAlternatif;
			
			formVars.talebealternatifurunekle_523925_options = stateVars.TM_GetProductBraceletAlternatif;
			this.props.form?.setFieldsValue(formVars);
			
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.TalebeAlternatifUrunEkleComponent_570898_onChange1_();
                  resolve();
                });
          })



        
        KuikaAppManager.hideSpinner(this);
        return isErrorOccurred;
    }
		TalebeAlternatifUrunEkleComponent_570898_onChange1_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }

				stateVars.SetValueOf = await ReactSystemFunctions.setValueOf(this, ReactSystemFunctions.convertToTypeByName("talebealternatifurunekle_523925_value", "string"), "", null, "Bracelet");
				
				stateVars.dataSource_523925 = stateVars.TM_GetProductBraceletAlternatif ?? this.state.TM_GetProductBraceletAlternatif;
				stateVars.dataSource_523925 = stateVars.TM_GetProductBraceletAlternatif ?? this.state.TM_GetProductBraceletAlternatif;

		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

            
            return isErrorOccurred;
        }




    TalebeAlternatifUrunEkleComponent_523925_onChange = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
		KuikaAppManager.increaseServerRequestCount();

        let localVar = {
				Brand_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "talebealternatifurunekle_375056_value", "value", "TM_GetProductBrandAlternatif", "brand", "brand")), "string"),
				Referance_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "talebealternatifurunekle_452629_value", "value", "TM_GetProductReferanceAlternatif", "id", "referance")), "string"),
				Dial_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "talebealternatifurunekle_570898_value", "value", "TM_GetProductDialAlternatif", "dial", "dial")), "string"),
				Bracelet_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "talebealternatifurunekle_523925_value", "value", "TM_GetProductBraceletAlternatif", "bracelet", "bracelet")), "string"),
				LeadId_1: ReactSystemFunctions.convertToTypeByName(this.props.screenInputs.LeadId ?? this.props.screenInputs.leadid, "Guid"),
				ProductId_1: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, (stateVars.TM_GetProductForAltModel !== undefined ? (stateVars.TM_GetProductForAltModel?.length > 0 ? stateVars.TM_GetProductForAltModel[0].id : null) : (this.state.TM_GetProductForAltModel?.length > 0 ? this.state.TM_GetProductForAltModel[0].id : null))), "Guid"),
				ProductId_2: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, (stateVars.TM_GetProductForAltModel !== undefined ? (stateVars.TM_GetProductForAltModel?.length > 0 ? stateVars.TM_GetProductForAltModel[0].id : null) : (this.state.TM_GetProductForAltModel?.length > 0 ? this.state.TM_GetProductForAltModel[0].id : null))), "Guid")
        }

		KuikaAppManager.showSpinner(this);
		
        if (true) {
        KuikaAppManager.showSpinner(this);
        }
        let result = await KuikaAppManager.ApiRequest(this, "TalebeAlternatifUrunEkle/TalebeAlternatifUrunEkleComponent_523925_onChange", localVar)
        if (!KMainFunctions.IsResStatus2XX(result)) return true;

			stateVars.TM_GetProductForAltModel = result?.data.tM_GetProductForAltModel;
			stateVars.GetAlternativeProductStockByLeadAndProductId = result?.data.getAlternativeProductStockByLeadAndProductId;
			formVars.talebealternatifurunekle_507956_value = ReactSystemFunctions.toString(this, (stateVars.GetAlternativeProductStockByLeadAndProductId !== undefined ? (stateVars.GetAlternativeProductStockByLeadAndProductId?.length > 0 ? stateVars.GetAlternativeProductStockByLeadAndProductId[0].productName : null) : (this.state.GetAlternativeProductStockByLeadAndProductId?.length > 0 ? this.state.GetAlternativeProductStockByLeadAndProductId[0].productName : null)));
			formVars.talebealternatifurunekle_180473_value = ReactSystemFunctions.toString(this, (stateVars.GetAlternativeProductStockByLeadAndProductId !== undefined ? (stateVars.GetAlternativeProductStockByLeadAndProductId?.length > 0 ? stateVars.GetAlternativeProductStockByLeadAndProductId[0].brand : null) : (this.state.GetAlternativeProductStockByLeadAndProductId?.length > 0 ? this.state.GetAlternativeProductStockByLeadAndProductId[0].brand : null)));
			formVars.talebealternatifurunekle_879123_value = ReactSystemFunctions.toString(this, (stateVars.GetAlternativeProductStockByLeadAndProductId !== undefined ? (stateVars.GetAlternativeProductStockByLeadAndProductId?.length > 0 ? stateVars.GetAlternativeProductStockByLeadAndProductId[0].referance : null) : (this.state.GetAlternativeProductStockByLeadAndProductId?.length > 0 ? this.state.GetAlternativeProductStockByLeadAndProductId[0].referance : null)));
			formVars.talebealternatifurunekle_30161_value = ReactSystemFunctions.toString(this, (stateVars.GetAlternativeProductStockByLeadAndProductId !== undefined ? (stateVars.GetAlternativeProductStockByLeadAndProductId?.length > 0 ? stateVars.GetAlternativeProductStockByLeadAndProductId[0].dial : null) : (this.state.GetAlternativeProductStockByLeadAndProductId?.length > 0 ? this.state.GetAlternativeProductStockByLeadAndProductId[0].dial : null)));
			formVars.talebealternatifurunekle_496121_value = ReactSystemFunctions.toString(this, (stateVars.GetAlternativeProductStockByLeadAndProductId !== undefined ? (stateVars.GetAlternativeProductStockByLeadAndProductId?.length > 0 ? stateVars.GetAlternativeProductStockByLeadAndProductId[0].bracelet : null) : (this.state.GetAlternativeProductStockByLeadAndProductId?.length > 0 ? this.state.GetAlternativeProductStockByLeadAndProductId[0].bracelet : null)));
			formVars.talebealternatifurunekle_4777_value = ReactSystemFunctions.toString(this, (stateVars.GetAlternativeProductStockByLeadAndProductId !== undefined ? (stateVars.GetAlternativeProductStockByLeadAndProductId?.length > 0 ? stateVars.GetAlternativeProductStockByLeadAndProductId[0].categoryName : null) : (this.state.GetAlternativeProductStockByLeadAndProductId?.length > 0 ? this.state.GetAlternativeProductStockByLeadAndProductId[0].categoryName : null)));
			formVars.talebealternatifurunekle_425110_value = ReactSystemFunctions.toString(this, (stateVars.GetAlternativeProductStockByLeadAndProductId !== undefined ? (stateVars.GetAlternativeProductStockByLeadAndProductId?.length > 0 ? stateVars.GetAlternativeProductStockByLeadAndProductId[0].categoryName : null) : (this.state.GetAlternativeProductStockByLeadAndProductId?.length > 0 ? this.state.GetAlternativeProductStockByLeadAndProductId[0].categoryName : null)));
			formVars.talebealternatifurunekle_836699_value = ReactSystemFunctions.toString(this, (stateVars.GetAlternativeProductStockByLeadAndProductId !== undefined ? (stateVars.GetAlternativeProductStockByLeadAndProductId?.length > 0 ? stateVars.GetAlternativeProductStockByLeadAndProductId[0].categoryName : null) : (this.state.GetAlternativeProductStockByLeadAndProductId?.length > 0 ? this.state.GetAlternativeProductStockByLeadAndProductId[0].categoryName : null)));
			formVars.talebealternatifurunekle_196080_value = ReactSystemFunctions.toString(this, (stateVars.GetAlternativeProductStockByLeadAndProductId !== undefined ? (stateVars.GetAlternativeProductStockByLeadAndProductId?.length > 0 ? stateVars.GetAlternativeProductStockByLeadAndProductId[0].categoryName : null) : (this.state.GetAlternativeProductStockByLeadAndProductId?.length > 0 ? this.state.GetAlternativeProductStockByLeadAndProductId[0].categoryName : null)));
			stateVars.isComp821230Visible = ((ReactSystemFunctions.isNotEmpty(ReactSystemFunctions.value(this, (stateVars.GetAlternativeProductStockByLeadAndProductId !== undefined ? (stateVars.GetAlternativeProductStockByLeadAndProductId?.length > 0 ? stateVars.GetAlternativeProductStockByLeadAndProductId[0].productId : null) : (this.state.GetAlternativeProductStockByLeadAndProductId?.length > 0 ? this.state.GetAlternativeProductStockByLeadAndProductId[0].productId : null))), ReactSystemFunctions.convertToTypeByName("True", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp4777Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.toString(this, (stateVars.GetAlternativeProductStockByLeadAndProductId !== undefined ? (stateVars.GetAlternativeProductStockByLeadAndProductId?.length > 0 ? stateVars.GetAlternativeProductStockByLeadAndProductId[0].categoryName : null) : (this.state.GetAlternativeProductStockByLeadAndProductId?.length > 0 ? this.state.GetAlternativeProductStockByLeadAndProductId[0].categoryName : null))), ReactSystemFunctions.convertToTypeByName("Kategori 2", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp425110Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.toString(this, (stateVars.GetAlternativeProductStockByLeadAndProductId !== undefined ? (stateVars.GetAlternativeProductStockByLeadAndProductId?.length > 0 ? stateVars.GetAlternativeProductStockByLeadAndProductId[0].categoryName : null) : (this.state.GetAlternativeProductStockByLeadAndProductId?.length > 0 ? this.state.GetAlternativeProductStockByLeadAndProductId[0].categoryName : null))), ReactSystemFunctions.convertToTypeByName("Kategori 1", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp836699Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.toString(this, (stateVars.GetAlternativeProductStockByLeadAndProductId !== undefined ? (stateVars.GetAlternativeProductStockByLeadAndProductId?.length > 0 ? stateVars.GetAlternativeProductStockByLeadAndProductId[0].categoryName : null) : (this.state.GetAlternativeProductStockByLeadAndProductId?.length > 0 ? this.state.GetAlternativeProductStockByLeadAndProductId[0].categoryName : null))), ReactSystemFunctions.convertToTypeByName("DEFAULT", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp196080Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.toString(this, (stateVars.GetAlternativeProductStockByLeadAndProductId !== undefined ? (stateVars.GetAlternativeProductStockByLeadAndProductId?.length > 0 ? stateVars.GetAlternativeProductStockByLeadAndProductId[0].categoryName : null) : (this.state.GetAlternativeProductStockByLeadAndProductId?.length > 0 ? this.state.GetAlternativeProductStockByLeadAndProductId[0].categoryName : null))), ReactSystemFunctions.convertToTypeByName("Kategori 3", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp793217Visible = ((ReactSystemFunctions.isGreaterThan(ReactSystemFunctions.value(this, (stateVars.GetAlternativeProductStockByLeadAndProductId !== undefined ? (stateVars.GetAlternativeProductStockByLeadAndProductId?.length > 0 ? stateVars.GetAlternativeProductStockByLeadAndProductId[0].totalStock : null) : (this.state.GetAlternativeProductStockByLeadAndProductId?.length > 0 ? this.state.GetAlternativeProductStockByLeadAndProductId[0].totalStock : null))), ReactSystemFunctions.convertToTypeByName("0", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp466478Visible = ((ReactSystemFunctions.isGreaterThan(ReactSystemFunctions.value(this, (stateVars.GetAlternativeProductStockByLeadAndProductId !== undefined ? (stateVars.GetAlternativeProductStockByLeadAndProductId?.length > 0 ? stateVars.GetAlternativeProductStockByLeadAndProductId[0].availableStock : null) : (this.state.GetAlternativeProductStockByLeadAndProductId?.length > 0 ? this.state.GetAlternativeProductStockByLeadAndProductId[0].availableStock : null))), ReactSystemFunctions.convertToTypeByName("0", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp946312Visible = ((ReactSystemFunctions.isLessThan(ReactSystemFunctions.value(this, (stateVars.GetAlternativeProductStockByLeadAndProductId !== undefined ? (stateVars.GetAlternativeProductStockByLeadAndProductId?.length > 0 ? stateVars.GetAlternativeProductStockByLeadAndProductId[0].totalStock : null) : (this.state.GetAlternativeProductStockByLeadAndProductId?.length > 0 ? this.state.GetAlternativeProductStockByLeadAndProductId[0].totalStock : null))), ReactSystemFunctions.convertToTypeByName("1", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp698453Visible = ((ReactSystemFunctions.isLessThan(ReactSystemFunctions.value(this, (stateVars.GetAlternativeProductStockByLeadAndProductId !== undefined ? (stateVars.GetAlternativeProductStockByLeadAndProductId?.length > 0 ? stateVars.GetAlternativeProductStockByLeadAndProductId[0].availableStock : null) : (this.state.GetAlternativeProductStockByLeadAndProductId?.length > 0 ? this.state.GetAlternativeProductStockByLeadAndProductId[0].availableStock : null))), ReactSystemFunctions.convertToTypeByName("1", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp669205Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, (stateVars.GetAlternativeProductStockByLeadAndProductId !== undefined ? (stateVars.GetAlternativeProductStockByLeadAndProductId?.length > 0 ? stateVars.GetAlternativeProductStockByLeadAndProductId[0].hasActiveLead : null) : (this.state.GetAlternativeProductStockByLeadAndProductId?.length > 0 ? this.state.GetAlternativeProductStockByLeadAndProductId[0].hasActiveLead : null))), ReactSystemFunctions.convertToTypeByName("True", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp159985Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, (stateVars.GetAlternativeProductStockByLeadAndProductId !== undefined ? (stateVars.GetAlternativeProductStockByLeadAndProductId?.length > 0 ? stateVars.GetAlternativeProductStockByLeadAndProductId[0].hasActiveLead : null) : (this.state.GetAlternativeProductStockByLeadAndProductId?.length > 0 ? this.state.GetAlternativeProductStockByLeadAndProductId[0].hasActiveLead : null))), ReactSystemFunctions.convertToTypeByName("False", "string"))) === true ? "visible" : "hidden")
			stateVars.GetAltrenativeProductStockInfoByProductId = result?.data.getAltrenativeProductStockInfoByProductId;
			
			this.props.form?.setFieldsValue(formVars);
			
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.TalebeAlternatifUrunEkleComponent_523925_onChange1_();
                  resolve();
                });
          })



        
        KuikaAppManager.hideSpinner(this);
        return isErrorOccurred;
    }
		TalebeAlternatifUrunEkleComponent_523925_onChange1_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }

				formVars.talebealternatifurunekle_507956_value = ReactSystemFunctions.toString(this, (stateVars.GetAlternativeProductStockByLeadAndProductId !== undefined ? (stateVars.GetAlternativeProductStockByLeadAndProductId?.length > 0 ? stateVars.GetAlternativeProductStockByLeadAndProductId[0].productName : null) : (this.state.GetAlternativeProductStockByLeadAndProductId?.length > 0 ? this.state.GetAlternativeProductStockByLeadAndProductId[0].productName : null)));

				formVars.talebealternatifurunekle_180473_value = ReactSystemFunctions.toString(this, (stateVars.GetAlternativeProductStockByLeadAndProductId !== undefined ? (stateVars.GetAlternativeProductStockByLeadAndProductId?.length > 0 ? stateVars.GetAlternativeProductStockByLeadAndProductId[0].brand : null) : (this.state.GetAlternativeProductStockByLeadAndProductId?.length > 0 ? this.state.GetAlternativeProductStockByLeadAndProductId[0].brand : null)));

				formVars.talebealternatifurunekle_879123_value = ReactSystemFunctions.toString(this, (stateVars.GetAlternativeProductStockByLeadAndProductId !== undefined ? (stateVars.GetAlternativeProductStockByLeadAndProductId?.length > 0 ? stateVars.GetAlternativeProductStockByLeadAndProductId[0].referance : null) : (this.state.GetAlternativeProductStockByLeadAndProductId?.length > 0 ? this.state.GetAlternativeProductStockByLeadAndProductId[0].referance : null)));

				formVars.talebealternatifurunekle_30161_value = ReactSystemFunctions.toString(this, (stateVars.GetAlternativeProductStockByLeadAndProductId !== undefined ? (stateVars.GetAlternativeProductStockByLeadAndProductId?.length > 0 ? stateVars.GetAlternativeProductStockByLeadAndProductId[0].dial : null) : (this.state.GetAlternativeProductStockByLeadAndProductId?.length > 0 ? this.state.GetAlternativeProductStockByLeadAndProductId[0].dial : null)));

				formVars.talebealternatifurunekle_496121_value = ReactSystemFunctions.toString(this, (stateVars.GetAlternativeProductStockByLeadAndProductId !== undefined ? (stateVars.GetAlternativeProductStockByLeadAndProductId?.length > 0 ? stateVars.GetAlternativeProductStockByLeadAndProductId[0].bracelet : null) : (this.state.GetAlternativeProductStockByLeadAndProductId?.length > 0 ? this.state.GetAlternativeProductStockByLeadAndProductId[0].bracelet : null)));

				formVars.talebealternatifurunekle_4777_value = ReactSystemFunctions.toString(this, (stateVars.GetAlternativeProductStockByLeadAndProductId !== undefined ? (stateVars.GetAlternativeProductStockByLeadAndProductId?.length > 0 ? stateVars.GetAlternativeProductStockByLeadAndProductId[0].categoryName : null) : (this.state.GetAlternativeProductStockByLeadAndProductId?.length > 0 ? this.state.GetAlternativeProductStockByLeadAndProductId[0].categoryName : null)));

				formVars.talebealternatifurunekle_425110_value = ReactSystemFunctions.toString(this, (stateVars.GetAlternativeProductStockByLeadAndProductId !== undefined ? (stateVars.GetAlternativeProductStockByLeadAndProductId?.length > 0 ? stateVars.GetAlternativeProductStockByLeadAndProductId[0].categoryName : null) : (this.state.GetAlternativeProductStockByLeadAndProductId?.length > 0 ? this.state.GetAlternativeProductStockByLeadAndProductId[0].categoryName : null)));

				formVars.talebealternatifurunekle_836699_value = ReactSystemFunctions.toString(this, (stateVars.GetAlternativeProductStockByLeadAndProductId !== undefined ? (stateVars.GetAlternativeProductStockByLeadAndProductId?.length > 0 ? stateVars.GetAlternativeProductStockByLeadAndProductId[0].categoryName : null) : (this.state.GetAlternativeProductStockByLeadAndProductId?.length > 0 ? this.state.GetAlternativeProductStockByLeadAndProductId[0].categoryName : null)));

				formVars.talebealternatifurunekle_196080_value = ReactSystemFunctions.toString(this, (stateVars.GetAlternativeProductStockByLeadAndProductId !== undefined ? (stateVars.GetAlternativeProductStockByLeadAndProductId?.length > 0 ? stateVars.GetAlternativeProductStockByLeadAndProductId[0].categoryName : null) : (this.state.GetAlternativeProductStockByLeadAndProductId?.length > 0 ? this.state.GetAlternativeProductStockByLeadAndProductId[0].categoryName : null)));

				
				stateVars.dataSource_469879 = stateVars.GetAltrenativeProductStockInfoByProductId ?? this.state.GetAltrenativeProductStockInfoByProductId;

		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

            
            return isErrorOccurred;
        }




    TalebeAlternatifUrunEkleComponent_986401_onClick = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
		KuikaAppManager.increaseServerRequestCount();

        let localVar = {
				LeadId_0: ReactSystemFunctions.convertToTypeByName(this.props.screenInputs.LeadId ?? this.props.screenInputs.leadid, "Guid"),
				ProductId_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, (stateVars.TM_GetProductForAltModel !== undefined ? (stateVars.TM_GetProductForAltModel?.length > 0 ? stateVars.TM_GetProductForAltModel[0].id : null) : (this.state.TM_GetProductForAltModel?.length > 0 ? this.state.TM_GetProductForAltModel[0].id : null))), "Guid"),
				LeadId_1: ReactSystemFunctions.convertToTypeByName(this.props.screenInputs.LeadId ?? this.props.screenInputs.leadid, "Guid")
        }

		KuikaAppManager.showSpinner(this);
		
        if (true) {
        KuikaAppManager.showSpinner(this);
        }
        let result = await KuikaAppManager.ApiRequest(this, "TalebeAlternatifUrunEkle/TalebeAlternatifUrunEkleComponent_986401_onClick", localVar)
        if (!KMainFunctions.IsResStatus2XX(result)) return true;

			stateVars.TM_InsertLeadAlternativeModel = result?.data.tM_InsertLeadAlternativeModel;
			stateVars.TM_GetLeadAlternativeModel = result?.data.tM_GetLeadAlternativeModel;
			
			stateVars.isComp505914Visible = ((ReactSystemFunctions.isEmpty(ReactSystemFunctions.value(this, (stateVars.TM_GetLeadAlternativeModel !== undefined ? (stateVars.TM_GetLeadAlternativeModel?.length > 0 ? stateVars.TM_GetLeadAlternativeModel[0].productId : null) : (this.state.TM_GetLeadAlternativeModel?.length > 0 ? this.state.TM_GetLeadAlternativeModel[0].productId : null))), ReactSystemFunctions.convertToTypeByName("True", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp976246Visible = ((ReactSystemFunctions.isNotEmpty(ReactSystemFunctions.value(this, (stateVars.TM_GetLeadAlternativeModel !== undefined ? (stateVars.TM_GetLeadAlternativeModel?.length > 0 ? stateVars.TM_GetLeadAlternativeModel[0].productId : null) : (this.state.TM_GetLeadAlternativeModel?.length > 0 ? this.state.TM_GetLeadAlternativeModel[0].productId : null))), ReactSystemFunctions.convertToTypeByName("True", "string"))) === true ? "visible" : "hidden")
			this.props.form?.setFieldsValue(formVars);
			
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.TalebeAlternatifUrunEkleComponent_986401_onClick1_();
                  resolve();
                });
          })



        
        KuikaAppManager.hideSpinner(this);
        return isErrorOccurred;
    }
		TalebeAlternatifUrunEkleComponent_986401_onClick1_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }

				stateVars.Notify = await ReactSystemFunctions.notify(this, ReactSystemFunctions.toString(this, (stateVars.TM_InsertLeadAlternativeModel !== undefined ? (stateVars.TM_InsertLeadAlternativeModel?.length > 0 ? stateVars.TM_InsertLeadAlternativeModel[0].message : null) : (this.state.TM_InsertLeadAlternativeModel?.length > 0 ? this.state.TM_InsertLeadAlternativeModel[0].message : null))), ReactSystemFunctions.convertToTypeByName("default", "string"), ReactSystemFunctions.convertToTypeByName("bottom-right", "string"), 2, ReactSystemFunctions.convertToTypeByName("", "string"), ReactSystemFunctions.convertToTypeByName("", "string"), 0);
				stateVars.SetValueOf = await ReactSystemFunctions.setValueOf(this, ReactSystemFunctions.convertToTypeByName("talebealternatifurunekle_375056_value", "string"), "", null, "Brand");
				stateVars.SetValueOf = await ReactSystemFunctions.setValueOf(this, ReactSystemFunctions.convertToTypeByName("talebealternatifurunekle_452629_value", "string"), "", null, "Id");
				stateVars.SetValueOf = await ReactSystemFunctions.setValueOf(this, ReactSystemFunctions.convertToTypeByName("talebealternatifurunekle_570898_value", "string"), "", null, "Dial");
				stateVars.SetValueOf = await ReactSystemFunctions.setValueOf(this, ReactSystemFunctions.convertToTypeByName("talebealternatifurunekle_523925_value", "string"), "", null, "Bracelet");
				
				stateVars.dataSource_976246 = stateVars.TM_GetLeadAlternativeModel ?? this.state.TM_GetLeadAlternativeModel;

		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

            
            return isErrorOccurred;
        }




    TalebeAlternatifUrunEkleComponent_667292_onClick = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
		KuikaAppManager.increaseServerRequestCount();

        let localVar = {
				Id_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, "talebealternatifurunekle_976246_value", "alternativeModelId"), "Guid"),
				LeadId_1: ReactSystemFunctions.convertToTypeByName(this.props.screenInputs.LeadId ?? this.props.screenInputs.leadid, "Guid")
        }

		KuikaAppManager.showSpinner(this);
		
        if (true) {
        KuikaAppManager.showSpinner(this);
        }
        let result = await KuikaAppManager.ApiRequest(this, "TalebeAlternatifUrunEkle/TalebeAlternatifUrunEkleComponent_667292_onClick", localVar)
        if (!KMainFunctions.IsResStatus2XX(result)) return true;

			stateVars.TM_DeleteLeadAlternativeModel = result?.data.tM_DeleteLeadAlternativeModel;
			stateVars.TM_GetLeadAlternativeModel = result?.data.tM_GetLeadAlternativeModel;
			
			stateVars.isComp505914Visible = ((ReactSystemFunctions.isEmpty(ReactSystemFunctions.value(this, (stateVars.TM_GetLeadAlternativeModel !== undefined ? (stateVars.TM_GetLeadAlternativeModel?.length > 0 ? stateVars.TM_GetLeadAlternativeModel[0].productId : null) : (this.state.TM_GetLeadAlternativeModel?.length > 0 ? this.state.TM_GetLeadAlternativeModel[0].productId : null))), ReactSystemFunctions.convertToTypeByName("True", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp976246Visible = ((ReactSystemFunctions.isNotEmpty(ReactSystemFunctions.value(this, (stateVars.TM_GetLeadAlternativeModel !== undefined ? (stateVars.TM_GetLeadAlternativeModel?.length > 0 ? stateVars.TM_GetLeadAlternativeModel[0].productId : null) : (this.state.TM_GetLeadAlternativeModel?.length > 0 ? this.state.TM_GetLeadAlternativeModel[0].productId : null))), ReactSystemFunctions.convertToTypeByName("True", "string"))) === true ? "visible" : "hidden")
			this.props.form?.setFieldsValue(formVars);
			
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.TalebeAlternatifUrunEkleComponent_667292_onClick1_();
                  resolve();
                });
          })



        
        KuikaAppManager.hideSpinner(this);
        return isErrorOccurred;
    }
		TalebeAlternatifUrunEkleComponent_667292_onClick1_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }

				stateVars.Notify = await ReactSystemFunctions.notify(this, ReactSystemFunctions.toString(this, (stateVars.TM_DeleteLeadAlternativeModel !== undefined ? (stateVars.TM_DeleteLeadAlternativeModel?.length > 0 ? stateVars.TM_DeleteLeadAlternativeModel[0].message : null) : (this.state.TM_DeleteLeadAlternativeModel?.length > 0 ? this.state.TM_DeleteLeadAlternativeModel[0].message : null))), ReactSystemFunctions.convertToTypeByName("default", "string"), ReactSystemFunctions.convertToTypeByName("bottom-right", "string"), 2, ReactSystemFunctions.convertToTypeByName("", "string"), ReactSystemFunctions.convertToTypeByName("", "string"), 0);
				
				stateVars.dataSource_976246 = stateVars.TM_GetLeadAlternativeModel ?? this.state.TM_GetLeadAlternativeModel;

		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

            
            return isErrorOccurred;
        }






    async callCallbackFunction(diId: number, isFromMaster: boolean = false) {
        let isErrorOccurred = false;
		let pageInitCallerNavDiIDs = [] as number[];
		if (isFromMaster || pageInitCallerNavDiIDs.indexOf(diId) > -1) {
			await this.TalebeAlternatifUrunEklePageInit();
		}

    }


}
