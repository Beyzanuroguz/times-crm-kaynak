import React from "react";
import Axios, { AxiosResponse } from "axios";
import { KuikaAppManager } from "../../shared/utilty/kuika-app-manager";
import { ReactSystemFunctions } from "../../shared/utilty/react-system-functions";
import { KNavigator } from "../../shared/hoc/with-history";
import { KContext } from "../../shared/hoc/with-context";
import { useLocation } from "react-router-dom";
import { FormInstance } from "antd/es/form";
import { Guid } from "guid-typescript";
import Swal from "sweetalert2";
import { KMainFunctions } from "../../shared/utilty/main-functions";
import moment from "moment";
import { IValidationData } from "../../models/dto/validation-data";
import { IStripePayment } from "../../models/dto/stripe-payment";
import { IUserInfoDto } from "../../models/dto/user-info.dto";
import { UserService } from "../../services/user-service";
import { kuikaCoreWasmBridgeService } from "../../services/_singletons";
import _ from "lodash";
import mqtt, { MqttClient } from "mqtt";
import { IMqttResult } from "../../models/dto/mqtt.dto";


declare let window: any;

export interface IUrunVeMagazaStokDetay_ScreenProps {
  navigator: KNavigator;
  form: FormInstance<any>;
  googleLogin: any;
  screenInputs: any;
  context: KContext;
  initialValues: any;
  children: any;
}

export interface IUrunVeMagazaStokDetay_ScreenState {
    isSpinnerVisible: boolean;
    isPageVisible: boolean;
	isLeftMenuVisible: boolean;
    spinnerCount: number;
    selectedLanguage: string;
    isPageInitLoaded: false;
    isPageRecurringLoaded: false;

}

export class UrunVeMagazaStokDetay_ScreenBase extends React.PureComponent<IUrunVeMagazaStokDetay_ScreenProps, any> {

	urunvemagazastokdetay_126301_value_kuikaTableRef: React.RefObject<any>;
    ml=[{"Id":"d5a61d2b-bd60-485f-86e2-661e9ed4e486","Name":"en_US","ShortName":"English","IsDefault":true,"LanguagePhrases":[]},{"Id":"a6957019-97e5-410f-bae2-20cef64738f6","Name":"FixedValues","ShortName":"FixedValues","LanguagePhrases":[{"Id":276202,"PropertyName":"label","Value":"Stok ve Ürün Aramaya Dön"},{"Id":789243,"PropertyName":"value","Value":"Ürün ve Mağaza Stok Detayı"},{"Id":345933,"PropertyName":"value","Value":"Ürünün mağazalardaki stok ve müsaitlik durumunu inceleyin."},{"Id":676710,"PropertyName":"label","Value":"Merkeze Talep Aç"},{"Id":379037,"PropertyName":"value","Value":"Ürün Kodu"},{"Id":684,"PropertyName":"value","Value":"126711"},{"Id":857693,"PropertyName":"value","Value":"Ürün Adı"},{"Id":357925,"PropertyName":"value","Value":"Rolex Submariner Date"},{"Id":162536,"PropertyName":"value","Value":"Marka"},{"Id":783244,"PropertyName":"value","Value":"Rolex"},{"Id":50278,"PropertyName":"value","Value":"Kategori"},{"Id":379113,"PropertyName":"value","Value":"Saat"},{"Id":228190,"PropertyName":"value","Value":"Toplam Mağaza Stoğu"},{"Id":692841,"PropertyName":"value","Value":"7"},{"Id":9218,"PropertyName":"title","Value":"Mağaza"},{"Id":946220,"PropertyName":"value","Value":"Adana Times"},{"Id":177119,"PropertyName":"value","Value":"Kendi Mağazam"},{"Id":895591,"PropertyName":"title","Value":"Mevcut Stok"},{"Id":859053,"PropertyName":"value","Value":"3"},{"Id":171404,"PropertyName":"title","Value":"Aktif Rezerv"},{"Id":594372,"PropertyName":"value","Value":"1"},{"Id":826903,"PropertyName":"title","Value":"Müsait Stok"},{"Id":288424,"PropertyName":"value","Value":"4"},{"Id":272152,"PropertyName":"value","Value":"1"},{"Id":808467,"PropertyName":"value","Value":"0"},{"Id":61938,"PropertyName":"title","Value":"İşlemler"},{"Id":288653,"PropertyName":"label","Value":"Transfer Talebi Aç"}]}]
    defaultML = "en_US"
    
    screenHash = ""
    


    constructor(props) {
        super(props);
		this.urunvemagazastokdetay_126301_value_kuikaTableRef = React.createRef();

        this.state = {
            isSpinnerVisible: false,
            isPageVisible: false,
            isLeftMenuVisible: false,
            spinnerCount: 0,
            selectedLanguage: "",
            isPageInitLoaded: false,
            isPageRecurringLoaded: false,
            
        }

        this.state.isPageVisible = true;
        
    }

    async componentDidMount() {

        if (KuikaAppManager.isPageInitPrevented()) {
            KuikaAppManager.calculateAndSetBodyHeight("urunvemagazastokdetay", "");
            return;
        }
        
        
        ReactSystemFunctions.validateToken()
        this.fillFormInitValues();
        if (true){
            
        }
        
        
        
        KuikaAppManager.calculateAndSetBodyHeight("urunvemagazastokdetay", "");

        if (ReactSystemFunctions.getIsMicroApp() === false) {
           window.parentScreen = this;
        }
    }

    componentWillUnmount() {
        
        
        

        if (ReactSystemFunctions.getIsMicroApp() === false) {
           window.parentScreen = null;
        }
    }

    

        
    componentDidUpdate= async (prevProps, prevState) => {
		KuikaAppManager.calculateAndSetBodyHeight("urunvemagazastokdetay", ""    );
        if (prevProps?.location?.search !== (this.props as any)?.location?.search) {
			
		}

        

        if (ReactSystemFunctions.getIsMicroApp() === false) {
            for (const key in prevState) {
                if (key.startsWith('NavVisible') && prevState[key] === true && this.state[key] === false) {
                    window.parentScreen = this;
                    break;
                }
            }
        }
	}

    fillFormInitValues() {
        this.props.form?.setFieldsValue({
});

    }

      setPageInitLoaded = (value: boolean) => {
        this.setState({ isPageInitLoaded: value });
      }

      setPageRecurringLoaded = (value: boolean) => {
        this.setState({ isPageRecurringLoaded: value });
      }

      clearFieldValidation = (changedValues: any) => {
        const fieldName = Object.keys(changedValues)[0];
        if (fieldName) {
          this.props.form?.setFields([
            {
              name: fieldName,
              errors: []
            }
          ]);
        }
      };

      




    async callCallbackFunction(diId: number, isFromMaster: boolean = false) {
        let isErrorOccurred = false;

    }


}
