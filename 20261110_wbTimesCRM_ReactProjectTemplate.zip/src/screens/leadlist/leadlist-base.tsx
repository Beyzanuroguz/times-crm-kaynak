import React from "react";
import Axios, { AxiosResponse } from "axios";
import { KuikaAppManager } from "../../shared/utilty/kuika-app-manager";
import { ReactSystemFunctions } from "../../shared/utilty/react-system-functions";
import { KNavigator } from "../../shared/hoc/with-history";
import { KContext } from "../../shared/hoc/with-context";
import { useLocation } from "react-router-dom";
import { FormInstance } from "antd/es/form";
import { Guid } from "guid-typescript";
import Swal from "sweetalert2";
import { KMainFunctions } from "../../shared/utilty/main-functions";
import moment from "moment";
import { IValidationData } from "../../models/dto/validation-data";
import { IStripePayment } from "../../models/dto/stripe-payment";
import { IUserInfoDto } from "../../models/dto/user-info.dto";
import { UserService } from "../../services/user-service";
import { kuikaCoreWasmBridgeService } from "../../services/_singletons";
import _ from "lodash";
import mqtt, { MqttClient } from "mqtt";
import { IMqttResult } from "../../models/dto/mqtt.dto";
import { MasterScreen_ScreenContext } from "../masterscreen/masterscreen-context";

declare let window: any;

export interface ILeadList_ScreenProps {
  navigator: KNavigator;
  form: FormInstance<any>;
  googleLogin: any;
  screenInputs: any;
  context: KContext;
  initialValues: any;
  children: any;
}

export interface ILeadList_ScreenState {
    isSpinnerVisible: boolean;
    isPageVisible: boolean;
	isLeftMenuVisible: boolean;
    spinnerCount: number;
    selectedLanguage: string;
    isPageInitLoaded: false;
    isPageRecurringLoaded: false;
	TM_GetLeads: any[];
	TM_GetLeads_dummy: any[];
	TMLeadProcessCountSummary: any[];
	TMLeadProcessCountSummary_dummy: any[];
	TM_GetProductCategory: any[];
	TM_GetProductCategory_dummy: any[];
	TM_GetProductReferanceFilter: any[];
	TM_GetProductReferanceFilter_dummy: any[];
	TM_GetCustomerByName: any[];
	TM_GetCustomerByName_dummy: any[];
	TM_GetStore: any[];
	TM_GetStore_dummy: any[];
	TM_GetSalesPerson: any[];
	TM_GetSalesPerson_dummy: any[];
	TM_GetLeadStatus: any[];
	TM_GetLeadStatus_dummy: any[];
	TM_GetLeadProcess: any[];
	TM_GetLeadProcess_dummy: any[];
	TMGetProductAllLeadsMultiSelect: any[];
	TMGetProductAllLeadsMultiSelect_dummy: any[];
	NAVIGATE: any;
	NAVIGATE_dummy: any;
	ChangeVisibilityOf: string;
	ChangeVisibilityOf_dummy: string;
	SetValueOf: any;
	SetValueOf_dummy: any;
	ExportExcel: any;
	ExportExcel_dummy: any;
	isComp188701Visible: 'visible' | 'hidden';
	isComp169183Visible: 'visible' | 'hidden';
	isComp921329Visible: 'visible' | 'hidden';
	isComp378811Visible: 'visible' | 'hidden';
	isComp65859Visible: 'visible' | 'hidden';
	isComp193325Visible: 'visible' | 'hidden';
	isComp954115Visible: 'visible' | 'hidden';
	isComp562166Visible: 'visible' | 'hidden';
	isComp400233Visible: 'visible' | 'hidden';
	isComp779571Visible: 'visible' | 'hidden';
	isComp668839Visible: 'visible' | 'hidden';
	isComp967789Visible: 'visible' | 'hidden';
	isComp408551Visible: 'visible' | 'hidden';
	isComp874659Visible: 'visible' | 'hidden';
	isComp391899Visible: 'visible' | 'hidden';
	isComp909224Visible: 'visible' | 'hidden';
	isComp383770Visible: 'visible' | 'hidden';
	isComp279981Visible: 'visible' | 'hidden';
	isComp616972Visible: 'visible' | 'hidden';
	isComp648813Visible: 'visible' | 'hidden';

}

export class LeadList_ScreenBase extends React.PureComponent<ILeadList_ScreenProps, any> {
    static contextType = MasterScreen_ScreenContext;
    declare context: React.ContextType<typeof MasterScreen_ScreenContext>;
	leadlist_980795_value_kuikaDateRef: React.RefObject<any>;
	leadlist_6623_value_kuikaDateRef: React.RefObject<any>;
	leadlist_414332_value_kuikaTableRef: React.RefObject<any>;
    ml=[{"Id":"d5a61d2b-bd60-485f-86e2-661e9ed4e486","Name":"en_US","ShortName":"English","IsDefault":true,"LanguagePhrases":[]},{"Id":"6db4d4e0-93be-4179-85f8-43f509bffc64","Name":"FixedValues","ShortName":"FixedValues","LanguagePhrases":[{"Id":309801,"PropertyName":"value","Value":"Talep Bilgileri"},{"Id":427766,"PropertyName":"value","Value":"Tüm talepleri görüntüleyin ve yönetin."},{"Id":418752,"PropertyName":"value","Value":"Talepler"},{"Id":782376,"PropertyName":"value","Value":"Onay Bekleyen"},{"Id":637220,"PropertyName":"value","Value":"Termin Bekleyen"},{"Id":150643,"PropertyName":"value","Value":"Onaylanan Talepler"},{"Id":174312,"PropertyName":"value","Value":"Reddedilen Talepler"},{"Id":879578,"PropertyName":"value","Value":"Teslim Bekleyen"},{"Id":840782,"PropertyName":"value","Value":"Teslim Edildi"},{"Id":820661,"PropertyName":"value","Value":"Talep Listesi"},{"Id":239508,"PropertyName":"label","Value":"Yeni Talep Ekle"},{"Id":77786,"PropertyName":"value","Value":"Filtre"},{"Id":917804,"PropertyName":"value","Value":"Müşteri Adı"},{"Id":288211,"PropertyName":"placeholder","Value":"Müşteri Adı"},{"Id":67577,"PropertyName":"value","Value":"Müşteri Telefon Numarası"},{"Id":776113,"PropertyName":"placeholder","Value":"Müşteri Telefon Numarası"},{"Id":951859,"PropertyName":"value","Value":"Ürün Adı"},{"Id":576673,"PropertyName":"placeholder","Value":"Ürün Adı"},{"Id":747549,"PropertyName":"value","Value":"Kategori"},{"Id":836823,"PropertyName":"placeholder","Value":"Kategori"},{"Id":443669,"PropertyName":"value","Value":"Mağaza"},{"Id":314150,"PropertyName":"placeholder","Value":"Mağaza"},{"Id":843290,"PropertyName":"value","Value":"Satış Danışmanı"},{"Id":872239,"PropertyName":"placeholder","Value":"Satış Danışmanı"},{"Id":969723,"PropertyName":"value","Value":"Talep Durumu"},{"Id":161661,"PropertyName":"placeholder","Value":"Talep Durumu"},{"Id":204468,"PropertyName":"value","Value":"Başlangıç Tarihi"},{"Id":720982,"PropertyName":"value","Value":"Bitiş Tarihi"},{"Id":937502,"PropertyName":"label","Value":"Filtre Uygula"},{"Id":873248,"PropertyName":"label","Value":"Filtre Temizle"},{"Id":651437,"PropertyName":"value","Value":"Talep Numarasına Göre Ara"},{"Id":60588,"PropertyName":"placeholder","Value":"Talep Numarası Giriniz"},{"Id":378811,"PropertyName":"label","Value":"Export Excel"},{"Id":414332,"PropertyName":"nodatafoundmessage","Value":"Talep Bilgisi Bulunmamaktadır"},{"Id":30651,"PropertyName":"title","Value":"Talep Tarihi"},{"Id":356666,"PropertyName":"value","Value":"[datafield:taleptarihi]"},{"Id":348056,"PropertyName":"title","Value":"Talep Numarası"},{"Id":96516,"PropertyName":"value","Value":"[datafield:leadnumarasi]"},{"Id":488464,"PropertyName":"title","Value":"Mağaza"},{"Id":693455,"PropertyName":"value","Value":"[datafield:storename]"},{"Id":323059,"PropertyName":"title","Value":"Marka"},{"Id":699705,"PropertyName":"value","Value":"[datafield:brand]"},{"Id":213076,"PropertyName":"title","Value":"Kategori"},{"Id":65859,"PropertyName":"value","Value":"[datafield:categoryname]"},{"Id":193325,"PropertyName":"value","Value":"[datafield:categoryname]"},{"Id":954115,"PropertyName":"value","Value":"[datafield:categoryname]"},{"Id":562166,"PropertyName":"value","Value":"[datafield:categoryname]"},{"Id":27261,"PropertyName":"title","Value":"Ürün Adı"},{"Id":386305,"PropertyName":"value","Value":"[datafield:productname]"},{"Id":196778,"PropertyName":"title","Value":"Müşteri"},{"Id":128019,"PropertyName":"value","Value":"[datafield:musteri]"},{"Id":358651,"PropertyName":"title","Value":"Takip Durum"},{"Id":400233,"PropertyName":"value","Value":"[datafield:leaddurumu]"},{"Id":779571,"PropertyName":"value","Value":"[datafield:leaddurumu]"},{"Id":893953,"PropertyName":"title","Value":"Sonraki Adım"},{"Id":594100,"PropertyName":"value","Value":"[datafield:sonrakiadim]"},{"Id":313797,"PropertyName":"title","Value":"Tahmini Teslimat"},{"Id":748065,"PropertyName":"value","Value":"[datafield:termintarihi]"},{"Id":799782,"PropertyName":"title","Value":"Rezerve Durumu"},{"Id":967789,"PropertyName":"value","Value":"Evet"},{"Id":408551,"PropertyName":"value","Value":"Onay Bekliyor"},{"Id":874659,"PropertyName":"value","Value":"Hayır"},{"Id":429749,"PropertyName":"title","Value":"Satış Danışmanı"},{"Id":598361,"PropertyName":"value","Value":"[datafield:satisdanismani]"},{"Id":195675,"PropertyName":"title","Value":"Talep Durum"},{"Id":391899,"PropertyName":"value","Value":"[datafield:processname]"},{"Id":909224,"PropertyName":"value","Value":"[datafield:processname]"},{"Id":383770,"PropertyName":"value","Value":"[datafield:processname]"},{"Id":279981,"PropertyName":"value","Value":"[datafield:processname]"},{"Id":616972,"PropertyName":"value","Value":"[datafield:processname]"},{"Id":648813,"PropertyName":"value","Value":"[datafield:processname]"}]}]
    defaultML = "en_US"
    
    screenHash = ""
    

    private _prevMasterPageInitLoaded: boolean = false;
    private _prevMasterPageRecurringLoaded: boolean = false;
    private _prevShouldTriggerPageInit: boolean = false;
    constructor(props) {
        super(props);
		this.leadlist_288211_value_kuikaTextInputRef = React.createRef();
		this.leadlist_776113_value_kuikaTextInputRef = React.createRef();
		this.leadlist_576673_value_kuikaTextInputRef = React.createRef();
		this.leadlist_980795_value_kuikaDateRef = React.createRef();
		this.leadlist_6623_value_kuikaDateRef = React.createRef();
		this.leadlist_60588_value_kuikaTextInputRef = React.createRef();
		this.leadlist_414332_value_kuikaTableRef = React.createRef();

        this.state = {
            isSpinnerVisible: false,
            isPageVisible: false,
            isLeftMenuVisible: false,
            spinnerCount: 0,
            selectedLanguage: "",
            isPageInitLoaded: false,
            isPageRecurringLoaded: false,
            	        TM_GetLeads: [],
	        TMLeadProcessCountSummary: [],
	        TM_GetProductCategory: [],
	        TM_GetProductReferanceFilter: [],
	        TM_GetCustomerByName: [],
	        TM_GetStore: [],
	        TM_GetSalesPerson: [],
	        TM_GetLeadStatus: [],
	        TM_GetLeadProcess: [],
	        TMGetProductAllLeadsMultiSelect: [],
	        NAVIGATE: "",
	        ChangeVisibilityOf: "",
	        SetValueOf: "",
	        ExportExcel: "",
	        isComp188701Visible: 'visible',
	        isComp169183Visible: 'hidden',
	        isComp921329Visible: 'visible',
	        isComp378811Visible: 'hidden',
	        isComp65859Visible: 'hidden',
	        isComp193325Visible: 'hidden',
	        isComp954115Visible: 'hidden',
	        isComp562166Visible: 'hidden',
	        isComp400233Visible: 'hidden',
	        isComp779571Visible: 'hidden',
	        isComp668839Visible: 'hidden',
	        isComp967789Visible: 'hidden',
	        isComp408551Visible: 'hidden',
	        isComp874659Visible: 'hidden',
	        isComp391899Visible: 'hidden',
	        isComp909224Visible: 'hidden',
	        isComp383770Visible: 'hidden',
	        isComp279981Visible: 'hidden',
	        isComp616972Visible: 'hidden',
	        isComp648813Visible: 'hidden',

        }

        this.CheckPageAuthorization(this.state);

        
    }

    async componentDidMount() {

        if (KuikaAppManager.isPageInitPrevented()) {
            KuikaAppManager.calculateAndSetBodyHeight("leadlist", "masterscreen_screen");
            return;
        }
        this.context.registerCallbackFunction(this.callCallbackFunction.bind(this));
        
        ReactSystemFunctions.validateToken()
        this.fillFormInitValues();
        if (false){
            await this.LeadListPageInit();
        } else if (this.context?.isMasterPageInitLoaded) { this._prevMasterPageInitLoaded = true; await this.LeadListPageInit(); }
        
        
        
        KuikaAppManager.calculateAndSetBodyHeight("leadlist", "masterscreen_screen");

        if (ReactSystemFunctions.getIsMicroApp() === false) {
           window.parentScreen = this;
        }
    }

    componentWillUnmount() {
        
        
        

        if (ReactSystemFunctions.getIsMicroApp() === false) {
           window.parentScreen = null;
        }
    }

    
              CheckPageAuthorization = async (state) => {
                KuikaAppManager.showSpinner(this);
                if (_.isEmpty(window.userInfo)) {
                  await UserService.GetUserInfoForce();
                }
                const permittedRoleNames: string[] = ["TimesYonetici","TimesUstYonetici","TimesSatisPersoneli","TimesMagazaMuduru","TimesAdmin",];
                const userInfo = window.userInfo as IUserInfoDto;
                const userRoleNames = userInfo.roles.map((role) => role.name);
                if (!ReactSystemFunctions.hasAnyRoleName(permittedRoleNames, userRoleNames)) {
                  await ReactSystemFunctions.goBack(this);

                  const language = localStorage.getItem("ml");
                  let permissonErrorMessageText = "You do not have permission to access this page.";
                  if (language === "tr_TR") {
                    permissonErrorMessageText = "Bu sayfaya erişim yetkiniz yok.";
                  } else if (language === "fr_FR") {
                    permissonErrorMessageText = "Vous n'avez pas la permission d'accéder à cette page.";
                  } else if (language === "de_DE") {
                    permissonErrorMessageText = "Sie haben keine Berechtigung, auf diese Seite zuzugreifen.";
                  } else if (language === "es_ES") {
                    permissonErrorMessageText = "No tienes permiso para acceder a esta página.";
                  }

                  KMainFunctions.displayErrorNotification(permissonErrorMessageText);
                  state.isPageVisible = false;
                  KuikaAppManager.hideSpinner(this);
                  return;
                }
                state.isPageVisible = true;
                KuikaAppManager.hideSpinner(this);
              };
        

        
    componentDidUpdate= async (prevProps, prevState) => {
		KuikaAppManager.calculateAndSetBodyHeight("leadlist", "masterscreen_screen"    );
        if (prevProps?.location?.search !== (this.props as any)?.location?.search) {
			await this.LeadListPageInit();
		}

        		if (this._prevMasterPageInitLoaded !== this.context.isMasterPageInitLoaded && this.context.isMasterPageInitLoaded === true) {this._prevMasterPageInitLoaded = this.context.isMasterPageInitLoaded;await this.LeadListPageInit()}


        if (ReactSystemFunctions.getIsMicroApp() === false) {
            for (const key in prevState) {
                if (key.startsWith('NavVisible') && prevState[key] === true && this.state[key] === false) {
                    window.parentScreen = this;
                    break;
                }
            }
        }
	}

    fillFormInitValues() {
        this.props.form?.setFieldsValue({
});

    }

      setPageInitLoaded = (value: boolean) => {
        this.setState({ isPageInitLoaded: value });
      }

      setPageRecurringLoaded = (value: boolean) => {
        this.setState({ isPageRecurringLoaded: value });
      }

      clearFieldValidation = (changedValues: any) => {
        const fieldName = Object.keys(changedValues)[0];
        if (fieldName) {
          this.props.form?.setFields([
            {
              name: fieldName,
              errors: []
            }
          ]);
        }
      };

      

    LeadListPageInit = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


	if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }

        let localVar = {
			StepOrder_0: ReactSystemFunctions.convertToTypeByName(null, "number"),
			UserId_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.getMyUserId(), "Guid"),
			MusteriAdi_0: ReactSystemFunctions.convertToTypeByName(null, "string"),
			ProductName_0: ReactSystemFunctions.convertToTypeByName(null, "string"),
			LeadCode_0: ReactSystemFunctions.convertToTypeByName(null, "string"),
			Tel_0: ReactSystemFunctions.convertToTypeByName(null, "string"),
			CategoryName_0: ReactSystemFunctions.convertToTypeByName(null, "string"),
			StoreIds_0: ReactSystemFunctions.convertToTypeByName(null, "string"),
			SatisDanismaniIds_0: ReactSystemFunctions.convertToTypeByName(null, "string"),
			ProcessCode_0: ReactSystemFunctions.convertToTypeByName(null, "string"),
			StartDate_0: ReactSystemFunctions.convertToTypeByName(null, "Date"),
			EndDate_0: ReactSystemFunctions.convertToTypeByName(null, "Date"),
			UserId_1: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.getMyUserId(), "Guid"),
			MusteriAdi_1: ReactSystemFunctions.convertToTypeByName(null, "string"),
			ProductName_1: ReactSystemFunctions.convertToTypeByName(null, "string"),
			LeadCode_1: ReactSystemFunctions.convertToTypeByName(null, "string"),
			Tel_1: ReactSystemFunctions.convertToTypeByName(null, "string"),
			CategoryName_1: ReactSystemFunctions.convertToTypeByName(null, "string"),
			StoreIds_1: ReactSystemFunctions.convertToTypeByName(null, "string"),
			SatisDanismaniIds_1: ReactSystemFunctions.convertToTypeByName(null, "string"),
			ProcessCode_1: ReactSystemFunctions.convertToTypeByName(null, "string"),
			StartDate_1: ReactSystemFunctions.convertToTypeByName(null, "Date"),
			EndDate_1: ReactSystemFunctions.convertToTypeByName(null, "Date"),
			KUserId_5: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.getMyUserId(), "Guid"),
			KUserId_6: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.getMyUserId(), "Guid"),
			StoreId_6: ReactSystemFunctions.convertToTypeByName(null, "Guid"),
			StepOrder_8: ReactSystemFunctions.convertToTypeByName(0, "number")
        }

	KuikaAppManager.showSpinner(this);
	
        if (true) {
        KuikaAppManager.showSpinner(this);
        }
        let result = await KuikaAppManager.ApiRequest(this, "LeadList/LeadListPageInit", localVar)
        if (!KMainFunctions.IsResStatus2XX(result)) return true;

		stateVars.TM_GetLeads = result?.data.tM_GetLeads;
		
		stateVars.TMLeadProcessCountSummary = result?.data.tmLeadProcessCountSummary;
		formVars.leadlist_893473_value = ReactSystemFunctions.toString(this, (stateVars.TMLeadProcessCountSummary !== undefined ? (stateVars.TMLeadProcessCountSummary?.length > 0 ? stateVars.TMLeadProcessCountSummary[0].toplamTalepSayisi : null) : (this.state.TMLeadProcessCountSummary?.length > 0 ? this.state.TMLeadProcessCountSummary[0].toplamTalepSayisi : null)));
		formVars.leadlist_864952_value = ReactSystemFunctions.toString(this, (stateVars.TMLeadProcessCountSummary !== undefined ? (stateVars.TMLeadProcessCountSummary?.length > 0 ? stateVars.TMLeadProcessCountSummary[0].onayBekleyenSayisi : null) : (this.state.TMLeadProcessCountSummary?.length > 0 ? this.state.TMLeadProcessCountSummary[0].onayBekleyenSayisi : null)));
		formVars.leadlist_844329_value = ReactSystemFunctions.toString(this, (stateVars.TMLeadProcessCountSummary !== undefined ? (stateVars.TMLeadProcessCountSummary?.length > 0 ? stateVars.TMLeadProcessCountSummary[0].terminBekleyenSayisi : null) : (this.state.TMLeadProcessCountSummary?.length > 0 ? this.state.TMLeadProcessCountSummary[0].terminBekleyenSayisi : null)));
		formVars.leadlist_574886_value = ReactSystemFunctions.toString(this, (stateVars.TMLeadProcessCountSummary !== undefined ? (stateVars.TMLeadProcessCountSummary?.length > 0 ? stateVars.TMLeadProcessCountSummary[0].onaylananSayisi : null) : (this.state.TMLeadProcessCountSummary?.length > 0 ? this.state.TMLeadProcessCountSummary[0].onaylananSayisi : null)));
		formVars.leadlist_582775_value = ReactSystemFunctions.toString(this, (stateVars.TMLeadProcessCountSummary !== undefined ? (stateVars.TMLeadProcessCountSummary?.length > 0 ? stateVars.TMLeadProcessCountSummary[0].reddedilenSayisi : null) : (this.state.TMLeadProcessCountSummary?.length > 0 ? this.state.TMLeadProcessCountSummary[0].reddedilenSayisi : null)));
		formVars.leadlist_207750_value = ReactSystemFunctions.toString(this, (stateVars.TMLeadProcessCountSummary !== undefined ? (stateVars.TMLeadProcessCountSummary?.length > 0 ? stateVars.TMLeadProcessCountSummary[0].teslimEdilecekSayisi : null) : (this.state.TMLeadProcessCountSummary?.length > 0 ? this.state.TMLeadProcessCountSummary[0].teslimEdilecekSayisi : null)));
		formVars.leadlist_967794_value = ReactSystemFunctions.toString(this, (stateVars.TMLeadProcessCountSummary !== undefined ? (stateVars.TMLeadProcessCountSummary?.length > 0 ? stateVars.TMLeadProcessCountSummary[0].teslimEdildiSayisi : null) : (this.state.TMLeadProcessCountSummary?.length > 0 ? this.state.TMLeadProcessCountSummary[0].teslimEdildiSayisi : null)));
		stateVars.TM_GetProductCategory = result?.data.tM_GetProductCategory;
		
		formVars.leadlist_836823_options = stateVars.TM_GetProductCategory;
		stateVars.TM_GetProductReferanceFilter = result?.data.tM_GetProductReferanceFilter;
		stateVars.TM_GetCustomerByName = result?.data.tM_GetCustomerByName;
		stateVars.TM_GetStore = result?.data.tM_GetStore;
		
		formVars.leadlist_314150_options = stateVars.TM_GetStore;
		stateVars.TM_GetSalesPerson = result?.data.tM_GetSalesPerson;
		
		formVars.leadlist_872239_options = stateVars.TM_GetSalesPerson;
		stateVars.TM_GetLeadStatus = result?.data.tM_GetLeadStatus;
		stateVars.TM_GetLeadProcess = result?.data.tM_GetLeadProcess;
		
		formVars.leadlist_161661_options = stateVars.TM_GetLeadProcess;
		stateVars.TMGetProductAllLeadsMultiSelect = result?.data.tmGetProductAllLeadsMultiSelect;
		this.props.form?.setFieldsValue(formVars);
		
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.LeadListPageInit1_();
                  resolve();
                });
          })



        
        KuikaAppManager.hideSpinner(this);
        return isErrorOccurred;
    }
	LeadListPageInit1_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


	if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }

			formVars.leadlist_893473_value = ReactSystemFunctions.toString(this, (stateVars.TMLeadProcessCountSummary !== undefined ? (stateVars.TMLeadProcessCountSummary?.length > 0 ? stateVars.TMLeadProcessCountSummary[0].toplamTalepSayisi : null) : (this.state.TMLeadProcessCountSummary?.length > 0 ? this.state.TMLeadProcessCountSummary[0].toplamTalepSayisi : null)));

			formVars.leadlist_864952_value = ReactSystemFunctions.toString(this, (stateVars.TMLeadProcessCountSummary !== undefined ? (stateVars.TMLeadProcessCountSummary?.length > 0 ? stateVars.TMLeadProcessCountSummary[0].onayBekleyenSayisi : null) : (this.state.TMLeadProcessCountSummary?.length > 0 ? this.state.TMLeadProcessCountSummary[0].onayBekleyenSayisi : null)));

			formVars.leadlist_844329_value = ReactSystemFunctions.toString(this, (stateVars.TMLeadProcessCountSummary !== undefined ? (stateVars.TMLeadProcessCountSummary?.length > 0 ? stateVars.TMLeadProcessCountSummary[0].terminBekleyenSayisi : null) : (this.state.TMLeadProcessCountSummary?.length > 0 ? this.state.TMLeadProcessCountSummary[0].terminBekleyenSayisi : null)));

			formVars.leadlist_574886_value = ReactSystemFunctions.toString(this, (stateVars.TMLeadProcessCountSummary !== undefined ? (stateVars.TMLeadProcessCountSummary?.length > 0 ? stateVars.TMLeadProcessCountSummary[0].onaylananSayisi : null) : (this.state.TMLeadProcessCountSummary?.length > 0 ? this.state.TMLeadProcessCountSummary[0].onaylananSayisi : null)));

			formVars.leadlist_582775_value = ReactSystemFunctions.toString(this, (stateVars.TMLeadProcessCountSummary !== undefined ? (stateVars.TMLeadProcessCountSummary?.length > 0 ? stateVars.TMLeadProcessCountSummary[0].reddedilenSayisi : null) : (this.state.TMLeadProcessCountSummary?.length > 0 ? this.state.TMLeadProcessCountSummary[0].reddedilenSayisi : null)));

			formVars.leadlist_207750_value = ReactSystemFunctions.toString(this, (stateVars.TMLeadProcessCountSummary !== undefined ? (stateVars.TMLeadProcessCountSummary?.length > 0 ? stateVars.TMLeadProcessCountSummary[0].teslimEdilecekSayisi : null) : (this.state.TMLeadProcessCountSummary?.length > 0 ? this.state.TMLeadProcessCountSummary[0].teslimEdilecekSayisi : null)));

			formVars.leadlist_967794_value = ReactSystemFunctions.toString(this, (stateVars.TMLeadProcessCountSummary !== undefined ? (stateVars.TMLeadProcessCountSummary?.length > 0 ? stateVars.TMLeadProcessCountSummary[0].teslimEdildiSayisi : null) : (this.state.TMLeadProcessCountSummary?.length > 0 ? this.state.TMLeadProcessCountSummary[0].teslimEdildiSayisi : null)));

			
			stateVars.dataSource_836823 = stateVars.TM_GetProductCategory ?? this.state.TM_GetProductCategory;
			stateVars.dataSource_836823 = stateVars.TM_GetProductCategory ?? this.state.TM_GetProductCategory;
			
			stateVars.dataSource_314150 = stateVars.TM_GetStore ?? this.state.TM_GetStore;
			stateVars.dataSource_314150 = stateVars.TM_GetStore ?? this.state.TM_GetStore;
			
			stateVars.dataSource_872239 = stateVars.TM_GetSalesPerson ?? this.state.TM_GetSalesPerson;
			stateVars.dataSource_872239 = stateVars.TM_GetSalesPerson ?? this.state.TM_GetSalesPerson;
			
			stateVars.dataSource_161661 = stateVars.TM_GetLeadProcess ?? this.state.TM_GetLeadProcess;
			stateVars.dataSource_161661 = stateVars.TM_GetLeadProcess ?? this.state.TM_GetLeadProcess;
			stateVars.isComp378811Visible = (((ReactSystemFunctions.contains(ReactSystemFunctions.getMyRoleNames(), ReactSystemFunctions.convertToTypeByName("TimesMagazaMuduru", "string")) || ReactSystemFunctions.contains(ReactSystemFunctions.getMyRoleNames(), ReactSystemFunctions.convertToTypeByName("TimesUstYonetici", "string")) || ReactSystemFunctions.contains(ReactSystemFunctions.getMyRoleNames(), ReactSystemFunctions.convertToTypeByName("TimesAdmin", "string")))) === true ? "visible" : "hidden")
			
			stateVars.dataSource_414332 = stateVars.TM_GetLeads ?? this.state.TM_GetLeads;
			stateVars.isComp65859Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, "leadlist_414332_value", "categoryName"), ReactSystemFunctions.convertToTypeByName("Kategori 3", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp193325Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, "leadlist_414332_value", "categoryName"), ReactSystemFunctions.convertToTypeByName("Kategori 2", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp954115Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, "leadlist_414332_value", "categoryName"), ReactSystemFunctions.convertToTypeByName("Kategori 1", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp562166Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, "leadlist_414332_value", "categoryName"), ReactSystemFunctions.convertToTypeByName("DEFAULT", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp400233Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, "leadlist_414332_value", "leadDurumu"), ReactSystemFunctions.convertToTypeByName("2. Takip", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp779571Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, "leadlist_414332_value", "leadDurumu"), ReactSystemFunctions.convertToTypeByName("Takip ediliyor", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp668839Visible = ((ReactSystemFunctions.isEmpty(ReactSystemFunctions.value(this, "leadlist_414332_value", "terminTarihi"), ReactSystemFunctions.convertToTypeByName("True", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp967789Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, "leadlist_414332_value", "rezerveDurumu"), ReactSystemFunctions.convertToTypeByName("Evet", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp408551Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, "leadlist_414332_value", "rezerveDurumu"), ReactSystemFunctions.convertToTypeByName("Onay Bekliyor", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp874659Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, "leadlist_414332_value", "rezerveDurumu"), ReactSystemFunctions.convertToTypeByName("Hayır", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp391899Visible = (((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, "leadlist_414332_value", "processName"), ReactSystemFunctions.convertToTypeByName("Onaylandı", "string")) || ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, "leadlist_414332_value", "processName"), ReactSystemFunctions.convertToTypeByName("Oluşturuldu", "string")))) === true ? "visible" : "hidden")
			stateVars.isComp909224Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, "leadlist_414332_value", "processName"), ReactSystemFunctions.convertToTypeByName("Reddedildi", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp383770Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, "leadlist_414332_value", "processCode"), ReactSystemFunctions.convertToTypeByName("CUSTOMER_DECLINED", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp279981Visible = (((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, "leadlist_414332_value", "processName"), ReactSystemFunctions.convertToTypeByName("Onay Bekliyor", "string")) || ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, "leadlist_414332_value", "processName"), ReactSystemFunctions.convertToTypeByName("Termin Bekliyor", "string")) || ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, "leadlist_414332_value", "processName"), ReactSystemFunctions.convertToTypeByName("Satış Bekliyor", "string")))) === true ? "visible" : "hidden")
			stateVars.isComp616972Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, "leadlist_414332_value", "processCode"), ReactSystemFunctions.convertToTypeByName("DELIVERED", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp648813Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, "leadlist_414332_value", "processName"), ReactSystemFunctions.convertToTypeByName("Kapatıldı", "string"))) === true ? "visible" : "hidden")

	this.props.form?.setFieldsValue(formVars);
	this.setState(stateVars);
	KuikaAppManager.hideSpinner(this);

            this.setPageInitLoaded(true);
            return isErrorOccurred;
        }




    LeadListComponent_361899_onClick = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
		KuikaAppManager.increaseServerRequestCount();

        let localVar = {
				StepOrder_0: ReactSystemFunctions.convertToTypeByName(null, "number"),
				UserId_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.getMyUserId(), "Guid"),
				MusteriAdi_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "leadlist_288211_value", "value", "", "", "")), "string"),
				ProductName_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "leadlist_576673_value", "value", "", "", "")), "string"),
				LeadCode_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "leadlist_60588_value", "value", "", "", "")), "string"),
				Tel_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "leadlist_776113_value", "value", "", "", "")), "string"),
				CategoryName_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "leadlist_836823_value", "value", "TM_GetProductCategory", "categoryName", "categoryName")), "string"),
				StoreIds_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "leadlist_314150_value", "value", "TM_GetStore", "storeCode", "id")), "string"),
				SatisDanismaniIds_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "leadlist_872239_value", "value", "TM_GetSalesPerson", "kUserId", "kUserId")), "string"),
				ProcessCode_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "leadlist_161661_value", "value", "TM_GetLeadProcess", "id", "code")), "string"),
				StartDate_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "leadlist_980795_value", "value", "", "", "")), "Date"),
				EndDate_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "leadlist_6623_value", "value", "", "", "")), "Date")
        }

		KuikaAppManager.showSpinner(this);
		
        if (true) {
        KuikaAppManager.showSpinner(this);
        }
        let result = await KuikaAppManager.ApiRequest(this, "LeadList/LeadListComponent_361899_onClick", localVar)
        if (!KMainFunctions.IsResStatus2XX(result)) return true;

			stateVars.TM_GetLeads = result?.data.tM_GetLeads;
			
			this.props.form?.setFieldsValue(formVars);
			
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.LeadListComponent_361899_onClick1_();
                  resolve();
                });
          })



        
        KuikaAppManager.hideSpinner(this);
        return isErrorOccurred;
    }
		LeadListComponent_361899_onClick1_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }

				
				stateVars.dataSource_414332 = stateVars.TM_GetLeads ?? this.state.TM_GetLeads;

		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

            
            return isErrorOccurred;
        }




    LeadListComponent_470282_onClick = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
		KuikaAppManager.increaseServerRequestCount();

        let localVar = {
				StepOrder_0: ReactSystemFunctions.convertToTypeByName(3, "number"),
				UserId_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.getMyUserId(), "Guid"),
				MusteriAdi_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "leadlist_288211_value", "value", "", "", "")), "string"),
				ProductName_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "leadlist_576673_value", "value", "", "", "")), "string"),
				LeadCode_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "leadlist_60588_value", "value", "", "", "")), "string"),
				Tel_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "leadlist_776113_value", "value", "", "", "")), "string"),
				CategoryName_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "leadlist_836823_value", "value", "TM_GetProductCategory", "categoryName", "categoryName")), "string"),
				StoreIds_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "leadlist_314150_value", "value", "TM_GetStore", "storeCode", "id")), "string"),
				SatisDanismaniIds_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "leadlist_872239_value", "value", "TM_GetSalesPerson", "kUserId", "kUserId")), "string"),
				ProcessCode_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "leadlist_161661_value", "value", "TM_GetLeadProcess", "id", "code")), "string"),
				StartDate_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "leadlist_980795_value", "value", "", "", "")), "Date"),
				EndDate_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "leadlist_6623_value", "value", "", "", "")), "Date")
        }

		KuikaAppManager.showSpinner(this);
		
        if (true) {
        KuikaAppManager.showSpinner(this);
        }
        let result = await KuikaAppManager.ApiRequest(this, "LeadList/LeadListComponent_470282_onClick", localVar)
        if (!KMainFunctions.IsResStatus2XX(result)) return true;

			stateVars.TM_GetLeads = result?.data.tM_GetLeads;
			
			this.props.form?.setFieldsValue(formVars);
			
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.LeadListComponent_470282_onClick1_();
                  resolve();
                });
          })



        
        KuikaAppManager.hideSpinner(this);
        return isErrorOccurred;
    }
		LeadListComponent_470282_onClick1_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }

				
				stateVars.dataSource_414332 = stateVars.TM_GetLeads ?? this.state.TM_GetLeads;

		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

            
            return isErrorOccurred;
        }




    LeadListComponent_576136_onClick = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
		KuikaAppManager.increaseServerRequestCount();

        let localVar = {
				StepOrder_0: ReactSystemFunctions.convertToTypeByName(2, "number"),
				UserId_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.getMyUserId(), "Guid"),
				MusteriAdi_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "leadlist_288211_value", "value", "", "", "")), "string"),
				ProductName_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "leadlist_576673_value", "value", "", "", "")), "string"),
				LeadCode_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "leadlist_60588_value", "value", "", "", "")), "string"),
				Tel_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "leadlist_776113_value", "value", "", "", "")), "string"),
				CategoryName_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "leadlist_836823_value", "value", "TM_GetProductCategory", "categoryName", "categoryName")), "string"),
				StoreIds_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "leadlist_314150_value", "value", "TM_GetStore", "storeCode", "id")), "string"),
				SatisDanismaniIds_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "leadlist_872239_value", "value", "TM_GetSalesPerson", "kUserId", "kUserId")), "string"),
				ProcessCode_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "leadlist_161661_value", "value", "TM_GetLeadProcess", "id", "code")), "string"),
				StartDate_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "leadlist_980795_value", "value", "", "", "")), "Date"),
				EndDate_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "leadlist_6623_value", "value", "", "", "")), "Date")
        }

		KuikaAppManager.showSpinner(this);
		
        if (true) {
        KuikaAppManager.showSpinner(this);
        }
        let result = await KuikaAppManager.ApiRequest(this, "LeadList/LeadListComponent_576136_onClick", localVar)
        if (!KMainFunctions.IsResStatus2XX(result)) return true;

			stateVars.TM_GetLeads = result?.data.tM_GetLeads;
			
			this.props.form?.setFieldsValue(formVars);
			
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.LeadListComponent_576136_onClick1_();
                  resolve();
                });
          })



        
        KuikaAppManager.hideSpinner(this);
        return isErrorOccurred;
    }
		LeadListComponent_576136_onClick1_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }

				
				stateVars.dataSource_414332 = stateVars.TM_GetLeads ?? this.state.TM_GetLeads;

		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

            
            return isErrorOccurred;
        }




    LeadListComponent_399191_onClick = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
		KuikaAppManager.increaseServerRequestCount();

        let localVar = {
				StepOrder_0: ReactSystemFunctions.convertToTypeByName(4, "number"),
				UserId_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.getMyUserId(), "Guid"),
				MusteriAdi_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "leadlist_288211_value", "value", "", "", "")), "string"),
				ProductName_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "leadlist_576673_value", "value", "", "", "")), "string"),
				LeadCode_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "leadlist_60588_value", "value", "", "", "")), "string"),
				Tel_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "leadlist_776113_value", "value", "", "", "")), "string"),
				CategoryName_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "leadlist_836823_value", "value", "TM_GetProductCategory", "categoryName", "categoryName")), "string"),
				StoreIds_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "leadlist_314150_value", "value", "TM_GetStore", "storeCode", "id")), "string"),
				SatisDanismaniIds_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "leadlist_872239_value", "value", "TM_GetSalesPerson", "kUserId", "kUserId")), "string"),
				ProcessCode_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "leadlist_161661_value", "value", "TM_GetLeadProcess", "id", "code")), "string"),
				StartDate_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "leadlist_980795_value", "value", "", "", "")), "Date"),
				EndDate_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "leadlist_6623_value", "value", "", "", "")), "Date")
        }

		KuikaAppManager.showSpinner(this);
		
        if (true) {
        KuikaAppManager.showSpinner(this);
        }
        let result = await KuikaAppManager.ApiRequest(this, "LeadList/LeadListComponent_399191_onClick", localVar)
        if (!KMainFunctions.IsResStatus2XX(result)) return true;

			stateVars.TM_GetLeads = result?.data.tM_GetLeads;
			
			this.props.form?.setFieldsValue(formVars);
			
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.LeadListComponent_399191_onClick1_();
                  resolve();
                });
          })



        
        KuikaAppManager.hideSpinner(this);
        return isErrorOccurred;
    }
		LeadListComponent_399191_onClick1_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }

				
				stateVars.dataSource_414332 = stateVars.TM_GetLeads ?? this.state.TM_GetLeads;

		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

            
            return isErrorOccurred;
        }




    LeadListComponent_398408_onClick = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
		KuikaAppManager.increaseServerRequestCount();

        let localVar = {
				StepOrder_0: ReactSystemFunctions.convertToTypeByName(5, "number"),
				UserId_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.getMyUserId(), "Guid"),
				MusteriAdi_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "leadlist_288211_value", "value", "", "", "")), "string"),
				ProductName_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "leadlist_576673_value", "value", "", "", "")), "string"),
				LeadCode_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "leadlist_60588_value", "value", "", "", "")), "string"),
				Tel_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "leadlist_776113_value", "value", "", "", "")), "string"),
				CategoryName_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "leadlist_836823_value", "value", "TM_GetProductCategory", "categoryName", "categoryName")), "string"),
				StoreIds_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "leadlist_314150_value", "value", "TM_GetStore", "storeCode", "id")), "string"),
				SatisDanismaniIds_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "leadlist_872239_value", "value", "TM_GetSalesPerson", "kUserId", "kUserId")), "string"),
				ProcessCode_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "leadlist_161661_value", "value", "TM_GetLeadProcess", "id", "code")), "string"),
				StartDate_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "leadlist_980795_value", "value", "", "", "")), "Date"),
				EndDate_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "leadlist_6623_value", "value", "", "", "")), "Date")
        }

		KuikaAppManager.showSpinner(this);
		
        if (true) {
        KuikaAppManager.showSpinner(this);
        }
        let result = await KuikaAppManager.ApiRequest(this, "LeadList/LeadListComponent_398408_onClick", localVar)
        if (!KMainFunctions.IsResStatus2XX(result)) return true;

			stateVars.TM_GetLeads = result?.data.tM_GetLeads;
			
			this.props.form?.setFieldsValue(formVars);
			
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.LeadListComponent_398408_onClick1_();
                  resolve();
                });
          })



        
        KuikaAppManager.hideSpinner(this);
        return isErrorOccurred;
    }
		LeadListComponent_398408_onClick1_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }

				
				stateVars.dataSource_414332 = stateVars.TM_GetLeads ?? this.state.TM_GetLeads;

		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

            
            return isErrorOccurred;
        }




    LeadListComponent_416933_onClick = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
		KuikaAppManager.increaseServerRequestCount();

        let localVar = {
				StepOrder_0: ReactSystemFunctions.convertToTypeByName(6, "number"),
				UserId_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.getMyUserId(), "Guid"),
				MusteriAdi_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "leadlist_288211_value", "value", "", "", "")), "string"),
				ProductName_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "leadlist_576673_value", "value", "", "", "")), "string"),
				LeadCode_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "leadlist_60588_value", "value", "", "", "")), "string"),
				Tel_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "leadlist_776113_value", "value", "", "", "")), "string"),
				CategoryName_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "leadlist_836823_value", "value", "TM_GetProductCategory", "categoryName", "categoryName")), "string"),
				StoreIds_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "leadlist_314150_value", "value", "TM_GetStore", "storeCode", "id")), "string"),
				SatisDanismaniIds_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "leadlist_872239_value", "value", "TM_GetSalesPerson", "kUserId", "kUserId")), "string"),
				ProcessCode_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "leadlist_161661_value", "value", "TM_GetLeadProcess", "id", "code")), "string"),
				StartDate_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "leadlist_980795_value", "value", "", "", "")), "Date"),
				EndDate_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "leadlist_6623_value", "value", "", "", "")), "Date")
        }

		KuikaAppManager.showSpinner(this);
		
        if (true) {
        KuikaAppManager.showSpinner(this);
        }
        let result = await KuikaAppManager.ApiRequest(this, "LeadList/LeadListComponent_416933_onClick", localVar)
        if (!KMainFunctions.IsResStatus2XX(result)) return true;

			stateVars.TM_GetLeads = result?.data.tM_GetLeads;
			
			this.props.form?.setFieldsValue(formVars);
			
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.LeadListComponent_416933_onClick1_();
                  resolve();
                });
          })



        
        KuikaAppManager.hideSpinner(this);
        return isErrorOccurred;
    }
		LeadListComponent_416933_onClick1_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }

				
				stateVars.dataSource_414332 = stateVars.TM_GetLeads ?? this.state.TM_GetLeads;

		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

            
            return isErrorOccurred;
        }




    LeadListComponent_634059_onClick = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
		KuikaAppManager.increaseServerRequestCount();

        let localVar = {
				StepOrder_0: ReactSystemFunctions.convertToTypeByName(7, "number"),
				UserId_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.getMyUserId(), "Guid"),
				MusteriAdi_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "leadlist_288211_value", "value", "", "", "")), "string"),
				ProductName_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "leadlist_576673_value", "value", "", "", "")), "string"),
				LeadCode_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "leadlist_60588_value", "value", "", "", "")), "string"),
				Tel_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "leadlist_776113_value", "value", "", "", "")), "string"),
				CategoryName_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "leadlist_836823_value", "value", "TM_GetProductCategory", "categoryName", "categoryName")), "string"),
				StoreIds_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "leadlist_314150_value", "value", "TM_GetStore", "storeCode", "id")), "string"),
				SatisDanismaniIds_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "leadlist_872239_value", "value", "TM_GetSalesPerson", "kUserId", "kUserId")), "string"),
				ProcessCode_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "leadlist_161661_value", "value", "TM_GetLeadProcess", "id", "code")), "string"),
				StartDate_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "leadlist_980795_value", "value", "", "", "")), "Date"),
				EndDate_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "leadlist_6623_value", "value", "", "", "")), "Date")
        }

		KuikaAppManager.showSpinner(this);
		
        if (true) {
        KuikaAppManager.showSpinner(this);
        }
        let result = await KuikaAppManager.ApiRequest(this, "LeadList/LeadListComponent_634059_onClick", localVar)
        if (!KMainFunctions.IsResStatus2XX(result)) return true;

			stateVars.TM_GetLeads = result?.data.tM_GetLeads;
			
			this.props.form?.setFieldsValue(formVars);
			
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.LeadListComponent_634059_onClick1_();
                  resolve();
                });
          })



        
        KuikaAppManager.hideSpinner(this);
        return isErrorOccurred;
    }
		LeadListComponent_634059_onClick1_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }

				
				stateVars.dataSource_414332 = stateVars.TM_GetLeads ?? this.state.TM_GetLeads;

		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

            
            return isErrorOccurred;
        }




		LeadListComponent_239508_onClick = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
KuikaAppManager.showSpinner(this);

const __currentPath = (window.location.hash ? window.location.hash.replace(/^#/, '').split('?')[0] : window.location.pathname.split('?')[0]).toLowerCase();
if (__currentPath !== "/leadadd") {
  this.context.setMasterPageInitLoaded(false);
  this.context.setMasterPageRecurringLoaded(false);
  this.context.setShouldTriggerPageInit(true);
}
					KuikaAppManager.prepareForNavigation();
						KuikaAppManager.addToPageInputVariables("LeadAdd", "CustomerId", ReactSystemFunctions.convertToTypeByName("00000000-0000-0000-0000-000000000000", "Guid"));

				stateVars.NAVIGATE = await ReactSystemFunctions.navigate(this, undefined, "LeadList", "LeadAdd", "", "currentPage", null, null, null, null, null, null, true, false);

		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

            
            return isErrorOccurred;
        }


		LeadListComponent_921329_onClick = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
KuikaAppManager.showSpinner(this);

				stateVars.ChangeVisibilityOf = await ReactSystemFunctions.changeVisibilityOf(this, ReactSystemFunctions.convertToTypeByName("isComp188701Visible", "string"), ReactSystemFunctions.convertToTypeByName("hidden", "string"));
				stateVars.ChangeVisibilityOf = await ReactSystemFunctions.changeVisibilityOf(this, ReactSystemFunctions.convertToTypeByName("isComp169183Visible", "string"), ReactSystemFunctions.convertToTypeByName("visible", "string"));
				stateVars.ChangeVisibilityOf = await ReactSystemFunctions.changeVisibilityOf(this, ReactSystemFunctions.convertToTypeByName("isComp921329Visible", "string"), ReactSystemFunctions.convertToTypeByName("hidden", "string"));

		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

            
            return isErrorOccurred;
        }


		LeadListComponent_169183_onClick = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
KuikaAppManager.showSpinner(this);

				stateVars.ChangeVisibilityOf = await ReactSystemFunctions.changeVisibilityOf(this, ReactSystemFunctions.convertToTypeByName("isComp188701Visible", "string"), ReactSystemFunctions.convertToTypeByName("visible", "string"));
				stateVars.ChangeVisibilityOf = await ReactSystemFunctions.changeVisibilityOf(this, ReactSystemFunctions.convertToTypeByName("isComp921329Visible", "string"), ReactSystemFunctions.convertToTypeByName("visible", "string"));
				stateVars.ChangeVisibilityOf = await ReactSystemFunctions.changeVisibilityOf(this, ReactSystemFunctions.convertToTypeByName("isComp169183Visible", "string"), ReactSystemFunctions.convertToTypeByName("hidden", "string"));

		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

            
            return isErrorOccurred;
        }


    LeadListComponent_288211_onChange = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
		KuikaAppManager.increaseServerRequestCount();

        let localVar = {
				StepOrder_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, (stateVars.TM_GetLeads !== undefined ? (stateVars.TM_GetLeads?.length > 0 ? stateVars.TM_GetLeads[0].selectedStepOrder : null) : (this.state.TM_GetLeads?.length > 0 ? this.state.TM_GetLeads[0].selectedStepOrder : null))), "number"),
				UserId_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.getMyUserId(), "Guid"),
				MusteriAdi_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "leadlist_288211_value", "value", "", "", "")), "string"),
				ProductName_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "leadlist_576673_value", "value", "", "", "")), "string"),
				LeadCode_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "leadlist_60588_value", "value", "", "", "")), "string"),
				Tel_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "leadlist_776113_value", "value", "", "", "")), "string"),
				CategoryName_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "leadlist_836823_value", "value", "TM_GetProductCategory", "categoryName", "categoryName")), "string"),
				StoreIds_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "leadlist_314150_value", "value", "TM_GetStore", "storeCode", "id")), "string"),
				SatisDanismaniIds_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "leadlist_872239_value", "value", "TM_GetSalesPerson", "kUserId", "kUserId")), "string"),
				ProcessCode_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "leadlist_161661_value", "value", "TM_GetLeadProcess", "id", "code")), "string"),
				StartDate_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "leadlist_980795_value", "value", "", "", "")), "Date"),
				EndDate_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "leadlist_6623_value", "value", "", "", "")), "Date"),
				UserId_1: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.getMyUserId(), "Guid"),
				MusteriAdi_1: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "leadlist_288211_value", "value", "", "", "")), "string"),
				ProductName_1: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "leadlist_576673_value", "value", "", "", "")), "string"),
				LeadCode_1: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "leadlist_60588_value", "value", "", "", "")), "string"),
				Tel_1: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "leadlist_776113_value", "value", "", "", "")), "string"),
				CategoryName_1: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "leadlist_836823_value", "value", "TM_GetProductCategory", "categoryName", "categoryName")), "string"),
				StoreIds_1: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "leadlist_314150_value", "value", "TM_GetStore", "storeCode", "id")), "string"),
				SatisDanismaniIds_1: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "leadlist_872239_value", "value", "TM_GetSalesPerson", "kUserId", "kUserId")), "string"),
				ProcessCode_1: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "leadlist_161661_value", "value", "TM_GetLeadProcess", "id", "code")), "string"),
				StartDate_1: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "leadlist_980795_value", "value", "", "", "")), "Date"),
				EndDate_1: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "leadlist_6623_value", "value", "", "", "")), "Date")
        }

		KuikaAppManager.showSpinner(this);
		
        if (true) {
        KuikaAppManager.showSpinner(this);
        }
        let result = await KuikaAppManager.ApiRequest(this, "LeadList/LeadListComponent_288211_onChange", localVar)
        if (!KMainFunctions.IsResStatus2XX(result)) return true;

			stateVars.TM_GetLeads = result?.data.tM_GetLeads;
			
			stateVars.TMLeadProcessCountSummary = result?.data.tmLeadProcessCountSummary;
			formVars.leadlist_893473_value = ReactSystemFunctions.toString(this, (stateVars.TMLeadProcessCountSummary !== undefined ? (stateVars.TMLeadProcessCountSummary?.length > 0 ? stateVars.TMLeadProcessCountSummary[0].toplamTalepSayisi : null) : (this.state.TMLeadProcessCountSummary?.length > 0 ? this.state.TMLeadProcessCountSummary[0].toplamTalepSayisi : null)));
			formVars.leadlist_864952_value = ReactSystemFunctions.toString(this, (stateVars.TMLeadProcessCountSummary !== undefined ? (stateVars.TMLeadProcessCountSummary?.length > 0 ? stateVars.TMLeadProcessCountSummary[0].onayBekleyenSayisi : null) : (this.state.TMLeadProcessCountSummary?.length > 0 ? this.state.TMLeadProcessCountSummary[0].onayBekleyenSayisi : null)));
			formVars.leadlist_844329_value = ReactSystemFunctions.toString(this, (stateVars.TMLeadProcessCountSummary !== undefined ? (stateVars.TMLeadProcessCountSummary?.length > 0 ? stateVars.TMLeadProcessCountSummary[0].terminBekleyenSayisi : null) : (this.state.TMLeadProcessCountSummary?.length > 0 ? this.state.TMLeadProcessCountSummary[0].terminBekleyenSayisi : null)));
			formVars.leadlist_574886_value = ReactSystemFunctions.toString(this, (stateVars.TMLeadProcessCountSummary !== undefined ? (stateVars.TMLeadProcessCountSummary?.length > 0 ? stateVars.TMLeadProcessCountSummary[0].onaylananSayisi : null) : (this.state.TMLeadProcessCountSummary?.length > 0 ? this.state.TMLeadProcessCountSummary[0].onaylananSayisi : null)));
			formVars.leadlist_582775_value = ReactSystemFunctions.toString(this, (stateVars.TMLeadProcessCountSummary !== undefined ? (stateVars.TMLeadProcessCountSummary?.length > 0 ? stateVars.TMLeadProcessCountSummary[0].reddedilenSayisi : null) : (this.state.TMLeadProcessCountSummary?.length > 0 ? this.state.TMLeadProcessCountSummary[0].reddedilenSayisi : null)));
			formVars.leadlist_207750_value = ReactSystemFunctions.toString(this, (stateVars.TMLeadProcessCountSummary !== undefined ? (stateVars.TMLeadProcessCountSummary?.length > 0 ? stateVars.TMLeadProcessCountSummary[0].teslimEdilecekSayisi : null) : (this.state.TMLeadProcessCountSummary?.length > 0 ? this.state.TMLeadProcessCountSummary[0].teslimEdilecekSayisi : null)));
			formVars.leadlist_967794_value = ReactSystemFunctions.toString(this, (stateVars.TMLeadProcessCountSummary !== undefined ? (stateVars.TMLeadProcessCountSummary?.length > 0 ? stateVars.TMLeadProcessCountSummary[0].teslimEdildiSayisi : null) : (this.state.TMLeadProcessCountSummary?.length > 0 ? this.state.TMLeadProcessCountSummary[0].teslimEdildiSayisi : null)));
			this.props.form?.setFieldsValue(formVars);
			
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.LeadListComponent_288211_onChange1_();
                  resolve();
                });
          })



        
        KuikaAppManager.hideSpinner(this);
        return isErrorOccurred;
    }
		LeadListComponent_288211_onChange1_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }

				formVars.leadlist_893473_value = ReactSystemFunctions.toString(this, (stateVars.TMLeadProcessCountSummary !== undefined ? (stateVars.TMLeadProcessCountSummary?.length > 0 ? stateVars.TMLeadProcessCountSummary[0].toplamTalepSayisi : null) : (this.state.TMLeadProcessCountSummary?.length > 0 ? this.state.TMLeadProcessCountSummary[0].toplamTalepSayisi : null)));

				formVars.leadlist_864952_value = ReactSystemFunctions.toString(this, (stateVars.TMLeadProcessCountSummary !== undefined ? (stateVars.TMLeadProcessCountSummary?.length > 0 ? stateVars.TMLeadProcessCountSummary[0].onayBekleyenSayisi : null) : (this.state.TMLeadProcessCountSummary?.length > 0 ? this.state.TMLeadProcessCountSummary[0].onayBekleyenSayisi : null)));

				formVars.leadlist_844329_value = ReactSystemFunctions.toString(this, (stateVars.TMLeadProcessCountSummary !== undefined ? (stateVars.TMLeadProcessCountSummary?.length > 0 ? stateVars.TMLeadProcessCountSummary[0].terminBekleyenSayisi : null) : (this.state.TMLeadProcessCountSummary?.length > 0 ? this.state.TMLeadProcessCountSummary[0].terminBekleyenSayisi : null)));

				formVars.leadlist_574886_value = ReactSystemFunctions.toString(this, (stateVars.TMLeadProcessCountSummary !== undefined ? (stateVars.TMLeadProcessCountSummary?.length > 0 ? stateVars.TMLeadProcessCountSummary[0].onaylananSayisi : null) : (this.state.TMLeadProcessCountSummary?.length > 0 ? this.state.TMLeadProcessCountSummary[0].onaylananSayisi : null)));

				formVars.leadlist_582775_value = ReactSystemFunctions.toString(this, (stateVars.TMLeadProcessCountSummary !== undefined ? (stateVars.TMLeadProcessCountSummary?.length > 0 ? stateVars.TMLeadProcessCountSummary[0].reddedilenSayisi : null) : (this.state.TMLeadProcessCountSummary?.length > 0 ? this.state.TMLeadProcessCountSummary[0].reddedilenSayisi : null)));

				formVars.leadlist_207750_value = ReactSystemFunctions.toString(this, (stateVars.TMLeadProcessCountSummary !== undefined ? (stateVars.TMLeadProcessCountSummary?.length > 0 ? stateVars.TMLeadProcessCountSummary[0].teslimEdilecekSayisi : null) : (this.state.TMLeadProcessCountSummary?.length > 0 ? this.state.TMLeadProcessCountSummary[0].teslimEdilecekSayisi : null)));

				formVars.leadlist_967794_value = ReactSystemFunctions.toString(this, (stateVars.TMLeadProcessCountSummary !== undefined ? (stateVars.TMLeadProcessCountSummary?.length > 0 ? stateVars.TMLeadProcessCountSummary[0].teslimEdildiSayisi : null) : (this.state.TMLeadProcessCountSummary?.length > 0 ? this.state.TMLeadProcessCountSummary[0].teslimEdildiSayisi : null)));

				
				stateVars.dataSource_414332 = stateVars.TM_GetLeads ?? this.state.TM_GetLeads;

		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

            
            return isErrorOccurred;
        }




    LeadListComponent_776113_onChange = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
		KuikaAppManager.increaseServerRequestCount();

        let localVar = {
				StepOrder_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, (stateVars.TM_GetLeads !== undefined ? (stateVars.TM_GetLeads?.length > 0 ? stateVars.TM_GetLeads[0].selectedStepOrder : null) : (this.state.TM_GetLeads?.length > 0 ? this.state.TM_GetLeads[0].selectedStepOrder : null))), "number"),
				UserId_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.getMyUserId(), "Guid"),
				MusteriAdi_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "leadlist_288211_value", "value", "", "", "")), "string"),
				ProductName_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "leadlist_576673_value", "value", "", "", "")), "string"),
				LeadCode_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "leadlist_60588_value", "value", "", "", "")), "string"),
				Tel_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "leadlist_776113_value", "value", "", "", "")), "string"),
				CategoryName_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "leadlist_836823_value", "value", "TM_GetProductCategory", "categoryName", "categoryName")), "string"),
				StoreIds_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "leadlist_314150_value", "value", "TM_GetStore", "storeCode", "id")), "string"),
				SatisDanismaniIds_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "leadlist_872239_value", "value", "TM_GetSalesPerson", "kUserId", "kUserId")), "string"),
				ProcessCode_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "leadlist_161661_value", "value", "TM_GetLeadProcess", "id", "code")), "string"),
				StartDate_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "leadlist_980795_value", "value", "", "", "")), "Date"),
				EndDate_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "leadlist_6623_value", "value", "", "", "")), "Date"),
				UserId_1: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.getMyUserId(), "Guid"),
				MusteriAdi_1: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "leadlist_288211_value", "value", "", "", "")), "string"),
				ProductName_1: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "leadlist_576673_value", "value", "", "", "")), "string"),
				LeadCode_1: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "leadlist_60588_value", "value", "", "", "")), "string"),
				Tel_1: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "leadlist_776113_value", "value", "", "", "")), "string"),
				CategoryName_1: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "leadlist_836823_value", "value", "TM_GetProductCategory", "categoryName", "categoryName")), "string"),
				StoreIds_1: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "leadlist_314150_value", "value", "TM_GetStore", "storeCode", "id")), "string"),
				SatisDanismaniIds_1: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "leadlist_872239_value", "value", "TM_GetSalesPerson", "kUserId", "kUserId")), "string"),
				ProcessCode_1: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "leadlist_161661_value", "value", "TM_GetLeadProcess", "id", "code")), "string"),
				StartDate_1: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "leadlist_980795_value", "value", "", "", "")), "Date"),
				EndDate_1: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "leadlist_6623_value", "value", "", "", "")), "Date")
        }

		KuikaAppManager.showSpinner(this);
		
        if (true) {
        KuikaAppManager.showSpinner(this);
        }
        let result = await KuikaAppManager.ApiRequest(this, "LeadList/LeadListComponent_776113_onChange", localVar)
        if (!KMainFunctions.IsResStatus2XX(result)) return true;

			stateVars.TM_GetLeads = result?.data.tM_GetLeads;
			
			stateVars.TMLeadProcessCountSummary = result?.data.tmLeadProcessCountSummary;
			formVars.leadlist_893473_value = ReactSystemFunctions.toString(this, (stateVars.TMLeadProcessCountSummary !== undefined ? (stateVars.TMLeadProcessCountSummary?.length > 0 ? stateVars.TMLeadProcessCountSummary[0].toplamTalepSayisi : null) : (this.state.TMLeadProcessCountSummary?.length > 0 ? this.state.TMLeadProcessCountSummary[0].toplamTalepSayisi : null)));
			formVars.leadlist_864952_value = ReactSystemFunctions.toString(this, (stateVars.TMLeadProcessCountSummary !== undefined ? (stateVars.TMLeadProcessCountSummary?.length > 0 ? stateVars.TMLeadProcessCountSummary[0].onayBekleyenSayisi : null) : (this.state.TMLeadProcessCountSummary?.length > 0 ? this.state.TMLeadProcessCountSummary[0].onayBekleyenSayisi : null)));
			formVars.leadlist_844329_value = ReactSystemFunctions.toString(this, (stateVars.TMLeadProcessCountSummary !== undefined ? (stateVars.TMLeadProcessCountSummary?.length > 0 ? stateVars.TMLeadProcessCountSummary[0].terminBekleyenSayisi : null) : (this.state.TMLeadProcessCountSummary?.length > 0 ? this.state.TMLeadProcessCountSummary[0].terminBekleyenSayisi : null)));
			formVars.leadlist_574886_value = ReactSystemFunctions.toString(this, (stateVars.TMLeadProcessCountSummary !== undefined ? (stateVars.TMLeadProcessCountSummary?.length > 0 ? stateVars.TMLeadProcessCountSummary[0].onaylananSayisi : null) : (this.state.TMLeadProcessCountSummary?.length > 0 ? this.state.TMLeadProcessCountSummary[0].onaylananSayisi : null)));
			formVars.leadlist_582775_value = ReactSystemFunctions.toString(this, (stateVars.TMLeadProcessCountSummary !== undefined ? (stateVars.TMLeadProcessCountSummary?.length > 0 ? stateVars.TMLeadProcessCountSummary[0].reddedilenSayisi : null) : (this.state.TMLeadProcessCountSummary?.length > 0 ? this.state.TMLeadProcessCountSummary[0].reddedilenSayisi : null)));
			formVars.leadlist_207750_value = ReactSystemFunctions.toString(this, (stateVars.TMLeadProcessCountSummary !== undefined ? (stateVars.TMLeadProcessCountSummary?.length > 0 ? stateVars.TMLeadProcessCountSummary[0].teslimEdilecekSayisi : null) : (this.state.TMLeadProcessCountSummary?.length > 0 ? this.state.TMLeadProcessCountSummary[0].teslimEdilecekSayisi : null)));
			formVars.leadlist_967794_value = ReactSystemFunctions.toString(this, (stateVars.TMLeadProcessCountSummary !== undefined ? (stateVars.TMLeadProcessCountSummary?.length > 0 ? stateVars.TMLeadProcessCountSummary[0].teslimEdildiSayisi : null) : (this.state.TMLeadProcessCountSummary?.length > 0 ? this.state.TMLeadProcessCountSummary[0].teslimEdildiSayisi : null)));
			this.props.form?.setFieldsValue(formVars);
			
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.LeadListComponent_776113_onChange1_();
                  resolve();
                });
          })



        
        KuikaAppManager.hideSpinner(this);
        return isErrorOccurred;
    }
		LeadListComponent_776113_onChange1_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }

				formVars.leadlist_893473_value = ReactSystemFunctions.toString(this, (stateVars.TMLeadProcessCountSummary !== undefined ? (stateVars.TMLeadProcessCountSummary?.length > 0 ? stateVars.TMLeadProcessCountSummary[0].toplamTalepSayisi : null) : (this.state.TMLeadProcessCountSummary?.length > 0 ? this.state.TMLeadProcessCountSummary[0].toplamTalepSayisi : null)));

				formVars.leadlist_864952_value = ReactSystemFunctions.toString(this, (stateVars.TMLeadProcessCountSummary !== undefined ? (stateVars.TMLeadProcessCountSummary?.length > 0 ? stateVars.TMLeadProcessCountSummary[0].onayBekleyenSayisi : null) : (this.state.TMLeadProcessCountSummary?.length > 0 ? this.state.TMLeadProcessCountSummary[0].onayBekleyenSayisi : null)));

				formVars.leadlist_844329_value = ReactSystemFunctions.toString(this, (stateVars.TMLeadProcessCountSummary !== undefined ? (stateVars.TMLeadProcessCountSummary?.length > 0 ? stateVars.TMLeadProcessCountSummary[0].terminBekleyenSayisi : null) : (this.state.TMLeadProcessCountSummary?.length > 0 ? this.state.TMLeadProcessCountSummary[0].terminBekleyenSayisi : null)));

				formVars.leadlist_574886_value = ReactSystemFunctions.toString(this, (stateVars.TMLeadProcessCountSummary !== undefined ? (stateVars.TMLeadProcessCountSummary?.length > 0 ? stateVars.TMLeadProcessCountSummary[0].onaylananSayisi : null) : (this.state.TMLeadProcessCountSummary?.length > 0 ? this.state.TMLeadProcessCountSummary[0].onaylananSayisi : null)));

				formVars.leadlist_582775_value = ReactSystemFunctions.toString(this, (stateVars.TMLeadProcessCountSummary !== undefined ? (stateVars.TMLeadProcessCountSummary?.length > 0 ? stateVars.TMLeadProcessCountSummary[0].reddedilenSayisi : null) : (this.state.TMLeadProcessCountSummary?.length > 0 ? this.state.TMLeadProcessCountSummary[0].reddedilenSayisi : null)));

				formVars.leadlist_207750_value = ReactSystemFunctions.toString(this, (stateVars.TMLeadProcessCountSummary !== undefined ? (stateVars.TMLeadProcessCountSummary?.length > 0 ? stateVars.TMLeadProcessCountSummary[0].teslimEdilecekSayisi : null) : (this.state.TMLeadProcessCountSummary?.length > 0 ? this.state.TMLeadProcessCountSummary[0].teslimEdilecekSayisi : null)));

				formVars.leadlist_967794_value = ReactSystemFunctions.toString(this, (stateVars.TMLeadProcessCountSummary !== undefined ? (stateVars.TMLeadProcessCountSummary?.length > 0 ? stateVars.TMLeadProcessCountSummary[0].teslimEdildiSayisi : null) : (this.state.TMLeadProcessCountSummary?.length > 0 ? this.state.TMLeadProcessCountSummary[0].teslimEdildiSayisi : null)));

				
				stateVars.dataSource_414332 = stateVars.TM_GetLeads ?? this.state.TM_GetLeads;

		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

            
            return isErrorOccurred;
        }




    LeadListComponent_576673_onChange = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
		KuikaAppManager.increaseServerRequestCount();

        let localVar = {
				StepOrder_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, (stateVars.TM_GetLeads !== undefined ? (stateVars.TM_GetLeads?.length > 0 ? stateVars.TM_GetLeads[0].selectedStepOrder : null) : (this.state.TM_GetLeads?.length > 0 ? this.state.TM_GetLeads[0].selectedStepOrder : null))), "number"),
				UserId_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.getMyUserId(), "Guid"),
				MusteriAdi_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "leadlist_288211_value", "value", "", "", "")), "string"),
				ProductName_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "leadlist_576673_value", "value", "", "", "")), "string"),
				LeadCode_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "leadlist_60588_value", "value", "", "", "")), "string"),
				Tel_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "leadlist_776113_value", "value", "", "", "")), "string"),
				CategoryName_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "leadlist_836823_value", "value", "TM_GetProductCategory", "categoryName", "categoryName")), "string"),
				StoreIds_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "leadlist_314150_value", "value", "TM_GetStore", "storeCode", "id")), "string"),
				SatisDanismaniIds_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "leadlist_872239_value", "value", "TM_GetSalesPerson", "kUserId", "kUserId")), "string"),
				ProcessCode_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "leadlist_161661_value", "value", "TM_GetLeadProcess", "id", "code")), "string"),
				StartDate_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "leadlist_980795_value", "value", "", "", "")), "Date"),
				EndDate_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "leadlist_6623_value", "value", "", "", "")), "Date"),
				UserId_1: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.getMyUserId(), "Guid"),
				MusteriAdi_1: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "leadlist_288211_value", "value", "", "", "")), "string"),
				ProductName_1: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "leadlist_576673_value", "value", "", "", "")), "string"),
				LeadCode_1: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "leadlist_60588_value", "value", "", "", "")), "string"),
				Tel_1: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "leadlist_776113_value", "value", "", "", "")), "string"),
				CategoryName_1: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "leadlist_836823_value", "value", "TM_GetProductCategory", "categoryName", "categoryName")), "string"),
				StoreIds_1: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "leadlist_314150_value", "value", "TM_GetStore", "storeCode", "id")), "string"),
				SatisDanismaniIds_1: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "leadlist_872239_value", "value", "TM_GetSalesPerson", "kUserId", "kUserId")), "string"),
				ProcessCode_1: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "leadlist_161661_value", "value", "TM_GetLeadProcess", "id", "code")), "string"),
				StartDate_1: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "leadlist_980795_value", "value", "", "", "")), "Date"),
				EndDate_1: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "leadlist_6623_value", "value", "", "", "")), "Date")
        }

		KuikaAppManager.showSpinner(this);
		
        if (true) {
        KuikaAppManager.showSpinner(this);
        }
        let result = await KuikaAppManager.ApiRequest(this, "LeadList/LeadListComponent_576673_onChange", localVar)
        if (!KMainFunctions.IsResStatus2XX(result)) return true;

			stateVars.TM_GetLeads = result?.data.tM_GetLeads;
			
			stateVars.TMLeadProcessCountSummary = result?.data.tmLeadProcessCountSummary;
			formVars.leadlist_893473_value = ReactSystemFunctions.toString(this, (stateVars.TMLeadProcessCountSummary !== undefined ? (stateVars.TMLeadProcessCountSummary?.length > 0 ? stateVars.TMLeadProcessCountSummary[0].toplamTalepSayisi : null) : (this.state.TMLeadProcessCountSummary?.length > 0 ? this.state.TMLeadProcessCountSummary[0].toplamTalepSayisi : null)));
			formVars.leadlist_864952_value = ReactSystemFunctions.toString(this, (stateVars.TMLeadProcessCountSummary !== undefined ? (stateVars.TMLeadProcessCountSummary?.length > 0 ? stateVars.TMLeadProcessCountSummary[0].onayBekleyenSayisi : null) : (this.state.TMLeadProcessCountSummary?.length > 0 ? this.state.TMLeadProcessCountSummary[0].onayBekleyenSayisi : null)));
			formVars.leadlist_844329_value = ReactSystemFunctions.toString(this, (stateVars.TMLeadProcessCountSummary !== undefined ? (stateVars.TMLeadProcessCountSummary?.length > 0 ? stateVars.TMLeadProcessCountSummary[0].terminBekleyenSayisi : null) : (this.state.TMLeadProcessCountSummary?.length > 0 ? this.state.TMLeadProcessCountSummary[0].terminBekleyenSayisi : null)));
			formVars.leadlist_574886_value = ReactSystemFunctions.toString(this, (stateVars.TMLeadProcessCountSummary !== undefined ? (stateVars.TMLeadProcessCountSummary?.length > 0 ? stateVars.TMLeadProcessCountSummary[0].onaylananSayisi : null) : (this.state.TMLeadProcessCountSummary?.length > 0 ? this.state.TMLeadProcessCountSummary[0].onaylananSayisi : null)));
			formVars.leadlist_582775_value = ReactSystemFunctions.toString(this, (stateVars.TMLeadProcessCountSummary !== undefined ? (stateVars.TMLeadProcessCountSummary?.length > 0 ? stateVars.TMLeadProcessCountSummary[0].reddedilenSayisi : null) : (this.state.TMLeadProcessCountSummary?.length > 0 ? this.state.TMLeadProcessCountSummary[0].reddedilenSayisi : null)));
			formVars.leadlist_207750_value = ReactSystemFunctions.toString(this, (stateVars.TMLeadProcessCountSummary !== undefined ? (stateVars.TMLeadProcessCountSummary?.length > 0 ? stateVars.TMLeadProcessCountSummary[0].teslimEdilecekSayisi : null) : (this.state.TMLeadProcessCountSummary?.length > 0 ? this.state.TMLeadProcessCountSummary[0].teslimEdilecekSayisi : null)));
			formVars.leadlist_967794_value = ReactSystemFunctions.toString(this, (stateVars.TMLeadProcessCountSummary !== undefined ? (stateVars.TMLeadProcessCountSummary?.length > 0 ? stateVars.TMLeadProcessCountSummary[0].teslimEdildiSayisi : null) : (this.state.TMLeadProcessCountSummary?.length > 0 ? this.state.TMLeadProcessCountSummary[0].teslimEdildiSayisi : null)));
			this.props.form?.setFieldsValue(formVars);
			
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.LeadListComponent_576673_onChange1_();
                  resolve();
                });
          })



        
        KuikaAppManager.hideSpinner(this);
        return isErrorOccurred;
    }
		LeadListComponent_576673_onChange1_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }

				formVars.leadlist_893473_value = ReactSystemFunctions.toString(this, (stateVars.TMLeadProcessCountSummary !== undefined ? (stateVars.TMLeadProcessCountSummary?.length > 0 ? stateVars.TMLeadProcessCountSummary[0].toplamTalepSayisi : null) : (this.state.TMLeadProcessCountSummary?.length > 0 ? this.state.TMLeadProcessCountSummary[0].toplamTalepSayisi : null)));

				formVars.leadlist_864952_value = ReactSystemFunctions.toString(this, (stateVars.TMLeadProcessCountSummary !== undefined ? (stateVars.TMLeadProcessCountSummary?.length > 0 ? stateVars.TMLeadProcessCountSummary[0].onayBekleyenSayisi : null) : (this.state.TMLeadProcessCountSummary?.length > 0 ? this.state.TMLeadProcessCountSummary[0].onayBekleyenSayisi : null)));

				formVars.leadlist_844329_value = ReactSystemFunctions.toString(this, (stateVars.TMLeadProcessCountSummary !== undefined ? (stateVars.TMLeadProcessCountSummary?.length > 0 ? stateVars.TMLeadProcessCountSummary[0].terminBekleyenSayisi : null) : (this.state.TMLeadProcessCountSummary?.length > 0 ? this.state.TMLeadProcessCountSummary[0].terminBekleyenSayisi : null)));

				formVars.leadlist_574886_value = ReactSystemFunctions.toString(this, (stateVars.TMLeadProcessCountSummary !== undefined ? (stateVars.TMLeadProcessCountSummary?.length > 0 ? stateVars.TMLeadProcessCountSummary[0].onaylananSayisi : null) : (this.state.TMLeadProcessCountSummary?.length > 0 ? this.state.TMLeadProcessCountSummary[0].onaylananSayisi : null)));

				formVars.leadlist_582775_value = ReactSystemFunctions.toString(this, (stateVars.TMLeadProcessCountSummary !== undefined ? (stateVars.TMLeadProcessCountSummary?.length > 0 ? stateVars.TMLeadProcessCountSummary[0].reddedilenSayisi : null) : (this.state.TMLeadProcessCountSummary?.length > 0 ? this.state.TMLeadProcessCountSummary[0].reddedilenSayisi : null)));

				formVars.leadlist_207750_value = ReactSystemFunctions.toString(this, (stateVars.TMLeadProcessCountSummary !== undefined ? (stateVars.TMLeadProcessCountSummary?.length > 0 ? stateVars.TMLeadProcessCountSummary[0].teslimEdilecekSayisi : null) : (this.state.TMLeadProcessCountSummary?.length > 0 ? this.state.TMLeadProcessCountSummary[0].teslimEdilecekSayisi : null)));

				formVars.leadlist_967794_value = ReactSystemFunctions.toString(this, (stateVars.TMLeadProcessCountSummary !== undefined ? (stateVars.TMLeadProcessCountSummary?.length > 0 ? stateVars.TMLeadProcessCountSummary[0].teslimEdildiSayisi : null) : (this.state.TMLeadProcessCountSummary?.length > 0 ? this.state.TMLeadProcessCountSummary[0].teslimEdildiSayisi : null)));

				
				stateVars.dataSource_414332 = stateVars.TM_GetLeads ?? this.state.TM_GetLeads;

		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

            
            return isErrorOccurred;
        }




    LeadListComponent_836823_onChange = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
		KuikaAppManager.increaseServerRequestCount();

        let localVar = {
				StepOrder_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, (stateVars.TM_GetLeads !== undefined ? (stateVars.TM_GetLeads?.length > 0 ? stateVars.TM_GetLeads[0].selectedStepOrder : null) : (this.state.TM_GetLeads?.length > 0 ? this.state.TM_GetLeads[0].selectedStepOrder : null))), "number"),
				UserId_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.getMyUserId(), "Guid"),
				MusteriAdi_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "leadlist_288211_value", "value", "", "", "")), "string"),
				ProductName_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "leadlist_576673_value", "value", "", "", "")), "string"),
				LeadCode_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "leadlist_60588_value", "value", "", "", "")), "string"),
				Tel_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "leadlist_776113_value", "value", "", "", "")), "string"),
				CategoryName_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "leadlist_836823_value", "value", "TM_GetProductCategory", "categoryName", "categoryName")), "string"),
				StoreIds_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "leadlist_314150_value", "value", "TM_GetStore", "storeCode", "id")), "string"),
				SatisDanismaniIds_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "leadlist_872239_value", "value", "TM_GetSalesPerson", "kUserId", "kUserId")), "string"),
				ProcessCode_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "leadlist_161661_value", "value", "TM_GetLeadProcess", "id", "code")), "string"),
				StartDate_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "leadlist_980795_value", "value", "", "", "")), "Date"),
				EndDate_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "leadlist_6623_value", "value", "", "", "")), "Date"),
				UserId_1: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.getMyUserId(), "Guid"),
				MusteriAdi_1: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "leadlist_288211_value", "value", "", "", "")), "string"),
				ProductName_1: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "leadlist_576673_value", "value", "", "", "")), "string"),
				LeadCode_1: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "leadlist_60588_value", "value", "", "", "")), "string"),
				Tel_1: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "leadlist_776113_value", "value", "", "", "")), "string"),
				CategoryName_1: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "leadlist_836823_value", "value", "TM_GetProductCategory", "categoryName", "categoryName")), "string"),
				StoreIds_1: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "leadlist_314150_value", "value", "TM_GetStore", "storeCode", "id")), "string"),
				SatisDanismaniIds_1: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "leadlist_872239_value", "value", "TM_GetSalesPerson", "kUserId", "kUserId")), "string"),
				ProcessCode_1: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "leadlist_161661_value", "value", "TM_GetLeadProcess", "id", "code")), "string"),
				StartDate_1: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "leadlist_980795_value", "value", "", "", "")), "Date"),
				EndDate_1: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "leadlist_6623_value", "value", "", "", "")), "Date")
        }

		KuikaAppManager.showSpinner(this);
		
        if (true) {
        KuikaAppManager.showSpinner(this);
        }
        let result = await KuikaAppManager.ApiRequest(this, "LeadList/LeadListComponent_836823_onChange", localVar)
        if (!KMainFunctions.IsResStatus2XX(result)) return true;

			stateVars.TM_GetLeads = result?.data.tM_GetLeads;
			
			stateVars.TMLeadProcessCountSummary = result?.data.tmLeadProcessCountSummary;
			formVars.leadlist_893473_value = ReactSystemFunctions.toString(this, (stateVars.TMLeadProcessCountSummary !== undefined ? (stateVars.TMLeadProcessCountSummary?.length > 0 ? stateVars.TMLeadProcessCountSummary[0].toplamTalepSayisi : null) : (this.state.TMLeadProcessCountSummary?.length > 0 ? this.state.TMLeadProcessCountSummary[0].toplamTalepSayisi : null)));
			formVars.leadlist_864952_value = ReactSystemFunctions.toString(this, (stateVars.TMLeadProcessCountSummary !== undefined ? (stateVars.TMLeadProcessCountSummary?.length > 0 ? stateVars.TMLeadProcessCountSummary[0].onayBekleyenSayisi : null) : (this.state.TMLeadProcessCountSummary?.length > 0 ? this.state.TMLeadProcessCountSummary[0].onayBekleyenSayisi : null)));
			formVars.leadlist_844329_value = ReactSystemFunctions.toString(this, (stateVars.TMLeadProcessCountSummary !== undefined ? (stateVars.TMLeadProcessCountSummary?.length > 0 ? stateVars.TMLeadProcessCountSummary[0].terminBekleyenSayisi : null) : (this.state.TMLeadProcessCountSummary?.length > 0 ? this.state.TMLeadProcessCountSummary[0].terminBekleyenSayisi : null)));
			formVars.leadlist_574886_value = ReactSystemFunctions.toString(this, (stateVars.TMLeadProcessCountSummary !== undefined ? (stateVars.TMLeadProcessCountSummary?.length > 0 ? stateVars.TMLeadProcessCountSummary[0].onaylananSayisi : null) : (this.state.TMLeadProcessCountSummary?.length > 0 ? this.state.TMLeadProcessCountSummary[0].onaylananSayisi : null)));
			formVars.leadlist_582775_value = ReactSystemFunctions.toString(this, (stateVars.TMLeadProcessCountSummary !== undefined ? (stateVars.TMLeadProcessCountSummary?.length > 0 ? stateVars.TMLeadProcessCountSummary[0].reddedilenSayisi : null) : (this.state.TMLeadProcessCountSummary?.length > 0 ? this.state.TMLeadProcessCountSummary[0].reddedilenSayisi : null)));
			formVars.leadlist_207750_value = ReactSystemFunctions.toString(this, (stateVars.TMLeadProcessCountSummary !== undefined ? (stateVars.TMLeadProcessCountSummary?.length > 0 ? stateVars.TMLeadProcessCountSummary[0].teslimEdilecekSayisi : null) : (this.state.TMLeadProcessCountSummary?.length > 0 ? this.state.TMLeadProcessCountSummary[0].teslimEdilecekSayisi : null)));
			formVars.leadlist_967794_value = ReactSystemFunctions.toString(this, (stateVars.TMLeadProcessCountSummary !== undefined ? (stateVars.TMLeadProcessCountSummary?.length > 0 ? stateVars.TMLeadProcessCountSummary[0].teslimEdildiSayisi : null) : (this.state.TMLeadProcessCountSummary?.length > 0 ? this.state.TMLeadProcessCountSummary[0].teslimEdildiSayisi : null)));
			this.props.form?.setFieldsValue(formVars);
			
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.LeadListComponent_836823_onChange1_();
                  resolve();
                });
          })



        
        KuikaAppManager.hideSpinner(this);
        return isErrorOccurred;
    }
		LeadListComponent_836823_onChange1_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }

				formVars.leadlist_893473_value = ReactSystemFunctions.toString(this, (stateVars.TMLeadProcessCountSummary !== undefined ? (stateVars.TMLeadProcessCountSummary?.length > 0 ? stateVars.TMLeadProcessCountSummary[0].toplamTalepSayisi : null) : (this.state.TMLeadProcessCountSummary?.length > 0 ? this.state.TMLeadProcessCountSummary[0].toplamTalepSayisi : null)));

				formVars.leadlist_864952_value = ReactSystemFunctions.toString(this, (stateVars.TMLeadProcessCountSummary !== undefined ? (stateVars.TMLeadProcessCountSummary?.length > 0 ? stateVars.TMLeadProcessCountSummary[0].onayBekleyenSayisi : null) : (this.state.TMLeadProcessCountSummary?.length > 0 ? this.state.TMLeadProcessCountSummary[0].onayBekleyenSayisi : null)));

				formVars.leadlist_844329_value = ReactSystemFunctions.toString(this, (stateVars.TMLeadProcessCountSummary !== undefined ? (stateVars.TMLeadProcessCountSummary?.length > 0 ? stateVars.TMLeadProcessCountSummary[0].terminBekleyenSayisi : null) : (this.state.TMLeadProcessCountSummary?.length > 0 ? this.state.TMLeadProcessCountSummary[0].terminBekleyenSayisi : null)));

				formVars.leadlist_574886_value = ReactSystemFunctions.toString(this, (stateVars.TMLeadProcessCountSummary !== undefined ? (stateVars.TMLeadProcessCountSummary?.length > 0 ? stateVars.TMLeadProcessCountSummary[0].onaylananSayisi : null) : (this.state.TMLeadProcessCountSummary?.length > 0 ? this.state.TMLeadProcessCountSummary[0].onaylananSayisi : null)));

				formVars.leadlist_582775_value = ReactSystemFunctions.toString(this, (stateVars.TMLeadProcessCountSummary !== undefined ? (stateVars.TMLeadProcessCountSummary?.length > 0 ? stateVars.TMLeadProcessCountSummary[0].reddedilenSayisi : null) : (this.state.TMLeadProcessCountSummary?.length > 0 ? this.state.TMLeadProcessCountSummary[0].reddedilenSayisi : null)));

				formVars.leadlist_207750_value = ReactSystemFunctions.toString(this, (stateVars.TMLeadProcessCountSummary !== undefined ? (stateVars.TMLeadProcessCountSummary?.length > 0 ? stateVars.TMLeadProcessCountSummary[0].teslimEdilecekSayisi : null) : (this.state.TMLeadProcessCountSummary?.length > 0 ? this.state.TMLeadProcessCountSummary[0].teslimEdilecekSayisi : null)));

				formVars.leadlist_967794_value = ReactSystemFunctions.toString(this, (stateVars.TMLeadProcessCountSummary !== undefined ? (stateVars.TMLeadProcessCountSummary?.length > 0 ? stateVars.TMLeadProcessCountSummary[0].teslimEdildiSayisi : null) : (this.state.TMLeadProcessCountSummary?.length > 0 ? this.state.TMLeadProcessCountSummary[0].teslimEdildiSayisi : null)));

				
				stateVars.dataSource_414332 = stateVars.TM_GetLeads ?? this.state.TM_GetLeads;

		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

            
            return isErrorOccurred;
        }




    LeadListComponent_314150_onChange = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
		KuikaAppManager.increaseServerRequestCount();

        let localVar = {
				StepOrder_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, (stateVars.TM_GetLeads !== undefined ? (stateVars.TM_GetLeads?.length > 0 ? stateVars.TM_GetLeads[0].selectedStepOrder : null) : (this.state.TM_GetLeads?.length > 0 ? this.state.TM_GetLeads[0].selectedStepOrder : null))), "number"),
				UserId_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.getMyUserId(), "Guid"),
				MusteriAdi_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "leadlist_288211_value", "value", "", "", "")), "string"),
				ProductName_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "leadlist_576673_value", "value", "", "", "")), "string"),
				LeadCode_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "leadlist_60588_value", "value", "", "", "")), "string"),
				Tel_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "leadlist_776113_value", "value", "", "", "")), "string"),
				CategoryName_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "leadlist_836823_value", "value", "TM_GetProductCategory", "categoryName", "categoryName")), "string"),
				StoreIds_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "leadlist_314150_value", "value", "TM_GetStore", "storeCode", "id")), "string"),
				SatisDanismaniIds_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "leadlist_872239_value", "value", "TM_GetSalesPerson", "kUserId", "kUserId")), "string"),
				ProcessCode_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "leadlist_161661_value", "value", "TM_GetLeadProcess", "id", "code")), "string"),
				StartDate_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "leadlist_980795_value", "value", "", "", "")), "Date"),
				EndDate_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "leadlist_6623_value", "value", "", "", "")), "Date"),
				UserId_1: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.getMyUserId(), "Guid"),
				MusteriAdi_1: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "leadlist_288211_value", "value", "", "", "")), "string"),
				ProductName_1: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "leadlist_576673_value", "value", "", "", "")), "string"),
				LeadCode_1: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "leadlist_60588_value", "value", "", "", "")), "string"),
				Tel_1: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "leadlist_776113_value", "value", "", "", "")), "string"),
				CategoryName_1: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "leadlist_836823_value", "value", "TM_GetProductCategory", "categoryName", "categoryName")), "string"),
				StoreIds_1: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "leadlist_314150_value", "value", "TM_GetStore", "storeCode", "id")), "string"),
				SatisDanismaniIds_1: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "leadlist_872239_value", "value", "TM_GetSalesPerson", "kUserId", "kUserId")), "string"),
				ProcessCode_1: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "leadlist_161661_value", "value", "TM_GetLeadProcess", "id", "code")), "string"),
				StartDate_1: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "leadlist_980795_value", "value", "", "", "")), "Date"),
				EndDate_1: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "leadlist_6623_value", "value", "", "", "")), "Date")
        }

		KuikaAppManager.showSpinner(this);
		
        if (true) {
        KuikaAppManager.showSpinner(this);
        }
        let result = await KuikaAppManager.ApiRequest(this, "LeadList/LeadListComponent_314150_onChange", localVar)
        if (!KMainFunctions.IsResStatus2XX(result)) return true;

			stateVars.TM_GetLeads = result?.data.tM_GetLeads;
			
			stateVars.TMLeadProcessCountSummary = result?.data.tmLeadProcessCountSummary;
			formVars.leadlist_893473_value = ReactSystemFunctions.toString(this, (stateVars.TMLeadProcessCountSummary !== undefined ? (stateVars.TMLeadProcessCountSummary?.length > 0 ? stateVars.TMLeadProcessCountSummary[0].toplamTalepSayisi : null) : (this.state.TMLeadProcessCountSummary?.length > 0 ? this.state.TMLeadProcessCountSummary[0].toplamTalepSayisi : null)));
			formVars.leadlist_864952_value = ReactSystemFunctions.toString(this, (stateVars.TMLeadProcessCountSummary !== undefined ? (stateVars.TMLeadProcessCountSummary?.length > 0 ? stateVars.TMLeadProcessCountSummary[0].onayBekleyenSayisi : null) : (this.state.TMLeadProcessCountSummary?.length > 0 ? this.state.TMLeadProcessCountSummary[0].onayBekleyenSayisi : null)));
			formVars.leadlist_844329_value = ReactSystemFunctions.toString(this, (stateVars.TMLeadProcessCountSummary !== undefined ? (stateVars.TMLeadProcessCountSummary?.length > 0 ? stateVars.TMLeadProcessCountSummary[0].terminBekleyenSayisi : null) : (this.state.TMLeadProcessCountSummary?.length > 0 ? this.state.TMLeadProcessCountSummary[0].terminBekleyenSayisi : null)));
			formVars.leadlist_574886_value = ReactSystemFunctions.toString(this, (stateVars.TMLeadProcessCountSummary !== undefined ? (stateVars.TMLeadProcessCountSummary?.length > 0 ? stateVars.TMLeadProcessCountSummary[0].onaylananSayisi : null) : (this.state.TMLeadProcessCountSummary?.length > 0 ? this.state.TMLeadProcessCountSummary[0].onaylananSayisi : null)));
			formVars.leadlist_582775_value = ReactSystemFunctions.toString(this, (stateVars.TMLeadProcessCountSummary !== undefined ? (stateVars.TMLeadProcessCountSummary?.length > 0 ? stateVars.TMLeadProcessCountSummary[0].reddedilenSayisi : null) : (this.state.TMLeadProcessCountSummary?.length > 0 ? this.state.TMLeadProcessCountSummary[0].reddedilenSayisi : null)));
			formVars.leadlist_207750_value = ReactSystemFunctions.toString(this, (stateVars.TMLeadProcessCountSummary !== undefined ? (stateVars.TMLeadProcessCountSummary?.length > 0 ? stateVars.TMLeadProcessCountSummary[0].teslimEdilecekSayisi : null) : (this.state.TMLeadProcessCountSummary?.length > 0 ? this.state.TMLeadProcessCountSummary[0].teslimEdilecekSayisi : null)));
			formVars.leadlist_967794_value = ReactSystemFunctions.toString(this, (stateVars.TMLeadProcessCountSummary !== undefined ? (stateVars.TMLeadProcessCountSummary?.length > 0 ? stateVars.TMLeadProcessCountSummary[0].teslimEdildiSayisi : null) : (this.state.TMLeadProcessCountSummary?.length > 0 ? this.state.TMLeadProcessCountSummary[0].teslimEdildiSayisi : null)));
			this.props.form?.setFieldsValue(formVars);
			
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.LeadListComponent_314150_onChange1_();
                  resolve();
                });
          })



        
        KuikaAppManager.hideSpinner(this);
        return isErrorOccurred;
    }
		LeadListComponent_314150_onChange1_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }

				formVars.leadlist_893473_value = ReactSystemFunctions.toString(this, (stateVars.TMLeadProcessCountSummary !== undefined ? (stateVars.TMLeadProcessCountSummary?.length > 0 ? stateVars.TMLeadProcessCountSummary[0].toplamTalepSayisi : null) : (this.state.TMLeadProcessCountSummary?.length > 0 ? this.state.TMLeadProcessCountSummary[0].toplamTalepSayisi : null)));

				formVars.leadlist_864952_value = ReactSystemFunctions.toString(this, (stateVars.TMLeadProcessCountSummary !== undefined ? (stateVars.TMLeadProcessCountSummary?.length > 0 ? stateVars.TMLeadProcessCountSummary[0].onayBekleyenSayisi : null) : (this.state.TMLeadProcessCountSummary?.length > 0 ? this.state.TMLeadProcessCountSummary[0].onayBekleyenSayisi : null)));

				formVars.leadlist_844329_value = ReactSystemFunctions.toString(this, (stateVars.TMLeadProcessCountSummary !== undefined ? (stateVars.TMLeadProcessCountSummary?.length > 0 ? stateVars.TMLeadProcessCountSummary[0].terminBekleyenSayisi : null) : (this.state.TMLeadProcessCountSummary?.length > 0 ? this.state.TMLeadProcessCountSummary[0].terminBekleyenSayisi : null)));

				formVars.leadlist_574886_value = ReactSystemFunctions.toString(this, (stateVars.TMLeadProcessCountSummary !== undefined ? (stateVars.TMLeadProcessCountSummary?.length > 0 ? stateVars.TMLeadProcessCountSummary[0].onaylananSayisi : null) : (this.state.TMLeadProcessCountSummary?.length > 0 ? this.state.TMLeadProcessCountSummary[0].onaylananSayisi : null)));

				formVars.leadlist_582775_value = ReactSystemFunctions.toString(this, (stateVars.TMLeadProcessCountSummary !== undefined ? (stateVars.TMLeadProcessCountSummary?.length > 0 ? stateVars.TMLeadProcessCountSummary[0].reddedilenSayisi : null) : (this.state.TMLeadProcessCountSummary?.length > 0 ? this.state.TMLeadProcessCountSummary[0].reddedilenSayisi : null)));

				formVars.leadlist_207750_value = ReactSystemFunctions.toString(this, (stateVars.TMLeadProcessCountSummary !== undefined ? (stateVars.TMLeadProcessCountSummary?.length > 0 ? stateVars.TMLeadProcessCountSummary[0].teslimEdilecekSayisi : null) : (this.state.TMLeadProcessCountSummary?.length > 0 ? this.state.TMLeadProcessCountSummary[0].teslimEdilecekSayisi : null)));

				formVars.leadlist_967794_value = ReactSystemFunctions.toString(this, (stateVars.TMLeadProcessCountSummary !== undefined ? (stateVars.TMLeadProcessCountSummary?.length > 0 ? stateVars.TMLeadProcessCountSummary[0].teslimEdildiSayisi : null) : (this.state.TMLeadProcessCountSummary?.length > 0 ? this.state.TMLeadProcessCountSummary[0].teslimEdildiSayisi : null)));

				
				stateVars.dataSource_414332 = stateVars.TM_GetLeads ?? this.state.TM_GetLeads;

		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

            
            return isErrorOccurred;
        }




    LeadListComponent_872239_onChange = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
		KuikaAppManager.increaseServerRequestCount();

        let localVar = {
				StepOrder_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, (stateVars.TM_GetLeads !== undefined ? (stateVars.TM_GetLeads?.length > 0 ? stateVars.TM_GetLeads[0].selectedStepOrder : null) : (this.state.TM_GetLeads?.length > 0 ? this.state.TM_GetLeads[0].selectedStepOrder : null))), "number"),
				UserId_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.getMyUserId(), "Guid"),
				MusteriAdi_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "leadlist_288211_value", "value", "", "", "")), "string"),
				ProductName_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "leadlist_576673_value", "value", "", "", "")), "string"),
				LeadCode_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "leadlist_60588_value", "value", "", "", "")), "string"),
				Tel_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "leadlist_776113_value", "value", "", "", "")), "string"),
				CategoryName_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "leadlist_836823_value", "value", "TM_GetProductCategory", "categoryName", "categoryName")), "string"),
				StoreIds_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "leadlist_314150_value", "value", "TM_GetStore", "storeCode", "id")), "string"),
				SatisDanismaniIds_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "leadlist_872239_value", "value", "TM_GetSalesPerson", "kUserId", "kUserId")), "string"),
				ProcessCode_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "leadlist_161661_value", "value", "TM_GetLeadProcess", "id", "code")), "string"),
				StartDate_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "leadlist_980795_value", "value", "", "", "")), "Date"),
				EndDate_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "leadlist_6623_value", "value", "", "", "")), "Date"),
				UserId_1: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.getMyUserId(), "Guid"),
				MusteriAdi_1: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "leadlist_288211_value", "value", "", "", "")), "string"),
				ProductName_1: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "leadlist_576673_value", "value", "", "", "")), "string"),
				LeadCode_1: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "leadlist_60588_value", "value", "", "", "")), "string"),
				Tel_1: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "leadlist_776113_value", "value", "", "", "")), "string"),
				CategoryName_1: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "leadlist_836823_value", "value", "TM_GetProductCategory", "categoryName", "categoryName")), "string"),
				StoreIds_1: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "leadlist_314150_value", "value", "TM_GetStore", "storeCode", "id")), "string"),
				SatisDanismaniIds_1: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "leadlist_872239_value", "value", "TM_GetSalesPerson", "kUserId", "kUserId")), "string"),
				ProcessCode_1: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "leadlist_161661_value", "value", "TM_GetLeadProcess", "id", "code")), "string"),
				StartDate_1: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "leadlist_980795_value", "value", "", "", "")), "Date"),
				EndDate_1: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "leadlist_6623_value", "value", "", "", "")), "Date")
        }

		KuikaAppManager.showSpinner(this);
		
        if (true) {
        KuikaAppManager.showSpinner(this);
        }
        let result = await KuikaAppManager.ApiRequest(this, "LeadList/LeadListComponent_872239_onChange", localVar)
        if (!KMainFunctions.IsResStatus2XX(result)) return true;

			stateVars.TM_GetLeads = result?.data.tM_GetLeads;
			
			stateVars.TMLeadProcessCountSummary = result?.data.tmLeadProcessCountSummary;
			formVars.leadlist_893473_value = ReactSystemFunctions.toString(this, (stateVars.TMLeadProcessCountSummary !== undefined ? (stateVars.TMLeadProcessCountSummary?.length > 0 ? stateVars.TMLeadProcessCountSummary[0].toplamTalepSayisi : null) : (this.state.TMLeadProcessCountSummary?.length > 0 ? this.state.TMLeadProcessCountSummary[0].toplamTalepSayisi : null)));
			formVars.leadlist_864952_value = ReactSystemFunctions.toString(this, (stateVars.TMLeadProcessCountSummary !== undefined ? (stateVars.TMLeadProcessCountSummary?.length > 0 ? stateVars.TMLeadProcessCountSummary[0].onayBekleyenSayisi : null) : (this.state.TMLeadProcessCountSummary?.length > 0 ? this.state.TMLeadProcessCountSummary[0].onayBekleyenSayisi : null)));
			formVars.leadlist_844329_value = ReactSystemFunctions.toString(this, (stateVars.TMLeadProcessCountSummary !== undefined ? (stateVars.TMLeadProcessCountSummary?.length > 0 ? stateVars.TMLeadProcessCountSummary[0].terminBekleyenSayisi : null) : (this.state.TMLeadProcessCountSummary?.length > 0 ? this.state.TMLeadProcessCountSummary[0].terminBekleyenSayisi : null)));
			formVars.leadlist_574886_value = ReactSystemFunctions.toString(this, (stateVars.TMLeadProcessCountSummary !== undefined ? (stateVars.TMLeadProcessCountSummary?.length > 0 ? stateVars.TMLeadProcessCountSummary[0].onaylananSayisi : null) : (this.state.TMLeadProcessCountSummary?.length > 0 ? this.state.TMLeadProcessCountSummary[0].onaylananSayisi : null)));
			formVars.leadlist_582775_value = ReactSystemFunctions.toString(this, (stateVars.TMLeadProcessCountSummary !== undefined ? (stateVars.TMLeadProcessCountSummary?.length > 0 ? stateVars.TMLeadProcessCountSummary[0].reddedilenSayisi : null) : (this.state.TMLeadProcessCountSummary?.length > 0 ? this.state.TMLeadProcessCountSummary[0].reddedilenSayisi : null)));
			formVars.leadlist_207750_value = ReactSystemFunctions.toString(this, (stateVars.TMLeadProcessCountSummary !== undefined ? (stateVars.TMLeadProcessCountSummary?.length > 0 ? stateVars.TMLeadProcessCountSummary[0].teslimEdilecekSayisi : null) : (this.state.TMLeadProcessCountSummary?.length > 0 ? this.state.TMLeadProcessCountSummary[0].teslimEdilecekSayisi : null)));
			formVars.leadlist_967794_value = ReactSystemFunctions.toString(this, (stateVars.TMLeadProcessCountSummary !== undefined ? (stateVars.TMLeadProcessCountSummary?.length > 0 ? stateVars.TMLeadProcessCountSummary[0].teslimEdildiSayisi : null) : (this.state.TMLeadProcessCountSummary?.length > 0 ? this.state.TMLeadProcessCountSummary[0].teslimEdildiSayisi : null)));
			this.props.form?.setFieldsValue(formVars);
			
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.LeadListComponent_872239_onChange1_();
                  resolve();
                });
          })



        
        KuikaAppManager.hideSpinner(this);
        return isErrorOccurred;
    }
		LeadListComponent_872239_onChange1_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }

				formVars.leadlist_893473_value = ReactSystemFunctions.toString(this, (stateVars.TMLeadProcessCountSummary !== undefined ? (stateVars.TMLeadProcessCountSummary?.length > 0 ? stateVars.TMLeadProcessCountSummary[0].toplamTalepSayisi : null) : (this.state.TMLeadProcessCountSummary?.length > 0 ? this.state.TMLeadProcessCountSummary[0].toplamTalepSayisi : null)));

				formVars.leadlist_864952_value = ReactSystemFunctions.toString(this, (stateVars.TMLeadProcessCountSummary !== undefined ? (stateVars.TMLeadProcessCountSummary?.length > 0 ? stateVars.TMLeadProcessCountSummary[0].onayBekleyenSayisi : null) : (this.state.TMLeadProcessCountSummary?.length > 0 ? this.state.TMLeadProcessCountSummary[0].onayBekleyenSayisi : null)));

				formVars.leadlist_844329_value = ReactSystemFunctions.toString(this, (stateVars.TMLeadProcessCountSummary !== undefined ? (stateVars.TMLeadProcessCountSummary?.length > 0 ? stateVars.TMLeadProcessCountSummary[0].terminBekleyenSayisi : null) : (this.state.TMLeadProcessCountSummary?.length > 0 ? this.state.TMLeadProcessCountSummary[0].terminBekleyenSayisi : null)));

				formVars.leadlist_574886_value = ReactSystemFunctions.toString(this, (stateVars.TMLeadProcessCountSummary !== undefined ? (stateVars.TMLeadProcessCountSummary?.length > 0 ? stateVars.TMLeadProcessCountSummary[0].onaylananSayisi : null) : (this.state.TMLeadProcessCountSummary?.length > 0 ? this.state.TMLeadProcessCountSummary[0].onaylananSayisi : null)));

				formVars.leadlist_582775_value = ReactSystemFunctions.toString(this, (stateVars.TMLeadProcessCountSummary !== undefined ? (stateVars.TMLeadProcessCountSummary?.length > 0 ? stateVars.TMLeadProcessCountSummary[0].reddedilenSayisi : null) : (this.state.TMLeadProcessCountSummary?.length > 0 ? this.state.TMLeadProcessCountSummary[0].reddedilenSayisi : null)));

				formVars.leadlist_207750_value = ReactSystemFunctions.toString(this, (stateVars.TMLeadProcessCountSummary !== undefined ? (stateVars.TMLeadProcessCountSummary?.length > 0 ? stateVars.TMLeadProcessCountSummary[0].teslimEdilecekSayisi : null) : (this.state.TMLeadProcessCountSummary?.length > 0 ? this.state.TMLeadProcessCountSummary[0].teslimEdilecekSayisi : null)));

				formVars.leadlist_967794_value = ReactSystemFunctions.toString(this, (stateVars.TMLeadProcessCountSummary !== undefined ? (stateVars.TMLeadProcessCountSummary?.length > 0 ? stateVars.TMLeadProcessCountSummary[0].teslimEdildiSayisi : null) : (this.state.TMLeadProcessCountSummary?.length > 0 ? this.state.TMLeadProcessCountSummary[0].teslimEdildiSayisi : null)));

				
				stateVars.dataSource_414332 = stateVars.TM_GetLeads ?? this.state.TM_GetLeads;

		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

            
            return isErrorOccurred;
        }




    LeadListComponent_161661_onChange = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
		KuikaAppManager.increaseServerRequestCount();

        let localVar = {
				StepOrder_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, (stateVars.TM_GetLeads !== undefined ? (stateVars.TM_GetLeads?.length > 0 ? stateVars.TM_GetLeads[0].selectedStepOrder : null) : (this.state.TM_GetLeads?.length > 0 ? this.state.TM_GetLeads[0].selectedStepOrder : null))), "number"),
				UserId_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.getMyUserId(), "Guid"),
				MusteriAdi_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "leadlist_288211_value", "value", "", "", "")), "string"),
				ProductName_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "leadlist_576673_value", "value", "", "", "")), "string"),
				LeadCode_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "leadlist_60588_value", "value", "", "", "")), "string"),
				Tel_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "leadlist_776113_value", "value", "", "", "")), "string"),
				CategoryName_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "leadlist_836823_value", "value", "TM_GetProductCategory", "categoryName", "categoryName")), "string"),
				StoreIds_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "leadlist_314150_value", "value", "TM_GetStore", "storeCode", "id")), "string"),
				SatisDanismaniIds_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "leadlist_872239_value", "value", "TM_GetSalesPerson", "kUserId", "kUserId")), "string"),
				ProcessCode_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "leadlist_161661_value", "value", "TM_GetLeadProcess", "id", "code")), "string"),
				StartDate_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "leadlist_980795_value", "value", "", "", "")), "Date"),
				EndDate_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "leadlist_6623_value", "value", "", "", "")), "Date"),
				UserId_1: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.getMyUserId(), "Guid"),
				MusteriAdi_1: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "leadlist_288211_value", "value", "", "", "")), "string"),
				ProductName_1: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "leadlist_576673_value", "value", "", "", "")), "string"),
				LeadCode_1: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "leadlist_60588_value", "value", "", "", "")), "string"),
				Tel_1: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "leadlist_776113_value", "value", "", "", "")), "string"),
				CategoryName_1: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "leadlist_836823_value", "value", "TM_GetProductCategory", "categoryName", "categoryName")), "string"),
				StoreIds_1: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "leadlist_314150_value", "value", "TM_GetStore", "storeCode", "id")), "string"),
				SatisDanismaniIds_1: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "leadlist_872239_value", "value", "TM_GetSalesPerson", "kUserId", "kUserId")), "string"),
				ProcessCode_1: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "leadlist_161661_value", "value", "TM_GetLeadProcess", "id", "code")), "string"),
				StartDate_1: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "leadlist_980795_value", "value", "", "", "")), "Date"),
				EndDate_1: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "leadlist_6623_value", "value", "", "", "")), "Date")
        }

		KuikaAppManager.showSpinner(this);
		
        if (true) {
        KuikaAppManager.showSpinner(this);
        }
        let result = await KuikaAppManager.ApiRequest(this, "LeadList/LeadListComponent_161661_onChange", localVar)
        if (!KMainFunctions.IsResStatus2XX(result)) return true;

			stateVars.TM_GetLeads = result?.data.tM_GetLeads;
			
			stateVars.TMLeadProcessCountSummary = result?.data.tmLeadProcessCountSummary;
			formVars.leadlist_893473_value = ReactSystemFunctions.toString(this, (stateVars.TMLeadProcessCountSummary !== undefined ? (stateVars.TMLeadProcessCountSummary?.length > 0 ? stateVars.TMLeadProcessCountSummary[0].toplamTalepSayisi : null) : (this.state.TMLeadProcessCountSummary?.length > 0 ? this.state.TMLeadProcessCountSummary[0].toplamTalepSayisi : null)));
			formVars.leadlist_864952_value = ReactSystemFunctions.toString(this, (stateVars.TMLeadProcessCountSummary !== undefined ? (stateVars.TMLeadProcessCountSummary?.length > 0 ? stateVars.TMLeadProcessCountSummary[0].onayBekleyenSayisi : null) : (this.state.TMLeadProcessCountSummary?.length > 0 ? this.state.TMLeadProcessCountSummary[0].onayBekleyenSayisi : null)));
			formVars.leadlist_844329_value = ReactSystemFunctions.toString(this, (stateVars.TMLeadProcessCountSummary !== undefined ? (stateVars.TMLeadProcessCountSummary?.length > 0 ? stateVars.TMLeadProcessCountSummary[0].terminBekleyenSayisi : null) : (this.state.TMLeadProcessCountSummary?.length > 0 ? this.state.TMLeadProcessCountSummary[0].terminBekleyenSayisi : null)));
			formVars.leadlist_574886_value = ReactSystemFunctions.toString(this, (stateVars.TMLeadProcessCountSummary !== undefined ? (stateVars.TMLeadProcessCountSummary?.length > 0 ? stateVars.TMLeadProcessCountSummary[0].onaylananSayisi : null) : (this.state.TMLeadProcessCountSummary?.length > 0 ? this.state.TMLeadProcessCountSummary[0].onaylananSayisi : null)));
			formVars.leadlist_582775_value = ReactSystemFunctions.toString(this, (stateVars.TMLeadProcessCountSummary !== undefined ? (stateVars.TMLeadProcessCountSummary?.length > 0 ? stateVars.TMLeadProcessCountSummary[0].reddedilenSayisi : null) : (this.state.TMLeadProcessCountSummary?.length > 0 ? this.state.TMLeadProcessCountSummary[0].reddedilenSayisi : null)));
			formVars.leadlist_207750_value = ReactSystemFunctions.toString(this, (stateVars.TMLeadProcessCountSummary !== undefined ? (stateVars.TMLeadProcessCountSummary?.length > 0 ? stateVars.TMLeadProcessCountSummary[0].teslimEdilecekSayisi : null) : (this.state.TMLeadProcessCountSummary?.length > 0 ? this.state.TMLeadProcessCountSummary[0].teslimEdilecekSayisi : null)));
			formVars.leadlist_967794_value = ReactSystemFunctions.toString(this, (stateVars.TMLeadProcessCountSummary !== undefined ? (stateVars.TMLeadProcessCountSummary?.length > 0 ? stateVars.TMLeadProcessCountSummary[0].teslimEdildiSayisi : null) : (this.state.TMLeadProcessCountSummary?.length > 0 ? this.state.TMLeadProcessCountSummary[0].teslimEdildiSayisi : null)));
			this.props.form?.setFieldsValue(formVars);
			
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.LeadListComponent_161661_onChange1_();
                  resolve();
                });
          })



        
        KuikaAppManager.hideSpinner(this);
        return isErrorOccurred;
    }
		LeadListComponent_161661_onChange1_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }

				formVars.leadlist_893473_value = ReactSystemFunctions.toString(this, (stateVars.TMLeadProcessCountSummary !== undefined ? (stateVars.TMLeadProcessCountSummary?.length > 0 ? stateVars.TMLeadProcessCountSummary[0].toplamTalepSayisi : null) : (this.state.TMLeadProcessCountSummary?.length > 0 ? this.state.TMLeadProcessCountSummary[0].toplamTalepSayisi : null)));

				formVars.leadlist_864952_value = ReactSystemFunctions.toString(this, (stateVars.TMLeadProcessCountSummary !== undefined ? (stateVars.TMLeadProcessCountSummary?.length > 0 ? stateVars.TMLeadProcessCountSummary[0].onayBekleyenSayisi : null) : (this.state.TMLeadProcessCountSummary?.length > 0 ? this.state.TMLeadProcessCountSummary[0].onayBekleyenSayisi : null)));

				formVars.leadlist_844329_value = ReactSystemFunctions.toString(this, (stateVars.TMLeadProcessCountSummary !== undefined ? (stateVars.TMLeadProcessCountSummary?.length > 0 ? stateVars.TMLeadProcessCountSummary[0].terminBekleyenSayisi : null) : (this.state.TMLeadProcessCountSummary?.length > 0 ? this.state.TMLeadProcessCountSummary[0].terminBekleyenSayisi : null)));

				formVars.leadlist_574886_value = ReactSystemFunctions.toString(this, (stateVars.TMLeadProcessCountSummary !== undefined ? (stateVars.TMLeadProcessCountSummary?.length > 0 ? stateVars.TMLeadProcessCountSummary[0].onaylananSayisi : null) : (this.state.TMLeadProcessCountSummary?.length > 0 ? this.state.TMLeadProcessCountSummary[0].onaylananSayisi : null)));

				formVars.leadlist_582775_value = ReactSystemFunctions.toString(this, (stateVars.TMLeadProcessCountSummary !== undefined ? (stateVars.TMLeadProcessCountSummary?.length > 0 ? stateVars.TMLeadProcessCountSummary[0].reddedilenSayisi : null) : (this.state.TMLeadProcessCountSummary?.length > 0 ? this.state.TMLeadProcessCountSummary[0].reddedilenSayisi : null)));

				formVars.leadlist_207750_value = ReactSystemFunctions.toString(this, (stateVars.TMLeadProcessCountSummary !== undefined ? (stateVars.TMLeadProcessCountSummary?.length > 0 ? stateVars.TMLeadProcessCountSummary[0].teslimEdilecekSayisi : null) : (this.state.TMLeadProcessCountSummary?.length > 0 ? this.state.TMLeadProcessCountSummary[0].teslimEdilecekSayisi : null)));

				formVars.leadlist_967794_value = ReactSystemFunctions.toString(this, (stateVars.TMLeadProcessCountSummary !== undefined ? (stateVars.TMLeadProcessCountSummary?.length > 0 ? stateVars.TMLeadProcessCountSummary[0].teslimEdildiSayisi : null) : (this.state.TMLeadProcessCountSummary?.length > 0 ? this.state.TMLeadProcessCountSummary[0].teslimEdildiSayisi : null)));

				
				stateVars.dataSource_414332 = stateVars.TM_GetLeads ?? this.state.TM_GetLeads;

		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

            
            return isErrorOccurred;
        }




    LeadListComponent_937502_onClick = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
		KuikaAppManager.increaseServerRequestCount();

        let localVar = {
				StepOrder_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, (stateVars.TM_GetLeads !== undefined ? (stateVars.TM_GetLeads?.length > 0 ? stateVars.TM_GetLeads[0].selectedStepOrder : null) : (this.state.TM_GetLeads?.length > 0 ? this.state.TM_GetLeads[0].selectedStepOrder : null))), "number"),
				UserId_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.getMyUserId(), "Guid"),
				MusteriAdi_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "leadlist_288211_value", "value", "", "", "")), "string"),
				ProductName_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "leadlist_576673_value", "value", "", "", "")), "string"),
				LeadCode_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "leadlist_60588_value", "value", "", "", "")), "string"),
				Tel_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "leadlist_776113_value", "value", "", "", "")), "string"),
				CategoryName_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "leadlist_836823_value", "value", "TM_GetProductCategory", "categoryName", "categoryName")), "string"),
				StoreIds_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "leadlist_314150_value", "value", "TM_GetStore", "storeCode", "id")), "string"),
				SatisDanismaniIds_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "leadlist_872239_value", "value", "TM_GetSalesPerson", "kUserId", "kUserId")), "string"),
				ProcessCode_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "leadlist_161661_value", "value", "TM_GetLeadProcess", "id", "code")), "string"),
				StartDate_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "leadlist_980795_value", "value", "", "", "")), "Date"),
				EndDate_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "leadlist_6623_value", "value", "", "", "")), "Date"),
				UserId_1: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.getMyUserId(), "Guid"),
				MusteriAdi_1: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "leadlist_288211_value", "value", "", "", "")), "string"),
				ProductName_1: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "leadlist_576673_value", "value", "", "", "")), "string"),
				LeadCode_1: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "leadlist_60588_value", "value", "", "", "")), "string"),
				Tel_1: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "leadlist_776113_value", "value", "", "", "")), "string"),
				CategoryName_1: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "leadlist_836823_value", "value", "TM_GetProductCategory", "categoryName", "categoryName")), "string"),
				StoreIds_1: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "leadlist_314150_value", "value", "TM_GetStore", "storeCode", "id")), "string"),
				SatisDanismaniIds_1: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "leadlist_872239_value", "value", "TM_GetSalesPerson", "kUserId", "kUserId")), "string"),
				ProcessCode_1: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "leadlist_161661_value", "value", "TM_GetLeadProcess", "id", "code")), "string"),
				StartDate_1: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "leadlist_980795_value", "value", "", "", "")), "Date"),
				EndDate_1: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "leadlist_6623_value", "value", "", "", "")), "Date")
        }

		KuikaAppManager.showSpinner(this);
		
        if (true) {
        KuikaAppManager.showSpinner(this);
        }
        let result = await KuikaAppManager.ApiRequest(this, "LeadList/LeadListComponent_937502_onClick", localVar)
        if (!KMainFunctions.IsResStatus2XX(result)) return true;

			stateVars.TM_GetLeads = result?.data.tM_GetLeads;
			
			stateVars.TMLeadProcessCountSummary = result?.data.tmLeadProcessCountSummary;
			formVars.leadlist_893473_value = ReactSystemFunctions.toString(this, (stateVars.TMLeadProcessCountSummary !== undefined ? (stateVars.TMLeadProcessCountSummary?.length > 0 ? stateVars.TMLeadProcessCountSummary[0].toplamTalepSayisi : null) : (this.state.TMLeadProcessCountSummary?.length > 0 ? this.state.TMLeadProcessCountSummary[0].toplamTalepSayisi : null)));
			formVars.leadlist_864952_value = ReactSystemFunctions.toString(this, (stateVars.TMLeadProcessCountSummary !== undefined ? (stateVars.TMLeadProcessCountSummary?.length > 0 ? stateVars.TMLeadProcessCountSummary[0].onayBekleyenSayisi : null) : (this.state.TMLeadProcessCountSummary?.length > 0 ? this.state.TMLeadProcessCountSummary[0].onayBekleyenSayisi : null)));
			formVars.leadlist_844329_value = ReactSystemFunctions.toString(this, (stateVars.TMLeadProcessCountSummary !== undefined ? (stateVars.TMLeadProcessCountSummary?.length > 0 ? stateVars.TMLeadProcessCountSummary[0].terminBekleyenSayisi : null) : (this.state.TMLeadProcessCountSummary?.length > 0 ? this.state.TMLeadProcessCountSummary[0].terminBekleyenSayisi : null)));
			formVars.leadlist_574886_value = ReactSystemFunctions.toString(this, (stateVars.TMLeadProcessCountSummary !== undefined ? (stateVars.TMLeadProcessCountSummary?.length > 0 ? stateVars.TMLeadProcessCountSummary[0].onaylananSayisi : null) : (this.state.TMLeadProcessCountSummary?.length > 0 ? this.state.TMLeadProcessCountSummary[0].onaylananSayisi : null)));
			formVars.leadlist_582775_value = ReactSystemFunctions.toString(this, (stateVars.TMLeadProcessCountSummary !== undefined ? (stateVars.TMLeadProcessCountSummary?.length > 0 ? stateVars.TMLeadProcessCountSummary[0].reddedilenSayisi : null) : (this.state.TMLeadProcessCountSummary?.length > 0 ? this.state.TMLeadProcessCountSummary[0].reddedilenSayisi : null)));
			formVars.leadlist_207750_value = ReactSystemFunctions.toString(this, (stateVars.TMLeadProcessCountSummary !== undefined ? (stateVars.TMLeadProcessCountSummary?.length > 0 ? stateVars.TMLeadProcessCountSummary[0].teslimEdilecekSayisi : null) : (this.state.TMLeadProcessCountSummary?.length > 0 ? this.state.TMLeadProcessCountSummary[0].teslimEdilecekSayisi : null)));
			formVars.leadlist_967794_value = ReactSystemFunctions.toString(this, (stateVars.TMLeadProcessCountSummary !== undefined ? (stateVars.TMLeadProcessCountSummary?.length > 0 ? stateVars.TMLeadProcessCountSummary[0].teslimEdildiSayisi : null) : (this.state.TMLeadProcessCountSummary?.length > 0 ? this.state.TMLeadProcessCountSummary[0].teslimEdildiSayisi : null)));
			this.props.form?.setFieldsValue(formVars);
			
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.LeadListComponent_937502_onClick1_();
                  resolve();
                });
          })



        
        KuikaAppManager.hideSpinner(this);
        return isErrorOccurred;
    }
		LeadListComponent_937502_onClick1_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }

				formVars.leadlist_893473_value = ReactSystemFunctions.toString(this, (stateVars.TMLeadProcessCountSummary !== undefined ? (stateVars.TMLeadProcessCountSummary?.length > 0 ? stateVars.TMLeadProcessCountSummary[0].toplamTalepSayisi : null) : (this.state.TMLeadProcessCountSummary?.length > 0 ? this.state.TMLeadProcessCountSummary[0].toplamTalepSayisi : null)));

				formVars.leadlist_864952_value = ReactSystemFunctions.toString(this, (stateVars.TMLeadProcessCountSummary !== undefined ? (stateVars.TMLeadProcessCountSummary?.length > 0 ? stateVars.TMLeadProcessCountSummary[0].onayBekleyenSayisi : null) : (this.state.TMLeadProcessCountSummary?.length > 0 ? this.state.TMLeadProcessCountSummary[0].onayBekleyenSayisi : null)));

				formVars.leadlist_844329_value = ReactSystemFunctions.toString(this, (stateVars.TMLeadProcessCountSummary !== undefined ? (stateVars.TMLeadProcessCountSummary?.length > 0 ? stateVars.TMLeadProcessCountSummary[0].terminBekleyenSayisi : null) : (this.state.TMLeadProcessCountSummary?.length > 0 ? this.state.TMLeadProcessCountSummary[0].terminBekleyenSayisi : null)));

				formVars.leadlist_574886_value = ReactSystemFunctions.toString(this, (stateVars.TMLeadProcessCountSummary !== undefined ? (stateVars.TMLeadProcessCountSummary?.length > 0 ? stateVars.TMLeadProcessCountSummary[0].onaylananSayisi : null) : (this.state.TMLeadProcessCountSummary?.length > 0 ? this.state.TMLeadProcessCountSummary[0].onaylananSayisi : null)));

				formVars.leadlist_582775_value = ReactSystemFunctions.toString(this, (stateVars.TMLeadProcessCountSummary !== undefined ? (stateVars.TMLeadProcessCountSummary?.length > 0 ? stateVars.TMLeadProcessCountSummary[0].reddedilenSayisi : null) : (this.state.TMLeadProcessCountSummary?.length > 0 ? this.state.TMLeadProcessCountSummary[0].reddedilenSayisi : null)));

				formVars.leadlist_207750_value = ReactSystemFunctions.toString(this, (stateVars.TMLeadProcessCountSummary !== undefined ? (stateVars.TMLeadProcessCountSummary?.length > 0 ? stateVars.TMLeadProcessCountSummary[0].teslimEdilecekSayisi : null) : (this.state.TMLeadProcessCountSummary?.length > 0 ? this.state.TMLeadProcessCountSummary[0].teslimEdilecekSayisi : null)));

				formVars.leadlist_967794_value = ReactSystemFunctions.toString(this, (stateVars.TMLeadProcessCountSummary !== undefined ? (stateVars.TMLeadProcessCountSummary?.length > 0 ? stateVars.TMLeadProcessCountSummary[0].teslimEdildiSayisi : null) : (this.state.TMLeadProcessCountSummary?.length > 0 ? this.state.TMLeadProcessCountSummary[0].teslimEdildiSayisi : null)));

				
				stateVars.dataSource_414332 = stateVars.TM_GetLeads ?? this.state.TM_GetLeads;

		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

            
            return isErrorOccurred;
        }




		LeadListComponent_873248_onClick = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
KuikaAppManager.showSpinner(this);

				stateVars.SetValueOf = await ReactSystemFunctions.setValueOf(this, ReactSystemFunctions.convertToTypeByName("leadlist_288211_value", "string"), "", null, false);
				stateVars.SetValueOf = await ReactSystemFunctions.setValueOf(this, ReactSystemFunctions.convertToTypeByName("leadlist_776113_value", "string"), "", null, false);
				stateVars.SetValueOf = await ReactSystemFunctions.setValueOf(this, ReactSystemFunctions.convertToTypeByName("leadlist_576673_value", "string"), "", null, false);
				stateVars.SetValueOf = await ReactSystemFunctions.setValueOf(this, ReactSystemFunctions.convertToTypeByName("leadlist_836823_value", "string"), "", null, false);
				stateVars.SetValueOf = await ReactSystemFunctions.setValueOf(this, ReactSystemFunctions.convertToTypeByName("leadlist_314150_value", "string"), "", null, false);
				stateVars.SetValueOf = await ReactSystemFunctions.setValueOf(this, ReactSystemFunctions.convertToTypeByName("leadlist_872239_value", "string"), "", null, false);
				stateVars.SetValueOf = await ReactSystemFunctions.setValueOf(this, ReactSystemFunctions.convertToTypeByName("leadlist_161661_value", "string"), "", null, false);
				stateVars.SetValueOf = await ReactSystemFunctions.setValueOf(this, ReactSystemFunctions.convertToTypeByName("leadlist_980795_value", "string"), "", null, false);
				stateVars.SetValueOf = await ReactSystemFunctions.setValueOf(this, ReactSystemFunctions.convertToTypeByName("leadlist_6623_value", "string"), "", null, false);

		this.props.form?.setFieldsValue(formVars);
		
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.LeadListComponent_873248_onClick1_();
                  resolve();
                });
          })

            
            return isErrorOccurred;
        }
    LeadListComponent_873248_onClick1_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
		KuikaAppManager.increaseServerRequestCount();

        let localVar = {
				StepOrder_0: ReactSystemFunctions.convertToTypeByName(null, "number"),
				UserId_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.getMyUserId(), "Guid"),
				MusteriAdi_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "leadlist_288211_value", "value", "", "", "")), "string"),
				ProductName_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "leadlist_576673_value", "value", "", "", "")), "string"),
				LeadCode_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "leadlist_60588_value", "value", "", "", "")), "string"),
				Tel_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "leadlist_776113_value", "value", "", "", "")), "string"),
				CategoryName_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "leadlist_836823_value", "value", "TM_GetProductCategory", "categoryName", "categoryName")), "string"),
				StoreIds_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "leadlist_314150_value", "value", "TM_GetStore", "storeCode", "id")), "string"),
				SatisDanismaniIds_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "leadlist_872239_value", "value", "TM_GetSalesPerson", "kUserId", "kUserId")), "string"),
				ProcessCode_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "leadlist_161661_value", "value", "TM_GetLeadProcess", "id", "code")), "string"),
				StartDate_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "leadlist_980795_value", "value", "", "", "")), "Date"),
				EndDate_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "leadlist_6623_value", "value", "", "", "")), "Date"),
				UserId_1: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.getMyUserId(), "Guid"),
				MusteriAdi_1: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "leadlist_288211_value", "value", "", "", "")), "string"),
				ProductName_1: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "leadlist_576673_value", "value", "", "", "")), "string"),
				LeadCode_1: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "leadlist_60588_value", "value", "", "", "")), "string"),
				Tel_1: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "leadlist_776113_value", "value", "", "", "")), "string"),
				CategoryName_1: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "leadlist_836823_value", "value", "TM_GetProductCategory", "categoryName", "categoryName")), "string"),
				StoreIds_1: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "leadlist_314150_value", "value", "TM_GetStore", "storeCode", "id")), "string"),
				SatisDanismaniIds_1: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "leadlist_872239_value", "value", "TM_GetSalesPerson", "kUserId", "kUserId")), "string"),
				ProcessCode_1: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "leadlist_161661_value", "value", "TM_GetLeadProcess", "id", "code")), "string"),
				StartDate_1: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "leadlist_980795_value", "value", "", "", "")), "Date"),
				EndDate_1: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "leadlist_6623_value", "value", "", "", "")), "Date")
        }

		
        if (true) {
        KuikaAppManager.showSpinner(this);
        }
        let result = await KuikaAppManager.ApiRequest(this, "LeadList/LeadListComponent_873248_onClick1_", localVar)
        if (!KMainFunctions.IsResStatus2XX(result)) return true;

			stateVars.TM_GetLeads = result?.data.tM_GetLeads;
			
			stateVars.TMLeadProcessCountSummary = result?.data.tmLeadProcessCountSummary;
			formVars.leadlist_893473_value = ReactSystemFunctions.toString(this, (stateVars.TMLeadProcessCountSummary !== undefined ? (stateVars.TMLeadProcessCountSummary?.length > 0 ? stateVars.TMLeadProcessCountSummary[0].toplamTalepSayisi : null) : (this.state.TMLeadProcessCountSummary?.length > 0 ? this.state.TMLeadProcessCountSummary[0].toplamTalepSayisi : null)));
			formVars.leadlist_864952_value = ReactSystemFunctions.toString(this, (stateVars.TMLeadProcessCountSummary !== undefined ? (stateVars.TMLeadProcessCountSummary?.length > 0 ? stateVars.TMLeadProcessCountSummary[0].onayBekleyenSayisi : null) : (this.state.TMLeadProcessCountSummary?.length > 0 ? this.state.TMLeadProcessCountSummary[0].onayBekleyenSayisi : null)));
			formVars.leadlist_844329_value = ReactSystemFunctions.toString(this, (stateVars.TMLeadProcessCountSummary !== undefined ? (stateVars.TMLeadProcessCountSummary?.length > 0 ? stateVars.TMLeadProcessCountSummary[0].terminBekleyenSayisi : null) : (this.state.TMLeadProcessCountSummary?.length > 0 ? this.state.TMLeadProcessCountSummary[0].terminBekleyenSayisi : null)));
			formVars.leadlist_574886_value = ReactSystemFunctions.toString(this, (stateVars.TMLeadProcessCountSummary !== undefined ? (stateVars.TMLeadProcessCountSummary?.length > 0 ? stateVars.TMLeadProcessCountSummary[0].onaylananSayisi : null) : (this.state.TMLeadProcessCountSummary?.length > 0 ? this.state.TMLeadProcessCountSummary[0].onaylananSayisi : null)));
			formVars.leadlist_582775_value = ReactSystemFunctions.toString(this, (stateVars.TMLeadProcessCountSummary !== undefined ? (stateVars.TMLeadProcessCountSummary?.length > 0 ? stateVars.TMLeadProcessCountSummary[0].reddedilenSayisi : null) : (this.state.TMLeadProcessCountSummary?.length > 0 ? this.state.TMLeadProcessCountSummary[0].reddedilenSayisi : null)));
			formVars.leadlist_207750_value = ReactSystemFunctions.toString(this, (stateVars.TMLeadProcessCountSummary !== undefined ? (stateVars.TMLeadProcessCountSummary?.length > 0 ? stateVars.TMLeadProcessCountSummary[0].teslimEdilecekSayisi : null) : (this.state.TMLeadProcessCountSummary?.length > 0 ? this.state.TMLeadProcessCountSummary[0].teslimEdilecekSayisi : null)));
			formVars.leadlist_967794_value = ReactSystemFunctions.toString(this, (stateVars.TMLeadProcessCountSummary !== undefined ? (stateVars.TMLeadProcessCountSummary?.length > 0 ? stateVars.TMLeadProcessCountSummary[0].teslimEdildiSayisi : null) : (this.state.TMLeadProcessCountSummary?.length > 0 ? this.state.TMLeadProcessCountSummary[0].teslimEdildiSayisi : null)));
			this.props.form?.setFieldsValue(formVars);
			
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.LeadListComponent_873248_onClick2_();
                  resolve();
                });
          })



        
        KuikaAppManager.hideSpinner(this);
        return isErrorOccurred;
    }
		LeadListComponent_873248_onClick2_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }

				formVars.leadlist_893473_value = ReactSystemFunctions.toString(this, (stateVars.TMLeadProcessCountSummary !== undefined ? (stateVars.TMLeadProcessCountSummary?.length > 0 ? stateVars.TMLeadProcessCountSummary[0].toplamTalepSayisi : null) : (this.state.TMLeadProcessCountSummary?.length > 0 ? this.state.TMLeadProcessCountSummary[0].toplamTalepSayisi : null)));

				formVars.leadlist_864952_value = ReactSystemFunctions.toString(this, (stateVars.TMLeadProcessCountSummary !== undefined ? (stateVars.TMLeadProcessCountSummary?.length > 0 ? stateVars.TMLeadProcessCountSummary[0].onayBekleyenSayisi : null) : (this.state.TMLeadProcessCountSummary?.length > 0 ? this.state.TMLeadProcessCountSummary[0].onayBekleyenSayisi : null)));

				formVars.leadlist_844329_value = ReactSystemFunctions.toString(this, (stateVars.TMLeadProcessCountSummary !== undefined ? (stateVars.TMLeadProcessCountSummary?.length > 0 ? stateVars.TMLeadProcessCountSummary[0].terminBekleyenSayisi : null) : (this.state.TMLeadProcessCountSummary?.length > 0 ? this.state.TMLeadProcessCountSummary[0].terminBekleyenSayisi : null)));

				formVars.leadlist_574886_value = ReactSystemFunctions.toString(this, (stateVars.TMLeadProcessCountSummary !== undefined ? (stateVars.TMLeadProcessCountSummary?.length > 0 ? stateVars.TMLeadProcessCountSummary[0].onaylananSayisi : null) : (this.state.TMLeadProcessCountSummary?.length > 0 ? this.state.TMLeadProcessCountSummary[0].onaylananSayisi : null)));

				formVars.leadlist_582775_value = ReactSystemFunctions.toString(this, (stateVars.TMLeadProcessCountSummary !== undefined ? (stateVars.TMLeadProcessCountSummary?.length > 0 ? stateVars.TMLeadProcessCountSummary[0].reddedilenSayisi : null) : (this.state.TMLeadProcessCountSummary?.length > 0 ? this.state.TMLeadProcessCountSummary[0].reddedilenSayisi : null)));

				formVars.leadlist_207750_value = ReactSystemFunctions.toString(this, (stateVars.TMLeadProcessCountSummary !== undefined ? (stateVars.TMLeadProcessCountSummary?.length > 0 ? stateVars.TMLeadProcessCountSummary[0].teslimEdilecekSayisi : null) : (this.state.TMLeadProcessCountSummary?.length > 0 ? this.state.TMLeadProcessCountSummary[0].teslimEdilecekSayisi : null)));

				formVars.leadlist_967794_value = ReactSystemFunctions.toString(this, (stateVars.TMLeadProcessCountSummary !== undefined ? (stateVars.TMLeadProcessCountSummary?.length > 0 ? stateVars.TMLeadProcessCountSummary[0].teslimEdildiSayisi : null) : (this.state.TMLeadProcessCountSummary?.length > 0 ? this.state.TMLeadProcessCountSummary[0].teslimEdildiSayisi : null)));

				
				stateVars.dataSource_414332 = stateVars.TM_GetLeads ?? this.state.TM_GetLeads;

		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

            
            return isErrorOccurred;
        }





    LeadListComponent_60588_onChange = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
		KuikaAppManager.increaseServerRequestCount();

        let localVar = {
				StepOrder_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, (stateVars.TM_GetLeads !== undefined ? (stateVars.TM_GetLeads?.length > 0 ? stateVars.TM_GetLeads[0].selectedStepOrder : null) : (this.state.TM_GetLeads?.length > 0 ? this.state.TM_GetLeads[0].selectedStepOrder : null))), "number"),
				UserId_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.getMyUserId(), "Guid"),
				MusteriAdi_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "leadlist_288211_value", "value", "", "", "")), "string"),
				ProductName_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "leadlist_576673_value", "value", "", "", "")), "string"),
				LeadCode_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "leadlist_60588_value", "value", "", "", "")), "string"),
				Tel_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "leadlist_776113_value", "value", "", "", "")), "string"),
				CategoryName_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "leadlist_836823_value", "value", "TM_GetProductCategory", "categoryName", "categoryName")), "string"),
				StoreIds_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "leadlist_314150_value", "value", "TM_GetStore", "storeCode", "id")), "string"),
				SatisDanismaniIds_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "leadlist_872239_value", "value", "TM_GetSalesPerson", "kUserId", "kUserId")), "string"),
				ProcessCode_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "leadlist_161661_value", "value", "TM_GetLeadProcess", "id", "code")), "string"),
				StartDate_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "leadlist_980795_value", "value", "", "", "")), "Date"),
				EndDate_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "leadlist_6623_value", "value", "", "", "")), "Date")
        }

		KuikaAppManager.showSpinner(this);
		
        if (true) {
        KuikaAppManager.showSpinner(this);
        }
        let result = await KuikaAppManager.ApiRequest(this, "LeadList/LeadListComponent_60588_onChange", localVar)
        if (!KMainFunctions.IsResStatus2XX(result)) return true;

			stateVars.TM_GetLeads = result?.data.tM_GetLeads;
			
			this.props.form?.setFieldsValue(formVars);
			
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.LeadListComponent_60588_onChange1_();
                  resolve();
                });
          })



        
        KuikaAppManager.hideSpinner(this);
        return isErrorOccurred;
    }
		LeadListComponent_60588_onChange1_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }

				
				stateVars.dataSource_414332 = stateVars.TM_GetLeads ?? this.state.TM_GetLeads;

		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

            
            return isErrorOccurred;
        }




		LeadListComponent_17950_onClick = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
KuikaAppManager.showSpinner(this);

				stateVars.SetValueOf = await ReactSystemFunctions.setValueOf(this, ReactSystemFunctions.convertToTypeByName("leadlist_60588_value", "string"), "", null, false);

		this.props.form?.setFieldsValue(formVars);
		
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.LeadListComponent_17950_onClick1_();
                  resolve();
                });
          })

            
            return isErrorOccurred;
        }
    LeadListComponent_17950_onClick1_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
		KuikaAppManager.increaseServerRequestCount();

        let localVar = {
				StepOrder_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, (stateVars.TM_GetLeads !== undefined ? (stateVars.TM_GetLeads?.length > 0 ? stateVars.TM_GetLeads[0].selectedStepOrder : null) : (this.state.TM_GetLeads?.length > 0 ? this.state.TM_GetLeads[0].selectedStepOrder : null))), "number"),
				UserId_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.getMyUserId(), "Guid"),
				MusteriAdi_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "leadlist_288211_value", "value", "", "", "")), "string"),
				ProductName_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "leadlist_576673_value", "value", "", "", "")), "string"),
				LeadCode_0: ReactSystemFunctions.convertToTypeByName("", "string"),
				Tel_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "leadlist_776113_value", "value", "", "", "")), "string"),
				CategoryName_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "leadlist_836823_value", "value", "TM_GetProductCategory", "categoryName", "categoryName")), "string"),
				StoreIds_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "leadlist_314150_value", "value", "TM_GetStore", "storeCode", "id")), "string"),
				SatisDanismaniIds_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "leadlist_872239_value", "value", "TM_GetSalesPerson", "kUserId", "kUserId")), "string"),
				ProcessCode_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "leadlist_161661_value", "value", "TM_GetLeadProcess", "id", "code")), "string"),
				StartDate_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "leadlist_980795_value", "value", "", "", "")), "Date"),
				EndDate_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "leadlist_6623_value", "value", "", "", "")), "Date")
        }

		
        if (true) {
        KuikaAppManager.showSpinner(this);
        }
        let result = await KuikaAppManager.ApiRequest(this, "LeadList/LeadListComponent_17950_onClick1_", localVar)
        if (!KMainFunctions.IsResStatus2XX(result)) return true;

			stateVars.TM_GetLeads = result?.data.tM_GetLeads;
			
			this.props.form?.setFieldsValue(formVars);
			
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.LeadListComponent_17950_onClick2_();
                  resolve();
                });
          })



        
        KuikaAppManager.hideSpinner(this);
        return isErrorOccurred;
    }
		LeadListComponent_17950_onClick2_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }

				
				stateVars.dataSource_414332 = stateVars.TM_GetLeads ?? this.state.TM_GetLeads;

		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

            
            return isErrorOccurred;
        }





    LeadListComponent_378811_onClick = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
		KuikaAppManager.increaseServerRequestCount();

        let localVar = {
				value_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, this.state.TM_GetLeads), "any"),
				header_0: ReactSystemFunctions.convertToTypeByName("", "string"),
				footer_0: ReactSystemFunctions.convertToTypeByName("", "string"),
				columns_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.convertToTypeByName("TalepTarihi,Referans,Kadran,Bilezik,Musteri,MusteriInfo,Lokasyon,IletisimKaynagi,LeadDurumu,SonrakiAdim,IrtibatNumarasi,EmailAdresi,ProcessName,SatisDanismani,AlisverisiVarMi,TerminTarihi", "string"), "string")
        }

		KuikaAppManager.showSpinner(this);
		
        if (true) {
        KuikaAppManager.showSpinner(this);
        }
        let result = await KuikaAppManager.ApiRequest(this, "LeadList/LeadListComponent_378811_onClick", localVar)
        if (!KMainFunctions.IsResStatus2XX(result)) return true;

			stateVars.ExportExcel = result?.data.exportExcel;
			ReactSystemFunctions.downloadFile(result?.data?.exportExcel);
			this.props.form?.setFieldsValue(formVars);
			this.setState(stateVars);
			KuikaAppManager.hideSpinner(this);



        this.setPageInitLoaded(true);
        KuikaAppManager.hideSpinner(this);
        return isErrorOccurred;
    }



		LeadListComponent_749466_onClick = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
KuikaAppManager.showSpinner(this);

					KuikaAppManager.prepareForNavigation();
						KuikaAppManager.addToPageInputVariables("LeadDetail", "LeadId", ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, "leadlist_414332_value", "leadId"), "Guid"));

				stateVars.NAVIGATE = await ReactSystemFunctions.navigate(this, undefined, "LeadList", "LeadDetail", "", "7d969ddf-5801-4eb6-b92b-12be35bdd565", "561598", null, "right", "true", "70vw", "98vh", true, false);

		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

            
            return isErrorOccurred;
        }




    async callCallbackFunction(diId: number, isFromMaster: boolean = false) {
        let isErrorOccurred = false;
		let pageInitCallerNavDiIDs = [561598] as number[];
		if (isFromMaster || pageInitCallerNavDiIDs.indexOf(diId) > -1) {
			await this.LeadListPageInit();
		}

    }


}
