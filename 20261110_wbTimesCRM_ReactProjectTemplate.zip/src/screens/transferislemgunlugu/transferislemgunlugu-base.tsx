import React from "react";
import Axios, { AxiosResponse } from "axios";
import { KuikaAppManager } from "../../shared/utilty/kuika-app-manager";
import { ReactSystemFunctions } from "../../shared/utilty/react-system-functions";
import { KNavigator } from "../../shared/hoc/with-history";
import { KContext } from "../../shared/hoc/with-context";
import { useLocation } from "react-router-dom";
import { FormInstance } from "antd/es/form";
import { Guid } from "guid-typescript";
import Swal from "sweetalert2";
import { KMainFunctions } from "../../shared/utilty/main-functions";
import moment from "moment";
import { IValidationData } from "../../models/dto/validation-data";
import { IStripePayment } from "../../models/dto/stripe-payment";
import { IUserInfoDto } from "../../models/dto/user-info.dto";
import { UserService } from "../../services/user-service";
import { kuikaCoreWasmBridgeService } from "../../services/_singletons";
import _ from "lodash";
import mqtt, { MqttClient } from "mqtt";
import { IMqttResult } from "../../models/dto/mqtt.dto";


declare let window: any;

export interface ITransferIslemGunlugu_ScreenProps {
  navigator: KNavigator;
  form: FormInstance<any>;
  googleLogin: any;
  screenInputs: any;
  context: KContext;
  initialValues: any;
  children: any;
}

export interface ITransferIslemGunlugu_ScreenState {
    isSpinnerVisible: boolean;
    isPageVisible: boolean;
	isLeftMenuVisible: boolean;
    spinnerCount: number;
    selectedLanguage: string;
    isPageInitLoaded: false;
    isPageRecurringLoaded: false;

}

export class TransferIslemGunlugu_ScreenBase extends React.PureComponent<ITransferIslemGunlugu_ScreenProps, any> {

	transferislemgunlugu_890376_value_kuikaAutoCompleteRef: React.RefObject<any>;
	transferislemgunlugu_618603_value_kuikaAutoCompleteRef: React.RefObject<any>;
	transferislemgunlugu_479528_value_kuikaAutoCompleteRef: React.RefObject<any>;
	transferislemgunlugu_469664_value_kuikaAutoCompleteRef: React.RefObject<any>;
	transferislemgunlugu_453072_value_kuikaAutoCompleteRef: React.RefObject<any>;
	transferislemgunlugu_424955_value_kuikaTableRef: React.RefObject<any>;
    ml=[{"Id":"d5a61d2b-bd60-485f-86e2-661e9ed4e486","Name":"en_US","ShortName":"English","IsDefault":true,"LanguagePhrases":[]},{"Id":"1e4a617e-dfb8-4dcf-adda-1904992054b9","Name":"FixedValues","ShortName":"FixedValues","LanguagePhrases":[{"Id":314950,"PropertyName":"value","Value":"Transfer İşlem Günlüğü"},{"Id":585825,"PropertyName":"value","Value":"Transfer süreçlerindeki değişiklikleri ve sistem olaylarını inceleyin."},{"Id":889453,"PropertyName":"label","Value":"Excel'e Aktar"},{"Id":937281,"PropertyName":"value","Value":"Filtrele"},{"Id":169487,"PropertyName":"value","Value":"Talep/Fiş No"},{"Id":334149,"PropertyName":"placeholder","Value":"Talep veya fiş no"},{"Id":154478,"PropertyName":"value","Value":"Kayıt Türü"},{"Id":890376,"PropertyName":"placeholder","Value":"Tümü"},{"Id":315821,"PropertyName":"value","Value":"Olay Türü"},{"Id":618603,"PropertyName":"placeholder","Value":"Tümü"},{"Id":71091,"PropertyName":"value","Value":"Gönderen Mağaza"},{"Id":479528,"PropertyName":"placeholder","Value":"Mağaza seçin"},{"Id":572605,"PropertyName":"value","Value":"Alıcı Mağaza"},{"Id":469664,"PropertyName":"placeholder","Value":"Mağaza seçin"},{"Id":798135,"PropertyName":"value","Value":"İşlemi Yapan Kullanıcı"},{"Id":453072,"PropertyName":"placeholder","Value":"Kullanıcı seçin"},{"Id":709180,"PropertyName":"value","Value":"Tarih Aralığı"},{"Id":365119,"PropertyName":"startDatePlaceholder","Value":"Başlangıç"},{"Id":365119,"PropertyName":"endDatePlaceholder","Value":"Bitiş"},{"Id":627492,"PropertyName":"value","Value":"Son 7 Gün"},{"Id":454779,"PropertyName":"value","Value":"Yalnız Hatalar"},{"Id":304934,"PropertyName":"label","Value":"Ara"},{"Id":34721,"PropertyName":"label","Value":"Temizle"},{"Id":131924,"PropertyName":"value","Value":"Kronolojik İşlem Kayıtları"},{"Id":832969,"PropertyName":"title","Value":"Title"},{"Id":342035,"PropertyName":"value","Value":"18.06.2024 09:12"},{"Id":650625,"PropertyName":"title","Value":"Title"},{"Id":720648,"PropertyName":"value","Value":"Talep"},{"Id":656325,"PropertyName":"title","Value":"Title"},{"Id":506262,"PropertyName":"value","Value":"TR-2024-01842"},{"Id":621456,"PropertyName":"title","Value":"Title"},{"Id":361953,"PropertyName":"value","Value":"Transfer oluşturuldu"},{"Id":601175,"PropertyName":"title","Value":"Title"},{"Id":128718,"PropertyName":"value","Value":"Merkez Depo"},{"Id":1414,"PropertyName":"title","Value":"Title"},{"Id":547575,"PropertyName":"value","Value":"Kadıköy Mağaza"},{"Id":672446,"PropertyName":"title","Value":"Title"},{"Id":35927,"PropertyName":"value","Value":"Ayşe Demir"},{"Id":800365,"PropertyName":"title","Value":"Title"},{"Id":732298,"PropertyName":"value","Value":"Yeni transfer talebi kaydedildi."},{"Id":743308,"PropertyName":"title","Value":"Title"},{"Id":141055,"PropertyName":"title","Value":"Title"},{"Id":855534,"PropertyName":"label","Value":"Detay"},{"Id":138359,"PropertyName":"value","Value":"248 kayıttan 1–50 arası gösteriliyor"},{"Id":457905,"PropertyName":"label","Value":"Previous"},{"Id":584936,"PropertyName":"label","Value":"1"},{"Id":845222,"PropertyName":"label","Value":"2"},{"Id":859868,"PropertyName":"label","Value":"3"},{"Id":768987,"PropertyName":"label","Value":"Next"},{"Id":357110,"PropertyName":"value","Value":"50 / page"}]}]
    defaultML = "en_US"
    
    screenHash = ""
    


    constructor(props) {
        super(props);
		this.transferislemgunlugu_334149_value_kuikaTextInputRef = React.createRef();
		this.transferislemgunlugu_890376_value_kuikaAutoCompleteRef = React.createRef();
		this.transferislemgunlugu_618603_value_kuikaAutoCompleteRef = React.createRef();
		this.transferislemgunlugu_479528_value_kuikaAutoCompleteRef = React.createRef();
		this.transferislemgunlugu_469664_value_kuikaAutoCompleteRef = React.createRef();
		this.transferislemgunlugu_453072_value_kuikaAutoCompleteRef = React.createRef();
		this.transferislemgunlugu_424955_value_kuikaTableRef = React.createRef();

        this.state = {
            isSpinnerVisible: false,
            isPageVisible: false,
            isLeftMenuVisible: false,
            spinnerCount: 0,
            selectedLanguage: "",
            isPageInitLoaded: false,
            isPageRecurringLoaded: false,
            	        dataSource_890376: [{"key":"all","text":"Tümü"},{"key":"talep","text":"Talep"},{"key":"fis","text":"Fiş"},{"key":"kabul","text":"Kabul"}],
	        dataSource_618603: [{"key":"all","text":"Tümü"},{"key":"olusturma","text":"Oluşturma"},{"key":"onay","text":"Onay"},{"key":"entegrasyon","text":"Entegrasyon"}],
	        dataSource_479528: [{"key":"merkez","text":"Merkez Depo"},{"key":"kadikoy","text":"Kadıköy Mağaza"},{"key":"besiktas","text":"Beşiktaş Mağaza"}],
	        dataSource_469664: [{"key":"kadikoy","text":"Kadıköy Mağaza"},{"key":"besiktas","text":"Beşiktaş Mağaza"},{"key":"ankara","text":"Ankara Mağaza"}],
	        dataSource_453072: [{"key":"ayse","text":"Ayşe Demir"},{"key":"mehmet","text":"Mehmet Kaya"},{"key":"sistem","text":"Sistem"}],

        }

        this.state.isPageVisible = true;
        
    }

    async componentDidMount() {

        if (KuikaAppManager.isPageInitPrevented()) {
            KuikaAppManager.calculateAndSetBodyHeight("transferislemgunlugu", "");
            return;
        }
        
        
        ReactSystemFunctions.validateToken()
        this.fillFormInitValues();
        if (true){
            
        }
        
        
        
        KuikaAppManager.calculateAndSetBodyHeight("transferislemgunlugu", "");

        if (ReactSystemFunctions.getIsMicroApp() === false) {
           window.parentScreen = this;
        }
    }

    componentWillUnmount() {
        
        
        

        if (ReactSystemFunctions.getIsMicroApp() === false) {
           window.parentScreen = null;
        }
    }

    

        
    componentDidUpdate= async (prevProps, prevState) => {
		KuikaAppManager.calculateAndSetBodyHeight("transferislemgunlugu", ""    );
        if (prevProps?.location?.search !== (this.props as any)?.location?.search) {
			
		}

        

        if (ReactSystemFunctions.getIsMicroApp() === false) {
            for (const key in prevState) {
                if (key.startsWith('NavVisible') && prevState[key] === true && this.state[key] === false) {
                    window.parentScreen = this;
                    break;
                }
            }
        }
	}

    fillFormInitValues() {
        this.props.form?.setFieldsValue({
});

    }

      setPageInitLoaded = (value: boolean) => {
        this.setState({ isPageInitLoaded: value });
      }

      setPageRecurringLoaded = (value: boolean) => {
        this.setState({ isPageRecurringLoaded: value });
      }

      clearFieldValidation = (changedValues: any) => {
        const fieldName = Object.keys(changedValues)[0];
        if (fieldName) {
          this.props.form?.setFields([
            {
              name: fieldName,
              errors: []
            }
          ]);
        }
      };

      




    async callCallbackFunction(diId: number, isFromMaster: boolean = false) {
        let isErrorOccurred = false;

    }


}
