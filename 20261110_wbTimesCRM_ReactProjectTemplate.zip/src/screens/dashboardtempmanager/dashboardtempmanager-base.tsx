import React from "react";
import Axios, { AxiosResponse } from "axios";
import { KuikaAppManager } from "../../shared/utilty/kuika-app-manager";
import { ReactSystemFunctions } from "../../shared/utilty/react-system-functions";
import { KNavigator } from "../../shared/hoc/with-history";
import { KContext } from "../../shared/hoc/with-context";
import { useLocation } from "react-router-dom";
import { FormInstance } from "antd/es/form";
import { Guid } from "guid-typescript";
import Swal from "sweetalert2";
import { KMainFunctions } from "../../shared/utilty/main-functions";
import moment from "moment";
import { IValidationData } from "../../models/dto/validation-data";
import { IStripePayment } from "../../models/dto/stripe-payment";
import { IUserInfoDto } from "../../models/dto/user-info.dto";
import { UserService } from "../../services/user-service";
import { kuikaCoreWasmBridgeService } from "../../services/_singletons";
import _ from "lodash";
import mqtt, { MqttClient } from "mqtt";
import { IMqttResult } from "../../models/dto/mqtt.dto";
import { MasterScreen_ScreenContext } from "../masterscreen/masterscreen-context";

declare let window: any;

export interface IDashBoardTempManager_ScreenProps {
  navigator: KNavigator;
  form: FormInstance<any>;
  googleLogin: any;
  screenInputs: any;
  context: KContext;
  initialValues: any;
  children: any;
}

export interface IDashBoardTempManager_ScreenState {
    isSpinnerVisible: boolean;
    isPageVisible: boolean;
	isLeftMenuVisible: boolean;
    spinnerCount: number;
    selectedLanguage: string;
    isPageInitLoaded: false;
    isPageRecurringLoaded: false;
	TM_TopManagerDashSummary: any[];
	TM_TopManagerDashSummary_dummy: any[];
	TMGetDashboardStoreManagerTaskList: any[];
	TMGetDashboardStoreManagerTaskList_dummy: any[];
	TM_TopManagerDashboardAnalysis: any[];
	TM_TopManagerDashboardAnalysis_dummy: any[];
	TM_TopManagerDashboardLeadList: any[];
	TM_TopManagerDashboardLeadList_dummy: any[];
	TM_GetProductCategory: any[];
	TM_GetProductCategory_dummy: any[];
	TM_GetStore: any[];
	TM_GetStore_dummy: any[];
	TM_GetSalesPerson: any[];
	TM_GetSalesPerson_dummy: any[];
	TM_GetLeadStatus: any[];
	TM_GetLeadStatus_dummy: any[];
	TM_GetLeadProcess: any[];
	TM_GetLeadProcess_dummy: any[];
	TM_GetUserStoreInfo: any[];
	TM_GetUserStoreInfo_dummy: any[];
	TM_UserRoleByUserId: any[];
	TM_UserRoleByUserId_dummy: any[];
	TM_LeadProcessCountGrafik: any[];
	TM_LeadProcessCountGrafik_dummy: any[];
	TM_CategoryGrafik: any[];
	TM_CategoryGrafik_dummy: any[];
	TM_SatisDonusumGrafik: any[];
	TM_SatisDonusumGrafik_dummy: any[];
	TM_GetSalesExchangesRate: any[];
	TM_GetSalesExchangesRate_dummy: any[];
	NAVIGATE: any;
	NAVIGATE_dummy: any;
	SetValueOf: any;
	SetValueOf_dummy: any;
	isComp68480Visible: 'visible' | 'hidden';
	isComp460572Visible: 'visible' | 'hidden';
	isComp524280Visible: 'visible' | 'hidden';
	isComp259947Visible: 'visible' | 'hidden';
	isComp555357Visible: 'visible' | 'hidden';
	isComp350848Visible: 'visible' | 'hidden';
	isComp793422Visible: 'visible' | 'hidden';
	isComp438978Visible: 'visible' | 'hidden';
	isComp833206Visible: 'visible' | 'hidden';
	isComp10051Visible: 'visible' | 'hidden';
	isComp812626Visible: 'visible' | 'hidden';
	isComp853889Visible: 'visible' | 'hidden';
	isComp142402Visible: 'visible' | 'hidden';
	isComp373351Visible: 'visible' | 'hidden';
	isComp621790Visible: 'visible' | 'hidden';
	isComp296871Visible: 'visible' | 'hidden';
	isComp11830Visible: 'visible' | 'hidden';
	isComp508013Visible: 'visible' | 'hidden';
	isComp20059Visible: 'visible' | 'hidden';
	isComp693403Visible: 'visible' | 'hidden';
	isComp77242Visible: 'visible' | 'hidden';
	isComp352710Visible: 'visible' | 'hidden';
	isComp744094Visible: 'visible' | 'hidden';
	isComp558447Visible: 'visible' | 'hidden';
	isComp551457Visible: 'visible' | 'hidden';
	isComp862838Visible: 'visible' | 'hidden';
	isComp4159Visible: 'visible' | 'hidden';
	isComp170471Visible: 'visible' | 'hidden';
	isComp397882Visible: 'visible' | 'hidden';
	isComp941736Visible: 'visible' | 'hidden';
	isComp489263Visible: 'visible' | 'hidden';
	isComp675337Visible: 'visible' | 'hidden';
	isComp654813Visible: 'visible' | 'hidden';
	isComp804552Visible: 'visible' | 'hidden';
	isComp371503Visible: 'visible' | 'hidden';
	isComp698275Visible: 'visible' | 'hidden';
	isComp663057Visible: 'visible' | 'hidden';
	isComp864312Visible: 'visible' | 'hidden';
	isComp494064Visible: 'visible' | 'hidden';
	isComp855947Visible: 'visible' | 'hidden';
	isComp841562Visible: 'visible' | 'hidden';
	isComp520053Visible: 'visible' | 'hidden';
	isComp295368Visible: 'visible' | 'hidden';
	isComp230659Visible: 'visible' | 'hidden';
	isComp538553Visible: 'visible' | 'hidden';
	isComp273129Visible: 'visible' | 'hidden';
	isComp356733Visible: 'visible' | 'hidden';
	isComp508867Visible: 'visible' | 'hidden';
	isComp282096Visible: 'visible' | 'hidden';
	isComp326896Visible: 'visible' | 'hidden';
	isCompdashboardtempmanager_70736AuthorizationVisible: 'visible' | 'hidden';

}

export class DashBoardTempManager_ScreenBase extends React.PureComponent<IDashBoardTempManager_ScreenProps, any> {
    static contextType = MasterScreen_ScreenContext;
    declare context: React.ContextType<typeof MasterScreen_ScreenContext>;
	dashboardtempmanager_392247_value_kuikaFlexGridRef: React.RefObject<any>;
	dashboardtempmanager_934663_value_kuikaSelectBoxRef: React.RefObject<any>;
	dashboardtempmanager_75145_value_kuikaTableRef: React.RefObject<any>;
	dashboardtempmanager_138929_value_kuikaDateRef: React.RefObject<any>;
	dashboardtempmanager_381090_value_kuikaDateRef: React.RefObject<any>;
	dashboardtempmanager_827135_value_kuikaTableRef: React.RefObject<any>;
    ml=[{"Id":"d5a61d2b-bd60-485f-86e2-661e9ed4e486","Name":"en_US","ShortName":"English","IsDefault":true,"LanguagePhrases":[]},{"Id":"8cf8c3f8-cfc9-4f72-8f87-9631a7b00a92","Name":"FixedValues","ShortName":"FixedValues","LanguagePhrases":[{"Id":274103,"PropertyName":"value","Value":"Talep Yönetimi"},{"Id":789332,"PropertyName":"value","Value":"Dashboard"},{"Id":837504,"PropertyName":"value","Value":"Talep Yönetimi Dashboard"},{"Id":140351,"PropertyName":"value","Value":"Leadlerinizi, görevlerinizi ve satış süreçlerinizi tek ekrandan takip edin."},{"Id":392247,"PropertyName":"nodatafoundmessage","Value":"No data found."},{"Id":919827,"PropertyName":"value","Value":"[datafield:currencycode]"},{"Id":261215,"PropertyName":"value","Value":"[datafield:rate]"},{"Id":640020,"PropertyName":"value","Value":"Aktif Leadler"},{"Id":752799,"PropertyName":"value","Value":"İşlem bekleyen açık kayıtlar"},{"Id":369082,"PropertyName":"value","Value":"Bu Ayın Terminleri"},{"Id":938700,"PropertyName":"value","Value":"Gün içinde tamamlanacak işler"},{"Id":125925,"PropertyName":"value","Value":"Geciken Terminler"},{"Id":607761,"PropertyName":"value","Value":"Öncelikli aksiyon gerekenler"},{"Id":390276,"PropertyName":"value","Value":"Onay Bekleyenler"},{"Id":804596,"PropertyName":"value","Value":"Yönetici veya mağaza onayı"},{"Id":766671,"PropertyName":"value","Value":"Rezerv Onayı Bekleyenler"},{"Id":204668,"PropertyName":"value","Value":"Onay kuyruğundaki rezervler"},{"Id":757494,"PropertyName":"value","Value":"Satış Bekleyenler"},{"Id":964521,"PropertyName":"value","Value":"Müşteri dönüşü beklenen kayıtlar"},{"Id":735181,"PropertyName":"value","Value":"Satışı Yapılanlar"},{"Id":487614,"PropertyName":"value","Value":"Sonuçlanan satışlar"},{"Id":483429,"PropertyName":"value","Value":"Müşteri İstemedi"},{"Id":501923,"PropertyName":"value","Value":"Kapanan olumsuz dönüşler"},{"Id":581858,"PropertyName":"value","Value":"Geciken Leadler"},{"Id":640933,"PropertyName":"value","Value":"Termin veya rezerv aksiyonu geciken kayıtlar"},{"Id":179261,"PropertyName":"value","Value":"Personel Bazlı Performans"},{"Id":606342,"PropertyName":"value","Value":"Bu ay en yüksek sonuçlanan lead"},{"Id":65817,"PropertyName":"value","Value":"Mağaza Bazlı Performans"},{"Id":980424,"PropertyName":"value","Value":"Aktif lead ve satış kapanış oranı en yüksek mağaza"},{"Id":990510,"PropertyName":"value","Value":"Öncelikli Görevlerim"},{"Id":448598,"PropertyName":"value","Value":"Günlük operasyon akışında ilk aksiyon gerektiren görevler"},{"Id":561859,"PropertyName":"value","Value":"Operasyon Tablosu"},{"Id":504673,"PropertyName":"label","Value":"Talep Ekle"},{"Id":934663,"PropertyName":"placeholder","Value":"Görev Seç"},{"Id":250548,"PropertyName":"title","Value":"Lead No"},{"Id":311744,"PropertyName":"value","Value":"[datafield:leadnumarasi]"},{"Id":183038,"PropertyName":"title","Value":"Mağaza"},{"Id":139053,"PropertyName":"value","Value":"[datafield:storename]"},{"Id":239171,"PropertyName":"title","Value":"Müşteri"},{"Id":184409,"PropertyName":"value","Value":"[datafield:musteri]"},{"Id":211715,"PropertyName":"title","Value":"Ürün"},{"Id":273730,"PropertyName":"value","Value":"[datafield:productname]"},{"Id":946565,"PropertyName":"title","Value":"Kategori"},{"Id":259947,"PropertyName":"value","Value":"[datafield:categoryname]"},{"Id":555357,"PropertyName":"value","Value":"[datafield:categoryname]"},{"Id":350848,"PropertyName":"value","Value":"[datafield:categoryname]"},{"Id":793422,"PropertyName":"value","Value":"[datafield:categoryname]"},{"Id":365407,"PropertyName":"title","Value":"Mevcut Durum"},{"Id":438978,"PropertyName":"value","Value":"[datafield:processname]"},{"Id":833206,"PropertyName":"value","Value":"[datafield:processname]"},{"Id":10051,"PropertyName":"value","Value":"[datafield:processname]"},{"Id":812626,"PropertyName":"value","Value":"[datafield:processname]"},{"Id":853889,"PropertyName":"value","Value":"[datafield:processname]"},{"Id":623955,"PropertyName":"title","Value":"Termin Tarihi"},{"Id":88587,"PropertyName":"value","Value":"[datafield:termintarihi]"},{"Id":864660,"PropertyName":"title","Value":"Görev Tipi"},{"Id":142402,"PropertyName":"value","Value":"[datafield:tasktitle]"},{"Id":373351,"PropertyName":"value","Value":"[datafield:tasktitle]"},{"Id":621790,"PropertyName":"value","Value":"[datafield:tasktitle]"},{"Id":296871,"PropertyName":"value","Value":"[datafield:tasktitle]"},{"Id":11830,"PropertyName":"value","Value":"[datafield:tasktitle]"},{"Id":508013,"PropertyName":"value","Value":"[datafield:tasktitle]"},{"Id":230270,"PropertyName":"title","Value":"Aksiyon"},{"Id":152850,"PropertyName":"label","Value":"Detaya Git"},{"Id":443987,"PropertyName":"value","Value":"Leadler"},{"Id":350872,"PropertyName":"value","Value":"Mevcut Lead List ekranındaki sade tablo yoğunluğuna uyumlu genel görünüm"},{"Id":348333,"PropertyName":"value","Value":"Liste Görünümü"},{"Id":20059,"PropertyName":"label","Value":"Tümü"},{"Id":693403,"PropertyName":"label","Value":"Tümü"},{"Id":77242,"PropertyName":"label","Value":"Aktif"},{"Id":352710,"PropertyName":"label","Value":"Aktif"},{"Id":744094,"PropertyName":"label","Value":"Bugün"},{"Id":558447,"PropertyName":"label","Value":"Bugün"},{"Id":551457,"PropertyName":"label","Value":"Geciken"},{"Id":862838,"PropertyName":"label","Value":"Geciken"},{"Id":4159,"PropertyName":"label","Value":"Termin Bekleyen"},{"Id":170471,"PropertyName":"label","Value":"Termin Bekleyen"},{"Id":397882,"PropertyName":"label","Value":"Onay Bekleyen"},{"Id":941736,"PropertyName":"label","Value":"Onay Bekleyen"},{"Id":489263,"PropertyName":"label","Value":"Rezerv Bekleyen"},{"Id":675337,"PropertyName":"label","Value":"Rezerv Bekleyen"},{"Id":654813,"PropertyName":"label","Value":"Satış Bekleyen"},{"Id":804552,"PropertyName":"label","Value":"Satış Bekleyen"},{"Id":371503,"PropertyName":"label","Value":"Sonuçlanan"},{"Id":698275,"PropertyName":"label","Value":"Sonuçlanan"},{"Id":710914,"PropertyName":"value","Value":"Detaylı Tablo"},{"Id":422039,"PropertyName":"value","Value":"Filtre"},{"Id":63357,"PropertyName":"value","Value":"Müşteri Adı"},{"Id":666343,"PropertyName":"placeholder","Value":"Müşteri Adı"},{"Id":137338,"PropertyName":"value","Value":"Ürün Adı"},{"Id":153369,"PropertyName":"placeholder","Value":"Ürün Adı"},{"Id":625431,"PropertyName":"value","Value":"Kategori"},{"Id":731364,"PropertyName":"placeholder","Value":"Kategori"},{"Id":815387,"PropertyName":"value","Value":"Mağaza"},{"Id":453042,"PropertyName":"placeholder","Value":"Mağaza"},{"Id":599253,"PropertyName":"value","Value":"Satış Danışmanı"},{"Id":425161,"PropertyName":"placeholder","Value":"Satış Danışmanı"},{"Id":634284,"PropertyName":"value","Value":"Talep Durumu"},{"Id":274478,"PropertyName":"placeholder","Value":"Talep Durumu"},{"Id":238742,"PropertyName":"value","Value":"Başlangıç Tarihi"},{"Id":138929,"PropertyName":"placeholder","Value":"Select Date..."},{"Id":299511,"PropertyName":"value","Value":"Bitiş Tarihi"},{"Id":381090,"PropertyName":"placeholder","Value":"Select Date..."},{"Id":56981,"PropertyName":"label","Value":"Filtre Uygula"},{"Id":462456,"PropertyName":"label","Value":"Filtre Temizle"},{"Id":239982,"PropertyName":"title","Value":"Talep Tarihi"},{"Id":576950,"PropertyName":"value","Value":"[datafield:taleptarihi]"},{"Id":760326,"PropertyName":"title","Value":"Lead No"},{"Id":559636,"PropertyName":"value","Value":"[datafield:leadnumarasi]"},{"Id":294249,"PropertyName":"title","Value":"Mağaza"},{"Id":105263,"PropertyName":"value","Value":"[datafield:storename]"},{"Id":153646,"PropertyName":"title","Value":"Marka"},{"Id":199688,"PropertyName":"value","Value":"[datafield:brand]"},{"Id":13665,"PropertyName":"title","Value":"Kategori"},{"Id":663057,"PropertyName":"value","Value":"[datafield:categoryname]"},{"Id":864312,"PropertyName":"value","Value":"[datafield:categoryname]"},{"Id":494064,"PropertyName":"value","Value":"[datafield:categoryname]"},{"Id":855947,"PropertyName":"value","Value":"[datafield:categoryname]"},{"Id":109828,"PropertyName":"title","Value":"Ürün Adı"},{"Id":888963,"PropertyName":"value","Value":"[datafield:productname]"},{"Id":397898,"PropertyName":"title","Value":"Müşteri"},{"Id":683955,"PropertyName":"value","Value":"[datafield:musteri]"},{"Id":672001,"PropertyName":"title","Value":"Takip Durumu"},{"Id":841562,"PropertyName":"value","Value":"[datafield:leaddurumu]"},{"Id":520053,"PropertyName":"value","Value":"[datafield:leaddurumu]"},{"Id":816484,"PropertyName":"title","Value":"Sonraki Adım"},{"Id":464359,"PropertyName":"value","Value":"[datafield:sonrakiadim]"},{"Id":859738,"PropertyName":"title","Value":"Tahmini Teslimat"},{"Id":665159,"PropertyName":"value","Value":"[datafield:termintarihi]"},{"Id":758920,"PropertyName":"title","Value":"Rezerve Durumu"},{"Id":295368,"PropertyName":"value","Value":"Evet"},{"Id":230659,"PropertyName":"value","Value":"Hayır"},{"Id":538553,"PropertyName":"value","Value":"Onay Bekliyor"},{"Id":157252,"PropertyName":"title","Value":"Satış Danışmanı"},{"Id":840311,"PropertyName":"value","Value":"[datafield:satisdanismani]"},{"Id":315557,"PropertyName":"title","Value":"Talep Durumu"},{"Id":273129,"PropertyName":"value","Value":"[datafield:processname]"},{"Id":356733,"PropertyName":"value","Value":"[datafield:processname]"},{"Id":508867,"PropertyName":"value","Value":"[datafield:processname]"},{"Id":282096,"PropertyName":"value","Value":"[datafield:processname]"},{"Id":326896,"PropertyName":"value","Value":"[datafield:processname]"},{"Id":673334,"PropertyName":"title","Value":"Detay"},{"Id":372153,"PropertyName":"label","Value":"Detaya Git"},{"Id":390533,"PropertyName":"value","Value":"Lead Durum Dağılımı"},{"Id":777794,"PropertyName":"value","Value":"Durum bazlı yük dengesi"},{"Id":987210,"PropertyName":"value","Value":"Kategori Bazlı Lead Dağılımı"},{"Id":389215,"PropertyName":"value","Value":"Talep yoğunluğu karşılaştırması"},{"Id":701700,"PropertyName":"value","Value":"Satış Dönüşüm Oranı"},{"Id":701655,"PropertyName":"value","Value":"Satışı Yapıldı / Toplam Sonuçlanan Lead"}]}]
    defaultML = "en_US"
    
    screenHash = ""
    

    private _prevMasterPageInitLoaded: boolean = false;
    private _prevMasterPageRecurringLoaded: boolean = false;
    private _prevShouldTriggerPageInit: boolean = false;
    constructor(props) {
        super(props);
		this.dashboardtempmanager_392247_value_kuikaFlexGridRef = React.createRef();
		this.dashboardtempmanager_934663_value_kuikaSelectBoxRef = React.createRef();
		this.dashboardtempmanager_75145_value_kuikaTableRef = React.createRef();
		this.dashboardtempmanager_666343_value_kuikaTextInputRef = React.createRef();
		this.dashboardtempmanager_153369_value_kuikaTextInputRef = React.createRef();
		this.dashboardtempmanager_138929_value_kuikaDateRef = React.createRef();
		this.dashboardtempmanager_381090_value_kuikaDateRef = React.createRef();
		this.dashboardtempmanager_827135_value_kuikaTableRef = React.createRef();

        this.state = {
            isSpinnerVisible: false,
            isPageVisible: false,
            isLeftMenuVisible: false,
            spinnerCount: 0,
            selectedLanguage: "",
            isPageInitLoaded: false,
            isPageRecurringLoaded: false,
            	        TM_TopManagerDashSummary: [],
	        TMGetDashboardStoreManagerTaskList: [],
	        TM_TopManagerDashboardAnalysis: [],
	        TM_TopManagerDashboardLeadList: [],
	        TM_GetProductCategory: [],
	        TM_GetStore: [],
	        TM_GetSalesPerson: [],
	        TM_GetLeadStatus: [],
	        TM_GetLeadProcess: [],
	        TM_GetUserStoreInfo: [],
	        TM_UserRoleByUserId: [],
	        TM_LeadProcessCountGrafik: [],
	        TM_CategoryGrafik: [],
	        TM_SatisDonusumGrafik: [],
	        TM_GetSalesExchangesRate: [],
	        NAVIGATE: "",
	        SetValueOf: "",
	        dataSource_934663: [{"key":"1","text":"Onay Bekleyenler"},{"key":"2","text":"Teslim Bekleyenler"},{"key":"3","text":"Termin Önerisi Bekleyenler"},{"key":"4","text":"Rezerv Onayı Bekleyenler"},{"key":"5","text":"Rezerv Talebi Bekleyenler"}],
	        isComp68480Visible: 'hidden',
	        isComp460572Visible: 'hidden',
	        isComp524280Visible: 'hidden',
	        isComp259947Visible: 'hidden',
	        isComp555357Visible: 'hidden',
	        isComp350848Visible: 'hidden',
	        isComp793422Visible: 'hidden',
	        isComp438978Visible: 'hidden',
	        isComp833206Visible: 'hidden',
	        isComp10051Visible: 'hidden',
	        isComp812626Visible: 'hidden',
	        isComp853889Visible: 'hidden',
	        isComp142402Visible: 'hidden',
	        isComp373351Visible: 'hidden',
	        isComp621790Visible: 'hidden',
	        isComp296871Visible: 'hidden',
	        isComp11830Visible: 'hidden',
	        isComp508013Visible: 'hidden',
	        isComp20059Visible: 'hidden',
	        isComp693403Visible: 'hidden',
	        isComp77242Visible: 'hidden',
	        isComp352710Visible: 'hidden',
	        isComp744094Visible: 'hidden',
	        isComp558447Visible: 'hidden',
	        isComp551457Visible: 'hidden',
	        isComp862838Visible: 'hidden',
	        isComp4159Visible: 'hidden',
	        isComp170471Visible: 'hidden',
	        isComp397882Visible: 'hidden',
	        isComp941736Visible: 'hidden',
	        isComp489263Visible: 'hidden',
	        isComp675337Visible: 'hidden',
	        isComp654813Visible: 'hidden',
	        isComp804552Visible: 'hidden',
	        isComp371503Visible: 'hidden',
	        isComp698275Visible: 'hidden',
	        isComp663057Visible: 'hidden',
	        isComp864312Visible: 'hidden',
	        isComp494064Visible: 'hidden',
	        isComp855947Visible: 'hidden',
	        isComp841562Visible: 'hidden',
	        isComp520053Visible: 'hidden',
	        isComp295368Visible: 'hidden',
	        isComp230659Visible: 'hidden',
	        isComp538553Visible: 'hidden',
	        isComp273129Visible: 'hidden',
	        isComp356733Visible: 'hidden',
	        isComp508867Visible: 'hidden',
	        isComp282096Visible: 'hidden',
	        isComp326896Visible: 'hidden',
	        isCompdashboardtempmanager_70736AuthorizationVisible: 'visible',

        }

        this.state.isPageVisible = true;
        
    }

    async componentDidMount() {

        if (KuikaAppManager.isPageInitPrevented()) {
            KuikaAppManager.calculateAndSetBodyHeight("dashboardtempmanager", "masterscreen_screen");
            return;
        }
        this.context.registerCallbackFunction(this.callCallbackFunction.bind(this));
        
        ReactSystemFunctions.validateToken()
        this.fillFormInitValues();
        if (false){
            await this.DashBoardTempManagerPageInit();
        } else if (this.context?.isMasterPageInitLoaded) { this._prevMasterPageInitLoaded = true; await this.DashBoardTempManagerPageInit(); }
        ReactSystemFunctions.hideIsNotAuthorized(this, "isCompdashboardtempmanager_70736AuthorizationVisible", ["cdb536b0-6297-155f-d446-8453d8a60304","4da1f213-c8e4-0b50-5c84-02fd13f1a622","c4e882ef-977d-f613-7694-230ac83919d2","d6658aef-a188-d73c-9c42-e40f55e18bdb","TimesYonetici","TimesUstYonetici","TimesAdmin","_SystemAdmin"]);

        
        
        KuikaAppManager.calculateAndSetBodyHeight("dashboardtempmanager", "masterscreen_screen");

        if (ReactSystemFunctions.getIsMicroApp() === false) {
           window.parentScreen = this;
        }
    }

    componentWillUnmount() {
        
        
        

        if (ReactSystemFunctions.getIsMicroApp() === false) {
           window.parentScreen = null;
        }
    }

    

        
    componentDidUpdate= async (prevProps, prevState) => {
		KuikaAppManager.calculateAndSetBodyHeight("dashboardtempmanager", "masterscreen_screen"    );
        if (prevProps?.location?.search !== (this.props as any)?.location?.search) {
			await this.DashBoardTempManagerPageInit();
		}

        		if (this._prevMasterPageInitLoaded !== this.context.isMasterPageInitLoaded && this.context.isMasterPageInitLoaded === true) {this._prevMasterPageInitLoaded = this.context.isMasterPageInitLoaded;await this.DashBoardTempManagerPageInit()}


        if (ReactSystemFunctions.getIsMicroApp() === false) {
            for (const key in prevState) {
                if (key.startsWith('NavVisible') && prevState[key] === true && this.state[key] === false) {
                    window.parentScreen = this;
                    break;
                }
            }
        }
	}

    fillFormInitValues() {
        this.props.form?.setFieldsValue({
});

    }

      setPageInitLoaded = (value: boolean) => {
        this.setState({ isPageInitLoaded: value });
      }

      setPageRecurringLoaded = (value: boolean) => {
        this.setState({ isPageRecurringLoaded: value });
      }

      clearFieldValidation = (changedValues: any) => {
        const fieldName = Object.keys(changedValues)[0];
        if (fieldName) {
          this.props.form?.setFields([
            {
              name: fieldName,
              errors: []
            }
          ]);
        }
      };

      

    DashBoardTempManagerPageInit = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


	if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }

        let localVar = {
			UserId_1: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.getMyUserId(), "Guid"),
			TaskTypeFilter_1: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toInteger(this, ReactSystemFunctions.value(this, "dashboardtempmanager_934663_value", "value", "", "key", "")), "number"),
			ThisMonth_2: ReactSystemFunctions.convertToTypeByName(0, "number"),
			UserId_3: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.getMyUserId(), "Guid"),
			MusteriAdi_3: ReactSystemFunctions.convertToTypeByName(null, "string"),
			ProductName_3: ReactSystemFunctions.convertToTypeByName(null, "string"),
			LeadCode_3: ReactSystemFunctions.convertToTypeByName(null, "string"),
			Tel_3: ReactSystemFunctions.convertToTypeByName(null, "string"),
			CategoryName_3: ReactSystemFunctions.convertToTypeByName(null, "string"),
			StoreIds_3: ReactSystemFunctions.convertToTypeByName(null, "string"),
			SatisDanismaniIds_3: ReactSystemFunctions.convertToTypeByName(null, "string"),
			ProcessCode_3: ReactSystemFunctions.convertToTypeByName(null, "string"),
			StepOrder_3: ReactSystemFunctions.convertToTypeByName(0, "number"),
			StartDate_3: ReactSystemFunctions.convertToTypeByName(null, "Date"),
			EndDate_3: ReactSystemFunctions.convertToTypeByName(null, "Date"),
			KUserId_5: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.getMyUserId(), "Guid"),
			KUserId_6: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.getMyUserId(), "Guid"),
			StoreId_6: ReactSystemFunctions.convertToTypeByName(null, "Guid"),
			StepOrder_8: ReactSystemFunctions.convertToTypeByName(0, "number"),
			UserId_9: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.getMyUserId(), "Guid"),
			UserID_10: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.getMyUserId(), "Guid"),
			UserId_11: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.getMyUserId(), "Guid"),
			StartDate_11: ReactSystemFunctions.convertToTypeByName(null, "Date"),
			EndDate_11: ReactSystemFunctions.convertToTypeByName(null, "Date"),
			UserId_12: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.getMyUserId(), "Guid"),
			StartDate_12: ReactSystemFunctions.convertToTypeByName(null, "Date"),
			EndDate_12: ReactSystemFunctions.convertToTypeByName(null, "Date"),
			UserId_13: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.getMyUserId(), "Guid"),
			StartDate_13: ReactSystemFunctions.convertToTypeByName(null, "Date"),
			EndDate_13: ReactSystemFunctions.convertToTypeByName(null, "Date")
        }

	KuikaAppManager.showSpinner(this);
	
        if (true) {
        KuikaAppManager.showSpinner(this);
        }
        let result = await KuikaAppManager.ApiRequest(this, "DashBoardTempManager/DashBoardTempManagerPageInit", localVar)
        if (!KMainFunctions.IsResStatus2XX(result)) return true;

		stateVars.TM_TopManagerDashSummary = result?.data.tM_TopManagerDashSummary;
		formVars.dashboardtempmanager_975657_value = ReactSystemFunctions.toString(this, (stateVars.TM_TopManagerDashSummary !== undefined ? (stateVars.TM_TopManagerDashSummary?.length > 0 ? stateVars.TM_TopManagerDashSummary[0].activeLead : null) : (this.state.TM_TopManagerDashSummary?.length > 0 ? this.state.TM_TopManagerDashSummary[0].activeLead : null)));
		formVars.dashboardtempmanager_759366_value = ReactSystemFunctions.toString(this, (stateVars.TM_TopManagerDashSummary !== undefined ? (stateVars.TM_TopManagerDashSummary?.length > 0 ? stateVars.TM_TopManagerDashSummary[0].buAyinTerminleri : null) : (this.state.TM_TopManagerDashSummary?.length > 0 ? this.state.TM_TopManagerDashSummary[0].buAyinTerminleri : null)));
		formVars.dashboardtempmanager_933641_value = ReactSystemFunctions.toString(this, (stateVars.TM_TopManagerDashSummary !== undefined ? (stateVars.TM_TopManagerDashSummary?.length > 0 ? stateVars.TM_TopManagerDashSummary[0].gecikenTerminler : null) : (this.state.TM_TopManagerDashSummary?.length > 0 ? this.state.TM_TopManagerDashSummary[0].gecikenTerminler : null)));
		formVars.dashboardtempmanager_97977_value = ReactSystemFunctions.toString(this, (stateVars.TM_TopManagerDashSummary !== undefined ? (stateVars.TM_TopManagerDashSummary?.length > 0 ? stateVars.TM_TopManagerDashSummary[0].onayBekleyenler : null) : (this.state.TM_TopManagerDashSummary?.length > 0 ? this.state.TM_TopManagerDashSummary[0].onayBekleyenler : null)));
		formVars.dashboardtempmanager_744058_value = ReactSystemFunctions.toString(this, (stateVars.TM_TopManagerDashSummary !== undefined ? (stateVars.TM_TopManagerDashSummary?.length > 0 ? stateVars.TM_TopManagerDashSummary[0].rezervOnayBekleyenler : null) : (this.state.TM_TopManagerDashSummary?.length > 0 ? this.state.TM_TopManagerDashSummary[0].rezervOnayBekleyenler : null)));
		formVars.dashboardtempmanager_201486_value = ReactSystemFunctions.toString(this, (stateVars.TM_TopManagerDashSummary !== undefined ? (stateVars.TM_TopManagerDashSummary?.length > 0 ? stateVars.TM_TopManagerDashSummary[0].satisBekleyenler : null) : (this.state.TM_TopManagerDashSummary?.length > 0 ? this.state.TM_TopManagerDashSummary[0].satisBekleyenler : null)));
		formVars.dashboardtempmanager_274863_value = ReactSystemFunctions.toString(this, (stateVars.TM_TopManagerDashSummary !== undefined ? (stateVars.TM_TopManagerDashSummary?.length > 0 ? stateVars.TM_TopManagerDashSummary[0].satisiYapilanlar : null) : (this.state.TM_TopManagerDashSummary?.length > 0 ? this.state.TM_TopManagerDashSummary[0].satisiYapilanlar : null)));
		formVars.dashboardtempmanager_926490_value = ReactSystemFunctions.toString(this, (stateVars.TM_TopManagerDashSummary !== undefined ? (stateVars.TM_TopManagerDashSummary?.length > 0 ? stateVars.TM_TopManagerDashSummary[0].musteriIstemedi : null) : (this.state.TM_TopManagerDashSummary?.length > 0 ? this.state.TM_TopManagerDashSummary[0].musteriIstemedi : null)));
		formVars.dashboardtempmanager_292258_value = ReactSystemFunctions.toString(this, (stateVars.TM_TopManagerDashSummary !== undefined ? (stateVars.TM_TopManagerDashSummary?.length > 0 ? stateVars.TM_TopManagerDashSummary[0].gecikenLeadler : null) : (this.state.TM_TopManagerDashSummary?.length > 0 ? this.state.TM_TopManagerDashSummary[0].gecikenLeadler : null)));
		stateVars.TMGetDashboardStoreManagerTaskList = result?.data.tmGetDashboardStoreManagerTaskList;
		
		stateVars.TM_TopManagerDashboardAnalysis = result?.data.tM_TopManagerDashboardAnalysis;
		formVars.dashboardtempmanager_299556_value = ReactSystemFunctions.toString(this, (stateVars.TM_TopManagerDashboardAnalysis !== undefined ? (stateVars.TM_TopManagerDashboardAnalysis?.length > 0 ? stateVars.TM_TopManagerDashboardAnalysis[0].bestSalesPerson : null) : (this.state.TM_TopManagerDashboardAnalysis?.length > 0 ? this.state.TM_TopManagerDashboardAnalysis[0].bestSalesPerson : null)));
		formVars.dashboardtempmanager_652231_percent = ReactSystemFunctions.value(this, (stateVars.TM_TopManagerDashboardAnalysis !== undefined ? (stateVars.TM_TopManagerDashboardAnalysis?.length > 0 ? stateVars.TM_TopManagerDashboardAnalysis[0].personConversionRate : null) : (this.state.TM_TopManagerDashboardAnalysis?.length > 0 ? this.state.TM_TopManagerDashboardAnalysis[0].personConversionRate : null)));
		formVars.dashboardtempmanager_128340_value = ReactSystemFunctions.toString(this, (stateVars.TM_TopManagerDashboardAnalysis !== undefined ? (stateVars.TM_TopManagerDashboardAnalysis?.length > 0 ? stateVars.TM_TopManagerDashboardAnalysis[0].bestStore : null) : (this.state.TM_TopManagerDashboardAnalysis?.length > 0 ? this.state.TM_TopManagerDashboardAnalysis[0].bestStore : null)));
		formVars.dashboardtempmanager_989995_percent = ReactSystemFunctions.value(this, (stateVars.TM_TopManagerDashboardAnalysis !== undefined ? (stateVars.TM_TopManagerDashboardAnalysis?.length > 0 ? stateVars.TM_TopManagerDashboardAnalysis[0].storeConversionRate : null) : (this.state.TM_TopManagerDashboardAnalysis?.length > 0 ? this.state.TM_TopManagerDashboardAnalysis[0].storeConversionRate : null)));
		stateVars.TM_TopManagerDashboardLeadList = result?.data.tM_TopManagerDashboardLeadList;
		
		stateVars.isComp20059Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, (stateVars.TM_TopManagerDashboardLeadList !== undefined ? (stateVars.TM_TopManagerDashboardLeadList?.length > 0 ? stateVars.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null) : (this.state.TM_TopManagerDashboardLeadList?.length > 0 ? this.state.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null))), ReactSystemFunctions.convertToTypeByName("0", "string"))) === true ? "visible" : "hidden")
		stateVars.isComp693403Visible = ((ReactSystemFunctions.isNotEqualTo(ReactSystemFunctions.value(this, (stateVars.TM_TopManagerDashboardLeadList !== undefined ? (stateVars.TM_TopManagerDashboardLeadList?.length > 0 ? stateVars.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null) : (this.state.TM_TopManagerDashboardLeadList?.length > 0 ? this.state.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null))), ReactSystemFunctions.convertToTypeByName("0", "string"))) === true ? "visible" : "hidden")
		stateVars.isComp77242Visible = ((ReactSystemFunctions.isNotEqualTo(ReactSystemFunctions.value(this, (stateVars.TM_TopManagerDashboardLeadList !== undefined ? (stateVars.TM_TopManagerDashboardLeadList?.length > 0 ? stateVars.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null) : (this.state.TM_TopManagerDashboardLeadList?.length > 0 ? this.state.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null))), ReactSystemFunctions.convertToTypeByName("-1", "string"))) === true ? "visible" : "hidden")
		stateVars.isComp352710Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, (stateVars.TM_TopManagerDashboardLeadList !== undefined ? (stateVars.TM_TopManagerDashboardLeadList?.length > 0 ? stateVars.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null) : (this.state.TM_TopManagerDashboardLeadList?.length > 0 ? this.state.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null))), ReactSystemFunctions.convertToTypeByName("-1", "string"))) === true ? "visible" : "hidden")
		stateVars.isComp744094Visible = ((ReactSystemFunctions.isNotEqualTo(ReactSystemFunctions.value(this, (stateVars.TM_TopManagerDashboardLeadList !== undefined ? (stateVars.TM_TopManagerDashboardLeadList?.length > 0 ? stateVars.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null) : (this.state.TM_TopManagerDashboardLeadList?.length > 0 ? this.state.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null))), ReactSystemFunctions.convertToTypeByName("-2", "string"))) === true ? "visible" : "hidden")
		stateVars.isComp558447Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, (stateVars.TM_TopManagerDashboardLeadList !== undefined ? (stateVars.TM_TopManagerDashboardLeadList?.length > 0 ? stateVars.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null) : (this.state.TM_TopManagerDashboardLeadList?.length > 0 ? this.state.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null))), ReactSystemFunctions.convertToTypeByName("-2", "string"))) === true ? "visible" : "hidden")
		stateVars.isComp551457Visible = ((ReactSystemFunctions.isNotEqualTo(ReactSystemFunctions.value(this, (stateVars.TM_TopManagerDashboardLeadList !== undefined ? (stateVars.TM_TopManagerDashboardLeadList?.length > 0 ? stateVars.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null) : (this.state.TM_TopManagerDashboardLeadList?.length > 0 ? this.state.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null))), ReactSystemFunctions.convertToTypeByName("-3", "string"))) === true ? "visible" : "hidden")
		stateVars.isComp862838Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, (stateVars.TM_TopManagerDashboardLeadList !== undefined ? (stateVars.TM_TopManagerDashboardLeadList?.length > 0 ? stateVars.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null) : (this.state.TM_TopManagerDashboardLeadList?.length > 0 ? this.state.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null))), ReactSystemFunctions.convertToTypeByName("-3", "string"))) === true ? "visible" : "hidden")
		stateVars.isComp4159Visible = ((ReactSystemFunctions.isNotEqualTo(ReactSystemFunctions.value(this, (stateVars.TM_TopManagerDashboardLeadList !== undefined ? (stateVars.TM_TopManagerDashboardLeadList?.length > 0 ? stateVars.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null) : (this.state.TM_TopManagerDashboardLeadList?.length > 0 ? this.state.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null))), ReactSystemFunctions.convertToTypeByName("2", "string"))) === true ? "visible" : "hidden")
		stateVars.isComp170471Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, (stateVars.TM_TopManagerDashboardLeadList !== undefined ? (stateVars.TM_TopManagerDashboardLeadList?.length > 0 ? stateVars.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null) : (this.state.TM_TopManagerDashboardLeadList?.length > 0 ? this.state.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null))), ReactSystemFunctions.convertToTypeByName("2", "string"))) === true ? "visible" : "hidden")
		stateVars.isComp397882Visible = ((ReactSystemFunctions.isNotEqualTo(ReactSystemFunctions.value(this, (stateVars.TM_TopManagerDashboardLeadList !== undefined ? (stateVars.TM_TopManagerDashboardLeadList?.length > 0 ? stateVars.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null) : (this.state.TM_TopManagerDashboardLeadList?.length > 0 ? this.state.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null))), ReactSystemFunctions.convertToTypeByName("3", "string"))) === true ? "visible" : "hidden")
		stateVars.isComp941736Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, (stateVars.TM_TopManagerDashboardLeadList !== undefined ? (stateVars.TM_TopManagerDashboardLeadList?.length > 0 ? stateVars.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null) : (this.state.TM_TopManagerDashboardLeadList?.length > 0 ? this.state.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null))), ReactSystemFunctions.convertToTypeByName("3", "string"))) === true ? "visible" : "hidden")
		stateVars.isComp489263Visible = ((ReactSystemFunctions.isNotEqualTo(ReactSystemFunctions.value(this, (stateVars.TM_TopManagerDashboardLeadList !== undefined ? (stateVars.TM_TopManagerDashboardLeadList?.length > 0 ? stateVars.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null) : (this.state.TM_TopManagerDashboardLeadList?.length > 0 ? this.state.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null))), ReactSystemFunctions.convertToTypeByName("10", "string"))) === true ? "visible" : "hidden")
		stateVars.isComp675337Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, (stateVars.TM_TopManagerDashboardLeadList !== undefined ? (stateVars.TM_TopManagerDashboardLeadList?.length > 0 ? stateVars.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null) : (this.state.TM_TopManagerDashboardLeadList?.length > 0 ? this.state.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null))), ReactSystemFunctions.convertToTypeByName("10", "string"))) === true ? "visible" : "hidden")
		stateVars.isComp654813Visible = ((ReactSystemFunctions.isNotEqualTo(ReactSystemFunctions.value(this, (stateVars.TM_TopManagerDashboardLeadList !== undefined ? (stateVars.TM_TopManagerDashboardLeadList?.length > 0 ? stateVars.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null) : (this.state.TM_TopManagerDashboardLeadList?.length > 0 ? this.state.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null))), ReactSystemFunctions.convertToTypeByName("6", "string"))) === true ? "visible" : "hidden")
		stateVars.isComp804552Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, (stateVars.TM_TopManagerDashboardLeadList !== undefined ? (stateVars.TM_TopManagerDashboardLeadList?.length > 0 ? stateVars.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null) : (this.state.TM_TopManagerDashboardLeadList?.length > 0 ? this.state.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null))), ReactSystemFunctions.convertToTypeByName("6", "string"))) === true ? "visible" : "hidden")
		stateVars.isComp371503Visible = ((ReactSystemFunctions.isNotEqualTo(ReactSystemFunctions.value(this, (stateVars.TM_TopManagerDashboardLeadList !== undefined ? (stateVars.TM_TopManagerDashboardLeadList?.length > 0 ? stateVars.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null) : (this.state.TM_TopManagerDashboardLeadList?.length > 0 ? this.state.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null))), ReactSystemFunctions.convertToTypeByName("7", "string"))) === true ? "visible" : "hidden")
		stateVars.isComp698275Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, (stateVars.TM_TopManagerDashboardLeadList !== undefined ? (stateVars.TM_TopManagerDashboardLeadList?.length > 0 ? stateVars.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null) : (this.state.TM_TopManagerDashboardLeadList?.length > 0 ? this.state.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null))), ReactSystemFunctions.convertToTypeByName("7", "string"))) === true ? "visible" : "hidden")
		stateVars.TM_GetProductCategory = result?.data.tM_GetProductCategory;
		
		formVars.dashboardtempmanager_731364_options = stateVars.TM_GetProductCategory;
		stateVars.TM_GetStore = result?.data.tM_GetStore;
		
		formVars.dashboardtempmanager_453042_options = stateVars.TM_GetStore;
		stateVars.TM_GetSalesPerson = result?.data.tM_GetSalesPerson;
		
		formVars.dashboardtempmanager_425161_options = stateVars.TM_GetSalesPerson;
		stateVars.TM_GetLeadStatus = result?.data.tM_GetLeadStatus;
		stateVars.TM_GetLeadProcess = result?.data.tM_GetLeadProcess;
		
		formVars.dashboardtempmanager_274478_options = stateVars.TM_GetLeadProcess;
		stateVars.TM_GetUserStoreInfo = result?.data.tM_GetUserStoreInfo;
		stateVars.TM_UserRoleByUserId = result?.data.tM_UserRoleByUserId;
		formVars.dashboardtempmanager_83734_value = ReactSystemFunctions.toString(this, (stateVars.TM_UserRoleByUserId !== undefined ? (stateVars.TM_UserRoleByUserId?.length > 0 ? stateVars.TM_UserRoleByUserId[0].roleNames : null) : (this.state.TM_UserRoleByUserId?.length > 0 ? this.state.TM_UserRoleByUserId[0].roleNames : null)));
		stateVars.TM_LeadProcessCountGrafik = result?.data.tM_LeadProcessCountGrafik;
		
		stateVars.TM_CategoryGrafik = result?.data.tM_CategoryGrafik;
		
		stateVars.TM_SatisDonusumGrafik = result?.data.tM_SatisDonusumGrafik;
		formVars.dashboardtempmanager_928779_value = ReactSystemFunctions.toString(this, (stateVars.TM_SatisDonusumGrafik !== undefined ? (stateVars.TM_SatisDonusumGrafik?.length > 0 ? stateVars.TM_SatisDonusumGrafik[0].donusumOrani : null) : (this.state.TM_SatisDonusumGrafik?.length > 0 ? this.state.TM_SatisDonusumGrafik[0].donusumOrani : null)));
		formVars.dashboardtempmanager_94650_percent = ReactSystemFunctions.value(this, (stateVars.TM_SatisDonusumGrafik !== undefined ? (stateVars.TM_SatisDonusumGrafik?.length > 0 ? stateVars.TM_SatisDonusumGrafik[0].donusumOrani : null) : (this.state.TM_SatisDonusumGrafik?.length > 0 ? this.state.TM_SatisDonusumGrafik[0].donusumOrani : null)));
		stateVars.TM_GetSalesExchangesRate = result?.data.tM_GetSalesExchangesRate;
		
		this.props.form?.setFieldsValue(formVars);
		
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.DashBoardTempManagerPageInit1_();
                  resolve();
                });
          })



        
        KuikaAppManager.hideSpinner(this);
        return isErrorOccurred;
    }
	DashBoardTempManagerPageInit1_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


	if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }

			formVars.dashboardtempmanager_83734_value = ReactSystemFunctions.toString(this, (stateVars.TM_UserRoleByUserId !== undefined ? (stateVars.TM_UserRoleByUserId?.length > 0 ? stateVars.TM_UserRoleByUserId[0].roleNames : null) : (this.state.TM_UserRoleByUserId?.length > 0 ? this.state.TM_UserRoleByUserId[0].roleNames : null)));

			
			stateVars.dataSource_392247 = stateVars.TM_GetSalesExchangesRate ?? this.state.TM_GetSalesExchangesRate;
			formVars.dashboardtempmanager_975657_value = ReactSystemFunctions.toString(this, (stateVars.TM_TopManagerDashSummary !== undefined ? (stateVars.TM_TopManagerDashSummary?.length > 0 ? stateVars.TM_TopManagerDashSummary[0].activeLead : null) : (this.state.TM_TopManagerDashSummary?.length > 0 ? this.state.TM_TopManagerDashSummary[0].activeLead : null)));

			formVars.dashboardtempmanager_759366_value = ReactSystemFunctions.toString(this, (stateVars.TM_TopManagerDashSummary !== undefined ? (stateVars.TM_TopManagerDashSummary?.length > 0 ? stateVars.TM_TopManagerDashSummary[0].buAyinTerminleri : null) : (this.state.TM_TopManagerDashSummary?.length > 0 ? this.state.TM_TopManagerDashSummary[0].buAyinTerminleri : null)));

			formVars.dashboardtempmanager_933641_value = ReactSystemFunctions.toString(this, (stateVars.TM_TopManagerDashSummary !== undefined ? (stateVars.TM_TopManagerDashSummary?.length > 0 ? stateVars.TM_TopManagerDashSummary[0].gecikenTerminler : null) : (this.state.TM_TopManagerDashSummary?.length > 0 ? this.state.TM_TopManagerDashSummary[0].gecikenTerminler : null)));

			formVars.dashboardtempmanager_97977_value = ReactSystemFunctions.toString(this, (stateVars.TM_TopManagerDashSummary !== undefined ? (stateVars.TM_TopManagerDashSummary?.length > 0 ? stateVars.TM_TopManagerDashSummary[0].onayBekleyenler : null) : (this.state.TM_TopManagerDashSummary?.length > 0 ? this.state.TM_TopManagerDashSummary[0].onayBekleyenler : null)));

			formVars.dashboardtempmanager_744058_value = ReactSystemFunctions.toString(this, (stateVars.TM_TopManagerDashSummary !== undefined ? (stateVars.TM_TopManagerDashSummary?.length > 0 ? stateVars.TM_TopManagerDashSummary[0].rezervOnayBekleyenler : null) : (this.state.TM_TopManagerDashSummary?.length > 0 ? this.state.TM_TopManagerDashSummary[0].rezervOnayBekleyenler : null)));

			formVars.dashboardtempmanager_201486_value = ReactSystemFunctions.toString(this, (stateVars.TM_TopManagerDashSummary !== undefined ? (stateVars.TM_TopManagerDashSummary?.length > 0 ? stateVars.TM_TopManagerDashSummary[0].satisBekleyenler : null) : (this.state.TM_TopManagerDashSummary?.length > 0 ? this.state.TM_TopManagerDashSummary[0].satisBekleyenler : null)));

			formVars.dashboardtempmanager_274863_value = ReactSystemFunctions.toString(this, (stateVars.TM_TopManagerDashSummary !== undefined ? (stateVars.TM_TopManagerDashSummary?.length > 0 ? stateVars.TM_TopManagerDashSummary[0].satisiYapilanlar : null) : (this.state.TM_TopManagerDashSummary?.length > 0 ? this.state.TM_TopManagerDashSummary[0].satisiYapilanlar : null)));

			formVars.dashboardtempmanager_926490_value = ReactSystemFunctions.toString(this, (stateVars.TM_TopManagerDashSummary !== undefined ? (stateVars.TM_TopManagerDashSummary?.length > 0 ? stateVars.TM_TopManagerDashSummary[0].musteriIstemedi : null) : (this.state.TM_TopManagerDashSummary?.length > 0 ? this.state.TM_TopManagerDashSummary[0].musteriIstemedi : null)));

			formVars.dashboardtempmanager_292258_value = ReactSystemFunctions.toString(this, (stateVars.TM_TopManagerDashSummary !== undefined ? (stateVars.TM_TopManagerDashSummary?.length > 0 ? stateVars.TM_TopManagerDashSummary[0].gecikenLeadler : null) : (this.state.TM_TopManagerDashSummary?.length > 0 ? this.state.TM_TopManagerDashSummary[0].gecikenLeadler : null)));

			formVars.dashboardtempmanager_299556_value = ReactSystemFunctions.toString(this, (stateVars.TM_TopManagerDashboardAnalysis !== undefined ? (stateVars.TM_TopManagerDashboardAnalysis?.length > 0 ? stateVars.TM_TopManagerDashboardAnalysis[0].bestSalesPerson : null) : (this.state.TM_TopManagerDashboardAnalysis?.length > 0 ? this.state.TM_TopManagerDashboardAnalysis[0].bestSalesPerson : null)));

			formVars.dashboardtempmanager_652231_percent = ReactSystemFunctions.value(this, (stateVars.TM_TopManagerDashboardAnalysis !== undefined ? (stateVars.TM_TopManagerDashboardAnalysis?.length > 0 ? stateVars.TM_TopManagerDashboardAnalysis[0].personConversionRate : null) : (this.state.TM_TopManagerDashboardAnalysis?.length > 0 ? this.state.TM_TopManagerDashboardAnalysis[0].personConversionRate : null)));

			formVars.dashboardtempmanager_128340_value = ReactSystemFunctions.toString(this, (stateVars.TM_TopManagerDashboardAnalysis !== undefined ? (stateVars.TM_TopManagerDashboardAnalysis?.length > 0 ? stateVars.TM_TopManagerDashboardAnalysis[0].bestStore : null) : (this.state.TM_TopManagerDashboardAnalysis?.length > 0 ? this.state.TM_TopManagerDashboardAnalysis[0].bestStore : null)));

			formVars.dashboardtempmanager_989995_percent = ReactSystemFunctions.value(this, (stateVars.TM_TopManagerDashboardAnalysis !== undefined ? (stateVars.TM_TopManagerDashboardAnalysis?.length > 0 ? stateVars.TM_TopManagerDashboardAnalysis[0].storeConversionRate : null) : (this.state.TM_TopManagerDashboardAnalysis?.length > 0 ? this.state.TM_TopManagerDashboardAnalysis[0].storeConversionRate : null)));

			
			stateVars.dataSource_75145 = stateVars.TMGetDashboardStoreManagerTaskList ?? this.state.TMGetDashboardStoreManagerTaskList;
			stateVars.isComp259947Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, "dashboardtempmanager_75145_value", "categoryName"), ReactSystemFunctions.convertToTypeByName("Kategori 2", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp555357Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, "dashboardtempmanager_75145_value", "categoryName"), ReactSystemFunctions.convertToTypeByName("Kategori 1", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp350848Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, "dashboardtempmanager_75145_value", "categoryName"), ReactSystemFunctions.convertToTypeByName("DEFAULT", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp793422Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, "dashboardtempmanager_75145_value", "categoryName"), ReactSystemFunctions.convertToTypeByName("Kategori 3", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp438978Visible = (((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, "dashboardtempmanager_75145_value", "processCode"), ReactSystemFunctions.convertToTypeByName("PENDING", "string")) || ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, "dashboardtempmanager_75145_value", "processCode"), ReactSystemFunctions.convertToTypeByName("TERMIN_PENDING", "string")) || ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, "dashboardtempmanager_75145_value", "processCode"), ReactSystemFunctions.convertToTypeByName("DELIVERY_PENDING", "string")))) === true ? "visible" : "hidden")
			stateVars.isComp833206Visible = (((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, "dashboardtempmanager_75145_value", "processCode"), ReactSystemFunctions.convertToTypeByName("CUSTOMER_DECLINED", "string")) || ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, "dashboardtempmanager_75145_value", "processCode"), ReactSystemFunctions.convertToTypeByName("REJECTED", "string")))) === true ? "visible" : "hidden")
			stateVars.isComp10051Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, "dashboardtempmanager_75145_value", "processCode"), ReactSystemFunctions.convertToTypeByName("DELIVERED", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp812626Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, "dashboardtempmanager_75145_value", "processCode"), ReactSystemFunctions.convertToTypeByName("CLOSED", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp853889Visible = (((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, "dashboardtempmanager_75145_value", "processCode"), ReactSystemFunctions.convertToTypeByName("APPROVED", "string")) || ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, "dashboardtempmanager_75145_value", "processCode"), ReactSystemFunctions.convertToTypeByName("CREATED", "string")))) === true ? "visible" : "hidden")
			stateVars.isComp142402Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, "dashboardtempmanager_75145_value", "actionCode"), ReactSystemFunctions.convertToTypeByName("APPROVE_RESERVATION", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp373351Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, "dashboardtempmanager_75145_value", "actionCode"), ReactSystemFunctions.convertToTypeByName("COMPLETE_SALE", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp621790Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, "dashboardtempmanager_75145_value", "actionCode"), ReactSystemFunctions.convertToTypeByName("SET_ESTIMATE", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp296871Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, "dashboardtempmanager_75145_value", "actionCode"), ReactSystemFunctions.convertToTypeByName("SEND_ESTIMATE_REQUEST", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp11830Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, "dashboardtempmanager_75145_value", "actionCode"), ReactSystemFunctions.convertToTypeByName("DIRECT_RESERVE", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp508013Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, "dashboardtempmanager_75145_value", "actionCode"), ReactSystemFunctions.convertToTypeByName("SEND_RESERVATION_REQUEST", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp20059Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, (stateVars.TM_TopManagerDashboardLeadList !== undefined ? (stateVars.TM_TopManagerDashboardLeadList?.length > 0 ? stateVars.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null) : (this.state.TM_TopManagerDashboardLeadList?.length > 0 ? this.state.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null))), ReactSystemFunctions.convertToTypeByName("0", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp693403Visible = ((ReactSystemFunctions.isNotEqualTo(ReactSystemFunctions.value(this, (stateVars.TM_TopManagerDashboardLeadList !== undefined ? (stateVars.TM_TopManagerDashboardLeadList?.length > 0 ? stateVars.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null) : (this.state.TM_TopManagerDashboardLeadList?.length > 0 ? this.state.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null))), ReactSystemFunctions.convertToTypeByName("0", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp77242Visible = ((ReactSystemFunctions.isNotEqualTo(ReactSystemFunctions.value(this, (stateVars.TM_TopManagerDashboardLeadList !== undefined ? (stateVars.TM_TopManagerDashboardLeadList?.length > 0 ? stateVars.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null) : (this.state.TM_TopManagerDashboardLeadList?.length > 0 ? this.state.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null))), ReactSystemFunctions.convertToTypeByName("-1", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp352710Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, (stateVars.TM_TopManagerDashboardLeadList !== undefined ? (stateVars.TM_TopManagerDashboardLeadList?.length > 0 ? stateVars.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null) : (this.state.TM_TopManagerDashboardLeadList?.length > 0 ? this.state.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null))), ReactSystemFunctions.convertToTypeByName("-1", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp744094Visible = ((ReactSystemFunctions.isNotEqualTo(ReactSystemFunctions.value(this, (stateVars.TM_TopManagerDashboardLeadList !== undefined ? (stateVars.TM_TopManagerDashboardLeadList?.length > 0 ? stateVars.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null) : (this.state.TM_TopManagerDashboardLeadList?.length > 0 ? this.state.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null))), ReactSystemFunctions.convertToTypeByName("-2", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp558447Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, (stateVars.TM_TopManagerDashboardLeadList !== undefined ? (stateVars.TM_TopManagerDashboardLeadList?.length > 0 ? stateVars.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null) : (this.state.TM_TopManagerDashboardLeadList?.length > 0 ? this.state.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null))), ReactSystemFunctions.convertToTypeByName("-2", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp551457Visible = ((ReactSystemFunctions.isNotEqualTo(ReactSystemFunctions.value(this, (stateVars.TM_TopManagerDashboardLeadList !== undefined ? (stateVars.TM_TopManagerDashboardLeadList?.length > 0 ? stateVars.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null) : (this.state.TM_TopManagerDashboardLeadList?.length > 0 ? this.state.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null))), ReactSystemFunctions.convertToTypeByName("-3", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp862838Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, (stateVars.TM_TopManagerDashboardLeadList !== undefined ? (stateVars.TM_TopManagerDashboardLeadList?.length > 0 ? stateVars.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null) : (this.state.TM_TopManagerDashboardLeadList?.length > 0 ? this.state.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null))), ReactSystemFunctions.convertToTypeByName("-3", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp4159Visible = ((ReactSystemFunctions.isNotEqualTo(ReactSystemFunctions.value(this, (stateVars.TM_TopManagerDashboardLeadList !== undefined ? (stateVars.TM_TopManagerDashboardLeadList?.length > 0 ? stateVars.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null) : (this.state.TM_TopManagerDashboardLeadList?.length > 0 ? this.state.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null))), ReactSystemFunctions.convertToTypeByName("2", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp170471Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, (stateVars.TM_TopManagerDashboardLeadList !== undefined ? (stateVars.TM_TopManagerDashboardLeadList?.length > 0 ? stateVars.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null) : (this.state.TM_TopManagerDashboardLeadList?.length > 0 ? this.state.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null))), ReactSystemFunctions.convertToTypeByName("2", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp397882Visible = ((ReactSystemFunctions.isNotEqualTo(ReactSystemFunctions.value(this, (stateVars.TM_TopManagerDashboardLeadList !== undefined ? (stateVars.TM_TopManagerDashboardLeadList?.length > 0 ? stateVars.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null) : (this.state.TM_TopManagerDashboardLeadList?.length > 0 ? this.state.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null))), ReactSystemFunctions.convertToTypeByName("3", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp941736Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, (stateVars.TM_TopManagerDashboardLeadList !== undefined ? (stateVars.TM_TopManagerDashboardLeadList?.length > 0 ? stateVars.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null) : (this.state.TM_TopManagerDashboardLeadList?.length > 0 ? this.state.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null))), ReactSystemFunctions.convertToTypeByName("3", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp489263Visible = ((ReactSystemFunctions.isNotEqualTo(ReactSystemFunctions.value(this, (stateVars.TM_TopManagerDashboardLeadList !== undefined ? (stateVars.TM_TopManagerDashboardLeadList?.length > 0 ? stateVars.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null) : (this.state.TM_TopManagerDashboardLeadList?.length > 0 ? this.state.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null))), ReactSystemFunctions.convertToTypeByName("10", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp675337Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, (stateVars.TM_TopManagerDashboardLeadList !== undefined ? (stateVars.TM_TopManagerDashboardLeadList?.length > 0 ? stateVars.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null) : (this.state.TM_TopManagerDashboardLeadList?.length > 0 ? this.state.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null))), ReactSystemFunctions.convertToTypeByName("10", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp654813Visible = ((ReactSystemFunctions.isNotEqualTo(ReactSystemFunctions.value(this, (stateVars.TM_TopManagerDashboardLeadList !== undefined ? (stateVars.TM_TopManagerDashboardLeadList?.length > 0 ? stateVars.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null) : (this.state.TM_TopManagerDashboardLeadList?.length > 0 ? this.state.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null))), ReactSystemFunctions.convertToTypeByName("6", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp804552Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, (stateVars.TM_TopManagerDashboardLeadList !== undefined ? (stateVars.TM_TopManagerDashboardLeadList?.length > 0 ? stateVars.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null) : (this.state.TM_TopManagerDashboardLeadList?.length > 0 ? this.state.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null))), ReactSystemFunctions.convertToTypeByName("6", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp371503Visible = ((ReactSystemFunctions.isNotEqualTo(ReactSystemFunctions.value(this, (stateVars.TM_TopManagerDashboardLeadList !== undefined ? (stateVars.TM_TopManagerDashboardLeadList?.length > 0 ? stateVars.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null) : (this.state.TM_TopManagerDashboardLeadList?.length > 0 ? this.state.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null))), ReactSystemFunctions.convertToTypeByName("7", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp698275Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, (stateVars.TM_TopManagerDashboardLeadList !== undefined ? (stateVars.TM_TopManagerDashboardLeadList?.length > 0 ? stateVars.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null) : (this.state.TM_TopManagerDashboardLeadList?.length > 0 ? this.state.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null))), ReactSystemFunctions.convertToTypeByName("7", "string"))) === true ? "visible" : "hidden")
			
			stateVars.dataSource_731364 = stateVars.TM_GetProductCategory ?? this.state.TM_GetProductCategory;
			stateVars.dataSource_731364 = stateVars.TM_GetProductCategory ?? this.state.TM_GetProductCategory;
			
			stateVars.dataSource_453042 = stateVars.TM_GetStore ?? this.state.TM_GetStore;
			stateVars.dataSource_453042 = stateVars.TM_GetStore ?? this.state.TM_GetStore;
			
			stateVars.dataSource_425161 = stateVars.TM_GetSalesPerson ?? this.state.TM_GetSalesPerson;
			stateVars.dataSource_425161 = stateVars.TM_GetSalesPerson ?? this.state.TM_GetSalesPerson;
			
			stateVars.dataSource_274478 = stateVars.TM_GetLeadProcess ?? this.state.TM_GetLeadProcess;
			stateVars.dataSource_274478 = stateVars.TM_GetLeadProcess ?? this.state.TM_GetLeadProcess;
			
			stateVars.dataSource_827135 = stateVars.TM_TopManagerDashboardLeadList ?? this.state.TM_TopManagerDashboardLeadList;
			stateVars.isComp663057Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, "dashboardtempmanager_827135_value", "categoryName"), ReactSystemFunctions.convertToTypeByName("Kategori 2", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp864312Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, "dashboardtempmanager_827135_value", "categoryName"), ReactSystemFunctions.convertToTypeByName("Kategori 1", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp494064Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, "dashboardtempmanager_827135_value", "categoryName"), ReactSystemFunctions.convertToTypeByName("DEFAULT", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp855947Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, "dashboardtempmanager_827135_value", "categoryName"), ReactSystemFunctions.convertToTypeByName("Kategori 3", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp841562Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, "dashboardtempmanager_827135_value", "leadDurumu"), ReactSystemFunctions.convertToTypeByName("Takip ediliyor", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp520053Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, "dashboardtempmanager_827135_value", "leadDurumu"), ReactSystemFunctions.convertToTypeByName("2. Takip", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp295368Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, "dashboardtempmanager_827135_value", "rezerveDurumu"), ReactSystemFunctions.convertToTypeByName("Evet", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp230659Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, "dashboardtempmanager_827135_value", "rezerveDurumu"), ReactSystemFunctions.convertToTypeByName("Hayır", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp538553Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, "dashboardtempmanager_827135_value", "rezerveDurumu"), ReactSystemFunctions.convertToTypeByName("Onay Bekliyor", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp273129Visible = (((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, "dashboardtempmanager_827135_value", "processCode"), ReactSystemFunctions.convertToTypeByName("PENDING", "string")) || ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, "dashboardtempmanager_827135_value", "processCode"), ReactSystemFunctions.convertToTypeByName("TERMIN_PENDING", "string")) || ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, "dashboardtempmanager_827135_value", "processCode"), ReactSystemFunctions.convertToTypeByName("DELIVERY_PENDING", "string")))) === true ? "visible" : "hidden")
			stateVars.isComp356733Visible = (((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, "dashboardtempmanager_827135_value", "processCode"), ReactSystemFunctions.convertToTypeByName("CUSTOMER_DECLINED", "string")) || ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, "dashboardtempmanager_827135_value", "processCode"), ReactSystemFunctions.convertToTypeByName("REJECTED", "string")))) === true ? "visible" : "hidden")
			stateVars.isComp508867Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, "dashboardtempmanager_827135_value", "processCode"), ReactSystemFunctions.convertToTypeByName("DELIVERED", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp282096Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, "dashboardtempmanager_827135_value", "processCode"), ReactSystemFunctions.convertToTypeByName("CLOSED", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp326896Visible = (((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, "dashboardtempmanager_827135_value", "processCode"), ReactSystemFunctions.convertToTypeByName("APPROVED", "string")) || ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, "dashboardtempmanager_827135_value", "processCode"), ReactSystemFunctions.convertToTypeByName("CREATED", "string")))) === true ? "visible" : "hidden")
			
			stateVars.dataSource_630260 = stateVars.TM_LeadProcessCountGrafik ?? this.state.TM_LeadProcessCountGrafik;
			
			stateVars.dataSource_730567 = stateVars.TM_CategoryGrafik ?? this.state.TM_CategoryGrafik;
			formVars.dashboardtempmanager_928779_value = ReactSystemFunctions.toString(this, (stateVars.TM_SatisDonusumGrafik !== undefined ? (stateVars.TM_SatisDonusumGrafik?.length > 0 ? stateVars.TM_SatisDonusumGrafik[0].donusumOrani : null) : (this.state.TM_SatisDonusumGrafik?.length > 0 ? this.state.TM_SatisDonusumGrafik[0].donusumOrani : null)));

			formVars.dashboardtempmanager_94650_percent = ReactSystemFunctions.value(this, (stateVars.TM_SatisDonusumGrafik !== undefined ? (stateVars.TM_SatisDonusumGrafik?.length > 0 ? stateVars.TM_SatisDonusumGrafik[0].donusumOrani : null) : (this.state.TM_SatisDonusumGrafik?.length > 0 ? this.state.TM_SatisDonusumGrafik[0].donusumOrani : null)));


	this.props.form?.setFieldsValue(formVars);
	this.setState(stateVars);
	KuikaAppManager.hideSpinner(this);

            this.setPageInitLoaded(true);
            return isErrorOccurred;
        }




    DashBoardTempManagerComponent_783535_onClick = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
		KuikaAppManager.increaseServerRequestCount();

        let localVar = {
				UserId_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.getMyUserId(), "Guid"),
				MusteriAdi_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "dashboardtempmanager_666343_value", "value", "", "", "")), "string"),
				ProductName_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "dashboardtempmanager_153369_value", "value", "", "", "")), "string"),
				LeadCode_0: ReactSystemFunctions.convertToTypeByName(null, "string"),
				Tel_0: ReactSystemFunctions.convertToTypeByName(null, "string"),
				CategoryName_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "dashboardtempmanager_731364_value", "value", "TM_GetProductCategory", "categoryCode", "categoryName")), "string"),
				StoreIds_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "dashboardtempmanager_453042_value", "value", "TM_GetStore", "id", "id")), "string"),
				SatisDanismaniIds_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "dashboardtempmanager_425161_value", "value", "TM_GetSalesPerson", "kUserId", "kUserId")), "string"),
				ProcessCode_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "dashboardtempmanager_274478_value", "value", "TM_GetLeadProcess", "id", "code")), "string"),
				StepOrder_0: ReactSystemFunctions.convertToTypeByName(-1, "number"),
				StartDate_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "dashboardtempmanager_138929_value", "value", "", "", "")), "Date"),
				EndDate_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "dashboardtempmanager_381090_value", "value", "", "", "")), "Date")
        }

		KuikaAppManager.showSpinner(this);
		
        if (true) {
        KuikaAppManager.showSpinner(this);
        }
        let result = await KuikaAppManager.ApiRequest(this, "DashBoardTempManager/DashBoardTempManagerComponent_783535_onClick", localVar)
        if (!KMainFunctions.IsResStatus2XX(result)) return true;

			stateVars.TM_TopManagerDashboardLeadList = result?.data.tM_TopManagerDashboardLeadList;
			
			stateVars.isComp20059Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, (stateVars.TM_TopManagerDashboardLeadList !== undefined ? (stateVars.TM_TopManagerDashboardLeadList?.length > 0 ? stateVars.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null) : (this.state.TM_TopManagerDashboardLeadList?.length > 0 ? this.state.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null))), ReactSystemFunctions.convertToTypeByName("0", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp693403Visible = ((ReactSystemFunctions.isNotEqualTo(ReactSystemFunctions.value(this, (stateVars.TM_TopManagerDashboardLeadList !== undefined ? (stateVars.TM_TopManagerDashboardLeadList?.length > 0 ? stateVars.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null) : (this.state.TM_TopManagerDashboardLeadList?.length > 0 ? this.state.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null))), ReactSystemFunctions.convertToTypeByName("0", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp77242Visible = ((ReactSystemFunctions.isNotEqualTo(ReactSystemFunctions.value(this, (stateVars.TM_TopManagerDashboardLeadList !== undefined ? (stateVars.TM_TopManagerDashboardLeadList?.length > 0 ? stateVars.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null) : (this.state.TM_TopManagerDashboardLeadList?.length > 0 ? this.state.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null))), ReactSystemFunctions.convertToTypeByName("-1", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp352710Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, (stateVars.TM_TopManagerDashboardLeadList !== undefined ? (stateVars.TM_TopManagerDashboardLeadList?.length > 0 ? stateVars.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null) : (this.state.TM_TopManagerDashboardLeadList?.length > 0 ? this.state.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null))), ReactSystemFunctions.convertToTypeByName("-1", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp744094Visible = ((ReactSystemFunctions.isNotEqualTo(ReactSystemFunctions.value(this, (stateVars.TM_TopManagerDashboardLeadList !== undefined ? (stateVars.TM_TopManagerDashboardLeadList?.length > 0 ? stateVars.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null) : (this.state.TM_TopManagerDashboardLeadList?.length > 0 ? this.state.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null))), ReactSystemFunctions.convertToTypeByName("-2", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp558447Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, (stateVars.TM_TopManagerDashboardLeadList !== undefined ? (stateVars.TM_TopManagerDashboardLeadList?.length > 0 ? stateVars.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null) : (this.state.TM_TopManagerDashboardLeadList?.length > 0 ? this.state.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null))), ReactSystemFunctions.convertToTypeByName("-2", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp551457Visible = ((ReactSystemFunctions.isNotEqualTo(ReactSystemFunctions.value(this, (stateVars.TM_TopManagerDashboardLeadList !== undefined ? (stateVars.TM_TopManagerDashboardLeadList?.length > 0 ? stateVars.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null) : (this.state.TM_TopManagerDashboardLeadList?.length > 0 ? this.state.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null))), ReactSystemFunctions.convertToTypeByName("-3", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp862838Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, (stateVars.TM_TopManagerDashboardLeadList !== undefined ? (stateVars.TM_TopManagerDashboardLeadList?.length > 0 ? stateVars.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null) : (this.state.TM_TopManagerDashboardLeadList?.length > 0 ? this.state.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null))), ReactSystemFunctions.convertToTypeByName("-3", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp4159Visible = ((ReactSystemFunctions.isNotEqualTo(ReactSystemFunctions.value(this, (stateVars.TM_TopManagerDashboardLeadList !== undefined ? (stateVars.TM_TopManagerDashboardLeadList?.length > 0 ? stateVars.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null) : (this.state.TM_TopManagerDashboardLeadList?.length > 0 ? this.state.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null))), ReactSystemFunctions.convertToTypeByName("2", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp170471Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, (stateVars.TM_TopManagerDashboardLeadList !== undefined ? (stateVars.TM_TopManagerDashboardLeadList?.length > 0 ? stateVars.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null) : (this.state.TM_TopManagerDashboardLeadList?.length > 0 ? this.state.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null))), ReactSystemFunctions.convertToTypeByName("2", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp397882Visible = ((ReactSystemFunctions.isNotEqualTo(ReactSystemFunctions.value(this, (stateVars.TM_TopManagerDashboardLeadList !== undefined ? (stateVars.TM_TopManagerDashboardLeadList?.length > 0 ? stateVars.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null) : (this.state.TM_TopManagerDashboardLeadList?.length > 0 ? this.state.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null))), ReactSystemFunctions.convertToTypeByName("3", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp941736Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, (stateVars.TM_TopManagerDashboardLeadList !== undefined ? (stateVars.TM_TopManagerDashboardLeadList?.length > 0 ? stateVars.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null) : (this.state.TM_TopManagerDashboardLeadList?.length > 0 ? this.state.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null))), ReactSystemFunctions.convertToTypeByName("3", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp489263Visible = ((ReactSystemFunctions.isNotEqualTo(ReactSystemFunctions.value(this, (stateVars.TM_TopManagerDashboardLeadList !== undefined ? (stateVars.TM_TopManagerDashboardLeadList?.length > 0 ? stateVars.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null) : (this.state.TM_TopManagerDashboardLeadList?.length > 0 ? this.state.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null))), ReactSystemFunctions.convertToTypeByName("10", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp675337Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, (stateVars.TM_TopManagerDashboardLeadList !== undefined ? (stateVars.TM_TopManagerDashboardLeadList?.length > 0 ? stateVars.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null) : (this.state.TM_TopManagerDashboardLeadList?.length > 0 ? this.state.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null))), ReactSystemFunctions.convertToTypeByName("10", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp654813Visible = ((ReactSystemFunctions.isNotEqualTo(ReactSystemFunctions.value(this, (stateVars.TM_TopManagerDashboardLeadList !== undefined ? (stateVars.TM_TopManagerDashboardLeadList?.length > 0 ? stateVars.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null) : (this.state.TM_TopManagerDashboardLeadList?.length > 0 ? this.state.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null))), ReactSystemFunctions.convertToTypeByName("6", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp804552Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, (stateVars.TM_TopManagerDashboardLeadList !== undefined ? (stateVars.TM_TopManagerDashboardLeadList?.length > 0 ? stateVars.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null) : (this.state.TM_TopManagerDashboardLeadList?.length > 0 ? this.state.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null))), ReactSystemFunctions.convertToTypeByName("6", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp371503Visible = ((ReactSystemFunctions.isNotEqualTo(ReactSystemFunctions.value(this, (stateVars.TM_TopManagerDashboardLeadList !== undefined ? (stateVars.TM_TopManagerDashboardLeadList?.length > 0 ? stateVars.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null) : (this.state.TM_TopManagerDashboardLeadList?.length > 0 ? this.state.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null))), ReactSystemFunctions.convertToTypeByName("7", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp698275Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, (stateVars.TM_TopManagerDashboardLeadList !== undefined ? (stateVars.TM_TopManagerDashboardLeadList?.length > 0 ? stateVars.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null) : (this.state.TM_TopManagerDashboardLeadList?.length > 0 ? this.state.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null))), ReactSystemFunctions.convertToTypeByName("7", "string"))) === true ? "visible" : "hidden")
			this.props.form?.setFieldsValue(formVars);
			
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.DashBoardTempManagerComponent_783535_onClick1_();
                  resolve();
                });
          })



        
        KuikaAppManager.hideSpinner(this);
        return isErrorOccurred;
    }
		DashBoardTempManagerComponent_783535_onClick1_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }

				
				stateVars.dataSource_827135 = stateVars.TM_TopManagerDashboardLeadList ?? this.state.TM_TopManagerDashboardLeadList;

		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

            
            return isErrorOccurred;
        }




    DashBoardTempManagerComponent_758525_onClick = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
		KuikaAppManager.increaseServerRequestCount();

        let localVar = {
				UserId_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.getMyUserId(), "Guid"),
				MusteriAdi_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "dashboardtempmanager_666343_value", "value", "", "", "")), "string"),
				ProductName_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "dashboardtempmanager_153369_value", "value", "", "", "")), "string"),
				LeadCode_0: ReactSystemFunctions.convertToTypeByName(null, "string"),
				Tel_0: ReactSystemFunctions.convertToTypeByName(null, "string"),
				CategoryName_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "dashboardtempmanager_731364_value", "value", "TM_GetProductCategory", "categoryCode", "categoryName")), "string"),
				StoreIds_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "dashboardtempmanager_453042_value", "value", "TM_GetStore", "id", "id")), "string"),
				SatisDanismaniIds_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "dashboardtempmanager_425161_value", "value", "TM_GetSalesPerson", "kUserId", "kUserId")), "string"),
				ProcessCode_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "dashboardtempmanager_274478_value", "value", "TM_GetLeadProcess", "id", "code")), "string"),
				StepOrder_0: ReactSystemFunctions.convertToTypeByName(-4, "number"),
				StartDate_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "dashboardtempmanager_138929_value", "value", "", "", "")), "Date"),
				EndDate_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "dashboardtempmanager_381090_value", "value", "", "", "")), "Date")
        }

		KuikaAppManager.showSpinner(this);
		
        if (true) {
        KuikaAppManager.showSpinner(this);
        }
        let result = await KuikaAppManager.ApiRequest(this, "DashBoardTempManager/DashBoardTempManagerComponent_758525_onClick", localVar)
        if (!KMainFunctions.IsResStatus2XX(result)) return true;

			stateVars.TM_TopManagerDashboardLeadList = result?.data.tM_TopManagerDashboardLeadList;
			
			stateVars.isComp20059Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, (stateVars.TM_TopManagerDashboardLeadList !== undefined ? (stateVars.TM_TopManagerDashboardLeadList?.length > 0 ? stateVars.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null) : (this.state.TM_TopManagerDashboardLeadList?.length > 0 ? this.state.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null))), ReactSystemFunctions.convertToTypeByName("0", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp693403Visible = ((ReactSystemFunctions.isNotEqualTo(ReactSystemFunctions.value(this, (stateVars.TM_TopManagerDashboardLeadList !== undefined ? (stateVars.TM_TopManagerDashboardLeadList?.length > 0 ? stateVars.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null) : (this.state.TM_TopManagerDashboardLeadList?.length > 0 ? this.state.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null))), ReactSystemFunctions.convertToTypeByName("0", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp77242Visible = ((ReactSystemFunctions.isNotEqualTo(ReactSystemFunctions.value(this, (stateVars.TM_TopManagerDashboardLeadList !== undefined ? (stateVars.TM_TopManagerDashboardLeadList?.length > 0 ? stateVars.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null) : (this.state.TM_TopManagerDashboardLeadList?.length > 0 ? this.state.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null))), ReactSystemFunctions.convertToTypeByName("-1", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp352710Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, (stateVars.TM_TopManagerDashboardLeadList !== undefined ? (stateVars.TM_TopManagerDashboardLeadList?.length > 0 ? stateVars.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null) : (this.state.TM_TopManagerDashboardLeadList?.length > 0 ? this.state.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null))), ReactSystemFunctions.convertToTypeByName("-1", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp744094Visible = ((ReactSystemFunctions.isNotEqualTo(ReactSystemFunctions.value(this, (stateVars.TM_TopManagerDashboardLeadList !== undefined ? (stateVars.TM_TopManagerDashboardLeadList?.length > 0 ? stateVars.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null) : (this.state.TM_TopManagerDashboardLeadList?.length > 0 ? this.state.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null))), ReactSystemFunctions.convertToTypeByName("-2", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp558447Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, (stateVars.TM_TopManagerDashboardLeadList !== undefined ? (stateVars.TM_TopManagerDashboardLeadList?.length > 0 ? stateVars.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null) : (this.state.TM_TopManagerDashboardLeadList?.length > 0 ? this.state.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null))), ReactSystemFunctions.convertToTypeByName("-2", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp551457Visible = ((ReactSystemFunctions.isNotEqualTo(ReactSystemFunctions.value(this, (stateVars.TM_TopManagerDashboardLeadList !== undefined ? (stateVars.TM_TopManagerDashboardLeadList?.length > 0 ? stateVars.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null) : (this.state.TM_TopManagerDashboardLeadList?.length > 0 ? this.state.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null))), ReactSystemFunctions.convertToTypeByName("-3", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp862838Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, (stateVars.TM_TopManagerDashboardLeadList !== undefined ? (stateVars.TM_TopManagerDashboardLeadList?.length > 0 ? stateVars.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null) : (this.state.TM_TopManagerDashboardLeadList?.length > 0 ? this.state.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null))), ReactSystemFunctions.convertToTypeByName("-3", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp4159Visible = ((ReactSystemFunctions.isNotEqualTo(ReactSystemFunctions.value(this, (stateVars.TM_TopManagerDashboardLeadList !== undefined ? (stateVars.TM_TopManagerDashboardLeadList?.length > 0 ? stateVars.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null) : (this.state.TM_TopManagerDashboardLeadList?.length > 0 ? this.state.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null))), ReactSystemFunctions.convertToTypeByName("2", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp170471Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, (stateVars.TM_TopManagerDashboardLeadList !== undefined ? (stateVars.TM_TopManagerDashboardLeadList?.length > 0 ? stateVars.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null) : (this.state.TM_TopManagerDashboardLeadList?.length > 0 ? this.state.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null))), ReactSystemFunctions.convertToTypeByName("2", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp397882Visible = ((ReactSystemFunctions.isNotEqualTo(ReactSystemFunctions.value(this, (stateVars.TM_TopManagerDashboardLeadList !== undefined ? (stateVars.TM_TopManagerDashboardLeadList?.length > 0 ? stateVars.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null) : (this.state.TM_TopManagerDashboardLeadList?.length > 0 ? this.state.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null))), ReactSystemFunctions.convertToTypeByName("3", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp941736Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, (stateVars.TM_TopManagerDashboardLeadList !== undefined ? (stateVars.TM_TopManagerDashboardLeadList?.length > 0 ? stateVars.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null) : (this.state.TM_TopManagerDashboardLeadList?.length > 0 ? this.state.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null))), ReactSystemFunctions.convertToTypeByName("3", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp489263Visible = ((ReactSystemFunctions.isNotEqualTo(ReactSystemFunctions.value(this, (stateVars.TM_TopManagerDashboardLeadList !== undefined ? (stateVars.TM_TopManagerDashboardLeadList?.length > 0 ? stateVars.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null) : (this.state.TM_TopManagerDashboardLeadList?.length > 0 ? this.state.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null))), ReactSystemFunctions.convertToTypeByName("10", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp675337Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, (stateVars.TM_TopManagerDashboardLeadList !== undefined ? (stateVars.TM_TopManagerDashboardLeadList?.length > 0 ? stateVars.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null) : (this.state.TM_TopManagerDashboardLeadList?.length > 0 ? this.state.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null))), ReactSystemFunctions.convertToTypeByName("10", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp654813Visible = ((ReactSystemFunctions.isNotEqualTo(ReactSystemFunctions.value(this, (stateVars.TM_TopManagerDashboardLeadList !== undefined ? (stateVars.TM_TopManagerDashboardLeadList?.length > 0 ? stateVars.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null) : (this.state.TM_TopManagerDashboardLeadList?.length > 0 ? this.state.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null))), ReactSystemFunctions.convertToTypeByName("6", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp804552Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, (stateVars.TM_TopManagerDashboardLeadList !== undefined ? (stateVars.TM_TopManagerDashboardLeadList?.length > 0 ? stateVars.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null) : (this.state.TM_TopManagerDashboardLeadList?.length > 0 ? this.state.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null))), ReactSystemFunctions.convertToTypeByName("6", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp371503Visible = ((ReactSystemFunctions.isNotEqualTo(ReactSystemFunctions.value(this, (stateVars.TM_TopManagerDashboardLeadList !== undefined ? (stateVars.TM_TopManagerDashboardLeadList?.length > 0 ? stateVars.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null) : (this.state.TM_TopManagerDashboardLeadList?.length > 0 ? this.state.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null))), ReactSystemFunctions.convertToTypeByName("7", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp698275Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, (stateVars.TM_TopManagerDashboardLeadList !== undefined ? (stateVars.TM_TopManagerDashboardLeadList?.length > 0 ? stateVars.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null) : (this.state.TM_TopManagerDashboardLeadList?.length > 0 ? this.state.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null))), ReactSystemFunctions.convertToTypeByName("7", "string"))) === true ? "visible" : "hidden")
			this.props.form?.setFieldsValue(formVars);
			
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.DashBoardTempManagerComponent_758525_onClick1_();
                  resolve();
                });
          })



        
        KuikaAppManager.hideSpinner(this);
        return isErrorOccurred;
    }
		DashBoardTempManagerComponent_758525_onClick1_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }

				
				stateVars.dataSource_827135 = stateVars.TM_TopManagerDashboardLeadList ?? this.state.TM_TopManagerDashboardLeadList;

		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

            
            return isErrorOccurred;
        }




    DashBoardTempManagerComponent_398231_onClick = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
		KuikaAppManager.increaseServerRequestCount();

        let localVar = {
				UserId_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.getMyUserId(), "Guid"),
				MusteriAdi_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "dashboardtempmanager_666343_value", "value", "", "", "")), "string"),
				ProductName_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "dashboardtempmanager_153369_value", "value", "", "", "")), "string"),
				LeadCode_0: ReactSystemFunctions.convertToTypeByName(null, "string"),
				Tel_0: ReactSystemFunctions.convertToTypeByName(null, "string"),
				CategoryName_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "dashboardtempmanager_731364_value", "value", "TM_GetProductCategory", "categoryCode", "categoryName")), "string"),
				StoreIds_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "dashboardtempmanager_453042_value", "value", "TM_GetStore", "id", "id")), "string"),
				SatisDanismaniIds_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "dashboardtempmanager_425161_value", "value", "TM_GetSalesPerson", "kUserId", "kUserId")), "string"),
				ProcessCode_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "dashboardtempmanager_274478_value", "value", "TM_GetLeadProcess", "id", "code")), "string"),
				StepOrder_0: ReactSystemFunctions.convertToTypeByName(-3, "number"),
				StartDate_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "dashboardtempmanager_138929_value", "value", "", "", "")), "Date"),
				EndDate_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "dashboardtempmanager_381090_value", "value", "", "", "")), "Date")
        }

		KuikaAppManager.showSpinner(this);
		
        if (true) {
        KuikaAppManager.showSpinner(this);
        }
        let result = await KuikaAppManager.ApiRequest(this, "DashBoardTempManager/DashBoardTempManagerComponent_398231_onClick", localVar)
        if (!KMainFunctions.IsResStatus2XX(result)) return true;

			stateVars.TM_TopManagerDashboardLeadList = result?.data.tM_TopManagerDashboardLeadList;
			
			stateVars.isComp20059Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, (stateVars.TM_TopManagerDashboardLeadList !== undefined ? (stateVars.TM_TopManagerDashboardLeadList?.length > 0 ? stateVars.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null) : (this.state.TM_TopManagerDashboardLeadList?.length > 0 ? this.state.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null))), ReactSystemFunctions.convertToTypeByName("0", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp693403Visible = ((ReactSystemFunctions.isNotEqualTo(ReactSystemFunctions.value(this, (stateVars.TM_TopManagerDashboardLeadList !== undefined ? (stateVars.TM_TopManagerDashboardLeadList?.length > 0 ? stateVars.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null) : (this.state.TM_TopManagerDashboardLeadList?.length > 0 ? this.state.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null))), ReactSystemFunctions.convertToTypeByName("0", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp77242Visible = ((ReactSystemFunctions.isNotEqualTo(ReactSystemFunctions.value(this, (stateVars.TM_TopManagerDashboardLeadList !== undefined ? (stateVars.TM_TopManagerDashboardLeadList?.length > 0 ? stateVars.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null) : (this.state.TM_TopManagerDashboardLeadList?.length > 0 ? this.state.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null))), ReactSystemFunctions.convertToTypeByName("-1", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp352710Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, (stateVars.TM_TopManagerDashboardLeadList !== undefined ? (stateVars.TM_TopManagerDashboardLeadList?.length > 0 ? stateVars.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null) : (this.state.TM_TopManagerDashboardLeadList?.length > 0 ? this.state.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null))), ReactSystemFunctions.convertToTypeByName("-1", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp744094Visible = ((ReactSystemFunctions.isNotEqualTo(ReactSystemFunctions.value(this, (stateVars.TM_TopManagerDashboardLeadList !== undefined ? (stateVars.TM_TopManagerDashboardLeadList?.length > 0 ? stateVars.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null) : (this.state.TM_TopManagerDashboardLeadList?.length > 0 ? this.state.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null))), ReactSystemFunctions.convertToTypeByName("-2", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp558447Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, (stateVars.TM_TopManagerDashboardLeadList !== undefined ? (stateVars.TM_TopManagerDashboardLeadList?.length > 0 ? stateVars.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null) : (this.state.TM_TopManagerDashboardLeadList?.length > 0 ? this.state.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null))), ReactSystemFunctions.convertToTypeByName("-2", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp551457Visible = ((ReactSystemFunctions.isNotEqualTo(ReactSystemFunctions.value(this, (stateVars.TM_TopManagerDashboardLeadList !== undefined ? (stateVars.TM_TopManagerDashboardLeadList?.length > 0 ? stateVars.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null) : (this.state.TM_TopManagerDashboardLeadList?.length > 0 ? this.state.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null))), ReactSystemFunctions.convertToTypeByName("-3", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp862838Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, (stateVars.TM_TopManagerDashboardLeadList !== undefined ? (stateVars.TM_TopManagerDashboardLeadList?.length > 0 ? stateVars.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null) : (this.state.TM_TopManagerDashboardLeadList?.length > 0 ? this.state.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null))), ReactSystemFunctions.convertToTypeByName("-3", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp4159Visible = ((ReactSystemFunctions.isNotEqualTo(ReactSystemFunctions.value(this, (stateVars.TM_TopManagerDashboardLeadList !== undefined ? (stateVars.TM_TopManagerDashboardLeadList?.length > 0 ? stateVars.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null) : (this.state.TM_TopManagerDashboardLeadList?.length > 0 ? this.state.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null))), ReactSystemFunctions.convertToTypeByName("2", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp170471Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, (stateVars.TM_TopManagerDashboardLeadList !== undefined ? (stateVars.TM_TopManagerDashboardLeadList?.length > 0 ? stateVars.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null) : (this.state.TM_TopManagerDashboardLeadList?.length > 0 ? this.state.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null))), ReactSystemFunctions.convertToTypeByName("2", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp397882Visible = ((ReactSystemFunctions.isNotEqualTo(ReactSystemFunctions.value(this, (stateVars.TM_TopManagerDashboardLeadList !== undefined ? (stateVars.TM_TopManagerDashboardLeadList?.length > 0 ? stateVars.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null) : (this.state.TM_TopManagerDashboardLeadList?.length > 0 ? this.state.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null))), ReactSystemFunctions.convertToTypeByName("3", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp941736Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, (stateVars.TM_TopManagerDashboardLeadList !== undefined ? (stateVars.TM_TopManagerDashboardLeadList?.length > 0 ? stateVars.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null) : (this.state.TM_TopManagerDashboardLeadList?.length > 0 ? this.state.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null))), ReactSystemFunctions.convertToTypeByName("3", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp489263Visible = ((ReactSystemFunctions.isNotEqualTo(ReactSystemFunctions.value(this, (stateVars.TM_TopManagerDashboardLeadList !== undefined ? (stateVars.TM_TopManagerDashboardLeadList?.length > 0 ? stateVars.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null) : (this.state.TM_TopManagerDashboardLeadList?.length > 0 ? this.state.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null))), ReactSystemFunctions.convertToTypeByName("10", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp675337Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, (stateVars.TM_TopManagerDashboardLeadList !== undefined ? (stateVars.TM_TopManagerDashboardLeadList?.length > 0 ? stateVars.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null) : (this.state.TM_TopManagerDashboardLeadList?.length > 0 ? this.state.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null))), ReactSystemFunctions.convertToTypeByName("10", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp654813Visible = ((ReactSystemFunctions.isNotEqualTo(ReactSystemFunctions.value(this, (stateVars.TM_TopManagerDashboardLeadList !== undefined ? (stateVars.TM_TopManagerDashboardLeadList?.length > 0 ? stateVars.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null) : (this.state.TM_TopManagerDashboardLeadList?.length > 0 ? this.state.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null))), ReactSystemFunctions.convertToTypeByName("6", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp804552Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, (stateVars.TM_TopManagerDashboardLeadList !== undefined ? (stateVars.TM_TopManagerDashboardLeadList?.length > 0 ? stateVars.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null) : (this.state.TM_TopManagerDashboardLeadList?.length > 0 ? this.state.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null))), ReactSystemFunctions.convertToTypeByName("6", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp371503Visible = ((ReactSystemFunctions.isNotEqualTo(ReactSystemFunctions.value(this, (stateVars.TM_TopManagerDashboardLeadList !== undefined ? (stateVars.TM_TopManagerDashboardLeadList?.length > 0 ? stateVars.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null) : (this.state.TM_TopManagerDashboardLeadList?.length > 0 ? this.state.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null))), ReactSystemFunctions.convertToTypeByName("7", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp698275Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, (stateVars.TM_TopManagerDashboardLeadList !== undefined ? (stateVars.TM_TopManagerDashboardLeadList?.length > 0 ? stateVars.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null) : (this.state.TM_TopManagerDashboardLeadList?.length > 0 ? this.state.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null))), ReactSystemFunctions.convertToTypeByName("7", "string"))) === true ? "visible" : "hidden")
			this.props.form?.setFieldsValue(formVars);
			
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.DashBoardTempManagerComponent_398231_onClick1_();
                  resolve();
                });
          })



        
        KuikaAppManager.hideSpinner(this);
        return isErrorOccurred;
    }
		DashBoardTempManagerComponent_398231_onClick1_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }

				
				stateVars.dataSource_827135 = stateVars.TM_TopManagerDashboardLeadList ?? this.state.TM_TopManagerDashboardLeadList;

		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

            
            return isErrorOccurred;
        }




    DashBoardTempManagerComponent_892106_onClick = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
		KuikaAppManager.increaseServerRequestCount();

        let localVar = {
				UserId_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.getMyUserId(), "Guid"),
				MusteriAdi_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "dashboardtempmanager_666343_value", "value", "", "", "")), "string"),
				ProductName_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "dashboardtempmanager_153369_value", "value", "", "", "")), "string"),
				LeadCode_0: ReactSystemFunctions.convertToTypeByName(null, "string"),
				Tel_0: ReactSystemFunctions.convertToTypeByName(null, "string"),
				CategoryName_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "dashboardtempmanager_731364_value", "value", "TM_GetProductCategory", "categoryCode", "categoryName")), "string"),
				StoreIds_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "dashboardtempmanager_453042_value", "value", "TM_GetStore", "id", "id")), "string"),
				SatisDanismaniIds_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "dashboardtempmanager_425161_value", "value", "TM_GetSalesPerson", "kUserId", "kUserId")), "string"),
				ProcessCode_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "dashboardtempmanager_274478_value", "value", "TM_GetLeadProcess", "id", "code")), "string"),
				StepOrder_0: ReactSystemFunctions.convertToTypeByName(3, "number"),
				StartDate_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "dashboardtempmanager_138929_value", "value", "", "", "")), "Date"),
				EndDate_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "dashboardtempmanager_381090_value", "value", "", "", "")), "Date")
        }

		KuikaAppManager.showSpinner(this);
		
        if (true) {
        KuikaAppManager.showSpinner(this);
        }
        let result = await KuikaAppManager.ApiRequest(this, "DashBoardTempManager/DashBoardTempManagerComponent_892106_onClick", localVar)
        if (!KMainFunctions.IsResStatus2XX(result)) return true;

			stateVars.TM_TopManagerDashboardLeadList = result?.data.tM_TopManagerDashboardLeadList;
			
			stateVars.isComp20059Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, (stateVars.TM_TopManagerDashboardLeadList !== undefined ? (stateVars.TM_TopManagerDashboardLeadList?.length > 0 ? stateVars.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null) : (this.state.TM_TopManagerDashboardLeadList?.length > 0 ? this.state.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null))), ReactSystemFunctions.convertToTypeByName("0", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp693403Visible = ((ReactSystemFunctions.isNotEqualTo(ReactSystemFunctions.value(this, (stateVars.TM_TopManagerDashboardLeadList !== undefined ? (stateVars.TM_TopManagerDashboardLeadList?.length > 0 ? stateVars.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null) : (this.state.TM_TopManagerDashboardLeadList?.length > 0 ? this.state.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null))), ReactSystemFunctions.convertToTypeByName("0", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp77242Visible = ((ReactSystemFunctions.isNotEqualTo(ReactSystemFunctions.value(this, (stateVars.TM_TopManagerDashboardLeadList !== undefined ? (stateVars.TM_TopManagerDashboardLeadList?.length > 0 ? stateVars.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null) : (this.state.TM_TopManagerDashboardLeadList?.length > 0 ? this.state.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null))), ReactSystemFunctions.convertToTypeByName("-1", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp352710Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, (stateVars.TM_TopManagerDashboardLeadList !== undefined ? (stateVars.TM_TopManagerDashboardLeadList?.length > 0 ? stateVars.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null) : (this.state.TM_TopManagerDashboardLeadList?.length > 0 ? this.state.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null))), ReactSystemFunctions.convertToTypeByName("-1", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp744094Visible = ((ReactSystemFunctions.isNotEqualTo(ReactSystemFunctions.value(this, (stateVars.TM_TopManagerDashboardLeadList !== undefined ? (stateVars.TM_TopManagerDashboardLeadList?.length > 0 ? stateVars.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null) : (this.state.TM_TopManagerDashboardLeadList?.length > 0 ? this.state.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null))), ReactSystemFunctions.convertToTypeByName("-2", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp558447Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, (stateVars.TM_TopManagerDashboardLeadList !== undefined ? (stateVars.TM_TopManagerDashboardLeadList?.length > 0 ? stateVars.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null) : (this.state.TM_TopManagerDashboardLeadList?.length > 0 ? this.state.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null))), ReactSystemFunctions.convertToTypeByName("-2", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp551457Visible = ((ReactSystemFunctions.isNotEqualTo(ReactSystemFunctions.value(this, (stateVars.TM_TopManagerDashboardLeadList !== undefined ? (stateVars.TM_TopManagerDashboardLeadList?.length > 0 ? stateVars.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null) : (this.state.TM_TopManagerDashboardLeadList?.length > 0 ? this.state.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null))), ReactSystemFunctions.convertToTypeByName("-3", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp862838Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, (stateVars.TM_TopManagerDashboardLeadList !== undefined ? (stateVars.TM_TopManagerDashboardLeadList?.length > 0 ? stateVars.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null) : (this.state.TM_TopManagerDashboardLeadList?.length > 0 ? this.state.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null))), ReactSystemFunctions.convertToTypeByName("-3", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp4159Visible = ((ReactSystemFunctions.isNotEqualTo(ReactSystemFunctions.value(this, (stateVars.TM_TopManagerDashboardLeadList !== undefined ? (stateVars.TM_TopManagerDashboardLeadList?.length > 0 ? stateVars.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null) : (this.state.TM_TopManagerDashboardLeadList?.length > 0 ? this.state.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null))), ReactSystemFunctions.convertToTypeByName("2", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp170471Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, (stateVars.TM_TopManagerDashboardLeadList !== undefined ? (stateVars.TM_TopManagerDashboardLeadList?.length > 0 ? stateVars.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null) : (this.state.TM_TopManagerDashboardLeadList?.length > 0 ? this.state.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null))), ReactSystemFunctions.convertToTypeByName("2", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp397882Visible = ((ReactSystemFunctions.isNotEqualTo(ReactSystemFunctions.value(this, (stateVars.TM_TopManagerDashboardLeadList !== undefined ? (stateVars.TM_TopManagerDashboardLeadList?.length > 0 ? stateVars.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null) : (this.state.TM_TopManagerDashboardLeadList?.length > 0 ? this.state.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null))), ReactSystemFunctions.convertToTypeByName("3", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp941736Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, (stateVars.TM_TopManagerDashboardLeadList !== undefined ? (stateVars.TM_TopManagerDashboardLeadList?.length > 0 ? stateVars.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null) : (this.state.TM_TopManagerDashboardLeadList?.length > 0 ? this.state.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null))), ReactSystemFunctions.convertToTypeByName("3", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp489263Visible = ((ReactSystemFunctions.isNotEqualTo(ReactSystemFunctions.value(this, (stateVars.TM_TopManagerDashboardLeadList !== undefined ? (stateVars.TM_TopManagerDashboardLeadList?.length > 0 ? stateVars.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null) : (this.state.TM_TopManagerDashboardLeadList?.length > 0 ? this.state.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null))), ReactSystemFunctions.convertToTypeByName("10", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp675337Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, (stateVars.TM_TopManagerDashboardLeadList !== undefined ? (stateVars.TM_TopManagerDashboardLeadList?.length > 0 ? stateVars.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null) : (this.state.TM_TopManagerDashboardLeadList?.length > 0 ? this.state.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null))), ReactSystemFunctions.convertToTypeByName("10", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp654813Visible = ((ReactSystemFunctions.isNotEqualTo(ReactSystemFunctions.value(this, (stateVars.TM_TopManagerDashboardLeadList !== undefined ? (stateVars.TM_TopManagerDashboardLeadList?.length > 0 ? stateVars.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null) : (this.state.TM_TopManagerDashboardLeadList?.length > 0 ? this.state.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null))), ReactSystemFunctions.convertToTypeByName("6", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp804552Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, (stateVars.TM_TopManagerDashboardLeadList !== undefined ? (stateVars.TM_TopManagerDashboardLeadList?.length > 0 ? stateVars.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null) : (this.state.TM_TopManagerDashboardLeadList?.length > 0 ? this.state.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null))), ReactSystemFunctions.convertToTypeByName("6", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp371503Visible = ((ReactSystemFunctions.isNotEqualTo(ReactSystemFunctions.value(this, (stateVars.TM_TopManagerDashboardLeadList !== undefined ? (stateVars.TM_TopManagerDashboardLeadList?.length > 0 ? stateVars.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null) : (this.state.TM_TopManagerDashboardLeadList?.length > 0 ? this.state.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null))), ReactSystemFunctions.convertToTypeByName("7", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp698275Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, (stateVars.TM_TopManagerDashboardLeadList !== undefined ? (stateVars.TM_TopManagerDashboardLeadList?.length > 0 ? stateVars.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null) : (this.state.TM_TopManagerDashboardLeadList?.length > 0 ? this.state.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null))), ReactSystemFunctions.convertToTypeByName("7", "string"))) === true ? "visible" : "hidden")
			this.props.form?.setFieldsValue(formVars);
			
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.DashBoardTempManagerComponent_892106_onClick1_();
                  resolve();
                });
          })



        
        KuikaAppManager.hideSpinner(this);
        return isErrorOccurred;
    }
		DashBoardTempManagerComponent_892106_onClick1_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }

				
				stateVars.dataSource_827135 = stateVars.TM_TopManagerDashboardLeadList ?? this.state.TM_TopManagerDashboardLeadList;

		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

            
            return isErrorOccurred;
        }




    DashBoardTempManagerComponent_464762_onClick = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
		KuikaAppManager.increaseServerRequestCount();

        let localVar = {
				UserId_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.getMyUserId(), "Guid"),
				MusteriAdi_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "dashboardtempmanager_666343_value", "value", "", "", "")), "string"),
				ProductName_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "dashboardtempmanager_153369_value", "value", "", "", "")), "string"),
				LeadCode_0: ReactSystemFunctions.convertToTypeByName(null, "string"),
				Tel_0: ReactSystemFunctions.convertToTypeByName(null, "string"),
				CategoryName_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "dashboardtempmanager_731364_value", "value", "TM_GetProductCategory", "categoryCode", "categoryName")), "string"),
				StoreIds_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "dashboardtempmanager_453042_value", "value", "TM_GetStore", "id", "id")), "string"),
				SatisDanismaniIds_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "dashboardtempmanager_425161_value", "value", "TM_GetSalesPerson", "kUserId", "kUserId")), "string"),
				ProcessCode_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "dashboardtempmanager_274478_value", "value", "TM_GetLeadProcess", "id", "code")), "string"),
				StepOrder_0: ReactSystemFunctions.convertToTypeByName(10, "number"),
				StartDate_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "dashboardtempmanager_138929_value", "value", "", "", "")), "Date"),
				EndDate_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "dashboardtempmanager_381090_value", "value", "", "", "")), "Date")
        }

		KuikaAppManager.showSpinner(this);
		
        if (true) {
        KuikaAppManager.showSpinner(this);
        }
        let result = await KuikaAppManager.ApiRequest(this, "DashBoardTempManager/DashBoardTempManagerComponent_464762_onClick", localVar)
        if (!KMainFunctions.IsResStatus2XX(result)) return true;

			stateVars.TM_TopManagerDashboardLeadList = result?.data.tM_TopManagerDashboardLeadList;
			
			stateVars.isComp20059Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, (stateVars.TM_TopManagerDashboardLeadList !== undefined ? (stateVars.TM_TopManagerDashboardLeadList?.length > 0 ? stateVars.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null) : (this.state.TM_TopManagerDashboardLeadList?.length > 0 ? this.state.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null))), ReactSystemFunctions.convertToTypeByName("0", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp693403Visible = ((ReactSystemFunctions.isNotEqualTo(ReactSystemFunctions.value(this, (stateVars.TM_TopManagerDashboardLeadList !== undefined ? (stateVars.TM_TopManagerDashboardLeadList?.length > 0 ? stateVars.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null) : (this.state.TM_TopManagerDashboardLeadList?.length > 0 ? this.state.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null))), ReactSystemFunctions.convertToTypeByName("0", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp77242Visible = ((ReactSystemFunctions.isNotEqualTo(ReactSystemFunctions.value(this, (stateVars.TM_TopManagerDashboardLeadList !== undefined ? (stateVars.TM_TopManagerDashboardLeadList?.length > 0 ? stateVars.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null) : (this.state.TM_TopManagerDashboardLeadList?.length > 0 ? this.state.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null))), ReactSystemFunctions.convertToTypeByName("-1", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp352710Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, (stateVars.TM_TopManagerDashboardLeadList !== undefined ? (stateVars.TM_TopManagerDashboardLeadList?.length > 0 ? stateVars.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null) : (this.state.TM_TopManagerDashboardLeadList?.length > 0 ? this.state.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null))), ReactSystemFunctions.convertToTypeByName("-1", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp744094Visible = ((ReactSystemFunctions.isNotEqualTo(ReactSystemFunctions.value(this, (stateVars.TM_TopManagerDashboardLeadList !== undefined ? (stateVars.TM_TopManagerDashboardLeadList?.length > 0 ? stateVars.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null) : (this.state.TM_TopManagerDashboardLeadList?.length > 0 ? this.state.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null))), ReactSystemFunctions.convertToTypeByName("-2", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp558447Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, (stateVars.TM_TopManagerDashboardLeadList !== undefined ? (stateVars.TM_TopManagerDashboardLeadList?.length > 0 ? stateVars.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null) : (this.state.TM_TopManagerDashboardLeadList?.length > 0 ? this.state.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null))), ReactSystemFunctions.convertToTypeByName("-2", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp551457Visible = ((ReactSystemFunctions.isNotEqualTo(ReactSystemFunctions.value(this, (stateVars.TM_TopManagerDashboardLeadList !== undefined ? (stateVars.TM_TopManagerDashboardLeadList?.length > 0 ? stateVars.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null) : (this.state.TM_TopManagerDashboardLeadList?.length > 0 ? this.state.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null))), ReactSystemFunctions.convertToTypeByName("-3", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp862838Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, (stateVars.TM_TopManagerDashboardLeadList !== undefined ? (stateVars.TM_TopManagerDashboardLeadList?.length > 0 ? stateVars.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null) : (this.state.TM_TopManagerDashboardLeadList?.length > 0 ? this.state.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null))), ReactSystemFunctions.convertToTypeByName("-3", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp4159Visible = ((ReactSystemFunctions.isNotEqualTo(ReactSystemFunctions.value(this, (stateVars.TM_TopManagerDashboardLeadList !== undefined ? (stateVars.TM_TopManagerDashboardLeadList?.length > 0 ? stateVars.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null) : (this.state.TM_TopManagerDashboardLeadList?.length > 0 ? this.state.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null))), ReactSystemFunctions.convertToTypeByName("2", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp170471Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, (stateVars.TM_TopManagerDashboardLeadList !== undefined ? (stateVars.TM_TopManagerDashboardLeadList?.length > 0 ? stateVars.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null) : (this.state.TM_TopManagerDashboardLeadList?.length > 0 ? this.state.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null))), ReactSystemFunctions.convertToTypeByName("2", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp397882Visible = ((ReactSystemFunctions.isNotEqualTo(ReactSystemFunctions.value(this, (stateVars.TM_TopManagerDashboardLeadList !== undefined ? (stateVars.TM_TopManagerDashboardLeadList?.length > 0 ? stateVars.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null) : (this.state.TM_TopManagerDashboardLeadList?.length > 0 ? this.state.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null))), ReactSystemFunctions.convertToTypeByName("3", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp941736Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, (stateVars.TM_TopManagerDashboardLeadList !== undefined ? (stateVars.TM_TopManagerDashboardLeadList?.length > 0 ? stateVars.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null) : (this.state.TM_TopManagerDashboardLeadList?.length > 0 ? this.state.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null))), ReactSystemFunctions.convertToTypeByName("3", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp489263Visible = ((ReactSystemFunctions.isNotEqualTo(ReactSystemFunctions.value(this, (stateVars.TM_TopManagerDashboardLeadList !== undefined ? (stateVars.TM_TopManagerDashboardLeadList?.length > 0 ? stateVars.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null) : (this.state.TM_TopManagerDashboardLeadList?.length > 0 ? this.state.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null))), ReactSystemFunctions.convertToTypeByName("10", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp675337Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, (stateVars.TM_TopManagerDashboardLeadList !== undefined ? (stateVars.TM_TopManagerDashboardLeadList?.length > 0 ? stateVars.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null) : (this.state.TM_TopManagerDashboardLeadList?.length > 0 ? this.state.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null))), ReactSystemFunctions.convertToTypeByName("10", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp654813Visible = ((ReactSystemFunctions.isNotEqualTo(ReactSystemFunctions.value(this, (stateVars.TM_TopManagerDashboardLeadList !== undefined ? (stateVars.TM_TopManagerDashboardLeadList?.length > 0 ? stateVars.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null) : (this.state.TM_TopManagerDashboardLeadList?.length > 0 ? this.state.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null))), ReactSystemFunctions.convertToTypeByName("6", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp804552Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, (stateVars.TM_TopManagerDashboardLeadList !== undefined ? (stateVars.TM_TopManagerDashboardLeadList?.length > 0 ? stateVars.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null) : (this.state.TM_TopManagerDashboardLeadList?.length > 0 ? this.state.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null))), ReactSystemFunctions.convertToTypeByName("6", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp371503Visible = ((ReactSystemFunctions.isNotEqualTo(ReactSystemFunctions.value(this, (stateVars.TM_TopManagerDashboardLeadList !== undefined ? (stateVars.TM_TopManagerDashboardLeadList?.length > 0 ? stateVars.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null) : (this.state.TM_TopManagerDashboardLeadList?.length > 0 ? this.state.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null))), ReactSystemFunctions.convertToTypeByName("7", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp698275Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, (stateVars.TM_TopManagerDashboardLeadList !== undefined ? (stateVars.TM_TopManagerDashboardLeadList?.length > 0 ? stateVars.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null) : (this.state.TM_TopManagerDashboardLeadList?.length > 0 ? this.state.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null))), ReactSystemFunctions.convertToTypeByName("7", "string"))) === true ? "visible" : "hidden")
			this.props.form?.setFieldsValue(formVars);
			
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.DashBoardTempManagerComponent_464762_onClick1_();
                  resolve();
                });
          })



        
        KuikaAppManager.hideSpinner(this);
        return isErrorOccurred;
    }
		DashBoardTempManagerComponent_464762_onClick1_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }

				
				stateVars.dataSource_827135 = stateVars.TM_TopManagerDashboardLeadList ?? this.state.TM_TopManagerDashboardLeadList;

		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

            
            return isErrorOccurred;
        }




    DashBoardTempManagerComponent_134969_onClick = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
		KuikaAppManager.increaseServerRequestCount();

        let localVar = {
				UserId_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.getMyUserId(), "Guid"),
				MusteriAdi_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "dashboardtempmanager_666343_value", "value", "", "", "")), "string"),
				ProductName_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "dashboardtempmanager_153369_value", "value", "", "", "")), "string"),
				LeadCode_0: ReactSystemFunctions.convertToTypeByName(null, "string"),
				Tel_0: ReactSystemFunctions.convertToTypeByName(null, "string"),
				CategoryName_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "dashboardtempmanager_731364_value", "value", "TM_GetProductCategory", "categoryCode", "categoryName")), "string"),
				StoreIds_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "dashboardtempmanager_453042_value", "value", "TM_GetStore", "id", "id")), "string"),
				SatisDanismaniIds_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "dashboardtempmanager_425161_value", "value", "TM_GetSalesPerson", "kUserId", "kUserId")), "string"),
				ProcessCode_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "dashboardtempmanager_274478_value", "value", "TM_GetLeadProcess", "id", "code")), "string"),
				StepOrder_0: ReactSystemFunctions.convertToTypeByName(6, "number"),
				StartDate_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "dashboardtempmanager_138929_value", "value", "", "", "")), "Date"),
				EndDate_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "dashboardtempmanager_381090_value", "value", "", "", "")), "Date")
        }

		KuikaAppManager.showSpinner(this);
		
        if (true) {
        KuikaAppManager.showSpinner(this);
        }
        let result = await KuikaAppManager.ApiRequest(this, "DashBoardTempManager/DashBoardTempManagerComponent_134969_onClick", localVar)
        if (!KMainFunctions.IsResStatus2XX(result)) return true;

			stateVars.TM_TopManagerDashboardLeadList = result?.data.tM_TopManagerDashboardLeadList;
			
			stateVars.isComp20059Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, (stateVars.TM_TopManagerDashboardLeadList !== undefined ? (stateVars.TM_TopManagerDashboardLeadList?.length > 0 ? stateVars.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null) : (this.state.TM_TopManagerDashboardLeadList?.length > 0 ? this.state.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null))), ReactSystemFunctions.convertToTypeByName("0", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp693403Visible = ((ReactSystemFunctions.isNotEqualTo(ReactSystemFunctions.value(this, (stateVars.TM_TopManagerDashboardLeadList !== undefined ? (stateVars.TM_TopManagerDashboardLeadList?.length > 0 ? stateVars.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null) : (this.state.TM_TopManagerDashboardLeadList?.length > 0 ? this.state.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null))), ReactSystemFunctions.convertToTypeByName("0", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp77242Visible = ((ReactSystemFunctions.isNotEqualTo(ReactSystemFunctions.value(this, (stateVars.TM_TopManagerDashboardLeadList !== undefined ? (stateVars.TM_TopManagerDashboardLeadList?.length > 0 ? stateVars.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null) : (this.state.TM_TopManagerDashboardLeadList?.length > 0 ? this.state.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null))), ReactSystemFunctions.convertToTypeByName("-1", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp352710Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, (stateVars.TM_TopManagerDashboardLeadList !== undefined ? (stateVars.TM_TopManagerDashboardLeadList?.length > 0 ? stateVars.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null) : (this.state.TM_TopManagerDashboardLeadList?.length > 0 ? this.state.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null))), ReactSystemFunctions.convertToTypeByName("-1", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp744094Visible = ((ReactSystemFunctions.isNotEqualTo(ReactSystemFunctions.value(this, (stateVars.TM_TopManagerDashboardLeadList !== undefined ? (stateVars.TM_TopManagerDashboardLeadList?.length > 0 ? stateVars.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null) : (this.state.TM_TopManagerDashboardLeadList?.length > 0 ? this.state.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null))), ReactSystemFunctions.convertToTypeByName("-2", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp558447Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, (stateVars.TM_TopManagerDashboardLeadList !== undefined ? (stateVars.TM_TopManagerDashboardLeadList?.length > 0 ? stateVars.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null) : (this.state.TM_TopManagerDashboardLeadList?.length > 0 ? this.state.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null))), ReactSystemFunctions.convertToTypeByName("-2", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp551457Visible = ((ReactSystemFunctions.isNotEqualTo(ReactSystemFunctions.value(this, (stateVars.TM_TopManagerDashboardLeadList !== undefined ? (stateVars.TM_TopManagerDashboardLeadList?.length > 0 ? stateVars.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null) : (this.state.TM_TopManagerDashboardLeadList?.length > 0 ? this.state.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null))), ReactSystemFunctions.convertToTypeByName("-3", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp862838Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, (stateVars.TM_TopManagerDashboardLeadList !== undefined ? (stateVars.TM_TopManagerDashboardLeadList?.length > 0 ? stateVars.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null) : (this.state.TM_TopManagerDashboardLeadList?.length > 0 ? this.state.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null))), ReactSystemFunctions.convertToTypeByName("-3", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp4159Visible = ((ReactSystemFunctions.isNotEqualTo(ReactSystemFunctions.value(this, (stateVars.TM_TopManagerDashboardLeadList !== undefined ? (stateVars.TM_TopManagerDashboardLeadList?.length > 0 ? stateVars.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null) : (this.state.TM_TopManagerDashboardLeadList?.length > 0 ? this.state.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null))), ReactSystemFunctions.convertToTypeByName("2", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp170471Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, (stateVars.TM_TopManagerDashboardLeadList !== undefined ? (stateVars.TM_TopManagerDashboardLeadList?.length > 0 ? stateVars.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null) : (this.state.TM_TopManagerDashboardLeadList?.length > 0 ? this.state.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null))), ReactSystemFunctions.convertToTypeByName("2", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp397882Visible = ((ReactSystemFunctions.isNotEqualTo(ReactSystemFunctions.value(this, (stateVars.TM_TopManagerDashboardLeadList !== undefined ? (stateVars.TM_TopManagerDashboardLeadList?.length > 0 ? stateVars.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null) : (this.state.TM_TopManagerDashboardLeadList?.length > 0 ? this.state.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null))), ReactSystemFunctions.convertToTypeByName("3", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp941736Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, (stateVars.TM_TopManagerDashboardLeadList !== undefined ? (stateVars.TM_TopManagerDashboardLeadList?.length > 0 ? stateVars.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null) : (this.state.TM_TopManagerDashboardLeadList?.length > 0 ? this.state.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null))), ReactSystemFunctions.convertToTypeByName("3", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp489263Visible = ((ReactSystemFunctions.isNotEqualTo(ReactSystemFunctions.value(this, (stateVars.TM_TopManagerDashboardLeadList !== undefined ? (stateVars.TM_TopManagerDashboardLeadList?.length > 0 ? stateVars.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null) : (this.state.TM_TopManagerDashboardLeadList?.length > 0 ? this.state.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null))), ReactSystemFunctions.convertToTypeByName("10", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp675337Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, (stateVars.TM_TopManagerDashboardLeadList !== undefined ? (stateVars.TM_TopManagerDashboardLeadList?.length > 0 ? stateVars.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null) : (this.state.TM_TopManagerDashboardLeadList?.length > 0 ? this.state.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null))), ReactSystemFunctions.convertToTypeByName("10", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp654813Visible = ((ReactSystemFunctions.isNotEqualTo(ReactSystemFunctions.value(this, (stateVars.TM_TopManagerDashboardLeadList !== undefined ? (stateVars.TM_TopManagerDashboardLeadList?.length > 0 ? stateVars.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null) : (this.state.TM_TopManagerDashboardLeadList?.length > 0 ? this.state.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null))), ReactSystemFunctions.convertToTypeByName("6", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp804552Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, (stateVars.TM_TopManagerDashboardLeadList !== undefined ? (stateVars.TM_TopManagerDashboardLeadList?.length > 0 ? stateVars.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null) : (this.state.TM_TopManagerDashboardLeadList?.length > 0 ? this.state.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null))), ReactSystemFunctions.convertToTypeByName("6", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp371503Visible = ((ReactSystemFunctions.isNotEqualTo(ReactSystemFunctions.value(this, (stateVars.TM_TopManagerDashboardLeadList !== undefined ? (stateVars.TM_TopManagerDashboardLeadList?.length > 0 ? stateVars.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null) : (this.state.TM_TopManagerDashboardLeadList?.length > 0 ? this.state.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null))), ReactSystemFunctions.convertToTypeByName("7", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp698275Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, (stateVars.TM_TopManagerDashboardLeadList !== undefined ? (stateVars.TM_TopManagerDashboardLeadList?.length > 0 ? stateVars.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null) : (this.state.TM_TopManagerDashboardLeadList?.length > 0 ? this.state.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null))), ReactSystemFunctions.convertToTypeByName("7", "string"))) === true ? "visible" : "hidden")
			this.props.form?.setFieldsValue(formVars);
			
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.DashBoardTempManagerComponent_134969_onClick1_();
                  resolve();
                });
          })



        
        KuikaAppManager.hideSpinner(this);
        return isErrorOccurred;
    }
		DashBoardTempManagerComponent_134969_onClick1_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }

				
				stateVars.dataSource_827135 = stateVars.TM_TopManagerDashboardLeadList ?? this.state.TM_TopManagerDashboardLeadList;

		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

            
            return isErrorOccurred;
        }




    DashBoardTempManagerComponent_694338_onClick = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
		KuikaAppManager.increaseServerRequestCount();

        let localVar = {
				UserId_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.getMyUserId(), "Guid"),
				MusteriAdi_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "dashboardtempmanager_666343_value", "value", "", "", "")), "string"),
				ProductName_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "dashboardtempmanager_153369_value", "value", "", "", "")), "string"),
				LeadCode_0: ReactSystemFunctions.convertToTypeByName(null, "string"),
				Tel_0: ReactSystemFunctions.convertToTypeByName(null, "string"),
				CategoryName_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "dashboardtempmanager_731364_value", "value", "TM_GetProductCategory", "categoryCode", "categoryName")), "string"),
				StoreIds_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "dashboardtempmanager_453042_value", "value", "TM_GetStore", "id", "id")), "string"),
				SatisDanismaniIds_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "dashboardtempmanager_425161_value", "value", "TM_GetSalesPerson", "kUserId", "kUserId")), "string"),
				ProcessCode_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "dashboardtempmanager_274478_value", "value", "TM_GetLeadProcess", "id", "code")), "string"),
				StepOrder_0: ReactSystemFunctions.convertToTypeByName(7, "number"),
				StartDate_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "dashboardtempmanager_138929_value", "value", "", "", "")), "Date"),
				EndDate_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "dashboardtempmanager_381090_value", "value", "", "", "")), "Date")
        }

		KuikaAppManager.showSpinner(this);
		
        if (true) {
        KuikaAppManager.showSpinner(this);
        }
        let result = await KuikaAppManager.ApiRequest(this, "DashBoardTempManager/DashBoardTempManagerComponent_694338_onClick", localVar)
        if (!KMainFunctions.IsResStatus2XX(result)) return true;

			stateVars.TM_TopManagerDashboardLeadList = result?.data.tM_TopManagerDashboardLeadList;
			
			stateVars.isComp20059Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, (stateVars.TM_TopManagerDashboardLeadList !== undefined ? (stateVars.TM_TopManagerDashboardLeadList?.length > 0 ? stateVars.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null) : (this.state.TM_TopManagerDashboardLeadList?.length > 0 ? this.state.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null))), ReactSystemFunctions.convertToTypeByName("0", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp693403Visible = ((ReactSystemFunctions.isNotEqualTo(ReactSystemFunctions.value(this, (stateVars.TM_TopManagerDashboardLeadList !== undefined ? (stateVars.TM_TopManagerDashboardLeadList?.length > 0 ? stateVars.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null) : (this.state.TM_TopManagerDashboardLeadList?.length > 0 ? this.state.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null))), ReactSystemFunctions.convertToTypeByName("0", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp77242Visible = ((ReactSystemFunctions.isNotEqualTo(ReactSystemFunctions.value(this, (stateVars.TM_TopManagerDashboardLeadList !== undefined ? (stateVars.TM_TopManagerDashboardLeadList?.length > 0 ? stateVars.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null) : (this.state.TM_TopManagerDashboardLeadList?.length > 0 ? this.state.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null))), ReactSystemFunctions.convertToTypeByName("-1", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp352710Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, (stateVars.TM_TopManagerDashboardLeadList !== undefined ? (stateVars.TM_TopManagerDashboardLeadList?.length > 0 ? stateVars.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null) : (this.state.TM_TopManagerDashboardLeadList?.length > 0 ? this.state.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null))), ReactSystemFunctions.convertToTypeByName("-1", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp744094Visible = ((ReactSystemFunctions.isNotEqualTo(ReactSystemFunctions.value(this, (stateVars.TM_TopManagerDashboardLeadList !== undefined ? (stateVars.TM_TopManagerDashboardLeadList?.length > 0 ? stateVars.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null) : (this.state.TM_TopManagerDashboardLeadList?.length > 0 ? this.state.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null))), ReactSystemFunctions.convertToTypeByName("-2", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp558447Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, (stateVars.TM_TopManagerDashboardLeadList !== undefined ? (stateVars.TM_TopManagerDashboardLeadList?.length > 0 ? stateVars.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null) : (this.state.TM_TopManagerDashboardLeadList?.length > 0 ? this.state.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null))), ReactSystemFunctions.convertToTypeByName("-2", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp551457Visible = ((ReactSystemFunctions.isNotEqualTo(ReactSystemFunctions.value(this, (stateVars.TM_TopManagerDashboardLeadList !== undefined ? (stateVars.TM_TopManagerDashboardLeadList?.length > 0 ? stateVars.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null) : (this.state.TM_TopManagerDashboardLeadList?.length > 0 ? this.state.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null))), ReactSystemFunctions.convertToTypeByName("-3", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp862838Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, (stateVars.TM_TopManagerDashboardLeadList !== undefined ? (stateVars.TM_TopManagerDashboardLeadList?.length > 0 ? stateVars.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null) : (this.state.TM_TopManagerDashboardLeadList?.length > 0 ? this.state.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null))), ReactSystemFunctions.convertToTypeByName("-3", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp4159Visible = ((ReactSystemFunctions.isNotEqualTo(ReactSystemFunctions.value(this, (stateVars.TM_TopManagerDashboardLeadList !== undefined ? (stateVars.TM_TopManagerDashboardLeadList?.length > 0 ? stateVars.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null) : (this.state.TM_TopManagerDashboardLeadList?.length > 0 ? this.state.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null))), ReactSystemFunctions.convertToTypeByName("2", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp170471Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, (stateVars.TM_TopManagerDashboardLeadList !== undefined ? (stateVars.TM_TopManagerDashboardLeadList?.length > 0 ? stateVars.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null) : (this.state.TM_TopManagerDashboardLeadList?.length > 0 ? this.state.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null))), ReactSystemFunctions.convertToTypeByName("2", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp397882Visible = ((ReactSystemFunctions.isNotEqualTo(ReactSystemFunctions.value(this, (stateVars.TM_TopManagerDashboardLeadList !== undefined ? (stateVars.TM_TopManagerDashboardLeadList?.length > 0 ? stateVars.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null) : (this.state.TM_TopManagerDashboardLeadList?.length > 0 ? this.state.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null))), ReactSystemFunctions.convertToTypeByName("3", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp941736Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, (stateVars.TM_TopManagerDashboardLeadList !== undefined ? (stateVars.TM_TopManagerDashboardLeadList?.length > 0 ? stateVars.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null) : (this.state.TM_TopManagerDashboardLeadList?.length > 0 ? this.state.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null))), ReactSystemFunctions.convertToTypeByName("3", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp489263Visible = ((ReactSystemFunctions.isNotEqualTo(ReactSystemFunctions.value(this, (stateVars.TM_TopManagerDashboardLeadList !== undefined ? (stateVars.TM_TopManagerDashboardLeadList?.length > 0 ? stateVars.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null) : (this.state.TM_TopManagerDashboardLeadList?.length > 0 ? this.state.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null))), ReactSystemFunctions.convertToTypeByName("10", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp675337Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, (stateVars.TM_TopManagerDashboardLeadList !== undefined ? (stateVars.TM_TopManagerDashboardLeadList?.length > 0 ? stateVars.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null) : (this.state.TM_TopManagerDashboardLeadList?.length > 0 ? this.state.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null))), ReactSystemFunctions.convertToTypeByName("10", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp654813Visible = ((ReactSystemFunctions.isNotEqualTo(ReactSystemFunctions.value(this, (stateVars.TM_TopManagerDashboardLeadList !== undefined ? (stateVars.TM_TopManagerDashboardLeadList?.length > 0 ? stateVars.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null) : (this.state.TM_TopManagerDashboardLeadList?.length > 0 ? this.state.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null))), ReactSystemFunctions.convertToTypeByName("6", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp804552Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, (stateVars.TM_TopManagerDashboardLeadList !== undefined ? (stateVars.TM_TopManagerDashboardLeadList?.length > 0 ? stateVars.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null) : (this.state.TM_TopManagerDashboardLeadList?.length > 0 ? this.state.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null))), ReactSystemFunctions.convertToTypeByName("6", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp371503Visible = ((ReactSystemFunctions.isNotEqualTo(ReactSystemFunctions.value(this, (stateVars.TM_TopManagerDashboardLeadList !== undefined ? (stateVars.TM_TopManagerDashboardLeadList?.length > 0 ? stateVars.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null) : (this.state.TM_TopManagerDashboardLeadList?.length > 0 ? this.state.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null))), ReactSystemFunctions.convertToTypeByName("7", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp698275Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, (stateVars.TM_TopManagerDashboardLeadList !== undefined ? (stateVars.TM_TopManagerDashboardLeadList?.length > 0 ? stateVars.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null) : (this.state.TM_TopManagerDashboardLeadList?.length > 0 ? this.state.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null))), ReactSystemFunctions.convertToTypeByName("7", "string"))) === true ? "visible" : "hidden")
			this.props.form?.setFieldsValue(formVars);
			
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.DashBoardTempManagerComponent_694338_onClick1_();
                  resolve();
                });
          })



        
        KuikaAppManager.hideSpinner(this);
        return isErrorOccurred;
    }
		DashBoardTempManagerComponent_694338_onClick1_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }

				
				stateVars.dataSource_827135 = stateVars.TM_TopManagerDashboardLeadList ?? this.state.TM_TopManagerDashboardLeadList;

		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

            
            return isErrorOccurred;
        }




    DashBoardTempManagerComponent_888656_onClick = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
		KuikaAppManager.increaseServerRequestCount();

        let localVar = {
				UserId_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.getMyUserId(), "Guid"),
				MusteriAdi_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "dashboardtempmanager_666343_value", "value", "", "", "")), "string"),
				ProductName_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "dashboardtempmanager_153369_value", "value", "", "", "")), "string"),
				LeadCode_0: ReactSystemFunctions.convertToTypeByName(null, "string"),
				Tel_0: ReactSystemFunctions.convertToTypeByName(null, "string"),
				CategoryName_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "dashboardtempmanager_731364_value", "value", "TM_GetProductCategory", "categoryCode", "categoryName")), "string"),
				StoreIds_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "dashboardtempmanager_453042_value", "value", "TM_GetStore", "id", "id")), "string"),
				SatisDanismaniIds_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "dashboardtempmanager_425161_value", "value", "TM_GetSalesPerson", "kUserId", "kUserId")), "string"),
				ProcessCode_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "dashboardtempmanager_274478_value", "value", "TM_GetLeadProcess", "id", "code")), "string"),
				StepOrder_0: ReactSystemFunctions.convertToTypeByName(99, "number"),
				StartDate_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "dashboardtempmanager_138929_value", "value", "", "", "")), "Date"),
				EndDate_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "dashboardtempmanager_381090_value", "value", "", "", "")), "Date")
        }

		KuikaAppManager.showSpinner(this);
		
        if (true) {
        KuikaAppManager.showSpinner(this);
        }
        let result = await KuikaAppManager.ApiRequest(this, "DashBoardTempManager/DashBoardTempManagerComponent_888656_onClick", localVar)
        if (!KMainFunctions.IsResStatus2XX(result)) return true;

			stateVars.TM_TopManagerDashboardLeadList = result?.data.tM_TopManagerDashboardLeadList;
			
			stateVars.isComp20059Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, (stateVars.TM_TopManagerDashboardLeadList !== undefined ? (stateVars.TM_TopManagerDashboardLeadList?.length > 0 ? stateVars.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null) : (this.state.TM_TopManagerDashboardLeadList?.length > 0 ? this.state.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null))), ReactSystemFunctions.convertToTypeByName("0", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp693403Visible = ((ReactSystemFunctions.isNotEqualTo(ReactSystemFunctions.value(this, (stateVars.TM_TopManagerDashboardLeadList !== undefined ? (stateVars.TM_TopManagerDashboardLeadList?.length > 0 ? stateVars.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null) : (this.state.TM_TopManagerDashboardLeadList?.length > 0 ? this.state.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null))), ReactSystemFunctions.convertToTypeByName("0", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp77242Visible = ((ReactSystemFunctions.isNotEqualTo(ReactSystemFunctions.value(this, (stateVars.TM_TopManagerDashboardLeadList !== undefined ? (stateVars.TM_TopManagerDashboardLeadList?.length > 0 ? stateVars.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null) : (this.state.TM_TopManagerDashboardLeadList?.length > 0 ? this.state.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null))), ReactSystemFunctions.convertToTypeByName("-1", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp352710Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, (stateVars.TM_TopManagerDashboardLeadList !== undefined ? (stateVars.TM_TopManagerDashboardLeadList?.length > 0 ? stateVars.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null) : (this.state.TM_TopManagerDashboardLeadList?.length > 0 ? this.state.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null))), ReactSystemFunctions.convertToTypeByName("-1", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp744094Visible = ((ReactSystemFunctions.isNotEqualTo(ReactSystemFunctions.value(this, (stateVars.TM_TopManagerDashboardLeadList !== undefined ? (stateVars.TM_TopManagerDashboardLeadList?.length > 0 ? stateVars.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null) : (this.state.TM_TopManagerDashboardLeadList?.length > 0 ? this.state.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null))), ReactSystemFunctions.convertToTypeByName("-2", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp558447Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, (stateVars.TM_TopManagerDashboardLeadList !== undefined ? (stateVars.TM_TopManagerDashboardLeadList?.length > 0 ? stateVars.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null) : (this.state.TM_TopManagerDashboardLeadList?.length > 0 ? this.state.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null))), ReactSystemFunctions.convertToTypeByName("-2", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp551457Visible = ((ReactSystemFunctions.isNotEqualTo(ReactSystemFunctions.value(this, (stateVars.TM_TopManagerDashboardLeadList !== undefined ? (stateVars.TM_TopManagerDashboardLeadList?.length > 0 ? stateVars.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null) : (this.state.TM_TopManagerDashboardLeadList?.length > 0 ? this.state.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null))), ReactSystemFunctions.convertToTypeByName("-3", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp862838Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, (stateVars.TM_TopManagerDashboardLeadList !== undefined ? (stateVars.TM_TopManagerDashboardLeadList?.length > 0 ? stateVars.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null) : (this.state.TM_TopManagerDashboardLeadList?.length > 0 ? this.state.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null))), ReactSystemFunctions.convertToTypeByName("-3", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp4159Visible = ((ReactSystemFunctions.isNotEqualTo(ReactSystemFunctions.value(this, (stateVars.TM_TopManagerDashboardLeadList !== undefined ? (stateVars.TM_TopManagerDashboardLeadList?.length > 0 ? stateVars.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null) : (this.state.TM_TopManagerDashboardLeadList?.length > 0 ? this.state.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null))), ReactSystemFunctions.convertToTypeByName("2", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp170471Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, (stateVars.TM_TopManagerDashboardLeadList !== undefined ? (stateVars.TM_TopManagerDashboardLeadList?.length > 0 ? stateVars.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null) : (this.state.TM_TopManagerDashboardLeadList?.length > 0 ? this.state.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null))), ReactSystemFunctions.convertToTypeByName("2", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp397882Visible = ((ReactSystemFunctions.isNotEqualTo(ReactSystemFunctions.value(this, (stateVars.TM_TopManagerDashboardLeadList !== undefined ? (stateVars.TM_TopManagerDashboardLeadList?.length > 0 ? stateVars.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null) : (this.state.TM_TopManagerDashboardLeadList?.length > 0 ? this.state.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null))), ReactSystemFunctions.convertToTypeByName("3", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp941736Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, (stateVars.TM_TopManagerDashboardLeadList !== undefined ? (stateVars.TM_TopManagerDashboardLeadList?.length > 0 ? stateVars.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null) : (this.state.TM_TopManagerDashboardLeadList?.length > 0 ? this.state.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null))), ReactSystemFunctions.convertToTypeByName("3", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp489263Visible = ((ReactSystemFunctions.isNotEqualTo(ReactSystemFunctions.value(this, (stateVars.TM_TopManagerDashboardLeadList !== undefined ? (stateVars.TM_TopManagerDashboardLeadList?.length > 0 ? stateVars.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null) : (this.state.TM_TopManagerDashboardLeadList?.length > 0 ? this.state.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null))), ReactSystemFunctions.convertToTypeByName("10", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp675337Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, (stateVars.TM_TopManagerDashboardLeadList !== undefined ? (stateVars.TM_TopManagerDashboardLeadList?.length > 0 ? stateVars.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null) : (this.state.TM_TopManagerDashboardLeadList?.length > 0 ? this.state.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null))), ReactSystemFunctions.convertToTypeByName("10", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp654813Visible = ((ReactSystemFunctions.isNotEqualTo(ReactSystemFunctions.value(this, (stateVars.TM_TopManagerDashboardLeadList !== undefined ? (stateVars.TM_TopManagerDashboardLeadList?.length > 0 ? stateVars.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null) : (this.state.TM_TopManagerDashboardLeadList?.length > 0 ? this.state.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null))), ReactSystemFunctions.convertToTypeByName("6", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp804552Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, (stateVars.TM_TopManagerDashboardLeadList !== undefined ? (stateVars.TM_TopManagerDashboardLeadList?.length > 0 ? stateVars.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null) : (this.state.TM_TopManagerDashboardLeadList?.length > 0 ? this.state.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null))), ReactSystemFunctions.convertToTypeByName("6", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp371503Visible = ((ReactSystemFunctions.isNotEqualTo(ReactSystemFunctions.value(this, (stateVars.TM_TopManagerDashboardLeadList !== undefined ? (stateVars.TM_TopManagerDashboardLeadList?.length > 0 ? stateVars.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null) : (this.state.TM_TopManagerDashboardLeadList?.length > 0 ? this.state.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null))), ReactSystemFunctions.convertToTypeByName("7", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp698275Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, (stateVars.TM_TopManagerDashboardLeadList !== undefined ? (stateVars.TM_TopManagerDashboardLeadList?.length > 0 ? stateVars.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null) : (this.state.TM_TopManagerDashboardLeadList?.length > 0 ? this.state.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null))), ReactSystemFunctions.convertToTypeByName("7", "string"))) === true ? "visible" : "hidden")
			this.props.form?.setFieldsValue(formVars);
			
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.DashBoardTempManagerComponent_888656_onClick1_();
                  resolve();
                });
          })



        
        KuikaAppManager.hideSpinner(this);
        return isErrorOccurred;
    }
		DashBoardTempManagerComponent_888656_onClick1_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }

				
				stateVars.dataSource_827135 = stateVars.TM_TopManagerDashboardLeadList ?? this.state.TM_TopManagerDashboardLeadList;

		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

            
            return isErrorOccurred;
        }




		DashBoardTempManagerComponent_504673_onClick = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
KuikaAppManager.showSpinner(this);

const __currentPath = (window.location.hash ? window.location.hash.replace(/^#/, '').split('?')[0] : window.location.pathname.split('?')[0]).toLowerCase();
if (__currentPath !== "/leadaddtemp") {
  this.context.setMasterPageInitLoaded(false);
  this.context.setMasterPageRecurringLoaded(false);
  this.context.setShouldTriggerPageInit(true);
}
					KuikaAppManager.prepareForNavigation();
						KuikaAppManager.addToPageInputVariables("LeadAddTemp", "CustomerId", ReactSystemFunctions.convertToTypeByName("00000000-0000-0000-0000-000000000000", "Guid"));

				stateVars.NAVIGATE = await ReactSystemFunctions.navigate(this, undefined, "DashBoardTempManager", "LeadAddTemp", "", "currentPage", null, null, null, null, null, null, true, false);

		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

            
            return isErrorOccurred;
        }


    DashBoardTempManagerComponent_934663_onChange = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
		KuikaAppManager.increaseServerRequestCount();

        let localVar = {
				UserId_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.getMyUserId(), "Guid"),
				TaskTypeFilter_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toInteger(this, ReactSystemFunctions.value(this, "dashboardtempmanager_934663_value", "value", "", "key", "")), "number")
        }

		KuikaAppManager.showSpinner(this);
		
        if (true) {
        KuikaAppManager.showSpinner(this);
        }
        let result = await KuikaAppManager.ApiRequest(this, "DashBoardTempManager/DashBoardTempManagerComponent_934663_onChange", localVar)
        if (!KMainFunctions.IsResStatus2XX(result)) return true;

			stateVars.TMGetDashboardStoreManagerTaskList = result?.data.tmGetDashboardStoreManagerTaskList;
			
			this.props.form?.setFieldsValue(formVars);
			
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.DashBoardTempManagerComponent_934663_onChange1_();
                  resolve();
                });
          })



        
        KuikaAppManager.hideSpinner(this);
        return isErrorOccurred;
    }
		DashBoardTempManagerComponent_934663_onChange1_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }

				
				stateVars.dataSource_75145 = stateVars.TMGetDashboardStoreManagerTaskList ?? this.state.TMGetDashboardStoreManagerTaskList;

		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

            
            return isErrorOccurred;
        }




		DashBoardTempManagerComponent_142402_onClick = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
KuikaAppManager.showSpinner(this);

					KuikaAppManager.prepareForNavigation();
						KuikaAppManager.addToPageInputVariables("PopRezervOnayBekleyenPopup", "LeadId", ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, "dashboardtempmanager_75145_value", "leadId"), "Guid"));

				stateVars.NAVIGATE = await ReactSystemFunctions.navigate(this, undefined, "DashBoardTempManager", "PopRezervOnayBekleyenPopup", "", "currentPage", null, null, null, null, null, null, true, false);

		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

            
            return isErrorOccurred;
        }


		DashBoardTempManagerComponent_373351_onClick = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
KuikaAppManager.showSpinner(this);

					KuikaAppManager.prepareForNavigation();
						KuikaAppManager.addToPageInputVariables("TalepSatisIslemi", "LeadId", ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, "dashboardtempmanager_75145_value", "leadId"), "Guid"));
						KuikaAppManager.addToPageInputVariables("TalepSatisIslemi", "ApprovalId", ReactSystemFunctions.convertToTypeByName(null, "Guid"));
						KuikaAppManager.addToPageInputVariables("TalepSatisIslemi", "SalesLeadDraftId", ReactSystemFunctions.convertToTypeByName(null, "Guid"));

				stateVars.NAVIGATE = await ReactSystemFunctions.navigate(this, undefined, "DashBoardTempManager", "TalepSatisIslemi", "", "currentPage", null, null, null, null, null, null, true, false);

		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

            
            return isErrorOccurred;
        }


		DashBoardTempManagerComponent_621790_onClick = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
KuikaAppManager.showSpinner(this);

					KuikaAppManager.prepareForNavigation();
						KuikaAppManager.addToPageInputVariables("PopOnayBekleyen", "LeadId", ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, "dashboardtempmanager_75145_value", "leadId"), "Guid"));

				stateVars.NAVIGATE = await ReactSystemFunctions.navigate(this, undefined, "DashBoardTempManager", "PopOnayBekleyen", "", "currentPage", null, null, null, null, null, null, true, false);

		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

            
            return isErrorOccurred;
        }


		DashBoardTempManagerComponent_296871_onClick = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
KuikaAppManager.showSpinner(this);

					KuikaAppManager.prepareForNavigation();
						KuikaAppManager.addToPageInputVariables("PopTerminOnerisiBekleyen", "LeadId", ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, "dashboardtempmanager_75145_value", "leadId"), "Guid"));

				stateVars.NAVIGATE = await ReactSystemFunctions.navigate(this, undefined, "DashBoardTempManager", "PopTerminOnerisiBekleyen", "", "currentPage", null, null, null, null, null, null, true, false);

		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

            
            return isErrorOccurred;
        }


		DashBoardTempManagerComponent_11830_onClick = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
KuikaAppManager.showSpinner(this);

					KuikaAppManager.prepareForNavigation();
						KuikaAppManager.addToPageInputVariables("reservationPopUp2", "LeadId", ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, "dashboardtempmanager_75145_value", "leadId"), "Guid"));

				stateVars.NAVIGATE = await ReactSystemFunctions.navigate(this, undefined, "DashBoardTempManager", "reservationPopUp2", "", "currentPage", null, null, null, null, null, null, true, false);

		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

            
            return isErrorOccurred;
        }


		DashBoardTempManagerComponent_508013_onClick = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
KuikaAppManager.showSpinner(this);

					KuikaAppManager.prepareForNavigation();
						KuikaAppManager.addToPageInputVariables("reservationPopup1", "LeadId", ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, "dashboardtempmanager_75145_value", "leadId"), "Guid"));

				stateVars.NAVIGATE = await ReactSystemFunctions.navigate(this, undefined, "DashBoardTempManager", "reservationPopup1", "", "currentPage", null, null, null, null, null, null, true, false);

		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

            
            return isErrorOccurred;
        }


		DashBoardTempManagerComponent_152850_onClick = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
KuikaAppManager.showSpinner(this);

					KuikaAppManager.prepareForNavigation();
						KuikaAppManager.addToPageInputVariables("LeadDetailTemp", "LeadId", ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, "dashboardtempmanager_75145_value", "leadId"), "Guid"));

				stateVars.NAVIGATE = await ReactSystemFunctions.navigate(this, undefined, "DashBoardTempManager", "LeadDetailTemp", "", "7d969ddf-5801-4eb6-b92b-12be35bdd565", "246279", null, "right", "true", "70vw", "100vh", true, false);

		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

            
            return isErrorOccurred;
        }


    DashBoardTempManagerComponent_693403_onClick = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
		KuikaAppManager.increaseServerRequestCount();

        let localVar = {
				UserId_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.getMyUserId(), "Guid"),
				MusteriAdi_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "dashboardtempmanager_666343_value", "value", "", "", "")), "string"),
				ProductName_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "dashboardtempmanager_153369_value", "value", "", "", "")), "string"),
				LeadCode_0: ReactSystemFunctions.convertToTypeByName(null, "string"),
				Tel_0: ReactSystemFunctions.convertToTypeByName(null, "string"),
				CategoryName_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "dashboardtempmanager_731364_value", "value", "TM_GetProductCategory", "categoryCode", "categoryName")), "string"),
				StoreIds_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "dashboardtempmanager_453042_value", "value", "TM_GetStore", "id", "id")), "string"),
				SatisDanismaniIds_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "dashboardtempmanager_425161_value", "value", "TM_GetSalesPerson", "kUserId", "kUserId")), "string"),
				ProcessCode_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "dashboardtempmanager_274478_value", "value", "TM_GetLeadProcess", "id", "code")), "string"),
				StepOrder_0: ReactSystemFunctions.convertToTypeByName(0, "number"),
				StartDate_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "dashboardtempmanager_138929_value", "value", "", "", "")), "Date"),
				EndDate_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "dashboardtempmanager_381090_value", "value", "", "", "")), "Date")
        }

		KuikaAppManager.showSpinner(this);
		
        if (true) {
        KuikaAppManager.showSpinner(this);
        }
        let result = await KuikaAppManager.ApiRequest(this, "DashBoardTempManager/DashBoardTempManagerComponent_693403_onClick", localVar)
        if (!KMainFunctions.IsResStatus2XX(result)) return true;

			stateVars.TM_TopManagerDashboardLeadList = result?.data.tM_TopManagerDashboardLeadList;
			
			stateVars.isComp20059Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, (stateVars.TM_TopManagerDashboardLeadList !== undefined ? (stateVars.TM_TopManagerDashboardLeadList?.length > 0 ? stateVars.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null) : (this.state.TM_TopManagerDashboardLeadList?.length > 0 ? this.state.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null))), ReactSystemFunctions.convertToTypeByName("0", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp693403Visible = ((ReactSystemFunctions.isNotEqualTo(ReactSystemFunctions.value(this, (stateVars.TM_TopManagerDashboardLeadList !== undefined ? (stateVars.TM_TopManagerDashboardLeadList?.length > 0 ? stateVars.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null) : (this.state.TM_TopManagerDashboardLeadList?.length > 0 ? this.state.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null))), ReactSystemFunctions.convertToTypeByName("0", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp77242Visible = ((ReactSystemFunctions.isNotEqualTo(ReactSystemFunctions.value(this, (stateVars.TM_TopManagerDashboardLeadList !== undefined ? (stateVars.TM_TopManagerDashboardLeadList?.length > 0 ? stateVars.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null) : (this.state.TM_TopManagerDashboardLeadList?.length > 0 ? this.state.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null))), ReactSystemFunctions.convertToTypeByName("-1", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp352710Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, (stateVars.TM_TopManagerDashboardLeadList !== undefined ? (stateVars.TM_TopManagerDashboardLeadList?.length > 0 ? stateVars.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null) : (this.state.TM_TopManagerDashboardLeadList?.length > 0 ? this.state.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null))), ReactSystemFunctions.convertToTypeByName("-1", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp744094Visible = ((ReactSystemFunctions.isNotEqualTo(ReactSystemFunctions.value(this, (stateVars.TM_TopManagerDashboardLeadList !== undefined ? (stateVars.TM_TopManagerDashboardLeadList?.length > 0 ? stateVars.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null) : (this.state.TM_TopManagerDashboardLeadList?.length > 0 ? this.state.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null))), ReactSystemFunctions.convertToTypeByName("-2", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp558447Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, (stateVars.TM_TopManagerDashboardLeadList !== undefined ? (stateVars.TM_TopManagerDashboardLeadList?.length > 0 ? stateVars.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null) : (this.state.TM_TopManagerDashboardLeadList?.length > 0 ? this.state.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null))), ReactSystemFunctions.convertToTypeByName("-2", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp551457Visible = ((ReactSystemFunctions.isNotEqualTo(ReactSystemFunctions.value(this, (stateVars.TM_TopManagerDashboardLeadList !== undefined ? (stateVars.TM_TopManagerDashboardLeadList?.length > 0 ? stateVars.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null) : (this.state.TM_TopManagerDashboardLeadList?.length > 0 ? this.state.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null))), ReactSystemFunctions.convertToTypeByName("-3", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp862838Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, (stateVars.TM_TopManagerDashboardLeadList !== undefined ? (stateVars.TM_TopManagerDashboardLeadList?.length > 0 ? stateVars.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null) : (this.state.TM_TopManagerDashboardLeadList?.length > 0 ? this.state.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null))), ReactSystemFunctions.convertToTypeByName("-3", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp4159Visible = ((ReactSystemFunctions.isNotEqualTo(ReactSystemFunctions.value(this, (stateVars.TM_TopManagerDashboardLeadList !== undefined ? (stateVars.TM_TopManagerDashboardLeadList?.length > 0 ? stateVars.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null) : (this.state.TM_TopManagerDashboardLeadList?.length > 0 ? this.state.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null))), ReactSystemFunctions.convertToTypeByName("2", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp170471Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, (stateVars.TM_TopManagerDashboardLeadList !== undefined ? (stateVars.TM_TopManagerDashboardLeadList?.length > 0 ? stateVars.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null) : (this.state.TM_TopManagerDashboardLeadList?.length > 0 ? this.state.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null))), ReactSystemFunctions.convertToTypeByName("2", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp397882Visible = ((ReactSystemFunctions.isNotEqualTo(ReactSystemFunctions.value(this, (stateVars.TM_TopManagerDashboardLeadList !== undefined ? (stateVars.TM_TopManagerDashboardLeadList?.length > 0 ? stateVars.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null) : (this.state.TM_TopManagerDashboardLeadList?.length > 0 ? this.state.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null))), ReactSystemFunctions.convertToTypeByName("3", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp941736Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, (stateVars.TM_TopManagerDashboardLeadList !== undefined ? (stateVars.TM_TopManagerDashboardLeadList?.length > 0 ? stateVars.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null) : (this.state.TM_TopManagerDashboardLeadList?.length > 0 ? this.state.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null))), ReactSystemFunctions.convertToTypeByName("3", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp489263Visible = ((ReactSystemFunctions.isNotEqualTo(ReactSystemFunctions.value(this, (stateVars.TM_TopManagerDashboardLeadList !== undefined ? (stateVars.TM_TopManagerDashboardLeadList?.length > 0 ? stateVars.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null) : (this.state.TM_TopManagerDashboardLeadList?.length > 0 ? this.state.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null))), ReactSystemFunctions.convertToTypeByName("10", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp675337Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, (stateVars.TM_TopManagerDashboardLeadList !== undefined ? (stateVars.TM_TopManagerDashboardLeadList?.length > 0 ? stateVars.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null) : (this.state.TM_TopManagerDashboardLeadList?.length > 0 ? this.state.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null))), ReactSystemFunctions.convertToTypeByName("10", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp654813Visible = ((ReactSystemFunctions.isNotEqualTo(ReactSystemFunctions.value(this, (stateVars.TM_TopManagerDashboardLeadList !== undefined ? (stateVars.TM_TopManagerDashboardLeadList?.length > 0 ? stateVars.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null) : (this.state.TM_TopManagerDashboardLeadList?.length > 0 ? this.state.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null))), ReactSystemFunctions.convertToTypeByName("6", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp804552Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, (stateVars.TM_TopManagerDashboardLeadList !== undefined ? (stateVars.TM_TopManagerDashboardLeadList?.length > 0 ? stateVars.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null) : (this.state.TM_TopManagerDashboardLeadList?.length > 0 ? this.state.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null))), ReactSystemFunctions.convertToTypeByName("6", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp371503Visible = ((ReactSystemFunctions.isNotEqualTo(ReactSystemFunctions.value(this, (stateVars.TM_TopManagerDashboardLeadList !== undefined ? (stateVars.TM_TopManagerDashboardLeadList?.length > 0 ? stateVars.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null) : (this.state.TM_TopManagerDashboardLeadList?.length > 0 ? this.state.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null))), ReactSystemFunctions.convertToTypeByName("7", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp698275Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, (stateVars.TM_TopManagerDashboardLeadList !== undefined ? (stateVars.TM_TopManagerDashboardLeadList?.length > 0 ? stateVars.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null) : (this.state.TM_TopManagerDashboardLeadList?.length > 0 ? this.state.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null))), ReactSystemFunctions.convertToTypeByName("7", "string"))) === true ? "visible" : "hidden")
			this.props.form?.setFieldsValue(formVars);
			
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.DashBoardTempManagerComponent_693403_onClick1_();
                  resolve();
                });
          })



        
        KuikaAppManager.hideSpinner(this);
        return isErrorOccurred;
    }
		DashBoardTempManagerComponent_693403_onClick1_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }

				
				stateVars.dataSource_827135 = stateVars.TM_TopManagerDashboardLeadList ?? this.state.TM_TopManagerDashboardLeadList;

		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

            
            return isErrorOccurred;
        }




    DashBoardTempManagerComponent_77242_onClick = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
		KuikaAppManager.increaseServerRequestCount();

        let localVar = {
				UserId_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.getMyUserId(), "Guid"),
				MusteriAdi_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "dashboardtempmanager_666343_value", "value", "", "", "")), "string"),
				ProductName_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "dashboardtempmanager_153369_value", "value", "", "", "")), "string"),
				LeadCode_0: ReactSystemFunctions.convertToTypeByName(null, "string"),
				Tel_0: ReactSystemFunctions.convertToTypeByName(null, "string"),
				CategoryName_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "dashboardtempmanager_731364_value", "value", "TM_GetProductCategory", "categoryCode", "categoryName")), "string"),
				StoreIds_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "dashboardtempmanager_453042_value", "value", "TM_GetStore", "id", "id")), "string"),
				SatisDanismaniIds_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "dashboardtempmanager_425161_value", "value", "TM_GetSalesPerson", "kUserId", "kUserId")), "string"),
				ProcessCode_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "dashboardtempmanager_274478_value", "value", "TM_GetLeadProcess", "id", "code")), "string"),
				StepOrder_0: ReactSystemFunctions.convertToTypeByName(-1, "number"),
				StartDate_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "dashboardtempmanager_138929_value", "value", "", "", "")), "Date"),
				EndDate_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "dashboardtempmanager_381090_value", "value", "", "", "")), "Date")
        }

		KuikaAppManager.showSpinner(this);
		
        if (true) {
        KuikaAppManager.showSpinner(this);
        }
        let result = await KuikaAppManager.ApiRequest(this, "DashBoardTempManager/DashBoardTempManagerComponent_77242_onClick", localVar)
        if (!KMainFunctions.IsResStatus2XX(result)) return true;

			stateVars.TM_TopManagerDashboardLeadList = result?.data.tM_TopManagerDashboardLeadList;
			
			stateVars.isComp20059Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, (stateVars.TM_TopManagerDashboardLeadList !== undefined ? (stateVars.TM_TopManagerDashboardLeadList?.length > 0 ? stateVars.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null) : (this.state.TM_TopManagerDashboardLeadList?.length > 0 ? this.state.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null))), ReactSystemFunctions.convertToTypeByName("0", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp693403Visible = ((ReactSystemFunctions.isNotEqualTo(ReactSystemFunctions.value(this, (stateVars.TM_TopManagerDashboardLeadList !== undefined ? (stateVars.TM_TopManagerDashboardLeadList?.length > 0 ? stateVars.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null) : (this.state.TM_TopManagerDashboardLeadList?.length > 0 ? this.state.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null))), ReactSystemFunctions.convertToTypeByName("0", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp77242Visible = ((ReactSystemFunctions.isNotEqualTo(ReactSystemFunctions.value(this, (stateVars.TM_TopManagerDashboardLeadList !== undefined ? (stateVars.TM_TopManagerDashboardLeadList?.length > 0 ? stateVars.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null) : (this.state.TM_TopManagerDashboardLeadList?.length > 0 ? this.state.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null))), ReactSystemFunctions.convertToTypeByName("-1", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp352710Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, (stateVars.TM_TopManagerDashboardLeadList !== undefined ? (stateVars.TM_TopManagerDashboardLeadList?.length > 0 ? stateVars.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null) : (this.state.TM_TopManagerDashboardLeadList?.length > 0 ? this.state.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null))), ReactSystemFunctions.convertToTypeByName("-1", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp744094Visible = ((ReactSystemFunctions.isNotEqualTo(ReactSystemFunctions.value(this, (stateVars.TM_TopManagerDashboardLeadList !== undefined ? (stateVars.TM_TopManagerDashboardLeadList?.length > 0 ? stateVars.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null) : (this.state.TM_TopManagerDashboardLeadList?.length > 0 ? this.state.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null))), ReactSystemFunctions.convertToTypeByName("-2", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp558447Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, (stateVars.TM_TopManagerDashboardLeadList !== undefined ? (stateVars.TM_TopManagerDashboardLeadList?.length > 0 ? stateVars.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null) : (this.state.TM_TopManagerDashboardLeadList?.length > 0 ? this.state.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null))), ReactSystemFunctions.convertToTypeByName("-2", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp551457Visible = ((ReactSystemFunctions.isNotEqualTo(ReactSystemFunctions.value(this, (stateVars.TM_TopManagerDashboardLeadList !== undefined ? (stateVars.TM_TopManagerDashboardLeadList?.length > 0 ? stateVars.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null) : (this.state.TM_TopManagerDashboardLeadList?.length > 0 ? this.state.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null))), ReactSystemFunctions.convertToTypeByName("-3", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp862838Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, (stateVars.TM_TopManagerDashboardLeadList !== undefined ? (stateVars.TM_TopManagerDashboardLeadList?.length > 0 ? stateVars.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null) : (this.state.TM_TopManagerDashboardLeadList?.length > 0 ? this.state.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null))), ReactSystemFunctions.convertToTypeByName("-3", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp4159Visible = ((ReactSystemFunctions.isNotEqualTo(ReactSystemFunctions.value(this, (stateVars.TM_TopManagerDashboardLeadList !== undefined ? (stateVars.TM_TopManagerDashboardLeadList?.length > 0 ? stateVars.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null) : (this.state.TM_TopManagerDashboardLeadList?.length > 0 ? this.state.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null))), ReactSystemFunctions.convertToTypeByName("2", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp170471Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, (stateVars.TM_TopManagerDashboardLeadList !== undefined ? (stateVars.TM_TopManagerDashboardLeadList?.length > 0 ? stateVars.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null) : (this.state.TM_TopManagerDashboardLeadList?.length > 0 ? this.state.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null))), ReactSystemFunctions.convertToTypeByName("2", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp397882Visible = ((ReactSystemFunctions.isNotEqualTo(ReactSystemFunctions.value(this, (stateVars.TM_TopManagerDashboardLeadList !== undefined ? (stateVars.TM_TopManagerDashboardLeadList?.length > 0 ? stateVars.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null) : (this.state.TM_TopManagerDashboardLeadList?.length > 0 ? this.state.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null))), ReactSystemFunctions.convertToTypeByName("3", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp941736Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, (stateVars.TM_TopManagerDashboardLeadList !== undefined ? (stateVars.TM_TopManagerDashboardLeadList?.length > 0 ? stateVars.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null) : (this.state.TM_TopManagerDashboardLeadList?.length > 0 ? this.state.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null))), ReactSystemFunctions.convertToTypeByName("3", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp489263Visible = ((ReactSystemFunctions.isNotEqualTo(ReactSystemFunctions.value(this, (stateVars.TM_TopManagerDashboardLeadList !== undefined ? (stateVars.TM_TopManagerDashboardLeadList?.length > 0 ? stateVars.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null) : (this.state.TM_TopManagerDashboardLeadList?.length > 0 ? this.state.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null))), ReactSystemFunctions.convertToTypeByName("10", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp675337Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, (stateVars.TM_TopManagerDashboardLeadList !== undefined ? (stateVars.TM_TopManagerDashboardLeadList?.length > 0 ? stateVars.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null) : (this.state.TM_TopManagerDashboardLeadList?.length > 0 ? this.state.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null))), ReactSystemFunctions.convertToTypeByName("10", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp654813Visible = ((ReactSystemFunctions.isNotEqualTo(ReactSystemFunctions.value(this, (stateVars.TM_TopManagerDashboardLeadList !== undefined ? (stateVars.TM_TopManagerDashboardLeadList?.length > 0 ? stateVars.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null) : (this.state.TM_TopManagerDashboardLeadList?.length > 0 ? this.state.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null))), ReactSystemFunctions.convertToTypeByName("6", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp804552Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, (stateVars.TM_TopManagerDashboardLeadList !== undefined ? (stateVars.TM_TopManagerDashboardLeadList?.length > 0 ? stateVars.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null) : (this.state.TM_TopManagerDashboardLeadList?.length > 0 ? this.state.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null))), ReactSystemFunctions.convertToTypeByName("6", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp371503Visible = ((ReactSystemFunctions.isNotEqualTo(ReactSystemFunctions.value(this, (stateVars.TM_TopManagerDashboardLeadList !== undefined ? (stateVars.TM_TopManagerDashboardLeadList?.length > 0 ? stateVars.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null) : (this.state.TM_TopManagerDashboardLeadList?.length > 0 ? this.state.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null))), ReactSystemFunctions.convertToTypeByName("7", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp698275Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, (stateVars.TM_TopManagerDashboardLeadList !== undefined ? (stateVars.TM_TopManagerDashboardLeadList?.length > 0 ? stateVars.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null) : (this.state.TM_TopManagerDashboardLeadList?.length > 0 ? this.state.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null))), ReactSystemFunctions.convertToTypeByName("7", "string"))) === true ? "visible" : "hidden")
			this.props.form?.setFieldsValue(formVars);
			
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.DashBoardTempManagerComponent_77242_onClick1_();
                  resolve();
                });
          })



        
        KuikaAppManager.hideSpinner(this);
        return isErrorOccurred;
    }
		DashBoardTempManagerComponent_77242_onClick1_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }

				
				stateVars.dataSource_827135 = stateVars.TM_TopManagerDashboardLeadList ?? this.state.TM_TopManagerDashboardLeadList;

		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

            
            return isErrorOccurred;
        }




    DashBoardTempManagerComponent_744094_onClick = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
		KuikaAppManager.increaseServerRequestCount();

        let localVar = {
				UserId_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.getMyUserId(), "Guid"),
				MusteriAdi_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "dashboardtempmanager_666343_value", "value", "", "", "")), "string"),
				ProductName_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "dashboardtempmanager_153369_value", "value", "", "", "")), "string"),
				LeadCode_0: ReactSystemFunctions.convertToTypeByName(null, "string"),
				Tel_0: ReactSystemFunctions.convertToTypeByName(null, "string"),
				CategoryName_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "dashboardtempmanager_731364_value", "value", "TM_GetProductCategory", "categoryCode", "categoryName")), "string"),
				StoreIds_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "dashboardtempmanager_453042_value", "value", "TM_GetStore", "id", "id")), "string"),
				SatisDanismaniIds_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "dashboardtempmanager_425161_value", "value", "TM_GetSalesPerson", "kUserId", "kUserId")), "string"),
				ProcessCode_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "dashboardtempmanager_274478_value", "value", "TM_GetLeadProcess", "id", "code")), "string"),
				StepOrder_0: ReactSystemFunctions.convertToTypeByName(-2, "number"),
				StartDate_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "dashboardtempmanager_138929_value", "value", "", "", "")), "Date"),
				EndDate_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "dashboardtempmanager_381090_value", "value", "", "", "")), "Date")
        }

		KuikaAppManager.showSpinner(this);
		
        if (true) {
        KuikaAppManager.showSpinner(this);
        }
        let result = await KuikaAppManager.ApiRequest(this, "DashBoardTempManager/DashBoardTempManagerComponent_744094_onClick", localVar)
        if (!KMainFunctions.IsResStatus2XX(result)) return true;

			stateVars.TM_TopManagerDashboardLeadList = result?.data.tM_TopManagerDashboardLeadList;
			
			stateVars.isComp20059Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, (stateVars.TM_TopManagerDashboardLeadList !== undefined ? (stateVars.TM_TopManagerDashboardLeadList?.length > 0 ? stateVars.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null) : (this.state.TM_TopManagerDashboardLeadList?.length > 0 ? this.state.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null))), ReactSystemFunctions.convertToTypeByName("0", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp693403Visible = ((ReactSystemFunctions.isNotEqualTo(ReactSystemFunctions.value(this, (stateVars.TM_TopManagerDashboardLeadList !== undefined ? (stateVars.TM_TopManagerDashboardLeadList?.length > 0 ? stateVars.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null) : (this.state.TM_TopManagerDashboardLeadList?.length > 0 ? this.state.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null))), ReactSystemFunctions.convertToTypeByName("0", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp77242Visible = ((ReactSystemFunctions.isNotEqualTo(ReactSystemFunctions.value(this, (stateVars.TM_TopManagerDashboardLeadList !== undefined ? (stateVars.TM_TopManagerDashboardLeadList?.length > 0 ? stateVars.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null) : (this.state.TM_TopManagerDashboardLeadList?.length > 0 ? this.state.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null))), ReactSystemFunctions.convertToTypeByName("-1", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp352710Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, (stateVars.TM_TopManagerDashboardLeadList !== undefined ? (stateVars.TM_TopManagerDashboardLeadList?.length > 0 ? stateVars.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null) : (this.state.TM_TopManagerDashboardLeadList?.length > 0 ? this.state.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null))), ReactSystemFunctions.convertToTypeByName("-1", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp744094Visible = ((ReactSystemFunctions.isNotEqualTo(ReactSystemFunctions.value(this, (stateVars.TM_TopManagerDashboardLeadList !== undefined ? (stateVars.TM_TopManagerDashboardLeadList?.length > 0 ? stateVars.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null) : (this.state.TM_TopManagerDashboardLeadList?.length > 0 ? this.state.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null))), ReactSystemFunctions.convertToTypeByName("-2", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp558447Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, (stateVars.TM_TopManagerDashboardLeadList !== undefined ? (stateVars.TM_TopManagerDashboardLeadList?.length > 0 ? stateVars.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null) : (this.state.TM_TopManagerDashboardLeadList?.length > 0 ? this.state.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null))), ReactSystemFunctions.convertToTypeByName("-2", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp551457Visible = ((ReactSystemFunctions.isNotEqualTo(ReactSystemFunctions.value(this, (stateVars.TM_TopManagerDashboardLeadList !== undefined ? (stateVars.TM_TopManagerDashboardLeadList?.length > 0 ? stateVars.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null) : (this.state.TM_TopManagerDashboardLeadList?.length > 0 ? this.state.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null))), ReactSystemFunctions.convertToTypeByName("-3", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp862838Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, (stateVars.TM_TopManagerDashboardLeadList !== undefined ? (stateVars.TM_TopManagerDashboardLeadList?.length > 0 ? stateVars.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null) : (this.state.TM_TopManagerDashboardLeadList?.length > 0 ? this.state.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null))), ReactSystemFunctions.convertToTypeByName("-3", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp4159Visible = ((ReactSystemFunctions.isNotEqualTo(ReactSystemFunctions.value(this, (stateVars.TM_TopManagerDashboardLeadList !== undefined ? (stateVars.TM_TopManagerDashboardLeadList?.length > 0 ? stateVars.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null) : (this.state.TM_TopManagerDashboardLeadList?.length > 0 ? this.state.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null))), ReactSystemFunctions.convertToTypeByName("2", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp170471Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, (stateVars.TM_TopManagerDashboardLeadList !== undefined ? (stateVars.TM_TopManagerDashboardLeadList?.length > 0 ? stateVars.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null) : (this.state.TM_TopManagerDashboardLeadList?.length > 0 ? this.state.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null))), ReactSystemFunctions.convertToTypeByName("2", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp397882Visible = ((ReactSystemFunctions.isNotEqualTo(ReactSystemFunctions.value(this, (stateVars.TM_TopManagerDashboardLeadList !== undefined ? (stateVars.TM_TopManagerDashboardLeadList?.length > 0 ? stateVars.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null) : (this.state.TM_TopManagerDashboardLeadList?.length > 0 ? this.state.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null))), ReactSystemFunctions.convertToTypeByName("3", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp941736Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, (stateVars.TM_TopManagerDashboardLeadList !== undefined ? (stateVars.TM_TopManagerDashboardLeadList?.length > 0 ? stateVars.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null) : (this.state.TM_TopManagerDashboardLeadList?.length > 0 ? this.state.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null))), ReactSystemFunctions.convertToTypeByName("3", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp489263Visible = ((ReactSystemFunctions.isNotEqualTo(ReactSystemFunctions.value(this, (stateVars.TM_TopManagerDashboardLeadList !== undefined ? (stateVars.TM_TopManagerDashboardLeadList?.length > 0 ? stateVars.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null) : (this.state.TM_TopManagerDashboardLeadList?.length > 0 ? this.state.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null))), ReactSystemFunctions.convertToTypeByName("10", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp675337Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, (stateVars.TM_TopManagerDashboardLeadList !== undefined ? (stateVars.TM_TopManagerDashboardLeadList?.length > 0 ? stateVars.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null) : (this.state.TM_TopManagerDashboardLeadList?.length > 0 ? this.state.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null))), ReactSystemFunctions.convertToTypeByName("10", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp654813Visible = ((ReactSystemFunctions.isNotEqualTo(ReactSystemFunctions.value(this, (stateVars.TM_TopManagerDashboardLeadList !== undefined ? (stateVars.TM_TopManagerDashboardLeadList?.length > 0 ? stateVars.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null) : (this.state.TM_TopManagerDashboardLeadList?.length > 0 ? this.state.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null))), ReactSystemFunctions.convertToTypeByName("6", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp804552Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, (stateVars.TM_TopManagerDashboardLeadList !== undefined ? (stateVars.TM_TopManagerDashboardLeadList?.length > 0 ? stateVars.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null) : (this.state.TM_TopManagerDashboardLeadList?.length > 0 ? this.state.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null))), ReactSystemFunctions.convertToTypeByName("6", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp371503Visible = ((ReactSystemFunctions.isNotEqualTo(ReactSystemFunctions.value(this, (stateVars.TM_TopManagerDashboardLeadList !== undefined ? (stateVars.TM_TopManagerDashboardLeadList?.length > 0 ? stateVars.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null) : (this.state.TM_TopManagerDashboardLeadList?.length > 0 ? this.state.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null))), ReactSystemFunctions.convertToTypeByName("7", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp698275Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, (stateVars.TM_TopManagerDashboardLeadList !== undefined ? (stateVars.TM_TopManagerDashboardLeadList?.length > 0 ? stateVars.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null) : (this.state.TM_TopManagerDashboardLeadList?.length > 0 ? this.state.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null))), ReactSystemFunctions.convertToTypeByName("7", "string"))) === true ? "visible" : "hidden")
			this.props.form?.setFieldsValue(formVars);
			
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.DashBoardTempManagerComponent_744094_onClick1_();
                  resolve();
                });
          })



        
        KuikaAppManager.hideSpinner(this);
        return isErrorOccurred;
    }
		DashBoardTempManagerComponent_744094_onClick1_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }

				
				stateVars.dataSource_827135 = stateVars.TM_TopManagerDashboardLeadList ?? this.state.TM_TopManagerDashboardLeadList;

		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

            
            return isErrorOccurred;
        }




    DashBoardTempManagerComponent_551457_onClick = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
		KuikaAppManager.increaseServerRequestCount();

        let localVar = {
				UserId_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.getMyUserId(), "Guid"),
				MusteriAdi_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "dashboardtempmanager_666343_value", "value", "", "", "")), "string"),
				ProductName_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "dashboardtempmanager_153369_value", "value", "", "", "")), "string"),
				LeadCode_0: ReactSystemFunctions.convertToTypeByName(null, "string"),
				Tel_0: ReactSystemFunctions.convertToTypeByName(null, "string"),
				CategoryName_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "dashboardtempmanager_731364_value", "value", "TM_GetProductCategory", "categoryCode", "categoryName")), "string"),
				StoreIds_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "dashboardtempmanager_453042_value", "value", "TM_GetStore", "id", "id")), "string"),
				SatisDanismaniIds_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "dashboardtempmanager_425161_value", "value", "TM_GetSalesPerson", "kUserId", "kUserId")), "string"),
				ProcessCode_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "dashboardtempmanager_274478_value", "value", "TM_GetLeadProcess", "id", "code")), "string"),
				StepOrder_0: ReactSystemFunctions.convertToTypeByName(-3, "number"),
				StartDate_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "dashboardtempmanager_138929_value", "value", "", "", "")), "Date"),
				EndDate_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "dashboardtempmanager_381090_value", "value", "", "", "")), "Date")
        }

		KuikaAppManager.showSpinner(this);
		
        if (true) {
        KuikaAppManager.showSpinner(this);
        }
        let result = await KuikaAppManager.ApiRequest(this, "DashBoardTempManager/DashBoardTempManagerComponent_551457_onClick", localVar)
        if (!KMainFunctions.IsResStatus2XX(result)) return true;

			stateVars.TM_TopManagerDashboardLeadList = result?.data.tM_TopManagerDashboardLeadList;
			
			stateVars.isComp20059Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, (stateVars.TM_TopManagerDashboardLeadList !== undefined ? (stateVars.TM_TopManagerDashboardLeadList?.length > 0 ? stateVars.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null) : (this.state.TM_TopManagerDashboardLeadList?.length > 0 ? this.state.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null))), ReactSystemFunctions.convertToTypeByName("0", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp693403Visible = ((ReactSystemFunctions.isNotEqualTo(ReactSystemFunctions.value(this, (stateVars.TM_TopManagerDashboardLeadList !== undefined ? (stateVars.TM_TopManagerDashboardLeadList?.length > 0 ? stateVars.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null) : (this.state.TM_TopManagerDashboardLeadList?.length > 0 ? this.state.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null))), ReactSystemFunctions.convertToTypeByName("0", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp77242Visible = ((ReactSystemFunctions.isNotEqualTo(ReactSystemFunctions.value(this, (stateVars.TM_TopManagerDashboardLeadList !== undefined ? (stateVars.TM_TopManagerDashboardLeadList?.length > 0 ? stateVars.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null) : (this.state.TM_TopManagerDashboardLeadList?.length > 0 ? this.state.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null))), ReactSystemFunctions.convertToTypeByName("-1", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp352710Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, (stateVars.TM_TopManagerDashboardLeadList !== undefined ? (stateVars.TM_TopManagerDashboardLeadList?.length > 0 ? stateVars.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null) : (this.state.TM_TopManagerDashboardLeadList?.length > 0 ? this.state.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null))), ReactSystemFunctions.convertToTypeByName("-1", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp744094Visible = ((ReactSystemFunctions.isNotEqualTo(ReactSystemFunctions.value(this, (stateVars.TM_TopManagerDashboardLeadList !== undefined ? (stateVars.TM_TopManagerDashboardLeadList?.length > 0 ? stateVars.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null) : (this.state.TM_TopManagerDashboardLeadList?.length > 0 ? this.state.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null))), ReactSystemFunctions.convertToTypeByName("-2", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp558447Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, (stateVars.TM_TopManagerDashboardLeadList !== undefined ? (stateVars.TM_TopManagerDashboardLeadList?.length > 0 ? stateVars.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null) : (this.state.TM_TopManagerDashboardLeadList?.length > 0 ? this.state.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null))), ReactSystemFunctions.convertToTypeByName("-2", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp551457Visible = ((ReactSystemFunctions.isNotEqualTo(ReactSystemFunctions.value(this, (stateVars.TM_TopManagerDashboardLeadList !== undefined ? (stateVars.TM_TopManagerDashboardLeadList?.length > 0 ? stateVars.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null) : (this.state.TM_TopManagerDashboardLeadList?.length > 0 ? this.state.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null))), ReactSystemFunctions.convertToTypeByName("-3", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp862838Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, (stateVars.TM_TopManagerDashboardLeadList !== undefined ? (stateVars.TM_TopManagerDashboardLeadList?.length > 0 ? stateVars.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null) : (this.state.TM_TopManagerDashboardLeadList?.length > 0 ? this.state.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null))), ReactSystemFunctions.convertToTypeByName("-3", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp4159Visible = ((ReactSystemFunctions.isNotEqualTo(ReactSystemFunctions.value(this, (stateVars.TM_TopManagerDashboardLeadList !== undefined ? (stateVars.TM_TopManagerDashboardLeadList?.length > 0 ? stateVars.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null) : (this.state.TM_TopManagerDashboardLeadList?.length > 0 ? this.state.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null))), ReactSystemFunctions.convertToTypeByName("2", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp170471Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, (stateVars.TM_TopManagerDashboardLeadList !== undefined ? (stateVars.TM_TopManagerDashboardLeadList?.length > 0 ? stateVars.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null) : (this.state.TM_TopManagerDashboardLeadList?.length > 0 ? this.state.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null))), ReactSystemFunctions.convertToTypeByName("2", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp397882Visible = ((ReactSystemFunctions.isNotEqualTo(ReactSystemFunctions.value(this, (stateVars.TM_TopManagerDashboardLeadList !== undefined ? (stateVars.TM_TopManagerDashboardLeadList?.length > 0 ? stateVars.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null) : (this.state.TM_TopManagerDashboardLeadList?.length > 0 ? this.state.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null))), ReactSystemFunctions.convertToTypeByName("3", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp941736Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, (stateVars.TM_TopManagerDashboardLeadList !== undefined ? (stateVars.TM_TopManagerDashboardLeadList?.length > 0 ? stateVars.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null) : (this.state.TM_TopManagerDashboardLeadList?.length > 0 ? this.state.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null))), ReactSystemFunctions.convertToTypeByName("3", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp489263Visible = ((ReactSystemFunctions.isNotEqualTo(ReactSystemFunctions.value(this, (stateVars.TM_TopManagerDashboardLeadList !== undefined ? (stateVars.TM_TopManagerDashboardLeadList?.length > 0 ? stateVars.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null) : (this.state.TM_TopManagerDashboardLeadList?.length > 0 ? this.state.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null))), ReactSystemFunctions.convertToTypeByName("10", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp675337Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, (stateVars.TM_TopManagerDashboardLeadList !== undefined ? (stateVars.TM_TopManagerDashboardLeadList?.length > 0 ? stateVars.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null) : (this.state.TM_TopManagerDashboardLeadList?.length > 0 ? this.state.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null))), ReactSystemFunctions.convertToTypeByName("10", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp654813Visible = ((ReactSystemFunctions.isNotEqualTo(ReactSystemFunctions.value(this, (stateVars.TM_TopManagerDashboardLeadList !== undefined ? (stateVars.TM_TopManagerDashboardLeadList?.length > 0 ? stateVars.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null) : (this.state.TM_TopManagerDashboardLeadList?.length > 0 ? this.state.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null))), ReactSystemFunctions.convertToTypeByName("6", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp804552Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, (stateVars.TM_TopManagerDashboardLeadList !== undefined ? (stateVars.TM_TopManagerDashboardLeadList?.length > 0 ? stateVars.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null) : (this.state.TM_TopManagerDashboardLeadList?.length > 0 ? this.state.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null))), ReactSystemFunctions.convertToTypeByName("6", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp371503Visible = ((ReactSystemFunctions.isNotEqualTo(ReactSystemFunctions.value(this, (stateVars.TM_TopManagerDashboardLeadList !== undefined ? (stateVars.TM_TopManagerDashboardLeadList?.length > 0 ? stateVars.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null) : (this.state.TM_TopManagerDashboardLeadList?.length > 0 ? this.state.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null))), ReactSystemFunctions.convertToTypeByName("7", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp698275Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, (stateVars.TM_TopManagerDashboardLeadList !== undefined ? (stateVars.TM_TopManagerDashboardLeadList?.length > 0 ? stateVars.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null) : (this.state.TM_TopManagerDashboardLeadList?.length > 0 ? this.state.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null))), ReactSystemFunctions.convertToTypeByName("7", "string"))) === true ? "visible" : "hidden")
			this.props.form?.setFieldsValue(formVars);
			
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.DashBoardTempManagerComponent_551457_onClick1_();
                  resolve();
                });
          })



        
        KuikaAppManager.hideSpinner(this);
        return isErrorOccurred;
    }
		DashBoardTempManagerComponent_551457_onClick1_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }

				
				stateVars.dataSource_827135 = stateVars.TM_TopManagerDashboardLeadList ?? this.state.TM_TopManagerDashboardLeadList;

		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

            
            return isErrorOccurred;
        }




    DashBoardTempManagerComponent_4159_onClick = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
		KuikaAppManager.increaseServerRequestCount();

        let localVar = {
				UserId_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.getMyUserId(), "Guid"),
				MusteriAdi_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "dashboardtempmanager_666343_value", "value", "", "", "")), "string"),
				ProductName_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "dashboardtempmanager_153369_value", "value", "", "", "")), "string"),
				LeadCode_0: ReactSystemFunctions.convertToTypeByName(null, "string"),
				Tel_0: ReactSystemFunctions.convertToTypeByName(null, "string"),
				CategoryName_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "dashboardtempmanager_731364_value", "value", "TM_GetProductCategory", "categoryCode", "categoryName")), "string"),
				StoreIds_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "dashboardtempmanager_453042_value", "value", "TM_GetStore", "id", "id")), "string"),
				SatisDanismaniIds_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "dashboardtempmanager_425161_value", "value", "TM_GetSalesPerson", "kUserId", "kUserId")), "string"),
				ProcessCode_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "dashboardtempmanager_274478_value", "value", "TM_GetLeadProcess", "id", "code")), "string"),
				StepOrder_0: ReactSystemFunctions.convertToTypeByName(2, "number"),
				StartDate_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "dashboardtempmanager_138929_value", "value", "", "", "")), "Date"),
				EndDate_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "dashboardtempmanager_381090_value", "value", "", "", "")), "Date")
        }

		KuikaAppManager.showSpinner(this);
		
        if (true) {
        KuikaAppManager.showSpinner(this);
        }
        let result = await KuikaAppManager.ApiRequest(this, "DashBoardTempManager/DashBoardTempManagerComponent_4159_onClick", localVar)
        if (!KMainFunctions.IsResStatus2XX(result)) return true;

			stateVars.TM_TopManagerDashboardLeadList = result?.data.tM_TopManagerDashboardLeadList;
			
			stateVars.isComp20059Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, (stateVars.TM_TopManagerDashboardLeadList !== undefined ? (stateVars.TM_TopManagerDashboardLeadList?.length > 0 ? stateVars.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null) : (this.state.TM_TopManagerDashboardLeadList?.length > 0 ? this.state.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null))), ReactSystemFunctions.convertToTypeByName("0", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp693403Visible = ((ReactSystemFunctions.isNotEqualTo(ReactSystemFunctions.value(this, (stateVars.TM_TopManagerDashboardLeadList !== undefined ? (stateVars.TM_TopManagerDashboardLeadList?.length > 0 ? stateVars.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null) : (this.state.TM_TopManagerDashboardLeadList?.length > 0 ? this.state.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null))), ReactSystemFunctions.convertToTypeByName("0", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp77242Visible = ((ReactSystemFunctions.isNotEqualTo(ReactSystemFunctions.value(this, (stateVars.TM_TopManagerDashboardLeadList !== undefined ? (stateVars.TM_TopManagerDashboardLeadList?.length > 0 ? stateVars.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null) : (this.state.TM_TopManagerDashboardLeadList?.length > 0 ? this.state.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null))), ReactSystemFunctions.convertToTypeByName("-1", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp352710Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, (stateVars.TM_TopManagerDashboardLeadList !== undefined ? (stateVars.TM_TopManagerDashboardLeadList?.length > 0 ? stateVars.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null) : (this.state.TM_TopManagerDashboardLeadList?.length > 0 ? this.state.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null))), ReactSystemFunctions.convertToTypeByName("-1", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp744094Visible = ((ReactSystemFunctions.isNotEqualTo(ReactSystemFunctions.value(this, (stateVars.TM_TopManagerDashboardLeadList !== undefined ? (stateVars.TM_TopManagerDashboardLeadList?.length > 0 ? stateVars.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null) : (this.state.TM_TopManagerDashboardLeadList?.length > 0 ? this.state.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null))), ReactSystemFunctions.convertToTypeByName("-2", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp558447Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, (stateVars.TM_TopManagerDashboardLeadList !== undefined ? (stateVars.TM_TopManagerDashboardLeadList?.length > 0 ? stateVars.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null) : (this.state.TM_TopManagerDashboardLeadList?.length > 0 ? this.state.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null))), ReactSystemFunctions.convertToTypeByName("-2", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp551457Visible = ((ReactSystemFunctions.isNotEqualTo(ReactSystemFunctions.value(this, (stateVars.TM_TopManagerDashboardLeadList !== undefined ? (stateVars.TM_TopManagerDashboardLeadList?.length > 0 ? stateVars.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null) : (this.state.TM_TopManagerDashboardLeadList?.length > 0 ? this.state.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null))), ReactSystemFunctions.convertToTypeByName("-3", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp862838Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, (stateVars.TM_TopManagerDashboardLeadList !== undefined ? (stateVars.TM_TopManagerDashboardLeadList?.length > 0 ? stateVars.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null) : (this.state.TM_TopManagerDashboardLeadList?.length > 0 ? this.state.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null))), ReactSystemFunctions.convertToTypeByName("-3", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp4159Visible = ((ReactSystemFunctions.isNotEqualTo(ReactSystemFunctions.value(this, (stateVars.TM_TopManagerDashboardLeadList !== undefined ? (stateVars.TM_TopManagerDashboardLeadList?.length > 0 ? stateVars.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null) : (this.state.TM_TopManagerDashboardLeadList?.length > 0 ? this.state.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null))), ReactSystemFunctions.convertToTypeByName("2", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp170471Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, (stateVars.TM_TopManagerDashboardLeadList !== undefined ? (stateVars.TM_TopManagerDashboardLeadList?.length > 0 ? stateVars.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null) : (this.state.TM_TopManagerDashboardLeadList?.length > 0 ? this.state.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null))), ReactSystemFunctions.convertToTypeByName("2", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp397882Visible = ((ReactSystemFunctions.isNotEqualTo(ReactSystemFunctions.value(this, (stateVars.TM_TopManagerDashboardLeadList !== undefined ? (stateVars.TM_TopManagerDashboardLeadList?.length > 0 ? stateVars.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null) : (this.state.TM_TopManagerDashboardLeadList?.length > 0 ? this.state.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null))), ReactSystemFunctions.convertToTypeByName("3", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp941736Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, (stateVars.TM_TopManagerDashboardLeadList !== undefined ? (stateVars.TM_TopManagerDashboardLeadList?.length > 0 ? stateVars.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null) : (this.state.TM_TopManagerDashboardLeadList?.length > 0 ? this.state.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null))), ReactSystemFunctions.convertToTypeByName("3", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp489263Visible = ((ReactSystemFunctions.isNotEqualTo(ReactSystemFunctions.value(this, (stateVars.TM_TopManagerDashboardLeadList !== undefined ? (stateVars.TM_TopManagerDashboardLeadList?.length > 0 ? stateVars.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null) : (this.state.TM_TopManagerDashboardLeadList?.length > 0 ? this.state.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null))), ReactSystemFunctions.convertToTypeByName("10", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp675337Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, (stateVars.TM_TopManagerDashboardLeadList !== undefined ? (stateVars.TM_TopManagerDashboardLeadList?.length > 0 ? stateVars.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null) : (this.state.TM_TopManagerDashboardLeadList?.length > 0 ? this.state.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null))), ReactSystemFunctions.convertToTypeByName("10", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp654813Visible = ((ReactSystemFunctions.isNotEqualTo(ReactSystemFunctions.value(this, (stateVars.TM_TopManagerDashboardLeadList !== undefined ? (stateVars.TM_TopManagerDashboardLeadList?.length > 0 ? stateVars.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null) : (this.state.TM_TopManagerDashboardLeadList?.length > 0 ? this.state.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null))), ReactSystemFunctions.convertToTypeByName("6", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp804552Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, (stateVars.TM_TopManagerDashboardLeadList !== undefined ? (stateVars.TM_TopManagerDashboardLeadList?.length > 0 ? stateVars.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null) : (this.state.TM_TopManagerDashboardLeadList?.length > 0 ? this.state.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null))), ReactSystemFunctions.convertToTypeByName("6", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp371503Visible = ((ReactSystemFunctions.isNotEqualTo(ReactSystemFunctions.value(this, (stateVars.TM_TopManagerDashboardLeadList !== undefined ? (stateVars.TM_TopManagerDashboardLeadList?.length > 0 ? stateVars.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null) : (this.state.TM_TopManagerDashboardLeadList?.length > 0 ? this.state.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null))), ReactSystemFunctions.convertToTypeByName("7", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp698275Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, (stateVars.TM_TopManagerDashboardLeadList !== undefined ? (stateVars.TM_TopManagerDashboardLeadList?.length > 0 ? stateVars.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null) : (this.state.TM_TopManagerDashboardLeadList?.length > 0 ? this.state.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null))), ReactSystemFunctions.convertToTypeByName("7", "string"))) === true ? "visible" : "hidden")
			this.props.form?.setFieldsValue(formVars);
			
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.DashBoardTempManagerComponent_4159_onClick1_();
                  resolve();
                });
          })



        
        KuikaAppManager.hideSpinner(this);
        return isErrorOccurred;
    }
		DashBoardTempManagerComponent_4159_onClick1_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }

				
				stateVars.dataSource_827135 = stateVars.TM_TopManagerDashboardLeadList ?? this.state.TM_TopManagerDashboardLeadList;

		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

            
            return isErrorOccurred;
        }




    DashBoardTempManagerComponent_397882_onClick = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
		KuikaAppManager.increaseServerRequestCount();

        let localVar = {
				UserId_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.getMyUserId(), "Guid"),
				MusteriAdi_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "dashboardtempmanager_666343_value", "value", "", "", "")), "string"),
				ProductName_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "dashboardtempmanager_153369_value", "value", "", "", "")), "string"),
				LeadCode_0: ReactSystemFunctions.convertToTypeByName(null, "string"),
				Tel_0: ReactSystemFunctions.convertToTypeByName(null, "string"),
				CategoryName_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "dashboardtempmanager_731364_value", "value", "TM_GetProductCategory", "categoryCode", "categoryName")), "string"),
				StoreIds_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "dashboardtempmanager_453042_value", "value", "TM_GetStore", "id", "id")), "string"),
				SatisDanismaniIds_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "dashboardtempmanager_425161_value", "value", "TM_GetSalesPerson", "kUserId", "kUserId")), "string"),
				ProcessCode_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "dashboardtempmanager_274478_value", "value", "TM_GetLeadProcess", "id", "code")), "string"),
				StepOrder_0: ReactSystemFunctions.convertToTypeByName(3, "number"),
				StartDate_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "dashboardtempmanager_138929_value", "value", "", "", "")), "Date"),
				EndDate_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "dashboardtempmanager_381090_value", "value", "", "", "")), "Date")
        }

		KuikaAppManager.showSpinner(this);
		
        if (true) {
        KuikaAppManager.showSpinner(this);
        }
        let result = await KuikaAppManager.ApiRequest(this, "DashBoardTempManager/DashBoardTempManagerComponent_397882_onClick", localVar)
        if (!KMainFunctions.IsResStatus2XX(result)) return true;

			stateVars.TM_TopManagerDashboardLeadList = result?.data.tM_TopManagerDashboardLeadList;
			
			stateVars.isComp20059Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, (stateVars.TM_TopManagerDashboardLeadList !== undefined ? (stateVars.TM_TopManagerDashboardLeadList?.length > 0 ? stateVars.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null) : (this.state.TM_TopManagerDashboardLeadList?.length > 0 ? this.state.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null))), ReactSystemFunctions.convertToTypeByName("0", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp693403Visible = ((ReactSystemFunctions.isNotEqualTo(ReactSystemFunctions.value(this, (stateVars.TM_TopManagerDashboardLeadList !== undefined ? (stateVars.TM_TopManagerDashboardLeadList?.length > 0 ? stateVars.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null) : (this.state.TM_TopManagerDashboardLeadList?.length > 0 ? this.state.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null))), ReactSystemFunctions.convertToTypeByName("0", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp77242Visible = ((ReactSystemFunctions.isNotEqualTo(ReactSystemFunctions.value(this, (stateVars.TM_TopManagerDashboardLeadList !== undefined ? (stateVars.TM_TopManagerDashboardLeadList?.length > 0 ? stateVars.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null) : (this.state.TM_TopManagerDashboardLeadList?.length > 0 ? this.state.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null))), ReactSystemFunctions.convertToTypeByName("-1", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp352710Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, (stateVars.TM_TopManagerDashboardLeadList !== undefined ? (stateVars.TM_TopManagerDashboardLeadList?.length > 0 ? stateVars.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null) : (this.state.TM_TopManagerDashboardLeadList?.length > 0 ? this.state.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null))), ReactSystemFunctions.convertToTypeByName("-1", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp744094Visible = ((ReactSystemFunctions.isNotEqualTo(ReactSystemFunctions.value(this, (stateVars.TM_TopManagerDashboardLeadList !== undefined ? (stateVars.TM_TopManagerDashboardLeadList?.length > 0 ? stateVars.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null) : (this.state.TM_TopManagerDashboardLeadList?.length > 0 ? this.state.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null))), ReactSystemFunctions.convertToTypeByName("-2", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp558447Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, (stateVars.TM_TopManagerDashboardLeadList !== undefined ? (stateVars.TM_TopManagerDashboardLeadList?.length > 0 ? stateVars.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null) : (this.state.TM_TopManagerDashboardLeadList?.length > 0 ? this.state.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null))), ReactSystemFunctions.convertToTypeByName("-2", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp551457Visible = ((ReactSystemFunctions.isNotEqualTo(ReactSystemFunctions.value(this, (stateVars.TM_TopManagerDashboardLeadList !== undefined ? (stateVars.TM_TopManagerDashboardLeadList?.length > 0 ? stateVars.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null) : (this.state.TM_TopManagerDashboardLeadList?.length > 0 ? this.state.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null))), ReactSystemFunctions.convertToTypeByName("-3", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp862838Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, (stateVars.TM_TopManagerDashboardLeadList !== undefined ? (stateVars.TM_TopManagerDashboardLeadList?.length > 0 ? stateVars.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null) : (this.state.TM_TopManagerDashboardLeadList?.length > 0 ? this.state.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null))), ReactSystemFunctions.convertToTypeByName("-3", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp4159Visible = ((ReactSystemFunctions.isNotEqualTo(ReactSystemFunctions.value(this, (stateVars.TM_TopManagerDashboardLeadList !== undefined ? (stateVars.TM_TopManagerDashboardLeadList?.length > 0 ? stateVars.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null) : (this.state.TM_TopManagerDashboardLeadList?.length > 0 ? this.state.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null))), ReactSystemFunctions.convertToTypeByName("2", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp170471Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, (stateVars.TM_TopManagerDashboardLeadList !== undefined ? (stateVars.TM_TopManagerDashboardLeadList?.length > 0 ? stateVars.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null) : (this.state.TM_TopManagerDashboardLeadList?.length > 0 ? this.state.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null))), ReactSystemFunctions.convertToTypeByName("2", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp397882Visible = ((ReactSystemFunctions.isNotEqualTo(ReactSystemFunctions.value(this, (stateVars.TM_TopManagerDashboardLeadList !== undefined ? (stateVars.TM_TopManagerDashboardLeadList?.length > 0 ? stateVars.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null) : (this.state.TM_TopManagerDashboardLeadList?.length > 0 ? this.state.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null))), ReactSystemFunctions.convertToTypeByName("3", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp941736Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, (stateVars.TM_TopManagerDashboardLeadList !== undefined ? (stateVars.TM_TopManagerDashboardLeadList?.length > 0 ? stateVars.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null) : (this.state.TM_TopManagerDashboardLeadList?.length > 0 ? this.state.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null))), ReactSystemFunctions.convertToTypeByName("3", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp489263Visible = ((ReactSystemFunctions.isNotEqualTo(ReactSystemFunctions.value(this, (stateVars.TM_TopManagerDashboardLeadList !== undefined ? (stateVars.TM_TopManagerDashboardLeadList?.length > 0 ? stateVars.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null) : (this.state.TM_TopManagerDashboardLeadList?.length > 0 ? this.state.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null))), ReactSystemFunctions.convertToTypeByName("10", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp675337Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, (stateVars.TM_TopManagerDashboardLeadList !== undefined ? (stateVars.TM_TopManagerDashboardLeadList?.length > 0 ? stateVars.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null) : (this.state.TM_TopManagerDashboardLeadList?.length > 0 ? this.state.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null))), ReactSystemFunctions.convertToTypeByName("10", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp654813Visible = ((ReactSystemFunctions.isNotEqualTo(ReactSystemFunctions.value(this, (stateVars.TM_TopManagerDashboardLeadList !== undefined ? (stateVars.TM_TopManagerDashboardLeadList?.length > 0 ? stateVars.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null) : (this.state.TM_TopManagerDashboardLeadList?.length > 0 ? this.state.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null))), ReactSystemFunctions.convertToTypeByName("6", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp804552Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, (stateVars.TM_TopManagerDashboardLeadList !== undefined ? (stateVars.TM_TopManagerDashboardLeadList?.length > 0 ? stateVars.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null) : (this.state.TM_TopManagerDashboardLeadList?.length > 0 ? this.state.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null))), ReactSystemFunctions.convertToTypeByName("6", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp371503Visible = ((ReactSystemFunctions.isNotEqualTo(ReactSystemFunctions.value(this, (stateVars.TM_TopManagerDashboardLeadList !== undefined ? (stateVars.TM_TopManagerDashboardLeadList?.length > 0 ? stateVars.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null) : (this.state.TM_TopManagerDashboardLeadList?.length > 0 ? this.state.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null))), ReactSystemFunctions.convertToTypeByName("7", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp698275Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, (stateVars.TM_TopManagerDashboardLeadList !== undefined ? (stateVars.TM_TopManagerDashboardLeadList?.length > 0 ? stateVars.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null) : (this.state.TM_TopManagerDashboardLeadList?.length > 0 ? this.state.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null))), ReactSystemFunctions.convertToTypeByName("7", "string"))) === true ? "visible" : "hidden")
			this.props.form?.setFieldsValue(formVars);
			
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.DashBoardTempManagerComponent_397882_onClick1_();
                  resolve();
                });
          })



        
        KuikaAppManager.hideSpinner(this);
        return isErrorOccurred;
    }
		DashBoardTempManagerComponent_397882_onClick1_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }

				
				stateVars.dataSource_827135 = stateVars.TM_TopManagerDashboardLeadList ?? this.state.TM_TopManagerDashboardLeadList;

		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

            
            return isErrorOccurred;
        }




    DashBoardTempManagerComponent_489263_onClick = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
		KuikaAppManager.increaseServerRequestCount();

        let localVar = {
				UserId_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.getMyUserId(), "Guid"),
				MusteriAdi_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "dashboardtempmanager_666343_value", "value", "", "", "")), "string"),
				ProductName_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "dashboardtempmanager_153369_value", "value", "", "", "")), "string"),
				LeadCode_0: ReactSystemFunctions.convertToTypeByName(null, "string"),
				Tel_0: ReactSystemFunctions.convertToTypeByName(null, "string"),
				CategoryName_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "dashboardtempmanager_731364_value", "value", "TM_GetProductCategory", "categoryCode", "categoryName")), "string"),
				StoreIds_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "dashboardtempmanager_453042_value", "value", "TM_GetStore", "id", "id")), "string"),
				SatisDanismaniIds_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "dashboardtempmanager_425161_value", "value", "TM_GetSalesPerson", "kUserId", "kUserId")), "string"),
				ProcessCode_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "dashboardtempmanager_274478_value", "value", "TM_GetLeadProcess", "id", "code")), "string"),
				StepOrder_0: ReactSystemFunctions.convertToTypeByName(10, "number"),
				StartDate_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "dashboardtempmanager_138929_value", "value", "", "", "")), "Date"),
				EndDate_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "dashboardtempmanager_381090_value", "value", "", "", "")), "Date")
        }

		KuikaAppManager.showSpinner(this);
		
        if (true) {
        KuikaAppManager.showSpinner(this);
        }
        let result = await KuikaAppManager.ApiRequest(this, "DashBoardTempManager/DashBoardTempManagerComponent_489263_onClick", localVar)
        if (!KMainFunctions.IsResStatus2XX(result)) return true;

			stateVars.TM_TopManagerDashboardLeadList = result?.data.tM_TopManagerDashboardLeadList;
			
			stateVars.isComp20059Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, (stateVars.TM_TopManagerDashboardLeadList !== undefined ? (stateVars.TM_TopManagerDashboardLeadList?.length > 0 ? stateVars.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null) : (this.state.TM_TopManagerDashboardLeadList?.length > 0 ? this.state.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null))), ReactSystemFunctions.convertToTypeByName("0", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp693403Visible = ((ReactSystemFunctions.isNotEqualTo(ReactSystemFunctions.value(this, (stateVars.TM_TopManagerDashboardLeadList !== undefined ? (stateVars.TM_TopManagerDashboardLeadList?.length > 0 ? stateVars.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null) : (this.state.TM_TopManagerDashboardLeadList?.length > 0 ? this.state.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null))), ReactSystemFunctions.convertToTypeByName("0", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp77242Visible = ((ReactSystemFunctions.isNotEqualTo(ReactSystemFunctions.value(this, (stateVars.TM_TopManagerDashboardLeadList !== undefined ? (stateVars.TM_TopManagerDashboardLeadList?.length > 0 ? stateVars.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null) : (this.state.TM_TopManagerDashboardLeadList?.length > 0 ? this.state.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null))), ReactSystemFunctions.convertToTypeByName("-1", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp352710Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, (stateVars.TM_TopManagerDashboardLeadList !== undefined ? (stateVars.TM_TopManagerDashboardLeadList?.length > 0 ? stateVars.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null) : (this.state.TM_TopManagerDashboardLeadList?.length > 0 ? this.state.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null))), ReactSystemFunctions.convertToTypeByName("-1", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp744094Visible = ((ReactSystemFunctions.isNotEqualTo(ReactSystemFunctions.value(this, (stateVars.TM_TopManagerDashboardLeadList !== undefined ? (stateVars.TM_TopManagerDashboardLeadList?.length > 0 ? stateVars.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null) : (this.state.TM_TopManagerDashboardLeadList?.length > 0 ? this.state.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null))), ReactSystemFunctions.convertToTypeByName("-2", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp558447Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, (stateVars.TM_TopManagerDashboardLeadList !== undefined ? (stateVars.TM_TopManagerDashboardLeadList?.length > 0 ? stateVars.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null) : (this.state.TM_TopManagerDashboardLeadList?.length > 0 ? this.state.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null))), ReactSystemFunctions.convertToTypeByName("-2", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp551457Visible = ((ReactSystemFunctions.isNotEqualTo(ReactSystemFunctions.value(this, (stateVars.TM_TopManagerDashboardLeadList !== undefined ? (stateVars.TM_TopManagerDashboardLeadList?.length > 0 ? stateVars.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null) : (this.state.TM_TopManagerDashboardLeadList?.length > 0 ? this.state.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null))), ReactSystemFunctions.convertToTypeByName("-3", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp862838Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, (stateVars.TM_TopManagerDashboardLeadList !== undefined ? (stateVars.TM_TopManagerDashboardLeadList?.length > 0 ? stateVars.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null) : (this.state.TM_TopManagerDashboardLeadList?.length > 0 ? this.state.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null))), ReactSystemFunctions.convertToTypeByName("-3", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp4159Visible = ((ReactSystemFunctions.isNotEqualTo(ReactSystemFunctions.value(this, (stateVars.TM_TopManagerDashboardLeadList !== undefined ? (stateVars.TM_TopManagerDashboardLeadList?.length > 0 ? stateVars.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null) : (this.state.TM_TopManagerDashboardLeadList?.length > 0 ? this.state.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null))), ReactSystemFunctions.convertToTypeByName("2", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp170471Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, (stateVars.TM_TopManagerDashboardLeadList !== undefined ? (stateVars.TM_TopManagerDashboardLeadList?.length > 0 ? stateVars.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null) : (this.state.TM_TopManagerDashboardLeadList?.length > 0 ? this.state.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null))), ReactSystemFunctions.convertToTypeByName("2", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp397882Visible = ((ReactSystemFunctions.isNotEqualTo(ReactSystemFunctions.value(this, (stateVars.TM_TopManagerDashboardLeadList !== undefined ? (stateVars.TM_TopManagerDashboardLeadList?.length > 0 ? stateVars.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null) : (this.state.TM_TopManagerDashboardLeadList?.length > 0 ? this.state.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null))), ReactSystemFunctions.convertToTypeByName("3", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp941736Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, (stateVars.TM_TopManagerDashboardLeadList !== undefined ? (stateVars.TM_TopManagerDashboardLeadList?.length > 0 ? stateVars.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null) : (this.state.TM_TopManagerDashboardLeadList?.length > 0 ? this.state.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null))), ReactSystemFunctions.convertToTypeByName("3", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp489263Visible = ((ReactSystemFunctions.isNotEqualTo(ReactSystemFunctions.value(this, (stateVars.TM_TopManagerDashboardLeadList !== undefined ? (stateVars.TM_TopManagerDashboardLeadList?.length > 0 ? stateVars.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null) : (this.state.TM_TopManagerDashboardLeadList?.length > 0 ? this.state.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null))), ReactSystemFunctions.convertToTypeByName("10", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp675337Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, (stateVars.TM_TopManagerDashboardLeadList !== undefined ? (stateVars.TM_TopManagerDashboardLeadList?.length > 0 ? stateVars.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null) : (this.state.TM_TopManagerDashboardLeadList?.length > 0 ? this.state.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null))), ReactSystemFunctions.convertToTypeByName("10", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp654813Visible = ((ReactSystemFunctions.isNotEqualTo(ReactSystemFunctions.value(this, (stateVars.TM_TopManagerDashboardLeadList !== undefined ? (stateVars.TM_TopManagerDashboardLeadList?.length > 0 ? stateVars.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null) : (this.state.TM_TopManagerDashboardLeadList?.length > 0 ? this.state.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null))), ReactSystemFunctions.convertToTypeByName("6", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp804552Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, (stateVars.TM_TopManagerDashboardLeadList !== undefined ? (stateVars.TM_TopManagerDashboardLeadList?.length > 0 ? stateVars.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null) : (this.state.TM_TopManagerDashboardLeadList?.length > 0 ? this.state.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null))), ReactSystemFunctions.convertToTypeByName("6", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp371503Visible = ((ReactSystemFunctions.isNotEqualTo(ReactSystemFunctions.value(this, (stateVars.TM_TopManagerDashboardLeadList !== undefined ? (stateVars.TM_TopManagerDashboardLeadList?.length > 0 ? stateVars.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null) : (this.state.TM_TopManagerDashboardLeadList?.length > 0 ? this.state.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null))), ReactSystemFunctions.convertToTypeByName("7", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp698275Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, (stateVars.TM_TopManagerDashboardLeadList !== undefined ? (stateVars.TM_TopManagerDashboardLeadList?.length > 0 ? stateVars.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null) : (this.state.TM_TopManagerDashboardLeadList?.length > 0 ? this.state.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null))), ReactSystemFunctions.convertToTypeByName("7", "string"))) === true ? "visible" : "hidden")
			this.props.form?.setFieldsValue(formVars);
			
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.DashBoardTempManagerComponent_489263_onClick1_();
                  resolve();
                });
          })



        
        KuikaAppManager.hideSpinner(this);
        return isErrorOccurred;
    }
		DashBoardTempManagerComponent_489263_onClick1_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }

				
				stateVars.dataSource_827135 = stateVars.TM_TopManagerDashboardLeadList ?? this.state.TM_TopManagerDashboardLeadList;

		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

            
            return isErrorOccurred;
        }




    DashBoardTempManagerComponent_654813_onClick = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
		KuikaAppManager.increaseServerRequestCount();

        let localVar = {
				UserId_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.getMyUserId(), "Guid"),
				MusteriAdi_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "dashboardtempmanager_666343_value", "value", "", "", "")), "string"),
				ProductName_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "dashboardtempmanager_153369_value", "value", "", "", "")), "string"),
				LeadCode_0: ReactSystemFunctions.convertToTypeByName(null, "string"),
				Tel_0: ReactSystemFunctions.convertToTypeByName(null, "string"),
				CategoryName_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "dashboardtempmanager_731364_value", "value", "TM_GetProductCategory", "categoryCode", "categoryName")), "string"),
				StoreIds_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "dashboardtempmanager_453042_value", "value", "TM_GetStore", "id", "id")), "string"),
				SatisDanismaniIds_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "dashboardtempmanager_425161_value", "value", "TM_GetSalesPerson", "kUserId", "kUserId")), "string"),
				ProcessCode_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "dashboardtempmanager_274478_value", "value", "TM_GetLeadProcess", "id", "code")), "string"),
				StepOrder_0: ReactSystemFunctions.convertToTypeByName(6, "number"),
				StartDate_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "dashboardtempmanager_138929_value", "value", "", "", "")), "Date"),
				EndDate_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "dashboardtempmanager_381090_value", "value", "", "", "")), "Date")
        }

		KuikaAppManager.showSpinner(this);
		
        if (true) {
        KuikaAppManager.showSpinner(this);
        }
        let result = await KuikaAppManager.ApiRequest(this, "DashBoardTempManager/DashBoardTempManagerComponent_654813_onClick", localVar)
        if (!KMainFunctions.IsResStatus2XX(result)) return true;

			stateVars.TM_TopManagerDashboardLeadList = result?.data.tM_TopManagerDashboardLeadList;
			
			stateVars.isComp20059Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, (stateVars.TM_TopManagerDashboardLeadList !== undefined ? (stateVars.TM_TopManagerDashboardLeadList?.length > 0 ? stateVars.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null) : (this.state.TM_TopManagerDashboardLeadList?.length > 0 ? this.state.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null))), ReactSystemFunctions.convertToTypeByName("0", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp693403Visible = ((ReactSystemFunctions.isNotEqualTo(ReactSystemFunctions.value(this, (stateVars.TM_TopManagerDashboardLeadList !== undefined ? (stateVars.TM_TopManagerDashboardLeadList?.length > 0 ? stateVars.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null) : (this.state.TM_TopManagerDashboardLeadList?.length > 0 ? this.state.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null))), ReactSystemFunctions.convertToTypeByName("0", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp77242Visible = ((ReactSystemFunctions.isNotEqualTo(ReactSystemFunctions.value(this, (stateVars.TM_TopManagerDashboardLeadList !== undefined ? (stateVars.TM_TopManagerDashboardLeadList?.length > 0 ? stateVars.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null) : (this.state.TM_TopManagerDashboardLeadList?.length > 0 ? this.state.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null))), ReactSystemFunctions.convertToTypeByName("-1", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp352710Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, (stateVars.TM_TopManagerDashboardLeadList !== undefined ? (stateVars.TM_TopManagerDashboardLeadList?.length > 0 ? stateVars.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null) : (this.state.TM_TopManagerDashboardLeadList?.length > 0 ? this.state.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null))), ReactSystemFunctions.convertToTypeByName("-1", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp744094Visible = ((ReactSystemFunctions.isNotEqualTo(ReactSystemFunctions.value(this, (stateVars.TM_TopManagerDashboardLeadList !== undefined ? (stateVars.TM_TopManagerDashboardLeadList?.length > 0 ? stateVars.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null) : (this.state.TM_TopManagerDashboardLeadList?.length > 0 ? this.state.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null))), ReactSystemFunctions.convertToTypeByName("-2", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp558447Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, (stateVars.TM_TopManagerDashboardLeadList !== undefined ? (stateVars.TM_TopManagerDashboardLeadList?.length > 0 ? stateVars.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null) : (this.state.TM_TopManagerDashboardLeadList?.length > 0 ? this.state.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null))), ReactSystemFunctions.convertToTypeByName("-2", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp551457Visible = ((ReactSystemFunctions.isNotEqualTo(ReactSystemFunctions.value(this, (stateVars.TM_TopManagerDashboardLeadList !== undefined ? (stateVars.TM_TopManagerDashboardLeadList?.length > 0 ? stateVars.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null) : (this.state.TM_TopManagerDashboardLeadList?.length > 0 ? this.state.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null))), ReactSystemFunctions.convertToTypeByName("-3", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp862838Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, (stateVars.TM_TopManagerDashboardLeadList !== undefined ? (stateVars.TM_TopManagerDashboardLeadList?.length > 0 ? stateVars.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null) : (this.state.TM_TopManagerDashboardLeadList?.length > 0 ? this.state.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null))), ReactSystemFunctions.convertToTypeByName("-3", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp4159Visible = ((ReactSystemFunctions.isNotEqualTo(ReactSystemFunctions.value(this, (stateVars.TM_TopManagerDashboardLeadList !== undefined ? (stateVars.TM_TopManagerDashboardLeadList?.length > 0 ? stateVars.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null) : (this.state.TM_TopManagerDashboardLeadList?.length > 0 ? this.state.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null))), ReactSystemFunctions.convertToTypeByName("2", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp170471Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, (stateVars.TM_TopManagerDashboardLeadList !== undefined ? (stateVars.TM_TopManagerDashboardLeadList?.length > 0 ? stateVars.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null) : (this.state.TM_TopManagerDashboardLeadList?.length > 0 ? this.state.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null))), ReactSystemFunctions.convertToTypeByName("2", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp397882Visible = ((ReactSystemFunctions.isNotEqualTo(ReactSystemFunctions.value(this, (stateVars.TM_TopManagerDashboardLeadList !== undefined ? (stateVars.TM_TopManagerDashboardLeadList?.length > 0 ? stateVars.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null) : (this.state.TM_TopManagerDashboardLeadList?.length > 0 ? this.state.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null))), ReactSystemFunctions.convertToTypeByName("3", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp941736Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, (stateVars.TM_TopManagerDashboardLeadList !== undefined ? (stateVars.TM_TopManagerDashboardLeadList?.length > 0 ? stateVars.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null) : (this.state.TM_TopManagerDashboardLeadList?.length > 0 ? this.state.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null))), ReactSystemFunctions.convertToTypeByName("3", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp489263Visible = ((ReactSystemFunctions.isNotEqualTo(ReactSystemFunctions.value(this, (stateVars.TM_TopManagerDashboardLeadList !== undefined ? (stateVars.TM_TopManagerDashboardLeadList?.length > 0 ? stateVars.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null) : (this.state.TM_TopManagerDashboardLeadList?.length > 0 ? this.state.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null))), ReactSystemFunctions.convertToTypeByName("10", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp675337Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, (stateVars.TM_TopManagerDashboardLeadList !== undefined ? (stateVars.TM_TopManagerDashboardLeadList?.length > 0 ? stateVars.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null) : (this.state.TM_TopManagerDashboardLeadList?.length > 0 ? this.state.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null))), ReactSystemFunctions.convertToTypeByName("10", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp654813Visible = ((ReactSystemFunctions.isNotEqualTo(ReactSystemFunctions.value(this, (stateVars.TM_TopManagerDashboardLeadList !== undefined ? (stateVars.TM_TopManagerDashboardLeadList?.length > 0 ? stateVars.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null) : (this.state.TM_TopManagerDashboardLeadList?.length > 0 ? this.state.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null))), ReactSystemFunctions.convertToTypeByName("6", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp804552Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, (stateVars.TM_TopManagerDashboardLeadList !== undefined ? (stateVars.TM_TopManagerDashboardLeadList?.length > 0 ? stateVars.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null) : (this.state.TM_TopManagerDashboardLeadList?.length > 0 ? this.state.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null))), ReactSystemFunctions.convertToTypeByName("6", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp371503Visible = ((ReactSystemFunctions.isNotEqualTo(ReactSystemFunctions.value(this, (stateVars.TM_TopManagerDashboardLeadList !== undefined ? (stateVars.TM_TopManagerDashboardLeadList?.length > 0 ? stateVars.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null) : (this.state.TM_TopManagerDashboardLeadList?.length > 0 ? this.state.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null))), ReactSystemFunctions.convertToTypeByName("7", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp698275Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, (stateVars.TM_TopManagerDashboardLeadList !== undefined ? (stateVars.TM_TopManagerDashboardLeadList?.length > 0 ? stateVars.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null) : (this.state.TM_TopManagerDashboardLeadList?.length > 0 ? this.state.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null))), ReactSystemFunctions.convertToTypeByName("7", "string"))) === true ? "visible" : "hidden")
			this.props.form?.setFieldsValue(formVars);
			
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.DashBoardTempManagerComponent_654813_onClick1_();
                  resolve();
                });
          })



        
        KuikaAppManager.hideSpinner(this);
        return isErrorOccurred;
    }
		DashBoardTempManagerComponent_654813_onClick1_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }

				
				stateVars.dataSource_827135 = stateVars.TM_TopManagerDashboardLeadList ?? this.state.TM_TopManagerDashboardLeadList;

		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

            
            return isErrorOccurred;
        }




    DashBoardTempManagerComponent_371503_onClick = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
		KuikaAppManager.increaseServerRequestCount();

        let localVar = {
				UserId_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.getMyUserId(), "Guid"),
				MusteriAdi_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "dashboardtempmanager_666343_value", "value", "", "", "")), "string"),
				ProductName_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "dashboardtempmanager_153369_value", "value", "", "", "")), "string"),
				LeadCode_0: ReactSystemFunctions.convertToTypeByName(null, "string"),
				Tel_0: ReactSystemFunctions.convertToTypeByName(null, "string"),
				CategoryName_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "dashboardtempmanager_731364_value", "value", "TM_GetProductCategory", "categoryCode", "categoryName")), "string"),
				StoreIds_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "dashboardtempmanager_453042_value", "value", "TM_GetStore", "id", "id")), "string"),
				SatisDanismaniIds_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "dashboardtempmanager_425161_value", "value", "TM_GetSalesPerson", "kUserId", "kUserId")), "string"),
				ProcessCode_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "dashboardtempmanager_274478_value", "value", "TM_GetLeadProcess", "id", "code")), "string"),
				StepOrder_0: ReactSystemFunctions.convertToTypeByName(7, "number"),
				StartDate_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "dashboardtempmanager_138929_value", "value", "", "", "")), "Date"),
				EndDate_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "dashboardtempmanager_381090_value", "value", "", "", "")), "Date")
        }

		KuikaAppManager.showSpinner(this);
		
        if (true) {
        KuikaAppManager.showSpinner(this);
        }
        let result = await KuikaAppManager.ApiRequest(this, "DashBoardTempManager/DashBoardTempManagerComponent_371503_onClick", localVar)
        if (!KMainFunctions.IsResStatus2XX(result)) return true;

			stateVars.TM_TopManagerDashboardLeadList = result?.data.tM_TopManagerDashboardLeadList;
			
			stateVars.isComp20059Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, (stateVars.TM_TopManagerDashboardLeadList !== undefined ? (stateVars.TM_TopManagerDashboardLeadList?.length > 0 ? stateVars.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null) : (this.state.TM_TopManagerDashboardLeadList?.length > 0 ? this.state.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null))), ReactSystemFunctions.convertToTypeByName("0", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp693403Visible = ((ReactSystemFunctions.isNotEqualTo(ReactSystemFunctions.value(this, (stateVars.TM_TopManagerDashboardLeadList !== undefined ? (stateVars.TM_TopManagerDashboardLeadList?.length > 0 ? stateVars.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null) : (this.state.TM_TopManagerDashboardLeadList?.length > 0 ? this.state.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null))), ReactSystemFunctions.convertToTypeByName("0", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp77242Visible = ((ReactSystemFunctions.isNotEqualTo(ReactSystemFunctions.value(this, (stateVars.TM_TopManagerDashboardLeadList !== undefined ? (stateVars.TM_TopManagerDashboardLeadList?.length > 0 ? stateVars.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null) : (this.state.TM_TopManagerDashboardLeadList?.length > 0 ? this.state.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null))), ReactSystemFunctions.convertToTypeByName("-1", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp352710Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, (stateVars.TM_TopManagerDashboardLeadList !== undefined ? (stateVars.TM_TopManagerDashboardLeadList?.length > 0 ? stateVars.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null) : (this.state.TM_TopManagerDashboardLeadList?.length > 0 ? this.state.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null))), ReactSystemFunctions.convertToTypeByName("-1", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp744094Visible = ((ReactSystemFunctions.isNotEqualTo(ReactSystemFunctions.value(this, (stateVars.TM_TopManagerDashboardLeadList !== undefined ? (stateVars.TM_TopManagerDashboardLeadList?.length > 0 ? stateVars.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null) : (this.state.TM_TopManagerDashboardLeadList?.length > 0 ? this.state.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null))), ReactSystemFunctions.convertToTypeByName("-2", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp558447Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, (stateVars.TM_TopManagerDashboardLeadList !== undefined ? (stateVars.TM_TopManagerDashboardLeadList?.length > 0 ? stateVars.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null) : (this.state.TM_TopManagerDashboardLeadList?.length > 0 ? this.state.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null))), ReactSystemFunctions.convertToTypeByName("-2", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp551457Visible = ((ReactSystemFunctions.isNotEqualTo(ReactSystemFunctions.value(this, (stateVars.TM_TopManagerDashboardLeadList !== undefined ? (stateVars.TM_TopManagerDashboardLeadList?.length > 0 ? stateVars.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null) : (this.state.TM_TopManagerDashboardLeadList?.length > 0 ? this.state.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null))), ReactSystemFunctions.convertToTypeByName("-3", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp862838Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, (stateVars.TM_TopManagerDashboardLeadList !== undefined ? (stateVars.TM_TopManagerDashboardLeadList?.length > 0 ? stateVars.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null) : (this.state.TM_TopManagerDashboardLeadList?.length > 0 ? this.state.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null))), ReactSystemFunctions.convertToTypeByName("-3", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp4159Visible = ((ReactSystemFunctions.isNotEqualTo(ReactSystemFunctions.value(this, (stateVars.TM_TopManagerDashboardLeadList !== undefined ? (stateVars.TM_TopManagerDashboardLeadList?.length > 0 ? stateVars.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null) : (this.state.TM_TopManagerDashboardLeadList?.length > 0 ? this.state.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null))), ReactSystemFunctions.convertToTypeByName("2", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp170471Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, (stateVars.TM_TopManagerDashboardLeadList !== undefined ? (stateVars.TM_TopManagerDashboardLeadList?.length > 0 ? stateVars.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null) : (this.state.TM_TopManagerDashboardLeadList?.length > 0 ? this.state.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null))), ReactSystemFunctions.convertToTypeByName("2", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp397882Visible = ((ReactSystemFunctions.isNotEqualTo(ReactSystemFunctions.value(this, (stateVars.TM_TopManagerDashboardLeadList !== undefined ? (stateVars.TM_TopManagerDashboardLeadList?.length > 0 ? stateVars.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null) : (this.state.TM_TopManagerDashboardLeadList?.length > 0 ? this.state.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null))), ReactSystemFunctions.convertToTypeByName("3", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp941736Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, (stateVars.TM_TopManagerDashboardLeadList !== undefined ? (stateVars.TM_TopManagerDashboardLeadList?.length > 0 ? stateVars.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null) : (this.state.TM_TopManagerDashboardLeadList?.length > 0 ? this.state.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null))), ReactSystemFunctions.convertToTypeByName("3", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp489263Visible = ((ReactSystemFunctions.isNotEqualTo(ReactSystemFunctions.value(this, (stateVars.TM_TopManagerDashboardLeadList !== undefined ? (stateVars.TM_TopManagerDashboardLeadList?.length > 0 ? stateVars.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null) : (this.state.TM_TopManagerDashboardLeadList?.length > 0 ? this.state.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null))), ReactSystemFunctions.convertToTypeByName("10", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp675337Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, (stateVars.TM_TopManagerDashboardLeadList !== undefined ? (stateVars.TM_TopManagerDashboardLeadList?.length > 0 ? stateVars.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null) : (this.state.TM_TopManagerDashboardLeadList?.length > 0 ? this.state.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null))), ReactSystemFunctions.convertToTypeByName("10", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp654813Visible = ((ReactSystemFunctions.isNotEqualTo(ReactSystemFunctions.value(this, (stateVars.TM_TopManagerDashboardLeadList !== undefined ? (stateVars.TM_TopManagerDashboardLeadList?.length > 0 ? stateVars.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null) : (this.state.TM_TopManagerDashboardLeadList?.length > 0 ? this.state.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null))), ReactSystemFunctions.convertToTypeByName("6", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp804552Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, (stateVars.TM_TopManagerDashboardLeadList !== undefined ? (stateVars.TM_TopManagerDashboardLeadList?.length > 0 ? stateVars.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null) : (this.state.TM_TopManagerDashboardLeadList?.length > 0 ? this.state.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null))), ReactSystemFunctions.convertToTypeByName("6", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp371503Visible = ((ReactSystemFunctions.isNotEqualTo(ReactSystemFunctions.value(this, (stateVars.TM_TopManagerDashboardLeadList !== undefined ? (stateVars.TM_TopManagerDashboardLeadList?.length > 0 ? stateVars.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null) : (this.state.TM_TopManagerDashboardLeadList?.length > 0 ? this.state.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null))), ReactSystemFunctions.convertToTypeByName("7", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp698275Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, (stateVars.TM_TopManagerDashboardLeadList !== undefined ? (stateVars.TM_TopManagerDashboardLeadList?.length > 0 ? stateVars.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null) : (this.state.TM_TopManagerDashboardLeadList?.length > 0 ? this.state.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null))), ReactSystemFunctions.convertToTypeByName("7", "string"))) === true ? "visible" : "hidden")
			this.props.form?.setFieldsValue(formVars);
			
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.DashBoardTempManagerComponent_371503_onClick1_();
                  resolve();
                });
          })



        
        KuikaAppManager.hideSpinner(this);
        return isErrorOccurred;
    }
		DashBoardTempManagerComponent_371503_onClick1_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }

				
				stateVars.dataSource_827135 = stateVars.TM_TopManagerDashboardLeadList ?? this.state.TM_TopManagerDashboardLeadList;

		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

            
            return isErrorOccurred;
        }




    DashBoardTempManagerComponent_56981_onClick = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
		KuikaAppManager.increaseServerRequestCount();

        let localVar = {
				UserId_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.getMyUserId(), "Guid"),
				MusteriAdi_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "dashboardtempmanager_666343_value", "value", "", "", "")), "string"),
				ProductName_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "dashboardtempmanager_153369_value", "value", "", "", "")), "string"),
				LeadCode_0: ReactSystemFunctions.convertToTypeByName(null, "string"),
				Tel_0: ReactSystemFunctions.convertToTypeByName(null, "string"),
				CategoryName_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "dashboardtempmanager_731364_value", "value", "TM_GetProductCategory", "categoryCode", "categoryName")), "string"),
				StoreIds_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "dashboardtempmanager_453042_value", "value", "TM_GetStore", "id", "id")), "string"),
				SatisDanismaniIds_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "dashboardtempmanager_425161_value", "value", "TM_GetSalesPerson", "kUserId", "kUserId")), "string"),
				ProcessCode_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "dashboardtempmanager_274478_value", "value", "TM_GetLeadProcess", "id", "code")), "string"),
				StepOrder_0: ReactSystemFunctions.convertToTypeByName(0, "number"),
				StartDate_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "dashboardtempmanager_138929_value", "value", "", "", "")), "Date"),
				EndDate_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "dashboardtempmanager_381090_value", "value", "", "", "")), "Date")
        }

		KuikaAppManager.showSpinner(this);
		
        if (true) {
        KuikaAppManager.showSpinner(this);
        }
        let result = await KuikaAppManager.ApiRequest(this, "DashBoardTempManager/DashBoardTempManagerComponent_56981_onClick", localVar)
        if (!KMainFunctions.IsResStatus2XX(result)) return true;

			stateVars.TM_TopManagerDashboardLeadList = result?.data.tM_TopManagerDashboardLeadList;
			
			stateVars.isComp20059Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, (stateVars.TM_TopManagerDashboardLeadList !== undefined ? (stateVars.TM_TopManagerDashboardLeadList?.length > 0 ? stateVars.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null) : (this.state.TM_TopManagerDashboardLeadList?.length > 0 ? this.state.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null))), ReactSystemFunctions.convertToTypeByName("0", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp693403Visible = ((ReactSystemFunctions.isNotEqualTo(ReactSystemFunctions.value(this, (stateVars.TM_TopManagerDashboardLeadList !== undefined ? (stateVars.TM_TopManagerDashboardLeadList?.length > 0 ? stateVars.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null) : (this.state.TM_TopManagerDashboardLeadList?.length > 0 ? this.state.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null))), ReactSystemFunctions.convertToTypeByName("0", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp77242Visible = ((ReactSystemFunctions.isNotEqualTo(ReactSystemFunctions.value(this, (stateVars.TM_TopManagerDashboardLeadList !== undefined ? (stateVars.TM_TopManagerDashboardLeadList?.length > 0 ? stateVars.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null) : (this.state.TM_TopManagerDashboardLeadList?.length > 0 ? this.state.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null))), ReactSystemFunctions.convertToTypeByName("-1", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp352710Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, (stateVars.TM_TopManagerDashboardLeadList !== undefined ? (stateVars.TM_TopManagerDashboardLeadList?.length > 0 ? stateVars.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null) : (this.state.TM_TopManagerDashboardLeadList?.length > 0 ? this.state.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null))), ReactSystemFunctions.convertToTypeByName("-1", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp744094Visible = ((ReactSystemFunctions.isNotEqualTo(ReactSystemFunctions.value(this, (stateVars.TM_TopManagerDashboardLeadList !== undefined ? (stateVars.TM_TopManagerDashboardLeadList?.length > 0 ? stateVars.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null) : (this.state.TM_TopManagerDashboardLeadList?.length > 0 ? this.state.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null))), ReactSystemFunctions.convertToTypeByName("-2", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp558447Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, (stateVars.TM_TopManagerDashboardLeadList !== undefined ? (stateVars.TM_TopManagerDashboardLeadList?.length > 0 ? stateVars.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null) : (this.state.TM_TopManagerDashboardLeadList?.length > 0 ? this.state.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null))), ReactSystemFunctions.convertToTypeByName("-2", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp551457Visible = ((ReactSystemFunctions.isNotEqualTo(ReactSystemFunctions.value(this, (stateVars.TM_TopManagerDashboardLeadList !== undefined ? (stateVars.TM_TopManagerDashboardLeadList?.length > 0 ? stateVars.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null) : (this.state.TM_TopManagerDashboardLeadList?.length > 0 ? this.state.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null))), ReactSystemFunctions.convertToTypeByName("-3", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp862838Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, (stateVars.TM_TopManagerDashboardLeadList !== undefined ? (stateVars.TM_TopManagerDashboardLeadList?.length > 0 ? stateVars.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null) : (this.state.TM_TopManagerDashboardLeadList?.length > 0 ? this.state.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null))), ReactSystemFunctions.convertToTypeByName("-3", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp4159Visible = ((ReactSystemFunctions.isNotEqualTo(ReactSystemFunctions.value(this, (stateVars.TM_TopManagerDashboardLeadList !== undefined ? (stateVars.TM_TopManagerDashboardLeadList?.length > 0 ? stateVars.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null) : (this.state.TM_TopManagerDashboardLeadList?.length > 0 ? this.state.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null))), ReactSystemFunctions.convertToTypeByName("2", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp170471Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, (stateVars.TM_TopManagerDashboardLeadList !== undefined ? (stateVars.TM_TopManagerDashboardLeadList?.length > 0 ? stateVars.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null) : (this.state.TM_TopManagerDashboardLeadList?.length > 0 ? this.state.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null))), ReactSystemFunctions.convertToTypeByName("2", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp397882Visible = ((ReactSystemFunctions.isNotEqualTo(ReactSystemFunctions.value(this, (stateVars.TM_TopManagerDashboardLeadList !== undefined ? (stateVars.TM_TopManagerDashboardLeadList?.length > 0 ? stateVars.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null) : (this.state.TM_TopManagerDashboardLeadList?.length > 0 ? this.state.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null))), ReactSystemFunctions.convertToTypeByName("3", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp941736Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, (stateVars.TM_TopManagerDashboardLeadList !== undefined ? (stateVars.TM_TopManagerDashboardLeadList?.length > 0 ? stateVars.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null) : (this.state.TM_TopManagerDashboardLeadList?.length > 0 ? this.state.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null))), ReactSystemFunctions.convertToTypeByName("3", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp489263Visible = ((ReactSystemFunctions.isNotEqualTo(ReactSystemFunctions.value(this, (stateVars.TM_TopManagerDashboardLeadList !== undefined ? (stateVars.TM_TopManagerDashboardLeadList?.length > 0 ? stateVars.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null) : (this.state.TM_TopManagerDashboardLeadList?.length > 0 ? this.state.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null))), ReactSystemFunctions.convertToTypeByName("10", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp675337Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, (stateVars.TM_TopManagerDashboardLeadList !== undefined ? (stateVars.TM_TopManagerDashboardLeadList?.length > 0 ? stateVars.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null) : (this.state.TM_TopManagerDashboardLeadList?.length > 0 ? this.state.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null))), ReactSystemFunctions.convertToTypeByName("10", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp654813Visible = ((ReactSystemFunctions.isNotEqualTo(ReactSystemFunctions.value(this, (stateVars.TM_TopManagerDashboardLeadList !== undefined ? (stateVars.TM_TopManagerDashboardLeadList?.length > 0 ? stateVars.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null) : (this.state.TM_TopManagerDashboardLeadList?.length > 0 ? this.state.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null))), ReactSystemFunctions.convertToTypeByName("6", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp804552Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, (stateVars.TM_TopManagerDashboardLeadList !== undefined ? (stateVars.TM_TopManagerDashboardLeadList?.length > 0 ? stateVars.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null) : (this.state.TM_TopManagerDashboardLeadList?.length > 0 ? this.state.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null))), ReactSystemFunctions.convertToTypeByName("6", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp371503Visible = ((ReactSystemFunctions.isNotEqualTo(ReactSystemFunctions.value(this, (stateVars.TM_TopManagerDashboardLeadList !== undefined ? (stateVars.TM_TopManagerDashboardLeadList?.length > 0 ? stateVars.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null) : (this.state.TM_TopManagerDashboardLeadList?.length > 0 ? this.state.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null))), ReactSystemFunctions.convertToTypeByName("7", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp698275Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, (stateVars.TM_TopManagerDashboardLeadList !== undefined ? (stateVars.TM_TopManagerDashboardLeadList?.length > 0 ? stateVars.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null) : (this.state.TM_TopManagerDashboardLeadList?.length > 0 ? this.state.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null))), ReactSystemFunctions.convertToTypeByName("7", "string"))) === true ? "visible" : "hidden")
			this.props.form?.setFieldsValue(formVars);
			
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.DashBoardTempManagerComponent_56981_onClick1_();
                  resolve();
                });
          })



        
        KuikaAppManager.hideSpinner(this);
        return isErrorOccurred;
    }
		DashBoardTempManagerComponent_56981_onClick1_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }

				
				stateVars.dataSource_827135 = stateVars.TM_TopManagerDashboardLeadList ?? this.state.TM_TopManagerDashboardLeadList;

		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

            
            return isErrorOccurred;
        }




    DashBoardTempManagerComponent_462456_onClick = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
		KuikaAppManager.increaseServerRequestCount();

        let localVar = {
				UserId_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.getMyUserId(), "Guid"),
				MusteriAdi_0: ReactSystemFunctions.convertToTypeByName(null, "string"),
				ProductName_0: ReactSystemFunctions.convertToTypeByName(null, "string"),
				LeadCode_0: ReactSystemFunctions.convertToTypeByName(null, "string"),
				Tel_0: ReactSystemFunctions.convertToTypeByName(null, "string"),
				CategoryName_0: ReactSystemFunctions.convertToTypeByName(null, "string"),
				StoreIds_0: ReactSystemFunctions.convertToTypeByName(null, "string"),
				SatisDanismaniIds_0: ReactSystemFunctions.convertToTypeByName(null, "string"),
				ProcessCode_0: ReactSystemFunctions.convertToTypeByName(null, "string"),
				StepOrder_0: ReactSystemFunctions.convertToTypeByName(0, "number"),
				StartDate_0: ReactSystemFunctions.convertToTypeByName(null, "Date"),
				EndDate_0: ReactSystemFunctions.convertToTypeByName(null, "Date")
        }

		KuikaAppManager.showSpinner(this);
		
        if (true) {
        KuikaAppManager.showSpinner(this);
        }
        let result = await KuikaAppManager.ApiRequest(this, "DashBoardTempManager/DashBoardTempManagerComponent_462456_onClick", localVar)
        if (!KMainFunctions.IsResStatus2XX(result)) return true;

			stateVars.TM_TopManagerDashboardLeadList = result?.data.tM_TopManagerDashboardLeadList;
			
			stateVars.isComp20059Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, (stateVars.TM_TopManagerDashboardLeadList !== undefined ? (stateVars.TM_TopManagerDashboardLeadList?.length > 0 ? stateVars.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null) : (this.state.TM_TopManagerDashboardLeadList?.length > 0 ? this.state.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null))), ReactSystemFunctions.convertToTypeByName("0", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp693403Visible = ((ReactSystemFunctions.isNotEqualTo(ReactSystemFunctions.value(this, (stateVars.TM_TopManagerDashboardLeadList !== undefined ? (stateVars.TM_TopManagerDashboardLeadList?.length > 0 ? stateVars.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null) : (this.state.TM_TopManagerDashboardLeadList?.length > 0 ? this.state.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null))), ReactSystemFunctions.convertToTypeByName("0", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp77242Visible = ((ReactSystemFunctions.isNotEqualTo(ReactSystemFunctions.value(this, (stateVars.TM_TopManagerDashboardLeadList !== undefined ? (stateVars.TM_TopManagerDashboardLeadList?.length > 0 ? stateVars.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null) : (this.state.TM_TopManagerDashboardLeadList?.length > 0 ? this.state.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null))), ReactSystemFunctions.convertToTypeByName("-1", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp352710Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, (stateVars.TM_TopManagerDashboardLeadList !== undefined ? (stateVars.TM_TopManagerDashboardLeadList?.length > 0 ? stateVars.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null) : (this.state.TM_TopManagerDashboardLeadList?.length > 0 ? this.state.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null))), ReactSystemFunctions.convertToTypeByName("-1", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp744094Visible = ((ReactSystemFunctions.isNotEqualTo(ReactSystemFunctions.value(this, (stateVars.TM_TopManagerDashboardLeadList !== undefined ? (stateVars.TM_TopManagerDashboardLeadList?.length > 0 ? stateVars.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null) : (this.state.TM_TopManagerDashboardLeadList?.length > 0 ? this.state.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null))), ReactSystemFunctions.convertToTypeByName("-2", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp558447Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, (stateVars.TM_TopManagerDashboardLeadList !== undefined ? (stateVars.TM_TopManagerDashboardLeadList?.length > 0 ? stateVars.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null) : (this.state.TM_TopManagerDashboardLeadList?.length > 0 ? this.state.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null))), ReactSystemFunctions.convertToTypeByName("-2", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp551457Visible = ((ReactSystemFunctions.isNotEqualTo(ReactSystemFunctions.value(this, (stateVars.TM_TopManagerDashboardLeadList !== undefined ? (stateVars.TM_TopManagerDashboardLeadList?.length > 0 ? stateVars.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null) : (this.state.TM_TopManagerDashboardLeadList?.length > 0 ? this.state.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null))), ReactSystemFunctions.convertToTypeByName("-3", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp862838Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, (stateVars.TM_TopManagerDashboardLeadList !== undefined ? (stateVars.TM_TopManagerDashboardLeadList?.length > 0 ? stateVars.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null) : (this.state.TM_TopManagerDashboardLeadList?.length > 0 ? this.state.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null))), ReactSystemFunctions.convertToTypeByName("-3", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp4159Visible = ((ReactSystemFunctions.isNotEqualTo(ReactSystemFunctions.value(this, (stateVars.TM_TopManagerDashboardLeadList !== undefined ? (stateVars.TM_TopManagerDashboardLeadList?.length > 0 ? stateVars.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null) : (this.state.TM_TopManagerDashboardLeadList?.length > 0 ? this.state.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null))), ReactSystemFunctions.convertToTypeByName("2", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp170471Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, (stateVars.TM_TopManagerDashboardLeadList !== undefined ? (stateVars.TM_TopManagerDashboardLeadList?.length > 0 ? stateVars.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null) : (this.state.TM_TopManagerDashboardLeadList?.length > 0 ? this.state.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null))), ReactSystemFunctions.convertToTypeByName("2", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp397882Visible = ((ReactSystemFunctions.isNotEqualTo(ReactSystemFunctions.value(this, (stateVars.TM_TopManagerDashboardLeadList !== undefined ? (stateVars.TM_TopManagerDashboardLeadList?.length > 0 ? stateVars.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null) : (this.state.TM_TopManagerDashboardLeadList?.length > 0 ? this.state.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null))), ReactSystemFunctions.convertToTypeByName("3", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp941736Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, (stateVars.TM_TopManagerDashboardLeadList !== undefined ? (stateVars.TM_TopManagerDashboardLeadList?.length > 0 ? stateVars.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null) : (this.state.TM_TopManagerDashboardLeadList?.length > 0 ? this.state.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null))), ReactSystemFunctions.convertToTypeByName("3", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp489263Visible = ((ReactSystemFunctions.isNotEqualTo(ReactSystemFunctions.value(this, (stateVars.TM_TopManagerDashboardLeadList !== undefined ? (stateVars.TM_TopManagerDashboardLeadList?.length > 0 ? stateVars.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null) : (this.state.TM_TopManagerDashboardLeadList?.length > 0 ? this.state.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null))), ReactSystemFunctions.convertToTypeByName("10", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp675337Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, (stateVars.TM_TopManagerDashboardLeadList !== undefined ? (stateVars.TM_TopManagerDashboardLeadList?.length > 0 ? stateVars.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null) : (this.state.TM_TopManagerDashboardLeadList?.length > 0 ? this.state.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null))), ReactSystemFunctions.convertToTypeByName("10", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp654813Visible = ((ReactSystemFunctions.isNotEqualTo(ReactSystemFunctions.value(this, (stateVars.TM_TopManagerDashboardLeadList !== undefined ? (stateVars.TM_TopManagerDashboardLeadList?.length > 0 ? stateVars.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null) : (this.state.TM_TopManagerDashboardLeadList?.length > 0 ? this.state.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null))), ReactSystemFunctions.convertToTypeByName("6", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp804552Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, (stateVars.TM_TopManagerDashboardLeadList !== undefined ? (stateVars.TM_TopManagerDashboardLeadList?.length > 0 ? stateVars.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null) : (this.state.TM_TopManagerDashboardLeadList?.length > 0 ? this.state.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null))), ReactSystemFunctions.convertToTypeByName("6", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp371503Visible = ((ReactSystemFunctions.isNotEqualTo(ReactSystemFunctions.value(this, (stateVars.TM_TopManagerDashboardLeadList !== undefined ? (stateVars.TM_TopManagerDashboardLeadList?.length > 0 ? stateVars.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null) : (this.state.TM_TopManagerDashboardLeadList?.length > 0 ? this.state.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null))), ReactSystemFunctions.convertToTypeByName("7", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp698275Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, (stateVars.TM_TopManagerDashboardLeadList !== undefined ? (stateVars.TM_TopManagerDashboardLeadList?.length > 0 ? stateVars.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null) : (this.state.TM_TopManagerDashboardLeadList?.length > 0 ? this.state.TM_TopManagerDashboardLeadList[0].selectedStepOrder : null))), ReactSystemFunctions.convertToTypeByName("7", "string"))) === true ? "visible" : "hidden")
			this.props.form?.setFieldsValue(formVars);
			
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.DashBoardTempManagerComponent_462456_onClick1_();
                  resolve();
                });
          })



        
        KuikaAppManager.hideSpinner(this);
        return isErrorOccurred;
    }
		DashBoardTempManagerComponent_462456_onClick1_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }

				stateVars.SetValueOf = await ReactSystemFunctions.setValueOf(this, ReactSystemFunctions.convertToTypeByName("dashboardtempmanager_666343_value", "string"), "", null, false);
				stateVars.SetValueOf = await ReactSystemFunctions.setValueOf(this, ReactSystemFunctions.convertToTypeByName("dashboardtempmanager_153369_value", "string"), "", null, false);
				stateVars.SetValueOf = await ReactSystemFunctions.setValueOf(this, ReactSystemFunctions.convertToTypeByName("dashboardtempmanager_731364_value", "string"), "", null, false);
				stateVars.SetValueOf = await ReactSystemFunctions.setValueOf(this, ReactSystemFunctions.convertToTypeByName("dashboardtempmanager_453042_value", "string"), "", null, false);
				stateVars.SetValueOf = await ReactSystemFunctions.setValueOf(this, ReactSystemFunctions.convertToTypeByName("dashboardtempmanager_425161_value", "string"), "", null, false);
				stateVars.SetValueOf = await ReactSystemFunctions.setValueOf(this, ReactSystemFunctions.convertToTypeByName("dashboardtempmanager_274478_value", "string"), "", null, false);
				stateVars.SetValueOf = await ReactSystemFunctions.setValueOf(this, ReactSystemFunctions.convertToTypeByName("dashboardtempmanager_138929_value", "string"), "", null, false);
				stateVars.SetValueOf = await ReactSystemFunctions.setValueOf(this, ReactSystemFunctions.convertToTypeByName("dashboardtempmanager_381090_value", "string"), "", null, false);
				
				stateVars.dataSource_827135 = stateVars.TM_TopManagerDashboardLeadList ?? this.state.TM_TopManagerDashboardLeadList;

		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

            
            return isErrorOccurred;
        }




		DashBoardTempManagerComponent_372153_onClick = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
KuikaAppManager.showSpinner(this);

					KuikaAppManager.prepareForNavigation();
						KuikaAppManager.addToPageInputVariables("LeadDetailTemp", "LeadId", ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, "dashboardtempmanager_827135_value", "leadId"), "Guid"));

				stateVars.NAVIGATE = await ReactSystemFunctions.navigate(this, undefined, "DashBoardTempManager", "LeadDetailTemp", "", "7d969ddf-5801-4eb6-b92b-12be35bdd565", "687840", null, "right", "true", "70vw", "100vh", true, false);

		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

            
            return isErrorOccurred;
        }




    async callCallbackFunction(diId: number, isFromMaster: boolean = false) {
        let isErrorOccurred = false;
		let pageInitCallerNavDiIDs = [, , , , , , , 246279, 687840] as number[];
		if (isFromMaster || pageInitCallerNavDiIDs.indexOf(diId) > -1) {
			await this.DashBoardTempManagerPageInit();
		}

    }


}
