import React from "react";
import Axios, { AxiosResponse } from "axios";
import { KuikaAppManager } from "../../shared/utilty/kuika-app-manager";
import { ReactSystemFunctions } from "../../shared/utilty/react-system-functions";
import { KNavigator } from "../../shared/hoc/with-history";
import { KContext } from "../../shared/hoc/with-context";
import { useLocation } from "react-router-dom";
import { FormInstance } from "antd/es/form";
import { Guid } from "guid-typescript";
import Swal from "sweetalert2";
import { KMainFunctions } from "../../shared/utilty/main-functions";
import moment from "moment";
import { IValidationData } from "../../models/dto/validation-data";
import { IStripePayment } from "../../models/dto/stripe-payment";
import { IUserInfoDto } from "../../models/dto/user-info.dto";
import { UserService } from "../../services/user-service";
import { kuikaCoreWasmBridgeService } from "../../services/_singletons";
import _ from "lodash";
import mqtt, { MqttClient } from "mqtt";
import { IMqttResult } from "../../models/dto/mqtt.dto";
import { MasterScreen_ScreenContext } from "../masterscreen/masterscreen-context";

declare let window: any;

export interface IStockListStore_ScreenProps {
  navigator: KNavigator;
  form: FormInstance<any>;
  googleLogin: any;
  screenInputs: any;
  context: KContext;
  initialValues: any;
  children: any;
}

export interface IStockListStore_ScreenState {
    isSpinnerVisible: boolean;
    isPageVisible: boolean;
	isLeftMenuVisible: boolean;
    spinnerCount: number;
    selectedLanguage: string;
    isPageInitLoaded: false;
    isPageRecurringLoaded: false;
	TM_GetInventoryByUserStore: any[];
	TM_GetInventoryByUserStore_dummy: any[];
	TM_GetStockBrands: any[];
	TM_GetStockBrands_dummy: any[];
	TM_GetProductNamesByStore: any[];
	TM_GetProductNamesByStore_dummy: any[];
	TM_GetCategoriesByStore: any[];
	TM_GetCategoriesByStore_dummy: any[];
	TM_GetReferencesByStore: any[];
	TM_GetReferencesByStore_dummy: any[];
	TM_GetDialsByStore: any[];
	TM_GetDialsByStore_dummy: any[];
	TM_GetBraceletsByStore: any[];
	TM_GetBraceletsByStore_dummy: any[];
	TM_GetItemType: any[];
	TM_GetItemType_dummy: any[];
	TM_StockButton: any[];
	TM_StockButton_dummy: any[];
	GoBack: any;
	GoBack_dummy: any;
	ChangeVisibilityOf: string;
	ChangeVisibilityOf_dummy: string;
	SetValueOf: any;
	SetValueOf_dummy: any;
	NAVIGATE: any;
	NAVIGATE_dummy: any;
	isComp750455Visible: 'visible' | 'hidden';
	isComp993814Visible: 'visible' | 'hidden';
	isComp167638Visible: 'visible' | 'hidden';
	isComp803621Visible: 'visible' | 'hidden';
	isComp939973Visible: 'visible' | 'hidden';
	isComp534718Visible: 'visible' | 'hidden';
	isComp159928Visible: 'visible' | 'hidden';
	isComp274123Visible: 'visible' | 'hidden';

}

export class StockListStore_ScreenBase extends React.PureComponent<IStockListStore_ScreenProps, any> {
    static contextType = MasterScreen_ScreenContext;
    declare context: React.ContextType<typeof MasterScreen_ScreenContext>;
	stockliststore_66600_value_kuikaAutoCompleteRef: React.RefObject<any>;
	stockliststore_190692_value_kuikaAutoCompleteRef: React.RefObject<any>;
	stockliststore_560082_value_kuikaAutoCompleteRef: React.RefObject<any>;
	stockliststore_944323_value_kuikaAutoCompleteRef: React.RefObject<any>;
	stockliststore_944471_value_kuikaAutoCompleteRef: React.RefObject<any>;
	stockliststore_651590_value_kuikaAutoCompleteRef: React.RefObject<any>;
	stockliststore_831544_value_kuikaAutoCompleteRef: React.RefObject<any>;
	stockliststore_466548_value_kuikaAutoCompleteRef: React.RefObject<any>;
	stockliststore_968810_value_kuikaTableRef: React.RefObject<any>;
    ml=[{"Id":"d5a61d2b-bd60-485f-86e2-661e9ed4e486","Name":"en_US","ShortName":"English","IsDefault":true,"LanguagePhrases":[]},{"Id":"f376293f-e93e-4e04-91a9-b7a10f3ec8be","Name":"FixedValues","ShortName":"FixedValues","LanguagePhrases":[{"Id":274505,"PropertyName":"value","Value":"Ürün stoklarını görüntüleyin ve yönetin"},{"Id":87878,"PropertyName":"label","Value":"Genel Listeye Geri Dön"},{"Id":841706,"PropertyName":"value","Value":"Filtre"},{"Id":601004,"PropertyName":"value","Value":"Ürün Tipi"},{"Id":326652,"PropertyName":"value","Value":"Marka"},{"Id":951723,"PropertyName":"value","Value":"Ürün"},{"Id":54545,"PropertyName":"value","Value":"Kategori"},{"Id":698455,"PropertyName":"value","Value":"Model"},{"Id":310937,"PropertyName":"value","Value":"Kadran"},{"Id":242571,"PropertyName":"value","Value":"Bilezik"},{"Id":152982,"PropertyName":"value","Value":"Durum"},{"Id":702276,"PropertyName":"label","Value":"Filtreleri Temizle"},{"Id":227569,"PropertyName":"title","Value":"Ürün Adı"},{"Id":604676,"PropertyName":"value","Value":"[datafield:productname]"},{"Id":322666,"PropertyName":"title","Value":"Kategori"},{"Id":803621,"PropertyName":"value","Value":"[datafield:categoryname]"},{"Id":939973,"PropertyName":"value","Value":"[datafield:categoryname]"},{"Id":534718,"PropertyName":"value","Value":"[datafield:categoryname]"},{"Id":159928,"PropertyName":"value","Value":"[datafield:categoryname]"},{"Id":661936,"PropertyName":"title","Value":"Referans(Özellik 3)"},{"Id":972612,"PropertyName":"value","Value":"[datafield:referance]"},{"Id":162815,"PropertyName":"title","Value":"Kadran(Özellik 5)"},{"Id":326753,"PropertyName":"value","Value":"[datafield:dial]"},{"Id":426803,"PropertyName":"title","Value":"Bilezik(Özellik 4)"},{"Id":154697,"PropertyName":"value","Value":"[datafield:bracelet]"},{"Id":866181,"PropertyName":"title","Value":"Toplam Stok"},{"Id":399005,"PropertyName":"value","Value":"[datafield:toplamstok]"},{"Id":660270,"PropertyName":"title","Value":"Rezerve Ürün"},{"Id":567234,"PropertyName":"value","Value":"[datafield:rezervestok]"}]}]
    defaultML = "en_US"
    
    screenHash = ""
    

    private _prevMasterPageInitLoaded: boolean = false;
    private _prevMasterPageRecurringLoaded: boolean = false;
    private _prevShouldTriggerPageInit: boolean = false;
    constructor(props) {
        super(props);
		this.stockliststore_66600_value_kuikaAutoCompleteRef = React.createRef();
		this.stockliststore_190692_value_kuikaAutoCompleteRef = React.createRef();
		this.stockliststore_560082_value_kuikaAutoCompleteRef = React.createRef();
		this.stockliststore_944323_value_kuikaAutoCompleteRef = React.createRef();
		this.stockliststore_944471_value_kuikaAutoCompleteRef = React.createRef();
		this.stockliststore_651590_value_kuikaAutoCompleteRef = React.createRef();
		this.stockliststore_831544_value_kuikaAutoCompleteRef = React.createRef();
		this.stockliststore_466548_value_kuikaAutoCompleteRef = React.createRef();
		this.stockliststore_968810_value_kuikaTableRef = React.createRef();

        this.state = {
            isSpinnerVisible: false,
            isPageVisible: false,
            isLeftMenuVisible: false,
            spinnerCount: 0,
            selectedLanguage: "",
            isPageInitLoaded: false,
            isPageRecurringLoaded: false,
            	        TM_GetInventoryByUserStore: [],
	        TM_GetStockBrands: [],
	        TM_GetProductNamesByStore: [],
	        TM_GetCategoriesByStore: [],
	        TM_GetReferencesByStore: [],
	        TM_GetDialsByStore: [],
	        TM_GetBraceletsByStore: [],
	        TM_GetItemType: [],
	        TM_StockButton: [],
	        GoBack: "",
	        ChangeVisibilityOf: "",
	        SetValueOf: "",
	        NAVIGATE: "",
	        dataSource_466548: [{"key":"1","text":"Rezerve"},{"key":"0","text":"Müsait"}],
	        isComp750455Visible: 'visible',
	        isComp993814Visible: 'hidden',
	        isComp167638Visible: 'visible',
	        isComp803621Visible: 'hidden',
	        isComp939973Visible: 'hidden',
	        isComp534718Visible: 'hidden',
	        isComp159928Visible: 'hidden',
	        isComp274123Visible: 'hidden',

        }

        this.state.isPageVisible = true;
        
    }

    async componentDidMount() {

        if (KuikaAppManager.isPageInitPrevented()) {
            KuikaAppManager.calculateAndSetBodyHeight("stockliststore", "masterscreen_screen");
            return;
        }
        this.context.registerCallbackFunction(this.callCallbackFunction.bind(this));
        
        ReactSystemFunctions.validateToken()
        this.fillFormInitValues();
        if (false){
            await this.StockListStorePageInit();
        } else if (this.context?.isMasterPageInitLoaded) { this._prevMasterPageInitLoaded = true; await this.StockListStorePageInit(); }
        
        
        
        KuikaAppManager.calculateAndSetBodyHeight("stockliststore", "masterscreen_screen");

        if (ReactSystemFunctions.getIsMicroApp() === false) {
           window.parentScreen = this;
        }
    }

    componentWillUnmount() {
        
        
        

        if (ReactSystemFunctions.getIsMicroApp() === false) {
           window.parentScreen = null;
        }
    }

    

        
    componentDidUpdate= async (prevProps, prevState) => {
		KuikaAppManager.calculateAndSetBodyHeight("stockliststore", "masterscreen_screen"    );
        if (prevProps?.location?.search !== (this.props as any)?.location?.search) {
			await this.StockListStorePageInit();
		}

        		if (this._prevMasterPageInitLoaded !== this.context.isMasterPageInitLoaded && this.context.isMasterPageInitLoaded === true) {this._prevMasterPageInitLoaded = this.context.isMasterPageInitLoaded;await this.StockListStorePageInit()}


        if (ReactSystemFunctions.getIsMicroApp() === false) {
            for (const key in prevState) {
                if (key.startsWith('NavVisible') && prevState[key] === true && this.state[key] === false) {
                    window.parentScreen = this;
                    break;
                }
            }
        }
	}

    fillFormInitValues() {
        this.props.form?.setFieldsValue({
});

    }

      setPageInitLoaded = (value: boolean) => {
        this.setState({ isPageInitLoaded: value });
      }

      setPageRecurringLoaded = (value: boolean) => {
        this.setState({ isPageRecurringLoaded: value });
      }

      clearFieldValidation = (changedValues: any) => {
        const fieldName = Object.keys(changedValues)[0];
        if (fieldName) {
          this.props.form?.setFields([
            {
              name: fieldName,
              errors: []
            }
          ]);
        }
      };

      

    StockListStorePageInit = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


	if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }

        let localVar = {
			StoreCode_0: ReactSystemFunctions.convertToTypeByName(this.props.screenInputs.StoreCode ?? this.props.screenInputs.storecode, "string"),
			UrunTipi_0: ReactSystemFunctions.convertToTypeByName(null, "string"),
			Brand_0: ReactSystemFunctions.convertToTypeByName(null, "string"),
			CategoryName_0: ReactSystemFunctions.convertToTypeByName(null, "string"),
			ProductName_0: ReactSystemFunctions.convertToTypeByName(null, "string"),
			Referance_0: ReactSystemFunctions.convertToTypeByName(null, "string"),
			Dial_0: ReactSystemFunctions.convertToTypeByName(null, "string"),
			Bracelet_0: ReactSystemFunctions.convertToTypeByName(null, "string"),
			Durum_0: ReactSystemFunctions.convertToTypeByName(null, "number"),
			StoreCode_1: ReactSystemFunctions.convertToTypeByName(this.props.screenInputs.StoreCode ?? this.props.screenInputs.storecode, "string"),
			StoreCode_2: ReactSystemFunctions.convertToTypeByName(this.props.screenInputs.StoreCode ?? this.props.screenInputs.storecode, "string"),
			StoreCode_3: ReactSystemFunctions.convertToTypeByName(this.props.screenInputs.StoreCode ?? this.props.screenInputs.storecode, "string"),
			StoreCode_4: ReactSystemFunctions.convertToTypeByName(this.props.screenInputs.StoreCode ?? this.props.screenInputs.storecode, "string"),
			StoreCode_5: ReactSystemFunctions.convertToTypeByName(this.props.screenInputs.StoreCode ?? this.props.screenInputs.storecode, "string"),
			StoreCode_6: ReactSystemFunctions.convertToTypeByName(this.props.screenInputs.StoreCode ?? this.props.screenInputs.storecode, "string"),
			StoreCode_7: ReactSystemFunctions.convertToTypeByName(this.props.screenInputs.StoreCode ?? this.props.screenInputs.storecode, "string"),
			UserId_8: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.getMyUserId(), "Guid"),
			StoreCode_8: ReactSystemFunctions.convertToTypeByName(this.props.screenInputs.StoreCode ?? this.props.screenInputs.storecode, "string")
        }

	KuikaAppManager.showSpinner(this);
	
        if (true) {
        KuikaAppManager.showSpinner(this);
        }
        let result = await KuikaAppManager.ApiRequest(this, "StockListStore/StockListStorePageInit", localVar)
        if (!KMainFunctions.IsResStatus2XX(result)) return true;

		stateVars.TM_GetInventoryByUserStore = result?.data.tM_GetInventoryByUserStore;
		
		stateVars.TM_GetStockBrands = result?.data.tM_GetStockBrands;
		
		formVars.stockliststore_190692_options = stateVars.TM_GetStockBrands;
		stateVars.TM_GetProductNamesByStore = result?.data.tM_GetProductNamesByStore;
		
		formVars.stockliststore_560082_options = stateVars.TM_GetProductNamesByStore;
		stateVars.TM_GetCategoriesByStore = result?.data.tM_GetCategoriesByStore;
		
		formVars.stockliststore_944323_options = stateVars.TM_GetCategoriesByStore;
		stateVars.TM_GetReferencesByStore = result?.data.tM_GetReferencesByStore;
		
		formVars.stockliststore_944471_options = stateVars.TM_GetReferencesByStore;
		stateVars.TM_GetDialsByStore = result?.data.tM_GetDialsByStore;
		
		formVars.stockliststore_651590_options = stateVars.TM_GetDialsByStore;
		stateVars.TM_GetBraceletsByStore = result?.data.tM_GetBraceletsByStore;
		
		formVars.stockliststore_831544_options = stateVars.TM_GetBraceletsByStore;
		stateVars.TM_GetItemType = result?.data.tM_GetItemType;
		
		formVars.stockliststore_66600_options = stateVars.TM_GetItemType;
		stateVars.TM_StockButton = result?.data.tM_StockButton;
		stateVars.isComp274123Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, (stateVars.TM_StockButton !== undefined ? (stateVars.TM_StockButton?.length > 0 ? stateVars.TM_StockButton[0].canGoDetail : null) : (this.state.TM_StockButton?.length > 0 ? this.state.TM_StockButton[0].canGoDetail : null))), ReactSystemFunctions.convertToTypeByName("True", "string"))) === true ? "visible" : "hidden")
		this.props.form?.setFieldsValue(formVars);
		
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.StockListStorePageInit1_();
                  resolve();
                });
          })



        
        KuikaAppManager.hideSpinner(this);
        return isErrorOccurred;
    }
	StockListStorePageInit1_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


	if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }

			
			stateVars.dataSource_66600 = stateVars.TM_GetItemType ?? this.state.TM_GetItemType;
			stateVars.dataSource_66600 = stateVars.TM_GetItemType ?? this.state.TM_GetItemType;
			
			stateVars.dataSource_190692 = stateVars.TM_GetStockBrands ?? this.state.TM_GetStockBrands;
			stateVars.dataSource_190692 = stateVars.TM_GetStockBrands ?? this.state.TM_GetStockBrands;
			
			stateVars.dataSource_560082 = stateVars.TM_GetProductNamesByStore ?? this.state.TM_GetProductNamesByStore;
			stateVars.dataSource_560082 = stateVars.TM_GetProductNamesByStore ?? this.state.TM_GetProductNamesByStore;
			
			stateVars.dataSource_944323 = stateVars.TM_GetCategoriesByStore ?? this.state.TM_GetCategoriesByStore;
			stateVars.dataSource_944323 = stateVars.TM_GetCategoriesByStore ?? this.state.TM_GetCategoriesByStore;
			
			stateVars.dataSource_944471 = stateVars.TM_GetReferencesByStore ?? this.state.TM_GetReferencesByStore;
			stateVars.dataSource_944471 = stateVars.TM_GetReferencesByStore ?? this.state.TM_GetReferencesByStore;
			
			stateVars.dataSource_651590 = stateVars.TM_GetDialsByStore ?? this.state.TM_GetDialsByStore;
			stateVars.dataSource_651590 = stateVars.TM_GetDialsByStore ?? this.state.TM_GetDialsByStore;
			
			stateVars.dataSource_831544 = stateVars.TM_GetBraceletsByStore ?? this.state.TM_GetBraceletsByStore;
			stateVars.dataSource_831544 = stateVars.TM_GetBraceletsByStore ?? this.state.TM_GetBraceletsByStore;
			
			stateVars.dataSource_968810 = stateVars.TM_GetInventoryByUserStore ?? this.state.TM_GetInventoryByUserStore;
			stateVars.isComp803621Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, "stockliststore_968810_value", "categoryName"), ReactSystemFunctions.convertToTypeByName("Kategori 1", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp939973Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, "stockliststore_968810_value", "categoryName"), ReactSystemFunctions.convertToTypeByName("Kategori 2", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp534718Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, "stockliststore_968810_value", "categoryName"), ReactSystemFunctions.convertToTypeByName("Kategori 3", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp159928Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, "stockliststore_968810_value", "categoryName"), ReactSystemFunctions.convertToTypeByName("DEFAULT", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp274123Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, (stateVars.TM_StockButton !== undefined ? (stateVars.TM_StockButton?.length > 0 ? stateVars.TM_StockButton[0].canGoDetail : null) : (this.state.TM_StockButton?.length > 0 ? this.state.TM_StockButton[0].canGoDetail : null))), ReactSystemFunctions.convertToTypeByName("True", "string"))) === true ? "visible" : "hidden")

	this.props.form?.setFieldsValue(formVars);
	this.setState(stateVars);
	KuikaAppManager.hideSpinner(this);

            this.setPageInitLoaded(true);
            return isErrorOccurred;
        }




		StockListStoreComponent_87878_onClick = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
KuikaAppManager.showSpinner(this);

				stateVars.GoBack = await ReactSystemFunctions.goBack(this, false);

		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

            
            return isErrorOccurred;
        }


		StockListStoreComponent_167638_onClick = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
KuikaAppManager.showSpinner(this);

				stateVars.ChangeVisibilityOf = await ReactSystemFunctions.changeVisibilityOf(this, ReactSystemFunctions.convertToTypeByName("isComp750455Visible", "string"), ReactSystemFunctions.convertToTypeByName("hidden", "string"));
				stateVars.ChangeVisibilityOf = await ReactSystemFunctions.changeVisibilityOf(this, ReactSystemFunctions.convertToTypeByName("isComp993814Visible", "string"), ReactSystemFunctions.convertToTypeByName("visible", "string"));
				stateVars.ChangeVisibilityOf = await ReactSystemFunctions.changeVisibilityOf(this, ReactSystemFunctions.convertToTypeByName("isComp167638Visible", "string"), ReactSystemFunctions.convertToTypeByName("hidden", "string"));

		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

            
            return isErrorOccurred;
        }


		StockListStoreComponent_993814_onClick = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
KuikaAppManager.showSpinner(this);

				stateVars.ChangeVisibilityOf = await ReactSystemFunctions.changeVisibilityOf(this, ReactSystemFunctions.convertToTypeByName("isComp750455Visible", "string"), ReactSystemFunctions.convertToTypeByName("visible", "string"));
				stateVars.ChangeVisibilityOf = await ReactSystemFunctions.changeVisibilityOf(this, ReactSystemFunctions.convertToTypeByName("isComp167638Visible", "string"), ReactSystemFunctions.convertToTypeByName("visible", "string"));
				stateVars.ChangeVisibilityOf = await ReactSystemFunctions.changeVisibilityOf(this, ReactSystemFunctions.convertToTypeByName("isComp993814Visible", "string"), ReactSystemFunctions.convertToTypeByName("hidden", "string"));

		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

            
            return isErrorOccurred;
        }


    StockListStoreComponent_66600_onChange = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
		KuikaAppManager.increaseServerRequestCount();

        let localVar = {
				StoreCode_0: ReactSystemFunctions.convertToTypeByName(this.props.screenInputs.StoreCode ?? this.props.screenInputs.storecode, "string"),
				UrunTipi_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "stockliststore_66600_value", "value", "TM_GetItemType", "urunTipi", "urunTipi")), "string"),
				Brand_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "stockliststore_190692_value", "value", "TM_GetStockBrands", "brand", "brand")), "string"),
				CategoryName_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "stockliststore_944323_value", "value", "TM_GetCategoriesByStore", "categoryName", "categoryName")), "string"),
				ProductName_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "stockliststore_560082_value", "value", "TM_GetProductNamesByStore", "productName", "productName")), "string"),
				Referance_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "stockliststore_944471_value", "value", "TM_GetReferencesByStore", "referance", "")), "string"),
				Dial_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "stockliststore_651590_value", "value", "TM_GetDialsByStore", "dial", "")), "string"),
				Bracelet_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "stockliststore_831544_value", "value", "TM_GetBraceletsByStore", "bracelet", "bracelet")), "string"),
				Durum_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toInteger(this, ReactSystemFunctions.value(this, "stockliststore_466548_value", "value", "", "key", "")), "number")
        }

		KuikaAppManager.showSpinner(this);
		
        if (true) {
        KuikaAppManager.showSpinner(this);
        }
        let result = await KuikaAppManager.ApiRequest(this, "StockListStore/StockListStoreComponent_66600_onChange", localVar)
        if (!KMainFunctions.IsResStatus2XX(result)) return true;

			stateVars.TM_GetInventoryByUserStore = result?.data.tM_GetInventoryByUserStore;
			
			this.props.form?.setFieldsValue(formVars);
			
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.StockListStoreComponent_66600_onChange1_();
                  resolve();
                });
          })



        
        KuikaAppManager.hideSpinner(this);
        return isErrorOccurred;
    }
		StockListStoreComponent_66600_onChange1_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }

				
				stateVars.dataSource_968810 = stateVars.TM_GetInventoryByUserStore ?? this.state.TM_GetInventoryByUserStore;

		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

            
            return isErrorOccurred;
        }




    StockListStoreComponent_190692_onChange = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
		KuikaAppManager.increaseServerRequestCount();

        let localVar = {
				StoreCode_0: ReactSystemFunctions.convertToTypeByName(this.props.screenInputs.StoreCode ?? this.props.screenInputs.storecode, "string"),
				UrunTipi_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "stockliststore_66600_value", "value", "TM_GetItemType", "urunTipi", "urunTipi")), "string"),
				Brand_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "stockliststore_190692_value", "value", "TM_GetStockBrands", "brand", "brand")), "string"),
				CategoryName_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "stockliststore_944323_value", "value", "TM_GetCategoriesByStore", "categoryName", "categoryName")), "string"),
				ProductName_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "stockliststore_560082_value", "value", "TM_GetProductNamesByStore", "productName", "productName")), "string"),
				Referance_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "stockliststore_944471_value", "value", "TM_GetReferencesByStore", "referance", "")), "string"),
				Dial_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "stockliststore_651590_value", "value", "TM_GetDialsByStore", "dial", "")), "string"),
				Bracelet_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "stockliststore_831544_value", "value", "TM_GetBraceletsByStore", "bracelet", "bracelet")), "string"),
				Durum_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toInteger(this, ReactSystemFunctions.value(this, "stockliststore_466548_value", "value", "", "key", "")), "number")
        }

		KuikaAppManager.showSpinner(this);
		
        if (true) {
        KuikaAppManager.showSpinner(this);
        }
        let result = await KuikaAppManager.ApiRequest(this, "StockListStore/StockListStoreComponent_190692_onChange", localVar)
        if (!KMainFunctions.IsResStatus2XX(result)) return true;

			stateVars.TM_GetInventoryByUserStore = result?.data.tM_GetInventoryByUserStore;
			
			this.props.form?.setFieldsValue(formVars);
			
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.StockListStoreComponent_190692_onChange1_();
                  resolve();
                });
          })



        
        KuikaAppManager.hideSpinner(this);
        return isErrorOccurred;
    }
		StockListStoreComponent_190692_onChange1_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }

				
				stateVars.dataSource_968810 = stateVars.TM_GetInventoryByUserStore ?? this.state.TM_GetInventoryByUserStore;

		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

            
            return isErrorOccurred;
        }




    StockListStoreComponent_560082_onChange = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
		KuikaAppManager.increaseServerRequestCount();

        let localVar = {
				StoreCode_0: ReactSystemFunctions.convertToTypeByName(this.props.screenInputs.StoreCode ?? this.props.screenInputs.storecode, "string"),
				UrunTipi_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "stockliststore_66600_value", "value", "TM_GetItemType", "urunTipi", "urunTipi")), "string"),
				Brand_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "stockliststore_190692_value", "value", "TM_GetStockBrands", "brand", "brand")), "string"),
				CategoryName_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "stockliststore_944323_value", "value", "TM_GetCategoriesByStore", "categoryName", "categoryName")), "string"),
				ProductName_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "stockliststore_560082_value", "value", "TM_GetProductNamesByStore", "productName", "productName")), "string"),
				Referance_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "stockliststore_944471_value", "value", "TM_GetReferencesByStore", "referance", "")), "string"),
				Dial_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "stockliststore_651590_value", "value", "TM_GetDialsByStore", "dial", "")), "string"),
				Bracelet_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "stockliststore_831544_value", "value", "TM_GetBraceletsByStore", "bracelet", "bracelet")), "string"),
				Durum_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toInteger(this, ReactSystemFunctions.value(this, "stockliststore_466548_value", "value", "", "key", "")), "number")
        }

		KuikaAppManager.showSpinner(this);
		
        if (true) {
        KuikaAppManager.showSpinner(this);
        }
        let result = await KuikaAppManager.ApiRequest(this, "StockListStore/StockListStoreComponent_560082_onChange", localVar)
        if (!KMainFunctions.IsResStatus2XX(result)) return true;

			stateVars.TM_GetInventoryByUserStore = result?.data.tM_GetInventoryByUserStore;
			
			this.props.form?.setFieldsValue(formVars);
			
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.StockListStoreComponent_560082_onChange1_();
                  resolve();
                });
          })



        
        KuikaAppManager.hideSpinner(this);
        return isErrorOccurred;
    }
		StockListStoreComponent_560082_onChange1_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }

				
				stateVars.dataSource_968810 = stateVars.TM_GetInventoryByUserStore ?? this.state.TM_GetInventoryByUserStore;

		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

            
            return isErrorOccurred;
        }




    StockListStoreComponent_944323_onChange = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
		KuikaAppManager.increaseServerRequestCount();

        let localVar = {
				StoreCode_0: ReactSystemFunctions.convertToTypeByName(this.props.screenInputs.StoreCode ?? this.props.screenInputs.storecode, "string"),
				UrunTipi_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "stockliststore_66600_value", "value", "TM_GetItemType", "urunTipi", "urunTipi")), "string"),
				Brand_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "stockliststore_190692_value", "value", "TM_GetStockBrands", "brand", "brand")), "string"),
				CategoryName_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "stockliststore_944323_value", "value", "TM_GetCategoriesByStore", "categoryName", "categoryName")), "string"),
				ProductName_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "stockliststore_560082_value", "value", "TM_GetProductNamesByStore", "productName", "productName")), "string"),
				Referance_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "stockliststore_944471_value", "value", "TM_GetReferencesByStore", "referance", "")), "string"),
				Dial_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "stockliststore_651590_value", "value", "TM_GetDialsByStore", "dial", "")), "string"),
				Bracelet_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "stockliststore_831544_value", "value", "TM_GetBraceletsByStore", "bracelet", "bracelet")), "string"),
				Durum_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toInteger(this, ReactSystemFunctions.value(this, "stockliststore_466548_value", "value", "", "key", "")), "number")
        }

		KuikaAppManager.showSpinner(this);
		
        if (true) {
        KuikaAppManager.showSpinner(this);
        }
        let result = await KuikaAppManager.ApiRequest(this, "StockListStore/StockListStoreComponent_944323_onChange", localVar)
        if (!KMainFunctions.IsResStatus2XX(result)) return true;

			stateVars.TM_GetInventoryByUserStore = result?.data.tM_GetInventoryByUserStore;
			
			this.props.form?.setFieldsValue(formVars);
			
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.StockListStoreComponent_944323_onChange1_();
                  resolve();
                });
          })



        
        KuikaAppManager.hideSpinner(this);
        return isErrorOccurred;
    }
		StockListStoreComponent_944323_onChange1_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }

				
				stateVars.dataSource_968810 = stateVars.TM_GetInventoryByUserStore ?? this.state.TM_GetInventoryByUserStore;

		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

            
            return isErrorOccurred;
        }




    StockListStoreComponent_944471_onChange = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
		KuikaAppManager.increaseServerRequestCount();

        let localVar = {
				StoreCode_0: ReactSystemFunctions.convertToTypeByName(this.props.screenInputs.StoreCode ?? this.props.screenInputs.storecode, "string"),
				UrunTipi_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "stockliststore_66600_value", "value", "TM_GetItemType", "urunTipi", "urunTipi")), "string"),
				Brand_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "stockliststore_190692_value", "value", "TM_GetStockBrands", "brand", "brand")), "string"),
				CategoryName_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "stockliststore_944323_value", "value", "TM_GetCategoriesByStore", "categoryName", "categoryName")), "string"),
				ProductName_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "stockliststore_560082_value", "value", "TM_GetProductNamesByStore", "productName", "productName")), "string"),
				Referance_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "stockliststore_944471_value", "value", "TM_GetReferencesByStore", "referance", "")), "string"),
				Dial_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "stockliststore_651590_value", "value", "TM_GetDialsByStore", "dial", "")), "string"),
				Bracelet_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "stockliststore_831544_value", "value", "TM_GetBraceletsByStore", "bracelet", "bracelet")), "string"),
				Durum_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toInteger(this, ReactSystemFunctions.value(this, "stockliststore_466548_value", "value", "", "key", "")), "number")
        }

		KuikaAppManager.showSpinner(this);
		
        if (true) {
        KuikaAppManager.showSpinner(this);
        }
        let result = await KuikaAppManager.ApiRequest(this, "StockListStore/StockListStoreComponent_944471_onChange", localVar)
        if (!KMainFunctions.IsResStatus2XX(result)) return true;

			stateVars.TM_GetInventoryByUserStore = result?.data.tM_GetInventoryByUserStore;
			
			this.props.form?.setFieldsValue(formVars);
			
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.StockListStoreComponent_944471_onChange1_();
                  resolve();
                });
          })



        
        KuikaAppManager.hideSpinner(this);
        return isErrorOccurred;
    }
		StockListStoreComponent_944471_onChange1_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }

				
				stateVars.dataSource_968810 = stateVars.TM_GetInventoryByUserStore ?? this.state.TM_GetInventoryByUserStore;

		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

            
            return isErrorOccurred;
        }




    StockListStoreComponent_651590_onChange = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
		KuikaAppManager.increaseServerRequestCount();

        let localVar = {
				StoreCode_0: ReactSystemFunctions.convertToTypeByName(this.props.screenInputs.StoreCode ?? this.props.screenInputs.storecode, "string"),
				UrunTipi_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "stockliststore_66600_value", "value", "TM_GetItemType", "urunTipi", "urunTipi")), "string"),
				Brand_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "stockliststore_190692_value", "value", "TM_GetStockBrands", "brand", "brand")), "string"),
				CategoryName_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "stockliststore_944323_value", "value", "TM_GetCategoriesByStore", "categoryName", "categoryName")), "string"),
				ProductName_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "stockliststore_560082_value", "value", "TM_GetProductNamesByStore", "productName", "productName")), "string"),
				Referance_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "stockliststore_944471_value", "value", "TM_GetReferencesByStore", "referance", "")), "string"),
				Dial_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "stockliststore_651590_value", "value", "TM_GetDialsByStore", "dial", "")), "string"),
				Bracelet_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "stockliststore_831544_value", "value", "TM_GetBraceletsByStore", "bracelet", "bracelet")), "string"),
				Durum_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toInteger(this, ReactSystemFunctions.value(this, "stockliststore_466548_value", "value", "", "key", "")), "number")
        }

		KuikaAppManager.showSpinner(this);
		
        if (true) {
        KuikaAppManager.showSpinner(this);
        }
        let result = await KuikaAppManager.ApiRequest(this, "StockListStore/StockListStoreComponent_651590_onChange", localVar)
        if (!KMainFunctions.IsResStatus2XX(result)) return true;

			stateVars.TM_GetInventoryByUserStore = result?.data.tM_GetInventoryByUserStore;
			
			this.props.form?.setFieldsValue(formVars);
			
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.StockListStoreComponent_651590_onChange1_();
                  resolve();
                });
          })



        
        KuikaAppManager.hideSpinner(this);
        return isErrorOccurred;
    }
		StockListStoreComponent_651590_onChange1_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }

				
				stateVars.dataSource_968810 = stateVars.TM_GetInventoryByUserStore ?? this.state.TM_GetInventoryByUserStore;

		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

            
            return isErrorOccurred;
        }




    StockListStoreComponent_831544_onChange = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
		KuikaAppManager.increaseServerRequestCount();

        let localVar = {
				StoreCode_0: ReactSystemFunctions.convertToTypeByName(this.props.screenInputs.StoreCode ?? this.props.screenInputs.storecode, "string"),
				UrunTipi_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "stockliststore_66600_value", "value", "TM_GetItemType", "urunTipi", "urunTipi")), "string"),
				Brand_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "stockliststore_190692_value", "value", "TM_GetStockBrands", "brand", "brand")), "string"),
				CategoryName_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "stockliststore_944323_value", "value", "TM_GetCategoriesByStore", "categoryName", "categoryName")), "string"),
				ProductName_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "stockliststore_560082_value", "value", "TM_GetProductNamesByStore", "productName", "productName")), "string"),
				Referance_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "stockliststore_944471_value", "value", "TM_GetReferencesByStore", "referance", "")), "string"),
				Dial_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "stockliststore_651590_value", "value", "TM_GetDialsByStore", "dial", "")), "string"),
				Bracelet_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "stockliststore_831544_value", "value", "TM_GetBraceletsByStore", "bracelet", "bracelet")), "string"),
				Durum_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toInteger(this, ReactSystemFunctions.value(this, "stockliststore_466548_value", "value", "", "key", "")), "number")
        }

		KuikaAppManager.showSpinner(this);
		
        if (true) {
        KuikaAppManager.showSpinner(this);
        }
        let result = await KuikaAppManager.ApiRequest(this, "StockListStore/StockListStoreComponent_831544_onChange", localVar)
        if (!KMainFunctions.IsResStatus2XX(result)) return true;

			stateVars.TM_GetInventoryByUserStore = result?.data.tM_GetInventoryByUserStore;
			
			this.props.form?.setFieldsValue(formVars);
			
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.StockListStoreComponent_831544_onChange1_();
                  resolve();
                });
          })



        
        KuikaAppManager.hideSpinner(this);
        return isErrorOccurred;
    }
		StockListStoreComponent_831544_onChange1_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }

				
				stateVars.dataSource_968810 = stateVars.TM_GetInventoryByUserStore ?? this.state.TM_GetInventoryByUserStore;

		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

            
            return isErrorOccurred;
        }




    StockListStoreComponent_466548_onChange = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
		KuikaAppManager.increaseServerRequestCount();

        let localVar = {
				StoreCode_0: ReactSystemFunctions.convertToTypeByName(this.props.screenInputs.StoreCode ?? this.props.screenInputs.storecode, "string"),
				UrunTipi_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "stockliststore_66600_value", "value", "TM_GetItemType", "urunTipi", "urunTipi")), "string"),
				Brand_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "stockliststore_190692_value", "value", "TM_GetStockBrands", "brand", "brand")), "string"),
				CategoryName_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "stockliststore_944323_value", "value", "TM_GetCategoriesByStore", "categoryName", "categoryName")), "string"),
				ProductName_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "stockliststore_560082_value", "value", "TM_GetProductNamesByStore", "productName", "productName")), "string"),
				Referance_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "stockliststore_944471_value", "value", "TM_GetReferencesByStore", "referance", "")), "string"),
				Dial_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "stockliststore_651590_value", "value", "TM_GetDialsByStore", "dial", "")), "string"),
				Bracelet_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "stockliststore_831544_value", "value", "TM_GetBraceletsByStore", "bracelet", "bracelet")), "string"),
				Durum_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toInteger(this, ReactSystemFunctions.value(this, "stockliststore_466548_value", "value", "", "key", "")), "number")
        }

		KuikaAppManager.showSpinner(this);
		
        if (true) {
        KuikaAppManager.showSpinner(this);
        }
        let result = await KuikaAppManager.ApiRequest(this, "StockListStore/StockListStoreComponent_466548_onChange", localVar)
        if (!KMainFunctions.IsResStatus2XX(result)) return true;

			stateVars.TM_GetInventoryByUserStore = result?.data.tM_GetInventoryByUserStore;
			
			this.props.form?.setFieldsValue(formVars);
			
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.StockListStoreComponent_466548_onChange1_();
                  resolve();
                });
          })



        
        KuikaAppManager.hideSpinner(this);
        return isErrorOccurred;
    }
		StockListStoreComponent_466548_onChange1_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }

				
				stateVars.dataSource_968810 = stateVars.TM_GetInventoryByUserStore ?? this.state.TM_GetInventoryByUserStore;

		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

            
            return isErrorOccurred;
        }




		StockListStoreComponent_702276_onClick = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
KuikaAppManager.showSpinner(this);

				stateVars.SetValueOf = await ReactSystemFunctions.setValueOf(this, ReactSystemFunctions.convertToTypeByName("stockliststore_190692_value", "string"), null, null, "Brand");
				stateVars.SetValueOf = await ReactSystemFunctions.setValueOf(this, ReactSystemFunctions.convertToTypeByName("stockliststore_560082_value", "string"), null, null, "ProductName");
				stateVars.SetValueOf = await ReactSystemFunctions.setValueOf(this, ReactSystemFunctions.convertToTypeByName("stockliststore_944323_value", "string"), null, null, "CategoryName");
				stateVars.SetValueOf = await ReactSystemFunctions.setValueOf(this, ReactSystemFunctions.convertToTypeByName("stockliststore_944471_value", "string"), null, null, "Referance");
				stateVars.SetValueOf = await ReactSystemFunctions.setValueOf(this, ReactSystemFunctions.convertToTypeByName("stockliststore_651590_value", "string"), null, null, "Dial");
				stateVars.SetValueOf = await ReactSystemFunctions.setValueOf(this, ReactSystemFunctions.convertToTypeByName("stockliststore_831544_value", "string"), null, null, "Bracelet");
				stateVars.SetValueOf = await ReactSystemFunctions.setValueOf(this, ReactSystemFunctions.convertToTypeByName("stockliststore_466548_value", "string"), null, null, "Key");
				stateVars.SetValueOf = await ReactSystemFunctions.setValueOf(this, ReactSystemFunctions.convertToTypeByName("stockliststore_66600_value", "string"), null, null, "UrunTipi");

		this.props.form?.setFieldsValue(formVars);
		
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.StockListStoreComponent_702276_onClick1_();
                  resolve();
                });
          })

            
            return isErrorOccurred;
        }
    StockListStoreComponent_702276_onClick1_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
		KuikaAppManager.increaseServerRequestCount();

        let localVar = {
				StoreCode_0: ReactSystemFunctions.convertToTypeByName(this.props.screenInputs.StoreCode ?? this.props.screenInputs.storecode, "string"),
				UrunTipi_0: ReactSystemFunctions.convertToTypeByName(null, "string"),
				Brand_0: ReactSystemFunctions.convertToTypeByName(null, "string"),
				CategoryName_0: ReactSystemFunctions.convertToTypeByName(null, "string"),
				ProductName_0: ReactSystemFunctions.convertToTypeByName(null, "string"),
				Referance_0: ReactSystemFunctions.convertToTypeByName(null, "string"),
				Dial_0: ReactSystemFunctions.convertToTypeByName(null, "string"),
				Bracelet_0: ReactSystemFunctions.convertToTypeByName(null, "string"),
				Durum_0: ReactSystemFunctions.convertToTypeByName(0, "number")
        }

		
        if (true) {
        KuikaAppManager.showSpinner(this);
        }
        let result = await KuikaAppManager.ApiRequest(this, "StockListStore/StockListStoreComponent_702276_onClick1_", localVar)
        if (!KMainFunctions.IsResStatus2XX(result)) return true;

			stateVars.TM_GetInventoryByUserStore = result?.data.tM_GetInventoryByUserStore;
			
			this.props.form?.setFieldsValue(formVars);
			
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.StockListStoreComponent_702276_onClick2_();
                  resolve();
                });
          })



        
        KuikaAppManager.hideSpinner(this);
        return isErrorOccurred;
    }
		StockListStoreComponent_702276_onClick2_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }

				
				stateVars.dataSource_968810 = stateVars.TM_GetInventoryByUserStore ?? this.state.TM_GetInventoryByUserStore;

		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

            
            return isErrorOccurred;
        }





		StockListStoreComponent_274123_onClick = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
KuikaAppManager.showSpinner(this);

const __currentPath = (window.location.hash ? window.location.hash.replace(/^#/, '').split('?')[0] : window.location.pathname.split('?')[0]).toLowerCase();
if (__currentPath !== "/stocklistdetail") {
  this.context.setMasterPageInitLoaded(false);
  this.context.setMasterPageRecurringLoaded(false);
  this.context.setShouldTriggerPageInit(true);
}
					KuikaAppManager.prepareForNavigation();
						KuikaAppManager.addToPageInputVariables("StockListDetail", "ProductCode", ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, "stockliststore_968810_value", "productCode"), "string"));
						KuikaAppManager.addToPageInputVariables("StockListDetail", "StoreCode", ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, "stockliststore_968810_value", "storeCode"), "string"));

				stateVars.NAVIGATE = await ReactSystemFunctions.navigate(this, undefined, "StockListStore", "StockListDetail", "", "currentPage", null, null, null, null, null, null, true, false);

		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

            
            return isErrorOccurred;
        }




    async callCallbackFunction(diId: number, isFromMaster: boolean = false) {
        let isErrorOccurred = false;
		let pageInitCallerNavDiIDs = [] as number[];
		if (isFromMaster || pageInitCallerNavDiIDs.indexOf(diId) > -1) {
			await this.StockListStorePageInit();
		}

    }


}
