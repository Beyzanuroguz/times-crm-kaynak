import React from "react";
import Axios, { AxiosResponse } from "axios";
import { KuikaAppManager } from "../../shared/utilty/kuika-app-manager";
import { ReactSystemFunctions } from "../../shared/utilty/react-system-functions";
import { KNavigator } from "../../shared/hoc/with-history";
import { KContext } from "../../shared/hoc/with-context";
import { useLocation } from "react-router-dom";
import { FormInstance } from "antd/es/form";
import { Guid } from "guid-typescript";
import Swal from "sweetalert2";
import { KMainFunctions } from "../../shared/utilty/main-functions";
import moment from "moment";
import { IValidationData } from "../../models/dto/validation-data";
import { IStripePayment } from "../../models/dto/stripe-payment";
import { IUserInfoDto } from "../../models/dto/user-info.dto";
import { UserService } from "../../services/user-service";
import { kuikaCoreWasmBridgeService } from "../../services/_singletons";
import _ from "lodash";
import mqtt, { MqttClient } from "mqtt";
import { IMqttResult } from "../../models/dto/mqtt.dto";


declare let window: any;

export interface ICustomerUpdatePost_ScreenProps {
  navigator: KNavigator;
  form: FormInstance<any>;
  googleLogin: any;
  screenInputs: any;
  context: KContext;
  initialValues: any;
  children: any;
}

export interface ICustomerUpdatePost_ScreenState {
    isSpinnerVisible: boolean;
    isPageVisible: boolean;
	isLeftMenuVisible: boolean;
    spinnerCount: number;
    selectedLanguage: string;
    isPageInitLoaded: false;
    isPageRecurringLoaded: false;
	TM_GetCustomerUpdate: any[];
	TM_GetCustomerUpdate_dummy: any[];
	Kuika_CurrAccAttribute: any[];
	Kuika_CurrAccAttribute_dummy: any[];
	TM_GetCountry: any[];
	TM_GetCountry_dummy: any[];
	TM_GetCitySql: any[];
	TM_GetCitySql_dummy: any[];
	TM_GetDistrict: any[];
	TM_GetDistrict_dummy: any[];
	SirketTipi: any[];
	SirketTipi_dummy: any[];
	GetTaxOffices: any[];
	GetTaxOffices_dummy: any[];
	GoBack: any;
	GoBack_dummy: any;
	SetValueOf: any;
	SetValueOf_dummy: any;
	ChangeEnabledOf: any;
	ChangeEnabledOf_dummy: any;
	IfThenElse: boolean;
	IfThenElse_dummy: boolean;
	UpdateCustomer: any;
	UpdateCustomer_dummy: any;
	Notify: boolean;
	Notify_dummy: boolean;
	isComp107316Enabled: 'enabled' | 'disabled';
	isComp627602Enabled: 'enabled' | 'disabled';
	isComp965730Enabled: 'enabled' | 'disabled';
	isComp585027Enabled: 'enabled' | 'disabled';
	isComp391058Enabled: 'enabled' | 'disabled';
	isComp560950Enabled: 'enabled' | 'disabled';

}

export class CustomerUpdatePost_ScreenBase extends React.PureComponent<ICustomerUpdatePost_ScreenProps, any> {

	customerupdatepost_586416_value_kuikaSelectBoxRef: React.RefObject<any>;
	customerupdatepost_557630998_value_kuikaSelectBoxRef: React.RefObject<any>;
	customerupdatepost_519157866_value_kuikaSelectBoxRef: React.RefObject<any>;
	customerupdatepost_941270_value_kuikaSelectBoxRef: React.RefObject<any>;
	customerupdatepost_846303_value_kuikaSelectBoxRef: React.RefObject<any>;
	customerupdatepost_469746_value_kuikaSelectBoxRef: React.RefObject<any>;
	customerupdatepost_407342_value_kuikaSelectBoxRef: React.RefObject<any>;
	customerupdatepost_174356_value_kuikaDateRef: React.RefObject<any>;
	customerupdatepost_585027_value_kuikaSelectBoxRef: React.RefObject<any>;
	customerupdatepost_560950_value_kuikaDateRef: React.RefObject<any>;
    ml=[{"Id":"d5a61d2b-bd60-485f-86e2-661e9ed4e486","Name":"en_US","ShortName":"English","IsDefault":true,"LanguagePhrases":[]},{"Id":"f0697928-9327-4f76-bc1b-22a6b3caa62b","Name":"FixedValues","ShortName":"FixedValues","LanguagePhrases":[{"Id":432253,"PropertyName":"value","Value":"Müşteri Güncelle"},{"Id":586924,"PropertyName":"value","Value":"Genel Bilgiler"},{"Id":307657,"PropertyName":"value","Value":"Ad*"},{"Id":627602,"PropertyName":"placeholder","Value":"Ad"},{"Id":795693,"PropertyName":"value","Value":"Soyad*"},{"Id":965730,"PropertyName":"placeholder","Value":"Ad"},{"Id":29863,"PropertyName":"value","Value":"Telefon Numarası*"},{"Id":856033,"PropertyName":"placeholder","Value":"0(xxx) xxx xx xx"},{"Id":789292,"PropertyName":"value","Value":"Email*"},{"Id":196298,"PropertyName":"placeholder","Value":"name@domainname.com"},{"Id":696940,"PropertyName":"value","Value":"Müşteri Tipi*"},{"Id":586416,"PropertyName":"placeholder","Value":"Müşteri Tipi"},{"Id":1515064130,"PropertyName":"value","Value":"E-Dünya Süreci"},{"Id":859821866,"PropertyName":"value","Value":"Şirket Statüsü"},{"Id":455250,"PropertyName":"value","Value":"Adres Bilgileri"},{"Id":719200,"PropertyName":"value","Value":"Ülke*"},{"Id":941270,"PropertyName":"placeholder","Value":"Ülke"},{"Id":521978,"PropertyName":"value","Value":"İl*"},{"Id":846303,"PropertyName":"placeholder","Value":"İl"},{"Id":435698,"PropertyName":"value","Value":"İlçe*"},{"Id":469746,"PropertyName":"placeholder","Value":"İlçe"},{"Id":836456,"PropertyName":"value","Value":"Adres"},{"Id":697352,"PropertyName":"placeholder","Value":"Adres"},{"Id":238773,"PropertyName":"value","Value":"Info"},{"Id":812192,"PropertyName":"value","Value":"Kişisel Bilgiler"},{"Id":47456,"PropertyName":"value","Value":"TC Kimlik Numarası*"},{"Id":107316,"PropertyName":"placeholder","Value":"TC Kimlik Numarası"},{"Id":911272,"PropertyName":"value","Value":"Vergi Numarası"},{"Id":442968,"PropertyName":"placeholder","Value":"Vergi Numarası"},{"Id":18003515,"PropertyName":"value","Value":"Vergi Dairesi"},{"Id":407342,"PropertyName":"placeholder","Value":"Vergi Dairesi"},{"Id":138597,"PropertyName":"value","Value":"Doğum Tarihi"},{"Id":174356,"PropertyName":"placeholder","Value":"Doğum Tarihi"},{"Id":480794,"PropertyName":"value","Value":"Pasaport Ülkesi"},{"Id":585027,"PropertyName":"placeholder","Value":"Pasaport Ülkesi"},{"Id":992182,"PropertyName":"value","Value":"Pasaport No"},{"Id":391058,"PropertyName":"placeholder","Value":"Pasaport Numarası"},{"Id":500037,"PropertyName":"value","Value":"Pasaport Veriliş Tarihi"},{"Id":560950,"PropertyName":"placeholder","Value":"Pasaport Veriliş Tarihi"},{"Id":163827,"PropertyName":"label","Value":"Vazgeç"},{"Id":42731,"PropertyName":"label","Value":"Güncelle"}]}]
    defaultML = "en_US"
    
    screenHash = ""
    


    constructor(props) {
        super(props);
		this.customerupdatepost_627602_value_kuikaTextInputRef = React.createRef();
		this.customerupdatepost_965730_value_kuikaTextInputRef = React.createRef();
		this.customerupdatepost_856033_value_kuikaTextInputRef = React.createRef();
		this.customerupdatepost_586416_value_kuikaSelectBoxRef = React.createRef();
		this.customerupdatepost_557630998_value_kuikaSelectBoxRef = React.createRef();
		this.customerupdatepost_519157866_value_kuikaSelectBoxRef = React.createRef();
		this.customerupdatepost_941270_value_kuikaSelectBoxRef = React.createRef();
		this.customerupdatepost_846303_value_kuikaSelectBoxRef = React.createRef();
		this.customerupdatepost_469746_value_kuikaSelectBoxRef = React.createRef();
		this.customerupdatepost_107316_value_kuikaTextInputRef = React.createRef();
		this.customerupdatepost_442968_value_kuikaTextInputRef = React.createRef();
		this.customerupdatepost_407342_value_kuikaSelectBoxRef = React.createRef();
		this.customerupdatepost_174356_value_kuikaDateRef = React.createRef();
		this.customerupdatepost_585027_value_kuikaSelectBoxRef = React.createRef();
		this.customerupdatepost_391058_value_kuikaTextInputRef = React.createRef();
		this.customerupdatepost_560950_value_kuikaDateRef = React.createRef();

        this.state = {
            isSpinnerVisible: false,
            isPageVisible: false,
            isLeftMenuVisible: false,
            spinnerCount: 0,
            selectedLanguage: "",
            isPageInitLoaded: false,
            isPageRecurringLoaded: false,
            	        TM_GetCustomerUpdate: [],
	        Kuika_CurrAccAttribute: [],
	        TM_GetCountry: [],
	        TM_GetCitySql: [],
	        TM_GetDistrict: [],
	        SirketTipi: [],
	        GetTaxOffices: [],
	        GoBack: "",
	        IfThenElse: false,
	        UpdateCustomer: "",
	        Notify: false,
	        dataSource_557630998: [{"key":"0","text":"E-Arşive Tabiidir"},{"key":"1","text":"E-Faturaya Tabiidir"}],
	        isComp107316Enabled: 'enabled',
	        isComp627602Enabled: 'disabled',
	        isComp965730Enabled: 'disabled',
	        isComp585027Enabled: 'disabled',
	        isComp391058Enabled: 'disabled',
	        isComp560950Enabled: 'disabled',

        }

        this.CheckPageAuthorization(this.state);

        
    }

    async componentDidMount() {

        if (KuikaAppManager.isPageInitPrevented()) {
            KuikaAppManager.calculateAndSetBodyHeight("customerupdatepost", "");
            return;
        }
        
        
        ReactSystemFunctions.validateToken()
        this.fillFormInitValues();
        if (true){
            await this.CustomerUpdatePostPageInit();
        }
        
        
        
        KuikaAppManager.calculateAndSetBodyHeight("customerupdatepost", "");

        if (ReactSystemFunctions.getIsMicroApp() === false) {
           window.parentScreen = this;
        }
    }

    componentWillUnmount() {
        
        
        

        if (ReactSystemFunctions.getIsMicroApp() === false) {
           window.parentScreen = null;
        }
    }

    
              CheckPageAuthorization = async (state) => {
                KuikaAppManager.showSpinner(this);
                if (_.isEmpty(window.userInfo)) {
                  await UserService.GetUserInfoForce();
                }
                const permittedRoleNames: string[] = ["TimesYonetici","TimesUstYonetici","TimesSatisPersoneli","TimesMagazaMuduru","TimesAdmin",];
                const userInfo = window.userInfo as IUserInfoDto;
                const userRoleNames = userInfo.roles.map((role) => role.name);
                if (!ReactSystemFunctions.hasAnyRoleName(permittedRoleNames, userRoleNames)) {
                  await ReactSystemFunctions.goBack(this);

                  const language = localStorage.getItem("ml");
                  let permissonErrorMessageText = "You do not have permission to access this page.";
                  if (language === "tr_TR") {
                    permissonErrorMessageText = "Bu sayfaya erişim yetkiniz yok.";
                  } else if (language === "fr_FR") {
                    permissonErrorMessageText = "Vous n'avez pas la permission d'accéder à cette page.";
                  } else if (language === "de_DE") {
                    permissonErrorMessageText = "Sie haben keine Berechtigung, auf diese Seite zuzugreifen.";
                  } else if (language === "es_ES") {
                    permissonErrorMessageText = "No tienes permiso para acceder a esta página.";
                  }

                  KMainFunctions.displayErrorNotification(permissonErrorMessageText);
                  state.isPageVisible = false;
                  KuikaAppManager.hideSpinner(this);
                  return;
                }
                state.isPageVisible = true;
                KuikaAppManager.hideSpinner(this);
              };
        

        
    componentDidUpdate= async (prevProps, prevState) => {
		KuikaAppManager.calculateAndSetBodyHeight("customerupdatepost", ""    );
        if (prevProps?.location?.search !== (this.props as any)?.location?.search) {
			await this.CustomerUpdatePostPageInit();
		}

        

        if (ReactSystemFunctions.getIsMicroApp() === false) {
            for (const key in prevState) {
                if (key.startsWith('NavVisible') && prevState[key] === true && this.state[key] === false) {
                    window.parentScreen = this;
                    break;
                }
            }
        }
	}

    fillFormInitValues() {
        this.props.form?.setFieldsValue({
customerupdatepost_627602_value: this.state.TM_GetCustomerUpdate?.at?.(0)?.name ?? undefined,
customerupdatepost_965730_value: this.state.TM_GetCustomerUpdate?.at?.(0)?.lastName ?? undefined,
customerupdatepost_856033_value: this.state.TM_GetCustomerUpdate?.at?.(0)?.tel ?? undefined,
customerupdatepost_196298_value: this.state.TM_GetCustomerUpdate?.at?.(0)?.email ?? undefined,
customerupdatepost_586416_value: this.state.TM_GetCustomerUpdate?.at?.(0)?.customerTypeCode ?? undefined,
customerupdatepost_557630998_value: this.state.TM_GetCustomerUpdate?.at?.(0)?.isEInvoiceSelectValue ?? undefined,
customerupdatepost_519157866_value: this.state.TM_GetCustomerUpdate?.at?.(0)?.isIndividualSelectValue ?? undefined,
customerupdatepost_941270_value: this.state.TM_GetCustomerUpdate?.at?.(0)?.countryCode ?? undefined,
customerupdatepost_846303_value: this.state.TM_GetCustomerUpdate?.at?.(0)?.cityCode ?? undefined,
customerupdatepost_469746_value: this.state.TM_GetCustomerUpdate?.at?.(0)?.districtCode ?? undefined,
customerupdatepost_697352_value: this.state.TM_GetCustomerUpdate?.at?.(0)?.address ?? undefined,
customerupdatepost_941555_value: this.state.TM_GetCustomerUpdate?.at?.(0)?.info ?? undefined,
customerupdatepost_107316_value: this.state.TM_GetCustomerUpdate?.at?.(0)?.nationalID ?? undefined,
customerupdatepost_442968_value: this.state.TM_GetCustomerUpdate?.at?.(0)?.taxNumber ?? undefined,
customerupdatepost_407342_value: this.state.TM_GetCustomerUpdate?.at?.(0)?.taxOfficeActualCode ?? undefined,
customerupdatepost_174356_value: this.state.TM_GetCustomerUpdate?.at?.(0)?.birthDate ?? undefined,
customerupdatepost_585027_value: this.state.TM_GetCustomerUpdate?.at?.(0)?.pasaportCountryCode ?? undefined,
customerupdatepost_391058_value: this.state.TM_GetCustomerUpdate?.at?.(0)?.pasaportNo ?? undefined,
customerupdatepost_560950_value: this.state.TM_GetCustomerUpdate?.at?.(0)?.passaportIssueDate ?? undefined
});

    }

      setPageInitLoaded = (value: boolean) => {
        this.setState({ isPageInitLoaded: value });
      }

      setPageRecurringLoaded = (value: boolean) => {
        this.setState({ isPageRecurringLoaded: value });
      }

      clearFieldValidation = (changedValues: any) => {
        const fieldName = Object.keys(changedValues)[0];
        if (fieldName) {
          this.props.form?.setFields([
            {
              name: fieldName,
              errors: []
            }
          ]);
        }
      };

      

    CustomerUpdatePostPageInit = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


	if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }

        let localVar = {
			CustomerId_0: ReactSystemFunctions.convertToTypeByName(this.props.screenInputs.CustomerId ?? this.props.screenInputs.customerid, "Guid"),
			CountryCode_3: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, (stateVars.TM_GetCustomerUpdate !== undefined ? (stateVars.TM_GetCustomerUpdate?.length > 0 ? stateVars.TM_GetCustomerUpdate[0].countryCode : null) : (this.state.TM_GetCustomerUpdate?.length > 0 ? this.state.TM_GetCustomerUpdate[0].countryCode : null))), "string"),
			CityCode_4: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, (stateVars.TM_GetCustomerUpdate !== undefined ? (stateVars.TM_GetCustomerUpdate?.length > 0 ? stateVars.TM_GetCustomerUpdate[0].cityCode : null) : (this.state.TM_GetCustomerUpdate?.length > 0 ? this.state.TM_GetCustomerUpdate[0].cityCode : null))), "string"),
			cityCode_6: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, (stateVars.TM_GetCustomerUpdate !== undefined ? (stateVars.TM_GetCustomerUpdate?.length > 0 ? stateVars.TM_GetCustomerUpdate[0].cityCode : null) : (this.state.TM_GetCustomerUpdate?.length > 0 ? this.state.TM_GetCustomerUpdate[0].cityCode : null))), "string")
        }

	KuikaAppManager.showSpinner(this);
	
        if (true) {
        KuikaAppManager.showSpinner(this);
        }
        let result = await KuikaAppManager.ApiRequest(this, "CustomerUpdatePost/CustomerUpdatePostPageInit", localVar)
        if (!KMainFunctions.IsResStatus2XX(result)) return true;

		stateVars.TM_GetCustomerUpdate = result?.data.tM_GetCustomerUpdate;
		formVars.customerupdatepost_627602_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetCustomerUpdate !== undefined ? (stateVars.TM_GetCustomerUpdate?.length > 0 ? stateVars.TM_GetCustomerUpdate[0].name : null) : (this.state.TM_GetCustomerUpdate?.length > 0 ? this.state.TM_GetCustomerUpdate[0].name : null)));
		formVars.customerupdatepost_965730_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetCustomerUpdate !== undefined ? (stateVars.TM_GetCustomerUpdate?.length > 0 ? stateVars.TM_GetCustomerUpdate[0].lastName : null) : (this.state.TM_GetCustomerUpdate?.length > 0 ? this.state.TM_GetCustomerUpdate[0].lastName : null)));
		formVars.customerupdatepost_856033_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetCustomerUpdate !== undefined ? (stateVars.TM_GetCustomerUpdate?.length > 0 ? stateVars.TM_GetCustomerUpdate[0].tel : null) : (this.state.TM_GetCustomerUpdate?.length > 0 ? this.state.TM_GetCustomerUpdate[0].tel : null)));
		formVars.customerupdatepost_196298_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetCustomerUpdate !== undefined ? (stateVars.TM_GetCustomerUpdate?.length > 0 ? stateVars.TM_GetCustomerUpdate[0].email : null) : (this.state.TM_GetCustomerUpdate?.length > 0 ? this.state.TM_GetCustomerUpdate[0].email : null)));
		formVars.customerupdatepost_586416_value = (stateVars.TM_GetCustomerUpdate !== undefined ? (stateVars.TM_GetCustomerUpdate?.length > 0 ? stateVars.TM_GetCustomerUpdate[0].customerTypeCode : null) : (this.state.TM_GetCustomerUpdate?.length > 0 ? this.state.TM_GetCustomerUpdate[0].customerTypeCode : null));
		formVars.customerupdatepost_586416_options = stateVars.Kuika_CurrAccAttribute;
		formVars.customerupdatepost_557630998_value = (stateVars.TM_GetCustomerUpdate !== undefined ? (stateVars.TM_GetCustomerUpdate?.length > 0 ? stateVars.TM_GetCustomerUpdate[0].isEInvoiceSelectValue : null) : (this.state.TM_GetCustomerUpdate?.length > 0 ? this.state.TM_GetCustomerUpdate[0].isEInvoiceSelectValue : null));
		formVars.customerupdatepost_519157866_value = (stateVars.TM_GetCustomerUpdate !== undefined ? (stateVars.TM_GetCustomerUpdate?.length > 0 ? stateVars.TM_GetCustomerUpdate[0].isIndividualSelectValue : null) : (this.state.TM_GetCustomerUpdate?.length > 0 ? this.state.TM_GetCustomerUpdate[0].isIndividualSelectValue : null));
		formVars.customerupdatepost_519157866_options = stateVars.SirketTipi;
		formVars.customerupdatepost_941270_value = (stateVars.TM_GetCustomerUpdate !== undefined ? (stateVars.TM_GetCustomerUpdate?.length > 0 ? stateVars.TM_GetCustomerUpdate[0].countryCode : null) : (this.state.TM_GetCustomerUpdate?.length > 0 ? this.state.TM_GetCustomerUpdate[0].countryCode : null));
		formVars.customerupdatepost_941270_options = stateVars.TM_GetCountry;
		formVars.customerupdatepost_846303_value = (stateVars.TM_GetCustomerUpdate !== undefined ? (stateVars.TM_GetCustomerUpdate?.length > 0 ? stateVars.TM_GetCustomerUpdate[0].cityCode : null) : (this.state.TM_GetCustomerUpdate?.length > 0 ? this.state.TM_GetCustomerUpdate[0].cityCode : null));
		formVars.customerupdatepost_846303_options = stateVars.TM_GetCitySql;
		formVars.customerupdatepost_469746_value = (stateVars.TM_GetCustomerUpdate !== undefined ? (stateVars.TM_GetCustomerUpdate?.length > 0 ? stateVars.TM_GetCustomerUpdate[0].districtCode : null) : (this.state.TM_GetCustomerUpdate?.length > 0 ? this.state.TM_GetCustomerUpdate[0].districtCode : null));
		formVars.customerupdatepost_469746_options = stateVars.TM_GetDistrict;
		formVars.customerupdatepost_697352_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetCustomerUpdate !== undefined ? (stateVars.TM_GetCustomerUpdate?.length > 0 ? stateVars.TM_GetCustomerUpdate[0].address : null) : (this.state.TM_GetCustomerUpdate?.length > 0 ? this.state.TM_GetCustomerUpdate[0].address : null)));
		formVars.customerupdatepost_941555_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetCustomerUpdate !== undefined ? (stateVars.TM_GetCustomerUpdate?.length > 0 ? stateVars.TM_GetCustomerUpdate[0].info : null) : (this.state.TM_GetCustomerUpdate?.length > 0 ? this.state.TM_GetCustomerUpdate[0].info : null)));
		formVars.customerupdatepost_107316_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetCustomerUpdate !== undefined ? (stateVars.TM_GetCustomerUpdate?.length > 0 ? stateVars.TM_GetCustomerUpdate[0].nationalID : null) : (this.state.TM_GetCustomerUpdate?.length > 0 ? this.state.TM_GetCustomerUpdate[0].nationalID : null)));
		formVars.customerupdatepost_442968_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetCustomerUpdate !== undefined ? (stateVars.TM_GetCustomerUpdate?.length > 0 ? stateVars.TM_GetCustomerUpdate[0].taxNumber : null) : (this.state.TM_GetCustomerUpdate?.length > 0 ? this.state.TM_GetCustomerUpdate[0].taxNumber : null)));
		formVars.customerupdatepost_407342_value = (stateVars.TM_GetCustomerUpdate !== undefined ? (stateVars.TM_GetCustomerUpdate?.length > 0 ? stateVars.TM_GetCustomerUpdate[0].taxOfficeActualCode : null) : (this.state.TM_GetCustomerUpdate?.length > 0 ? this.state.TM_GetCustomerUpdate[0].taxOfficeActualCode : null));
		formVars.customerupdatepost_407342_options = stateVars.GetTaxOffices;
		formVars.customerupdatepost_174356_value = ReactSystemFunctions.value(this, (stateVars.TM_GetCustomerUpdate !== undefined ? (stateVars.TM_GetCustomerUpdate?.length > 0 ? stateVars.TM_GetCustomerUpdate[0].birthDate : null) : (this.state.TM_GetCustomerUpdate?.length > 0 ? this.state.TM_GetCustomerUpdate[0].birthDate : null)));
		formVars.customerupdatepost_585027_value = (stateVars.TM_GetCustomerUpdate !== undefined ? (stateVars.TM_GetCustomerUpdate?.length > 0 ? stateVars.TM_GetCustomerUpdate[0].pasaportCountryCode : null) : (this.state.TM_GetCustomerUpdate?.length > 0 ? this.state.TM_GetCustomerUpdate[0].pasaportCountryCode : null));
		formVars.customerupdatepost_585027_options = stateVars.TM_GetCountry;
		formVars.customerupdatepost_391058_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetCustomerUpdate !== undefined ? (stateVars.TM_GetCustomerUpdate?.length > 0 ? stateVars.TM_GetCustomerUpdate[0].pasaportNo : null) : (this.state.TM_GetCustomerUpdate?.length > 0 ? this.state.TM_GetCustomerUpdate[0].pasaportNo : null)));
		formVars.customerupdatepost_560950_value = ReactSystemFunctions.value(this, (stateVars.TM_GetCustomerUpdate !== undefined ? (stateVars.TM_GetCustomerUpdate?.length > 0 ? stateVars.TM_GetCustomerUpdate[0].passaportIssueDate : null) : (this.state.TM_GetCustomerUpdate?.length > 0 ? this.state.TM_GetCustomerUpdate[0].passaportIssueDate : null)));
		stateVars.Kuika_CurrAccAttribute = result?.data.kuika_CurrAccAttribute;
		
		formVars.customerupdatepost_586416_value = (stateVars.TM_GetCustomerUpdate !== undefined ? (stateVars.TM_GetCustomerUpdate?.length > 0 ? stateVars.TM_GetCustomerUpdate[0].customerTypeCode : null) : (this.state.TM_GetCustomerUpdate?.length > 0 ? this.state.TM_GetCustomerUpdate[0].customerTypeCode : null));
		formVars.customerupdatepost_586416_options = stateVars.Kuika_CurrAccAttribute;
		stateVars.TM_GetCountry = result?.data.tM_GetCountry;
		
		formVars.customerupdatepost_941270_value = (stateVars.TM_GetCustomerUpdate !== undefined ? (stateVars.TM_GetCustomerUpdate?.length > 0 ? stateVars.TM_GetCustomerUpdate[0].countryCode : null) : (this.state.TM_GetCustomerUpdate?.length > 0 ? this.state.TM_GetCustomerUpdate[0].countryCode : null));
		formVars.customerupdatepost_941270_options = stateVars.TM_GetCountry;
		
		formVars.customerupdatepost_585027_value = (stateVars.TM_GetCustomerUpdate !== undefined ? (stateVars.TM_GetCustomerUpdate?.length > 0 ? stateVars.TM_GetCustomerUpdate[0].pasaportCountryCode : null) : (this.state.TM_GetCustomerUpdate?.length > 0 ? this.state.TM_GetCustomerUpdate[0].pasaportCountryCode : null));
		formVars.customerupdatepost_585027_options = stateVars.TM_GetCountry;
		stateVars.TM_GetCitySql = result?.data.tM_GetCitySql;
		
		formVars.customerupdatepost_846303_value = (stateVars.TM_GetCustomerUpdate !== undefined ? (stateVars.TM_GetCustomerUpdate?.length > 0 ? stateVars.TM_GetCustomerUpdate[0].cityCode : null) : (this.state.TM_GetCustomerUpdate?.length > 0 ? this.state.TM_GetCustomerUpdate[0].cityCode : null));
		formVars.customerupdatepost_846303_options = stateVars.TM_GetCitySql;
		stateVars.TM_GetDistrict = result?.data.tM_GetDistrict;
		
		formVars.customerupdatepost_469746_value = (stateVars.TM_GetCustomerUpdate !== undefined ? (stateVars.TM_GetCustomerUpdate?.length > 0 ? stateVars.TM_GetCustomerUpdate[0].districtCode : null) : (this.state.TM_GetCustomerUpdate?.length > 0 ? this.state.TM_GetCustomerUpdate[0].districtCode : null));
		formVars.customerupdatepost_469746_options = stateVars.TM_GetDistrict;
		stateVars.SirketTipi = result?.data.sirketTipi;
		
		formVars.customerupdatepost_519157866_value = (stateVars.TM_GetCustomerUpdate !== undefined ? (stateVars.TM_GetCustomerUpdate?.length > 0 ? stateVars.TM_GetCustomerUpdate[0].isIndividualSelectValue : null) : (this.state.TM_GetCustomerUpdate?.length > 0 ? this.state.TM_GetCustomerUpdate[0].isIndividualSelectValue : null));
		formVars.customerupdatepost_519157866_options = stateVars.SirketTipi;
		stateVars.GetTaxOffices = result?.data.getTaxOffices;
		
		formVars.customerupdatepost_407342_value = (stateVars.TM_GetCustomerUpdate !== undefined ? (stateVars.TM_GetCustomerUpdate?.length > 0 ? stateVars.TM_GetCustomerUpdate[0].taxOfficeActualCode : null) : (this.state.TM_GetCustomerUpdate?.length > 0 ? this.state.TM_GetCustomerUpdate[0].taxOfficeActualCode : null));
		formVars.customerupdatepost_407342_options = stateVars.GetTaxOffices;
		this.props.form?.setFieldsValue(formVars);
		
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.CustomerUpdatePostPageInit1_();
                  resolve();
                });
          })



        
        KuikaAppManager.hideSpinner(this);
        return isErrorOccurred;
    }
	CustomerUpdatePostPageInit1_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


	if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }

			formVars.customerupdatepost_627602_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetCustomerUpdate !== undefined ? (stateVars.TM_GetCustomerUpdate?.length > 0 ? stateVars.TM_GetCustomerUpdate[0].name : null) : (this.state.TM_GetCustomerUpdate?.length > 0 ? this.state.TM_GetCustomerUpdate[0].name : null)));

			formVars.customerupdatepost_965730_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetCustomerUpdate !== undefined ? (stateVars.TM_GetCustomerUpdate?.length > 0 ? stateVars.TM_GetCustomerUpdate[0].lastName : null) : (this.state.TM_GetCustomerUpdate?.length > 0 ? this.state.TM_GetCustomerUpdate[0].lastName : null)));

			formVars.customerupdatepost_856033_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetCustomerUpdate !== undefined ? (stateVars.TM_GetCustomerUpdate?.length > 0 ? stateVars.TM_GetCustomerUpdate[0].tel : null) : (this.state.TM_GetCustomerUpdate?.length > 0 ? this.state.TM_GetCustomerUpdate[0].tel : null)));

			formVars.customerupdatepost_196298_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetCustomerUpdate !== undefined ? (stateVars.TM_GetCustomerUpdate?.length > 0 ? stateVars.TM_GetCustomerUpdate[0].email : null) : (this.state.TM_GetCustomerUpdate?.length > 0 ? this.state.TM_GetCustomerUpdate[0].email : null)));

			formVars.customerupdatepost_586416_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetCustomerUpdate !== undefined ? (stateVars.TM_GetCustomerUpdate?.length > 0 ? stateVars.TM_GetCustomerUpdate[0].customerTypeCode : null) : (this.state.TM_GetCustomerUpdate?.length > 0 ? this.state.TM_GetCustomerUpdate[0].customerTypeCode : null)));

			
			stateVars.dataSource_586416 = stateVars.Kuika_CurrAccAttribute ?? this.state.Kuika_CurrAccAttribute;
			stateVars.dataSource_586416 = stateVars.Kuika_CurrAccAttribute ?? this.state.Kuika_CurrAccAttribute;
			formVars.customerupdatepost_557630998_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetCustomerUpdate !== undefined ? (stateVars.TM_GetCustomerUpdate?.length > 0 ? stateVars.TM_GetCustomerUpdate[0].isEInvoiceSelectValue : null) : (this.state.TM_GetCustomerUpdate?.length > 0 ? this.state.TM_GetCustomerUpdate[0].isEInvoiceSelectValue : null)));

			formVars.customerupdatepost_519157866_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetCustomerUpdate !== undefined ? (stateVars.TM_GetCustomerUpdate?.length > 0 ? stateVars.TM_GetCustomerUpdate[0].isIndividualSelectValue : null) : (this.state.TM_GetCustomerUpdate?.length > 0 ? this.state.TM_GetCustomerUpdate[0].isIndividualSelectValue : null)));

			
			stateVars.dataSource_519157866 = stateVars.SirketTipi ?? this.state.SirketTipi;
			stateVars.dataSource_519157866 = stateVars.SirketTipi ?? this.state.SirketTipi;
			formVars.customerupdatepost_941270_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetCustomerUpdate !== undefined ? (stateVars.TM_GetCustomerUpdate?.length > 0 ? stateVars.TM_GetCustomerUpdate[0].countryCode : null) : (this.state.TM_GetCustomerUpdate?.length > 0 ? this.state.TM_GetCustomerUpdate[0].countryCode : null)));

			
			stateVars.dataSource_941270 = stateVars.TM_GetCountry ?? this.state.TM_GetCountry;
			stateVars.dataSource_941270 = stateVars.TM_GetCountry ?? this.state.TM_GetCountry;
			formVars.customerupdatepost_846303_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetCustomerUpdate !== undefined ? (stateVars.TM_GetCustomerUpdate?.length > 0 ? stateVars.TM_GetCustomerUpdate[0].cityCode : null) : (this.state.TM_GetCustomerUpdate?.length > 0 ? this.state.TM_GetCustomerUpdate[0].cityCode : null)));

			
			stateVars.dataSource_846303 = stateVars.TM_GetCitySql ?? this.state.TM_GetCitySql;
			stateVars.dataSource_846303 = stateVars.TM_GetCitySql ?? this.state.TM_GetCitySql;
			formVars.customerupdatepost_469746_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetCustomerUpdate !== undefined ? (stateVars.TM_GetCustomerUpdate?.length > 0 ? stateVars.TM_GetCustomerUpdate[0].districtCode : null) : (this.state.TM_GetCustomerUpdate?.length > 0 ? this.state.TM_GetCustomerUpdate[0].districtCode : null)));

			
			stateVars.dataSource_469746 = stateVars.TM_GetDistrict ?? this.state.TM_GetDistrict;
			stateVars.dataSource_469746 = stateVars.TM_GetDistrict ?? this.state.TM_GetDistrict;
			formVars.customerupdatepost_697352_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetCustomerUpdate !== undefined ? (stateVars.TM_GetCustomerUpdate?.length > 0 ? stateVars.TM_GetCustomerUpdate[0].address : null) : (this.state.TM_GetCustomerUpdate?.length > 0 ? this.state.TM_GetCustomerUpdate[0].address : null)));

			formVars.customerupdatepost_941555_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetCustomerUpdate !== undefined ? (stateVars.TM_GetCustomerUpdate?.length > 0 ? stateVars.TM_GetCustomerUpdate[0].info : null) : (this.state.TM_GetCustomerUpdate?.length > 0 ? this.state.TM_GetCustomerUpdate[0].info : null)));

			formVars.customerupdatepost_107316_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetCustomerUpdate !== undefined ? (stateVars.TM_GetCustomerUpdate?.length > 0 ? stateVars.TM_GetCustomerUpdate[0].nationalID : null) : (this.state.TM_GetCustomerUpdate?.length > 0 ? this.state.TM_GetCustomerUpdate[0].nationalID : null)));

			formVars.customerupdatepost_442968_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetCustomerUpdate !== undefined ? (stateVars.TM_GetCustomerUpdate?.length > 0 ? stateVars.TM_GetCustomerUpdate[0].taxNumber : null) : (this.state.TM_GetCustomerUpdate?.length > 0 ? this.state.TM_GetCustomerUpdate[0].taxNumber : null)));

			formVars.customerupdatepost_407342_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetCustomerUpdate !== undefined ? (stateVars.TM_GetCustomerUpdate?.length > 0 ? stateVars.TM_GetCustomerUpdate[0].taxOfficeActualCode : null) : (this.state.TM_GetCustomerUpdate?.length > 0 ? this.state.TM_GetCustomerUpdate[0].taxOfficeActualCode : null)));

			
			stateVars.dataSource_407342 = stateVars.GetTaxOffices ?? this.state.GetTaxOffices;
			stateVars.dataSource_407342 = stateVars.GetTaxOffices ?? this.state.GetTaxOffices;
			formVars.customerupdatepost_174356_value = ReactSystemFunctions.value(this, (stateVars.TM_GetCustomerUpdate !== undefined ? (stateVars.TM_GetCustomerUpdate?.length > 0 ? stateVars.TM_GetCustomerUpdate[0].birthDate : null) : (this.state.TM_GetCustomerUpdate?.length > 0 ? this.state.TM_GetCustomerUpdate[0].birthDate : null)));

			formVars.customerupdatepost_585027_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetCustomerUpdate !== undefined ? (stateVars.TM_GetCustomerUpdate?.length > 0 ? stateVars.TM_GetCustomerUpdate[0].pasaportCountryCode : null) : (this.state.TM_GetCustomerUpdate?.length > 0 ? this.state.TM_GetCustomerUpdate[0].pasaportCountryCode : null)));

			
			stateVars.dataSource_585027 = stateVars.TM_GetCountry ?? this.state.TM_GetCountry;
			stateVars.dataSource_585027 = stateVars.TM_GetCountry ?? this.state.TM_GetCountry;
			formVars.customerupdatepost_391058_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetCustomerUpdate !== undefined ? (stateVars.TM_GetCustomerUpdate?.length > 0 ? stateVars.TM_GetCustomerUpdate[0].pasaportNo : null) : (this.state.TM_GetCustomerUpdate?.length > 0 ? this.state.TM_GetCustomerUpdate[0].pasaportNo : null)));

			formVars.customerupdatepost_560950_value = ReactSystemFunctions.value(this, (stateVars.TM_GetCustomerUpdate !== undefined ? (stateVars.TM_GetCustomerUpdate?.length > 0 ? stateVars.TM_GetCustomerUpdate[0].passaportIssueDate : null) : (this.state.TM_GetCustomerUpdate?.length > 0 ? this.state.TM_GetCustomerUpdate[0].passaportIssueDate : null)));


	this.props.form?.setFieldsValue(formVars);
	this.setState(stateVars);
	KuikaAppManager.hideSpinner(this);

            this.setPageInitLoaded(true);
            return isErrorOccurred;
        }




		CustomerUpdatePostComponent_158561_onClick = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
KuikaAppManager.showSpinner(this);

				stateVars.GoBack = await ReactSystemFunctions.goBack(this, false);

		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

            
            return isErrorOccurred;
        }


		CustomerUpdatePostComponent_519157866_onChange_if0 = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
KuikaAppManager.showSpinner(this);

				stateVars.SetValueOf = await ReactSystemFunctions.setValueOf(this, ReactSystemFunctions.convertToTypeByName("customerupdatepost_107316_value", "string"), ReactSystemFunctions.toString(this, (stateVars.TM_GetCustomerUpdate !== undefined ? (stateVars.TM_GetCustomerUpdate?.length > 0 ? stateVars.TM_GetCustomerUpdate[0].nationalID : null) : (this.state.TM_GetCustomerUpdate?.length > 0 ? this.state.TM_GetCustomerUpdate[0].nationalID : null))), null, false);
				stateVars.ChangeEnabledOf = await ReactSystemFunctions.changeEnabledOf(this, ReactSystemFunctions.convertToTypeByName("isComp107316Enabled", "string"), ReactSystemFunctions.convertToTypeByName("enabled", "string"));

		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);

            
            return isErrorOccurred;
        }


		CustomerUpdatePostComponent_519157866_onChange_else0 = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
KuikaAppManager.showSpinner(this);

				stateVars.SetValueOf = await ReactSystemFunctions.setValueOf(this, ReactSystemFunctions.convertToTypeByName("customerupdatepost_107316_value", "string"), "", null, false);
				stateVars.ChangeEnabledOf = await ReactSystemFunctions.changeEnabledOf(this, ReactSystemFunctions.convertToTypeByName("isComp107316Enabled", "string"), ReactSystemFunctions.convertToTypeByName("disabled", "string"));

		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);

            
            return isErrorOccurred;
        }


		CustomerUpdatePostComponent_519157866_onChange = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
if (ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "customerupdatepost_519157866_value", "value", "SirketTipi", "key", "key")), "1")) {
            isErrorOccurred = await this.CustomerUpdatePostComponent_519157866_onChange_if0();
                if (isErrorOccurred) return true;
        } else {
            isErrorOccurred = await this.CustomerUpdatePostComponent_519157866_onChange_else0();
                if (isErrorOccurred) return true;
        }
KuikaAppManager.showSpinner(this);


		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

            
            return isErrorOccurred;
        }


    CustomerUpdatePostComponent_941270_onChange = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;

			validations.push({ 
				isValid: ReactSystemFunctions.isNotEmpty(ReactSystemFunctions.value(this, "customerupdatepost_941270_value", "value", "TM_GetCountry", "countryCode", ""), null),
				message: "Bu alan boş bırakılamaz !",
				formName: "customerupdatepost_941270_value",
				condition: true
			} as IValidationData);

validations.forEach((validation) => {
            if (validation.message === "Geçerli bir mail adresi giriniz.") {
                validation.message = ReactSystemFunctions.getEmailValidationMessage()
            }
        })

		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
		KuikaAppManager.increaseServerRequestCount();

        let localVar = {
				CountryCode_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "customerupdatepost_941270_value", "value", "TM_GetCountry", "countryCode", "countryCode")), "string")
        }

		KuikaAppManager.showSpinner(this);
		
        if (true) {
        KuikaAppManager.showSpinner(this);
        }
        let result = await KuikaAppManager.ApiRequest(this, "CustomerUpdatePost/CustomerUpdatePostComponent_941270_onChange", localVar)
        if (!KMainFunctions.IsResStatus2XX(result)) return true;

			stateVars.TM_GetCitySql = result?.data.tM_GetCitySql;
			
			formVars.customerupdatepost_846303_options = stateVars.TM_GetCitySql;
			this.props.form?.setFieldsValue(formVars);
			
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.CustomerUpdatePostComponent_941270_onChange1_();
                  resolve();
                });
          })



        
        KuikaAppManager.hideSpinner(this);
        return isErrorOccurred;
    }
		CustomerUpdatePostComponent_941270_onChange1_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }

				
				stateVars.dataSource_846303 = stateVars.TM_GetCitySql ?? this.state.TM_GetCitySql;
				stateVars.dataSource_846303 = stateVars.TM_GetCitySql ?? this.state.TM_GetCitySql;

		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

            
            return isErrorOccurred;
        }




    CustomerUpdatePostComponent_846303_onChange = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;

			validations.push({ 
				isValid: ReactSystemFunctions.isNotEmpty(ReactSystemFunctions.value(this, "customerupdatepost_846303_value", "value", "TM_GetCitySql", "cityCode", ""), null),
				message: "Bu alan boş bırakılamaz !",
				formName: "customerupdatepost_846303_value",
				condition: true
			} as IValidationData);

validations.forEach((validation) => {
            if (validation.message === "Geçerli bir mail adresi giriniz.") {
                validation.message = ReactSystemFunctions.getEmailValidationMessage()
            }
        })

		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
		KuikaAppManager.increaseServerRequestCount();

        let localVar = {
				CityCode_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "customerupdatepost_846303_value", "value", "TM_GetCitySql", "cityCode", "cityCode")), "string")
        }

		KuikaAppManager.showSpinner(this);
		
        if (true) {
        KuikaAppManager.showSpinner(this);
        }
        let result = await KuikaAppManager.ApiRequest(this, "CustomerUpdatePost/CustomerUpdatePostComponent_846303_onChange", localVar)
        if (!KMainFunctions.IsResStatus2XX(result)) return true;

			stateVars.TM_GetDistrict = result?.data.tM_GetDistrict;
			
			formVars.customerupdatepost_469746_options = stateVars.TM_GetDistrict;
			this.props.form?.setFieldsValue(formVars);
			
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.CustomerUpdatePostComponent_846303_onChange1_();
                  resolve();
                });
          })



        
        KuikaAppManager.hideSpinner(this);
        return isErrorOccurred;
    }
		CustomerUpdatePostComponent_846303_onChange1_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }

				
				stateVars.dataSource_469746 = stateVars.TM_GetDistrict ?? this.state.TM_GetDistrict;
				stateVars.dataSource_469746 = stateVars.TM_GetDistrict ?? this.state.TM_GetDistrict;

		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

            
            return isErrorOccurred;
        }




		CustomerUpdatePostComponent_163827_onClick = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
KuikaAppManager.showSpinner(this);

				stateVars.GoBack = await ReactSystemFunctions.goBack(this, false);

		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

            
            return isErrorOccurred;
        }


    CustomerUpdatePostComponent_42731_onClick = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;

			validations.push({ 
				isValid: ReactSystemFunctions.isNotEmpty(ReactSystemFunctions.value(this, "customerupdatepost_627602_value", "value", "", "", ""), null),
				message: "Bu alan boş bırakılamaz !",
				formName: "customerupdatepost_627602_value",
				condition: true
			} as IValidationData);

validations.forEach((validation) => {
            if (validation.message === "Geçerli bir mail adresi giriniz.") {
                validation.message = ReactSystemFunctions.getEmailValidationMessage()
            }
        })
			validations.push({ 
				isValid: ReactSystemFunctions.isNotEmpty(ReactSystemFunctions.value(this, "customerupdatepost_965730_value", "value", "", "", ""), null),
				message: "Bu alan boş bırakılamaz!",
				formName: "customerupdatepost_965730_value",
				condition: true
			} as IValidationData);

validations.forEach((validation) => {
            if (validation.message === "Geçerli bir mail adresi giriniz.") {
                validation.message = ReactSystemFunctions.getEmailValidationMessage()
            }
        })
			validations.push({ 
				isValid: ReactSystemFunctions.isNotEmpty(ReactSystemFunctions.value(this, "customerupdatepost_856033_value", "value", "", "", ""), null),
				message: "Bu alan boş bırakılamaz !",
				formName: "customerupdatepost_856033_value",
				condition: true
			} as IValidationData);

validations.forEach((validation) => {
            if (validation.message === "Geçerli bir mail adresi giriniz.") {
                validation.message = ReactSystemFunctions.getEmailValidationMessage()
            }
        })
			validations.push({ 
				isValid: ReactSystemFunctions.isNotEmpty(ReactSystemFunctions.value(this, "customerupdatepost_196298_value", "value", "", "", ""), null),
				message: "Bu alan boş bırakılamaz !",
				formName: "customerupdatepost_196298_value",
				condition: true
			} as IValidationData);

validations.forEach((validation) => {
            if (validation.message === "Geçerli bir mail adresi giriniz.") {
                validation.message = ReactSystemFunctions.getEmailValidationMessage()
            }
        })
			validations.push({ 
				isValid: ReactSystemFunctions.isValidEmail(ReactSystemFunctions.value(this, "customerupdatepost_196298_value", "value", "", "", ""), null),
				message: "Geçerli bir mail adresi giriniz.",
				formName: "customerupdatepost_196298_value",
				condition: true
			} as IValidationData);

validations.forEach((validation) => {
            if (validation.message === "Geçerli bir mail adresi giriniz.") {
                validation.message = ReactSystemFunctions.getEmailValidationMessage()
            }
        })
			validations.push({ 
				isValid: ReactSystemFunctions.isNotEmpty(ReactSystemFunctions.value(this, "customerupdatepost_107316_value", "value", "", "", ""), null),
				message: "Gerçek kişiliklerde TC zorunludur. TC bilinmiyorsa 11111111111 girilebilir.",
				formName: "customerupdatepost_107316_value",
				condition: ReactSystemFunctions.isNotEqualTo(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "customerupdatepost_519157866_value", "value", "SirketTipi", "key", "key")), ReactSystemFunctions.convertToTypeByName("0", "string"))
			} as IValidationData);

validations.forEach((validation) => {
            if (validation.message === "Geçerli bir mail adresi giriniz.") {
                validation.message = ReactSystemFunctions.getEmailValidationMessage()
            }
        })
			validations.push({ 
				isValid: ReactSystemFunctions.isNotEmpty(ReactSystemFunctions.value(this, "customerupdatepost_586416_value", "value", "Kuika_CurrAccAttribute", "customerAtt02", ""), null),
				message: "Bu alan boş bırakılamaz !",
				formName: "customerupdatepost_586416_value",
				condition: true
			} as IValidationData);

validations.forEach((validation) => {
            if (validation.message === "Geçerli bir mail adresi giriniz.") {
                validation.message = ReactSystemFunctions.getEmailValidationMessage()
            }
        })
			validations.push({ 
				isValid: ReactSystemFunctions.isNotEmpty(ReactSystemFunctions.value(this, "customerupdatepost_846303_value", "value", "TM_GetCitySql", "cityCode", ""), null),
				message: "Bu alan boş bırakılamaz !",
				formName: "customerupdatepost_846303_value",
				condition: true
			} as IValidationData);

validations.forEach((validation) => {
            if (validation.message === "Geçerli bir mail adresi giriniz.") {
                validation.message = ReactSystemFunctions.getEmailValidationMessage()
            }
        })
			validations.push({ 
				isValid: ReactSystemFunctions.isNotEmpty(ReactSystemFunctions.value(this, "customerupdatepost_941270_value", "value", "TM_GetCountry", "countryCode", ""), null),
				message: "Bu alan boş bırakılamaz !",
				formName: "customerupdatepost_941270_value",
				condition: true
			} as IValidationData);

validations.forEach((validation) => {
            if (validation.message === "Geçerli bir mail adresi giriniz.") {
                validation.message = ReactSystemFunctions.getEmailValidationMessage()
            }
        })
			validations.push({ 
				isValid: ReactSystemFunctions.isNotEmpty(ReactSystemFunctions.value(this, "customerupdatepost_469746_value", "value", "TM_GetDistrict", "districtCode", ""), null),
				message: "Bu alan boş bırakılamaz !",
				formName: "customerupdatepost_469746_value",
				condition: true
			} as IValidationData);

validations.forEach((validation) => {
            if (validation.message === "Geçerli bir mail adresi giriniz.") {
                validation.message = ReactSystemFunctions.getEmailValidationMessage()
            }
        })
			validations.push({ 
				isValid: ReactSystemFunctions.isNotEmpty(ReactSystemFunctions.value(this, "customerupdatepost_941555_value", "value", "", "", ""), null),
				message: "Bu alan zorunludur!",
				formName: "customerupdatepost_941555_value",
				condition: true
			} as IValidationData);

validations.forEach((validation) => {
            if (validation.message === "Geçerli bir mail adresi giriniz.") {
                validation.message = ReactSystemFunctions.getEmailValidationMessage()
            }
        })

		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
		KuikaAppManager.increaseServerRequestCount();

        let localVar = {
				currAccCode_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, (stateVars.TM_GetCustomerUpdate !== undefined ? (stateVars.TM_GetCustomerUpdate?.length > 0 ? stateVars.TM_GetCustomerUpdate[0].currAccCode : null) : (this.state.TM_GetCustomerUpdate?.length > 0 ? this.state.TM_GetCustomerUpdate[0].currAccCode : null))), "string"),
				ad_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "customerupdatepost_627602_value", "value", "", "", "")), "string"),
				soyad_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "customerupdatepost_965730_value", "value", "", "", "")), "string"),
				telefon_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "customerupdatepost_856033_value", "value", "", "", "")), "string"),
				telId_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, (stateVars.TM_GetCustomerUpdate !== undefined ? (stateVars.TM_GetCustomerUpdate?.length > 0 ? stateVars.TM_GetCustomerUpdate[0].telID : null) : (this.state.TM_GetCustomerUpdate?.length > 0 ? this.state.TM_GetCustomerUpdate[0].telID : null))), "string"),
				email_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "customerupdatepost_196298_value", "value", "", "", "")), "string"),
				emailId_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, (stateVars.TM_GetCustomerUpdate !== undefined ? (stateVars.TM_GetCustomerUpdate?.length > 0 ? stateVars.TM_GetCustomerUpdate[0].emailID : null) : (this.state.TM_GetCustomerUpdate?.length > 0 ? this.state.TM_GetCustomerUpdate[0].emailID : null))), "string"),
				identityNo_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "customerupdatepost_107316_value", "value", "", "", "")), "string"),
				taxNumber_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "customerupdatepost_442968_value", "value", "", "", "")), "string"),
				taxOfficeCode_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "customerupdatepost_407342_value", "value", "GetTaxOffices", "taxOfficeCode", "taxOfficeCode")), "string"),
				isIndividual_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "customerupdatepost_519157866_value", "value", "SirketTipi", "key", "key")), "number"),
				attributeCode2_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "customerupdatepost_586416_value", "value", "Kuika_CurrAccAttribute", "customerAtt02", "customerAtt02")), "string"),
				attributeCode2Desc_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "customerupdatepost_586416_value", "value", "Kuika_CurrAccAttribute", "customerAtt02", "customerAtt02Desc")), "string"),
				address_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "customerupdatepost_697352_value", "value", "", "", "")), "string"),
				birthDate_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "customerupdatepost_174356_value", "value", "", "", "")), "Date"),
				cityCode_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "customerupdatepost_846303_value", "value", "TM_GetCitySql", "cityCode", "cityCode")), "string"),
				countryCode_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "customerupdatepost_941270_value", "value", "TM_GetCountry", "countryCode", "countryCode")), "string"),
				districtCode_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "customerupdatepost_469746_value", "value", "TM_GetDistrict", "districtCode", "districtCode")), "string"),
				postalAddressId_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, (stateVars.TM_GetCustomerUpdate !== undefined ? (stateVars.TM_GetCustomerUpdate?.length > 0 ? stateVars.TM_GetCustomerUpdate[0].postalAddressID : null) : (this.state.TM_GetCustomerUpdate?.length > 0 ? this.state.TM_GetCustomerUpdate[0].postalAddressID : null))), "string"),
				changedBy_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.getMyUserId(), "Guid"),
				info_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "customerupdatepost_941555_value", "value", "", "", "")), "string"),
				isSubjectToEInvoice_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toInteger(this, ReactSystemFunctions.value(this, "customerupdatepost_557630998_value", "value", "", "key", "")), "number")
        }

		KuikaAppManager.showSpinner(this);
		
        if (true) {
        KuikaAppManager.showSpinner(this);
        }
        let result = await KuikaAppManager.ApiRequest(this, "CustomerUpdatePost/CustomerUpdatePostComponent_42731_onClick", localVar)
        if (!KMainFunctions.IsResStatus2XX(result)) return true;

			stateVars.UpdateCustomer = result?.data.updateCustomer;
			this.props.form?.setFieldsValue(formVars);
			
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.CustomerUpdatePostComponent_42731_onClick1_();
                  resolve();
                });
          })



        
        KuikaAppManager.hideSpinner(this);
        return isErrorOccurred;
    }
		CustomerUpdatePostComponent_42731_onClick1_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }

				stateVars.Notify = await ReactSystemFunctions.notify(this, ReactSystemFunctions.toString(this, this.state.UpdateCustomer?.responseMessage), ReactSystemFunctions.convertToTypeByName("default", "string"), ReactSystemFunctions.convertToTypeByName("bottom-right", "string"), 4, ReactSystemFunctions.convertToTypeByName("", "string"), ReactSystemFunctions.convertToTypeByName("", "string"), 0);

		this.props.form?.setFieldsValue(formVars);
		
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.CustomerUpdatePostComponent_42731_onClick2_();
                  resolve();
                });
          })

            
            return isErrorOccurred;
        }
		CustomerUpdatePostComponent_42731_onClick2_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
if (ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, this.state.UpdateCustomer?.isSuccess), "1")) {
            
				stateVars.GoBack = await ReactSystemFunctions.goBack(this, false);

		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

        } else {
            KuikaAppManager.hideSpinner(this);
        }

            
            return isErrorOccurred;
        }







    async callCallbackFunction(diId: number, isFromMaster: boolean = false) {
        let isErrorOccurred = false;
		let pageInitCallerNavDiIDs = [] as number[];
		if (isFromMaster || pageInitCallerNavDiIDs.indexOf(diId) > -1) {
			await this.CustomerUpdatePostPageInit();
		}

    }


}
