import React from "react";
import Axios, { AxiosResponse } from "axios";
import { KuikaAppManager } from "../../shared/utilty/kuika-app-manager";
import { ReactSystemFunctions } from "../../shared/utilty/react-system-functions";
import { KNavigator } from "../../shared/hoc/with-history";
import { KContext } from "../../shared/hoc/with-context";
import { useLocation } from "react-router-dom";
import { FormInstance } from "antd/es/form";
import { Guid } from "guid-typescript";
import Swal from "sweetalert2";
import { KMainFunctions } from "../../shared/utilty/main-functions";
import moment from "moment";
import { IValidationData } from "../../models/dto/validation-data";
import { IStripePayment } from "../../models/dto/stripe-payment";
import { IUserInfoDto } from "../../models/dto/user-info.dto";
import { UserService } from "../../services/user-service";
import { kuikaCoreWasmBridgeService } from "../../services/_singletons";
import _ from "lodash";
import mqtt, { MqttClient } from "mqtt";
import { IMqttResult } from "../../models/dto/mqtt.dto";


declare let window: any;

export interface ITransferBildirimGonderimIzleme_ScreenProps {
  navigator: KNavigator;
  form: FormInstance<any>;
  googleLogin: any;
  screenInputs: any;
  context: KContext;
  initialValues: any;
  children: any;
}

export interface ITransferBildirimGonderimIzleme_ScreenState {
    isSpinnerVisible: boolean;
    isPageVisible: boolean;
	isLeftMenuVisible: boolean;
    spinnerCount: number;
    selectedLanguage: string;
    isPageInitLoaded: false;
    isPageRecurringLoaded: false;

}

export class TransferBildirimGonderimIzleme_ScreenBase extends React.PureComponent<ITransferBildirimGonderimIzleme_ScreenProps, any> {

	transferbildirimgonderimizleme_158650_value_kuikaAutoCompleteRef: React.RefObject<any>;
	transferbildirimgonderimizleme_947366_value_kuikaSelectBoxRef: React.RefObject<any>;
	transferbildirimgonderimizleme_739803_value_kuikaDateRef: React.RefObject<any>;
	transferbildirimgonderimizleme_473870_value_kuikaDateRef: React.RefObject<any>;
	transferbildirimgonderimizleme_268151_value_kuikaTableRef: React.RefObject<any>;
    ml=[{"Id":"d5a61d2b-bd60-485f-86e2-661e9ed4e486","Name":"en_US","ShortName":"English","IsDefault":true,"LanguagePhrases":[]},{"Id":"172789c5-4845-4a46-b730-871894492351","Name":"FixedValues","ShortName":"FixedValues","LanguagePhrases":[{"Id":246697,"PropertyName":"value","Value":"Bildirim Gönderim İzleme"},{"Id":509181,"PropertyName":"value","Value":"E-posta ve push bildirimlerinin gönderim durumlarını takip edin."},{"Id":236722,"PropertyName":"label","Value":"Yenile"},{"Id":915266,"PropertyName":"label","Value":"E-posta 8"},{"Id":939620,"PropertyName":"label","Value":"Push Bildirim 3"},{"Id":143344,"PropertyName":"value","Value":"Talep/Fiş No"},{"Id":173691,"PropertyName":"placeholder","Value":"Talep/Fiş No"},{"Id":936156,"PropertyName":"value","Value":"Olay Türü"},{"Id":158650,"PropertyName":"placeholder","Value":"Olay Türü"},{"Id":112740,"PropertyName":"value","Value":"Alıcı Kullanıcı"},{"Id":204887,"PropertyName":"placeholder","Value":"Alıcı Kullanıcı"},{"Id":712522,"PropertyName":"value","Value":"Alıcı Adresi"},{"Id":177740,"PropertyName":"placeholder","Value":"Alıcı Adresi"},{"Id":253183,"PropertyName":"value","Value":"Gönderim Durumu"},{"Id":947366,"PropertyName":"placeholder","Value":"Gönderim Durumu"},{"Id":503602,"PropertyName":"value","Value":"Deneme Sayısı"},{"Id":52634,"PropertyName":"placeholder","Value":"Deneme Sayısı"},{"Id":899582,"PropertyName":"value","Value":"Oluşturma Tarihi"},{"Id":739803,"PropertyName":"placeholder","Value":"Oluşturma Tarihi"},{"Id":689461,"PropertyName":"value","Value":"Gönderim Tarihi"},{"Id":473870,"PropertyName":"placeholder","Value":"Gönderim Tarihi"},{"Id":782403,"PropertyName":"label","Value":"Ara"},{"Id":695493,"PropertyName":"label","Value":"Temizle"},{"Id":725848,"PropertyName":"title","Value":"Talep/Fiş No"},{"Id":514209,"PropertyName":"value","Value":"TRF-2024-0017"},{"Id":159565,"PropertyName":"title","Value":"Olay Türü"},{"Id":661867,"PropertyName":"value","Value":"E-posta Bildirimi"},{"Id":404691,"PropertyName":"title","Value":"Alıcı"},{"Id":763125,"PropertyName":"value","Value":"Ayşe Yılmaz"},{"Id":573081,"PropertyName":"title","Value":"E-posta Adresi"},{"Id":402446,"PropertyName":"value","Value":"ayse.yilmaz@example.com"},{"Id":456211,"PropertyName":"title","Value":"Durum"},{"Id":357915,"PropertyName":"value","Value":"Gönderildi"},{"Id":487867,"PropertyName":"value","Value":"Kritik"},{"Id":707456,"PropertyName":"title","Value":"Deneme Sayısı"},{"Id":651148,"PropertyName":"value","Value":"3"},{"Id":38951,"PropertyName":"title","Value":"Son Hata"},{"Id":973230,"PropertyName":"value","Value":"SMTP sunucusuna ulaşılamadı"},{"Id":662543,"PropertyName":"title","Value":"Oluşturma Tarihi"},{"Id":224882,"PropertyName":"value","Value":"12.06.2024 09:14"},{"Id":334481,"PropertyName":"title","Value":"Gönderim Tarihi"},{"Id":766941,"PropertyName":"value","Value":"12.06.2024 09:16"},{"Id":497337,"PropertyName":"title","Value":"Ek"},{"Id":328424,"PropertyName":"value","Value":"PDF Eklendi"},{"Id":558444,"PropertyName":"title","Value":"İşlemler"},{"Id":525803,"PropertyName":"label","Value":"Detay"},{"Id":955630,"PropertyName":"label","Value":"Tekrar Gönder"},{"Id":82145,"PropertyName":"value","Value":"Toplam 8 kayıt"},{"Id":614199,"PropertyName":"label","Value":"Önceki"},{"Id":866643,"PropertyName":"label","Value":"1"},{"Id":260643,"PropertyName":"label","Value":"2"},{"Id":756434,"PropertyName":"label","Value":"3"},{"Id":679111,"PropertyName":"label","Value":"Sonraki"},{"Id":897807,"PropertyName":"value","Value":"25 / sayfa"}]}]
    defaultML = "en_US"
    
    screenHash = ""
    


    constructor(props) {
        super(props);
		this.transferbildirimgonderimizleme_173691_value_kuikaTextInputRef = React.createRef();
		this.transferbildirimgonderimizleme_158650_value_kuikaAutoCompleteRef = React.createRef();
		this.transferbildirimgonderimizleme_204887_value_kuikaTextInputRef = React.createRef();
		this.transferbildirimgonderimizleme_177740_value_kuikaTextInputRef = React.createRef();
		this.transferbildirimgonderimizleme_947366_value_kuikaSelectBoxRef = React.createRef();
		this.transferbildirimgonderimizleme_739803_value_kuikaDateRef = React.createRef();
		this.transferbildirimgonderimizleme_473870_value_kuikaDateRef = React.createRef();
		this.transferbildirimgonderimizleme_268151_value_kuikaTableRef = React.createRef();

        this.state = {
            isSpinnerVisible: false,
            isPageVisible: false,
            isLeftMenuVisible: false,
            spinnerCount: 0,
            selectedLanguage: "",
            isPageInitLoaded: false,
            isPageRecurringLoaded: false,
            	        dataSource_158650: [{"key":"email","text":"E-posta"},{"key":"push","text":"Push Bildirim"},{"key":"sistem","text":"Sistem Uyarısı"}],
	        dataSource_947366: [{"key":"pending","text":"Bekliyor"},{"key":"sending","text":"Gönderiliyor"},{"key":"sent","text":"Gönderildi"},{"key":"failed","text":"Hatalı"}],

        }

        this.state.isPageVisible = true;
        
    }

    async componentDidMount() {

        if (KuikaAppManager.isPageInitPrevented()) {
            KuikaAppManager.calculateAndSetBodyHeight("transferbildirimgonderimizleme", "");
            return;
        }
        
        
        ReactSystemFunctions.validateToken()
        this.fillFormInitValues();
        if (true){
            
        }
        
        
        
        KuikaAppManager.calculateAndSetBodyHeight("transferbildirimgonderimizleme", "");

        if (ReactSystemFunctions.getIsMicroApp() === false) {
           window.parentScreen = this;
        }
    }

    componentWillUnmount() {
        
        
        

        if (ReactSystemFunctions.getIsMicroApp() === false) {
           window.parentScreen = null;
        }
    }

    

        
    componentDidUpdate= async (prevProps, prevState) => {
		KuikaAppManager.calculateAndSetBodyHeight("transferbildirimgonderimizleme", ""    );
        if (prevProps?.location?.search !== (this.props as any)?.location?.search) {
			
		}

        

        if (ReactSystemFunctions.getIsMicroApp() === false) {
            for (const key in prevState) {
                if (key.startsWith('NavVisible') && prevState[key] === true && this.state[key] === false) {
                    window.parentScreen = this;
                    break;
                }
            }
        }
	}

    fillFormInitValues() {
        this.props.form?.setFieldsValue({
transferbildirimgonderimizleme_948184_value: false,
transferbildirimgonderimizleme_52634_value: undefined
});

    }

      setPageInitLoaded = (value: boolean) => {
        this.setState({ isPageInitLoaded: value });
      }

      setPageRecurringLoaded = (value: boolean) => {
        this.setState({ isPageRecurringLoaded: value });
      }

      clearFieldValidation = (changedValues: any) => {
        const fieldName = Object.keys(changedValues)[0];
        if (fieldName) {
          this.props.form?.setFields([
            {
              name: fieldName,
              errors: []
            }
          ]);
        }
      };

      




    async callCallbackFunction(diId: number, isFromMaster: boolean = false) {
        let isErrorOccurred = false;

    }


}
