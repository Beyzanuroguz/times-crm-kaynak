import React from "react";
import Axios, { AxiosResponse } from "axios";
import { KuikaAppManager } from "../../shared/utilty/kuika-app-manager";
import { ReactSystemFunctions } from "../../shared/utilty/react-system-functions";
import { KNavigator } from "../../shared/hoc/with-history";
import { KContext } from "../../shared/hoc/with-context";
import { useLocation } from "react-router-dom";
import { FormInstance } from "antd/es/form";
import { Guid } from "guid-typescript";
import Swal from "sweetalert2";
import { KMainFunctions } from "../../shared/utilty/main-functions";
import moment from "moment";
import { IValidationData } from "../../models/dto/validation-data";
import { IStripePayment } from "../../models/dto/stripe-payment";
import { IUserInfoDto } from "../../models/dto/user-info.dto";
import { UserService } from "../../services/user-service";
import { kuikaCoreWasmBridgeService } from "../../services/_singletons";
import _ from "lodash";
import mqtt, { MqttClient } from "mqtt";
import { IMqttResult } from "../../models/dto/mqtt.dto";
import { MasterScreen_ScreenContext } from "../masterscreen/masterscreen-context";

declare let window: any;

export interface IRolexFamilyReporting_ScreenProps {
  navigator: KNavigator;
  form: FormInstance<any>;
  googleLogin: any;
  screenInputs: any;
  context: KContext;
  initialValues: any;
  children: any;
}

export interface IRolexFamilyReporting_ScreenState {
    isSpinnerVisible: boolean;
    isPageVisible: boolean;
	isLeftMenuVisible: boolean;
    spinnerCount: number;
    selectedLanguage: string;
    isPageInitLoaded: false;
    isPageRecurringLoaded: false;
	KuikaY_RolexTudorFamilyStoreSalesMatrix: any[];
	KuikaY_RolexTudorFamilyStoreSalesMatrix_dummy: any[];
	KuikaY_GetFamilyByBrandProductGroup: any[];
	KuikaY_GetFamilyByBrandProductGroup_dummy: any[];
	NAVIGATE: any;
	NAVIGATE_dummy: any;
	ExportExcel: any;
	ExportExcel_dummy: any;
	KuikaY_RolexTudorFamilyStoreSalesMatrixMonthly: any[];
	KuikaY_RolexTudorFamilyStoreSalesMatrixMonthly_dummy: any[];
	ChangeVisibilityOf: string;
	ChangeVisibilityOf_dummy: string;
	isComp305499Visible: 'visible' | 'hidden';
	isComp167279Visible: 'visible' | 'hidden';
	isComp603305Visible: 'visible' | 'hidden';
	isComp380Visible: 'visible' | 'hidden';

}

export class RolexFamilyReporting_ScreenBase extends React.PureComponent<IRolexFamilyReporting_ScreenProps, any> {
    static contextType = MasterScreen_ScreenContext;
    declare context: React.ContextType<typeof MasterScreen_ScreenContext>;
	rolexfamilyreporting_770123_value_kuikaAutoCompleteRef: React.RefObject<any>;
	rolexfamilyreporting_2183_value_kuikaTableRef: React.RefObject<any>;
	rolexfamilyreporting_911338_value_kuikaAutoCompleteRef: React.RefObject<any>;
	rolexfamilyreporting_103699_value_kuikaAutoCompleteRef: React.RefObject<any>;
	rolexfamilyreporting_430546_value_kuikaTableRef: React.RefObject<any>;
    ml=[{"Id":"d5a61d2b-bd60-485f-86e2-661e9ed4e486","Name":"en_US","ShortName":"English","IsDefault":true,"LanguagePhrases":[]},{"Id":"31a95e54-74a1-421a-81ee-aebb6105730f","Name":"FixedValues","ShortName":"FixedValues","LanguagePhrases":[{"Id":910240,"PropertyName":"value","Value":"Marka Bazlı Raporlama"},{"Id":869891,"PropertyName":"value","Value":"Mağaza satış performanslarını karşılaştırmalı olarak analiz edin."},{"Id":808770,"PropertyName":"label","Value":"Rolex"},{"Id":265439,"PropertyName":"label","Value":"Tudor"},{"Id":41756,"PropertyName":"label","Value":"Mont Blanc"},{"Id":691365,"PropertyName":"label","Value":"Dupont"},{"Id":126713,"PropertyName":"value","Value":"Analiz Tipi"},{"Id":248363,"PropertyName":"value","Value":"Genel Satış"},{"Id":640909,"PropertyName":"value","Value":"Family Bazlı"},{"Id":774535,"PropertyName":"value","Value":"Material Bazlı"},{"Id":359129,"PropertyName":"value","Value":"Diameter Bazlı"},{"Id":384797,"PropertyName":"value","Value":"Ürün Grubu Bazlı"},{"Id":761907,"PropertyName":"value","Value":"Toplam Satış Adedi"},{"Id":526193,"PropertyName":"value","Value":"1,247"},{"Id":314567,"PropertyName":"value","Value":"+18.5%"},{"Id":604619,"PropertyName":"value","Value":"-18.5%"},{"Id":100879,"PropertyName":"value","Value":"Toplam Ciro"},{"Id":333171,"PropertyName":"value","Value":"₺42.5M"},{"Id":970632,"PropertyName":"value","Value":"+18.5%"},{"Id":240423,"PropertyName":"value","Value":"-18.5%"},{"Id":590055,"PropertyName":"value","Value":"Geçen Yıla Göre Artış"},{"Id":536252,"PropertyName":"value","Value":"+32.8%"},{"Id":223482,"PropertyName":"value","Value":"Yıllık Büyüme"},{"Id":149372,"PropertyName":"value","Value":"En Güçlü Mağaza"},{"Id":102679,"PropertyName":"value","Value":"Adana"},{"Id":53190,"PropertyName":"value","Value":"₺8.2M Ciro"},{"Id":175225,"PropertyName":"value","Value":"En Çok Satan Family"},{"Id":716024,"PropertyName":"value","Value":"Submariner"},{"Id":936850,"PropertyName":"value","Value":"342 Adet"},{"Id":383957,"PropertyName":"value","Value":"En Çok Satan Material"},{"Id":241482,"PropertyName":"value","Value":"Yellow Gold"},{"Id":792428,"PropertyName":"value","Value":"₺12.4M Ciro"},{"Id":94524,"PropertyName":"value","Value":"Rolex-"},{"Id":689955,"PropertyName":"value","Value":"-Family Bazlı Yıllık Satış Görünüm"},{"Id":751356,"PropertyName":"placeholder","Value":"Select Year..."},{"Id":770123,"PropertyName":"placeholder","Value":"Tümü"},{"Id":833116,"PropertyName":"title","Value":"Family"},{"Id":998996,"PropertyName":"value","Value":"[datafield:family]"},{"Id":879664,"PropertyName":"title","Value":"Adana Times"},{"Id":774024,"PropertyName":"value","Value":"[datafield:adana]"},{"Id":151581,"PropertyName":"title","Value":"Antalya Rolex Boutique Times"},{"Id":312873,"PropertyName":"value","Value":"[datafield:antalya]"},{"Id":479854,"PropertyName":"title","Value":"Gaziantep Times"},{"Id":14947,"PropertyName":"value","Value":"[datafield:gaziantep]"},{"Id":792609,"PropertyName":"title","Value":"Mersin Rolex Boutique"},{"Id":953473,"PropertyName":"value","Value":"[datafield:mersinmağaza]"},{"Id":776948,"PropertyName":"title","Value":"Toplam"},{"Id":54451,"PropertyName":"value","Value":"[datafield:toplam]"},{"Id":922479,"PropertyName":"value","Value":"Rolex-"},{"Id":143601,"PropertyName":"value","Value":"-"},{"Id":321630,"PropertyName":"value","Value":".Ay"},{"Id":619922,"PropertyName":"value","Value":"-Family Bazlı Yıllık Satış Görünüm"},{"Id":616916,"PropertyName":"value","Value":"Yıl"},{"Id":521202,"PropertyName":"placeholder","Value":"Select Year..."},{"Id":134946,"PropertyName":"value","Value":"Ay"},{"Id":911338,"PropertyName":"placeholder","Value":"Ay"},{"Id":71755,"PropertyName":"value","Value":"Family"},{"Id":103699,"PropertyName":"placeholder","Value":"Tümü"},{"Id":702983,"PropertyName":"label","Value":"Çalıştır"},{"Id":890597,"PropertyName":"title","Value":"Family"},{"Id":913155,"PropertyName":"value","Value":"[datafield:family]"},{"Id":338272,"PropertyName":"title","Value":"Adana Times"},{"Id":37483,"PropertyName":"value","Value":"[datafield:adana]"},{"Id":807912,"PropertyName":"title","Value":"Antalya Rolex Boutique"},{"Id":866502,"PropertyName":"value","Value":"[datafield:antalya]"},{"Id":536844,"PropertyName":"title","Value":"Gaziantep Times"},{"Id":958276,"PropertyName":"value","Value":"[datafield:gaziantep]"},{"Id":552292,"PropertyName":"title","Value":"Mersin Rolex Boutique"},{"Id":439832,"PropertyName":"value","Value":"[datafield:mersinmagaza]"},{"Id":609535,"PropertyName":"title","Value":"Toplam"},{"Id":911365,"PropertyName":"value","Value":"[datafield:toplam]"},{"Id":627712,"PropertyName":"value","Value":"Aylık Family Bazlı Satış Raporlarını Görmek için Raporu Çalıştırınız."}]}]
    defaultML = "en_US"
    
    screenHash = ""
    

    private _prevMasterPageInitLoaded: boolean = false;
    private _prevMasterPageRecurringLoaded: boolean = false;
    private _prevShouldTriggerPageInit: boolean = false;
    constructor(props) {
        super(props);
		this.rolexfamilyreporting_770123_value_kuikaAutoCompleteRef = React.createRef();
		this.rolexfamilyreporting_2183_value_kuikaTableRef = React.createRef();
		this.rolexfamilyreporting_911338_value_kuikaAutoCompleteRef = React.createRef();
		this.rolexfamilyreporting_103699_value_kuikaAutoCompleteRef = React.createRef();
		this.rolexfamilyreporting_430546_value_kuikaTableRef = React.createRef();

        this.state = {
            isSpinnerVisible: false,
            isPageVisible: false,
            isLeftMenuVisible: false,
            spinnerCount: 0,
            selectedLanguage: "",
            isPageInitLoaded: false,
            isPageRecurringLoaded: false,
            	        KuikaY_RolexTudorFamilyStoreSalesMatrix: [],
	        KuikaY_GetFamilyByBrandProductGroup: [],
	        NAVIGATE: "",
	        ExportExcel: "",
	        KuikaY_RolexTudorFamilyStoreSalesMatrixMonthly: [],
	        ChangeVisibilityOf: "",
	        dataSource_911338: [{"key":"1","text":"Ocak"},{"key":"2","text":"Şubat"},{"key":"3","text":"Mart"},{"key":"4","text":"Nisan"},{"key":"5","text":"Mayıs"},{"key":"6","text":"Haziran"},{"key":"7","text":"Temmuz"},{"key":"8","text":"Ağustos"},{"key":"9","text":"Eylül"},{"key":"10","text":"Ekim"},{"key":"11","text":"Kasım"},{"key":"12","text":"Aralık"}],
	        isComp305499Visible: 'hidden',
	        isComp167279Visible: 'hidden',
	        isComp603305Visible: 'hidden',
	        isComp380Visible: 'hidden',

        }

        this.state.isPageVisible = true;
        
    }

    async componentDidMount() {

        if (KuikaAppManager.isPageInitPrevented()) {
            KuikaAppManager.calculateAndSetBodyHeight("rolexfamilyreporting", "masterscreen_screen");
            return;
        }
        this.context.registerCallbackFunction(this.callCallbackFunction.bind(this));
        
        ReactSystemFunctions.validateToken()
        this.fillFormInitValues();
        if (false){
            await this.RolexFamilyReportingPageInit();
        } else if (this.context?.isMasterPageInitLoaded) { this._prevMasterPageInitLoaded = true; await this.RolexFamilyReportingPageInit(); }
        
        
        
        KuikaAppManager.calculateAndSetBodyHeight("rolexfamilyreporting", "masterscreen_screen");

        if (ReactSystemFunctions.getIsMicroApp() === false) {
           window.parentScreen = this;
        }
    }

    componentWillUnmount() {
        
        
        

        if (ReactSystemFunctions.getIsMicroApp() === false) {
           window.parentScreen = null;
        }
    }

    

        
    componentDidUpdate= async (prevProps, prevState) => {
		KuikaAppManager.calculateAndSetBodyHeight("rolexfamilyreporting", "masterscreen_screen"    );
        if (prevProps?.location?.search !== (this.props as any)?.location?.search) {
			await this.RolexFamilyReportingPageInit();
		}

        		if (this._prevMasterPageInitLoaded !== this.context.isMasterPageInitLoaded && this.context.isMasterPageInitLoaded === true) {this._prevMasterPageInitLoaded = this.context.isMasterPageInitLoaded;await this.RolexFamilyReportingPageInit()}


        if (ReactSystemFunctions.getIsMicroApp() === false) {
            for (const key in prevState) {
                if (key.startsWith('NavVisible') && prevState[key] === true && this.state[key] === false) {
                    window.parentScreen = this;
                    break;
                }
            }
        }
	}

    fillFormInitValues() {
        this.props.form?.setFieldsValue({
rolexfamilyreporting_751356_value: 2026,
rolexfamilyreporting_521202_value: 2026
});

    }

      setPageInitLoaded = (value: boolean) => {
        this.setState({ isPageInitLoaded: value });
      }

      setPageRecurringLoaded = (value: boolean) => {
        this.setState({ isPageRecurringLoaded: value });
      }

      clearFieldValidation = (changedValues: any) => {
        const fieldName = Object.keys(changedValues)[0];
        if (fieldName) {
          this.props.form?.setFields([
            {
              name: fieldName,
              errors: []
            }
          ]);
        }
      };

      

    RolexFamilyReportingPageInit = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


	if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }

        let localVar = {
			Brand_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.convertToTypeByName("Rolex", "string"), "string"),
			ProductGroup_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.convertToTypeByName("Kol saati", "string"), "string"),
			Family_0: ReactSystemFunctions.convertToTypeByName("", "string"),
			Year_0: ReactSystemFunctions.convertToTypeByName(2026, "number"),
			Marka_1: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.convertToTypeByName("Rolex", "string"), "string"),
			UrunGrubu_1: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.convertToTypeByName("Kol Saati", "string"), "string")
        }

	KuikaAppManager.showSpinner(this);
	
        if (true) {
        KuikaAppManager.showSpinner(this);
        }
        let result = await KuikaAppManager.ApiRequest(this, "RolexFamilyReporting/RolexFamilyReportingPageInit", localVar)
        if (!KMainFunctions.IsResStatus2XX(result)) return true;

		stateVars.KuikaY_RolexTudorFamilyStoreSalesMatrix = result?.data.kuikaY_RolexTudorFamilyStoreSalesMatrix;
		
		stateVars.KuikaY_GetFamilyByBrandProductGroup = result?.data.kuikaY_GetFamilyByBrandProductGroup;
		
		formVars.rolexfamilyreporting_770123_options = stateVars.KuikaY_GetFamilyByBrandProductGroup;
		
		formVars.rolexfamilyreporting_103699_options = stateVars.KuikaY_GetFamilyByBrandProductGroup;
		this.props.form?.setFieldsValue(formVars);
		
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.RolexFamilyReportingPageInit1_();
                  resolve();
                });
          })



        
        KuikaAppManager.hideSpinner(this);
        return isErrorOccurred;
    }
	RolexFamilyReportingPageInit1_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


	if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }

			ReactSystemFunctions.setValueOf(this, "rolexfamilyreporting_479237_toString", ReactSystemFunctions.value(this, "rolexfamilyreporting_751356_value", "value"), "value");

			
			stateVars.dataSource_770123 = stateVars.KuikaY_GetFamilyByBrandProductGroup ?? this.state.KuikaY_GetFamilyByBrandProductGroup;
			stateVars.dataSource_770123 = stateVars.KuikaY_GetFamilyByBrandProductGroup ?? this.state.KuikaY_GetFamilyByBrandProductGroup;
			
			stateVars.dataSource_2183 = stateVars.KuikaY_RolexTudorFamilyStoreSalesMatrix ?? this.state.KuikaY_RolexTudorFamilyStoreSalesMatrix;
			ReactSystemFunctions.setValueOf(this, "rolexfamilyreporting_246050_toString", ReactSystemFunctions.value(this, "rolexfamilyreporting_521202_value", "value"), "value");

			ReactSystemFunctions.setValueOf(this, "rolexfamilyreporting_108101_value", ReactSystemFunctions.value(this, "rolexfamilyreporting_911338_value", "value"), "value");

			
			stateVars.dataSource_103699 = stateVars.KuikaY_GetFamilyByBrandProductGroup ?? this.state.KuikaY_GetFamilyByBrandProductGroup;
			stateVars.dataSource_103699 = stateVars.KuikaY_GetFamilyByBrandProductGroup ?? this.state.KuikaY_GetFamilyByBrandProductGroup;
			stateVars.isComp380Visible = ((ReactSystemFunctions.isEmpty(ReactSystemFunctions.value(this, (stateVars.KuikaY_RolexTudorFamilyStoreSalesMatrixMonthly !== undefined ? (stateVars.KuikaY_RolexTudorFamilyStoreSalesMatrixMonthly?.length > 0 ? stateVars.KuikaY_RolexTudorFamilyStoreSalesMatrixMonthly[0].toplam : null) : (this.state.KuikaY_RolexTudorFamilyStoreSalesMatrixMonthly?.length > 0 ? this.state.KuikaY_RolexTudorFamilyStoreSalesMatrixMonthly[0].toplam : null))), ReactSystemFunctions.convertToTypeByName("True", "string"))) === true ? "visible" : "hidden")

	this.props.form?.setFieldsValue(formVars);
	this.setState(stateVars);
	KuikaAppManager.hideSpinner(this);

            this.setPageInitLoaded(true);
            return isErrorOccurred;
        }




		RolexFamilyReportingComponent_265439_onClick = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
KuikaAppManager.showSpinner(this);

const __currentPath = (window.location.hash ? window.location.hash.replace(/^#/, '').split('?')[0] : window.location.pathname.split('?')[0]).toLowerCase();
if (__currentPath !== "/tudorbasedreporting") {
  this.context.setMasterPageInitLoaded(false);
  this.context.setMasterPageRecurringLoaded(false);
  this.context.setShouldTriggerPageInit(true);
}
					KuikaAppManager.prepareForNavigation();

				stateVars.NAVIGATE = await ReactSystemFunctions.navigate(this, undefined, "RolexFamilyReporting", "TudorBasedReporting", "", "currentPage", null, null, null, null, null, null, true, false);

		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

            
            return isErrorOccurred;
        }


		RolexFamilyReportingComponent_41756_onClick = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
KuikaAppManager.showSpinner(this);

const __currentPath = (window.location.hash ? window.location.hash.replace(/^#/, '').split('?')[0] : window.location.pathname.split('?')[0]).toLowerCase();
if (__currentPath !== "/montblancbasedreporting") {
  this.context.setMasterPageInitLoaded(false);
  this.context.setMasterPageRecurringLoaded(false);
  this.context.setShouldTriggerPageInit(true);
}
					KuikaAppManager.prepareForNavigation();

				stateVars.NAVIGATE = await ReactSystemFunctions.navigate(this, undefined, "RolexFamilyReporting", "MontBlancBasedReporting", "", "currentPage", null, null, null, null, null, null, true, false);

		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

            
            return isErrorOccurred;
        }


		RolexFamilyReportingComponent_691365_onClick = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
KuikaAppManager.showSpinner(this);

const __currentPath = (window.location.hash ? window.location.hash.replace(/^#/, '').split('?')[0] : window.location.pathname.split('?')[0]).toLowerCase();
if (__currentPath !== "/dupontbasedreporting") {
  this.context.setMasterPageInitLoaded(false);
  this.context.setMasterPageRecurringLoaded(false);
  this.context.setShouldTriggerPageInit(true);
}
					KuikaAppManager.prepareForNavigation();

				stateVars.NAVIGATE = await ReactSystemFunctions.navigate(this, undefined, "RolexFamilyReporting", "DupontBasedReporting", "", "currentPage", null, null, null, null, null, null, true, false);

		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

            
            return isErrorOccurred;
        }


		RolexFamilyReportingComponent_377465_onClick = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
KuikaAppManager.showSpinner(this);

const __currentPath = (window.location.hash ? window.location.hash.replace(/^#/, '').split('?')[0] : window.location.pathname.split('?')[0]).toLowerCase();
if (__currentPath !== "/rolexbasedreporting") {
  this.context.setMasterPageInitLoaded(false);
  this.context.setMasterPageRecurringLoaded(false);
  this.context.setShouldTriggerPageInit(true);
}
					KuikaAppManager.prepareForNavigation();

				stateVars.NAVIGATE = await ReactSystemFunctions.navigate(this, undefined, "RolexFamilyReporting", "RolexBasedReporting", "", "currentPage", null, null, null, null, null, null, true, false);

		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

            
            return isErrorOccurred;
        }


		RolexFamilyReportingComponent_727992_onClick = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
KuikaAppManager.showSpinner(this);

const __currentPath = (window.location.hash ? window.location.hash.replace(/^#/, '').split('?')[0] : window.location.pathname.split('?')[0]).toLowerCase();
if (__currentPath !== "/rolexmaterialreporting") {
  this.context.setMasterPageInitLoaded(false);
  this.context.setMasterPageRecurringLoaded(false);
  this.context.setShouldTriggerPageInit(true);
}
					KuikaAppManager.prepareForNavigation();

				stateVars.NAVIGATE = await ReactSystemFunctions.navigate(this, undefined, "RolexFamilyReporting", "RolexMaterialReporting", "", "currentPage", null, null, null, null, null, null, true, false);

		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

            
            return isErrorOccurred;
        }


		RolexFamilyReportingComponent_885746_onClick = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
KuikaAppManager.showSpinner(this);

const __currentPath = (window.location.hash ? window.location.hash.replace(/^#/, '').split('?')[0] : window.location.pathname.split('?')[0]).toLowerCase();
if (__currentPath !== "/rolexdiameterreporting") {
  this.context.setMasterPageInitLoaded(false);
  this.context.setMasterPageRecurringLoaded(false);
  this.context.setShouldTriggerPageInit(true);
}
					KuikaAppManager.prepareForNavigation();

				stateVars.NAVIGATE = await ReactSystemFunctions.navigate(this, undefined, "RolexFamilyReporting", "RolexDiameterReporting", "", "currentPage", null, null, null, null, null, null, true, false);

		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

            
            return isErrorOccurred;
        }


		RolexFamilyReportingComponent_206592_onClick = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
KuikaAppManager.showSpinner(this);

const __currentPath = (window.location.hash ? window.location.hash.replace(/^#/, '').split('?')[0] : window.location.pathname.split('?')[0]).toLowerCase();
if (__currentPath !== "/rolexotherproductreporting") {
  this.context.setMasterPageInitLoaded(false);
  this.context.setMasterPageRecurringLoaded(false);
  this.context.setShouldTriggerPageInit(true);
}
					KuikaAppManager.prepareForNavigation();

				stateVars.NAVIGATE = await ReactSystemFunctions.navigate(this, undefined, "RolexFamilyReporting", "RolexOtherProductReporting", "", "currentPage", null, null, null, null, null, null, true, false);

		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

            
            return isErrorOccurred;
        }


		RolexFamilyReportingComponent_751356_onChange = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
KuikaAppManager.showSpinner(this);

				ReactSystemFunctions.setValueOf(this, "rolexfamilyreporting_479237_toString", ReactSystemFunctions.value(this, "rolexfamilyreporting_751356_value", "value"), "value");


		this.props.form?.setFieldsValue(formVars);
		
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.RolexFamilyReportingComponent_751356_onChange1_();
                  resolve();
                });
          })

            
            return isErrorOccurred;
        }
    RolexFamilyReportingComponent_751356_onChange1_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
		KuikaAppManager.increaseServerRequestCount();

        let localVar = {
				Brand_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.convertToTypeByName("Rolex", "string"), "string"),
				ProductGroup_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.convertToTypeByName("Kol saati", "string"), "string"),
				Family_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "rolexfamilyreporting_770123_value", "value", "KuikaY_GetFamilyByBrandProductGroup", "familyCode", "code")), "string"),
				Year_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "rolexfamilyreporting_751356_value", "value", "", "", "")), "number")
        }

		
        if (true) {
        KuikaAppManager.showSpinner(this);
        }
        let result = await KuikaAppManager.ApiRequest(this, "RolexFamilyReporting/RolexFamilyReportingComponent_751356_onChange1_", localVar)
        if (!KMainFunctions.IsResStatus2XX(result)) return true;

			stateVars.KuikaY_RolexTudorFamilyStoreSalesMatrix = result?.data.kuikaY_RolexTudorFamilyStoreSalesMatrix;
			
			this.props.form?.setFieldsValue(formVars);
			
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.RolexFamilyReportingComponent_751356_onChange2_();
                  resolve();
                });
          })



        
        KuikaAppManager.hideSpinner(this);
        return isErrorOccurred;
    }
		RolexFamilyReportingComponent_751356_onChange2_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }

				
				stateVars.dataSource_2183 = stateVars.KuikaY_RolexTudorFamilyStoreSalesMatrix ?? this.state.KuikaY_RolexTudorFamilyStoreSalesMatrix;

		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

            
            return isErrorOccurred;
        }





    RolexFamilyReportingComponent_770123_onChange = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
		KuikaAppManager.increaseServerRequestCount();

        let localVar = {
				Brand_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.convertToTypeByName("Rolex", "string"), "string"),
				ProductGroup_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.convertToTypeByName("Kol saati", "string"), "string"),
				Family_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "rolexfamilyreporting_770123_value", "value", "KuikaY_GetFamilyByBrandProductGroup", "familyCode", "code")), "string"),
				Year_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "rolexfamilyreporting_751356_value", "value", "", "", "")), "number")
        }

		KuikaAppManager.showSpinner(this);
		
        if (true) {
        KuikaAppManager.showSpinner(this);
        }
        let result = await KuikaAppManager.ApiRequest(this, "RolexFamilyReporting/RolexFamilyReportingComponent_770123_onChange", localVar)
        if (!KMainFunctions.IsResStatus2XX(result)) return true;

			stateVars.KuikaY_RolexTudorFamilyStoreSalesMatrix = result?.data.kuikaY_RolexTudorFamilyStoreSalesMatrix;
			
			this.props.form?.setFieldsValue(formVars);
			
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.RolexFamilyReportingComponent_770123_onChange1_();
                  resolve();
                });
          })



        
        KuikaAppManager.hideSpinner(this);
        return isErrorOccurred;
    }
		RolexFamilyReportingComponent_770123_onChange1_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }

				
				stateVars.dataSource_2183 = stateVars.KuikaY_RolexTudorFamilyStoreSalesMatrix ?? this.state.KuikaY_RolexTudorFamilyStoreSalesMatrix;

		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

            
            return isErrorOccurred;
        }




    RolexFamilyReportingComponent_52805_onClick = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
		KuikaAppManager.increaseServerRequestCount();

        let localVar = {
				value_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, this.state.KuikaY_RolexTudorFamilyStoreSalesMatrix), "any"),
				header_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.convertToTypeByName("Rolex Family Bazlı Yıllık Satış Raporu", "string"), "string"),
				footer_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "rolexfamilyreporting_751356_value", "value", "", "", "")), "string"),
				columns_0: ReactSystemFunctions.convertToTypeByName("", "string")
        }

		KuikaAppManager.showSpinner(this);
		
        if (true) {
        KuikaAppManager.showSpinner(this);
        }
        let result = await KuikaAppManager.ApiRequest(this, "RolexFamilyReporting/RolexFamilyReportingComponent_52805_onClick", localVar)
        if (!KMainFunctions.IsResStatus2XX(result)) return true;

			stateVars.ExportExcel = result?.data.exportExcel;
			ReactSystemFunctions.downloadFile(result?.data?.exportExcel);
			this.props.form?.setFieldsValue(formVars);
			this.setState(stateVars);
			KuikaAppManager.hideSpinner(this);



        this.setPageInitLoaded(true);
        KuikaAppManager.hideSpinner(this);
        return isErrorOccurred;
    }



    RolexFamilyReportingComponent_490041_onClick = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
		KuikaAppManager.increaseServerRequestCount();

        let localVar = {
				value_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, this.state.KuikaY_RolexTudorFamilyStoreSalesMatrixMonthly), "any"),
				header_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.convertToTypeByName("Rolex Family Bazlı Yıllık-Aylık Satış Raporu", "string"), "string"),
				footer_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "rolexfamilyreporting_751356_value", "value", "", "", "")), "string"),
				columns_0: ReactSystemFunctions.convertToTypeByName("", "string")
        }

		KuikaAppManager.showSpinner(this);
		
        if (true) {
        KuikaAppManager.showSpinner(this);
        }
        let result = await KuikaAppManager.ApiRequest(this, "RolexFamilyReporting/RolexFamilyReportingComponent_490041_onClick", localVar)
        if (!KMainFunctions.IsResStatus2XX(result)) return true;

			stateVars.ExportExcel = result?.data.exportExcel;
			ReactSystemFunctions.downloadFile(result?.data?.exportExcel);
			this.props.form?.setFieldsValue(formVars);
			this.setState(stateVars);
			KuikaAppManager.hideSpinner(this);



        this.setPageInitLoaded(true);
        KuikaAppManager.hideSpinner(this);
        return isErrorOccurred;
    }



    RolexFamilyReportingComponent_702983_onClick = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
		KuikaAppManager.increaseServerRequestCount();

        let localVar = {
				Brand_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.convertToTypeByName("Rolex", "string"), "string"),
				ProductGroup_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.convertToTypeByName("Kol saati", "string"), "string"),
				Family_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "rolexfamilyreporting_103699_value", "value", "KuikaY_GetFamilyByBrandProductGroup", "familyCode", "code")), "string"),
				Year_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "rolexfamilyreporting_521202_value", "value", "", "", "")), "number"),
				Month_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toInteger(this, ReactSystemFunctions.value(this, "rolexfamilyreporting_911338_value", "value", "", "key", "")), "number")
        }

		KuikaAppManager.showSpinner(this);
		
        if (true) {
        KuikaAppManager.showSpinner(this);
        }
        let result = await KuikaAppManager.ApiRequest(this, "RolexFamilyReporting/RolexFamilyReportingComponent_702983_onClick", localVar)
        if (!KMainFunctions.IsResStatus2XX(result)) return true;

			stateVars.KuikaY_RolexTudorFamilyStoreSalesMatrixMonthly = result?.data.kuikaY_RolexTudorFamilyStoreSalesMatrixMonthly;
			
			stateVars.isComp380Visible = ((ReactSystemFunctions.isEmpty(ReactSystemFunctions.value(this, (stateVars.KuikaY_RolexTudorFamilyStoreSalesMatrixMonthly !== undefined ? (stateVars.KuikaY_RolexTudorFamilyStoreSalesMatrixMonthly?.length > 0 ? stateVars.KuikaY_RolexTudorFamilyStoreSalesMatrixMonthly[0].toplam : null) : (this.state.KuikaY_RolexTudorFamilyStoreSalesMatrixMonthly?.length > 0 ? this.state.KuikaY_RolexTudorFamilyStoreSalesMatrixMonthly[0].toplam : null))), ReactSystemFunctions.convertToTypeByName("True", "string"))) === true ? "visible" : "hidden")
			this.props.form?.setFieldsValue(formVars);
			
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.RolexFamilyReportingComponent_702983_onClick1_();
                  resolve();
                });
          })



        
        KuikaAppManager.hideSpinner(this);
        return isErrorOccurred;
    }
		RolexFamilyReportingComponent_702983_onClick1_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }

				stateVars.ChangeVisibilityOf = await ReactSystemFunctions.changeVisibilityOf(this, ReactSystemFunctions.convertToTypeByName("isComp305499Visible", "string"), ReactSystemFunctions.convertToTypeByName("visible", "string"));
				
				stateVars.dataSource_430546 = stateVars.KuikaY_RolexTudorFamilyStoreSalesMatrixMonthly ?? this.state.KuikaY_RolexTudorFamilyStoreSalesMatrixMonthly;

		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

            
            return isErrorOccurred;
        }




		RolexFamilyReportingComponent_521202_onChange = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
KuikaAppManager.showSpinner(this);

				ReactSystemFunctions.setValueOf(this, "rolexfamilyreporting_246050_toString", ReactSystemFunctions.value(this, "rolexfamilyreporting_521202_value", "value"), "value");


		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

            
            return isErrorOccurred;
        }


		RolexFamilyReportingComponent_911338_onChange = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
KuikaAppManager.showSpinner(this);

				ReactSystemFunctions.setValueOf(this, "rolexfamilyreporting_108101_value", ReactSystemFunctions.value(this, "rolexfamilyreporting_911338_value", "value"), "value");


		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

            
            return isErrorOccurred;
        }




    async callCallbackFunction(diId: number, isFromMaster: boolean = false) {
        let isErrorOccurred = false;
		let pageInitCallerNavDiIDs = [, , , , , , ] as number[];
		if (isFromMaster || pageInitCallerNavDiIDs.indexOf(diId) > -1) {
			await this.RolexFamilyReportingPageInit();
		}

    }


}
