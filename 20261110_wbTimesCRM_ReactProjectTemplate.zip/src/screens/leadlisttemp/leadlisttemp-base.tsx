import React from "react";
import Axios, { AxiosResponse } from "axios";
import { KuikaAppManager } from "../../shared/utilty/kuika-app-manager";
import { ReactSystemFunctions } from "../../shared/utilty/react-system-functions";
import { KNavigator } from "../../shared/hoc/with-history";
import { KContext } from "../../shared/hoc/with-context";
import { useLocation } from "react-router-dom";
import { FormInstance } from "antd/es/form";
import { Guid } from "guid-typescript";
import Swal from "sweetalert2";
import { KMainFunctions } from "../../shared/utilty/main-functions";
import moment from "moment";
import { IValidationData } from "../../models/dto/validation-data";
import { IStripePayment } from "../../models/dto/stripe-payment";
import { IUserInfoDto } from "../../models/dto/user-info.dto";
import { UserService } from "../../services/user-service";
import { kuikaCoreWasmBridgeService } from "../../services/_singletons";
import _ from "lodash";
import mqtt, { MqttClient } from "mqtt";
import { IMqttResult } from "../../models/dto/mqtt.dto";
import { MasterScreen_ScreenContext } from "../masterscreen/masterscreen-context";

declare let window: any;

export interface ILeadListTemp_ScreenProps {
  navigator: KNavigator;
  form: FormInstance<any>;
  googleLogin: any;
  screenInputs: any;
  context: KContext;
  initialValues: any;
  children: any;
}

export interface ILeadListTemp_ScreenState {
    isSpinnerVisible: boolean;
    isPageVisible: boolean;
	isLeftMenuVisible: boolean;
    spinnerCount: number;
    selectedLanguage: string;
    isPageInitLoaded: false;
    isPageRecurringLoaded: false;
	TM_GetLeads: any[];
	TM_GetLeads_dummy: any[];
	TM_GetLeadListSummary: any[];
	TM_GetLeadListSummary_dummy: any[];
	TM_GetProductCategory: any[];
	TM_GetProductCategory_dummy: any[];
	TM_GetProductReferanceFilter: any[];
	TM_GetProductReferanceFilter_dummy: any[];
	TM_GetCustomerByName: any[];
	TM_GetCustomerByName_dummy: any[];
	TM_GetStore: any[];
	TM_GetStore_dummy: any[];
	TM_GetSalesPerson: any[];
	TM_GetSalesPerson_dummy: any[];
	TM_GetLeadStatus: any[];
	TM_GetLeadStatus_dummy: any[];
	TM_GetLeadProcess: any[];
	TM_GetLeadProcess_dummy: any[];
	TMGetProductAllLeadsMultiSelect: any[];
	TMGetProductAllLeadsMultiSelect_dummy: any[];
	NAVIGATE: any;
	NAVIGATE_dummy: any;
	SetValueOf: any;
	SetValueOf_dummy: any;
	ExportExcel: any;
	ExportExcel_dummy: any;
	isComp923027Visible: 'visible' | 'hidden';
	isComp169851Visible: 'visible' | 'hidden';
	isComp111623Visible: 'visible' | 'hidden';
	isComp476519Visible: 'visible' | 'hidden';
	isComp683094Visible: 'visible' | 'hidden';
	isComp277824Visible: 'visible' | 'hidden';
	isComp141038Visible: 'visible' | 'hidden';
	isComp213408Visible: 'visible' | 'hidden';
	isComp34770Visible: 'visible' | 'hidden';
	isComp83795Visible: 'visible' | 'hidden';
	isComp355093Visible: 'visible' | 'hidden';
	isComp960157Visible: 'visible' | 'hidden';
	isComp232151Visible: 'visible' | 'hidden';
	isComp766333Visible: 'visible' | 'hidden';
	isComp470694Visible: 'visible' | 'hidden';
	isComp876364Visible: 'visible' | 'hidden';
	isComp385325Visible: 'visible' | 'hidden';
	isComp923971Visible: 'visible' | 'hidden';
	isCompleadlisttemp_773100AuthorizationVisible: 'visible' | 'hidden';
	isCompleadlisttemp_476519AuthorizationVisible: 'visible' | 'hidden';

}

export class LeadListTemp_ScreenBase extends React.PureComponent<ILeadListTemp_ScreenProps, any> {
    static contextType = MasterScreen_ScreenContext;
    declare context: React.ContextType<typeof MasterScreen_ScreenContext>;
	leadlisttemp_471678_value_kuikaDateRef: React.RefObject<any>;
	leadlisttemp_740276_value_kuikaDateRef: React.RefObject<any>;
	leadlisttemp_627891_value_kuikaTableRef: React.RefObject<any>;
    ml=[{"Id":"d5a61d2b-bd60-485f-86e2-661e9ed4e486","Name":"en_US","ShortName":"English","IsDefault":true,"LanguagePhrases":[]},{"Id":"ab970eb6-1e2e-47a4-acee-ddc48539833a","Name":"FixedValues","ShortName":"FixedValues","LanguagePhrases":[{"Id":169851,"PropertyName":"label","Value":"Seçilen Talepleri Onayla"},{"Id":111623,"PropertyName":"label","Value":"Onaylanan Talepler"},{"Id":476519,"PropertyName":"label","Value":"Mevcut Talep Ekle"},{"Id":966017,"PropertyName":"value","Value":"Talep Bilgileri"},{"Id":132827,"PropertyName":"value","Value":"Tüm talepleri görüntüleyin ve yönetin."},{"Id":948271,"PropertyName":"value","Value":"Talepler"},{"Id":646303,"PropertyName":"value","Value":"Oluşturulan Talepler"},{"Id":280220,"PropertyName":"value","Value":"Onay Bekleyen"},{"Id":729091,"PropertyName":"value","Value":"Onaylanan Talepler"},{"Id":981119,"PropertyName":"value","Value":"Rezerv Onayı Bekleyen"},{"Id":668515,"PropertyName":"value","Value":"Satış Bekleyen"},{"Id":651152,"PropertyName":"value","Value":"Satışı Yapılan"},{"Id":471107,"PropertyName":"value","Value":"Reddedilen Talepler ve Kapatılan Talepler"},{"Id":20221,"PropertyName":"value","Value":"Müşteri İstemedi"},{"Id":243104,"PropertyName":"value","Value":"Talep Listesi"},{"Id":659885,"PropertyName":"label","Value":"Yeni Talep Ekle"},{"Id":685915,"PropertyName":"value","Value":"Filtre"},{"Id":576205,"PropertyName":"value","Value":"Müşteri Adı"},{"Id":637785,"PropertyName":"placeholder","Value":"Müşteri Adı"},{"Id":285691,"PropertyName":"value","Value":"Müşteri Telefon Numarası"},{"Id":156403,"PropertyName":"placeholder","Value":"Müşteri Telefon Numarası"},{"Id":895494,"PropertyName":"value","Value":"Ürün Adı"},{"Id":142164,"PropertyName":"placeholder","Value":"Ürün Adı"},{"Id":271939,"PropertyName":"value","Value":"Kategori"},{"Id":735719,"PropertyName":"placeholder","Value":"Kategori"},{"Id":500978,"PropertyName":"value","Value":"Mağaza"},{"Id":877174,"PropertyName":"placeholder","Value":"Mağaza"},{"Id":453016,"PropertyName":"value","Value":"Satış Danışmanı"},{"Id":810709,"PropertyName":"placeholder","Value":"Satış Danışmanı"},{"Id":832413,"PropertyName":"value","Value":"Talep Durumu"},{"Id":897080,"PropertyName":"placeholder","Value":"Talep Durumu"},{"Id":56163,"PropertyName":"value","Value":"Başlangıç Tarihi"},{"Id":48474,"PropertyName":"value","Value":"Bitiş Tarihi"},{"Id":816162,"PropertyName":"label","Value":"Filtre Uygula"},{"Id":105452,"PropertyName":"label","Value":"Filtre Temizle"},{"Id":422878,"PropertyName":"value","Value":"Talep Numarasına Göre Ara"},{"Id":962784,"PropertyName":"placeholder","Value":"Talep Numarası Giriniz"},{"Id":183968,"PropertyName":"label","Value":"Export Excel"},{"Id":883762,"PropertyName":"title","Value":"Talep Tarihi"},{"Id":527190,"PropertyName":"value","Value":"[datafield:taleptarihi]"},{"Id":979541,"PropertyName":"title","Value":"Talep Numarası"},{"Id":853823,"PropertyName":"value","Value":"[datafield:leadnumarasi]"},{"Id":242521,"PropertyName":"title","Value":"Mağaza"},{"Id":398060,"PropertyName":"value","Value":"[datafield:storename]"},{"Id":875824,"PropertyName":"title","Value":"Marka"},{"Id":257701,"PropertyName":"value","Value":"[datafield:brand]"},{"Id":959808,"PropertyName":"title","Value":"Kategori"},{"Id":683094,"PropertyName":"value","Value":"[datafield:categoryname]"},{"Id":277824,"PropertyName":"value","Value":"[datafield:categoryname]"},{"Id":141038,"PropertyName":"value","Value":"[datafield:categoryname]"},{"Id":213408,"PropertyName":"value","Value":"[datafield:categoryname]"},{"Id":675147,"PropertyName":"title","Value":"Ürün Adı"},{"Id":388447,"PropertyName":"value","Value":"[datafield:productname]"},{"Id":488645,"PropertyName":"title","Value":"Müşteri"},{"Id":726730,"PropertyName":"value","Value":"[datafield:musteri]"},{"Id":3245,"PropertyName":"title","Value":"Takip Durumu"},{"Id":34770,"PropertyName":"value","Value":"[datafield:leaddurumu]"},{"Id":83795,"PropertyName":"value","Value":"[datafield:leaddurumu]"},{"Id":135794,"PropertyName":"title","Value":"Sonraki Adım"},{"Id":717762,"PropertyName":"value","Value":"[datafield:sonrakiadim]"},{"Id":582755,"PropertyName":"title","Value":"Tahmini Teslimat"},{"Id":75277,"PropertyName":"value","Value":"[datafield:termintarihi]"},{"Id":450401,"PropertyName":"title","Value":"Rezerve Durumu"},{"Id":355093,"PropertyName":"value","Value":"Evet"},{"Id":960157,"PropertyName":"value","Value":"Hayır"},{"Id":232151,"PropertyName":"value","Value":"Onay Bekliyor"},{"Id":905038,"PropertyName":"title","Value":"Satış Danışmanı"},{"Id":509165,"PropertyName":"value","Value":"[datafield:satisdanismani]"},{"Id":740257,"PropertyName":"title","Value":"Talep Durumu"},{"Id":766333,"PropertyName":"value","Value":"[datafield:processname]"},{"Id":470694,"PropertyName":"value","Value":"[datafield:processname]"},{"Id":876364,"PropertyName":"value","Value":"[datafield:processname]"},{"Id":385325,"PropertyName":"value","Value":"[datafield:processname]"},{"Id":923971,"PropertyName":"value","Value":"[datafield:processname]"},{"Id":709503,"PropertyName":"title","Value":"Detay"},{"Id":777033,"PropertyName":"label","Value":"Detay"}]}]
    defaultML = "en_US"
    
    screenHash = ""
    

    private _prevMasterPageInitLoaded: boolean = false;
    private _prevMasterPageRecurringLoaded: boolean = false;
    private _prevShouldTriggerPageInit: boolean = false;
    constructor(props) {
        super(props);
		this.leadlisttemp_637785_value_kuikaTextInputRef = React.createRef();
		this.leadlisttemp_156403_value_kuikaTextInputRef = React.createRef();
		this.leadlisttemp_142164_value_kuikaTextInputRef = React.createRef();
		this.leadlisttemp_471678_value_kuikaDateRef = React.createRef();
		this.leadlisttemp_740276_value_kuikaDateRef = React.createRef();
		this.leadlisttemp_962784_value_kuikaTextInputRef = React.createRef();
		this.leadlisttemp_627891_value_kuikaTableRef = React.createRef();

        this.state = {
            isSpinnerVisible: false,
            isPageVisible: false,
            isLeftMenuVisible: false,
            spinnerCount: 0,
            selectedLanguage: "",
            isPageInitLoaded: false,
            isPageRecurringLoaded: false,
            	        TM_GetLeads: [],
	        TM_GetLeadListSummary: [],
	        TM_GetProductCategory: [],
	        TM_GetProductReferanceFilter: [],
	        TM_GetCustomerByName: [],
	        TM_GetStore: [],
	        TM_GetSalesPerson: [],
	        TM_GetLeadStatus: [],
	        TM_GetLeadProcess: [],
	        TMGetProductAllLeadsMultiSelect: [],
	        NAVIGATE: "",
	        SetValueOf: "",
	        ExportExcel: "",
	        isComp923027Visible: 'hidden',
	        isComp169851Visible: 'hidden',
	        isComp111623Visible: 'hidden',
	        isComp476519Visible: 'hidden',
	        isComp683094Visible: 'hidden',
	        isComp277824Visible: 'hidden',
	        isComp141038Visible: 'hidden',
	        isComp213408Visible: 'hidden',
	        isComp34770Visible: 'hidden',
	        isComp83795Visible: 'hidden',
	        isComp355093Visible: 'hidden',
	        isComp960157Visible: 'hidden',
	        isComp232151Visible: 'hidden',
	        isComp766333Visible: 'hidden',
	        isComp470694Visible: 'hidden',
	        isComp876364Visible: 'hidden',
	        isComp385325Visible: 'hidden',
	        isComp923971Visible: 'hidden',
	        isCompleadlisttemp_773100AuthorizationVisible: 'visible',
	        isCompleadlisttemp_476519AuthorizationVisible: 'visible',

        }

        this.CheckPageAuthorization(this.state);

        
    }

    async componentDidMount() {

        if (KuikaAppManager.isPageInitPrevented()) {
            KuikaAppManager.calculateAndSetBodyHeight("leadlisttemp", "masterscreen_screen");
            return;
        }
        this.context.registerCallbackFunction(this.callCallbackFunction.bind(this));
        
        ReactSystemFunctions.validateToken()
        this.fillFormInitValues();
        if (false){
            await this.LeadListTempPageInit();
        } else if (this.context?.isMasterPageInitLoaded) { this._prevMasterPageInitLoaded = true; await this.LeadListTempPageInit(); }
        ReactSystemFunctions.hideIsNotAuthorized(this, "isCompleadlisttemp_773100AuthorizationVisible", ["cdb536b0-6297-155f-d446-8453d8a60304","4da1f213-c8e4-0b50-5c84-02fd13f1a622","70de6cfc-6087-6059-59b4-0b5a8527af6b","c4e882ef-977d-f613-7694-230ac83919d2","TimesYonetici","TimesUstYonetici","TimesMagazaMuduru","TimesAdmin"]);
ReactSystemFunctions.hideIsNotAuthorized(this, "isCompleadlisttemp_476519AuthorizationVisible", ["cdb536b0-6297-155f-d446-8453d8a60304","4da1f213-c8e4-0b50-5c84-02fd13f1a622","70de6cfc-6087-6059-59b4-0b5a8527af6b","c4e882ef-977d-f613-7694-230ac83919d2","TimesYonetici","TimesUstYonetici","TimesMagazaMuduru","TimesAdmin"]);

        
        
        KuikaAppManager.calculateAndSetBodyHeight("leadlisttemp", "masterscreen_screen");

        if (ReactSystemFunctions.getIsMicroApp() === false) {
           window.parentScreen = this;
        }
    }

    componentWillUnmount() {
        
        
        

        if (ReactSystemFunctions.getIsMicroApp() === false) {
           window.parentScreen = null;
        }
    }

    
              CheckPageAuthorization = async (state) => {
                KuikaAppManager.showSpinner(this);
                if (_.isEmpty(window.userInfo)) {
                  await UserService.GetUserInfoForce();
                }
                const permittedRoleNames: string[] = ["TimesYonetici","TimesUstYonetici","TimesSatisPersoneli","TimesMagazaMuduru","TimesAdmin","_SystemAdmin",];
                const userInfo = window.userInfo as IUserInfoDto;
                const userRoleNames = userInfo.roles.map((role) => role.name);
                if (!ReactSystemFunctions.hasAnyRoleName(permittedRoleNames, userRoleNames)) {
                  await ReactSystemFunctions.goBack(this);

                  const language = localStorage.getItem("ml");
                  let permissonErrorMessageText = "You do not have permission to access this page.";
                  if (language === "tr_TR") {
                    permissonErrorMessageText = "Bu sayfaya erişim yetkiniz yok.";
                  } else if (language === "fr_FR") {
                    permissonErrorMessageText = "Vous n'avez pas la permission d'accéder à cette page.";
                  } else if (language === "de_DE") {
                    permissonErrorMessageText = "Sie haben keine Berechtigung, auf diese Seite zuzugreifen.";
                  } else if (language === "es_ES") {
                    permissonErrorMessageText = "No tienes permiso para acceder a esta página.";
                  }

                  KMainFunctions.displayErrorNotification(permissonErrorMessageText);
                  state.isPageVisible = false;
                  KuikaAppManager.hideSpinner(this);
                  return;
                }
                state.isPageVisible = true;
                KuikaAppManager.hideSpinner(this);
              };
        

        
    componentDidUpdate= async (prevProps, prevState) => {
		KuikaAppManager.calculateAndSetBodyHeight("leadlisttemp", "masterscreen_screen"    );
        if (prevProps?.location?.search !== (this.props as any)?.location?.search) {
			await this.LeadListTempPageInit();
		}

        		if (this._prevMasterPageInitLoaded !== this.context.isMasterPageInitLoaded && this.context.isMasterPageInitLoaded === true) {this._prevMasterPageInitLoaded = this.context.isMasterPageInitLoaded;await this.LeadListTempPageInit()}


        if (ReactSystemFunctions.getIsMicroApp() === false) {
            for (const key in prevState) {
                if (key.startsWith('NavVisible') && prevState[key] === true && this.state[key] === false) {
                    window.parentScreen = this;
                    break;
                }
            }
        }
	}

    fillFormInitValues() {
        this.props.form?.setFieldsValue({
});

    }

      setPageInitLoaded = (value: boolean) => {
        this.setState({ isPageInitLoaded: value });
      }

      setPageRecurringLoaded = (value: boolean) => {
        this.setState({ isPageRecurringLoaded: value });
      }

      clearFieldValidation = (changedValues: any) => {
        const fieldName = Object.keys(changedValues)[0];
        if (fieldName) {
          this.props.form?.setFields([
            {
              name: fieldName,
              errors: []
            }
          ]);
        }
      };

      

    LeadListTempPageInit = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


	if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }

        let localVar = {
			StepOrder_0: ReactSystemFunctions.convertToTypeByName(0, "number"),
			UserId_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.getMyUserId(), "Guid"),
			MusteriAdi_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "leadlisttemp_637785_value", "value", "", "", "")), "string"),
			ProductName_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "leadlisttemp_142164_value", "value", "", "", "")), "string"),
			LeadCode_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "leadlisttemp_962784_value", "value", "", "", "")), "string"),
			Tel_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "leadlisttemp_156403_value", "value", "", "", "")), "string"),
			CategoryName_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "leadlisttemp_735719_value", "value", "TM_GetProductCategory", "categoryCode", "categoryName")), "string"),
			StoreIds_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "leadlisttemp_877174_value", "value", "TM_GetStore", "storeCode", "id")), "string"),
			SatisDanismaniIds_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "leadlisttemp_810709_value", "value", "TM_GetSalesPerson", "kUserId", "kUserId")), "string"),
			ProcessCode_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "leadlisttemp_897080_value", "value", "TM_GetLeadProcess", "id", "code")), "string"),
			StartDate_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "leadlisttemp_471678_value", "value", "", "", "")), "Date"),
			EndDate_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "leadlisttemp_740276_value", "value", "", "", "")), "Date"),
			UserId_1: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.getMyUserId(), "Guid"),
			MusteriAdi_1: ReactSystemFunctions.convertToTypeByName(null, "string"),
			ProductName_1: ReactSystemFunctions.convertToTypeByName(null, "string"),
			LeadCode_1: ReactSystemFunctions.convertToTypeByName(null, "string"),
			Tel_1: ReactSystemFunctions.convertToTypeByName(null, "string"),
			CategoryName_1: ReactSystemFunctions.convertToTypeByName(null, "string"),
			StoreIds_1: ReactSystemFunctions.convertToTypeByName(null, "string"),
			SatisDanismaniIds_1: ReactSystemFunctions.convertToTypeByName(null, "string"),
			ProcessCode_1: ReactSystemFunctions.convertToTypeByName(null, "string"),
			StartDate_1: ReactSystemFunctions.convertToTypeByName(null, "Date"),
			EndDate_1: ReactSystemFunctions.convertToTypeByName(null, "Date"),
			KUserId_5: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.getMyUserId(), "Guid"),
			KUserId_6: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.getMyUserId(), "Guid"),
			StoreId_6: ReactSystemFunctions.convertToTypeByName(null, "Guid"),
			StepOrder_8: ReactSystemFunctions.convertToTypeByName(0, "number"),
			StepOrder_10: ReactSystemFunctions.convertToTypeByName(0, "number"),
			UserId_10: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.getMyUserId(), "Guid"),
			MusteriAdi_10: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "leadlisttemp_637785_value", "value", "", "", "")), "string"),
			ProductName_10: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "leadlisttemp_142164_value", "value", "", "", "")), "string"),
			LeadCode_10: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "leadlisttemp_962784_value", "value", "", "", "")), "string"),
			Tel_10: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "leadlisttemp_156403_value", "value", "", "", "")), "string"),
			CategoryName_10: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "leadlisttemp_735719_value", "value", "TM_GetProductCategory", "categoryCode", "categoryName")), "string"),
			StoreIds_10: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "leadlisttemp_877174_value", "value", "TM_GetStore", "storeCode", "id")), "string"),
			SatisDanismaniIds_10: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "leadlisttemp_810709_value", "value", "TM_GetSalesPerson", "kUserId", "kUserId")), "string"),
			ProcessCode_10: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "leadlisttemp_897080_value", "value", "TM_GetLeadProcess", "id", "code")), "string"),
			StartDate_10: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "leadlisttemp_471678_value", "value", "", "", "")), "Date"),
			EndDate_10: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "leadlisttemp_740276_value", "value", "", "", "")), "Date")
        }

	KuikaAppManager.showSpinner(this);
	
        if (true) {
        KuikaAppManager.showSpinner(this);
        }
        let result = await KuikaAppManager.ApiRequest(this, "LeadListTemp/LeadListTempPageInit", localVar)
        if (!KMainFunctions.IsResStatus2XX(result)) return true;

		stateVars.TM_GetLeads = result?.data.tM_GetLeads;
		
		stateVars.TM_GetLeadListSummary = result?.data.tM_GetLeadListSummary;
		formVars.leadlisttemp_694879_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadListSummary !== undefined ? (stateVars.TM_GetLeadListSummary?.length > 0 ? stateVars.TM_GetLeadListSummary[0].talepler : null) : (this.state.TM_GetLeadListSummary?.length > 0 ? this.state.TM_GetLeadListSummary[0].talepler : null)));
		formVars.leadlisttemp_961337_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadListSummary !== undefined ? (stateVars.TM_GetLeadListSummary?.length > 0 ? stateVars.TM_GetLeadListSummary[0].olusturulanTalepler : null) : (this.state.TM_GetLeadListSummary?.length > 0 ? this.state.TM_GetLeadListSummary[0].olusturulanTalepler : null)));
		formVars.leadlisttemp_644429_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadListSummary !== undefined ? (stateVars.TM_GetLeadListSummary?.length > 0 ? stateVars.TM_GetLeadListSummary[0].onayBekleyen : null) : (this.state.TM_GetLeadListSummary?.length > 0 ? this.state.TM_GetLeadListSummary[0].onayBekleyen : null)));
		formVars.leadlisttemp_101832_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadListSummary !== undefined ? (stateVars.TM_GetLeadListSummary?.length > 0 ? stateVars.TM_GetLeadListSummary[0].onaylananTalepler : null) : (this.state.TM_GetLeadListSummary?.length > 0 ? this.state.TM_GetLeadListSummary[0].onaylananTalepler : null)));
		formVars.leadlisttemp_941027_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadListSummary !== undefined ? (stateVars.TM_GetLeadListSummary?.length > 0 ? stateVars.TM_GetLeadListSummary[0].rezervOnayBekleyen : null) : (this.state.TM_GetLeadListSummary?.length > 0 ? this.state.TM_GetLeadListSummary[0].rezervOnayBekleyen : null)));
		formVars.leadlisttemp_606021_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadListSummary !== undefined ? (stateVars.TM_GetLeadListSummary?.length > 0 ? stateVars.TM_GetLeadListSummary[0].satisBekleyen : null) : (this.state.TM_GetLeadListSummary?.length > 0 ? this.state.TM_GetLeadListSummary[0].satisBekleyen : null)));
		formVars.leadlisttemp_599705_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadListSummary !== undefined ? (stateVars.TM_GetLeadListSummary?.length > 0 ? stateVars.TM_GetLeadListSummary[0].satisiYapilan : null) : (this.state.TM_GetLeadListSummary?.length > 0 ? this.state.TM_GetLeadListSummary[0].satisiYapilan : null)));
		formVars.leadlisttemp_585643_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadListSummary !== undefined ? (stateVars.TM_GetLeadListSummary?.length > 0 ? stateVars.TM_GetLeadListSummary[0].reddedilenKapatilanToplam : null) : (this.state.TM_GetLeadListSummary?.length > 0 ? this.state.TM_GetLeadListSummary[0].reddedilenKapatilanToplam : null)));
		formVars.leadlisttemp_604493_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadListSummary !== undefined ? (stateVars.TM_GetLeadListSummary?.length > 0 ? stateVars.TM_GetLeadListSummary[0].musteriIstemedi : null) : (this.state.TM_GetLeadListSummary?.length > 0 ? this.state.TM_GetLeadListSummary[0].musteriIstemedi : null)));
		stateVars.TM_GetProductCategory = result?.data.tM_GetProductCategory;
		
		formVars.leadlisttemp_735719_options = stateVars.TM_GetProductCategory;
		stateVars.TM_GetProductReferanceFilter = result?.data.tM_GetProductReferanceFilter;
		stateVars.TM_GetCustomerByName = result?.data.tM_GetCustomerByName;
		stateVars.TM_GetStore = result?.data.tM_GetStore;
		
		formVars.leadlisttemp_877174_options = stateVars.TM_GetStore;
		stateVars.TM_GetSalesPerson = result?.data.tM_GetSalesPerson;
		
		formVars.leadlisttemp_810709_options = stateVars.TM_GetSalesPerson;
		stateVars.TM_GetLeadStatus = result?.data.tM_GetLeadStatus;
		stateVars.TM_GetLeadProcess = result?.data.tM_GetLeadProcess;
		
		formVars.leadlisttemp_897080_options = stateVars.TM_GetLeadProcess;
		stateVars.TMGetProductAllLeadsMultiSelect = result?.data.tmGetProductAllLeadsMultiSelect;
		stateVars.TM_GetLeads = result?.data.tM_GetLeads;
		
		this.props.form?.setFieldsValue(formVars);
		
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.LeadListTempPageInit1_();
                  resolve();
                });
          })



        
        KuikaAppManager.hideSpinner(this);
        return isErrorOccurred;
    }
	LeadListTempPageInit1_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


	if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }

			stateVars.isComp923027Visible = (((ReactSystemFunctions.contains(ReactSystemFunctions.getMyRoleNames(), ReactSystemFunctions.convertToTypeByName("TimesUstYonetici", "string")) || ReactSystemFunctions.contains(ReactSystemFunctions.getMyRoleNames(), ReactSystemFunctions.convertToTypeByName("TimesMagazaMuduru", "string")))) === true ? "visible" : "hidden")
			stateVars.isComp169851Visible = ((ReactSystemFunctions.contains(ReactSystemFunctions.getMyRoleNames(), ReactSystemFunctions.convertToTypeByName("TimesUstYonetici", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp111623Visible = ((ReactSystemFunctions.contains(ReactSystemFunctions.getMyRoleNames(), ReactSystemFunctions.convertToTypeByName("TimesUstYonetici", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp476519Visible = (((ReactSystemFunctions.contains(ReactSystemFunctions.getMyRoleNames(), ReactSystemFunctions.convertToTypeByName("TimesUstYonetici", "string")) || ReactSystemFunctions.contains(ReactSystemFunctions.getMyRoleNames(), ReactSystemFunctions.convertToTypeByName("TimesMagazaMuduru", "string")))) === true ? "visible" : "hidden")
			formVars.leadlisttemp_694879_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadListSummary !== undefined ? (stateVars.TM_GetLeadListSummary?.length > 0 ? stateVars.TM_GetLeadListSummary[0].talepler : null) : (this.state.TM_GetLeadListSummary?.length > 0 ? this.state.TM_GetLeadListSummary[0].talepler : null)));

			formVars.leadlisttemp_961337_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadListSummary !== undefined ? (stateVars.TM_GetLeadListSummary?.length > 0 ? stateVars.TM_GetLeadListSummary[0].olusturulanTalepler : null) : (this.state.TM_GetLeadListSummary?.length > 0 ? this.state.TM_GetLeadListSummary[0].olusturulanTalepler : null)));

			formVars.leadlisttemp_644429_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadListSummary !== undefined ? (stateVars.TM_GetLeadListSummary?.length > 0 ? stateVars.TM_GetLeadListSummary[0].onayBekleyen : null) : (this.state.TM_GetLeadListSummary?.length > 0 ? this.state.TM_GetLeadListSummary[0].onayBekleyen : null)));

			formVars.leadlisttemp_101832_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadListSummary !== undefined ? (stateVars.TM_GetLeadListSummary?.length > 0 ? stateVars.TM_GetLeadListSummary[0].onaylananTalepler : null) : (this.state.TM_GetLeadListSummary?.length > 0 ? this.state.TM_GetLeadListSummary[0].onaylananTalepler : null)));

			formVars.leadlisttemp_941027_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadListSummary !== undefined ? (stateVars.TM_GetLeadListSummary?.length > 0 ? stateVars.TM_GetLeadListSummary[0].rezervOnayBekleyen : null) : (this.state.TM_GetLeadListSummary?.length > 0 ? this.state.TM_GetLeadListSummary[0].rezervOnayBekleyen : null)));

			formVars.leadlisttemp_606021_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadListSummary !== undefined ? (stateVars.TM_GetLeadListSummary?.length > 0 ? stateVars.TM_GetLeadListSummary[0].satisBekleyen : null) : (this.state.TM_GetLeadListSummary?.length > 0 ? this.state.TM_GetLeadListSummary[0].satisBekleyen : null)));

			formVars.leadlisttemp_599705_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadListSummary !== undefined ? (stateVars.TM_GetLeadListSummary?.length > 0 ? stateVars.TM_GetLeadListSummary[0].satisiYapilan : null) : (this.state.TM_GetLeadListSummary?.length > 0 ? this.state.TM_GetLeadListSummary[0].satisiYapilan : null)));

			formVars.leadlisttemp_585643_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadListSummary !== undefined ? (stateVars.TM_GetLeadListSummary?.length > 0 ? stateVars.TM_GetLeadListSummary[0].reddedilenKapatilanToplam : null) : (this.state.TM_GetLeadListSummary?.length > 0 ? this.state.TM_GetLeadListSummary[0].reddedilenKapatilanToplam : null)));

			formVars.leadlisttemp_604493_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadListSummary !== undefined ? (stateVars.TM_GetLeadListSummary?.length > 0 ? stateVars.TM_GetLeadListSummary[0].musteriIstemedi : null) : (this.state.TM_GetLeadListSummary?.length > 0 ? this.state.TM_GetLeadListSummary[0].musteriIstemedi : null)));

			
			stateVars.dataSource_735719 = stateVars.TM_GetProductCategory ?? this.state.TM_GetProductCategory;
			stateVars.dataSource_735719 = stateVars.TM_GetProductCategory ?? this.state.TM_GetProductCategory;
			
			stateVars.dataSource_877174 = stateVars.TM_GetStore ?? this.state.TM_GetStore;
			stateVars.dataSource_877174 = stateVars.TM_GetStore ?? this.state.TM_GetStore;
			
			stateVars.dataSource_810709 = stateVars.TM_GetSalesPerson ?? this.state.TM_GetSalesPerson;
			stateVars.dataSource_810709 = stateVars.TM_GetSalesPerson ?? this.state.TM_GetSalesPerson;
			
			stateVars.dataSource_897080 = stateVars.TM_GetLeadProcess ?? this.state.TM_GetLeadProcess;
			stateVars.dataSource_897080 = stateVars.TM_GetLeadProcess ?? this.state.TM_GetLeadProcess;
			
			stateVars.dataSource_627891 = stateVars.TM_GetLeads ?? this.state.TM_GetLeads;
			stateVars.isComp683094Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, "leadlisttemp_627891_value", "categoryName"), ReactSystemFunctions.convertToTypeByName("Kategori 2", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp277824Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, "leadlisttemp_627891_value", "categoryName"), ReactSystemFunctions.convertToTypeByName("Kategori 1", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp141038Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, "leadlisttemp_627891_value", "categoryName"), ReactSystemFunctions.convertToTypeByName("DEFAULT", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp213408Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, "leadlisttemp_627891_value", "categoryName"), ReactSystemFunctions.convertToTypeByName("Kategori 3", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp34770Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, "leadlisttemp_627891_value", "leadDurumu"), ReactSystemFunctions.convertToTypeByName("Takip ediliyor", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp83795Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, "leadlisttemp_627891_value", "leadDurumu"), ReactSystemFunctions.convertToTypeByName("2. Takip", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp355093Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, "leadlisttemp_627891_value", "rezerveDurumu"), ReactSystemFunctions.convertToTypeByName("Evet", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp960157Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, "leadlisttemp_627891_value", "rezerveDurumu"), ReactSystemFunctions.convertToTypeByName("Hayır", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp232151Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, "leadlisttemp_627891_value", "rezerveDurumu"), ReactSystemFunctions.convertToTypeByName("Onay Bekliyor", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp766333Visible = (((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, "leadlisttemp_627891_value", "processCode"), ReactSystemFunctions.convertToTypeByName("PENDING", "string")) || ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, "leadlisttemp_627891_value", "processCode"), ReactSystemFunctions.convertToTypeByName("TERMIN_PENDING", "string")) || ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, "leadlisttemp_627891_value", "processCode"), ReactSystemFunctions.convertToTypeByName("DELIVERY_PENDING", "string")))) === true ? "visible" : "hidden")
			stateVars.isComp470694Visible = (((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, "leadlisttemp_627891_value", "processCode"), ReactSystemFunctions.convertToTypeByName("CUSTOMER_DECLINED", "string")) || ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, "leadlisttemp_627891_value", "processCode"), ReactSystemFunctions.convertToTypeByName("REJECTED", "string")))) === true ? "visible" : "hidden")
			stateVars.isComp876364Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, "leadlisttemp_627891_value", "processCode"), ReactSystemFunctions.convertToTypeByName("DELIVERED", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp385325Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, "leadlisttemp_627891_value", "processCode"), ReactSystemFunctions.convertToTypeByName("CLOSED", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp923971Visible = (((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, "leadlisttemp_627891_value", "processCode"), ReactSystemFunctions.convertToTypeByName("APPROVED", "string")) || ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, "leadlisttemp_627891_value", "processCode"), ReactSystemFunctions.convertToTypeByName("CREATED", "string")))) === true ? "visible" : "hidden")

	this.props.form?.setFieldsValue(formVars);
	this.setState(stateVars);
	KuikaAppManager.hideSpinner(this);

            this.setPageInitLoaded(true);
            return isErrorOccurred;
        }




		LeadListTempComponent_169851_onClick = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
KuikaAppManager.showSpinner(this);

const __currentPath = (window.location.hash ? window.location.hash.replace(/^#/, '').split('?')[0] : window.location.pathname.split('?')[0]).toLowerCase();
if (__currentPath !== "/allleadpending") {
  this.context.setMasterPageInitLoaded(false);
  this.context.setMasterPageRecurringLoaded(false);
  this.context.setShouldTriggerPageInit(true);
}
					KuikaAppManager.prepareForNavigation();

				stateVars.NAVIGATE = await ReactSystemFunctions.navigate(this, undefined, "LeadListTemp", "AllLeadPending", "", "currentPage", null, null, null, null, null, null, true, false);

		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

            
            return isErrorOccurred;
        }


		LeadListTempComponent_111623_onClick = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
if ((ReactSystemFunctions.contains(ReactSystemFunctions.getMyRoleNames(), "TimesUstYonetici") || ReactSystemFunctions.contains(ReactSystemFunctions.getMyRoleNames(), "TimesYonetici"))) {
            KuikaAppManager.showSpinner(this);

const __currentPath = (window.location.hash ? window.location.hash.replace(/^#/, '').split('?')[0] : window.location.pathname.split('?')[0]).toLowerCase();
if (__currentPath !== "/approvedleadlist") {
  this.context.setMasterPageInitLoaded(false);
  this.context.setMasterPageRecurringLoaded(false);
  this.context.setShouldTriggerPageInit(true);
}
					KuikaAppManager.prepareForNavigation();

				stateVars.NAVIGATE = await ReactSystemFunctions.navigate(this, undefined, "LeadListTemp", "ApprovedLeadList", "", "currentPage", null, null, null, null, null, null, true, false);

		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

        } else {
            KuikaAppManager.hideSpinner(this);
        }

            
            return isErrorOccurred;
        }


    LeadListTempComponent_308567_onClick = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
		KuikaAppManager.increaseServerRequestCount();

        let localVar = {
				StepOrder_0: ReactSystemFunctions.convertToTypeByName(0, "number"),
				UserId_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.getMyUserId(), "Guid"),
				MusteriAdi_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "leadlisttemp_637785_value", "value", "", "", "")), "string"),
				ProductName_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "leadlisttemp_142164_value", "value", "", "", "")), "string"),
				LeadCode_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "leadlisttemp_962784_value", "value", "", "", "")), "string"),
				Tel_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "leadlisttemp_156403_value", "value", "", "", "")), "string"),
				CategoryName_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "leadlisttemp_735719_value", "value", "TM_GetProductCategory", "categoryCode", "categoryName")), "string"),
				StoreIds_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "leadlisttemp_877174_value", "value", "TM_GetStore", "storeCode", "id")), "string"),
				SatisDanismaniIds_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "leadlisttemp_810709_value", "value", "TM_GetSalesPerson", "kUserId", "kUserId")), "string"),
				ProcessCode_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "leadlisttemp_897080_value", "value", "TM_GetLeadProcess", "id", "code")), "string"),
				StartDate_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "leadlisttemp_471678_value", "value", "", "", "")), "Date"),
				EndDate_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "leadlisttemp_740276_value", "value", "", "", "")), "Date")
        }

		KuikaAppManager.showSpinner(this);
		
        if (true) {
        KuikaAppManager.showSpinner(this);
        }
        let result = await KuikaAppManager.ApiRequest(this, "LeadListTemp/LeadListTempComponent_308567_onClick", localVar)
        if (!KMainFunctions.IsResStatus2XX(result)) return true;

			stateVars.TM_GetLeads = result?.data.tM_GetLeads;
			
			this.props.form?.setFieldsValue(formVars);
			
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.LeadListTempComponent_308567_onClick1_();
                  resolve();
                });
          })



        
        KuikaAppManager.hideSpinner(this);
        return isErrorOccurred;
    }
		LeadListTempComponent_308567_onClick1_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }

				
				stateVars.dataSource_627891 = stateVars.TM_GetLeads ?? this.state.TM_GetLeads;

		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

            
            return isErrorOccurred;
        }




    LeadListTempComponent_600134_onClick = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
		KuikaAppManager.increaseServerRequestCount();

        let localVar = {
				StepOrder_0: ReactSystemFunctions.convertToTypeByName(1, "number"),
				UserId_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.getMyUserId(), "Guid"),
				MusteriAdi_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "leadlisttemp_637785_value", "value", "", "", "")), "string"),
				ProductName_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "leadlisttemp_142164_value", "value", "", "", "")), "string"),
				LeadCode_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "leadlisttemp_962784_value", "value", "", "", "")), "string"),
				Tel_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "leadlisttemp_156403_value", "value", "", "", "")), "string"),
				CategoryName_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "leadlisttemp_735719_value", "value", "TM_GetProductCategory", "categoryCode", "categoryName")), "string"),
				StoreIds_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "leadlisttemp_877174_value", "value", "TM_GetStore", "storeCode", "id")), "string"),
				SatisDanismaniIds_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "leadlisttemp_810709_value", "value", "TM_GetSalesPerson", "kUserId", "kUserId")), "string"),
				ProcessCode_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "leadlisttemp_897080_value", "value", "TM_GetLeadProcess", "id", "code")), "string"),
				StartDate_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "leadlisttemp_471678_value", "value", "", "", "")), "Date"),
				EndDate_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "leadlisttemp_740276_value", "value", "", "", "")), "Date")
        }

		KuikaAppManager.showSpinner(this);
		
        if (true) {
        KuikaAppManager.showSpinner(this);
        }
        let result = await KuikaAppManager.ApiRequest(this, "LeadListTemp/LeadListTempComponent_600134_onClick", localVar)
        if (!KMainFunctions.IsResStatus2XX(result)) return true;

			stateVars.TM_GetLeads = result?.data.tM_GetLeads;
			
			this.props.form?.setFieldsValue(formVars);
			
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.LeadListTempComponent_600134_onClick1_();
                  resolve();
                });
          })



        
        KuikaAppManager.hideSpinner(this);
        return isErrorOccurred;
    }
		LeadListTempComponent_600134_onClick1_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }

				
				stateVars.dataSource_627891 = stateVars.TM_GetLeads ?? this.state.TM_GetLeads;

		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

            
            return isErrorOccurred;
        }




    LeadListTempComponent_382936_onClick = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
		KuikaAppManager.increaseServerRequestCount();

        let localVar = {
				StepOrder_0: ReactSystemFunctions.convertToTypeByName(3, "number"),
				UserId_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.getMyUserId(), "Guid"),
				MusteriAdi_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "leadlisttemp_637785_value", "value", "", "", "")), "string"),
				ProductName_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "leadlisttemp_142164_value", "value", "", "", "")), "string"),
				LeadCode_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "leadlisttemp_962784_value", "value", "", "", "")), "string"),
				Tel_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "leadlisttemp_156403_value", "value", "", "", "")), "string"),
				CategoryName_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "leadlisttemp_735719_value", "value", "TM_GetProductCategory", "categoryCode", "categoryName")), "string"),
				StoreIds_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "leadlisttemp_877174_value", "value", "TM_GetStore", "storeCode", "id")), "string"),
				SatisDanismaniIds_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "leadlisttemp_810709_value", "value", "TM_GetSalesPerson", "kUserId", "kUserId")), "string"),
				ProcessCode_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "leadlisttemp_897080_value", "value", "TM_GetLeadProcess", "id", "code")), "string"),
				StartDate_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "leadlisttemp_471678_value", "value", "", "", "")), "Date"),
				EndDate_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "leadlisttemp_740276_value", "value", "", "", "")), "Date")
        }

		KuikaAppManager.showSpinner(this);
		
        if (true) {
        KuikaAppManager.showSpinner(this);
        }
        let result = await KuikaAppManager.ApiRequest(this, "LeadListTemp/LeadListTempComponent_382936_onClick", localVar)
        if (!KMainFunctions.IsResStatus2XX(result)) return true;

			stateVars.TM_GetLeads = result?.data.tM_GetLeads;
			
			this.props.form?.setFieldsValue(formVars);
			
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.LeadListTempComponent_382936_onClick1_();
                  resolve();
                });
          })



        
        KuikaAppManager.hideSpinner(this);
        return isErrorOccurred;
    }
		LeadListTempComponent_382936_onClick1_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }

				
				stateVars.dataSource_627891 = stateVars.TM_GetLeads ?? this.state.TM_GetLeads;

		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

            
            return isErrorOccurred;
        }




    LeadListTempComponent_863882_onClick = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
		KuikaAppManager.increaseServerRequestCount();

        let localVar = {
				StepOrder_0: ReactSystemFunctions.convertToTypeByName(4, "number"),
				UserId_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.getMyUserId(), "Guid"),
				MusteriAdi_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "leadlisttemp_637785_value", "value", "", "", "")), "string"),
				ProductName_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "leadlisttemp_142164_value", "value", "", "", "")), "string"),
				LeadCode_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "leadlisttemp_962784_value", "value", "", "", "")), "string"),
				Tel_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "leadlisttemp_156403_value", "value", "", "", "")), "string"),
				CategoryName_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "leadlisttemp_735719_value", "value", "TM_GetProductCategory", "categoryCode", "categoryName")), "string"),
				StoreIds_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "leadlisttemp_877174_value", "value", "TM_GetStore", "storeCode", "id")), "string"),
				SatisDanismaniIds_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "leadlisttemp_810709_value", "value", "TM_GetSalesPerson", "kUserId", "kUserId")), "string"),
				ProcessCode_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "leadlisttemp_897080_value", "value", "TM_GetLeadProcess", "id", "code")), "string"),
				StartDate_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "leadlisttemp_471678_value", "value", "", "", "")), "Date"),
				EndDate_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "leadlisttemp_740276_value", "value", "", "", "")), "Date")
        }

		KuikaAppManager.showSpinner(this);
		
        if (true) {
        KuikaAppManager.showSpinner(this);
        }
        let result = await KuikaAppManager.ApiRequest(this, "LeadListTemp/LeadListTempComponent_863882_onClick", localVar)
        if (!KMainFunctions.IsResStatus2XX(result)) return true;

			stateVars.TM_GetLeads = result?.data.tM_GetLeads;
			
			this.props.form?.setFieldsValue(formVars);
			
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.LeadListTempComponent_863882_onClick1_();
                  resolve();
                });
          })



        
        KuikaAppManager.hideSpinner(this);
        return isErrorOccurred;
    }
		LeadListTempComponent_863882_onClick1_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }

				
				stateVars.dataSource_627891 = stateVars.TM_GetLeads ?? this.state.TM_GetLeads;

		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

            
            return isErrorOccurred;
        }




    LeadListTempComponent_484161_onClick = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
		KuikaAppManager.increaseServerRequestCount();

        let localVar = {
				StepOrder_0: ReactSystemFunctions.convertToTypeByName(10, "number"),
				UserId_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.getMyUserId(), "Guid"),
				MusteriAdi_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "leadlisttemp_637785_value", "value", "", "", "")), "string"),
				ProductName_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "leadlisttemp_142164_value", "value", "", "", "")), "string"),
				LeadCode_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "leadlisttemp_962784_value", "value", "", "", "")), "string"),
				Tel_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "leadlisttemp_156403_value", "value", "", "", "")), "string"),
				CategoryName_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "leadlisttemp_735719_value", "value", "TM_GetProductCategory", "categoryCode", "categoryName")), "string"),
				StoreIds_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "leadlisttemp_877174_value", "value", "TM_GetStore", "storeCode", "id")), "string"),
				SatisDanismaniIds_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "leadlisttemp_810709_value", "value", "TM_GetSalesPerson", "kUserId", "kUserId")), "string"),
				ProcessCode_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "leadlisttemp_897080_value", "value", "TM_GetLeadProcess", "id", "code")), "string"),
				StartDate_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "leadlisttemp_471678_value", "value", "", "", "")), "Date"),
				EndDate_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "leadlisttemp_740276_value", "value", "", "", "")), "Date")
        }

		KuikaAppManager.showSpinner(this);
		
        if (true) {
        KuikaAppManager.showSpinner(this);
        }
        let result = await KuikaAppManager.ApiRequest(this, "LeadListTemp/LeadListTempComponent_484161_onClick", localVar)
        if (!KMainFunctions.IsResStatus2XX(result)) return true;

			stateVars.TM_GetLeads = result?.data.tM_GetLeads;
			
			this.props.form?.setFieldsValue(formVars);
			
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.LeadListTempComponent_484161_onClick1_();
                  resolve();
                });
          })



        
        KuikaAppManager.hideSpinner(this);
        return isErrorOccurred;
    }
		LeadListTempComponent_484161_onClick1_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }

				
				stateVars.dataSource_627891 = stateVars.TM_GetLeads ?? this.state.TM_GetLeads;

		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

            
            return isErrorOccurred;
        }




    LeadListTempComponent_788080_onClick = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
		KuikaAppManager.increaseServerRequestCount();

        let localVar = {
				StepOrder_0: ReactSystemFunctions.convertToTypeByName(6, "number"),
				UserId_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.getMyUserId(), "Guid"),
				MusteriAdi_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "leadlisttemp_637785_value", "value", "", "", "")), "string"),
				ProductName_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "leadlisttemp_142164_value", "value", "", "", "")), "string"),
				LeadCode_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "leadlisttemp_962784_value", "value", "", "", "")), "string"),
				Tel_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "leadlisttemp_156403_value", "value", "", "", "")), "string"),
				CategoryName_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "leadlisttemp_735719_value", "value", "TM_GetProductCategory", "categoryCode", "categoryName")), "string"),
				StoreIds_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "leadlisttemp_877174_value", "value", "TM_GetStore", "storeCode", "id")), "string"),
				SatisDanismaniIds_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "leadlisttemp_810709_value", "value", "TM_GetSalesPerson", "kUserId", "kUserId")), "string"),
				ProcessCode_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "leadlisttemp_897080_value", "value", "TM_GetLeadProcess", "id", "code")), "string"),
				StartDate_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "leadlisttemp_471678_value", "value", "", "", "")), "Date"),
				EndDate_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "leadlisttemp_740276_value", "value", "", "", "")), "Date")
        }

		KuikaAppManager.showSpinner(this);
		
        if (true) {
        KuikaAppManager.showSpinner(this);
        }
        let result = await KuikaAppManager.ApiRequest(this, "LeadListTemp/LeadListTempComponent_788080_onClick", localVar)
        if (!KMainFunctions.IsResStatus2XX(result)) return true;

			stateVars.TM_GetLeads = result?.data.tM_GetLeads;
			
			this.props.form?.setFieldsValue(formVars);
			
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.LeadListTempComponent_788080_onClick1_();
                  resolve();
                });
          })



        
        KuikaAppManager.hideSpinner(this);
        return isErrorOccurred;
    }
		LeadListTempComponent_788080_onClick1_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }

				
				stateVars.dataSource_627891 = stateVars.TM_GetLeads ?? this.state.TM_GetLeads;

		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

            
            return isErrorOccurred;
        }




    LeadListTempComponent_589711_onClick = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
		KuikaAppManager.increaseServerRequestCount();

        let localVar = {
				StepOrder_0: ReactSystemFunctions.convertToTypeByName(7, "number"),
				UserId_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.getMyUserId(), "Guid"),
				MusteriAdi_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "leadlisttemp_637785_value", "value", "", "", "")), "string"),
				ProductName_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "leadlisttemp_142164_value", "value", "", "", "")), "string"),
				LeadCode_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "leadlisttemp_962784_value", "value", "", "", "")), "string"),
				Tel_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "leadlisttemp_156403_value", "value", "", "", "")), "string"),
				CategoryName_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "leadlisttemp_735719_value", "value", "TM_GetProductCategory", "categoryCode", "categoryName")), "string"),
				StoreIds_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "leadlisttemp_877174_value", "value", "TM_GetStore", "storeCode", "id")), "string"),
				SatisDanismaniIds_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "leadlisttemp_810709_value", "value", "TM_GetSalesPerson", "kUserId", "kUserId")), "string"),
				ProcessCode_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "leadlisttemp_897080_value", "value", "TM_GetLeadProcess", "id", "code")), "string"),
				StartDate_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "leadlisttemp_471678_value", "value", "", "", "")), "Date"),
				EndDate_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "leadlisttemp_740276_value", "value", "", "", "")), "Date")
        }

		KuikaAppManager.showSpinner(this);
		
        if (true) {
        KuikaAppManager.showSpinner(this);
        }
        let result = await KuikaAppManager.ApiRequest(this, "LeadListTemp/LeadListTempComponent_589711_onClick", localVar)
        if (!KMainFunctions.IsResStatus2XX(result)) return true;

			stateVars.TM_GetLeads = result?.data.tM_GetLeads;
			
			this.props.form?.setFieldsValue(formVars);
			
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.LeadListTempComponent_589711_onClick1_();
                  resolve();
                });
          })



        
        KuikaAppManager.hideSpinner(this);
        return isErrorOccurred;
    }
		LeadListTempComponent_589711_onClick1_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }

				
				stateVars.dataSource_627891 = stateVars.TM_GetLeads ?? this.state.TM_GetLeads;

		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

            
            return isErrorOccurred;
        }




    LeadListTempComponent_742423_onClick = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
		KuikaAppManager.increaseServerRequestCount();

        let localVar = {
				StepOrder_0: ReactSystemFunctions.convertToTypeByName(5, "number"),
				UserId_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.getMyUserId(), "Guid"),
				MusteriAdi_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "leadlisttemp_637785_value", "value", "", "", "")), "string"),
				ProductName_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "leadlisttemp_142164_value", "value", "", "", "")), "string"),
				LeadCode_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "leadlisttemp_962784_value", "value", "", "", "")), "string"),
				Tel_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "leadlisttemp_156403_value", "value", "", "", "")), "string"),
				CategoryName_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "leadlisttemp_735719_value", "value", "TM_GetProductCategory", "categoryCode", "categoryName")), "string"),
				StoreIds_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "leadlisttemp_877174_value", "value", "TM_GetStore", "storeCode", "id")), "string"),
				SatisDanismaniIds_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "leadlisttemp_810709_value", "value", "TM_GetSalesPerson", "kUserId", "kUserId")), "string"),
				ProcessCode_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "leadlisttemp_897080_value", "value", "TM_GetLeadProcess", "id", "code")), "string"),
				StartDate_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "leadlisttemp_471678_value", "value", "", "", "")), "Date"),
				EndDate_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "leadlisttemp_740276_value", "value", "", "", "")), "Date")
        }

		KuikaAppManager.showSpinner(this);
		
        if (true) {
        KuikaAppManager.showSpinner(this);
        }
        let result = await KuikaAppManager.ApiRequest(this, "LeadListTemp/LeadListTempComponent_742423_onClick", localVar)
        if (!KMainFunctions.IsResStatus2XX(result)) return true;

			stateVars.TM_GetLeads = result?.data.tM_GetLeads;
			
			this.props.form?.setFieldsValue(formVars);
			
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.LeadListTempComponent_742423_onClick1_();
                  resolve();
                });
          })



        
        KuikaAppManager.hideSpinner(this);
        return isErrorOccurred;
    }
		LeadListTempComponent_742423_onClick1_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }

				
				stateVars.dataSource_627891 = stateVars.TM_GetLeads ?? this.state.TM_GetLeads;

		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

            
            return isErrorOccurred;
        }




    LeadListTempComponent_273825_onClick = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
		KuikaAppManager.increaseServerRequestCount();

        let localVar = {
				StepOrder_0: ReactSystemFunctions.convertToTypeByName(99, "number"),
				UserId_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.getMyUserId(), "Guid"),
				MusteriAdi_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "leadlisttemp_637785_value", "value", "", "", "")), "string"),
				ProductName_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "leadlisttemp_142164_value", "value", "", "", "")), "string"),
				LeadCode_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "leadlisttemp_962784_value", "value", "", "", "")), "string"),
				Tel_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "leadlisttemp_156403_value", "value", "", "", "")), "string"),
				CategoryName_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "leadlisttemp_735719_value", "value", "TM_GetProductCategory", "categoryCode", "categoryName")), "string"),
				StoreIds_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "leadlisttemp_877174_value", "value", "TM_GetStore", "storeCode", "id")), "string"),
				SatisDanismaniIds_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "leadlisttemp_810709_value", "value", "TM_GetSalesPerson", "kUserId", "kUserId")), "string"),
				ProcessCode_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "leadlisttemp_897080_value", "value", "TM_GetLeadProcess", "id", "code")), "string"),
				StartDate_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "leadlisttemp_471678_value", "value", "", "", "")), "Date"),
				EndDate_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "leadlisttemp_740276_value", "value", "", "", "")), "Date")
        }

		KuikaAppManager.showSpinner(this);
		
        if (true) {
        KuikaAppManager.showSpinner(this);
        }
        let result = await KuikaAppManager.ApiRequest(this, "LeadListTemp/LeadListTempComponent_273825_onClick", localVar)
        if (!KMainFunctions.IsResStatus2XX(result)) return true;

			stateVars.TM_GetLeads = result?.data.tM_GetLeads;
			
			this.props.form?.setFieldsValue(formVars);
			
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.LeadListTempComponent_273825_onClick1_();
                  resolve();
                });
          })



        
        KuikaAppManager.hideSpinner(this);
        return isErrorOccurred;
    }
		LeadListTempComponent_273825_onClick1_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }

				
				stateVars.dataSource_627891 = stateVars.TM_GetLeads ?? this.state.TM_GetLeads;

		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

            
            return isErrorOccurred;
        }




		LeadListTempComponent_659885_onClick = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
KuikaAppManager.showSpinner(this);

					KuikaAppManager.prepareForNavigation();
						KuikaAppManager.addToPageInputVariables("LeadAdd", "CustomerId", ReactSystemFunctions.convertToTypeByName("00000000-0000-0000-0000-000000000000", "Guid"));

				stateVars.NAVIGATE = await ReactSystemFunctions.navigate(this, undefined, "LeadListTemp", "LeadAdd", "", "7d969ddf-5801-4eb6-b92b-12be35bdd565", "935516", null, "right", "true", "70vw", "100vh", true, false);

		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

            
            return isErrorOccurred;
        }


    LeadListTempComponent_637785_onBlur = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
		KuikaAppManager.increaseServerRequestCount();

        let localVar = {
				StepOrder_0: ReactSystemFunctions.convertToTypeByName(0, "number"),
				UserId_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.getMyUserId(), "Guid"),
				MusteriAdi_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "leadlisttemp_637785_value", "value", "", "", "")), "string"),
				ProductName_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "leadlisttemp_142164_value", "value", "", "", "")), "string"),
				LeadCode_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "leadlisttemp_962784_value", "value", "", "", "")), "string"),
				Tel_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "leadlisttemp_156403_value", "value", "", "", "")), "string"),
				CategoryName_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "leadlisttemp_735719_value", "value", "TM_GetProductCategory", "categoryCode", "categoryName")), "string"),
				StoreIds_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "leadlisttemp_877174_value", "value", "TM_GetStore", "storeCode", "id")), "string"),
				SatisDanismaniIds_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "leadlisttemp_810709_value", "value", "TM_GetSalesPerson", "kUserId", "kUserId")), "string"),
				ProcessCode_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "leadlisttemp_897080_value", "value", "TM_GetLeadProcess", "id", "code")), "string"),
				StartDate_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "leadlisttemp_471678_value", "value", "", "", "")), "Date"),
				EndDate_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "leadlisttemp_740276_value", "value", "", "", "")), "Date"),
				UserId_1: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.getMyUserId(), "Guid"),
				MusteriAdi_1: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "leadlisttemp_637785_value", "value", "", "", "")), "string"),
				ProductName_1: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "leadlisttemp_142164_value", "value", "", "", "")), "string"),
				LeadCode_1: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "leadlisttemp_962784_value", "value", "", "", "")), "string"),
				Tel_1: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "leadlisttemp_156403_value", "value", "", "", "")), "string"),
				CategoryName_1: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "leadlisttemp_735719_value", "value", "TM_GetProductCategory", "categoryCode", "categoryName")), "string"),
				StoreIds_1: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "leadlisttemp_877174_value", "value", "TM_GetStore", "storeCode", "id")), "string"),
				SatisDanismaniIds_1: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "leadlisttemp_810709_value", "value", "TM_GetSalesPerson", "kUserId", "kUserId")), "string"),
				ProcessCode_1: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "leadlisttemp_897080_value", "value", "TM_GetLeadProcess", "id", "code")), "string"),
				StartDate_1: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "leadlisttemp_471678_value", "value", "", "", "")), "Date"),
				EndDate_1: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "leadlisttemp_740276_value", "value", "", "", "")), "Date")
        }

		KuikaAppManager.showSpinner(this);
		
        if (true) {
        KuikaAppManager.showSpinner(this);
        }
        let result = await KuikaAppManager.ApiRequest(this, "LeadListTemp/LeadListTempComponent_637785_onBlur", localVar)
        if (!KMainFunctions.IsResStatus2XX(result)) return true;

			stateVars.TM_GetLeads = result?.data.tM_GetLeads;
			
			stateVars.TM_GetLeadListSummary = result?.data.tM_GetLeadListSummary;
			formVars.leadlisttemp_694879_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadListSummary !== undefined ? (stateVars.TM_GetLeadListSummary?.length > 0 ? stateVars.TM_GetLeadListSummary[0].talepler : null) : (this.state.TM_GetLeadListSummary?.length > 0 ? this.state.TM_GetLeadListSummary[0].talepler : null)));
			formVars.leadlisttemp_961337_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadListSummary !== undefined ? (stateVars.TM_GetLeadListSummary?.length > 0 ? stateVars.TM_GetLeadListSummary[0].olusturulanTalepler : null) : (this.state.TM_GetLeadListSummary?.length > 0 ? this.state.TM_GetLeadListSummary[0].olusturulanTalepler : null)));
			formVars.leadlisttemp_644429_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadListSummary !== undefined ? (stateVars.TM_GetLeadListSummary?.length > 0 ? stateVars.TM_GetLeadListSummary[0].onayBekleyen : null) : (this.state.TM_GetLeadListSummary?.length > 0 ? this.state.TM_GetLeadListSummary[0].onayBekleyen : null)));
			formVars.leadlisttemp_101832_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadListSummary !== undefined ? (stateVars.TM_GetLeadListSummary?.length > 0 ? stateVars.TM_GetLeadListSummary[0].onaylananTalepler : null) : (this.state.TM_GetLeadListSummary?.length > 0 ? this.state.TM_GetLeadListSummary[0].onaylananTalepler : null)));
			formVars.leadlisttemp_941027_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadListSummary !== undefined ? (stateVars.TM_GetLeadListSummary?.length > 0 ? stateVars.TM_GetLeadListSummary[0].rezervOnayBekleyen : null) : (this.state.TM_GetLeadListSummary?.length > 0 ? this.state.TM_GetLeadListSummary[0].rezervOnayBekleyen : null)));
			formVars.leadlisttemp_606021_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadListSummary !== undefined ? (stateVars.TM_GetLeadListSummary?.length > 0 ? stateVars.TM_GetLeadListSummary[0].satisBekleyen : null) : (this.state.TM_GetLeadListSummary?.length > 0 ? this.state.TM_GetLeadListSummary[0].satisBekleyen : null)));
			formVars.leadlisttemp_599705_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadListSummary !== undefined ? (stateVars.TM_GetLeadListSummary?.length > 0 ? stateVars.TM_GetLeadListSummary[0].satisiYapilan : null) : (this.state.TM_GetLeadListSummary?.length > 0 ? this.state.TM_GetLeadListSummary[0].satisiYapilan : null)));
			formVars.leadlisttemp_585643_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadListSummary !== undefined ? (stateVars.TM_GetLeadListSummary?.length > 0 ? stateVars.TM_GetLeadListSummary[0].reddedilenKapatilanToplam : null) : (this.state.TM_GetLeadListSummary?.length > 0 ? this.state.TM_GetLeadListSummary[0].reddedilenKapatilanToplam : null)));
			formVars.leadlisttemp_604493_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadListSummary !== undefined ? (stateVars.TM_GetLeadListSummary?.length > 0 ? stateVars.TM_GetLeadListSummary[0].musteriIstemedi : null) : (this.state.TM_GetLeadListSummary?.length > 0 ? this.state.TM_GetLeadListSummary[0].musteriIstemedi : null)));
			this.props.form?.setFieldsValue(formVars);
			
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.LeadListTempComponent_637785_onBlur1_();
                  resolve();
                });
          })



        
        KuikaAppManager.hideSpinner(this);
        return isErrorOccurred;
    }
		LeadListTempComponent_637785_onBlur1_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }

				formVars.leadlisttemp_694879_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadListSummary !== undefined ? (stateVars.TM_GetLeadListSummary?.length > 0 ? stateVars.TM_GetLeadListSummary[0].talepler : null) : (this.state.TM_GetLeadListSummary?.length > 0 ? this.state.TM_GetLeadListSummary[0].talepler : null)));

				formVars.leadlisttemp_961337_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadListSummary !== undefined ? (stateVars.TM_GetLeadListSummary?.length > 0 ? stateVars.TM_GetLeadListSummary[0].olusturulanTalepler : null) : (this.state.TM_GetLeadListSummary?.length > 0 ? this.state.TM_GetLeadListSummary[0].olusturulanTalepler : null)));

				formVars.leadlisttemp_644429_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadListSummary !== undefined ? (stateVars.TM_GetLeadListSummary?.length > 0 ? stateVars.TM_GetLeadListSummary[0].onayBekleyen : null) : (this.state.TM_GetLeadListSummary?.length > 0 ? this.state.TM_GetLeadListSummary[0].onayBekleyen : null)));

				formVars.leadlisttemp_101832_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadListSummary !== undefined ? (stateVars.TM_GetLeadListSummary?.length > 0 ? stateVars.TM_GetLeadListSummary[0].onaylananTalepler : null) : (this.state.TM_GetLeadListSummary?.length > 0 ? this.state.TM_GetLeadListSummary[0].onaylananTalepler : null)));

				formVars.leadlisttemp_941027_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadListSummary !== undefined ? (stateVars.TM_GetLeadListSummary?.length > 0 ? stateVars.TM_GetLeadListSummary[0].rezervOnayBekleyen : null) : (this.state.TM_GetLeadListSummary?.length > 0 ? this.state.TM_GetLeadListSummary[0].rezervOnayBekleyen : null)));

				formVars.leadlisttemp_606021_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadListSummary !== undefined ? (stateVars.TM_GetLeadListSummary?.length > 0 ? stateVars.TM_GetLeadListSummary[0].satisBekleyen : null) : (this.state.TM_GetLeadListSummary?.length > 0 ? this.state.TM_GetLeadListSummary[0].satisBekleyen : null)));

				formVars.leadlisttemp_599705_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadListSummary !== undefined ? (stateVars.TM_GetLeadListSummary?.length > 0 ? stateVars.TM_GetLeadListSummary[0].satisiYapilan : null) : (this.state.TM_GetLeadListSummary?.length > 0 ? this.state.TM_GetLeadListSummary[0].satisiYapilan : null)));

				formVars.leadlisttemp_585643_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadListSummary !== undefined ? (stateVars.TM_GetLeadListSummary?.length > 0 ? stateVars.TM_GetLeadListSummary[0].reddedilenKapatilanToplam : null) : (this.state.TM_GetLeadListSummary?.length > 0 ? this.state.TM_GetLeadListSummary[0].reddedilenKapatilanToplam : null)));

				formVars.leadlisttemp_604493_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadListSummary !== undefined ? (stateVars.TM_GetLeadListSummary?.length > 0 ? stateVars.TM_GetLeadListSummary[0].musteriIstemedi : null) : (this.state.TM_GetLeadListSummary?.length > 0 ? this.state.TM_GetLeadListSummary[0].musteriIstemedi : null)));

				
				stateVars.dataSource_627891 = stateVars.TM_GetLeads ?? this.state.TM_GetLeads;

		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

            
            return isErrorOccurred;
        }




    LeadListTempComponent_156403_onBlur = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
		KuikaAppManager.increaseServerRequestCount();

        let localVar = {
				StepOrder_0: ReactSystemFunctions.convertToTypeByName(0, "number"),
				UserId_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.getMyUserId(), "Guid"),
				MusteriAdi_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "leadlisttemp_637785_value", "value", "", "", "")), "string"),
				ProductName_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "leadlisttemp_142164_value", "value", "", "", "")), "string"),
				LeadCode_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "leadlisttemp_962784_value", "value", "", "", "")), "string"),
				Tel_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "leadlisttemp_156403_value", "value", "", "", "")), "string"),
				CategoryName_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "leadlisttemp_735719_value", "value", "TM_GetProductCategory", "categoryCode", "categoryName")), "string"),
				StoreIds_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "leadlisttemp_877174_value", "value", "TM_GetStore", "storeCode", "id")), "string"),
				SatisDanismaniIds_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "leadlisttemp_810709_value", "value", "TM_GetSalesPerson", "kUserId", "kUserId")), "string"),
				ProcessCode_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "leadlisttemp_897080_value", "value", "TM_GetLeadProcess", "id", "code")), "string"),
				StartDate_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "leadlisttemp_471678_value", "value", "", "", "")), "Date"),
				EndDate_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "leadlisttemp_740276_value", "value", "", "", "")), "Date"),
				UserId_1: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.getMyUserId(), "Guid"),
				MusteriAdi_1: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "leadlisttemp_637785_value", "value", "", "", "")), "string"),
				ProductName_1: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "leadlisttemp_142164_value", "value", "", "", "")), "string"),
				LeadCode_1: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "leadlisttemp_962784_value", "value", "", "", "")), "string"),
				Tel_1: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "leadlisttemp_156403_value", "value", "", "", "")), "string"),
				CategoryName_1: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "leadlisttemp_735719_value", "value", "TM_GetProductCategory", "categoryCode", "categoryName")), "string"),
				StoreIds_1: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "leadlisttemp_877174_value", "value", "TM_GetStore", "storeCode", "id")), "string"),
				SatisDanismaniIds_1: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "leadlisttemp_810709_value", "value", "TM_GetSalesPerson", "kUserId", "kUserId")), "string"),
				ProcessCode_1: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "leadlisttemp_897080_value", "value", "TM_GetLeadProcess", "id", "code")), "string"),
				StartDate_1: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "leadlisttemp_471678_value", "value", "", "", "")), "Date"),
				EndDate_1: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "leadlisttemp_740276_value", "value", "", "", "")), "Date")
        }

		KuikaAppManager.showSpinner(this);
		
        if (true) {
        KuikaAppManager.showSpinner(this);
        }
        let result = await KuikaAppManager.ApiRequest(this, "LeadListTemp/LeadListTempComponent_156403_onBlur", localVar)
        if (!KMainFunctions.IsResStatus2XX(result)) return true;

			stateVars.TM_GetLeads = result?.data.tM_GetLeads;
			
			stateVars.TM_GetLeadListSummary = result?.data.tM_GetLeadListSummary;
			formVars.leadlisttemp_694879_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadListSummary !== undefined ? (stateVars.TM_GetLeadListSummary?.length > 0 ? stateVars.TM_GetLeadListSummary[0].talepler : null) : (this.state.TM_GetLeadListSummary?.length > 0 ? this.state.TM_GetLeadListSummary[0].talepler : null)));
			formVars.leadlisttemp_961337_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadListSummary !== undefined ? (stateVars.TM_GetLeadListSummary?.length > 0 ? stateVars.TM_GetLeadListSummary[0].olusturulanTalepler : null) : (this.state.TM_GetLeadListSummary?.length > 0 ? this.state.TM_GetLeadListSummary[0].olusturulanTalepler : null)));
			formVars.leadlisttemp_644429_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadListSummary !== undefined ? (stateVars.TM_GetLeadListSummary?.length > 0 ? stateVars.TM_GetLeadListSummary[0].onayBekleyen : null) : (this.state.TM_GetLeadListSummary?.length > 0 ? this.state.TM_GetLeadListSummary[0].onayBekleyen : null)));
			formVars.leadlisttemp_101832_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadListSummary !== undefined ? (stateVars.TM_GetLeadListSummary?.length > 0 ? stateVars.TM_GetLeadListSummary[0].onaylananTalepler : null) : (this.state.TM_GetLeadListSummary?.length > 0 ? this.state.TM_GetLeadListSummary[0].onaylananTalepler : null)));
			formVars.leadlisttemp_941027_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadListSummary !== undefined ? (stateVars.TM_GetLeadListSummary?.length > 0 ? stateVars.TM_GetLeadListSummary[0].rezervOnayBekleyen : null) : (this.state.TM_GetLeadListSummary?.length > 0 ? this.state.TM_GetLeadListSummary[0].rezervOnayBekleyen : null)));
			formVars.leadlisttemp_606021_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadListSummary !== undefined ? (stateVars.TM_GetLeadListSummary?.length > 0 ? stateVars.TM_GetLeadListSummary[0].satisBekleyen : null) : (this.state.TM_GetLeadListSummary?.length > 0 ? this.state.TM_GetLeadListSummary[0].satisBekleyen : null)));
			formVars.leadlisttemp_599705_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadListSummary !== undefined ? (stateVars.TM_GetLeadListSummary?.length > 0 ? stateVars.TM_GetLeadListSummary[0].satisiYapilan : null) : (this.state.TM_GetLeadListSummary?.length > 0 ? this.state.TM_GetLeadListSummary[0].satisiYapilan : null)));
			formVars.leadlisttemp_585643_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadListSummary !== undefined ? (stateVars.TM_GetLeadListSummary?.length > 0 ? stateVars.TM_GetLeadListSummary[0].reddedilenKapatilanToplam : null) : (this.state.TM_GetLeadListSummary?.length > 0 ? this.state.TM_GetLeadListSummary[0].reddedilenKapatilanToplam : null)));
			formVars.leadlisttemp_604493_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadListSummary !== undefined ? (stateVars.TM_GetLeadListSummary?.length > 0 ? stateVars.TM_GetLeadListSummary[0].musteriIstemedi : null) : (this.state.TM_GetLeadListSummary?.length > 0 ? this.state.TM_GetLeadListSummary[0].musteriIstemedi : null)));
			this.props.form?.setFieldsValue(formVars);
			
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.LeadListTempComponent_156403_onBlur1_();
                  resolve();
                });
          })



        
        KuikaAppManager.hideSpinner(this);
        return isErrorOccurred;
    }
		LeadListTempComponent_156403_onBlur1_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }

				formVars.leadlisttemp_694879_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadListSummary !== undefined ? (stateVars.TM_GetLeadListSummary?.length > 0 ? stateVars.TM_GetLeadListSummary[0].talepler : null) : (this.state.TM_GetLeadListSummary?.length > 0 ? this.state.TM_GetLeadListSummary[0].talepler : null)));

				formVars.leadlisttemp_961337_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadListSummary !== undefined ? (stateVars.TM_GetLeadListSummary?.length > 0 ? stateVars.TM_GetLeadListSummary[0].olusturulanTalepler : null) : (this.state.TM_GetLeadListSummary?.length > 0 ? this.state.TM_GetLeadListSummary[0].olusturulanTalepler : null)));

				formVars.leadlisttemp_644429_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadListSummary !== undefined ? (stateVars.TM_GetLeadListSummary?.length > 0 ? stateVars.TM_GetLeadListSummary[0].onayBekleyen : null) : (this.state.TM_GetLeadListSummary?.length > 0 ? this.state.TM_GetLeadListSummary[0].onayBekleyen : null)));

				formVars.leadlisttemp_101832_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadListSummary !== undefined ? (stateVars.TM_GetLeadListSummary?.length > 0 ? stateVars.TM_GetLeadListSummary[0].onaylananTalepler : null) : (this.state.TM_GetLeadListSummary?.length > 0 ? this.state.TM_GetLeadListSummary[0].onaylananTalepler : null)));

				formVars.leadlisttemp_941027_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadListSummary !== undefined ? (stateVars.TM_GetLeadListSummary?.length > 0 ? stateVars.TM_GetLeadListSummary[0].rezervOnayBekleyen : null) : (this.state.TM_GetLeadListSummary?.length > 0 ? this.state.TM_GetLeadListSummary[0].rezervOnayBekleyen : null)));

				formVars.leadlisttemp_606021_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadListSummary !== undefined ? (stateVars.TM_GetLeadListSummary?.length > 0 ? stateVars.TM_GetLeadListSummary[0].satisBekleyen : null) : (this.state.TM_GetLeadListSummary?.length > 0 ? this.state.TM_GetLeadListSummary[0].satisBekleyen : null)));

				formVars.leadlisttemp_599705_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadListSummary !== undefined ? (stateVars.TM_GetLeadListSummary?.length > 0 ? stateVars.TM_GetLeadListSummary[0].satisiYapilan : null) : (this.state.TM_GetLeadListSummary?.length > 0 ? this.state.TM_GetLeadListSummary[0].satisiYapilan : null)));

				formVars.leadlisttemp_585643_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadListSummary !== undefined ? (stateVars.TM_GetLeadListSummary?.length > 0 ? stateVars.TM_GetLeadListSummary[0].reddedilenKapatilanToplam : null) : (this.state.TM_GetLeadListSummary?.length > 0 ? this.state.TM_GetLeadListSummary[0].reddedilenKapatilanToplam : null)));

				formVars.leadlisttemp_604493_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadListSummary !== undefined ? (stateVars.TM_GetLeadListSummary?.length > 0 ? stateVars.TM_GetLeadListSummary[0].musteriIstemedi : null) : (this.state.TM_GetLeadListSummary?.length > 0 ? this.state.TM_GetLeadListSummary[0].musteriIstemedi : null)));

				
				stateVars.dataSource_627891 = stateVars.TM_GetLeads ?? this.state.TM_GetLeads;

		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

            
            return isErrorOccurred;
        }




    LeadListTempComponent_142164_onBlur = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
		KuikaAppManager.increaseServerRequestCount();

        let localVar = {
				StepOrder_0: ReactSystemFunctions.convertToTypeByName(0, "number"),
				UserId_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.getMyUserId(), "Guid"),
				MusteriAdi_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "leadlisttemp_637785_value", "value", "", "", "")), "string"),
				ProductName_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "leadlisttemp_142164_value", "value", "", "", "")), "string"),
				LeadCode_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "leadlisttemp_962784_value", "value", "", "", "")), "string"),
				Tel_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "leadlisttemp_156403_value", "value", "", "", "")), "string"),
				CategoryName_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "leadlisttemp_735719_value", "value", "TM_GetProductCategory", "categoryCode", "categoryName")), "string"),
				StoreIds_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "leadlisttemp_877174_value", "value", "TM_GetStore", "storeCode", "id")), "string"),
				SatisDanismaniIds_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "leadlisttemp_810709_value", "value", "TM_GetSalesPerson", "kUserId", "kUserId")), "string"),
				ProcessCode_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "leadlisttemp_897080_value", "value", "TM_GetLeadProcess", "id", "code")), "string"),
				StartDate_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "leadlisttemp_471678_value", "value", "", "", "")), "Date"),
				EndDate_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "leadlisttemp_740276_value", "value", "", "", "")), "Date"),
				UserId_1: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.getMyUserId(), "Guid"),
				MusteriAdi_1: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "leadlisttemp_637785_value", "value", "", "", "")), "string"),
				ProductName_1: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "leadlisttemp_142164_value", "value", "", "", "")), "string"),
				LeadCode_1: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "leadlisttemp_962784_value", "value", "", "", "")), "string"),
				Tel_1: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "leadlisttemp_156403_value", "value", "", "", "")), "string"),
				CategoryName_1: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "leadlisttemp_735719_value", "value", "TM_GetProductCategory", "categoryCode", "categoryName")), "string"),
				StoreIds_1: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "leadlisttemp_877174_value", "value", "TM_GetStore", "storeCode", "id")), "string"),
				SatisDanismaniIds_1: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "leadlisttemp_810709_value", "value", "TM_GetSalesPerson", "kUserId", "kUserId")), "string"),
				ProcessCode_1: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "leadlisttemp_897080_value", "value", "TM_GetLeadProcess", "id", "code")), "string"),
				StartDate_1: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "leadlisttemp_471678_value", "value", "", "", "")), "Date"),
				EndDate_1: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "leadlisttemp_740276_value", "value", "", "", "")), "Date")
        }

		KuikaAppManager.showSpinner(this);
		
        if (true) {
        KuikaAppManager.showSpinner(this);
        }
        let result = await KuikaAppManager.ApiRequest(this, "LeadListTemp/LeadListTempComponent_142164_onBlur", localVar)
        if (!KMainFunctions.IsResStatus2XX(result)) return true;

			stateVars.TM_GetLeads = result?.data.tM_GetLeads;
			
			stateVars.TM_GetLeadListSummary = result?.data.tM_GetLeadListSummary;
			formVars.leadlisttemp_694879_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadListSummary !== undefined ? (stateVars.TM_GetLeadListSummary?.length > 0 ? stateVars.TM_GetLeadListSummary[0].talepler : null) : (this.state.TM_GetLeadListSummary?.length > 0 ? this.state.TM_GetLeadListSummary[0].talepler : null)));
			formVars.leadlisttemp_961337_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadListSummary !== undefined ? (stateVars.TM_GetLeadListSummary?.length > 0 ? stateVars.TM_GetLeadListSummary[0].olusturulanTalepler : null) : (this.state.TM_GetLeadListSummary?.length > 0 ? this.state.TM_GetLeadListSummary[0].olusturulanTalepler : null)));
			formVars.leadlisttemp_644429_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadListSummary !== undefined ? (stateVars.TM_GetLeadListSummary?.length > 0 ? stateVars.TM_GetLeadListSummary[0].onayBekleyen : null) : (this.state.TM_GetLeadListSummary?.length > 0 ? this.state.TM_GetLeadListSummary[0].onayBekleyen : null)));
			formVars.leadlisttemp_101832_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadListSummary !== undefined ? (stateVars.TM_GetLeadListSummary?.length > 0 ? stateVars.TM_GetLeadListSummary[0].onaylananTalepler : null) : (this.state.TM_GetLeadListSummary?.length > 0 ? this.state.TM_GetLeadListSummary[0].onaylananTalepler : null)));
			formVars.leadlisttemp_941027_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadListSummary !== undefined ? (stateVars.TM_GetLeadListSummary?.length > 0 ? stateVars.TM_GetLeadListSummary[0].rezervOnayBekleyen : null) : (this.state.TM_GetLeadListSummary?.length > 0 ? this.state.TM_GetLeadListSummary[0].rezervOnayBekleyen : null)));
			formVars.leadlisttemp_606021_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadListSummary !== undefined ? (stateVars.TM_GetLeadListSummary?.length > 0 ? stateVars.TM_GetLeadListSummary[0].satisBekleyen : null) : (this.state.TM_GetLeadListSummary?.length > 0 ? this.state.TM_GetLeadListSummary[0].satisBekleyen : null)));
			formVars.leadlisttemp_599705_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadListSummary !== undefined ? (stateVars.TM_GetLeadListSummary?.length > 0 ? stateVars.TM_GetLeadListSummary[0].satisiYapilan : null) : (this.state.TM_GetLeadListSummary?.length > 0 ? this.state.TM_GetLeadListSummary[0].satisiYapilan : null)));
			formVars.leadlisttemp_585643_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadListSummary !== undefined ? (stateVars.TM_GetLeadListSummary?.length > 0 ? stateVars.TM_GetLeadListSummary[0].reddedilenKapatilanToplam : null) : (this.state.TM_GetLeadListSummary?.length > 0 ? this.state.TM_GetLeadListSummary[0].reddedilenKapatilanToplam : null)));
			formVars.leadlisttemp_604493_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadListSummary !== undefined ? (stateVars.TM_GetLeadListSummary?.length > 0 ? stateVars.TM_GetLeadListSummary[0].musteriIstemedi : null) : (this.state.TM_GetLeadListSummary?.length > 0 ? this.state.TM_GetLeadListSummary[0].musteriIstemedi : null)));
			this.props.form?.setFieldsValue(formVars);
			
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.LeadListTempComponent_142164_onBlur1_();
                  resolve();
                });
          })



        
        KuikaAppManager.hideSpinner(this);
        return isErrorOccurred;
    }
		LeadListTempComponent_142164_onBlur1_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }

				formVars.leadlisttemp_694879_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadListSummary !== undefined ? (stateVars.TM_GetLeadListSummary?.length > 0 ? stateVars.TM_GetLeadListSummary[0].talepler : null) : (this.state.TM_GetLeadListSummary?.length > 0 ? this.state.TM_GetLeadListSummary[0].talepler : null)));

				formVars.leadlisttemp_961337_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadListSummary !== undefined ? (stateVars.TM_GetLeadListSummary?.length > 0 ? stateVars.TM_GetLeadListSummary[0].olusturulanTalepler : null) : (this.state.TM_GetLeadListSummary?.length > 0 ? this.state.TM_GetLeadListSummary[0].olusturulanTalepler : null)));

				formVars.leadlisttemp_644429_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadListSummary !== undefined ? (stateVars.TM_GetLeadListSummary?.length > 0 ? stateVars.TM_GetLeadListSummary[0].onayBekleyen : null) : (this.state.TM_GetLeadListSummary?.length > 0 ? this.state.TM_GetLeadListSummary[0].onayBekleyen : null)));

				formVars.leadlisttemp_101832_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadListSummary !== undefined ? (stateVars.TM_GetLeadListSummary?.length > 0 ? stateVars.TM_GetLeadListSummary[0].onaylananTalepler : null) : (this.state.TM_GetLeadListSummary?.length > 0 ? this.state.TM_GetLeadListSummary[0].onaylananTalepler : null)));

				formVars.leadlisttemp_941027_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadListSummary !== undefined ? (stateVars.TM_GetLeadListSummary?.length > 0 ? stateVars.TM_GetLeadListSummary[0].rezervOnayBekleyen : null) : (this.state.TM_GetLeadListSummary?.length > 0 ? this.state.TM_GetLeadListSummary[0].rezervOnayBekleyen : null)));

				formVars.leadlisttemp_606021_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadListSummary !== undefined ? (stateVars.TM_GetLeadListSummary?.length > 0 ? stateVars.TM_GetLeadListSummary[0].satisBekleyen : null) : (this.state.TM_GetLeadListSummary?.length > 0 ? this.state.TM_GetLeadListSummary[0].satisBekleyen : null)));

				formVars.leadlisttemp_599705_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadListSummary !== undefined ? (stateVars.TM_GetLeadListSummary?.length > 0 ? stateVars.TM_GetLeadListSummary[0].satisiYapilan : null) : (this.state.TM_GetLeadListSummary?.length > 0 ? this.state.TM_GetLeadListSummary[0].satisiYapilan : null)));

				formVars.leadlisttemp_585643_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadListSummary !== undefined ? (stateVars.TM_GetLeadListSummary?.length > 0 ? stateVars.TM_GetLeadListSummary[0].reddedilenKapatilanToplam : null) : (this.state.TM_GetLeadListSummary?.length > 0 ? this.state.TM_GetLeadListSummary[0].reddedilenKapatilanToplam : null)));

				formVars.leadlisttemp_604493_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadListSummary !== undefined ? (stateVars.TM_GetLeadListSummary?.length > 0 ? stateVars.TM_GetLeadListSummary[0].musteriIstemedi : null) : (this.state.TM_GetLeadListSummary?.length > 0 ? this.state.TM_GetLeadListSummary[0].musteriIstemedi : null)));

				
				stateVars.dataSource_627891 = stateVars.TM_GetLeads ?? this.state.TM_GetLeads;

		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

            
            return isErrorOccurred;
        }




    LeadListTempComponent_735719_onChange = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
		KuikaAppManager.increaseServerRequestCount();

        let localVar = {
				StepOrder_0: ReactSystemFunctions.convertToTypeByName(0, "number"),
				UserId_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.getMyUserId(), "Guid"),
				MusteriAdi_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "leadlisttemp_637785_value", "value", "", "", "")), "string"),
				ProductName_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "leadlisttemp_142164_value", "value", "", "", "")), "string"),
				LeadCode_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "leadlisttemp_962784_value", "value", "", "", "")), "string"),
				Tel_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "leadlisttemp_156403_value", "value", "", "", "")), "string"),
				CategoryName_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "leadlisttemp_735719_value", "value", "TM_GetProductCategory", "categoryCode", "categoryName")), "string"),
				StoreIds_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "leadlisttemp_877174_value", "value", "TM_GetStore", "storeCode", "id")), "string"),
				SatisDanismaniIds_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "leadlisttemp_810709_value", "value", "TM_GetSalesPerson", "kUserId", "kUserId")), "string"),
				ProcessCode_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "leadlisttemp_897080_value", "value", "TM_GetLeadProcess", "id", "code")), "string"),
				StartDate_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "leadlisttemp_471678_value", "value", "", "", "")), "Date"),
				EndDate_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "leadlisttemp_740276_value", "value", "", "", "")), "Date"),
				UserId_1: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.getMyUserId(), "Guid"),
				MusteriAdi_1: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "leadlisttemp_637785_value", "value", "", "", "")), "string"),
				ProductName_1: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "leadlisttemp_142164_value", "value", "", "", "")), "string"),
				LeadCode_1: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "leadlisttemp_962784_value", "value", "", "", "")), "string"),
				Tel_1: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "leadlisttemp_156403_value", "value", "", "", "")), "string"),
				CategoryName_1: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "leadlisttemp_735719_value", "value", "TM_GetProductCategory", "categoryCode", "categoryName")), "string"),
				StoreIds_1: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "leadlisttemp_877174_value", "value", "TM_GetStore", "storeCode", "id")), "string"),
				SatisDanismaniIds_1: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "leadlisttemp_810709_value", "value", "TM_GetSalesPerson", "kUserId", "kUserId")), "string"),
				ProcessCode_1: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "leadlisttemp_897080_value", "value", "TM_GetLeadProcess", "id", "code")), "string"),
				StartDate_1: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "leadlisttemp_471678_value", "value", "", "", "")), "Date"),
				EndDate_1: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "leadlisttemp_740276_value", "value", "", "", "")), "Date")
        }

		KuikaAppManager.showSpinner(this);
		
        if (true) {
        KuikaAppManager.showSpinner(this);
        }
        let result = await KuikaAppManager.ApiRequest(this, "LeadListTemp/LeadListTempComponent_735719_onChange", localVar)
        if (!KMainFunctions.IsResStatus2XX(result)) return true;

			stateVars.TM_GetLeads = result?.data.tM_GetLeads;
			
			stateVars.TM_GetLeadListSummary = result?.data.tM_GetLeadListSummary;
			formVars.leadlisttemp_694879_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadListSummary !== undefined ? (stateVars.TM_GetLeadListSummary?.length > 0 ? stateVars.TM_GetLeadListSummary[0].talepler : null) : (this.state.TM_GetLeadListSummary?.length > 0 ? this.state.TM_GetLeadListSummary[0].talepler : null)));
			formVars.leadlisttemp_961337_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadListSummary !== undefined ? (stateVars.TM_GetLeadListSummary?.length > 0 ? stateVars.TM_GetLeadListSummary[0].olusturulanTalepler : null) : (this.state.TM_GetLeadListSummary?.length > 0 ? this.state.TM_GetLeadListSummary[0].olusturulanTalepler : null)));
			formVars.leadlisttemp_644429_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadListSummary !== undefined ? (stateVars.TM_GetLeadListSummary?.length > 0 ? stateVars.TM_GetLeadListSummary[0].onayBekleyen : null) : (this.state.TM_GetLeadListSummary?.length > 0 ? this.state.TM_GetLeadListSummary[0].onayBekleyen : null)));
			formVars.leadlisttemp_101832_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadListSummary !== undefined ? (stateVars.TM_GetLeadListSummary?.length > 0 ? stateVars.TM_GetLeadListSummary[0].onaylananTalepler : null) : (this.state.TM_GetLeadListSummary?.length > 0 ? this.state.TM_GetLeadListSummary[0].onaylananTalepler : null)));
			formVars.leadlisttemp_941027_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadListSummary !== undefined ? (stateVars.TM_GetLeadListSummary?.length > 0 ? stateVars.TM_GetLeadListSummary[0].rezervOnayBekleyen : null) : (this.state.TM_GetLeadListSummary?.length > 0 ? this.state.TM_GetLeadListSummary[0].rezervOnayBekleyen : null)));
			formVars.leadlisttemp_606021_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadListSummary !== undefined ? (stateVars.TM_GetLeadListSummary?.length > 0 ? stateVars.TM_GetLeadListSummary[0].satisBekleyen : null) : (this.state.TM_GetLeadListSummary?.length > 0 ? this.state.TM_GetLeadListSummary[0].satisBekleyen : null)));
			formVars.leadlisttemp_599705_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadListSummary !== undefined ? (stateVars.TM_GetLeadListSummary?.length > 0 ? stateVars.TM_GetLeadListSummary[0].satisiYapilan : null) : (this.state.TM_GetLeadListSummary?.length > 0 ? this.state.TM_GetLeadListSummary[0].satisiYapilan : null)));
			formVars.leadlisttemp_585643_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadListSummary !== undefined ? (stateVars.TM_GetLeadListSummary?.length > 0 ? stateVars.TM_GetLeadListSummary[0].reddedilenKapatilanToplam : null) : (this.state.TM_GetLeadListSummary?.length > 0 ? this.state.TM_GetLeadListSummary[0].reddedilenKapatilanToplam : null)));
			formVars.leadlisttemp_604493_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadListSummary !== undefined ? (stateVars.TM_GetLeadListSummary?.length > 0 ? stateVars.TM_GetLeadListSummary[0].musteriIstemedi : null) : (this.state.TM_GetLeadListSummary?.length > 0 ? this.state.TM_GetLeadListSummary[0].musteriIstemedi : null)));
			this.props.form?.setFieldsValue(formVars);
			
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.LeadListTempComponent_735719_onChange1_();
                  resolve();
                });
          })



        
        KuikaAppManager.hideSpinner(this);
        return isErrorOccurred;
    }
		LeadListTempComponent_735719_onChange1_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }

				formVars.leadlisttemp_694879_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadListSummary !== undefined ? (stateVars.TM_GetLeadListSummary?.length > 0 ? stateVars.TM_GetLeadListSummary[0].talepler : null) : (this.state.TM_GetLeadListSummary?.length > 0 ? this.state.TM_GetLeadListSummary[0].talepler : null)));

				formVars.leadlisttemp_961337_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadListSummary !== undefined ? (stateVars.TM_GetLeadListSummary?.length > 0 ? stateVars.TM_GetLeadListSummary[0].olusturulanTalepler : null) : (this.state.TM_GetLeadListSummary?.length > 0 ? this.state.TM_GetLeadListSummary[0].olusturulanTalepler : null)));

				formVars.leadlisttemp_644429_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadListSummary !== undefined ? (stateVars.TM_GetLeadListSummary?.length > 0 ? stateVars.TM_GetLeadListSummary[0].onayBekleyen : null) : (this.state.TM_GetLeadListSummary?.length > 0 ? this.state.TM_GetLeadListSummary[0].onayBekleyen : null)));

				formVars.leadlisttemp_101832_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadListSummary !== undefined ? (stateVars.TM_GetLeadListSummary?.length > 0 ? stateVars.TM_GetLeadListSummary[0].onaylananTalepler : null) : (this.state.TM_GetLeadListSummary?.length > 0 ? this.state.TM_GetLeadListSummary[0].onaylananTalepler : null)));

				formVars.leadlisttemp_941027_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadListSummary !== undefined ? (stateVars.TM_GetLeadListSummary?.length > 0 ? stateVars.TM_GetLeadListSummary[0].rezervOnayBekleyen : null) : (this.state.TM_GetLeadListSummary?.length > 0 ? this.state.TM_GetLeadListSummary[0].rezervOnayBekleyen : null)));

				formVars.leadlisttemp_606021_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadListSummary !== undefined ? (stateVars.TM_GetLeadListSummary?.length > 0 ? stateVars.TM_GetLeadListSummary[0].satisBekleyen : null) : (this.state.TM_GetLeadListSummary?.length > 0 ? this.state.TM_GetLeadListSummary[0].satisBekleyen : null)));

				formVars.leadlisttemp_599705_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadListSummary !== undefined ? (stateVars.TM_GetLeadListSummary?.length > 0 ? stateVars.TM_GetLeadListSummary[0].satisiYapilan : null) : (this.state.TM_GetLeadListSummary?.length > 0 ? this.state.TM_GetLeadListSummary[0].satisiYapilan : null)));

				formVars.leadlisttemp_585643_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadListSummary !== undefined ? (stateVars.TM_GetLeadListSummary?.length > 0 ? stateVars.TM_GetLeadListSummary[0].reddedilenKapatilanToplam : null) : (this.state.TM_GetLeadListSummary?.length > 0 ? this.state.TM_GetLeadListSummary[0].reddedilenKapatilanToplam : null)));

				formVars.leadlisttemp_604493_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadListSummary !== undefined ? (stateVars.TM_GetLeadListSummary?.length > 0 ? stateVars.TM_GetLeadListSummary[0].musteriIstemedi : null) : (this.state.TM_GetLeadListSummary?.length > 0 ? this.state.TM_GetLeadListSummary[0].musteriIstemedi : null)));

				
				stateVars.dataSource_627891 = stateVars.TM_GetLeads ?? this.state.TM_GetLeads;

		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

            
            return isErrorOccurred;
        }




    LeadListTempComponent_877174_onChange = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
		KuikaAppManager.increaseServerRequestCount();

        let localVar = {
				StepOrder_0: ReactSystemFunctions.convertToTypeByName(0, "number"),
				UserId_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.getMyUserId(), "Guid"),
				MusteriAdi_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "leadlisttemp_637785_value", "value", "", "", "")), "string"),
				ProductName_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "leadlisttemp_142164_value", "value", "", "", "")), "string"),
				LeadCode_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "leadlisttemp_962784_value", "value", "", "", "")), "string"),
				Tel_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "leadlisttemp_156403_value", "value", "", "", "")), "string"),
				CategoryName_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "leadlisttemp_735719_value", "value", "TM_GetProductCategory", "categoryCode", "categoryName")), "string"),
				StoreIds_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "leadlisttemp_877174_value", "value", "TM_GetStore", "storeCode", "id")), "string"),
				SatisDanismaniIds_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "leadlisttemp_810709_value", "value", "TM_GetSalesPerson", "kUserId", "kUserId")), "string"),
				ProcessCode_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "leadlisttemp_897080_value", "value", "TM_GetLeadProcess", "id", "code")), "string"),
				StartDate_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "leadlisttemp_471678_value", "value", "", "", "")), "Date"),
				EndDate_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "leadlisttemp_740276_value", "value", "", "", "")), "Date"),
				UserId_1: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.getMyUserId(), "Guid"),
				MusteriAdi_1: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "leadlisttemp_637785_value", "value", "", "", "")), "string"),
				ProductName_1: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "leadlisttemp_142164_value", "value", "", "", "")), "string"),
				LeadCode_1: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "leadlisttemp_962784_value", "value", "", "", "")), "string"),
				Tel_1: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "leadlisttemp_156403_value", "value", "", "", "")), "string"),
				CategoryName_1: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "leadlisttemp_735719_value", "value", "TM_GetProductCategory", "categoryCode", "categoryName")), "string"),
				StoreIds_1: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "leadlisttemp_877174_value", "value", "TM_GetStore", "storeCode", "id")), "string"),
				SatisDanismaniIds_1: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "leadlisttemp_810709_value", "value", "TM_GetSalesPerson", "kUserId", "kUserId")), "string"),
				ProcessCode_1: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "leadlisttemp_897080_value", "value", "TM_GetLeadProcess", "id", "code")), "string"),
				StartDate_1: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "leadlisttemp_471678_value", "value", "", "", "")), "Date"),
				EndDate_1: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "leadlisttemp_740276_value", "value", "", "", "")), "Date")
        }

		KuikaAppManager.showSpinner(this);
		
        if (true) {
        KuikaAppManager.showSpinner(this);
        }
        let result = await KuikaAppManager.ApiRequest(this, "LeadListTemp/LeadListTempComponent_877174_onChange", localVar)
        if (!KMainFunctions.IsResStatus2XX(result)) return true;

			stateVars.TM_GetLeads = result?.data.tM_GetLeads;
			
			stateVars.TM_GetLeadListSummary = result?.data.tM_GetLeadListSummary;
			formVars.leadlisttemp_694879_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadListSummary !== undefined ? (stateVars.TM_GetLeadListSummary?.length > 0 ? stateVars.TM_GetLeadListSummary[0].talepler : null) : (this.state.TM_GetLeadListSummary?.length > 0 ? this.state.TM_GetLeadListSummary[0].talepler : null)));
			formVars.leadlisttemp_961337_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadListSummary !== undefined ? (stateVars.TM_GetLeadListSummary?.length > 0 ? stateVars.TM_GetLeadListSummary[0].olusturulanTalepler : null) : (this.state.TM_GetLeadListSummary?.length > 0 ? this.state.TM_GetLeadListSummary[0].olusturulanTalepler : null)));
			formVars.leadlisttemp_644429_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadListSummary !== undefined ? (stateVars.TM_GetLeadListSummary?.length > 0 ? stateVars.TM_GetLeadListSummary[0].onayBekleyen : null) : (this.state.TM_GetLeadListSummary?.length > 0 ? this.state.TM_GetLeadListSummary[0].onayBekleyen : null)));
			formVars.leadlisttemp_101832_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadListSummary !== undefined ? (stateVars.TM_GetLeadListSummary?.length > 0 ? stateVars.TM_GetLeadListSummary[0].onaylananTalepler : null) : (this.state.TM_GetLeadListSummary?.length > 0 ? this.state.TM_GetLeadListSummary[0].onaylananTalepler : null)));
			formVars.leadlisttemp_941027_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadListSummary !== undefined ? (stateVars.TM_GetLeadListSummary?.length > 0 ? stateVars.TM_GetLeadListSummary[0].rezervOnayBekleyen : null) : (this.state.TM_GetLeadListSummary?.length > 0 ? this.state.TM_GetLeadListSummary[0].rezervOnayBekleyen : null)));
			formVars.leadlisttemp_606021_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadListSummary !== undefined ? (stateVars.TM_GetLeadListSummary?.length > 0 ? stateVars.TM_GetLeadListSummary[0].satisBekleyen : null) : (this.state.TM_GetLeadListSummary?.length > 0 ? this.state.TM_GetLeadListSummary[0].satisBekleyen : null)));
			formVars.leadlisttemp_599705_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadListSummary !== undefined ? (stateVars.TM_GetLeadListSummary?.length > 0 ? stateVars.TM_GetLeadListSummary[0].satisiYapilan : null) : (this.state.TM_GetLeadListSummary?.length > 0 ? this.state.TM_GetLeadListSummary[0].satisiYapilan : null)));
			formVars.leadlisttemp_585643_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadListSummary !== undefined ? (stateVars.TM_GetLeadListSummary?.length > 0 ? stateVars.TM_GetLeadListSummary[0].reddedilenKapatilanToplam : null) : (this.state.TM_GetLeadListSummary?.length > 0 ? this.state.TM_GetLeadListSummary[0].reddedilenKapatilanToplam : null)));
			formVars.leadlisttemp_604493_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadListSummary !== undefined ? (stateVars.TM_GetLeadListSummary?.length > 0 ? stateVars.TM_GetLeadListSummary[0].musteriIstemedi : null) : (this.state.TM_GetLeadListSummary?.length > 0 ? this.state.TM_GetLeadListSummary[0].musteriIstemedi : null)));
			this.props.form?.setFieldsValue(formVars);
			
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.LeadListTempComponent_877174_onChange1_();
                  resolve();
                });
          })



        
        KuikaAppManager.hideSpinner(this);
        return isErrorOccurred;
    }
		LeadListTempComponent_877174_onChange1_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }

				formVars.leadlisttemp_694879_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadListSummary !== undefined ? (stateVars.TM_GetLeadListSummary?.length > 0 ? stateVars.TM_GetLeadListSummary[0].talepler : null) : (this.state.TM_GetLeadListSummary?.length > 0 ? this.state.TM_GetLeadListSummary[0].talepler : null)));

				formVars.leadlisttemp_961337_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadListSummary !== undefined ? (stateVars.TM_GetLeadListSummary?.length > 0 ? stateVars.TM_GetLeadListSummary[0].olusturulanTalepler : null) : (this.state.TM_GetLeadListSummary?.length > 0 ? this.state.TM_GetLeadListSummary[0].olusturulanTalepler : null)));

				formVars.leadlisttemp_644429_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadListSummary !== undefined ? (stateVars.TM_GetLeadListSummary?.length > 0 ? stateVars.TM_GetLeadListSummary[0].onayBekleyen : null) : (this.state.TM_GetLeadListSummary?.length > 0 ? this.state.TM_GetLeadListSummary[0].onayBekleyen : null)));

				formVars.leadlisttemp_101832_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadListSummary !== undefined ? (stateVars.TM_GetLeadListSummary?.length > 0 ? stateVars.TM_GetLeadListSummary[0].onaylananTalepler : null) : (this.state.TM_GetLeadListSummary?.length > 0 ? this.state.TM_GetLeadListSummary[0].onaylananTalepler : null)));

				formVars.leadlisttemp_941027_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadListSummary !== undefined ? (stateVars.TM_GetLeadListSummary?.length > 0 ? stateVars.TM_GetLeadListSummary[0].rezervOnayBekleyen : null) : (this.state.TM_GetLeadListSummary?.length > 0 ? this.state.TM_GetLeadListSummary[0].rezervOnayBekleyen : null)));

				formVars.leadlisttemp_606021_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadListSummary !== undefined ? (stateVars.TM_GetLeadListSummary?.length > 0 ? stateVars.TM_GetLeadListSummary[0].satisBekleyen : null) : (this.state.TM_GetLeadListSummary?.length > 0 ? this.state.TM_GetLeadListSummary[0].satisBekleyen : null)));

				formVars.leadlisttemp_599705_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadListSummary !== undefined ? (stateVars.TM_GetLeadListSummary?.length > 0 ? stateVars.TM_GetLeadListSummary[0].satisiYapilan : null) : (this.state.TM_GetLeadListSummary?.length > 0 ? this.state.TM_GetLeadListSummary[0].satisiYapilan : null)));

				formVars.leadlisttemp_585643_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadListSummary !== undefined ? (stateVars.TM_GetLeadListSummary?.length > 0 ? stateVars.TM_GetLeadListSummary[0].reddedilenKapatilanToplam : null) : (this.state.TM_GetLeadListSummary?.length > 0 ? this.state.TM_GetLeadListSummary[0].reddedilenKapatilanToplam : null)));

				formVars.leadlisttemp_604493_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadListSummary !== undefined ? (stateVars.TM_GetLeadListSummary?.length > 0 ? stateVars.TM_GetLeadListSummary[0].musteriIstemedi : null) : (this.state.TM_GetLeadListSummary?.length > 0 ? this.state.TM_GetLeadListSummary[0].musteriIstemedi : null)));

				
				stateVars.dataSource_627891 = stateVars.TM_GetLeads ?? this.state.TM_GetLeads;

		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

            
            return isErrorOccurred;
        }




    LeadListTempComponent_810709_onChange = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
		KuikaAppManager.increaseServerRequestCount();

        let localVar = {
				StepOrder_0: ReactSystemFunctions.convertToTypeByName(0, "number"),
				UserId_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.getMyUserId(), "Guid"),
				MusteriAdi_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "leadlisttemp_637785_value", "value", "", "", "")), "string"),
				ProductName_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "leadlisttemp_142164_value", "value", "", "", "")), "string"),
				LeadCode_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "leadlisttemp_962784_value", "value", "", "", "")), "string"),
				Tel_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "leadlisttemp_156403_value", "value", "", "", "")), "string"),
				CategoryName_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "leadlisttemp_735719_value", "value", "TM_GetProductCategory", "categoryCode", "categoryName")), "string"),
				StoreIds_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "leadlisttemp_877174_value", "value", "TM_GetStore", "storeCode", "id")), "string"),
				SatisDanismaniIds_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "leadlisttemp_810709_value", "value", "TM_GetSalesPerson", "kUserId", "kUserId")), "string"),
				ProcessCode_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "leadlisttemp_897080_value", "value", "TM_GetLeadProcess", "id", "code")), "string"),
				StartDate_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "leadlisttemp_471678_value", "value", "", "", "")), "Date"),
				EndDate_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "leadlisttemp_740276_value", "value", "", "", "")), "Date"),
				UserId_1: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.getMyUserId(), "Guid"),
				MusteriAdi_1: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "leadlisttemp_637785_value", "value", "", "", "")), "string"),
				ProductName_1: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "leadlisttemp_142164_value", "value", "", "", "")), "string"),
				LeadCode_1: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "leadlisttemp_962784_value", "value", "", "", "")), "string"),
				Tel_1: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "leadlisttemp_156403_value", "value", "", "", "")), "string"),
				CategoryName_1: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "leadlisttemp_735719_value", "value", "TM_GetProductCategory", "categoryCode", "categoryName")), "string"),
				StoreIds_1: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "leadlisttemp_877174_value", "value", "TM_GetStore", "storeCode", "id")), "string"),
				SatisDanismaniIds_1: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "leadlisttemp_810709_value", "value", "TM_GetSalesPerson", "kUserId", "kUserId")), "string"),
				ProcessCode_1: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "leadlisttemp_897080_value", "value", "TM_GetLeadProcess", "id", "code")), "string"),
				StartDate_1: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "leadlisttemp_471678_value", "value", "", "", "")), "Date"),
				EndDate_1: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "leadlisttemp_740276_value", "value", "", "", "")), "Date")
        }

		KuikaAppManager.showSpinner(this);
		
        if (true) {
        KuikaAppManager.showSpinner(this);
        }
        let result = await KuikaAppManager.ApiRequest(this, "LeadListTemp/LeadListTempComponent_810709_onChange", localVar)
        if (!KMainFunctions.IsResStatus2XX(result)) return true;

			stateVars.TM_GetLeads = result?.data.tM_GetLeads;
			
			stateVars.TM_GetLeadListSummary = result?.data.tM_GetLeadListSummary;
			formVars.leadlisttemp_694879_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadListSummary !== undefined ? (stateVars.TM_GetLeadListSummary?.length > 0 ? stateVars.TM_GetLeadListSummary[0].talepler : null) : (this.state.TM_GetLeadListSummary?.length > 0 ? this.state.TM_GetLeadListSummary[0].talepler : null)));
			formVars.leadlisttemp_961337_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadListSummary !== undefined ? (stateVars.TM_GetLeadListSummary?.length > 0 ? stateVars.TM_GetLeadListSummary[0].olusturulanTalepler : null) : (this.state.TM_GetLeadListSummary?.length > 0 ? this.state.TM_GetLeadListSummary[0].olusturulanTalepler : null)));
			formVars.leadlisttemp_644429_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadListSummary !== undefined ? (stateVars.TM_GetLeadListSummary?.length > 0 ? stateVars.TM_GetLeadListSummary[0].onayBekleyen : null) : (this.state.TM_GetLeadListSummary?.length > 0 ? this.state.TM_GetLeadListSummary[0].onayBekleyen : null)));
			formVars.leadlisttemp_101832_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadListSummary !== undefined ? (stateVars.TM_GetLeadListSummary?.length > 0 ? stateVars.TM_GetLeadListSummary[0].onaylananTalepler : null) : (this.state.TM_GetLeadListSummary?.length > 0 ? this.state.TM_GetLeadListSummary[0].onaylananTalepler : null)));
			formVars.leadlisttemp_941027_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadListSummary !== undefined ? (stateVars.TM_GetLeadListSummary?.length > 0 ? stateVars.TM_GetLeadListSummary[0].rezervOnayBekleyen : null) : (this.state.TM_GetLeadListSummary?.length > 0 ? this.state.TM_GetLeadListSummary[0].rezervOnayBekleyen : null)));
			formVars.leadlisttemp_606021_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadListSummary !== undefined ? (stateVars.TM_GetLeadListSummary?.length > 0 ? stateVars.TM_GetLeadListSummary[0].satisBekleyen : null) : (this.state.TM_GetLeadListSummary?.length > 0 ? this.state.TM_GetLeadListSummary[0].satisBekleyen : null)));
			formVars.leadlisttemp_599705_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadListSummary !== undefined ? (stateVars.TM_GetLeadListSummary?.length > 0 ? stateVars.TM_GetLeadListSummary[0].satisiYapilan : null) : (this.state.TM_GetLeadListSummary?.length > 0 ? this.state.TM_GetLeadListSummary[0].satisiYapilan : null)));
			formVars.leadlisttemp_585643_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadListSummary !== undefined ? (stateVars.TM_GetLeadListSummary?.length > 0 ? stateVars.TM_GetLeadListSummary[0].reddedilenKapatilanToplam : null) : (this.state.TM_GetLeadListSummary?.length > 0 ? this.state.TM_GetLeadListSummary[0].reddedilenKapatilanToplam : null)));
			formVars.leadlisttemp_604493_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadListSummary !== undefined ? (stateVars.TM_GetLeadListSummary?.length > 0 ? stateVars.TM_GetLeadListSummary[0].musteriIstemedi : null) : (this.state.TM_GetLeadListSummary?.length > 0 ? this.state.TM_GetLeadListSummary[0].musteriIstemedi : null)));
			this.props.form?.setFieldsValue(formVars);
			
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.LeadListTempComponent_810709_onChange1_();
                  resolve();
                });
          })



        
        KuikaAppManager.hideSpinner(this);
        return isErrorOccurred;
    }
		LeadListTempComponent_810709_onChange1_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }

				formVars.leadlisttemp_694879_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadListSummary !== undefined ? (stateVars.TM_GetLeadListSummary?.length > 0 ? stateVars.TM_GetLeadListSummary[0].talepler : null) : (this.state.TM_GetLeadListSummary?.length > 0 ? this.state.TM_GetLeadListSummary[0].talepler : null)));

				formVars.leadlisttemp_961337_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadListSummary !== undefined ? (stateVars.TM_GetLeadListSummary?.length > 0 ? stateVars.TM_GetLeadListSummary[0].olusturulanTalepler : null) : (this.state.TM_GetLeadListSummary?.length > 0 ? this.state.TM_GetLeadListSummary[0].olusturulanTalepler : null)));

				formVars.leadlisttemp_644429_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadListSummary !== undefined ? (stateVars.TM_GetLeadListSummary?.length > 0 ? stateVars.TM_GetLeadListSummary[0].onayBekleyen : null) : (this.state.TM_GetLeadListSummary?.length > 0 ? this.state.TM_GetLeadListSummary[0].onayBekleyen : null)));

				formVars.leadlisttemp_101832_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadListSummary !== undefined ? (stateVars.TM_GetLeadListSummary?.length > 0 ? stateVars.TM_GetLeadListSummary[0].onaylananTalepler : null) : (this.state.TM_GetLeadListSummary?.length > 0 ? this.state.TM_GetLeadListSummary[0].onaylananTalepler : null)));

				formVars.leadlisttemp_941027_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadListSummary !== undefined ? (stateVars.TM_GetLeadListSummary?.length > 0 ? stateVars.TM_GetLeadListSummary[0].rezervOnayBekleyen : null) : (this.state.TM_GetLeadListSummary?.length > 0 ? this.state.TM_GetLeadListSummary[0].rezervOnayBekleyen : null)));

				formVars.leadlisttemp_606021_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadListSummary !== undefined ? (stateVars.TM_GetLeadListSummary?.length > 0 ? stateVars.TM_GetLeadListSummary[0].satisBekleyen : null) : (this.state.TM_GetLeadListSummary?.length > 0 ? this.state.TM_GetLeadListSummary[0].satisBekleyen : null)));

				formVars.leadlisttemp_599705_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadListSummary !== undefined ? (stateVars.TM_GetLeadListSummary?.length > 0 ? stateVars.TM_GetLeadListSummary[0].satisiYapilan : null) : (this.state.TM_GetLeadListSummary?.length > 0 ? this.state.TM_GetLeadListSummary[0].satisiYapilan : null)));

				formVars.leadlisttemp_585643_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadListSummary !== undefined ? (stateVars.TM_GetLeadListSummary?.length > 0 ? stateVars.TM_GetLeadListSummary[0].reddedilenKapatilanToplam : null) : (this.state.TM_GetLeadListSummary?.length > 0 ? this.state.TM_GetLeadListSummary[0].reddedilenKapatilanToplam : null)));

				formVars.leadlisttemp_604493_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadListSummary !== undefined ? (stateVars.TM_GetLeadListSummary?.length > 0 ? stateVars.TM_GetLeadListSummary[0].musteriIstemedi : null) : (this.state.TM_GetLeadListSummary?.length > 0 ? this.state.TM_GetLeadListSummary[0].musteriIstemedi : null)));

				
				stateVars.dataSource_627891 = stateVars.TM_GetLeads ?? this.state.TM_GetLeads;

		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

            
            return isErrorOccurred;
        }




    LeadListTempComponent_897080_onChange = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
		KuikaAppManager.increaseServerRequestCount();

        let localVar = {
				StepOrder_0: ReactSystemFunctions.convertToTypeByName(0, "number"),
				UserId_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.getMyUserId(), "Guid"),
				MusteriAdi_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "leadlisttemp_637785_value", "value", "", "", "")), "string"),
				ProductName_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "leadlisttemp_142164_value", "value", "", "", "")), "string"),
				LeadCode_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "leadlisttemp_962784_value", "value", "", "", "")), "string"),
				Tel_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "leadlisttemp_156403_value", "value", "", "", "")), "string"),
				CategoryName_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "leadlisttemp_735719_value", "value", "TM_GetProductCategory", "categoryCode", "categoryName")), "string"),
				StoreIds_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "leadlisttemp_877174_value", "value", "TM_GetStore", "storeCode", "id")), "string"),
				SatisDanismaniIds_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "leadlisttemp_810709_value", "value", "TM_GetSalesPerson", "kUserId", "kUserId")), "string"),
				ProcessCode_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "leadlisttemp_897080_value", "value", "TM_GetLeadProcess", "id", "code")), "string"),
				StartDate_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "leadlisttemp_471678_value", "value", "", "", "")), "Date"),
				EndDate_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "leadlisttemp_740276_value", "value", "", "", "")), "Date"),
				UserId_1: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.getMyUserId(), "Guid"),
				MusteriAdi_1: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "leadlisttemp_637785_value", "value", "", "", "")), "string"),
				ProductName_1: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "leadlisttemp_142164_value", "value", "", "", "")), "string"),
				LeadCode_1: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "leadlisttemp_962784_value", "value", "", "", "")), "string"),
				Tel_1: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "leadlisttemp_156403_value", "value", "", "", "")), "string"),
				CategoryName_1: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "leadlisttemp_735719_value", "value", "TM_GetProductCategory", "categoryCode", "categoryName")), "string"),
				StoreIds_1: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "leadlisttemp_877174_value", "value", "TM_GetStore", "storeCode", "id")), "string"),
				SatisDanismaniIds_1: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "leadlisttemp_810709_value", "value", "TM_GetSalesPerson", "kUserId", "kUserId")), "string"),
				ProcessCode_1: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "leadlisttemp_897080_value", "value", "TM_GetLeadProcess", "id", "code")), "string"),
				StartDate_1: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "leadlisttemp_471678_value", "value", "", "", "")), "Date"),
				EndDate_1: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "leadlisttemp_740276_value", "value", "", "", "")), "Date")
        }

		KuikaAppManager.showSpinner(this);
		
        if (true) {
        KuikaAppManager.showSpinner(this);
        }
        let result = await KuikaAppManager.ApiRequest(this, "LeadListTemp/LeadListTempComponent_897080_onChange", localVar)
        if (!KMainFunctions.IsResStatus2XX(result)) return true;

			stateVars.TM_GetLeads = result?.data.tM_GetLeads;
			
			stateVars.TM_GetLeadListSummary = result?.data.tM_GetLeadListSummary;
			formVars.leadlisttemp_694879_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadListSummary !== undefined ? (stateVars.TM_GetLeadListSummary?.length > 0 ? stateVars.TM_GetLeadListSummary[0].talepler : null) : (this.state.TM_GetLeadListSummary?.length > 0 ? this.state.TM_GetLeadListSummary[0].talepler : null)));
			formVars.leadlisttemp_961337_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadListSummary !== undefined ? (stateVars.TM_GetLeadListSummary?.length > 0 ? stateVars.TM_GetLeadListSummary[0].olusturulanTalepler : null) : (this.state.TM_GetLeadListSummary?.length > 0 ? this.state.TM_GetLeadListSummary[0].olusturulanTalepler : null)));
			formVars.leadlisttemp_644429_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadListSummary !== undefined ? (stateVars.TM_GetLeadListSummary?.length > 0 ? stateVars.TM_GetLeadListSummary[0].onayBekleyen : null) : (this.state.TM_GetLeadListSummary?.length > 0 ? this.state.TM_GetLeadListSummary[0].onayBekleyen : null)));
			formVars.leadlisttemp_101832_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadListSummary !== undefined ? (stateVars.TM_GetLeadListSummary?.length > 0 ? stateVars.TM_GetLeadListSummary[0].onaylananTalepler : null) : (this.state.TM_GetLeadListSummary?.length > 0 ? this.state.TM_GetLeadListSummary[0].onaylananTalepler : null)));
			formVars.leadlisttemp_941027_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadListSummary !== undefined ? (stateVars.TM_GetLeadListSummary?.length > 0 ? stateVars.TM_GetLeadListSummary[0].rezervOnayBekleyen : null) : (this.state.TM_GetLeadListSummary?.length > 0 ? this.state.TM_GetLeadListSummary[0].rezervOnayBekleyen : null)));
			formVars.leadlisttemp_606021_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadListSummary !== undefined ? (stateVars.TM_GetLeadListSummary?.length > 0 ? stateVars.TM_GetLeadListSummary[0].satisBekleyen : null) : (this.state.TM_GetLeadListSummary?.length > 0 ? this.state.TM_GetLeadListSummary[0].satisBekleyen : null)));
			formVars.leadlisttemp_599705_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadListSummary !== undefined ? (stateVars.TM_GetLeadListSummary?.length > 0 ? stateVars.TM_GetLeadListSummary[0].satisiYapilan : null) : (this.state.TM_GetLeadListSummary?.length > 0 ? this.state.TM_GetLeadListSummary[0].satisiYapilan : null)));
			formVars.leadlisttemp_585643_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadListSummary !== undefined ? (stateVars.TM_GetLeadListSummary?.length > 0 ? stateVars.TM_GetLeadListSummary[0].reddedilenKapatilanToplam : null) : (this.state.TM_GetLeadListSummary?.length > 0 ? this.state.TM_GetLeadListSummary[0].reddedilenKapatilanToplam : null)));
			formVars.leadlisttemp_604493_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadListSummary !== undefined ? (stateVars.TM_GetLeadListSummary?.length > 0 ? stateVars.TM_GetLeadListSummary[0].musteriIstemedi : null) : (this.state.TM_GetLeadListSummary?.length > 0 ? this.state.TM_GetLeadListSummary[0].musteriIstemedi : null)));
			this.props.form?.setFieldsValue(formVars);
			
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.LeadListTempComponent_897080_onChange1_();
                  resolve();
                });
          })



        
        KuikaAppManager.hideSpinner(this);
        return isErrorOccurred;
    }
		LeadListTempComponent_897080_onChange1_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }

				formVars.leadlisttemp_694879_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadListSummary !== undefined ? (stateVars.TM_GetLeadListSummary?.length > 0 ? stateVars.TM_GetLeadListSummary[0].talepler : null) : (this.state.TM_GetLeadListSummary?.length > 0 ? this.state.TM_GetLeadListSummary[0].talepler : null)));

				formVars.leadlisttemp_961337_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadListSummary !== undefined ? (stateVars.TM_GetLeadListSummary?.length > 0 ? stateVars.TM_GetLeadListSummary[0].olusturulanTalepler : null) : (this.state.TM_GetLeadListSummary?.length > 0 ? this.state.TM_GetLeadListSummary[0].olusturulanTalepler : null)));

				formVars.leadlisttemp_644429_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadListSummary !== undefined ? (stateVars.TM_GetLeadListSummary?.length > 0 ? stateVars.TM_GetLeadListSummary[0].onayBekleyen : null) : (this.state.TM_GetLeadListSummary?.length > 0 ? this.state.TM_GetLeadListSummary[0].onayBekleyen : null)));

				formVars.leadlisttemp_101832_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadListSummary !== undefined ? (stateVars.TM_GetLeadListSummary?.length > 0 ? stateVars.TM_GetLeadListSummary[0].onaylananTalepler : null) : (this.state.TM_GetLeadListSummary?.length > 0 ? this.state.TM_GetLeadListSummary[0].onaylananTalepler : null)));

				formVars.leadlisttemp_941027_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadListSummary !== undefined ? (stateVars.TM_GetLeadListSummary?.length > 0 ? stateVars.TM_GetLeadListSummary[0].rezervOnayBekleyen : null) : (this.state.TM_GetLeadListSummary?.length > 0 ? this.state.TM_GetLeadListSummary[0].rezervOnayBekleyen : null)));

				formVars.leadlisttemp_606021_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadListSummary !== undefined ? (stateVars.TM_GetLeadListSummary?.length > 0 ? stateVars.TM_GetLeadListSummary[0].satisBekleyen : null) : (this.state.TM_GetLeadListSummary?.length > 0 ? this.state.TM_GetLeadListSummary[0].satisBekleyen : null)));

				formVars.leadlisttemp_599705_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadListSummary !== undefined ? (stateVars.TM_GetLeadListSummary?.length > 0 ? stateVars.TM_GetLeadListSummary[0].satisiYapilan : null) : (this.state.TM_GetLeadListSummary?.length > 0 ? this.state.TM_GetLeadListSummary[0].satisiYapilan : null)));

				formVars.leadlisttemp_585643_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadListSummary !== undefined ? (stateVars.TM_GetLeadListSummary?.length > 0 ? stateVars.TM_GetLeadListSummary[0].reddedilenKapatilanToplam : null) : (this.state.TM_GetLeadListSummary?.length > 0 ? this.state.TM_GetLeadListSummary[0].reddedilenKapatilanToplam : null)));

				formVars.leadlisttemp_604493_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadListSummary !== undefined ? (stateVars.TM_GetLeadListSummary?.length > 0 ? stateVars.TM_GetLeadListSummary[0].musteriIstemedi : null) : (this.state.TM_GetLeadListSummary?.length > 0 ? this.state.TM_GetLeadListSummary[0].musteriIstemedi : null)));

				
				stateVars.dataSource_627891 = stateVars.TM_GetLeads ?? this.state.TM_GetLeads;

		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

            
            return isErrorOccurred;
        }




    LeadListTempComponent_471678_onChange = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
		KuikaAppManager.increaseServerRequestCount();

        let localVar = {
				StepOrder_0: ReactSystemFunctions.convertToTypeByName(0, "number"),
				UserId_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.getMyUserId(), "Guid"),
				MusteriAdi_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "leadlisttemp_637785_value", "value", "", "", "")), "string"),
				ProductName_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "leadlisttemp_142164_value", "value", "", "", "")), "string"),
				LeadCode_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "leadlisttemp_962784_value", "value", "", "", "")), "string"),
				Tel_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "leadlisttemp_156403_value", "value", "", "", "")), "string"),
				CategoryName_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "leadlisttemp_735719_value", "value", "TM_GetProductCategory", "categoryCode", "categoryName")), "string"),
				StoreIds_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "leadlisttemp_877174_value", "value", "TM_GetStore", "storeCode", "id")), "string"),
				SatisDanismaniIds_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "leadlisttemp_810709_value", "value", "TM_GetSalesPerson", "kUserId", "kUserId")), "string"),
				ProcessCode_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "leadlisttemp_897080_value", "value", "TM_GetLeadProcess", "id", "code")), "string"),
				StartDate_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "leadlisttemp_471678_value", "value", "", "", "")), "Date"),
				EndDate_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "leadlisttemp_740276_value", "value", "", "", "")), "Date"),
				UserId_1: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.getMyUserId(), "Guid"),
				MusteriAdi_1: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "leadlisttemp_637785_value", "value", "", "", "")), "string"),
				ProductName_1: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "leadlisttemp_142164_value", "value", "", "", "")), "string"),
				LeadCode_1: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "leadlisttemp_962784_value", "value", "", "", "")), "string"),
				Tel_1: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "leadlisttemp_156403_value", "value", "", "", "")), "string"),
				CategoryName_1: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "leadlisttemp_735719_value", "value", "TM_GetProductCategory", "categoryCode", "categoryName")), "string"),
				StoreIds_1: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "leadlisttemp_877174_value", "value", "TM_GetStore", "storeCode", "id")), "string"),
				SatisDanismaniIds_1: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "leadlisttemp_810709_value", "value", "TM_GetSalesPerson", "kUserId", "kUserId")), "string"),
				ProcessCode_1: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "leadlisttemp_897080_value", "value", "TM_GetLeadProcess", "id", "code")), "string"),
				StartDate_1: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "leadlisttemp_471678_value", "value", "", "", "")), "Date"),
				EndDate_1: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "leadlisttemp_740276_value", "value", "", "", "")), "Date")
        }

		KuikaAppManager.showSpinner(this);
		
        if (true) {
        KuikaAppManager.showSpinner(this);
        }
        let result = await KuikaAppManager.ApiRequest(this, "LeadListTemp/LeadListTempComponent_471678_onChange", localVar)
        if (!KMainFunctions.IsResStatus2XX(result)) return true;

			stateVars.TM_GetLeads = result?.data.tM_GetLeads;
			
			stateVars.TM_GetLeadListSummary = result?.data.tM_GetLeadListSummary;
			formVars.leadlisttemp_694879_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadListSummary !== undefined ? (stateVars.TM_GetLeadListSummary?.length > 0 ? stateVars.TM_GetLeadListSummary[0].talepler : null) : (this.state.TM_GetLeadListSummary?.length > 0 ? this.state.TM_GetLeadListSummary[0].talepler : null)));
			formVars.leadlisttemp_961337_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadListSummary !== undefined ? (stateVars.TM_GetLeadListSummary?.length > 0 ? stateVars.TM_GetLeadListSummary[0].olusturulanTalepler : null) : (this.state.TM_GetLeadListSummary?.length > 0 ? this.state.TM_GetLeadListSummary[0].olusturulanTalepler : null)));
			formVars.leadlisttemp_644429_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadListSummary !== undefined ? (stateVars.TM_GetLeadListSummary?.length > 0 ? stateVars.TM_GetLeadListSummary[0].onayBekleyen : null) : (this.state.TM_GetLeadListSummary?.length > 0 ? this.state.TM_GetLeadListSummary[0].onayBekleyen : null)));
			formVars.leadlisttemp_101832_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadListSummary !== undefined ? (stateVars.TM_GetLeadListSummary?.length > 0 ? stateVars.TM_GetLeadListSummary[0].onaylananTalepler : null) : (this.state.TM_GetLeadListSummary?.length > 0 ? this.state.TM_GetLeadListSummary[0].onaylananTalepler : null)));
			formVars.leadlisttemp_941027_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadListSummary !== undefined ? (stateVars.TM_GetLeadListSummary?.length > 0 ? stateVars.TM_GetLeadListSummary[0].rezervOnayBekleyen : null) : (this.state.TM_GetLeadListSummary?.length > 0 ? this.state.TM_GetLeadListSummary[0].rezervOnayBekleyen : null)));
			formVars.leadlisttemp_606021_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadListSummary !== undefined ? (stateVars.TM_GetLeadListSummary?.length > 0 ? stateVars.TM_GetLeadListSummary[0].satisBekleyen : null) : (this.state.TM_GetLeadListSummary?.length > 0 ? this.state.TM_GetLeadListSummary[0].satisBekleyen : null)));
			formVars.leadlisttemp_599705_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadListSummary !== undefined ? (stateVars.TM_GetLeadListSummary?.length > 0 ? stateVars.TM_GetLeadListSummary[0].satisiYapilan : null) : (this.state.TM_GetLeadListSummary?.length > 0 ? this.state.TM_GetLeadListSummary[0].satisiYapilan : null)));
			formVars.leadlisttemp_585643_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadListSummary !== undefined ? (stateVars.TM_GetLeadListSummary?.length > 0 ? stateVars.TM_GetLeadListSummary[0].reddedilenKapatilanToplam : null) : (this.state.TM_GetLeadListSummary?.length > 0 ? this.state.TM_GetLeadListSummary[0].reddedilenKapatilanToplam : null)));
			formVars.leadlisttemp_604493_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadListSummary !== undefined ? (stateVars.TM_GetLeadListSummary?.length > 0 ? stateVars.TM_GetLeadListSummary[0].musteriIstemedi : null) : (this.state.TM_GetLeadListSummary?.length > 0 ? this.state.TM_GetLeadListSummary[0].musteriIstemedi : null)));
			this.props.form?.setFieldsValue(formVars);
			
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.LeadListTempComponent_471678_onChange1_();
                  resolve();
                });
          })



        
        KuikaAppManager.hideSpinner(this);
        return isErrorOccurred;
    }
		LeadListTempComponent_471678_onChange1_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }

				formVars.leadlisttemp_694879_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadListSummary !== undefined ? (stateVars.TM_GetLeadListSummary?.length > 0 ? stateVars.TM_GetLeadListSummary[0].talepler : null) : (this.state.TM_GetLeadListSummary?.length > 0 ? this.state.TM_GetLeadListSummary[0].talepler : null)));

				formVars.leadlisttemp_961337_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadListSummary !== undefined ? (stateVars.TM_GetLeadListSummary?.length > 0 ? stateVars.TM_GetLeadListSummary[0].olusturulanTalepler : null) : (this.state.TM_GetLeadListSummary?.length > 0 ? this.state.TM_GetLeadListSummary[0].olusturulanTalepler : null)));

				formVars.leadlisttemp_644429_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadListSummary !== undefined ? (stateVars.TM_GetLeadListSummary?.length > 0 ? stateVars.TM_GetLeadListSummary[0].onayBekleyen : null) : (this.state.TM_GetLeadListSummary?.length > 0 ? this.state.TM_GetLeadListSummary[0].onayBekleyen : null)));

				formVars.leadlisttemp_101832_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadListSummary !== undefined ? (stateVars.TM_GetLeadListSummary?.length > 0 ? stateVars.TM_GetLeadListSummary[0].onaylananTalepler : null) : (this.state.TM_GetLeadListSummary?.length > 0 ? this.state.TM_GetLeadListSummary[0].onaylananTalepler : null)));

				formVars.leadlisttemp_941027_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadListSummary !== undefined ? (stateVars.TM_GetLeadListSummary?.length > 0 ? stateVars.TM_GetLeadListSummary[0].rezervOnayBekleyen : null) : (this.state.TM_GetLeadListSummary?.length > 0 ? this.state.TM_GetLeadListSummary[0].rezervOnayBekleyen : null)));

				formVars.leadlisttemp_606021_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadListSummary !== undefined ? (stateVars.TM_GetLeadListSummary?.length > 0 ? stateVars.TM_GetLeadListSummary[0].satisBekleyen : null) : (this.state.TM_GetLeadListSummary?.length > 0 ? this.state.TM_GetLeadListSummary[0].satisBekleyen : null)));

				formVars.leadlisttemp_599705_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadListSummary !== undefined ? (stateVars.TM_GetLeadListSummary?.length > 0 ? stateVars.TM_GetLeadListSummary[0].satisiYapilan : null) : (this.state.TM_GetLeadListSummary?.length > 0 ? this.state.TM_GetLeadListSummary[0].satisiYapilan : null)));

				formVars.leadlisttemp_585643_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadListSummary !== undefined ? (stateVars.TM_GetLeadListSummary?.length > 0 ? stateVars.TM_GetLeadListSummary[0].reddedilenKapatilanToplam : null) : (this.state.TM_GetLeadListSummary?.length > 0 ? this.state.TM_GetLeadListSummary[0].reddedilenKapatilanToplam : null)));

				formVars.leadlisttemp_604493_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadListSummary !== undefined ? (stateVars.TM_GetLeadListSummary?.length > 0 ? stateVars.TM_GetLeadListSummary[0].musteriIstemedi : null) : (this.state.TM_GetLeadListSummary?.length > 0 ? this.state.TM_GetLeadListSummary[0].musteriIstemedi : null)));

				
				stateVars.dataSource_627891 = stateVars.TM_GetLeads ?? this.state.TM_GetLeads;

		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

            
            return isErrorOccurred;
        }




    LeadListTempComponent_740276_onChange = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
		KuikaAppManager.increaseServerRequestCount();

        let localVar = {
				StepOrder_0: ReactSystemFunctions.convertToTypeByName(0, "number"),
				UserId_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.getMyUserId(), "Guid"),
				MusteriAdi_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "leadlisttemp_637785_value", "value", "", "", "")), "string"),
				ProductName_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "leadlisttemp_142164_value", "value", "", "", "")), "string"),
				LeadCode_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "leadlisttemp_962784_value", "value", "", "", "")), "string"),
				Tel_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "leadlisttemp_156403_value", "value", "", "", "")), "string"),
				CategoryName_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "leadlisttemp_735719_value", "value", "TM_GetProductCategory", "categoryCode", "categoryName")), "string"),
				StoreIds_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "leadlisttemp_877174_value", "value", "TM_GetStore", "storeCode", "id")), "string"),
				SatisDanismaniIds_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "leadlisttemp_810709_value", "value", "TM_GetSalesPerson", "kUserId", "kUserId")), "string"),
				ProcessCode_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "leadlisttemp_897080_value", "value", "TM_GetLeadProcess", "id", "code")), "string"),
				StartDate_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "leadlisttemp_471678_value", "value", "", "", "")), "Date"),
				EndDate_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "leadlisttemp_740276_value", "value", "", "", "")), "Date"),
				UserId_1: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.getMyUserId(), "Guid"),
				MusteriAdi_1: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "leadlisttemp_637785_value", "value", "", "", "")), "string"),
				ProductName_1: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "leadlisttemp_142164_value", "value", "", "", "")), "string"),
				LeadCode_1: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "leadlisttemp_962784_value", "value", "", "", "")), "string"),
				Tel_1: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "leadlisttemp_156403_value", "value", "", "", "")), "string"),
				CategoryName_1: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "leadlisttemp_735719_value", "value", "TM_GetProductCategory", "categoryCode", "categoryName")), "string"),
				StoreIds_1: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "leadlisttemp_877174_value", "value", "TM_GetStore", "storeCode", "id")), "string"),
				SatisDanismaniIds_1: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "leadlisttemp_810709_value", "value", "TM_GetSalesPerson", "kUserId", "kUserId")), "string"),
				ProcessCode_1: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "leadlisttemp_897080_value", "value", "TM_GetLeadProcess", "id", "code")), "string"),
				StartDate_1: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "leadlisttemp_471678_value", "value", "", "", "")), "Date"),
				EndDate_1: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "leadlisttemp_740276_value", "value", "", "", "")), "Date")
        }

		KuikaAppManager.showSpinner(this);
		
        if (true) {
        KuikaAppManager.showSpinner(this);
        }
        let result = await KuikaAppManager.ApiRequest(this, "LeadListTemp/LeadListTempComponent_740276_onChange", localVar)
        if (!KMainFunctions.IsResStatus2XX(result)) return true;

			stateVars.TM_GetLeads = result?.data.tM_GetLeads;
			
			stateVars.TM_GetLeadListSummary = result?.data.tM_GetLeadListSummary;
			formVars.leadlisttemp_694879_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadListSummary !== undefined ? (stateVars.TM_GetLeadListSummary?.length > 0 ? stateVars.TM_GetLeadListSummary[0].talepler : null) : (this.state.TM_GetLeadListSummary?.length > 0 ? this.state.TM_GetLeadListSummary[0].talepler : null)));
			formVars.leadlisttemp_961337_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadListSummary !== undefined ? (stateVars.TM_GetLeadListSummary?.length > 0 ? stateVars.TM_GetLeadListSummary[0].olusturulanTalepler : null) : (this.state.TM_GetLeadListSummary?.length > 0 ? this.state.TM_GetLeadListSummary[0].olusturulanTalepler : null)));
			formVars.leadlisttemp_644429_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadListSummary !== undefined ? (stateVars.TM_GetLeadListSummary?.length > 0 ? stateVars.TM_GetLeadListSummary[0].onayBekleyen : null) : (this.state.TM_GetLeadListSummary?.length > 0 ? this.state.TM_GetLeadListSummary[0].onayBekleyen : null)));
			formVars.leadlisttemp_101832_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadListSummary !== undefined ? (stateVars.TM_GetLeadListSummary?.length > 0 ? stateVars.TM_GetLeadListSummary[0].onaylananTalepler : null) : (this.state.TM_GetLeadListSummary?.length > 0 ? this.state.TM_GetLeadListSummary[0].onaylananTalepler : null)));
			formVars.leadlisttemp_941027_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadListSummary !== undefined ? (stateVars.TM_GetLeadListSummary?.length > 0 ? stateVars.TM_GetLeadListSummary[0].rezervOnayBekleyen : null) : (this.state.TM_GetLeadListSummary?.length > 0 ? this.state.TM_GetLeadListSummary[0].rezervOnayBekleyen : null)));
			formVars.leadlisttemp_606021_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadListSummary !== undefined ? (stateVars.TM_GetLeadListSummary?.length > 0 ? stateVars.TM_GetLeadListSummary[0].satisBekleyen : null) : (this.state.TM_GetLeadListSummary?.length > 0 ? this.state.TM_GetLeadListSummary[0].satisBekleyen : null)));
			formVars.leadlisttemp_599705_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadListSummary !== undefined ? (stateVars.TM_GetLeadListSummary?.length > 0 ? stateVars.TM_GetLeadListSummary[0].satisiYapilan : null) : (this.state.TM_GetLeadListSummary?.length > 0 ? this.state.TM_GetLeadListSummary[0].satisiYapilan : null)));
			formVars.leadlisttemp_585643_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadListSummary !== undefined ? (stateVars.TM_GetLeadListSummary?.length > 0 ? stateVars.TM_GetLeadListSummary[0].reddedilenKapatilanToplam : null) : (this.state.TM_GetLeadListSummary?.length > 0 ? this.state.TM_GetLeadListSummary[0].reddedilenKapatilanToplam : null)));
			formVars.leadlisttemp_604493_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadListSummary !== undefined ? (stateVars.TM_GetLeadListSummary?.length > 0 ? stateVars.TM_GetLeadListSummary[0].musteriIstemedi : null) : (this.state.TM_GetLeadListSummary?.length > 0 ? this.state.TM_GetLeadListSummary[0].musteriIstemedi : null)));
			this.props.form?.setFieldsValue(formVars);
			
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.LeadListTempComponent_740276_onChange1_();
                  resolve();
                });
          })



        
        KuikaAppManager.hideSpinner(this);
        return isErrorOccurred;
    }
		LeadListTempComponent_740276_onChange1_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }

				formVars.leadlisttemp_694879_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadListSummary !== undefined ? (stateVars.TM_GetLeadListSummary?.length > 0 ? stateVars.TM_GetLeadListSummary[0].talepler : null) : (this.state.TM_GetLeadListSummary?.length > 0 ? this.state.TM_GetLeadListSummary[0].talepler : null)));

				formVars.leadlisttemp_961337_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadListSummary !== undefined ? (stateVars.TM_GetLeadListSummary?.length > 0 ? stateVars.TM_GetLeadListSummary[0].olusturulanTalepler : null) : (this.state.TM_GetLeadListSummary?.length > 0 ? this.state.TM_GetLeadListSummary[0].olusturulanTalepler : null)));

				formVars.leadlisttemp_644429_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadListSummary !== undefined ? (stateVars.TM_GetLeadListSummary?.length > 0 ? stateVars.TM_GetLeadListSummary[0].onayBekleyen : null) : (this.state.TM_GetLeadListSummary?.length > 0 ? this.state.TM_GetLeadListSummary[0].onayBekleyen : null)));

				formVars.leadlisttemp_101832_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadListSummary !== undefined ? (stateVars.TM_GetLeadListSummary?.length > 0 ? stateVars.TM_GetLeadListSummary[0].onaylananTalepler : null) : (this.state.TM_GetLeadListSummary?.length > 0 ? this.state.TM_GetLeadListSummary[0].onaylananTalepler : null)));

				formVars.leadlisttemp_941027_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadListSummary !== undefined ? (stateVars.TM_GetLeadListSummary?.length > 0 ? stateVars.TM_GetLeadListSummary[0].rezervOnayBekleyen : null) : (this.state.TM_GetLeadListSummary?.length > 0 ? this.state.TM_GetLeadListSummary[0].rezervOnayBekleyen : null)));

				formVars.leadlisttemp_606021_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadListSummary !== undefined ? (stateVars.TM_GetLeadListSummary?.length > 0 ? stateVars.TM_GetLeadListSummary[0].satisBekleyen : null) : (this.state.TM_GetLeadListSummary?.length > 0 ? this.state.TM_GetLeadListSummary[0].satisBekleyen : null)));

				formVars.leadlisttemp_599705_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadListSummary !== undefined ? (stateVars.TM_GetLeadListSummary?.length > 0 ? stateVars.TM_GetLeadListSummary[0].satisiYapilan : null) : (this.state.TM_GetLeadListSummary?.length > 0 ? this.state.TM_GetLeadListSummary[0].satisiYapilan : null)));

				formVars.leadlisttemp_585643_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadListSummary !== undefined ? (stateVars.TM_GetLeadListSummary?.length > 0 ? stateVars.TM_GetLeadListSummary[0].reddedilenKapatilanToplam : null) : (this.state.TM_GetLeadListSummary?.length > 0 ? this.state.TM_GetLeadListSummary[0].reddedilenKapatilanToplam : null)));

				formVars.leadlisttemp_604493_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadListSummary !== undefined ? (stateVars.TM_GetLeadListSummary?.length > 0 ? stateVars.TM_GetLeadListSummary[0].musteriIstemedi : null) : (this.state.TM_GetLeadListSummary?.length > 0 ? this.state.TM_GetLeadListSummary[0].musteriIstemedi : null)));

				
				stateVars.dataSource_627891 = stateVars.TM_GetLeads ?? this.state.TM_GetLeads;

		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

            
            return isErrorOccurred;
        }




    LeadListTempComponent_816162_onClick = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
		KuikaAppManager.increaseServerRequestCount();

        let localVar = {
				StepOrder_0: ReactSystemFunctions.convertToTypeByName(0, "number"),
				UserId_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.getMyUserId(), "Guid"),
				MusteriAdi_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "leadlisttemp_637785_value", "value", "", "", "")), "string"),
				ProductName_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "leadlisttemp_142164_value", "value", "", "", "")), "string"),
				LeadCode_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "leadlisttemp_962784_value", "value", "", "", "")), "string"),
				Tel_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "leadlisttemp_156403_value", "value", "", "", "")), "string"),
				CategoryName_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "leadlisttemp_735719_value", "value", "TM_GetProductCategory", "categoryCode", "categoryName")), "string"),
				StoreIds_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "leadlisttemp_877174_value", "value", "TM_GetStore", "storeCode", "id")), "string"),
				SatisDanismaniIds_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "leadlisttemp_810709_value", "value", "TM_GetSalesPerson", "kUserId", "kUserId")), "string"),
				ProcessCode_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "leadlisttemp_897080_value", "value", "TM_GetLeadProcess", "id", "code")), "string"),
				StartDate_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "leadlisttemp_471678_value", "value", "", "", "")), "Date"),
				EndDate_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "leadlisttemp_740276_value", "value", "", "", "")), "Date"),
				UserId_1: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.getMyUserId(), "Guid"),
				MusteriAdi_1: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "leadlisttemp_637785_value", "value", "", "", "")), "string"),
				ProductName_1: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "leadlisttemp_142164_value", "value", "", "", "")), "string"),
				LeadCode_1: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "leadlisttemp_962784_value", "value", "", "", "")), "string"),
				Tel_1: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "leadlisttemp_156403_value", "value", "", "", "")), "string"),
				CategoryName_1: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "leadlisttemp_735719_value", "value", "TM_GetProductCategory", "categoryCode", "categoryName")), "string"),
				StoreIds_1: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "leadlisttemp_877174_value", "value", "TM_GetStore", "storeCode", "id")), "string"),
				SatisDanismaniIds_1: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "leadlisttemp_810709_value", "value", "TM_GetSalesPerson", "kUserId", "kUserId")), "string"),
				ProcessCode_1: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "leadlisttemp_897080_value", "value", "TM_GetLeadProcess", "id", "code")), "string"),
				StartDate_1: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "leadlisttemp_471678_value", "value", "", "", "")), "Date"),
				EndDate_1: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "leadlisttemp_740276_value", "value", "", "", "")), "Date")
        }

		KuikaAppManager.showSpinner(this);
		
        if (true) {
        KuikaAppManager.showSpinner(this);
        }
        let result = await KuikaAppManager.ApiRequest(this, "LeadListTemp/LeadListTempComponent_816162_onClick", localVar)
        if (!KMainFunctions.IsResStatus2XX(result)) return true;

			stateVars.TM_GetLeads = result?.data.tM_GetLeads;
			
			stateVars.TM_GetLeadListSummary = result?.data.tM_GetLeadListSummary;
			formVars.leadlisttemp_694879_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadListSummary !== undefined ? (stateVars.TM_GetLeadListSummary?.length > 0 ? stateVars.TM_GetLeadListSummary[0].talepler : null) : (this.state.TM_GetLeadListSummary?.length > 0 ? this.state.TM_GetLeadListSummary[0].talepler : null)));
			formVars.leadlisttemp_961337_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadListSummary !== undefined ? (stateVars.TM_GetLeadListSummary?.length > 0 ? stateVars.TM_GetLeadListSummary[0].olusturulanTalepler : null) : (this.state.TM_GetLeadListSummary?.length > 0 ? this.state.TM_GetLeadListSummary[0].olusturulanTalepler : null)));
			formVars.leadlisttemp_644429_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadListSummary !== undefined ? (stateVars.TM_GetLeadListSummary?.length > 0 ? stateVars.TM_GetLeadListSummary[0].onayBekleyen : null) : (this.state.TM_GetLeadListSummary?.length > 0 ? this.state.TM_GetLeadListSummary[0].onayBekleyen : null)));
			formVars.leadlisttemp_101832_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadListSummary !== undefined ? (stateVars.TM_GetLeadListSummary?.length > 0 ? stateVars.TM_GetLeadListSummary[0].onaylananTalepler : null) : (this.state.TM_GetLeadListSummary?.length > 0 ? this.state.TM_GetLeadListSummary[0].onaylananTalepler : null)));
			formVars.leadlisttemp_941027_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadListSummary !== undefined ? (stateVars.TM_GetLeadListSummary?.length > 0 ? stateVars.TM_GetLeadListSummary[0].rezervOnayBekleyen : null) : (this.state.TM_GetLeadListSummary?.length > 0 ? this.state.TM_GetLeadListSummary[0].rezervOnayBekleyen : null)));
			formVars.leadlisttemp_606021_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadListSummary !== undefined ? (stateVars.TM_GetLeadListSummary?.length > 0 ? stateVars.TM_GetLeadListSummary[0].satisBekleyen : null) : (this.state.TM_GetLeadListSummary?.length > 0 ? this.state.TM_GetLeadListSummary[0].satisBekleyen : null)));
			formVars.leadlisttemp_599705_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadListSummary !== undefined ? (stateVars.TM_GetLeadListSummary?.length > 0 ? stateVars.TM_GetLeadListSummary[0].satisiYapilan : null) : (this.state.TM_GetLeadListSummary?.length > 0 ? this.state.TM_GetLeadListSummary[0].satisiYapilan : null)));
			formVars.leadlisttemp_585643_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadListSummary !== undefined ? (stateVars.TM_GetLeadListSummary?.length > 0 ? stateVars.TM_GetLeadListSummary[0].reddedilenKapatilanToplam : null) : (this.state.TM_GetLeadListSummary?.length > 0 ? this.state.TM_GetLeadListSummary[0].reddedilenKapatilanToplam : null)));
			formVars.leadlisttemp_604493_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadListSummary !== undefined ? (stateVars.TM_GetLeadListSummary?.length > 0 ? stateVars.TM_GetLeadListSummary[0].musteriIstemedi : null) : (this.state.TM_GetLeadListSummary?.length > 0 ? this.state.TM_GetLeadListSummary[0].musteriIstemedi : null)));
			this.props.form?.setFieldsValue(formVars);
			
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.LeadListTempComponent_816162_onClick1_();
                  resolve();
                });
          })



        
        KuikaAppManager.hideSpinner(this);
        return isErrorOccurred;
    }
		LeadListTempComponent_816162_onClick1_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }

				formVars.leadlisttemp_694879_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadListSummary !== undefined ? (stateVars.TM_GetLeadListSummary?.length > 0 ? stateVars.TM_GetLeadListSummary[0].talepler : null) : (this.state.TM_GetLeadListSummary?.length > 0 ? this.state.TM_GetLeadListSummary[0].talepler : null)));

				formVars.leadlisttemp_961337_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadListSummary !== undefined ? (stateVars.TM_GetLeadListSummary?.length > 0 ? stateVars.TM_GetLeadListSummary[0].olusturulanTalepler : null) : (this.state.TM_GetLeadListSummary?.length > 0 ? this.state.TM_GetLeadListSummary[0].olusturulanTalepler : null)));

				formVars.leadlisttemp_644429_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadListSummary !== undefined ? (stateVars.TM_GetLeadListSummary?.length > 0 ? stateVars.TM_GetLeadListSummary[0].onayBekleyen : null) : (this.state.TM_GetLeadListSummary?.length > 0 ? this.state.TM_GetLeadListSummary[0].onayBekleyen : null)));

				formVars.leadlisttemp_101832_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadListSummary !== undefined ? (stateVars.TM_GetLeadListSummary?.length > 0 ? stateVars.TM_GetLeadListSummary[0].onaylananTalepler : null) : (this.state.TM_GetLeadListSummary?.length > 0 ? this.state.TM_GetLeadListSummary[0].onaylananTalepler : null)));

				formVars.leadlisttemp_941027_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadListSummary !== undefined ? (stateVars.TM_GetLeadListSummary?.length > 0 ? stateVars.TM_GetLeadListSummary[0].rezervOnayBekleyen : null) : (this.state.TM_GetLeadListSummary?.length > 0 ? this.state.TM_GetLeadListSummary[0].rezervOnayBekleyen : null)));

				formVars.leadlisttemp_606021_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadListSummary !== undefined ? (stateVars.TM_GetLeadListSummary?.length > 0 ? stateVars.TM_GetLeadListSummary[0].satisBekleyen : null) : (this.state.TM_GetLeadListSummary?.length > 0 ? this.state.TM_GetLeadListSummary[0].satisBekleyen : null)));

				formVars.leadlisttemp_599705_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadListSummary !== undefined ? (stateVars.TM_GetLeadListSummary?.length > 0 ? stateVars.TM_GetLeadListSummary[0].satisiYapilan : null) : (this.state.TM_GetLeadListSummary?.length > 0 ? this.state.TM_GetLeadListSummary[0].satisiYapilan : null)));

				formVars.leadlisttemp_585643_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadListSummary !== undefined ? (stateVars.TM_GetLeadListSummary?.length > 0 ? stateVars.TM_GetLeadListSummary[0].reddedilenKapatilanToplam : null) : (this.state.TM_GetLeadListSummary?.length > 0 ? this.state.TM_GetLeadListSummary[0].reddedilenKapatilanToplam : null)));

				formVars.leadlisttemp_604493_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadListSummary !== undefined ? (stateVars.TM_GetLeadListSummary?.length > 0 ? stateVars.TM_GetLeadListSummary[0].musteriIstemedi : null) : (this.state.TM_GetLeadListSummary?.length > 0 ? this.state.TM_GetLeadListSummary[0].musteriIstemedi : null)));

				
				stateVars.dataSource_627891 = stateVars.TM_GetLeads ?? this.state.TM_GetLeads;

		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

            
            return isErrorOccurred;
        }




		LeadListTempComponent_105452_onClick = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
KuikaAppManager.showSpinner(this);

				stateVars.SetValueOf = await ReactSystemFunctions.setValueOf(this, ReactSystemFunctions.convertToTypeByName("leadlisttemp_637785_value", "string"), "", null, false);
				stateVars.SetValueOf = await ReactSystemFunctions.setValueOf(this, ReactSystemFunctions.convertToTypeByName("leadlisttemp_156403_value", "string"), "", null, false);
				stateVars.SetValueOf = await ReactSystemFunctions.setValueOf(this, ReactSystemFunctions.convertToTypeByName("leadlisttemp_142164_value", "string"), "", null, false);
				stateVars.SetValueOf = await ReactSystemFunctions.setValueOf(this, ReactSystemFunctions.convertToTypeByName("leadlisttemp_735719_value", "string"), "", null, false);
				stateVars.SetValueOf = await ReactSystemFunctions.setValueOf(this, ReactSystemFunctions.convertToTypeByName("leadlisttemp_877174_value", "string"), "", null, false);
				stateVars.SetValueOf = await ReactSystemFunctions.setValueOf(this, ReactSystemFunctions.convertToTypeByName("leadlisttemp_810709_value", "string"), "", null, false);
				stateVars.SetValueOf = await ReactSystemFunctions.setValueOf(this, ReactSystemFunctions.convertToTypeByName("leadlisttemp_897080_value", "string"), "", null, false);
				stateVars.SetValueOf = await ReactSystemFunctions.setValueOf(this, ReactSystemFunctions.convertToTypeByName("leadlisttemp_471678_value", "string"), "", null, false);
				stateVars.SetValueOf = await ReactSystemFunctions.setValueOf(this, ReactSystemFunctions.convertToTypeByName("leadlisttemp_740276_value", "string"), "", null, false);

		this.props.form?.setFieldsValue(formVars);
		
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.LeadListTempComponent_105452_onClick1_();
                  resolve();
                });
          })

            
            return isErrorOccurred;
        }
    LeadListTempComponent_105452_onClick1_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
		KuikaAppManager.increaseServerRequestCount();

        let localVar = {
				StepOrder_0: ReactSystemFunctions.convertToTypeByName(null, "number"),
				UserId_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.getMyUserId(), "Guid"),
				MusteriAdi_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "leadlisttemp_637785_value", "value", "", "", "")), "string"),
				ProductName_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "leadlisttemp_142164_value", "value", "", "", "")), "string"),
				LeadCode_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "leadlisttemp_962784_value", "value", "", "", "")), "string"),
				Tel_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "leadlisttemp_156403_value", "value", "", "", "")), "string"),
				CategoryName_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "leadlisttemp_735719_value", "value", "TM_GetProductCategory", "categoryCode", "categoryName")), "string"),
				StoreIds_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "leadlisttemp_877174_value", "value", "TM_GetStore", "storeCode", "id")), "string"),
				SatisDanismaniIds_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "leadlisttemp_810709_value", "value", "TM_GetSalesPerson", "kUserId", "kUserId")), "string"),
				ProcessCode_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "leadlisttemp_897080_value", "value", "TM_GetLeadProcess", "id", "code")), "string"),
				StartDate_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "leadlisttemp_471678_value", "value", "", "", "")), "Date"),
				EndDate_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "leadlisttemp_740276_value", "value", "", "", "")), "Date"),
				UserId_1: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.getMyUserId(), "Guid"),
				MusteriAdi_1: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "leadlisttemp_637785_value", "value", "", "", "")), "string"),
				ProductName_1: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "leadlisttemp_142164_value", "value", "", "", "")), "string"),
				LeadCode_1: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "leadlisttemp_962784_value", "value", "", "", "")), "string"),
				Tel_1: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "leadlisttemp_156403_value", "value", "", "", "")), "string"),
				CategoryName_1: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "leadlisttemp_735719_value", "value", "TM_GetProductCategory", "categoryCode", "categoryName")), "string"),
				StoreIds_1: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "leadlisttemp_877174_value", "value", "TM_GetStore", "storeCode", "id")), "string"),
				SatisDanismaniIds_1: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "leadlisttemp_810709_value", "value", "TM_GetSalesPerson", "kUserId", "kUserId")), "string"),
				ProcessCode_1: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "leadlisttemp_897080_value", "value", "TM_GetLeadProcess", "id", "code")), "string"),
				StartDate_1: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "leadlisttemp_471678_value", "value", "", "", "")), "Date"),
				EndDate_1: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "leadlisttemp_740276_value", "value", "", "", "")), "Date")
        }

		
        if (true) {
        KuikaAppManager.showSpinner(this);
        }
        let result = await KuikaAppManager.ApiRequest(this, "LeadListTemp/LeadListTempComponent_105452_onClick1_", localVar)
        if (!KMainFunctions.IsResStatus2XX(result)) return true;

			stateVars.TM_GetLeads = result?.data.tM_GetLeads;
			
			stateVars.TM_GetLeadListSummary = result?.data.tM_GetLeadListSummary;
			formVars.leadlisttemp_694879_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadListSummary !== undefined ? (stateVars.TM_GetLeadListSummary?.length > 0 ? stateVars.TM_GetLeadListSummary[0].talepler : null) : (this.state.TM_GetLeadListSummary?.length > 0 ? this.state.TM_GetLeadListSummary[0].talepler : null)));
			formVars.leadlisttemp_961337_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadListSummary !== undefined ? (stateVars.TM_GetLeadListSummary?.length > 0 ? stateVars.TM_GetLeadListSummary[0].olusturulanTalepler : null) : (this.state.TM_GetLeadListSummary?.length > 0 ? this.state.TM_GetLeadListSummary[0].olusturulanTalepler : null)));
			formVars.leadlisttemp_644429_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadListSummary !== undefined ? (stateVars.TM_GetLeadListSummary?.length > 0 ? stateVars.TM_GetLeadListSummary[0].onayBekleyen : null) : (this.state.TM_GetLeadListSummary?.length > 0 ? this.state.TM_GetLeadListSummary[0].onayBekleyen : null)));
			formVars.leadlisttemp_101832_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadListSummary !== undefined ? (stateVars.TM_GetLeadListSummary?.length > 0 ? stateVars.TM_GetLeadListSummary[0].onaylananTalepler : null) : (this.state.TM_GetLeadListSummary?.length > 0 ? this.state.TM_GetLeadListSummary[0].onaylananTalepler : null)));
			formVars.leadlisttemp_941027_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadListSummary !== undefined ? (stateVars.TM_GetLeadListSummary?.length > 0 ? stateVars.TM_GetLeadListSummary[0].rezervOnayBekleyen : null) : (this.state.TM_GetLeadListSummary?.length > 0 ? this.state.TM_GetLeadListSummary[0].rezervOnayBekleyen : null)));
			formVars.leadlisttemp_606021_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadListSummary !== undefined ? (stateVars.TM_GetLeadListSummary?.length > 0 ? stateVars.TM_GetLeadListSummary[0].satisBekleyen : null) : (this.state.TM_GetLeadListSummary?.length > 0 ? this.state.TM_GetLeadListSummary[0].satisBekleyen : null)));
			formVars.leadlisttemp_599705_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadListSummary !== undefined ? (stateVars.TM_GetLeadListSummary?.length > 0 ? stateVars.TM_GetLeadListSummary[0].satisiYapilan : null) : (this.state.TM_GetLeadListSummary?.length > 0 ? this.state.TM_GetLeadListSummary[0].satisiYapilan : null)));
			formVars.leadlisttemp_585643_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadListSummary !== undefined ? (stateVars.TM_GetLeadListSummary?.length > 0 ? stateVars.TM_GetLeadListSummary[0].reddedilenKapatilanToplam : null) : (this.state.TM_GetLeadListSummary?.length > 0 ? this.state.TM_GetLeadListSummary[0].reddedilenKapatilanToplam : null)));
			formVars.leadlisttemp_604493_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadListSummary !== undefined ? (stateVars.TM_GetLeadListSummary?.length > 0 ? stateVars.TM_GetLeadListSummary[0].musteriIstemedi : null) : (this.state.TM_GetLeadListSummary?.length > 0 ? this.state.TM_GetLeadListSummary[0].musteriIstemedi : null)));
			this.props.form?.setFieldsValue(formVars);
			
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.LeadListTempComponent_105452_onClick2_();
                  resolve();
                });
          })



        
        KuikaAppManager.hideSpinner(this);
        return isErrorOccurred;
    }
		LeadListTempComponent_105452_onClick2_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }

				formVars.leadlisttemp_694879_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadListSummary !== undefined ? (stateVars.TM_GetLeadListSummary?.length > 0 ? stateVars.TM_GetLeadListSummary[0].talepler : null) : (this.state.TM_GetLeadListSummary?.length > 0 ? this.state.TM_GetLeadListSummary[0].talepler : null)));

				formVars.leadlisttemp_961337_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadListSummary !== undefined ? (stateVars.TM_GetLeadListSummary?.length > 0 ? stateVars.TM_GetLeadListSummary[0].olusturulanTalepler : null) : (this.state.TM_GetLeadListSummary?.length > 0 ? this.state.TM_GetLeadListSummary[0].olusturulanTalepler : null)));

				formVars.leadlisttemp_644429_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadListSummary !== undefined ? (stateVars.TM_GetLeadListSummary?.length > 0 ? stateVars.TM_GetLeadListSummary[0].onayBekleyen : null) : (this.state.TM_GetLeadListSummary?.length > 0 ? this.state.TM_GetLeadListSummary[0].onayBekleyen : null)));

				formVars.leadlisttemp_101832_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadListSummary !== undefined ? (stateVars.TM_GetLeadListSummary?.length > 0 ? stateVars.TM_GetLeadListSummary[0].onaylananTalepler : null) : (this.state.TM_GetLeadListSummary?.length > 0 ? this.state.TM_GetLeadListSummary[0].onaylananTalepler : null)));

				formVars.leadlisttemp_941027_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadListSummary !== undefined ? (stateVars.TM_GetLeadListSummary?.length > 0 ? stateVars.TM_GetLeadListSummary[0].rezervOnayBekleyen : null) : (this.state.TM_GetLeadListSummary?.length > 0 ? this.state.TM_GetLeadListSummary[0].rezervOnayBekleyen : null)));

				formVars.leadlisttemp_606021_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadListSummary !== undefined ? (stateVars.TM_GetLeadListSummary?.length > 0 ? stateVars.TM_GetLeadListSummary[0].satisBekleyen : null) : (this.state.TM_GetLeadListSummary?.length > 0 ? this.state.TM_GetLeadListSummary[0].satisBekleyen : null)));

				formVars.leadlisttemp_599705_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadListSummary !== undefined ? (stateVars.TM_GetLeadListSummary?.length > 0 ? stateVars.TM_GetLeadListSummary[0].satisiYapilan : null) : (this.state.TM_GetLeadListSummary?.length > 0 ? this.state.TM_GetLeadListSummary[0].satisiYapilan : null)));

				formVars.leadlisttemp_585643_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadListSummary !== undefined ? (stateVars.TM_GetLeadListSummary?.length > 0 ? stateVars.TM_GetLeadListSummary[0].reddedilenKapatilanToplam : null) : (this.state.TM_GetLeadListSummary?.length > 0 ? this.state.TM_GetLeadListSummary[0].reddedilenKapatilanToplam : null)));

				formVars.leadlisttemp_604493_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadListSummary !== undefined ? (stateVars.TM_GetLeadListSummary?.length > 0 ? stateVars.TM_GetLeadListSummary[0].musteriIstemedi : null) : (this.state.TM_GetLeadListSummary?.length > 0 ? this.state.TM_GetLeadListSummary[0].musteriIstemedi : null)));

				
				stateVars.dataSource_627891 = stateVars.TM_GetLeads ?? this.state.TM_GetLeads;

		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

            
            return isErrorOccurred;
        }





    LeadListTempComponent_962784_onBlur = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
		KuikaAppManager.increaseServerRequestCount();

        let localVar = {
				StepOrder_0: ReactSystemFunctions.convertToTypeByName(0, "number"),
				UserId_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.getMyUserId(), "Guid"),
				MusteriAdi_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "leadlisttemp_637785_value", "value", "", "", "")), "string"),
				ProductName_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "leadlisttemp_142164_value", "value", "", "", "")), "string"),
				LeadCode_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "leadlisttemp_962784_value", "value", "", "", "")), "string"),
				Tel_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "leadlisttemp_156403_value", "value", "", "", "")), "string"),
				CategoryName_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "leadlisttemp_735719_value", "value", "TM_GetProductCategory", "categoryCode", "categoryName")), "string"),
				StoreIds_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "leadlisttemp_877174_value", "value", "TM_GetStore", "storeCode", "id")), "string"),
				SatisDanismaniIds_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "leadlisttemp_810709_value", "value", "TM_GetSalesPerson", "kUserId", "kUserId")), "string"),
				ProcessCode_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "leadlisttemp_897080_value", "value", "TM_GetLeadProcess", "id", "code")), "string"),
				StartDate_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "leadlisttemp_471678_value", "value", "", "", "")), "Date"),
				EndDate_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "leadlisttemp_740276_value", "value", "", "", "")), "Date")
        }

		KuikaAppManager.showSpinner(this);
		
        if (true) {
        KuikaAppManager.showSpinner(this);
        }
        let result = await KuikaAppManager.ApiRequest(this, "LeadListTemp/LeadListTempComponent_962784_onBlur", localVar)
        if (!KMainFunctions.IsResStatus2XX(result)) return true;

			stateVars.TM_GetLeads = result?.data.tM_GetLeads;
			
			this.props.form?.setFieldsValue(formVars);
			
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.LeadListTempComponent_962784_onBlur1_();
                  resolve();
                });
          })



        
        KuikaAppManager.hideSpinner(this);
        return isErrorOccurred;
    }
		LeadListTempComponent_962784_onBlur1_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }

				
				stateVars.dataSource_627891 = stateVars.TM_GetLeads ?? this.state.TM_GetLeads;

		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

            
            return isErrorOccurred;
        }




    LeadListTempComponent_183968_onClick = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
		KuikaAppManager.increaseServerRequestCount();

        let localVar = {
				value_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, this.state.TM_GetLeads), "any"),
				header_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.convertToTypeByName("Talep Raporu", "string"), "string"),
				footer_0: ReactSystemFunctions.convertToTypeByName("", "string"),
				columns_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.convertToTypeByName("RezerveDurumu,IsReserved,LeadNumarasi,TalepTarihi,ProductName,Bilezik,Brand,Kadran,Referans,Musteri,Lokasyon,Ilce,Ulke,MusteriInfo,AlisverisiVarMi,IrtibatNumarasi,EmailAdresi,IletisimKaynagi,CategoryName,LeadDurumu,SonrakiAdim,ProcessName,TerminTarihi,SatisDanismani,StoreName", "string"), "string")
        }

		KuikaAppManager.showSpinner(this);
		
        if (true) {
        KuikaAppManager.showSpinner(this);
        }
        let result = await KuikaAppManager.ApiRequest(this, "LeadListTemp/LeadListTempComponent_183968_onClick", localVar)
        if (!KMainFunctions.IsResStatus2XX(result)) return true;

			stateVars.ExportExcel = result?.data.exportExcel;
			ReactSystemFunctions.downloadFile(result?.data?.exportExcel);
			this.props.form?.setFieldsValue(formVars);
			this.setState(stateVars);
			KuikaAppManager.hideSpinner(this);



        this.setPageInitLoaded(true);
        KuikaAppManager.hideSpinner(this);
        return isErrorOccurred;
    }



		LeadListTempComponent_777033_onClick = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
KuikaAppManager.showSpinner(this);

					KuikaAppManager.prepareForNavigation();
						KuikaAppManager.addToPageInputVariables("LeadDetailTemp", "LeadId", ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, "leadlisttemp_627891_value", "leadId"), "Guid"));

				stateVars.NAVIGATE = await ReactSystemFunctions.navigate(this, undefined, "LeadListTemp", "LeadDetailTemp", "", "7d969ddf-5801-4eb6-b92b-12be35bdd565", "284094", null, "right", "true", "70vw", "100vh", true, false);

		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

            
            return isErrorOccurred;
        }




    async callCallbackFunction(diId: number, isFromMaster: boolean = false) {
        let isErrorOccurred = false;
		let pageInitCallerNavDiIDs = [, , 935516, 284094] as number[];
		if (isFromMaster || pageInitCallerNavDiIDs.indexOf(diId) > -1) {
			await this.LeadListTempPageInit();
		}

    }


}
