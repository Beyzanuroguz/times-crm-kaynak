import React from "react";
import Axios, { AxiosResponse } from "axios";
import { KuikaAppManager } from "../../shared/utilty/kuika-app-manager";
import { ReactSystemFunctions } from "../../shared/utilty/react-system-functions";
import { KNavigator } from "../../shared/hoc/with-history";
import { KContext } from "../../shared/hoc/with-context";
import { useLocation } from "react-router-dom";
import { FormInstance } from "antd/es/form";
import { Guid } from "guid-typescript";
import Swal from "sweetalert2";
import { KMainFunctions } from "../../shared/utilty/main-functions";
import moment from "moment";
import { IValidationData } from "../../models/dto/validation-data";
import { IStripePayment } from "../../models/dto/stripe-payment";
import { IUserInfoDto } from "../../models/dto/user-info.dto";
import { UserService } from "../../services/user-service";
import { kuikaCoreWasmBridgeService } from "../../services/_singletons";
import _ from "lodash";
import mqtt, { MqttClient } from "mqtt";
import { IMqttResult } from "../../models/dto/mqtt.dto";
import { MasterScreen_ScreenContext } from "../masterscreen/masterscreen-context";

declare let window: any;

export interface IAllLeadPending_ScreenProps {
  navigator: KNavigator;
  form: FormInstance<any>;
  googleLogin: any;
  screenInputs: any;
  context: KContext;
  initialValues: any;
  children: any;
}

export interface IAllLeadPending_ScreenState {
    isSpinnerVisible: boolean;
    isPageVisible: boolean;
	isLeftMenuVisible: boolean;
    spinnerCount: number;
    selectedLanguage: string;
    isPageInitLoaded: false;
    isPageRecurringLoaded: false;
	TerminOneriSlctbox: any[];
	TerminOneriSlctbox_dummy: any[];
	TM_GetPendingLeads: any[];
	TM_GetPendingLeads_dummy: any[];
	TMGetApprovedList: any[];
	TMGetApprovedList_dummy: any[];
	TM_GetStore: any[];
	TM_GetStore_dummy: any[];
	TM_GetProductCategory: any[];
	TM_GetProductCategory_dummy: any[];
	TM_GetLeadStatus: any[];
	TM_GetLeadStatus_dummy: any[];
	TM_GetLeadProcess: any[];
	TM_GetLeadProcess_dummy: any[];
	TM_GetSalesPerson: any[];
	TM_GetSalesPerson_dummy: any[];
	SetValueOf: any;
	SetValueOf_dummy: any;
	ChangeVisibilityOf: string;
	ChangeVisibilityOf_dummy: string;
	TM_BulkApproveTerminProposals: any[];
	TM_BulkApproveTerminProposals_dummy: any[];
	Notify: boolean;
	Notify_dummy: boolean;
	TM_BulkSetTerminAndApprove: any[];
	TM_BulkSetTerminAndApprove_dummy: any[];
	NAVIGATE: any;
	NAVIGATE_dummy: any;
	TM_BulkChangeApprovedLeadTermin: any[];
	TM_BulkChangeApprovedLeadTermin_dummy: any[];
	isComp384188Visible: 'visible' | 'hidden';
	isComp222070Visible: 'visible' | 'hidden';
	isComp340825Visible: 'visible' | 'hidden';
	isComp324523243Visible: 'visible' | 'hidden';
	isComp348079Visible: 'visible' | 'hidden';
	isComp1960132892Visible: 'visible' | 'hidden';
	isComp1830446497Visible: 'visible' | 'hidden';
	isComp1390549895Visible: 'visible' | 'hidden';
	isComp1815110498Visible: 'visible' | 'hidden';
	isComp1829986670Visible: 'visible' | 'hidden';
	isComp1140624241Visible: 'visible' | 'hidden';
	isComp1733992048Visible: 'visible' | 'hidden';
	isComp1109289554Visible: 'visible' | 'hidden';
	isComp794829871Visible: 'visible' | 'hidden';
	isComp259376128Visible: 'visible' | 'hidden';
	isComp1566137016Visible: 'visible' | 'hidden';
	isComp1336712822Visible: 'visible' | 'hidden';
	isComp1662995164Visible: 'visible' | 'hidden';
	isComp221575437Visible: 'visible' | 'hidden';
	isComp1584996465Visible: 'visible' | 'hidden';
	isComp1928748848Visible: 'visible' | 'hidden';
	isComp533394467Visible: 'visible' | 'hidden';
	isComp932523823Visible: 'visible' | 'hidden';
	isComp958140466Visible: 'visible' | 'hidden';
	isComp1966365116Visible: 'visible' | 'hidden';
	isComp1199564709Visible: 'visible' | 'hidden';
	isComp709157561Visible: 'visible' | 'hidden';
	isComp1306638514Visible: 'visible' | 'hidden';
	isComp519501061Visible: 'visible' | 'hidden';
	isComp1994694700Visible: 'visible' | 'hidden';

}

export class AllLeadPending_ScreenBase extends React.PureComponent<IAllLeadPending_ScreenProps, any> {
    static contextType = MasterScreen_ScreenContext;
    declare context: React.ContextType<typeof MasterScreen_ScreenContext>;
	allleadpending_1904273601_value_kuikaDateRef: React.RefObject<any>;
	allleadpending_1827823391_value_kuikaDateRef: React.RefObject<any>;
	allleadpending_206028_value_kuikaSelectBoxRef: React.RefObject<any>;
	allleadpending_2038824790_value_kuikaAutoCompleteRef: React.RefObject<any>;
	allleadpending_2007552957_value_kuikaAutoCompleteRef: React.RefObject<any>;
	allleadpending_1735739523_value_kuikaTableRef: React.RefObject<any>;
	allleadpending_761630611_value_kuikaAutoCompleteRef: React.RefObject<any>;
	allleadpending_1897922726_value_kuikaAutoCompleteRef: React.RefObject<any>;
	allleadpending_1676811829_value_kuikaTableRef: React.RefObject<any>;
    ml=[{"Id":"d5a61d2b-bd60-485f-86e2-661e9ed4e486","Name":"en_US","ShortName":"English","IsDefault":true,"LanguagePhrases":[]},{"Id":"baa5beb3-82d1-47f3-85ec-4249bfd82aeb","Name":"FixedValues","ShortName":"FixedValues","LanguagePhrases":[{"Id":822957,"PropertyName":"value","Value":"Onay Bekleyen Talepler"},{"Id":851146,"PropertyName":"value","Value":"Onay bekleyen kayıtları görüntüleyin ve onaylayın."},{"Id":482695,"PropertyName":"value","Value":"Onay Bekleyen Talep Listesi"},{"Id":923170,"PropertyName":"header","Value":"Filtreler"},{"Id":607311583,"PropertyName":"value","Value":"Müşteri Adı"},{"Id":1393106492,"PropertyName":"placeholder","Value":"Müşteri Adı"},{"Id":1531975066,"PropertyName":"value","Value":"Müşteri Telefon Numarası"},{"Id":226438964,"PropertyName":"placeholder","Value":"Müşteri Telefon Numarası"},{"Id":651456171,"PropertyName":"value","Value":"Ürün Adı"},{"Id":1486438661,"PropertyName":"placeholder","Value":"Ürün Adı"},{"Id":1686419716,"PropertyName":"value","Value":"Kategori"},{"Id":1888449157,"PropertyName":"placeholder","Value":"Kategori"},{"Id":1289573443,"PropertyName":"value","Value":"Mağaza"},{"Id":1836228438,"PropertyName":"placeholder","Value":"Mağaza"},{"Id":642554002,"PropertyName":"value","Value":"Satış Danışmanı"},{"Id":86365187,"PropertyName":"placeholder","Value":"Satış Danışmanı"},{"Id":1978234303,"PropertyName":"value","Value":"Talep Durumu"},{"Id":869961548,"PropertyName":"placeholder","Value":"Talep Durumu"},{"Id":1419844633,"PropertyName":"value","Value":"Başlangıç Tarihi"},{"Id":1424747020,"PropertyName":"value","Value":"Bitiş Tarihi"},{"Id":1684357334,"PropertyName":"label","Value":"Filtreleri Temizle"},{"Id":788616,"PropertyName":"label","Value":"Filtreyi Uygula"},{"Id":852460,"PropertyName":"value","Value":"Talep Numarasına Göre Ara"},{"Id":16517,"PropertyName":"placeholder","Value":"Talep Numarası Giriniz"},{"Id":985272,"PropertyName":"value","Value":"Onaylanmış Leadleri Göster"},{"Id":206028,"PropertyName":"placeholder","Value":"Termin Onerisi Filtresi"},{"Id":1960132892,"PropertyName":"label","Value":"Seçilmiş, Termin Önerisi Olan Leadleri Toplu Onayla"},{"Id":2038824790,"PropertyName":"placeholder","Value":"Termin yılı seçiniz"},{"Id":2007552957,"PropertyName":"placeholder","Value":"Termin ayı seçiniz"},{"Id":34070132,"PropertyName":"label","Value":"Seçilmiş Leadleri Toplu Onayla"},{"Id":58047,"PropertyName":"value","Value":"Onay Bekleyen Leadler"},{"Id":107293919,"PropertyName":"title","Value":"Talep Tarihi"},{"Id":1681178749,"PropertyName":"value","Value":"[datafield:taleptarihi]"},{"Id":2059573083,"PropertyName":"title","Value":"Talep Numarası"},{"Id":346403413,"PropertyName":"value","Value":"[datafield:leadnumarasi]"},{"Id":2038592747,"PropertyName":"title","Value":"Mağaza"},{"Id":197077549,"PropertyName":"value","Value":"[datafield:storename]"},{"Id":1865985466,"PropertyName":"title","Value":"Marka"},{"Id":780528542,"PropertyName":"value","Value":"[datafield:brand]"},{"Id":39913232,"PropertyName":"title","Value":"Kategori"},{"Id":1390549895,"PropertyName":"value","Value":"[datafield:categoryname]"},{"Id":1815110498,"PropertyName":"value","Value":"[datafield:categoryname]"},{"Id":1829986670,"PropertyName":"value","Value":"[datafield:categoryname]"},{"Id":1140624241,"PropertyName":"value","Value":"[datafield:categoryname]"},{"Id":132937405,"PropertyName":"title","Value":"Ürün Adı"},{"Id":413246892,"PropertyName":"value","Value":"[datafield:productname]"},{"Id":1654833203,"PropertyName":"title","Value":"Müşteri"},{"Id":1095075856,"PropertyName":"value","Value":"[datafield:musteri]"},{"Id":101097380,"PropertyName":"title","Value":"Takip Durumu"},{"Id":1733992048,"PropertyName":"value","Value":"[datafield:leaddurumu]"},{"Id":1109289554,"PropertyName":"value","Value":"[datafield:leaddurumu]"},{"Id":1335809119,"PropertyName":"title","Value":"Sonraki Adım"},{"Id":690283879,"PropertyName":"value","Value":"[datafield:sonrakiadim]"},{"Id":502782602,"PropertyName":"title","Value":"Satış Danışmanı"},{"Id":89686577,"PropertyName":"value","Value":"[datafield:satisdanismani]"},{"Id":404209691,"PropertyName":"title","Value":"Talep Durumu"},{"Id":794829871,"PropertyName":"value","Value":"[datafield:processname]"},{"Id":259376128,"PropertyName":"value","Value":"[datafield:processname]"},{"Id":1566137016,"PropertyName":"value","Value":"[datafield:processname]"},{"Id":1336712822,"PropertyName":"value","Value":"[datafield:processname]"},{"Id":1662995164,"PropertyName":"value","Value":"[datafield:processname]"},{"Id":1579947266,"PropertyName":"title","Value":"Termin Önerisi"},{"Id":1500287824,"PropertyName":"value","Value":"[datafield:proposaldatetext]"},{"Id":1368093471,"PropertyName":"title","Value":"Onay"},{"Id":770563660,"PropertyName":"label","Value":"Onayla"},{"Id":222311101,"PropertyName":"title","Value":"Detay"},{"Id":12401070,"PropertyName":"label","Value":"Detay"},{"Id":1743018118,"PropertyName":"label","Value":"Lead Detay Mevcut Sekme"},{"Id":1492248385,"PropertyName":"label","Value":"Lead Detay Yeni Sekme"},{"Id":831143980,"PropertyName":"label","Value":"Aynı Ürün Leadleri Mevcut Sekme"},{"Id":1103704329,"PropertyName":"label","Value":"Aynı Ürün Leadleri Yeni Sekme"},{"Id":761630611,"PropertyName":"placeholder","Value":"Termin yılı seçiniz"},{"Id":1897922726,"PropertyName":"placeholder","Value":"Termin ayı seçiniz"},{"Id":735657199,"PropertyName":"label","Value":"Seçilmiş Leadleri Toplu Değiştir"},{"Id":321323,"PropertyName":"value","Value":"Onaylanmış Leadler"},{"Id":1838917994,"PropertyName":"title","Value":"Talep Tarihi"},{"Id":1071936807,"PropertyName":"value","Value":"[datafield:taleptarihi]"},{"Id":976077778,"PropertyName":"title","Value":"Talep Numarası"},{"Id":1596929512,"PropertyName":"value","Value":"[datafield:leadnumarasi]"},{"Id":1424359057,"PropertyName":"title","Value":"Mağaza"},{"Id":24343592,"PropertyName":"value","Value":"[datafield:storename]"},{"Id":432998379,"PropertyName":"title","Value":"Marka"},{"Id":787023413,"PropertyName":"value","Value":"[datafield:brand]"},{"Id":119739654,"PropertyName":"title","Value":"Kategori"},{"Id":1584996465,"PropertyName":"value","Value":"[datafield:categoryname]"},{"Id":1928748848,"PropertyName":"value","Value":"[datafield:categoryname]"},{"Id":533394467,"PropertyName":"value","Value":"[datafield:categoryname]"},{"Id":932523823,"PropertyName":"value","Value":"[datafield:categoryname]"},{"Id":982319723,"PropertyName":"title","Value":"Ürün Adı"},{"Id":1350323165,"PropertyName":"value","Value":"[datafield:productname]"},{"Id":1688050219,"PropertyName":"title","Value":"Müşteri"},{"Id":705569129,"PropertyName":"value","Value":"[datafield:musteri]"},{"Id":1378991451,"PropertyName":"title","Value":"Takip Durumu"},{"Id":958140466,"PropertyName":"value","Value":"[datafield:leaddurumu]"},{"Id":1966365116,"PropertyName":"value","Value":"[datafield:leaddurumu]"},{"Id":1244943497,"PropertyName":"title","Value":"Sonraki Adım"},{"Id":1540070051,"PropertyName":"value","Value":"[datafield:sonrakiadim]"},{"Id":1619450162,"PropertyName":"title","Value":"Satış Danışmanı"},{"Id":1905489680,"PropertyName":"value","Value":"[datafield:satisdanismani]"},{"Id":1964210598,"PropertyName":"title","Value":"Talep Durumu"},{"Id":1199564709,"PropertyName":"value","Value":"[datafield:processname]"},{"Id":709157561,"PropertyName":"value","Value":"[datafield:processname]"},{"Id":1306638514,"PropertyName":"value","Value":"[datafield:processname]"},{"Id":519501061,"PropertyName":"value","Value":"[datafield:processname]"},{"Id":1994694700,"PropertyName":"value","Value":"[datafield:processname]"},{"Id":224643512,"PropertyName":"title","Value":"Termin Tarihi"},{"Id":956082693,"PropertyName":"value","Value":"[datafield:termintarihitext]"},{"Id":2126869735,"PropertyName":"title","Value":"Termin"},{"Id":2121711473,"PropertyName":"label","Value":"Değiştir"},{"Id":1621009855,"PropertyName":"title","Value":"Detay"},{"Id":1282361739,"PropertyName":"label","Value":"Detay"},{"Id":2223545,"PropertyName":"label","Value":"Lead Detay Mevcut Sekme"},{"Id":480889991,"PropertyName":"label","Value":"Lead Detay Yeni Sekme"},{"Id":906008770,"PropertyName":"label","Value":"Aynı Ürün Leadleri Mevcut Sekme"},{"Id":695390301,"PropertyName":"label","Value":"Aynı Ürün Leadleri Yeni Sekme"}]}]
    defaultML = "en_US"
    
    screenHash = ""
    

    private _prevMasterPageInitLoaded: boolean = false;
    private _prevMasterPageRecurringLoaded: boolean = false;
    private _prevShouldTriggerPageInit: boolean = false;
    constructor(props) {
        super(props);
		this.allleadpending_1393106492_value_kuikaTextInputRef = React.createRef();
		this.allleadpending_226438964_value_kuikaTextInputRef = React.createRef();
		this.allleadpending_1486438661_value_kuikaTextInputRef = React.createRef();
		this.allleadpending_1904273601_value_kuikaDateRef = React.createRef();
		this.allleadpending_1827823391_value_kuikaDateRef = React.createRef();
		this.allleadpending_16517_value_kuikaTextInputRef = React.createRef();
		this.allleadpending_206028_value_kuikaSelectBoxRef = React.createRef();
		this.allleadpending_2038824790_value_kuikaAutoCompleteRef = React.createRef();
		this.allleadpending_2007552957_value_kuikaAutoCompleteRef = React.createRef();
		this.allleadpending_1735739523_value_kuikaTableRef = React.createRef();
		this.allleadpending_761630611_value_kuikaAutoCompleteRef = React.createRef();
		this.allleadpending_1897922726_value_kuikaAutoCompleteRef = React.createRef();
		this.allleadpending_1676811829_value_kuikaTableRef = React.createRef();

        this.state = {
            isSpinnerVisible: false,
            isPageVisible: false,
            isLeftMenuVisible: false,
            spinnerCount: 0,
            selectedLanguage: "",
            isPageInitLoaded: false,
            isPageRecurringLoaded: false,
            	        TerminOneriSlctbox: [],
	        TM_GetPendingLeads: [],
	        TMGetApprovedList: [],
	        TM_GetStore: [],
	        TM_GetProductCategory: [],
	        TM_GetLeadStatus: [],
	        TM_GetLeadProcess: [],
	        TM_GetSalesPerson: [],
	        SetValueOf: "",
	        ChangeVisibilityOf: "",
	        TM_BulkApproveTerminProposals: [],
	        Notify: false,
	        TM_BulkSetTerminAndApprove: [],
	        NAVIGATE: "",
	        TM_BulkChangeApprovedLeadTermin: [],
	        dataSource_2038824790: [{"key":"2026","text":"2026"},{"key":"2027","text":"2027"},{"key":"2028","text":"2028"},{"key":"2029","text":"2029"},{"key":"2030","text":"2030"},{"key":"2031","text":"2031"},{"key":"2032","text":"2032"},{"key":"2033","text":"2033"},{"key":"2034","text":"2034"},{"key":"2035","text":"2035"},{"key":"2036","text":"2036"},{"key":"2037","text":"2037"},{"key":"2038","text":"2038"},{"key":"2039","text":"2039"},{"key":"2040","text":"2040"}],
	        dataSource_2007552957: [{"key":"1","text":"Ocak"},{"key":"2","text":"Şubat"},{"key":"3","text":"Mart"},{"key":"4","text":"Nisan"},{"key":"5","text":"Mayıs"},{"key":"6","text":"Haziran"},{"key":"7","text":"Temmuz"},{"key":"8","text":"Ağustos"},{"key":"9","text":"Eylül"},{"key":"10","text":"Ekim"},{"key":"11","text":"Kasım"},{"key":"12","text":"Aralık"}],
	        dataSource_761630611: [{"key":"2026","text":"2026"},{"key":"2027","text":"2027"},{"key":"2028","text":"2028"},{"key":"2029","text":"2029"},{"key":"2030","text":"2030"},{"key":"2031","text":"2031"},{"key":"2032","text":"2032"},{"key":"2033","text":"2033"},{"key":"2034","text":"2034"},{"key":"2035","text":"2035"},{"key":"2036","text":"2036"},{"key":"2037","text":"2037"},{"key":"2038","text":"2038"},{"key":"2039","text":"2039"},{"key":"2040","text":"2040"}],
	        dataSource_1897922726: [{"key":"1","text":"Ocak"},{"key":"2","text":"Şubat"},{"key":"3","text":"Mart"},{"key":"4","text":"Nisan"},{"key":"5","text":"Mayıs"},{"key":"6","text":"Haziran"},{"key":"7","text":"Temmuz"},{"key":"8","text":"Ağustos"},{"key":"9","text":"Eylül"},{"key":"10","text":"Ekim"},{"key":"11","text":"Kasım"},{"key":"12","text":"Aralık"}],
	        isComp384188Visible: 'visible',
	        isComp222070Visible: 'hidden',
	        isComp340825Visible: 'visible',
	        isComp324523243Visible: 'visible',
	        isComp348079Visible: 'hidden',
	        isComp1960132892Visible: 'hidden',
	        isComp1830446497Visible: 'hidden',
	        isComp1390549895Visible: 'hidden',
	        isComp1815110498Visible: 'hidden',
	        isComp1829986670Visible: 'hidden',
	        isComp1140624241Visible: 'hidden',
	        isComp1733992048Visible: 'hidden',
	        isComp1109289554Visible: 'hidden',
	        isComp794829871Visible: 'hidden',
	        isComp259376128Visible: 'hidden',
	        isComp1566137016Visible: 'hidden',
	        isComp1336712822Visible: 'hidden',
	        isComp1662995164Visible: 'hidden',
	        isComp221575437Visible: 'hidden',
	        isComp1584996465Visible: 'hidden',
	        isComp1928748848Visible: 'hidden',
	        isComp533394467Visible: 'hidden',
	        isComp932523823Visible: 'hidden',
	        isComp958140466Visible: 'hidden',
	        isComp1966365116Visible: 'hidden',
	        isComp1199564709Visible: 'hidden',
	        isComp709157561Visible: 'hidden',
	        isComp1306638514Visible: 'hidden',
	        isComp519501061Visible: 'hidden',
	        isComp1994694700Visible: 'hidden',

        }

        this.CheckPageAuthorization(this.state);

        
    }

    async componentDidMount() {

        if (KuikaAppManager.isPageInitPrevented()) {
            KuikaAppManager.calculateAndSetBodyHeight("allleadpending", "masterscreen_screen");
            return;
        }
        this.context.registerCallbackFunction(this.callCallbackFunction.bind(this));
        
        ReactSystemFunctions.validateToken()
        this.fillFormInitValues();
        if (false){
            await this.AllLeadPendingPageInit();
        } else if (this.context?.isMasterPageInitLoaded) { this._prevMasterPageInitLoaded = true; await this.AllLeadPendingPageInit(); }
        
        
        
        KuikaAppManager.calculateAndSetBodyHeight("allleadpending", "masterscreen_screen");

        if (ReactSystemFunctions.getIsMicroApp() === false) {
           window.parentScreen = this;
        }
    }

    componentWillUnmount() {
        
        
        

        if (ReactSystemFunctions.getIsMicroApp() === false) {
           window.parentScreen = null;
        }
    }

    
              CheckPageAuthorization = async (state) => {
                KuikaAppManager.showSpinner(this);
                if (_.isEmpty(window.userInfo)) {
                  await UserService.GetUserInfoForce();
                }
                const permittedRoleNames: string[] = ["TimesYonetici","TimesUstYonetici","TimesMagazaMuduru",];
                const userInfo = window.userInfo as IUserInfoDto;
                const userRoleNames = userInfo.roles.map((role) => role.name);
                if (!ReactSystemFunctions.hasAnyRoleName(permittedRoleNames, userRoleNames)) {
                  await ReactSystemFunctions.goBack(this);

                  const language = localStorage.getItem("ml");
                  let permissonErrorMessageText = "You do not have permission to access this page.";
                  if (language === "tr_TR") {
                    permissonErrorMessageText = "Bu sayfaya erişim yetkiniz yok.";
                  } else if (language === "fr_FR") {
                    permissonErrorMessageText = "Vous n'avez pas la permission d'accéder à cette page.";
                  } else if (language === "de_DE") {
                    permissonErrorMessageText = "Sie haben keine Berechtigung, auf diese Seite zuzugreifen.";
                  } else if (language === "es_ES") {
                    permissonErrorMessageText = "No tienes permiso para acceder a esta página.";
                  }

                  KMainFunctions.displayErrorNotification(permissonErrorMessageText);
                  state.isPageVisible = false;
                  KuikaAppManager.hideSpinner(this);
                  return;
                }
                state.isPageVisible = true;
                KuikaAppManager.hideSpinner(this);
              };
        

        
    componentDidUpdate= async (prevProps, prevState) => {
		KuikaAppManager.calculateAndSetBodyHeight("allleadpending", "masterscreen_screen"    );
        if (prevProps?.location?.search !== (this.props as any)?.location?.search) {
			await this.AllLeadPendingPageInit();
		}

        		if (this._prevMasterPageInitLoaded !== this.context.isMasterPageInitLoaded && this.context.isMasterPageInitLoaded === true) {this._prevMasterPageInitLoaded = this.context.isMasterPageInitLoaded;await this.AllLeadPendingPageInit()}


        if (ReactSystemFunctions.getIsMicroApp() === false) {
            for (const key in prevState) {
                if (key.startsWith('NavVisible') && prevState[key] === true && this.state[key] === false) {
                    window.parentScreen = this;
                    break;
                }
            }
        }
	}

    fillFormInitValues() {
        this.props.form?.setFieldsValue({
allleadpending_509274_checked: false
});

    }

      setPageInitLoaded = (value: boolean) => {
        this.setState({ isPageInitLoaded: value });
      }

      setPageRecurringLoaded = (value: boolean) => {
        this.setState({ isPageRecurringLoaded: value });
      }

      clearFieldValidation = (changedValues: any) => {
        const fieldName = Object.keys(changedValues)[0];
        if (fieldName) {
          this.props.form?.setFields([
            {
              name: fieldName,
              errors: []
            }
          ]);
        }
      };

      

    AllLeadPendingPageInit = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


	if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }

        let localVar = {
			UserId_1: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.getMyUserId(), "Guid"),
			LeadCode_1: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "allleadpending_16517_value", "value", "", "", "")), "string"),
			MusteriAdi_1: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "allleadpending_1393106492_value", "value", "", "", "")), "string"),
			Tel_1: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "allleadpending_226438964_value", "value", "", "", "")), "string"),
			ProductName_1: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "allleadpending_1486438661_value", "value", "", "", "")), "string"),
			CategoryName_1: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "allleadpending_1888449157_value", "value", "TM_GetProductCategory", "categoryCode", "categoryName")), "string"),
			StoreIds_1: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "allleadpending_1836228438_value", "value", "TM_GetStore", "storeCode", "id")), "string"),
			SatisDanismaniIds_1: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "allleadpending_86365187_value", "value", "TM_GetSalesPerson", "kUserId", "kUserId")), "string"),
			ProcessCode_1: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "allleadpending_869961548_value", "value", "TM_GetLeadProcess", "id", "code")), "string"),
			StartDate_1: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "allleadpending_1904273601_value", "value", "", "", "")), "Date"),
			EndDate_1: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "allleadpending_1827823391_value", "value", "", "", "")), "Date"),
			TerminOnerisiDurumu_1: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "allleadpending_206028_value", "value", "TerminOneriSlctbox", "key", "key")), "string"),
			UserId_2: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.getMyUserId(), "Guid"),
			LeadCode_2: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "allleadpending_16517_value", "value", "", "", "")), "string"),
			MusteriAdi_2: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "allleadpending_1393106492_value", "value", "", "", "")), "string"),
			Tel_2: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "allleadpending_226438964_value", "value", "", "", "")), "string"),
			ProductName_2: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "allleadpending_1486438661_value", "value", "", "", "")), "string"),
			CategoryName_2: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "allleadpending_1888449157_value", "value", "TM_GetProductCategory", "categoryCode", "categoryName")), "string"),
			StoreIds_2: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "allleadpending_1836228438_value", "value", "TM_GetStore", "storeCode", "id")), "string"),
			SatisDanismaniIds_2: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "allleadpending_86365187_value", "value", "TM_GetSalesPerson", "kUserId", "kUserId")), "string"),
			ProcessCode_2: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "allleadpending_869961548_value", "value", "TM_GetLeadProcess", "id", "code")), "string"),
			StartDate_2: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "allleadpending_1904273601_value", "value", "", "", "")), "Date"),
			EndDate_2: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "allleadpending_1827823391_value", "value", "", "", "")), "Date"),
			KUserId_3: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.getMyUserId(), "Guid"),
			StepOrder_6: ReactSystemFunctions.convertToTypeByName(0, "number"),
			KUserId_7: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.getMyUserId(), "Guid"),
			StoreId_7: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, (stateVars.TM_GetStore !== undefined ? (stateVars.TM_GetStore?.length > 0 ? stateVars.TM_GetStore[0].id : null) : (this.state.TM_GetStore?.length > 0 ? this.state.TM_GetStore[0].id : null))), "Guid")
        }

	KuikaAppManager.showSpinner(this);
	
        if (true) {
        KuikaAppManager.showSpinner(this);
        }
        let result = await KuikaAppManager.ApiRequest(this, "AllLeadPending/AllLeadPendingPageInit", localVar)
        if (!KMainFunctions.IsResStatus2XX(result)) return true;

		stateVars.TerminOneriSlctbox = result?.data.terminOneriSlctbox;
		
		formVars.allleadpending_206028_options = stateVars.TerminOneriSlctbox;
		stateVars.TM_GetPendingLeads = result?.data.tM_GetPendingLeads;
		
		stateVars.TMGetApprovedList = result?.data.tmGetApprovedList;
		
		stateVars.TM_GetStore = result?.data.tM_GetStore;
		
		formVars.allleadpending_1836228438_options = stateVars.TM_GetStore;
		stateVars.TM_GetProductCategory = result?.data.tM_GetProductCategory;
		
		formVars.allleadpending_1888449157_options = stateVars.TM_GetProductCategory;
		stateVars.TM_GetLeadStatus = result?.data.tM_GetLeadStatus;
		stateVars.TM_GetLeadProcess = result?.data.tM_GetLeadProcess;
		
		formVars.allleadpending_869961548_options = stateVars.TM_GetLeadProcess;
		stateVars.TM_GetSalesPerson = result?.data.tM_GetSalesPerson;
		
		formVars.allleadpending_86365187_options = stateVars.TM_GetSalesPerson;
		this.props.form?.setFieldsValue(formVars);
		
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.AllLeadPendingPageInit1_();
                  resolve();
                });
          })



        
        KuikaAppManager.hideSpinner(this);
        return isErrorOccurred;
    }
	AllLeadPendingPageInit1_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


	if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }

			
			stateVars.dataSource_1888449157 = stateVars.TM_GetProductCategory ?? this.state.TM_GetProductCategory;
			stateVars.dataSource_1888449157 = stateVars.TM_GetProductCategory ?? this.state.TM_GetProductCategory;
			
			stateVars.dataSource_1836228438 = stateVars.TM_GetStore ?? this.state.TM_GetStore;
			stateVars.dataSource_1836228438 = stateVars.TM_GetStore ?? this.state.TM_GetStore;
			
			stateVars.dataSource_86365187 = stateVars.TM_GetSalesPerson ?? this.state.TM_GetSalesPerson;
			stateVars.dataSource_86365187 = stateVars.TM_GetSalesPerson ?? this.state.TM_GetSalesPerson;
			
			stateVars.dataSource_869961548 = stateVars.TM_GetLeadProcess ?? this.state.TM_GetLeadProcess;
			stateVars.dataSource_869961548 = stateVars.TM_GetLeadProcess ?? this.state.TM_GetLeadProcess;
			
			stateVars.dataSource_206028 = stateVars.TerminOneriSlctbox ?? this.state.TerminOneriSlctbox;
			stateVars.dataSource_206028 = stateVars.TerminOneriSlctbox ?? this.state.TerminOneriSlctbox;
			stateVars.isComp1960132892Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "allleadpending_206028_value", "value", "TerminOneriSlctbox", "key", "key")), ReactSystemFunctions.convertToTypeByName("WITH_PROPOSAL", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp1830446497Visible = (((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "allleadpending_206028_value", "value", "TerminOneriSlctbox", "key", "key")), ReactSystemFunctions.convertToTypeByName("WITHOUT_PROPOSAL", "string")) || ReactSystemFunctions.isEqualTo(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "allleadpending_206028_value", "value", "TerminOneriSlctbox", "key", "key")), ReactSystemFunctions.convertToTypeByName("ALL", "string")))) === true ? "visible" : "hidden")
			
			stateVars.dataSource_1735739523 = stateVars.TM_GetPendingLeads ?? this.state.TM_GetPendingLeads;
			stateVars.isComp1390549895Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, "allleadpending_1735739523_value", "categoryName"), ReactSystemFunctions.convertToTypeByName("Kategori 2", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp1815110498Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, "allleadpending_1735739523_value", "categoryName"), ReactSystemFunctions.convertToTypeByName("Kategori 1", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp1829986670Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, "allleadpending_1735739523_value", "categoryName"), ReactSystemFunctions.convertToTypeByName("DEFAULT", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp1140624241Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, "allleadpending_1735739523_value", "categoryName"), ReactSystemFunctions.convertToTypeByName("Kategori 3", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp1733992048Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, "allleadpending_1735739523_value", "leadDurumu"), ReactSystemFunctions.convertToTypeByName("Takip ediliyor", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp1109289554Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, "allleadpending_1735739523_value", "leadDurumu"), ReactSystemFunctions.convertToTypeByName("2. Takip", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp794829871Visible = (((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, "allleadpending_1735739523_value", "processCode"), ReactSystemFunctions.convertToTypeByName("PENDING", "string")) || ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, "allleadpending_1735739523_value", "processCode"), ReactSystemFunctions.convertToTypeByName("TERMIN_PENDING", "string")) || ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, "allleadpending_1735739523_value", "processCode"), ReactSystemFunctions.convertToTypeByName("DELIVERY_PENDING", "string")))) === true ? "visible" : "hidden")
			stateVars.isComp259376128Visible = (((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, "allleadpending_1735739523_value", "processCode"), ReactSystemFunctions.convertToTypeByName("CUSTOMER_DECLINED", "string")) || ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, "allleadpending_1735739523_value", "processCode"), ReactSystemFunctions.convertToTypeByName("REJECTED", "string")))) === true ? "visible" : "hidden")
			stateVars.isComp1566137016Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, "allleadpending_1735739523_value", "processCode"), ReactSystemFunctions.convertToTypeByName("DELIVERED", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp1336712822Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, "allleadpending_1735739523_value", "processCode"), ReactSystemFunctions.convertToTypeByName("CLOSED", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp1662995164Visible = (((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, "allleadpending_1735739523_value", "processCode"), ReactSystemFunctions.convertToTypeByName("APPROVED", "string")) || ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, "allleadpending_1735739523_value", "processCode"), ReactSystemFunctions.convertToTypeByName("CREATED", "string")))) === true ? "visible" : "hidden")
			stateVars.isComp221575437Visible = (((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "allleadpending_206028_value", "value", "TerminOneriSlctbox", "key", "key")), ReactSystemFunctions.convertToTypeByName("WITHOUT_PROPOSAL", "string")) || ReactSystemFunctions.isEqualTo(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "allleadpending_206028_value", "value", "TerminOneriSlctbox", "key", "key")), ReactSystemFunctions.convertToTypeByName("ALL", "string")))) === true ? "visible" : "hidden")
			
			stateVars.dataSource_1676811829 = stateVars.TMGetApprovedList ?? this.state.TMGetApprovedList;
			stateVars.isComp1584996465Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, "allleadpending_1676811829_value", "categoryName"), ReactSystemFunctions.convertToTypeByName("Kategori 2", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp1928748848Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, "allleadpending_1676811829_value", "categoryName"), ReactSystemFunctions.convertToTypeByName("Kategori 1", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp533394467Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, "allleadpending_1676811829_value", "categoryName"), ReactSystemFunctions.convertToTypeByName("DEFAULT", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp932523823Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, "allleadpending_1676811829_value", "categoryName"), ReactSystemFunctions.convertToTypeByName("Kategori 3", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp958140466Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, "allleadpending_1676811829_value", "leadDurumu"), ReactSystemFunctions.convertToTypeByName("Takip ediliyor", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp1966365116Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, "allleadpending_1676811829_value", "leadDurumu"), ReactSystemFunctions.convertToTypeByName("2. Takip", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp1199564709Visible = (((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, "allleadpending_1676811829_value", "processCode"), ReactSystemFunctions.convertToTypeByName("PENDING", "string")) || ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, "allleadpending_1676811829_value", "processCode"), ReactSystemFunctions.convertToTypeByName("TERMIN_PENDING", "string")) || ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, "allleadpending_1676811829_value", "processCode"), ReactSystemFunctions.convertToTypeByName("DELIVERY_PENDING", "string")))) === true ? "visible" : "hidden")
			stateVars.isComp709157561Visible = (((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, "allleadpending_1676811829_value", "processCode"), ReactSystemFunctions.convertToTypeByName("CUSTOMER_DECLINED", "string")) || ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, "allleadpending_1676811829_value", "processCode"), ReactSystemFunctions.convertToTypeByName("REJECTED", "string")))) === true ? "visible" : "hidden")
			stateVars.isComp1306638514Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, "allleadpending_1676811829_value", "processCode"), ReactSystemFunctions.convertToTypeByName("DELIVERED", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp519501061Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, "allleadpending_1676811829_value", "processCode"), ReactSystemFunctions.convertToTypeByName("CLOSED", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp1994694700Visible = (((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, "allleadpending_1676811829_value", "processCode"), ReactSystemFunctions.convertToTypeByName("APPROVED", "string")) || ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, "allleadpending_1676811829_value", "processCode"), ReactSystemFunctions.convertToTypeByName("CREATED", "string")))) === true ? "visible" : "hidden")

	this.props.form?.setFieldsValue(formVars);
	this.setState(stateVars);
	KuikaAppManager.hideSpinner(this);

            this.setPageInitLoaded(true);
            return isErrorOccurred;
        }




		AllLeadPendingComponent_1684357334_onClick = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
KuikaAppManager.showSpinner(this);

				stateVars.SetValueOf = await ReactSystemFunctions.setValueOf(this, ReactSystemFunctions.convertToTypeByName("allleadpending_1393106492_value", "string"), "", null, false);
				stateVars.SetValueOf = await ReactSystemFunctions.setValueOf(this, ReactSystemFunctions.convertToTypeByName("allleadpending_226438964_value", "string"), "", null, false);
				stateVars.SetValueOf = await ReactSystemFunctions.setValueOf(this, ReactSystemFunctions.convertToTypeByName("allleadpending_1486438661_value", "string"), "", null, false);
				stateVars.SetValueOf = await ReactSystemFunctions.setValueOf(this, ReactSystemFunctions.convertToTypeByName("allleadpending_1888449157_value", "string"), "", null, false);
				stateVars.SetValueOf = await ReactSystemFunctions.setValueOf(this, ReactSystemFunctions.convertToTypeByName("allleadpending_1836228438_value", "string"), "", null, false);
				stateVars.SetValueOf = await ReactSystemFunctions.setValueOf(this, ReactSystemFunctions.convertToTypeByName("allleadpending_86365187_value", "string"), "", null, false);
				stateVars.SetValueOf = await ReactSystemFunctions.setValueOf(this, ReactSystemFunctions.convertToTypeByName("allleadpending_869961548_value", "string"), "", null, false);
				stateVars.SetValueOf = await ReactSystemFunctions.setValueOf(this, ReactSystemFunctions.convertToTypeByName("allleadpending_1904273601_value", "string"), "", null, false);
				stateVars.SetValueOf = await ReactSystemFunctions.setValueOf(this, ReactSystemFunctions.convertToTypeByName("allleadpending_1827823391_value", "string"), "", null, false);
				stateVars.SetValueOf = await ReactSystemFunctions.setValueOf(this, ReactSystemFunctions.convertToTypeByName("allleadpending_1735739523_value", "string"), "", ReactSystemFunctions.convertToTypeByName("selectedValues", "string"), false);
				stateVars.SetValueOf = await ReactSystemFunctions.setValueOf(this, ReactSystemFunctions.convertToTypeByName("allleadpending_1676811829_value", "string"), "", ReactSystemFunctions.convertToTypeByName("selectedValues", "string"), false);

		this.props.form?.setFieldsValue(formVars);
		
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.AllLeadPendingComponent_1684357334_onClick1_();
                  resolve();
                });
          })

            
            return isErrorOccurred;
        }
    AllLeadPendingComponent_1684357334_onClick1_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
		KuikaAppManager.increaseServerRequestCount();

        let localVar = {
				UserId_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.getMyUserId(), "Guid"),
				LeadCode_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "allleadpending_16517_value", "value", "", "", "")), "string"),
				MusteriAdi_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "allleadpending_1393106492_value", "value", "", "", "")), "string"),
				Tel_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "allleadpending_226438964_value", "value", "", "", "")), "string"),
				ProductName_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "allleadpending_1486438661_value", "value", "", "", "")), "string"),
				CategoryName_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "allleadpending_1888449157_value", "value", "TM_GetProductCategory", "categoryCode", "categoryName")), "string"),
				StoreIds_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "allleadpending_1836228438_value", "value", "TM_GetStore", "storeCode", "id")), "string"),
				SatisDanismaniIds_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "allleadpending_86365187_value", "value", "TM_GetSalesPerson", "kUserId", "kUserId")), "string"),
				ProcessCode_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "allleadpending_869961548_value", "value", "TM_GetLeadProcess", "id", "code")), "string"),
				StartDate_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "allleadpending_1904273601_value", "value", "", "", "")), "Date"),
				EndDate_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "allleadpending_1827823391_value", "value", "", "", "")), "Date"),
				TerminOnerisiDurumu_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "allleadpending_206028_value", "value", "TerminOneriSlctbox", "key", "key")), "string"),
				UserId_1: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.getMyUserId(), "Guid"),
				LeadCode_1: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "allleadpending_16517_value", "value", "", "", "")), "string"),
				MusteriAdi_1: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "allleadpending_1393106492_value", "value", "", "", "")), "string"),
				Tel_1: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "allleadpending_226438964_value", "value", "", "", "")), "string"),
				ProductName_1: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "allleadpending_1486438661_value", "value", "", "", "")), "string"),
				CategoryName_1: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "allleadpending_1888449157_value", "value", "TM_GetProductCategory", "categoryCode", "categoryName")), "string"),
				StoreIds_1: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "allleadpending_1836228438_value", "value", "TM_GetStore", "storeCode", "id")), "string"),
				SatisDanismaniIds_1: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "allleadpending_86365187_value", "value", "TM_GetSalesPerson", "kUserId", "kUserId")), "string"),
				ProcessCode_1: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "allleadpending_869961548_value", "value", "TM_GetLeadProcess", "id", "code")), "string"),
				StartDate_1: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "allleadpending_1904273601_value", "value", "", "", "")), "Date"),
				EndDate_1: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "allleadpending_1827823391_value", "value", "", "", "")), "Date")
        }

		
        if (true) {
        KuikaAppManager.showSpinner(this);
        }
        let result = await KuikaAppManager.ApiRequest(this, "AllLeadPending/AllLeadPendingComponent_1684357334_onClick1_", localVar)
        if (!KMainFunctions.IsResStatus2XX(result)) return true;

			stateVars.TM_GetPendingLeads = result?.data.tM_GetPendingLeads;
			
			stateVars.TMGetApprovedList = result?.data.tmGetApprovedList;
			
			this.props.form?.setFieldsValue(formVars);
			
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.AllLeadPendingComponent_1684357334_onClick2_();
                  resolve();
                });
          })



        
        KuikaAppManager.hideSpinner(this);
        return isErrorOccurred;
    }
		AllLeadPendingComponent_1684357334_onClick2_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }

				
				stateVars.dataSource_1735739523 = stateVars.TM_GetPendingLeads ?? this.state.TM_GetPendingLeads;
				
				stateVars.dataSource_1676811829 = stateVars.TMGetApprovedList ?? this.state.TMGetApprovedList;

		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

            
            return isErrorOccurred;
        }





		AllLeadPendingComponent_788616_onClick = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
KuikaAppManager.showSpinner(this);

				stateVars.SetValueOf = await ReactSystemFunctions.setValueOf(this, ReactSystemFunctions.convertToTypeByName("allleadpending_1735739523_value", "string"), "", ReactSystemFunctions.convertToTypeByName("selectedValues", "string"), false);
				stateVars.SetValueOf = await ReactSystemFunctions.setValueOf(this, ReactSystemFunctions.convertToTypeByName("allleadpending_1676811829_value", "string"), "", ReactSystemFunctions.convertToTypeByName("selectedValues", "string"), false);

		this.props.form?.setFieldsValue(formVars);
		
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.AllLeadPendingComponent_788616_onClick1_();
                  resolve();
                });
          })

            
            return isErrorOccurred;
        }
    AllLeadPendingComponent_788616_onClick1_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
		KuikaAppManager.increaseServerRequestCount();

        let localVar = {
				UserId_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.getMyUserId(), "Guid"),
				LeadCode_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "allleadpending_16517_value", "value", "", "", "")), "string"),
				MusteriAdi_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "allleadpending_1393106492_value", "value", "", "", "")), "string"),
				Tel_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "allleadpending_226438964_value", "value", "", "", "")), "string"),
				ProductName_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "allleadpending_1486438661_value", "value", "", "", "")), "string"),
				CategoryName_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "allleadpending_1888449157_value", "value", "TM_GetProductCategory", "categoryCode", "categoryName")), "string"),
				StoreIds_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "allleadpending_1836228438_value", "value", "TM_GetStore", "storeCode", "id")), "string"),
				SatisDanismaniIds_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "allleadpending_86365187_value", "value", "TM_GetSalesPerson", "kUserId", "kUserId")), "string"),
				ProcessCode_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "allleadpending_869961548_value", "value", "TM_GetLeadProcess", "id", "code")), "string"),
				StartDate_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "allleadpending_1904273601_value", "value", "", "", "")), "Date"),
				EndDate_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "allleadpending_1827823391_value", "value", "", "", "")), "Date"),
				TerminOnerisiDurumu_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "allleadpending_206028_value", "value", "TerminOneriSlctbox", "key", "key")), "string"),
				UserId_1: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.getMyUserId(), "Guid"),
				LeadCode_1: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "allleadpending_16517_value", "value", "", "", "")), "string"),
				MusteriAdi_1: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "allleadpending_1393106492_value", "value", "", "", "")), "string"),
				Tel_1: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "allleadpending_226438964_value", "value", "", "", "")), "string"),
				ProductName_1: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "allleadpending_1486438661_value", "value", "", "", "")), "string"),
				CategoryName_1: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "allleadpending_1888449157_value", "value", "TM_GetProductCategory", "categoryCode", "categoryName")), "string"),
				StoreIds_1: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "allleadpending_1836228438_value", "value", "TM_GetStore", "storeCode", "id")), "string"),
				SatisDanismaniIds_1: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "allleadpending_86365187_value", "value", "TM_GetSalesPerson", "kUserId", "kUserId")), "string"),
				ProcessCode_1: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "allleadpending_869961548_value", "value", "TM_GetLeadProcess", "id", "code")), "string"),
				StartDate_1: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "allleadpending_1904273601_value", "value", "", "", "")), "Date"),
				EndDate_1: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "allleadpending_1827823391_value", "value", "", "", "")), "Date")
        }

		
        if (true) {
        KuikaAppManager.showSpinner(this);
        }
        let result = await KuikaAppManager.ApiRequest(this, "AllLeadPending/AllLeadPendingComponent_788616_onClick1_", localVar)
        if (!KMainFunctions.IsResStatus2XX(result)) return true;

			stateVars.TM_GetPendingLeads = result?.data.tM_GetPendingLeads;
			
			stateVars.TMGetApprovedList = result?.data.tmGetApprovedList;
			
			this.props.form?.setFieldsValue(formVars);
			
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.AllLeadPendingComponent_788616_onClick2_();
                  resolve();
                });
          })



        
        KuikaAppManager.hideSpinner(this);
        return isErrorOccurred;
    }
		AllLeadPendingComponent_788616_onClick2_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }

				
				stateVars.dataSource_1735739523 = stateVars.TM_GetPendingLeads ?? this.state.TM_GetPendingLeads;
				
				stateVars.dataSource_1676811829 = stateVars.TMGetApprovedList ?? this.state.TMGetApprovedList;

		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

            
            return isErrorOccurred;
        }





    AllLeadPendingComponent_16517_onChange = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
		KuikaAppManager.increaseServerRequestCount();

        let localVar = {
				UserId_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.getMyUserId(), "Guid"),
				LeadCode_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "allleadpending_16517_value", "value", "", "", "")), "string"),
				MusteriAdi_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "allleadpending_1393106492_value", "value", "", "", "")), "string"),
				Tel_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "allleadpending_226438964_value", "value", "", "", "")), "string"),
				ProductName_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "allleadpending_1486438661_value", "value", "", "", "")), "string"),
				CategoryName_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "allleadpending_1888449157_value", "value", "TM_GetProductCategory", "categoryCode", "categoryName")), "string"),
				StoreIds_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "allleadpending_1836228438_value", "value", "TM_GetStore", "storeCode", "id")), "string"),
				SatisDanismaniIds_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "allleadpending_86365187_value", "value", "TM_GetSalesPerson", "kUserId", "kUserId")), "string"),
				ProcessCode_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "allleadpending_869961548_value", "value", "TM_GetLeadProcess", "id", "code")), "string"),
				StartDate_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "allleadpending_1904273601_value", "value", "", "", "")), "Date"),
				EndDate_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "allleadpending_1827823391_value", "value", "", "", "")), "Date"),
				TerminOnerisiDurumu_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "allleadpending_206028_value", "value", "TerminOneriSlctbox", "key", "key")), "string"),
				UserId_1: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.getMyUserId(), "Guid"),
				LeadCode_1: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "allleadpending_16517_value", "value", "", "", "")), "string"),
				MusteriAdi_1: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "allleadpending_1393106492_value", "value", "", "", "")), "string"),
				Tel_1: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "allleadpending_226438964_value", "value", "", "", "")), "string"),
				ProductName_1: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "allleadpending_1486438661_value", "value", "", "", "")), "string"),
				CategoryName_1: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "allleadpending_1888449157_value", "value", "TM_GetProductCategory", "categoryCode", "categoryName")), "string"),
				StoreIds_1: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "allleadpending_1836228438_value", "value", "TM_GetStore", "storeCode", "id")), "string"),
				SatisDanismaniIds_1: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "allleadpending_86365187_value", "value", "TM_GetSalesPerson", "kUserId", "kUserId")), "string"),
				ProcessCode_1: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "allleadpending_869961548_value", "value", "TM_GetLeadProcess", "id", "code")), "string"),
				StartDate_1: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "allleadpending_1904273601_value", "value", "", "", "")), "Date"),
				EndDate_1: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "allleadpending_1827823391_value", "value", "", "", "")), "Date")
        }

		KuikaAppManager.showSpinner(this);
		
        if (true) {
        KuikaAppManager.showSpinner(this);
        }
        let result = await KuikaAppManager.ApiRequest(this, "AllLeadPending/AllLeadPendingComponent_16517_onChange", localVar)
        if (!KMainFunctions.IsResStatus2XX(result)) return true;

			stateVars.TM_GetPendingLeads = result?.data.tM_GetPendingLeads;
			
			stateVars.TMGetApprovedList = result?.data.tmGetApprovedList;
			
			this.props.form?.setFieldsValue(formVars);
			
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.AllLeadPendingComponent_16517_onChange1_();
                  resolve();
                });
          })



        
        KuikaAppManager.hideSpinner(this);
        return isErrorOccurred;
    }
		AllLeadPendingComponent_16517_onChange1_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }

				
				stateVars.dataSource_1735739523 = stateVars.TM_GetPendingLeads ?? this.state.TM_GetPendingLeads;
				
				stateVars.dataSource_1676811829 = stateVars.TMGetApprovedList ?? this.state.TMGetApprovedList;

		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

            
            return isErrorOccurred;
        }




		AllLeadPendingComponent_212835_onClick = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
KuikaAppManager.showSpinner(this);

				stateVars.SetValueOf = await ReactSystemFunctions.setValueOf(this, ReactSystemFunctions.convertToTypeByName("allleadpending_16517_value", "string"), "", null, false);

		this.props.form?.setFieldsValue(formVars);
		
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.AllLeadPendingComponent_212835_onClick1_();
                  resolve();
                });
          })

            
            return isErrorOccurred;
        }
    AllLeadPendingComponent_212835_onClick1_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
		KuikaAppManager.increaseServerRequestCount();

        let localVar = {
				UserId_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.getMyUserId(), "Guid"),
				LeadCode_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "allleadpending_16517_value", "value", "", "", "")), "string"),
				MusteriAdi_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "allleadpending_1393106492_value", "value", "", "", "")), "string"),
				Tel_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "allleadpending_226438964_value", "value", "", "", "")), "string"),
				ProductName_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "allleadpending_1486438661_value", "value", "", "", "")), "string"),
				CategoryName_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "allleadpending_1888449157_value", "value", "TM_GetProductCategory", "categoryCode", "categoryName")), "string"),
				StoreIds_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "allleadpending_1836228438_value", "value", "TM_GetStore", "storeCode", "id")), "string"),
				SatisDanismaniIds_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "allleadpending_86365187_value", "value", "TM_GetSalesPerson", "kUserId", "kUserId")), "string"),
				ProcessCode_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "allleadpending_869961548_value", "value", "TM_GetLeadProcess", "id", "code")), "string"),
				StartDate_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "allleadpending_1904273601_value", "value", "", "", "")), "Date"),
				EndDate_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "allleadpending_1827823391_value", "value", "", "", "")), "Date"),
				TerminOnerisiDurumu_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "allleadpending_206028_value", "value", "TerminOneriSlctbox", "key", "key")), "string"),
				UserId_1: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.getMyUserId(), "Guid"),
				LeadCode_1: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "allleadpending_16517_value", "value", "", "", "")), "string"),
				MusteriAdi_1: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "allleadpending_1393106492_value", "value", "", "", "")), "string"),
				Tel_1: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "allleadpending_226438964_value", "value", "", "", "")), "string"),
				ProductName_1: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "allleadpending_1486438661_value", "value", "", "", "")), "string"),
				CategoryName_1: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "allleadpending_1888449157_value", "value", "TM_GetProductCategory", "categoryCode", "categoryName")), "string"),
				StoreIds_1: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "allleadpending_1836228438_value", "value", "TM_GetStore", "storeCode", "id")), "string"),
				SatisDanismaniIds_1: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "allleadpending_86365187_value", "value", "TM_GetSalesPerson", "kUserId", "kUserId")), "string"),
				ProcessCode_1: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "allleadpending_869961548_value", "value", "TM_GetLeadProcess", "id", "code")), "string"),
				StartDate_1: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "allleadpending_1904273601_value", "value", "", "", "")), "Date"),
				EndDate_1: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "allleadpending_1827823391_value", "value", "", "", "")), "Date")
        }

		
        if (true) {
        KuikaAppManager.showSpinner(this);
        }
        let result = await KuikaAppManager.ApiRequest(this, "AllLeadPending/AllLeadPendingComponent_212835_onClick1_", localVar)
        if (!KMainFunctions.IsResStatus2XX(result)) return true;

			stateVars.TM_GetPendingLeads = result?.data.tM_GetPendingLeads;
			
			stateVars.TMGetApprovedList = result?.data.tmGetApprovedList;
			
			this.props.form?.setFieldsValue(formVars);
			
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.AllLeadPendingComponent_212835_onClick2_();
                  resolve();
                });
          })



        
        KuikaAppManager.hideSpinner(this);
        return isErrorOccurred;
    }
		AllLeadPendingComponent_212835_onClick2_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }

				
				stateVars.dataSource_1735739523 = stateVars.TM_GetPendingLeads ?? this.state.TM_GetPendingLeads;
				
				stateVars.dataSource_1676811829 = stateVars.TMGetApprovedList ?? this.state.TMGetApprovedList;

		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

            
            return isErrorOccurred;
        }





		AllLeadPendingComponent_509274_onChange = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
if (ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "allleadpending_509274_checked", "checked", "", "", "")), true)) {
            KuikaAppManager.showSpinner(this);

				stateVars.ChangeVisibilityOf = await ReactSystemFunctions.changeVisibilityOf(this, ReactSystemFunctions.convertToTypeByName("isComp384188Visible", "string"), ReactSystemFunctions.convertToTypeByName("hidden", "string"));

		this.props.form?.setFieldsValue(formVars);
		
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.AllLeadPendingComponent_509274_onChange1_();
                  resolve();
                });
          })

        } else {
            
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.AllLeadPendingComponent_509274_onChange1_();
                  resolve();
                });
          })
        }

            
            return isErrorOccurred;
        }
		AllLeadPendingComponent_509274_onChange1_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
if (ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "allleadpending_509274_checked", "checked", "", "", "")), true)) {
            
				stateVars.ChangeVisibilityOf = await ReactSystemFunctions.changeVisibilityOf(this, ReactSystemFunctions.convertToTypeByName("isComp222070Visible", "string"), ReactSystemFunctions.convertToTypeByName("visible", "string"));

		this.props.form?.setFieldsValue(formVars);
		
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.AllLeadPendingComponent_509274_onChange2_();
                  resolve();
                });
          })

        } else {
            
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.AllLeadPendingComponent_509274_onChange2_();
                  resolve();
                });
          })
        }

            
            return isErrorOccurred;
        }
		AllLeadPendingComponent_509274_onChange2_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
if (ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "allleadpending_509274_checked", "checked", "", "", "")), false)) {
            
				stateVars.ChangeVisibilityOf = await ReactSystemFunctions.changeVisibilityOf(this, ReactSystemFunctions.convertToTypeByName("isComp384188Visible", "string"), ReactSystemFunctions.convertToTypeByName("visible", "string"));

		this.props.form?.setFieldsValue(formVars);
		
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.AllLeadPendingComponent_509274_onChange3_();
                  resolve();
                });
          })

        } else {
            
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.AllLeadPendingComponent_509274_onChange3_();
                  resolve();
                });
          })
        }

            
            return isErrorOccurred;
        }
		AllLeadPendingComponent_509274_onChange3_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
if (ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "allleadpending_509274_checked", "checked", "", "", "")), false)) {
            
				stateVars.ChangeVisibilityOf = await ReactSystemFunctions.changeVisibilityOf(this, ReactSystemFunctions.convertToTypeByName("isComp222070Visible", "string"), ReactSystemFunctions.convertToTypeByName("hidden", "string"));

		this.props.form?.setFieldsValue(formVars);
		
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.AllLeadPendingComponent_509274_onChange4_();
                  resolve();
                });
          })

        } else {
            
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.AllLeadPendingComponent_509274_onChange4_();
                  resolve();
                });
          })
        }

            
            return isErrorOccurred;
        }
		AllLeadPendingComponent_509274_onChange4_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
if (ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "allleadpending_509274_checked", "checked", "", "", "")), false)) {
            
				stateVars.ChangeVisibilityOf = await ReactSystemFunctions.changeVisibilityOf(this, ReactSystemFunctions.convertToTypeByName("isComp340825Visible", "string"), ReactSystemFunctions.convertToTypeByName("visible", "string"));

		this.props.form?.setFieldsValue(formVars);
		
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.AllLeadPendingComponent_509274_onChange5_();
                  resolve();
                });
          })

        } else {
            
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.AllLeadPendingComponent_509274_onChange5_();
                  resolve();
                });
          })
        }

            
            return isErrorOccurred;
        }
		AllLeadPendingComponent_509274_onChange5_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
if (ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "allleadpending_509274_checked", "checked", "", "", "")), false)) {
            
				stateVars.ChangeVisibilityOf = await ReactSystemFunctions.changeVisibilityOf(this, ReactSystemFunctions.convertToTypeByName("isComp324523243Visible", "string"), ReactSystemFunctions.convertToTypeByName("visible", "string"));

		this.props.form?.setFieldsValue(formVars);
		
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.AllLeadPendingComponent_509274_onChange6_();
                  resolve();
                });
          })

        } else {
            
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.AllLeadPendingComponent_509274_onChange6_();
                  resolve();
                });
          })
        }

            
            return isErrorOccurred;
        }
		AllLeadPendingComponent_509274_onChange6_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
if (ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "allleadpending_509274_checked", "checked", "", "", "")), true)) {
            
				stateVars.ChangeVisibilityOf = await ReactSystemFunctions.changeVisibilityOf(this, ReactSystemFunctions.convertToTypeByName("isComp340825Visible", "string"), ReactSystemFunctions.convertToTypeByName("hidden", "string"));

		this.props.form?.setFieldsValue(formVars);
		
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.AllLeadPendingComponent_509274_onChange7_();
                  resolve();
                });
          })

        } else {
            
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.AllLeadPendingComponent_509274_onChange7_();
                  resolve();
                });
          })
        }

            
            return isErrorOccurred;
        }
		AllLeadPendingComponent_509274_onChange7_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
if (ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "allleadpending_509274_checked", "checked", "", "", "")), true)) {
            
				stateVars.ChangeVisibilityOf = await ReactSystemFunctions.changeVisibilityOf(this, ReactSystemFunctions.convertToTypeByName("isComp324523243Visible", "string"), ReactSystemFunctions.convertToTypeByName("hidden", "string"));

		this.props.form?.setFieldsValue(formVars);
		
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.AllLeadPendingComponent_509274_onChange8_();
                  resolve();
                });
          })

        } else {
            
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.AllLeadPendingComponent_509274_onChange8_();
                  resolve();
                });
          })
        }

            
            return isErrorOccurred;
        }
		AllLeadPendingComponent_509274_onChange8_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
if (ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "allleadpending_509274_checked", "checked", "", "", "")), true)) {
            
				stateVars.ChangeVisibilityOf = await ReactSystemFunctions.changeVisibilityOf(this, ReactSystemFunctions.convertToTypeByName("isComp348079Visible", "string"), ReactSystemFunctions.convertToTypeByName("visible", "string"));

		this.props.form?.setFieldsValue(formVars);
		
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.AllLeadPendingComponent_509274_onChange9_();
                  resolve();
                });
          })

        } else {
            
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.AllLeadPendingComponent_509274_onChange9_();
                  resolve();
                });
          })
        }

            
            return isErrorOccurred;
        }
		AllLeadPendingComponent_509274_onChange9_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
if (ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "allleadpending_509274_checked", "checked", "", "", "")), false)) {
            
				stateVars.ChangeVisibilityOf = await ReactSystemFunctions.changeVisibilityOf(this, ReactSystemFunctions.convertToTypeByName("isComp348079Visible", "string"), ReactSystemFunctions.convertToTypeByName("hidden", "string"));

		this.props.form?.setFieldsValue(formVars);
		
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.AllLeadPendingComponent_509274_onChange10_();
                  resolve();
                });
          })

        } else {
            
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.AllLeadPendingComponent_509274_onChange10_();
                  resolve();
                });
          })
        }

            
            return isErrorOccurred;
        }
		AllLeadPendingComponent_509274_onChange10_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }

				stateVars.SetValueOf = await ReactSystemFunctions.setValueOf(this, ReactSystemFunctions.convertToTypeByName("allleadpending_1735739523_value", "string"), "", ReactSystemFunctions.convertToTypeByName("selectedValues", "string"), false);
				stateVars.SetValueOf = await ReactSystemFunctions.setValueOf(this, ReactSystemFunctions.convertToTypeByName("allleadpending_1676811829_value", "string"), "", ReactSystemFunctions.convertToTypeByName("selectedValues", "string"), false);

		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

            
            return isErrorOccurred;
        }












    AllLeadPendingComponent_206028_onChange = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
		KuikaAppManager.increaseServerRequestCount();

        let localVar = {
				UserId_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.getMyUserId(), "Guid"),
				LeadCode_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "allleadpending_16517_value", "value", "", "", "")), "string"),
				MusteriAdi_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "allleadpending_1393106492_value", "value", "", "", "")), "string"),
				Tel_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "allleadpending_226438964_value", "value", "", "", "")), "string"),
				ProductName_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "allleadpending_1486438661_value", "value", "", "", "")), "string"),
				CategoryName_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "allleadpending_1888449157_value", "value", "TM_GetProductCategory", "categoryCode", "categoryName")), "string"),
				StoreIds_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "allleadpending_1836228438_value", "value", "TM_GetStore", "storeCode", "id")), "string"),
				SatisDanismaniIds_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "allleadpending_86365187_value", "value", "TM_GetSalesPerson", "kUserId", "kUserId")), "string"),
				ProcessCode_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "allleadpending_869961548_value", "value", "TM_GetLeadProcess", "id", "code")), "string"),
				StartDate_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "allleadpending_1904273601_value", "value", "", "", "")), "Date"),
				EndDate_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "allleadpending_1827823391_value", "value", "", "", "")), "Date"),
				TerminOnerisiDurumu_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "allleadpending_206028_value", "value", "TerminOneriSlctbox", "key", "key")), "string")
        }

		KuikaAppManager.showSpinner(this);
		
        if (true) {
        KuikaAppManager.showSpinner(this);
        }
        let result = await KuikaAppManager.ApiRequest(this, "AllLeadPending/AllLeadPendingComponent_206028_onChange", localVar)
        if (!KMainFunctions.IsResStatus2XX(result)) return true;

			stateVars.TM_GetPendingLeads = result?.data.tM_GetPendingLeads;
			
			this.props.form?.setFieldsValue(formVars);
			
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.AllLeadPendingComponent_206028_onChange1_();
                  resolve();
                });
          })



        
        KuikaAppManager.hideSpinner(this);
        return isErrorOccurred;
    }
		AllLeadPendingComponent_206028_onChange1_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }

				stateVars.SetValueOf = await ReactSystemFunctions.setValueOf(this, ReactSystemFunctions.convertToTypeByName("allleadpending_1735739523_value", "string"), "", ReactSystemFunctions.convertToTypeByName("selectedValues", "string"), false);
				stateVars.isComp1960132892Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "allleadpending_206028_value", "value", "TerminOneriSlctbox", "key", "key")), "WITH_PROPOSAL")) === true ? "visible" : "hidden")
				stateVars.isComp1830446497Visible = (((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "allleadpending_206028_value", "value", "TerminOneriSlctbox", "key", "key")), "WITHOUT_PROPOSAL") || ReactSystemFunctions.isEqualTo(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "allleadpending_206028_value", "value", "TerminOneriSlctbox", "key", "key")), "ALL"))) === true ? "visible" : "hidden")
				stateVars.isComp1830446497Visible = (((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "allleadpending_206028_value", "value", "TerminOneriSlctbox", "key", "key")), "WITHOUT_PROPOSAL") || ReactSystemFunctions.isEqualTo(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "allleadpending_206028_value", "value", "TerminOneriSlctbox", "key", "key")), "ALL"))) === true ? "visible" : "hidden")
				
				stateVars.dataSource_1735739523 = stateVars.TM_GetPendingLeads ?? this.state.TM_GetPendingLeads;
				stateVars.isComp221575437Visible = (((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "allleadpending_206028_value", "value", "TerminOneriSlctbox", "key", "key")), "WITHOUT_PROPOSAL") || ReactSystemFunctions.isEqualTo(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "allleadpending_206028_value", "value", "TerminOneriSlctbox", "key", "key")), "ALL"))) === true ? "visible" : "hidden")
				stateVars.isComp221575437Visible = (((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "allleadpending_206028_value", "value", "TerminOneriSlctbox", "key", "key")), "WITHOUT_PROPOSAL") || ReactSystemFunctions.isEqualTo(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "allleadpending_206028_value", "value", "TerminOneriSlctbox", "key", "key")), "ALL"))) === true ? "visible" : "hidden")

		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

            
            return isErrorOccurred;
        }




    AllLeadPendingComponent_1960132892_onClick = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
		KuikaAppManager.increaseServerRequestCount();

        let localVar = {
				UserId_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.getMyUserId(), "Guid"),
				LeadIds_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "allleadpending_1735739523_value", "selectedValues", "TM_GetPendingLeads", "", "")), "string")
        }

		KuikaAppManager.showSpinner(this);
		
        if (true) {
        KuikaAppManager.showSpinner(this);
        }
        let result = await KuikaAppManager.ApiRequest(this, "AllLeadPending/AllLeadPendingComponent_1960132892_onClick", localVar)
        if (!KMainFunctions.IsResStatus2XX(result)) return true;

			stateVars.TM_BulkApproveTerminProposals = result?.data.tM_BulkApproveTerminProposals;
			this.props.form?.setFieldsValue(formVars);
			
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.AllLeadPendingComponent_1960132892_onClick1_();
                  resolve();
                });
          })



        
        KuikaAppManager.hideSpinner(this);
        return isErrorOccurred;
    }
		AllLeadPendingComponent_1960132892_onClick1_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }

				stateVars.Notify = await ReactSystemFunctions.notify(this, ReactSystemFunctions.toString(this, (stateVars.TM_BulkApproveTerminProposals !== undefined ? (stateVars.TM_BulkApproveTerminProposals?.length > 0 ? stateVars.TM_BulkApproveTerminProposals[0].message : null) : (this.state.TM_BulkApproveTerminProposals?.length > 0 ? this.state.TM_BulkApproveTerminProposals[0].message : null))), ReactSystemFunctions.convertToTypeByName("default", "string"), ReactSystemFunctions.convertToTypeByName("bottom-right", "string"), 4, ReactSystemFunctions.convertToTypeByName("", "string"), ReactSystemFunctions.convertToTypeByName("", "string"), 0);

		this.props.form?.setFieldsValue(formVars);
		
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.AllLeadPendingComponent_1960132892_onClick2_();
                  resolve();
                });
          })

            
            return isErrorOccurred;
        }
    AllLeadPendingComponent_1960132892_onClick2_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
		KuikaAppManager.increaseServerRequestCount();

        let localVar = {
				UserId_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.getMyUserId(), "Guid"),
				LeadCode_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "allleadpending_16517_value", "value", "", "", "")), "string"),
				MusteriAdi_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "allleadpending_1393106492_value", "value", "", "", "")), "string"),
				Tel_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "allleadpending_226438964_value", "value", "", "", "")), "string"),
				ProductName_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "allleadpending_1486438661_value", "value", "", "", "")), "string"),
				CategoryName_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "allleadpending_1888449157_value", "value", "TM_GetProductCategory", "categoryCode", "categoryName")), "string"),
				StoreIds_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "allleadpending_1836228438_value", "value", "TM_GetStore", "storeCode", "id")), "string"),
				SatisDanismaniIds_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "allleadpending_86365187_value", "value", "TM_GetSalesPerson", "kUserId", "kUserId")), "string"),
				ProcessCode_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "allleadpending_869961548_value", "value", "TM_GetLeadProcess", "id", "code")), "string"),
				StartDate_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "allleadpending_1904273601_value", "value", "", "", "")), "Date"),
				EndDate_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "allleadpending_1827823391_value", "value", "", "", "")), "Date"),
				TerminOnerisiDurumu_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "allleadpending_206028_value", "value", "TerminOneriSlctbox", "key", "key")), "string")
        }

		
        if (true) {
        KuikaAppManager.showSpinner(this);
        }
        let result = await KuikaAppManager.ApiRequest(this, "AllLeadPending/AllLeadPendingComponent_1960132892_onClick2_", localVar)
        if (!KMainFunctions.IsResStatus2XX(result)) return true;

			stateVars.TM_GetPendingLeads = result?.data.tM_GetPendingLeads;
			
			this.props.form?.setFieldsValue(formVars);
			
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.AllLeadPendingComponent_1960132892_onClick3_();
                  resolve();
                });
          })



        
        KuikaAppManager.hideSpinner(this);
        return isErrorOccurred;
    }
		AllLeadPendingComponent_1960132892_onClick3_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
if (ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, (stateVars.TM_BulkApproveTerminProposals !== undefined ? (stateVars.TM_BulkApproveTerminProposals?.length > 0 ? stateVars.TM_BulkApproveTerminProposals[0].success : null) : (this.state.TM_BulkApproveTerminProposals?.length > 0 ? this.state.TM_BulkApproveTerminProposals[0].success : null))), true)) {
            
				stateVars.SetValueOf = await ReactSystemFunctions.setValueOf(this, ReactSystemFunctions.convertToTypeByName("allleadpending_1735739523_value", "string"), "", ReactSystemFunctions.convertToTypeByName("selectedValues", "string"), false);

		this.props.form?.setFieldsValue(formVars);
		
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.AllLeadPendingComponent_1960132892_onClick4_();
                  resolve();
                });
          })

        } else {
            
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.AllLeadPendingComponent_1960132892_onClick4_();
                  resolve();
                });
          })
        }

            
            return isErrorOccurred;
        }
		AllLeadPendingComponent_1960132892_onClick4_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }

				
				stateVars.dataSource_1735739523 = stateVars.TM_GetPendingLeads ?? this.state.TM_GetPendingLeads;

		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

            
            return isErrorOccurred;
        }








    AllLeadPendingComponent_34070132_onClick = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
		KuikaAppManager.increaseServerRequestCount();

        let localVar = {
				UserId_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.getMyUserId(), "Guid"),
				LeadIds_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "allleadpending_1735739523_value", "selectedValues", "TM_GetPendingLeads", "", "")), "string"),
				EstimatedYear_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toInteger(this, ReactSystemFunctions.value(this, "allleadpending_2038824790_value", "value", "", "key", "")), "number"),
				EstimatedMonth_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toInteger(this, ReactSystemFunctions.value(this, "allleadpending_2007552957_value", "value", "", "key", "")), "number")
        }

		KuikaAppManager.showSpinner(this);
		
        if (true) {
        KuikaAppManager.showSpinner(this);
        }
        let result = await KuikaAppManager.ApiRequest(this, "AllLeadPending/AllLeadPendingComponent_34070132_onClick", localVar)
        if (!KMainFunctions.IsResStatus2XX(result)) return true;

			stateVars.TM_BulkSetTerminAndApprove = result?.data.tM_BulkSetTerminAndApprove;
			this.props.form?.setFieldsValue(formVars);
			
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.AllLeadPendingComponent_34070132_onClick1_();
                  resolve();
                });
          })



        
        KuikaAppManager.hideSpinner(this);
        return isErrorOccurred;
    }
		AllLeadPendingComponent_34070132_onClick1_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }

				stateVars.Notify = await ReactSystemFunctions.notify(this, ReactSystemFunctions.toString(this, (stateVars.TM_BulkSetTerminAndApprove !== undefined ? (stateVars.TM_BulkSetTerminAndApprove?.length > 0 ? stateVars.TM_BulkSetTerminAndApprove[0].message : null) : (this.state.TM_BulkSetTerminAndApprove?.length > 0 ? this.state.TM_BulkSetTerminAndApprove[0].message : null))), ReactSystemFunctions.convertToTypeByName("default", "string"), ReactSystemFunctions.convertToTypeByName("bottom-right", "string"), 4, ReactSystemFunctions.convertToTypeByName("", "string"), ReactSystemFunctions.convertToTypeByName("", "string"), 0);

		this.props.form?.setFieldsValue(formVars);
		
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.AllLeadPendingComponent_34070132_onClick2_();
                  resolve();
                });
          })

            
            return isErrorOccurred;
        }
    AllLeadPendingComponent_34070132_onClick2_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
		KuikaAppManager.increaseServerRequestCount();

        let localVar = {
				UserId_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.getMyUserId(), "Guid"),
				LeadCode_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "allleadpending_16517_value", "value", "", "", "")), "string"),
				MusteriAdi_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "allleadpending_1393106492_value", "value", "", "", "")), "string"),
				Tel_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "allleadpending_226438964_value", "value", "", "", "")), "string"),
				ProductName_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "allleadpending_1486438661_value", "value", "", "", "")), "string"),
				CategoryName_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "allleadpending_1888449157_value", "value", "TM_GetProductCategory", "categoryCode", "categoryName")), "string"),
				StoreIds_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "allleadpending_1836228438_value", "value", "TM_GetStore", "storeCode", "id")), "string"),
				SatisDanismaniIds_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "allleadpending_86365187_value", "value", "TM_GetSalesPerson", "kUserId", "kUserId")), "string"),
				ProcessCode_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "allleadpending_869961548_value", "value", "TM_GetLeadProcess", "id", "code")), "string"),
				StartDate_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "allleadpending_1904273601_value", "value", "", "", "")), "Date"),
				EndDate_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "allleadpending_1827823391_value", "value", "", "", "")), "Date"),
				TerminOnerisiDurumu_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "allleadpending_206028_value", "value", "TerminOneriSlctbox", "key", "key")), "string")
        }

		
        if (true) {
        KuikaAppManager.showSpinner(this);
        }
        let result = await KuikaAppManager.ApiRequest(this, "AllLeadPending/AllLeadPendingComponent_34070132_onClick2_", localVar)
        if (!KMainFunctions.IsResStatus2XX(result)) return true;

			stateVars.TM_GetPendingLeads = result?.data.tM_GetPendingLeads;
			
			this.props.form?.setFieldsValue(formVars);
			
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.AllLeadPendingComponent_34070132_onClick3_();
                  resolve();
                });
          })



        
        KuikaAppManager.hideSpinner(this);
        return isErrorOccurred;
    }
		AllLeadPendingComponent_34070132_onClick3_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
if (ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, (stateVars.TM_BulkSetTerminAndApprove !== undefined ? (stateVars.TM_BulkSetTerminAndApprove?.length > 0 ? stateVars.TM_BulkSetTerminAndApprove[0].success : null) : (this.state.TM_BulkSetTerminAndApprove?.length > 0 ? this.state.TM_BulkSetTerminAndApprove[0].success : null))), true)) {
            
				stateVars.SetValueOf = await ReactSystemFunctions.setValueOf(this, ReactSystemFunctions.convertToTypeByName("allleadpending_1735739523_value", "string"), "", ReactSystemFunctions.convertToTypeByName("selectedValues", "string"), false);

		this.props.form?.setFieldsValue(formVars);
		
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.AllLeadPendingComponent_34070132_onClick4_();
                  resolve();
                });
          })

        } else {
            
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.AllLeadPendingComponent_34070132_onClick4_();
                  resolve();
                });
          })
        }

            
            return isErrorOccurred;
        }
		AllLeadPendingComponent_34070132_onClick4_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }

				
				stateVars.dataSource_1735739523 = stateVars.TM_GetPendingLeads ?? this.state.TM_GetPendingLeads;

		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

            
            return isErrorOccurred;
        }








		AllLeadPendingComponent_770563660_onClick = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
KuikaAppManager.showSpinner(this);

					KuikaAppManager.prepareForNavigation();
						KuikaAppManager.addToPageInputVariables("PopOnayBekleyen", "LeadId", ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, "allleadpending_1735739523_value", "leadId"), "Guid"));

				stateVars.NAVIGATE = await ReactSystemFunctions.navigate(this, undefined, "AllLeadPending", "PopOnayBekleyen", "", "7d969ddf-5801-4eb6-b92b-12be35bdd565", "1991843134", null, "right", "true", "80%", "100vh", true, false);

		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

            
            return isErrorOccurred;
        }


		AllLeadPendingComponent_1743018118_onClick = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
KuikaAppManager.showSpinner(this);

					KuikaAppManager.prepareForNavigation();
						KuikaAppManager.addToPageInputVariables("LeadDetailTemp", "LeadId", ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, "allleadpending_1735739523_value", "leadId"), "Guid"));

				stateVars.NAVIGATE = await ReactSystemFunctions.navigate(this, undefined, "AllLeadPending", "LeadDetailTemp", "", "7d969ddf-5801-4eb6-b92b-12be35bdd565", "293474136", null, "right", "true", "90%", "100vh", true, false);

		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

            
            return isErrorOccurred;
        }


		AllLeadPendingComponent_1492248385_onClick = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
KuikaAppManager.showSpinner(this);

					KuikaAppManager.prepareForNavigation();
						KuikaAppManager.addToPageInputVariables("LeadDetailTemp", "LeadId", ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, "allleadpending_1735739523_value", "leadId"), "Guid"));

				stateVars.NAVIGATE = await ReactSystemFunctions.navigate(this, undefined, "AllLeadPending", "LeadDetailTemp", "", "newTab", null, null, null, null, null, null, true, false);

		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

            
            return isErrorOccurred;
        }


		AllLeadPendingComponent_831143980_onClick = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
KuikaAppManager.showSpinner(this);

					KuikaAppManager.prepareForNavigation();
						KuikaAppManager.addToPageInputVariables("AllLeadPendingDetail", "LeadId", ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, "allleadpending_1735739523_value", "leadId"), "Guid"));

				stateVars.NAVIGATE = await ReactSystemFunctions.navigate(this, undefined, "AllLeadPending", "AllLeadPendingDetail", "", "7d969ddf-5801-4eb6-b92b-12be35bdd565", "633941128", null, "right", "true", "90%", "100vh", true, false);

		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

            
            return isErrorOccurred;
        }


		AllLeadPendingComponent_1103704329_onClick = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
KuikaAppManager.showSpinner(this);

					KuikaAppManager.prepareForNavigation();
						KuikaAppManager.addToPageInputVariables("AllLeadPendingDetail", "LeadId", ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, "allleadpending_1735739523_value", "leadId"), "Guid"));

				stateVars.NAVIGATE = await ReactSystemFunctions.navigate(this, undefined, "AllLeadPending", "AllLeadPendingDetail", "", "newTab", null, null, null, null, null, null, true, false);

		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

            
            return isErrorOccurred;
        }


    AllLeadPendingComponent_735657199_onClick = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
		KuikaAppManager.increaseServerRequestCount();

        let localVar = {
				UserId_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.getMyUserId(), "Guid"),
				LeadIds_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "allleadpending_1676811829_value", "selectedValues", "TMGetApprovedList", "", "")), "string"),
				EstimatedYear_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toInteger(this, ReactSystemFunctions.value(this, "allleadpending_761630611_value", "value", "", "key", "")), "number"),
				EstimatedMonth_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toInteger(this, ReactSystemFunctions.value(this, "allleadpending_1897922726_value", "value", "", "key", "")), "number"),
				UserId_1: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.getMyUserId(), "Guid"),
				LeadCode_1: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "allleadpending_16517_value", "value", "", "", "")), "string"),
				MusteriAdi_1: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "allleadpending_1393106492_value", "value", "", "", "")), "string"),
				Tel_1: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "allleadpending_226438964_value", "value", "", "", "")), "string"),
				ProductName_1: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "allleadpending_1486438661_value", "value", "", "", "")), "string"),
				CategoryName_1: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "allleadpending_1888449157_value", "value", "TM_GetProductCategory", "categoryCode", "categoryName")), "string"),
				StoreIds_1: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "allleadpending_1836228438_value", "value", "TM_GetStore", "storeCode", "id")), "string"),
				SatisDanismaniIds_1: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "allleadpending_86365187_value", "value", "TM_GetSalesPerson", "kUserId", "kUserId")), "string"),
				ProcessCode_1: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "allleadpending_869961548_value", "value", "TM_GetLeadProcess", "id", "code")), "string"),
				StartDate_1: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "allleadpending_1904273601_value", "value", "", "", "")), "Date"),
				EndDate_1: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "allleadpending_1827823391_value", "value", "", "", "")), "Date")
        }

		KuikaAppManager.showSpinner(this);
		
        if (true) {
        KuikaAppManager.showSpinner(this);
        }
        let result = await KuikaAppManager.ApiRequest(this, "AllLeadPending/AllLeadPendingComponent_735657199_onClick", localVar)
        if (!KMainFunctions.IsResStatus2XX(result)) return true;

			stateVars.TM_BulkChangeApprovedLeadTermin = result?.data.tM_BulkChangeApprovedLeadTermin;
			stateVars.TMGetApprovedList = result?.data.tmGetApprovedList;
			
			this.props.form?.setFieldsValue(formVars);
			
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.AllLeadPendingComponent_735657199_onClick1_();
                  resolve();
                });
          })



        
        KuikaAppManager.hideSpinner(this);
        return isErrorOccurred;
    }
		AllLeadPendingComponent_735657199_onClick1_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }

				stateVars.Notify = await ReactSystemFunctions.notify(this, ReactSystemFunctions.toString(this, (stateVars.TM_BulkChangeApprovedLeadTermin !== undefined ? (stateVars.TM_BulkChangeApprovedLeadTermin?.length > 0 ? stateVars.TM_BulkChangeApprovedLeadTermin[0].message : null) : (this.state.TM_BulkChangeApprovedLeadTermin?.length > 0 ? this.state.TM_BulkChangeApprovedLeadTermin[0].message : null))), ReactSystemFunctions.convertToTypeByName("default", "string"), ReactSystemFunctions.convertToTypeByName("bottom-right", "string"), 4, ReactSystemFunctions.convertToTypeByName("", "string"), ReactSystemFunctions.convertToTypeByName("", "string"), 0);

		this.props.form?.setFieldsValue(formVars);
		
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.AllLeadPendingComponent_735657199_onClick2_();
                  resolve();
                });
          })

            
            return isErrorOccurred;
        }
		AllLeadPendingComponent_735657199_onClick2_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
if (ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, (stateVars.TM_BulkChangeApprovedLeadTermin !== undefined ? (stateVars.TM_BulkChangeApprovedLeadTermin?.length > 0 ? stateVars.TM_BulkChangeApprovedLeadTermin[0].success : null) : (this.state.TM_BulkChangeApprovedLeadTermin?.length > 0 ? this.state.TM_BulkChangeApprovedLeadTermin[0].success : null))), true)) {
            
				stateVars.SetValueOf = await ReactSystemFunctions.setValueOf(this, ReactSystemFunctions.convertToTypeByName("allleadpending_1676811829_value", "string"), "", ReactSystemFunctions.convertToTypeByName("selectedValues", "string"), false);

		this.props.form?.setFieldsValue(formVars);
		
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.AllLeadPendingComponent_735657199_onClick3_();
                  resolve();
                });
          })

        } else {
            
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.AllLeadPendingComponent_735657199_onClick3_();
                  resolve();
                });
          })
        }

            
            return isErrorOccurred;
        }
		AllLeadPendingComponent_735657199_onClick3_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }

				
				stateVars.dataSource_1676811829 = stateVars.TMGetApprovedList ?? this.state.TMGetApprovedList;

		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

            
            return isErrorOccurred;
        }






		AllLeadPendingComponent_2121711473_onClick = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
KuikaAppManager.showSpinner(this);

					KuikaAppManager.prepareForNavigation();
						KuikaAppManager.addToPageInputVariables("AllLeadPendingTerminDegis", "LeadId", ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, "allleadpending_1676811829_value", "leadId"), "Guid"));

				stateVars.NAVIGATE = await ReactSystemFunctions.navigate(this, undefined, "AllLeadPending", "AllLeadPendingTerminDegis", "", "7d969ddf-5801-4eb6-b92b-12be35bdd565", "1484835976", null, "right", "true", "80%", "100vh", true, false);

		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

            
            return isErrorOccurred;
        }


		AllLeadPendingComponent_2223545_onClick = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
KuikaAppManager.showSpinner(this);

					KuikaAppManager.prepareForNavigation();
						KuikaAppManager.addToPageInputVariables("LeadDetailTemp", "LeadId", ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, "allleadpending_1676811829_value", "leadId"), "Guid"));

				stateVars.NAVIGATE = await ReactSystemFunctions.navigate(this, undefined, "AllLeadPending", "LeadDetailTemp", "", "7d969ddf-5801-4eb6-b92b-12be35bdd565", "1952535163", null, "right", "true", "90%", "100vh", true, false);

		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

            
            return isErrorOccurred;
        }


		AllLeadPendingComponent_480889991_onClick = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
KuikaAppManager.showSpinner(this);

					KuikaAppManager.prepareForNavigation();
						KuikaAppManager.addToPageInputVariables("LeadDetailTemp", "LeadId", ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, "allleadpending_1676811829_value", "leadId"), "Guid"));

				stateVars.NAVIGATE = await ReactSystemFunctions.navigate(this, undefined, "AllLeadPending", "LeadDetailTemp", "", "newTab", null, null, null, null, null, null, true, false);

		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

            
            return isErrorOccurred;
        }


		AllLeadPendingComponent_906008770_onClick = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
KuikaAppManager.showSpinner(this);

					KuikaAppManager.prepareForNavigation();
						KuikaAppManager.addToPageInputVariables("AllLeadPendingDetail", "LeadId", ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, "allleadpending_1676811829_value", "leadId"), "Guid"));

				stateVars.NAVIGATE = await ReactSystemFunctions.navigate(this, undefined, "AllLeadPending", "AllLeadPendingDetail", "", "7d969ddf-5801-4eb6-b92b-12be35bdd565", "1844990273", null, "right", "true", "90%", "100vh", true, false);

		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

            
            return isErrorOccurred;
        }


		AllLeadPendingComponent_695390301_onClick = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
KuikaAppManager.showSpinner(this);

					KuikaAppManager.prepareForNavigation();
						KuikaAppManager.addToPageInputVariables("AllLeadPendingDetail", "LeadId", ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, "allleadpending_1676811829_value", "leadId"), "Guid"));

				stateVars.NAVIGATE = await ReactSystemFunctions.navigate(this, undefined, "AllLeadPending", "AllLeadPendingDetail", "", "newTab", null, null, null, null, null, null, true, false);

		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

            
            return isErrorOccurred;
        }




    async callCallbackFunction(diId: number, isFromMaster: boolean = false) {
        let isErrorOccurred = false;
		let pageInitCallerNavDiIDs = [1991843134, 293474136, 633941128, 1484835976, 1952535163, 1844990273] as number[];
		if (isFromMaster || pageInitCallerNavDiIDs.indexOf(diId) > -1) {
			await this.AllLeadPendingPageInit();
		}

    }


}
