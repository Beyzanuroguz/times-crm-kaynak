import React from "react";
import Axios, { AxiosResponse } from "axios";
import { KuikaAppManager } from "../../shared/utilty/kuika-app-manager";
import { ReactSystemFunctions } from "../../shared/utilty/react-system-functions";
import { KNavigator } from "../../shared/hoc/with-history";
import { KContext } from "../../shared/hoc/with-context";
import { useLocation } from "react-router-dom";
import { FormInstance } from "antd/es/form";
import { Guid } from "guid-typescript";
import Swal from "sweetalert2";
import { KMainFunctions } from "../../shared/utilty/main-functions";
import moment from "moment";
import { IValidationData } from "../../models/dto/validation-data";
import { IStripePayment } from "../../models/dto/stripe-payment";
import { IUserInfoDto } from "../../models/dto/user-info.dto";
import { UserService } from "../../services/user-service";
import { kuikaCoreWasmBridgeService } from "../../services/_singletons";
import _ from "lodash";
import mqtt, { MqttClient } from "mqtt";
import { IMqttResult } from "../../models/dto/mqtt.dto";


declare let window: any;

export interface IPopTerminOnerisiBekleyen_ScreenProps {
  navigator: KNavigator;
  form: FormInstance<any>;
  googleLogin: any;
  screenInputs: any;
  context: KContext;
  initialValues: any;
  children: any;
}

export interface IPopTerminOnerisiBekleyen_ScreenState {
    isSpinnerVisible: boolean;
    isPageVisible: boolean;
	isLeftMenuVisible: boolean;
    spinnerCount: number;
    selectedLanguage: string;
    isPageInitLoaded: false;
    isPageRecurringLoaded: false;
	TM_GetLeadById: any[];
	TM_GetLeadById_dummy: any[];
	GoBack: any;
	GoBack_dummy: any;
	TMCreateEstimatedDateProposalWithLog: any[];
	TMCreateEstimatedDateProposalWithLog_dummy: any[];
	Notify: boolean;
	Notify_dummy: boolean;

}

export class PopTerminOnerisiBekleyen_ScreenBase extends React.PureComponent<IPopTerminOnerisiBekleyen_ScreenProps, any> {

	popterminonerisibekleyen_810341_value_kuikaAutoCompleteRef: React.RefObject<any>;
	popterminonerisibekleyen_702134_value_kuikaAutoCompleteRef: React.RefObject<any>;
    ml=[{"Id":"d5a61d2b-bd60-485f-86e2-661e9ed4e486","Name":"en_US","ShortName":"English","IsDefault":true,"LanguagePhrases":[]},{"Id":"3510edf5-0811-4ddd-9349-646f4633af1f","Name":"FixedValues","ShortName":"FixedValues","LanguagePhrases":[{"Id":507057,"PropertyName":"value","Value":"Termin Öner"},{"Id":120659,"PropertyName":"value","Value":"Lead No"},{"Id":342831,"PropertyName":"value","Value":"Kategori"},{"Id":591098,"PropertyName":"value","Value":"Süreç"},{"Id":143601,"PropertyName":"value","Value":"Müşteri ve mağaza"},{"Id":691468,"PropertyName":"value","Value":"Müşteri"},{"Id":287486,"PropertyName":"value","Value":"Telefon"},{"Id":796392,"PropertyName":"value","Value":"Mağaza"},{"Id":411375,"PropertyName":"value","Value":"Satış personeli"},{"Id":832235,"PropertyName":"value","Value":"Ürün ve talep"},{"Id":182911,"PropertyName":"value","Value":"Ürün"},{"Id":235049,"PropertyName":"value","Value":"Model"},{"Id":943139,"PropertyName":"value","Value":"Talep tarihi"},{"Id":729346,"PropertyName":"value","Value":"Termin Öner"},{"Id":17801,"PropertyName":"value","Value":"Termin yılı"},{"Id":810341,"PropertyName":"placeholder","Value":"Termin yılı seçiniz"},{"Id":698831,"PropertyName":"value","Value":"Termin ayı"},{"Id":702134,"PropertyName":"placeholder","Value":"Termin ayı seçiniz"},{"Id":331137,"PropertyName":"value","Value":"Termin önerisi açıklaması"},{"Id":72401,"PropertyName":"placeholder","Value":"Termin önerisi açıklamasını yazınız..."},{"Id":402750,"PropertyName":"label","Value":"Termin Önerisinde Bulun"},{"Id":296266,"PropertyName":"label","Value":"Vazgeç"}]}]
    defaultML = "en_US"
    
    screenHash = ""
    


    constructor(props) {
        super(props);
		this.popterminonerisibekleyen_810341_value_kuikaAutoCompleteRef = React.createRef();
		this.popterminonerisibekleyen_702134_value_kuikaAutoCompleteRef = React.createRef();

        this.state = {
            isSpinnerVisible: false,
            isPageVisible: false,
            isLeftMenuVisible: false,
            spinnerCount: 0,
            selectedLanguage: "",
            isPageInitLoaded: false,
            isPageRecurringLoaded: false,
            	        TM_GetLeadById: [],
	        GoBack: "",
	        TMCreateEstimatedDateProposalWithLog: [],
	        Notify: false,
	        dataSource_810341: [{"key":"2026","text":"2026"},{"key":"2027","text":"2027"},{"key":"2028","text":"2028"},{"key":"2029","text":"2029"},{"key":"2030","text":"2030"},{"key":"2031","text":"2031"},{"key":"2032","text":"2032"},{"key":"2033","text":"2033"},{"key":"2034","text":"2034"},{"key":"2035","text":"2035"},{"key":"2036","text":"2036"},{"key":"2037","text":"2037"},{"key":"2038","text":"2038"},{"key":"2039","text":"2039"},{"key":"2040","text":"2040"}],
	        dataSource_702134: [{"key":"1","text":"Ocak"},{"key":"2","text":"Şubat"},{"key":"3","text":"Mart"},{"key":"4","text":"Nisan"},{"key":"5","text":"Mayıs"},{"key":"6","text":"Haziran"},{"key":"7","text":"Temmuz"},{"key":"8","text":"Ağustos"},{"key":"9","text":"Eylül"},{"key":"10","text":"Ekim"},{"key":"11","text":"Kasım"},{"key":"12","text":"Aralık"}],

        }

        this.state.isPageVisible = true;
        
    }

    async componentDidMount() {

        if (KuikaAppManager.isPageInitPrevented()) {
            KuikaAppManager.calculateAndSetBodyHeight("popterminonerisibekleyen", "");
            return;
        }
        
        
        ReactSystemFunctions.validateToken()
        this.fillFormInitValues();
        if (true){
            await this.PopTerminOnerisiBekleyenPageInit();
        }
        
        
        
        KuikaAppManager.calculateAndSetBodyHeight("popterminonerisibekleyen", "");

        if (ReactSystemFunctions.getIsMicroApp() === false) {
           window.parentScreen = this;
        }
    }

    componentWillUnmount() {
        
        
        

        if (ReactSystemFunctions.getIsMicroApp() === false) {
           window.parentScreen = null;
        }
    }

    

        
    componentDidUpdate= async (prevProps, prevState) => {
		KuikaAppManager.calculateAndSetBodyHeight("popterminonerisibekleyen", ""    );
        if (prevProps?.location?.search !== (this.props as any)?.location?.search) {
			await this.PopTerminOnerisiBekleyenPageInit();
		}

        

        if (ReactSystemFunctions.getIsMicroApp() === false) {
            for (const key in prevState) {
                if (key.startsWith('NavVisible') && prevState[key] === true && this.state[key] === false) {
                    window.parentScreen = this;
                    break;
                }
            }
        }
	}

    fillFormInitValues() {
        this.props.form?.setFieldsValue({
});

    }

      setPageInitLoaded = (value: boolean) => {
        this.setState({ isPageInitLoaded: value });
      }

      setPageRecurringLoaded = (value: boolean) => {
        this.setState({ isPageRecurringLoaded: value });
      }

      clearFieldValidation = (changedValues: any) => {
        const fieldName = Object.keys(changedValues)[0];
        if (fieldName) {
          this.props.form?.setFields([
            {
              name: fieldName,
              errors: []
            }
          ]);
        }
      };

      

    PopTerminOnerisiBekleyenPageInit = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


	if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }

        let localVar = {
			LeadId_0: ReactSystemFunctions.convertToTypeByName(this.props.screenInputs.LeadId ?? this.props.screenInputs.leadid, "Guid")
        }

	KuikaAppManager.showSpinner(this);
	
        if (true) {
        KuikaAppManager.showSpinner(this);
        }
        let result = await KuikaAppManager.ApiRequest(this, "PopTerminOnerisiBekleyen/PopTerminOnerisiBekleyenPageInit", localVar)
        if (!KMainFunctions.IsResStatus2XX(result)) return true;

		stateVars.TM_GetLeadById = result?.data.tM_GetLeadById;
		formVars.popterminonerisibekleyen_333213_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadById !== undefined ? (stateVars.TM_GetLeadById?.length > 0 ? stateVars.TM_GetLeadById[0].leadCode : null) : (this.state.TM_GetLeadById?.length > 0 ? this.state.TM_GetLeadById[0].leadCode : null)));
		formVars.popterminonerisibekleyen_672544_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadById !== undefined ? (stateVars.TM_GetLeadById?.length > 0 ? stateVars.TM_GetLeadById[0].categoryName : null) : (this.state.TM_GetLeadById?.length > 0 ? this.state.TM_GetLeadById[0].categoryName : null)));
		formVars.popterminonerisibekleyen_761943_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadById !== undefined ? (stateVars.TM_GetLeadById?.length > 0 ? stateVars.TM_GetLeadById[0].processName : null) : (this.state.TM_GetLeadById?.length > 0 ? this.state.TM_GetLeadById[0].processName : null)));
		formVars.popterminonerisibekleyen_756811_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadById !== undefined ? (stateVars.TM_GetLeadById?.length > 0 ? stateVars.TM_GetLeadById[0].musteriAdi : null) : (this.state.TM_GetLeadById?.length > 0 ? this.state.TM_GetLeadById[0].musteriAdi : null)));
		formVars.popterminonerisibekleyen_270747_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadById !== undefined ? (stateVars.TM_GetLeadById?.length > 0 ? stateVars.TM_GetLeadById[0].telefonNo : null) : (this.state.TM_GetLeadById?.length > 0 ? this.state.TM_GetLeadById[0].telefonNo : null)));
		formVars.popterminonerisibekleyen_971733_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadById !== undefined ? (stateVars.TM_GetLeadById?.length > 0 ? stateVars.TM_GetLeadById[0].magaza : null) : (this.state.TM_GetLeadById?.length > 0 ? this.state.TM_GetLeadById[0].magaza : null)));
		formVars.popterminonerisibekleyen_408098_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadById !== undefined ? (stateVars.TM_GetLeadById?.length > 0 ? stateVars.TM_GetLeadById[0].satisPersoneli : null) : (this.state.TM_GetLeadById?.length > 0 ? this.state.TM_GetLeadById[0].satisPersoneli : null)));
		formVars.popterminonerisibekleyen_877220_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadById !== undefined ? (stateVars.TM_GetLeadById?.length > 0 ? stateVars.TM_GetLeadById[0].urunAdi : null) : (this.state.TM_GetLeadById?.length > 0 ? this.state.TM_GetLeadById[0].urunAdi : null)));
		formVars.popterminonerisibekleyen_423594_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadById !== undefined ? (stateVars.TM_GetLeadById?.length > 0 ? stateVars.TM_GetLeadById[0].referans : null) : (this.state.TM_GetLeadById?.length > 0 ? this.state.TM_GetLeadById[0].referans : null)));
		formVars.popterminonerisibekleyen_672876_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadById !== undefined ? (stateVars.TM_GetLeadById?.length > 0 ? stateVars.TM_GetLeadById[0].talepOlusturmaTarihi : null) : (this.state.TM_GetLeadById?.length > 0 ? this.state.TM_GetLeadById[0].talepOlusturmaTarihi : null)));
		this.props.form?.setFieldsValue(formVars);
		
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.PopTerminOnerisiBekleyenPageInit1_();
                  resolve();
                });
          })



        
        KuikaAppManager.hideSpinner(this);
        return isErrorOccurred;
    }
	PopTerminOnerisiBekleyenPageInit1_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


	if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }

			formVars.popterminonerisibekleyen_333213_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadById !== undefined ? (stateVars.TM_GetLeadById?.length > 0 ? stateVars.TM_GetLeadById[0].leadCode : null) : (this.state.TM_GetLeadById?.length > 0 ? this.state.TM_GetLeadById[0].leadCode : null)));

			formVars.popterminonerisibekleyen_672544_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadById !== undefined ? (stateVars.TM_GetLeadById?.length > 0 ? stateVars.TM_GetLeadById[0].categoryName : null) : (this.state.TM_GetLeadById?.length > 0 ? this.state.TM_GetLeadById[0].categoryName : null)));

			formVars.popterminonerisibekleyen_761943_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadById !== undefined ? (stateVars.TM_GetLeadById?.length > 0 ? stateVars.TM_GetLeadById[0].processName : null) : (this.state.TM_GetLeadById?.length > 0 ? this.state.TM_GetLeadById[0].processName : null)));

			formVars.popterminonerisibekleyen_756811_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadById !== undefined ? (stateVars.TM_GetLeadById?.length > 0 ? stateVars.TM_GetLeadById[0].musteriAdi : null) : (this.state.TM_GetLeadById?.length > 0 ? this.state.TM_GetLeadById[0].musteriAdi : null)));

			formVars.popterminonerisibekleyen_270747_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadById !== undefined ? (stateVars.TM_GetLeadById?.length > 0 ? stateVars.TM_GetLeadById[0].telefonNo : null) : (this.state.TM_GetLeadById?.length > 0 ? this.state.TM_GetLeadById[0].telefonNo : null)));

			formVars.popterminonerisibekleyen_971733_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadById !== undefined ? (stateVars.TM_GetLeadById?.length > 0 ? stateVars.TM_GetLeadById[0].magaza : null) : (this.state.TM_GetLeadById?.length > 0 ? this.state.TM_GetLeadById[0].magaza : null)));

			formVars.popterminonerisibekleyen_408098_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadById !== undefined ? (stateVars.TM_GetLeadById?.length > 0 ? stateVars.TM_GetLeadById[0].satisPersoneli : null) : (this.state.TM_GetLeadById?.length > 0 ? this.state.TM_GetLeadById[0].satisPersoneli : null)));

			formVars.popterminonerisibekleyen_877220_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadById !== undefined ? (stateVars.TM_GetLeadById?.length > 0 ? stateVars.TM_GetLeadById[0].urunAdi : null) : (this.state.TM_GetLeadById?.length > 0 ? this.state.TM_GetLeadById[0].urunAdi : null)));

			formVars.popterminonerisibekleyen_423594_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadById !== undefined ? (stateVars.TM_GetLeadById?.length > 0 ? stateVars.TM_GetLeadById[0].referans : null) : (this.state.TM_GetLeadById?.length > 0 ? this.state.TM_GetLeadById[0].referans : null)));

			formVars.popterminonerisibekleyen_672876_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadById !== undefined ? (stateVars.TM_GetLeadById?.length > 0 ? stateVars.TM_GetLeadById[0].talepOlusturmaTarihi : null) : (this.state.TM_GetLeadById?.length > 0 ? this.state.TM_GetLeadById[0].talepOlusturmaTarihi : null)));


	this.props.form?.setFieldsValue(formVars);
	this.setState(stateVars);
	KuikaAppManager.hideSpinner(this);

            this.setPageInitLoaded(true);
            return isErrorOccurred;
        }




		PopTerminOnerisiBekleyenComponent_896345_onClick = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
KuikaAppManager.showSpinner(this);

				stateVars.GoBack = await ReactSystemFunctions.goBack(this, false);

		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

            
            return isErrorOccurred;
        }


    PopTerminOnerisiBekleyenComponent_402750_onClick = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
		KuikaAppManager.increaseServerRequestCount();

        let localVar = {
				LeadId_0: ReactSystemFunctions.convertToTypeByName(this.props.screenInputs.LeadId ?? this.props.screenInputs.leadid, "Guid"),
				UserId_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.getMyUserId(), "Guid"),
				EstimatedYear_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toInteger(this, ReactSystemFunctions.value(this, "popterminonerisibekleyen_810341_value", "value", "", "key", "")), "number"),
				EstimatedMonth_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toInteger(this, ReactSystemFunctions.value(this, "popterminonerisibekleyen_702134_value", "value", "", "key", "")), "number"),
				ProposalNote_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "popterminonerisibekleyen_72401_value", "value", "", "", "")), "string")
        }

		KuikaAppManager.showSpinner(this);
		
        if (true) {
        KuikaAppManager.showSpinner(this);
        }
        let result = await KuikaAppManager.ApiRequest(this, "PopTerminOnerisiBekleyen/PopTerminOnerisiBekleyenComponent_402750_onClick", localVar)
        if (!KMainFunctions.IsResStatus2XX(result)) return true;

			stateVars.TMCreateEstimatedDateProposalWithLog = result?.data.tmCreateEstimatedDateProposalWithLog;
			this.props.form?.setFieldsValue(formVars);
			
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.PopTerminOnerisiBekleyenComponent_402750_onClick1_();
                  resolve();
                });
          })



        
        KuikaAppManager.hideSpinner(this);
        return isErrorOccurred;
    }
		PopTerminOnerisiBekleyenComponent_402750_onClick1_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }

				stateVars.Notify = await ReactSystemFunctions.notify(this, ReactSystemFunctions.toString(this, (stateVars.TMCreateEstimatedDateProposalWithLog !== undefined ? (stateVars.TMCreateEstimatedDateProposalWithLog?.length > 0 ? stateVars.TMCreateEstimatedDateProposalWithLog[0].message : null) : (this.state.TMCreateEstimatedDateProposalWithLog?.length > 0 ? this.state.TMCreateEstimatedDateProposalWithLog[0].message : null))), ReactSystemFunctions.convertToTypeByName("default", "string"), ReactSystemFunctions.convertToTypeByName("top-center", "string"), 2, ReactSystemFunctions.convertToTypeByName("", "string"), ReactSystemFunctions.convertToTypeByName("", "string"), 0);

		this.props.form?.setFieldsValue(formVars);
		
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.PopTerminOnerisiBekleyenComponent_402750_onClick2_();
                  resolve();
                });
          })

            
            return isErrorOccurred;
        }
		PopTerminOnerisiBekleyenComponent_402750_onClick2_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
if (ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, (stateVars.TMCreateEstimatedDateProposalWithLog !== undefined ? (stateVars.TMCreateEstimatedDateProposalWithLog?.length > 0 ? stateVars.TMCreateEstimatedDateProposalWithLog[0].success : null) : (this.state.TMCreateEstimatedDateProposalWithLog?.length > 0 ? this.state.TMCreateEstimatedDateProposalWithLog[0].success : null))), true)) {
            
				stateVars.GoBack = await ReactSystemFunctions.goBack(this, false);

		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

        } else {
            KuikaAppManager.hideSpinner(this);
        }

            
            return isErrorOccurred;
        }





		PopTerminOnerisiBekleyenComponent_296266_onClick = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
KuikaAppManager.showSpinner(this);

				stateVars.GoBack = await ReactSystemFunctions.goBack(this, false);

		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

            
            return isErrorOccurred;
        }




    async callCallbackFunction(diId: number, isFromMaster: boolean = false) {
        let isErrorOccurred = false;
		let pageInitCallerNavDiIDs = [] as number[];
		if (isFromMaster || pageInitCallerNavDiIDs.indexOf(diId) > -1) {
			await this.PopTerminOnerisiBekleyenPageInit();
		}

    }


}
