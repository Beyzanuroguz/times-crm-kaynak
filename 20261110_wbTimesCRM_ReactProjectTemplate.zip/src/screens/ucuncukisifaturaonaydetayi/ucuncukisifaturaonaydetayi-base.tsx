import React from "react";
import Axios, { AxiosResponse } from "axios";
import { KuikaAppManager } from "../../shared/utilty/kuika-app-manager";
import { ReactSystemFunctions } from "../../shared/utilty/react-system-functions";
import { KNavigator } from "../../shared/hoc/with-history";
import { KContext } from "../../shared/hoc/with-context";
import { useLocation } from "react-router-dom";
import { FormInstance } from "antd/es/form";
import { Guid } from "guid-typescript";
import Swal from "sweetalert2";
import { KMainFunctions } from "../../shared/utilty/main-functions";
import moment from "moment";
import { IValidationData } from "../../models/dto/validation-data";
import { IStripePayment } from "../../models/dto/stripe-payment";
import { IUserInfoDto } from "../../models/dto/user-info.dto";
import { UserService } from "../../services/user-service";
import { kuikaCoreWasmBridgeService } from "../../services/_singletons";
import _ from "lodash";
import mqtt, { MqttClient } from "mqtt";
import { IMqttResult } from "../../models/dto/mqtt.dto";


declare let window: any;

export interface IUcuncuKisiFaturaOnayDetayi_ScreenProps {
  navigator: KNavigator;
  form: FormInstance<any>;
  googleLogin: any;
  screenInputs: any;
  context: KContext;
  initialValues: any;
  children: any;
}

export interface IUcuncuKisiFaturaOnayDetayi_ScreenState {
    isSpinnerVisible: boolean;
    isPageVisible: boolean;
	isLeftMenuVisible: boolean;
    spinnerCount: number;
    selectedLanguage: string;
    isPageInitLoaded: false;
    isPageRecurringLoaded: false;
	TM_GetThirdPartyInvoiceApprovalDetail: any[];
	TM_GetThirdPartyInvoiceApprovalDetail_dummy: any[];
	GoBack: any;
	GoBack_dummy: any;
	TM_DecideThirdPartyInvoiceApproval: any[];
	TM_DecideThirdPartyInvoiceApproval_dummy: any[];
	Notify: boolean;
	Notify_dummy: boolean;
	isComp1483445269Visible: 'visible' | 'hidden';
	isComp77130012Visible: 'visible' | 'hidden';
	isComp1919117261Enabled: 'enabled' | 'disabled';
	isComp2136670538Enabled: 'enabled' | 'disabled';

}

export class UcuncuKisiFaturaOnayDetayi_ScreenBase extends React.PureComponent<IUcuncuKisiFaturaOnayDetayi_ScreenProps, any> {


    ml=[{"Id":"d5a61d2b-bd60-485f-86e2-661e9ed4e486","Name":"en_US","ShortName":"English","IsDefault":true,"LanguagePhrases":[]},{"Id":"687d0d53-194e-4cd3-8230-db6b849085c1","Name":"FixedValues","ShortName":"FixedValues","LanguagePhrases":[{"Id":153531279,"PropertyName":"label","Value":"Onay Listesine Dön"},{"Id":430873670,"PropertyName":"value","Value":"3. KİŞİ FATURALANDIRMA"},{"Id":623158260,"PropertyName":"value","Value":"Faturalandırma Onay Talebi"},{"Id":426039323,"PropertyName":"value","Value":"Satış ve fatura alıcısı bilgilerini inceleyerek talebi sonuçlandırın."},{"Id":462321490,"PropertyName":"value","Value":"Onay Bekliyor"},{"Id":674051982,"PropertyName":"value","Value":"Talep Tarihi"},{"Id":1708627195,"PropertyName":"value","Value":"Talep Eden"},{"Id":1180223145,"PropertyName":"value","Value":"Satış Bilgileri"},{"Id":2133144071,"PropertyName":"value","Value":"Faturalandırmaya konu olan satışın özeti"},{"Id":1638871933,"PropertyName":"value","Value":"Asıl Müşteri"},{"Id":1594969167,"PropertyName":"value","Value":"Müşteri Kodu"},{"Id":2073370039,"PropertyName":"value","Value":"Mağaza"},{"Id":904955034,"PropertyName":"value","Value":"Satış Tutarı"},{"Id":593173028,"PropertyName":"value","Value":"Para Birimi"},{"Id":34999791,"PropertyName":"value","Value":"Fatura Tipi"},{"Id":1841447265,"PropertyName":"value","Value":"Fatura Edilecek 3. Kişi"},{"Id":1483798248,"PropertyName":"value","Value":"Faturada kullanılacak kişi, şirket ve adres bilgileri"},{"Id":1513501597,"PropertyName":"value","Value":"Bilgi Kaynağı"},{"Id":786799189,"PropertyName":"value","Value":"Kişi / Şirket"},{"Id":896429554,"PropertyName":"value","Value":"Kimlik / Vergi No"},{"Id":204441051,"PropertyName":"value","Value":"Şirket Unvanı"},{"Id":1445865618,"PropertyName":"value","Value":"Vergi Dairesi Kodu"},{"Id":1990696086,"PropertyName":"value","Value":"Nebim Müşteri Kodu"},{"Id":1301085200,"PropertyName":"value","Value":"Fatura Adresi"},{"Id":1250292880,"PropertyName":"value","Value":"Adres"},{"Id":2097458916,"PropertyName":"value","Value":"Ülke"},{"Id":78363113,"PropertyName":"value","Value":"Bölge"},{"Id":26812727,"PropertyName":"value","Value":"Şehir"},{"Id":1543717198,"PropertyName":"value","Value":"İlçe"},{"Id":442952189,"PropertyName":"value","Value":"Onay verildiğinde satış personeli belirlenen 3. kişi adına faturalandırma işlemine devam edebilir. Ret durumunda açıklama yazılması zorunludur. Verilen karar sistemde kayıt altına alınır."},{"Id":909905486,"PropertyName":"value","Value":"Kararınızı Girin"},{"Id":1699332273,"PropertyName":"value","Value":"Talebi onaylayabilir veya gerekçenizi belirterek reddedebilirsiniz."},{"Id":1207586048,"PropertyName":"placeholder","Value":"Onay notunuzu veya ret gerekçenizi yazınız"},{"Id":643774933,"PropertyName":"label","Value":"Vazgeç"},{"Id":1919117261,"PropertyName":"label","Value":"Talebi Reddet"},{"Id":2136670538,"PropertyName":"label","Value":"Talebi Onayla"},{"Id":320006745,"PropertyName":"value","Value":"Talep bulunamadı veya bu talebe erişim yetkiniz yok"}]}]
    defaultML = "en_US"
    
    screenHash = ""
    


    constructor(props) {
        super(props);


        this.state = {
            isSpinnerVisible: false,
            isPageVisible: false,
            isLeftMenuVisible: false,
            spinnerCount: 0,
            selectedLanguage: "",
            isPageInitLoaded: false,
            isPageRecurringLoaded: false,
            	        TM_GetThirdPartyInvoiceApprovalDetail: [],
	        GoBack: "",
	        TM_DecideThirdPartyInvoiceApproval: [],
	        Notify: false,
	        isComp1483445269Visible: 'hidden',
	        isComp77130012Visible: 'hidden',
	        isComp1919117261Enabled: 'disabled',
	        isComp2136670538Enabled: 'disabled',

        }

        this.state.isPageVisible = true;
        
    }

    async componentDidMount() {

        if (KuikaAppManager.isPageInitPrevented()) {
            KuikaAppManager.calculateAndSetBodyHeight("ucuncukisifaturaonaydetayi", "");
            return;
        }
        
        
        ReactSystemFunctions.validateToken()
        this.fillFormInitValues();
        if (true){
            await this.UcuncuKisiFaturaOnayDetayiPageInit();
        }
        
        
        
        KuikaAppManager.calculateAndSetBodyHeight("ucuncukisifaturaonaydetayi", "");

        if (ReactSystemFunctions.getIsMicroApp() === false) {
           window.parentScreen = this;
        }
    }

    componentWillUnmount() {
        
        
        

        if (ReactSystemFunctions.getIsMicroApp() === false) {
           window.parentScreen = null;
        }
    }

    

        
    componentDidUpdate= async (prevProps, prevState) => {
		KuikaAppManager.calculateAndSetBodyHeight("ucuncukisifaturaonaydetayi", ""    );
        if (prevProps?.location?.search !== (this.props as any)?.location?.search) {
			await this.UcuncuKisiFaturaOnayDetayiPageInit();
		}

        

        if (ReactSystemFunctions.getIsMicroApp() === false) {
            for (const key in prevState) {
                if (key.startsWith('NavVisible') && prevState[key] === true && this.state[key] === false) {
                    window.parentScreen = this;
                    break;
                }
            }
        }
	}

    fillFormInitValues() {
        this.props.form?.setFieldsValue({
});

    }

      setPageInitLoaded = (value: boolean) => {
        this.setState({ isPageInitLoaded: value });
      }

      setPageRecurringLoaded = (value: boolean) => {
        this.setState({ isPageRecurringLoaded: value });
      }

      clearFieldValidation = (changedValues: any) => {
        const fieldName = Object.keys(changedValues)[0];
        if (fieldName) {
          this.props.form?.setFields([
            {
              name: fieldName,
              errors: []
            }
          ]);
        }
      };

      

    UcuncuKisiFaturaOnayDetayiPageInit = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


	if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }

        let localVar = {
			ApprovalId_0: ReactSystemFunctions.convertToTypeByName(this.props.screenInputs.ApprovalId ?? this.props.screenInputs.approvalid, "Guid"),
			CurrentUserId_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.getMyUserId(), "Guid")
        }

	KuikaAppManager.showSpinner(this);
	
        if (true) {
        KuikaAppManager.showSpinner(this);
        }
        let result = await KuikaAppManager.ApiRequest(this, "UcuncuKisiFaturaOnayDetayi/UcuncuKisiFaturaOnayDetayiPageInit", localVar)
        if (!KMainFunctions.IsResStatus2XX(result)) return true;

		stateVars.TM_GetThirdPartyInvoiceApprovalDetail = result?.data.tM_GetThirdPartyInvoiceApprovalDetail;
		formVars.ucuncukisifaturaonaydetayi_611854287_value = ReactSystemFunctions.value(this, (stateVars.TM_GetThirdPartyInvoiceApprovalDetail !== undefined ? (stateVars.TM_GetThirdPartyInvoiceApprovalDetail?.length > 0 ? stateVars.TM_GetThirdPartyInvoiceApprovalDetail[0].requestedAt : null) : (this.state.TM_GetThirdPartyInvoiceApprovalDetail?.length > 0 ? this.state.TM_GetThirdPartyInvoiceApprovalDetail[0].requestedAt : null)));
		formVars.ucuncukisifaturaonaydetayi_1020388695_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetThirdPartyInvoiceApprovalDetail !== undefined ? (stateVars.TM_GetThirdPartyInvoiceApprovalDetail?.length > 0 ? stateVars.TM_GetThirdPartyInvoiceApprovalDetail[0].requestedByFullName : null) : (this.state.TM_GetThirdPartyInvoiceApprovalDetail?.length > 0 ? this.state.TM_GetThirdPartyInvoiceApprovalDetail[0].requestedByFullName : null)));
		formVars.ucuncukisifaturaonaydetayi_485365728_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetThirdPartyInvoiceApprovalDetail !== undefined ? (stateVars.TM_GetThirdPartyInvoiceApprovalDetail?.length > 0 ? stateVars.TM_GetThirdPartyInvoiceApprovalDetail[0].originalCustomerFullName : null) : (this.state.TM_GetThirdPartyInvoiceApprovalDetail?.length > 0 ? this.state.TM_GetThirdPartyInvoiceApprovalDetail[0].originalCustomerFullName : null)));
		formVars.ucuncukisifaturaonaydetayi_1133018171_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetThirdPartyInvoiceApprovalDetail !== undefined ? (stateVars.TM_GetThirdPartyInvoiceApprovalDetail?.length > 0 ? stateVars.TM_GetThirdPartyInvoiceApprovalDetail[0].originalCustomerCode : null) : (this.state.TM_GetThirdPartyInvoiceApprovalDetail?.length > 0 ? this.state.TM_GetThirdPartyInvoiceApprovalDetail[0].originalCustomerCode : null)));
		formVars.ucuncukisifaturaonaydetayi_72418256_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetThirdPartyInvoiceApprovalDetail !== undefined ? (stateVars.TM_GetThirdPartyInvoiceApprovalDetail?.length > 0 ? stateVars.TM_GetThirdPartyInvoiceApprovalDetail[0].storeName : null) : (this.state.TM_GetThirdPartyInvoiceApprovalDetail?.length > 0 ? this.state.TM_GetThirdPartyInvoiceApprovalDetail[0].storeName : null)));
		formVars.ucuncukisifaturaonaydetayi_1937464553_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetThirdPartyInvoiceApprovalDetail !== undefined ? (stateVars.TM_GetThirdPartyInvoiceApprovalDetail?.length > 0 ? stateVars.TM_GetThirdPartyInvoiceApprovalDetail[0].totalAmountEUR : null) : (this.state.TM_GetThirdPartyInvoiceApprovalDetail?.length > 0 ? this.state.TM_GetThirdPartyInvoiceApprovalDetail[0].totalAmountEUR : null)));
		formVars.ucuncukisifaturaonaydetayi_166073642_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetThirdPartyInvoiceApprovalDetail !== undefined ? (stateVars.TM_GetThirdPartyInvoiceApprovalDetail?.length > 0 ? stateVars.TM_GetThirdPartyInvoiceApprovalDetail[0].currencyCode : null) : (this.state.TM_GetThirdPartyInvoiceApprovalDetail?.length > 0 ? this.state.TM_GetThirdPartyInvoiceApprovalDetail[0].currencyCode : null)));
		formVars.ucuncukisifaturaonaydetayi_1594771199_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetThirdPartyInvoiceApprovalDetail !== undefined ? (stateVars.TM_GetThirdPartyInvoiceApprovalDetail?.length > 0 ? stateVars.TM_GetThirdPartyInvoiceApprovalDetail[0].invoiceType : null) : (this.state.TM_GetThirdPartyInvoiceApprovalDetail?.length > 0 ? this.state.TM_GetThirdPartyInvoiceApprovalDetail[0].invoiceType : null)));
		formVars.ucuncukisifaturaonaydetayi_149884898_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetThirdPartyInvoiceApprovalDetail !== undefined ? (stateVars.TM_GetThirdPartyInvoiceApprovalDetail?.length > 0 ? stateVars.TM_GetThirdPartyInvoiceApprovalDetail[0].sourceTypeText : null) : (this.state.TM_GetThirdPartyInvoiceApprovalDetail?.length > 0 ? this.state.TM_GetThirdPartyInvoiceApprovalDetail[0].sourceTypeText : null)));
		formVars.ucuncukisifaturaonaydetayi_63088270_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetThirdPartyInvoiceApprovalDetail !== undefined ? (stateVars.TM_GetThirdPartyInvoiceApprovalDetail?.length > 0 ? stateVars.TM_GetThirdPartyInvoiceApprovalDetail[0].thirdPartyFullName : null) : (this.state.TM_GetThirdPartyInvoiceApprovalDetail?.length > 0 ? this.state.TM_GetThirdPartyInvoiceApprovalDetail[0].thirdPartyFullName : null)));
		formVars.ucuncukisifaturaonaydetayi_49025102_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetThirdPartyInvoiceApprovalDetail !== undefined ? (stateVars.TM_GetThirdPartyInvoiceApprovalDetail?.length > 0 ? stateVars.TM_GetThirdPartyInvoiceApprovalDetail[0].identityNumber : null) : (this.state.TM_GetThirdPartyInvoiceApprovalDetail?.length > 0 ? this.state.TM_GetThirdPartyInvoiceApprovalDetail[0].identityNumber : null)));
		formVars.ucuncukisifaturaonaydetayi_468476152_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetThirdPartyInvoiceApprovalDetail !== undefined ? (stateVars.TM_GetThirdPartyInvoiceApprovalDetail?.length > 0 ? stateVars.TM_GetThirdPartyInvoiceApprovalDetail[0].taxNumber : null) : (this.state.TM_GetThirdPartyInvoiceApprovalDetail?.length > 0 ? this.state.TM_GetThirdPartyInvoiceApprovalDetail[0].taxNumber : null)));
		formVars.ucuncukisifaturaonaydetayi_225006068_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetThirdPartyInvoiceApprovalDetail !== undefined ? (stateVars.TM_GetThirdPartyInvoiceApprovalDetail?.length > 0 ? stateVars.TM_GetThirdPartyInvoiceApprovalDetail[0].companyName : null) : (this.state.TM_GetThirdPartyInvoiceApprovalDetail?.length > 0 ? this.state.TM_GetThirdPartyInvoiceApprovalDetail[0].companyName : null)));
		formVars.ucuncukisifaturaonaydetayi_1238184698_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetThirdPartyInvoiceApprovalDetail !== undefined ? (stateVars.TM_GetThirdPartyInvoiceApprovalDetail?.length > 0 ? stateVars.TM_GetThirdPartyInvoiceApprovalDetail[0].taxOfficeCode : null) : (this.state.TM_GetThirdPartyInvoiceApprovalDetail?.length > 0 ? this.state.TM_GetThirdPartyInvoiceApprovalDetail[0].taxOfficeCode : null)));
		formVars.ucuncukisifaturaonaydetayi_1899958549_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetThirdPartyInvoiceApprovalDetail !== undefined ? (stateVars.TM_GetThirdPartyInvoiceApprovalDetail?.length > 0 ? stateVars.TM_GetThirdPartyInvoiceApprovalDetail[0].thirdPartyCustomerCode : null) : (this.state.TM_GetThirdPartyInvoiceApprovalDetail?.length > 0 ? this.state.TM_GetThirdPartyInvoiceApprovalDetail[0].thirdPartyCustomerCode : null)));
		formVars.ucuncukisifaturaonaydetayi_615139469_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetThirdPartyInvoiceApprovalDetail !== undefined ? (stateVars.TM_GetThirdPartyInvoiceApprovalDetail?.length > 0 ? stateVars.TM_GetThirdPartyInvoiceApprovalDetail[0].address : null) : (this.state.TM_GetThirdPartyInvoiceApprovalDetail?.length > 0 ? this.state.TM_GetThirdPartyInvoiceApprovalDetail[0].address : null)));
		formVars.ucuncukisifaturaonaydetayi_1196771392_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetThirdPartyInvoiceApprovalDetail !== undefined ? (stateVars.TM_GetThirdPartyInvoiceApprovalDetail?.length > 0 ? stateVars.TM_GetThirdPartyInvoiceApprovalDetail[0].countryDisplay : null) : (this.state.TM_GetThirdPartyInvoiceApprovalDetail?.length > 0 ? this.state.TM_GetThirdPartyInvoiceApprovalDetail[0].countryDisplay : null)));
		formVars.ucuncukisifaturaonaydetayi_56858637_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetThirdPartyInvoiceApprovalDetail !== undefined ? (stateVars.TM_GetThirdPartyInvoiceApprovalDetail?.length > 0 ? stateVars.TM_GetThirdPartyInvoiceApprovalDetail[0].stateDisplay : null) : (this.state.TM_GetThirdPartyInvoiceApprovalDetail?.length > 0 ? this.state.TM_GetThirdPartyInvoiceApprovalDetail[0].stateDisplay : null)));
		formVars.ucuncukisifaturaonaydetayi_1762142582_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetThirdPartyInvoiceApprovalDetail !== undefined ? (stateVars.TM_GetThirdPartyInvoiceApprovalDetail?.length > 0 ? stateVars.TM_GetThirdPartyInvoiceApprovalDetail[0].cityDisplay : null) : (this.state.TM_GetThirdPartyInvoiceApprovalDetail?.length > 0 ? this.state.TM_GetThirdPartyInvoiceApprovalDetail[0].cityDisplay : null)));
		formVars.ucuncukisifaturaonaydetayi_1065693503_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetThirdPartyInvoiceApprovalDetail !== undefined ? (stateVars.TM_GetThirdPartyInvoiceApprovalDetail?.length > 0 ? stateVars.TM_GetThirdPartyInvoiceApprovalDetail[0].districtDisplay : null) : (this.state.TM_GetThirdPartyInvoiceApprovalDetail?.length > 0 ? this.state.TM_GetThirdPartyInvoiceApprovalDetail[0].districtDisplay : null)));
		stateVars.isComp1483445269Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, (stateVars.TM_GetThirdPartyInvoiceApprovalDetail !== undefined ? (stateVars.TM_GetThirdPartyInvoiceApprovalDetail?.length > 0 ? stateVars.TM_GetThirdPartyInvoiceApprovalDetail[0].canDecide : null) : (this.state.TM_GetThirdPartyInvoiceApprovalDetail?.length > 0 ? this.state.TM_GetThirdPartyInvoiceApprovalDetail[0].canDecide : null))), ReactSystemFunctions.convertToTypeByName("True", "string"))) === true ? "visible" : "hidden")
		stateVars.isComp77130012Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, (stateVars.TM_GetThirdPartyInvoiceApprovalDetail !== undefined ? (stateVars.TM_GetThirdPartyInvoiceApprovalDetail?.length > 0 ? stateVars.TM_GetThirdPartyInvoiceApprovalDetail[0].canDecide : null) : (this.state.TM_GetThirdPartyInvoiceApprovalDetail?.length > 0 ? this.state.TM_GetThirdPartyInvoiceApprovalDetail[0].canDecide : null))), ReactSystemFunctions.convertToTypeByName("False", "string"))) === true ? "visible" : "hidden")
		stateVars.isComp1919117261Enabled = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, (stateVars.TM_GetThirdPartyInvoiceApprovalDetail !== undefined ? (stateVars.TM_GetThirdPartyInvoiceApprovalDetail?.length > 0 ? stateVars.TM_GetThirdPartyInvoiceApprovalDetail[0].canDecide : null) : (this.state.TM_GetThirdPartyInvoiceApprovalDetail?.length > 0 ? this.state.TM_GetThirdPartyInvoiceApprovalDetail[0].canDecide : null))), ReactSystemFunctions.convertToTypeByName("True", "string"))) === true ? "enabled" : "disabled")
		stateVars.isComp2136670538Enabled = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, (stateVars.TM_GetThirdPartyInvoiceApprovalDetail !== undefined ? (stateVars.TM_GetThirdPartyInvoiceApprovalDetail?.length > 0 ? stateVars.TM_GetThirdPartyInvoiceApprovalDetail[0].canDecide : null) : (this.state.TM_GetThirdPartyInvoiceApprovalDetail?.length > 0 ? this.state.TM_GetThirdPartyInvoiceApprovalDetail[0].canDecide : null))), ReactSystemFunctions.convertToTypeByName("True", "string"))) === true ? "enabled" : "disabled")
		this.props.form?.setFieldsValue(formVars);
		
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.UcuncuKisiFaturaOnayDetayiPageInit1_();
                  resolve();
                });
          })



        
        KuikaAppManager.hideSpinner(this);
        return isErrorOccurred;
    }
	UcuncuKisiFaturaOnayDetayiPageInit1_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


	if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }

			formVars.ucuncukisifaturaonaydetayi_611854287_value = ReactSystemFunctions.value(this, (stateVars.TM_GetThirdPartyInvoiceApprovalDetail !== undefined ? (stateVars.TM_GetThirdPartyInvoiceApprovalDetail?.length > 0 ? stateVars.TM_GetThirdPartyInvoiceApprovalDetail[0].requestedAt : null) : (this.state.TM_GetThirdPartyInvoiceApprovalDetail?.length > 0 ? this.state.TM_GetThirdPartyInvoiceApprovalDetail[0].requestedAt : null)));

			formVars.ucuncukisifaturaonaydetayi_1020388695_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetThirdPartyInvoiceApprovalDetail !== undefined ? (stateVars.TM_GetThirdPartyInvoiceApprovalDetail?.length > 0 ? stateVars.TM_GetThirdPartyInvoiceApprovalDetail[0].requestedByFullName : null) : (this.state.TM_GetThirdPartyInvoiceApprovalDetail?.length > 0 ? this.state.TM_GetThirdPartyInvoiceApprovalDetail[0].requestedByFullName : null)));

			formVars.ucuncukisifaturaonaydetayi_485365728_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetThirdPartyInvoiceApprovalDetail !== undefined ? (stateVars.TM_GetThirdPartyInvoiceApprovalDetail?.length > 0 ? stateVars.TM_GetThirdPartyInvoiceApprovalDetail[0].originalCustomerFullName : null) : (this.state.TM_GetThirdPartyInvoiceApprovalDetail?.length > 0 ? this.state.TM_GetThirdPartyInvoiceApprovalDetail[0].originalCustomerFullName : null)));

			formVars.ucuncukisifaturaonaydetayi_1133018171_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetThirdPartyInvoiceApprovalDetail !== undefined ? (stateVars.TM_GetThirdPartyInvoiceApprovalDetail?.length > 0 ? stateVars.TM_GetThirdPartyInvoiceApprovalDetail[0].originalCustomerCode : null) : (this.state.TM_GetThirdPartyInvoiceApprovalDetail?.length > 0 ? this.state.TM_GetThirdPartyInvoiceApprovalDetail[0].originalCustomerCode : null)));

			formVars.ucuncukisifaturaonaydetayi_72418256_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetThirdPartyInvoiceApprovalDetail !== undefined ? (stateVars.TM_GetThirdPartyInvoiceApprovalDetail?.length > 0 ? stateVars.TM_GetThirdPartyInvoiceApprovalDetail[0].storeName : null) : (this.state.TM_GetThirdPartyInvoiceApprovalDetail?.length > 0 ? this.state.TM_GetThirdPartyInvoiceApprovalDetail[0].storeName : null)));

			formVars.ucuncukisifaturaonaydetayi_1937464553_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetThirdPartyInvoiceApprovalDetail !== undefined ? (stateVars.TM_GetThirdPartyInvoiceApprovalDetail?.length > 0 ? stateVars.TM_GetThirdPartyInvoiceApprovalDetail[0].totalAmountEUR : null) : (this.state.TM_GetThirdPartyInvoiceApprovalDetail?.length > 0 ? this.state.TM_GetThirdPartyInvoiceApprovalDetail[0].totalAmountEUR : null)));

			formVars.ucuncukisifaturaonaydetayi_166073642_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetThirdPartyInvoiceApprovalDetail !== undefined ? (stateVars.TM_GetThirdPartyInvoiceApprovalDetail?.length > 0 ? stateVars.TM_GetThirdPartyInvoiceApprovalDetail[0].currencyCode : null) : (this.state.TM_GetThirdPartyInvoiceApprovalDetail?.length > 0 ? this.state.TM_GetThirdPartyInvoiceApprovalDetail[0].currencyCode : null)));

			formVars.ucuncukisifaturaonaydetayi_1594771199_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetThirdPartyInvoiceApprovalDetail !== undefined ? (stateVars.TM_GetThirdPartyInvoiceApprovalDetail?.length > 0 ? stateVars.TM_GetThirdPartyInvoiceApprovalDetail[0].invoiceType : null) : (this.state.TM_GetThirdPartyInvoiceApprovalDetail?.length > 0 ? this.state.TM_GetThirdPartyInvoiceApprovalDetail[0].invoiceType : null)));

			formVars.ucuncukisifaturaonaydetayi_149884898_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetThirdPartyInvoiceApprovalDetail !== undefined ? (stateVars.TM_GetThirdPartyInvoiceApprovalDetail?.length > 0 ? stateVars.TM_GetThirdPartyInvoiceApprovalDetail[0].sourceTypeText : null) : (this.state.TM_GetThirdPartyInvoiceApprovalDetail?.length > 0 ? this.state.TM_GetThirdPartyInvoiceApprovalDetail[0].sourceTypeText : null)));

			formVars.ucuncukisifaturaonaydetayi_63088270_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetThirdPartyInvoiceApprovalDetail !== undefined ? (stateVars.TM_GetThirdPartyInvoiceApprovalDetail?.length > 0 ? stateVars.TM_GetThirdPartyInvoiceApprovalDetail[0].thirdPartyFullName : null) : (this.state.TM_GetThirdPartyInvoiceApprovalDetail?.length > 0 ? this.state.TM_GetThirdPartyInvoiceApprovalDetail[0].thirdPartyFullName : null)));

			formVars.ucuncukisifaturaonaydetayi_49025102_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetThirdPartyInvoiceApprovalDetail !== undefined ? (stateVars.TM_GetThirdPartyInvoiceApprovalDetail?.length > 0 ? stateVars.TM_GetThirdPartyInvoiceApprovalDetail[0].identityNumber : null) : (this.state.TM_GetThirdPartyInvoiceApprovalDetail?.length > 0 ? this.state.TM_GetThirdPartyInvoiceApprovalDetail[0].identityNumber : null)));

			formVars.ucuncukisifaturaonaydetayi_468476152_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetThirdPartyInvoiceApprovalDetail !== undefined ? (stateVars.TM_GetThirdPartyInvoiceApprovalDetail?.length > 0 ? stateVars.TM_GetThirdPartyInvoiceApprovalDetail[0].taxNumber : null) : (this.state.TM_GetThirdPartyInvoiceApprovalDetail?.length > 0 ? this.state.TM_GetThirdPartyInvoiceApprovalDetail[0].taxNumber : null)));

			formVars.ucuncukisifaturaonaydetayi_225006068_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetThirdPartyInvoiceApprovalDetail !== undefined ? (stateVars.TM_GetThirdPartyInvoiceApprovalDetail?.length > 0 ? stateVars.TM_GetThirdPartyInvoiceApprovalDetail[0].companyName : null) : (this.state.TM_GetThirdPartyInvoiceApprovalDetail?.length > 0 ? this.state.TM_GetThirdPartyInvoiceApprovalDetail[0].companyName : null)));

			formVars.ucuncukisifaturaonaydetayi_1238184698_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetThirdPartyInvoiceApprovalDetail !== undefined ? (stateVars.TM_GetThirdPartyInvoiceApprovalDetail?.length > 0 ? stateVars.TM_GetThirdPartyInvoiceApprovalDetail[0].taxOfficeCode : null) : (this.state.TM_GetThirdPartyInvoiceApprovalDetail?.length > 0 ? this.state.TM_GetThirdPartyInvoiceApprovalDetail[0].taxOfficeCode : null)));

			formVars.ucuncukisifaturaonaydetayi_1899958549_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetThirdPartyInvoiceApprovalDetail !== undefined ? (stateVars.TM_GetThirdPartyInvoiceApprovalDetail?.length > 0 ? stateVars.TM_GetThirdPartyInvoiceApprovalDetail[0].thirdPartyCustomerCode : null) : (this.state.TM_GetThirdPartyInvoiceApprovalDetail?.length > 0 ? this.state.TM_GetThirdPartyInvoiceApprovalDetail[0].thirdPartyCustomerCode : null)));

			formVars.ucuncukisifaturaonaydetayi_615139469_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetThirdPartyInvoiceApprovalDetail !== undefined ? (stateVars.TM_GetThirdPartyInvoiceApprovalDetail?.length > 0 ? stateVars.TM_GetThirdPartyInvoiceApprovalDetail[0].address : null) : (this.state.TM_GetThirdPartyInvoiceApprovalDetail?.length > 0 ? this.state.TM_GetThirdPartyInvoiceApprovalDetail[0].address : null)));

			formVars.ucuncukisifaturaonaydetayi_1196771392_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetThirdPartyInvoiceApprovalDetail !== undefined ? (stateVars.TM_GetThirdPartyInvoiceApprovalDetail?.length > 0 ? stateVars.TM_GetThirdPartyInvoiceApprovalDetail[0].countryDisplay : null) : (this.state.TM_GetThirdPartyInvoiceApprovalDetail?.length > 0 ? this.state.TM_GetThirdPartyInvoiceApprovalDetail[0].countryDisplay : null)));

			formVars.ucuncukisifaturaonaydetayi_56858637_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetThirdPartyInvoiceApprovalDetail !== undefined ? (stateVars.TM_GetThirdPartyInvoiceApprovalDetail?.length > 0 ? stateVars.TM_GetThirdPartyInvoiceApprovalDetail[0].stateDisplay : null) : (this.state.TM_GetThirdPartyInvoiceApprovalDetail?.length > 0 ? this.state.TM_GetThirdPartyInvoiceApprovalDetail[0].stateDisplay : null)));

			formVars.ucuncukisifaturaonaydetayi_1762142582_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetThirdPartyInvoiceApprovalDetail !== undefined ? (stateVars.TM_GetThirdPartyInvoiceApprovalDetail?.length > 0 ? stateVars.TM_GetThirdPartyInvoiceApprovalDetail[0].cityDisplay : null) : (this.state.TM_GetThirdPartyInvoiceApprovalDetail?.length > 0 ? this.state.TM_GetThirdPartyInvoiceApprovalDetail[0].cityDisplay : null)));

			formVars.ucuncukisifaturaonaydetayi_1065693503_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetThirdPartyInvoiceApprovalDetail !== undefined ? (stateVars.TM_GetThirdPartyInvoiceApprovalDetail?.length > 0 ? stateVars.TM_GetThirdPartyInvoiceApprovalDetail[0].districtDisplay : null) : (this.state.TM_GetThirdPartyInvoiceApprovalDetail?.length > 0 ? this.state.TM_GetThirdPartyInvoiceApprovalDetail[0].districtDisplay : null)));

			stateVars.isComp1483445269Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, (stateVars.TM_GetThirdPartyInvoiceApprovalDetail !== undefined ? (stateVars.TM_GetThirdPartyInvoiceApprovalDetail?.length > 0 ? stateVars.TM_GetThirdPartyInvoiceApprovalDetail[0].canDecide : null) : (this.state.TM_GetThirdPartyInvoiceApprovalDetail?.length > 0 ? this.state.TM_GetThirdPartyInvoiceApprovalDetail[0].canDecide : null))), ReactSystemFunctions.convertToTypeByName("True", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp1919117261Enabled = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, (stateVars.TM_GetThirdPartyInvoiceApprovalDetail !== undefined ? (stateVars.TM_GetThirdPartyInvoiceApprovalDetail?.length > 0 ? stateVars.TM_GetThirdPartyInvoiceApprovalDetail[0].canDecide : null) : (this.state.TM_GetThirdPartyInvoiceApprovalDetail?.length > 0 ? this.state.TM_GetThirdPartyInvoiceApprovalDetail[0].canDecide : null))), ReactSystemFunctions.convertToTypeByName("True", "string"))) === true ? "enabled" : "disabled")
			stateVars.isComp2136670538Enabled = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, (stateVars.TM_GetThirdPartyInvoiceApprovalDetail !== undefined ? (stateVars.TM_GetThirdPartyInvoiceApprovalDetail?.length > 0 ? stateVars.TM_GetThirdPartyInvoiceApprovalDetail[0].canDecide : null) : (this.state.TM_GetThirdPartyInvoiceApprovalDetail?.length > 0 ? this.state.TM_GetThirdPartyInvoiceApprovalDetail[0].canDecide : null))), ReactSystemFunctions.convertToTypeByName("True", "string"))) === true ? "enabled" : "disabled")
			stateVars.isComp77130012Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, (stateVars.TM_GetThirdPartyInvoiceApprovalDetail !== undefined ? (stateVars.TM_GetThirdPartyInvoiceApprovalDetail?.length > 0 ? stateVars.TM_GetThirdPartyInvoiceApprovalDetail[0].canDecide : null) : (this.state.TM_GetThirdPartyInvoiceApprovalDetail?.length > 0 ? this.state.TM_GetThirdPartyInvoiceApprovalDetail[0].canDecide : null))), ReactSystemFunctions.convertToTypeByName("False", "string"))) === true ? "visible" : "hidden")

	this.props.form?.setFieldsValue(formVars);
	this.setState(stateVars);
	KuikaAppManager.hideSpinner(this);

            this.setPageInitLoaded(true);
            return isErrorOccurred;
        }




		UcuncuKisiFaturaOnayDetayiComponent_643774933_onClick = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
KuikaAppManager.showSpinner(this);

				stateVars.GoBack = await ReactSystemFunctions.goBack(this, false);

		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

            
            return isErrorOccurred;
        }


    UcuncuKisiFaturaOnayDetayiComponent_1919117261_onClick = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
		KuikaAppManager.increaseServerRequestCount();

        let localVar = {
				Decision_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.convertToTypeByName("REJECTED", "string"), "string"),
				DecisionNote_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "ucuncukisifaturaonaydetayi_1207586048_value", "value", "", "", "")), "string"),
				ApprovalId_0: ReactSystemFunctions.convertToTypeByName(this.props.screenInputs.ApprovalId ?? this.props.screenInputs.approvalid, "Guid"),
				CurrentUserId_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.getMyUserId(), "Guid")
        }

		KuikaAppManager.showSpinner(this);
		
        if (true) {
        KuikaAppManager.showSpinner(this);
        }
        let result = await KuikaAppManager.ApiRequest(this, "UcuncuKisiFaturaOnayDetayi/UcuncuKisiFaturaOnayDetayiComponent_1919117261_onClick", localVar)
        if (!KMainFunctions.IsResStatus2XX(result)) return true;

			stateVars.TM_DecideThirdPartyInvoiceApproval = result?.data.tM_DecideThirdPartyInvoiceApproval;
			this.props.form?.setFieldsValue(formVars);
			
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.UcuncuKisiFaturaOnayDetayiComponent_1919117261_onClick1_();
                  resolve();
                });
          })



        
        KuikaAppManager.hideSpinner(this);
        return isErrorOccurred;
    }
		UcuncuKisiFaturaOnayDetayiComponent_1919117261_onClick1_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }

				stateVars.Notify = await ReactSystemFunctions.notify(this, ReactSystemFunctions.toString(this, (stateVars.TM_DecideThirdPartyInvoiceApproval !== undefined ? (stateVars.TM_DecideThirdPartyInvoiceApproval?.length > 0 ? stateVars.TM_DecideThirdPartyInvoiceApproval[0].message : null) : (this.state.TM_DecideThirdPartyInvoiceApproval?.length > 0 ? this.state.TM_DecideThirdPartyInvoiceApproval[0].message : null))), ReactSystemFunctions.convertToTypeByName("default", "string"), ReactSystemFunctions.convertToTypeByName("bottom-right", "string"), 3, ReactSystemFunctions.convertToTypeByName("", "string"), ReactSystemFunctions.convertToTypeByName("", "string"), 0);

		this.props.form?.setFieldsValue(formVars);
		
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.UcuncuKisiFaturaOnayDetayiComponent_1919117261_onClick2_();
                  resolve();
                });
          })

            
            return isErrorOccurred;
        }
		UcuncuKisiFaturaOnayDetayiComponent_1919117261_onClick2_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
if (ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, (stateVars.TM_DecideThirdPartyInvoiceApproval !== undefined ? (stateVars.TM_DecideThirdPartyInvoiceApproval?.length > 0 ? stateVars.TM_DecideThirdPartyInvoiceApproval[0].success : null) : (this.state.TM_DecideThirdPartyInvoiceApproval?.length > 0 ? this.state.TM_DecideThirdPartyInvoiceApproval[0].success : null))), "1")) {
            
				stateVars.GoBack = await ReactSystemFunctions.goBack(this, false);

		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

        } else {
            KuikaAppManager.hideSpinner(this);
        }

            
            return isErrorOccurred;
        }





    UcuncuKisiFaturaOnayDetayiComponent_2136670538_onClick = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
		KuikaAppManager.increaseServerRequestCount();

        let localVar = {
				Decision_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.convertToTypeByName("APPROVED", "string"), "string"),
				DecisionNote_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "ucuncukisifaturaonaydetayi_1207586048_value", "value", "", "", "")), "string"),
				ApprovalId_0: ReactSystemFunctions.convertToTypeByName(this.props.screenInputs.ApprovalId ?? this.props.screenInputs.approvalid, "Guid"),
				CurrentUserId_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.getMyUserId(), "Guid")
        }

		KuikaAppManager.showSpinner(this);
		
        if (true) {
        KuikaAppManager.showSpinner(this);
        }
        let result = await KuikaAppManager.ApiRequest(this, "UcuncuKisiFaturaOnayDetayi/UcuncuKisiFaturaOnayDetayiComponent_2136670538_onClick", localVar)
        if (!KMainFunctions.IsResStatus2XX(result)) return true;

			stateVars.TM_DecideThirdPartyInvoiceApproval = result?.data.tM_DecideThirdPartyInvoiceApproval;
			this.props.form?.setFieldsValue(formVars);
			
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.UcuncuKisiFaturaOnayDetayiComponent_2136670538_onClick1_();
                  resolve();
                });
          })



        
        KuikaAppManager.hideSpinner(this);
        return isErrorOccurred;
    }
		UcuncuKisiFaturaOnayDetayiComponent_2136670538_onClick1_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }

				stateVars.Notify = await ReactSystemFunctions.notify(this, ReactSystemFunctions.toString(this, (stateVars.TM_DecideThirdPartyInvoiceApproval !== undefined ? (stateVars.TM_DecideThirdPartyInvoiceApproval?.length > 0 ? stateVars.TM_DecideThirdPartyInvoiceApproval[0].message : null) : (this.state.TM_DecideThirdPartyInvoiceApproval?.length > 0 ? this.state.TM_DecideThirdPartyInvoiceApproval[0].message : null))), ReactSystemFunctions.convertToTypeByName("default", "string"), ReactSystemFunctions.convertToTypeByName("bottom-right", "string"), 3, ReactSystemFunctions.convertToTypeByName("", "string"), ReactSystemFunctions.convertToTypeByName("", "string"), 0);

		this.props.form?.setFieldsValue(formVars);
		
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.UcuncuKisiFaturaOnayDetayiComponent_2136670538_onClick2_();
                  resolve();
                });
          })

            
            return isErrorOccurred;
        }
		UcuncuKisiFaturaOnayDetayiComponent_2136670538_onClick2_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
if (ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, (stateVars.TM_DecideThirdPartyInvoiceApproval !== undefined ? (stateVars.TM_DecideThirdPartyInvoiceApproval?.length > 0 ? stateVars.TM_DecideThirdPartyInvoiceApproval[0].success : null) : (this.state.TM_DecideThirdPartyInvoiceApproval?.length > 0 ? this.state.TM_DecideThirdPartyInvoiceApproval[0].success : null))), "1")) {
            
				stateVars.GoBack = await ReactSystemFunctions.goBack(this, false);

		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

        } else {
            KuikaAppManager.hideSpinner(this);
        }

            
            return isErrorOccurred;
        }







    async callCallbackFunction(diId: number, isFromMaster: boolean = false) {
        let isErrorOccurred = false;
		let pageInitCallerNavDiIDs = [] as number[];
		if (isFromMaster || pageInitCallerNavDiIDs.indexOf(diId) > -1) {
			await this.UcuncuKisiFaturaOnayDetayiPageInit();
		}

    }


}
