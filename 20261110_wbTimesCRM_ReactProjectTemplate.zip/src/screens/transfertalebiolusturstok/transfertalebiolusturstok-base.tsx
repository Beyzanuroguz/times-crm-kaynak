import React from "react";
import Axios, { AxiosResponse } from "axios";
import { KuikaAppManager } from "../../shared/utilty/kuika-app-manager";
import { ReactSystemFunctions } from "../../shared/utilty/react-system-functions";
import { KNavigator } from "../../shared/hoc/with-history";
import { KContext } from "../../shared/hoc/with-context";
import { useLocation } from "react-router-dom";
import { FormInstance } from "antd/es/form";
import { Guid } from "guid-typescript";
import Swal from "sweetalert2";
import { KMainFunctions } from "../../shared/utilty/main-functions";
import moment from "moment";
import { IValidationData } from "../../models/dto/validation-data";
import { IStripePayment } from "../../models/dto/stripe-payment";
import { IUserInfoDto } from "../../models/dto/user-info.dto";
import { UserService } from "../../services/user-service";
import { kuikaCoreWasmBridgeService } from "../../services/_singletons";
import _ from "lodash";
import mqtt, { MqttClient } from "mqtt";
import { IMqttResult } from "../../models/dto/mqtt.dto";


declare let window: any;

export interface ITransferTalebiOlusturStok_ScreenProps {
  navigator: KNavigator;
  form: FormInstance<any>;
  googleLogin: any;
  screenInputs: any;
  context: KContext;
  initialValues: any;
  children: any;
}

export interface ITransferTalebiOlusturStok_ScreenState {
    isSpinnerVisible: boolean;
    isPageVisible: boolean;
	isLeftMenuVisible: boolean;
    spinnerCount: number;
    selectedLanguage: string;
    isPageInitLoaded: false;
    isPageRecurringLoaded: false;

}

export class TransferTalebiOlusturStok_ScreenBase extends React.PureComponent<ITransferTalebiOlusturStok_ScreenProps, any> {


    ml=[{"Id":"d5a61d2b-bd60-485f-86e2-661e9ed4e486","Name":"en_US","ShortName":"English","IsDefault":true,"LanguagePhrases":[]},{"Id":"faf094ae-aa9b-4b6c-b641-a2672fe474d4","Name":"FixedValues","ShortName":"FixedValues","LanguagePhrases":[{"Id":692257,"PropertyName":"label","Value":"Ürün Detayına Dön"},{"Id":124650,"PropertyName":"value","Value":"Transfer Talebi Oluştur"},{"Id":957412,"PropertyName":"value","Value":"Seçilen ürün için transfer talebi bilgilerini tamamlayın."},{"Id":455994,"PropertyName":"value","Value":"Talep numarası gönderim sonrasında otomatik oluşturulacaktır."},{"Id":533446,"PropertyName":"value","Value":"Mağazadan Mağazaya"},{"Id":806195,"PropertyName":"value","Value":"Talep Eden Mağaza"},{"Id":945722,"PropertyName":"value","Value":"Adana Times"},{"Id":267007,"PropertyName":"value","Value":"Talep Edilen Mağaza"},{"Id":406890,"PropertyName":"value","Value":"Gaziantep Times"},{"Id":736523,"PropertyName":"value","Value":"Ürün Kodu"},{"Id":147010,"PropertyName":"value","Value":"126711"},{"Id":708566,"PropertyName":"value","Value":"Ürün Adı"},{"Id":487327,"PropertyName":"value","Value":"Rolex Submariner Date"},{"Id":321450,"PropertyName":"value","Value":"Güncel Müsait Stok"},{"Id":832303,"PropertyName":"value","Value":"4 adet"},{"Id":118170,"PropertyName":"value","Value":"Talep Miktarı *"},{"Id":307754,"PropertyName":"placeholder","Value":"Talep miktarını girin"},{"Id":400979,"PropertyName":"value","Value":"En fazla 4 adet talep edebilirsiniz."},{"Id":320843,"PropertyName":"value","Value":"Talep Notu *"},{"Id":569075,"PropertyName":"placeholder","Value":"Talep gerekçesini veya açıklamanızı girin"},{"Id":162627,"PropertyName":"value","Value":"0 / 1000"},{"Id":604330,"PropertyName":"value","Value":"Transfer Talebini Onaya Gönder"},{"Id":84723,"PropertyName":"value","Value":"Bu transfer talebini onaya göndermek istediğinizden emin misiniz?"},{"Id":765463,"PropertyName":"value","Value":"Mağazadan Mağazaya"},{"Id":664030,"PropertyName":"value","Value":"Adana Times"},{"Id":706479,"PropertyName":"value","Value":"Gaziantep Times"},{"Id":145260,"PropertyName":"value","Value":"Rolex Submariner Date"},{"Id":826249,"PropertyName":"value","Value":"1 adet"},{"Id":186167,"PropertyName":"label","Value":"Vazgeç"},{"Id":136064,"PropertyName":"label","Value":"Onaya Gönder"}]}]
    defaultML = "en_US"
    
    screenHash = ""
    


    constructor(props) {
        super(props);


        this.state = {
            isSpinnerVisible: false,
            isPageVisible: false,
            isLeftMenuVisible: false,
            spinnerCount: 0,
            selectedLanguage: "",
            isPageInitLoaded: false,
            isPageRecurringLoaded: false,
            
        }

        this.state.isPageVisible = true;
        
    }

    async componentDidMount() {

        if (KuikaAppManager.isPageInitPrevented()) {
            KuikaAppManager.calculateAndSetBodyHeight("transfertalebiolusturstok", "");
            return;
        }
        
        
        ReactSystemFunctions.validateToken()
        this.fillFormInitValues();
        if (true){
            
        }
        
        
        
        KuikaAppManager.calculateAndSetBodyHeight("transfertalebiolusturstok", "");

        if (ReactSystemFunctions.getIsMicroApp() === false) {
           window.parentScreen = this;
        }
    }

    componentWillUnmount() {
        
        
        

        if (ReactSystemFunctions.getIsMicroApp() === false) {
           window.parentScreen = null;
        }
    }

    

        
    componentDidUpdate= async (prevProps, prevState) => {
		KuikaAppManager.calculateAndSetBodyHeight("transfertalebiolusturstok", ""    );
        if (prevProps?.location?.search !== (this.props as any)?.location?.search) {
			
		}

        

        if (ReactSystemFunctions.getIsMicroApp() === false) {
            for (const key in prevState) {
                if (key.startsWith('NavVisible') && prevState[key] === true && this.state[key] === false) {
                    window.parentScreen = this;
                    break;
                }
            }
        }
	}

    fillFormInitValues() {
        this.props.form?.setFieldsValue({
transfertalebiolusturstok_307754_value: 1
});

    }

      setPageInitLoaded = (value: boolean) => {
        this.setState({ isPageInitLoaded: value });
      }

      setPageRecurringLoaded = (value: boolean) => {
        this.setState({ isPageRecurringLoaded: value });
      }

      clearFieldValidation = (changedValues: any) => {
        const fieldName = Object.keys(changedValues)[0];
        if (fieldName) {
          this.props.form?.setFields([
            {
              name: fieldName,
              errors: []
            }
          ]);
        }
      };

      




    async callCallbackFunction(diId: number, isFromMaster: boolean = false) {
        let isErrorOccurred = false;

    }


}
