import React from "react";
import Axios, { AxiosResponse } from "axios";
import { KuikaAppManager } from "../../shared/utilty/kuika-app-manager";
import { ReactSystemFunctions } from "../../shared/utilty/react-system-functions";
import { KNavigator } from "../../shared/hoc/with-history";
import { KContext } from "../../shared/hoc/with-context";
import { useLocation } from "react-router-dom";
import { FormInstance } from "antd/es/form";
import { Guid } from "guid-typescript";
import Swal from "sweetalert2";
import { KMainFunctions } from "../../shared/utilty/main-functions";
import moment from "moment";
import { IValidationData } from "../../models/dto/validation-data";
import { IStripePayment } from "../../models/dto/stripe-payment";
import { IUserInfoDto } from "../../models/dto/user-info.dto";
import { UserService } from "../../services/user-service";
import { kuikaCoreWasmBridgeService } from "../../services/_singletons";
import _ from "lodash";
import mqtt, { MqttClient } from "mqtt";
import { IMqttResult } from "../../models/dto/mqtt.dto";
import { MasterScreen_ScreenContext } from "../masterscreen/masterscreen-context";

declare let window: any;

export interface ITaskManagementPerson_ScreenProps {
  navigator: KNavigator;
  form: FormInstance<any>;
  googleLogin: any;
  screenInputs: any;
  context: KContext;
  initialValues: any;
  children: any;
}

export interface ITaskManagementPerson_ScreenState {
    isSpinnerVisible: boolean;
    isPageVisible: boolean;
	isLeftMenuVisible: boolean;
    spinnerCount: number;
    selectedLanguage: string;
    isPageInitLoaded: false;
    isPageRecurringLoaded: false;
	TMSalesPersonDashBoardTaskList: any[];
	TMSalesPersonDashBoardTaskList_dummy: any[];
	NAVIGATE: any;
	NAVIGATE_dummy: any;
	isComp2068142632Visible: 'visible' | 'hidden';
	isComp1292281252Visible: 'visible' | 'hidden';
	isComp2094032383Visible: 'visible' | 'hidden';
	isComp777136060Visible: 'visible' | 'hidden';
	isComp1216175397Visible: 'visible' | 'hidden';
	isComp1057774360Visible: 'visible' | 'hidden';
	isComp999358601Visible: 'visible' | 'hidden';
	isComp1732820688Visible: 'visible' | 'hidden';
	isComp1398302429Visible: 'visible' | 'hidden';
	isComp458598940Visible: 'visible' | 'hidden';
	isComp397739370Visible: 'visible' | 'hidden';
	isComp265069318Visible: 'visible' | 'hidden';
	isComp510019112Visible: 'visible' | 'hidden';
	isComp247345099Visible: 'visible' | 'hidden';

}

export class TaskManagementPerson_ScreenBase extends React.PureComponent<ITaskManagementPerson_ScreenProps, any> {
    static contextType = MasterScreen_ScreenContext;
    declare context: React.ContextType<typeof MasterScreen_ScreenContext>;
	taskmanagementperson_419024151_value_kuikaSelectBoxRef: React.RefObject<any>;
	taskmanagementperson_78969483_value_kuikaTableRef: React.RefObject<any>;
    ml=[{"Id":"d5a61d2b-bd60-485f-86e2-661e9ed4e486","Name":"en_US","ShortName":"English","IsDefault":true,"LanguagePhrases":[]},{"Id":"1152c2a8-6da6-42cc-86f6-7035c94c49c7","Name":"FixedValues","ShortName":"FixedValues","LanguagePhrases":[{"Id":1766216893,"PropertyName":"value","Value":"Öncelikli Görevlerim"},{"Id":1139202618,"PropertyName":"value","Value":"Günlük operasyon akışında ilk aksiyon gerektiren görevler"},{"Id":1657887813,"PropertyName":"value","Value":"Operasyon Tablosu"},{"Id":989322873,"PropertyName":"label","Value":"Talep Ekle"},{"Id":419024151,"PropertyName":"placeholder","Value":"Görev Seç"},{"Id":1799038793,"PropertyName":"title","Value":"Lead No"},{"Id":1337348636,"PropertyName":"value","Value":"[datafield:leadnumarasi]"},{"Id":1113887636,"PropertyName":"title","Value":"Mağaza"},{"Id":738827030,"PropertyName":"value","Value":"[datafield:storename]"},{"Id":780184848,"PropertyName":"title","Value":"Müşteri"},{"Id":2139042731,"PropertyName":"value","Value":"[datafield:musteri]"},{"Id":1317974218,"PropertyName":"title","Value":"Ürün"},{"Id":1904027612,"PropertyName":"value","Value":"[datafield:productname]"},{"Id":1038827662,"PropertyName":"title","Value":"Kategori"},{"Id":2068142632,"PropertyName":"value","Value":"[datafield:categoryname]"},{"Id":1292281252,"PropertyName":"value","Value":"[datafield:categoryname]"},{"Id":2094032383,"PropertyName":"value","Value":"[datafield:categoryname]"},{"Id":777136060,"PropertyName":"value","Value":"[datafield:categoryname]"},{"Id":1195667428,"PropertyName":"title","Value":"Mevcut Durum"},{"Id":1216175397,"PropertyName":"value","Value":"[datafield:processname]"},{"Id":1057774360,"PropertyName":"value","Value":"[datafield:processname]"},{"Id":999358601,"PropertyName":"value","Value":"[datafield:processname]"},{"Id":1732820688,"PropertyName":"value","Value":"[datafield:processname]"},{"Id":1398302429,"PropertyName":"value","Value":"[datafield:processname]"},{"Id":1387229874,"PropertyName":"title","Value":"Termin Tarihi"},{"Id":1937625289,"PropertyName":"value","Value":"[datafield:termintarihi]"},{"Id":2115430482,"PropertyName":"title","Value":"Rezerve Durumu"},{"Id":458598940,"PropertyName":"value","Value":"Evet"},{"Id":397739370,"PropertyName":"value","Value":"Hayır"},{"Id":265069318,"PropertyName":"value","Value":"Onay Bekliyor"},{"Id":274478640,"PropertyName":"title","Value":"Görev Tipi"},{"Id":510019112,"PropertyName":"value","Value":"Satış Yap"},{"Id":247345099,"PropertyName":"value","Value":"Rezerve Talebi Gönder"},{"Id":1815347955,"PropertyName":"title","Value":"Aksiyon"},{"Id":850017961,"PropertyName":"label","Value":"Detaya Git"}]}]
    defaultML = "en_US"
    
    screenHash = ""
    

    private _prevMasterPageInitLoaded: boolean = false;
    private _prevMasterPageRecurringLoaded: boolean = false;
    private _prevShouldTriggerPageInit: boolean = false;
    constructor(props) {
        super(props);
		this.taskmanagementperson_419024151_value_kuikaSelectBoxRef = React.createRef();
		this.taskmanagementperson_78969483_value_kuikaTableRef = React.createRef();

        this.state = {
            isSpinnerVisible: false,
            isPageVisible: false,
            isLeftMenuVisible: false,
            spinnerCount: 0,
            selectedLanguage: "",
            isPageInitLoaded: false,
            isPageRecurringLoaded: false,
            	        TMSalesPersonDashBoardTaskList: [],
	        NAVIGATE: "",
	        dataSource_419024151: [{"key":"0","text":"Tümü"},{"key":"1","text":"Rezerve Talebi Gönder"},{"key":"2","text":"Satış Yap"}],
	        isComp2068142632Visible: 'hidden',
	        isComp1292281252Visible: 'hidden',
	        isComp2094032383Visible: 'hidden',
	        isComp777136060Visible: 'hidden',
	        isComp1216175397Visible: 'hidden',
	        isComp1057774360Visible: 'hidden',
	        isComp999358601Visible: 'hidden',
	        isComp1732820688Visible: 'hidden',
	        isComp1398302429Visible: 'hidden',
	        isComp458598940Visible: 'hidden',
	        isComp397739370Visible: 'hidden',
	        isComp265069318Visible: 'hidden',
	        isComp510019112Visible: 'hidden',
	        isComp247345099Visible: 'hidden',

        }

        this.state.isPageVisible = true;
        
    }

    async componentDidMount() {

        if (KuikaAppManager.isPageInitPrevented()) {
            KuikaAppManager.calculateAndSetBodyHeight("taskmanagementperson", "masterscreen_screen");
            return;
        }
        this.context.registerCallbackFunction(this.callCallbackFunction.bind(this));
        
        ReactSystemFunctions.validateToken()
        this.fillFormInitValues();
        if (false){
            await this.TaskManagementPersonPageInit();
        } else if (this.context?.isMasterPageInitLoaded) { this._prevMasterPageInitLoaded = true; await this.TaskManagementPersonPageInit(); }
        
        
        
        KuikaAppManager.calculateAndSetBodyHeight("taskmanagementperson", "masterscreen_screen");

        if (ReactSystemFunctions.getIsMicroApp() === false) {
           window.parentScreen = this;
        }
    }

    componentWillUnmount() {
        
        
        

        if (ReactSystemFunctions.getIsMicroApp() === false) {
           window.parentScreen = null;
        }
    }

    

        
    componentDidUpdate= async (prevProps, prevState) => {
		KuikaAppManager.calculateAndSetBodyHeight("taskmanagementperson", "masterscreen_screen"    );
        if (prevProps?.location?.search !== (this.props as any)?.location?.search) {
			await this.TaskManagementPersonPageInit();
		}

        		if (this._prevMasterPageInitLoaded !== this.context.isMasterPageInitLoaded && this.context.isMasterPageInitLoaded === true) {this._prevMasterPageInitLoaded = this.context.isMasterPageInitLoaded;await this.TaskManagementPersonPageInit()}


        if (ReactSystemFunctions.getIsMicroApp() === false) {
            for (const key in prevState) {
                if (key.startsWith('NavVisible') && prevState[key] === true && this.state[key] === false) {
                    window.parentScreen = this;
                    break;
                }
            }
        }
	}

    fillFormInitValues() {
        this.props.form?.setFieldsValue({
});

    }

      setPageInitLoaded = (value: boolean) => {
        this.setState({ isPageInitLoaded: value });
      }

      setPageRecurringLoaded = (value: boolean) => {
        this.setState({ isPageRecurringLoaded: value });
      }

      clearFieldValidation = (changedValues: any) => {
        const fieldName = Object.keys(changedValues)[0];
        if (fieldName) {
          this.props.form?.setFields([
            {
              name: fieldName,
              errors: []
            }
          ]);
        }
      };

      

    TaskManagementPersonPageInit = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


	if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }

        let localVar = {
			UserId_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.getMyUserId(), "Guid"),
			TaskFilter_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toInteger(this, ReactSystemFunctions.value(this, "taskmanagementperson_419024151_value", "value", "", "key", "")), "number")
        }

	KuikaAppManager.showSpinner(this);
	
        if (true) {
        KuikaAppManager.showSpinner(this);
        }
        let result = await KuikaAppManager.ApiRequest(this, "TaskManagementPerson/TaskManagementPersonPageInit", localVar)
        if (!KMainFunctions.IsResStatus2XX(result)) return true;

		stateVars.TMSalesPersonDashBoardTaskList = result?.data.tmSalesPersonDashBoardTaskList;
		
		this.props.form?.setFieldsValue(formVars);
		
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.TaskManagementPersonPageInit1_();
                  resolve();
                });
          })



        
        KuikaAppManager.hideSpinner(this);
        return isErrorOccurred;
    }
	TaskManagementPersonPageInit1_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


	if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }

			
			stateVars.dataSource_78969483 = stateVars.TMSalesPersonDashBoardTaskList ?? this.state.TMSalesPersonDashBoardTaskList;
			stateVars.isComp2068142632Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, "taskmanagementperson_78969483_value", "categoryName"), ReactSystemFunctions.convertToTypeByName("Kategori 2", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp1292281252Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, "taskmanagementperson_78969483_value", "categoryName"), ReactSystemFunctions.convertToTypeByName("Kategori 1", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp2094032383Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, "taskmanagementperson_78969483_value", "categoryName"), ReactSystemFunctions.convertToTypeByName("DEFAULT", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp777136060Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, "taskmanagementperson_78969483_value", "categoryName"), ReactSystemFunctions.convertToTypeByName("Kategori 3", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp1216175397Visible = (((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, "taskmanagementperson_78969483_value", "processCode"), ReactSystemFunctions.convertToTypeByName("PENDING", "string")) || ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, "taskmanagementperson_78969483_value", "processCode"), ReactSystemFunctions.convertToTypeByName("TERMIN_PENDING", "string")) || ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, "taskmanagementperson_78969483_value", "processCode"), ReactSystemFunctions.convertToTypeByName("DELIVERY_PENDING", "string")))) === true ? "visible" : "hidden")
			stateVars.isComp1057774360Visible = (((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, "taskmanagementperson_78969483_value", "processCode"), ReactSystemFunctions.convertToTypeByName("CUSTOMER_DECLINED", "string")) || ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, "taskmanagementperson_78969483_value", "processCode"), ReactSystemFunctions.convertToTypeByName("REJECTED", "string")))) === true ? "visible" : "hidden")
			stateVars.isComp999358601Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, "taskmanagementperson_78969483_value", "processCode"), ReactSystemFunctions.convertToTypeByName("DELIVERED", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp1732820688Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, "taskmanagementperson_78969483_value", "processCode"), ReactSystemFunctions.convertToTypeByName("CLOSED", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp1398302429Visible = (((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, "taskmanagementperson_78969483_value", "processCode"), ReactSystemFunctions.convertToTypeByName("APPROVED", "string")) || ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, "taskmanagementperson_78969483_value", "processCode"), ReactSystemFunctions.convertToTypeByName("CREATED", "string")))) === true ? "visible" : "hidden")
			stateVars.isComp458598940Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, "taskmanagementperson_78969483_value", "rezerveDurumu"), ReactSystemFunctions.convertToTypeByName("Evet", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp397739370Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, "taskmanagementperson_78969483_value", "rezerveDurumu"), ReactSystemFunctions.convertToTypeByName("Hayır", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp265069318Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, "taskmanagementperson_78969483_value", "rezerveDurumu"), ReactSystemFunctions.convertToTypeByName("Onay Bekliyor", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp510019112Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, "taskmanagementperson_78969483_value", "satisYapShow"), ReactSystemFunctions.convertToTypeByName("True", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp247345099Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, "taskmanagementperson_78969483_value", "rezervTalebiGonderShow"), ReactSystemFunctions.convertToTypeByName("True", "string"))) === true ? "visible" : "hidden")

	this.props.form?.setFieldsValue(formVars);
	this.setState(stateVars);
	KuikaAppManager.hideSpinner(this);

            this.setPageInitLoaded(true);
            return isErrorOccurred;
        }




		TaskManagementPersonComponent_989322873_onClick = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
KuikaAppManager.showSpinner(this);

const __currentPath = (window.location.hash ? window.location.hash.replace(/^#/, '').split('?')[0] : window.location.pathname.split('?')[0]).toLowerCase();
if (__currentPath !== "/leadaddtemp") {
  this.context.setMasterPageInitLoaded(false);
  this.context.setMasterPageRecurringLoaded(false);
  this.context.setShouldTriggerPageInit(true);
}
					KuikaAppManager.prepareForNavigation();
						KuikaAppManager.addToPageInputVariables("LeadAddTemp", "CustomerId", ReactSystemFunctions.convertToTypeByName("00000000-0000-0000-0000-000000000000", "Guid"));

				stateVars.NAVIGATE = await ReactSystemFunctions.navigate(this, undefined, "TaskManagementPerson", "LeadAddTemp", "", "currentPage", null, null, null, null, null, null, true, false);

		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

            
            return isErrorOccurred;
        }


    TaskManagementPersonComponent_419024151_onChange = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
		KuikaAppManager.increaseServerRequestCount();

        let localVar = {
				UserId_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.getMyUserId(), "Guid"),
				TaskFilter_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toInteger(this, ReactSystemFunctions.value(this, "taskmanagementperson_419024151_value", "value", "", "key", "")), "number")
        }

		KuikaAppManager.showSpinner(this);
		
        if (true) {
        KuikaAppManager.showSpinner(this);
        }
        let result = await KuikaAppManager.ApiRequest(this, "TaskManagementPerson/TaskManagementPersonComponent_419024151_onChange", localVar)
        if (!KMainFunctions.IsResStatus2XX(result)) return true;

			stateVars.TMSalesPersonDashBoardTaskList = result?.data.tmSalesPersonDashBoardTaskList;
			
			this.props.form?.setFieldsValue(formVars);
			
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.TaskManagementPersonComponent_419024151_onChange1_();
                  resolve();
                });
          })



        
        KuikaAppManager.hideSpinner(this);
        return isErrorOccurred;
    }
		TaskManagementPersonComponent_419024151_onChange1_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }

				
				stateVars.dataSource_78969483 = stateVars.TMSalesPersonDashBoardTaskList ?? this.state.TMSalesPersonDashBoardTaskList;

		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

            
            return isErrorOccurred;
        }




		TaskManagementPersonComponent_510019112_onClick = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
KuikaAppManager.showSpinner(this);

					KuikaAppManager.prepareForNavigation();
						KuikaAppManager.addToPageInputVariables("TalepSatisIslemi", "LeadId", ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, "taskmanagementperson_78969483_value", "leadId"), "Guid"));
						KuikaAppManager.addToPageInputVariables("TalepSatisIslemi", "ApprovalId", ReactSystemFunctions.convertToTypeByName(null, "Guid"));
						KuikaAppManager.addToPageInputVariables("TalepSatisIslemi", "SalesLeadDraftId", ReactSystemFunctions.convertToTypeByName(null, "Guid"));

				stateVars.NAVIGATE = await ReactSystemFunctions.navigate(this, undefined, "TaskManagementPerson", "TalepSatisIslemi", "", "7d969ddf-5801-4eb6-b92b-12be35bdd565", "473454318", null, "right", "true", "90%", "100vh", true, false);

		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

            
            return isErrorOccurred;
        }


		TaskManagementPersonComponent_247345099_onClick = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
KuikaAppManager.showSpinner(this);

					KuikaAppManager.prepareForNavigation();
						KuikaAppManager.addToPageInputVariables("reservationPopup1", "LeadId", ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, "taskmanagementperson_78969483_value", "leadId"), "Guid"));

				stateVars.NAVIGATE = await ReactSystemFunctions.navigate(this, undefined, "TaskManagementPerson", "reservationPopup1", "", "7d969ddf-5801-4eb6-b92b-12be35bdd565", "1144146050", null, "right", "true", "90%", "100vh", true, false);

		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

            
            return isErrorOccurred;
        }


		TaskManagementPersonComponent_850017961_onClick = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
KuikaAppManager.showSpinner(this);

					KuikaAppManager.prepareForNavigation();
						KuikaAppManager.addToPageInputVariables("LeadDetailTemp", "LeadId", ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, "taskmanagementperson_78969483_value", "leadId"), "Guid"));

				stateVars.NAVIGATE = await ReactSystemFunctions.navigate(this, undefined, "TaskManagementPerson", "LeadDetailTemp", "", "7d969ddf-5801-4eb6-b92b-12be35bdd565", "1077967658", null, "right", "true", "70vw", "100vh", true, false);

		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

            
            return isErrorOccurred;
        }




    async callCallbackFunction(diId: number, isFromMaster: boolean = false) {
        let isErrorOccurred = false;
		let pageInitCallerNavDiIDs = [, 473454318, 1144146050, 1077967658] as number[];
		if (isFromMaster || pageInitCallerNavDiIDs.indexOf(diId) > -1) {
			await this.TaskManagementPersonPageInit();
		}

    }


}
