import React from "react";
import Axios, { AxiosResponse } from "axios";
import { KuikaAppManager } from "../../shared/utilty/kuika-app-manager";
import { ReactSystemFunctions } from "../../shared/utilty/react-system-functions";
import { KNavigator } from "../../shared/hoc/with-history";
import { KContext } from "../../shared/hoc/with-context";
import { useLocation } from "react-router-dom";
import { FormInstance } from "antd/es/form";
import { Guid } from "guid-typescript";
import Swal from "sweetalert2";
import { KMainFunctions } from "../../shared/utilty/main-functions";
import moment from "moment";
import { IValidationData } from "../../models/dto/validation-data";
import { IStripePayment } from "../../models/dto/stripe-payment";
import { IUserInfoDto } from "../../models/dto/user-info.dto";
import { UserService } from "../../services/user-service";
import { kuikaCoreWasmBridgeService } from "../../services/_singletons";
import _ from "lodash";
import mqtt, { MqttClient } from "mqtt";
import { IMqttResult } from "../../models/dto/mqtt.dto";
import { MasterScreen_ScreenContext } from "../masterscreen/masterscreen-context";

declare let window: any;

export interface ITaskManagementManager_ScreenProps {
  navigator: KNavigator;
  form: FormInstance<any>;
  googleLogin: any;
  screenInputs: any;
  context: KContext;
  initialValues: any;
  children: any;
}

export interface ITaskManagementManager_ScreenState {
    isSpinnerVisible: boolean;
    isPageVisible: boolean;
	isLeftMenuVisible: boolean;
    spinnerCount: number;
    selectedLanguage: string;
    isPageInitLoaded: false;
    isPageRecurringLoaded: false;
	TMGetDashboardStoreManagerTaskList: any[];
	TMGetDashboardStoreManagerTaskList_dummy: any[];
	NAVIGATE: any;
	NAVIGATE_dummy: any;
	isComp203840255Visible: 'visible' | 'hidden';
	isComp24360287Visible: 'visible' | 'hidden';
	isComp111937696Visible: 'visible' | 'hidden';
	isComp637749070Visible: 'visible' | 'hidden';
	isComp1396492598Visible: 'visible' | 'hidden';
	isComp206986698Visible: 'visible' | 'hidden';
	isComp116552440Visible: 'visible' | 'hidden';
	isComp1984058518Visible: 'visible' | 'hidden';
	isComp1839108734Visible: 'visible' | 'hidden';
	isComp776899827Visible: 'visible' | 'hidden';
	isComp1024228997Visible: 'visible' | 'hidden';
	isComp276981289Visible: 'visible' | 'hidden';
	isComp1887688986Visible: 'visible' | 'hidden';
	isComp577783133Visible: 'visible' | 'hidden';
	isComp1078375097Visible: 'visible' | 'hidden';

}

export class TaskManagementManager_ScreenBase extends React.PureComponent<ITaskManagementManager_ScreenProps, any> {
    static contextType = MasterScreen_ScreenContext;
    declare context: React.ContextType<typeof MasterScreen_ScreenContext>;
	taskmanagementmanager_2095323019_value_kuikaSelectBoxRef: React.RefObject<any>;
	taskmanagementmanager_1164003735_value_kuikaTableRef: React.RefObject<any>;
    ml=[{"Id":"d5a61d2b-bd60-485f-86e2-661e9ed4e486","Name":"en_US","ShortName":"English","IsDefault":true,"LanguagePhrases":[]},{"Id":"a702bc60-2d6f-47aa-89af-93ed2674174d","Name":"FixedValues","ShortName":"FixedValues","LanguagePhrases":[{"Id":297690801,"PropertyName":"value","Value":"Öncelikli Görevlerim"},{"Id":1673743345,"PropertyName":"value","Value":"Günlük operasyon akışında ilk aksiyon gerektiren görevler"},{"Id":1113483563,"PropertyName":"value","Value":"Operasyon Tablosu"},{"Id":2006693355,"PropertyName":"label","Value":"Talep Ekle"},{"Id":2095323019,"PropertyName":"placeholder","Value":"Görev Seç"},{"Id":1933464709,"PropertyName":"title","Value":"Lead No"},{"Id":1228054126,"PropertyName":"value","Value":"[datafield:leadnumarasi]"},{"Id":50517367,"PropertyName":"title","Value":"Mağaza"},{"Id":149506683,"PropertyName":"value","Value":"[datafield:storename]"},{"Id":673670289,"PropertyName":"title","Value":"Müşteri"},{"Id":1787543959,"PropertyName":"value","Value":"[datafield:musteri]"},{"Id":1732718096,"PropertyName":"title","Value":"Ürün"},{"Id":1237726798,"PropertyName":"value","Value":"[datafield:productname]"},{"Id":1507712585,"PropertyName":"title","Value":"Kategori"},{"Id":203840255,"PropertyName":"value","Value":"[datafield:categoryname]"},{"Id":24360287,"PropertyName":"value","Value":"[datafield:categoryname]"},{"Id":111937696,"PropertyName":"value","Value":"[datafield:categoryname]"},{"Id":637749070,"PropertyName":"value","Value":"[datafield:categoryname]"},{"Id":1682858252,"PropertyName":"title","Value":"Mevcut Durum"},{"Id":1396492598,"PropertyName":"value","Value":"[datafield:processname]"},{"Id":206986698,"PropertyName":"value","Value":"[datafield:processname]"},{"Id":116552440,"PropertyName":"value","Value":"[datafield:processname]"},{"Id":1984058518,"PropertyName":"value","Value":"[datafield:processname]"},{"Id":1839108734,"PropertyName":"value","Value":"[datafield:processname]"},{"Id":1221573264,"PropertyName":"title","Value":"Termin Tarihi"},{"Id":1156311064,"PropertyName":"value","Value":"[datafield:termintarihi]"},{"Id":411526142,"PropertyName":"title","Value":"Görev Tipi"},{"Id":776899827,"PropertyName":"value","Value":"[datafield:tasktitle]"},{"Id":1024228997,"PropertyName":"value","Value":"[datafield:tasktitle]"},{"Id":276981289,"PropertyName":"value","Value":"[datafield:tasktitle]"},{"Id":1887688986,"PropertyName":"value","Value":"[datafield:tasktitle]"},{"Id":577783133,"PropertyName":"value","Value":"[datafield:tasktitle]"},{"Id":1078375097,"PropertyName":"value","Value":"[datafield:tasktitle]"},{"Id":701385164,"PropertyName":"title","Value":"Aksiyon"},{"Id":1151895281,"PropertyName":"label","Value":"Detaya Git"}]}]
    defaultML = "en_US"
    
    screenHash = ""
    

    private _prevMasterPageInitLoaded: boolean = false;
    private _prevMasterPageRecurringLoaded: boolean = false;
    private _prevShouldTriggerPageInit: boolean = false;
    constructor(props) {
        super(props);
		this.taskmanagementmanager_2095323019_value_kuikaSelectBoxRef = React.createRef();
		this.taskmanagementmanager_1164003735_value_kuikaTableRef = React.createRef();

        this.state = {
            isSpinnerVisible: false,
            isPageVisible: false,
            isLeftMenuVisible: false,
            spinnerCount: 0,
            selectedLanguage: "",
            isPageInitLoaded: false,
            isPageRecurringLoaded: false,
            	        TMGetDashboardStoreManagerTaskList: [],
	        NAVIGATE: "",
	        dataSource_2095323019: [{"key":"1","text":"Onay Bekleyenler"},{"key":"2","text":"Teslim Bekleyenler"},{"key":"3","text":"Termin Önerisi Bekleyenler"},{"key":"4","text":"Rezerv Onayı Bekleyenler"},{"key":"5","text":"Rezerv Talebi Bekleyenler"}],
	        isComp203840255Visible: 'hidden',
	        isComp24360287Visible: 'hidden',
	        isComp111937696Visible: 'hidden',
	        isComp637749070Visible: 'hidden',
	        isComp1396492598Visible: 'hidden',
	        isComp206986698Visible: 'hidden',
	        isComp116552440Visible: 'hidden',
	        isComp1984058518Visible: 'hidden',
	        isComp1839108734Visible: 'hidden',
	        isComp776899827Visible: 'hidden',
	        isComp1024228997Visible: 'hidden',
	        isComp276981289Visible: 'hidden',
	        isComp1887688986Visible: 'hidden',
	        isComp577783133Visible: 'hidden',
	        isComp1078375097Visible: 'hidden',

        }

        this.state.isPageVisible = true;
        
    }

    async componentDidMount() {

        if (KuikaAppManager.isPageInitPrevented()) {
            KuikaAppManager.calculateAndSetBodyHeight("taskmanagementmanager", "masterscreen_screen");
            return;
        }
        this.context.registerCallbackFunction(this.callCallbackFunction.bind(this));
        
        ReactSystemFunctions.validateToken()
        this.fillFormInitValues();
        if (false){
            await this.TaskManagementManagerPageInit();
        } else if (this.context?.isMasterPageInitLoaded) { this._prevMasterPageInitLoaded = true; await this.TaskManagementManagerPageInit(); }
        
        
        
        KuikaAppManager.calculateAndSetBodyHeight("taskmanagementmanager", "masterscreen_screen");

        if (ReactSystemFunctions.getIsMicroApp() === false) {
           window.parentScreen = this;
        }
    }

    componentWillUnmount() {
        
        
        

        if (ReactSystemFunctions.getIsMicroApp() === false) {
           window.parentScreen = null;
        }
    }

    

        
    componentDidUpdate= async (prevProps, prevState) => {
		KuikaAppManager.calculateAndSetBodyHeight("taskmanagementmanager", "masterscreen_screen"    );
        if (prevProps?.location?.search !== (this.props as any)?.location?.search) {
			await this.TaskManagementManagerPageInit();
		}

        		if (this._prevMasterPageInitLoaded !== this.context.isMasterPageInitLoaded && this.context.isMasterPageInitLoaded === true) {this._prevMasterPageInitLoaded = this.context.isMasterPageInitLoaded;await this.TaskManagementManagerPageInit()}


        if (ReactSystemFunctions.getIsMicroApp() === false) {
            for (const key in prevState) {
                if (key.startsWith('NavVisible') && prevState[key] === true && this.state[key] === false) {
                    window.parentScreen = this;
                    break;
                }
            }
        }
	}

    fillFormInitValues() {
        this.props.form?.setFieldsValue({
});

    }

      setPageInitLoaded = (value: boolean) => {
        this.setState({ isPageInitLoaded: value });
      }

      setPageRecurringLoaded = (value: boolean) => {
        this.setState({ isPageRecurringLoaded: value });
      }

      clearFieldValidation = (changedValues: any) => {
        const fieldName = Object.keys(changedValues)[0];
        if (fieldName) {
          this.props.form?.setFields([
            {
              name: fieldName,
              errors: []
            }
          ]);
        }
      };

      

    TaskManagementManagerPageInit = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


	if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }

        let localVar = {
			UserId_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.getMyUserId(), "Guid"),
			TaskTypeFilter_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toInteger(this, ReactSystemFunctions.value(this, "taskmanagementmanager_2095323019_value", "value", "", "key", "")), "number")
        }

	KuikaAppManager.showSpinner(this);
	
        if (true) {
        KuikaAppManager.showSpinner(this);
        }
        let result = await KuikaAppManager.ApiRequest(this, "TaskManagementManager/TaskManagementManagerPageInit", localVar)
        if (!KMainFunctions.IsResStatus2XX(result)) return true;

		stateVars.TMGetDashboardStoreManagerTaskList = result?.data.tmGetDashboardStoreManagerTaskList;
		
		this.props.form?.setFieldsValue(formVars);
		
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.TaskManagementManagerPageInit1_();
                  resolve();
                });
          })



        
        KuikaAppManager.hideSpinner(this);
        return isErrorOccurred;
    }
	TaskManagementManagerPageInit1_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


	if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }

			
			stateVars.dataSource_1164003735 = stateVars.TMGetDashboardStoreManagerTaskList ?? this.state.TMGetDashboardStoreManagerTaskList;
			stateVars.isComp203840255Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, "taskmanagementmanager_1164003735_value", "categoryName"), ReactSystemFunctions.convertToTypeByName("Kategori 2", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp24360287Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, "taskmanagementmanager_1164003735_value", "categoryName"), ReactSystemFunctions.convertToTypeByName("Kategori 1", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp111937696Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, "taskmanagementmanager_1164003735_value", "categoryName"), ReactSystemFunctions.convertToTypeByName("DEFAULT", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp637749070Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, "taskmanagementmanager_1164003735_value", "categoryName"), ReactSystemFunctions.convertToTypeByName("Kategori 3", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp1396492598Visible = (((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, "taskmanagementmanager_1164003735_value", "processCode"), ReactSystemFunctions.convertToTypeByName("PENDING", "string")) || ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, "taskmanagementmanager_1164003735_value", "processCode"), ReactSystemFunctions.convertToTypeByName("TERMIN_PENDING", "string")) || ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, "taskmanagementmanager_1164003735_value", "processCode"), ReactSystemFunctions.convertToTypeByName("DELIVERY_PENDING", "string")))) === true ? "visible" : "hidden")
			stateVars.isComp206986698Visible = (((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, "taskmanagementmanager_1164003735_value", "processCode"), ReactSystemFunctions.convertToTypeByName("CUSTOMER_DECLINED", "string")) || ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, "taskmanagementmanager_1164003735_value", "processCode"), ReactSystemFunctions.convertToTypeByName("REJECTED", "string")))) === true ? "visible" : "hidden")
			stateVars.isComp116552440Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, "taskmanagementmanager_1164003735_value", "processCode"), ReactSystemFunctions.convertToTypeByName("DELIVERED", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp1984058518Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, "taskmanagementmanager_1164003735_value", "processCode"), ReactSystemFunctions.convertToTypeByName("CLOSED", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp1839108734Visible = (((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, "taskmanagementmanager_1164003735_value", "processCode"), ReactSystemFunctions.convertToTypeByName("APPROVED", "string")) || ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, "taskmanagementmanager_1164003735_value", "processCode"), ReactSystemFunctions.convertToTypeByName("CREATED", "string")))) === true ? "visible" : "hidden")
			stateVars.isComp776899827Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, "taskmanagementmanager_1164003735_value", "actionCode"), ReactSystemFunctions.convertToTypeByName("APPROVE_RESERVATION", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp1024228997Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, "taskmanagementmanager_1164003735_value", "actionCode"), ReactSystemFunctions.convertToTypeByName("COMPLETE_SALE", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp276981289Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, "taskmanagementmanager_1164003735_value", "actionCode"), ReactSystemFunctions.convertToTypeByName("SET_ESTIMATE", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp1887688986Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, "taskmanagementmanager_1164003735_value", "actionCode"), ReactSystemFunctions.convertToTypeByName("SEND_ESTIMATE_REQUEST", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp577783133Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, "taskmanagementmanager_1164003735_value", "actionCode"), ReactSystemFunctions.convertToTypeByName("DIRECT_RESERVE", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp1078375097Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, "taskmanagementmanager_1164003735_value", "actionCode"), ReactSystemFunctions.convertToTypeByName("SEND_RESERVATION_REQUEST", "string"))) === true ? "visible" : "hidden")

	this.props.form?.setFieldsValue(formVars);
	this.setState(stateVars);
	KuikaAppManager.hideSpinner(this);

            this.setPageInitLoaded(true);
            return isErrorOccurred;
        }




		TaskManagementManagerComponent_2006693355_onClick = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
KuikaAppManager.showSpinner(this);

const __currentPath = (window.location.hash ? window.location.hash.replace(/^#/, '').split('?')[0] : window.location.pathname.split('?')[0]).toLowerCase();
if (__currentPath !== "/leadaddtemp") {
  this.context.setMasterPageInitLoaded(false);
  this.context.setMasterPageRecurringLoaded(false);
  this.context.setShouldTriggerPageInit(true);
}
					KuikaAppManager.prepareForNavigation();
						KuikaAppManager.addToPageInputVariables("LeadAddTemp", "CustomerId", ReactSystemFunctions.convertToTypeByName("00000000-0000-0000-0000-000000000000", "Guid"));

				stateVars.NAVIGATE = await ReactSystemFunctions.navigate(this, undefined, "TaskManagementManager", "LeadAddTemp", "", "currentPage", null, null, null, null, null, null, true, false);

		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

            
            return isErrorOccurred;
        }


    TaskManagementManagerComponent_2095323019_onChange = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
		KuikaAppManager.increaseServerRequestCount();

        let localVar = {
				UserId_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.getMyUserId(), "Guid"),
				TaskTypeFilter_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toInteger(this, ReactSystemFunctions.value(this, "taskmanagementmanager_2095323019_value", "value", "", "key", "")), "number")
        }

		KuikaAppManager.showSpinner(this);
		
        if (true) {
        KuikaAppManager.showSpinner(this);
        }
        let result = await KuikaAppManager.ApiRequest(this, "TaskManagementManager/TaskManagementManagerComponent_2095323019_onChange", localVar)
        if (!KMainFunctions.IsResStatus2XX(result)) return true;

			stateVars.TMGetDashboardStoreManagerTaskList = result?.data.tmGetDashboardStoreManagerTaskList;
			
			this.props.form?.setFieldsValue(formVars);
			
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.TaskManagementManagerComponent_2095323019_onChange1_();
                  resolve();
                });
          })



        
        KuikaAppManager.hideSpinner(this);
        return isErrorOccurred;
    }
		TaskManagementManagerComponent_2095323019_onChange1_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }

				
				stateVars.dataSource_1164003735 = stateVars.TMGetDashboardStoreManagerTaskList ?? this.state.TMGetDashboardStoreManagerTaskList;

		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

            
            return isErrorOccurred;
        }




		TaskManagementManagerComponent_776899827_onClick = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
KuikaAppManager.showSpinner(this);

					KuikaAppManager.prepareForNavigation();
						KuikaAppManager.addToPageInputVariables("PopRezervOnayBekleyenPopup", "LeadId", ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, "taskmanagementmanager_1164003735_value", "leadId"), "Guid"));

				stateVars.NAVIGATE = await ReactSystemFunctions.navigate(this, undefined, "TaskManagementManager", "PopRezervOnayBekleyenPopup", "", "7d969ddf-5801-4eb6-b92b-12be35bdd565", "190183522", null, "right", "true", "90%", "100vh", true, false);

		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

            
            return isErrorOccurred;
        }


		TaskManagementManagerComponent_1024228997_onClick = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
KuikaAppManager.showSpinner(this);

					KuikaAppManager.prepareForNavigation();
						KuikaAppManager.addToPageInputVariables("TalepSatisIslemi", "LeadId", ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, "taskmanagementmanager_1164003735_value", "leadId"), "Guid"));
						KuikaAppManager.addToPageInputVariables("TalepSatisIslemi", "ApprovalId", ReactSystemFunctions.convertToTypeByName(null, "Guid"));
						KuikaAppManager.addToPageInputVariables("TalepSatisIslemi", "SalesLeadDraftId", ReactSystemFunctions.convertToTypeByName(null, "Guid"));

				stateVars.NAVIGATE = await ReactSystemFunctions.navigate(this, undefined, "TaskManagementManager", "TalepSatisIslemi", "", "7d969ddf-5801-4eb6-b92b-12be35bdd565", "878942499", null, "right", "true", "90%", "100vh", true, false);

		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

            
            return isErrorOccurred;
        }


		TaskManagementManagerComponent_276981289_onClick = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
KuikaAppManager.showSpinner(this);

					KuikaAppManager.prepareForNavigation();
						KuikaAppManager.addToPageInputVariables("PopOnayBekleyen", "LeadId", ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, "taskmanagementmanager_1164003735_value", "leadId"), "Guid"));

				stateVars.NAVIGATE = await ReactSystemFunctions.navigate(this, undefined, "TaskManagementManager", "PopOnayBekleyen", "", "7d969ddf-5801-4eb6-b92b-12be35bdd565", "291489283", null, "right", "true", "90%", "100vh", true, false);

		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

            
            return isErrorOccurred;
        }


		TaskManagementManagerComponent_1887688986_onClick = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
KuikaAppManager.showSpinner(this);

					KuikaAppManager.prepareForNavigation();
						KuikaAppManager.addToPageInputVariables("PopTerminOnerisiBekleyen", "LeadId", ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, "taskmanagementmanager_1164003735_value", "leadId"), "Guid"));

				stateVars.NAVIGATE = await ReactSystemFunctions.navigate(this, undefined, "TaskManagementManager", "PopTerminOnerisiBekleyen", "", "7d969ddf-5801-4eb6-b92b-12be35bdd565", "1632453697", null, "right", "true", "90%", "100vh", true, false);

		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

            
            return isErrorOccurred;
        }


		TaskManagementManagerComponent_577783133_onClick = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
KuikaAppManager.showSpinner(this);

					KuikaAppManager.prepareForNavigation();
						KuikaAppManager.addToPageInputVariables("reservationPopUp2", "LeadId", ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, "taskmanagementmanager_1164003735_value", "leadId"), "Guid"));

				stateVars.NAVIGATE = await ReactSystemFunctions.navigate(this, undefined, "TaskManagementManager", "reservationPopUp2", "", "7d969ddf-5801-4eb6-b92b-12be35bdd565", "1237060792", null, "right", "true", "90%", "100vh", true, false);

		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

            
            return isErrorOccurred;
        }


		TaskManagementManagerComponent_1078375097_onClick = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
KuikaAppManager.showSpinner(this);

					KuikaAppManager.prepareForNavigation();
						KuikaAppManager.addToPageInputVariables("reservationPopup1", "LeadId", ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, "taskmanagementmanager_1164003735_value", "leadId"), "Guid"));

				stateVars.NAVIGATE = await ReactSystemFunctions.navigate(this, undefined, "TaskManagementManager", "reservationPopup1", "", "7d969ddf-5801-4eb6-b92b-12be35bdd565", "473815598", null, "right", "true", "90%", "100vh", true, false);

		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

            
            return isErrorOccurred;
        }


		TaskManagementManagerComponent_1151895281_onClick = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
KuikaAppManager.showSpinner(this);

					KuikaAppManager.prepareForNavigation();
						KuikaAppManager.addToPageInputVariables("LeadDetailTemp", "LeadId", ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, "taskmanagementmanager_1164003735_value", "leadId"), "Guid"));

				stateVars.NAVIGATE = await ReactSystemFunctions.navigate(this, undefined, "TaskManagementManager", "LeadDetailTemp", "", "7d969ddf-5801-4eb6-b92b-12be35bdd565", "1985841002", null, "right", "true", "70vw", "100vh", true, false);

		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

            
            return isErrorOccurred;
        }


		TaskManagementManagerComponent_190183522_onClick = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
KuikaAppManager.showSpinner(this);

					KuikaAppManager.prepareForNavigation();
						KuikaAppManager.addToPageInputVariables("TalepSatisIslemi", "LeadId", ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, "taskmanagementmanager_1164003735_value", "leadId"), "Guid"));
						KuikaAppManager.addToPageInputVariables("TalepSatisIslemi", "ApprovalId", ReactSystemFunctions.convertToTypeByName(null, "Guid"));
						KuikaAppManager.addToPageInputVariables("TalepSatisIslemi", "SalesLeadDraftId", ReactSystemFunctions.convertToTypeByName(null, "Guid"));

				stateVars.NAVIGATE = await ReactSystemFunctions.navigate(this, undefined, "TaskManagementManager", "TalepSatisIslemi", "", "7d969ddf-5801-4eb6-b92b-12be35bdd565", "878942499", null, "right", "true", "90%", "100vh", true, false);

		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

            
            return isErrorOccurred;
        }


		TaskManagementManagerComponent_1632453697_onClick = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
KuikaAppManager.showSpinner(this);

					KuikaAppManager.prepareForNavigation();
						KuikaAppManager.addToPageInputVariables("reservationPopUp2", "LeadId", ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, "taskmanagementmanager_1164003735_value", "leadId"), "Guid"));

				stateVars.NAVIGATE = await ReactSystemFunctions.navigate(this, undefined, "TaskManagementManager", "reservationPopUp2", "", "7d969ddf-5801-4eb6-b92b-12be35bdd565", "1237060792", null, "right", "true", "90%", "100vh", true, false);

		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

            
            return isErrorOccurred;
        }




    async callCallbackFunction(diId: number, isFromMaster: boolean = false) {
        let isErrorOccurred = false;
		let pageInitCallerNavDiIDs = [, 190183522, 878942499, 291489283, 1632453697, 1237060792, 473815598, 1985841002, 878942499, 1237060792] as number[];
		if (isFromMaster || pageInitCallerNavDiIDs.indexOf(diId) > -1) {
			await this.TaskManagementManagerPageInit();
		}

    }


}
