import React from "react";
import Axios, { AxiosResponse } from "axios";
import { KuikaAppManager } from "../../shared/utilty/kuika-app-manager";
import { ReactSystemFunctions } from "../../shared/utilty/react-system-functions";
import { KNavigator } from "../../shared/hoc/with-history";
import { KContext } from "../../shared/hoc/with-context";
import { useLocation } from "react-router-dom";
import { FormInstance } from "antd/es/form";
import { Guid } from "guid-typescript";
import Swal from "sweetalert2";
import { KMainFunctions } from "../../shared/utilty/main-functions";
import moment from "moment";
import { IValidationData } from "../../models/dto/validation-data";
import { IStripePayment } from "../../models/dto/stripe-payment";
import { IUserInfoDto } from "../../models/dto/user-info.dto";
import { UserService } from "../../services/user-service";
import { kuikaCoreWasmBridgeService } from "../../services/_singletons";
import _ from "lodash";
import mqtt, { MqttClient } from "mqtt";
import { IMqttResult } from "../../models/dto/mqtt.dto";


declare let window: any;

export interface IAddDiscountLimit_ScreenProps {
  navigator: KNavigator;
  form: FormInstance<any>;
  googleLogin: any;
  screenInputs: any;
  context: KContext;
  initialValues: any;
  children: any;
}

export interface IAddDiscountLimit_ScreenState {
    isSpinnerVisible: boolean;
    isPageVisible: boolean;
	isLeftMenuVisible: boolean;
    spinnerCount: number;
    selectedLanguage: string;
    isPageInitLoaded: false;
    isPageRecurringLoaded: false;
	TM_DiscountLimitAdd: any[];
	TM_DiscountLimitAdd_dummy: any[];
	Notify: boolean;
	Notify_dummy: boolean;
	GoBack: any;
	GoBack_dummy: any;

}

export class AddDiscountLimit_ScreenBase extends React.PureComponent<IAddDiscountLimit_ScreenProps, any> {


    ml=[{"Id":"d5a61d2b-bd60-485f-86e2-661e9ed4e486","Name":"en_US","ShortName":"English","IsDefault":true,"LanguagePhrases":[]},{"Id":"205c7f4e-be85-4a1d-990f-2bad5499b39d","Name":"FixedValues","ShortName":"FixedValues","LanguagePhrases":[{"Id":191328,"PropertyName":"value","Value":"İskonto Limiti Giriniz"},{"Id":875888,"PropertyName":"value","Value":"İskonto Limiti %"},{"Id":913785,"PropertyName":"placeholder","Value":"10"},{"Id":608132,"PropertyName":"label","Value":"İskonto Limitini Uygula"}]}]
    defaultML = "en_US"
    
    screenHash = ""
    


    constructor(props) {
        super(props);


        this.state = {
            isSpinnerVisible: false,
            isPageVisible: false,
            isLeftMenuVisible: false,
            spinnerCount: 0,
            selectedLanguage: "",
            isPageInitLoaded: false,
            isPageRecurringLoaded: false,
            	        TM_DiscountLimitAdd: [],
	        Notify: false,
	        GoBack: "",

        }

        this.state.isPageVisible = true;
        
    }

    async componentDidMount() {

        if (KuikaAppManager.isPageInitPrevented()) {
            KuikaAppManager.calculateAndSetBodyHeight("adddiscountlimit", "");
            return;
        }
        
        
        ReactSystemFunctions.validateToken()
        this.fillFormInitValues();
        if (true){
            
        }
        
        
        
        KuikaAppManager.calculateAndSetBodyHeight("adddiscountlimit", "");

        if (ReactSystemFunctions.getIsMicroApp() === false) {
           window.parentScreen = this;
        }
    }

    componentWillUnmount() {
        
        
        

        if (ReactSystemFunctions.getIsMicroApp() === false) {
           window.parentScreen = null;
        }
    }

    

        
    componentDidUpdate= async (prevProps, prevState) => {
		KuikaAppManager.calculateAndSetBodyHeight("adddiscountlimit", ""    );
        if (prevProps?.location?.search !== (this.props as any)?.location?.search) {
			
		}

        

        if (ReactSystemFunctions.getIsMicroApp() === false) {
            for (const key in prevState) {
                if (key.startsWith('NavVisible') && prevState[key] === true && this.state[key] === false) {
                    window.parentScreen = this;
                    break;
                }
            }
        }
	}

    fillFormInitValues() {
        this.props.form?.setFieldsValue({
adddiscountlimit_913785_value: undefined
});

    }

      setPageInitLoaded = (value: boolean) => {
        this.setState({ isPageInitLoaded: value });
      }

      setPageRecurringLoaded = (value: boolean) => {
        this.setState({ isPageRecurringLoaded: value });
      }

      clearFieldValidation = (changedValues: any) => {
        const fieldName = Object.keys(changedValues)[0];
        if (fieldName) {
          this.props.form?.setFields([
            {
              name: fieldName,
              errors: []
            }
          ]);
        }
      };

      


    AddDiscountLimitComponent_608132_onClick = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
		KuikaAppManager.increaseServerRequestCount();

        let localVar = {
				MaxDiscountRate_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "adddiscountlimit_913785_value", "value", "", "", "")), "number")
        }

		KuikaAppManager.showSpinner(this);
		
        if (true) {
        KuikaAppManager.showSpinner(this);
        }
        let result = await KuikaAppManager.ApiRequest(this, "AddDiscountLimit/AddDiscountLimitComponent_608132_onClick", localVar)
        if (!KMainFunctions.IsResStatus2XX(result)) return true;

			stateVars.TM_DiscountLimitAdd = result?.data.tM_DiscountLimitAdd;
			this.props.form?.setFieldsValue(formVars);
			
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.AddDiscountLimitComponent_608132_onClick1_();
                  resolve();
                });
          })



        
        KuikaAppManager.hideSpinner(this);
        return isErrorOccurred;
    }
		AddDiscountLimitComponent_608132_onClick1_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }

				stateVars.Notify = await ReactSystemFunctions.notify(this, ReactSystemFunctions.toString(this, (stateVars.TM_DiscountLimitAdd !== undefined ? (stateVars.TM_DiscountLimitAdd?.length > 0 ? stateVars.TM_DiscountLimitAdd[0].message : null) : (this.state.TM_DiscountLimitAdd?.length > 0 ? this.state.TM_DiscountLimitAdd[0].message : null))), ReactSystemFunctions.convertToTypeByName("default", "string"), ReactSystemFunctions.convertToTypeByName("top-center", "string"), 2, ReactSystemFunctions.convertToTypeByName("", "string"), ReactSystemFunctions.convertToTypeByName("", "string"), 0);

		this.props.form?.setFieldsValue(formVars);
		
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.AddDiscountLimitComponent_608132_onClick2_();
                  resolve();
                });
          })

            
            return isErrorOccurred;
        }
		AddDiscountLimitComponent_608132_onClick2_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
if (ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, (stateVars.TM_DiscountLimitAdd !== undefined ? (stateVars.TM_DiscountLimitAdd?.length > 0 ? stateVars.TM_DiscountLimitAdd[0].success : null) : (this.state.TM_DiscountLimitAdd?.length > 0 ? this.state.TM_DiscountLimitAdd[0].success : null))), true)) {
            
				stateVars.GoBack = await ReactSystemFunctions.goBack(this, false);

		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

        } else {
            KuikaAppManager.hideSpinner(this);
        }

            
            return isErrorOccurred;
        }







    async callCallbackFunction(diId: number, isFromMaster: boolean = false) {
        let isErrorOccurred = false;

    }


}
