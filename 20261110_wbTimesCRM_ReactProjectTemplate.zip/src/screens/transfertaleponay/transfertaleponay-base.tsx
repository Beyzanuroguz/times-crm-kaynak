import React from "react";
import Axios, { AxiosResponse } from "axios";
import { KuikaAppManager } from "../../shared/utilty/kuika-app-manager";
import { ReactSystemFunctions } from "../../shared/utilty/react-system-functions";
import { KNavigator } from "../../shared/hoc/with-history";
import { KContext } from "../../shared/hoc/with-context";
import { useLocation } from "react-router-dom";
import { FormInstance } from "antd/es/form";
import { Guid } from "guid-typescript";
import Swal from "sweetalert2";
import { KMainFunctions } from "../../shared/utilty/main-functions";
import moment from "moment";
import { IValidationData } from "../../models/dto/validation-data";
import { IStripePayment } from "../../models/dto/stripe-payment";
import { IUserInfoDto } from "../../models/dto/user-info.dto";
import { UserService } from "../../services/user-service";
import { kuikaCoreWasmBridgeService } from "../../services/_singletons";
import _ from "lodash";
import mqtt, { MqttClient } from "mqtt";
import { IMqttResult } from "../../models/dto/mqtt.dto";


declare let window: any;

export interface ITransferTalepOnay_ScreenProps {
  navigator: KNavigator;
  form: FormInstance<any>;
  googleLogin: any;
  screenInputs: any;
  context: KContext;
  initialValues: any;
  children: any;
}

export interface ITransferTalepOnay_ScreenState {
    isSpinnerVisible: boolean;
    isPageVisible: boolean;
	isLeftMenuVisible: boolean;
    spinnerCount: number;
    selectedLanguage: string;
    isPageInitLoaded: false;
    isPageRecurringLoaded: false;

}

export class TransferTalepOnay_ScreenBase extends React.PureComponent<ITransferTalepOnay_ScreenProps, any> {


    ml=[{"Id":"d5a61d2b-bd60-485f-86e2-661e9ed4e486","Name":"en_US","ShortName":"English","IsDefault":true,"LanguagePhrases":[]},{"Id":"76beaf57-ece8-49df-831f-4d52a8bfd05c","Name":"FixedValues","ShortName":"FixedValues","LanguagePhrases":[{"Id":974779,"PropertyName":"label","Value":"Talep Detayına Dön"},{"Id":528940,"PropertyName":"value","Value":"Transfer Talep Onayı"},{"Id":762991,"PropertyName":"value","Value":"TR-06082026-0001"},{"Id":694731,"PropertyName":"value","Value":"TR-06082026-0001"},{"Id":450975,"PropertyName":"value","Value":"Onay Bekliyor"},{"Id":857032,"PropertyName":"value","Value":"Talep bilgilerini ve güncel stok durumunu kontrol ederek kararınızı verin."},{"Id":537387,"PropertyName":"value","Value":"Talep Özeti"},{"Id":942492,"PropertyName":"value","Value":"Talep Türü"},{"Id":737581,"PropertyName":"value","Value":"Mağazadan Mağazaya"},{"Id":913704,"PropertyName":"value","Value":"Talebi Açan"},{"Id":3779,"PropertyName":"value","Value":"Ayşe Demir"},{"Id":906026,"PropertyName":"value","Value":"Ürün Adı"},{"Id":87910,"PropertyName":"value","Value":"Rolex Submariner Date"},{"Id":995010,"PropertyName":"value","Value":"Talep Eden"},{"Id":358054,"PropertyName":"value","Value":"Adana Times"},{"Id":223031,"PropertyName":"value","Value":"Talep Tarihi"},{"Id":688535,"PropertyName":"value","Value":"06.08.2026 14:30"},{"Id":183342,"PropertyName":"value","Value":"Talep Miktarı"},{"Id":717459,"PropertyName":"value","Value":"2 adet"},{"Id":189891,"PropertyName":"value","Value":"Talep Edilen"},{"Id":945365,"PropertyName":"value","Value":"Gaziantep Times"},{"Id":382660,"PropertyName":"value","Value":"Ürün Kodu"},{"Id":217423,"PropertyName":"value","Value":"126711"},{"Id":748060,"PropertyName":"value","Value":"Talep Notu"},{"Id":554577,"PropertyName":"value","Value":"Müşteri teslimatı için ürünlerin en kısa sürede gönderilmesi rica olunur."},{"Id":135997,"PropertyName":"value","Value":"Güncel Stok Durumu"},{"Id":32061,"PropertyName":"value","Value":"Müsait Stok = Mevcut Stok − Aktif Rezervler − Açık Transferler"},{"Id":475572,"PropertyName":"value","Value":"Mevcut Stok"},{"Id":721639,"PropertyName":"value","Value":"5"},{"Id":811985,"PropertyName":"value","Value":"Aktif Rezerv"},{"Id":73047,"PropertyName":"value","Value":"1"},{"Id":19455,"PropertyName":"value","Value":"Açık Transfer"},{"Id":569820,"PropertyName":"value","Value":"0"},{"Id":910118,"PropertyName":"value","Value":"Güncel Müsait Stok"},{"Id":881452,"PropertyName":"value","Value":"4"},{"Id":392288,"PropertyName":"value","Value":"Talep Edilen Miktar"},{"Id":886483,"PropertyName":"value","Value":"2"},{"Id":4902,"PropertyName":"value","Value":"Stok Uygun"},{"Id":703241,"PropertyName":"label","Value":"Reddet"},{"Id":699583,"PropertyName":"label","Value":"Onayla"}]}]
    defaultML = "en_US"
    
    screenHash = ""
    


    constructor(props) {
        super(props);


        this.state = {
            isSpinnerVisible: false,
            isPageVisible: false,
            isLeftMenuVisible: false,
            spinnerCount: 0,
            selectedLanguage: "",
            isPageInitLoaded: false,
            isPageRecurringLoaded: false,
            
        }

        this.state.isPageVisible = true;
        
    }

    async componentDidMount() {

        if (KuikaAppManager.isPageInitPrevented()) {
            KuikaAppManager.calculateAndSetBodyHeight("transfertaleponay", "");
            return;
        }
        
        
        ReactSystemFunctions.validateToken()
        this.fillFormInitValues();
        if (true){
            
        }
        
        
        
        KuikaAppManager.calculateAndSetBodyHeight("transfertaleponay", "");

        if (ReactSystemFunctions.getIsMicroApp() === false) {
           window.parentScreen = this;
        }
    }

    componentWillUnmount() {
        
        
        

        if (ReactSystemFunctions.getIsMicroApp() === false) {
           window.parentScreen = null;
        }
    }

    

        
    componentDidUpdate= async (prevProps, prevState) => {
		KuikaAppManager.calculateAndSetBodyHeight("transfertaleponay", ""    );
        if (prevProps?.location?.search !== (this.props as any)?.location?.search) {
			
		}

        

        if (ReactSystemFunctions.getIsMicroApp() === false) {
            for (const key in prevState) {
                if (key.startsWith('NavVisible') && prevState[key] === true && this.state[key] === false) {
                    window.parentScreen = this;
                    break;
                }
            }
        }
	}

    fillFormInitValues() {
        this.props.form?.setFieldsValue({
});

    }

      setPageInitLoaded = (value: boolean) => {
        this.setState({ isPageInitLoaded: value });
      }

      setPageRecurringLoaded = (value: boolean) => {
        this.setState({ isPageRecurringLoaded: value });
      }

      clearFieldValidation = (changedValues: any) => {
        const fieldName = Object.keys(changedValues)[0];
        if (fieldName) {
          this.props.form?.setFields([
            {
              name: fieldName,
              errors: []
            }
          ]);
        }
      };

      




    async callCallbackFunction(diId: number, isFromMaster: boolean = false) {
        let isErrorOccurred = false;

    }


}
