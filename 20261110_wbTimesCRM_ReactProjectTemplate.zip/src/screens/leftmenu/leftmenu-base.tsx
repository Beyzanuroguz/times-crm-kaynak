import React from "react";
import Axios, { AxiosResponse } from "axios";
import { KuikaAppManager } from "../../shared/utilty/kuika-app-manager";
import { ReactSystemFunctions } from "../../shared/utilty/react-system-functions";
import { KNavigator } from "../../shared/hoc/with-history";
import { KContext } from "../../shared/hoc/with-context";
import { useLocation } from "react-router-dom";
import { FormInstance } from "antd/es/form";
import { Guid } from "guid-typescript";
import Swal from "sweetalert2";
import { KMainFunctions } from "../../shared/utilty/main-functions";
import moment from "moment";
import { IValidationData } from "../../models/dto/validation-data";
import { IStripePayment } from "../../models/dto/stripe-payment";
import { IUserInfoDto } from "../../models/dto/user-info.dto";
import { UserService } from "../../services/user-service";
import { kuikaCoreWasmBridgeService } from "../../services/_singletons";
import _ from "lodash";
import mqtt, { MqttClient } from "mqtt";
import { IMqttResult } from "../../models/dto/mqtt.dto";


declare let window: any;

export interface ILeftMenu_ScreenProps {
  navigator: KNavigator;
  form: FormInstance<any>;
  googleLogin: any;
  screenInputs: any;
  context: KContext;
  initialValues: any;
  children: any;
}

export interface ILeftMenu_ScreenState {
    isSpinnerVisible: boolean;
    isPageVisible: boolean;
	isLeftMenuVisible: boolean;
    spinnerCount: number;
    selectedLanguage: string;
    isPageInitLoaded: false;
    isPageRecurringLoaded: false;
	GoBack: any;
	GoBack_dummy: any;
	NAVIGATE: any;
	NAVIGATE_dummy: any;
	Logout: boolean;
	Logout_dummy: boolean;
	goToSignInActivity: any;
	goToSignInActivity_dummy: any;
	isCompleftmenu_822360AuthorizationVisible: 'visible' | 'hidden';
	isCompleftmenu_546861AuthorizationVisible: 'visible' | 'hidden';
	isCompleftmenu_455309AuthorizationVisible: 'visible' | 'hidden';
	isCompleftmenu_126212AuthorizationVisible: 'visible' | 'hidden';
	isCompleftmenu_163561AuthorizationVisible: 'visible' | 'hidden';
	isCompleftmenu_520626AuthorizationVisible: 'visible' | 'hidden';
	isCompleftmenu_162703AuthorizationVisible: 'visible' | 'hidden';
	isCompleftmenu_812368AuthorizationVisible: 'visible' | 'hidden';
	isCompleftmenu_724157AuthorizationVisible: 'visible' | 'hidden';
	isCompleftmenu_167815AuthorizationVisible: 'visible' | 'hidden';

}

export class LeftMenu_ScreenBase extends React.PureComponent<ILeftMenu_ScreenProps, any> {


    ml=[{"Id":"d5a61d2b-bd60-485f-86e2-661e9ed4e486","Name":"en_US","ShortName":"English","IsDefault":true,"LanguagePhrases":[]},{"Id":"9326ea27-c7be-4243-a0ca-36f5c068d8b2","Name":"FixedValues","ShortName":"FixedValues","LanguagePhrases":[{"Id":501123,"PropertyName":"value","Value":"TIMES"},{"Id":950642,"PropertyName":"value","Value":"Talep Listesi"},{"Id":416187,"PropertyName":"value","Value":"Yeni Talep"},{"Id":649128,"PropertyName":"value","Value":"Toplu Talep Onayla"},{"Id":516942,"PropertyName":"value","Value":"Onaylı Sipariş Listesi"},{"Id":981115,"PropertyName":"value","Value":"Müşteriler"},{"Id":675350,"PropertyName":"value","Value":"Ürünler"},{"Id":733506,"PropertyName":"value","Value":"Stok Listesi"},{"Id":895244,"PropertyName":"value","Value":"Portföy Listesi"},{"Id":806004,"PropertyName":"value","Value":"Transfer Yönetimi"},{"Id":38910,"PropertyName":"value","Value":"İthalat Listesi"},{"Id":188381,"PropertyName":"value","Value":"Logout"}]}]
    defaultML = "en_US"
    
    screenHash = ""
    


    constructor(props) {
        super(props);


        this.state = {
            isSpinnerVisible: false,
            isPageVisible: false,
            isLeftMenuVisible: false,
            spinnerCount: 0,
            selectedLanguage: "",
            isPageInitLoaded: false,
            isPageRecurringLoaded: false,
            	        GoBack: "",
	        NAVIGATE: "",
	        Logout: false,
	        goToSignInActivity: "",
	        isCompleftmenu_822360AuthorizationVisible: 'visible',
	        isCompleftmenu_546861AuthorizationVisible: 'visible',
	        isCompleftmenu_455309AuthorizationVisible: 'visible',
	        isCompleftmenu_126212AuthorizationVisible: 'visible',
	        isCompleftmenu_163561AuthorizationVisible: 'visible',
	        isCompleftmenu_520626AuthorizationVisible: 'visible',
	        isCompleftmenu_162703AuthorizationVisible: 'visible',
	        isCompleftmenu_812368AuthorizationVisible: 'visible',
	        isCompleftmenu_724157AuthorizationVisible: 'visible',
	        isCompleftmenu_167815AuthorizationVisible: 'visible',

        }

        this.state.isPageVisible = true;
        
    }

    async componentDidMount() {

        if (KuikaAppManager.isPageInitPrevented()) {
            KuikaAppManager.calculateAndSetBodyHeight("leftmenu", "");
            return;
        }
        
        
        
        this.fillFormInitValues();
        if (true){
            
        }
        ReactSystemFunctions.hideIsNotAuthorized(this, "isCompleftmenu_822360AuthorizationVisible", ["cdb536b0-6297-155f-d446-8453d8a60304","4da1f213-c8e4-0b50-5c84-02fd13f1a622","b4bfd39c-ac02-f442-c899-7a2374a45b47","70de6cfc-6087-6059-59b4-0b5a8527af6b","TimesYonetici","TimesUstYonetici","TimesSatisPersoneli","TimesMagazaMuduru"]);
ReactSystemFunctions.hideIsNotAuthorized(this, "isCompleftmenu_546861AuthorizationVisible", ["cdb536b0-6297-155f-d446-8453d8a60304","4da1f213-c8e4-0b50-5c84-02fd13f1a622","b4bfd39c-ac02-f442-c899-7a2374a45b47","70de6cfc-6087-6059-59b4-0b5a8527af6b","TimesYonetici","TimesUstYonetici","TimesSatisPersoneli","TimesMagazaMuduru"]);
ReactSystemFunctions.hideIsNotAuthorized(this, "isCompleftmenu_455309AuthorizationVisible", ["cdb536b0-6297-155f-d446-8453d8a60304","4da1f213-c8e4-0b50-5c84-02fd13f1a622","TimesYonetici","TimesUstYonetici"]);
ReactSystemFunctions.hideIsNotAuthorized(this, "isCompleftmenu_126212AuthorizationVisible", ["4da1f213-c8e4-0b50-5c84-02fd13f1a622","cdb536b0-6297-155f-d446-8453d8a60304","TimesYonetici","TimesUstYonetici"]);
ReactSystemFunctions.hideIsNotAuthorized(this, "isCompleftmenu_163561AuthorizationVisible", ["4da1f213-c8e4-0b50-5c84-02fd13f1a622","cdb536b0-6297-155f-d446-8453d8a60304","70de6cfc-6087-6059-59b4-0b5a8527af6b","b4bfd39c-ac02-f442-c899-7a2374a45b47","TimesYonetici","TimesUstYonetici","TimesSatisPersoneli","TimesMagazaMuduru"]);
ReactSystemFunctions.hideIsNotAuthorized(this, "isCompleftmenu_520626AuthorizationVisible", ["4da1f213-c8e4-0b50-5c84-02fd13f1a622","cdb536b0-6297-155f-d446-8453d8a60304","70de6cfc-6087-6059-59b4-0b5a8527af6b","b4bfd39c-ac02-f442-c899-7a2374a45b47","TimesYonetici","TimesUstYonetici","TimesSatisPersoneli","TimesMagazaMuduru"]);
ReactSystemFunctions.hideIsNotAuthorized(this, "isCompleftmenu_162703AuthorizationVisible", ["4da1f213-c8e4-0b50-5c84-02fd13f1a622","cdb536b0-6297-155f-d446-8453d8a60304","b4bfd39c-ac02-f442-c899-7a2374a45b47","70de6cfc-6087-6059-59b4-0b5a8527af6b","TimesYonetici","TimesUstYonetici","TimesSatisPersoneli","TimesMagazaMuduru"]);
ReactSystemFunctions.hideIsNotAuthorized(this, "isCompleftmenu_812368AuthorizationVisible", ["4da1f213-c8e4-0b50-5c84-02fd13f1a622","cdb536b0-6297-155f-d446-8453d8a60304","TimesYonetici","TimesUstYonetici"]);
ReactSystemFunctions.hideIsNotAuthorized(this, "isCompleftmenu_724157AuthorizationVisible", ["70de6cfc-6087-6059-59b4-0b5a8527af6b","TimesMagazaMuduru"]);
ReactSystemFunctions.hideIsNotAuthorized(this, "isCompleftmenu_167815AuthorizationVisible", ["cdb536b0-6297-155f-d446-8453d8a60304","4da1f213-c8e4-0b50-5c84-02fd13f1a622","TimesYonetici","TimesUstYonetici"]);

        
        
        KuikaAppManager.calculateAndSetBodyHeight("leftmenu", "");

        if (ReactSystemFunctions.getIsMicroApp() === false) {
           window.parentScreen = this;
        }
    }

    componentWillUnmount() {
        
        
        

        if (ReactSystemFunctions.getIsMicroApp() === false) {
           window.parentScreen = null;
        }
    }

    

        
    componentDidUpdate= async (prevProps, prevState) => {
		KuikaAppManager.calculateAndSetBodyHeight("leftmenu", ""    );
        if (prevProps?.location?.search !== (this.props as any)?.location?.search) {
			
		}

        

        if (ReactSystemFunctions.getIsMicroApp() === false) {
            for (const key in prevState) {
                if (key.startsWith('NavVisible') && prevState[key] === true && this.state[key] === false) {
                    window.parentScreen = this;
                    break;
                }
            }
        }
	}

    fillFormInitValues() {
        this.props.form?.setFieldsValue({
});

    }

      setPageInitLoaded = (value: boolean) => {
        this.setState({ isPageInitLoaded: value });
      }

      setPageRecurringLoaded = (value: boolean) => {
        this.setState({ isPageRecurringLoaded: value });
      }

      clearFieldValidation = (changedValues: any) => {
        const fieldName = Object.keys(changedValues)[0];
        if (fieldName) {
          this.props.form?.setFields([
            {
              name: fieldName,
              errors: []
            }
          ]);
        }
      };

      


		LeftMenuComponent_620279_onClick = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
KuikaAppManager.showSpinner(this);

				stateVars.GoBack = await ReactSystemFunctions.goBack(this, null);

		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

            
            return isErrorOccurred;
        }


		LeftMenuComponent_822360_onClick = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
KuikaAppManager.showSpinner(this);

					KuikaAppManager.prepareForNavigation();

				stateVars.NAVIGATE = await ReactSystemFunctions.navigate(this, undefined, "LeftMenu", "LeadList", "", "currentPage", null, null, null, null, null, null, true, false);

		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

            
            return isErrorOccurred;
        }


		LeftMenuComponent_546861_onClick = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
KuikaAppManager.showSpinner(this);

					KuikaAppManager.prepareForNavigation();
						KuikaAppManager.addToPageInputVariables("LeadAdd", "CustomerId", ReactSystemFunctions.convertToTypeByName("00000000-0000-0000-0000-000000000000", "Guid"));

				stateVars.NAVIGATE = await ReactSystemFunctions.navigate(this, undefined, "LeftMenu", "LeadAdd", "", "currentPage", null, null, null, null, null, null, true, false);

		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

            
            return isErrorOccurred;
        }


		LeftMenuComponent_455309_onClick = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
KuikaAppManager.showSpinner(this);

					KuikaAppManager.prepareForNavigation();

				stateVars.NAVIGATE = await ReactSystemFunctions.navigate(this, undefined, "LeftMenu", "AllLeadPending", "", "currentPage", null, null, null, null, null, null, true, false);

		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

            
            return isErrorOccurred;
        }


		LeftMenuComponent_126212_onClick = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
if ((ReactSystemFunctions.contains(ReactSystemFunctions.getMyRoleNames(), "TimesUstYonetici") || ReactSystemFunctions.contains(ReactSystemFunctions.getMyRoleNames(), "TimesYonetici"))) {
            KuikaAppManager.showSpinner(this);

					KuikaAppManager.prepareForNavigation();

				stateVars.NAVIGATE = await ReactSystemFunctions.navigate(this, undefined, "LeftMenu", "ApprovedLeadList", "", "currentPage", null, null, null, null, null, null, true, false);

		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

        } else {
            KuikaAppManager.hideSpinner(this);
        }

            
            return isErrorOccurred;
        }


		LeftMenuComponent_163561_onClick = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
KuikaAppManager.showSpinner(this);

					KuikaAppManager.prepareForNavigation();

				stateVars.NAVIGATE = await ReactSystemFunctions.navigate(this, undefined, "LeftMenu", "CustomerList", "", "currentPage", null, null, null, null, null, null, true, false);

		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

            
            return isErrorOccurred;
        }


		LeftMenuComponent_520626_onClick = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
KuikaAppManager.showSpinner(this);

					KuikaAppManager.prepareForNavigation();

				stateVars.NAVIGATE = await ReactSystemFunctions.navigate(this, undefined, "LeftMenu", "ProductList", "", "currentPage", null, null, null, null, null, null, true, false);

		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

            
            return isErrorOccurred;
        }


		LeftMenuComponent_162703_onClick = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
KuikaAppManager.showSpinner(this);

					KuikaAppManager.prepareForNavigation();

				stateVars.NAVIGATE = await ReactSystemFunctions.navigate(this, undefined, "LeftMenu", "StockListManager", "", "currentPage", null, null, null, null, null, null, true, false);

		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

            
            return isErrorOccurred;
        }


		LeftMenuComponent_812368_onClick = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
KuikaAppManager.showSpinner(this);

					KuikaAppManager.prepareForNavigation();

				stateVars.NAVIGATE = await ReactSystemFunctions.navigate(this, undefined, "LeftMenu", "AnnualPortfolioList", "", "currentPage", null, null, null, null, null, null, true, false);

		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

            
            return isErrorOccurred;
        }


		LeftMenuComponent_167815_onClick = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
KuikaAppManager.showSpinner(this);

					KuikaAppManager.prepareForNavigation();

				stateVars.NAVIGATE = await ReactSystemFunctions.navigate(this, undefined, "LeftMenu", "ImportList", "", "currentPage", null, null, null, null, null, null, true, false);

		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

            
            return isErrorOccurred;
        }


		LeftMenuComponent_20424_onClick = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
KuikaAppManager.showSpinner(this);
		KuikaAppManager.increaseServerRequestCount();

				stateVars.Logout = await ReactSystemFunctions.logout();
				stateVars.tmpBoolResult = await ReactSystemFunctions.goToSignInActivity(this);

		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

            
            return isErrorOccurred;
        }




    async callCallbackFunction(diId: number, isFromMaster: boolean = false) {
        let isErrorOccurred = false;

    }


}
