import React from "react";
import Axios, { AxiosResponse } from "axios";
import { KuikaAppManager } from "../../shared/utilty/kuika-app-manager";
import { ReactSystemFunctions } from "../../shared/utilty/react-system-functions";
import { KNavigator } from "../../shared/hoc/with-history";
import { KContext } from "../../shared/hoc/with-context";
import { useLocation } from "react-router-dom";
import { FormInstance } from "antd/es/form";
import { Guid } from "guid-typescript";
import Swal from "sweetalert2";
import { KMainFunctions } from "../../shared/utilty/main-functions";
import moment from "moment";
import { IValidationData } from "../../models/dto/validation-data";
import { IStripePayment } from "../../models/dto/stripe-payment";
import { IUserInfoDto } from "../../models/dto/user-info.dto";
import { UserService } from "../../services/user-service";
import { kuikaCoreWasmBridgeService } from "../../services/_singletons";
import _ from "lodash";
import mqtt, { MqttClient } from "mqtt";
import { IMqttResult } from "../../models/dto/mqtt.dto";


declare let window: any;

export interface IBosekranYusuf_ScreenProps {
  navigator: KNavigator;
  form: FormInstance<any>;
  googleLogin: any;
  screenInputs: any;
  context: KContext;
  initialValues: any;
  children: any;
}

export interface IBosekranYusuf_ScreenState {
    isSpinnerVisible: boolean;
    isPageVisible: boolean;
	isLeftMenuVisible: boolean;
    spinnerCount: number;
    selectedLanguage: string;
    isPageInitLoaded: false;
    isPageRecurringLoaded: false;
	Connect: any;
	Connect_dummy: any;
	SyncProductExcel: string;
	SyncProductExcel_dummy: string;
	KuikaY_MontBlancAylikSatisKarsilastirma: any[];
	KuikaY_MontBlancAylikSatisKarsilastirma_dummy: any[];
	KuikaY_MonthlyStoreSalesReport: any[];
	KuikaY_MonthlyStoreSalesReport_dummy: any[];
	KuikaY_RolexGrupAylikSatisKarsilastirma: any[];
	KuikaY_RolexGrupAylikSatisKarsilastirma_dummy: any[];
	KuikaY_RolexMaterialSalesReport: any[];
	KuikaY_RolexMaterialSalesReport_dummy: any[];
	KuikaY_RolexTudorFamilySalesReport: any[];
	KuikaY_RolexTudorFamilySalesReport_dummy: any[];
	KuikaY_RolexTudorStoreSalesReport: any[];
	KuikaY_RolexTudorStoreSalesReport_dummy: any[];
	Kuika_ExchangeRates: any[];
	Kuika_ExchangeRates_dummy: any[];

}

export class BosekranYusuf_ScreenBase extends React.PureComponent<IBosekranYusuf_ScreenProps, any> {

	bosekranyusuf_811399_value_kuikaTableRef: React.RefObject<any>;
	bosekranyusuf_569780_value_kuikaTableRef: React.RefObject<any>;
	bosekranyusuf_694943_value_kuikaTableRef: React.RefObject<any>;
	bosekranyusuf_218606_value_kuikaTableRef: React.RefObject<any>;
	bosekranyusuf_474492_value_kuikaTableRef: React.RefObject<any>;
	bosekranyusuf_459168_value_kuikaTableRef: React.RefObject<any>;
	bosekranyusuf_126997_value_kuikaTableRef: React.RefObject<any>;
	bosekranyusuf_878076_value_kuikaTableRef: React.RefObject<any>;
    ml=[{"Id":"d5a61d2b-bd60-485f-86e2-661e9ed4e486","Name":"en_US","ShortName":"English","IsDefault":true,"LanguagePhrases":[]},{"Id":"5c9750a3-f9f8-455c-8f01-1e87d929133b","Name":"FixedValues","ShortName":"FixedValues","LanguagePhrases":[{"Id":179445,"PropertyName":"label","Value":"Button text"},{"Id":20686,"PropertyName":"title","Value":"Title"},{"Id":857522,"PropertyName":"value","Value":"[datafield:salespersoncode]"},{"Id":455097,"PropertyName":"label","Value":"MontBlancAylıkKars"},{"Id":276496,"PropertyName":"title","Value":"Title"},{"Id":215146,"PropertyName":"value","Value":"[datafield:magaza]"},{"Id":845754,"PropertyName":"title","Value":"Title"},{"Id":775140,"PropertyName":"value","Value":"[datafield:ocakadet2025]"},{"Id":568319,"PropertyName":"title","Value":"Title"},{"Id":371888,"PropertyName":"value","Value":"[datafield:ocakadet2026]"},{"Id":397881,"PropertyName":"title","Value":"Title"},{"Id":926740,"PropertyName":"value","Value":"[datafield:ocakadetdegisim]"},{"Id":986953,"PropertyName":"label","Value":"MonthlyStoreSalesRep"},{"Id":990701,"PropertyName":"title","Value":"Title"},{"Id":637065,"PropertyName":"value","Value":"[datafield:magaza]"},{"Id":881102,"PropertyName":"title","Value":"Title"},{"Id":347100,"PropertyName":"value","Value":"[datafield:ocak]"},{"Id":287745,"PropertyName":"title","Value":"Title"},{"Id":855123,"PropertyName":"value","Value":"[datafield:ocak]"},{"Id":94362,"PropertyName":"title","Value":"Title"},{"Id":454987,"PropertyName":"value","Value":"[datafield:ocak]"},{"Id":891852,"PropertyName":"label","Value":"RolexGrupaylik"},{"Id":229248,"PropertyName":"title","Value":"Title"},{"Id":523662,"PropertyName":"value","Value":"[datafield:magaza]"},{"Id":818894,"PropertyName":"title","Value":"Title"},{"Id":192762,"PropertyName":"value","Value":"[datafield:ocak2025]"},{"Id":575567,"PropertyName":"title","Value":"Title"},{"Id":451762,"PropertyName":"value","Value":"[datafield:ocak2026]"},{"Id":527447,"PropertyName":"title","Value":"Title"},{"Id":348426,"PropertyName":"value","Value":"[datafield:ocakdegisim]"},{"Id":397008,"PropertyName":"label","Value":"Rolex material"},{"Id":998093,"PropertyName":"title","Value":"Title"},{"Id":514617,"PropertyName":"value","Value":"[datafield:magaza]"},{"Id":11522,"PropertyName":"title","Value":"Title"},{"Id":651680,"PropertyName":"value","Value":"[datafield:steel]"},{"Id":860106,"PropertyName":"title","Value":"Title"},{"Id":898648,"PropertyName":"value","Value":"[datafield:everoserolesor]"},{"Id":675859,"PropertyName":"title","Value":"Title"},{"Id":105473,"PropertyName":"value","Value":"[datafield:rolesium]"},{"Id":785925,"PropertyName":"label","Value":"Familysalesreports"},{"Id":397435,"PropertyName":"title","Value":"Title"},{"Id":408675,"PropertyName":"value","Value":"[datafield:magaza]"},{"Id":212406,"PropertyName":"title","Value":"Title"},{"Id":963321,"PropertyName":"value","Value":"[datafield:family]"},{"Id":442107,"PropertyName":"title","Value":"Title"},{"Id":392521,"PropertyName":"value","Value":"[datafield:satisadedi]"},{"Id":667325,"PropertyName":"title","Value":"Title"},{"Id":707018,"PropertyName":"value","Value":"[datafield:cirotl]"},{"Id":751277,"PropertyName":"label","Value":"RolexTtudorstoresales"},{"Id":366193,"PropertyName":"title","Value":"Title"},{"Id":594086,"PropertyName":"value","Value":"[datafield:magaza]"},{"Id":134024,"PropertyName":"title","Value":"Title"},{"Id":214618,"PropertyName":"value","Value":"[datafield:satisadedi]"},{"Id":571878,"PropertyName":"title","Value":"Title"},{"Id":150917,"PropertyName":"value","Value":"[datafield:cirotl]"},{"Id":479437,"PropertyName":"title","Value":"Title"},{"Id":990475,"PropertyName":"value","Value":"[datafield:cirodoviz]"},{"Id":334240,"PropertyName":"label","Value":"Kur api get"},{"Id":100480,"PropertyName":"title","Value":"Title"},{"Id":976434,"PropertyName":"value","Value":"[datafield:currencycode]"},{"Id":514645,"PropertyName":"title","Value":"Title"},{"Id":985872,"PropertyName":"value","Value":"[datafield:rate]"},{"Id":402471,"PropertyName":"title","Value":"Title"},{"Id":819271,"PropertyName":"value","Value":"[datafield:date]"}]}]
    defaultML = "en_US"
    
    screenHash = ""
    


    constructor(props) {
        super(props);
		this.bosekranyusuf_811399_value_kuikaTableRef = React.createRef();
		this.bosekranyusuf_569780_value_kuikaTableRef = React.createRef();
		this.bosekranyusuf_694943_value_kuikaTableRef = React.createRef();
		this.bosekranyusuf_218606_value_kuikaTableRef = React.createRef();
		this.bosekranyusuf_474492_value_kuikaTableRef = React.createRef();
		this.bosekranyusuf_459168_value_kuikaTableRef = React.createRef();
		this.bosekranyusuf_126997_value_kuikaTableRef = React.createRef();
		this.bosekranyusuf_878076_value_kuikaTableRef = React.createRef();

        this.state = {
            isSpinnerVisible: false,
            isPageVisible: false,
            isLeftMenuVisible: false,
            spinnerCount: 0,
            selectedLanguage: "",
            isPageInitLoaded: false,
            isPageRecurringLoaded: false,
            	        Connect: "",
	        SyncProductExcel: "",
	        KuikaY_MontBlancAylikSatisKarsilastirma: [],
	        KuikaY_MonthlyStoreSalesReport: [],
	        KuikaY_RolexGrupAylikSatisKarsilastirma: [],
	        KuikaY_RolexMaterialSalesReport: [],
	        KuikaY_RolexTudorFamilySalesReport: [],
	        KuikaY_RolexTudorStoreSalesReport: [],
	        Kuika_ExchangeRates: [],

        }

        this.CheckPageAuthorization(this.state);

        
    }

    async componentDidMount() {

        if (KuikaAppManager.isPageInitPrevented()) {
            KuikaAppManager.calculateAndSetBodyHeight("bosekranyusuf", "");
            return;
        }
        
        
        ReactSystemFunctions.validateToken()
        this.fillFormInitValues();
        if (true){
            
        }
        
        
        
        KuikaAppManager.calculateAndSetBodyHeight("bosekranyusuf", "");

        if (ReactSystemFunctions.getIsMicroApp() === false) {
           window.parentScreen = this;
        }
    }

    componentWillUnmount() {
        
        
        

        if (ReactSystemFunctions.getIsMicroApp() === false) {
           window.parentScreen = null;
        }
    }

    
              CheckPageAuthorization = async (state) => {
                KuikaAppManager.showSpinner(this);
                if (_.isEmpty(window.userInfo)) {
                  await UserService.GetUserInfoForce();
                }
                const permittedRoleNames: string[] = ["_SystemAdmin",];
                const userInfo = window.userInfo as IUserInfoDto;
                const userRoleNames = userInfo.roles.map((role) => role.name);
                if (!ReactSystemFunctions.hasAnyRoleName(permittedRoleNames, userRoleNames)) {
                  await ReactSystemFunctions.goBack(this);

                  const language = localStorage.getItem("ml");
                  let permissonErrorMessageText = "You do not have permission to access this page.";
                  if (language === "tr_TR") {
                    permissonErrorMessageText = "Bu sayfaya erişim yetkiniz yok.";
                  } else if (language === "fr_FR") {
                    permissonErrorMessageText = "Vous n'avez pas la permission d'accéder à cette page.";
                  } else if (language === "de_DE") {
                    permissonErrorMessageText = "Sie haben keine Berechtigung, auf diese Seite zuzugreifen.";
                  } else if (language === "es_ES") {
                    permissonErrorMessageText = "No tienes permiso para acceder a esta página.";
                  }

                  KMainFunctions.displayErrorNotification(permissonErrorMessageText);
                  state.isPageVisible = false;
                  KuikaAppManager.hideSpinner(this);
                  return;
                }
                state.isPageVisible = true;
                KuikaAppManager.hideSpinner(this);
              };
        

        
    componentDidUpdate= async (prevProps, prevState) => {
		KuikaAppManager.calculateAndSetBodyHeight("bosekranyusuf", ""    );
        if (prevProps?.location?.search !== (this.props as any)?.location?.search) {
			
		}

        

        if (ReactSystemFunctions.getIsMicroApp() === false) {
            for (const key in prevState) {
                if (key.startsWith('NavVisible') && prevState[key] === true && this.state[key] === false) {
                    window.parentScreen = this;
                    break;
                }
            }
        }
	}

    fillFormInitValues() {
        this.props.form?.setFieldsValue({
});

    }

      setPageInitLoaded = (value: boolean) => {
        this.setState({ isPageInitLoaded: value });
      }

      setPageRecurringLoaded = (value: boolean) => {
        this.setState({ isPageRecurringLoaded: value });
      }

      clearFieldValidation = (changedValues: any) => {
        const fieldName = Object.keys(changedValues)[0];
        if (fieldName) {
          this.props.form?.setFields([
            {
              name: fieldName,
              errors: []
            }
          ]);
        }
      };

      


    bosekranYusufComponent_179445_onClick = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
		KuikaAppManager.increaseServerRequestCount();

        let localVar = {
        }

		KuikaAppManager.showSpinner(this);
		
        if (true) {
        KuikaAppManager.showSpinner(this);
        }
        let result = await KuikaAppManager.ApiRequest(this, "bosekranYusuf/bosekranYusufComponent_179445_onClick", localVar)
        if (!KMainFunctions.IsResStatus2XX(result)) return true;

			stateVars.SyncProductExcel = result?.data.syncProductExcel;
			this.props.form?.setFieldsValue(formVars);
			this.setState(stateVars);
			KuikaAppManager.hideSpinner(this);



        this.setPageInitLoaded(true);
        KuikaAppManager.hideSpinner(this);
        return isErrorOccurred;
    }



    bosekranYusufComponent_455097_onClick = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
		KuikaAppManager.increaseServerRequestCount();

        let localVar = {
				Year1_1: ReactSystemFunctions.convertToTypeByName(2025, "number"),
				Year2_1: ReactSystemFunctions.convertToTypeByName(2026, "number")
        }

		KuikaAppManager.showSpinner(this);
		
        if (true) {
        KuikaAppManager.showSpinner(this);
        }
        let result = await KuikaAppManager.ApiRequest(this, "bosekranYusuf/bosekranYusufComponent_455097_onClick", localVar)
        if (!KMainFunctions.IsResStatus2XX(result)) return true;

			stateVars.KuikaY_MontBlancAylikSatisKarsilastirma = result?.data.kuikaY_MontBlancAylikSatisKarsilastirma;
			
			this.props.form?.setFieldsValue(formVars);
			
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.bosekranYusufComponent_455097_onClick1_();
                  resolve();
                });
          })



        
        KuikaAppManager.hideSpinner(this);
        return isErrorOccurred;
    }
		bosekranYusufComponent_455097_onClick1_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }

				
				stateVars.dataSource_569780 = stateVars.KuikaY_MontBlancAylikSatisKarsilastirma ?? this.state.KuikaY_MontBlancAylikSatisKarsilastirma;

		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

            
            return isErrorOccurred;
        }




    bosekranYusufComponent_986953_onClick = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
		KuikaAppManager.increaseServerRequestCount();

        let localVar = {
				Brand_1: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.convertToTypeByName("Rolex", "string"), "string"),
				ProductGroup_1: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.convertToTypeByName("Kol Saati", "string"), "string"),
				Year_1: ReactSystemFunctions.convertToTypeByName(2025, "number")
        }

		KuikaAppManager.showSpinner(this);
		
        if (true) {
        KuikaAppManager.showSpinner(this);
        }
        let result = await KuikaAppManager.ApiRequest(this, "bosekranYusuf/bosekranYusufComponent_986953_onClick", localVar)
        if (!KMainFunctions.IsResStatus2XX(result)) return true;

			stateVars.KuikaY_MonthlyStoreSalesReport = result?.data.kuikaY_MonthlyStoreSalesReport;
			
			this.props.form?.setFieldsValue(formVars);
			
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.bosekranYusufComponent_986953_onClick1_();
                  resolve();
                });
          })



        
        KuikaAppManager.hideSpinner(this);
        return isErrorOccurred;
    }
		bosekranYusufComponent_986953_onClick1_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }

				
				stateVars.dataSource_694943 = stateVars.KuikaY_MonthlyStoreSalesReport ?? this.state.KuikaY_MonthlyStoreSalesReport;

		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

            
            return isErrorOccurred;
        }




    bosekranYusufComponent_891852_onClick = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
		KuikaAppManager.increaseServerRequestCount();

        let localVar = {
				Brand_1: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.convertToTypeByName("Rolex", "string"), "string"),
				ProductGroup_1: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.convertToTypeByName("Kol Saati", "string"), "string"),
				Year1_1: ReactSystemFunctions.convertToTypeByName(2025, "number"),
				Year2_1: ReactSystemFunctions.convertToTypeByName(2026, "number")
        }

		KuikaAppManager.showSpinner(this);
		
        if (true) {
        KuikaAppManager.showSpinner(this);
        }
        let result = await KuikaAppManager.ApiRequest(this, "bosekranYusuf/bosekranYusufComponent_891852_onClick", localVar)
        if (!KMainFunctions.IsResStatus2XX(result)) return true;

			stateVars.KuikaY_RolexGrupAylikSatisKarsilastirma = result?.data.kuikaY_RolexGrupAylikSatisKarsilastirma;
			
			this.props.form?.setFieldsValue(formVars);
			
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.bosekranYusufComponent_891852_onClick1_();
                  resolve();
                });
          })



        
        KuikaAppManager.hideSpinner(this);
        return isErrorOccurred;
    }
		bosekranYusufComponent_891852_onClick1_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }

				
				stateVars.dataSource_218606 = stateVars.KuikaY_RolexGrupAylikSatisKarsilastirma ?? this.state.KuikaY_RolexGrupAylikSatisKarsilastirma;

		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

            
            return isErrorOccurred;
        }




    bosekranYusufComponent_397008_onClick = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
		KuikaAppManager.increaseServerRequestCount();

        let localVar = {
				StartDate_1: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.convertToTypeByName("20250101", "string"), "string"),
				EndDate_1: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.convertToTypeByName("20260101", "string"), "string")
        }

		KuikaAppManager.showSpinner(this);
		
        if (true) {
        KuikaAppManager.showSpinner(this);
        }
        let result = await KuikaAppManager.ApiRequest(this, "bosekranYusuf/bosekranYusufComponent_397008_onClick", localVar)
        if (!KMainFunctions.IsResStatus2XX(result)) return true;

			stateVars.KuikaY_RolexMaterialSalesReport = result?.data.kuikaY_RolexMaterialSalesReport;
			
			this.props.form?.setFieldsValue(formVars);
			
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.bosekranYusufComponent_397008_onClick1_();
                  resolve();
                });
          })



        
        KuikaAppManager.hideSpinner(this);
        return isErrorOccurred;
    }
		bosekranYusufComponent_397008_onClick1_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }

				
				stateVars.dataSource_474492 = stateVars.KuikaY_RolexMaterialSalesReport ?? this.state.KuikaY_RolexMaterialSalesReport;

		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

            
            return isErrorOccurred;
        }




    bosekranYusufComponent_785925_onClick = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
		KuikaAppManager.increaseServerRequestCount();

        let localVar = {
				Brand_1: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.convertToTypeByName("Tudor", "string"), "string"),
				ProductGroup_1: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.convertToTypeByName("kol saati", "string"), "string"),
				Family_1: ReactSystemFunctions.convertToTypeByName("", "string"),
				StoreCode_1: ReactSystemFunctions.convertToTypeByName("", "string"),
				StartDate_1: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.convertToTypeByName("20250101", "string"), "string"),
				EndDate_1: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.convertToTypeByName("20260101", "string"), "string")
        }

		KuikaAppManager.showSpinner(this);
		
        if (true) {
        KuikaAppManager.showSpinner(this);
        }
        let result = await KuikaAppManager.ApiRequest(this, "bosekranYusuf/bosekranYusufComponent_785925_onClick", localVar)
        if (!KMainFunctions.IsResStatus2XX(result)) return true;

			stateVars.KuikaY_RolexTudorFamilySalesReport = result?.data.kuikaY_RolexTudorFamilySalesReport;
			
			this.props.form?.setFieldsValue(formVars);
			
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.bosekranYusufComponent_785925_onClick1_();
                  resolve();
                });
          })



        
        KuikaAppManager.hideSpinner(this);
        return isErrorOccurred;
    }
		bosekranYusufComponent_785925_onClick1_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }

				
				stateVars.dataSource_459168 = stateVars.KuikaY_RolexTudorFamilySalesReport ?? this.state.KuikaY_RolexTudorFamilySalesReport;

		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

            
            return isErrorOccurred;
        }




    bosekranYusufComponent_751277_onClick = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
		KuikaAppManager.increaseServerRequestCount();

        let localVar = {
				Brand_1: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.convertToTypeByName("Rolex", "string"), "string"),
				ProductGroup_1: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.convertToTypeByName("kol saati", "string"), "string"),
				StartDate_1: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.convertToTypeByName("20250101", "string"), "string"),
				EndDate_1: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.convertToTypeByName("20260101", "string"), "string")
        }

		KuikaAppManager.showSpinner(this);
		
        if (true) {
        KuikaAppManager.showSpinner(this);
        }
        let result = await KuikaAppManager.ApiRequest(this, "bosekranYusuf/bosekranYusufComponent_751277_onClick", localVar)
        if (!KMainFunctions.IsResStatus2XX(result)) return true;

			stateVars.KuikaY_RolexTudorStoreSalesReport = result?.data.kuikaY_RolexTudorStoreSalesReport;
			
			this.props.form?.setFieldsValue(formVars);
			
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.bosekranYusufComponent_751277_onClick1_();
                  resolve();
                });
          })



        
        KuikaAppManager.hideSpinner(this);
        return isErrorOccurred;
    }
		bosekranYusufComponent_751277_onClick1_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }

				
				stateVars.dataSource_126997 = stateVars.KuikaY_RolexTudorStoreSalesReport ?? this.state.KuikaY_RolexTudorStoreSalesReport;

		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

            
            return isErrorOccurred;
        }




    bosekranYusufComponent_334240_onClick = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
		KuikaAppManager.increaseServerRequestCount();

        let localVar = {
				date_1: ReactSystemFunctions.convertToTypeByName(moment().format("YYYY-MM-DDTHH:mm:ss"), "Date")
        }

		KuikaAppManager.showSpinner(this);
		
        if (true) {
        KuikaAppManager.showSpinner(this);
        }
        let result = await KuikaAppManager.ApiRequest(this, "bosekranYusuf/bosekranYusufComponent_334240_onClick", localVar)
        if (!KMainFunctions.IsResStatus2XX(result)) return true;

			stateVars.Kuika_ExchangeRates = result?.data.kuika_ExchangeRates;
			
			this.props.form?.setFieldsValue(formVars);
			
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.bosekranYusufComponent_334240_onClick1_();
                  resolve();
                });
          })



        
        KuikaAppManager.hideSpinner(this);
        return isErrorOccurred;
    }
		bosekranYusufComponent_334240_onClick1_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }

				
				stateVars.dataSource_878076 = stateVars.Kuika_ExchangeRates ?? this.state.Kuika_ExchangeRates;

		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

            
            return isErrorOccurred;
        }






    async callCallbackFunction(diId: number, isFromMaster: boolean = false) {
        let isErrorOccurred = false;

    }


}
