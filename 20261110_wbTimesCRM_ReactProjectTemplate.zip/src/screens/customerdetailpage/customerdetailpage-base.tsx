import React from "react";
import Axios, { AxiosResponse } from "axios";
import { KuikaAppManager } from "../../shared/utilty/kuika-app-manager";
import { ReactSystemFunctions } from "../../shared/utilty/react-system-functions";
import { KNavigator } from "../../shared/hoc/with-history";
import { KContext } from "../../shared/hoc/with-context";
import { useLocation } from "react-router-dom";
import { FormInstance } from "antd/es/form";
import { Guid } from "guid-typescript";
import Swal from "sweetalert2";
import { KMainFunctions } from "../../shared/utilty/main-functions";
import moment from "moment";
import { IValidationData } from "../../models/dto/validation-data";
import { IStripePayment } from "../../models/dto/stripe-payment";
import { IUserInfoDto } from "../../models/dto/user-info.dto";
import { UserService } from "../../services/user-service";
import { kuikaCoreWasmBridgeService } from "../../services/_singletons";
import _ from "lodash";
import mqtt, { MqttClient } from "mqtt";
import { IMqttResult } from "../../models/dto/mqtt.dto";


declare let window: any;

export interface ICustomerDetailPage_ScreenProps {
  navigator: KNavigator;
  form: FormInstance<any>;
  googleLogin: any;
  screenInputs: any;
  context: KContext;
  initialValues: any;
  children: any;
}

export interface ICustomerDetailPage_ScreenState {
    isSpinnerVisible: boolean;
    isPageVisible: boolean;
	isLeftMenuVisible: boolean;
    spinnerCount: number;
    selectedLanguage: string;
    isPageInitLoaded: false;
    isPageRecurringLoaded: false;
	TM_GetCustomerById: any[];
	TM_GetCustomerById_dummy: any[];
	TM_GetAllCustomerLead: any[];
	TM_GetAllCustomerLead_dummy: any[];
	GetUsdEurForexSelling: any;
	GetUsdEurForexSelling_dummy: any;
	GetCustomerDetail: any[];
	GetCustomerDetail_dummy: any[];
	GoBack: any;
	GoBack_dummy: any;
	NAVIGATE: any;
	NAVIGATE_dummy: any;
	isComp954207Visible: 'visible' | 'hidden';
	isComp242314Visible: 'visible' | 'hidden';
	isComp500246Visible: 'visible' | 'hidden';
	isComp974000Visible: 'visible' | 'hidden';
	isComp325634Visible: 'visible' | 'hidden';
	isComp163122Visible: 'visible' | 'hidden';
	isComp118495Visible: 'visible' | 'hidden';
	isComp954547Visible: 'visible' | 'hidden';
	isComp152106Visible: 'visible' | 'hidden';
	isComp409278Visible: 'visible' | 'hidden';
	isComp647616Visible: 'visible' | 'hidden';
	isComp881654Visible: 'visible' | 'hidden';
	isComp950909Visible: 'visible' | 'hidden';
	isComp930321Visible: 'visible' | 'hidden';

}

export class CustomerDetailPage_ScreenBase extends React.PureComponent<ICustomerDetailPage_ScreenProps, any> {

	customerdetailpage_974000_value_kuikaTableRef: React.RefObject<any>;
	customerdetailpage_647616_value_kuikaTableRef: React.RefObject<any>;
    ml=[{"Id":"d5a61d2b-bd60-485f-86e2-661e9ed4e486","Name":"en_US","ShortName":"English","IsDefault":true,"LanguagePhrases":[]},{"Id":"af4e0cb2-f70d-41e9-95b8-7ebf9e487935","Name":"FixedValues","ShortName":"FixedValues","LanguagePhrases":[{"Id":554792,"PropertyName":"value","Value":"Tc Kimlik No"},{"Id":855208,"PropertyName":"value","Value":"Email"},{"Id":930363,"PropertyName":"value","Value":"Vergi No"},{"Id":330173,"PropertyName":"value","Value":"Pasaport No"},{"Id":577918,"PropertyName":"value","Value":"Veriliş Tarihi(Pasaport)"},{"Id":537883,"PropertyName":"value","Value":"Pasaport Ülkesi"},{"Id":813162,"PropertyName":"value","Value":"Ülke"},{"Id":622294,"PropertyName":"value","Value":"Şehir"},{"Id":437301,"PropertyName":"value","Value":"İlçe"},{"Id":754214,"PropertyName":"value","Value":"Info"},{"Id":169657,"PropertyName":"value","Value":"Doğum Günü"},{"Id":24581,"PropertyName":"value","Value":"Alışveriş Var Mı ?"},{"Id":954207,"PropertyName":"value","Value":"Evet"},{"Id":242314,"PropertyName":"value","Value":"Hayır"},{"Id":693346,"PropertyName":"value","Value":"Müşteri Tipi"},{"Id":661202,"PropertyName":"value","Value":"Adres"},{"Id":594332,"PropertyName":"value","Value":"Talep Bilgileri"},{"Id":777774,"PropertyName":"value","Value":"Bu müşteriye ait mevcut talep bulunamadı."},{"Id":974000,"PropertyName":"nodatafoundmessage","Value":"Bu Müşterinin Talep Bilgisi Yoktur"},{"Id":885396,"PropertyName":"title","Value":"Title"},{"Id":739943,"PropertyName":"value","Value":"[datafield:processname]"},{"Id":325634,"PropertyName":"value","Value":"-"},{"Id":163122,"PropertyName":"value","Value":"Termin Tarihi:"},{"Id":118495,"PropertyName":"value","Value":"[datafield:estimateddate]"},{"Id":350946,"PropertyName":"value","Value":"[datafield:leadcode]"},{"Id":362281,"PropertyName":"value","Value":"[datafield:productdisplay]"},{"Id":575630,"PropertyName":"value","Value":"[datafield:leaddurumu]"},{"Id":456223,"PropertyName":"value","Value":"[datafield:createdat]"},{"Id":437402,"PropertyName":"value","Value":"Ekstre Bilgileri"},{"Id":496328,"PropertyName":"value","Value":"Bu müşteriye ait mevcut ekstre bulunamadı."},{"Id":87559,"PropertyName":"value","Value":"Toplam Tutar"},{"Id":647616,"PropertyName":"nodatafoundmessage","Value":"Bu Müşterinin Ekstre Bilgisi Yoktur"},{"Id":621438,"PropertyName":"title","Value":"Title"},{"Id":367919,"PropertyName":"value","Value":"[datafield:itemdescription]"},{"Id":542428,"PropertyName":"value","Value":"[datafield:doc_netamount]"},{"Id":711992,"PropertyName":"value","Value":"[datafield:doc_netamount]"},{"Id":451843,"PropertyName":"value","Value":"[datafield:doc_netamount]"},{"Id":572302,"PropertyName":"value","Value":"[datafield:documentdate]"}]}]
    defaultML = "en_US"
    
    screenHash = ""
    


    constructor(props) {
        super(props);
		this.customerdetailpage_974000_value_kuikaTableRef = React.createRef();
		this.customerdetailpage_647616_value_kuikaTableRef = React.createRef();

        this.state = {
            isSpinnerVisible: false,
            isPageVisible: false,
            isLeftMenuVisible: false,
            spinnerCount: 0,
            selectedLanguage: "",
            isPageInitLoaded: false,
            isPageRecurringLoaded: false,
            	        TM_GetCustomerById: [],
	        TM_GetAllCustomerLead: [],
	        GetUsdEurForexSelling: "",
	        GetCustomerDetail: [],
	        GoBack: "",
	        NAVIGATE: "",
	        isComp954207Visible: 'hidden',
	        isComp242314Visible: 'hidden',
	        isComp500246Visible: 'hidden',
	        isComp974000Visible: 'hidden',
	        isComp325634Visible: 'hidden',
	        isComp163122Visible: 'hidden',
	        isComp118495Visible: 'hidden',
	        isComp954547Visible: 'hidden',
	        isComp152106Visible: 'hidden',
	        isComp409278Visible: 'hidden',
	        isComp647616Visible: 'hidden',
	        isComp881654Visible: 'hidden',
	        isComp950909Visible: 'hidden',
	        isComp930321Visible: 'hidden',

        }

        this.CheckPageAuthorization(this.state);

        
    }

    async componentDidMount() {

        if (KuikaAppManager.isPageInitPrevented()) {
            KuikaAppManager.calculateAndSetBodyHeight("customerdetailpage", "");
            return;
        }
        
        
        ReactSystemFunctions.validateToken()
        this.fillFormInitValues();
        if (true){
            await this.CustomerDetailPagePageInit();
        }
        
        
        
        KuikaAppManager.calculateAndSetBodyHeight("customerdetailpage", "");

        if (ReactSystemFunctions.getIsMicroApp() === false) {
           window.parentScreen = this;
        }
    }

    componentWillUnmount() {
        
        
        

        if (ReactSystemFunctions.getIsMicroApp() === false) {
           window.parentScreen = null;
        }
    }

    
              CheckPageAuthorization = async (state) => {
                KuikaAppManager.showSpinner(this);
                if (_.isEmpty(window.userInfo)) {
                  await UserService.GetUserInfoForce();
                }
                const permittedRoleNames: string[] = ["TimesYonetici","TimesUstYonetici","TimesSatisPersoneli","TimesMagazaMuduru",];
                const userInfo = window.userInfo as IUserInfoDto;
                const userRoleNames = userInfo.roles.map((role) => role.name);
                if (!ReactSystemFunctions.hasAnyRoleName(permittedRoleNames, userRoleNames)) {
                  await ReactSystemFunctions.goBack(this);

                  const language = localStorage.getItem("ml");
                  let permissonErrorMessageText = "You do not have permission to access this page.";
                  if (language === "tr_TR") {
                    permissonErrorMessageText = "Bu sayfaya erişim yetkiniz yok.";
                  } else if (language === "fr_FR") {
                    permissonErrorMessageText = "Vous n'avez pas la permission d'accéder à cette page.";
                  } else if (language === "de_DE") {
                    permissonErrorMessageText = "Sie haben keine Berechtigung, auf diese Seite zuzugreifen.";
                  } else if (language === "es_ES") {
                    permissonErrorMessageText = "No tienes permiso para acceder a esta página.";
                  }

                  KMainFunctions.displayErrorNotification(permissonErrorMessageText);
                  state.isPageVisible = false;
                  KuikaAppManager.hideSpinner(this);
                  return;
                }
                state.isPageVisible = true;
                KuikaAppManager.hideSpinner(this);
              };
        

        
    componentDidUpdate= async (prevProps, prevState) => {
		KuikaAppManager.calculateAndSetBodyHeight("customerdetailpage", ""    );
        if (prevProps?.location?.search !== (this.props as any)?.location?.search) {
			await this.CustomerDetailPagePageInit();
		}

        

        if (ReactSystemFunctions.getIsMicroApp() === false) {
            for (const key in prevState) {
                if (key.startsWith('NavVisible') && prevState[key] === true && this.state[key] === false) {
                    window.parentScreen = this;
                    break;
                }
            }
        }
	}

    fillFormInitValues() {
        this.props.form?.setFieldsValue({
});

    }

      setPageInitLoaded = (value: boolean) => {
        this.setState({ isPageInitLoaded: value });
      }

      setPageRecurringLoaded = (value: boolean) => {
        this.setState({ isPageRecurringLoaded: value });
      }

      clearFieldValidation = (changedValues: any) => {
        const fieldName = Object.keys(changedValues)[0];
        if (fieldName) {
          this.props.form?.setFields([
            {
              name: fieldName,
              errors: []
            }
          ]);
        }
      };

      

    CustomerDetailPagePageInit = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


	if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }

        let localVar = {
			CustomerId_0: ReactSystemFunctions.convertToTypeByName(this.props.screenInputs.CustomerId ?? this.props.screenInputs.customerid, "Guid"),
			CustomerId_1: ReactSystemFunctions.convertToTypeByName(this.props.screenInputs.CustomerId ?? this.props.screenInputs.customerid, "Guid"),
			customerCode_3: ReactSystemFunctions.convertToTypeByName(this.props.screenInputs.customerCode ?? this.props.screenInputs.customercode, "string"),
			usdRate_3: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, stateVars.GetUsdEurForexSelling?.usdForexSelling), "number"),
			eurRate_3: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, stateVars.GetUsdEurForexSelling?.eurForexSelling), "number")
        }

	KuikaAppManager.showSpinner(this);
	
        if (true) {
        KuikaAppManager.showSpinner(this);
        }
        let result = await KuikaAppManager.ApiRequest(this, "CustomerDetailPage/CustomerDetailPagePageInit", localVar)
        if (!KMainFunctions.IsResStatus2XX(result)) return true;

		stateVars.TM_GetCustomerById = result?.data.tM_GetCustomerById;
		formVars.customerdetailpage_217677_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetCustomerById !== undefined ? (stateVars.TM_GetCustomerById?.length > 0 ? stateVars.TM_GetCustomerById[0].adSoyad : null) : (this.state.TM_GetCustomerById?.length > 0 ? this.state.TM_GetCustomerById[0].adSoyad : null)));
		formVars.customerdetailpage_803344_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetCustomerById !== undefined ? (stateVars.TM_GetCustomerById?.length > 0 ? stateVars.TM_GetCustomerById[0].telefonNo : null) : (this.state.TM_GetCustomerById?.length > 0 ? this.state.TM_GetCustomerById[0].telefonNo : null)));
		formVars.customerdetailpage_922974_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetCustomerById !== undefined ? (stateVars.TM_GetCustomerById?.length > 0 ? stateVars.TM_GetCustomerById[0].tcKimlikNo : null) : (this.state.TM_GetCustomerById?.length > 0 ? this.state.TM_GetCustomerById[0].tcKimlikNo : null)));
		formVars.customerdetailpage_59481_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetCustomerById !== undefined ? (stateVars.TM_GetCustomerById?.length > 0 ? stateVars.TM_GetCustomerById[0].email : null) : (this.state.TM_GetCustomerById?.length > 0 ? this.state.TM_GetCustomerById[0].email : null)));
		formVars.customerdetailpage_922496_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetCustomerById !== undefined ? (stateVars.TM_GetCustomerById?.length > 0 ? stateVars.TM_GetCustomerById[0].vergiNo : null) : (this.state.TM_GetCustomerById?.length > 0 ? this.state.TM_GetCustomerById[0].vergiNo : null)));
		formVars.customerdetailpage_290080_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetCustomerById !== undefined ? (stateVars.TM_GetCustomerById?.length > 0 ? stateVars.TM_GetCustomerById[0].pasaportNo : null) : (this.state.TM_GetCustomerById?.length > 0 ? this.state.TM_GetCustomerById[0].pasaportNo : null)));
		formVars.customerdetailpage_609340_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetCustomerById !== undefined ? (stateVars.TM_GetCustomerById?.length > 0 ? stateVars.TM_GetCustomerById[0].pasaportVerilisTarihi : null) : (this.state.TM_GetCustomerById?.length > 0 ? this.state.TM_GetCustomerById[0].pasaportVerilisTarihi : null)));
		formVars.customerdetailpage_428279_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetCustomerById !== undefined ? (stateVars.TM_GetCustomerById?.length > 0 ? stateVars.TM_GetCustomerById[0].pasaportUlkesi : null) : (this.state.TM_GetCustomerById?.length > 0 ? this.state.TM_GetCustomerById[0].pasaportUlkesi : null)));
		formVars.customerdetailpage_253779_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetCustomerById !== undefined ? (stateVars.TM_GetCustomerById?.length > 0 ? stateVars.TM_GetCustomerById[0].ulke : null) : (this.state.TM_GetCustomerById?.length > 0 ? this.state.TM_GetCustomerById[0].ulke : null)));
		formVars.customerdetailpage_403067_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetCustomerById !== undefined ? (stateVars.TM_GetCustomerById?.length > 0 ? stateVars.TM_GetCustomerById[0].sehir : null) : (this.state.TM_GetCustomerById?.length > 0 ? this.state.TM_GetCustomerById[0].sehir : null)));
		formVars.customerdetailpage_784104_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetCustomerById !== undefined ? (stateVars.TM_GetCustomerById?.length > 0 ? stateVars.TM_GetCustomerById[0].ulke : null) : (this.state.TM_GetCustomerById?.length > 0 ? this.state.TM_GetCustomerById[0].ulke : null)));
		formVars.customerdetailpage_669679_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetCustomerById !== undefined ? (stateVars.TM_GetCustomerById?.length > 0 ? stateVars.TM_GetCustomerById[0].info : null) : (this.state.TM_GetCustomerById?.length > 0 ? this.state.TM_GetCustomerById[0].info : null)));
		formVars.customerdetailpage_854992_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetCustomerById !== undefined ? (stateVars.TM_GetCustomerById?.length > 0 ? stateVars.TM_GetCustomerById[0].dogumGunu : null) : (this.state.TM_GetCustomerById?.length > 0 ? this.state.TM_GetCustomerById[0].dogumGunu : null)));
		formVars.customerdetailpage_184616_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetCustomerById !== undefined ? (stateVars.TM_GetCustomerById?.length > 0 ? stateVars.TM_GetCustomerById[0].musteriTipi : null) : (this.state.TM_GetCustomerById?.length > 0 ? this.state.TM_GetCustomerById[0].musteriTipi : null)));
		formVars.customerdetailpage_981977_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetCustomerById !== undefined ? (stateVars.TM_GetCustomerById?.length > 0 ? stateVars.TM_GetCustomerById[0].adres : null) : (this.state.TM_GetCustomerById?.length > 0 ? this.state.TM_GetCustomerById[0].adres : null)));
		stateVars.isComp954207Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, (stateVars.TM_GetCustomerById !== undefined ? (stateVars.TM_GetCustomerById?.length > 0 ? stateVars.TM_GetCustomerById[0].isShopping : null) : (this.state.TM_GetCustomerById?.length > 0 ? this.state.TM_GetCustomerById[0].isShopping : null))), ReactSystemFunctions.convertToTypeByName("True", "string"))) === true ? "visible" : "hidden")
		stateVars.isComp242314Visible = ((ReactSystemFunctions.isNotEqualTo(ReactSystemFunctions.value(this, (stateVars.TM_GetCustomerById !== undefined ? (stateVars.TM_GetCustomerById?.length > 0 ? stateVars.TM_GetCustomerById[0].isShopping : null) : (this.state.TM_GetCustomerById?.length > 0 ? this.state.TM_GetCustomerById[0].isShopping : null))), ReactSystemFunctions.convertToTypeByName("True", "string"))) === true ? "visible" : "hidden")
		stateVars.TM_GetAllCustomerLead = result?.data.tM_GetAllCustomerLead;
		
		stateVars.isComp500246Visible = ((ReactSystemFunctions.isEmpty(ReactSystemFunctions.value(this, (stateVars.TM_GetAllCustomerLead !== undefined ? (stateVars.TM_GetAllCustomerLead?.length > 0 ? stateVars.TM_GetAllCustomerLead[0].leadId : null) : (this.state.TM_GetAllCustomerLead?.length > 0 ? this.state.TM_GetAllCustomerLead[0].leadId : null))), ReactSystemFunctions.convertToTypeByName("True", "string"))) === true ? "visible" : "hidden")
		stateVars.isComp974000Visible = ((ReactSystemFunctions.isNotEmpty(ReactSystemFunctions.value(this, (stateVars.TM_GetAllCustomerLead !== undefined ? (stateVars.TM_GetAllCustomerLead?.length > 0 ? stateVars.TM_GetAllCustomerLead[0].leadId : null) : (this.state.TM_GetAllCustomerLead?.length > 0 ? this.state.TM_GetAllCustomerLead[0].leadId : null))), ReactSystemFunctions.convertToTypeByName("True", "string"))) === true ? "visible" : "hidden")
		stateVars.GetUsdEurForexSelling = result?.data.getUsdEurForexSelling;
		stateVars.GetCustomerDetail = result?.data.getCustomerDetail;
		
		formVars.customerdetailpage_409278_value = ReactSystemFunctions.toString(this, (stateVars.GetCustomerDetail !== undefined ? (stateVars.GetCustomerDetail?.length > 0 ? stateVars.GetCustomerDetail[0].totalPriceTL : null) : (this.state.GetCustomerDetail?.length > 0 ? this.state.GetCustomerDetail[0].totalPriceTL : null)));
		formVars.customerdetailpage_839187_value = ReactSystemFunctions.toString(this, (stateVars.GetCustomerDetail !== undefined ? (stateVars.GetCustomerDetail?.length > 0 ? stateVars.GetCustomerDetail[0].totalPriceEUR : null) : (this.state.GetCustomerDetail?.length > 0 ? this.state.GetCustomerDetail[0].totalPriceEUR : null)));
		stateVars.isComp954547Visible = ((ReactSystemFunctions.isEmpty(ReactSystemFunctions.value(this, (stateVars.GetCustomerDetail !== undefined ? (stateVars.GetCustomerDetail?.length > 0 ? stateVars.GetCustomerDetail[0].totalPriceTL : null) : (this.state.GetCustomerDetail?.length > 0 ? this.state.GetCustomerDetail[0].totalPriceTL : null))), ReactSystemFunctions.convertToTypeByName("True", "string"))) === true ? "visible" : "hidden")
		stateVars.isComp152106Visible = ((ReactSystemFunctions.isNotEmpty(ReactSystemFunctions.value(this, (stateVars.GetCustomerDetail !== undefined ? (stateVars.GetCustomerDetail?.length > 0 ? stateVars.GetCustomerDetail[0].documentDate : null) : (this.state.GetCustomerDetail?.length > 0 ? this.state.GetCustomerDetail[0].documentDate : null))), ReactSystemFunctions.convertToTypeByName("True", "string"))) === true ? "visible" : "hidden")
		stateVars.isComp647616Visible = ((ReactSystemFunctions.isNotEmpty(ReactSystemFunctions.toString(this, (stateVars.GetCustomerDetail !== undefined ? (stateVars.GetCustomerDetail?.length > 0 ? stateVars.GetCustomerDetail[0].customerCode : null) : (this.state.GetCustomerDetail?.length > 0 ? this.state.GetCustomerDetail[0].customerCode : null))), ReactSystemFunctions.convertToTypeByName("True", "string"))) === true ? "visible" : "hidden")
		this.props.form?.setFieldsValue(formVars);
		
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.CustomerDetailPagePageInit1_();
                  resolve();
                });
          })



        
        KuikaAppManager.hideSpinner(this);
        return isErrorOccurred;
    }
	CustomerDetailPagePageInit1_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


	if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }

			formVars.customerdetailpage_217677_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetCustomerById !== undefined ? (stateVars.TM_GetCustomerById?.length > 0 ? stateVars.TM_GetCustomerById[0].adSoyad : null) : (this.state.TM_GetCustomerById?.length > 0 ? this.state.TM_GetCustomerById[0].adSoyad : null)));

			formVars.customerdetailpage_803344_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetCustomerById !== undefined ? (stateVars.TM_GetCustomerById?.length > 0 ? stateVars.TM_GetCustomerById[0].telefonNo : null) : (this.state.TM_GetCustomerById?.length > 0 ? this.state.TM_GetCustomerById[0].telefonNo : null)));

			formVars.customerdetailpage_922974_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetCustomerById !== undefined ? (stateVars.TM_GetCustomerById?.length > 0 ? stateVars.TM_GetCustomerById[0].tcKimlikNo : null) : (this.state.TM_GetCustomerById?.length > 0 ? this.state.TM_GetCustomerById[0].tcKimlikNo : null)));

			formVars.customerdetailpage_59481_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetCustomerById !== undefined ? (stateVars.TM_GetCustomerById?.length > 0 ? stateVars.TM_GetCustomerById[0].email : null) : (this.state.TM_GetCustomerById?.length > 0 ? this.state.TM_GetCustomerById[0].email : null)));

			formVars.customerdetailpage_922496_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetCustomerById !== undefined ? (stateVars.TM_GetCustomerById?.length > 0 ? stateVars.TM_GetCustomerById[0].vergiNo : null) : (this.state.TM_GetCustomerById?.length > 0 ? this.state.TM_GetCustomerById[0].vergiNo : null)));

			formVars.customerdetailpage_290080_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetCustomerById !== undefined ? (stateVars.TM_GetCustomerById?.length > 0 ? stateVars.TM_GetCustomerById[0].pasaportNo : null) : (this.state.TM_GetCustomerById?.length > 0 ? this.state.TM_GetCustomerById[0].pasaportNo : null)));

			formVars.customerdetailpage_609340_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetCustomerById !== undefined ? (stateVars.TM_GetCustomerById?.length > 0 ? stateVars.TM_GetCustomerById[0].pasaportVerilisTarihi : null) : (this.state.TM_GetCustomerById?.length > 0 ? this.state.TM_GetCustomerById[0].pasaportVerilisTarihi : null)));

			formVars.customerdetailpage_428279_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetCustomerById !== undefined ? (stateVars.TM_GetCustomerById?.length > 0 ? stateVars.TM_GetCustomerById[0].pasaportUlkesi : null) : (this.state.TM_GetCustomerById?.length > 0 ? this.state.TM_GetCustomerById[0].pasaportUlkesi : null)));

			formVars.customerdetailpage_253779_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetCustomerById !== undefined ? (stateVars.TM_GetCustomerById?.length > 0 ? stateVars.TM_GetCustomerById[0].ulke : null) : (this.state.TM_GetCustomerById?.length > 0 ? this.state.TM_GetCustomerById[0].ulke : null)));

			formVars.customerdetailpage_403067_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetCustomerById !== undefined ? (stateVars.TM_GetCustomerById?.length > 0 ? stateVars.TM_GetCustomerById[0].sehir : null) : (this.state.TM_GetCustomerById?.length > 0 ? this.state.TM_GetCustomerById[0].sehir : null)));

			formVars.customerdetailpage_784104_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetCustomerById !== undefined ? (stateVars.TM_GetCustomerById?.length > 0 ? stateVars.TM_GetCustomerById[0].ulke : null) : (this.state.TM_GetCustomerById?.length > 0 ? this.state.TM_GetCustomerById[0].ulke : null)));

			formVars.customerdetailpage_669679_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetCustomerById !== undefined ? (stateVars.TM_GetCustomerById?.length > 0 ? stateVars.TM_GetCustomerById[0].info : null) : (this.state.TM_GetCustomerById?.length > 0 ? this.state.TM_GetCustomerById[0].info : null)));

			formVars.customerdetailpage_854992_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetCustomerById !== undefined ? (stateVars.TM_GetCustomerById?.length > 0 ? stateVars.TM_GetCustomerById[0].dogumGunu : null) : (this.state.TM_GetCustomerById?.length > 0 ? this.state.TM_GetCustomerById[0].dogumGunu : null)));

			stateVars.isComp954207Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, (stateVars.TM_GetCustomerById !== undefined ? (stateVars.TM_GetCustomerById?.length > 0 ? stateVars.TM_GetCustomerById[0].isShopping : null) : (this.state.TM_GetCustomerById?.length > 0 ? this.state.TM_GetCustomerById[0].isShopping : null))), ReactSystemFunctions.convertToTypeByName("True", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp242314Visible = ((ReactSystemFunctions.isNotEqualTo(ReactSystemFunctions.value(this, (stateVars.TM_GetCustomerById !== undefined ? (stateVars.TM_GetCustomerById?.length > 0 ? stateVars.TM_GetCustomerById[0].isShopping : null) : (this.state.TM_GetCustomerById?.length > 0 ? this.state.TM_GetCustomerById[0].isShopping : null))), ReactSystemFunctions.convertToTypeByName("True", "string"))) === true ? "visible" : "hidden")
			formVars.customerdetailpage_184616_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetCustomerById !== undefined ? (stateVars.TM_GetCustomerById?.length > 0 ? stateVars.TM_GetCustomerById[0].musteriTipi : null) : (this.state.TM_GetCustomerById?.length > 0 ? this.state.TM_GetCustomerById[0].musteriTipi : null)));

			formVars.customerdetailpage_981977_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetCustomerById !== undefined ? (stateVars.TM_GetCustomerById?.length > 0 ? stateVars.TM_GetCustomerById[0].adres : null) : (this.state.TM_GetCustomerById?.length > 0 ? this.state.TM_GetCustomerById[0].adres : null)));

			stateVars.isComp500246Visible = ((ReactSystemFunctions.isEmpty(ReactSystemFunctions.value(this, (stateVars.TM_GetAllCustomerLead !== undefined ? (stateVars.TM_GetAllCustomerLead?.length > 0 ? stateVars.TM_GetAllCustomerLead[0].leadId : null) : (this.state.TM_GetAllCustomerLead?.length > 0 ? this.state.TM_GetAllCustomerLead[0].leadId : null))), ReactSystemFunctions.convertToTypeByName("True", "string"))) === true ? "visible" : "hidden")
			
			stateVars.dataSource_974000 = stateVars.TM_GetAllCustomerLead ?? this.state.TM_GetAllCustomerLead;
			stateVars.isComp974000Visible = ((ReactSystemFunctions.isNotEmpty(ReactSystemFunctions.value(this, (stateVars.TM_GetAllCustomerLead !== undefined ? (stateVars.TM_GetAllCustomerLead?.length > 0 ? stateVars.TM_GetAllCustomerLead[0].leadId : null) : (this.state.TM_GetAllCustomerLead?.length > 0 ? this.state.TM_GetAllCustomerLead[0].leadId : null))), ReactSystemFunctions.convertToTypeByName("True", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp325634Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, "customerdetailpage_974000_value", "processName"), ReactSystemFunctions.convertToTypeByName("Onaylandı", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp163122Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, "customerdetailpage_974000_value", "processName"), ReactSystemFunctions.convertToTypeByName("Onaylandı", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp118495Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, "customerdetailpage_974000_value", "processName"), ReactSystemFunctions.convertToTypeByName("Onaylandı", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp954547Visible = ((ReactSystemFunctions.isEmpty(ReactSystemFunctions.value(this, (stateVars.GetCustomerDetail !== undefined ? (stateVars.GetCustomerDetail?.length > 0 ? stateVars.GetCustomerDetail[0].totalPriceTL : null) : (this.state.GetCustomerDetail?.length > 0 ? this.state.GetCustomerDetail[0].totalPriceTL : null))), ReactSystemFunctions.convertToTypeByName("True", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp152106Visible = ((ReactSystemFunctions.isNotEmpty(ReactSystemFunctions.value(this, (stateVars.GetCustomerDetail !== undefined ? (stateVars.GetCustomerDetail?.length > 0 ? stateVars.GetCustomerDetail[0].documentDate : null) : (this.state.GetCustomerDetail?.length > 0 ? this.state.GetCustomerDetail[0].documentDate : null))), ReactSystemFunctions.convertToTypeByName("True", "string"))) === true ? "visible" : "hidden")
			formVars.customerdetailpage_409278_value = ReactSystemFunctions.toString(this, (stateVars.GetCustomerDetail !== undefined ? (stateVars.GetCustomerDetail?.length > 0 ? stateVars.GetCustomerDetail[0].totalPriceTL : null) : (this.state.GetCustomerDetail?.length > 0 ? this.state.GetCustomerDetail[0].totalPriceTL : null)));

			formVars.customerdetailpage_839187_value = ReactSystemFunctions.toString(this, (stateVars.GetCustomerDetail !== undefined ? (stateVars.GetCustomerDetail?.length > 0 ? stateVars.GetCustomerDetail[0].totalPriceEUR : null) : (this.state.GetCustomerDetail?.length > 0 ? this.state.GetCustomerDetail[0].totalPriceEUR : null)));

			
			stateVars.dataSource_647616 = stateVars.GetCustomerDetail ?? this.state.GetCustomerDetail;
			stateVars.isComp647616Visible = ((ReactSystemFunctions.isNotEmpty(ReactSystemFunctions.toString(this, (stateVars.GetCustomerDetail !== undefined ? (stateVars.GetCustomerDetail?.length > 0 ? stateVars.GetCustomerDetail[0].customerCode : null) : (this.state.GetCustomerDetail?.length > 0 ? this.state.GetCustomerDetail[0].customerCode : null))), ReactSystemFunctions.convertToTypeByName("True", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp881654Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, "customerdetailpage_647616_value", "docCurrencyCode"), ReactSystemFunctions.convertToTypeByName("TRY", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp950909Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, "customerdetailpage_647616_value", "docCurrencyCode"), ReactSystemFunctions.convertToTypeByName("USD", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp930321Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, "customerdetailpage_647616_value", "docCurrencyCode"), ReactSystemFunctions.convertToTypeByName("EUR", "string"))) === true ? "visible" : "hidden")

	this.props.form?.setFieldsValue(formVars);
	this.setState(stateVars);
	KuikaAppManager.hideSpinner(this);

            this.setPageInitLoaded(true);
            return isErrorOccurred;
        }




		CustomerDetailPageComponent_54151_onClick = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
KuikaAppManager.showSpinner(this);

				stateVars.GoBack = await ReactSystemFunctions.goBack(this, false);

		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

            
            return isErrorOccurred;
        }


		CustomerDetailPageComponent_294972_onClick = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
KuikaAppManager.showSpinner(this);

					KuikaAppManager.prepareForNavigation();
						KuikaAppManager.addToPageInputVariables("CustomerChangeLog", "CustomerId", ReactSystemFunctions.convertToTypeByName(this.props.screenInputs.CustomerId ?? this.props.screenInputs.customerid, "Guid"));

				stateVars.NAVIGATE = await ReactSystemFunctions.navigate(this, undefined, "CustomerDetailPage", "CustomerChangeLog", "", "7d969ddf-5801-4eb6-b92b-12be35bdd565", "70342", null, "right", "true", "60%", "100vh", true, false);

		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

            
            return isErrorOccurred;
        }




    async callCallbackFunction(diId: number, isFromMaster: boolean = false) {
        let isErrorOccurred = false;
		let pageInitCallerNavDiIDs = [70342] as number[];
		if (isFromMaster || pageInitCallerNavDiIDs.indexOf(diId) > -1) {
			await this.CustomerDetailPagePageInit();
		}

    }


}
