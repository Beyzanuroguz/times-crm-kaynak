import React from "react";
import Axios, { AxiosResponse } from "axios";
import { KuikaAppManager } from "../../shared/utilty/kuika-app-manager";
import { ReactSystemFunctions } from "../../shared/utilty/react-system-functions";
import { KNavigator } from "../../shared/hoc/with-history";
import { KContext } from "../../shared/hoc/with-context";
import { useLocation } from "react-router-dom";
import { FormInstance } from "antd/es/form";
import { Guid } from "guid-typescript";
import Swal from "sweetalert2";
import { KMainFunctions } from "../../shared/utilty/main-functions";
import moment from "moment";
import { IValidationData } from "../../models/dto/validation-data";
import { IStripePayment } from "../../models/dto/stripe-payment";
import { IUserInfoDto } from "../../models/dto/user-info.dto";
import { UserService } from "../../services/user-service";
import { kuikaCoreWasmBridgeService } from "../../services/_singletons";
import _ from "lodash";
import mqtt, { MqttClient } from "mqtt";
import { IMqttResult } from "../../models/dto/mqtt.dto";
import { MasterScreen_ScreenContext } from "../masterscreen/masterscreen-context";

declare let window: any;

export interface IDupontBasedReporting_ScreenProps {
  navigator: KNavigator;
  form: FormInstance<any>;
  googleLogin: any;
  screenInputs: any;
  context: KContext;
  initialValues: any;
  children: any;
}

export interface IDupontBasedReporting_ScreenState {
    isSpinnerVisible: boolean;
    isPageVisible: boolean;
	isLeftMenuVisible: boolean;
    spinnerCount: number;
    selectedLanguage: string;
    isPageInitLoaded: false;
    isPageRecurringLoaded: false;
	KuikaY_MonthlyStoreSalesReport: any[];
	KuikaY_MonthlyStoreSalesReport_dummy: any[];
	KuikaY_GetProductGroupsByBrand: any[];
	KuikaY_GetProductGroupsByBrand_dummy: any[];
	Kuika_ReportProductSales: any[];
	Kuika_ReportProductSales_dummy: any[];
	KuikaY_DupontAylikSatisKarsilastirma: any[];
	KuikaY_DupontAylikSatisKarsilastirma_dummy: any[];
	NAVIGATE: any;
	NAVIGATE_dummy: any;
	ExportExcel: any;
	ExportExcel_dummy: any;
	isComp209508Visible: 'visible' | 'hidden';
	isComp479325Visible: 'visible' | 'hidden';
	isComp483040Visible: 'visible' | 'hidden';
	isComp467053Visible: 'visible' | 'hidden';
	isComp529962Visible: 'visible' | 'hidden';
	isComp382072Visible: 'visible' | 'hidden';
	isComp720102Visible: 'visible' | 'hidden';
	isComp338511Visible: 'visible' | 'hidden';
	isComp74718Visible: 'visible' | 'hidden';
	isComp612408Visible: 'visible' | 'hidden';
	isComp676030Visible: 'visible' | 'hidden';
	isComp813367Visible: 'visible' | 'hidden';
	isComp29390Visible: 'visible' | 'hidden';
	isComp696744Visible: 'visible' | 'hidden';
	isComp948714Visible: 'visible' | 'hidden';
	isComp36787Visible: 'visible' | 'hidden';
	isComp856623Visible: 'visible' | 'hidden';
	isComp632315Visible: 'visible' | 'hidden';
	isComp414230Visible: 'visible' | 'hidden';
	isComp387172Visible: 'visible' | 'hidden';
	isComp785001Visible: 'visible' | 'hidden';
	isComp535336Visible: 'visible' | 'hidden';
	isComp711961Visible: 'visible' | 'hidden';
	isComp921931Visible: 'visible' | 'hidden';
	isComp80876Visible: 'visible' | 'hidden';
	isComp424357Visible: 'visible' | 'hidden';
	isComp667218Visible: 'visible' | 'hidden';
	isComp878906Visible: 'visible' | 'hidden';

}

export class DupontBasedReporting_ScreenBase extends React.PureComponent<IDupontBasedReporting_ScreenProps, any> {
    static contextType = MasterScreen_ScreenContext;
    declare context: React.ContextType<typeof MasterScreen_ScreenContext>;
	dupontbasedreporting_706925_value_kuikaAutoCompleteRef: React.RefObject<any>;
	dupontbasedreporting_847069_value_kuikaAutoCompleteRef: React.RefObject<any>;
	dupontbasedreporting_33296_value_kuikaTableRef: React.RefObject<any>;
	dupontbasedreporting_833904_value_kuikaTableRef: React.RefObject<any>;
	dupontbasedreporting_109751_value_kuikaTableRef: React.RefObject<any>;
	dupontbasedreporting_165803_value_kuikaTableRef: React.RefObject<any>;
	dupontbasedreporting_888464_value_kuikaTableRef: React.RefObject<any>;
	dupontbasedreporting_554019_value_kuikaTableRef: React.RefObject<any>;
	dupontbasedreporting_487656_value_kuikaTableRef: React.RefObject<any>;
	dupontbasedreporting_804184_value_kuikaTableRef: React.RefObject<any>;
	dupontbasedreporting_198551_value_kuikaTableRef: React.RefObject<any>;
	dupontbasedreporting_645134_value_kuikaTableRef: React.RefObject<any>;
	dupontbasedreporting_10624_value_kuikaTableRef: React.RefObject<any>;
	dupontbasedreporting_774686_value_kuikaTableRef: React.RefObject<any>;
	dupontbasedreporting_754648_value_kuikaTableRef: React.RefObject<any>;
    ml=[{"Id":"d5a61d2b-bd60-485f-86e2-661e9ed4e486","Name":"en_US","ShortName":"English","IsDefault":true,"LanguagePhrases":[]},{"Id":"5d6b254d-a7e1-4929-80fc-fb6c6f4283b9","Name":"FixedValues","ShortName":"FixedValues","LanguagePhrases":[{"Id":910240,"PropertyName":"value","Value":"Marka Bazlı Raporlama"},{"Id":869891,"PropertyName":"value","Value":"Mağaza satış performanslarını karşılaştırmalı olarak analiz edin."},{"Id":890243,"PropertyName":"label","Value":"Rolex"},{"Id":913849,"PropertyName":"label","Value":"Tudor"},{"Id":42755,"PropertyName":"label","Value":"Mont Blanc"},{"Id":793351,"PropertyName":"label","Value":"Dupont"},{"Id":126713,"PropertyName":"value","Value":"Analiz Tipi"},{"Id":248363,"PropertyName":"value","Value":"Genel Satış"},{"Id":437443,"PropertyName":"value","Value":"Dupont-"},{"Id":275449,"PropertyName":"value","Value":"-Mağaza Bazlı Satış Özet Görünüm"},{"Id":878329,"PropertyName":"value","Value":"Yıl"},{"Id":98494,"PropertyName":"placeholder","Value":"Select Year..."},{"Id":615441,"PropertyName":"value","Value":"Ürün Grubu"},{"Id":706925,"PropertyName":"placeholder","Value":"Tümü"},{"Id":37878,"PropertyName":"value","Value":"Toplam Satış Adedi"},{"Id":833488,"PropertyName":"value","Value":"+18.5%"},{"Id":232881,"PropertyName":"value","Value":"-18.5%"},{"Id":48790,"PropertyName":"value","Value":"Bu Ayın Satış Adeti"},{"Id":793158,"PropertyName":"value","Value":"+18.5%"},{"Id":268030,"PropertyName":"value","Value":"-18.5%"},{"Id":609778,"PropertyName":"value","Value":"Geçen Yıla Göre Artış"},{"Id":134804,"PropertyName":"value","Value":"Yıllık Büyüme"},{"Id":833729,"PropertyName":"value","Value":"En Güçlü Mağaza"},{"Id":111309,"PropertyName":"value","Value":"En Çok Satan Family"},{"Id":316216,"PropertyName":"value","Value":"En Çok Satan Material"},{"Id":972470,"PropertyName":"value","Value":"Dupont-"},{"Id":503531,"PropertyName":"value","Value":"-Mağaza Bazlı Satış Özet Görünüm"},{"Id":747367,"PropertyName":"value","Value":"Yıl"},{"Id":281612,"PropertyName":"placeholder","Value":"Select Year..."},{"Id":781076,"PropertyName":"value","Value":"Ürün Grubu"},{"Id":847069,"PropertyName":"placeholder","Value":"Tümü"},{"Id":933507,"PropertyName":"title","Value":"Mağaza"},{"Id":166832,"PropertyName":"value","Value":"[datafield:magaza]"},{"Id":641809,"PropertyName":"title","Value":"Ocak"},{"Id":897384,"PropertyName":"value","Value":"[datafield:ocak]"},{"Id":472100,"PropertyName":"title","Value":"Şubat"},{"Id":472372,"PropertyName":"value","Value":"[datafield:subat]"},{"Id":337393,"PropertyName":"title","Value":"Mart"},{"Id":774269,"PropertyName":"value","Value":"[datafield:mart]"},{"Id":917538,"PropertyName":"title","Value":"Nisan"},{"Id":467442,"PropertyName":"value","Value":"[datafield:nisan]"},{"Id":570359,"PropertyName":"title","Value":"Mayıs"},{"Id":933911,"PropertyName":"value","Value":"[datafield:mayis]"},{"Id":337273,"PropertyName":"title","Value":"Haziran"},{"Id":703202,"PropertyName":"value","Value":"[datafield:haziran]"},{"Id":953524,"PropertyName":"title","Value":"Temmuz"},{"Id":228099,"PropertyName":"value","Value":"[datafield:temmuz]"},{"Id":804431,"PropertyName":"title","Value":"Ağustos"},{"Id":918320,"PropertyName":"value","Value":"[datafield:agustos]"},{"Id":621269,"PropertyName":"title","Value":"Eylül"},{"Id":890688,"PropertyName":"value","Value":"[datafield:eylul]"},{"Id":467069,"PropertyName":"title","Value":"Ekim"},{"Id":675007,"PropertyName":"value","Value":"[datafield:ekim]"},{"Id":747767,"PropertyName":"title","Value":"Kasım"},{"Id":759058,"PropertyName":"value","Value":"[datafield:kasim]"},{"Id":627737,"PropertyName":"title","Value":"Aralık"},{"Id":353789,"PropertyName":"value","Value":"[datafield:aralik]"},{"Id":293989,"PropertyName":"title","Value":"Toplam"},{"Id":588249,"PropertyName":"value","Value":"[datafield:toplam]"},{"Id":348452,"PropertyName":"value","Value":"Aylık Satış Raporları - Dupont"},{"Id":973026,"PropertyName":"value","Value":"Yıl 1"},{"Id":70669,"PropertyName":"placeholder","Value":"Select Year..."},{"Id":82588,"PropertyName":"value","Value":"Yıl 2"},{"Id":421729,"PropertyName":"placeholder","Value":"Select Year..."},{"Id":883454,"PropertyName":"label","Value":"Uygula"},{"Id":549805,"PropertyName":"value","Value":"Ocak/"},{"Id":827056,"PropertyName":"value","Value":"-"},{"Id":955585,"PropertyName":"title","Value":"Mağaza"},{"Id":928431,"PropertyName":"value","Value":"[datafield:magaza]"},{"Id":529353,"PropertyName":"value","Value":"[datafield:ocakadet2025]"},{"Id":169928,"PropertyName":"value","Value":"[datafield:ocakadet2026]"},{"Id":690253,"PropertyName":"title","Value":"Değişim"},{"Id":529962,"PropertyName":"value","Value":"[datafield:ocakadetdegisim]"},{"Id":382072,"PropertyName":"value","Value":"[datafield:ocakadetdegisim]"},{"Id":806554,"PropertyName":"value","Value":"Şubat/"},{"Id":383690,"PropertyName":"value","Value":"-"},{"Id":161857,"PropertyName":"title","Value":"Mağaza"},{"Id":2750,"PropertyName":"value","Value":"[datafield:magaza]"},{"Id":253192,"PropertyName":"value","Value":"[datafield:subatadet2025]"},{"Id":304032,"PropertyName":"value","Value":"[datafield:subatadet2026]"},{"Id":830701,"PropertyName":"title","Value":"Değişim"},{"Id":720102,"PropertyName":"value","Value":"[datafield:subatadetdegisim]"},{"Id":338511,"PropertyName":"value","Value":"[datafield:subatadetdegisim]"},{"Id":870175,"PropertyName":"value","Value":"Mart/"},{"Id":272,"PropertyName":"value","Value":"-"},{"Id":960434,"PropertyName":"title","Value":"Mağaza"},{"Id":509919,"PropertyName":"value","Value":"[datafield:magaza]"},{"Id":748547,"PropertyName":"value","Value":"[datafield:martadet2025]"},{"Id":23888,"PropertyName":"value","Value":"[datafield:martadet2026]"},{"Id":874547,"PropertyName":"title","Value":"Değişim"},{"Id":74718,"PropertyName":"value","Value":"[datafield:martadetdegisim]"},{"Id":612408,"PropertyName":"value","Value":"[datafield:martadetdegisim]"},{"Id":899448,"PropertyName":"value","Value":"Nisan/"},{"Id":256106,"PropertyName":"value","Value":"-"},{"Id":334365,"PropertyName":"title","Value":"Mağaza"},{"Id":135460,"PropertyName":"value","Value":"[datafield:magaza]"},{"Id":590309,"PropertyName":"value","Value":"[datafield:nisanadet2025]"},{"Id":935870,"PropertyName":"value","Value":"[datafield:nisanadet2026]"},{"Id":484666,"PropertyName":"title","Value":"Değişim"},{"Id":676030,"PropertyName":"value","Value":"[datafield:nisanadetdegisim]"},{"Id":813367,"PropertyName":"value","Value":"[datafield:nisanadetdegisim]"},{"Id":319758,"PropertyName":"value","Value":"Mayıs/"},{"Id":809628,"PropertyName":"value","Value":"-"},{"Id":422299,"PropertyName":"title","Value":"Mağaza"},{"Id":856278,"PropertyName":"value","Value":"[datafield:magaza]"},{"Id":391879,"PropertyName":"value","Value":"[datafield:mayisadet2025]"},{"Id":673202,"PropertyName":"value","Value":"[datafield:mayisadet2026]"},{"Id":9967,"PropertyName":"title","Value":"Değişim"},{"Id":29390,"PropertyName":"value","Value":"[datafield:mayisadetdegisim]"},{"Id":696744,"PropertyName":"value","Value":"[datafield:mayisadetdegisim]"},{"Id":681454,"PropertyName":"value","Value":"Haziran/"},{"Id":640566,"PropertyName":"value","Value":"-"},{"Id":392093,"PropertyName":"title","Value":"Mağaza"},{"Id":291265,"PropertyName":"value","Value":"[datafield:magaza]"},{"Id":788976,"PropertyName":"value","Value":"[datafield:haziranadet2025]"},{"Id":450286,"PropertyName":"value","Value":"[datafield:haziranadet2026]"},{"Id":988051,"PropertyName":"title","Value":"Değişim"},{"Id":948714,"PropertyName":"value","Value":"[datafield:haziranadetdegisim]"},{"Id":36787,"PropertyName":"value","Value":"[datafield:haziranadetdegisim]"},{"Id":529912,"PropertyName":"value","Value":"Temmuz/"},{"Id":604683,"PropertyName":"value","Value":"-"},{"Id":543445,"PropertyName":"title","Value":"Mağaza"},{"Id":332662,"PropertyName":"value","Value":"[datafield:magaza]"},{"Id":462392,"PropertyName":"value","Value":"[datafield:temmuzadet2025]"},{"Id":496822,"PropertyName":"value","Value":"[datafield:temmuzadet2026]"},{"Id":600077,"PropertyName":"title","Value":"Değişim"},{"Id":856623,"PropertyName":"value","Value":"[datafield:temmuzadetdegisim]"},{"Id":632315,"PropertyName":"value","Value":"[datafield:temmuzadetdegisim]"},{"Id":96394,"PropertyName":"value","Value":"Ağustos/"},{"Id":472526,"PropertyName":"value","Value":"-"},{"Id":853555,"PropertyName":"title","Value":"Mağaza"},{"Id":397303,"PropertyName":"value","Value":"[datafield:magaza]"},{"Id":992295,"PropertyName":"value","Value":"[datafield:agustosadet2025]"},{"Id":502875,"PropertyName":"value","Value":"[datafield:agustosadet2026]"},{"Id":698788,"PropertyName":"title","Value":"Değişim"},{"Id":414230,"PropertyName":"value","Value":"[datafield:agustosadetdegisim]"},{"Id":387172,"PropertyName":"value","Value":"[datafield:agustosadetdegisim]"},{"Id":712881,"PropertyName":"value","Value":"Eylül/"},{"Id":530297,"PropertyName":"value","Value":"-"},{"Id":508513,"PropertyName":"title","Value":"Mağaza"},{"Id":740130,"PropertyName":"value","Value":"[datafield:magaza]"},{"Id":292822,"PropertyName":"value","Value":"[datafield:eyluladet2025]"},{"Id":386939,"PropertyName":"value","Value":"[datafield:eyluladet2026]"},{"Id":673887,"PropertyName":"title","Value":"Değişim"},{"Id":785001,"PropertyName":"value","Value":"[datafield:eyluladetdegisim]"},{"Id":535336,"PropertyName":"value","Value":"[datafield:eyluladetdegisim]"},{"Id":476459,"PropertyName":"value","Value":"Ekim/"},{"Id":46188,"PropertyName":"value","Value":"-"},{"Id":992392,"PropertyName":"title","Value":"Mağaza"},{"Id":533377,"PropertyName":"value","Value":"[datafield:magaza]"},{"Id":260237,"PropertyName":"value","Value":"[datafield:ekimadet2025]"},{"Id":101070,"PropertyName":"value","Value":"[datafield:ekimadet2026]"},{"Id":44150,"PropertyName":"title","Value":"Değişim"},{"Id":711961,"PropertyName":"value","Value":"[datafield:ekimadetdegisim]"},{"Id":921931,"PropertyName":"value","Value":"[datafield:ekimadetdegisim]"},{"Id":426321,"PropertyName":"value","Value":"Kasım/"},{"Id":660327,"PropertyName":"value","Value":"-"},{"Id":484505,"PropertyName":"title","Value":"Mağaza"},{"Id":502537,"PropertyName":"value","Value":"[datafield:magaza]"},{"Id":230921,"PropertyName":"value","Value":"[datafield:kasimadet2025]"},{"Id":619023,"PropertyName":"value","Value":"[datafield:kasimadet2026]"},{"Id":187885,"PropertyName":"title","Value":"Değişim"},{"Id":80876,"PropertyName":"value","Value":"[datafield:kasimadetdegisim]"},{"Id":424357,"PropertyName":"value","Value":"[datafield:kasimadetdegisim]"},{"Id":345326,"PropertyName":"value","Value":"Aralık/"},{"Id":111475,"PropertyName":"value","Value":"-"},{"Id":844681,"PropertyName":"title","Value":"Mağaza"},{"Id":390660,"PropertyName":"value","Value":"[datafield:magaza]"},{"Id":858705,"PropertyName":"value","Value":"[datafield:aralikadet2025]"},{"Id":883842,"PropertyName":"value","Value":"[datafield:aralikadet2026]"},{"Id":473992,"PropertyName":"title","Value":"Değişim"},{"Id":667218,"PropertyName":"value","Value":"[datafield:aralikadetdegisim]"},{"Id":878906,"PropertyName":"value","Value":"[datafield:aralikadetdegisim]"}]}]
    defaultML = "en_US"
    
    screenHash = ""
    

    private _prevMasterPageInitLoaded: boolean = false;
    private _prevMasterPageRecurringLoaded: boolean = false;
    private _prevShouldTriggerPageInit: boolean = false;
    constructor(props) {
        super(props);
		this.dupontbasedreporting_706925_value_kuikaAutoCompleteRef = React.createRef();
		this.dupontbasedreporting_847069_value_kuikaAutoCompleteRef = React.createRef();
		this.dupontbasedreporting_33296_value_kuikaTableRef = React.createRef();
		this.dupontbasedreporting_833904_value_kuikaTableRef = React.createRef();
		this.dupontbasedreporting_109751_value_kuikaTableRef = React.createRef();
		this.dupontbasedreporting_165803_value_kuikaTableRef = React.createRef();
		this.dupontbasedreporting_888464_value_kuikaTableRef = React.createRef();
		this.dupontbasedreporting_554019_value_kuikaTableRef = React.createRef();
		this.dupontbasedreporting_487656_value_kuikaTableRef = React.createRef();
		this.dupontbasedreporting_804184_value_kuikaTableRef = React.createRef();
		this.dupontbasedreporting_198551_value_kuikaTableRef = React.createRef();
		this.dupontbasedreporting_645134_value_kuikaTableRef = React.createRef();
		this.dupontbasedreporting_10624_value_kuikaTableRef = React.createRef();
		this.dupontbasedreporting_774686_value_kuikaTableRef = React.createRef();
		this.dupontbasedreporting_754648_value_kuikaTableRef = React.createRef();

        this.state = {
            isSpinnerVisible: false,
            isPageVisible: false,
            isLeftMenuVisible: false,
            spinnerCount: 0,
            selectedLanguage: "",
            isPageInitLoaded: false,
            isPageRecurringLoaded: false,
            	        KuikaY_MonthlyStoreSalesReport: [],
	        KuikaY_GetProductGroupsByBrand: [],
	        Kuika_ReportProductSales: [],
	        KuikaY_DupontAylikSatisKarsilastirma: [],
	        NAVIGATE: "",
	        ExportExcel: "",
	        isComp209508Visible: 'hidden',
	        isComp479325Visible: 'hidden',
	        isComp483040Visible: 'hidden',
	        isComp467053Visible: 'hidden',
	        isComp529962Visible: 'hidden',
	        isComp382072Visible: 'hidden',
	        isComp720102Visible: 'hidden',
	        isComp338511Visible: 'hidden',
	        isComp74718Visible: 'hidden',
	        isComp612408Visible: 'hidden',
	        isComp676030Visible: 'hidden',
	        isComp813367Visible: 'hidden',
	        isComp29390Visible: 'hidden',
	        isComp696744Visible: 'hidden',
	        isComp948714Visible: 'hidden',
	        isComp36787Visible: 'hidden',
	        isComp856623Visible: 'hidden',
	        isComp632315Visible: 'hidden',
	        isComp414230Visible: 'hidden',
	        isComp387172Visible: 'hidden',
	        isComp785001Visible: 'hidden',
	        isComp535336Visible: 'hidden',
	        isComp711961Visible: 'hidden',
	        isComp921931Visible: 'hidden',
	        isComp80876Visible: 'hidden',
	        isComp424357Visible: 'hidden',
	        isComp667218Visible: 'hidden',
	        isComp878906Visible: 'hidden',

        }

        this.state.isPageVisible = true;
        
    }

    async componentDidMount() {

        if (KuikaAppManager.isPageInitPrevented()) {
            KuikaAppManager.calculateAndSetBodyHeight("dupontbasedreporting", "masterscreen_screen");
            return;
        }
        this.context.registerCallbackFunction(this.callCallbackFunction.bind(this));
        
        ReactSystemFunctions.validateToken()
        this.fillFormInitValues();
        if (false){
            await this.DupontBasedReportingPageInit();
        } else if (this.context?.isMasterPageInitLoaded) { this._prevMasterPageInitLoaded = true; await this.DupontBasedReportingPageInit(); }
        
        
        
        KuikaAppManager.calculateAndSetBodyHeight("dupontbasedreporting", "masterscreen_screen");

        if (ReactSystemFunctions.getIsMicroApp() === false) {
           window.parentScreen = this;
        }
    }

    componentWillUnmount() {
        
        
        

        if (ReactSystemFunctions.getIsMicroApp() === false) {
           window.parentScreen = null;
        }
    }

    

        
    componentDidUpdate= async (prevProps, prevState) => {
		KuikaAppManager.calculateAndSetBodyHeight("dupontbasedreporting", "masterscreen_screen"    );
        if (prevProps?.location?.search !== (this.props as any)?.location?.search) {
			await this.DupontBasedReportingPageInit();
		}

        		if (this._prevMasterPageInitLoaded !== this.context.isMasterPageInitLoaded && this.context.isMasterPageInitLoaded === true) {this._prevMasterPageInitLoaded = this.context.isMasterPageInitLoaded;await this.DupontBasedReportingPageInit()}


        if (ReactSystemFunctions.getIsMicroApp() === false) {
            for (const key in prevState) {
                if (key.startsWith('NavVisible') && prevState[key] === true && this.state[key] === false) {
                    window.parentScreen = this;
                    break;
                }
            }
        }
	}

    fillFormInitValues() {
        this.props.form?.setFieldsValue({
dupontbasedreporting_98494_value: 2026,
dupontbasedreporting_281612_value: 2026,
dupontbasedreporting_70669_value: 2025,
dupontbasedreporting_421729_value: 2026
});

    }

      setPageInitLoaded = (value: boolean) => {
        this.setState({ isPageInitLoaded: value });
      }

      setPageRecurringLoaded = (value: boolean) => {
        this.setState({ isPageRecurringLoaded: value });
      }

      clearFieldValidation = (changedValues: any) => {
        const fieldName = Object.keys(changedValues)[0];
        if (fieldName) {
          this.props.form?.setFields([
            {
              name: fieldName,
              errors: []
            }
          ]);
        }
      };

      

    DupontBasedReportingPageInit = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


	if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }

        let localVar = {
			Brand_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.convertToTypeByName("Dupont", "string"), "string"),
			ProductGroup_0: ReactSystemFunctions.convertToTypeByName("", "string"),
			Year_0: ReactSystemFunctions.convertToTypeByName(2026, "number"),
			Brand_1: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.convertToTypeByName("Dupont", "string"), "string"),
			Marka_2: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.convertToTypeByName("Dupont", "string"), "string"),
			UrunGrubu_2: ReactSystemFunctions.convertToTypeByName("", "string"),
			Year_2: ReactSystemFunctions.convertToTypeByName(2026, "number"),
			Year1_3: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "dupontbasedreporting_70669_value", "value", "", "", "")), "number"),
			Year2_3: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "dupontbasedreporting_421729_value", "value", "", "", "")), "number")
        }

	KuikaAppManager.showSpinner(this);
	
        if (true) {
        KuikaAppManager.showSpinner(this);
        }
        let result = await KuikaAppManager.ApiRequest(this, "DupontBasedReporting/DupontBasedReportingPageInit", localVar)
        if (!KMainFunctions.IsResStatus2XX(result)) return true;

		stateVars.KuikaY_MonthlyStoreSalesReport = result?.data.kuikaY_MonthlyStoreSalesReport;
		
		stateVars.KuikaY_GetProductGroupsByBrand = result?.data.kuikaY_GetProductGroupsByBrand;
		
		formVars.dupontbasedreporting_706925_options = stateVars.KuikaY_GetProductGroupsByBrand;
		
		formVars.dupontbasedreporting_847069_options = stateVars.KuikaY_GetProductGroupsByBrand;
		stateVars.Kuika_ReportProductSales = result?.data.kuika_ReportProductSales;
		formVars.dupontbasedreporting_142273_value = ReactSystemFunctions.toString(this, (stateVars.Kuika_ReportProductSales !== undefined ? (stateVars.Kuika_ReportProductSales?.length > 0 ? stateVars.Kuika_ReportProductSales[0].toplamSatisAdedi : null) : (this.state.Kuika_ReportProductSales?.length > 0 ? this.state.Kuika_ReportProductSales[0].toplamSatisAdedi : null)));
		formVars.dupontbasedreporting_862873_value = ReactSystemFunctions.toString(this, (stateVars.Kuika_ReportProductSales !== undefined ? (stateVars.Kuika_ReportProductSales?.length > 0 ? stateVars.Kuika_ReportProductSales[0].bulundugumuzAySatisAdedi : null) : (this.state.Kuika_ReportProductSales?.length > 0 ? this.state.Kuika_ReportProductSales[0].bulundugumuzAySatisAdedi : null)));
		formVars.dupontbasedreporting_442377_value = ReactSystemFunctions.toString(this, (stateVars.Kuika_ReportProductSales !== undefined ? (stateVars.Kuika_ReportProductSales?.length > 0 ? stateVars.Kuika_ReportProductSales[0].gecenYilaGoreArtisYuzde : null) : (this.state.Kuika_ReportProductSales?.length > 0 ? this.state.Kuika_ReportProductSales[0].gecenYilaGoreArtisYuzde : null)));
		formVars.dupontbasedreporting_49365_value = ReactSystemFunctions.toString(this, (stateVars.Kuika_ReportProductSales !== undefined ? (stateVars.Kuika_ReportProductSales?.length > 0 ? stateVars.Kuika_ReportProductSales[0].enGucluMagazaDesc : null) : (this.state.Kuika_ReportProductSales?.length > 0 ? this.state.Kuika_ReportProductSales[0].enGucluMagazaDesc : null)));
		formVars.dupontbasedreporting_689773_value = ReactSystemFunctions.toString(this, (stateVars.Kuika_ReportProductSales !== undefined ? (stateVars.Kuika_ReportProductSales?.length > 0 ? stateVars.Kuika_ReportProductSales[0].enGucluMagazaCiro : null) : (this.state.Kuika_ReportProductSales?.length > 0 ? this.state.Kuika_ReportProductSales[0].enGucluMagazaCiro : null)));
		formVars.dupontbasedreporting_662229_value = ReactSystemFunctions.toString(this, (stateVars.Kuika_ReportProductSales !== undefined ? (stateVars.Kuika_ReportProductSales?.length > 0 ? stateVars.Kuika_ReportProductSales[0].enCokSatanFamily : null) : (this.state.Kuika_ReportProductSales?.length > 0 ? this.state.Kuika_ReportProductSales[0].enCokSatanFamily : null)));
		formVars.dupontbasedreporting_825140_value = ReactSystemFunctions.toString(this, (stateVars.Kuika_ReportProductSales !== undefined ? (stateVars.Kuika_ReportProductSales?.length > 0 ? stateVars.Kuika_ReportProductSales[0].enCokSatanFamilyAdet : null) : (this.state.Kuika_ReportProductSales?.length > 0 ? this.state.Kuika_ReportProductSales[0].enCokSatanFamilyAdet : null)));
		formVars.dupontbasedreporting_51555_value = ReactSystemFunctions.toString(this, (stateVars.Kuika_ReportProductSales !== undefined ? (stateVars.Kuika_ReportProductSales?.length > 0 ? stateVars.Kuika_ReportProductSales[0].enCokSatanMaterial : null) : (this.state.Kuika_ReportProductSales?.length > 0 ? this.state.Kuika_ReportProductSales[0].enCokSatanMaterial : null)));
		formVars.dupontbasedreporting_816749_value = ReactSystemFunctions.toString(this, (stateVars.Kuika_ReportProductSales !== undefined ? (stateVars.Kuika_ReportProductSales?.length > 0 ? stateVars.Kuika_ReportProductSales[0].enCokSatanMaterialCiro : null) : (this.state.Kuika_ReportProductSales?.length > 0 ? this.state.Kuika_ReportProductSales[0].enCokSatanMaterialCiro : null)));
		stateVars.KuikaY_DupontAylikSatisKarsilastirma = result?.data.kuikaY_DupontAylikSatisKarsilastirma;
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		this.props.form?.setFieldsValue(formVars);
		
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.DupontBasedReportingPageInit1_();
                  resolve();
                });
          })



        
        KuikaAppManager.hideSpinner(this);
        return isErrorOccurred;
    }
	DupontBasedReportingPageInit1_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


	if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }

			ReactSystemFunctions.setValueOf(this, "dupontbasedreporting_529751_toString", ReactSystemFunctions.value(this, "dupontbasedreporting_98494_value", "value"), "value");

			
			stateVars.dataSource_706925 = stateVars.KuikaY_GetProductGroupsByBrand ?? this.state.KuikaY_GetProductGroupsByBrand;
			stateVars.dataSource_706925 = stateVars.KuikaY_GetProductGroupsByBrand ?? this.state.KuikaY_GetProductGroupsByBrand;
			formVars.dupontbasedreporting_142273_value = ReactSystemFunctions.toString(this, (stateVars.Kuika_ReportProductSales !== undefined ? (stateVars.Kuika_ReportProductSales?.length > 0 ? stateVars.Kuika_ReportProductSales[0].toplamSatisAdedi : null) : (this.state.Kuika_ReportProductSales?.length > 0 ? this.state.Kuika_ReportProductSales[0].toplamSatisAdedi : null)));

			formVars.dupontbasedreporting_862873_value = ReactSystemFunctions.toString(this, (stateVars.Kuika_ReportProductSales !== undefined ? (stateVars.Kuika_ReportProductSales?.length > 0 ? stateVars.Kuika_ReportProductSales[0].bulundugumuzAySatisAdedi : null) : (this.state.Kuika_ReportProductSales?.length > 0 ? this.state.Kuika_ReportProductSales[0].bulundugumuzAySatisAdedi : null)));

			formVars.dupontbasedreporting_442377_value = ReactSystemFunctions.toString(this, (stateVars.Kuika_ReportProductSales !== undefined ? (stateVars.Kuika_ReportProductSales?.length > 0 ? stateVars.Kuika_ReportProductSales[0].gecenYilaGoreArtisYuzde : null) : (this.state.Kuika_ReportProductSales?.length > 0 ? this.state.Kuika_ReportProductSales[0].gecenYilaGoreArtisYuzde : null)));

			formVars.dupontbasedreporting_49365_value = ReactSystemFunctions.toString(this, (stateVars.Kuika_ReportProductSales !== undefined ? (stateVars.Kuika_ReportProductSales?.length > 0 ? stateVars.Kuika_ReportProductSales[0].enGucluMagazaDesc : null) : (this.state.Kuika_ReportProductSales?.length > 0 ? this.state.Kuika_ReportProductSales[0].enGucluMagazaDesc : null)));

			formVars.dupontbasedreporting_689773_value = ReactSystemFunctions.toString(this, (stateVars.Kuika_ReportProductSales !== undefined ? (stateVars.Kuika_ReportProductSales?.length > 0 ? stateVars.Kuika_ReportProductSales[0].enGucluMagazaCiro : null) : (this.state.Kuika_ReportProductSales?.length > 0 ? this.state.Kuika_ReportProductSales[0].enGucluMagazaCiro : null)));

			formVars.dupontbasedreporting_662229_value = ReactSystemFunctions.toString(this, (stateVars.Kuika_ReportProductSales !== undefined ? (stateVars.Kuika_ReportProductSales?.length > 0 ? stateVars.Kuika_ReportProductSales[0].enCokSatanFamily : null) : (this.state.Kuika_ReportProductSales?.length > 0 ? this.state.Kuika_ReportProductSales[0].enCokSatanFamily : null)));

			formVars.dupontbasedreporting_825140_value = ReactSystemFunctions.toString(this, (stateVars.Kuika_ReportProductSales !== undefined ? (stateVars.Kuika_ReportProductSales?.length > 0 ? stateVars.Kuika_ReportProductSales[0].enCokSatanFamilyAdet : null) : (this.state.Kuika_ReportProductSales?.length > 0 ? this.state.Kuika_ReportProductSales[0].enCokSatanFamilyAdet : null)));

			formVars.dupontbasedreporting_51555_value = ReactSystemFunctions.toString(this, (stateVars.Kuika_ReportProductSales !== undefined ? (stateVars.Kuika_ReportProductSales?.length > 0 ? stateVars.Kuika_ReportProductSales[0].enCokSatanMaterial : null) : (this.state.Kuika_ReportProductSales?.length > 0 ? this.state.Kuika_ReportProductSales[0].enCokSatanMaterial : null)));

			formVars.dupontbasedreporting_816749_value = ReactSystemFunctions.toString(this, (stateVars.Kuika_ReportProductSales !== undefined ? (stateVars.Kuika_ReportProductSales?.length > 0 ? stateVars.Kuika_ReportProductSales[0].enCokSatanMaterialCiro : null) : (this.state.Kuika_ReportProductSales?.length > 0 ? this.state.Kuika_ReportProductSales[0].enCokSatanMaterialCiro : null)));

			ReactSystemFunctions.setValueOf(this, "dupontbasedreporting_928162_toString", ReactSystemFunctions.value(this, "dupontbasedreporting_281612_value", "value"), "value");

			
			stateVars.dataSource_847069 = stateVars.KuikaY_GetProductGroupsByBrand ?? this.state.KuikaY_GetProductGroupsByBrand;
			stateVars.dataSource_847069 = stateVars.KuikaY_GetProductGroupsByBrand ?? this.state.KuikaY_GetProductGroupsByBrand;
			
			stateVars.dataSource_33296 = stateVars.KuikaY_MonthlyStoreSalesReport ?? this.state.KuikaY_MonthlyStoreSalesReport;
			ReactSystemFunctions.setValueOf(this, "dupontbasedreporting_764507_toString", ReactSystemFunctions.value(this, "dupontbasedreporting_70669_value", "value"), "value");

			ReactSystemFunctions.setValueOf(this, "dupontbasedreporting_64123_toString", ReactSystemFunctions.value(this, "dupontbasedreporting_421729_value", "value"), "value");

			
			stateVars.dataSource_833904 = stateVars.KuikaY_DupontAylikSatisKarsilastirma ?? this.state.KuikaY_DupontAylikSatisKarsilastirma;
			
			
			stateVars.isComp529962Visible = ((ReactSystemFunctions.isGreaterOrEqual(ReactSystemFunctions.value(this, "dupontbasedreporting_833904_value", "ocakAdetDegisim"), ReactSystemFunctions.convertToTypeByName("0", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp382072Visible = ((ReactSystemFunctions.isLessThan(ReactSystemFunctions.value(this, "dupontbasedreporting_833904_value", "ocakAdetDegisim"), ReactSystemFunctions.convertToTypeByName("0", "string"))) === true ? "visible" : "hidden")
			
			stateVars.dataSource_834767 = stateVars.KuikaY_DupontAylikSatisKarsilastirma ?? this.state.KuikaY_DupontAylikSatisKarsilastirma;
			ReactSystemFunctions.setValueOf(this, "dupontbasedreporting_409033_toString", ReactSystemFunctions.value(this, "dupontbasedreporting_70669_value", "value"), "value");

			ReactSystemFunctions.setValueOf(this, "dupontbasedreporting_417597_toString", ReactSystemFunctions.value(this, "dupontbasedreporting_421729_value", "value"), "value");

			
			stateVars.dataSource_109751 = stateVars.KuikaY_DupontAylikSatisKarsilastirma ?? this.state.KuikaY_DupontAylikSatisKarsilastirma;
			
			
			stateVars.isComp720102Visible = ((ReactSystemFunctions.isGreaterOrEqual(ReactSystemFunctions.value(this, "dupontbasedreporting_109751_value", "subatAdetDegisim"), ReactSystemFunctions.convertToTypeByName("0", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp338511Visible = ((ReactSystemFunctions.isLessThan(ReactSystemFunctions.value(this, "dupontbasedreporting_109751_value", "subatAdetDegisim"), ReactSystemFunctions.convertToTypeByName("0", "string"))) === true ? "visible" : "hidden")
			
			stateVars.dataSource_693923 = stateVars.KuikaY_DupontAylikSatisKarsilastirma ?? this.state.KuikaY_DupontAylikSatisKarsilastirma;
			ReactSystemFunctions.setValueOf(this, "dupontbasedreporting_800382_toString", ReactSystemFunctions.value(this, "dupontbasedreporting_70669_value", "value"), "value");

			ReactSystemFunctions.setValueOf(this, "dupontbasedreporting_586949_toString", ReactSystemFunctions.value(this, "dupontbasedreporting_421729_value", "value"), "value");

			
			stateVars.dataSource_165803 = stateVars.KuikaY_DupontAylikSatisKarsilastirma ?? this.state.KuikaY_DupontAylikSatisKarsilastirma;
			
			
			stateVars.isComp74718Visible = ((ReactSystemFunctions.isGreaterOrEqual(ReactSystemFunctions.value(this, "dupontbasedreporting_165803_value", "martAdetDegisim"), ReactSystemFunctions.convertToTypeByName("0", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp612408Visible = ((ReactSystemFunctions.isLessThan(ReactSystemFunctions.value(this, "dupontbasedreporting_165803_value", "martAdetDegisim"), ReactSystemFunctions.convertToTypeByName("0", "string"))) === true ? "visible" : "hidden")
			
			stateVars.dataSource_632782 = stateVars.KuikaY_DupontAylikSatisKarsilastirma ?? this.state.KuikaY_DupontAylikSatisKarsilastirma;
			ReactSystemFunctions.setValueOf(this, "dupontbasedreporting_730787_toString", ReactSystemFunctions.value(this, "dupontbasedreporting_70669_value", "value"), "value");

			ReactSystemFunctions.setValueOf(this, "dupontbasedreporting_687434_toString", ReactSystemFunctions.value(this, "dupontbasedreporting_421729_value", "value"), "value");

			
			stateVars.dataSource_888464 = stateVars.KuikaY_DupontAylikSatisKarsilastirma ?? this.state.KuikaY_DupontAylikSatisKarsilastirma;
			
			
			stateVars.isComp676030Visible = ((ReactSystemFunctions.isGreaterOrEqual(ReactSystemFunctions.value(this, "dupontbasedreporting_888464_value", "nisanAdetDegisim"), ReactSystemFunctions.convertToTypeByName("0", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp813367Visible = ((ReactSystemFunctions.isLessThan(ReactSystemFunctions.value(this, "dupontbasedreporting_888464_value", "nisanAdetDegisim"), ReactSystemFunctions.convertToTypeByName("0", "string"))) === true ? "visible" : "hidden")
			
			stateVars.dataSource_522144 = stateVars.KuikaY_DupontAylikSatisKarsilastirma ?? this.state.KuikaY_DupontAylikSatisKarsilastirma;
			ReactSystemFunctions.setValueOf(this, "dupontbasedreporting_505224_toString", ReactSystemFunctions.value(this, "dupontbasedreporting_70669_value", "value"), "value");

			ReactSystemFunctions.setValueOf(this, "dupontbasedreporting_280856_toString", ReactSystemFunctions.value(this, "dupontbasedreporting_421729_value", "value"), "value");

			
			stateVars.dataSource_554019 = stateVars.KuikaY_DupontAylikSatisKarsilastirma ?? this.state.KuikaY_DupontAylikSatisKarsilastirma;
			
			
			stateVars.isComp29390Visible = ((ReactSystemFunctions.isGreaterOrEqual(ReactSystemFunctions.value(this, "dupontbasedreporting_554019_value", "mayisAdetDegisim"), ReactSystemFunctions.convertToTypeByName("0", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp696744Visible = ((ReactSystemFunctions.isLessThan(ReactSystemFunctions.value(this, "dupontbasedreporting_554019_value", "mayisAdetDegisim"), ReactSystemFunctions.convertToTypeByName("0", "string"))) === true ? "visible" : "hidden")
			
			stateVars.dataSource_237636 = stateVars.KuikaY_DupontAylikSatisKarsilastirma ?? this.state.KuikaY_DupontAylikSatisKarsilastirma;
			ReactSystemFunctions.setValueOf(this, "dupontbasedreporting_561858_toString", ReactSystemFunctions.value(this, "dupontbasedreporting_70669_value", "value"), "value");

			ReactSystemFunctions.setValueOf(this, "dupontbasedreporting_331949_toString", ReactSystemFunctions.value(this, "dupontbasedreporting_421729_value", "value"), "value");

			
			stateVars.dataSource_487656 = stateVars.KuikaY_DupontAylikSatisKarsilastirma ?? this.state.KuikaY_DupontAylikSatisKarsilastirma;
			
			
			stateVars.isComp948714Visible = ((ReactSystemFunctions.isGreaterOrEqual(ReactSystemFunctions.value(this, "dupontbasedreporting_487656_value", "haziranAdetDegisim"), ReactSystemFunctions.convertToTypeByName("0", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp36787Visible = ((ReactSystemFunctions.isLessThan(ReactSystemFunctions.value(this, "dupontbasedreporting_487656_value", "haziranAdetDegisim"), ReactSystemFunctions.convertToTypeByName("0", "string"))) === true ? "visible" : "hidden")
			
			stateVars.dataSource_510713 = stateVars.KuikaY_DupontAylikSatisKarsilastirma ?? this.state.KuikaY_DupontAylikSatisKarsilastirma;
			ReactSystemFunctions.setValueOf(this, "dupontbasedreporting_428037_toString", ReactSystemFunctions.value(this, "dupontbasedreporting_70669_value", "value"), "value");

			ReactSystemFunctions.setValueOf(this, "dupontbasedreporting_952544_toString", ReactSystemFunctions.value(this, "dupontbasedreporting_421729_value", "value"), "value");

			
			stateVars.dataSource_804184 = stateVars.KuikaY_DupontAylikSatisKarsilastirma ?? this.state.KuikaY_DupontAylikSatisKarsilastirma;
			
			
			stateVars.isComp856623Visible = ((ReactSystemFunctions.isGreaterOrEqual(ReactSystemFunctions.value(this, "dupontbasedreporting_804184_value", "temmuzAdetDegisim"), ReactSystemFunctions.convertToTypeByName("0", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp632315Visible = ((ReactSystemFunctions.isLessThan(ReactSystemFunctions.value(this, "dupontbasedreporting_804184_value", "temmuzAdetDegisim"), ReactSystemFunctions.convertToTypeByName("0", "string"))) === true ? "visible" : "hidden")
			
			stateVars.dataSource_61899 = stateVars.KuikaY_DupontAylikSatisKarsilastirma ?? this.state.KuikaY_DupontAylikSatisKarsilastirma;
			ReactSystemFunctions.setValueOf(this, "dupontbasedreporting_736836_toString", ReactSystemFunctions.value(this, "dupontbasedreporting_70669_value", "value"), "value");

			ReactSystemFunctions.setValueOf(this, "dupontbasedreporting_291136_toString", ReactSystemFunctions.value(this, "dupontbasedreporting_421729_value", "value"), "value");

			
			stateVars.dataSource_198551 = stateVars.KuikaY_DupontAylikSatisKarsilastirma ?? this.state.KuikaY_DupontAylikSatisKarsilastirma;
			
			
			stateVars.isComp414230Visible = ((ReactSystemFunctions.isGreaterOrEqual(ReactSystemFunctions.value(this, "dupontbasedreporting_198551_value", "agustosAdetDegisim"), ReactSystemFunctions.convertToTypeByName("0", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp387172Visible = ((ReactSystemFunctions.isLessThan(ReactSystemFunctions.value(this, "dupontbasedreporting_198551_value", "agustosAdetDegisim"), ReactSystemFunctions.convertToTypeByName("0", "string"))) === true ? "visible" : "hidden")
			
			stateVars.dataSource_376833 = stateVars.KuikaY_DupontAylikSatisKarsilastirma ?? this.state.KuikaY_DupontAylikSatisKarsilastirma;
			ReactSystemFunctions.setValueOf(this, "dupontbasedreporting_309942_toString", ReactSystemFunctions.value(this, "dupontbasedreporting_70669_value", "value"), "value");

			ReactSystemFunctions.setValueOf(this, "dupontbasedreporting_27886_toString", ReactSystemFunctions.value(this, "dupontbasedreporting_421729_value", "value"), "value");

			
			stateVars.dataSource_645134 = stateVars.KuikaY_DupontAylikSatisKarsilastirma ?? this.state.KuikaY_DupontAylikSatisKarsilastirma;
			
			
			stateVars.isComp785001Visible = ((ReactSystemFunctions.isGreaterOrEqual(ReactSystemFunctions.value(this, "dupontbasedreporting_645134_value", "eylulAdetDegisim"), ReactSystemFunctions.convertToTypeByName("0", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp535336Visible = ((ReactSystemFunctions.isLessThan(ReactSystemFunctions.value(this, "dupontbasedreporting_645134_value", "eylulAdetDegisim"), ReactSystemFunctions.convertToTypeByName("0", "string"))) === true ? "visible" : "hidden")
			
			stateVars.dataSource_442224 = stateVars.KuikaY_DupontAylikSatisKarsilastirma ?? this.state.KuikaY_DupontAylikSatisKarsilastirma;
			ReactSystemFunctions.setValueOf(this, "dupontbasedreporting_960211_toString", ReactSystemFunctions.value(this, "dupontbasedreporting_70669_value", "value"), "value");

			ReactSystemFunctions.setValueOf(this, "dupontbasedreporting_799877_toString", ReactSystemFunctions.value(this, "dupontbasedreporting_421729_value", "value"), "value");

			
			stateVars.dataSource_10624 = stateVars.KuikaY_DupontAylikSatisKarsilastirma ?? this.state.KuikaY_DupontAylikSatisKarsilastirma;
			
			
			stateVars.isComp711961Visible = ((ReactSystemFunctions.isGreaterOrEqual(ReactSystemFunctions.value(this, "dupontbasedreporting_10624_value", "ekimAdetDegisim"), ReactSystemFunctions.convertToTypeByName("0", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp921931Visible = ((ReactSystemFunctions.isLessThan(ReactSystemFunctions.value(this, "dupontbasedreporting_10624_value", "ekimAdetDegisim"), ReactSystemFunctions.convertToTypeByName("0", "string"))) === true ? "visible" : "hidden")
			
			stateVars.dataSource_410450 = stateVars.KuikaY_DupontAylikSatisKarsilastirma ?? this.state.KuikaY_DupontAylikSatisKarsilastirma;
			ReactSystemFunctions.setValueOf(this, "dupontbasedreporting_991258_toString", ReactSystemFunctions.value(this, "dupontbasedreporting_70669_value", "value"), "value");

			ReactSystemFunctions.setValueOf(this, "dupontbasedreporting_55219_toString", ReactSystemFunctions.value(this, "dupontbasedreporting_421729_value", "value"), "value");

			
			stateVars.dataSource_774686 = stateVars.KuikaY_DupontAylikSatisKarsilastirma ?? this.state.KuikaY_DupontAylikSatisKarsilastirma;
			
			
			stateVars.isComp80876Visible = ((ReactSystemFunctions.isGreaterOrEqual(ReactSystemFunctions.value(this, "dupontbasedreporting_774686_value", "kasimAdetDegisim"), ReactSystemFunctions.convertToTypeByName("0", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp424357Visible = ((ReactSystemFunctions.isLessThan(ReactSystemFunctions.value(this, "dupontbasedreporting_774686_value", "kasimAdetDegisim"), ReactSystemFunctions.convertToTypeByName("0", "string"))) === true ? "visible" : "hidden")
			
			stateVars.dataSource_179721 = stateVars.KuikaY_DupontAylikSatisKarsilastirma ?? this.state.KuikaY_DupontAylikSatisKarsilastirma;
			ReactSystemFunctions.setValueOf(this, "dupontbasedreporting_965202_toString", ReactSystemFunctions.value(this, "dupontbasedreporting_70669_value", "value"), "value");

			ReactSystemFunctions.setValueOf(this, "dupontbasedreporting_369145_toString", ReactSystemFunctions.value(this, "dupontbasedreporting_421729_value", "value"), "value");

			
			stateVars.dataSource_754648 = stateVars.KuikaY_DupontAylikSatisKarsilastirma ?? this.state.KuikaY_DupontAylikSatisKarsilastirma;
			
			
			stateVars.isComp667218Visible = ((ReactSystemFunctions.isGreaterOrEqual(ReactSystemFunctions.value(this, "dupontbasedreporting_754648_value", "aralikAdetDegisim"), ReactSystemFunctions.convertToTypeByName("0", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp878906Visible = ((ReactSystemFunctions.isLessThan(ReactSystemFunctions.value(this, "dupontbasedreporting_754648_value", "aralikAdetDegisim"), ReactSystemFunctions.convertToTypeByName("0", "string"))) === true ? "visible" : "hidden")
			
			stateVars.dataSource_419800 = stateVars.KuikaY_DupontAylikSatisKarsilastirma ?? this.state.KuikaY_DupontAylikSatisKarsilastirma;

	this.props.form?.setFieldsValue(formVars);
	this.setState(stateVars);
	KuikaAppManager.hideSpinner(this);

            this.setPageInitLoaded(true);
            return isErrorOccurred;
        }




		DupontBasedReportingComponent_890243_onClick = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
KuikaAppManager.showSpinner(this);

const __currentPath = (window.location.hash ? window.location.hash.replace(/^#/, '').split('?')[0] : window.location.pathname.split('?')[0]).toLowerCase();
if (__currentPath !== "/rolexbasedreporting") {
  this.context.setMasterPageInitLoaded(false);
  this.context.setMasterPageRecurringLoaded(false);
  this.context.setShouldTriggerPageInit(true);
}
					KuikaAppManager.prepareForNavigation();

				stateVars.NAVIGATE = await ReactSystemFunctions.navigate(this, undefined, "DupontBasedReporting", "RolexBasedReporting", "", "currentPage", null, null, null, null, null, null, true, false);

		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

            
            return isErrorOccurred;
        }


		DupontBasedReportingComponent_913849_onClick = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
KuikaAppManager.showSpinner(this);

const __currentPath = (window.location.hash ? window.location.hash.replace(/^#/, '').split('?')[0] : window.location.pathname.split('?')[0]).toLowerCase();
if (__currentPath !== "/tudorbasedreporting") {
  this.context.setMasterPageInitLoaded(false);
  this.context.setMasterPageRecurringLoaded(false);
  this.context.setShouldTriggerPageInit(true);
}
					KuikaAppManager.prepareForNavigation();

				stateVars.NAVIGATE = await ReactSystemFunctions.navigate(this, undefined, "DupontBasedReporting", "TudorBasedReporting", "", "currentPage", null, null, null, null, null, null, true, false);

		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

            
            return isErrorOccurred;
        }


		DupontBasedReportingComponent_42755_onClick = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
KuikaAppManager.showSpinner(this);

const __currentPath = (window.location.hash ? window.location.hash.replace(/^#/, '').split('?')[0] : window.location.pathname.split('?')[0]).toLowerCase();
if (__currentPath !== "/montblancbasedreporting") {
  this.context.setMasterPageInitLoaded(false);
  this.context.setMasterPageRecurringLoaded(false);
  this.context.setShouldTriggerPageInit(true);
}
					KuikaAppManager.prepareForNavigation();

				stateVars.NAVIGATE = await ReactSystemFunctions.navigate(this, undefined, "DupontBasedReporting", "MontBlancBasedReporting", "", "currentPage", null, null, null, null, null, null, true, false);

		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

            
            return isErrorOccurred;
        }


		DupontBasedReportingComponent_98494_onChange = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
KuikaAppManager.showSpinner(this);

				ReactSystemFunctions.setValueOf(this, "dupontbasedreporting_529751_toString", ReactSystemFunctions.value(this, "dupontbasedreporting_98494_value", "value"), "value");


		this.props.form?.setFieldsValue(formVars);
		
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.DupontBasedReportingComponent_98494_onChange1_();
                  resolve();
                });
          })

            
            return isErrorOccurred;
        }
    DupontBasedReportingComponent_98494_onChange1_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
		KuikaAppManager.increaseServerRequestCount();

        let localVar = {
				Marka_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.convertToTypeByName("Dupont", "string"), "string"),
				UrunGrubu_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "dupontbasedreporting_706925_value", "value", "KuikaY_GetProductGroupsByBrand", "productGroup", "productGroup")), "string"),
				Year_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "dupontbasedreporting_98494_value", "value", "", "", "")), "number")
        }

		
        if (true) {
        KuikaAppManager.showSpinner(this);
        }
        let result = await KuikaAppManager.ApiRequest(this, "DupontBasedReporting/DupontBasedReportingComponent_98494_onChange1_", localVar)
        if (!KMainFunctions.IsResStatus2XX(result)) return true;

			stateVars.Kuika_ReportProductSales = result?.data.kuika_ReportProductSales;
			formVars.dupontbasedreporting_142273_value = ReactSystemFunctions.toString(this, (stateVars.Kuika_ReportProductSales !== undefined ? (stateVars.Kuika_ReportProductSales?.length > 0 ? stateVars.Kuika_ReportProductSales[0].toplamSatisAdedi : null) : (this.state.Kuika_ReportProductSales?.length > 0 ? this.state.Kuika_ReportProductSales[0].toplamSatisAdedi : null)));
			formVars.dupontbasedreporting_862873_value = ReactSystemFunctions.toString(this, (stateVars.Kuika_ReportProductSales !== undefined ? (stateVars.Kuika_ReportProductSales?.length > 0 ? stateVars.Kuika_ReportProductSales[0].bulundugumuzAySatisAdedi : null) : (this.state.Kuika_ReportProductSales?.length > 0 ? this.state.Kuika_ReportProductSales[0].bulundugumuzAySatisAdedi : null)));
			formVars.dupontbasedreporting_442377_value = ReactSystemFunctions.toString(this, (stateVars.Kuika_ReportProductSales !== undefined ? (stateVars.Kuika_ReportProductSales?.length > 0 ? stateVars.Kuika_ReportProductSales[0].gecenYilaGoreArtisYuzde : null) : (this.state.Kuika_ReportProductSales?.length > 0 ? this.state.Kuika_ReportProductSales[0].gecenYilaGoreArtisYuzde : null)));
			formVars.dupontbasedreporting_49365_value = ReactSystemFunctions.toString(this, (stateVars.Kuika_ReportProductSales !== undefined ? (stateVars.Kuika_ReportProductSales?.length > 0 ? stateVars.Kuika_ReportProductSales[0].enGucluMagazaDesc : null) : (this.state.Kuika_ReportProductSales?.length > 0 ? this.state.Kuika_ReportProductSales[0].enGucluMagazaDesc : null)));
			formVars.dupontbasedreporting_689773_value = ReactSystemFunctions.toString(this, (stateVars.Kuika_ReportProductSales !== undefined ? (stateVars.Kuika_ReportProductSales?.length > 0 ? stateVars.Kuika_ReportProductSales[0].enGucluMagazaCiro : null) : (this.state.Kuika_ReportProductSales?.length > 0 ? this.state.Kuika_ReportProductSales[0].enGucluMagazaCiro : null)));
			formVars.dupontbasedreporting_662229_value = ReactSystemFunctions.toString(this, (stateVars.Kuika_ReportProductSales !== undefined ? (stateVars.Kuika_ReportProductSales?.length > 0 ? stateVars.Kuika_ReportProductSales[0].enCokSatanFamily : null) : (this.state.Kuika_ReportProductSales?.length > 0 ? this.state.Kuika_ReportProductSales[0].enCokSatanFamily : null)));
			formVars.dupontbasedreporting_825140_value = ReactSystemFunctions.toString(this, (stateVars.Kuika_ReportProductSales !== undefined ? (stateVars.Kuika_ReportProductSales?.length > 0 ? stateVars.Kuika_ReportProductSales[0].enCokSatanFamilyAdet : null) : (this.state.Kuika_ReportProductSales?.length > 0 ? this.state.Kuika_ReportProductSales[0].enCokSatanFamilyAdet : null)));
			formVars.dupontbasedreporting_51555_value = ReactSystemFunctions.toString(this, (stateVars.Kuika_ReportProductSales !== undefined ? (stateVars.Kuika_ReportProductSales?.length > 0 ? stateVars.Kuika_ReportProductSales[0].enCokSatanMaterial : null) : (this.state.Kuika_ReportProductSales?.length > 0 ? this.state.Kuika_ReportProductSales[0].enCokSatanMaterial : null)));
			formVars.dupontbasedreporting_816749_value = ReactSystemFunctions.toString(this, (stateVars.Kuika_ReportProductSales !== undefined ? (stateVars.Kuika_ReportProductSales?.length > 0 ? stateVars.Kuika_ReportProductSales[0].enCokSatanMaterialCiro : null) : (this.state.Kuika_ReportProductSales?.length > 0 ? this.state.Kuika_ReportProductSales[0].enCokSatanMaterialCiro : null)));
			this.props.form?.setFieldsValue(formVars);
			
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.DupontBasedReportingComponent_98494_onChange2_();
                  resolve();
                });
          })



        
        KuikaAppManager.hideSpinner(this);
        return isErrorOccurred;
    }
		DupontBasedReportingComponent_98494_onChange2_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }

				formVars.dupontbasedreporting_142273_value = ReactSystemFunctions.toString(this, (stateVars.Kuika_ReportProductSales !== undefined ? (stateVars.Kuika_ReportProductSales?.length > 0 ? stateVars.Kuika_ReportProductSales[0].toplamSatisAdedi : null) : (this.state.Kuika_ReportProductSales?.length > 0 ? this.state.Kuika_ReportProductSales[0].toplamSatisAdedi : null)));

				formVars.dupontbasedreporting_862873_value = ReactSystemFunctions.toString(this, (stateVars.Kuika_ReportProductSales !== undefined ? (stateVars.Kuika_ReportProductSales?.length > 0 ? stateVars.Kuika_ReportProductSales[0].bulundugumuzAySatisAdedi : null) : (this.state.Kuika_ReportProductSales?.length > 0 ? this.state.Kuika_ReportProductSales[0].bulundugumuzAySatisAdedi : null)));

				formVars.dupontbasedreporting_442377_value = ReactSystemFunctions.toString(this, (stateVars.Kuika_ReportProductSales !== undefined ? (stateVars.Kuika_ReportProductSales?.length > 0 ? stateVars.Kuika_ReportProductSales[0].gecenYilaGoreArtisYuzde : null) : (this.state.Kuika_ReportProductSales?.length > 0 ? this.state.Kuika_ReportProductSales[0].gecenYilaGoreArtisYuzde : null)));

				formVars.dupontbasedreporting_49365_value = ReactSystemFunctions.toString(this, (stateVars.Kuika_ReportProductSales !== undefined ? (stateVars.Kuika_ReportProductSales?.length > 0 ? stateVars.Kuika_ReportProductSales[0].enGucluMagazaDesc : null) : (this.state.Kuika_ReportProductSales?.length > 0 ? this.state.Kuika_ReportProductSales[0].enGucluMagazaDesc : null)));

				formVars.dupontbasedreporting_689773_value = ReactSystemFunctions.toString(this, (stateVars.Kuika_ReportProductSales !== undefined ? (stateVars.Kuika_ReportProductSales?.length > 0 ? stateVars.Kuika_ReportProductSales[0].enGucluMagazaCiro : null) : (this.state.Kuika_ReportProductSales?.length > 0 ? this.state.Kuika_ReportProductSales[0].enGucluMagazaCiro : null)));

				formVars.dupontbasedreporting_662229_value = ReactSystemFunctions.toString(this, (stateVars.Kuika_ReportProductSales !== undefined ? (stateVars.Kuika_ReportProductSales?.length > 0 ? stateVars.Kuika_ReportProductSales[0].enCokSatanFamily : null) : (this.state.Kuika_ReportProductSales?.length > 0 ? this.state.Kuika_ReportProductSales[0].enCokSatanFamily : null)));

				formVars.dupontbasedreporting_825140_value = ReactSystemFunctions.toString(this, (stateVars.Kuika_ReportProductSales !== undefined ? (stateVars.Kuika_ReportProductSales?.length > 0 ? stateVars.Kuika_ReportProductSales[0].enCokSatanFamilyAdet : null) : (this.state.Kuika_ReportProductSales?.length > 0 ? this.state.Kuika_ReportProductSales[0].enCokSatanFamilyAdet : null)));

				formVars.dupontbasedreporting_51555_value = ReactSystemFunctions.toString(this, (stateVars.Kuika_ReportProductSales !== undefined ? (stateVars.Kuika_ReportProductSales?.length > 0 ? stateVars.Kuika_ReportProductSales[0].enCokSatanMaterial : null) : (this.state.Kuika_ReportProductSales?.length > 0 ? this.state.Kuika_ReportProductSales[0].enCokSatanMaterial : null)));

				formVars.dupontbasedreporting_816749_value = ReactSystemFunctions.toString(this, (stateVars.Kuika_ReportProductSales !== undefined ? (stateVars.Kuika_ReportProductSales?.length > 0 ? stateVars.Kuika_ReportProductSales[0].enCokSatanMaterialCiro : null) : (this.state.Kuika_ReportProductSales?.length > 0 ? this.state.Kuika_ReportProductSales[0].enCokSatanMaterialCiro : null)));


		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

            
            return isErrorOccurred;
        }





    DupontBasedReportingComponent_706925_onChange = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
		KuikaAppManager.increaseServerRequestCount();

        let localVar = {
				Marka_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.convertToTypeByName("Dupont", "string"), "string"),
				UrunGrubu_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "dupontbasedreporting_706925_value", "value", "KuikaY_GetProductGroupsByBrand", "productGroup", "productGroup")), "string"),
				Year_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "dupontbasedreporting_98494_value", "value", "", "", "")), "number")
        }

		KuikaAppManager.showSpinner(this);
		
        if (true) {
        KuikaAppManager.showSpinner(this);
        }
        let result = await KuikaAppManager.ApiRequest(this, "DupontBasedReporting/DupontBasedReportingComponent_706925_onChange", localVar)
        if (!KMainFunctions.IsResStatus2XX(result)) return true;

			stateVars.Kuika_ReportProductSales = result?.data.kuika_ReportProductSales;
			formVars.dupontbasedreporting_142273_value = ReactSystemFunctions.toString(this, (stateVars.Kuika_ReportProductSales !== undefined ? (stateVars.Kuika_ReportProductSales?.length > 0 ? stateVars.Kuika_ReportProductSales[0].toplamSatisAdedi : null) : (this.state.Kuika_ReportProductSales?.length > 0 ? this.state.Kuika_ReportProductSales[0].toplamSatisAdedi : null)));
			formVars.dupontbasedreporting_862873_value = ReactSystemFunctions.toString(this, (stateVars.Kuika_ReportProductSales !== undefined ? (stateVars.Kuika_ReportProductSales?.length > 0 ? stateVars.Kuika_ReportProductSales[0].bulundugumuzAySatisAdedi : null) : (this.state.Kuika_ReportProductSales?.length > 0 ? this.state.Kuika_ReportProductSales[0].bulundugumuzAySatisAdedi : null)));
			formVars.dupontbasedreporting_442377_value = ReactSystemFunctions.toString(this, (stateVars.Kuika_ReportProductSales !== undefined ? (stateVars.Kuika_ReportProductSales?.length > 0 ? stateVars.Kuika_ReportProductSales[0].gecenYilaGoreArtisYuzde : null) : (this.state.Kuika_ReportProductSales?.length > 0 ? this.state.Kuika_ReportProductSales[0].gecenYilaGoreArtisYuzde : null)));
			formVars.dupontbasedreporting_49365_value = ReactSystemFunctions.toString(this, (stateVars.Kuika_ReportProductSales !== undefined ? (stateVars.Kuika_ReportProductSales?.length > 0 ? stateVars.Kuika_ReportProductSales[0].enGucluMagazaDesc : null) : (this.state.Kuika_ReportProductSales?.length > 0 ? this.state.Kuika_ReportProductSales[0].enGucluMagazaDesc : null)));
			formVars.dupontbasedreporting_689773_value = ReactSystemFunctions.toString(this, (stateVars.Kuika_ReportProductSales !== undefined ? (stateVars.Kuika_ReportProductSales?.length > 0 ? stateVars.Kuika_ReportProductSales[0].enGucluMagazaCiro : null) : (this.state.Kuika_ReportProductSales?.length > 0 ? this.state.Kuika_ReportProductSales[0].enGucluMagazaCiro : null)));
			formVars.dupontbasedreporting_662229_value = ReactSystemFunctions.toString(this, (stateVars.Kuika_ReportProductSales !== undefined ? (stateVars.Kuika_ReportProductSales?.length > 0 ? stateVars.Kuika_ReportProductSales[0].enCokSatanFamily : null) : (this.state.Kuika_ReportProductSales?.length > 0 ? this.state.Kuika_ReportProductSales[0].enCokSatanFamily : null)));
			formVars.dupontbasedreporting_825140_value = ReactSystemFunctions.toString(this, (stateVars.Kuika_ReportProductSales !== undefined ? (stateVars.Kuika_ReportProductSales?.length > 0 ? stateVars.Kuika_ReportProductSales[0].enCokSatanFamilyAdet : null) : (this.state.Kuika_ReportProductSales?.length > 0 ? this.state.Kuika_ReportProductSales[0].enCokSatanFamilyAdet : null)));
			formVars.dupontbasedreporting_51555_value = ReactSystemFunctions.toString(this, (stateVars.Kuika_ReportProductSales !== undefined ? (stateVars.Kuika_ReportProductSales?.length > 0 ? stateVars.Kuika_ReportProductSales[0].enCokSatanMaterial : null) : (this.state.Kuika_ReportProductSales?.length > 0 ? this.state.Kuika_ReportProductSales[0].enCokSatanMaterial : null)));
			formVars.dupontbasedreporting_816749_value = ReactSystemFunctions.toString(this, (stateVars.Kuika_ReportProductSales !== undefined ? (stateVars.Kuika_ReportProductSales?.length > 0 ? stateVars.Kuika_ReportProductSales[0].enCokSatanMaterialCiro : null) : (this.state.Kuika_ReportProductSales?.length > 0 ? this.state.Kuika_ReportProductSales[0].enCokSatanMaterialCiro : null)));
			this.props.form?.setFieldsValue(formVars);
			
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.DupontBasedReportingComponent_706925_onChange1_();
                  resolve();
                });
          })



        
        KuikaAppManager.hideSpinner(this);
        return isErrorOccurred;
    }
		DupontBasedReportingComponent_706925_onChange1_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }

				formVars.dupontbasedreporting_142273_value = ReactSystemFunctions.toString(this, (stateVars.Kuika_ReportProductSales !== undefined ? (stateVars.Kuika_ReportProductSales?.length > 0 ? stateVars.Kuika_ReportProductSales[0].toplamSatisAdedi : null) : (this.state.Kuika_ReportProductSales?.length > 0 ? this.state.Kuika_ReportProductSales[0].toplamSatisAdedi : null)));

				formVars.dupontbasedreporting_862873_value = ReactSystemFunctions.toString(this, (stateVars.Kuika_ReportProductSales !== undefined ? (stateVars.Kuika_ReportProductSales?.length > 0 ? stateVars.Kuika_ReportProductSales[0].bulundugumuzAySatisAdedi : null) : (this.state.Kuika_ReportProductSales?.length > 0 ? this.state.Kuika_ReportProductSales[0].bulundugumuzAySatisAdedi : null)));

				formVars.dupontbasedreporting_442377_value = ReactSystemFunctions.toString(this, (stateVars.Kuika_ReportProductSales !== undefined ? (stateVars.Kuika_ReportProductSales?.length > 0 ? stateVars.Kuika_ReportProductSales[0].gecenYilaGoreArtisYuzde : null) : (this.state.Kuika_ReportProductSales?.length > 0 ? this.state.Kuika_ReportProductSales[0].gecenYilaGoreArtisYuzde : null)));

				formVars.dupontbasedreporting_49365_value = ReactSystemFunctions.toString(this, (stateVars.Kuika_ReportProductSales !== undefined ? (stateVars.Kuika_ReportProductSales?.length > 0 ? stateVars.Kuika_ReportProductSales[0].enGucluMagazaDesc : null) : (this.state.Kuika_ReportProductSales?.length > 0 ? this.state.Kuika_ReportProductSales[0].enGucluMagazaDesc : null)));

				formVars.dupontbasedreporting_689773_value = ReactSystemFunctions.toString(this, (stateVars.Kuika_ReportProductSales !== undefined ? (stateVars.Kuika_ReportProductSales?.length > 0 ? stateVars.Kuika_ReportProductSales[0].enGucluMagazaCiro : null) : (this.state.Kuika_ReportProductSales?.length > 0 ? this.state.Kuika_ReportProductSales[0].enGucluMagazaCiro : null)));

				formVars.dupontbasedreporting_662229_value = ReactSystemFunctions.toString(this, (stateVars.Kuika_ReportProductSales !== undefined ? (stateVars.Kuika_ReportProductSales?.length > 0 ? stateVars.Kuika_ReportProductSales[0].enCokSatanFamily : null) : (this.state.Kuika_ReportProductSales?.length > 0 ? this.state.Kuika_ReportProductSales[0].enCokSatanFamily : null)));

				formVars.dupontbasedreporting_825140_value = ReactSystemFunctions.toString(this, (stateVars.Kuika_ReportProductSales !== undefined ? (stateVars.Kuika_ReportProductSales?.length > 0 ? stateVars.Kuika_ReportProductSales[0].enCokSatanFamilyAdet : null) : (this.state.Kuika_ReportProductSales?.length > 0 ? this.state.Kuika_ReportProductSales[0].enCokSatanFamilyAdet : null)));

				formVars.dupontbasedreporting_51555_value = ReactSystemFunctions.toString(this, (stateVars.Kuika_ReportProductSales !== undefined ? (stateVars.Kuika_ReportProductSales?.length > 0 ? stateVars.Kuika_ReportProductSales[0].enCokSatanMaterial : null) : (this.state.Kuika_ReportProductSales?.length > 0 ? this.state.Kuika_ReportProductSales[0].enCokSatanMaterial : null)));

				formVars.dupontbasedreporting_816749_value = ReactSystemFunctions.toString(this, (stateVars.Kuika_ReportProductSales !== undefined ? (stateVars.Kuika_ReportProductSales?.length > 0 ? stateVars.Kuika_ReportProductSales[0].enCokSatanMaterialCiro : null) : (this.state.Kuika_ReportProductSales?.length > 0 ? this.state.Kuika_ReportProductSales[0].enCokSatanMaterialCiro : null)));


		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

            
            return isErrorOccurred;
        }




		DupontBasedReportingComponent_281612_onChange = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
KuikaAppManager.showSpinner(this);

				ReactSystemFunctions.setValueOf(this, "dupontbasedreporting_928162_toString", ReactSystemFunctions.value(this, "dupontbasedreporting_281612_value", "value"), "value");


		this.props.form?.setFieldsValue(formVars);
		
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.DupontBasedReportingComponent_281612_onChange1_();
                  resolve();
                });
          })

            
            return isErrorOccurred;
        }
    DupontBasedReportingComponent_281612_onChange1_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
		KuikaAppManager.increaseServerRequestCount();

        let localVar = {
				Brand_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.convertToTypeByName("Dupont", "string"), "string"),
				ProductGroup_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "dupontbasedreporting_847069_value", "value", "KuikaY_GetProductGroupsByBrand", "productGroup", "productGroup")), "string"),
				Year_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "dupontbasedreporting_281612_value", "value", "", "", "")), "number")
        }

		
        if (true) {
        KuikaAppManager.showSpinner(this);
        }
        let result = await KuikaAppManager.ApiRequest(this, "DupontBasedReporting/DupontBasedReportingComponent_281612_onChange1_", localVar)
        if (!KMainFunctions.IsResStatus2XX(result)) return true;

			stateVars.KuikaY_MonthlyStoreSalesReport = result?.data.kuikaY_MonthlyStoreSalesReport;
			
			this.props.form?.setFieldsValue(formVars);
			
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.DupontBasedReportingComponent_281612_onChange2_();
                  resolve();
                });
          })



        
        KuikaAppManager.hideSpinner(this);
        return isErrorOccurred;
    }
		DupontBasedReportingComponent_281612_onChange2_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }

				
				stateVars.dataSource_33296 = stateVars.KuikaY_MonthlyStoreSalesReport ?? this.state.KuikaY_MonthlyStoreSalesReport;

		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

            
            return isErrorOccurred;
        }





    DupontBasedReportingComponent_847069_onChange = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
		KuikaAppManager.increaseServerRequestCount();

        let localVar = {
				Brand_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.convertToTypeByName("Dupont", "string"), "string"),
				ProductGroup_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "dupontbasedreporting_847069_value", "value", "KuikaY_GetProductGroupsByBrand", "productGroup", "productGroup")), "string"),
				Year_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "dupontbasedreporting_281612_value", "value", "", "", "")), "number")
        }

		KuikaAppManager.showSpinner(this);
		
        if (true) {
        KuikaAppManager.showSpinner(this);
        }
        let result = await KuikaAppManager.ApiRequest(this, "DupontBasedReporting/DupontBasedReportingComponent_847069_onChange", localVar)
        if (!KMainFunctions.IsResStatus2XX(result)) return true;

			stateVars.KuikaY_MonthlyStoreSalesReport = result?.data.kuikaY_MonthlyStoreSalesReport;
			
			this.props.form?.setFieldsValue(formVars);
			
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.DupontBasedReportingComponent_847069_onChange1_();
                  resolve();
                });
          })



        
        KuikaAppManager.hideSpinner(this);
        return isErrorOccurred;
    }
		DupontBasedReportingComponent_847069_onChange1_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }

				
				stateVars.dataSource_33296 = stateVars.KuikaY_MonthlyStoreSalesReport ?? this.state.KuikaY_MonthlyStoreSalesReport;

		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

            
            return isErrorOccurred;
        }




    DupontBasedReportingComponent_703687_onClick = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
		KuikaAppManager.increaseServerRequestCount();

        let localVar = {
				value_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, this.state.KuikaY_MonthlyStoreSalesReport), "any"),
				header_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.convertToTypeByName("Dupont Mağaza Bazlı Aylık Satış Raporu", "string"), "string"),
				footer_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "dupontbasedreporting_281612_value", "value", "", "", "")), "string"),
				columns_0: ReactSystemFunctions.convertToTypeByName("", "string")
        }

		KuikaAppManager.showSpinner(this);
		
        if (true) {
        KuikaAppManager.showSpinner(this);
        }
        let result = await KuikaAppManager.ApiRequest(this, "DupontBasedReporting/DupontBasedReportingComponent_703687_onClick", localVar)
        if (!KMainFunctions.IsResStatus2XX(result)) return true;

			stateVars.ExportExcel = result?.data.exportExcel;
			ReactSystemFunctions.downloadFile(result?.data?.exportExcel);
			this.props.form?.setFieldsValue(formVars);
			this.setState(stateVars);
			KuikaAppManager.hideSpinner(this);



        this.setPageInitLoaded(true);
        KuikaAppManager.hideSpinner(this);
        return isErrorOccurred;
    }



    DupontBasedReportingComponent_883454_onClick = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
		KuikaAppManager.increaseServerRequestCount();

        let localVar = {
				Year1_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "dupontbasedreporting_70669_value", "value", "", "", "")), "number"),
				Year2_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "dupontbasedreporting_421729_value", "value", "", "", "")), "number")
        }

		KuikaAppManager.showSpinner(this);
		
        if (true) {
        KuikaAppManager.showSpinner(this);
        }
        let result = await KuikaAppManager.ApiRequest(this, "DupontBasedReporting/DupontBasedReportingComponent_883454_onClick", localVar)
        if (!KMainFunctions.IsResStatus2XX(result)) return true;

			stateVars.KuikaY_DupontAylikSatisKarsilastirma = result?.data.kuikaY_DupontAylikSatisKarsilastirma;
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			this.props.form?.setFieldsValue(formVars);
			
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.DupontBasedReportingComponent_883454_onClick1_();
                  resolve();
                });
          })



        
        KuikaAppManager.hideSpinner(this);
        return isErrorOccurred;
    }
		DupontBasedReportingComponent_883454_onClick1_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }

				
				stateVars.dataSource_833904 = stateVars.KuikaY_DupontAylikSatisKarsilastirma ?? this.state.KuikaY_DupontAylikSatisKarsilastirma;
				
				stateVars.dataSource_834767 = stateVars.KuikaY_DupontAylikSatisKarsilastirma ?? this.state.KuikaY_DupontAylikSatisKarsilastirma;
				
				stateVars.dataSource_109751 = stateVars.KuikaY_DupontAylikSatisKarsilastirma ?? this.state.KuikaY_DupontAylikSatisKarsilastirma;
				
				stateVars.dataSource_693923 = stateVars.KuikaY_DupontAylikSatisKarsilastirma ?? this.state.KuikaY_DupontAylikSatisKarsilastirma;
				
				stateVars.dataSource_165803 = stateVars.KuikaY_DupontAylikSatisKarsilastirma ?? this.state.KuikaY_DupontAylikSatisKarsilastirma;
				
				stateVars.dataSource_632782 = stateVars.KuikaY_DupontAylikSatisKarsilastirma ?? this.state.KuikaY_DupontAylikSatisKarsilastirma;
				
				stateVars.dataSource_888464 = stateVars.KuikaY_DupontAylikSatisKarsilastirma ?? this.state.KuikaY_DupontAylikSatisKarsilastirma;
				
				stateVars.dataSource_522144 = stateVars.KuikaY_DupontAylikSatisKarsilastirma ?? this.state.KuikaY_DupontAylikSatisKarsilastirma;
				
				stateVars.dataSource_554019 = stateVars.KuikaY_DupontAylikSatisKarsilastirma ?? this.state.KuikaY_DupontAylikSatisKarsilastirma;
				
				stateVars.dataSource_237636 = stateVars.KuikaY_DupontAylikSatisKarsilastirma ?? this.state.KuikaY_DupontAylikSatisKarsilastirma;
				
				stateVars.dataSource_487656 = stateVars.KuikaY_DupontAylikSatisKarsilastirma ?? this.state.KuikaY_DupontAylikSatisKarsilastirma;
				
				stateVars.dataSource_510713 = stateVars.KuikaY_DupontAylikSatisKarsilastirma ?? this.state.KuikaY_DupontAylikSatisKarsilastirma;
				
				stateVars.dataSource_804184 = stateVars.KuikaY_DupontAylikSatisKarsilastirma ?? this.state.KuikaY_DupontAylikSatisKarsilastirma;
				
				stateVars.dataSource_61899 = stateVars.KuikaY_DupontAylikSatisKarsilastirma ?? this.state.KuikaY_DupontAylikSatisKarsilastirma;
				
				stateVars.dataSource_198551 = stateVars.KuikaY_DupontAylikSatisKarsilastirma ?? this.state.KuikaY_DupontAylikSatisKarsilastirma;
				
				stateVars.dataSource_376833 = stateVars.KuikaY_DupontAylikSatisKarsilastirma ?? this.state.KuikaY_DupontAylikSatisKarsilastirma;
				
				stateVars.dataSource_645134 = stateVars.KuikaY_DupontAylikSatisKarsilastirma ?? this.state.KuikaY_DupontAylikSatisKarsilastirma;
				
				stateVars.dataSource_442224 = stateVars.KuikaY_DupontAylikSatisKarsilastirma ?? this.state.KuikaY_DupontAylikSatisKarsilastirma;
				
				stateVars.dataSource_10624 = stateVars.KuikaY_DupontAylikSatisKarsilastirma ?? this.state.KuikaY_DupontAylikSatisKarsilastirma;
				
				stateVars.dataSource_410450 = stateVars.KuikaY_DupontAylikSatisKarsilastirma ?? this.state.KuikaY_DupontAylikSatisKarsilastirma;
				
				stateVars.dataSource_774686 = stateVars.KuikaY_DupontAylikSatisKarsilastirma ?? this.state.KuikaY_DupontAylikSatisKarsilastirma;
				
				stateVars.dataSource_179721 = stateVars.KuikaY_DupontAylikSatisKarsilastirma ?? this.state.KuikaY_DupontAylikSatisKarsilastirma;
				
				stateVars.dataSource_754648 = stateVars.KuikaY_DupontAylikSatisKarsilastirma ?? this.state.KuikaY_DupontAylikSatisKarsilastirma;
				
				stateVars.dataSource_419800 = stateVars.KuikaY_DupontAylikSatisKarsilastirma ?? this.state.KuikaY_DupontAylikSatisKarsilastirma;

		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

            
            return isErrorOccurred;
        }




    DupontBasedReportingComponent_16924_onClick = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
		KuikaAppManager.increaseServerRequestCount();

        let localVar = {
				value_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, this.state.KuikaY_DupontAylikSatisKarsilastirma), "any"),
				header_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.convertToTypeByName("Mont Blanc Yıl Karşılaştırmalı Satış Raporu", "string"), "string"),
				footer_0: ReactSystemFunctions.convertToTypeByName("", "string"),
				columns_0: ReactSystemFunctions.convertToTypeByName("", "string")
        }

		KuikaAppManager.showSpinner(this);
		
        if (true) {
        KuikaAppManager.showSpinner(this);
        }
        let result = await KuikaAppManager.ApiRequest(this, "DupontBasedReporting/DupontBasedReportingComponent_16924_onClick", localVar)
        if (!KMainFunctions.IsResStatus2XX(result)) return true;

			stateVars.ExportExcel = result?.data.exportExcel;
			ReactSystemFunctions.downloadFile(result?.data?.exportExcel);
			this.props.form?.setFieldsValue(formVars);
			this.setState(stateVars);
			KuikaAppManager.hideSpinner(this);



        this.setPageInitLoaded(true);
        KuikaAppManager.hideSpinner(this);
        return isErrorOccurred;
    }



    DupontBasedReportingComponent_407747_onClick = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
		KuikaAppManager.increaseServerRequestCount();

        let localVar = {
				value_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, this.state.KuikaY_DupontAylikSatisKarsilastirma), "any"),
				header_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.convertToTypeByName("Karşılaştırmalı Dupont Ocak Ayı Satış Raporu", "string"), "string"),
				footer_0: ReactSystemFunctions.convertToTypeByName("", "string"),
				columns_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.convertToTypeByName("Magaza,OcakAdet2025,OcakAdet2026,OcakAdetDegisim,OcakTL2025,OcakTL2026,OcakTLDegisim,OcakEUR2025,OcakEUR2026", "string"), "string")
        }

		KuikaAppManager.showSpinner(this);
		
        if (true) {
        KuikaAppManager.showSpinner(this);
        }
        let result = await KuikaAppManager.ApiRequest(this, "DupontBasedReporting/DupontBasedReportingComponent_407747_onClick", localVar)
        if (!KMainFunctions.IsResStatus2XX(result)) return true;

			stateVars.ExportExcel = result?.data.exportExcel;
			ReactSystemFunctions.downloadFile(result?.data?.exportExcel);
			this.props.form?.setFieldsValue(formVars);
			this.setState(stateVars);
			KuikaAppManager.hideSpinner(this);



        this.setPageInitLoaded(true);
        KuikaAppManager.hideSpinner(this);
        return isErrorOccurred;
    }



    DupontBasedReportingComponent_164886_onClick = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
		KuikaAppManager.increaseServerRequestCount();

        let localVar = {
				value_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, this.state.KuikaY_DupontAylikSatisKarsilastirma), "any"),
				header_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.convertToTypeByName("Karşılaştırmalı Dupont Şubat Ayı Satış Raporu", "string"), "string"),
				footer_0: ReactSystemFunctions.convertToTypeByName("", "string"),
				columns_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.convertToTypeByName("Magaza,SubatAdet2025,SubatAdet2026,SubatAdetDegisim,SubatTL2025,SubatTL2026,SubatTLDegisim,SubatEUR2025,SubatEUR2026", "string"), "string")
        }

		KuikaAppManager.showSpinner(this);
		
        if (true) {
        KuikaAppManager.showSpinner(this);
        }
        let result = await KuikaAppManager.ApiRequest(this, "DupontBasedReporting/DupontBasedReportingComponent_164886_onClick", localVar)
        if (!KMainFunctions.IsResStatus2XX(result)) return true;

			stateVars.ExportExcel = result?.data.exportExcel;
			ReactSystemFunctions.downloadFile(result?.data?.exportExcel);
			this.props.form?.setFieldsValue(formVars);
			this.setState(stateVars);
			KuikaAppManager.hideSpinner(this);



        this.setPageInitLoaded(true);
        KuikaAppManager.hideSpinner(this);
        return isErrorOccurred;
    }



    DupontBasedReportingComponent_562520_onClick = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
		KuikaAppManager.increaseServerRequestCount();

        let localVar = {
				value_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, this.state.KuikaY_DupontAylikSatisKarsilastirma), "any"),
				header_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.convertToTypeByName("Karşılaştırmalı Dupont Mart Ayı Satış Raporu", "string"), "string"),
				footer_0: ReactSystemFunctions.convertToTypeByName("", "string"),
				columns_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.convertToTypeByName("Magaza,MartAdet2025,MartAdet2026,MartAdetDegisim,MartTL2025,MartTL2026,MartTLDegisim,MartEUR2025,MartEUR2026", "string"), "string")
        }

		KuikaAppManager.showSpinner(this);
		
        if (true) {
        KuikaAppManager.showSpinner(this);
        }
        let result = await KuikaAppManager.ApiRequest(this, "DupontBasedReporting/DupontBasedReportingComponent_562520_onClick", localVar)
        if (!KMainFunctions.IsResStatus2XX(result)) return true;

			stateVars.ExportExcel = result?.data.exportExcel;
			ReactSystemFunctions.downloadFile(result?.data?.exportExcel);
			this.props.form?.setFieldsValue(formVars);
			this.setState(stateVars);
			KuikaAppManager.hideSpinner(this);



        this.setPageInitLoaded(true);
        KuikaAppManager.hideSpinner(this);
        return isErrorOccurred;
    }



    DupontBasedReportingComponent_157880_onClick = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
		KuikaAppManager.increaseServerRequestCount();

        let localVar = {
				value_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, this.state.KuikaY_DupontAylikSatisKarsilastirma), "any"),
				header_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.convertToTypeByName("Karşılaştırmalı Dupont Nisan Ayı Satış Raporu", "string"), "string"),
				footer_0: ReactSystemFunctions.convertToTypeByName("", "string"),
				columns_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.convertToTypeByName("Magaza,NisanAdet2025,NisanAdet2026,NisanAdetDegisim,NisanTL2025,NisanTL2026,NisanTLDegisim,NisanEUR2025,NisanEUR2026", "string"), "string")
        }

		KuikaAppManager.showSpinner(this);
		
        if (true) {
        KuikaAppManager.showSpinner(this);
        }
        let result = await KuikaAppManager.ApiRequest(this, "DupontBasedReporting/DupontBasedReportingComponent_157880_onClick", localVar)
        if (!KMainFunctions.IsResStatus2XX(result)) return true;

			stateVars.ExportExcel = result?.data.exportExcel;
			ReactSystemFunctions.downloadFile(result?.data?.exportExcel);
			this.props.form?.setFieldsValue(formVars);
			this.setState(stateVars);
			KuikaAppManager.hideSpinner(this);



        this.setPageInitLoaded(true);
        KuikaAppManager.hideSpinner(this);
        return isErrorOccurred;
    }



    DupontBasedReportingComponent_470468_onClick = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
		KuikaAppManager.increaseServerRequestCount();

        let localVar = {
				value_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, this.state.KuikaY_DupontAylikSatisKarsilastirma), "any"),
				header_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.convertToTypeByName("Karşılaştırmalı Dupont Mayıs Ayı Satış Raporu", "string"), "string"),
				footer_0: ReactSystemFunctions.convertToTypeByName("", "string"),
				columns_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.convertToTypeByName("Magaza,MayisAdet2025,MayisAdet2026,MayisAdetDegisim,MayisTL2025,MayisTL2026,MayisTLDegisim,MayisEUR2025,MayisEUR2026", "string"), "string")
        }

		KuikaAppManager.showSpinner(this);
		
        if (true) {
        KuikaAppManager.showSpinner(this);
        }
        let result = await KuikaAppManager.ApiRequest(this, "DupontBasedReporting/DupontBasedReportingComponent_470468_onClick", localVar)
        if (!KMainFunctions.IsResStatus2XX(result)) return true;

			stateVars.ExportExcel = result?.data.exportExcel;
			ReactSystemFunctions.downloadFile(result?.data?.exportExcel);
			this.props.form?.setFieldsValue(formVars);
			this.setState(stateVars);
			KuikaAppManager.hideSpinner(this);



        this.setPageInitLoaded(true);
        KuikaAppManager.hideSpinner(this);
        return isErrorOccurred;
    }



    DupontBasedReportingComponent_611497_onClick = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
		KuikaAppManager.increaseServerRequestCount();

        let localVar = {
				value_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, this.state.KuikaY_DupontAylikSatisKarsilastirma), "any"),
				header_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.convertToTypeByName("Karşılaştırmalı Dupont Haziran Ayı Satış Raporu", "string"), "string"),
				footer_0: ReactSystemFunctions.convertToTypeByName("", "string"),
				columns_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.convertToTypeByName("Magaza,HaziranAdet2025,HaziranAdet2026,HaziranAdetDegisim,HaziranTL2025,HaziranTL2026,HaziranTLDegisim,HaziranEUR2025,HaziranEUR2026", "string"), "string")
        }

		KuikaAppManager.showSpinner(this);
		
        if (true) {
        KuikaAppManager.showSpinner(this);
        }
        let result = await KuikaAppManager.ApiRequest(this, "DupontBasedReporting/DupontBasedReportingComponent_611497_onClick", localVar)
        if (!KMainFunctions.IsResStatus2XX(result)) return true;

			stateVars.ExportExcel = result?.data.exportExcel;
			ReactSystemFunctions.downloadFile(result?.data?.exportExcel);
			this.props.form?.setFieldsValue(formVars);
			this.setState(stateVars);
			KuikaAppManager.hideSpinner(this);



        this.setPageInitLoaded(true);
        KuikaAppManager.hideSpinner(this);
        return isErrorOccurred;
    }



    DupontBasedReportingComponent_553256_onClick = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
		KuikaAppManager.increaseServerRequestCount();

        let localVar = {
				value_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, this.state.KuikaY_DupontAylikSatisKarsilastirma), "any"),
				header_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.convertToTypeByName("Karşılaştırmalı Dupont Temmuz Ayı Satış Raporu", "string"), "string"),
				footer_0: ReactSystemFunctions.convertToTypeByName("", "string"),
				columns_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.convertToTypeByName("Magaza,TemmuzAdet2025,TemmuzAdet2026,TemmuzAdetDegisim,TemmuzTL2025,TemmuzTL2026,TemmuzTLDegisim,TemmuzEUR2025,TemmuzEUR2026", "string"), "string")
        }

		KuikaAppManager.showSpinner(this);
		
        if (true) {
        KuikaAppManager.showSpinner(this);
        }
        let result = await KuikaAppManager.ApiRequest(this, "DupontBasedReporting/DupontBasedReportingComponent_553256_onClick", localVar)
        if (!KMainFunctions.IsResStatus2XX(result)) return true;

			stateVars.ExportExcel = result?.data.exportExcel;
			ReactSystemFunctions.downloadFile(result?.data?.exportExcel);
			this.props.form?.setFieldsValue(formVars);
			this.setState(stateVars);
			KuikaAppManager.hideSpinner(this);



        this.setPageInitLoaded(true);
        KuikaAppManager.hideSpinner(this);
        return isErrorOccurred;
    }



    DupontBasedReportingComponent_780563_onClick = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
		KuikaAppManager.increaseServerRequestCount();

        let localVar = {
				value_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, this.state.KuikaY_DupontAylikSatisKarsilastirma), "any"),
				header_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.convertToTypeByName("Karşılaştırmalı Dupont Ağustos Ayı Satış Raporu", "string"), "string"),
				footer_0: ReactSystemFunctions.convertToTypeByName("", "string"),
				columns_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.convertToTypeByName("Magaza,AgustosAdet2025,AgustosAdet2026,AgustosAdetDegisim,AgustosTL2025,AgustosTL2026,AgustosTLDegisim,AgustosEUR2025,AgustosEUR2026", "string"), "string")
        }

		KuikaAppManager.showSpinner(this);
		
        if (true) {
        KuikaAppManager.showSpinner(this);
        }
        let result = await KuikaAppManager.ApiRequest(this, "DupontBasedReporting/DupontBasedReportingComponent_780563_onClick", localVar)
        if (!KMainFunctions.IsResStatus2XX(result)) return true;

			stateVars.ExportExcel = result?.data.exportExcel;
			ReactSystemFunctions.downloadFile(result?.data?.exportExcel);
			this.props.form?.setFieldsValue(formVars);
			this.setState(stateVars);
			KuikaAppManager.hideSpinner(this);



        this.setPageInitLoaded(true);
        KuikaAppManager.hideSpinner(this);
        return isErrorOccurred;
    }



    DupontBasedReportingComponent_699584_onClick = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
		KuikaAppManager.increaseServerRequestCount();

        let localVar = {
				value_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, this.state.KuikaY_DupontAylikSatisKarsilastirma), "any"),
				header_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.convertToTypeByName("Karşılaştırmalı Dupont Eylül Ayı Satış Raporu", "string"), "string"),
				footer_0: ReactSystemFunctions.convertToTypeByName("", "string"),
				columns_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.convertToTypeByName("Magaza,EylulAdet2025,EylulAdet2026,EylulAdetDegisim,EylulTL2025,EylulTL2026,EylulTLDegisim,EylulEUR2025,EylulEUR2026", "string"), "string")
        }

		KuikaAppManager.showSpinner(this);
		
        if (true) {
        KuikaAppManager.showSpinner(this);
        }
        let result = await KuikaAppManager.ApiRequest(this, "DupontBasedReporting/DupontBasedReportingComponent_699584_onClick", localVar)
        if (!KMainFunctions.IsResStatus2XX(result)) return true;

			stateVars.ExportExcel = result?.data.exportExcel;
			ReactSystemFunctions.downloadFile(result?.data?.exportExcel);
			this.props.form?.setFieldsValue(formVars);
			this.setState(stateVars);
			KuikaAppManager.hideSpinner(this);



        this.setPageInitLoaded(true);
        KuikaAppManager.hideSpinner(this);
        return isErrorOccurred;
    }



    DupontBasedReportingComponent_118185_onClick = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
		KuikaAppManager.increaseServerRequestCount();

        let localVar = {
				value_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, this.state.KuikaY_DupontAylikSatisKarsilastirma), "any"),
				header_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.convertToTypeByName("Karşılaştırmalı Dupont Ekim Ayı Satış Raporu", "string"), "string"),
				footer_0: ReactSystemFunctions.convertToTypeByName("", "string"),
				columns_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.convertToTypeByName("Magaza,EkimAdet2025,EkimAdet2026,EkimAdetDegisim,EkimTL2025,EkimTL2026,EkimTLDegisim,EkimEUR2025,EkimEUR2026", "string"), "string")
        }

		KuikaAppManager.showSpinner(this);
		
        if (true) {
        KuikaAppManager.showSpinner(this);
        }
        let result = await KuikaAppManager.ApiRequest(this, "DupontBasedReporting/DupontBasedReportingComponent_118185_onClick", localVar)
        if (!KMainFunctions.IsResStatus2XX(result)) return true;

			stateVars.ExportExcel = result?.data.exportExcel;
			ReactSystemFunctions.downloadFile(result?.data?.exportExcel);
			this.props.form?.setFieldsValue(formVars);
			this.setState(stateVars);
			KuikaAppManager.hideSpinner(this);



        this.setPageInitLoaded(true);
        KuikaAppManager.hideSpinner(this);
        return isErrorOccurred;
    }



    DupontBasedReportingComponent_852168_onClick = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
		KuikaAppManager.increaseServerRequestCount();

        let localVar = {
				value_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, this.state.KuikaY_DupontAylikSatisKarsilastirma), "any"),
				header_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.convertToTypeByName("Karşılaştırmalı Dupont Kasım Ayı Satış Raporu", "string"), "string"),
				footer_0: ReactSystemFunctions.convertToTypeByName("", "string"),
				columns_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.convertToTypeByName("Magaza,KasimAdet2025,KasimAdet2026,KasimAdetDegisim,KasimTL2025,KasimTL2026,KasimTLDegisim,KasimEUR2025,KasimEUR2026", "string"), "string")
        }

		KuikaAppManager.showSpinner(this);
		
        if (true) {
        KuikaAppManager.showSpinner(this);
        }
        let result = await KuikaAppManager.ApiRequest(this, "DupontBasedReporting/DupontBasedReportingComponent_852168_onClick", localVar)
        if (!KMainFunctions.IsResStatus2XX(result)) return true;

			stateVars.ExportExcel = result?.data.exportExcel;
			ReactSystemFunctions.downloadFile(result?.data?.exportExcel);
			this.props.form?.setFieldsValue(formVars);
			this.setState(stateVars);
			KuikaAppManager.hideSpinner(this);



        this.setPageInitLoaded(true);
        KuikaAppManager.hideSpinner(this);
        return isErrorOccurred;
    }



    DupontBasedReportingComponent_386278_onClick = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
		KuikaAppManager.increaseServerRequestCount();

        let localVar = {
				value_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, this.state.KuikaY_DupontAylikSatisKarsilastirma), "any"),
				header_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.convertToTypeByName("Karşılaştırmalı Dupont Aralık Ayı Satış Raporu", "string"), "string"),
				footer_0: ReactSystemFunctions.convertToTypeByName("", "string"),
				columns_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.convertToTypeByName("Magaza", "string"), "string")
        }

		KuikaAppManager.showSpinner(this);
		
        if (true) {
        KuikaAppManager.showSpinner(this);
        }
        let result = await KuikaAppManager.ApiRequest(this, "DupontBasedReporting/DupontBasedReportingComponent_386278_onClick", localVar)
        if (!KMainFunctions.IsResStatus2XX(result)) return true;

			stateVars.ExportExcel = result?.data.exportExcel;
			ReactSystemFunctions.downloadFile(result?.data?.exportExcel);
			this.props.form?.setFieldsValue(formVars);
			this.setState(stateVars);
			KuikaAppManager.hideSpinner(this);



        this.setPageInitLoaded(true);
        KuikaAppManager.hideSpinner(this);
        return isErrorOccurred;
    }



		DupontBasedReportingComponent_70669_onChange = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
KuikaAppManager.showSpinner(this);

				
				ReactSystemFunctions.setValueOf(this, "dupontbasedreporting_965202_toString", ReactSystemFunctions.value(this, "dupontbasedreporting_70669_value", "value"), "value");

				
				ReactSystemFunctions.setValueOf(this, "dupontbasedreporting_991258_toString", ReactSystemFunctions.value(this, "dupontbasedreporting_70669_value", "value"), "value");

				
				ReactSystemFunctions.setValueOf(this, "dupontbasedreporting_960211_toString", ReactSystemFunctions.value(this, "dupontbasedreporting_70669_value", "value"), "value");

				
				ReactSystemFunctions.setValueOf(this, "dupontbasedreporting_309942_toString", ReactSystemFunctions.value(this, "dupontbasedreporting_70669_value", "value"), "value");

				
				ReactSystemFunctions.setValueOf(this, "dupontbasedreporting_736836_toString", ReactSystemFunctions.value(this, "dupontbasedreporting_70669_value", "value"), "value");

				
				ReactSystemFunctions.setValueOf(this, "dupontbasedreporting_428037_toString", ReactSystemFunctions.value(this, "dupontbasedreporting_70669_value", "value"), "value");

				
				ReactSystemFunctions.setValueOf(this, "dupontbasedreporting_561858_toString", ReactSystemFunctions.value(this, "dupontbasedreporting_70669_value", "value"), "value");

				
				ReactSystemFunctions.setValueOf(this, "dupontbasedreporting_505224_toString", ReactSystemFunctions.value(this, "dupontbasedreporting_70669_value", "value"), "value");

				
				ReactSystemFunctions.setValueOf(this, "dupontbasedreporting_730787_toString", ReactSystemFunctions.value(this, "dupontbasedreporting_70669_value", "value"), "value");

				
				ReactSystemFunctions.setValueOf(this, "dupontbasedreporting_800382_toString", ReactSystemFunctions.value(this, "dupontbasedreporting_70669_value", "value"), "value");

				
				ReactSystemFunctions.setValueOf(this, "dupontbasedreporting_409033_toString", ReactSystemFunctions.value(this, "dupontbasedreporting_70669_value", "value"), "value");

				
				ReactSystemFunctions.setValueOf(this, "dupontbasedreporting_764507_toString", ReactSystemFunctions.value(this, "dupontbasedreporting_70669_value", "value"), "value");


		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

            
            return isErrorOccurred;
        }


		DupontBasedReportingComponent_421729_onChange = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
KuikaAppManager.showSpinner(this);

				
				ReactSystemFunctions.setValueOf(this, "dupontbasedreporting_369145_toString", ReactSystemFunctions.value(this, "dupontbasedreporting_421729_value", "value"), "value");

				
				ReactSystemFunctions.setValueOf(this, "dupontbasedreporting_55219_toString", ReactSystemFunctions.value(this, "dupontbasedreporting_421729_value", "value"), "value");

				
				ReactSystemFunctions.setValueOf(this, "dupontbasedreporting_799877_toString", ReactSystemFunctions.value(this, "dupontbasedreporting_421729_value", "value"), "value");

				
				ReactSystemFunctions.setValueOf(this, "dupontbasedreporting_27886_toString", ReactSystemFunctions.value(this, "dupontbasedreporting_421729_value", "value"), "value");

				
				ReactSystemFunctions.setValueOf(this, "dupontbasedreporting_291136_toString", ReactSystemFunctions.value(this, "dupontbasedreporting_421729_value", "value"), "value");

				
				ReactSystemFunctions.setValueOf(this, "dupontbasedreporting_952544_toString", ReactSystemFunctions.value(this, "dupontbasedreporting_421729_value", "value"), "value");

				
				ReactSystemFunctions.setValueOf(this, "dupontbasedreporting_331949_toString", ReactSystemFunctions.value(this, "dupontbasedreporting_421729_value", "value"), "value");

				
				ReactSystemFunctions.setValueOf(this, "dupontbasedreporting_280856_toString", ReactSystemFunctions.value(this, "dupontbasedreporting_421729_value", "value"), "value");

				
				ReactSystemFunctions.setValueOf(this, "dupontbasedreporting_687434_toString", ReactSystemFunctions.value(this, "dupontbasedreporting_421729_value", "value"), "value");

				
				ReactSystemFunctions.setValueOf(this, "dupontbasedreporting_586949_toString", ReactSystemFunctions.value(this, "dupontbasedreporting_421729_value", "value"), "value");

				
				ReactSystemFunctions.setValueOf(this, "dupontbasedreporting_417597_toString", ReactSystemFunctions.value(this, "dupontbasedreporting_421729_value", "value"), "value");

				
				ReactSystemFunctions.setValueOf(this, "dupontbasedreporting_64123_toString", ReactSystemFunctions.value(this, "dupontbasedreporting_421729_value", "value"), "value");


		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

            
            return isErrorOccurred;
        }




    async callCallbackFunction(diId: number, isFromMaster: boolean = false) {
        let isErrorOccurred = false;
		let pageInitCallerNavDiIDs = [, , ] as number[];
		if (isFromMaster || pageInitCallerNavDiIDs.indexOf(diId) > -1) {
			await this.DupontBasedReportingPageInit();
		}

    }


}
