import React from "react";
import Axios, { AxiosResponse } from "axios";
import { KuikaAppManager } from "../../shared/utilty/kuika-app-manager";
import { ReactSystemFunctions } from "../../shared/utilty/react-system-functions";
import { KNavigator } from "../../shared/hoc/with-history";
import { KContext } from "../../shared/hoc/with-context";
import { useLocation } from "react-router-dom";
import { FormInstance } from "antd/es/form";
import { Guid } from "guid-typescript";
import Swal from "sweetalert2";
import { KMainFunctions } from "../../shared/utilty/main-functions";
import moment from "moment";
import { IValidationData } from "../../models/dto/validation-data";
import { IStripePayment } from "../../models/dto/stripe-payment";
import { IUserInfoDto } from "../../models/dto/user-info.dto";
import { UserService } from "../../services/user-service";
import { kuikaCoreWasmBridgeService } from "../../services/_singletons";
import _ from "lodash";
import mqtt, { MqttClient } from "mqtt";
import { IMqttResult } from "../../models/dto/mqtt.dto";


declare let window: any;

export interface ITalepDuzenlemeEkrani_ScreenProps {
  navigator: KNavigator;
  form: FormInstance<any>;
  googleLogin: any;
  screenInputs: any;
  context: KContext;
  initialValues: any;
  children: any;
}

export interface ITalepDuzenlemeEkrani_ScreenState {
    isSpinnerVisible: boolean;
    isPageVisible: boolean;
	isLeftMenuVisible: boolean;
    spinnerCount: number;
    selectedLanguage: string;
    isPageInitLoaded: false;
    isPageRecurringLoaded: false;
	TM_UserRoleByUserId: any[];
	TM_UserRoleByUserId_dummy: any[];
	TM_GetLeadDetailUpdate: any[];
	TM_GetLeadDetailUpdate_dummy: any[];
	TM_StoreGetList: any[];
	TM_StoreGetList_dummy: any[];
	TS_GetStoreUsers: any[];
	TS_GetStoreUsers_dummy: any[];
	GetSalesPersonByStore: any[];
	GetSalesPersonByStore_dummy: any[];
	TM_GetLeadStatus: any[];
	TM_GetLeadStatus_dummy: any[];
	TM_GetLeadNextSteps: any[];
	TM_GetLeadNextSteps_dummy: any[];
	TM_GetAllContactSource: any[];
	TM_GetAllContactSource_dummy: any[];
	TM_ShowButton: any[];
	TM_ShowButton_dummy: any[];
	GoBack: any;
	GoBack_dummy: any;
	LeadUpdateAIScreen: any[];
	LeadUpdateAIScreen_dummy: any[];
	Notify: boolean;
	Notify_dummy: boolean;
	isComp995322Visible: 'visible' | 'hidden';
	isComp896529Visible: 'visible' | 'hidden';
	isComp714272Visible: 'visible' | 'hidden';
	isComp582321Visible: 'visible' | 'hidden';
	isComp307362Visible: 'visible' | 'hidden';
	isComp173696Visible: 'visible' | 'hidden';
	isComp679137Enabled: 'enabled' | 'disabled';
	isComp497133Enabled: 'enabled' | 'disabled';

}

export class TalepDuzenlemeEkrani_ScreenBase extends React.PureComponent<ITalepDuzenlemeEkrani_ScreenProps, any> {

	talepduzenlemeekrani_409980_value_kuikaSelectBoxRef: React.RefObject<any>;
	talepduzenlemeekrani_224087_value_kuikaSelectBoxRef: React.RefObject<any>;
	talepduzenlemeekrani_236789_value_kuikaSelectBoxRef: React.RefObject<any>;
	talepduzenlemeekrani_800346_value_kuikaSelectBoxRef: React.RefObject<any>;
	talepduzenlemeekrani_782197_value_kuikaSelectBoxRef: React.RefObject<any>;
	talepduzenlemeekrani_562354_value_kuikaSelectBoxRef: React.RefObject<any>;
	talepduzenlemeekrani_996295_value_kuikaSelectBoxRef: React.RefObject<any>;
    ml=[{"Id":"d5a61d2b-bd60-485f-86e2-661e9ed4e486","Name":"en_US","ShortName":"English","IsDefault":true,"LanguagePhrases":[]},{"Id":"12c6411c-69e3-4324-a914-9c1226168eb5","Name":"FixedValues","ShortName":"FixedValues","LanguagePhrases":[{"Id":789226,"PropertyName":"label","Value":"Geri"},{"Id":400873,"PropertyName":"value","Value":"Talep Düzenle"},{"Id":199250,"PropertyName":"value","Value":"Talebe ait güncellenebilir alanları düzenleyin ve değişiklikleri kaydedin."},{"Id":740680,"PropertyName":"value","Value":"Mevcut Talep Bilgisi"},{"Id":469506,"PropertyName":"value","Value":"Düzenleme sırasında hangi talep üzerinde çalıştığınızı net biçimde görün."},{"Id":504950,"PropertyName":"value","Value":"Talep No"},{"Id":613503,"PropertyName":"value","Value":"Müşteri"},{"Id":37104,"PropertyName":"value","Value":"Ürün"},{"Id":525523,"PropertyName":"value","Value":"Mevcut Durum"},{"Id":79375,"PropertyName":"value","Value":"Mağaza"},{"Id":784119,"PropertyName":"value","Value":"Satış Personeli"},{"Id":279315,"PropertyName":"value","Value":"Talep Temel Bilgileri"},{"Id":262512,"PropertyName":"value","Value":"Temel operasyonel alanları güncelleyin."},{"Id":775236,"PropertyName":"value","Value":"Açılan Mağaza"},{"Id":366305,"PropertyName":"value","Value":"*"},{"Id":409980,"PropertyName":"placeholder","Value":"Mağaza seçin"},{"Id":885935,"PropertyName":"value","Value":"Satış Personeli"},{"Id":337082,"PropertyName":"value","Value":"*"},{"Id":224087,"PropertyName":"placeholder","Value":"Personel seçin"},{"Id":667544,"PropertyName":"value","Value":"Takip Durumu"},{"Id":634665,"PropertyName":"value","Value":"*"},{"Id":236789,"PropertyName":"placeholder","Value":"Takip durumu seçin"},{"Id":574347,"PropertyName":"value","Value":"Sonraki Adım"},{"Id":83900,"PropertyName":"value","Value":"*"},{"Id":800346,"PropertyName":"placeholder","Value":"Sonraki adımı seçin"},{"Id":135140,"PropertyName":"value","Value":"Termin ve Süreç Bilgileri"},{"Id":535602,"PropertyName":"value","Value":"Planlanan tarihleri ve iletişim süreci detaylarını girin."},{"Id":31336,"PropertyName":"value","Value":"Termin Tarihi Güncelle"},{"Id":782197,"PropertyName":"placeholder","Value":"Yıl"},{"Id":562354,"PropertyName":"placeholder","Value":"Ay"},{"Id":42938,"PropertyName":"value","Value":"İletişim Kaynağı"},{"Id":442830,"PropertyName":"value","Value":"*"},{"Id":996295,"PropertyName":"placeholder","Value":"Kaynak seçin"},{"Id":460253,"PropertyName":"value","Value":"Talep Notu"},{"Id":599892,"PropertyName":"placeholder","Value":"Talebe ait önemli notları girin"},{"Id":121874,"PropertyName":"value","Value":"Değişiklikleri kaydetmeden önce tüm zorunlu alanları ve koşullu seçimleri kontrol edin."},{"Id":684445,"PropertyName":"label","Value":"Vazgeç"},{"Id":273722,"PropertyName":"label","Value":"Değişiklikleri Kaydet"}]}]
    defaultML = "en_US"
    
    screenHash = ""
    


    constructor(props) {
        super(props);
		this.talepduzenlemeekrani_409980_value_kuikaSelectBoxRef = React.createRef();
		this.talepduzenlemeekrani_224087_value_kuikaSelectBoxRef = React.createRef();
		this.talepduzenlemeekrani_236789_value_kuikaSelectBoxRef = React.createRef();
		this.talepduzenlemeekrani_800346_value_kuikaSelectBoxRef = React.createRef();
		this.talepduzenlemeekrani_782197_value_kuikaSelectBoxRef = React.createRef();
		this.talepduzenlemeekrani_562354_value_kuikaSelectBoxRef = React.createRef();
		this.talepduzenlemeekrani_996295_value_kuikaSelectBoxRef = React.createRef();

        this.state = {
            isSpinnerVisible: false,
            isPageVisible: false,
            isLeftMenuVisible: false,
            spinnerCount: 0,
            selectedLanguage: "",
            isPageInitLoaded: false,
            isPageRecurringLoaded: false,
            	        TM_UserRoleByUserId: [],
	        TM_GetLeadDetailUpdate: [],
	        TM_StoreGetList: [],
	        TS_GetStoreUsers: [],
	        GetSalesPersonByStore: [],
	        TM_GetLeadStatus: [],
	        TM_GetLeadNextSteps: [],
	        TM_GetAllContactSource: [],
	        TM_ShowButton: [],
	        GoBack: "",
	        LeadUpdateAIScreen: [],
	        Notify: false,
	        dataSource_782197: [{"key":"2025","text":"2025"},{"key":"2026","text":"2026"},{"key":"2027","text":"2027"},{"key":"2028","text":"2028"},{"key":"2029","text":"2029"},{"key":"2030","text":"2030"},{"key":"2031","text":"2031"},{"key":"2032","text":"2032"},{"key":"2033","text":"2033"},{"key":"2034","text":"2034"},{"key":"2035","text":"2035"}],
	        dataSource_562354: [{"key":"1","text":"Ocak"},{"key":"2","text":"Şubat"},{"key":"3","text":"Mart"},{"key":"4","text":"Nisan"},{"key":"5","text":"Mayıs"},{"key":"6","text":"Haziran"},{"key":"7","text":"Temmuz"},{"key":"8","text":"Ağustos"},{"key":"9","text":"Eylül"},{"key":"10","text":"Ekim"},{"key":"11","text":"Kasım"},{"key":"12","text":"Aralık"}],
	        isComp995322Visible: 'hidden',
	        isComp896529Visible: 'hidden',
	        isComp714272Visible: 'hidden',
	        isComp582321Visible: 'hidden',
	        isComp307362Visible: 'hidden',
	        isComp173696Visible: 'hidden',
	        isComp679137Enabled: 'disabled',
	        isComp497133Enabled: 'disabled',

        }

        this.state.isPageVisible = true;
        
    }

    async componentDidMount() {

        if (KuikaAppManager.isPageInitPrevented()) {
            KuikaAppManager.calculateAndSetBodyHeight("talepduzenlemeekrani", "");
            return;
        }
        
        
        ReactSystemFunctions.validateToken()
        this.fillFormInitValues();
        if (true){
            await this.TalepDuzenlemeEkraniPageInit();
        }
        
        
        
        KuikaAppManager.calculateAndSetBodyHeight("talepduzenlemeekrani", "");

        if (ReactSystemFunctions.getIsMicroApp() === false) {
           window.parentScreen = this;
        }
    }

    componentWillUnmount() {
        
        
        

        if (ReactSystemFunctions.getIsMicroApp() === false) {
           window.parentScreen = null;
        }
    }

    

        
    componentDidUpdate= async (prevProps, prevState) => {
		KuikaAppManager.calculateAndSetBodyHeight("talepduzenlemeekrani", ""    );
        if (prevProps?.location?.search !== (this.props as any)?.location?.search) {
			await this.TalepDuzenlemeEkraniPageInit();
		}

        

        if (ReactSystemFunctions.getIsMicroApp() === false) {
            for (const key in prevState) {
                if (key.startsWith('NavVisible') && prevState[key] === true && this.state[key] === false) {
                    window.parentScreen = this;
                    break;
                }
            }
        }
	}

    fillFormInitValues() {
        this.props.form?.setFieldsValue({
talepduzenlemeekrani_409980_value: this.state.TM_GetLeadDetailUpdate?.at?.(0)?.storeId ?? undefined,
talepduzenlemeekrani_224087_value: this.state.TM_GetLeadDetailUpdate?.at?.(0)?.salesPersonKUserId ?? undefined,
talepduzenlemeekrani_236789_value: this.state.TM_GetLeadDetailUpdate?.at?.(0)?.statuId ?? undefined,
talepduzenlemeekrani_800346_value: this.state.TM_GetLeadDetailUpdate?.at?.(0)?.nextStepId ?? undefined,
talepduzenlemeekrani_782197_value: this.state.TM_GetLeadDetailUpdate?.at?.(0)?.estimatedYear ?? undefined,
talepduzenlemeekrani_562354_value: this.state.TM_GetLeadDetailUpdate?.at?.(0)?.estimatedMonth ?? undefined,
talepduzenlemeekrani_996295_value: this.state.TM_GetLeadDetailUpdate?.at?.(0)?.contactResourceId ?? undefined,
talepduzenlemeekrani_599892_value: this.state.TM_GetLeadDetailUpdate?.at?.(0)?.talepNotu ?? undefined
});

    }

      setPageInitLoaded = (value: boolean) => {
        this.setState({ isPageInitLoaded: value });
      }

      setPageRecurringLoaded = (value: boolean) => {
        this.setState({ isPageRecurringLoaded: value });
      }

      clearFieldValidation = (changedValues: any) => {
        const fieldName = Object.keys(changedValues)[0];
        if (fieldName) {
          this.props.form?.setFields([
            {
              name: fieldName,
              errors: []
            }
          ]);
        }
      };

      

    TalepDuzenlemeEkraniPageInit = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


	if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }

        let localVar = {
			UserID_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.getMyUserId(), "Guid"),
			LeadId_1: ReactSystemFunctions.convertToTypeByName(this.props.screenInputs.LeadId ?? this.props.screenInputs.leadid, "Guid"),
			KUserId_3: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.getMyUserId(), "Guid"),
			StoreId_4: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, (stateVars.TM_GetLeadDetailUpdate !== undefined ? (stateVars.TM_GetLeadDetailUpdate?.length > 0 ? stateVars.TM_GetLeadDetailUpdate[0].storeId : null) : (this.state.TM_GetLeadDetailUpdate?.length > 0 ? this.state.TM_GetLeadDetailUpdate[0].storeId : null))), "Guid"),
			LeadId_8: ReactSystemFunctions.convertToTypeByName(this.props.screenInputs.LeadId ?? this.props.screenInputs.leadid, "Guid"),
			UserId_8: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.getMyUserId(), "Guid")
        }

	KuikaAppManager.showSpinner(this);
	
        if (true) {
        KuikaAppManager.showSpinner(this);
        }
        let result = await KuikaAppManager.ApiRequest(this, "TalepDuzenlemeEkrani/TalepDuzenlemeEkraniPageInit", localVar)
        if (!KMainFunctions.IsResStatus2XX(result)) return true;

		stateVars.TM_UserRoleByUserId = result?.data.tM_UserRoleByUserId;
		stateVars.TM_GetLeadDetailUpdate = result?.data.tM_GetLeadDetailUpdate;
		formVars.talepduzenlemeekrani_394533_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadDetailUpdate !== undefined ? (stateVars.TM_GetLeadDetailUpdate?.length > 0 ? stateVars.TM_GetLeadDetailUpdate[0].leadCode : null) : (this.state.TM_GetLeadDetailUpdate?.length > 0 ? this.state.TM_GetLeadDetailUpdate[0].leadCode : null)));
		formVars.talepduzenlemeekrani_169809_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadDetailUpdate !== undefined ? (stateVars.TM_GetLeadDetailUpdate?.length > 0 ? stateVars.TM_GetLeadDetailUpdate[0].customerName : null) : (this.state.TM_GetLeadDetailUpdate?.length > 0 ? this.state.TM_GetLeadDetailUpdate[0].customerName : null)));
		formVars.talepduzenlemeekrani_308103_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadDetailUpdate !== undefined ? (stateVars.TM_GetLeadDetailUpdate?.length > 0 ? stateVars.TM_GetLeadDetailUpdate[0].productName : null) : (this.state.TM_GetLeadDetailUpdate?.length > 0 ? this.state.TM_GetLeadDetailUpdate[0].productName : null)));
		formVars.talepduzenlemeekrani_995322_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadDetailUpdate !== undefined ? (stateVars.TM_GetLeadDetailUpdate?.length > 0 ? stateVars.TM_GetLeadDetailUpdate[0].processName : null) : (this.state.TM_GetLeadDetailUpdate?.length > 0 ? this.state.TM_GetLeadDetailUpdate[0].processName : null)));
		formVars.talepduzenlemeekrani_896529_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadDetailUpdate !== undefined ? (stateVars.TM_GetLeadDetailUpdate?.length > 0 ? stateVars.TM_GetLeadDetailUpdate[0].processName : null) : (this.state.TM_GetLeadDetailUpdate?.length > 0 ? this.state.TM_GetLeadDetailUpdate[0].processName : null)));
		formVars.talepduzenlemeekrani_714272_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadDetailUpdate !== undefined ? (stateVars.TM_GetLeadDetailUpdate?.length > 0 ? stateVars.TM_GetLeadDetailUpdate[0].processName : null) : (this.state.TM_GetLeadDetailUpdate?.length > 0 ? this.state.TM_GetLeadDetailUpdate[0].processName : null)));
		formVars.talepduzenlemeekrani_582321_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadDetailUpdate !== undefined ? (stateVars.TM_GetLeadDetailUpdate?.length > 0 ? stateVars.TM_GetLeadDetailUpdate[0].processName : null) : (this.state.TM_GetLeadDetailUpdate?.length > 0 ? this.state.TM_GetLeadDetailUpdate[0].processName : null)));
		formVars.talepduzenlemeekrani_307362_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadDetailUpdate !== undefined ? (stateVars.TM_GetLeadDetailUpdate?.length > 0 ? stateVars.TM_GetLeadDetailUpdate[0].processName : null) : (this.state.TM_GetLeadDetailUpdate?.length > 0 ? this.state.TM_GetLeadDetailUpdate[0].processName : null)));
		formVars.talepduzenlemeekrani_460919_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadDetailUpdate !== undefined ? (stateVars.TM_GetLeadDetailUpdate?.length > 0 ? stateVars.TM_GetLeadDetailUpdate[0].storeName : null) : (this.state.TM_GetLeadDetailUpdate?.length > 0 ? this.state.TM_GetLeadDetailUpdate[0].storeName : null)));
		formVars.talepduzenlemeekrani_390170_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadDetailUpdate !== undefined ? (stateVars.TM_GetLeadDetailUpdate?.length > 0 ? stateVars.TM_GetLeadDetailUpdate[0].salesPersonName : null) : (this.state.TM_GetLeadDetailUpdate?.length > 0 ? this.state.TM_GetLeadDetailUpdate[0].salesPersonName : null)));
		formVars.talepduzenlemeekrani_409980_value = (stateVars.TM_GetLeadDetailUpdate !== undefined ? (stateVars.TM_GetLeadDetailUpdate?.length > 0 ? stateVars.TM_GetLeadDetailUpdate[0].storeId : null) : (this.state.TM_GetLeadDetailUpdate?.length > 0 ? this.state.TM_GetLeadDetailUpdate[0].storeId : null));
		formVars.talepduzenlemeekrani_409980_options = stateVars.TM_StoreGetList;
		formVars.talepduzenlemeekrani_224087_value = (stateVars.TM_GetLeadDetailUpdate !== undefined ? (stateVars.TM_GetLeadDetailUpdate?.length > 0 ? stateVars.TM_GetLeadDetailUpdate[0].salesPersonKUserId : null) : (this.state.TM_GetLeadDetailUpdate?.length > 0 ? this.state.TM_GetLeadDetailUpdate[0].salesPersonKUserId : null));
		formVars.talepduzenlemeekrani_224087_options = stateVars.GetSalesPersonByStore;
		formVars.talepduzenlemeekrani_236789_value = (stateVars.TM_GetLeadDetailUpdate !== undefined ? (stateVars.TM_GetLeadDetailUpdate?.length > 0 ? stateVars.TM_GetLeadDetailUpdate[0].statuId : null) : (this.state.TM_GetLeadDetailUpdate?.length > 0 ? this.state.TM_GetLeadDetailUpdate[0].statuId : null));
		formVars.talepduzenlemeekrani_236789_options = stateVars.TM_GetLeadStatus;
		formVars.talepduzenlemeekrani_800346_value = (stateVars.TM_GetLeadDetailUpdate !== undefined ? (stateVars.TM_GetLeadDetailUpdate?.length > 0 ? stateVars.TM_GetLeadDetailUpdate[0].nextStepId : null) : (this.state.TM_GetLeadDetailUpdate?.length > 0 ? this.state.TM_GetLeadDetailUpdate[0].nextStepId : null));
		formVars.talepduzenlemeekrani_800346_options = stateVars.TM_GetLeadNextSteps;
		formVars.talepduzenlemeekrani_782197_value = (stateVars.TM_GetLeadDetailUpdate !== undefined ? (stateVars.TM_GetLeadDetailUpdate?.length > 0 ? stateVars.TM_GetLeadDetailUpdate[0].estimatedYear : null) : (this.state.TM_GetLeadDetailUpdate?.length > 0 ? this.state.TM_GetLeadDetailUpdate[0].estimatedYear : null));
		formVars.talepduzenlemeekrani_562354_value = (stateVars.TM_GetLeadDetailUpdate !== undefined ? (stateVars.TM_GetLeadDetailUpdate?.length > 0 ? stateVars.TM_GetLeadDetailUpdate[0].estimatedMonth : null) : (this.state.TM_GetLeadDetailUpdate?.length > 0 ? this.state.TM_GetLeadDetailUpdate[0].estimatedMonth : null));
		formVars.talepduzenlemeekrani_996295_value = (stateVars.TM_GetLeadDetailUpdate !== undefined ? (stateVars.TM_GetLeadDetailUpdate?.length > 0 ? stateVars.TM_GetLeadDetailUpdate[0].contactResourceId : null) : (this.state.TM_GetLeadDetailUpdate?.length > 0 ? this.state.TM_GetLeadDetailUpdate[0].contactResourceId : null));
		formVars.talepduzenlemeekrani_996295_options = stateVars.TM_GetAllContactSource;
		formVars.talepduzenlemeekrani_599892_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadDetailUpdate !== undefined ? (stateVars.TM_GetLeadDetailUpdate?.length > 0 ? stateVars.TM_GetLeadDetailUpdate[0].talepNotu : null) : (this.state.TM_GetLeadDetailUpdate?.length > 0 ? this.state.TM_GetLeadDetailUpdate[0].talepNotu : null)));
		stateVars.isComp995322Visible = (((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadDetailUpdate !== undefined ? (stateVars.TM_GetLeadDetailUpdate?.length > 0 ? stateVars.TM_GetLeadDetailUpdate[0].processCode : null) : (this.state.TM_GetLeadDetailUpdate?.length > 0 ? this.state.TM_GetLeadDetailUpdate[0].processCode : null))), ReactSystemFunctions.convertToTypeByName("PENDING", "string")) || ReactSystemFunctions.isEqualTo(ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadDetailUpdate !== undefined ? (stateVars.TM_GetLeadDetailUpdate?.length > 0 ? stateVars.TM_GetLeadDetailUpdate[0].processCode : null) : (this.state.TM_GetLeadDetailUpdate?.length > 0 ? this.state.TM_GetLeadDetailUpdate[0].processCode : null))), ReactSystemFunctions.convertToTypeByName("TERMIN_PENDING", "string")) || ReactSystemFunctions.isEqualTo(ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadDetailUpdate !== undefined ? (stateVars.TM_GetLeadDetailUpdate?.length > 0 ? stateVars.TM_GetLeadDetailUpdate[0].processCode : null) : (this.state.TM_GetLeadDetailUpdate?.length > 0 ? this.state.TM_GetLeadDetailUpdate[0].processCode : null))), ReactSystemFunctions.convertToTypeByName("DELIVERY_PENDING", "string")))) === true ? "visible" : "hidden")
		stateVars.isComp896529Visible = (((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadDetailUpdate !== undefined ? (stateVars.TM_GetLeadDetailUpdate?.length > 0 ? stateVars.TM_GetLeadDetailUpdate[0].processCode : null) : (this.state.TM_GetLeadDetailUpdate?.length > 0 ? this.state.TM_GetLeadDetailUpdate[0].processCode : null))), ReactSystemFunctions.convertToTypeByName("CUSTOMER_DECLINED", "string")) || ReactSystemFunctions.isEqualTo(ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadDetailUpdate !== undefined ? (stateVars.TM_GetLeadDetailUpdate?.length > 0 ? stateVars.TM_GetLeadDetailUpdate[0].processCode : null) : (this.state.TM_GetLeadDetailUpdate?.length > 0 ? this.state.TM_GetLeadDetailUpdate[0].processCode : null))), ReactSystemFunctions.convertToTypeByName("REJECTED", "string")))) === true ? "visible" : "hidden")
		stateVars.isComp714272Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadDetailUpdate !== undefined ? (stateVars.TM_GetLeadDetailUpdate?.length > 0 ? stateVars.TM_GetLeadDetailUpdate[0].processCode : null) : (this.state.TM_GetLeadDetailUpdate?.length > 0 ? this.state.TM_GetLeadDetailUpdate[0].processCode : null))), ReactSystemFunctions.convertToTypeByName("DELIVERED", "string"))) === true ? "visible" : "hidden")
		stateVars.isComp582321Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadDetailUpdate !== undefined ? (stateVars.TM_GetLeadDetailUpdate?.length > 0 ? stateVars.TM_GetLeadDetailUpdate[0].processCode : null) : (this.state.TM_GetLeadDetailUpdate?.length > 0 ? this.state.TM_GetLeadDetailUpdate[0].processCode : null))), ReactSystemFunctions.convertToTypeByName("CLOSED", "string"))) === true ? "visible" : "hidden")
		stateVars.isComp307362Visible = (((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadDetailUpdate !== undefined ? (stateVars.TM_GetLeadDetailUpdate?.length > 0 ? stateVars.TM_GetLeadDetailUpdate[0].processCode : null) : (this.state.TM_GetLeadDetailUpdate?.length > 0 ? this.state.TM_GetLeadDetailUpdate[0].processCode : null))), ReactSystemFunctions.convertToTypeByName("APPROVED", "string")) || ReactSystemFunctions.isEqualTo(ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadDetailUpdate !== undefined ? (stateVars.TM_GetLeadDetailUpdate?.length > 0 ? stateVars.TM_GetLeadDetailUpdate[0].processCode : null) : (this.state.TM_GetLeadDetailUpdate?.length > 0 ? this.state.TM_GetLeadDetailUpdate[0].processCode : null))), ReactSystemFunctions.convertToTypeByName("CREATED", "string")))) === true ? "visible" : "hidden")
		stateVars.isComp173696Visible = (((ReactSystemFunctions.doesNotContain(ReactSystemFunctions.getMyRoleNames(), ReactSystemFunctions.convertToTypeByName("TimesSatisPersoneli", "string")) && ReactSystemFunctions.isNotEmpty(ReactSystemFunctions.value(this, (stateVars.TM_GetLeadDetailUpdate !== undefined ? (stateVars.TM_GetLeadDetailUpdate?.length > 0 ? stateVars.TM_GetLeadDetailUpdate[0].estimatedDate : null) : (this.state.TM_GetLeadDetailUpdate?.length > 0 ? this.state.TM_GetLeadDetailUpdate[0].estimatedDate : null))), ReactSystemFunctions.convertToTypeByName("True", "string")) && ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, (stateVars.TM_ShowButton !== undefined ? (stateVars.TM_ShowButton?.length > 0 ? stateVars.TM_ShowButton[0].terminOnayShow : null) : (this.state.TM_ShowButton?.length > 0 ? this.state.TM_ShowButton[0].terminOnayShow : null))), ReactSystemFunctions.convertToTypeByName("True", "string")))) === true ? "visible" : "hidden")
		stateVars.TM_StoreGetList = result?.data.tM_StoreGetList;
		
		formVars.talepduzenlemeekrani_409980_value = (stateVars.TM_GetLeadDetailUpdate !== undefined ? (stateVars.TM_GetLeadDetailUpdate?.length > 0 ? stateVars.TM_GetLeadDetailUpdate[0].storeId : null) : (this.state.TM_GetLeadDetailUpdate?.length > 0 ? this.state.TM_GetLeadDetailUpdate[0].storeId : null));
		formVars.talepduzenlemeekrani_409980_options = stateVars.TM_StoreGetList;
		stateVars.TS_GetStoreUsers = result?.data.tS_GetStoreUsers;
		stateVars.GetSalesPersonByStore = result?.data.getSalesPersonByStore;
		
		formVars.talepduzenlemeekrani_224087_value = (stateVars.TM_GetLeadDetailUpdate !== undefined ? (stateVars.TM_GetLeadDetailUpdate?.length > 0 ? stateVars.TM_GetLeadDetailUpdate[0].salesPersonKUserId : null) : (this.state.TM_GetLeadDetailUpdate?.length > 0 ? this.state.TM_GetLeadDetailUpdate[0].salesPersonKUserId : null));
		formVars.talepduzenlemeekrani_224087_options = stateVars.GetSalesPersonByStore;
		stateVars.TM_GetLeadStatus = result?.data.tM_GetLeadStatus;
		
		formVars.talepduzenlemeekrani_236789_value = (stateVars.TM_GetLeadDetailUpdate !== undefined ? (stateVars.TM_GetLeadDetailUpdate?.length > 0 ? stateVars.TM_GetLeadDetailUpdate[0].statuId : null) : (this.state.TM_GetLeadDetailUpdate?.length > 0 ? this.state.TM_GetLeadDetailUpdate[0].statuId : null));
		formVars.talepduzenlemeekrani_236789_options = stateVars.TM_GetLeadStatus;
		stateVars.TM_GetLeadNextSteps = result?.data.tM_GetLeadNextSteps;
		
		formVars.talepduzenlemeekrani_800346_value = (stateVars.TM_GetLeadDetailUpdate !== undefined ? (stateVars.TM_GetLeadDetailUpdate?.length > 0 ? stateVars.TM_GetLeadDetailUpdate[0].nextStepId : null) : (this.state.TM_GetLeadDetailUpdate?.length > 0 ? this.state.TM_GetLeadDetailUpdate[0].nextStepId : null));
		formVars.talepduzenlemeekrani_800346_options = stateVars.TM_GetLeadNextSteps;
		stateVars.TM_GetAllContactSource = result?.data.tM_GetAllContactSource;
		
		formVars.talepduzenlemeekrani_996295_value = (stateVars.TM_GetLeadDetailUpdate !== undefined ? (stateVars.TM_GetLeadDetailUpdate?.length > 0 ? stateVars.TM_GetLeadDetailUpdate[0].contactResourceId : null) : (this.state.TM_GetLeadDetailUpdate?.length > 0 ? this.state.TM_GetLeadDetailUpdate[0].contactResourceId : null));
		formVars.talepduzenlemeekrani_996295_options = stateVars.TM_GetAllContactSource;
		stateVars.TM_ShowButton = result?.data.tM_ShowButton;
		stateVars.isComp173696Visible = (((ReactSystemFunctions.doesNotContain(ReactSystemFunctions.getMyRoleNames(), ReactSystemFunctions.convertToTypeByName("TimesSatisPersoneli", "string")) && ReactSystemFunctions.isNotEmpty(ReactSystemFunctions.value(this, (stateVars.TM_GetLeadDetailUpdate !== undefined ? (stateVars.TM_GetLeadDetailUpdate?.length > 0 ? stateVars.TM_GetLeadDetailUpdate[0].estimatedDate : null) : (this.state.TM_GetLeadDetailUpdate?.length > 0 ? this.state.TM_GetLeadDetailUpdate[0].estimatedDate : null))), ReactSystemFunctions.convertToTypeByName("True", "string")) && ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, (stateVars.TM_ShowButton !== undefined ? (stateVars.TM_ShowButton?.length > 0 ? stateVars.TM_ShowButton[0].terminOnayShow : null) : (this.state.TM_ShowButton?.length > 0 ? this.state.TM_ShowButton[0].terminOnayShow : null))), ReactSystemFunctions.convertToTypeByName("True", "string")))) === true ? "visible" : "hidden")
		this.props.form?.setFieldsValue(formVars);
		
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.TalepDuzenlemeEkraniPageInit1_();
                  resolve();
                });
          })



        
        KuikaAppManager.hideSpinner(this);
        return isErrorOccurred;
    }
	TalepDuzenlemeEkraniPageInit1_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


	if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }

			formVars.talepduzenlemeekrani_394533_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadDetailUpdate !== undefined ? (stateVars.TM_GetLeadDetailUpdate?.length > 0 ? stateVars.TM_GetLeadDetailUpdate[0].leadCode : null) : (this.state.TM_GetLeadDetailUpdate?.length > 0 ? this.state.TM_GetLeadDetailUpdate[0].leadCode : null)));

			formVars.talepduzenlemeekrani_169809_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadDetailUpdate !== undefined ? (stateVars.TM_GetLeadDetailUpdate?.length > 0 ? stateVars.TM_GetLeadDetailUpdate[0].customerName : null) : (this.state.TM_GetLeadDetailUpdate?.length > 0 ? this.state.TM_GetLeadDetailUpdate[0].customerName : null)));

			formVars.talepduzenlemeekrani_308103_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadDetailUpdate !== undefined ? (stateVars.TM_GetLeadDetailUpdate?.length > 0 ? stateVars.TM_GetLeadDetailUpdate[0].productName : null) : (this.state.TM_GetLeadDetailUpdate?.length > 0 ? this.state.TM_GetLeadDetailUpdate[0].productName : null)));

			formVars.talepduzenlemeekrani_995322_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadDetailUpdate !== undefined ? (stateVars.TM_GetLeadDetailUpdate?.length > 0 ? stateVars.TM_GetLeadDetailUpdate[0].processName : null) : (this.state.TM_GetLeadDetailUpdate?.length > 0 ? this.state.TM_GetLeadDetailUpdate[0].processName : null)));

			stateVars.isComp995322Visible = (((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadDetailUpdate !== undefined ? (stateVars.TM_GetLeadDetailUpdate?.length > 0 ? stateVars.TM_GetLeadDetailUpdate[0].processCode : null) : (this.state.TM_GetLeadDetailUpdate?.length > 0 ? this.state.TM_GetLeadDetailUpdate[0].processCode : null))), ReactSystemFunctions.convertToTypeByName("PENDING", "string")) || ReactSystemFunctions.isEqualTo(ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadDetailUpdate !== undefined ? (stateVars.TM_GetLeadDetailUpdate?.length > 0 ? stateVars.TM_GetLeadDetailUpdate[0].processCode : null) : (this.state.TM_GetLeadDetailUpdate?.length > 0 ? this.state.TM_GetLeadDetailUpdate[0].processCode : null))), ReactSystemFunctions.convertToTypeByName("TERMIN_PENDING", "string")) || ReactSystemFunctions.isEqualTo(ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadDetailUpdate !== undefined ? (stateVars.TM_GetLeadDetailUpdate?.length > 0 ? stateVars.TM_GetLeadDetailUpdate[0].processCode : null) : (this.state.TM_GetLeadDetailUpdate?.length > 0 ? this.state.TM_GetLeadDetailUpdate[0].processCode : null))), ReactSystemFunctions.convertToTypeByName("DELIVERY_PENDING", "string")))) === true ? "visible" : "hidden")
			formVars.talepduzenlemeekrani_896529_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadDetailUpdate !== undefined ? (stateVars.TM_GetLeadDetailUpdate?.length > 0 ? stateVars.TM_GetLeadDetailUpdate[0].processName : null) : (this.state.TM_GetLeadDetailUpdate?.length > 0 ? this.state.TM_GetLeadDetailUpdate[0].processName : null)));

			stateVars.isComp896529Visible = (((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadDetailUpdate !== undefined ? (stateVars.TM_GetLeadDetailUpdate?.length > 0 ? stateVars.TM_GetLeadDetailUpdate[0].processCode : null) : (this.state.TM_GetLeadDetailUpdate?.length > 0 ? this.state.TM_GetLeadDetailUpdate[0].processCode : null))), ReactSystemFunctions.convertToTypeByName("CUSTOMER_DECLINED", "string")) || ReactSystemFunctions.isEqualTo(ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadDetailUpdate !== undefined ? (stateVars.TM_GetLeadDetailUpdate?.length > 0 ? stateVars.TM_GetLeadDetailUpdate[0].processCode : null) : (this.state.TM_GetLeadDetailUpdate?.length > 0 ? this.state.TM_GetLeadDetailUpdate[0].processCode : null))), ReactSystemFunctions.convertToTypeByName("REJECTED", "string")))) === true ? "visible" : "hidden")
			formVars.talepduzenlemeekrani_714272_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadDetailUpdate !== undefined ? (stateVars.TM_GetLeadDetailUpdate?.length > 0 ? stateVars.TM_GetLeadDetailUpdate[0].processName : null) : (this.state.TM_GetLeadDetailUpdate?.length > 0 ? this.state.TM_GetLeadDetailUpdate[0].processName : null)));

			stateVars.isComp714272Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadDetailUpdate !== undefined ? (stateVars.TM_GetLeadDetailUpdate?.length > 0 ? stateVars.TM_GetLeadDetailUpdate[0].processCode : null) : (this.state.TM_GetLeadDetailUpdate?.length > 0 ? this.state.TM_GetLeadDetailUpdate[0].processCode : null))), ReactSystemFunctions.convertToTypeByName("DELIVERED", "string"))) === true ? "visible" : "hidden")
			formVars.talepduzenlemeekrani_582321_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadDetailUpdate !== undefined ? (stateVars.TM_GetLeadDetailUpdate?.length > 0 ? stateVars.TM_GetLeadDetailUpdate[0].processName : null) : (this.state.TM_GetLeadDetailUpdate?.length > 0 ? this.state.TM_GetLeadDetailUpdate[0].processName : null)));

			stateVars.isComp582321Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadDetailUpdate !== undefined ? (stateVars.TM_GetLeadDetailUpdate?.length > 0 ? stateVars.TM_GetLeadDetailUpdate[0].processCode : null) : (this.state.TM_GetLeadDetailUpdate?.length > 0 ? this.state.TM_GetLeadDetailUpdate[0].processCode : null))), ReactSystemFunctions.convertToTypeByName("CLOSED", "string"))) === true ? "visible" : "hidden")
			formVars.talepduzenlemeekrani_307362_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadDetailUpdate !== undefined ? (stateVars.TM_GetLeadDetailUpdate?.length > 0 ? stateVars.TM_GetLeadDetailUpdate[0].processName : null) : (this.state.TM_GetLeadDetailUpdate?.length > 0 ? this.state.TM_GetLeadDetailUpdate[0].processName : null)));

			stateVars.isComp307362Visible = (((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadDetailUpdate !== undefined ? (stateVars.TM_GetLeadDetailUpdate?.length > 0 ? stateVars.TM_GetLeadDetailUpdate[0].processCode : null) : (this.state.TM_GetLeadDetailUpdate?.length > 0 ? this.state.TM_GetLeadDetailUpdate[0].processCode : null))), ReactSystemFunctions.convertToTypeByName("APPROVED", "string")) || ReactSystemFunctions.isEqualTo(ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadDetailUpdate !== undefined ? (stateVars.TM_GetLeadDetailUpdate?.length > 0 ? stateVars.TM_GetLeadDetailUpdate[0].processCode : null) : (this.state.TM_GetLeadDetailUpdate?.length > 0 ? this.state.TM_GetLeadDetailUpdate[0].processCode : null))), ReactSystemFunctions.convertToTypeByName("CREATED", "string")))) === true ? "visible" : "hidden")
			formVars.talepduzenlemeekrani_460919_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadDetailUpdate !== undefined ? (stateVars.TM_GetLeadDetailUpdate?.length > 0 ? stateVars.TM_GetLeadDetailUpdate[0].storeName : null) : (this.state.TM_GetLeadDetailUpdate?.length > 0 ? this.state.TM_GetLeadDetailUpdate[0].storeName : null)));

			formVars.talepduzenlemeekrani_390170_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadDetailUpdate !== undefined ? (stateVars.TM_GetLeadDetailUpdate?.length > 0 ? stateVars.TM_GetLeadDetailUpdate[0].salesPersonName : null) : (this.state.TM_GetLeadDetailUpdate?.length > 0 ? this.state.TM_GetLeadDetailUpdate[0].salesPersonName : null)));

			stateVars.isComp679137Enabled = (((ReactSystemFunctions.contains(ReactSystemFunctions.getMyRoleNames(), ReactSystemFunctions.convertToTypeByName("TimesUstYonetici", "string")) || ReactSystemFunctions.contains(ReactSystemFunctions.getMyRoleNames(), ReactSystemFunctions.convertToTypeByName("TimesYonetici", "string")))) === true ? "enabled" : "disabled")
			formVars.talepduzenlemeekrani_409980_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadDetailUpdate !== undefined ? (stateVars.TM_GetLeadDetailUpdate?.length > 0 ? stateVars.TM_GetLeadDetailUpdate[0].storeId : null) : (this.state.TM_GetLeadDetailUpdate?.length > 0 ? this.state.TM_GetLeadDetailUpdate[0].storeId : null)));

			
			stateVars.dataSource_409980 = stateVars.TM_StoreGetList ?? this.state.TM_StoreGetList;
			stateVars.dataSource_409980 = stateVars.TM_StoreGetList ?? this.state.TM_StoreGetList;
			stateVars.isComp497133Enabled = (((ReactSystemFunctions.contains(ReactSystemFunctions.getMyRoleNames(), ReactSystemFunctions.convertToTypeByName("TimesMagazaMuduru", "string")) || ReactSystemFunctions.contains(ReactSystemFunctions.getMyRoleNames(), ReactSystemFunctions.convertToTypeByName("TimesUstYonetici", "string")))) === true ? "enabled" : "disabled")
			formVars.talepduzenlemeekrani_224087_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadDetailUpdate !== undefined ? (stateVars.TM_GetLeadDetailUpdate?.length > 0 ? stateVars.TM_GetLeadDetailUpdate[0].salesPersonKUserId : null) : (this.state.TM_GetLeadDetailUpdate?.length > 0 ? this.state.TM_GetLeadDetailUpdate[0].salesPersonKUserId : null)));

			
			stateVars.dataSource_224087 = stateVars.GetSalesPersonByStore ?? this.state.GetSalesPersonByStore;
			stateVars.dataSource_224087 = stateVars.GetSalesPersonByStore ?? this.state.GetSalesPersonByStore;
			formVars.talepduzenlemeekrani_236789_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadDetailUpdate !== undefined ? (stateVars.TM_GetLeadDetailUpdate?.length > 0 ? stateVars.TM_GetLeadDetailUpdate[0].statuId : null) : (this.state.TM_GetLeadDetailUpdate?.length > 0 ? this.state.TM_GetLeadDetailUpdate[0].statuId : null)));

			
			stateVars.dataSource_236789 = stateVars.TM_GetLeadStatus ?? this.state.TM_GetLeadStatus;
			stateVars.dataSource_236789 = stateVars.TM_GetLeadStatus ?? this.state.TM_GetLeadStatus;
			formVars.talepduzenlemeekrani_800346_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadDetailUpdate !== undefined ? (stateVars.TM_GetLeadDetailUpdate?.length > 0 ? stateVars.TM_GetLeadDetailUpdate[0].nextStepId : null) : (this.state.TM_GetLeadDetailUpdate?.length > 0 ? this.state.TM_GetLeadDetailUpdate[0].nextStepId : null)));

			
			stateVars.dataSource_800346 = stateVars.TM_GetLeadNextSteps ?? this.state.TM_GetLeadNextSteps;
			stateVars.dataSource_800346 = stateVars.TM_GetLeadNextSteps ?? this.state.TM_GetLeadNextSteps;
			stateVars.isComp173696Visible = (((ReactSystemFunctions.doesNotContain(ReactSystemFunctions.getMyRoleNames(), ReactSystemFunctions.convertToTypeByName("TimesSatisPersoneli", "string")) && ReactSystemFunctions.isNotEmpty(ReactSystemFunctions.value(this, (stateVars.TM_GetLeadDetailUpdate !== undefined ? (stateVars.TM_GetLeadDetailUpdate?.length > 0 ? stateVars.TM_GetLeadDetailUpdate[0].estimatedDate : null) : (this.state.TM_GetLeadDetailUpdate?.length > 0 ? this.state.TM_GetLeadDetailUpdate[0].estimatedDate : null))), ReactSystemFunctions.convertToTypeByName("True", "string")) && ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, (stateVars.TM_ShowButton !== undefined ? (stateVars.TM_ShowButton?.length > 0 ? stateVars.TM_ShowButton[0].terminOnayShow : null) : (this.state.TM_ShowButton?.length > 0 ? this.state.TM_ShowButton[0].terminOnayShow : null))), ReactSystemFunctions.convertToTypeByName("True", "string")))) === true ? "visible" : "hidden")
			formVars.talepduzenlemeekrani_782197_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadDetailUpdate !== undefined ? (stateVars.TM_GetLeadDetailUpdate?.length > 0 ? stateVars.TM_GetLeadDetailUpdate[0].estimatedYear : null) : (this.state.TM_GetLeadDetailUpdate?.length > 0 ? this.state.TM_GetLeadDetailUpdate[0].estimatedYear : null)));

			formVars.talepduzenlemeekrani_562354_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadDetailUpdate !== undefined ? (stateVars.TM_GetLeadDetailUpdate?.length > 0 ? stateVars.TM_GetLeadDetailUpdate[0].estimatedMonth : null) : (this.state.TM_GetLeadDetailUpdate?.length > 0 ? this.state.TM_GetLeadDetailUpdate[0].estimatedMonth : null)));

			formVars.talepduzenlemeekrani_996295_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadDetailUpdate !== undefined ? (stateVars.TM_GetLeadDetailUpdate?.length > 0 ? stateVars.TM_GetLeadDetailUpdate[0].contactResourceId : null) : (this.state.TM_GetLeadDetailUpdate?.length > 0 ? this.state.TM_GetLeadDetailUpdate[0].contactResourceId : null)));

			
			stateVars.dataSource_996295 = stateVars.TM_GetAllContactSource ?? this.state.TM_GetAllContactSource;
			stateVars.dataSource_996295 = stateVars.TM_GetAllContactSource ?? this.state.TM_GetAllContactSource;
			formVars.talepduzenlemeekrani_599892_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadDetailUpdate !== undefined ? (stateVars.TM_GetLeadDetailUpdate?.length > 0 ? stateVars.TM_GetLeadDetailUpdate[0].talepNotu : null) : (this.state.TM_GetLeadDetailUpdate?.length > 0 ? this.state.TM_GetLeadDetailUpdate[0].talepNotu : null)));


	this.props.form?.setFieldsValue(formVars);
	this.setState(stateVars);
	KuikaAppManager.hideSpinner(this);

            this.setPageInitLoaded(true);
            return isErrorOccurred;
        }




		TalepDuzenlemeEkraniComponent_789226_onClick = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
KuikaAppManager.showSpinner(this);

				stateVars.GoBack = await ReactSystemFunctions.goBack(this, false);

		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

            
            return isErrorOccurred;
        }


    TalepDuzenlemeEkraniComponent_409980_onChange = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
		KuikaAppManager.increaseServerRequestCount();

        let localVar = {
				StoreId_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "talepduzenlemeekrani_409980_value", "value", "TM_StoreGetList", "id", "id")), "Guid")
        }

		KuikaAppManager.showSpinner(this);
		
        if (true) {
        KuikaAppManager.showSpinner(this);
        }
        let result = await KuikaAppManager.ApiRequest(this, "TalepDuzenlemeEkrani/TalepDuzenlemeEkraniComponent_409980_onChange", localVar)
        if (!KMainFunctions.IsResStatus2XX(result)) return true;

			stateVars.GetSalesPersonByStore = result?.data.getSalesPersonByStore;
			
			formVars.talepduzenlemeekrani_224087_options = stateVars.GetSalesPersonByStore;
			this.props.form?.setFieldsValue(formVars);
			
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.TalepDuzenlemeEkraniComponent_409980_onChange1_();
                  resolve();
                });
          })



        
        KuikaAppManager.hideSpinner(this);
        return isErrorOccurred;
    }
		TalepDuzenlemeEkraniComponent_409980_onChange1_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }

				
				stateVars.dataSource_224087 = stateVars.GetSalesPersonByStore ?? this.state.GetSalesPersonByStore;
				stateVars.dataSource_224087 = stateVars.GetSalesPersonByStore ?? this.state.GetSalesPersonByStore;

		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

            
            return isErrorOccurred;
        }




    TalepDuzenlemeEkraniComponent_273722_onClick = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;

			validations.push({ 
				isValid: ReactSystemFunctions.isNotEmpty(ReactSystemFunctions.value(this, "talepduzenlemeekrani_562354_value", "value", "", "key", ""), null),
				message: "Ay boş bırakılamaz!",
				formName: "talepduzenlemeekrani_562354_value",
				condition: ReactSystemFunctions.isNotEmpty(ReactSystemFunctions.value(this, (stateVars.TM_GetLeadDetailUpdate !== undefined ? (stateVars.TM_GetLeadDetailUpdate?.length > 0 ? stateVars.TM_GetLeadDetailUpdate[0].estimatedMonth : null) : (this.state.TM_GetLeadDetailUpdate?.length > 0 ? this.state.TM_GetLeadDetailUpdate[0].estimatedMonth : null))), ReactSystemFunctions.convertToTypeByName("True", "string"))
			} as IValidationData);

validations.forEach((validation) => {
            if (validation.message === "Geçerli bir mail adresi giriniz.") {
                validation.message = ReactSystemFunctions.getEmailValidationMessage()
            }
        })
			validations.push({ 
				isValid: ReactSystemFunctions.isNotEmpty(ReactSystemFunctions.value(this, "talepduzenlemeekrani_782197_value", "value", "", "key", ""), null),
				message: "Yıl boş bırakılamaz!",
				formName: "talepduzenlemeekrani_782197_value",
				condition: ReactSystemFunctions.isNotEmpty(ReactSystemFunctions.value(this, (stateVars.TM_GetLeadDetailUpdate !== undefined ? (stateVars.TM_GetLeadDetailUpdate?.length > 0 ? stateVars.TM_GetLeadDetailUpdate[0].estimatedYear : null) : (this.state.TM_GetLeadDetailUpdate?.length > 0 ? this.state.TM_GetLeadDetailUpdate[0].estimatedYear : null))), ReactSystemFunctions.convertToTypeByName("True", "string"))
			} as IValidationData);

validations.forEach((validation) => {
            if (validation.message === "Geçerli bir mail adresi giriniz.") {
                validation.message = ReactSystemFunctions.getEmailValidationMessage()
            }
        })

		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
		KuikaAppManager.increaseServerRequestCount();

        let localVar = {
				LeadId_0: ReactSystemFunctions.convertToTypeByName(this.props.screenInputs.LeadId ?? this.props.screenInputs.leadid, "Guid"),
				EstimatedMonth_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toInteger(this, ReactSystemFunctions.value(this, "talepduzenlemeekrani_562354_value", "value", "", "key", "")), "number"),
				SalesPersonKUserId_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "talepduzenlemeekrani_224087_value", "value", "GetSalesPersonByStore", "kuserID", "kuserID")), "Guid"),
				UpdatedBy_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.getMyUserId(), "Guid"),
				EstimatedYear_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toInteger(this, ReactSystemFunctions.value(this, "talepduzenlemeekrani_782197_value", "value", "", "key", "")), "number"),
				StatuId_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "talepduzenlemeekrani_236789_value", "value", "TM_GetLeadStatus", "id", "id")), "Guid"),
				NextStepId_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "talepduzenlemeekrani_800346_value", "value", "TM_GetLeadNextSteps", "id", "id")), "Guid"),
				StoreId_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "talepduzenlemeekrani_409980_value", "value", "TM_StoreGetList", "id", "id")), "Guid"),
				ContactResourceId_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "talepduzenlemeekrani_996295_value", "value", "TM_GetAllContactSource", "id", "id")), "Guid"),
				LeadNote_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "talepduzenlemeekrani_599892_value", "value", "", "", "")), "string")
        }

		KuikaAppManager.showSpinner(this);
		
        if (true) {
        KuikaAppManager.showSpinner(this);
        }
        let result = await KuikaAppManager.ApiRequest(this, "TalepDuzenlemeEkrani/TalepDuzenlemeEkraniComponent_273722_onClick", localVar)
        if (!KMainFunctions.IsResStatus2XX(result)) return true;

			stateVars.LeadUpdateAIScreen = result?.data.leadUpdateAIScreen;
			this.props.form?.setFieldsValue(formVars);
			
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.TalepDuzenlemeEkraniComponent_273722_onClick1_();
                  resolve();
                });
          })



        
        KuikaAppManager.hideSpinner(this);
        return isErrorOccurred;
    }
		TalepDuzenlemeEkraniComponent_273722_onClick1_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }

				stateVars.Notify = await ReactSystemFunctions.notify(this, ReactSystemFunctions.toString(this, (stateVars.LeadUpdateAIScreen !== undefined ? (stateVars.LeadUpdateAIScreen?.length > 0 ? stateVars.LeadUpdateAIScreen[0].message : null) : (this.state.LeadUpdateAIScreen?.length > 0 ? this.state.LeadUpdateAIScreen[0].message : null))), ReactSystemFunctions.convertToTypeByName("default", "string"), ReactSystemFunctions.convertToTypeByName("bottom-right", "string"), 2, ReactSystemFunctions.convertToTypeByName("", "string"), ReactSystemFunctions.convertToTypeByName("", "string"), 0);

		this.props.form?.setFieldsValue(formVars);
		
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.TalepDuzenlemeEkraniComponent_273722_onClick2_();
                  resolve();
                });
          })

            
            return isErrorOccurred;
        }
		TalepDuzenlemeEkraniComponent_273722_onClick2_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
if (ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, (stateVars.LeadUpdateAIScreen !== undefined ? (stateVars.LeadUpdateAIScreen?.length > 0 ? stateVars.LeadUpdateAIScreen[0].isSuccess : null) : (this.state.LeadUpdateAIScreen?.length > 0 ? this.state.LeadUpdateAIScreen[0].isSuccess : null))), true)) {
            
				stateVars.GoBack = await ReactSystemFunctions.goBack(this, false);

		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

        } else {
            KuikaAppManager.hideSpinner(this);
        }

            
            return isErrorOccurred;
        }







    async callCallbackFunction(diId: number, isFromMaster: boolean = false) {
        let isErrorOccurred = false;
		let pageInitCallerNavDiIDs = [] as number[];
		if (isFromMaster || pageInitCallerNavDiIDs.indexOf(diId) > -1) {
			await this.TalepDuzenlemeEkraniPageInit();
		}

    }


}
