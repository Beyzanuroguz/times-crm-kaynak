import * as React from "react";
import { MasterScreenWrapper } from "../../routes/master-screen-wrapper";
import { MasterScreen_Screen } from "./masterscreen";
import { MasterScreen_ScreenProvider } from "./masterscreen-context";
import { SparePartsBasedReports_Screen } from "../sparepartsbasedreports/sparepartsbasedreports";
import { TechnicalServiceReports_Screen } from "../technicalservicereports/technicalservicereports";
import { NextStepList_Screen } from "../nextsteplist/nextsteplist";
import { RoleList_Screen } from "../rolelist/rolelist";
import { UserProfile_Screen } from "../userprofile/userprofile";
import { PolisajBasedReports_Screen } from "../polisajbasedreports/polisajbasedreports";
import { MonthlyAllocationcopy_Screen } from "../monthlyallocationcopy/monthlyallocationcopy";
import { LoomisReports_Screen } from "../loomisreports/loomisreports";
import { PurchaseBasedReports_Screen } from "../purchasebasedreports/purchasebasedreports";
import { ImportList_Screen } from "../importlist/importlist";
import { ProductDetail_Screen } from "../productdetail/productdetail";
import { ContactSourceList_Screen } from "../contactsourcelist/contactsourcelist";
import { RolexMaterialReporting_Screen } from "../rolexmaterialreporting/rolexmaterialreporting";
import { TudorBasedReporting_Screen } from "../tudorbasedreporting/tudorbasedreporting";
import { RolexOtherProductReporting_Screen } from "../rolexotherproductreporting/rolexotherproductreporting";
import { StockDistribution_Screen } from "../stockdistribution/stockdistribution";
import { LeadAddByExcelcopy_Screen } from "../leadaddbyexcelcopy/leadaddbyexcelcopy";
import { DistributionDetail_Screen } from "../distributiondetail/distributiondetail";
import { TransferBekleyenHavuzu_Screen } from "../transferbekleyenhavuzu/transferbekleyenhavuzu";
import { OrderList_Screen } from "../orderlist/orderlist";
import { DistributionDetailStore_Screen } from "../distributiondetailstore/distributiondetailstore";
import { CreateTransferReceipt_Screen } from "../createtransferreceipt/createtransferreceipt";
import { UserManagementcopy_Screen } from "../usermanagementcopy/usermanagementcopy";
import { InComingTransferDetail_Screen } from "../incomingtransferdetail/incomingtransferdetail";
import { LeadAddByExcelAI_Screen } from "../leadaddbyexcelai/leadaddbyexcelai";
import { StockListManager_Screen } from "../stocklistmanager/stocklistmanager";
import { RolexBasedReporting_Screen } from "../rolexbasedreporting/rolexbasedreporting";
import { ReservationManagement_Screen } from "../reservationmanagement/reservationmanagement";
import { DupontBasedReporting_Screen } from "../dupontbasedreporting/dupontbasedreporting";
import { StockListStoreBase_Screen } from "../stockliststorebase/stockliststorebase";
import { RolexFamilyReporting_Screen } from "../rolexfamilyreporting/rolexfamilyreporting";
import { LeadList_Screen } from "../leadlist/leadlist";
import { MontBlancBasedReporting_Screen } from "../montblancbasedreporting/montblancbasedreporting";
import { TudorFamilyReporting_Screen } from "../tudorfamilyreporting/tudorfamilyreporting";
import { StokVeUrunArama_Screen } from "../stokveurunarama/stokveurunarama";
import { AnnualPortfolioList_Screen } from "../annualportfoliolist/annualportfoliolist";
import { RolexDiameterReporting_Screen } from "../rolexdiameterreporting/rolexdiameterreporting";
import { ProductDistribution_Screen } from "../productdistribution/productdistribution";
import { OnayaGonderdigimSatislar_Screen } from "../onayagonderdigimsatislar/onayagonderdigimsatislar";
import { ProductList_Screen } from "../productlist/productlist";
import { TransferTalepleri_Screen } from "../transfertalepleri/transfertalepleri";
import { DashBoardTempManager_Screen } from "../dashboardtempmanager/dashboardtempmanager";
import { ReportCashNebim_Screen } from "../reportcashnebim/reportcashnebim";
import { LeadAdd_Screen } from "../leadadd/leadadd";
import { LeadAddTemp_Screen } from "../leadaddtemp/leadaddtemp";
import { SatisBasariliPop_Screen } from "../satisbasarilipop/satisbasarilipop";
import { DashBoardTempTopManager_Screen } from "../dashboardtemptopmanager/dashboardtemptopmanager";
import { NotificationManager_Screen } from "../notificationmanager/notificationmanager";
import { AnnualPortfolioCreationStep1copycopy_Screen } from "../annualportfoliocreationstep1copycopy/annualportfoliocreationstep1copycopy";
import { ReportSalesNebim_Screen } from "../reportsalesnebim/reportsalesnebim";
import { ApprovedLeadList_Screen } from "../approvedleadlist/approvedleadlist";
import { TaskManagementTopManager_Screen } from "../taskmanagementtopmanager/taskmanagementtopmanager";
import { StockListDetail_Screen } from "../stocklistdetail/stocklistdetail";
import { YearlyStockEntry_Screen } from "../yearlystockentry/yearlystockentry";
import { CustomerList_Screen } from "../customerlist/customerlist";
import { YearlyAllocationcopy_Screen } from "../yearlyallocationcopy/yearlyallocationcopy";
import { ReportInventoryNebim_Screen } from "../reportinventorynebim/reportinventorynebim";
import { DistributionPool_Screen } from "../distributionpool/distributionpool";
import { AllLeadPending_Screen } from "../allleadpending/allleadpending";
import { SatisIslemi_Screen } from "../satisislemi/satisislemi";
import { DashBoardTemp_Screen } from "../dashboardtemp/dashboardtemp";
import { ImportListDetail_Screen } from "../importlistdetail/importlistdetail";
import { LeadListTemp_Screen } from "../leadlisttemp/leadlisttemp";
import { TaskManagementPerson_Screen } from "../taskmanagementperson/taskmanagementperson";
import { TaskManagementManager_Screen } from "../taskmanagementmanager/taskmanagementmanager";
import { StockListStore_Screen } from "../stockliststore/stockliststore";
import { LeadReport_Screen } from "../leadreport/leadreport";
import { DiscountLimit_Screen } from "../discountlimit/discountlimit";
import { FreeSalesWeb_Screen } from "../freesalesweb/freesalesweb";
import { UcuncuKisiFaturaOnaylari_Screen } from "../ucuncukisifaturaonaylari/ucuncukisifaturaonaylari";
// Inline mount of the master, used by drawer / modal / floatingPanel NAVIGATE targets.
// It mounts inside an already-routed (already-authenticated) parent screen, so the
// privateRouteReady auth gate that the router-level wrapper uses is irrelevant here —
// `forceReady` short-circuits it so master always renders inside the drawer/modal/panel.
//
// KOA-8559: this inline wrapper doubles as an "Open in Current Overlay" host. While it is
// mounted it publishes InlineOverlayNavContext to its own subtree (see MasterScreenWrapper).
// A NAVIGATE with openAs="currentOverlay" fired from inside it (master menu or child) and
// targeting one of this master's child screens swaps the overlay's visible child to that
// screen via renderOverlayScreen — keeping the overlay open and the master chrome / shared
// form mounted — instead of routing the page behind it.
export class MasterScreen_Screen_InlineWrapper extends MasterScreenWrapper {
    protected get anonymousPaths(): string[] { return []; }
    protected get forceReady(): boolean { return true; }
    protected get MasterComponent(): React.ComponentType<{ children?: React.ReactNode }> { return MasterScreen_Screen; }
    protected get MasterProvider(): React.ComponentType<{ children?: React.ReactNode }> { return MasterScreen_ScreenProvider; }
    protected get overlayScreenNames(): string[] | null { return ["sparepartsbasedreports", "technicalservicereports", "nextsteplist", "rolelist", "userprofile", "polisajbasedreports", "monthlyallocationcopy", "loomisreports", "purchasebasedreports", "importlist", "productdetail", "contactsourcelist", "rolexmaterialreporting", "tudorbasedreporting", "rolexotherproductreporting", "stockdistribution", "leadaddbyexcelcopy", "distributiondetail", "transferbekleyenhavuzu", "orderlist", "distributiondetailstore", "createtransferreceipt", "usermanagementcopy", "incomingtransferdetail", "leadaddbyexcelai", "stocklistmanager", "rolexbasedreporting", "reservationmanagement", "dupontbasedreporting", "stockliststorebase", "rolexfamilyreporting", "leadlist", "montblancbasedreporting", "tudorfamilyreporting", "stokveurunarama", "annualportfoliolist", "rolexdiameterreporting", "productdistribution", "onayagonderdigimsatislar", "productlist", "transfertalepleri", "dashboardtempmanager", "reportcashnebim", "leadadd", "leadaddtemp", "satisbasarilipop", "dashboardtemptopmanager", "notificationmanager", "annualportfoliocreationstep1copycopy", "reportsalesnebim", "approvedleadlist", "taskmanagementtopmanager", "stocklistdetail", "yearlystockentry", "customerlist", "yearlyallocationcopy", "reportinventorynebim", "distributionpool", "allleadpending", "satisislemi", "dashboardtemp", "importlistdetail", "leadlisttemp", "taskmanagementperson", "taskmanagementmanager", "stockliststore", "leadreport", "discountlimit", "freesalesweb", "ucuncukisifaturaonaylari"]; }
    protected renderOverlayScreen(screenName: string, screenInputs: Record<string, unknown>, onClose: () => void): React.ReactNode {
        switch (screenName.toLowerCase()) {
            case "sparepartsbasedreports":
                return <SparePartsBasedReports_Screen key={screenName} onClose={onClose} screenInputs={screenInputs} />;
            case "technicalservicereports":
                return <TechnicalServiceReports_Screen key={screenName} onClose={onClose} screenInputs={screenInputs} />;
            case "nextsteplist":
                return <NextStepList_Screen key={screenName} onClose={onClose} screenInputs={screenInputs} />;
            case "rolelist":
                return <RoleList_Screen key={screenName} onClose={onClose} screenInputs={screenInputs} />;
            case "userprofile":
                return <UserProfile_Screen key={screenName} onClose={onClose} screenInputs={screenInputs} />;
            case "polisajbasedreports":
                return <PolisajBasedReports_Screen key={screenName} onClose={onClose} screenInputs={screenInputs} />;
            case "monthlyallocationcopy":
                return <MonthlyAllocationcopy_Screen key={screenName} onClose={onClose} screenInputs={screenInputs} />;
            case "loomisreports":
                return <LoomisReports_Screen key={screenName} onClose={onClose} screenInputs={screenInputs} />;
            case "purchasebasedreports":
                return <PurchaseBasedReports_Screen key={screenName} onClose={onClose} screenInputs={screenInputs} />;
            case "importlist":
                return <ImportList_Screen key={screenName} onClose={onClose} screenInputs={screenInputs} />;
            case "productdetail":
                return <ProductDetail_Screen key={screenName} onClose={onClose} screenInputs={screenInputs} />;
            case "contactsourcelist":
                return <ContactSourceList_Screen key={screenName} onClose={onClose} screenInputs={screenInputs} />;
            case "rolexmaterialreporting":
                return <RolexMaterialReporting_Screen key={screenName} onClose={onClose} screenInputs={screenInputs} />;
            case "tudorbasedreporting":
                return <TudorBasedReporting_Screen key={screenName} onClose={onClose} screenInputs={screenInputs} />;
            case "rolexotherproductreporting":
                return <RolexOtherProductReporting_Screen key={screenName} onClose={onClose} screenInputs={screenInputs} />;
            case "stockdistribution":
                return <StockDistribution_Screen key={screenName} onClose={onClose} screenInputs={screenInputs} />;
            case "leadaddbyexcelcopy":
                return <LeadAddByExcelcopy_Screen key={screenName} onClose={onClose} screenInputs={screenInputs} />;
            case "distributiondetail":
                return <DistributionDetail_Screen key={screenName} onClose={onClose} screenInputs={screenInputs} />;
            case "transferbekleyenhavuzu":
                return <TransferBekleyenHavuzu_Screen key={screenName} onClose={onClose} screenInputs={screenInputs} />;
            case "orderlist":
                return <OrderList_Screen key={screenName} onClose={onClose} screenInputs={screenInputs} />;
            case "distributiondetailstore":
                return <DistributionDetailStore_Screen key={screenName} onClose={onClose} screenInputs={screenInputs} />;
            case "createtransferreceipt":
                return <CreateTransferReceipt_Screen key={screenName} onClose={onClose} screenInputs={screenInputs} />;
            case "usermanagementcopy":
                return <UserManagementcopy_Screen key={screenName} onClose={onClose} screenInputs={screenInputs} />;
            case "incomingtransferdetail":
                return <InComingTransferDetail_Screen key={screenName} onClose={onClose} screenInputs={screenInputs} />;
            case "leadaddbyexcelai":
                return <LeadAddByExcelAI_Screen key={screenName} onClose={onClose} screenInputs={screenInputs} />;
            case "stocklistmanager":
                return <StockListManager_Screen key={screenName} onClose={onClose} screenInputs={screenInputs} />;
            case "rolexbasedreporting":
                return <RolexBasedReporting_Screen key={screenName} onClose={onClose} screenInputs={screenInputs} />;
            case "reservationmanagement":
                return <ReservationManagement_Screen key={screenName} onClose={onClose} screenInputs={screenInputs} />;
            case "dupontbasedreporting":
                return <DupontBasedReporting_Screen key={screenName} onClose={onClose} screenInputs={screenInputs} />;
            case "stockliststorebase":
                return <StockListStoreBase_Screen key={screenName} onClose={onClose} screenInputs={screenInputs} />;
            case "rolexfamilyreporting":
                return <RolexFamilyReporting_Screen key={screenName} onClose={onClose} screenInputs={screenInputs} />;
            case "leadlist":
                return <LeadList_Screen key={screenName} onClose={onClose} screenInputs={screenInputs} />;
            case "montblancbasedreporting":
                return <MontBlancBasedReporting_Screen key={screenName} onClose={onClose} screenInputs={screenInputs} />;
            case "tudorfamilyreporting":
                return <TudorFamilyReporting_Screen key={screenName} onClose={onClose} screenInputs={screenInputs} />;
            case "stokveurunarama":
                return <StokVeUrunArama_Screen key={screenName} onClose={onClose} screenInputs={screenInputs} />;
            case "annualportfoliolist":
                return <AnnualPortfolioList_Screen key={screenName} onClose={onClose} screenInputs={screenInputs} />;
            case "rolexdiameterreporting":
                return <RolexDiameterReporting_Screen key={screenName} onClose={onClose} screenInputs={screenInputs} />;
            case "productdistribution":
                return <ProductDistribution_Screen key={screenName} onClose={onClose} screenInputs={screenInputs} />;
            case "onayagonderdigimsatislar":
                return <OnayaGonderdigimSatislar_Screen key={screenName} onClose={onClose} screenInputs={screenInputs} />;
            case "productlist":
                return <ProductList_Screen key={screenName} onClose={onClose} screenInputs={screenInputs} />;
            case "transfertalepleri":
                return <TransferTalepleri_Screen key={screenName} onClose={onClose} screenInputs={screenInputs} />;
            case "dashboardtempmanager":
                return <DashBoardTempManager_Screen key={screenName} onClose={onClose} screenInputs={screenInputs} />;
            case "reportcashnebim":
                return <ReportCashNebim_Screen key={screenName} onClose={onClose} screenInputs={screenInputs} />;
            case "leadadd":
                return <LeadAdd_Screen key={screenName} onClose={onClose} screenInputs={screenInputs} />;
            case "leadaddtemp":
                return <LeadAddTemp_Screen key={screenName} onClose={onClose} screenInputs={screenInputs} />;
            case "satisbasarilipop":
                return <SatisBasariliPop_Screen key={screenName} onClose={onClose} screenInputs={screenInputs} />;
            case "dashboardtemptopmanager":
                return <DashBoardTempTopManager_Screen key={screenName} onClose={onClose} screenInputs={screenInputs} />;
            case "notificationmanager":
                return <NotificationManager_Screen key={screenName} onClose={onClose} screenInputs={screenInputs} />;
            case "annualportfoliocreationstep1copycopy":
                return <AnnualPortfolioCreationStep1copycopy_Screen key={screenName} onClose={onClose} screenInputs={screenInputs} />;
            case "reportsalesnebim":
                return <ReportSalesNebim_Screen key={screenName} onClose={onClose} screenInputs={screenInputs} />;
            case "approvedleadlist":
                return <ApprovedLeadList_Screen key={screenName} onClose={onClose} screenInputs={screenInputs} />;
            case "taskmanagementtopmanager":
                return <TaskManagementTopManager_Screen key={screenName} onClose={onClose} screenInputs={screenInputs} />;
            case "stocklistdetail":
                return <StockListDetail_Screen key={screenName} onClose={onClose} screenInputs={screenInputs} />;
            case "yearlystockentry":
                return <YearlyStockEntry_Screen key={screenName} onClose={onClose} screenInputs={screenInputs} />;
            case "customerlist":
                return <CustomerList_Screen key={screenName} onClose={onClose} screenInputs={screenInputs} />;
            case "yearlyallocationcopy":
                return <YearlyAllocationcopy_Screen key={screenName} onClose={onClose} screenInputs={screenInputs} />;
            case "reportinventorynebim":
                return <ReportInventoryNebim_Screen key={screenName} onClose={onClose} screenInputs={screenInputs} />;
            case "distributionpool":
                return <DistributionPool_Screen key={screenName} onClose={onClose} screenInputs={screenInputs} />;
            case "allleadpending":
                return <AllLeadPending_Screen key={screenName} onClose={onClose} screenInputs={screenInputs} />;
            case "satisislemi":
                return <SatisIslemi_Screen key={screenName} onClose={onClose} screenInputs={screenInputs} />;
            case "dashboardtemp":
                return <DashBoardTemp_Screen key={screenName} onClose={onClose} screenInputs={screenInputs} />;
            case "importlistdetail":
                return <ImportListDetail_Screen key={screenName} onClose={onClose} screenInputs={screenInputs} />;
            case "leadlisttemp":
                return <LeadListTemp_Screen key={screenName} onClose={onClose} screenInputs={screenInputs} />;
            case "taskmanagementperson":
                return <TaskManagementPerson_Screen key={screenName} onClose={onClose} screenInputs={screenInputs} />;
            case "taskmanagementmanager":
                return <TaskManagementManager_Screen key={screenName} onClose={onClose} screenInputs={screenInputs} />;
            case "stockliststore":
                return <StockListStore_Screen key={screenName} onClose={onClose} screenInputs={screenInputs} />;
            case "leadreport":
                return <LeadReport_Screen key={screenName} onClose={onClose} screenInputs={screenInputs} />;
            case "discountlimit":
                return <DiscountLimit_Screen key={screenName} onClose={onClose} screenInputs={screenInputs} />;
            case "freesalesweb":
                return <FreeSalesWeb_Screen key={screenName} onClose={onClose} screenInputs={screenInputs} />;
            case "ucuncukisifaturaonaylari":
                return <UcuncuKisiFaturaOnaylari_Screen key={screenName} onClose={onClose} screenInputs={screenInputs} />;
            default:
                return null;
        }
    }
    protected renderSwitchWrapper(): React.ReactNode { return this.props.children ?? null; }
}
