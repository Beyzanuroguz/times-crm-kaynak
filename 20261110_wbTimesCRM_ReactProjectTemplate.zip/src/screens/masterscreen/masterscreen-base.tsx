import React from "react";
import Axios, { AxiosResponse } from "axios";
import { KuikaAppManager } from "../../shared/utilty/kuika-app-manager";
import { ReactSystemFunctions } from "../../shared/utilty/react-system-functions";
import { KNavigator } from "../../shared/hoc/with-history";
import { KContext } from "../../shared/hoc/with-context";
import { useLocation } from "react-router-dom";
import { FormInstance } from "antd/es/form";
import { Guid } from "guid-typescript";
import Swal from "sweetalert2";
import { KMainFunctions } from "../../shared/utilty/main-functions";
import moment from "moment";
import { IValidationData } from "../../models/dto/validation-data";
import { IStripePayment } from "../../models/dto/stripe-payment";
import { IUserInfoDto } from "../../models/dto/user-info.dto";
import { UserService } from "../../services/user-service";
import { kuikaCoreWasmBridgeService } from "../../services/_singletons";
import _ from "lodash";
import mqtt, { MqttClient } from "mqtt";
import { IMqttResult } from "../../models/dto/mqtt.dto";
import { MasterScreen_ScreenContext } from "./masterscreen-context";

declare let window: any;

export interface IMasterScreen_ScreenProps {
  navigator: KNavigator;
  form: FormInstance<any>;
  googleLogin: any;
  screenInputs: any;
  context: KContext;
  initialValues: any;
  children: any;
}

export interface IMasterScreen_ScreenState {
    isSpinnerVisible: boolean;
    isPageVisible: boolean;
	isLeftMenuVisible: boolean;
    spinnerCount: number;
    selectedLanguage: string;
    isPageInitLoaded: false;
    isPageRecurringLoaded: false;
	TM_GetUserStoreInfo: any[];
	TM_GetUserStoreInfo_dummy: any[];
	TM_UserRoleByUserId: any[];
	TM_UserRoleByUserId_dummy: any[];
	TMBadgerCount: any[];
	TMBadgerCount_dummy: any[];
	NAVIGATE: any;
	NAVIGATE_dummy: any;
	Logout: boolean;
	Logout_dummy: boolean;
	goToSignInActivity: any;
	goToSignInActivity_dummy: any;
	isComp424957Visible: 'visible' | 'hidden';
	isComp545276Visible: 'visible' | 'hidden';
	isComp979769Visible: 'visible' | 'hidden';
	isComp1291110417Visible: 'visible' | 'hidden';
	isComp1625272635Visible: 'visible' | 'hidden';
	isComp820866Visible: 'visible' | 'hidden';
	isComp945667Visible: 'visible' | 'hidden';
	isComp802599Visible: 'visible' | 'hidden';
	isComp665979760Enabled: 'enabled' | 'disabled';
	isComp1599455810Enabled: 'enabled' | 'disabled';
	isCompmasterscreen_951926AuthorizationVisible: 'visible' | 'hidden';
	isCompmasterscreen_376907AuthorizationVisible: 'visible' | 'hidden';
	isCompmasterscreen_511997538AuthorizationVisible: 'visible' | 'hidden';
	isCompmasterscreen_665979760AuthorizationVisible: 'visible' | 'hidden';
	isCompmasterscreen_1722535183AuthorizationVisible: 'visible' | 'hidden';
	isCompmasterscreen_1599455810AuthorizationVisible: 'visible' | 'hidden';
	isCompmasterscreen_243392AuthorizationVisible: 'visible' | 'hidden';
	isCompmasterscreen_459138AuthorizationVisible: 'visible' | 'hidden';
	isCompmasterscreen_453824AuthorizationVisible: 'visible' | 'hidden';
	isCompmasterscreen_346388AuthorizationVisible: 'visible' | 'hidden';
	isCompmasterscreen_649986AuthorizationVisible: 'visible' | 'hidden';
	isCompmasterscreen_178656AuthorizationVisible: 'visible' | 'hidden';
	isCompmasterscreen_424957AuthorizationVisible: 'visible' | 'hidden';
	isCompmasterscreen_379784AuthorizationVisible: 'visible' | 'hidden';
	isCompmasterscreen_545276AuthorizationVisible: 'visible' | 'hidden';
	isCompmasterscreen_140599AuthorizationVisible: 'visible' | 'hidden';
	isCompmasterscreen_979769AuthorizationVisible: 'visible' | 'hidden';
	isCompmasterscreen_732429AuthorizationVisible: 'visible' | 'hidden';
	isCompmasterscreen_29945AuthorizationVisible: 'visible' | 'hidden';
	isCompmasterscreen_916921805AuthorizationVisible: 'visible' | 'hidden';
	isCompmasterscreen_334494AuthorizationVisible: 'visible' | 'hidden';
	isCompmasterscreen_1291110417AuthorizationVisible: 'visible' | 'hidden';
	isCompmasterscreen_413571752AuthorizationVisible: 'visible' | 'hidden';
	isCompmasterscreen_1625272635AuthorizationVisible: 'visible' | 'hidden';
	isCompmasterscreen_484693AuthorizationVisible: 'visible' | 'hidden';
	isCompmasterscreen_802599AuthorizationVisible: 'visible' | 'hidden';

}

export class MasterScreen_ScreenBase extends React.PureComponent<IMasterScreen_ScreenProps, any> {
    static contextType = MasterScreen_ScreenContext;
    declare context: React.ContextType<typeof MasterScreen_ScreenContext>;
	masterscreen_752466_value_kuikaSiderMenuRef: React.RefObject<any>;
	masterscreen_584050_value_kuikaSiderMenuRef: React.RefObject<any>;
	masterscreen_945484_value_kuikaSiderMenuRef: React.RefObject<any>;
	masterscreen_375797_value_kuikaSiderMenuRef: React.RefObject<any>;
    ml=[{"Id":"d5a61d2b-bd60-485f-86e2-661e9ed4e486","Name":"en_US","ShortName":"English","IsDefault":true,"LanguagePhrases":[]},{"Id":"fa831f8a-bfb1-4788-baf0-cf62686ad40c","Name":"FixedValues","ShortName":"FixedValues","LanguagePhrases":[{"Id":914246,"PropertyName":"value","Value":"label"},{"Id":116286,"PropertyName":"label","Value":"Sub Menu"},{"Id":467573,"PropertyName":"label","Value":"Menu Item"},{"Id":209623,"PropertyName":"label","Value":"Sub Menu"},{"Id":350840,"PropertyName":"label","Value":"Menu Item"},{"Id":535636,"PropertyName":"label","Value":"Menu Item"},{"Id":4947,"PropertyName":"label","Value":"Menu Item"},{"Id":515892,"PropertyName":"label","Value":"Sub Menu"},{"Id":838847,"PropertyName":"label","Value":"Menu Item"},{"Id":71440,"PropertyName":"label","Value":"Sub Menu"},{"Id":228276,"PropertyName":"label","Value":"Menu Item"},{"Id":588521,"PropertyName":"label","Value":"Menu Item"},{"Id":280036,"PropertyName":"label","Value":"Menu Item"},{"Id":205290,"PropertyName":"label","Value":"Sub Menu"},{"Id":414431,"PropertyName":"label","Value":"Menu Item"},{"Id":736598,"PropertyName":"label","Value":"Sub Menu"},{"Id":722617,"PropertyName":"label","Value":"Menu Item"},{"Id":555280,"PropertyName":"label","Value":"Menu Item"},{"Id":216085,"PropertyName":"label","Value":"Menu Item"},{"Id":348986,"PropertyName":"value","Value":"Times"},{"Id":386165,"PropertyName":"label","Value":"Anasayfa"},{"Id":511997538,"PropertyName":"label","Value":"Görevlerim"},{"Id":665979760,"PropertyName":"label","Value":"Onaydaki Satışlarım"},{"Id":1722535183,"PropertyName":"label","Value":"Lead Onayları"},{"Id":1599455810,"PropertyName":"label","Value":"3. Kişi Fatura Onayları"},{"Id":243392,"PropertyName":"label","Value":"Ürün Talepleri"},{"Id":459138,"PropertyName":"label","Value":"Talep Listesi"},{"Id":453824,"PropertyName":"label","Value":"Yeni Talep"},{"Id":346388,"PropertyName":"label","Value":"Excelden Talep Oluştur"},{"Id":649986,"PropertyName":"label","Value":"Müşteriler"},{"Id":178656,"PropertyName":"label","Value":"Ürünler"},{"Id":424957,"PropertyName":"label","Value":"Stok Yönetimi"},{"Id":379784,"PropertyName":"label","Value":"Satış"},{"Id":266628218,"PropertyName":"label","Value":"Transfer Yönetimi "},{"Id":136060982,"PropertyName":"label","Value":"Transfer Talepleri "},{"Id":545276,"PropertyName":"label","Value":"Dağıtım & Teslimat"},{"Id":140599,"PropertyName":"label","Value":"Dağıtım"},{"Id":979769,"PropertyName":"label","Value":"Portföy Yönetimi"},{"Id":732429,"PropertyName":"label","Value":"Portföy Listeleme"},{"Id":29945,"PropertyName":"label","Value":"Raporlar"},{"Id":916921805,"PropertyName":"label","Value":"Lead Raporları"},{"Id":334494,"PropertyName":"label","Value":"Marka Bazlı Rapor"},{"Id":1291110417,"PropertyName":"label","Value":"Satış Raporu"},{"Id":413571752,"PropertyName":"label","Value":"Envanter Raporu"},{"Id":1625272635,"PropertyName":"label","Value":"Kasa Rapor Dökümü"},{"Id":820866,"PropertyName":"label","Value":"Teknik Servis Raporları"},{"Id":945667,"PropertyName":"label","Value":"Loomis(Kargo) Raporu"},{"Id":484693,"PropertyName":"label","Value":"Çıkış Yap"},{"Id":802599,"PropertyName":"label","Value":"Transfer Yönetimi"}]}]
    defaultML = "en_US"
    
    screenHash = ""
    

    private _prevMasterPageInitLoaded: boolean = false;
    private _prevMasterPageRecurringLoaded: boolean = false;
    private _prevShouldTriggerPageInit: boolean = false;
    constructor(props) {
        super(props);
		this.masterscreen_752466_value_kuikaSiderMenuRef = React.createRef();
		this.masterscreen_584050_value_kuikaSiderMenuRef = React.createRef();
		this.masterscreen_945484_value_kuikaSiderMenuRef = React.createRef();
		this.masterscreen_375797_value_kuikaSiderMenuRef = React.createRef();

        this.state = {
            isSpinnerVisible: false,
            isPageVisible: false,
            isLeftMenuVisible: false,
            spinnerCount: 0,
            selectedLanguage: "",
            isPageInitLoaded: false,
            isPageRecurringLoaded: false,
            	        TM_GetUserStoreInfo: [],
	        TM_UserRoleByUserId: [],
	        TMBadgerCount: [],
	        NAVIGATE: "",
	        Logout: false,
	        goToSignInActivity: "",
	        isComp424957Visible: 'hidden',
	        isComp545276Visible: 'hidden',
	        isComp979769Visible: 'hidden',
	        isComp1291110417Visible: 'hidden',
	        isComp1625272635Visible: 'hidden',
	        isComp820866Visible: 'hidden',
	        isComp945667Visible: 'hidden',
	        isComp802599Visible: 'hidden',
	        isComp665979760Enabled: 'disabled',
	        isComp1599455810Enabled: 'disabled',
	        isCompmasterscreen_951926AuthorizationVisible: 'visible',
	        isCompmasterscreen_376907AuthorizationVisible: 'visible',
	        isCompmasterscreen_511997538AuthorizationVisible: 'visible',
	        isCompmasterscreen_665979760AuthorizationVisible: 'visible',
	        isCompmasterscreen_1722535183AuthorizationVisible: 'visible',
	        isCompmasterscreen_1599455810AuthorizationVisible: 'visible',
	        isCompmasterscreen_243392AuthorizationVisible: 'visible',
	        isCompmasterscreen_459138AuthorizationVisible: 'visible',
	        isCompmasterscreen_453824AuthorizationVisible: 'visible',
	        isCompmasterscreen_346388AuthorizationVisible: 'visible',
	        isCompmasterscreen_649986AuthorizationVisible: 'visible',
	        isCompmasterscreen_178656AuthorizationVisible: 'visible',
	        isCompmasterscreen_424957AuthorizationVisible: 'visible',
	        isCompmasterscreen_379784AuthorizationVisible: 'visible',
	        isCompmasterscreen_545276AuthorizationVisible: 'visible',
	        isCompmasterscreen_140599AuthorizationVisible: 'visible',
	        isCompmasterscreen_979769AuthorizationVisible: 'visible',
	        isCompmasterscreen_732429AuthorizationVisible: 'visible',
	        isCompmasterscreen_29945AuthorizationVisible: 'visible',
	        isCompmasterscreen_916921805AuthorizationVisible: 'visible',
	        isCompmasterscreen_334494AuthorizationVisible: 'visible',
	        isCompmasterscreen_1291110417AuthorizationVisible: 'visible',
	        isCompmasterscreen_413571752AuthorizationVisible: 'visible',
	        isCompmasterscreen_1625272635AuthorizationVisible: 'visible',
	        isCompmasterscreen_484693AuthorizationVisible: 'visible',
	        isCompmasterscreen_802599AuthorizationVisible: 'visible',

        }

        this.state.isPageVisible = true;
        
    }

    async componentDidMount() {

        if (KuikaAppManager.isPageInitPrevented()) {
            KuikaAppManager.calculateAndSetBodyHeight("masterscreen", "");
            return;
        }
        
        
        
        this.fillFormInitValues();
        try {
        if (true){
            await this.MasterScreenPageInit();
        }
        } finally { this.context.setMasterPageInitLoaded(true); }
        ReactSystemFunctions.hideIsNotAuthorized(this, "isCompmasterscreen_951926AuthorizationVisible", ["4da1f213-c8e4-0b50-5c84-02fd13f1a622","TimesUstYonetici"]);
ReactSystemFunctions.hideIsNotAuthorized(this, "isCompmasterscreen_376907AuthorizationVisible", ["4da1f213-c8e4-0b50-5c84-02fd13f1a622","TimesUstYonetici"]);
ReactSystemFunctions.hideIsNotAuthorized(this, "isCompmasterscreen_511997538AuthorizationVisible", ["4da1f213-c8e4-0b50-5c84-02fd13f1a622","b4bfd39c-ac02-f442-c899-7a2374a45b47","70de6cfc-6087-6059-59b4-0b5a8527af6b","TimesUstYonetici","TimesSatisPersoneli","TimesMagazaMuduru"]);
ReactSystemFunctions.hideIsNotAuthorized(this, "isCompmasterscreen_665979760AuthorizationVisible", ["b4bfd39c-ac02-f442-c899-7a2374a45b47","70de6cfc-6087-6059-59b4-0b5a8527af6b","TimesSatisPersoneli","TimesMagazaMuduru"]);
ReactSystemFunctions.hideIsNotAuthorized(this, "isCompmasterscreen_1722535183AuthorizationVisible", ["4da1f213-c8e4-0b50-5c84-02fd13f1a622","70de6cfc-6087-6059-59b4-0b5a8527af6b","TimesUstYonetici","TimesMagazaMuduru"]);
ReactSystemFunctions.hideIsNotAuthorized(this, "isCompmasterscreen_1599455810AuthorizationVisible", ["4da1f213-c8e4-0b50-5c84-02fd13f1a622","TimesUstYonetici"]);
ReactSystemFunctions.hideIsNotAuthorized(this, "isCompmasterscreen_243392AuthorizationVisible", ["cdb536b0-6297-155f-d446-8453d8a60304","4da1f213-c8e4-0b50-5c84-02fd13f1a622","b4bfd39c-ac02-f442-c899-7a2374a45b47","70de6cfc-6087-6059-59b4-0b5a8527af6b","c4e882ef-977d-f613-7694-230ac83919d2","TimesYonetici","TimesUstYonetici","TimesSatisPersoneli","TimesMagazaMuduru","TimesAdmin"]);
ReactSystemFunctions.hideIsNotAuthorized(this, "isCompmasterscreen_459138AuthorizationVisible", ["cdb536b0-6297-155f-d446-8453d8a60304","4da1f213-c8e4-0b50-5c84-02fd13f1a622","b4bfd39c-ac02-f442-c899-7a2374a45b47","70de6cfc-6087-6059-59b4-0b5a8527af6b","c4e882ef-977d-f613-7694-230ac83919d2","TimesYonetici","TimesUstYonetici","TimesSatisPersoneli","TimesMagazaMuduru","TimesAdmin"]);
ReactSystemFunctions.hideIsNotAuthorized(this, "isCompmasterscreen_453824AuthorizationVisible", ["cdb536b0-6297-155f-d446-8453d8a60304","4da1f213-c8e4-0b50-5c84-02fd13f1a622","b4bfd39c-ac02-f442-c899-7a2374a45b47","70de6cfc-6087-6059-59b4-0b5a8527af6b","TimesYonetici","TimesUstYonetici","TimesSatisPersoneli","TimesMagazaMuduru"]);
ReactSystemFunctions.hideIsNotAuthorized(this, "isCompmasterscreen_346388AuthorizationVisible", ["c4e882ef-977d-f613-7694-230ac83919d2","d6658aef-a188-d73c-9c42-e40f55e18bdb","70de6cfc-6087-6059-59b4-0b5a8527af6b","TimesMagazaMuduru","TimesAdmin","_SystemAdmin"]);
ReactSystemFunctions.hideIsNotAuthorized(this, "isCompmasterscreen_649986AuthorizationVisible", ["4da1f213-c8e4-0b50-5c84-02fd13f1a622","cdb536b0-6297-155f-d446-8453d8a60304","b4bfd39c-ac02-f442-c899-7a2374a45b47","70de6cfc-6087-6059-59b4-0b5a8527af6b","TimesYonetici","TimesUstYonetici","TimesSatisPersoneli","TimesMagazaMuduru"]);
ReactSystemFunctions.hideIsNotAuthorized(this, "isCompmasterscreen_178656AuthorizationVisible", ["4da1f213-c8e4-0b50-5c84-02fd13f1a622","cdb536b0-6297-155f-d446-8453d8a60304","b4bfd39c-ac02-f442-c899-7a2374a45b47","70de6cfc-6087-6059-59b4-0b5a8527af6b","TimesYonetici","TimesUstYonetici","TimesSatisPersoneli","TimesMagazaMuduru"]);
ReactSystemFunctions.hideIsNotAuthorized(this, "isCompmasterscreen_424957AuthorizationVisible", ["4da1f213-c8e4-0b50-5c84-02fd13f1a622","cdb536b0-6297-155f-d446-8453d8a60304","70de6cfc-6087-6059-59b4-0b5a8527af6b","b4bfd39c-ac02-f442-c899-7a2374a45b47","TimesYonetici","TimesUstYonetici","TimesSatisPersoneli","TimesMagazaMuduru"]);
ReactSystemFunctions.hideIsNotAuthorized(this, "isCompmasterscreen_379784AuthorizationVisible", ["4da1f213-c8e4-0b50-5c84-02fd13f1a622","70de6cfc-6087-6059-59b4-0b5a8527af6b","b4bfd39c-ac02-f442-c899-7a2374a45b47","TimesUstYonetici","TimesSatisPersoneli","TimesMagazaMuduru"]);
ReactSystemFunctions.hideIsNotAuthorized(this, "isCompmasterscreen_545276AuthorizationVisible", ["cdb536b0-6297-155f-d446-8453d8a60304","4da1f213-c8e4-0b50-5c84-02fd13f1a622","TimesYonetici","TimesUstYonetici"]);
ReactSystemFunctions.hideIsNotAuthorized(this, "isCompmasterscreen_140599AuthorizationVisible", ["cdb536b0-6297-155f-d446-8453d8a60304","4da1f213-c8e4-0b50-5c84-02fd13f1a622","TimesYonetici","TimesUstYonetici"]);
ReactSystemFunctions.hideIsNotAuthorized(this, "isCompmasterscreen_979769AuthorizationVisible", ["cdb536b0-6297-155f-d446-8453d8a60304","4da1f213-c8e4-0b50-5c84-02fd13f1a622","TimesYonetici","TimesUstYonetici"]);
ReactSystemFunctions.hideIsNotAuthorized(this, "isCompmasterscreen_732429AuthorizationVisible", ["cdb536b0-6297-155f-d446-8453d8a60304","4da1f213-c8e4-0b50-5c84-02fd13f1a622","TimesYonetici","TimesUstYonetici"]);
ReactSystemFunctions.hideIsNotAuthorized(this, "isCompmasterscreen_29945AuthorizationVisible", ["4da1f213-c8e4-0b50-5c84-02fd13f1a622","cdb536b0-6297-155f-d446-8453d8a60304","b4bfd39c-ac02-f442-c899-7a2374a45b47","70de6cfc-6087-6059-59b4-0b5a8527af6b","TimesYonetici","TimesUstYonetici","TimesSatisPersoneli","TimesMagazaMuduru"]);
ReactSystemFunctions.hideIsNotAuthorized(this, "isCompmasterscreen_916921805AuthorizationVisible", ["4da1f213-c8e4-0b50-5c84-02fd13f1a622","c4e882ef-977d-f613-7694-230ac83919d2","cdb536b0-6297-155f-d446-8453d8a60304","70de6cfc-6087-6059-59b4-0b5a8527af6b","TimesYonetici","TimesUstYonetici","TimesMagazaMuduru","TimesAdmin"]);
ReactSystemFunctions.hideIsNotAuthorized(this, "isCompmasterscreen_334494AuthorizationVisible", ["cdb536b0-6297-155f-d446-8453d8a60304","4da1f213-c8e4-0b50-5c84-02fd13f1a622","70de6cfc-6087-6059-59b4-0b5a8527af6b","b4bfd39c-ac02-f442-c899-7a2374a45b47","TimesYonetici","TimesUstYonetici","TimesSatisPersoneli","TimesMagazaMuduru"]);
ReactSystemFunctions.hideIsNotAuthorized(this, "isCompmasterscreen_1291110417AuthorizationVisible", ["cdb536b0-6297-155f-d446-8453d8a60304","4da1f213-c8e4-0b50-5c84-02fd13f1a622","b4bfd39c-ac02-f442-c899-7a2374a45b47","70de6cfc-6087-6059-59b4-0b5a8527af6b","TimesYonetici","TimesUstYonetici","TimesSatisPersoneli","TimesMagazaMuduru"]);
ReactSystemFunctions.hideIsNotAuthorized(this, "isCompmasterscreen_413571752AuthorizationVisible", ["cdb536b0-6297-155f-d446-8453d8a60304","4da1f213-c8e4-0b50-5c84-02fd13f1a622","b4bfd39c-ac02-f442-c899-7a2374a45b47","70de6cfc-6087-6059-59b4-0b5a8527af6b","c4e882ef-977d-f613-7694-230ac83919d2","TimesYonetici","TimesUstYonetici","TimesSatisPersoneli","TimesMagazaMuduru","TimesAdmin"]);
ReactSystemFunctions.hideIsNotAuthorized(this, "isCompmasterscreen_1625272635AuthorizationVisible", ["c4e882ef-977d-f613-7694-230ac83919d2","cdb536b0-6297-155f-d446-8453d8a60304","4da1f213-c8e4-0b50-5c84-02fd13f1a622","b4bfd39c-ac02-f442-c899-7a2374a45b47","70de6cfc-6087-6059-59b4-0b5a8527af6b","TimesYonetici","TimesUstYonetici","TimesSatisPersoneli","TimesMagazaMuduru","TimesAdmin"]);
ReactSystemFunctions.hideIsNotAuthorized(this, "isCompmasterscreen_484693AuthorizationVisible", ["cdb536b0-6297-155f-d446-8453d8a60304","4da1f213-c8e4-0b50-5c84-02fd13f1a622","b4bfd39c-ac02-f442-c899-7a2374a45b47","70de6cfc-6087-6059-59b4-0b5a8527af6b","c4e882ef-977d-f613-7694-230ac83919d2","TimesYonetici","TimesUstYonetici","TimesSatisPersoneli","TimesMagazaMuduru","TimesAdmin"]);
ReactSystemFunctions.hideIsNotAuthorized(this, "isCompmasterscreen_802599AuthorizationVisible", ["cdb536b0-6297-155f-d446-8453d8a60304","4da1f213-c8e4-0b50-5c84-02fd13f1a622","70de6cfc-6087-6059-59b4-0b5a8527af6b","TimesYonetici","TimesUstYonetici","TimesMagazaMuduru"]);

        
        
        KuikaAppManager.calculateAndSetBodyHeight("masterscreen", "");

        if (ReactSystemFunctions.getIsMicroApp() === false) {
           window.parentScreen = this;
        }
    }

    componentWillUnmount() {
        
        
        

        if (ReactSystemFunctions.getIsMicroApp() === false) {
           window.parentScreen = null;
        }
    }

    

        
    componentDidUpdate= async (prevProps, prevState) => {
		KuikaAppManager.calculateAndSetBodyHeight("masterscreen", ""    );
        if (prevProps?.location?.search !== (this.props as any)?.location?.search) {
			await this.MasterScreenPageInit();
		}

        		if (this._prevShouldTriggerPageInit !== this.context.shouldTriggerPageInit && this.context.shouldTriggerPageInit === true) {this._prevShouldTriggerPageInit = this.context.shouldTriggerPageInit;this._prevMasterPageInitLoaded = false; this.MasterScreenPageInit().finally(() => { this.context.setMasterPageInitLoaded(true); });this.context.setShouldTriggerPageInit(false);this._prevShouldTriggerPageInit = false;}


        if (ReactSystemFunctions.getIsMicroApp() === false) {
            for (const key in prevState) {
                if (key.startsWith('NavVisible') && prevState[key] === true && this.state[key] === false) {
                    window.parentScreen = this;
                    break;
                }
            }
        }
	}

    fillFormInitValues() {
        this.props.form?.setFieldsValue({
masterscreen_752466_value: { collapsed: (false) },
masterscreen_584050_value: { collapsed: (false) },
masterscreen_945484_value: { collapsed: (false) },
masterscreen_375797_value: { collapsed: (false) }
});

    }

      setPageInitLoaded = (value: boolean) => {
        this.setState({ isPageInitLoaded: value });
      }

      setPageRecurringLoaded = (value: boolean) => {
        this.setState({ isPageRecurringLoaded: value });
      }

      clearFieldValidation = (changedValues: any) => {
        const fieldName = Object.keys(changedValues)[0];
        if (fieldName) {
          this.props.form?.setFields([
            {
              name: fieldName,
              errors: []
            }
          ]);
        }
      };

      

    MasterScreenPageInit = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


	if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }

        let localVar = {
			UserId_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.getMyUserId(), "Guid"),
			UserID_1: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.getMyUserId(), "Guid"),
			KUserId_2: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.getMyUserId(), "Guid")
        }

	KuikaAppManager.showSpinner(this);
	
        if (true) {
        KuikaAppManager.showSpinner(this);
        }
        let result = await KuikaAppManager.ApiRequest(this, "MasterScreen/MasterScreenPageInit", localVar)
        if (!KMainFunctions.IsResStatus2XX(result)) return true;

		stateVars.TM_GetUserStoreInfo = result?.data.tM_GetUserStoreInfo;
		formVars.masterscreen_498052_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetUserStoreInfo !== undefined ? (stateVars.TM_GetUserStoreInfo?.length > 0 ? stateVars.TM_GetUserStoreInfo[0].subeAdi : null) : (this.state.TM_GetUserStoreInfo?.length > 0 ? this.state.TM_GetUserStoreInfo[0].subeAdi : null)));
		stateVars.TM_UserRoleByUserId = result?.data.tM_UserRoleByUserId;
		formVars.masterscreen_708276_value = ReactSystemFunctions.toString(this, (stateVars.TM_UserRoleByUserId !== undefined ? (stateVars.TM_UserRoleByUserId?.length > 0 ? stateVars.TM_UserRoleByUserId[0].roleNames : null) : (this.state.TM_UserRoleByUserId?.length > 0 ? this.state.TM_UserRoleByUserId[0].roleNames : null)));
		stateVars.TMBadgerCount = result?.data.tmBadgerCount;
		formVars.masterscreen_951926_count = ReactSystemFunctions.toString(this, (stateVars.TMBadgerCount !== undefined ? (stateVars.TMBadgerCount?.length > 0 ? stateVars.TMBadgerCount[0].notificationCount : null) : (this.state.TMBadgerCount?.length > 0 ? this.state.TMBadgerCount[0].notificationCount : null)));
		this.props.form?.setFieldsValue(formVars);
		
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.MasterScreenPageInit1_();
                  resolve();
                });
          })



        
        KuikaAppManager.hideSpinner(this);
        return isErrorOccurred;
    }
	MasterScreenPageInit1_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


	if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }

			formVars.masterscreen_498052_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetUserStoreInfo !== undefined ? (stateVars.TM_GetUserStoreInfo?.length > 0 ? stateVars.TM_GetUserStoreInfo[0].subeAdi : null) : (this.state.TM_GetUserStoreInfo?.length > 0 ? this.state.TM_GetUserStoreInfo[0].subeAdi : null)));

			formVars.masterscreen_951926_count = ReactSystemFunctions.toString(this, (stateVars.TMBadgerCount !== undefined ? (stateVars.TMBadgerCount?.length > 0 ? stateVars.TMBadgerCount[0].notificationCount : null) : (this.state.TMBadgerCount?.length > 0 ? this.state.TMBadgerCount[0].notificationCount : null)));

			formVars.masterscreen_708276_value = ReactSystemFunctions.toString(this, (stateVars.TM_UserRoleByUserId !== undefined ? (stateVars.TM_UserRoleByUserId?.length > 0 ? stateVars.TM_UserRoleByUserId[0].roleNames : null) : (this.state.TM_UserRoleByUserId?.length > 0 ? this.state.TM_UserRoleByUserId[0].roleNames : null)));


	this.props.form?.setFieldsValue(formVars);
	this.setState(stateVars);
	KuikaAppManager.hideSpinner(this);

            this.context.setMasterPageInitLoaded(true);
            return isErrorOccurred;
        }




		MasterScreenComponent_693093_onClick = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
KuikaAppManager.showSpinner(this);

					KuikaAppManager.prepareForNavigation();

				stateVars.NAVIGATE = await ReactSystemFunctions.navigate(this, undefined, "MasterScreen", "SettingPanel", "", "c9a7c7da-0306-4861-bdfa-6754fc0d829c", "608779", null, null, null, "40vw", "40vh", true, false);

		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

            
            return isErrorOccurred;
        }


		MasterScreenComponent_376907_onClick = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
if (ReactSystemFunctions.contains(ReactSystemFunctions.getMyRoleNames(), "TimesUstYonetici")) {
            KuikaAppManager.showSpinner(this);

					KuikaAppManager.prepareForNavigation();

				stateVars.NAVIGATE = await ReactSystemFunctions.navigate(this, undefined, "MasterScreen", "BildirimPopup", "", "c9a7c7da-0306-4861-bdfa-6754fc0d829c", "747879842", null, null, null, "380px", "600px", true, false);

		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

        } else {
            KuikaAppManager.hideSpinner(this);
        }

            
            return isErrorOccurred;
        }


		MasterScreenComponent_386165_onClick = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
if ((ReactSystemFunctions.contains(ReactSystemFunctions.getMyRoleNames(), "TimesUstYonetici") || ReactSystemFunctions.contains(ReactSystemFunctions.getMyRoleNames(), "TimesYonetici") || ReactSystemFunctions.contains(ReactSystemFunctions.getMyRoleNames(), "TimesAdmin"))) {
            KuikaAppManager.showSpinner(this);

const __currentPath = (window.location.hash ? window.location.hash.replace(/^#/, '').split('?')[0] : window.location.pathname.split('?')[0]).toLowerCase();
if (__currentPath !== "/dashboardtemptopmanager") {
  this.context.setMasterPageInitLoaded(false);
  this.context.setMasterPageRecurringLoaded(false);
  this.context.setShouldTriggerPageInit(true);
}
					KuikaAppManager.prepareForNavigation();

				stateVars.NAVIGATE = await ReactSystemFunctions.navigate(this, this.MasterScreenComponent_386165_onClick1_, "MasterScreen", "DashBoardTempTopManager", "", "currentPage", null, null, null, null, null, null, true, false);

		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

        } else {
            
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.MasterScreenComponent_386165_onClick1_();
                  resolve();
                });
          })
        }

            
            return isErrorOccurred;
        }
		MasterScreenComponent_386165_onClick1_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
if (ReactSystemFunctions.contains(ReactSystemFunctions.getMyRoleNames(), "TimesSatisPersoneli")) {
            KuikaAppManager.showSpinner(this);

const __currentPath = (window.location.hash ? window.location.hash.replace(/^#/, '').split('?')[0] : window.location.pathname.split('?')[0]).toLowerCase();
if (__currentPath !== "/dashboardtemp") {
  this.context.setMasterPageInitLoaded(false);
  this.context.setMasterPageRecurringLoaded(false);
  this.context.setShouldTriggerPageInit(true);
}
					KuikaAppManager.prepareForNavigation();

				stateVars.NAVIGATE = await ReactSystemFunctions.navigate(this, this.MasterScreenComponent_386165_onClick2_, "MasterScreen", "DashBoardTemp", "", "currentPage", null, null, null, null, null, null, true, false);

		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

        } else {
            
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.MasterScreenComponent_386165_onClick2_();
                  resolve();
                });
          })
        }

            
            return isErrorOccurred;
        }
		MasterScreenComponent_386165_onClick2_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
if (ReactSystemFunctions.contains(ReactSystemFunctions.getMyRoleNames(), "TimesMagazaMuduru")) {
            KuikaAppManager.showSpinner(this);

const __currentPath = (window.location.hash ? window.location.hash.replace(/^#/, '').split('?')[0] : window.location.pathname.split('?')[0]).toLowerCase();
if (__currentPath !== "/dashboardtempmanager") {
  this.context.setMasterPageInitLoaded(false);
  this.context.setMasterPageRecurringLoaded(false);
  this.context.setShouldTriggerPageInit(true);
}
					KuikaAppManager.prepareForNavigation();

				stateVars.NAVIGATE = await ReactSystemFunctions.navigate(this, undefined, "MasterScreen", "DashBoardTempManager", "", "currentPage", null, null, null, null, null, null, true, false);

		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

        } else {
            KuikaAppManager.hideSpinner(this);
        }

            
            return isErrorOccurred;
        }




		MasterScreenComponent_511997538_onClick = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
if (ReactSystemFunctions.contains(ReactSystemFunctions.getMyRoleNames(), "TimesUstYonetici")) {
            KuikaAppManager.showSpinner(this);

const __currentPath = (window.location.hash ? window.location.hash.replace(/^#/, '').split('?')[0] : window.location.pathname.split('?')[0]).toLowerCase();
if (__currentPath !== "/taskmanagementtopmanager") {
  this.context.setMasterPageInitLoaded(false);
  this.context.setMasterPageRecurringLoaded(false);
  this.context.setShouldTriggerPageInit(true);
}
					KuikaAppManager.prepareForNavigation();

				stateVars.NAVIGATE = await ReactSystemFunctions.navigate(this, this.MasterScreenComponent_511997538_onClick1_, "MasterScreen", "TaskManagementTopManager", "", "currentPage", null, null, null, null, null, null, true, false);

		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

        } else {
            
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.MasterScreenComponent_511997538_onClick1_();
                  resolve();
                });
          })
        }

            
            return isErrorOccurred;
        }
		MasterScreenComponent_511997538_onClick1_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
if (ReactSystemFunctions.contains(ReactSystemFunctions.getMyRoleNames(), "TimesSatisPersoneli")) {
            KuikaAppManager.showSpinner(this);

const __currentPath = (window.location.hash ? window.location.hash.replace(/^#/, '').split('?')[0] : window.location.pathname.split('?')[0]).toLowerCase();
if (__currentPath !== "/taskmanagementperson") {
  this.context.setMasterPageInitLoaded(false);
  this.context.setMasterPageRecurringLoaded(false);
  this.context.setShouldTriggerPageInit(true);
}
					KuikaAppManager.prepareForNavigation();

				stateVars.NAVIGATE = await ReactSystemFunctions.navigate(this, this.MasterScreenComponent_511997538_onClick2_, "MasterScreen", "TaskManagementPerson", "", "currentPage", null, null, null, null, null, null, true, false);

		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

        } else {
            
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.MasterScreenComponent_511997538_onClick2_();
                  resolve();
                });
          })
        }

            
            return isErrorOccurred;
        }
		MasterScreenComponent_511997538_onClick2_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
if (ReactSystemFunctions.contains(ReactSystemFunctions.getMyRoleNames(), "TimesMagazaMuduru")) {
            KuikaAppManager.showSpinner(this);

const __currentPath = (window.location.hash ? window.location.hash.replace(/^#/, '').split('?')[0] : window.location.pathname.split('?')[0]).toLowerCase();
if (__currentPath !== "/taskmanagementmanager") {
  this.context.setMasterPageInitLoaded(false);
  this.context.setMasterPageRecurringLoaded(false);
  this.context.setShouldTriggerPageInit(true);
}
					KuikaAppManager.prepareForNavigation();

				stateVars.NAVIGATE = await ReactSystemFunctions.navigate(this, undefined, "MasterScreen", "TaskManagementManager", "", "currentPage", null, null, null, null, null, null, true, false);

		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

        } else {
            KuikaAppManager.hideSpinner(this);
        }

            
            return isErrorOccurred;
        }




		MasterScreenComponent_665979760_onClick = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
KuikaAppManager.showSpinner(this);

const __currentPath = (window.location.hash ? window.location.hash.replace(/^#/, '').split('?')[0] : window.location.pathname.split('?')[0]).toLowerCase();
if (__currentPath !== "/onayagonderdigimsatislar") {
  this.context.setMasterPageInitLoaded(false);
  this.context.setMasterPageRecurringLoaded(false);
  this.context.setShouldTriggerPageInit(true);
}
					KuikaAppManager.prepareForNavigation();

				stateVars.NAVIGATE = await ReactSystemFunctions.navigate(this, undefined, "MasterScreen", "OnayaGonderdigimSatislar", "", "currentPage", null, null, null, null, null, null, true, false);

		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

            
            return isErrorOccurred;
        }


		MasterScreenComponent_1722535183_onClick = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
KuikaAppManager.showSpinner(this);

const __currentPath = (window.location.hash ? window.location.hash.replace(/^#/, '').split('?')[0] : window.location.pathname.split('?')[0]).toLowerCase();
if (__currentPath !== "/allleadpending") {
  this.context.setMasterPageInitLoaded(false);
  this.context.setMasterPageRecurringLoaded(false);
  this.context.setShouldTriggerPageInit(true);
}
					KuikaAppManager.prepareForNavigation();

				stateVars.NAVIGATE = await ReactSystemFunctions.navigate(this, undefined, "MasterScreen", "AllLeadPending", "", "currentPage", null, null, null, null, null, null, true, false);

		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

            
            return isErrorOccurred;
        }


		MasterScreenComponent_1599455810_onClick = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
KuikaAppManager.showSpinner(this);

const __currentPath = (window.location.hash ? window.location.hash.replace(/^#/, '').split('?')[0] : window.location.pathname.split('?')[0]).toLowerCase();
if (__currentPath !== "/ucuncukisifaturaonaylari") {
  this.context.setMasterPageInitLoaded(false);
  this.context.setMasterPageRecurringLoaded(false);
  this.context.setShouldTriggerPageInit(true);
}
					KuikaAppManager.prepareForNavigation();

				stateVars.NAVIGATE = await ReactSystemFunctions.navigate(this, undefined, "MasterScreen", "UcuncuKisiFaturaOnaylari", "", "currentPage", null, null, null, null, null, null, true, false);

		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

            
            return isErrorOccurred;
        }


		MasterScreenComponent_459138_onClick = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
KuikaAppManager.showSpinner(this);

const __currentPath = (window.location.hash ? window.location.hash.replace(/^#/, '').split('?')[0] : window.location.pathname.split('?')[0]).toLowerCase();
if (__currentPath !== "/leadlisttemp") {
  this.context.setMasterPageInitLoaded(false);
  this.context.setMasterPageRecurringLoaded(false);
  this.context.setShouldTriggerPageInit(true);
}
					KuikaAppManager.prepareForNavigation();

				stateVars.NAVIGATE = await ReactSystemFunctions.navigate(this, undefined, "MasterScreen", "LeadListTemp", "", "currentPage", null, null, null, null, null, null, true, false);

		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

            
            return isErrorOccurred;
        }


		MasterScreenComponent_453824_onClick = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
KuikaAppManager.showSpinner(this);

const __currentPath = (window.location.hash ? window.location.hash.replace(/^#/, '').split('?')[0] : window.location.pathname.split('?')[0]).toLowerCase();
if (__currentPath !== "/leadaddtemp") {
  this.context.setMasterPageInitLoaded(false);
  this.context.setMasterPageRecurringLoaded(false);
  this.context.setShouldTriggerPageInit(true);
}
					KuikaAppManager.prepareForNavigation();
						KuikaAppManager.addToPageInputVariables("LeadAddTemp", "CustomerId", ReactSystemFunctions.convertToTypeByName("00000000-0000-0000-0000-000000000000", "Guid"));

				stateVars.NAVIGATE = await ReactSystemFunctions.navigate(this, undefined, "MasterScreen", "LeadAddTemp", "", "currentPage", null, null, null, null, null, null, true, false);

		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

            
            return isErrorOccurred;
        }


		MasterScreenComponent_346388_onClick = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
KuikaAppManager.showSpinner(this);

const __currentPath = (window.location.hash ? window.location.hash.replace(/^#/, '').split('?')[0] : window.location.pathname.split('?')[0]).toLowerCase();
if (__currentPath !== "/leadaddbyexcelai") {
  this.context.setMasterPageInitLoaded(false);
  this.context.setMasterPageRecurringLoaded(false);
  this.context.setShouldTriggerPageInit(true);
}
					KuikaAppManager.prepareForNavigation();
						KuikaAppManager.addToPageInputVariables("LeadAddByExcelAI", "KUserId", ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.getMyUserId(), "Guid"));

				stateVars.NAVIGATE = await ReactSystemFunctions.navigate(this, undefined, "MasterScreen", "LeadAddByExcelAI", "", "currentPage", null, null, null, null, null, null, true, false);

		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

            
            return isErrorOccurred;
        }


		MasterScreenComponent_649986_onClick = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
KuikaAppManager.showSpinner(this);

const __currentPath = (window.location.hash ? window.location.hash.replace(/^#/, '').split('?')[0] : window.location.pathname.split('?')[0]).toLowerCase();
if (__currentPath !== "/customerlist") {
  this.context.setMasterPageInitLoaded(false);
  this.context.setMasterPageRecurringLoaded(false);
  this.context.setShouldTriggerPageInit(true);
}
					KuikaAppManager.prepareForNavigation();

				stateVars.NAVIGATE = await ReactSystemFunctions.navigate(this, undefined, "MasterScreen", "CustomerList", "", "currentPage", null, null, null, null, null, null, true, false);

		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

            
            return isErrorOccurred;
        }


		MasterScreenComponent_178656_onClick = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
KuikaAppManager.showSpinner(this);

const __currentPath = (window.location.hash ? window.location.hash.replace(/^#/, '').split('?')[0] : window.location.pathname.split('?')[0]).toLowerCase();
if (__currentPath !== "/productlist") {
  this.context.setMasterPageInitLoaded(false);
  this.context.setMasterPageRecurringLoaded(false);
  this.context.setShouldTriggerPageInit(true);
}
					KuikaAppManager.prepareForNavigation();

				stateVars.NAVIGATE = await ReactSystemFunctions.navigate(this, undefined, "MasterScreen", "ProductList", "", "currentPage", null, null, null, null, null, null, true, false);

		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

            
            return isErrorOccurred;
        }


		MasterScreenComponent_424957_onClick = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
KuikaAppManager.showSpinner(this);

const __currentPath = (window.location.hash ? window.location.hash.replace(/^#/, '').split('?')[0] : window.location.pathname.split('?')[0]).toLowerCase();
if (__currentPath !== "/stocklistmanager") {
  this.context.setMasterPageInitLoaded(false);
  this.context.setMasterPageRecurringLoaded(false);
  this.context.setShouldTriggerPageInit(true);
}
					KuikaAppManager.prepareForNavigation();

				stateVars.NAVIGATE = await ReactSystemFunctions.navigate(this, undefined, "MasterScreen", "StockListManager", "", "currentPage", null, null, null, null, null, null, true, false);

		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

            
            return isErrorOccurred;
        }


		MasterScreenComponent_379784_onClick = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
KuikaAppManager.showSpinner(this);

const __currentPath = (window.location.hash ? window.location.hash.replace(/^#/, '').split('?')[0] : window.location.pathname.split('?')[0]).toLowerCase();
if (__currentPath !== "/satisislemi") {
  this.context.setMasterPageInitLoaded(false);
  this.context.setMasterPageRecurringLoaded(false);
  this.context.setShouldTriggerPageInit(true);
}
					KuikaAppManager.prepareForNavigation();
						KuikaAppManager.addToPageInputVariables("SatisIslemi", "ApprovalId", ReactSystemFunctions.convertToTypeByName(null, "Guid"));
						KuikaAppManager.addToPageInputVariables("SatisIslemi", "SalesDraftId", ReactSystemFunctions.convertToTypeByName(null, "Guid"));

				stateVars.NAVIGATE = await ReactSystemFunctions.navigate(this, undefined, "MasterScreen", "SatisIslemi", "", "currentPage", null, null, null, null, null, null, true, false);

		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

            
            return isErrorOccurred;
        }


		MasterScreenComponent_136060982_onClick = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
KuikaAppManager.showSpinner(this);

const __currentPath = (window.location.hash ? window.location.hash.replace(/^#/, '').split('?')[0] : window.location.pathname.split('?')[0]).toLowerCase();
if (__currentPath !== "/transfertalepleri") {
  this.context.setMasterPageInitLoaded(false);
  this.context.setMasterPageRecurringLoaded(false);
  this.context.setShouldTriggerPageInit(true);
}
					KuikaAppManager.prepareForNavigation();

				stateVars.NAVIGATE = await ReactSystemFunctions.navigate(this, undefined, "MasterScreen", "TransferTalepleri", "", "currentPage", null, null, null, null, null, null, true, false);

		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

            
            return isErrorOccurred;
        }


		MasterScreenComponent_140599_onClick = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
KuikaAppManager.showSpinner(this);

const __currentPath = (window.location.hash ? window.location.hash.replace(/^#/, '').split('?')[0] : window.location.pathname.split('?')[0]).toLowerCase();
if (__currentPath !== "/importlist") {
  this.context.setMasterPageInitLoaded(false);
  this.context.setMasterPageRecurringLoaded(false);
  this.context.setShouldTriggerPageInit(true);
}
					KuikaAppManager.prepareForNavigation();

				stateVars.NAVIGATE = await ReactSystemFunctions.navigate(this, undefined, "MasterScreen", "ImportList", "", "currentPage", null, null, null, null, null, null, true, false);

		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

            
            return isErrorOccurred;
        }


		MasterScreenComponent_732429_onClick = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
KuikaAppManager.showSpinner(this);

const __currentPath = (window.location.hash ? window.location.hash.replace(/^#/, '').split('?')[0] : window.location.pathname.split('?')[0]).toLowerCase();
if (__currentPath !== "/annualportfoliolist") {
  this.context.setMasterPageInitLoaded(false);
  this.context.setMasterPageRecurringLoaded(false);
  this.context.setShouldTriggerPageInit(true);
}
					KuikaAppManager.prepareForNavigation();

				stateVars.NAVIGATE = await ReactSystemFunctions.navigate(this, undefined, "MasterScreen", "AnnualPortfolioList", "", "currentPage", null, null, null, null, null, null, true, false);

		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

            
            return isErrorOccurred;
        }


		MasterScreenComponent_916921805_onClick = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
KuikaAppManager.showSpinner(this);

const __currentPath = (window.location.hash ? window.location.hash.replace(/^#/, '').split('?')[0] : window.location.pathname.split('?')[0]).toLowerCase();
if (__currentPath !== "/leadreport") {
  this.context.setMasterPageInitLoaded(false);
  this.context.setMasterPageRecurringLoaded(false);
  this.context.setShouldTriggerPageInit(true);
}
					KuikaAppManager.prepareForNavigation();

				stateVars.NAVIGATE = await ReactSystemFunctions.navigate(this, undefined, "MasterScreen", "LeadReport", "", "currentPage", null, null, null, null, null, null, true, false);

		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

            
            return isErrorOccurred;
        }


		MasterScreenComponent_334494_onClick = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
KuikaAppManager.showSpinner(this);

const __currentPath = (window.location.hash ? window.location.hash.replace(/^#/, '').split('?')[0] : window.location.pathname.split('?')[0]).toLowerCase();
if (__currentPath !== "/rolexbasedreporting") {
  this.context.setMasterPageInitLoaded(false);
  this.context.setMasterPageRecurringLoaded(false);
  this.context.setShouldTriggerPageInit(true);
}
					KuikaAppManager.prepareForNavigation();

				stateVars.NAVIGATE = await ReactSystemFunctions.navigate(this, undefined, "MasterScreen", "RolexBasedReporting", "", "currentPage", null, null, null, null, null, null, true, false);

		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

            
            return isErrorOccurred;
        }


		MasterScreenComponent_1291110417_onClick = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
KuikaAppManager.showSpinner(this);

const __currentPath = (window.location.hash ? window.location.hash.replace(/^#/, '').split('?')[0] : window.location.pathname.split('?')[0]).toLowerCase();
if (__currentPath !== "/reportsalesnebim") {
  this.context.setMasterPageInitLoaded(false);
  this.context.setMasterPageRecurringLoaded(false);
  this.context.setShouldTriggerPageInit(true);
}
					KuikaAppManager.prepareForNavigation();

				stateVars.NAVIGATE = await ReactSystemFunctions.navigate(this, undefined, "MasterScreen", "ReportSalesNebim", "", "currentPage", null, null, null, null, null, null, true, false);

		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

            
            return isErrorOccurred;
        }


		MasterScreenComponent_413571752_onClick = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
KuikaAppManager.showSpinner(this);

const __currentPath = (window.location.hash ? window.location.hash.replace(/^#/, '').split('?')[0] : window.location.pathname.split('?')[0]).toLowerCase();
if (__currentPath !== "/reportinventorynebim") {
  this.context.setMasterPageInitLoaded(false);
  this.context.setMasterPageRecurringLoaded(false);
  this.context.setShouldTriggerPageInit(true);
}
					KuikaAppManager.prepareForNavigation();

				stateVars.NAVIGATE = await ReactSystemFunctions.navigate(this, undefined, "MasterScreen", "ReportInventoryNebim", "", "currentPage", null, null, null, null, null, null, true, false);

		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

            
            return isErrorOccurred;
        }


		MasterScreenComponent_1625272635_onClick = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
KuikaAppManager.showSpinner(this);

const __currentPath = (window.location.hash ? window.location.hash.replace(/^#/, '').split('?')[0] : window.location.pathname.split('?')[0]).toLowerCase();
if (__currentPath !== "/reportcashnebim") {
  this.context.setMasterPageInitLoaded(false);
  this.context.setMasterPageRecurringLoaded(false);
  this.context.setShouldTriggerPageInit(true);
}
					KuikaAppManager.prepareForNavigation();

				stateVars.NAVIGATE = await ReactSystemFunctions.navigate(this, undefined, "MasterScreen", "ReportCashNebim", "", "currentPage", null, null, null, null, null, null, true, false);

		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

            
            return isErrorOccurred;
        }


		MasterScreenComponent_820866_onClick = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
KuikaAppManager.showSpinner(this);

const __currentPath = (window.location.hash ? window.location.hash.replace(/^#/, '').split('?')[0] : window.location.pathname.split('?')[0]).toLowerCase();
if (__currentPath !== "/technicalservicereports") {
  this.context.setMasterPageInitLoaded(false);
  this.context.setMasterPageRecurringLoaded(false);
  this.context.setShouldTriggerPageInit(true);
}
					KuikaAppManager.prepareForNavigation();

				stateVars.NAVIGATE = await ReactSystemFunctions.navigate(this, undefined, "MasterScreen", "TechnicalServiceReports", "", "currentPage", null, null, null, null, null, null, true, false);

		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

            
            return isErrorOccurred;
        }


		MasterScreenComponent_484693_onClick = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
KuikaAppManager.showSpinner(this);
		KuikaAppManager.increaseServerRequestCount();

				stateVars.Logout = await ReactSystemFunctions.logout();
				stateVars.tmpBoolResult = await ReactSystemFunctions.goToSignInActivity(this);

		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

            
            return isErrorOccurred;
        }




    async callCallbackFunction(diId: number, isFromMaster: boolean = false) {
        let isErrorOccurred = false;
		let pageInitCallerNavDiIDs = [608779, 747879842, , , , , , , , , , , , , , , , , , , , , , , , , ] as number[];
		if (isFromMaster || pageInitCallerNavDiIDs.indexOf(diId) > -1) {
			await this.MasterScreenPageInit();
		}
		this.context?.callCallbackFunction?.(diId, true);

    }


}
