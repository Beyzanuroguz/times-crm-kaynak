import React from "react";
import Axios, { AxiosResponse } from "axios";
import { KuikaAppManager } from "../../shared/utilty/kuika-app-manager";
import { ReactSystemFunctions } from "../../shared/utilty/react-system-functions";
import { KNavigator } from "../../shared/hoc/with-history";
import { KContext } from "../../shared/hoc/with-context";
import { useLocation } from "react-router-dom";
import { FormInstance } from "antd/es/form";
import { Guid } from "guid-typescript";
import Swal from "sweetalert2";
import { KMainFunctions } from "../../shared/utilty/main-functions";
import moment from "moment";
import { IValidationData } from "../../models/dto/validation-data";
import { IStripePayment } from "../../models/dto/stripe-payment";
import { IUserInfoDto } from "../../models/dto/user-info.dto";
import { UserService } from "../../services/user-service";
import { kuikaCoreWasmBridgeService } from "../../services/_singletons";
import _ from "lodash";
import mqtt, { MqttClient } from "mqtt";
import { IMqttResult } from "../../models/dto/mqtt.dto";


declare let window: any;

export interface ILeadDetailSalesPerson_ScreenProps {
  navigator: KNavigator;
  form: FormInstance<any>;
  googleLogin: any;
  screenInputs: any;
  context: KContext;
  initialValues: any;
  children: any;
}

export interface ILeadDetailSalesPerson_ScreenState {
    isSpinnerVisible: boolean;
    isPageVisible: boolean;
	isLeftMenuVisible: boolean;
    spinnerCount: number;
    selectedLanguage: string;
    isPageInitLoaded: false;
    isPageRecurringLoaded: false;
	TM_UserRoleByUserId: any[];
	TM_UserRoleByUserId_dummy: any[];
	TM_GetLeadById: any[];
	TM_GetLeadById_dummy: any[];
	TM_GetLeadProcessLogById: any[];
	TM_GetLeadProcessLogById_dummy: any[];
	TM_CheckLeadApprovalPermission: any[];
	TM_CheckLeadApprovalPermission_dummy: any[];
	TM_ProductList: any[];
	TM_ProductList_dummy: any[];
	TM_GetCustomerByName: any[];
	TM_GetCustomerByName_dummy: any[];
	GoBack: any;
	GoBack_dummy: any;
	ChangeVisibilityOf: string;
	ChangeVisibilityOf_dummy: string;
	ChangeEnabledOf: any;
	ChangeEnabledOf_dummy: any;
	TMLeadUpdateDetailSalesPerson: any[];
	TMLeadUpdateDetailSalesPerson_dummy: any[];
	TriggerEvent: string;
	TriggerEvent_dummy: string;
	isComp949400Visible: 'visible' | 'hidden';
	isComp67620Visible: 'visible' | 'hidden';
	isComp644441Visible: 'visible' | 'hidden';
	isComp831086Visible: 'visible' | 'hidden';
	isComp541169Visible: 'visible' | 'hidden';
	isComp865936Visible: 'visible' | 'hidden';
	isComp42351Visible: 'visible' | 'hidden';
	isComp55855Visible: 'visible' | 'hidden';
	isComp800106Visible: 'visible' | 'hidden';
	isComp632067Visible: 'visible' | 'hidden';
	isComp140179Visible: 'visible' | 'hidden';
	isComp574454Visible: 'visible' | 'hidden';
	isComp83818Visible: 'visible' | 'hidden';
	isComp819111Visible: 'visible' | 'hidden';
	isComp675255Visible: 'visible' | 'hidden';
	isComp712716Enabled: 'enabled' | 'disabled';
	isComp397748Enabled: 'enabled' | 'disabled';
	isComp188017Enabled: 'enabled' | 'disabled';
	isComp727006Enabled: 'enabled' | 'disabled';
	isComp812333Enabled: 'enabled' | 'disabled';

}

export class LeadDetailSalesPerson_ScreenBase extends React.PureComponent<ILeadDetailSalesPerson_ScreenProps, any> {

	leaddetailsalesperson_727006_value_kuikaSelectBoxRef: React.RefObject<any>;
	leaddetailsalesperson_812333_value_kuikaSelectBoxRef: React.RefObject<any>;
	leaddetailsalesperson_712716_value_kuikaSelectBoxRef: React.RefObject<any>;
	leaddetailsalesperson_397748_value_kuikaSelectBoxRef: React.RefObject<any>;
	leaddetailsalesperson_717760_value_kuikaTableRef: React.RefObject<any>;
    ml=[{"Id":"d5a61d2b-bd60-485f-86e2-661e9ed4e486","Name":"en_US","ShortName":"English","IsDefault":true,"LanguagePhrases":[]},{"Id":"258719b4-2e82-4493-abba-b88c13269b0b","Name":"FixedValues","ShortName":"FixedValues","LanguagePhrases":[{"Id":250318,"PropertyName":"value","Value":"Talep Bilgileri"},{"Id":644441,"PropertyName":"label","Value":"Düzenle"},{"Id":949400,"PropertyName":"label","Value":"Kaydet"},{"Id":67620,"PropertyName":"label","Value":"İptal"},{"Id":544730,"PropertyName":"value","Value":"Talep Özeti"},{"Id":897959,"PropertyName":"value","Value":"Mağaza"},{"Id":116245,"PropertyName":"value","Value":"Oluşturma Tarihi"},{"Id":287775,"PropertyName":"value","Value":"Termin Tarihi"},{"Id":727006,"PropertyName":"placeholder","Value":"Yıl"},{"Id":812333,"PropertyName":"placeholder","Value":"Ay"},{"Id":149101,"PropertyName":"value","Value":"Ürün Bilgileri"},{"Id":342706,"PropertyName":"value","Value":"Ürün Adı"},{"Id":712716,"PropertyName":"placeholder","Value":"Ürün seçiniz..."},{"Id":334422,"PropertyName":"value","Value":"Müşteri Bilgileri"},{"Id":306022,"PropertyName":"value","Value":"Müşteri Adı"},{"Id":397748,"PropertyName":"placeholder","Value":"Müşteri Seçiniz.."},{"Id":120451,"PropertyName":"value","Value":"İnfo"},{"Id":919800,"PropertyName":"value","Value":"Telefon No"},{"Id":876219,"PropertyName":"value","Value":"İletişim Kaynağı"},{"Id":626616,"PropertyName":"value","Value":"Alışveriş Yaptı Mı?"},{"Id":544840,"PropertyName":"value","Value":"Lokasyon"},{"Id":433195,"PropertyName":"value","Value":"/"},{"Id":791923,"PropertyName":"value","Value":"Referans Bilgileri"},{"Id":123288,"PropertyName":"value","Value":"Ad-Soyad"},{"Id":440579,"PropertyName":"value","Value":"1"},{"Id":555539,"PropertyName":"value","Value":"Kişi İnfo"},{"Id":599435,"PropertyName":"value","Value":"2"},{"Id":386406,"PropertyName":"value","Value":"Telefon No"},{"Id":65530,"PropertyName":"value","Value":"3"},{"Id":743480,"PropertyName":"value","Value":"Email"},{"Id":900989,"PropertyName":"value","Value":"4"},{"Id":161458,"PropertyName":"value","Value":"Referans Notu"},{"Id":513279,"PropertyName":"value","Value":"5"},{"Id":362230,"PropertyName":"value","Value":"Onay Bilgileri"},{"Id":407324,"PropertyName":"title","Value":"Title"},{"Id":83818,"PropertyName":"value","Value":"[datafield:processname]"},{"Id":819111,"PropertyName":"value","Value":"[datafield:processname]"},{"Id":675255,"PropertyName":"value","Value":"[datafield:processname]"},{"Id":336775,"PropertyName":"value","Value":"[datafield:note]"},{"Id":756853,"PropertyName":"value","Value":"[datafield:createdbyuser]"},{"Id":966237,"PropertyName":"value","Value":"[datafield:createdat]"},{"Id":334122,"PropertyName":"value","Value":"[datafield:rolenames]"}]}]
    defaultML = "en_US"
    
    screenHash = ""
    


    constructor(props) {
        super(props);
		this.leaddetailsalesperson_727006_value_kuikaSelectBoxRef = React.createRef();
		this.leaddetailsalesperson_812333_value_kuikaSelectBoxRef = React.createRef();
		this.leaddetailsalesperson_712716_value_kuikaSelectBoxRef = React.createRef();
		this.leaddetailsalesperson_397748_value_kuikaSelectBoxRef = React.createRef();
		this.leaddetailsalesperson_717760_value_kuikaTableRef = React.createRef();

        this.state = {
            isSpinnerVisible: false,
            isPageVisible: false,
            isLeftMenuVisible: false,
            spinnerCount: 0,
            selectedLanguage: "",
            isPageInitLoaded: false,
            isPageRecurringLoaded: false,
            	        TM_UserRoleByUserId: [],
	        TM_GetLeadById: [],
	        TM_GetLeadProcessLogById: [],
	        TM_CheckLeadApprovalPermission: [],
	        TM_ProductList: [],
	        TM_GetCustomerByName: [],
	        GoBack: "",
	        ChangeVisibilityOf: "",
	        ChangeEnabledOf: "",
	        TMLeadUpdateDetailSalesPerson: [],
	        TriggerEvent: "",
	        dataSource_727006: [{"key":"2025","text":"2025"},{"key":"2026","text":"2026"},{"key":"2027","text":"2027"},{"key":"2028","text":"2028"},{"key":"2029","text":"2029"},{"key":"2030","text":"2030"},{"key":"2031","text":"2031"},{"key":"2032","text":"2032"},{"key":"2033","text":"2033"},{"key":"2034","text":"2034"},{"key":"2035","text":"2035"}],
	        dataSource_812333: [{"key":"Ocak","text":"Ocak"},{"key":"Şubat","text":"Şubat"},{"key":"Mart","text":"Mart"},{"key":"Nisan","text":"Nisan"},{"key":"Mayıs","text":"Mayıs"},{"key":"Haziran","text":"Haziran"},{"key":"Temmuz","text":"Temmuz"},{"key":"Ağustos","text":"Ağustos"},{"key":"Eylül","text":"Eylül"},{"key":"Ekim","text":"Ekim"},{"key":"Kasım","text":"Kasım"},{"key":"Aralık","text":"Aralık"}],
	        isComp949400Visible: 'hidden',
	        isComp67620Visible: 'hidden',
	        isComp644441Visible: 'hidden',
	        isComp831086Visible: 'hidden',
	        isComp541169Visible: 'hidden',
	        isComp865936Visible: 'hidden',
	        isComp42351Visible: 'hidden',
	        isComp55855Visible: 'hidden',
	        isComp800106Visible: 'hidden',
	        isComp632067Visible: 'hidden',
	        isComp140179Visible: 'hidden',
	        isComp574454Visible: 'hidden',
	        isComp83818Visible: 'hidden',
	        isComp819111Visible: 'hidden',
	        isComp675255Visible: 'hidden',
	        isComp712716Enabled: 'disabled',
	        isComp397748Enabled: 'disabled',
	        isComp188017Enabled: 'disabled',
	        isComp727006Enabled: 'disabled',
	        isComp812333Enabled: 'disabled',

        }

        this.CheckPageAuthorization(this.state);

        
    }

    async componentDidMount() {

        if (KuikaAppManager.isPageInitPrevented()) {
            KuikaAppManager.calculateAndSetBodyHeight("leaddetailsalesperson", "");
            return;
        }
        
        
        ReactSystemFunctions.validateToken()
        this.fillFormInitValues();
        if (true){
            await this.LeadDetailSalesPersonPageInit();
        }
        
        
        
        KuikaAppManager.calculateAndSetBodyHeight("leaddetailsalesperson", "");

        if (ReactSystemFunctions.getIsMicroApp() === false) {
           window.parentScreen = this;
        }
    }

    componentWillUnmount() {
        
        
        

        if (ReactSystemFunctions.getIsMicroApp() === false) {
           window.parentScreen = null;
        }
    }

    
              CheckPageAuthorization = async (state) => {
                KuikaAppManager.showSpinner(this);
                if (_.isEmpty(window.userInfo)) {
                  await UserService.GetUserInfoForce();
                }
                const permittedRoleNames: string[] = ["TimesYonetici","TimesUstYonetici","TimesSatisPersoneli","TimesMagazaMuduru",];
                const userInfo = window.userInfo as IUserInfoDto;
                const userRoleNames = userInfo.roles.map((role) => role.name);
                if (!ReactSystemFunctions.hasAnyRoleName(permittedRoleNames, userRoleNames)) {
                  await ReactSystemFunctions.goBack(this);

                  const language = localStorage.getItem("ml");
                  let permissonErrorMessageText = "You do not have permission to access this page.";
                  if (language === "tr_TR") {
                    permissonErrorMessageText = "Bu sayfaya erişim yetkiniz yok.";
                  } else if (language === "fr_FR") {
                    permissonErrorMessageText = "Vous n'avez pas la permission d'accéder à cette page.";
                  } else if (language === "de_DE") {
                    permissonErrorMessageText = "Sie haben keine Berechtigung, auf diese Seite zuzugreifen.";
                  } else if (language === "es_ES") {
                    permissonErrorMessageText = "No tienes permiso para acceder a esta página.";
                  }

                  KMainFunctions.displayErrorNotification(permissonErrorMessageText);
                  state.isPageVisible = false;
                  KuikaAppManager.hideSpinner(this);
                  return;
                }
                state.isPageVisible = true;
                KuikaAppManager.hideSpinner(this);
              };
        

        
    componentDidUpdate= async (prevProps, prevState) => {
		KuikaAppManager.calculateAndSetBodyHeight("leaddetailsalesperson", ""    );
        if (prevProps?.location?.search !== (this.props as any)?.location?.search) {
			await this.LeadDetailSalesPersonPageInit();
		}

        

        if (ReactSystemFunctions.getIsMicroApp() === false) {
            for (const key in prevState) {
                if (key.startsWith('NavVisible') && prevState[key] === true && this.state[key] === false) {
                    window.parentScreen = this;
                    break;
                }
            }
        }
	}

    fillFormInitValues() {
        this.props.form?.setFieldsValue({
});

    }

      setPageInitLoaded = (value: boolean) => {
        this.setState({ isPageInitLoaded: value });
      }

      setPageRecurringLoaded = (value: boolean) => {
        this.setState({ isPageRecurringLoaded: value });
      }

      clearFieldValidation = (changedValues: any) => {
        const fieldName = Object.keys(changedValues)[0];
        if (fieldName) {
          this.props.form?.setFields([
            {
              name: fieldName,
              errors: []
            }
          ]);
        }
      };

      

    LeadDetailSalesPersonPageInit = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


	if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }

        let localVar = {
			UserID_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.getMyUserId(), "Guid"),
			LeadId_1: ReactSystemFunctions.convertToTypeByName(this.props.screenInputs.LeadId ?? this.props.screenInputs.leadid, "Guid"),
			Id_2: ReactSystemFunctions.convertToTypeByName(this.props.screenInputs.LeadId ?? this.props.screenInputs.leadid, "Guid"),
			IncomingUserRole_3: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, (stateVars.TM_UserRoleByUserId !== undefined ? (stateVars.TM_UserRoleByUserId?.length > 0 ? stateVars.TM_UserRoleByUserId[0].role : null) : (this.state.TM_UserRoleByUserId?.length > 0 ? this.state.TM_UserRoleByUserId[0].role : null))), "string"),
			IncomingLeadId_3: ReactSystemFunctions.convertToTypeByName(this.props.screenInputs.LeadId ?? this.props.screenInputs.leadid, "Guid"),
			Dial_4: ReactSystemFunctions.convertToTypeByName("", "string"),
			Brand_4: ReactSystemFunctions.convertToTypeByName("", "string"),
			Bracelet_4: ReactSystemFunctions.convertToTypeByName("", "string"),
			Referance_4: ReactSystemFunctions.convertToTypeByName("", "string"),
			CategoryName_4: ReactSystemFunctions.convertToTypeByName("", "string"),
			ProductName_4: ReactSystemFunctions.convertToTypeByName("", "string"),
			RMCCode_4: ReactSystemFunctions.convertToTypeByName("", "string")
        }

	KuikaAppManager.showSpinner(this);
	
        if (true) {
        KuikaAppManager.showSpinner(this);
        }
        let result = await KuikaAppManager.ApiRequest(this, "LeadDetailSalesPerson/LeadDetailSalesPersonPageInit", localVar)
        if (!KMainFunctions.IsResStatus2XX(result)) return true;

		stateVars.TM_UserRoleByUserId = result?.data.tM_UserRoleByUserId;
		stateVars.isComp188017Enabled = (((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.toString(this, (stateVars.TM_UserRoleByUserId !== undefined ? (stateVars.TM_UserRoleByUserId?.length > 0 ? stateVars.TM_UserRoleByUserId[0].roleNames : null) : (this.state.TM_UserRoleByUserId?.length > 0 ? this.state.TM_UserRoleByUserId[0].roleNames : null))), ReactSystemFunctions.convertToTypeByName("Mağaza Müdürü", "string")) && ReactSystemFunctions.isNotEqualTo(ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadById !== undefined ? (stateVars.TM_GetLeadById?.length > 0 ? stateVars.TM_GetLeadById[0].processName : null) : (this.state.TM_GetLeadById?.length > 0 ? this.state.TM_GetLeadById[0].processName : null))), ReactSystemFunctions.convertToTypeByName("Onaylandı", "string")) && ReactSystemFunctions.isNotEqualTo(ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadById !== undefined ? (stateVars.TM_GetLeadById?.length > 0 ? stateVars.TM_GetLeadById[0].processName : null) : (this.state.TM_GetLeadById?.length > 0 ? this.state.TM_GetLeadById[0].processName : null))), ReactSystemFunctions.convertToTypeByName("Reddedildi", "string")))) === true ? "enabled" : "disabled")
		stateVars.TM_GetLeadById = result?.data.tM_GetLeadById;
		formVars.leaddetailsalesperson_591206_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadById !== undefined ? (stateVars.TM_GetLeadById?.length > 0 ? stateVars.TM_GetLeadById[0].magaza : null) : (this.state.TM_GetLeadById?.length > 0 ? this.state.TM_GetLeadById[0].magaza : null)));
		formVars.leaddetailsalesperson_514003_value = ReactSystemFunctions.value(this, (stateVars.TM_GetLeadById !== undefined ? (stateVars.TM_GetLeadById?.length > 0 ? stateVars.TM_GetLeadById[0].talepOlusturmaTarihi : null) : (this.state.TM_GetLeadById?.length > 0 ? this.state.TM_GetLeadById[0].talepOlusturmaTarihi : null)));
		formVars.leaddetailsalesperson_712716_value = (stateVars.TM_GetLeadById !== undefined ? (stateVars.TM_GetLeadById?.length > 0 ? stateVars.TM_GetLeadById[0].productId : null) : (this.state.TM_GetLeadById?.length > 0 ? this.state.TM_GetLeadById[0].productId : null));
		formVars.leaddetailsalesperson_712716_options = stateVars.TM_ProductList;
		formVars.leaddetailsalesperson_397748_value = (stateVars.TM_GetLeadById !== undefined ? (stateVars.TM_GetLeadById?.length > 0 ? stateVars.TM_GetLeadById[0].customerId : null) : (this.state.TM_GetLeadById?.length > 0 ? this.state.TM_GetLeadById[0].customerId : null));
		formVars.leaddetailsalesperson_397748_options = stateVars.TM_GetCustomerByName;
		formVars.leaddetailsalesperson_831086_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadById !== undefined ? (stateVars.TM_GetLeadById?.length > 0 ? stateVars.TM_GetLeadById[0].musteriInfo : null) : (this.state.TM_GetLeadById?.length > 0 ? this.state.TM_GetLeadById[0].musteriInfo : null)));
		formVars.leaddetailsalesperson_865936_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadById !== undefined ? (stateVars.TM_GetLeadById?.length > 0 ? stateVars.TM_GetLeadById[0].telefonNo : null) : (this.state.TM_GetLeadById?.length > 0 ? this.state.TM_GetLeadById[0].telefonNo : null)));
		formVars.leaddetailsalesperson_574590_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadById !== undefined ? (stateVars.TM_GetLeadById?.length > 0 ? stateVars.TM_GetLeadById[0].iletisimKaynagi : null) : (this.state.TM_GetLeadById?.length > 0 ? this.state.TM_GetLeadById[0].iletisimKaynagi : null)));
		formVars.leaddetailsalesperson_800106_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadById !== undefined ? (stateVars.TM_GetLeadById?.length > 0 ? stateVars.TM_GetLeadById[0].alisverisYaptiMi : null) : (this.state.TM_GetLeadById?.length > 0 ? this.state.TM_GetLeadById[0].alisverisYaptiMi : null)));
		formVars.leaddetailsalesperson_140179_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadById !== undefined ? (stateVars.TM_GetLeadById?.length > 0 ? stateVars.TM_GetLeadById[0].lokasyon : null) : (this.state.TM_GetLeadById?.length > 0 ? this.state.TM_GetLeadById[0].lokasyon : null)));
		formVars.leaddetailsalesperson_574454_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadById !== undefined ? (stateVars.TM_GetLeadById?.length > 0 ? stateVars.TM_GetLeadById[0].ilce : null) : (this.state.TM_GetLeadById?.length > 0 ? this.state.TM_GetLeadById[0].ilce : null)));
		stateVars.isComp644441Visible = (((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadById !== undefined ? (stateVars.TM_GetLeadById?.length > 0 ? stateVars.TM_GetLeadById[0].processName : null) : (this.state.TM_GetLeadById?.length > 0 ? this.state.TM_GetLeadById[0].processName : null))), ReactSystemFunctions.convertToTypeByName("Oluşturuldu", "string")) || ReactSystemFunctions.isEqualTo(ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadById !== undefined ? (stateVars.TM_GetLeadById?.length > 0 ? stateVars.TM_GetLeadById[0].processName : null) : (this.state.TM_GetLeadById?.length > 0 ? this.state.TM_GetLeadById[0].processName : null))), ReactSystemFunctions.convertToTypeByName("Termin Bekliyor", "string")))) === true ? "visible" : "hidden")
		stateVars.isComp831086Visible = ((ReactSystemFunctions.isNotEmpty(ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadById !== undefined ? (stateVars.TM_GetLeadById?.length > 0 ? stateVars.TM_GetLeadById[0].musteriInfo : null) : (this.state.TM_GetLeadById?.length > 0 ? this.state.TM_GetLeadById[0].musteriInfo : null))), ReactSystemFunctions.convertToTypeByName("True", "string"))) === true ? "visible" : "hidden")
		stateVars.isComp541169Visible = ((ReactSystemFunctions.isEmpty(ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadById !== undefined ? (stateVars.TM_GetLeadById?.length > 0 ? stateVars.TM_GetLeadById[0].musteriInfo : null) : (this.state.TM_GetLeadById?.length > 0 ? this.state.TM_GetLeadById[0].musteriInfo : null))), ReactSystemFunctions.convertToTypeByName("True", "string"))) === true ? "visible" : "hidden")
		stateVars.isComp865936Visible = ((ReactSystemFunctions.isNotEmpty(ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadById !== undefined ? (stateVars.TM_GetLeadById?.length > 0 ? stateVars.TM_GetLeadById[0].telefonNo : null) : (this.state.TM_GetLeadById?.length > 0 ? this.state.TM_GetLeadById[0].telefonNo : null))), ReactSystemFunctions.convertToTypeByName("True", "string"))) === true ? "visible" : "hidden")
		stateVars.isComp42351Visible = ((ReactSystemFunctions.isEmpty(ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadById !== undefined ? (stateVars.TM_GetLeadById?.length > 0 ? stateVars.TM_GetLeadById[0].telefonNo : null) : (this.state.TM_GetLeadById?.length > 0 ? this.state.TM_GetLeadById[0].telefonNo : null))), ReactSystemFunctions.convertToTypeByName("True", "string"))) === true ? "visible" : "hidden")
		stateVars.isComp55855Visible = ((ReactSystemFunctions.isEmpty(ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadById !== undefined ? (stateVars.TM_GetLeadById?.length > 0 ? stateVars.TM_GetLeadById[0].iletisimKaynagi : null) : (this.state.TM_GetLeadById?.length > 0 ? this.state.TM_GetLeadById[0].iletisimKaynagi : null))), ReactSystemFunctions.convertToTypeByName("True", "string"))) === true ? "visible" : "hidden")
		stateVars.isComp800106Visible = ((ReactSystemFunctions.isNotEmpty(ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadById !== undefined ? (stateVars.TM_GetLeadById?.length > 0 ? stateVars.TM_GetLeadById[0].telefonNo : null) : (this.state.TM_GetLeadById?.length > 0 ? this.state.TM_GetLeadById[0].telefonNo : null))), ReactSystemFunctions.convertToTypeByName("True", "string"))) === true ? "visible" : "hidden")
		stateVars.isComp632067Visible = ((ReactSystemFunctions.isEmpty(ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadById !== undefined ? (stateVars.TM_GetLeadById?.length > 0 ? stateVars.TM_GetLeadById[0].telefonNo : null) : (this.state.TM_GetLeadById?.length > 0 ? this.state.TM_GetLeadById[0].telefonNo : null))), ReactSystemFunctions.convertToTypeByName("True", "string"))) === true ? "visible" : "hidden")
		stateVars.isComp140179Visible = ((ReactSystemFunctions.isNotEmpty(ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadById !== undefined ? (stateVars.TM_GetLeadById?.length > 0 ? stateVars.TM_GetLeadById[0].lokasyon : null) : (this.state.TM_GetLeadById?.length > 0 ? this.state.TM_GetLeadById[0].lokasyon : null))), ReactSystemFunctions.convertToTypeByName("True", "string"))) === true ? "visible" : "hidden")
		stateVars.isComp574454Visible = ((ReactSystemFunctions.isNotEmpty(ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadById !== undefined ? (stateVars.TM_GetLeadById?.length > 0 ? stateVars.TM_GetLeadById[0].ilce : null) : (this.state.TM_GetLeadById?.length > 0 ? this.state.TM_GetLeadById[0].ilce : null))), ReactSystemFunctions.convertToTypeByName("True", "string"))) === true ? "visible" : "hidden")
		stateVars.isComp188017Enabled = (((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.toString(this, (stateVars.TM_UserRoleByUserId !== undefined ? (stateVars.TM_UserRoleByUserId?.length > 0 ? stateVars.TM_UserRoleByUserId[0].roleNames : null) : (this.state.TM_UserRoleByUserId?.length > 0 ? this.state.TM_UserRoleByUserId[0].roleNames : null))), ReactSystemFunctions.convertToTypeByName("Mağaza Müdürü", "string")) && ReactSystemFunctions.isNotEqualTo(ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadById !== undefined ? (stateVars.TM_GetLeadById?.length > 0 ? stateVars.TM_GetLeadById[0].processName : null) : (this.state.TM_GetLeadById?.length > 0 ? this.state.TM_GetLeadById[0].processName : null))), ReactSystemFunctions.convertToTypeByName("Onaylandı", "string")) && ReactSystemFunctions.isNotEqualTo(ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadById !== undefined ? (stateVars.TM_GetLeadById?.length > 0 ? stateVars.TM_GetLeadById[0].processName : null) : (this.state.TM_GetLeadById?.length > 0 ? this.state.TM_GetLeadById[0].processName : null))), ReactSystemFunctions.convertToTypeByName("Reddedildi", "string")))) === true ? "enabled" : "disabled")
		stateVars.TM_GetLeadProcessLogById = result?.data.tM_GetLeadProcessLogById;
		
		stateVars.TM_CheckLeadApprovalPermission = result?.data.tM_CheckLeadApprovalPermission;
		stateVars.TM_ProductList = result?.data.tM_ProductList;
		
		formVars.leaddetailsalesperson_712716_value = (stateVars.TM_GetLeadById !== undefined ? (stateVars.TM_GetLeadById?.length > 0 ? stateVars.TM_GetLeadById[0].productId : null) : (this.state.TM_GetLeadById?.length > 0 ? this.state.TM_GetLeadById[0].productId : null));
		formVars.leaddetailsalesperson_712716_options = stateVars.TM_ProductList;
		stateVars.TM_GetCustomerByName = result?.data.tM_GetCustomerByName;
		
		formVars.leaddetailsalesperson_397748_value = (stateVars.TM_GetLeadById !== undefined ? (stateVars.TM_GetLeadById?.length > 0 ? stateVars.TM_GetLeadById[0].customerId : null) : (this.state.TM_GetLeadById?.length > 0 ? this.state.TM_GetLeadById[0].customerId : null));
		formVars.leaddetailsalesperson_397748_options = stateVars.TM_GetCustomerByName;
		this.props.form?.setFieldsValue(formVars);
		
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.LeadDetailSalesPersonPageInit1_();
                  resolve();
                });
          })



        
        KuikaAppManager.hideSpinner(this);
        return isErrorOccurred;
    }
	LeadDetailSalesPersonPageInit1_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


	if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }

			stateVars.isComp644441Visible = (((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadById !== undefined ? (stateVars.TM_GetLeadById?.length > 0 ? stateVars.TM_GetLeadById[0].processName : null) : (this.state.TM_GetLeadById?.length > 0 ? this.state.TM_GetLeadById[0].processName : null))), ReactSystemFunctions.convertToTypeByName("Oluşturuldu", "string")) || ReactSystemFunctions.isEqualTo(ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadById !== undefined ? (stateVars.TM_GetLeadById?.length > 0 ? stateVars.TM_GetLeadById[0].processName : null) : (this.state.TM_GetLeadById?.length > 0 ? this.state.TM_GetLeadById[0].processName : null))), ReactSystemFunctions.convertToTypeByName("Termin Bekliyor", "string")))) === true ? "visible" : "hidden")
			formVars.leaddetailsalesperson_591206_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadById !== undefined ? (stateVars.TM_GetLeadById?.length > 0 ? stateVars.TM_GetLeadById[0].magaza : null) : (this.state.TM_GetLeadById?.length > 0 ? this.state.TM_GetLeadById[0].magaza : null)));

			formVars.leaddetailsalesperson_514003_value = ReactSystemFunctions.value(this, (stateVars.TM_GetLeadById !== undefined ? (stateVars.TM_GetLeadById?.length > 0 ? stateVars.TM_GetLeadById[0].talepOlusturmaTarihi : null) : (this.state.TM_GetLeadById?.length > 0 ? this.state.TM_GetLeadById[0].talepOlusturmaTarihi : null)));

			stateVars.isComp188017Enabled = (((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.toString(this, (stateVars.TM_UserRoleByUserId !== undefined ? (stateVars.TM_UserRoleByUserId?.length > 0 ? stateVars.TM_UserRoleByUserId[0].roleNames : null) : (this.state.TM_UserRoleByUserId?.length > 0 ? this.state.TM_UserRoleByUserId[0].roleNames : null))), ReactSystemFunctions.convertToTypeByName("Mağaza Müdürü", "string")) && ReactSystemFunctions.isNotEqualTo(ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadById !== undefined ? (stateVars.TM_GetLeadById?.length > 0 ? stateVars.TM_GetLeadById[0].processName : null) : (this.state.TM_GetLeadById?.length > 0 ? this.state.TM_GetLeadById[0].processName : null))), ReactSystemFunctions.convertToTypeByName("Onaylandı", "string")) && ReactSystemFunctions.isNotEqualTo(ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadById !== undefined ? (stateVars.TM_GetLeadById?.length > 0 ? stateVars.TM_GetLeadById[0].processName : null) : (this.state.TM_GetLeadById?.length > 0 ? this.state.TM_GetLeadById[0].processName : null))), ReactSystemFunctions.convertToTypeByName("Reddedildi", "string")))) === true ? "enabled" : "disabled")
			formVars.leaddetailsalesperson_712716_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadById !== undefined ? (stateVars.TM_GetLeadById?.length > 0 ? stateVars.TM_GetLeadById[0].productId : null) : (this.state.TM_GetLeadById?.length > 0 ? this.state.TM_GetLeadById[0].productId : null)));

			
			stateVars.dataSource_712716 = stateVars.TM_ProductList ?? this.state.TM_ProductList;
			stateVars.dataSource_712716 = stateVars.TM_ProductList ?? this.state.TM_ProductList;
			formVars.leaddetailsalesperson_397748_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadById !== undefined ? (stateVars.TM_GetLeadById?.length > 0 ? stateVars.TM_GetLeadById[0].customerId : null) : (this.state.TM_GetLeadById?.length > 0 ? this.state.TM_GetLeadById[0].customerId : null)));

			
			stateVars.dataSource_397748 = stateVars.TM_GetCustomerByName ?? this.state.TM_GetCustomerByName;
			stateVars.dataSource_397748 = stateVars.TM_GetCustomerByName ?? this.state.TM_GetCustomerByName;
			formVars.leaddetailsalesperson_831086_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadById !== undefined ? (stateVars.TM_GetLeadById?.length > 0 ? stateVars.TM_GetLeadById[0].musteriInfo : null) : (this.state.TM_GetLeadById?.length > 0 ? this.state.TM_GetLeadById[0].musteriInfo : null)));

			stateVars.isComp831086Visible = ((ReactSystemFunctions.isNotEmpty(ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadById !== undefined ? (stateVars.TM_GetLeadById?.length > 0 ? stateVars.TM_GetLeadById[0].musteriInfo : null) : (this.state.TM_GetLeadById?.length > 0 ? this.state.TM_GetLeadById[0].musteriInfo : null))), ReactSystemFunctions.convertToTypeByName("True", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp541169Visible = ((ReactSystemFunctions.isEmpty(ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadById !== undefined ? (stateVars.TM_GetLeadById?.length > 0 ? stateVars.TM_GetLeadById[0].musteriInfo : null) : (this.state.TM_GetLeadById?.length > 0 ? this.state.TM_GetLeadById[0].musteriInfo : null))), ReactSystemFunctions.convertToTypeByName("True", "string"))) === true ? "visible" : "hidden")
			formVars.leaddetailsalesperson_865936_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadById !== undefined ? (stateVars.TM_GetLeadById?.length > 0 ? stateVars.TM_GetLeadById[0].telefonNo : null) : (this.state.TM_GetLeadById?.length > 0 ? this.state.TM_GetLeadById[0].telefonNo : null)));

			stateVars.isComp865936Visible = ((ReactSystemFunctions.isNotEmpty(ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadById !== undefined ? (stateVars.TM_GetLeadById?.length > 0 ? stateVars.TM_GetLeadById[0].telefonNo : null) : (this.state.TM_GetLeadById?.length > 0 ? this.state.TM_GetLeadById[0].telefonNo : null))), ReactSystemFunctions.convertToTypeByName("True", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp42351Visible = ((ReactSystemFunctions.isEmpty(ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadById !== undefined ? (stateVars.TM_GetLeadById?.length > 0 ? stateVars.TM_GetLeadById[0].telefonNo : null) : (this.state.TM_GetLeadById?.length > 0 ? this.state.TM_GetLeadById[0].telefonNo : null))), ReactSystemFunctions.convertToTypeByName("True", "string"))) === true ? "visible" : "hidden")
			formVars.leaddetailsalesperson_574590_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadById !== undefined ? (stateVars.TM_GetLeadById?.length > 0 ? stateVars.TM_GetLeadById[0].iletisimKaynagi : null) : (this.state.TM_GetLeadById?.length > 0 ? this.state.TM_GetLeadById[0].iletisimKaynagi : null)));

			stateVars.isComp55855Visible = ((ReactSystemFunctions.isEmpty(ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadById !== undefined ? (stateVars.TM_GetLeadById?.length > 0 ? stateVars.TM_GetLeadById[0].iletisimKaynagi : null) : (this.state.TM_GetLeadById?.length > 0 ? this.state.TM_GetLeadById[0].iletisimKaynagi : null))), ReactSystemFunctions.convertToTypeByName("True", "string"))) === true ? "visible" : "hidden")
			formVars.leaddetailsalesperson_800106_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadById !== undefined ? (stateVars.TM_GetLeadById?.length > 0 ? stateVars.TM_GetLeadById[0].alisverisYaptiMi : null) : (this.state.TM_GetLeadById?.length > 0 ? this.state.TM_GetLeadById[0].alisverisYaptiMi : null)));

			stateVars.isComp800106Visible = ((ReactSystemFunctions.isNotEmpty(ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadById !== undefined ? (stateVars.TM_GetLeadById?.length > 0 ? stateVars.TM_GetLeadById[0].telefonNo : null) : (this.state.TM_GetLeadById?.length > 0 ? this.state.TM_GetLeadById[0].telefonNo : null))), ReactSystemFunctions.convertToTypeByName("True", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp632067Visible = ((ReactSystemFunctions.isEmpty(ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadById !== undefined ? (stateVars.TM_GetLeadById?.length > 0 ? stateVars.TM_GetLeadById[0].telefonNo : null) : (this.state.TM_GetLeadById?.length > 0 ? this.state.TM_GetLeadById[0].telefonNo : null))), ReactSystemFunctions.convertToTypeByName("True", "string"))) === true ? "visible" : "hidden")
			formVars.leaddetailsalesperson_140179_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadById !== undefined ? (stateVars.TM_GetLeadById?.length > 0 ? stateVars.TM_GetLeadById[0].lokasyon : null) : (this.state.TM_GetLeadById?.length > 0 ? this.state.TM_GetLeadById[0].lokasyon : null)));

			stateVars.isComp140179Visible = ((ReactSystemFunctions.isNotEmpty(ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadById !== undefined ? (stateVars.TM_GetLeadById?.length > 0 ? stateVars.TM_GetLeadById[0].lokasyon : null) : (this.state.TM_GetLeadById?.length > 0 ? this.state.TM_GetLeadById[0].lokasyon : null))), ReactSystemFunctions.convertToTypeByName("True", "string"))) === true ? "visible" : "hidden")
			formVars.leaddetailsalesperson_574454_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadById !== undefined ? (stateVars.TM_GetLeadById?.length > 0 ? stateVars.TM_GetLeadById[0].ilce : null) : (this.state.TM_GetLeadById?.length > 0 ? this.state.TM_GetLeadById[0].ilce : null)));

			stateVars.isComp574454Visible = ((ReactSystemFunctions.isNotEmpty(ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadById !== undefined ? (stateVars.TM_GetLeadById?.length > 0 ? stateVars.TM_GetLeadById[0].ilce : null) : (this.state.TM_GetLeadById?.length > 0 ? this.state.TM_GetLeadById[0].ilce : null))), ReactSystemFunctions.convertToTypeByName("True", "string"))) === true ? "visible" : "hidden")
			
			stateVars.dataSource_717760 = stateVars.TM_GetLeadProcessLogById ?? this.state.TM_GetLeadProcessLogById;
			stateVars.isComp83818Visible = (((ReactSystemFunctions.isNotEqualTo(ReactSystemFunctions.value(this, "leaddetailsalesperson_717760_value", "processName"), ReactSystemFunctions.convertToTypeByName("Reddedildi", "string")) && ReactSystemFunctions.isNotEqualTo(ReactSystemFunctions.value(this, "leaddetailsalesperson_717760_value", "processName"), ReactSystemFunctions.convertToTypeByName("Onaylandı", "string")))) === true ? "visible" : "hidden")
			stateVars.isComp819111Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, "leaddetailsalesperson_717760_value", "processName"), ReactSystemFunctions.convertToTypeByName("Reddedildi", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp675255Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, "leaddetailsalesperson_717760_value", "processName"), ReactSystemFunctions.convertToTypeByName("Onaylandı", "string"))) === true ? "visible" : "hidden")

	this.props.form?.setFieldsValue(formVars);
	this.setState(stateVars);
	KuikaAppManager.hideSpinner(this);

            this.setPageInitLoaded(true);
            return isErrorOccurred;
        }




		LeadDetailSalesPersonComponent_5757_onClick = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
KuikaAppManager.showSpinner(this);

				stateVars.GoBack = await ReactSystemFunctions.goBack(this, false);

		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

            
            return isErrorOccurred;
        }


		LeadDetailSalesPersonComponent_644441_onClick = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
KuikaAppManager.showSpinner(this);

				stateVars.ChangeVisibilityOf = await ReactSystemFunctions.changeVisibilityOf(this, ReactSystemFunctions.convertToTypeByName("isComp949400Visible", "string"), ReactSystemFunctions.convertToTypeByName("visible", "string"));
				stateVars.ChangeVisibilityOf = await ReactSystemFunctions.changeVisibilityOf(this, ReactSystemFunctions.convertToTypeByName("isComp67620Visible", "string"), ReactSystemFunctions.convertToTypeByName("visible", "string"));
				stateVars.ChangeVisibilityOf = await ReactSystemFunctions.changeVisibilityOf(this, ReactSystemFunctions.convertToTypeByName("isComp644441Visible", "string"), ReactSystemFunctions.convertToTypeByName("hidden", "string"));
				stateVars.ChangeEnabledOf = await ReactSystemFunctions.changeEnabledOf(this, ReactSystemFunctions.convertToTypeByName("isComp712716Enabled", "string"), ReactSystemFunctions.convertToTypeByName("enabled", "string"));
				stateVars.ChangeEnabledOf = await ReactSystemFunctions.changeEnabledOf(this, ReactSystemFunctions.convertToTypeByName("isComp397748Enabled", "string"), ReactSystemFunctions.convertToTypeByName("enabled", "string"));

		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

            
            return isErrorOccurred;
        }


		LeadDetailSalesPersonComponent_949400_onClick = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
KuikaAppManager.showSpinner(this);

				stateVars.ChangeVisibilityOf = await ReactSystemFunctions.changeVisibilityOf(this, ReactSystemFunctions.convertToTypeByName("isComp67620Visible", "string"), ReactSystemFunctions.convertToTypeByName("hidden", "string"));
				stateVars.ChangeVisibilityOf = await ReactSystemFunctions.changeVisibilityOf(this, ReactSystemFunctions.convertToTypeByName("isComp644441Visible", "string"), ReactSystemFunctions.convertToTypeByName("visible", "string"));
				stateVars.ChangeVisibilityOf = await ReactSystemFunctions.changeVisibilityOf(this, ReactSystemFunctions.convertToTypeByName("isComp949400Visible", "string"), ReactSystemFunctions.convertToTypeByName("hidden", "string"));
				stateVars.ChangeEnabledOf = await ReactSystemFunctions.changeEnabledOf(this, ReactSystemFunctions.convertToTypeByName("isComp712716Enabled", "string"), ReactSystemFunctions.convertToTypeByName("disabled", "string"));
				stateVars.ChangeEnabledOf = await ReactSystemFunctions.changeEnabledOf(this, ReactSystemFunctions.convertToTypeByName("isComp397748Enabled", "string"), ReactSystemFunctions.convertToTypeByName("disabled", "string"));

		this.props.form?.setFieldsValue(formVars);
		
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.LeadDetailSalesPersonComponent_949400_onClick1_();
                  resolve();
                });
          })

            
            return isErrorOccurred;
        }
    LeadDetailSalesPersonComponent_949400_onClick1_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
		KuikaAppManager.increaseServerRequestCount();

        let localVar = {
				LeadId_0: ReactSystemFunctions.convertToTypeByName(this.props.screenInputs.LeadId ?? this.props.screenInputs.leadid, "Guid"),
				NewCustomerId_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "leaddetailsalesperson_397748_value", "value", "TM_GetCustomerByName", "id", "id")), "Guid"),
				NewProductId_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "leaddetailsalesperson_712716_value", "value", "TM_ProductList", "productId", "productId")), "Guid"),
				UpdatedBy_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.getMyUserId(), "Guid")
        }

		
        if (true) {
        KuikaAppManager.showSpinner(this);
        }
        let result = await KuikaAppManager.ApiRequest(this, "LeadDetailSalesPerson/LeadDetailSalesPersonComponent_949400_onClick1_", localVar)
        if (!KMainFunctions.IsResStatus2XX(result)) return true;

			stateVars.TMLeadUpdateDetailSalesPerson = result?.data.tmLeadUpdateDetailSalesPerson;
			this.props.form?.setFieldsValue(formVars);
			
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.LeadDetailSalesPersonComponent_949400_onClick2_();
                  resolve();
                });
          })



        
        KuikaAppManager.hideSpinner(this);
        return isErrorOccurred;
    }
		LeadDetailSalesPersonComponent_949400_onClick2_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }

				await this.LeadDetailSalesPersonPageInit();
				

		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

            
            return isErrorOccurred;
        }





		LeadDetailSalesPersonComponent_67620_onClick = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
KuikaAppManager.showSpinner(this);

				stateVars.ChangeVisibilityOf = await ReactSystemFunctions.changeVisibilityOf(this, ReactSystemFunctions.convertToTypeByName("isComp67620Visible", "string"), ReactSystemFunctions.convertToTypeByName("hidden", "string"));
				stateVars.ChangeVisibilityOf = await ReactSystemFunctions.changeVisibilityOf(this, ReactSystemFunctions.convertToTypeByName("isComp644441Visible", "string"), ReactSystemFunctions.convertToTypeByName("visible", "string"));
				stateVars.ChangeVisibilityOf = await ReactSystemFunctions.changeVisibilityOf(this, ReactSystemFunctions.convertToTypeByName("isComp949400Visible", "string"), ReactSystemFunctions.convertToTypeByName("hidden", "string"));
				stateVars.ChangeEnabledOf = await ReactSystemFunctions.changeEnabledOf(this, ReactSystemFunctions.convertToTypeByName("isComp712716Enabled", "string"), ReactSystemFunctions.convertToTypeByName("disabled", "string"));
				stateVars.ChangeEnabledOf = await ReactSystemFunctions.changeEnabledOf(this, ReactSystemFunctions.convertToTypeByName("isComp397748Enabled", "string"), ReactSystemFunctions.convertToTypeByName("disabled", "string"));
				await this.LeadDetailSalesPersonPageInit();
				

		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

            
            return isErrorOccurred;
        }




    async callCallbackFunction(diId: number, isFromMaster: boolean = false) {
        let isErrorOccurred = false;
		let pageInitCallerNavDiIDs = [] as number[];
		if (isFromMaster || pageInitCallerNavDiIDs.indexOf(diId) > -1) {
			await this.LeadDetailSalesPersonPageInit();
		}

    }


}
