import React from "react";
import Axios, { AxiosResponse } from "axios";
import { KuikaAppManager } from "../../shared/utilty/kuika-app-manager";
import { ReactSystemFunctions } from "../../shared/utilty/react-system-functions";
import { KNavigator } from "../../shared/hoc/with-history";
import { KContext } from "../../shared/hoc/with-context";
import { useLocation } from "react-router-dom";
import { FormInstance } from "antd/es/form";
import { Guid } from "guid-typescript";
import Swal from "sweetalert2";
import { KMainFunctions } from "../../shared/utilty/main-functions";
import moment from "moment";
import { IValidationData } from "../../models/dto/validation-data";
import { IStripePayment } from "../../models/dto/stripe-payment";
import { IUserInfoDto } from "../../models/dto/user-info.dto";
import { UserService } from "../../services/user-service";
import { kuikaCoreWasmBridgeService } from "../../services/_singletons";
import _ from "lodash";
import mqtt, { MqttClient } from "mqtt";
import { IMqttResult } from "../../models/dto/mqtt.dto";
import { MasterScreen_ScreenContext } from "../masterscreen/masterscreen-context";

declare let window: any;

export interface IReportCashNebim_ScreenProps {
  navigator: KNavigator;
  form: FormInstance<any>;
  googleLogin: any;
  screenInputs: any;
  context: KContext;
  initialValues: any;
  children: any;
}

export interface IReportCashNebim_ScreenState {
    isSpinnerVisible: boolean;
    isPageVisible: boolean;
	isLeftMenuVisible: boolean;
    spinnerCount: number;
    selectedLanguage: string;
    isPageInitLoaded: false;
    isPageRecurringLoaded: false;
	Connect: any;
	Connect_dummy: any;
	Notify: boolean;
	Notify_dummy: boolean;
	ChangeVisibilityOf: string;
	ChangeVisibilityOf_dummy: string;
	GetOfficeAndCompany: any[];
	GetOfficeAndCompany_dummy: any[];
	Kuika_KasaRaporuSatisSiparisleri1: any[];
	Kuika_KasaRaporuSatisSiparisleri1_dummy: any[];
	Kuika_SatisFaturalari2: any[];
	Kuika_SatisFaturalari2_dummy: any[];
	Kuika_NakitDevirler3: any[];
	Kuika_NakitDevirler3_dummy: any[];
	Kuika_KrediKartiTahsilatlari4: any[];
	Kuika_KrediKartiTahsilatlari4_dummy: any[];
	Kuika_BankaKontrol5: any[];
	Kuika_BankaKontrol5_dummy: any[];
	Kuika_TedarikciPosCekimleri6: any[];
	Kuika_TedarikciPosCekimleri6_dummy: any[];
	Kuika_Orders7: any[];
	Kuika_Orders7_dummy: any[];
	Kuika_Masraflar8: any[];
	Kuika_Masraflar8_dummy: any[];
	Kuika_CashDevir9: any[];
	Kuika_CashDevir9_dummy: any[];
	Kuika_KasaKalani10: any[];
	Kuika_KasaKalani10_dummy: any[];
	PrintReport: string;
	PrintReport_dummy: string;
	PrintPdf: string;
	PrintPdf_dummy: string;
	isComp272272649Visible: 'visible' | 'hidden';
	isComp731855Visible: 'visible' | 'hidden';
	isComp2054284029Enabled: 'enabled' | 'disabled';

}

export class ReportCashNebim_ScreenBase extends React.PureComponent<IReportCashNebim_ScreenProps, any> {
    static contextType = MasterScreen_ScreenContext;
    declare context: React.ContextType<typeof MasterScreen_ScreenContext>;
	reportcashnebim_1812032468_value_kuikaDateRef: React.RefObject<any>;
	reportcashnebim_150322063_value_kuikaTableRef: React.RefObject<any>;
	reportcashnebim_314371451_value_kuikaTableRef: React.RefObject<any>;
	reportcashnebim_1784203962_value_kuikaTableRef: React.RefObject<any>;
	reportcashnebim_2057450190_value_kuikaTableRef: React.RefObject<any>;
	reportcashnebim_353483336_value_kuikaTableRef: React.RefObject<any>;
	reportcashnebim_739616295_value_kuikaTableRef: React.RefObject<any>;
	reportcashnebim_49354912_value_kuikaTableRef: React.RefObject<any>;
	reportcashnebim_404047900_value_kuikaTableRef: React.RefObject<any>;
	reportcashnebim_1708045397_value_kuikaTableRef: React.RefObject<any>;
    ml=[{"Id":"d5a61d2b-bd60-485f-86e2-661e9ed4e486","Name":"en_US","ShortName":"English","IsDefault":true,"LanguagePhrases":[]},{"Id":"0746ade4-3b8c-4dbc-91c5-356ca4ec10a7","Name":"FixedValues","ShortName":"FixedValues","LanguagePhrases":[{"Id":757658759,"PropertyName":"value","Value":"Günlük Kasa Rapor Dökümleri"},{"Id":1659716133,"PropertyName":"value","Value":"Rapor Filtreleri"},{"Id":1812032468,"PropertyName":"placeholder","Value":"Tarih seçin"},{"Id":903085484,"PropertyName":"label","Value":"çalıştır"},{"Id":2054284029,"PropertyName":"label","Value":"Çalıştır ve PDF Al"},{"Id":1537206838,"PropertyName":"value","Value":"Günlük finansal hareketlerin ve kasa bakiyesinin özeti"},{"Id":181426300,"PropertyName":"value","Value":"İşlem Tarihi"},{"Id":1563064523,"PropertyName":"value","Value":"Kasa Tarihi"},{"Id":1888184847,"PropertyName":"value","Value":"Şirket Adı"},{"Id":598702924,"PropertyName":"value","Value":"Şube Kodu"},{"Id":1242266714,"PropertyName":"value","Value":"Satış Siparişleri"},{"Id":2079669844,"PropertyName":"title","Value":"Müşteri"},{"Id":734351674,"PropertyName":"value","Value":"[datafield:curraccdescription]"},{"Id":1848999783,"PropertyName":"title","Value":"Ürün Adı"},{"Id":405177110,"PropertyName":"value","Value":"[datafield:itemdescription]"},{"Id":955206479,"PropertyName":"title","Value":"Teslim Tarihi"},{"Id":132565656,"PropertyName":"value","Value":"[datafield:deliverydate]"},{"Id":1037037315,"PropertyName":"title","Value":"Satış Sorumlusu"},{"Id":35872001,"PropertyName":"value","Value":"[datafield:salespersonname]"},{"Id":845416544,"PropertyName":"title","Value":"Liste Fiyatı"},{"Id":1185428028,"PropertyName":"value","Value":"[datafield:doc_taxbase]"},{"Id":886751394,"PropertyName":"title","Value":"TRY Fiyatı"},{"Id":78510341,"PropertyName":"value","Value":"[datafield:doc_netamount]"},{"Id":597358452,"PropertyName":"title","Value":"%"},{"Id":964701176,"PropertyName":"value","Value":"[datafield:vatrate]"},{"Id":376923193,"PropertyName":"title","Value":"Satış Tutarı"},{"Id":459224973,"PropertyName":"value","Value":"[datafield:doc_netamount]"},{"Id":1937007998,"PropertyName":"title","Value":"Satış Tutarı TRY"},{"Id":967289114,"PropertyName":"value","Value":"[datafield:loc_netamount]"},{"Id":590440475,"PropertyName":"value","Value":"Satış Faturaları"},{"Id":1546438703,"PropertyName":"title","Value":"Müşteri Adı"},{"Id":354791619,"PropertyName":"value","Value":"[datafield:curraccdescription]"},{"Id":2078907269,"PropertyName":"title","Value":"E-Fatura Numarası"},{"Id":996572777,"PropertyName":"value","Value":"[datafield:einvoicenumber]"},{"Id":332273074,"PropertyName":"title","Value":"Ürün Adı"},{"Id":91900698,"PropertyName":"value","Value":"[datafield:itemdescription]"},{"Id":1962203588,"PropertyName":"title","Value":"Seri Numarası"},{"Id":990666754,"PropertyName":"value","Value":"[datafield:ürünserinumarası]"},{"Id":1994230070,"PropertyName":"title","Value":"DVZ"},{"Id":1038306066,"PropertyName":"value","Value":"[datafield:doc_currencycode]"},{"Id":548135199,"PropertyName":"title","Value":"Liste Fiyatı"},{"Id":1866822105,"PropertyName":"value","Value":"[datafield:doc_netamount]"},{"Id":2141725737,"PropertyName":"title","Value":"%"},{"Id":1749635083,"PropertyName":"value","Value":"[datafield:doc_ldiscountvitotal]"},{"Id":1176230418,"PropertyName":"title","Value":"Tutar"},{"Id":781948965,"PropertyName":"value","Value":"[datafield:doc_netamount]"},{"Id":1731901199,"PropertyName":"title","Value":"Tutar TRY"},{"Id":1694096688,"PropertyName":"value","Value":"[datafield:loc_netamount]"},{"Id":1278583982,"PropertyName":"value","Value":"Nakit Devirler"},{"Id":822412734,"PropertyName":"title","Value":"Kasa Kodu"},{"Id":1776013720,"PropertyName":"value","Value":"[datafield:curracccode]"},{"Id":1155721117,"PropertyName":"title","Value":"Kasa Adı"},{"Id":1216195421,"PropertyName":"value","Value":"[datafield:curraccdescription]"},{"Id":1513143729,"PropertyName":"title","Value":"Para Birimi"},{"Id":1511395456,"PropertyName":"value","Value":"[datafield:doc_currencycode]"},{"Id":879112923,"PropertyName":"title","Value":"Devir Bakiyesi"},{"Id":803025988,"PropertyName":"value","Value":"[datafield:doc_amount]"},{"Id":1871015984,"PropertyName":"title","Value":"Devir Bakiyesi TRY"},{"Id":1872921754,"PropertyName":"value","Value":"[datafield:loc_amount]"},{"Id":363959696,"PropertyName":"value","Value":"Nakit Tahsilatlar"},{"Id":795369432,"PropertyName":"title","Value":"Müşteri Kodu"},{"Id":1902695858,"PropertyName":"value","Value":"[datafield:curracccode]"},{"Id":961941361,"PropertyName":"title","Value":"Müşteri Adı"},{"Id":696384299,"PropertyName":"value","Value":"[datafield:curraccdescription]"},{"Id":454819592,"PropertyName":"title","Value":"Kasa Adı"},{"Id":44305713,"PropertyName":"value","Value":"[datafield:kasahesabiadi]"},{"Id":289249618,"PropertyName":"title","Value":"Peşin Tahsilat"},{"Id":218149155,"PropertyName":"value","Value":"[datafield:tahsil]"},{"Id":1433528990,"PropertyName":"title","Value":"Peşin Tahsilat TRY"},{"Id":1247360982,"PropertyName":"value","Value":"[datafield:tahsil1]"},{"Id":1424339268,"PropertyName":"value","Value":"Kasadan Bankaya Çıkış İşlemleri"},{"Id":1214859108,"PropertyName":"title","Value":"Kasa Kodu"},{"Id":2097156517,"PropertyName":"value","Value":"[datafield:cashcurracccode]"},{"Id":1309926253,"PropertyName":"title","Value":"Kasa Adı"},{"Id":57178200,"PropertyName":"value","Value":"[datafield:kasahesabiadi]"},{"Id":103777931,"PropertyName":"title","Value":"Banka Adı"},{"Id":455106783,"PropertyName":"value","Value":"[datafield:curraccdescription]"},{"Id":955827455,"PropertyName":"title","Value":"Açıklama"},{"Id":2103061807,"PropertyName":"value","Value":"[datafield:linedescription]"},{"Id":1715979067,"PropertyName":"title","Value":"Tutar"},{"Id":1738917614,"PropertyName":"value","Value":"[datafield:tediye]"},{"Id":932419584,"PropertyName":"title","Value":"Tutar TRY"},{"Id":1500915564,"PropertyName":"value","Value":"[datafield:tediye1]"},{"Id":1465747605,"PropertyName":"value","Value":"Gün Sonu Kasa Bakiyesi"},{"Id":946703363,"PropertyName":"title","Value":"Kasa Kodu"},{"Id":1297057038,"PropertyName":"value","Value":"[datafield:curracccode]"},{"Id":1067756356,"PropertyName":"title","Value":"Kasa Adı"},{"Id":36234713,"PropertyName":"value","Value":"[datafield:curraccdescription]"},{"Id":1777692324,"PropertyName":"title","Value":"Para Birimi"},{"Id":231333921,"PropertyName":"value","Value":"[datafield:currencycode]"},{"Id":578525400,"PropertyName":"title","Value":"Devir Bakiyesi"},{"Id":1130145780,"PropertyName":"value","Value":"[datafield:balance]"},{"Id":134084516,"PropertyName":"title","Value":"Devir Bakiyesi TRY"},{"Id":873222933,"PropertyName":"value","Value":"[datafield:balance1]"},{"Id":140718629,"PropertyName":"value","Value":"Kredi Kartı Tahsilatları"},{"Id":1193015978,"PropertyName":"title","Value":"Müşteri Kodu"},{"Id":230369329,"PropertyName":"value","Value":"[datafield:curracccode]"},{"Id":853574446,"PropertyName":"title","Value":"Müşteri Adı"},{"Id":1268586737,"PropertyName":"value","Value":"[datafield:curraccdescription]"},{"Id":1927476338,"PropertyName":"title","Value":"Satış Temsilcisi"},{"Id":1846504817,"PropertyName":"value","Value":"[datafield:customeratt02desc]"},{"Id":1559923801,"PropertyName":"title","Value":"Pos Banka Adı"},{"Id":1306937204,"PropertyName":"value","Value":"[datafield:poshesabiadi]"},{"Id":1464407117,"PropertyName":"title","Value":"Para Birimi"},{"Id":1524483698,"PropertyName":"value","Value":"[datafield:curracccurrencycode]"},{"Id":2092059830,"PropertyName":"title","Value":"Tutar"},{"Id":707066740,"PropertyName":"value","Value":"[datafield:curraccamount]"},{"Id":1349749064,"PropertyName":"title","Value":"Tutar TRY"},{"Id":1757618879,"PropertyName":"value","Value":"[datafield:doc_amount]"},{"Id":6762612,"PropertyName":"value","Value":"Banka Tahsilatları"},{"Id":860194792,"PropertyName":"title","Value":"Müşteri Kodu"},{"Id":741534217,"PropertyName":"value","Value":"[datafield:curracccode]"},{"Id":1867081971,"PropertyName":"title","Value":"Müşteri Adı"},{"Id":1335031577,"PropertyName":"value","Value":"[datafield:curraccdescription]"},{"Id":761537764,"PropertyName":"title","Value":"Dekont Numarası"},{"Id":401968444,"PropertyName":"value","Value":"[datafield:documentnumber]"},{"Id":961590700,"PropertyName":"title","Value":"Banka Adı"},{"Id":1258650308,"PropertyName":"value","Value":"[datafield:kasahesabiadi]"},{"Id":424883436,"PropertyName":"title","Value":"TRY"},{"Id":505051453,"PropertyName":"value","Value":"[datafield:loc_amount]"},{"Id":1033823296,"PropertyName":"title","Value":"DVZ"},{"Id":2004424310,"PropertyName":"value","Value":"[datafield:doc_amount]"},{"Id":1586610418,"PropertyName":"value","Value":"Masraf Dökümü"},{"Id":200985523,"PropertyName":"title","Value":"Evrak No"},{"Id":982337327,"PropertyName":"value","Value":"[datafield:invoicenumberep]"},{"Id":1753565527,"PropertyName":"title","Value":"Cari Ünvanı"},{"Id":1073133411,"PropertyName":"value","Value":"[datafield:vendordescription]"},{"Id":1066650772,"PropertyName":"title","Value":"Masraf Adı"},{"Id":995816424,"PropertyName":"value","Value":"[datafield:itemdescription]"},{"Id":1735846811,"PropertyName":"title","Value":"Açıklama"},{"Id":1020660103,"PropertyName":"value","Value":"[datafield:linedescription]"},{"Id":747107267,"PropertyName":"title","Value":"DVZ"},{"Id":2146109742,"PropertyName":"value","Value":"[datafield:doc_currencycode]"},{"Id":1424350646,"PropertyName":"title","Value":"Tutar"},{"Id":498764304,"PropertyName":"value","Value":"[datafield:doc_amount]"},{"Id":527286829,"PropertyName":"title","Value":"Tutar TRY"},{"Id":1431834881,"PropertyName":"value","Value":"[datafield:loc_amount]"},{"Id":697517824,"PropertyName":"value","Value":"Raporu Çalıştırınız"}]}]
    defaultML = "en_US"
    
    screenHash = ""
    

    private _prevMasterPageInitLoaded: boolean = false;
    private _prevMasterPageRecurringLoaded: boolean = false;
    private _prevShouldTriggerPageInit: boolean = false;
    constructor(props) {
        super(props);
		this.reportcashnebim_1812032468_value_kuikaDateRef = React.createRef();
		this.reportcashnebim_150322063_value_kuikaTableRef = React.createRef();
		this.reportcashnebim_314371451_value_kuikaTableRef = React.createRef();
		this.reportcashnebim_1784203962_value_kuikaTableRef = React.createRef();
		this.reportcashnebim_2057450190_value_kuikaTableRef = React.createRef();
		this.reportcashnebim_353483336_value_kuikaTableRef = React.createRef();
		this.reportcashnebim_739616295_value_kuikaTableRef = React.createRef();
		this.reportcashnebim_49354912_value_kuikaTableRef = React.createRef();
		this.reportcashnebim_404047900_value_kuikaTableRef = React.createRef();
		this.reportcashnebim_1708045397_value_kuikaTableRef = React.createRef();

        this.state = {
            isSpinnerVisible: false,
            isPageVisible: false,
            isLeftMenuVisible: false,
            spinnerCount: 0,
            selectedLanguage: "",
            isPageInitLoaded: false,
            isPageRecurringLoaded: false,
            	        Connect: "",
	        Notify: false,
	        ChangeVisibilityOf: "",
	        GetOfficeAndCompany: [],
	        Kuika_KasaRaporuSatisSiparisleri1: [],
	        Kuika_SatisFaturalari2: [],
	        Kuika_NakitDevirler3: [],
	        Kuika_KrediKartiTahsilatlari4: [],
	        Kuika_BankaKontrol5: [],
	        Kuika_TedarikciPosCekimleri6: [],
	        Kuika_Orders7: [],
	        Kuika_Masraflar8: [],
	        Kuika_CashDevir9: [],
	        Kuika_KasaKalani10: [],
	        PrintReport: "",
	        PrintPdf: "",
	        isComp272272649Visible: 'hidden',
	        isComp731855Visible: 'visible',
	        isComp2054284029Enabled: 'disabled',

        }

        this.state.isPageVisible = true;
        
    }

    async componentDidMount() {

        if (KuikaAppManager.isPageInitPrevented()) {
            KuikaAppManager.calculateAndSetBodyHeight("reportcashnebim", "masterscreen_screen");
            return;
        }
        this.context.registerCallbackFunction(this.callCallbackFunction.bind(this));
        
        ReactSystemFunctions.validateToken()
        this.fillFormInitValues();
        if (false){
            await this.ReportCashNebimPageInit();
        } else if (this.context?.isMasterPageInitLoaded) { this._prevMasterPageInitLoaded = true; await this.ReportCashNebimPageInit(); }
        
        
        
        KuikaAppManager.calculateAndSetBodyHeight("reportcashnebim", "masterscreen_screen");

        if (ReactSystemFunctions.getIsMicroApp() === false) {
           window.parentScreen = this;
        }
    }

    componentWillUnmount() {
        
        
        

        if (ReactSystemFunctions.getIsMicroApp() === false) {
           window.parentScreen = null;
        }
    }

    

        
    componentDidUpdate= async (prevProps, prevState) => {
		KuikaAppManager.calculateAndSetBodyHeight("reportcashnebim", "masterscreen_screen"    );
        if (prevProps?.location?.search !== (this.props as any)?.location?.search) {
			await this.ReportCashNebimPageInit();
		}

        		if (this._prevMasterPageInitLoaded !== this.context.isMasterPageInitLoaded && this.context.isMasterPageInitLoaded === true) {this._prevMasterPageInitLoaded = this.context.isMasterPageInitLoaded;await this.ReportCashNebimPageInit()}


        if (ReactSystemFunctions.getIsMicroApp() === false) {
            for (const key in prevState) {
                if (key.startsWith('NavVisible') && prevState[key] === true && this.state[key] === false) {
                    window.parentScreen = this;
                    break;
                }
            }
        }
	}

    fillFormInitValues() {
        this.props.form?.setFieldsValue({
reportcashnebim_1812032468_value: moment().format("YYYY-MM-DDTHH:mm:ss")
});

    }

      setPageInitLoaded = (value: boolean) => {
        this.setState({ isPageInitLoaded: value });
      }

      setPageRecurringLoaded = (value: boolean) => {
        this.setState({ isPageRecurringLoaded: value });
      }

      clearFieldValidation = (changedValues: any) => {
        const fieldName = Object.keys(changedValues)[0];
        if (fieldName) {
          this.props.form?.setFields([
            {
              name: fieldName,
              errors: []
            }
          ]);
        }
      };

      

    ReportCashNebimPageInit = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


	if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }

        let localVar = {
        }

	KuikaAppManager.showSpinner(this);
	
        if (true) {
        KuikaAppManager.showSpinner(this);
        }
        let result = await KuikaAppManager.ApiRequest(this, "ReportCashNebim/ReportCashNebimPageInit", localVar)
        if (!KMainFunctions.IsResStatus2XX(result)) return true;

		this.props.form?.setFieldsValue(formVars);
		
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.ReportCashNebimPageInit1_();
                  resolve();
                });
          })



        
        KuikaAppManager.hideSpinner(this);
        return isErrorOccurred;
    }
	ReportCashNebimPageInit1_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


	if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }

			ReactSystemFunctions.setValueOf(this, "reportcashnebim_1140736150_value", ReactSystemFunctions.value(this, "reportcashnebim_1812032468_value", "value"), "value");


	this.props.form?.setFieldsValue(formVars);
	this.setState(stateVars);
	KuikaAppManager.hideSpinner(this);

            this.setPageInitLoaded(true);
            return isErrorOccurred;
        }




		ReportCashNebimComponent_903085484_onClick = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
KuikaAppManager.showSpinner(this);

				stateVars.Notify = await ReactSystemFunctions.notify(this, ReactSystemFunctions.translateCustomActions(this.ml,"32b774ee_fa1a_08b6_00dc_8c8b2cf66dd9_notify",this.defaultML,"Yükleniyor, lütfen bekleyiniz" ), ReactSystemFunctions.convertToTypeByName("default", "string"), ReactSystemFunctions.convertToTypeByName("top-center", "string"), 5, ReactSystemFunctions.convertToTypeByName("", "string"), ReactSystemFunctions.convertToTypeByName("", "string"), 0);
				stateVars.ChangeVisibilityOf = await ReactSystemFunctions.changeVisibilityOf(this, ReactSystemFunctions.convertToTypeByName("isComp272272649Visible", "string"), ReactSystemFunctions.convertToTypeByName("visible", "string"));
				stateVars.ChangeVisibilityOf = await ReactSystemFunctions.changeVisibilityOf(this, ReactSystemFunctions.convertToTypeByName("isComp731855Visible", "string"), ReactSystemFunctions.convertToTypeByName("hidden", "string"));

		this.props.form?.setFieldsValue(formVars);
		
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.ReportCashNebimComponent_903085484_onClick1_();
                  resolve();
                });
          })

            
            return isErrorOccurred;
        }
    ReportCashNebimComponent_903085484_onClick1_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
		KuikaAppManager.increaseServerRequestCount();

        let localVar = {
				KUserId_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.getMyUserId(), "Guid"),
				Date_1: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "reportcashnebim_1812032468_value", "value", "", "", "")), "string"),
				CompanyCode_1: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toInteger(this, (stateVars.GetOfficeAndCompany !== undefined ? (stateVars.GetOfficeAndCompany?.length > 0 ? stateVars.GetOfficeAndCompany[0].companyCode : null) : (this.state.GetOfficeAndCompany?.length > 0 ? this.state.GetOfficeAndCompany[0].companyCode : null))), "number"),
				OfficeCode_1: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, (stateVars.GetOfficeAndCompany !== undefined ? (stateVars.GetOfficeAndCompany?.length > 0 ? stateVars.GetOfficeAndCompany[0].officeCode : null) : (this.state.GetOfficeAndCompany?.length > 0 ? this.state.GetOfficeAndCompany[0].officeCode : null))), "string"),
				OperationDate_2: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "reportcashnebim_1812032468_value", "value", "", "", "")), "string"),
				CompanyCode_2: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toInteger(this, (stateVars.GetOfficeAndCompany !== undefined ? (stateVars.GetOfficeAndCompany?.length > 0 ? stateVars.GetOfficeAndCompany[0].companyCode : null) : (this.state.GetOfficeAndCompany?.length > 0 ? this.state.GetOfficeAndCompany[0].companyCode : null))), "number"),
				OfficeCode_2: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, (stateVars.GetOfficeAndCompany !== undefined ? (stateVars.GetOfficeAndCompany?.length > 0 ? stateVars.GetOfficeAndCompany[0].officeCode : null) : (this.state.GetOfficeAndCompany?.length > 0 ? this.state.GetOfficeAndCompany[0].officeCode : null))), "string"),
				OperationDate_3: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "reportcashnebim_1812032468_value", "value", "", "", "")), "string"),
				CompanyCode_3: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toInteger(this, (stateVars.GetOfficeAndCompany !== undefined ? (stateVars.GetOfficeAndCompany?.length > 0 ? stateVars.GetOfficeAndCompany[0].companyCode : null) : (this.state.GetOfficeAndCompany?.length > 0 ? this.state.GetOfficeAndCompany[0].companyCode : null))), "number"),
				OfficeCode_3: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, (stateVars.GetOfficeAndCompany !== undefined ? (stateVars.GetOfficeAndCompany?.length > 0 ? stateVars.GetOfficeAndCompany[0].officeCode : null) : (this.state.GetOfficeAndCompany?.length > 0 ? this.state.GetOfficeAndCompany[0].officeCode : null))), "string"),
				OperationDate_4: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "reportcashnebim_1812032468_value", "value", "", "", "")), "string"),
				CompanyCode_4: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toInteger(this, (stateVars.GetOfficeAndCompany !== undefined ? (stateVars.GetOfficeAndCompany?.length > 0 ? stateVars.GetOfficeAndCompany[0].companyCode : null) : (this.state.GetOfficeAndCompany?.length > 0 ? this.state.GetOfficeAndCompany[0].companyCode : null))), "number"),
				OfficeCode_4: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, (stateVars.GetOfficeAndCompany !== undefined ? (stateVars.GetOfficeAndCompany?.length > 0 ? stateVars.GetOfficeAndCompany[0].officeCode : null) : (this.state.GetOfficeAndCompany?.length > 0 ? this.state.GetOfficeAndCompany[0].officeCode : null))), "string"),
				OperationDate_5: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "reportcashnebim_1812032468_value", "value", "", "", "")), "string"),
				CompanyCode_5: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toInteger(this, (stateVars.GetOfficeAndCompany !== undefined ? (stateVars.GetOfficeAndCompany?.length > 0 ? stateVars.GetOfficeAndCompany[0].companyCode : null) : (this.state.GetOfficeAndCompany?.length > 0 ? this.state.GetOfficeAndCompany[0].companyCode : null))), "number"),
				OfficeCode_5: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, (stateVars.GetOfficeAndCompany !== undefined ? (stateVars.GetOfficeAndCompany?.length > 0 ? stateVars.GetOfficeAndCompany[0].officeCode : null) : (this.state.GetOfficeAndCompany?.length > 0 ? this.state.GetOfficeAndCompany[0].officeCode : null))), "string"),
				OperationDate_6: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "reportcashnebim_1812032468_value", "value", "", "", "")), "string"),
				CompanyCode_6: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toInteger(this, (stateVars.GetOfficeAndCompany !== undefined ? (stateVars.GetOfficeAndCompany?.length > 0 ? stateVars.GetOfficeAndCompany[0].companyCode : null) : (this.state.GetOfficeAndCompany?.length > 0 ? this.state.GetOfficeAndCompany[0].companyCode : null))), "number"),
				OfficeCode_6: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, (stateVars.GetOfficeAndCompany !== undefined ? (stateVars.GetOfficeAndCompany?.length > 0 ? stateVars.GetOfficeAndCompany[0].officeCode : null) : (this.state.GetOfficeAndCompany?.length > 0 ? this.state.GetOfficeAndCompany[0].officeCode : null))), "string"),
				OperationDate_7: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "reportcashnebim_1812032468_value", "value", "", "", "")), "string"),
				CompanyCode_7: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toInteger(this, (stateVars.GetOfficeAndCompany !== undefined ? (stateVars.GetOfficeAndCompany?.length > 0 ? stateVars.GetOfficeAndCompany[0].companyCode : null) : (this.state.GetOfficeAndCompany?.length > 0 ? this.state.GetOfficeAndCompany[0].companyCode : null))), "number"),
				OfficeCode_7: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, (stateVars.GetOfficeAndCompany !== undefined ? (stateVars.GetOfficeAndCompany?.length > 0 ? stateVars.GetOfficeAndCompany[0].officeCode : null) : (this.state.GetOfficeAndCompany?.length > 0 ? this.state.GetOfficeAndCompany[0].officeCode : null))), "string"),
				OperationDate_8: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "reportcashnebim_1812032468_value", "value", "", "", "")), "string"),
				CompanyCode_8: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toInteger(this, (stateVars.GetOfficeAndCompany !== undefined ? (stateVars.GetOfficeAndCompany?.length > 0 ? stateVars.GetOfficeAndCompany[0].companyCode : null) : (this.state.GetOfficeAndCompany?.length > 0 ? this.state.GetOfficeAndCompany[0].companyCode : null))), "number"),
				OfficeCode_8: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, (stateVars.GetOfficeAndCompany !== undefined ? (stateVars.GetOfficeAndCompany?.length > 0 ? stateVars.GetOfficeAndCompany[0].officeCode : null) : (this.state.GetOfficeAndCompany?.length > 0 ? this.state.GetOfficeAndCompany[0].officeCode : null))), "string"),
				OperationDate_9: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "reportcashnebim_1812032468_value", "value", "", "", "")), "string"),
				CompanyCode_9: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toInteger(this, (stateVars.GetOfficeAndCompany !== undefined ? (stateVars.GetOfficeAndCompany?.length > 0 ? stateVars.GetOfficeAndCompany[0].companyCode : null) : (this.state.GetOfficeAndCompany?.length > 0 ? this.state.GetOfficeAndCompany[0].companyCode : null))), "number"),
				OfficeCode_9: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, (stateVars.GetOfficeAndCompany !== undefined ? (stateVars.GetOfficeAndCompany?.length > 0 ? stateVars.GetOfficeAndCompany[0].officeCode : null) : (this.state.GetOfficeAndCompany?.length > 0 ? this.state.GetOfficeAndCompany[0].officeCode : null))), "string"),
				OperationDate_10: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "reportcashnebim_1812032468_value", "value", "", "", "")), "string"),
				CompanyCode_10: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toInteger(this, (stateVars.GetOfficeAndCompany !== undefined ? (stateVars.GetOfficeAndCompany?.length > 0 ? stateVars.GetOfficeAndCompany[0].companyCode : null) : (this.state.GetOfficeAndCompany?.length > 0 ? this.state.GetOfficeAndCompany[0].companyCode : null))), "number"),
				OfficeCode_10: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, (stateVars.GetOfficeAndCompany !== undefined ? (stateVars.GetOfficeAndCompany?.length > 0 ? stateVars.GetOfficeAndCompany[0].officeCode : null) : (this.state.GetOfficeAndCompany?.length > 0 ? this.state.GetOfficeAndCompany[0].officeCode : null))), "string")
        }

		
        if (true) {
        KuikaAppManager.showSpinner(this);
        }
        let result = await KuikaAppManager.ApiRequest(this, "ReportCashNebim/ReportCashNebimComponent_903085484_onClick1_", localVar)
        if (!KMainFunctions.IsResStatus2XX(result)) return true;

			stateVars.GetOfficeAndCompany = result?.data.getOfficeAndCompany;
			formVars.reportcashnebim_674743335_value = ReactSystemFunctions.toString(this, (stateVars.GetOfficeAndCompany !== undefined ? (stateVars.GetOfficeAndCompany?.length > 0 ? stateVars.GetOfficeAndCompany[0].companyName : null) : (this.state.GetOfficeAndCompany?.length > 0 ? this.state.GetOfficeAndCompany[0].companyName : null)));
			formVars.reportcashnebim_1441995161_value = ReactSystemFunctions.toString(this, (stateVars.GetOfficeAndCompany !== undefined ? (stateVars.GetOfficeAndCompany?.length > 0 ? stateVars.GetOfficeAndCompany[0].officeName : null) : (this.state.GetOfficeAndCompany?.length > 0 ? this.state.GetOfficeAndCompany[0].officeName : null)));
			stateVars.Kuika_KasaRaporuSatisSiparisleri1 = result?.data.kuika_KasaRaporuSatisSiparisleri1;
			
			stateVars.Kuika_SatisFaturalari2 = result?.data.kuika_SatisFaturalari2;
			stateVars.Kuika_NakitDevirler3 = result?.data.kuika_NakitDevirler3;
			
			
			stateVars.Kuika_KrediKartiTahsilatlari4 = result?.data.kuika_KrediKartiTahsilatlari4;
			
			stateVars.Kuika_BankaKontrol5 = result?.data.kuika_BankaKontrol5;
			
			
			stateVars.Kuika_TedarikciPosCekimleri6 = result?.data.kuika_TedarikciPosCekimleri6;
			stateVars.Kuika_Orders7 = result?.data.kuika_Orders7;
			
			stateVars.Kuika_Masraflar8 = result?.data.kuika_Masraflar8;
			
			stateVars.Kuika_CashDevir9 = result?.data.kuika_CashDevir9;
			stateVars.Kuika_KasaKalani10 = result?.data.kuika_KasaKalani10;
			
			this.props.form?.setFieldsValue(formVars);
			
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.ReportCashNebimComponent_903085484_onClick2_();
                  resolve();
                });
          })



        
        KuikaAppManager.hideSpinner(this);
        return isErrorOccurred;
    }
		ReportCashNebimComponent_903085484_onClick2_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }

				formVars.reportcashnebim_674743335_value = ReactSystemFunctions.toString(this, (stateVars.GetOfficeAndCompany !== undefined ? (stateVars.GetOfficeAndCompany?.length > 0 ? stateVars.GetOfficeAndCompany[0].companyName : null) : (this.state.GetOfficeAndCompany?.length > 0 ? this.state.GetOfficeAndCompany[0].companyName : null)));

				formVars.reportcashnebim_1441995161_value = ReactSystemFunctions.toString(this, (stateVars.GetOfficeAndCompany !== undefined ? (stateVars.GetOfficeAndCompany?.length > 0 ? stateVars.GetOfficeAndCompany[0].officeName : null) : (this.state.GetOfficeAndCompany?.length > 0 ? this.state.GetOfficeAndCompany[0].officeName : null)));

				
				stateVars.dataSource_150322063 = stateVars.Kuika_Orders7 ?? this.state.Kuika_Orders7;
				
				stateVars.dataSource_314371451 = stateVars.Kuika_KasaRaporuSatisSiparisleri1 ?? this.state.Kuika_KasaRaporuSatisSiparisleri1;
				
				stateVars.dataSource_1784203962 = stateVars.Kuika_NakitDevirler3 ?? this.state.Kuika_NakitDevirler3;
				
				stateVars.dataSource_2057450190 = stateVars.Kuika_BankaKontrol5 ?? this.state.Kuika_BankaKontrol5;
				
				stateVars.dataSource_353483336 = stateVars.Kuika_BankaKontrol5 ?? this.state.Kuika_BankaKontrol5;
				
				stateVars.dataSource_739616295 = stateVars.Kuika_KasaKalani10 ?? this.state.Kuika_KasaKalani10;
				
				stateVars.dataSource_49354912 = stateVars.Kuika_KrediKartiTahsilatlari4 ?? this.state.Kuika_KrediKartiTahsilatlari4;
				
				stateVars.dataSource_404047900 = stateVars.Kuika_NakitDevirler3 ?? this.state.Kuika_NakitDevirler3;
				
				stateVars.dataSource_1708045397 = stateVars.Kuika_Masraflar8 ?? this.state.Kuika_Masraflar8;

		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

            
            return isErrorOccurred;
        }





    ReportCashNebimComponent_2054284029_onClick = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
		KuikaAppManager.increaseServerRequestCount();

        let localVar = {
				KUserId_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.getMyUserId(), "Guid"),
				reportName_1: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.convertToTypeByName("acb83dad-177b-4bcc-a400-fda7b31a1305", "string"), "string"),
				Date_1: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "reportcashnebim_1812032468_value", "value", "", "", "")), "string"),
				CompanyCode_1: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, (stateVars.GetOfficeAndCompany !== undefined ? (stateVars.GetOfficeAndCompany?.length > 0 ? stateVars.GetOfficeAndCompany[0].companyCode : null) : (this.state.GetOfficeAndCompany?.length > 0 ? this.state.GetOfficeAndCompany[0].companyCode : null))), "number"),
				OfficeCode_1: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, (stateVars.GetOfficeAndCompany !== undefined ? (stateVars.GetOfficeAndCompany?.length > 0 ? stateVars.GetOfficeAndCompany[0].officeCode : null) : (this.state.GetOfficeAndCompany?.length > 0 ? this.state.GetOfficeAndCompany[0].officeCode : null))), "string")
        }

		KuikaAppManager.showSpinner(this);
		
        if (true) {
        KuikaAppManager.showSpinner(this);
        }
        let result = await KuikaAppManager.ApiRequest(this, "ReportCashNebim/ReportCashNebimComponent_2054284029_onClick", localVar)
        if (!KMainFunctions.IsResStatus2XX(result)) return true;

			stateVars.GetOfficeAndCompany = result?.data.getOfficeAndCompany;
			formVars.reportcashnebim_674743335_value = ReactSystemFunctions.toString(this, (stateVars.GetOfficeAndCompany !== undefined ? (stateVars.GetOfficeAndCompany?.length > 0 ? stateVars.GetOfficeAndCompany[0].companyName : null) : (this.state.GetOfficeAndCompany?.length > 0 ? this.state.GetOfficeAndCompany[0].companyName : null)));
			formVars.reportcashnebim_1441995161_value = ReactSystemFunctions.toString(this, (stateVars.GetOfficeAndCompany !== undefined ? (stateVars.GetOfficeAndCompany?.length > 0 ? stateVars.GetOfficeAndCompany[0].officeName : null) : (this.state.GetOfficeAndCompany?.length > 0 ? this.state.GetOfficeAndCompany[0].officeName : null)));
			stateVars.PrintReport = result?.data.printReport;
			this.props.form?.setFieldsValue(formVars);
			
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.ReportCashNebimComponent_2054284029_onClick1_();
                  resolve();
                });
          })



        
        KuikaAppManager.hideSpinner(this);
        return isErrorOccurred;
    }
		ReportCashNebimComponent_2054284029_onClick1_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }

				stateVars.PrintPdf = await ReactSystemFunctions.printPdf(ReactSystemFunctions.toString(this, this.state.PrintReport));
				formVars.reportcashnebim_674743335_value = ReactSystemFunctions.toString(this, (stateVars.GetOfficeAndCompany !== undefined ? (stateVars.GetOfficeAndCompany?.length > 0 ? stateVars.GetOfficeAndCompany[0].companyName : null) : (this.state.GetOfficeAndCompany?.length > 0 ? this.state.GetOfficeAndCompany[0].companyName : null)));

				formVars.reportcashnebim_1441995161_value = ReactSystemFunctions.toString(this, (stateVars.GetOfficeAndCompany !== undefined ? (stateVars.GetOfficeAndCompany?.length > 0 ? stateVars.GetOfficeAndCompany[0].officeName : null) : (this.state.GetOfficeAndCompany?.length > 0 ? this.state.GetOfficeAndCompany[0].officeName : null)));


		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

            
            return isErrorOccurred;
        }




		ReportCashNebimComponent_1812032468_onChange = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
KuikaAppManager.showSpinner(this);

				ReactSystemFunctions.setValueOf(this, "reportcashnebim_1140736150_value", ReactSystemFunctions.value(this, "reportcashnebim_1812032468_value", "value"), "value");


		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

            
            return isErrorOccurred;
        }




    async callCallbackFunction(diId: number, isFromMaster: boolean = false) {
        let isErrorOccurred = false;
		let pageInitCallerNavDiIDs = [] as number[];
		if (isFromMaster || pageInitCallerNavDiIDs.indexOf(diId) > -1) {
			await this.ReportCashNebimPageInit();
		}

    }


}
