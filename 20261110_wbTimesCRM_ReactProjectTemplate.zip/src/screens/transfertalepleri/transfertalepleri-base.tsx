import React from "react";
import Axios, { AxiosResponse } from "axios";
import { KuikaAppManager } from "../../shared/utilty/kuika-app-manager";
import { ReactSystemFunctions } from "../../shared/utilty/react-system-functions";
import { KNavigator } from "../../shared/hoc/with-history";
import { KContext } from "../../shared/hoc/with-context";
import { useLocation } from "react-router-dom";
import { FormInstance } from "antd/es/form";
import { Guid } from "guid-typescript";
import Swal from "sweetalert2";
import { KMainFunctions } from "../../shared/utilty/main-functions";
import moment from "moment";
import { IValidationData } from "../../models/dto/validation-data";
import { IStripePayment } from "../../models/dto/stripe-payment";
import { IUserInfoDto } from "../../models/dto/user-info.dto";
import { UserService } from "../../services/user-service";
import { kuikaCoreWasmBridgeService } from "../../services/_singletons";
import _ from "lodash";
import mqtt, { MqttClient } from "mqtt";
import { IMqttResult } from "../../models/dto/mqtt.dto";
import { MasterScreen_ScreenContext } from "../masterscreen/masterscreen-context";

declare let window: any;

export interface ITransferTalepleri_ScreenProps {
  navigator: KNavigator;
  form: FormInstance<any>;
  googleLogin: any;
  screenInputs: any;
  context: KContext;
  initialValues: any;
  children: any;
}

export interface ITransferTalepleri_ScreenState {
    isSpinnerVisible: boolean;
    isPageVisible: boolean;
	isLeftMenuVisible: boolean;
    spinnerCount: number;
    selectedLanguage: string;
    isPageInitLoaded: false;
    isPageRecurringLoaded: false;
	TM_GetCurrentUserTransferScope: any[];
	TM_GetCurrentUserTransferScope_dummy: any[];
	TM_GetTransferRequestStatusOptions: any[];
	TM_GetTransferRequestStatusOptions_dummy: any[];
	TM_GetTransferRequestTypeOptions: any[];
	TM_GetTransferRequestTypeOptions_dummy: any[];
	TM_GetTransferIncomingRequestingStoreOptions: any[];
	TM_GetTransferIncomingRequestingStoreOptions_dummy: any[];
	TM_GetTransferIncomingCreatorOptions: any[];
	TM_GetTransferIncomingCreatorOptions_dummy: any[];
	TM_GetTransferIncomingHeaderMetrics: any[];
	TM_GetTransferIncomingHeaderMetrics_dummy: any[];
	TM_GetTransferRequestsIncoming: any[];
	TM_GetTransferRequestsIncoming_dummy: any[];
	TM_GetTransferOutgoingRequestedStoreOptions: any[];
	TM_GetTransferOutgoingRequestedStoreOptions_dummy: any[];
	TM_GetTransferOutgoingCreatorOption: any[];
	TM_GetTransferOutgoingCreatorOption_dummy: any[];
	TM_GetTransferOutgoingHeaderMetrics: any[];
	TM_GetTransferOutgoingHeaderMetrics_dummy: any[];
	TM_GetTransferRequestsOutgoing: any[];
	TM_GetTransferRequestsOutgoing_dummy: any[];
	TM_GetTransferStoreOptions: any[];
	TM_GetTransferStoreOptions_dummy: any[];
	TM_GetTransferAllCreatorOptions: any[];
	TM_GetTransferAllCreatorOptions_dummy: any[];
	TM_GetTransferAllHeaderMetrics: any[];
	TM_GetTransferAllHeaderMetrics_dummy: any[];
	TM_GetTransferRequestsAll: any[];
	TM_GetTransferRequestsAll_dummy: any[];
	TM_GetTransferRequestTabCounts: any[];
	TM_GetTransferRequestTabCounts_dummy: any[];
	SetValueOf: any;
	SetValueOf_dummy: any;
	NAVIGATE: any;
	NAVIGATE_dummy: any;
	isComp988164Visible: 'visible' | 'hidden';
	isComp188694Visible: 'visible' | 'hidden';
	isComp869705Visible: 'visible' | 'hidden';
	isComp334544Visible: 'visible' | 'hidden';
	isComp289355Visible: 'visible' | 'hidden';
	isComp534410Visible: 'visible' | 'hidden';
	isComptransfertalepleri_533003AuthorizationVisible: 'visible' | 'hidden';

}

export class TransferTalepleri_ScreenBase extends React.PureComponent<ITransferTalepleri_ScreenProps, any> {
    static contextType = MasterScreen_ScreenContext;
    declare context: React.ContextType<typeof MasterScreen_ScreenContext>;
	transfertalepleri_395073_value_kuikaAutoCompleteRef: React.RefObject<any>;
	transfertalepleri_993533_value_kuikaAutoCompleteRef: React.RefObject<any>;
	transfertalepleri_69151_value_kuikaAutoCompleteRef: React.RefObject<any>;
	transfertalepleri_633048_value_kuikaDateRef: React.RefObject<any>;
	transfertalepleri_993607_value_kuikaDateRef: React.RefObject<any>;
	transfertalepleri_782225_value_kuikaTableRef: React.RefObject<any>;
	transfertalepleri_429236_value_kuikaPaginationRef: React.RefObject<any>;
	transfertalepleri_513059_value_kuikaAutoCompleteRef: React.RefObject<any>;
	transfertalepleri_433075_value_kuikaAutoCompleteRef: React.RefObject<any>;
	transfertalepleri_86009_value_kuikaAutoCompleteRef: React.RefObject<any>;
	transfertalepleri_401386_value_kuikaDateRef: React.RefObject<any>;
	transfertalepleri_959886_value_kuikaDateRef: React.RefObject<any>;
	transfertalepleri_681679_value_kuikaTableRef: React.RefObject<any>;
	transfertalepleri_554974_value_kuikaPaginationRef: React.RefObject<any>;
	transfertalepleri_412000_value_kuikaAutoCompleteRef: React.RefObject<any>;
	transfertalepleri_38408_value_kuikaAutoCompleteRef: React.RefObject<any>;
	transfertalepleri_549686_value_kuikaAutoCompleteRef: React.RefObject<any>;
	transfertalepleri_163767_value_kuikaAutoCompleteRef: React.RefObject<any>;
	transfertalepleri_374249_value_kuikaDateRef: React.RefObject<any>;
	transfertalepleri_959115_value_kuikaDateRef: React.RefObject<any>;
	transfertalepleri_901194_value_kuikaTableRef: React.RefObject<any>;
	transfertalepleri_984416_value_kuikaPaginationRef: React.RefObject<any>;
    ml=[{"Id":"d5a61d2b-bd60-485f-86e2-661e9ed4e486","Name":"en_US","ShortName":"English","IsDefault":true,"LanguagePhrases":[]},{"Id":"a54d1c09-5b9e-43d9-a360-3c183d6fa685","Name":"FixedValues","ShortName":"FixedValues","LanguagePhrases":[{"Id":52033,"PropertyName":"value","Value":"Transfer Talepleri"},{"Id":383117,"PropertyName":"value","Value":"Mağazalar ve merkez arasındaki ürün taleplerini görüntüleyin ve takip edin."},{"Id":627608,"PropertyName":"label","Value":"+ Yeni Transfer Talebi"},{"Id":887553,"PropertyName":"tab","Value":"Kendi Mağazam — Gelen"},{"Id":338365,"PropertyName":"value","Value":"Mağazama Gelen Talepler"},{"Id":653206,"PropertyName":"value","Value":"Diğer mağazaların sizin mağazanızdan istediği ürünleri değerlendirin."},{"Id":932844,"PropertyName":"value","Value":"Tüm Talepler"},{"Id":573867,"PropertyName":"value","Value":"Onay Bekleyen"},{"Id":805131,"PropertyName":"value","Value":"Transfer Bekliyor"},{"Id":107899,"PropertyName":"value","Value":"Transfer Sürecinde"},{"Id":408255,"PropertyName":"value","Value":"Transfer Edilen"},{"Id":353480,"PropertyName":"value","Value":"İptal Edilen"},{"Id":857400,"PropertyName":"value","Value":"Bugün Gelen"},{"Id":55183,"PropertyName":"value","Value":"Talep No"},{"Id":854593,"PropertyName":"placeholder","Value":"Talep No"},{"Id":683600,"PropertyName":"value","Value":"Durum"},{"Id":603398,"PropertyName":"placeholder","Value":"Durum seçin"},{"Id":619445,"PropertyName":"value","Value":"Talep Eden Mağaza"},{"Id":395073,"PropertyName":"placeholder","Value":"Mağaza seçin"},{"Id":827001,"PropertyName":"value","Value":"Talebi Açan"},{"Id":993533,"PropertyName":"placeholder","Value":"Kullanıcı seçin"},{"Id":605188,"PropertyName":"value","Value":"Talep Türü"},{"Id":69151,"PropertyName":"placeholder","Value":"Talep türü seçin"},{"Id":74141,"PropertyName":"value","Value":"Ürün Kodu veya Ürün Adı"},{"Id":772464,"PropertyName":"placeholder","Value":"Ürün kodu veya adı"},{"Id":380908,"PropertyName":"value","Value":"Talep Tarihi Başlangıç"},{"Id":633048,"PropertyName":"placeholder","Value":"Başlangıç tarihi seçin"},{"Id":340507,"PropertyName":"value","Value":"Talep Tarihi Bitiş"},{"Id":993607,"PropertyName":"placeholder","Value":"Bitiş tarihi seçin"},{"Id":299914,"PropertyName":"label","Value":"Ara"},{"Id":22006,"PropertyName":"label","Value":"Temizle"},{"Id":149324,"PropertyName":"title","Value":"Talep No"},{"Id":31851,"PropertyName":"value","Value":"[datafield:requestnumber]"},{"Id":886250,"PropertyName":"title","Value":"Durum"},{"Id":313538,"PropertyName":"value","Value":"[datafield:statusname]"},{"Id":104175,"PropertyName":"title","Value":"Talep Edilen"},{"Id":675968,"PropertyName":"value","Value":"[datafield:requestedstorename]"},{"Id":245662,"PropertyName":"title","Value":"Talep Eden"},{"Id":443931,"PropertyName":"value","Value":"[datafield:requestingstorename]"},{"Id":312730,"PropertyName":"title","Value":"Talep Türü"},{"Id":381437,"PropertyName":"value","Value":"[datafield:requesttypename]"},{"Id":988164,"PropertyName":"title","Value":"Ürün  adı"},{"Id":204500,"PropertyName":"value","Value":"[datafield:productname]"},{"Id":800631,"PropertyName":"title","Value":"Ürün / Miktar"},{"Id":138721,"PropertyName":"value","Value":"[datafield:totalrequestedqty]"},{"Id":539464,"PropertyName":"title","Value":"Talebi Açan"},{"Id":666947,"PropertyName":"value","Value":"[datafield:createdbyname]"},{"Id":569744,"PropertyName":"title","Value":"Talep Tarihi"},{"Id":378491,"PropertyName":"value","Value":"[datafield:createdat]"},{"Id":540619,"PropertyName":"title","Value":"Onay/Ret Tarihi"},{"Id":560199,"PropertyName":"value","Value":"[datafield:decisionat]"},{"Id":627130,"PropertyName":"title","Value":"Bekleme Süresi"},{"Id":632824,"PropertyName":"value","Value":"[datafield:waitingdurationtext]"},{"Id":260260,"PropertyName":"title","Value":"İşlemler"},{"Id":284990,"PropertyName":"label","Value":"Detay"},{"Id":188694,"PropertyName":"label","Value":"⋯"},{"Id":786328,"PropertyName":"tab","Value":"Kendi Mağazam — Giden"},{"Id":603888,"PropertyName":"value","Value":"Mağazamdan Giden Talepler"},{"Id":974689,"PropertyName":"value","Value":"Mağazanızın diğer mağazalardan istediği ürünlerin durumunu takip edin."},{"Id":242264,"PropertyName":"value","Value":"Tüm Talepler"},{"Id":119792,"PropertyName":"value","Value":"Onay Bekleyen"},{"Id":265416,"PropertyName":"value","Value":"Transfer Bekliyor"},{"Id":889001,"PropertyName":"value","Value":"Transfer Sürecinde"},{"Id":381097,"PropertyName":"value","Value":"Transfer Edilen"},{"Id":45816,"PropertyName":"value","Value":"İptal Edilen"},{"Id":193986,"PropertyName":"value","Value":"Bugün Giden"},{"Id":567093,"PropertyName":"value","Value":"Talep No"},{"Id":50402,"PropertyName":"placeholder","Value":"Talep No"},{"Id":177728,"PropertyName":"value","Value":"Durum"},{"Id":995645,"PropertyName":"placeholder","Value":"Durum seçin"},{"Id":498742,"PropertyName":"value","Value":"Talep Edilen Mağaza"},{"Id":513059,"PropertyName":"placeholder","Value":"Mağaza seçin"},{"Id":373680,"PropertyName":"value","Value":"Talebi Açan"},{"Id":433075,"PropertyName":"placeholder","Value":"Kullanıcı seçin"},{"Id":831066,"PropertyName":"value","Value":"Talep Türü"},{"Id":86009,"PropertyName":"placeholder","Value":"Talep türü seçin"},{"Id":831106,"PropertyName":"value","Value":"Ürün Kodu veya Ürün Adı"},{"Id":809044,"PropertyName":"placeholder","Value":"Ürün kodu veya adı"},{"Id":754204,"PropertyName":"value","Value":"Talep Tarihi Başlangıç"},{"Id":401386,"PropertyName":"placeholder","Value":"Başlangıç tarihi seçin"},{"Id":958185,"PropertyName":"value","Value":"Talep Tarihi Bitiş"},{"Id":959886,"PropertyName":"placeholder","Value":"Bitiş tarihi seçin"},{"Id":529588,"PropertyName":"label","Value":"Ara"},{"Id":684523,"PropertyName":"label","Value":"Temizle"},{"Id":522476,"PropertyName":"title","Value":"Talep No"},{"Id":397476,"PropertyName":"value","Value":"[datafield:requestnumber]"},{"Id":231211,"PropertyName":"title","Value":"Durum"},{"Id":244240,"PropertyName":"value","Value":"[datafield:statusname]"},{"Id":912263,"PropertyName":"title","Value":"Talep Eden"},{"Id":83154,"PropertyName":"value","Value":"[datafield:requestingstorename]"},{"Id":210395,"PropertyName":"title","Value":"Talep Edilen"},{"Id":955888,"PropertyName":"value","Value":"[datafield:requestedstorename]"},{"Id":109440,"PropertyName":"title","Value":"Talep Türü"},{"Id":111014,"PropertyName":"value","Value":"[datafield:requesttypename]"},{"Id":869705,"PropertyName":"title","Value":"Ürün adı"},{"Id":885694,"PropertyName":"value","Value":"[datafield:productname]"},{"Id":541228,"PropertyName":"title","Value":"Ürün / Miktar"},{"Id":2675,"PropertyName":"value","Value":"[datafield:productcount]"},{"Id":904659,"PropertyName":"title","Value":"Talebi Açan"},{"Id":733103,"PropertyName":"value","Value":"[datafield:createdbyname]"},{"Id":5950,"PropertyName":"title","Value":"Talep Tarihi"},{"Id":921911,"PropertyName":"value","Value":"[datafield:createdat]"},{"Id":172631,"PropertyName":"title","Value":"Onay/Ret Tarihi"},{"Id":802823,"PropertyName":"value","Value":"[datafield:decisionat]"},{"Id":799050,"PropertyName":"title","Value":"Bekleme Süresi"},{"Id":534495,"PropertyName":"value","Value":"[datafield:waitingdurationtext]"},{"Id":47174,"PropertyName":"title","Value":"İşlemler"},{"Id":483178,"PropertyName":"label","Value":"Detay"},{"Id":334544,"PropertyName":"label","Value":"⋯"},{"Id":758848,"PropertyName":"tab","Value":"Tüm Talepler"},{"Id":331353,"PropertyName":"value","Value":"Tüm Transfer Talepleri"},{"Id":463269,"PropertyName":"value","Value":"Yetkiniz kapsamındaki mağazalar arası tüm transfer taleplerini görüntüleyin."},{"Id":851302,"PropertyName":"value","Value":"Toplam Açık"},{"Id":634254,"PropertyName":"value","Value":"Transferde"},{"Id":490864,"PropertyName":"value","Value":"Tamamlanan"},{"Id":678453,"PropertyName":"value","Value":"Bugün Açılan"},{"Id":881753,"PropertyName":"value","Value":"Talep No"},{"Id":519462,"PropertyName":"placeholder","Value":"Talep No"},{"Id":956045,"PropertyName":"value","Value":"Durum"},{"Id":755228,"PropertyName":"placeholder","Value":"Durum seçin"},{"Id":985783,"PropertyName":"value","Value":"Talep Eden Mağaza"},{"Id":412000,"PropertyName":"placeholder","Value":"Mağaza seçin"},{"Id":26085,"PropertyName":"value","Value":"Talep Edilen Mağaza"},{"Id":38408,"PropertyName":"placeholder","Value":"Mağaza seçin"},{"Id":563519,"PropertyName":"value","Value":"Talebi Açan"},{"Id":549686,"PropertyName":"placeholder","Value":"Kullanıcı seçin"},{"Id":550843,"PropertyName":"value","Value":"Talep Türü"},{"Id":163767,"PropertyName":"placeholder","Value":"Talep türü seçin"},{"Id":472913,"PropertyName":"value","Value":"Ürün Kodu veya Ürün Adı"},{"Id":815155,"PropertyName":"placeholder","Value":"Ürün kodu veya adı"},{"Id":97019,"PropertyName":"value","Value":"Talep Tarihi Başlangıç"},{"Id":374249,"PropertyName":"placeholder","Value":"Başlangıç tarihi seçin"},{"Id":555588,"PropertyName":"value","Value":"Talep Tarihi Bitiş"},{"Id":959115,"PropertyName":"placeholder","Value":"Bitiş tarihi seçin"},{"Id":294970,"PropertyName":"label","Value":"Ara"},{"Id":663454,"PropertyName":"label","Value":"Temizle"},{"Id":461308,"PropertyName":"title","Value":"Talep No"},{"Id":79385,"PropertyName":"value","Value":"[datafield:requestnumber]"},{"Id":880064,"PropertyName":"title","Value":"Durum"},{"Id":950568,"PropertyName":"value","Value":"[datafield:statusname]"},{"Id":932600,"PropertyName":"title","Value":"Talep Eden"},{"Id":616780,"PropertyName":"value","Value":"[datafield:requestingstorename]"},{"Id":19469,"PropertyName":"title","Value":"Talep Edilen"},{"Id":245282,"PropertyName":"value","Value":"[datafield:requestedstorename]"},{"Id":777777,"PropertyName":"title","Value":"Talep Türü"},{"Id":955076,"PropertyName":"value","Value":"[datafield:requesttypename]"},{"Id":289355,"PropertyName":"title","Value":"Ürün adı"},{"Id":292320,"PropertyName":"value","Value":"[datafield:productname]"},{"Id":852017,"PropertyName":"title","Value":"Ürün / Miktar"},{"Id":723489,"PropertyName":"value","Value":"[datafield:productcount]"},{"Id":60165,"PropertyName":"title","Value":"Talebi Açan"},{"Id":617298,"PropertyName":"value","Value":"[datafield:createdbyname]"},{"Id":656063,"PropertyName":"title","Value":"Talep Tarihi"},{"Id":568514,"PropertyName":"value","Value":"[datafield:createdat]"},{"Id":434556,"PropertyName":"title","Value":"Onay/Ret Tarihi"},{"Id":400153,"PropertyName":"value","Value":"[datafield:decisionat]"},{"Id":468692,"PropertyName":"title","Value":"Bekleme Süresi"},{"Id":649024,"PropertyName":"value","Value":"[datafield:waitingdurationtext]"},{"Id":721129,"PropertyName":"title","Value":"İşlemler"},{"Id":670182,"PropertyName":"label","Value":"Detay"},{"Id":534410,"PropertyName":"label","Value":"⋯"}]}]
    defaultML = "en_US"
    
    screenHash = ""
    

    private _prevMasterPageInitLoaded: boolean = false;
    private _prevMasterPageRecurringLoaded: boolean = false;
    private _prevShouldTriggerPageInit: boolean = false;
    constructor(props) {
        super(props);
		this.transfertalepleri_854593_value_kuikaTextInputRef = React.createRef();
		this.transfertalepleri_395073_value_kuikaAutoCompleteRef = React.createRef();
		this.transfertalepleri_993533_value_kuikaAutoCompleteRef = React.createRef();
		this.transfertalepleri_69151_value_kuikaAutoCompleteRef = React.createRef();
		this.transfertalepleri_772464_value_kuikaTextInputRef = React.createRef();
		this.transfertalepleri_633048_value_kuikaDateRef = React.createRef();
		this.transfertalepleri_993607_value_kuikaDateRef = React.createRef();
		this.transfertalepleri_782225_value_kuikaTableRef = React.createRef();
		this.transfertalepleri_429236_value_kuikaPaginationRef = React.createRef();
		this.transfertalepleri_50402_value_kuikaTextInputRef = React.createRef();
		this.transfertalepleri_513059_value_kuikaAutoCompleteRef = React.createRef();
		this.transfertalepleri_433075_value_kuikaAutoCompleteRef = React.createRef();
		this.transfertalepleri_86009_value_kuikaAutoCompleteRef = React.createRef();
		this.transfertalepleri_809044_value_kuikaTextInputRef = React.createRef();
		this.transfertalepleri_401386_value_kuikaDateRef = React.createRef();
		this.transfertalepleri_959886_value_kuikaDateRef = React.createRef();
		this.transfertalepleri_681679_value_kuikaTableRef = React.createRef();
		this.transfertalepleri_554974_value_kuikaPaginationRef = React.createRef();
		this.transfertalepleri_519462_value_kuikaTextInputRef = React.createRef();
		this.transfertalepleri_412000_value_kuikaAutoCompleteRef = React.createRef();
		this.transfertalepleri_38408_value_kuikaAutoCompleteRef = React.createRef();
		this.transfertalepleri_549686_value_kuikaAutoCompleteRef = React.createRef();
		this.transfertalepleri_163767_value_kuikaAutoCompleteRef = React.createRef();
		this.transfertalepleri_815155_value_kuikaTextInputRef = React.createRef();
		this.transfertalepleri_374249_value_kuikaDateRef = React.createRef();
		this.transfertalepleri_959115_value_kuikaDateRef = React.createRef();
		this.transfertalepleri_901194_value_kuikaTableRef = React.createRef();
		this.transfertalepleri_984416_value_kuikaPaginationRef = React.createRef();

        this.state = {
            isSpinnerVisible: false,
            isPageVisible: false,
            isLeftMenuVisible: false,
            spinnerCount: 0,
            selectedLanguage: "",
            isPageInitLoaded: false,
            isPageRecurringLoaded: false,
            	        TM_GetCurrentUserTransferScope: [],
	        TM_GetTransferRequestStatusOptions: [],
	        TM_GetTransferRequestTypeOptions: [],
	        TM_GetTransferIncomingRequestingStoreOptions: [],
	        TM_GetTransferIncomingCreatorOptions: [],
	        TM_GetTransferIncomingHeaderMetrics: [],
	        TM_GetTransferRequestsIncoming: [],
	        TM_GetTransferOutgoingRequestedStoreOptions: [],
	        TM_GetTransferOutgoingCreatorOption: [],
	        TM_GetTransferOutgoingHeaderMetrics: [],
	        TM_GetTransferRequestsOutgoing: [],
	        TM_GetTransferStoreOptions: [],
	        TM_GetTransferAllCreatorOptions: [],
	        TM_GetTransferAllHeaderMetrics: [],
	        TM_GetTransferRequestsAll: [],
	        TM_GetTransferRequestTabCounts: [],
	        SetValueOf: "",
	        NAVIGATE: "",
	        isComp988164Visible: 'hidden',
	        isComp188694Visible: 'hidden',
	        isComp869705Visible: 'hidden',
	        isComp334544Visible: 'hidden',
	        isComp289355Visible: 'hidden',
	        isComp534410Visible: 'hidden',
	        isComptransfertalepleri_533003AuthorizationVisible: 'visible',

        }

        this.state.isPageVisible = true;
        
    }

    async componentDidMount() {

        if (KuikaAppManager.isPageInitPrevented()) {
            KuikaAppManager.calculateAndSetBodyHeight("transfertalepleri", "masterscreen_screen");
            return;
        }
        this.context.registerCallbackFunction(this.callCallbackFunction.bind(this));
        
        ReactSystemFunctions.validateToken()
        this.fillFormInitValues();
        if (false){
            await this.TransferTalepleriPageInit();
        } else if (this.context?.isMasterPageInitLoaded) { this._prevMasterPageInitLoaded = true; await this.TransferTalepleriPageInit(); }
        ReactSystemFunctions.hideIsNotAuthorized(this, "isComptransfertalepleri_533003AuthorizationVisible", []);

        
        
        KuikaAppManager.calculateAndSetBodyHeight("transfertalepleri", "masterscreen_screen");

        if (ReactSystemFunctions.getIsMicroApp() === false) {
           window.parentScreen = this;
        }
    }

    componentWillUnmount() {
        
        
        

        if (ReactSystemFunctions.getIsMicroApp() === false) {
           window.parentScreen = null;
        }
    }

    

        
    componentDidUpdate= async (prevProps, prevState) => {
		KuikaAppManager.calculateAndSetBodyHeight("transfertalepleri", "masterscreen_screen"    );
        if (prevProps?.location?.search !== (this.props as any)?.location?.search) {
			await this.TransferTalepleriPageInit();
		}

        		if (this._prevMasterPageInitLoaded !== this.context.isMasterPageInitLoaded && this.context.isMasterPageInitLoaded === true) {this._prevMasterPageInitLoaded = this.context.isMasterPageInitLoaded;await this.TransferTalepleriPageInit()}


        if (ReactSystemFunctions.getIsMicroApp() === false) {
            for (const key in prevState) {
                if (key.startsWith('NavVisible') && prevState[key] === true && this.state[key] === false) {
                    window.parentScreen = this;
                    break;
                }
            }
        }
	}

    fillFormInitValues() {
        this.props.form?.setFieldsValue({
});

    }

      setPageInitLoaded = (value: boolean) => {
        this.setState({ isPageInitLoaded: value });
      }

      setPageRecurringLoaded = (value: boolean) => {
        this.setState({ isPageRecurringLoaded: value });
      }

      clearFieldValidation = (changedValues: any) => {
        const fieldName = Object.keys(changedValues)[0];
        if (fieldName) {
          this.props.form?.setFields([
            {
              name: fieldName,
              errors: []
            }
          ]);
        }
      };

        checkTabErrors = () => {
    document.querySelectorAll(".rc-tabs-tab").forEach((tab) => {
      (tab as HTMLElement).style.color = "";
    });

    const tabPanes = document.querySelectorAll(".rc-tabs-tabpane");
    const tabs = document.querySelectorAll(".rc-tabs-tab");

    tabPanes.forEach((tabPane, index) => {
      const uniquePaneId = `rc-tabs-tabpane-${index}`;
      if (!tabPane.hasAttribute("id")) {
        tabPane.setAttribute("id", uniquePaneId); 
      }

      const uniqueTabId = `rc-tabs-tab-${index}`;
      if (tabs[index]) {
        if (!tabs[index].hasAttribute("id")) {
          tabs[index].setAttribute("id", uniqueTabId); 
        }
        tabs[index].setAttribute("aria-controls", uniquePaneId);
      }
    });

    const errorElements = document.querySelectorAll(".rc-tabs .ant-form-item-explain-error");

    const tabsWithErrors = new Set<string>();

    errorElements.forEach((errorElement) => {
      const tabPane = errorElement.closest(".rc-tabs-tabpane");
      if (tabPane && tabPane.id) {
        tabsWithErrors.add(tabPane.id);
      }
    });

    tabsWithErrors.forEach((tabPaneId) => {
      const tab = document.querySelector(`.rc-tabs-tab[aria-controls="${tabPaneId}"]`);
      if (tab) {
        (tab as HTMLElement).style.color = "red"; 
      }
    });
  };

    TransferTalepleriPageInit = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


	if (KuikaAppManager.handleValidations(this, validations, this.checkTabErrors))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }

        let localVar = {
			CurrentUsername_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.getMyUsername(), "string"),
			CurrentUsername_3: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.getMyUsername(), "string"),
			CurrentUsername_4: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.getMyUsername(), "string"),
			CurrentUsername_5: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.getMyUsername(), "string"),
			RequestNumber_5: ReactSystemFunctions.convertToTypeByName(null, "string"),
			StatusIds_5: ReactSystemFunctions.convertToTypeByName(null, "string"),
			RequestingStoreCodes_5: ReactSystemFunctions.convertToTypeByName(null, "string"),
			RequestTypeCodes_5: ReactSystemFunctions.convertToTypeByName(null, "string"),
			ProductSearch_5: ReactSystemFunctions.convertToTypeByName(null, "string"),
			CreatedByIds_5: ReactSystemFunctions.convertToTypeByName(null, "string"),
			RequestDateFrom_5: ReactSystemFunctions.convertToTypeByName(null, "Date"),
			RequestDateTo_5: ReactSystemFunctions.convertToTypeByName(null, "Date"),
			CurrentUsername_6: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.getMyUsername(), "string"),
			RequestNumber_6: ReactSystemFunctions.convertToTypeByName(null, "string"),
			StatusIds_6: ReactSystemFunctions.convertToTypeByName(null, "string"),
			RequestingStoreCodes_6: ReactSystemFunctions.convertToTypeByName(null, "string"),
			RequestedStoreCodes_6: ReactSystemFunctions.convertToTypeByName(null, "string"),
			RequestTypeCodes_6: ReactSystemFunctions.convertToTypeByName(null, "string"),
			ProductSearch_6: ReactSystemFunctions.convertToTypeByName(null, "string"),
			CreatedByIds_6: ReactSystemFunctions.convertToTypeByName(null, "string"),
			RequestDateFrom_6: ReactSystemFunctions.convertToTypeByName(null, "Date"),
			RequestDateTo_6: ReactSystemFunctions.convertToTypeByName(null, "Date"),
			DecisionDateFrom_6: ReactSystemFunctions.convertToTypeByName(null, "Date"),
			DecisionDateTo_6: ReactSystemFunctions.convertToTypeByName(null, "Date"),
			CurrentPage_6: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "transfertalepleri_429236_value", "current", "", "", "")), "number"),
			PageSize_6: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "transfertalepleri_429236_value", "pageSize", "", "", "")), "number"),
			CurrentUsername_7: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.getMyUsername(), "string"),
			CurrentUsername_8: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.getMyUsername(), "string"),
			CurrentUsername_9: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.getMyUsername(), "string"),
			CurrentUsername_10: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.getMyUsername(), "string"),
			RequestNumber_10: ReactSystemFunctions.convertToTypeByName(null, "string"),
			StatusIds_10: ReactSystemFunctions.convertToTypeByName(null, "string"),
			RequestingStoreCodes_10: ReactSystemFunctions.convertToTypeByName(null, "string"),
			RequestedStoreCodes_10: ReactSystemFunctions.convertToTypeByName(null, "string"),
			RequestTypeCodes_10: ReactSystemFunctions.convertToTypeByName(null, "string"),
			ProductSearch_10: ReactSystemFunctions.convertToTypeByName(null, "string"),
			CreatedByIds_10: ReactSystemFunctions.convertToTypeByName(null, "string"),
			RequestDateFrom_10: ReactSystemFunctions.convertToTypeByName(null, "Date"),
			RequestDateTo_10: ReactSystemFunctions.convertToTypeByName(null, "Date"),
			DecisionDateFrom_10: ReactSystemFunctions.convertToTypeByName(null, "Date"),
			DecisionDateTo_10: ReactSystemFunctions.convertToTypeByName(null, "Date"),
			CurrentPage_10: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "transfertalepleri_554974_value", "current", "", "", "")), "number"),
			PageSize_10: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "transfertalepleri_554974_value", "pageSize", "", "", "")), "number"),
			CurrentUsername_12: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.getMyUsername(), "string"),
			CurrentUsername_13: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.getMyUsername(), "string"),
			CurrentUsername_14: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.getMyUsername(), "string"),
			RequestNumber_14: ReactSystemFunctions.convertToTypeByName(null, "string"),
			StatusIds_14: ReactSystemFunctions.convertToTypeByName(null, "string"),
			RequestingStoreCodes_14: ReactSystemFunctions.convertToTypeByName(null, "string"),
			RequestedStoreCodes_14: ReactSystemFunctions.convertToTypeByName(null, "string"),
			RequestTypeCodes_14: ReactSystemFunctions.convertToTypeByName(null, "string"),
			ProductSearch_14: ReactSystemFunctions.convertToTypeByName(null, "string"),
			CreatedByIds_14: ReactSystemFunctions.convertToTypeByName(null, "string"),
			RequestDateFrom_14: ReactSystemFunctions.convertToTypeByName(null, "Date"),
			RequestDateTo_14: ReactSystemFunctions.convertToTypeByName(null, "Date"),
			DecisionDateFrom_14: ReactSystemFunctions.convertToTypeByName(null, "Date"),
			DecisionDateTo_14: ReactSystemFunctions.convertToTypeByName(null, "Date"),
			CurrentPage_14: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "transfertalepleri_984416_value", "current", "", "", "")), "number"),
			PageSize_14: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "transfertalepleri_984416_value", "pageSize", "", "", "")), "number"),
			CurrentUsername_15: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.getMyUsername(), "string"),
			RequestNumber_15: ReactSystemFunctions.convertToTypeByName(null, "string"),
			StatusIds_15: ReactSystemFunctions.convertToTypeByName(null, "string"),
			RequestingStoreCodes_15: ReactSystemFunctions.convertToTypeByName(null, "string"),
			RequestedStoreCodes_15: ReactSystemFunctions.convertToTypeByName(null, "string"),
			RequestTypeCodes_15: ReactSystemFunctions.convertToTypeByName(null, "string"),
			ProductSearch_15: ReactSystemFunctions.convertToTypeByName(null, "string"),
			CreatedByIds_15: ReactSystemFunctions.convertToTypeByName(null, "string"),
			RequestDateFrom_15: ReactSystemFunctions.convertToTypeByName(null, "Date"),
			RequestDateTo_15: ReactSystemFunctions.convertToTypeByName(null, "Date"),
			DecisionDateFrom_15: ReactSystemFunctions.convertToTypeByName(null, "Date"),
			DecisionDateTo_15: ReactSystemFunctions.convertToTypeByName(null, "Date")
        }

	KuikaAppManager.showSpinner(this);
	
        if (true) {
        KuikaAppManager.showSpinner(this);
        }
        let result = await KuikaAppManager.ApiRequest(this, "TransferTalepleri/TransferTalepleriPageInit", localVar)
        if (!KMainFunctions.IsResStatus2XX(result)) return true;

		stateVars.TM_GetCurrentUserTransferScope = result?.data.tM_GetCurrentUserTransferScope;
		stateVars.TM_GetTransferRequestStatusOptions = result?.data.tM_GetTransferRequestStatusOptions;
		
		formVars.transfertalepleri_603398_options = stateVars.TM_GetTransferRequestStatusOptions;
		
		formVars.transfertalepleri_995645_options = stateVars.TM_GetTransferRequestStatusOptions;
		
		formVars.transfertalepleri_755228_options = stateVars.TM_GetTransferRequestStatusOptions;
		stateVars.TM_GetTransferRequestTypeOptions = result?.data.tM_GetTransferRequestTypeOptions;
		
		formVars.transfertalepleri_69151_options = stateVars.TM_GetTransferRequestTypeOptions;
		
		formVars.transfertalepleri_86009_options = stateVars.TM_GetTransferRequestTypeOptions;
		
		formVars.transfertalepleri_163767_options = stateVars.TM_GetTransferRequestTypeOptions;
		stateVars.TM_GetTransferIncomingRequestingStoreOptions = result?.data.tM_GetTransferIncomingRequestingStoreOptions;
		
		formVars.transfertalepleri_395073_options = stateVars.TM_GetTransferIncomingRequestingStoreOptions;
		stateVars.TM_GetTransferIncomingCreatorOptions = result?.data.tM_GetTransferIncomingCreatorOptions;
		
		formVars.transfertalepleri_993533_options = stateVars.TM_GetTransferIncomingCreatorOptions;
		stateVars.TM_GetTransferIncomingHeaderMetrics = result?.data.tM_GetTransferIncomingHeaderMetrics;
		formVars.transfertalepleri_549601_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetTransferIncomingHeaderMetrics !== undefined ? (stateVars.TM_GetTransferIncomingHeaderMetrics?.length > 0 ? stateVars.TM_GetTransferIncomingHeaderMetrics[0].totalCount : null) : (this.state.TM_GetTransferIncomingHeaderMetrics?.length > 0 ? this.state.TM_GetTransferIncomingHeaderMetrics[0].totalCount : null)));
		formVars.transfertalepleri_512439_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetTransferIncomingHeaderMetrics !== undefined ? (stateVars.TM_GetTransferIncomingHeaderMetrics?.length > 0 ? stateVars.TM_GetTransferIncomingHeaderMetrics[0].pendingApprovalCount : null) : (this.state.TM_GetTransferIncomingHeaderMetrics?.length > 0 ? this.state.TM_GetTransferIncomingHeaderMetrics[0].pendingApprovalCount : null)));
		formVars.transfertalepleri_151087_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetTransferIncomingHeaderMetrics !== undefined ? (stateVars.TM_GetTransferIncomingHeaderMetrics?.length > 0 ? stateVars.TM_GetTransferIncomingHeaderMetrics[0].transferWaitingCount : null) : (this.state.TM_GetTransferIncomingHeaderMetrics?.length > 0 ? this.state.TM_GetTransferIncomingHeaderMetrics[0].transferWaitingCount : null)));
		formVars.transfertalepleri_548723_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetTransferIncomingHeaderMetrics !== undefined ? (stateVars.TM_GetTransferIncomingHeaderMetrics?.length > 0 ? stateVars.TM_GetTransferIncomingHeaderMetrics[0].inTransitCount : null) : (this.state.TM_GetTransferIncomingHeaderMetrics?.length > 0 ? this.state.TM_GetTransferIncomingHeaderMetrics[0].inTransitCount : null)));
		formVars.transfertalepleri_59903_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetTransferIncomingHeaderMetrics !== undefined ? (stateVars.TM_GetTransferIncomingHeaderMetrics?.length > 0 ? stateVars.TM_GetTransferIncomingHeaderMetrics[0].completedCount : null) : (this.state.TM_GetTransferIncomingHeaderMetrics?.length > 0 ? this.state.TM_GetTransferIncomingHeaderMetrics[0].completedCount : null)));
		formVars.transfertalepleri_968525_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetTransferIncomingHeaderMetrics !== undefined ? (stateVars.TM_GetTransferIncomingHeaderMetrics?.length > 0 ? stateVars.TM_GetTransferIncomingHeaderMetrics[0].cancelledCount : null) : (this.state.TM_GetTransferIncomingHeaderMetrics?.length > 0 ? this.state.TM_GetTransferIncomingHeaderMetrics[0].cancelledCount : null)));
		formVars.transfertalepleri_543915_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetTransferIncomingHeaderMetrics !== undefined ? (stateVars.TM_GetTransferIncomingHeaderMetrics?.length > 0 ? stateVars.TM_GetTransferIncomingHeaderMetrics[0].todayCount : null) : (this.state.TM_GetTransferIncomingHeaderMetrics?.length > 0 ? this.state.TM_GetTransferIncomingHeaderMetrics[0].todayCount : null)));
		formVars.transfertalepleri_163922_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetTransferIncomingHeaderMetrics !== undefined ? (stateVars.TM_GetTransferIncomingHeaderMetrics?.length > 0 ? stateVars.TM_GetTransferIncomingHeaderMetrics[0].completedCount : null) : (this.state.TM_GetTransferIncomingHeaderMetrics?.length > 0 ? this.state.TM_GetTransferIncomingHeaderMetrics[0].completedCount : null)));
		formVars.transfertalepleri_368094_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetTransferIncomingHeaderMetrics !== undefined ? (stateVars.TM_GetTransferIncomingHeaderMetrics?.length > 0 ? stateVars.TM_GetTransferIncomingHeaderMetrics[0].cancelledCount : null) : (this.state.TM_GetTransferIncomingHeaderMetrics?.length > 0 ? this.state.TM_GetTransferIncomingHeaderMetrics[0].cancelledCount : null)));
		formVars.transfertalepleri_982825_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetTransferIncomingHeaderMetrics !== undefined ? (stateVars.TM_GetTransferIncomingHeaderMetrics?.length > 0 ? stateVars.TM_GetTransferIncomingHeaderMetrics[0].todayCount : null) : (this.state.TM_GetTransferIncomingHeaderMetrics?.length > 0 ? this.state.TM_GetTransferIncomingHeaderMetrics[0].todayCount : null)));
		stateVars.TM_GetTransferRequestsIncoming = result?.data.tM_GetTransferRequestsIncoming;
		
		formVars.transfertalepleri_815611_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetTransferRequestsIncoming !== undefined ? (stateVars.TM_GetTransferRequestsIncoming?.length > 0 ? stateVars.TM_GetTransferRequestsIncoming[0].paginationLabel : null) : (this.state.TM_GetTransferRequestsIncoming?.length > 0 ? this.state.TM_GetTransferRequestsIncoming[0].paginationLabel : null)));
		stateVars.TM_GetTransferOutgoingRequestedStoreOptions = result?.data.tM_GetTransferOutgoingRequestedStoreOptions;
		
		formVars.transfertalepleri_513059_options = stateVars.TM_GetTransferOutgoingRequestedStoreOptions;
		stateVars.TM_GetTransferOutgoingCreatorOption = result?.data.tM_GetTransferOutgoingCreatorOption;
		
		formVars.transfertalepleri_433075_options = stateVars.TM_GetTransferOutgoingCreatorOption;
		stateVars.TM_GetTransferOutgoingHeaderMetrics = result?.data.tM_GetTransferOutgoingHeaderMetrics;
		formVars.transfertalepleri_304759_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetTransferOutgoingHeaderMetrics !== undefined ? (stateVars.TM_GetTransferOutgoingHeaderMetrics?.length > 0 ? stateVars.TM_GetTransferOutgoingHeaderMetrics[0].totalCount : null) : (this.state.TM_GetTransferOutgoingHeaderMetrics?.length > 0 ? this.state.TM_GetTransferOutgoingHeaderMetrics[0].totalCount : null)));
		formVars.transfertalepleri_859473_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetTransferOutgoingHeaderMetrics !== undefined ? (stateVars.TM_GetTransferOutgoingHeaderMetrics?.length > 0 ? stateVars.TM_GetTransferOutgoingHeaderMetrics[0].pendingApprovalCount : null) : (this.state.TM_GetTransferOutgoingHeaderMetrics?.length > 0 ? this.state.TM_GetTransferOutgoingHeaderMetrics[0].pendingApprovalCount : null)));
		formVars.transfertalepleri_55877_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetTransferOutgoingHeaderMetrics !== undefined ? (stateVars.TM_GetTransferOutgoingHeaderMetrics?.length > 0 ? stateVars.TM_GetTransferOutgoingHeaderMetrics[0].transferWaitingCount : null) : (this.state.TM_GetTransferOutgoingHeaderMetrics?.length > 0 ? this.state.TM_GetTransferOutgoingHeaderMetrics[0].transferWaitingCount : null)));
		formVars.transfertalepleri_524626_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetTransferOutgoingHeaderMetrics !== undefined ? (stateVars.TM_GetTransferOutgoingHeaderMetrics?.length > 0 ? stateVars.TM_GetTransferOutgoingHeaderMetrics[0].inTransitCount : null) : (this.state.TM_GetTransferOutgoingHeaderMetrics?.length > 0 ? this.state.TM_GetTransferOutgoingHeaderMetrics[0].inTransitCount : null)));
		stateVars.TM_GetTransferRequestsOutgoing = result?.data.tM_GetTransferRequestsOutgoing;
		
		formVars.transfertalepleri_893312_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetTransferRequestsOutgoing !== undefined ? (stateVars.TM_GetTransferRequestsOutgoing?.length > 0 ? stateVars.TM_GetTransferRequestsOutgoing[0].paginationLabel : null) : (this.state.TM_GetTransferRequestsOutgoing?.length > 0 ? this.state.TM_GetTransferRequestsOutgoing[0].paginationLabel : null)));
		stateVars.TM_GetTransferStoreOptions = result?.data.tM_GetTransferStoreOptions;
		
		formVars.transfertalepleri_412000_options = stateVars.TM_GetTransferStoreOptions;
		
		formVars.transfertalepleri_38408_options = stateVars.TM_GetTransferStoreOptions;
		stateVars.TM_GetTransferAllCreatorOptions = result?.data.tM_GetTransferAllCreatorOptions;
		
		formVars.transfertalepleri_549686_options = stateVars.TM_GetTransferAllCreatorOptions;
		stateVars.TM_GetTransferAllHeaderMetrics = result?.data.tM_GetTransferAllHeaderMetrics;
		formVars.transfertalepleri_661617_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetTransferAllHeaderMetrics !== undefined ? (stateVars.TM_GetTransferAllHeaderMetrics?.length > 0 ? stateVars.TM_GetTransferAllHeaderMetrics[0].totalOpenCount : null) : (this.state.TM_GetTransferAllHeaderMetrics?.length > 0 ? this.state.TM_GetTransferAllHeaderMetrics[0].totalOpenCount : null)));
		formVars.transfertalepleri_312724_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetTransferAllHeaderMetrics !== undefined ? (stateVars.TM_GetTransferAllHeaderMetrics?.length > 0 ? stateVars.TM_GetTransferAllHeaderMetrics[0].inTransitCount : null) : (this.state.TM_GetTransferAllHeaderMetrics?.length > 0 ? this.state.TM_GetTransferAllHeaderMetrics[0].inTransitCount : null)));
		formVars.transfertalepleri_186038_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetTransferAllHeaderMetrics !== undefined ? (stateVars.TM_GetTransferAllHeaderMetrics?.length > 0 ? stateVars.TM_GetTransferAllHeaderMetrics[0].completedCount : null) : (this.state.TM_GetTransferAllHeaderMetrics?.length > 0 ? this.state.TM_GetTransferAllHeaderMetrics[0].completedCount : null)));
		formVars.transfertalepleri_135861_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetTransferAllHeaderMetrics !== undefined ? (stateVars.TM_GetTransferAllHeaderMetrics?.length > 0 ? stateVars.TM_GetTransferAllHeaderMetrics[0].todayCount : null) : (this.state.TM_GetTransferAllHeaderMetrics?.length > 0 ? this.state.TM_GetTransferAllHeaderMetrics[0].todayCount : null)));
		stateVars.TM_GetTransferRequestsAll = result?.data.tM_GetTransferRequestsAll;
		
		formVars.transfertalepleri_155350_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetTransferRequestsAll !== undefined ? (stateVars.TM_GetTransferRequestsAll?.length > 0 ? stateVars.TM_GetTransferRequestsAll[0].paginationLabel : null) : (this.state.TM_GetTransferRequestsAll?.length > 0 ? this.state.TM_GetTransferRequestsAll[0].paginationLabel : null)));
		stateVars.TM_GetTransferRequestTabCounts = result?.data.tM_GetTransferRequestTabCounts;
		this.props.form?.setFieldsValue(formVars);
		
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.TransferTalepleriPageInit1_();
                  resolve();
                });
          })



        
        KuikaAppManager.hideSpinner(this);
        return isErrorOccurred;
    }
	TransferTalepleriPageInit1_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


	if (KuikaAppManager.handleValidations(this, validations, this.checkTabErrors))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }

			stateVars.SetValueOf = await ReactSystemFunctions.setValueOf(this, ReactSystemFunctions.convertToTypeByName("transfertalepleri_533003_value", "string"), ReactSystemFunctions.convertToTypeByName("887553", "string"), null, false);
			formVars.transfertalepleri_549601_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetTransferIncomingHeaderMetrics !== undefined ? (stateVars.TM_GetTransferIncomingHeaderMetrics?.length > 0 ? stateVars.TM_GetTransferIncomingHeaderMetrics[0].totalCount : null) : (this.state.TM_GetTransferIncomingHeaderMetrics?.length > 0 ? this.state.TM_GetTransferIncomingHeaderMetrics[0].totalCount : null)));

			formVars.transfertalepleri_512439_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetTransferIncomingHeaderMetrics !== undefined ? (stateVars.TM_GetTransferIncomingHeaderMetrics?.length > 0 ? stateVars.TM_GetTransferIncomingHeaderMetrics[0].pendingApprovalCount : null) : (this.state.TM_GetTransferIncomingHeaderMetrics?.length > 0 ? this.state.TM_GetTransferIncomingHeaderMetrics[0].pendingApprovalCount : null)));

			formVars.transfertalepleri_151087_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetTransferIncomingHeaderMetrics !== undefined ? (stateVars.TM_GetTransferIncomingHeaderMetrics?.length > 0 ? stateVars.TM_GetTransferIncomingHeaderMetrics[0].transferWaitingCount : null) : (this.state.TM_GetTransferIncomingHeaderMetrics?.length > 0 ? this.state.TM_GetTransferIncomingHeaderMetrics[0].transferWaitingCount : null)));

			formVars.transfertalepleri_548723_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetTransferIncomingHeaderMetrics !== undefined ? (stateVars.TM_GetTransferIncomingHeaderMetrics?.length > 0 ? stateVars.TM_GetTransferIncomingHeaderMetrics[0].inTransitCount : null) : (this.state.TM_GetTransferIncomingHeaderMetrics?.length > 0 ? this.state.TM_GetTransferIncomingHeaderMetrics[0].inTransitCount : null)));

			formVars.transfertalepleri_59903_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetTransferIncomingHeaderMetrics !== undefined ? (stateVars.TM_GetTransferIncomingHeaderMetrics?.length > 0 ? stateVars.TM_GetTransferIncomingHeaderMetrics[0].completedCount : null) : (this.state.TM_GetTransferIncomingHeaderMetrics?.length > 0 ? this.state.TM_GetTransferIncomingHeaderMetrics[0].completedCount : null)));

			formVars.transfertalepleri_968525_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetTransferIncomingHeaderMetrics !== undefined ? (stateVars.TM_GetTransferIncomingHeaderMetrics?.length > 0 ? stateVars.TM_GetTransferIncomingHeaderMetrics[0].cancelledCount : null) : (this.state.TM_GetTransferIncomingHeaderMetrics?.length > 0 ? this.state.TM_GetTransferIncomingHeaderMetrics[0].cancelledCount : null)));

			formVars.transfertalepleri_543915_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetTransferIncomingHeaderMetrics !== undefined ? (stateVars.TM_GetTransferIncomingHeaderMetrics?.length > 0 ? stateVars.TM_GetTransferIncomingHeaderMetrics[0].todayCount : null) : (this.state.TM_GetTransferIncomingHeaderMetrics?.length > 0 ? this.state.TM_GetTransferIncomingHeaderMetrics[0].todayCount : null)));

			
			stateVars.dataSource_603398 = stateVars.TM_GetTransferRequestStatusOptions ?? this.state.TM_GetTransferRequestStatusOptions;
			stateVars.dataSource_603398 = stateVars.TM_GetTransferRequestStatusOptions ?? this.state.TM_GetTransferRequestStatusOptions;
			
			stateVars.dataSource_395073 = stateVars.TM_GetTransferIncomingRequestingStoreOptions ?? this.state.TM_GetTransferIncomingRequestingStoreOptions;
			stateVars.dataSource_395073 = stateVars.TM_GetTransferIncomingRequestingStoreOptions ?? this.state.TM_GetTransferIncomingRequestingStoreOptions;
			
			stateVars.dataSource_993533 = stateVars.TM_GetTransferIncomingCreatorOptions ?? this.state.TM_GetTransferIncomingCreatorOptions;
			stateVars.dataSource_993533 = stateVars.TM_GetTransferIncomingCreatorOptions ?? this.state.TM_GetTransferIncomingCreatorOptions;
			
			stateVars.dataSource_69151 = stateVars.TM_GetTransferRequestTypeOptions ?? this.state.TM_GetTransferRequestTypeOptions;
			stateVars.dataSource_69151 = stateVars.TM_GetTransferRequestTypeOptions ?? this.state.TM_GetTransferRequestTypeOptions;
			
			stateVars.dataSource_782225 = stateVars.TM_GetTransferRequestsIncoming ?? this.state.TM_GetTransferRequestsIncoming;
			formVars.transfertalepleri_815611_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetTransferRequestsIncoming !== undefined ? (stateVars.TM_GetTransferRequestsIncoming?.length > 0 ? stateVars.TM_GetTransferRequestsIncoming[0].paginationLabel : null) : (this.state.TM_GetTransferRequestsIncoming?.length > 0 ? this.state.TM_GetTransferRequestsIncoming[0].paginationLabel : null)));

			formVars.transfertalepleri_429236_total = ReactSystemFunctions.value(this, (stateVars.TM_GetTransferRequestsIncoming !== undefined ? (stateVars.TM_GetTransferRequestsIncoming?.length > 0 ? stateVars.TM_GetTransferRequestsIncoming[0].totalCount : null) : (this.state.TM_GetTransferRequestsIncoming?.length > 0 ? this.state.TM_GetTransferRequestsIncoming[0].totalCount : null)));

			formVars.transfertalepleri_304759_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetTransferOutgoingHeaderMetrics !== undefined ? (stateVars.TM_GetTransferOutgoingHeaderMetrics?.length > 0 ? stateVars.TM_GetTransferOutgoingHeaderMetrics[0].totalCount : null) : (this.state.TM_GetTransferOutgoingHeaderMetrics?.length > 0 ? this.state.TM_GetTransferOutgoingHeaderMetrics[0].totalCount : null)));

			formVars.transfertalepleri_859473_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetTransferOutgoingHeaderMetrics !== undefined ? (stateVars.TM_GetTransferOutgoingHeaderMetrics?.length > 0 ? stateVars.TM_GetTransferOutgoingHeaderMetrics[0].pendingApprovalCount : null) : (this.state.TM_GetTransferOutgoingHeaderMetrics?.length > 0 ? this.state.TM_GetTransferOutgoingHeaderMetrics[0].pendingApprovalCount : null)));

			formVars.transfertalepleri_55877_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetTransferOutgoingHeaderMetrics !== undefined ? (stateVars.TM_GetTransferOutgoingHeaderMetrics?.length > 0 ? stateVars.TM_GetTransferOutgoingHeaderMetrics[0].transferWaitingCount : null) : (this.state.TM_GetTransferOutgoingHeaderMetrics?.length > 0 ? this.state.TM_GetTransferOutgoingHeaderMetrics[0].transferWaitingCount : null)));

			formVars.transfertalepleri_524626_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetTransferOutgoingHeaderMetrics !== undefined ? (stateVars.TM_GetTransferOutgoingHeaderMetrics?.length > 0 ? stateVars.TM_GetTransferOutgoingHeaderMetrics[0].inTransitCount : null) : (this.state.TM_GetTransferOutgoingHeaderMetrics?.length > 0 ? this.state.TM_GetTransferOutgoingHeaderMetrics[0].inTransitCount : null)));

			formVars.transfertalepleri_163922_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetTransferIncomingHeaderMetrics !== undefined ? (stateVars.TM_GetTransferIncomingHeaderMetrics?.length > 0 ? stateVars.TM_GetTransferIncomingHeaderMetrics[0].completedCount : null) : (this.state.TM_GetTransferIncomingHeaderMetrics?.length > 0 ? this.state.TM_GetTransferIncomingHeaderMetrics[0].completedCount : null)));

			formVars.transfertalepleri_368094_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetTransferIncomingHeaderMetrics !== undefined ? (stateVars.TM_GetTransferIncomingHeaderMetrics?.length > 0 ? stateVars.TM_GetTransferIncomingHeaderMetrics[0].cancelledCount : null) : (this.state.TM_GetTransferIncomingHeaderMetrics?.length > 0 ? this.state.TM_GetTransferIncomingHeaderMetrics[0].cancelledCount : null)));

			formVars.transfertalepleri_982825_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetTransferIncomingHeaderMetrics !== undefined ? (stateVars.TM_GetTransferIncomingHeaderMetrics?.length > 0 ? stateVars.TM_GetTransferIncomingHeaderMetrics[0].todayCount : null) : (this.state.TM_GetTransferIncomingHeaderMetrics?.length > 0 ? this.state.TM_GetTransferIncomingHeaderMetrics[0].todayCount : null)));

			
			stateVars.dataSource_995645 = stateVars.TM_GetTransferRequestStatusOptions ?? this.state.TM_GetTransferRequestStatusOptions;
			stateVars.dataSource_995645 = stateVars.TM_GetTransferRequestStatusOptions ?? this.state.TM_GetTransferRequestStatusOptions;
			
			stateVars.dataSource_513059 = stateVars.TM_GetTransferOutgoingRequestedStoreOptions ?? this.state.TM_GetTransferOutgoingRequestedStoreOptions;
			stateVars.dataSource_513059 = stateVars.TM_GetTransferOutgoingRequestedStoreOptions ?? this.state.TM_GetTransferOutgoingRequestedStoreOptions;
			
			stateVars.dataSource_433075 = stateVars.TM_GetTransferOutgoingCreatorOption ?? this.state.TM_GetTransferOutgoingCreatorOption;
			stateVars.dataSource_433075 = stateVars.TM_GetTransferOutgoingCreatorOption ?? this.state.TM_GetTransferOutgoingCreatorOption;
			
			stateVars.dataSource_86009 = stateVars.TM_GetTransferRequestTypeOptions ?? this.state.TM_GetTransferRequestTypeOptions;
			stateVars.dataSource_86009 = stateVars.TM_GetTransferRequestTypeOptions ?? this.state.TM_GetTransferRequestTypeOptions;
			
			stateVars.dataSource_681679 = stateVars.TM_GetTransferRequestsOutgoing ?? this.state.TM_GetTransferRequestsOutgoing;
			formVars.transfertalepleri_893312_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetTransferRequestsOutgoing !== undefined ? (stateVars.TM_GetTransferRequestsOutgoing?.length > 0 ? stateVars.TM_GetTransferRequestsOutgoing[0].paginationLabel : null) : (this.state.TM_GetTransferRequestsOutgoing?.length > 0 ? this.state.TM_GetTransferRequestsOutgoing[0].paginationLabel : null)));

			formVars.transfertalepleri_554974_total = ReactSystemFunctions.value(this, (stateVars.TM_GetTransferRequestsOutgoing !== undefined ? (stateVars.TM_GetTransferRequestsOutgoing?.length > 0 ? stateVars.TM_GetTransferRequestsOutgoing[0].totalCount : null) : (this.state.TM_GetTransferRequestsOutgoing?.length > 0 ? this.state.TM_GetTransferRequestsOutgoing[0].totalCount : null)));

			formVars.transfertalepleri_661617_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetTransferAllHeaderMetrics !== undefined ? (stateVars.TM_GetTransferAllHeaderMetrics?.length > 0 ? stateVars.TM_GetTransferAllHeaderMetrics[0].totalOpenCount : null) : (this.state.TM_GetTransferAllHeaderMetrics?.length > 0 ? this.state.TM_GetTransferAllHeaderMetrics[0].totalOpenCount : null)));

			formVars.transfertalepleri_312724_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetTransferAllHeaderMetrics !== undefined ? (stateVars.TM_GetTransferAllHeaderMetrics?.length > 0 ? stateVars.TM_GetTransferAllHeaderMetrics[0].inTransitCount : null) : (this.state.TM_GetTransferAllHeaderMetrics?.length > 0 ? this.state.TM_GetTransferAllHeaderMetrics[0].inTransitCount : null)));

			formVars.transfertalepleri_186038_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetTransferAllHeaderMetrics !== undefined ? (stateVars.TM_GetTransferAllHeaderMetrics?.length > 0 ? stateVars.TM_GetTransferAllHeaderMetrics[0].completedCount : null) : (this.state.TM_GetTransferAllHeaderMetrics?.length > 0 ? this.state.TM_GetTransferAllHeaderMetrics[0].completedCount : null)));

			formVars.transfertalepleri_135861_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetTransferAllHeaderMetrics !== undefined ? (stateVars.TM_GetTransferAllHeaderMetrics?.length > 0 ? stateVars.TM_GetTransferAllHeaderMetrics[0].todayCount : null) : (this.state.TM_GetTransferAllHeaderMetrics?.length > 0 ? this.state.TM_GetTransferAllHeaderMetrics[0].todayCount : null)));

			
			stateVars.dataSource_755228 = stateVars.TM_GetTransferRequestStatusOptions ?? this.state.TM_GetTransferRequestStatusOptions;
			stateVars.dataSource_755228 = stateVars.TM_GetTransferRequestStatusOptions ?? this.state.TM_GetTransferRequestStatusOptions;
			
			stateVars.dataSource_412000 = stateVars.TM_GetTransferStoreOptions ?? this.state.TM_GetTransferStoreOptions;
			stateVars.dataSource_412000 = stateVars.TM_GetTransferStoreOptions ?? this.state.TM_GetTransferStoreOptions;
			
			stateVars.dataSource_38408 = stateVars.TM_GetTransferStoreOptions ?? this.state.TM_GetTransferStoreOptions;
			stateVars.dataSource_38408 = stateVars.TM_GetTransferStoreOptions ?? this.state.TM_GetTransferStoreOptions;
			
			stateVars.dataSource_549686 = stateVars.TM_GetTransferAllCreatorOptions ?? this.state.TM_GetTransferAllCreatorOptions;
			stateVars.dataSource_549686 = stateVars.TM_GetTransferAllCreatorOptions ?? this.state.TM_GetTransferAllCreatorOptions;
			
			stateVars.dataSource_163767 = stateVars.TM_GetTransferRequestTypeOptions ?? this.state.TM_GetTransferRequestTypeOptions;
			stateVars.dataSource_163767 = stateVars.TM_GetTransferRequestTypeOptions ?? this.state.TM_GetTransferRequestTypeOptions;
			
			stateVars.dataSource_901194 = stateVars.TM_GetTransferRequestsAll ?? this.state.TM_GetTransferRequestsAll;
			formVars.transfertalepleri_155350_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetTransferRequestsAll !== undefined ? (stateVars.TM_GetTransferRequestsAll?.length > 0 ? stateVars.TM_GetTransferRequestsAll[0].paginationLabel : null) : (this.state.TM_GetTransferRequestsAll?.length > 0 ? this.state.TM_GetTransferRequestsAll[0].paginationLabel : null)));

			formVars.transfertalepleri_984416_total = ReactSystemFunctions.value(this, (stateVars.TM_GetTransferRequestsAll !== undefined ? (stateVars.TM_GetTransferRequestsAll?.length > 0 ? stateVars.TM_GetTransferRequestsAll[0].totalCount : null) : (this.state.TM_GetTransferRequestsAll?.length > 0 ? this.state.TM_GetTransferRequestsAll[0].totalCount : null)));


	this.props.form?.setFieldsValue(formVars);
	this.setState(stateVars);
	KuikaAppManager.hideSpinner(this);

            this.setPageInitLoaded(true);
            return isErrorOccurred;
        }




		TransferTalepleriComponent_627608_onClick = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations, this.checkTabErrors))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
KuikaAppManager.showSpinner(this);

					KuikaAppManager.prepareForNavigation();

				stateVars.NAVIGATE = await ReactSystemFunctions.navigate(this, undefined, "TransferTalepleri", "TransferTalebiOlusturV2", "", "7d969ddf-5801-4eb6-b92b-12be35bdd565", "321039", null, "right", "true", "60vw", "100vh", true, false);

		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

            
            return isErrorOccurred;
        }


		TransferTalepleriComponent_299914_onClick = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations, this.checkTabErrors))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
KuikaAppManager.showSpinner(this);

				stateVars.SetValueOf = await ReactSystemFunctions.setValueOf(this, ReactSystemFunctions.convertToTypeByName("transfertalepleri_782225_value", "string"), 1, ReactSystemFunctions.convertToTypeByName("current", "string"), false);

		this.props.form?.setFieldsValue(formVars);
		
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.TransferTalepleriComponent_299914_onClick1_();
                  resolve();
                });
          })

            
            return isErrorOccurred;
        }
    TransferTalepleriComponent_299914_onClick1_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations, this.checkTabErrors))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
		KuikaAppManager.increaseServerRequestCount();


        let localVar = {
				CurrentUsername_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.getMyUsername(), "string"),
				RequestNumber_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "transfertalepleri_854593_value", "value", "", "", "")), "string"),
				StatusIds_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "transfertalepleri_603398_value", "value", "TM_GetTransferRequestStatusOptions", "id", "id")), "string"),
				RequestingStoreCodes_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "transfertalepleri_395073_value", "value", "TM_GetTransferIncomingRequestingStoreOptions", "storeCode", "storeCode")), "string"),
				RequestedStoreCodes_0: ReactSystemFunctions.convertToTypeByName(null, "string"),
				RequestTypeCodes_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "transfertalepleri_69151_value", "value", "TM_GetTransferRequestTypeOptions", "code", "code")), "string"),
				ProductSearch_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "transfertalepleri_772464_value", "value", "", "", "")), "string"),
				CreatedByIds_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "transfertalepleri_993533_value", "value", "TM_GetTransferIncomingCreatorOptions", "kUserId", "kUserId")), "string"),
				RequestDateFrom_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "transfertalepleri_633048_value", "value", "", "", "")), "Date"),
				RequestDateTo_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "transfertalepleri_993607_value", "value", "", "", "")), "Date"),
				DecisionDateFrom_0: ReactSystemFunctions.convertToTypeByName(null, "Date"),
				DecisionDateTo_0: ReactSystemFunctions.convertToTypeByName(null, "Date"),
				CurrentPage_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "transfertalepleri_429236_value", "current", "", "", "")), "number"),
				PageSize_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "transfertalepleri_429236_value", "pageSize", "", "", "")), "number")
        }

		
        if (true) {
        KuikaAppManager.showSpinner(this);
        }
        let result = await KuikaAppManager.ApiRequest(this, "TransferTalepleri/TransferTalepleriComponent_299914_onClick1_", localVar)
        if (!KMainFunctions.IsResStatus2XX(result)) return true;

			stateVars.TM_GetTransferRequestsIncoming = result?.data.tM_GetTransferRequestsIncoming;
			
			formVars.transfertalepleri_815611_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetTransferRequestsIncoming !== undefined ? (stateVars.TM_GetTransferRequestsIncoming?.length > 0 ? stateVars.TM_GetTransferRequestsIncoming[0].paginationLabel : null) : (this.state.TM_GetTransferRequestsIncoming?.length > 0 ? this.state.TM_GetTransferRequestsIncoming[0].paginationLabel : null)));
			this.props.form?.setFieldsValue(formVars);
			
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.TransferTalepleriComponent_299914_onClick2_();
                  resolve();
                });
          })



        
        KuikaAppManager.hideSpinner(this);
        return isErrorOccurred;
    }
		TransferTalepleriComponent_299914_onClick2_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations, this.checkTabErrors))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }

				
				stateVars.dataSource_782225 = stateVars.TM_GetTransferRequestsIncoming ?? this.state.TM_GetTransferRequestsIncoming;
				formVars.transfertalepleri_815611_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetTransferRequestsIncoming !== undefined ? (stateVars.TM_GetTransferRequestsIncoming?.length > 0 ? stateVars.TM_GetTransferRequestsIncoming[0].paginationLabel : null) : (this.state.TM_GetTransferRequestsIncoming?.length > 0 ? this.state.TM_GetTransferRequestsIncoming[0].paginationLabel : null)));

				formVars.transfertalepleri_429236_total = ReactSystemFunctions.value(this, (stateVars.TM_GetTransferRequestsIncoming !== undefined ? (stateVars.TM_GetTransferRequestsIncoming?.length > 0 ? stateVars.TM_GetTransferRequestsIncoming[0].totalCount : null) : (this.state.TM_GetTransferRequestsIncoming?.length > 0 ? this.state.TM_GetTransferRequestsIncoming[0].totalCount : null)));


		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

            
            return isErrorOccurred;
        }





		TransferTalepleriComponent_22006_onClick = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations, this.checkTabErrors))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
KuikaAppManager.showSpinner(this);

				stateVars.SetValueOf = await ReactSystemFunctions.setValueOf(this, ReactSystemFunctions.convertToTypeByName("transfertalepleri_854593_value", "string"), "", null, false);
				stateVars.SetValueOf = await ReactSystemFunctions.setValueOf(this, ReactSystemFunctions.convertToTypeByName("transfertalepleri_603398_value", "string"), "", null, false);
				stateVars.SetValueOf = await ReactSystemFunctions.setValueOf(this, ReactSystemFunctions.convertToTypeByName("transfertalepleri_395073_value", "string"), "", null, "StoreCode");
				stateVars.SetValueOf = await ReactSystemFunctions.setValueOf(this, ReactSystemFunctions.convertToTypeByName("transfertalepleri_993533_value", "string"), "", null, "KUserId");
				stateVars.SetValueOf = await ReactSystemFunctions.setValueOf(this, ReactSystemFunctions.convertToTypeByName("transfertalepleri_69151_value", "string"), "", null, "Code");
				stateVars.SetValueOf = await ReactSystemFunctions.setValueOf(this, ReactSystemFunctions.convertToTypeByName("transfertalepleri_772464_value", "string"), "", null, false);
				stateVars.SetValueOf = await ReactSystemFunctions.setValueOf(this, ReactSystemFunctions.convertToTypeByName("transfertalepleri_633048_value", "string"), "", null, false);
				stateVars.SetValueOf = await ReactSystemFunctions.setValueOf(this, ReactSystemFunctions.convertToTypeByName("transfertalepleri_993607_value", "string"), "", null, false);

		this.props.form?.setFieldsValue(formVars);
		
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.TransferTalepleriComponent_22006_onClick1_();
                  resolve();
                });
          })

            
            return isErrorOccurred;
        }
    TransferTalepleriComponent_22006_onClick1_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations, this.checkTabErrors))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
		KuikaAppManager.increaseServerRequestCount();


        let localVar = {
				CurrentUsername_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.getMyUsername(), "string"),
				RequestNumber_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "transfertalepleri_854593_value", "value", "", "", "")), "string"),
				StatusIds_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "transfertalepleri_603398_value", "value", "TM_GetTransferRequestStatusOptions", "id", "id")), "string"),
				RequestingStoreCodes_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "transfertalepleri_395073_value", "value", "TM_GetTransferIncomingRequestingStoreOptions", "storeCode", "storeCode")), "string"),
				RequestedStoreCodes_0: ReactSystemFunctions.convertToTypeByName("", "string"),
				RequestTypeCodes_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "transfertalepleri_69151_value", "value", "TM_GetTransferRequestTypeOptions", "code", "code")), "string"),
				ProductSearch_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "transfertalepleri_772464_value", "value", "", "", "")), "string"),
				CreatedByIds_0: ReactSystemFunctions.convertToTypeByName("", "string"),
				RequestDateFrom_0: ReactSystemFunctions.convertToTypeByName(null, "Date"),
				RequestDateTo_0: ReactSystemFunctions.convertToTypeByName(null, "Date"),
				DecisionDateFrom_0: ReactSystemFunctions.convertToTypeByName(null, "Date"),
				DecisionDateTo_0: ReactSystemFunctions.convertToTypeByName(null, "Date"),
				CurrentPage_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "transfertalepleri_429236_value", "current", "", "", "")), "number"),
				PageSize_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "transfertalepleri_429236_value", "pageSize", "", "", "")), "number"),
				CurrentUsername_1: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.getMyUsername(), "string"),
				RequestNumber_1: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "transfertalepleri_854593_value", "value", "", "", "")), "string"),
				StatusIds_1: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "transfertalepleri_603398_value", "value", "TM_GetTransferRequestStatusOptions", "id", "code")), "string"),
				RequestingStoreCodes_1: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "transfertalepleri_395073_value", "value", "TM_GetTransferIncomingRequestingStoreOptions", "storeCode", "storeCode")), "string"),
				RequestTypeCodes_1: ReactSystemFunctions.convertToTypeByName("", "string"),
				ProductSearch_1: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "transfertalepleri_772464_value", "value", "", "", "")), "string"),
				CreatedByIds_1: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "transfertalepleri_993533_value", "value", "TM_GetTransferIncomingCreatorOptions", "kUserId", "kUserId")), "string"),
				RequestDateFrom_1: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "transfertalepleri_633048_value", "value", "", "", "")), "Date"),
				RequestDateTo_1: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "transfertalepleri_993607_value", "value", "", "", "")), "Date")
        }

		
        if (true) {
        KuikaAppManager.showSpinner(this);
        }
        let result = await KuikaAppManager.ApiRequest(this, "TransferTalepleri/TransferTalepleriComponent_22006_onClick1_", localVar)
        if (!KMainFunctions.IsResStatus2XX(result)) return true;

			stateVars.TM_GetTransferRequestsIncoming = result?.data.tM_GetTransferRequestsIncoming;
			
			formVars.transfertalepleri_815611_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetTransferRequestsIncoming !== undefined ? (stateVars.TM_GetTransferRequestsIncoming?.length > 0 ? stateVars.TM_GetTransferRequestsIncoming[0].paginationLabel : null) : (this.state.TM_GetTransferRequestsIncoming?.length > 0 ? this.state.TM_GetTransferRequestsIncoming[0].paginationLabel : null)));
			stateVars.TM_GetTransferIncomingHeaderMetrics = result?.data.tM_GetTransferIncomingHeaderMetrics;
			formVars.transfertalepleri_549601_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetTransferIncomingHeaderMetrics !== undefined ? (stateVars.TM_GetTransferIncomingHeaderMetrics?.length > 0 ? stateVars.TM_GetTransferIncomingHeaderMetrics[0].totalCount : null) : (this.state.TM_GetTransferIncomingHeaderMetrics?.length > 0 ? this.state.TM_GetTransferIncomingHeaderMetrics[0].totalCount : null)));
			formVars.transfertalepleri_512439_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetTransferIncomingHeaderMetrics !== undefined ? (stateVars.TM_GetTransferIncomingHeaderMetrics?.length > 0 ? stateVars.TM_GetTransferIncomingHeaderMetrics[0].pendingApprovalCount : null) : (this.state.TM_GetTransferIncomingHeaderMetrics?.length > 0 ? this.state.TM_GetTransferIncomingHeaderMetrics[0].pendingApprovalCount : null)));
			formVars.transfertalepleri_151087_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetTransferIncomingHeaderMetrics !== undefined ? (stateVars.TM_GetTransferIncomingHeaderMetrics?.length > 0 ? stateVars.TM_GetTransferIncomingHeaderMetrics[0].transferWaitingCount : null) : (this.state.TM_GetTransferIncomingHeaderMetrics?.length > 0 ? this.state.TM_GetTransferIncomingHeaderMetrics[0].transferWaitingCount : null)));
			formVars.transfertalepleri_548723_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetTransferIncomingHeaderMetrics !== undefined ? (stateVars.TM_GetTransferIncomingHeaderMetrics?.length > 0 ? stateVars.TM_GetTransferIncomingHeaderMetrics[0].inTransitCount : null) : (this.state.TM_GetTransferIncomingHeaderMetrics?.length > 0 ? this.state.TM_GetTransferIncomingHeaderMetrics[0].inTransitCount : null)));
			formVars.transfertalepleri_59903_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetTransferIncomingHeaderMetrics !== undefined ? (stateVars.TM_GetTransferIncomingHeaderMetrics?.length > 0 ? stateVars.TM_GetTransferIncomingHeaderMetrics[0].completedCount : null) : (this.state.TM_GetTransferIncomingHeaderMetrics?.length > 0 ? this.state.TM_GetTransferIncomingHeaderMetrics[0].completedCount : null)));
			formVars.transfertalepleri_968525_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetTransferIncomingHeaderMetrics !== undefined ? (stateVars.TM_GetTransferIncomingHeaderMetrics?.length > 0 ? stateVars.TM_GetTransferIncomingHeaderMetrics[0].cancelledCount : null) : (this.state.TM_GetTransferIncomingHeaderMetrics?.length > 0 ? this.state.TM_GetTransferIncomingHeaderMetrics[0].cancelledCount : null)));
			formVars.transfertalepleri_543915_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetTransferIncomingHeaderMetrics !== undefined ? (stateVars.TM_GetTransferIncomingHeaderMetrics?.length > 0 ? stateVars.TM_GetTransferIncomingHeaderMetrics[0].todayCount : null) : (this.state.TM_GetTransferIncomingHeaderMetrics?.length > 0 ? this.state.TM_GetTransferIncomingHeaderMetrics[0].todayCount : null)));
			formVars.transfertalepleri_163922_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetTransferIncomingHeaderMetrics !== undefined ? (stateVars.TM_GetTransferIncomingHeaderMetrics?.length > 0 ? stateVars.TM_GetTransferIncomingHeaderMetrics[0].completedCount : null) : (this.state.TM_GetTransferIncomingHeaderMetrics?.length > 0 ? this.state.TM_GetTransferIncomingHeaderMetrics[0].completedCount : null)));
			formVars.transfertalepleri_368094_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetTransferIncomingHeaderMetrics !== undefined ? (stateVars.TM_GetTransferIncomingHeaderMetrics?.length > 0 ? stateVars.TM_GetTransferIncomingHeaderMetrics[0].cancelledCount : null) : (this.state.TM_GetTransferIncomingHeaderMetrics?.length > 0 ? this.state.TM_GetTransferIncomingHeaderMetrics[0].cancelledCount : null)));
			formVars.transfertalepleri_982825_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetTransferIncomingHeaderMetrics !== undefined ? (stateVars.TM_GetTransferIncomingHeaderMetrics?.length > 0 ? stateVars.TM_GetTransferIncomingHeaderMetrics[0].todayCount : null) : (this.state.TM_GetTransferIncomingHeaderMetrics?.length > 0 ? this.state.TM_GetTransferIncomingHeaderMetrics[0].todayCount : null)));
			this.props.form?.setFieldsValue(formVars);
			
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.TransferTalepleriComponent_22006_onClick2_();
                  resolve();
                });
          })



        
        KuikaAppManager.hideSpinner(this);
        return isErrorOccurred;
    }
		TransferTalepleriComponent_22006_onClick2_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations, this.checkTabErrors))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }

				formVars.transfertalepleri_549601_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetTransferIncomingHeaderMetrics !== undefined ? (stateVars.TM_GetTransferIncomingHeaderMetrics?.length > 0 ? stateVars.TM_GetTransferIncomingHeaderMetrics[0].totalCount : null) : (this.state.TM_GetTransferIncomingHeaderMetrics?.length > 0 ? this.state.TM_GetTransferIncomingHeaderMetrics[0].totalCount : null)));

				formVars.transfertalepleri_512439_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetTransferIncomingHeaderMetrics !== undefined ? (stateVars.TM_GetTransferIncomingHeaderMetrics?.length > 0 ? stateVars.TM_GetTransferIncomingHeaderMetrics[0].pendingApprovalCount : null) : (this.state.TM_GetTransferIncomingHeaderMetrics?.length > 0 ? this.state.TM_GetTransferIncomingHeaderMetrics[0].pendingApprovalCount : null)));

				formVars.transfertalepleri_151087_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetTransferIncomingHeaderMetrics !== undefined ? (stateVars.TM_GetTransferIncomingHeaderMetrics?.length > 0 ? stateVars.TM_GetTransferIncomingHeaderMetrics[0].transferWaitingCount : null) : (this.state.TM_GetTransferIncomingHeaderMetrics?.length > 0 ? this.state.TM_GetTransferIncomingHeaderMetrics[0].transferWaitingCount : null)));

				formVars.transfertalepleri_548723_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetTransferIncomingHeaderMetrics !== undefined ? (stateVars.TM_GetTransferIncomingHeaderMetrics?.length > 0 ? stateVars.TM_GetTransferIncomingHeaderMetrics[0].inTransitCount : null) : (this.state.TM_GetTransferIncomingHeaderMetrics?.length > 0 ? this.state.TM_GetTransferIncomingHeaderMetrics[0].inTransitCount : null)));

				formVars.transfertalepleri_59903_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetTransferIncomingHeaderMetrics !== undefined ? (stateVars.TM_GetTransferIncomingHeaderMetrics?.length > 0 ? stateVars.TM_GetTransferIncomingHeaderMetrics[0].completedCount : null) : (this.state.TM_GetTransferIncomingHeaderMetrics?.length > 0 ? this.state.TM_GetTransferIncomingHeaderMetrics[0].completedCount : null)));

				formVars.transfertalepleri_968525_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetTransferIncomingHeaderMetrics !== undefined ? (stateVars.TM_GetTransferIncomingHeaderMetrics?.length > 0 ? stateVars.TM_GetTransferIncomingHeaderMetrics[0].cancelledCount : null) : (this.state.TM_GetTransferIncomingHeaderMetrics?.length > 0 ? this.state.TM_GetTransferIncomingHeaderMetrics[0].cancelledCount : null)));

				formVars.transfertalepleri_543915_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetTransferIncomingHeaderMetrics !== undefined ? (stateVars.TM_GetTransferIncomingHeaderMetrics?.length > 0 ? stateVars.TM_GetTransferIncomingHeaderMetrics[0].todayCount : null) : (this.state.TM_GetTransferIncomingHeaderMetrics?.length > 0 ? this.state.TM_GetTransferIncomingHeaderMetrics[0].todayCount : null)));

				
				stateVars.dataSource_782225 = stateVars.TM_GetTransferRequestsIncoming ?? this.state.TM_GetTransferRequestsIncoming;
				formVars.transfertalepleri_815611_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetTransferRequestsIncoming !== undefined ? (stateVars.TM_GetTransferRequestsIncoming?.length > 0 ? stateVars.TM_GetTransferRequestsIncoming[0].paginationLabel : null) : (this.state.TM_GetTransferRequestsIncoming?.length > 0 ? this.state.TM_GetTransferRequestsIncoming[0].paginationLabel : null)));

				formVars.transfertalepleri_429236_total = ReactSystemFunctions.value(this, (stateVars.TM_GetTransferRequestsIncoming !== undefined ? (stateVars.TM_GetTransferRequestsIncoming?.length > 0 ? stateVars.TM_GetTransferRequestsIncoming[0].totalCount : null) : (this.state.TM_GetTransferRequestsIncoming?.length > 0 ? this.state.TM_GetTransferRequestsIncoming[0].totalCount : null)));

				formVars.transfertalepleri_163922_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetTransferIncomingHeaderMetrics !== undefined ? (stateVars.TM_GetTransferIncomingHeaderMetrics?.length > 0 ? stateVars.TM_GetTransferIncomingHeaderMetrics[0].completedCount : null) : (this.state.TM_GetTransferIncomingHeaderMetrics?.length > 0 ? this.state.TM_GetTransferIncomingHeaderMetrics[0].completedCount : null)));

				formVars.transfertalepleri_368094_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetTransferIncomingHeaderMetrics !== undefined ? (stateVars.TM_GetTransferIncomingHeaderMetrics?.length > 0 ? stateVars.TM_GetTransferIncomingHeaderMetrics[0].cancelledCount : null) : (this.state.TM_GetTransferIncomingHeaderMetrics?.length > 0 ? this.state.TM_GetTransferIncomingHeaderMetrics[0].cancelledCount : null)));

				formVars.transfertalepleri_982825_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetTransferIncomingHeaderMetrics !== undefined ? (stateVars.TM_GetTransferIncomingHeaderMetrics?.length > 0 ? stateVars.TM_GetTransferIncomingHeaderMetrics[0].todayCount : null) : (this.state.TM_GetTransferIncomingHeaderMetrics?.length > 0 ? this.state.TM_GetTransferIncomingHeaderMetrics[0].todayCount : null)));


		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

            
            return isErrorOccurred;
        }





		TransferTalepleriComponent_284990_onClick = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations, this.checkTabErrors))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
KuikaAppManager.showSpinner(this);

					KuikaAppManager.prepareForNavigation();
						KuikaAppManager.addToPageInputVariables("TransferTalepDetay", "TransferRequestHeaderId", ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, "transfertalepleri_782225_value", "requestHeaderId"), "Guid"));

				stateVars.NAVIGATE = await ReactSystemFunctions.navigate(this, undefined, "TransferTalepleri", "TransferTalepDetay", "", "7d969ddf-5801-4eb6-b92b-12be35bdd565", "192218", null, "right", "true", "50vw", "100vh", true, false);

		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

            
            return isErrorOccurred;
        }


    TransferTalepleriComponent_429236_onChange = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations, this.checkTabErrors))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
		KuikaAppManager.increaseServerRequestCount();

        let localVar = {
				CurrentUsername_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.getMyUsername(), "string"),
				RequestNumber_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "transfertalepleri_854593_value", "value", "", "", "")), "string"),
				StatusIds_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "transfertalepleri_603398_value", "value", "TM_GetTransferRequestStatusOptions", "id", "id")), "string"),
				RequestingStoreCodes_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "transfertalepleri_395073_value", "value", "TM_GetTransferIncomingRequestingStoreOptions", "storeCode", "storeCode")), "string"),
				RequestedStoreCodes_0: ReactSystemFunctions.convertToTypeByName("", "string"),
				RequestTypeCodes_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "transfertalepleri_69151_value", "value", "TM_GetTransferRequestTypeOptions", "code", "code")), "string"),
				ProductSearch_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "transfertalepleri_772464_value", "value", "", "", "")), "string"),
				CreatedByIds_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "transfertalepleri_993533_value", "value", "TM_GetTransferIncomingCreatorOptions", "kUserId", "kUserId")), "string"),
				RequestDateFrom_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "transfertalepleri_633048_value", "value", "", "", "")), "Date"),
				RequestDateTo_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "transfertalepleri_993607_value", "value", "", "", "")), "Date"),
				DecisionDateFrom_0: ReactSystemFunctions.convertToTypeByName("", "Date"),
				DecisionDateTo_0: ReactSystemFunctions.convertToTypeByName("", "Date"),
				CurrentPage_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "transfertalepleri_429236_value", "current", "", "", "")), "number"),
				PageSize_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "transfertalepleri_429236_value", "pageSize", "", "", "")), "number")
        }

		KuikaAppManager.showSpinner(this);
		
        if (true) {
        KuikaAppManager.showSpinner(this);
        }
        let result = await KuikaAppManager.ApiRequest(this, "TransferTalepleri/TransferTalepleriComponent_429236_onChange", localVar)
        if (!KMainFunctions.IsResStatus2XX(result)) return true;

			stateVars.TM_GetTransferRequestsIncoming = result?.data.tM_GetTransferRequestsIncoming;
			
			formVars.transfertalepleri_815611_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetTransferRequestsIncoming !== undefined ? (stateVars.TM_GetTransferRequestsIncoming?.length > 0 ? stateVars.TM_GetTransferRequestsIncoming[0].paginationLabel : null) : (this.state.TM_GetTransferRequestsIncoming?.length > 0 ? this.state.TM_GetTransferRequestsIncoming[0].paginationLabel : null)));
			this.props.form?.setFieldsValue(formVars);
			
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.TransferTalepleriComponent_429236_onChange1_();
                  resolve();
                });
          })



        
        KuikaAppManager.hideSpinner(this);
        return isErrorOccurred;
    }
		TransferTalepleriComponent_429236_onChange1_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations, this.checkTabErrors))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }

				
				stateVars.dataSource_782225 = stateVars.TM_GetTransferRequestsIncoming ?? this.state.TM_GetTransferRequestsIncoming;
				formVars.transfertalepleri_815611_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetTransferRequestsIncoming !== undefined ? (stateVars.TM_GetTransferRequestsIncoming?.length > 0 ? stateVars.TM_GetTransferRequestsIncoming[0].paginationLabel : null) : (this.state.TM_GetTransferRequestsIncoming?.length > 0 ? this.state.TM_GetTransferRequestsIncoming[0].paginationLabel : null)));

				formVars.transfertalepleri_429236_total = ReactSystemFunctions.value(this, (stateVars.TM_GetTransferRequestsIncoming !== undefined ? (stateVars.TM_GetTransferRequestsIncoming?.length > 0 ? stateVars.TM_GetTransferRequestsIncoming[0].totalCount : null) : (this.state.TM_GetTransferRequestsIncoming?.length > 0 ? this.state.TM_GetTransferRequestsIncoming[0].totalCount : null)));


		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

            
            return isErrorOccurred;
        }




    TransferTalepleriComponent_529588_onClick = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations, this.checkTabErrors))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
		KuikaAppManager.increaseServerRequestCount();


        let localVar = {
				CurrentUsername_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.getMyUsername(), "string"),
				RequestNumber_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "transfertalepleri_50402_value", "value", "", "", "")), "string"),
				StatusIds_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "transfertalepleri_995645_value", "value", "TM_GetTransferRequestStatusOptions", "id", "id")), "string"),
				RequestingStoreCodes_0: ReactSystemFunctions.convertToTypeByName(null, "string"),
				RequestedStoreCodes_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "transfertalepleri_513059_value", "value", "TM_GetTransferOutgoingRequestedStoreOptions", "storeCode", "storeCode")), "string"),
				RequestTypeCodes_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "transfertalepleri_86009_value", "value", "TM_GetTransferRequestTypeOptions", "code", "")), "string"),
				ProductSearch_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "transfertalepleri_809044_value", "value", "", "", "")), "string"),
				CreatedByIds_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "transfertalepleri_433075_value", "value", "TM_GetTransferOutgoingCreatorOption", "id", "id")), "string"),
				RequestDateFrom_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "transfertalepleri_401386_value", "value", "", "", "")), "Date"),
				RequestDateTo_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "transfertalepleri_959886_value", "value", "", "", "")), "Date"),
				DecisionDateFrom_0: ReactSystemFunctions.convertToTypeByName(null, "Date"),
				DecisionDateTo_0: ReactSystemFunctions.convertToTypeByName(null, "Date"),
				CurrentPage_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "transfertalepleri_554974_value", "current", "", "", "")), "number"),
				PageSize_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "transfertalepleri_554974_value", "pageSize", "", "", "")), "number")
        }

		KuikaAppManager.showSpinner(this);
		
        if (true) {
        KuikaAppManager.showSpinner(this);
        }
        let result = await KuikaAppManager.ApiRequest(this, "TransferTalepleri/TransferTalepleriComponent_529588_onClick", localVar)
        if (!KMainFunctions.IsResStatus2XX(result)) return true;

			stateVars.TM_GetTransferRequestsOutgoing = result?.data.tM_GetTransferRequestsOutgoing;
			
			formVars.transfertalepleri_893312_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetTransferRequestsOutgoing !== undefined ? (stateVars.TM_GetTransferRequestsOutgoing?.length > 0 ? stateVars.TM_GetTransferRequestsOutgoing[0].paginationLabel : null) : (this.state.TM_GetTransferRequestsOutgoing?.length > 0 ? this.state.TM_GetTransferRequestsOutgoing[0].paginationLabel : null)));
			this.props.form?.setFieldsValue(formVars);
			
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.TransferTalepleriComponent_529588_onClick1_();
                  resolve();
                });
          })



        
        KuikaAppManager.hideSpinner(this);
        return isErrorOccurred;
    }
		TransferTalepleriComponent_529588_onClick1_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations, this.checkTabErrors))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }

				
				stateVars.dataSource_681679 = stateVars.TM_GetTransferRequestsOutgoing ?? this.state.TM_GetTransferRequestsOutgoing;
				formVars.transfertalepleri_893312_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetTransferRequestsOutgoing !== undefined ? (stateVars.TM_GetTransferRequestsOutgoing?.length > 0 ? stateVars.TM_GetTransferRequestsOutgoing[0].paginationLabel : null) : (this.state.TM_GetTransferRequestsOutgoing?.length > 0 ? this.state.TM_GetTransferRequestsOutgoing[0].paginationLabel : null)));

				formVars.transfertalepleri_554974_total = ReactSystemFunctions.value(this, (stateVars.TM_GetTransferRequestsOutgoing !== undefined ? (stateVars.TM_GetTransferRequestsOutgoing?.length > 0 ? stateVars.TM_GetTransferRequestsOutgoing[0].totalCount : null) : (this.state.TM_GetTransferRequestsOutgoing?.length > 0 ? this.state.TM_GetTransferRequestsOutgoing[0].totalCount : null)));


		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

            
            return isErrorOccurred;
        }




		TransferTalepleriComponent_684523_onClick = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations, this.checkTabErrors))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
KuikaAppManager.showSpinner(this);

				stateVars.SetValueOf = await ReactSystemFunctions.setValueOf(this, ReactSystemFunctions.convertToTypeByName("transfertalepleri_995645_value", "string"), "", null, false);
				stateVars.SetValueOf = await ReactSystemFunctions.setValueOf(this, ReactSystemFunctions.convertToTypeByName("transfertalepleri_50402_value", "string"), "", null, false);
				stateVars.SetValueOf = await ReactSystemFunctions.setValueOf(this, ReactSystemFunctions.convertToTypeByName("transfertalepleri_513059_value", "string"), "", null, "StoreCode");
				stateVars.SetValueOf = await ReactSystemFunctions.setValueOf(this, ReactSystemFunctions.convertToTypeByName("transfertalepleri_86009_value", "string"), "", null, "Code");
				stateVars.SetValueOf = await ReactSystemFunctions.setValueOf(this, ReactSystemFunctions.convertToTypeByName("transfertalepleri_433075_value", "string"), "", null, "Id");
				stateVars.SetValueOf = await ReactSystemFunctions.setValueOf(this, ReactSystemFunctions.convertToTypeByName("transfertalepleri_809044_value", "string"), "", null, false);
				stateVars.SetValueOf = await ReactSystemFunctions.setValueOf(this, ReactSystemFunctions.convertToTypeByName("transfertalepleri_401386_value", "string"), "", null, false);
				stateVars.SetValueOf = await ReactSystemFunctions.setValueOf(this, ReactSystemFunctions.convertToTypeByName("transfertalepleri_959886_value", "string"), "", null, false);

		this.props.form?.setFieldsValue(formVars);
		
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.TransferTalepleriComponent_684523_onClick1_();
                  resolve();
                });
          })

            
            return isErrorOccurred;
        }
    TransferTalepleriComponent_684523_onClick1_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations, this.checkTabErrors))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
		KuikaAppManager.increaseServerRequestCount();


        let localVar = {
				CurrentUsername_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.getMyUsername(), "string"),
				RequestNumber_0: ReactSystemFunctions.convertToTypeByName(null, "string"),
				StatusIds_0: ReactSystemFunctions.convertToTypeByName(null, "string"),
				RequestingStoreCodes_0: ReactSystemFunctions.convertToTypeByName(null, "string"),
				RequestedStoreCodes_0: ReactSystemFunctions.convertToTypeByName(null, "string"),
				RequestTypeCodes_0: ReactSystemFunctions.convertToTypeByName(null, "string"),
				ProductSearch_0: ReactSystemFunctions.convertToTypeByName(null, "string"),
				CreatedByIds_0: ReactSystemFunctions.convertToTypeByName(null, "string"),
				RequestDateFrom_0: ReactSystemFunctions.convertToTypeByName(null, "Date"),
				RequestDateTo_0: ReactSystemFunctions.convertToTypeByName(null, "Date"),
				DecisionDateFrom_0: ReactSystemFunctions.convertToTypeByName(null, "Date"),
				DecisionDateTo_0: ReactSystemFunctions.convertToTypeByName(null, "Date"),
				CurrentPage_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "transfertalepleri_554974_value", "current", "", "", "")), "number"),
				PageSize_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "transfertalepleri_554974_value", "pageSize", "", "", "")), "number")
        }

		
        if (true) {
        KuikaAppManager.showSpinner(this);
        }
        let result = await KuikaAppManager.ApiRequest(this, "TransferTalepleri/TransferTalepleriComponent_684523_onClick1_", localVar)
        if (!KMainFunctions.IsResStatus2XX(result)) return true;

			stateVars.TM_GetTransferRequestsOutgoing = result?.data.tM_GetTransferRequestsOutgoing;
			
			formVars.transfertalepleri_893312_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetTransferRequestsOutgoing !== undefined ? (stateVars.TM_GetTransferRequestsOutgoing?.length > 0 ? stateVars.TM_GetTransferRequestsOutgoing[0].paginationLabel : null) : (this.state.TM_GetTransferRequestsOutgoing?.length > 0 ? this.state.TM_GetTransferRequestsOutgoing[0].paginationLabel : null)));
			this.props.form?.setFieldsValue(formVars);
			
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.TransferTalepleriComponent_684523_onClick2_();
                  resolve();
                });
          })



        
        KuikaAppManager.hideSpinner(this);
        return isErrorOccurred;
    }
		TransferTalepleriComponent_684523_onClick2_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations, this.checkTabErrors))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }

				
				stateVars.dataSource_681679 = stateVars.TM_GetTransferRequestsOutgoing ?? this.state.TM_GetTransferRequestsOutgoing;
				formVars.transfertalepleri_893312_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetTransferRequestsOutgoing !== undefined ? (stateVars.TM_GetTransferRequestsOutgoing?.length > 0 ? stateVars.TM_GetTransferRequestsOutgoing[0].paginationLabel : null) : (this.state.TM_GetTransferRequestsOutgoing?.length > 0 ? this.state.TM_GetTransferRequestsOutgoing[0].paginationLabel : null)));

				formVars.transfertalepleri_554974_total = ReactSystemFunctions.value(this, (stateVars.TM_GetTransferRequestsOutgoing !== undefined ? (stateVars.TM_GetTransferRequestsOutgoing?.length > 0 ? stateVars.TM_GetTransferRequestsOutgoing[0].totalCount : null) : (this.state.TM_GetTransferRequestsOutgoing?.length > 0 ? this.state.TM_GetTransferRequestsOutgoing[0].totalCount : null)));


		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

            
            return isErrorOccurred;
        }





		TransferTalepleriComponent_483178_onClick = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations, this.checkTabErrors))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
KuikaAppManager.showSpinner(this);

					KuikaAppManager.prepareForNavigation();
						KuikaAppManager.addToPageInputVariables("TransferTalepDetay", "TransferRequestHeaderId", ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, "transfertalepleri_681679_value", "requestHeaderId"), "Guid"));

				stateVars.NAVIGATE = await ReactSystemFunctions.navigate(this, undefined, "TransferTalepleri", "TransferTalepDetay", "", "7d969ddf-5801-4eb6-b92b-12be35bdd565", "937423", null, "right", "true", "50vw", "100vh", true, false);

		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

            
            return isErrorOccurred;
        }


    TransferTalepleriComponent_294970_onClick = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations, this.checkTabErrors))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
		KuikaAppManager.increaseServerRequestCount();


        let localVar = {
				CurrentUsername_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.getMyUsername(), "string"),
				RequestNumber_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "transfertalepleri_519462_value", "value", "", "", "")), "string"),
				StatusIds_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "transfertalepleri_755228_value", "value", "TM_GetTransferRequestStatusOptions", "id", "id")), "string"),
				RequestingStoreCodes_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "transfertalepleri_412000_value", "value", "TM_GetTransferStoreOptions", "storeCode", "storeCode")), "string"),
				RequestedStoreCodes_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "transfertalepleri_38408_value", "value", "TM_GetTransferStoreOptions", "storeCode", "storeCode")), "string"),
				RequestTypeCodes_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "transfertalepleri_163767_value", "value", "TM_GetTransferRequestTypeOptions", "code", "")), "string"),
				ProductSearch_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "transfertalepleri_815155_value", "value", "", "", "")), "string"),
				CreatedByIds_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "transfertalepleri_549686_value", "value", "TM_GetTransferAllCreatorOptions", "id", "id")), "string"),
				RequestDateFrom_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "transfertalepleri_374249_value", "value", "", "", "")), "Date"),
				RequestDateTo_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "transfertalepleri_959115_value", "value", "", "", "")), "Date"),
				DecisionDateFrom_0: ReactSystemFunctions.convertToTypeByName(null, "Date"),
				DecisionDateTo_0: ReactSystemFunctions.convertToTypeByName(null, "Date"),
				CurrentPage_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "transfertalepleri_984416_value", "current", "", "", "")), "number"),
				PageSize_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "transfertalepleri_984416_value", "pageSize", "", "", "")), "number")
        }

		KuikaAppManager.showSpinner(this);
		
        if (true) {
        KuikaAppManager.showSpinner(this);
        }
        let result = await KuikaAppManager.ApiRequest(this, "TransferTalepleri/TransferTalepleriComponent_294970_onClick", localVar)
        if (!KMainFunctions.IsResStatus2XX(result)) return true;

			stateVars.TM_GetTransferRequestsAll = result?.data.tM_GetTransferRequestsAll;
			
			formVars.transfertalepleri_155350_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetTransferRequestsAll !== undefined ? (stateVars.TM_GetTransferRequestsAll?.length > 0 ? stateVars.TM_GetTransferRequestsAll[0].paginationLabel : null) : (this.state.TM_GetTransferRequestsAll?.length > 0 ? this.state.TM_GetTransferRequestsAll[0].paginationLabel : null)));
			this.props.form?.setFieldsValue(formVars);
			
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.TransferTalepleriComponent_294970_onClick1_();
                  resolve();
                });
          })



        
        KuikaAppManager.hideSpinner(this);
        return isErrorOccurred;
    }
		TransferTalepleriComponent_294970_onClick1_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations, this.checkTabErrors))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }

				
				stateVars.dataSource_901194 = stateVars.TM_GetTransferRequestsAll ?? this.state.TM_GetTransferRequestsAll;
				formVars.transfertalepleri_155350_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetTransferRequestsAll !== undefined ? (stateVars.TM_GetTransferRequestsAll?.length > 0 ? stateVars.TM_GetTransferRequestsAll[0].paginationLabel : null) : (this.state.TM_GetTransferRequestsAll?.length > 0 ? this.state.TM_GetTransferRequestsAll[0].paginationLabel : null)));

				formVars.transfertalepleri_984416_total = ReactSystemFunctions.value(this, (stateVars.TM_GetTransferRequestsAll !== undefined ? (stateVars.TM_GetTransferRequestsAll?.length > 0 ? stateVars.TM_GetTransferRequestsAll[0].totalCount : null) : (this.state.TM_GetTransferRequestsAll?.length > 0 ? this.state.TM_GetTransferRequestsAll[0].totalCount : null)));


		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

            
            return isErrorOccurred;
        }




		TransferTalepleriComponent_663454_onClick = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations, this.checkTabErrors))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
KuikaAppManager.showSpinner(this);

				stateVars.SetValueOf = await ReactSystemFunctions.setValueOf(this, ReactSystemFunctions.convertToTypeByName("transfertalepleri_519462_value", "string"), "", null, false);
				stateVars.SetValueOf = await ReactSystemFunctions.setValueOf(this, ReactSystemFunctions.convertToTypeByName("transfertalepleri_755228_value", "string"), "", null, false);
				stateVars.SetValueOf = await ReactSystemFunctions.setValueOf(this, ReactSystemFunctions.convertToTypeByName("transfertalepleri_412000_value", "string"), "", null, "StoreCode");
				stateVars.SetValueOf = await ReactSystemFunctions.setValueOf(this, ReactSystemFunctions.convertToTypeByName("transfertalepleri_163767_value", "string"), "", null, "Code");
				stateVars.SetValueOf = await ReactSystemFunctions.setValueOf(this, ReactSystemFunctions.convertToTypeByName("transfertalepleri_549686_value", "string"), "", null, "Id");
				stateVars.SetValueOf = await ReactSystemFunctions.setValueOf(this, ReactSystemFunctions.convertToTypeByName("transfertalepleri_38408_value", "string"), "", null, "StoreCode");
				stateVars.SetValueOf = await ReactSystemFunctions.setValueOf(this, ReactSystemFunctions.convertToTypeByName("transfertalepleri_815155_value", "string"), "", null, false);
				stateVars.SetValueOf = await ReactSystemFunctions.setValueOf(this, ReactSystemFunctions.convertToTypeByName("transfertalepleri_374249_value", "string"), "", null, false);
				stateVars.SetValueOf = await ReactSystemFunctions.setValueOf(this, ReactSystemFunctions.convertToTypeByName("transfertalepleri_959115_value", "string"), "", null, false);

		this.props.form?.setFieldsValue(formVars);
		
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.TransferTalepleriComponent_663454_onClick1_();
                  resolve();
                });
          })

            
            return isErrorOccurred;
        }
    TransferTalepleriComponent_663454_onClick1_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations, this.checkTabErrors))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
		KuikaAppManager.increaseServerRequestCount();


        let localVar = {
				CurrentUsername_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.getMyUsername(), "string"),
				RequestNumber_0: ReactSystemFunctions.convertToTypeByName(null, "string"),
				StatusIds_0: ReactSystemFunctions.convertToTypeByName(null, "string"),
				RequestingStoreCodes_0: ReactSystemFunctions.convertToTypeByName(null, "string"),
				RequestedStoreCodes_0: ReactSystemFunctions.convertToTypeByName(null, "string"),
				RequestTypeCodes_0: ReactSystemFunctions.convertToTypeByName(null, "string"),
				ProductSearch_0: ReactSystemFunctions.convertToTypeByName(null, "string"),
				CreatedByIds_0: ReactSystemFunctions.convertToTypeByName(null, "string"),
				RequestDateFrom_0: ReactSystemFunctions.convertToTypeByName(null, "Date"),
				RequestDateTo_0: ReactSystemFunctions.convertToTypeByName(null, "Date"),
				DecisionDateFrom_0: ReactSystemFunctions.convertToTypeByName(null, "Date"),
				DecisionDateTo_0: ReactSystemFunctions.convertToTypeByName(null, "Date"),
				CurrentPage_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "transfertalepleri_984416_value", "current", "", "", "")), "number"),
				PageSize_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "transfertalepleri_984416_value", "pageSize", "", "", "")), "number")
        }

		
        if (true) {
        KuikaAppManager.showSpinner(this);
        }
        let result = await KuikaAppManager.ApiRequest(this, "TransferTalepleri/TransferTalepleriComponent_663454_onClick1_", localVar)
        if (!KMainFunctions.IsResStatus2XX(result)) return true;

			stateVars.TM_GetTransferRequestsAll = result?.data.tM_GetTransferRequestsAll;
			
			formVars.transfertalepleri_155350_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetTransferRequestsAll !== undefined ? (stateVars.TM_GetTransferRequestsAll?.length > 0 ? stateVars.TM_GetTransferRequestsAll[0].paginationLabel : null) : (this.state.TM_GetTransferRequestsAll?.length > 0 ? this.state.TM_GetTransferRequestsAll[0].paginationLabel : null)));
			this.props.form?.setFieldsValue(formVars);
			
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.TransferTalepleriComponent_663454_onClick2_();
                  resolve();
                });
          })



        
        KuikaAppManager.hideSpinner(this);
        return isErrorOccurred;
    }
		TransferTalepleriComponent_663454_onClick2_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations, this.checkTabErrors))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }

				
				stateVars.dataSource_901194 = stateVars.TM_GetTransferRequestsAll ?? this.state.TM_GetTransferRequestsAll;
				formVars.transfertalepleri_155350_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetTransferRequestsAll !== undefined ? (stateVars.TM_GetTransferRequestsAll?.length > 0 ? stateVars.TM_GetTransferRequestsAll[0].paginationLabel : null) : (this.state.TM_GetTransferRequestsAll?.length > 0 ? this.state.TM_GetTransferRequestsAll[0].paginationLabel : null)));

				formVars.transfertalepleri_984416_total = ReactSystemFunctions.value(this, (stateVars.TM_GetTransferRequestsAll !== undefined ? (stateVars.TM_GetTransferRequestsAll?.length > 0 ? stateVars.TM_GetTransferRequestsAll[0].totalCount : null) : (this.state.TM_GetTransferRequestsAll?.length > 0 ? this.state.TM_GetTransferRequestsAll[0].totalCount : null)));


		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

            
            return isErrorOccurred;
        }





		TransferTalepleriComponent_670182_onClick = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations, this.checkTabErrors))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
KuikaAppManager.showSpinner(this);

					KuikaAppManager.prepareForNavigation();
						KuikaAppManager.addToPageInputVariables("TransferTalepDetay", "TransferRequestHeaderId", ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, "transfertalepleri_901194_value", "requestHeaderId"), "Guid"));

				stateVars.NAVIGATE = await ReactSystemFunctions.navigate(this, undefined, "TransferTalepleri", "TransferTalepDetay", "", "7d969ddf-5801-4eb6-b92b-12be35bdd565", "307131", null, "right", "true", "50vw", "100vh", true, false);

		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

            
            return isErrorOccurred;
        }




    async callCallbackFunction(diId: number, isFromMaster: boolean = false) {
        let isErrorOccurred = false;
		let pageInitCallerNavDiIDs = [321039, 192218, 937423, 307131] as number[];
		if (isFromMaster || pageInitCallerNavDiIDs.indexOf(diId) > -1) {
			await this.TransferTalepleriPageInit();
		}

    }


}
