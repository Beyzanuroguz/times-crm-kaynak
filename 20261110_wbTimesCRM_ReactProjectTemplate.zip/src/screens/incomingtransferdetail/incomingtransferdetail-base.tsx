import React from "react";
import Axios, { AxiosResponse } from "axios";
import { KuikaAppManager } from "../../shared/utilty/kuika-app-manager";
import { ReactSystemFunctions } from "../../shared/utilty/react-system-functions";
import { KNavigator } from "../../shared/hoc/with-history";
import { KContext } from "../../shared/hoc/with-context";
import { useLocation } from "react-router-dom";
import { FormInstance } from "antd/es/form";
import { Guid } from "guid-typescript";
import Swal from "sweetalert2";
import { KMainFunctions } from "../../shared/utilty/main-functions";
import moment from "moment";
import { IValidationData } from "../../models/dto/validation-data";
import { IStripePayment } from "../../models/dto/stripe-payment";
import { IUserInfoDto } from "../../models/dto/user-info.dto";
import { UserService } from "../../services/user-service";
import { kuikaCoreWasmBridgeService } from "../../services/_singletons";
import _ from "lodash";
import mqtt, { MqttClient } from "mqtt";
import { IMqttResult } from "../../models/dto/mqtt.dto";
import { MasterScreen_ScreenContext } from "../masterscreen/masterscreen-context";

declare let window: any;

export interface IInComingTransferDetail_ScreenProps {
  navigator: KNavigator;
  form: FormInstance<any>;
  googleLogin: any;
  screenInputs: any;
  context: KContext;
  initialValues: any;
  children: any;
}

export interface IInComingTransferDetail_ScreenState {
    isSpinnerVisible: boolean;
    isPageVisible: boolean;
	isLeftMenuVisible: boolean;
    spinnerCount: number;
    selectedLanguage: string;
    isPageInitLoaded: false;
    isPageRecurringLoaded: false;
	TM_GetTransferHeader: any[];
	TM_GetTransferHeader_dummy: any[];
	TM_GetTransferItems: any[];
	TM_GetTransferItems_dummy: any[];
	GoBack: any;
	GoBack_dummy: any;
	isComp961948Visible: 'visible' | 'hidden';
	isComp89704Visible: 'visible' | 'hidden';
	isComp366963Visible: 'visible' | 'hidden';
	isComp958680Visible: 'visible' | 'hidden';
	isComp460188Visible: 'visible' | 'hidden';

}

export class InComingTransferDetail_ScreenBase extends React.PureComponent<IInComingTransferDetail_ScreenProps, any> {
    static contextType = MasterScreen_ScreenContext;
    declare context: React.ContextType<typeof MasterScreen_ScreenContext>;
	incomingtransferdetail_972656_value_kuikaTableRef: React.RefObject<any>;
    ml=[{"Id":"d5a61d2b-bd60-485f-86e2-661e9ed4e486","Name":"en_US","ShortName":"English","IsDefault":true,"LanguagePhrases":[]},{"Id":"98fc985a-057a-40fe-841a-512b01cac5b2","Name":"FixedValues","ShortName":"FixedValues","LanguagePhrases":[{"Id":921142,"PropertyName":"value","Value":"Transfer Detay"},{"Id":331363,"PropertyName":"value","Value":"Transfer Numarası"},{"Id":935196,"PropertyName":"value","Value":"Transfer Eden Mağaza"},{"Id":693803,"PropertyName":"value","Value":"Transfer Eden Kişi"},{"Id":859864,"PropertyName":"value","Value":"Transfer Tarihi"},{"Id":190562,"PropertyName":"value","Value":"Transfer Edilen Ürünler"},{"Id":153333,"PropertyName":"title","Value":"Kabul Edilen Seri Numarası"},{"Id":583246,"PropertyName":"value","Value":"[datafield:acceptedserialnumber]"},{"Id":135839,"PropertyName":"title","Value":"Marka"},{"Id":109359,"PropertyName":"value","Value":"[datafield:brand]"},{"Id":375532,"PropertyName":"title","Value":"Referans"},{"Id":811079,"PropertyName":"value","Value":"[datafield:referance]"},{"Id":31193,"PropertyName":"title","Value":"Kadran"},{"Id":547168,"PropertyName":"value","Value":"[datafield:dial]"},{"Id":403152,"PropertyName":"title","Value":"Bilezik"},{"Id":245048,"PropertyName":"value","Value":"[datafield:bracelet]"},{"Id":703353,"PropertyName":"title","Value":"Durum"},{"Id":961948,"PropertyName":"value","Value":"[datafield:statusname]"},{"Id":89704,"PropertyName":"value","Value":"[datafield:statusname]"},{"Id":366963,"PropertyName":"value","Value":"[datafield:statusname]"},{"Id":958680,"PropertyName":"value","Value":"[datafield:statusname]"},{"Id":902142,"PropertyName":"title","Value":"Transferi Onaylayan Kişi"},{"Id":88763,"PropertyName":"value","Value":"[datafield:receivedbyname]"},{"Id":72490,"PropertyName":"title","Value":"Transfer Onay Tarihi"},{"Id":579862,"PropertyName":"value","Value":"[datafield:receivedat]"},{"Id":460188,"PropertyName":"label","Value":"Ürünü Kabul Et"}]}]
    defaultML = "en_US"
    
    screenHash = ""
    

    private _prevMasterPageInitLoaded: boolean = false;
    private _prevMasterPageRecurringLoaded: boolean = false;
    private _prevShouldTriggerPageInit: boolean = false;
    constructor(props) {
        super(props);
		this.incomingtransferdetail_972656_value_kuikaTableRef = React.createRef();

        this.state = {
            isSpinnerVisible: false,
            isPageVisible: false,
            isLeftMenuVisible: false,
            spinnerCount: 0,
            selectedLanguage: "",
            isPageInitLoaded: false,
            isPageRecurringLoaded: false,
            	        TM_GetTransferHeader: [],
	        TM_GetTransferItems: [],
	        GoBack: "",
	        isComp961948Visible: 'hidden',
	        isComp89704Visible: 'hidden',
	        isComp366963Visible: 'hidden',
	        isComp958680Visible: 'hidden',
	        isComp460188Visible: 'hidden',

        }

        this.state.isPageVisible = true;
        
    }

    async componentDidMount() {

        if (KuikaAppManager.isPageInitPrevented()) {
            KuikaAppManager.calculateAndSetBodyHeight("incomingtransferdetail", "masterscreen_screen");
            return;
        }
        this.context.registerCallbackFunction(this.callCallbackFunction.bind(this));
        
        ReactSystemFunctions.validateToken()
        this.fillFormInitValues();
        if (false){
            await this.InComingTransferDetailPageInit();
        } else if (this.context?.isMasterPageInitLoaded) { this._prevMasterPageInitLoaded = true; await this.InComingTransferDetailPageInit(); }
        
        
        
        KuikaAppManager.calculateAndSetBodyHeight("incomingtransferdetail", "masterscreen_screen");

        if (ReactSystemFunctions.getIsMicroApp() === false) {
           window.parentScreen = this;
        }
    }

    componentWillUnmount() {
        
        
        

        if (ReactSystemFunctions.getIsMicroApp() === false) {
           window.parentScreen = null;
        }
    }

    

        
    componentDidUpdate= async (prevProps, prevState) => {
		KuikaAppManager.calculateAndSetBodyHeight("incomingtransferdetail", "masterscreen_screen"    );
        if (prevProps?.location?.search !== (this.props as any)?.location?.search) {
			await this.InComingTransferDetailPageInit();
		}

        		if (this._prevMasterPageInitLoaded !== this.context.isMasterPageInitLoaded && this.context.isMasterPageInitLoaded === true) {this._prevMasterPageInitLoaded = this.context.isMasterPageInitLoaded;await this.InComingTransferDetailPageInit()}


        if (ReactSystemFunctions.getIsMicroApp() === false) {
            for (const key in prevState) {
                if (key.startsWith('NavVisible') && prevState[key] === true && this.state[key] === false) {
                    window.parentScreen = this;
                    break;
                }
            }
        }
	}

    fillFormInitValues() {
        this.props.form?.setFieldsValue({
});

    }

      setPageInitLoaded = (value: boolean) => {
        this.setState({ isPageInitLoaded: value });
      }

      setPageRecurringLoaded = (value: boolean) => {
        this.setState({ isPageRecurringLoaded: value });
      }

      clearFieldValidation = (changedValues: any) => {
        const fieldName = Object.keys(changedValues)[0];
        if (fieldName) {
          this.props.form?.setFields([
            {
              name: fieldName,
              errors: []
            }
          ]);
        }
      };

      

    InComingTransferDetailPageInit = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


	if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }

        let localVar = {
			TransferCode_0: ReactSystemFunctions.convertToTypeByName(this.props.screenInputs.TransferCode ?? this.props.screenInputs.transfercode, "string"),
			TransferCode_1: ReactSystemFunctions.convertToTypeByName(this.props.screenInputs.TransferCode ?? this.props.screenInputs.transfercode, "string")
        }

	KuikaAppManager.showSpinner(this);
	
        if (true) {
        KuikaAppManager.showSpinner(this);
        }
        let result = await KuikaAppManager.ApiRequest(this, "InComingTransferDetail/InComingTransferDetailPageInit", localVar)
        if (!KMainFunctions.IsResStatus2XX(result)) return true;

		stateVars.TM_GetTransferHeader = result?.data.tM_GetTransferHeader;
		formVars.incomingtransferdetail_864655_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetTransferHeader !== undefined ? (stateVars.TM_GetTransferHeader?.length > 0 ? stateVars.TM_GetTransferHeader[0].fromStoreName : null) : (this.state.TM_GetTransferHeader?.length > 0 ? this.state.TM_GetTransferHeader[0].fromStoreName : null)));
		formVars.incomingtransferdetail_333272_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetTransferHeader !== undefined ? (stateVars.TM_GetTransferHeader?.length > 0 ? stateVars.TM_GetTransferHeader[0].shippedByName : null) : (this.state.TM_GetTransferHeader?.length > 0 ? this.state.TM_GetTransferHeader[0].shippedByName : null)));
		formVars.incomingtransferdetail_531266_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetTransferHeader !== undefined ? (stateVars.TM_GetTransferHeader?.length > 0 ? stateVars.TM_GetTransferHeader[0].shippedAt : null) : (this.state.TM_GetTransferHeader?.length > 0 ? this.state.TM_GetTransferHeader[0].shippedAt : null)));
		stateVars.TM_GetTransferItems = result?.data.tM_GetTransferItems;
		
		this.props.form?.setFieldsValue(formVars);
		
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.InComingTransferDetailPageInit1_();
                  resolve();
                });
          })



        
        KuikaAppManager.hideSpinner(this);
        return isErrorOccurred;
    }
	InComingTransferDetailPageInit1_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


	if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }

			formVars.incomingtransferdetail_864655_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetTransferHeader !== undefined ? (stateVars.TM_GetTransferHeader?.length > 0 ? stateVars.TM_GetTransferHeader[0].fromStoreName : null) : (this.state.TM_GetTransferHeader?.length > 0 ? this.state.TM_GetTransferHeader[0].fromStoreName : null)));

			formVars.incomingtransferdetail_333272_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetTransferHeader !== undefined ? (stateVars.TM_GetTransferHeader?.length > 0 ? stateVars.TM_GetTransferHeader[0].shippedByName : null) : (this.state.TM_GetTransferHeader?.length > 0 ? this.state.TM_GetTransferHeader[0].shippedByName : null)));

			formVars.incomingtransferdetail_531266_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetTransferHeader !== undefined ? (stateVars.TM_GetTransferHeader?.length > 0 ? stateVars.TM_GetTransferHeader[0].shippedAt : null) : (this.state.TM_GetTransferHeader?.length > 0 ? this.state.TM_GetTransferHeader[0].shippedAt : null)));

			
			stateVars.dataSource_972656 = stateVars.TM_GetTransferItems ?? this.state.TM_GetTransferItems;
			stateVars.isComp961948Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, "incomingtransferdetail_972656_value", "statusCode"), ReactSystemFunctions.convertToTypeByName("COMPLETED", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp89704Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, "incomingtransferdetail_972656_value", "statusCode"), ReactSystemFunctions.convertToTypeByName("RECEIVED", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp366963Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, "incomingtransferdetail_972656_value", "statusCode"), ReactSystemFunctions.convertToTypeByName("REJECTED", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp958680Visible = (((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, "incomingtransferdetail_972656_value", "statusCode"), ReactSystemFunctions.convertToTypeByName("PENDING", "string")) || ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, "incomingtransferdetail_972656_value", "statusCode"), ReactSystemFunctions.convertToTypeByName("APPROVED", "string")))) === true ? "visible" : "hidden")
			stateVars.isComp460188Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, "incomingtransferdetail_972656_value", "acceptedSerialNumber"), ReactSystemFunctions.convertToTypeByName("-", "string"))) === true ? "visible" : "hidden")

	this.props.form?.setFieldsValue(formVars);
	this.setState(stateVars);
	KuikaAppManager.hideSpinner(this);

            this.setPageInitLoaded(true);
            return isErrorOccurred;
        }




		InComingTransferDetailComponent_568392_onClick = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
KuikaAppManager.showSpinner(this);

				stateVars.GoBack = await ReactSystemFunctions.goBack(this, false);

		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

            
            return isErrorOccurred;
        }




    async callCallbackFunction(diId: number, isFromMaster: boolean = false) {
        let isErrorOccurred = false;
		let pageInitCallerNavDiIDs = [] as number[];
		if (isFromMaster || pageInitCallerNavDiIDs.indexOf(diId) > -1) {
			await this.InComingTransferDetailPageInit();
		}

    }


}
