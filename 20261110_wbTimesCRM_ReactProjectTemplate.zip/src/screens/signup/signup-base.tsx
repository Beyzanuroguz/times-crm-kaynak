import React from "react";
import Axios, { AxiosResponse } from "axios";
import { KuikaAppManager } from "../../shared/utilty/kuika-app-manager";
import { ReactSystemFunctions } from "../../shared/utilty/react-system-functions";
import { KNavigator } from "../../shared/hoc/with-history";
import { KContext } from "../../shared/hoc/with-context";
import { useLocation } from "react-router-dom";
import { FormInstance } from "antd/es/form";
import { Guid } from "guid-typescript";
import Swal from "sweetalert2";
import { KMainFunctions } from "../../shared/utilty/main-functions";
import moment from "moment";
import { IValidationData } from "../../models/dto/validation-data";
import { IStripePayment } from "../../models/dto/stripe-payment";
import { IUserInfoDto } from "../../models/dto/user-info.dto";
import { UserService } from "../../services/user-service";
import { kuikaCoreWasmBridgeService } from "../../services/_singletons";
import _ from "lodash";
import mqtt, { MqttClient } from "mqtt";
import { IMqttResult } from "../../models/dto/mqtt.dto";


declare let window: any;

export interface ISignup_ScreenProps {
  navigator: KNavigator;
  form: FormInstance<any>;
  googleLogin: any;
  screenInputs: any;
  context: KContext;
  initialValues: any;
  children: any;
}

export interface ISignup_ScreenState {
    isSpinnerVisible: boolean;
    isPageVisible: boolean;
	isLeftMenuVisible: boolean;
    spinnerCount: number;
    selectedLanguage: string;
    isPageInitLoaded: false;
    isPageRecurringLoaded: false;
	Signup: any;
	Signup_dummy: any;
	goToNextScreenAfterSignup: any;
	goToNextScreenAfterSignup_dummy: any;
	NAVIGATE: any;
	NAVIGATE_dummy: any;

}

export class Signup_ScreenBase extends React.PureComponent<ISignup_ScreenProps, any> {


    ml=[{"Id":"d5a61d2b-bd60-485f-86e2-661e9ed4e486","Name":"en_US","ShortName":"English","IsDefault":true,"LanguagePhrases":[]},{"Id":"b63ead02-9baf-4af2-849b-500eaff48071","Name":"FixedValues","ShortName":"FixedValues","LanguagePhrases":[{"Id":717912,"PropertyName":"value","Value":"Create an account"},{"Id":997730,"PropertyName":"value","Value":"Fill in the details to create your new account."},{"Id":388216,"PropertyName":"placeholder","Value":"First Name"},{"Id":973972,"PropertyName":"placeholder","Value":"Last Name"},{"Id":298012,"PropertyName":"placeholder","Value":"Enter your email address"},{"Id":717714,"PropertyName":"placeholder","Value":"Create a password"},{"Id":807378,"PropertyName":"value","Value":"By signing up, you agree to our"},{"Id":513929,"PropertyName":"value","Value":"Terms of Service"},{"Id":782186,"PropertyName":"value","Value":"and"},{"Id":486824,"PropertyName":"value","Value":"Privacy Policy."},{"Id":387716,"PropertyName":"label","Value":"Create Account"},{"Id":593542,"PropertyName":"value","Value":"Already a member ?"},{"Id":687615,"PropertyName":"value","Value":"Sign in"}]}]
    defaultML = "en_US"
    
    screenHash = ""
    


    constructor(props) {
        super(props);
		this.signup_388216_value_kuikaTextInputRef = React.createRef();
		this.signup_973972_value_kuikaTextInputRef = React.createRef();

        this.state = {
            isSpinnerVisible: false,
            isPageVisible: false,
            isLeftMenuVisible: false,
            spinnerCount: 0,
            selectedLanguage: "",
            isPageInitLoaded: false,
            isPageRecurringLoaded: false,
            	        Signup: "",
	        goToNextScreenAfterSignup: "",
	        NAVIGATE: "",

        }

        this.state.isPageVisible = true;
        
    }

    async componentDidMount() {

        if (KuikaAppManager.isPageInitPrevented()) {
            KuikaAppManager.calculateAndSetBodyHeight("signup", "");
            return;
        }
        
        
        
        this.fillFormInitValues();
        if (true){
            
        }
        
        window.addEventListener("keydown", this.onKeyDown)
        
        KuikaAppManager.calculateAndSetBodyHeight("signup", "");

        if (ReactSystemFunctions.getIsMicroApp() === false) {
           window.parentScreen = this;
        }
    }

    componentWillUnmount() {
        window.removeEventListener("keydown", this.onKeyDown)
        
        

        if (ReactSystemFunctions.getIsMicroApp() === false) {
           window.parentScreen = null;
        }
    }

    

        

  onKeyDown = (e: any) => {
    if (e.keyCode === undefined) return;
    if (e.repeat) return;

    const keyCode = e.keyCode;
    if(keyCode === 13) {
      e.stopPropagation();
      var element = document.getElementById("387716");
      if (element && element.click)
      {
                element.click();
      }
    }
    
  }

    componentDidUpdate= async (prevProps, prevState) => {
		KuikaAppManager.calculateAndSetBodyHeight("signup", ""    );
        if (prevProps?.location?.search !== (this.props as any)?.location?.search) {
			
		}

        

        if (ReactSystemFunctions.getIsMicroApp() === false) {
            for (const key in prevState) {
                if (key.startsWith('NavVisible') && prevState[key] === true && this.state[key] === false) {
                    window.parentScreen = this;
                    break;
                }
            }
        }
	}

    fillFormInitValues() {
        this.props.form?.setFieldsValue({
});

    }

      setPageInitLoaded = (value: boolean) => {
        this.setState({ isPageInitLoaded: value });
      }

      setPageRecurringLoaded = (value: boolean) => {
        this.setState({ isPageRecurringLoaded: value });
      }

      clearFieldValidation = (changedValues: any) => {
        const fieldName = Object.keys(changedValues)[0];
        if (fieldName) {
          this.props.form?.setFields([
            {
              name: fieldName,
              errors: []
            }
          ]);
        }
      };

      


		SignupComponent_387716_onClick = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;

		validations.push({ 
			isValid: ReactSystemFunctions.isNotEmpty(ReactSystemFunctions.value(this, "signup_298012_value", "value", "", "", ""), null),
			message: "This field is required",
			formName: "signup_298012_value",
			condition: true
		} as IValidationData);

validations.forEach((validation) => {
            if (validation.message === "Geçerli bir mail adresi giriniz.") {
                validation.message = ReactSystemFunctions.getEmailValidationMessage()
            }
        })
		validations.push({ 
			isValid: ReactSystemFunctions.isValidEmail(ReactSystemFunctions.value(this, "signup_298012_value", "value", "", "", ""), null),
			message: "Geçerli bir mail adresi giriniz.",
			formName: "signup_298012_value",
			condition: true
		} as IValidationData);

validations.forEach((validation) => {
            if (validation.message === "Geçerli bir mail adresi giriniz.") {
                validation.message = ReactSystemFunctions.getEmailValidationMessage()
            }
        })
		validations.push({ 
			isValid: ReactSystemFunctions.isNotEmpty(ReactSystemFunctions.value(this, "signup_717714_value", "value", "", "", ""), null),
			message: "This field is required",
			formName: "signup_717714_value",
			condition: true
		} as IValidationData);

validations.forEach((validation) => {
            if (validation.message === "Geçerli bir mail adresi giriniz.") {
                validation.message = ReactSystemFunctions.getEmailValidationMessage()
            }
        })
		validations.push({ 
			isValid: ReactSystemFunctions.isNotEmpty(ReactSystemFunctions.value(this, "signup_388216_value", "value", "", "", ""), null),
			message: "This field is required",
			formName: "signup_388216_value",
			condition: true
		} as IValidationData);

validations.forEach((validation) => {
            if (validation.message === "Geçerli bir mail adresi giriniz.") {
                validation.message = ReactSystemFunctions.getEmailValidationMessage()
            }
        })

		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
KuikaAppManager.showSpinner(this);
		KuikaAppManager.increaseServerRequestCount();

				stateVars.Signup = (await ReactSystemFunctions.signup(this, ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "signup_298012_value", "value", "", "", "")), ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "signup_717714_value", "value", "", "", "")), ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "signup_388216_value", "value", "", "", "")), ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "signup_973972_value", "value", "", "", "")), true, undefined, null, null) as any).data;
				stateVars.tmpBoolResult = await ReactSystemFunctions.goToNextScreenAfterSignup(this);

		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

            
            return isErrorOccurred;
        }


		SignupComponent_687615_onClick = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
KuikaAppManager.showSpinner(this);

					KuikaAppManager.prepareForNavigation();

				stateVars.NAVIGATE = await ReactSystemFunctions.navigate(this, undefined, "Signup", "Signin", "", "currentPage", null, null, null, null, null, null, true, false);

		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

            
            return isErrorOccurred;
        }




    async callCallbackFunction(diId: number, isFromMaster: boolean = false) {
        let isErrorOccurred = false;

    }


}
