import React from "react";
import Axios, { AxiosResponse } from "axios";
import { KuikaAppManager } from "../../shared/utilty/kuika-app-manager";
import { ReactSystemFunctions } from "../../shared/utilty/react-system-functions";
import { KNavigator } from "../../shared/hoc/with-history";
import { KContext } from "../../shared/hoc/with-context";
import { useLocation } from "react-router-dom";
import { FormInstance } from "antd/es/form";
import { Guid } from "guid-typescript";
import Swal from "sweetalert2";
import { KMainFunctions } from "../../shared/utilty/main-functions";
import moment from "moment";
import { IValidationData } from "../../models/dto/validation-data";
import { IStripePayment } from "../../models/dto/stripe-payment";
import { IUserInfoDto } from "../../models/dto/user-info.dto";
import { UserService } from "../../services/user-service";
import { kuikaCoreWasmBridgeService } from "../../services/_singletons";
import _ from "lodash";
import mqtt, { MqttClient } from "mqtt";
import { IMqttResult } from "../../models/dto/mqtt.dto";


declare let window: any;

export interface IReservationPopUp3_ScreenProps {
  navigator: KNavigator;
  form: FormInstance<any>;
  googleLogin: any;
  screenInputs: any;
  context: KContext;
  initialValues: any;
  children: any;
}

export interface IReservationPopUp3_ScreenState {
    isSpinnerVisible: boolean;
    isPageVisible: boolean;
	isLeftMenuVisible: boolean;
    spinnerCount: number;
    selectedLanguage: string;
    isPageInitLoaded: false;
    isPageRecurringLoaded: false;
	TM_GetLeadById: any[];
	TM_GetLeadById_dummy: any[];
	TM_GetReservationByLeadId: any[];
	TM_GetReservationByLeadId_dummy: any[];
	TMLeadSuggestion: any[];
	TMLeadSuggestion_dummy: any[];
	TMGetProductDetailStockByLeadId: any[];
	TMGetProductDetailStockByLeadId_dummy: any[];
	GoBack: any;
	GoBack_dummy: any;
	TMApproveLeadAndReservationCreate: any[];
	TMApproveLeadAndReservationCreate_dummy: any[];
	Notify: boolean;
	Notify_dummy: boolean;
	isComp114164Visible: 'visible' | 'hidden';
	isComp550602Visible: 'visible' | 'hidden';
	isComp41164Visible: 'visible' | 'hidden';

}

export class ReservationPopUp3_ScreenBase extends React.PureComponent<IReservationPopUp3_ScreenProps, any> {

	reservationpopup3_432168_value_kuikaAutoCompleteRef: React.RefObject<any>;
	reservationpopup3_185461_value_kuikaAutoCompleteRef: React.RefObject<any>;
    ml=[{"Id":"d5a61d2b-bd60-485f-86e2-661e9ed4e486","Name":"en_US","ShortName":"English","IsDefault":true,"LanguagePhrases":[]},{"Id":"a9b5d304-dc98-41ac-abed-60c272b15945","Name":"FixedValues","ShortName":"FixedValues","LanguagePhrases":[{"Id":80315,"PropertyName":"value","Value":"Ürün Rezervasyonu"},{"Id":35800,"PropertyName":"value","Value":"Ürün, stok ve teslimat bilgilerini kontrol ederek rezervasyon planını tamamlayın."},{"Id":88675,"PropertyName":"value","Value":"Ürün Bilgileri"},{"Id":628448,"PropertyName":"value","Value":"Ürün"},{"Id":806905,"PropertyName":"value","Value":"Mağaza"},{"Id":341682,"PropertyName":"value","Value":"Kategori"},{"Id":780360,"PropertyName":"value","Value":"Stok durumu"},{"Id":114164,"PropertyName":"value","Value":"Stokta mevcut"},{"Id":550602,"PropertyName":"value","Value":"Stokta mevcut değil"},{"Id":368549,"PropertyName":"value","Value":"Toplam Stok"},{"Id":328743,"PropertyName":"value","Value":"Rezerve Stok"},{"Id":958452,"PropertyName":"value","Value":"Müsait Stok"},{"Id":557141,"PropertyName":"value","Value":"Talep Bilgileri"},{"Id":804122,"PropertyName":"value","Value":"Müşteri"},{"Id":976195,"PropertyName":"value","Value":"Talep tarihi"},{"Id":94374,"PropertyName":"value","Value":"Talep No"},{"Id":637889,"PropertyName":"value","Value":"Tahmini Teslimat Tarihi"},{"Id":913122,"PropertyName":"value","Value":"Satış Personeli"},{"Id":948030,"PropertyName":"value","Value":"Termin planı"},{"Id":69477,"PropertyName":"value","Value":"Termin yılı"},{"Id":432168,"PropertyName":"placeholder","Value":"Yıl seçin"},{"Id":258449,"PropertyName":"value","Value":"Termin ayı"},{"Id":185461,"PropertyName":"placeholder","Value":"Ay seçin"},{"Id":644832,"PropertyName":"value","Value":"Önerilen termin"},{"Id":973230,"PropertyName":"value","Value":"Rezervasyon notu"},{"Id":763837,"PropertyName":"placeholder","Value":"Rezervasyonla ilgili özel bir not ekleyin"},{"Id":517521,"PropertyName":"label","Value":"Onayla ve Rezerve Et"},{"Id":722027,"PropertyName":"label","Value":"Vazgeç"}]}]
    defaultML = "en_US"
    
    screenHash = ""
    


    constructor(props) {
        super(props);
		this.reservationpopup3_432168_value_kuikaAutoCompleteRef = React.createRef();
		this.reservationpopup3_185461_value_kuikaAutoCompleteRef = React.createRef();

        this.state = {
            isSpinnerVisible: false,
            isPageVisible: false,
            isLeftMenuVisible: false,
            spinnerCount: 0,
            selectedLanguage: "",
            isPageInitLoaded: false,
            isPageRecurringLoaded: false,
            	        TM_GetLeadById: [],
	        TM_GetReservationByLeadId: [],
	        TMLeadSuggestion: [],
	        TMGetProductDetailStockByLeadId: [],
	        GoBack: "",
	        TMApproveLeadAndReservationCreate: [],
	        Notify: false,
	        dataSource_432168: [{"key":"2026","text":"2026"},{"key":"2027","text":"2027"},{"key":"2028","text":"2028"},{"key":"2029","text":"2029"},{"key":"2030","text":"2030"},{"key":"2031","text":"2031"},{"key":"2032","text":"2032"},{"key":"2033","text":"2033"},{"key":"2034","text":"2034"},{"key":"2035","text":"2035"},{"key":"2036","text":"2036"},{"key":"2037","text":"2037"},{"key":"2038","text":"2038"},{"key":"2039","text":"2039"},{"key":"2040","text":"2040"}],
	        dataSource_185461: [{"key":"1","text":"Ocak"},{"key":"2","text":"Şubat"},{"key":"3","text":"Mart"},{"key":"4","text":"Nisan"},{"key":"5","text":"Mayıs"},{"key":"6","text":"Haziran"},{"key":"7","text":"Temmuz"},{"key":"8","text":"Ağustos"},{"key":"9","text":"Eylül"},{"key":"10","text":"Ekim"},{"key":"11","text":"Kasım"},{"key":"12","text":"Aralık"}],
	        isComp114164Visible: 'hidden',
	        isComp550602Visible: 'hidden',
	        isComp41164Visible: 'hidden',

        }

        this.state.isPageVisible = true;
        
    }

    async componentDidMount() {

        if (KuikaAppManager.isPageInitPrevented()) {
            KuikaAppManager.calculateAndSetBodyHeight("reservationpopup3", "");
            return;
        }
        
        
        ReactSystemFunctions.validateToken()
        this.fillFormInitValues();
        if (true){
            await this.reservationPopUp3PageInit();
        }
        
        
        
        KuikaAppManager.calculateAndSetBodyHeight("reservationpopup3", "");

        if (ReactSystemFunctions.getIsMicroApp() === false) {
           window.parentScreen = this;
        }
    }

    componentWillUnmount() {
        
        
        

        if (ReactSystemFunctions.getIsMicroApp() === false) {
           window.parentScreen = null;
        }
    }

    

        
    componentDidUpdate= async (prevProps, prevState) => {
		KuikaAppManager.calculateAndSetBodyHeight("reservationpopup3", ""    );
        if (prevProps?.location?.search !== (this.props as any)?.location?.search) {
			await this.reservationPopUp3PageInit();
		}

        

        if (ReactSystemFunctions.getIsMicroApp() === false) {
            for (const key in prevState) {
                if (key.startsWith('NavVisible') && prevState[key] === true && this.state[key] === false) {
                    window.parentScreen = this;
                    break;
                }
            }
        }
	}

    fillFormInitValues() {
        this.props.form?.setFieldsValue({
reservationpopup3_432168_value: this.state.TMLeadSuggestion?.at?.(0)?.terminYil ?? undefined,
reservationpopup3_185461_value: this.state.TMLeadSuggestion?.at?.(0)?.terminAy ?? undefined
});

    }

      setPageInitLoaded = (value: boolean) => {
        this.setState({ isPageInitLoaded: value });
      }

      setPageRecurringLoaded = (value: boolean) => {
        this.setState({ isPageRecurringLoaded: value });
      }

      clearFieldValidation = (changedValues: any) => {
        const fieldName = Object.keys(changedValues)[0];
        if (fieldName) {
          this.props.form?.setFields([
            {
              name: fieldName,
              errors: []
            }
          ]);
        }
      };

      

    reservationPopUp3PageInit = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


	if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }

        let localVar = {
			LeadId_0: ReactSystemFunctions.convertToTypeByName(this.props.screenInputs.LeadId ?? this.props.screenInputs.leadid, "Guid"),
			LeadId_1: ReactSystemFunctions.convertToTypeByName(this.props.screenInputs.LeadId ?? this.props.screenInputs.leadid, "Guid"),
			LeadId_2: ReactSystemFunctions.convertToTypeByName(this.props.screenInputs.LeadId ?? this.props.screenInputs.leadid, "Guid"),
			LeadId_3: ReactSystemFunctions.convertToTypeByName(this.props.screenInputs.LeadId ?? this.props.screenInputs.leadid, "Guid")
        }

	KuikaAppManager.showSpinner(this);
	
        if (true) {
        KuikaAppManager.showSpinner(this);
        }
        let result = await KuikaAppManager.ApiRequest(this, "reservationPopUp3/reservationPopUp3PageInit", localVar)
        if (!KMainFunctions.IsResStatus2XX(result)) return true;

		stateVars.TM_GetLeadById = result?.data.tM_GetLeadById;
		formVars.reservationpopup3_738912_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadById !== undefined ? (stateVars.TM_GetLeadById?.length > 0 ? stateVars.TM_GetLeadById[0].urunAdi : null) : (this.state.TM_GetLeadById?.length > 0 ? this.state.TM_GetLeadById[0].urunAdi : null)));
		formVars.reservationpopup3_148239_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadById !== undefined ? (stateVars.TM_GetLeadById?.length > 0 ? stateVars.TM_GetLeadById[0].magaza : null) : (this.state.TM_GetLeadById?.length > 0 ? this.state.TM_GetLeadById[0].magaza : null)));
		formVars.reservationpopup3_1158_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadById !== undefined ? (stateVars.TM_GetLeadById?.length > 0 ? stateVars.TM_GetLeadById[0].categoryName : null) : (this.state.TM_GetLeadById?.length > 0 ? this.state.TM_GetLeadById[0].categoryName : null)));
		formVars.reservationpopup3_479797_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadById !== undefined ? (stateVars.TM_GetLeadById?.length > 0 ? stateVars.TM_GetLeadById[0].musteriAdi : null) : (this.state.TM_GetLeadById?.length > 0 ? this.state.TM_GetLeadById[0].musteriAdi : null)));
		formVars.reservationpopup3_270773_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadById !== undefined ? (stateVars.TM_GetLeadById?.length > 0 ? stateVars.TM_GetLeadById[0].talepOlusturmaTarihi : null) : (this.state.TM_GetLeadById?.length > 0 ? this.state.TM_GetLeadById[0].talepOlusturmaTarihi : null)));
		formVars.reservationpopup3_53417_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadById !== undefined ? (stateVars.TM_GetLeadById?.length > 0 ? stateVars.TM_GetLeadById[0].leadCode : null) : (this.state.TM_GetLeadById?.length > 0 ? this.state.TM_GetLeadById[0].leadCode : null)));
		formVars.reservationpopup3_983813_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadById !== undefined ? (stateVars.TM_GetLeadById?.length > 0 ? stateVars.TM_GetLeadById[0].terminTarihi : null) : (this.state.TM_GetLeadById?.length > 0 ? this.state.TM_GetLeadById[0].terminTarihi : null)));
		formVars.reservationpopup3_908246_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadById !== undefined ? (stateVars.TM_GetLeadById?.length > 0 ? stateVars.TM_GetLeadById[0].satisPersoneli : null) : (this.state.TM_GetLeadById?.length > 0 ? this.state.TM_GetLeadById[0].satisPersoneli : null)));
		stateVars.TM_GetReservationByLeadId = result?.data.tM_GetReservationByLeadId;
		stateVars.TMLeadSuggestion = result?.data.tmLeadSuggestion;
		formVars.reservationpopup3_432168_value = (stateVars.TMLeadSuggestion !== undefined ? (stateVars.TMLeadSuggestion?.length > 0 ? stateVars.TMLeadSuggestion[0].terminYil : null) : (this.state.TMLeadSuggestion?.length > 0 ? this.state.TMLeadSuggestion[0].terminYil : null));
		formVars.reservationpopup3_185461_value = (stateVars.TMLeadSuggestion !== undefined ? (stateVars.TMLeadSuggestion?.length > 0 ? stateVars.TMLeadSuggestion[0].terminAy : null) : (this.state.TMLeadSuggestion?.length > 0 ? this.state.TMLeadSuggestion[0].terminAy : null));
		formVars.reservationpopup3_890290_value = ReactSystemFunctions.toString(this, (stateVars.TMLeadSuggestion !== undefined ? (stateVars.TMLeadSuggestion?.length > 0 ? stateVars.TMLeadSuggestion[0].terminOneriText : null) : (this.state.TMLeadSuggestion?.length > 0 ? this.state.TMLeadSuggestion[0].terminOneriText : null)));
		formVars.reservationpopup3_690531_value = ReactSystemFunctions.toString(this, (stateVars.TMLeadSuggestion !== undefined ? (stateVars.TMLeadSuggestion?.length > 0 ? stateVars.TMLeadSuggestion[0].terminOneriAciklama : null) : (this.state.TMLeadSuggestion?.length > 0 ? this.state.TMLeadSuggestion[0].terminOneriAciklama : null)));
		stateVars.isComp41164Visible = ((ReactSystemFunctions.isNotEmpty(ReactSystemFunctions.toString(this, (stateVars.TMLeadSuggestion !== undefined ? (stateVars.TMLeadSuggestion?.length > 0 ? stateVars.TMLeadSuggestion[0].terminOneriText : null) : (this.state.TMLeadSuggestion?.length > 0 ? this.state.TMLeadSuggestion[0].terminOneriText : null))), ReactSystemFunctions.convertToTypeByName("True", "string"))) === true ? "visible" : "hidden")
		stateVars.TMGetProductDetailStockByLeadId = result?.data.tmGetProductDetailStockByLeadId;
		formVars.reservationpopup3_381460_value = ReactSystemFunctions.toString(this, (stateVars.TMGetProductDetailStockByLeadId !== undefined ? (stateVars.TMGetProductDetailStockByLeadId?.length > 0 ? stateVars.TMGetProductDetailStockByLeadId[0].toplamStok : null) : (this.state.TMGetProductDetailStockByLeadId?.length > 0 ? this.state.TMGetProductDetailStockByLeadId[0].toplamStok : null)));
		formVars.reservationpopup3_362234_value = ReactSystemFunctions.toString(this, (stateVars.TMGetProductDetailStockByLeadId !== undefined ? (stateVars.TMGetProductDetailStockByLeadId?.length > 0 ? stateVars.TMGetProductDetailStockByLeadId[0].rezerveStok : null) : (this.state.TMGetProductDetailStockByLeadId?.length > 0 ? this.state.TMGetProductDetailStockByLeadId[0].rezerveStok : null)));
		formVars.reservationpopup3_886181_value = ReactSystemFunctions.toString(this, (stateVars.TMGetProductDetailStockByLeadId !== undefined ? (stateVars.TMGetProductDetailStockByLeadId?.length > 0 ? stateVars.TMGetProductDetailStockByLeadId[0].musaitStok : null) : (this.state.TMGetProductDetailStockByLeadId?.length > 0 ? this.state.TMGetProductDetailStockByLeadId[0].musaitStok : null)));
		stateVars.isComp114164Visible = ((ReactSystemFunctions.isGreaterThan(ReactSystemFunctions.value(this, (stateVars.TMGetProductDetailStockByLeadId !== undefined ? (stateVars.TMGetProductDetailStockByLeadId?.length > 0 ? stateVars.TMGetProductDetailStockByLeadId[0].musaitStok : null) : (this.state.TMGetProductDetailStockByLeadId?.length > 0 ? this.state.TMGetProductDetailStockByLeadId[0].musaitStok : null))), ReactSystemFunctions.convertToTypeByName("0", "string"))) === true ? "visible" : "hidden")
		stateVars.isComp550602Visible = ((ReactSystemFunctions.isLessThan(ReactSystemFunctions.value(this, (stateVars.TMGetProductDetailStockByLeadId !== undefined ? (stateVars.TMGetProductDetailStockByLeadId?.length > 0 ? stateVars.TMGetProductDetailStockByLeadId[0].musaitStok : null) : (this.state.TMGetProductDetailStockByLeadId?.length > 0 ? this.state.TMGetProductDetailStockByLeadId[0].musaitStok : null))), ReactSystemFunctions.convertToTypeByName("1", "string"))) === true ? "visible" : "hidden")
		this.props.form?.setFieldsValue(formVars);
		
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.reservationPopUp3PageInit1_();
                  resolve();
                });
          })



        
        KuikaAppManager.hideSpinner(this);
        return isErrorOccurred;
    }
	reservationPopUp3PageInit1_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


	if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }

			formVars.reservationpopup3_738912_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadById !== undefined ? (stateVars.TM_GetLeadById?.length > 0 ? stateVars.TM_GetLeadById[0].urunAdi : null) : (this.state.TM_GetLeadById?.length > 0 ? this.state.TM_GetLeadById[0].urunAdi : null)));

			formVars.reservationpopup3_148239_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadById !== undefined ? (stateVars.TM_GetLeadById?.length > 0 ? stateVars.TM_GetLeadById[0].magaza : null) : (this.state.TM_GetLeadById?.length > 0 ? this.state.TM_GetLeadById[0].magaza : null)));

			formVars.reservationpopup3_1158_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadById !== undefined ? (stateVars.TM_GetLeadById?.length > 0 ? stateVars.TM_GetLeadById[0].categoryName : null) : (this.state.TM_GetLeadById?.length > 0 ? this.state.TM_GetLeadById[0].categoryName : null)));

			stateVars.isComp114164Visible = ((ReactSystemFunctions.isGreaterThan(ReactSystemFunctions.value(this, (stateVars.TMGetProductDetailStockByLeadId !== undefined ? (stateVars.TMGetProductDetailStockByLeadId?.length > 0 ? stateVars.TMGetProductDetailStockByLeadId[0].musaitStok : null) : (this.state.TMGetProductDetailStockByLeadId?.length > 0 ? this.state.TMGetProductDetailStockByLeadId[0].musaitStok : null))), ReactSystemFunctions.convertToTypeByName("0", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp550602Visible = ((ReactSystemFunctions.isLessThan(ReactSystemFunctions.value(this, (stateVars.TMGetProductDetailStockByLeadId !== undefined ? (stateVars.TMGetProductDetailStockByLeadId?.length > 0 ? stateVars.TMGetProductDetailStockByLeadId[0].musaitStok : null) : (this.state.TMGetProductDetailStockByLeadId?.length > 0 ? this.state.TMGetProductDetailStockByLeadId[0].musaitStok : null))), ReactSystemFunctions.convertToTypeByName("1", "string"))) === true ? "visible" : "hidden")
			formVars.reservationpopup3_381460_value = ReactSystemFunctions.toString(this, (stateVars.TMGetProductDetailStockByLeadId !== undefined ? (stateVars.TMGetProductDetailStockByLeadId?.length > 0 ? stateVars.TMGetProductDetailStockByLeadId[0].toplamStok : null) : (this.state.TMGetProductDetailStockByLeadId?.length > 0 ? this.state.TMGetProductDetailStockByLeadId[0].toplamStok : null)));

			formVars.reservationpopup3_362234_value = ReactSystemFunctions.toString(this, (stateVars.TMGetProductDetailStockByLeadId !== undefined ? (stateVars.TMGetProductDetailStockByLeadId?.length > 0 ? stateVars.TMGetProductDetailStockByLeadId[0].rezerveStok : null) : (this.state.TMGetProductDetailStockByLeadId?.length > 0 ? this.state.TMGetProductDetailStockByLeadId[0].rezerveStok : null)));

			formVars.reservationpopup3_886181_value = ReactSystemFunctions.toString(this, (stateVars.TMGetProductDetailStockByLeadId !== undefined ? (stateVars.TMGetProductDetailStockByLeadId?.length > 0 ? stateVars.TMGetProductDetailStockByLeadId[0].musaitStok : null) : (this.state.TMGetProductDetailStockByLeadId?.length > 0 ? this.state.TMGetProductDetailStockByLeadId[0].musaitStok : null)));

			formVars.reservationpopup3_479797_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadById !== undefined ? (stateVars.TM_GetLeadById?.length > 0 ? stateVars.TM_GetLeadById[0].musteriAdi : null) : (this.state.TM_GetLeadById?.length > 0 ? this.state.TM_GetLeadById[0].musteriAdi : null)));

			formVars.reservationpopup3_270773_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadById !== undefined ? (stateVars.TM_GetLeadById?.length > 0 ? stateVars.TM_GetLeadById[0].talepOlusturmaTarihi : null) : (this.state.TM_GetLeadById?.length > 0 ? this.state.TM_GetLeadById[0].talepOlusturmaTarihi : null)));

			formVars.reservationpopup3_53417_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadById !== undefined ? (stateVars.TM_GetLeadById?.length > 0 ? stateVars.TM_GetLeadById[0].leadCode : null) : (this.state.TM_GetLeadById?.length > 0 ? this.state.TM_GetLeadById[0].leadCode : null)));

			formVars.reservationpopup3_983813_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadById !== undefined ? (stateVars.TM_GetLeadById?.length > 0 ? stateVars.TM_GetLeadById[0].terminTarihi : null) : (this.state.TM_GetLeadById?.length > 0 ? this.state.TM_GetLeadById[0].terminTarihi : null)));

			formVars.reservationpopup3_908246_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadById !== undefined ? (stateVars.TM_GetLeadById?.length > 0 ? stateVars.TM_GetLeadById[0].satisPersoneli : null) : (this.state.TM_GetLeadById?.length > 0 ? this.state.TM_GetLeadById[0].satisPersoneli : null)));

			formVars.reservationpopup3_432168_value = ReactSystemFunctions.toString(this, (stateVars.TMLeadSuggestion !== undefined ? (stateVars.TMLeadSuggestion?.length > 0 ? stateVars.TMLeadSuggestion[0].terminYil : null) : (this.state.TMLeadSuggestion?.length > 0 ? this.state.TMLeadSuggestion[0].terminYil : null)));

			formVars.reservationpopup3_185461_value = ReactSystemFunctions.toString(this, (stateVars.TMLeadSuggestion !== undefined ? (stateVars.TMLeadSuggestion?.length > 0 ? stateVars.TMLeadSuggestion[0].terminAy : null) : (this.state.TMLeadSuggestion?.length > 0 ? this.state.TMLeadSuggestion[0].terminAy : null)));

			stateVars.isComp41164Visible = ((ReactSystemFunctions.isNotEmpty(ReactSystemFunctions.toString(this, (stateVars.TMLeadSuggestion !== undefined ? (stateVars.TMLeadSuggestion?.length > 0 ? stateVars.TMLeadSuggestion[0].terminOneriText : null) : (this.state.TMLeadSuggestion?.length > 0 ? this.state.TMLeadSuggestion[0].terminOneriText : null))), ReactSystemFunctions.convertToTypeByName("True", "string"))) === true ? "visible" : "hidden")
			formVars.reservationpopup3_890290_value = ReactSystemFunctions.toString(this, (stateVars.TMLeadSuggestion !== undefined ? (stateVars.TMLeadSuggestion?.length > 0 ? stateVars.TMLeadSuggestion[0].terminOneriText : null) : (this.state.TMLeadSuggestion?.length > 0 ? this.state.TMLeadSuggestion[0].terminOneriText : null)));

			formVars.reservationpopup3_690531_value = ReactSystemFunctions.toString(this, (stateVars.TMLeadSuggestion !== undefined ? (stateVars.TMLeadSuggestion?.length > 0 ? stateVars.TMLeadSuggestion[0].terminOneriAciklama : null) : (this.state.TMLeadSuggestion?.length > 0 ? this.state.TMLeadSuggestion[0].terminOneriAciklama : null)));


	this.props.form?.setFieldsValue(formVars);
	this.setState(stateVars);
	KuikaAppManager.hideSpinner(this);

            this.setPageInitLoaded(true);
            return isErrorOccurred;
        }




		reservationPopUp3Component_610197_onClick = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
KuikaAppManager.showSpinner(this);

				stateVars.GoBack = await ReactSystemFunctions.goBack(this, false);

		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

            
            return isErrorOccurred;
        }


    reservationPopUp3Component_517521_onClick = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
		KuikaAppManager.increaseServerRequestCount();

        let localVar = {
				EstimatedYear_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toInteger(this, ReactSystemFunctions.value(this, "reservationpopup3_432168_value", "value", "", "key", "")), "number"),
				EstimatedMonth_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toInteger(this, ReactSystemFunctions.value(this, "reservationpopup3_185461_value", "value", "", "key", "")), "number"),
				LeadId_0: ReactSystemFunctions.convertToTypeByName(this.props.screenInputs.LeadId ?? this.props.screenInputs.leadid, "Guid"),
				UserId_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.getMyUserId(), "Guid"),
				Note_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "reservationpopup3_763837_value", "value", "", "", "")), "string")
        }

		KuikaAppManager.showSpinner(this);
		
        if (true) {
        KuikaAppManager.showSpinner(this);
        }
        let result = await KuikaAppManager.ApiRequest(this, "reservationPopUp3/reservationPopUp3Component_517521_onClick", localVar)
        if (!KMainFunctions.IsResStatus2XX(result)) return true;

			stateVars.TMApproveLeadAndReservationCreate = result?.data.tmApproveLeadAndReservationCreate;
			this.props.form?.setFieldsValue(formVars);
			
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.reservationPopUp3Component_517521_onClick1_();
                  resolve();
                });
          })



        
        KuikaAppManager.hideSpinner(this);
        return isErrorOccurred;
    }
		reservationPopUp3Component_517521_onClick1_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }

				stateVars.Notify = await ReactSystemFunctions.notify(this, ReactSystemFunctions.toString(this, (stateVars.TMApproveLeadAndReservationCreate !== undefined ? (stateVars.TMApproveLeadAndReservationCreate?.length > 0 ? stateVars.TMApproveLeadAndReservationCreate[0].message : null) : (this.state.TMApproveLeadAndReservationCreate?.length > 0 ? this.state.TMApproveLeadAndReservationCreate[0].message : null))), ReactSystemFunctions.convertToTypeByName("default", "string"), ReactSystemFunctions.convertToTypeByName("top-center", "string"), 2, ReactSystemFunctions.convertToTypeByName("", "string"), ReactSystemFunctions.convertToTypeByName("", "string"), 0);

		this.props.form?.setFieldsValue(formVars);
		
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.reservationPopUp3Component_517521_onClick2_();
                  resolve();
                });
          })

            
            return isErrorOccurred;
        }
		reservationPopUp3Component_517521_onClick2_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
if (ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, (stateVars.TMApproveLeadAndReservationCreate !== undefined ? (stateVars.TMApproveLeadAndReservationCreate?.length > 0 ? stateVars.TMApproveLeadAndReservationCreate[0].success : null) : (this.state.TMApproveLeadAndReservationCreate?.length > 0 ? this.state.TMApproveLeadAndReservationCreate[0].success : null))), "1")) {
            
				stateVars.GoBack = await ReactSystemFunctions.goBack(this, false);

		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

        } else {
            KuikaAppManager.hideSpinner(this);
        }

            
            return isErrorOccurred;
        }





		reservationPopUp3Component_722027_onClick = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
KuikaAppManager.showSpinner(this);

				stateVars.GoBack = await ReactSystemFunctions.goBack(this, false);

		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

            
            return isErrorOccurred;
        }




    async callCallbackFunction(diId: number, isFromMaster: boolean = false) {
        let isErrorOccurred = false;
		let pageInitCallerNavDiIDs = [] as number[];
		if (isFromMaster || pageInitCallerNavDiIDs.indexOf(diId) > -1) {
			await this.reservationPopUp3PageInit();
		}

    }


}
