import React from "react";
import Axios, { AxiosResponse } from "axios";
import { KuikaAppManager } from "../../shared/utilty/kuika-app-manager";
import { ReactSystemFunctions } from "../../shared/utilty/react-system-functions";
import { KNavigator } from "../../shared/hoc/with-history";
import { KContext } from "../../shared/hoc/with-context";
import { useLocation } from "react-router-dom";
import { FormInstance } from "antd/es/form";
import { Guid } from "guid-typescript";
import Swal from "sweetalert2";
import { KMainFunctions } from "../../shared/utilty/main-functions";
import moment from "moment";
import { IValidationData } from "../../models/dto/validation-data";
import { IStripePayment } from "../../models/dto/stripe-payment";
import { IUserInfoDto } from "../../models/dto/user-info.dto";
import { UserService } from "../../services/user-service";
import { kuikaCoreWasmBridgeService } from "../../services/_singletons";
import _ from "lodash";
import mqtt, { MqttClient } from "mqtt";
import { IMqttResult } from "../../models/dto/mqtt.dto";
import { MasterScreen_ScreenContext } from "../masterscreen/masterscreen-context";

declare let window: any;

export interface IDistributionDetail_ScreenProps {
  navigator: KNavigator;
  form: FormInstance<any>;
  googleLogin: any;
  screenInputs: any;
  context: KContext;
  initialValues: any;
  children: any;
}

export interface IDistributionDetail_ScreenState {
    isSpinnerVisible: boolean;
    isPageVisible: boolean;
	isLeftMenuVisible: boolean;
    spinnerCount: number;
    selectedLanguage: string;
    isPageInitLoaded: false;
    isPageRecurringLoaded: false;
	TM_GetDistributionItemDetailsByHeader: any[];
	TM_GetDistributionItemDetailsByHeader_dummy: any[];
	TM_GetStoreDistributionSummary: any[];
	TM_GetStoreDistributionSummary_dummy: any[];
	TM_GetDistributionBrandDropdown: any[];
	TM_GetDistributionBrandDropdown_dummy: any[];
	NAVIGATE: any;
	NAVIGATE_dummy: any;
	SetValueOf: any;
	SetValueOf_dummy: any;
	TM_GiveDistributionOrder: any[];
	TM_GiveDistributionOrder_dummy: any[];
	Notify: boolean;
	Notify_dummy: boolean;
	isComp151745Visible: 'visible' | 'hidden';

}

export class DistributionDetail_ScreenBase extends React.PureComponent<IDistributionDetail_ScreenProps, any> {
    static contextType = MasterScreen_ScreenContext;
    declare context: React.ContextType<typeof MasterScreen_ScreenContext>;
	distributiondetail_431329_value_kuikaSelectBoxRef: React.RefObject<any>;
	distributiondetail_548003_value_kuikaTableRef: React.RefObject<any>;
    ml=[{"Id":"d5a61d2b-bd60-485f-86e2-661e9ed4e486","Name":"en_US","ShortName":"English","IsDefault":true,"LanguagePhrases":[]},{"Id":"19274377-753d-462c-8e94-92f2353f60f4","Name":"FixedValues","ShortName":"FixedValues","LanguagePhrases":[{"Id":783986,"PropertyName":"value","Value":"Dağıtım Özeti"},{"Id":40070,"PropertyName":"value","Value":"Toplam Tahsis Edilen"},{"Id":226535,"PropertyName":"value","Value":"Mağaza Bazlı Özet"},{"Id":533352,"PropertyName":"value","Value":"Adana Mağaza"},{"Id":223679,"PropertyName":"value","Value":"Antalya Mağaza"},{"Id":598030,"PropertyName":"value","Value":"Mersin Mağaza"},{"Id":342323,"PropertyName":"value","Value":"Gaziantep Mağaza"},{"Id":307190,"PropertyName":"header","Value":"Filtreler"},{"Id":831142,"PropertyName":"value","Value":"Marka"},{"Id":274975,"PropertyName":"value","Value":"Ürün Kodu"},{"Id":501085,"PropertyName":"value","Value":"Ürün Adı"},{"Id":511890,"PropertyName":"value","Value":"RMC Kodu"},{"Id":5461,"PropertyName":"value","Value":"Müşteri Adı-Soyadı"},{"Id":577520,"PropertyName":"label","Value":"Filtreleri Temizle"},{"Id":129189,"PropertyName":"title","Value":"Ürün Kodu"},{"Id":955696,"PropertyName":"value","Value":"[datafield:productcode]"},{"Id":108888,"PropertyName":"title","Value":"Ürün Adı"},{"Id":129726,"PropertyName":"value","Value":"[datafield:productname]"},{"Id":372047,"PropertyName":"title","Value":"Marka"},{"Id":705896,"PropertyName":"value","Value":"[datafield:brand]"},{"Id":431616,"PropertyName":"title","Value":"RMC Kodu"},{"Id":886777,"PropertyName":"value","Value":"[datafield:rmccode]"},{"Id":274810,"PropertyName":"title","Value":"Teslim Edilecek Mağaza"},{"Id":846858,"PropertyName":"value","Value":"[datafield:storename]"},{"Id":157357,"PropertyName":"title","Value":"Müşteri"},{"Id":960360,"PropertyName":"value","Value":"[datafield:customerfullname]"},{"Id":758233,"PropertyName":"title","Value":"Telefon Numarası"},{"Id":520483,"PropertyName":"value","Value":"[datafield:customerphone]"},{"Id":904620,"PropertyName":"label","Value":"Geri Dön"},{"Id":2632,"PropertyName":"label","Value":"Dağıtım Emri Ver"}]}]
    defaultML = "en_US"
    
    screenHash = ""
    

    private _prevMasterPageInitLoaded: boolean = false;
    private _prevMasterPageRecurringLoaded: boolean = false;
    private _prevShouldTriggerPageInit: boolean = false;
    constructor(props) {
        super(props);
		this.distributiondetail_431329_value_kuikaSelectBoxRef = React.createRef();
		this.distributiondetail_179075_value_kuikaTextInputRef = React.createRef();
		this.distributiondetail_780497_value_kuikaTextInputRef = React.createRef();
		this.distributiondetail_176495_value_kuikaTextInputRef = React.createRef();
		this.distributiondetail_944239_value_kuikaTextInputRef = React.createRef();
		this.distributiondetail_548003_value_kuikaTableRef = React.createRef();

        this.state = {
            isSpinnerVisible: false,
            isPageVisible: false,
            isLeftMenuVisible: false,
            spinnerCount: 0,
            selectedLanguage: "",
            isPageInitLoaded: false,
            isPageRecurringLoaded: false,
            	        TM_GetDistributionItemDetailsByHeader: [],
	        TM_GetStoreDistributionSummary: [],
	        TM_GetDistributionBrandDropdown: [],
	        NAVIGATE: "",
	        SetValueOf: "",
	        TM_GiveDistributionOrder: [],
	        Notify: false,
	        isComp151745Visible: 'hidden',

        }

        this.state.isPageVisible = true;
        
    }

    async componentDidMount() {

        if (KuikaAppManager.isPageInitPrevented()) {
            KuikaAppManager.calculateAndSetBodyHeight("distributiondetail", "masterscreen_screen");
            return;
        }
        this.context.registerCallbackFunction(this.callCallbackFunction.bind(this));
        
        ReactSystemFunctions.validateToken()
        this.fillFormInitValues();
        if (false){
            await this.DistributionDetailPageInit();
        } else if (this.context?.isMasterPageInitLoaded) { this._prevMasterPageInitLoaded = true; await this.DistributionDetailPageInit(); }
        
        
        
        KuikaAppManager.calculateAndSetBodyHeight("distributiondetail", "masterscreen_screen");

        if (ReactSystemFunctions.getIsMicroApp() === false) {
           window.parentScreen = this;
        }
    }

    componentWillUnmount() {
        
        
        

        if (ReactSystemFunctions.getIsMicroApp() === false) {
           window.parentScreen = null;
        }
    }

    

        
    componentDidUpdate= async (prevProps, prevState) => {
		KuikaAppManager.calculateAndSetBodyHeight("distributiondetail", "masterscreen_screen"    );
        if (prevProps?.location?.search !== (this.props as any)?.location?.search) {
			await this.DistributionDetailPageInit();
		}

        		if (this._prevMasterPageInitLoaded !== this.context.isMasterPageInitLoaded && this.context.isMasterPageInitLoaded === true) {this._prevMasterPageInitLoaded = this.context.isMasterPageInitLoaded;await this.DistributionDetailPageInit()}


        if (ReactSystemFunctions.getIsMicroApp() === false) {
            for (const key in prevState) {
                if (key.startsWith('NavVisible') && prevState[key] === true && this.state[key] === false) {
                    window.parentScreen = this;
                    break;
                }
            }
        }
	}

    fillFormInitValues() {
        this.props.form?.setFieldsValue({
});

    }

      setPageInitLoaded = (value: boolean) => {
        this.setState({ isPageInitLoaded: value });
      }

      setPageRecurringLoaded = (value: boolean) => {
        this.setState({ isPageRecurringLoaded: value });
      }

      clearFieldValidation = (changedValues: any) => {
        const fieldName = Object.keys(changedValues)[0];
        if (fieldName) {
          this.props.form?.setFields([
            {
              name: fieldName,
              errors: []
            }
          ]);
        }
      };

      

    DistributionDetailPageInit = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


	if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }

        let localVar = {
			DistributionHeaderId_0: ReactSystemFunctions.convertToTypeByName(this.props.screenInputs.HeaderId ?? this.props.screenInputs.headerid, "Guid"),
			Brand_0: ReactSystemFunctions.convertToTypeByName("", "string"),
			ProductCode_0: ReactSystemFunctions.convertToTypeByName("", "string"),
			ProductName_0: ReactSystemFunctions.convertToTypeByName("", "string"),
			RMCCode_0: ReactSystemFunctions.convertToTypeByName("", "string"),
			CustomerName_0: ReactSystemFunctions.convertToTypeByName("", "string"),
			DistributionHeaderId_1: ReactSystemFunctions.convertToTypeByName(this.props.screenInputs.HeaderId ?? this.props.screenInputs.headerid, "Guid"),
			DistributionHeaderId_2: ReactSystemFunctions.convertToTypeByName(this.props.screenInputs.HeaderId ?? this.props.screenInputs.headerid, "Guid"),
			DistributionHeaderId_3: ReactSystemFunctions.convertToTypeByName(this.props.screenInputs.HeaderId ?? this.props.screenInputs.headerid, "Guid")
        }

	KuikaAppManager.showSpinner(this);
	
        if (true) {
        KuikaAppManager.showSpinner(this);
        }
        let result = await KuikaAppManager.ApiRequest(this, "DistributionDetail/DistributionDetailPageInit", localVar)
        if (!KMainFunctions.IsResStatus2XX(result)) return true;

		stateVars.TM_GetDistributionItemDetailsByHeader = result?.data.tM_GetDistributionItemDetailsByHeader;
		
		stateVars.TM_GetStoreDistributionSummary = result?.data.tM_GetStoreDistributionSummary;
		formVars.distributiondetail_763266_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetStoreDistributionSummary !== undefined ? (stateVars.TM_GetStoreDistributionSummary?.length > 0 ? stateVars.TM_GetStoreDistributionSummary[0].toplamAdet : null) : (this.state.TM_GetStoreDistributionSummary?.length > 0 ? this.state.TM_GetStoreDistributionSummary[0].toplamAdet : null)));
		formVars.distributiondetail_96212_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetStoreDistributionSummary !== undefined ? (stateVars.TM_GetStoreDistributionSummary?.length > 0 ? stateVars.TM_GetStoreDistributionSummary[0].adanaAdet : null) : (this.state.TM_GetStoreDistributionSummary?.length > 0 ? this.state.TM_GetStoreDistributionSummary[0].adanaAdet : null)));
		formVars.distributiondetail_341559_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetStoreDistributionSummary !== undefined ? (stateVars.TM_GetStoreDistributionSummary?.length > 0 ? stateVars.TM_GetStoreDistributionSummary[0].antalyaAdet : null) : (this.state.TM_GetStoreDistributionSummary?.length > 0 ? this.state.TM_GetStoreDistributionSummary[0].antalyaAdet : null)));
		formVars.distributiondetail_232453_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetStoreDistributionSummary !== undefined ? (stateVars.TM_GetStoreDistributionSummary?.length > 0 ? stateVars.TM_GetStoreDistributionSummary[0].mersinAdet : null) : (this.state.TM_GetStoreDistributionSummary?.length > 0 ? this.state.TM_GetStoreDistributionSummary[0].mersinAdet : null)));
		formVars.distributiondetail_439294_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetStoreDistributionSummary !== undefined ? (stateVars.TM_GetStoreDistributionSummary?.length > 0 ? stateVars.TM_GetStoreDistributionSummary[0].gaziantepAdet : null) : (this.state.TM_GetStoreDistributionSummary?.length > 0 ? this.state.TM_GetStoreDistributionSummary[0].gaziantepAdet : null)));
		stateVars.TM_GetStoreDistributionSummary = result?.data.tM_GetStoreDistributionSummary;
		formVars.distributiondetail_763266_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetStoreDistributionSummary !== undefined ? (stateVars.TM_GetStoreDistributionSummary?.length > 0 ? stateVars.TM_GetStoreDistributionSummary[0].toplamAdet : null) : (this.state.TM_GetStoreDistributionSummary?.length > 0 ? this.state.TM_GetStoreDistributionSummary[0].toplamAdet : null)));
		formVars.distributiondetail_96212_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetStoreDistributionSummary !== undefined ? (stateVars.TM_GetStoreDistributionSummary?.length > 0 ? stateVars.TM_GetStoreDistributionSummary[0].adanaAdet : null) : (this.state.TM_GetStoreDistributionSummary?.length > 0 ? this.state.TM_GetStoreDistributionSummary[0].adanaAdet : null)));
		formVars.distributiondetail_341559_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetStoreDistributionSummary !== undefined ? (stateVars.TM_GetStoreDistributionSummary?.length > 0 ? stateVars.TM_GetStoreDistributionSummary[0].antalyaAdet : null) : (this.state.TM_GetStoreDistributionSummary?.length > 0 ? this.state.TM_GetStoreDistributionSummary[0].antalyaAdet : null)));
		formVars.distributiondetail_232453_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetStoreDistributionSummary !== undefined ? (stateVars.TM_GetStoreDistributionSummary?.length > 0 ? stateVars.TM_GetStoreDistributionSummary[0].mersinAdet : null) : (this.state.TM_GetStoreDistributionSummary?.length > 0 ? this.state.TM_GetStoreDistributionSummary[0].mersinAdet : null)));
		formVars.distributiondetail_439294_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetStoreDistributionSummary !== undefined ? (stateVars.TM_GetStoreDistributionSummary?.length > 0 ? stateVars.TM_GetStoreDistributionSummary[0].gaziantepAdet : null) : (this.state.TM_GetStoreDistributionSummary?.length > 0 ? this.state.TM_GetStoreDistributionSummary[0].gaziantepAdet : null)));
		stateVars.TM_GetDistributionBrandDropdown = result?.data.tM_GetDistributionBrandDropdown;
		
		formVars.distributiondetail_431329_options = stateVars.TM_GetDistributionBrandDropdown;
		this.props.form?.setFieldsValue(formVars);
		
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.DistributionDetailPageInit1_();
                  resolve();
                });
          })



        
        KuikaAppManager.hideSpinner(this);
        return isErrorOccurred;
    }
	DistributionDetailPageInit1_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


	if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }

			formVars.distributiondetail_763266_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetStoreDistributionSummary !== undefined ? (stateVars.TM_GetStoreDistributionSummary?.length > 0 ? stateVars.TM_GetStoreDistributionSummary[0].toplamAdet : null) : (this.state.TM_GetStoreDistributionSummary?.length > 0 ? this.state.TM_GetStoreDistributionSummary[0].toplamAdet : null)));

			formVars.distributiondetail_96212_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetStoreDistributionSummary !== undefined ? (stateVars.TM_GetStoreDistributionSummary?.length > 0 ? stateVars.TM_GetStoreDistributionSummary[0].adanaAdet : null) : (this.state.TM_GetStoreDistributionSummary?.length > 0 ? this.state.TM_GetStoreDistributionSummary[0].adanaAdet : null)));

			formVars.distributiondetail_341559_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetStoreDistributionSummary !== undefined ? (stateVars.TM_GetStoreDistributionSummary?.length > 0 ? stateVars.TM_GetStoreDistributionSummary[0].antalyaAdet : null) : (this.state.TM_GetStoreDistributionSummary?.length > 0 ? this.state.TM_GetStoreDistributionSummary[0].antalyaAdet : null)));

			formVars.distributiondetail_232453_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetStoreDistributionSummary !== undefined ? (stateVars.TM_GetStoreDistributionSummary?.length > 0 ? stateVars.TM_GetStoreDistributionSummary[0].mersinAdet : null) : (this.state.TM_GetStoreDistributionSummary?.length > 0 ? this.state.TM_GetStoreDistributionSummary[0].mersinAdet : null)));

			formVars.distributiondetail_439294_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetStoreDistributionSummary !== undefined ? (stateVars.TM_GetStoreDistributionSummary?.length > 0 ? stateVars.TM_GetStoreDistributionSummary[0].gaziantepAdet : null) : (this.state.TM_GetStoreDistributionSummary?.length > 0 ? this.state.TM_GetStoreDistributionSummary[0].gaziantepAdet : null)));

			
			stateVars.dataSource_431329 = stateVars.TM_GetDistributionBrandDropdown ?? this.state.TM_GetDistributionBrandDropdown;
			stateVars.dataSource_431329 = stateVars.TM_GetDistributionBrandDropdown ?? this.state.TM_GetDistributionBrandDropdown;
			
			stateVars.dataSource_548003 = stateVars.TM_GetDistributionItemDetailsByHeader ?? this.state.TM_GetDistributionItemDetailsByHeader;
			stateVars.isComp151745Visible = ((ReactSystemFunctions.isEqualTo(this.props.screenInputs.StatusName ?? this.props.screenInputs.statusname, ReactSystemFunctions.convertToTypeByName("Dağıtım Onaylandı", "string"))) === true ? "visible" : "hidden")

	this.props.form?.setFieldsValue(formVars);
	this.setState(stateVars);
	KuikaAppManager.hideSpinner(this);

            this.setPageInitLoaded(true);
            return isErrorOccurred;
        }




		DistributionDetailComponent_591177_onClick = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
KuikaAppManager.showSpinner(this);

const __currentPath = (window.location.hash ? window.location.hash.replace(/^#/, '').split('?')[0] : window.location.pathname.split('?')[0]).toLowerCase();
if (__currentPath !== "/distributiondetailstore") {
  this.context.setMasterPageInitLoaded(false);
  this.context.setMasterPageRecurringLoaded(false);
  this.context.setShouldTriggerPageInit(true);
}
					KuikaAppManager.prepareForNavigation();
						KuikaAppManager.addToPageInputVariables("DistributionDetailStore", "HeaderId", ReactSystemFunctions.convertToTypeByName(this.props.screenInputs.HeaderId ?? this.props.screenInputs.headerid, "Guid"));
						KuikaAppManager.addToPageInputVariables("DistributionDetailStore", "StoreCode", ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.convertToTypeByName("ADN001", "string"), "string"));
						KuikaAppManager.addToPageInputVariables("DistributionDetailStore", "DistributionCode", ReactSystemFunctions.convertToTypeByName(this.props.screenInputs.DistributionCode ?? this.props.screenInputs.distributioncode, "string"));

				stateVars.NAVIGATE = await ReactSystemFunctions.navigate(this, undefined, "DistributionDetail", "DistributionDetailStore", "", "currentPage", null, null, null, null, null, null, true, false);

		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

            
            return isErrorOccurred;
        }


		DistributionDetailComponent_750636_onClick = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
KuikaAppManager.showSpinner(this);

const __currentPath = (window.location.hash ? window.location.hash.replace(/^#/, '').split('?')[0] : window.location.pathname.split('?')[0]).toLowerCase();
if (__currentPath !== "/distributiondetailstore") {
  this.context.setMasterPageInitLoaded(false);
  this.context.setMasterPageRecurringLoaded(false);
  this.context.setShouldTriggerPageInit(true);
}
					KuikaAppManager.prepareForNavigation();
						KuikaAppManager.addToPageInputVariables("DistributionDetailStore", "HeaderId", ReactSystemFunctions.convertToTypeByName(this.props.screenInputs.HeaderId ?? this.props.screenInputs.headerid, "Guid"));
						KuikaAppManager.addToPageInputVariables("DistributionDetailStore", "StoreCode", ReactSystemFunctions.convertToTypeByName("ANT001", "string"));
						KuikaAppManager.addToPageInputVariables("DistributionDetailStore", "DistributionCode", ReactSystemFunctions.convertToTypeByName(this.props.screenInputs.DistributionCode ?? this.props.screenInputs.distributioncode, "string"));

				stateVars.NAVIGATE = await ReactSystemFunctions.navigate(this, undefined, "DistributionDetail", "DistributionDetailStore", "", "currentPage", null, null, null, null, null, null, true, false);

		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

            
            return isErrorOccurred;
        }


		DistributionDetailComponent_153337_onClick = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
KuikaAppManager.showSpinner(this);

const __currentPath = (window.location.hash ? window.location.hash.replace(/^#/, '').split('?')[0] : window.location.pathname.split('?')[0]).toLowerCase();
if (__currentPath !== "/distributiondetailstore") {
  this.context.setMasterPageInitLoaded(false);
  this.context.setMasterPageRecurringLoaded(false);
  this.context.setShouldTriggerPageInit(true);
}
					KuikaAppManager.prepareForNavigation();
						KuikaAppManager.addToPageInputVariables("DistributionDetailStore", "HeaderId", ReactSystemFunctions.convertToTypeByName(this.props.screenInputs.HeaderId ?? this.props.screenInputs.headerid, "Guid"));
						KuikaAppManager.addToPageInputVariables("DistributionDetailStore", "StoreCode", ReactSystemFunctions.convertToTypeByName("MRS001", "string"));
						KuikaAppManager.addToPageInputVariables("DistributionDetailStore", "DistributionCode", ReactSystemFunctions.convertToTypeByName(this.props.screenInputs.DistributionCode ?? this.props.screenInputs.distributioncode, "string"));

				stateVars.NAVIGATE = await ReactSystemFunctions.navigate(this, undefined, "DistributionDetail", "DistributionDetailStore", "", "currentPage", null, null, null, null, null, null, true, false);

		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

            
            return isErrorOccurred;
        }


		DistributionDetailComponent_570385_onClick = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
KuikaAppManager.showSpinner(this);

const __currentPath = (window.location.hash ? window.location.hash.replace(/^#/, '').split('?')[0] : window.location.pathname.split('?')[0]).toLowerCase();
if (__currentPath !== "/distributiondetailstore") {
  this.context.setMasterPageInitLoaded(false);
  this.context.setMasterPageRecurringLoaded(false);
  this.context.setShouldTriggerPageInit(true);
}
					KuikaAppManager.prepareForNavigation();
						KuikaAppManager.addToPageInputVariables("DistributionDetailStore", "HeaderId", ReactSystemFunctions.convertToTypeByName(this.props.screenInputs.HeaderId ?? this.props.screenInputs.headerid, "Guid"));
						KuikaAppManager.addToPageInputVariables("DistributionDetailStore", "StoreCode", ReactSystemFunctions.convertToTypeByName("GZT001", "string"));
						KuikaAppManager.addToPageInputVariables("DistributionDetailStore", "DistributionCode", ReactSystemFunctions.convertToTypeByName(this.props.screenInputs.DistributionCode ?? this.props.screenInputs.distributioncode, "string"));

				stateVars.NAVIGATE = await ReactSystemFunctions.navigate(this, undefined, "DistributionDetail", "DistributionDetailStore", "", "currentPage", null, null, null, null, null, null, true, false);

		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

            
            return isErrorOccurred;
        }


    DistributionDetailComponent_431329_onChange = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
		KuikaAppManager.increaseServerRequestCount();

        let localVar = {
				DistributionHeaderId_0: ReactSystemFunctions.convertToTypeByName(this.props.screenInputs.HeaderId ?? this.props.screenInputs.headerid, "Guid"),
				Brand_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "distributiondetail_431329_value", "value", "TM_GetDistributionBrandDropdown", "brandName", "brandName")), "string"),
				ProductCode_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "distributiondetail_179075_value", "value", "", "", "")), "string"),
				ProductName_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "distributiondetail_780497_value", "value", "", "", "")), "string"),
				RMCCode_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "distributiondetail_176495_value", "value", "", "", "")), "string"),
				CustomerName_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "distributiondetail_944239_value", "value", "", "", "")), "string")
        }

		KuikaAppManager.showSpinner(this);
		
        if (true) {
        KuikaAppManager.showSpinner(this);
        }
        let result = await KuikaAppManager.ApiRequest(this, "DistributionDetail/DistributionDetailComponent_431329_onChange", localVar)
        if (!KMainFunctions.IsResStatus2XX(result)) return true;

			stateVars.TM_GetDistributionItemDetailsByHeader = result?.data.tM_GetDistributionItemDetailsByHeader;
			
			this.props.form?.setFieldsValue(formVars);
			
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.DistributionDetailComponent_431329_onChange1_();
                  resolve();
                });
          })



        
        KuikaAppManager.hideSpinner(this);
        return isErrorOccurred;
    }
		DistributionDetailComponent_431329_onChange1_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }

				
				stateVars.dataSource_548003 = stateVars.TM_GetDistributionItemDetailsByHeader ?? this.state.TM_GetDistributionItemDetailsByHeader;

		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

            
            return isErrorOccurred;
        }




    DistributionDetailComponent_179075_onChange = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
		KuikaAppManager.increaseServerRequestCount();

        let localVar = {
				DistributionHeaderId_0: ReactSystemFunctions.convertToTypeByName(this.props.screenInputs.HeaderId ?? this.props.screenInputs.headerid, "Guid"),
				Brand_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "distributiondetail_431329_value", "value", "TM_GetDistributionBrandDropdown", "brandName", "brandName")), "string"),
				ProductCode_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "distributiondetail_179075_value", "value", "", "", "")), "string"),
				ProductName_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "distributiondetail_780497_value", "value", "", "", "")), "string"),
				RMCCode_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "distributiondetail_176495_value", "value", "", "", "")), "string"),
				CustomerName_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "distributiondetail_944239_value", "value", "", "", "")), "string")
        }

		KuikaAppManager.showSpinner(this);
		
        if (true) {
        KuikaAppManager.showSpinner(this);
        }
        let result = await KuikaAppManager.ApiRequest(this, "DistributionDetail/DistributionDetailComponent_179075_onChange", localVar)
        if (!KMainFunctions.IsResStatus2XX(result)) return true;

			stateVars.TM_GetDistributionItemDetailsByHeader = result?.data.tM_GetDistributionItemDetailsByHeader;
			
			this.props.form?.setFieldsValue(formVars);
			
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.DistributionDetailComponent_179075_onChange1_();
                  resolve();
                });
          })



        
        KuikaAppManager.hideSpinner(this);
        return isErrorOccurred;
    }
		DistributionDetailComponent_179075_onChange1_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }

				
				stateVars.dataSource_548003 = stateVars.TM_GetDistributionItemDetailsByHeader ?? this.state.TM_GetDistributionItemDetailsByHeader;

		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

            
            return isErrorOccurred;
        }




    DistributionDetailComponent_780497_onChange = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
		KuikaAppManager.increaseServerRequestCount();

        let localVar = {
				DistributionHeaderId_0: ReactSystemFunctions.convertToTypeByName(this.props.screenInputs.HeaderId ?? this.props.screenInputs.headerid, "Guid"),
				Brand_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "distributiondetail_431329_value", "value", "TM_GetDistributionBrandDropdown", "brandName", "brandName")), "string"),
				ProductCode_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "distributiondetail_179075_value", "value", "", "", "")), "string"),
				ProductName_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "distributiondetail_780497_value", "value", "", "", "")), "string"),
				RMCCode_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "distributiondetail_176495_value", "value", "", "", "")), "string"),
				CustomerName_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "distributiondetail_944239_value", "value", "", "", "")), "string")
        }

		KuikaAppManager.showSpinner(this);
		
        if (true) {
        KuikaAppManager.showSpinner(this);
        }
        let result = await KuikaAppManager.ApiRequest(this, "DistributionDetail/DistributionDetailComponent_780497_onChange", localVar)
        if (!KMainFunctions.IsResStatus2XX(result)) return true;

			stateVars.TM_GetDistributionItemDetailsByHeader = result?.data.tM_GetDistributionItemDetailsByHeader;
			
			this.props.form?.setFieldsValue(formVars);
			
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.DistributionDetailComponent_780497_onChange1_();
                  resolve();
                });
          })



        
        KuikaAppManager.hideSpinner(this);
        return isErrorOccurred;
    }
		DistributionDetailComponent_780497_onChange1_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }

				
				stateVars.dataSource_548003 = stateVars.TM_GetDistributionItemDetailsByHeader ?? this.state.TM_GetDistributionItemDetailsByHeader;

		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

            
            return isErrorOccurred;
        }




    DistributionDetailComponent_176495_onChange = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
		KuikaAppManager.increaseServerRequestCount();

        let localVar = {
				DistributionHeaderId_0: ReactSystemFunctions.convertToTypeByName(this.props.screenInputs.HeaderId ?? this.props.screenInputs.headerid, "Guid"),
				Brand_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "distributiondetail_431329_value", "value", "TM_GetDistributionBrandDropdown", "brandName", "brandName")), "string"),
				ProductCode_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "distributiondetail_179075_value", "value", "", "", "")), "string"),
				ProductName_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "distributiondetail_780497_value", "value", "", "", "")), "string"),
				RMCCode_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "distributiondetail_176495_value", "value", "", "", "")), "string"),
				CustomerName_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "distributiondetail_944239_value", "value", "", "", "")), "string")
        }

		KuikaAppManager.showSpinner(this);
		
        if (true) {
        KuikaAppManager.showSpinner(this);
        }
        let result = await KuikaAppManager.ApiRequest(this, "DistributionDetail/DistributionDetailComponent_176495_onChange", localVar)
        if (!KMainFunctions.IsResStatus2XX(result)) return true;

			stateVars.TM_GetDistributionItemDetailsByHeader = result?.data.tM_GetDistributionItemDetailsByHeader;
			
			this.props.form?.setFieldsValue(formVars);
			
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.DistributionDetailComponent_176495_onChange1_();
                  resolve();
                });
          })



        
        KuikaAppManager.hideSpinner(this);
        return isErrorOccurred;
    }
		DistributionDetailComponent_176495_onChange1_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }

				
				stateVars.dataSource_548003 = stateVars.TM_GetDistributionItemDetailsByHeader ?? this.state.TM_GetDistributionItemDetailsByHeader;

		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

            
            return isErrorOccurred;
        }




    DistributionDetailComponent_944239_onChange = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
		KuikaAppManager.increaseServerRequestCount();

        let localVar = {
				DistributionHeaderId_0: ReactSystemFunctions.convertToTypeByName(this.props.screenInputs.HeaderId ?? this.props.screenInputs.headerid, "Guid"),
				Brand_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "distributiondetail_431329_value", "value", "TM_GetDistributionBrandDropdown", "brandName", "brandName")), "string"),
				ProductCode_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "distributiondetail_179075_value", "value", "", "", "")), "string"),
				ProductName_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "distributiondetail_780497_value", "value", "", "", "")), "string"),
				RMCCode_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "distributiondetail_176495_value", "value", "", "", "")), "string"),
				CustomerName_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "distributiondetail_944239_value", "value", "", "", "")), "string")
        }

		KuikaAppManager.showSpinner(this);
		
        if (true) {
        KuikaAppManager.showSpinner(this);
        }
        let result = await KuikaAppManager.ApiRequest(this, "DistributionDetail/DistributionDetailComponent_944239_onChange", localVar)
        if (!KMainFunctions.IsResStatus2XX(result)) return true;

			stateVars.TM_GetDistributionItemDetailsByHeader = result?.data.tM_GetDistributionItemDetailsByHeader;
			
			this.props.form?.setFieldsValue(formVars);
			
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.DistributionDetailComponent_944239_onChange1_();
                  resolve();
                });
          })



        
        KuikaAppManager.hideSpinner(this);
        return isErrorOccurred;
    }
		DistributionDetailComponent_944239_onChange1_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }

				
				stateVars.dataSource_548003 = stateVars.TM_GetDistributionItemDetailsByHeader ?? this.state.TM_GetDistributionItemDetailsByHeader;

		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

            
            return isErrorOccurred;
        }




		DistributionDetailComponent_577520_onClick = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
KuikaAppManager.showSpinner(this);

				stateVars.SetValueOf = await ReactSystemFunctions.setValueOf(this, ReactSystemFunctions.convertToTypeByName("distributiondetail_431329_value", "string"), "", null, "BrandName");
				stateVars.SetValueOf = await ReactSystemFunctions.setValueOf(this, ReactSystemFunctions.convertToTypeByName("distributiondetail_179075_value", "string"), "", null, false);
				stateVars.SetValueOf = await ReactSystemFunctions.setValueOf(this, ReactSystemFunctions.convertToTypeByName("distributiondetail_780497_value", "string"), "", null, false);
				stateVars.SetValueOf = await ReactSystemFunctions.setValueOf(this, ReactSystemFunctions.convertToTypeByName("distributiondetail_176495_value", "string"), "", null, false);
				stateVars.SetValueOf = await ReactSystemFunctions.setValueOf(this, ReactSystemFunctions.convertToTypeByName("distributiondetail_944239_value", "string"), "", null, false);

		this.props.form?.setFieldsValue(formVars);
		
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.DistributionDetailComponent_577520_onClick1_();
                  resolve();
                });
          })

            
            return isErrorOccurred;
        }
    DistributionDetailComponent_577520_onClick1_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
		KuikaAppManager.increaseServerRequestCount();

        let localVar = {
				DistributionHeaderId_0: ReactSystemFunctions.convertToTypeByName(this.props.screenInputs.HeaderId ?? this.props.screenInputs.headerid, "Guid"),
				Brand_0: ReactSystemFunctions.convertToTypeByName("", "string"),
				ProductCode_0: ReactSystemFunctions.convertToTypeByName("", "string"),
				ProductName_0: ReactSystemFunctions.convertToTypeByName("", "string"),
				RMCCode_0: ReactSystemFunctions.convertToTypeByName("", "string"),
				CustomerName_0: ReactSystemFunctions.convertToTypeByName("", "string")
        }

		
        if (true) {
        KuikaAppManager.showSpinner(this);
        }
        let result = await KuikaAppManager.ApiRequest(this, "DistributionDetail/DistributionDetailComponent_577520_onClick1_", localVar)
        if (!KMainFunctions.IsResStatus2XX(result)) return true;

			stateVars.TM_GetDistributionItemDetailsByHeader = result?.data.tM_GetDistributionItemDetailsByHeader;
			
			this.props.form?.setFieldsValue(formVars);
			
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.DistributionDetailComponent_577520_onClick2_();
                  resolve();
                });
          })



        
        KuikaAppManager.hideSpinner(this);
        return isErrorOccurred;
    }
		DistributionDetailComponent_577520_onClick2_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }

				
				stateVars.dataSource_548003 = stateVars.TM_GetDistributionItemDetailsByHeader ?? this.state.TM_GetDistributionItemDetailsByHeader;

		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

            
            return isErrorOccurred;
        }





    DistributionDetailComponent_2632_onClick = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
		KuikaAppManager.increaseServerRequestCount();

        let localVar = {
				DistributionHeaderId_0: ReactSystemFunctions.convertToTypeByName(this.props.screenInputs.HeaderId ?? this.props.screenInputs.headerid, "Guid")
        }

		KuikaAppManager.showSpinner(this);
		
        if (true) {
        KuikaAppManager.showSpinner(this);
        }
        let result = await KuikaAppManager.ApiRequest(this, "DistributionDetail/DistributionDetailComponent_2632_onClick", localVar)
        if (!KMainFunctions.IsResStatus2XX(result)) return true;

			stateVars.TM_GiveDistributionOrder = result?.data.tM_GiveDistributionOrder;
			this.props.form?.setFieldsValue(formVars);
			
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.DistributionDetailComponent_2632_onClick1_();
                  resolve();
                });
          })



        
        KuikaAppManager.hideSpinner(this);
        return isErrorOccurred;
    }
		DistributionDetailComponent_2632_onClick1_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }

				stateVars.Notify = await ReactSystemFunctions.notify(this, ReactSystemFunctions.toString(this, (stateVars.TM_GiveDistributionOrder !== undefined ? (stateVars.TM_GiveDistributionOrder?.length > 0 ? stateVars.TM_GiveDistributionOrder[0].message : null) : (this.state.TM_GiveDistributionOrder?.length > 0 ? this.state.TM_GiveDistributionOrder[0].message : null))), ReactSystemFunctions.convertToTypeByName("default", "string"), ReactSystemFunctions.convertToTypeByName("top-center", "string"), 3, ReactSystemFunctions.convertToTypeByName("", "string"), ReactSystemFunctions.convertToTypeByName("", "string"), 0);
const __currentPath = (window.location.hash ? window.location.hash.replace(/^#/, '').split('?')[0] : window.location.pathname.split('?')[0]).toLowerCase();
if (__currentPath !== "/importlist") {
  this.context.setMasterPageInitLoaded(false);
  this.context.setMasterPageRecurringLoaded(false);
  this.context.setShouldTriggerPageInit(true);
}
					KuikaAppManager.prepareForNavigation();

				stateVars.NAVIGATE = await ReactSystemFunctions.navigate(this, undefined, "DistributionDetail", "ImportList", "", "currentPage", null, null, null, null, null, null, true, false);

		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

            
            return isErrorOccurred;
        }






    async callCallbackFunction(diId: number, isFromMaster: boolean = false) {
        let isErrorOccurred = false;
		let pageInitCallerNavDiIDs = [, , , , ] as number[];
		if (isFromMaster || pageInitCallerNavDiIDs.indexOf(diId) > -1) {
			await this.DistributionDetailPageInit();
		}

    }


}
