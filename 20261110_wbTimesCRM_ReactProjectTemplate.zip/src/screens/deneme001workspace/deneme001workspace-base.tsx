import React from "react";
import Axios, { AxiosResponse } from "axios";
import { KuikaAppManager } from "../../shared/utilty/kuika-app-manager";
import { ReactSystemFunctions } from "../../shared/utilty/react-system-functions";
import { KNavigator } from "../../shared/hoc/with-history";
import { KContext } from "../../shared/hoc/with-context";
import { useLocation } from "react-router-dom";
import { FormInstance } from "antd/es/form";
import { Guid } from "guid-typescript";
import Swal from "sweetalert2";
import { KMainFunctions } from "../../shared/utilty/main-functions";
import moment from "moment";
import { IValidationData } from "../../models/dto/validation-data";
import { IStripePayment } from "../../models/dto/stripe-payment";
import { IUserInfoDto } from "../../models/dto/user-info.dto";
import { UserService } from "../../services/user-service";
import { kuikaCoreWasmBridgeService } from "../../services/_singletons";
import _ from "lodash";
import mqtt, { MqttClient } from "mqtt";
import { IMqttResult } from "../../models/dto/mqtt.dto";


declare let window: any;

export interface IDeneme001Workspace_ScreenProps {
  navigator: KNavigator;
  form: FormInstance<any>;
  googleLogin: any;
  screenInputs: any;
  context: KContext;
  initialValues: any;
  children: any;
}

export interface IDeneme001Workspace_ScreenState {
    isSpinnerVisible: boolean;
    isPageVisible: boolean;
	isLeftMenuVisible: boolean;
    spinnerCount: number;
    selectedLanguage: string;
    isPageInitLoaded: false;
    isPageRecurringLoaded: false;

}

export class Deneme001Workspace_ScreenBase extends React.PureComponent<IDeneme001Workspace_ScreenProps, any> {


    ml=[{"Id":"d5a61d2b-bd60-485f-86e2-661e9ed4e486","Name":"en_US","ShortName":"English","IsDefault":true,"LanguagePhrases":[]},{"Id":"7dabe56f-b215-440c-9256-7d0f7a7684bc","Name":"FixedValues","ShortName":"FixedValues","LanguagePhrases":[{"Id":565244,"PropertyName":"value","Value":"Mağazama Gelen Talepler"},{"Id":145284,"PropertyName":"value","Value":"Diğer mağazaların sizin mağazanızdan istediği ürünleri değerlendirin."},{"Id":59350,"PropertyName":"value","Value":"Onay Bekleyen"},{"Id":627875,"PropertyName":"value","Value":"0"},{"Id":251309,"PropertyName":"value","Value":"Transfer Sürecinde"},{"Id":775774,"PropertyName":"value","Value":"0"},{"Id":856581,"PropertyName":"value","Value":"Bugün Gelen"},{"Id":288507,"PropertyName":"value","Value":"0"},{"Id":414163,"PropertyName":"value","Value":"Mağazamdan Giden Talepler"},{"Id":517306,"PropertyName":"value","Value":"Mağazanızın diğer mağazalardan istediği ürünlerin durumunu takip edin."},{"Id":720346,"PropertyName":"value","Value":"Bekleyen"},{"Id":183242,"PropertyName":"value","Value":"0"},{"Id":553570,"PropertyName":"value","Value":"Onaylanan"},{"Id":110239,"PropertyName":"value","Value":"0"},{"Id":218129,"PropertyName":"value","Value":"Tamamlanan"},{"Id":986031,"PropertyName":"value","Value":"0"},{"Id":561747,"PropertyName":"value","Value":"Tüm Transfer Talepleri"},{"Id":762313,"PropertyName":"value","Value":"Yetkiniz kapsamındaki mağazalar arası tüm transfer taleplerini görüntüleyin."},{"Id":266726,"PropertyName":"value","Value":"Toplam Açık"},{"Id":891062,"PropertyName":"value","Value":"0"},{"Id":74921,"PropertyName":"value","Value":"Transferde"},{"Id":572465,"PropertyName":"value","Value":"0"},{"Id":711996,"PropertyName":"value","Value":"Geciken"},{"Id":772986,"PropertyName":"value","Value":"0"}]}]
    defaultML = "en_US"
    
    screenHash = ""
    


    constructor(props) {
        super(props);


        this.state = {
            isSpinnerVisible: false,
            isPageVisible: false,
            isLeftMenuVisible: false,
            spinnerCount: 0,
            selectedLanguage: "",
            isPageInitLoaded: false,
            isPageRecurringLoaded: false,
            
        }

        this.state.isPageVisible = true;
        
    }

    async componentDidMount() {

        if (KuikaAppManager.isPageInitPrevented()) {
            KuikaAppManager.calculateAndSetBodyHeight("deneme001workspace", "");
            return;
        }
        
        
        ReactSystemFunctions.validateToken()
        this.fillFormInitValues();
        if (true){
            
        }
        
        
        
        KuikaAppManager.calculateAndSetBodyHeight("deneme001workspace", "");

        if (ReactSystemFunctions.getIsMicroApp() === false) {
           window.parentScreen = this;
        }
    }

    componentWillUnmount() {
        
        
        

        if (ReactSystemFunctions.getIsMicroApp() === false) {
           window.parentScreen = null;
        }
    }

    

        
    componentDidUpdate= async (prevProps, prevState) => {
		KuikaAppManager.calculateAndSetBodyHeight("deneme001workspace", ""    );
        if (prevProps?.location?.search !== (this.props as any)?.location?.search) {
			
		}

        

        if (ReactSystemFunctions.getIsMicroApp() === false) {
            for (const key in prevState) {
                if (key.startsWith('NavVisible') && prevState[key] === true && this.state[key] === false) {
                    window.parentScreen = this;
                    break;
                }
            }
        }
	}

    fillFormInitValues() {
        this.props.form?.setFieldsValue({
});

    }

      setPageInitLoaded = (value: boolean) => {
        this.setState({ isPageInitLoaded: value });
      }

      setPageRecurringLoaded = (value: boolean) => {
        this.setState({ isPageRecurringLoaded: value });
      }

      clearFieldValidation = (changedValues: any) => {
        const fieldName = Object.keys(changedValues)[0];
        if (fieldName) {
          this.props.form?.setFields([
            {
              name: fieldName,
              errors: []
            }
          ]);
        }
      };

      




    async callCallbackFunction(diId: number, isFromMaster: boolean = false) {
        let isErrorOccurred = false;

    }


}
