import React from "react";
import Axios, { AxiosResponse } from "axios";
import { KuikaAppManager } from "../../shared/utilty/kuika-app-manager";
import { ReactSystemFunctions } from "../../shared/utilty/react-system-functions";
import { KNavigator } from "../../shared/hoc/with-history";
import { KContext } from "../../shared/hoc/with-context";
import { useLocation } from "react-router-dom";
import { FormInstance } from "antd/es/form";
import { Guid } from "guid-typescript";
import Swal from "sweetalert2";
import { KMainFunctions } from "../../shared/utilty/main-functions";
import moment from "moment";
import { IValidationData } from "../../models/dto/validation-data";
import { IStripePayment } from "../../models/dto/stripe-payment";
import { IUserInfoDto } from "../../models/dto/user-info.dto";
import { UserService } from "../../services/user-service";
import { kuikaCoreWasmBridgeService } from "../../services/_singletons";
import _ from "lodash";
import mqtt, { MqttClient } from "mqtt";
import { IMqttResult } from "../../models/dto/mqtt.dto";
import { MasterScreen_ScreenContext } from "../masterscreen/masterscreen-context";

declare let window: any;

export interface IApprovedLeadList_ScreenProps {
  navigator: KNavigator;
  form: FormInstance<any>;
  googleLogin: any;
  screenInputs: any;
  context: KContext;
  initialValues: any;
  children: any;
}

export interface IApprovedLeadList_ScreenState {
    isSpinnerVisible: boolean;
    isPageVisible: boolean;
	isLeftMenuVisible: boolean;
    spinnerCount: number;
    selectedLanguage: string;
    isPageInitLoaded: false;
    isPageRecurringLoaded: false;
	TM_GetApprovedLeads: any[];
	TM_GetApprovedLeads_dummy: any[];
	TM_GetApprovedLeadStores: any[];
	TM_GetApprovedLeadStores_dummy: any[];
	TM_GetApprovedLeadCategories: any[];
	TM_GetApprovedLeadCategories_dummy: any[];
	TMTotalStoreApprovedLead: any[];
	TMTotalStoreApprovedLead_dummy: any[];
	TMGetRefApproved: any[];
	TMGetRefApproved_dummy: any[];
	ExportExcel: any;
	ExportExcel_dummy: any;
	Notify: boolean;
	Notify_dummy: boolean;
	ChangeEnabledOf: any;
	ChangeEnabledOf_dummy: any;
	ChangeVisibilityOf: string;
	ChangeVisibilityOf_dummy: string;
	SetValueOf: any;
	SetValueOf_dummy: any;
	isComp896586Visible: 'visible' | 'hidden';
	isComp654433Visible: 'visible' | 'hidden';
	isComp25615Visible: 'visible' | 'hidden';
	isComp466228Visible: 'visible' | 'hidden';
	isComp226426Visible: 'visible' | 'hidden';
	isComp328471Visible: 'visible' | 'hidden';
	isComp758913Visible: 'visible' | 'hidden';
	isComp240269Visible: 'visible' | 'hidden';
	isComp746483Visible: 'visible' | 'hidden';
	isComp887947Visible: 'visible' | 'hidden';
	isComp505603Visible: 'visible' | 'hidden';
	isComp704832Visible: 'visible' | 'hidden';
	isComp51772Visible: 'visible' | 'hidden';
	isComp985567Visible: 'visible' | 'hidden';
	isComp51248Enabled: 'enabled' | 'disabled';
	isComp886431Enabled: 'enabled' | 'disabled';
	isComp713966Enabled: 'enabled' | 'disabled';
	isComp140260Enabled: 'enabled' | 'disabled';
	isComp198119Enabled: 'enabled' | 'disabled';
	isComp329182Enabled: 'enabled' | 'disabled';

}

export class ApprovedLeadList_ScreenBase extends React.PureComponent<IApprovedLeadList_ScreenProps, any> {
    static contextType = MasterScreen_ScreenContext;
    declare context: React.ContextType<typeof MasterScreen_ScreenContext>;
	approvedleadlist_713966_value_kuikaSelectBoxRef: React.RefObject<any>;
	approvedleadlist_270363_value_kuikaDateRef: React.RefObject<any>;
	approvedleadlist_334933_value_kuikaDateRef: React.RefObject<any>;
	approvedleadlist_3547_value_kuikaTableRef: React.RefObject<any>;
	approvedleadlist_633056_value_kuikaTableRef: React.RefObject<any>;
    ml=[{"Id":"d5a61d2b-bd60-485f-86e2-661e9ed4e486","Name":"en_US","ShortName":"English","IsDefault":true,"LanguagePhrases":[]},{"Id":"5861980f-81ce-43f1-9c27-2aa85fae70c6","Name":"FixedValues","ShortName":"FixedValues","LanguagePhrases":[{"Id":551455,"PropertyName":"value","Value":"Onaylananan Talepler"},{"Id":943270,"PropertyName":"value","Value":"Onaylanan kayıtları görüntüleyin."},{"Id":205690,"PropertyName":"value","Value":"Talep Listesi"},{"Id":209741,"PropertyName":"label","Value":"Export Excel"},{"Id":728992,"PropertyName":"value","Value":"Ürün ve Mağaza Bazında Grupla"},{"Id":850238,"PropertyName":"header","Value":"Filtreler"},{"Id":657917,"PropertyName":"value","Value":"Mağaza"},{"Id":545890,"PropertyName":"value","Value":"Kategori"},{"Id":326691,"PropertyName":"value","Value":"Ürün Adı"},{"Id":173919,"PropertyName":"value","Value":"Talep Tarihine Göre Sırala"},{"Id":244436,"PropertyName":"value","Value":"Müşteri Adı-Soyadı"},{"Id":198119,"PropertyName":"placeholder","Value":" "},{"Id":380401,"PropertyName":"value","Value":"Müşteri Referansları"},{"Id":329182,"PropertyName":"placeholder","Value":"Müşteri Referansları"},{"Id":37083,"PropertyName":"value","Value":"Tahmini Teslimat Zaman Filtresi"},{"Id":374163,"PropertyName":"value","Value":"Başlangıç"},{"Id":270363,"PropertyName":"placeholder","Value":"Tahmini Teslimat Başlangıç"},{"Id":481394,"PropertyName":"value","Value":"Bitiş"},{"Id":334933,"PropertyName":"placeholder","Value":"Tahmini Teslimat Bitiş"},{"Id":893327,"PropertyName":"label","Value":"Zaman Filtresini Uygula"},{"Id":134501,"PropertyName":"label","Value":"Filtreleri Temizle"},{"Id":287364,"PropertyName":"value","Value":"Talep Numarasına Göre Ara"},{"Id":531862,"PropertyName":"placeholder","Value":"Talep Numarası Giriniz"},{"Id":723841,"PropertyName":"title","Value":"Talep Tarihi"},{"Id":337457,"PropertyName":"value","Value":"[datafield:olusturmatarihi]"},{"Id":850420,"PropertyName":"title","Value":"Talep Numarası"},{"Id":934159,"PropertyName":"value","Value":"[datafield:leadcode]"},{"Id":616377,"PropertyName":"title","Value":"Mağaza"},{"Id":899217,"PropertyName":"value","Value":"[datafield:magazaadi]"},{"Id":298838,"PropertyName":"title","Value":"Kategori"},{"Id":226426,"PropertyName":"value","Value":"[datafield:kategoriadi]"},{"Id":328471,"PropertyName":"value","Value":"[datafield:kategoriadi]"},{"Id":758913,"PropertyName":"value","Value":"[datafield:kategoriadi]"},{"Id":37521,"PropertyName":"title","Value":"Ürün Adı"},{"Id":47950,"PropertyName":"value","Value":"[datafield:urunadi]"},{"Id":641023,"PropertyName":"title","Value":"Model"},{"Id":234892,"PropertyName":"value","Value":"[datafield:referans]"},{"Id":421051,"PropertyName":"title","Value":"Kadran"},{"Id":797615,"PropertyName":"value","Value":"[datafield:kadran]"},{"Id":980510,"PropertyName":"title","Value":"Bilezik"},{"Id":524325,"PropertyName":"value","Value":"[datafield:bilezik]"},{"Id":79159,"PropertyName":"title","Value":"Müşteri"},{"Id":941802,"PropertyName":"value","Value":"[datafield:musteriadisoyadi]"},{"Id":689605,"PropertyName":"title","Value":"Müşteri Referansı"},{"Id":18630,"PropertyName":"value","Value":"[datafield:referansadisoyadi]"},{"Id":240269,"PropertyName":"value","Value":"-"},{"Id":563296,"PropertyName":"title","Value":"Takip Durumu"},{"Id":746483,"PropertyName":"value","Value":"[datafield:takipdurumu]"},{"Id":887947,"PropertyName":"value","Value":"[datafield:takipdurumu]"},{"Id":688361,"PropertyName":"title","Value":"Sonraki Adım"},{"Id":488433,"PropertyName":"value","Value":"[datafield:sonrakiadim]"},{"Id":139632,"PropertyName":"title","Value":"Tahmini Teslimat"},{"Id":312740,"PropertyName":"value","Value":"[datafield:tahminiteslimattarihi]"},{"Id":361489,"PropertyName":"title","Value":"Satış Danışmanı "},{"Id":252762,"PropertyName":"value","Value":"[datafield:olusturankullanici]"},{"Id":517264,"PropertyName":"header","Value":"Filtreler"},{"Id":194806,"PropertyName":"value","Value":"Mağaza"},{"Id":527526,"PropertyName":"value","Value":"Kategori"},{"Id":976279,"PropertyName":"value","Value":"Ürün Adı"},{"Id":964973,"PropertyName":"value","Value":"Referans"},{"Id":19472,"PropertyName":"value","Value":"Kadran"},{"Id":487400,"PropertyName":"value","Value":"Bilezik"},{"Id":228982,"PropertyName":"label","Value":"Filtreleri Temizle"},{"Id":465433,"PropertyName":"title","Value":"Mağaza"},{"Id":402662,"PropertyName":"value","Value":"[datafield:magazaadi]"},{"Id":356454,"PropertyName":"title","Value":"Ürün Kodu"},{"Id":423795,"PropertyName":"value","Value":"[datafield:urunkodu]"},{"Id":837898,"PropertyName":"title","Value":"Kategori"},{"Id":704832,"PropertyName":"value","Value":"[datafield:kategori]"},{"Id":51772,"PropertyName":"value","Value":"[datafield:kategori]"},{"Id":985567,"PropertyName":"value","Value":"[datafield:kategori]"},{"Id":832233,"PropertyName":"title","Value":"Ürün Adı"},{"Id":859294,"PropertyName":"value","Value":"[datafield:urunadi]"},{"Id":256663,"PropertyName":"title","Value":"Model"},{"Id":144970,"PropertyName":"value","Value":"[datafield:referans]"},{"Id":45996,"PropertyName":"title","Value":"Kadran"},{"Id":972685,"PropertyName":"value","Value":"[datafield:kadran]"},{"Id":416876,"PropertyName":"title","Value":"Bilezik"},{"Id":359481,"PropertyName":"value","Value":"[datafield:bilezik]"},{"Id":431170,"PropertyName":"title","Value":"Talep Adedi"},{"Id":247267,"PropertyName":"value","Value":"[datafield:adedi]"}]}]
    defaultML = "en_US"
    
    screenHash = ""
    

    private _prevMasterPageInitLoaded: boolean = false;
    private _prevMasterPageRecurringLoaded: boolean = false;
    private _prevShouldTriggerPageInit: boolean = false;
    constructor(props) {
        super(props);
		this.approvedleadlist_140260_value_kuikaTextInputRef = React.createRef();
		this.approvedleadlist_713966_value_kuikaSelectBoxRef = React.createRef();
		this.approvedleadlist_198119_value_kuikaTextInputRef = React.createRef();
		this.approvedleadlist_270363_value_kuikaDateRef = React.createRef();
		this.approvedleadlist_334933_value_kuikaDateRef = React.createRef();
		this.approvedleadlist_531862_value_kuikaTextInputRef = React.createRef();
		this.approvedleadlist_3547_value_kuikaTableRef = React.createRef();
		this.approvedleadlist_84425_value_kuikaTextInputRef = React.createRef();
		this.approvedleadlist_847615_value_kuikaTextInputRef = React.createRef();
		this.approvedleadlist_999251_value_kuikaTextInputRef = React.createRef();
		this.approvedleadlist_79693_value_kuikaTextInputRef = React.createRef();
		this.approvedleadlist_633056_value_kuikaTableRef = React.createRef();

        this.state = {
            isSpinnerVisible: false,
            isPageVisible: false,
            isLeftMenuVisible: false,
            spinnerCount: 0,
            selectedLanguage: "",
            isPageInitLoaded: false,
            isPageRecurringLoaded: false,
            	        TM_GetApprovedLeads: [],
	        TM_GetApprovedLeadStores: [],
	        TM_GetApprovedLeadCategories: [],
	        TMTotalStoreApprovedLead: [],
	        TMGetRefApproved: [],
	        ExportExcel: "",
	        Notify: false,
	        ChangeEnabledOf: "",
	        ChangeVisibilityOf: "",
	        SetValueOf: "",
	        dataSource_713966: [{"key":"0","text":"⬆️ Eski → Yeni"},{"key":"1","text":"⬇️ Yeni → Eski"}],
	        isComp896586Visible: 'visible',
	        isComp654433Visible: 'hidden',
	        isComp25615Visible: 'hidden',
	        isComp466228Visible: 'hidden',
	        isComp226426Visible: 'hidden',
	        isComp328471Visible: 'hidden',
	        isComp758913Visible: 'hidden',
	        isComp240269Visible: 'hidden',
	        isComp746483Visible: 'hidden',
	        isComp887947Visible: 'hidden',
	        isComp505603Visible: 'hidden',
	        isComp704832Visible: 'hidden',
	        isComp51772Visible: 'hidden',
	        isComp985567Visible: 'hidden',
	        isComp51248Enabled: 'enabled',
	        isComp886431Enabled: 'enabled',
	        isComp713966Enabled: 'enabled',
	        isComp140260Enabled: 'enabled',
	        isComp198119Enabled: 'enabled',
	        isComp329182Enabled: 'enabled',

        }

        this.state.isPageVisible = true;
        
    }

    async componentDidMount() {

        if (KuikaAppManager.isPageInitPrevented()) {
            KuikaAppManager.calculateAndSetBodyHeight("approvedleadlist", "masterscreen_screen");
            return;
        }
        this.context.registerCallbackFunction(this.callCallbackFunction.bind(this));
        
        ReactSystemFunctions.validateToken()
        this.fillFormInitValues();
        if (false){
            await this.ApprovedLeadListPageInit();
        } else if (this.context?.isMasterPageInitLoaded) { this._prevMasterPageInitLoaded = true; await this.ApprovedLeadListPageInit(); }
        
        
        
        KuikaAppManager.calculateAndSetBodyHeight("approvedleadlist", "masterscreen_screen");

        if (ReactSystemFunctions.getIsMicroApp() === false) {
           window.parentScreen = this;
        }
    }

    componentWillUnmount() {
        
        
        

        if (ReactSystemFunctions.getIsMicroApp() === false) {
           window.parentScreen = null;
        }
    }

    

        
    componentDidUpdate= async (prevProps, prevState) => {
		KuikaAppManager.calculateAndSetBodyHeight("approvedleadlist", "masterscreen_screen"    );
        if (prevProps?.location?.search !== (this.props as any)?.location?.search) {
			await this.ApprovedLeadListPageInit();
		}

        		if (this._prevMasterPageInitLoaded !== this.context.isMasterPageInitLoaded && this.context.isMasterPageInitLoaded === true) {this._prevMasterPageInitLoaded = this.context.isMasterPageInitLoaded;await this.ApprovedLeadListPageInit()}


        if (ReactSystemFunctions.getIsMicroApp() === false) {
            for (const key in prevState) {
                if (key.startsWith('NavVisible') && prevState[key] === true && this.state[key] === false) {
                    window.parentScreen = this;
                    break;
                }
            }
        }
	}

    fillFormInitValues() {
        this.props.form?.setFieldsValue({
approvedleadlist_235062_checked: false
});

    }

      setPageInitLoaded = (value: boolean) => {
        this.setState({ isPageInitLoaded: value });
      }

      setPageRecurringLoaded = (value: boolean) => {
        this.setState({ isPageRecurringLoaded: value });
      }

      clearFieldValidation = (changedValues: any) => {
        const fieldName = Object.keys(changedValues)[0];
        if (fieldName) {
          this.props.form?.setFields([
            {
              name: fieldName,
              errors: []
            }
          ]);
        }
      };

      

    ApprovedLeadListPageInit = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


	if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }

        let localVar = {
			StoreId_0: ReactSystemFunctions.convertToTypeByName(null, "string"),
			CategoryName_0: ReactSystemFunctions.convertToTypeByName(null, "string"),
			ProductName_0: ReactSystemFunctions.convertToTypeByName(null, "string"),
			Musteri_0: ReactSystemFunctions.convertToTypeByName(null, "string"),
			EstimatedDateStart_0: ReactSystemFunctions.convertToTypeByName(null, "Date"),
			EstimatedDateEnd_0: ReactSystemFunctions.convertToTypeByName(null, "Date"),
			LeadCode_0: ReactSystemFunctions.convertToTypeByName(null, "string"),
			ReferenceId_0: ReactSystemFunctions.convertToTypeByName(null, "string"),
			OrderType_0: ReactSystemFunctions.convertToTypeByName(0, "number"),
			StoreId_3: ReactSystemFunctions.convertToTypeByName(null, "string"),
			CategoryName_3: ReactSystemFunctions.convertToTypeByName(null, "string"),
			ProductName_3: ReactSystemFunctions.convertToTypeByName(null, "string"),
			Referance_3: ReactSystemFunctions.convertToTypeByName(null, "string"),
			Dial_3: ReactSystemFunctions.convertToTypeByName(null, "string"),
			Bracelet_3: ReactSystemFunctions.convertToTypeByName(null, "string"),
			StoreId_4: ReactSystemFunctions.convertToTypeByName(null, "string"),
			CategoryName_4: ReactSystemFunctions.convertToTypeByName(null, "string"),
			ProductName_4: ReactSystemFunctions.convertToTypeByName(null, "string"),
			EstimatedDateStart_4: ReactSystemFunctions.convertToTypeByName(null, "Date"),
			EstimatedDateEnd_4: ReactSystemFunctions.convertToTypeByName(null, "Date")
        }

	KuikaAppManager.showSpinner(this);
	
        if (true) {
        KuikaAppManager.showSpinner(this);
        }
        let result = await KuikaAppManager.ApiRequest(this, "ApprovedLeadList/ApprovedLeadListPageInit", localVar)
        if (!KMainFunctions.IsResStatus2XX(result)) return true;

		stateVars.TM_GetApprovedLeads = result?.data.tM_GetApprovedLeads;
		
		stateVars.TM_GetApprovedLeadStores = result?.data.tM_GetApprovedLeadStores;
		
		formVars.approvedleadlist_51248_options = stateVars.TM_GetApprovedLeadStores;
		
		formVars.approvedleadlist_463912_options = stateVars.TM_GetApprovedLeadStores;
		stateVars.TM_GetApprovedLeadCategories = result?.data.tM_GetApprovedLeadCategories;
		
		formVars.approvedleadlist_886431_options = stateVars.TM_GetApprovedLeadCategories;
		
		formVars.approvedleadlist_198382_options = stateVars.TM_GetApprovedLeadCategories;
		stateVars.TMTotalStoreApprovedLead = result?.data.tmTotalStoreApprovedLead;
		
		stateVars.TMGetRefApproved = result?.data.tmGetRefApproved;
		
		formVars.approvedleadlist_329182_options = stateVars.TMGetRefApproved;
		this.props.form?.setFieldsValue(formVars);
		
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.ApprovedLeadListPageInit1_();
                  resolve();
                });
          })



        
        KuikaAppManager.hideSpinner(this);
        return isErrorOccurred;
    }
	ApprovedLeadListPageInit1_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


	if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }

			stateVars.isComp25615Visible = ((ReactSystemFunctions.isNotEqualTo(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "approvedleadlist_235062_checked", "checked", "", "", "")), ReactSystemFunctions.convertToTypeByName("True", "string"))) === true ? "visible" : "hidden")
			
			stateVars.dataSource_51248 = stateVars.TM_GetApprovedLeadStores ?? this.state.TM_GetApprovedLeadStores;
			stateVars.dataSource_51248 = stateVars.TM_GetApprovedLeadStores ?? this.state.TM_GetApprovedLeadStores;
			
			stateVars.dataSource_886431 = stateVars.TM_GetApprovedLeadCategories ?? this.state.TM_GetApprovedLeadCategories;
			stateVars.dataSource_886431 = stateVars.TM_GetApprovedLeadCategories ?? this.state.TM_GetApprovedLeadCategories;
			
			stateVars.dataSource_329182 = stateVars.TMGetRefApproved ?? this.state.TMGetRefApproved;
			stateVars.dataSource_329182 = stateVars.TMGetRefApproved ?? this.state.TMGetRefApproved;
			ReactSystemFunctions.setValueOf(this, "approvedleadlist_334933_value", ReactSystemFunctions.value(this, "approvedleadlist_270363_value", "value"), "disablebeforedate");

			stateVars.isComp466228Visible = ((ReactSystemFunctions.isNotEqualTo(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "approvedleadlist_235062_checked", "checked", "", "", "")), ReactSystemFunctions.convertToTypeByName("True", "string"))) === true ? "visible" : "hidden")
			
			stateVars.dataSource_3547 = stateVars.TM_GetApprovedLeads ?? this.state.TM_GetApprovedLeads;
			formVars.approvedleadlist_899217_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetApprovedLeads !== undefined ? (stateVars.TM_GetApprovedLeads?.length > 0 ? stateVars.TM_GetApprovedLeads[0].magazaAdi : null) : (this.state.TM_GetApprovedLeads?.length > 0 ? this.state.TM_GetApprovedLeads[0].magazaAdi : null)));

			formVars.approvedleadlist_226426_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetApprovedLeads !== undefined ? (stateVars.TM_GetApprovedLeads?.length > 0 ? stateVars.TM_GetApprovedLeads[0].kategoriAdi : null) : (this.state.TM_GetApprovedLeads?.length > 0 ? this.state.TM_GetApprovedLeads[0].kategoriAdi : null)));

			stateVars.isComp226426Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, "approvedleadlist_3547_value", "kategoriAdi"), ReactSystemFunctions.convertToTypeByName("Kategori 3", "string"))) === true ? "visible" : "hidden")
			formVars.approvedleadlist_328471_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetApprovedLeads !== undefined ? (stateVars.TM_GetApprovedLeads?.length > 0 ? stateVars.TM_GetApprovedLeads[0].kategoriAdi : null) : (this.state.TM_GetApprovedLeads?.length > 0 ? this.state.TM_GetApprovedLeads[0].kategoriAdi : null)));

			stateVars.isComp328471Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, "approvedleadlist_3547_value", "kategoriAdi"), ReactSystemFunctions.convertToTypeByName("Kategori 2", "string"))) === true ? "visible" : "hidden")
			formVars.approvedleadlist_758913_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetApprovedLeads !== undefined ? (stateVars.TM_GetApprovedLeads?.length > 0 ? stateVars.TM_GetApprovedLeads[0].kategoriAdi : null) : (this.state.TM_GetApprovedLeads?.length > 0 ? this.state.TM_GetApprovedLeads[0].kategoriAdi : null)));

			stateVars.isComp758913Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, "approvedleadlist_3547_value", "kategoriAdi"), ReactSystemFunctions.convertToTypeByName("Kategori 1", "string"))) === true ? "visible" : "hidden")
			formVars.approvedleadlist_47950_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetApprovedLeads !== undefined ? (stateVars.TM_GetApprovedLeads?.length > 0 ? stateVars.TM_GetApprovedLeads[0].urunAdi : null) : (this.state.TM_GetApprovedLeads?.length > 0 ? this.state.TM_GetApprovedLeads[0].urunAdi : null)));

			formVars.approvedleadlist_941802_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetApprovedLeads !== undefined ? (stateVars.TM_GetApprovedLeads?.length > 0 ? stateVars.TM_GetApprovedLeads[0].musteriAdiSoyadi : null) : (this.state.TM_GetApprovedLeads?.length > 0 ? this.state.TM_GetApprovedLeads[0].musteriAdiSoyadi : null)));

			formVars.approvedleadlist_18630_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetApprovedLeads !== undefined ? (stateVars.TM_GetApprovedLeads?.length > 0 ? stateVars.TM_GetApprovedLeads[0].referansAdiSoyadi : null) : (this.state.TM_GetApprovedLeads?.length > 0 ? this.state.TM_GetApprovedLeads[0].referansAdiSoyadi : null)));

			stateVars.isComp240269Visible = ((ReactSystemFunctions.isEmpty(ReactSystemFunctions.value(this, "approvedleadlist_3547_value", "referansAdiSoyadi"), ReactSystemFunctions.convertToTypeByName("True", "string"))) === true ? "visible" : "hidden")
			formVars.approvedleadlist_746483_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetApprovedLeads !== undefined ? (stateVars.TM_GetApprovedLeads?.length > 0 ? stateVars.TM_GetApprovedLeads[0].takipDurumu : null) : (this.state.TM_GetApprovedLeads?.length > 0 ? this.state.TM_GetApprovedLeads[0].takipDurumu : null)));

			stateVars.isComp746483Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, "approvedleadlist_3547_value", "takipDurumu"), ReactSystemFunctions.convertToTypeByName("2. Takip", "string"))) === true ? "visible" : "hidden")
			formVars.approvedleadlist_887947_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetApprovedLeads !== undefined ? (stateVars.TM_GetApprovedLeads?.length > 0 ? stateVars.TM_GetApprovedLeads[0].takipDurumu : null) : (this.state.TM_GetApprovedLeads?.length > 0 ? this.state.TM_GetApprovedLeads[0].takipDurumu : null)));

			stateVars.isComp887947Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, "approvedleadlist_3547_value", "takipDurumu"), ReactSystemFunctions.convertToTypeByName("Takip ediliyor", "string"))) === true ? "visible" : "hidden")
			formVars.approvedleadlist_488433_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetApprovedLeads !== undefined ? (stateVars.TM_GetApprovedLeads?.length > 0 ? stateVars.TM_GetApprovedLeads[0].sonrakiAdim : null) : (this.state.TM_GetApprovedLeads?.length > 0 ? this.state.TM_GetApprovedLeads[0].sonrakiAdim : null)));

			formVars.approvedleadlist_312740_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetApprovedLeads !== undefined ? (stateVars.TM_GetApprovedLeads?.length > 0 ? stateVars.TM_GetApprovedLeads[0].tahminiTeslimatTarihi : null) : (this.state.TM_GetApprovedLeads?.length > 0 ? this.state.TM_GetApprovedLeads[0].tahminiTeslimatTarihi : null)));

			formVars.approvedleadlist_252762_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetApprovedLeads !== undefined ? (stateVars.TM_GetApprovedLeads?.length > 0 ? stateVars.TM_GetApprovedLeads[0].olusturanKullanici : null) : (this.state.TM_GetApprovedLeads?.length > 0 ? this.state.TM_GetApprovedLeads[0].olusturanKullanici : null)));

			stateVars.isComp505603Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "approvedleadlist_235062_checked", "checked", "", "", "")), ReactSystemFunctions.convertToTypeByName("True", "string"))) === true ? "visible" : "hidden")
			
			stateVars.dataSource_463912 = stateVars.TM_GetApprovedLeadStores ?? this.state.TM_GetApprovedLeadStores;
			stateVars.dataSource_463912 = stateVars.TM_GetApprovedLeadStores ?? this.state.TM_GetApprovedLeadStores;
			
			stateVars.dataSource_198382 = stateVars.TM_GetApprovedLeadCategories ?? this.state.TM_GetApprovedLeadCategories;
			stateVars.dataSource_198382 = stateVars.TM_GetApprovedLeadCategories ?? this.state.TM_GetApprovedLeadCategories;
			
			stateVars.dataSource_633056 = stateVars.TMTotalStoreApprovedLead ?? this.state.TMTotalStoreApprovedLead;
			formVars.approvedleadlist_402662_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetApprovedLeads !== undefined ? (stateVars.TM_GetApprovedLeads?.length > 0 ? stateVars.TM_GetApprovedLeads[0].magazaAdi : null) : (this.state.TM_GetApprovedLeads?.length > 0 ? this.state.TM_GetApprovedLeads[0].magazaAdi : null)));

			formVars.approvedleadlist_423795_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetApprovedLeads !== undefined ? (stateVars.TM_GetApprovedLeads?.length > 0 ? stateVars.TM_GetApprovedLeads[0].urunKodu : null) : (this.state.TM_GetApprovedLeads?.length > 0 ? this.state.TM_GetApprovedLeads[0].urunKodu : null)));

			stateVars.isComp704832Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, "approvedleadlist_633056_value", "kategori"), ReactSystemFunctions.convertToTypeByName("Kategori 3", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp51772Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, "approvedleadlist_633056_value", "kategori"), ReactSystemFunctions.convertToTypeByName("Kategori 2", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp985567Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, "approvedleadlist_633056_value", "kategori"), ReactSystemFunctions.convertToTypeByName("Kategori 1", "string"))) === true ? "visible" : "hidden")
			formVars.approvedleadlist_859294_value = ReactSystemFunctions.value(this, (stateVars.TM_GetApprovedLeads !== undefined ? (stateVars.TM_GetApprovedLeads?.length > 0 ? stateVars.TM_GetApprovedLeads[0].urunAdi : null) : (this.state.TM_GetApprovedLeads?.length > 0 ? this.state.TM_GetApprovedLeads[0].urunAdi : null)));

			formVars.approvedleadlist_247267_value = ReactSystemFunctions.value(this, (stateVars.TMTotalStoreApprovedLead !== undefined ? (stateVars.TMTotalStoreApprovedLead?.length > 0 ? stateVars.TMTotalStoreApprovedLead[0].adedi : null) : (this.state.TMTotalStoreApprovedLead?.length > 0 ? this.state.TMTotalStoreApprovedLead[0].adedi : null)));


	this.props.form?.setFieldsValue(formVars);
	this.setState(stateVars);
	KuikaAppManager.hideSpinner(this);

            this.setPageInitLoaded(true);
            return isErrorOccurred;
        }




    ApprovedLeadListComponent_209741_onClick = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
		KuikaAppManager.increaseServerRequestCount();

        let localVar = {
				value_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, this.state.TM_GetApprovedLeads), "any"),
				header_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.convertToTypeByName("Onaylanmış Talep Siparişleri", "string"), "string"),
				footer_0: ReactSystemFunctions.convertToTypeByName("", "string"),
				columns_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.convertToTypeByName("OlusturmaTarihi,UrunAdi,UrunKodu,KategoriAdi,MusteriAdiSoyadi,TakipDurumu,SonrakiAdim,SurecAdi,TahminiTeslimatTarihi,OlusturanKullanici,MagazaAdi,Referans,Kadran,Bilezik,ReferansAdiSoyadi", "string"), "string")
        }

		KuikaAppManager.showSpinner(this);
if (ReactSystemFunctions.isNotEqualTo(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "approvedleadlist_235062_checked", "checked", "", "", "")), ReactSystemFunctions.convertToTypeByName("True", "string"))) {
            		
        if (true) {
        KuikaAppManager.showSpinner(this);
        }
        let result = await KuikaAppManager.ApiRequest(this, "ApprovedLeadList/ApprovedLeadListComponent_209741_onClick", localVar)
        if (!KMainFunctions.IsResStatus2XX(result)) return true;

			stateVars.ExportExcel = result?.data.exportExcel;
			ReactSystemFunctions.downloadFile(result?.data?.exportExcel);
			this.props.form?.setFieldsValue(formVars);
			
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.ApprovedLeadListComponent_209741_onClick1_();
                  resolve();
                });
          })

        } else {
            
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.ApprovedLeadListComponent_209741_onClick1_();
                  resolve();
                });
          })
        }


        
        KuikaAppManager.hideSpinner(this);
        return isErrorOccurred;
    }
    ApprovedLeadListComponent_209741_onClick1_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
		KuikaAppManager.increaseServerRequestCount();

        let localVar = {
				value_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, this.state.TMTotalStoreApprovedLead), "any"),
				header_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.convertToTypeByName("Mağaza ve Ürün Bazında Onaylanmış Talepler", "string"), "string"),
				footer_0: ReactSystemFunctions.convertToTypeByName("", "string"),
				columns_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.convertToTypeByName("UrunAdi,UrunKodu,Referans,Kadran,Bilezik,MagazaAdi,Adedi", "string"), "string")
        }

if (ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "approvedleadlist_235062_checked", "checked", "", "", "")), ReactSystemFunctions.convertToTypeByName("True", "string"))) {
            		
        if (true) {
        KuikaAppManager.showSpinner(this);
        }
        let result = await KuikaAppManager.ApiRequest(this, "ApprovedLeadList/ApprovedLeadListComponent_209741_onClick1_", localVar)
        if (!KMainFunctions.IsResStatus2XX(result)) return true;

			stateVars.ExportExcel = result?.data.exportExcel;
			ReactSystemFunctions.downloadFile(result?.data?.exportExcel);
			this.props.form?.setFieldsValue(formVars);
			
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.ApprovedLeadListComponent_209741_onClick2_();
                  resolve();
                });
          })

        } else {
            
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.ApprovedLeadListComponent_209741_onClick2_();
                  resolve();
                });
          })
        }


        
        KuikaAppManager.hideSpinner(this);
        return isErrorOccurred;
    }
		ApprovedLeadListComponent_209741_onClick2_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }

				stateVars.Notify = await ReactSystemFunctions.notify(this, ReactSystemFunctions.translateCustomActions(this.ml,"87d06eca_98ef_6e14_ad05_7024a575cca2_notify",this.defaultML,"Excel başarıyla indirildi!" ), ReactSystemFunctions.convertToTypeByName("success", "string"), ReactSystemFunctions.convertToTypeByName("top-center", "string"), 2, ReactSystemFunctions.convertToTypeByName("", "string"), ReactSystemFunctions.convertToTypeByName("", "string"), 0);

		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

            
            return isErrorOccurred;
        }






		ApprovedLeadListComponent_235062_onChange = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
if (ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "approvedleadlist_235062_checked", "checked", "", "", "")), true)) {
            KuikaAppManager.showSpinner(this);

				stateVars.ChangeEnabledOf = await ReactSystemFunctions.changeEnabledOf(this, ReactSystemFunctions.convertToTypeByName("isComp51248Enabled", "string"), ReactSystemFunctions.convertToTypeByName("disabled", "string"));

		this.props.form?.setFieldsValue(formVars);
		
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.ApprovedLeadListComponent_235062_onChange1_();
                  resolve();
                });
          })

        } else {
            
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.ApprovedLeadListComponent_235062_onChange1_();
                  resolve();
                });
          })
        }

            
            return isErrorOccurred;
        }
		ApprovedLeadListComponent_235062_onChange1_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
if (ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "approvedleadlist_235062_checked", "checked", "", "", "")), true)) {
            
				stateVars.ChangeEnabledOf = await ReactSystemFunctions.changeEnabledOf(this, ReactSystemFunctions.convertToTypeByName("isComp886431Enabled", "string"), ReactSystemFunctions.convertToTypeByName("disabled", "string"));

		this.props.form?.setFieldsValue(formVars);
		
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.ApprovedLeadListComponent_235062_onChange2_();
                  resolve();
                });
          })

        } else {
            
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.ApprovedLeadListComponent_235062_onChange2_();
                  resolve();
                });
          })
        }

            
            return isErrorOccurred;
        }
		ApprovedLeadListComponent_235062_onChange2_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
if (ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "approvedleadlist_235062_checked", "checked", "", "", "")), true)) {
            
				stateVars.ChangeEnabledOf = await ReactSystemFunctions.changeEnabledOf(this, ReactSystemFunctions.convertToTypeByName("isComp713966Enabled", "string"), ReactSystemFunctions.convertToTypeByName("disabled", "string"));

		this.props.form?.setFieldsValue(formVars);
		
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.ApprovedLeadListComponent_235062_onChange3_();
                  resolve();
                });
          })

        } else {
            
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.ApprovedLeadListComponent_235062_onChange3_();
                  resolve();
                });
          })
        }

            
            return isErrorOccurred;
        }
		ApprovedLeadListComponent_235062_onChange3_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
if (ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "approvedleadlist_235062_checked", "checked", "", "", "")), true)) {
            
				stateVars.ChangeEnabledOf = await ReactSystemFunctions.changeEnabledOf(this, ReactSystemFunctions.convertToTypeByName("isComp140260Enabled", "string"), ReactSystemFunctions.convertToTypeByName("disabled", "string"));

		this.props.form?.setFieldsValue(formVars);
		
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.ApprovedLeadListComponent_235062_onChange4_();
                  resolve();
                });
          })

        } else {
            
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.ApprovedLeadListComponent_235062_onChange4_();
                  resolve();
                });
          })
        }

            
            return isErrorOccurred;
        }
		ApprovedLeadListComponent_235062_onChange4_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
if (ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "approvedleadlist_235062_checked", "checked", "", "", "")), true)) {
            
				stateVars.ChangeEnabledOf = await ReactSystemFunctions.changeEnabledOf(this, ReactSystemFunctions.convertToTypeByName("isComp198119Enabled", "string"), ReactSystemFunctions.convertToTypeByName("disabled", "string"));

		this.props.form?.setFieldsValue(formVars);
		
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.ApprovedLeadListComponent_235062_onChange5_();
                  resolve();
                });
          })

        } else {
            
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.ApprovedLeadListComponent_235062_onChange5_();
                  resolve();
                });
          })
        }

            
            return isErrorOccurred;
        }
		ApprovedLeadListComponent_235062_onChange5_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
if (ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "approvedleadlist_235062_checked", "checked", "", "", "")), true)) {
            
				stateVars.ChangeEnabledOf = await ReactSystemFunctions.changeEnabledOf(this, ReactSystemFunctions.convertToTypeByName("isComp329182Enabled", "string"), ReactSystemFunctions.convertToTypeByName("disabled", "string"));

		this.props.form?.setFieldsValue(formVars);
		
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.ApprovedLeadListComponent_235062_onChange6_();
                  resolve();
                });
          })

        } else {
            
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.ApprovedLeadListComponent_235062_onChange6_();
                  resolve();
                });
          })
        }

            
            return isErrorOccurred;
        }
		ApprovedLeadListComponent_235062_onChange6_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
if (ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "approvedleadlist_235062_checked", "checked", "", "", "")), false)) {
            
				stateVars.ChangeEnabledOf = await ReactSystemFunctions.changeEnabledOf(this, ReactSystemFunctions.convertToTypeByName("isComp51248Enabled", "string"), ReactSystemFunctions.convertToTypeByName("enabled", "string"));

		this.props.form?.setFieldsValue(formVars);
		
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.ApprovedLeadListComponent_235062_onChange7_();
                  resolve();
                });
          })

        } else {
            
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.ApprovedLeadListComponent_235062_onChange7_();
                  resolve();
                });
          })
        }

            
            return isErrorOccurred;
        }
		ApprovedLeadListComponent_235062_onChange7_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
if (ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "approvedleadlist_235062_checked", "checked", "", "", "")), false)) {
            
				stateVars.ChangeEnabledOf = await ReactSystemFunctions.changeEnabledOf(this, ReactSystemFunctions.convertToTypeByName("isComp886431Enabled", "string"), ReactSystemFunctions.convertToTypeByName("enabled", "string"));

		this.props.form?.setFieldsValue(formVars);
		
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.ApprovedLeadListComponent_235062_onChange8_();
                  resolve();
                });
          })

        } else {
            
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.ApprovedLeadListComponent_235062_onChange8_();
                  resolve();
                });
          })
        }

            
            return isErrorOccurred;
        }
		ApprovedLeadListComponent_235062_onChange8_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
if (ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "approvedleadlist_235062_checked", "checked", "", "", "")), false)) {
            
				stateVars.ChangeEnabledOf = await ReactSystemFunctions.changeEnabledOf(this, ReactSystemFunctions.convertToTypeByName("isComp713966Enabled", "string"), ReactSystemFunctions.convertToTypeByName("enabled", "string"));

		this.props.form?.setFieldsValue(formVars);
		
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.ApprovedLeadListComponent_235062_onChange9_();
                  resolve();
                });
          })

        } else {
            
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.ApprovedLeadListComponent_235062_onChange9_();
                  resolve();
                });
          })
        }

            
            return isErrorOccurred;
        }
		ApprovedLeadListComponent_235062_onChange9_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
if (ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "approvedleadlist_235062_checked", "checked", "", "", "")), false)) {
            
				stateVars.ChangeEnabledOf = await ReactSystemFunctions.changeEnabledOf(this, ReactSystemFunctions.convertToTypeByName("isComp140260Enabled", "string"), ReactSystemFunctions.convertToTypeByName("enabled", "string"));

		this.props.form?.setFieldsValue(formVars);
		
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.ApprovedLeadListComponent_235062_onChange10_();
                  resolve();
                });
          })

        } else {
            
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.ApprovedLeadListComponent_235062_onChange10_();
                  resolve();
                });
          })
        }

            
            return isErrorOccurred;
        }
		ApprovedLeadListComponent_235062_onChange10_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
if (ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "approvedleadlist_235062_checked", "checked", "", "", "")), false)) {
            
				stateVars.ChangeEnabledOf = await ReactSystemFunctions.changeEnabledOf(this, ReactSystemFunctions.convertToTypeByName("isComp198119Enabled", "string"), ReactSystemFunctions.convertToTypeByName("enabled", "string"));

		this.props.form?.setFieldsValue(formVars);
		
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.ApprovedLeadListComponent_235062_onChange11_();
                  resolve();
                });
          })

        } else {
            
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.ApprovedLeadListComponent_235062_onChange11_();
                  resolve();
                });
          })
        }

            
            return isErrorOccurred;
        }
		ApprovedLeadListComponent_235062_onChange11_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
if (ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "approvedleadlist_235062_checked", "checked", "", "", "")), false)) {
            
				stateVars.ChangeEnabledOf = await ReactSystemFunctions.changeEnabledOf(this, ReactSystemFunctions.convertToTypeByName("isComp329182Enabled", "string"), ReactSystemFunctions.convertToTypeByName("enabled", "string"));

		this.props.form?.setFieldsValue(formVars);
		
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.ApprovedLeadListComponent_235062_onChange12_();
                  resolve();
                });
          })

        } else {
            
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.ApprovedLeadListComponent_235062_onChange12_();
                  resolve();
                });
          })
        }

            
            return isErrorOccurred;
        }
		ApprovedLeadListComponent_235062_onChange12_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
if (ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "approvedleadlist_235062_checked", "checked", "", "", "")), true)) {
            
				stateVars.ChangeVisibilityOf = await ReactSystemFunctions.changeVisibilityOf(this, ReactSystemFunctions.convertToTypeByName("isComp896586Visible", "string"), ReactSystemFunctions.convertToTypeByName("hidden", "string"));

		this.props.form?.setFieldsValue(formVars);
		
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.ApprovedLeadListComponent_235062_onChange13_();
                  resolve();
                });
          })

        } else {
            
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.ApprovedLeadListComponent_235062_onChange13_();
                  resolve();
                });
          })
        }

            
            return isErrorOccurred;
        }
		ApprovedLeadListComponent_235062_onChange13_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
if (ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "approvedleadlist_235062_checked", "checked", "", "", "")), false)) {
            
				stateVars.ChangeVisibilityOf = await ReactSystemFunctions.changeVisibilityOf(this, ReactSystemFunctions.convertToTypeByName("isComp896586Visible", "string"), ReactSystemFunctions.convertToTypeByName("visible", "string"));

		this.props.form?.setFieldsValue(formVars);
		
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.ApprovedLeadListComponent_235062_onChange14_();
                  resolve();
                });
          })

        } else {
            
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.ApprovedLeadListComponent_235062_onChange14_();
                  resolve();
                });
          })
        }

            
            return isErrorOccurred;
        }
		ApprovedLeadListComponent_235062_onChange14_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
if (ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "approvedleadlist_235062_checked", "checked", "", "", "")), false)) {
            
				stateVars.ChangeVisibilityOf = await ReactSystemFunctions.changeVisibilityOf(this, ReactSystemFunctions.convertToTypeByName("isComp654433Visible", "string"), ReactSystemFunctions.convertToTypeByName("hidden", "string"));

		this.props.form?.setFieldsValue(formVars);
		
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.ApprovedLeadListComponent_235062_onChange15_();
                  resolve();
                });
          })

        } else {
            
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.ApprovedLeadListComponent_235062_onChange15_();
                  resolve();
                });
          })
        }

            
            return isErrorOccurred;
        }
		ApprovedLeadListComponent_235062_onChange15_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
if (ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "approvedleadlist_235062_checked", "checked", "", "", "")), true)) {
            
				stateVars.ChangeVisibilityOf = await ReactSystemFunctions.changeVisibilityOf(this, ReactSystemFunctions.convertToTypeByName("isComp654433Visible", "string"), ReactSystemFunctions.convertToTypeByName("visible", "string"));

		this.props.form?.setFieldsValue(formVars);
		
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.ApprovedLeadListComponent_235062_onChange16_();
                  resolve();
                });
          })

        } else {
            
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.ApprovedLeadListComponent_235062_onChange16_();
                  resolve();
                });
          })
        }

            
            return isErrorOccurred;
        }
		ApprovedLeadListComponent_235062_onChange16_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }

				stateVars.isComp25615Visible = ((ReactSystemFunctions.isNotEqualTo(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "approvedleadlist_235062_checked", "checked", "", "", "")), true)) === true ? "visible" : "hidden")
				stateVars.isComp466228Visible = ((ReactSystemFunctions.isNotEqualTo(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "approvedleadlist_235062_checked", "checked", "", "", "")), true)) === true ? "visible" : "hidden")
				stateVars.isComp505603Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "approvedleadlist_235062_checked", "checked", "", "", "")), true)) === true ? "visible" : "hidden")

		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

            
            return isErrorOccurred;
        }


















    ApprovedLeadListComponent_51248_onChange = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
		KuikaAppManager.increaseServerRequestCount();

        let localVar = {
				StoreId_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "approvedleadlist_51248_value", "value", "TM_GetApprovedLeadStores", "storeId", "storeId")), "string"),
				CategoryName_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "approvedleadlist_886431_value", "value", "TM_GetApprovedLeadCategories", "categoryName", "categoryName")), "string"),
				ProductName_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "approvedleadlist_140260_value", "value", "", "", "")), "string"),
				Musteri_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "approvedleadlist_198119_value", "value", "", "", "")), "string"),
				EstimatedDateStart_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "approvedleadlist_270363_value", "value", "", "", "")), "Date"),
				EstimatedDateEnd_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "approvedleadlist_334933_value", "value", "", "", "")), "Date"),
				LeadCode_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "approvedleadlist_531862_value", "value", "", "", "")), "string"),
				ReferenceId_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "approvedleadlist_329182_value", "value", "TMGetRefApproved", "referenceId", "referenceId")), "string"),
				OrderType_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toInteger(this, ReactSystemFunctions.value(this, "approvedleadlist_713966_value", "value", "", "key", "")), "number")
        }

		KuikaAppManager.showSpinner(this);
		
        if (true) {
        KuikaAppManager.showSpinner(this);
        }
        let result = await KuikaAppManager.ApiRequest(this, "ApprovedLeadList/ApprovedLeadListComponent_51248_onChange", localVar)
        if (!KMainFunctions.IsResStatus2XX(result)) return true;

			stateVars.TM_GetApprovedLeads = result?.data.tM_GetApprovedLeads;
			
			this.props.form?.setFieldsValue(formVars);
			
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.ApprovedLeadListComponent_51248_onChange1_();
                  resolve();
                });
          })



        
        KuikaAppManager.hideSpinner(this);
        return isErrorOccurred;
    }
		ApprovedLeadListComponent_51248_onChange1_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }

				
				stateVars.dataSource_3547 = stateVars.TM_GetApprovedLeads ?? this.state.TM_GetApprovedLeads;
				formVars.approvedleadlist_899217_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetApprovedLeads !== undefined ? (stateVars.TM_GetApprovedLeads?.length > 0 ? stateVars.TM_GetApprovedLeads[0].magazaAdi : null) : (this.state.TM_GetApprovedLeads?.length > 0 ? this.state.TM_GetApprovedLeads[0].magazaAdi : null)));

				formVars.approvedleadlist_226426_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetApprovedLeads !== undefined ? (stateVars.TM_GetApprovedLeads?.length > 0 ? stateVars.TM_GetApprovedLeads[0].kategoriAdi : null) : (this.state.TM_GetApprovedLeads?.length > 0 ? this.state.TM_GetApprovedLeads[0].kategoriAdi : null)));

				formVars.approvedleadlist_328471_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetApprovedLeads !== undefined ? (stateVars.TM_GetApprovedLeads?.length > 0 ? stateVars.TM_GetApprovedLeads[0].kategoriAdi : null) : (this.state.TM_GetApprovedLeads?.length > 0 ? this.state.TM_GetApprovedLeads[0].kategoriAdi : null)));

				formVars.approvedleadlist_758913_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetApprovedLeads !== undefined ? (stateVars.TM_GetApprovedLeads?.length > 0 ? stateVars.TM_GetApprovedLeads[0].kategoriAdi : null) : (this.state.TM_GetApprovedLeads?.length > 0 ? this.state.TM_GetApprovedLeads[0].kategoriAdi : null)));

				formVars.approvedleadlist_47950_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetApprovedLeads !== undefined ? (stateVars.TM_GetApprovedLeads?.length > 0 ? stateVars.TM_GetApprovedLeads[0].urunAdi : null) : (this.state.TM_GetApprovedLeads?.length > 0 ? this.state.TM_GetApprovedLeads[0].urunAdi : null)));

				formVars.approvedleadlist_941802_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetApprovedLeads !== undefined ? (stateVars.TM_GetApprovedLeads?.length > 0 ? stateVars.TM_GetApprovedLeads[0].musteriAdiSoyadi : null) : (this.state.TM_GetApprovedLeads?.length > 0 ? this.state.TM_GetApprovedLeads[0].musteriAdiSoyadi : null)));

				formVars.approvedleadlist_18630_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetApprovedLeads !== undefined ? (stateVars.TM_GetApprovedLeads?.length > 0 ? stateVars.TM_GetApprovedLeads[0].referansAdiSoyadi : null) : (this.state.TM_GetApprovedLeads?.length > 0 ? this.state.TM_GetApprovedLeads[0].referansAdiSoyadi : null)));

				formVars.approvedleadlist_746483_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetApprovedLeads !== undefined ? (stateVars.TM_GetApprovedLeads?.length > 0 ? stateVars.TM_GetApprovedLeads[0].takipDurumu : null) : (this.state.TM_GetApprovedLeads?.length > 0 ? this.state.TM_GetApprovedLeads[0].takipDurumu : null)));

				formVars.approvedleadlist_887947_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetApprovedLeads !== undefined ? (stateVars.TM_GetApprovedLeads?.length > 0 ? stateVars.TM_GetApprovedLeads[0].takipDurumu : null) : (this.state.TM_GetApprovedLeads?.length > 0 ? this.state.TM_GetApprovedLeads[0].takipDurumu : null)));

				formVars.approvedleadlist_488433_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetApprovedLeads !== undefined ? (stateVars.TM_GetApprovedLeads?.length > 0 ? stateVars.TM_GetApprovedLeads[0].sonrakiAdim : null) : (this.state.TM_GetApprovedLeads?.length > 0 ? this.state.TM_GetApprovedLeads[0].sonrakiAdim : null)));

				formVars.approvedleadlist_312740_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetApprovedLeads !== undefined ? (stateVars.TM_GetApprovedLeads?.length > 0 ? stateVars.TM_GetApprovedLeads[0].tahminiTeslimatTarihi : null) : (this.state.TM_GetApprovedLeads?.length > 0 ? this.state.TM_GetApprovedLeads[0].tahminiTeslimatTarihi : null)));

				formVars.approvedleadlist_252762_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetApprovedLeads !== undefined ? (stateVars.TM_GetApprovedLeads?.length > 0 ? stateVars.TM_GetApprovedLeads[0].olusturanKullanici : null) : (this.state.TM_GetApprovedLeads?.length > 0 ? this.state.TM_GetApprovedLeads[0].olusturanKullanici : null)));

				formVars.approvedleadlist_402662_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetApprovedLeads !== undefined ? (stateVars.TM_GetApprovedLeads?.length > 0 ? stateVars.TM_GetApprovedLeads[0].magazaAdi : null) : (this.state.TM_GetApprovedLeads?.length > 0 ? this.state.TM_GetApprovedLeads[0].magazaAdi : null)));

				formVars.approvedleadlist_423795_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetApprovedLeads !== undefined ? (stateVars.TM_GetApprovedLeads?.length > 0 ? stateVars.TM_GetApprovedLeads[0].urunKodu : null) : (this.state.TM_GetApprovedLeads?.length > 0 ? this.state.TM_GetApprovedLeads[0].urunKodu : null)));

				formVars.approvedleadlist_859294_value = ReactSystemFunctions.value(this, (stateVars.TM_GetApprovedLeads !== undefined ? (stateVars.TM_GetApprovedLeads?.length > 0 ? stateVars.TM_GetApprovedLeads[0].urunAdi : null) : (this.state.TM_GetApprovedLeads?.length > 0 ? this.state.TM_GetApprovedLeads[0].urunAdi : null)));


		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

            
            return isErrorOccurred;
        }




    ApprovedLeadListComponent_886431_onChange = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
		KuikaAppManager.increaseServerRequestCount();

        let localVar = {
				StoreId_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "approvedleadlist_51248_value", "value", "TM_GetApprovedLeadStores", "storeId", "storeId")), "string"),
				CategoryName_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "approvedleadlist_886431_value", "value", "TM_GetApprovedLeadCategories", "categoryName", "categoryName")), "string"),
				ProductName_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "approvedleadlist_140260_value", "value", "", "", "")), "string"),
				Musteri_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "approvedleadlist_198119_value", "value", "", "", "")), "string"),
				EstimatedDateStart_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "approvedleadlist_270363_value", "value", "", "", "")), "Date"),
				EstimatedDateEnd_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "approvedleadlist_334933_value", "value", "", "", "")), "Date"),
				LeadCode_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "approvedleadlist_531862_value", "value", "", "", "")), "string"),
				ReferenceId_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "approvedleadlist_329182_value", "value", "TMGetRefApproved", "referenceId", "referenceId")), "string"),
				OrderType_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toInteger(this, ReactSystemFunctions.value(this, "approvedleadlist_713966_value", "value", "", "key", "")), "number")
        }

		KuikaAppManager.showSpinner(this);
		
        if (true) {
        KuikaAppManager.showSpinner(this);
        }
        let result = await KuikaAppManager.ApiRequest(this, "ApprovedLeadList/ApprovedLeadListComponent_886431_onChange", localVar)
        if (!KMainFunctions.IsResStatus2XX(result)) return true;

			stateVars.TM_GetApprovedLeads = result?.data.tM_GetApprovedLeads;
			
			this.props.form?.setFieldsValue(formVars);
			
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.ApprovedLeadListComponent_886431_onChange1_();
                  resolve();
                });
          })



        
        KuikaAppManager.hideSpinner(this);
        return isErrorOccurred;
    }
		ApprovedLeadListComponent_886431_onChange1_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }

				
				stateVars.dataSource_3547 = stateVars.TM_GetApprovedLeads ?? this.state.TM_GetApprovedLeads;
				formVars.approvedleadlist_899217_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetApprovedLeads !== undefined ? (stateVars.TM_GetApprovedLeads?.length > 0 ? stateVars.TM_GetApprovedLeads[0].magazaAdi : null) : (this.state.TM_GetApprovedLeads?.length > 0 ? this.state.TM_GetApprovedLeads[0].magazaAdi : null)));

				formVars.approvedleadlist_226426_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetApprovedLeads !== undefined ? (stateVars.TM_GetApprovedLeads?.length > 0 ? stateVars.TM_GetApprovedLeads[0].kategoriAdi : null) : (this.state.TM_GetApprovedLeads?.length > 0 ? this.state.TM_GetApprovedLeads[0].kategoriAdi : null)));

				formVars.approvedleadlist_328471_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetApprovedLeads !== undefined ? (stateVars.TM_GetApprovedLeads?.length > 0 ? stateVars.TM_GetApprovedLeads[0].kategoriAdi : null) : (this.state.TM_GetApprovedLeads?.length > 0 ? this.state.TM_GetApprovedLeads[0].kategoriAdi : null)));

				formVars.approvedleadlist_758913_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetApprovedLeads !== undefined ? (stateVars.TM_GetApprovedLeads?.length > 0 ? stateVars.TM_GetApprovedLeads[0].kategoriAdi : null) : (this.state.TM_GetApprovedLeads?.length > 0 ? this.state.TM_GetApprovedLeads[0].kategoriAdi : null)));

				formVars.approvedleadlist_47950_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetApprovedLeads !== undefined ? (stateVars.TM_GetApprovedLeads?.length > 0 ? stateVars.TM_GetApprovedLeads[0].urunAdi : null) : (this.state.TM_GetApprovedLeads?.length > 0 ? this.state.TM_GetApprovedLeads[0].urunAdi : null)));

				formVars.approvedleadlist_941802_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetApprovedLeads !== undefined ? (stateVars.TM_GetApprovedLeads?.length > 0 ? stateVars.TM_GetApprovedLeads[0].musteriAdiSoyadi : null) : (this.state.TM_GetApprovedLeads?.length > 0 ? this.state.TM_GetApprovedLeads[0].musteriAdiSoyadi : null)));

				formVars.approvedleadlist_18630_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetApprovedLeads !== undefined ? (stateVars.TM_GetApprovedLeads?.length > 0 ? stateVars.TM_GetApprovedLeads[0].referansAdiSoyadi : null) : (this.state.TM_GetApprovedLeads?.length > 0 ? this.state.TM_GetApprovedLeads[0].referansAdiSoyadi : null)));

				formVars.approvedleadlist_746483_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetApprovedLeads !== undefined ? (stateVars.TM_GetApprovedLeads?.length > 0 ? stateVars.TM_GetApprovedLeads[0].takipDurumu : null) : (this.state.TM_GetApprovedLeads?.length > 0 ? this.state.TM_GetApprovedLeads[0].takipDurumu : null)));

				formVars.approvedleadlist_887947_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetApprovedLeads !== undefined ? (stateVars.TM_GetApprovedLeads?.length > 0 ? stateVars.TM_GetApprovedLeads[0].takipDurumu : null) : (this.state.TM_GetApprovedLeads?.length > 0 ? this.state.TM_GetApprovedLeads[0].takipDurumu : null)));

				formVars.approvedleadlist_488433_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetApprovedLeads !== undefined ? (stateVars.TM_GetApprovedLeads?.length > 0 ? stateVars.TM_GetApprovedLeads[0].sonrakiAdim : null) : (this.state.TM_GetApprovedLeads?.length > 0 ? this.state.TM_GetApprovedLeads[0].sonrakiAdim : null)));

				formVars.approvedleadlist_312740_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetApprovedLeads !== undefined ? (stateVars.TM_GetApprovedLeads?.length > 0 ? stateVars.TM_GetApprovedLeads[0].tahminiTeslimatTarihi : null) : (this.state.TM_GetApprovedLeads?.length > 0 ? this.state.TM_GetApprovedLeads[0].tahminiTeslimatTarihi : null)));

				formVars.approvedleadlist_252762_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetApprovedLeads !== undefined ? (stateVars.TM_GetApprovedLeads?.length > 0 ? stateVars.TM_GetApprovedLeads[0].olusturanKullanici : null) : (this.state.TM_GetApprovedLeads?.length > 0 ? this.state.TM_GetApprovedLeads[0].olusturanKullanici : null)));

				formVars.approvedleadlist_402662_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetApprovedLeads !== undefined ? (stateVars.TM_GetApprovedLeads?.length > 0 ? stateVars.TM_GetApprovedLeads[0].magazaAdi : null) : (this.state.TM_GetApprovedLeads?.length > 0 ? this.state.TM_GetApprovedLeads[0].magazaAdi : null)));

				formVars.approvedleadlist_423795_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetApprovedLeads !== undefined ? (stateVars.TM_GetApprovedLeads?.length > 0 ? stateVars.TM_GetApprovedLeads[0].urunKodu : null) : (this.state.TM_GetApprovedLeads?.length > 0 ? this.state.TM_GetApprovedLeads[0].urunKodu : null)));

				formVars.approvedleadlist_859294_value = ReactSystemFunctions.value(this, (stateVars.TM_GetApprovedLeads !== undefined ? (stateVars.TM_GetApprovedLeads?.length > 0 ? stateVars.TM_GetApprovedLeads[0].urunAdi : null) : (this.state.TM_GetApprovedLeads?.length > 0 ? this.state.TM_GetApprovedLeads[0].urunAdi : null)));


		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

            
            return isErrorOccurred;
        }




    ApprovedLeadListComponent_140260_onChange = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
		KuikaAppManager.increaseServerRequestCount();

        let localVar = {
				StoreId_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "approvedleadlist_51248_value", "value", "TM_GetApprovedLeadStores", "storeId", "storeId")), "string"),
				CategoryName_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "approvedleadlist_886431_value", "value", "TM_GetApprovedLeadCategories", "categoryName", "categoryName")), "string"),
				ProductName_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "approvedleadlist_140260_value", "value", "", "", "")), "string"),
				Musteri_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "approvedleadlist_198119_value", "value", "", "", "")), "string"),
				EstimatedDateStart_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "approvedleadlist_270363_value", "value", "", "", "")), "Date"),
				EstimatedDateEnd_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "approvedleadlist_334933_value", "value", "", "", "")), "Date"),
				LeadCode_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "approvedleadlist_531862_value", "value", "", "", "")), "string"),
				ReferenceId_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "approvedleadlist_329182_value", "value", "TMGetRefApproved", "referenceId", "referenceId")), "string"),
				OrderType_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toInteger(this, ReactSystemFunctions.value(this, "approvedleadlist_713966_value", "value", "", "key", "")), "number")
        }

		KuikaAppManager.showSpinner(this);
		
        if (true) {
        KuikaAppManager.showSpinner(this);
        }
        let result = await KuikaAppManager.ApiRequest(this, "ApprovedLeadList/ApprovedLeadListComponent_140260_onChange", localVar)
        if (!KMainFunctions.IsResStatus2XX(result)) return true;

			stateVars.TM_GetApprovedLeads = result?.data.tM_GetApprovedLeads;
			
			this.props.form?.setFieldsValue(formVars);
			
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.ApprovedLeadListComponent_140260_onChange1_();
                  resolve();
                });
          })



        
        KuikaAppManager.hideSpinner(this);
        return isErrorOccurred;
    }
		ApprovedLeadListComponent_140260_onChange1_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }

				
				stateVars.dataSource_3547 = stateVars.TM_GetApprovedLeads ?? this.state.TM_GetApprovedLeads;
				formVars.approvedleadlist_899217_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetApprovedLeads !== undefined ? (stateVars.TM_GetApprovedLeads?.length > 0 ? stateVars.TM_GetApprovedLeads[0].magazaAdi : null) : (this.state.TM_GetApprovedLeads?.length > 0 ? this.state.TM_GetApprovedLeads[0].magazaAdi : null)));

				formVars.approvedleadlist_226426_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetApprovedLeads !== undefined ? (stateVars.TM_GetApprovedLeads?.length > 0 ? stateVars.TM_GetApprovedLeads[0].kategoriAdi : null) : (this.state.TM_GetApprovedLeads?.length > 0 ? this.state.TM_GetApprovedLeads[0].kategoriAdi : null)));

				formVars.approvedleadlist_328471_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetApprovedLeads !== undefined ? (stateVars.TM_GetApprovedLeads?.length > 0 ? stateVars.TM_GetApprovedLeads[0].kategoriAdi : null) : (this.state.TM_GetApprovedLeads?.length > 0 ? this.state.TM_GetApprovedLeads[0].kategoriAdi : null)));

				formVars.approvedleadlist_758913_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetApprovedLeads !== undefined ? (stateVars.TM_GetApprovedLeads?.length > 0 ? stateVars.TM_GetApprovedLeads[0].kategoriAdi : null) : (this.state.TM_GetApprovedLeads?.length > 0 ? this.state.TM_GetApprovedLeads[0].kategoriAdi : null)));

				formVars.approvedleadlist_47950_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetApprovedLeads !== undefined ? (stateVars.TM_GetApprovedLeads?.length > 0 ? stateVars.TM_GetApprovedLeads[0].urunAdi : null) : (this.state.TM_GetApprovedLeads?.length > 0 ? this.state.TM_GetApprovedLeads[0].urunAdi : null)));

				formVars.approvedleadlist_941802_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetApprovedLeads !== undefined ? (stateVars.TM_GetApprovedLeads?.length > 0 ? stateVars.TM_GetApprovedLeads[0].musteriAdiSoyadi : null) : (this.state.TM_GetApprovedLeads?.length > 0 ? this.state.TM_GetApprovedLeads[0].musteriAdiSoyadi : null)));

				formVars.approvedleadlist_18630_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetApprovedLeads !== undefined ? (stateVars.TM_GetApprovedLeads?.length > 0 ? stateVars.TM_GetApprovedLeads[0].referansAdiSoyadi : null) : (this.state.TM_GetApprovedLeads?.length > 0 ? this.state.TM_GetApprovedLeads[0].referansAdiSoyadi : null)));

				formVars.approvedleadlist_746483_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetApprovedLeads !== undefined ? (stateVars.TM_GetApprovedLeads?.length > 0 ? stateVars.TM_GetApprovedLeads[0].takipDurumu : null) : (this.state.TM_GetApprovedLeads?.length > 0 ? this.state.TM_GetApprovedLeads[0].takipDurumu : null)));

				formVars.approvedleadlist_887947_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetApprovedLeads !== undefined ? (stateVars.TM_GetApprovedLeads?.length > 0 ? stateVars.TM_GetApprovedLeads[0].takipDurumu : null) : (this.state.TM_GetApprovedLeads?.length > 0 ? this.state.TM_GetApprovedLeads[0].takipDurumu : null)));

				formVars.approvedleadlist_488433_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetApprovedLeads !== undefined ? (stateVars.TM_GetApprovedLeads?.length > 0 ? stateVars.TM_GetApprovedLeads[0].sonrakiAdim : null) : (this.state.TM_GetApprovedLeads?.length > 0 ? this.state.TM_GetApprovedLeads[0].sonrakiAdim : null)));

				formVars.approvedleadlist_312740_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetApprovedLeads !== undefined ? (stateVars.TM_GetApprovedLeads?.length > 0 ? stateVars.TM_GetApprovedLeads[0].tahminiTeslimatTarihi : null) : (this.state.TM_GetApprovedLeads?.length > 0 ? this.state.TM_GetApprovedLeads[0].tahminiTeslimatTarihi : null)));

				formVars.approvedleadlist_252762_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetApprovedLeads !== undefined ? (stateVars.TM_GetApprovedLeads?.length > 0 ? stateVars.TM_GetApprovedLeads[0].olusturanKullanici : null) : (this.state.TM_GetApprovedLeads?.length > 0 ? this.state.TM_GetApprovedLeads[0].olusturanKullanici : null)));

				formVars.approvedleadlist_402662_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetApprovedLeads !== undefined ? (stateVars.TM_GetApprovedLeads?.length > 0 ? stateVars.TM_GetApprovedLeads[0].magazaAdi : null) : (this.state.TM_GetApprovedLeads?.length > 0 ? this.state.TM_GetApprovedLeads[0].magazaAdi : null)));

				formVars.approvedleadlist_423795_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetApprovedLeads !== undefined ? (stateVars.TM_GetApprovedLeads?.length > 0 ? stateVars.TM_GetApprovedLeads[0].urunKodu : null) : (this.state.TM_GetApprovedLeads?.length > 0 ? this.state.TM_GetApprovedLeads[0].urunKodu : null)));

				formVars.approvedleadlist_859294_value = ReactSystemFunctions.value(this, (stateVars.TM_GetApprovedLeads !== undefined ? (stateVars.TM_GetApprovedLeads?.length > 0 ? stateVars.TM_GetApprovedLeads[0].urunAdi : null) : (this.state.TM_GetApprovedLeads?.length > 0 ? this.state.TM_GetApprovedLeads[0].urunAdi : null)));


		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

            
            return isErrorOccurred;
        }




    ApprovedLeadListComponent_713966_onChange = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
		KuikaAppManager.increaseServerRequestCount();

        let localVar = {
				StoreId_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "approvedleadlist_51248_value", "value", "TM_GetApprovedLeadStores", "storeId", "storeId")), "string"),
				CategoryName_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "approvedleadlist_886431_value", "value", "TM_GetApprovedLeadCategories", "categoryName", "categoryName")), "string"),
				ProductName_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "approvedleadlist_140260_value", "value", "", "", "")), "string"),
				Musteri_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "approvedleadlist_198119_value", "value", "", "", "")), "string"),
				EstimatedDateStart_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "approvedleadlist_270363_value", "value", "", "", "")), "Date"),
				EstimatedDateEnd_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "approvedleadlist_334933_value", "value", "", "", "")), "Date"),
				LeadCode_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "approvedleadlist_531862_value", "value", "", "", "")), "string"),
				ReferenceId_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "approvedleadlist_329182_value", "value", "TMGetRefApproved", "referenceId", "referenceId")), "string"),
				OrderType_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toInteger(this, ReactSystemFunctions.value(this, "approvedleadlist_713966_value", "value", "", "key", "")), "number")
        }

		KuikaAppManager.showSpinner(this);
		
        if (true) {
        KuikaAppManager.showSpinner(this);
        }
        let result = await KuikaAppManager.ApiRequest(this, "ApprovedLeadList/ApprovedLeadListComponent_713966_onChange", localVar)
        if (!KMainFunctions.IsResStatus2XX(result)) return true;

			stateVars.TM_GetApprovedLeads = result?.data.tM_GetApprovedLeads;
			
			this.props.form?.setFieldsValue(formVars);
			
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.ApprovedLeadListComponent_713966_onChange1_();
                  resolve();
                });
          })



        
        KuikaAppManager.hideSpinner(this);
        return isErrorOccurred;
    }
		ApprovedLeadListComponent_713966_onChange1_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }

				
				stateVars.dataSource_3547 = stateVars.TM_GetApprovedLeads ?? this.state.TM_GetApprovedLeads;
				formVars.approvedleadlist_899217_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetApprovedLeads !== undefined ? (stateVars.TM_GetApprovedLeads?.length > 0 ? stateVars.TM_GetApprovedLeads[0].magazaAdi : null) : (this.state.TM_GetApprovedLeads?.length > 0 ? this.state.TM_GetApprovedLeads[0].magazaAdi : null)));

				formVars.approvedleadlist_226426_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetApprovedLeads !== undefined ? (stateVars.TM_GetApprovedLeads?.length > 0 ? stateVars.TM_GetApprovedLeads[0].kategoriAdi : null) : (this.state.TM_GetApprovedLeads?.length > 0 ? this.state.TM_GetApprovedLeads[0].kategoriAdi : null)));

				formVars.approvedleadlist_328471_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetApprovedLeads !== undefined ? (stateVars.TM_GetApprovedLeads?.length > 0 ? stateVars.TM_GetApprovedLeads[0].kategoriAdi : null) : (this.state.TM_GetApprovedLeads?.length > 0 ? this.state.TM_GetApprovedLeads[0].kategoriAdi : null)));

				formVars.approvedleadlist_758913_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetApprovedLeads !== undefined ? (stateVars.TM_GetApprovedLeads?.length > 0 ? stateVars.TM_GetApprovedLeads[0].kategoriAdi : null) : (this.state.TM_GetApprovedLeads?.length > 0 ? this.state.TM_GetApprovedLeads[0].kategoriAdi : null)));

				formVars.approvedleadlist_47950_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetApprovedLeads !== undefined ? (stateVars.TM_GetApprovedLeads?.length > 0 ? stateVars.TM_GetApprovedLeads[0].urunAdi : null) : (this.state.TM_GetApprovedLeads?.length > 0 ? this.state.TM_GetApprovedLeads[0].urunAdi : null)));

				formVars.approvedleadlist_941802_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetApprovedLeads !== undefined ? (stateVars.TM_GetApprovedLeads?.length > 0 ? stateVars.TM_GetApprovedLeads[0].musteriAdiSoyadi : null) : (this.state.TM_GetApprovedLeads?.length > 0 ? this.state.TM_GetApprovedLeads[0].musteriAdiSoyadi : null)));

				formVars.approvedleadlist_18630_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetApprovedLeads !== undefined ? (stateVars.TM_GetApprovedLeads?.length > 0 ? stateVars.TM_GetApprovedLeads[0].referansAdiSoyadi : null) : (this.state.TM_GetApprovedLeads?.length > 0 ? this.state.TM_GetApprovedLeads[0].referansAdiSoyadi : null)));

				formVars.approvedleadlist_746483_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetApprovedLeads !== undefined ? (stateVars.TM_GetApprovedLeads?.length > 0 ? stateVars.TM_GetApprovedLeads[0].takipDurumu : null) : (this.state.TM_GetApprovedLeads?.length > 0 ? this.state.TM_GetApprovedLeads[0].takipDurumu : null)));

				formVars.approvedleadlist_887947_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetApprovedLeads !== undefined ? (stateVars.TM_GetApprovedLeads?.length > 0 ? stateVars.TM_GetApprovedLeads[0].takipDurumu : null) : (this.state.TM_GetApprovedLeads?.length > 0 ? this.state.TM_GetApprovedLeads[0].takipDurumu : null)));

				formVars.approvedleadlist_488433_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetApprovedLeads !== undefined ? (stateVars.TM_GetApprovedLeads?.length > 0 ? stateVars.TM_GetApprovedLeads[0].sonrakiAdim : null) : (this.state.TM_GetApprovedLeads?.length > 0 ? this.state.TM_GetApprovedLeads[0].sonrakiAdim : null)));

				formVars.approvedleadlist_312740_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetApprovedLeads !== undefined ? (stateVars.TM_GetApprovedLeads?.length > 0 ? stateVars.TM_GetApprovedLeads[0].tahminiTeslimatTarihi : null) : (this.state.TM_GetApprovedLeads?.length > 0 ? this.state.TM_GetApprovedLeads[0].tahminiTeslimatTarihi : null)));

				formVars.approvedleadlist_252762_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetApprovedLeads !== undefined ? (stateVars.TM_GetApprovedLeads?.length > 0 ? stateVars.TM_GetApprovedLeads[0].olusturanKullanici : null) : (this.state.TM_GetApprovedLeads?.length > 0 ? this.state.TM_GetApprovedLeads[0].olusturanKullanici : null)));

				formVars.approvedleadlist_402662_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetApprovedLeads !== undefined ? (stateVars.TM_GetApprovedLeads?.length > 0 ? stateVars.TM_GetApprovedLeads[0].magazaAdi : null) : (this.state.TM_GetApprovedLeads?.length > 0 ? this.state.TM_GetApprovedLeads[0].magazaAdi : null)));

				formVars.approvedleadlist_423795_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetApprovedLeads !== undefined ? (stateVars.TM_GetApprovedLeads?.length > 0 ? stateVars.TM_GetApprovedLeads[0].urunKodu : null) : (this.state.TM_GetApprovedLeads?.length > 0 ? this.state.TM_GetApprovedLeads[0].urunKodu : null)));

				formVars.approvedleadlist_859294_value = ReactSystemFunctions.value(this, (stateVars.TM_GetApprovedLeads !== undefined ? (stateVars.TM_GetApprovedLeads?.length > 0 ? stateVars.TM_GetApprovedLeads[0].urunAdi : null) : (this.state.TM_GetApprovedLeads?.length > 0 ? this.state.TM_GetApprovedLeads[0].urunAdi : null)));


		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

            
            return isErrorOccurred;
        }




    ApprovedLeadListComponent_198119_onChange = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
		KuikaAppManager.increaseServerRequestCount();

        let localVar = {
				StoreId_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "approvedleadlist_51248_value", "value", "TM_GetApprovedLeadStores", "storeId", "storeId")), "string"),
				CategoryName_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "approvedleadlist_886431_value", "value", "TM_GetApprovedLeadCategories", "categoryName", "categoryName")), "string"),
				ProductName_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "approvedleadlist_140260_value", "value", "", "", "")), "string"),
				Musteri_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "approvedleadlist_198119_value", "value", "", "", "")), "string"),
				EstimatedDateStart_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "approvedleadlist_270363_value", "value", "", "", "")), "Date"),
				EstimatedDateEnd_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "approvedleadlist_334933_value", "value", "", "", "")), "Date"),
				LeadCode_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "approvedleadlist_531862_value", "value", "", "", "")), "string"),
				ReferenceId_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "approvedleadlist_329182_value", "value", "TMGetRefApproved", "referenceId", "referenceId")), "string"),
				OrderType_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toInteger(this, ReactSystemFunctions.value(this, "approvedleadlist_713966_value", "value", "", "key", "")), "number")
        }

		KuikaAppManager.showSpinner(this);
		
        if (true) {
        KuikaAppManager.showSpinner(this);
        }
        let result = await KuikaAppManager.ApiRequest(this, "ApprovedLeadList/ApprovedLeadListComponent_198119_onChange", localVar)
        if (!KMainFunctions.IsResStatus2XX(result)) return true;

			stateVars.TM_GetApprovedLeads = result?.data.tM_GetApprovedLeads;
			
			this.props.form?.setFieldsValue(formVars);
			
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.ApprovedLeadListComponent_198119_onChange1_();
                  resolve();
                });
          })



        
        KuikaAppManager.hideSpinner(this);
        return isErrorOccurred;
    }
		ApprovedLeadListComponent_198119_onChange1_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }

				
				stateVars.dataSource_3547 = stateVars.TM_GetApprovedLeads ?? this.state.TM_GetApprovedLeads;
				formVars.approvedleadlist_899217_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetApprovedLeads !== undefined ? (stateVars.TM_GetApprovedLeads?.length > 0 ? stateVars.TM_GetApprovedLeads[0].magazaAdi : null) : (this.state.TM_GetApprovedLeads?.length > 0 ? this.state.TM_GetApprovedLeads[0].magazaAdi : null)));

				formVars.approvedleadlist_226426_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetApprovedLeads !== undefined ? (stateVars.TM_GetApprovedLeads?.length > 0 ? stateVars.TM_GetApprovedLeads[0].kategoriAdi : null) : (this.state.TM_GetApprovedLeads?.length > 0 ? this.state.TM_GetApprovedLeads[0].kategoriAdi : null)));

				formVars.approvedleadlist_328471_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetApprovedLeads !== undefined ? (stateVars.TM_GetApprovedLeads?.length > 0 ? stateVars.TM_GetApprovedLeads[0].kategoriAdi : null) : (this.state.TM_GetApprovedLeads?.length > 0 ? this.state.TM_GetApprovedLeads[0].kategoriAdi : null)));

				formVars.approvedleadlist_758913_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetApprovedLeads !== undefined ? (stateVars.TM_GetApprovedLeads?.length > 0 ? stateVars.TM_GetApprovedLeads[0].kategoriAdi : null) : (this.state.TM_GetApprovedLeads?.length > 0 ? this.state.TM_GetApprovedLeads[0].kategoriAdi : null)));

				formVars.approvedleadlist_47950_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetApprovedLeads !== undefined ? (stateVars.TM_GetApprovedLeads?.length > 0 ? stateVars.TM_GetApprovedLeads[0].urunAdi : null) : (this.state.TM_GetApprovedLeads?.length > 0 ? this.state.TM_GetApprovedLeads[0].urunAdi : null)));

				formVars.approvedleadlist_941802_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetApprovedLeads !== undefined ? (stateVars.TM_GetApprovedLeads?.length > 0 ? stateVars.TM_GetApprovedLeads[0].musteriAdiSoyadi : null) : (this.state.TM_GetApprovedLeads?.length > 0 ? this.state.TM_GetApprovedLeads[0].musteriAdiSoyadi : null)));

				formVars.approvedleadlist_18630_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetApprovedLeads !== undefined ? (stateVars.TM_GetApprovedLeads?.length > 0 ? stateVars.TM_GetApprovedLeads[0].referansAdiSoyadi : null) : (this.state.TM_GetApprovedLeads?.length > 0 ? this.state.TM_GetApprovedLeads[0].referansAdiSoyadi : null)));

				formVars.approvedleadlist_746483_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetApprovedLeads !== undefined ? (stateVars.TM_GetApprovedLeads?.length > 0 ? stateVars.TM_GetApprovedLeads[0].takipDurumu : null) : (this.state.TM_GetApprovedLeads?.length > 0 ? this.state.TM_GetApprovedLeads[0].takipDurumu : null)));

				formVars.approvedleadlist_887947_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetApprovedLeads !== undefined ? (stateVars.TM_GetApprovedLeads?.length > 0 ? stateVars.TM_GetApprovedLeads[0].takipDurumu : null) : (this.state.TM_GetApprovedLeads?.length > 0 ? this.state.TM_GetApprovedLeads[0].takipDurumu : null)));

				formVars.approvedleadlist_488433_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetApprovedLeads !== undefined ? (stateVars.TM_GetApprovedLeads?.length > 0 ? stateVars.TM_GetApprovedLeads[0].sonrakiAdim : null) : (this.state.TM_GetApprovedLeads?.length > 0 ? this.state.TM_GetApprovedLeads[0].sonrakiAdim : null)));

				formVars.approvedleadlist_312740_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetApprovedLeads !== undefined ? (stateVars.TM_GetApprovedLeads?.length > 0 ? stateVars.TM_GetApprovedLeads[0].tahminiTeslimatTarihi : null) : (this.state.TM_GetApprovedLeads?.length > 0 ? this.state.TM_GetApprovedLeads[0].tahminiTeslimatTarihi : null)));

				formVars.approvedleadlist_252762_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetApprovedLeads !== undefined ? (stateVars.TM_GetApprovedLeads?.length > 0 ? stateVars.TM_GetApprovedLeads[0].olusturanKullanici : null) : (this.state.TM_GetApprovedLeads?.length > 0 ? this.state.TM_GetApprovedLeads[0].olusturanKullanici : null)));

				formVars.approvedleadlist_402662_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetApprovedLeads !== undefined ? (stateVars.TM_GetApprovedLeads?.length > 0 ? stateVars.TM_GetApprovedLeads[0].magazaAdi : null) : (this.state.TM_GetApprovedLeads?.length > 0 ? this.state.TM_GetApprovedLeads[0].magazaAdi : null)));

				formVars.approvedleadlist_423795_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetApprovedLeads !== undefined ? (stateVars.TM_GetApprovedLeads?.length > 0 ? stateVars.TM_GetApprovedLeads[0].urunKodu : null) : (this.state.TM_GetApprovedLeads?.length > 0 ? this.state.TM_GetApprovedLeads[0].urunKodu : null)));

				formVars.approvedleadlist_859294_value = ReactSystemFunctions.value(this, (stateVars.TM_GetApprovedLeads !== undefined ? (stateVars.TM_GetApprovedLeads?.length > 0 ? stateVars.TM_GetApprovedLeads[0].urunAdi : null) : (this.state.TM_GetApprovedLeads?.length > 0 ? this.state.TM_GetApprovedLeads[0].urunAdi : null)));


		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

            
            return isErrorOccurred;
        }




    ApprovedLeadListComponent_329182_onChange = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
		KuikaAppManager.increaseServerRequestCount();

        let localVar = {
				StoreId_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "approvedleadlist_51248_value", "value", "TM_GetApprovedLeadStores", "storeId", "storeId")), "string"),
				CategoryName_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "approvedleadlist_886431_value", "value", "TM_GetApprovedLeadCategories", "categoryName", "categoryName")), "string"),
				ProductName_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "approvedleadlist_140260_value", "value", "", "", "")), "string"),
				Musteri_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "approvedleadlist_198119_value", "value", "", "", "")), "string"),
				EstimatedDateStart_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "approvedleadlist_270363_value", "value", "", "", "")), "Date"),
				EstimatedDateEnd_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "approvedleadlist_334933_value", "value", "", "", "")), "Date"),
				LeadCode_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "approvedleadlist_531862_value", "value", "", "", "")), "string"),
				ReferenceId_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "approvedleadlist_329182_value", "value", "TMGetRefApproved", "referenceId", "referenceId")), "string"),
				OrderType_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toInteger(this, ReactSystemFunctions.value(this, "approvedleadlist_713966_value", "value", "", "key", "")), "number")
        }

		KuikaAppManager.showSpinner(this);
		
        if (true) {
        KuikaAppManager.showSpinner(this);
        }
        let result = await KuikaAppManager.ApiRequest(this, "ApprovedLeadList/ApprovedLeadListComponent_329182_onChange", localVar)
        if (!KMainFunctions.IsResStatus2XX(result)) return true;

			stateVars.TM_GetApprovedLeads = result?.data.tM_GetApprovedLeads;
			
			this.props.form?.setFieldsValue(formVars);
			
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.ApprovedLeadListComponent_329182_onChange1_();
                  resolve();
                });
          })



        
        KuikaAppManager.hideSpinner(this);
        return isErrorOccurred;
    }
		ApprovedLeadListComponent_329182_onChange1_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }

				
				stateVars.dataSource_3547 = stateVars.TM_GetApprovedLeads ?? this.state.TM_GetApprovedLeads;
				formVars.approvedleadlist_899217_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetApprovedLeads !== undefined ? (stateVars.TM_GetApprovedLeads?.length > 0 ? stateVars.TM_GetApprovedLeads[0].magazaAdi : null) : (this.state.TM_GetApprovedLeads?.length > 0 ? this.state.TM_GetApprovedLeads[0].magazaAdi : null)));

				formVars.approvedleadlist_226426_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetApprovedLeads !== undefined ? (stateVars.TM_GetApprovedLeads?.length > 0 ? stateVars.TM_GetApprovedLeads[0].kategoriAdi : null) : (this.state.TM_GetApprovedLeads?.length > 0 ? this.state.TM_GetApprovedLeads[0].kategoriAdi : null)));

				formVars.approvedleadlist_328471_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetApprovedLeads !== undefined ? (stateVars.TM_GetApprovedLeads?.length > 0 ? stateVars.TM_GetApprovedLeads[0].kategoriAdi : null) : (this.state.TM_GetApprovedLeads?.length > 0 ? this.state.TM_GetApprovedLeads[0].kategoriAdi : null)));

				formVars.approvedleadlist_758913_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetApprovedLeads !== undefined ? (stateVars.TM_GetApprovedLeads?.length > 0 ? stateVars.TM_GetApprovedLeads[0].kategoriAdi : null) : (this.state.TM_GetApprovedLeads?.length > 0 ? this.state.TM_GetApprovedLeads[0].kategoriAdi : null)));

				formVars.approvedleadlist_47950_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetApprovedLeads !== undefined ? (stateVars.TM_GetApprovedLeads?.length > 0 ? stateVars.TM_GetApprovedLeads[0].urunAdi : null) : (this.state.TM_GetApprovedLeads?.length > 0 ? this.state.TM_GetApprovedLeads[0].urunAdi : null)));

				formVars.approvedleadlist_941802_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetApprovedLeads !== undefined ? (stateVars.TM_GetApprovedLeads?.length > 0 ? stateVars.TM_GetApprovedLeads[0].musteriAdiSoyadi : null) : (this.state.TM_GetApprovedLeads?.length > 0 ? this.state.TM_GetApprovedLeads[0].musteriAdiSoyadi : null)));

				formVars.approvedleadlist_18630_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetApprovedLeads !== undefined ? (stateVars.TM_GetApprovedLeads?.length > 0 ? stateVars.TM_GetApprovedLeads[0].referansAdiSoyadi : null) : (this.state.TM_GetApprovedLeads?.length > 0 ? this.state.TM_GetApprovedLeads[0].referansAdiSoyadi : null)));

				formVars.approvedleadlist_746483_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetApprovedLeads !== undefined ? (stateVars.TM_GetApprovedLeads?.length > 0 ? stateVars.TM_GetApprovedLeads[0].takipDurumu : null) : (this.state.TM_GetApprovedLeads?.length > 0 ? this.state.TM_GetApprovedLeads[0].takipDurumu : null)));

				formVars.approvedleadlist_887947_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetApprovedLeads !== undefined ? (stateVars.TM_GetApprovedLeads?.length > 0 ? stateVars.TM_GetApprovedLeads[0].takipDurumu : null) : (this.state.TM_GetApprovedLeads?.length > 0 ? this.state.TM_GetApprovedLeads[0].takipDurumu : null)));

				formVars.approvedleadlist_488433_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetApprovedLeads !== undefined ? (stateVars.TM_GetApprovedLeads?.length > 0 ? stateVars.TM_GetApprovedLeads[0].sonrakiAdim : null) : (this.state.TM_GetApprovedLeads?.length > 0 ? this.state.TM_GetApprovedLeads[0].sonrakiAdim : null)));

				formVars.approvedleadlist_312740_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetApprovedLeads !== undefined ? (stateVars.TM_GetApprovedLeads?.length > 0 ? stateVars.TM_GetApprovedLeads[0].tahminiTeslimatTarihi : null) : (this.state.TM_GetApprovedLeads?.length > 0 ? this.state.TM_GetApprovedLeads[0].tahminiTeslimatTarihi : null)));

				formVars.approvedleadlist_252762_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetApprovedLeads !== undefined ? (stateVars.TM_GetApprovedLeads?.length > 0 ? stateVars.TM_GetApprovedLeads[0].olusturanKullanici : null) : (this.state.TM_GetApprovedLeads?.length > 0 ? this.state.TM_GetApprovedLeads[0].olusturanKullanici : null)));

				formVars.approvedleadlist_402662_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetApprovedLeads !== undefined ? (stateVars.TM_GetApprovedLeads?.length > 0 ? stateVars.TM_GetApprovedLeads[0].magazaAdi : null) : (this.state.TM_GetApprovedLeads?.length > 0 ? this.state.TM_GetApprovedLeads[0].magazaAdi : null)));

				formVars.approvedleadlist_423795_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetApprovedLeads !== undefined ? (stateVars.TM_GetApprovedLeads?.length > 0 ? stateVars.TM_GetApprovedLeads[0].urunKodu : null) : (this.state.TM_GetApprovedLeads?.length > 0 ? this.state.TM_GetApprovedLeads[0].urunKodu : null)));

				formVars.approvedleadlist_859294_value = ReactSystemFunctions.value(this, (stateVars.TM_GetApprovedLeads !== undefined ? (stateVars.TM_GetApprovedLeads?.length > 0 ? stateVars.TM_GetApprovedLeads[0].urunAdi : null) : (this.state.TM_GetApprovedLeads?.length > 0 ? this.state.TM_GetApprovedLeads[0].urunAdi : null)));


		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

            
            return isErrorOccurred;
        }




    ApprovedLeadListComponent_893327_onClick = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
		KuikaAppManager.increaseServerRequestCount();

        let localVar = {
				StoreId_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "approvedleadlist_51248_value", "value", "TM_GetApprovedLeadStores", "storeId", "storeId")), "string"),
				CategoryName_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "approvedleadlist_886431_value", "value", "TM_GetApprovedLeadCategories", "categoryName", "categoryName")), "string"),
				ProductName_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "approvedleadlist_140260_value", "value", "", "", "")), "string"),
				Musteri_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "approvedleadlist_198119_value", "value", "", "", "")), "string"),
				EstimatedDateStart_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "approvedleadlist_270363_value", "value", "", "", "")), "Date"),
				EstimatedDateEnd_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "approvedleadlist_334933_value", "value", "", "", "")), "Date"),
				LeadCode_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "approvedleadlist_531862_value", "value", "", "", "")), "string"),
				ReferenceId_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "approvedleadlist_329182_value", "value", "TMGetRefApproved", "referenceId", "referenceId")), "string"),
				OrderType_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toInteger(this, ReactSystemFunctions.value(this, "approvedleadlist_713966_value", "value", "", "key", "")), "number")
        }

		KuikaAppManager.showSpinner(this);
		
        if (true) {
        KuikaAppManager.showSpinner(this);
        }
        let result = await KuikaAppManager.ApiRequest(this, "ApprovedLeadList/ApprovedLeadListComponent_893327_onClick", localVar)
        if (!KMainFunctions.IsResStatus2XX(result)) return true;

			stateVars.TM_GetApprovedLeads = result?.data.tM_GetApprovedLeads;
			
			this.props.form?.setFieldsValue(formVars);
			
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.ApprovedLeadListComponent_893327_onClick1_();
                  resolve();
                });
          })



        
        KuikaAppManager.hideSpinner(this);
        return isErrorOccurred;
    }
		ApprovedLeadListComponent_893327_onClick1_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }

				
				stateVars.dataSource_3547 = stateVars.TM_GetApprovedLeads ?? this.state.TM_GetApprovedLeads;
				formVars.approvedleadlist_899217_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetApprovedLeads !== undefined ? (stateVars.TM_GetApprovedLeads?.length > 0 ? stateVars.TM_GetApprovedLeads[0].magazaAdi : null) : (this.state.TM_GetApprovedLeads?.length > 0 ? this.state.TM_GetApprovedLeads[0].magazaAdi : null)));

				formVars.approvedleadlist_226426_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetApprovedLeads !== undefined ? (stateVars.TM_GetApprovedLeads?.length > 0 ? stateVars.TM_GetApprovedLeads[0].kategoriAdi : null) : (this.state.TM_GetApprovedLeads?.length > 0 ? this.state.TM_GetApprovedLeads[0].kategoriAdi : null)));

				formVars.approvedleadlist_328471_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetApprovedLeads !== undefined ? (stateVars.TM_GetApprovedLeads?.length > 0 ? stateVars.TM_GetApprovedLeads[0].kategoriAdi : null) : (this.state.TM_GetApprovedLeads?.length > 0 ? this.state.TM_GetApprovedLeads[0].kategoriAdi : null)));

				formVars.approvedleadlist_758913_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetApprovedLeads !== undefined ? (stateVars.TM_GetApprovedLeads?.length > 0 ? stateVars.TM_GetApprovedLeads[0].kategoriAdi : null) : (this.state.TM_GetApprovedLeads?.length > 0 ? this.state.TM_GetApprovedLeads[0].kategoriAdi : null)));

				formVars.approvedleadlist_47950_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetApprovedLeads !== undefined ? (stateVars.TM_GetApprovedLeads?.length > 0 ? stateVars.TM_GetApprovedLeads[0].urunAdi : null) : (this.state.TM_GetApprovedLeads?.length > 0 ? this.state.TM_GetApprovedLeads[0].urunAdi : null)));

				formVars.approvedleadlist_941802_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetApprovedLeads !== undefined ? (stateVars.TM_GetApprovedLeads?.length > 0 ? stateVars.TM_GetApprovedLeads[0].musteriAdiSoyadi : null) : (this.state.TM_GetApprovedLeads?.length > 0 ? this.state.TM_GetApprovedLeads[0].musteriAdiSoyadi : null)));

				formVars.approvedleadlist_18630_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetApprovedLeads !== undefined ? (stateVars.TM_GetApprovedLeads?.length > 0 ? stateVars.TM_GetApprovedLeads[0].referansAdiSoyadi : null) : (this.state.TM_GetApprovedLeads?.length > 0 ? this.state.TM_GetApprovedLeads[0].referansAdiSoyadi : null)));

				formVars.approvedleadlist_746483_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetApprovedLeads !== undefined ? (stateVars.TM_GetApprovedLeads?.length > 0 ? stateVars.TM_GetApprovedLeads[0].takipDurumu : null) : (this.state.TM_GetApprovedLeads?.length > 0 ? this.state.TM_GetApprovedLeads[0].takipDurumu : null)));

				formVars.approvedleadlist_887947_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetApprovedLeads !== undefined ? (stateVars.TM_GetApprovedLeads?.length > 0 ? stateVars.TM_GetApprovedLeads[0].takipDurumu : null) : (this.state.TM_GetApprovedLeads?.length > 0 ? this.state.TM_GetApprovedLeads[0].takipDurumu : null)));

				formVars.approvedleadlist_488433_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetApprovedLeads !== undefined ? (stateVars.TM_GetApprovedLeads?.length > 0 ? stateVars.TM_GetApprovedLeads[0].sonrakiAdim : null) : (this.state.TM_GetApprovedLeads?.length > 0 ? this.state.TM_GetApprovedLeads[0].sonrakiAdim : null)));

				formVars.approvedleadlist_312740_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetApprovedLeads !== undefined ? (stateVars.TM_GetApprovedLeads?.length > 0 ? stateVars.TM_GetApprovedLeads[0].tahminiTeslimatTarihi : null) : (this.state.TM_GetApprovedLeads?.length > 0 ? this.state.TM_GetApprovedLeads[0].tahminiTeslimatTarihi : null)));

				formVars.approvedleadlist_252762_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetApprovedLeads !== undefined ? (stateVars.TM_GetApprovedLeads?.length > 0 ? stateVars.TM_GetApprovedLeads[0].olusturanKullanici : null) : (this.state.TM_GetApprovedLeads?.length > 0 ? this.state.TM_GetApprovedLeads[0].olusturanKullanici : null)));

				formVars.approvedleadlist_402662_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetApprovedLeads !== undefined ? (stateVars.TM_GetApprovedLeads?.length > 0 ? stateVars.TM_GetApprovedLeads[0].magazaAdi : null) : (this.state.TM_GetApprovedLeads?.length > 0 ? this.state.TM_GetApprovedLeads[0].magazaAdi : null)));

				formVars.approvedleadlist_423795_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetApprovedLeads !== undefined ? (stateVars.TM_GetApprovedLeads?.length > 0 ? stateVars.TM_GetApprovedLeads[0].urunKodu : null) : (this.state.TM_GetApprovedLeads?.length > 0 ? this.state.TM_GetApprovedLeads[0].urunKodu : null)));

				formVars.approvedleadlist_859294_value = ReactSystemFunctions.value(this, (stateVars.TM_GetApprovedLeads !== undefined ? (stateVars.TM_GetApprovedLeads?.length > 0 ? stateVars.TM_GetApprovedLeads[0].urunAdi : null) : (this.state.TM_GetApprovedLeads?.length > 0 ? this.state.TM_GetApprovedLeads[0].urunAdi : null)));


		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

            
            return isErrorOccurred;
        }




		ApprovedLeadListComponent_134501_onClick = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
KuikaAppManager.showSpinner(this);

				stateVars.SetValueOf = await ReactSystemFunctions.setValueOf(this, ReactSystemFunctions.convertToTypeByName("approvedleadlist_51248_value", "string"), null, null, false);
				stateVars.SetValueOf = await ReactSystemFunctions.setValueOf(this, ReactSystemFunctions.convertToTypeByName("approvedleadlist_886431_value", "string"), null, null, false);
				stateVars.SetValueOf = await ReactSystemFunctions.setValueOf(this, ReactSystemFunctions.convertToTypeByName("approvedleadlist_713966_value", "string"), null, null, "Key");
				stateVars.SetValueOf = await ReactSystemFunctions.setValueOf(this, ReactSystemFunctions.convertToTypeByName("approvedleadlist_140260_value", "string"), null, null, false);
				stateVars.SetValueOf = await ReactSystemFunctions.setValueOf(this, ReactSystemFunctions.convertToTypeByName("approvedleadlist_198119_value", "string"), null, null, false);
				stateVars.SetValueOf = await ReactSystemFunctions.setValueOf(this, ReactSystemFunctions.convertToTypeByName("approvedleadlist_270363_value", "string"), null, null, false);
				stateVars.SetValueOf = await ReactSystemFunctions.setValueOf(this, ReactSystemFunctions.convertToTypeByName("approvedleadlist_334933_value", "string"), null, null, false);
				stateVars.SetValueOf = await ReactSystemFunctions.setValueOf(this, ReactSystemFunctions.convertToTypeByName("approvedleadlist_329182_value", "string"), null, null, false);

		this.props.form?.setFieldsValue(formVars);
		
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.ApprovedLeadListComponent_134501_onClick1_();
                  resolve();
                });
          })

            
            return isErrorOccurred;
        }
    ApprovedLeadListComponent_134501_onClick1_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
		KuikaAppManager.increaseServerRequestCount();

        let localVar = {
				StoreId_0: ReactSystemFunctions.convertToTypeByName(null, "string"),
				CategoryName_0: ReactSystemFunctions.convertToTypeByName(null, "string"),
				ProductName_0: ReactSystemFunctions.convertToTypeByName(null, "string"),
				Musteri_0: ReactSystemFunctions.convertToTypeByName(null, "string"),
				EstimatedDateStart_0: ReactSystemFunctions.convertToTypeByName(null, "Date"),
				EstimatedDateEnd_0: ReactSystemFunctions.convertToTypeByName(null, "Date"),
				LeadCode_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "approvedleadlist_531862_value", "value", "", "", "")), "string"),
				ReferenceId_0: ReactSystemFunctions.convertToTypeByName(null, "string"),
				OrderType_0: ReactSystemFunctions.convertToTypeByName(0, "number")
        }

		
        if (true) {
        KuikaAppManager.showSpinner(this);
        }
        let result = await KuikaAppManager.ApiRequest(this, "ApprovedLeadList/ApprovedLeadListComponent_134501_onClick1_", localVar)
        if (!KMainFunctions.IsResStatus2XX(result)) return true;

			stateVars.TM_GetApprovedLeads = result?.data.tM_GetApprovedLeads;
			
			this.props.form?.setFieldsValue(formVars);
			
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.ApprovedLeadListComponent_134501_onClick2_();
                  resolve();
                });
          })



        
        KuikaAppManager.hideSpinner(this);
        return isErrorOccurred;
    }
		ApprovedLeadListComponent_134501_onClick2_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }

				
				stateVars.dataSource_3547 = stateVars.TM_GetApprovedLeads ?? this.state.TM_GetApprovedLeads;
				formVars.approvedleadlist_899217_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetApprovedLeads !== undefined ? (stateVars.TM_GetApprovedLeads?.length > 0 ? stateVars.TM_GetApprovedLeads[0].magazaAdi : null) : (this.state.TM_GetApprovedLeads?.length > 0 ? this.state.TM_GetApprovedLeads[0].magazaAdi : null)));

				formVars.approvedleadlist_226426_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetApprovedLeads !== undefined ? (stateVars.TM_GetApprovedLeads?.length > 0 ? stateVars.TM_GetApprovedLeads[0].kategoriAdi : null) : (this.state.TM_GetApprovedLeads?.length > 0 ? this.state.TM_GetApprovedLeads[0].kategoriAdi : null)));

				formVars.approvedleadlist_328471_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetApprovedLeads !== undefined ? (stateVars.TM_GetApprovedLeads?.length > 0 ? stateVars.TM_GetApprovedLeads[0].kategoriAdi : null) : (this.state.TM_GetApprovedLeads?.length > 0 ? this.state.TM_GetApprovedLeads[0].kategoriAdi : null)));

				formVars.approvedleadlist_758913_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetApprovedLeads !== undefined ? (stateVars.TM_GetApprovedLeads?.length > 0 ? stateVars.TM_GetApprovedLeads[0].kategoriAdi : null) : (this.state.TM_GetApprovedLeads?.length > 0 ? this.state.TM_GetApprovedLeads[0].kategoriAdi : null)));

				formVars.approvedleadlist_47950_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetApprovedLeads !== undefined ? (stateVars.TM_GetApprovedLeads?.length > 0 ? stateVars.TM_GetApprovedLeads[0].urunAdi : null) : (this.state.TM_GetApprovedLeads?.length > 0 ? this.state.TM_GetApprovedLeads[0].urunAdi : null)));

				formVars.approvedleadlist_941802_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetApprovedLeads !== undefined ? (stateVars.TM_GetApprovedLeads?.length > 0 ? stateVars.TM_GetApprovedLeads[0].musteriAdiSoyadi : null) : (this.state.TM_GetApprovedLeads?.length > 0 ? this.state.TM_GetApprovedLeads[0].musteriAdiSoyadi : null)));

				formVars.approvedleadlist_18630_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetApprovedLeads !== undefined ? (stateVars.TM_GetApprovedLeads?.length > 0 ? stateVars.TM_GetApprovedLeads[0].referansAdiSoyadi : null) : (this.state.TM_GetApprovedLeads?.length > 0 ? this.state.TM_GetApprovedLeads[0].referansAdiSoyadi : null)));

				formVars.approvedleadlist_746483_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetApprovedLeads !== undefined ? (stateVars.TM_GetApprovedLeads?.length > 0 ? stateVars.TM_GetApprovedLeads[0].takipDurumu : null) : (this.state.TM_GetApprovedLeads?.length > 0 ? this.state.TM_GetApprovedLeads[0].takipDurumu : null)));

				formVars.approvedleadlist_887947_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetApprovedLeads !== undefined ? (stateVars.TM_GetApprovedLeads?.length > 0 ? stateVars.TM_GetApprovedLeads[0].takipDurumu : null) : (this.state.TM_GetApprovedLeads?.length > 0 ? this.state.TM_GetApprovedLeads[0].takipDurumu : null)));

				formVars.approvedleadlist_488433_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetApprovedLeads !== undefined ? (stateVars.TM_GetApprovedLeads?.length > 0 ? stateVars.TM_GetApprovedLeads[0].sonrakiAdim : null) : (this.state.TM_GetApprovedLeads?.length > 0 ? this.state.TM_GetApprovedLeads[0].sonrakiAdim : null)));

				formVars.approvedleadlist_312740_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetApprovedLeads !== undefined ? (stateVars.TM_GetApprovedLeads?.length > 0 ? stateVars.TM_GetApprovedLeads[0].tahminiTeslimatTarihi : null) : (this.state.TM_GetApprovedLeads?.length > 0 ? this.state.TM_GetApprovedLeads[0].tahminiTeslimatTarihi : null)));

				formVars.approvedleadlist_252762_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetApprovedLeads !== undefined ? (stateVars.TM_GetApprovedLeads?.length > 0 ? stateVars.TM_GetApprovedLeads[0].olusturanKullanici : null) : (this.state.TM_GetApprovedLeads?.length > 0 ? this.state.TM_GetApprovedLeads[0].olusturanKullanici : null)));

				formVars.approvedleadlist_402662_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetApprovedLeads !== undefined ? (stateVars.TM_GetApprovedLeads?.length > 0 ? stateVars.TM_GetApprovedLeads[0].magazaAdi : null) : (this.state.TM_GetApprovedLeads?.length > 0 ? this.state.TM_GetApprovedLeads[0].magazaAdi : null)));

				formVars.approvedleadlist_423795_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetApprovedLeads !== undefined ? (stateVars.TM_GetApprovedLeads?.length > 0 ? stateVars.TM_GetApprovedLeads[0].urunKodu : null) : (this.state.TM_GetApprovedLeads?.length > 0 ? this.state.TM_GetApprovedLeads[0].urunKodu : null)));

				formVars.approvedleadlist_859294_value = ReactSystemFunctions.value(this, (stateVars.TM_GetApprovedLeads !== undefined ? (stateVars.TM_GetApprovedLeads?.length > 0 ? stateVars.TM_GetApprovedLeads[0].urunAdi : null) : (this.state.TM_GetApprovedLeads?.length > 0 ? this.state.TM_GetApprovedLeads[0].urunAdi : null)));


		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

            
            return isErrorOccurred;
        }





    ApprovedLeadListComponent_531862_onChange = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
		KuikaAppManager.increaseServerRequestCount();

        let localVar = {
				StoreId_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "approvedleadlist_51248_value", "value", "TM_GetApprovedLeadStores", "storeId", "storeId")), "string"),
				CategoryName_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "approvedleadlist_886431_value", "value", "TM_GetApprovedLeadCategories", "categoryName", "categoryName")), "string"),
				ProductName_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "approvedleadlist_140260_value", "value", "", "", "")), "string"),
				Musteri_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "approvedleadlist_198119_value", "value", "", "", "")), "string"),
				EstimatedDateStart_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "approvedleadlist_270363_value", "value", "", "", "")), "Date"),
				EstimatedDateEnd_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "approvedleadlist_334933_value", "value", "", "", "")), "Date"),
				LeadCode_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "approvedleadlist_531862_value", "value", "", "", "")), "string"),
				ReferenceId_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "approvedleadlist_329182_value", "value", "TMGetRefApproved", "referenceId", "referenceId")), "string"),
				OrderType_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toInteger(this, ReactSystemFunctions.value(this, "approvedleadlist_713966_value", "value", "", "key", "")), "number")
        }

		KuikaAppManager.showSpinner(this);
		
        if (true) {
        KuikaAppManager.showSpinner(this);
        }
        let result = await KuikaAppManager.ApiRequest(this, "ApprovedLeadList/ApprovedLeadListComponent_531862_onChange", localVar)
        if (!KMainFunctions.IsResStatus2XX(result)) return true;

			stateVars.TM_GetApprovedLeads = result?.data.tM_GetApprovedLeads;
			
			this.props.form?.setFieldsValue(formVars);
			
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.ApprovedLeadListComponent_531862_onChange1_();
                  resolve();
                });
          })



        
        KuikaAppManager.hideSpinner(this);
        return isErrorOccurred;
    }
		ApprovedLeadListComponent_531862_onChange1_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }

				
				stateVars.dataSource_3547 = stateVars.TM_GetApprovedLeads ?? this.state.TM_GetApprovedLeads;
				formVars.approvedleadlist_899217_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetApprovedLeads !== undefined ? (stateVars.TM_GetApprovedLeads?.length > 0 ? stateVars.TM_GetApprovedLeads[0].magazaAdi : null) : (this.state.TM_GetApprovedLeads?.length > 0 ? this.state.TM_GetApprovedLeads[0].magazaAdi : null)));

				formVars.approvedleadlist_226426_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetApprovedLeads !== undefined ? (stateVars.TM_GetApprovedLeads?.length > 0 ? stateVars.TM_GetApprovedLeads[0].kategoriAdi : null) : (this.state.TM_GetApprovedLeads?.length > 0 ? this.state.TM_GetApprovedLeads[0].kategoriAdi : null)));

				formVars.approvedleadlist_328471_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetApprovedLeads !== undefined ? (stateVars.TM_GetApprovedLeads?.length > 0 ? stateVars.TM_GetApprovedLeads[0].kategoriAdi : null) : (this.state.TM_GetApprovedLeads?.length > 0 ? this.state.TM_GetApprovedLeads[0].kategoriAdi : null)));

				formVars.approvedleadlist_758913_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetApprovedLeads !== undefined ? (stateVars.TM_GetApprovedLeads?.length > 0 ? stateVars.TM_GetApprovedLeads[0].kategoriAdi : null) : (this.state.TM_GetApprovedLeads?.length > 0 ? this.state.TM_GetApprovedLeads[0].kategoriAdi : null)));

				formVars.approvedleadlist_47950_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetApprovedLeads !== undefined ? (stateVars.TM_GetApprovedLeads?.length > 0 ? stateVars.TM_GetApprovedLeads[0].urunAdi : null) : (this.state.TM_GetApprovedLeads?.length > 0 ? this.state.TM_GetApprovedLeads[0].urunAdi : null)));

				formVars.approvedleadlist_941802_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetApprovedLeads !== undefined ? (stateVars.TM_GetApprovedLeads?.length > 0 ? stateVars.TM_GetApprovedLeads[0].musteriAdiSoyadi : null) : (this.state.TM_GetApprovedLeads?.length > 0 ? this.state.TM_GetApprovedLeads[0].musteriAdiSoyadi : null)));

				formVars.approvedleadlist_18630_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetApprovedLeads !== undefined ? (stateVars.TM_GetApprovedLeads?.length > 0 ? stateVars.TM_GetApprovedLeads[0].referansAdiSoyadi : null) : (this.state.TM_GetApprovedLeads?.length > 0 ? this.state.TM_GetApprovedLeads[0].referansAdiSoyadi : null)));

				formVars.approvedleadlist_746483_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetApprovedLeads !== undefined ? (stateVars.TM_GetApprovedLeads?.length > 0 ? stateVars.TM_GetApprovedLeads[0].takipDurumu : null) : (this.state.TM_GetApprovedLeads?.length > 0 ? this.state.TM_GetApprovedLeads[0].takipDurumu : null)));

				formVars.approvedleadlist_887947_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetApprovedLeads !== undefined ? (stateVars.TM_GetApprovedLeads?.length > 0 ? stateVars.TM_GetApprovedLeads[0].takipDurumu : null) : (this.state.TM_GetApprovedLeads?.length > 0 ? this.state.TM_GetApprovedLeads[0].takipDurumu : null)));

				formVars.approvedleadlist_488433_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetApprovedLeads !== undefined ? (stateVars.TM_GetApprovedLeads?.length > 0 ? stateVars.TM_GetApprovedLeads[0].sonrakiAdim : null) : (this.state.TM_GetApprovedLeads?.length > 0 ? this.state.TM_GetApprovedLeads[0].sonrakiAdim : null)));

				formVars.approvedleadlist_312740_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetApprovedLeads !== undefined ? (stateVars.TM_GetApprovedLeads?.length > 0 ? stateVars.TM_GetApprovedLeads[0].tahminiTeslimatTarihi : null) : (this.state.TM_GetApprovedLeads?.length > 0 ? this.state.TM_GetApprovedLeads[0].tahminiTeslimatTarihi : null)));

				formVars.approvedleadlist_252762_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetApprovedLeads !== undefined ? (stateVars.TM_GetApprovedLeads?.length > 0 ? stateVars.TM_GetApprovedLeads[0].olusturanKullanici : null) : (this.state.TM_GetApprovedLeads?.length > 0 ? this.state.TM_GetApprovedLeads[0].olusturanKullanici : null)));

				formVars.approvedleadlist_402662_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetApprovedLeads !== undefined ? (stateVars.TM_GetApprovedLeads?.length > 0 ? stateVars.TM_GetApprovedLeads[0].magazaAdi : null) : (this.state.TM_GetApprovedLeads?.length > 0 ? this.state.TM_GetApprovedLeads[0].magazaAdi : null)));

				formVars.approvedleadlist_423795_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetApprovedLeads !== undefined ? (stateVars.TM_GetApprovedLeads?.length > 0 ? stateVars.TM_GetApprovedLeads[0].urunKodu : null) : (this.state.TM_GetApprovedLeads?.length > 0 ? this.state.TM_GetApprovedLeads[0].urunKodu : null)));

				formVars.approvedleadlist_859294_value = ReactSystemFunctions.value(this, (stateVars.TM_GetApprovedLeads !== undefined ? (stateVars.TM_GetApprovedLeads?.length > 0 ? stateVars.TM_GetApprovedLeads[0].urunAdi : null) : (this.state.TM_GetApprovedLeads?.length > 0 ? this.state.TM_GetApprovedLeads[0].urunAdi : null)));


		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

            
            return isErrorOccurred;
        }




		ApprovedLeadListComponent_889462_onClick = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
KuikaAppManager.showSpinner(this);

				stateVars.SetValueOf = await ReactSystemFunctions.setValueOf(this, ReactSystemFunctions.convertToTypeByName("approvedleadlist_531862_value", "string"), "", null, false);

		this.props.form?.setFieldsValue(formVars);
		
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.ApprovedLeadListComponent_889462_onClick1_();
                  resolve();
                });
          })

            
            return isErrorOccurred;
        }
    ApprovedLeadListComponent_889462_onClick1_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
		KuikaAppManager.increaseServerRequestCount();

        let localVar = {
				StoreId_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "approvedleadlist_51248_value", "value", "TM_GetApprovedLeadStores", "storeId", "storeId")), "string"),
				CategoryName_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "approvedleadlist_886431_value", "value", "TM_GetApprovedLeadCategories", "categoryName", "categoryName")), "string"),
				ProductName_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "approvedleadlist_140260_value", "value", "", "", "")), "string"),
				Musteri_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "approvedleadlist_198119_value", "value", "", "", "")), "string"),
				EstimatedDateStart_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "approvedleadlist_270363_value", "value", "", "", "")), "Date"),
				EstimatedDateEnd_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "approvedleadlist_334933_value", "value", "", "", "")), "Date"),
				LeadCode_0: ReactSystemFunctions.convertToTypeByName("", "string"),
				ReferenceId_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "approvedleadlist_329182_value", "value", "TMGetRefApproved", "referenceId", "referenceId")), "string"),
				OrderType_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toInteger(this, ReactSystemFunctions.value(this, "approvedleadlist_713966_value", "value", "", "key", "")), "number")
        }

		
        if (true) {
        KuikaAppManager.showSpinner(this);
        }
        let result = await KuikaAppManager.ApiRequest(this, "ApprovedLeadList/ApprovedLeadListComponent_889462_onClick1_", localVar)
        if (!KMainFunctions.IsResStatus2XX(result)) return true;

			stateVars.TM_GetApprovedLeads = result?.data.tM_GetApprovedLeads;
			
			this.props.form?.setFieldsValue(formVars);
			
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.ApprovedLeadListComponent_889462_onClick2_();
                  resolve();
                });
          })



        
        KuikaAppManager.hideSpinner(this);
        return isErrorOccurred;
    }
		ApprovedLeadListComponent_889462_onClick2_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }

				
				stateVars.dataSource_3547 = stateVars.TM_GetApprovedLeads ?? this.state.TM_GetApprovedLeads;
				formVars.approvedleadlist_899217_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetApprovedLeads !== undefined ? (stateVars.TM_GetApprovedLeads?.length > 0 ? stateVars.TM_GetApprovedLeads[0].magazaAdi : null) : (this.state.TM_GetApprovedLeads?.length > 0 ? this.state.TM_GetApprovedLeads[0].magazaAdi : null)));

				formVars.approvedleadlist_226426_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetApprovedLeads !== undefined ? (stateVars.TM_GetApprovedLeads?.length > 0 ? stateVars.TM_GetApprovedLeads[0].kategoriAdi : null) : (this.state.TM_GetApprovedLeads?.length > 0 ? this.state.TM_GetApprovedLeads[0].kategoriAdi : null)));

				formVars.approvedleadlist_328471_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetApprovedLeads !== undefined ? (stateVars.TM_GetApprovedLeads?.length > 0 ? stateVars.TM_GetApprovedLeads[0].kategoriAdi : null) : (this.state.TM_GetApprovedLeads?.length > 0 ? this.state.TM_GetApprovedLeads[0].kategoriAdi : null)));

				formVars.approvedleadlist_758913_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetApprovedLeads !== undefined ? (stateVars.TM_GetApprovedLeads?.length > 0 ? stateVars.TM_GetApprovedLeads[0].kategoriAdi : null) : (this.state.TM_GetApprovedLeads?.length > 0 ? this.state.TM_GetApprovedLeads[0].kategoriAdi : null)));

				formVars.approvedleadlist_47950_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetApprovedLeads !== undefined ? (stateVars.TM_GetApprovedLeads?.length > 0 ? stateVars.TM_GetApprovedLeads[0].urunAdi : null) : (this.state.TM_GetApprovedLeads?.length > 0 ? this.state.TM_GetApprovedLeads[0].urunAdi : null)));

				formVars.approvedleadlist_941802_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetApprovedLeads !== undefined ? (stateVars.TM_GetApprovedLeads?.length > 0 ? stateVars.TM_GetApprovedLeads[0].musteriAdiSoyadi : null) : (this.state.TM_GetApprovedLeads?.length > 0 ? this.state.TM_GetApprovedLeads[0].musteriAdiSoyadi : null)));

				formVars.approvedleadlist_18630_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetApprovedLeads !== undefined ? (stateVars.TM_GetApprovedLeads?.length > 0 ? stateVars.TM_GetApprovedLeads[0].referansAdiSoyadi : null) : (this.state.TM_GetApprovedLeads?.length > 0 ? this.state.TM_GetApprovedLeads[0].referansAdiSoyadi : null)));

				formVars.approvedleadlist_746483_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetApprovedLeads !== undefined ? (stateVars.TM_GetApprovedLeads?.length > 0 ? stateVars.TM_GetApprovedLeads[0].takipDurumu : null) : (this.state.TM_GetApprovedLeads?.length > 0 ? this.state.TM_GetApprovedLeads[0].takipDurumu : null)));

				formVars.approvedleadlist_887947_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetApprovedLeads !== undefined ? (stateVars.TM_GetApprovedLeads?.length > 0 ? stateVars.TM_GetApprovedLeads[0].takipDurumu : null) : (this.state.TM_GetApprovedLeads?.length > 0 ? this.state.TM_GetApprovedLeads[0].takipDurumu : null)));

				formVars.approvedleadlist_488433_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetApprovedLeads !== undefined ? (stateVars.TM_GetApprovedLeads?.length > 0 ? stateVars.TM_GetApprovedLeads[0].sonrakiAdim : null) : (this.state.TM_GetApprovedLeads?.length > 0 ? this.state.TM_GetApprovedLeads[0].sonrakiAdim : null)));

				formVars.approvedleadlist_312740_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetApprovedLeads !== undefined ? (stateVars.TM_GetApprovedLeads?.length > 0 ? stateVars.TM_GetApprovedLeads[0].tahminiTeslimatTarihi : null) : (this.state.TM_GetApprovedLeads?.length > 0 ? this.state.TM_GetApprovedLeads[0].tahminiTeslimatTarihi : null)));

				formVars.approvedleadlist_252762_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetApprovedLeads !== undefined ? (stateVars.TM_GetApprovedLeads?.length > 0 ? stateVars.TM_GetApprovedLeads[0].olusturanKullanici : null) : (this.state.TM_GetApprovedLeads?.length > 0 ? this.state.TM_GetApprovedLeads[0].olusturanKullanici : null)));

				formVars.approvedleadlist_402662_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetApprovedLeads !== undefined ? (stateVars.TM_GetApprovedLeads?.length > 0 ? stateVars.TM_GetApprovedLeads[0].magazaAdi : null) : (this.state.TM_GetApprovedLeads?.length > 0 ? this.state.TM_GetApprovedLeads[0].magazaAdi : null)));

				formVars.approvedleadlist_423795_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetApprovedLeads !== undefined ? (stateVars.TM_GetApprovedLeads?.length > 0 ? stateVars.TM_GetApprovedLeads[0].urunKodu : null) : (this.state.TM_GetApprovedLeads?.length > 0 ? this.state.TM_GetApprovedLeads[0].urunKodu : null)));

				formVars.approvedleadlist_859294_value = ReactSystemFunctions.value(this, (stateVars.TM_GetApprovedLeads !== undefined ? (stateVars.TM_GetApprovedLeads?.length > 0 ? stateVars.TM_GetApprovedLeads[0].urunAdi : null) : (this.state.TM_GetApprovedLeads?.length > 0 ? this.state.TM_GetApprovedLeads[0].urunAdi : null)));


		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

            
            return isErrorOccurred;
        }





    ApprovedLeadListComponent_463912_onChange = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
		KuikaAppManager.increaseServerRequestCount();

        let localVar = {
				StoreId_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "approvedleadlist_463912_value", "value", "TM_GetApprovedLeadStores", "storeId", "storeId")), "string"),
				CategoryName_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "approvedleadlist_198382_value", "value", "TM_GetApprovedLeadCategories", "categoryName", "categoryName")), "string"),
				ProductName_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "approvedleadlist_84425_value", "value", "", "", "")), "string"),
				Referance_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "approvedleadlist_847615_value", "value", "", "", "")), "string"),
				Dial_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "approvedleadlist_999251_value", "value", "", "", "")), "string"),
				Bracelet_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "approvedleadlist_79693_value", "value", "", "", "")), "string")
        }

		KuikaAppManager.showSpinner(this);
		
        if (true) {
        KuikaAppManager.showSpinner(this);
        }
        let result = await KuikaAppManager.ApiRequest(this, "ApprovedLeadList/ApprovedLeadListComponent_463912_onChange", localVar)
        if (!KMainFunctions.IsResStatus2XX(result)) return true;

			stateVars.TMTotalStoreApprovedLead = result?.data.tmTotalStoreApprovedLead;
			
			this.props.form?.setFieldsValue(formVars);
			
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.ApprovedLeadListComponent_463912_onChange1_();
                  resolve();
                });
          })



        
        KuikaAppManager.hideSpinner(this);
        return isErrorOccurred;
    }
		ApprovedLeadListComponent_463912_onChange1_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }

				
				stateVars.dataSource_633056 = stateVars.TMTotalStoreApprovedLead ?? this.state.TMTotalStoreApprovedLead;
				formVars.approvedleadlist_247267_value = ReactSystemFunctions.value(this, (stateVars.TMTotalStoreApprovedLead !== undefined ? (stateVars.TMTotalStoreApprovedLead?.length > 0 ? stateVars.TMTotalStoreApprovedLead[0].adedi : null) : (this.state.TMTotalStoreApprovedLead?.length > 0 ? this.state.TMTotalStoreApprovedLead[0].adedi : null)));


		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

            
            return isErrorOccurred;
        }




    ApprovedLeadListComponent_198382_onChange = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
		KuikaAppManager.increaseServerRequestCount();

        let localVar = {
				StoreId_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "approvedleadlist_463912_value", "value", "TM_GetApprovedLeadStores", "storeId", "storeId")), "string"),
				CategoryName_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "approvedleadlist_198382_value", "value", "TM_GetApprovedLeadCategories", "categoryName", "categoryName")), "string"),
				ProductName_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "approvedleadlist_84425_value", "value", "", "", "")), "string"),
				Referance_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "approvedleadlist_847615_value", "value", "", "", "")), "string"),
				Dial_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "approvedleadlist_999251_value", "value", "", "", "")), "string"),
				Bracelet_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "approvedleadlist_79693_value", "value", "", "", "")), "string")
        }

		KuikaAppManager.showSpinner(this);
		
        if (true) {
        KuikaAppManager.showSpinner(this);
        }
        let result = await KuikaAppManager.ApiRequest(this, "ApprovedLeadList/ApprovedLeadListComponent_198382_onChange", localVar)
        if (!KMainFunctions.IsResStatus2XX(result)) return true;

			stateVars.TMTotalStoreApprovedLead = result?.data.tmTotalStoreApprovedLead;
			
			this.props.form?.setFieldsValue(formVars);
			
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.ApprovedLeadListComponent_198382_onChange1_();
                  resolve();
                });
          })



        
        KuikaAppManager.hideSpinner(this);
        return isErrorOccurred;
    }
		ApprovedLeadListComponent_198382_onChange1_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }

				
				stateVars.dataSource_633056 = stateVars.TMTotalStoreApprovedLead ?? this.state.TMTotalStoreApprovedLead;
				formVars.approvedleadlist_247267_value = ReactSystemFunctions.value(this, (stateVars.TMTotalStoreApprovedLead !== undefined ? (stateVars.TMTotalStoreApprovedLead?.length > 0 ? stateVars.TMTotalStoreApprovedLead[0].adedi : null) : (this.state.TMTotalStoreApprovedLead?.length > 0 ? this.state.TMTotalStoreApprovedLead[0].adedi : null)));


		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

            
            return isErrorOccurred;
        }




    ApprovedLeadListComponent_84425_onChange = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
		KuikaAppManager.increaseServerRequestCount();

        let localVar = {
				StoreId_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "approvedleadlist_463912_value", "value", "TM_GetApprovedLeadStores", "storeId", "storeId")), "string"),
				CategoryName_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "approvedleadlist_198382_value", "value", "TM_GetApprovedLeadCategories", "categoryName", "categoryName")), "string"),
				ProductName_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "approvedleadlist_84425_value", "value", "", "", "")), "string"),
				Referance_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "approvedleadlist_847615_value", "value", "", "", "")), "string"),
				Dial_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "approvedleadlist_999251_value", "value", "", "", "")), "string"),
				Bracelet_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "approvedleadlist_79693_value", "value", "", "", "")), "string")
        }

		KuikaAppManager.showSpinner(this);
		
        if (true) {
        KuikaAppManager.showSpinner(this);
        }
        let result = await KuikaAppManager.ApiRequest(this, "ApprovedLeadList/ApprovedLeadListComponent_84425_onChange", localVar)
        if (!KMainFunctions.IsResStatus2XX(result)) return true;

			stateVars.TMTotalStoreApprovedLead = result?.data.tmTotalStoreApprovedLead;
			
			this.props.form?.setFieldsValue(formVars);
			
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.ApprovedLeadListComponent_84425_onChange1_();
                  resolve();
                });
          })



        
        KuikaAppManager.hideSpinner(this);
        return isErrorOccurred;
    }
		ApprovedLeadListComponent_84425_onChange1_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }

				
				stateVars.dataSource_633056 = stateVars.TMTotalStoreApprovedLead ?? this.state.TMTotalStoreApprovedLead;
				formVars.approvedleadlist_247267_value = ReactSystemFunctions.value(this, (stateVars.TMTotalStoreApprovedLead !== undefined ? (stateVars.TMTotalStoreApprovedLead?.length > 0 ? stateVars.TMTotalStoreApprovedLead[0].adedi : null) : (this.state.TMTotalStoreApprovedLead?.length > 0 ? this.state.TMTotalStoreApprovedLead[0].adedi : null)));


		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

            
            return isErrorOccurred;
        }




    ApprovedLeadListComponent_847615_onChange = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
		KuikaAppManager.increaseServerRequestCount();

        let localVar = {
				StoreId_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "approvedleadlist_463912_value", "value", "TM_GetApprovedLeadStores", "storeId", "storeId")), "string"),
				CategoryName_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "approvedleadlist_198382_value", "value", "TM_GetApprovedLeadCategories", "categoryName", "categoryName")), "string"),
				ProductName_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "approvedleadlist_84425_value", "value", "", "", "")), "string"),
				Referance_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "approvedleadlist_847615_value", "value", "", "", "")), "string"),
				Dial_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "approvedleadlist_999251_value", "value", "", "", "")), "string"),
				Bracelet_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "approvedleadlist_79693_value", "value", "", "", "")), "string")
        }

		KuikaAppManager.showSpinner(this);
		
        if (true) {
        KuikaAppManager.showSpinner(this);
        }
        let result = await KuikaAppManager.ApiRequest(this, "ApprovedLeadList/ApprovedLeadListComponent_847615_onChange", localVar)
        if (!KMainFunctions.IsResStatus2XX(result)) return true;

			stateVars.TMTotalStoreApprovedLead = result?.data.tmTotalStoreApprovedLead;
			
			this.props.form?.setFieldsValue(formVars);
			
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.ApprovedLeadListComponent_847615_onChange1_();
                  resolve();
                });
          })



        
        KuikaAppManager.hideSpinner(this);
        return isErrorOccurred;
    }
		ApprovedLeadListComponent_847615_onChange1_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }

				
				stateVars.dataSource_633056 = stateVars.TMTotalStoreApprovedLead ?? this.state.TMTotalStoreApprovedLead;
				formVars.approvedleadlist_247267_value = ReactSystemFunctions.value(this, (stateVars.TMTotalStoreApprovedLead !== undefined ? (stateVars.TMTotalStoreApprovedLead?.length > 0 ? stateVars.TMTotalStoreApprovedLead[0].adedi : null) : (this.state.TMTotalStoreApprovedLead?.length > 0 ? this.state.TMTotalStoreApprovedLead[0].adedi : null)));


		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

            
            return isErrorOccurred;
        }




    ApprovedLeadListComponent_999251_onChange = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
		KuikaAppManager.increaseServerRequestCount();

        let localVar = {
				StoreId_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "approvedleadlist_463912_value", "value", "TM_GetApprovedLeadStores", "storeId", "storeId")), "string"),
				CategoryName_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "approvedleadlist_198382_value", "value", "TM_GetApprovedLeadCategories", "categoryName", "categoryName")), "string"),
				ProductName_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "approvedleadlist_84425_value", "value", "", "", "")), "string"),
				Referance_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "approvedleadlist_847615_value", "value", "", "", "")), "string"),
				Dial_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "approvedleadlist_999251_value", "value", "", "", "")), "string"),
				Bracelet_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "approvedleadlist_79693_value", "value", "", "", "")), "string")
        }

		KuikaAppManager.showSpinner(this);
		
        if (true) {
        KuikaAppManager.showSpinner(this);
        }
        let result = await KuikaAppManager.ApiRequest(this, "ApprovedLeadList/ApprovedLeadListComponent_999251_onChange", localVar)
        if (!KMainFunctions.IsResStatus2XX(result)) return true;

			stateVars.TMTotalStoreApprovedLead = result?.data.tmTotalStoreApprovedLead;
			
			this.props.form?.setFieldsValue(formVars);
			
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.ApprovedLeadListComponent_999251_onChange1_();
                  resolve();
                });
          })



        
        KuikaAppManager.hideSpinner(this);
        return isErrorOccurred;
    }
		ApprovedLeadListComponent_999251_onChange1_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }

				
				stateVars.dataSource_633056 = stateVars.TMTotalStoreApprovedLead ?? this.state.TMTotalStoreApprovedLead;
				formVars.approvedleadlist_247267_value = ReactSystemFunctions.value(this, (stateVars.TMTotalStoreApprovedLead !== undefined ? (stateVars.TMTotalStoreApprovedLead?.length > 0 ? stateVars.TMTotalStoreApprovedLead[0].adedi : null) : (this.state.TMTotalStoreApprovedLead?.length > 0 ? this.state.TMTotalStoreApprovedLead[0].adedi : null)));


		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

            
            return isErrorOccurred;
        }




    ApprovedLeadListComponent_79693_onChange = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
		KuikaAppManager.increaseServerRequestCount();

        let localVar = {
				StoreId_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "approvedleadlist_463912_value", "value", "TM_GetApprovedLeadStores", "storeId", "storeId")), "string"),
				CategoryName_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "approvedleadlist_198382_value", "value", "TM_GetApprovedLeadCategories", "categoryName", "categoryName")), "string"),
				ProductName_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "approvedleadlist_84425_value", "value", "", "", "")), "string"),
				Referance_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "approvedleadlist_847615_value", "value", "", "", "")), "string"),
				Dial_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "approvedleadlist_999251_value", "value", "", "", "")), "string"),
				Bracelet_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "approvedleadlist_79693_value", "value", "", "", "")), "string")
        }

		KuikaAppManager.showSpinner(this);
		
        if (true) {
        KuikaAppManager.showSpinner(this);
        }
        let result = await KuikaAppManager.ApiRequest(this, "ApprovedLeadList/ApprovedLeadListComponent_79693_onChange", localVar)
        if (!KMainFunctions.IsResStatus2XX(result)) return true;

			stateVars.TMTotalStoreApprovedLead = result?.data.tmTotalStoreApprovedLead;
			
			this.props.form?.setFieldsValue(formVars);
			
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.ApprovedLeadListComponent_79693_onChange1_();
                  resolve();
                });
          })



        
        KuikaAppManager.hideSpinner(this);
        return isErrorOccurred;
    }
		ApprovedLeadListComponent_79693_onChange1_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }

				
				stateVars.dataSource_633056 = stateVars.TMTotalStoreApprovedLead ?? this.state.TMTotalStoreApprovedLead;
				formVars.approvedleadlist_247267_value = ReactSystemFunctions.value(this, (stateVars.TMTotalStoreApprovedLead !== undefined ? (stateVars.TMTotalStoreApprovedLead?.length > 0 ? stateVars.TMTotalStoreApprovedLead[0].adedi : null) : (this.state.TMTotalStoreApprovedLead?.length > 0 ? this.state.TMTotalStoreApprovedLead[0].adedi : null)));


		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

            
            return isErrorOccurred;
        }




		ApprovedLeadListComponent_228982_onClick = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
KuikaAppManager.showSpinner(this);

				stateVars.SetValueOf = await ReactSystemFunctions.setValueOf(this, ReactSystemFunctions.convertToTypeByName("approvedleadlist_463912_value", "string"), "", null, false);
				stateVars.SetValueOf = await ReactSystemFunctions.setValueOf(this, ReactSystemFunctions.convertToTypeByName("approvedleadlist_84425_value", "string"), "", null, false);
				stateVars.SetValueOf = await ReactSystemFunctions.setValueOf(this, ReactSystemFunctions.convertToTypeByName("approvedleadlist_198382_value", "string"), "", null, false);

		this.props.form?.setFieldsValue(formVars);
		
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.ApprovedLeadListComponent_228982_onClick1_();
                  resolve();
                });
          })

            
            return isErrorOccurred;
        }
    ApprovedLeadListComponent_228982_onClick1_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
		KuikaAppManager.increaseServerRequestCount();

        let localVar = {
				StoreId_0: ReactSystemFunctions.convertToTypeByName(null, "string"),
				CategoryName_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "approvedleadlist_198382_value", "value", "TM_GetApprovedLeadCategories", "categoryName", "categoryName")), "string"),
				ProductName_0: ReactSystemFunctions.convertToTypeByName(null, "string"),
				Referance_0: ReactSystemFunctions.convertToTypeByName(null, "string"),
				Dial_0: ReactSystemFunctions.convertToTypeByName(null, "string"),
				Bracelet_0: ReactSystemFunctions.convertToTypeByName(null, "string")
        }

		
        if (true) {
        KuikaAppManager.showSpinner(this);
        }
        let result = await KuikaAppManager.ApiRequest(this, "ApprovedLeadList/ApprovedLeadListComponent_228982_onClick1_", localVar)
        if (!KMainFunctions.IsResStatus2XX(result)) return true;

			stateVars.TMTotalStoreApprovedLead = result?.data.tmTotalStoreApprovedLead;
			
			this.props.form?.setFieldsValue(formVars);
			
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.ApprovedLeadListComponent_228982_onClick2_();
                  resolve();
                });
          })



        
        KuikaAppManager.hideSpinner(this);
        return isErrorOccurred;
    }
		ApprovedLeadListComponent_228982_onClick2_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }

				
				stateVars.dataSource_633056 = stateVars.TMTotalStoreApprovedLead ?? this.state.TMTotalStoreApprovedLead;
				formVars.approvedleadlist_247267_value = ReactSystemFunctions.value(this, (stateVars.TMTotalStoreApprovedLead !== undefined ? (stateVars.TMTotalStoreApprovedLead?.length > 0 ? stateVars.TMTotalStoreApprovedLead[0].adedi : null) : (this.state.TMTotalStoreApprovedLead?.length > 0 ? this.state.TMTotalStoreApprovedLead[0].adedi : null)));


		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

            
            return isErrorOccurred;
        }





		ApprovedLeadListComponent_270363_onChange = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
KuikaAppManager.showSpinner(this);

				ReactSystemFunctions.setValueOf(this, "approvedleadlist_334933_value", ReactSystemFunctions.value(this, "approvedleadlist_270363_value", "value"), "disablebeforedate");


		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

            
            return isErrorOccurred;
        }




    async callCallbackFunction(diId: number, isFromMaster: boolean = false) {
        let isErrorOccurred = false;
		let pageInitCallerNavDiIDs = [] as number[];
		if (isFromMaster || pageInitCallerNavDiIDs.indexOf(diId) > -1) {
			await this.ApprovedLeadListPageInit();
		}

    }


}
