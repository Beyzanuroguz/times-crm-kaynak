import React from "react";
import Axios, { AxiosResponse } from "axios";
import { KuikaAppManager } from "../../shared/utilty/kuika-app-manager";
import { ReactSystemFunctions } from "../../shared/utilty/react-system-functions";
import { KNavigator } from "../../shared/hoc/with-history";
import { KContext } from "../../shared/hoc/with-context";
import { useLocation } from "react-router-dom";
import { FormInstance } from "antd/es/form";
import { Guid } from "guid-typescript";
import Swal from "sweetalert2";
import { KMainFunctions } from "../../shared/utilty/main-functions";
import moment from "moment";
import { IValidationData } from "../../models/dto/validation-data";
import { IStripePayment } from "../../models/dto/stripe-payment";
import { IUserInfoDto } from "../../models/dto/user-info.dto";
import { UserService } from "../../services/user-service";
import { kuikaCoreWasmBridgeService } from "../../services/_singletons";
import _ from "lodash";
import mqtt, { MqttClient } from "mqtt";
import { IMqttResult } from "../../models/dto/mqtt.dto";
import { MasterScreen_ScreenContext } from "../masterscreen/masterscreen-context";

declare let window: any;

export interface ILeadReport_ScreenProps {
  navigator: KNavigator;
  form: FormInstance<any>;
  googleLogin: any;
  screenInputs: any;
  context: KContext;
  initialValues: any;
  children: any;
}

export interface ILeadReport_ScreenState {
    isSpinnerVisible: boolean;
    isPageVisible: boolean;
	isLeftMenuVisible: boolean;
    spinnerCount: number;
    selectedLanguage: string;
    isPageInitLoaded: false;
    isPageRecurringLoaded: false;
	TM_LR_GetStore: any[];
	TM_LR_GetStore_dummy: any[];
	TM_LR_GetProductBrand: any[];
	TM_LR_GetProductBrand_dummy: any[];
	TM_LR_GetSalesPerson: any[];
	TM_LR_GetSalesPerson_dummy: any[];
	TM_LR_GetLeadProcess: any[];
	TM_LR_GetLeadProcess_dummy: any[];
	TM_LR_GetLeadStatus: any[];
	TM_LR_GetLeadStatus_dummy: any[];
	TM_LR_GetProductCategory: any[];
	TM_LR_GetProductCategory_dummy: any[];
	TM_GetLeadReportList: any[];
	TM_GetLeadReportList_dummy: any[];
	TM_LR_GetKPI: any[];
	TM_LR_GetKPI_dummy: any[];
	TM_LR_GetProcessDistribution: any[];
	TM_LR_GetProcessDistribution_dummy: any[];
	TM_LR_GetStoreDistribution: any[];
	TM_LR_GetStoreDistribution_dummy: any[];
	TM_LR_GetProductDistribution: any[];
	TM_LR_GetProductDistribution_dummy: any[];
	TM_LR_GetStoreLeadStatus: any[];
	TM_LR_GetStoreLeadStatus_dummy: any[];
	TM_LR_GetStoreProductDistribution: any[];
	TM_LR_GetStoreProductDistribution_dummy: any[];
	TM_LR_GetMonthlyLeadTrend: any[];
	TM_LR_GetMonthlyLeadTrend_dummy: any[];
	TM_LR_GetLeadResultDistribution: any[];
	TM_LR_GetLeadResultDistribution_dummy: any[];
	SetValueOf: any;
	SetValueOf_dummy: any;
	ExportExcel: any;
	ExportExcel_dummy: any;
	NAVIGATE: any;
	NAVIGATE_dummy: any;
	isComp2041704481Visible: 'visible' | 'hidden';
	isComp562299Visible: 'visible' | 'hidden';
	isComp436147923Visible: 'visible' | 'hidden';
	isComp409002623Visible: 'visible' | 'hidden';
	isComp257294576Visible: 'visible' | 'hidden';
	isComp823711768Visible: 'visible' | 'hidden';
	isComp1063961095Visible: 'visible' | 'hidden';
	isComp1022415963Visible: 'visible' | 'hidden';
	isComp1336153348Visible: 'visible' | 'hidden';
	isComp1374188352Visible: 'visible' | 'hidden';
	isComp29676Visible: 'visible' | 'hidden';
	isComp1174339289Visible: 'visible' | 'hidden';
	isComp1558580705Visible: 'visible' | 'hidden';
	isComp1455777370Visible: 'visible' | 'hidden';
	isComp774508948Visible: 'visible' | 'hidden';
	isComp694575305Visible: 'visible' | 'hidden';
	isComp1755108776Visible: 'visible' | 'hidden';
	isComp615175562Visible: 'visible' | 'hidden';
	isComp2589513Visible: 'visible' | 'hidden';
	isComp1590928990Visible: 'visible' | 'hidden';
	isComp1025399884Visible: 'visible' | 'hidden';
	isComp998926227Visible: 'visible' | 'hidden';
	isComp629412425Visible: 'visible' | 'hidden';
	isComp48850614Visible: 'visible' | 'hidden';
	isComp1839559748Visible: 'visible' | 'hidden';
	isComp869566328Visible: 'visible' | 'hidden';
	isComp1326511064Visible: 'visible' | 'hidden';
	isComp2084770286Visible: 'visible' | 'hidden';
	isComp1289620961Visible: 'visible' | 'hidden';
	isComp809795820Visible: 'visible' | 'hidden';

}

export class LeadReport_ScreenBase extends React.PureComponent<ILeadReport_ScreenProps, any> {
    static contextType = MasterScreen_ScreenContext;
    declare context: React.ContextType<typeof MasterScreen_ScreenContext>;
	leadreport_680946_value_kuikaAutoCompleteRef: React.RefObject<any>;
	leadreport_889015525_value_kuikaAutoCompleteRef: React.RefObject<any>;
	leadreport_1654656927_value_kuikaAutoCompleteRef: React.RefObject<any>;
	leadreport_2092042287_value_kuikaAutoCompleteRef: React.RefObject<any>;
	leadreport_725505088_value_kuikaAutoCompleteRef: React.RefObject<any>;
	leadreport_1474920253_value_kuikaAutoCompleteRef: React.RefObject<any>;
	leadreport_1208152912_value_kuikaSelectBoxRef: React.RefObject<any>;
	leadreport_846576_value_kuikaTableRef: React.RefObject<any>;
	leadreport_672374655_value_kuikaTableRef: React.RefObject<any>;
	leadreport_353892_value_kuikaTableRef: React.RefObject<any>;
	leadreport_367777433_value_kuikaTableRef: React.RefObject<any>;
	leadreport_524175975_value_kuikaTableRef: React.RefObject<any>;
    ml=[{"Id":"d5a61d2b-bd60-485f-86e2-661e9ed4e486","Name":"en_US","ShortName":"English","IsDefault":true,"LanguagePhrases":[]},{"Id":"ef581176-eec8-4868-9c8a-2bf42f19ca0d","Name":"FixedValues","ShortName":"FixedValues","LanguagePhrases":[{"Id":895482,"PropertyName":"value","Value":"Mağaza"},{"Id":680946,"PropertyName":"placeholder","Value":"Mağaza"},{"Id":1389900430,"PropertyName":"value","Value":"Satış Personeli"},{"Id":889015525,"PropertyName":"placeholder","Value":"Satış Personeli"},{"Id":120607727,"PropertyName":"value","Value":"Marka"},{"Id":1654656927,"PropertyName":"placeholder","Value":"Marka"},{"Id":1904124127,"PropertyName":"value","Value":"Kategori"},{"Id":2092042287,"PropertyName":"placeholder","Value":"Kategori"},{"Id":1062344412,"PropertyName":"value","Value":"Talep Durumu"},{"Id":725505088,"PropertyName":"placeholder","Value":"Talep Durumu"},{"Id":1761718827,"PropertyName":"value","Value":"Takip Durumu"},{"Id":1474920253,"PropertyName":"placeholder","Value":"Takip Durumu"},{"Id":650005,"PropertyName":"value","Value":"Tarih"},{"Id":128677,"PropertyName":"startDatePlaceholder","Value":"Start Date"},{"Id":128677,"PropertyName":"endDatePlaceholder","Value":"End Date"},{"Id":1480921505,"PropertyName":"value","Value":"İşlem"},{"Id":1208152912,"PropertyName":"placeholder","Value":"İşlem"},{"Id":662481,"PropertyName":"label","Value":"Temizle"},{"Id":886840,"PropertyName":"label","Value":"Filtrele"},{"Id":975949,"PropertyName":"value","Value":"Bu Ay Terminli"},{"Id":1972654644,"PropertyName":"value","Value":"Aktif Takipte"},{"Id":939958048,"PropertyName":"value","Value":"2.Takip"},{"Id":227485639,"PropertyName":"value","Value":"Onay Bekleyen "},{"Id":217200479,"PropertyName":"value","Value":"Onaylanan"},{"Id":560821309,"PropertyName":"value","Value":"Reddedilen"},{"Id":2145452247,"PropertyName":"value","Value":"Talep Süreç Dağılımı"},{"Id":1394705446,"PropertyName":"title","Value":"Süreç"},{"Id":273815,"PropertyName":"value","Value":"[datafield:processname]"},{"Id":1720434643,"PropertyName":"title","Value":"Talep Sayısı"},{"Id":673768,"PropertyName":"value","Value":"[datafield:talepsayisi]"},{"Id":42224,"PropertyName":"value","Value":"Mağaza Bazında Talep Dağılımı"},{"Id":763225753,"PropertyName":"title","Value":"Mağaza"},{"Id":372445932,"PropertyName":"value","Value":"[datafield:storename]"},{"Id":1201873741,"PropertyName":"title","Value":"Dağılım"},{"Id":1164448534,"PropertyName":"title","Value":"Talep Sayısı"},{"Id":1473736371,"PropertyName":"value","Value":"[datafield:talepsayisi]"},{"Id":1405734621,"PropertyName":"value","Value":"Ürün Dağılımı"},{"Id":277328,"PropertyName":"value","Value":"Ürün"},{"Id":957992958,"PropertyName":"value","Value":"Dağılım"},{"Id":1253577974,"PropertyName":"value","Value":"Talep Sayısı"},{"Id":1158015669,"PropertyName":"value","Value":"Tudor"},{"Id":1567158666,"PropertyName":"value","Value":"Rolex"},{"Id":465906480,"PropertyName":"value","Value":"Kategori 1"},{"Id":1216315116,"PropertyName":"value","Value":"Kategori 2"},{"Id":220105591,"PropertyName":"value","Value":"Kategori 3"},{"Id":1970548513,"PropertyName":"value","Value":"Aylık Talep Trendi"},{"Id":990947198,"PropertyName":"value","Value":"Talep Sonuç Dağılımı"},{"Id":234335,"PropertyName":"value","Value":"Mağaza Bazında Talep Durumları"},{"Id":1308896275,"PropertyName":"label","Value":"Export Excel"},{"Id":184857164,"PropertyName":"title","Value":"Mağaza"},{"Id":858904892,"PropertyName":"value","Value":"[datafield:magaza]"},{"Id":1091602840,"PropertyName":"title","Value":"Toplam"},{"Id":143060,"PropertyName":"value","Value":"[datafield:toplam]"},{"Id":2061528058,"PropertyName":"title","Value":"Oluşturuldu"},{"Id":1417502939,"PropertyName":"value","Value":"[datafield:olusturuldu]"},{"Id":1380585248,"PropertyName":"title","Value":"Termin Bekleyen"},{"Id":1311016812,"PropertyName":"value","Value":"[datafield:terminbekleyen]"},{"Id":1302432711,"PropertyName":"title","Value":"Onay Bekleyen"},{"Id":23759712,"PropertyName":"value","Value":"[datafield:onaybekleyen]"},{"Id":775931841,"PropertyName":"title","Value":"Onaylanan"},{"Id":1360957561,"PropertyName":"value","Value":"[datafield:onaylanan]"},{"Id":886763433,"PropertyName":"title","Value":"Satış Bekleyen"},{"Id":72466891,"PropertyName":"value","Value":"[datafield:satisbekleyen]"},{"Id":80819850,"PropertyName":"title","Value":"Satışı Yapılan"},{"Id":1620971644,"PropertyName":"value","Value":"[datafield:satisiyapilan]"},{"Id":934834002,"PropertyName":"title","Value":"Reddedilen"},{"Id":1121449014,"PropertyName":"value","Value":"[datafield:reddedilen]"},{"Id":696116860,"PropertyName":"value","Value":"Ürün / Marka Bazında Dağılım"},{"Id":1932689703,"PropertyName":"label","Value":"Export Excel"},{"Id":712510406,"PropertyName":"title","Value":"Mağaza"},{"Id":100072930,"PropertyName":"value","Value":"[datafield:magaza]"},{"Id":238027731,"PropertyName":"title","Value":"Tudor"},{"Id":962225,"PropertyName":"value","Value":"[datafield:tudor]"},{"Id":993908260,"PropertyName":"title","Value":"Kategori 1"},{"Id":989047718,"PropertyName":"value","Value":"[datafield:kategori1]"},{"Id":1318053631,"PropertyName":"title","Value":"Kategori 2"},{"Id":1125437159,"PropertyName":"value","Value":"[datafield:kategori2]"},{"Id":438764231,"PropertyName":"title","Value":"Kategori 3"},{"Id":914967374,"PropertyName":"value","Value":"[datafield:kategori3]"},{"Id":349902320,"PropertyName":"title","Value":"Toplam"},{"Id":1167886047,"PropertyName":"value","Value":"[datafield:toplam]"},{"Id":257044099,"PropertyName":"value","Value":"Talep Listesi"},{"Id":1928069397,"PropertyName":"label","Value":"Export Excel"},{"Id":1475582979,"PropertyName":"title","Value":"Talep Tarihi"},{"Id":186233768,"PropertyName":"value","Value":"[datafield:taleptarihi]"},{"Id":357386863,"PropertyName":"title","Value":"Talep Numarası"},{"Id":480883,"PropertyName":"value","Value":"[datafield:leadnumarasi]"},{"Id":1756135042,"PropertyName":"title","Value":"Mağaza"},{"Id":824928623,"PropertyName":"value","Value":"[datafield:magaza]"},{"Id":1299131403,"PropertyName":"title","Value":"Marka "},{"Id":1689569174,"PropertyName":"value","Value":"[datafield:marka]"},{"Id":1162425232,"PropertyName":"title","Value":"Kategori"},{"Id":1590928990,"PropertyName":"value","Value":"[datafield:kategori]"},{"Id":1025399884,"PropertyName":"value","Value":"[datafield:kategori]"},{"Id":998926227,"PropertyName":"value","Value":"[datafield:kategori]"},{"Id":629412425,"PropertyName":"value","Value":"[datafield:kategori]"},{"Id":1833172543,"PropertyName":"title","Value":"Model"},{"Id":794934957,"PropertyName":"value","Value":"[datafield:referans]"},{"Id":711201874,"PropertyName":"title","Value":"Müşteri"},{"Id":1217605493,"PropertyName":"value","Value":"[datafield:musteri]"},{"Id":1778549408,"PropertyName":"title","Value":"Takip Durumu"},{"Id":48850614,"PropertyName":"value","Value":"[datafield:takipdurumu]"},{"Id":1839559748,"PropertyName":"value","Value":"[datafield:takipdurumu]"},{"Id":660685354,"PropertyName":"title","Value":"Talep Durumu"},{"Id":869566328,"PropertyName":"value","Value":"[datafield:talepdurumu]"},{"Id":1326511064,"PropertyName":"value","Value":"[datafield:talepdurumu]"},{"Id":2084770286,"PropertyName":"value","Value":"[datafield:talepdurumu]"},{"Id":1289620961,"PropertyName":"value","Value":"[datafield:talepdurumu]"},{"Id":809795820,"PropertyName":"value","Value":"[datafield:talepdurumu]"},{"Id":1875128156,"PropertyName":"title","Value":"Termin Tarihi"},{"Id":1981893476,"PropertyName":"value","Value":"[datafield:termintarihi]"},{"Id":971016081,"PropertyName":"title","Value":"Satış Danışmanı"},{"Id":1530670825,"PropertyName":"value","Value":"[datafield:satispersoneli]"},{"Id":1451736520,"PropertyName":"title","Value":"Detay"},{"Id":1418671398,"PropertyName":"label","Value":"Detay"}]}]
    defaultML = "en_US"
    
    screenHash = ""
    

    private _prevMasterPageInitLoaded: boolean = false;
    private _prevMasterPageRecurringLoaded: boolean = false;
    private _prevShouldTriggerPageInit: boolean = false;
    constructor(props) {
        super(props);
		this.leadreport_680946_value_kuikaAutoCompleteRef = React.createRef();
		this.leadreport_889015525_value_kuikaAutoCompleteRef = React.createRef();
		this.leadreport_1654656927_value_kuikaAutoCompleteRef = React.createRef();
		this.leadreport_2092042287_value_kuikaAutoCompleteRef = React.createRef();
		this.leadreport_725505088_value_kuikaAutoCompleteRef = React.createRef();
		this.leadreport_1474920253_value_kuikaAutoCompleteRef = React.createRef();
		this.leadreport_1208152912_value_kuikaSelectBoxRef = React.createRef();
		this.leadreport_846576_value_kuikaTableRef = React.createRef();
		this.leadreport_672374655_value_kuikaTableRef = React.createRef();
		this.leadreport_353892_value_kuikaTableRef = React.createRef();
		this.leadreport_367777433_value_kuikaTableRef = React.createRef();
		this.leadreport_524175975_value_kuikaTableRef = React.createRef();

        this.state = {
            isSpinnerVisible: false,
            isPageVisible: false,
            isLeftMenuVisible: false,
            spinnerCount: 0,
            selectedLanguage: "",
            isPageInitLoaded: false,
            isPageRecurringLoaded: false,
            	        TM_LR_GetStore: [],
	        TM_LR_GetProductBrand: [],
	        TM_LR_GetSalesPerson: [],
	        TM_LR_GetLeadProcess: [],
	        TM_LR_GetLeadStatus: [],
	        TM_LR_GetProductCategory: [],
	        TM_GetLeadReportList: [],
	        TM_LR_GetKPI: [],
	        TM_LR_GetProcessDistribution: [],
	        TM_LR_GetStoreDistribution: [],
	        TM_LR_GetProductDistribution: [],
	        TM_LR_GetStoreLeadStatus: [],
	        TM_LR_GetStoreProductDistribution: [],
	        TM_LR_GetMonthlyLeadTrend: [],
	        TM_LR_GetLeadResultDistribution: [],
	        SetValueOf: "",
	        ExportExcel: "",
	        NAVIGATE: "",
	        isComp2041704481Visible: 'hidden',
	        isComp562299Visible: 'hidden',
	        isComp436147923Visible: 'hidden',
	        isComp409002623Visible: 'hidden',
	        isComp257294576Visible: 'hidden',
	        isComp823711768Visible: 'hidden',
	        isComp1063961095Visible: 'hidden',
	        isComp1022415963Visible: 'hidden',
	        isComp1336153348Visible: 'hidden',
	        isComp1374188352Visible: 'hidden',
	        isComp29676Visible: 'hidden',
	        isComp1174339289Visible: 'hidden',
	        isComp1558580705Visible: 'hidden',
	        isComp1455777370Visible: 'hidden',
	        isComp774508948Visible: 'hidden',
	        isComp694575305Visible: 'hidden',
	        isComp1755108776Visible: 'hidden',
	        isComp615175562Visible: 'hidden',
	        isComp2589513Visible: 'hidden',
	        isComp1590928990Visible: 'hidden',
	        isComp1025399884Visible: 'hidden',
	        isComp998926227Visible: 'hidden',
	        isComp629412425Visible: 'hidden',
	        isComp48850614Visible: 'hidden',
	        isComp1839559748Visible: 'hidden',
	        isComp869566328Visible: 'hidden',
	        isComp1326511064Visible: 'hidden',
	        isComp2084770286Visible: 'hidden',
	        isComp1289620961Visible: 'hidden',
	        isComp809795820Visible: 'hidden',

        }

        this.state.isPageVisible = true;
        
    }

    async componentDidMount() {

        if (KuikaAppManager.isPageInitPrevented()) {
            KuikaAppManager.calculateAndSetBodyHeight("leadreport", "masterscreen_screen");
            return;
        }
        this.context.registerCallbackFunction(this.callCallbackFunction.bind(this));
        
        ReactSystemFunctions.validateToken()
        this.fillFormInitValues();
        if (false){
            await this.LeadReportPageInit();
        } else if (this.context?.isMasterPageInitLoaded) { this._prevMasterPageInitLoaded = true; await this.LeadReportPageInit(); }
        
        
        
        KuikaAppManager.calculateAndSetBodyHeight("leadreport", "masterscreen_screen");

        if (ReactSystemFunctions.getIsMicroApp() === false) {
           window.parentScreen = this;
        }
    }

    componentWillUnmount() {
        
        
        

        if (ReactSystemFunctions.getIsMicroApp() === false) {
           window.parentScreen = null;
        }
    }

    

        
    componentDidUpdate= async (prevProps, prevState) => {
		KuikaAppManager.calculateAndSetBodyHeight("leadreport", "masterscreen_screen"    );
        if (prevProps?.location?.search !== (this.props as any)?.location?.search) {
			await this.LeadReportPageInit();
		}

        		if (this._prevMasterPageInitLoaded !== this.context.isMasterPageInitLoaded && this.context.isMasterPageInitLoaded === true) {this._prevMasterPageInitLoaded = this.context.isMasterPageInitLoaded;await this.LeadReportPageInit()}


        if (ReactSystemFunctions.getIsMicroApp() === false) {
            for (const key in prevState) {
                if (key.startsWith('NavVisible') && prevState[key] === true && this.state[key] === false) {
                    window.parentScreen = this;
                    break;
                }
            }
        }
	}

    fillFormInitValues() {
        this.props.form?.setFieldsValue({
});

    }

      setPageInitLoaded = (value: boolean) => {
        this.setState({ isPageInitLoaded: value });
      }

      setPageRecurringLoaded = (value: boolean) => {
        this.setState({ isPageRecurringLoaded: value });
      }

      clearFieldValidation = (changedValues: any) => {
        const fieldName = Object.keys(changedValues)[0];
        if (fieldName) {
          this.props.form?.setFields([
            {
              name: fieldName,
              errors: []
            }
          ]);
        }
      };

      

    LeadReportPageInit = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


	if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }

        let localVar = {
			KUserId_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.getMyUserId(), "Guid"),
			KUserId_1: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.getMyUserId(), "Guid"),
			KUserId_2: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.getMyUserId(), "Guid"),
			StoreId_2: ReactSystemFunctions.convertToTypeByName(null, "Guid"),
			StepOrder_3: ReactSystemFunctions.convertToTypeByName(0, "number"),
			UserId_6: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.getMyUserId(), "Guid"),
			StoreIds_6: ReactSystemFunctions.convertToTypeByName(null, "string"),
			Brand_6: ReactSystemFunctions.convertToTypeByName(null, "string"),
			SatisDanismaniIds_6: ReactSystemFunctions.convertToTypeByName(null, "string"),
			StepOrder_6: ReactSystemFunctions.convertToTypeByName(0, "number"),
			StatusIds_6: ReactSystemFunctions.convertToTypeByName(null, "string"),
			CategoryName_6: ReactSystemFunctions.convertToTypeByName(null, "string"),
			ProcessCode_6: ReactSystemFunctions.convertToTypeByName(null, "string"),
			StartDate_6: ReactSystemFunctions.convertToTypeByName(null, "Date"),
			EndDate_6: ReactSystemFunctions.convertToTypeByName(null, "Date"),
			UserId_7: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.getMyUserId(), "Guid"),
			StoreIds_7: ReactSystemFunctions.convertToTypeByName(null, "string"),
			Brand_7: ReactSystemFunctions.convertToTypeByName(null, "string"),
			SatisDanismaniIds_7: ReactSystemFunctions.convertToTypeByName(null, "string"),
			StepOrder_7: ReactSystemFunctions.convertToTypeByName(0, "number"),
			StatusIds_7: ReactSystemFunctions.convertToTypeByName(null, "string"),
			CategoryName_7: ReactSystemFunctions.convertToTypeByName(null, "string"),
			ProcessCode_7: ReactSystemFunctions.convertToTypeByName(null, "string"),
			StartDate_7: ReactSystemFunctions.convertToTypeByName(null, "Date"),
			EndDate_7: ReactSystemFunctions.convertToTypeByName(null, "Date"),
			UserId_8: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.getMyUserId(), "Guid"),
			StoreIds_8: ReactSystemFunctions.convertToTypeByName(null, "string"),
			Brand_8: ReactSystemFunctions.convertToTypeByName(null, "string"),
			SatisDanismaniIds_8: ReactSystemFunctions.convertToTypeByName(null, "string"),
			StepOrder_8: ReactSystemFunctions.convertToTypeByName(0, "number"),
			StatusIds_8: ReactSystemFunctions.convertToTypeByName(null, "string"),
			CategoryName_8: ReactSystemFunctions.convertToTypeByName(null, "string"),
			ProcessCode_8: ReactSystemFunctions.convertToTypeByName(null, "string"),
			StartDate_8: ReactSystemFunctions.convertToTypeByName(null, "Date"),
			EndDate_8: ReactSystemFunctions.convertToTypeByName(null, "Date"),
			UserId_9: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.getMyUserId(), "Guid"),
			StoreIds_9: ReactSystemFunctions.convertToTypeByName(null, "string"),
			Brand_9: ReactSystemFunctions.convertToTypeByName(null, "string"),
			SatisDanismaniIds_9: ReactSystemFunctions.convertToTypeByName(null, "string"),
			StepOrder_9: ReactSystemFunctions.convertToTypeByName(0, "number"),
			StatusIds_9: ReactSystemFunctions.convertToTypeByName(null, "string"),
			CategoryName_9: ReactSystemFunctions.convertToTypeByName(null, "string"),
			ProcessCode_9: ReactSystemFunctions.convertToTypeByName(null, "string"),
			StartDate_9: ReactSystemFunctions.convertToTypeByName(null, "Date"),
			EndDate_9: ReactSystemFunctions.convertToTypeByName(null, "Date"),
			UserId_10: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.getMyUserId(), "Guid"),
			StoreIds_10: ReactSystemFunctions.convertToTypeByName(null, "string"),
			Brand_10: ReactSystemFunctions.convertToTypeByName(null, "string"),
			SatisDanismaniIds_10: ReactSystemFunctions.convertToTypeByName(null, "string"),
			StepOrder_10: ReactSystemFunctions.convertToTypeByName(0, "number"),
			StatusIds_10: ReactSystemFunctions.convertToTypeByName(null, "string"),
			CategoryName_10: ReactSystemFunctions.convertToTypeByName(null, "string"),
			ProcessCode_10: ReactSystemFunctions.convertToTypeByName(null, "string"),
			StartDate_10: ReactSystemFunctions.convertToTypeByName(null, "Date"),
			EndDate_10: ReactSystemFunctions.convertToTypeByName(null, "Date"),
			UserId_11: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.getMyUserId(), "Guid"),
			StoreIds_11: ReactSystemFunctions.convertToTypeByName(null, "string"),
			Brand_11: ReactSystemFunctions.convertToTypeByName(null, "string"),
			SatisDanismaniIds_11: ReactSystemFunctions.convertToTypeByName(null, "string"),
			StepOrder_11: ReactSystemFunctions.convertToTypeByName(0, "number"),
			StatusIds_11: ReactSystemFunctions.convertToTypeByName(null, "string"),
			CategoryName_11: ReactSystemFunctions.convertToTypeByName(null, "string"),
			ProcessCode_11: ReactSystemFunctions.convertToTypeByName(null, "string"),
			StartDate_11: ReactSystemFunctions.convertToTypeByName(null, "Date"),
			EndDate_11: ReactSystemFunctions.convertToTypeByName(null, "Date"),
			UserId_12: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.getMyUserId(), "Guid"),
			StoreIds_12: ReactSystemFunctions.convertToTypeByName(null, "string"),
			Brand_12: ReactSystemFunctions.convertToTypeByName(null, "string"),
			SatisDanismaniIds_12: ReactSystemFunctions.convertToTypeByName(null, "string"),
			StepOrder_12: ReactSystemFunctions.convertToTypeByName(0, "number"),
			StatusIds_12: ReactSystemFunctions.convertToTypeByName(null, "string"),
			CategoryName_12: ReactSystemFunctions.convertToTypeByName(null, "string"),
			ProcessCode_12: ReactSystemFunctions.convertToTypeByName(null, "string"),
			StartDate_12: ReactSystemFunctions.convertToTypeByName(null, "Date"),
			EndDate_12: ReactSystemFunctions.convertToTypeByName(null, "Date"),
			StartDate_13: ReactSystemFunctions.convertToTypeByName(null, "Date"),
			EndDate_13: ReactSystemFunctions.convertToTypeByName(null, "Date"),
			UserId_13: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.getMyUserId(), "Guid"),
			StoreIds_13: ReactSystemFunctions.convertToTypeByName(null, "string"),
			Brand_13: ReactSystemFunctions.convertToTypeByName(null, "string"),
			SatisDanismaniIds_13: ReactSystemFunctions.convertToTypeByName(null, "string"),
			StepOrder_13: ReactSystemFunctions.convertToTypeByName(0, "number"),
			StatusIds_13: ReactSystemFunctions.convertToTypeByName(null, "string"),
			CategoryName_13: ReactSystemFunctions.convertToTypeByName(null, "string"),
			ProcessCode_13: ReactSystemFunctions.convertToTypeByName(null, "string"),
			UserId_14: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.getMyUserId(), "Guid"),
			StoreIds_14: ReactSystemFunctions.convertToTypeByName(null, "string"),
			Brand_14: ReactSystemFunctions.convertToTypeByName(null, "string"),
			SatisDanismaniIds_14: ReactSystemFunctions.convertToTypeByName(null, "string"),
			StepOrder_14: ReactSystemFunctions.convertToTypeByName(0, "number"),
			StatusIds_14: ReactSystemFunctions.convertToTypeByName(null, "string"),
			CategoryName_14: ReactSystemFunctions.convertToTypeByName(null, "string"),
			ProcessCode_14: ReactSystemFunctions.convertToTypeByName(null, "string"),
			StartDate_14: ReactSystemFunctions.convertToTypeByName(null, "Date"),
			EndDate_14: ReactSystemFunctions.convertToTypeByName(null, "Date")
        }

	KuikaAppManager.showSpinner(this);
	
        if (true) {
        KuikaAppManager.showSpinner(this);
        }
        let result = await KuikaAppManager.ApiRequest(this, "LeadReport/LeadReportPageInit", localVar)
        if (!KMainFunctions.IsResStatus2XX(result)) return true;

		stateVars.TM_LR_GetStore = result?.data.tM_LR_GetStore;
		
		formVars.leadreport_680946_options = stateVars.TM_LR_GetStore;
		stateVars.TM_LR_GetProductBrand = result?.data.tM_LR_GetProductBrand;
		
		formVars.leadreport_1654656927_options = stateVars.TM_LR_GetProductBrand;
		stateVars.TM_LR_GetSalesPerson = result?.data.tM_LR_GetSalesPerson;
		
		formVars.leadreport_889015525_options = stateVars.TM_LR_GetSalesPerson;
		stateVars.TM_LR_GetLeadProcess = result?.data.tM_LR_GetLeadProcess;
		
		formVars.leadreport_725505088_options = stateVars.TM_LR_GetLeadProcess;
		stateVars.TM_LR_GetLeadStatus = result?.data.tM_LR_GetLeadStatus;
		
		formVars.leadreport_1474920253_options = stateVars.TM_LR_GetLeadStatus;
		stateVars.TM_LR_GetProductCategory = result?.data.tM_LR_GetProductCategory;
		
		formVars.leadreport_2092042287_options = stateVars.TM_LR_GetProductCategory;
		stateVars.TM_GetLeadReportList = result?.data.tM_GetLeadReportList;
		
		stateVars.TM_LR_GetKPI = result?.data.tM_LR_GetKPI;
		formVars.leadreport_2073564093_value = ReactSystemFunctions.toString(this, (stateVars.TM_LR_GetKPI !== undefined ? (stateVars.TM_LR_GetKPI?.length > 0 ? stateVars.TM_LR_GetKPI[0].buAyTerminli : null) : (this.state.TM_LR_GetKPI?.length > 0 ? this.state.TM_LR_GetKPI[0].buAyTerminli : null)));
		formVars.leadreport_1311511404_value = ReactSystemFunctions.toString(this, (stateVars.TM_LR_GetKPI !== undefined ? (stateVars.TM_LR_GetKPI?.length > 0 ? stateVars.TM_LR_GetKPI[0].aktifTakipte : null) : (this.state.TM_LR_GetKPI?.length > 0 ? this.state.TM_LR_GetKPI[0].aktifTakipte : null)));
		formVars.leadreport_1304438269_value = ReactSystemFunctions.toString(this, (stateVars.TM_LR_GetKPI !== undefined ? (stateVars.TM_LR_GetKPI?.length > 0 ? stateVars.TM_LR_GetKPI[0].ikinciTakip : null) : (this.state.TM_LR_GetKPI?.length > 0 ? this.state.TM_LR_GetKPI[0].ikinciTakip : null)));
		formVars.leadreport_1902670072_value = ReactSystemFunctions.toString(this, (stateVars.TM_LR_GetKPI !== undefined ? (stateVars.TM_LR_GetKPI?.length > 0 ? stateVars.TM_LR_GetKPI[0].onayBekleyen : null) : (this.state.TM_LR_GetKPI?.length > 0 ? this.state.TM_LR_GetKPI[0].onayBekleyen : null)));
		formVars.leadreport_233056958_value = ReactSystemFunctions.toString(this, (stateVars.TM_LR_GetKPI !== undefined ? (stateVars.TM_LR_GetKPI?.length > 0 ? stateVars.TM_LR_GetKPI[0].onaylanan : null) : (this.state.TM_LR_GetKPI?.length > 0 ? this.state.TM_LR_GetKPI[0].onaylanan : null)));
		formVars.leadreport_630686224_value = ReactSystemFunctions.toString(this, (stateVars.TM_LR_GetKPI !== undefined ? (stateVars.TM_LR_GetKPI?.length > 0 ? stateVars.TM_LR_GetKPI[0].reddedilen : null) : (this.state.TM_LR_GetKPI?.length > 0 ? this.state.TM_LR_GetKPI[0].reddedilen : null)));
		stateVars.TM_LR_GetProcessDistribution = result?.data.tM_LR_GetProcessDistribution;
		
		stateVars.TM_LR_GetStoreDistribution = result?.data.tM_LR_GetStoreDistribution;
		
		stateVars.TM_LR_GetProductDistribution = result?.data.tM_LR_GetProductDistribution;
		formVars.leadreport_387818547_percent = ReactSystemFunctions.value(this, (stateVars.TM_LR_GetProductDistribution !== undefined ? (stateVars.TM_LR_GetProductDistribution?.length > 0 ? stateVars.TM_LR_GetProductDistribution[0].tudorPercent : null) : (this.state.TM_LR_GetProductDistribution?.length > 0 ? this.state.TM_LR_GetProductDistribution[0].tudorPercent : null)));
		formVars.leadreport_115241_value = ReactSystemFunctions.toString(this, (stateVars.TM_LR_GetProductDistribution !== undefined ? (stateVars.TM_LR_GetProductDistribution?.length > 0 ? stateVars.TM_LR_GetProductDistribution[0].tudorCount : null) : (this.state.TM_LR_GetProductDistribution?.length > 0 ? this.state.TM_LR_GetProductDistribution[0].tudorCount : null)));
		formVars.leadreport_1979486780_percent = ReactSystemFunctions.value(this, (stateVars.TM_LR_GetProductDistribution !== undefined ? (stateVars.TM_LR_GetProductDistribution?.length > 0 ? stateVars.TM_LR_GetProductDistribution[0].rolexPercent : null) : (this.state.TM_LR_GetProductDistribution?.length > 0 ? this.state.TM_LR_GetProductDistribution[0].rolexPercent : null)));
		formVars.leadreport_348768957_value = ReactSystemFunctions.toString(this, (stateVars.TM_LR_GetProductDistribution !== undefined ? (stateVars.TM_LR_GetProductDistribution?.length > 0 ? stateVars.TM_LR_GetProductDistribution[0].rolexCount : null) : (this.state.TM_LR_GetProductDistribution?.length > 0 ? this.state.TM_LR_GetProductDistribution[0].rolexCount : null)));
		formVars.leadreport_859009014_percent = ReactSystemFunctions.value(this, (stateVars.TM_LR_GetProductDistribution !== undefined ? (stateVars.TM_LR_GetProductDistribution?.length > 0 ? stateVars.TM_LR_GetProductDistribution[0].category1Percent : null) : (this.state.TM_LR_GetProductDistribution?.length > 0 ? this.state.TM_LR_GetProductDistribution[0].category1Percent : null)));
		formVars.leadreport_1630003451_value = ReactSystemFunctions.toString(this, (stateVars.TM_LR_GetProductDistribution !== undefined ? (stateVars.TM_LR_GetProductDistribution?.length > 0 ? stateVars.TM_LR_GetProductDistribution[0].category1Count : null) : (this.state.TM_LR_GetProductDistribution?.length > 0 ? this.state.TM_LR_GetProductDistribution[0].category1Count : null)));
		formVars.leadreport_622538780_percent = ReactSystemFunctions.value(this, (stateVars.TM_LR_GetProductDistribution !== undefined ? (stateVars.TM_LR_GetProductDistribution?.length > 0 ? stateVars.TM_LR_GetProductDistribution[0].category2Percent : null) : (this.state.TM_LR_GetProductDistribution?.length > 0 ? this.state.TM_LR_GetProductDistribution[0].category2Percent : null)));
		formVars.leadreport_2134985305_value = ReactSystemFunctions.toString(this, (stateVars.TM_LR_GetProductDistribution !== undefined ? (stateVars.TM_LR_GetProductDistribution?.length > 0 ? stateVars.TM_LR_GetProductDistribution[0].category2Count : null) : (this.state.TM_LR_GetProductDistribution?.length > 0 ? this.state.TM_LR_GetProductDistribution[0].category2Count : null)));
		formVars.leadreport_2113078156_percent = ReactSystemFunctions.value(this, (stateVars.TM_LR_GetProductDistribution !== undefined ? (stateVars.TM_LR_GetProductDistribution?.length > 0 ? stateVars.TM_LR_GetProductDistribution[0].category3Percent : null) : (this.state.TM_LR_GetProductDistribution?.length > 0 ? this.state.TM_LR_GetProductDistribution[0].category3Percent : null)));
		formVars.leadreport_440995668_value = ReactSystemFunctions.toString(this, (stateVars.TM_LR_GetProductDistribution !== undefined ? (stateVars.TM_LR_GetProductDistribution?.length > 0 ? stateVars.TM_LR_GetProductDistribution[0].category3Count : null) : (this.state.TM_LR_GetProductDistribution?.length > 0 ? this.state.TM_LR_GetProductDistribution[0].category3Count : null)));
		stateVars.TM_LR_GetStoreLeadStatus = result?.data.tM_LR_GetStoreLeadStatus;
		
		stateVars.TM_LR_GetStoreProductDistribution = result?.data.tM_LR_GetStoreProductDistribution;
		
		stateVars.TM_LR_GetMonthlyLeadTrend = result?.data.tM_LR_GetMonthlyLeadTrend;
		
		stateVars.TM_LR_GetLeadResultDistribution = result?.data.tM_LR_GetLeadResultDistribution;
		
		this.props.form?.setFieldsValue(formVars);
		
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.LeadReportPageInit1_();
                  resolve();
                });
          })



        
        KuikaAppManager.hideSpinner(this);
        return isErrorOccurred;
    }
	LeadReportPageInit1_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


	if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }

			
			stateVars.dataSource_680946 = stateVars.TM_LR_GetStore ?? this.state.TM_LR_GetStore;
			stateVars.dataSource_680946 = stateVars.TM_LR_GetStore ?? this.state.TM_LR_GetStore;
			
			stateVars.dataSource_889015525 = stateVars.TM_LR_GetSalesPerson ?? this.state.TM_LR_GetSalesPerson;
			stateVars.dataSource_889015525 = stateVars.TM_LR_GetSalesPerson ?? this.state.TM_LR_GetSalesPerson;
			
			stateVars.dataSource_1654656927 = stateVars.TM_LR_GetProductBrand ?? this.state.TM_LR_GetProductBrand;
			stateVars.dataSource_1654656927 = stateVars.TM_LR_GetProductBrand ?? this.state.TM_LR_GetProductBrand;
			
			stateVars.dataSource_2092042287 = stateVars.TM_LR_GetProductCategory ?? this.state.TM_LR_GetProductCategory;
			stateVars.dataSource_2092042287 = stateVars.TM_LR_GetProductCategory ?? this.state.TM_LR_GetProductCategory;
			
			stateVars.dataSource_725505088 = stateVars.TM_LR_GetLeadProcess ?? this.state.TM_LR_GetLeadProcess;
			stateVars.dataSource_725505088 = stateVars.TM_LR_GetLeadProcess ?? this.state.TM_LR_GetLeadProcess;
			
			stateVars.dataSource_1474920253 = stateVars.TM_LR_GetLeadStatus ?? this.state.TM_LR_GetLeadStatus;
			stateVars.dataSource_1474920253 = stateVars.TM_LR_GetLeadStatus ?? this.state.TM_LR_GetLeadStatus;
			formVars.leadreport_2073564093_value = ReactSystemFunctions.toString(this, (stateVars.TM_LR_GetKPI !== undefined ? (stateVars.TM_LR_GetKPI?.length > 0 ? stateVars.TM_LR_GetKPI[0].buAyTerminli : null) : (this.state.TM_LR_GetKPI?.length > 0 ? this.state.TM_LR_GetKPI[0].buAyTerminli : null)));

			formVars.leadreport_1311511404_value = ReactSystemFunctions.toString(this, (stateVars.TM_LR_GetKPI !== undefined ? (stateVars.TM_LR_GetKPI?.length > 0 ? stateVars.TM_LR_GetKPI[0].aktifTakipte : null) : (this.state.TM_LR_GetKPI?.length > 0 ? this.state.TM_LR_GetKPI[0].aktifTakipte : null)));

			formVars.leadreport_1304438269_value = ReactSystemFunctions.toString(this, (stateVars.TM_LR_GetKPI !== undefined ? (stateVars.TM_LR_GetKPI?.length > 0 ? stateVars.TM_LR_GetKPI[0].ikinciTakip : null) : (this.state.TM_LR_GetKPI?.length > 0 ? this.state.TM_LR_GetKPI[0].ikinciTakip : null)));

			formVars.leadreport_1902670072_value = ReactSystemFunctions.toString(this, (stateVars.TM_LR_GetKPI !== undefined ? (stateVars.TM_LR_GetKPI?.length > 0 ? stateVars.TM_LR_GetKPI[0].onayBekleyen : null) : (this.state.TM_LR_GetKPI?.length > 0 ? this.state.TM_LR_GetKPI[0].onayBekleyen : null)));

			formVars.leadreport_233056958_value = ReactSystemFunctions.toString(this, (stateVars.TM_LR_GetKPI !== undefined ? (stateVars.TM_LR_GetKPI?.length > 0 ? stateVars.TM_LR_GetKPI[0].onaylanan : null) : (this.state.TM_LR_GetKPI?.length > 0 ? this.state.TM_LR_GetKPI[0].onaylanan : null)));

			formVars.leadreport_630686224_value = ReactSystemFunctions.toString(this, (stateVars.TM_LR_GetKPI !== undefined ? (stateVars.TM_LR_GetKPI?.length > 0 ? stateVars.TM_LR_GetKPI[0].reddedilen : null) : (this.state.TM_LR_GetKPI?.length > 0 ? this.state.TM_LR_GetKPI[0].reddedilen : null)));

			
			stateVars.dataSource_846576 = stateVars.TM_LR_GetProcessDistribution ?? this.state.TM_LR_GetProcessDistribution;
			stateVars.isComp562299Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, "leadreport_846576_value", "processCode"), ReactSystemFunctions.convertToTypeByName("CREATED", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp436147923Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, "leadreport_846576_value", "processCode"), ReactSystemFunctions.convertToTypeByName("TERMIN_PENDING", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp409002623Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, "leadreport_846576_value", "processCode"), ReactSystemFunctions.convertToTypeByName("PENDING", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp257294576Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, "leadreport_846576_value", "processCode"), ReactSystemFunctions.convertToTypeByName("APPROVED", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp823711768Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, "leadreport_846576_value", "processCode"), ReactSystemFunctions.convertToTypeByName("DELIVERY_PENDING", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp1063961095Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, "leadreport_846576_value", "processCode"), ReactSystemFunctions.convertToTypeByName("DELIVERED", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp1022415963Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, "leadreport_846576_value", "processCode"), ReactSystemFunctions.convertToTypeByName("REJECTED", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp1336153348Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, "leadreport_846576_value", "processCode"), ReactSystemFunctions.convertToTypeByName("CUSTOMER_DECLINED", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp1374188352Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, "leadreport_846576_value", "processCode"), ReactSystemFunctions.convertToTypeByName("CLOSED", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp29676Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, "leadreport_846576_value", "processCode"), ReactSystemFunctions.convertToTypeByName("CREATED", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp1174339289Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, "leadreport_846576_value", "processCode"), ReactSystemFunctions.convertToTypeByName("TERMIN_PENDING", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp1558580705Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, "leadreport_846576_value", "processCode"), ReactSystemFunctions.convertToTypeByName("PENDING", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp1455777370Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, "leadreport_846576_value", "processCode"), ReactSystemFunctions.convertToTypeByName("APPROVED", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp774508948Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, "leadreport_846576_value", "processCode"), ReactSystemFunctions.convertToTypeByName("DELIVERY_PENDING", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp694575305Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, "leadreport_846576_value", "processCode"), ReactSystemFunctions.convertToTypeByName("DELIVERED", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp1755108776Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, "leadreport_846576_value", "processCode"), ReactSystemFunctions.convertToTypeByName("REJECTED", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp615175562Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, "leadreport_846576_value", "processCode"), ReactSystemFunctions.convertToTypeByName("CUSTOMER_DECLINED", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp2589513Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, "leadreport_846576_value", "processCode"), ReactSystemFunctions.convertToTypeByName("CLOSED", "string"))) === true ? "visible" : "hidden")
			
			stateVars.dataSource_672374655 = stateVars.TM_LR_GetStoreDistribution ?? this.state.TM_LR_GetStoreDistribution;
			formVars.leadreport_387818547_percent = ReactSystemFunctions.value(this, (stateVars.TM_LR_GetProductDistribution !== undefined ? (stateVars.TM_LR_GetProductDistribution?.length > 0 ? stateVars.TM_LR_GetProductDistribution[0].tudorPercent : null) : (this.state.TM_LR_GetProductDistribution?.length > 0 ? this.state.TM_LR_GetProductDistribution[0].tudorPercent : null)));

			formVars.leadreport_115241_value = ReactSystemFunctions.toString(this, (stateVars.TM_LR_GetProductDistribution !== undefined ? (stateVars.TM_LR_GetProductDistribution?.length > 0 ? stateVars.TM_LR_GetProductDistribution[0].tudorCount : null) : (this.state.TM_LR_GetProductDistribution?.length > 0 ? this.state.TM_LR_GetProductDistribution[0].tudorCount : null)));

			formVars.leadreport_1979486780_percent = ReactSystemFunctions.value(this, (stateVars.TM_LR_GetProductDistribution !== undefined ? (stateVars.TM_LR_GetProductDistribution?.length > 0 ? stateVars.TM_LR_GetProductDistribution[0].rolexPercent : null) : (this.state.TM_LR_GetProductDistribution?.length > 0 ? this.state.TM_LR_GetProductDistribution[0].rolexPercent : null)));

			formVars.leadreport_348768957_value = ReactSystemFunctions.toString(this, (stateVars.TM_LR_GetProductDistribution !== undefined ? (stateVars.TM_LR_GetProductDistribution?.length > 0 ? stateVars.TM_LR_GetProductDistribution[0].rolexCount : null) : (this.state.TM_LR_GetProductDistribution?.length > 0 ? this.state.TM_LR_GetProductDistribution[0].rolexCount : null)));

			formVars.leadreport_859009014_percent = ReactSystemFunctions.value(this, (stateVars.TM_LR_GetProductDistribution !== undefined ? (stateVars.TM_LR_GetProductDistribution?.length > 0 ? stateVars.TM_LR_GetProductDistribution[0].category1Percent : null) : (this.state.TM_LR_GetProductDistribution?.length > 0 ? this.state.TM_LR_GetProductDistribution[0].category1Percent : null)));

			formVars.leadreport_1630003451_value = ReactSystemFunctions.toString(this, (stateVars.TM_LR_GetProductDistribution !== undefined ? (stateVars.TM_LR_GetProductDistribution?.length > 0 ? stateVars.TM_LR_GetProductDistribution[0].category1Count : null) : (this.state.TM_LR_GetProductDistribution?.length > 0 ? this.state.TM_LR_GetProductDistribution[0].category1Count : null)));

			formVars.leadreport_622538780_percent = ReactSystemFunctions.value(this, (stateVars.TM_LR_GetProductDistribution !== undefined ? (stateVars.TM_LR_GetProductDistribution?.length > 0 ? stateVars.TM_LR_GetProductDistribution[0].category2Percent : null) : (this.state.TM_LR_GetProductDistribution?.length > 0 ? this.state.TM_LR_GetProductDistribution[0].category2Percent : null)));

			formVars.leadreport_2134985305_value = ReactSystemFunctions.toString(this, (stateVars.TM_LR_GetProductDistribution !== undefined ? (stateVars.TM_LR_GetProductDistribution?.length > 0 ? stateVars.TM_LR_GetProductDistribution[0].category2Count : null) : (this.state.TM_LR_GetProductDistribution?.length > 0 ? this.state.TM_LR_GetProductDistribution[0].category2Count : null)));

			formVars.leadreport_2113078156_percent = ReactSystemFunctions.value(this, (stateVars.TM_LR_GetProductDistribution !== undefined ? (stateVars.TM_LR_GetProductDistribution?.length > 0 ? stateVars.TM_LR_GetProductDistribution[0].category3Percent : null) : (this.state.TM_LR_GetProductDistribution?.length > 0 ? this.state.TM_LR_GetProductDistribution[0].category3Percent : null)));

			formVars.leadreport_440995668_value = ReactSystemFunctions.toString(this, (stateVars.TM_LR_GetProductDistribution !== undefined ? (stateVars.TM_LR_GetProductDistribution?.length > 0 ? stateVars.TM_LR_GetProductDistribution[0].category3Count : null) : (this.state.TM_LR_GetProductDistribution?.length > 0 ? this.state.TM_LR_GetProductDistribution[0].category3Count : null)));

			
			stateVars.dataSource_906776 = stateVars.TM_LR_GetMonthlyLeadTrend ?? this.state.TM_LR_GetMonthlyLeadTrend;
			
			stateVars.dataSource_788395 = stateVars.TM_LR_GetLeadResultDistribution ?? this.state.TM_LR_GetLeadResultDistribution;
			
			stateVars.dataSource_353892 = stateVars.TM_LR_GetStoreLeadStatus ?? this.state.TM_LR_GetStoreLeadStatus;
			
			stateVars.dataSource_367777433 = stateVars.TM_LR_GetStoreProductDistribution ?? this.state.TM_LR_GetStoreProductDistribution;
			
			stateVars.dataSource_524175975 = stateVars.TM_GetLeadReportList ?? this.state.TM_GetLeadReportList;
			stateVars.isComp1590928990Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, "leadreport_524175975_value", "kategori"), ReactSystemFunctions.convertToTypeByName("Kategori 2", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp1025399884Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, "leadreport_524175975_value", "kategori"), ReactSystemFunctions.convertToTypeByName("Kategori 1", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp998926227Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, "leadreport_524175975_value", "kategori"), ReactSystemFunctions.convertToTypeByName("Kategori 3", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp629412425Visible = (((ReactSystemFunctions.isNotEqualTo(ReactSystemFunctions.value(this, "leadreport_524175975_value", "kategori"), ReactSystemFunctions.convertToTypeByName("Kategori 1", "string")) && ReactSystemFunctions.isNotEqualTo(ReactSystemFunctions.value(this, "leadreport_524175975_value", "kategori"), ReactSystemFunctions.convertToTypeByName("Kategori 2", "string")) && ReactSystemFunctions.isNotEqualTo(ReactSystemFunctions.value(this, "leadreport_524175975_value", "kategori"), ReactSystemFunctions.convertToTypeByName("Kategori 3", "string")))) === true ? "visible" : "hidden")
			stateVars.isComp48850614Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, "leadreport_524175975_value", "leadStatusCode"), ReactSystemFunctions.convertToTypeByName("FOLLOW_UP_1", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp1839559748Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, "leadreport_524175975_value", "leadStatusCode"), ReactSystemFunctions.convertToTypeByName("FOLLOW_UP_2", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp869566328Visible = (((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, "leadreport_524175975_value", "leadProcessCode"), ReactSystemFunctions.convertToTypeByName("PENDING", "string")) || ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, "leadreport_524175975_value", "leadProcessCode"), ReactSystemFunctions.convertToTypeByName("TERMIN_PENDING", "string")) || ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, "leadreport_524175975_value", "leadProcessCode"), ReactSystemFunctions.convertToTypeByName("DELIVERY_PENDING", "string")))) === true ? "visible" : "hidden")
			stateVars.isComp1326511064Visible = (((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, "leadreport_524175975_value", "leadProcessCode"), ReactSystemFunctions.convertToTypeByName("CUSTOMER_DECLINED", "string")) || ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, "leadreport_524175975_value", "leadProcessCode"), ReactSystemFunctions.convertToTypeByName("REJECTED", "string")))) === true ? "visible" : "hidden")
			stateVars.isComp2084770286Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, "leadreport_524175975_value", "leadProcessCode"), ReactSystemFunctions.convertToTypeByName("DELIVERED", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp1289620961Visible = (((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, "leadreport_524175975_value", "leadProcessCode"), ReactSystemFunctions.convertToTypeByName("APPROVED", "string")) || ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, "leadreport_524175975_value", "leadProcessCode"), ReactSystemFunctions.convertToTypeByName("CREATED", "string")))) === true ? "visible" : "hidden")
			stateVars.isComp809795820Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, "leadreport_524175975_value", "leadProcessCode"), ReactSystemFunctions.convertToTypeByName("CLOSED", "string"))) === true ? "visible" : "hidden")

	this.props.form?.setFieldsValue(formVars);
	this.setState(stateVars);
	KuikaAppManager.hideSpinner(this);

            this.setPageInitLoaded(true);
            return isErrorOccurred;
        }




		LeadReportComponent_680946_onChange = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
KuikaAppManager.showSpinner(this);

				stateVars.SetValueOf = await ReactSystemFunctions.setValueOf(this, ReactSystemFunctions.convertToTypeByName("leadreport_889015525_value", "string"), null, null, "KUserId");

		this.props.form?.setFieldsValue(formVars);
		
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.LeadReportComponent_680946_onChange1_();
                  resolve();
                });
          })

            
            return isErrorOccurred;
        }
    LeadReportComponent_680946_onChange1_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
		KuikaAppManager.increaseServerRequestCount();

        let localVar = {
				KUserId_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.getMyUserId(), "Guid"),
				StoreId_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "leadreport_680946_value", "value", "TM_LR_GetStore", "id", "id")), "Guid")
        }

		
        if (true) {
        KuikaAppManager.showSpinner(this);
        }
        let result = await KuikaAppManager.ApiRequest(this, "LeadReport/LeadReportComponent_680946_onChange1_", localVar)
        if (!KMainFunctions.IsResStatus2XX(result)) return true;

			stateVars.TM_LR_GetSalesPerson = result?.data.tM_LR_GetSalesPerson;
			
			formVars.leadreport_889015525_options = stateVars.TM_LR_GetSalesPerson;
			this.props.form?.setFieldsValue(formVars);
			
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.LeadReportComponent_680946_onChange2_();
                  resolve();
                });
          })



        
        KuikaAppManager.hideSpinner(this);
        return isErrorOccurred;
    }
		LeadReportComponent_680946_onChange2_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }

				
				stateVars.dataSource_889015525 = stateVars.TM_LR_GetSalesPerson ?? this.state.TM_LR_GetSalesPerson;
				stateVars.dataSource_889015525 = stateVars.TM_LR_GetSalesPerson ?? this.state.TM_LR_GetSalesPerson;

		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

            
            return isErrorOccurred;
        }





    LeadReportComponent_889015525_onChange = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
		KuikaAppManager.increaseServerRequestCount();

        let localVar = {
				KUserId_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.getMyUserId(), "Guid"),
				StoreId_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "leadreport_680946_value", "value", "TM_LR_GetStore", "id", "id")), "Guid")
        }

		KuikaAppManager.showSpinner(this);
		
        if (true) {
        KuikaAppManager.showSpinner(this);
        }
        let result = await KuikaAppManager.ApiRequest(this, "LeadReport/LeadReportComponent_889015525_onChange", localVar)
        if (!KMainFunctions.IsResStatus2XX(result)) return true;

			stateVars.TM_LR_GetSalesPerson = result?.data.tM_LR_GetSalesPerson;
			
			formVars.leadreport_889015525_options = stateVars.TM_LR_GetSalesPerson;
			this.props.form?.setFieldsValue(formVars);
			
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.LeadReportComponent_889015525_onChange1_();
                  resolve();
                });
          })



        
        KuikaAppManager.hideSpinner(this);
        return isErrorOccurred;
    }
		LeadReportComponent_889015525_onChange1_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }

				
				stateVars.dataSource_889015525 = stateVars.TM_LR_GetSalesPerson ?? this.state.TM_LR_GetSalesPerson;
				stateVars.dataSource_889015525 = stateVars.TM_LR_GetSalesPerson ?? this.state.TM_LR_GetSalesPerson;

		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

            
            return isErrorOccurred;
        }




		LeadReportComponent_662481_onClick = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
KuikaAppManager.showSpinner(this);

				stateVars.SetValueOf = await ReactSystemFunctions.setValueOf(this, ReactSystemFunctions.convertToTypeByName("leadreport_725505088_value", "string"), null, null, "StepOrder");
				stateVars.SetValueOf = await ReactSystemFunctions.setValueOf(this, ReactSystemFunctions.convertToTypeByName("leadreport_1474920253_value", "string"), null, null, "Id");
				stateVars.SetValueOf = await ReactSystemFunctions.setValueOf(this, ReactSystemFunctions.convertToTypeByName("leadreport_889015525_value", "string"), null, null, "KUserId");
				stateVars.SetValueOf = await ReactSystemFunctions.setValueOf(this, ReactSystemFunctions.convertToTypeByName("leadreport_1654656927_value", "string"), null, null, "Brand");
				stateVars.SetValueOf = await ReactSystemFunctions.setValueOf(this, ReactSystemFunctions.convertToTypeByName("leadreport_680946_value", "string"), null, null, "Id");
				stateVars.SetValueOf = await ReactSystemFunctions.setValueOf(this, ReactSystemFunctions.convertToTypeByName("leadreport_2092042287_value", "string"), null, null, "CategoryCode");
				stateVars.SetValueOf = await ReactSystemFunctions.setValueOf(this, ReactSystemFunctions.convertToTypeByName("leadreport_1208152912_value", "string"), null, null, false);
				stateVars.SetValueOf = await ReactSystemFunctions.setValueOf(this, ReactSystemFunctions.convertToTypeByName("leadreport_128677_value", "string"), null, ReactSystemFunctions.convertToTypeByName("startValue", "string"), false);
				stateVars.SetValueOf = await ReactSystemFunctions.setValueOf(this, ReactSystemFunctions.convertToTypeByName("leadreport_128677_value", "string"), null, ReactSystemFunctions.convertToTypeByName("endValue", "string"), false);

		this.props.form?.setFieldsValue(formVars);
		
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.LeadReportComponent_662481_onClick1_();
                  resolve();
                });
          })

            
            return isErrorOccurred;
        }
    LeadReportComponent_662481_onClick1_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
		KuikaAppManager.increaseServerRequestCount();

        let localVar = {
				KUserId_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.getMyUserId(), "Guid"),
				StoreId_0: ReactSystemFunctions.convertToTypeByName(null, "Guid"),
				UserId_1: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.getMyUserId(), "Guid"),
				StoreIds_1: ReactSystemFunctions.convertToTypeByName(null, "string"),
				Brand_1: ReactSystemFunctions.convertToTypeByName(null, "string"),
				SatisDanismaniIds_1: ReactSystemFunctions.convertToTypeByName(null, "string"),
				StepOrder_1: ReactSystemFunctions.convertToTypeByName(0, "number"),
				StatusIds_1: ReactSystemFunctions.convertToTypeByName(null, "string"),
				CategoryName_1: ReactSystemFunctions.convertToTypeByName(null, "string"),
				ProcessCode_1: ReactSystemFunctions.convertToTypeByName(null, "string"),
				StartDate_1: ReactSystemFunctions.convertToTypeByName(null, "Date"),
				EndDate_1: ReactSystemFunctions.convertToTypeByName(null, "Date"),
				UserId_2: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.getMyUserId(), "Guid"),
				StoreIds_2: ReactSystemFunctions.convertToTypeByName(null, "string"),
				Brand_2: ReactSystemFunctions.convertToTypeByName(null, "string"),
				SatisDanismaniIds_2: ReactSystemFunctions.convertToTypeByName(null, "string"),
				StepOrder_2: ReactSystemFunctions.convertToTypeByName(0, "number"),
				StatusIds_2: ReactSystemFunctions.convertToTypeByName(null, "string"),
				CategoryName_2: ReactSystemFunctions.convertToTypeByName(null, "string"),
				ProcessCode_2: ReactSystemFunctions.convertToTypeByName(null, "string"),
				StartDate_2: ReactSystemFunctions.convertToTypeByName(null, "Date"),
				EndDate_2: ReactSystemFunctions.convertToTypeByName(null, "Date"),
				UserId_3: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.getMyUserId(), "Guid"),
				StoreIds_3: ReactSystemFunctions.convertToTypeByName(null, "string"),
				Brand_3: ReactSystemFunctions.convertToTypeByName(null, "string"),
				SatisDanismaniIds_3: ReactSystemFunctions.convertToTypeByName(null, "string"),
				StepOrder_3: ReactSystemFunctions.convertToTypeByName(0, "number"),
				StatusIds_3: ReactSystemFunctions.convertToTypeByName(null, "string"),
				CategoryName_3: ReactSystemFunctions.convertToTypeByName(null, "string"),
				ProcessCode_3: ReactSystemFunctions.convertToTypeByName(null, "string"),
				StartDate_3: ReactSystemFunctions.convertToTypeByName(null, "Date"),
				EndDate_3: ReactSystemFunctions.convertToTypeByName(null, "Date"),
				UserId_4: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.getMyUserId(), "Guid"),
				StoreIds_4: ReactSystemFunctions.convertToTypeByName(null, "string"),
				Brand_4: ReactSystemFunctions.convertToTypeByName(null, "string"),
				SatisDanismaniIds_4: ReactSystemFunctions.convertToTypeByName(null, "string"),
				StepOrder_4: ReactSystemFunctions.convertToTypeByName(0, "number"),
				StatusIds_4: ReactSystemFunctions.convertToTypeByName(null, "string"),
				CategoryName_4: ReactSystemFunctions.convertToTypeByName(null, "string"),
				ProcessCode_4: ReactSystemFunctions.convertToTypeByName(null, "string"),
				StartDate_4: ReactSystemFunctions.convertToTypeByName(null, "Date"),
				EndDate_4: ReactSystemFunctions.convertToTypeByName(null, "Date"),
				UserId_5: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.getMyUserId(), "Guid"),
				StoreIds_5: ReactSystemFunctions.convertToTypeByName(null, "string"),
				Brand_5: ReactSystemFunctions.convertToTypeByName(null, "string"),
				SatisDanismaniIds_5: ReactSystemFunctions.convertToTypeByName(null, "string"),
				StepOrder_5: ReactSystemFunctions.convertToTypeByName(0, "number"),
				StatusIds_5: ReactSystemFunctions.convertToTypeByName(null, "string"),
				CategoryName_5: ReactSystemFunctions.convertToTypeByName(null, "string"),
				ProcessCode_5: ReactSystemFunctions.convertToTypeByName(null, "string"),
				StartDate_5: ReactSystemFunctions.convertToTypeByName(null, "Date"),
				EndDate_5: ReactSystemFunctions.convertToTypeByName(null, "Date"),
				UserId_6: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.getMyUserId(), "Guid"),
				StoreIds_6: ReactSystemFunctions.convertToTypeByName(null, "string"),
				Brand_6: ReactSystemFunctions.convertToTypeByName(null, "string"),
				SatisDanismaniIds_6: ReactSystemFunctions.convertToTypeByName(null, "string"),
				StepOrder_6: ReactSystemFunctions.convertToTypeByName(0, "number"),
				StatusIds_6: ReactSystemFunctions.convertToTypeByName(null, "string"),
				CategoryName_6: ReactSystemFunctions.convertToTypeByName(null, "string"),
				ProcessCode_6: ReactSystemFunctions.convertToTypeByName(null, "string"),
				StartDate_6: ReactSystemFunctions.convertToTypeByName(null, "Date"),
				EndDate_6: ReactSystemFunctions.convertToTypeByName(null, "Date"),
				UserId_7: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.getMyUserId(), "Guid"),
				StoreIds_7: ReactSystemFunctions.convertToTypeByName(null, "string"),
				Brand_7: ReactSystemFunctions.convertToTypeByName(null, "string"),
				SatisDanismaniIds_7: ReactSystemFunctions.convertToTypeByName(null, "string"),
				StepOrder_7: ReactSystemFunctions.convertToTypeByName(0, "number"),
				StatusIds_7: ReactSystemFunctions.convertToTypeByName(null, "string"),
				CategoryName_7: ReactSystemFunctions.convertToTypeByName(null, "string"),
				ProcessCode_7: ReactSystemFunctions.convertToTypeByName(null, "string"),
				StartDate_7: ReactSystemFunctions.convertToTypeByName(null, "Date"),
				EndDate_7: ReactSystemFunctions.convertToTypeByName(null, "Date"),
				StartDate_8: ReactSystemFunctions.convertToTypeByName(null, "Date"),
				EndDate_8: ReactSystemFunctions.convertToTypeByName(null, "Date"),
				UserId_8: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.getMyUserId(), "Guid"),
				StoreIds_8: ReactSystemFunctions.convertToTypeByName(null, "string"),
				Brand_8: ReactSystemFunctions.convertToTypeByName(null, "string"),
				SatisDanismaniIds_8: ReactSystemFunctions.convertToTypeByName(null, "string"),
				StepOrder_8: ReactSystemFunctions.convertToTypeByName(0, "number"),
				StatusIds_8: ReactSystemFunctions.convertToTypeByName(null, "string"),
				CategoryName_8: ReactSystemFunctions.convertToTypeByName(null, "string"),
				ProcessCode_8: ReactSystemFunctions.convertToTypeByName(null, "string"),
				UserId_9: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.getMyUserId(), "Guid"),
				StoreIds_9: ReactSystemFunctions.convertToTypeByName(null, "string"),
				Brand_9: ReactSystemFunctions.convertToTypeByName(null, "string"),
				SatisDanismaniIds_9: ReactSystemFunctions.convertToTypeByName(null, "string"),
				StepOrder_9: ReactSystemFunctions.convertToTypeByName(0, "number"),
				StatusIds_9: ReactSystemFunctions.convertToTypeByName(null, "string"),
				CategoryName_9: ReactSystemFunctions.convertToTypeByName(null, "string"),
				ProcessCode_9: ReactSystemFunctions.convertToTypeByName(null, "string"),
				StartDate_9: ReactSystemFunctions.convertToTypeByName(null, "Date"),
				EndDate_9: ReactSystemFunctions.convertToTypeByName(null, "Date")
        }

		
        if (true) {
        KuikaAppManager.showSpinner(this);
        }
        let result = await KuikaAppManager.ApiRequest(this, "LeadReport/LeadReportComponent_662481_onClick1_", localVar)
        if (!KMainFunctions.IsResStatus2XX(result)) return true;

			stateVars.TM_LR_GetSalesPerson = result?.data.tM_LR_GetSalesPerson;
			
			formVars.leadreport_889015525_options = stateVars.TM_LR_GetSalesPerson;
			stateVars.TM_GetLeadReportList = result?.data.tM_GetLeadReportList;
			
			stateVars.TM_LR_GetKPI = result?.data.tM_LR_GetKPI;
			formVars.leadreport_2073564093_value = ReactSystemFunctions.toString(this, (stateVars.TM_LR_GetKPI !== undefined ? (stateVars.TM_LR_GetKPI?.length > 0 ? stateVars.TM_LR_GetKPI[0].buAyTerminli : null) : (this.state.TM_LR_GetKPI?.length > 0 ? this.state.TM_LR_GetKPI[0].buAyTerminli : null)));
			formVars.leadreport_1311511404_value = ReactSystemFunctions.toString(this, (stateVars.TM_LR_GetKPI !== undefined ? (stateVars.TM_LR_GetKPI?.length > 0 ? stateVars.TM_LR_GetKPI[0].aktifTakipte : null) : (this.state.TM_LR_GetKPI?.length > 0 ? this.state.TM_LR_GetKPI[0].aktifTakipte : null)));
			formVars.leadreport_1304438269_value = ReactSystemFunctions.toString(this, (stateVars.TM_LR_GetKPI !== undefined ? (stateVars.TM_LR_GetKPI?.length > 0 ? stateVars.TM_LR_GetKPI[0].ikinciTakip : null) : (this.state.TM_LR_GetKPI?.length > 0 ? this.state.TM_LR_GetKPI[0].ikinciTakip : null)));
			formVars.leadreport_1902670072_value = ReactSystemFunctions.toString(this, (stateVars.TM_LR_GetKPI !== undefined ? (stateVars.TM_LR_GetKPI?.length > 0 ? stateVars.TM_LR_GetKPI[0].onayBekleyen : null) : (this.state.TM_LR_GetKPI?.length > 0 ? this.state.TM_LR_GetKPI[0].onayBekleyen : null)));
			formVars.leadreport_233056958_value = ReactSystemFunctions.toString(this, (stateVars.TM_LR_GetKPI !== undefined ? (stateVars.TM_LR_GetKPI?.length > 0 ? stateVars.TM_LR_GetKPI[0].onaylanan : null) : (this.state.TM_LR_GetKPI?.length > 0 ? this.state.TM_LR_GetKPI[0].onaylanan : null)));
			formVars.leadreport_630686224_value = ReactSystemFunctions.toString(this, (stateVars.TM_LR_GetKPI !== undefined ? (stateVars.TM_LR_GetKPI?.length > 0 ? stateVars.TM_LR_GetKPI[0].reddedilen : null) : (this.state.TM_LR_GetKPI?.length > 0 ? this.state.TM_LR_GetKPI[0].reddedilen : null)));
			stateVars.TM_LR_GetProcessDistribution = result?.data.tM_LR_GetProcessDistribution;
			
			stateVars.TM_LR_GetStoreDistribution = result?.data.tM_LR_GetStoreDistribution;
			
			stateVars.TM_LR_GetProductDistribution = result?.data.tM_LR_GetProductDistribution;
			formVars.leadreport_387818547_percent = ReactSystemFunctions.value(this, (stateVars.TM_LR_GetProductDistribution !== undefined ? (stateVars.TM_LR_GetProductDistribution?.length > 0 ? stateVars.TM_LR_GetProductDistribution[0].tudorPercent : null) : (this.state.TM_LR_GetProductDistribution?.length > 0 ? this.state.TM_LR_GetProductDistribution[0].tudorPercent : null)));
			formVars.leadreport_115241_value = ReactSystemFunctions.toString(this, (stateVars.TM_LR_GetProductDistribution !== undefined ? (stateVars.TM_LR_GetProductDistribution?.length > 0 ? stateVars.TM_LR_GetProductDistribution[0].tudorCount : null) : (this.state.TM_LR_GetProductDistribution?.length > 0 ? this.state.TM_LR_GetProductDistribution[0].tudorCount : null)));
			formVars.leadreport_1979486780_percent = ReactSystemFunctions.value(this, (stateVars.TM_LR_GetProductDistribution !== undefined ? (stateVars.TM_LR_GetProductDistribution?.length > 0 ? stateVars.TM_LR_GetProductDistribution[0].rolexPercent : null) : (this.state.TM_LR_GetProductDistribution?.length > 0 ? this.state.TM_LR_GetProductDistribution[0].rolexPercent : null)));
			formVars.leadreport_348768957_value = ReactSystemFunctions.toString(this, (stateVars.TM_LR_GetProductDistribution !== undefined ? (stateVars.TM_LR_GetProductDistribution?.length > 0 ? stateVars.TM_LR_GetProductDistribution[0].rolexCount : null) : (this.state.TM_LR_GetProductDistribution?.length > 0 ? this.state.TM_LR_GetProductDistribution[0].rolexCount : null)));
			formVars.leadreport_859009014_percent = ReactSystemFunctions.value(this, (stateVars.TM_LR_GetProductDistribution !== undefined ? (stateVars.TM_LR_GetProductDistribution?.length > 0 ? stateVars.TM_LR_GetProductDistribution[0].category1Percent : null) : (this.state.TM_LR_GetProductDistribution?.length > 0 ? this.state.TM_LR_GetProductDistribution[0].category1Percent : null)));
			formVars.leadreport_1630003451_value = ReactSystemFunctions.toString(this, (stateVars.TM_LR_GetProductDistribution !== undefined ? (stateVars.TM_LR_GetProductDistribution?.length > 0 ? stateVars.TM_LR_GetProductDistribution[0].category1Count : null) : (this.state.TM_LR_GetProductDistribution?.length > 0 ? this.state.TM_LR_GetProductDistribution[0].category1Count : null)));
			formVars.leadreport_622538780_percent = ReactSystemFunctions.value(this, (stateVars.TM_LR_GetProductDistribution !== undefined ? (stateVars.TM_LR_GetProductDistribution?.length > 0 ? stateVars.TM_LR_GetProductDistribution[0].category2Percent : null) : (this.state.TM_LR_GetProductDistribution?.length > 0 ? this.state.TM_LR_GetProductDistribution[0].category2Percent : null)));
			formVars.leadreport_2134985305_value = ReactSystemFunctions.toString(this, (stateVars.TM_LR_GetProductDistribution !== undefined ? (stateVars.TM_LR_GetProductDistribution?.length > 0 ? stateVars.TM_LR_GetProductDistribution[0].category2Count : null) : (this.state.TM_LR_GetProductDistribution?.length > 0 ? this.state.TM_LR_GetProductDistribution[0].category2Count : null)));
			formVars.leadreport_2113078156_percent = ReactSystemFunctions.value(this, (stateVars.TM_LR_GetProductDistribution !== undefined ? (stateVars.TM_LR_GetProductDistribution?.length > 0 ? stateVars.TM_LR_GetProductDistribution[0].category3Percent : null) : (this.state.TM_LR_GetProductDistribution?.length > 0 ? this.state.TM_LR_GetProductDistribution[0].category3Percent : null)));
			formVars.leadreport_440995668_value = ReactSystemFunctions.toString(this, (stateVars.TM_LR_GetProductDistribution !== undefined ? (stateVars.TM_LR_GetProductDistribution?.length > 0 ? stateVars.TM_LR_GetProductDistribution[0].category3Count : null) : (this.state.TM_LR_GetProductDistribution?.length > 0 ? this.state.TM_LR_GetProductDistribution[0].category3Count : null)));
			stateVars.TM_LR_GetStoreLeadStatus = result?.data.tM_LR_GetStoreLeadStatus;
			
			stateVars.TM_LR_GetStoreProductDistribution = result?.data.tM_LR_GetStoreProductDistribution;
			
			stateVars.TM_LR_GetMonthlyLeadTrend = result?.data.tM_LR_GetMonthlyLeadTrend;
			
			stateVars.TM_LR_GetLeadResultDistribution = result?.data.tM_LR_GetLeadResultDistribution;
			
			this.props.form?.setFieldsValue(formVars);
			
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.LeadReportComponent_662481_onClick2_();
                  resolve();
                });
          })



        
        KuikaAppManager.hideSpinner(this);
        return isErrorOccurred;
    }
		LeadReportComponent_662481_onClick2_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }

				
				stateVars.dataSource_889015525 = stateVars.TM_LR_GetSalesPerson ?? this.state.TM_LR_GetSalesPerson;
				stateVars.dataSource_889015525 = stateVars.TM_LR_GetSalesPerson ?? this.state.TM_LR_GetSalesPerson;
				formVars.leadreport_2073564093_value = ReactSystemFunctions.toString(this, (stateVars.TM_LR_GetKPI !== undefined ? (stateVars.TM_LR_GetKPI?.length > 0 ? stateVars.TM_LR_GetKPI[0].buAyTerminli : null) : (this.state.TM_LR_GetKPI?.length > 0 ? this.state.TM_LR_GetKPI[0].buAyTerminli : null)));

				formVars.leadreport_1311511404_value = ReactSystemFunctions.toString(this, (stateVars.TM_LR_GetKPI !== undefined ? (stateVars.TM_LR_GetKPI?.length > 0 ? stateVars.TM_LR_GetKPI[0].aktifTakipte : null) : (this.state.TM_LR_GetKPI?.length > 0 ? this.state.TM_LR_GetKPI[0].aktifTakipte : null)));

				formVars.leadreport_1304438269_value = ReactSystemFunctions.toString(this, (stateVars.TM_LR_GetKPI !== undefined ? (stateVars.TM_LR_GetKPI?.length > 0 ? stateVars.TM_LR_GetKPI[0].ikinciTakip : null) : (this.state.TM_LR_GetKPI?.length > 0 ? this.state.TM_LR_GetKPI[0].ikinciTakip : null)));

				formVars.leadreport_1902670072_value = ReactSystemFunctions.toString(this, (stateVars.TM_LR_GetKPI !== undefined ? (stateVars.TM_LR_GetKPI?.length > 0 ? stateVars.TM_LR_GetKPI[0].onayBekleyen : null) : (this.state.TM_LR_GetKPI?.length > 0 ? this.state.TM_LR_GetKPI[0].onayBekleyen : null)));

				formVars.leadreport_233056958_value = ReactSystemFunctions.toString(this, (stateVars.TM_LR_GetKPI !== undefined ? (stateVars.TM_LR_GetKPI?.length > 0 ? stateVars.TM_LR_GetKPI[0].onaylanan : null) : (this.state.TM_LR_GetKPI?.length > 0 ? this.state.TM_LR_GetKPI[0].onaylanan : null)));

				formVars.leadreport_630686224_value = ReactSystemFunctions.toString(this, (stateVars.TM_LR_GetKPI !== undefined ? (stateVars.TM_LR_GetKPI?.length > 0 ? stateVars.TM_LR_GetKPI[0].reddedilen : null) : (this.state.TM_LR_GetKPI?.length > 0 ? this.state.TM_LR_GetKPI[0].reddedilen : null)));

				
				stateVars.dataSource_846576 = stateVars.TM_LR_GetProcessDistribution ?? this.state.TM_LR_GetProcessDistribution;
				
				stateVars.dataSource_672374655 = stateVars.TM_LR_GetStoreDistribution ?? this.state.TM_LR_GetStoreDistribution;
				formVars.leadreport_387818547_percent = ReactSystemFunctions.value(this, (stateVars.TM_LR_GetProductDistribution !== undefined ? (stateVars.TM_LR_GetProductDistribution?.length > 0 ? stateVars.TM_LR_GetProductDistribution[0].tudorPercent : null) : (this.state.TM_LR_GetProductDistribution?.length > 0 ? this.state.TM_LR_GetProductDistribution[0].tudorPercent : null)));

				formVars.leadreport_115241_value = ReactSystemFunctions.toString(this, (stateVars.TM_LR_GetProductDistribution !== undefined ? (stateVars.TM_LR_GetProductDistribution?.length > 0 ? stateVars.TM_LR_GetProductDistribution[0].tudorCount : null) : (this.state.TM_LR_GetProductDistribution?.length > 0 ? this.state.TM_LR_GetProductDistribution[0].tudorCount : null)));

				formVars.leadreport_1979486780_percent = ReactSystemFunctions.value(this, (stateVars.TM_LR_GetProductDistribution !== undefined ? (stateVars.TM_LR_GetProductDistribution?.length > 0 ? stateVars.TM_LR_GetProductDistribution[0].rolexPercent : null) : (this.state.TM_LR_GetProductDistribution?.length > 0 ? this.state.TM_LR_GetProductDistribution[0].rolexPercent : null)));

				formVars.leadreport_348768957_value = ReactSystemFunctions.toString(this, (stateVars.TM_LR_GetProductDistribution !== undefined ? (stateVars.TM_LR_GetProductDistribution?.length > 0 ? stateVars.TM_LR_GetProductDistribution[0].rolexCount : null) : (this.state.TM_LR_GetProductDistribution?.length > 0 ? this.state.TM_LR_GetProductDistribution[0].rolexCount : null)));

				formVars.leadreport_859009014_percent = ReactSystemFunctions.value(this, (stateVars.TM_LR_GetProductDistribution !== undefined ? (stateVars.TM_LR_GetProductDistribution?.length > 0 ? stateVars.TM_LR_GetProductDistribution[0].category1Percent : null) : (this.state.TM_LR_GetProductDistribution?.length > 0 ? this.state.TM_LR_GetProductDistribution[0].category1Percent : null)));

				formVars.leadreport_1630003451_value = ReactSystemFunctions.toString(this, (stateVars.TM_LR_GetProductDistribution !== undefined ? (stateVars.TM_LR_GetProductDistribution?.length > 0 ? stateVars.TM_LR_GetProductDistribution[0].category1Count : null) : (this.state.TM_LR_GetProductDistribution?.length > 0 ? this.state.TM_LR_GetProductDistribution[0].category1Count : null)));

				formVars.leadreport_622538780_percent = ReactSystemFunctions.value(this, (stateVars.TM_LR_GetProductDistribution !== undefined ? (stateVars.TM_LR_GetProductDistribution?.length > 0 ? stateVars.TM_LR_GetProductDistribution[0].category2Percent : null) : (this.state.TM_LR_GetProductDistribution?.length > 0 ? this.state.TM_LR_GetProductDistribution[0].category2Percent : null)));

				formVars.leadreport_2134985305_value = ReactSystemFunctions.toString(this, (stateVars.TM_LR_GetProductDistribution !== undefined ? (stateVars.TM_LR_GetProductDistribution?.length > 0 ? stateVars.TM_LR_GetProductDistribution[0].category2Count : null) : (this.state.TM_LR_GetProductDistribution?.length > 0 ? this.state.TM_LR_GetProductDistribution[0].category2Count : null)));

				formVars.leadreport_2113078156_percent = ReactSystemFunctions.value(this, (stateVars.TM_LR_GetProductDistribution !== undefined ? (stateVars.TM_LR_GetProductDistribution?.length > 0 ? stateVars.TM_LR_GetProductDistribution[0].category3Percent : null) : (this.state.TM_LR_GetProductDistribution?.length > 0 ? this.state.TM_LR_GetProductDistribution[0].category3Percent : null)));

				formVars.leadreport_440995668_value = ReactSystemFunctions.toString(this, (stateVars.TM_LR_GetProductDistribution !== undefined ? (stateVars.TM_LR_GetProductDistribution?.length > 0 ? stateVars.TM_LR_GetProductDistribution[0].category3Count : null) : (this.state.TM_LR_GetProductDistribution?.length > 0 ? this.state.TM_LR_GetProductDistribution[0].category3Count : null)));

				
				stateVars.dataSource_906776 = stateVars.TM_LR_GetMonthlyLeadTrend ?? this.state.TM_LR_GetMonthlyLeadTrend;
				
				stateVars.dataSource_788395 = stateVars.TM_LR_GetLeadResultDistribution ?? this.state.TM_LR_GetLeadResultDistribution;
				
				stateVars.dataSource_353892 = stateVars.TM_LR_GetStoreLeadStatus ?? this.state.TM_LR_GetStoreLeadStatus;
				
				stateVars.dataSource_367777433 = stateVars.TM_LR_GetStoreProductDistribution ?? this.state.TM_LR_GetStoreProductDistribution;
				
				stateVars.dataSource_524175975 = stateVars.TM_GetLeadReportList ?? this.state.TM_GetLeadReportList;

		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

            
            return isErrorOccurred;
        }





    LeadReportComponent_886840_onClick = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
		KuikaAppManager.increaseServerRequestCount();

        let localVar = {
				UserId_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.getMyUserId(), "Guid"),
				StoreIds_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "leadreport_680946_value", "value", "TM_LR_GetStore", "id", "id")), "string"),
				Brand_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "leadreport_1654656927_value", "value", "TM_LR_GetProductBrand", "brand", "brand")), "string"),
				SatisDanismaniIds_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "leadreport_889015525_value", "value", "TM_LR_GetSalesPerson", "kUserId", "kUserId")), "string"),
				StepOrder_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "leadreport_725505088_value", "value", "TM_LR_GetLeadProcess", "stepOrder", "stepOrder")), "number"),
				StatusIds_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "leadreport_1474920253_value", "value", "TM_LR_GetLeadStatus", "id", "id")), "string"),
				CategoryName_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "leadreport_2092042287_value", "value", "TM_LR_GetProductCategory", "categoryCode", "categoryName")), "string"),
				ProcessCode_0: ReactSystemFunctions.convertToTypeByName(null, "string"),
				StartDate_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "leadreport_128677_value", "startValue", "", "", "")), "Date"),
				EndDate_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "leadreport_128677_value", "endValue", "", "", "")), "Date"),
				UserId_1: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.getMyUserId(), "Guid"),
				StoreIds_1: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "leadreport_680946_value", "value", "TM_LR_GetStore", "id", "id")), "string"),
				Brand_1: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "leadreport_1654656927_value", "value", "TM_LR_GetProductBrand", "brand", "brand")), "string"),
				SatisDanismaniIds_1: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "leadreport_889015525_value", "value", "TM_LR_GetSalesPerson", "kUserId", "kUserId")), "string"),
				StepOrder_1: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "leadreport_725505088_value", "value", "TM_LR_GetLeadProcess", "stepOrder", "stepOrder")), "number"),
				StatusIds_1: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "leadreport_1474920253_value", "value", "TM_LR_GetLeadStatus", "id", "id")), "string"),
				CategoryName_1: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "leadreport_2092042287_value", "value", "TM_LR_GetProductCategory", "categoryCode", "categoryName")), "string"),
				ProcessCode_1: ReactSystemFunctions.convertToTypeByName(null, "string"),
				StartDate_1: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "leadreport_128677_value", "startValue", "", "", "")), "Date"),
				EndDate_1: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "leadreport_128677_value", "endValue", "", "", "")), "Date"),
				UserId_2: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.getMyUserId(), "Guid"),
				StoreIds_2: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "leadreport_680946_value", "value", "TM_LR_GetStore", "id", "id")), "string"),
				Brand_2: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "leadreport_1654656927_value", "value", "TM_LR_GetProductBrand", "brand", "brand")), "string"),
				SatisDanismaniIds_2: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "leadreport_889015525_value", "value", "TM_LR_GetSalesPerson", "kUserId", "kUserId")), "string"),
				StepOrder_2: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "leadreport_725505088_value", "value", "TM_LR_GetLeadProcess", "stepOrder", "stepOrder")), "number"),
				StatusIds_2: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "leadreport_1474920253_value", "value", "TM_LR_GetLeadStatus", "id", "id")), "string"),
				CategoryName_2: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "leadreport_2092042287_value", "value", "TM_LR_GetProductCategory", "categoryCode", "categoryName")), "string"),
				ProcessCode_2: ReactSystemFunctions.convertToTypeByName(null, "string"),
				StartDate_2: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "leadreport_128677_value", "startValue", "", "", "")), "Date"),
				EndDate_2: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "leadreport_128677_value", "endValue", "", "", "")), "Date"),
				UserId_3: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.getMyUserId(), "Guid"),
				StoreIds_3: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "leadreport_680946_value", "value", "TM_LR_GetStore", "id", "id")), "string"),
				Brand_3: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "leadreport_1654656927_value", "value", "TM_LR_GetProductBrand", "brand", "brand")), "string"),
				SatisDanismaniIds_3: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "leadreport_889015525_value", "value", "TM_LR_GetSalesPerson", "kUserId", "kUserId")), "string"),
				StepOrder_3: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "leadreport_725505088_value", "value", "TM_LR_GetLeadProcess", "stepOrder", "stepOrder")), "number"),
				StatusIds_3: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "leadreport_1474920253_value", "value", "TM_LR_GetLeadStatus", "id", "id")), "string"),
				CategoryName_3: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "leadreport_2092042287_value", "value", "TM_LR_GetProductCategory", "categoryCode", "categoryName")), "string"),
				ProcessCode_3: ReactSystemFunctions.convertToTypeByName(null, "string"),
				StartDate_3: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "leadreport_128677_value", "startValue", "", "", "")), "Date"),
				EndDate_3: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "leadreport_128677_value", "endValue", "", "", "")), "Date"),
				UserId_4: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.getMyUserId(), "Guid"),
				StoreIds_4: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "leadreport_680946_value", "value", "TM_LR_GetStore", "id", "id")), "string"),
				Brand_4: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "leadreport_1654656927_value", "value", "TM_LR_GetProductBrand", "brand", "brand")), "string"),
				SatisDanismaniIds_4: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "leadreport_889015525_value", "value", "TM_LR_GetSalesPerson", "kUserId", "kUserId")), "string"),
				StepOrder_4: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "leadreport_725505088_value", "value", "TM_LR_GetLeadProcess", "stepOrder", "stepOrder")), "number"),
				StatusIds_4: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "leadreport_1474920253_value", "value", "TM_LR_GetLeadStatus", "id", "id")), "string"),
				CategoryName_4: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "leadreport_2092042287_value", "value", "TM_LR_GetProductCategory", "categoryCode", "categoryName")), "string"),
				ProcessCode_4: ReactSystemFunctions.convertToTypeByName(null, "string"),
				StartDate_4: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "leadreport_128677_value", "startValue", "", "", "")), "Date"),
				EndDate_4: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "leadreport_128677_value", "endValue", "", "", "")), "Date"),
				UserId_5: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.getMyUserId(), "Guid"),
				StoreIds_5: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "leadreport_680946_value", "value", "TM_LR_GetStore", "id", "id")), "string"),
				Brand_5: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "leadreport_1654656927_value", "value", "TM_LR_GetProductBrand", "brand", "brand")), "string"),
				SatisDanismaniIds_5: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "leadreport_889015525_value", "value", "TM_LR_GetSalesPerson", "kUserId", "kUserId")), "string"),
				StepOrder_5: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "leadreport_725505088_value", "value", "TM_LR_GetLeadProcess", "stepOrder", "stepOrder")), "number"),
				StatusIds_5: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "leadreport_1474920253_value", "value", "TM_LR_GetLeadStatus", "id", "id")), "string"),
				CategoryName_5: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "leadreport_2092042287_value", "value", "TM_LR_GetProductCategory", "categoryCode", "categoryName")), "string"),
				ProcessCode_5: ReactSystemFunctions.convertToTypeByName(null, "string"),
				StartDate_5: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "leadreport_128677_value", "startValue", "", "", "")), "Date"),
				EndDate_5: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "leadreport_128677_value", "endValue", "", "", "")), "Date"),
				UserId_6: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.getMyUserId(), "Guid"),
				StoreIds_6: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "leadreport_680946_value", "value", "TM_LR_GetStore", "id", "id")), "string"),
				Brand_6: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "leadreport_1654656927_value", "value", "TM_LR_GetProductBrand", "brand", "brand")), "string"),
				SatisDanismaniIds_6: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "leadreport_889015525_value", "value", "TM_LR_GetSalesPerson", "kUserId", "kUserId")), "string"),
				StepOrder_6: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "leadreport_725505088_value", "value", "TM_LR_GetLeadProcess", "stepOrder", "stepOrder")), "number"),
				StatusIds_6: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "leadreport_1474920253_value", "value", "TM_LR_GetLeadStatus", "id", "id")), "string"),
				CategoryName_6: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "leadreport_2092042287_value", "value", "TM_LR_GetProductCategory", "categoryCode", "categoryName")), "string"),
				ProcessCode_6: ReactSystemFunctions.convertToTypeByName(null, "string"),
				StartDate_6: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "leadreport_128677_value", "startValue", "", "", "")), "Date"),
				EndDate_6: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "leadreport_128677_value", "endValue", "", "", "")), "Date"),
				StartDate_7: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "leadreport_128677_value", "startValue", "", "", "")), "Date"),
				EndDate_7: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "leadreport_128677_value", "endValue", "", "", "")), "Date"),
				UserId_7: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.getMyUserId(), "Guid"),
				StoreIds_7: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "leadreport_680946_value", "value", "TM_LR_GetStore", "id", "id")), "string"),
				Brand_7: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "leadreport_1654656927_value", "value", "TM_LR_GetProductBrand", "brand", "brand")), "string"),
				SatisDanismaniIds_7: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "leadreport_889015525_value", "value", "TM_LR_GetSalesPerson", "kUserId", "kUserId")), "string"),
				StepOrder_7: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "leadreport_725505088_value", "value", "TM_LR_GetLeadProcess", "stepOrder", "stepOrder")), "number"),
				StatusIds_7: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "leadreport_1474920253_value", "value", "TM_LR_GetLeadStatus", "id", "id")), "string"),
				CategoryName_7: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "leadreport_2092042287_value", "value", "TM_LR_GetProductCategory", "categoryCode", "categoryName")), "string"),
				ProcessCode_7: ReactSystemFunctions.convertToTypeByName(null, "string"),
				UserId_8: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.getMyUserId(), "Guid"),
				StoreIds_8: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "leadreport_680946_value", "value", "TM_LR_GetStore", "id", "id")), "string"),
				Brand_8: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "leadreport_1654656927_value", "value", "TM_LR_GetProductBrand", "brand", "brand")), "string"),
				SatisDanismaniIds_8: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "leadreport_889015525_value", "value", "TM_LR_GetSalesPerson", "kUserId", "kUserId")), "string"),
				StepOrder_8: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "leadreport_725505088_value", "value", "TM_LR_GetLeadProcess", "stepOrder", "stepOrder")), "number"),
				StatusIds_8: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "leadreport_1474920253_value", "value", "TM_LR_GetLeadStatus", "id", "id")), "string"),
				CategoryName_8: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "leadreport_2092042287_value", "value", "TM_LR_GetProductCategory", "categoryCode", "categoryName")), "string"),
				ProcessCode_8: ReactSystemFunctions.convertToTypeByName(null, "string"),
				StartDate_8: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "leadreport_128677_value", "startValue", "", "", "")), "Date"),
				EndDate_8: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "leadreport_128677_value", "endValue", "", "", "")), "Date")
        }

		KuikaAppManager.showSpinner(this);
		
        if (true) {
        KuikaAppManager.showSpinner(this);
        }
        let result = await KuikaAppManager.ApiRequest(this, "LeadReport/LeadReportComponent_886840_onClick", localVar)
        if (!KMainFunctions.IsResStatus2XX(result)) return true;

			stateVars.TM_GetLeadReportList = result?.data.tM_GetLeadReportList;
			
			stateVars.TM_LR_GetKPI = result?.data.tM_LR_GetKPI;
			formVars.leadreport_2073564093_value = ReactSystemFunctions.toString(this, (stateVars.TM_LR_GetKPI !== undefined ? (stateVars.TM_LR_GetKPI?.length > 0 ? stateVars.TM_LR_GetKPI[0].buAyTerminli : null) : (this.state.TM_LR_GetKPI?.length > 0 ? this.state.TM_LR_GetKPI[0].buAyTerminli : null)));
			formVars.leadreport_1311511404_value = ReactSystemFunctions.toString(this, (stateVars.TM_LR_GetKPI !== undefined ? (stateVars.TM_LR_GetKPI?.length > 0 ? stateVars.TM_LR_GetKPI[0].aktifTakipte : null) : (this.state.TM_LR_GetKPI?.length > 0 ? this.state.TM_LR_GetKPI[0].aktifTakipte : null)));
			formVars.leadreport_1304438269_value = ReactSystemFunctions.toString(this, (stateVars.TM_LR_GetKPI !== undefined ? (stateVars.TM_LR_GetKPI?.length > 0 ? stateVars.TM_LR_GetKPI[0].ikinciTakip : null) : (this.state.TM_LR_GetKPI?.length > 0 ? this.state.TM_LR_GetKPI[0].ikinciTakip : null)));
			formVars.leadreport_1902670072_value = ReactSystemFunctions.toString(this, (stateVars.TM_LR_GetKPI !== undefined ? (stateVars.TM_LR_GetKPI?.length > 0 ? stateVars.TM_LR_GetKPI[0].onayBekleyen : null) : (this.state.TM_LR_GetKPI?.length > 0 ? this.state.TM_LR_GetKPI[0].onayBekleyen : null)));
			formVars.leadreport_233056958_value = ReactSystemFunctions.toString(this, (stateVars.TM_LR_GetKPI !== undefined ? (stateVars.TM_LR_GetKPI?.length > 0 ? stateVars.TM_LR_GetKPI[0].onaylanan : null) : (this.state.TM_LR_GetKPI?.length > 0 ? this.state.TM_LR_GetKPI[0].onaylanan : null)));
			formVars.leadreport_630686224_value = ReactSystemFunctions.toString(this, (stateVars.TM_LR_GetKPI !== undefined ? (stateVars.TM_LR_GetKPI?.length > 0 ? stateVars.TM_LR_GetKPI[0].reddedilen : null) : (this.state.TM_LR_GetKPI?.length > 0 ? this.state.TM_LR_GetKPI[0].reddedilen : null)));
			stateVars.TM_LR_GetProcessDistribution = result?.data.tM_LR_GetProcessDistribution;
			
			stateVars.TM_LR_GetStoreDistribution = result?.data.tM_LR_GetStoreDistribution;
			
			stateVars.TM_LR_GetProductDistribution = result?.data.tM_LR_GetProductDistribution;
			formVars.leadreport_387818547_percent = ReactSystemFunctions.value(this, (stateVars.TM_LR_GetProductDistribution !== undefined ? (stateVars.TM_LR_GetProductDistribution?.length > 0 ? stateVars.TM_LR_GetProductDistribution[0].tudorPercent : null) : (this.state.TM_LR_GetProductDistribution?.length > 0 ? this.state.TM_LR_GetProductDistribution[0].tudorPercent : null)));
			formVars.leadreport_115241_value = ReactSystemFunctions.toString(this, (stateVars.TM_LR_GetProductDistribution !== undefined ? (stateVars.TM_LR_GetProductDistribution?.length > 0 ? stateVars.TM_LR_GetProductDistribution[0].tudorCount : null) : (this.state.TM_LR_GetProductDistribution?.length > 0 ? this.state.TM_LR_GetProductDistribution[0].tudorCount : null)));
			formVars.leadreport_1979486780_percent = ReactSystemFunctions.value(this, (stateVars.TM_LR_GetProductDistribution !== undefined ? (stateVars.TM_LR_GetProductDistribution?.length > 0 ? stateVars.TM_LR_GetProductDistribution[0].rolexPercent : null) : (this.state.TM_LR_GetProductDistribution?.length > 0 ? this.state.TM_LR_GetProductDistribution[0].rolexPercent : null)));
			formVars.leadreport_348768957_value = ReactSystemFunctions.toString(this, (stateVars.TM_LR_GetProductDistribution !== undefined ? (stateVars.TM_LR_GetProductDistribution?.length > 0 ? stateVars.TM_LR_GetProductDistribution[0].rolexCount : null) : (this.state.TM_LR_GetProductDistribution?.length > 0 ? this.state.TM_LR_GetProductDistribution[0].rolexCount : null)));
			formVars.leadreport_859009014_percent = ReactSystemFunctions.value(this, (stateVars.TM_LR_GetProductDistribution !== undefined ? (stateVars.TM_LR_GetProductDistribution?.length > 0 ? stateVars.TM_LR_GetProductDistribution[0].category1Percent : null) : (this.state.TM_LR_GetProductDistribution?.length > 0 ? this.state.TM_LR_GetProductDistribution[0].category1Percent : null)));
			formVars.leadreport_1630003451_value = ReactSystemFunctions.toString(this, (stateVars.TM_LR_GetProductDistribution !== undefined ? (stateVars.TM_LR_GetProductDistribution?.length > 0 ? stateVars.TM_LR_GetProductDistribution[0].category1Count : null) : (this.state.TM_LR_GetProductDistribution?.length > 0 ? this.state.TM_LR_GetProductDistribution[0].category1Count : null)));
			formVars.leadreport_622538780_percent = ReactSystemFunctions.value(this, (stateVars.TM_LR_GetProductDistribution !== undefined ? (stateVars.TM_LR_GetProductDistribution?.length > 0 ? stateVars.TM_LR_GetProductDistribution[0].category2Percent : null) : (this.state.TM_LR_GetProductDistribution?.length > 0 ? this.state.TM_LR_GetProductDistribution[0].category2Percent : null)));
			formVars.leadreport_2134985305_value = ReactSystemFunctions.toString(this, (stateVars.TM_LR_GetProductDistribution !== undefined ? (stateVars.TM_LR_GetProductDistribution?.length > 0 ? stateVars.TM_LR_GetProductDistribution[0].category2Count : null) : (this.state.TM_LR_GetProductDistribution?.length > 0 ? this.state.TM_LR_GetProductDistribution[0].category2Count : null)));
			formVars.leadreport_2113078156_percent = ReactSystemFunctions.value(this, (stateVars.TM_LR_GetProductDistribution !== undefined ? (stateVars.TM_LR_GetProductDistribution?.length > 0 ? stateVars.TM_LR_GetProductDistribution[0].category3Percent : null) : (this.state.TM_LR_GetProductDistribution?.length > 0 ? this.state.TM_LR_GetProductDistribution[0].category3Percent : null)));
			formVars.leadreport_440995668_value = ReactSystemFunctions.toString(this, (stateVars.TM_LR_GetProductDistribution !== undefined ? (stateVars.TM_LR_GetProductDistribution?.length > 0 ? stateVars.TM_LR_GetProductDistribution[0].category3Count : null) : (this.state.TM_LR_GetProductDistribution?.length > 0 ? this.state.TM_LR_GetProductDistribution[0].category3Count : null)));
			stateVars.TM_LR_GetStoreLeadStatus = result?.data.tM_LR_GetStoreLeadStatus;
			
			stateVars.TM_LR_GetStoreProductDistribution = result?.data.tM_LR_GetStoreProductDistribution;
			
			stateVars.TM_LR_GetMonthlyLeadTrend = result?.data.tM_LR_GetMonthlyLeadTrend;
			
			stateVars.TM_LR_GetLeadResultDistribution = result?.data.tM_LR_GetLeadResultDistribution;
			
			this.props.form?.setFieldsValue(formVars);
			
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.LeadReportComponent_886840_onClick1_();
                  resolve();
                });
          })



        
        KuikaAppManager.hideSpinner(this);
        return isErrorOccurred;
    }
		LeadReportComponent_886840_onClick1_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }

				formVars.leadreport_2073564093_value = ReactSystemFunctions.toString(this, (stateVars.TM_LR_GetKPI !== undefined ? (stateVars.TM_LR_GetKPI?.length > 0 ? stateVars.TM_LR_GetKPI[0].buAyTerminli : null) : (this.state.TM_LR_GetKPI?.length > 0 ? this.state.TM_LR_GetKPI[0].buAyTerminli : null)));

				formVars.leadreport_1311511404_value = ReactSystemFunctions.toString(this, (stateVars.TM_LR_GetKPI !== undefined ? (stateVars.TM_LR_GetKPI?.length > 0 ? stateVars.TM_LR_GetKPI[0].aktifTakipte : null) : (this.state.TM_LR_GetKPI?.length > 0 ? this.state.TM_LR_GetKPI[0].aktifTakipte : null)));

				formVars.leadreport_1304438269_value = ReactSystemFunctions.toString(this, (stateVars.TM_LR_GetKPI !== undefined ? (stateVars.TM_LR_GetKPI?.length > 0 ? stateVars.TM_LR_GetKPI[0].ikinciTakip : null) : (this.state.TM_LR_GetKPI?.length > 0 ? this.state.TM_LR_GetKPI[0].ikinciTakip : null)));

				formVars.leadreport_1902670072_value = ReactSystemFunctions.toString(this, (stateVars.TM_LR_GetKPI !== undefined ? (stateVars.TM_LR_GetKPI?.length > 0 ? stateVars.TM_LR_GetKPI[0].onayBekleyen : null) : (this.state.TM_LR_GetKPI?.length > 0 ? this.state.TM_LR_GetKPI[0].onayBekleyen : null)));

				formVars.leadreport_233056958_value = ReactSystemFunctions.toString(this, (stateVars.TM_LR_GetKPI !== undefined ? (stateVars.TM_LR_GetKPI?.length > 0 ? stateVars.TM_LR_GetKPI[0].onaylanan : null) : (this.state.TM_LR_GetKPI?.length > 0 ? this.state.TM_LR_GetKPI[0].onaylanan : null)));

				formVars.leadreport_630686224_value = ReactSystemFunctions.toString(this, (stateVars.TM_LR_GetKPI !== undefined ? (stateVars.TM_LR_GetKPI?.length > 0 ? stateVars.TM_LR_GetKPI[0].reddedilen : null) : (this.state.TM_LR_GetKPI?.length > 0 ? this.state.TM_LR_GetKPI[0].reddedilen : null)));

				
				stateVars.dataSource_846576 = stateVars.TM_LR_GetProcessDistribution ?? this.state.TM_LR_GetProcessDistribution;
				
				stateVars.dataSource_672374655 = stateVars.TM_LR_GetStoreDistribution ?? this.state.TM_LR_GetStoreDistribution;
				formVars.leadreport_387818547_percent = ReactSystemFunctions.value(this, (stateVars.TM_LR_GetProductDistribution !== undefined ? (stateVars.TM_LR_GetProductDistribution?.length > 0 ? stateVars.TM_LR_GetProductDistribution[0].tudorPercent : null) : (this.state.TM_LR_GetProductDistribution?.length > 0 ? this.state.TM_LR_GetProductDistribution[0].tudorPercent : null)));

				formVars.leadreport_115241_value = ReactSystemFunctions.toString(this, (stateVars.TM_LR_GetProductDistribution !== undefined ? (stateVars.TM_LR_GetProductDistribution?.length > 0 ? stateVars.TM_LR_GetProductDistribution[0].tudorCount : null) : (this.state.TM_LR_GetProductDistribution?.length > 0 ? this.state.TM_LR_GetProductDistribution[0].tudorCount : null)));

				formVars.leadreport_1979486780_percent = ReactSystemFunctions.value(this, (stateVars.TM_LR_GetProductDistribution !== undefined ? (stateVars.TM_LR_GetProductDistribution?.length > 0 ? stateVars.TM_LR_GetProductDistribution[0].rolexPercent : null) : (this.state.TM_LR_GetProductDistribution?.length > 0 ? this.state.TM_LR_GetProductDistribution[0].rolexPercent : null)));

				formVars.leadreport_348768957_value = ReactSystemFunctions.toString(this, (stateVars.TM_LR_GetProductDistribution !== undefined ? (stateVars.TM_LR_GetProductDistribution?.length > 0 ? stateVars.TM_LR_GetProductDistribution[0].rolexCount : null) : (this.state.TM_LR_GetProductDistribution?.length > 0 ? this.state.TM_LR_GetProductDistribution[0].rolexCount : null)));

				formVars.leadreport_859009014_percent = ReactSystemFunctions.value(this, (stateVars.TM_LR_GetProductDistribution !== undefined ? (stateVars.TM_LR_GetProductDistribution?.length > 0 ? stateVars.TM_LR_GetProductDistribution[0].category1Percent : null) : (this.state.TM_LR_GetProductDistribution?.length > 0 ? this.state.TM_LR_GetProductDistribution[0].category1Percent : null)));

				formVars.leadreport_1630003451_value = ReactSystemFunctions.toString(this, (stateVars.TM_LR_GetProductDistribution !== undefined ? (stateVars.TM_LR_GetProductDistribution?.length > 0 ? stateVars.TM_LR_GetProductDistribution[0].category1Count : null) : (this.state.TM_LR_GetProductDistribution?.length > 0 ? this.state.TM_LR_GetProductDistribution[0].category1Count : null)));

				formVars.leadreport_622538780_percent = ReactSystemFunctions.value(this, (stateVars.TM_LR_GetProductDistribution !== undefined ? (stateVars.TM_LR_GetProductDistribution?.length > 0 ? stateVars.TM_LR_GetProductDistribution[0].category2Percent : null) : (this.state.TM_LR_GetProductDistribution?.length > 0 ? this.state.TM_LR_GetProductDistribution[0].category2Percent : null)));

				formVars.leadreport_2134985305_value = ReactSystemFunctions.toString(this, (stateVars.TM_LR_GetProductDistribution !== undefined ? (stateVars.TM_LR_GetProductDistribution?.length > 0 ? stateVars.TM_LR_GetProductDistribution[0].category2Count : null) : (this.state.TM_LR_GetProductDistribution?.length > 0 ? this.state.TM_LR_GetProductDistribution[0].category2Count : null)));

				formVars.leadreport_2113078156_percent = ReactSystemFunctions.value(this, (stateVars.TM_LR_GetProductDistribution !== undefined ? (stateVars.TM_LR_GetProductDistribution?.length > 0 ? stateVars.TM_LR_GetProductDistribution[0].category3Percent : null) : (this.state.TM_LR_GetProductDistribution?.length > 0 ? this.state.TM_LR_GetProductDistribution[0].category3Percent : null)));

				formVars.leadreport_440995668_value = ReactSystemFunctions.toString(this, (stateVars.TM_LR_GetProductDistribution !== undefined ? (stateVars.TM_LR_GetProductDistribution?.length > 0 ? stateVars.TM_LR_GetProductDistribution[0].category3Count : null) : (this.state.TM_LR_GetProductDistribution?.length > 0 ? this.state.TM_LR_GetProductDistribution[0].category3Count : null)));

				
				stateVars.dataSource_906776 = stateVars.TM_LR_GetMonthlyLeadTrend ?? this.state.TM_LR_GetMonthlyLeadTrend;
				
				stateVars.dataSource_788395 = stateVars.TM_LR_GetLeadResultDistribution ?? this.state.TM_LR_GetLeadResultDistribution;
				
				stateVars.dataSource_353892 = stateVars.TM_LR_GetStoreLeadStatus ?? this.state.TM_LR_GetStoreLeadStatus;
				
				stateVars.dataSource_367777433 = stateVars.TM_LR_GetStoreProductDistribution ?? this.state.TM_LR_GetStoreProductDistribution;
				
				stateVars.dataSource_524175975 = stateVars.TM_GetLeadReportList ?? this.state.TM_GetLeadReportList;

		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

            
            return isErrorOccurred;
        }




    LeadReportComponent_1308896275_onClick = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
		KuikaAppManager.increaseServerRequestCount();

        let localVar = {
				value_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, this.state.TM_LR_GetStoreLeadStatus), "any"),
				header_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.convertToTypeByName("Mağaza Bazında Talep Durumları", "string"), "string"),
				footer_0: ReactSystemFunctions.convertToTypeByName("", "string"),
				columns_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.convertToTypeByName("Magaza,Toplam,Olusturuldu,TerminBekleyen,OnayBekleyen,Onaylanan,SatisBekleyen,SatisiYapilan,Reddedilen", "string"), "string")
        }

		KuikaAppManager.showSpinner(this);
		
        if (true) {
        KuikaAppManager.showSpinner(this);
        }
        let result = await KuikaAppManager.ApiRequest(this, "LeadReport/LeadReportComponent_1308896275_onClick", localVar)
        if (!KMainFunctions.IsResStatus2XX(result)) return true;

			stateVars.ExportExcel = result?.data.exportExcel;
			ReactSystemFunctions.downloadFile(result?.data?.exportExcel);
			this.props.form?.setFieldsValue(formVars);
			this.setState(stateVars);
			KuikaAppManager.hideSpinner(this);



        this.setPageInitLoaded(true);
        KuikaAppManager.hideSpinner(this);
        return isErrorOccurred;
    }



    LeadReportComponent_1932689703_onClick = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
		KuikaAppManager.increaseServerRequestCount();

        let localVar = {
				value_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, this.state.TM_LR_GetStoreProductDistribution), "any"),
				header_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.convertToTypeByName("Ürün / Marka Bazında Dağılım", "string"), "string"),
				footer_0: ReactSystemFunctions.convertToTypeByName("", "string"),
				columns_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.convertToTypeByName("Magaza,Tudor,Kategori1,Kategori2,Kategori3,Toplam", "string"), "string")
        }

		KuikaAppManager.showSpinner(this);
		
        if (true) {
        KuikaAppManager.showSpinner(this);
        }
        let result = await KuikaAppManager.ApiRequest(this, "LeadReport/LeadReportComponent_1932689703_onClick", localVar)
        if (!KMainFunctions.IsResStatus2XX(result)) return true;

			stateVars.ExportExcel = result?.data.exportExcel;
			ReactSystemFunctions.downloadFile(result?.data?.exportExcel);
			this.props.form?.setFieldsValue(formVars);
			this.setState(stateVars);
			KuikaAppManager.hideSpinner(this);



        this.setPageInitLoaded(true);
        KuikaAppManager.hideSpinner(this);
        return isErrorOccurred;
    }



    LeadReportComponent_1928069397_onClick = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
		KuikaAppManager.increaseServerRequestCount();

        let localVar = {
				value_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, this.state.TM_GetLeadReportList), "any"),
				header_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.convertToTypeByName("Mağaza Bazında Talep Durumları", "string"), "string"),
				footer_0: ReactSystemFunctions.convertToTypeByName("", "string"),
				columns_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.convertToTypeByName("TalepTarihi,LeadNumarasi,Magaza,Marka,Kategori,Referans,Musteri,TakipDurumu,TalepDurumu,TerminTarihi,SatisPersoneli", "string"), "string")
        }

		KuikaAppManager.showSpinner(this);
		
        if (true) {
        KuikaAppManager.showSpinner(this);
        }
        let result = await KuikaAppManager.ApiRequest(this, "LeadReport/LeadReportComponent_1928069397_onClick", localVar)
        if (!KMainFunctions.IsResStatus2XX(result)) return true;

			stateVars.ExportExcel = result?.data.exportExcel;
			ReactSystemFunctions.downloadFile(result?.data?.exportExcel);
			this.props.form?.setFieldsValue(formVars);
			this.setState(stateVars);
			KuikaAppManager.hideSpinner(this);



        this.setPageInitLoaded(true);
        KuikaAppManager.hideSpinner(this);
        return isErrorOccurred;
    }



		LeadReportComponent_1418671398_onClick = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
KuikaAppManager.showSpinner(this);

					KuikaAppManager.prepareForNavigation();
						KuikaAppManager.addToPageInputVariables("LeadDetailTemp", "LeadId", ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, "leadreport_524175975_value", "leadId"), "Guid"));

				stateVars.NAVIGATE = await ReactSystemFunctions.navigate(this, undefined, "LeadReport", "LeadDetailTemp", "", "7d969ddf-5801-4eb6-b92b-12be35bdd565", "1582513710", null, "right", "true", "70vw", "100vh", true, false);

		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

            
            return isErrorOccurred;
        }




    async callCallbackFunction(diId: number, isFromMaster: boolean = false) {
        let isErrorOccurred = false;
		let pageInitCallerNavDiIDs = [1582513710] as number[];
		if (isFromMaster || pageInitCallerNavDiIDs.indexOf(diId) > -1) {
			await this.LeadReportPageInit();
		}

    }


}
