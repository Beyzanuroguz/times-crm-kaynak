import React from "react";
import Axios, { AxiosResponse } from "axios";
import { KuikaAppManager } from "../../shared/utilty/kuika-app-manager";
import { ReactSystemFunctions } from "../../shared/utilty/react-system-functions";
import { KNavigator } from "../../shared/hoc/with-history";
import { KContext } from "../../shared/hoc/with-context";
import { useLocation } from "react-router-dom";
import { FormInstance } from "antd/es/form";
import { Guid } from "guid-typescript";
import Swal from "sweetalert2";
import { KMainFunctions } from "../../shared/utilty/main-functions";
import moment from "moment";
import { IValidationData } from "../../models/dto/validation-data";
import { IStripePayment } from "../../models/dto/stripe-payment";
import { IUserInfoDto } from "../../models/dto/user-info.dto";
import { UserService } from "../../services/user-service";
import { kuikaCoreWasmBridgeService } from "../../services/_singletons";
import _ from "lodash";
import mqtt, { MqttClient } from "mqtt";
import { IMqttResult } from "../../models/dto/mqtt.dto";


declare let window: any;

export interface IPopOnayBekleyen_ScreenProps {
  navigator: KNavigator;
  form: FormInstance<any>;
  googleLogin: any;
  screenInputs: any;
  context: KContext;
  initialValues: any;
  children: any;
}

export interface IPopOnayBekleyen_ScreenState {
    isSpinnerVisible: boolean;
    isPageVisible: boolean;
	isLeftMenuVisible: boolean;
    spinnerCount: number;
    selectedLanguage: string;
    isPageInitLoaded: false;
    isPageRecurringLoaded: false;
	TM_GetLeadById: any[];
	TM_GetLeadById_dummy: any[];
	TMLeadSuggestion: any[];
	TMLeadSuggestion_dummy: any[];
	TMApproveLeadAndReservation: any[];
	TMApproveLeadAndReservation_dummy: any[];
	GoBack: any;
	GoBack_dummy: any;
	TM_CreateLeadApproveLog: any[];
	TM_CreateLeadApproveLog_dummy: any[];
	Notify: boolean;
	Notify_dummy: boolean;
	NAVIGATE: any;
	NAVIGATE_dummy: any;
	isComp296124Visible: 'visible' | 'hidden';
	isComp9723Visible: 'visible' | 'hidden';

}

export class PopOnayBekleyen_ScreenBase extends React.PureComponent<IPopOnayBekleyen_ScreenProps, any> {

	poponaybekleyen_174743_value_kuikaAutoCompleteRef: React.RefObject<any>;
	poponaybekleyen_40820_value_kuikaAutoCompleteRef: React.RefObject<any>;
    ml=[{"Id":"d5a61d2b-bd60-485f-86e2-661e9ed4e486","Name":"en_US","ShortName":"English","IsDefault":true,"LanguagePhrases":[]},{"Id":"2727291b-09bb-4143-bf3e-bbaabd841685","Name":"FixedValues","ShortName":"FixedValues","LanguagePhrases":[{"Id":190905,"PropertyName":"value","Value":"Talep Onayı"},{"Id":833222,"PropertyName":"value","Value":"LEAD NO"},{"Id":300559,"PropertyName":"value","Value":"Süreç"},{"Id":700368,"PropertyName":"value","Value":"KATEGORİ"},{"Id":580062,"PropertyName":"value","Value":"Müşteri ve Mağaza"},{"Id":768163,"PropertyName":"value","Value":"Müşteri"},{"Id":618322,"PropertyName":"value","Value":"Satış Personeli"},{"Id":71290,"PropertyName":"value","Value":"Telefon"},{"Id":65504,"PropertyName":"value","Value":"Mağaza"},{"Id":638011,"PropertyName":"value","Value":"Lokasyon"},{"Id":559489,"PropertyName":"value","Value":"Ürün ve Talep"},{"Id":203766,"PropertyName":"value","Value":"Ürün"},{"Id":343457,"PropertyName":"value","Value":"Model"},{"Id":204373,"PropertyName":"value","Value":"Talep Tarihi"},{"Id":20964,"PropertyName":"value","Value":"Sonraki Adım"},{"Id":519823,"PropertyName":"value","Value":"Not"},{"Id":622383,"PropertyName":"value","Value":"Termin Önerisi"},{"Id":773198,"PropertyName":"value","Value":"Önerilen tarih"},{"Id":357800,"PropertyName":"value","Value":"Termin Notu"},{"Id":709830,"PropertyName":"placeholder","Value":"Termin notunu yazın"},{"Id":174743,"PropertyName":"placeholder","Value":"Termin yılı seçin"},{"Id":40820,"PropertyName":"placeholder","Value":"Termin ayı seçin"},{"Id":134041,"PropertyName":"label","Value":"Onayla"},{"Id":86121,"PropertyName":"label","Value":"Onayla ve Rezerv Et"},{"Id":877716,"PropertyName":"label","Value":"Reddet"}]}]
    defaultML = "en_US"
    
    screenHash = ""
    


    constructor(props) {
        super(props);
		this.poponaybekleyen_174743_value_kuikaAutoCompleteRef = React.createRef();
		this.poponaybekleyen_40820_value_kuikaAutoCompleteRef = React.createRef();

        this.state = {
            isSpinnerVisible: false,
            isPageVisible: false,
            isLeftMenuVisible: false,
            spinnerCount: 0,
            selectedLanguage: "",
            isPageInitLoaded: false,
            isPageRecurringLoaded: false,
            	        TM_GetLeadById: [],
	        TMLeadSuggestion: [],
	        TMApproveLeadAndReservation: [],
	        GoBack: "",
	        TM_CreateLeadApproveLog: [],
	        Notify: false,
	        NAVIGATE: "",
	        dataSource_174743: [{"key":"2026","text":"2026"},{"key":"2027","text":"2027"},{"key":"2028","text":"2028"},{"key":"2029","text":"2029"},{"key":"2030","text":"2030"},{"key":"2031","text":"2031"},{"key":"2032","text":"2032"},{"key":"2033","text":"2033"},{"key":"2034","text":"2034"},{"key":"2035","text":"2035"},{"key":"2036","text":"2036"},{"key":"2037","text":"2037"},{"key":"2038","text":"2038"},{"key":"2039","text":"2039"},{"key":"2040","text":"2040"}],
	        dataSource_40820: [{"key":"1","text":"Ocak"},{"key":"2","text":"Şubat"},{"key":"3","text":"Mart"},{"key":"4","text":"Nisan"},{"key":"5","text":"Mayıs"},{"key":"6","text":"Haziran"},{"key":"7","text":"Temmuz"},{"key":"8","text":"Ağustos"},{"key":"9","text":"Eylül"},{"key":"10","text":"Ekim"},{"key":"11","text":"Kasım"},{"key":"12","text":"Aralık"}],
	        isComp296124Visible: 'hidden',
	        isComp9723Visible: 'hidden',

        }

        this.state.isPageVisible = true;
        
    }

    async componentDidMount() {

        if (KuikaAppManager.isPageInitPrevented()) {
            KuikaAppManager.calculateAndSetBodyHeight("poponaybekleyen", "");
            return;
        }
        
        
        ReactSystemFunctions.validateToken()
        this.fillFormInitValues();
        if (true){
            await this.PopOnayBekleyenPageInit();
        }
        
        
        
        KuikaAppManager.calculateAndSetBodyHeight("poponaybekleyen", "");

        if (ReactSystemFunctions.getIsMicroApp() === false) {
           window.parentScreen = this;
        }
    }

    componentWillUnmount() {
        
        
        

        if (ReactSystemFunctions.getIsMicroApp() === false) {
           window.parentScreen = null;
        }
    }

    

        
    componentDidUpdate= async (prevProps, prevState) => {
		KuikaAppManager.calculateAndSetBodyHeight("poponaybekleyen", ""    );
        if (prevProps?.location?.search !== (this.props as any)?.location?.search) {
			await this.PopOnayBekleyenPageInit();
		}

        

        if (ReactSystemFunctions.getIsMicroApp() === false) {
            for (const key in prevState) {
                if (key.startsWith('NavVisible') && prevState[key] === true && this.state[key] === false) {
                    window.parentScreen = this;
                    break;
                }
            }
        }
	}

    fillFormInitValues() {
        this.props.form?.setFieldsValue({
poponaybekleyen_709830_value: this.state.TMLeadSuggestion?.at?.(0)?.oneriNotu ?? undefined,
poponaybekleyen_174743_value: this.state.TMLeadSuggestion?.at?.(0)?.terminYil ?? undefined,
poponaybekleyen_40820_value: this.state.TMLeadSuggestion?.at?.(0)?.terminAy ?? undefined
});

    }

      setPageInitLoaded = (value: boolean) => {
        this.setState({ isPageInitLoaded: value });
      }

      setPageRecurringLoaded = (value: boolean) => {
        this.setState({ isPageRecurringLoaded: value });
      }

      clearFieldValidation = (changedValues: any) => {
        const fieldName = Object.keys(changedValues)[0];
        if (fieldName) {
          this.props.form?.setFields([
            {
              name: fieldName,
              errors: []
            }
          ]);
        }
      };

      

    PopOnayBekleyenPageInit = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


	if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }

        let localVar = {
			LeadId_0: ReactSystemFunctions.convertToTypeByName(this.props.screenInputs.LeadId ?? this.props.screenInputs.leadid, "Guid"),
			LeadId_1: ReactSystemFunctions.convertToTypeByName(this.props.screenInputs.LeadId ?? this.props.screenInputs.leadid, "Guid"),
			UserId_2: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.getMyUserId(), "Guid"),
			LeadId_2: ReactSystemFunctions.convertToTypeByName(this.props.screenInputs.LeadId ?? this.props.screenInputs.leadid, "Guid")
        }

	KuikaAppManager.showSpinner(this);
	
        if (true) {
        KuikaAppManager.showSpinner(this);
        }
        let result = await KuikaAppManager.ApiRequest(this, "PopOnayBekleyen/PopOnayBekleyenPageInit", localVar)
        if (!KMainFunctions.IsResStatus2XX(result)) return true;

		stateVars.TM_GetLeadById = result?.data.tM_GetLeadById;
		formVars.poponaybekleyen_605301_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadById !== undefined ? (stateVars.TM_GetLeadById?.length > 0 ? stateVars.TM_GetLeadById[0].leadCode : null) : (this.state.TM_GetLeadById?.length > 0 ? this.state.TM_GetLeadById[0].leadCode : null)));
		formVars.poponaybekleyen_520204_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadById !== undefined ? (stateVars.TM_GetLeadById?.length > 0 ? stateVars.TM_GetLeadById[0].processName : null) : (this.state.TM_GetLeadById?.length > 0 ? this.state.TM_GetLeadById[0].processName : null)));
		formVars.poponaybekleyen_203820_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadById !== undefined ? (stateVars.TM_GetLeadById?.length > 0 ? stateVars.TM_GetLeadById[0].categoryName : null) : (this.state.TM_GetLeadById?.length > 0 ? this.state.TM_GetLeadById[0].categoryName : null)));
		formVars.poponaybekleyen_951867_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadById !== undefined ? (stateVars.TM_GetLeadById?.length > 0 ? stateVars.TM_GetLeadById[0].musteriAdi : null) : (this.state.TM_GetLeadById?.length > 0 ? this.state.TM_GetLeadById[0].musteriAdi : null)));
		formVars.poponaybekleyen_2439_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadById !== undefined ? (stateVars.TM_GetLeadById?.length > 0 ? stateVars.TM_GetLeadById[0].satisPersoneli : null) : (this.state.TM_GetLeadById?.length > 0 ? this.state.TM_GetLeadById[0].satisPersoneli : null)));
		formVars.poponaybekleyen_321981_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadById !== undefined ? (stateVars.TM_GetLeadById?.length > 0 ? stateVars.TM_GetLeadById[0].telefonNo : null) : (this.state.TM_GetLeadById?.length > 0 ? this.state.TM_GetLeadById[0].telefonNo : null)));
		formVars.poponaybekleyen_3085_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadById !== undefined ? (stateVars.TM_GetLeadById?.length > 0 ? stateVars.TM_GetLeadById[0].magaza : null) : (this.state.TM_GetLeadById?.length > 0 ? this.state.TM_GetLeadById[0].magaza : null)));
		formVars.poponaybekleyen_216706_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadById !== undefined ? (stateVars.TM_GetLeadById?.length > 0 ? stateVars.TM_GetLeadById[0].lokasyon : null) : (this.state.TM_GetLeadById?.length > 0 ? this.state.TM_GetLeadById[0].lokasyon : null)));
		formVars.poponaybekleyen_405848_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadById !== undefined ? (stateVars.TM_GetLeadById?.length > 0 ? stateVars.TM_GetLeadById[0].urunAdi : null) : (this.state.TM_GetLeadById?.length > 0 ? this.state.TM_GetLeadById[0].urunAdi : null)));
		formVars.poponaybekleyen_325876_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadById !== undefined ? (stateVars.TM_GetLeadById?.length > 0 ? stateVars.TM_GetLeadById[0].referans : null) : (this.state.TM_GetLeadById?.length > 0 ? this.state.TM_GetLeadById[0].referans : null)));
		formVars.poponaybekleyen_663741_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadById !== undefined ? (stateVars.TM_GetLeadById?.length > 0 ? stateVars.TM_GetLeadById[0].talepOlusturmaTarihi : null) : (this.state.TM_GetLeadById?.length > 0 ? this.state.TM_GetLeadById[0].talepOlusturmaTarihi : null)));
		formVars.poponaybekleyen_475520_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadById !== undefined ? (stateVars.TM_GetLeadById?.length > 0 ? stateVars.TM_GetLeadById[0].sonrakiAdim : null) : (this.state.TM_GetLeadById?.length > 0 ? this.state.TM_GetLeadById[0].sonrakiAdim : null)));
		formVars.poponaybekleyen_928078_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadById !== undefined ? (stateVars.TM_GetLeadById?.length > 0 ? stateVars.TM_GetLeadById[0].talepNotu : null) : (this.state.TM_GetLeadById?.length > 0 ? this.state.TM_GetLeadById[0].talepNotu : null)));
		stateVars.TMLeadSuggestion = result?.data.tmLeadSuggestion;
		formVars.poponaybekleyen_159430_value = ReactSystemFunctions.toString(this, (stateVars.TMLeadSuggestion !== undefined ? (stateVars.TMLeadSuggestion?.length > 0 ? stateVars.TMLeadSuggestion[0].terminOneriText : null) : (this.state.TMLeadSuggestion?.length > 0 ? this.state.TMLeadSuggestion[0].terminOneriText : null)));
		formVars.poponaybekleyen_17300_value = ReactSystemFunctions.toString(this, (stateVars.TMLeadSuggestion !== undefined ? (stateVars.TMLeadSuggestion?.length > 0 ? stateVars.TMLeadSuggestion[0].terminOneriAciklama : null) : (this.state.TMLeadSuggestion?.length > 0 ? this.state.TMLeadSuggestion[0].terminOneriAciklama : null)));
		formVars.poponaybekleyen_709830_value = ReactSystemFunctions.toString(this, (stateVars.TMLeadSuggestion !== undefined ? (stateVars.TMLeadSuggestion?.length > 0 ? stateVars.TMLeadSuggestion[0].oneriNotu : null) : (this.state.TMLeadSuggestion?.length > 0 ? this.state.TMLeadSuggestion[0].oneriNotu : null)));
		formVars.poponaybekleyen_174743_value = (stateVars.TMLeadSuggestion !== undefined ? (stateVars.TMLeadSuggestion?.length > 0 ? stateVars.TMLeadSuggestion[0].terminYil : null) : (this.state.TMLeadSuggestion?.length > 0 ? this.state.TMLeadSuggestion[0].terminYil : null));
		formVars.poponaybekleyen_40820_value = (stateVars.TMLeadSuggestion !== undefined ? (stateVars.TMLeadSuggestion?.length > 0 ? stateVars.TMLeadSuggestion[0].terminAy : null) : (this.state.TMLeadSuggestion?.length > 0 ? this.state.TMLeadSuggestion[0].terminAy : null));
		stateVars.isComp296124Visible = ((ReactSystemFunctions.isNotEmpty(ReactSystemFunctions.toString(this, (stateVars.TMLeadSuggestion !== undefined ? (stateVars.TMLeadSuggestion?.length > 0 ? stateVars.TMLeadSuggestion[0].terminOneriText : null) : (this.state.TMLeadSuggestion?.length > 0 ? this.state.TMLeadSuggestion[0].terminOneriText : null))), ReactSystemFunctions.convertToTypeByName("True", "string"))) === true ? "visible" : "hidden")
		stateVars.TMApproveLeadAndReservation = result?.data.tmApproveLeadAndReservation;
		stateVars.isComp9723Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, (stateVars.TMApproveLeadAndReservation !== undefined ? (stateVars.TMApproveLeadAndReservation?.length > 0 ? stateVars.TMApproveLeadAndReservation[0].approveAndReserveShow : null) : (this.state.TMApproveLeadAndReservation?.length > 0 ? this.state.TMApproveLeadAndReservation[0].approveAndReserveShow : null))), ReactSystemFunctions.convertToTypeByName("True", "string"))) === true ? "visible" : "hidden")
		this.props.form?.setFieldsValue(formVars);
		
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.PopOnayBekleyenPageInit1_();
                  resolve();
                });
          })



        
        KuikaAppManager.hideSpinner(this);
        return isErrorOccurred;
    }
	PopOnayBekleyenPageInit1_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


	if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }

			formVars.poponaybekleyen_605301_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadById !== undefined ? (stateVars.TM_GetLeadById?.length > 0 ? stateVars.TM_GetLeadById[0].leadCode : null) : (this.state.TM_GetLeadById?.length > 0 ? this.state.TM_GetLeadById[0].leadCode : null)));

			formVars.poponaybekleyen_520204_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadById !== undefined ? (stateVars.TM_GetLeadById?.length > 0 ? stateVars.TM_GetLeadById[0].processName : null) : (this.state.TM_GetLeadById?.length > 0 ? this.state.TM_GetLeadById[0].processName : null)));

			formVars.poponaybekleyen_203820_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadById !== undefined ? (stateVars.TM_GetLeadById?.length > 0 ? stateVars.TM_GetLeadById[0].categoryName : null) : (this.state.TM_GetLeadById?.length > 0 ? this.state.TM_GetLeadById[0].categoryName : null)));

			formVars.poponaybekleyen_951867_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadById !== undefined ? (stateVars.TM_GetLeadById?.length > 0 ? stateVars.TM_GetLeadById[0].musteriAdi : null) : (this.state.TM_GetLeadById?.length > 0 ? this.state.TM_GetLeadById[0].musteriAdi : null)));

			formVars.poponaybekleyen_2439_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadById !== undefined ? (stateVars.TM_GetLeadById?.length > 0 ? stateVars.TM_GetLeadById[0].satisPersoneli : null) : (this.state.TM_GetLeadById?.length > 0 ? this.state.TM_GetLeadById[0].satisPersoneli : null)));

			formVars.poponaybekleyen_321981_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadById !== undefined ? (stateVars.TM_GetLeadById?.length > 0 ? stateVars.TM_GetLeadById[0].telefonNo : null) : (this.state.TM_GetLeadById?.length > 0 ? this.state.TM_GetLeadById[0].telefonNo : null)));

			formVars.poponaybekleyen_3085_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadById !== undefined ? (stateVars.TM_GetLeadById?.length > 0 ? stateVars.TM_GetLeadById[0].magaza : null) : (this.state.TM_GetLeadById?.length > 0 ? this.state.TM_GetLeadById[0].magaza : null)));

			formVars.poponaybekleyen_216706_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadById !== undefined ? (stateVars.TM_GetLeadById?.length > 0 ? stateVars.TM_GetLeadById[0].lokasyon : null) : (this.state.TM_GetLeadById?.length > 0 ? this.state.TM_GetLeadById[0].lokasyon : null)));

			formVars.poponaybekleyen_405848_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadById !== undefined ? (stateVars.TM_GetLeadById?.length > 0 ? stateVars.TM_GetLeadById[0].urunAdi : null) : (this.state.TM_GetLeadById?.length > 0 ? this.state.TM_GetLeadById[0].urunAdi : null)));

			formVars.poponaybekleyen_325876_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadById !== undefined ? (stateVars.TM_GetLeadById?.length > 0 ? stateVars.TM_GetLeadById[0].referans : null) : (this.state.TM_GetLeadById?.length > 0 ? this.state.TM_GetLeadById[0].referans : null)));

			formVars.poponaybekleyen_663741_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadById !== undefined ? (stateVars.TM_GetLeadById?.length > 0 ? stateVars.TM_GetLeadById[0].talepOlusturmaTarihi : null) : (this.state.TM_GetLeadById?.length > 0 ? this.state.TM_GetLeadById[0].talepOlusturmaTarihi : null)));

			formVars.poponaybekleyen_475520_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadById !== undefined ? (stateVars.TM_GetLeadById?.length > 0 ? stateVars.TM_GetLeadById[0].sonrakiAdim : null) : (this.state.TM_GetLeadById?.length > 0 ? this.state.TM_GetLeadById[0].sonrakiAdim : null)));

			formVars.poponaybekleyen_928078_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadById !== undefined ? (stateVars.TM_GetLeadById?.length > 0 ? stateVars.TM_GetLeadById[0].talepNotu : null) : (this.state.TM_GetLeadById?.length > 0 ? this.state.TM_GetLeadById[0].talepNotu : null)));

			stateVars.isComp296124Visible = ((ReactSystemFunctions.isNotEmpty(ReactSystemFunctions.toString(this, (stateVars.TMLeadSuggestion !== undefined ? (stateVars.TMLeadSuggestion?.length > 0 ? stateVars.TMLeadSuggestion[0].terminOneriText : null) : (this.state.TMLeadSuggestion?.length > 0 ? this.state.TMLeadSuggestion[0].terminOneriText : null))), ReactSystemFunctions.convertToTypeByName("True", "string"))) === true ? "visible" : "hidden")
			formVars.poponaybekleyen_159430_value = ReactSystemFunctions.toString(this, (stateVars.TMLeadSuggestion !== undefined ? (stateVars.TMLeadSuggestion?.length > 0 ? stateVars.TMLeadSuggestion[0].terminOneriText : null) : (this.state.TMLeadSuggestion?.length > 0 ? this.state.TMLeadSuggestion[0].terminOneriText : null)));

			formVars.poponaybekleyen_17300_value = ReactSystemFunctions.toString(this, (stateVars.TMLeadSuggestion !== undefined ? (stateVars.TMLeadSuggestion?.length > 0 ? stateVars.TMLeadSuggestion[0].terminOneriAciklama : null) : (this.state.TMLeadSuggestion?.length > 0 ? this.state.TMLeadSuggestion[0].terminOneriAciklama : null)));

			formVars.poponaybekleyen_709830_value = ReactSystemFunctions.toString(this, (stateVars.TMLeadSuggestion !== undefined ? (stateVars.TMLeadSuggestion?.length > 0 ? stateVars.TMLeadSuggestion[0].oneriNotu : null) : (this.state.TMLeadSuggestion?.length > 0 ? this.state.TMLeadSuggestion[0].oneriNotu : null)));

			formVars.poponaybekleyen_174743_value = ReactSystemFunctions.toString(this, (stateVars.TMLeadSuggestion !== undefined ? (stateVars.TMLeadSuggestion?.length > 0 ? stateVars.TMLeadSuggestion[0].terminYil : null) : (this.state.TMLeadSuggestion?.length > 0 ? this.state.TMLeadSuggestion[0].terminYil : null)));

			formVars.poponaybekleyen_40820_value = ReactSystemFunctions.toString(this, (stateVars.TMLeadSuggestion !== undefined ? (stateVars.TMLeadSuggestion?.length > 0 ? stateVars.TMLeadSuggestion[0].terminAy : null) : (this.state.TMLeadSuggestion?.length > 0 ? this.state.TMLeadSuggestion[0].terminAy : null)));

			stateVars.isComp9723Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, (stateVars.TMApproveLeadAndReservation !== undefined ? (stateVars.TMApproveLeadAndReservation?.length > 0 ? stateVars.TMApproveLeadAndReservation[0].approveAndReserveShow : null) : (this.state.TMApproveLeadAndReservation?.length > 0 ? this.state.TMApproveLeadAndReservation[0].approveAndReserveShow : null))), ReactSystemFunctions.convertToTypeByName("True", "string"))) === true ? "visible" : "hidden")

	this.props.form?.setFieldsValue(formVars);
	this.setState(stateVars);
	KuikaAppManager.hideSpinner(this);

            this.setPageInitLoaded(true);
            return isErrorOccurred;
        }




		PopOnayBekleyenComponent_604458_onClick = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
KuikaAppManager.showSpinner(this);

				stateVars.GoBack = await ReactSystemFunctions.goBack(this, false);

		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

            
            return isErrorOccurred;
        }


    PopOnayBekleyenComponent_134041_onClick = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
		KuikaAppManager.increaseServerRequestCount();

        let localVar = {
				EstimatedYear_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toInteger(this, ReactSystemFunctions.value(this, "poponaybekleyen_174743_value", "value", "", "key", "")), "number"),
				EstimatedMonth_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toInteger(this, ReactSystemFunctions.value(this, "poponaybekleyen_40820_value", "value", "", "key", "")), "number"),
				LeadId_0: ReactSystemFunctions.convertToTypeByName(this.props.screenInputs.LeadId ?? this.props.screenInputs.leadid, "Guid"),
				UserId_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.getMyUserId(), "Guid")
        }

		KuikaAppManager.showSpinner(this);
		
        if (true) {
        KuikaAppManager.showSpinner(this);
        }
        let result = await KuikaAppManager.ApiRequest(this, "PopOnayBekleyen/PopOnayBekleyenComponent_134041_onClick", localVar)
        if (!KMainFunctions.IsResStatus2XX(result)) return true;

			stateVars.TM_CreateLeadApproveLog = result?.data.tM_CreateLeadApproveLog;
			this.props.form?.setFieldsValue(formVars);
			
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.PopOnayBekleyenComponent_134041_onClick1_();
                  resolve();
                });
          })



        
        KuikaAppManager.hideSpinner(this);
        return isErrorOccurred;
    }
		PopOnayBekleyenComponent_134041_onClick1_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }

				stateVars.Notify = await ReactSystemFunctions.notify(this, ReactSystemFunctions.toString(this, (stateVars.TM_CreateLeadApproveLog !== undefined ? (stateVars.TM_CreateLeadApproveLog?.length > 0 ? stateVars.TM_CreateLeadApproveLog[0].message : null) : (this.state.TM_CreateLeadApproveLog?.length > 0 ? this.state.TM_CreateLeadApproveLog[0].message : null))), ReactSystemFunctions.convertToTypeByName("default", "string"), ReactSystemFunctions.convertToTypeByName("top-center", "string"), 2, ReactSystemFunctions.convertToTypeByName("", "string"), ReactSystemFunctions.convertToTypeByName("", "string"), 0);

		this.props.form?.setFieldsValue(formVars);
		
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.PopOnayBekleyenComponent_134041_onClick2_();
                  resolve();
                });
          })

            
            return isErrorOccurred;
        }
		PopOnayBekleyenComponent_134041_onClick2_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
if (ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, (stateVars.TM_CreateLeadApproveLog !== undefined ? (stateVars.TM_CreateLeadApproveLog?.length > 0 ? stateVars.TM_CreateLeadApproveLog[0].success : null) : (this.state.TM_CreateLeadApproveLog?.length > 0 ? this.state.TM_CreateLeadApproveLog[0].success : null))), "1")) {
            
				stateVars.GoBack = await ReactSystemFunctions.goBack(this, false);

		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

        } else {
            KuikaAppManager.hideSpinner(this);
        }

            
            return isErrorOccurred;
        }





		PopOnayBekleyenComponent_86121_onClick = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
KuikaAppManager.showSpinner(this);

					KuikaAppManager.prepareForNavigation();
						KuikaAppManager.addToPageInputVariables("reservationPopUp3", "LeadId", ReactSystemFunctions.convertToTypeByName(this.props.screenInputs.LeadId ?? this.props.screenInputs.leadid, "Guid"));

				stateVars.NAVIGATE = await ReactSystemFunctions.navigate(this, undefined, "PopOnayBekleyen", "reservationPopUp3", "", "currentPage", null, null, null, null, null, null, true, false);

		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

            
            return isErrorOccurred;
        }


		PopOnayBekleyenComponent_877716_onClick = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
KuikaAppManager.showSpinner(this);

					KuikaAppManager.prepareForNavigation();
						KuikaAppManager.addToPageInputVariables("LeadRejectPopUp", "LeadId", ReactSystemFunctions.convertToTypeByName(this.props.screenInputs.LeadId ?? this.props.screenInputs.leadid, "Guid"));

				stateVars.NAVIGATE = await ReactSystemFunctions.navigate(this, undefined, "PopOnayBekleyen", "LeadRejectPopUp", "", "9924ef5f-4b84-4200-b624-8d76348c7686", "702745", null, null, "true", "800px", "70vh", true, false);

		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

            
            return isErrorOccurred;
        }




    async callCallbackFunction(diId: number, isFromMaster: boolean = false) {
        let isErrorOccurred = false;
		let pageInitCallerNavDiIDs = [, 702745] as number[];
		if (isFromMaster || pageInitCallerNavDiIDs.indexOf(diId) > -1) {
			await this.PopOnayBekleyenPageInit();
		}

    }


}
