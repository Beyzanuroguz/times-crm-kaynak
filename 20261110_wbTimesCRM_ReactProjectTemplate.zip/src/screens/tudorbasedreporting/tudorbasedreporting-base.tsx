import React from "react";
import Axios, { AxiosResponse } from "axios";
import { KuikaAppManager } from "../../shared/utilty/kuika-app-manager";
import { ReactSystemFunctions } from "../../shared/utilty/react-system-functions";
import { KNavigator } from "../../shared/hoc/with-history";
import { KContext } from "../../shared/hoc/with-context";
import { useLocation } from "react-router-dom";
import { FormInstance } from "antd/es/form";
import { Guid } from "guid-typescript";
import Swal from "sweetalert2";
import { KMainFunctions } from "../../shared/utilty/main-functions";
import moment from "moment";
import { IValidationData } from "../../models/dto/validation-data";
import { IStripePayment } from "../../models/dto/stripe-payment";
import { IUserInfoDto } from "../../models/dto/user-info.dto";
import { UserService } from "../../services/user-service";
import { kuikaCoreWasmBridgeService } from "../../services/_singletons";
import _ from "lodash";
import mqtt, { MqttClient } from "mqtt";
import { IMqttResult } from "../../models/dto/mqtt.dto";
import { MasterScreen_ScreenContext } from "../masterscreen/masterscreen-context";

declare let window: any;

export interface ITudorBasedReporting_ScreenProps {
  navigator: KNavigator;
  form: FormInstance<any>;
  googleLogin: any;
  screenInputs: any;
  context: KContext;
  initialValues: any;
  children: any;
}

export interface ITudorBasedReporting_ScreenState {
    isSpinnerVisible: boolean;
    isPageVisible: boolean;
	isLeftMenuVisible: boolean;
    spinnerCount: number;
    selectedLanguage: string;
    isPageInitLoaded: false;
    isPageRecurringLoaded: false;
	KuikaY_MonthlyStoreSalesReport: any[];
	KuikaY_MonthlyStoreSalesReport_dummy: any[];
	Kuika_ReportProductSales: any[];
	Kuika_ReportProductSales_dummy: any[];
	KuikaY_RolexTudorMonthlyStoreComparison: any[];
	KuikaY_RolexTudorMonthlyStoreComparison_dummy: any[];
	NAVIGATE: any;
	NAVIGATE_dummy: any;
	ExportExcel: any;
	ExportExcel_dummy: any;
	ChangeVisibilityOf: string;
	ChangeVisibilityOf_dummy: string;
	isComp15049Visible: 'visible' | 'hidden';
	isComp456411Visible: 'visible' | 'hidden';
	isComp209508Visible: 'visible' | 'hidden';
	isComp479325Visible: 'visible' | 'hidden';
	isComp483040Visible: 'visible' | 'hidden';
	isComp467053Visible: 'visible' | 'hidden';
	isComp232766Visible: 'visible' | 'hidden';
	isComp535273Visible: 'visible' | 'hidden';
	isComp835831Visible: 'visible' | 'hidden';
	isComp319590Visible: 'visible' | 'hidden';
	isComp479827Visible: 'visible' | 'hidden';
	isComp80834Visible: 'visible' | 'hidden';
	isComp775898Visible: 'visible' | 'hidden';
	isComp303079Visible: 'visible' | 'hidden';
	isComp963108Visible: 'visible' | 'hidden';
	isComp70247Visible: 'visible' | 'hidden';
	isComp523654Visible: 'visible' | 'hidden';
	isComp71362Visible: 'visible' | 'hidden';
	isComp547337Visible: 'visible' | 'hidden';
	isComp499406Visible: 'visible' | 'hidden';
	isComp912535Visible: 'visible' | 'hidden';
	isComp104136Visible: 'visible' | 'hidden';
	isComp189581Visible: 'visible' | 'hidden';
	isComp12509Visible: 'visible' | 'hidden';
	isComp600828Visible: 'visible' | 'hidden';
	isComp342166Visible: 'visible' | 'hidden';
	isComp294678Visible: 'visible' | 'hidden';
	isComp107219Visible: 'visible' | 'hidden';
	isComp185264Visible: 'visible' | 'hidden';
	isComp285886Visible: 'visible' | 'hidden';
	isComp799715Visible: 'visible' | 'hidden';
	isComp885805Visible: 'visible' | 'hidden';
	isComp319606Visible: 'visible' | 'hidden';

}

export class TudorBasedReporting_ScreenBase extends React.PureComponent<ITudorBasedReporting_ScreenProps, any> {
    static contextType = MasterScreen_ScreenContext;
    declare context: React.ContextType<typeof MasterScreen_ScreenContext>;
	tudorbasedreporting_828484_value_kuikaTableRef: React.RefObject<any>;
	tudorbasedreporting_214137_value_kuikaTableRef: React.RefObject<any>;
	tudorbasedreporting_68219_value_kuikaTableRef: React.RefObject<any>;
	tudorbasedreporting_52001_value_kuikaTableRef: React.RefObject<any>;
	tudorbasedreporting_736715_value_kuikaTableRef: React.RefObject<any>;
	tudorbasedreporting_772268_value_kuikaTableRef: React.RefObject<any>;
	tudorbasedreporting_183311_value_kuikaTableRef: React.RefObject<any>;
	tudorbasedreporting_91524_value_kuikaTableRef: React.RefObject<any>;
	tudorbasedreporting_223959_value_kuikaTableRef: React.RefObject<any>;
	tudorbasedreporting_992813_value_kuikaTableRef: React.RefObject<any>;
	tudorbasedreporting_958463_value_kuikaTableRef: React.RefObject<any>;
	tudorbasedreporting_365292_value_kuikaTableRef: React.RefObject<any>;
	tudorbasedreporting_822923_value_kuikaTableRef: React.RefObject<any>;
    ml=[{"Id":"d5a61d2b-bd60-485f-86e2-661e9ed4e486","Name":"en_US","ShortName":"English","IsDefault":true,"LanguagePhrases":[]},{"Id":"1fdb204e-81b2-4ff4-91c7-60131b134d41","Name":"FixedValues","ShortName":"FixedValues","LanguagePhrases":[{"Id":910240,"PropertyName":"value","Value":"Marka Bazlı Raporlama"},{"Id":869891,"PropertyName":"value","Value":"Mağaza satış performanslarını karşılaştırmalı olarak analiz edin."},{"Id":630245,"PropertyName":"label","Value":"Rolex"},{"Id":875001,"PropertyName":"label","Value":"Tudor"},{"Id":435603,"PropertyName":"label","Value":"Mont Blanc"},{"Id":110385,"PropertyName":"label","Value":"Dupont"},{"Id":126713,"PropertyName":"value","Value":"Analiz Tipi"},{"Id":248363,"PropertyName":"value","Value":"Genel Satış"},{"Id":640909,"PropertyName":"value","Value":"Family Bazlı"},{"Id":21556,"PropertyName":"value","Value":"Tudor-"},{"Id":459927,"PropertyName":"value","Value":"-Genel Satış Özeti"},{"Id":808537,"PropertyName":"placeholder","Value":"Select Year..."},{"Id":37878,"PropertyName":"value","Value":"Toplam Satış Adedi"},{"Id":833488,"PropertyName":"value","Value":"+18.5%"},{"Id":232881,"PropertyName":"value","Value":"-18.5%"},{"Id":48790,"PropertyName":"value","Value":"Bu Ayın Satış Adeti"},{"Id":793158,"PropertyName":"value","Value":"+18.5%"},{"Id":268030,"PropertyName":"value","Value":"-18.5%"},{"Id":609778,"PropertyName":"value","Value":"Geçen Yıla Göre Artış"},{"Id":134804,"PropertyName":"value","Value":"Yıllık Büyüme"},{"Id":833729,"PropertyName":"value","Value":"En Güçlü Mağaza"},{"Id":111309,"PropertyName":"value","Value":"En Çok Satan Family"},{"Id":316216,"PropertyName":"value","Value":"En Çok Satan Material"},{"Id":914043,"PropertyName":"value","Value":"Tudor-"},{"Id":340599,"PropertyName":"value","Value":"-Mağaza Bazlı Satış Özet Görünüm"},{"Id":63060,"PropertyName":"placeholder","Value":"Select Year..."},{"Id":876329,"PropertyName":"title","Value":"Mağaza"},{"Id":640324,"PropertyName":"value","Value":"[datafield:magaza]"},{"Id":864911,"PropertyName":"title","Value":"Ocak"},{"Id":221520,"PropertyName":"value","Value":"[datafield:ocak]"},{"Id":538131,"PropertyName":"title","Value":"Şubat"},{"Id":897065,"PropertyName":"value","Value":"[datafield:subat]"},{"Id":24479,"PropertyName":"title","Value":"Mart"},{"Id":879969,"PropertyName":"value","Value":"[datafield:mart]"},{"Id":927901,"PropertyName":"title","Value":"Nisan"},{"Id":406927,"PropertyName":"value","Value":"[datafield:nisan]"},{"Id":406483,"PropertyName":"title","Value":"Mayıs"},{"Id":893650,"PropertyName":"value","Value":"[datafield:mayis]"},{"Id":836111,"PropertyName":"title","Value":"Haziran"},{"Id":945048,"PropertyName":"value","Value":"[datafield:haziran]"},{"Id":366464,"PropertyName":"title","Value":"Temmuz"},{"Id":556480,"PropertyName":"value","Value":"[datafield:temmuz]"},{"Id":362362,"PropertyName":"title","Value":"Ağustos"},{"Id":154209,"PropertyName":"value","Value":"[datafield:agustos]"},{"Id":368975,"PropertyName":"title","Value":"Eylül"},{"Id":388432,"PropertyName":"value","Value":"[datafield:eylul]"},{"Id":625241,"PropertyName":"title","Value":"Ekim"},{"Id":489180,"PropertyName":"value","Value":"[datafield:ekim]"},{"Id":995065,"PropertyName":"title","Value":"Kasım"},{"Id":130241,"PropertyName":"value","Value":"[datafield:kasim]"},{"Id":694031,"PropertyName":"title","Value":"Aralık"},{"Id":695667,"PropertyName":"value","Value":"[datafield:aralik]"},{"Id":455864,"PropertyName":"title","Value":"Toplam"},{"Id":455386,"PropertyName":"value","Value":"[datafield:toplam]"},{"Id":856092,"PropertyName":"value","Value":"Aylık Satış Raporları - Tudor"},{"Id":695952,"PropertyName":"value","Value":"Yıl 1"},{"Id":174946,"PropertyName":"placeholder","Value":"Select Year..."},{"Id":419400,"PropertyName":"value","Value":"Yıl 2"},{"Id":424839,"PropertyName":"placeholder","Value":"Select Year..."},{"Id":732267,"PropertyName":"label","Value":"Çalıştır"},{"Id":267786,"PropertyName":"value","Value":"Aylık Satış Raporlarını Görmek için Raporu Çalıştırınız."},{"Id":911702,"PropertyName":"value","Value":"Ocak/"},{"Id":235822,"PropertyName":"value","Value":"-"},{"Id":633698,"PropertyName":"title","Value":"Mağaza"},{"Id":972461,"PropertyName":"value","Value":"[datafield:merkez]"},{"Id":324639,"PropertyName":"value","Value":"[datafield:ocak_yil1]"},{"Id":830326,"PropertyName":"value","Value":"[datafield:ocak_yil2]"},{"Id":160855,"PropertyName":"title","Value":"Değişim"},{"Id":319590,"PropertyName":"value","Value":"[datafield:ocakdegisim]"},{"Id":479827,"PropertyName":"value","Value":"[datafield:ocakdegisim]"},{"Id":685344,"PropertyName":"value","Value":"Şubat/"},{"Id":745,"PropertyName":"value","Value":"-"},{"Id":824694,"PropertyName":"title","Value":"Mağaza"},{"Id":485876,"PropertyName":"value","Value":"[datafield:merkez]"},{"Id":924113,"PropertyName":"value","Value":"[datafield:subat_yil1]"},{"Id":129694,"PropertyName":"value","Value":"[datafield:subat_yil2]"},{"Id":383994,"PropertyName":"title","Value":"Değişim"},{"Id":80834,"PropertyName":"value","Value":"[datafield:subatdegisim]"},{"Id":775898,"PropertyName":"value","Value":"[datafield:subatdegisim]"},{"Id":378266,"PropertyName":"value","Value":"Mart/"},{"Id":93287,"PropertyName":"value","Value":"-"},{"Id":133250,"PropertyName":"title","Value":"Mağaza"},{"Id":106726,"PropertyName":"value","Value":"[datafield:merkez]"},{"Id":600124,"PropertyName":"value","Value":"[datafield:mart_yil1]"},{"Id":814094,"PropertyName":"value","Value":"[datafield:mart_yil2]"},{"Id":192013,"PropertyName":"title","Value":"Değişim"},{"Id":303079,"PropertyName":"value","Value":"[datafield:martdegisim]"},{"Id":963108,"PropertyName":"value","Value":"[datafield:martdegisim]"},{"Id":505906,"PropertyName":"value","Value":"Nisan/"},{"Id":590609,"PropertyName":"value","Value":"-"},{"Id":686307,"PropertyName":"title","Value":"Mağaza"},{"Id":250161,"PropertyName":"value","Value":"[datafield:merkez]"},{"Id":175659,"PropertyName":"value","Value":"[datafield:nisan_yil1]"},{"Id":876716,"PropertyName":"value","Value":"[datafield:nisan_yil2]"},{"Id":929509,"PropertyName":"title","Value":"Değişim"},{"Id":70247,"PropertyName":"value","Value":"[datafield:nisandegisim]"},{"Id":523654,"PropertyName":"value","Value":"[datafield:nisandegisim]"},{"Id":809412,"PropertyName":"value","Value":"Mayıs/"},{"Id":276054,"PropertyName":"value","Value":"-"},{"Id":998865,"PropertyName":"title","Value":"Mağaza"},{"Id":370609,"PropertyName":"value","Value":"[datafield:merkez]"},{"Id":829158,"PropertyName":"value","Value":"[datafield:mayis_yil1]"},{"Id":612489,"PropertyName":"value","Value":"[datafield:mayis_yil2]"},{"Id":463418,"PropertyName":"title","Value":"Değişim"},{"Id":71362,"PropertyName":"value","Value":"[datafield:mayisdegisim]"},{"Id":547337,"PropertyName":"value","Value":"[datafield:mayisdegisim]"},{"Id":411790,"PropertyName":"value","Value":"Haziran/"},{"Id":649212,"PropertyName":"value","Value":"-"},{"Id":546654,"PropertyName":"title","Value":"Mağaza"},{"Id":327620,"PropertyName":"value","Value":"[datafield:merkez]"},{"Id":163810,"PropertyName":"value","Value":"[datafield:haziran_yil1]"},{"Id":968810,"PropertyName":"value","Value":"[datafield:haziran_yil2]"},{"Id":587517,"PropertyName":"title","Value":"Değişim"},{"Id":499406,"PropertyName":"value","Value":"[datafield:hazirandegisim]"},{"Id":912535,"PropertyName":"value","Value":"[datafield:hazirandegisim]"},{"Id":737485,"PropertyName":"value","Value":"Temmuz/"},{"Id":614458,"PropertyName":"value","Value":"-"},{"Id":434718,"PropertyName":"title","Value":"Mağaza"},{"Id":581478,"PropertyName":"value","Value":"[datafield:merkez]"},{"Id":617422,"PropertyName":"value","Value":"[datafield:temmuz_yil1]"},{"Id":798856,"PropertyName":"value","Value":"[datafield:temmuz_yil2]"},{"Id":408692,"PropertyName":"title","Value":"Değişim"},{"Id":104136,"PropertyName":"value","Value":"[datafield:temmuzdegisim]"},{"Id":189581,"PropertyName":"value","Value":"[datafield:temmuzdegisim]"},{"Id":361315,"PropertyName":"value","Value":"Ağustos/"},{"Id":449423,"PropertyName":"value","Value":"-"},{"Id":569980,"PropertyName":"title","Value":"Mağaza"},{"Id":652271,"PropertyName":"value","Value":"[datafield:merkez]"},{"Id":915530,"PropertyName":"value","Value":"[datafield:agustos_yil1]"},{"Id":911517,"PropertyName":"value","Value":"[datafield:agustos_yil2]"},{"Id":592417,"PropertyName":"title","Value":"Değişim"},{"Id":12509,"PropertyName":"value","Value":"[datafield:agustosdegisim]"},{"Id":600828,"PropertyName":"value","Value":"[datafield:agustosdegisim]"},{"Id":370707,"PropertyName":"value","Value":"Eylül/"},{"Id":473626,"PropertyName":"value","Value":"-"},{"Id":749642,"PropertyName":"title","Value":"Mağaza"},{"Id":900637,"PropertyName":"value","Value":"[datafield:merkez]"},{"Id":631023,"PropertyName":"value","Value":"[datafield:eylul_yil1]"},{"Id":975071,"PropertyName":"value","Value":"[datafield:eylul_yil2]"},{"Id":207175,"PropertyName":"title","Value":"Değişim"},{"Id":342166,"PropertyName":"value","Value":"[datafield:eyluldegisim]"},{"Id":294678,"PropertyName":"value","Value":"[datafield:eyluldegisim]"},{"Id":985712,"PropertyName":"value","Value":"Ekim/"},{"Id":587619,"PropertyName":"value","Value":"-"},{"Id":185163,"PropertyName":"title","Value":"Mağaza"},{"Id":850965,"PropertyName":"value","Value":"[datafield:merkez]"},{"Id":118847,"PropertyName":"value","Value":"[datafield:ekim_yil1]"},{"Id":753105,"PropertyName":"value","Value":"[datafield:ekim_yil2]"},{"Id":630279,"PropertyName":"title","Value":"Değişim"},{"Id":107219,"PropertyName":"value","Value":"[datafield:ekimdegisim]"},{"Id":185264,"PropertyName":"value","Value":"[datafield:ekimdegisim]"},{"Id":343704,"PropertyName":"value","Value":"Kasım/"},{"Id":506441,"PropertyName":"value","Value":"-"},{"Id":587929,"PropertyName":"title","Value":"Mağaza"},{"Id":470687,"PropertyName":"value","Value":"[datafield:merkez]"},{"Id":709186,"PropertyName":"value","Value":"[datafield:kasim_yil1]"},{"Id":164201,"PropertyName":"value","Value":"[datafield:kasim_yil2]"},{"Id":470383,"PropertyName":"title","Value":"Değişim"},{"Id":285886,"PropertyName":"value","Value":"[datafield:kasimdegisim]"},{"Id":799715,"PropertyName":"value","Value":"[datafield:kasimdegisim]"},{"Id":42627,"PropertyName":"value","Value":"Aralık/"},{"Id":716186,"PropertyName":"value","Value":"-"},{"Id":445729,"PropertyName":"title","Value":"Mağaza"},{"Id":815678,"PropertyName":"value","Value":"[datafield:merkez]"},{"Id":812982,"PropertyName":"value","Value":"[datafield:aralik_yil1]"},{"Id":212507,"PropertyName":"value","Value":"[datafield:aralik_yil2]"},{"Id":362957,"PropertyName":"title","Value":"Değişim"},{"Id":885805,"PropertyName":"value","Value":"[datafield:aralikdegisim]"},{"Id":319606,"PropertyName":"value","Value":"[datafield:aralikdegisim]"}]}]
    defaultML = "en_US"
    
    screenHash = ""
    

    private _prevMasterPageInitLoaded: boolean = false;
    private _prevMasterPageRecurringLoaded: boolean = false;
    private _prevShouldTriggerPageInit: boolean = false;
    constructor(props) {
        super(props);
		this.tudorbasedreporting_828484_value_kuikaTableRef = React.createRef();
		this.tudorbasedreporting_214137_value_kuikaTableRef = React.createRef();
		this.tudorbasedreporting_68219_value_kuikaTableRef = React.createRef();
		this.tudorbasedreporting_52001_value_kuikaTableRef = React.createRef();
		this.tudorbasedreporting_736715_value_kuikaTableRef = React.createRef();
		this.tudorbasedreporting_772268_value_kuikaTableRef = React.createRef();
		this.tudorbasedreporting_183311_value_kuikaTableRef = React.createRef();
		this.tudorbasedreporting_91524_value_kuikaTableRef = React.createRef();
		this.tudorbasedreporting_223959_value_kuikaTableRef = React.createRef();
		this.tudorbasedreporting_992813_value_kuikaTableRef = React.createRef();
		this.tudorbasedreporting_958463_value_kuikaTableRef = React.createRef();
		this.tudorbasedreporting_365292_value_kuikaTableRef = React.createRef();
		this.tudorbasedreporting_822923_value_kuikaTableRef = React.createRef();

        this.state = {
            isSpinnerVisible: false,
            isPageVisible: false,
            isLeftMenuVisible: false,
            spinnerCount: 0,
            selectedLanguage: "",
            isPageInitLoaded: false,
            isPageRecurringLoaded: false,
            	        KuikaY_MonthlyStoreSalesReport: [],
	        Kuika_ReportProductSales: [],
	        KuikaY_RolexTudorMonthlyStoreComparison: [],
	        NAVIGATE: "",
	        ExportExcel: "",
	        ChangeVisibilityOf: "",
	        isComp15049Visible: 'visible',
	        isComp456411Visible: 'hidden',
	        isComp209508Visible: 'hidden',
	        isComp479325Visible: 'hidden',
	        isComp483040Visible: 'hidden',
	        isComp467053Visible: 'hidden',
	        isComp232766Visible: 'hidden',
	        isComp535273Visible: 'hidden',
	        isComp835831Visible: 'hidden',
	        isComp319590Visible: 'hidden',
	        isComp479827Visible: 'hidden',
	        isComp80834Visible: 'hidden',
	        isComp775898Visible: 'hidden',
	        isComp303079Visible: 'hidden',
	        isComp963108Visible: 'hidden',
	        isComp70247Visible: 'hidden',
	        isComp523654Visible: 'hidden',
	        isComp71362Visible: 'hidden',
	        isComp547337Visible: 'hidden',
	        isComp499406Visible: 'hidden',
	        isComp912535Visible: 'hidden',
	        isComp104136Visible: 'hidden',
	        isComp189581Visible: 'hidden',
	        isComp12509Visible: 'hidden',
	        isComp600828Visible: 'hidden',
	        isComp342166Visible: 'hidden',
	        isComp294678Visible: 'hidden',
	        isComp107219Visible: 'hidden',
	        isComp185264Visible: 'hidden',
	        isComp285886Visible: 'hidden',
	        isComp799715Visible: 'hidden',
	        isComp885805Visible: 'hidden',
	        isComp319606Visible: 'hidden',

        }

        this.state.isPageVisible = true;
        
    }

    async componentDidMount() {

        if (KuikaAppManager.isPageInitPrevented()) {
            KuikaAppManager.calculateAndSetBodyHeight("tudorbasedreporting", "masterscreen_screen");
            return;
        }
        this.context.registerCallbackFunction(this.callCallbackFunction.bind(this));
        
        ReactSystemFunctions.validateToken()
        this.fillFormInitValues();
        if (false){
            await this.TudorBasedReportingPageInit();
        } else if (this.context?.isMasterPageInitLoaded) { this._prevMasterPageInitLoaded = true; await this.TudorBasedReportingPageInit(); }
        
        
        
        KuikaAppManager.calculateAndSetBodyHeight("tudorbasedreporting", "masterscreen_screen");

        if (ReactSystemFunctions.getIsMicroApp() === false) {
           window.parentScreen = this;
        }
    }

    componentWillUnmount() {
        
        
        

        if (ReactSystemFunctions.getIsMicroApp() === false) {
           window.parentScreen = null;
        }
    }

    

        
    componentDidUpdate= async (prevProps, prevState) => {
		KuikaAppManager.calculateAndSetBodyHeight("tudorbasedreporting", "masterscreen_screen"    );
        if (prevProps?.location?.search !== (this.props as any)?.location?.search) {
			await this.TudorBasedReportingPageInit();
		}

        		if (this._prevMasterPageInitLoaded !== this.context.isMasterPageInitLoaded && this.context.isMasterPageInitLoaded === true) {this._prevMasterPageInitLoaded = this.context.isMasterPageInitLoaded;await this.TudorBasedReportingPageInit()}


        if (ReactSystemFunctions.getIsMicroApp() === false) {
            for (const key in prevState) {
                if (key.startsWith('NavVisible') && prevState[key] === true && this.state[key] === false) {
                    window.parentScreen = this;
                    break;
                }
            }
        }
	}

    fillFormInitValues() {
        this.props.form?.setFieldsValue({
});

    }

      setPageInitLoaded = (value: boolean) => {
        this.setState({ isPageInitLoaded: value });
      }

      setPageRecurringLoaded = (value: boolean) => {
        this.setState({ isPageRecurringLoaded: value });
      }

      clearFieldValidation = (changedValues: any) => {
        const fieldName = Object.keys(changedValues)[0];
        if (fieldName) {
          this.props.form?.setFields([
            {
              name: fieldName,
              errors: []
            }
          ]);
        }
      };

      

    TudorBasedReportingPageInit = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


	if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }

        let localVar = {
			Brand_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.convertToTypeByName("Tudor", "string"), "string"),
			ProductGroup_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.convertToTypeByName("Kol Saati", "string"), "string"),
			Year_0: ReactSystemFunctions.convertToTypeByName(2026, "number"),
			Marka_1: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.convertToTypeByName("Tudor", "string"), "string"),
			UrunGrubu_1: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.convertToTypeByName("Kol saati", "string"), "string"),
			Year_1: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "tudorbasedreporting_808537_value", "value", "", "", "")), "number"),
			Brand_2: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.convertToTypeByName("Tudor", "string"), "string"),
			ProductGroup_2: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.convertToTypeByName("Kol Saati", "string"), "string"),
			Year1_2: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "tudorbasedreporting_174946_value", "value", "", "", "")), "number"),
			Year2_2: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "tudorbasedreporting_424839_value", "value", "", "", "")), "number")
        }

	KuikaAppManager.showSpinner(this);
	
        if (true) {
        KuikaAppManager.showSpinner(this);
        }
        let result = await KuikaAppManager.ApiRequest(this, "TudorBasedReporting/TudorBasedReportingPageInit", localVar)
        if (!KMainFunctions.IsResStatus2XX(result)) return true;

		stateVars.KuikaY_MonthlyStoreSalesReport = result?.data.kuikaY_MonthlyStoreSalesReport;
		
		stateVars.Kuika_ReportProductSales = result?.data.kuika_ReportProductSales;
		formVars.tudorbasedreporting_142273_value = ReactSystemFunctions.toString(this, (stateVars.Kuika_ReportProductSales !== undefined ? (stateVars.Kuika_ReportProductSales?.length > 0 ? stateVars.Kuika_ReportProductSales[0].toplamSatisAdedi : null) : (this.state.Kuika_ReportProductSales?.length > 0 ? this.state.Kuika_ReportProductSales[0].toplamSatisAdedi : null)));
		formVars.tudorbasedreporting_862873_value = ReactSystemFunctions.toString(this, (stateVars.Kuika_ReportProductSales !== undefined ? (stateVars.Kuika_ReportProductSales?.length > 0 ? stateVars.Kuika_ReportProductSales[0].bulundugumuzAySatisAdedi : null) : (this.state.Kuika_ReportProductSales?.length > 0 ? this.state.Kuika_ReportProductSales[0].bulundugumuzAySatisAdedi : null)));
		formVars.tudorbasedreporting_442377_value = ReactSystemFunctions.toString(this, (stateVars.Kuika_ReportProductSales !== undefined ? (stateVars.Kuika_ReportProductSales?.length > 0 ? stateVars.Kuika_ReportProductSales[0].gecenYilaGoreArtisYuzde : null) : (this.state.Kuika_ReportProductSales?.length > 0 ? this.state.Kuika_ReportProductSales[0].gecenYilaGoreArtisYuzde : null)));
		formVars.tudorbasedreporting_49365_value = ReactSystemFunctions.toString(this, (stateVars.Kuika_ReportProductSales !== undefined ? (stateVars.Kuika_ReportProductSales?.length > 0 ? stateVars.Kuika_ReportProductSales[0].enGucluMagazaDesc : null) : (this.state.Kuika_ReportProductSales?.length > 0 ? this.state.Kuika_ReportProductSales[0].enGucluMagazaDesc : null)));
		formVars.tudorbasedreporting_689773_value = ReactSystemFunctions.toString(this, (stateVars.Kuika_ReportProductSales !== undefined ? (stateVars.Kuika_ReportProductSales?.length > 0 ? stateVars.Kuika_ReportProductSales[0].enGucluMagazaCiro : null) : (this.state.Kuika_ReportProductSales?.length > 0 ? this.state.Kuika_ReportProductSales[0].enGucluMagazaCiro : null)));
		formVars.tudorbasedreporting_662229_value = ReactSystemFunctions.toString(this, (stateVars.Kuika_ReportProductSales !== undefined ? (stateVars.Kuika_ReportProductSales?.length > 0 ? stateVars.Kuika_ReportProductSales[0].enCokSatanFamily : null) : (this.state.Kuika_ReportProductSales?.length > 0 ? this.state.Kuika_ReportProductSales[0].enCokSatanFamily : null)));
		formVars.tudorbasedreporting_825140_value = ReactSystemFunctions.toString(this, (stateVars.Kuika_ReportProductSales !== undefined ? (stateVars.Kuika_ReportProductSales?.length > 0 ? stateVars.Kuika_ReportProductSales[0].enCokSatanFamilyAdet : null) : (this.state.Kuika_ReportProductSales?.length > 0 ? this.state.Kuika_ReportProductSales[0].enCokSatanFamilyAdet : null)));
		formVars.tudorbasedreporting_51555_value = ReactSystemFunctions.toString(this, (stateVars.Kuika_ReportProductSales !== undefined ? (stateVars.Kuika_ReportProductSales?.length > 0 ? stateVars.Kuika_ReportProductSales[0].enCokSatanMaterial : null) : (this.state.Kuika_ReportProductSales?.length > 0 ? this.state.Kuika_ReportProductSales[0].enCokSatanMaterial : null)));
		formVars.tudorbasedreporting_816749_value = ReactSystemFunctions.toString(this, (stateVars.Kuika_ReportProductSales !== undefined ? (stateVars.Kuika_ReportProductSales?.length > 0 ? stateVars.Kuika_ReportProductSales[0].enCokSatanMaterialCiro : null) : (this.state.Kuika_ReportProductSales?.length > 0 ? this.state.Kuika_ReportProductSales[0].enCokSatanMaterialCiro : null)));
		stateVars.KuikaY_RolexTudorMonthlyStoreComparison = result?.data.kuikaY_RolexTudorMonthlyStoreComparison;
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		this.props.form?.setFieldsValue(formVars);
		
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.TudorBasedReportingPageInit1_();
                  resolve();
                });
          })



        
        KuikaAppManager.hideSpinner(this);
        return isErrorOccurred;
    }
	TudorBasedReportingPageInit1_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


	if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }

			ReactSystemFunctions.setValueOf(this, "tudorbasedreporting_453969_toString", ReactSystemFunctions.value(this, "tudorbasedreporting_808537_value", "value"), "value");

			formVars.tudorbasedreporting_142273_value = ReactSystemFunctions.toString(this, (stateVars.Kuika_ReportProductSales !== undefined ? (stateVars.Kuika_ReportProductSales?.length > 0 ? stateVars.Kuika_ReportProductSales[0].toplamSatisAdedi : null) : (this.state.Kuika_ReportProductSales?.length > 0 ? this.state.Kuika_ReportProductSales[0].toplamSatisAdedi : null)));

			formVars.tudorbasedreporting_862873_value = ReactSystemFunctions.toString(this, (stateVars.Kuika_ReportProductSales !== undefined ? (stateVars.Kuika_ReportProductSales?.length > 0 ? stateVars.Kuika_ReportProductSales[0].bulundugumuzAySatisAdedi : null) : (this.state.Kuika_ReportProductSales?.length > 0 ? this.state.Kuika_ReportProductSales[0].bulundugumuzAySatisAdedi : null)));

			formVars.tudorbasedreporting_442377_value = ReactSystemFunctions.toString(this, (stateVars.Kuika_ReportProductSales !== undefined ? (stateVars.Kuika_ReportProductSales?.length > 0 ? stateVars.Kuika_ReportProductSales[0].gecenYilaGoreArtisYuzde : null) : (this.state.Kuika_ReportProductSales?.length > 0 ? this.state.Kuika_ReportProductSales[0].gecenYilaGoreArtisYuzde : null)));

			formVars.tudorbasedreporting_49365_value = ReactSystemFunctions.toString(this, (stateVars.Kuika_ReportProductSales !== undefined ? (stateVars.Kuika_ReportProductSales?.length > 0 ? stateVars.Kuika_ReportProductSales[0].enGucluMagazaDesc : null) : (this.state.Kuika_ReportProductSales?.length > 0 ? this.state.Kuika_ReportProductSales[0].enGucluMagazaDesc : null)));

			formVars.tudorbasedreporting_689773_value = ReactSystemFunctions.toString(this, (stateVars.Kuika_ReportProductSales !== undefined ? (stateVars.Kuika_ReportProductSales?.length > 0 ? stateVars.Kuika_ReportProductSales[0].enGucluMagazaCiro : null) : (this.state.Kuika_ReportProductSales?.length > 0 ? this.state.Kuika_ReportProductSales[0].enGucluMagazaCiro : null)));

			formVars.tudorbasedreporting_662229_value = ReactSystemFunctions.toString(this, (stateVars.Kuika_ReportProductSales !== undefined ? (stateVars.Kuika_ReportProductSales?.length > 0 ? stateVars.Kuika_ReportProductSales[0].enCokSatanFamily : null) : (this.state.Kuika_ReportProductSales?.length > 0 ? this.state.Kuika_ReportProductSales[0].enCokSatanFamily : null)));

			formVars.tudorbasedreporting_825140_value = ReactSystemFunctions.toString(this, (stateVars.Kuika_ReportProductSales !== undefined ? (stateVars.Kuika_ReportProductSales?.length > 0 ? stateVars.Kuika_ReportProductSales[0].enCokSatanFamilyAdet : null) : (this.state.Kuika_ReportProductSales?.length > 0 ? this.state.Kuika_ReportProductSales[0].enCokSatanFamilyAdet : null)));

			formVars.tudorbasedreporting_51555_value = ReactSystemFunctions.toString(this, (stateVars.Kuika_ReportProductSales !== undefined ? (stateVars.Kuika_ReportProductSales?.length > 0 ? stateVars.Kuika_ReportProductSales[0].enCokSatanMaterial : null) : (this.state.Kuika_ReportProductSales?.length > 0 ? this.state.Kuika_ReportProductSales[0].enCokSatanMaterial : null)));

			formVars.tudorbasedreporting_816749_value = ReactSystemFunctions.toString(this, (stateVars.Kuika_ReportProductSales !== undefined ? (stateVars.Kuika_ReportProductSales?.length > 0 ? stateVars.Kuika_ReportProductSales[0].enCokSatanMaterialCiro : null) : (this.state.Kuika_ReportProductSales?.length > 0 ? this.state.Kuika_ReportProductSales[0].enCokSatanMaterialCiro : null)));

			ReactSystemFunctions.setValueOf(this, "tudorbasedreporting_355310_toString", ReactSystemFunctions.value(this, "tudorbasedreporting_63060_value", "value"), "value");

			
			stateVars.dataSource_828484 = stateVars.KuikaY_MonthlyStoreSalesReport ?? this.state.KuikaY_MonthlyStoreSalesReport;
			ReactSystemFunctions.setValueOf(this, "tudorbasedreporting_168682_toString", ReactSystemFunctions.value(this, "tudorbasedreporting_174946_value", "value"), "value");

			ReactSystemFunctions.setValueOf(this, "tudorbasedreporting_704810_toString", ReactSystemFunctions.value(this, "tudorbasedreporting_424839_value", "value"), "value");

			
			stateVars.dataSource_214137 = stateVars.KuikaY_RolexTudorMonthlyStoreComparison ?? this.state.KuikaY_RolexTudorMonthlyStoreComparison;
			
			
			stateVars.isComp319590Visible = ((ReactSystemFunctions.isGreaterOrEqual(ReactSystemFunctions.value(this, "tudorbasedreporting_214137_value", "ocakDegisim"), ReactSystemFunctions.convertToTypeByName("0", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp479827Visible = ((ReactSystemFunctions.isLessThan(ReactSystemFunctions.value(this, "tudorbasedreporting_214137_value", "ocakDegisim"), ReactSystemFunctions.convertToTypeByName("0", "string"))) === true ? "visible" : "hidden")
			
			stateVars.dataSource_802879 = stateVars.KuikaY_RolexTudorMonthlyStoreComparison ?? this.state.KuikaY_RolexTudorMonthlyStoreComparison;
			ReactSystemFunctions.setValueOf(this, "tudorbasedreporting_305000_toString", ReactSystemFunctions.value(this, "tudorbasedreporting_174946_value", "value"), "value");

			ReactSystemFunctions.setValueOf(this, "tudorbasedreporting_749396_toString", ReactSystemFunctions.value(this, "tudorbasedreporting_424839_value", "value"), "value");

			
			stateVars.dataSource_68219 = stateVars.KuikaY_RolexTudorMonthlyStoreComparison ?? this.state.KuikaY_RolexTudorMonthlyStoreComparison;
			
			
			stateVars.isComp80834Visible = ((ReactSystemFunctions.isGreaterOrEqual(ReactSystemFunctions.value(this, "tudorbasedreporting_68219_value", "subatDegisim"), ReactSystemFunctions.convertToTypeByName("0", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp775898Visible = ((ReactSystemFunctions.isLessThan(ReactSystemFunctions.value(this, "tudorbasedreporting_68219_value", "subatDegisim"), ReactSystemFunctions.convertToTypeByName("0", "string"))) === true ? "visible" : "hidden")
			
			stateVars.dataSource_741677 = stateVars.KuikaY_RolexTudorMonthlyStoreComparison ?? this.state.KuikaY_RolexTudorMonthlyStoreComparison;
			ReactSystemFunctions.setValueOf(this, "tudorbasedreporting_46217_toString", ReactSystemFunctions.value(this, "tudorbasedreporting_174946_value", "value"), "value");

			ReactSystemFunctions.setValueOf(this, "tudorbasedreporting_591719_toString", ReactSystemFunctions.value(this, "tudorbasedreporting_424839_value", "value"), "value");

			
			stateVars.dataSource_52001 = stateVars.KuikaY_RolexTudorMonthlyStoreComparison ?? this.state.KuikaY_RolexTudorMonthlyStoreComparison;
			
			
			stateVars.isComp303079Visible = ((ReactSystemFunctions.isGreaterOrEqual(ReactSystemFunctions.value(this, "tudorbasedreporting_52001_value", "martDegisim"), ReactSystemFunctions.convertToTypeByName("0", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp963108Visible = ((ReactSystemFunctions.isLessThan(ReactSystemFunctions.value(this, "tudorbasedreporting_52001_value", "martDegisim"), ReactSystemFunctions.convertToTypeByName("0", "string"))) === true ? "visible" : "hidden")
			
			stateVars.dataSource_594842 = stateVars.KuikaY_RolexTudorMonthlyStoreComparison ?? this.state.KuikaY_RolexTudorMonthlyStoreComparison;
			ReactSystemFunctions.setValueOf(this, "tudorbasedreporting_571581_toString", ReactSystemFunctions.value(this, "tudorbasedreporting_174946_value", "value"), "value");

			ReactSystemFunctions.setValueOf(this, "tudorbasedreporting_453243_toString", ReactSystemFunctions.value(this, "tudorbasedreporting_424839_value", "value"), "value");

			
			stateVars.dataSource_736715 = stateVars.KuikaY_RolexTudorMonthlyStoreComparison ?? this.state.KuikaY_RolexTudorMonthlyStoreComparison;
			
			
			stateVars.isComp70247Visible = ((ReactSystemFunctions.isGreaterOrEqual(ReactSystemFunctions.value(this, "tudorbasedreporting_736715_value", "nisanDegisim"), ReactSystemFunctions.convertToTypeByName("0", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp523654Visible = ((ReactSystemFunctions.isLessThan(ReactSystemFunctions.value(this, "tudorbasedreporting_736715_value", "nisanDegisim"), ReactSystemFunctions.convertToTypeByName("0", "string"))) === true ? "visible" : "hidden")
			
			stateVars.dataSource_447343 = stateVars.KuikaY_RolexTudorMonthlyStoreComparison ?? this.state.KuikaY_RolexTudorMonthlyStoreComparison;
			ReactSystemFunctions.setValueOf(this, "tudorbasedreporting_657616_toString", ReactSystemFunctions.value(this, "tudorbasedreporting_174946_value", "value"), "value");

			ReactSystemFunctions.setValueOf(this, "tudorbasedreporting_465588_toString", ReactSystemFunctions.value(this, "tudorbasedreporting_424839_value", "value"), "value");

			
			stateVars.dataSource_772268 = stateVars.KuikaY_RolexTudorMonthlyStoreComparison ?? this.state.KuikaY_RolexTudorMonthlyStoreComparison;
			
			
			stateVars.isComp71362Visible = ((ReactSystemFunctions.isGreaterOrEqual(ReactSystemFunctions.value(this, "tudorbasedreporting_772268_value", "mayisDegisim"), ReactSystemFunctions.convertToTypeByName("0", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp547337Visible = ((ReactSystemFunctions.isLessThan(ReactSystemFunctions.value(this, "tudorbasedreporting_772268_value", "mayisDegisim"), ReactSystemFunctions.convertToTypeByName("0", "string"))) === true ? "visible" : "hidden")
			
			stateVars.dataSource_529931 = stateVars.KuikaY_RolexTudorMonthlyStoreComparison ?? this.state.KuikaY_RolexTudorMonthlyStoreComparison;
			ReactSystemFunctions.setValueOf(this, "tudorbasedreporting_983061_toString", ReactSystemFunctions.value(this, "tudorbasedreporting_174946_value", "value"), "value");

			ReactSystemFunctions.setValueOf(this, "tudorbasedreporting_763754_toString", ReactSystemFunctions.value(this, "tudorbasedreporting_424839_value", "value"), "value");

			
			stateVars.dataSource_183311 = stateVars.KuikaY_RolexTudorMonthlyStoreComparison ?? this.state.KuikaY_RolexTudorMonthlyStoreComparison;
			
			
			stateVars.isComp499406Visible = ((ReactSystemFunctions.isGreaterOrEqual(ReactSystemFunctions.value(this, "tudorbasedreporting_183311_value", "haziranDegisim"), ReactSystemFunctions.convertToTypeByName("0", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp912535Visible = ((ReactSystemFunctions.isLessThan(ReactSystemFunctions.value(this, "tudorbasedreporting_183311_value", "haziranDegisim"), ReactSystemFunctions.convertToTypeByName("0", "string"))) === true ? "visible" : "hidden")
			
			stateVars.dataSource_970294 = stateVars.KuikaY_RolexTudorMonthlyStoreComparison ?? this.state.KuikaY_RolexTudorMonthlyStoreComparison;
			ReactSystemFunctions.setValueOf(this, "tudorbasedreporting_731402_toString", ReactSystemFunctions.value(this, "tudorbasedreporting_174946_value", "value"), "value");

			ReactSystemFunctions.setValueOf(this, "tudorbasedreporting_364364_toString", ReactSystemFunctions.value(this, "tudorbasedreporting_424839_value", "value"), "value");

			
			stateVars.dataSource_91524 = stateVars.KuikaY_RolexTudorMonthlyStoreComparison ?? this.state.KuikaY_RolexTudorMonthlyStoreComparison;
			
			
			stateVars.isComp104136Visible = ((ReactSystemFunctions.isGreaterOrEqual(ReactSystemFunctions.value(this, "tudorbasedreporting_91524_value", "temmuzDegisim"), ReactSystemFunctions.convertToTypeByName("0", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp189581Visible = ((ReactSystemFunctions.isLessThan(ReactSystemFunctions.value(this, "tudorbasedreporting_91524_value", "temmuzDegisim"), ReactSystemFunctions.convertToTypeByName("0", "string"))) === true ? "visible" : "hidden")
			
			stateVars.dataSource_371388 = stateVars.KuikaY_RolexTudorMonthlyStoreComparison ?? this.state.KuikaY_RolexTudorMonthlyStoreComparison;
			ReactSystemFunctions.setValueOf(this, "tudorbasedreporting_824492_toString", ReactSystemFunctions.value(this, "tudorbasedreporting_174946_value", "value"), "value");

			ReactSystemFunctions.setValueOf(this, "tudorbasedreporting_669134_toString", ReactSystemFunctions.value(this, "tudorbasedreporting_424839_value", "value"), "value");

			
			stateVars.dataSource_223959 = stateVars.KuikaY_RolexTudorMonthlyStoreComparison ?? this.state.KuikaY_RolexTudorMonthlyStoreComparison;
			
			
			stateVars.isComp12509Visible = ((ReactSystemFunctions.isGreaterOrEqual(ReactSystemFunctions.value(this, "tudorbasedreporting_223959_value", "agustosDegisim"), ReactSystemFunctions.convertToTypeByName("0", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp600828Visible = ((ReactSystemFunctions.isLessThan(ReactSystemFunctions.value(this, "tudorbasedreporting_223959_value", "agustosDegisim"), ReactSystemFunctions.convertToTypeByName("0", "string"))) === true ? "visible" : "hidden")
			
			stateVars.dataSource_928314 = stateVars.KuikaY_RolexTudorMonthlyStoreComparison ?? this.state.KuikaY_RolexTudorMonthlyStoreComparison;
			ReactSystemFunctions.setValueOf(this, "tudorbasedreporting_386741_toString", ReactSystemFunctions.value(this, "tudorbasedreporting_174946_value", "value"), "value");

			ReactSystemFunctions.setValueOf(this, "tudorbasedreporting_278270_toString", ReactSystemFunctions.value(this, "tudorbasedreporting_424839_value", "value"), "value");

			
			stateVars.dataSource_992813 = stateVars.KuikaY_RolexTudorMonthlyStoreComparison ?? this.state.KuikaY_RolexTudorMonthlyStoreComparison;
			
			
			stateVars.isComp342166Visible = ((ReactSystemFunctions.isGreaterOrEqual(ReactSystemFunctions.value(this, "tudorbasedreporting_992813_value", "eylulDegisim"), ReactSystemFunctions.convertToTypeByName("0", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp294678Visible = ((ReactSystemFunctions.isLessThan(ReactSystemFunctions.value(this, "tudorbasedreporting_992813_value", "eylulDegisim"), ReactSystemFunctions.convertToTypeByName("0", "string"))) === true ? "visible" : "hidden")
			
			stateVars.dataSource_61939 = stateVars.KuikaY_RolexTudorMonthlyStoreComparison ?? this.state.KuikaY_RolexTudorMonthlyStoreComparison;
			ReactSystemFunctions.setValueOf(this, "tudorbasedreporting_732053_toString", ReactSystemFunctions.value(this, "tudorbasedreporting_174946_value", "value"), "value");

			ReactSystemFunctions.setValueOf(this, "tudorbasedreporting_445120_toString", ReactSystemFunctions.value(this, "tudorbasedreporting_424839_value", "value"), "value");

			
			stateVars.dataSource_958463 = stateVars.KuikaY_RolexTudorMonthlyStoreComparison ?? this.state.KuikaY_RolexTudorMonthlyStoreComparison;
			
			
			stateVars.isComp107219Visible = ((ReactSystemFunctions.isGreaterOrEqual(ReactSystemFunctions.value(this, "tudorbasedreporting_958463_value", "ekimDegisim"), ReactSystemFunctions.convertToTypeByName("0", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp185264Visible = ((ReactSystemFunctions.isLessThan(ReactSystemFunctions.value(this, "tudorbasedreporting_958463_value", "ekimDegisim"), ReactSystemFunctions.convertToTypeByName("0", "string"))) === true ? "visible" : "hidden")
			
			stateVars.dataSource_111625 = stateVars.KuikaY_RolexTudorMonthlyStoreComparison ?? this.state.KuikaY_RolexTudorMonthlyStoreComparison;
			ReactSystemFunctions.setValueOf(this, "tudorbasedreporting_719529_toString", ReactSystemFunctions.value(this, "tudorbasedreporting_174946_value", "value"), "value");

			ReactSystemFunctions.setValueOf(this, "tudorbasedreporting_775415_toString", ReactSystemFunctions.value(this, "tudorbasedreporting_424839_value", "value"), "value");

			
			stateVars.dataSource_365292 = stateVars.KuikaY_RolexTudorMonthlyStoreComparison ?? this.state.KuikaY_RolexTudorMonthlyStoreComparison;
			
			
			stateVars.isComp285886Visible = ((ReactSystemFunctions.isGreaterOrEqual(ReactSystemFunctions.value(this, "tudorbasedreporting_365292_value", "kasimDegisim"), ReactSystemFunctions.convertToTypeByName("0", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp799715Visible = ((ReactSystemFunctions.isLessThan(ReactSystemFunctions.value(this, "tudorbasedreporting_365292_value", "kasimDegisim"), ReactSystemFunctions.convertToTypeByName("0", "string"))) === true ? "visible" : "hidden")
			
			stateVars.dataSource_373877 = stateVars.KuikaY_RolexTudorMonthlyStoreComparison ?? this.state.KuikaY_RolexTudorMonthlyStoreComparison;
			ReactSystemFunctions.setValueOf(this, "tudorbasedreporting_864393_toString", ReactSystemFunctions.value(this, "tudorbasedreporting_174946_value", "value"), "value");

			ReactSystemFunctions.setValueOf(this, "tudorbasedreporting_659728_toString", ReactSystemFunctions.value(this, "tudorbasedreporting_424839_value", "value"), "value");

			
			stateVars.dataSource_822923 = stateVars.KuikaY_RolexTudorMonthlyStoreComparison ?? this.state.KuikaY_RolexTudorMonthlyStoreComparison;
			
			
			stateVars.isComp885805Visible = ((ReactSystemFunctions.isGreaterOrEqual(ReactSystemFunctions.value(this, "tudorbasedreporting_822923_value", "aralikDegisim"), ReactSystemFunctions.convertToTypeByName("0", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp319606Visible = ((ReactSystemFunctions.isLessThan(ReactSystemFunctions.value(this, "tudorbasedreporting_822923_value", "aralikDegisim"), ReactSystemFunctions.convertToTypeByName("0", "string"))) === true ? "visible" : "hidden")
			
			stateVars.dataSource_98565 = stateVars.KuikaY_RolexTudorMonthlyStoreComparison ?? this.state.KuikaY_RolexTudorMonthlyStoreComparison;

	this.props.form?.setFieldsValue(formVars);
	this.setState(stateVars);
	KuikaAppManager.hideSpinner(this);

            this.setPageInitLoaded(true);
            return isErrorOccurred;
        }




		TudorBasedReportingComponent_630245_onClick = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
KuikaAppManager.showSpinner(this);

const __currentPath = (window.location.hash ? window.location.hash.replace(/^#/, '').split('?')[0] : window.location.pathname.split('?')[0]).toLowerCase();
if (__currentPath !== "/rolexbasedreporting") {
  this.context.setMasterPageInitLoaded(false);
  this.context.setMasterPageRecurringLoaded(false);
  this.context.setShouldTriggerPageInit(true);
}
					KuikaAppManager.prepareForNavigation();

				stateVars.NAVIGATE = await ReactSystemFunctions.navigate(this, undefined, "TudorBasedReporting", "RolexBasedReporting", "", "currentPage", null, null, null, null, null, null, true, false);

		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

            
            return isErrorOccurred;
        }


		TudorBasedReportingComponent_435603_onClick = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
KuikaAppManager.showSpinner(this);

const __currentPath = (window.location.hash ? window.location.hash.replace(/^#/, '').split('?')[0] : window.location.pathname.split('?')[0]).toLowerCase();
if (__currentPath !== "/montblancbasedreporting") {
  this.context.setMasterPageInitLoaded(false);
  this.context.setMasterPageRecurringLoaded(false);
  this.context.setShouldTriggerPageInit(true);
}
					KuikaAppManager.prepareForNavigation();

				stateVars.NAVIGATE = await ReactSystemFunctions.navigate(this, undefined, "TudorBasedReporting", "MontBlancBasedReporting", "", "currentPage", null, null, null, null, null, null, true, false);

		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

            
            return isErrorOccurred;
        }


		TudorBasedReportingComponent_110385_onClick = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
KuikaAppManager.showSpinner(this);

const __currentPath = (window.location.hash ? window.location.hash.replace(/^#/, '').split('?')[0] : window.location.pathname.split('?')[0]).toLowerCase();
if (__currentPath !== "/dupontbasedreporting") {
  this.context.setMasterPageInitLoaded(false);
  this.context.setMasterPageRecurringLoaded(false);
  this.context.setShouldTriggerPageInit(true);
}
					KuikaAppManager.prepareForNavigation();

				stateVars.NAVIGATE = await ReactSystemFunctions.navigate(this, undefined, "TudorBasedReporting", "DupontBasedReporting", "", "currentPage", null, null, null, null, null, null, true, false);

		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

            
            return isErrorOccurred;
        }


		TudorBasedReportingComponent_948064_onClick = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
KuikaAppManager.showSpinner(this);

const __currentPath = (window.location.hash ? window.location.hash.replace(/^#/, '').split('?')[0] : window.location.pathname.split('?')[0]).toLowerCase();
if (__currentPath !== "/tudorfamilyreporting") {
  this.context.setMasterPageInitLoaded(false);
  this.context.setMasterPageRecurringLoaded(false);
  this.context.setShouldTriggerPageInit(true);
}
					KuikaAppManager.prepareForNavigation();

				stateVars.NAVIGATE = await ReactSystemFunctions.navigate(this, undefined, "TudorBasedReporting", "TudorFamilyReporting", "", "currentPage", null, null, null, null, null, null, true, false);

		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

            
            return isErrorOccurred;
        }


		TudorBasedReportingComponent_808537_onChange = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
KuikaAppManager.showSpinner(this);

				ReactSystemFunctions.setValueOf(this, "tudorbasedreporting_453969_toString", ReactSystemFunctions.value(this, "tudorbasedreporting_808537_value", "value"), "value");


		this.props.form?.setFieldsValue(formVars);
		
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.TudorBasedReportingComponent_808537_onChange1_();
                  resolve();
                });
          })

            
            return isErrorOccurred;
        }
    TudorBasedReportingComponent_808537_onChange1_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
		KuikaAppManager.increaseServerRequestCount();

        let localVar = {
				Marka_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.convertToTypeByName("Tudor", "string"), "string"),
				UrunGrubu_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.convertToTypeByName("Kol saati", "string"), "string"),
				Year_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "tudorbasedreporting_808537_value", "value", "", "", "")), "number")
        }

		
        if (true) {
        KuikaAppManager.showSpinner(this);
        }
        let result = await KuikaAppManager.ApiRequest(this, "TudorBasedReporting/TudorBasedReportingComponent_808537_onChange1_", localVar)
        if (!KMainFunctions.IsResStatus2XX(result)) return true;

			stateVars.Kuika_ReportProductSales = result?.data.kuika_ReportProductSales;
			formVars.tudorbasedreporting_142273_value = ReactSystemFunctions.toString(this, (stateVars.Kuika_ReportProductSales !== undefined ? (stateVars.Kuika_ReportProductSales?.length > 0 ? stateVars.Kuika_ReportProductSales[0].toplamSatisAdedi : null) : (this.state.Kuika_ReportProductSales?.length > 0 ? this.state.Kuika_ReportProductSales[0].toplamSatisAdedi : null)));
			formVars.tudorbasedreporting_862873_value = ReactSystemFunctions.toString(this, (stateVars.Kuika_ReportProductSales !== undefined ? (stateVars.Kuika_ReportProductSales?.length > 0 ? stateVars.Kuika_ReportProductSales[0].bulundugumuzAySatisAdedi : null) : (this.state.Kuika_ReportProductSales?.length > 0 ? this.state.Kuika_ReportProductSales[0].bulundugumuzAySatisAdedi : null)));
			formVars.tudorbasedreporting_442377_value = ReactSystemFunctions.toString(this, (stateVars.Kuika_ReportProductSales !== undefined ? (stateVars.Kuika_ReportProductSales?.length > 0 ? stateVars.Kuika_ReportProductSales[0].gecenYilaGoreArtisYuzde : null) : (this.state.Kuika_ReportProductSales?.length > 0 ? this.state.Kuika_ReportProductSales[0].gecenYilaGoreArtisYuzde : null)));
			formVars.tudorbasedreporting_49365_value = ReactSystemFunctions.toString(this, (stateVars.Kuika_ReportProductSales !== undefined ? (stateVars.Kuika_ReportProductSales?.length > 0 ? stateVars.Kuika_ReportProductSales[0].enGucluMagazaDesc : null) : (this.state.Kuika_ReportProductSales?.length > 0 ? this.state.Kuika_ReportProductSales[0].enGucluMagazaDesc : null)));
			formVars.tudorbasedreporting_689773_value = ReactSystemFunctions.toString(this, (stateVars.Kuika_ReportProductSales !== undefined ? (stateVars.Kuika_ReportProductSales?.length > 0 ? stateVars.Kuika_ReportProductSales[0].enGucluMagazaCiro : null) : (this.state.Kuika_ReportProductSales?.length > 0 ? this.state.Kuika_ReportProductSales[0].enGucluMagazaCiro : null)));
			formVars.tudorbasedreporting_662229_value = ReactSystemFunctions.toString(this, (stateVars.Kuika_ReportProductSales !== undefined ? (stateVars.Kuika_ReportProductSales?.length > 0 ? stateVars.Kuika_ReportProductSales[0].enCokSatanFamily : null) : (this.state.Kuika_ReportProductSales?.length > 0 ? this.state.Kuika_ReportProductSales[0].enCokSatanFamily : null)));
			formVars.tudorbasedreporting_825140_value = ReactSystemFunctions.toString(this, (stateVars.Kuika_ReportProductSales !== undefined ? (stateVars.Kuika_ReportProductSales?.length > 0 ? stateVars.Kuika_ReportProductSales[0].enCokSatanFamilyAdet : null) : (this.state.Kuika_ReportProductSales?.length > 0 ? this.state.Kuika_ReportProductSales[0].enCokSatanFamilyAdet : null)));
			formVars.tudorbasedreporting_51555_value = ReactSystemFunctions.toString(this, (stateVars.Kuika_ReportProductSales !== undefined ? (stateVars.Kuika_ReportProductSales?.length > 0 ? stateVars.Kuika_ReportProductSales[0].enCokSatanMaterial : null) : (this.state.Kuika_ReportProductSales?.length > 0 ? this.state.Kuika_ReportProductSales[0].enCokSatanMaterial : null)));
			formVars.tudorbasedreporting_816749_value = ReactSystemFunctions.toString(this, (stateVars.Kuika_ReportProductSales !== undefined ? (stateVars.Kuika_ReportProductSales?.length > 0 ? stateVars.Kuika_ReportProductSales[0].enCokSatanMaterialCiro : null) : (this.state.Kuika_ReportProductSales?.length > 0 ? this.state.Kuika_ReportProductSales[0].enCokSatanMaterialCiro : null)));
			this.props.form?.setFieldsValue(formVars);
			
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.TudorBasedReportingComponent_808537_onChange2_();
                  resolve();
                });
          })



        
        KuikaAppManager.hideSpinner(this);
        return isErrorOccurred;
    }
		TudorBasedReportingComponent_808537_onChange2_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }

				formVars.tudorbasedreporting_142273_value = ReactSystemFunctions.toString(this, (stateVars.Kuika_ReportProductSales !== undefined ? (stateVars.Kuika_ReportProductSales?.length > 0 ? stateVars.Kuika_ReportProductSales[0].toplamSatisAdedi : null) : (this.state.Kuika_ReportProductSales?.length > 0 ? this.state.Kuika_ReportProductSales[0].toplamSatisAdedi : null)));

				formVars.tudorbasedreporting_862873_value = ReactSystemFunctions.toString(this, (stateVars.Kuika_ReportProductSales !== undefined ? (stateVars.Kuika_ReportProductSales?.length > 0 ? stateVars.Kuika_ReportProductSales[0].bulundugumuzAySatisAdedi : null) : (this.state.Kuika_ReportProductSales?.length > 0 ? this.state.Kuika_ReportProductSales[0].bulundugumuzAySatisAdedi : null)));

				formVars.tudorbasedreporting_442377_value = ReactSystemFunctions.toString(this, (stateVars.Kuika_ReportProductSales !== undefined ? (stateVars.Kuika_ReportProductSales?.length > 0 ? stateVars.Kuika_ReportProductSales[0].gecenYilaGoreArtisYuzde : null) : (this.state.Kuika_ReportProductSales?.length > 0 ? this.state.Kuika_ReportProductSales[0].gecenYilaGoreArtisYuzde : null)));

				formVars.tudorbasedreporting_49365_value = ReactSystemFunctions.toString(this, (stateVars.Kuika_ReportProductSales !== undefined ? (stateVars.Kuika_ReportProductSales?.length > 0 ? stateVars.Kuika_ReportProductSales[0].enGucluMagazaDesc : null) : (this.state.Kuika_ReportProductSales?.length > 0 ? this.state.Kuika_ReportProductSales[0].enGucluMagazaDesc : null)));

				formVars.tudorbasedreporting_689773_value = ReactSystemFunctions.toString(this, (stateVars.Kuika_ReportProductSales !== undefined ? (stateVars.Kuika_ReportProductSales?.length > 0 ? stateVars.Kuika_ReportProductSales[0].enGucluMagazaCiro : null) : (this.state.Kuika_ReportProductSales?.length > 0 ? this.state.Kuika_ReportProductSales[0].enGucluMagazaCiro : null)));

				formVars.tudorbasedreporting_662229_value = ReactSystemFunctions.toString(this, (stateVars.Kuika_ReportProductSales !== undefined ? (stateVars.Kuika_ReportProductSales?.length > 0 ? stateVars.Kuika_ReportProductSales[0].enCokSatanFamily : null) : (this.state.Kuika_ReportProductSales?.length > 0 ? this.state.Kuika_ReportProductSales[0].enCokSatanFamily : null)));

				formVars.tudorbasedreporting_825140_value = ReactSystemFunctions.toString(this, (stateVars.Kuika_ReportProductSales !== undefined ? (stateVars.Kuika_ReportProductSales?.length > 0 ? stateVars.Kuika_ReportProductSales[0].enCokSatanFamilyAdet : null) : (this.state.Kuika_ReportProductSales?.length > 0 ? this.state.Kuika_ReportProductSales[0].enCokSatanFamilyAdet : null)));

				formVars.tudorbasedreporting_51555_value = ReactSystemFunctions.toString(this, (stateVars.Kuika_ReportProductSales !== undefined ? (stateVars.Kuika_ReportProductSales?.length > 0 ? stateVars.Kuika_ReportProductSales[0].enCokSatanMaterial : null) : (this.state.Kuika_ReportProductSales?.length > 0 ? this.state.Kuika_ReportProductSales[0].enCokSatanMaterial : null)));

				formVars.tudorbasedreporting_816749_value = ReactSystemFunctions.toString(this, (stateVars.Kuika_ReportProductSales !== undefined ? (stateVars.Kuika_ReportProductSales?.length > 0 ? stateVars.Kuika_ReportProductSales[0].enCokSatanMaterialCiro : null) : (this.state.Kuika_ReportProductSales?.length > 0 ? this.state.Kuika_ReportProductSales[0].enCokSatanMaterialCiro : null)));


		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

            
            return isErrorOccurred;
        }





		TudorBasedReportingComponent_63060_onChange = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
KuikaAppManager.showSpinner(this);

				ReactSystemFunctions.setValueOf(this, "tudorbasedreporting_355310_toString", ReactSystemFunctions.value(this, "tudorbasedreporting_63060_value", "value"), "value");


		this.props.form?.setFieldsValue(formVars);
		
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.TudorBasedReportingComponent_63060_onChange1_();
                  resolve();
                });
          })

            
            return isErrorOccurred;
        }
    TudorBasedReportingComponent_63060_onChange1_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
		KuikaAppManager.increaseServerRequestCount();

        let localVar = {
				Brand_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.convertToTypeByName("Tudor", "string"), "string"),
				ProductGroup_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.convertToTypeByName("Kol Saati", "string"), "string"),
				Year_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "tudorbasedreporting_63060_value", "value", "", "", "")), "number")
        }

		
        if (true) {
        KuikaAppManager.showSpinner(this);
        }
        let result = await KuikaAppManager.ApiRequest(this, "TudorBasedReporting/TudorBasedReportingComponent_63060_onChange1_", localVar)
        if (!KMainFunctions.IsResStatus2XX(result)) return true;

			stateVars.KuikaY_MonthlyStoreSalesReport = result?.data.kuikaY_MonthlyStoreSalesReport;
			
			this.props.form?.setFieldsValue(formVars);
			
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.TudorBasedReportingComponent_63060_onChange2_();
                  resolve();
                });
          })



        
        KuikaAppManager.hideSpinner(this);
        return isErrorOccurred;
    }
		TudorBasedReportingComponent_63060_onChange2_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }

				
				stateVars.dataSource_828484 = stateVars.KuikaY_MonthlyStoreSalesReport ?? this.state.KuikaY_MonthlyStoreSalesReport;

		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

            
            return isErrorOccurred;
        }





    TudorBasedReportingComponent_617720_onClick = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
		KuikaAppManager.increaseServerRequestCount();

        let localVar = {
				value_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, this.state.KuikaY_MonthlyStoreSalesReport), "any"),
				header_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.convertToTypeByName("Tudor Mağaza Bazlı Aylık Satış Özeti", "string"), "string"),
				footer_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "tudorbasedreporting_63060_value", "value", "", "", "")), "string"),
				columns_0: ReactSystemFunctions.convertToTypeByName("", "string")
        }

		KuikaAppManager.showSpinner(this);
		
        if (true) {
        KuikaAppManager.showSpinner(this);
        }
        let result = await KuikaAppManager.ApiRequest(this, "TudorBasedReporting/TudorBasedReportingComponent_617720_onClick", localVar)
        if (!KMainFunctions.IsResStatus2XX(result)) return true;

			stateVars.ExportExcel = result?.data.exportExcel;
			ReactSystemFunctions.downloadFile(result?.data?.exportExcel);
			this.props.form?.setFieldsValue(formVars);
			this.setState(stateVars);
			KuikaAppManager.hideSpinner(this);



        this.setPageInitLoaded(true);
        KuikaAppManager.hideSpinner(this);
        return isErrorOccurred;
    }



    TudorBasedReportingComponent_732267_onClick = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
		KuikaAppManager.increaseServerRequestCount();

        let localVar = {
				Brand_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.convertToTypeByName("Tudor", "string"), "string"),
				ProductGroup_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.convertToTypeByName("Kol Saati", "string"), "string"),
				Year1_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "tudorbasedreporting_174946_value", "value", "", "", "")), "number"),
				Year2_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "tudorbasedreporting_424839_value", "value", "", "", "")), "number")
        }

		KuikaAppManager.showSpinner(this);
		
        if (true) {
        KuikaAppManager.showSpinner(this);
        }
        let result = await KuikaAppManager.ApiRequest(this, "TudorBasedReporting/TudorBasedReportingComponent_732267_onClick", localVar)
        if (!KMainFunctions.IsResStatus2XX(result)) return true;

			stateVars.KuikaY_RolexTudorMonthlyStoreComparison = result?.data.kuikaY_RolexTudorMonthlyStoreComparison;
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			this.props.form?.setFieldsValue(formVars);
			
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.TudorBasedReportingComponent_732267_onClick1_();
                  resolve();
                });
          })



        
        KuikaAppManager.hideSpinner(this);
        return isErrorOccurred;
    }
		TudorBasedReportingComponent_732267_onClick1_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }

				stateVars.ChangeVisibilityOf = await ReactSystemFunctions.changeVisibilityOf(this, ReactSystemFunctions.convertToTypeByName("isComp15049Visible", "string"), ReactSystemFunctions.convertToTypeByName("visible", "string"));
				stateVars.ChangeVisibilityOf = await ReactSystemFunctions.changeVisibilityOf(this, ReactSystemFunctions.convertToTypeByName("isComp456411Visible", "string"), ReactSystemFunctions.convertToTypeByName("hidden", "string"));
				
				stateVars.dataSource_214137 = stateVars.KuikaY_RolexTudorMonthlyStoreComparison ?? this.state.KuikaY_RolexTudorMonthlyStoreComparison;
				
				stateVars.dataSource_802879 = stateVars.KuikaY_RolexTudorMonthlyStoreComparison ?? this.state.KuikaY_RolexTudorMonthlyStoreComparison;
				
				stateVars.dataSource_68219 = stateVars.KuikaY_RolexTudorMonthlyStoreComparison ?? this.state.KuikaY_RolexTudorMonthlyStoreComparison;
				
				stateVars.dataSource_741677 = stateVars.KuikaY_RolexTudorMonthlyStoreComparison ?? this.state.KuikaY_RolexTudorMonthlyStoreComparison;
				
				stateVars.dataSource_52001 = stateVars.KuikaY_RolexTudorMonthlyStoreComparison ?? this.state.KuikaY_RolexTudorMonthlyStoreComparison;
				
				stateVars.dataSource_594842 = stateVars.KuikaY_RolexTudorMonthlyStoreComparison ?? this.state.KuikaY_RolexTudorMonthlyStoreComparison;
				
				stateVars.dataSource_736715 = stateVars.KuikaY_RolexTudorMonthlyStoreComparison ?? this.state.KuikaY_RolexTudorMonthlyStoreComparison;
				
				stateVars.dataSource_447343 = stateVars.KuikaY_RolexTudorMonthlyStoreComparison ?? this.state.KuikaY_RolexTudorMonthlyStoreComparison;
				
				stateVars.dataSource_772268 = stateVars.KuikaY_RolexTudorMonthlyStoreComparison ?? this.state.KuikaY_RolexTudorMonthlyStoreComparison;
				
				stateVars.dataSource_529931 = stateVars.KuikaY_RolexTudorMonthlyStoreComparison ?? this.state.KuikaY_RolexTudorMonthlyStoreComparison;
				
				stateVars.dataSource_183311 = stateVars.KuikaY_RolexTudorMonthlyStoreComparison ?? this.state.KuikaY_RolexTudorMonthlyStoreComparison;
				
				stateVars.dataSource_970294 = stateVars.KuikaY_RolexTudorMonthlyStoreComparison ?? this.state.KuikaY_RolexTudorMonthlyStoreComparison;
				
				stateVars.dataSource_91524 = stateVars.KuikaY_RolexTudorMonthlyStoreComparison ?? this.state.KuikaY_RolexTudorMonthlyStoreComparison;
				
				stateVars.dataSource_371388 = stateVars.KuikaY_RolexTudorMonthlyStoreComparison ?? this.state.KuikaY_RolexTudorMonthlyStoreComparison;
				
				stateVars.dataSource_223959 = stateVars.KuikaY_RolexTudorMonthlyStoreComparison ?? this.state.KuikaY_RolexTudorMonthlyStoreComparison;
				
				stateVars.dataSource_928314 = stateVars.KuikaY_RolexTudorMonthlyStoreComparison ?? this.state.KuikaY_RolexTudorMonthlyStoreComparison;
				
				stateVars.dataSource_992813 = stateVars.KuikaY_RolexTudorMonthlyStoreComparison ?? this.state.KuikaY_RolexTudorMonthlyStoreComparison;
				
				stateVars.dataSource_61939 = stateVars.KuikaY_RolexTudorMonthlyStoreComparison ?? this.state.KuikaY_RolexTudorMonthlyStoreComparison;
				
				stateVars.dataSource_958463 = stateVars.KuikaY_RolexTudorMonthlyStoreComparison ?? this.state.KuikaY_RolexTudorMonthlyStoreComparison;
				
				stateVars.dataSource_111625 = stateVars.KuikaY_RolexTudorMonthlyStoreComparison ?? this.state.KuikaY_RolexTudorMonthlyStoreComparison;
				
				stateVars.dataSource_365292 = stateVars.KuikaY_RolexTudorMonthlyStoreComparison ?? this.state.KuikaY_RolexTudorMonthlyStoreComparison;
				
				stateVars.dataSource_373877 = stateVars.KuikaY_RolexTudorMonthlyStoreComparison ?? this.state.KuikaY_RolexTudorMonthlyStoreComparison;
				
				stateVars.dataSource_822923 = stateVars.KuikaY_RolexTudorMonthlyStoreComparison ?? this.state.KuikaY_RolexTudorMonthlyStoreComparison;
				
				stateVars.dataSource_98565 = stateVars.KuikaY_RolexTudorMonthlyStoreComparison ?? this.state.KuikaY_RolexTudorMonthlyStoreComparison;

		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

            
            return isErrorOccurred;
        }




    TudorBasedReportingComponent_328228_onClick = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
		KuikaAppManager.increaseServerRequestCount();

        let localVar = {
				value_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, this.state.KuikaY_RolexTudorMonthlyStoreComparison), "any"),
				header_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.convertToTypeByName("Karşılaştırmalı Aylık Tudor Satış Raporu", "string"), "string"),
				footer_0: ReactSystemFunctions.convertToTypeByName("", "string"),
				columns_0: ReactSystemFunctions.convertToTypeByName("", "string")
        }

		KuikaAppManager.showSpinner(this);
		
        if (true) {
        KuikaAppManager.showSpinner(this);
        }
        let result = await KuikaAppManager.ApiRequest(this, "TudorBasedReporting/TudorBasedReportingComponent_328228_onClick", localVar)
        if (!KMainFunctions.IsResStatus2XX(result)) return true;

			stateVars.ExportExcel = result?.data.exportExcel;
			ReactSystemFunctions.downloadFile(result?.data?.exportExcel);
			this.props.form?.setFieldsValue(formVars);
			this.setState(stateVars);
			KuikaAppManager.hideSpinner(this);



        this.setPageInitLoaded(true);
        KuikaAppManager.hideSpinner(this);
        return isErrorOccurred;
    }



    TudorBasedReportingComponent_977458_onClick = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
		KuikaAppManager.increaseServerRequestCount();

        let localVar = {
				value_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, this.state.KuikaY_RolexTudorMonthlyStoreComparison), "any"),
				header_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.convertToTypeByName("Karşılaştırmalı Tudor Ocak Ayı Satış Raporu", "string"), "string"),
				footer_0: ReactSystemFunctions.convertToTypeByName("", "string"),
				columns_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.convertToTypeByName("Merkez,Ocak_Yil1,Ocak_Yil2,OcakDegisim", "string"), "string")
        }

		KuikaAppManager.showSpinner(this);
		
        if (true) {
        KuikaAppManager.showSpinner(this);
        }
        let result = await KuikaAppManager.ApiRequest(this, "TudorBasedReporting/TudorBasedReportingComponent_977458_onClick", localVar)
        if (!KMainFunctions.IsResStatus2XX(result)) return true;

			stateVars.ExportExcel = result?.data.exportExcel;
			ReactSystemFunctions.downloadFile(result?.data?.exportExcel);
			this.props.form?.setFieldsValue(formVars);
			this.setState(stateVars);
			KuikaAppManager.hideSpinner(this);



        this.setPageInitLoaded(true);
        KuikaAppManager.hideSpinner(this);
        return isErrorOccurred;
    }



    TudorBasedReportingComponent_580172_onClick = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
		KuikaAppManager.increaseServerRequestCount();

        let localVar = {
				value_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, this.state.KuikaY_RolexTudorMonthlyStoreComparison), "any"),
				header_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.convertToTypeByName("Karşılaştırmalı Tudor Şubat Ayı Satış Raporu", "string"), "string"),
				footer_0: ReactSystemFunctions.convertToTypeByName("", "string"),
				columns_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.convertToTypeByName("Merkez,Subat_Yil1,Subat_Yil2,SubatDegisim", "string"), "string")
        }

		KuikaAppManager.showSpinner(this);
		
        if (true) {
        KuikaAppManager.showSpinner(this);
        }
        let result = await KuikaAppManager.ApiRequest(this, "TudorBasedReporting/TudorBasedReportingComponent_580172_onClick", localVar)
        if (!KMainFunctions.IsResStatus2XX(result)) return true;

			stateVars.ExportExcel = result?.data.exportExcel;
			ReactSystemFunctions.downloadFile(result?.data?.exportExcel);
			this.props.form?.setFieldsValue(formVars);
			this.setState(stateVars);
			KuikaAppManager.hideSpinner(this);



        this.setPageInitLoaded(true);
        KuikaAppManager.hideSpinner(this);
        return isErrorOccurred;
    }



    TudorBasedReportingComponent_501744_onClick = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
		KuikaAppManager.increaseServerRequestCount();

        let localVar = {
				value_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, this.state.KuikaY_RolexTudorMonthlyStoreComparison), "any"),
				header_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.convertToTypeByName("Karşılaştırmalı Tudor Mart Ayı Satış Raporu", "string"), "string"),
				footer_0: ReactSystemFunctions.convertToTypeByName("", "string"),
				columns_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.convertToTypeByName("Merkez,Mart_Yil1,Mart_Yil2,MartDegisim", "string"), "string")
        }

		KuikaAppManager.showSpinner(this);
		
        if (true) {
        KuikaAppManager.showSpinner(this);
        }
        let result = await KuikaAppManager.ApiRequest(this, "TudorBasedReporting/TudorBasedReportingComponent_501744_onClick", localVar)
        if (!KMainFunctions.IsResStatus2XX(result)) return true;

			stateVars.ExportExcel = result?.data.exportExcel;
			ReactSystemFunctions.downloadFile(result?.data?.exportExcel);
			this.props.form?.setFieldsValue(formVars);
			this.setState(stateVars);
			KuikaAppManager.hideSpinner(this);



        this.setPageInitLoaded(true);
        KuikaAppManager.hideSpinner(this);
        return isErrorOccurred;
    }



    TudorBasedReportingComponent_276137_onClick = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
		KuikaAppManager.increaseServerRequestCount();

        let localVar = {
				value_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, this.state.KuikaY_RolexTudorMonthlyStoreComparison), "any"),
				header_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.convertToTypeByName("Karşılaştırmalı Tudor Nisan Ayı Satış Raporu", "string"), "string"),
				footer_0: ReactSystemFunctions.convertToTypeByName("", "string"),
				columns_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.convertToTypeByName("Merkez,Nisan_Yil1,Nisan_Yil2,NisanDegisim", "string"), "string")
        }

		KuikaAppManager.showSpinner(this);
		
        if (true) {
        KuikaAppManager.showSpinner(this);
        }
        let result = await KuikaAppManager.ApiRequest(this, "TudorBasedReporting/TudorBasedReportingComponent_276137_onClick", localVar)
        if (!KMainFunctions.IsResStatus2XX(result)) return true;

			stateVars.ExportExcel = result?.data.exportExcel;
			ReactSystemFunctions.downloadFile(result?.data?.exportExcel);
			this.props.form?.setFieldsValue(formVars);
			this.setState(stateVars);
			KuikaAppManager.hideSpinner(this);



        this.setPageInitLoaded(true);
        KuikaAppManager.hideSpinner(this);
        return isErrorOccurred;
    }



    TudorBasedReportingComponent_790775_onClick = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
		KuikaAppManager.increaseServerRequestCount();

        let localVar = {
				value_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, this.state.KuikaY_RolexTudorMonthlyStoreComparison), "any"),
				header_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.convertToTypeByName("Karşılaştırmalı Tudor Mayıs Ayı Satış Raporu", "string"), "string"),
				footer_0: ReactSystemFunctions.convertToTypeByName("", "string"),
				columns_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.convertToTypeByName("Merkez,Mayis_Yil1,Mayis_Yil2,MayisDegisim", "string"), "string")
        }

		KuikaAppManager.showSpinner(this);
		
        if (true) {
        KuikaAppManager.showSpinner(this);
        }
        let result = await KuikaAppManager.ApiRequest(this, "TudorBasedReporting/TudorBasedReportingComponent_790775_onClick", localVar)
        if (!KMainFunctions.IsResStatus2XX(result)) return true;

			stateVars.ExportExcel = result?.data.exportExcel;
			ReactSystemFunctions.downloadFile(result?.data?.exportExcel);
			this.props.form?.setFieldsValue(formVars);
			this.setState(stateVars);
			KuikaAppManager.hideSpinner(this);



        this.setPageInitLoaded(true);
        KuikaAppManager.hideSpinner(this);
        return isErrorOccurred;
    }



    TudorBasedReportingComponent_917522_onClick = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
		KuikaAppManager.increaseServerRequestCount();

        let localVar = {
				value_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, this.state.KuikaY_RolexTudorMonthlyStoreComparison), "any"),
				header_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.convertToTypeByName("Karşılaştırmalı Tudor Haziran Ayı Satış Raporu", "string"), "string"),
				footer_0: ReactSystemFunctions.convertToTypeByName("", "string"),
				columns_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.convertToTypeByName("Merkez,Haziran_Yil1,Haziran_Yil2,HaziranDegisim", "string"), "string")
        }

		KuikaAppManager.showSpinner(this);
		
        if (true) {
        KuikaAppManager.showSpinner(this);
        }
        let result = await KuikaAppManager.ApiRequest(this, "TudorBasedReporting/TudorBasedReportingComponent_917522_onClick", localVar)
        if (!KMainFunctions.IsResStatus2XX(result)) return true;

			stateVars.ExportExcel = result?.data.exportExcel;
			ReactSystemFunctions.downloadFile(result?.data?.exportExcel);
			this.props.form?.setFieldsValue(formVars);
			this.setState(stateVars);
			KuikaAppManager.hideSpinner(this);



        this.setPageInitLoaded(true);
        KuikaAppManager.hideSpinner(this);
        return isErrorOccurred;
    }



    TudorBasedReportingComponent_479425_onClick = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
		KuikaAppManager.increaseServerRequestCount();

        let localVar = {
				value_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, this.state.KuikaY_RolexTudorMonthlyStoreComparison), "any"),
				header_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.convertToTypeByName("Karşılaştırmalı Tudor Temmuz Ayı Satış Raporu", "string"), "string"),
				footer_0: ReactSystemFunctions.convertToTypeByName("", "string"),
				columns_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.convertToTypeByName("Merkez,Temmuz_Yil1,Temmuz_Yil2,TemmuzDegisim", "string"), "string")
        }

		KuikaAppManager.showSpinner(this);
		
        if (true) {
        KuikaAppManager.showSpinner(this);
        }
        let result = await KuikaAppManager.ApiRequest(this, "TudorBasedReporting/TudorBasedReportingComponent_479425_onClick", localVar)
        if (!KMainFunctions.IsResStatus2XX(result)) return true;

			stateVars.ExportExcel = result?.data.exportExcel;
			ReactSystemFunctions.downloadFile(result?.data?.exportExcel);
			this.props.form?.setFieldsValue(formVars);
			this.setState(stateVars);
			KuikaAppManager.hideSpinner(this);



        this.setPageInitLoaded(true);
        KuikaAppManager.hideSpinner(this);
        return isErrorOccurred;
    }



    TudorBasedReportingComponent_684876_onClick = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
		KuikaAppManager.increaseServerRequestCount();

        let localVar = {
				value_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, this.state.KuikaY_RolexTudorMonthlyStoreComparison), "any"),
				header_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.convertToTypeByName("Karşılaştırmalı Tudor Ağustos Ayı Satış Raporu", "string"), "string"),
				footer_0: ReactSystemFunctions.convertToTypeByName("", "string"),
				columns_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.convertToTypeByName("Merkez,Agustos_Yil1,Agustos_Yil2,AgustosDegisim", "string"), "string")
        }

		KuikaAppManager.showSpinner(this);
		
        if (true) {
        KuikaAppManager.showSpinner(this);
        }
        let result = await KuikaAppManager.ApiRequest(this, "TudorBasedReporting/TudorBasedReportingComponent_684876_onClick", localVar)
        if (!KMainFunctions.IsResStatus2XX(result)) return true;

			stateVars.ExportExcel = result?.data.exportExcel;
			ReactSystemFunctions.downloadFile(result?.data?.exportExcel);
			this.props.form?.setFieldsValue(formVars);
			this.setState(stateVars);
			KuikaAppManager.hideSpinner(this);



        this.setPageInitLoaded(true);
        KuikaAppManager.hideSpinner(this);
        return isErrorOccurred;
    }



    TudorBasedReportingComponent_506033_onClick = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
		KuikaAppManager.increaseServerRequestCount();

        let localVar = {
				value_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, this.state.KuikaY_RolexTudorMonthlyStoreComparison), "any"),
				header_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.convertToTypeByName("Karşılaştırmalı Tudor Eylül Ayı Satış Raporu", "string"), "string"),
				footer_0: ReactSystemFunctions.convertToTypeByName("", "string"),
				columns_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.convertToTypeByName("Merkez,Eylul_Yil1,Eylul_Yil2,EylulDegisim", "string"), "string")
        }

		KuikaAppManager.showSpinner(this);
		
        if (true) {
        KuikaAppManager.showSpinner(this);
        }
        let result = await KuikaAppManager.ApiRequest(this, "TudorBasedReporting/TudorBasedReportingComponent_506033_onClick", localVar)
        if (!KMainFunctions.IsResStatus2XX(result)) return true;

			stateVars.ExportExcel = result?.data.exportExcel;
			ReactSystemFunctions.downloadFile(result?.data?.exportExcel);
			this.props.form?.setFieldsValue(formVars);
			this.setState(stateVars);
			KuikaAppManager.hideSpinner(this);



        this.setPageInitLoaded(true);
        KuikaAppManager.hideSpinner(this);
        return isErrorOccurred;
    }



    TudorBasedReportingComponent_262777_onClick = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
		KuikaAppManager.increaseServerRequestCount();

        let localVar = {
				value_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, this.state.KuikaY_RolexTudorMonthlyStoreComparison), "any"),
				header_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.convertToTypeByName("Karşılaştırmalı Tudor Ekim Ayı Satış Raporu", "string"), "string"),
				footer_0: ReactSystemFunctions.convertToTypeByName("", "string"),
				columns_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.convertToTypeByName("Merkez,Ekim_Yil1,Ekim_Yil2,EkimDegisim", "string"), "string")
        }

		KuikaAppManager.showSpinner(this);
		
        if (true) {
        KuikaAppManager.showSpinner(this);
        }
        let result = await KuikaAppManager.ApiRequest(this, "TudorBasedReporting/TudorBasedReportingComponent_262777_onClick", localVar)
        if (!KMainFunctions.IsResStatus2XX(result)) return true;

			stateVars.ExportExcel = result?.data.exportExcel;
			ReactSystemFunctions.downloadFile(result?.data?.exportExcel);
			this.props.form?.setFieldsValue(formVars);
			this.setState(stateVars);
			KuikaAppManager.hideSpinner(this);



        this.setPageInitLoaded(true);
        KuikaAppManager.hideSpinner(this);
        return isErrorOccurred;
    }



    TudorBasedReportingComponent_85753_onClick = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
		KuikaAppManager.increaseServerRequestCount();

        let localVar = {
				value_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, this.state.KuikaY_RolexTudorMonthlyStoreComparison), "any"),
				header_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.convertToTypeByName("Karşılaştırmalı Tudor Kasım Ayı Satış Raporu", "string"), "string"),
				footer_0: ReactSystemFunctions.convertToTypeByName("", "string"),
				columns_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.convertToTypeByName("Merkez,Kasim_Yil1,Kasim_Yil2,KasimDegisim", "string"), "string")
        }

		KuikaAppManager.showSpinner(this);
		
        if (true) {
        KuikaAppManager.showSpinner(this);
        }
        let result = await KuikaAppManager.ApiRequest(this, "TudorBasedReporting/TudorBasedReportingComponent_85753_onClick", localVar)
        if (!KMainFunctions.IsResStatus2XX(result)) return true;

			stateVars.ExportExcel = result?.data.exportExcel;
			ReactSystemFunctions.downloadFile(result?.data?.exportExcel);
			this.props.form?.setFieldsValue(formVars);
			this.setState(stateVars);
			KuikaAppManager.hideSpinner(this);



        this.setPageInitLoaded(true);
        KuikaAppManager.hideSpinner(this);
        return isErrorOccurred;
    }



    TudorBasedReportingComponent_408021_onClick = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
		KuikaAppManager.increaseServerRequestCount();

        let localVar = {
				value_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, this.state.KuikaY_RolexTudorMonthlyStoreComparison), "any"),
				header_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.convertToTypeByName("Karşılaştırmalı Tudor Aralık Ayı Satış Raporu", "string"), "string"),
				footer_0: ReactSystemFunctions.convertToTypeByName("", "string"),
				columns_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.convertToTypeByName("Merkez,Aralik_Yil1,Aralik_Yil2,AralikDegisim", "string"), "string")
        }

		KuikaAppManager.showSpinner(this);
		
        if (true) {
        KuikaAppManager.showSpinner(this);
        }
        let result = await KuikaAppManager.ApiRequest(this, "TudorBasedReporting/TudorBasedReportingComponent_408021_onClick", localVar)
        if (!KMainFunctions.IsResStatus2XX(result)) return true;

			stateVars.ExportExcel = result?.data.exportExcel;
			ReactSystemFunctions.downloadFile(result?.data?.exportExcel);
			this.props.form?.setFieldsValue(formVars);
			this.setState(stateVars);
			KuikaAppManager.hideSpinner(this);



        this.setPageInitLoaded(true);
        KuikaAppManager.hideSpinner(this);
        return isErrorOccurred;
    }



		TudorBasedReportingComponent_174946_onChange = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
KuikaAppManager.showSpinner(this);

				
				ReactSystemFunctions.setValueOf(this, "tudorbasedreporting_864393_toString", ReactSystemFunctions.value(this, "tudorbasedreporting_174946_value", "value"), "value");

				
				ReactSystemFunctions.setValueOf(this, "tudorbasedreporting_719529_toString", ReactSystemFunctions.value(this, "tudorbasedreporting_174946_value", "value"), "value");

				
				ReactSystemFunctions.setValueOf(this, "tudorbasedreporting_732053_toString", ReactSystemFunctions.value(this, "tudorbasedreporting_174946_value", "value"), "value");

				
				ReactSystemFunctions.setValueOf(this, "tudorbasedreporting_386741_toString", ReactSystemFunctions.value(this, "tudorbasedreporting_174946_value", "value"), "value");

				
				ReactSystemFunctions.setValueOf(this, "tudorbasedreporting_824492_toString", ReactSystemFunctions.value(this, "tudorbasedreporting_174946_value", "value"), "value");

				
				ReactSystemFunctions.setValueOf(this, "tudorbasedreporting_731402_toString", ReactSystemFunctions.value(this, "tudorbasedreporting_174946_value", "value"), "value");

				
				ReactSystemFunctions.setValueOf(this, "tudorbasedreporting_983061_toString", ReactSystemFunctions.value(this, "tudorbasedreporting_174946_value", "value"), "value");

				
				ReactSystemFunctions.setValueOf(this, "tudorbasedreporting_657616_toString", ReactSystemFunctions.value(this, "tudorbasedreporting_174946_value", "value"), "value");

				
				ReactSystemFunctions.setValueOf(this, "tudorbasedreporting_571581_toString", ReactSystemFunctions.value(this, "tudorbasedreporting_174946_value", "value"), "value");

				
				ReactSystemFunctions.setValueOf(this, "tudorbasedreporting_46217_toString", ReactSystemFunctions.value(this, "tudorbasedreporting_174946_value", "value"), "value");

				
				ReactSystemFunctions.setValueOf(this, "tudorbasedreporting_305000_toString", ReactSystemFunctions.value(this, "tudorbasedreporting_174946_value", "value"), "value");

				
				ReactSystemFunctions.setValueOf(this, "tudorbasedreporting_168682_toString", ReactSystemFunctions.value(this, "tudorbasedreporting_174946_value", "value"), "value");


		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

            
            return isErrorOccurred;
        }


		TudorBasedReportingComponent_424839_onChange = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
KuikaAppManager.showSpinner(this);

				
				ReactSystemFunctions.setValueOf(this, "tudorbasedreporting_659728_toString", ReactSystemFunctions.value(this, "tudorbasedreporting_424839_value", "value"), "value");

				
				ReactSystemFunctions.setValueOf(this, "tudorbasedreporting_775415_toString", ReactSystemFunctions.value(this, "tudorbasedreporting_424839_value", "value"), "value");

				
				ReactSystemFunctions.setValueOf(this, "tudorbasedreporting_445120_toString", ReactSystemFunctions.value(this, "tudorbasedreporting_424839_value", "value"), "value");

				
				ReactSystemFunctions.setValueOf(this, "tudorbasedreporting_278270_toString", ReactSystemFunctions.value(this, "tudorbasedreporting_424839_value", "value"), "value");

				
				ReactSystemFunctions.setValueOf(this, "tudorbasedreporting_669134_toString", ReactSystemFunctions.value(this, "tudorbasedreporting_424839_value", "value"), "value");

				
				ReactSystemFunctions.setValueOf(this, "tudorbasedreporting_364364_toString", ReactSystemFunctions.value(this, "tudorbasedreporting_424839_value", "value"), "value");

				
				ReactSystemFunctions.setValueOf(this, "tudorbasedreporting_763754_toString", ReactSystemFunctions.value(this, "tudorbasedreporting_424839_value", "value"), "value");

				
				ReactSystemFunctions.setValueOf(this, "tudorbasedreporting_465588_toString", ReactSystemFunctions.value(this, "tudorbasedreporting_424839_value", "value"), "value");

				
				ReactSystemFunctions.setValueOf(this, "tudorbasedreporting_453243_toString", ReactSystemFunctions.value(this, "tudorbasedreporting_424839_value", "value"), "value");

				
				ReactSystemFunctions.setValueOf(this, "tudorbasedreporting_591719_toString", ReactSystemFunctions.value(this, "tudorbasedreporting_424839_value", "value"), "value");

				
				ReactSystemFunctions.setValueOf(this, "tudorbasedreporting_749396_toString", ReactSystemFunctions.value(this, "tudorbasedreporting_424839_value", "value"), "value");

				
				ReactSystemFunctions.setValueOf(this, "tudorbasedreporting_704810_toString", ReactSystemFunctions.value(this, "tudorbasedreporting_424839_value", "value"), "value");


		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

            
            return isErrorOccurred;
        }




    async callCallbackFunction(diId: number, isFromMaster: boolean = false) {
        let isErrorOccurred = false;
		let pageInitCallerNavDiIDs = [, , , ] as number[];
		if (isFromMaster || pageInitCallerNavDiIDs.indexOf(diId) > -1) {
			await this.TudorBasedReportingPageInit();
		}

    }


}
