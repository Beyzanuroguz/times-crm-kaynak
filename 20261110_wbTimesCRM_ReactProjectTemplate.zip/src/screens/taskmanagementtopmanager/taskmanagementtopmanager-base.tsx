import React from "react";
import Axios, { AxiosResponse } from "axios";
import { KuikaAppManager } from "../../shared/utilty/kuika-app-manager";
import { ReactSystemFunctions } from "../../shared/utilty/react-system-functions";
import { KNavigator } from "../../shared/hoc/with-history";
import { KContext } from "../../shared/hoc/with-context";
import { useLocation } from "react-router-dom";
import { FormInstance } from "antd/es/form";
import { Guid } from "guid-typescript";
import Swal from "sweetalert2";
import { KMainFunctions } from "../../shared/utilty/main-functions";
import moment from "moment";
import { IValidationData } from "../../models/dto/validation-data";
import { IStripePayment } from "../../models/dto/stripe-payment";
import { IUserInfoDto } from "../../models/dto/user-info.dto";
import { UserService } from "../../services/user-service";
import { kuikaCoreWasmBridgeService } from "../../services/_singletons";
import _ from "lodash";
import mqtt, { MqttClient } from "mqtt";
import { IMqttResult } from "../../models/dto/mqtt.dto";
import { MasterScreen_ScreenContext } from "../masterscreen/masterscreen-context";

declare let window: any;

export interface ITaskManagementTopManager_ScreenProps {
  navigator: KNavigator;
  form: FormInstance<any>;
  googleLogin: any;
  screenInputs: any;
  context: KContext;
  initialValues: any;
  children: any;
}

export interface ITaskManagementTopManager_ScreenState {
    isSpinnerVisible: boolean;
    isPageVisible: boolean;
	isLeftMenuVisible: boolean;
    spinnerCount: number;
    selectedLanguage: string;
    isPageInitLoaded: false;
    isPageRecurringLoaded: false;
	TM_TopManagerDashboardTaskList: any[];
	TM_TopManagerDashboardTaskList_dummy: any[];
	NAVIGATE: any;
	NAVIGATE_dummy: any;
	isComp1090218096Visible: 'visible' | 'hidden';
	isComp512870594Visible: 'visible' | 'hidden';
	isComp536530811Visible: 'visible' | 'hidden';
	isComp682359701Visible: 'visible' | 'hidden';
	isComp649843446Visible: 'visible' | 'hidden';
	isComp621263863Visible: 'visible' | 'hidden';
	isComp683491532Visible: 'visible' | 'hidden';
	isComp2101484674Visible: 'visible' | 'hidden';
	isComp1198571895Visible: 'visible' | 'hidden';
	isComp496671412Visible: 'visible' | 'hidden';
	isComp1464336833Visible: 'visible' | 'hidden';
	isComp2144457124Visible: 'visible' | 'hidden';
	isComp8354934Visible: 'visible' | 'hidden';
	isComp832318450Visible: 'visible' | 'hidden';
	isComp1214438674Visible: 'visible' | 'hidden';

}

export class TaskManagementTopManager_ScreenBase extends React.PureComponent<ITaskManagementTopManager_ScreenProps, any> {
    static contextType = MasterScreen_ScreenContext;
    declare context: React.ContextType<typeof MasterScreen_ScreenContext>;
	taskmanagementtopmanager_1554162121_value_kuikaSelectBoxRef: React.RefObject<any>;
	taskmanagementtopmanager_1659983565_value_kuikaTableRef: React.RefObject<any>;
    ml=[{"Id":"d5a61d2b-bd60-485f-86e2-661e9ed4e486","Name":"en_US","ShortName":"English","IsDefault":true,"LanguagePhrases":[]},{"Id":"5a264b66-d634-43e0-817e-b8a171c53699","Name":"FixedValues","ShortName":"FixedValues","LanguagePhrases":[{"Id":1736153336,"PropertyName":"value","Value":"Öncelikli Görevlerim"},{"Id":1329412211,"PropertyName":"value","Value":"Günlük operasyon akışında ilk aksiyon gerektiren görevler"},{"Id":604183141,"PropertyName":"value","Value":"Operasyon Tablosu"},{"Id":241148256,"PropertyName":"label","Value":"Talep Ekle"},{"Id":1554162121,"PropertyName":"placeholder","Value":"Görev Seç"},{"Id":560363933,"PropertyName":"title","Value":"Lead No"},{"Id":1523790857,"PropertyName":"value","Value":"[datafield:leadnumarasi]"},{"Id":1735916485,"PropertyName":"title","Value":"Mağaza"},{"Id":1711390022,"PropertyName":"value","Value":"[datafield:storename]"},{"Id":480919717,"PropertyName":"title","Value":"Müşteri"},{"Id":1774461844,"PropertyName":"value","Value":"[datafield:musteri]"},{"Id":1173497336,"PropertyName":"title","Value":"Ürün"},{"Id":148908279,"PropertyName":"value","Value":"[datafield:productname]"},{"Id":613946589,"PropertyName":"title","Value":"Kategori"},{"Id":1090218096,"PropertyName":"value","Value":"[datafield:categoryname]"},{"Id":512870594,"PropertyName":"value","Value":"[datafield:categoryname]"},{"Id":536530811,"PropertyName":"value","Value":"[datafield:categoryname]"},{"Id":682359701,"PropertyName":"value","Value":"[datafield:categoryname]"},{"Id":1928267889,"PropertyName":"title","Value":"Mevcut Durum"},{"Id":649843446,"PropertyName":"value","Value":"[datafield:processname]"},{"Id":621263863,"PropertyName":"value","Value":"[datafield:processname]"},{"Id":683491532,"PropertyName":"value","Value":"[datafield:processname]"},{"Id":2101484674,"PropertyName":"value","Value":"[datafield:processname]"},{"Id":1198571895,"PropertyName":"value","Value":"[datafield:processname]"},{"Id":1525517602,"PropertyName":"title","Value":"Termin Tarihi"},{"Id":1704769424,"PropertyName":"value","Value":"[datafield:termintarihi]"},{"Id":1302637835,"PropertyName":"title","Value":"Görev Tipi"},{"Id":496671412,"PropertyName":"value","Value":"[datafield:tasktitle]"},{"Id":1464336833,"PropertyName":"value","Value":"[datafield:tasktitle]"},{"Id":2144457124,"PropertyName":"value","Value":"[datafield:tasktitle]"},{"Id":8354934,"PropertyName":"value","Value":"[datafield:tasktitle]"},{"Id":832318450,"PropertyName":"value","Value":"[datafield:tasktitle]"},{"Id":1214438674,"PropertyName":"value","Value":"[datafield:tasktitle]"},{"Id":667932408,"PropertyName":"title","Value":"Aksiyon"},{"Id":853762066,"PropertyName":"label","Value":"Detaya Git"}]}]
    defaultML = "en_US"
    
    screenHash = ""
    

    private _prevMasterPageInitLoaded: boolean = false;
    private _prevMasterPageRecurringLoaded: boolean = false;
    private _prevShouldTriggerPageInit: boolean = false;
    constructor(props) {
        super(props);
		this.taskmanagementtopmanager_1554162121_value_kuikaSelectBoxRef = React.createRef();
		this.taskmanagementtopmanager_1659983565_value_kuikaTableRef = React.createRef();

        this.state = {
            isSpinnerVisible: false,
            isPageVisible: false,
            isLeftMenuVisible: false,
            spinnerCount: 0,
            selectedLanguage: "",
            isPageInitLoaded: false,
            isPageRecurringLoaded: false,
            	        TM_TopManagerDashboardTaskList: [],
	        NAVIGATE: "",
	        dataSource_1554162121: [{"key":"1","text":"Onay Bekleyenler"},{"key":"2","text":"Termin Onayı Bekleyenler"},{"key":"3","text":"Teslim Bekleyenler"},{"key":"4","text":"Rezerv Onayı Bekleyenler"},{"key":"5","text":"Rezerv Talebi Bekleyenler"}],
	        isComp1090218096Visible: 'hidden',
	        isComp512870594Visible: 'hidden',
	        isComp536530811Visible: 'hidden',
	        isComp682359701Visible: 'hidden',
	        isComp649843446Visible: 'hidden',
	        isComp621263863Visible: 'hidden',
	        isComp683491532Visible: 'hidden',
	        isComp2101484674Visible: 'hidden',
	        isComp1198571895Visible: 'hidden',
	        isComp496671412Visible: 'hidden',
	        isComp1464336833Visible: 'hidden',
	        isComp2144457124Visible: 'hidden',
	        isComp8354934Visible: 'hidden',
	        isComp832318450Visible: 'hidden',
	        isComp1214438674Visible: 'hidden',

        }

        this.state.isPageVisible = true;
        
    }

    async componentDidMount() {

        if (KuikaAppManager.isPageInitPrevented()) {
            KuikaAppManager.calculateAndSetBodyHeight("taskmanagementtopmanager", "masterscreen_screen");
            return;
        }
        this.context.registerCallbackFunction(this.callCallbackFunction.bind(this));
        
        ReactSystemFunctions.validateToken()
        this.fillFormInitValues();
        if (false){
            await this.TaskManagementTopManagerPageInit();
        } else if (this.context?.isMasterPageInitLoaded) { this._prevMasterPageInitLoaded = true; await this.TaskManagementTopManagerPageInit(); }
        
        
        
        KuikaAppManager.calculateAndSetBodyHeight("taskmanagementtopmanager", "masterscreen_screen");

        if (ReactSystemFunctions.getIsMicroApp() === false) {
           window.parentScreen = this;
        }
    }

    componentWillUnmount() {
        
        
        

        if (ReactSystemFunctions.getIsMicroApp() === false) {
           window.parentScreen = null;
        }
    }

    

        
    componentDidUpdate= async (prevProps, prevState) => {
		KuikaAppManager.calculateAndSetBodyHeight("taskmanagementtopmanager", "masterscreen_screen"    );
        if (prevProps?.location?.search !== (this.props as any)?.location?.search) {
			await this.TaskManagementTopManagerPageInit();
		}

        		if (this._prevMasterPageInitLoaded !== this.context.isMasterPageInitLoaded && this.context.isMasterPageInitLoaded === true) {this._prevMasterPageInitLoaded = this.context.isMasterPageInitLoaded;await this.TaskManagementTopManagerPageInit()}


        if (ReactSystemFunctions.getIsMicroApp() === false) {
            for (const key in prevState) {
                if (key.startsWith('NavVisible') && prevState[key] === true && this.state[key] === false) {
                    window.parentScreen = this;
                    break;
                }
            }
        }
	}

    fillFormInitValues() {
        this.props.form?.setFieldsValue({
});

    }

      setPageInitLoaded = (value: boolean) => {
        this.setState({ isPageInitLoaded: value });
      }

      setPageRecurringLoaded = (value: boolean) => {
        this.setState({ isPageRecurringLoaded: value });
      }

      clearFieldValidation = (changedValues: any) => {
        const fieldName = Object.keys(changedValues)[0];
        if (fieldName) {
          this.props.form?.setFields([
            {
              name: fieldName,
              errors: []
            }
          ]);
        }
      };

      

    TaskManagementTopManagerPageInit = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


	if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }

        let localVar = {
			UserId_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.getMyUserId(), "Guid"),
			TaskTypeFilter_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toInteger(this, ReactSystemFunctions.value(this, "taskmanagementtopmanager_1554162121_value", "value", "", "key", "")), "number")
        }

	KuikaAppManager.showSpinner(this);
	
        if (true) {
        KuikaAppManager.showSpinner(this);
        }
        let result = await KuikaAppManager.ApiRequest(this, "TaskManagementTopManager/TaskManagementTopManagerPageInit", localVar)
        if (!KMainFunctions.IsResStatus2XX(result)) return true;

		stateVars.TM_TopManagerDashboardTaskList = result?.data.tM_TopManagerDashboardTaskList;
		
		this.props.form?.setFieldsValue(formVars);
		
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.TaskManagementTopManagerPageInit1_();
                  resolve();
                });
          })



        
        KuikaAppManager.hideSpinner(this);
        return isErrorOccurred;
    }
	TaskManagementTopManagerPageInit1_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


	if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }

			
			stateVars.dataSource_1659983565 = stateVars.TM_TopManagerDashboardTaskList ?? this.state.TM_TopManagerDashboardTaskList;
			stateVars.isComp1090218096Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, "taskmanagementtopmanager_1659983565_value", "categoryName"), ReactSystemFunctions.convertToTypeByName("Kategori 2", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp512870594Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, "taskmanagementtopmanager_1659983565_value", "categoryName"), ReactSystemFunctions.convertToTypeByName("Kategori 1", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp536530811Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, "taskmanagementtopmanager_1659983565_value", "categoryName"), ReactSystemFunctions.convertToTypeByName("DEFAULT", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp682359701Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, "taskmanagementtopmanager_1659983565_value", "categoryName"), ReactSystemFunctions.convertToTypeByName("Kategori 3", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp649843446Visible = (((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, "taskmanagementtopmanager_1659983565_value", "processCode"), ReactSystemFunctions.convertToTypeByName("PENDING", "string")) || ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, "taskmanagementtopmanager_1659983565_value", "processCode"), ReactSystemFunctions.convertToTypeByName("TERMIN_PENDING", "string")) || ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, "taskmanagementtopmanager_1659983565_value", "processCode"), ReactSystemFunctions.convertToTypeByName("DELIVERY_PENDING", "string")))) === true ? "visible" : "hidden")
			stateVars.isComp621263863Visible = (((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, "taskmanagementtopmanager_1659983565_value", "processCode"), ReactSystemFunctions.convertToTypeByName("CUSTOMER_DECLINED", "string")) || ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, "taskmanagementtopmanager_1659983565_value", "processCode"), ReactSystemFunctions.convertToTypeByName("REJECTED", "string")))) === true ? "visible" : "hidden")
			stateVars.isComp683491532Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, "taskmanagementtopmanager_1659983565_value", "processCode"), ReactSystemFunctions.convertToTypeByName("DELIVERED", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp2101484674Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, "taskmanagementtopmanager_1659983565_value", "processCode"), ReactSystemFunctions.convertToTypeByName("CLOSED", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp1198571895Visible = (((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, "taskmanagementtopmanager_1659983565_value", "processCode"), ReactSystemFunctions.convertToTypeByName("APPROVED", "string")) || ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, "taskmanagementtopmanager_1659983565_value", "processCode"), ReactSystemFunctions.convertToTypeByName("CREATED", "string")))) === true ? "visible" : "hidden")
			stateVars.isComp496671412Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, "taskmanagementtopmanager_1659983565_value", "actionCode"), ReactSystemFunctions.convertToTypeByName("APPROVE_RESERVATION", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp1464336833Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, "taskmanagementtopmanager_1659983565_value", "actionCode"), ReactSystemFunctions.convertToTypeByName("COMPLETE_SALE", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp2144457124Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, "taskmanagementtopmanager_1659983565_value", "actionCode"), ReactSystemFunctions.convertToTypeByName("SET_ESTIMATE", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp8354934Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, "taskmanagementtopmanager_1659983565_value", "actionCode"), ReactSystemFunctions.convertToTypeByName("APPROVE_ESTIMATE", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp832318450Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, "taskmanagementtopmanager_1659983565_value", "actionCode"), ReactSystemFunctions.convertToTypeByName("DIRECT_RESERVE", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp1214438674Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, "taskmanagementtopmanager_1659983565_value", "actionCode"), ReactSystemFunctions.convertToTypeByName("SEND_RESERVATION_REQUEST", "string"))) === true ? "visible" : "hidden")

	this.props.form?.setFieldsValue(formVars);
	this.setState(stateVars);
	KuikaAppManager.hideSpinner(this);

            this.setPageInitLoaded(true);
            return isErrorOccurred;
        }




		TaskManagementTopManagerComponent_241148256_onClick = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
KuikaAppManager.showSpinner(this);

const __currentPath = (window.location.hash ? window.location.hash.replace(/^#/, '').split('?')[0] : window.location.pathname.split('?')[0]).toLowerCase();
if (__currentPath !== "/leadaddtemp") {
  this.context.setMasterPageInitLoaded(false);
  this.context.setMasterPageRecurringLoaded(false);
  this.context.setShouldTriggerPageInit(true);
}
					KuikaAppManager.prepareForNavigation();
						KuikaAppManager.addToPageInputVariables("LeadAddTemp", "CustomerId", ReactSystemFunctions.convertToTypeByName("00000000-0000-0000-0000-000000000000", "Guid"));

				stateVars.NAVIGATE = await ReactSystemFunctions.navigate(this, undefined, "TaskManagementTopManager", "LeadAddTemp", "", "currentPage", null, null, null, null, null, null, true, false);

		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

            
            return isErrorOccurred;
        }


    TaskManagementTopManagerComponent_1554162121_onChange = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
		KuikaAppManager.increaseServerRequestCount();

        let localVar = {
				UserId_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.getMyUserId(), "Guid"),
				TaskTypeFilter_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toInteger(this, ReactSystemFunctions.value(this, "taskmanagementtopmanager_1554162121_value", "value", "", "key", "")), "number")
        }

		KuikaAppManager.showSpinner(this);
		
        if (true) {
        KuikaAppManager.showSpinner(this);
        }
        let result = await KuikaAppManager.ApiRequest(this, "TaskManagementTopManager/TaskManagementTopManagerComponent_1554162121_onChange", localVar)
        if (!KMainFunctions.IsResStatus2XX(result)) return true;

			stateVars.TM_TopManagerDashboardTaskList = result?.data.tM_TopManagerDashboardTaskList;
			
			this.props.form?.setFieldsValue(formVars);
			
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.TaskManagementTopManagerComponent_1554162121_onChange1_();
                  resolve();
                });
          })



        
        KuikaAppManager.hideSpinner(this);
        return isErrorOccurred;
    }
		TaskManagementTopManagerComponent_1554162121_onChange1_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }

				
				stateVars.dataSource_1659983565 = stateVars.TM_TopManagerDashboardTaskList ?? this.state.TM_TopManagerDashboardTaskList;

		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

            
            return isErrorOccurred;
        }




		TaskManagementTopManagerComponent_496671412_onClick = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
KuikaAppManager.showSpinner(this);

					KuikaAppManager.prepareForNavigation();
						KuikaAppManager.addToPageInputVariables("PopRezervOnayBekleyenPopup", "LeadId", ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, "taskmanagementtopmanager_1659983565_value", "leadId"), "Guid"));

				stateVars.NAVIGATE = await ReactSystemFunctions.navigate(this, undefined, "TaskManagementTopManager", "PopRezervOnayBekleyenPopup", "", "7d969ddf-5801-4eb6-b92b-12be35bdd565", "331120399", null, "right", "true", "90%", "100vh", true, false);

		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

            
            return isErrorOccurred;
        }


		TaskManagementTopManagerComponent_1464336833_onClick = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
KuikaAppManager.showSpinner(this);

					KuikaAppManager.prepareForNavigation();
						KuikaAppManager.addToPageInputVariables("TalepSatisIslemi", "LeadId", ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, "taskmanagementtopmanager_1659983565_value", "leadId"), "Guid"));
						KuikaAppManager.addToPageInputVariables("TalepSatisIslemi", "ApprovalId", ReactSystemFunctions.convertToTypeByName(null, "Guid"));
						KuikaAppManager.addToPageInputVariables("TalepSatisIslemi", "SalesLeadDraftId", ReactSystemFunctions.convertToTypeByName(null, "Guid"));

				stateVars.NAVIGATE = await ReactSystemFunctions.navigate(this, undefined, "TaskManagementTopManager", "TalepSatisIslemi", "", "7d969ddf-5801-4eb6-b92b-12be35bdd565", "513773715", null, "right", "true", "90%", "100vh", true, false);

		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

            
            return isErrorOccurred;
        }


		TaskManagementTopManagerComponent_2144457124_onClick = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
KuikaAppManager.showSpinner(this);

					KuikaAppManager.prepareForNavigation();
						KuikaAppManager.addToPageInputVariables("PopOnayBekleyen", "LeadId", ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, "taskmanagementtopmanager_1659983565_value", "leadId"), "Guid"));

				stateVars.NAVIGATE = await ReactSystemFunctions.navigate(this, undefined, "TaskManagementTopManager", "PopOnayBekleyen", "", "7d969ddf-5801-4eb6-b92b-12be35bdd565", "1643251536", null, "right", "true", "90%", "100vh", true, false);

		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

            
            return isErrorOccurred;
        }


		TaskManagementTopManagerComponent_8354934_onClick = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
KuikaAppManager.showSpinner(this);

					KuikaAppManager.prepareForNavigation();
						KuikaAppManager.addToPageInputVariables("PopOnayBekleyen", "LeadId", ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, "taskmanagementtopmanager_1659983565_value", "leadId"), "Guid"));

				stateVars.NAVIGATE = await ReactSystemFunctions.navigate(this, undefined, "TaskManagementTopManager", "PopOnayBekleyen", "", "7d969ddf-5801-4eb6-b92b-12be35bdd565", "896370730", null, "right", "true", "90%", "100vh", true, false);

		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

            
            return isErrorOccurred;
        }


		TaskManagementTopManagerComponent_832318450_onClick = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
KuikaAppManager.showSpinner(this);

					KuikaAppManager.prepareForNavigation();
						KuikaAppManager.addToPageInputVariables("reservationPopUp2", "LeadId", ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, "taskmanagementtopmanager_1659983565_value", "leadId"), "Guid"));

				stateVars.NAVIGATE = await ReactSystemFunctions.navigate(this, undefined, "TaskManagementTopManager", "reservationPopUp2", "", "7d969ddf-5801-4eb6-b92b-12be35bdd565", "269468120", null, "right", "true", "90%", "100vh", true, false);

		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

            
            return isErrorOccurred;
        }


		TaskManagementTopManagerComponent_1214438674_onClick = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
KuikaAppManager.showSpinner(this);

					KuikaAppManager.prepareForNavigation();
						KuikaAppManager.addToPageInputVariables("reservationPopup1", "LeadId", ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, "taskmanagementtopmanager_1659983565_value", "leadId"), "Guid"));

				stateVars.NAVIGATE = await ReactSystemFunctions.navigate(this, undefined, "TaskManagementTopManager", "reservationPopup1", "", "7d969ddf-5801-4eb6-b92b-12be35bdd565", "1166372791", null, "right", "true", "90%", "100vh", true, false);

		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

            
            return isErrorOccurred;
        }


		TaskManagementTopManagerComponent_853762066_onClick = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
KuikaAppManager.showSpinner(this);

					KuikaAppManager.prepareForNavigation();
						KuikaAppManager.addToPageInputVariables("LeadDetailTemp", "LeadId", ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, "taskmanagementtopmanager_1659983565_value", "leadId"), "Guid"));

				stateVars.NAVIGATE = await ReactSystemFunctions.navigate(this, undefined, "TaskManagementTopManager", "LeadDetailTemp", "", "7d969ddf-5801-4eb6-b92b-12be35bdd565", "1773786569", null, "right", "true", "70%", "100vh", true, false);

		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

            
            return isErrorOccurred;
        }


		TaskManagementTopManagerComponent_513773715_onClick = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
KuikaAppManager.showSpinner(this);

					KuikaAppManager.prepareForNavigation();
						KuikaAppManager.addToPageInputVariables("PopOnayBekleyen", "LeadId", ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, "taskmanagementtopmanager_1659983565_value", "leadId"), "Guid"));

				stateVars.NAVIGATE = await ReactSystemFunctions.navigate(this, undefined, "TaskManagementTopManager", "PopOnayBekleyen", "", "7d969ddf-5801-4eb6-b92b-12be35bdd565", "1643251536", null, "right", "true", "90%", "100vh", true, false);

		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

            
            return isErrorOccurred;
        }


		TaskManagementTopManagerComponent_269468120_onClick = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
KuikaAppManager.showSpinner(this);

					KuikaAppManager.prepareForNavigation();
						KuikaAppManager.addToPageInputVariables("reservationPopup1", "LeadId", ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, "taskmanagementtopmanager_1659983565_value", "leadId"), "Guid"));

				stateVars.NAVIGATE = await ReactSystemFunctions.navigate(this, undefined, "TaskManagementTopManager", "reservationPopup1", "", "7d969ddf-5801-4eb6-b92b-12be35bdd565", "1166372791", null, "right", "true", "90%", "100vh", true, false);

		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

            
            return isErrorOccurred;
        }




    async callCallbackFunction(diId: number, isFromMaster: boolean = false) {
        let isErrorOccurred = false;
		let pageInitCallerNavDiIDs = [, 331120399, 513773715, 1643251536, 896370730, 269468120, 1166372791, 1773786569, 1643251536, 1166372791] as number[];
		if (isFromMaster || pageInitCallerNavDiIDs.indexOf(diId) > -1) {
			await this.TaskManagementTopManagerPageInit();
		}

    }


}
