import React from "react";
import Axios, { AxiosResponse } from "axios";
import { KuikaAppManager } from "../../shared/utilty/kuika-app-manager";
import { ReactSystemFunctions } from "../../shared/utilty/react-system-functions";
import { KNavigator } from "../../shared/hoc/with-history";
import { KContext } from "../../shared/hoc/with-context";
import { useLocation } from "react-router-dom";
import { FormInstance } from "antd/es/form";
import { Guid } from "guid-typescript";
import Swal from "sweetalert2";
import { KMainFunctions } from "../../shared/utilty/main-functions";
import moment from "moment";
import { IValidationData } from "../../models/dto/validation-data";
import { IStripePayment } from "../../models/dto/stripe-payment";
import { IUserInfoDto } from "../../models/dto/user-info.dto";
import { UserService } from "../../services/user-service";
import { kuikaCoreWasmBridgeService } from "../../services/_singletons";
import _ from "lodash";
import mqtt, { MqttClient } from "mqtt";
import { IMqttResult } from "../../models/dto/mqtt.dto";


declare let window: any;

export interface ILeadFileDetail_ScreenProps {
  navigator: KNavigator;
  form: FormInstance<any>;
  googleLogin: any;
  screenInputs: any;
  context: KContext;
  initialValues: any;
  children: any;
}

export interface ILeadFileDetail_ScreenState {
    isSpinnerVisible: boolean;
    isPageVisible: boolean;
	isLeftMenuVisible: boolean;
    spinnerCount: number;
    selectedLanguage: string;
    isPageInitLoaded: false;
    isPageRecurringLoaded: false;
	TM_GetLeadFilesByNoteId: any[];
	TM_GetLeadFilesByNoteId_dummy: any[];
	TM_GetLeadNoteFileCounts: any[];
	TM_GetLeadNoteFileCounts_dummy: any[];
	GoBack: any;
	GoBack_dummy: any;
	UploadFile: any[];
	UploadFile_dummy: any[];
	TM_AddLeadFile: any[];
	TM_AddLeadFile_dummy: any[];
	DownloadFile: any;
	DownloadFile_dummy: any;
	TM_DeleteLeadFile: any[];
	TM_DeleteLeadFile_dummy: any[];

}

export class LeadFileDetail_ScreenBase extends React.PureComponent<ILeadFileDetail_ScreenProps, any> {

	leadfiledetail_590249_value_kuikaTableRef: React.RefObject<any>;
    ml=[{"Id":"d5a61d2b-bd60-485f-86e2-661e9ed4e486","Name":"en_US","ShortName":"English","IsDefault":true,"LanguagePhrases":[]},{"Id":"e6e2a7cd-2bb3-4c1c-9eaa-20df614d8d6a","Name":"FixedValues","ShortName":"FixedValues","LanguagePhrases":[{"Id":630561,"PropertyName":"value","Value":"Talep Dosyaları"},{"Id":459730,"PropertyName":"value","Value":"Dosya"},{"Id":479603,"PropertyName":"label","Value":"Dosya Ekle"},{"Id":548924,"PropertyName":"value","Value":"Eklenen Dosyalar"},{"Id":966813,"PropertyName":"title","Value":"Title"},{"Id":164585,"PropertyName":"value","Value":"[datafield:filename]"},{"Id":120906,"PropertyName":"value","Value":"[datafield:createdby]"},{"Id":980512,"PropertyName":"value","Value":"[datafield:createdby]"}]}]
    defaultML = "en_US"
    
    screenHash = ""
    


    constructor(props) {
        super(props);
		this.leadfiledetail_590249_value_kuikaTableRef = React.createRef();

        this.state = {
            isSpinnerVisible: false,
            isPageVisible: false,
            isLeftMenuVisible: false,
            spinnerCount: 0,
            selectedLanguage: "",
            isPageInitLoaded: false,
            isPageRecurringLoaded: false,
            	        TM_GetLeadFilesByNoteId: [],
	        TM_GetLeadNoteFileCounts: [],
	        GoBack: "",
	        UploadFile: [],
	        TM_AddLeadFile: [],
	        DownloadFile: "",
	        TM_DeleteLeadFile: [],

        }

        this.state.isPageVisible = true;
        
    }

    async componentDidMount() {

        if (KuikaAppManager.isPageInitPrevented()) {
            KuikaAppManager.calculateAndSetBodyHeight("leadfiledetail", "");
            return;
        }
        
        
        ReactSystemFunctions.validateToken()
        this.fillFormInitValues();
        if (true){
            await this.LeadFileDetailPageInit();
        }
        
        
        
        KuikaAppManager.calculateAndSetBodyHeight("leadfiledetail", "");

        if (ReactSystemFunctions.getIsMicroApp() === false) {
           window.parentScreen = this;
        }
    }

    componentWillUnmount() {
        
        
        

        if (ReactSystemFunctions.getIsMicroApp() === false) {
           window.parentScreen = null;
        }
    }

    

        
    componentDidUpdate= async (prevProps, prevState) => {
		KuikaAppManager.calculateAndSetBodyHeight("leadfiledetail", ""    );
        if (prevProps?.location?.search !== (this.props as any)?.location?.search) {
			await this.LeadFileDetailPageInit();
		}

        

        if (ReactSystemFunctions.getIsMicroApp() === false) {
            for (const key in prevState) {
                if (key.startsWith('NavVisible') && prevState[key] === true && this.state[key] === false) {
                    window.parentScreen = this;
                    break;
                }
            }
        }
	}

    fillFormInitValues() {
        this.props.form?.setFieldsValue({
});

    }

      setPageInitLoaded = (value: boolean) => {
        this.setState({ isPageInitLoaded: value });
      }

      setPageRecurringLoaded = (value: boolean) => {
        this.setState({ isPageRecurringLoaded: value });
      }

      clearFieldValidation = (changedValues: any) => {
        const fieldName = Object.keys(changedValues)[0];
        if (fieldName) {
          this.props.form?.setFields([
            {
              name: fieldName,
              errors: []
            }
          ]);
        }
      };

      

    LeadFileDetailPageInit = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


	if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }

        let localVar = {
			LeadId_0: ReactSystemFunctions.convertToTypeByName(this.props.screenInputs.LeadId ?? this.props.screenInputs.leadid, "Guid"),
			LeadId_1: ReactSystemFunctions.convertToTypeByName(this.props.screenInputs.LeadId ?? this.props.screenInputs.leadid, "Guid")
        }

	KuikaAppManager.showSpinner(this);
	
        if (true) {
        KuikaAppManager.showSpinner(this);
        }
        let result = await KuikaAppManager.ApiRequest(this, "LeadFileDetail/LeadFileDetailPageInit", localVar)
        if (!KMainFunctions.IsResStatus2XX(result)) return true;

		stateVars.TM_GetLeadFilesByNoteId = result?.data.tM_GetLeadFilesByNoteId;
		
		stateVars.TM_GetLeadNoteFileCounts = result?.data.tM_GetLeadNoteFileCounts;
		formVars.leadfiledetail_990414_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadNoteFileCounts !== undefined ? (stateVars.TM_GetLeadNoteFileCounts?.length > 0 ? stateVars.TM_GetLeadNoteFileCounts[0].fileCount : null) : (this.state.TM_GetLeadNoteFileCounts?.length > 0 ? this.state.TM_GetLeadNoteFileCounts[0].fileCount : null)));
		this.props.form?.setFieldsValue(formVars);
		
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.LeadFileDetailPageInit1_();
                  resolve();
                });
          })



        
        KuikaAppManager.hideSpinner(this);
        return isErrorOccurred;
    }
	LeadFileDetailPageInit1_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


	if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }

			formVars.leadfiledetail_990414_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadNoteFileCounts !== undefined ? (stateVars.TM_GetLeadNoteFileCounts?.length > 0 ? stateVars.TM_GetLeadNoteFileCounts[0].fileCount : null) : (this.state.TM_GetLeadNoteFileCounts?.length > 0 ? this.state.TM_GetLeadNoteFileCounts[0].fileCount : null)));

			
			stateVars.dataSource_590249 = stateVars.TM_GetLeadFilesByNoteId ?? this.state.TM_GetLeadFilesByNoteId;

	this.props.form?.setFieldsValue(formVars);
	this.setState(stateVars);
	KuikaAppManager.hideSpinner(this);

            this.setPageInitLoaded(true);
            return isErrorOccurred;
        }




		LeadFileDetailComponent_104972_onClick = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
KuikaAppManager.showSpinner(this);

				stateVars.GoBack = await ReactSystemFunctions.goBack(this, false);

		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

            
            return isErrorOccurred;
        }


		LeadFileDetailComponent_479603_onClick = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
KuikaAppManager.showSpinner(this);

				stateVars.UploadFile = (await ReactSystemFunctions.uploadFilesWithInfo(ReactSystemFunctions.convertToTypeByName("", "string")) as any).data;

		this.props.form?.setFieldsValue(formVars);
		
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.LeadFileDetailComponent_479603_onClick1_();
                  resolve();
                });
          })

            
            return isErrorOccurred;
        }
    LeadFileDetailComponent_479603_onClick1_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
		KuikaAppManager.increaseServerRequestCount();

        let localVar = {
				LeadId_0: ReactSystemFunctions.convertToTypeByName(this.props.screenInputs.LeadId ?? this.props.screenInputs.leadid, "Guid"),
				CreatedBy_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.getMyUserId(), "Guid"),
				FileData_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, (stateVars.UploadFile !== undefined ? (stateVars.UploadFile?.length > 0 ? stateVars.UploadFile[0].data : null) : (this.state.UploadFile?.length > 0 ? this.state.UploadFile[0].data : null))), "string"),
				FileName_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, (stateVars.UploadFile !== undefined ? (stateVars.UploadFile?.length > 0 ? stateVars.UploadFile[0].name : null) : (this.state.UploadFile?.length > 0 ? this.state.UploadFile[0].name : null))), "string"),
				FileSize_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, (stateVars.UploadFile !== undefined ? (stateVars.UploadFile?.length > 0 ? stateVars.UploadFile[0].size : null) : (this.state.UploadFile?.length > 0 ? this.state.UploadFile[0].size : null))), "number"),
				FileType_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, (stateVars.UploadFile !== undefined ? (stateVars.UploadFile?.length > 0 ? stateVars.UploadFile[0].type : null) : (this.state.UploadFile?.length > 0 ? this.state.UploadFile[0].type : null))), "string"),
				LeadNoteId_0: ReactSystemFunctions.convertToTypeByName(null, "Guid"),
				TRANCOUNT_0: ReactSystemFunctions.convertToTypeByName(0, "number")
        }

		
        if (true) {
        KuikaAppManager.showSpinner(this);
        }
        let result = await KuikaAppManager.ApiRequest(this, "LeadFileDetail/LeadFileDetailComponent_479603_onClick1_", localVar)
        if (!KMainFunctions.IsResStatus2XX(result)) return true;

			stateVars.TM_AddLeadFile = result?.data.tM_AddLeadFile;
			this.props.form?.setFieldsValue(formVars);
			this.setState(stateVars);
			KuikaAppManager.hideSpinner(this);



        this.setPageInitLoaded(true);
        KuikaAppManager.hideSpinner(this);
        return isErrorOccurred;
    }




		LeadFileDetailComponent_230568_onClick = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
KuikaAppManager.showSpinner(this);

				stateVars.DownloadFile = await ReactSystemFunctions.downloadFile(ReactSystemFunctions.value(this, "leadfiledetail_590249_value", "fileData"), ReactSystemFunctions.value(this, "leadfiledetail_590249_value", "fileName"));

		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

            
            return isErrorOccurred;
        }


    LeadFileDetailComponent_929699_onClick = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
		KuikaAppManager.increaseServerRequestCount();

        let localVar = {
				FileId_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, "leadfiledetail_590249_value", "id"), "Guid"),
				TRANCOUNT_0: ReactSystemFunctions.convertToTypeByName(0, "number"),
				LeadId_1: ReactSystemFunctions.convertToTypeByName(this.props.screenInputs.LeadId ?? this.props.screenInputs.leadid, "Guid")
        }

		KuikaAppManager.showSpinner(this);

            stateVars.Confirm = await ReactSystemFunctions.confirmation(
                ReactSystemFunctions.translateCustomActions(this.ml,"952045c6_2518_b132_53a3_ff12bbfde2ae_confirmation",this.defaultML,"Silmek istediğinizden emin misiniz ?" ),
                "poppins",
                "Onay",
                "confirmation",
                "#246dff",
                "",
                ""
            );

            if (stateVars.Confirm)
            {
                		
        if (true) {
        KuikaAppManager.showSpinner(this);
        }
        let result = await KuikaAppManager.ApiRequest(this, "LeadFileDetail/LeadFileDetailComponent_929699_onClick", localVar)
        if (!KMainFunctions.IsResStatus2XX(result)) return true;

			stateVars.TM_DeleteLeadFile = result?.data.tM_DeleteLeadFile;
			stateVars.TM_GetLeadFilesByNoteId = result?.data.tM_GetLeadFilesByNoteId;
			
			this.props.form?.setFieldsValue(formVars);
			
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.LeadFileDetailComponent_929699_onClick1_();
                  resolve();
                });
          })

            }
            else
            {
                KuikaAppManager.hideSpinner(this);
            }


        
        KuikaAppManager.hideSpinner(this);
        return isErrorOccurred;
    }
		LeadFileDetailComponent_929699_onClick1_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }

				
				stateVars.dataSource_590249 = stateVars.TM_GetLeadFilesByNoteId ?? this.state.TM_GetLeadFilesByNoteId;

		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

            
            return isErrorOccurred;
        }






    async callCallbackFunction(diId: number, isFromMaster: boolean = false) {
        let isErrorOccurred = false;
		let pageInitCallerNavDiIDs = [] as number[];
		if (isFromMaster || pageInitCallerNavDiIDs.indexOf(diId) > -1) {
			await this.LeadFileDetailPageInit();
		}

    }


}
