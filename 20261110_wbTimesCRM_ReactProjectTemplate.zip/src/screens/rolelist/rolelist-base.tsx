import React from "react";
import Axios, { AxiosResponse } from "axios";
import { KuikaAppManager } from "../../shared/utilty/kuika-app-manager";
import { ReactSystemFunctions } from "../../shared/utilty/react-system-functions";
import { KNavigator } from "../../shared/hoc/with-history";
import { KContext } from "../../shared/hoc/with-context";
import { useLocation } from "react-router-dom";
import { FormInstance } from "antd/es/form";
import { Guid } from "guid-typescript";
import Swal from "sweetalert2";
import { KMainFunctions } from "../../shared/utilty/main-functions";
import moment from "moment";
import { IValidationData } from "../../models/dto/validation-data";
import { IStripePayment } from "../../models/dto/stripe-payment";
import { IUserInfoDto } from "../../models/dto/user-info.dto";
import { UserService } from "../../services/user-service";
import { kuikaCoreWasmBridgeService } from "../../services/_singletons";
import _ from "lodash";
import mqtt, { MqttClient } from "mqtt";
import { IMqttResult } from "../../models/dto/mqtt.dto";
import { MasterScreen_ScreenContext } from "../masterscreen/masterscreen-context";

declare let window: any;

export interface IRoleList_ScreenProps {
  navigator: KNavigator;
  form: FormInstance<any>;
  googleLogin: any;
  screenInputs: any;
  context: KContext;
  initialValues: any;
  children: any;
}

export interface IRoleList_ScreenState {
    isSpinnerVisible: boolean;
    isPageVisible: boolean;
	isLeftMenuVisible: boolean;
    spinnerCount: number;
    selectedLanguage: string;
    isPageInitLoaded: false;
    isPageRecurringLoaded: false;
	TM_GetTimesRoles: any[];
	TM_GetTimesRoles_dummy: any[];
	NAVIGATE: any;
	NAVIGATE_dummy: any;

}

export class RoleList_ScreenBase extends React.PureComponent<IRoleList_ScreenProps, any> {
    static contextType = MasterScreen_ScreenContext;
    declare context: React.ContextType<typeof MasterScreen_ScreenContext>;
	rolelist_172985_value_kuikaTableRef: React.RefObject<any>;
    ml=[{"Id":"d5a61d2b-bd60-485f-86e2-661e9ed4e486","Name":"en_US","ShortName":"English","IsDefault":true,"LanguagePhrases":[]},{"Id":"d519ef1a-bd1a-462b-907b-0b4d5779a097","Name":"FixedValues","ShortName":"FixedValues","LanguagePhrases":[{"Id":276378,"PropertyName":"value","Value":"Roller"},{"Id":144373,"PropertyName":"value","Value":"Tüm rolleri görüntüleyin ve yönetin"},{"Id":453768,"PropertyName":"value","Value":"Rol Listesi"},{"Id":172692,"PropertyName":"placeholder","Value":"Ara: Rol Adı"},{"Id":622935,"PropertyName":"title","Value":"Rol Adı"},{"Id":457322,"PropertyName":"value","Value":"[datafield:name]"},{"Id":312953,"PropertyName":"label","Value":"Kullanıcılar"}]}]
    defaultML = "en_US"
    
    screenHash = ""
    

    private _prevMasterPageInitLoaded: boolean = false;
    private _prevMasterPageRecurringLoaded: boolean = false;
    private _prevShouldTriggerPageInit: boolean = false;
    constructor(props) {
        super(props);
		this.rolelist_172692_value_kuikaTextInputRef = React.createRef();
		this.rolelist_172985_value_kuikaTableRef = React.createRef();

        this.state = {
            isSpinnerVisible: false,
            isPageVisible: false,
            isLeftMenuVisible: false,
            spinnerCount: 0,
            selectedLanguage: "",
            isPageInitLoaded: false,
            isPageRecurringLoaded: false,
            	        TM_GetTimesRoles: [],
	        NAVIGATE: "",

        }

        this.CheckPageAuthorization(this.state);

        
    }

    async componentDidMount() {

        if (KuikaAppManager.isPageInitPrevented()) {
            KuikaAppManager.calculateAndSetBodyHeight("rolelist", "masterscreen_screen");
            return;
        }
        this.context.registerCallbackFunction(this.callCallbackFunction.bind(this));
        
        ReactSystemFunctions.validateToken()
        this.fillFormInitValues();
        if (false){
            await this.RoleListPageInit();
        } else if (this.context?.isMasterPageInitLoaded) { this._prevMasterPageInitLoaded = true; await this.RoleListPageInit(); }
        
        
        
        KuikaAppManager.calculateAndSetBodyHeight("rolelist", "masterscreen_screen");

        if (ReactSystemFunctions.getIsMicroApp() === false) {
           window.parentScreen = this;
        }
    }

    componentWillUnmount() {
        
        
        

        if (ReactSystemFunctions.getIsMicroApp() === false) {
           window.parentScreen = null;
        }
    }

    
              CheckPageAuthorization = async (state) => {
                KuikaAppManager.showSpinner(this);
                if (_.isEmpty(window.userInfo)) {
                  await UserService.GetUserInfoForce();
                }
                const permittedRoleNames: string[] = ["TimesAdmin",];
                const userInfo = window.userInfo as IUserInfoDto;
                const userRoleNames = userInfo.roles.map((role) => role.name);
                if (!ReactSystemFunctions.hasAnyRoleName(permittedRoleNames, userRoleNames)) {
                  await ReactSystemFunctions.goBack(this);

                  const language = localStorage.getItem("ml");
                  let permissonErrorMessageText = "You do not have permission to access this page.";
                  if (language === "tr_TR") {
                    permissonErrorMessageText = "Bu sayfaya erişim yetkiniz yok.";
                  } else if (language === "fr_FR") {
                    permissonErrorMessageText = "Vous n'avez pas la permission d'accéder à cette page.";
                  } else if (language === "de_DE") {
                    permissonErrorMessageText = "Sie haben keine Berechtigung, auf diese Seite zuzugreifen.";
                  } else if (language === "es_ES") {
                    permissonErrorMessageText = "No tienes permiso para acceder a esta página.";
                  }

                  KMainFunctions.displayErrorNotification(permissonErrorMessageText);
                  state.isPageVisible = false;
                  KuikaAppManager.hideSpinner(this);
                  return;
                }
                state.isPageVisible = true;
                KuikaAppManager.hideSpinner(this);
              };
        

        
    componentDidUpdate= async (prevProps, prevState) => {
		KuikaAppManager.calculateAndSetBodyHeight("rolelist", "masterscreen_screen"    );
        if (prevProps?.location?.search !== (this.props as any)?.location?.search) {
			await this.RoleListPageInit();
		}

        		if (this._prevMasterPageInitLoaded !== this.context.isMasterPageInitLoaded && this.context.isMasterPageInitLoaded === true) {this._prevMasterPageInitLoaded = this.context.isMasterPageInitLoaded;await this.RoleListPageInit()}


        if (ReactSystemFunctions.getIsMicroApp() === false) {
            for (const key in prevState) {
                if (key.startsWith('NavVisible') && prevState[key] === true && this.state[key] === false) {
                    window.parentScreen = this;
                    break;
                }
            }
        }
	}

    fillFormInitValues() {
        this.props.form?.setFieldsValue({
});

    }

      setPageInitLoaded = (value: boolean) => {
        this.setState({ isPageInitLoaded: value });
      }

      setPageRecurringLoaded = (value: boolean) => {
        this.setState({ isPageRecurringLoaded: value });
      }

      clearFieldValidation = (changedValues: any) => {
        const fieldName = Object.keys(changedValues)[0];
        if (fieldName) {
          this.props.form?.setFields([
            {
              name: fieldName,
              errors: []
            }
          ]);
        }
      };

      

    RoleListPageInit = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


	if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }

        let localVar = {
			SearchValue_0: ReactSystemFunctions.convertToTypeByName("", "string")
        }

	KuikaAppManager.showSpinner(this);
	
        if (true) {
        KuikaAppManager.showSpinner(this);
        }
        let result = await KuikaAppManager.ApiRequest(this, "RoleList/RoleListPageInit", localVar)
        if (!KMainFunctions.IsResStatus2XX(result)) return true;

		stateVars.TM_GetTimesRoles = result?.data.tM_GetTimesRoles;
		
		this.props.form?.setFieldsValue(formVars);
		
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.RoleListPageInit1_();
                  resolve();
                });
          })



        
        KuikaAppManager.hideSpinner(this);
        return isErrorOccurred;
    }
	RoleListPageInit1_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


	if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }

			
			stateVars.dataSource_172985 = stateVars.TM_GetTimesRoles ?? this.state.TM_GetTimesRoles;

	this.props.form?.setFieldsValue(formVars);
	this.setState(stateVars);
	KuikaAppManager.hideSpinner(this);

            this.setPageInitLoaded(true);
            return isErrorOccurred;
        }




    RoleListComponent_172692_onChange = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
		KuikaAppManager.increaseServerRequestCount();

        let localVar = {
				SearchValue_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "rolelist_172692_value", "value", "", "", "")), "string")
        }

		KuikaAppManager.showSpinner(this);
		
        if (true) {
        KuikaAppManager.showSpinner(this);
        }
        let result = await KuikaAppManager.ApiRequest(this, "RoleList/RoleListComponent_172692_onChange", localVar)
        if (!KMainFunctions.IsResStatus2XX(result)) return true;

			stateVars.TM_GetTimesRoles = result?.data.tM_GetTimesRoles;
			
			this.props.form?.setFieldsValue(formVars);
			
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.RoleListComponent_172692_onChange1_();
                  resolve();
                });
          })



        
        KuikaAppManager.hideSpinner(this);
        return isErrorOccurred;
    }
		RoleListComponent_172692_onChange1_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }

				
				stateVars.dataSource_172985 = stateVars.TM_GetTimesRoles ?? this.state.TM_GetTimesRoles;

		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

            
            return isErrorOccurred;
        }




		RoleListComponent_312953_onClick = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
KuikaAppManager.showSpinner(this);

					KuikaAppManager.prepareForNavigation();
						KuikaAppManager.addToPageInputVariables("UserRoles", "RoleName", ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, "rolelist_172985_value", "name"), "string"));

				stateVars.NAVIGATE = await ReactSystemFunctions.navigate(this, undefined, "RoleList", "UserRoles", "", "7d969ddf-5801-4eb6-b92b-12be35bdd565", "924282", null, "right", "true", "480px", "100vh", true, false);

		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

            
            return isErrorOccurred;
        }




    async callCallbackFunction(diId: number, isFromMaster: boolean = false) {
        let isErrorOccurred = false;
		let pageInitCallerNavDiIDs = [924282] as number[];
		if (isFromMaster || pageInitCallerNavDiIDs.indexOf(diId) > -1) {
			await this.RoleListPageInit();
		}

    }


}
