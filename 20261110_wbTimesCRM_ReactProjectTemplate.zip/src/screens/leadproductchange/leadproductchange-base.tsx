import React from "react";
import Axios, { AxiosResponse } from "axios";
import { KuikaAppManager } from "../../shared/utilty/kuika-app-manager";
import { ReactSystemFunctions } from "../../shared/utilty/react-system-functions";
import { KNavigator } from "../../shared/hoc/with-history";
import { KContext } from "../../shared/hoc/with-context";
import { useLocation } from "react-router-dom";
import { FormInstance } from "antd/es/form";
import { Guid } from "guid-typescript";
import Swal from "sweetalert2";
import { KMainFunctions } from "../../shared/utilty/main-functions";
import moment from "moment";
import { IValidationData } from "../../models/dto/validation-data";
import { IStripePayment } from "../../models/dto/stripe-payment";
import { IUserInfoDto } from "../../models/dto/user-info.dto";
import { UserService } from "../../services/user-service";
import { kuikaCoreWasmBridgeService } from "../../services/_singletons";
import _ from "lodash";
import mqtt, { MqttClient } from "mqtt";
import { IMqttResult } from "../../models/dto/mqtt.dto";


declare let window: any;

export interface ILeadProductChange_ScreenProps {
  navigator: KNavigator;
  form: FormInstance<any>;
  googleLogin: any;
  screenInputs: any;
  context: KContext;
  initialValues: any;
  children: any;
}

export interface ILeadProductChange_ScreenState {
    isSpinnerVisible: boolean;
    isPageVisible: boolean;
	isLeftMenuVisible: boolean;
    spinnerCount: number;
    selectedLanguage: string;
    isPageInitLoaded: false;
    isPageRecurringLoaded: false;
	TM_GetLeadAlternativeModel: any[];
	TM_GetLeadAlternativeModel_dummy: any[];
	TM_UserRoleByUserId: any[];
	TM_UserRoleByUserId_dummy: any[];
	TM_StoreGetList: any[];
	TM_StoreGetList_dummy: any[];
	TM_GetLeadStatus: any[];
	TM_GetLeadStatus_dummy: any[];
	TM_GetLeadNextSteps: any[];
	TM_GetLeadNextSteps_dummy: any[];
	TM_GetAllContactSource: any[];
	TM_GetAllContactSource_dummy: any[];
	TM_GetLeadDetailUpdate: any[];
	TM_GetLeadDetailUpdate_dummy: any[];
	GetSalesPersonByStore: any[];
	GetSalesPersonByStore_dummy: any[];
	TS_GetStoreUsers: any[];
	TS_GetStoreUsers_dummy: any[];
	GoBack: any;
	GoBack_dummy: any;
	GetAlternativeProductStockByLeadAndProductId: any[];
	GetAlternativeProductStockByLeadAndProductId_dummy: any[];
	GetAltrenativeProductStockInfoByProductId: any[];
	GetAltrenativeProductStockInfoByProductId_dummy: any[];
	ChangeVisibilityOf: string;
	ChangeVisibilityOf_dummy: string;
	TM_LeadProductChangeCheck: any[];
	TM_LeadProductChangeCheck_dummy: any[];
	TM_LeadProductChangeSameReference: any[];
	TM_LeadProductChangeSameReference_dummy: any[];
	Notify: boolean;
	Notify_dummy: boolean;
	TM_CreateLead: any[];
	TM_CreateLead_dummy: any[];
	TM_LeadCloseOnProductChange: any[];
	TM_LeadCloseOnProductChange_dummy: any[];
	isComp597261Visible: 'visible' | 'hidden';
	isComp811509Visible: 'visible' | 'hidden';
	isComp678158Visible: 'visible' | 'hidden';
	isComp492230Visible: 'visible' | 'hidden';
	isComp447712Visible: 'visible' | 'hidden';
	isComp219088Visible: 'visible' | 'hidden';
	isComp883175Visible: 'visible' | 'hidden';
	isComp995040Visible: 'visible' | 'hidden';
	isComp424423Visible: 'visible' | 'hidden';
	isComp290650Visible: 'visible' | 'hidden';
	isComp841777Visible: 'visible' | 'hidden';
	isComp899131Visible: 'visible' | 'hidden';
	isComp426370Visible: 'visible' | 'hidden';
	isComp1807695110Visible: 'visible' | 'hidden';
	isComp526608Visible: 'visible' | 'hidden';
	isComp927855Visible: 'visible' | 'hidden';
	isComp533254Visible: 'visible' | 'hidden';
	isComp83104439Visible: 'visible' | 'hidden';
	isComp1313677025Visible: 'visible' | 'hidden';

}

export class LeadProductChange_ScreenBase extends React.PureComponent<ILeadProductChange_ScreenProps, any> {

	leadproductchange_971012_value_kuikaSelectBoxRef: React.RefObject<any>;
	leadproductchange_597018_value_kuikaTableRef: React.RefObject<any>;
	leadproductchange_783386_value_kuikaAutoCompleteRef: React.RefObject<any>;
	leadproductchange_631367_value_kuikaAutoCompleteRef: React.RefObject<any>;
	leadproductchange_48899_value_kuikaAutoCompleteRef: React.RefObject<any>;
	leadproductchange_28274_value_kuikaAutoCompleteRef: React.RefObject<any>;
	leadproductchange_231791_value_kuikaAutoCompleteRef: React.RefObject<any>;
    ml=[{"Id":"d5a61d2b-bd60-485f-86e2-661e9ed4e486","Name":"en_US","ShortName":"English","IsDefault":true,"LanguagePhrases":[]},{"Id":"eb09fdbb-9d2b-45ed-bbce-e05b05ed8179","Name":"FixedValues","ShortName":"FixedValues","LanguagePhrases":[{"Id":811189,"PropertyName":"value","Value":"Ürün Değiştir & Talebi Kapat"},{"Id":931719,"PropertyName":"value","Value":"Talep kapsamında sunulan alternatif modeller arasından seçim yapılarak ürün değişikliği yapılabilir ve talep kapatılabilir."},{"Id":951421,"PropertyName":"value","Value":"Değiştirilecek Ürün"},{"Id":971012,"PropertyName":"placeholder","Value":"Ürün seçiniz..."},{"Id":976680,"PropertyName":"value","Value":"Mevcut Mağaza ve Mağaza Bazlı Stok Bilgisi"},{"Id":723385,"PropertyName":"value","Value":"Eklenecek Alternatif Ürünün Mağaza Bazlı Stok Bilgisi"},{"Id":962487,"PropertyName":"value","Value":"Ürün Adı"},{"Id":587171,"PropertyName":"value","Value":"Marka"},{"Id":74241,"PropertyName":"value","Value":"Model"},{"Id":902888,"PropertyName":"value","Value":"Kadran"},{"Id":347829,"PropertyName":"value","Value":"Bilezik"},{"Id":840159,"PropertyName":"value","Value":"Stok Durumu"},{"Id":883175,"PropertyName":"value","Value":"Stokta Var"},{"Id":995040,"PropertyName":"value","Value":"Stok Müsait"},{"Id":424423,"PropertyName":"value","Value":"Stokta Yok"},{"Id":290650,"PropertyName":"value","Value":"Stok Müsait Değil"},{"Id":907081,"PropertyName":"value","Value":"Aktif Lead Var mı?"},{"Id":841777,"PropertyName":"value","Value":"Var"},{"Id":899131,"PropertyName":"value","Value":"Yok"},{"Id":145912,"PropertyName":"title","Value":"Mağaza"},{"Id":78467,"PropertyName":"value","Value":"[datafield:storedesc]"},{"Id":193532,"PropertyName":"title","Value":"Toplam Stok"},{"Id":217832,"PropertyName":"value","Value":"[datafield:totalstock]"},{"Id":799474,"PropertyName":"title","Value":"Müsait Stok(Rezerve Edilmemiş)"},{"Id":793882,"PropertyName":"value","Value":"[datafield:availablestock]"},{"Id":272486,"PropertyName":"value","Value":"Yeni talep oluşturulurken mevcut talep bilgileri kullanılacaktır. Düzenlenebilir alanları kontrol ederek gerekli güncellemeleri yapabilirsiniz."},{"Id":1936547524,"PropertyName":"value","Value":"Seçtiğiniz ürün mevcut ürünle aynı referans numarasına sahip; yalnızca kadran ve/veya bilezik farklı. Bu nedenle talep kapatılmayacak, mevcut talep üzerinden devam edilecektir. Talep tarihi, termin tarihi ve rezervasyon durumu olduğu gibi korunur. Talebin süreci değişmez."},{"Id":540879,"PropertyName":"value","Value":"Yeni Talep Bilgileri"},{"Id":922625,"PropertyName":"value","Value":"Açılan Mağaza"},{"Id":783386,"PropertyName":"placeholder","Value":"Açılan Mağazayı Seçiniz..."},{"Id":500587,"PropertyName":"value","Value":"Satış Personeli"},{"Id":631367,"PropertyName":"placeholder","Value":"Satış Personeli Seçiniz..."},{"Id":5322,"PropertyName":"value","Value":"Lead Durumu"},{"Id":48899,"PropertyName":"placeholder","Value":"Lead Durumu"},{"Id":160347,"PropertyName":"value","Value":"Sonraki Adım"},{"Id":28274,"PropertyName":"placeholder","Value":"Sonraki Adım"},{"Id":800828,"PropertyName":"value","Value":"İletişim Kaynağı"},{"Id":231791,"PropertyName":"placeholder","Value":"İletişim Kaynağı Seçiniz"},{"Id":833316,"PropertyName":"value","Value":"Talep Notu"},{"Id":680055,"PropertyName":"placeholder","Value":"Talep Notu"},{"Id":165528,"PropertyName":"label","Value":"Ürünü Değiştir"},{"Id":239273,"PropertyName":"label","Value":"Ürünü Değiştir & Yeni Talep Oluştur"}]}]
    defaultML = "en_US"
    
    screenHash = ""
    


    constructor(props) {
        super(props);
		this.leadproductchange_971012_value_kuikaSelectBoxRef = React.createRef();
		this.leadproductchange_597018_value_kuikaTableRef = React.createRef();
		this.leadproductchange_783386_value_kuikaAutoCompleteRef = React.createRef();
		this.leadproductchange_631367_value_kuikaAutoCompleteRef = React.createRef();
		this.leadproductchange_48899_value_kuikaAutoCompleteRef = React.createRef();
		this.leadproductchange_28274_value_kuikaAutoCompleteRef = React.createRef();
		this.leadproductchange_231791_value_kuikaAutoCompleteRef = React.createRef();

        this.state = {
            isSpinnerVisible: false,
            isPageVisible: false,
            isLeftMenuVisible: false,
            spinnerCount: 0,
            selectedLanguage: "",
            isPageInitLoaded: false,
            isPageRecurringLoaded: false,
            	        TM_GetLeadAlternativeModel: [],
	        TM_UserRoleByUserId: [],
	        TM_StoreGetList: [],
	        TM_GetLeadStatus: [],
	        TM_GetLeadNextSteps: [],
	        TM_GetAllContactSource: [],
	        TM_GetLeadDetailUpdate: [],
	        GetSalesPersonByStore: [],
	        TS_GetStoreUsers: [],
	        GoBack: "",
	        GetAlternativeProductStockByLeadAndProductId: [],
	        GetAltrenativeProductStockInfoByProductId: [],
	        ChangeVisibilityOf: "",
	        TM_LeadProductChangeCheck: [],
	        TM_LeadProductChangeSameReference: [],
	        Notify: false,
	        TM_CreateLead: [],
	        TM_LeadCloseOnProductChange: [],
	        isComp597261Visible: 'hidden',
	        isComp811509Visible: 'hidden',
	        isComp678158Visible: 'hidden',
	        isComp492230Visible: 'hidden',
	        isComp447712Visible: 'hidden',
	        isComp219088Visible: 'hidden',
	        isComp883175Visible: 'hidden',
	        isComp995040Visible: 'hidden',
	        isComp424423Visible: 'hidden',
	        isComp290650Visible: 'hidden',
	        isComp841777Visible: 'hidden',
	        isComp899131Visible: 'hidden',
	        isComp426370Visible: 'hidden',
	        isComp1807695110Visible: 'hidden',
	        isComp526608Visible: 'hidden',
	        isComp927855Visible: 'hidden',
	        isComp533254Visible: 'hidden',
	        isComp83104439Visible: 'hidden',
	        isComp1313677025Visible: 'hidden',

        }

        this.state.isPageVisible = true;
        
    }

    async componentDidMount() {

        if (KuikaAppManager.isPageInitPrevented()) {
            KuikaAppManager.calculateAndSetBodyHeight("leadproductchange", "");
            return;
        }
        
        
        ReactSystemFunctions.validateToken()
        this.fillFormInitValues();
        if (true){
            await this.LeadProductChangePageInit();
        }
        
        
        
        KuikaAppManager.calculateAndSetBodyHeight("leadproductchange", "");

        if (ReactSystemFunctions.getIsMicroApp() === false) {
           window.parentScreen = this;
        }
    }

    componentWillUnmount() {
        
        
        

        if (ReactSystemFunctions.getIsMicroApp() === false) {
           window.parentScreen = null;
        }
    }

    

        
    componentDidUpdate= async (prevProps, prevState) => {
		KuikaAppManager.calculateAndSetBodyHeight("leadproductchange", ""    );
        if (prevProps?.location?.search !== (this.props as any)?.location?.search) {
			await this.LeadProductChangePageInit();
		}

        

        if (ReactSystemFunctions.getIsMicroApp() === false) {
            for (const key in prevState) {
                if (key.startsWith('NavVisible') && prevState[key] === true && this.state[key] === false) {
                    window.parentScreen = this;
                    break;
                }
            }
        }
	}

    fillFormInitValues() {
        this.props.form?.setFieldsValue({
leadproductchange_783386_value: this.state.TM_GetLeadDetailUpdate?.at?.(0)?.storeId ?? undefined,
leadproductchange_631367_value: this.state.TM_GetLeadDetailUpdate?.at?.(0)?.salesPersonKUserId ?? undefined,
leadproductchange_48899_value: this.state.TM_GetLeadDetailUpdate?.at?.(0)?.statuId ?? undefined,
leadproductchange_28274_value: this.state.TM_GetLeadDetailUpdate?.at?.(0)?.nextStepId ?? undefined,
leadproductchange_231791_value: this.state.TM_GetLeadDetailUpdate?.at?.(0)?.contactResourceId ?? undefined,
leadproductchange_680055_value: this.state.TM_GetLeadDetailUpdate?.at?.(0)?.talepNotu ?? undefined
});

    }

      setPageInitLoaded = (value: boolean) => {
        this.setState({ isPageInitLoaded: value });
      }

      setPageRecurringLoaded = (value: boolean) => {
        this.setState({ isPageRecurringLoaded: value });
      }

      clearFieldValidation = (changedValues: any) => {
        const fieldName = Object.keys(changedValues)[0];
        if (fieldName) {
          this.props.form?.setFields([
            {
              name: fieldName,
              errors: []
            }
          ]);
        }
      };

      

    LeadProductChangePageInit = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


	if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }

        let localVar = {
			LeadId_0: ReactSystemFunctions.convertToTypeByName(this.props.screenInputs.LeadId ?? this.props.screenInputs.leadid, "Guid"),
			UserID_1: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.getMyUserId(), "Guid"),
			LeadId_6: ReactSystemFunctions.convertToTypeByName(this.props.screenInputs.LeadId ?? this.props.screenInputs.leadid, "Guid"),
			StoreId_7: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, (stateVars.TM_GetLeadDetailUpdate !== undefined ? (stateVars.TM_GetLeadDetailUpdate?.length > 0 ? stateVars.TM_GetLeadDetailUpdate[0].storeId : null) : (this.state.TM_GetLeadDetailUpdate?.length > 0 ? this.state.TM_GetLeadDetailUpdate[0].storeId : null))), "Guid"),
			KUserId_8: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, (stateVars.TM_GetLeadDetailUpdate !== undefined ? (stateVars.TM_GetLeadDetailUpdate?.length > 0 ? stateVars.TM_GetLeadDetailUpdate[0].salesPersonKUserId : null) : (this.state.TM_GetLeadDetailUpdate?.length > 0 ? this.state.TM_GetLeadDetailUpdate[0].salesPersonKUserId : null))), "Guid")
        }

	KuikaAppManager.showSpinner(this);
	
        if (true) {
        KuikaAppManager.showSpinner(this);
        }
        let result = await KuikaAppManager.ApiRequest(this, "LeadProductChange/LeadProductChangePageInit", localVar)
        if (!KMainFunctions.IsResStatus2XX(result)) return true;

		stateVars.TM_GetLeadAlternativeModel = result?.data.tM_GetLeadAlternativeModel;
		
		formVars.leadproductchange_971012_options = stateVars.TM_GetLeadAlternativeModel;
		stateVars.TM_UserRoleByUserId = result?.data.tM_UserRoleByUserId;
		stateVars.TM_StoreGetList = result?.data.tM_StoreGetList;
		
		formVars.leadproductchange_783386_value = (stateVars.TM_GetLeadDetailUpdate !== undefined ? (stateVars.TM_GetLeadDetailUpdate?.length > 0 ? stateVars.TM_GetLeadDetailUpdate[0].storeId : null) : (this.state.TM_GetLeadDetailUpdate?.length > 0 ? this.state.TM_GetLeadDetailUpdate[0].storeId : null));
		formVars.leadproductchange_783386_options = stateVars.TM_StoreGetList;
		stateVars.TM_GetLeadStatus = result?.data.tM_GetLeadStatus;
		
		formVars.leadproductchange_48899_value = (stateVars.TM_GetLeadDetailUpdate !== undefined ? (stateVars.TM_GetLeadDetailUpdate?.length > 0 ? stateVars.TM_GetLeadDetailUpdate[0].statuId : null) : (this.state.TM_GetLeadDetailUpdate?.length > 0 ? this.state.TM_GetLeadDetailUpdate[0].statuId : null));
		formVars.leadproductchange_48899_options = stateVars.TM_GetLeadStatus;
		stateVars.TM_GetLeadNextSteps = result?.data.tM_GetLeadNextSteps;
		
		formVars.leadproductchange_28274_value = (stateVars.TM_GetLeadDetailUpdate !== undefined ? (stateVars.TM_GetLeadDetailUpdate?.length > 0 ? stateVars.TM_GetLeadDetailUpdate[0].nextStepId : null) : (this.state.TM_GetLeadDetailUpdate?.length > 0 ? this.state.TM_GetLeadDetailUpdate[0].nextStepId : null));
		formVars.leadproductchange_28274_options = stateVars.TM_GetLeadNextSteps;
		stateVars.TM_GetAllContactSource = result?.data.tM_GetAllContactSource;
		
		formVars.leadproductchange_231791_value = (stateVars.TM_GetLeadDetailUpdate !== undefined ? (stateVars.TM_GetLeadDetailUpdate?.length > 0 ? stateVars.TM_GetLeadDetailUpdate[0].contactResourceId : null) : (this.state.TM_GetLeadDetailUpdate?.length > 0 ? this.state.TM_GetLeadDetailUpdate[0].contactResourceId : null));
		formVars.leadproductchange_231791_options = stateVars.TM_GetAllContactSource;
		stateVars.TM_GetLeadDetailUpdate = result?.data.tM_GetLeadDetailUpdate;
		formVars.leadproductchange_783386_value = (stateVars.TM_GetLeadDetailUpdate !== undefined ? (stateVars.TM_GetLeadDetailUpdate?.length > 0 ? stateVars.TM_GetLeadDetailUpdate[0].storeId : null) : (this.state.TM_GetLeadDetailUpdate?.length > 0 ? this.state.TM_GetLeadDetailUpdate[0].storeId : null));
		formVars.leadproductchange_783386_options = stateVars.TM_StoreGetList;
		formVars.leadproductchange_631367_value = (stateVars.TM_GetLeadDetailUpdate !== undefined ? (stateVars.TM_GetLeadDetailUpdate?.length > 0 ? stateVars.TM_GetLeadDetailUpdate[0].salesPersonKUserId : null) : (this.state.TM_GetLeadDetailUpdate?.length > 0 ? this.state.TM_GetLeadDetailUpdate[0].salesPersonKUserId : null));
		formVars.leadproductchange_631367_options = stateVars.GetSalesPersonByStore;
		formVars.leadproductchange_48899_value = (stateVars.TM_GetLeadDetailUpdate !== undefined ? (stateVars.TM_GetLeadDetailUpdate?.length > 0 ? stateVars.TM_GetLeadDetailUpdate[0].statuId : null) : (this.state.TM_GetLeadDetailUpdate?.length > 0 ? this.state.TM_GetLeadDetailUpdate[0].statuId : null));
		formVars.leadproductchange_48899_options = stateVars.TM_GetLeadStatus;
		formVars.leadproductchange_28274_value = (stateVars.TM_GetLeadDetailUpdate !== undefined ? (stateVars.TM_GetLeadDetailUpdate?.length > 0 ? stateVars.TM_GetLeadDetailUpdate[0].nextStepId : null) : (this.state.TM_GetLeadDetailUpdate?.length > 0 ? this.state.TM_GetLeadDetailUpdate[0].nextStepId : null));
		formVars.leadproductchange_28274_options = stateVars.TM_GetLeadNextSteps;
		formVars.leadproductchange_231791_value = (stateVars.TM_GetLeadDetailUpdate !== undefined ? (stateVars.TM_GetLeadDetailUpdate?.length > 0 ? stateVars.TM_GetLeadDetailUpdate[0].contactResourceId : null) : (this.state.TM_GetLeadDetailUpdate?.length > 0 ? this.state.TM_GetLeadDetailUpdate[0].contactResourceId : null));
		formVars.leadproductchange_231791_options = stateVars.TM_GetAllContactSource;
		formVars.leadproductchange_680055_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadDetailUpdate !== undefined ? (stateVars.TM_GetLeadDetailUpdate?.length > 0 ? stateVars.TM_GetLeadDetailUpdate[0].talepNotu : null) : (this.state.TM_GetLeadDetailUpdate?.length > 0 ? this.state.TM_GetLeadDetailUpdate[0].talepNotu : null)));
		stateVars.GetSalesPersonByStore = result?.data.getSalesPersonByStore;
		
		formVars.leadproductchange_631367_value = (stateVars.TM_GetLeadDetailUpdate !== undefined ? (stateVars.TM_GetLeadDetailUpdate?.length > 0 ? stateVars.TM_GetLeadDetailUpdate[0].salesPersonKUserId : null) : (this.state.TM_GetLeadDetailUpdate?.length > 0 ? this.state.TM_GetLeadDetailUpdate[0].salesPersonKUserId : null));
		formVars.leadproductchange_631367_options = stateVars.GetSalesPersonByStore;
		stateVars.TS_GetStoreUsers = result?.data.tS_GetStoreUsers;
		this.props.form?.setFieldsValue(formVars);
		
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.LeadProductChangePageInit1_();
                  resolve();
                });
          })



        
        KuikaAppManager.hideSpinner(this);
        return isErrorOccurred;
    }
	LeadProductChangePageInit1_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


	if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }

			
			stateVars.dataSource_971012 = stateVars.TM_GetLeadAlternativeModel ?? this.state.TM_GetLeadAlternativeModel;
			stateVars.dataSource_971012 = stateVars.TM_GetLeadAlternativeModel ?? this.state.TM_GetLeadAlternativeModel;
			stateVars.isComp811509Visible = ((ReactSystemFunctions.isNotEmpty(ReactSystemFunctions.value(this, (stateVars.GetAlternativeProductStockByLeadAndProductId !== undefined ? (stateVars.GetAlternativeProductStockByLeadAndProductId?.length > 0 ? stateVars.GetAlternativeProductStockByLeadAndProductId[0].productId : null) : (this.state.GetAlternativeProductStockByLeadAndProductId?.length > 0 ? this.state.GetAlternativeProductStockByLeadAndProductId[0].productId : null))), ReactSystemFunctions.convertToTypeByName("True", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp678158Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.toString(this, (stateVars.GetAlternativeProductStockByLeadAndProductId !== undefined ? (stateVars.GetAlternativeProductStockByLeadAndProductId?.length > 0 ? stateVars.GetAlternativeProductStockByLeadAndProductId[0].categoryName : null) : (this.state.GetAlternativeProductStockByLeadAndProductId?.length > 0 ? this.state.GetAlternativeProductStockByLeadAndProductId[0].categoryName : null))), ReactSystemFunctions.convertToTypeByName("Kategori 2", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp492230Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.toString(this, (stateVars.GetAlternativeProductStockByLeadAndProductId !== undefined ? (stateVars.GetAlternativeProductStockByLeadAndProductId?.length > 0 ? stateVars.GetAlternativeProductStockByLeadAndProductId[0].categoryName : null) : (this.state.GetAlternativeProductStockByLeadAndProductId?.length > 0 ? this.state.GetAlternativeProductStockByLeadAndProductId[0].categoryName : null))), ReactSystemFunctions.convertToTypeByName("Kategori 1", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp447712Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.toString(this, (stateVars.GetAlternativeProductStockByLeadAndProductId !== undefined ? (stateVars.GetAlternativeProductStockByLeadAndProductId?.length > 0 ? stateVars.GetAlternativeProductStockByLeadAndProductId[0].categoryName : null) : (this.state.GetAlternativeProductStockByLeadAndProductId?.length > 0 ? this.state.GetAlternativeProductStockByLeadAndProductId[0].categoryName : null))), ReactSystemFunctions.convertToTypeByName("DEFAULT", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp219088Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.toString(this, (stateVars.GetAlternativeProductStockByLeadAndProductId !== undefined ? (stateVars.GetAlternativeProductStockByLeadAndProductId?.length > 0 ? stateVars.GetAlternativeProductStockByLeadAndProductId[0].categoryName : null) : (this.state.GetAlternativeProductStockByLeadAndProductId?.length > 0 ? this.state.GetAlternativeProductStockByLeadAndProductId[0].categoryName : null))), ReactSystemFunctions.convertToTypeByName("Kategori 3", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp883175Visible = ((ReactSystemFunctions.isGreaterThan(ReactSystemFunctions.value(this, (stateVars.GetAlternativeProductStockByLeadAndProductId !== undefined ? (stateVars.GetAlternativeProductStockByLeadAndProductId?.length > 0 ? stateVars.GetAlternativeProductStockByLeadAndProductId[0].totalStock : null) : (this.state.GetAlternativeProductStockByLeadAndProductId?.length > 0 ? this.state.GetAlternativeProductStockByLeadAndProductId[0].totalStock : null))), ReactSystemFunctions.convertToTypeByName("0", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp995040Visible = ((ReactSystemFunctions.isGreaterThan(ReactSystemFunctions.value(this, (stateVars.GetAlternativeProductStockByLeadAndProductId !== undefined ? (stateVars.GetAlternativeProductStockByLeadAndProductId?.length > 0 ? stateVars.GetAlternativeProductStockByLeadAndProductId[0].availableStock : null) : (this.state.GetAlternativeProductStockByLeadAndProductId?.length > 0 ? this.state.GetAlternativeProductStockByLeadAndProductId[0].availableStock : null))), ReactSystemFunctions.convertToTypeByName("0", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp424423Visible = ((ReactSystemFunctions.isLessThan(ReactSystemFunctions.value(this, (stateVars.GetAlternativeProductStockByLeadAndProductId !== undefined ? (stateVars.GetAlternativeProductStockByLeadAndProductId?.length > 0 ? stateVars.GetAlternativeProductStockByLeadAndProductId[0].totalStock : null) : (this.state.GetAlternativeProductStockByLeadAndProductId?.length > 0 ? this.state.GetAlternativeProductStockByLeadAndProductId[0].totalStock : null))), ReactSystemFunctions.convertToTypeByName("1", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp290650Visible = ((ReactSystemFunctions.isLessThan(ReactSystemFunctions.value(this, (stateVars.GetAlternativeProductStockByLeadAndProductId !== undefined ? (stateVars.GetAlternativeProductStockByLeadAndProductId?.length > 0 ? stateVars.GetAlternativeProductStockByLeadAndProductId[0].availableStock : null) : (this.state.GetAlternativeProductStockByLeadAndProductId?.length > 0 ? this.state.GetAlternativeProductStockByLeadAndProductId[0].availableStock : null))), ReactSystemFunctions.convertToTypeByName("1", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp841777Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, (stateVars.GetAlternativeProductStockByLeadAndProductId !== undefined ? (stateVars.GetAlternativeProductStockByLeadAndProductId?.length > 0 ? stateVars.GetAlternativeProductStockByLeadAndProductId[0].hasActiveLead : null) : (this.state.GetAlternativeProductStockByLeadAndProductId?.length > 0 ? this.state.GetAlternativeProductStockByLeadAndProductId[0].hasActiveLead : null))), ReactSystemFunctions.convertToTypeByName("True", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp899131Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, (stateVars.GetAlternativeProductStockByLeadAndProductId !== undefined ? (stateVars.GetAlternativeProductStockByLeadAndProductId?.length > 0 ? stateVars.GetAlternativeProductStockByLeadAndProductId[0].hasActiveLead : null) : (this.state.GetAlternativeProductStockByLeadAndProductId?.length > 0 ? this.state.GetAlternativeProductStockByLeadAndProductId[0].hasActiveLead : null))), ReactSystemFunctions.convertToTypeByName("False", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp426370Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, (stateVars.TM_LeadProductChangeCheck !== undefined ? (stateVars.TM_LeadProductChangeCheck?.length > 0 ? stateVars.TM_LeadProductChangeCheck[0].isSameReference : null) : (this.state.TM_LeadProductChangeCheck?.length > 0 ? this.state.TM_LeadProductChangeCheck[0].isSameReference : null))), ReactSystemFunctions.convertToTypeByName("False", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp1807695110Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, (stateVars.TM_LeadProductChangeCheck !== undefined ? (stateVars.TM_LeadProductChangeCheck?.length > 0 ? stateVars.TM_LeadProductChangeCheck[0].isSameReference : null) : (this.state.TM_LeadProductChangeCheck?.length > 0 ? this.state.TM_LeadProductChangeCheck[0].isSameReference : null))), ReactSystemFunctions.convertToTypeByName("True", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp526608Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, (stateVars.TM_LeadProductChangeCheck !== undefined ? (stateVars.TM_LeadProductChangeCheck?.length > 0 ? stateVars.TM_LeadProductChangeCheck[0].isSameReference : null) : (this.state.TM_LeadProductChangeCheck?.length > 0 ? this.state.TM_LeadProductChangeCheck[0].isSameReference : null))), ReactSystemFunctions.convertToTypeByName("False", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp927855Visible = (((ReactSystemFunctions.contains(ReactSystemFunctions.getMyRoleNames(), ReactSystemFunctions.convertToTypeByName("TimesUstYonetici", "string")) || ReactSystemFunctions.contains(ReactSystemFunctions.getMyRoleNames(), ReactSystemFunctions.convertToTypeByName("TimesYonetici", "string")))) === true ? "visible" : "hidden")
			formVars.leadproductchange_783386_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadDetailUpdate !== undefined ? (stateVars.TM_GetLeadDetailUpdate?.length > 0 ? stateVars.TM_GetLeadDetailUpdate[0].storeId : null) : (this.state.TM_GetLeadDetailUpdate?.length > 0 ? this.state.TM_GetLeadDetailUpdate[0].storeId : null)));

			
			stateVars.dataSource_783386 = stateVars.TM_StoreGetList ?? this.state.TM_StoreGetList;
			stateVars.dataSource_783386 = stateVars.TM_StoreGetList ?? this.state.TM_StoreGetList;
			stateVars.isComp533254Visible = (((ReactSystemFunctions.contains(ReactSystemFunctions.getMyRoleNames(), ReactSystemFunctions.convertToTypeByName("TimesMagazaMuduru", "string")) || ReactSystemFunctions.contains(ReactSystemFunctions.getMyRoleNames(), ReactSystemFunctions.convertToTypeByName("TimesUstYonetici", "string")))) === true ? "visible" : "hidden")
			formVars.leadproductchange_631367_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadDetailUpdate !== undefined ? (stateVars.TM_GetLeadDetailUpdate?.length > 0 ? stateVars.TM_GetLeadDetailUpdate[0].salesPersonKUserId : null) : (this.state.TM_GetLeadDetailUpdate?.length > 0 ? this.state.TM_GetLeadDetailUpdate[0].salesPersonKUserId : null)));

			
			stateVars.dataSource_631367 = stateVars.GetSalesPersonByStore ?? this.state.GetSalesPersonByStore;
			stateVars.dataSource_631367 = stateVars.GetSalesPersonByStore ?? this.state.GetSalesPersonByStore;
			formVars.leadproductchange_48899_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadDetailUpdate !== undefined ? (stateVars.TM_GetLeadDetailUpdate?.length > 0 ? stateVars.TM_GetLeadDetailUpdate[0].statuId : null) : (this.state.TM_GetLeadDetailUpdate?.length > 0 ? this.state.TM_GetLeadDetailUpdate[0].statuId : null)));

			
			stateVars.dataSource_48899 = stateVars.TM_GetLeadStatus ?? this.state.TM_GetLeadStatus;
			stateVars.dataSource_48899 = stateVars.TM_GetLeadStatus ?? this.state.TM_GetLeadStatus;
			formVars.leadproductchange_28274_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadDetailUpdate !== undefined ? (stateVars.TM_GetLeadDetailUpdate?.length > 0 ? stateVars.TM_GetLeadDetailUpdate[0].nextStepId : null) : (this.state.TM_GetLeadDetailUpdate?.length > 0 ? this.state.TM_GetLeadDetailUpdate[0].nextStepId : null)));

			
			stateVars.dataSource_28274 = stateVars.TM_GetLeadNextSteps ?? this.state.TM_GetLeadNextSteps;
			stateVars.dataSource_28274 = stateVars.TM_GetLeadNextSteps ?? this.state.TM_GetLeadNextSteps;
			formVars.leadproductchange_231791_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadDetailUpdate !== undefined ? (stateVars.TM_GetLeadDetailUpdate?.length > 0 ? stateVars.TM_GetLeadDetailUpdate[0].contactResourceId : null) : (this.state.TM_GetLeadDetailUpdate?.length > 0 ? this.state.TM_GetLeadDetailUpdate[0].contactResourceId : null)));

			
			stateVars.dataSource_231791 = stateVars.TM_GetAllContactSource ?? this.state.TM_GetAllContactSource;
			stateVars.dataSource_231791 = stateVars.TM_GetAllContactSource ?? this.state.TM_GetAllContactSource;
			formVars.leadproductchange_680055_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadDetailUpdate !== undefined ? (stateVars.TM_GetLeadDetailUpdate?.length > 0 ? stateVars.TM_GetLeadDetailUpdate[0].talepNotu : null) : (this.state.TM_GetLeadDetailUpdate?.length > 0 ? this.state.TM_GetLeadDetailUpdate[0].talepNotu : null)));

			stateVars.isComp83104439Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, (stateVars.TM_LeadProductChangeCheck !== undefined ? (stateVars.TM_LeadProductChangeCheck?.length > 0 ? stateVars.TM_LeadProductChangeCheck[0].isSameReference : null) : (this.state.TM_LeadProductChangeCheck?.length > 0 ? this.state.TM_LeadProductChangeCheck[0].isSameReference : null))), ReactSystemFunctions.convertToTypeByName("True", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp1313677025Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, (stateVars.TM_LeadProductChangeCheck !== undefined ? (stateVars.TM_LeadProductChangeCheck?.length > 0 ? stateVars.TM_LeadProductChangeCheck[0].isSameReference : null) : (this.state.TM_LeadProductChangeCheck?.length > 0 ? this.state.TM_LeadProductChangeCheck[0].isSameReference : null))), ReactSystemFunctions.convertToTypeByName("False", "string"))) === true ? "visible" : "hidden")

	this.props.form?.setFieldsValue(formVars);
	this.setState(stateVars);
	KuikaAppManager.hideSpinner(this);

            this.setPageInitLoaded(true);
            return isErrorOccurred;
        }




		LeadProductChangeComponent_315283_onClick = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
KuikaAppManager.showSpinner(this);

				stateVars.GoBack = await ReactSystemFunctions.goBack(this, false);

		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

            
            return isErrorOccurred;
        }


    LeadProductChangeComponent_971012_onChange = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
		KuikaAppManager.increaseServerRequestCount();

        let localVar = {
				LeadId_0: ReactSystemFunctions.convertToTypeByName(this.props.screenInputs.LeadId ?? this.props.screenInputs.leadid, "Guid"),
				LeadId_1: ReactSystemFunctions.convertToTypeByName(this.props.screenInputs.LeadId ?? this.props.screenInputs.leadid, "Guid"),
				ProductId_1: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "leadproductchange_971012_value", "value", "TM_GetLeadAlternativeModel", "productId", "productId")), "Guid"),
				ProductId_2: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "leadproductchange_971012_value", "value", "TM_GetLeadAlternativeModel", "productId", "productId")), "Guid")
        }

		KuikaAppManager.showSpinner(this);
		
        if (true) {
        KuikaAppManager.showSpinner(this);
        }
        let result = await KuikaAppManager.ApiRequest(this, "LeadProductChange/LeadProductChangeComponent_971012_onChange", localVar)
        if (!KMainFunctions.IsResStatus2XX(result)) return true;

			stateVars.TM_GetLeadDetailUpdate = result?.data.tM_GetLeadDetailUpdate;
			formVars.leadproductchange_783386_value = (stateVars.TM_GetLeadDetailUpdate !== undefined ? (stateVars.TM_GetLeadDetailUpdate?.length > 0 ? stateVars.TM_GetLeadDetailUpdate[0].storeId : null) : (this.state.TM_GetLeadDetailUpdate?.length > 0 ? this.state.TM_GetLeadDetailUpdate[0].storeId : null));
			formVars.leadproductchange_631367_value = (stateVars.TM_GetLeadDetailUpdate !== undefined ? (stateVars.TM_GetLeadDetailUpdate?.length > 0 ? stateVars.TM_GetLeadDetailUpdate[0].salesPersonKUserId : null) : (this.state.TM_GetLeadDetailUpdate?.length > 0 ? this.state.TM_GetLeadDetailUpdate[0].salesPersonKUserId : null));
			formVars.leadproductchange_48899_value = (stateVars.TM_GetLeadDetailUpdate !== undefined ? (stateVars.TM_GetLeadDetailUpdate?.length > 0 ? stateVars.TM_GetLeadDetailUpdate[0].statuId : null) : (this.state.TM_GetLeadDetailUpdate?.length > 0 ? this.state.TM_GetLeadDetailUpdate[0].statuId : null));
			formVars.leadproductchange_28274_value = (stateVars.TM_GetLeadDetailUpdate !== undefined ? (stateVars.TM_GetLeadDetailUpdate?.length > 0 ? stateVars.TM_GetLeadDetailUpdate[0].nextStepId : null) : (this.state.TM_GetLeadDetailUpdate?.length > 0 ? this.state.TM_GetLeadDetailUpdate[0].nextStepId : null));
			formVars.leadproductchange_231791_value = (stateVars.TM_GetLeadDetailUpdate !== undefined ? (stateVars.TM_GetLeadDetailUpdate?.length > 0 ? stateVars.TM_GetLeadDetailUpdate[0].contactResourceId : null) : (this.state.TM_GetLeadDetailUpdate?.length > 0 ? this.state.TM_GetLeadDetailUpdate[0].contactResourceId : null));
			formVars.leadproductchange_680055_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadDetailUpdate !== undefined ? (stateVars.TM_GetLeadDetailUpdate?.length > 0 ? stateVars.TM_GetLeadDetailUpdate[0].talepNotu : null) : (this.state.TM_GetLeadDetailUpdate?.length > 0 ? this.state.TM_GetLeadDetailUpdate[0].talepNotu : null)));
			stateVars.GetAlternativeProductStockByLeadAndProductId = result?.data.getAlternativeProductStockByLeadAndProductId;
			formVars.leadproductchange_925392_value = ReactSystemFunctions.toString(this, (stateVars.GetAlternativeProductStockByLeadAndProductId !== undefined ? (stateVars.GetAlternativeProductStockByLeadAndProductId?.length > 0 ? stateVars.GetAlternativeProductStockByLeadAndProductId[0].productName : null) : (this.state.GetAlternativeProductStockByLeadAndProductId?.length > 0 ? this.state.GetAlternativeProductStockByLeadAndProductId[0].productName : null)));
			formVars.leadproductchange_60887_value = ReactSystemFunctions.toString(this, (stateVars.GetAlternativeProductStockByLeadAndProductId !== undefined ? (stateVars.GetAlternativeProductStockByLeadAndProductId?.length > 0 ? stateVars.GetAlternativeProductStockByLeadAndProductId[0].brand : null) : (this.state.GetAlternativeProductStockByLeadAndProductId?.length > 0 ? this.state.GetAlternativeProductStockByLeadAndProductId[0].brand : null)));
			formVars.leadproductchange_965326_value = ReactSystemFunctions.toString(this, (stateVars.GetAlternativeProductStockByLeadAndProductId !== undefined ? (stateVars.GetAlternativeProductStockByLeadAndProductId?.length > 0 ? stateVars.GetAlternativeProductStockByLeadAndProductId[0].referance : null) : (this.state.GetAlternativeProductStockByLeadAndProductId?.length > 0 ? this.state.GetAlternativeProductStockByLeadAndProductId[0].referance : null)));
			formVars.leadproductchange_178310_value = ReactSystemFunctions.toString(this, (stateVars.GetAlternativeProductStockByLeadAndProductId !== undefined ? (stateVars.GetAlternativeProductStockByLeadAndProductId?.length > 0 ? stateVars.GetAlternativeProductStockByLeadAndProductId[0].dial : null) : (this.state.GetAlternativeProductStockByLeadAndProductId?.length > 0 ? this.state.GetAlternativeProductStockByLeadAndProductId[0].dial : null)));
			formVars.leadproductchange_623087_value = ReactSystemFunctions.toString(this, (stateVars.GetAlternativeProductStockByLeadAndProductId !== undefined ? (stateVars.GetAlternativeProductStockByLeadAndProductId?.length > 0 ? stateVars.GetAlternativeProductStockByLeadAndProductId[0].bracelet : null) : (this.state.GetAlternativeProductStockByLeadAndProductId?.length > 0 ? this.state.GetAlternativeProductStockByLeadAndProductId[0].bracelet : null)));
			formVars.leadproductchange_678158_value = ReactSystemFunctions.toString(this, (stateVars.GetAlternativeProductStockByLeadAndProductId !== undefined ? (stateVars.GetAlternativeProductStockByLeadAndProductId?.length > 0 ? stateVars.GetAlternativeProductStockByLeadAndProductId[0].categoryName : null) : (this.state.GetAlternativeProductStockByLeadAndProductId?.length > 0 ? this.state.GetAlternativeProductStockByLeadAndProductId[0].categoryName : null)));
			formVars.leadproductchange_492230_value = ReactSystemFunctions.toString(this, (stateVars.GetAlternativeProductStockByLeadAndProductId !== undefined ? (stateVars.GetAlternativeProductStockByLeadAndProductId?.length > 0 ? stateVars.GetAlternativeProductStockByLeadAndProductId[0].categoryName : null) : (this.state.GetAlternativeProductStockByLeadAndProductId?.length > 0 ? this.state.GetAlternativeProductStockByLeadAndProductId[0].categoryName : null)));
			formVars.leadproductchange_447712_value = ReactSystemFunctions.toString(this, (stateVars.GetAlternativeProductStockByLeadAndProductId !== undefined ? (stateVars.GetAlternativeProductStockByLeadAndProductId?.length > 0 ? stateVars.GetAlternativeProductStockByLeadAndProductId[0].categoryName : null) : (this.state.GetAlternativeProductStockByLeadAndProductId?.length > 0 ? this.state.GetAlternativeProductStockByLeadAndProductId[0].categoryName : null)));
			formVars.leadproductchange_219088_value = ReactSystemFunctions.toString(this, (stateVars.GetAlternativeProductStockByLeadAndProductId !== undefined ? (stateVars.GetAlternativeProductStockByLeadAndProductId?.length > 0 ? stateVars.GetAlternativeProductStockByLeadAndProductId[0].categoryName : null) : (this.state.GetAlternativeProductStockByLeadAndProductId?.length > 0 ? this.state.GetAlternativeProductStockByLeadAndProductId[0].categoryName : null)));
			stateVars.isComp811509Visible = ((ReactSystemFunctions.isNotEmpty(ReactSystemFunctions.value(this, (stateVars.GetAlternativeProductStockByLeadAndProductId !== undefined ? (stateVars.GetAlternativeProductStockByLeadAndProductId?.length > 0 ? stateVars.GetAlternativeProductStockByLeadAndProductId[0].productId : null) : (this.state.GetAlternativeProductStockByLeadAndProductId?.length > 0 ? this.state.GetAlternativeProductStockByLeadAndProductId[0].productId : null))), ReactSystemFunctions.convertToTypeByName("True", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp678158Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.toString(this, (stateVars.GetAlternativeProductStockByLeadAndProductId !== undefined ? (stateVars.GetAlternativeProductStockByLeadAndProductId?.length > 0 ? stateVars.GetAlternativeProductStockByLeadAndProductId[0].categoryName : null) : (this.state.GetAlternativeProductStockByLeadAndProductId?.length > 0 ? this.state.GetAlternativeProductStockByLeadAndProductId[0].categoryName : null))), ReactSystemFunctions.convertToTypeByName("Kategori 2", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp492230Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.toString(this, (stateVars.GetAlternativeProductStockByLeadAndProductId !== undefined ? (stateVars.GetAlternativeProductStockByLeadAndProductId?.length > 0 ? stateVars.GetAlternativeProductStockByLeadAndProductId[0].categoryName : null) : (this.state.GetAlternativeProductStockByLeadAndProductId?.length > 0 ? this.state.GetAlternativeProductStockByLeadAndProductId[0].categoryName : null))), ReactSystemFunctions.convertToTypeByName("Kategori 1", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp447712Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.toString(this, (stateVars.GetAlternativeProductStockByLeadAndProductId !== undefined ? (stateVars.GetAlternativeProductStockByLeadAndProductId?.length > 0 ? stateVars.GetAlternativeProductStockByLeadAndProductId[0].categoryName : null) : (this.state.GetAlternativeProductStockByLeadAndProductId?.length > 0 ? this.state.GetAlternativeProductStockByLeadAndProductId[0].categoryName : null))), ReactSystemFunctions.convertToTypeByName("DEFAULT", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp219088Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.toString(this, (stateVars.GetAlternativeProductStockByLeadAndProductId !== undefined ? (stateVars.GetAlternativeProductStockByLeadAndProductId?.length > 0 ? stateVars.GetAlternativeProductStockByLeadAndProductId[0].categoryName : null) : (this.state.GetAlternativeProductStockByLeadAndProductId?.length > 0 ? this.state.GetAlternativeProductStockByLeadAndProductId[0].categoryName : null))), ReactSystemFunctions.convertToTypeByName("Kategori 3", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp883175Visible = ((ReactSystemFunctions.isGreaterThan(ReactSystemFunctions.value(this, (stateVars.GetAlternativeProductStockByLeadAndProductId !== undefined ? (stateVars.GetAlternativeProductStockByLeadAndProductId?.length > 0 ? stateVars.GetAlternativeProductStockByLeadAndProductId[0].totalStock : null) : (this.state.GetAlternativeProductStockByLeadAndProductId?.length > 0 ? this.state.GetAlternativeProductStockByLeadAndProductId[0].totalStock : null))), ReactSystemFunctions.convertToTypeByName("0", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp995040Visible = ((ReactSystemFunctions.isGreaterThan(ReactSystemFunctions.value(this, (stateVars.GetAlternativeProductStockByLeadAndProductId !== undefined ? (stateVars.GetAlternativeProductStockByLeadAndProductId?.length > 0 ? stateVars.GetAlternativeProductStockByLeadAndProductId[0].availableStock : null) : (this.state.GetAlternativeProductStockByLeadAndProductId?.length > 0 ? this.state.GetAlternativeProductStockByLeadAndProductId[0].availableStock : null))), ReactSystemFunctions.convertToTypeByName("0", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp424423Visible = ((ReactSystemFunctions.isLessThan(ReactSystemFunctions.value(this, (stateVars.GetAlternativeProductStockByLeadAndProductId !== undefined ? (stateVars.GetAlternativeProductStockByLeadAndProductId?.length > 0 ? stateVars.GetAlternativeProductStockByLeadAndProductId[0].totalStock : null) : (this.state.GetAlternativeProductStockByLeadAndProductId?.length > 0 ? this.state.GetAlternativeProductStockByLeadAndProductId[0].totalStock : null))), ReactSystemFunctions.convertToTypeByName("1", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp290650Visible = ((ReactSystemFunctions.isLessThan(ReactSystemFunctions.value(this, (stateVars.GetAlternativeProductStockByLeadAndProductId !== undefined ? (stateVars.GetAlternativeProductStockByLeadAndProductId?.length > 0 ? stateVars.GetAlternativeProductStockByLeadAndProductId[0].availableStock : null) : (this.state.GetAlternativeProductStockByLeadAndProductId?.length > 0 ? this.state.GetAlternativeProductStockByLeadAndProductId[0].availableStock : null))), ReactSystemFunctions.convertToTypeByName("1", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp841777Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, (stateVars.GetAlternativeProductStockByLeadAndProductId !== undefined ? (stateVars.GetAlternativeProductStockByLeadAndProductId?.length > 0 ? stateVars.GetAlternativeProductStockByLeadAndProductId[0].hasActiveLead : null) : (this.state.GetAlternativeProductStockByLeadAndProductId?.length > 0 ? this.state.GetAlternativeProductStockByLeadAndProductId[0].hasActiveLead : null))), ReactSystemFunctions.convertToTypeByName("True", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp899131Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, (stateVars.GetAlternativeProductStockByLeadAndProductId !== undefined ? (stateVars.GetAlternativeProductStockByLeadAndProductId?.length > 0 ? stateVars.GetAlternativeProductStockByLeadAndProductId[0].hasActiveLead : null) : (this.state.GetAlternativeProductStockByLeadAndProductId?.length > 0 ? this.state.GetAlternativeProductStockByLeadAndProductId[0].hasActiveLead : null))), ReactSystemFunctions.convertToTypeByName("False", "string"))) === true ? "visible" : "hidden")
			stateVars.GetAltrenativeProductStockInfoByProductId = result?.data.getAltrenativeProductStockInfoByProductId;
			
			this.props.form?.setFieldsValue(formVars);
			
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.LeadProductChangeComponent_971012_onChange1_();
                  resolve();
                });
          })



        
        KuikaAppManager.hideSpinner(this);
        return isErrorOccurred;
    }
		LeadProductChangeComponent_971012_onChange1_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }

				stateVars.ChangeVisibilityOf = await ReactSystemFunctions.changeVisibilityOf(this, ReactSystemFunctions.convertToTypeByName("isComp597261Visible", "string"), ReactSystemFunctions.convertToTypeByName("visible", "string"));

		this.props.form?.setFieldsValue(formVars);
		
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.LeadProductChangeComponent_971012_onChange2_();
                  resolve();
                });
          })

            
            return isErrorOccurred;
        }
    LeadProductChangeComponent_971012_onChange2_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
		KuikaAppManager.increaseServerRequestCount();

        let localVar = {
				LeadId_0: ReactSystemFunctions.convertToTypeByName(this.props.screenInputs.LeadId ?? this.props.screenInputs.leadid, "Guid"),
				NewProductId_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "leadproductchange_971012_value", "value", "TM_GetLeadAlternativeModel", "productId", "productId")), "Guid")
        }

		
        if (true) {
        KuikaAppManager.showSpinner(this);
        }
        let result = await KuikaAppManager.ApiRequest(this, "LeadProductChange/LeadProductChangeComponent_971012_onChange2_", localVar)
        if (!KMainFunctions.IsResStatus2XX(result)) return true;

			stateVars.TM_LeadProductChangeCheck = result?.data.tM_LeadProductChangeCheck;
			stateVars.isComp426370Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, (stateVars.TM_LeadProductChangeCheck !== undefined ? (stateVars.TM_LeadProductChangeCheck?.length > 0 ? stateVars.TM_LeadProductChangeCheck[0].isSameReference : null) : (this.state.TM_LeadProductChangeCheck?.length > 0 ? this.state.TM_LeadProductChangeCheck[0].isSameReference : null))), ReactSystemFunctions.convertToTypeByName("False", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp1807695110Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, (stateVars.TM_LeadProductChangeCheck !== undefined ? (stateVars.TM_LeadProductChangeCheck?.length > 0 ? stateVars.TM_LeadProductChangeCheck[0].isSameReference : null) : (this.state.TM_LeadProductChangeCheck?.length > 0 ? this.state.TM_LeadProductChangeCheck[0].isSameReference : null))), ReactSystemFunctions.convertToTypeByName("True", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp526608Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, (stateVars.TM_LeadProductChangeCheck !== undefined ? (stateVars.TM_LeadProductChangeCheck?.length > 0 ? stateVars.TM_LeadProductChangeCheck[0].isSameReference : null) : (this.state.TM_LeadProductChangeCheck?.length > 0 ? this.state.TM_LeadProductChangeCheck[0].isSameReference : null))), ReactSystemFunctions.convertToTypeByName("False", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp83104439Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, (stateVars.TM_LeadProductChangeCheck !== undefined ? (stateVars.TM_LeadProductChangeCheck?.length > 0 ? stateVars.TM_LeadProductChangeCheck[0].isSameReference : null) : (this.state.TM_LeadProductChangeCheck?.length > 0 ? this.state.TM_LeadProductChangeCheck[0].isSameReference : null))), ReactSystemFunctions.convertToTypeByName("True", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp1313677025Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, (stateVars.TM_LeadProductChangeCheck !== undefined ? (stateVars.TM_LeadProductChangeCheck?.length > 0 ? stateVars.TM_LeadProductChangeCheck[0].isSameReference : null) : (this.state.TM_LeadProductChangeCheck?.length > 0 ? this.state.TM_LeadProductChangeCheck[0].isSameReference : null))), ReactSystemFunctions.convertToTypeByName("False", "string"))) === true ? "visible" : "hidden")
			this.props.form?.setFieldsValue(formVars);
			
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.LeadProductChangeComponent_971012_onChange3_();
                  resolve();
                });
          })



        
        KuikaAppManager.hideSpinner(this);
        return isErrorOccurred;
    }
		LeadProductChangeComponent_971012_onChange3_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }

				formVars.leadproductchange_925392_value = ReactSystemFunctions.toString(this, (stateVars.GetAlternativeProductStockByLeadAndProductId !== undefined ? (stateVars.GetAlternativeProductStockByLeadAndProductId?.length > 0 ? stateVars.GetAlternativeProductStockByLeadAndProductId[0].productName : null) : (this.state.GetAlternativeProductStockByLeadAndProductId?.length > 0 ? this.state.GetAlternativeProductStockByLeadAndProductId[0].productName : null)));

				formVars.leadproductchange_60887_value = ReactSystemFunctions.toString(this, (stateVars.GetAlternativeProductStockByLeadAndProductId !== undefined ? (stateVars.GetAlternativeProductStockByLeadAndProductId?.length > 0 ? stateVars.GetAlternativeProductStockByLeadAndProductId[0].brand : null) : (this.state.GetAlternativeProductStockByLeadAndProductId?.length > 0 ? this.state.GetAlternativeProductStockByLeadAndProductId[0].brand : null)));

				formVars.leadproductchange_965326_value = ReactSystemFunctions.toString(this, (stateVars.GetAlternativeProductStockByLeadAndProductId !== undefined ? (stateVars.GetAlternativeProductStockByLeadAndProductId?.length > 0 ? stateVars.GetAlternativeProductStockByLeadAndProductId[0].referance : null) : (this.state.GetAlternativeProductStockByLeadAndProductId?.length > 0 ? this.state.GetAlternativeProductStockByLeadAndProductId[0].referance : null)));

				formVars.leadproductchange_178310_value = ReactSystemFunctions.toString(this, (stateVars.GetAlternativeProductStockByLeadAndProductId !== undefined ? (stateVars.GetAlternativeProductStockByLeadAndProductId?.length > 0 ? stateVars.GetAlternativeProductStockByLeadAndProductId[0].dial : null) : (this.state.GetAlternativeProductStockByLeadAndProductId?.length > 0 ? this.state.GetAlternativeProductStockByLeadAndProductId[0].dial : null)));

				formVars.leadproductchange_623087_value = ReactSystemFunctions.toString(this, (stateVars.GetAlternativeProductStockByLeadAndProductId !== undefined ? (stateVars.GetAlternativeProductStockByLeadAndProductId?.length > 0 ? stateVars.GetAlternativeProductStockByLeadAndProductId[0].bracelet : null) : (this.state.GetAlternativeProductStockByLeadAndProductId?.length > 0 ? this.state.GetAlternativeProductStockByLeadAndProductId[0].bracelet : null)));

				formVars.leadproductchange_678158_value = ReactSystemFunctions.toString(this, (stateVars.GetAlternativeProductStockByLeadAndProductId !== undefined ? (stateVars.GetAlternativeProductStockByLeadAndProductId?.length > 0 ? stateVars.GetAlternativeProductStockByLeadAndProductId[0].categoryName : null) : (this.state.GetAlternativeProductStockByLeadAndProductId?.length > 0 ? this.state.GetAlternativeProductStockByLeadAndProductId[0].categoryName : null)));

				formVars.leadproductchange_492230_value = ReactSystemFunctions.toString(this, (stateVars.GetAlternativeProductStockByLeadAndProductId !== undefined ? (stateVars.GetAlternativeProductStockByLeadAndProductId?.length > 0 ? stateVars.GetAlternativeProductStockByLeadAndProductId[0].categoryName : null) : (this.state.GetAlternativeProductStockByLeadAndProductId?.length > 0 ? this.state.GetAlternativeProductStockByLeadAndProductId[0].categoryName : null)));

				formVars.leadproductchange_447712_value = ReactSystemFunctions.toString(this, (stateVars.GetAlternativeProductStockByLeadAndProductId !== undefined ? (stateVars.GetAlternativeProductStockByLeadAndProductId?.length > 0 ? stateVars.GetAlternativeProductStockByLeadAndProductId[0].categoryName : null) : (this.state.GetAlternativeProductStockByLeadAndProductId?.length > 0 ? this.state.GetAlternativeProductStockByLeadAndProductId[0].categoryName : null)));

				formVars.leadproductchange_219088_value = ReactSystemFunctions.toString(this, (stateVars.GetAlternativeProductStockByLeadAndProductId !== undefined ? (stateVars.GetAlternativeProductStockByLeadAndProductId?.length > 0 ? stateVars.GetAlternativeProductStockByLeadAndProductId[0].categoryName : null) : (this.state.GetAlternativeProductStockByLeadAndProductId?.length > 0 ? this.state.GetAlternativeProductStockByLeadAndProductId[0].categoryName : null)));

				
				stateVars.dataSource_597018 = stateVars.GetAltrenativeProductStockInfoByProductId ?? this.state.GetAltrenativeProductStockInfoByProductId;
				formVars.leadproductchange_783386_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadDetailUpdate !== undefined ? (stateVars.TM_GetLeadDetailUpdate?.length > 0 ? stateVars.TM_GetLeadDetailUpdate[0].storeId : null) : (this.state.TM_GetLeadDetailUpdate?.length > 0 ? this.state.TM_GetLeadDetailUpdate[0].storeId : null)));

				formVars.leadproductchange_631367_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadDetailUpdate !== undefined ? (stateVars.TM_GetLeadDetailUpdate?.length > 0 ? stateVars.TM_GetLeadDetailUpdate[0].salesPersonKUserId : null) : (this.state.TM_GetLeadDetailUpdate?.length > 0 ? this.state.TM_GetLeadDetailUpdate[0].salesPersonKUserId : null)));

				formVars.leadproductchange_48899_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadDetailUpdate !== undefined ? (stateVars.TM_GetLeadDetailUpdate?.length > 0 ? stateVars.TM_GetLeadDetailUpdate[0].statuId : null) : (this.state.TM_GetLeadDetailUpdate?.length > 0 ? this.state.TM_GetLeadDetailUpdate[0].statuId : null)));

				formVars.leadproductchange_28274_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadDetailUpdate !== undefined ? (stateVars.TM_GetLeadDetailUpdate?.length > 0 ? stateVars.TM_GetLeadDetailUpdate[0].nextStepId : null) : (this.state.TM_GetLeadDetailUpdate?.length > 0 ? this.state.TM_GetLeadDetailUpdate[0].nextStepId : null)));

				formVars.leadproductchange_231791_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadDetailUpdate !== undefined ? (stateVars.TM_GetLeadDetailUpdate?.length > 0 ? stateVars.TM_GetLeadDetailUpdate[0].contactResourceId : null) : (this.state.TM_GetLeadDetailUpdate?.length > 0 ? this.state.TM_GetLeadDetailUpdate[0].contactResourceId : null)));

				formVars.leadproductchange_680055_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadDetailUpdate !== undefined ? (stateVars.TM_GetLeadDetailUpdate?.length > 0 ? stateVars.TM_GetLeadDetailUpdate[0].talepNotu : null) : (this.state.TM_GetLeadDetailUpdate?.length > 0 ? this.state.TM_GetLeadDetailUpdate[0].talepNotu : null)));


		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

            
            return isErrorOccurred;
        }







    LeadProductChangeComponent_165528_onClick = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
		KuikaAppManager.increaseServerRequestCount();

        let localVar = {
				LeadId_0: ReactSystemFunctions.convertToTypeByName(this.props.screenInputs.LeadId ?? this.props.screenInputs.leadid, "Guid"),
				NewProductId_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "leadproductchange_971012_value", "value", "TM_GetLeadAlternativeModel", "productId", "productId")), "Guid"),
				UserId_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.getMyUserId(), "Guid"),
				TRANCOUNT_0: ReactSystemFunctions.convertToTypeByName(0, "number")
        }

		KuikaAppManager.showSpinner(this);
		
        if (true) {
        KuikaAppManager.showSpinner(this);
        }
        let result = await KuikaAppManager.ApiRequest(this, "LeadProductChange/LeadProductChangeComponent_165528_onClick", localVar)
        if (!KMainFunctions.IsResStatus2XX(result)) return true;

			stateVars.TM_LeadProductChangeSameReference = result?.data.tM_LeadProductChangeSameReference;
			this.props.form?.setFieldsValue(formVars);
			
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.LeadProductChangeComponent_165528_onClick1_();
                  resolve();
                });
          })



        
        KuikaAppManager.hideSpinner(this);
        return isErrorOccurred;
    }
		LeadProductChangeComponent_165528_onClick1_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }

				stateVars.Notify = await ReactSystemFunctions.notify(this, ReactSystemFunctions.toString(this, (stateVars.TM_LeadProductChangeSameReference !== undefined ? (stateVars.TM_LeadProductChangeSameReference?.length > 0 ? stateVars.TM_LeadProductChangeSameReference[0].message : null) : (this.state.TM_LeadProductChangeSameReference?.length > 0 ? this.state.TM_LeadProductChangeSameReference[0].message : null))), ReactSystemFunctions.convertToTypeByName("default", "string"), ReactSystemFunctions.convertToTypeByName("bottom-right", "string"), 1, ReactSystemFunctions.convertToTypeByName("", "string"), ReactSystemFunctions.convertToTypeByName("", "string"), 0);
				stateVars.GoBack = await ReactSystemFunctions.goBack(this, false);

		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

            
            return isErrorOccurred;
        }




    LeadProductChangeComponent_239273_onClick = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;

			validations.push({ 
				isValid: ReactSystemFunctions.isNotEmpty(ReactSystemFunctions.value(this, "leadproductchange_48899_value", "value", "TM_GetLeadStatus", "id", ""), null),
				message: "Bu alan boş bırakılamaz!",
				formName: "leadproductchange_48899_value",
				condition: true
			} as IValidationData);

validations.forEach((validation) => {
            if (validation.message === "Geçerli bir mail adresi giriniz.") {
                validation.message = ReactSystemFunctions.getEmailValidationMessage()
            }
        })
			validations.push({ 
				isValid: ReactSystemFunctions.isNotEmpty(ReactSystemFunctions.value(this, "leadproductchange_28274_value", "value", "TM_GetLeadNextSteps", "id", ""), null),
				message: "Bu alan boş bırakılamaz!",
				formName: "leadproductchange_28274_value",
				condition: true
			} as IValidationData);

validations.forEach((validation) => {
            if (validation.message === "Geçerli bir mail adresi giriniz.") {
                validation.message = ReactSystemFunctions.getEmailValidationMessage()
            }
        })
			validations.push({ 
				isValid: ReactSystemFunctions.isNotEmpty(ReactSystemFunctions.value(this, "leadproductchange_231791_value", "value", "TM_GetAllContactSource", "id", ""), null),
				message: "Bu alan boş bırakılamaz!",
				formName: "leadproductchange_231791_value",
				condition: true
			} as IValidationData);

validations.forEach((validation) => {
            if (validation.message === "Geçerli bir mail adresi giriniz.") {
                validation.message = ReactSystemFunctions.getEmailValidationMessage()
            }
        })

		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
		KuikaAppManager.increaseServerRequestCount();

        let localVar = {
				SalesPersonKUserId_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "leadproductchange_631367_value", "value", "GetSalesPersonByStore", "kuserID", "kuserID")), "Guid"),
				CreatedBy_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.getMyUserId(), "Guid"),
				Brand_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "leadproductchange_971012_value", "value", "TM_GetLeadAlternativeModel", "productId", "brand")), "string"),
				StatuId_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "leadproductchange_48899_value", "value", "TM_GetLeadStatus", "id", "id")), "Guid"),
				NextStepId_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "leadproductchange_28274_value", "value", "TM_GetLeadNextSteps", "id", "id")), "Guid"),
				StoreId_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "leadproductchange_783386_value", "value", "TM_StoreGetList", "id", "id")), "Guid"),
				ContactResourceId_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "leadproductchange_231791_value", "value", "TM_GetAllContactSource", "id", "id")), "Guid"),
				ProductId_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "leadproductchange_971012_value", "value", "TM_GetLeadAlternativeModel", "productId", "productId")), "Guid"),
				CustomerId_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, (stateVars.TM_GetLeadDetailUpdate !== undefined ? (stateVars.TM_GetLeadDetailUpdate?.length > 0 ? stateVars.TM_GetLeadDetailUpdate[0].customerId : null) : (this.state.TM_GetLeadDetailUpdate?.length > 0 ? this.state.TM_GetLeadDetailUpdate[0].customerId : null))), "Guid"),
				LeadNote_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "leadproductchange_680055_value", "value", "", "", "")), "string"),
				ReferencePersonID_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, (stateVars.TM_GetLeadDetailUpdate !== undefined ? (stateVars.TM_GetLeadDetailUpdate?.length > 0 ? stateVars.TM_GetLeadDetailUpdate[0].referencePersonID : null) : (this.state.TM_GetLeadDetailUpdate?.length > 0 ? this.state.TM_GetLeadDetailUpdate[0].referencePersonID : null))), "Guid"),
				SessionCode_0: ReactSystemFunctions.convertToTypeByName(null, "string")
        }

		KuikaAppManager.showSpinner(this);
if (((ReactSystemFunctions.contains(ReactSystemFunctions.getMyRoleNames(), ReactSystemFunctions.convertToTypeByName("TimesUstYonetici", "string")) || ReactSystemFunctions.contains(ReactSystemFunctions.getMyRoleNames(), ReactSystemFunctions.convertToTypeByName("TimesYonetici", "string"))) && ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, (stateVars.TM_LeadProductChangeCheck !== undefined ? (stateVars.TM_LeadProductChangeCheck?.length > 0 ? stateVars.TM_LeadProductChangeCheck[0].isBlocked : null) : (this.state.TM_LeadProductChangeCheck?.length > 0 ? this.state.TM_LeadProductChangeCheck[0].isBlocked : null))), ReactSystemFunctions.convertToTypeByName("False", "string")) && ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, (stateVars.TM_LeadProductChangeCheck !== undefined ? (stateVars.TM_LeadProductChangeCheck?.length > 0 ? stateVars.TM_LeadProductChangeCheck[0].isSameReference : null) : (this.state.TM_LeadProductChangeCheck?.length > 0 ? this.state.TM_LeadProductChangeCheck[0].isSameReference : null))), ReactSystemFunctions.convertToTypeByName("False", "string")))) {
            
            stateVars.Confirm = await ReactSystemFunctions.confirmation(
                ReactSystemFunctions.translateCustomActions(this.ml,"35af92bb_ebd8_5725_1799_caf54d8196b7_confirmation",this.defaultML,"Ürün değişikliği sonucunda mevcut talep kapatılıp yeni talep açılacaktır. Devam etmek istediğinize emin misiniz?" ),
                "poppins",
                "Onay",
                "confirmation",
                "#246dff",
                "",
                ""
            );

            if (stateVars.Confirm)
            {
                		
        if (true) {
        KuikaAppManager.showSpinner(this);
        }
        let result = await KuikaAppManager.ApiRequest(this, "LeadProductChange/LeadProductChangeComponent_239273_onClick", localVar)
        if (!KMainFunctions.IsResStatus2XX(result)) return true;

			stateVars.TM_CreateLead = result?.data.tM_CreateLead;
			this.props.form?.setFieldsValue(formVars);
			
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.LeadProductChangeComponent_239273_onClick1_();
                  resolve();
                });
          })

            }
            else
            {
                KuikaAppManager.hideSpinner(this);
            }
        } else {
            
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.LeadProductChangeComponent_239273_onClick1_();
                  resolve();
                });
          })
        }


        
        KuikaAppManager.hideSpinner(this);
        return isErrorOccurred;
    }
    LeadProductChangeComponent_239273_onClick1_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;

			validations.push({ 
				isValid: ReactSystemFunctions.isNotEmpty(ReactSystemFunctions.value(this, "leadproductchange_48899_value", "value", "TM_GetLeadStatus", "id", ""), null),
				message: "Bu alan boş bırakılamaz!",
				formName: "leadproductchange_48899_value",
				condition: true
			} as IValidationData);

validations.forEach((validation) => {
            if (validation.message === "Geçerli bir mail adresi giriniz.") {
                validation.message = ReactSystemFunctions.getEmailValidationMessage()
            }
        })
			validations.push({ 
				isValid: ReactSystemFunctions.isNotEmpty(ReactSystemFunctions.value(this, "leadproductchange_28274_value", "value", "TM_GetLeadNextSteps", "id", ""), null),
				message: "Bu alan boş bırakılamaz!",
				formName: "leadproductchange_28274_value",
				condition: true
			} as IValidationData);

validations.forEach((validation) => {
            if (validation.message === "Geçerli bir mail adresi giriniz.") {
                validation.message = ReactSystemFunctions.getEmailValidationMessage()
            }
        })
			validations.push({ 
				isValid: ReactSystemFunctions.isNotEmpty(ReactSystemFunctions.value(this, "leadproductchange_231791_value", "value", "TM_GetAllContactSource", "id", ""), null),
				message: "Bu alan boş bırakılamaz!",
				formName: "leadproductchange_231791_value",
				condition: true
			} as IValidationData);

validations.forEach((validation) => {
            if (validation.message === "Geçerli bir mail adresi giriniz.") {
                validation.message = ReactSystemFunctions.getEmailValidationMessage()
            }
        })

		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
		KuikaAppManager.increaseServerRequestCount();

        let localVar = {
				SalesPersonKUserId_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "leadproductchange_631367_value", "value", "GetSalesPersonByStore", "kuserID", "kuserID")), "Guid"),
				CreatedBy_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.getMyUserId(), "Guid"),
				Brand_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "leadproductchange_971012_value", "value", "TM_GetLeadAlternativeModel", "productId", "brand")), "string"),
				StatuId_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "leadproductchange_48899_value", "value", "TM_GetLeadStatus", "id", "id")), "Guid"),
				NextStepId_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "leadproductchange_28274_value", "value", "TM_GetLeadNextSteps", "id", "id")), "Guid"),
				StoreId_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, (stateVars.TS_GetStoreUsers !== undefined ? (stateVars.TS_GetStoreUsers?.length > 0 ? stateVars.TS_GetStoreUsers[0].storeID : null) : (this.state.TS_GetStoreUsers?.length > 0 ? this.state.TS_GetStoreUsers[0].storeID : null))), "Guid"),
				ContactResourceId_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "leadproductchange_231791_value", "value", "TM_GetAllContactSource", "id", "id")), "Guid"),
				ProductId_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "leadproductchange_971012_value", "value", "TM_GetLeadAlternativeModel", "productId", "productId")), "Guid"),
				CustomerId_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, (stateVars.TM_GetLeadDetailUpdate !== undefined ? (stateVars.TM_GetLeadDetailUpdate?.length > 0 ? stateVars.TM_GetLeadDetailUpdate[0].customerId : null) : (this.state.TM_GetLeadDetailUpdate?.length > 0 ? this.state.TM_GetLeadDetailUpdate[0].customerId : null))), "Guid"),
				LeadNote_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "leadproductchange_680055_value", "value", "", "", "")), "string"),
				ReferencePersonID_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, (stateVars.TM_GetLeadDetailUpdate !== undefined ? (stateVars.TM_GetLeadDetailUpdate?.length > 0 ? stateVars.TM_GetLeadDetailUpdate[0].referencePersonID : null) : (this.state.TM_GetLeadDetailUpdate?.length > 0 ? this.state.TM_GetLeadDetailUpdate[0].referencePersonID : null))), "Guid"),
				SessionCode_0: ReactSystemFunctions.convertToTypeByName(null, "string")
        }

if ((ReactSystemFunctions.contains(ReactSystemFunctions.getMyRoleNames(), ReactSystemFunctions.convertToTypeByName("TimesMagazaMuduru", "string")) && ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, (stateVars.TM_LeadProductChangeCheck !== undefined ? (stateVars.TM_LeadProductChangeCheck?.length > 0 ? stateVars.TM_LeadProductChangeCheck[0].isBlocked : null) : (this.state.TM_LeadProductChangeCheck?.length > 0 ? this.state.TM_LeadProductChangeCheck[0].isBlocked : null))), ReactSystemFunctions.convertToTypeByName("False", "string")) && ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, (stateVars.TM_LeadProductChangeCheck !== undefined ? (stateVars.TM_LeadProductChangeCheck?.length > 0 ? stateVars.TM_LeadProductChangeCheck[0].isSameReference : null) : (this.state.TM_LeadProductChangeCheck?.length > 0 ? this.state.TM_LeadProductChangeCheck[0].isSameReference : null))), ReactSystemFunctions.convertToTypeByName("False", "string")))) {
            
            stateVars.Confirm = await ReactSystemFunctions.confirmation(
                ReactSystemFunctions.translateCustomActions(this.ml,"3b05ea28_e66a_ad1e_22c2_d2db4534e0f0_confirmation",this.defaultML,"Ürün değişikliği sonucunda mevcut talep kapatılıp yeni talep açılacaktır. Devam etmek istediğinize emin misiniz?" ),
                "poppins",
                "Onay",
                "confirmation",
                "#246dff",
                "",
                ""
            );

            if (stateVars.Confirm)
            {
                		
        if (true) {
        KuikaAppManager.showSpinner(this);
        }
        let result = await KuikaAppManager.ApiRequest(this, "LeadProductChange/LeadProductChangeComponent_239273_onClick1_", localVar)
        if (!KMainFunctions.IsResStatus2XX(result)) return true;

			stateVars.TM_CreateLead = result?.data.tM_CreateLead;
			this.props.form?.setFieldsValue(formVars);
			
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.LeadProductChangeComponent_239273_onClick2_();
                  resolve();
                });
          })

            }
            else
            {
                KuikaAppManager.hideSpinner(this);
            }
        } else {
            
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.LeadProductChangeComponent_239273_onClick2_();
                  resolve();
                });
          })
        }


        
        KuikaAppManager.hideSpinner(this);
        return isErrorOccurred;
    }
    LeadProductChangeComponent_239273_onClick2_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;

			validations.push({ 
				isValid: ReactSystemFunctions.isNotEmpty(ReactSystemFunctions.value(this, "leadproductchange_48899_value", "value", "TM_GetLeadStatus", "id", ""), null),
				message: "Bu alan boş bırakılamaz!",
				formName: "leadproductchange_48899_value",
				condition: true
			} as IValidationData);

validations.forEach((validation) => {
            if (validation.message === "Geçerli bir mail adresi giriniz.") {
                validation.message = ReactSystemFunctions.getEmailValidationMessage()
            }
        })
			validations.push({ 
				isValid: ReactSystemFunctions.isNotEmpty(ReactSystemFunctions.value(this, "leadproductchange_28274_value", "value", "TM_GetLeadNextSteps", "id", ""), null),
				message: "Bu alan boş bırakılamaz!",
				formName: "leadproductchange_28274_value",
				condition: true
			} as IValidationData);

validations.forEach((validation) => {
            if (validation.message === "Geçerli bir mail adresi giriniz.") {
                validation.message = ReactSystemFunctions.getEmailValidationMessage()
            }
        })
			validations.push({ 
				isValid: ReactSystemFunctions.isNotEmpty(ReactSystemFunctions.value(this, "leadproductchange_231791_value", "value", "TM_GetAllContactSource", "id", ""), null),
				message: "Bu alan boş bırakılamaz!",
				formName: "leadproductchange_231791_value",
				condition: true
			} as IValidationData);

validations.forEach((validation) => {
            if (validation.message === "Geçerli bir mail adresi giriniz.") {
                validation.message = ReactSystemFunctions.getEmailValidationMessage()
            }
        })

		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
		KuikaAppManager.increaseServerRequestCount();

        let localVar = {
				SalesPersonKUserId_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.getMyUserId(), "Guid"),
				CreatedBy_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.getMyUserId(), "Guid"),
				Brand_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "leadproductchange_971012_value", "value", "TM_GetLeadAlternativeModel", "productId", "brand")), "string"),
				StatuId_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "leadproductchange_48899_value", "value", "TM_GetLeadStatus", "id", "id")), "Guid"),
				NextStepId_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "leadproductchange_28274_value", "value", "TM_GetLeadNextSteps", "id", "id")), "Guid"),
				StoreId_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, (stateVars.TS_GetStoreUsers !== undefined ? (stateVars.TS_GetStoreUsers?.length > 0 ? stateVars.TS_GetStoreUsers[0].storeID : null) : (this.state.TS_GetStoreUsers?.length > 0 ? this.state.TS_GetStoreUsers[0].storeID : null))), "Guid"),
				ContactResourceId_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "leadproductchange_231791_value", "value", "TM_GetAllContactSource", "id", "id")), "Guid"),
				ProductId_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "leadproductchange_971012_value", "value", "TM_GetLeadAlternativeModel", "productId", "productId")), "Guid"),
				CustomerId_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, (stateVars.TM_GetLeadDetailUpdate !== undefined ? (stateVars.TM_GetLeadDetailUpdate?.length > 0 ? stateVars.TM_GetLeadDetailUpdate[0].customerId : null) : (this.state.TM_GetLeadDetailUpdate?.length > 0 ? this.state.TM_GetLeadDetailUpdate[0].customerId : null))), "Guid"),
				LeadNote_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "leadproductchange_680055_value", "value", "", "", "")), "string"),
				ReferencePersonID_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, (stateVars.TM_GetLeadDetailUpdate !== undefined ? (stateVars.TM_GetLeadDetailUpdate?.length > 0 ? stateVars.TM_GetLeadDetailUpdate[0].referencePersonID : null) : (this.state.TM_GetLeadDetailUpdate?.length > 0 ? this.state.TM_GetLeadDetailUpdate[0].referencePersonID : null))), "Guid"),
				SessionCode_0: ReactSystemFunctions.convertToTypeByName(null, "string")
        }

if ((ReactSystemFunctions.contains(ReactSystemFunctions.getMyRoleNames(), ReactSystemFunctions.convertToTypeByName("TimesSatisPersoneli", "string")) && ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, (stateVars.TM_LeadProductChangeCheck !== undefined ? (stateVars.TM_LeadProductChangeCheck?.length > 0 ? stateVars.TM_LeadProductChangeCheck[0].isBlocked : null) : (this.state.TM_LeadProductChangeCheck?.length > 0 ? this.state.TM_LeadProductChangeCheck[0].isBlocked : null))), ReactSystemFunctions.convertToTypeByName("False", "string")) && ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, (stateVars.TM_LeadProductChangeCheck !== undefined ? (stateVars.TM_LeadProductChangeCheck?.length > 0 ? stateVars.TM_LeadProductChangeCheck[0].isSameReference : null) : (this.state.TM_LeadProductChangeCheck?.length > 0 ? this.state.TM_LeadProductChangeCheck[0].isSameReference : null))), ReactSystemFunctions.convertToTypeByName("False", "string")))) {
            
            stateVars.Confirm = await ReactSystemFunctions.confirmation(
                ReactSystemFunctions.translateCustomActions(this.ml,"c1dd418b_5beb_7bf5_ae2b_95693a5462a8_confirmation",this.defaultML,"Ürün değişikliği sonucunda mevcut talep kapatılıp yeni talep açılacaktır. Devam etmek istediğinize emin misiniz?" ),
                "poppins",
                "Onay",
                "confirmation",
                "#246dff",
                "",
                ""
            );

            if (stateVars.Confirm)
            {
                		
        if (true) {
        KuikaAppManager.showSpinner(this);
        }
        let result = await KuikaAppManager.ApiRequest(this, "LeadProductChange/LeadProductChangeComponent_239273_onClick2_", localVar)
        if (!KMainFunctions.IsResStatus2XX(result)) return true;

			stateVars.TM_CreateLead = result?.data.tM_CreateLead;
			this.props.form?.setFieldsValue(formVars);
			
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.LeadProductChangeComponent_239273_onClick3_();
                  resolve();
                });
          })

            }
            else
            {
                KuikaAppManager.hideSpinner(this);
            }
        } else {
            
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.LeadProductChangeComponent_239273_onClick3_();
                  resolve();
                });
          })
        }


        
        KuikaAppManager.hideSpinner(this);
        return isErrorOccurred;
    }
		LeadProductChangeComponent_239273_onClick3_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
if ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, (stateVars.TM_LeadProductChangeCheck !== undefined ? (stateVars.TM_LeadProductChangeCheck?.length > 0 ? stateVars.TM_LeadProductChangeCheck[0].isBlocked : null) : (this.state.TM_LeadProductChangeCheck?.length > 0 ? this.state.TM_LeadProductChangeCheck[0].isBlocked : null))), false) && ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, (stateVars.TM_LeadProductChangeCheck !== undefined ? (stateVars.TM_LeadProductChangeCheck?.length > 0 ? stateVars.TM_LeadProductChangeCheck[0].isSameReference : null) : (this.state.TM_LeadProductChangeCheck?.length > 0 ? this.state.TM_LeadProductChangeCheck[0].isSameReference : null))), false))) {
            
				stateVars.Notify = await ReactSystemFunctions.notify(this, ReactSystemFunctions.toString(this, (stateVars.TM_CreateLead !== undefined ? (stateVars.TM_CreateLead?.length > 0 ? stateVars.TM_CreateLead[0].message : null) : (this.state.TM_CreateLead?.length > 0 ? this.state.TM_CreateLead[0].message : null))), ReactSystemFunctions.convertToTypeByName("default", "string"), ReactSystemFunctions.convertToTypeByName("top-center", "string"), 2, ReactSystemFunctions.convertToTypeByName("", "string"), ReactSystemFunctions.convertToTypeByName("", "string"), 0);

		this.props.form?.setFieldsValue(formVars);
		
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.LeadProductChangeComponent_239273_onClick4_();
                  resolve();
                });
          })

        } else {
            
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.LeadProductChangeComponent_239273_onClick4_();
                  resolve();
                });
          })
        }

            
            return isErrorOccurred;
        }
    LeadProductChangeComponent_239273_onClick4_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
		KuikaAppManager.increaseServerRequestCount();

        let localVar = {
				NewLeadId_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, (stateVars.TM_CreateLead !== undefined ? (stateVars.TM_CreateLead?.length > 0 ? stateVars.TM_CreateLead[0].leadId : null) : (this.state.TM_CreateLead?.length > 0 ? this.state.TM_CreateLead[0].leadId : null))), "Guid"),
				LeadId_0: ReactSystemFunctions.convertToTypeByName(this.props.screenInputs.LeadId ?? this.props.screenInputs.leadid, "Guid"),
				NewProductId_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "leadproductchange_971012_value", "value", "TM_GetLeadAlternativeModel", "productId", "productId")), "Guid"),
				UserId_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.getMyUserId(), "Guid")
        }

if ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, (stateVars.TM_LeadProductChangeCheck !== undefined ? (stateVars.TM_LeadProductChangeCheck?.length > 0 ? stateVars.TM_LeadProductChangeCheck[0].isBlocked : null) : (this.state.TM_LeadProductChangeCheck?.length > 0 ? this.state.TM_LeadProductChangeCheck[0].isBlocked : null))), ReactSystemFunctions.convertToTypeByName("False", "string")) && ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, (stateVars.TM_LeadProductChangeCheck !== undefined ? (stateVars.TM_LeadProductChangeCheck?.length > 0 ? stateVars.TM_LeadProductChangeCheck[0].isSameReference : null) : (this.state.TM_LeadProductChangeCheck?.length > 0 ? this.state.TM_LeadProductChangeCheck[0].isSameReference : null))), ReactSystemFunctions.convertToTypeByName("False", "string")))) {
            		
        if (true) {
        KuikaAppManager.showSpinner(this);
        }
        let result = await KuikaAppManager.ApiRequest(this, "LeadProductChange/LeadProductChangeComponent_239273_onClick4_", localVar)
        if (!KMainFunctions.IsResStatus2XX(result)) return true;

			stateVars.TM_LeadCloseOnProductChange = result?.data.tM_LeadCloseOnProductChange;
			this.props.form?.setFieldsValue(formVars);
			
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.LeadProductChangeComponent_239273_onClick5_();
                  resolve();
                });
          })

        } else {
            
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.LeadProductChangeComponent_239273_onClick5_();
                  resolve();
                });
          })
        }


        
        KuikaAppManager.hideSpinner(this);
        return isErrorOccurred;
    }
		LeadProductChangeComponent_239273_onClick5_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
if (ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, (stateVars.TM_LeadProductChangeCheck !== undefined ? (stateVars.TM_LeadProductChangeCheck?.length > 0 ? stateVars.TM_LeadProductChangeCheck[0].isBlocked : null) : (this.state.TM_LeadProductChangeCheck?.length > 0 ? this.state.TM_LeadProductChangeCheck[0].isBlocked : null))), false)) {
            
				stateVars.GoBack = await ReactSystemFunctions.goBack(this, true);

		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

        } else {
            KuikaAppManager.hideSpinner(this);
        }

            
            return isErrorOccurred;
        }













    async callCallbackFunction(diId: number, isFromMaster: boolean = false) {
        let isErrorOccurred = false;
		let pageInitCallerNavDiIDs = [] as number[];
		if (isFromMaster || pageInitCallerNavDiIDs.indexOf(diId) > -1) {
			await this.LeadProductChangePageInit();
		}

    }


}
