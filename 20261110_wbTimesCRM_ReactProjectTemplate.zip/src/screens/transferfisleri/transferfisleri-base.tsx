import React from "react";
import Axios, { AxiosResponse } from "axios";
import { KuikaAppManager } from "../../shared/utilty/kuika-app-manager";
import { ReactSystemFunctions } from "../../shared/utilty/react-system-functions";
import { KNavigator } from "../../shared/hoc/with-history";
import { KContext } from "../../shared/hoc/with-context";
import { useLocation } from "react-router-dom";
import { FormInstance } from "antd/es/form";
import { Guid } from "guid-typescript";
import Swal from "sweetalert2";
import { KMainFunctions } from "../../shared/utilty/main-functions";
import moment from "moment";
import { IValidationData } from "../../models/dto/validation-data";
import { IStripePayment } from "../../models/dto/stripe-payment";
import { IUserInfoDto } from "../../models/dto/user-info.dto";
import { UserService } from "../../services/user-service";
import { kuikaCoreWasmBridgeService } from "../../services/_singletons";
import _ from "lodash";
import mqtt, { MqttClient } from "mqtt";
import { IMqttResult } from "../../models/dto/mqtt.dto";


declare let window: any;

export interface ITransferFisleri_ScreenProps {
  navigator: KNavigator;
  form: FormInstance<any>;
  googleLogin: any;
  screenInputs: any;
  context: KContext;
  initialValues: any;
  children: any;
}

export interface ITransferFisleri_ScreenState {
    isSpinnerVisible: boolean;
    isPageVisible: boolean;
	isLeftMenuVisible: boolean;
    spinnerCount: number;
    selectedLanguage: string;
    isPageInitLoaded: false;
    isPageRecurringLoaded: false;

}

export class TransferFisleri_ScreenBase extends React.PureComponent<ITransferFisleri_ScreenProps, any> {

	transferfisleri_413834_value_kuikaAutoCompleteRef: React.RefObject<any>;
	transferfisleri_402197_value_kuikaAutoCompleteRef: React.RefObject<any>;
	transferfisleri_539143_value_kuikaAutoCompleteRef: React.RefObject<any>;
	transferfisleri_217734_value_kuikaTableRef: React.RefObject<any>;
	transferfisleri_618397_value_kuikaPaginationRef: React.RefObject<any>;
    ml=[{"Id":"d5a61d2b-bd60-485f-86e2-661e9ed4e486","Name":"en_US","ShortName":"English","IsDefault":true,"LanguagePhrases":[]},{"Id":"59b1a9af-0bf2-46f7-9afc-06c6f508312c","Name":"FixedValues","ShortName":"FixedValues","LanguagePhrases":[{"Id":784109,"PropertyName":"value","Value":"Transfer Fişleri"},{"Id":17721,"PropertyName":"value","Value":"Oluşturulan transfer fişlerini, sevk ve kabul durumlarıyla takip edin."},{"Id":892133,"PropertyName":"label","Value":"Yenile"},{"Id":373302,"PropertyName":"tab","Value":"Devam Eden 12"},{"Id":521003,"PropertyName":"value","Value":"Fiş No"},{"Id":687916,"PropertyName":"placeholder","Value":"Fiş No"},{"Id":587243,"PropertyName":"value","Value":"Nebim Fiş No"},{"Id":956980,"PropertyName":"placeholder","Value":"Nebim Fiş No"},{"Id":64714,"PropertyName":"value","Value":"Gönderen Mağaza"},{"Id":413834,"PropertyName":"placeholder","Value":"Gönderen Mağaza"},{"Id":675262,"PropertyName":"value","Value":"Alıcı Mağaza"},{"Id":402197,"PropertyName":"placeholder","Value":"Alıcı Mağaza"},{"Id":550117,"PropertyName":"value","Value":"Fiş Durumu"},{"Id":379874,"PropertyName":"placeholder","Value":"Fiş Durumu"},{"Id":240289,"PropertyName":"value","Value":"Kargo Firması"},{"Id":539143,"PropertyName":"placeholder","Value":"Kargo Firması"},{"Id":622761,"PropertyName":"value","Value":"Takip Numarası"},{"Id":322509,"PropertyName":"placeholder","Value":"Takip Numarası"},{"Id":155582,"PropertyName":"value","Value":"Oluşturma Tarihi"},{"Id":754863,"PropertyName":"startDatePlaceholder","Value":"Başlangıç"},{"Id":754863,"PropertyName":"endDatePlaceholder","Value":"Bitiş"},{"Id":38806,"PropertyName":"header","Value":"Gelişmiş Filtreler"},{"Id":366435,"PropertyName":"placeholder","Value":"Ürün Kodu veya Seri Numarası"},{"Id":194076,"PropertyName":"label","Value":"Ara"},{"Id":563467,"PropertyName":"label","Value":"Temizle"},{"Id":798263,"PropertyName":"title","Value":"Fiş No"},{"Id":734467,"PropertyName":"value","Value":"label"},{"Id":236229,"PropertyName":"title","Value":"Durum"},{"Id":518495,"PropertyName":"value","Value":"label"},{"Id":441275,"PropertyName":"title","Value":"Gönderen"},{"Id":64632,"PropertyName":"value","Value":"label"},{"Id":641342,"PropertyName":"title","Value":"Alıcı"},{"Id":931633,"PropertyName":"value","Value":"label"},{"Id":32130,"PropertyName":"title","Value":"Talep Sayısı"},{"Id":986507,"PropertyName":"value","Value":"label"},{"Id":162142,"PropertyName":"title","Value":"Ürün Adedi"},{"Id":50720,"PropertyName":"value","Value":"label"},{"Id":354813,"PropertyName":"title","Value":"Kargo Firması"},{"Id":395203,"PropertyName":"value","Value":"label"},{"Id":884298,"PropertyName":"title","Value":"Takip Numarası"},{"Id":676531,"PropertyName":"value","Value":"label"},{"Id":600501,"PropertyName":"title","Value":"Nebim Fiş No"},{"Id":286056,"PropertyName":"value","Value":"label"},{"Id":762539,"PropertyName":"title","Value":"Transfer Tarihi"},{"Id":841917,"PropertyName":"value","Value":"label"},{"Id":448406,"PropertyName":"title","Value":"Geçen Süre"},{"Id":363773,"PropertyName":"value","Value":"label"},{"Id":20149,"PropertyName":"title","Value":"İşlemler"},{"Id":351905,"PropertyName":"label","Value":"Fiş Detayı"},{"Id":966195,"PropertyName":"label","Value":"Menü"},{"Id":265279,"PropertyName":"value","Value":"46 kayıttan 1–25 arası gösteriliyor"},{"Id":442611,"PropertyName":"tab","Value":"Tamamlananlar 34"}]}]
    defaultML = "en_US"
    
    screenHash = ""
    


    constructor(props) {
        super(props);
		this.transferfisleri_687916_value_kuikaTextInputRef = React.createRef();
		this.transferfisleri_956980_value_kuikaTextInputRef = React.createRef();
		this.transferfisleri_413834_value_kuikaAutoCompleteRef = React.createRef();
		this.transferfisleri_402197_value_kuikaAutoCompleteRef = React.createRef();
		this.transferfisleri_539143_value_kuikaAutoCompleteRef = React.createRef();
		this.transferfisleri_322509_value_kuikaTextInputRef = React.createRef();
		this.transferfisleri_366435_value_kuikaTextInputRef = React.createRef();
		this.transferfisleri_217734_value_kuikaTableRef = React.createRef();
		this.transferfisleri_618397_value_kuikaPaginationRef = React.createRef();

        this.state = {
            isSpinnerVisible: false,
            isPageVisible: false,
            isLeftMenuVisible: false,
            spinnerCount: 0,
            selectedLanguage: "",
            isPageInitLoaded: false,
            isPageRecurringLoaded: false,
            	        dataSource_413834: [{"key":"adana","text":"Adana Times"},{"key":"mersin","text":"Mersin Times"},{"key":"antalya","text":"Antalya Times"}],
	        dataSource_402197: [{"key":"merkez","text":"Merkez"},{"key":"adana","text":"Adana Times"},{"key":"gaziantep","text":"Gaziantep Times"}],
	        dataSource_379874: [{"key":"sent","text":"Transfer Edildi"},{"key":"road","text":"Yolda"},{"key":"accept","text":"Kabul İşleminde"}],
	        dataSource_539143: [{"key":"aras","text":"Aras Kargo"},{"key":"yurtici","text":"Yurtiçi Kargo"},{"key":"mng","text":"MNG Kargo"}],

        }

        this.state.isPageVisible = true;
        
    }

    async componentDidMount() {

        if (KuikaAppManager.isPageInitPrevented()) {
            KuikaAppManager.calculateAndSetBodyHeight("transferfisleri", "");
            return;
        }
        
        
        ReactSystemFunctions.validateToken()
        this.fillFormInitValues();
        if (true){
            
        }
        
        
        
        KuikaAppManager.calculateAndSetBodyHeight("transferfisleri", "");

        if (ReactSystemFunctions.getIsMicroApp() === false) {
           window.parentScreen = this;
        }
    }

    componentWillUnmount() {
        
        
        

        if (ReactSystemFunctions.getIsMicroApp() === false) {
           window.parentScreen = null;
        }
    }

    

        
    componentDidUpdate= async (prevProps, prevState) => {
		KuikaAppManager.calculateAndSetBodyHeight("transferfisleri", ""    );
        if (prevProps?.location?.search !== (this.props as any)?.location?.search) {
			
		}

        

        if (ReactSystemFunctions.getIsMicroApp() === false) {
            for (const key in prevState) {
                if (key.startsWith('NavVisible') && prevState[key] === true && this.state[key] === false) {
                    window.parentScreen = this;
                    break;
                }
            }
        }
	}

    fillFormInitValues() {
        this.props.form?.setFieldsValue({
});

    }

      setPageInitLoaded = (value: boolean) => {
        this.setState({ isPageInitLoaded: value });
      }

      setPageRecurringLoaded = (value: boolean) => {
        this.setState({ isPageRecurringLoaded: value });
      }

      clearFieldValidation = (changedValues: any) => {
        const fieldName = Object.keys(changedValues)[0];
        if (fieldName) {
          this.props.form?.setFields([
            {
              name: fieldName,
              errors: []
            }
          ]);
        }
      };

        checkTabErrors = () => {
    document.querySelectorAll(".rc-tabs-tab").forEach((tab) => {
      (tab as HTMLElement).style.color = "";
    });

    const tabPanes = document.querySelectorAll(".rc-tabs-tabpane");
    const tabs = document.querySelectorAll(".rc-tabs-tab");

    tabPanes.forEach((tabPane, index) => {
      const uniquePaneId = `rc-tabs-tabpane-${index}`;
      if (!tabPane.hasAttribute("id")) {
        tabPane.setAttribute("id", uniquePaneId); 
      }

      const uniqueTabId = `rc-tabs-tab-${index}`;
      if (tabs[index]) {
        if (!tabs[index].hasAttribute("id")) {
          tabs[index].setAttribute("id", uniqueTabId); 
        }
        tabs[index].setAttribute("aria-controls", uniquePaneId);
      }
    });

    const errorElements = document.querySelectorAll(".rc-tabs .ant-form-item-explain-error");

    const tabsWithErrors = new Set<string>();

    errorElements.forEach((errorElement) => {
      const tabPane = errorElement.closest(".rc-tabs-tabpane");
      if (tabPane && tabPane.id) {
        tabsWithErrors.add(tabPane.id);
      }
    });

    tabsWithErrors.forEach((tabPaneId) => {
      const tab = document.querySelector(`.rc-tabs-tab[aria-controls="${tabPaneId}"]`);
      if (tab) {
        (tab as HTMLElement).style.color = "red"; 
      }
    });
  };




    async callCallbackFunction(diId: number, isFromMaster: boolean = false) {
        let isErrorOccurred = false;

    }


}
