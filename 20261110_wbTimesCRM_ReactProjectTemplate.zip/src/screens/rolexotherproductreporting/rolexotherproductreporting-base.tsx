import React from "react";
import Axios, { AxiosResponse } from "axios";
import { KuikaAppManager } from "../../shared/utilty/kuika-app-manager";
import { ReactSystemFunctions } from "../../shared/utilty/react-system-functions";
import { KNavigator } from "../../shared/hoc/with-history";
import { KContext } from "../../shared/hoc/with-context";
import { useLocation } from "react-router-dom";
import { FormInstance } from "antd/es/form";
import { Guid } from "guid-typescript";
import Swal from "sweetalert2";
import { KMainFunctions } from "../../shared/utilty/main-functions";
import moment from "moment";
import { IValidationData } from "../../models/dto/validation-data";
import { IStripePayment } from "../../models/dto/stripe-payment";
import { IUserInfoDto } from "../../models/dto/user-info.dto";
import { UserService } from "../../services/user-service";
import { kuikaCoreWasmBridgeService } from "../../services/_singletons";
import _ from "lodash";
import mqtt, { MqttClient } from "mqtt";
import { IMqttResult } from "../../models/dto/mqtt.dto";
import { MasterScreen_ScreenContext } from "../masterscreen/masterscreen-context";

declare let window: any;

export interface IRolexOtherProductReporting_ScreenProps {
  navigator: KNavigator;
  form: FormInstance<any>;
  googleLogin: any;
  screenInputs: any;
  context: KContext;
  initialValues: any;
  children: any;
}

export interface IRolexOtherProductReporting_ScreenState {
    isSpinnerVisible: boolean;
    isPageVisible: boolean;
	isLeftMenuVisible: boolean;
    spinnerCount: number;
    selectedLanguage: string;
    isPageInitLoaded: false;
    isPageRecurringLoaded: false;
	KuikaY_RolexGrupAylikSatisKarsilastirma_S1: any[];
	KuikaY_RolexGrupAylikSatisKarsilastirma_S1_dummy: any[];
	KuikaY_RolexGrupAylikSatisKarsilastirma_S2: any[];
	KuikaY_RolexGrupAylikSatisKarsilastirma_S2_dummy: any[];
	KuikaY_RolexGrupAylikSatisKarsilastirma_S3: any[];
	KuikaY_RolexGrupAylikSatisKarsilastirma_S3_dummy: any[];
	NAVIGATE: any;
	NAVIGATE_dummy: any;
	ExportExcel: any;
	ExportExcel_dummy: any;
	isComp113085Visible: 'visible' | 'hidden';
	isComp626227Visible: 'visible' | 'hidden';
	isComp161669Visible: 'visible' | 'hidden';
	isComp287775Visible: 'visible' | 'hidden';
	isComp586282Visible: 'visible' | 'hidden';
	isComp583930Visible: 'visible' | 'hidden';
	isComp579785Visible: 'visible' | 'hidden';
	isComp538425Visible: 'visible' | 'hidden';
	isComp921751Visible: 'visible' | 'hidden';
	isComp168185Visible: 'visible' | 'hidden';
	isComp221926Visible: 'visible' | 'hidden';
	isComp147684Visible: 'visible' | 'hidden';
	isComp296451Visible: 'visible' | 'hidden';
	isComp62537Visible: 'visible' | 'hidden';
	isComp677622Visible: 'visible' | 'hidden';
	isComp978143Visible: 'visible' | 'hidden';
	isComp323662Visible: 'visible' | 'hidden';
	isComp901964Visible: 'visible' | 'hidden';
	isComp986714Visible: 'visible' | 'hidden';
	isComp335343Visible: 'visible' | 'hidden';
	isComp105059Visible: 'visible' | 'hidden';
	isComp928119Visible: 'visible' | 'hidden';
	isComp903909Visible: 'visible' | 'hidden';
	isComp957716Visible: 'visible' | 'hidden';
	isComp217755Visible: 'visible' | 'hidden';
	isComp50459Visible: 'visible' | 'hidden';
	isComp715114Visible: 'visible' | 'hidden';
	isComp218606Visible: 'visible' | 'hidden';
	isComp845403Visible: 'visible' | 'hidden';
	isComp187868Visible: 'visible' | 'hidden';
	isComp617807Visible: 'visible' | 'hidden';
	isComp736888Visible: 'visible' | 'hidden';
	isComp750573Visible: 'visible' | 'hidden';
	isComp517683Visible: 'visible' | 'hidden';
	isComp211529Visible: 'visible' | 'hidden';
	isComp376481Visible: 'visible' | 'hidden';
	isComp417983Visible: 'visible' | 'hidden';
	isComp187538Visible: 'visible' | 'hidden';
	isComp978033Visible: 'visible' | 'hidden';
	isComp584012Visible: 'visible' | 'hidden';
	isComp360041Visible: 'visible' | 'hidden';
	isComp610944Visible: 'visible' | 'hidden';
	isComp151940Visible: 'visible' | 'hidden';
	isComp765709Visible: 'visible' | 'hidden';
	isComp754337Visible: 'visible' | 'hidden';
	isComp781791Visible: 'visible' | 'hidden';
	isComp497524Visible: 'visible' | 'hidden';
	isComp964317Visible: 'visible' | 'hidden';
	isComp239462Visible: 'visible' | 'hidden';
	isComp857528Visible: 'visible' | 'hidden';
	isComp681283Visible: 'visible' | 'hidden';
	isComp390216Visible: 'visible' | 'hidden';
	isComp148761Visible: 'visible' | 'hidden';
	isComp466811Visible: 'visible' | 'hidden';
	isComp399425Visible: 'visible' | 'hidden';
	isComp994014Visible: 'visible' | 'hidden';
	isComp578783Visible: 'visible' | 'hidden';
	isComp600306Visible: 'visible' | 'hidden';
	isComp482131Visible: 'visible' | 'hidden';
	isComp640218Visible: 'visible' | 'hidden';
	isComp518732Visible: 'visible' | 'hidden';
	isComp965830Visible: 'visible' | 'hidden';
	isComp766286Visible: 'visible' | 'hidden';
	isComp506019Visible: 'visible' | 'hidden';
	isComp423425Visible: 'visible' | 'hidden';
	isComp238705Visible: 'visible' | 'hidden';
	isComp48092Visible: 'visible' | 'hidden';
	isComp198035Visible: 'visible' | 'hidden';
	isComp1323Visible: 'visible' | 'hidden';
	isComp601309Visible: 'visible' | 'hidden';
	isComp487652Visible: 'visible' | 'hidden';
	isComp408188Visible: 'visible' | 'hidden';
	isComp163264Visible: 'visible' | 'hidden';
	isComp595496Visible: 'visible' | 'hidden';

}

export class RolexOtherProductReporting_ScreenBase extends React.PureComponent<IRolexOtherProductReporting_ScreenProps, any> {
    static contextType = MasterScreen_ScreenContext;
    declare context: React.ContextType<typeof MasterScreen_ScreenContext>;
	rolexotherproductreporting_275766_value_kuikaTableRef: React.RefObject<any>;
	rolexotherproductreporting_518172_value_kuikaTableRef: React.RefObject<any>;
	rolexotherproductreporting_718974_value_kuikaTableRef: React.RefObject<any>;
	rolexotherproductreporting_792925_value_kuikaTableRef: React.RefObject<any>;
	rolexotherproductreporting_709026_value_kuikaTableRef: React.RefObject<any>;
	rolexotherproductreporting_277280_value_kuikaTableRef: React.RefObject<any>;
	rolexotherproductreporting_229235_value_kuikaTableRef: React.RefObject<any>;
	rolexotherproductreporting_945811_value_kuikaTableRef: React.RefObject<any>;
	rolexotherproductreporting_129469_value_kuikaTableRef: React.RefObject<any>;
	rolexotherproductreporting_135272_value_kuikaTableRef: React.RefObject<any>;
	rolexotherproductreporting_454237_value_kuikaTableRef: React.RefObject<any>;
	rolexotherproductreporting_740992_value_kuikaTableRef: React.RefObject<any>;
	rolexotherproductreporting_954334_value_kuikaTableRef: React.RefObject<any>;
	rolexotherproductreporting_560631_value_kuikaTableRef: React.RefObject<any>;
	rolexotherproductreporting_771338_value_kuikaTableRef: React.RefObject<any>;
	rolexotherproductreporting_98342_value_kuikaTableRef: React.RefObject<any>;
	rolexotherproductreporting_959130_value_kuikaTableRef: React.RefObject<any>;
	rolexotherproductreporting_663232_value_kuikaTableRef: React.RefObject<any>;
	rolexotherproductreporting_936158_value_kuikaTableRef: React.RefObject<any>;
	rolexotherproductreporting_921927_value_kuikaTableRef: React.RefObject<any>;
	rolexotherproductreporting_399719_value_kuikaTableRef: React.RefObject<any>;
	rolexotherproductreporting_887255_value_kuikaTableRef: React.RefObject<any>;
	rolexotherproductreporting_927967_value_kuikaTableRef: React.RefObject<any>;
	rolexotherproductreporting_547472_value_kuikaTableRef: React.RefObject<any>;
	rolexotherproductreporting_937402_value_kuikaTableRef: React.RefObject<any>;
	rolexotherproductreporting_217447_value_kuikaTableRef: React.RefObject<any>;
	rolexotherproductreporting_288283_value_kuikaTableRef: React.RefObject<any>;
	rolexotherproductreporting_637605_value_kuikaTableRef: React.RefObject<any>;
	rolexotherproductreporting_618611_value_kuikaTableRef: React.RefObject<any>;
	rolexotherproductreporting_707740_value_kuikaTableRef: React.RefObject<any>;
	rolexotherproductreporting_248545_value_kuikaTableRef: React.RefObject<any>;
	rolexotherproductreporting_458677_value_kuikaTableRef: React.RefObject<any>;
	rolexotherproductreporting_629750_value_kuikaTableRef: React.RefObject<any>;
	rolexotherproductreporting_649122_value_kuikaTableRef: React.RefObject<any>;
	rolexotherproductreporting_644418_value_kuikaTableRef: React.RefObject<any>;
	rolexotherproductreporting_371718_value_kuikaTableRef: React.RefObject<any>;
    ml=[{"Id":"d5a61d2b-bd60-485f-86e2-661e9ed4e486","Name":"en_US","ShortName":"English","IsDefault":true,"LanguagePhrases":[]},{"Id":"818f7a28-1d21-42f6-90ee-ac0cbb7ae080","Name":"FixedValues","ShortName":"FixedValues","LanguagePhrases":[{"Id":910240,"PropertyName":"value","Value":"Marka Bazlı Raporlama"},{"Id":869891,"PropertyName":"value","Value":"Mağaza satış performanslarını karşılaştırmalı olarak analiz edin."},{"Id":445085,"PropertyName":"label","Value":"Rolex"},{"Id":311444,"PropertyName":"label","Value":"Tudor"},{"Id":20847,"PropertyName":"label","Value":"Mont Blanc"},{"Id":629388,"PropertyName":"label","Value":"Dupont"},{"Id":126713,"PropertyName":"value","Value":"Analiz Tipi"},{"Id":248363,"PropertyName":"value","Value":"Genel Satış"},{"Id":640909,"PropertyName":"value","Value":"Family Bazlı"},{"Id":774535,"PropertyName":"value","Value":"Material Bazlı"},{"Id":359129,"PropertyName":"value","Value":"Diameter Bazlı"},{"Id":384797,"PropertyName":"value","Value":"Ürün Grubu Bazlı"},{"Id":242895,"PropertyName":"value","Value":"Toplam Satış Adedi"},{"Id":570827,"PropertyName":"value","Value":"1,247"},{"Id":869642,"PropertyName":"value","Value":"+18.5%"},{"Id":791845,"PropertyName":"value","Value":"-18.5%"},{"Id":113469,"PropertyName":"value","Value":"Toplam Ciro"},{"Id":844586,"PropertyName":"value","Value":"₺42.5M"},{"Id":134433,"PropertyName":"value","Value":"+18.5%"},{"Id":266671,"PropertyName":"value","Value":"-18.5%"},{"Id":29709,"PropertyName":"value","Value":"Geçen Yıla Göre Artış"},{"Id":393484,"PropertyName":"value","Value":"+32.8%"},{"Id":979185,"PropertyName":"value","Value":"Yıllık Büyüme"},{"Id":440243,"PropertyName":"value","Value":"En Güçlü Mağaza"},{"Id":811623,"PropertyName":"value","Value":"Adana"},{"Id":64426,"PropertyName":"value","Value":"₺8.2M Ciro"},{"Id":413268,"PropertyName":"value","Value":"En Çok Satan Family"},{"Id":560829,"PropertyName":"value","Value":"Submariner"},{"Id":631265,"PropertyName":"value","Value":"342 Adet"},{"Id":24580,"PropertyName":"value","Value":"En Çok Satan Material"},{"Id":69173,"PropertyName":"value","Value":"Yellow Gold"},{"Id":503969,"PropertyName":"value","Value":"₺12.4M Ciro"},{"Id":661254,"PropertyName":"value","Value":"Ürün Gruplarına Göre Aylık Satış Raporları - Rolex"},{"Id":153314,"PropertyName":"tab","Value":"Kol Düğmesi"},{"Id":675461,"PropertyName":"value","Value":"Yıl 1"},{"Id":585930,"PropertyName":"placeholder","Value":"Select Year..."},{"Id":3956,"PropertyName":"value","Value":"Yıl 2"},{"Id":420182,"PropertyName":"placeholder","Value":"Select Year..."},{"Id":775349,"PropertyName":"label","Value":"Uygula"},{"Id":50575,"PropertyName":"value","Value":"Ocak/"},{"Id":782674,"PropertyName":"value","Value":"-"},{"Id":528609,"PropertyName":"title","Value":"Mağaza"},{"Id":770434,"PropertyName":"value","Value":"[datafield:magaza]"},{"Id":520370,"PropertyName":"value","Value":"[datafield:ocak2025]"},{"Id":678386,"PropertyName":"value","Value":"[datafield:ocak2026]"},{"Id":751151,"PropertyName":"title","Value":"Değişim"},{"Id":161669,"PropertyName":"value","Value":"[datafield:ocakdegisim]"},{"Id":287775,"PropertyName":"value","Value":"[datafield:ocakdegisim]"},{"Id":895620,"PropertyName":"value","Value":"Şubat/"},{"Id":973528,"PropertyName":"value","Value":"-"},{"Id":625857,"PropertyName":"title","Value":"Mağaza"},{"Id":233641,"PropertyName":"value","Value":"[datafield:magaza]"},{"Id":908604,"PropertyName":"value","Value":"[datafield:subat2025]"},{"Id":353227,"PropertyName":"value","Value":"[datafield:subat2026]"},{"Id":400801,"PropertyName":"title","Value":"Değişim"},{"Id":586282,"PropertyName":"value","Value":"[datafield:subatdegisim]"},{"Id":583930,"PropertyName":"value","Value":"[datafield:subatdegisim]"},{"Id":691970,"PropertyName":"value","Value":"Mart/"},{"Id":263781,"PropertyName":"value","Value":"-"},{"Id":808847,"PropertyName":"title","Value":"Mağaza"},{"Id":625425,"PropertyName":"value","Value":"[datafield:magaza]"},{"Id":29624,"PropertyName":"value","Value":"[datafield:mart2025]"},{"Id":371237,"PropertyName":"value","Value":"[datafield:mart2026]"},{"Id":600072,"PropertyName":"title","Value":"Değişim"},{"Id":579785,"PropertyName":"value","Value":"[datafield:martdegisim]"},{"Id":538425,"PropertyName":"value","Value":"[datafield:martdegisim]"},{"Id":27868,"PropertyName":"value","Value":"Nisan/"},{"Id":702874,"PropertyName":"value","Value":"-"},{"Id":359928,"PropertyName":"title","Value":"Mağaza"},{"Id":479834,"PropertyName":"value","Value":"[datafield:magaza]"},{"Id":2066,"PropertyName":"value","Value":"[datafield:nisan2025]"},{"Id":175696,"PropertyName":"value","Value":"[datafield:nisan2026]"},{"Id":237367,"PropertyName":"title","Value":"Değişim"},{"Id":921751,"PropertyName":"value","Value":"[datafield:nisandegisim]"},{"Id":168185,"PropertyName":"value","Value":"[datafield:nisandegisim]"},{"Id":827705,"PropertyName":"value","Value":"Mayıs/"},{"Id":589005,"PropertyName":"value","Value":"-"},{"Id":453498,"PropertyName":"title","Value":"Mağaza"},{"Id":50465,"PropertyName":"value","Value":"[datafield:magaza]"},{"Id":988715,"PropertyName":"value","Value":"[datafield:mayis2025]"},{"Id":351807,"PropertyName":"value","Value":"[datafield:mayis2026]"},{"Id":489797,"PropertyName":"title","Value":"Değişim"},{"Id":221926,"PropertyName":"value","Value":"[datafield:mayisdegisim]"},{"Id":147684,"PropertyName":"value","Value":"[datafield:mayisdegisim]"},{"Id":1951,"PropertyName":"value","Value":"Haziran/"},{"Id":651229,"PropertyName":"value","Value":"-"},{"Id":657260,"PropertyName":"title","Value":"Mağaza"},{"Id":220864,"PropertyName":"value","Value":"[datafield:magaza]"},{"Id":732528,"PropertyName":"value","Value":"[datafield:haziran2025]"},{"Id":632356,"PropertyName":"value","Value":"[datafield:haziran2026]"},{"Id":641804,"PropertyName":"title","Value":"Değişim"},{"Id":296451,"PropertyName":"value","Value":"[datafield:hazirandegisim]"},{"Id":62537,"PropertyName":"value","Value":"[datafield:hazirandegisim]"},{"Id":527213,"PropertyName":"value","Value":"Temmuz/"},{"Id":87121,"PropertyName":"value","Value":"-"},{"Id":804733,"PropertyName":"title","Value":"Mağaza"},{"Id":129301,"PropertyName":"value","Value":"[datafield:magaza]"},{"Id":796152,"PropertyName":"value","Value":"[datafield:temmuz2025]"},{"Id":478412,"PropertyName":"value","Value":"[datafield:temmuz2026]"},{"Id":899806,"PropertyName":"title","Value":"Değişim"},{"Id":677622,"PropertyName":"value","Value":"[datafield:temmuzdegisim]"},{"Id":978143,"PropertyName":"value","Value":"[datafield:temmuzdegisim]"},{"Id":295517,"PropertyName":"value","Value":"Ağustos/"},{"Id":252912,"PropertyName":"value","Value":"-"},{"Id":920558,"PropertyName":"title","Value":"Mağaza"},{"Id":192189,"PropertyName":"value","Value":"[datafield:magaza]"},{"Id":204439,"PropertyName":"value","Value":"[datafield:agustos2025]"},{"Id":445789,"PropertyName":"value","Value":"[datafield:agustos2026]"},{"Id":769144,"PropertyName":"title","Value":"Değişim"},{"Id":323662,"PropertyName":"value","Value":"[datafield:agustosdegisim]"},{"Id":901964,"PropertyName":"value","Value":"[datafield:agustosdegisim]"},{"Id":918766,"PropertyName":"value","Value":"Eylül/"},{"Id":343652,"PropertyName":"value","Value":"-"},{"Id":178179,"PropertyName":"title","Value":"Mağaza"},{"Id":352622,"PropertyName":"value","Value":"[datafield:magaza]"},{"Id":260226,"PropertyName":"value","Value":"[datafield:eylul2025]"},{"Id":698666,"PropertyName":"value","Value":"[datafield:eylul2026]"},{"Id":693248,"PropertyName":"title","Value":"Değişim"},{"Id":986714,"PropertyName":"value","Value":"[datafield:eyluldegisim]"},{"Id":335343,"PropertyName":"value","Value":"[datafield:eyluldegisim]"},{"Id":684645,"PropertyName":"value","Value":"Ekim/"},{"Id":109658,"PropertyName":"value","Value":"-"},{"Id":823040,"PropertyName":"title","Value":"Mağaza"},{"Id":573000,"PropertyName":"value","Value":"[datafield:magaza]"},{"Id":682258,"PropertyName":"value","Value":"[datafield:ekim2025]"},{"Id":968948,"PropertyName":"value","Value":"[datafield:ekim2026]"},{"Id":297615,"PropertyName":"title","Value":"Değişim"},{"Id":105059,"PropertyName":"value","Value":"[datafield:ekimdegisim]"},{"Id":928119,"PropertyName":"value","Value":"[datafield:ekimdegisim]"},{"Id":916214,"PropertyName":"value","Value":"Kasım/"},{"Id":785069,"PropertyName":"value","Value":"-"},{"Id":100350,"PropertyName":"title","Value":"Mağaza"},{"Id":99178,"PropertyName":"value","Value":"[datafield:magaza]"},{"Id":743591,"PropertyName":"value","Value":"[datafield:kasim2025]"},{"Id":962777,"PropertyName":"value","Value":"[datafield:kasim2026]"},{"Id":327419,"PropertyName":"title","Value":"Değişim"},{"Id":903909,"PropertyName":"value","Value":"[datafield:kasimdegisim]"},{"Id":957716,"PropertyName":"value","Value":"[datafield:kasimdegisim]"},{"Id":407104,"PropertyName":"value","Value":"Aralık/"},{"Id":411435,"PropertyName":"value","Value":"-"},{"Id":57646,"PropertyName":"title","Value":"Mağaza"},{"Id":928570,"PropertyName":"value","Value":"[datafield:magaza]"},{"Id":869193,"PropertyName":"value","Value":"[datafield:aralik2025]"},{"Id":940177,"PropertyName":"value","Value":"[datafield:aralik2026]"},{"Id":275230,"PropertyName":"title","Value":"Değişim"},{"Id":217755,"PropertyName":"value","Value":"[datafield:aralikdegisim]"},{"Id":50459,"PropertyName":"value","Value":"[datafield:aralikdegisim]"},{"Id":460945,"PropertyName":"tab","Value":"Kitap"},{"Id":348782,"PropertyName":"value","Value":"Yıl 1"},{"Id":556215,"PropertyName":"placeholder","Value":"Select Year..."},{"Id":433704,"PropertyName":"value","Value":"Yıl 2"},{"Id":131933,"PropertyName":"placeholder","Value":"Select Year..."},{"Id":736558,"PropertyName":"label","Value":"Uygula"},{"Id":437464,"PropertyName":"value","Value":"Ocak/"},{"Id":358609,"PropertyName":"value","Value":"-"},{"Id":731790,"PropertyName":"title","Value":"Mağaza"},{"Id":239347,"PropertyName":"value","Value":"[datafield:magaza]"},{"Id":664587,"PropertyName":"value","Value":"[datafield:ocak2025]"},{"Id":748955,"PropertyName":"value","Value":"[datafield:ocak2026]"},{"Id":943595,"PropertyName":"title","Value":"Değişim"},{"Id":715114,"PropertyName":"value","Value":"[datafield:ocakdegisim]"},{"Id":218606,"PropertyName":"value","Value":"[datafield:ocakdegisim]"},{"Id":28270,"PropertyName":"value","Value":"Şubat/"},{"Id":509072,"PropertyName":"value","Value":"-"},{"Id":69441,"PropertyName":"title","Value":"Mağaza"},{"Id":311882,"PropertyName":"value","Value":"[datafield:magaza]"},{"Id":389758,"PropertyName":"value","Value":"[datafield:subat2025]"},{"Id":528008,"PropertyName":"value","Value":"[datafield:subat2026]"},{"Id":53428,"PropertyName":"title","Value":"Değişim"},{"Id":845403,"PropertyName":"value","Value":"[datafield:subatdegisim]"},{"Id":187868,"PropertyName":"value","Value":"[datafield:subatdegisim]"},{"Id":975824,"PropertyName":"value","Value":"Mart/"},{"Id":656912,"PropertyName":"value","Value":"-"},{"Id":858784,"PropertyName":"title","Value":"Mağaza"},{"Id":216475,"PropertyName":"value","Value":"[datafield:magaza]"},{"Id":320939,"PropertyName":"value","Value":"[datafield:mart2025]"},{"Id":889649,"PropertyName":"value","Value":"[datafield:mart2026]"},{"Id":622844,"PropertyName":"title","Value":"Değişim"},{"Id":617807,"PropertyName":"value","Value":"[datafield:martdegisim]"},{"Id":736888,"PropertyName":"value","Value":"[datafield:martdegisim]"},{"Id":864125,"PropertyName":"value","Value":"Nisan/"},{"Id":581822,"PropertyName":"value","Value":"-"},{"Id":265825,"PropertyName":"title","Value":"Mağaza"},{"Id":196060,"PropertyName":"value","Value":"[datafield:magaza]"},{"Id":940612,"PropertyName":"value","Value":"[datafield:nisan2025]"},{"Id":763253,"PropertyName":"value","Value":"[datafield:nisan2026]"},{"Id":671031,"PropertyName":"title","Value":"Değişim"},{"Id":750573,"PropertyName":"value","Value":"[datafield:nisandegisim]"},{"Id":517683,"PropertyName":"value","Value":"[datafield:nisandegisim]"},{"Id":851957,"PropertyName":"value","Value":"Mayıs/"},{"Id":988426,"PropertyName":"value","Value":"-"},{"Id":677812,"PropertyName":"title","Value":"Mağaza"},{"Id":855509,"PropertyName":"value","Value":"[datafield:magaza]"},{"Id":514961,"PropertyName":"value","Value":"[datafield:mayis2025]"},{"Id":126212,"PropertyName":"value","Value":"[datafield:mayis2026]"},{"Id":156533,"PropertyName":"title","Value":"Değişim"},{"Id":211529,"PropertyName":"value","Value":"[datafield:mayisdegisim]"},{"Id":376481,"PropertyName":"value","Value":"[datafield:mayisdegisim]"},{"Id":4317,"PropertyName":"value","Value":"Haziran/"},{"Id":697135,"PropertyName":"value","Value":"-"},{"Id":262582,"PropertyName":"title","Value":"Mağaza"},{"Id":492768,"PropertyName":"value","Value":"[datafield:magaza]"},{"Id":217292,"PropertyName":"value","Value":"[datafield:haziran2025]"},{"Id":43903,"PropertyName":"value","Value":"[datafield:haziran2026]"},{"Id":419295,"PropertyName":"title","Value":"Değişim"},{"Id":417983,"PropertyName":"value","Value":"[datafield:hazirandegisim]"},{"Id":187538,"PropertyName":"value","Value":"[datafield:hazirandegisim]"},{"Id":4933,"PropertyName":"value","Value":"Temmuz/"},{"Id":332705,"PropertyName":"value","Value":"-"},{"Id":685356,"PropertyName":"title","Value":"Mağaza"},{"Id":586716,"PropertyName":"value","Value":"[datafield:magaza]"},{"Id":289834,"PropertyName":"value","Value":"[datafield:temmuz2025]"},{"Id":386489,"PropertyName":"value","Value":"[datafield:temmuz2026]"},{"Id":478930,"PropertyName":"title","Value":"Değişim"},{"Id":978033,"PropertyName":"value","Value":"[datafield:temmuzdegisim]"},{"Id":584012,"PropertyName":"value","Value":"[datafield:temmuzdegisim]"},{"Id":997996,"PropertyName":"value","Value":"Ağustos/"},{"Id":273010,"PropertyName":"value","Value":"-"},{"Id":144346,"PropertyName":"title","Value":"Mağaza"},{"Id":436053,"PropertyName":"value","Value":"[datafield:magaza]"},{"Id":716668,"PropertyName":"value","Value":"[datafield:agustos2025]"},{"Id":410138,"PropertyName":"value","Value":"[datafield:agustos2026]"},{"Id":227587,"PropertyName":"title","Value":"Değişim"},{"Id":360041,"PropertyName":"value","Value":"[datafield:agustosdegisim]"},{"Id":610944,"PropertyName":"value","Value":"[datafield:agustosdegisim]"},{"Id":100086,"PropertyName":"value","Value":"Eylül/"},{"Id":198393,"PropertyName":"value","Value":"-"},{"Id":613982,"PropertyName":"title","Value":"Mağaza"},{"Id":878418,"PropertyName":"value","Value":"[datafield:magaza]"},{"Id":267893,"PropertyName":"value","Value":"[datafield:eylul2025]"},{"Id":236795,"PropertyName":"value","Value":"[datafield:eylul2026]"},{"Id":755446,"PropertyName":"title","Value":"Değişim"},{"Id":151940,"PropertyName":"value","Value":"[datafield:eyluldegisim]"},{"Id":765709,"PropertyName":"value","Value":"[datafield:eyluldegisim]"},{"Id":875035,"PropertyName":"value","Value":"Ekim/"},{"Id":626052,"PropertyName":"value","Value":"-"},{"Id":492499,"PropertyName":"title","Value":"Mağaza"},{"Id":909699,"PropertyName":"value","Value":"[datafield:magaza]"},{"Id":670812,"PropertyName":"value","Value":"[datafield:ekim2025]"},{"Id":838454,"PropertyName":"value","Value":"[datafield:ekim2026]"},{"Id":548798,"PropertyName":"title","Value":"Değişim"},{"Id":754337,"PropertyName":"value","Value":"[datafield:ekimdegisim]"},{"Id":781791,"PropertyName":"value","Value":"[datafield:ekimdegisim]"},{"Id":703893,"PropertyName":"value","Value":"Kasım/"},{"Id":941654,"PropertyName":"value","Value":"-"},{"Id":965859,"PropertyName":"title","Value":"Mağaza"},{"Id":221733,"PropertyName":"value","Value":"[datafield:magaza]"},{"Id":981970,"PropertyName":"value","Value":"[datafield:kasim2025]"},{"Id":315868,"PropertyName":"value","Value":"[datafield:kasim2026]"},{"Id":260359,"PropertyName":"title","Value":"Değişim"},{"Id":497524,"PropertyName":"value","Value":"[datafield:kasimdegisim]"},{"Id":964317,"PropertyName":"value","Value":"[datafield:kasimdegisim]"},{"Id":151418,"PropertyName":"value","Value":"Aralık/"},{"Id":778048,"PropertyName":"value","Value":"-"},{"Id":541956,"PropertyName":"title","Value":"Mağaza"},{"Id":999397,"PropertyName":"value","Value":"[datafield:magaza]"},{"Id":320629,"PropertyName":"value","Value":"[datafield:aralik2025]"},{"Id":76929,"PropertyName":"value","Value":"[datafield:aralik2026]"},{"Id":449019,"PropertyName":"title","Value":"Değişim"},{"Id":239462,"PropertyName":"value","Value":"[datafield:aralikdegisim]"},{"Id":857528,"PropertyName":"value","Value":"[datafield:aralikdegisim]"},{"Id":789478,"PropertyName":"tab","Value":"Masa Saati"},{"Id":37628,"PropertyName":"value","Value":"Yıl 1"},{"Id":501380,"PropertyName":"placeholder","Value":"Select Year..."},{"Id":849416,"PropertyName":"value","Value":"Yıl 2"},{"Id":96734,"PropertyName":"placeholder","Value":"Select Year..."},{"Id":558385,"PropertyName":"label","Value":"Uygula"},{"Id":298826,"PropertyName":"value","Value":"Ocak/"},{"Id":393409,"PropertyName":"value","Value":"-"},{"Id":132624,"PropertyName":"title","Value":"Mağaza"},{"Id":447508,"PropertyName":"value","Value":"[datafield:magaza]"},{"Id":811826,"PropertyName":"value","Value":"[datafield:ocak2025]"},{"Id":317330,"PropertyName":"value","Value":"[datafield:ocak2026]"},{"Id":151483,"PropertyName":"title","Value":"Değişim"},{"Id":681283,"PropertyName":"value","Value":"[datafield:ocakdegisim]"},{"Id":390216,"PropertyName":"value","Value":"[datafield:ocakdegisim]"},{"Id":215270,"PropertyName":"value","Value":"Şubat/"},{"Id":43898,"PropertyName":"value","Value":"-"},{"Id":769513,"PropertyName":"title","Value":"Mağaza"},{"Id":705812,"PropertyName":"value","Value":"[datafield:magaza]"},{"Id":355190,"PropertyName":"value","Value":"[datafield:subat2025]"},{"Id":973064,"PropertyName":"value","Value":"[datafield:subat2026]"},{"Id":988700,"PropertyName":"title","Value":"Değişim"},{"Id":148761,"PropertyName":"value","Value":"[datafield:subatdegisim]"},{"Id":466811,"PropertyName":"value","Value":"[datafield:subatdegisim]"},{"Id":283088,"PropertyName":"value","Value":"Mart/"},{"Id":543183,"PropertyName":"value","Value":"-"},{"Id":791901,"PropertyName":"title","Value":"Mağaza"},{"Id":320120,"PropertyName":"value","Value":"[datafield:magaza]"},{"Id":159194,"PropertyName":"value","Value":"[datafield:mart2025]"},{"Id":824948,"PropertyName":"value","Value":"[datafield:mart2026]"},{"Id":347713,"PropertyName":"title","Value":"Değişim"},{"Id":399425,"PropertyName":"value","Value":"[datafield:martdegisim]"},{"Id":994014,"PropertyName":"value","Value":"[datafield:martdegisim]"},{"Id":772784,"PropertyName":"value","Value":"Nisan/"},{"Id":319312,"PropertyName":"value","Value":"-"},{"Id":156426,"PropertyName":"title","Value":"Mağaza"},{"Id":212350,"PropertyName":"value","Value":"[datafield:magaza]"},{"Id":622193,"PropertyName":"value","Value":"[datafield:nisan2025]"},{"Id":224433,"PropertyName":"value","Value":"[datafield:nisan2026]"},{"Id":471541,"PropertyName":"title","Value":"Değişim"},{"Id":578783,"PropertyName":"value","Value":"[datafield:nisandegisim]"},{"Id":600306,"PropertyName":"value","Value":"[datafield:nisandegisim]"},{"Id":69485,"PropertyName":"value","Value":"Mayıs/"},{"Id":321026,"PropertyName":"value","Value":"-"},{"Id":506740,"PropertyName":"title","Value":"Mağaza"},{"Id":390038,"PropertyName":"value","Value":"[datafield:magaza]"},{"Id":984825,"PropertyName":"value","Value":"[datafield:mayis2025]"},{"Id":301614,"PropertyName":"value","Value":"[datafield:mayis2026]"},{"Id":482779,"PropertyName":"title","Value":"Değişim"},{"Id":482131,"PropertyName":"value","Value":"[datafield:mayisdegisim]"},{"Id":640218,"PropertyName":"value","Value":"[datafield:mayisdegisim]"},{"Id":321907,"PropertyName":"value","Value":"Haziran/"},{"Id":235705,"PropertyName":"value","Value":"-"},{"Id":708317,"PropertyName":"title","Value":"Mağaza"},{"Id":776681,"PropertyName":"value","Value":"[datafield:magaza]"},{"Id":714266,"PropertyName":"value","Value":"[datafield:haziran2025]"},{"Id":719639,"PropertyName":"value","Value":"[datafield:haziran2026]"},{"Id":513124,"PropertyName":"title","Value":"Değişim"},{"Id":518732,"PropertyName":"value","Value":"[datafield:hazirandegisim]"},{"Id":965830,"PropertyName":"value","Value":"[datafield:hazirandegisim]"},{"Id":696073,"PropertyName":"value","Value":"Temmuz/"},{"Id":696274,"PropertyName":"value","Value":"-"},{"Id":92980,"PropertyName":"title","Value":"Mağaza"},{"Id":341231,"PropertyName":"value","Value":"[datafield:magaza]"},{"Id":21168,"PropertyName":"value","Value":"[datafield:temmuz2025]"},{"Id":425122,"PropertyName":"value","Value":"[datafield:temmuz2026]"},{"Id":198187,"PropertyName":"title","Value":"Değişim"},{"Id":766286,"PropertyName":"value","Value":"[datafield:temmuzdegisim]"},{"Id":506019,"PropertyName":"value","Value":"[datafield:temmuzdegisim]"},{"Id":212620,"PropertyName":"value","Value":"Ağustos/"},{"Id":477169,"PropertyName":"value","Value":"-"},{"Id":281158,"PropertyName":"title","Value":"Mağaza"},{"Id":8168,"PropertyName":"value","Value":"[datafield:magaza]"},{"Id":663437,"PropertyName":"value","Value":"[datafield:agustos2025]"},{"Id":214591,"PropertyName":"value","Value":"[datafield:agustos2026]"},{"Id":325195,"PropertyName":"title","Value":"Değişim"},{"Id":423425,"PropertyName":"value","Value":"[datafield:agustosdegisim]"},{"Id":238705,"PropertyName":"value","Value":"[datafield:agustosdegisim]"},{"Id":579154,"PropertyName":"value","Value":"Eylül/"},{"Id":471270,"PropertyName":"value","Value":"-"},{"Id":274466,"PropertyName":"title","Value":"Mağaza"},{"Id":535560,"PropertyName":"value","Value":"[datafield:magaza]"},{"Id":61930,"PropertyName":"value","Value":"[datafield:eylul2025]"},{"Id":152459,"PropertyName":"value","Value":"[datafield:eylul2026]"},{"Id":813276,"PropertyName":"title","Value":"Değişim"},{"Id":48092,"PropertyName":"value","Value":"[datafield:eyluldegisim]"},{"Id":198035,"PropertyName":"value","Value":"[datafield:eyluldegisim]"},{"Id":178958,"PropertyName":"value","Value":"Ekim/"},{"Id":880789,"PropertyName":"value","Value":"-"},{"Id":809328,"PropertyName":"title","Value":"Mağaza"},{"Id":839172,"PropertyName":"value","Value":"[datafield:magaza]"},{"Id":719737,"PropertyName":"value","Value":"[datafield:ekim2025]"},{"Id":391233,"PropertyName":"value","Value":"[datafield:ekim2026]"},{"Id":519382,"PropertyName":"title","Value":"Değişim"},{"Id":1323,"PropertyName":"value","Value":"[datafield:ekimdegisim]"},{"Id":601309,"PropertyName":"value","Value":"[datafield:ekimdegisim]"},{"Id":979174,"PropertyName":"value","Value":"Kasım/"},{"Id":129773,"PropertyName":"value","Value":"-"},{"Id":132559,"PropertyName":"title","Value":"Mağaza"},{"Id":470447,"PropertyName":"value","Value":"[datafield:magaza]"},{"Id":618441,"PropertyName":"value","Value":"[datafield:kasim2025]"},{"Id":973369,"PropertyName":"value","Value":"[datafield:kasim2026]"},{"Id":668436,"PropertyName":"title","Value":"Değişim"},{"Id":487652,"PropertyName":"value","Value":"[datafield:kasimdegisim]"},{"Id":408188,"PropertyName":"value","Value":"[datafield:kasimdegisim]"},{"Id":125168,"PropertyName":"value","Value":"Aralık/"},{"Id":869905,"PropertyName":"value","Value":"-"},{"Id":112571,"PropertyName":"title","Value":"Mağaza"},{"Id":550739,"PropertyName":"value","Value":"[datafield:magaza]"},{"Id":241441,"PropertyName":"value","Value":"[datafield:aralik2025]"},{"Id":518962,"PropertyName":"value","Value":"[datafield:aralik2026]"},{"Id":57491,"PropertyName":"title","Value":"Değişim"},{"Id":163264,"PropertyName":"value","Value":"[datafield:aralikdegisim]"},{"Id":595496,"PropertyName":"value","Value":"[datafield:aralikdegisim]"}]}]
    defaultML = "en_US"
    
    screenHash = ""
    

    private _prevMasterPageInitLoaded: boolean = false;
    private _prevMasterPageRecurringLoaded: boolean = false;
    private _prevShouldTriggerPageInit: boolean = false;
    constructor(props) {
        super(props);
		this.rolexotherproductreporting_275766_value_kuikaTableRef = React.createRef();
		this.rolexotherproductreporting_518172_value_kuikaTableRef = React.createRef();
		this.rolexotherproductreporting_718974_value_kuikaTableRef = React.createRef();
		this.rolexotherproductreporting_792925_value_kuikaTableRef = React.createRef();
		this.rolexotherproductreporting_709026_value_kuikaTableRef = React.createRef();
		this.rolexotherproductreporting_277280_value_kuikaTableRef = React.createRef();
		this.rolexotherproductreporting_229235_value_kuikaTableRef = React.createRef();
		this.rolexotherproductreporting_945811_value_kuikaTableRef = React.createRef();
		this.rolexotherproductreporting_129469_value_kuikaTableRef = React.createRef();
		this.rolexotherproductreporting_135272_value_kuikaTableRef = React.createRef();
		this.rolexotherproductreporting_454237_value_kuikaTableRef = React.createRef();
		this.rolexotherproductreporting_740992_value_kuikaTableRef = React.createRef();
		this.rolexotherproductreporting_954334_value_kuikaTableRef = React.createRef();
		this.rolexotherproductreporting_560631_value_kuikaTableRef = React.createRef();
		this.rolexotherproductreporting_771338_value_kuikaTableRef = React.createRef();
		this.rolexotherproductreporting_98342_value_kuikaTableRef = React.createRef();
		this.rolexotherproductreporting_959130_value_kuikaTableRef = React.createRef();
		this.rolexotherproductreporting_663232_value_kuikaTableRef = React.createRef();
		this.rolexotherproductreporting_936158_value_kuikaTableRef = React.createRef();
		this.rolexotherproductreporting_921927_value_kuikaTableRef = React.createRef();
		this.rolexotherproductreporting_399719_value_kuikaTableRef = React.createRef();
		this.rolexotherproductreporting_887255_value_kuikaTableRef = React.createRef();
		this.rolexotherproductreporting_927967_value_kuikaTableRef = React.createRef();
		this.rolexotherproductreporting_547472_value_kuikaTableRef = React.createRef();
		this.rolexotherproductreporting_937402_value_kuikaTableRef = React.createRef();
		this.rolexotherproductreporting_217447_value_kuikaTableRef = React.createRef();
		this.rolexotherproductreporting_288283_value_kuikaTableRef = React.createRef();
		this.rolexotherproductreporting_637605_value_kuikaTableRef = React.createRef();
		this.rolexotherproductreporting_618611_value_kuikaTableRef = React.createRef();
		this.rolexotherproductreporting_707740_value_kuikaTableRef = React.createRef();
		this.rolexotherproductreporting_248545_value_kuikaTableRef = React.createRef();
		this.rolexotherproductreporting_458677_value_kuikaTableRef = React.createRef();
		this.rolexotherproductreporting_629750_value_kuikaTableRef = React.createRef();
		this.rolexotherproductreporting_649122_value_kuikaTableRef = React.createRef();
		this.rolexotherproductreporting_644418_value_kuikaTableRef = React.createRef();
		this.rolexotherproductreporting_371718_value_kuikaTableRef = React.createRef();

        this.state = {
            isSpinnerVisible: false,
            isPageVisible: false,
            isLeftMenuVisible: false,
            spinnerCount: 0,
            selectedLanguage: "",
            isPageInitLoaded: false,
            isPageRecurringLoaded: false,
            	        KuikaY_RolexGrupAylikSatisKarsilastirma_S1: [],
	        KuikaY_RolexGrupAylikSatisKarsilastirma_S2: [],
	        KuikaY_RolexGrupAylikSatisKarsilastirma_S3: [],
	        NAVIGATE: "",
	        ExportExcel: "",
	        isComp113085Visible: 'hidden',
	        isComp626227Visible: 'hidden',
	        isComp161669Visible: 'hidden',
	        isComp287775Visible: 'hidden',
	        isComp586282Visible: 'hidden',
	        isComp583930Visible: 'hidden',
	        isComp579785Visible: 'hidden',
	        isComp538425Visible: 'hidden',
	        isComp921751Visible: 'hidden',
	        isComp168185Visible: 'hidden',
	        isComp221926Visible: 'hidden',
	        isComp147684Visible: 'hidden',
	        isComp296451Visible: 'hidden',
	        isComp62537Visible: 'hidden',
	        isComp677622Visible: 'hidden',
	        isComp978143Visible: 'hidden',
	        isComp323662Visible: 'hidden',
	        isComp901964Visible: 'hidden',
	        isComp986714Visible: 'hidden',
	        isComp335343Visible: 'hidden',
	        isComp105059Visible: 'hidden',
	        isComp928119Visible: 'hidden',
	        isComp903909Visible: 'hidden',
	        isComp957716Visible: 'hidden',
	        isComp217755Visible: 'hidden',
	        isComp50459Visible: 'hidden',
	        isComp715114Visible: 'hidden',
	        isComp218606Visible: 'hidden',
	        isComp845403Visible: 'hidden',
	        isComp187868Visible: 'hidden',
	        isComp617807Visible: 'hidden',
	        isComp736888Visible: 'hidden',
	        isComp750573Visible: 'hidden',
	        isComp517683Visible: 'hidden',
	        isComp211529Visible: 'hidden',
	        isComp376481Visible: 'hidden',
	        isComp417983Visible: 'hidden',
	        isComp187538Visible: 'hidden',
	        isComp978033Visible: 'hidden',
	        isComp584012Visible: 'hidden',
	        isComp360041Visible: 'hidden',
	        isComp610944Visible: 'hidden',
	        isComp151940Visible: 'hidden',
	        isComp765709Visible: 'hidden',
	        isComp754337Visible: 'hidden',
	        isComp781791Visible: 'hidden',
	        isComp497524Visible: 'hidden',
	        isComp964317Visible: 'hidden',
	        isComp239462Visible: 'hidden',
	        isComp857528Visible: 'hidden',
	        isComp681283Visible: 'hidden',
	        isComp390216Visible: 'hidden',
	        isComp148761Visible: 'hidden',
	        isComp466811Visible: 'hidden',
	        isComp399425Visible: 'hidden',
	        isComp994014Visible: 'hidden',
	        isComp578783Visible: 'hidden',
	        isComp600306Visible: 'hidden',
	        isComp482131Visible: 'hidden',
	        isComp640218Visible: 'hidden',
	        isComp518732Visible: 'hidden',
	        isComp965830Visible: 'hidden',
	        isComp766286Visible: 'hidden',
	        isComp506019Visible: 'hidden',
	        isComp423425Visible: 'hidden',
	        isComp238705Visible: 'hidden',
	        isComp48092Visible: 'hidden',
	        isComp198035Visible: 'hidden',
	        isComp1323Visible: 'hidden',
	        isComp601309Visible: 'hidden',
	        isComp487652Visible: 'hidden',
	        isComp408188Visible: 'hidden',
	        isComp163264Visible: 'hidden',
	        isComp595496Visible: 'hidden',

        }

        this.state.isPageVisible = true;
        
    }

    async componentDidMount() {

        if (KuikaAppManager.isPageInitPrevented()) {
            KuikaAppManager.calculateAndSetBodyHeight("rolexotherproductreporting", "masterscreen_screen");
            return;
        }
        this.context.registerCallbackFunction(this.callCallbackFunction.bind(this));
        
        ReactSystemFunctions.validateToken()
        this.fillFormInitValues();
        if (false){
            await this.RolexOtherProductReportingPageInit();
        } else if (this.context?.isMasterPageInitLoaded) { this._prevMasterPageInitLoaded = true; await this.RolexOtherProductReportingPageInit(); }
        
        
        
        KuikaAppManager.calculateAndSetBodyHeight("rolexotherproductreporting", "masterscreen_screen");

        if (ReactSystemFunctions.getIsMicroApp() === false) {
           window.parentScreen = this;
        }
    }

    componentWillUnmount() {
        
        
        

        if (ReactSystemFunctions.getIsMicroApp() === false) {
           window.parentScreen = null;
        }
    }

    

        
    componentDidUpdate= async (prevProps, prevState) => {
		KuikaAppManager.calculateAndSetBodyHeight("rolexotherproductreporting", "masterscreen_screen"    );
        if (prevProps?.location?.search !== (this.props as any)?.location?.search) {
			await this.RolexOtherProductReportingPageInit();
		}

        		if (this._prevMasterPageInitLoaded !== this.context.isMasterPageInitLoaded && this.context.isMasterPageInitLoaded === true) {this._prevMasterPageInitLoaded = this.context.isMasterPageInitLoaded;await this.RolexOtherProductReportingPageInit()}


        if (ReactSystemFunctions.getIsMicroApp() === false) {
            for (const key in prevState) {
                if (key.startsWith('NavVisible') && prevState[key] === true && this.state[key] === false) {
                    window.parentScreen = this;
                    break;
                }
            }
        }
	}

    fillFormInitValues() {
        this.props.form?.setFieldsValue({
});

    }

      setPageInitLoaded = (value: boolean) => {
        this.setState({ isPageInitLoaded: value });
      }

      setPageRecurringLoaded = (value: boolean) => {
        this.setState({ isPageRecurringLoaded: value });
      }

      clearFieldValidation = (changedValues: any) => {
        const fieldName = Object.keys(changedValues)[0];
        if (fieldName) {
          this.props.form?.setFields([
            {
              name: fieldName,
              errors: []
            }
          ]);
        }
      };

        checkTabErrors = () => {
    document.querySelectorAll(".rc-tabs-tab").forEach((tab) => {
      (tab as HTMLElement).style.color = "";
    });

    const tabPanes = document.querySelectorAll(".rc-tabs-tabpane");
    const tabs = document.querySelectorAll(".rc-tabs-tab");

    tabPanes.forEach((tabPane, index) => {
      const uniquePaneId = `rc-tabs-tabpane-${index}`;
      if (!tabPane.hasAttribute("id")) {
        tabPane.setAttribute("id", uniquePaneId); 
      }

      const uniqueTabId = `rc-tabs-tab-${index}`;
      if (tabs[index]) {
        if (!tabs[index].hasAttribute("id")) {
          tabs[index].setAttribute("id", uniqueTabId); 
        }
        tabs[index].setAttribute("aria-controls", uniquePaneId);
      }
    });

    const errorElements = document.querySelectorAll(".rc-tabs .ant-form-item-explain-error");

    const tabsWithErrors = new Set<string>();

    errorElements.forEach((errorElement) => {
      const tabPane = errorElement.closest(".rc-tabs-tabpane");
      if (tabPane && tabPane.id) {
        tabsWithErrors.add(tabPane.id);
      }
    });

    tabsWithErrors.forEach((tabPaneId) => {
      const tab = document.querySelector(`.rc-tabs-tab[aria-controls="${tabPaneId}"]`);
      if (tab) {
        (tab as HTMLElement).style.color = "red"; 
      }
    });
  };

    RolexOtherProductReportingPageInit = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


	if (KuikaAppManager.handleValidations(this, validations, this.checkTabErrors))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }

        let localVar = {
			Brand_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.convertToTypeByName("Rolex", "string"), "string"),
			ProductGroup_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.convertToTypeByName("Kol Düğmesi", "string"), "string"),
			Year1_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "rolexotherproductreporting_585930_value", "value", "", "", "")), "number"),
			Year2_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "rolexotherproductreporting_420182_value", "value", "", "", "")), "number"),
			Brand_1: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.convertToTypeByName("Rolex", "string"), "string"),
			ProductGroup_1: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.convertToTypeByName("Kitap", "string"), "string"),
			Year1_1: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "rolexotherproductreporting_556215_value", "value", "", "", "")), "number"),
			Year2_1: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "rolexotherproductreporting_131933_value", "value", "", "", "")), "number"),
			Brand_2: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.convertToTypeByName("Rolex", "string"), "string"),
			ProductGroup_2: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.convertToTypeByName("Masa Saati", "string"), "string"),
			Year1_2: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "rolexotherproductreporting_501380_value", "value", "", "", "")), "number"),
			Year2_2: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "rolexotherproductreporting_96734_value", "value", "", "", "")), "number")
        }

	KuikaAppManager.showSpinner(this);
	
        if (true) {
        KuikaAppManager.showSpinner(this);
        }
        let result = await KuikaAppManager.ApiRequest(this, "RolexOtherProductReporting/RolexOtherProductReportingPageInit", localVar)
        if (!KMainFunctions.IsResStatus2XX(result)) return true;

		stateVars.KuikaY_RolexGrupAylikSatisKarsilastirma_S1 = result?.data.kuikaY_RolexGrupAylikSatisKarsilastirma_S1;
		stateVars.KuikaY_RolexGrupAylikSatisKarsilastirma_S2 = result?.data.kuikaY_RolexGrupAylikSatisKarsilastirma_S2;
		stateVars.KuikaY_RolexGrupAylikSatisKarsilastirma_S3 = result?.data.kuikaY_RolexGrupAylikSatisKarsilastirma_S3;
		this.props.form?.setFieldsValue(formVars);
		
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.RolexOtherProductReportingPageInit1_();
                  resolve();
                });
          })



        
        KuikaAppManager.hideSpinner(this);
        return isErrorOccurred;
    }
	RolexOtherProductReportingPageInit1_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


	if (KuikaAppManager.handleValidations(this, validations, this.checkTabErrors))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }

			ReactSystemFunctions.setValueOf(this, "rolexotherproductreporting_419462_toString", ReactSystemFunctions.value(this, "rolexotherproductreporting_585930_value", "value"), "value");

			ReactSystemFunctions.setValueOf(this, "rolexotherproductreporting_376605_toString", ReactSystemFunctions.value(this, "rolexotherproductreporting_420182_value", "value"), "value");

			
			stateVars.dataSource_275766 = stateVars.KuikaY_RolexGrupAylikSatisKarsilastirma_S1 ?? this.state.KuikaY_RolexGrupAylikSatisKarsilastirma_S1;
			
			
			stateVars.isComp161669Visible = ((ReactSystemFunctions.isGreaterOrEqual(ReactSystemFunctions.value(this, "rolexotherproductreporting_275766_value", "ocakDegisim"), ReactSystemFunctions.convertToTypeByName("0", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp287775Visible = ((ReactSystemFunctions.isLessThan(ReactSystemFunctions.value(this, "rolexotherproductreporting_275766_value", "ocakDegisim"), ReactSystemFunctions.convertToTypeByName("0", "string"))) === true ? "visible" : "hidden")
			
			stateVars.dataSource_964103 = stateVars.KuikaY_RolexGrupAylikSatisKarsilastirma_S1 ?? this.state.KuikaY_RolexGrupAylikSatisKarsilastirma_S1;
			ReactSystemFunctions.setValueOf(this, "rolexotherproductreporting_728979_toString", ReactSystemFunctions.value(this, "rolexotherproductreporting_585930_value", "value"), "value");

			ReactSystemFunctions.setValueOf(this, "rolexotherproductreporting_301836_toString", ReactSystemFunctions.value(this, "rolexotherproductreporting_420182_value", "value"), "value");

			
			stateVars.dataSource_518172 = stateVars.KuikaY_RolexGrupAylikSatisKarsilastirma_S1 ?? this.state.KuikaY_RolexGrupAylikSatisKarsilastirma_S1;
			
			
			stateVars.isComp586282Visible = ((ReactSystemFunctions.isGreaterOrEqual(ReactSystemFunctions.value(this, "rolexotherproductreporting_518172_value", "subatDegisim"), ReactSystemFunctions.convertToTypeByName("0", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp583930Visible = ((ReactSystemFunctions.isLessThan(ReactSystemFunctions.value(this, "rolexotherproductreporting_518172_value", "subatDegisim"), ReactSystemFunctions.convertToTypeByName("0", "string"))) === true ? "visible" : "hidden")
			
			stateVars.dataSource_664290 = stateVars.KuikaY_RolexGrupAylikSatisKarsilastirma_S1 ?? this.state.KuikaY_RolexGrupAylikSatisKarsilastirma_S1;
			ReactSystemFunctions.setValueOf(this, "rolexotherproductreporting_704294_toString", ReactSystemFunctions.value(this, "rolexotherproductreporting_585930_value", "value"), "value");

			ReactSystemFunctions.setValueOf(this, "rolexotherproductreporting_696535_toString", ReactSystemFunctions.value(this, "rolexotherproductreporting_420182_value", "value"), "value");

			
			stateVars.dataSource_718974 = stateVars.KuikaY_RolexGrupAylikSatisKarsilastirma_S1 ?? this.state.KuikaY_RolexGrupAylikSatisKarsilastirma_S1;
			
			
			stateVars.isComp579785Visible = ((ReactSystemFunctions.isGreaterOrEqual(ReactSystemFunctions.value(this, "rolexotherproductreporting_718974_value", "martDegisim"), ReactSystemFunctions.convertToTypeByName("0", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp538425Visible = ((ReactSystemFunctions.isLessThan(ReactSystemFunctions.value(this, "rolexotherproductreporting_718974_value", "martDegisim"), ReactSystemFunctions.convertToTypeByName("0", "string"))) === true ? "visible" : "hidden")
			
			stateVars.dataSource_42801 = stateVars.KuikaY_RolexGrupAylikSatisKarsilastirma_S1 ?? this.state.KuikaY_RolexGrupAylikSatisKarsilastirma_S1;
			ReactSystemFunctions.setValueOf(this, "rolexotherproductreporting_977033_toString", ReactSystemFunctions.value(this, "rolexotherproductreporting_585930_value", "value"), "value");

			ReactSystemFunctions.setValueOf(this, "rolexotherproductreporting_833300_toString", ReactSystemFunctions.value(this, "rolexotherproductreporting_420182_value", "value"), "value");

			
			stateVars.dataSource_792925 = stateVars.KuikaY_RolexGrupAylikSatisKarsilastirma_S1 ?? this.state.KuikaY_RolexGrupAylikSatisKarsilastirma_S1;
			
			
			stateVars.isComp921751Visible = ((ReactSystemFunctions.isGreaterOrEqual(ReactSystemFunctions.value(this, "rolexotherproductreporting_792925_value", "nisanDegisim"), ReactSystemFunctions.convertToTypeByName("0", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp168185Visible = ((ReactSystemFunctions.isLessThan(ReactSystemFunctions.value(this, "rolexotherproductreporting_792925_value", "nisanDegisim"), ReactSystemFunctions.convertToTypeByName("0", "string"))) === true ? "visible" : "hidden")
			
			stateVars.dataSource_648584 = stateVars.KuikaY_RolexGrupAylikSatisKarsilastirma_S1 ?? this.state.KuikaY_RolexGrupAylikSatisKarsilastirma_S1;
			ReactSystemFunctions.setValueOf(this, "rolexotherproductreporting_386207_toString", ReactSystemFunctions.value(this, "rolexotherproductreporting_585930_value", "value"), "value");

			ReactSystemFunctions.setValueOf(this, "rolexotherproductreporting_23840_toString", ReactSystemFunctions.value(this, "rolexotherproductreporting_420182_value", "value"), "value");

			
			stateVars.dataSource_709026 = stateVars.KuikaY_RolexGrupAylikSatisKarsilastirma_S1 ?? this.state.KuikaY_RolexGrupAylikSatisKarsilastirma_S1;
			
			
			stateVars.isComp221926Visible = ((ReactSystemFunctions.isGreaterOrEqual(ReactSystemFunctions.value(this, "rolexotherproductreporting_709026_value", "mayisDegisim"), ReactSystemFunctions.convertToTypeByName("0", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp147684Visible = ((ReactSystemFunctions.isLessThan(ReactSystemFunctions.value(this, "rolexotherproductreporting_709026_value", "mayisDegisim"), ReactSystemFunctions.convertToTypeByName("0", "string"))) === true ? "visible" : "hidden")
			
			stateVars.dataSource_819329 = stateVars.KuikaY_RolexGrupAylikSatisKarsilastirma_S1 ?? this.state.KuikaY_RolexGrupAylikSatisKarsilastirma_S1;
			ReactSystemFunctions.setValueOf(this, "rolexotherproductreporting_950927_toString", ReactSystemFunctions.value(this, "rolexotherproductreporting_585930_value", "value"), "value");

			ReactSystemFunctions.setValueOf(this, "rolexotherproductreporting_360493_toString", ReactSystemFunctions.value(this, "rolexotherproductreporting_420182_value", "value"), "value");

			
			stateVars.dataSource_277280 = stateVars.KuikaY_RolexGrupAylikSatisKarsilastirma_S1 ?? this.state.KuikaY_RolexGrupAylikSatisKarsilastirma_S1;
			
			
			stateVars.isComp296451Visible = ((ReactSystemFunctions.isGreaterOrEqual(ReactSystemFunctions.value(this, "rolexotherproductreporting_277280_value", "haziranDegisim"), ReactSystemFunctions.convertToTypeByName("0", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp62537Visible = ((ReactSystemFunctions.isLessThan(ReactSystemFunctions.value(this, "rolexotherproductreporting_277280_value", "haziranDegisim"), ReactSystemFunctions.convertToTypeByName("0", "string"))) === true ? "visible" : "hidden")
			
			stateVars.dataSource_999621 = stateVars.KuikaY_RolexGrupAylikSatisKarsilastirma_S1 ?? this.state.KuikaY_RolexGrupAylikSatisKarsilastirma_S1;
			ReactSystemFunctions.setValueOf(this, "rolexotherproductreporting_484491_toString", ReactSystemFunctions.value(this, "rolexotherproductreporting_585930_value", "value"), "value");

			ReactSystemFunctions.setValueOf(this, "rolexotherproductreporting_370958_toString", ReactSystemFunctions.value(this, "rolexotherproductreporting_420182_value", "value"), "value");

			
			stateVars.dataSource_229235 = stateVars.KuikaY_RolexGrupAylikSatisKarsilastirma_S1 ?? this.state.KuikaY_RolexGrupAylikSatisKarsilastirma_S1;
			
			
			stateVars.isComp677622Visible = ((ReactSystemFunctions.isGreaterOrEqual(ReactSystemFunctions.value(this, "rolexotherproductreporting_229235_value", "temmuzDegisim"), ReactSystemFunctions.convertToTypeByName("0", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp978143Visible = ((ReactSystemFunctions.isLessThan(ReactSystemFunctions.value(this, "rolexotherproductreporting_229235_value", "temmuzDegisim"), ReactSystemFunctions.convertToTypeByName("0", "string"))) === true ? "visible" : "hidden")
			
			stateVars.dataSource_111148 = stateVars.KuikaY_RolexGrupAylikSatisKarsilastirma_S1 ?? this.state.KuikaY_RolexGrupAylikSatisKarsilastirma_S1;
			ReactSystemFunctions.setValueOf(this, "rolexotherproductreporting_981244_toString", ReactSystemFunctions.value(this, "rolexotherproductreporting_585930_value", "value"), "value");

			ReactSystemFunctions.setValueOf(this, "rolexotherproductreporting_995178_toString", ReactSystemFunctions.value(this, "rolexotherproductreporting_420182_value", "value"), "value");

			
			stateVars.dataSource_945811 = stateVars.KuikaY_RolexGrupAylikSatisKarsilastirma_S1 ?? this.state.KuikaY_RolexGrupAylikSatisKarsilastirma_S1;
			
			
			stateVars.isComp323662Visible = ((ReactSystemFunctions.isGreaterOrEqual(ReactSystemFunctions.value(this, "rolexotherproductreporting_945811_value", "agustosDegisim"), ReactSystemFunctions.convertToTypeByName("0", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp901964Visible = ((ReactSystemFunctions.isLessThan(ReactSystemFunctions.value(this, "rolexotherproductreporting_945811_value", "agustosDegisim"), ReactSystemFunctions.convertToTypeByName("0", "string"))) === true ? "visible" : "hidden")
			
			stateVars.dataSource_748861 = stateVars.KuikaY_RolexGrupAylikSatisKarsilastirma_S1 ?? this.state.KuikaY_RolexGrupAylikSatisKarsilastirma_S1;
			ReactSystemFunctions.setValueOf(this, "rolexotherproductreporting_990501_toString", ReactSystemFunctions.value(this, "rolexotherproductreporting_585930_value", "value"), "value");

			ReactSystemFunctions.setValueOf(this, "rolexotherproductreporting_187489_toString", ReactSystemFunctions.value(this, "rolexotherproductreporting_420182_value", "value"), "value");

			
			stateVars.dataSource_129469 = stateVars.KuikaY_RolexGrupAylikSatisKarsilastirma_S1 ?? this.state.KuikaY_RolexGrupAylikSatisKarsilastirma_S1;
			
			
			stateVars.isComp986714Visible = ((ReactSystemFunctions.isGreaterOrEqual(ReactSystemFunctions.value(this, "rolexotherproductreporting_129469_value", "eylulDegisim"), ReactSystemFunctions.convertToTypeByName("0", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp335343Visible = ((ReactSystemFunctions.isLessThan(ReactSystemFunctions.value(this, "rolexotherproductreporting_129469_value", "eylulDegisim"), ReactSystemFunctions.convertToTypeByName("0", "string"))) === true ? "visible" : "hidden")
			
			stateVars.dataSource_897693 = stateVars.KuikaY_RolexGrupAylikSatisKarsilastirma_S1 ?? this.state.KuikaY_RolexGrupAylikSatisKarsilastirma_S1;
			ReactSystemFunctions.setValueOf(this, "rolexotherproductreporting_726664_toString", ReactSystemFunctions.value(this, "rolexotherproductreporting_585930_value", "value"), "value");

			ReactSystemFunctions.setValueOf(this, "rolexotherproductreporting_187296_toString", ReactSystemFunctions.value(this, "rolexotherproductreporting_420182_value", "value"), "value");

			
			stateVars.dataSource_135272 = stateVars.KuikaY_RolexGrupAylikSatisKarsilastirma_S1 ?? this.state.KuikaY_RolexGrupAylikSatisKarsilastirma_S1;
			
			
			stateVars.isComp105059Visible = ((ReactSystemFunctions.isGreaterOrEqual(ReactSystemFunctions.value(this, "rolexotherproductreporting_135272_value", "ekimDegisim"), ReactSystemFunctions.convertToTypeByName("0", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp928119Visible = ((ReactSystemFunctions.isLessThan(ReactSystemFunctions.value(this, "rolexotherproductreporting_135272_value", "ekimDegisim"), ReactSystemFunctions.convertToTypeByName("0", "string"))) === true ? "visible" : "hidden")
			
			stateVars.dataSource_199279 = stateVars.KuikaY_RolexGrupAylikSatisKarsilastirma_S1 ?? this.state.KuikaY_RolexGrupAylikSatisKarsilastirma_S1;
			ReactSystemFunctions.setValueOf(this, "rolexotherproductreporting_349724_toString", ReactSystemFunctions.value(this, "rolexotherproductreporting_585930_value", "value"), "value");

			ReactSystemFunctions.setValueOf(this, "rolexotherproductreporting_275539_toString", ReactSystemFunctions.value(this, "rolexotherproductreporting_420182_value", "value"), "value");

			
			stateVars.dataSource_454237 = stateVars.KuikaY_RolexGrupAylikSatisKarsilastirma_S1 ?? this.state.KuikaY_RolexGrupAylikSatisKarsilastirma_S1;
			
			
			stateVars.isComp903909Visible = ((ReactSystemFunctions.isGreaterOrEqual(ReactSystemFunctions.value(this, "rolexotherproductreporting_454237_value", "kasimDegisim"), ReactSystemFunctions.convertToTypeByName("0", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp957716Visible = ((ReactSystemFunctions.isLessThan(ReactSystemFunctions.value(this, "rolexotherproductreporting_454237_value", "kasimDegisim"), ReactSystemFunctions.convertToTypeByName("0", "string"))) === true ? "visible" : "hidden")
			
			stateVars.dataSource_628219 = stateVars.KuikaY_RolexGrupAylikSatisKarsilastirma_S1 ?? this.state.KuikaY_RolexGrupAylikSatisKarsilastirma_S1;
			ReactSystemFunctions.setValueOf(this, "rolexotherproductreporting_706774_toString", ReactSystemFunctions.value(this, "rolexotherproductreporting_585930_value", "value"), "value");

			ReactSystemFunctions.setValueOf(this, "rolexotherproductreporting_975801_toString", ReactSystemFunctions.value(this, "rolexotherproductreporting_420182_value", "value"), "value");

			
			stateVars.dataSource_740992 = stateVars.KuikaY_RolexGrupAylikSatisKarsilastirma_S1 ?? this.state.KuikaY_RolexGrupAylikSatisKarsilastirma_S1;
			
			
			stateVars.isComp217755Visible = ((ReactSystemFunctions.isGreaterOrEqual(ReactSystemFunctions.value(this, "rolexotherproductreporting_740992_value", "aralikDegisim"), ReactSystemFunctions.convertToTypeByName("0", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp50459Visible = ((ReactSystemFunctions.isLessThan(ReactSystemFunctions.value(this, "rolexotherproductreporting_740992_value", "aralikDegisim"), ReactSystemFunctions.convertToTypeByName("0", "string"))) === true ? "visible" : "hidden")
			
			stateVars.dataSource_568723 = stateVars.KuikaY_RolexGrupAylikSatisKarsilastirma_S1 ?? this.state.KuikaY_RolexGrupAylikSatisKarsilastirma_S1;
			ReactSystemFunctions.setValueOf(this, "rolexotherproductreporting_576345_toString", ReactSystemFunctions.value(this, "rolexotherproductreporting_556215_value", "value"), "value");

			ReactSystemFunctions.setValueOf(this, "rolexotherproductreporting_849312_toString", ReactSystemFunctions.value(this, "rolexotherproductreporting_131933_value", "value"), "value");

			
			stateVars.dataSource_954334 = stateVars.KuikaY_RolexGrupAylikSatisKarsilastirma_S1 ?? this.state.KuikaY_RolexGrupAylikSatisKarsilastirma_S1;
			
			
			stateVars.isComp715114Visible = ((ReactSystemFunctions.isGreaterOrEqual(ReactSystemFunctions.value(this, "rolexotherproductreporting_954334_value", "ocakDegisim"), ReactSystemFunctions.convertToTypeByName("0", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp218606Visible = ((ReactSystemFunctions.isLessThan(ReactSystemFunctions.value(this, "rolexotherproductreporting_954334_value", "ocakDegisim"), ReactSystemFunctions.convertToTypeByName("0", "string"))) === true ? "visible" : "hidden")
			
			stateVars.dataSource_285411 = stateVars.KuikaY_RolexGrupAylikSatisKarsilastirma_S1 ?? this.state.KuikaY_RolexGrupAylikSatisKarsilastirma_S1;
			ReactSystemFunctions.setValueOf(this, "rolexotherproductreporting_48417_toString", ReactSystemFunctions.value(this, "rolexotherproductreporting_556215_value", "value"), "value");

			ReactSystemFunctions.setValueOf(this, "rolexotherproductreporting_339984_toString", ReactSystemFunctions.value(this, "rolexotherproductreporting_131933_value", "value"), "value");

			
			stateVars.dataSource_560631 = stateVars.KuikaY_RolexGrupAylikSatisKarsilastirma_S1 ?? this.state.KuikaY_RolexGrupAylikSatisKarsilastirma_S1;
			
			
			stateVars.isComp845403Visible = ((ReactSystemFunctions.isGreaterOrEqual(ReactSystemFunctions.value(this, "rolexotherproductreporting_560631_value", "subatDegisim"), ReactSystemFunctions.convertToTypeByName("0", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp187868Visible = ((ReactSystemFunctions.isLessThan(ReactSystemFunctions.value(this, "rolexotherproductreporting_560631_value", "subatDegisim"), ReactSystemFunctions.convertToTypeByName("0", "string"))) === true ? "visible" : "hidden")
			
			stateVars.dataSource_187950 = stateVars.KuikaY_RolexGrupAylikSatisKarsilastirma_S1 ?? this.state.KuikaY_RolexGrupAylikSatisKarsilastirma_S1;
			ReactSystemFunctions.setValueOf(this, "rolexotherproductreporting_997908_toString", ReactSystemFunctions.value(this, "rolexotherproductreporting_556215_value", "value"), "value");

			ReactSystemFunctions.setValueOf(this, "rolexotherproductreporting_101809_toString", ReactSystemFunctions.value(this, "rolexotherproductreporting_131933_value", "value"), "value");

			
			stateVars.dataSource_771338 = stateVars.KuikaY_RolexGrupAylikSatisKarsilastirma_S1 ?? this.state.KuikaY_RolexGrupAylikSatisKarsilastirma_S1;
			
			
			stateVars.isComp617807Visible = ((ReactSystemFunctions.isGreaterOrEqual(ReactSystemFunctions.value(this, "rolexotherproductreporting_771338_value", "martDegisim"), ReactSystemFunctions.convertToTypeByName("0", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp736888Visible = ((ReactSystemFunctions.isLessThan(ReactSystemFunctions.value(this, "rolexotherproductreporting_771338_value", "martDegisim"), ReactSystemFunctions.convertToTypeByName("0", "string"))) === true ? "visible" : "hidden")
			
			stateVars.dataSource_201235 = stateVars.KuikaY_RolexGrupAylikSatisKarsilastirma_S1 ?? this.state.KuikaY_RolexGrupAylikSatisKarsilastirma_S1;
			ReactSystemFunctions.setValueOf(this, "rolexotherproductreporting_706016_toString", ReactSystemFunctions.value(this, "rolexotherproductreporting_556215_value", "value"), "value");

			ReactSystemFunctions.setValueOf(this, "rolexotherproductreporting_131058_toString", ReactSystemFunctions.value(this, "rolexotherproductreporting_131933_value", "value"), "value");

			
			stateVars.dataSource_98342 = stateVars.KuikaY_RolexGrupAylikSatisKarsilastirma_S1 ?? this.state.KuikaY_RolexGrupAylikSatisKarsilastirma_S1;
			
			
			stateVars.isComp750573Visible = ((ReactSystemFunctions.isGreaterOrEqual(ReactSystemFunctions.value(this, "rolexotherproductreporting_98342_value", "nisanDegisim"), ReactSystemFunctions.convertToTypeByName("0", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp517683Visible = ((ReactSystemFunctions.isLessThan(ReactSystemFunctions.value(this, "rolexotherproductreporting_98342_value", "nisanDegisim"), ReactSystemFunctions.convertToTypeByName("0", "string"))) === true ? "visible" : "hidden")
			
			stateVars.dataSource_633909 = stateVars.KuikaY_RolexGrupAylikSatisKarsilastirma_S1 ?? this.state.KuikaY_RolexGrupAylikSatisKarsilastirma_S1;
			ReactSystemFunctions.setValueOf(this, "rolexotherproductreporting_35232_toString", ReactSystemFunctions.value(this, "rolexotherproductreporting_556215_value", "value"), "value");

			ReactSystemFunctions.setValueOf(this, "rolexotherproductreporting_510100_toString", ReactSystemFunctions.value(this, "rolexotherproductreporting_131933_value", "value"), "value");

			
			stateVars.dataSource_959130 = stateVars.KuikaY_RolexGrupAylikSatisKarsilastirma_S1 ?? this.state.KuikaY_RolexGrupAylikSatisKarsilastirma_S1;
			
			
			stateVars.isComp211529Visible = ((ReactSystemFunctions.isGreaterOrEqual(ReactSystemFunctions.value(this, "rolexotherproductreporting_959130_value", "mayisDegisim"), ReactSystemFunctions.convertToTypeByName("0", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp376481Visible = ((ReactSystemFunctions.isLessThan(ReactSystemFunctions.value(this, "rolexotherproductreporting_959130_value", "mayisDegisim"), ReactSystemFunctions.convertToTypeByName("0", "string"))) === true ? "visible" : "hidden")
			
			stateVars.dataSource_218800 = stateVars.KuikaY_RolexGrupAylikSatisKarsilastirma_S1 ?? this.state.KuikaY_RolexGrupAylikSatisKarsilastirma_S1;
			ReactSystemFunctions.setValueOf(this, "rolexotherproductreporting_226257_toString", ReactSystemFunctions.value(this, "rolexotherproductreporting_556215_value", "value"), "value");

			ReactSystemFunctions.setValueOf(this, "rolexotherproductreporting_796164_toString", ReactSystemFunctions.value(this, "rolexotherproductreporting_131933_value", "value"), "value");

			
			stateVars.dataSource_663232 = stateVars.KuikaY_RolexGrupAylikSatisKarsilastirma_S1 ?? this.state.KuikaY_RolexGrupAylikSatisKarsilastirma_S1;
			
			
			stateVars.isComp417983Visible = ((ReactSystemFunctions.isGreaterOrEqual(ReactSystemFunctions.value(this, "rolexotherproductreporting_663232_value", "haziranDegisim"), ReactSystemFunctions.convertToTypeByName("0", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp187538Visible = ((ReactSystemFunctions.isLessThan(ReactSystemFunctions.value(this, "rolexotherproductreporting_663232_value", "haziranDegisim"), ReactSystemFunctions.convertToTypeByName("0", "string"))) === true ? "visible" : "hidden")
			
			stateVars.dataSource_297134 = stateVars.KuikaY_RolexGrupAylikSatisKarsilastirma_S1 ?? this.state.KuikaY_RolexGrupAylikSatisKarsilastirma_S1;
			ReactSystemFunctions.setValueOf(this, "rolexotherproductreporting_986881_toString", ReactSystemFunctions.value(this, "rolexotherproductreporting_556215_value", "value"), "value");

			ReactSystemFunctions.setValueOf(this, "rolexotherproductreporting_891406_toString", ReactSystemFunctions.value(this, "rolexotherproductreporting_131933_value", "value"), "value");

			
			stateVars.dataSource_936158 = stateVars.KuikaY_RolexGrupAylikSatisKarsilastirma_S1 ?? this.state.KuikaY_RolexGrupAylikSatisKarsilastirma_S1;
			
			
			stateVars.isComp978033Visible = ((ReactSystemFunctions.isGreaterOrEqual(ReactSystemFunctions.value(this, "rolexotherproductreporting_936158_value", "temmuzDegisim"), ReactSystemFunctions.convertToTypeByName("0", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp584012Visible = ((ReactSystemFunctions.isLessThan(ReactSystemFunctions.value(this, "rolexotherproductreporting_936158_value", "temmuzDegisim"), ReactSystemFunctions.convertToTypeByName("0", "string"))) === true ? "visible" : "hidden")
			
			stateVars.dataSource_439784 = stateVars.KuikaY_RolexGrupAylikSatisKarsilastirma_S1 ?? this.state.KuikaY_RolexGrupAylikSatisKarsilastirma_S1;
			ReactSystemFunctions.setValueOf(this, "rolexotherproductreporting_399502_toString", ReactSystemFunctions.value(this, "rolexotherproductreporting_556215_value", "value"), "value");

			ReactSystemFunctions.setValueOf(this, "rolexotherproductreporting_2268_toString", ReactSystemFunctions.value(this, "rolexotherproductreporting_131933_value", "value"), "value");

			
			stateVars.dataSource_921927 = stateVars.KuikaY_RolexGrupAylikSatisKarsilastirma_S1 ?? this.state.KuikaY_RolexGrupAylikSatisKarsilastirma_S1;
			
			
			stateVars.isComp360041Visible = ((ReactSystemFunctions.isGreaterOrEqual(ReactSystemFunctions.value(this, "rolexotherproductreporting_921927_value", "agustosDegisim"), ReactSystemFunctions.convertToTypeByName("0", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp610944Visible = ((ReactSystemFunctions.isLessThan(ReactSystemFunctions.value(this, "rolexotherproductreporting_921927_value", "agustosDegisim"), ReactSystemFunctions.convertToTypeByName("0", "string"))) === true ? "visible" : "hidden")
			
			stateVars.dataSource_721216 = stateVars.KuikaY_RolexGrupAylikSatisKarsilastirma_S1 ?? this.state.KuikaY_RolexGrupAylikSatisKarsilastirma_S1;
			ReactSystemFunctions.setValueOf(this, "rolexotherproductreporting_158260_toString", ReactSystemFunctions.value(this, "rolexotherproductreporting_556215_value", "value"), "value");

			ReactSystemFunctions.setValueOf(this, "rolexotherproductreporting_102910_toString", ReactSystemFunctions.value(this, "rolexotherproductreporting_131933_value", "value"), "value");

			
			stateVars.dataSource_399719 = stateVars.KuikaY_RolexGrupAylikSatisKarsilastirma_S1 ?? this.state.KuikaY_RolexGrupAylikSatisKarsilastirma_S1;
			
			
			stateVars.isComp151940Visible = ((ReactSystemFunctions.isGreaterOrEqual(ReactSystemFunctions.value(this, "rolexotherproductreporting_399719_value", "eylulDegisim"), ReactSystemFunctions.convertToTypeByName("0", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp765709Visible = ((ReactSystemFunctions.isLessThan(ReactSystemFunctions.value(this, "rolexotherproductreporting_399719_value", "eylulDegisim"), ReactSystemFunctions.convertToTypeByName("0", "string"))) === true ? "visible" : "hidden")
			
			stateVars.dataSource_65682 = stateVars.KuikaY_RolexGrupAylikSatisKarsilastirma_S1 ?? this.state.KuikaY_RolexGrupAylikSatisKarsilastirma_S1;
			ReactSystemFunctions.setValueOf(this, "rolexotherproductreporting_454310_toString", ReactSystemFunctions.value(this, "rolexotherproductreporting_556215_value", "value"), "value");

			ReactSystemFunctions.setValueOf(this, "rolexotherproductreporting_657487_toString", ReactSystemFunctions.value(this, "rolexotherproductreporting_131933_value", "value"), "value");

			
			stateVars.dataSource_887255 = stateVars.KuikaY_RolexGrupAylikSatisKarsilastirma_S1 ?? this.state.KuikaY_RolexGrupAylikSatisKarsilastirma_S1;
			
			
			stateVars.isComp754337Visible = ((ReactSystemFunctions.isGreaterOrEqual(ReactSystemFunctions.value(this, "rolexotherproductreporting_887255_value", "ekimDegisim"), ReactSystemFunctions.convertToTypeByName("0", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp781791Visible = ((ReactSystemFunctions.isLessThan(ReactSystemFunctions.value(this, "rolexotherproductreporting_887255_value", "ekimDegisim"), ReactSystemFunctions.convertToTypeByName("0", "string"))) === true ? "visible" : "hidden")
			
			stateVars.dataSource_431933 = stateVars.KuikaY_RolexGrupAylikSatisKarsilastirma_S1 ?? this.state.KuikaY_RolexGrupAylikSatisKarsilastirma_S1;
			ReactSystemFunctions.setValueOf(this, "rolexotherproductreporting_699935_toString", ReactSystemFunctions.value(this, "rolexotherproductreporting_556215_value", "value"), "value");

			ReactSystemFunctions.setValueOf(this, "rolexotherproductreporting_732051_toString", ReactSystemFunctions.value(this, "rolexotherproductreporting_131933_value", "value"), "value");

			
			stateVars.dataSource_927967 = stateVars.KuikaY_RolexGrupAylikSatisKarsilastirma_S1 ?? this.state.KuikaY_RolexGrupAylikSatisKarsilastirma_S1;
			
			
			stateVars.isComp497524Visible = ((ReactSystemFunctions.isGreaterOrEqual(ReactSystemFunctions.value(this, "rolexotherproductreporting_927967_value", "kasimDegisim"), ReactSystemFunctions.convertToTypeByName("0", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp964317Visible = ((ReactSystemFunctions.isLessThan(ReactSystemFunctions.value(this, "rolexotherproductreporting_927967_value", "kasimDegisim"), ReactSystemFunctions.convertToTypeByName("0", "string"))) === true ? "visible" : "hidden")
			
			stateVars.dataSource_97268 = stateVars.KuikaY_RolexGrupAylikSatisKarsilastirma_S1 ?? this.state.KuikaY_RolexGrupAylikSatisKarsilastirma_S1;
			ReactSystemFunctions.setValueOf(this, "rolexotherproductreporting_561867_toString", ReactSystemFunctions.value(this, "rolexotherproductreporting_556215_value", "value"), "value");

			ReactSystemFunctions.setValueOf(this, "rolexotherproductreporting_319217_toString", ReactSystemFunctions.value(this, "rolexotherproductreporting_131933_value", "value"), "value");

			
			stateVars.dataSource_547472 = stateVars.KuikaY_RolexGrupAylikSatisKarsilastirma_S1 ?? this.state.KuikaY_RolexGrupAylikSatisKarsilastirma_S1;
			
			
			stateVars.isComp239462Visible = ((ReactSystemFunctions.isGreaterOrEqual(ReactSystemFunctions.value(this, "rolexotherproductreporting_547472_value", "aralikDegisim"), ReactSystemFunctions.convertToTypeByName("0", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp857528Visible = ((ReactSystemFunctions.isLessThan(ReactSystemFunctions.value(this, "rolexotherproductreporting_547472_value", "aralikDegisim"), ReactSystemFunctions.convertToTypeByName("0", "string"))) === true ? "visible" : "hidden")
			
			stateVars.dataSource_865953 = stateVars.KuikaY_RolexGrupAylikSatisKarsilastirma_S1 ?? this.state.KuikaY_RolexGrupAylikSatisKarsilastirma_S1;
			ReactSystemFunctions.setValueOf(this, "rolexotherproductreporting_717019_toString", ReactSystemFunctions.value(this, "rolexotherproductreporting_501380_value", "value"), "value");

			ReactSystemFunctions.setValueOf(this, "rolexotherproductreporting_221691_toString", ReactSystemFunctions.value(this, "rolexotherproductreporting_96734_value", "value"), "value");

			
			stateVars.dataSource_937402 = stateVars.KuikaY_RolexGrupAylikSatisKarsilastirma_S1 ?? this.state.KuikaY_RolexGrupAylikSatisKarsilastirma_S1;
			
			
			stateVars.isComp681283Visible = ((ReactSystemFunctions.isGreaterOrEqual(ReactSystemFunctions.value(this, "rolexotherproductreporting_937402_value", "ocakDegisim"), ReactSystemFunctions.convertToTypeByName("0", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp390216Visible = ((ReactSystemFunctions.isLessThan(ReactSystemFunctions.value(this, "rolexotherproductreporting_937402_value", "ocakDegisim"), ReactSystemFunctions.convertToTypeByName("0", "string"))) === true ? "visible" : "hidden")
			
			stateVars.dataSource_540011 = stateVars.KuikaY_RolexGrupAylikSatisKarsilastirma_S1 ?? this.state.KuikaY_RolexGrupAylikSatisKarsilastirma_S1;
			ReactSystemFunctions.setValueOf(this, "rolexotherproductreporting_913360_toString", ReactSystemFunctions.value(this, "rolexotherproductreporting_501380_value", "value"), "value");

			ReactSystemFunctions.setValueOf(this, "rolexotherproductreporting_429389_toString", ReactSystemFunctions.value(this, "rolexotherproductreporting_96734_value", "value"), "value");

			
			stateVars.dataSource_217447 = stateVars.KuikaY_RolexGrupAylikSatisKarsilastirma_S1 ?? this.state.KuikaY_RolexGrupAylikSatisKarsilastirma_S1;
			
			
			stateVars.isComp148761Visible = ((ReactSystemFunctions.isGreaterOrEqual(ReactSystemFunctions.value(this, "rolexotherproductreporting_217447_value", "subatDegisim"), ReactSystemFunctions.convertToTypeByName("0", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp466811Visible = ((ReactSystemFunctions.isLessThan(ReactSystemFunctions.value(this, "rolexotherproductreporting_217447_value", "subatDegisim"), ReactSystemFunctions.convertToTypeByName("0", "string"))) === true ? "visible" : "hidden")
			
			stateVars.dataSource_214508 = stateVars.KuikaY_RolexGrupAylikSatisKarsilastirma_S1 ?? this.state.KuikaY_RolexGrupAylikSatisKarsilastirma_S1;
			ReactSystemFunctions.setValueOf(this, "rolexotherproductreporting_959183_toString", ReactSystemFunctions.value(this, "rolexotherproductreporting_501380_value", "value"), "value");

			ReactSystemFunctions.setValueOf(this, "rolexotherproductreporting_657551_toString", ReactSystemFunctions.value(this, "rolexotherproductreporting_96734_value", "value"), "value");

			
			stateVars.dataSource_288283 = stateVars.KuikaY_RolexGrupAylikSatisKarsilastirma_S1 ?? this.state.KuikaY_RolexGrupAylikSatisKarsilastirma_S1;
			
			
			stateVars.isComp399425Visible = ((ReactSystemFunctions.isGreaterOrEqual(ReactSystemFunctions.value(this, "rolexotherproductreporting_288283_value", "martDegisim"), ReactSystemFunctions.convertToTypeByName("0", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp994014Visible = ((ReactSystemFunctions.isLessThan(ReactSystemFunctions.value(this, "rolexotherproductreporting_288283_value", "martDegisim"), ReactSystemFunctions.convertToTypeByName("0", "string"))) === true ? "visible" : "hidden")
			
			stateVars.dataSource_726679 = stateVars.KuikaY_RolexGrupAylikSatisKarsilastirma_S1 ?? this.state.KuikaY_RolexGrupAylikSatisKarsilastirma_S1;
			ReactSystemFunctions.setValueOf(this, "rolexotherproductreporting_72195_toString", ReactSystemFunctions.value(this, "rolexotherproductreporting_501380_value", "value"), "value");

			ReactSystemFunctions.setValueOf(this, "rolexotherproductreporting_136210_toString", ReactSystemFunctions.value(this, "rolexotherproductreporting_96734_value", "value"), "value");

			
			stateVars.dataSource_637605 = stateVars.KuikaY_RolexGrupAylikSatisKarsilastirma_S1 ?? this.state.KuikaY_RolexGrupAylikSatisKarsilastirma_S1;
			
			
			stateVars.isComp578783Visible = ((ReactSystemFunctions.isGreaterOrEqual(ReactSystemFunctions.value(this, "rolexotherproductreporting_637605_value", "nisanDegisim"), ReactSystemFunctions.convertToTypeByName("0", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp600306Visible = ((ReactSystemFunctions.isLessThan(ReactSystemFunctions.value(this, "rolexotherproductreporting_637605_value", "nisanDegisim"), ReactSystemFunctions.convertToTypeByName("0", "string"))) === true ? "visible" : "hidden")
			
			stateVars.dataSource_707536 = stateVars.KuikaY_RolexGrupAylikSatisKarsilastirma_S1 ?? this.state.KuikaY_RolexGrupAylikSatisKarsilastirma_S1;
			ReactSystemFunctions.setValueOf(this, "rolexotherproductreporting_402618_toString", ReactSystemFunctions.value(this, "rolexotherproductreporting_501380_value", "value"), "value");

			ReactSystemFunctions.setValueOf(this, "rolexotherproductreporting_703507_toString", ReactSystemFunctions.value(this, "rolexotherproductreporting_96734_value", "value"), "value");

			
			stateVars.dataSource_618611 = stateVars.KuikaY_RolexGrupAylikSatisKarsilastirma_S1 ?? this.state.KuikaY_RolexGrupAylikSatisKarsilastirma_S1;
			
			
			stateVars.isComp482131Visible = ((ReactSystemFunctions.isGreaterOrEqual(ReactSystemFunctions.value(this, "rolexotherproductreporting_618611_value", "mayisDegisim"), ReactSystemFunctions.convertToTypeByName("0", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp640218Visible = ((ReactSystemFunctions.isLessThan(ReactSystemFunctions.value(this, "rolexotherproductreporting_618611_value", "mayisDegisim"), ReactSystemFunctions.convertToTypeByName("0", "string"))) === true ? "visible" : "hidden")
			
			stateVars.dataSource_751944 = stateVars.KuikaY_RolexGrupAylikSatisKarsilastirma_S1 ?? this.state.KuikaY_RolexGrupAylikSatisKarsilastirma_S1;
			ReactSystemFunctions.setValueOf(this, "rolexotherproductreporting_247686_toString", ReactSystemFunctions.value(this, "rolexotherproductreporting_501380_value", "value"), "value");

			ReactSystemFunctions.setValueOf(this, "rolexotherproductreporting_869277_toString", ReactSystemFunctions.value(this, "rolexotherproductreporting_96734_value", "value"), "value");

			
			stateVars.dataSource_707740 = stateVars.KuikaY_RolexGrupAylikSatisKarsilastirma_S1 ?? this.state.KuikaY_RolexGrupAylikSatisKarsilastirma_S1;
			
			
			stateVars.isComp518732Visible = ((ReactSystemFunctions.isGreaterOrEqual(ReactSystemFunctions.value(this, "rolexotherproductreporting_707740_value", "haziranDegisim"), ReactSystemFunctions.convertToTypeByName("0", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp965830Visible = ((ReactSystemFunctions.isLessThan(ReactSystemFunctions.value(this, "rolexotherproductreporting_707740_value", "haziranDegisim"), ReactSystemFunctions.convertToTypeByName("0", "string"))) === true ? "visible" : "hidden")
			
			stateVars.dataSource_599192 = stateVars.KuikaY_RolexGrupAylikSatisKarsilastirma_S1 ?? this.state.KuikaY_RolexGrupAylikSatisKarsilastirma_S1;
			ReactSystemFunctions.setValueOf(this, "rolexotherproductreporting_129833_toString", ReactSystemFunctions.value(this, "rolexotherproductreporting_501380_value", "value"), "value");

			ReactSystemFunctions.setValueOf(this, "rolexotherproductreporting_80855_toString", ReactSystemFunctions.value(this, "rolexotherproductreporting_96734_value", "value"), "value");

			
			stateVars.dataSource_248545 = stateVars.KuikaY_RolexGrupAylikSatisKarsilastirma_S1 ?? this.state.KuikaY_RolexGrupAylikSatisKarsilastirma_S1;
			
			
			stateVars.isComp766286Visible = ((ReactSystemFunctions.isGreaterOrEqual(ReactSystemFunctions.value(this, "rolexotherproductreporting_248545_value", "temmuzDegisim"), ReactSystemFunctions.convertToTypeByName("0", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp506019Visible = ((ReactSystemFunctions.isLessThan(ReactSystemFunctions.value(this, "rolexotherproductreporting_248545_value", "temmuzDegisim"), ReactSystemFunctions.convertToTypeByName("0", "string"))) === true ? "visible" : "hidden")
			
			stateVars.dataSource_751193 = stateVars.KuikaY_RolexGrupAylikSatisKarsilastirma_S1 ?? this.state.KuikaY_RolexGrupAylikSatisKarsilastirma_S1;
			ReactSystemFunctions.setValueOf(this, "rolexotherproductreporting_545441_toString", ReactSystemFunctions.value(this, "rolexotherproductreporting_501380_value", "value"), "value");

			ReactSystemFunctions.setValueOf(this, "rolexotherproductreporting_252409_toString", ReactSystemFunctions.value(this, "rolexotherproductreporting_96734_value", "value"), "value");

			
			stateVars.dataSource_458677 = stateVars.KuikaY_RolexGrupAylikSatisKarsilastirma_S1 ?? this.state.KuikaY_RolexGrupAylikSatisKarsilastirma_S1;
			
			
			stateVars.isComp423425Visible = ((ReactSystemFunctions.isGreaterOrEqual(ReactSystemFunctions.value(this, "rolexotherproductreporting_458677_value", "agustosDegisim"), ReactSystemFunctions.convertToTypeByName("0", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp238705Visible = ((ReactSystemFunctions.isLessThan(ReactSystemFunctions.value(this, "rolexotherproductreporting_458677_value", "agustosDegisim"), ReactSystemFunctions.convertToTypeByName("0", "string"))) === true ? "visible" : "hidden")
			
			stateVars.dataSource_404646 = stateVars.KuikaY_RolexGrupAylikSatisKarsilastirma_S1 ?? this.state.KuikaY_RolexGrupAylikSatisKarsilastirma_S1;
			ReactSystemFunctions.setValueOf(this, "rolexotherproductreporting_959105_toString", ReactSystemFunctions.value(this, "rolexotherproductreporting_501380_value", "value"), "value");

			ReactSystemFunctions.setValueOf(this, "rolexotherproductreporting_810497_toString", ReactSystemFunctions.value(this, "rolexotherproductreporting_96734_value", "value"), "value");

			
			stateVars.dataSource_629750 = stateVars.KuikaY_RolexGrupAylikSatisKarsilastirma_S1 ?? this.state.KuikaY_RolexGrupAylikSatisKarsilastirma_S1;
			
			
			stateVars.isComp48092Visible = ((ReactSystemFunctions.isGreaterOrEqual(ReactSystemFunctions.value(this, "rolexotherproductreporting_629750_value", "eylulDegisim"), ReactSystemFunctions.convertToTypeByName("0", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp198035Visible = ((ReactSystemFunctions.isLessThan(ReactSystemFunctions.value(this, "rolexotherproductreporting_629750_value", "eylulDegisim"), ReactSystemFunctions.convertToTypeByName("0", "string"))) === true ? "visible" : "hidden")
			
			stateVars.dataSource_711149 = stateVars.KuikaY_RolexGrupAylikSatisKarsilastirma_S1 ?? this.state.KuikaY_RolexGrupAylikSatisKarsilastirma_S1;
			ReactSystemFunctions.setValueOf(this, "rolexotherproductreporting_909095_toString", ReactSystemFunctions.value(this, "rolexotherproductreporting_501380_value", "value"), "value");

			ReactSystemFunctions.setValueOf(this, "rolexotherproductreporting_94973_toString", ReactSystemFunctions.value(this, "rolexotherproductreporting_96734_value", "value"), "value");

			
			stateVars.dataSource_649122 = stateVars.KuikaY_RolexGrupAylikSatisKarsilastirma_S1 ?? this.state.KuikaY_RolexGrupAylikSatisKarsilastirma_S1;
			
			
			stateVars.isComp1323Visible = ((ReactSystemFunctions.isGreaterOrEqual(ReactSystemFunctions.value(this, "rolexotherproductreporting_649122_value", "ekimDegisim"), ReactSystemFunctions.convertToTypeByName("0", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp601309Visible = ((ReactSystemFunctions.isLessThan(ReactSystemFunctions.value(this, "rolexotherproductreporting_649122_value", "ekimDegisim"), ReactSystemFunctions.convertToTypeByName("0", "string"))) === true ? "visible" : "hidden")
			
			stateVars.dataSource_340559 = stateVars.KuikaY_RolexGrupAylikSatisKarsilastirma_S1 ?? this.state.KuikaY_RolexGrupAylikSatisKarsilastirma_S1;
			ReactSystemFunctions.setValueOf(this, "rolexotherproductreporting_838511_toString", ReactSystemFunctions.value(this, "rolexotherproductreporting_501380_value", "value"), "value");

			ReactSystemFunctions.setValueOf(this, "rolexotherproductreporting_2385_toString", ReactSystemFunctions.value(this, "rolexotherproductreporting_96734_value", "value"), "value");

			
			stateVars.dataSource_644418 = stateVars.KuikaY_RolexGrupAylikSatisKarsilastirma_S1 ?? this.state.KuikaY_RolexGrupAylikSatisKarsilastirma_S1;
			
			
			stateVars.isComp487652Visible = ((ReactSystemFunctions.isGreaterOrEqual(ReactSystemFunctions.value(this, "rolexotherproductreporting_644418_value", "kasimDegisim"), ReactSystemFunctions.convertToTypeByName("0", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp408188Visible = ((ReactSystemFunctions.isLessThan(ReactSystemFunctions.value(this, "rolexotherproductreporting_644418_value", "kasimDegisim"), ReactSystemFunctions.convertToTypeByName("0", "string"))) === true ? "visible" : "hidden")
			
			stateVars.dataSource_630976 = stateVars.KuikaY_RolexGrupAylikSatisKarsilastirma_S1 ?? this.state.KuikaY_RolexGrupAylikSatisKarsilastirma_S1;
			ReactSystemFunctions.setValueOf(this, "rolexotherproductreporting_584110_toString", ReactSystemFunctions.value(this, "rolexotherproductreporting_501380_value", "value"), "value");

			ReactSystemFunctions.setValueOf(this, "rolexotherproductreporting_184777_toString", ReactSystemFunctions.value(this, "rolexotherproductreporting_96734_value", "value"), "value");

			
			stateVars.dataSource_371718 = stateVars.KuikaY_RolexGrupAylikSatisKarsilastirma_S1 ?? this.state.KuikaY_RolexGrupAylikSatisKarsilastirma_S1;
			
			
			stateVars.isComp163264Visible = ((ReactSystemFunctions.isGreaterOrEqual(ReactSystemFunctions.value(this, "rolexotherproductreporting_371718_value", "aralikDegisim"), ReactSystemFunctions.convertToTypeByName("0", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp595496Visible = ((ReactSystemFunctions.isLessThan(ReactSystemFunctions.value(this, "rolexotherproductreporting_371718_value", "aralikDegisim"), ReactSystemFunctions.convertToTypeByName("0", "string"))) === true ? "visible" : "hidden")
			
			stateVars.dataSource_495338 = stateVars.KuikaY_RolexGrupAylikSatisKarsilastirma_S1 ?? this.state.KuikaY_RolexGrupAylikSatisKarsilastirma_S1;

	this.props.form?.setFieldsValue(formVars);
	this.setState(stateVars);
	KuikaAppManager.hideSpinner(this);

            this.setPageInitLoaded(true);
            return isErrorOccurred;
        }




		RolexOtherProductReportingComponent_311444_onClick = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations, this.checkTabErrors))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
KuikaAppManager.showSpinner(this);

const __currentPath = (window.location.hash ? window.location.hash.replace(/^#/, '').split('?')[0] : window.location.pathname.split('?')[0]).toLowerCase();
if (__currentPath !== "/tudorbasedreporting") {
  this.context.setMasterPageInitLoaded(false);
  this.context.setMasterPageRecurringLoaded(false);
  this.context.setShouldTriggerPageInit(true);
}
					KuikaAppManager.prepareForNavigation();

				stateVars.NAVIGATE = await ReactSystemFunctions.navigate(this, undefined, "RolexOtherProductReporting", "TudorBasedReporting", "", "currentPage", null, null, null, null, null, null, true, false);

		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

            
            return isErrorOccurred;
        }


		RolexOtherProductReportingComponent_20847_onClick = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations, this.checkTabErrors))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
KuikaAppManager.showSpinner(this);

const __currentPath = (window.location.hash ? window.location.hash.replace(/^#/, '').split('?')[0] : window.location.pathname.split('?')[0]).toLowerCase();
if (__currentPath !== "/montblancbasedreporting") {
  this.context.setMasterPageInitLoaded(false);
  this.context.setMasterPageRecurringLoaded(false);
  this.context.setShouldTriggerPageInit(true);
}
					KuikaAppManager.prepareForNavigation();

				stateVars.NAVIGATE = await ReactSystemFunctions.navigate(this, undefined, "RolexOtherProductReporting", "MontBlancBasedReporting", "", "currentPage", null, null, null, null, null, null, true, false);

		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

            
            return isErrorOccurred;
        }


		RolexOtherProductReportingComponent_629388_onClick = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations, this.checkTabErrors))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
KuikaAppManager.showSpinner(this);

const __currentPath = (window.location.hash ? window.location.hash.replace(/^#/, '').split('?')[0] : window.location.pathname.split('?')[0]).toLowerCase();
if (__currentPath !== "/dupontbasedreporting") {
  this.context.setMasterPageInitLoaded(false);
  this.context.setMasterPageRecurringLoaded(false);
  this.context.setShouldTriggerPageInit(true);
}
					KuikaAppManager.prepareForNavigation();

				stateVars.NAVIGATE = await ReactSystemFunctions.navigate(this, undefined, "RolexOtherProductReporting", "DupontBasedReporting", "", "currentPage", null, null, null, null, null, null, true, false);

		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

            
            return isErrorOccurred;
        }


		RolexOtherProductReportingComponent_377465_onClick = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations, this.checkTabErrors))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
KuikaAppManager.showSpinner(this);

const __currentPath = (window.location.hash ? window.location.hash.replace(/^#/, '').split('?')[0] : window.location.pathname.split('?')[0]).toLowerCase();
if (__currentPath !== "/rolexbasedreporting") {
  this.context.setMasterPageInitLoaded(false);
  this.context.setMasterPageRecurringLoaded(false);
  this.context.setShouldTriggerPageInit(true);
}
					KuikaAppManager.prepareForNavigation();

				stateVars.NAVIGATE = await ReactSystemFunctions.navigate(this, undefined, "RolexOtherProductReporting", "RolexBasedReporting", "", "currentPage", null, null, null, null, null, null, true, false);

		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

            
            return isErrorOccurred;
        }


		RolexOtherProductReportingComponent_251301_onClick = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations, this.checkTabErrors))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
KuikaAppManager.showSpinner(this);

const __currentPath = (window.location.hash ? window.location.hash.replace(/^#/, '').split('?')[0] : window.location.pathname.split('?')[0]).toLowerCase();
if (__currentPath !== "/rolexbasedreporting") {
  this.context.setMasterPageInitLoaded(false);
  this.context.setMasterPageRecurringLoaded(false);
  this.context.setShouldTriggerPageInit(true);
}
					KuikaAppManager.prepareForNavigation();

				stateVars.NAVIGATE = await ReactSystemFunctions.navigate(this, undefined, "RolexOtherProductReporting", "RolexBasedReporting", "", "currentPage", null, null, null, null, null, null, true, false);

		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

            
            return isErrorOccurred;
        }


		RolexOtherProductReportingComponent_948064_onClick = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations, this.checkTabErrors))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
KuikaAppManager.showSpinner(this);

const __currentPath = (window.location.hash ? window.location.hash.replace(/^#/, '').split('?')[0] : window.location.pathname.split('?')[0]).toLowerCase();
if (__currentPath !== "/rolexfamilyreporting") {
  this.context.setMasterPageInitLoaded(false);
  this.context.setMasterPageRecurringLoaded(false);
  this.context.setShouldTriggerPageInit(true);
}
					KuikaAppManager.prepareForNavigation();

				stateVars.NAVIGATE = await ReactSystemFunctions.navigate(this, undefined, "RolexOtherProductReporting", "RolexFamilyReporting", "", "currentPage", null, null, null, null, null, null, true, false);

		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

            
            return isErrorOccurred;
        }


		RolexOtherProductReportingComponent_727992_onClick = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations, this.checkTabErrors))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
KuikaAppManager.showSpinner(this);

const __currentPath = (window.location.hash ? window.location.hash.replace(/^#/, '').split('?')[0] : window.location.pathname.split('?')[0]).toLowerCase();
if (__currentPath !== "/rolexmaterialreporting") {
  this.context.setMasterPageInitLoaded(false);
  this.context.setMasterPageRecurringLoaded(false);
  this.context.setShouldTriggerPageInit(true);
}
					KuikaAppManager.prepareForNavigation();

				stateVars.NAVIGATE = await ReactSystemFunctions.navigate(this, undefined, "RolexOtherProductReporting", "RolexMaterialReporting", "", "currentPage", null, null, null, null, null, null, true, false);

		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

            
            return isErrorOccurred;
        }


		RolexOtherProductReportingComponent_885746_onClick = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations, this.checkTabErrors))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
KuikaAppManager.showSpinner(this);

const __currentPath = (window.location.hash ? window.location.hash.replace(/^#/, '').split('?')[0] : window.location.pathname.split('?')[0]).toLowerCase();
if (__currentPath !== "/rolexdiameterreporting") {
  this.context.setMasterPageInitLoaded(false);
  this.context.setMasterPageRecurringLoaded(false);
  this.context.setShouldTriggerPageInit(true);
}
					KuikaAppManager.prepareForNavigation();

				stateVars.NAVIGATE = await ReactSystemFunctions.navigate(this, undefined, "RolexOtherProductReporting", "RolexDiameterReporting", "", "currentPage", null, null, null, null, null, null, true, false);

		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

            
            return isErrorOccurred;
        }


    RolexOtherProductReportingComponent_616475_onClick = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations, this.checkTabErrors))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
		KuikaAppManager.increaseServerRequestCount();

        let localVar = {
				value_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, this.state.KuikaY_RolexGrupAylikSatisKarsilastirma_S1), "any"),
				header_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.convertToTypeByName("Rolex Kol Düğmesi 2 Yıl Arası Karşılaştırmalı Ay Bazlı Rapor", "string"), "string"),
				footer_0: ReactSystemFunctions.convertToTypeByName("", "string"),
				columns_0: ReactSystemFunctions.convertToTypeByName("", "string")
        }

		KuikaAppManager.showSpinner(this);
		
        if (true) {
        KuikaAppManager.showSpinner(this);
        }
        let result = await KuikaAppManager.ApiRequest(this, "RolexOtherProductReporting/RolexOtherProductReportingComponent_616475_onClick", localVar)
        if (!KMainFunctions.IsResStatus2XX(result)) return true;

			stateVars.ExportExcel = result?.data.exportExcel;
			ReactSystemFunctions.downloadFile(result?.data?.exportExcel);
			this.props.form?.setFieldsValue(formVars);
			this.setState(stateVars);
			KuikaAppManager.hideSpinner(this);



        this.setPageInitLoaded(true);
        KuikaAppManager.hideSpinner(this);
        return isErrorOccurred;
    }



    RolexOtherProductReportingComponent_80364_onClick = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations, this.checkTabErrors))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
		KuikaAppManager.increaseServerRequestCount();

        let localVar = {
				value_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, this.state.KuikaY_RolexGrupAylikSatisKarsilastirma_S1), "any"),
				header_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.convertToTypeByName("Rolex Kol Düğmesi 2 Yıl Arası Karşılaştırmalı Ocak Ayı Raporu", "string"), "string"),
				footer_0: ReactSystemFunctions.convertToTypeByName("", "string"),
				columns_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.convertToTypeByName("Magaza,Ocak2025,Ocak2026,OcakDegisim", "string"), "string")
        }

		KuikaAppManager.showSpinner(this);
		
        if (true) {
        KuikaAppManager.showSpinner(this);
        }
        let result = await KuikaAppManager.ApiRequest(this, "RolexOtherProductReporting/RolexOtherProductReportingComponent_80364_onClick", localVar)
        if (!KMainFunctions.IsResStatus2XX(result)) return true;

			stateVars.ExportExcel = result?.data.exportExcel;
			ReactSystemFunctions.downloadFile(result?.data?.exportExcel);
			this.props.form?.setFieldsValue(formVars);
			this.setState(stateVars);
			KuikaAppManager.hideSpinner(this);



        this.setPageInitLoaded(true);
        KuikaAppManager.hideSpinner(this);
        return isErrorOccurred;
    }



    RolexOtherProductReportingComponent_701801_onClick = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations, this.checkTabErrors))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
		KuikaAppManager.increaseServerRequestCount();

        let localVar = {
				value_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, this.state.KuikaY_RolexGrupAylikSatisKarsilastirma_S1), "any"),
				header_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.convertToTypeByName("Rolex Kol Düğmesi 2 Yıl Arası Karşılaştırmalı Şubat Ayı Raporu", "string"), "string"),
				footer_0: ReactSystemFunctions.convertToTypeByName("", "string"),
				columns_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.convertToTypeByName("Magaza,Subat2025,Subat2026,SubatDegisim", "string"), "string")
        }

		KuikaAppManager.showSpinner(this);
		
        if (true) {
        KuikaAppManager.showSpinner(this);
        }
        let result = await KuikaAppManager.ApiRequest(this, "RolexOtherProductReporting/RolexOtherProductReportingComponent_701801_onClick", localVar)
        if (!KMainFunctions.IsResStatus2XX(result)) return true;

			stateVars.ExportExcel = result?.data.exportExcel;
			ReactSystemFunctions.downloadFile(result?.data?.exportExcel);
			this.props.form?.setFieldsValue(formVars);
			this.setState(stateVars);
			KuikaAppManager.hideSpinner(this);



        this.setPageInitLoaded(true);
        KuikaAppManager.hideSpinner(this);
        return isErrorOccurred;
    }



    RolexOtherProductReportingComponent_601127_onClick = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations, this.checkTabErrors))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
		KuikaAppManager.increaseServerRequestCount();

        let localVar = {
				value_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, this.state.KuikaY_RolexGrupAylikSatisKarsilastirma_S1), "any"),
				header_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.convertToTypeByName("Rolex Kol Düğmesi 2 Yıl Arası Karşılaştırmalı Mart Ayı Raporu", "string"), "string"),
				footer_0: ReactSystemFunctions.convertToTypeByName("", "string"),
				columns_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.convertToTypeByName("Magaza,Mart2025,Mart2026,MartDegisim", "string"), "string")
        }

		KuikaAppManager.showSpinner(this);
		
        if (true) {
        KuikaAppManager.showSpinner(this);
        }
        let result = await KuikaAppManager.ApiRequest(this, "RolexOtherProductReporting/RolexOtherProductReportingComponent_601127_onClick", localVar)
        if (!KMainFunctions.IsResStatus2XX(result)) return true;

			stateVars.ExportExcel = result?.data.exportExcel;
			ReactSystemFunctions.downloadFile(result?.data?.exportExcel);
			this.props.form?.setFieldsValue(formVars);
			this.setState(stateVars);
			KuikaAppManager.hideSpinner(this);



        this.setPageInitLoaded(true);
        KuikaAppManager.hideSpinner(this);
        return isErrorOccurred;
    }



    RolexOtherProductReportingComponent_545006_onClick = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations, this.checkTabErrors))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
		KuikaAppManager.increaseServerRequestCount();

        let localVar = {
				value_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, this.state.KuikaY_RolexGrupAylikSatisKarsilastirma_S1), "any"),
				header_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.convertToTypeByName("Rolex Kol Düğmesi 2 Yıl Arası Karşılaştırmalı Nisan Ayı Raporu", "string"), "string"),
				footer_0: ReactSystemFunctions.convertToTypeByName("", "string"),
				columns_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.convertToTypeByName("Magaza,Nisan2025,Nisan2026,NisanDegisim", "string"), "string")
        }

		KuikaAppManager.showSpinner(this);
		
        if (true) {
        KuikaAppManager.showSpinner(this);
        }
        let result = await KuikaAppManager.ApiRequest(this, "RolexOtherProductReporting/RolexOtherProductReportingComponent_545006_onClick", localVar)
        if (!KMainFunctions.IsResStatus2XX(result)) return true;

			stateVars.ExportExcel = result?.data.exportExcel;
			ReactSystemFunctions.downloadFile(result?.data?.exportExcel);
			this.props.form?.setFieldsValue(formVars);
			this.setState(stateVars);
			KuikaAppManager.hideSpinner(this);



        this.setPageInitLoaded(true);
        KuikaAppManager.hideSpinner(this);
        return isErrorOccurred;
    }



    RolexOtherProductReportingComponent_824313_onClick = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations, this.checkTabErrors))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
		KuikaAppManager.increaseServerRequestCount();

        let localVar = {
				value_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, this.state.KuikaY_RolexGrupAylikSatisKarsilastirma_S1), "any"),
				header_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.convertToTypeByName("Rolex Kol Düğmesi 2 Yıl Arası Karşılaştırmalı Mayıs Ayı Raporu", "string"), "string"),
				footer_0: ReactSystemFunctions.convertToTypeByName("", "string"),
				columns_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.convertToTypeByName("Magaza,Mayis2025,Mayis2026,MayisDegisim", "string"), "string")
        }

		KuikaAppManager.showSpinner(this);
		
        if (true) {
        KuikaAppManager.showSpinner(this);
        }
        let result = await KuikaAppManager.ApiRequest(this, "RolexOtherProductReporting/RolexOtherProductReportingComponent_824313_onClick", localVar)
        if (!KMainFunctions.IsResStatus2XX(result)) return true;

			stateVars.ExportExcel = result?.data.exportExcel;
			ReactSystemFunctions.downloadFile(result?.data?.exportExcel);
			this.props.form?.setFieldsValue(formVars);
			this.setState(stateVars);
			KuikaAppManager.hideSpinner(this);



        this.setPageInitLoaded(true);
        KuikaAppManager.hideSpinner(this);
        return isErrorOccurred;
    }



    RolexOtherProductReportingComponent_551578_onClick = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations, this.checkTabErrors))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
		KuikaAppManager.increaseServerRequestCount();

        let localVar = {
				value_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, this.state.KuikaY_RolexGrupAylikSatisKarsilastirma_S1), "any"),
				header_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.convertToTypeByName("Rolex Kol Düğmesi 2 Yıl Arası Karşılaştırmalı Haziran Ayı Raporu", "string"), "string"),
				footer_0: ReactSystemFunctions.convertToTypeByName("", "string"),
				columns_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.convertToTypeByName("Magaza,Haziran2025,Haziran2026,HaziranDegisim", "string"), "string")
        }

		KuikaAppManager.showSpinner(this);
		
        if (true) {
        KuikaAppManager.showSpinner(this);
        }
        let result = await KuikaAppManager.ApiRequest(this, "RolexOtherProductReporting/RolexOtherProductReportingComponent_551578_onClick", localVar)
        if (!KMainFunctions.IsResStatus2XX(result)) return true;

			stateVars.ExportExcel = result?.data.exportExcel;
			ReactSystemFunctions.downloadFile(result?.data?.exportExcel);
			this.props.form?.setFieldsValue(formVars);
			this.setState(stateVars);
			KuikaAppManager.hideSpinner(this);



        this.setPageInitLoaded(true);
        KuikaAppManager.hideSpinner(this);
        return isErrorOccurred;
    }



    RolexOtherProductReportingComponent_386843_onClick = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations, this.checkTabErrors))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
		KuikaAppManager.increaseServerRequestCount();

        let localVar = {
				value_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, this.state.KuikaY_RolexGrupAylikSatisKarsilastirma_S1), "any"),
				header_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.convertToTypeByName("Rolex Kol Düğmesi 2 Yıl Arası Karşılaştırmalı Ocak Ayı Raporu", "string"), "string"),
				footer_0: ReactSystemFunctions.convertToTypeByName("", "string"),
				columns_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.convertToTypeByName("Magaza,Temmuz2025,Temmuz2026,TemmuzDegisim", "string"), "string")
        }

		KuikaAppManager.showSpinner(this);
		
        if (true) {
        KuikaAppManager.showSpinner(this);
        }
        let result = await KuikaAppManager.ApiRequest(this, "RolexOtherProductReporting/RolexOtherProductReportingComponent_386843_onClick", localVar)
        if (!KMainFunctions.IsResStatus2XX(result)) return true;

			stateVars.ExportExcel = result?.data.exportExcel;
			ReactSystemFunctions.downloadFile(result?.data?.exportExcel);
			this.props.form?.setFieldsValue(formVars);
			this.setState(stateVars);
			KuikaAppManager.hideSpinner(this);



        this.setPageInitLoaded(true);
        KuikaAppManager.hideSpinner(this);
        return isErrorOccurred;
    }



    RolexOtherProductReportingComponent_693420_onClick = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations, this.checkTabErrors))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
		KuikaAppManager.increaseServerRequestCount();

        let localVar = {
				value_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, this.state.KuikaY_RolexGrupAylikSatisKarsilastirma_S1), "any"),
				header_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.convertToTypeByName("Rolex Kol Düğmesi 2 Yıl Arası Karşılaştırmalı Ağustos Ayı Raporu", "string"), "string"),
				footer_0: ReactSystemFunctions.convertToTypeByName("", "string"),
				columns_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.convertToTypeByName("Magaza,Agustos2025,Agustos2026,AgustosDegisim", "string"), "string")
        }

		KuikaAppManager.showSpinner(this);
		
        if (true) {
        KuikaAppManager.showSpinner(this);
        }
        let result = await KuikaAppManager.ApiRequest(this, "RolexOtherProductReporting/RolexOtherProductReportingComponent_693420_onClick", localVar)
        if (!KMainFunctions.IsResStatus2XX(result)) return true;

			stateVars.ExportExcel = result?.data.exportExcel;
			ReactSystemFunctions.downloadFile(result?.data?.exportExcel);
			this.props.form?.setFieldsValue(formVars);
			this.setState(stateVars);
			KuikaAppManager.hideSpinner(this);



        this.setPageInitLoaded(true);
        KuikaAppManager.hideSpinner(this);
        return isErrorOccurred;
    }



    RolexOtherProductReportingComponent_4525_onClick = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations, this.checkTabErrors))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
		KuikaAppManager.increaseServerRequestCount();

        let localVar = {
				value_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, this.state.KuikaY_RolexGrupAylikSatisKarsilastirma_S1), "any"),
				header_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.convertToTypeByName("Rolex Kol Düğmesi 2 Yıl Arası Karşılaştırmalı Eylül Ayı Raporu", "string"), "string"),
				footer_0: ReactSystemFunctions.convertToTypeByName("", "string"),
				columns_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.convertToTypeByName("Magaza,Eylul2025,Eylul2026,EylulDegisim", "string"), "string")
        }

		KuikaAppManager.showSpinner(this);
		
        if (true) {
        KuikaAppManager.showSpinner(this);
        }
        let result = await KuikaAppManager.ApiRequest(this, "RolexOtherProductReporting/RolexOtherProductReportingComponent_4525_onClick", localVar)
        if (!KMainFunctions.IsResStatus2XX(result)) return true;

			stateVars.ExportExcel = result?.data.exportExcel;
			ReactSystemFunctions.downloadFile(result?.data?.exportExcel);
			this.props.form?.setFieldsValue(formVars);
			this.setState(stateVars);
			KuikaAppManager.hideSpinner(this);



        this.setPageInitLoaded(true);
        KuikaAppManager.hideSpinner(this);
        return isErrorOccurred;
    }



    RolexOtherProductReportingComponent_213735_onClick = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations, this.checkTabErrors))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
		KuikaAppManager.increaseServerRequestCount();

        let localVar = {
				value_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, this.state.KuikaY_RolexGrupAylikSatisKarsilastirma_S1), "any"),
				header_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.convertToTypeByName("Rolex Kol Düğmesi 2 Yıl Arası Karşılaştırmalı Ekim Ayı Raporu", "string"), "string"),
				footer_0: ReactSystemFunctions.convertToTypeByName("", "string"),
				columns_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.convertToTypeByName("Magaza,Ekim2025,Ekim2026,EkimDegisim", "string"), "string")
        }

		KuikaAppManager.showSpinner(this);
		
        if (true) {
        KuikaAppManager.showSpinner(this);
        }
        let result = await KuikaAppManager.ApiRequest(this, "RolexOtherProductReporting/RolexOtherProductReportingComponent_213735_onClick", localVar)
        if (!KMainFunctions.IsResStatus2XX(result)) return true;

			stateVars.ExportExcel = result?.data.exportExcel;
			ReactSystemFunctions.downloadFile(result?.data?.exportExcel);
			this.props.form?.setFieldsValue(formVars);
			this.setState(stateVars);
			KuikaAppManager.hideSpinner(this);



        this.setPageInitLoaded(true);
        KuikaAppManager.hideSpinner(this);
        return isErrorOccurred;
    }



    RolexOtherProductReportingComponent_27453_onClick = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations, this.checkTabErrors))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
		KuikaAppManager.increaseServerRequestCount();

        let localVar = {
				value_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, this.state.KuikaY_RolexGrupAylikSatisKarsilastirma_S1), "any"),
				header_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.convertToTypeByName("Rolex Kol Düğmesi 2 Yıl Arası Karşılaştırmalı Kasım Ayı Raporu", "string"), "string"),
				footer_0: ReactSystemFunctions.convertToTypeByName("", "string"),
				columns_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.convertToTypeByName("Magaza,Kasim2025,Kasim2026,KasimDegisim", "string"), "string")
        }

		KuikaAppManager.showSpinner(this);
		
        if (true) {
        KuikaAppManager.showSpinner(this);
        }
        let result = await KuikaAppManager.ApiRequest(this, "RolexOtherProductReporting/RolexOtherProductReportingComponent_27453_onClick", localVar)
        if (!KMainFunctions.IsResStatus2XX(result)) return true;

			stateVars.ExportExcel = result?.data.exportExcel;
			ReactSystemFunctions.downloadFile(result?.data?.exportExcel);
			this.props.form?.setFieldsValue(formVars);
			this.setState(stateVars);
			KuikaAppManager.hideSpinner(this);



        this.setPageInitLoaded(true);
        KuikaAppManager.hideSpinner(this);
        return isErrorOccurred;
    }



    RolexOtherProductReportingComponent_603178_onClick = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations, this.checkTabErrors))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
		KuikaAppManager.increaseServerRequestCount();

        let localVar = {
				value_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, this.state.KuikaY_RolexGrupAylikSatisKarsilastirma_S1), "any"),
				header_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.convertToTypeByName("Rolex Kol Düğmesi 2 Yıl Arası Karşılaştırmalı Aralık Ayı Raporu", "string"), "string"),
				footer_0: ReactSystemFunctions.convertToTypeByName("", "string"),
				columns_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.convertToTypeByName("Magaza,Aralik2025,Aralik2026,AralikDegisim", "string"), "string")
        }

		KuikaAppManager.showSpinner(this);
		
        if (true) {
        KuikaAppManager.showSpinner(this);
        }
        let result = await KuikaAppManager.ApiRequest(this, "RolexOtherProductReporting/RolexOtherProductReportingComponent_603178_onClick", localVar)
        if (!KMainFunctions.IsResStatus2XX(result)) return true;

			stateVars.ExportExcel = result?.data.exportExcel;
			ReactSystemFunctions.downloadFile(result?.data?.exportExcel);
			this.props.form?.setFieldsValue(formVars);
			this.setState(stateVars);
			KuikaAppManager.hideSpinner(this);



        this.setPageInitLoaded(true);
        KuikaAppManager.hideSpinner(this);
        return isErrorOccurred;
    }



    RolexOtherProductReportingComponent_736558_onClick = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations, this.checkTabErrors))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
		KuikaAppManager.increaseServerRequestCount();

        let localVar = {
				Brand_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.convertToTypeByName("Rolex", "string"), "string"),
				ProductGroup_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.convertToTypeByName("Kitap", "string"), "string"),
				Year1_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "rolexotherproductreporting_556215_value", "value", "", "", "")), "number"),
				Year2_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "rolexotherproductreporting_131933_value", "value", "", "", "")), "number")
        }

		KuikaAppManager.showSpinner(this);
		
        if (true) {
        KuikaAppManager.showSpinner(this);
        }
        let result = await KuikaAppManager.ApiRequest(this, "RolexOtherProductReporting/RolexOtherProductReportingComponent_736558_onClick", localVar)
        if (!KMainFunctions.IsResStatus2XX(result)) return true;

			stateVars.KuikaY_RolexGrupAylikSatisKarsilastirma_S2 = result?.data.kuikaY_RolexGrupAylikSatisKarsilastirma_S2;
			this.props.form?.setFieldsValue(formVars);
			
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.RolexOtherProductReportingComponent_736558_onClick1_();
                  resolve();
                });
          })



        
        KuikaAppManager.hideSpinner(this);
        return isErrorOccurred;
    }
		RolexOtherProductReportingComponent_736558_onClick1_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations, this.checkTabErrors))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }

				
				stateVars.dataSource_275766 = stateVars.KuikaY_RolexGrupAylikSatisKarsilastirma_S1 ?? this.state.KuikaY_RolexGrupAylikSatisKarsilastirma_S1;
				
				stateVars.dataSource_964103 = stateVars.KuikaY_RolexGrupAylikSatisKarsilastirma_S1 ?? this.state.KuikaY_RolexGrupAylikSatisKarsilastirma_S1;
				
				stateVars.dataSource_518172 = stateVars.KuikaY_RolexGrupAylikSatisKarsilastirma_S1 ?? this.state.KuikaY_RolexGrupAylikSatisKarsilastirma_S1;
				
				stateVars.dataSource_664290 = stateVars.KuikaY_RolexGrupAylikSatisKarsilastirma_S1 ?? this.state.KuikaY_RolexGrupAylikSatisKarsilastirma_S1;
				
				stateVars.dataSource_718974 = stateVars.KuikaY_RolexGrupAylikSatisKarsilastirma_S1 ?? this.state.KuikaY_RolexGrupAylikSatisKarsilastirma_S1;
				
				stateVars.dataSource_42801 = stateVars.KuikaY_RolexGrupAylikSatisKarsilastirma_S1 ?? this.state.KuikaY_RolexGrupAylikSatisKarsilastirma_S1;
				
				stateVars.dataSource_792925 = stateVars.KuikaY_RolexGrupAylikSatisKarsilastirma_S1 ?? this.state.KuikaY_RolexGrupAylikSatisKarsilastirma_S1;
				
				stateVars.dataSource_648584 = stateVars.KuikaY_RolexGrupAylikSatisKarsilastirma_S1 ?? this.state.KuikaY_RolexGrupAylikSatisKarsilastirma_S1;
				
				stateVars.dataSource_709026 = stateVars.KuikaY_RolexGrupAylikSatisKarsilastirma_S1 ?? this.state.KuikaY_RolexGrupAylikSatisKarsilastirma_S1;
				
				stateVars.dataSource_819329 = stateVars.KuikaY_RolexGrupAylikSatisKarsilastirma_S1 ?? this.state.KuikaY_RolexGrupAylikSatisKarsilastirma_S1;
				
				stateVars.dataSource_277280 = stateVars.KuikaY_RolexGrupAylikSatisKarsilastirma_S1 ?? this.state.KuikaY_RolexGrupAylikSatisKarsilastirma_S1;
				
				stateVars.dataSource_999621 = stateVars.KuikaY_RolexGrupAylikSatisKarsilastirma_S1 ?? this.state.KuikaY_RolexGrupAylikSatisKarsilastirma_S1;
				
				stateVars.dataSource_229235 = stateVars.KuikaY_RolexGrupAylikSatisKarsilastirma_S1 ?? this.state.KuikaY_RolexGrupAylikSatisKarsilastirma_S1;
				
				stateVars.dataSource_111148 = stateVars.KuikaY_RolexGrupAylikSatisKarsilastirma_S1 ?? this.state.KuikaY_RolexGrupAylikSatisKarsilastirma_S1;
				
				stateVars.dataSource_945811 = stateVars.KuikaY_RolexGrupAylikSatisKarsilastirma_S1 ?? this.state.KuikaY_RolexGrupAylikSatisKarsilastirma_S1;
				
				stateVars.dataSource_748861 = stateVars.KuikaY_RolexGrupAylikSatisKarsilastirma_S1 ?? this.state.KuikaY_RolexGrupAylikSatisKarsilastirma_S1;
				
				stateVars.dataSource_129469 = stateVars.KuikaY_RolexGrupAylikSatisKarsilastirma_S1 ?? this.state.KuikaY_RolexGrupAylikSatisKarsilastirma_S1;
				
				stateVars.dataSource_897693 = stateVars.KuikaY_RolexGrupAylikSatisKarsilastirma_S1 ?? this.state.KuikaY_RolexGrupAylikSatisKarsilastirma_S1;
				
				stateVars.dataSource_135272 = stateVars.KuikaY_RolexGrupAylikSatisKarsilastirma_S1 ?? this.state.KuikaY_RolexGrupAylikSatisKarsilastirma_S1;
				
				stateVars.dataSource_199279 = stateVars.KuikaY_RolexGrupAylikSatisKarsilastirma_S1 ?? this.state.KuikaY_RolexGrupAylikSatisKarsilastirma_S1;
				
				stateVars.dataSource_454237 = stateVars.KuikaY_RolexGrupAylikSatisKarsilastirma_S1 ?? this.state.KuikaY_RolexGrupAylikSatisKarsilastirma_S1;
				
				stateVars.dataSource_628219 = stateVars.KuikaY_RolexGrupAylikSatisKarsilastirma_S1 ?? this.state.KuikaY_RolexGrupAylikSatisKarsilastirma_S1;
				
				stateVars.dataSource_740992 = stateVars.KuikaY_RolexGrupAylikSatisKarsilastirma_S1 ?? this.state.KuikaY_RolexGrupAylikSatisKarsilastirma_S1;
				
				stateVars.dataSource_568723 = stateVars.KuikaY_RolexGrupAylikSatisKarsilastirma_S1 ?? this.state.KuikaY_RolexGrupAylikSatisKarsilastirma_S1;
				
				stateVars.dataSource_954334 = stateVars.KuikaY_RolexGrupAylikSatisKarsilastirma_S1 ?? this.state.KuikaY_RolexGrupAylikSatisKarsilastirma_S1;
				
				stateVars.dataSource_285411 = stateVars.KuikaY_RolexGrupAylikSatisKarsilastirma_S1 ?? this.state.KuikaY_RolexGrupAylikSatisKarsilastirma_S1;
				
				stateVars.dataSource_560631 = stateVars.KuikaY_RolexGrupAylikSatisKarsilastirma_S1 ?? this.state.KuikaY_RolexGrupAylikSatisKarsilastirma_S1;
				
				stateVars.dataSource_187950 = stateVars.KuikaY_RolexGrupAylikSatisKarsilastirma_S1 ?? this.state.KuikaY_RolexGrupAylikSatisKarsilastirma_S1;
				
				stateVars.dataSource_771338 = stateVars.KuikaY_RolexGrupAylikSatisKarsilastirma_S1 ?? this.state.KuikaY_RolexGrupAylikSatisKarsilastirma_S1;
				
				stateVars.dataSource_201235 = stateVars.KuikaY_RolexGrupAylikSatisKarsilastirma_S1 ?? this.state.KuikaY_RolexGrupAylikSatisKarsilastirma_S1;
				
				stateVars.dataSource_98342 = stateVars.KuikaY_RolexGrupAylikSatisKarsilastirma_S1 ?? this.state.KuikaY_RolexGrupAylikSatisKarsilastirma_S1;
				
				stateVars.dataSource_633909 = stateVars.KuikaY_RolexGrupAylikSatisKarsilastirma_S1 ?? this.state.KuikaY_RolexGrupAylikSatisKarsilastirma_S1;
				
				stateVars.dataSource_959130 = stateVars.KuikaY_RolexGrupAylikSatisKarsilastirma_S1 ?? this.state.KuikaY_RolexGrupAylikSatisKarsilastirma_S1;
				
				stateVars.dataSource_218800 = stateVars.KuikaY_RolexGrupAylikSatisKarsilastirma_S1 ?? this.state.KuikaY_RolexGrupAylikSatisKarsilastirma_S1;
				
				stateVars.dataSource_663232 = stateVars.KuikaY_RolexGrupAylikSatisKarsilastirma_S1 ?? this.state.KuikaY_RolexGrupAylikSatisKarsilastirma_S1;
				
				stateVars.dataSource_297134 = stateVars.KuikaY_RolexGrupAylikSatisKarsilastirma_S1 ?? this.state.KuikaY_RolexGrupAylikSatisKarsilastirma_S1;
				
				stateVars.dataSource_936158 = stateVars.KuikaY_RolexGrupAylikSatisKarsilastirma_S1 ?? this.state.KuikaY_RolexGrupAylikSatisKarsilastirma_S1;
				
				stateVars.dataSource_439784 = stateVars.KuikaY_RolexGrupAylikSatisKarsilastirma_S1 ?? this.state.KuikaY_RolexGrupAylikSatisKarsilastirma_S1;
				
				stateVars.dataSource_921927 = stateVars.KuikaY_RolexGrupAylikSatisKarsilastirma_S1 ?? this.state.KuikaY_RolexGrupAylikSatisKarsilastirma_S1;
				
				stateVars.dataSource_721216 = stateVars.KuikaY_RolexGrupAylikSatisKarsilastirma_S1 ?? this.state.KuikaY_RolexGrupAylikSatisKarsilastirma_S1;
				
				stateVars.dataSource_399719 = stateVars.KuikaY_RolexGrupAylikSatisKarsilastirma_S1 ?? this.state.KuikaY_RolexGrupAylikSatisKarsilastirma_S1;
				
				stateVars.dataSource_65682 = stateVars.KuikaY_RolexGrupAylikSatisKarsilastirma_S1 ?? this.state.KuikaY_RolexGrupAylikSatisKarsilastirma_S1;
				
				stateVars.dataSource_887255 = stateVars.KuikaY_RolexGrupAylikSatisKarsilastirma_S1 ?? this.state.KuikaY_RolexGrupAylikSatisKarsilastirma_S1;
				
				stateVars.dataSource_431933 = stateVars.KuikaY_RolexGrupAylikSatisKarsilastirma_S1 ?? this.state.KuikaY_RolexGrupAylikSatisKarsilastirma_S1;
				
				stateVars.dataSource_927967 = stateVars.KuikaY_RolexGrupAylikSatisKarsilastirma_S1 ?? this.state.KuikaY_RolexGrupAylikSatisKarsilastirma_S1;
				
				stateVars.dataSource_97268 = stateVars.KuikaY_RolexGrupAylikSatisKarsilastirma_S1 ?? this.state.KuikaY_RolexGrupAylikSatisKarsilastirma_S1;
				
				stateVars.dataSource_547472 = stateVars.KuikaY_RolexGrupAylikSatisKarsilastirma_S1 ?? this.state.KuikaY_RolexGrupAylikSatisKarsilastirma_S1;
				
				stateVars.dataSource_865953 = stateVars.KuikaY_RolexGrupAylikSatisKarsilastirma_S1 ?? this.state.KuikaY_RolexGrupAylikSatisKarsilastirma_S1;
				
				stateVars.dataSource_937402 = stateVars.KuikaY_RolexGrupAylikSatisKarsilastirma_S1 ?? this.state.KuikaY_RolexGrupAylikSatisKarsilastirma_S1;
				
				stateVars.dataSource_540011 = stateVars.KuikaY_RolexGrupAylikSatisKarsilastirma_S1 ?? this.state.KuikaY_RolexGrupAylikSatisKarsilastirma_S1;
				
				stateVars.dataSource_217447 = stateVars.KuikaY_RolexGrupAylikSatisKarsilastirma_S1 ?? this.state.KuikaY_RolexGrupAylikSatisKarsilastirma_S1;
				
				stateVars.dataSource_214508 = stateVars.KuikaY_RolexGrupAylikSatisKarsilastirma_S1 ?? this.state.KuikaY_RolexGrupAylikSatisKarsilastirma_S1;
				
				stateVars.dataSource_288283 = stateVars.KuikaY_RolexGrupAylikSatisKarsilastirma_S1 ?? this.state.KuikaY_RolexGrupAylikSatisKarsilastirma_S1;
				
				stateVars.dataSource_726679 = stateVars.KuikaY_RolexGrupAylikSatisKarsilastirma_S1 ?? this.state.KuikaY_RolexGrupAylikSatisKarsilastirma_S1;
				
				stateVars.dataSource_637605 = stateVars.KuikaY_RolexGrupAylikSatisKarsilastirma_S1 ?? this.state.KuikaY_RolexGrupAylikSatisKarsilastirma_S1;
				
				stateVars.dataSource_707536 = stateVars.KuikaY_RolexGrupAylikSatisKarsilastirma_S1 ?? this.state.KuikaY_RolexGrupAylikSatisKarsilastirma_S1;
				
				stateVars.dataSource_618611 = stateVars.KuikaY_RolexGrupAylikSatisKarsilastirma_S1 ?? this.state.KuikaY_RolexGrupAylikSatisKarsilastirma_S1;
				
				stateVars.dataSource_751944 = stateVars.KuikaY_RolexGrupAylikSatisKarsilastirma_S1 ?? this.state.KuikaY_RolexGrupAylikSatisKarsilastirma_S1;
				
				stateVars.dataSource_707740 = stateVars.KuikaY_RolexGrupAylikSatisKarsilastirma_S1 ?? this.state.KuikaY_RolexGrupAylikSatisKarsilastirma_S1;
				
				stateVars.dataSource_599192 = stateVars.KuikaY_RolexGrupAylikSatisKarsilastirma_S1 ?? this.state.KuikaY_RolexGrupAylikSatisKarsilastirma_S1;
				
				stateVars.dataSource_248545 = stateVars.KuikaY_RolexGrupAylikSatisKarsilastirma_S1 ?? this.state.KuikaY_RolexGrupAylikSatisKarsilastirma_S1;
				
				stateVars.dataSource_751193 = stateVars.KuikaY_RolexGrupAylikSatisKarsilastirma_S1 ?? this.state.KuikaY_RolexGrupAylikSatisKarsilastirma_S1;
				
				stateVars.dataSource_458677 = stateVars.KuikaY_RolexGrupAylikSatisKarsilastirma_S1 ?? this.state.KuikaY_RolexGrupAylikSatisKarsilastirma_S1;
				
				stateVars.dataSource_404646 = stateVars.KuikaY_RolexGrupAylikSatisKarsilastirma_S1 ?? this.state.KuikaY_RolexGrupAylikSatisKarsilastirma_S1;
				
				stateVars.dataSource_629750 = stateVars.KuikaY_RolexGrupAylikSatisKarsilastirma_S1 ?? this.state.KuikaY_RolexGrupAylikSatisKarsilastirma_S1;
				
				stateVars.dataSource_711149 = stateVars.KuikaY_RolexGrupAylikSatisKarsilastirma_S1 ?? this.state.KuikaY_RolexGrupAylikSatisKarsilastirma_S1;
				
				stateVars.dataSource_649122 = stateVars.KuikaY_RolexGrupAylikSatisKarsilastirma_S1 ?? this.state.KuikaY_RolexGrupAylikSatisKarsilastirma_S1;
				
				stateVars.dataSource_340559 = stateVars.KuikaY_RolexGrupAylikSatisKarsilastirma_S1 ?? this.state.KuikaY_RolexGrupAylikSatisKarsilastirma_S1;
				
				stateVars.dataSource_644418 = stateVars.KuikaY_RolexGrupAylikSatisKarsilastirma_S1 ?? this.state.KuikaY_RolexGrupAylikSatisKarsilastirma_S1;
				
				stateVars.dataSource_630976 = stateVars.KuikaY_RolexGrupAylikSatisKarsilastirma_S1 ?? this.state.KuikaY_RolexGrupAylikSatisKarsilastirma_S1;
				
				stateVars.dataSource_371718 = stateVars.KuikaY_RolexGrupAylikSatisKarsilastirma_S1 ?? this.state.KuikaY_RolexGrupAylikSatisKarsilastirma_S1;
				
				stateVars.dataSource_495338 = stateVars.KuikaY_RolexGrupAylikSatisKarsilastirma_S1 ?? this.state.KuikaY_RolexGrupAylikSatisKarsilastirma_S1;

		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

            
            return isErrorOccurred;
        }




    RolexOtherProductReportingComponent_338196_onClick = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations, this.checkTabErrors))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
		KuikaAppManager.increaseServerRequestCount();

        let localVar = {
				value_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, this.state.KuikaY_RolexGrupAylikSatisKarsilastirma_S1), "any"),
				header_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.convertToTypeByName("Rolex Kitap 2 Yıl Arası Karşılaştırmalı Ay Bazlı Rapor", "string"), "string"),
				footer_0: ReactSystemFunctions.convertToTypeByName("", "string"),
				columns_0: ReactSystemFunctions.convertToTypeByName("", "string")
        }

		KuikaAppManager.showSpinner(this);
		
        if (true) {
        KuikaAppManager.showSpinner(this);
        }
        let result = await KuikaAppManager.ApiRequest(this, "RolexOtherProductReporting/RolexOtherProductReportingComponent_338196_onClick", localVar)
        if (!KMainFunctions.IsResStatus2XX(result)) return true;

			stateVars.ExportExcel = result?.data.exportExcel;
			ReactSystemFunctions.downloadFile(result?.data?.exportExcel);
			this.props.form?.setFieldsValue(formVars);
			this.setState(stateVars);
			KuikaAppManager.hideSpinner(this);



        this.setPageInitLoaded(true);
        KuikaAppManager.hideSpinner(this);
        return isErrorOccurred;
    }



    RolexOtherProductReportingComponent_447049_onClick = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations, this.checkTabErrors))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
		KuikaAppManager.increaseServerRequestCount();

        let localVar = {
				value_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, this.state.KuikaY_RolexGrupAylikSatisKarsilastirma_S1), "any"),
				header_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.convertToTypeByName("Rolex Kitap 2 Yıl Arası Karşılaştırmalı Ocak Ayı Raporu", "string"), "string"),
				footer_0: ReactSystemFunctions.convertToTypeByName("", "string"),
				columns_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.convertToTypeByName("Magaza,Ocak2025,Ocak2026,OcakDegisim", "string"), "string")
        }

		KuikaAppManager.showSpinner(this);
		
        if (true) {
        KuikaAppManager.showSpinner(this);
        }
        let result = await KuikaAppManager.ApiRequest(this, "RolexOtherProductReporting/RolexOtherProductReportingComponent_447049_onClick", localVar)
        if (!KMainFunctions.IsResStatus2XX(result)) return true;

			stateVars.ExportExcel = result?.data.exportExcel;
			ReactSystemFunctions.downloadFile(result?.data?.exportExcel);
			this.props.form?.setFieldsValue(formVars);
			this.setState(stateVars);
			KuikaAppManager.hideSpinner(this);



        this.setPageInitLoaded(true);
        KuikaAppManager.hideSpinner(this);
        return isErrorOccurred;
    }



    RolexOtherProductReportingComponent_124225_onClick = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations, this.checkTabErrors))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
		KuikaAppManager.increaseServerRequestCount();

        let localVar = {
				value_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, this.state.KuikaY_RolexGrupAylikSatisKarsilastirma_S1), "any"),
				header_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.convertToTypeByName("Rolex Kitap 2 Yıl Arası Karşılaştırmalı Şubat Ayı Raporu", "string"), "string"),
				footer_0: ReactSystemFunctions.convertToTypeByName("", "string"),
				columns_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.convertToTypeByName("Magaza,Subat2025,Subat2026,SubatDegisim", "string"), "string")
        }

		KuikaAppManager.showSpinner(this);
		
        if (true) {
        KuikaAppManager.showSpinner(this);
        }
        let result = await KuikaAppManager.ApiRequest(this, "RolexOtherProductReporting/RolexOtherProductReportingComponent_124225_onClick", localVar)
        if (!KMainFunctions.IsResStatus2XX(result)) return true;

			stateVars.ExportExcel = result?.data.exportExcel;
			ReactSystemFunctions.downloadFile(result?.data?.exportExcel);
			this.props.form?.setFieldsValue(formVars);
			this.setState(stateVars);
			KuikaAppManager.hideSpinner(this);



        this.setPageInitLoaded(true);
        KuikaAppManager.hideSpinner(this);
        return isErrorOccurred;
    }



    RolexOtherProductReportingComponent_865445_onClick = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations, this.checkTabErrors))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
		KuikaAppManager.increaseServerRequestCount();

        let localVar = {
				value_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, this.state.KuikaY_RolexGrupAylikSatisKarsilastirma_S1), "any"),
				header_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.convertToTypeByName("Rolex Kitap 2 Yıl Arası Karşılaştırmalı Mart Ayı Raporu", "string"), "string"),
				footer_0: ReactSystemFunctions.convertToTypeByName("", "string"),
				columns_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.convertToTypeByName("Magaza,Mart2025,Mart2026,MartDegisim", "string"), "string")
        }

		KuikaAppManager.showSpinner(this);
		
        if (true) {
        KuikaAppManager.showSpinner(this);
        }
        let result = await KuikaAppManager.ApiRequest(this, "RolexOtherProductReporting/RolexOtherProductReportingComponent_865445_onClick", localVar)
        if (!KMainFunctions.IsResStatus2XX(result)) return true;

			stateVars.ExportExcel = result?.data.exportExcel;
			ReactSystemFunctions.downloadFile(result?.data?.exportExcel);
			this.props.form?.setFieldsValue(formVars);
			this.setState(stateVars);
			KuikaAppManager.hideSpinner(this);



        this.setPageInitLoaded(true);
        KuikaAppManager.hideSpinner(this);
        return isErrorOccurred;
    }



    RolexOtherProductReportingComponent_172862_onClick = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations, this.checkTabErrors))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
		KuikaAppManager.increaseServerRequestCount();

        let localVar = {
				value_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, this.state.KuikaY_RolexGrupAylikSatisKarsilastirma_S1), "any"),
				header_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.convertToTypeByName("Rolex Kitap 2 Yıl Arası Karşılaştırmalı Nisan Ayı Raporu", "string"), "string"),
				footer_0: ReactSystemFunctions.convertToTypeByName("", "string"),
				columns_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.convertToTypeByName("Magaza,Nisan2025,Nisan2026,NisanDegisim", "string"), "string")
        }

		KuikaAppManager.showSpinner(this);
		
        if (true) {
        KuikaAppManager.showSpinner(this);
        }
        let result = await KuikaAppManager.ApiRequest(this, "RolexOtherProductReporting/RolexOtherProductReportingComponent_172862_onClick", localVar)
        if (!KMainFunctions.IsResStatus2XX(result)) return true;

			stateVars.ExportExcel = result?.data.exportExcel;
			ReactSystemFunctions.downloadFile(result?.data?.exportExcel);
			this.props.form?.setFieldsValue(formVars);
			this.setState(stateVars);
			KuikaAppManager.hideSpinner(this);



        this.setPageInitLoaded(true);
        KuikaAppManager.hideSpinner(this);
        return isErrorOccurred;
    }



    RolexOtherProductReportingComponent_851110_onClick = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations, this.checkTabErrors))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
		KuikaAppManager.increaseServerRequestCount();

        let localVar = {
				value_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, this.state.KuikaY_RolexGrupAylikSatisKarsilastirma_S1), "any"),
				header_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.convertToTypeByName("Rolex Kitap 2 Yıl Arası Karşılaştırmalı Mayıs Ayı Raporu", "string"), "string"),
				footer_0: ReactSystemFunctions.convertToTypeByName("", "string"),
				columns_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.convertToTypeByName("Magaza,Mayis2025,Mayis2026,MayisDegisim", "string"), "string")
        }

		KuikaAppManager.showSpinner(this);
		
        if (true) {
        KuikaAppManager.showSpinner(this);
        }
        let result = await KuikaAppManager.ApiRequest(this, "RolexOtherProductReporting/RolexOtherProductReportingComponent_851110_onClick", localVar)
        if (!KMainFunctions.IsResStatus2XX(result)) return true;

			stateVars.ExportExcel = result?.data.exportExcel;
			ReactSystemFunctions.downloadFile(result?.data?.exportExcel);
			this.props.form?.setFieldsValue(formVars);
			this.setState(stateVars);
			KuikaAppManager.hideSpinner(this);



        this.setPageInitLoaded(true);
        KuikaAppManager.hideSpinner(this);
        return isErrorOccurred;
    }



    RolexOtherProductReportingComponent_56305_onClick = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations, this.checkTabErrors))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
		KuikaAppManager.increaseServerRequestCount();

        let localVar = {
				value_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, this.state.KuikaY_RolexGrupAylikSatisKarsilastirma_S1), "any"),
				header_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.convertToTypeByName("Rolex Kitap 2 Yıl Arası Karşılaştırmalı Haziran Ayı Raporu", "string"), "string"),
				footer_0: ReactSystemFunctions.convertToTypeByName("", "string"),
				columns_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.convertToTypeByName("Magaza,Haziran2025,Haziran2026,HaziranDegisim", "string"), "string")
        }

		KuikaAppManager.showSpinner(this);
		
        if (true) {
        KuikaAppManager.showSpinner(this);
        }
        let result = await KuikaAppManager.ApiRequest(this, "RolexOtherProductReporting/RolexOtherProductReportingComponent_56305_onClick", localVar)
        if (!KMainFunctions.IsResStatus2XX(result)) return true;

			stateVars.ExportExcel = result?.data.exportExcel;
			ReactSystemFunctions.downloadFile(result?.data?.exportExcel);
			this.props.form?.setFieldsValue(formVars);
			this.setState(stateVars);
			KuikaAppManager.hideSpinner(this);



        this.setPageInitLoaded(true);
        KuikaAppManager.hideSpinner(this);
        return isErrorOccurred;
    }



    RolexOtherProductReportingComponent_280884_onClick = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations, this.checkTabErrors))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
		KuikaAppManager.increaseServerRequestCount();

        let localVar = {
				value_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, this.state.KuikaY_RolexGrupAylikSatisKarsilastirma_S1), "any"),
				header_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.convertToTypeByName("Rolex Kitap 2 Yıl Arası Karşılaştırmalı Temmuz Ayı Raporu", "string"), "string"),
				footer_0: ReactSystemFunctions.convertToTypeByName("", "string"),
				columns_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.convertToTypeByName("Magaza,Temmuz2025,Temmuz2026,TemmuzDegisim", "string"), "string")
        }

		KuikaAppManager.showSpinner(this);
		
        if (true) {
        KuikaAppManager.showSpinner(this);
        }
        let result = await KuikaAppManager.ApiRequest(this, "RolexOtherProductReporting/RolexOtherProductReportingComponent_280884_onClick", localVar)
        if (!KMainFunctions.IsResStatus2XX(result)) return true;

			stateVars.ExportExcel = result?.data.exportExcel;
			ReactSystemFunctions.downloadFile(result?.data?.exportExcel);
			this.props.form?.setFieldsValue(formVars);
			this.setState(stateVars);
			KuikaAppManager.hideSpinner(this);



        this.setPageInitLoaded(true);
        KuikaAppManager.hideSpinner(this);
        return isErrorOccurred;
    }



    RolexOtherProductReportingComponent_856979_onClick = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations, this.checkTabErrors))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
		KuikaAppManager.increaseServerRequestCount();

        let localVar = {
				value_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, this.state.KuikaY_RolexGrupAylikSatisKarsilastirma_S1), "any"),
				header_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.convertToTypeByName("Rolex Kitap 2 Yıl Arası Karşılaştırmalı Ağustos Ayı Raporu", "string"), "string"),
				footer_0: ReactSystemFunctions.convertToTypeByName("", "string"),
				columns_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.convertToTypeByName("Magaza,Agustos2025,Agustos2026,AgustosDegisim", "string"), "string")
        }

		KuikaAppManager.showSpinner(this);
		
        if (true) {
        KuikaAppManager.showSpinner(this);
        }
        let result = await KuikaAppManager.ApiRequest(this, "RolexOtherProductReporting/RolexOtherProductReportingComponent_856979_onClick", localVar)
        if (!KMainFunctions.IsResStatus2XX(result)) return true;

			stateVars.ExportExcel = result?.data.exportExcel;
			ReactSystemFunctions.downloadFile(result?.data?.exportExcel);
			this.props.form?.setFieldsValue(formVars);
			this.setState(stateVars);
			KuikaAppManager.hideSpinner(this);



        this.setPageInitLoaded(true);
        KuikaAppManager.hideSpinner(this);
        return isErrorOccurred;
    }



    RolexOtherProductReportingComponent_609731_onClick = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations, this.checkTabErrors))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
		KuikaAppManager.increaseServerRequestCount();

        let localVar = {
				value_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, this.state.KuikaY_RolexGrupAylikSatisKarsilastirma_S1), "any"),
				header_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.convertToTypeByName("Rolex Kitap 2 Yıl Arası Karşılaştırmalı Eylül Ayı Raporu", "string"), "string"),
				footer_0: ReactSystemFunctions.convertToTypeByName("", "string"),
				columns_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.convertToTypeByName("Magaza,Eylul2025,Eylul2026,EylulDegisim", "string"), "string")
        }

		KuikaAppManager.showSpinner(this);
		
        if (true) {
        KuikaAppManager.showSpinner(this);
        }
        let result = await KuikaAppManager.ApiRequest(this, "RolexOtherProductReporting/RolexOtherProductReportingComponent_609731_onClick", localVar)
        if (!KMainFunctions.IsResStatus2XX(result)) return true;

			stateVars.ExportExcel = result?.data.exportExcel;
			ReactSystemFunctions.downloadFile(result?.data?.exportExcel);
			this.props.form?.setFieldsValue(formVars);
			this.setState(stateVars);
			KuikaAppManager.hideSpinner(this);



        this.setPageInitLoaded(true);
        KuikaAppManager.hideSpinner(this);
        return isErrorOccurred;
    }



    RolexOtherProductReportingComponent_446473_onClick = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations, this.checkTabErrors))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
		KuikaAppManager.increaseServerRequestCount();

        let localVar = {
				value_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, this.state.KuikaY_RolexGrupAylikSatisKarsilastirma_S1), "any"),
				header_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.convertToTypeByName("Rolex Kitap 2 Yıl Arası Karşılaştırmalı Ekim Ayı Raporu", "string"), "string"),
				footer_0: ReactSystemFunctions.convertToTypeByName("", "string"),
				columns_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.convertToTypeByName("Magaza,Ekim2025,Ekim2026,EkimDegisim", "string"), "string")
        }

		KuikaAppManager.showSpinner(this);
		
        if (true) {
        KuikaAppManager.showSpinner(this);
        }
        let result = await KuikaAppManager.ApiRequest(this, "RolexOtherProductReporting/RolexOtherProductReportingComponent_446473_onClick", localVar)
        if (!KMainFunctions.IsResStatus2XX(result)) return true;

			stateVars.ExportExcel = result?.data.exportExcel;
			ReactSystemFunctions.downloadFile(result?.data?.exportExcel);
			this.props.form?.setFieldsValue(formVars);
			this.setState(stateVars);
			KuikaAppManager.hideSpinner(this);



        this.setPageInitLoaded(true);
        KuikaAppManager.hideSpinner(this);
        return isErrorOccurred;
    }



    RolexOtherProductReportingComponent_487226_onClick = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations, this.checkTabErrors))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
		KuikaAppManager.increaseServerRequestCount();

        let localVar = {
				value_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, this.state.KuikaY_RolexGrupAylikSatisKarsilastirma_S1), "any"),
				header_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.convertToTypeByName("Rolex Kitap 2 Yıl Arası Karşılaştırmalı Kasım Ayı Raporu", "string"), "string"),
				footer_0: ReactSystemFunctions.convertToTypeByName("", "string"),
				columns_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.convertToTypeByName("Magaza,Kasim2025,Kasim2026,KasimDegisim", "string"), "string")
        }

		KuikaAppManager.showSpinner(this);
		
        if (true) {
        KuikaAppManager.showSpinner(this);
        }
        let result = await KuikaAppManager.ApiRequest(this, "RolexOtherProductReporting/RolexOtherProductReportingComponent_487226_onClick", localVar)
        if (!KMainFunctions.IsResStatus2XX(result)) return true;

			stateVars.ExportExcel = result?.data.exportExcel;
			ReactSystemFunctions.downloadFile(result?.data?.exportExcel);
			this.props.form?.setFieldsValue(formVars);
			this.setState(stateVars);
			KuikaAppManager.hideSpinner(this);



        this.setPageInitLoaded(true);
        KuikaAppManager.hideSpinner(this);
        return isErrorOccurred;
    }



    RolexOtherProductReportingComponent_376198_onClick = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations, this.checkTabErrors))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
		KuikaAppManager.increaseServerRequestCount();

        let localVar = {
				value_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, this.state.KuikaY_RolexGrupAylikSatisKarsilastirma_S1), "any"),
				header_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.convertToTypeByName("Rolex Kitap 2 Yıl Arası Karşılaştırmalı Aralık Ayı Raporu", "string"), "string"),
				footer_0: ReactSystemFunctions.convertToTypeByName("", "string"),
				columns_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.convertToTypeByName("Magaza,Aralik2025,Aralik2026,AralikDegisim", "string"), "string")
        }

		KuikaAppManager.showSpinner(this);
		
        if (true) {
        KuikaAppManager.showSpinner(this);
        }
        let result = await KuikaAppManager.ApiRequest(this, "RolexOtherProductReporting/RolexOtherProductReportingComponent_376198_onClick", localVar)
        if (!KMainFunctions.IsResStatus2XX(result)) return true;

			stateVars.ExportExcel = result?.data.exportExcel;
			ReactSystemFunctions.downloadFile(result?.data?.exportExcel);
			this.props.form?.setFieldsValue(formVars);
			this.setState(stateVars);
			KuikaAppManager.hideSpinner(this);



        this.setPageInitLoaded(true);
        KuikaAppManager.hideSpinner(this);
        return isErrorOccurred;
    }



    RolexOtherProductReportingComponent_558385_onClick = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations, this.checkTabErrors))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
		KuikaAppManager.increaseServerRequestCount();

        let localVar = {
				Brand_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.convertToTypeByName("Rolex", "string"), "string"),
				ProductGroup_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.convertToTypeByName("Masa Saati", "string"), "string"),
				Year1_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "rolexotherproductreporting_501380_value", "value", "", "", "")), "number"),
				Year2_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "rolexotherproductreporting_96734_value", "value", "", "", "")), "number")
        }

		KuikaAppManager.showSpinner(this);
		
        if (true) {
        KuikaAppManager.showSpinner(this);
        }
        let result = await KuikaAppManager.ApiRequest(this, "RolexOtherProductReporting/RolexOtherProductReportingComponent_558385_onClick", localVar)
        if (!KMainFunctions.IsResStatus2XX(result)) return true;

			stateVars.KuikaY_RolexGrupAylikSatisKarsilastirma_S3 = result?.data.kuikaY_RolexGrupAylikSatisKarsilastirma_S3;
			this.props.form?.setFieldsValue(formVars);
			
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.RolexOtherProductReportingComponent_558385_onClick1_();
                  resolve();
                });
          })



        
        KuikaAppManager.hideSpinner(this);
        return isErrorOccurred;
    }
		RolexOtherProductReportingComponent_558385_onClick1_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations, this.checkTabErrors))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }

				
				stateVars.dataSource_275766 = stateVars.KuikaY_RolexGrupAylikSatisKarsilastirma_S1 ?? this.state.KuikaY_RolexGrupAylikSatisKarsilastirma_S1;
				
				stateVars.dataSource_964103 = stateVars.KuikaY_RolexGrupAylikSatisKarsilastirma_S1 ?? this.state.KuikaY_RolexGrupAylikSatisKarsilastirma_S1;
				
				stateVars.dataSource_518172 = stateVars.KuikaY_RolexGrupAylikSatisKarsilastirma_S1 ?? this.state.KuikaY_RolexGrupAylikSatisKarsilastirma_S1;
				
				stateVars.dataSource_664290 = stateVars.KuikaY_RolexGrupAylikSatisKarsilastirma_S1 ?? this.state.KuikaY_RolexGrupAylikSatisKarsilastirma_S1;
				
				stateVars.dataSource_718974 = stateVars.KuikaY_RolexGrupAylikSatisKarsilastirma_S1 ?? this.state.KuikaY_RolexGrupAylikSatisKarsilastirma_S1;
				
				stateVars.dataSource_42801 = stateVars.KuikaY_RolexGrupAylikSatisKarsilastirma_S1 ?? this.state.KuikaY_RolexGrupAylikSatisKarsilastirma_S1;
				
				stateVars.dataSource_792925 = stateVars.KuikaY_RolexGrupAylikSatisKarsilastirma_S1 ?? this.state.KuikaY_RolexGrupAylikSatisKarsilastirma_S1;
				
				stateVars.dataSource_648584 = stateVars.KuikaY_RolexGrupAylikSatisKarsilastirma_S1 ?? this.state.KuikaY_RolexGrupAylikSatisKarsilastirma_S1;
				
				stateVars.dataSource_709026 = stateVars.KuikaY_RolexGrupAylikSatisKarsilastirma_S1 ?? this.state.KuikaY_RolexGrupAylikSatisKarsilastirma_S1;
				
				stateVars.dataSource_819329 = stateVars.KuikaY_RolexGrupAylikSatisKarsilastirma_S1 ?? this.state.KuikaY_RolexGrupAylikSatisKarsilastirma_S1;
				
				stateVars.dataSource_277280 = stateVars.KuikaY_RolexGrupAylikSatisKarsilastirma_S1 ?? this.state.KuikaY_RolexGrupAylikSatisKarsilastirma_S1;
				
				stateVars.dataSource_999621 = stateVars.KuikaY_RolexGrupAylikSatisKarsilastirma_S1 ?? this.state.KuikaY_RolexGrupAylikSatisKarsilastirma_S1;
				
				stateVars.dataSource_229235 = stateVars.KuikaY_RolexGrupAylikSatisKarsilastirma_S1 ?? this.state.KuikaY_RolexGrupAylikSatisKarsilastirma_S1;
				
				stateVars.dataSource_111148 = stateVars.KuikaY_RolexGrupAylikSatisKarsilastirma_S1 ?? this.state.KuikaY_RolexGrupAylikSatisKarsilastirma_S1;
				
				stateVars.dataSource_945811 = stateVars.KuikaY_RolexGrupAylikSatisKarsilastirma_S1 ?? this.state.KuikaY_RolexGrupAylikSatisKarsilastirma_S1;
				
				stateVars.dataSource_748861 = stateVars.KuikaY_RolexGrupAylikSatisKarsilastirma_S1 ?? this.state.KuikaY_RolexGrupAylikSatisKarsilastirma_S1;
				
				stateVars.dataSource_129469 = stateVars.KuikaY_RolexGrupAylikSatisKarsilastirma_S1 ?? this.state.KuikaY_RolexGrupAylikSatisKarsilastirma_S1;
				
				stateVars.dataSource_897693 = stateVars.KuikaY_RolexGrupAylikSatisKarsilastirma_S1 ?? this.state.KuikaY_RolexGrupAylikSatisKarsilastirma_S1;
				
				stateVars.dataSource_135272 = stateVars.KuikaY_RolexGrupAylikSatisKarsilastirma_S1 ?? this.state.KuikaY_RolexGrupAylikSatisKarsilastirma_S1;
				
				stateVars.dataSource_199279 = stateVars.KuikaY_RolexGrupAylikSatisKarsilastirma_S1 ?? this.state.KuikaY_RolexGrupAylikSatisKarsilastirma_S1;
				
				stateVars.dataSource_454237 = stateVars.KuikaY_RolexGrupAylikSatisKarsilastirma_S1 ?? this.state.KuikaY_RolexGrupAylikSatisKarsilastirma_S1;
				
				stateVars.dataSource_628219 = stateVars.KuikaY_RolexGrupAylikSatisKarsilastirma_S1 ?? this.state.KuikaY_RolexGrupAylikSatisKarsilastirma_S1;
				
				stateVars.dataSource_740992 = stateVars.KuikaY_RolexGrupAylikSatisKarsilastirma_S1 ?? this.state.KuikaY_RolexGrupAylikSatisKarsilastirma_S1;
				
				stateVars.dataSource_568723 = stateVars.KuikaY_RolexGrupAylikSatisKarsilastirma_S1 ?? this.state.KuikaY_RolexGrupAylikSatisKarsilastirma_S1;
				
				stateVars.dataSource_954334 = stateVars.KuikaY_RolexGrupAylikSatisKarsilastirma_S1 ?? this.state.KuikaY_RolexGrupAylikSatisKarsilastirma_S1;
				
				stateVars.dataSource_285411 = stateVars.KuikaY_RolexGrupAylikSatisKarsilastirma_S1 ?? this.state.KuikaY_RolexGrupAylikSatisKarsilastirma_S1;
				
				stateVars.dataSource_560631 = stateVars.KuikaY_RolexGrupAylikSatisKarsilastirma_S1 ?? this.state.KuikaY_RolexGrupAylikSatisKarsilastirma_S1;
				
				stateVars.dataSource_187950 = stateVars.KuikaY_RolexGrupAylikSatisKarsilastirma_S1 ?? this.state.KuikaY_RolexGrupAylikSatisKarsilastirma_S1;
				
				stateVars.dataSource_771338 = stateVars.KuikaY_RolexGrupAylikSatisKarsilastirma_S1 ?? this.state.KuikaY_RolexGrupAylikSatisKarsilastirma_S1;
				
				stateVars.dataSource_201235 = stateVars.KuikaY_RolexGrupAylikSatisKarsilastirma_S1 ?? this.state.KuikaY_RolexGrupAylikSatisKarsilastirma_S1;
				
				stateVars.dataSource_98342 = stateVars.KuikaY_RolexGrupAylikSatisKarsilastirma_S1 ?? this.state.KuikaY_RolexGrupAylikSatisKarsilastirma_S1;
				
				stateVars.dataSource_633909 = stateVars.KuikaY_RolexGrupAylikSatisKarsilastirma_S1 ?? this.state.KuikaY_RolexGrupAylikSatisKarsilastirma_S1;
				
				stateVars.dataSource_959130 = stateVars.KuikaY_RolexGrupAylikSatisKarsilastirma_S1 ?? this.state.KuikaY_RolexGrupAylikSatisKarsilastirma_S1;
				
				stateVars.dataSource_218800 = stateVars.KuikaY_RolexGrupAylikSatisKarsilastirma_S1 ?? this.state.KuikaY_RolexGrupAylikSatisKarsilastirma_S1;
				
				stateVars.dataSource_663232 = stateVars.KuikaY_RolexGrupAylikSatisKarsilastirma_S1 ?? this.state.KuikaY_RolexGrupAylikSatisKarsilastirma_S1;
				
				stateVars.dataSource_297134 = stateVars.KuikaY_RolexGrupAylikSatisKarsilastirma_S1 ?? this.state.KuikaY_RolexGrupAylikSatisKarsilastirma_S1;
				
				stateVars.dataSource_936158 = stateVars.KuikaY_RolexGrupAylikSatisKarsilastirma_S1 ?? this.state.KuikaY_RolexGrupAylikSatisKarsilastirma_S1;
				
				stateVars.dataSource_439784 = stateVars.KuikaY_RolexGrupAylikSatisKarsilastirma_S1 ?? this.state.KuikaY_RolexGrupAylikSatisKarsilastirma_S1;
				
				stateVars.dataSource_921927 = stateVars.KuikaY_RolexGrupAylikSatisKarsilastirma_S1 ?? this.state.KuikaY_RolexGrupAylikSatisKarsilastirma_S1;
				
				stateVars.dataSource_721216 = stateVars.KuikaY_RolexGrupAylikSatisKarsilastirma_S1 ?? this.state.KuikaY_RolexGrupAylikSatisKarsilastirma_S1;
				
				stateVars.dataSource_399719 = stateVars.KuikaY_RolexGrupAylikSatisKarsilastirma_S1 ?? this.state.KuikaY_RolexGrupAylikSatisKarsilastirma_S1;
				
				stateVars.dataSource_65682 = stateVars.KuikaY_RolexGrupAylikSatisKarsilastirma_S1 ?? this.state.KuikaY_RolexGrupAylikSatisKarsilastirma_S1;
				
				stateVars.dataSource_887255 = stateVars.KuikaY_RolexGrupAylikSatisKarsilastirma_S1 ?? this.state.KuikaY_RolexGrupAylikSatisKarsilastirma_S1;
				
				stateVars.dataSource_431933 = stateVars.KuikaY_RolexGrupAylikSatisKarsilastirma_S1 ?? this.state.KuikaY_RolexGrupAylikSatisKarsilastirma_S1;
				
				stateVars.dataSource_927967 = stateVars.KuikaY_RolexGrupAylikSatisKarsilastirma_S1 ?? this.state.KuikaY_RolexGrupAylikSatisKarsilastirma_S1;
				
				stateVars.dataSource_97268 = stateVars.KuikaY_RolexGrupAylikSatisKarsilastirma_S1 ?? this.state.KuikaY_RolexGrupAylikSatisKarsilastirma_S1;
				
				stateVars.dataSource_547472 = stateVars.KuikaY_RolexGrupAylikSatisKarsilastirma_S1 ?? this.state.KuikaY_RolexGrupAylikSatisKarsilastirma_S1;
				
				stateVars.dataSource_865953 = stateVars.KuikaY_RolexGrupAylikSatisKarsilastirma_S1 ?? this.state.KuikaY_RolexGrupAylikSatisKarsilastirma_S1;
				
				stateVars.dataSource_937402 = stateVars.KuikaY_RolexGrupAylikSatisKarsilastirma_S1 ?? this.state.KuikaY_RolexGrupAylikSatisKarsilastirma_S1;
				
				stateVars.dataSource_540011 = stateVars.KuikaY_RolexGrupAylikSatisKarsilastirma_S1 ?? this.state.KuikaY_RolexGrupAylikSatisKarsilastirma_S1;
				
				stateVars.dataSource_217447 = stateVars.KuikaY_RolexGrupAylikSatisKarsilastirma_S1 ?? this.state.KuikaY_RolexGrupAylikSatisKarsilastirma_S1;
				
				stateVars.dataSource_214508 = stateVars.KuikaY_RolexGrupAylikSatisKarsilastirma_S1 ?? this.state.KuikaY_RolexGrupAylikSatisKarsilastirma_S1;
				
				stateVars.dataSource_288283 = stateVars.KuikaY_RolexGrupAylikSatisKarsilastirma_S1 ?? this.state.KuikaY_RolexGrupAylikSatisKarsilastirma_S1;
				
				stateVars.dataSource_726679 = stateVars.KuikaY_RolexGrupAylikSatisKarsilastirma_S1 ?? this.state.KuikaY_RolexGrupAylikSatisKarsilastirma_S1;
				
				stateVars.dataSource_637605 = stateVars.KuikaY_RolexGrupAylikSatisKarsilastirma_S1 ?? this.state.KuikaY_RolexGrupAylikSatisKarsilastirma_S1;
				
				stateVars.dataSource_707536 = stateVars.KuikaY_RolexGrupAylikSatisKarsilastirma_S1 ?? this.state.KuikaY_RolexGrupAylikSatisKarsilastirma_S1;
				
				stateVars.dataSource_618611 = stateVars.KuikaY_RolexGrupAylikSatisKarsilastirma_S1 ?? this.state.KuikaY_RolexGrupAylikSatisKarsilastirma_S1;
				
				stateVars.dataSource_751944 = stateVars.KuikaY_RolexGrupAylikSatisKarsilastirma_S1 ?? this.state.KuikaY_RolexGrupAylikSatisKarsilastirma_S1;
				
				stateVars.dataSource_707740 = stateVars.KuikaY_RolexGrupAylikSatisKarsilastirma_S1 ?? this.state.KuikaY_RolexGrupAylikSatisKarsilastirma_S1;
				
				stateVars.dataSource_599192 = stateVars.KuikaY_RolexGrupAylikSatisKarsilastirma_S1 ?? this.state.KuikaY_RolexGrupAylikSatisKarsilastirma_S1;
				
				stateVars.dataSource_248545 = stateVars.KuikaY_RolexGrupAylikSatisKarsilastirma_S1 ?? this.state.KuikaY_RolexGrupAylikSatisKarsilastirma_S1;
				
				stateVars.dataSource_751193 = stateVars.KuikaY_RolexGrupAylikSatisKarsilastirma_S1 ?? this.state.KuikaY_RolexGrupAylikSatisKarsilastirma_S1;
				
				stateVars.dataSource_458677 = stateVars.KuikaY_RolexGrupAylikSatisKarsilastirma_S1 ?? this.state.KuikaY_RolexGrupAylikSatisKarsilastirma_S1;
				
				stateVars.dataSource_404646 = stateVars.KuikaY_RolexGrupAylikSatisKarsilastirma_S1 ?? this.state.KuikaY_RolexGrupAylikSatisKarsilastirma_S1;
				
				stateVars.dataSource_629750 = stateVars.KuikaY_RolexGrupAylikSatisKarsilastirma_S1 ?? this.state.KuikaY_RolexGrupAylikSatisKarsilastirma_S1;
				
				stateVars.dataSource_711149 = stateVars.KuikaY_RolexGrupAylikSatisKarsilastirma_S1 ?? this.state.KuikaY_RolexGrupAylikSatisKarsilastirma_S1;
				
				stateVars.dataSource_649122 = stateVars.KuikaY_RolexGrupAylikSatisKarsilastirma_S1 ?? this.state.KuikaY_RolexGrupAylikSatisKarsilastirma_S1;
				
				stateVars.dataSource_340559 = stateVars.KuikaY_RolexGrupAylikSatisKarsilastirma_S1 ?? this.state.KuikaY_RolexGrupAylikSatisKarsilastirma_S1;
				
				stateVars.dataSource_644418 = stateVars.KuikaY_RolexGrupAylikSatisKarsilastirma_S1 ?? this.state.KuikaY_RolexGrupAylikSatisKarsilastirma_S1;
				
				stateVars.dataSource_630976 = stateVars.KuikaY_RolexGrupAylikSatisKarsilastirma_S1 ?? this.state.KuikaY_RolexGrupAylikSatisKarsilastirma_S1;
				
				stateVars.dataSource_371718 = stateVars.KuikaY_RolexGrupAylikSatisKarsilastirma_S1 ?? this.state.KuikaY_RolexGrupAylikSatisKarsilastirma_S1;
				
				stateVars.dataSource_495338 = stateVars.KuikaY_RolexGrupAylikSatisKarsilastirma_S1 ?? this.state.KuikaY_RolexGrupAylikSatisKarsilastirma_S1;

		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

            
            return isErrorOccurred;
        }




    RolexOtherProductReportingComponent_142785_onClick = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations, this.checkTabErrors))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
		KuikaAppManager.increaseServerRequestCount();

        let localVar = {
				value_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, this.state.KuikaY_RolexGrupAylikSatisKarsilastirma_S1), "any"),
				header_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.convertToTypeByName("Rolex Masa Saati 2 Yıl Arası Karşılaştırmalı Ay Bazlı Rapor", "string"), "string"),
				footer_0: ReactSystemFunctions.convertToTypeByName("", "string"),
				columns_0: ReactSystemFunctions.convertToTypeByName("", "string")
        }

		KuikaAppManager.showSpinner(this);
		
        if (true) {
        KuikaAppManager.showSpinner(this);
        }
        let result = await KuikaAppManager.ApiRequest(this, "RolexOtherProductReporting/RolexOtherProductReportingComponent_142785_onClick", localVar)
        if (!KMainFunctions.IsResStatus2XX(result)) return true;

			stateVars.ExportExcel = result?.data.exportExcel;
			ReactSystemFunctions.downloadFile(result?.data?.exportExcel);
			this.props.form?.setFieldsValue(formVars);
			this.setState(stateVars);
			KuikaAppManager.hideSpinner(this);



        this.setPageInitLoaded(true);
        KuikaAppManager.hideSpinner(this);
        return isErrorOccurred;
    }



    RolexOtherProductReportingComponent_408362_onClick = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations, this.checkTabErrors))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
		KuikaAppManager.increaseServerRequestCount();

        let localVar = {
				value_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, this.state.KuikaY_RolexGrupAylikSatisKarsilastirma_S1), "any"),
				header_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.convertToTypeByName("Rolex Masa Saati 2 Yıl Arası Karşılaştırmalı Ocak Ayı Raporu", "string"), "string"),
				footer_0: ReactSystemFunctions.convertToTypeByName("", "string"),
				columns_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.convertToTypeByName("Magaza,Ocak2025,Ocak2026,OcakDegisim", "string"), "string")
        }

		KuikaAppManager.showSpinner(this);
		
        if (true) {
        KuikaAppManager.showSpinner(this);
        }
        let result = await KuikaAppManager.ApiRequest(this, "RolexOtherProductReporting/RolexOtherProductReportingComponent_408362_onClick", localVar)
        if (!KMainFunctions.IsResStatus2XX(result)) return true;

			stateVars.ExportExcel = result?.data.exportExcel;
			ReactSystemFunctions.downloadFile(result?.data?.exportExcel);
			this.props.form?.setFieldsValue(formVars);
			this.setState(stateVars);
			KuikaAppManager.hideSpinner(this);



        this.setPageInitLoaded(true);
        KuikaAppManager.hideSpinner(this);
        return isErrorOccurred;
    }



    RolexOtherProductReportingComponent_243711_onClick = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations, this.checkTabErrors))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
		KuikaAppManager.increaseServerRequestCount();

        let localVar = {
				value_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, this.state.KuikaY_RolexGrupAylikSatisKarsilastirma_S1), "any"),
				header_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.convertToTypeByName("Rolex Masa Saati 2 Yıl Arası Karşılaştırmalı Şubat Ayı Raporu", "string"), "string"),
				footer_0: ReactSystemFunctions.convertToTypeByName("", "string"),
				columns_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.convertToTypeByName("Magaza,Subat2025,Subat2026,SubatDegisim", "string"), "string")
        }

		KuikaAppManager.showSpinner(this);
		
        if (true) {
        KuikaAppManager.showSpinner(this);
        }
        let result = await KuikaAppManager.ApiRequest(this, "RolexOtherProductReporting/RolexOtherProductReportingComponent_243711_onClick", localVar)
        if (!KMainFunctions.IsResStatus2XX(result)) return true;

			stateVars.ExportExcel = result?.data.exportExcel;
			ReactSystemFunctions.downloadFile(result?.data?.exportExcel);
			this.props.form?.setFieldsValue(formVars);
			this.setState(stateVars);
			KuikaAppManager.hideSpinner(this);



        this.setPageInitLoaded(true);
        KuikaAppManager.hideSpinner(this);
        return isErrorOccurred;
    }



    RolexOtherProductReportingComponent_101219_onClick = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations, this.checkTabErrors))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
		KuikaAppManager.increaseServerRequestCount();

        let localVar = {
				value_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, this.state.KuikaY_RolexGrupAylikSatisKarsilastirma_S1), "any"),
				header_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.convertToTypeByName("Rolex Masa Saati 2 Yıl Arası Karşılaştırmalı Mart Ayı Raporu", "string"), "string"),
				footer_0: ReactSystemFunctions.convertToTypeByName("", "string"),
				columns_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.convertToTypeByName("Magaza,Mart2025,Mart2026,MartDegisim", "string"), "string")
        }

		KuikaAppManager.showSpinner(this);
		
        if (true) {
        KuikaAppManager.showSpinner(this);
        }
        let result = await KuikaAppManager.ApiRequest(this, "RolexOtherProductReporting/RolexOtherProductReportingComponent_101219_onClick", localVar)
        if (!KMainFunctions.IsResStatus2XX(result)) return true;

			stateVars.ExportExcel = result?.data.exportExcel;
			ReactSystemFunctions.downloadFile(result?.data?.exportExcel);
			this.props.form?.setFieldsValue(formVars);
			this.setState(stateVars);
			KuikaAppManager.hideSpinner(this);



        this.setPageInitLoaded(true);
        KuikaAppManager.hideSpinner(this);
        return isErrorOccurred;
    }



    RolexOtherProductReportingComponent_141570_onClick = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations, this.checkTabErrors))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
		KuikaAppManager.increaseServerRequestCount();

        let localVar = {
				value_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, this.state.KuikaY_RolexGrupAylikSatisKarsilastirma_S1), "any"),
				header_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.convertToTypeByName("Rolex Masa Saati 2 Yıl Arası Karşılaştırmalı Nisan Ayı Raporu", "string"), "string"),
				footer_0: ReactSystemFunctions.convertToTypeByName("", "string"),
				columns_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.convertToTypeByName("Magaza,Nisan2025,Nisan2026,NisanDegisim", "string"), "string")
        }

		KuikaAppManager.showSpinner(this);
		
        if (true) {
        KuikaAppManager.showSpinner(this);
        }
        let result = await KuikaAppManager.ApiRequest(this, "RolexOtherProductReporting/RolexOtherProductReportingComponent_141570_onClick", localVar)
        if (!KMainFunctions.IsResStatus2XX(result)) return true;

			stateVars.ExportExcel = result?.data.exportExcel;
			ReactSystemFunctions.downloadFile(result?.data?.exportExcel);
			this.props.form?.setFieldsValue(formVars);
			this.setState(stateVars);
			KuikaAppManager.hideSpinner(this);



        this.setPageInitLoaded(true);
        KuikaAppManager.hideSpinner(this);
        return isErrorOccurred;
    }



    RolexOtherProductReportingComponent_388935_onClick = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations, this.checkTabErrors))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
		KuikaAppManager.increaseServerRequestCount();

        let localVar = {
				value_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, this.state.KuikaY_RolexGrupAylikSatisKarsilastirma_S1), "any"),
				header_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.convertToTypeByName("Rolex Masa Saati 2 Yıl Arası Karşılaştırmalı Mayıs Ayı Raporu", "string"), "string"),
				footer_0: ReactSystemFunctions.convertToTypeByName("", "string"),
				columns_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.convertToTypeByName("Magaza,Mayis2025,Mayis2026,MayisDegisim", "string"), "string")
        }

		KuikaAppManager.showSpinner(this);
		
        if (true) {
        KuikaAppManager.showSpinner(this);
        }
        let result = await KuikaAppManager.ApiRequest(this, "RolexOtherProductReporting/RolexOtherProductReportingComponent_388935_onClick", localVar)
        if (!KMainFunctions.IsResStatus2XX(result)) return true;

			stateVars.ExportExcel = result?.data.exportExcel;
			ReactSystemFunctions.downloadFile(result?.data?.exportExcel);
			this.props.form?.setFieldsValue(formVars);
			this.setState(stateVars);
			KuikaAppManager.hideSpinner(this);



        this.setPageInitLoaded(true);
        KuikaAppManager.hideSpinner(this);
        return isErrorOccurred;
    }



    RolexOtherProductReportingComponent_790629_onClick = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations, this.checkTabErrors))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
		KuikaAppManager.increaseServerRequestCount();

        let localVar = {
				value_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, this.state.KuikaY_RolexGrupAylikSatisKarsilastirma_S1), "any"),
				header_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.convertToTypeByName("Rolex Masa Saati 2 Yıl Arası Karşılaştırmalı Haziran Ayı Raporu", "string"), "string"),
				footer_0: ReactSystemFunctions.convertToTypeByName("", "string"),
				columns_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.convertToTypeByName("Magaza,Haziran2025,Haziran2026,HaziranDegisim", "string"), "string")
        }

		KuikaAppManager.showSpinner(this);
		
        if (true) {
        KuikaAppManager.showSpinner(this);
        }
        let result = await KuikaAppManager.ApiRequest(this, "RolexOtherProductReporting/RolexOtherProductReportingComponent_790629_onClick", localVar)
        if (!KMainFunctions.IsResStatus2XX(result)) return true;

			stateVars.ExportExcel = result?.data.exportExcel;
			ReactSystemFunctions.downloadFile(result?.data?.exportExcel);
			this.props.form?.setFieldsValue(formVars);
			this.setState(stateVars);
			KuikaAppManager.hideSpinner(this);



        this.setPageInitLoaded(true);
        KuikaAppManager.hideSpinner(this);
        return isErrorOccurred;
    }



    RolexOtherProductReportingComponent_731922_onClick = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations, this.checkTabErrors))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
		KuikaAppManager.increaseServerRequestCount();

        let localVar = {
				value_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, this.state.KuikaY_RolexGrupAylikSatisKarsilastirma_S1), "any"),
				header_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.convertToTypeByName("Rolex Masa Saati 2 Yıl Arası Karşılaştırmalı Temmuz Ayı Raporu", "string"), "string"),
				footer_0: ReactSystemFunctions.convertToTypeByName("", "string"),
				columns_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.convertToTypeByName("Magaza,Temmuz2025,Temmuz2026,TemmuzDegisim", "string"), "string")
        }

		KuikaAppManager.showSpinner(this);
		
        if (true) {
        KuikaAppManager.showSpinner(this);
        }
        let result = await KuikaAppManager.ApiRequest(this, "RolexOtherProductReporting/RolexOtherProductReportingComponent_731922_onClick", localVar)
        if (!KMainFunctions.IsResStatus2XX(result)) return true;

			stateVars.ExportExcel = result?.data.exportExcel;
			ReactSystemFunctions.downloadFile(result?.data?.exportExcel);
			this.props.form?.setFieldsValue(formVars);
			this.setState(stateVars);
			KuikaAppManager.hideSpinner(this);



        this.setPageInitLoaded(true);
        KuikaAppManager.hideSpinner(this);
        return isErrorOccurred;
    }



    RolexOtherProductReportingComponent_724984_onClick = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations, this.checkTabErrors))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
		KuikaAppManager.increaseServerRequestCount();

        let localVar = {
				value_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, this.state.KuikaY_RolexGrupAylikSatisKarsilastirma_S1), "any"),
				header_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.convertToTypeByName("Rolex Masa Saati 2 Yıl Arası Karşılaştırmalı Ağustos Ayı Raporu", "string"), "string"),
				footer_0: ReactSystemFunctions.convertToTypeByName("", "string"),
				columns_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.convertToTypeByName("Magaza,Agustos2025,Agustos2026,AgustosDegisim", "string"), "string")
        }

		KuikaAppManager.showSpinner(this);
		
        if (true) {
        KuikaAppManager.showSpinner(this);
        }
        let result = await KuikaAppManager.ApiRequest(this, "RolexOtherProductReporting/RolexOtherProductReportingComponent_724984_onClick", localVar)
        if (!KMainFunctions.IsResStatus2XX(result)) return true;

			stateVars.ExportExcel = result?.data.exportExcel;
			ReactSystemFunctions.downloadFile(result?.data?.exportExcel);
			this.props.form?.setFieldsValue(formVars);
			this.setState(stateVars);
			KuikaAppManager.hideSpinner(this);



        this.setPageInitLoaded(true);
        KuikaAppManager.hideSpinner(this);
        return isErrorOccurred;
    }



    RolexOtherProductReportingComponent_265717_onClick = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations, this.checkTabErrors))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
		KuikaAppManager.increaseServerRequestCount();

        let localVar = {
				value_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, this.state.KuikaY_RolexGrupAylikSatisKarsilastirma_S1), "any"),
				header_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.convertToTypeByName("Rolex Masa Saati 2 Yıl Arası Karşılaştırmalı Eylül Ayı Raporu", "string"), "string"),
				footer_0: ReactSystemFunctions.convertToTypeByName("", "string"),
				columns_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.convertToTypeByName("Magaza,Eylul2025,Eylul2026,EylulDegisim", "string"), "string")
        }

		KuikaAppManager.showSpinner(this);
		
        if (true) {
        KuikaAppManager.showSpinner(this);
        }
        let result = await KuikaAppManager.ApiRequest(this, "RolexOtherProductReporting/RolexOtherProductReportingComponent_265717_onClick", localVar)
        if (!KMainFunctions.IsResStatus2XX(result)) return true;

			stateVars.ExportExcel = result?.data.exportExcel;
			ReactSystemFunctions.downloadFile(result?.data?.exportExcel);
			this.props.form?.setFieldsValue(formVars);
			this.setState(stateVars);
			KuikaAppManager.hideSpinner(this);



        this.setPageInitLoaded(true);
        KuikaAppManager.hideSpinner(this);
        return isErrorOccurred;
    }



    RolexOtherProductReportingComponent_737833_onClick = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations, this.checkTabErrors))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
		KuikaAppManager.increaseServerRequestCount();

        let localVar = {
				value_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, this.state.KuikaY_RolexGrupAylikSatisKarsilastirma_S1), "any"),
				header_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.convertToTypeByName("Rolex Masa Saati 2 Yıl Arası Karşılaştırmalı Ekim Ayı Raporu", "string"), "string"),
				footer_0: ReactSystemFunctions.convertToTypeByName("", "string"),
				columns_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.convertToTypeByName("Magaza,Ekim2025,Ekim2026,EkimDegisim", "string"), "string")
        }

		KuikaAppManager.showSpinner(this);
		
        if (true) {
        KuikaAppManager.showSpinner(this);
        }
        let result = await KuikaAppManager.ApiRequest(this, "RolexOtherProductReporting/RolexOtherProductReportingComponent_737833_onClick", localVar)
        if (!KMainFunctions.IsResStatus2XX(result)) return true;

			stateVars.ExportExcel = result?.data.exportExcel;
			ReactSystemFunctions.downloadFile(result?.data?.exportExcel);
			this.props.form?.setFieldsValue(formVars);
			this.setState(stateVars);
			KuikaAppManager.hideSpinner(this);



        this.setPageInitLoaded(true);
        KuikaAppManager.hideSpinner(this);
        return isErrorOccurred;
    }



    RolexOtherProductReportingComponent_64314_onClick = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations, this.checkTabErrors))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
		KuikaAppManager.increaseServerRequestCount();

        let localVar = {
				value_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, this.state.KuikaY_RolexGrupAylikSatisKarsilastirma_S1), "any"),
				header_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.convertToTypeByName("Rolex Masa Saati 2 Yıl Arası Karşılaştırmalı Kasım Ayı Raporu", "string"), "string"),
				footer_0: ReactSystemFunctions.convertToTypeByName("", "string"),
				columns_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.convertToTypeByName("Magaza,Kasim2025,Kasim2026,KasimDegisim", "string"), "string")
        }

		KuikaAppManager.showSpinner(this);
		
        if (true) {
        KuikaAppManager.showSpinner(this);
        }
        let result = await KuikaAppManager.ApiRequest(this, "RolexOtherProductReporting/RolexOtherProductReportingComponent_64314_onClick", localVar)
        if (!KMainFunctions.IsResStatus2XX(result)) return true;

			stateVars.ExportExcel = result?.data.exportExcel;
			ReactSystemFunctions.downloadFile(result?.data?.exportExcel);
			this.props.form?.setFieldsValue(formVars);
			this.setState(stateVars);
			KuikaAppManager.hideSpinner(this);



        this.setPageInitLoaded(true);
        KuikaAppManager.hideSpinner(this);
        return isErrorOccurred;
    }



    RolexOtherProductReportingComponent_188388_onClick = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations, this.checkTabErrors))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
		KuikaAppManager.increaseServerRequestCount();

        let localVar = {
				value_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, this.state.KuikaY_RolexGrupAylikSatisKarsilastirma_S1), "any"),
				header_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.convertToTypeByName("Rolex Masa Saati 2 Yıl Arası Karşılaştırmalı Aralık Ayı Raporu", "string"), "string"),
				footer_0: ReactSystemFunctions.convertToTypeByName("", "string"),
				columns_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.convertToTypeByName("Magaza,Aralik2025,Aralik2026,AralikDegisim", "string"), "string")
        }

		KuikaAppManager.showSpinner(this);
		
        if (true) {
        KuikaAppManager.showSpinner(this);
        }
        let result = await KuikaAppManager.ApiRequest(this, "RolexOtherProductReporting/RolexOtherProductReportingComponent_188388_onClick", localVar)
        if (!KMainFunctions.IsResStatus2XX(result)) return true;

			stateVars.ExportExcel = result?.data.exportExcel;
			ReactSystemFunctions.downloadFile(result?.data?.exportExcel);
			this.props.form?.setFieldsValue(formVars);
			this.setState(stateVars);
			KuikaAppManager.hideSpinner(this);



        this.setPageInitLoaded(true);
        KuikaAppManager.hideSpinner(this);
        return isErrorOccurred;
    }



		RolexOtherProductReportingComponent_585930_onChange = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations, this.checkTabErrors))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
KuikaAppManager.showSpinner(this);

				
				ReactSystemFunctions.setValueOf(this, "rolexotherproductreporting_706774_toString", ReactSystemFunctions.value(this, "rolexotherproductreporting_585930_value", "value"), "value");

				
				ReactSystemFunctions.setValueOf(this, "rolexotherproductreporting_349724_toString", ReactSystemFunctions.value(this, "rolexotherproductreporting_585930_value", "value"), "value");

				
				ReactSystemFunctions.setValueOf(this, "rolexotherproductreporting_726664_toString", ReactSystemFunctions.value(this, "rolexotherproductreporting_585930_value", "value"), "value");

				
				ReactSystemFunctions.setValueOf(this, "rolexotherproductreporting_990501_toString", ReactSystemFunctions.value(this, "rolexotherproductreporting_585930_value", "value"), "value");

				
				ReactSystemFunctions.setValueOf(this, "rolexotherproductreporting_981244_toString", ReactSystemFunctions.value(this, "rolexotherproductreporting_585930_value", "value"), "value");

				
				ReactSystemFunctions.setValueOf(this, "rolexotherproductreporting_484491_toString", ReactSystemFunctions.value(this, "rolexotherproductreporting_585930_value", "value"), "value");

				
				ReactSystemFunctions.setValueOf(this, "rolexotherproductreporting_950927_toString", ReactSystemFunctions.value(this, "rolexotherproductreporting_585930_value", "value"), "value");

				
				ReactSystemFunctions.setValueOf(this, "rolexotherproductreporting_386207_toString", ReactSystemFunctions.value(this, "rolexotherproductreporting_585930_value", "value"), "value");

				
				ReactSystemFunctions.setValueOf(this, "rolexotherproductreporting_977033_toString", ReactSystemFunctions.value(this, "rolexotherproductreporting_585930_value", "value"), "value");

				
				ReactSystemFunctions.setValueOf(this, "rolexotherproductreporting_704294_toString", ReactSystemFunctions.value(this, "rolexotherproductreporting_585930_value", "value"), "value");

				
				ReactSystemFunctions.setValueOf(this, "rolexotherproductreporting_728979_toString", ReactSystemFunctions.value(this, "rolexotherproductreporting_585930_value", "value"), "value");

				
				ReactSystemFunctions.setValueOf(this, "rolexotherproductreporting_419462_toString", ReactSystemFunctions.value(this, "rolexotherproductreporting_585930_value", "value"), "value");


		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

            
            return isErrorOccurred;
        }


		RolexOtherProductReportingComponent_420182_onChange = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations, this.checkTabErrors))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
KuikaAppManager.showSpinner(this);

				
				ReactSystemFunctions.setValueOf(this, "rolexotherproductreporting_975801_toString", ReactSystemFunctions.value(this, "rolexotherproductreporting_420182_value", "value"), "value");

				
				ReactSystemFunctions.setValueOf(this, "rolexotherproductreporting_275539_toString", ReactSystemFunctions.value(this, "rolexotherproductreporting_420182_value", "value"), "value");

				
				ReactSystemFunctions.setValueOf(this, "rolexotherproductreporting_187296_toString", ReactSystemFunctions.value(this, "rolexotherproductreporting_420182_value", "value"), "value");

				
				ReactSystemFunctions.setValueOf(this, "rolexotherproductreporting_187489_toString", ReactSystemFunctions.value(this, "rolexotherproductreporting_420182_value", "value"), "value");

				
				ReactSystemFunctions.setValueOf(this, "rolexotherproductreporting_995178_toString", ReactSystemFunctions.value(this, "rolexotherproductreporting_420182_value", "value"), "value");

				
				ReactSystemFunctions.setValueOf(this, "rolexotherproductreporting_370958_toString", ReactSystemFunctions.value(this, "rolexotherproductreporting_420182_value", "value"), "value");

				
				ReactSystemFunctions.setValueOf(this, "rolexotherproductreporting_360493_toString", ReactSystemFunctions.value(this, "rolexotherproductreporting_420182_value", "value"), "value");

				
				ReactSystemFunctions.setValueOf(this, "rolexotherproductreporting_23840_toString", ReactSystemFunctions.value(this, "rolexotherproductreporting_420182_value", "value"), "value");

				
				ReactSystemFunctions.setValueOf(this, "rolexotherproductreporting_833300_toString", ReactSystemFunctions.value(this, "rolexotherproductreporting_420182_value", "value"), "value");

				
				ReactSystemFunctions.setValueOf(this, "rolexotherproductreporting_696535_toString", ReactSystemFunctions.value(this, "rolexotherproductreporting_420182_value", "value"), "value");

				
				ReactSystemFunctions.setValueOf(this, "rolexotherproductreporting_301836_toString", ReactSystemFunctions.value(this, "rolexotherproductreporting_420182_value", "value"), "value");

				
				ReactSystemFunctions.setValueOf(this, "rolexotherproductreporting_376605_toString", ReactSystemFunctions.value(this, "rolexotherproductreporting_420182_value", "value"), "value");


		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

            
            return isErrorOccurred;
        }


		RolexOtherProductReportingComponent_556215_onChange = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations, this.checkTabErrors))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
KuikaAppManager.showSpinner(this);

				
				ReactSystemFunctions.setValueOf(this, "rolexotherproductreporting_561867_toString", ReactSystemFunctions.value(this, "rolexotherproductreporting_556215_value", "value"), "value");

				
				ReactSystemFunctions.setValueOf(this, "rolexotherproductreporting_699935_toString", ReactSystemFunctions.value(this, "rolexotherproductreporting_556215_value", "value"), "value");

				
				ReactSystemFunctions.setValueOf(this, "rolexotherproductreporting_454310_toString", ReactSystemFunctions.value(this, "rolexotherproductreporting_556215_value", "value"), "value");

				
				ReactSystemFunctions.setValueOf(this, "rolexotherproductreporting_158260_toString", ReactSystemFunctions.value(this, "rolexotherproductreporting_556215_value", "value"), "value");

				
				ReactSystemFunctions.setValueOf(this, "rolexotherproductreporting_399502_toString", ReactSystemFunctions.value(this, "rolexotherproductreporting_556215_value", "value"), "value");

				
				ReactSystemFunctions.setValueOf(this, "rolexotherproductreporting_986881_toString", ReactSystemFunctions.value(this, "rolexotherproductreporting_556215_value", "value"), "value");

				
				ReactSystemFunctions.setValueOf(this, "rolexotherproductreporting_226257_toString", ReactSystemFunctions.value(this, "rolexotherproductreporting_556215_value", "value"), "value");

				
				ReactSystemFunctions.setValueOf(this, "rolexotherproductreporting_35232_toString", ReactSystemFunctions.value(this, "rolexotherproductreporting_556215_value", "value"), "value");

				
				ReactSystemFunctions.setValueOf(this, "rolexotherproductreporting_706016_toString", ReactSystemFunctions.value(this, "rolexotherproductreporting_556215_value", "value"), "value");

				
				ReactSystemFunctions.setValueOf(this, "rolexotherproductreporting_997908_toString", ReactSystemFunctions.value(this, "rolexotherproductreporting_556215_value", "value"), "value");

				
				ReactSystemFunctions.setValueOf(this, "rolexotherproductreporting_48417_toString", ReactSystemFunctions.value(this, "rolexotherproductreporting_556215_value", "value"), "value");

				
				ReactSystemFunctions.setValueOf(this, "rolexotherproductreporting_576345_toString", ReactSystemFunctions.value(this, "rolexotherproductreporting_556215_value", "value"), "value");


		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

            
            return isErrorOccurred;
        }


		RolexOtherProductReportingComponent_131933_onChange = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations, this.checkTabErrors))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
KuikaAppManager.showSpinner(this);

				
				ReactSystemFunctions.setValueOf(this, "rolexotherproductreporting_319217_toString", ReactSystemFunctions.value(this, "rolexotherproductreporting_131933_value", "value"), "value");

				
				ReactSystemFunctions.setValueOf(this, "rolexotherproductreporting_732051_toString", ReactSystemFunctions.value(this, "rolexotherproductreporting_131933_value", "value"), "value");

				
				ReactSystemFunctions.setValueOf(this, "rolexotherproductreporting_657487_toString", ReactSystemFunctions.value(this, "rolexotherproductreporting_131933_value", "value"), "value");

				
				ReactSystemFunctions.setValueOf(this, "rolexotherproductreporting_102910_toString", ReactSystemFunctions.value(this, "rolexotherproductreporting_131933_value", "value"), "value");

				
				ReactSystemFunctions.setValueOf(this, "rolexotherproductreporting_2268_toString", ReactSystemFunctions.value(this, "rolexotherproductreporting_131933_value", "value"), "value");

				
				ReactSystemFunctions.setValueOf(this, "rolexotherproductreporting_891406_toString", ReactSystemFunctions.value(this, "rolexotherproductreporting_131933_value", "value"), "value");

				
				ReactSystemFunctions.setValueOf(this, "rolexotherproductreporting_796164_toString", ReactSystemFunctions.value(this, "rolexotherproductreporting_131933_value", "value"), "value");

				
				ReactSystemFunctions.setValueOf(this, "rolexotherproductreporting_510100_toString", ReactSystemFunctions.value(this, "rolexotherproductreporting_131933_value", "value"), "value");

				
				ReactSystemFunctions.setValueOf(this, "rolexotherproductreporting_131058_toString", ReactSystemFunctions.value(this, "rolexotherproductreporting_131933_value", "value"), "value");

				
				ReactSystemFunctions.setValueOf(this, "rolexotherproductreporting_101809_toString", ReactSystemFunctions.value(this, "rolexotherproductreporting_131933_value", "value"), "value");

				
				ReactSystemFunctions.setValueOf(this, "rolexotherproductreporting_339984_toString", ReactSystemFunctions.value(this, "rolexotherproductreporting_131933_value", "value"), "value");

				
				ReactSystemFunctions.setValueOf(this, "rolexotherproductreporting_849312_toString", ReactSystemFunctions.value(this, "rolexotherproductreporting_131933_value", "value"), "value");


		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

            
            return isErrorOccurred;
        }


		RolexOtherProductReportingComponent_501380_onChange = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations, this.checkTabErrors))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
KuikaAppManager.showSpinner(this);

				
				ReactSystemFunctions.setValueOf(this, "rolexotherproductreporting_584110_toString", ReactSystemFunctions.value(this, "rolexotherproductreporting_501380_value", "value"), "value");

				
				ReactSystemFunctions.setValueOf(this, "rolexotherproductreporting_838511_toString", ReactSystemFunctions.value(this, "rolexotherproductreporting_501380_value", "value"), "value");

				
				ReactSystemFunctions.setValueOf(this, "rolexotherproductreporting_909095_toString", ReactSystemFunctions.value(this, "rolexotherproductreporting_501380_value", "value"), "value");

				
				ReactSystemFunctions.setValueOf(this, "rolexotherproductreporting_959105_toString", ReactSystemFunctions.value(this, "rolexotherproductreporting_501380_value", "value"), "value");

				
				ReactSystemFunctions.setValueOf(this, "rolexotherproductreporting_545441_toString", ReactSystemFunctions.value(this, "rolexotherproductreporting_501380_value", "value"), "value");

				
				ReactSystemFunctions.setValueOf(this, "rolexotherproductreporting_129833_toString", ReactSystemFunctions.value(this, "rolexotherproductreporting_501380_value", "value"), "value");

				
				ReactSystemFunctions.setValueOf(this, "rolexotherproductreporting_247686_toString", ReactSystemFunctions.value(this, "rolexotherproductreporting_501380_value", "value"), "value");

				
				ReactSystemFunctions.setValueOf(this, "rolexotherproductreporting_402618_toString", ReactSystemFunctions.value(this, "rolexotherproductreporting_501380_value", "value"), "value");

				
				ReactSystemFunctions.setValueOf(this, "rolexotherproductreporting_72195_toString", ReactSystemFunctions.value(this, "rolexotherproductreporting_501380_value", "value"), "value");

				
				ReactSystemFunctions.setValueOf(this, "rolexotherproductreporting_959183_toString", ReactSystemFunctions.value(this, "rolexotherproductreporting_501380_value", "value"), "value");

				
				ReactSystemFunctions.setValueOf(this, "rolexotherproductreporting_913360_toString", ReactSystemFunctions.value(this, "rolexotherproductreporting_501380_value", "value"), "value");

				
				ReactSystemFunctions.setValueOf(this, "rolexotherproductreporting_717019_toString", ReactSystemFunctions.value(this, "rolexotherproductreporting_501380_value", "value"), "value");


		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

            
            return isErrorOccurred;
        }


		RolexOtherProductReportingComponent_96734_onChange = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations, this.checkTabErrors))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
KuikaAppManager.showSpinner(this);

				
				ReactSystemFunctions.setValueOf(this, "rolexotherproductreporting_184777_toString", ReactSystemFunctions.value(this, "rolexotherproductreporting_96734_value", "value"), "value");

				
				ReactSystemFunctions.setValueOf(this, "rolexotherproductreporting_2385_toString", ReactSystemFunctions.value(this, "rolexotherproductreporting_96734_value", "value"), "value");

				
				ReactSystemFunctions.setValueOf(this, "rolexotherproductreporting_94973_toString", ReactSystemFunctions.value(this, "rolexotherproductreporting_96734_value", "value"), "value");

				
				ReactSystemFunctions.setValueOf(this, "rolexotherproductreporting_810497_toString", ReactSystemFunctions.value(this, "rolexotherproductreporting_96734_value", "value"), "value");

				
				ReactSystemFunctions.setValueOf(this, "rolexotherproductreporting_252409_toString", ReactSystemFunctions.value(this, "rolexotherproductreporting_96734_value", "value"), "value");

				
				ReactSystemFunctions.setValueOf(this, "rolexotherproductreporting_80855_toString", ReactSystemFunctions.value(this, "rolexotherproductreporting_96734_value", "value"), "value");

				
				ReactSystemFunctions.setValueOf(this, "rolexotherproductreporting_869277_toString", ReactSystemFunctions.value(this, "rolexotherproductreporting_96734_value", "value"), "value");

				
				ReactSystemFunctions.setValueOf(this, "rolexotherproductreporting_703507_toString", ReactSystemFunctions.value(this, "rolexotherproductreporting_96734_value", "value"), "value");

				
				ReactSystemFunctions.setValueOf(this, "rolexotherproductreporting_136210_toString", ReactSystemFunctions.value(this, "rolexotherproductreporting_96734_value", "value"), "value");

				
				ReactSystemFunctions.setValueOf(this, "rolexotherproductreporting_657551_toString", ReactSystemFunctions.value(this, "rolexotherproductreporting_96734_value", "value"), "value");

				
				ReactSystemFunctions.setValueOf(this, "rolexotherproductreporting_429389_toString", ReactSystemFunctions.value(this, "rolexotherproductreporting_96734_value", "value"), "value");

				
				ReactSystemFunctions.setValueOf(this, "rolexotherproductreporting_221691_toString", ReactSystemFunctions.value(this, "rolexotherproductreporting_96734_value", "value"), "value");


		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

            
            return isErrorOccurred;
        }




    async callCallbackFunction(diId: number, isFromMaster: boolean = false) {
        let isErrorOccurred = false;
		let pageInitCallerNavDiIDs = [, , , , , , , ] as number[];
		if (isFromMaster || pageInitCallerNavDiIDs.indexOf(diId) > -1) {
			await this.RolexOtherProductReportingPageInit();
		}

    }


}
