import React from "react";
import Axios, { AxiosResponse } from "axios";
import { KuikaAppManager } from "../../shared/utilty/kuika-app-manager";
import { ReactSystemFunctions } from "../../shared/utilty/react-system-functions";
import { KNavigator } from "../../shared/hoc/with-history";
import { KContext } from "../../shared/hoc/with-context";
import { useLocation } from "react-router-dom";
import { FormInstance } from "antd/es/form";
import { Guid } from "guid-typescript";
import Swal from "sweetalert2";
import { KMainFunctions } from "../../shared/utilty/main-functions";
import moment from "moment";
import { IValidationData } from "../../models/dto/validation-data";
import { IStripePayment } from "../../models/dto/stripe-payment";
import { IUserInfoDto } from "../../models/dto/user-info.dto";
import { UserService } from "../../services/user-service";
import { kuikaCoreWasmBridgeService } from "../../services/_singletons";
import _ from "lodash";
import mqtt, { MqttClient } from "mqtt";
import { IMqttResult } from "../../models/dto/mqtt.dto";


declare let window: any;

export interface IReferanceCreateNew_ScreenProps {
  navigator: KNavigator;
  form: FormInstance<any>;
  googleLogin: any;
  screenInputs: any;
  context: KContext;
  initialValues: any;
  children: any;
}

export interface IReferanceCreateNew_ScreenState {
    isSpinnerVisible: boolean;
    isPageVisible: boolean;
	isLeftMenuVisible: boolean;
    spinnerCount: number;
    selectedLanguage: string;
    isPageInitLoaded: false;
    isPageRecurringLoaded: false;
	Kuika_CurrAccAttribute: any[];
	Kuika_CurrAccAttribute_dummy: any[];
	TM_GetCountry: any[];
	TM_GetCountry_dummy: any[];
	GoBack: any;
	GoBack_dummy: any;
	TM_GetCitySql: any[];
	TM_GetCitySql_dummy: any[];
	TM_GetDistrict: any[];
	TM_GetDistrict_dummy: any[];
	TMReferanceCreateNew: any[];
	TMReferanceCreateNew_dummy: any[];
	Notify: boolean;
	Notify_dummy: boolean;

}

export class ReferanceCreateNew_ScreenBase extends React.PureComponent<IReferanceCreateNew_ScreenProps, any> {

	referancecreatenew_586416_value_kuikaAutoCompleteRef: React.RefObject<any>;
	referancecreatenew_941270_value_kuikaAutoCompleteRef: React.RefObject<any>;
	referancecreatenew_846303_value_kuikaAutoCompleteRef: React.RefObject<any>;
	referancecreatenew_469746_value_kuikaAutoCompleteRef: React.RefObject<any>;
	referancecreatenew_811888_value_kuikaAutoCompleteRef: React.RefObject<any>;
	referancecreatenew_174356_value_kuikaDateRef: React.RefObject<any>;
	referancecreatenew_585027_value_kuikaAutoCompleteRef: React.RefObject<any>;
	referancecreatenew_560950_value_kuikaDateRef: React.RefObject<any>;
    ml=[{"Id":"d5a61d2b-bd60-485f-86e2-661e9ed4e486","Name":"en_US","ShortName":"English","IsDefault":true,"LanguagePhrases":[]},{"Id":"98ba0769-84ce-4fa8-8eb4-5644823fafad","Name":"FixedValues","ShortName":"FixedValues","LanguagePhrases":[{"Id":432253,"PropertyName":"value","Value":"Yeni Referans Oluştur"},{"Id":586924,"PropertyName":"value","Value":"Genel Bilgiler"},{"Id":307657,"PropertyName":"value","Value":"Ad*"},{"Id":627602,"PropertyName":"placeholder","Value":"Ad"},{"Id":952551,"PropertyName":"value","Value":"Soyad*"},{"Id":44548,"PropertyName":"placeholder","Value":"Soyad"},{"Id":29863,"PropertyName":"value","Value":"Telefon Numarası*"},{"Id":53933,"PropertyName":"placeholder","Value":"0(xxx) xxx xx xx"},{"Id":789292,"PropertyName":"value","Value":"Email"},{"Id":196298,"PropertyName":"placeholder","Value":"name@domainname.com"},{"Id":696940,"PropertyName":"value","Value":"Müşteri Tipi"},{"Id":586416,"PropertyName":"placeholder","Value":"Müşteri Tipi"},{"Id":755533,"PropertyName":"value","Value":"İnfo"},{"Id":402247,"PropertyName":"placeholder","Value":"İnfo"},{"Id":455250,"PropertyName":"value","Value":"Adres Bilgileri"},{"Id":719200,"PropertyName":"value","Value":"Ülke"},{"Id":941270,"PropertyName":"placeholder","Value":"Ülke"},{"Id":521978,"PropertyName":"value","Value":"İl"},{"Id":846303,"PropertyName":"placeholder","Value":"İl"},{"Id":435698,"PropertyName":"value","Value":"İlçe"},{"Id":469746,"PropertyName":"placeholder","Value":"İlçe"},{"Id":836456,"PropertyName":"value","Value":"Adres"},{"Id":697352,"PropertyName":"placeholder","Value":"Adres"},{"Id":812192,"PropertyName":"value","Value":"Kişisel Bilgiler"},{"Id":47456,"PropertyName":"value","Value":"TC Kimlik Numarası"},{"Id":107316,"PropertyName":"placeholder","Value":"TC Kimlik Numarası"},{"Id":911272,"PropertyName":"value","Value":"Vergi Numarası"},{"Id":442968,"PropertyName":"placeholder","Value":"Vergi Numarası"},{"Id":530644,"PropertyName":"value","Value":"Cinsiyet"},{"Id":811888,"PropertyName":"placeholder","Value":"Cinsiyet"},{"Id":138597,"PropertyName":"value","Value":"Doğum Tarihi"},{"Id":174356,"PropertyName":"placeholder","Value":"Doğum Tarihi"},{"Id":480794,"PropertyName":"value","Value":"Pasaport Ülkesi"},{"Id":585027,"PropertyName":"placeholder","Value":"Pasaport Ülkesi"},{"Id":992182,"PropertyName":"value","Value":"Pasaport No"},{"Id":391058,"PropertyName":"placeholder","Value":"Pasaport Numarası"},{"Id":500037,"PropertyName":"value","Value":"Pasaport Veriliş Tarihi"},{"Id":560950,"PropertyName":"placeholder","Value":"Pasaport Veriliş Tarihi"},{"Id":163827,"PropertyName":"label","Value":"Vazgeç"},{"Id":42731,"PropertyName":"label","Value":"Oluştur"}]}]
    defaultML = "en_US"
    
    screenHash = ""
    


    constructor(props) {
        super(props);
		this.referancecreatenew_627602_value_kuikaTextInputRef = React.createRef();
		this.referancecreatenew_44548_value_kuikaTextInputRef = React.createRef();
		this.referancecreatenew_53933_value_kuikaTextInputRef = React.createRef();
		this.referancecreatenew_586416_value_kuikaAutoCompleteRef = React.createRef();
		this.referancecreatenew_941270_value_kuikaAutoCompleteRef = React.createRef();
		this.referancecreatenew_846303_value_kuikaAutoCompleteRef = React.createRef();
		this.referancecreatenew_469746_value_kuikaAutoCompleteRef = React.createRef();
		this.referancecreatenew_107316_value_kuikaTextInputRef = React.createRef();
		this.referancecreatenew_442968_value_kuikaTextInputRef = React.createRef();
		this.referancecreatenew_811888_value_kuikaAutoCompleteRef = React.createRef();
		this.referancecreatenew_174356_value_kuikaDateRef = React.createRef();
		this.referancecreatenew_585027_value_kuikaAutoCompleteRef = React.createRef();
		this.referancecreatenew_391058_value_kuikaTextInputRef = React.createRef();
		this.referancecreatenew_560950_value_kuikaDateRef = React.createRef();

        this.state = {
            isSpinnerVisible: false,
            isPageVisible: false,
            isLeftMenuVisible: false,
            spinnerCount: 0,
            selectedLanguage: "",
            isPageInitLoaded: false,
            isPageRecurringLoaded: false,
            	        Kuika_CurrAccAttribute: [],
	        TM_GetCountry: [],
	        GoBack: "",
	        TM_GetCitySql: [],
	        TM_GetDistrict: [],
	        TMReferanceCreateNew: [],
	        Notify: false,
	        dataSource_811888: [{"key":"1","text":"Erkek"},{"key":"2","text":"Kadın"}],

        }

        this.CheckPageAuthorization(this.state);

        
    }

    async componentDidMount() {

        if (KuikaAppManager.isPageInitPrevented()) {
            KuikaAppManager.calculateAndSetBodyHeight("referancecreatenew", "");
            return;
        }
        
        
        ReactSystemFunctions.validateToken()
        this.fillFormInitValues();
        if (true){
            await this.ReferanceCreateNewPageInit();
        }
        
        
        
        KuikaAppManager.calculateAndSetBodyHeight("referancecreatenew", "");

        if (ReactSystemFunctions.getIsMicroApp() === false) {
           window.parentScreen = this;
        }
    }

    componentWillUnmount() {
        
        
        

        if (ReactSystemFunctions.getIsMicroApp() === false) {
           window.parentScreen = null;
        }
    }

    
              CheckPageAuthorization = async (state) => {
                KuikaAppManager.showSpinner(this);
                if (_.isEmpty(window.userInfo)) {
                  await UserService.GetUserInfoForce();
                }
                const permittedRoleNames: string[] = ["TimesYonetici","TimesUstYonetici","TimesSatisPersoneli","TimesMagazaMuduru","TimesAdmin",];
                const userInfo = window.userInfo as IUserInfoDto;
                const userRoleNames = userInfo.roles.map((role) => role.name);
                if (!ReactSystemFunctions.hasAnyRoleName(permittedRoleNames, userRoleNames)) {
                  await ReactSystemFunctions.goBack(this);

                  const language = localStorage.getItem("ml");
                  let permissonErrorMessageText = "You do not have permission to access this page.";
                  if (language === "tr_TR") {
                    permissonErrorMessageText = "Bu sayfaya erişim yetkiniz yok.";
                  } else if (language === "fr_FR") {
                    permissonErrorMessageText = "Vous n'avez pas la permission d'accéder à cette page.";
                  } else if (language === "de_DE") {
                    permissonErrorMessageText = "Sie haben keine Berechtigung, auf diese Seite zuzugreifen.";
                  } else if (language === "es_ES") {
                    permissonErrorMessageText = "No tienes permiso para acceder a esta página.";
                  }

                  KMainFunctions.displayErrorNotification(permissonErrorMessageText);
                  state.isPageVisible = false;
                  KuikaAppManager.hideSpinner(this);
                  return;
                }
                state.isPageVisible = true;
                KuikaAppManager.hideSpinner(this);
              };
        

        
    componentDidUpdate= async (prevProps, prevState) => {
		KuikaAppManager.calculateAndSetBodyHeight("referancecreatenew", ""    );
        if (prevProps?.location?.search !== (this.props as any)?.location?.search) {
			await this.ReferanceCreateNewPageInit();
		}

        

        if (ReactSystemFunctions.getIsMicroApp() === false) {
            for (const key in prevState) {
                if (key.startsWith('NavVisible') && prevState[key] === true && this.state[key] === false) {
                    window.parentScreen = this;
                    break;
                }
            }
        }
	}

    fillFormInitValues() {
        this.props.form?.setFieldsValue({
});

    }

      setPageInitLoaded = (value: boolean) => {
        this.setState({ isPageInitLoaded: value });
      }

      setPageRecurringLoaded = (value: boolean) => {
        this.setState({ isPageRecurringLoaded: value });
      }

      clearFieldValidation = (changedValues: any) => {
        const fieldName = Object.keys(changedValues)[0];
        if (fieldName) {
          this.props.form?.setFields([
            {
              name: fieldName,
              errors: []
            }
          ]);
        }
      };

      

    ReferanceCreateNewPageInit = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


	if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }

        let localVar = {
        }

	KuikaAppManager.showSpinner(this);
	
        if (true) {
        KuikaAppManager.showSpinner(this);
        }
        let result = await KuikaAppManager.ApiRequest(this, "ReferanceCreateNew/ReferanceCreateNewPageInit", localVar)
        if (!KMainFunctions.IsResStatus2XX(result)) return true;

		stateVars.Kuika_CurrAccAttribute = result?.data.kuika_CurrAccAttribute;
		
		formVars.referancecreatenew_586416_options = stateVars.Kuika_CurrAccAttribute;
		stateVars.TM_GetCountry = result?.data.tM_GetCountry;
		
		formVars.referancecreatenew_941270_options = stateVars.TM_GetCountry;
		
		formVars.referancecreatenew_585027_options = stateVars.TM_GetCountry;
		this.props.form?.setFieldsValue(formVars);
		
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.ReferanceCreateNewPageInit1_();
                  resolve();
                });
          })



        
        KuikaAppManager.hideSpinner(this);
        return isErrorOccurred;
    }
	ReferanceCreateNewPageInit1_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


	if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }

			
			stateVars.dataSource_586416 = stateVars.Kuika_CurrAccAttribute ?? this.state.Kuika_CurrAccAttribute;
			stateVars.dataSource_586416 = stateVars.Kuika_CurrAccAttribute ?? this.state.Kuika_CurrAccAttribute;
			
			stateVars.dataSource_941270 = stateVars.TM_GetCountry ?? this.state.TM_GetCountry;
			stateVars.dataSource_941270 = stateVars.TM_GetCountry ?? this.state.TM_GetCountry;
			
			stateVars.dataSource_585027 = stateVars.TM_GetCountry ?? this.state.TM_GetCountry;
			stateVars.dataSource_585027 = stateVars.TM_GetCountry ?? this.state.TM_GetCountry;

	this.props.form?.setFieldsValue(formVars);
	this.setState(stateVars);
	KuikaAppManager.hideSpinner(this);

            this.setPageInitLoaded(true);
            return isErrorOccurred;
        }




		ReferanceCreateNewComponent_158561_onClick = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
KuikaAppManager.showSpinner(this);

				stateVars.GoBack = await ReactSystemFunctions.goBack(this, false);

		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

            
            return isErrorOccurred;
        }


    ReferanceCreateNewComponent_941270_onChange = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
		KuikaAppManager.increaseServerRequestCount();

        let localVar = {
				CountryCode_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "referancecreatenew_941270_value", "value", "TM_GetCountry", "countryCode", "countryCode")), "string")
        }

		KuikaAppManager.showSpinner(this);
		
        if (true) {
        KuikaAppManager.showSpinner(this);
        }
        let result = await KuikaAppManager.ApiRequest(this, "ReferanceCreateNew/ReferanceCreateNewComponent_941270_onChange", localVar)
        if (!KMainFunctions.IsResStatus2XX(result)) return true;

			stateVars.TM_GetCitySql = result?.data.tM_GetCitySql;
			
			formVars.referancecreatenew_846303_options = stateVars.TM_GetCitySql;
			this.props.form?.setFieldsValue(formVars);
			
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.ReferanceCreateNewComponent_941270_onChange1_();
                  resolve();
                });
          })



        
        KuikaAppManager.hideSpinner(this);
        return isErrorOccurred;
    }
		ReferanceCreateNewComponent_941270_onChange1_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }

				
				stateVars.dataSource_846303 = stateVars.TM_GetCitySql ?? this.state.TM_GetCitySql;
				stateVars.dataSource_846303 = stateVars.TM_GetCitySql ?? this.state.TM_GetCitySql;

		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

            
            return isErrorOccurred;
        }




    ReferanceCreateNewComponent_846303_onChange = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
		KuikaAppManager.increaseServerRequestCount();

        let localVar = {
				CityCode_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "referancecreatenew_846303_value", "value", "TM_GetCitySql", "cityCode", "cityCode")), "string")
        }

		KuikaAppManager.showSpinner(this);
		
        if (true) {
        KuikaAppManager.showSpinner(this);
        }
        let result = await KuikaAppManager.ApiRequest(this, "ReferanceCreateNew/ReferanceCreateNewComponent_846303_onChange", localVar)
        if (!KMainFunctions.IsResStatus2XX(result)) return true;

			stateVars.TM_GetDistrict = result?.data.tM_GetDistrict;
			
			formVars.referancecreatenew_469746_options = stateVars.TM_GetDistrict;
			this.props.form?.setFieldsValue(formVars);
			
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.ReferanceCreateNewComponent_846303_onChange1_();
                  resolve();
                });
          })



        
        KuikaAppManager.hideSpinner(this);
        return isErrorOccurred;
    }
		ReferanceCreateNewComponent_846303_onChange1_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }

				
				stateVars.dataSource_469746 = stateVars.TM_GetDistrict ?? this.state.TM_GetDistrict;
				stateVars.dataSource_469746 = stateVars.TM_GetDistrict ?? this.state.TM_GetDistrict;

		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

            
            return isErrorOccurred;
        }




		ReferanceCreateNewComponent_163827_onClick = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
KuikaAppManager.showSpinner(this);

				stateVars.GoBack = await ReactSystemFunctions.goBack(this, false);

		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

            
            return isErrorOccurred;
        }


    ReferanceCreateNewComponent_42731_onClick = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;

			validations.push({ 
				isValid: ReactSystemFunctions.isNotEmpty(ReactSystemFunctions.value(this, "referancecreatenew_627602_value", "value", "", "", ""), null),
				message: "Bu alan boş bırakılamaz !",
				formName: "referancecreatenew_627602_value",
				condition: true
			} as IValidationData);

validations.forEach((validation) => {
            if (validation.message === "Geçerli bir mail adresi giriniz.") {
                validation.message = ReactSystemFunctions.getEmailValidationMessage()
            }
        })
			validations.push({ 
				isValid: ReactSystemFunctions.isNotEmpty(ReactSystemFunctions.value(this, "referancecreatenew_44548_value", "value", "", "", ""), null),
				message: "Bu alan boş bırakılamaz !",
				formName: "referancecreatenew_44548_value",
				condition: true
			} as IValidationData);

validations.forEach((validation) => {
            if (validation.message === "Geçerli bir mail adresi giriniz.") {
                validation.message = ReactSystemFunctions.getEmailValidationMessage()
            }
        })
			validations.push({ 
				isValid: ReactSystemFunctions.isValidEmail(ReactSystemFunctions.value(this, "referancecreatenew_196298_value", "value", "", "", ""), null),
				message: "Geçerli bir mail adresi giriniz.",
				formName: "referancecreatenew_196298_value",
				condition: true
			} as IValidationData);

validations.forEach((validation) => {
            if (validation.message === "Geçerli bir mail adresi giriniz.") {
                validation.message = ReactSystemFunctions.getEmailValidationMessage()
            }
        })

		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
		KuikaAppManager.increaseServerRequestCount();

        let localVar = {
				Name_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "referancecreatenew_627602_value", "value", "", "", "")), "string"),
				LastName_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "referancecreatenew_44548_value", "value", "", "", "")), "string"),
				Tel_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "referancecreatenew_53933_value", "value", "", "", "")), "string"),
				Address_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "referancecreatenew_697352_value", "value", "", "", "")), "string"),
				BirthDate_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "referancecreatenew_174356_value", "value", "", "", "")), "Date"),
				CityCode_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "referancecreatenew_846303_value", "value", "TM_GetCitySql", "cityCode", "cityCode")), "string"),
				CityName_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "referancecreatenew_846303_value", "value", "TM_GetCitySql", "cityCode", "cityName")), "string"),
				CountryCode_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "referancecreatenew_941270_value", "value", "TM_GetCountry", "countryCode", "countryCode")), "string"),
				CountryName_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "referancecreatenew_941270_value", "value", "TM_GetCountry", "countryCode", "countryName")), "string"),
				CustomerType_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "referancecreatenew_586416_value", "value", "Kuika_CurrAccAttribute", "customerAtt02", "customerAtt02Desc")), "string"),
				CustomerTypeCode_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "referancecreatenew_586416_value", "value", "Kuika_CurrAccAttribute", "customerAtt02", "customerAtt02")), "string"),
				DistrictCode_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "referancecreatenew_469746_value", "value", "TM_GetDistrict", "districtCode", "districtCode")), "string"),
				DistrictName_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "referancecreatenew_469746_value", "value", "TM_GetDistrict", "districtCode", "districtName")), "string"),
				Email_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "referancecreatenew_196298_value", "value", "", "", "")), "string"),
				GenderCode_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "referancecreatenew_811888_value", "value", "", "key", "")), "string"),
				Info_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "referancecreatenew_402247_value", "value", "", "", "")), "string"),
				IsEInvoice_0: ReactSystemFunctions.convertToTypeByName(false, "boolean"),
				IsShopping_0: ReactSystemFunctions.convertToTypeByName(false, "boolean"),
				NationalID_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "referancecreatenew_107316_value", "value", "", "", "")), "string"),
				PasaportCountryCode_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "referancecreatenew_585027_value", "value", "TM_GetCountry", "countryName", "countryCode")), "string"),
				PasaportCountryDescription_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "referancecreatenew_585027_value", "value", "TM_GetCountry", "countryName", "countryName")), "string"),
				PasaportNo_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "referancecreatenew_391058_value", "value", "", "", "")), "string"),
				PassaportIssueDate_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "referancecreatenew_560950_value", "value", "", "", "")), "string"),
				StateCode_0: ReactSystemFunctions.convertToTypeByName("", "string"),
				StateName_0: ReactSystemFunctions.convertToTypeByName("", "string"),
				TaxNumber_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "referancecreatenew_442968_value", "value", "", "", "")), "string")
        }

		KuikaAppManager.showSpinner(this);
		
        if (true) {
        KuikaAppManager.showSpinner(this);
        }
        let result = await KuikaAppManager.ApiRequest(this, "ReferanceCreateNew/ReferanceCreateNewComponent_42731_onClick", localVar)
        if (!KMainFunctions.IsResStatus2XX(result)) return true;

			stateVars.TMReferanceCreateNew = result?.data.tmReferanceCreateNew;
			this.props.form?.setFieldsValue(formVars);
			
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.ReferanceCreateNewComponent_42731_onClick1_();
                  resolve();
                });
          })



        
        KuikaAppManager.hideSpinner(this);
        return isErrorOccurred;
    }
		ReferanceCreateNewComponent_42731_onClick1_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }

				stateVars.Notify = await ReactSystemFunctions.notify(this, ReactSystemFunctions.toString(this, (stateVars.TMReferanceCreateNew !== undefined ? (stateVars.TMReferanceCreateNew?.length > 0 ? stateVars.TMReferanceCreateNew[0].message : null) : (this.state.TMReferanceCreateNew?.length > 0 ? this.state.TMReferanceCreateNew[0].message : null))), ReactSystemFunctions.convertToTypeByName("default", "string"), ReactSystemFunctions.convertToTypeByName("top-center", "string"), 2, ReactSystemFunctions.convertToTypeByName("", "string"), ReactSystemFunctions.convertToTypeByName("", "string"), 0);

		this.props.form?.setFieldsValue(formVars);
		
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.ReferanceCreateNewComponent_42731_onClick2_();
                  resolve();
                });
          })

            
            return isErrorOccurred;
        }
		ReferanceCreateNewComponent_42731_onClick2_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
if (ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, (stateVars.TMReferanceCreateNew !== undefined ? (stateVars.TMReferanceCreateNew?.length > 0 ? stateVars.TMReferanceCreateNew[0].success : null) : (this.state.TMReferanceCreateNew?.length > 0 ? this.state.TMReferanceCreateNew[0].success : null))), "1")) {
            
				stateVars.GoBack = await ReactSystemFunctions.goBack(this, false);

		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

        } else {
            KuikaAppManager.hideSpinner(this);
        }

            
            return isErrorOccurred;
        }







    async callCallbackFunction(diId: number, isFromMaster: boolean = false) {
        let isErrorOccurred = false;
		let pageInitCallerNavDiIDs = [] as number[];
		if (isFromMaster || pageInitCallerNavDiIDs.indexOf(diId) > -1) {
			await this.ReferanceCreateNewPageInit();
		}

    }


}
