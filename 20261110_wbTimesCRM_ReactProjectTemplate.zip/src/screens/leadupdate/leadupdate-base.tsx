import React from "react";
import Axios, { AxiosResponse } from "axios";
import { KuikaAppManager } from "../../shared/utilty/kuika-app-manager";
import { ReactSystemFunctions } from "../../shared/utilty/react-system-functions";
import { KNavigator } from "../../shared/hoc/with-history";
import { KContext } from "../../shared/hoc/with-context";
import { useLocation } from "react-router-dom";
import { FormInstance } from "antd/es/form";
import { Guid } from "guid-typescript";
import Swal from "sweetalert2";
import { KMainFunctions } from "../../shared/utilty/main-functions";
import moment from "moment";
import { IValidationData } from "../../models/dto/validation-data";
import { IStripePayment } from "../../models/dto/stripe-payment";
import { IUserInfoDto } from "../../models/dto/user-info.dto";
import { UserService } from "../../services/user-service";
import { kuikaCoreWasmBridgeService } from "../../services/_singletons";
import _ from "lodash";
import mqtt, { MqttClient } from "mqtt";
import { IMqttResult } from "../../models/dto/mqtt.dto";


declare let window: any;

export interface ILeadUpdate_ScreenProps {
  navigator: KNavigator;
  form: FormInstance<any>;
  googleLogin: any;
  screenInputs: any;
  context: KContext;
  initialValues: any;
  children: any;
}

export interface ILeadUpdate_ScreenState {
    isSpinnerVisible: boolean;
    isPageVisible: boolean;
	isLeftMenuVisible: boolean;
    spinnerCount: number;
    selectedLanguage: string;
    isPageInitLoaded: false;
    isPageRecurringLoaded: false;
	GoBack: any;
	GoBack_dummy: any;
	TM_UpdateLead: any[];
	TM_UpdateLead_dummy: any[];
	Notify: boolean;
	Notify_dummy: boolean;
	NAVIGATE: any;
	NAVIGATE_dummy: any;
	TM_UserRoleByUserId: any[];
	TM_UserRoleByUserId_dummy: any[];
	TM_GetLeadDetailUpdate: any[];
	TM_GetLeadDetailUpdate_dummy: any[];
	TM_StoreGetList: any[];
	TM_StoreGetList_dummy: any[];
	TS_GetStoreUsers: any[];
	TS_GetStoreUsers_dummy: any[];
	GetSalesPersonByStore: any[];
	GetSalesPersonByStore_dummy: any[];
	TM_GetCustomerByName: any[];
	TM_GetCustomerByName_dummy: any[];
	TM_GetLeadStatus: any[];
	TM_GetLeadStatus_dummy: any[];
	TM_GetLeadNextSteps: any[];
	TM_GetLeadNextSteps_dummy: any[];
	TM_GetAllContactSource: any[];
	TM_GetAllContactSource_dummy: any[];
	TM_GetCustomerById: any[];
	TM_GetCustomerById_dummy: any[];
	TM_GetReferanceByCurrAccCode: any[];
	TM_GetReferanceByCurrAccCode_dummy: any[];
	TM_ShowButton: any[];
	TM_ShowButton_dummy: any[];
	TM_GetProductBrandAlternatif: any[];
	TM_GetProductBrandAlternatif_dummy: any[];
	GetReferanceCustomerNew: any[];
	GetReferanceCustomerNew_dummy: any[];
	isComp703665Visible: 'visible' | 'hidden';
	isComp639898Visible: 'visible' | 'hidden';
	isComp910984Visible: 'visible' | 'hidden';
	isComp513936Visible: 'visible' | 'hidden';
	isComp366434Visible: 'visible' | 'hidden';
	isComp683308Visible: 'visible' | 'hidden';
	isComp315555Visible: 'visible' | 'hidden';
	isComp630051Visible: 'visible' | 'hidden';
	isComp875547Visible: 'visible' | 'hidden';
	isComp36755Visible: 'visible' | 'hidden';
	isComp561793Visible: 'visible' | 'hidden';
	isComp513812Visible: 'visible' | 'hidden';
	isComp398947Visible: 'visible' | 'hidden';
	isComp910731Enabled: 'enabled' | 'disabled';
	isComp999965Enabled: 'enabled' | 'disabled';
	isComp41512Enabled: 'enabled' | 'disabled';
	isComp964461Enabled: 'enabled' | 'disabled';

}

export class LeadUpdate_ScreenBase extends React.PureComponent<ILeadUpdate_ScreenProps, any> {

	leadupdate_8232_value_kuikaAutoCompleteRef: React.RefObject<any>;
	leadupdate_572982_value_kuikaAutoCompleteRef: React.RefObject<any>;
	leadupdate_999965_value_kuikaAutoCompleteRef: React.RefObject<any>;
	leadupdate_931332_value_kuikaAutoCompleteRef: React.RefObject<any>;
	leadupdate_964461_value_kuikaAutoCompleteRef: React.RefObject<any>;
	leadupdate_680481_value_kuikaAutoCompleteRef: React.RefObject<any>;
	leadupdate_748311_value_kuikaAutoCompleteRef: React.RefObject<any>;
	leadupdate_749612_value_kuikaSelectBoxRef: React.RefObject<any>;
	leadupdate_7574_value_kuikaSelectBoxRef: React.RefObject<any>;
    ml=[{"Id":"d5a61d2b-bd60-485f-86e2-661e9ed4e486","Name":"en_US","ShortName":"English","IsDefault":true,"LanguagePhrases":[]},{"Id":"b5c7528e-8cb3-497c-9f9b-1c76e59440ff","Name":"FixedValues","ShortName":"FixedValues","LanguagePhrases":[{"Id":357364,"PropertyName":"label","Value":"Vazgeç"},{"Id":795234,"PropertyName":"label","Value":"Güncelle"},{"Id":356299,"PropertyName":"value","Value":"Talep Düzenle"},{"Id":409623,"PropertyName":"value","Value":"Açtığınız talebi düzenleyiniz"},{"Id":842208,"PropertyName":"value","Value":"Ürün Talebi"},{"Id":117846,"PropertyName":"value","Value":"Açılan Mağaza"},{"Id":8232,"PropertyName":"placeholder","Value":"Açılan Mağazayı Seçiniz..."},{"Id":717797,"PropertyName":"value","Value":"Satış Personeli"},{"Id":572982,"PropertyName":"placeholder","Value":"Satış Personeli Seçiniz..."},{"Id":955907,"PropertyName":"value","Value":"Müşteri"},{"Id":999965,"PropertyName":"placeholder","Value":"Müşteri Seçiniz..."},{"Id":469991,"PropertyName":"value","Value":"Müşteri Bilgileri"},{"Id":128369,"PropertyName":"value","Value":"Müşteri Adı"},{"Id":374082,"PropertyName":"value","Value":"TC"},{"Id":742668,"PropertyName":"value","Value":"Telefon No"},{"Id":84281,"PropertyName":"value","Value":"E-mail"},{"Id":636915,"PropertyName":"value","Value":"Lokasyon"},{"Id":808974,"PropertyName":"value","Value":"Alışveriş Var Mı?"},{"Id":315555,"PropertyName":"value","Value":"Var"},{"Id":630051,"PropertyName":"value","Value":"Yok"},{"Id":841865,"PropertyName":"value","Value":"Referans Kişisi"},{"Id":931332,"PropertyName":"placeholder","Value":"Referans Seçiniz..."},{"Id":828382,"PropertyName":"value","Value":"Referans Bilgileri"},{"Id":952706,"PropertyName":"value","Value":"Referans Adı"},{"Id":768576,"PropertyName":"value","Value":"Referans Soyadı"},{"Id":569464,"PropertyName":"value","Value":"TC / Pasaport No"},{"Id":834243,"PropertyName":"value","Value":"Lead Durumu"},{"Id":964461,"PropertyName":"placeholder","Value":"Lead Durumu"},{"Id":989904,"PropertyName":"value","Value":"Sonraki Adım"},{"Id":680481,"PropertyName":"placeholder","Value":"Sonraki Adım"},{"Id":800892,"PropertyName":"value","Value":"İletişim Kaynağı"},{"Id":748311,"PropertyName":"placeholder","Value":"İletişim Kaynağı Seçiniz"},{"Id":807665,"PropertyName":"value","Value":"Talep Notu"},{"Id":10950,"PropertyName":"placeholder","Value":"Talep Notu"},{"Id":459929,"PropertyName":"value","Value":"Termin Tarihi Güncelle"},{"Id":749612,"PropertyName":"placeholder","Value":"Yıl"},{"Id":7574,"PropertyName":"placeholder","Value":"Ay"}]}]
    defaultML = "en_US"
    
    screenHash = ""
    


    constructor(props) {
        super(props);
		this.leadupdate_8232_value_kuikaAutoCompleteRef = React.createRef();
		this.leadupdate_572982_value_kuikaAutoCompleteRef = React.createRef();
		this.leadupdate_999965_value_kuikaAutoCompleteRef = React.createRef();
		this.leadupdate_931332_value_kuikaAutoCompleteRef = React.createRef();
		this.leadupdate_964461_value_kuikaAutoCompleteRef = React.createRef();
		this.leadupdate_680481_value_kuikaAutoCompleteRef = React.createRef();
		this.leadupdate_748311_value_kuikaAutoCompleteRef = React.createRef();
		this.leadupdate_749612_value_kuikaSelectBoxRef = React.createRef();
		this.leadupdate_7574_value_kuikaSelectBoxRef = React.createRef();

        this.state = {
            isSpinnerVisible: false,
            isPageVisible: false,
            isLeftMenuVisible: false,
            spinnerCount: 0,
            selectedLanguage: "",
            isPageInitLoaded: false,
            isPageRecurringLoaded: false,
            	        GoBack: "",
	        TM_UpdateLead: [],
	        Notify: false,
	        NAVIGATE: "",
	        TM_UserRoleByUserId: [],
	        TM_GetLeadDetailUpdate: [],
	        TM_StoreGetList: [],
	        TS_GetStoreUsers: [],
	        GetSalesPersonByStore: [],
	        TM_GetCustomerByName: [],
	        TM_GetLeadStatus: [],
	        TM_GetLeadNextSteps: [],
	        TM_GetAllContactSource: [],
	        TM_GetCustomerById: [],
	        TM_GetReferanceByCurrAccCode: [],
	        TM_ShowButton: [],
	        TM_GetProductBrandAlternatif: [],
	        GetReferanceCustomerNew: [],
	        dataSource_749612: [{"key":"2025","text":"2025"},{"key":"2026","text":"2026"},{"key":"2027","text":"2027"},{"key":"2028","text":"2028"},{"key":"2029","text":"2029"},{"key":"2030","text":"2030"},{"key":"2031","text":"2031"},{"key":"2032","text":"2032"},{"key":"2033","text":"2033"},{"key":"2034","text":"2034"},{"key":"2035","text":"2035"}],
	        dataSource_7574: [{"key":"1","text":"Ocak"},{"key":"2","text":"Şubat"},{"key":"3","text":"Mart"},{"key":"4","text":"Nisan"},{"key":"5","text":"Mayıs"},{"key":"6","text":"Haziran"},{"key":"7","text":"Temmuz"},{"key":"8","text":"Ağustos"},{"key":"9","text":"Eylül"},{"key":"10","text":"Ekim"},{"key":"11","text":"Kasım"},{"key":"12","text":"Aralık"}],
	        isComp703665Visible: 'hidden',
	        isComp639898Visible: 'hidden',
	        isComp910984Visible: 'hidden',
	        isComp513936Visible: 'hidden',
	        isComp366434Visible: 'hidden',
	        isComp683308Visible: 'hidden',
	        isComp315555Visible: 'hidden',
	        isComp630051Visible: 'hidden',
	        isComp875547Visible: 'hidden',
	        isComp36755Visible: 'hidden',
	        isComp561793Visible: 'hidden',
	        isComp513812Visible: 'hidden',
	        isComp398947Visible: 'hidden',
	        isComp910731Enabled: 'disabled',
	        isComp999965Enabled: 'disabled',
	        isComp41512Enabled: 'disabled',
	        isComp964461Enabled: 'disabled',

        }

        this.CheckPageAuthorization(this.state);

        
    }

    async componentDidMount() {

        if (KuikaAppManager.isPageInitPrevented()) {
            KuikaAppManager.calculateAndSetBodyHeight("leadupdate", "");
            return;
        }
        
        
        ReactSystemFunctions.validateToken()
        this.fillFormInitValues();
        if (true){
            await this.LeadUpdatePageInit();
        }
        
        
        
        KuikaAppManager.calculateAndSetBodyHeight("leadupdate", "");

        if (ReactSystemFunctions.getIsMicroApp() === false) {
           window.parentScreen = this;
        }
    }

    componentWillUnmount() {
        
        
        

        if (ReactSystemFunctions.getIsMicroApp() === false) {
           window.parentScreen = null;
        }
    }

    
              CheckPageAuthorization = async (state) => {
                KuikaAppManager.showSpinner(this);
                if (_.isEmpty(window.userInfo)) {
                  await UserService.GetUserInfoForce();
                }
                const permittedRoleNames: string[] = ["TimesYonetici","TimesUstYonetici","TimesSatisPersoneli","TimesMagazaMuduru",];
                const userInfo = window.userInfo as IUserInfoDto;
                const userRoleNames = userInfo.roles.map((role) => role.name);
                if (!ReactSystemFunctions.hasAnyRoleName(permittedRoleNames, userRoleNames)) {
                  await ReactSystemFunctions.goBack(this);

                  const language = localStorage.getItem("ml");
                  let permissonErrorMessageText = "You do not have permission to access this page.";
                  if (language === "tr_TR") {
                    permissonErrorMessageText = "Bu sayfaya erişim yetkiniz yok.";
                  } else if (language === "fr_FR") {
                    permissonErrorMessageText = "Vous n'avez pas la permission d'accéder à cette page.";
                  } else if (language === "de_DE") {
                    permissonErrorMessageText = "Sie haben keine Berechtigung, auf diese Seite zuzugreifen.";
                  } else if (language === "es_ES") {
                    permissonErrorMessageText = "No tienes permiso para acceder a esta página.";
                  }

                  KMainFunctions.displayErrorNotification(permissonErrorMessageText);
                  state.isPageVisible = false;
                  KuikaAppManager.hideSpinner(this);
                  return;
                }
                state.isPageVisible = true;
                KuikaAppManager.hideSpinner(this);
              };
        

        
    componentDidUpdate= async (prevProps, prevState) => {
		KuikaAppManager.calculateAndSetBodyHeight("leadupdate", ""    );
        if (prevProps?.location?.search !== (this.props as any)?.location?.search) {
			await this.LeadUpdatePageInit();
		}

        

        if (ReactSystemFunctions.getIsMicroApp() === false) {
            for (const key in prevState) {
                if (key.startsWith('NavVisible') && prevState[key] === true && this.state[key] === false) {
                    window.parentScreen = this;
                    break;
                }
            }
        }
	}

    fillFormInitValues() {
        this.props.form?.setFieldsValue({
leadupdate_8232_value: this.state.TM_GetLeadDetailUpdate?.at?.(0)?.storeId ?? undefined,
leadupdate_572982_value: this.state.TM_GetLeadDetailUpdate?.at?.(0)?.salesPersonKUserId ?? undefined,
leadupdate_999965_value: this.state.TM_GetLeadDetailUpdate?.at?.(0)?.customerId ?? undefined,
leadupdate_931332_value: this.state.TM_GetLeadDetailUpdate?.at?.(0)?.referencePersonID ?? undefined,
leadupdate_964461_value: this.state.TM_GetLeadDetailUpdate?.at?.(0)?.statuId ?? undefined,
leadupdate_680481_value: this.state.TM_GetLeadDetailUpdate?.at?.(0)?.nextStepId ?? undefined,
leadupdate_748311_value: this.state.TM_GetLeadDetailUpdate?.at?.(0)?.contactResourceId ?? undefined,
leadupdate_10950_value: this.state.TM_GetLeadDetailUpdate?.at?.(0)?.talepNotu ?? undefined,
leadupdate_749612_value: this.state.TM_GetLeadDetailUpdate?.at?.(0)?.estimatedYear ?? undefined,
leadupdate_7574_value: this.state.TM_GetLeadDetailUpdate?.at?.(0)?.estimatedMonth ?? undefined
});

    }

      setPageInitLoaded = (value: boolean) => {
        this.setState({ isPageInitLoaded: value });
      }

      setPageRecurringLoaded = (value: boolean) => {
        this.setState({ isPageRecurringLoaded: value });
      }

      clearFieldValidation = (changedValues: any) => {
        const fieldName = Object.keys(changedValues)[0];
        if (fieldName) {
          this.props.form?.setFields([
            {
              name: fieldName,
              errors: []
            }
          ]);
        }
      };

      

    LeadUpdatePageInit = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


	if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }

        let localVar = {
			UserID_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.getMyUserId(), "Guid"),
			LeadId_1: ReactSystemFunctions.convertToTypeByName(this.props.screenInputs.LeadId ?? this.props.screenInputs.leadid, "Guid"),
			KUserId_3: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, (stateVars.TM_GetLeadDetailUpdate !== undefined ? (stateVars.TM_GetLeadDetailUpdate?.length > 0 ? stateVars.TM_GetLeadDetailUpdate[0].salesPersonKUserId : null) : (this.state.TM_GetLeadDetailUpdate?.length > 0 ? this.state.TM_GetLeadDetailUpdate[0].salesPersonKUserId : null))), "Guid"),
			StoreId_4: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, (stateVars.TM_GetLeadDetailUpdate !== undefined ? (stateVars.TM_GetLeadDetailUpdate?.length > 0 ? stateVars.TM_GetLeadDetailUpdate[0].storeId : null) : (this.state.TM_GetLeadDetailUpdate?.length > 0 ? this.state.TM_GetLeadDetailUpdate[0].storeId : null))), "Guid"),
			CustomerId_9: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, (stateVars.TM_GetLeadDetailUpdate !== undefined ? (stateVars.TM_GetLeadDetailUpdate?.length > 0 ? stateVars.TM_GetLeadDetailUpdate[0].customerId : null) : (this.state.TM_GetLeadDetailUpdate?.length > 0 ? this.state.TM_GetLeadDetailUpdate[0].customerId : null))), "Guid"),
			CurrAccCode_10: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, (stateVars.TM_GetCustomerById !== undefined ? (stateVars.TM_GetCustomerById?.length > 0 ? stateVars.TM_GetCustomerById[0].currAccCode : null) : (this.state.TM_GetCustomerById?.length > 0 ? this.state.TM_GetCustomerById[0].currAccCode : null))), "string"),
			LeadId_11: ReactSystemFunctions.convertToTypeByName(this.props.screenInputs.LeadId ?? this.props.screenInputs.leadid, "Guid"),
			UserId_11: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.getMyUserId(), "Guid"),
			KUserId_12: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.getMyUserId(), "Guid")
        }

	KuikaAppManager.showSpinner(this);
	
        if (true) {
        KuikaAppManager.showSpinner(this);
        }
        let result = await KuikaAppManager.ApiRequest(this, "LeadUpdate/LeadUpdatePageInit", localVar)
        if (!KMainFunctions.IsResStatus2XX(result)) return true;

		stateVars.TM_UserRoleByUserId = result?.data.tM_UserRoleByUserId;
		stateVars.isComp964461Enabled = ((ReactSystemFunctions.doesNotContain(ReactSystemFunctions.toString(this, (stateVars.TM_UserRoleByUserId !== undefined ? (stateVars.TM_UserRoleByUserId?.length > 0 ? stateVars.TM_UserRoleByUserId[0].role : null) : (this.state.TM_UserRoleByUserId?.length > 0 ? this.state.TM_UserRoleByUserId[0].role : null))), ReactSystemFunctions.convertToTypeByName("TimesSatisPersoneli", "string"))) === true ? "enabled" : "disabled")
		stateVars.TM_GetLeadDetailUpdate = result?.data.tM_GetLeadDetailUpdate;
		formVars.leadupdate_8232_value = (stateVars.TM_GetLeadDetailUpdate !== undefined ? (stateVars.TM_GetLeadDetailUpdate?.length > 0 ? stateVars.TM_GetLeadDetailUpdate[0].storeId : null) : (this.state.TM_GetLeadDetailUpdate?.length > 0 ? this.state.TM_GetLeadDetailUpdate[0].storeId : null));
		formVars.leadupdate_8232_options = stateVars.TM_StoreGetList;
		formVars.leadupdate_572982_value = (stateVars.TM_GetLeadDetailUpdate !== undefined ? (stateVars.TM_GetLeadDetailUpdate?.length > 0 ? stateVars.TM_GetLeadDetailUpdate[0].salesPersonKUserId : null) : (this.state.TM_GetLeadDetailUpdate?.length > 0 ? this.state.TM_GetLeadDetailUpdate[0].salesPersonKUserId : null));
		formVars.leadupdate_572982_options = stateVars.GetSalesPersonByStore;
		formVars.leadupdate_999965_value = (stateVars.TM_GetLeadDetailUpdate !== undefined ? (stateVars.TM_GetLeadDetailUpdate?.length > 0 ? stateVars.TM_GetLeadDetailUpdate[0].customerId : null) : (this.state.TM_GetLeadDetailUpdate?.length > 0 ? this.state.TM_GetLeadDetailUpdate[0].customerId : null));
		formVars.leadupdate_999965_options = stateVars.TM_GetCustomerByName;
		formVars.leadupdate_931332_value = (stateVars.TM_GetLeadDetailUpdate !== undefined ? (stateVars.TM_GetLeadDetailUpdate?.length > 0 ? stateVars.TM_GetLeadDetailUpdate[0].referencePersonID : null) : (this.state.TM_GetLeadDetailUpdate?.length > 0 ? this.state.TM_GetLeadDetailUpdate[0].referencePersonID : null));
		formVars.leadupdate_931332_options = stateVars.GetReferanceCustomerNew;
		formVars.leadupdate_964461_value = (stateVars.TM_GetLeadDetailUpdate !== undefined ? (stateVars.TM_GetLeadDetailUpdate?.length > 0 ? stateVars.TM_GetLeadDetailUpdate[0].statuId : null) : (this.state.TM_GetLeadDetailUpdate?.length > 0 ? this.state.TM_GetLeadDetailUpdate[0].statuId : null));
		formVars.leadupdate_964461_options = stateVars.TM_GetLeadStatus;
		formVars.leadupdate_680481_value = (stateVars.TM_GetLeadDetailUpdate !== undefined ? (stateVars.TM_GetLeadDetailUpdate?.length > 0 ? stateVars.TM_GetLeadDetailUpdate[0].nextStepId : null) : (this.state.TM_GetLeadDetailUpdate?.length > 0 ? this.state.TM_GetLeadDetailUpdate[0].nextStepId : null));
		formVars.leadupdate_680481_options = stateVars.TM_GetLeadNextSteps;
		formVars.leadupdate_748311_value = (stateVars.TM_GetLeadDetailUpdate !== undefined ? (stateVars.TM_GetLeadDetailUpdate?.length > 0 ? stateVars.TM_GetLeadDetailUpdate[0].contactResourceId : null) : (this.state.TM_GetLeadDetailUpdate?.length > 0 ? this.state.TM_GetLeadDetailUpdate[0].contactResourceId : null));
		formVars.leadupdate_748311_options = stateVars.TM_GetAllContactSource;
		formVars.leadupdate_10950_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadDetailUpdate !== undefined ? (stateVars.TM_GetLeadDetailUpdate?.length > 0 ? stateVars.TM_GetLeadDetailUpdate[0].talepNotu : null) : (this.state.TM_GetLeadDetailUpdate?.length > 0 ? this.state.TM_GetLeadDetailUpdate[0].talepNotu : null)));
		formVars.leadupdate_749612_value = (stateVars.TM_GetLeadDetailUpdate !== undefined ? (stateVars.TM_GetLeadDetailUpdate?.length > 0 ? stateVars.TM_GetLeadDetailUpdate[0].estimatedYear : null) : (this.state.TM_GetLeadDetailUpdate?.length > 0 ? this.state.TM_GetLeadDetailUpdate[0].estimatedYear : null));
		formVars.leadupdate_7574_value = (stateVars.TM_GetLeadDetailUpdate !== undefined ? (stateVars.TM_GetLeadDetailUpdate?.length > 0 ? stateVars.TM_GetLeadDetailUpdate[0].estimatedMonth : null) : (this.state.TM_GetLeadDetailUpdate?.length > 0 ? this.state.TM_GetLeadDetailUpdate[0].estimatedMonth : null));
		stateVars.isComp398947Visible = (((ReactSystemFunctions.doesNotContain(ReactSystemFunctions.getMyRoleNames(), ReactSystemFunctions.convertToTypeByName("TimesSatisPersoneli", "string")) && ReactSystemFunctions.isNotEmpty(ReactSystemFunctions.value(this, (stateVars.TM_GetLeadDetailUpdate !== undefined ? (stateVars.TM_GetLeadDetailUpdate?.length > 0 ? stateVars.TM_GetLeadDetailUpdate[0].estimatedDate : null) : (this.state.TM_GetLeadDetailUpdate?.length > 0 ? this.state.TM_GetLeadDetailUpdate[0].estimatedDate : null))), ReactSystemFunctions.convertToTypeByName("True", "string")))) === true ? "visible" : "hidden")
		stateVars.TM_StoreGetList = result?.data.tM_StoreGetList;
		
		formVars.leadupdate_8232_value = (stateVars.TM_GetLeadDetailUpdate !== undefined ? (stateVars.TM_GetLeadDetailUpdate?.length > 0 ? stateVars.TM_GetLeadDetailUpdate[0].storeId : null) : (this.state.TM_GetLeadDetailUpdate?.length > 0 ? this.state.TM_GetLeadDetailUpdate[0].storeId : null));
		formVars.leadupdate_8232_options = stateVars.TM_StoreGetList;
		stateVars.TS_GetStoreUsers = result?.data.tS_GetStoreUsers;
		stateVars.GetSalesPersonByStore = result?.data.getSalesPersonByStore;
		
		formVars.leadupdate_572982_value = (stateVars.TM_GetLeadDetailUpdate !== undefined ? (stateVars.TM_GetLeadDetailUpdate?.length > 0 ? stateVars.TM_GetLeadDetailUpdate[0].salesPersonKUserId : null) : (this.state.TM_GetLeadDetailUpdate?.length > 0 ? this.state.TM_GetLeadDetailUpdate[0].salesPersonKUserId : null));
		formVars.leadupdate_572982_options = stateVars.GetSalesPersonByStore;
		stateVars.TM_GetCustomerByName = result?.data.tM_GetCustomerByName;
		
		formVars.leadupdate_999965_value = (stateVars.TM_GetLeadDetailUpdate !== undefined ? (stateVars.TM_GetLeadDetailUpdate?.length > 0 ? stateVars.TM_GetLeadDetailUpdate[0].customerId : null) : (this.state.TM_GetLeadDetailUpdate?.length > 0 ? this.state.TM_GetLeadDetailUpdate[0].customerId : null));
		formVars.leadupdate_999965_options = stateVars.TM_GetCustomerByName;
		stateVars.TM_GetLeadStatus = result?.data.tM_GetLeadStatus;
		
		formVars.leadupdate_964461_value = (stateVars.TM_GetLeadDetailUpdate !== undefined ? (stateVars.TM_GetLeadDetailUpdate?.length > 0 ? stateVars.TM_GetLeadDetailUpdate[0].statuId : null) : (this.state.TM_GetLeadDetailUpdate?.length > 0 ? this.state.TM_GetLeadDetailUpdate[0].statuId : null));
		formVars.leadupdate_964461_options = stateVars.TM_GetLeadStatus;
		stateVars.TM_GetLeadNextSteps = result?.data.tM_GetLeadNextSteps;
		
		formVars.leadupdate_680481_value = (stateVars.TM_GetLeadDetailUpdate !== undefined ? (stateVars.TM_GetLeadDetailUpdate?.length > 0 ? stateVars.TM_GetLeadDetailUpdate[0].nextStepId : null) : (this.state.TM_GetLeadDetailUpdate?.length > 0 ? this.state.TM_GetLeadDetailUpdate[0].nextStepId : null));
		formVars.leadupdate_680481_options = stateVars.TM_GetLeadNextSteps;
		stateVars.TM_GetAllContactSource = result?.data.tM_GetAllContactSource;
		
		formVars.leadupdate_748311_value = (stateVars.TM_GetLeadDetailUpdate !== undefined ? (stateVars.TM_GetLeadDetailUpdate?.length > 0 ? stateVars.TM_GetLeadDetailUpdate[0].contactResourceId : null) : (this.state.TM_GetLeadDetailUpdate?.length > 0 ? this.state.TM_GetLeadDetailUpdate[0].contactResourceId : null));
		formVars.leadupdate_748311_options = stateVars.TM_GetAllContactSource;
		stateVars.TM_GetCustomerById = result?.data.tM_GetCustomerById;
		formVars.leadupdate_410287_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetCustomerById !== undefined ? (stateVars.TM_GetCustomerById?.length > 0 ? stateVars.TM_GetCustomerById[0].adSoyad : null) : (this.state.TM_GetCustomerById?.length > 0 ? this.state.TM_GetCustomerById[0].adSoyad : null)));
		formVars.leadupdate_683308_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetCustomerById !== undefined ? (stateVars.TM_GetCustomerById?.length > 0 ? stateVars.TM_GetCustomerById[0].tcKimlikNo : null) : (this.state.TM_GetCustomerById?.length > 0 ? this.state.TM_GetCustomerById[0].tcKimlikNo : null)));
		formVars.leadupdate_381076_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetCustomerById !== undefined ? (stateVars.TM_GetCustomerById?.length > 0 ? stateVars.TM_GetCustomerById[0].telefonNo : null) : (this.state.TM_GetCustomerById?.length > 0 ? this.state.TM_GetCustomerById[0].telefonNo : null)));
		formVars.leadupdate_496941_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetCustomerById !== undefined ? (stateVars.TM_GetCustomerById?.length > 0 ? stateVars.TM_GetCustomerById[0].email : null) : (this.state.TM_GetCustomerById?.length > 0 ? this.state.TM_GetCustomerById[0].email : null)));
		formVars.leadupdate_826540_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetCustomerById !== undefined ? (stateVars.TM_GetCustomerById?.length > 0 ? stateVars.TM_GetCustomerById[0].sehir : null) : (this.state.TM_GetCustomerById?.length > 0 ? this.state.TM_GetCustomerById[0].sehir : null)));
		stateVars.isComp683308Visible = ((ReactSystemFunctions.isNotEmpty(ReactSystemFunctions.toString(this, (stateVars.TM_GetCustomerById !== undefined ? (stateVars.TM_GetCustomerById?.length > 0 ? stateVars.TM_GetCustomerById[0].tcKimlikNo : null) : (this.state.TM_GetCustomerById?.length > 0 ? this.state.TM_GetCustomerById[0].tcKimlikNo : null))), ReactSystemFunctions.convertToTypeByName("True", "string"))) === true ? "visible" : "hidden")
		stateVars.isComp315555Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, (stateVars.TM_GetCustomerById !== undefined ? (stateVars.TM_GetCustomerById?.length > 0 ? stateVars.TM_GetCustomerById[0].isShopping : null) : (this.state.TM_GetCustomerById?.length > 0 ? this.state.TM_GetCustomerById[0].isShopping : null))), ReactSystemFunctions.convertToTypeByName("True", "string"))) === true ? "visible" : "hidden")
		stateVars.isComp630051Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, (stateVars.TM_GetCustomerById !== undefined ? (stateVars.TM_GetCustomerById?.length > 0 ? stateVars.TM_GetCustomerById[0].isShopping : null) : (this.state.TM_GetCustomerById?.length > 0 ? this.state.TM_GetCustomerById[0].isShopping : null))), ReactSystemFunctions.convertToTypeByName("False", "string"))) === true ? "visible" : "hidden")
		stateVars.TM_GetReferanceByCurrAccCode = result?.data.tM_GetReferanceByCurrAccCode;
		formVars.leadupdate_667900_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetReferanceByCurrAccCode !== undefined ? (stateVars.TM_GetReferanceByCurrAccCode?.length > 0 ? stateVars.TM_GetReferanceByCurrAccCode[0].referenceName : null) : (this.state.TM_GetReferanceByCurrAccCode?.length > 0 ? this.state.TM_GetReferanceByCurrAccCode[0].referenceName : null)));
		formVars.leadupdate_729604_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetReferanceByCurrAccCode !== undefined ? (stateVars.TM_GetReferanceByCurrAccCode?.length > 0 ? stateVars.TM_GetReferanceByCurrAccCode[0].referenceLastName : null) : (this.state.TM_GetReferanceByCurrAccCode?.length > 0 ? this.state.TM_GetReferanceByCurrAccCode[0].referenceLastName : null)));
		formVars.leadupdate_513812_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetReferanceByCurrAccCode !== undefined ? (stateVars.TM_GetReferanceByCurrAccCode?.length > 0 ? stateVars.TM_GetReferanceByCurrAccCode[0].referenceNationalID : null) : (this.state.TM_GetReferanceByCurrAccCode?.length > 0 ? this.state.TM_GetReferanceByCurrAccCode[0].referenceNationalID : null)));
		stateVars.isComp513812Visible = ((ReactSystemFunctions.isNotEmpty(ReactSystemFunctions.toString(this, (stateVars.TM_GetReferanceByCurrAccCode !== undefined ? (stateVars.TM_GetReferanceByCurrAccCode?.length > 0 ? stateVars.TM_GetReferanceByCurrAccCode[0].referenceNationalID : null) : (this.state.TM_GetReferanceByCurrAccCode?.length > 0 ? this.state.TM_GetReferanceByCurrAccCode[0].referenceNationalID : null))), ReactSystemFunctions.convertToTypeByName("True", "string"))) === true ? "visible" : "hidden")
		stateVars.TM_ShowButton = result?.data.tM_ShowButton;
		stateVars.TM_GetProductBrandAlternatif = result?.data.tM_GetProductBrandAlternatif;
		stateVars.GetReferanceCustomerNew = result?.data.getReferanceCustomerNew;
		
		formVars.leadupdate_931332_value = (stateVars.TM_GetLeadDetailUpdate !== undefined ? (stateVars.TM_GetLeadDetailUpdate?.length > 0 ? stateVars.TM_GetLeadDetailUpdate[0].referencePersonID : null) : (this.state.TM_GetLeadDetailUpdate?.length > 0 ? this.state.TM_GetLeadDetailUpdate[0].referencePersonID : null));
		formVars.leadupdate_931332_options = stateVars.GetReferanceCustomerNew;
		this.props.form?.setFieldsValue(formVars);
		
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.LeadUpdatePageInit1_();
                  resolve();
                });
          })



        
        KuikaAppManager.hideSpinner(this);
        return isErrorOccurred;
    }
	LeadUpdatePageInit1_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


	if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }

			stateVars.isComp703665Visible = (((ReactSystemFunctions.contains(ReactSystemFunctions.getMyRoleNames(), ReactSystemFunctions.convertToTypeByName("TimesUstYonetici", "string")) || ReactSystemFunctions.contains(ReactSystemFunctions.getMyRoleNames(), ReactSystemFunctions.convertToTypeByName("TimesYonetici", "string")))) === true ? "visible" : "hidden")
			formVars.leadupdate_8232_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadDetailUpdate !== undefined ? (stateVars.TM_GetLeadDetailUpdate?.length > 0 ? stateVars.TM_GetLeadDetailUpdate[0].storeId : null) : (this.state.TM_GetLeadDetailUpdate?.length > 0 ? this.state.TM_GetLeadDetailUpdate[0].storeId : null)));

			
			stateVars.dataSource_8232 = stateVars.TM_StoreGetList ?? this.state.TM_StoreGetList;
			stateVars.dataSource_8232 = stateVars.TM_StoreGetList ?? this.state.TM_StoreGetList;
			stateVars.isComp639898Visible = (((ReactSystemFunctions.contains(ReactSystemFunctions.getMyRoleNames(), ReactSystemFunctions.convertToTypeByName("TimesMagazaMuduru", "string")) || ReactSystemFunctions.contains(ReactSystemFunctions.getMyRoleNames(), ReactSystemFunctions.convertToTypeByName("TimesUstYonetici", "string")))) === true ? "visible" : "hidden")
			formVars.leadupdate_572982_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadDetailUpdate !== undefined ? (stateVars.TM_GetLeadDetailUpdate?.length > 0 ? stateVars.TM_GetLeadDetailUpdate[0].salesPersonKUserId : null) : (this.state.TM_GetLeadDetailUpdate?.length > 0 ? this.state.TM_GetLeadDetailUpdate[0].salesPersonKUserId : null)));

			
			stateVars.dataSource_572982 = stateVars.GetSalesPersonByStore ?? this.state.GetSalesPersonByStore;
			stateVars.dataSource_572982 = stateVars.GetSalesPersonByStore ?? this.state.GetSalesPersonByStore;
			formVars.leadupdate_999965_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadDetailUpdate !== undefined ? (stateVars.TM_GetLeadDetailUpdate?.length > 0 ? stateVars.TM_GetLeadDetailUpdate[0].customerId : null) : (this.state.TM_GetLeadDetailUpdate?.length > 0 ? this.state.TM_GetLeadDetailUpdate[0].customerId : null)));

			
			stateVars.dataSource_999965 = stateVars.TM_GetCustomerByName ?? this.state.TM_GetCustomerByName;
			stateVars.dataSource_999965 = stateVars.TM_GetCustomerByName ?? this.state.TM_GetCustomerByName;
			stateVars.isComp910984Visible = ((ReactSystemFunctions.isNotEmpty(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "leadupdate_999965_value", "value", "TM_GetCustomerByName", "id", "id")), ReactSystemFunctions.convertToTypeByName("True", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp513936Visible = ((ReactSystemFunctions.isNotEmpty(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "leadupdate_8232_value", "value", "TM_StoreGetList", "id", "id")), ReactSystemFunctions.convertToTypeByName("True", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp366434Visible = ((ReactSystemFunctions.isNotEmpty(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "leadupdate_8232_value", "value", "TM_StoreGetList", "id", "id")), ReactSystemFunctions.convertToTypeByName("True", "string"))) === true ? "visible" : "hidden")
			formVars.leadupdate_410287_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetCustomerById !== undefined ? (stateVars.TM_GetCustomerById?.length > 0 ? stateVars.TM_GetCustomerById[0].adSoyad : null) : (this.state.TM_GetCustomerById?.length > 0 ? this.state.TM_GetCustomerById[0].adSoyad : null)));

			formVars.leadupdate_683308_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetCustomerById !== undefined ? (stateVars.TM_GetCustomerById?.length > 0 ? stateVars.TM_GetCustomerById[0].tcKimlikNo : null) : (this.state.TM_GetCustomerById?.length > 0 ? this.state.TM_GetCustomerById[0].tcKimlikNo : null)));

			stateVars.isComp683308Visible = ((ReactSystemFunctions.isNotEmpty(ReactSystemFunctions.toString(this, (stateVars.TM_GetCustomerById !== undefined ? (stateVars.TM_GetCustomerById?.length > 0 ? stateVars.TM_GetCustomerById[0].tcKimlikNo : null) : (this.state.TM_GetCustomerById?.length > 0 ? this.state.TM_GetCustomerById[0].tcKimlikNo : null))), ReactSystemFunctions.convertToTypeByName("True", "string"))) === true ? "visible" : "hidden")
			formVars.leadupdate_381076_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetCustomerById !== undefined ? (stateVars.TM_GetCustomerById?.length > 0 ? stateVars.TM_GetCustomerById[0].telefonNo : null) : (this.state.TM_GetCustomerById?.length > 0 ? this.state.TM_GetCustomerById[0].telefonNo : null)));

			formVars.leadupdate_496941_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetCustomerById !== undefined ? (stateVars.TM_GetCustomerById?.length > 0 ? stateVars.TM_GetCustomerById[0].email : null) : (this.state.TM_GetCustomerById?.length > 0 ? this.state.TM_GetCustomerById[0].email : null)));

			formVars.leadupdate_826540_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetCustomerById !== undefined ? (stateVars.TM_GetCustomerById?.length > 0 ? stateVars.TM_GetCustomerById[0].sehir : null) : (this.state.TM_GetCustomerById?.length > 0 ? this.state.TM_GetCustomerById[0].sehir : null)));

			stateVars.isComp315555Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, (stateVars.TM_GetCustomerById !== undefined ? (stateVars.TM_GetCustomerById?.length > 0 ? stateVars.TM_GetCustomerById[0].isShopping : null) : (this.state.TM_GetCustomerById?.length > 0 ? this.state.TM_GetCustomerById[0].isShopping : null))), ReactSystemFunctions.convertToTypeByName("True", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp630051Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, (stateVars.TM_GetCustomerById !== undefined ? (stateVars.TM_GetCustomerById?.length > 0 ? stateVars.TM_GetCustomerById[0].isShopping : null) : (this.state.TM_GetCustomerById?.length > 0 ? this.state.TM_GetCustomerById[0].isShopping : null))), ReactSystemFunctions.convertToTypeByName("False", "string"))) === true ? "visible" : "hidden")
			formVars.leadupdate_931332_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadDetailUpdate !== undefined ? (stateVars.TM_GetLeadDetailUpdate?.length > 0 ? stateVars.TM_GetLeadDetailUpdate[0].referencePersonID : null) : (this.state.TM_GetLeadDetailUpdate?.length > 0 ? this.state.TM_GetLeadDetailUpdate[0].referencePersonID : null)));

			
			stateVars.dataSource_931332 = stateVars.GetReferanceCustomerNew ?? this.state.GetReferanceCustomerNew;
			stateVars.dataSource_931332 = stateVars.GetReferanceCustomerNew ?? this.state.GetReferanceCustomerNew;
			stateVars.isComp36755Visible = ((ReactSystemFunctions.isNotEmpty(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "leadupdate_931332_value", "value", "GetReferanceCustomerNew", "id", "id")), ReactSystemFunctions.convertToTypeByName("True", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp561793Visible = ((ReactSystemFunctions.isNotEmpty(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "leadupdate_931332_value", "value", "GetReferanceCustomerNew", "id", "id")), ReactSystemFunctions.convertToTypeByName("True", "string"))) === true ? "visible" : "hidden")
			formVars.leadupdate_667900_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetReferanceByCurrAccCode !== undefined ? (stateVars.TM_GetReferanceByCurrAccCode?.length > 0 ? stateVars.TM_GetReferanceByCurrAccCode[0].referenceName : null) : (this.state.TM_GetReferanceByCurrAccCode?.length > 0 ? this.state.TM_GetReferanceByCurrAccCode[0].referenceName : null)));

			formVars.leadupdate_729604_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetReferanceByCurrAccCode !== undefined ? (stateVars.TM_GetReferanceByCurrAccCode?.length > 0 ? stateVars.TM_GetReferanceByCurrAccCode[0].referenceLastName : null) : (this.state.TM_GetReferanceByCurrAccCode?.length > 0 ? this.state.TM_GetReferanceByCurrAccCode[0].referenceLastName : null)));

			formVars.leadupdate_513812_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetReferanceByCurrAccCode !== undefined ? (stateVars.TM_GetReferanceByCurrAccCode?.length > 0 ? stateVars.TM_GetReferanceByCurrAccCode[0].referenceNationalID : null) : (this.state.TM_GetReferanceByCurrAccCode?.length > 0 ? this.state.TM_GetReferanceByCurrAccCode[0].referenceNationalID : null)));

			stateVars.isComp513812Visible = ((ReactSystemFunctions.isNotEmpty(ReactSystemFunctions.toString(this, (stateVars.TM_GetReferanceByCurrAccCode !== undefined ? (stateVars.TM_GetReferanceByCurrAccCode?.length > 0 ? stateVars.TM_GetReferanceByCurrAccCode[0].referenceNationalID : null) : (this.state.TM_GetReferanceByCurrAccCode?.length > 0 ? this.state.TM_GetReferanceByCurrAccCode[0].referenceNationalID : null))), ReactSystemFunctions.convertToTypeByName("True", "string"))) === true ? "visible" : "hidden")
			formVars.leadupdate_964461_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadDetailUpdate !== undefined ? (stateVars.TM_GetLeadDetailUpdate?.length > 0 ? stateVars.TM_GetLeadDetailUpdate[0].statuId : null) : (this.state.TM_GetLeadDetailUpdate?.length > 0 ? this.state.TM_GetLeadDetailUpdate[0].statuId : null)));

			
			stateVars.dataSource_964461 = stateVars.TM_GetLeadStatus ?? this.state.TM_GetLeadStatus;
			stateVars.dataSource_964461 = stateVars.TM_GetLeadStatus ?? this.state.TM_GetLeadStatus;
			stateVars.isComp964461Enabled = ((ReactSystemFunctions.doesNotContain(ReactSystemFunctions.toString(this, (stateVars.TM_UserRoleByUserId !== undefined ? (stateVars.TM_UserRoleByUserId?.length > 0 ? stateVars.TM_UserRoleByUserId[0].role : null) : (this.state.TM_UserRoleByUserId?.length > 0 ? this.state.TM_UserRoleByUserId[0].role : null))), ReactSystemFunctions.convertToTypeByName("TimesSatisPersoneli", "string"))) === true ? "enabled" : "disabled")
			formVars.leadupdate_680481_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadDetailUpdate !== undefined ? (stateVars.TM_GetLeadDetailUpdate?.length > 0 ? stateVars.TM_GetLeadDetailUpdate[0].nextStepId : null) : (this.state.TM_GetLeadDetailUpdate?.length > 0 ? this.state.TM_GetLeadDetailUpdate[0].nextStepId : null)));

			
			stateVars.dataSource_680481 = stateVars.TM_GetLeadNextSteps ?? this.state.TM_GetLeadNextSteps;
			stateVars.dataSource_680481 = stateVars.TM_GetLeadNextSteps ?? this.state.TM_GetLeadNextSteps;
			formVars.leadupdate_748311_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadDetailUpdate !== undefined ? (stateVars.TM_GetLeadDetailUpdate?.length > 0 ? stateVars.TM_GetLeadDetailUpdate[0].contactResourceId : null) : (this.state.TM_GetLeadDetailUpdate?.length > 0 ? this.state.TM_GetLeadDetailUpdate[0].contactResourceId : null)));

			
			stateVars.dataSource_748311 = stateVars.TM_GetAllContactSource ?? this.state.TM_GetAllContactSource;
			stateVars.dataSource_748311 = stateVars.TM_GetAllContactSource ?? this.state.TM_GetAllContactSource;
			formVars.leadupdate_10950_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadDetailUpdate !== undefined ? (stateVars.TM_GetLeadDetailUpdate?.length > 0 ? stateVars.TM_GetLeadDetailUpdate[0].talepNotu : null) : (this.state.TM_GetLeadDetailUpdate?.length > 0 ? this.state.TM_GetLeadDetailUpdate[0].talepNotu : null)));

			stateVars.isComp398947Visible = (((ReactSystemFunctions.doesNotContain(ReactSystemFunctions.getMyRoleNames(), ReactSystemFunctions.convertToTypeByName("TimesSatisPersoneli", "string")) && ReactSystemFunctions.isNotEmpty(ReactSystemFunctions.value(this, (stateVars.TM_GetLeadDetailUpdate !== undefined ? (stateVars.TM_GetLeadDetailUpdate?.length > 0 ? stateVars.TM_GetLeadDetailUpdate[0].estimatedDate : null) : (this.state.TM_GetLeadDetailUpdate?.length > 0 ? this.state.TM_GetLeadDetailUpdate[0].estimatedDate : null))), ReactSystemFunctions.convertToTypeByName("True", "string")))) === true ? "visible" : "hidden")
			formVars.leadupdate_749612_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadDetailUpdate !== undefined ? (stateVars.TM_GetLeadDetailUpdate?.length > 0 ? stateVars.TM_GetLeadDetailUpdate[0].estimatedYear : null) : (this.state.TM_GetLeadDetailUpdate?.length > 0 ? this.state.TM_GetLeadDetailUpdate[0].estimatedYear : null)));

			formVars.leadupdate_7574_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadDetailUpdate !== undefined ? (stateVars.TM_GetLeadDetailUpdate?.length > 0 ? stateVars.TM_GetLeadDetailUpdate[0].estimatedMonth : null) : (this.state.TM_GetLeadDetailUpdate?.length > 0 ? this.state.TM_GetLeadDetailUpdate[0].estimatedMonth : null)));


	this.props.form?.setFieldsValue(formVars);
	this.setState(stateVars);
	KuikaAppManager.hideSpinner(this);

            this.setPageInitLoaded(true);
            return isErrorOccurred;
        }




		LeadUpdateComponent_357364_onClick = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
KuikaAppManager.showSpinner(this);

				stateVars.GoBack = await ReactSystemFunctions.goBack(this, false);

		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

            
            return isErrorOccurred;
        }


    LeadUpdateComponent_795234_onClick = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;

			validations.push({ 
				isValid: ReactSystemFunctions.isNotEmpty(ReactSystemFunctions.value(this, "leadupdate_7574_value", "value", "", "key", ""), null),
				message: "Ay boş bırakılamaz!",
				formName: "leadupdate_7574_value",
				condition: ReactSystemFunctions.isNotEmpty(ReactSystemFunctions.value(this, (stateVars.TM_GetLeadDetailUpdate !== undefined ? (stateVars.TM_GetLeadDetailUpdate?.length > 0 ? stateVars.TM_GetLeadDetailUpdate[0].estimatedMonth : null) : (this.state.TM_GetLeadDetailUpdate?.length > 0 ? this.state.TM_GetLeadDetailUpdate[0].estimatedMonth : null))), ReactSystemFunctions.convertToTypeByName("True", "string"))
			} as IValidationData);

validations.forEach((validation) => {
            if (validation.message === "Geçerli bir mail adresi giriniz.") {
                validation.message = ReactSystemFunctions.getEmailValidationMessage()
            }
        })
			validations.push({ 
				isValid: ReactSystemFunctions.isNotEmpty(ReactSystemFunctions.value(this, "leadupdate_749612_value", "value", "", "key", ""), null),
				message: "Yıl boş bırakılamaz!",
				formName: "leadupdate_749612_value",
				condition: ReactSystemFunctions.isNotEmpty(ReactSystemFunctions.value(this, (stateVars.TM_GetLeadDetailUpdate !== undefined ? (stateVars.TM_GetLeadDetailUpdate?.length > 0 ? stateVars.TM_GetLeadDetailUpdate[0].estimatedYear : null) : (this.state.TM_GetLeadDetailUpdate?.length > 0 ? this.state.TM_GetLeadDetailUpdate[0].estimatedYear : null))), ReactSystemFunctions.convertToTypeByName("True", "string"))
			} as IValidationData);

validations.forEach((validation) => {
            if (validation.message === "Geçerli bir mail adresi giriniz.") {
                validation.message = ReactSystemFunctions.getEmailValidationMessage()
            }
        })
			validations.push({ 
				isValid: ReactSystemFunctions.isNotEmpty(ReactSystemFunctions.value(this, "leadupdate_964461_value", "value", "TM_GetLeadStatus", "id", ""), null),
				message: "Bu alan boş bırakılamaz!",
				formName: "leadupdate_964461_value",
				condition: true
			} as IValidationData);

validations.forEach((validation) => {
            if (validation.message === "Geçerli bir mail adresi giriniz.") {
                validation.message = ReactSystemFunctions.getEmailValidationMessage()
            }
        })
			validations.push({ 
				isValid: ReactSystemFunctions.isNotEmpty(ReactSystemFunctions.value(this, "leadupdate_964461_value", "value", "TM_GetLeadStatus", "id", ""), null),
				message: "Bu Alan Boş Bırakılamaz!",
				formName: "leadupdate_680481_value",
				condition: true
			} as IValidationData);

validations.forEach((validation) => {
            if (validation.message === "Geçerli bir mail adresi giriniz.") {
                validation.message = ReactSystemFunctions.getEmailValidationMessage()
            }
        })

		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
		KuikaAppManager.increaseServerRequestCount();

        let localVar = {
				LeadId_0: ReactSystemFunctions.convertToTypeByName(this.props.screenInputs.LeadId ?? this.props.screenInputs.leadid, "Guid"),
				EstimatedMonth_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toInteger(this, ReactSystemFunctions.value(this, "leadupdate_7574_value", "value", "", "key", "")), "number"),
				ReferencePersonID_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, (stateVars.TM_GetLeadDetailUpdate !== undefined ? (stateVars.TM_GetLeadDetailUpdate?.length > 0 ? stateVars.TM_GetLeadDetailUpdate[0].referencePersonID : null) : (this.state.TM_GetLeadDetailUpdate?.length > 0 ? this.state.TM_GetLeadDetailUpdate[0].referencePersonID : null))), "Guid"),
				SalesPersonKUserId_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "leadupdate_572982_value", "value", "GetSalesPersonByStore", "kuserID", "kuserID")), "Guid"),
				UpdatedBy_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.getMyUserId(), "Guid"),
				EstimatedYear_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toInteger(this, ReactSystemFunctions.value(this, "leadupdate_749612_value", "value", "", "key", "")), "number"),
				StatuId_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "leadupdate_964461_value", "value", "TM_GetLeadStatus", "id", "id")), "Guid"),
				NextStepId_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "leadupdate_680481_value", "value", "TM_GetLeadNextSteps", "id", "id")), "Guid"),
				StoreId_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "leadupdate_8232_value", "value", "TM_StoreGetList", "id", "id")), "Guid"),
				CustomerId_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "leadupdate_999965_value", "value", "TM_GetCustomerByName", "id", "id")), "Guid"),
				ContactResourceId_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "leadupdate_748311_value", "value", "TM_GetAllContactSource", "id", "id")), "Guid"),
				LeadNote_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "leadupdate_10950_value", "value", "", "", "")), "string")
        }

		KuikaAppManager.showSpinner(this);
		
        if (true) {
        KuikaAppManager.showSpinner(this);
        }
        let result = await KuikaAppManager.ApiRequest(this, "LeadUpdate/LeadUpdateComponent_795234_onClick", localVar)
        if (!KMainFunctions.IsResStatus2XX(result)) return true;

			stateVars.TM_UpdateLead = result?.data.tM_UpdateLead;
			this.props.form?.setFieldsValue(formVars);
			
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.LeadUpdateComponent_795234_onClick1_();
                  resolve();
                });
          })



        
        KuikaAppManager.hideSpinner(this);
        return isErrorOccurred;
    }
		LeadUpdateComponent_795234_onClick1_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }

				stateVars.Notify = await ReactSystemFunctions.notify(this, ReactSystemFunctions.toString(this, (stateVars.TM_UpdateLead !== undefined ? (stateVars.TM_UpdateLead?.length > 0 ? stateVars.TM_UpdateLead[0].message : null) : (this.state.TM_UpdateLead?.length > 0 ? this.state.TM_UpdateLead[0].message : null))), ReactSystemFunctions.convertToTypeByName("default", "string"), ReactSystemFunctions.convertToTypeByName("top-center", "string"), 3, ReactSystemFunctions.convertToTypeByName("", "string"), ReactSystemFunctions.convertToTypeByName("", "string"), 0);

		this.props.form?.setFieldsValue(formVars);
		
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.LeadUpdateComponent_795234_onClick2_();
                  resolve();
                });
          })

            
            return isErrorOccurred;
        }
		LeadUpdateComponent_795234_onClick2_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
if (ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, (stateVars.TM_UpdateLead !== undefined ? (stateVars.TM_UpdateLead?.length > 0 ? stateVars.TM_UpdateLead[0].isSuccess : null) : (this.state.TM_UpdateLead?.length > 0 ? this.state.TM_UpdateLead[0].isSuccess : null))), true)) {
            
					KuikaAppManager.prepareForNavigation();
						KuikaAppManager.addToPageInputVariables("LeadDetail", "LeadId", ReactSystemFunctions.convertToTypeByName(this.props.screenInputs.LeadId ?? this.props.screenInputs.leadid, "Guid"));

				stateVars.NAVIGATE = await ReactSystemFunctions.navigate(this, undefined, "LeadUpdate", "LeadDetail", "", "currentPage", null, null, null, null, null, null, true, false);

		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

        } else {
            KuikaAppManager.hideSpinner(this);
        }

            
            return isErrorOccurred;
        }





		LeadUpdateComponent_241466_onClick = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
KuikaAppManager.showSpinner(this);

				stateVars.GoBack = await ReactSystemFunctions.goBack(this, false);

		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

            
            return isErrorOccurred;
        }


    LeadUpdateComponent_8232_onChange = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
		KuikaAppManager.increaseServerRequestCount();

        let localVar = {
				StoreId_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "leadupdate_8232_value", "value", "TM_StoreGetList", "id", "id")), "Guid")
        }

		KuikaAppManager.showSpinner(this);
		
        if (true) {
        KuikaAppManager.showSpinner(this);
        }
        let result = await KuikaAppManager.ApiRequest(this, "LeadUpdate/LeadUpdateComponent_8232_onChange", localVar)
        if (!KMainFunctions.IsResStatus2XX(result)) return true;

			stateVars.GetSalesPersonByStore = result?.data.getSalesPersonByStore;
			
			formVars.leadupdate_572982_options = stateVars.GetSalesPersonByStore;
			this.props.form?.setFieldsValue(formVars);
			
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.LeadUpdateComponent_8232_onChange1_();
                  resolve();
                });
          })



        
        KuikaAppManager.hideSpinner(this);
        return isErrorOccurred;
    }
		LeadUpdateComponent_8232_onChange1_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }

				
				stateVars.dataSource_572982 = stateVars.GetSalesPersonByStore ?? this.state.GetSalesPersonByStore;
				stateVars.dataSource_572982 = stateVars.GetSalesPersonByStore ?? this.state.GetSalesPersonByStore;
				stateVars.isComp513936Visible = ((ReactSystemFunctions.isNotEmpty(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "leadupdate_8232_value", "value", "TM_StoreGetList", "id", "id")), ReactSystemFunctions.convertToTypeByName("True", "string"))) === true ? "visible" : "hidden")
				stateVars.isComp366434Visible = ((ReactSystemFunctions.isNotEmpty(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "leadupdate_8232_value", "value", "TM_StoreGetList", "id", "id")), ReactSystemFunctions.convertToTypeByName("True", "string"))) === true ? "visible" : "hidden")

		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

            
            return isErrorOccurred;
        }




    LeadUpdateComponent_572982_onChange = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
		KuikaAppManager.increaseServerRequestCount();

        let localVar = {
				KUserId_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "leadupdate_572982_value", "value", "GetSalesPersonByStore", "kuserID", "kuserID")), "Guid")
        }

		KuikaAppManager.showSpinner(this);
		
        if (true) {
        KuikaAppManager.showSpinner(this);
        }
        let result = await KuikaAppManager.ApiRequest(this, "LeadUpdate/LeadUpdateComponent_572982_onChange", localVar)
        if (!KMainFunctions.IsResStatus2XX(result)) return true;

			stateVars.TM_GetProductBrandAlternatif = result?.data.tM_GetProductBrandAlternatif;
			this.props.form?.setFieldsValue(formVars);
			this.setState(stateVars);
			KuikaAppManager.hideSpinner(this);



        this.setPageInitLoaded(true);
        KuikaAppManager.hideSpinner(this);
        return isErrorOccurred;
    }



    LeadUpdateComponent_999965_onChange = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
		KuikaAppManager.increaseServerRequestCount();

        let localVar = {
				CustomerId_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "leadupdate_999965_value", "value", "TM_GetCustomerByName", "id", "id")), "Guid"),
				CurrAccCode_1: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, (stateVars.TM_GetCustomerById !== undefined ? (stateVars.TM_GetCustomerById?.length > 0 ? stateVars.TM_GetCustomerById[0].currAccCode : null) : (this.state.TM_GetCustomerById?.length > 0 ? this.state.TM_GetCustomerById[0].currAccCode : null))), "string")
        }

		KuikaAppManager.showSpinner(this);
		
        if (true) {
        KuikaAppManager.showSpinner(this);
        }
        let result = await KuikaAppManager.ApiRequest(this, "LeadUpdate/LeadUpdateComponent_999965_onChange", localVar)
        if (!KMainFunctions.IsResStatus2XX(result)) return true;

			stateVars.TM_GetCustomerById = result?.data.tM_GetCustomerById;
			formVars.leadupdate_410287_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetCustomerById !== undefined ? (stateVars.TM_GetCustomerById?.length > 0 ? stateVars.TM_GetCustomerById[0].adSoyad : null) : (this.state.TM_GetCustomerById?.length > 0 ? this.state.TM_GetCustomerById[0].adSoyad : null)));
			formVars.leadupdate_683308_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetCustomerById !== undefined ? (stateVars.TM_GetCustomerById?.length > 0 ? stateVars.TM_GetCustomerById[0].tcKimlikNo : null) : (this.state.TM_GetCustomerById?.length > 0 ? this.state.TM_GetCustomerById[0].tcKimlikNo : null)));
			formVars.leadupdate_381076_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetCustomerById !== undefined ? (stateVars.TM_GetCustomerById?.length > 0 ? stateVars.TM_GetCustomerById[0].telefonNo : null) : (this.state.TM_GetCustomerById?.length > 0 ? this.state.TM_GetCustomerById[0].telefonNo : null)));
			formVars.leadupdate_496941_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetCustomerById !== undefined ? (stateVars.TM_GetCustomerById?.length > 0 ? stateVars.TM_GetCustomerById[0].email : null) : (this.state.TM_GetCustomerById?.length > 0 ? this.state.TM_GetCustomerById[0].email : null)));
			formVars.leadupdate_826540_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetCustomerById !== undefined ? (stateVars.TM_GetCustomerById?.length > 0 ? stateVars.TM_GetCustomerById[0].sehir : null) : (this.state.TM_GetCustomerById?.length > 0 ? this.state.TM_GetCustomerById[0].sehir : null)));
			stateVars.isComp683308Visible = ((ReactSystemFunctions.isNotEmpty(ReactSystemFunctions.toString(this, (stateVars.TM_GetCustomerById !== undefined ? (stateVars.TM_GetCustomerById?.length > 0 ? stateVars.TM_GetCustomerById[0].tcKimlikNo : null) : (this.state.TM_GetCustomerById?.length > 0 ? this.state.TM_GetCustomerById[0].tcKimlikNo : null))), ReactSystemFunctions.convertToTypeByName("True", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp315555Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, (stateVars.TM_GetCustomerById !== undefined ? (stateVars.TM_GetCustomerById?.length > 0 ? stateVars.TM_GetCustomerById[0].isShopping : null) : (this.state.TM_GetCustomerById?.length > 0 ? this.state.TM_GetCustomerById[0].isShopping : null))), ReactSystemFunctions.convertToTypeByName("True", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp630051Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, (stateVars.TM_GetCustomerById !== undefined ? (stateVars.TM_GetCustomerById?.length > 0 ? stateVars.TM_GetCustomerById[0].isShopping : null) : (this.state.TM_GetCustomerById?.length > 0 ? this.state.TM_GetCustomerById[0].isShopping : null))), ReactSystemFunctions.convertToTypeByName("False", "string"))) === true ? "visible" : "hidden")
			stateVars.TM_GetReferanceByCurrAccCode = result?.data.tM_GetReferanceByCurrAccCode;
			formVars.leadupdate_667900_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetReferanceByCurrAccCode !== undefined ? (stateVars.TM_GetReferanceByCurrAccCode?.length > 0 ? stateVars.TM_GetReferanceByCurrAccCode[0].referenceName : null) : (this.state.TM_GetReferanceByCurrAccCode?.length > 0 ? this.state.TM_GetReferanceByCurrAccCode[0].referenceName : null)));
			formVars.leadupdate_729604_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetReferanceByCurrAccCode !== undefined ? (stateVars.TM_GetReferanceByCurrAccCode?.length > 0 ? stateVars.TM_GetReferanceByCurrAccCode[0].referenceLastName : null) : (this.state.TM_GetReferanceByCurrAccCode?.length > 0 ? this.state.TM_GetReferanceByCurrAccCode[0].referenceLastName : null)));
			formVars.leadupdate_513812_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetReferanceByCurrAccCode !== undefined ? (stateVars.TM_GetReferanceByCurrAccCode?.length > 0 ? stateVars.TM_GetReferanceByCurrAccCode[0].referenceNationalID : null) : (this.state.TM_GetReferanceByCurrAccCode?.length > 0 ? this.state.TM_GetReferanceByCurrAccCode[0].referenceNationalID : null)));
			stateVars.isComp513812Visible = ((ReactSystemFunctions.isNotEmpty(ReactSystemFunctions.toString(this, (stateVars.TM_GetReferanceByCurrAccCode !== undefined ? (stateVars.TM_GetReferanceByCurrAccCode?.length > 0 ? stateVars.TM_GetReferanceByCurrAccCode[0].referenceNationalID : null) : (this.state.TM_GetReferanceByCurrAccCode?.length > 0 ? this.state.TM_GetReferanceByCurrAccCode[0].referenceNationalID : null))), ReactSystemFunctions.convertToTypeByName("True", "string"))) === true ? "visible" : "hidden")
			this.props.form?.setFieldsValue(formVars);
			
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.LeadUpdateComponent_999965_onChange1_();
                  resolve();
                });
          })



        
        KuikaAppManager.hideSpinner(this);
        return isErrorOccurred;
    }
		LeadUpdateComponent_999965_onChange1_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }

				stateVars.isComp910984Visible = ((ReactSystemFunctions.isNotEmpty(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "leadupdate_999965_value", "value", "TM_GetCustomerByName", "id", "id")), ReactSystemFunctions.convertToTypeByName("True", "string"))) === true ? "visible" : "hidden")
				formVars.leadupdate_410287_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetCustomerById !== undefined ? (stateVars.TM_GetCustomerById?.length > 0 ? stateVars.TM_GetCustomerById[0].adSoyad : null) : (this.state.TM_GetCustomerById?.length > 0 ? this.state.TM_GetCustomerById[0].adSoyad : null)));

				formVars.leadupdate_683308_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetCustomerById !== undefined ? (stateVars.TM_GetCustomerById?.length > 0 ? stateVars.TM_GetCustomerById[0].tcKimlikNo : null) : (this.state.TM_GetCustomerById?.length > 0 ? this.state.TM_GetCustomerById[0].tcKimlikNo : null)));

				formVars.leadupdate_381076_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetCustomerById !== undefined ? (stateVars.TM_GetCustomerById?.length > 0 ? stateVars.TM_GetCustomerById[0].telefonNo : null) : (this.state.TM_GetCustomerById?.length > 0 ? this.state.TM_GetCustomerById[0].telefonNo : null)));

				formVars.leadupdate_496941_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetCustomerById !== undefined ? (stateVars.TM_GetCustomerById?.length > 0 ? stateVars.TM_GetCustomerById[0].email : null) : (this.state.TM_GetCustomerById?.length > 0 ? this.state.TM_GetCustomerById[0].email : null)));

				formVars.leadupdate_826540_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetCustomerById !== undefined ? (stateVars.TM_GetCustomerById?.length > 0 ? stateVars.TM_GetCustomerById[0].sehir : null) : (this.state.TM_GetCustomerById?.length > 0 ? this.state.TM_GetCustomerById[0].sehir : null)));

				formVars.leadupdate_667900_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetReferanceByCurrAccCode !== undefined ? (stateVars.TM_GetReferanceByCurrAccCode?.length > 0 ? stateVars.TM_GetReferanceByCurrAccCode[0].referenceName : null) : (this.state.TM_GetReferanceByCurrAccCode?.length > 0 ? this.state.TM_GetReferanceByCurrAccCode[0].referenceName : null)));

				formVars.leadupdate_729604_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetReferanceByCurrAccCode !== undefined ? (stateVars.TM_GetReferanceByCurrAccCode?.length > 0 ? stateVars.TM_GetReferanceByCurrAccCode[0].referenceLastName : null) : (this.state.TM_GetReferanceByCurrAccCode?.length > 0 ? this.state.TM_GetReferanceByCurrAccCode[0].referenceLastName : null)));

				formVars.leadupdate_513812_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetReferanceByCurrAccCode !== undefined ? (stateVars.TM_GetReferanceByCurrAccCode?.length > 0 ? stateVars.TM_GetReferanceByCurrAccCode[0].referenceNationalID : null) : (this.state.TM_GetReferanceByCurrAccCode?.length > 0 ? this.state.TM_GetReferanceByCurrAccCode[0].referenceNationalID : null)));


		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

            
            return isErrorOccurred;
        }




    LeadUpdateComponent_513936_onClick = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
		KuikaAppManager.increaseServerRequestCount();

        let localVar = {
				CustomerId_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "leadupdate_8232_value", "value", "TM_StoreGetList", "id", "id")), "Guid")
        }

		KuikaAppManager.showSpinner(this);
		
        if (true) {
        KuikaAppManager.showSpinner(this);
        }
        let result = await KuikaAppManager.ApiRequest(this, "LeadUpdate/LeadUpdateComponent_513936_onClick", localVar)
        if (!KMainFunctions.IsResStatus2XX(result)) return true;

			stateVars.TM_GetCustomerById = result?.data.tM_GetCustomerById;
			formVars.leadupdate_410287_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetCustomerById !== undefined ? (stateVars.TM_GetCustomerById?.length > 0 ? stateVars.TM_GetCustomerById[0].adSoyad : null) : (this.state.TM_GetCustomerById?.length > 0 ? this.state.TM_GetCustomerById[0].adSoyad : null)));
			formVars.leadupdate_683308_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetCustomerById !== undefined ? (stateVars.TM_GetCustomerById?.length > 0 ? stateVars.TM_GetCustomerById[0].tcKimlikNo : null) : (this.state.TM_GetCustomerById?.length > 0 ? this.state.TM_GetCustomerById[0].tcKimlikNo : null)));
			formVars.leadupdate_381076_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetCustomerById !== undefined ? (stateVars.TM_GetCustomerById?.length > 0 ? stateVars.TM_GetCustomerById[0].telefonNo : null) : (this.state.TM_GetCustomerById?.length > 0 ? this.state.TM_GetCustomerById[0].telefonNo : null)));
			formVars.leadupdate_496941_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetCustomerById !== undefined ? (stateVars.TM_GetCustomerById?.length > 0 ? stateVars.TM_GetCustomerById[0].email : null) : (this.state.TM_GetCustomerById?.length > 0 ? this.state.TM_GetCustomerById[0].email : null)));
			formVars.leadupdate_826540_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetCustomerById !== undefined ? (stateVars.TM_GetCustomerById?.length > 0 ? stateVars.TM_GetCustomerById[0].sehir : null) : (this.state.TM_GetCustomerById?.length > 0 ? this.state.TM_GetCustomerById[0].sehir : null)));
			stateVars.isComp683308Visible = ((ReactSystemFunctions.isNotEmpty(ReactSystemFunctions.toString(this, (stateVars.TM_GetCustomerById !== undefined ? (stateVars.TM_GetCustomerById?.length > 0 ? stateVars.TM_GetCustomerById[0].tcKimlikNo : null) : (this.state.TM_GetCustomerById?.length > 0 ? this.state.TM_GetCustomerById[0].tcKimlikNo : null))), ReactSystemFunctions.convertToTypeByName("True", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp315555Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, (stateVars.TM_GetCustomerById !== undefined ? (stateVars.TM_GetCustomerById?.length > 0 ? stateVars.TM_GetCustomerById[0].isShopping : null) : (this.state.TM_GetCustomerById?.length > 0 ? this.state.TM_GetCustomerById[0].isShopping : null))), ReactSystemFunctions.convertToTypeByName("True", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp630051Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, (stateVars.TM_GetCustomerById !== undefined ? (stateVars.TM_GetCustomerById?.length > 0 ? stateVars.TM_GetCustomerById[0].isShopping : null) : (this.state.TM_GetCustomerById?.length > 0 ? this.state.TM_GetCustomerById[0].isShopping : null))), ReactSystemFunctions.convertToTypeByName("False", "string"))) === true ? "visible" : "hidden")
			this.props.form?.setFieldsValue(formVars);
			
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.LeadUpdateComponent_513936_onClick1_();
                  resolve();
                });
          })



        
        KuikaAppManager.hideSpinner(this);
        return isErrorOccurred;
    }
		LeadUpdateComponent_513936_onClick1_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }

					KuikaAppManager.prepareForNavigation();
						KuikaAppManager.addToPageInputVariables("CustomerDetailPage", "customerCode", ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, (stateVars.TM_GetCustomerById !== undefined ? (stateVars.TM_GetCustomerById?.length > 0 ? stateVars.TM_GetCustomerById[0].currAccCode : null) : (this.state.TM_GetCustomerById?.length > 0 ? this.state.TM_GetCustomerById[0].currAccCode : null))), "string"));
						KuikaAppManager.addToPageInputVariables("CustomerDetailPage", "CustomerId", ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, (stateVars.TM_GetCustomerById !== undefined ? (stateVars.TM_GetCustomerById?.length > 0 ? stateVars.TM_GetCustomerById[0].customerId : null) : (this.state.TM_GetCustomerById?.length > 0 ? this.state.TM_GetCustomerById[0].customerId : null))), "Guid"));

				stateVars.NAVIGATE = await ReactSystemFunctions.navigate(this, this.LeadUpdateComponent_513936_onClick2_, "LeadUpdate", "CustomerDetailPage", "", "7d969ddf-5801-4eb6-b92b-12be35bdd565", "627617", null, "right", "true", "80%", "100vh", true, false);

		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

            
            return isErrorOccurred;
        }
		LeadUpdateComponent_513936_onClick2_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
KuikaAppManager.showSpinner(this);

				formVars.leadupdate_410287_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetCustomerById !== undefined ? (stateVars.TM_GetCustomerById?.length > 0 ? stateVars.TM_GetCustomerById[0].adSoyad : null) : (this.state.TM_GetCustomerById?.length > 0 ? this.state.TM_GetCustomerById[0].adSoyad : null)));

				formVars.leadupdate_683308_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetCustomerById !== undefined ? (stateVars.TM_GetCustomerById?.length > 0 ? stateVars.TM_GetCustomerById[0].tcKimlikNo : null) : (this.state.TM_GetCustomerById?.length > 0 ? this.state.TM_GetCustomerById[0].tcKimlikNo : null)));

				formVars.leadupdate_381076_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetCustomerById !== undefined ? (stateVars.TM_GetCustomerById?.length > 0 ? stateVars.TM_GetCustomerById[0].telefonNo : null) : (this.state.TM_GetCustomerById?.length > 0 ? this.state.TM_GetCustomerById[0].telefonNo : null)));

				formVars.leadupdate_496941_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetCustomerById !== undefined ? (stateVars.TM_GetCustomerById?.length > 0 ? stateVars.TM_GetCustomerById[0].email : null) : (this.state.TM_GetCustomerById?.length > 0 ? this.state.TM_GetCustomerById[0].email : null)));

				formVars.leadupdate_826540_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetCustomerById !== undefined ? (stateVars.TM_GetCustomerById?.length > 0 ? stateVars.TM_GetCustomerById[0].sehir : null) : (this.state.TM_GetCustomerById?.length > 0 ? this.state.TM_GetCustomerById[0].sehir : null)));


		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

            
            return isErrorOccurred;
        }





    LeadUpdateComponent_366434_onClick = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
		KuikaAppManager.increaseServerRequestCount();

        let localVar = {
				CustomerId_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "leadupdate_8232_value", "value", "TM_StoreGetList", "id", "id")), "Guid")
        }

		KuikaAppManager.showSpinner(this);
		
        if (true) {
        KuikaAppManager.showSpinner(this);
        }
        let result = await KuikaAppManager.ApiRequest(this, "LeadUpdate/LeadUpdateComponent_366434_onClick", localVar)
        if (!KMainFunctions.IsResStatus2XX(result)) return true;

			stateVars.TM_GetCustomerById = result?.data.tM_GetCustomerById;
			formVars.leadupdate_410287_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetCustomerById !== undefined ? (stateVars.TM_GetCustomerById?.length > 0 ? stateVars.TM_GetCustomerById[0].adSoyad : null) : (this.state.TM_GetCustomerById?.length > 0 ? this.state.TM_GetCustomerById[0].adSoyad : null)));
			formVars.leadupdate_683308_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetCustomerById !== undefined ? (stateVars.TM_GetCustomerById?.length > 0 ? stateVars.TM_GetCustomerById[0].tcKimlikNo : null) : (this.state.TM_GetCustomerById?.length > 0 ? this.state.TM_GetCustomerById[0].tcKimlikNo : null)));
			formVars.leadupdate_381076_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetCustomerById !== undefined ? (stateVars.TM_GetCustomerById?.length > 0 ? stateVars.TM_GetCustomerById[0].telefonNo : null) : (this.state.TM_GetCustomerById?.length > 0 ? this.state.TM_GetCustomerById[0].telefonNo : null)));
			formVars.leadupdate_496941_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetCustomerById !== undefined ? (stateVars.TM_GetCustomerById?.length > 0 ? stateVars.TM_GetCustomerById[0].email : null) : (this.state.TM_GetCustomerById?.length > 0 ? this.state.TM_GetCustomerById[0].email : null)));
			formVars.leadupdate_826540_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetCustomerById !== undefined ? (stateVars.TM_GetCustomerById?.length > 0 ? stateVars.TM_GetCustomerById[0].sehir : null) : (this.state.TM_GetCustomerById?.length > 0 ? this.state.TM_GetCustomerById[0].sehir : null)));
			stateVars.isComp683308Visible = ((ReactSystemFunctions.isNotEmpty(ReactSystemFunctions.toString(this, (stateVars.TM_GetCustomerById !== undefined ? (stateVars.TM_GetCustomerById?.length > 0 ? stateVars.TM_GetCustomerById[0].tcKimlikNo : null) : (this.state.TM_GetCustomerById?.length > 0 ? this.state.TM_GetCustomerById[0].tcKimlikNo : null))), ReactSystemFunctions.convertToTypeByName("True", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp315555Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, (stateVars.TM_GetCustomerById !== undefined ? (stateVars.TM_GetCustomerById?.length > 0 ? stateVars.TM_GetCustomerById[0].isShopping : null) : (this.state.TM_GetCustomerById?.length > 0 ? this.state.TM_GetCustomerById[0].isShopping : null))), ReactSystemFunctions.convertToTypeByName("True", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp630051Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, (stateVars.TM_GetCustomerById !== undefined ? (stateVars.TM_GetCustomerById?.length > 0 ? stateVars.TM_GetCustomerById[0].isShopping : null) : (this.state.TM_GetCustomerById?.length > 0 ? this.state.TM_GetCustomerById[0].isShopping : null))), ReactSystemFunctions.convertToTypeByName("False", "string"))) === true ? "visible" : "hidden")
			this.props.form?.setFieldsValue(formVars);
			
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.LeadUpdateComponent_366434_onClick1_();
                  resolve();
                });
          })



        
        KuikaAppManager.hideSpinner(this);
        return isErrorOccurred;
    }
		LeadUpdateComponent_366434_onClick1_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }

					KuikaAppManager.prepareForNavigation();
						KuikaAppManager.addToPageInputVariables("CustomerUpdatePost", "CustomerId", ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, (stateVars.TM_GetCustomerById !== undefined ? (stateVars.TM_GetCustomerById?.length > 0 ? stateVars.TM_GetCustomerById[0].customerId : null) : (this.state.TM_GetCustomerById?.length > 0 ? this.state.TM_GetCustomerById[0].customerId : null))), "Guid"));

				stateVars.NAVIGATE = await ReactSystemFunctions.navigate(this, this.LeadUpdateComponent_366434_onClick2_, "LeadUpdate", "CustomerUpdatePost", "", "7d969ddf-5801-4eb6-b92b-12be35bdd565", "837957", null, "right", "true", "80%", "100vh", true, false);

		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

            
            return isErrorOccurred;
        }
		LeadUpdateComponent_366434_onClick2_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
KuikaAppManager.showSpinner(this);

				formVars.leadupdate_410287_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetCustomerById !== undefined ? (stateVars.TM_GetCustomerById?.length > 0 ? stateVars.TM_GetCustomerById[0].adSoyad : null) : (this.state.TM_GetCustomerById?.length > 0 ? this.state.TM_GetCustomerById[0].adSoyad : null)));

				formVars.leadupdate_683308_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetCustomerById !== undefined ? (stateVars.TM_GetCustomerById?.length > 0 ? stateVars.TM_GetCustomerById[0].tcKimlikNo : null) : (this.state.TM_GetCustomerById?.length > 0 ? this.state.TM_GetCustomerById[0].tcKimlikNo : null)));

				formVars.leadupdate_381076_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetCustomerById !== undefined ? (stateVars.TM_GetCustomerById?.length > 0 ? stateVars.TM_GetCustomerById[0].telefonNo : null) : (this.state.TM_GetCustomerById?.length > 0 ? this.state.TM_GetCustomerById[0].telefonNo : null)));

				formVars.leadupdate_496941_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetCustomerById !== undefined ? (stateVars.TM_GetCustomerById?.length > 0 ? stateVars.TM_GetCustomerById[0].email : null) : (this.state.TM_GetCustomerById?.length > 0 ? this.state.TM_GetCustomerById[0].email : null)));

				formVars.leadupdate_826540_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetCustomerById !== undefined ? (stateVars.TM_GetCustomerById?.length > 0 ? stateVars.TM_GetCustomerById[0].sehir : null) : (this.state.TM_GetCustomerById?.length > 0 ? this.state.TM_GetCustomerById[0].sehir : null)));


		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

            
            return isErrorOccurred;
        }





		LeadUpdateComponent_931332_onChange = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
KuikaAppManager.showSpinner(this);

				stateVars.isComp36755Visible = ((ReactSystemFunctions.isNotEmpty(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "leadupdate_931332_value", "value", "GetReferanceCustomerNew", "id", "id")), true)) === true ? "visible" : "hidden")
				stateVars.isComp561793Visible = ((ReactSystemFunctions.isNotEmpty(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "leadupdate_931332_value", "value", "GetReferanceCustomerNew", "id", "id")), true)) === true ? "visible" : "hidden")

		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

            
            return isErrorOccurred;
        }


    LeadUpdateComponent_36755_onClick = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
		KuikaAppManager.increaseServerRequestCount();

        let localVar = {
				CurrAccCode_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "leadupdate_931332_value", "value", "GetReferanceCustomerNew", "id", "currAccCode")), "string")
        }

		KuikaAppManager.showSpinner(this);
		
        if (true) {
        KuikaAppManager.showSpinner(this);
        }
        let result = await KuikaAppManager.ApiRequest(this, "LeadUpdate/LeadUpdateComponent_36755_onClick", localVar)
        if (!KMainFunctions.IsResStatus2XX(result)) return true;

			stateVars.TM_GetReferanceByCurrAccCode = result?.data.tM_GetReferanceByCurrAccCode;
			formVars.leadupdate_667900_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetReferanceByCurrAccCode !== undefined ? (stateVars.TM_GetReferanceByCurrAccCode?.length > 0 ? stateVars.TM_GetReferanceByCurrAccCode[0].referenceName : null) : (this.state.TM_GetReferanceByCurrAccCode?.length > 0 ? this.state.TM_GetReferanceByCurrAccCode[0].referenceName : null)));
			formVars.leadupdate_729604_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetReferanceByCurrAccCode !== undefined ? (stateVars.TM_GetReferanceByCurrAccCode?.length > 0 ? stateVars.TM_GetReferanceByCurrAccCode[0].referenceLastName : null) : (this.state.TM_GetReferanceByCurrAccCode?.length > 0 ? this.state.TM_GetReferanceByCurrAccCode[0].referenceLastName : null)));
			formVars.leadupdate_513812_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetReferanceByCurrAccCode !== undefined ? (stateVars.TM_GetReferanceByCurrAccCode?.length > 0 ? stateVars.TM_GetReferanceByCurrAccCode[0].referenceNationalID : null) : (this.state.TM_GetReferanceByCurrAccCode?.length > 0 ? this.state.TM_GetReferanceByCurrAccCode[0].referenceNationalID : null)));
			stateVars.isComp513812Visible = ((ReactSystemFunctions.isNotEmpty(ReactSystemFunctions.toString(this, (stateVars.TM_GetReferanceByCurrAccCode !== undefined ? (stateVars.TM_GetReferanceByCurrAccCode?.length > 0 ? stateVars.TM_GetReferanceByCurrAccCode[0].referenceNationalID : null) : (this.state.TM_GetReferanceByCurrAccCode?.length > 0 ? this.state.TM_GetReferanceByCurrAccCode[0].referenceNationalID : null))), ReactSystemFunctions.convertToTypeByName("True", "string"))) === true ? "visible" : "hidden")
			this.props.form?.setFieldsValue(formVars);
			
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.LeadUpdateComponent_36755_onClick1_();
                  resolve();
                });
          })



        
        KuikaAppManager.hideSpinner(this);
        return isErrorOccurred;
    }
		LeadUpdateComponent_36755_onClick1_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }

					KuikaAppManager.prepareForNavigation();
						KuikaAppManager.addToPageInputVariables("CustomerDetailPage", "customerCode", ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, (stateVars.TM_GetReferanceByCurrAccCode !== undefined ? (stateVars.TM_GetReferanceByCurrAccCode?.length > 0 ? stateVars.TM_GetReferanceByCurrAccCode[0].currAccCode : null) : (this.state.TM_GetReferanceByCurrAccCode?.length > 0 ? this.state.TM_GetReferanceByCurrAccCode[0].currAccCode : null))), "string"));
						KuikaAppManager.addToPageInputVariables("CustomerDetailPage", "CustomerId", ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, (stateVars.TM_GetReferanceByCurrAccCode !== undefined ? (stateVars.TM_GetReferanceByCurrAccCode?.length > 0 ? stateVars.TM_GetReferanceByCurrAccCode[0].customerId : null) : (this.state.TM_GetReferanceByCurrAccCode?.length > 0 ? this.state.TM_GetReferanceByCurrAccCode[0].customerId : null))), "Guid"));

				stateVars.NAVIGATE = await ReactSystemFunctions.navigate(this, this.LeadUpdateComponent_36755_onClick2_, "LeadUpdate", "CustomerDetailPage", "", "7d969ddf-5801-4eb6-b92b-12be35bdd565", "966643", null, "right", "true", "80%", "100vh", true, false);

		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

            
            return isErrorOccurred;
        }
		LeadUpdateComponent_36755_onClick2_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
KuikaAppManager.showSpinner(this);

				formVars.leadupdate_667900_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetReferanceByCurrAccCode !== undefined ? (stateVars.TM_GetReferanceByCurrAccCode?.length > 0 ? stateVars.TM_GetReferanceByCurrAccCode[0].referenceName : null) : (this.state.TM_GetReferanceByCurrAccCode?.length > 0 ? this.state.TM_GetReferanceByCurrAccCode[0].referenceName : null)));

				formVars.leadupdate_729604_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetReferanceByCurrAccCode !== undefined ? (stateVars.TM_GetReferanceByCurrAccCode?.length > 0 ? stateVars.TM_GetReferanceByCurrAccCode[0].referenceLastName : null) : (this.state.TM_GetReferanceByCurrAccCode?.length > 0 ? this.state.TM_GetReferanceByCurrAccCode[0].referenceLastName : null)));

				formVars.leadupdate_513812_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetReferanceByCurrAccCode !== undefined ? (stateVars.TM_GetReferanceByCurrAccCode?.length > 0 ? stateVars.TM_GetReferanceByCurrAccCode[0].referenceNationalID : null) : (this.state.TM_GetReferanceByCurrAccCode?.length > 0 ? this.state.TM_GetReferanceByCurrAccCode[0].referenceNationalID : null)));


		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

            
            return isErrorOccurred;
        }





    LeadUpdateComponent_561793_onClick = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
		KuikaAppManager.increaseServerRequestCount();

        let localVar = {
				CurrAccCode_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "leadupdate_931332_value", "value", "GetReferanceCustomerNew", "id", "currAccCode")), "string")
        }

		KuikaAppManager.showSpinner(this);
		
        if (true) {
        KuikaAppManager.showSpinner(this);
        }
        let result = await KuikaAppManager.ApiRequest(this, "LeadUpdate/LeadUpdateComponent_561793_onClick", localVar)
        if (!KMainFunctions.IsResStatus2XX(result)) return true;

			stateVars.TM_GetReferanceByCurrAccCode = result?.data.tM_GetReferanceByCurrAccCode;
			formVars.leadupdate_667900_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetReferanceByCurrAccCode !== undefined ? (stateVars.TM_GetReferanceByCurrAccCode?.length > 0 ? stateVars.TM_GetReferanceByCurrAccCode[0].referenceName : null) : (this.state.TM_GetReferanceByCurrAccCode?.length > 0 ? this.state.TM_GetReferanceByCurrAccCode[0].referenceName : null)));
			formVars.leadupdate_729604_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetReferanceByCurrAccCode !== undefined ? (stateVars.TM_GetReferanceByCurrAccCode?.length > 0 ? stateVars.TM_GetReferanceByCurrAccCode[0].referenceLastName : null) : (this.state.TM_GetReferanceByCurrAccCode?.length > 0 ? this.state.TM_GetReferanceByCurrAccCode[0].referenceLastName : null)));
			formVars.leadupdate_513812_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetReferanceByCurrAccCode !== undefined ? (stateVars.TM_GetReferanceByCurrAccCode?.length > 0 ? stateVars.TM_GetReferanceByCurrAccCode[0].referenceNationalID : null) : (this.state.TM_GetReferanceByCurrAccCode?.length > 0 ? this.state.TM_GetReferanceByCurrAccCode[0].referenceNationalID : null)));
			stateVars.isComp513812Visible = ((ReactSystemFunctions.isNotEmpty(ReactSystemFunctions.toString(this, (stateVars.TM_GetReferanceByCurrAccCode !== undefined ? (stateVars.TM_GetReferanceByCurrAccCode?.length > 0 ? stateVars.TM_GetReferanceByCurrAccCode[0].referenceNationalID : null) : (this.state.TM_GetReferanceByCurrAccCode?.length > 0 ? this.state.TM_GetReferanceByCurrAccCode[0].referenceNationalID : null))), ReactSystemFunctions.convertToTypeByName("True", "string"))) === true ? "visible" : "hidden")
			this.props.form?.setFieldsValue(formVars);
			
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.LeadUpdateComponent_561793_onClick1_();
                  resolve();
                });
          })



        
        KuikaAppManager.hideSpinner(this);
        return isErrorOccurred;
    }
		LeadUpdateComponent_561793_onClick1_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }

					KuikaAppManager.prepareForNavigation();
						KuikaAppManager.addToPageInputVariables("CustomerUpdatePost", "CustomerId", ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, (stateVars.TM_GetReferanceByCurrAccCode !== undefined ? (stateVars.TM_GetReferanceByCurrAccCode?.length > 0 ? stateVars.TM_GetReferanceByCurrAccCode[0].customerId : null) : (this.state.TM_GetReferanceByCurrAccCode?.length > 0 ? this.state.TM_GetReferanceByCurrAccCode[0].customerId : null))), "Guid"));

				stateVars.NAVIGATE = await ReactSystemFunctions.navigate(this, this.LeadUpdateComponent_561793_onClick2_, "LeadUpdate", "CustomerUpdatePost", "", "7d969ddf-5801-4eb6-b92b-12be35bdd565", "276990", null, "right", "true", "80%", "100vh", true, false);

		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

            
            return isErrorOccurred;
        }
		LeadUpdateComponent_561793_onClick2_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
KuikaAppManager.showSpinner(this);

				formVars.leadupdate_667900_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetReferanceByCurrAccCode !== undefined ? (stateVars.TM_GetReferanceByCurrAccCode?.length > 0 ? stateVars.TM_GetReferanceByCurrAccCode[0].referenceName : null) : (this.state.TM_GetReferanceByCurrAccCode?.length > 0 ? this.state.TM_GetReferanceByCurrAccCode[0].referenceName : null)));

				formVars.leadupdate_729604_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetReferanceByCurrAccCode !== undefined ? (stateVars.TM_GetReferanceByCurrAccCode?.length > 0 ? stateVars.TM_GetReferanceByCurrAccCode[0].referenceLastName : null) : (this.state.TM_GetReferanceByCurrAccCode?.length > 0 ? this.state.TM_GetReferanceByCurrAccCode[0].referenceLastName : null)));

				formVars.leadupdate_513812_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetReferanceByCurrAccCode !== undefined ? (stateVars.TM_GetReferanceByCurrAccCode?.length > 0 ? stateVars.TM_GetReferanceByCurrAccCode[0].referenceNationalID : null) : (this.state.TM_GetReferanceByCurrAccCode?.length > 0 ? this.state.TM_GetReferanceByCurrAccCode[0].referenceNationalID : null)));


		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

            
            return isErrorOccurred;
        }





		LeadUpdateComponent_433970_onClick = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
KuikaAppManager.showSpinner(this);

					KuikaAppManager.prepareForNavigation();

				stateVars.NAVIGATE = await ReactSystemFunctions.navigate(this, undefined, "LeadUpdate", "ContactSourceAdd", "", "7d969ddf-5801-4eb6-b92b-12be35bdd565", "715953", null, "right", "true", "380px", "100vh", true, false);

		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

            
            return isErrorOccurred;
        }




    async callCallbackFunction(diId: number, isFromMaster: boolean = false) {
        let isErrorOccurred = false;
		let pageInitCallerNavDiIDs = [, 627617, 837957, 966643, 276990, 715953] as number[];
		if (isFromMaster || pageInitCallerNavDiIDs.indexOf(diId) > -1) {
			await this.LeadUpdatePageInit();
		}
		if (diId == 627617) {
			isErrorOccurred = await this.LeadUpdateComponent_513936_onClick2_();
            if (isErrorOccurred) return true;
		}
		else if (diId == 837957) {
			isErrorOccurred = await this.LeadUpdateComponent_366434_onClick2_();
            if (isErrorOccurred) return true;
		}
		else if (diId == 966643) {
			isErrorOccurred = await this.LeadUpdateComponent_36755_onClick2_();
            if (isErrorOccurred) return true;
		}
		else if (diId == 276990) {
			isErrorOccurred = await this.LeadUpdateComponent_561793_onClick2_();
            if (isErrorOccurred) return true;
		}

    }


}
