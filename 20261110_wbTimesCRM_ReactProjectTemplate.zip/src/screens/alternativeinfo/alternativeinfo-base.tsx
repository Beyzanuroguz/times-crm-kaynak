import React from "react";
import Axios, { AxiosResponse } from "axios";
import { KuikaAppManager } from "../../shared/utilty/kuika-app-manager";
import { ReactSystemFunctions } from "../../shared/utilty/react-system-functions";
import { KNavigator } from "../../shared/hoc/with-history";
import { KContext } from "../../shared/hoc/with-context";
import { useLocation } from "react-router-dom";
import { FormInstance } from "antd/es/form";
import { Guid } from "guid-typescript";
import Swal from "sweetalert2";
import { KMainFunctions } from "../../shared/utilty/main-functions";
import moment from "moment";
import { IValidationData } from "../../models/dto/validation-data";
import { IStripePayment } from "../../models/dto/stripe-payment";
import { IUserInfoDto } from "../../models/dto/user-info.dto";
import { UserService } from "../../services/user-service";
import { kuikaCoreWasmBridgeService } from "../../services/_singletons";
import _ from "lodash";
import mqtt, { MqttClient } from "mqtt";
import { IMqttResult } from "../../models/dto/mqtt.dto";


declare let window: any;

export interface IAlternativeInfo_ScreenProps {
  navigator: KNavigator;
  form: FormInstance<any>;
  googleLogin: any;
  screenInputs: any;
  context: KContext;
  initialValues: any;
  children: any;
}

export interface IAlternativeInfo_ScreenState {
    isSpinnerVisible: boolean;
    isPageVisible: boolean;
	isLeftMenuVisible: boolean;
    spinnerCount: number;
    selectedLanguage: string;
    isPageInitLoaded: false;
    isPageRecurringLoaded: false;
	TMAlternativeInfo: any[];
	TMAlternativeInfo_dummy: any[];
	GoBack: any;
	GoBack_dummy: any;
	isComp440290Visible: 'visible' | 'hidden';
	isComp143144Visible: 'visible' | 'hidden';

}

export class AlternativeInfo_ScreenBase extends React.PureComponent<IAlternativeInfo_ScreenProps, any> {


    ml=[{"Id":"d5a61d2b-bd60-485f-86e2-661e9ed4e486","Name":"en_US","ShortName":"English","IsDefault":true,"LanguagePhrases":[]},{"Id":"cb23c7fb-ed82-46e2-bfdf-2e03c9783d2e","Name":"FixedValues","ShortName":"FixedValues","LanguagePhrases":[{"Id":998087,"PropertyName":"value","Value":"Alternatif Ürün Bilgisi"},{"Id":360675,"PropertyName":"value","Value":"Ürün Adı"},{"Id":128856,"PropertyName":"value","Value":"Mağaza"},{"Id":35514,"PropertyName":"value","Value":"Depo"},{"Id":548291,"PropertyName":"value","Value":"Stok"},{"Id":958420,"PropertyName":"value","Value":"Rezerve Durumu"},{"Id":617044,"PropertyName":"value","Value":"Rezerve Tarihi"},{"Id":343544,"PropertyName":"value","Value":"Rezerve Eden"},{"Id":757666,"PropertyName":"value","Value":"Rezerve Edilen Müşteri"}]}]
    defaultML = "en_US"
    
    screenHash = ""
    


    constructor(props) {
        super(props);


        this.state = {
            isSpinnerVisible: false,
            isPageVisible: false,
            isLeftMenuVisible: false,
            spinnerCount: 0,
            selectedLanguage: "",
            isPageInitLoaded: false,
            isPageRecurringLoaded: false,
            	        TMAlternativeInfo: [],
	        GoBack: "",
	        isComp440290Visible: 'hidden',
	        isComp143144Visible: 'hidden',

        }

        this.state.isPageVisible = true;
        
    }

    async componentDidMount() {

        if (KuikaAppManager.isPageInitPrevented()) {
            KuikaAppManager.calculateAndSetBodyHeight("alternativeinfo", "");
            return;
        }
        
        
        ReactSystemFunctions.validateToken()
        this.fillFormInitValues();
        if (true){
            await this.AlternativeInfoPageInit();
        }
        
        
        
        KuikaAppManager.calculateAndSetBodyHeight("alternativeinfo", "");

        if (ReactSystemFunctions.getIsMicroApp() === false) {
           window.parentScreen = this;
        }
    }

    componentWillUnmount() {
        
        
        

        if (ReactSystemFunctions.getIsMicroApp() === false) {
           window.parentScreen = null;
        }
    }

    

        
    componentDidUpdate= async (prevProps, prevState) => {
		KuikaAppManager.calculateAndSetBodyHeight("alternativeinfo", ""    );
        if (prevProps?.location?.search !== (this.props as any)?.location?.search) {
			await this.AlternativeInfoPageInit();
		}

        

        if (ReactSystemFunctions.getIsMicroApp() === false) {
            for (const key in prevState) {
                if (key.startsWith('NavVisible') && prevState[key] === true && this.state[key] === false) {
                    window.parentScreen = this;
                    break;
                }
            }
        }
	}

    fillFormInitValues() {
        this.props.form?.setFieldsValue({
});

    }

      setPageInitLoaded = (value: boolean) => {
        this.setState({ isPageInitLoaded: value });
      }

      setPageRecurringLoaded = (value: boolean) => {
        this.setState({ isPageRecurringLoaded: value });
      }

      clearFieldValidation = (changedValues: any) => {
        const fieldName = Object.keys(changedValues)[0];
        if (fieldName) {
          this.props.form?.setFields([
            {
              name: fieldName,
              errors: []
            }
          ]);
        }
      };

      

    AlternativeInfoPageInit = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


	if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }

        let localVar = {
			KUserId_0: ReactSystemFunctions.convertToTypeByName(this.props.screenInputs.KUserId ?? this.props.screenInputs.kuserid, "Guid"),
			AlternativeProductId_0: ReactSystemFunctions.convertToTypeByName(this.props.screenInputs.ProductId ?? this.props.screenInputs.productid, "Guid")
        }

	KuikaAppManager.showSpinner(this);
	
        if (true) {
        KuikaAppManager.showSpinner(this);
        }
        let result = await KuikaAppManager.ApiRequest(this, "AlternativeInfo/AlternativeInfoPageInit", localVar)
        if (!KMainFunctions.IsResStatus2XX(result)) return true;

		stateVars.TMAlternativeInfo = result?.data.tmAlternativeInfo;
		formVars.alternativeinfo_48088_value = ReactSystemFunctions.toString(this, (stateVars.TMAlternativeInfo !== undefined ? (stateVars.TMAlternativeInfo?.length > 0 ? stateVars.TMAlternativeInfo[0].productDescription : null) : (this.state.TMAlternativeInfo?.length > 0 ? this.state.TMAlternativeInfo[0].productDescription : null)));
		formVars.alternativeinfo_395380_value = ReactSystemFunctions.toString(this, (stateVars.TMAlternativeInfo !== undefined ? (stateVars.TMAlternativeInfo?.length > 0 ? stateVars.TMAlternativeInfo[0].storeDescription : null) : (this.state.TMAlternativeInfo?.length > 0 ? this.state.TMAlternativeInfo[0].storeDescription : null)));
		formVars.alternativeinfo_646224_value = ReactSystemFunctions.toString(this, (stateVars.TMAlternativeInfo !== undefined ? (stateVars.TMAlternativeInfo?.length > 0 ? stateVars.TMAlternativeInfo[0].wareHouseDescription : null) : (this.state.TMAlternativeInfo?.length > 0 ? this.state.TMAlternativeInfo[0].wareHouseDescription : null)));
		formVars.alternativeinfo_447021_value = ReactSystemFunctions.toString(this, (stateVars.TMAlternativeInfo !== undefined ? (stateVars.TMAlternativeInfo?.length > 0 ? stateVars.TMAlternativeInfo[0].stockQty : null) : (this.state.TMAlternativeInfo?.length > 0 ? this.state.TMAlternativeInfo[0].stockQty : null)));
		formVars.alternativeinfo_540792_value = ReactSystemFunctions.toString(this, (stateVars.TMAlternativeInfo !== undefined ? (stateVars.TMAlternativeInfo?.length > 0 ? stateVars.TMAlternativeInfo[0].reservationStatus : null) : (this.state.TMAlternativeInfo?.length > 0 ? this.state.TMAlternativeInfo[0].reservationStatus : null)));
		formVars.alternativeinfo_71351_value = ReactSystemFunctions.value(this, (stateVars.TMAlternativeInfo !== undefined ? (stateVars.TMAlternativeInfo?.length > 0 ? stateVars.TMAlternativeInfo[0].reservedAt : null) : (this.state.TMAlternativeInfo?.length > 0 ? this.state.TMAlternativeInfo[0].reservedAt : null)));
		formVars.alternativeinfo_310680_value = ReactSystemFunctions.toString(this, (stateVars.TMAlternativeInfo !== undefined ? (stateVars.TMAlternativeInfo?.length > 0 ? stateVars.TMAlternativeInfo[0].reservedBy : null) : (this.state.TMAlternativeInfo?.length > 0 ? this.state.TMAlternativeInfo[0].reservedBy : null)));
		formVars.alternativeinfo_4750_value = ReactSystemFunctions.toString(this, (stateVars.TMAlternativeInfo !== undefined ? (stateVars.TMAlternativeInfo?.length > 0 ? stateVars.TMAlternativeInfo[0].customerName : null) : (this.state.TMAlternativeInfo?.length > 0 ? this.state.TMAlternativeInfo[0].customerName : null)));
		stateVars.isComp440290Visible = ((ReactSystemFunctions.isNotEmpty(ReactSystemFunctions.value(this, (stateVars.TMAlternativeInfo !== undefined ? (stateVars.TMAlternativeInfo?.length > 0 ? stateVars.TMAlternativeInfo[0].reservedAt : null) : (this.state.TMAlternativeInfo?.length > 0 ? this.state.TMAlternativeInfo[0].reservedAt : null))), ReactSystemFunctions.convertToTypeByName("True", "string"))) === true ? "visible" : "hidden")
		stateVars.isComp143144Visible = ((ReactSystemFunctions.isNotEmpty(ReactSystemFunctions.value(this, (stateVars.TMAlternativeInfo !== undefined ? (stateVars.TMAlternativeInfo?.length > 0 ? stateVars.TMAlternativeInfo[0].reservedAt : null) : (this.state.TMAlternativeInfo?.length > 0 ? this.state.TMAlternativeInfo[0].reservedAt : null))), ReactSystemFunctions.convertToTypeByName("True", "string"))) === true ? "visible" : "hidden")
		this.props.form?.setFieldsValue(formVars);
		
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.AlternativeInfoPageInit1_();
                  resolve();
                });
          })



        
        KuikaAppManager.hideSpinner(this);
        return isErrorOccurred;
    }
	AlternativeInfoPageInit1_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


	if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }

			formVars.alternativeinfo_48088_value = ReactSystemFunctions.toString(this, (stateVars.TMAlternativeInfo !== undefined ? (stateVars.TMAlternativeInfo?.length > 0 ? stateVars.TMAlternativeInfo[0].productDescription : null) : (this.state.TMAlternativeInfo?.length > 0 ? this.state.TMAlternativeInfo[0].productDescription : null)));

			formVars.alternativeinfo_395380_value = ReactSystemFunctions.toString(this, (stateVars.TMAlternativeInfo !== undefined ? (stateVars.TMAlternativeInfo?.length > 0 ? stateVars.TMAlternativeInfo[0].storeDescription : null) : (this.state.TMAlternativeInfo?.length > 0 ? this.state.TMAlternativeInfo[0].storeDescription : null)));

			formVars.alternativeinfo_646224_value = ReactSystemFunctions.toString(this, (stateVars.TMAlternativeInfo !== undefined ? (stateVars.TMAlternativeInfo?.length > 0 ? stateVars.TMAlternativeInfo[0].wareHouseDescription : null) : (this.state.TMAlternativeInfo?.length > 0 ? this.state.TMAlternativeInfo[0].wareHouseDescription : null)));

			formVars.alternativeinfo_447021_value = ReactSystemFunctions.toString(this, (stateVars.TMAlternativeInfo !== undefined ? (stateVars.TMAlternativeInfo?.length > 0 ? stateVars.TMAlternativeInfo[0].stockQty : null) : (this.state.TMAlternativeInfo?.length > 0 ? this.state.TMAlternativeInfo[0].stockQty : null)));

			formVars.alternativeinfo_540792_value = ReactSystemFunctions.toString(this, (stateVars.TMAlternativeInfo !== undefined ? (stateVars.TMAlternativeInfo?.length > 0 ? stateVars.TMAlternativeInfo[0].reservationStatus : null) : (this.state.TMAlternativeInfo?.length > 0 ? this.state.TMAlternativeInfo[0].reservationStatus : null)));

			stateVars.isComp440290Visible = ((ReactSystemFunctions.isNotEmpty(ReactSystemFunctions.value(this, (stateVars.TMAlternativeInfo !== undefined ? (stateVars.TMAlternativeInfo?.length > 0 ? stateVars.TMAlternativeInfo[0].reservedAt : null) : (this.state.TMAlternativeInfo?.length > 0 ? this.state.TMAlternativeInfo[0].reservedAt : null))), ReactSystemFunctions.convertToTypeByName("True", "string"))) === true ? "visible" : "hidden")
			formVars.alternativeinfo_71351_value = ReactSystemFunctions.value(this, (stateVars.TMAlternativeInfo !== undefined ? (stateVars.TMAlternativeInfo?.length > 0 ? stateVars.TMAlternativeInfo[0].reservedAt : null) : (this.state.TMAlternativeInfo?.length > 0 ? this.state.TMAlternativeInfo[0].reservedAt : null)));

			stateVars.isComp143144Visible = ((ReactSystemFunctions.isNotEmpty(ReactSystemFunctions.value(this, (stateVars.TMAlternativeInfo !== undefined ? (stateVars.TMAlternativeInfo?.length > 0 ? stateVars.TMAlternativeInfo[0].reservedAt : null) : (this.state.TMAlternativeInfo?.length > 0 ? this.state.TMAlternativeInfo[0].reservedAt : null))), ReactSystemFunctions.convertToTypeByName("True", "string"))) === true ? "visible" : "hidden")
			formVars.alternativeinfo_310680_value = ReactSystemFunctions.toString(this, (stateVars.TMAlternativeInfo !== undefined ? (stateVars.TMAlternativeInfo?.length > 0 ? stateVars.TMAlternativeInfo[0].reservedBy : null) : (this.state.TMAlternativeInfo?.length > 0 ? this.state.TMAlternativeInfo[0].reservedBy : null)));

			formVars.alternativeinfo_4750_value = ReactSystemFunctions.toString(this, (stateVars.TMAlternativeInfo !== undefined ? (stateVars.TMAlternativeInfo?.length > 0 ? stateVars.TMAlternativeInfo[0].customerName : null) : (this.state.TMAlternativeInfo?.length > 0 ? this.state.TMAlternativeInfo[0].customerName : null)));


	this.props.form?.setFieldsValue(formVars);
	this.setState(stateVars);
	KuikaAppManager.hideSpinner(this);

            this.setPageInitLoaded(true);
            return isErrorOccurred;
        }




		AlternativeInfoComponent_953804_onClick = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
KuikaAppManager.showSpinner(this);

				stateVars.GoBack = await ReactSystemFunctions.goBack(this, false);

		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

            
            return isErrorOccurred;
        }




    async callCallbackFunction(diId: number, isFromMaster: boolean = false) {
        let isErrorOccurred = false;
		let pageInitCallerNavDiIDs = [] as number[];
		if (isFromMaster || pageInitCallerNavDiIDs.indexOf(diId) > -1) {
			await this.AlternativeInfoPageInit();
		}

    }


}
