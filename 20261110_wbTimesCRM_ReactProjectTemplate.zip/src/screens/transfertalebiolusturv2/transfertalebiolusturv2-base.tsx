import React from "react";
import Axios, { AxiosResponse } from "axios";
import { KuikaAppManager } from "../../shared/utilty/kuika-app-manager";
import { ReactSystemFunctions } from "../../shared/utilty/react-system-functions";
import { KNavigator } from "../../shared/hoc/with-history";
import { KContext } from "../../shared/hoc/with-context";
import { useLocation } from "react-router-dom";
import { FormInstance } from "antd/es/form";
import { Guid } from "guid-typescript";
import Swal from "sweetalert2";
import { KMainFunctions } from "../../shared/utilty/main-functions";
import moment from "moment";
import { IValidationData } from "../../models/dto/validation-data";
import { IStripePayment } from "../../models/dto/stripe-payment";
import { IUserInfoDto } from "../../models/dto/user-info.dto";
import { UserService } from "../../services/user-service";
import { kuikaCoreWasmBridgeService } from "../../services/_singletons";
import _ from "lodash";
import mqtt, { MqttClient } from "mqtt";
import { IMqttResult } from "../../models/dto/mqtt.dto";


declare let window: any;

export interface ITransferTalebiOlusturV2_ScreenProps {
  navigator: KNavigator;
  form: FormInstance<any>;
  googleLogin: any;
  screenInputs: any;
  context: KContext;
  initialValues: any;
  children: any;
}

export interface ITransferTalebiOlusturV2_ScreenState {
    isSpinnerVisible: boolean;
    isPageVisible: boolean;
	isLeftMenuVisible: boolean;
    spinnerCount: number;
    selectedLanguage: string;
    isPageInitLoaded: false;
    isPageRecurringLoaded: false;
	TM_ClearCurrentUserTransferBasket: any[];
	TM_ClearCurrentUserTransferBasket_dummy: any[];
	TM_GetCurrentUserTransferScope: any[];
	TM_GetCurrentUserTransferScope_dummy: any[];
	TM_GetTransferStoreOptions: any[];
	TM_GetTransferStoreOptions_dummy: any[];
	TM_SearchTransferProducts: any[];
	TM_SearchTransferProducts_dummy: any[];
	GoBack: any;
	GoBack_dummy: any;
	TM_GetSelectedProduct: any[];
	TM_GetSelectedProduct_dummy: any[];
	TM_GetProductAvailableStores: any[];
	TM_GetProductAvailableStores_dummy: any[];
	SetValueOf: any;
	SetValueOf_dummy: any;
	TM_AddTransferBasketItem: any[];
	TM_AddTransferBasketItem_dummy: any[];
	TM_GetTransferBasketItems: any[];
	TM_GetTransferBasketItems_dummy: any[];
	TM_UpdateTransferBasketItemNote: any[];
	TM_UpdateTransferBasketItemNote_dummy: any[];
	TM_RemoveTransferBasketItem: any[];
	TM_RemoveTransferBasketItem_dummy: any[];
	TM_CreateTransferRequest: any[];
	TM_CreateTransferRequest_dummy: any[];
	NAVIGATE: any;
	NAVIGATE_dummy: any;
	isComp73891Visible: 'visible' | 'hidden';
	isComp402447Visible: 'visible' | 'hidden';
	isComp872844Visible: 'visible' | 'hidden';
	isComp958267Visible: 'visible' | 'hidden';
	isComp52722Visible: 'visible' | 'hidden';
	isComp958267Enabled: 'enabled' | 'disabled';
	isComp711262595Enabled: 'enabled' | 'disabled';
	isComp1833032207Enabled: 'enabled' | 'disabled';
	isComp722236Enabled: 'enabled' | 'disabled';
	isComp449656Enabled: 'enabled' | 'disabled';
	isComp726863Enabled: 'enabled' | 'disabled';
	isComp535579Enabled: 'enabled' | 'disabled';

}

export class TransferTalebiOlusturV2_ScreenBase extends React.PureComponent<ITransferTalebiOlusturV2_ScreenProps, any> {

	transfertalebiolusturv2_402447_value_kuikaAutoCompleteRef: React.RefObject<any>;
	transfertalebiolusturv2_258368_value_kuikaSelectBoxRef: React.RefObject<any>;
	transfertalebiolusturv2_363435_value_kuikaTableRef: React.RefObject<any>;
	transfertalebiolusturv2_794147_value_kuikaTableRef: React.RefObject<any>;
    ml=[{"Id":"d5a61d2b-bd60-485f-86e2-661e9ed4e486","Name":"en_US","ShortName":"English","IsDefault":true,"LanguagePhrases":[]},{"Id":"774617bc-2e96-4505-9cec-65f2203c685b","Name":"FixedValues","ShortName":"FixedValues","LanguagePhrases":[{"Id":267307,"PropertyName":"value","Value":"Transfer Taleplerine Dön"},{"Id":936412,"PropertyName":"value","Value":"Transfer Talebi Oluştur"},{"Id":792775,"PropertyName":"value","Value":"Ürün ve talep edilecek mağazayı seçerek transfer talebini oluşturun."},{"Id":466103,"PropertyName":"value","Value":"Talep numarası gönderim sonrasında otomatik oluşturulacaktır."},{"Id":73891,"PropertyName":"value","Value":"Talep Eden Mağaza"},{"Id":402447,"PropertyName":"placeholder","Value":"Talep eden mağaza..."},{"Id":495148,"PropertyName":"value","Value":"Seri Numarasına Tabi Ürün Aratınız*"},{"Id":573645,"PropertyName":"placeholder","Value":"Ürün adıyla ara..."},{"Id":258368,"PropertyName":"placeholder","Value":"Arama sonucundan ürün seçiniz..."},{"Id":590719,"PropertyName":"value","Value":"Seçilen Ürün"},{"Id":523534,"PropertyName":"value","Value":"Kategori"},{"Id":239615,"PropertyName":"value","Value":"Ürün Adı"},{"Id":767945,"PropertyName":"value","Value":"Uygun Mağaza Stokları"},{"Id":476057,"PropertyName":"value","Value":"Merkez Mağaza dışında yalnız müsait stoğu bulunan mağazalar listelenir."},{"Id":1804232753,"PropertyName":"value","Value":"Merkez mağaza stok bilgisi görüntülenemez. Stok durumundan bağımsız olarak tüm ürünler için talep oluşturulabilir.*"},{"Id":363435,"PropertyName":"nodatafoundmessage","Value":"Uygun mağaza stoğu bulunamadı"},{"Id":958267,"PropertyName":"title","Value":"Seçilen Mağaza"},{"Id":854737,"PropertyName":"value","Value":"[datafield:requestingstorename]"},{"Id":944111015,"PropertyName":"placeholder","Value":"Type here..."},{"Id":711262595,"PropertyName":"title","Value":"Talep Edilen Mağaza"},{"Id":1763778522,"PropertyName":"value","Value":"[datafield:storename]"},{"Id":330511736,"PropertyName":"placeholder","Value":"Type here..."},{"Id":1833032207,"PropertyName":"title","Value":"Ürün"},{"Id":1147675259,"PropertyName":"value","Value":"[datafield:productname]"},{"Id":2053135781,"PropertyName":"placeholder","Value":"Type here..."},{"Id":722236,"PropertyName":"title","Value":"Toplam Stok"},{"Id":148840,"PropertyName":"value","Value":"[datafield:totalstock]"},{"Id":977763,"PropertyName":"placeholder","Value":"15"},{"Id":449656,"PropertyName":"title","Value":"Rezerv"},{"Id":842907,"PropertyName":"value","Value":"[datafield:reservationqty]"},{"Id":357397,"PropertyName":"placeholder","Value":"15"},{"Id":726863,"PropertyName":"title","Value":"Transfer Bekleyen"},{"Id":131179,"PropertyName":"value","Value":"[datafield:transferwaitingqty]"},{"Id":2129008198,"PropertyName":"placeholder","Value":"15"},{"Id":535579,"PropertyName":"title","Value":"Müsait Stok"},{"Id":997659,"PropertyName":"value","Value":"[datafield:availableqty]"},{"Id":622412265,"PropertyName":"placeholder","Value":"15"},{"Id":775106,"PropertyName":"title","Value":"İşlem"},{"Id":911365,"PropertyName":"label","Value":"Ekle"},{"Id":617720725,"PropertyName":"title","Value":"Title"},{"Id":303104,"PropertyName":"value","Value":"Talep Eden Mağaza"},{"Id":525006,"PropertyName":"value","Value":"[datafield:requestingstorename]"},{"Id":1520777378,"PropertyName":"value","Value":"Talep Edilen Mağaza"},{"Id":1023806922,"PropertyName":"value","Value":"[datafield:sourcestorename]"},{"Id":314877759,"PropertyName":"value","Value":"Ürün"},{"Id":271782839,"PropertyName":"value","Value":"[datafield:productname]"},{"Id":13333,"PropertyName":"label","Value":"Seçimi Bırak"},{"Id":246648,"PropertyName":"value","Value":"Talep miktarı sistem tarafından 1 adet olarak oluşturulur."},{"Id":467413,"PropertyName":"value","Value":"Talep Notu *"},{"Id":492378,"PropertyName":"placeholder","Value":"Talep gerekçesini veya açıklamanızı girin"},{"Id":743374,"PropertyName":"value","Value":"0 / 1000"},{"Id":100210,"PropertyName":"label","Value":"Vazgeç"},{"Id":192785,"PropertyName":"label","Value":"Transfer Talebi Oluştur"}]}]
    defaultML = "en_US"
    
    screenHash = ""
    


    constructor(props) {
        super(props);
		this.transfertalebiolusturv2_402447_value_kuikaAutoCompleteRef = React.createRef();
		this.transfertalebiolusturv2_573645_value_kuikaTextInputRef = React.createRef();
		this.transfertalebiolusturv2_258368_value_kuikaSelectBoxRef = React.createRef();
		this.transfertalebiolusturv2_363435_value_kuikaTableRef = React.createRef();
		this.transfertalebiolusturv2_944111015_value_kuikaTextInputRef = React.createRef();
		this.transfertalebiolusturv2_330511736_value_kuikaTextInputRef = React.createRef();
		this.transfertalebiolusturv2_2053135781_value_kuikaTextInputRef = React.createRef();
		this.transfertalebiolusturv2_794147_value_kuikaTableRef = React.createRef();

        this.state = {
            isSpinnerVisible: false,
            isPageVisible: false,
            isLeftMenuVisible: false,
            spinnerCount: 0,
            selectedLanguage: "",
            isPageInitLoaded: false,
            isPageRecurringLoaded: false,
            	        TM_ClearCurrentUserTransferBasket: [],
	        TM_GetCurrentUserTransferScope: [],
	        TM_GetTransferStoreOptions: [],
	        TM_SearchTransferProducts: [],
	        GoBack: "",
	        TM_GetSelectedProduct: [],
	        TM_GetProductAvailableStores: [],
	        SetValueOf: "",
	        TM_AddTransferBasketItem: [],
	        TM_GetTransferBasketItems: [],
	        TM_UpdateTransferBasketItemNote: [],
	        TM_RemoveTransferBasketItem: [],
	        TM_CreateTransferRequest: [],
	        NAVIGATE: "",
	        isComp73891Visible: 'hidden',
	        isComp402447Visible: 'hidden',
	        isComp872844Visible: 'hidden',
	        isComp958267Visible: 'hidden',
	        isComp52722Visible: 'hidden',
	        isComp958267Enabled: 'disabled',
	        isComp711262595Enabled: 'disabled',
	        isComp1833032207Enabled: 'disabled',
	        isComp722236Enabled: 'disabled',
	        isComp449656Enabled: 'disabled',
	        isComp726863Enabled: 'disabled',
	        isComp535579Enabled: 'disabled',

        }

        this.state.isPageVisible = true;
        
    }

    async componentDidMount() {

        if (KuikaAppManager.isPageInitPrevented()) {
            KuikaAppManager.calculateAndSetBodyHeight("transfertalebiolusturv2", "");
            return;
        }
        
        
        ReactSystemFunctions.validateToken()
        this.fillFormInitValues();
        if (true){
            await this.TransferTalebiOlusturV2PageInit();
        }
        
        
        
        KuikaAppManager.calculateAndSetBodyHeight("transfertalebiolusturv2", "");

        if (ReactSystemFunctions.getIsMicroApp() === false) {
           window.parentScreen = this;
        }
    }

    componentWillUnmount() {
        
        
        

        if (ReactSystemFunctions.getIsMicroApp() === false) {
           window.parentScreen = null;
        }
    }

    

        
    componentDidUpdate= async (prevProps, prevState) => {
		KuikaAppManager.calculateAndSetBodyHeight("transfertalebiolusturv2", ""    );
        if (prevProps?.location?.search !== (this.props as any)?.location?.search) {
			await this.TransferTalebiOlusturV2PageInit();
		}

        

        if (ReactSystemFunctions.getIsMicroApp() === false) {
            for (const key in prevState) {
                if (key.startsWith('NavVisible') && prevState[key] === true && this.state[key] === false) {
                    window.parentScreen = this;
                    break;
                }
            }
        }
	}

    fillFormInitValues() {
        this.props.form?.setFieldsValue({
transfertalebiolusturv2_402447_value: this.state.TM_GetCurrentUserTransferScope?.at?.(0)?.physicalStoreId ?? undefined
});

    }

      setPageInitLoaded = (value: boolean) => {
        this.setState({ isPageInitLoaded: value });
      }

      setPageRecurringLoaded = (value: boolean) => {
        this.setState({ isPageRecurringLoaded: value });
      }

      clearFieldValidation = (changedValues: any) => {
        const fieldName = Object.keys(changedValues)[0];
        if (fieldName) {
          this.props.form?.setFields([
            {
              name: fieldName,
              errors: []
            }
          ]);
        }
      };

      

    TransferTalebiOlusturV2PageInit = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


	if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }

        let localVar = {
			CurrentUsername_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.getMyUsername(), "string"),
			CurrentUsername_1: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.getMyUsername(), "string"),
			SearchText_3: ReactSystemFunctions.convertToTypeByName(null, "string"),
			PageSize_3: ReactSystemFunctions.convertToTypeByName(25, "number")
        }

	KuikaAppManager.showSpinner(this);
	
        if (true) {
        KuikaAppManager.showSpinner(this);
        }
        let result = await KuikaAppManager.ApiRequest(this, "TransferTalebiOlusturV2/TransferTalebiOlusturV2PageInit", localVar)
        if (!KMainFunctions.IsResStatus2XX(result)) return true;

		stateVars.TM_ClearCurrentUserTransferBasket = result?.data.tM_ClearCurrentUserTransferBasket;
		stateVars.TM_GetCurrentUserTransferScope = result?.data.tM_GetCurrentUserTransferScope;
		formVars.transfertalebiolusturv2_402447_value = (stateVars.TM_GetCurrentUserTransferScope !== undefined ? (stateVars.TM_GetCurrentUserTransferScope?.length > 0 ? stateVars.TM_GetCurrentUserTransferScope[0].physicalStoreId : null) : (this.state.TM_GetCurrentUserTransferScope?.length > 0 ? this.state.TM_GetCurrentUserTransferScope[0].physicalStoreId : null));
		formVars.transfertalebiolusturv2_402447_options = stateVars.TM_GetTransferStoreOptions;
		stateVars.isComp73891Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, (stateVars.TM_GetCurrentUserTransferScope !== undefined ? (stateVars.TM_GetCurrentUserTransferScope?.length > 0 ? stateVars.TM_GetCurrentUserTransferScope[0].isUpperManager : null) : (this.state.TM_GetCurrentUserTransferScope?.length > 0 ? this.state.TM_GetCurrentUserTransferScope[0].isUpperManager : null))), ReactSystemFunctions.convertToTypeByName("True", "string"))) === true ? "visible" : "hidden")
		stateVars.isComp402447Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, (stateVars.TM_GetCurrentUserTransferScope !== undefined ? (stateVars.TM_GetCurrentUserTransferScope?.length > 0 ? stateVars.TM_GetCurrentUserTransferScope[0].isUpperManager : null) : (this.state.TM_GetCurrentUserTransferScope?.length > 0 ? this.state.TM_GetCurrentUserTransferScope[0].isUpperManager : null))), ReactSystemFunctions.convertToTypeByName("True", "string"))) === true ? "visible" : "hidden")
		stateVars.isComp958267Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, (stateVars.TM_GetCurrentUserTransferScope !== undefined ? (stateVars.TM_GetCurrentUserTransferScope?.length > 0 ? stateVars.TM_GetCurrentUserTransferScope[0].isUpperManager : null) : (this.state.TM_GetCurrentUserTransferScope?.length > 0 ? this.state.TM_GetCurrentUserTransferScope[0].isUpperManager : null))), ReactSystemFunctions.convertToTypeByName("True", "string"))) === true ? "visible" : "hidden")
		stateVars.TM_GetTransferStoreOptions = result?.data.tM_GetTransferStoreOptions;
		
		formVars.transfertalebiolusturv2_402447_value = (stateVars.TM_GetCurrentUserTransferScope !== undefined ? (stateVars.TM_GetCurrentUserTransferScope?.length > 0 ? stateVars.TM_GetCurrentUserTransferScope[0].physicalStoreId : null) : (this.state.TM_GetCurrentUserTransferScope?.length > 0 ? this.state.TM_GetCurrentUserTransferScope[0].physicalStoreId : null));
		formVars.transfertalebiolusturv2_402447_options = stateVars.TM_GetTransferStoreOptions;
		stateVars.TM_SearchTransferProducts = result?.data.tM_SearchTransferProducts;
		
		formVars.transfertalebiolusturv2_258368_options = stateVars.TM_SearchTransferProducts;
		this.props.form?.setFieldsValue(formVars);
		
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.TransferTalebiOlusturV2PageInit1_();
                  resolve();
                });
          })



        
        KuikaAppManager.hideSpinner(this);
        return isErrorOccurred;
    }
	TransferTalebiOlusturV2PageInit1_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


	if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }

			stateVars.isComp73891Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, (stateVars.TM_GetCurrentUserTransferScope !== undefined ? (stateVars.TM_GetCurrentUserTransferScope?.length > 0 ? stateVars.TM_GetCurrentUserTransferScope[0].isUpperManager : null) : (this.state.TM_GetCurrentUserTransferScope?.length > 0 ? this.state.TM_GetCurrentUserTransferScope[0].isUpperManager : null))), ReactSystemFunctions.convertToTypeByName("True", "string"))) === true ? "visible" : "hidden")
			formVars.transfertalebiolusturv2_402447_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetCurrentUserTransferScope !== undefined ? (stateVars.TM_GetCurrentUserTransferScope?.length > 0 ? stateVars.TM_GetCurrentUserTransferScope[0].physicalStoreId : null) : (this.state.TM_GetCurrentUserTransferScope?.length > 0 ? this.state.TM_GetCurrentUserTransferScope[0].physicalStoreId : null)));

			
			stateVars.dataSource_402447 = stateVars.TM_GetTransferStoreOptions ?? this.state.TM_GetTransferStoreOptions;
			stateVars.dataSource_402447 = stateVars.TM_GetTransferStoreOptions ?? this.state.TM_GetTransferStoreOptions;
			stateVars.isComp402447Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, (stateVars.TM_GetCurrentUserTransferScope !== undefined ? (stateVars.TM_GetCurrentUserTransferScope?.length > 0 ? stateVars.TM_GetCurrentUserTransferScope[0].isUpperManager : null) : (this.state.TM_GetCurrentUserTransferScope?.length > 0 ? this.state.TM_GetCurrentUserTransferScope[0].isUpperManager : null))), ReactSystemFunctions.convertToTypeByName("True", "string"))) === true ? "visible" : "hidden")
			
			stateVars.dataSource_258368 = stateVars.TM_SearchTransferProducts ?? this.state.TM_SearchTransferProducts;
			stateVars.dataSource_258368 = stateVars.TM_SearchTransferProducts ?? this.state.TM_SearchTransferProducts;
			stateVars.isComp872844Visible = ((ReactSystemFunctions.isNotEmpty(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "transfertalebiolusturv2_258368_value", "value", "TM_SearchTransferProducts", "productId", "productId")), ReactSystemFunctions.convertToTypeByName("True", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp958267Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, (stateVars.TM_GetCurrentUserTransferScope !== undefined ? (stateVars.TM_GetCurrentUserTransferScope?.length > 0 ? stateVars.TM_GetCurrentUserTransferScope[0].isUpperManager : null) : (this.state.TM_GetCurrentUserTransferScope?.length > 0 ? this.state.TM_GetCurrentUserTransferScope[0].isUpperManager : null))), ReactSystemFunctions.convertToTypeByName("True", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp52722Visible = ((ReactSystemFunctions.isNotEmpty(ReactSystemFunctions.value(this, (stateVars.TM_GetTransferBasketItems !== undefined ? (stateVars.TM_GetTransferBasketItems?.length > 0 ? stateVars.TM_GetTransferBasketItems[0].basketItemId : null) : (this.state.TM_GetTransferBasketItems?.length > 0 ? this.state.TM_GetTransferBasketItems[0].basketItemId : null))), ReactSystemFunctions.convertToTypeByName("True", "string"))) === true ? "visible" : "hidden")

	this.props.form?.setFieldsValue(formVars);
	this.setState(stateVars);
	KuikaAppManager.hideSpinner(this);

            this.setPageInitLoaded(true);
            return isErrorOccurred;
        }




		TransferTalebiOlusturV2Component_540030_onClick = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
KuikaAppManager.showSpinner(this);

				stateVars.GoBack = await ReactSystemFunctions.goBack(this, false);

		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

            
            return isErrorOccurred;
        }


		TransferTalebiOlusturV2Component_267307_onClick = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
KuikaAppManager.showSpinner(this);

				stateVars.GoBack = await ReactSystemFunctions.goBack(this, false);

		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

            
            return isErrorOccurred;
        }


    TransferTalebiOlusturV2Component_573645_onChange = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
		KuikaAppManager.increaseServerRequestCount();

        let localVar = {
				SearchText_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "transfertalebiolusturv2_573645_value", "value", "", "", "")), "string"),
				PageSize_0: ReactSystemFunctions.convertToTypeByName(25, "number")
        }

		KuikaAppManager.showSpinner(this);
		
        if (true) {
        KuikaAppManager.showSpinner(this);
        }
        let result = await KuikaAppManager.ApiRequest(this, "TransferTalebiOlusturV2/TransferTalebiOlusturV2Component_573645_onChange", localVar)
        if (!KMainFunctions.IsResStatus2XX(result)) return true;

			stateVars.TM_SearchTransferProducts = result?.data.tM_SearchTransferProducts;
			
			formVars.transfertalebiolusturv2_258368_options = stateVars.TM_SearchTransferProducts;
			this.props.form?.setFieldsValue(formVars);
			
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.TransferTalebiOlusturV2Component_573645_onChange1_();
                  resolve();
                });
          })



        
        KuikaAppManager.hideSpinner(this);
        return isErrorOccurred;
    }
		TransferTalebiOlusturV2Component_573645_onChange1_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }

				
				stateVars.dataSource_258368 = stateVars.TM_SearchTransferProducts ?? this.state.TM_SearchTransferProducts;
				stateVars.dataSource_258368 = stateVars.TM_SearchTransferProducts ?? this.state.TM_SearchTransferProducts;

		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

            
            return isErrorOccurred;
        }




    TransferTalebiOlusturV2Component_258368_onChange = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
		KuikaAppManager.increaseServerRequestCount();

        let localVar = {
				ProductId_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "transfertalebiolusturv2_258368_value", "value", "TM_SearchTransferProducts", "productId", "productId")), "Guid"),
				CurrentUsername_1: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.getMyUsername(), "string"),
				SelectedRequestingStoreId_1: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "transfertalebiolusturv2_402447_value", "value", "TM_GetTransferStoreOptions", "id", "id")), "Guid"),
				ProductId_1: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "transfertalebiolusturv2_258368_value", "value", "TM_SearchTransferProducts", "productId", "productId")), "Guid")
        }

		KuikaAppManager.showSpinner(this);
		
        if (true) {
        KuikaAppManager.showSpinner(this);
        }
        let result = await KuikaAppManager.ApiRequest(this, "TransferTalebiOlusturV2/TransferTalebiOlusturV2Component_258368_onChange", localVar)
        if (!KMainFunctions.IsResStatus2XX(result)) return true;

			stateVars.TM_GetSelectedProduct = result?.data.tM_GetSelectedProduct;
			formVars.transfertalebiolusturv2_939408_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetSelectedProduct !== undefined ? (stateVars.TM_GetSelectedProduct?.length > 0 ? stateVars.TM_GetSelectedProduct[0].productCategory : null) : (this.state.TM_GetSelectedProduct?.length > 0 ? this.state.TM_GetSelectedProduct[0].productCategory : null)));
			formVars.transfertalebiolusturv2_565602_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetSelectedProduct !== undefined ? (stateVars.TM_GetSelectedProduct?.length > 0 ? stateVars.TM_GetSelectedProduct[0].productName : null) : (this.state.TM_GetSelectedProduct?.length > 0 ? this.state.TM_GetSelectedProduct[0].productName : null)));
			stateVars.TM_GetProductAvailableStores = result?.data.tM_GetProductAvailableStores;
			
			this.props.form?.setFieldsValue(formVars);
			
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.TransferTalebiOlusturV2Component_258368_onChange1_();
                  resolve();
                });
          })



        
        KuikaAppManager.hideSpinner(this);
        return isErrorOccurred;
    }
		TransferTalebiOlusturV2Component_258368_onChange1_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }

				stateVars.SetValueOf = await ReactSystemFunctions.setValueOf(this, ReactSystemFunctions.convertToTypeByName("transfertalebiolusturv2_573645_value", "string"), "", null, false);
				stateVars.isComp872844Visible = ((ReactSystemFunctions.isNotEmpty(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "transfertalebiolusturv2_258368_value", "value", "TM_SearchTransferProducts", "productId", "productId")), true)) === true ? "visible" : "hidden")
				formVars.transfertalebiolusturv2_939408_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetSelectedProduct !== undefined ? (stateVars.TM_GetSelectedProduct?.length > 0 ? stateVars.TM_GetSelectedProduct[0].productCategory : null) : (this.state.TM_GetSelectedProduct?.length > 0 ? this.state.TM_GetSelectedProduct[0].productCategory : null)));

				formVars.transfertalebiolusturv2_565602_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetSelectedProduct !== undefined ? (stateVars.TM_GetSelectedProduct?.length > 0 ? stateVars.TM_GetSelectedProduct[0].productName : null) : (this.state.TM_GetSelectedProduct?.length > 0 ? this.state.TM_GetSelectedProduct[0].productName : null)));

				
				stateVars.dataSource_363435 = stateVars.TM_GetProductAvailableStores ?? this.state.TM_GetProductAvailableStores;

		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

            
            return isErrorOccurred;
        }




    TransferTalebiOlusturV2Component_911365_onClick = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
		KuikaAppManager.increaseServerRequestCount();

        let localVar = {
				CurrentKUserId_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, (stateVars.TM_GetCurrentUserTransferScope !== undefined ? (stateVars.TM_GetCurrentUserTransferScope?.length > 0 ? stateVars.TM_GetCurrentUserTransferScope[0].kUserId : null) : (this.state.TM_GetCurrentUserTransferScope?.length > 0 ? this.state.TM_GetCurrentUserTransferScope[0].kUserId : null))), "Guid"),
				SelectedRequestingStoreId_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "transfertalebiolusturv2_402447_value", "value", "TM_GetTransferStoreOptions", "id", "id")), "Guid"),
				SourceStoreId_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, "transfertalebiolusturv2_363435_value", "storeId"), "Guid"),
				ProductId_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, "transfertalebiolusturv2_363435_value", "productId"), "Guid"),
				CurrentUsername_1: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.getMyUsername(), "string")
        }

		KuikaAppManager.showSpinner(this);
		
        if (true) {
        KuikaAppManager.showSpinner(this);
        }
        let result = await KuikaAppManager.ApiRequest(this, "TransferTalebiOlusturV2/TransferTalebiOlusturV2Component_911365_onClick", localVar)
        if (!KMainFunctions.IsResStatus2XX(result)) return true;

			stateVars.TM_AddTransferBasketItem = result?.data.tM_AddTransferBasketItem;
			stateVars.TM_GetTransferBasketItems = result?.data.tM_GetTransferBasketItems;
			
			stateVars.isComp52722Visible = ((ReactSystemFunctions.isNotEmpty(ReactSystemFunctions.value(this, (stateVars.TM_GetTransferBasketItems !== undefined ? (stateVars.TM_GetTransferBasketItems?.length > 0 ? stateVars.TM_GetTransferBasketItems[0].basketItemId : null) : (this.state.TM_GetTransferBasketItems?.length > 0 ? this.state.TM_GetTransferBasketItems[0].basketItemId : null))), ReactSystemFunctions.convertToTypeByName("True", "string"))) === true ? "visible" : "hidden")
			this.props.form?.setFieldsValue(formVars);
			
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.TransferTalebiOlusturV2Component_911365_onClick1_();
                  resolve();
                });
          })



        
        KuikaAppManager.hideSpinner(this);
        return isErrorOccurred;
    }
		TransferTalebiOlusturV2Component_911365_onClick1_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }

				
				stateVars.dataSource_794147 = stateVars.TM_GetTransferBasketItems ?? this.state.TM_GetTransferBasketItems;

		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

            
            return isErrorOccurred;
        }




    TransferTalebiOlusturV2Component_794147_onRowEditFinished = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
		KuikaAppManager.increaseServerRequestCount();

        let localVar = {
				BasketItemId_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, (stateVars.TM_GetTransferBasketItems !== undefined ? (stateVars.TM_GetTransferBasketItems?.length > 0 ? stateVars.TM_GetTransferBasketItems[0].basketItemId : null) : (this.state.TM_GetTransferBasketItems?.length > 0 ? this.state.TM_GetTransferBasketItems[0].basketItemId : null))), "Guid"),
				CurrentUsername_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.getMyUsername(), "string"),
				Note_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, (stateVars.TM_GetTransferBasketItems !== undefined ? (stateVars.TM_GetTransferBasketItems?.length > 0 ? stateVars.TM_GetTransferBasketItems[0].note : null) : (this.state.TM_GetTransferBasketItems?.length > 0 ? this.state.TM_GetTransferBasketItems[0].note : null))), "string")
        }

		KuikaAppManager.showSpinner(this);
		
        if (true) {
        KuikaAppManager.showSpinner(this);
        }
        let result = await KuikaAppManager.ApiRequest(this, "TransferTalebiOlusturV2/TransferTalebiOlusturV2Component_794147_onRowEditFinished", localVar)
        if (!KMainFunctions.IsResStatus2XX(result)) return true;

			stateVars.TM_UpdateTransferBasketItemNote = result?.data.tM_UpdateTransferBasketItemNote;
			this.props.form?.setFieldsValue(formVars);
			this.setState(stateVars);
			KuikaAppManager.hideSpinner(this);



        this.setPageInitLoaded(true);
        KuikaAppManager.hideSpinner(this);
        return isErrorOccurred;
    }



    TransferTalebiOlusturV2Component_13333_onClick = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
		KuikaAppManager.increaseServerRequestCount();

        let localVar = {
				CurrentUsername_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.getMyUsername(), "string"),
				BasketItemId_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, "transfertalebiolusturv2_794147_value", "basketItemId"), "Guid"),
				CurrentUsername_1: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.getMyUsername(), "string")
        }

		KuikaAppManager.showSpinner(this);
		
        if (true) {
        KuikaAppManager.showSpinner(this);
        }
        let result = await KuikaAppManager.ApiRequest(this, "TransferTalebiOlusturV2/TransferTalebiOlusturV2Component_13333_onClick", localVar)
        if (!KMainFunctions.IsResStatus2XX(result)) return true;

			stateVars.TM_RemoveTransferBasketItem = result?.data.tM_RemoveTransferBasketItem;
			stateVars.TM_GetTransferBasketItems = result?.data.tM_GetTransferBasketItems;
			
			stateVars.isComp52722Visible = ((ReactSystemFunctions.isNotEmpty(ReactSystemFunctions.value(this, (stateVars.TM_GetTransferBasketItems !== undefined ? (stateVars.TM_GetTransferBasketItems?.length > 0 ? stateVars.TM_GetTransferBasketItems[0].basketItemId : null) : (this.state.TM_GetTransferBasketItems?.length > 0 ? this.state.TM_GetTransferBasketItems[0].basketItemId : null))), ReactSystemFunctions.convertToTypeByName("True", "string"))) === true ? "visible" : "hidden")
			this.props.form?.setFieldsValue(formVars);
			
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.TransferTalebiOlusturV2Component_13333_onClick1_();
                  resolve();
                });
          })



        
        KuikaAppManager.hideSpinner(this);
        return isErrorOccurred;
    }
		TransferTalebiOlusturV2Component_13333_onClick1_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }

				
				stateVars.dataSource_794147 = stateVars.TM_GetTransferBasketItems ?? this.state.TM_GetTransferBasketItems;

		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

            
            return isErrorOccurred;
        }




		TransferTalebiOlusturV2Component_100210_onClick = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
KuikaAppManager.showSpinner(this);

				stateVars.GoBack = await ReactSystemFunctions.goBack(this, false);

		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

            
            return isErrorOccurred;
        }


    TransferTalebiOlusturV2Component_192785_onClick = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
		KuikaAppManager.increaseServerRequestCount();

        let localVar = {
				CurrentUsername_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.getMyUsername(), "string"),
				SelectedRequestingStoreId_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "transfertalebiolusturv2_402447_value", "value", "TM_GetTransferStoreOptions", "id", "id")), "Guid"),
				RequestNote_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "transfertalebiolusturv2_492378_value", "value", "", "", "")), "string")
        }

		KuikaAppManager.showSpinner(this);
		
        if (true) {
        KuikaAppManager.showSpinner(this);
        }
        let result = await KuikaAppManager.ApiRequest(this, "TransferTalebiOlusturV2/TransferTalebiOlusturV2Component_192785_onClick", localVar)
        if (!KMainFunctions.IsResStatus2XX(result)) return true;

			stateVars.TM_CreateTransferRequest = result?.data.tM_CreateTransferRequest;
			this.props.form?.setFieldsValue(formVars);
			
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.TransferTalebiOlusturV2Component_192785_onClick1_();
                  resolve();
                });
          })



        
        KuikaAppManager.hideSpinner(this);
        return isErrorOccurred;
    }
		TransferTalebiOlusturV2Component_192785_onClick1_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
if (ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, (stateVars.TM_CreateTransferRequest !== undefined ? (stateVars.TM_CreateTransferRequest?.length > 0 ? stateVars.TM_CreateTransferRequest[0].isSuccess : null) : (this.state.TM_CreateTransferRequest?.length > 0 ? this.state.TM_CreateTransferRequest[0].isSuccess : null))), true)) {
            
					KuikaAppManager.prepareForNavigation();

				stateVars.NAVIGATE = await ReactSystemFunctions.navigate(this, undefined, "TransferTalebiOlusturV2", "TransferTalepleri", "", "currentPage", null, null, null, null, null, null, true, false);

		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

        } else {
            KuikaAppManager.hideSpinner(this);
        }

            
            return isErrorOccurred;
        }






    async callCallbackFunction(diId: number, isFromMaster: boolean = false) {
        let isErrorOccurred = false;
		let pageInitCallerNavDiIDs = [] as number[];
		if (isFromMaster || pageInitCallerNavDiIDs.indexOf(diId) > -1) {
			await this.TransferTalebiOlusturV2PageInit();
		}

    }


}
