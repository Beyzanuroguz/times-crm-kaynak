import React from "react";
import Axios, { AxiosResponse } from "axios";
import { KuikaAppManager } from "../../shared/utilty/kuika-app-manager";
import { ReactSystemFunctions } from "../../shared/utilty/react-system-functions";
import { HtmlA4Printer } from "../../shared/utilty/js-actions/HtmlA4Printer";
import { KNavigator } from "../../shared/hoc/with-history";
import { KContext } from "../../shared/hoc/with-context";
import { useLocation } from "react-router-dom";
import { FormInstance } from "antd/es/form";
import { Guid } from "guid-typescript";
import Swal from "sweetalert2";
import { KMainFunctions } from "../../shared/utilty/main-functions";
import moment from "moment";
import { IValidationData } from "../../models/dto/validation-data";
import { IStripePayment } from "../../models/dto/stripe-payment";
import { IUserInfoDto } from "../../models/dto/user-info.dto";
import { UserService } from "../../services/user-service";
import { kuikaCoreWasmBridgeService } from "../../services/_singletons";
import _ from "lodash";
import mqtt, { MqttClient } from "mqtt";
import { IMqttResult } from "../../models/dto/mqtt.dto";


declare let window: any;

export interface ITransferFisiDetayi_ScreenProps {
  navigator: KNavigator;
  form: FormInstance<any>;
  googleLogin: any;
  screenInputs: any;
  context: KContext;
  initialValues: any;
  children: any;
}

export interface ITransferFisiDetayi_ScreenState {
    isSpinnerVisible: boolean;
    isPageVisible: boolean;
	isLeftMenuVisible: boolean;
    spinnerCount: number;
    selectedLanguage: string;
    isPageInitLoaded: false;
    isPageRecurringLoaded: false;
	TM_GetTransferERPDetail: any[];
	TM_GetTransferERPDetail_dummy: any[];
	GoBack: any;
	GoBack_dummy: any;
	GetBase64Sql: any[];
	GetBase64Sql_dummy: any[];
	Decode: string;
	Decode_dummy: string;
	Open: string;
	Open_dummy: string;
	NAVIGATE: any;
	NAVIGATE_dummy: any;
	Kuika_EShipmentSerialNumberPrefix: any[];
	Kuika_EShipmentSerialNumberPrefix_dummy: any[];
	SendEShipment: any;
	SendEShipment_dummy: any;
	TMTransferApprovePostAfterSql: any[];
	TMTransferApprovePostAfterSql_dummy: any[];
	Notify: boolean;
	Notify_dummy: boolean;
	TriggerEvent: string;
	TriggerEvent_dummy: string;
	isComp1917891487Visible: 'visible' | 'hidden';
	isComp501754Visible: 'visible' | 'hidden';
	isComp836453Visible: 'visible' | 'hidden';
	isComp277639029Visible: 'visible' | 'hidden';
	isComp245724Visible: 'visible' | 'hidden';
	isComp838692Visible: 'visible' | 'hidden';
	isComp246330Visible: 'visible' | 'hidden';
	isComp967515Visible: 'visible' | 'hidden';
	isComp854845Visible: 'visible' | 'hidden';
	isComp155856Visible: 'visible' | 'hidden';
	isComp57799Visible: 'visible' | 'hidden';
	isComp605410Visible: 'visible' | 'hidden';

}

export class TransferFisiDetayi_ScreenBase extends React.PureComponent<ITransferFisiDetayi_ScreenProps, any> {


    ml=[{"Id":"d5a61d2b-bd60-485f-86e2-661e9ed4e486","Name":"en_US","ShortName":"English","IsDefault":true,"LanguagePhrases":[]},{"Id":"e916fc35-66a6-4823-b1ab-d1ffe0308f7f","Name":"FixedValues","ShortName":"FixedValues","LanguagePhrases":[{"Id":161228,"PropertyName":"label","Value":"Transfer Fişlerine Dön"},{"Id":86477,"PropertyName":"value","Value":"Transfer Fişi Detayı"},{"Id":483222,"PropertyName":"value","Value":"Transfer fişi, kargo, ürün ve kabul bilgilerini görüntüleyin."},{"Id":1917891487,"PropertyName":"label","Value":"PDF Görüntüle/İndir"},{"Id":501754,"PropertyName":"label","Value":"Kabul İşlemine Git"},{"Id":836453,"PropertyName":"label","Value":"Fiş Onayla"},{"Id":271798,"PropertyName":"value","Value":"Fiş No"},{"Id":59214,"PropertyName":"value","Value":"Durum"},{"Id":1610,"PropertyName":"value","Value":"Gönderen"},{"Id":409959,"PropertyName":"value","Value":"Alıcı"},{"Id":370922,"PropertyName":"value","Value":"Transfer Tarihi"},{"Id":82489,"PropertyName":"value","Value":"Talep No"},{"Id":855741,"PropertyName":"value","Value":"Seri No"},{"Id":1785351671,"PropertyName":"value","Value":"Toplam Ürün Adedi"},{"Id":1495714022,"PropertyName":"value","Value":"4"},{"Id":760200,"PropertyName":"tab","Value":"Genel Bilgiler"},{"Id":137850,"PropertyName":"value","Value":"Oluşturan"},{"Id":544217,"PropertyName":"value","Value":"Oluşturma Tarihi"},{"Id":324162,"PropertyName":"value","Value":"Gönderen"},{"Id":75682,"PropertyName":"value","Value":"Alıcı"},{"Id":705754,"PropertyName":"value","Value":"Transfer Tarihi"},{"Id":167419,"PropertyName":"value","Value":"Nebim Fiş No"},{"Id":441444,"PropertyName":"value","Value":"Takip Numarası"},{"Id":159902,"PropertyName":"value","Value":"YK123456789"},{"Id":906910,"PropertyName":"value","Value":"Kargo Firması"},{"Id":432912,"PropertyName":"value","Value":"Yurtiçi Kargo"},{"Id":383816,"PropertyName":"value","Value":"Fiş Notu"},{"Id":739943,"PropertyName":"value","Value":"Ürünler kontrol edilerek kargo firmasına teslim edilmiştir."},{"Id":798576,"PropertyName":"value","Value":"Son İşlemler"},{"Id":687158555,"PropertyName":"tab","Value":"Ürün Bilgileri"},{"Id":378532713,"PropertyName":"value","Value":"Talep No"},{"Id":353970001,"PropertyName":"value","Value":"Ürün"},{"Id":359907775,"PropertyName":"value","Value":"Ürün Kodu"},{"Id":786950895,"PropertyName":"value","Value":"Seri Numarası"},{"Id":37732753,"PropertyName":"value","Value":"Ürün Durumu"},{"Id":854845,"PropertyName":"tab","Value":"Dahil Edilen Talepler 2"},{"Id":155856,"PropertyName":"tab","Value":"Ürünler ve Seri Numaraları 4"},{"Id":57799,"PropertyName":"tab","Value":"Kargo / Nebim / PDF"},{"Id":605410,"PropertyName":"tab","Value":"İşlem Geçmişi 3"}]}]
    defaultML = "en_US"
    
    screenHash = ""
    


    constructor(props) {
        super(props);


        this.state = {
            isSpinnerVisible: false,
            isPageVisible: false,
            isLeftMenuVisible: false,
            spinnerCount: 0,
            selectedLanguage: "",
            isPageInitLoaded: false,
            isPageRecurringLoaded: false,
            	        TM_GetTransferERPDetail: [],
	        GoBack: "",
	        GetBase64Sql: [],
	        Decode: "",
	        Open: "",
	        NAVIGATE: "",
	        Kuika_EShipmentSerialNumberPrefix: [],
	        SendEShipment: "",
	        TMTransferApprovePostAfterSql: [],
	        Notify: false,
	        TriggerEvent: "",
	        isComp1917891487Visible: 'hidden',
	        isComp501754Visible: 'hidden',
	        isComp836453Visible: 'hidden',
	        isComp277639029Visible: 'hidden',
	        isComp245724Visible: 'hidden',
	        isComp838692Visible: 'hidden',
	        isComp246330Visible: 'hidden',
	        isComp967515Visible: 'hidden',
	        isComp854845Visible: 'hidden',
	        isComp155856Visible: 'hidden',
	        isComp57799Visible: 'hidden',
	        isComp605410Visible: 'hidden',

        }

        this.state.isPageVisible = true;
        
    }

    async componentDidMount() {

        if (KuikaAppManager.isPageInitPrevented()) {
            KuikaAppManager.calculateAndSetBodyHeight("transferfisidetayi", "");
            return;
        }
        
        
        ReactSystemFunctions.validateToken()
        this.fillFormInitValues();
        if (true){
            await this.TransferFisiDetayiPageInit();
        }
        
        
        
        KuikaAppManager.calculateAndSetBodyHeight("transferfisidetayi", "");

        if (ReactSystemFunctions.getIsMicroApp() === false) {
           window.parentScreen = this;
        }
    }

    componentWillUnmount() {
        
        
        

        if (ReactSystemFunctions.getIsMicroApp() === false) {
           window.parentScreen = null;
        }
    }

    

        
    componentDidUpdate= async (prevProps, prevState) => {
		KuikaAppManager.calculateAndSetBodyHeight("transferfisidetayi", ""    );
        if (prevProps?.location?.search !== (this.props as any)?.location?.search) {
			await this.TransferFisiDetayiPageInit();
		}

        

        if (ReactSystemFunctions.getIsMicroApp() === false) {
            for (const key in prevState) {
                if (key.startsWith('NavVisible') && prevState[key] === true && this.state[key] === false) {
                    window.parentScreen = this;
                    break;
                }
            }
        }
	}

    fillFormInitValues() {
        this.props.form?.setFieldsValue({
});

    }

      setPageInitLoaded = (value: boolean) => {
        this.setState({ isPageInitLoaded: value });
      }

      setPageRecurringLoaded = (value: boolean) => {
        this.setState({ isPageRecurringLoaded: value });
      }

      clearFieldValidation = (changedValues: any) => {
        const fieldName = Object.keys(changedValues)[0];
        if (fieldName) {
          this.props.form?.setFields([
            {
              name: fieldName,
              errors: []
            }
          ]);
        }
      };

        checkTabErrors = () => {
    document.querySelectorAll(".rc-tabs-tab").forEach((tab) => {
      (tab as HTMLElement).style.color = "";
    });

    const tabPanes = document.querySelectorAll(".rc-tabs-tabpane");
    const tabs = document.querySelectorAll(".rc-tabs-tab");

    tabPanes.forEach((tabPane, index) => {
      const uniquePaneId = `rc-tabs-tabpane-${index}`;
      if (!tabPane.hasAttribute("id")) {
        tabPane.setAttribute("id", uniquePaneId); 
      }

      const uniqueTabId = `rc-tabs-tab-${index}`;
      if (tabs[index]) {
        if (!tabs[index].hasAttribute("id")) {
          tabs[index].setAttribute("id", uniqueTabId); 
        }
        tabs[index].setAttribute("aria-controls", uniquePaneId);
      }
    });

    const errorElements = document.querySelectorAll(".rc-tabs .ant-form-item-explain-error");

    const tabsWithErrors = new Set<string>();

    errorElements.forEach((errorElement) => {
      const tabPane = errorElement.closest(".rc-tabs-tabpane");
      if (tabPane && tabPane.id) {
        tabsWithErrors.add(tabPane.id);
      }
    });

    tabsWithErrors.forEach((tabPaneId) => {
      const tab = document.querySelector(`.rc-tabs-tab[aria-controls="${tabPaneId}"]`);
      if (tab) {
        (tab as HTMLElement).style.color = "red"; 
      }
    });
  };

    TransferFisiDetayiPageInit = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


	if (KuikaAppManager.handleValidations(this, validations, this.checkTabErrors))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }

        let localVar = {
			CurrentUsername_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.getMyUsername(), "string"),
			TransferERPHeaderId_0: ReactSystemFunctions.convertToTypeByName(this.props.screenInputs.TransferERPHeaderId ?? this.props.screenInputs.transfererpheaderid, "Guid")
        }

	KuikaAppManager.showSpinner(this);
	
        if (true) {
        KuikaAppManager.showSpinner(this);
        }
        let result = await KuikaAppManager.ApiRequest(this, "TransferFisiDetayi/TransferFisiDetayiPageInit", localVar)
        if (!KMainFunctions.IsResStatus2XX(result)) return true;

		stateVars.TM_GetTransferERPDetail = result?.data.tM_GetTransferERPDetail;
		formVars.transferfisidetayi_833442_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetTransferERPDetail !== undefined ? (stateVars.TM_GetTransferERPDetail?.length > 0 ? stateVars.TM_GetTransferERPDetail[0].transferERPNumber : null) : (this.state.TM_GetTransferERPDetail?.length > 0 ? this.state.TM_GetTransferERPDetail[0].transferERPNumber : null)));
		formVars.transferfisidetayi_867218_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetTransferERPDetail !== undefined ? (stateVars.TM_GetTransferERPDetail?.length > 0 ? stateVars.TM_GetTransferERPDetail[0].transferERPStatusName : null) : (this.state.TM_GetTransferERPDetail?.length > 0 ? this.state.TM_GetTransferERPDetail[0].transferERPStatusName : null)));
		formVars.transferfisidetayi_754214_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetTransferERPDetail !== undefined ? (stateVars.TM_GetTransferERPDetail?.length > 0 ? stateVars.TM_GetTransferERPDetail[0].transferERPNumber : null) : (this.state.TM_GetTransferERPDetail?.length > 0 ? this.state.TM_GetTransferERPDetail[0].transferERPNumber : null)));
		formVars.transferfisidetayi_136546_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetTransferERPDetail !== undefined ? (stateVars.TM_GetTransferERPDetail?.length > 0 ? stateVars.TM_GetTransferERPDetail[0].transferERPStatusName : null) : (this.state.TM_GetTransferERPDetail?.length > 0 ? this.state.TM_GetTransferERPDetail[0].transferERPStatusName : null)));
		formVars.transferfisidetayi_53933_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetTransferERPDetail !== undefined ? (stateVars.TM_GetTransferERPDetail?.length > 0 ? stateVars.TM_GetTransferERPDetail[0].sourceStoreName : null) : (this.state.TM_GetTransferERPDetail?.length > 0 ? this.state.TM_GetTransferERPDetail[0].sourceStoreName : null)));
		formVars.transferfisidetayi_999536_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetTransferERPDetail !== undefined ? (stateVars.TM_GetTransferERPDetail?.length > 0 ? stateVars.TM_GetTransferERPDetail[0].destinationStoreName : null) : (this.state.TM_GetTransferERPDetail?.length > 0 ? this.state.TM_GetTransferERPDetail[0].destinationStoreName : null)));
		formVars.transferfisidetayi_894012_value = ReactSystemFunctions.value(this, (stateVars.TM_GetTransferERPDetail !== undefined ? (stateVars.TM_GetTransferERPDetail?.length > 0 ? stateVars.TM_GetTransferERPDetail[0].transferredAt : null) : (this.state.TM_GetTransferERPDetail?.length > 0 ? this.state.TM_GetTransferERPDetail[0].transferredAt : null)));
		formVars.transferfisidetayi_336432_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetTransferERPDetail !== undefined ? (stateVars.TM_GetTransferERPDetail?.length > 0 ? stateVars.TM_GetTransferERPDetail[0].requestNumber : null) : (this.state.TM_GetTransferERPDetail?.length > 0 ? this.state.TM_GetTransferERPDetail[0].requestNumber : null)));
		formVars.transferfisidetayi_589295_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetTransferERPDetail !== undefined ? (stateVars.TM_GetTransferERPDetail?.length > 0 ? stateVars.TM_GetTransferERPDetail[0].serialNumber : null) : (this.state.TM_GetTransferERPDetail?.length > 0 ? this.state.TM_GetTransferERPDetail[0].serialNumber : null)));
		formVars.transferfisidetayi_563033_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetTransferERPDetail !== undefined ? (stateVars.TM_GetTransferERPDetail?.length > 0 ? stateVars.TM_GetTransferERPDetail[0].createdByName : null) : (this.state.TM_GetTransferERPDetail?.length > 0 ? this.state.TM_GetTransferERPDetail[0].createdByName : null)));
		formVars.transferfisidetayi_106004_value = ReactSystemFunctions.value(this, (stateVars.TM_GetTransferERPDetail !== undefined ? (stateVars.TM_GetTransferERPDetail?.length > 0 ? stateVars.TM_GetTransferERPDetail[0].createdAt : null) : (this.state.TM_GetTransferERPDetail?.length > 0 ? this.state.TM_GetTransferERPDetail[0].createdAt : null)));
		formVars.transferfisidetayi_503983_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetTransferERPDetail !== undefined ? (stateVars.TM_GetTransferERPDetail?.length > 0 ? stateVars.TM_GetTransferERPDetail[0].sourceStoreName : null) : (this.state.TM_GetTransferERPDetail?.length > 0 ? this.state.TM_GetTransferERPDetail[0].sourceStoreName : null)));
		formVars.transferfisidetayi_472814_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetTransferERPDetail !== undefined ? (stateVars.TM_GetTransferERPDetail?.length > 0 ? stateVars.TM_GetTransferERPDetail[0].destinationStoreName : null) : (this.state.TM_GetTransferERPDetail?.length > 0 ? this.state.TM_GetTransferERPDetail[0].destinationStoreName : null)));
		formVars.transferfisidetayi_462847_value = ReactSystemFunctions.value(this, (stateVars.TM_GetTransferERPDetail !== undefined ? (stateVars.TM_GetTransferERPDetail?.length > 0 ? stateVars.TM_GetTransferERPDetail[0].transferredAt : null) : (this.state.TM_GetTransferERPDetail?.length > 0 ? this.state.TM_GetTransferERPDetail[0].transferredAt : null)));
		formVars.transferfisidetayi_733934_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetTransferERPDetail !== undefined ? (stateVars.TM_GetTransferERPDetail?.length > 0 ? stateVars.TM_GetTransferERPDetail[0].nebimShippingNumber : null) : (this.state.TM_GetTransferERPDetail?.length > 0 ? this.state.TM_GetTransferERPDetail[0].nebimShippingNumber : null)));
		formVars.transferfisidetayi_1276390993_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetTransferERPDetail !== undefined ? (stateVars.TM_GetTransferERPDetail?.length > 0 ? stateVars.TM_GetTransferERPDetail[0].requestNumber : null) : (this.state.TM_GetTransferERPDetail?.length > 0 ? this.state.TM_GetTransferERPDetail[0].requestNumber : null)));
		formVars.transferfisidetayi_392050841_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetTransferERPDetail !== undefined ? (stateVars.TM_GetTransferERPDetail?.length > 0 ? stateVars.TM_GetTransferERPDetail[0].productName : null) : (this.state.TM_GetTransferERPDetail?.length > 0 ? this.state.TM_GetTransferERPDetail[0].productName : null)));
		formVars.transferfisidetayi_1060286712_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetTransferERPDetail !== undefined ? (stateVars.TM_GetTransferERPDetail?.length > 0 ? stateVars.TM_GetTransferERPDetail[0].productCode : null) : (this.state.TM_GetTransferERPDetail?.length > 0 ? this.state.TM_GetTransferERPDetail[0].productCode : null)));
		formVars.transferfisidetayi_75661225_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetTransferERPDetail !== undefined ? (stateVars.TM_GetTransferERPDetail?.length > 0 ? stateVars.TM_GetTransferERPDetail[0].serialNumber : null) : (this.state.TM_GetTransferERPDetail?.length > 0 ? this.state.TM_GetTransferERPDetail[0].serialNumber : null)));
		formVars.transferfisidetayi_746791817_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetTransferERPDetail !== undefined ? (stateVars.TM_GetTransferERPDetail?.length > 0 ? stateVars.TM_GetTransferERPDetail[0].lineStatusName : null) : (this.state.TM_GetTransferERPDetail?.length > 0 ? this.state.TM_GetTransferERPDetail[0].lineStatusName : null)));
		stateVars.isComp1917891487Visible = (((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.toString(this, (stateVars.TM_GetTransferERPDetail !== undefined ? (stateVars.TM_GetTransferERPDetail?.length > 0 ? stateVars.TM_GetTransferERPDetail[0].transferERPStatusCode : null) : (this.state.TM_GetTransferERPDetail?.length > 0 ? this.state.TM_GetTransferERPDetail[0].transferERPStatusCode : null))), ReactSystemFunctions.convertToTypeByName("IN_TRANSIT", "string")) || ReactSystemFunctions.isEqualTo(ReactSystemFunctions.toString(this, (stateVars.TM_GetTransferERPDetail !== undefined ? (stateVars.TM_GetTransferERPDetail?.length > 0 ? stateVars.TM_GetTransferERPDetail[0].transferERPStatusCode : null) : (this.state.TM_GetTransferERPDetail?.length > 0 ? this.state.TM_GetTransferERPDetail[0].transferERPStatusCode : null))), ReactSystemFunctions.convertToTypeByName("COMPLETED", "string")))) === true ? "visible" : "hidden")
		stateVars.isComp501754Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, (stateVars.TM_GetTransferERPDetail !== undefined ? (stateVars.TM_GetTransferERPDetail?.length > 0 ? stateVars.TM_GetTransferERPDetail[0].canGoToAcceptance : null) : (this.state.TM_GetTransferERPDetail?.length > 0 ? this.state.TM_GetTransferERPDetail[0].canGoToAcceptance : null))), ReactSystemFunctions.convertToTypeByName("True", "string"))) === true ? "visible" : "hidden")
		stateVars.isComp836453Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, (stateVars.TM_GetTransferERPDetail !== undefined ? (stateVars.TM_GetTransferERPDetail?.length > 0 ? stateVars.TM_GetTransferERPDetail[0].canApproveSlip : null) : (this.state.TM_GetTransferERPDetail?.length > 0 ? this.state.TM_GetTransferERPDetail[0].canApproveSlip : null))), ReactSystemFunctions.convertToTypeByName("True", "string"))) === true ? "visible" : "hidden")
		this.props.form?.setFieldsValue(formVars);
		
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.TransferFisiDetayiPageInit1_();
                  resolve();
                });
          })



        
        KuikaAppManager.hideSpinner(this);
        return isErrorOccurred;
    }
	TransferFisiDetayiPageInit1_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


	if (KuikaAppManager.handleValidations(this, validations, this.checkTabErrors))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }

			formVars.transferfisidetayi_833442_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetTransferERPDetail !== undefined ? (stateVars.TM_GetTransferERPDetail?.length > 0 ? stateVars.TM_GetTransferERPDetail[0].transferERPNumber : null) : (this.state.TM_GetTransferERPDetail?.length > 0 ? this.state.TM_GetTransferERPDetail[0].transferERPNumber : null)));

			formVars.transferfisidetayi_867218_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetTransferERPDetail !== undefined ? (stateVars.TM_GetTransferERPDetail?.length > 0 ? stateVars.TM_GetTransferERPDetail[0].transferERPStatusName : null) : (this.state.TM_GetTransferERPDetail?.length > 0 ? this.state.TM_GetTransferERPDetail[0].transferERPStatusName : null)));

			stateVars.isComp1917891487Visible = (((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.toString(this, (stateVars.TM_GetTransferERPDetail !== undefined ? (stateVars.TM_GetTransferERPDetail?.length > 0 ? stateVars.TM_GetTransferERPDetail[0].transferERPStatusCode : null) : (this.state.TM_GetTransferERPDetail?.length > 0 ? this.state.TM_GetTransferERPDetail[0].transferERPStatusCode : null))), ReactSystemFunctions.convertToTypeByName("IN_TRANSIT", "string")) || ReactSystemFunctions.isEqualTo(ReactSystemFunctions.toString(this, (stateVars.TM_GetTransferERPDetail !== undefined ? (stateVars.TM_GetTransferERPDetail?.length > 0 ? stateVars.TM_GetTransferERPDetail[0].transferERPStatusCode : null) : (this.state.TM_GetTransferERPDetail?.length > 0 ? this.state.TM_GetTransferERPDetail[0].transferERPStatusCode : null))), ReactSystemFunctions.convertToTypeByName("COMPLETED", "string")))) === true ? "visible" : "hidden")
			stateVars.isComp501754Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, (stateVars.TM_GetTransferERPDetail !== undefined ? (stateVars.TM_GetTransferERPDetail?.length > 0 ? stateVars.TM_GetTransferERPDetail[0].canGoToAcceptance : null) : (this.state.TM_GetTransferERPDetail?.length > 0 ? this.state.TM_GetTransferERPDetail[0].canGoToAcceptance : null))), ReactSystemFunctions.convertToTypeByName("True", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp836453Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, (stateVars.TM_GetTransferERPDetail !== undefined ? (stateVars.TM_GetTransferERPDetail?.length > 0 ? stateVars.TM_GetTransferERPDetail[0].canApproveSlip : null) : (this.state.TM_GetTransferERPDetail?.length > 0 ? this.state.TM_GetTransferERPDetail[0].canApproveSlip : null))), ReactSystemFunctions.convertToTypeByName("True", "string"))) === true ? "visible" : "hidden")
			formVars.transferfisidetayi_754214_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetTransferERPDetail !== undefined ? (stateVars.TM_GetTransferERPDetail?.length > 0 ? stateVars.TM_GetTransferERPDetail[0].transferERPNumber : null) : (this.state.TM_GetTransferERPDetail?.length > 0 ? this.state.TM_GetTransferERPDetail[0].transferERPNumber : null)));

			formVars.transferfisidetayi_136546_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetTransferERPDetail !== undefined ? (stateVars.TM_GetTransferERPDetail?.length > 0 ? stateVars.TM_GetTransferERPDetail[0].transferERPStatusName : null) : (this.state.TM_GetTransferERPDetail?.length > 0 ? this.state.TM_GetTransferERPDetail[0].transferERPStatusName : null)));

			formVars.transferfisidetayi_53933_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetTransferERPDetail !== undefined ? (stateVars.TM_GetTransferERPDetail?.length > 0 ? stateVars.TM_GetTransferERPDetail[0].sourceStoreName : null) : (this.state.TM_GetTransferERPDetail?.length > 0 ? this.state.TM_GetTransferERPDetail[0].sourceStoreName : null)));

			formVars.transferfisidetayi_999536_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetTransferERPDetail !== undefined ? (stateVars.TM_GetTransferERPDetail?.length > 0 ? stateVars.TM_GetTransferERPDetail[0].destinationStoreName : null) : (this.state.TM_GetTransferERPDetail?.length > 0 ? this.state.TM_GetTransferERPDetail[0].destinationStoreName : null)));

			formVars.transferfisidetayi_894012_value = ReactSystemFunctions.value(this, (stateVars.TM_GetTransferERPDetail !== undefined ? (stateVars.TM_GetTransferERPDetail?.length > 0 ? stateVars.TM_GetTransferERPDetail[0].transferredAt : null) : (this.state.TM_GetTransferERPDetail?.length > 0 ? this.state.TM_GetTransferERPDetail[0].transferredAt : null)));

			formVars.transferfisidetayi_336432_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetTransferERPDetail !== undefined ? (stateVars.TM_GetTransferERPDetail?.length > 0 ? stateVars.TM_GetTransferERPDetail[0].requestNumber : null) : (this.state.TM_GetTransferERPDetail?.length > 0 ? this.state.TM_GetTransferERPDetail[0].requestNumber : null)));

			formVars.transferfisidetayi_589295_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetTransferERPDetail !== undefined ? (stateVars.TM_GetTransferERPDetail?.length > 0 ? stateVars.TM_GetTransferERPDetail[0].serialNumber : null) : (this.state.TM_GetTransferERPDetail?.length > 0 ? this.state.TM_GetTransferERPDetail[0].serialNumber : null)));

			formVars.transferfisidetayi_563033_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetTransferERPDetail !== undefined ? (stateVars.TM_GetTransferERPDetail?.length > 0 ? stateVars.TM_GetTransferERPDetail[0].createdByName : null) : (this.state.TM_GetTransferERPDetail?.length > 0 ? this.state.TM_GetTransferERPDetail[0].createdByName : null)));

			formVars.transferfisidetayi_106004_value = ReactSystemFunctions.value(this, (stateVars.TM_GetTransferERPDetail !== undefined ? (stateVars.TM_GetTransferERPDetail?.length > 0 ? stateVars.TM_GetTransferERPDetail[0].createdAt : null) : (this.state.TM_GetTransferERPDetail?.length > 0 ? this.state.TM_GetTransferERPDetail[0].createdAt : null)));

			formVars.transferfisidetayi_503983_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetTransferERPDetail !== undefined ? (stateVars.TM_GetTransferERPDetail?.length > 0 ? stateVars.TM_GetTransferERPDetail[0].sourceStoreName : null) : (this.state.TM_GetTransferERPDetail?.length > 0 ? this.state.TM_GetTransferERPDetail[0].sourceStoreName : null)));

			formVars.transferfisidetayi_472814_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetTransferERPDetail !== undefined ? (stateVars.TM_GetTransferERPDetail?.length > 0 ? stateVars.TM_GetTransferERPDetail[0].destinationStoreName : null) : (this.state.TM_GetTransferERPDetail?.length > 0 ? this.state.TM_GetTransferERPDetail[0].destinationStoreName : null)));

			formVars.transferfisidetayi_462847_value = ReactSystemFunctions.value(this, (stateVars.TM_GetTransferERPDetail !== undefined ? (stateVars.TM_GetTransferERPDetail?.length > 0 ? stateVars.TM_GetTransferERPDetail[0].transferredAt : null) : (this.state.TM_GetTransferERPDetail?.length > 0 ? this.state.TM_GetTransferERPDetail[0].transferredAt : null)));

			formVars.transferfisidetayi_733934_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetTransferERPDetail !== undefined ? (stateVars.TM_GetTransferERPDetail?.length > 0 ? stateVars.TM_GetTransferERPDetail[0].nebimShippingNumber : null) : (this.state.TM_GetTransferERPDetail?.length > 0 ? this.state.TM_GetTransferERPDetail[0].nebimShippingNumber : null)));

			formVars.transferfisidetayi_1276390993_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetTransferERPDetail !== undefined ? (stateVars.TM_GetTransferERPDetail?.length > 0 ? stateVars.TM_GetTransferERPDetail[0].requestNumber : null) : (this.state.TM_GetTransferERPDetail?.length > 0 ? this.state.TM_GetTransferERPDetail[0].requestNumber : null)));

			formVars.transferfisidetayi_392050841_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetTransferERPDetail !== undefined ? (stateVars.TM_GetTransferERPDetail?.length > 0 ? stateVars.TM_GetTransferERPDetail[0].productName : null) : (this.state.TM_GetTransferERPDetail?.length > 0 ? this.state.TM_GetTransferERPDetail[0].productName : null)));

			formVars.transferfisidetayi_1060286712_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetTransferERPDetail !== undefined ? (stateVars.TM_GetTransferERPDetail?.length > 0 ? stateVars.TM_GetTransferERPDetail[0].productCode : null) : (this.state.TM_GetTransferERPDetail?.length > 0 ? this.state.TM_GetTransferERPDetail[0].productCode : null)));

			formVars.transferfisidetayi_75661225_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetTransferERPDetail !== undefined ? (stateVars.TM_GetTransferERPDetail?.length > 0 ? stateVars.TM_GetTransferERPDetail[0].serialNumber : null) : (this.state.TM_GetTransferERPDetail?.length > 0 ? this.state.TM_GetTransferERPDetail[0].serialNumber : null)));

			formVars.transferfisidetayi_746791817_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetTransferERPDetail !== undefined ? (stateVars.TM_GetTransferERPDetail?.length > 0 ? stateVars.TM_GetTransferERPDetail[0].lineStatusName : null) : (this.state.TM_GetTransferERPDetail?.length > 0 ? this.state.TM_GetTransferERPDetail[0].lineStatusName : null)));


	this.props.form?.setFieldsValue(formVars);
	this.setState(stateVars);
	KuikaAppManager.hideSpinner(this);

            this.setPageInitLoaded(true);
            return isErrorOccurred;
        }




		TransferFisiDetayiComponent_161228_onClick = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations, this.checkTabErrors))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
KuikaAppManager.showSpinner(this);

				stateVars.GoBack = await ReactSystemFunctions.goBack(this, false);

		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

            
            return isErrorOccurred;
        }


    TransferFisiDetayiComponent_1917891487_onClick = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations, this.checkTabErrors))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
		KuikaAppManager.increaseServerRequestCount();

        let localVar = {
				TransferERPHeaderId_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, (stateVars.TM_GetTransferERPDetail !== undefined ? (stateVars.TM_GetTransferERPDetail?.length > 0 ? stateVars.TM_GetTransferERPDetail[0].transferERPHeaderId : null) : (this.state.TM_GetTransferERPDetail?.length > 0 ? this.state.TM_GetTransferERPDetail[0].transferERPHeaderId : null))), "Guid"),
				base64_1: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, (stateVars.GetBase64Sql !== undefined ? (stateVars.GetBase64Sql?.length > 0 ? stateVars.GetBase64Sql[0].base64Pdf : null) : (this.state.GetBase64Sql?.length > 0 ? this.state.GetBase64Sql[0].base64Pdf : null))), "string")
        }

		KuikaAppManager.showSpinner(this);
		
        if (true) {
        KuikaAppManager.showSpinner(this);
        }
        let result = await KuikaAppManager.ApiRequest(this, "TransferFisiDetayi/TransferFisiDetayiComponent_1917891487_onClick", localVar)
        if (!KMainFunctions.IsResStatus2XX(result)) return true;

			stateVars.GetBase64Sql = result?.data.getBase64Sql;
			stateVars.Decode = result?.data.decode;
			this.props.form?.setFieldsValue(formVars);
			
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.TransferFisiDetayiComponent_1917891487_onClick1_();
                  resolve();
                });
          })



        
        KuikaAppManager.hideSpinner(this);
        return isErrorOccurred;
    }
		TransferFisiDetayiComponent_1917891487_onClick1_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations, this.checkTabErrors))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }

				stateVars.Open = HtmlA4Printer.Open(ReactSystemFunctions.toString(this, this.state.Decode));

		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

            
            return isErrorOccurred;
        }




		TransferFisiDetayiComponent_501754_onClick = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations, this.checkTabErrors))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
KuikaAppManager.showSpinner(this);

					KuikaAppManager.prepareForNavigation();
						KuikaAppManager.addToPageInputVariables("TransferFisKabul", "TransferERPHeaderId", ReactSystemFunctions.convertToTypeByName(this.props.screenInputs.TransferERPHeaderId ?? this.props.screenInputs.transfererpheaderid, "Guid"));

				stateVars.NAVIGATE = await ReactSystemFunctions.navigate(this, undefined, "TransferFisiDetayi", "TransferFisKabul", "", "currentPage", null, null, null, null, null, null, true, false);

		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

            
            return isErrorOccurred;
        }


    TransferFisiDetayiComponent_836453_onClick = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations, this.checkTabErrors))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
		KuikaAppManager.increaseServerRequestCount();

        let localVar = {
				OfficeCode_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, (stateVars.TM_GetTransferERPDetail !== undefined ? (stateVars.TM_GetTransferERPDetail?.length > 0 ? stateVars.TM_GetTransferERPDetail[0].currentOfficeCode : null) : (this.state.TM_GetTransferERPDetail?.length > 0 ? this.state.TM_GetTransferERPDetail[0].currentOfficeCode : null))), "string"),
				StoreCode_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, (stateVars.TM_GetTransferERPDetail !== undefined ? (stateVars.TM_GetTransferERPDetail?.length > 0 ? stateVars.TM_GetTransferERPDetail[0].currentStoreCode : null) : (this.state.TM_GetTransferERPDetail?.length > 0 ? this.state.TM_GetTransferERPDetail[0].currentStoreCode : null))), "string"),
				shipmentHeaderId_1: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, (stateVars.TM_GetTransferERPDetail !== undefined ? (stateVars.TM_GetTransferERPDetail?.length > 0 ? stateVars.TM_GetTransferERPDetail[0].nebimShipmentHeaderId : null) : (this.state.TM_GetTransferERPDetail?.length > 0 ? this.state.TM_GetTransferERPDetail[0].nebimShipmentHeaderId : null))), "string"),
				shippingDate_1: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, (stateVars.TM_GetTransferERPDetail !== undefined ? (stateVars.TM_GetTransferERPDetail?.length > 0 ? stateVars.TM_GetTransferERPDetail[0].createdAt : null) : (this.state.TM_GetTransferERPDetail?.length > 0 ? this.state.TM_GetTransferERPDetail[0].createdAt : null))), "string"),
				prefix_1: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, (stateVars.Kuika_EShipmentSerialNumberPrefix !== undefined ? (stateVars.Kuika_EShipmentSerialNumberPrefix?.length > 0 ? stateVars.Kuika_EShipmentSerialNumberPrefix[0].eShipmentPrefixCode : null) : (this.state.Kuika_EShipmentSerialNumberPrefix?.length > 0 ? this.state.Kuika_EShipmentSerialNumberPrefix[0].eShipmentPrefixCode : null))), "string"),
				queryName_1: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.convertToTypeByName("Times Seri Numaralı", "string"), "string"),
				IsSuccess_2: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, stateVars.SendEShipment?.isSuccess), "number"),
				TransferERPHeaderId_2: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, (stateVars.TM_GetTransferERPDetail !== undefined ? (stateVars.TM_GetTransferERPDetail?.length > 0 ? stateVars.TM_GetTransferERPDetail[0].transferERPHeaderId : null) : (this.state.TM_GetTransferERPDetail?.length > 0 ? this.state.TM_GetTransferERPDetail[0].transferERPHeaderId : null))), "Guid"),
				TransferRequestHeaderId_2: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, (stateVars.TM_GetTransferERPDetail !== undefined ? (stateVars.TM_GetTransferERPDetail?.length > 0 ? stateVars.TM_GetTransferERPDetail[0].transferRequestHeaderId : null) : (this.state.TM_GetTransferERPDetail?.length > 0 ? this.state.TM_GetTransferERPDetail[0].transferRequestHeaderId : null))), "Guid"),
				TransferRequestLineId_2: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, (stateVars.TM_GetTransferERPDetail !== undefined ? (stateVars.TM_GetTransferERPDetail?.length > 0 ? stateVars.TM_GetTransferERPDetail[0].transferRequestLineId : null) : (this.state.TM_GetTransferERPDetail?.length > 0 ? this.state.TM_GetTransferERPDetail[0].transferRequestLineId : null))), "Guid"),
				Request_2: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, stateVars.SendEShipment?.request), "string"),
				Response_2: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, stateVars.SendEShipment?.response), "string"),
				CurrentUsername_2: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.getMyUsername(), "string"),
				Base64Pdf_2: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, stateVars.SendEShipment?.printResult), "string")
        }

		KuikaAppManager.showSpinner(this);
		
        if (true) {
        KuikaAppManager.showSpinner(this);
        }
        let result = await KuikaAppManager.ApiRequest(this, "TransferFisiDetayi/TransferFisiDetayiComponent_836453_onClick", localVar)
        if (!KMainFunctions.IsResStatus2XX(result)) return true;

			stateVars.Kuika_EShipmentSerialNumberPrefix = result?.data.kuika_EShipmentSerialNumberPrefix;
			stateVars.SendEShipment = result?.data.sendEShipment;
			stateVars.TMTransferApprovePostAfterSql = result?.data.tmTransferApprovePostAfterSql;
			this.props.form?.setFieldsValue(formVars);
			
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.TransferFisiDetayiComponent_836453_onClick1_();
                  resolve();
                });
          })



        
        KuikaAppManager.hideSpinner(this);
        return isErrorOccurred;
    }
		TransferFisiDetayiComponent_836453_onClick1_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations, this.checkTabErrors))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }

				stateVars.Notify = await ReactSystemFunctions.notify(this, ReactSystemFunctions.toString(this, (stateVars.TMTransferApprovePostAfterSql !== undefined ? (stateVars.TMTransferApprovePostAfterSql?.length > 0 ? stateVars.TMTransferApprovePostAfterSql[0].message : null) : (this.state.TMTransferApprovePostAfterSql?.length > 0 ? this.state.TMTransferApprovePostAfterSql[0].message : null))), ReactSystemFunctions.convertToTypeByName("default", "string"), ReactSystemFunctions.convertToTypeByName("bottom-right", "string"), 2, ReactSystemFunctions.convertToTypeByName("", "string"), ReactSystemFunctions.convertToTypeByName("", "string"), 0);
				await this.TransferFisiDetayiPageInit();
				

		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

            
            return isErrorOccurred;
        }




    TransferFisiDetayiComponent_661611_onChange = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations, this.checkTabErrors))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
		KuikaAppManager.increaseServerRequestCount();

        let localVar = {
				CurrentUsername_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.getMyUsername(), "string"),
				TransferERPHeaderId_0: ReactSystemFunctions.convertToTypeByName(this.props.screenInputs.TransferERPHeaderId ?? this.props.screenInputs.transfererpheaderid, "Guid")
        }

		KuikaAppManager.showSpinner(this);
		
        if (true) {
        KuikaAppManager.showSpinner(this);
        }
        let result = await KuikaAppManager.ApiRequest(this, "TransferFisiDetayi/TransferFisiDetayiComponent_661611_onChange", localVar)
        if (!KMainFunctions.IsResStatus2XX(result)) return true;

			stateVars.TM_GetTransferERPDetail = result?.data.tM_GetTransferERPDetail;
			formVars.transferfisidetayi_833442_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetTransferERPDetail !== undefined ? (stateVars.TM_GetTransferERPDetail?.length > 0 ? stateVars.TM_GetTransferERPDetail[0].transferERPNumber : null) : (this.state.TM_GetTransferERPDetail?.length > 0 ? this.state.TM_GetTransferERPDetail[0].transferERPNumber : null)));
			formVars.transferfisidetayi_867218_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetTransferERPDetail !== undefined ? (stateVars.TM_GetTransferERPDetail?.length > 0 ? stateVars.TM_GetTransferERPDetail[0].transferERPStatusName : null) : (this.state.TM_GetTransferERPDetail?.length > 0 ? this.state.TM_GetTransferERPDetail[0].transferERPStatusName : null)));
			formVars.transferfisidetayi_754214_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetTransferERPDetail !== undefined ? (stateVars.TM_GetTransferERPDetail?.length > 0 ? stateVars.TM_GetTransferERPDetail[0].transferERPNumber : null) : (this.state.TM_GetTransferERPDetail?.length > 0 ? this.state.TM_GetTransferERPDetail[0].transferERPNumber : null)));
			formVars.transferfisidetayi_136546_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetTransferERPDetail !== undefined ? (stateVars.TM_GetTransferERPDetail?.length > 0 ? stateVars.TM_GetTransferERPDetail[0].transferERPStatusName : null) : (this.state.TM_GetTransferERPDetail?.length > 0 ? this.state.TM_GetTransferERPDetail[0].transferERPStatusName : null)));
			formVars.transferfisidetayi_53933_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetTransferERPDetail !== undefined ? (stateVars.TM_GetTransferERPDetail?.length > 0 ? stateVars.TM_GetTransferERPDetail[0].sourceStoreName : null) : (this.state.TM_GetTransferERPDetail?.length > 0 ? this.state.TM_GetTransferERPDetail[0].sourceStoreName : null)));
			formVars.transferfisidetayi_999536_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetTransferERPDetail !== undefined ? (stateVars.TM_GetTransferERPDetail?.length > 0 ? stateVars.TM_GetTransferERPDetail[0].destinationStoreName : null) : (this.state.TM_GetTransferERPDetail?.length > 0 ? this.state.TM_GetTransferERPDetail[0].destinationStoreName : null)));
			formVars.transferfisidetayi_894012_value = ReactSystemFunctions.value(this, (stateVars.TM_GetTransferERPDetail !== undefined ? (stateVars.TM_GetTransferERPDetail?.length > 0 ? stateVars.TM_GetTransferERPDetail[0].transferredAt : null) : (this.state.TM_GetTransferERPDetail?.length > 0 ? this.state.TM_GetTransferERPDetail[0].transferredAt : null)));
			formVars.transferfisidetayi_336432_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetTransferERPDetail !== undefined ? (stateVars.TM_GetTransferERPDetail?.length > 0 ? stateVars.TM_GetTransferERPDetail[0].requestNumber : null) : (this.state.TM_GetTransferERPDetail?.length > 0 ? this.state.TM_GetTransferERPDetail[0].requestNumber : null)));
			formVars.transferfisidetayi_589295_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetTransferERPDetail !== undefined ? (stateVars.TM_GetTransferERPDetail?.length > 0 ? stateVars.TM_GetTransferERPDetail[0].serialNumber : null) : (this.state.TM_GetTransferERPDetail?.length > 0 ? this.state.TM_GetTransferERPDetail[0].serialNumber : null)));
			formVars.transferfisidetayi_563033_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetTransferERPDetail !== undefined ? (stateVars.TM_GetTransferERPDetail?.length > 0 ? stateVars.TM_GetTransferERPDetail[0].createdByName : null) : (this.state.TM_GetTransferERPDetail?.length > 0 ? this.state.TM_GetTransferERPDetail[0].createdByName : null)));
			formVars.transferfisidetayi_106004_value = ReactSystemFunctions.value(this, (stateVars.TM_GetTransferERPDetail !== undefined ? (stateVars.TM_GetTransferERPDetail?.length > 0 ? stateVars.TM_GetTransferERPDetail[0].createdAt : null) : (this.state.TM_GetTransferERPDetail?.length > 0 ? this.state.TM_GetTransferERPDetail[0].createdAt : null)));
			formVars.transferfisidetayi_503983_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetTransferERPDetail !== undefined ? (stateVars.TM_GetTransferERPDetail?.length > 0 ? stateVars.TM_GetTransferERPDetail[0].sourceStoreName : null) : (this.state.TM_GetTransferERPDetail?.length > 0 ? this.state.TM_GetTransferERPDetail[0].sourceStoreName : null)));
			formVars.transferfisidetayi_472814_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetTransferERPDetail !== undefined ? (stateVars.TM_GetTransferERPDetail?.length > 0 ? stateVars.TM_GetTransferERPDetail[0].destinationStoreName : null) : (this.state.TM_GetTransferERPDetail?.length > 0 ? this.state.TM_GetTransferERPDetail[0].destinationStoreName : null)));
			formVars.transferfisidetayi_462847_value = ReactSystemFunctions.value(this, (stateVars.TM_GetTransferERPDetail !== undefined ? (stateVars.TM_GetTransferERPDetail?.length > 0 ? stateVars.TM_GetTransferERPDetail[0].transferredAt : null) : (this.state.TM_GetTransferERPDetail?.length > 0 ? this.state.TM_GetTransferERPDetail[0].transferredAt : null)));
			formVars.transferfisidetayi_733934_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetTransferERPDetail !== undefined ? (stateVars.TM_GetTransferERPDetail?.length > 0 ? stateVars.TM_GetTransferERPDetail[0].nebimShippingNumber : null) : (this.state.TM_GetTransferERPDetail?.length > 0 ? this.state.TM_GetTransferERPDetail[0].nebimShippingNumber : null)));
			formVars.transferfisidetayi_1276390993_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetTransferERPDetail !== undefined ? (stateVars.TM_GetTransferERPDetail?.length > 0 ? stateVars.TM_GetTransferERPDetail[0].requestNumber : null) : (this.state.TM_GetTransferERPDetail?.length > 0 ? this.state.TM_GetTransferERPDetail[0].requestNumber : null)));
			formVars.transferfisidetayi_392050841_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetTransferERPDetail !== undefined ? (stateVars.TM_GetTransferERPDetail?.length > 0 ? stateVars.TM_GetTransferERPDetail[0].productName : null) : (this.state.TM_GetTransferERPDetail?.length > 0 ? this.state.TM_GetTransferERPDetail[0].productName : null)));
			formVars.transferfisidetayi_1060286712_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetTransferERPDetail !== undefined ? (stateVars.TM_GetTransferERPDetail?.length > 0 ? stateVars.TM_GetTransferERPDetail[0].productCode : null) : (this.state.TM_GetTransferERPDetail?.length > 0 ? this.state.TM_GetTransferERPDetail[0].productCode : null)));
			formVars.transferfisidetayi_75661225_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetTransferERPDetail !== undefined ? (stateVars.TM_GetTransferERPDetail?.length > 0 ? stateVars.TM_GetTransferERPDetail[0].serialNumber : null) : (this.state.TM_GetTransferERPDetail?.length > 0 ? this.state.TM_GetTransferERPDetail[0].serialNumber : null)));
			formVars.transferfisidetayi_746791817_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetTransferERPDetail !== undefined ? (stateVars.TM_GetTransferERPDetail?.length > 0 ? stateVars.TM_GetTransferERPDetail[0].lineStatusName : null) : (this.state.TM_GetTransferERPDetail?.length > 0 ? this.state.TM_GetTransferERPDetail[0].lineStatusName : null)));
			stateVars.isComp1917891487Visible = (((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.toString(this, (stateVars.TM_GetTransferERPDetail !== undefined ? (stateVars.TM_GetTransferERPDetail?.length > 0 ? stateVars.TM_GetTransferERPDetail[0].transferERPStatusCode : null) : (this.state.TM_GetTransferERPDetail?.length > 0 ? this.state.TM_GetTransferERPDetail[0].transferERPStatusCode : null))), ReactSystemFunctions.convertToTypeByName("IN_TRANSIT", "string")) || ReactSystemFunctions.isEqualTo(ReactSystemFunctions.toString(this, (stateVars.TM_GetTransferERPDetail !== undefined ? (stateVars.TM_GetTransferERPDetail?.length > 0 ? stateVars.TM_GetTransferERPDetail[0].transferERPStatusCode : null) : (this.state.TM_GetTransferERPDetail?.length > 0 ? this.state.TM_GetTransferERPDetail[0].transferERPStatusCode : null))), ReactSystemFunctions.convertToTypeByName("COMPLETED", "string")))) === true ? "visible" : "hidden")
			stateVars.isComp501754Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, (stateVars.TM_GetTransferERPDetail !== undefined ? (stateVars.TM_GetTransferERPDetail?.length > 0 ? stateVars.TM_GetTransferERPDetail[0].canGoToAcceptance : null) : (this.state.TM_GetTransferERPDetail?.length > 0 ? this.state.TM_GetTransferERPDetail[0].canGoToAcceptance : null))), ReactSystemFunctions.convertToTypeByName("True", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp836453Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, (stateVars.TM_GetTransferERPDetail !== undefined ? (stateVars.TM_GetTransferERPDetail?.length > 0 ? stateVars.TM_GetTransferERPDetail[0].canApproveSlip : null) : (this.state.TM_GetTransferERPDetail?.length > 0 ? this.state.TM_GetTransferERPDetail[0].canApproveSlip : null))), ReactSystemFunctions.convertToTypeByName("True", "string"))) === true ? "visible" : "hidden")
			this.props.form?.setFieldsValue(formVars);
			
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.TransferFisiDetayiComponent_661611_onChange1_();
                  resolve();
                });
          })



        
        KuikaAppManager.hideSpinner(this);
        return isErrorOccurred;
    }
		TransferFisiDetayiComponent_661611_onChange1_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations, this.checkTabErrors))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }

				formVars.transferfisidetayi_833442_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetTransferERPDetail !== undefined ? (stateVars.TM_GetTransferERPDetail?.length > 0 ? stateVars.TM_GetTransferERPDetail[0].transferERPNumber : null) : (this.state.TM_GetTransferERPDetail?.length > 0 ? this.state.TM_GetTransferERPDetail[0].transferERPNumber : null)));

				formVars.transferfisidetayi_867218_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetTransferERPDetail !== undefined ? (stateVars.TM_GetTransferERPDetail?.length > 0 ? stateVars.TM_GetTransferERPDetail[0].transferERPStatusName : null) : (this.state.TM_GetTransferERPDetail?.length > 0 ? this.state.TM_GetTransferERPDetail[0].transferERPStatusName : null)));

				formVars.transferfisidetayi_754214_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetTransferERPDetail !== undefined ? (stateVars.TM_GetTransferERPDetail?.length > 0 ? stateVars.TM_GetTransferERPDetail[0].transferERPNumber : null) : (this.state.TM_GetTransferERPDetail?.length > 0 ? this.state.TM_GetTransferERPDetail[0].transferERPNumber : null)));

				formVars.transferfisidetayi_136546_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetTransferERPDetail !== undefined ? (stateVars.TM_GetTransferERPDetail?.length > 0 ? stateVars.TM_GetTransferERPDetail[0].transferERPStatusName : null) : (this.state.TM_GetTransferERPDetail?.length > 0 ? this.state.TM_GetTransferERPDetail[0].transferERPStatusName : null)));

				formVars.transferfisidetayi_53933_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetTransferERPDetail !== undefined ? (stateVars.TM_GetTransferERPDetail?.length > 0 ? stateVars.TM_GetTransferERPDetail[0].sourceStoreName : null) : (this.state.TM_GetTransferERPDetail?.length > 0 ? this.state.TM_GetTransferERPDetail[0].sourceStoreName : null)));

				formVars.transferfisidetayi_999536_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetTransferERPDetail !== undefined ? (stateVars.TM_GetTransferERPDetail?.length > 0 ? stateVars.TM_GetTransferERPDetail[0].destinationStoreName : null) : (this.state.TM_GetTransferERPDetail?.length > 0 ? this.state.TM_GetTransferERPDetail[0].destinationStoreName : null)));

				formVars.transferfisidetayi_894012_value = ReactSystemFunctions.value(this, (stateVars.TM_GetTransferERPDetail !== undefined ? (stateVars.TM_GetTransferERPDetail?.length > 0 ? stateVars.TM_GetTransferERPDetail[0].transferredAt : null) : (this.state.TM_GetTransferERPDetail?.length > 0 ? this.state.TM_GetTransferERPDetail[0].transferredAt : null)));

				formVars.transferfisidetayi_336432_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetTransferERPDetail !== undefined ? (stateVars.TM_GetTransferERPDetail?.length > 0 ? stateVars.TM_GetTransferERPDetail[0].requestNumber : null) : (this.state.TM_GetTransferERPDetail?.length > 0 ? this.state.TM_GetTransferERPDetail[0].requestNumber : null)));

				formVars.transferfisidetayi_589295_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetTransferERPDetail !== undefined ? (stateVars.TM_GetTransferERPDetail?.length > 0 ? stateVars.TM_GetTransferERPDetail[0].serialNumber : null) : (this.state.TM_GetTransferERPDetail?.length > 0 ? this.state.TM_GetTransferERPDetail[0].serialNumber : null)));

				formVars.transferfisidetayi_563033_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetTransferERPDetail !== undefined ? (stateVars.TM_GetTransferERPDetail?.length > 0 ? stateVars.TM_GetTransferERPDetail[0].createdByName : null) : (this.state.TM_GetTransferERPDetail?.length > 0 ? this.state.TM_GetTransferERPDetail[0].createdByName : null)));

				formVars.transferfisidetayi_106004_value = ReactSystemFunctions.value(this, (stateVars.TM_GetTransferERPDetail !== undefined ? (stateVars.TM_GetTransferERPDetail?.length > 0 ? stateVars.TM_GetTransferERPDetail[0].createdAt : null) : (this.state.TM_GetTransferERPDetail?.length > 0 ? this.state.TM_GetTransferERPDetail[0].createdAt : null)));

				formVars.transferfisidetayi_503983_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetTransferERPDetail !== undefined ? (stateVars.TM_GetTransferERPDetail?.length > 0 ? stateVars.TM_GetTransferERPDetail[0].sourceStoreName : null) : (this.state.TM_GetTransferERPDetail?.length > 0 ? this.state.TM_GetTransferERPDetail[0].sourceStoreName : null)));

				formVars.transferfisidetayi_472814_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetTransferERPDetail !== undefined ? (stateVars.TM_GetTransferERPDetail?.length > 0 ? stateVars.TM_GetTransferERPDetail[0].destinationStoreName : null) : (this.state.TM_GetTransferERPDetail?.length > 0 ? this.state.TM_GetTransferERPDetail[0].destinationStoreName : null)));

				formVars.transferfisidetayi_462847_value = ReactSystemFunctions.value(this, (stateVars.TM_GetTransferERPDetail !== undefined ? (stateVars.TM_GetTransferERPDetail?.length > 0 ? stateVars.TM_GetTransferERPDetail[0].transferredAt : null) : (this.state.TM_GetTransferERPDetail?.length > 0 ? this.state.TM_GetTransferERPDetail[0].transferredAt : null)));

				formVars.transferfisidetayi_733934_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetTransferERPDetail !== undefined ? (stateVars.TM_GetTransferERPDetail?.length > 0 ? stateVars.TM_GetTransferERPDetail[0].nebimShippingNumber : null) : (this.state.TM_GetTransferERPDetail?.length > 0 ? this.state.TM_GetTransferERPDetail[0].nebimShippingNumber : null)));

				formVars.transferfisidetayi_1276390993_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetTransferERPDetail !== undefined ? (stateVars.TM_GetTransferERPDetail?.length > 0 ? stateVars.TM_GetTransferERPDetail[0].requestNumber : null) : (this.state.TM_GetTransferERPDetail?.length > 0 ? this.state.TM_GetTransferERPDetail[0].requestNumber : null)));

				formVars.transferfisidetayi_392050841_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetTransferERPDetail !== undefined ? (stateVars.TM_GetTransferERPDetail?.length > 0 ? stateVars.TM_GetTransferERPDetail[0].productName : null) : (this.state.TM_GetTransferERPDetail?.length > 0 ? this.state.TM_GetTransferERPDetail[0].productName : null)));

				formVars.transferfisidetayi_1060286712_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetTransferERPDetail !== undefined ? (stateVars.TM_GetTransferERPDetail?.length > 0 ? stateVars.TM_GetTransferERPDetail[0].productCode : null) : (this.state.TM_GetTransferERPDetail?.length > 0 ? this.state.TM_GetTransferERPDetail[0].productCode : null)));

				formVars.transferfisidetayi_75661225_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetTransferERPDetail !== undefined ? (stateVars.TM_GetTransferERPDetail?.length > 0 ? stateVars.TM_GetTransferERPDetail[0].serialNumber : null) : (this.state.TM_GetTransferERPDetail?.length > 0 ? this.state.TM_GetTransferERPDetail[0].serialNumber : null)));

				formVars.transferfisidetayi_746791817_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetTransferERPDetail !== undefined ? (stateVars.TM_GetTransferERPDetail?.length > 0 ? stateVars.TM_GetTransferERPDetail[0].lineStatusName : null) : (this.state.TM_GetTransferERPDetail?.length > 0 ? this.state.TM_GetTransferERPDetail[0].lineStatusName : null)));


		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

            
            return isErrorOccurred;
        }






    async callCallbackFunction(diId: number, isFromMaster: boolean = false) {
        let isErrorOccurred = false;
		let pageInitCallerNavDiIDs = [] as number[];
		if (isFromMaster || pageInitCallerNavDiIDs.indexOf(diId) > -1) {
			await this.TransferFisiDetayiPageInit();
		}

    }


}
