import React from "react";
import Axios, { AxiosResponse } from "axios";
import { KuikaAppManager } from "../../shared/utilty/kuika-app-manager";
import { ReactSystemFunctions } from "../../shared/utilty/react-system-functions";
import { KNavigator } from "../../shared/hoc/with-history";
import { KContext } from "../../shared/hoc/with-context";
import { useLocation } from "react-router-dom";
import { FormInstance } from "antd/es/form";
import { Guid } from "guid-typescript";
import Swal from "sweetalert2";
import { KMainFunctions } from "../../shared/utilty/main-functions";
import moment from "moment";
import { IValidationData } from "../../models/dto/validation-data";
import { IStripePayment } from "../../models/dto/stripe-payment";
import { IUserInfoDto } from "../../models/dto/user-info.dto";
import { UserService } from "../../services/user-service";
import { kuikaCoreWasmBridgeService } from "../../services/_singletons";
import _ from "lodash";
import mqtt, { MqttClient } from "mqtt";
import { IMqttResult } from "../../models/dto/mqtt.dto";
import { MasterScreen_ScreenContext } from "../masterscreen/masterscreen-context";

declare let window: any;

export interface IReportSalesNebim_ScreenProps {
  navigator: KNavigator;
  form: FormInstance<any>;
  googleLogin: any;
  screenInputs: any;
  context: KContext;
  initialValues: any;
  children: any;
}

export interface IReportSalesNebim_ScreenState {
    isSpinnerVisible: boolean;
    isPageVisible: boolean;
	isLeftMenuVisible: boolean;
    spinnerCount: number;
    selectedLanguage: string;
    isPageInitLoaded: false;
    isPageRecurringLoaded: false;
	Connect: any;
	Connect_dummy: any;
	IsUstYonetici: any[];
	IsUstYonetici_dummy: any[];
	Kuika_SatisRaporu: any[];
	Kuika_SatisRaporu_dummy: any[];
	SetValueOf: any;
	SetValueOf_dummy: any;
	ExportExcel: any;
	ExportExcel_dummy: any;

}

export class ReportSalesNebim_ScreenBase extends React.PureComponent<IReportSalesNebim_ScreenProps, any> {
    static contextType = MasterScreen_ScreenContext;
    declare context: React.ContextType<typeof MasterScreen_ScreenContext>;
	reportsalesnebim_251538899_value_kuikaTableRef: React.RefObject<any>;
    ml=[{"Id":"d5a61d2b-bd60-485f-86e2-661e9ed4e486","Name":"en_US","ShortName":"English","IsDefault":true,"LanguagePhrases":[]},{"Id":"841d7605-d0ee-4f99-88ef-3af1726af491","Name":"FixedValues","ShortName":"FixedValues","LanguagePhrases":[{"Id":354658722,"PropertyName":"value","Value":"Nebim Satış Raporu"},{"Id":1886367881,"PropertyName":"value","Value":"Satış verilerini tarih ve ürün kriterlerine göre filtreleyin."},{"Id":1368291981,"PropertyName":"value","Value":"Rapor Filtreleri"},{"Id":444024849,"PropertyName":"value","Value":"Tarih"},{"Id":236931,"PropertyName":"startDatePlaceholder","Value":"Başlangıç Tarihi"},{"Id":236931,"PropertyName":"endDatePlaceholder","Value":"Bitiş Tarihi"},{"Id":518761239,"PropertyName":"value","Value":"E-Fatura Seri No"},{"Id":1006957637,"PropertyName":"placeholder","Value":"Seri numarası girin"},{"Id":95353912,"PropertyName":"value","Value":"Fatura Ref No"},{"Id":475262368,"PropertyName":"placeholder","Value":"Fatura referans numarası girin"},{"Id":1315839238,"PropertyName":"value","Value":"Marka"},{"Id":848442265,"PropertyName":"placeholder","Value":"Marka"},{"Id":1318706920,"PropertyName":"value","Value":"Ürün Grubu"},{"Id":6222002,"PropertyName":"placeholder","Value":"Ürün Grubu"},{"Id":982347766,"PropertyName":"value","Value":"Material"},{"Id":546313168,"PropertyName":"placeholder","Value":"Material"},{"Id":798457994,"PropertyName":"value","Value":"Diameter / Çap"},{"Id":773781625,"PropertyName":"placeholder","Value":"Diameter"},{"Id":460605514,"PropertyName":"value","Value":"Family"},{"Id":393438511,"PropertyName":"placeholder","Value":"Family"},{"Id":1603875421,"PropertyName":"label","Value":"Temizle"},{"Id":2136600364,"PropertyName":"label","Value":"Filtrele"},{"Id":979725655,"PropertyName":"value","Value":"Satış Detayları"},{"Id":348358059,"PropertyName":"label","Value":"Excel'e Aktar"},{"Id":251538899,"PropertyName":"nodatafoundmessage","Value":"Satış detayı bulunamadı"},{"Id":665272091,"PropertyName":"title","Value":"Fatura Tarihi"},{"Id":1000686697,"PropertyName":"value","Value":"[datafield:faturatarihi]"},{"Id":1674356847,"PropertyName":"title","Value":"E-Fatura Seri No"},{"Id":1371932606,"PropertyName":"value","Value":"[datafield:efaturaserino]"},{"Id":1759136210,"PropertyName":"title","Value":"E-Fatura Ref No"},{"Id":1755136413,"PropertyName":"value","Value":"[datafield:faturarefno]"},{"Id":1329110106,"PropertyName":"title","Value":"Müşteri Kodu"},{"Id":900857174,"PropertyName":"value","Value":"[datafield:musterikodu]"},{"Id":591241722,"PropertyName":"title","Value":"Müşteri Adı"},{"Id":1437568986,"PropertyName":"value","Value":"[datafield:musteriadi]"},{"Id":443802293,"PropertyName":"title","Value":"Müşteri Tipi"},{"Id":1122363247,"PropertyName":"value","Value":"[datafield:musteritipi]"},{"Id":1365333135,"PropertyName":"title","Value":"Madde Kodu"},{"Id":756873671,"PropertyName":"value","Value":"[datafield:maddekodu]"},{"Id":1537214474,"PropertyName":"title","Value":"Madde Açıklaması"},{"Id":1845345577,"PropertyName":"value","Value":"[datafield:maddeaciklamasi]"},{"Id":1190446676,"PropertyName":"title","Value":"Ürün Seri Numarası"},{"Id":349590768,"PropertyName":"value","Value":"[datafield:urunserinumarasi]"},{"Id":1293863244,"PropertyName":"title","Value":"Marka"},{"Id":260124151,"PropertyName":"value","Value":"[datafield:marka]"},{"Id":836252767,"PropertyName":"title","Value":"Ürün Grubu"},{"Id":1376259524,"PropertyName":"value","Value":"[datafield:urungrubu]"},{"Id":1281407326,"PropertyName":"title","Value":"Model"},{"Id":731208488,"PropertyName":"value","Value":"[datafield:model]"},{"Id":2071474052,"PropertyName":"title","Value":"Bracelet"},{"Id":1597609380,"PropertyName":"value","Value":"[datafield:bracelet]"},{"Id":1401069337,"PropertyName":"title","Value":"Dial"},{"Id":1700888860,"PropertyName":"value","Value":"[datafield:dial]"},{"Id":1463269566,"PropertyName":"title","Value":"Material"},{"Id":1795764940,"PropertyName":"value","Value":"[datafield:material]"},{"Id":354796279,"PropertyName":"title","Value":"Diameter / Çap"},{"Id":1792334887,"PropertyName":"value","Value":"[datafield:diameter]"},{"Id":2026958012,"PropertyName":"title","Value":"Family"},{"Id":871804445,"PropertyName":"value","Value":"[datafield:family]"},{"Id":1804113587,"PropertyName":"title","Value":"Prim"},{"Id":1768205269,"PropertyName":"value","Value":"[datafield:prim]"},{"Id":1434188170,"PropertyName":"title","Value":"Satış Sorumlusu"},{"Id":1383531553,"PropertyName":"value","Value":"[datafield:satissorumlusu]"},{"Id":114554893,"PropertyName":"title","Value":"Miktar"},{"Id":129112992,"PropertyName":"value","Value":"[datafield:miktar]"},{"Id":95328894,"PropertyName":"title","Value":"Fiyat"},{"Id":2068391357,"PropertyName":"value","Value":"[datafield:fiyat]"},{"Id":1067744378,"PropertyName":"title","Value":"İskonto"},{"Id":769551674,"PropertyName":"value","Value":"[datafield:iskonto]"},{"Id":1102499672,"PropertyName":"title","Value":"Net Tutar"},{"Id":1164986122,"PropertyName":"value","Value":"[datafield:nettutar]"},{"Id":1782158353,"PropertyName":"title","Value":"Döviz"},{"Id":2144473389,"PropertyName":"value","Value":"[datafield:doviz]"},{"Id":1066465465,"PropertyName":"title","Value":"Döviz Net Tutar"},{"Id":1260762374,"PropertyName":"value","Value":"[datafield:doviznettutar]"},{"Id":1218584887,"PropertyName":"title","Value":"Mağaza Kodu"},{"Id":323415910,"PropertyName":"value","Value":"[datafield:magazakodu]"},{"Id":2144213583,"PropertyName":"title","Value":"Mağaza"},{"Id":2098140175,"PropertyName":"value","Value":"[datafield:magaza]"},{"Id":120508773,"PropertyName":"title","Value":"Ofis Kodu"},{"Id":1982234863,"PropertyName":"value","Value":"[datafield:ofiskodu]"},{"Id":2099962064,"PropertyName":"title","Value":"Depo Kodu"},{"Id":158413792,"PropertyName":"value","Value":"[datafield:depokodu]"}]}]
    defaultML = "en_US"
    
    screenHash = ""
    

    private _prevMasterPageInitLoaded: boolean = false;
    private _prevMasterPageRecurringLoaded: boolean = false;
    private _prevShouldTriggerPageInit: boolean = false;
    constructor(props) {
        super(props);
		this.reportsalesnebim_1006957637_value_kuikaTextInputRef = React.createRef();
		this.reportsalesnebim_475262368_value_kuikaTextInputRef = React.createRef();
		this.reportsalesnebim_848442265_value_kuikaTextInputRef = React.createRef();
		this.reportsalesnebim_6222002_value_kuikaTextInputRef = React.createRef();
		this.reportsalesnebim_546313168_value_kuikaTextInputRef = React.createRef();
		this.reportsalesnebim_773781625_value_kuikaTextInputRef = React.createRef();
		this.reportsalesnebim_393438511_value_kuikaTextInputRef = React.createRef();
		this.reportsalesnebim_251538899_value_kuikaTableRef = React.createRef();

        this.state = {
            isSpinnerVisible: false,
            isPageVisible: false,
            isLeftMenuVisible: false,
            spinnerCount: 0,
            selectedLanguage: "",
            isPageInitLoaded: false,
            isPageRecurringLoaded: false,
            	        Connect: "",
	        IsUstYonetici: [],
	        Kuika_SatisRaporu: [],
	        SetValueOf: "",
	        ExportExcel: "",

        }

        this.state.isPageVisible = true;
        
    }

    async componentDidMount() {

        if (KuikaAppManager.isPageInitPrevented()) {
            KuikaAppManager.calculateAndSetBodyHeight("reportsalesnebim", "masterscreen_screen");
            return;
        }
        this.context.registerCallbackFunction(this.callCallbackFunction.bind(this));
        
        ReactSystemFunctions.validateToken()
        this.fillFormInitValues();
        if (false){
            await this.ReportSalesNebimPageInit();
        } else if (this.context?.isMasterPageInitLoaded) { this._prevMasterPageInitLoaded = true; await this.ReportSalesNebimPageInit(); }
        
        
        
        KuikaAppManager.calculateAndSetBodyHeight("reportsalesnebim", "masterscreen_screen");

        if (ReactSystemFunctions.getIsMicroApp() === false) {
           window.parentScreen = this;
        }
    }

    componentWillUnmount() {
        
        
        

        if (ReactSystemFunctions.getIsMicroApp() === false) {
           window.parentScreen = null;
        }
    }

    

        
    componentDidUpdate= async (prevProps, prevState) => {
		KuikaAppManager.calculateAndSetBodyHeight("reportsalesnebim", "masterscreen_screen"    );
        if (prevProps?.location?.search !== (this.props as any)?.location?.search) {
			await this.ReportSalesNebimPageInit();
		}

        		if (this._prevMasterPageInitLoaded !== this.context.isMasterPageInitLoaded && this.context.isMasterPageInitLoaded === true) {this._prevMasterPageInitLoaded = this.context.isMasterPageInitLoaded;await this.ReportSalesNebimPageInit()}


        if (ReactSystemFunctions.getIsMicroApp() === false) {
            for (const key in prevState) {
                if (key.startsWith('NavVisible') && prevState[key] === true && this.state[key] === false) {
                    window.parentScreen = this;
                    break;
                }
            }
        }
	}

    fillFormInitValues() {
        this.props.form?.setFieldsValue({
reportsalesnebim_236931_value: { startValue: (moment().format("YYYY-MM-DDTHH:mm:ss")), endValue: (moment().format("YYYY-MM-DDTHH:mm:ss")) }
});

    }

      setPageInitLoaded = (value: boolean) => {
        this.setState({ isPageInitLoaded: value });
      }

      setPageRecurringLoaded = (value: boolean) => {
        this.setState({ isPageRecurringLoaded: value });
      }

      clearFieldValidation = (changedValues: any) => {
        const fieldName = Object.keys(changedValues)[0];
        if (fieldName) {
          this.props.form?.setFields([
            {
              name: fieldName,
              errors: []
            }
          ]);
        }
      };

      

    ReportSalesNebimPageInit = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


	if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }

        let localVar = {
			KUserId_1: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.getMyUserId(), "Guid"),
			StartDate_2: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "reportsalesnebim_236931_value", "startValue", "", "", "")), "string"),
			EndDate_2: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "reportsalesnebim_236931_value", "endValue", "", "", "")), "string"),
			EFaturaSeriNo_2: ReactSystemFunctions.convertToTypeByName(null, "string"),
			FaturaRefNo_2: ReactSystemFunctions.convertToTypeByName(null, "string"),
			Marka_2: ReactSystemFunctions.convertToTypeByName(null, "string"),
			UrunGrubu_2: ReactSystemFunctions.convertToTypeByName(null, "string"),
			Material_2: ReactSystemFunctions.convertToTypeByName(null, "string"),
			Diameter_2: ReactSystemFunctions.convertToTypeByName(null, "string"),
			Family_2: ReactSystemFunctions.convertToTypeByName(null, "string"),
			IsUstYonetici_2: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toBoolean(this, (stateVars.IsUstYonetici !== undefined ? (stateVars.IsUstYonetici?.length > 0 ? stateVars.IsUstYonetici[0].isUstYonetici : null) : (this.state.IsUstYonetici?.length > 0 ? this.state.IsUstYonetici[0].isUstYonetici : null))), "boolean")
        }

	KuikaAppManager.showSpinner(this);
	
        if (true) {
        KuikaAppManager.showSpinner(this);
        }
        let result = await KuikaAppManager.ApiRequest(this, "ReportSalesNebim/ReportSalesNebimPageInit", localVar)
        if (!KMainFunctions.IsResStatus2XX(result)) return true;

		stateVars.IsUstYonetici = result?.data.isUstYonetici;
		stateVars.Kuika_SatisRaporu = result?.data.kuika_SatisRaporu;
		
		this.props.form?.setFieldsValue(formVars);
		
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.ReportSalesNebimPageInit1_();
                  resolve();
                });
          })



        
        KuikaAppManager.hideSpinner(this);
        return isErrorOccurred;
    }
	ReportSalesNebimPageInit1_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


	if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }

			
			stateVars.dataSource_251538899 = stateVars.Kuika_SatisRaporu ?? this.state.Kuika_SatisRaporu;

	this.props.form?.setFieldsValue(formVars);
	this.setState(stateVars);
	KuikaAppManager.hideSpinner(this);

            this.setPageInitLoaded(true);
            return isErrorOccurred;
        }




		ReportSalesNebimComponent_1603875421_onClick = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
KuikaAppManager.showSpinner(this);

				stateVars.SetValueOf = await ReactSystemFunctions.setValueOf(this, ReactSystemFunctions.convertToTypeByName("reportsalesnebim_1006957637_value", "string"), "", null, false);
				stateVars.SetValueOf = await ReactSystemFunctions.setValueOf(this, ReactSystemFunctions.convertToTypeByName("reportsalesnebim_475262368_value", "string"), "", null, false);
				stateVars.SetValueOf = await ReactSystemFunctions.setValueOf(this, ReactSystemFunctions.convertToTypeByName("reportsalesnebim_848442265_value", "string"), "", null, false);
				stateVars.SetValueOf = await ReactSystemFunctions.setValueOf(this, ReactSystemFunctions.convertToTypeByName("reportsalesnebim_6222002_value", "string"), "", null, false);
				stateVars.SetValueOf = await ReactSystemFunctions.setValueOf(this, ReactSystemFunctions.convertToTypeByName("reportsalesnebim_546313168_value", "string"), "", null, false);
				stateVars.SetValueOf = await ReactSystemFunctions.setValueOf(this, ReactSystemFunctions.convertToTypeByName("reportsalesnebim_773781625_value", "string"), "", null, false);
				stateVars.SetValueOf = await ReactSystemFunctions.setValueOf(this, ReactSystemFunctions.convertToTypeByName("reportsalesnebim_393438511_value", "string"), "", null, false);

		this.props.form?.setFieldsValue(formVars);
		
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.ReportSalesNebimComponent_1603875421_onClick1_();
                  resolve();
                });
          })

            
            return isErrorOccurred;
        }
    ReportSalesNebimComponent_1603875421_onClick1_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
		KuikaAppManager.increaseServerRequestCount();

        let localVar = {
				StartDate_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "reportsalesnebim_236931_value", "startValue", "", "", "")), "string"),
				EndDate_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "reportsalesnebim_236931_value", "endValue", "", "", "")), "string"),
				EFaturaSeriNo_0: ReactSystemFunctions.convertToTypeByName(null, "string"),
				FaturaRefNo_0: ReactSystemFunctions.convertToTypeByName(null, "string"),
				Marka_0: ReactSystemFunctions.convertToTypeByName(null, "string"),
				UrunGrubu_0: ReactSystemFunctions.convertToTypeByName(null, "string"),
				Material_0: ReactSystemFunctions.convertToTypeByName(null, "string"),
				Diameter_0: ReactSystemFunctions.convertToTypeByName(null, "string"),
				Family_0: ReactSystemFunctions.convertToTypeByName(null, "string"),
				IsUstYonetici_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toBoolean(this, (stateVars.IsUstYonetici !== undefined ? (stateVars.IsUstYonetici?.length > 0 ? stateVars.IsUstYonetici[0].isUstYonetici : null) : (this.state.IsUstYonetici?.length > 0 ? this.state.IsUstYonetici[0].isUstYonetici : null))), "boolean")
        }

		
        if (true) {
        KuikaAppManager.showSpinner(this);
        }
        let result = await KuikaAppManager.ApiRequest(this, "ReportSalesNebim/ReportSalesNebimComponent_1603875421_onClick1_", localVar)
        if (!KMainFunctions.IsResStatus2XX(result)) return true;

			stateVars.Kuika_SatisRaporu = result?.data.kuika_SatisRaporu;
			
			this.props.form?.setFieldsValue(formVars);
			
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.ReportSalesNebimComponent_1603875421_onClick2_();
                  resolve();
                });
          })



        
        KuikaAppManager.hideSpinner(this);
        return isErrorOccurred;
    }
		ReportSalesNebimComponent_1603875421_onClick2_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }

				
				stateVars.dataSource_251538899 = stateVars.Kuika_SatisRaporu ?? this.state.Kuika_SatisRaporu;

		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

            
            return isErrorOccurred;
        }





    ReportSalesNebimComponent_2136600364_onClick = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
		KuikaAppManager.increaseServerRequestCount();

        let localVar = {
				StartDate_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "reportsalesnebim_236931_value", "startValue", "", "", "")), "string"),
				EndDate_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "reportsalesnebim_236931_value", "endValue", "", "", "")), "string"),
				EFaturaSeriNo_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "reportsalesnebim_1006957637_value", "value", "", "", "")), "string"),
				FaturaRefNo_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "reportsalesnebim_475262368_value", "value", "", "", "")), "string"),
				Marka_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "reportsalesnebim_848442265_value", "value", "", "", "")), "string"),
				UrunGrubu_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "reportsalesnebim_6222002_value", "value", "", "", "")), "string"),
				Material_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "reportsalesnebim_546313168_value", "value", "", "", "")), "string"),
				Diameter_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "reportsalesnebim_773781625_value", "value", "", "", "")), "string"),
				Family_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "reportsalesnebim_393438511_value", "value", "", "", "")), "string"),
				IsUstYonetici_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toBoolean(this, (stateVars.IsUstYonetici !== undefined ? (stateVars.IsUstYonetici?.length > 0 ? stateVars.IsUstYonetici[0].isUstYonetici : null) : (this.state.IsUstYonetici?.length > 0 ? this.state.IsUstYonetici[0].isUstYonetici : null))), "boolean")
        }

		KuikaAppManager.showSpinner(this);
		
        if (true) {
        KuikaAppManager.showSpinner(this);
        }
        let result = await KuikaAppManager.ApiRequest(this, "ReportSalesNebim/ReportSalesNebimComponent_2136600364_onClick", localVar)
        if (!KMainFunctions.IsResStatus2XX(result)) return true;

			stateVars.Kuika_SatisRaporu = result?.data.kuika_SatisRaporu;
			
			this.props.form?.setFieldsValue(formVars);
			
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.ReportSalesNebimComponent_2136600364_onClick1_();
                  resolve();
                });
          })



        
        KuikaAppManager.hideSpinner(this);
        return isErrorOccurred;
    }
		ReportSalesNebimComponent_2136600364_onClick1_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }

				
				stateVars.dataSource_251538899 = stateVars.Kuika_SatisRaporu ?? this.state.Kuika_SatisRaporu;

		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

            
            return isErrorOccurred;
        }




    ReportSalesNebimComponent_348358059_onClick = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
		KuikaAppManager.increaseServerRequestCount();

        let localVar = {
				value_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, this.state.Kuika_SatisRaporu), "any"),
				header_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.convertToTypeByName("Satış Raporu", "string"), "string"),
				footer_0: ReactSystemFunctions.convertToTypeByName("", "string"),
				columns_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.convertToTypeByName("FaturaTarihi,EFaturaSeriNo,FaturaRefNo,MusteriAdi,MaddeAciklamasi,UrunSeriNumarasi,Marka,UrunGrubu,Model,Bracelet,Dial,Material,Diameter,Family,Prim,SatisSorumlusu,Miktar,Fiyat,Iskonto,NetTutar,Magaza,OfisKodu,DepoKodu", "string"), "string")
        }

		KuikaAppManager.showSpinner(this);
		
        if (true) {
        KuikaAppManager.showSpinner(this);
        }
        let result = await KuikaAppManager.ApiRequest(this, "ReportSalesNebim/ReportSalesNebimComponent_348358059_onClick", localVar)
        if (!KMainFunctions.IsResStatus2XX(result)) return true;

			stateVars.ExportExcel = result?.data.exportExcel;
			ReactSystemFunctions.downloadFile(result?.data?.exportExcel);
			this.props.form?.setFieldsValue(formVars);
			this.setState(stateVars);
			KuikaAppManager.hideSpinner(this);



        this.setPageInitLoaded(true);
        KuikaAppManager.hideSpinner(this);
        return isErrorOccurred;
    }





    async callCallbackFunction(diId: number, isFromMaster: boolean = false) {
        let isErrorOccurred = false;
		let pageInitCallerNavDiIDs = [] as number[];
		if (isFromMaster || pageInitCallerNavDiIDs.indexOf(diId) > -1) {
			await this.ReportSalesNebimPageInit();
		}

    }


}
