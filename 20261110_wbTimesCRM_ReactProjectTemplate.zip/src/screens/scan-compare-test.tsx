import * as React from "react";
import { DocumentCompare } from "../components/web-components";

export interface IScanCompareTestState {
  leftInput: string;
  rightInput: string;
  appliedLeft: string;
  appliedRight: string;
  scanEngine: "auto" | "scan" | "off";
}

export class ScanCompareTest extends React.PureComponent<{}, IScanCompareTestState> {
  state: IScanCompareTestState = {
    leftInput: "",
    rightInput: "",
    appliedLeft: "",
    appliedRight: "",
    scanEngine: "scan"
  };

  private apply = () => {
    this.setState({
      appliedLeft: this.state.leftInput.trim(),
      appliedRight: this.state.rightInput.trim()
    });
  };

  render() {
    const { leftInput, rightInput, appliedLeft, appliedRight, scanEngine } = this.state;
    const ready = Boolean(appliedLeft && appliedRight);

    return (
      <div
        style={{
          padding: 24,
          display: "flex",
          flexDirection: "column",
          gap: 12,
          height: "100vh",
          boxSizing: "border-box"
        }}
      >
        <h2 style={{ margin: 0 }}>Scan PDF Compare — Test</h2>

        <div style={{ display: "flex", gap: 8, alignItems: "center" }}>
          <label style={{ width: 140 }}>Left versionId</label>
          <input
            value={leftInput}
            onChange={(e) => this.setState({ leftInput: e.target.value })}
            placeholder="GUID of KDocumentVersion #1"
            style={{ flex: 1, padding: 6, fontFamily: "monospace" }}
          />
        </div>

        <div style={{ display: "flex", gap: 8, alignItems: "center" }}>
          <label style={{ width: 140 }}>Right versionId</label>
          <input
            value={rightInput}
            onChange={(e) => this.setState({ rightInput: e.target.value })}
            placeholder="GUID of KDocumentVersion #2"
            style={{ flex: 1, padding: 6, fontFamily: "monospace" }}
          />
        </div>

        <div style={{ display: "flex", gap: 8, alignItems: "center" }}>
          <label style={{ width: 140 }}>scanEngine</label>
          <select
            value={scanEngine}
            onChange={(e) => this.setState({ scanEngine: e.target.value as "auto" | "scan" | "off" })}
          >
            <option value="auto">auto</option>
            <option value="scan">scan</option>
            <option value="off">off</option>
          </select>
          <button onClick={this.apply} style={{ marginLeft: "auto", padding: "6px 16px" }}>
            Compare
          </button>
        </div>

        <div style={{ flex: 1, border: "1px solid #ddd", overflow: "hidden" }}>
          {ready ? (
            <DocumentCompare
              leftVersionId={appliedLeft}
              rightVersionId={appliedRight}
              scanEngine={scanEngine}
              locale="tr"
              style={{ width: "100%", height: "100%" }}
            />
          ) : (
            <div style={{ padding: 24, color: "#888" }}>
              İki versionId gir ve "Compare" bas. Sistemde var olan herhangi iki KDocumentVersion GUID'i kullanılabilir
              (örn. Swagger'dan GET /v1/api/documentmanagement/tree?showVersions=true).
            </div>
          )}
        </div>
      </div>
    );
  }
}
