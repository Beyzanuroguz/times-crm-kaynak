import React from "react";
import Axios, { AxiosResponse } from "axios";
import { KuikaAppManager } from "../../shared/utilty/kuika-app-manager";
import { ReactSystemFunctions } from "../../shared/utilty/react-system-functions";
import { KNavigator } from "../../shared/hoc/with-history";
import { KContext } from "../../shared/hoc/with-context";
import { useLocation } from "react-router-dom";
import { FormInstance } from "antd/es/form";
import { Guid } from "guid-typescript";
import Swal from "sweetalert2";
import { KMainFunctions } from "../../shared/utilty/main-functions";
import moment from "moment";
import { IValidationData } from "../../models/dto/validation-data";
import { IStripePayment } from "../../models/dto/stripe-payment";
import { IUserInfoDto } from "../../models/dto/user-info.dto";
import { UserService } from "../../services/user-service";
import { kuikaCoreWasmBridgeService } from "../../services/_singletons";
import _ from "lodash";
import mqtt, { MqttClient } from "mqtt";
import { IMqttResult } from "../../models/dto/mqtt.dto";
import { MasterScreen_ScreenContext } from "../masterscreen/masterscreen-context";

declare let window: any;

export interface IRolexBasedReporting_ScreenProps {
  navigator: KNavigator;
  form: FormInstance<any>;
  googleLogin: any;
  screenInputs: any;
  context: KContext;
  initialValues: any;
  children: any;
}

export interface IRolexBasedReporting_ScreenState {
    isSpinnerVisible: boolean;
    isPageVisible: boolean;
	isLeftMenuVisible: boolean;
    spinnerCount: number;
    selectedLanguage: string;
    isPageInitLoaded: false;
    isPageRecurringLoaded: false;
	Connect: any;
	Connect_dummy: any;
	KuikaY_MonthlyStoreSalesReport: any[];
	KuikaY_MonthlyStoreSalesReport_dummy: any[];
	Kuika_ReportProductSales: any[];
	Kuika_ReportProductSales_dummy: any[];
	KuikaY_RolexTudorMonthlyStoreComparison: any[];
	KuikaY_RolexTudorMonthlyStoreComparison_dummy: any[];
	NAVIGATE: any;
	NAVIGATE_dummy: any;
	ExportExcel: any;
	ExportExcel_dummy: any;
	ChangeVisibilityOf: string;
	ChangeVisibilityOf_dummy: string;
	isComp289497Visible: 'visible' | 'hidden';
	isComp374338Visible: 'visible' | 'hidden';
	isComp617199Visible: 'visible' | 'hidden';
	isComp209508Visible: 'visible' | 'hidden';
	isComp479325Visible: 'visible' | 'hidden';
	isComp483040Visible: 'visible' | 'hidden';
	isComp467053Visible: 'visible' | 'hidden';
	isComp42928Visible: 'visible' | 'hidden';
	isComp486906Visible: 'visible' | 'hidden';
	isComp240274Visible: 'visible' | 'hidden';
	isComp652365Visible: 'visible' | 'hidden';
	isComp499501Visible: 'visible' | 'hidden';
	isComp177639Visible: 'visible' | 'hidden';
	isComp38488Visible: 'visible' | 'hidden';
	isComp419092Visible: 'visible' | 'hidden';
	isComp881608Visible: 'visible' | 'hidden';
	isComp601942Visible: 'visible' | 'hidden';
	isComp775042Visible: 'visible' | 'hidden';
	isComp627812Visible: 'visible' | 'hidden';
	isComp27869Visible: 'visible' | 'hidden';
	isComp877601Visible: 'visible' | 'hidden';
	isComp741238Visible: 'visible' | 'hidden';
	isComp256065Visible: 'visible' | 'hidden';
	isComp110030Visible: 'visible' | 'hidden';
	isComp387073Visible: 'visible' | 'hidden';
	isComp109367Visible: 'visible' | 'hidden';
	isComp327182Visible: 'visible' | 'hidden';
	isComp962790Visible: 'visible' | 'hidden';
	isComp311696Visible: 'visible' | 'hidden';
	isComp65893Visible: 'visible' | 'hidden';
	isComp518033Visible: 'visible' | 'hidden';

}

export class RolexBasedReporting_ScreenBase extends React.PureComponent<IRolexBasedReporting_ScreenProps, any> {
    static contextType = MasterScreen_ScreenContext;
    declare context: React.ContextType<typeof MasterScreen_ScreenContext>;
	rolexbasedreporting_390370_value_kuikaTableRef: React.RefObject<any>;
	rolexbasedreporting_426992_value_kuikaTableRef: React.RefObject<any>;
	rolexbasedreporting_228396_value_kuikaTableRef: React.RefObject<any>;
	rolexbasedreporting_714039_value_kuikaTableRef: React.RefObject<any>;
	rolexbasedreporting_274772_value_kuikaTableRef: React.RefObject<any>;
	rolexbasedreporting_537831_value_kuikaTableRef: React.RefObject<any>;
	rolexbasedreporting_758267_value_kuikaTableRef: React.RefObject<any>;
	rolexbasedreporting_825743_value_kuikaTableRef: React.RefObject<any>;
	rolexbasedreporting_957664_value_kuikaTableRef: React.RefObject<any>;
	rolexbasedreporting_579551_value_kuikaTableRef: React.RefObject<any>;
	rolexbasedreporting_593146_value_kuikaTableRef: React.RefObject<any>;
	rolexbasedreporting_618412_value_kuikaTableRef: React.RefObject<any>;
	rolexbasedreporting_673384_value_kuikaTableRef: React.RefObject<any>;
    ml=[{"Id":"d5a61d2b-bd60-485f-86e2-661e9ed4e486","Name":"en_US","ShortName":"English","IsDefault":true,"LanguagePhrases":[]},{"Id":"9bee373d-7606-49b7-a6d8-0d70b581ff79","Name":"FixedValues","ShortName":"FixedValues","LanguagePhrases":[{"Id":910240,"PropertyName":"value","Value":"Marka Bazlı Raporlama"},{"Id":869891,"PropertyName":"value","Value":"Mağaza satış performanslarını karşılaştırmalı olarak analiz edin."},{"Id":696937,"PropertyName":"label","Value":"Rolex"},{"Id":935607,"PropertyName":"label","Value":"Tudor"},{"Id":801579,"PropertyName":"label","Value":"Mont Blanc"},{"Id":409815,"PropertyName":"label","Value":"Dupont"},{"Id":126713,"PropertyName":"value","Value":"Analiz Tipi"},{"Id":248363,"PropertyName":"value","Value":"Genel Satış"},{"Id":640909,"PropertyName":"value","Value":"Family Bazlı"},{"Id":774535,"PropertyName":"value","Value":"Material Bazlı"},{"Id":359129,"PropertyName":"value","Value":"Diameter Bazlı"},{"Id":384797,"PropertyName":"value","Value":"Ürün Grubu Bazlı"},{"Id":732085,"PropertyName":"value","Value":"Rolex-"},{"Id":916050,"PropertyName":"value","Value":"-Genel Satış Özeti"},{"Id":782867,"PropertyName":"placeholder","Value":"Select Year..."},{"Id":37878,"PropertyName":"value","Value":"Toplam Satış Adedi"},{"Id":48790,"PropertyName":"value","Value":"Bu Ayın Satış Adeti"},{"Id":793158,"PropertyName":"value","Value":"+18.5%"},{"Id":268030,"PropertyName":"value","Value":"-18.5%"},{"Id":609778,"PropertyName":"value","Value":"Geçen Yıla Göre Artış"},{"Id":134804,"PropertyName":"value","Value":"Yıllık Büyüme"},{"Id":833729,"PropertyName":"value","Value":"En Güçlü Mağaza"},{"Id":111309,"PropertyName":"value","Value":"En Çok Satan Family"},{"Id":316216,"PropertyName":"value","Value":"En Çok Satan Material"},{"Id":728536,"PropertyName":"value","Value":"Rolex-"},{"Id":381076,"PropertyName":"value","Value":"-Mağaza Bazlı Satış Özet Görünüm"},{"Id":556665,"PropertyName":"placeholder","Value":"Select Year..."},{"Id":691585,"PropertyName":"title","Value":"Mağaza"},{"Id":158532,"PropertyName":"value","Value":"[datafield:magaza]"},{"Id":939883,"PropertyName":"title","Value":"Ocak"},{"Id":311253,"PropertyName":"value","Value":"[datafield:ocak]"},{"Id":291688,"PropertyName":"title","Value":"Şubat"},{"Id":847475,"PropertyName":"value","Value":"[datafield:subat]"},{"Id":334016,"PropertyName":"title","Value":"Mart"},{"Id":985530,"PropertyName":"value","Value":"[datafield:mart]"},{"Id":389443,"PropertyName":"title","Value":"Nisan"},{"Id":654404,"PropertyName":"value","Value":"[datafield:nisan]"},{"Id":38336,"PropertyName":"title","Value":"Mayıs"},{"Id":974849,"PropertyName":"value","Value":"[datafield:mayis]"},{"Id":611269,"PropertyName":"title","Value":"Haziran"},{"Id":149634,"PropertyName":"value","Value":"[datafield:haziran]"},{"Id":921949,"PropertyName":"title","Value":"Temmuz"},{"Id":41637,"PropertyName":"value","Value":"[datafield:temmuz]"},{"Id":520163,"PropertyName":"title","Value":"Ağustos"},{"Id":186117,"PropertyName":"value","Value":"[datafield:agustos]"},{"Id":56238,"PropertyName":"title","Value":"Eylül"},{"Id":498459,"PropertyName":"value","Value":"[datafield:eylul]"},{"Id":716515,"PropertyName":"title","Value":"Ekim"},{"Id":71926,"PropertyName":"value","Value":"[datafield:ekim]"},{"Id":499659,"PropertyName":"title","Value":"Kasım"},{"Id":883864,"PropertyName":"value","Value":"[datafield:kasim]"},{"Id":913924,"PropertyName":"title","Value":"Aralık"},{"Id":922906,"PropertyName":"value","Value":"[datafield:aralik]"},{"Id":69137,"PropertyName":"title","Value":"Toplam"},{"Id":285126,"PropertyName":"value","Value":"[datafield:toplam]"},{"Id":339583,"PropertyName":"value","Value":"Aylık Satış Raporları - Rolex"},{"Id":81355,"PropertyName":"value","Value":"Yıl 1"},{"Id":904704,"PropertyName":"placeholder","Value":"Select Year..."},{"Id":484508,"PropertyName":"value","Value":"Yıl 2"},{"Id":307394,"PropertyName":"placeholder","Value":"Select Year..."},{"Id":241118,"PropertyName":"label","Value":"Çalıştır"},{"Id":255367,"PropertyName":"value","Value":"Aylık Satış Raporlarını Görmek için Raporu Çalıştırınız."},{"Id":384301,"PropertyName":"value","Value":"Ocak/"},{"Id":887862,"PropertyName":"value","Value":"-"},{"Id":865822,"PropertyName":"title","Value":"Mağaza"},{"Id":991309,"PropertyName":"value","Value":"[datafield:merkez]"},{"Id":132800,"PropertyName":"value","Value":"[datafield:ocak_yil1]"},{"Id":367047,"PropertyName":"value","Value":"[datafield:ocak_yil2]"},{"Id":699642,"PropertyName":"title","Value":"Değişim"},{"Id":42928,"PropertyName":"value","Value":"[datafield:ocakdegisim]"},{"Id":486906,"PropertyName":"value","Value":"[datafield:ocakdegisim]"},{"Id":221773,"PropertyName":"value","Value":"Şubat/"},{"Id":988324,"PropertyName":"value","Value":"-"},{"Id":114212,"PropertyName":"title","Value":"Mağaza"},{"Id":432679,"PropertyName":"value","Value":"[datafield:merkez]"},{"Id":459413,"PropertyName":"value","Value":"[datafield:subat_yil1]"},{"Id":737667,"PropertyName":"value","Value":"[datafield:subat_yil2]"},{"Id":394828,"PropertyName":"title","Value":"Değişim"},{"Id":240274,"PropertyName":"value","Value":"[datafield:subatdegisim]"},{"Id":652365,"PropertyName":"value","Value":"[datafield:subatdegisim]"},{"Id":993006,"PropertyName":"value","Value":"Mart/"},{"Id":279468,"PropertyName":"value","Value":"-"},{"Id":342549,"PropertyName":"title","Value":"Mağaza"},{"Id":577705,"PropertyName":"value","Value":"[datafield:merkez]"},{"Id":654021,"PropertyName":"value","Value":"[datafield:mart_yil1]"},{"Id":839206,"PropertyName":"value","Value":"[datafield:mart_yil2]"},{"Id":854752,"PropertyName":"title","Value":"Değişim"},{"Id":499501,"PropertyName":"value","Value":"[datafield:martdegisim]"},{"Id":177639,"PropertyName":"value","Value":"[datafield:martdegisim]"},{"Id":89604,"PropertyName":"value","Value":"Nisan/"},{"Id":714835,"PropertyName":"value","Value":"-"},{"Id":4904,"PropertyName":"title","Value":"Mağaza"},{"Id":321949,"PropertyName":"value","Value":"[datafield:merkez]"},{"Id":93168,"PropertyName":"value","Value":"[datafield:nisan_yil1]"},{"Id":863110,"PropertyName":"value","Value":"[datafield:nisan_yil2]"},{"Id":479452,"PropertyName":"title","Value":"Değişim"},{"Id":38488,"PropertyName":"value","Value":"[datafield:nisandegisim]"},{"Id":419092,"PropertyName":"value","Value":"[datafield:nisandegisim]"},{"Id":704721,"PropertyName":"value","Value":"Mayıs/"},{"Id":154959,"PropertyName":"value","Value":"-"},{"Id":233463,"PropertyName":"title","Value":"Mağaza"},{"Id":727411,"PropertyName":"value","Value":"[datafield:merkez]"},{"Id":521835,"PropertyName":"value","Value":"[datafield:mayis_yil1]"},{"Id":971565,"PropertyName":"value","Value":"[datafield:mayis_yil2]"},{"Id":350107,"PropertyName":"title","Value":"Değişim"},{"Id":881608,"PropertyName":"value","Value":"[datafield:mayisdegisim]"},{"Id":601942,"PropertyName":"value","Value":"[datafield:mayisdegisim]"},{"Id":858462,"PropertyName":"value","Value":"Haziran/"},{"Id":457030,"PropertyName":"value","Value":"-"},{"Id":53055,"PropertyName":"title","Value":"Mağaza"},{"Id":324304,"PropertyName":"value","Value":"[datafield:merkez]"},{"Id":343183,"PropertyName":"value","Value":"[datafield:haziran_yil1]"},{"Id":912903,"PropertyName":"value","Value":"[datafield:haziran_yil2]"},{"Id":264391,"PropertyName":"title","Value":"Değişim"},{"Id":775042,"PropertyName":"value","Value":"[datafield:hazirandegisim]"},{"Id":627812,"PropertyName":"value","Value":"[datafield:hazirandegisim]"},{"Id":253842,"PropertyName":"value","Value":"Temmuz/"},{"Id":785724,"PropertyName":"value","Value":"-"},{"Id":781338,"PropertyName":"title","Value":"Mağaza"},{"Id":400109,"PropertyName":"value","Value":"[datafield:merkez]"},{"Id":184557,"PropertyName":"value","Value":"[datafield:temmuz_yil1]"},{"Id":235924,"PropertyName":"value","Value":"[datafield:temmuz_yil2]"},{"Id":744089,"PropertyName":"title","Value":"Değişim"},{"Id":27869,"PropertyName":"value","Value":"[datafield:temmuzdegisim]"},{"Id":877601,"PropertyName":"value","Value":"[datafield:temmuzdegisim]"},{"Id":155813,"PropertyName":"value","Value":"Ağustos/"},{"Id":689733,"PropertyName":"value","Value":"-"},{"Id":756881,"PropertyName":"title","Value":"Mağaza"},{"Id":737806,"PropertyName":"value","Value":"[datafield:merkez]"},{"Id":472874,"PropertyName":"value","Value":"[datafield:agustos_yil1]"},{"Id":676376,"PropertyName":"value","Value":"[datafield:agustos_yil2]"},{"Id":185070,"PropertyName":"title","Value":"Değişim"},{"Id":741238,"PropertyName":"value","Value":"[datafield:agustosdegisim]"},{"Id":256065,"PropertyName":"value","Value":"[datafield:agustosdegisim]"},{"Id":933237,"PropertyName":"value","Value":"Eylül/"},{"Id":912064,"PropertyName":"value","Value":"-"},{"Id":234774,"PropertyName":"title","Value":"Mağaza"},{"Id":697413,"PropertyName":"value","Value":"[datafield:merkez]"},{"Id":128221,"PropertyName":"value","Value":"[datafield:eylul_yil1]"},{"Id":91685,"PropertyName":"value","Value":"[datafield:eylul_yil2]"},{"Id":910546,"PropertyName":"title","Value":"Değişim"},{"Id":110030,"PropertyName":"value","Value":"[datafield:eyluldegisim]"},{"Id":387073,"PropertyName":"value","Value":"[datafield:eyluldegisim]"},{"Id":135190,"PropertyName":"value","Value":"Ekim/"},{"Id":302363,"PropertyName":"value","Value":"-"},{"Id":787271,"PropertyName":"title","Value":"Mağaza"},{"Id":785424,"PropertyName":"value","Value":"[datafield:merkez]"},{"Id":445847,"PropertyName":"value","Value":"[datafield:ekim_yil1]"},{"Id":290179,"PropertyName":"value","Value":"[datafield:ekim_yil2]"},{"Id":906614,"PropertyName":"title","Value":"Değişim"},{"Id":109367,"PropertyName":"value","Value":"[datafield:ekimdegisim]"},{"Id":327182,"PropertyName":"value","Value":"[datafield:ekimdegisim]"},{"Id":836554,"PropertyName":"value","Value":"Kasım/"},{"Id":35258,"PropertyName":"value","Value":"-"},{"Id":6515,"PropertyName":"title","Value":"Mağaza"},{"Id":978931,"PropertyName":"value","Value":"[datafield:merkez]"},{"Id":972988,"PropertyName":"value","Value":"[datafield:kasim_yil1]"},{"Id":188618,"PropertyName":"value","Value":"[datafield:kasim_yil2]"},{"Id":657150,"PropertyName":"title","Value":"Değişim"},{"Id":962790,"PropertyName":"value","Value":"[datafield:kasimdegisim]"},{"Id":311696,"PropertyName":"value","Value":"[datafield:kasimdegisim]"},{"Id":186793,"PropertyName":"value","Value":"Aralık/"},{"Id":829245,"PropertyName":"value","Value":"-"},{"Id":679267,"PropertyName":"title","Value":"Mağaza"},{"Id":286552,"PropertyName":"value","Value":"[datafield:merkez]"},{"Id":961246,"PropertyName":"value","Value":"[datafield:aralik_yil1]"},{"Id":823004,"PropertyName":"value","Value":"[datafield:aralik_yil2]"},{"Id":931847,"PropertyName":"title","Value":"Değişim"},{"Id":65893,"PropertyName":"value","Value":"[datafield:aralikdegisim]"},{"Id":518033,"PropertyName":"value","Value":"[datafield:aralikdegisim]"}]}]
    defaultML = "en_US"
    
    screenHash = ""
    

    private _prevMasterPageInitLoaded: boolean = false;
    private _prevMasterPageRecurringLoaded: boolean = false;
    private _prevShouldTriggerPageInit: boolean = false;
    constructor(props) {
        super(props);
		this.rolexbasedreporting_390370_value_kuikaTableRef = React.createRef();
		this.rolexbasedreporting_426992_value_kuikaTableRef = React.createRef();
		this.rolexbasedreporting_228396_value_kuikaTableRef = React.createRef();
		this.rolexbasedreporting_714039_value_kuikaTableRef = React.createRef();
		this.rolexbasedreporting_274772_value_kuikaTableRef = React.createRef();
		this.rolexbasedreporting_537831_value_kuikaTableRef = React.createRef();
		this.rolexbasedreporting_758267_value_kuikaTableRef = React.createRef();
		this.rolexbasedreporting_825743_value_kuikaTableRef = React.createRef();
		this.rolexbasedreporting_957664_value_kuikaTableRef = React.createRef();
		this.rolexbasedreporting_579551_value_kuikaTableRef = React.createRef();
		this.rolexbasedreporting_593146_value_kuikaTableRef = React.createRef();
		this.rolexbasedreporting_618412_value_kuikaTableRef = React.createRef();
		this.rolexbasedreporting_673384_value_kuikaTableRef = React.createRef();

        this.state = {
            isSpinnerVisible: false,
            isPageVisible: false,
            isLeftMenuVisible: false,
            spinnerCount: 0,
            selectedLanguage: "",
            isPageInitLoaded: false,
            isPageRecurringLoaded: false,
            	        Connect: "",
	        KuikaY_MonthlyStoreSalesReport: [],
	        Kuika_ReportProductSales: [],
	        KuikaY_RolexTudorMonthlyStoreComparison: [],
	        NAVIGATE: "",
	        ExportExcel: "",
	        ChangeVisibilityOf: "",
	        isComp289497Visible: 'visible',
	        isComp374338Visible: 'hidden',
	        isComp617199Visible: 'hidden',
	        isComp209508Visible: 'hidden',
	        isComp479325Visible: 'hidden',
	        isComp483040Visible: 'hidden',
	        isComp467053Visible: 'hidden',
	        isComp42928Visible: 'hidden',
	        isComp486906Visible: 'hidden',
	        isComp240274Visible: 'hidden',
	        isComp652365Visible: 'hidden',
	        isComp499501Visible: 'hidden',
	        isComp177639Visible: 'hidden',
	        isComp38488Visible: 'hidden',
	        isComp419092Visible: 'hidden',
	        isComp881608Visible: 'hidden',
	        isComp601942Visible: 'hidden',
	        isComp775042Visible: 'hidden',
	        isComp627812Visible: 'hidden',
	        isComp27869Visible: 'hidden',
	        isComp877601Visible: 'hidden',
	        isComp741238Visible: 'hidden',
	        isComp256065Visible: 'hidden',
	        isComp110030Visible: 'hidden',
	        isComp387073Visible: 'hidden',
	        isComp109367Visible: 'hidden',
	        isComp327182Visible: 'hidden',
	        isComp962790Visible: 'hidden',
	        isComp311696Visible: 'hidden',
	        isComp65893Visible: 'hidden',
	        isComp518033Visible: 'hidden',

        }

        this.state.isPageVisible = true;
        
    }

    async componentDidMount() {

        if (KuikaAppManager.isPageInitPrevented()) {
            KuikaAppManager.calculateAndSetBodyHeight("rolexbasedreporting", "masterscreen_screen");
            return;
        }
        this.context.registerCallbackFunction(this.callCallbackFunction.bind(this));
        
        ReactSystemFunctions.validateToken()
        this.fillFormInitValues();
        if (false){
            await this.RolexBasedReportingPageInit();
        } else if (this.context?.isMasterPageInitLoaded) { this._prevMasterPageInitLoaded = true; await this.RolexBasedReportingPageInit(); }
        
        
        
        KuikaAppManager.calculateAndSetBodyHeight("rolexbasedreporting", "masterscreen_screen");

        if (ReactSystemFunctions.getIsMicroApp() === false) {
           window.parentScreen = this;
        }
    }

    componentWillUnmount() {
        
        
        

        if (ReactSystemFunctions.getIsMicroApp() === false) {
           window.parentScreen = null;
        }
    }

    

        
    componentDidUpdate= async (prevProps, prevState) => {
		KuikaAppManager.calculateAndSetBodyHeight("rolexbasedreporting", "masterscreen_screen"    );
        if (prevProps?.location?.search !== (this.props as any)?.location?.search) {
			await this.RolexBasedReportingPageInit();
		}

        		if (this._prevMasterPageInitLoaded !== this.context.isMasterPageInitLoaded && this.context.isMasterPageInitLoaded === true) {this._prevMasterPageInitLoaded = this.context.isMasterPageInitLoaded;await this.RolexBasedReportingPageInit()}


        if (ReactSystemFunctions.getIsMicroApp() === false) {
            for (const key in prevState) {
                if (key.startsWith('NavVisible') && prevState[key] === true && this.state[key] === false) {
                    window.parentScreen = this;
                    break;
                }
            }
        }
	}

    fillFormInitValues() {
        this.props.form?.setFieldsValue({
rolexbasedreporting_782867_value: 2026,
rolexbasedreporting_556665_value: 2026,
rolexbasedreporting_904704_value: 2025,
rolexbasedreporting_307394_value: 2026
});

    }

      setPageInitLoaded = (value: boolean) => {
        this.setState({ isPageInitLoaded: value });
      }

      setPageRecurringLoaded = (value: boolean) => {
        this.setState({ isPageRecurringLoaded: value });
      }

      clearFieldValidation = (changedValues: any) => {
        const fieldName = Object.keys(changedValues)[0];
        if (fieldName) {
          this.props.form?.setFields([
            {
              name: fieldName,
              errors: []
            }
          ]);
        }
      };

      

    RolexBasedReportingPageInit = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


	if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }

        let localVar = {
			Brand_1: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.convertToTypeByName("Rolex", "string"), "string"),
			ProductGroup_1: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.convertToTypeByName("Kol Saati", "string"), "string"),
			Year_1: ReactSystemFunctions.convertToTypeByName(2026, "number"),
			Marka_2: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.convertToTypeByName("Rolex", "string"), "string"),
			UrunGrubu_2: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.convertToTypeByName("kol saati", "string"), "string"),
			Year_2: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "rolexbasedreporting_782867_value", "value", "", "", "")), "number"),
			Brand_3: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.convertToTypeByName("Rolex", "string"), "string"),
			ProductGroup_3: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.convertToTypeByName("Kol Saati", "string"), "string"),
			Year1_3: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "rolexbasedreporting_904704_value", "value", "", "", "")), "number"),
			Year2_3: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "rolexbasedreporting_307394_value", "value", "", "", "")), "number")
        }

	KuikaAppManager.showSpinner(this);
	
        if (true) {
        KuikaAppManager.showSpinner(this);
        }
        let result = await KuikaAppManager.ApiRequest(this, "RolexBasedReporting/RolexBasedReportingPageInit", localVar)
        if (!KMainFunctions.IsResStatus2XX(result)) return true;

		stateVars.KuikaY_MonthlyStoreSalesReport = result?.data.kuikaY_MonthlyStoreSalesReport;
		
		stateVars.Kuika_ReportProductSales = result?.data.kuika_ReportProductSales;
		formVars.rolexbasedreporting_142273_value = ReactSystemFunctions.toString(this, (stateVars.Kuika_ReportProductSales !== undefined ? (stateVars.Kuika_ReportProductSales?.length > 0 ? stateVars.Kuika_ReportProductSales[0].toplamSatisAdedi : null) : (this.state.Kuika_ReportProductSales?.length > 0 ? this.state.Kuika_ReportProductSales[0].toplamSatisAdedi : null)));
		formVars.rolexbasedreporting_833488_value = ReactSystemFunctions.toString(this, (stateVars.Kuika_ReportProductSales !== undefined ? (stateVars.Kuika_ReportProductSales?.length > 0 ? stateVars.Kuika_ReportProductSales[0].gecenYilaGoreArtisYuzde : null) : (this.state.Kuika_ReportProductSales?.length > 0 ? this.state.Kuika_ReportProductSales[0].gecenYilaGoreArtisYuzde : null)));
		formVars.rolexbasedreporting_232881_value = ReactSystemFunctions.toString(this, (stateVars.Kuika_ReportProductSales !== undefined ? (stateVars.Kuika_ReportProductSales?.length > 0 ? stateVars.Kuika_ReportProductSales[0].gecenYilaGoreArtisYuzde : null) : (this.state.Kuika_ReportProductSales?.length > 0 ? this.state.Kuika_ReportProductSales[0].gecenYilaGoreArtisYuzde : null)));
		formVars.rolexbasedreporting_862873_value = ReactSystemFunctions.toString(this, (stateVars.Kuika_ReportProductSales !== undefined ? (stateVars.Kuika_ReportProductSales?.length > 0 ? stateVars.Kuika_ReportProductSales[0].bulundugumuzAySatisAdedi : null) : (this.state.Kuika_ReportProductSales?.length > 0 ? this.state.Kuika_ReportProductSales[0].bulundugumuzAySatisAdedi : null)));
		formVars.rolexbasedreporting_442377_value = ReactSystemFunctions.toString(this, (stateVars.Kuika_ReportProductSales !== undefined ? (stateVars.Kuika_ReportProductSales?.length > 0 ? stateVars.Kuika_ReportProductSales[0].gecenYilaGoreArtisYuzde : null) : (this.state.Kuika_ReportProductSales?.length > 0 ? this.state.Kuika_ReportProductSales[0].gecenYilaGoreArtisYuzde : null)));
		formVars.rolexbasedreporting_49365_value = ReactSystemFunctions.toString(this, (stateVars.Kuika_ReportProductSales !== undefined ? (stateVars.Kuika_ReportProductSales?.length > 0 ? stateVars.Kuika_ReportProductSales[0].enGucluMagazaDesc : null) : (this.state.Kuika_ReportProductSales?.length > 0 ? this.state.Kuika_ReportProductSales[0].enGucluMagazaDesc : null)));
		formVars.rolexbasedreporting_689773_value = ReactSystemFunctions.toString(this, (stateVars.Kuika_ReportProductSales !== undefined ? (stateVars.Kuika_ReportProductSales?.length > 0 ? stateVars.Kuika_ReportProductSales[0].enGucluMagazaCiro : null) : (this.state.Kuika_ReportProductSales?.length > 0 ? this.state.Kuika_ReportProductSales[0].enGucluMagazaCiro : null)));
		formVars.rolexbasedreporting_662229_value = ReactSystemFunctions.toString(this, (stateVars.Kuika_ReportProductSales !== undefined ? (stateVars.Kuika_ReportProductSales?.length > 0 ? stateVars.Kuika_ReportProductSales[0].enCokSatanFamily : null) : (this.state.Kuika_ReportProductSales?.length > 0 ? this.state.Kuika_ReportProductSales[0].enCokSatanFamily : null)));
		formVars.rolexbasedreporting_825140_value = ReactSystemFunctions.toString(this, (stateVars.Kuika_ReportProductSales !== undefined ? (stateVars.Kuika_ReportProductSales?.length > 0 ? stateVars.Kuika_ReportProductSales[0].enCokSatanFamilyAdet : null) : (this.state.Kuika_ReportProductSales?.length > 0 ? this.state.Kuika_ReportProductSales[0].enCokSatanFamilyAdet : null)));
		formVars.rolexbasedreporting_51555_value = ReactSystemFunctions.toString(this, (stateVars.Kuika_ReportProductSales !== undefined ? (stateVars.Kuika_ReportProductSales?.length > 0 ? stateVars.Kuika_ReportProductSales[0].enCokSatanMaterial : null) : (this.state.Kuika_ReportProductSales?.length > 0 ? this.state.Kuika_ReportProductSales[0].enCokSatanMaterial : null)));
		formVars.rolexbasedreporting_816749_value = ReactSystemFunctions.toString(this, (stateVars.Kuika_ReportProductSales !== undefined ? (stateVars.Kuika_ReportProductSales?.length > 0 ? stateVars.Kuika_ReportProductSales[0].enCokSatanMaterialCiro : null) : (this.state.Kuika_ReportProductSales?.length > 0 ? this.state.Kuika_ReportProductSales[0].enCokSatanMaterialCiro : null)));
		stateVars.KuikaY_RolexTudorMonthlyStoreComparison = result?.data.kuikaY_RolexTudorMonthlyStoreComparison;
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		this.props.form?.setFieldsValue(formVars);
		
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.RolexBasedReportingPageInit1_();
                  resolve();
                });
          })



        
        KuikaAppManager.hideSpinner(this);
        return isErrorOccurred;
    }
	RolexBasedReportingPageInit1_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


	if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }

			ReactSystemFunctions.setValueOf(this, "rolexbasedreporting_603136_toString", ReactSystemFunctions.value(this, "rolexbasedreporting_782867_value", "value"), "value");

			formVars.rolexbasedreporting_142273_value = ReactSystemFunctions.toString(this, (stateVars.Kuika_ReportProductSales !== undefined ? (stateVars.Kuika_ReportProductSales?.length > 0 ? stateVars.Kuika_ReportProductSales[0].toplamSatisAdedi : null) : (this.state.Kuika_ReportProductSales?.length > 0 ? this.state.Kuika_ReportProductSales[0].toplamSatisAdedi : null)));

			formVars.rolexbasedreporting_833488_value = ReactSystemFunctions.toString(this, (stateVars.Kuika_ReportProductSales !== undefined ? (stateVars.Kuika_ReportProductSales?.length > 0 ? stateVars.Kuika_ReportProductSales[0].gecenYilaGoreArtisYuzde : null) : (this.state.Kuika_ReportProductSales?.length > 0 ? this.state.Kuika_ReportProductSales[0].gecenYilaGoreArtisYuzde : null)));

			formVars.rolexbasedreporting_232881_value = ReactSystemFunctions.toString(this, (stateVars.Kuika_ReportProductSales !== undefined ? (stateVars.Kuika_ReportProductSales?.length > 0 ? stateVars.Kuika_ReportProductSales[0].gecenYilaGoreArtisYuzde : null) : (this.state.Kuika_ReportProductSales?.length > 0 ? this.state.Kuika_ReportProductSales[0].gecenYilaGoreArtisYuzde : null)));

			formVars.rolexbasedreporting_862873_value = ReactSystemFunctions.toString(this, (stateVars.Kuika_ReportProductSales !== undefined ? (stateVars.Kuika_ReportProductSales?.length > 0 ? stateVars.Kuika_ReportProductSales[0].bulundugumuzAySatisAdedi : null) : (this.state.Kuika_ReportProductSales?.length > 0 ? this.state.Kuika_ReportProductSales[0].bulundugumuzAySatisAdedi : null)));

			formVars.rolexbasedreporting_442377_value = ReactSystemFunctions.toString(this, (stateVars.Kuika_ReportProductSales !== undefined ? (stateVars.Kuika_ReportProductSales?.length > 0 ? stateVars.Kuika_ReportProductSales[0].gecenYilaGoreArtisYuzde : null) : (this.state.Kuika_ReportProductSales?.length > 0 ? this.state.Kuika_ReportProductSales[0].gecenYilaGoreArtisYuzde : null)));

			formVars.rolexbasedreporting_49365_value = ReactSystemFunctions.toString(this, (stateVars.Kuika_ReportProductSales !== undefined ? (stateVars.Kuika_ReportProductSales?.length > 0 ? stateVars.Kuika_ReportProductSales[0].enGucluMagazaDesc : null) : (this.state.Kuika_ReportProductSales?.length > 0 ? this.state.Kuika_ReportProductSales[0].enGucluMagazaDesc : null)));

			formVars.rolexbasedreporting_689773_value = ReactSystemFunctions.toString(this, (stateVars.Kuika_ReportProductSales !== undefined ? (stateVars.Kuika_ReportProductSales?.length > 0 ? stateVars.Kuika_ReportProductSales[0].enGucluMagazaCiro : null) : (this.state.Kuika_ReportProductSales?.length > 0 ? this.state.Kuika_ReportProductSales[0].enGucluMagazaCiro : null)));

			formVars.rolexbasedreporting_662229_value = ReactSystemFunctions.toString(this, (stateVars.Kuika_ReportProductSales !== undefined ? (stateVars.Kuika_ReportProductSales?.length > 0 ? stateVars.Kuika_ReportProductSales[0].enCokSatanFamily : null) : (this.state.Kuika_ReportProductSales?.length > 0 ? this.state.Kuika_ReportProductSales[0].enCokSatanFamily : null)));

			formVars.rolexbasedreporting_825140_value = ReactSystemFunctions.toString(this, (stateVars.Kuika_ReportProductSales !== undefined ? (stateVars.Kuika_ReportProductSales?.length > 0 ? stateVars.Kuika_ReportProductSales[0].enCokSatanFamilyAdet : null) : (this.state.Kuika_ReportProductSales?.length > 0 ? this.state.Kuika_ReportProductSales[0].enCokSatanFamilyAdet : null)));

			formVars.rolexbasedreporting_51555_value = ReactSystemFunctions.toString(this, (stateVars.Kuika_ReportProductSales !== undefined ? (stateVars.Kuika_ReportProductSales?.length > 0 ? stateVars.Kuika_ReportProductSales[0].enCokSatanMaterial : null) : (this.state.Kuika_ReportProductSales?.length > 0 ? this.state.Kuika_ReportProductSales[0].enCokSatanMaterial : null)));

			formVars.rolexbasedreporting_816749_value = ReactSystemFunctions.toString(this, (stateVars.Kuika_ReportProductSales !== undefined ? (stateVars.Kuika_ReportProductSales?.length > 0 ? stateVars.Kuika_ReportProductSales[0].enCokSatanMaterialCiro : null) : (this.state.Kuika_ReportProductSales?.length > 0 ? this.state.Kuika_ReportProductSales[0].enCokSatanMaterialCiro : null)));

			ReactSystemFunctions.setValueOf(this, "rolexbasedreporting_456834_toString", ReactSystemFunctions.value(this, "rolexbasedreporting_556665_value", "value"), "value");

			
			stateVars.dataSource_390370 = stateVars.KuikaY_MonthlyStoreSalesReport ?? this.state.KuikaY_MonthlyStoreSalesReport;
			ReactSystemFunctions.setValueOf(this, "rolexbasedreporting_84776_toString", ReactSystemFunctions.value(this, "rolexbasedreporting_904704_value", "value"), "value");

			ReactSystemFunctions.setValueOf(this, "rolexbasedreporting_848372_toString", ReactSystemFunctions.value(this, "rolexbasedreporting_307394_value", "value"), "value");

			
			stateVars.dataSource_426992 = stateVars.KuikaY_RolexTudorMonthlyStoreComparison ?? this.state.KuikaY_RolexTudorMonthlyStoreComparison;
			
			
			stateVars.isComp42928Visible = ((ReactSystemFunctions.isGreaterOrEqual(ReactSystemFunctions.value(this, "rolexbasedreporting_426992_value", "ocakDegisim"), ReactSystemFunctions.convertToTypeByName("0", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp486906Visible = ((ReactSystemFunctions.isLessThan(ReactSystemFunctions.value(this, "rolexbasedreporting_426992_value", "ocakDegisim"), ReactSystemFunctions.convertToTypeByName("0", "string"))) === true ? "visible" : "hidden")
			
			stateVars.dataSource_810137 = stateVars.KuikaY_RolexTudorMonthlyStoreComparison ?? this.state.KuikaY_RolexTudorMonthlyStoreComparison;
			ReactSystemFunctions.setValueOf(this, "rolexbasedreporting_873004_toString", ReactSystemFunctions.value(this, "rolexbasedreporting_904704_value", "value"), "value");

			ReactSystemFunctions.setValueOf(this, "rolexbasedreporting_74906_toString", ReactSystemFunctions.value(this, "rolexbasedreporting_307394_value", "value"), "value");

			
			stateVars.dataSource_228396 = stateVars.KuikaY_RolexTudorMonthlyStoreComparison ?? this.state.KuikaY_RolexTudorMonthlyStoreComparison;
			
			
			stateVars.isComp240274Visible = ((ReactSystemFunctions.isGreaterOrEqual(ReactSystemFunctions.value(this, "rolexbasedreporting_228396_value", "subatDegisim"), ReactSystemFunctions.convertToTypeByName("0", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp652365Visible = ((ReactSystemFunctions.isLessThan(ReactSystemFunctions.value(this, "rolexbasedreporting_228396_value", "subatDegisim"), ReactSystemFunctions.convertToTypeByName("0", "string"))) === true ? "visible" : "hidden")
			
			stateVars.dataSource_886877 = stateVars.KuikaY_RolexTudorMonthlyStoreComparison ?? this.state.KuikaY_RolexTudorMonthlyStoreComparison;
			ReactSystemFunctions.setValueOf(this, "rolexbasedreporting_695756_toString", ReactSystemFunctions.value(this, "rolexbasedreporting_904704_value", "value"), "value");

			ReactSystemFunctions.setValueOf(this, "rolexbasedreporting_839527_toString", ReactSystemFunctions.value(this, "rolexbasedreporting_307394_value", "value"), "value");

			
			stateVars.dataSource_714039 = stateVars.KuikaY_RolexTudorMonthlyStoreComparison ?? this.state.KuikaY_RolexTudorMonthlyStoreComparison;
			
			
			stateVars.isComp499501Visible = ((ReactSystemFunctions.isGreaterOrEqual(ReactSystemFunctions.value(this, "rolexbasedreporting_714039_value", "martDegisim"), ReactSystemFunctions.convertToTypeByName("0", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp177639Visible = ((ReactSystemFunctions.isLessThan(ReactSystemFunctions.value(this, "rolexbasedreporting_714039_value", "martDegisim"), ReactSystemFunctions.convertToTypeByName("0", "string"))) === true ? "visible" : "hidden")
			
			stateVars.dataSource_258313 = stateVars.KuikaY_RolexTudorMonthlyStoreComparison ?? this.state.KuikaY_RolexTudorMonthlyStoreComparison;
			ReactSystemFunctions.setValueOf(this, "rolexbasedreporting_739479_toString", ReactSystemFunctions.value(this, "rolexbasedreporting_904704_value", "value"), "value");

			ReactSystemFunctions.setValueOf(this, "rolexbasedreporting_45154_toString", ReactSystemFunctions.value(this, "rolexbasedreporting_307394_value", "value"), "value");

			
			stateVars.dataSource_274772 = stateVars.KuikaY_RolexTudorMonthlyStoreComparison ?? this.state.KuikaY_RolexTudorMonthlyStoreComparison;
			
			
			stateVars.isComp38488Visible = ((ReactSystemFunctions.isGreaterOrEqual(ReactSystemFunctions.value(this, "rolexbasedreporting_274772_value", "nisanDegisim"), ReactSystemFunctions.convertToTypeByName("0", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp419092Visible = ((ReactSystemFunctions.isLessThan(ReactSystemFunctions.value(this, "rolexbasedreporting_274772_value", "nisanDegisim"), ReactSystemFunctions.convertToTypeByName("0", "string"))) === true ? "visible" : "hidden")
			
			stateVars.dataSource_621009 = stateVars.KuikaY_RolexTudorMonthlyStoreComparison ?? this.state.KuikaY_RolexTudorMonthlyStoreComparison;
			ReactSystemFunctions.setValueOf(this, "rolexbasedreporting_733552_toString", ReactSystemFunctions.value(this, "rolexbasedreporting_904704_value", "value"), "value");

			ReactSystemFunctions.setValueOf(this, "rolexbasedreporting_898130_toString", ReactSystemFunctions.value(this, "rolexbasedreporting_307394_value", "value"), "value");

			
			stateVars.dataSource_537831 = stateVars.KuikaY_RolexTudorMonthlyStoreComparison ?? this.state.KuikaY_RolexTudorMonthlyStoreComparison;
			
			
			stateVars.isComp881608Visible = ((ReactSystemFunctions.isGreaterOrEqual(ReactSystemFunctions.value(this, "rolexbasedreporting_537831_value", "mayisDegisim"), ReactSystemFunctions.convertToTypeByName("0", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp601942Visible = ((ReactSystemFunctions.isLessThan(ReactSystemFunctions.value(this, "rolexbasedreporting_537831_value", "mayisDegisim"), ReactSystemFunctions.convertToTypeByName("0", "string"))) === true ? "visible" : "hidden")
			
			stateVars.dataSource_671268 = stateVars.KuikaY_RolexTudorMonthlyStoreComparison ?? this.state.KuikaY_RolexTudorMonthlyStoreComparison;
			ReactSystemFunctions.setValueOf(this, "rolexbasedreporting_191176_toString", ReactSystemFunctions.value(this, "rolexbasedreporting_904704_value", "value"), "value");

			ReactSystemFunctions.setValueOf(this, "rolexbasedreporting_971542_toString", ReactSystemFunctions.value(this, "rolexbasedreporting_307394_value", "value"), "value");

			
			stateVars.dataSource_758267 = stateVars.KuikaY_RolexTudorMonthlyStoreComparison ?? this.state.KuikaY_RolexTudorMonthlyStoreComparison;
			
			
			stateVars.isComp775042Visible = ((ReactSystemFunctions.isGreaterOrEqual(ReactSystemFunctions.value(this, "rolexbasedreporting_758267_value", "haziranDegisim"), ReactSystemFunctions.convertToTypeByName("0", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp627812Visible = ((ReactSystemFunctions.isLessThan(ReactSystemFunctions.value(this, "rolexbasedreporting_758267_value", "haziranDegisim"), ReactSystemFunctions.convertToTypeByName("0", "string"))) === true ? "visible" : "hidden")
			
			stateVars.dataSource_632646 = stateVars.KuikaY_RolexTudorMonthlyStoreComparison ?? this.state.KuikaY_RolexTudorMonthlyStoreComparison;
			ReactSystemFunctions.setValueOf(this, "rolexbasedreporting_595413_toString", ReactSystemFunctions.value(this, "rolexbasedreporting_904704_value", "value"), "value");

			ReactSystemFunctions.setValueOf(this, "rolexbasedreporting_25718_toString", ReactSystemFunctions.value(this, "rolexbasedreporting_307394_value", "value"), "value");

			
			stateVars.dataSource_825743 = stateVars.KuikaY_RolexTudorMonthlyStoreComparison ?? this.state.KuikaY_RolexTudorMonthlyStoreComparison;
			
			
			stateVars.isComp27869Visible = ((ReactSystemFunctions.isGreaterOrEqual(ReactSystemFunctions.value(this, "rolexbasedreporting_825743_value", "temmuzDegisim"), ReactSystemFunctions.convertToTypeByName("0", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp877601Visible = ((ReactSystemFunctions.isLessThan(ReactSystemFunctions.value(this, "rolexbasedreporting_825743_value", "temmuzDegisim"), ReactSystemFunctions.convertToTypeByName("0", "string"))) === true ? "visible" : "hidden")
			
			stateVars.dataSource_918032 = stateVars.KuikaY_RolexTudorMonthlyStoreComparison ?? this.state.KuikaY_RolexTudorMonthlyStoreComparison;
			ReactSystemFunctions.setValueOf(this, "rolexbasedreporting_164218_toString", ReactSystemFunctions.value(this, "rolexbasedreporting_904704_value", "value"), "value");

			ReactSystemFunctions.setValueOf(this, "rolexbasedreporting_838743_toString", ReactSystemFunctions.value(this, "rolexbasedreporting_307394_value", "value"), "value");

			
			stateVars.dataSource_957664 = stateVars.KuikaY_RolexTudorMonthlyStoreComparison ?? this.state.KuikaY_RolexTudorMonthlyStoreComparison;
			
			
			stateVars.isComp741238Visible = ((ReactSystemFunctions.isGreaterOrEqual(ReactSystemFunctions.value(this, "rolexbasedreporting_957664_value", "agustosDegisim"), ReactSystemFunctions.convertToTypeByName("0", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp256065Visible = ((ReactSystemFunctions.isLessThan(ReactSystemFunctions.value(this, "rolexbasedreporting_957664_value", "agustosDegisim"), ReactSystemFunctions.convertToTypeByName("0", "string"))) === true ? "visible" : "hidden")
			
			stateVars.dataSource_192146 = stateVars.KuikaY_RolexTudorMonthlyStoreComparison ?? this.state.KuikaY_RolexTudorMonthlyStoreComparison;
			ReactSystemFunctions.setValueOf(this, "rolexbasedreporting_146113_toString", ReactSystemFunctions.value(this, "rolexbasedreporting_904704_value", "value"), "value");

			ReactSystemFunctions.setValueOf(this, "rolexbasedreporting_668857_toString", ReactSystemFunctions.value(this, "rolexbasedreporting_307394_value", "value"), "value");

			
			stateVars.dataSource_579551 = stateVars.KuikaY_RolexTudorMonthlyStoreComparison ?? this.state.KuikaY_RolexTudorMonthlyStoreComparison;
			
			
			stateVars.isComp110030Visible = ((ReactSystemFunctions.isGreaterOrEqual(ReactSystemFunctions.value(this, "rolexbasedreporting_579551_value", "eylulDegisim"), ReactSystemFunctions.convertToTypeByName("0", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp387073Visible = ((ReactSystemFunctions.isLessThan(ReactSystemFunctions.value(this, "rolexbasedreporting_579551_value", "eylulDegisim"), ReactSystemFunctions.convertToTypeByName("0", "string"))) === true ? "visible" : "hidden")
			
			stateVars.dataSource_550260 = stateVars.KuikaY_RolexTudorMonthlyStoreComparison ?? this.state.KuikaY_RolexTudorMonthlyStoreComparison;
			ReactSystemFunctions.setValueOf(this, "rolexbasedreporting_561400_toString", ReactSystemFunctions.value(this, "rolexbasedreporting_904704_value", "value"), "value");

			ReactSystemFunctions.setValueOf(this, "rolexbasedreporting_592652_toString", ReactSystemFunctions.value(this, "rolexbasedreporting_307394_value", "value"), "value");

			
			stateVars.dataSource_593146 = stateVars.KuikaY_RolexTudorMonthlyStoreComparison ?? this.state.KuikaY_RolexTudorMonthlyStoreComparison;
			
			
			stateVars.isComp109367Visible = ((ReactSystemFunctions.isGreaterOrEqual(ReactSystemFunctions.value(this, "rolexbasedreporting_593146_value", "ekimDegisim"), ReactSystemFunctions.convertToTypeByName("0", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp327182Visible = ((ReactSystemFunctions.isLessThan(ReactSystemFunctions.value(this, "rolexbasedreporting_593146_value", "ekimDegisim"), ReactSystemFunctions.convertToTypeByName("0", "string"))) === true ? "visible" : "hidden")
			
			stateVars.dataSource_658183 = stateVars.KuikaY_RolexTudorMonthlyStoreComparison ?? this.state.KuikaY_RolexTudorMonthlyStoreComparison;
			ReactSystemFunctions.setValueOf(this, "rolexbasedreporting_176929_toString", ReactSystemFunctions.value(this, "rolexbasedreporting_904704_value", "value"), "value");

			ReactSystemFunctions.setValueOf(this, "rolexbasedreporting_474531_toString", ReactSystemFunctions.value(this, "rolexbasedreporting_307394_value", "value"), "value");

			
			stateVars.dataSource_618412 = stateVars.KuikaY_RolexTudorMonthlyStoreComparison ?? this.state.KuikaY_RolexTudorMonthlyStoreComparison;
			
			
			stateVars.isComp962790Visible = ((ReactSystemFunctions.isGreaterOrEqual(ReactSystemFunctions.value(this, "rolexbasedreporting_618412_value", "kasimDegisim"), ReactSystemFunctions.convertToTypeByName("0", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp311696Visible = ((ReactSystemFunctions.isLessThan(ReactSystemFunctions.value(this, "rolexbasedreporting_618412_value", "kasimDegisim"), ReactSystemFunctions.convertToTypeByName("0", "string"))) === true ? "visible" : "hidden")
			
			stateVars.dataSource_865652 = stateVars.KuikaY_RolexTudorMonthlyStoreComparison ?? this.state.KuikaY_RolexTudorMonthlyStoreComparison;
			ReactSystemFunctions.setValueOf(this, "rolexbasedreporting_73067_toString", ReactSystemFunctions.value(this, "rolexbasedreporting_904704_value", "value"), "value");

			ReactSystemFunctions.setValueOf(this, "rolexbasedreporting_145035_toString", ReactSystemFunctions.value(this, "rolexbasedreporting_307394_value", "value"), "value");

			
			stateVars.dataSource_673384 = stateVars.KuikaY_RolexTudorMonthlyStoreComparison ?? this.state.KuikaY_RolexTudorMonthlyStoreComparison;
			
			
			stateVars.isComp65893Visible = ((ReactSystemFunctions.isGreaterOrEqual(ReactSystemFunctions.value(this, "rolexbasedreporting_673384_value", "aralikDegisim"), ReactSystemFunctions.convertToTypeByName("0", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp518033Visible = ((ReactSystemFunctions.isLessThan(ReactSystemFunctions.value(this, "rolexbasedreporting_673384_value", "aralikDegisim"), ReactSystemFunctions.convertToTypeByName("0", "string"))) === true ? "visible" : "hidden")
			
			stateVars.dataSource_917848 = stateVars.KuikaY_RolexTudorMonthlyStoreComparison ?? this.state.KuikaY_RolexTudorMonthlyStoreComparison;

	this.props.form?.setFieldsValue(formVars);
	this.setState(stateVars);
	KuikaAppManager.hideSpinner(this);

            this.setPageInitLoaded(true);
            return isErrorOccurred;
        }




		RolexBasedReportingComponent_935607_onClick = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
KuikaAppManager.showSpinner(this);

const __currentPath = (window.location.hash ? window.location.hash.replace(/^#/, '').split('?')[0] : window.location.pathname.split('?')[0]).toLowerCase();
if (__currentPath !== "/tudorbasedreporting") {
  this.context.setMasterPageInitLoaded(false);
  this.context.setMasterPageRecurringLoaded(false);
  this.context.setShouldTriggerPageInit(true);
}
					KuikaAppManager.prepareForNavigation();

				stateVars.NAVIGATE = await ReactSystemFunctions.navigate(this, undefined, "RolexBasedReporting", "TudorBasedReporting", "", "currentPage", null, null, null, null, null, null, true, false);

		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

            
            return isErrorOccurred;
        }


		RolexBasedReportingComponent_801579_onClick = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
KuikaAppManager.showSpinner(this);

const __currentPath = (window.location.hash ? window.location.hash.replace(/^#/, '').split('?')[0] : window.location.pathname.split('?')[0]).toLowerCase();
if (__currentPath !== "/montblancbasedreporting") {
  this.context.setMasterPageInitLoaded(false);
  this.context.setMasterPageRecurringLoaded(false);
  this.context.setShouldTriggerPageInit(true);
}
					KuikaAppManager.prepareForNavigation();

				stateVars.NAVIGATE = await ReactSystemFunctions.navigate(this, undefined, "RolexBasedReporting", "MontBlancBasedReporting", "", "currentPage", null, null, null, null, null, null, true, false);

		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

            
            return isErrorOccurred;
        }


		RolexBasedReportingComponent_409815_onClick = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
KuikaAppManager.showSpinner(this);

const __currentPath = (window.location.hash ? window.location.hash.replace(/^#/, '').split('?')[0] : window.location.pathname.split('?')[0]).toLowerCase();
if (__currentPath !== "/dupontbasedreporting") {
  this.context.setMasterPageInitLoaded(false);
  this.context.setMasterPageRecurringLoaded(false);
  this.context.setShouldTriggerPageInit(true);
}
					KuikaAppManager.prepareForNavigation();

				stateVars.NAVIGATE = await ReactSystemFunctions.navigate(this, undefined, "RolexBasedReporting", "DupontBasedReporting", "", "currentPage", null, null, null, null, null, null, true, false);

		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

            
            return isErrorOccurred;
        }


		RolexBasedReportingComponent_948064_onClick = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
KuikaAppManager.showSpinner(this);

const __currentPath = (window.location.hash ? window.location.hash.replace(/^#/, '').split('?')[0] : window.location.pathname.split('?')[0]).toLowerCase();
if (__currentPath !== "/rolexfamilyreporting") {
  this.context.setMasterPageInitLoaded(false);
  this.context.setMasterPageRecurringLoaded(false);
  this.context.setShouldTriggerPageInit(true);
}
					KuikaAppManager.prepareForNavigation();

				stateVars.NAVIGATE = await ReactSystemFunctions.navigate(this, undefined, "RolexBasedReporting", "RolexFamilyReporting", "", "currentPage", null, null, null, null, null, null, true, false);

		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

            
            return isErrorOccurred;
        }


		RolexBasedReportingComponent_727992_onClick = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
KuikaAppManager.showSpinner(this);

const __currentPath = (window.location.hash ? window.location.hash.replace(/^#/, '').split('?')[0] : window.location.pathname.split('?')[0]).toLowerCase();
if (__currentPath !== "/rolexmaterialreporting") {
  this.context.setMasterPageInitLoaded(false);
  this.context.setMasterPageRecurringLoaded(false);
  this.context.setShouldTriggerPageInit(true);
}
					KuikaAppManager.prepareForNavigation();

				stateVars.NAVIGATE = await ReactSystemFunctions.navigate(this, undefined, "RolexBasedReporting", "RolexMaterialReporting", "", "currentPage", null, null, null, null, null, null, true, false);

		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

            
            return isErrorOccurred;
        }


		RolexBasedReportingComponent_885746_onClick = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
KuikaAppManager.showSpinner(this);

const __currentPath = (window.location.hash ? window.location.hash.replace(/^#/, '').split('?')[0] : window.location.pathname.split('?')[0]).toLowerCase();
if (__currentPath !== "/rolexdiameterreporting") {
  this.context.setMasterPageInitLoaded(false);
  this.context.setMasterPageRecurringLoaded(false);
  this.context.setShouldTriggerPageInit(true);
}
					KuikaAppManager.prepareForNavigation();

				stateVars.NAVIGATE = await ReactSystemFunctions.navigate(this, undefined, "RolexBasedReporting", "RolexDiameterReporting", "", "currentPage", null, null, null, null, null, null, true, false);

		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

            
            return isErrorOccurred;
        }


		RolexBasedReportingComponent_206592_onClick = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
KuikaAppManager.showSpinner(this);

const __currentPath = (window.location.hash ? window.location.hash.replace(/^#/, '').split('?')[0] : window.location.pathname.split('?')[0]).toLowerCase();
if (__currentPath !== "/rolexotherproductreporting") {
  this.context.setMasterPageInitLoaded(false);
  this.context.setMasterPageRecurringLoaded(false);
  this.context.setShouldTriggerPageInit(true);
}
					KuikaAppManager.prepareForNavigation();

				stateVars.NAVIGATE = await ReactSystemFunctions.navigate(this, undefined, "RolexBasedReporting", "RolexOtherProductReporting", "", "currentPage", null, null, null, null, null, null, true, false);

		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

            
            return isErrorOccurred;
        }


		RolexBasedReportingComponent_782867_onChange = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
KuikaAppManager.showSpinner(this);

				ReactSystemFunctions.setValueOf(this, "rolexbasedreporting_603136_toString", ReactSystemFunctions.value(this, "rolexbasedreporting_782867_value", "value"), "value");


		this.props.form?.setFieldsValue(formVars);
		
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.RolexBasedReportingComponent_782867_onChange1_();
                  resolve();
                });
          })

            
            return isErrorOccurred;
        }
    RolexBasedReportingComponent_782867_onChange1_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
		KuikaAppManager.increaseServerRequestCount();

        let localVar = {
				Marka_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.convertToTypeByName("Rolex", "string"), "string"),
				UrunGrubu_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.convertToTypeByName("kol saati", "string"), "string"),
				Year_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "rolexbasedreporting_782867_value", "value", "", "", "")), "number")
        }

		
        if (true) {
        KuikaAppManager.showSpinner(this);
        }
        let result = await KuikaAppManager.ApiRequest(this, "RolexBasedReporting/RolexBasedReportingComponent_782867_onChange1_", localVar)
        if (!KMainFunctions.IsResStatus2XX(result)) return true;

			stateVars.Kuika_ReportProductSales = result?.data.kuika_ReportProductSales;
			formVars.rolexbasedreporting_142273_value = ReactSystemFunctions.toString(this, (stateVars.Kuika_ReportProductSales !== undefined ? (stateVars.Kuika_ReportProductSales?.length > 0 ? stateVars.Kuika_ReportProductSales[0].toplamSatisAdedi : null) : (this.state.Kuika_ReportProductSales?.length > 0 ? this.state.Kuika_ReportProductSales[0].toplamSatisAdedi : null)));
			formVars.rolexbasedreporting_833488_value = ReactSystemFunctions.toString(this, (stateVars.Kuika_ReportProductSales !== undefined ? (stateVars.Kuika_ReportProductSales?.length > 0 ? stateVars.Kuika_ReportProductSales[0].gecenYilaGoreArtisYuzde : null) : (this.state.Kuika_ReportProductSales?.length > 0 ? this.state.Kuika_ReportProductSales[0].gecenYilaGoreArtisYuzde : null)));
			formVars.rolexbasedreporting_232881_value = ReactSystemFunctions.toString(this, (stateVars.Kuika_ReportProductSales !== undefined ? (stateVars.Kuika_ReportProductSales?.length > 0 ? stateVars.Kuika_ReportProductSales[0].gecenYilaGoreArtisYuzde : null) : (this.state.Kuika_ReportProductSales?.length > 0 ? this.state.Kuika_ReportProductSales[0].gecenYilaGoreArtisYuzde : null)));
			formVars.rolexbasedreporting_862873_value = ReactSystemFunctions.toString(this, (stateVars.Kuika_ReportProductSales !== undefined ? (stateVars.Kuika_ReportProductSales?.length > 0 ? stateVars.Kuika_ReportProductSales[0].bulundugumuzAySatisAdedi : null) : (this.state.Kuika_ReportProductSales?.length > 0 ? this.state.Kuika_ReportProductSales[0].bulundugumuzAySatisAdedi : null)));
			formVars.rolexbasedreporting_442377_value = ReactSystemFunctions.toString(this, (stateVars.Kuika_ReportProductSales !== undefined ? (stateVars.Kuika_ReportProductSales?.length > 0 ? stateVars.Kuika_ReportProductSales[0].gecenYilaGoreArtisYuzde : null) : (this.state.Kuika_ReportProductSales?.length > 0 ? this.state.Kuika_ReportProductSales[0].gecenYilaGoreArtisYuzde : null)));
			formVars.rolexbasedreporting_49365_value = ReactSystemFunctions.toString(this, (stateVars.Kuika_ReportProductSales !== undefined ? (stateVars.Kuika_ReportProductSales?.length > 0 ? stateVars.Kuika_ReportProductSales[0].enGucluMagazaDesc : null) : (this.state.Kuika_ReportProductSales?.length > 0 ? this.state.Kuika_ReportProductSales[0].enGucluMagazaDesc : null)));
			formVars.rolexbasedreporting_689773_value = ReactSystemFunctions.toString(this, (stateVars.Kuika_ReportProductSales !== undefined ? (stateVars.Kuika_ReportProductSales?.length > 0 ? stateVars.Kuika_ReportProductSales[0].enGucluMagazaCiro : null) : (this.state.Kuika_ReportProductSales?.length > 0 ? this.state.Kuika_ReportProductSales[0].enGucluMagazaCiro : null)));
			formVars.rolexbasedreporting_662229_value = ReactSystemFunctions.toString(this, (stateVars.Kuika_ReportProductSales !== undefined ? (stateVars.Kuika_ReportProductSales?.length > 0 ? stateVars.Kuika_ReportProductSales[0].enCokSatanFamily : null) : (this.state.Kuika_ReportProductSales?.length > 0 ? this.state.Kuika_ReportProductSales[0].enCokSatanFamily : null)));
			formVars.rolexbasedreporting_825140_value = ReactSystemFunctions.toString(this, (stateVars.Kuika_ReportProductSales !== undefined ? (stateVars.Kuika_ReportProductSales?.length > 0 ? stateVars.Kuika_ReportProductSales[0].enCokSatanFamilyAdet : null) : (this.state.Kuika_ReportProductSales?.length > 0 ? this.state.Kuika_ReportProductSales[0].enCokSatanFamilyAdet : null)));
			formVars.rolexbasedreporting_51555_value = ReactSystemFunctions.toString(this, (stateVars.Kuika_ReportProductSales !== undefined ? (stateVars.Kuika_ReportProductSales?.length > 0 ? stateVars.Kuika_ReportProductSales[0].enCokSatanMaterial : null) : (this.state.Kuika_ReportProductSales?.length > 0 ? this.state.Kuika_ReportProductSales[0].enCokSatanMaterial : null)));
			formVars.rolexbasedreporting_816749_value = ReactSystemFunctions.toString(this, (stateVars.Kuika_ReportProductSales !== undefined ? (stateVars.Kuika_ReportProductSales?.length > 0 ? stateVars.Kuika_ReportProductSales[0].enCokSatanMaterialCiro : null) : (this.state.Kuika_ReportProductSales?.length > 0 ? this.state.Kuika_ReportProductSales[0].enCokSatanMaterialCiro : null)));
			this.props.form?.setFieldsValue(formVars);
			
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.RolexBasedReportingComponent_782867_onChange2_();
                  resolve();
                });
          })



        
        KuikaAppManager.hideSpinner(this);
        return isErrorOccurred;
    }
		RolexBasedReportingComponent_782867_onChange2_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }

				formVars.rolexbasedreporting_142273_value = ReactSystemFunctions.toString(this, (stateVars.Kuika_ReportProductSales !== undefined ? (stateVars.Kuika_ReportProductSales?.length > 0 ? stateVars.Kuika_ReportProductSales[0].toplamSatisAdedi : null) : (this.state.Kuika_ReportProductSales?.length > 0 ? this.state.Kuika_ReportProductSales[0].toplamSatisAdedi : null)));

				formVars.rolexbasedreporting_833488_value = ReactSystemFunctions.toString(this, (stateVars.Kuika_ReportProductSales !== undefined ? (stateVars.Kuika_ReportProductSales?.length > 0 ? stateVars.Kuika_ReportProductSales[0].gecenYilaGoreArtisYuzde : null) : (this.state.Kuika_ReportProductSales?.length > 0 ? this.state.Kuika_ReportProductSales[0].gecenYilaGoreArtisYuzde : null)));

				formVars.rolexbasedreporting_232881_value = ReactSystemFunctions.toString(this, (stateVars.Kuika_ReportProductSales !== undefined ? (stateVars.Kuika_ReportProductSales?.length > 0 ? stateVars.Kuika_ReportProductSales[0].gecenYilaGoreArtisYuzde : null) : (this.state.Kuika_ReportProductSales?.length > 0 ? this.state.Kuika_ReportProductSales[0].gecenYilaGoreArtisYuzde : null)));

				formVars.rolexbasedreporting_862873_value = ReactSystemFunctions.toString(this, (stateVars.Kuika_ReportProductSales !== undefined ? (stateVars.Kuika_ReportProductSales?.length > 0 ? stateVars.Kuika_ReportProductSales[0].bulundugumuzAySatisAdedi : null) : (this.state.Kuika_ReportProductSales?.length > 0 ? this.state.Kuika_ReportProductSales[0].bulundugumuzAySatisAdedi : null)));

				formVars.rolexbasedreporting_442377_value = ReactSystemFunctions.toString(this, (stateVars.Kuika_ReportProductSales !== undefined ? (stateVars.Kuika_ReportProductSales?.length > 0 ? stateVars.Kuika_ReportProductSales[0].gecenYilaGoreArtisYuzde : null) : (this.state.Kuika_ReportProductSales?.length > 0 ? this.state.Kuika_ReportProductSales[0].gecenYilaGoreArtisYuzde : null)));

				formVars.rolexbasedreporting_49365_value = ReactSystemFunctions.toString(this, (stateVars.Kuika_ReportProductSales !== undefined ? (stateVars.Kuika_ReportProductSales?.length > 0 ? stateVars.Kuika_ReportProductSales[0].enGucluMagazaDesc : null) : (this.state.Kuika_ReportProductSales?.length > 0 ? this.state.Kuika_ReportProductSales[0].enGucluMagazaDesc : null)));

				formVars.rolexbasedreporting_689773_value = ReactSystemFunctions.toString(this, (stateVars.Kuika_ReportProductSales !== undefined ? (stateVars.Kuika_ReportProductSales?.length > 0 ? stateVars.Kuika_ReportProductSales[0].enGucluMagazaCiro : null) : (this.state.Kuika_ReportProductSales?.length > 0 ? this.state.Kuika_ReportProductSales[0].enGucluMagazaCiro : null)));

				formVars.rolexbasedreporting_662229_value = ReactSystemFunctions.toString(this, (stateVars.Kuika_ReportProductSales !== undefined ? (stateVars.Kuika_ReportProductSales?.length > 0 ? stateVars.Kuika_ReportProductSales[0].enCokSatanFamily : null) : (this.state.Kuika_ReportProductSales?.length > 0 ? this.state.Kuika_ReportProductSales[0].enCokSatanFamily : null)));

				formVars.rolexbasedreporting_825140_value = ReactSystemFunctions.toString(this, (stateVars.Kuika_ReportProductSales !== undefined ? (stateVars.Kuika_ReportProductSales?.length > 0 ? stateVars.Kuika_ReportProductSales[0].enCokSatanFamilyAdet : null) : (this.state.Kuika_ReportProductSales?.length > 0 ? this.state.Kuika_ReportProductSales[0].enCokSatanFamilyAdet : null)));

				formVars.rolexbasedreporting_51555_value = ReactSystemFunctions.toString(this, (stateVars.Kuika_ReportProductSales !== undefined ? (stateVars.Kuika_ReportProductSales?.length > 0 ? stateVars.Kuika_ReportProductSales[0].enCokSatanMaterial : null) : (this.state.Kuika_ReportProductSales?.length > 0 ? this.state.Kuika_ReportProductSales[0].enCokSatanMaterial : null)));

				formVars.rolexbasedreporting_816749_value = ReactSystemFunctions.toString(this, (stateVars.Kuika_ReportProductSales !== undefined ? (stateVars.Kuika_ReportProductSales?.length > 0 ? stateVars.Kuika_ReportProductSales[0].enCokSatanMaterialCiro : null) : (this.state.Kuika_ReportProductSales?.length > 0 ? this.state.Kuika_ReportProductSales[0].enCokSatanMaterialCiro : null)));


		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

            
            return isErrorOccurred;
        }





		RolexBasedReportingComponent_556665_onChange = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
KuikaAppManager.showSpinner(this);

				ReactSystemFunctions.setValueOf(this, "rolexbasedreporting_456834_toString", ReactSystemFunctions.value(this, "rolexbasedreporting_556665_value", "value"), "value");


		this.props.form?.setFieldsValue(formVars);
		
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.RolexBasedReportingComponent_556665_onChange1_();
                  resolve();
                });
          })

            
            return isErrorOccurred;
        }
    RolexBasedReportingComponent_556665_onChange1_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
		KuikaAppManager.increaseServerRequestCount();

        let localVar = {
				Brand_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.convertToTypeByName("Rolex", "string"), "string"),
				ProductGroup_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.convertToTypeByName("Kol Saati", "string"), "string"),
				Year_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "rolexbasedreporting_556665_value", "value", "", "", "")), "number")
        }

		
        if (true) {
        KuikaAppManager.showSpinner(this);
        }
        let result = await KuikaAppManager.ApiRequest(this, "RolexBasedReporting/RolexBasedReportingComponent_556665_onChange1_", localVar)
        if (!KMainFunctions.IsResStatus2XX(result)) return true;

			stateVars.KuikaY_MonthlyStoreSalesReport = result?.data.kuikaY_MonthlyStoreSalesReport;
			
			this.props.form?.setFieldsValue(formVars);
			
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.RolexBasedReportingComponent_556665_onChange2_();
                  resolve();
                });
          })



        
        KuikaAppManager.hideSpinner(this);
        return isErrorOccurred;
    }
		RolexBasedReportingComponent_556665_onChange2_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }

				
				stateVars.dataSource_390370 = stateVars.KuikaY_MonthlyStoreSalesReport ?? this.state.KuikaY_MonthlyStoreSalesReport;

		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

            
            return isErrorOccurred;
        }





    RolexBasedReportingComponent_234254_onClick = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
		KuikaAppManager.increaseServerRequestCount();

        let localVar = {
				value_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, this.state.KuikaY_MonthlyStoreSalesReport), "any"),
				header_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.convertToTypeByName("Rolex Mağaza Bazlı Aylık Satış Özeti", "string"), "string"),
				footer_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "rolexbasedreporting_556665_value", "value", "", "", "")), "string"),
				columns_0: ReactSystemFunctions.convertToTypeByName("", "string")
        }

		KuikaAppManager.showSpinner(this);
		
        if (true) {
        KuikaAppManager.showSpinner(this);
        }
        let result = await KuikaAppManager.ApiRequest(this, "RolexBasedReporting/RolexBasedReportingComponent_234254_onClick", localVar)
        if (!KMainFunctions.IsResStatus2XX(result)) return true;

			stateVars.ExportExcel = result?.data.exportExcel;
			ReactSystemFunctions.downloadFile(result?.data?.exportExcel);
			this.props.form?.setFieldsValue(formVars);
			this.setState(stateVars);
			KuikaAppManager.hideSpinner(this);



        this.setPageInitLoaded(true);
        KuikaAppManager.hideSpinner(this);
        return isErrorOccurred;
    }



    RolexBasedReportingComponent_241118_onClick = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
		KuikaAppManager.increaseServerRequestCount();

        let localVar = {
				Brand_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.convertToTypeByName("Rolex", "string"), "string"),
				ProductGroup_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.convertToTypeByName("Kol Saati", "string"), "string"),
				Year1_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "rolexbasedreporting_904704_value", "value", "", "", "")), "number"),
				Year2_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "rolexbasedreporting_307394_value", "value", "", "", "")), "number")
        }

		KuikaAppManager.showSpinner(this);
		
        if (true) {
        KuikaAppManager.showSpinner(this);
        }
        let result = await KuikaAppManager.ApiRequest(this, "RolexBasedReporting/RolexBasedReportingComponent_241118_onClick", localVar)
        if (!KMainFunctions.IsResStatus2XX(result)) return true;

			stateVars.KuikaY_RolexTudorMonthlyStoreComparison = result?.data.kuikaY_RolexTudorMonthlyStoreComparison;
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			this.props.form?.setFieldsValue(formVars);
			
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.RolexBasedReportingComponent_241118_onClick1_();
                  resolve();
                });
          })



        
        KuikaAppManager.hideSpinner(this);
        return isErrorOccurred;
    }
		RolexBasedReportingComponent_241118_onClick1_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }

				stateVars.ChangeVisibilityOf = await ReactSystemFunctions.changeVisibilityOf(this, ReactSystemFunctions.convertToTypeByName("isComp289497Visible", "string"), ReactSystemFunctions.convertToTypeByName("visible", "string"));
				stateVars.ChangeVisibilityOf = await ReactSystemFunctions.changeVisibilityOf(this, ReactSystemFunctions.convertToTypeByName("isComp374338Visible", "string"), ReactSystemFunctions.convertToTypeByName("hidden", "string"));
				
				stateVars.dataSource_426992 = stateVars.KuikaY_RolexTudorMonthlyStoreComparison ?? this.state.KuikaY_RolexTudorMonthlyStoreComparison;
				
				stateVars.dataSource_810137 = stateVars.KuikaY_RolexTudorMonthlyStoreComparison ?? this.state.KuikaY_RolexTudorMonthlyStoreComparison;
				
				stateVars.dataSource_228396 = stateVars.KuikaY_RolexTudorMonthlyStoreComparison ?? this.state.KuikaY_RolexTudorMonthlyStoreComparison;
				
				stateVars.dataSource_886877 = stateVars.KuikaY_RolexTudorMonthlyStoreComparison ?? this.state.KuikaY_RolexTudorMonthlyStoreComparison;
				
				stateVars.dataSource_714039 = stateVars.KuikaY_RolexTudorMonthlyStoreComparison ?? this.state.KuikaY_RolexTudorMonthlyStoreComparison;
				
				stateVars.dataSource_258313 = stateVars.KuikaY_RolexTudorMonthlyStoreComparison ?? this.state.KuikaY_RolexTudorMonthlyStoreComparison;
				
				stateVars.dataSource_274772 = stateVars.KuikaY_RolexTudorMonthlyStoreComparison ?? this.state.KuikaY_RolexTudorMonthlyStoreComparison;
				
				stateVars.dataSource_621009 = stateVars.KuikaY_RolexTudorMonthlyStoreComparison ?? this.state.KuikaY_RolexTudorMonthlyStoreComparison;
				
				stateVars.dataSource_537831 = stateVars.KuikaY_RolexTudorMonthlyStoreComparison ?? this.state.KuikaY_RolexTudorMonthlyStoreComparison;
				
				stateVars.dataSource_671268 = stateVars.KuikaY_RolexTudorMonthlyStoreComparison ?? this.state.KuikaY_RolexTudorMonthlyStoreComparison;
				
				stateVars.dataSource_758267 = stateVars.KuikaY_RolexTudorMonthlyStoreComparison ?? this.state.KuikaY_RolexTudorMonthlyStoreComparison;
				
				stateVars.dataSource_632646 = stateVars.KuikaY_RolexTudorMonthlyStoreComparison ?? this.state.KuikaY_RolexTudorMonthlyStoreComparison;
				
				stateVars.dataSource_825743 = stateVars.KuikaY_RolexTudorMonthlyStoreComparison ?? this.state.KuikaY_RolexTudorMonthlyStoreComparison;
				
				stateVars.dataSource_918032 = stateVars.KuikaY_RolexTudorMonthlyStoreComparison ?? this.state.KuikaY_RolexTudorMonthlyStoreComparison;
				
				stateVars.dataSource_957664 = stateVars.KuikaY_RolexTudorMonthlyStoreComparison ?? this.state.KuikaY_RolexTudorMonthlyStoreComparison;
				
				stateVars.dataSource_192146 = stateVars.KuikaY_RolexTudorMonthlyStoreComparison ?? this.state.KuikaY_RolexTudorMonthlyStoreComparison;
				
				stateVars.dataSource_579551 = stateVars.KuikaY_RolexTudorMonthlyStoreComparison ?? this.state.KuikaY_RolexTudorMonthlyStoreComparison;
				
				stateVars.dataSource_550260 = stateVars.KuikaY_RolexTudorMonthlyStoreComparison ?? this.state.KuikaY_RolexTudorMonthlyStoreComparison;
				
				stateVars.dataSource_593146 = stateVars.KuikaY_RolexTudorMonthlyStoreComparison ?? this.state.KuikaY_RolexTudorMonthlyStoreComparison;
				
				stateVars.dataSource_658183 = stateVars.KuikaY_RolexTudorMonthlyStoreComparison ?? this.state.KuikaY_RolexTudorMonthlyStoreComparison;
				
				stateVars.dataSource_618412 = stateVars.KuikaY_RolexTudorMonthlyStoreComparison ?? this.state.KuikaY_RolexTudorMonthlyStoreComparison;
				
				stateVars.dataSource_865652 = stateVars.KuikaY_RolexTudorMonthlyStoreComparison ?? this.state.KuikaY_RolexTudorMonthlyStoreComparison;
				
				stateVars.dataSource_673384 = stateVars.KuikaY_RolexTudorMonthlyStoreComparison ?? this.state.KuikaY_RolexTudorMonthlyStoreComparison;
				
				stateVars.dataSource_917848 = stateVars.KuikaY_RolexTudorMonthlyStoreComparison ?? this.state.KuikaY_RolexTudorMonthlyStoreComparison;

		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

            
            return isErrorOccurred;
        }




    RolexBasedReportingComponent_81495_onClick = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
		KuikaAppManager.increaseServerRequestCount();

        let localVar = {
				value_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, this.state.KuikaY_RolexTudorMonthlyStoreComparison), "any"),
				header_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.convertToTypeByName("Karşılaştırmalı Aylık Rolex Satış Raporu", "string"), "string"),
				footer_0: ReactSystemFunctions.convertToTypeByName("", "string"),
				columns_0: ReactSystemFunctions.convertToTypeByName("", "string")
        }

		KuikaAppManager.showSpinner(this);
		
        if (true) {
        KuikaAppManager.showSpinner(this);
        }
        let result = await KuikaAppManager.ApiRequest(this, "RolexBasedReporting/RolexBasedReportingComponent_81495_onClick", localVar)
        if (!KMainFunctions.IsResStatus2XX(result)) return true;

			stateVars.ExportExcel = result?.data.exportExcel;
			ReactSystemFunctions.downloadFile(result?.data?.exportExcel);
			this.props.form?.setFieldsValue(formVars);
			this.setState(stateVars);
			KuikaAppManager.hideSpinner(this);



        this.setPageInitLoaded(true);
        KuikaAppManager.hideSpinner(this);
        return isErrorOccurred;
    }



    RolexBasedReportingComponent_150546_onClick = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
		KuikaAppManager.increaseServerRequestCount();

        let localVar = {
				value_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, this.state.KuikaY_RolexTudorMonthlyStoreComparison), "any"),
				header_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.convertToTypeByName("Karşılaştırmalı Aylık Rolex Satış Raporu", "string"), "string"),
				footer_0: ReactSystemFunctions.convertToTypeByName("", "string"),
				columns_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.convertToTypeByName("Merkez,Ocak_Yil1,Ocak_Yil2,OcakDegisim", "string"), "string")
        }

		KuikaAppManager.showSpinner(this);
		
        if (true) {
        KuikaAppManager.showSpinner(this);
        }
        let result = await KuikaAppManager.ApiRequest(this, "RolexBasedReporting/RolexBasedReportingComponent_150546_onClick", localVar)
        if (!KMainFunctions.IsResStatus2XX(result)) return true;

			stateVars.ExportExcel = result?.data.exportExcel;
			ReactSystemFunctions.downloadFile(result?.data?.exportExcel);
			this.props.form?.setFieldsValue(formVars);
			this.setState(stateVars);
			KuikaAppManager.hideSpinner(this);



        this.setPageInitLoaded(true);
        KuikaAppManager.hideSpinner(this);
        return isErrorOccurred;
    }



    RolexBasedReportingComponent_302530_onClick = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
		KuikaAppManager.increaseServerRequestCount();

        let localVar = {
				value_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, this.state.KuikaY_RolexTudorMonthlyStoreComparison), "any"),
				header_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.convertToTypeByName("Karşılaştırmalı Aylık Rolex Satış Raporu", "string"), "string"),
				footer_0: ReactSystemFunctions.convertToTypeByName("", "string"),
				columns_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.convertToTypeByName("Merkez,Subat_Yil1,Subat_Yil2,SubatDegisim", "string"), "string")
        }

		KuikaAppManager.showSpinner(this);
		
        if (true) {
        KuikaAppManager.showSpinner(this);
        }
        let result = await KuikaAppManager.ApiRequest(this, "RolexBasedReporting/RolexBasedReportingComponent_302530_onClick", localVar)
        if (!KMainFunctions.IsResStatus2XX(result)) return true;

			stateVars.ExportExcel = result?.data.exportExcel;
			ReactSystemFunctions.downloadFile(result?.data?.exportExcel);
			this.props.form?.setFieldsValue(formVars);
			this.setState(stateVars);
			KuikaAppManager.hideSpinner(this);



        this.setPageInitLoaded(true);
        KuikaAppManager.hideSpinner(this);
        return isErrorOccurred;
    }



    RolexBasedReportingComponent_311587_onClick = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
		KuikaAppManager.increaseServerRequestCount();

        let localVar = {
				value_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, this.state.KuikaY_RolexTudorMonthlyStoreComparison), "any"),
				header_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.convertToTypeByName("Karşılaştırmalı Aylık Rolex Satış Raporu", "string"), "string"),
				footer_0: ReactSystemFunctions.convertToTypeByName("", "string"),
				columns_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.convertToTypeByName("Merkez,Mart_Yil1,Mart_Yil2,MartDegisim", "string"), "string")
        }

		KuikaAppManager.showSpinner(this);
		
        if (true) {
        KuikaAppManager.showSpinner(this);
        }
        let result = await KuikaAppManager.ApiRequest(this, "RolexBasedReporting/RolexBasedReportingComponent_311587_onClick", localVar)
        if (!KMainFunctions.IsResStatus2XX(result)) return true;

			stateVars.ExportExcel = result?.data.exportExcel;
			ReactSystemFunctions.downloadFile(result?.data?.exportExcel);
			this.props.form?.setFieldsValue(formVars);
			this.setState(stateVars);
			KuikaAppManager.hideSpinner(this);



        this.setPageInitLoaded(true);
        KuikaAppManager.hideSpinner(this);
        return isErrorOccurred;
    }



    RolexBasedReportingComponent_169444_onClick = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
		KuikaAppManager.increaseServerRequestCount();

        let localVar = {
				value_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, this.state.KuikaY_RolexTudorMonthlyStoreComparison), "any"),
				header_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.convertToTypeByName("Karşılaştırmalı Aylık Rolex Satış Raporu", "string"), "string"),
				footer_0: ReactSystemFunctions.convertToTypeByName("", "string"),
				columns_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.convertToTypeByName("Merkez,Nisan_Yil1,Nisan_Yil2,NisanDegisim", "string"), "string")
        }

		KuikaAppManager.showSpinner(this);
		
        if (true) {
        KuikaAppManager.showSpinner(this);
        }
        let result = await KuikaAppManager.ApiRequest(this, "RolexBasedReporting/RolexBasedReportingComponent_169444_onClick", localVar)
        if (!KMainFunctions.IsResStatus2XX(result)) return true;

			stateVars.ExportExcel = result?.data.exportExcel;
			ReactSystemFunctions.downloadFile(result?.data?.exportExcel);
			this.props.form?.setFieldsValue(formVars);
			this.setState(stateVars);
			KuikaAppManager.hideSpinner(this);



        this.setPageInitLoaded(true);
        KuikaAppManager.hideSpinner(this);
        return isErrorOccurred;
    }



    RolexBasedReportingComponent_590747_onClick = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
		KuikaAppManager.increaseServerRequestCount();

        let localVar = {
				value_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, this.state.KuikaY_RolexTudorMonthlyStoreComparison), "any"),
				header_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.convertToTypeByName("Karşılaştırmalı Aylık Rolex Satış Raporu", "string"), "string"),
				footer_0: ReactSystemFunctions.convertToTypeByName("", "string"),
				columns_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.convertToTypeByName("Mayis_Yil1,Mayis_Yil2,MayisDegisim", "string"), "string")
        }

		KuikaAppManager.showSpinner(this);
		
        if (true) {
        KuikaAppManager.showSpinner(this);
        }
        let result = await KuikaAppManager.ApiRequest(this, "RolexBasedReporting/RolexBasedReportingComponent_590747_onClick", localVar)
        if (!KMainFunctions.IsResStatus2XX(result)) return true;

			stateVars.ExportExcel = result?.data.exportExcel;
			ReactSystemFunctions.downloadFile(result?.data?.exportExcel);
			this.props.form?.setFieldsValue(formVars);
			this.setState(stateVars);
			KuikaAppManager.hideSpinner(this);



        this.setPageInitLoaded(true);
        KuikaAppManager.hideSpinner(this);
        return isErrorOccurred;
    }



    RolexBasedReportingComponent_402561_onClick = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
		KuikaAppManager.increaseServerRequestCount();

        let localVar = {
				value_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, this.state.KuikaY_RolexTudorMonthlyStoreComparison), "any"),
				header_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.convertToTypeByName("Karşılaştırmalı Aylık Rolex Satış Raporu", "string"), "string"),
				footer_0: ReactSystemFunctions.convertToTypeByName("", "string"),
				columns_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.convertToTypeByName("Merkez,Haziran_Yil1,Haziran_Yil2,HaziranDegisim", "string"), "string")
        }

		KuikaAppManager.showSpinner(this);
		
        if (true) {
        KuikaAppManager.showSpinner(this);
        }
        let result = await KuikaAppManager.ApiRequest(this, "RolexBasedReporting/RolexBasedReportingComponent_402561_onClick", localVar)
        if (!KMainFunctions.IsResStatus2XX(result)) return true;

			stateVars.ExportExcel = result?.data.exportExcel;
			ReactSystemFunctions.downloadFile(result?.data?.exportExcel);
			this.props.form?.setFieldsValue(formVars);
			this.setState(stateVars);
			KuikaAppManager.hideSpinner(this);



        this.setPageInitLoaded(true);
        KuikaAppManager.hideSpinner(this);
        return isErrorOccurred;
    }



    RolexBasedReportingComponent_585136_onClick = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
		KuikaAppManager.increaseServerRequestCount();

        let localVar = {
				value_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, this.state.KuikaY_RolexTudorMonthlyStoreComparison), "any"),
				header_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.convertToTypeByName("Karşılaştırmalı Aylık Rolex Satış Raporu", "string"), "string"),
				footer_0: ReactSystemFunctions.convertToTypeByName("", "string"),
				columns_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.convertToTypeByName("Merkez,Temmuz_Yil1,Temmuz_Yil2,TemmuzDegisim", "string"), "string")
        }

		KuikaAppManager.showSpinner(this);
		
        if (true) {
        KuikaAppManager.showSpinner(this);
        }
        let result = await KuikaAppManager.ApiRequest(this, "RolexBasedReporting/RolexBasedReportingComponent_585136_onClick", localVar)
        if (!KMainFunctions.IsResStatus2XX(result)) return true;

			stateVars.ExportExcel = result?.data.exportExcel;
			ReactSystemFunctions.downloadFile(result?.data?.exportExcel);
			this.props.form?.setFieldsValue(formVars);
			this.setState(stateVars);
			KuikaAppManager.hideSpinner(this);



        this.setPageInitLoaded(true);
        KuikaAppManager.hideSpinner(this);
        return isErrorOccurred;
    }



    RolexBasedReportingComponent_586727_onClick = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
		KuikaAppManager.increaseServerRequestCount();

        let localVar = {
				value_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, this.state.KuikaY_RolexTudorMonthlyStoreComparison), "any"),
				header_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.convertToTypeByName("Karşılaştırmalı Aylık Rolex Satış Raporu", "string"), "string"),
				footer_0: ReactSystemFunctions.convertToTypeByName("", "string"),
				columns_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.convertToTypeByName("Merkez,Agustos_Yil1,Agustos_Yil2,AgustosDegisim", "string"), "string")
        }

		KuikaAppManager.showSpinner(this);
		
        if (true) {
        KuikaAppManager.showSpinner(this);
        }
        let result = await KuikaAppManager.ApiRequest(this, "RolexBasedReporting/RolexBasedReportingComponent_586727_onClick", localVar)
        if (!KMainFunctions.IsResStatus2XX(result)) return true;

			stateVars.ExportExcel = result?.data.exportExcel;
			ReactSystemFunctions.downloadFile(result?.data?.exportExcel);
			this.props.form?.setFieldsValue(formVars);
			this.setState(stateVars);
			KuikaAppManager.hideSpinner(this);



        this.setPageInitLoaded(true);
        KuikaAppManager.hideSpinner(this);
        return isErrorOccurred;
    }



    RolexBasedReportingComponent_633542_onClick = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
		KuikaAppManager.increaseServerRequestCount();

        let localVar = {
				value_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, this.state.KuikaY_RolexTudorMonthlyStoreComparison), "any"),
				header_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.convertToTypeByName("Karşılaştırmalı Aylık Rolex Satış Raporu", "string"), "string"),
				footer_0: ReactSystemFunctions.convertToTypeByName("", "string"),
				columns_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.convertToTypeByName("Merkez,Eylul_Yil1,Eylul_Yil2,EylulDegisim", "string"), "string")
        }

		KuikaAppManager.showSpinner(this);
		
        if (true) {
        KuikaAppManager.showSpinner(this);
        }
        let result = await KuikaAppManager.ApiRequest(this, "RolexBasedReporting/RolexBasedReportingComponent_633542_onClick", localVar)
        if (!KMainFunctions.IsResStatus2XX(result)) return true;

			stateVars.ExportExcel = result?.data.exportExcel;
			ReactSystemFunctions.downloadFile(result?.data?.exportExcel);
			this.props.form?.setFieldsValue(formVars);
			this.setState(stateVars);
			KuikaAppManager.hideSpinner(this);



        this.setPageInitLoaded(true);
        KuikaAppManager.hideSpinner(this);
        return isErrorOccurred;
    }



    RolexBasedReportingComponent_493673_onClick = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
		KuikaAppManager.increaseServerRequestCount();

        let localVar = {
				value_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, this.state.KuikaY_RolexTudorMonthlyStoreComparison), "any"),
				header_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.convertToTypeByName("Karşılaştırmalı Aylık Rolex Satış Raporu", "string"), "string"),
				footer_0: ReactSystemFunctions.convertToTypeByName("", "string"),
				columns_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.convertToTypeByName("Merkez,Ekim_Yil1,Ekim_Yil2,EkimDegisim", "string"), "string")
        }

		KuikaAppManager.showSpinner(this);
		
        if (true) {
        KuikaAppManager.showSpinner(this);
        }
        let result = await KuikaAppManager.ApiRequest(this, "RolexBasedReporting/RolexBasedReportingComponent_493673_onClick", localVar)
        if (!KMainFunctions.IsResStatus2XX(result)) return true;

			stateVars.ExportExcel = result?.data.exportExcel;
			ReactSystemFunctions.downloadFile(result?.data?.exportExcel);
			this.props.form?.setFieldsValue(formVars);
			this.setState(stateVars);
			KuikaAppManager.hideSpinner(this);



        this.setPageInitLoaded(true);
        KuikaAppManager.hideSpinner(this);
        return isErrorOccurred;
    }



    RolexBasedReportingComponent_25147_onClick = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
		KuikaAppManager.increaseServerRequestCount();

        let localVar = {
				value_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, this.state.KuikaY_RolexTudorMonthlyStoreComparison), "any"),
				header_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.convertToTypeByName("Karşılaştırmalı Aylık Rolex Satış Raporu", "string"), "string"),
				footer_0: ReactSystemFunctions.convertToTypeByName("", "string"),
				columns_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.convertToTypeByName("Merkez,Kasim_Yil1,Kasim_Yil2,KasimDegisim", "string"), "string")
        }

		KuikaAppManager.showSpinner(this);
		
        if (true) {
        KuikaAppManager.showSpinner(this);
        }
        let result = await KuikaAppManager.ApiRequest(this, "RolexBasedReporting/RolexBasedReportingComponent_25147_onClick", localVar)
        if (!KMainFunctions.IsResStatus2XX(result)) return true;

			stateVars.ExportExcel = result?.data.exportExcel;
			ReactSystemFunctions.downloadFile(result?.data?.exportExcel);
			this.props.form?.setFieldsValue(formVars);
			this.setState(stateVars);
			KuikaAppManager.hideSpinner(this);



        this.setPageInitLoaded(true);
        KuikaAppManager.hideSpinner(this);
        return isErrorOccurred;
    }



    RolexBasedReportingComponent_859257_onClick = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
		KuikaAppManager.increaseServerRequestCount();

        let localVar = {
				value_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, this.state.KuikaY_RolexTudorMonthlyStoreComparison), "any"),
				header_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.convertToTypeByName("Karşılaştırmalı Aylık Rolex Satış Raporu", "string"), "string"),
				footer_0: ReactSystemFunctions.convertToTypeByName("", "string"),
				columns_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.convertToTypeByName("Merkez,Aralik_Yil1,Aralik_Yil2,AralikDegisim", "string"), "string")
        }

		KuikaAppManager.showSpinner(this);
		
        if (true) {
        KuikaAppManager.showSpinner(this);
        }
        let result = await KuikaAppManager.ApiRequest(this, "RolexBasedReporting/RolexBasedReportingComponent_859257_onClick", localVar)
        if (!KMainFunctions.IsResStatus2XX(result)) return true;

			stateVars.ExportExcel = result?.data.exportExcel;
			ReactSystemFunctions.downloadFile(result?.data?.exportExcel);
			this.props.form?.setFieldsValue(formVars);
			this.setState(stateVars);
			KuikaAppManager.hideSpinner(this);



        this.setPageInitLoaded(true);
        KuikaAppManager.hideSpinner(this);
        return isErrorOccurred;
    }



		RolexBasedReportingComponent_904704_onChange = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
KuikaAppManager.showSpinner(this);

				
				ReactSystemFunctions.setValueOf(this, "rolexbasedreporting_73067_toString", ReactSystemFunctions.value(this, "rolexbasedreporting_904704_value", "value"), "value");

				
				ReactSystemFunctions.setValueOf(this, "rolexbasedreporting_176929_toString", ReactSystemFunctions.value(this, "rolexbasedreporting_904704_value", "value"), "value");

				
				ReactSystemFunctions.setValueOf(this, "rolexbasedreporting_561400_toString", ReactSystemFunctions.value(this, "rolexbasedreporting_904704_value", "value"), "value");

				
				ReactSystemFunctions.setValueOf(this, "rolexbasedreporting_146113_toString", ReactSystemFunctions.value(this, "rolexbasedreporting_904704_value", "value"), "value");

				
				ReactSystemFunctions.setValueOf(this, "rolexbasedreporting_164218_toString", ReactSystemFunctions.value(this, "rolexbasedreporting_904704_value", "value"), "value");

				
				ReactSystemFunctions.setValueOf(this, "rolexbasedreporting_595413_toString", ReactSystemFunctions.value(this, "rolexbasedreporting_904704_value", "value"), "value");

				
				ReactSystemFunctions.setValueOf(this, "rolexbasedreporting_191176_toString", ReactSystemFunctions.value(this, "rolexbasedreporting_904704_value", "value"), "value");

				
				ReactSystemFunctions.setValueOf(this, "rolexbasedreporting_733552_toString", ReactSystemFunctions.value(this, "rolexbasedreporting_904704_value", "value"), "value");

				
				ReactSystemFunctions.setValueOf(this, "rolexbasedreporting_739479_toString", ReactSystemFunctions.value(this, "rolexbasedreporting_904704_value", "value"), "value");

				
				ReactSystemFunctions.setValueOf(this, "rolexbasedreporting_695756_toString", ReactSystemFunctions.value(this, "rolexbasedreporting_904704_value", "value"), "value");

				
				ReactSystemFunctions.setValueOf(this, "rolexbasedreporting_873004_toString", ReactSystemFunctions.value(this, "rolexbasedreporting_904704_value", "value"), "value");

				
				ReactSystemFunctions.setValueOf(this, "rolexbasedreporting_84776_toString", ReactSystemFunctions.value(this, "rolexbasedreporting_904704_value", "value"), "value");


		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

            
            return isErrorOccurred;
        }


		RolexBasedReportingComponent_307394_onChange = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
KuikaAppManager.showSpinner(this);

				
				ReactSystemFunctions.setValueOf(this, "rolexbasedreporting_145035_toString", ReactSystemFunctions.value(this, "rolexbasedreporting_307394_value", "value"), "value");

				
				ReactSystemFunctions.setValueOf(this, "rolexbasedreporting_474531_toString", ReactSystemFunctions.value(this, "rolexbasedreporting_307394_value", "value"), "value");

				
				ReactSystemFunctions.setValueOf(this, "rolexbasedreporting_592652_toString", ReactSystemFunctions.value(this, "rolexbasedreporting_307394_value", "value"), "value");

				
				ReactSystemFunctions.setValueOf(this, "rolexbasedreporting_668857_toString", ReactSystemFunctions.value(this, "rolexbasedreporting_307394_value", "value"), "value");

				
				ReactSystemFunctions.setValueOf(this, "rolexbasedreporting_838743_toString", ReactSystemFunctions.value(this, "rolexbasedreporting_307394_value", "value"), "value");

				
				ReactSystemFunctions.setValueOf(this, "rolexbasedreporting_25718_toString", ReactSystemFunctions.value(this, "rolexbasedreporting_307394_value", "value"), "value");

				
				ReactSystemFunctions.setValueOf(this, "rolexbasedreporting_971542_toString", ReactSystemFunctions.value(this, "rolexbasedreporting_307394_value", "value"), "value");

				
				ReactSystemFunctions.setValueOf(this, "rolexbasedreporting_898130_toString", ReactSystemFunctions.value(this, "rolexbasedreporting_307394_value", "value"), "value");

				
				ReactSystemFunctions.setValueOf(this, "rolexbasedreporting_45154_toString", ReactSystemFunctions.value(this, "rolexbasedreporting_307394_value", "value"), "value");

				
				ReactSystemFunctions.setValueOf(this, "rolexbasedreporting_839527_toString", ReactSystemFunctions.value(this, "rolexbasedreporting_307394_value", "value"), "value");

				
				ReactSystemFunctions.setValueOf(this, "rolexbasedreporting_74906_toString", ReactSystemFunctions.value(this, "rolexbasedreporting_307394_value", "value"), "value");

				
				ReactSystemFunctions.setValueOf(this, "rolexbasedreporting_848372_toString", ReactSystemFunctions.value(this, "rolexbasedreporting_307394_value", "value"), "value");


		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

            
            return isErrorOccurred;
        }




    async callCallbackFunction(diId: number, isFromMaster: boolean = false) {
        let isErrorOccurred = false;
		let pageInitCallerNavDiIDs = [, , , , , , ] as number[];
		if (isFromMaster || pageInitCallerNavDiIDs.indexOf(diId) > -1) {
			await this.RolexBasedReportingPageInit();
		}

    }


}
