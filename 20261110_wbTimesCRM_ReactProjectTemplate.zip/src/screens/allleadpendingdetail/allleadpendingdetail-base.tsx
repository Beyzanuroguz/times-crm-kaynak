import React from "react";
import Axios, { AxiosResponse } from "axios";
import { KuikaAppManager } from "../../shared/utilty/kuika-app-manager";
import { ReactSystemFunctions } from "../../shared/utilty/react-system-functions";
import { KNavigator } from "../../shared/hoc/with-history";
import { KContext } from "../../shared/hoc/with-context";
import { useLocation } from "react-router-dom";
import { FormInstance } from "antd/es/form";
import { Guid } from "guid-typescript";
import Swal from "sweetalert2";
import { KMainFunctions } from "../../shared/utilty/main-functions";
import moment from "moment";
import { IValidationData } from "../../models/dto/validation-data";
import { IStripePayment } from "../../models/dto/stripe-payment";
import { IUserInfoDto } from "../../models/dto/user-info.dto";
import { UserService } from "../../services/user-service";
import { kuikaCoreWasmBridgeService } from "../../services/_singletons";
import _ from "lodash";
import mqtt, { MqttClient } from "mqtt";
import { IMqttResult } from "../../models/dto/mqtt.dto";


declare let window: any;

export interface IAllLeadPendingDetail_ScreenProps {
  navigator: KNavigator;
  form: FormInstance<any>;
  googleLogin: any;
  screenInputs: any;
  context: KContext;
  initialValues: any;
  children: any;
}

export interface IAllLeadPendingDetail_ScreenState {
    isSpinnerVisible: boolean;
    isPageVisible: boolean;
	isLeftMenuVisible: boolean;
    spinnerCount: number;
    selectedLanguage: string;
    isPageInitLoaded: false;
    isPageRecurringLoaded: false;
	TMGetSameProductLeads: any[];
	TMGetSameProductLeads_dummy: any[];
	TM_GetStore: any[];
	TM_GetStore_dummy: any[];
	TM_GetProductCategory: any[];
	TM_GetProductCategory_dummy: any[];
	TM_GetLeadStatus: any[];
	TM_GetLeadStatus_dummy: any[];
	TM_GetLeadProcess: any[];
	TM_GetLeadProcess_dummy: any[];
	TM_GetSalesPerson: any[];
	TM_GetSalesPerson_dummy: any[];
	SetValueOf: any;
	SetValueOf_dummy: any;
	NAVIGATE: any;
	NAVIGATE_dummy: any;
	isComp1390549895Visible: 'visible' | 'hidden';
	isComp1815110498Visible: 'visible' | 'hidden';
	isComp1829986670Visible: 'visible' | 'hidden';
	isComp1140624241Visible: 'visible' | 'hidden';
	isComp1733992048Visible: 'visible' | 'hidden';
	isComp1109289554Visible: 'visible' | 'hidden';
	isComp794829871Visible: 'visible' | 'hidden';
	isComp259376128Visible: 'visible' | 'hidden';
	isComp1566137016Visible: 'visible' | 'hidden';
	isComp1336712822Visible: 'visible' | 'hidden';
	isComp1662995164Visible: 'visible' | 'hidden';

}

export class AllLeadPendingDetail_ScreenBase extends React.PureComponent<IAllLeadPendingDetail_ScreenProps, any> {

	allleadpendingdetail_1904273601_value_kuikaDateRef: React.RefObject<any>;
	allleadpendingdetail_1827823391_value_kuikaDateRef: React.RefObject<any>;
	allleadpendingdetail_1735739523_value_kuikaTableRef: React.RefObject<any>;
    ml=[{"Id":"d5a61d2b-bd60-485f-86e2-661e9ed4e486","Name":"en_US","ShortName":"English","IsDefault":true,"LanguagePhrases":[]},{"Id":"1f1d4811-8cb7-4192-9464-6f70bb99a24c","Name":"FixedValues","ShortName":"FixedValues","LanguagePhrases":[{"Id":822957,"PropertyName":"value","Value":"Ürüne Ait Tüm Leadleri Görüntüleyin"},{"Id":851146,"PropertyName":"value","Value":"Ürüne ait tüm leadleri görüntüleyin ve termin atamanızda bilgi sahibi olun."},{"Id":482695,"PropertyName":"value","Value":"Ürüne Ait Tüm Onaylanan ve Onay Bekleyen Leadler"},{"Id":923170,"PropertyName":"header","Value":"Filtreler"},{"Id":607311583,"PropertyName":"value","Value":"Müşteri Adı"},{"Id":1393106492,"PropertyName":"placeholder","Value":"Müşteri Adı"},{"Id":1531975066,"PropertyName":"value","Value":"Müşteri Telefon Numarası"},{"Id":226438964,"PropertyName":"placeholder","Value":"Müşteri Telefon Numarası"},{"Id":651456171,"PropertyName":"value","Value":"Ürün Adı"},{"Id":1486438661,"PropertyName":"placeholder","Value":"Ürün Adı"},{"Id":1686419716,"PropertyName":"value","Value":"Kategori"},{"Id":1888449157,"PropertyName":"placeholder","Value":"Kategori"},{"Id":1289573443,"PropertyName":"value","Value":"Mağaza"},{"Id":1836228438,"PropertyName":"placeholder","Value":"Mağaza"},{"Id":642554002,"PropertyName":"value","Value":"Satış Danışmanı"},{"Id":86365187,"PropertyName":"placeholder","Value":"Satış Danışmanı"},{"Id":1978234303,"PropertyName":"value","Value":"Talep Durumu"},{"Id":869961548,"PropertyName":"placeholder","Value":"Talep Durumu"},{"Id":1419844633,"PropertyName":"value","Value":"Başlangıç Tarihi"},{"Id":1424747020,"PropertyName":"value","Value":"Bitiş Tarihi"},{"Id":1684357334,"PropertyName":"label","Value":"Filtreleri Temizle"},{"Id":788616,"PropertyName":"label","Value":"Filtreyi Uygula"},{"Id":852460,"PropertyName":"value","Value":"Talep Numarasına Göre Ara"},{"Id":16517,"PropertyName":"placeholder","Value":"Talep Numarası Giriniz"},{"Id":107293919,"PropertyName":"title","Value":"Talep Tarihi"},{"Id":1681178749,"PropertyName":"value","Value":"[datafield:taleptarihi]"},{"Id":2059573083,"PropertyName":"title","Value":"Talep Numarası"},{"Id":346403413,"PropertyName":"value","Value":"[datafield:leadnumarasi]"},{"Id":2038592747,"PropertyName":"title","Value":"Mağaza"},{"Id":197077549,"PropertyName":"value","Value":"[datafield:storename]"},{"Id":1865985466,"PropertyName":"title","Value":"Marka"},{"Id":780528542,"PropertyName":"value","Value":"[datafield:brand]"},{"Id":39913232,"PropertyName":"title","Value":"Kategori"},{"Id":1390549895,"PropertyName":"value","Value":"[datafield:categoryname]"},{"Id":1815110498,"PropertyName":"value","Value":"[datafield:categoryname]"},{"Id":1829986670,"PropertyName":"value","Value":"[datafield:categoryname]"},{"Id":1140624241,"PropertyName":"value","Value":"[datafield:categoryname]"},{"Id":132937405,"PropertyName":"title","Value":"Ürün Adı"},{"Id":413246892,"PropertyName":"value","Value":"[datafield:productname]"},{"Id":1654833203,"PropertyName":"title","Value":"Müşteri"},{"Id":1095075856,"PropertyName":"value","Value":"[datafield:musteri]"},{"Id":101097380,"PropertyName":"title","Value":"Takip Durumu"},{"Id":1733992048,"PropertyName":"value","Value":"[datafield:leaddurumu]"},{"Id":1109289554,"PropertyName":"value","Value":"[datafield:leaddurumu]"},{"Id":1335809119,"PropertyName":"title","Value":"Sonraki Adım"},{"Id":690283879,"PropertyName":"value","Value":"[datafield:sonrakiadim]"},{"Id":1579947266,"PropertyName":"title","Value":"Satış Danışmanı"},{"Id":1500287824,"PropertyName":"value","Value":"[datafield:satisdanismani]"},{"Id":404209691,"PropertyName":"title","Value":"Talep Durumu"},{"Id":794829871,"PropertyName":"value","Value":"[datafield:processname]"},{"Id":259376128,"PropertyName":"value","Value":"[datafield:processname]"},{"Id":1566137016,"PropertyName":"value","Value":"[datafield:processname]"},{"Id":1336712822,"PropertyName":"value","Value":"[datafield:processname]"},{"Id":1662995164,"PropertyName":"value","Value":"[datafield:processname]"},{"Id":1303532303,"PropertyName":"title","Value":"Termin Önerisi/Termin"},{"Id":1505567879,"PropertyName":"value","Value":"[datafield:termintarihitext]"},{"Id":222311101,"PropertyName":"title","Value":"Detay"},{"Id":12401070,"PropertyName":"label","Value":"Detay"},{"Id":1743018118,"PropertyName":"label","Value":"Mevcut Sekme"},{"Id":1492248385,"PropertyName":"label","Value":"Yeni Sekme"}]}]
    defaultML = "en_US"
    
    screenHash = ""
    


    constructor(props) {
        super(props);
		this.allleadpendingdetail_1393106492_value_kuikaTextInputRef = React.createRef();
		this.allleadpendingdetail_226438964_value_kuikaTextInputRef = React.createRef();
		this.allleadpendingdetail_1486438661_value_kuikaTextInputRef = React.createRef();
		this.allleadpendingdetail_1904273601_value_kuikaDateRef = React.createRef();
		this.allleadpendingdetail_1827823391_value_kuikaDateRef = React.createRef();
		this.allleadpendingdetail_16517_value_kuikaTextInputRef = React.createRef();
		this.allleadpendingdetail_1735739523_value_kuikaTableRef = React.createRef();

        this.state = {
            isSpinnerVisible: false,
            isPageVisible: false,
            isLeftMenuVisible: false,
            spinnerCount: 0,
            selectedLanguage: "",
            isPageInitLoaded: false,
            isPageRecurringLoaded: false,
            	        TMGetSameProductLeads: [],
	        TM_GetStore: [],
	        TM_GetProductCategory: [],
	        TM_GetLeadStatus: [],
	        TM_GetLeadProcess: [],
	        TM_GetSalesPerson: [],
	        SetValueOf: "",
	        NAVIGATE: "",
	        isComp1390549895Visible: 'hidden',
	        isComp1815110498Visible: 'hidden',
	        isComp1829986670Visible: 'hidden',
	        isComp1140624241Visible: 'hidden',
	        isComp1733992048Visible: 'hidden',
	        isComp1109289554Visible: 'hidden',
	        isComp794829871Visible: 'hidden',
	        isComp259376128Visible: 'hidden',
	        isComp1566137016Visible: 'hidden',
	        isComp1336712822Visible: 'hidden',
	        isComp1662995164Visible: 'hidden',

        }

        this.CheckPageAuthorization(this.state);

        
    }

    async componentDidMount() {

        if (KuikaAppManager.isPageInitPrevented()) {
            KuikaAppManager.calculateAndSetBodyHeight("allleadpendingdetail", "");
            return;
        }
        
        
        ReactSystemFunctions.validateToken()
        this.fillFormInitValues();
        if (true){
            await this.AllLeadPendingDetailPageInit();
        }
        
        
        
        KuikaAppManager.calculateAndSetBodyHeight("allleadpendingdetail", "");

        if (ReactSystemFunctions.getIsMicroApp() === false) {
           window.parentScreen = this;
        }
    }

    componentWillUnmount() {
        
        
        

        if (ReactSystemFunctions.getIsMicroApp() === false) {
           window.parentScreen = null;
        }
    }

    
              CheckPageAuthorization = async (state) => {
                KuikaAppManager.showSpinner(this);
                if (_.isEmpty(window.userInfo)) {
                  await UserService.GetUserInfoForce();
                }
                const permittedRoleNames: string[] = ["TimesYonetici","TimesUstYonetici","TimesMagazaMuduru",];
                const userInfo = window.userInfo as IUserInfoDto;
                const userRoleNames = userInfo.roles.map((role) => role.name);
                if (!ReactSystemFunctions.hasAnyRoleName(permittedRoleNames, userRoleNames)) {
                  await ReactSystemFunctions.goBack(this);

                  const language = localStorage.getItem("ml");
                  let permissonErrorMessageText = "You do not have permission to access this page.";
                  if (language === "tr_TR") {
                    permissonErrorMessageText = "Bu sayfaya erişim yetkiniz yok.";
                  } else if (language === "fr_FR") {
                    permissonErrorMessageText = "Vous n'avez pas la permission d'accéder à cette page.";
                  } else if (language === "de_DE") {
                    permissonErrorMessageText = "Sie haben keine Berechtigung, auf diese Seite zuzugreifen.";
                  } else if (language === "es_ES") {
                    permissonErrorMessageText = "No tienes permiso para acceder a esta página.";
                  }

                  KMainFunctions.displayErrorNotification(permissonErrorMessageText);
                  state.isPageVisible = false;
                  KuikaAppManager.hideSpinner(this);
                  return;
                }
                state.isPageVisible = true;
                KuikaAppManager.hideSpinner(this);
              };
        

        
    componentDidUpdate= async (prevProps, prevState) => {
		KuikaAppManager.calculateAndSetBodyHeight("allleadpendingdetail", ""    );
        if (prevProps?.location?.search !== (this.props as any)?.location?.search) {
			await this.AllLeadPendingDetailPageInit();
		}

        

        if (ReactSystemFunctions.getIsMicroApp() === false) {
            for (const key in prevState) {
                if (key.startsWith('NavVisible') && prevState[key] === true && this.state[key] === false) {
                    window.parentScreen = this;
                    break;
                }
            }
        }
	}

    fillFormInitValues() {
        this.props.form?.setFieldsValue({
});

    }

      setPageInitLoaded = (value: boolean) => {
        this.setState({ isPageInitLoaded: value });
      }

      setPageRecurringLoaded = (value: boolean) => {
        this.setState({ isPageRecurringLoaded: value });
      }

      clearFieldValidation = (changedValues: any) => {
        const fieldName = Object.keys(changedValues)[0];
        if (fieldName) {
          this.props.form?.setFields([
            {
              name: fieldName,
              errors: []
            }
          ]);
        }
      };

      

    AllLeadPendingDetailPageInit = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


	if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }

        let localVar = {
			LeadId_0: ReactSystemFunctions.convertToTypeByName(this.props.screenInputs.LeadId ?? this.props.screenInputs.leadid, "Guid"),
			UserId_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.getMyUserId(), "Guid"),
			LeadCode_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "allleadpendingdetail_16517_value", "value", "", "", "")), "string"),
			MusteriAdi_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "allleadpendingdetail_1393106492_value", "value", "", "", "")), "string"),
			Tel_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "allleadpendingdetail_226438964_value", "value", "", "", "")), "string"),
			ProductName_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "allleadpendingdetail_1486438661_value", "value", "", "", "")), "string"),
			CategoryName_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "allleadpendingdetail_1888449157_value", "value", "TM_GetProductCategory", "categoryCode", "categoryName")), "string"),
			StoreIds_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "allleadpendingdetail_1836228438_value", "value", "TM_GetStore", "storeCode", "id")), "string"),
			SatisDanismaniIds_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "allleadpendingdetail_86365187_value", "value", "TM_GetSalesPerson", "kUserId", "kUserId")), "string"),
			ProcessCode_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "allleadpendingdetail_869961548_value", "value", "TM_GetLeadProcess", "id", "code")), "string"),
			StartDate_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "allleadpendingdetail_1904273601_value", "value", "", "", "")), "Date"),
			EndDate_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "allleadpendingdetail_1827823391_value", "value", "", "", "")), "Date"),
			KUserId_1: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.getMyUserId(), "Guid"),
			StepOrder_4: ReactSystemFunctions.convertToTypeByName(0, "number"),
			KUserId_5: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.getMyUserId(), "Guid"),
			StoreId_5: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, (stateVars.TM_GetStore !== undefined ? (stateVars.TM_GetStore?.length > 0 ? stateVars.TM_GetStore[0].id : null) : (this.state.TM_GetStore?.length > 0 ? this.state.TM_GetStore[0].id : null))), "Guid")
        }

	KuikaAppManager.showSpinner(this);
	
        if (true) {
        KuikaAppManager.showSpinner(this);
        }
        let result = await KuikaAppManager.ApiRequest(this, "AllLeadPendingDetail/AllLeadPendingDetailPageInit", localVar)
        if (!KMainFunctions.IsResStatus2XX(result)) return true;

		stateVars.TMGetSameProductLeads = result?.data.tmGetSameProductLeads;
		
		stateVars.TM_GetStore = result?.data.tM_GetStore;
		
		formVars.allleadpendingdetail_1836228438_options = stateVars.TM_GetStore;
		stateVars.TM_GetProductCategory = result?.data.tM_GetProductCategory;
		
		formVars.allleadpendingdetail_1888449157_options = stateVars.TM_GetProductCategory;
		stateVars.TM_GetLeadStatus = result?.data.tM_GetLeadStatus;
		stateVars.TM_GetLeadProcess = result?.data.tM_GetLeadProcess;
		
		formVars.allleadpendingdetail_869961548_options = stateVars.TM_GetLeadProcess;
		stateVars.TM_GetSalesPerson = result?.data.tM_GetSalesPerson;
		
		formVars.allleadpendingdetail_86365187_options = stateVars.TM_GetSalesPerson;
		this.props.form?.setFieldsValue(formVars);
		
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.AllLeadPendingDetailPageInit1_();
                  resolve();
                });
          })



        
        KuikaAppManager.hideSpinner(this);
        return isErrorOccurred;
    }
	AllLeadPendingDetailPageInit1_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


	if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }

			
			stateVars.dataSource_1888449157 = stateVars.TM_GetProductCategory ?? this.state.TM_GetProductCategory;
			stateVars.dataSource_1888449157 = stateVars.TM_GetProductCategory ?? this.state.TM_GetProductCategory;
			
			stateVars.dataSource_1836228438 = stateVars.TM_GetStore ?? this.state.TM_GetStore;
			stateVars.dataSource_1836228438 = stateVars.TM_GetStore ?? this.state.TM_GetStore;
			
			stateVars.dataSource_86365187 = stateVars.TM_GetSalesPerson ?? this.state.TM_GetSalesPerson;
			stateVars.dataSource_86365187 = stateVars.TM_GetSalesPerson ?? this.state.TM_GetSalesPerson;
			
			stateVars.dataSource_869961548 = stateVars.TM_GetLeadProcess ?? this.state.TM_GetLeadProcess;
			stateVars.dataSource_869961548 = stateVars.TM_GetLeadProcess ?? this.state.TM_GetLeadProcess;
			
			stateVars.dataSource_1735739523 = stateVars.TMGetSameProductLeads ?? this.state.TMGetSameProductLeads;
			stateVars.isComp1390549895Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, "allleadpendingdetail_1735739523_value", "categoryName"), ReactSystemFunctions.convertToTypeByName("Kategori 2", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp1815110498Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, "allleadpendingdetail_1735739523_value", "categoryName"), ReactSystemFunctions.convertToTypeByName("Kategori 1", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp1829986670Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, "allleadpendingdetail_1735739523_value", "categoryName"), ReactSystemFunctions.convertToTypeByName("DEFAULT", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp1140624241Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, "allleadpendingdetail_1735739523_value", "categoryName"), ReactSystemFunctions.convertToTypeByName("Kategori 3", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp1733992048Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, "allleadpendingdetail_1735739523_value", "leadDurumu"), ReactSystemFunctions.convertToTypeByName("Takip ediliyor", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp1109289554Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, "allleadpendingdetail_1735739523_value", "leadDurumu"), ReactSystemFunctions.convertToTypeByName("2. Takip", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp794829871Visible = (((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, "allleadpendingdetail_1735739523_value", "processCode"), ReactSystemFunctions.convertToTypeByName("PENDING", "string")) || ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, "allleadpendingdetail_1735739523_value", "processCode"), ReactSystemFunctions.convertToTypeByName("TERMIN_PENDING", "string")) || ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, "allleadpendingdetail_1735739523_value", "processCode"), ReactSystemFunctions.convertToTypeByName("DELIVERY_PENDING", "string")))) === true ? "visible" : "hidden")
			stateVars.isComp259376128Visible = (((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, "allleadpendingdetail_1735739523_value", "processCode"), ReactSystemFunctions.convertToTypeByName("CUSTOMER_DECLINED", "string")) || ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, "allleadpendingdetail_1735739523_value", "processCode"), ReactSystemFunctions.convertToTypeByName("REJECTED", "string")))) === true ? "visible" : "hidden")
			stateVars.isComp1566137016Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, "allleadpendingdetail_1735739523_value", "processCode"), ReactSystemFunctions.convertToTypeByName("DELIVERED", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp1336712822Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, "allleadpendingdetail_1735739523_value", "processCode"), ReactSystemFunctions.convertToTypeByName("CLOSED", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp1662995164Visible = (((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, "allleadpendingdetail_1735739523_value", "processCode"), ReactSystemFunctions.convertToTypeByName("APPROVED", "string")) || ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, "allleadpendingdetail_1735739523_value", "processCode"), ReactSystemFunctions.convertToTypeByName("CREATED", "string")))) === true ? "visible" : "hidden")

	this.props.form?.setFieldsValue(formVars);
	this.setState(stateVars);
	KuikaAppManager.hideSpinner(this);

            this.setPageInitLoaded(true);
            return isErrorOccurred;
        }




		AllLeadPendingDetailComponent_1684357334_onClick = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
KuikaAppManager.showSpinner(this);

				stateVars.SetValueOf = await ReactSystemFunctions.setValueOf(this, ReactSystemFunctions.convertToTypeByName("allleadpendingdetail_1393106492_value", "string"), "", null, false);
				stateVars.SetValueOf = await ReactSystemFunctions.setValueOf(this, ReactSystemFunctions.convertToTypeByName("allleadpendingdetail_226438964_value", "string"), "", null, false);
				stateVars.SetValueOf = await ReactSystemFunctions.setValueOf(this, ReactSystemFunctions.convertToTypeByName("allleadpendingdetail_1486438661_value", "string"), "", null, false);
				stateVars.SetValueOf = await ReactSystemFunctions.setValueOf(this, ReactSystemFunctions.convertToTypeByName("allleadpendingdetail_1888449157_value", "string"), "", null, false);
				stateVars.SetValueOf = await ReactSystemFunctions.setValueOf(this, ReactSystemFunctions.convertToTypeByName("allleadpendingdetail_1836228438_value", "string"), "", null, false);
				stateVars.SetValueOf = await ReactSystemFunctions.setValueOf(this, ReactSystemFunctions.convertToTypeByName("allleadpendingdetail_86365187_value", "string"), "", null, false);
				stateVars.SetValueOf = await ReactSystemFunctions.setValueOf(this, ReactSystemFunctions.convertToTypeByName("allleadpendingdetail_869961548_value", "string"), "", null, false);
				stateVars.SetValueOf = await ReactSystemFunctions.setValueOf(this, ReactSystemFunctions.convertToTypeByName("allleadpendingdetail_1904273601_value", "string"), "", null, false);
				stateVars.SetValueOf = await ReactSystemFunctions.setValueOf(this, ReactSystemFunctions.convertToTypeByName("allleadpendingdetail_1827823391_value", "string"), "", null, false);

		this.props.form?.setFieldsValue(formVars);
		
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.AllLeadPendingDetailComponent_1684357334_onClick1_();
                  resolve();
                });
          })

            
            return isErrorOccurred;
        }
    AllLeadPendingDetailComponent_1684357334_onClick1_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
		KuikaAppManager.increaseServerRequestCount();

        let localVar = {
				LeadId_0: ReactSystemFunctions.convertToTypeByName(this.props.screenInputs.LeadId ?? this.props.screenInputs.leadid, "Guid"),
				UserId_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.getMyUserId(), "Guid"),
				LeadCode_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "allleadpendingdetail_16517_value", "value", "", "", "")), "string"),
				MusteriAdi_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "allleadpendingdetail_1393106492_value", "value", "", "", "")), "string"),
				Tel_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "allleadpendingdetail_226438964_value", "value", "", "", "")), "string"),
				ProductName_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "allleadpendingdetail_1486438661_value", "value", "", "", "")), "string"),
				CategoryName_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "allleadpendingdetail_1888449157_value", "value", "TM_GetProductCategory", "categoryCode", "categoryName")), "string"),
				StoreIds_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "allleadpendingdetail_1836228438_value", "value", "TM_GetStore", "storeCode", "id")), "string"),
				SatisDanismaniIds_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "allleadpendingdetail_86365187_value", "value", "TM_GetSalesPerson", "kUserId", "kUserId")), "string"),
				ProcessCode_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "allleadpendingdetail_869961548_value", "value", "TM_GetLeadProcess", "id", "code")), "string"),
				StartDate_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "allleadpendingdetail_1904273601_value", "value", "", "", "")), "Date"),
				EndDate_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "allleadpendingdetail_1827823391_value", "value", "", "", "")), "Date")
        }

		
        if (true) {
        KuikaAppManager.showSpinner(this);
        }
        let result = await KuikaAppManager.ApiRequest(this, "AllLeadPendingDetail/AllLeadPendingDetailComponent_1684357334_onClick1_", localVar)
        if (!KMainFunctions.IsResStatus2XX(result)) return true;

			stateVars.TMGetSameProductLeads = result?.data.tmGetSameProductLeads;
			
			this.props.form?.setFieldsValue(formVars);
			
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.AllLeadPendingDetailComponent_1684357334_onClick2_();
                  resolve();
                });
          })



        
        KuikaAppManager.hideSpinner(this);
        return isErrorOccurred;
    }
		AllLeadPendingDetailComponent_1684357334_onClick2_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }

				
				stateVars.dataSource_1735739523 = stateVars.TMGetSameProductLeads ?? this.state.TMGetSameProductLeads;

		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

            
            return isErrorOccurred;
        }





    AllLeadPendingDetailComponent_788616_onClick = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
		KuikaAppManager.increaseServerRequestCount();

        let localVar = {
				LeadId_0: ReactSystemFunctions.convertToTypeByName(this.props.screenInputs.LeadId ?? this.props.screenInputs.leadid, "Guid"),
				UserId_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.getMyUserId(), "Guid"),
				LeadCode_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "allleadpendingdetail_16517_value", "value", "", "", "")), "string"),
				MusteriAdi_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "allleadpendingdetail_1393106492_value", "value", "", "", "")), "string"),
				Tel_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "allleadpendingdetail_226438964_value", "value", "", "", "")), "string"),
				ProductName_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "allleadpendingdetail_1486438661_value", "value", "", "", "")), "string"),
				CategoryName_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "allleadpendingdetail_1888449157_value", "value", "TM_GetProductCategory", "categoryCode", "categoryName")), "string"),
				StoreIds_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "allleadpendingdetail_1836228438_value", "value", "TM_GetStore", "storeCode", "id")), "string"),
				SatisDanismaniIds_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "allleadpendingdetail_86365187_value", "value", "TM_GetSalesPerson", "kUserId", "kUserId")), "string"),
				ProcessCode_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "allleadpendingdetail_869961548_value", "value", "TM_GetLeadProcess", "id", "code")), "string"),
				StartDate_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "allleadpendingdetail_1904273601_value", "value", "", "", "")), "Date"),
				EndDate_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "allleadpendingdetail_1827823391_value", "value", "", "", "")), "Date")
        }

		KuikaAppManager.showSpinner(this);
		
        if (true) {
        KuikaAppManager.showSpinner(this);
        }
        let result = await KuikaAppManager.ApiRequest(this, "AllLeadPendingDetail/AllLeadPendingDetailComponent_788616_onClick", localVar)
        if (!KMainFunctions.IsResStatus2XX(result)) return true;

			stateVars.TMGetSameProductLeads = result?.data.tmGetSameProductLeads;
			
			this.props.form?.setFieldsValue(formVars);
			
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.AllLeadPendingDetailComponent_788616_onClick1_();
                  resolve();
                });
          })



        
        KuikaAppManager.hideSpinner(this);
        return isErrorOccurred;
    }
		AllLeadPendingDetailComponent_788616_onClick1_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }

				
				stateVars.dataSource_1735739523 = stateVars.TMGetSameProductLeads ?? this.state.TMGetSameProductLeads;

		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

            
            return isErrorOccurred;
        }




    AllLeadPendingDetailComponent_16517_onBlur = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
		KuikaAppManager.increaseServerRequestCount();

        let localVar = {
				LeadId_0: ReactSystemFunctions.convertToTypeByName(this.props.screenInputs.LeadId ?? this.props.screenInputs.leadid, "Guid"),
				UserId_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.getMyUserId(), "Guid"),
				LeadCode_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "allleadpendingdetail_16517_value", "value", "", "", "")), "string"),
				MusteriAdi_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "allleadpendingdetail_1393106492_value", "value", "", "", "")), "string"),
				Tel_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "allleadpendingdetail_226438964_value", "value", "", "", "")), "string"),
				ProductName_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "allleadpendingdetail_1486438661_value", "value", "", "", "")), "string"),
				CategoryName_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "allleadpendingdetail_1888449157_value", "value", "TM_GetProductCategory", "categoryCode", "categoryName")), "string"),
				StoreIds_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "allleadpendingdetail_1836228438_value", "value", "TM_GetStore", "storeCode", "id")), "string"),
				SatisDanismaniIds_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "allleadpendingdetail_86365187_value", "value", "TM_GetSalesPerson", "kUserId", "kUserId")), "string"),
				ProcessCode_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "allleadpendingdetail_869961548_value", "value", "TM_GetLeadProcess", "id", "code")), "string"),
				StartDate_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "allleadpendingdetail_1904273601_value", "value", "", "", "")), "Date"),
				EndDate_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "allleadpendingdetail_1827823391_value", "value", "", "", "")), "Date")
        }

		KuikaAppManager.showSpinner(this);
		
        if (true) {
        KuikaAppManager.showSpinner(this);
        }
        let result = await KuikaAppManager.ApiRequest(this, "AllLeadPendingDetail/AllLeadPendingDetailComponent_16517_onBlur", localVar)
        if (!KMainFunctions.IsResStatus2XX(result)) return true;

			stateVars.TMGetSameProductLeads = result?.data.tmGetSameProductLeads;
			
			this.props.form?.setFieldsValue(formVars);
			
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.AllLeadPendingDetailComponent_16517_onBlur1_();
                  resolve();
                });
          })



        
        KuikaAppManager.hideSpinner(this);
        return isErrorOccurred;
    }
		AllLeadPendingDetailComponent_16517_onBlur1_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }

				
				stateVars.dataSource_1735739523 = stateVars.TMGetSameProductLeads ?? this.state.TMGetSameProductLeads;

		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

            
            return isErrorOccurred;
        }




		AllLeadPendingDetailComponent_212835_onClick = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
KuikaAppManager.showSpinner(this);

				stateVars.SetValueOf = await ReactSystemFunctions.setValueOf(this, ReactSystemFunctions.convertToTypeByName("allleadpendingdetail_16517_value", "string"), "", null, false);

		this.props.form?.setFieldsValue(formVars);
		
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.AllLeadPendingDetailComponent_212835_onClick1_();
                  resolve();
                });
          })

            
            return isErrorOccurred;
        }
    AllLeadPendingDetailComponent_212835_onClick1_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
		KuikaAppManager.increaseServerRequestCount();

        let localVar = {
				LeadId_0: ReactSystemFunctions.convertToTypeByName(this.props.screenInputs.LeadId ?? this.props.screenInputs.leadid, "Guid"),
				UserId_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.getMyUserId(), "Guid"),
				LeadCode_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "allleadpendingdetail_16517_value", "value", "", "", "")), "string"),
				MusteriAdi_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "allleadpendingdetail_1393106492_value", "value", "", "", "")), "string"),
				Tel_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "allleadpendingdetail_226438964_value", "value", "", "", "")), "string"),
				ProductName_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "allleadpendingdetail_1486438661_value", "value", "", "", "")), "string"),
				CategoryName_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "allleadpendingdetail_1888449157_value", "value", "TM_GetProductCategory", "categoryCode", "categoryName")), "string"),
				StoreIds_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "allleadpendingdetail_1836228438_value", "value", "TM_GetStore", "storeCode", "id")), "string"),
				SatisDanismaniIds_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "allleadpendingdetail_86365187_value", "value", "TM_GetSalesPerson", "kUserId", "kUserId")), "string"),
				ProcessCode_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "allleadpendingdetail_869961548_value", "value", "TM_GetLeadProcess", "id", "code")), "string"),
				StartDate_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "allleadpendingdetail_1904273601_value", "value", "", "", "")), "Date"),
				EndDate_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "allleadpendingdetail_1827823391_value", "value", "", "", "")), "Date")
        }

		
        if (true) {
        KuikaAppManager.showSpinner(this);
        }
        let result = await KuikaAppManager.ApiRequest(this, "AllLeadPendingDetail/AllLeadPendingDetailComponent_212835_onClick1_", localVar)
        if (!KMainFunctions.IsResStatus2XX(result)) return true;

			stateVars.TMGetSameProductLeads = result?.data.tmGetSameProductLeads;
			
			this.props.form?.setFieldsValue(formVars);
			
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.AllLeadPendingDetailComponent_212835_onClick2_();
                  resolve();
                });
          })



        
        KuikaAppManager.hideSpinner(this);
        return isErrorOccurred;
    }
		AllLeadPendingDetailComponent_212835_onClick2_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }

				
				stateVars.dataSource_1735739523 = stateVars.TMGetSameProductLeads ?? this.state.TMGetSameProductLeads;

		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

            
            return isErrorOccurred;
        }





		AllLeadPendingDetailComponent_1743018118_onClick = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
KuikaAppManager.showSpinner(this);

					KuikaAppManager.prepareForNavigation();
						KuikaAppManager.addToPageInputVariables("LeadDetailTemp", "LeadId", ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, "allleadpendingdetail_1735739523_value", "leadId"), "Guid"));

				stateVars.NAVIGATE = await ReactSystemFunctions.navigate(this, undefined, "AllLeadPendingDetail", "LeadDetailTemp", "", "7d969ddf-5801-4eb6-b92b-12be35bdd565", "293474136", null, "right", "true", "90%", "100vh", true, false);

		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

            
            return isErrorOccurred;
        }


		AllLeadPendingDetailComponent_1492248385_onClick = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
KuikaAppManager.showSpinner(this);

					KuikaAppManager.prepareForNavigation();
						KuikaAppManager.addToPageInputVariables("LeadDetailTemp", "LeadId", ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, "allleadpendingdetail_1735739523_value", "leadId"), "Guid"));

				stateVars.NAVIGATE = await ReactSystemFunctions.navigate(this, undefined, "AllLeadPendingDetail", "LeadDetailTemp", "", "newTab", null, null, null, null, null, null, true, false);

		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

            
            return isErrorOccurred;
        }




    async callCallbackFunction(diId: number, isFromMaster: boolean = false) {
        let isErrorOccurred = false;
		let pageInitCallerNavDiIDs = [293474136] as number[];
		if (isFromMaster || pageInitCallerNavDiIDs.indexOf(diId) > -1) {
			await this.AllLeadPendingDetailPageInit();
		}

    }


}
