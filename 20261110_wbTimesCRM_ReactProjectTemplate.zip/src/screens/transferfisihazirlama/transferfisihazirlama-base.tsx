import React from "react";
import Axios, { AxiosResponse } from "axios";
import { KuikaAppManager } from "../../shared/utilty/kuika-app-manager";
import { ReactSystemFunctions } from "../../shared/utilty/react-system-functions";
import { KNavigator } from "../../shared/hoc/with-history";
import { KContext } from "../../shared/hoc/with-context";
import { useLocation } from "react-router-dom";
import { FormInstance } from "antd/es/form";
import { Guid } from "guid-typescript";
import Swal from "sweetalert2";
import { KMainFunctions } from "../../shared/utilty/main-functions";
import moment from "moment";
import { IValidationData } from "../../models/dto/validation-data";
import { IStripePayment } from "../../models/dto/stripe-payment";
import { IUserInfoDto } from "../../models/dto/user-info.dto";
import { UserService } from "../../services/user-service";
import { kuikaCoreWasmBridgeService } from "../../services/_singletons";
import _ from "lodash";
import mqtt, { MqttClient } from "mqtt";
import { IMqttResult } from "../../models/dto/mqtt.dto";


declare let window: any;

export interface ITransferFisiHazirlama_ScreenProps {
  navigator: KNavigator;
  form: FormInstance<any>;
  googleLogin: any;
  screenInputs: any;
  context: KContext;
  initialValues: any;
  children: any;
}

export interface ITransferFisiHazirlama_ScreenState {
    isSpinnerVisible: boolean;
    isPageVisible: boolean;
	isLeftMenuVisible: boolean;
    spinnerCount: number;
    selectedLanguage: string;
    isPageInitLoaded: false;
    isPageRecurringLoaded: false;
	TM_GetTransferSlipPreparationLine: any[];
	TM_GetTransferSlipPreparationLine_dummy: any[];
	TMShipmentMethodType: any[];
	TMShipmentMethodType_dummy: any[];
	GoBack: any;
	GoBack_dummy: any;
	TM_ValidateTransferSerialNumber: any[];
	TM_ValidateTransferSerialNumber_dummy: any[];
	Notify: boolean;
	Notify_dummy: boolean;
	Kuika_EShipmentMethod: any[];
	Kuika_EShipmentMethod_dummy: any[];
	CreateTransfer: any;
	CreateTransfer_dummy: any;
	PostAfterTransferCreateSQL: any[];
	PostAfterTransferCreateSQL_dummy: any[];
	NAVIGATE: any;
	NAVIGATE_dummy: any;
	isComp1036737177Visible: 'visible' | 'hidden';
	isComp942437926Visible: 'visible' | 'hidden';
	isComp958162Visible: 'visible' | 'hidden';
	isComp783203Visible: 'visible' | 'hidden';
	isComp748578Visible: 'visible' | 'hidden';
	isComp405987Visible: 'visible' | 'hidden';
	isComp428772875Enabled: 'enabled' | 'disabled';

}

export class TransferFisiHazirlama_ScreenBase extends React.PureComponent<ITransferFisiHazirlama_ScreenProps, any> {

	transferfisihazirlama_848432_value_kuikaAutoCompleteRef: React.RefObject<any>;
	transferfisihazirlama_1920101196_value_kuikaAutoCompleteRef: React.RefObject<any>;
	transferfisihazirlama_871343_value_kuikaTableRef: React.RefObject<any>;
    ml=[{"Id":"d5a61d2b-bd60-485f-86e2-661e9ed4e486","Name":"en_US","ShortName":"English","IsDefault":true,"LanguagePhrases":[]},{"Id":"359562fb-a558-4005-9cbd-423a03800c3f","Name":"FixedValues","ShortName":"FixedValues","LanguagePhrases":[{"Id":155322,"PropertyName":"label","Value":"Transfer Bekleyen Havuzuna Dön"},{"Id":921404,"PropertyName":"value","Value":"Transfer Fişi Hazırlama"},{"Id":817727,"PropertyName":"value","Value":"Hazırlanıyor"},{"Id":255995422,"PropertyName":"value","Value":"Ürün Bilgileri"},{"Id":1496945987,"PropertyName":"value","Value":"Talep No"},{"Id":1945192628,"PropertyName":"value","Value":"Ürün"},{"Id":1375587474,"PropertyName":"value","Value":"Ürün Kodu"},{"Id":1703085204,"PropertyName":"value","Value":"Kaynak Mağaza"},{"Id":2111639219,"PropertyName":"value","Value":"Alıcı Mağaza"},{"Id":1055066734,"PropertyName":"value","Value":"Adet"},{"Id":570050,"PropertyName":"value","Value":"Seri Numarası / Barkod *"},{"Id":1728879334,"PropertyName":"placeholder","Value":"Seri numarası girin"},{"Id":1693368173,"PropertyName":"label","Value":"Kontrol Et"},{"Id":422947,"PropertyName":"value","Value":"Kargo Bilgileri"},{"Id":617799,"PropertyName":"value","Value":"Sevkiyat Şekli"},{"Id":848432,"PropertyName":"placeholder","Value":"Sevkiyat Şekli"},{"Id":1012271945,"PropertyName":"value","Value":"Taşıyıcı/Firma"},{"Id":1920101196,"PropertyName":"placeholder","Value":"Kargo firması seçin"},{"Id":2087355102,"PropertyName":"value","Value":"Fiş Notu"},{"Id":1685620291,"PropertyName":"placeholder","Value":"Fiş için not ekleyin"},{"Id":440843652,"PropertyName":"label","Value":"Vazgeç"},{"Id":428772875,"PropertyName":"label","Value":"Transfer Fişi Oluştur"},{"Id":369102,"PropertyName":"value","Value":"Gönderen"},{"Id":613192,"PropertyName":"value","Value":"Mersin Times"},{"Id":411188,"PropertyName":"value","Value":"Alıcı"},{"Id":982878,"PropertyName":"value","Value":"Adana Times"},{"Id":954818,"PropertyName":"value","Value":"Seçilen Talep"},{"Id":362259,"PropertyName":"value","Value":"2"},{"Id":653426,"PropertyName":"value","Value":"Toplam Ürün Adedi"},{"Id":825751,"PropertyName":"value","Value":"4"},{"Id":338982,"PropertyName":"value","Value":"Talep Numaraları"},{"Id":591543,"PropertyName":"value","Value":"TR-24001, TR-24002"},{"Id":424540,"PropertyName":"header","Value":"Dahil Edilen Talepler 2"},{"Id":880893,"PropertyName":"title","Value":"Talep No"},{"Id":597887,"PropertyName":"value","Value":"TR-24001"},{"Id":302945,"PropertyName":"title","Value":"Ürün"},{"Id":561748,"PropertyName":"value","Value":"Rolex Submariner Date"},{"Id":278366,"PropertyName":"title","Value":"Miktar"},{"Id":727969,"PropertyName":"value","Value":"3"},{"Id":967941,"PropertyName":"title","Value":"Detay"},{"Id":962374,"PropertyName":"value","Value":"Seri girişi bekleniyor"},{"Id":690523,"PropertyName":"value","Value":"Ürünler ve Seri Numaraları"},{"Id":531899,"PropertyName":"value","Value":"3 / 4 seri doğrulandı"},{"Id":58166,"PropertyName":"value","Value":"126711"},{"Id":741631,"PropertyName":"value","Value":"Rolex Submariner Date · 3 adet"},{"Id":682174,"PropertyName":"value","Value":"Sıra"},{"Id":629632,"PropertyName":"value","Value":"Seri Numarası"},{"Id":638704,"PropertyName":"value","Value":"Kontrol Durumu"},{"Id":795453,"PropertyName":"value","Value":"Aksiyon"},{"Id":227449,"PropertyName":"value","Value":"1"},{"Id":359387,"PropertyName":"placeholder","Value":"Seri numarası girin"},{"Id":794027,"PropertyName":"value","Value":"Doğrulandı"},{"Id":139095,"PropertyName":"value","Value":"—"},{"Id":869399,"PropertyName":"value","Value":"2"},{"Id":987316,"PropertyName":"placeholder","Value":"Seri numarası girin"},{"Id":753334,"PropertyName":"value","Value":"Doğrulandı"},{"Id":179727,"PropertyName":"value","Value":"—"},{"Id":60770,"PropertyName":"value","Value":"3"},{"Id":254844,"PropertyName":"placeholder","Value":"Seri numarası girin"},{"Id":180228,"PropertyName":"value","Value":"Bekliyor"},{"Id":619327,"PropertyName":"label","Value":"Kontrol Et"},{"Id":830303,"PropertyName":"value","Value":"126710"},{"Id":66750,"PropertyName":"value","Value":"Rolex GMT-Master II · 1 adet"},{"Id":571969,"PropertyName":"value","Value":"1"},{"Id":135804,"PropertyName":"placeholder","Value":"Seri numarası girin"},{"Id":796952,"PropertyName":"value","Value":"Doğrulandı"},{"Id":568581,"PropertyName":"value","Value":"—"},{"Id":586855,"PropertyName":"value","Value":"Hazırlık Özeti"},{"Id":516303,"PropertyName":"value","Value":"Mersin Times → Adana Times"},{"Id":367383,"PropertyName":"value","Value":"2 seçili talep · 4 toplam ürün · 3 doğrulanmış seri"},{"Id":706237,"PropertyName":"value","Value":"Kargo: Seçim bekleniyor"},{"Id":639770,"PropertyName":"label","Value":"Havuza Dön"},{"Id":677355,"PropertyName":"label","Value":"Transfer Et"}]}]
    defaultML = "en_US"
    
    screenHash = ""
    


    constructor(props) {
        super(props);
		this.transferfisihazirlama_1728879334_value_kuikaTextInputRef = React.createRef();
		this.transferfisihazirlama_848432_value_kuikaAutoCompleteRef = React.createRef();
		this.transferfisihazirlama_1920101196_value_kuikaAutoCompleteRef = React.createRef();
		this.transferfisihazirlama_871343_value_kuikaTableRef = React.createRef();
		this.transferfisihazirlama_359387_value_kuikaTextInputRef = React.createRef();
		this.transferfisihazirlama_987316_value_kuikaTextInputRef = React.createRef();
		this.transferfisihazirlama_254844_value_kuikaTextInputRef = React.createRef();
		this.transferfisihazirlama_135804_value_kuikaTextInputRef = React.createRef();

        this.state = {
            isSpinnerVisible: false,
            isPageVisible: false,
            isLeftMenuVisible: false,
            spinnerCount: 0,
            selectedLanguage: "",
            isPageInitLoaded: false,
            isPageRecurringLoaded: false,
            	        TM_GetTransferSlipPreparationLine: [],
	        TMShipmentMethodType: [],
	        GoBack: "",
	        TM_ValidateTransferSerialNumber: [],
	        Notify: false,
	        Kuika_EShipmentMethod: [],
	        CreateTransfer: "",
	        PostAfterTransferCreateSQL: [],
	        NAVIGATE: "",
	        isComp1036737177Visible: 'hidden',
	        isComp942437926Visible: 'hidden',
	        isComp958162Visible: 'hidden',
	        isComp783203Visible: 'hidden',
	        isComp748578Visible: 'hidden',
	        isComp405987Visible: 'hidden',
	        isComp428772875Enabled: 'disabled',

        }

        this.state.isPageVisible = true;
        
    }

    async componentDidMount() {

        if (KuikaAppManager.isPageInitPrevented()) {
            KuikaAppManager.calculateAndSetBodyHeight("transferfisihazirlama", "");
            return;
        }
        
        
        ReactSystemFunctions.validateToken()
        this.fillFormInitValues();
        if (true){
            await this.TransferFisiHazirlamaPageInit();
        }
        
        
        
        KuikaAppManager.calculateAndSetBodyHeight("transferfisihazirlama", "");

        if (ReactSystemFunctions.getIsMicroApp() === false) {
           window.parentScreen = this;
        }
    }

    componentWillUnmount() {
        
        
        

        if (ReactSystemFunctions.getIsMicroApp() === false) {
           window.parentScreen = null;
        }
    }

    

        
    componentDidUpdate= async (prevProps, prevState) => {
		KuikaAppManager.calculateAndSetBodyHeight("transferfisihazirlama", ""    );
        if (prevProps?.location?.search !== (this.props as any)?.location?.search) {
			await this.TransferFisiHazirlamaPageInit();
		}

        

        if (ReactSystemFunctions.getIsMicroApp() === false) {
            for (const key in prevState) {
                if (key.startsWith('NavVisible') && prevState[key] === true && this.state[key] === false) {
                    window.parentScreen = this;
                    break;
                }
            }
        }
	}

    fillFormInitValues() {
        this.props.form?.setFieldsValue({
});

    }

      setPageInitLoaded = (value: boolean) => {
        this.setState({ isPageInitLoaded: value });
      }

      setPageRecurringLoaded = (value: boolean) => {
        this.setState({ isPageRecurringLoaded: value });
      }

      clearFieldValidation = (changedValues: any) => {
        const fieldName = Object.keys(changedValues)[0];
        if (fieldName) {
          this.props.form?.setFields([
            {
              name: fieldName,
              errors: []
            }
          ]);
        }
      };

      

    TransferFisiHazirlamaPageInit = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


	if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }

        let localVar = {
			TransferRequestLineId_0: ReactSystemFunctions.convertToTypeByName(this.props.screenInputs.TransferRequestLineId ?? this.props.screenInputs.transferrequestlineid, "Guid")
        }

	KuikaAppManager.showSpinner(this);
	
        if (true) {
        KuikaAppManager.showSpinner(this);
        }
        let result = await KuikaAppManager.ApiRequest(this, "TransferFisiHazirlama/TransferFisiHazirlamaPageInit", localVar)
        if (!KMainFunctions.IsResStatus2XX(result)) return true;

		stateVars.TM_GetTransferSlipPreparationLine = result?.data.tM_GetTransferSlipPreparationLine;
		formVars.transferfisihazirlama_1032902495_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetTransferSlipPreparationLine !== undefined ? (stateVars.TM_GetTransferSlipPreparationLine?.length > 0 ? stateVars.TM_GetTransferSlipPreparationLine[0].requestNumber : null) : (this.state.TM_GetTransferSlipPreparationLine?.length > 0 ? this.state.TM_GetTransferSlipPreparationLine[0].requestNumber : null)));
		formVars.transferfisihazirlama_739462930_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetTransferSlipPreparationLine !== undefined ? (stateVars.TM_GetTransferSlipPreparationLine?.length > 0 ? stateVars.TM_GetTransferSlipPreparationLine[0].productName : null) : (this.state.TM_GetTransferSlipPreparationLine?.length > 0 ? this.state.TM_GetTransferSlipPreparationLine[0].productName : null)));
		formVars.transferfisihazirlama_978293280_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetTransferSlipPreparationLine !== undefined ? (stateVars.TM_GetTransferSlipPreparationLine?.length > 0 ? stateVars.TM_GetTransferSlipPreparationLine[0].productCode : null) : (this.state.TM_GetTransferSlipPreparationLine?.length > 0 ? this.state.TM_GetTransferSlipPreparationLine[0].productCode : null)));
		formVars.transferfisihazirlama_1674102610_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetTransferSlipPreparationLine !== undefined ? (stateVars.TM_GetTransferSlipPreparationLine?.length > 0 ? stateVars.TM_GetTransferSlipPreparationLine[0].sourceStoreName : null) : (this.state.TM_GetTransferSlipPreparationLine?.length > 0 ? this.state.TM_GetTransferSlipPreparationLine[0].sourceStoreName : null)));
		formVars.transferfisihazirlama_1638634488_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetTransferSlipPreparationLine !== undefined ? (stateVars.TM_GetTransferSlipPreparationLine?.length > 0 ? stateVars.TM_GetTransferSlipPreparationLine[0].destinationStoreName : null) : (this.state.TM_GetTransferSlipPreparationLine?.length > 0 ? this.state.TM_GetTransferSlipPreparationLine[0].destinationStoreName : null)));
		formVars.transferfisihazirlama_770220837_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetTransferSlipPreparationLine !== undefined ? (stateVars.TM_GetTransferSlipPreparationLine?.length > 0 ? stateVars.TM_GetTransferSlipPreparationLine[0].requestedQty : null) : (this.state.TM_GetTransferSlipPreparationLine?.length > 0 ? this.state.TM_GetTransferSlipPreparationLine[0].requestedQty : null)));
		stateVars.isComp942437926Visible = (((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, (stateVars.TM_ValidateTransferSerialNumber !== undefined ? (stateVars.TM_ValidateTransferSerialNumber?.length > 0 ? stateVars.TM_ValidateTransferSerialNumber[0].isValid : null) : (this.state.TM_ValidateTransferSerialNumber?.length > 0 ? this.state.TM_ValidateTransferSerialNumber[0].isValid : null))), ReactSystemFunctions.convertToTypeByName("True", "string")) && ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, (stateVars.TM_GetTransferSlipPreparationLine !== undefined ? (stateVars.TM_GetTransferSlipPreparationLine?.length > 0 ? stateVars.TM_GetTransferSlipPreparationLine[0].hasTransferSlip : null) : (this.state.TM_GetTransferSlipPreparationLine?.length > 0 ? this.state.TM_GetTransferSlipPreparationLine[0].hasTransferSlip : null))), ReactSystemFunctions.convertToTypeByName("False", "string")))) === true ? "visible" : "hidden")
		stateVars.isComp428772875Enabled = (((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, (stateVars.TM_ValidateTransferSerialNumber !== undefined ? (stateVars.TM_ValidateTransferSerialNumber?.length > 0 ? stateVars.TM_ValidateTransferSerialNumber[0].isValid : null) : (this.state.TM_ValidateTransferSerialNumber?.length > 0 ? this.state.TM_ValidateTransferSerialNumber[0].isValid : null))), ReactSystemFunctions.convertToTypeByName("True", "string")) && ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, (stateVars.TM_GetTransferSlipPreparationLine !== undefined ? (stateVars.TM_GetTransferSlipPreparationLine?.length > 0 ? stateVars.TM_GetTransferSlipPreparationLine[0].hasTransferSlip : null) : (this.state.TM_GetTransferSlipPreparationLine?.length > 0 ? this.state.TM_GetTransferSlipPreparationLine[0].hasTransferSlip : null))), ReactSystemFunctions.convertToTypeByName("False", "string")))) === true ? "enabled" : "disabled")
		stateVars.TMShipmentMethodType = result?.data.tmShipmentMethodType;
		
		formVars.transferfisihazirlama_848432_options = stateVars.TMShipmentMethodType;
		this.props.form?.setFieldsValue(formVars);
		
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.TransferFisiHazirlamaPageInit1_();
                  resolve();
                });
          })



        
        KuikaAppManager.hideSpinner(this);
        return isErrorOccurred;
    }
	TransferFisiHazirlamaPageInit1_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


	if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }

			formVars.transferfisihazirlama_1032902495_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetTransferSlipPreparationLine !== undefined ? (stateVars.TM_GetTransferSlipPreparationLine?.length > 0 ? stateVars.TM_GetTransferSlipPreparationLine[0].requestNumber : null) : (this.state.TM_GetTransferSlipPreparationLine?.length > 0 ? this.state.TM_GetTransferSlipPreparationLine[0].requestNumber : null)));

			formVars.transferfisihazirlama_739462930_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetTransferSlipPreparationLine !== undefined ? (stateVars.TM_GetTransferSlipPreparationLine?.length > 0 ? stateVars.TM_GetTransferSlipPreparationLine[0].productName : null) : (this.state.TM_GetTransferSlipPreparationLine?.length > 0 ? this.state.TM_GetTransferSlipPreparationLine[0].productName : null)));

			formVars.transferfisihazirlama_978293280_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetTransferSlipPreparationLine !== undefined ? (stateVars.TM_GetTransferSlipPreparationLine?.length > 0 ? stateVars.TM_GetTransferSlipPreparationLine[0].productCode : null) : (this.state.TM_GetTransferSlipPreparationLine?.length > 0 ? this.state.TM_GetTransferSlipPreparationLine[0].productCode : null)));

			formVars.transferfisihazirlama_1674102610_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetTransferSlipPreparationLine !== undefined ? (stateVars.TM_GetTransferSlipPreparationLine?.length > 0 ? stateVars.TM_GetTransferSlipPreparationLine[0].sourceStoreName : null) : (this.state.TM_GetTransferSlipPreparationLine?.length > 0 ? this.state.TM_GetTransferSlipPreparationLine[0].sourceStoreName : null)));

			formVars.transferfisihazirlama_1638634488_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetTransferSlipPreparationLine !== undefined ? (stateVars.TM_GetTransferSlipPreparationLine?.length > 0 ? stateVars.TM_GetTransferSlipPreparationLine[0].destinationStoreName : null) : (this.state.TM_GetTransferSlipPreparationLine?.length > 0 ? this.state.TM_GetTransferSlipPreparationLine[0].destinationStoreName : null)));

			formVars.transferfisihazirlama_770220837_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetTransferSlipPreparationLine !== undefined ? (stateVars.TM_GetTransferSlipPreparationLine?.length > 0 ? stateVars.TM_GetTransferSlipPreparationLine[0].requestedQty : null) : (this.state.TM_GetTransferSlipPreparationLine?.length > 0 ? this.state.TM_GetTransferSlipPreparationLine[0].requestedQty : null)));

			stateVars.isComp1036737177Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, (stateVars.TM_ValidateTransferSerialNumber !== undefined ? (stateVars.TM_ValidateTransferSerialNumber?.length > 0 ? stateVars.TM_ValidateTransferSerialNumber[0].isValid : null) : (this.state.TM_ValidateTransferSerialNumber?.length > 0 ? this.state.TM_ValidateTransferSerialNumber[0].isValid : null))), ReactSystemFunctions.convertToTypeByName("True", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp942437926Visible = (((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, (stateVars.TM_ValidateTransferSerialNumber !== undefined ? (stateVars.TM_ValidateTransferSerialNumber?.length > 0 ? stateVars.TM_ValidateTransferSerialNumber[0].isValid : null) : (this.state.TM_ValidateTransferSerialNumber?.length > 0 ? this.state.TM_ValidateTransferSerialNumber[0].isValid : null))), ReactSystemFunctions.convertToTypeByName("True", "string")) && ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, (stateVars.TM_GetTransferSlipPreparationLine !== undefined ? (stateVars.TM_GetTransferSlipPreparationLine?.length > 0 ? stateVars.TM_GetTransferSlipPreparationLine[0].hasTransferSlip : null) : (this.state.TM_GetTransferSlipPreparationLine?.length > 0 ? this.state.TM_GetTransferSlipPreparationLine[0].hasTransferSlip : null))), ReactSystemFunctions.convertToTypeByName("False", "string")))) === true ? "visible" : "hidden")
			
			stateVars.dataSource_848432 = stateVars.TMShipmentMethodType ?? this.state.TMShipmentMethodType;
			stateVars.dataSource_848432 = stateVars.TMShipmentMethodType ?? this.state.TMShipmentMethodType;
			stateVars.isComp428772875Enabled = (((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, (stateVars.TM_ValidateTransferSerialNumber !== undefined ? (stateVars.TM_ValidateTransferSerialNumber?.length > 0 ? stateVars.TM_ValidateTransferSerialNumber[0].isValid : null) : (this.state.TM_ValidateTransferSerialNumber?.length > 0 ? this.state.TM_ValidateTransferSerialNumber[0].isValid : null))), ReactSystemFunctions.convertToTypeByName("True", "string")) && ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, (stateVars.TM_GetTransferSlipPreparationLine !== undefined ? (stateVars.TM_GetTransferSlipPreparationLine?.length > 0 ? stateVars.TM_GetTransferSlipPreparationLine[0].hasTransferSlip : null) : (this.state.TM_GetTransferSlipPreparationLine?.length > 0 ? this.state.TM_GetTransferSlipPreparationLine[0].hasTransferSlip : null))), ReactSystemFunctions.convertToTypeByName("False", "string")))) === true ? "enabled" : "disabled")

	this.props.form?.setFieldsValue(formVars);
	this.setState(stateVars);
	KuikaAppManager.hideSpinner(this);

            this.setPageInitLoaded(true);
            return isErrorOccurred;
        }




		TransferFisiHazirlamaComponent_155322_onClick = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
KuikaAppManager.showSpinner(this);

				stateVars.GoBack = await ReactSystemFunctions.goBack(this, false);

		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

            
            return isErrorOccurred;
        }


    TransferFisiHazirlamaComponent_1693368173_onClick = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
		KuikaAppManager.increaseServerRequestCount();

        let localVar = {
				SerialNumber_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "transferfisihazirlama_1728879334_value", "value", "", "", "")), "string"),
				TransferRequestLineId_0: ReactSystemFunctions.convertToTypeByName(this.props.screenInputs.TransferRequestLineId ?? this.props.screenInputs.transferrequestlineid, "Guid")
        }

		KuikaAppManager.showSpinner(this);
		
        if (true) {
        KuikaAppManager.showSpinner(this);
        }
        let result = await KuikaAppManager.ApiRequest(this, "TransferFisiHazirlama/TransferFisiHazirlamaComponent_1693368173_onClick", localVar)
        if (!KMainFunctions.IsResStatus2XX(result)) return true;

			stateVars.TM_ValidateTransferSerialNumber = result?.data.tM_ValidateTransferSerialNumber;
			formVars.transferfisihazirlama_238216_value = ReactSystemFunctions.toString(this, (stateVars.TM_ValidateTransferSerialNumber !== undefined ? (stateVars.TM_ValidateTransferSerialNumber?.length > 0 ? stateVars.TM_ValidateTransferSerialNumber[0].message : null) : (this.state.TM_ValidateTransferSerialNumber?.length > 0 ? this.state.TM_ValidateTransferSerialNumber[0].message : null)));
			stateVars.isComp1036737177Visible = ((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, (stateVars.TM_ValidateTransferSerialNumber !== undefined ? (stateVars.TM_ValidateTransferSerialNumber?.length > 0 ? stateVars.TM_ValidateTransferSerialNumber[0].isValid : null) : (this.state.TM_ValidateTransferSerialNumber?.length > 0 ? this.state.TM_ValidateTransferSerialNumber[0].isValid : null))), ReactSystemFunctions.convertToTypeByName("True", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp942437926Visible = (((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, (stateVars.TM_ValidateTransferSerialNumber !== undefined ? (stateVars.TM_ValidateTransferSerialNumber?.length > 0 ? stateVars.TM_ValidateTransferSerialNumber[0].isValid : null) : (this.state.TM_ValidateTransferSerialNumber?.length > 0 ? this.state.TM_ValidateTransferSerialNumber[0].isValid : null))), ReactSystemFunctions.convertToTypeByName("True", "string")) && ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, (stateVars.TM_GetTransferSlipPreparationLine !== undefined ? (stateVars.TM_GetTransferSlipPreparationLine?.length > 0 ? stateVars.TM_GetTransferSlipPreparationLine[0].hasTransferSlip : null) : (this.state.TM_GetTransferSlipPreparationLine?.length > 0 ? this.state.TM_GetTransferSlipPreparationLine[0].hasTransferSlip : null))), ReactSystemFunctions.convertToTypeByName("False", "string")))) === true ? "visible" : "hidden")
			stateVars.isComp428772875Enabled = (((ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, (stateVars.TM_ValidateTransferSerialNumber !== undefined ? (stateVars.TM_ValidateTransferSerialNumber?.length > 0 ? stateVars.TM_ValidateTransferSerialNumber[0].isValid : null) : (this.state.TM_ValidateTransferSerialNumber?.length > 0 ? this.state.TM_ValidateTransferSerialNumber[0].isValid : null))), ReactSystemFunctions.convertToTypeByName("True", "string")) && ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, (stateVars.TM_GetTransferSlipPreparationLine !== undefined ? (stateVars.TM_GetTransferSlipPreparationLine?.length > 0 ? stateVars.TM_GetTransferSlipPreparationLine[0].hasTransferSlip : null) : (this.state.TM_GetTransferSlipPreparationLine?.length > 0 ? this.state.TM_GetTransferSlipPreparationLine[0].hasTransferSlip : null))), ReactSystemFunctions.convertToTypeByName("False", "string")))) === true ? "enabled" : "disabled")
			this.props.form?.setFieldsValue(formVars);
			
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.TransferFisiHazirlamaComponent_1693368173_onClick1_();
                  resolve();
                });
          })



        
        KuikaAppManager.hideSpinner(this);
        return isErrorOccurred;
    }
		TransferFisiHazirlamaComponent_1693368173_onClick1_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }

				stateVars.Notify = await ReactSystemFunctions.notify(this, ReactSystemFunctions.toString(this, (stateVars.TM_ValidateTransferSerialNumber !== undefined ? (stateVars.TM_ValidateTransferSerialNumber?.length > 0 ? stateVars.TM_ValidateTransferSerialNumber[0].message : null) : (this.state.TM_ValidateTransferSerialNumber?.length > 0 ? this.state.TM_ValidateTransferSerialNumber[0].message : null))), ReactSystemFunctions.convertToTypeByName("default", "string"), ReactSystemFunctions.convertToTypeByName("bottom-right", "string"), 2, ReactSystemFunctions.convertToTypeByName("", "string"), ReactSystemFunctions.convertToTypeByName("", "string"), 0);
				formVars.transferfisihazirlama_238216_value = ReactSystemFunctions.toString(this, (stateVars.TM_ValidateTransferSerialNumber !== undefined ? (stateVars.TM_ValidateTransferSerialNumber?.length > 0 ? stateVars.TM_ValidateTransferSerialNumber[0].message : null) : (this.state.TM_ValidateTransferSerialNumber?.length > 0 ? this.state.TM_ValidateTransferSerialNumber[0].message : null)));


		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

            
            return isErrorOccurred;
        }




    TransferFisiHazirlamaComponent_848432_onChange = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;

			validations.push({ 
				isValid: ReactSystemFunctions.isNotEmpty(ReactSystemFunctions.value(this, "transferfisihazirlama_848432_value", "value", "TMShipmentMethodType", "key", ""), null),
				message: "This field is required",
				formName: "transferfisihazirlama_848432_value",
				condition: true
			} as IValidationData);

validations.forEach((validation) => {
            if (validation.message === "Geçerli bir mail adresi giriniz.") {
                validation.message = ReactSystemFunctions.getEmailValidationMessage()
            }
        })

		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
		KuikaAppManager.increaseServerRequestCount();

        let localVar = {
				Type_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toInteger(this, ReactSystemFunctions.value(this, "transferfisihazirlama_848432_value", "value", "TMShipmentMethodType", "key", "")), "number")
        }

		KuikaAppManager.showSpinner(this);
		
        if (true) {
        KuikaAppManager.showSpinner(this);
        }
        let result = await KuikaAppManager.ApiRequest(this, "TransferFisiHazirlama/TransferFisiHazirlamaComponent_848432_onChange", localVar)
        if (!KMainFunctions.IsResStatus2XX(result)) return true;

			stateVars.Kuika_EShipmentMethod = result?.data.kuika_EShipmentMethod;
			
			formVars.transferfisihazirlama_1920101196_options = stateVars.Kuika_EShipmentMethod;
			this.props.form?.setFieldsValue(formVars);
			
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.TransferFisiHazirlamaComponent_848432_onChange1_();
                  resolve();
                });
          })



        
        KuikaAppManager.hideSpinner(this);
        return isErrorOccurred;
    }
		TransferFisiHazirlamaComponent_848432_onChange1_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }

				
				stateVars.dataSource_1920101196 = stateVars.Kuika_EShipmentMethod ?? this.state.Kuika_EShipmentMethod;
				stateVars.dataSource_1920101196 = stateVars.Kuika_EShipmentMethod ?? this.state.Kuika_EShipmentMethod;

		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

            
            return isErrorOccurred;
        }




		TransferFisiHazirlamaComponent_440843652_onClick = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
KuikaAppManager.showSpinner(this);

				stateVars.GoBack = await ReactSystemFunctions.goBack(this, false);

		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

            
            return isErrorOccurred;
        }


    TransferFisiHazirlamaComponent_428772875_onClick = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;

			validations.push({ 
				isValid: ReactSystemFunctions.isNotEmpty(ReactSystemFunctions.value(this, "transferfisihazirlama_848432_value", "value", "TMShipmentMethodType", "key", ""), null),
				message: "This field is required",
				formName: "transferfisihazirlama_848432_value",
				condition: true
			} as IValidationData);

validations.forEach((validation) => {
            if (validation.message === "Geçerli bir mail adresi giriniz.") {
                validation.message = ReactSystemFunctions.getEmailValidationMessage()
            }
        })

		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
		KuikaAppManager.increaseServerRequestCount();

        let localVar = {
				transferRequestLineId_0: ReactSystemFunctions.convertToTypeByName(this.props.screenInputs.TransferRequestLineId ?? this.props.screenInputs.transferrequestlineid, "Guid"),
				serialNumber_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "transferfisihazirlama_1728879334_value", "value", "", "", "")), "string"),
				shippingMethodTypeCode_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "transferfisihazirlama_848432_value", "value", "TMShipmentMethodType", "key", "key")), "string"),
				shippingMethodCode_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "transferfisihazirlama_1920101196_value", "value", "Kuika_EShipmentMethod", "code", "code")), "string")
        }

		KuikaAppManager.showSpinner(this);
if ((ReactSystemFunctions.isNotEmpty(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "transferfisihazirlama_848432_value", "value", "TMShipmentMethodType", "key", "key")), ReactSystemFunctions.convertToTypeByName("True", "string")) && ReactSystemFunctions.isNotEmpty(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "transferfisihazirlama_1920101196_value", "value", "Kuika_EShipmentMethod", "code", "code")), ReactSystemFunctions.convertToTypeByName("True", "string")))) {
            		
        if (true) {
        KuikaAppManager.showSpinner(this);
        }
        let result = await KuikaAppManager.ApiRequest(this, "TransferFisiHazirlama/TransferFisiHazirlamaComponent_428772875_onClick", localVar)
        if (!KMainFunctions.IsResStatus2XX(result)) return true;

			stateVars.CreateTransfer = result?.data.createTransfer;
			this.props.form?.setFieldsValue(formVars);
			
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.TransferFisiHazirlamaComponent_428772875_onClick1_();
                  resolve();
                });
          })

        } else {
            
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.TransferFisiHazirlamaComponent_428772875_onClick1_();
                  resolve();
                });
          })
        }


        
        KuikaAppManager.hideSpinner(this);
        return isErrorOccurred;
    }
    TransferFisiHazirlamaComponent_428772875_onClick1_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;

			validations.push({ 
				isValid: ReactSystemFunctions.isNotEmpty(ReactSystemFunctions.value(this, "transferfisihazirlama_848432_value", "value", "TMShipmentMethodType", "key", ""), null),
				message: "This field is required",
				formName: "transferfisihazirlama_848432_value",
				condition: true
			} as IValidationData);

validations.forEach((validation) => {
            if (validation.message === "Geçerli bir mail adresi giriniz.") {
                validation.message = ReactSystemFunctions.getEmailValidationMessage()
            }
        })

		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
		KuikaAppManager.increaseServerRequestCount();

        let localVar = {
				IsSuccess_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, this.state.CreateTransfer?.isSuccess), "number"),
				ShipmentHeaderID_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, this.state.CreateTransfer?.shipmentHeaderID), "string"),
				ShippingNumber_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, this.state.CreateTransfer?.shippingNumber), "string"),
				ResponseMessage_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, this.state.CreateTransfer?.responseMessage), "string"),
				ShippingMethodCode_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "transferfisihazirlama_1920101196_value", "value", "Kuika_EShipmentMethod", "code", "code")), "string"),
				ShippingMethodDesc_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "transferfisihazirlama_1920101196_value", "value", "Kuika_EShipmentMethod", "code", "description")), "string"),
				ShippingMethodType_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "transferfisihazirlama_848432_value", "value", "TMShipmentMethodType", "key", "key")), "string"),
				ShippingMethodTypeDesc_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "transferfisihazirlama_848432_value", "value", "TMShipmentMethodType", "key", "text")), "string"),
				CurrentUsername_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.getMyUsername(), "string"),
				TransferRequestLineId_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toGuid(this, this.state.CreateTransfer?.transferRequestLineId), "Guid"),
				SerialNumber_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, this.state.CreateTransfer?.serialNumber), "string"),
				Request_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, this.state.CreateTransfer?.request), "string"),
				Response_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.toString(this, this.state.CreateTransfer?.response), "string")
        }

if ((ReactSystemFunctions.isNotEmpty(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "transferfisihazirlama_848432_value", "value", "TMShipmentMethodType", "key", "key")), ReactSystemFunctions.convertToTypeByName("True", "string")) && ReactSystemFunctions.isNotEmpty(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "transferfisihazirlama_1920101196_value", "value", "Kuika_EShipmentMethod", "code", "code")), ReactSystemFunctions.convertToTypeByName("True", "string")))) {
            		
        if (true) {
        KuikaAppManager.showSpinner(this);
        }
        let result = await KuikaAppManager.ApiRequest(this, "TransferFisiHazirlama/TransferFisiHazirlamaComponent_428772875_onClick1_", localVar)
        if (!KMainFunctions.IsResStatus2XX(result)) return true;

			stateVars.PostAfterTransferCreateSQL = result?.data.postAfterTransferCreateSQL;
			this.props.form?.setFieldsValue(formVars);
			
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.TransferFisiHazirlamaComponent_428772875_onClick2_();
                  resolve();
                });
          })

        } else {
            
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.TransferFisiHazirlamaComponent_428772875_onClick2_();
                  resolve();
                });
          })
        }


        
        KuikaAppManager.hideSpinner(this);
        return isErrorOccurred;
    }
		TransferFisiHazirlamaComponent_428772875_onClick2_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }

				stateVars.Notify = await ReactSystemFunctions.notify(this, ReactSystemFunctions.toString(this, this.state.CreateTransfer?.responseMessage), ReactSystemFunctions.convertToTypeByName("default", "string"), ReactSystemFunctions.convertToTypeByName("bottom-right", "string"), 5, ReactSystemFunctions.convertToTypeByName("", "string"), ReactSystemFunctions.convertToTypeByName("", "string"), 0);
				stateVars.Notify = await ReactSystemFunctions.notify(this, ReactSystemFunctions.toString(this, (stateVars.PostAfterTransferCreateSQL !== undefined ? (stateVars.PostAfterTransferCreateSQL?.length > 0 ? stateVars.PostAfterTransferCreateSQL[0].message : null) : (this.state.PostAfterTransferCreateSQL?.length > 0 ? this.state.PostAfterTransferCreateSQL[0].message : null))), ReactSystemFunctions.convertToTypeByName("default", "string"), ReactSystemFunctions.convertToTypeByName("bottom-right", "string"), 3, ReactSystemFunctions.convertToTypeByName("", "string"), ReactSystemFunctions.convertToTypeByName("", "string"), 0);

		this.props.form?.setFieldsValue(formVars);
		
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.TransferFisiHazirlamaComponent_428772875_onClick3_();
                  resolve();
                });
          })

            
            return isErrorOccurred;
        }
		TransferFisiHazirlamaComponent_428772875_onClick3_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
if (ReactSystemFunctions.isEqualTo(ReactSystemFunctions.value(this, this.state.CreateTransfer?.isSuccess), "1")) {
            
					KuikaAppManager.prepareForNavigation();
						KuikaAppManager.addToPageInputVariables("TransferFisiDetayi", "TransferERPHeaderId", ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, (stateVars.PostAfterTransferCreateSQL !== undefined ? (stateVars.PostAfterTransferCreateSQL?.length > 0 ? stateVars.PostAfterTransferCreateSQL[0].transferERPHeaderId : null) : (this.state.PostAfterTransferCreateSQL?.length > 0 ? this.state.PostAfterTransferCreateSQL[0].transferERPHeaderId : null))), "Guid"));

				stateVars.NAVIGATE = await ReactSystemFunctions.navigate(this, this.TransferFisiHazirlamaComponent_428772875_onClick4_, "TransferFisiHazirlama", "TransferFisiDetayi", "", "currentPage", null, null, null, null, null, null, true, false);

		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

        } else {
            
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.TransferFisiHazirlamaComponent_428772875_onClick4_();
                  resolve();
                });
          })
        }

            
            return isErrorOccurred;
        }
		TransferFisiHazirlamaComponent_428772875_onClick4_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
if ((ReactSystemFunctions.isEmpty(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "transferfisihazirlama_848432_value", "value", "TMShipmentMethodType", "key", "text")), true) || ReactSystemFunctions.isEmpty(ReactSystemFunctions.toString(this, ReactSystemFunctions.value(this, "transferfisihazirlama_1920101196_value", "value", "Kuika_EShipmentMethod", "code", "description")), true))) {
            KuikaAppManager.showSpinner(this);

				stateVars.Notify = await ReactSystemFunctions.notify(this, ReactSystemFunctions.translateCustomActions(this.ml,"7d38ac9d_3705_0766_2c01_f5d65e03348a_notify",this.defaultML,"Sevkiyat Şekli veya Taşıyıcı Firma Boş Bırakılamaz!" ), ReactSystemFunctions.convertToTypeByName("default", "string"), ReactSystemFunctions.convertToTypeByName("bottom-right", "string"), 3, ReactSystemFunctions.convertToTypeByName("", "string"), ReactSystemFunctions.convertToTypeByName("", "string"), 0);

		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

        } else {
            KuikaAppManager.hideSpinner(this);
        }

            
            return isErrorOccurred;
        }










    async callCallbackFunction(diId: number, isFromMaster: boolean = false) {
        let isErrorOccurred = false;
		let pageInitCallerNavDiIDs = [] as number[];
		if (isFromMaster || pageInitCallerNavDiIDs.indexOf(diId) > -1) {
			await this.TransferFisiHazirlamaPageInit();
		}

    }


}
