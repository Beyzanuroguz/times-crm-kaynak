import React from "react";
import Axios, { AxiosResponse } from "axios";
import { KuikaAppManager } from "../../shared/utilty/kuika-app-manager";
import { ReactSystemFunctions } from "../../shared/utilty/react-system-functions";
import { KNavigator } from "../../shared/hoc/with-history";
import { KContext } from "../../shared/hoc/with-context";
import { useLocation } from "react-router-dom";
import { FormInstance } from "antd/es/form";
import { Guid } from "guid-typescript";
import Swal from "sweetalert2";
import { KMainFunctions } from "../../shared/utilty/main-functions";
import moment from "moment";
import { IValidationData } from "../../models/dto/validation-data";
import { IStripePayment } from "../../models/dto/stripe-payment";
import { IUserInfoDto } from "../../models/dto/user-info.dto";
import { UserService } from "../../services/user-service";
import { kuikaCoreWasmBridgeService } from "../../services/_singletons";
import _ from "lodash";
import mqtt, { MqttClient } from "mqtt";
import { IMqttResult } from "../../models/dto/mqtt.dto";


declare let window: any;

export interface IReservationPopup1_ScreenProps {
  navigator: KNavigator;
  form: FormInstance<any>;
  googleLogin: any;
  screenInputs: any;
  context: KContext;
  initialValues: any;
  children: any;
}

export interface IReservationPopup1_ScreenState {
    isSpinnerVisible: boolean;
    isPageVisible: boolean;
	isLeftMenuVisible: boolean;
    spinnerCount: number;
    selectedLanguage: string;
    isPageInitLoaded: false;
    isPageRecurringLoaded: false;
	TMGetProductDetailStockByLeadId: any[];
	TMGetProductDetailStockByLeadId_dummy: any[];
	TM_GetLeadById: any[];
	TM_GetLeadById_dummy: any[];
	TM_CheckLeadPriorityNew: any[];
	TM_CheckLeadPriorityNew_dummy: any[];
	GoBack: any;
	GoBack_dummy: any;
	TM_ReserveLead: any[];
	TM_ReserveLead_dummy: any[];
	Notify: boolean;
	Notify_dummy: boolean;
	isComp589964Visible: 'visible' | 'hidden';
	isComp903102Visible: 'visible' | 'hidden';

}

export class ReservationPopup1_ScreenBase extends React.PureComponent<IReservationPopup1_ScreenProps, any> {


    ml=[{"Id":"d5a61d2b-bd60-485f-86e2-661e9ed4e486","Name":"en_US","ShortName":"English","IsDefault":true,"LanguagePhrases":[]},{"Id":"220c420f-b189-4c0f-9ac2-3cb8b03d4204","Name":"FixedValues","ShortName":"FixedValues","LanguagePhrases":[{"Id":60279,"PropertyName":"value","Value":"Ürün Rezerv Talebi"},{"Id":605406,"PropertyName":"value","Value":"Ürün ve talep bilgilerini kontrol ederek rezervasyon isteğinizi oluşturun."},{"Id":24000,"PropertyName":"value","Value":"Ürün Bilgileri"},{"Id":209182,"PropertyName":"value","Value":"Ürün"},{"Id":276299,"PropertyName":"value","Value":"Mağaza"},{"Id":581712,"PropertyName":"value","Value":"Kategori"},{"Id":379537,"PropertyName":"value","Value":"Stok durumu"},{"Id":589964,"PropertyName":"value","Value":"Stokta mevcut"},{"Id":903102,"PropertyName":"value","Value":"Stokta mevcut değil"},{"Id":819498,"PropertyName":"value","Value":"Toplam Stok"},{"Id":545342,"PropertyName":"value","Value":"Rezerve Stok"},{"Id":575461,"PropertyName":"value","Value":"Müsait Stok"},{"Id":211741,"PropertyName":"value","Value":"Talep Bilgileri"},{"Id":925014,"PropertyName":"value","Value":"Müşteri"},{"Id":273480,"PropertyName":"value","Value":"Talep tarihi"},{"Id":135059,"PropertyName":"value","Value":"Talep No"},{"Id":869240,"PropertyName":"value","Value":"Tahmini Teslimat Tarihi"},{"Id":92468,"PropertyName":"value","Value":"Satış Personeli"},{"Id":826375,"PropertyName":"value","Value":"Rezerv Notu"},{"Id":337775,"PropertyName":"value","Value":"Talebinizle ilgili ek bilgi veya teslimat notu paylaşabilirsiniz."},{"Id":635648,"PropertyName":"placeholder","Value":"Rezervasyon notunuzu yazın"},{"Id":517553,"PropertyName":"value","Value":"0/500 karakter"},{"Id":815956,"PropertyName":"label","Value":"Rezerv Talebi Gönder"},{"Id":636855,"PropertyName":"label","Value":"Vazgeç"}]}]
    defaultML = "en_US"
    
    screenHash = ""
    


    constructor(props) {
        super(props);


        this.state = {
            isSpinnerVisible: false,
            isPageVisible: false,
            isLeftMenuVisible: false,
            spinnerCount: 0,
            selectedLanguage: "",
            isPageInitLoaded: false,
            isPageRecurringLoaded: false,
            	        TMGetProductDetailStockByLeadId: [],
	        TM_GetLeadById: [],
	        TM_CheckLeadPriorityNew: [],
	        GoBack: "",
	        TM_ReserveLead: [],
	        Notify: false,
	        isComp589964Visible: 'hidden',
	        isComp903102Visible: 'hidden',

        }

        this.state.isPageVisible = true;
        
    }

    async componentDidMount() {

        if (KuikaAppManager.isPageInitPrevented()) {
            KuikaAppManager.calculateAndSetBodyHeight("reservationpopup1", "");
            return;
        }
        
        
        ReactSystemFunctions.validateToken()
        this.fillFormInitValues();
        if (true){
            await this.reservationPopup1PageInit();
        }
        
        
        
        KuikaAppManager.calculateAndSetBodyHeight("reservationpopup1", "");

        if (ReactSystemFunctions.getIsMicroApp() === false) {
           window.parentScreen = this;
        }
    }

    componentWillUnmount() {
        
        
        

        if (ReactSystemFunctions.getIsMicroApp() === false) {
           window.parentScreen = null;
        }
    }

    

        
    componentDidUpdate= async (prevProps, prevState) => {
		KuikaAppManager.calculateAndSetBodyHeight("reservationpopup1", ""    );
        if (prevProps?.location?.search !== (this.props as any)?.location?.search) {
			await this.reservationPopup1PageInit();
		}

        

        if (ReactSystemFunctions.getIsMicroApp() === false) {
            for (const key in prevState) {
                if (key.startsWith('NavVisible') && prevState[key] === true && this.state[key] === false) {
                    window.parentScreen = this;
                    break;
                }
            }
        }
	}

    fillFormInitValues() {
        this.props.form?.setFieldsValue({
});

    }

      setPageInitLoaded = (value: boolean) => {
        this.setState({ isPageInitLoaded: value });
      }

      setPageRecurringLoaded = (value: boolean) => {
        this.setState({ isPageRecurringLoaded: value });
      }

      clearFieldValidation = (changedValues: any) => {
        const fieldName = Object.keys(changedValues)[0];
        if (fieldName) {
          this.props.form?.setFields([
            {
              name: fieldName,
              errors: []
            }
          ]);
        }
      };

      

    reservationPopup1PageInit = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


	if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }

        let localVar = {
			LeadId_0: ReactSystemFunctions.convertToTypeByName(this.props.screenInputs.LeadId ?? this.props.screenInputs.leadid, "Guid"),
			LeadId_1: ReactSystemFunctions.convertToTypeByName(this.props.screenInputs.LeadId ?? this.props.screenInputs.leadid, "Guid"),
			LeadId_2: ReactSystemFunctions.convertToTypeByName(this.props.screenInputs.LeadId ?? this.props.screenInputs.leadid, "Guid")
        }

	KuikaAppManager.showSpinner(this);
	
        if (true) {
        KuikaAppManager.showSpinner(this);
        }
        let result = await KuikaAppManager.ApiRequest(this, "reservationPopup1/reservationPopup1PageInit", localVar)
        if (!KMainFunctions.IsResStatus2XX(result)) return true;

		stateVars.TMGetProductDetailStockByLeadId = result?.data.tmGetProductDetailStockByLeadId;
		formVars.reservationpopup1_88501_value = ReactSystemFunctions.toString(this, (stateVars.TMGetProductDetailStockByLeadId !== undefined ? (stateVars.TMGetProductDetailStockByLeadId?.length > 0 ? stateVars.TMGetProductDetailStockByLeadId[0].toplamStok : null) : (this.state.TMGetProductDetailStockByLeadId?.length > 0 ? this.state.TMGetProductDetailStockByLeadId[0].toplamStok : null)));
		formVars.reservationpopup1_809773_value = ReactSystemFunctions.toString(this, (stateVars.TMGetProductDetailStockByLeadId !== undefined ? (stateVars.TMGetProductDetailStockByLeadId?.length > 0 ? stateVars.TMGetProductDetailStockByLeadId[0].rezerveStok : null) : (this.state.TMGetProductDetailStockByLeadId?.length > 0 ? this.state.TMGetProductDetailStockByLeadId[0].rezerveStok : null)));
		formVars.reservationpopup1_789978_value = ReactSystemFunctions.toString(this, (stateVars.TMGetProductDetailStockByLeadId !== undefined ? (stateVars.TMGetProductDetailStockByLeadId?.length > 0 ? stateVars.TMGetProductDetailStockByLeadId[0].musaitStok : null) : (this.state.TMGetProductDetailStockByLeadId?.length > 0 ? this.state.TMGetProductDetailStockByLeadId[0].musaitStok : null)));
		stateVars.isComp589964Visible = ((ReactSystemFunctions.isGreaterThan(ReactSystemFunctions.value(this, (stateVars.TMGetProductDetailStockByLeadId !== undefined ? (stateVars.TMGetProductDetailStockByLeadId?.length > 0 ? stateVars.TMGetProductDetailStockByLeadId[0].musaitStok : null) : (this.state.TMGetProductDetailStockByLeadId?.length > 0 ? this.state.TMGetProductDetailStockByLeadId[0].musaitStok : null))), ReactSystemFunctions.convertToTypeByName("0", "string"))) === true ? "visible" : "hidden")
		stateVars.isComp903102Visible = ((ReactSystemFunctions.isLessThan(ReactSystemFunctions.value(this, (stateVars.TMGetProductDetailStockByLeadId !== undefined ? (stateVars.TMGetProductDetailStockByLeadId?.length > 0 ? stateVars.TMGetProductDetailStockByLeadId[0].musaitStok : null) : (this.state.TMGetProductDetailStockByLeadId?.length > 0 ? this.state.TMGetProductDetailStockByLeadId[0].musaitStok : null))), ReactSystemFunctions.convertToTypeByName("1", "string"))) === true ? "visible" : "hidden")
		stateVars.TM_GetLeadById = result?.data.tM_GetLeadById;
		formVars.reservationpopup1_409619_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadById !== undefined ? (stateVars.TM_GetLeadById?.length > 0 ? stateVars.TM_GetLeadById[0].urunAdi : null) : (this.state.TM_GetLeadById?.length > 0 ? this.state.TM_GetLeadById[0].urunAdi : null)));
		formVars.reservationpopup1_110564_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadById !== undefined ? (stateVars.TM_GetLeadById?.length > 0 ? stateVars.TM_GetLeadById[0].magaza : null) : (this.state.TM_GetLeadById?.length > 0 ? this.state.TM_GetLeadById[0].magaza : null)));
		formVars.reservationpopup1_466407_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadById !== undefined ? (stateVars.TM_GetLeadById?.length > 0 ? stateVars.TM_GetLeadById[0].categoryName : null) : (this.state.TM_GetLeadById?.length > 0 ? this.state.TM_GetLeadById[0].categoryName : null)));
		formVars.reservationpopup1_813064_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadById !== undefined ? (stateVars.TM_GetLeadById?.length > 0 ? stateVars.TM_GetLeadById[0].musteriAdi : null) : (this.state.TM_GetLeadById?.length > 0 ? this.state.TM_GetLeadById[0].musteriAdi : null)));
		formVars.reservationpopup1_47209_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadById !== undefined ? (stateVars.TM_GetLeadById?.length > 0 ? stateVars.TM_GetLeadById[0].talepOlusturmaTarihi : null) : (this.state.TM_GetLeadById?.length > 0 ? this.state.TM_GetLeadById[0].talepOlusturmaTarihi : null)));
		formVars.reservationpopup1_914728_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadById !== undefined ? (stateVars.TM_GetLeadById?.length > 0 ? stateVars.TM_GetLeadById[0].leadCode : null) : (this.state.TM_GetLeadById?.length > 0 ? this.state.TM_GetLeadById[0].leadCode : null)));
		formVars.reservationpopup1_927577_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadById !== undefined ? (stateVars.TM_GetLeadById?.length > 0 ? stateVars.TM_GetLeadById[0].terminTarihi : null) : (this.state.TM_GetLeadById?.length > 0 ? this.state.TM_GetLeadById[0].terminTarihi : null)));
		formVars.reservationpopup1_640289_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadById !== undefined ? (stateVars.TM_GetLeadById?.length > 0 ? stateVars.TM_GetLeadById[0].satisPersoneli : null) : (this.state.TM_GetLeadById?.length > 0 ? this.state.TM_GetLeadById[0].satisPersoneli : null)));
		stateVars.TM_CheckLeadPriorityNew = result?.data.tM_CheckLeadPriorityNew;
		this.props.form?.setFieldsValue(formVars);
		
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.reservationPopup1PageInit1_();
                  resolve();
                });
          })



        
        KuikaAppManager.hideSpinner(this);
        return isErrorOccurred;
    }
	reservationPopup1PageInit1_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


	if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }

			formVars.reservationpopup1_409619_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadById !== undefined ? (stateVars.TM_GetLeadById?.length > 0 ? stateVars.TM_GetLeadById[0].urunAdi : null) : (this.state.TM_GetLeadById?.length > 0 ? this.state.TM_GetLeadById[0].urunAdi : null)));

			formVars.reservationpopup1_110564_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadById !== undefined ? (stateVars.TM_GetLeadById?.length > 0 ? stateVars.TM_GetLeadById[0].magaza : null) : (this.state.TM_GetLeadById?.length > 0 ? this.state.TM_GetLeadById[0].magaza : null)));

			formVars.reservationpopup1_466407_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadById !== undefined ? (stateVars.TM_GetLeadById?.length > 0 ? stateVars.TM_GetLeadById[0].categoryName : null) : (this.state.TM_GetLeadById?.length > 0 ? this.state.TM_GetLeadById[0].categoryName : null)));

			stateVars.isComp589964Visible = ((ReactSystemFunctions.isGreaterThan(ReactSystemFunctions.value(this, (stateVars.TMGetProductDetailStockByLeadId !== undefined ? (stateVars.TMGetProductDetailStockByLeadId?.length > 0 ? stateVars.TMGetProductDetailStockByLeadId[0].musaitStok : null) : (this.state.TMGetProductDetailStockByLeadId?.length > 0 ? this.state.TMGetProductDetailStockByLeadId[0].musaitStok : null))), ReactSystemFunctions.convertToTypeByName("0", "string"))) === true ? "visible" : "hidden")
			stateVars.isComp903102Visible = ((ReactSystemFunctions.isLessThan(ReactSystemFunctions.value(this, (stateVars.TMGetProductDetailStockByLeadId !== undefined ? (stateVars.TMGetProductDetailStockByLeadId?.length > 0 ? stateVars.TMGetProductDetailStockByLeadId[0].musaitStok : null) : (this.state.TMGetProductDetailStockByLeadId?.length > 0 ? this.state.TMGetProductDetailStockByLeadId[0].musaitStok : null))), ReactSystemFunctions.convertToTypeByName("1", "string"))) === true ? "visible" : "hidden")
			formVars.reservationpopup1_88501_value = ReactSystemFunctions.toString(this, (stateVars.TMGetProductDetailStockByLeadId !== undefined ? (stateVars.TMGetProductDetailStockByLeadId?.length > 0 ? stateVars.TMGetProductDetailStockByLeadId[0].toplamStok : null) : (this.state.TMGetProductDetailStockByLeadId?.length > 0 ? this.state.TMGetProductDetailStockByLeadId[0].toplamStok : null)));

			formVars.reservationpopup1_809773_value = ReactSystemFunctions.toString(this, (stateVars.TMGetProductDetailStockByLeadId !== undefined ? (stateVars.TMGetProductDetailStockByLeadId?.length > 0 ? stateVars.TMGetProductDetailStockByLeadId[0].rezerveStok : null) : (this.state.TMGetProductDetailStockByLeadId?.length > 0 ? this.state.TMGetProductDetailStockByLeadId[0].rezerveStok : null)));

			formVars.reservationpopup1_789978_value = ReactSystemFunctions.toString(this, (stateVars.TMGetProductDetailStockByLeadId !== undefined ? (stateVars.TMGetProductDetailStockByLeadId?.length > 0 ? stateVars.TMGetProductDetailStockByLeadId[0].musaitStok : null) : (this.state.TMGetProductDetailStockByLeadId?.length > 0 ? this.state.TMGetProductDetailStockByLeadId[0].musaitStok : null)));

			formVars.reservationpopup1_813064_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadById !== undefined ? (stateVars.TM_GetLeadById?.length > 0 ? stateVars.TM_GetLeadById[0].musteriAdi : null) : (this.state.TM_GetLeadById?.length > 0 ? this.state.TM_GetLeadById[0].musteriAdi : null)));

			formVars.reservationpopup1_47209_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadById !== undefined ? (stateVars.TM_GetLeadById?.length > 0 ? stateVars.TM_GetLeadById[0].talepOlusturmaTarihi : null) : (this.state.TM_GetLeadById?.length > 0 ? this.state.TM_GetLeadById[0].talepOlusturmaTarihi : null)));

			formVars.reservationpopup1_914728_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadById !== undefined ? (stateVars.TM_GetLeadById?.length > 0 ? stateVars.TM_GetLeadById[0].leadCode : null) : (this.state.TM_GetLeadById?.length > 0 ? this.state.TM_GetLeadById[0].leadCode : null)));

			formVars.reservationpopup1_927577_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadById !== undefined ? (stateVars.TM_GetLeadById?.length > 0 ? stateVars.TM_GetLeadById[0].terminTarihi : null) : (this.state.TM_GetLeadById?.length > 0 ? this.state.TM_GetLeadById[0].terminTarihi : null)));

			formVars.reservationpopup1_640289_value = ReactSystemFunctions.toString(this, (stateVars.TM_GetLeadById !== undefined ? (stateVars.TM_GetLeadById?.length > 0 ? stateVars.TM_GetLeadById[0].satisPersoneli : null) : (this.state.TM_GetLeadById?.length > 0 ? this.state.TM_GetLeadById[0].satisPersoneli : null)));


	this.props.form?.setFieldsValue(formVars);
	this.setState(stateVars);
	KuikaAppManager.hideSpinner(this);

            this.setPageInitLoaded(true);
            return isErrorOccurred;
        }




		reservationPopup1Component_611306_onClick = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
KuikaAppManager.showSpinner(this);

				stateVars.GoBack = await ReactSystemFunctions.goBack(this, false);

		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

            
            return isErrorOccurred;
        }


    reservationPopup1Component_815956_onClick = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
		KuikaAppManager.increaseServerRequestCount();

        let localVar = {
				LeadId_0: ReactSystemFunctions.convertToTypeByName(this.props.screenInputs.LeadId ?? this.props.screenInputs.leadid, "Guid"),
				UserId_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.getMyUserId(), "Guid"),
				Note_0: ReactSystemFunctions.convertToTypeByName(ReactSystemFunctions.value(this, ReactSystemFunctions.value(this, "reservationpopup1_635648_value", "value", "", "", "")), "string")
        }

		KuikaAppManager.showSpinner(this);

            stateVars.Confirm = await ReactSystemFunctions.confirmation(
                ReactSystemFunctions.translateCustomActions(this.ml,"6a40fb83_131d_0766_c0c2_b0e335a2685f_confirmation",this.defaultML,"Rezerve talebi göndermek istediğinize emin misiniz?" ),
                "calibri",
                "Rezerve Talebi Gönder",
                "confirmation",
                "#246dff",
                "",
                ""
            );

            if (stateVars.Confirm)
            {
                		
        if (true) {
        KuikaAppManager.showSpinner(this);
        }
        let result = await KuikaAppManager.ApiRequest(this, "reservationPopup1/reservationPopup1Component_815956_onClick", localVar)
        if (!KMainFunctions.IsResStatus2XX(result)) return true;

			stateVars.TM_ReserveLead = result?.data.tM_ReserveLead;
			this.props.form?.setFieldsValue(formVars);
			
        await new Promise((resolve, reject) => {
          this.setState(stateVars, async () => {
                  isErrorOccurred = await this.reservationPopup1Component_815956_onClick1_();
                  resolve();
                });
          })

            }
            else
            {
                KuikaAppManager.hideSpinner(this);
            }


        
        KuikaAppManager.hideSpinner(this);
        return isErrorOccurred;
    }
		reservationPopup1Component_815956_onClick1_ = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }

				stateVars.Notify = await ReactSystemFunctions.notify(this, ReactSystemFunctions.toString(this, (stateVars.TM_ReserveLead !== undefined ? (stateVars.TM_ReserveLead?.length > 0 ? stateVars.TM_ReserveLead[0].message : null) : (this.state.TM_ReserveLead?.length > 0 ? this.state.TM_ReserveLead[0].message : null))), ReactSystemFunctions.convertToTypeByName("default", "string"), ReactSystemFunctions.convertToTypeByName("top-center", "string"), 2, ReactSystemFunctions.convertToTypeByName("", "string"), ReactSystemFunctions.convertToTypeByName("", "string"), 0);
				stateVars.GoBack = await ReactSystemFunctions.goBack(this, false);

		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

            
            return isErrorOccurred;
        }




		reservationPopup1Component_636855_onClick = async () => {
        let stateVars = {} as any;
        let formVars = {} as any;
        let validations = [] as IValidationData[];
        let isErrorOccurred = false;


		if (KuikaAppManager.handleValidations(this, validations))
{
                const invalidValidation = validations.find((v) => !v.isValid && v.condition);
                if (invalidValidation) {
                    const formName = invalidValidation?.formName;
                    const fieldId = formName?.match(/\d+/)?.[0];
                    if (!formName || !fieldId) return;

                    const applyError = () =>
                      this.props.form?.setFields([
                        {
                          name: formName,
                          errors: [invalidValidation.message],
                          touched: true,
                        },
                      ]);

                    applyError();

                }
                return true;
            }
KuikaAppManager.showSpinner(this);

				stateVars.GoBack = await ReactSystemFunctions.goBack(this, false);

		this.props.form?.setFieldsValue(formVars);
		this.setState(stateVars);
		KuikaAppManager.hideSpinner(this);

            
            return isErrorOccurred;
        }




    async callCallbackFunction(diId: number, isFromMaster: boolean = false) {
        let isErrorOccurred = false;
		let pageInitCallerNavDiIDs = [] as number[];
		if (isFromMaster || pageInitCallerNavDiIDs.indexOf(diId) > -1) {
			await this.reservationPopup1PageInit();
		}

    }


}
