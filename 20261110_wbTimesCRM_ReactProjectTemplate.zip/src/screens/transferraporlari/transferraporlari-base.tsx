import React from "react";
import Axios, { AxiosResponse } from "axios";
import { KuikaAppManager } from "../../shared/utilty/kuika-app-manager";
import { ReactSystemFunctions } from "../../shared/utilty/react-system-functions";
import { KNavigator } from "../../shared/hoc/with-history";
import { KContext } from "../../shared/hoc/with-context";
import { useLocation } from "react-router-dom";
import { FormInstance } from "antd/es/form";
import { Guid } from "guid-typescript";
import Swal from "sweetalert2";
import { KMainFunctions } from "../../shared/utilty/main-functions";
import moment from "moment";
import { IValidationData } from "../../models/dto/validation-data";
import { IStripePayment } from "../../models/dto/stripe-payment";
import { IUserInfoDto } from "../../models/dto/user-info.dto";
import { UserService } from "../../services/user-service";
import { kuikaCoreWasmBridgeService } from "../../services/_singletons";
import _ from "lodash";
import mqtt, { MqttClient } from "mqtt";
import { IMqttResult } from "../../models/dto/mqtt.dto";


declare let window: any;

export interface ITransferRaporlari_ScreenProps {
  navigator: KNavigator;
  form: FormInstance<any>;
  googleLogin: any;
  screenInputs: any;
  context: KContext;
  initialValues: any;
  children: any;
}

export interface ITransferRaporlari_ScreenState {
    isSpinnerVisible: boolean;
    isPageVisible: boolean;
	isLeftMenuVisible: boolean;
    spinnerCount: number;
    selectedLanguage: string;
    isPageInitLoaded: false;
    isPageRecurringLoaded: false;

}

export class TransferRaporlari_ScreenBase extends React.PureComponent<ITransferRaporlari_ScreenProps, any> {

	transferraporlari_975397_value_kuikaSelectBoxRef: React.RefObject<any>;
	transferraporlari_413567_value_kuikaAutoCompleteRef: React.RefObject<any>;
	transferraporlari_539109_value_kuikaAutoCompleteRef: React.RefObject<any>;
	transferraporlari_956621_value_kuikaSelectBoxRef: React.RefObject<any>;
	transferraporlari_609391_value_kuikaSelectBoxRef: React.RefObject<any>;
	transferraporlari_228182_value_kuikaAutoCompleteRef: React.RefObject<any>;
	transferraporlari_272663_value_kuikaAutoCompleteRef: React.RefObject<any>;
	transferraporlari_238318_value_kuikaTableRef: React.RefObject<any>;
    ml=[{"Id":"d5a61d2b-bd60-485f-86e2-661e9ed4e486","Name":"en_US","ShortName":"English","IsDefault":true,"LanguagePhrases":[]},{"Id":"0b4f8c89-db9e-4aac-ba4e-e2718caceb7b","Name":"FixedValues","ShortName":"FixedValues","LanguagePhrases":[{"Id":130220,"PropertyName":"value","Value":"Transfer Raporları"},{"Id":95389,"PropertyName":"value","Value":"Transfer süreçlerini ayrıntılı olarak analiz edin ve dışa aktarın."},{"Id":81000,"PropertyName":"label","Value":"Excel'e Aktar"},{"Id":996089,"PropertyName":"label","Value":"PDF Oluştur"},{"Id":60644,"PropertyName":"value","Value":"Rapor Filtreleri"},{"Id":424629,"PropertyName":"value","Value":"Rapor Türü"},{"Id":975397,"PropertyName":"placeholder","Value":"Talep Raporu"},{"Id":164028,"PropertyName":"value","Value":"Tarih Aralığı"},{"Id":378887,"PropertyName":"placeholder","Value":"Son 30 Gün"},{"Id":601442,"PropertyName":"value","Value":"Gönderen Mağaza"},{"Id":413567,"PropertyName":"placeholder","Value":"Tümü"},{"Id":42416,"PropertyName":"value","Value":"Alıcı Mağaza"},{"Id":539109,"PropertyName":"placeholder","Value":"Tümü"},{"Id":109760,"PropertyName":"value","Value":"Talep Türü"},{"Id":956621,"PropertyName":"placeholder","Value":"Tümü"},{"Id":771534,"PropertyName":"value","Value":"Durum"},{"Id":609391,"PropertyName":"placeholder","Value":"Tümü"},{"Id":642888,"PropertyName":"value","Value":"Marka"},{"Id":228182,"PropertyName":"placeholder","Value":"Tümü"},{"Id":74108,"PropertyName":"value","Value":"Kategori"},{"Id":272663,"PropertyName":"placeholder","Value":"Tümü"},{"Id":909785,"PropertyName":"value","Value":"Ürün Kodu veya Adı"},{"Id":329977,"PropertyName":"placeholder","Value":"Ürün kodu veya adı yazın"},{"Id":768600,"PropertyName":"value","Value":"Gelişmiş Filtreler"},{"Id":582300,"PropertyName":"label","Value":"Raporu Getir"},{"Id":609541,"PropertyName":"label","Value":"Temizle"},{"Id":115023,"PropertyName":"value","Value":"Kayıt Sayısı"},{"Id":101751,"PropertyName":"value","Value":"126"},{"Id":350038,"PropertyName":"value","Value":"Toplam Talep Miktarı"},{"Id":210950,"PropertyName":"value","Value":"342"},{"Id":472332,"PropertyName":"value","Value":"Toplam Transfer Miktarı"},{"Id":921392,"PropertyName":"value","Value":"298"},{"Id":201875,"PropertyName":"value","Value":"Sorunlu Kayıt"},{"Id":88866,"PropertyName":"value","Value":"7"},{"Id":614621,"PropertyName":"value","Value":"Talep Raporu"},{"Id":238318,"PropertyName":"nodatafoundmessage","Value":"Kayıt bulunamadı"},{"Id":220141,"PropertyName":"title","Value":"Talep No"},{"Id":605155,"PropertyName":"value","Value":"label"},{"Id":305876,"PropertyName":"title","Value":"Talep Tarihi"},{"Id":947485,"PropertyName":"value","Value":"label"},{"Id":236713,"PropertyName":"title","Value":"Talep Türü"},{"Id":178442,"PropertyName":"value","Value":"label"},{"Id":444896,"PropertyName":"title","Value":"Talep Eden"},{"Id":581084,"PropertyName":"value","Value":"label"},{"Id":285794,"PropertyName":"title","Value":"Talep Edilen"},{"Id":55305,"PropertyName":"value","Value":"label"},{"Id":548816,"PropertyName":"title","Value":"Ürün"},{"Id":503058,"PropertyName":"value","Value":"label"},{"Id":535942,"PropertyName":"title","Value":"Talep Miktarı"},{"Id":801731,"PropertyName":"value","Value":"label"},{"Id":113821,"PropertyName":"title","Value":"Durum"},{"Id":193932,"PropertyName":"value","Value":"label"},{"Id":227736,"PropertyName":"title","Value":"Onay/Ret Tarihi"},{"Id":598330,"PropertyName":"value","Value":"label"},{"Id":188294,"PropertyName":"title","Value":"Karar Süresi"},{"Id":435566,"PropertyName":"value","Value":"label"},{"Id":231698,"PropertyName":"title","Value":"İşlemler"},{"Id":607101,"PropertyName":"label","Value":"Detay"},{"Id":896676,"PropertyName":"value","Value":"126 kayıttan 1–50 arası gösteriliyor"},{"Id":559895,"PropertyName":"value","Value":"Previous"},{"Id":382706,"PropertyName":"value","Value":"1"},{"Id":665424,"PropertyName":"value","Value":"2"},{"Id":598122,"PropertyName":"value","Value":"3"},{"Id":471274,"PropertyName":"value","Value":"Next"},{"Id":467655,"PropertyName":"value","Value":"50 / page"}]}]
    defaultML = "en_US"
    
    screenHash = ""
    


    constructor(props) {
        super(props);
		this.transferraporlari_975397_value_kuikaSelectBoxRef = React.createRef();
		this.transferraporlari_378887_value_kuikaTextInputRef = React.createRef();
		this.transferraporlari_413567_value_kuikaAutoCompleteRef = React.createRef();
		this.transferraporlari_539109_value_kuikaAutoCompleteRef = React.createRef();
		this.transferraporlari_956621_value_kuikaSelectBoxRef = React.createRef();
		this.transferraporlari_609391_value_kuikaSelectBoxRef = React.createRef();
		this.transferraporlari_228182_value_kuikaAutoCompleteRef = React.createRef();
		this.transferraporlari_272663_value_kuikaAutoCompleteRef = React.createRef();
		this.transferraporlari_329977_value_kuikaTextInputRef = React.createRef();
		this.transferraporlari_238318_value_kuikaTableRef = React.createRef();

        this.state = {
            isSpinnerVisible: false,
            isPageVisible: false,
            isLeftMenuVisible: false,
            spinnerCount: 0,
            selectedLanguage: "",
            isPageInitLoaded: false,
            isPageRecurringLoaded: false,
            	        dataSource_975397: [{"key":"request","text":"Talep Raporu"},{"key":"transfer","text":"Transfer Raporu"},{"key":"problem","text":"Sorunlu Kayıtlar"}],
	        dataSource_413567: [{"key":"adana","text":"Adana Times"},{"key":"mersin","text":"Mersin Times"},{"key":"antalya","text":"Antalya Times"},{"key":"gaziantep","text":"Gaziantep Times"},{"key":"merkez","text":"Merkez"}],
	        dataSource_539109: [{"key":"merkez","text":"Merkez"},{"key":"adana","text":"Adana Times"},{"key":"mersin","text":"Mersin Times"},{"key":"antalya","text":"Antalya Times"}],
	        dataSource_956621: [{"key":"store","text":"Mağaza Talebi"},{"key":"transfer","text":"Transfer"},{"key":"urgent","text":"Acil Talep"}],
	        dataSource_609391: [{"key":"pending","text":"Onay Bekliyor"},{"key":"transfer","text":"Transfer Bekliyor"},{"key":"rejected","text":"Reddedildi"},{"key":"done","text":"Transfer Edildi"}],
	        dataSource_228182: [{"key":"times","text":"TIMES"},{"key":"north","text":"Northline"},{"key":"urban","text":"Urban Form"}],
	        dataSource_272663: [{"key":"shirt","text":"Gömlek"},{"key":"pants","text":"Pantolon"},{"key":"accessory","text":"Aksesuar"},{"key":"jacket","text":"Ceket"}],

        }

        this.state.isPageVisible = true;
        
    }

    async componentDidMount() {

        if (KuikaAppManager.isPageInitPrevented()) {
            KuikaAppManager.calculateAndSetBodyHeight("transferraporlari", "");
            return;
        }
        
        
        ReactSystemFunctions.validateToken()
        this.fillFormInitValues();
        if (true){
            
        }
        
        
        
        KuikaAppManager.calculateAndSetBodyHeight("transferraporlari", "");

        if (ReactSystemFunctions.getIsMicroApp() === false) {
           window.parentScreen = this;
        }
    }

    componentWillUnmount() {
        
        
        

        if (ReactSystemFunctions.getIsMicroApp() === false) {
           window.parentScreen = null;
        }
    }

    

        
    componentDidUpdate= async (prevProps, prevState) => {
		KuikaAppManager.calculateAndSetBodyHeight("transferraporlari", ""    );
        if (prevProps?.location?.search !== (this.props as any)?.location?.search) {
			
		}

        

        if (ReactSystemFunctions.getIsMicroApp() === false) {
            for (const key in prevState) {
                if (key.startsWith('NavVisible') && prevState[key] === true && this.state[key] === false) {
                    window.parentScreen = this;
                    break;
                }
            }
        }
	}

    fillFormInitValues() {
        this.props.form?.setFieldsValue({
});

    }

      setPageInitLoaded = (value: boolean) => {
        this.setState({ isPageInitLoaded: value });
      }

      setPageRecurringLoaded = (value: boolean) => {
        this.setState({ isPageRecurringLoaded: value });
      }

      clearFieldValidation = (changedValues: any) => {
        const fieldName = Object.keys(changedValues)[0];
        if (fieldName) {
          this.props.form?.setFields([
            {
              name: fieldName,
              errors: []
            }
          ]);
        }
      };

      




    async callCallbackFunction(diId: number, isFromMaster: boolean = false) {
        let isErrorOccurred = false;

    }


}
