import "@testing-library/jest-dom";

// Mock ReactDOM Events to fix compatibility issues
const ReactDOM = require("react-dom");

// Ensure Events is available before any tests run
if (!ReactDOM.Events) {
  Object.defineProperty(ReactDOM, "Events", {
    value: {
      Event: class MockEvent {
        constructor(type: string, options?: any) {
          this.type = type;
          Object.assign(this, options);
        }

        type: string;

        target: any;

        currentTarget: any;

        preventDefault: () => {};

        stopPropagation: () => {};
      }
    },
    writable: true,
    configurable: true
  });
}

// Also mock the test-utils version
const ReactDOMTestUtils = require("react-dom/test-utils");

if (!ReactDOMTestUtils.Events) {
  Object.defineProperty(ReactDOMTestUtils, "Events", {
    value: ReactDOM.Events,
    writable: true,
    configurable: true
  });
}

// Mock React 18 createRoot to fix usingClientEntryPoint issue
const ReactDOMClient = require("react-dom/client");

if (ReactDOMClient.createRoot) {
  const originalCreateRoot = ReactDOMClient.createRoot;
  ReactDOMClient.createRoot = (container: any, options?: any) => {
    const root = originalCreateRoot(container, options);
    if (root && typeof root.render === "function") {
      return root;
    }
    return {
      render: (element: any) => {},
      unmount: () => {},
      _internalRoot: { current: null }
    };
  };
}

// Mock window.kuika for tests
Object.defineProperty(window, "kuika", {
  value: {
    dashboardState: "runtime",
    isDesignTime: false
  },
  writable: true,
  configurable: true
});

// Mock addEventListener for JSDOM compatibility
const mockAddEventListener = jest.fn();
const mockRemoveEventListener = jest.fn();

Object.defineProperty(document, "addEventListener", {
  value: mockAddEventListener,
  writable: true,
  configurable: true
});

Object.defineProperty(document, "removeEventListener", {
  value: mockRemoveEventListener,
  writable: true,
  configurable: true
});

Object.defineProperty(window, "addEventListener", {
  value: mockAddEventListener,
  writable: true,
  configurable: true
});

Object.defineProperty(window, "removeEventListener", {
  value: mockRemoveEventListener,
  writable: true,
  configurable: true
});

// Ensure window.document.addEventListener is also mocked
if (window.document) {
  Object.defineProperty(window.document, "addEventListener", {
    value: mockAddEventListener,
    writable: true,
    configurable: true
  });

  Object.defineProperty(window.document, "removeEventListener", {
    value: mockRemoveEventListener,
    writable: true,
    configurable: true
  });
}

// Mock HTMLFormElement.requestSubmit to fix JSDOM compatibility
if (typeof HTMLFormElement.prototype.requestSubmit === "undefined") {
  HTMLFormElement.prototype.requestSubmit = function (submitter?: HTMLElement) {
    const form = this;
    const event = new Event("submit", { bubbles: true, cancelable: true });

    // If a submitter is provided, set it as the submitter
    if (submitter) {
      Object.defineProperty(event, "submitter", {
        value: submitter,
        writable: false,
        configurable: true
      });
    }

    // Dispatch the submit event
    form.dispatchEvent(event);

    // If the event wasn't prevented, call the form's submit method
    if (!event.defaultPrevented) {
      form.submit();
    }
  };
}

// Mock matchMedia for react-slick and other components that use it
Object.defineProperty(window, "matchMedia", {
  value: jest.fn().mockImplementation((query) => ({
    matches: false,
    media: query,
    onchange: null,
    addListener: jest.fn(), // Deprecated
    removeListener: jest.fn(), // Deprecated
    addEventListener: jest.fn(),
    removeEventListener: jest.fn(),
    dispatchEvent: jest.fn()
  })),
  writable: true,
  configurable: true
});

// Mock URL.createObjectURL for worker-timers compatibility
Object.defineProperty(global.URL, "createObjectURL", {
  value: jest.fn(() => "mock-object-url"),
  writable: true,
  configurable: true
});

Object.defineProperty(global.URL, "revokeObjectURL", {
  value: jest.fn(),
  writable: true,
  configurable: true
});

// Mock Worker for worker-timers compatibility
Object.defineProperty(global, "Worker", {
  value: class MockWorker {
    constructor(stringUrl: string | URL, options?: WorkerOptions) {
      this.onmessage = null;
      this.onerror = null;
    }

    onmessage: ((this: Worker, ev: MessageEvent) => any) | null;

    onerror: ((this: AbstractWorker, ev: ErrorEvent) => any) | null;

    postMessage(message: any, transfer?: Transferable[]): void {}

    terminate(): void {}

    addEventListener(
      type: string,
      listener: EventListenerOrEventListenerObject,
      options?: boolean | AddEventListenerOptions
    ): void {}

    removeEventListener(
      type: string,
      listener: EventListenerOrEventListenerObject,
      options?: boolean | EventListenerOptions
    ): void {}

    dispatchEvent(event: Event): boolean {
      return true;
    }
  },
  writable: true,
  configurable: true
});

// Mock worker-timers to use native setTimeout in tests
jest.mock("worker-timers", () => ({
  setTimeout: (callback: Function, delay: number) => global.setTimeout(callback, delay),
  clearTimeout: (id: NodeJS.Timeout) => global.clearTimeout(id),
  setInterval: (callback: Function, delay: number) => global.setInterval(callback, delay),
  clearInterval: (id: NodeJS.Timeout) => global.clearInterval(id)
}));

// Suppress specific known React prop warnings that are expected in tests
// IMPORTANT: Only suppress specific, well-understood warnings - not all warnings
const originalError = console.error;

// Known warnings that are safe to suppress in tests
const SUPPRESSED_WARNINGS = [
  // React DOM prop warnings for custom component props passed through
  "React does not recognize the",
  // Deprecated ReactDOM.render in React 18
  "Warning: ReactDOM.render is no longer supported",
  // findDOMNode deprecation warning from third-party libraries
  "findDOMNode is deprecated",
  // JSDOM limitation
  "Error: Not implemented"
];

console.error = (...args: any[]) => {
  const message = args[0];
  if (typeof message === "string") {
    const shouldSuppress = SUPPRESSED_WARNINGS.some((warning) => message.includes(warning));
    if (shouldSuppress) {
      return;
    }
  }
  originalError.call(console, ...args);
};
