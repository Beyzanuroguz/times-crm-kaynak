import { Form } from "antd/es";
import type { FormInstance } from "antd/es/form";
import React from "react";
import { KMainFunctions } from "../shared/utilty/main-functions";

declare let window: any;

export interface IMasterFormContextValue {
  form: FormInstance | null;
  // KOA-18186: the form of the enclosing master chrome, published ONLY inside a child
  // scope mounted with linkParentScope (the screen a master renders in its body). Null
  // everywhere else. A child screen owns its own form scope (KOA-17999), so its
  // validation runs can never re-evaluate — and therefore never clear — an error the
  // master's form is still showing from an earlier run. handleValidations uses this
  // handle to clear the master's stale errors when a child validation run passes.
  parentForm: FormInstance | null;
}

export const MasterFormContext = React.createContext<IMasterFormContextValue>({ form: null, parentForm: null });

interface IFormScopeProps {
  children?: React.ReactNode;
  // KOA-18186: mark this scope as belonging to a screen rendered INSIDE master chrome,
  // exposing the enclosing scope's form as parentForm. Only the master wrapper's inner
  // (visible-child) scope sets it — InlineFormScope stays unlinked on purpose: a
  // master-less overlay child sits next to its host screen, not inside its chrome, and
  // must not clear the host's validation state.
  linkParentScope?: boolean;
}

// One antd Form instance per mount, published to the subtree through MasterFormContext.
// Everything that needs an isolated form scope mounts one of these: the master chrome,
// each child screen the master renders, and master-less overlay children. Unmounting a
// scope disposes its Form instance — that is what makes field values die together with
// the screen that owned them (antd <Form> defaults to preserve={true}, so values of
// unmounted fields survive for as long as their Form instance does).
const FormScope: React.FC<IFormScopeProps> = ({ children, linkParentScope }) => {
  const [form] = Form.useForm();
  const outer: IMasterFormContextValue = React.useContext(MasterFormContext);
  const parentForm: FormInstance | null = linkParentScope ? outer.form : null;
  const value: IMasterFormContextValue = React.useMemo(() => ({ form, parentForm }), [form, parentForm]);
  return <MasterFormContext.Provider value={value}>{children}</MasterFormContext.Provider>;
};

interface IMasterScreenWrapperLocationState {
  screenInputs?: Record<string, unknown>;
}

interface IMasterScreenWrapperLocation {
  search?: string;
  pathname?: string;
  state?: IMasterScreenWrapperLocationState;
}

// KOA-8559: "Open in Current Overlay" navigation. An inline-mounted master wrapper
// (drawer/modal/floatingPanel) publishes this handle through InlineOverlayNavContext,
// so ONLY the screens rendered inside that overlay's React subtree (its master menu
// and child screen) can reach it. A NAVIGATE action with openAs="currentOverlay" reads
// it from the triggering screen's props (injected by the withInlineOverlayNav HOC) and,
// when the overlay's master can render the target, swaps the overlay's visible child to
// it — keeping the overlay open and the master chrome/master form mounted — instead of
// routing the page behind the overlay. Triggers outside any overlay get the default
// (null) context, so they degrade to a normal currentPage navigate.
export interface IInlineOverlayNav {
  // True when `screenName` (the NAVIGATE `toScreen`, i.e. the target screen's Name) is
  // one of this overlay master's child screens, so this overlay can render it.
  canRender: (screenName: string) => boolean;
  // Push a screen to render inside the overlay (replaces the visible child; the master,
  // its provider and its form stay mounted — the child gets a fresh form scope).
  push: (screenName: string, screenInputs: Record<string, unknown>) => void;
}

// Default null: a screen rendered OUTSIDE any inline overlay (router-level, or the page
// behind a maskless FloatPanel) reads null and its currentOverlay navigate degrades to
// currentPage. Only the inline overlay wrapper provides a non-null value.
export const InlineOverlayNavContext = React.createContext<IInlineOverlayNav | null>(null);

interface IInlineOverlayEntry {
  screenName: string;
  screenInputs: Record<string, unknown>;
}

// KOA-17999: the child screen the master is currently showing, plus the identity key that
// scopes its form. See getVisibleChild().
interface IVisibleChild {
  content: React.ReactNode;
  scopeKey: string;
}

// KOA-17353: form-scope isolation for drawer / modal / floatingPanel child screens that
// have NO master assigned. Such children would otherwise inherit the app-level
// MasterFormContext (set up by the root MasterScreenWrapper), which means their
// <Form.Item> values bind to the shared root form. Antd's <Form> defaults to
// preserve={true}, so unmounting fields on close keeps their values in the shared form;
// the next open re-mounts the fields and rehydrates the stale values. Result: drawer
// looked clean visually but the form state never reset without a page reload.
//
// Wrapping the master-less child in InlineFormScope gives it its own form instance.
// destroyOnClose unmounts the scope along with the child, disposing the form. The next
// open creates a fresh scope and a fresh form.
//
// Children that DO have a master are already isolated by `*_InlineWrapper` (itself a
// MasterScreenWrapper subclass that scopes its visible child), so they don't need this
// wrapper. Emitted by ResolveInlineMasterTag in React_UIGenerator.
export const InlineFormScope: React.FC<IFormScopeProps> = FormScope;

interface IMasterScreenWrapperProps {
  children?: React.ReactNode;
  // KOA-17357: react-router-dom injects `location` into the routed `*_Wrapper` subclass when
  // it is mounted via `<Route component={...} />`. We forward it to the Master component so
  // its outer `withScreenInput` HOC can parse query/state into `props.screenInputs`. Without
  // this, screen inputs declared on the master page were always `{}` because `withScreenInput`
  // sits OUTSIDE `withHistory` in the master's HOC chain and runs before the `useLocation`
  // hook injects a location prop. Used by the currentPage / newTab / newWindow openAs paths.
  // Absent for inline-mounted (drawer/modal/floatingPanel) wrappers — they have no Route.
  location?: IMasterScreenWrapperLocation;
  // KOA-17357: for drawer/modal/floatingPanel (and any other non-currentPage / non-newTab /
  // non-newWindow openAs) the generated parent screen passes `window.kuika.navigationScreenInputs`
  // to the `*_InlineWrapper` so the master's `withScreenInput` HOC can populate via the
  // `props.screenInputs` source (the same channel the child screen uses). Undefined for
  // route-mounted wrappers; their screen inputs flow through `location` above.
  screenInputs?: Record<string, unknown>;
}

interface IMasterScreenWrapperState {
  privateRouteReady: boolean;
  // KOA-8559: stack of screens pushed into this overlay via openAs="currentOverlay".
  // Empty for the initial mount (renderSwitchWrapper / props.children is shown) and
  // for every router-level wrapper (which is never an overlay host). The top entry is
  // the screen currently rendered inside the overlay.
  overlayStack: IInlineOverlayEntry[];
}

export abstract class MasterScreenWrapper extends React.PureComponent<
  IMasterScreenWrapperProps,
  IMasterScreenWrapperState
> {
  private _handler: (() => void) | null = null;

  private _inlineOverlayNavValue: IInlineOverlayNav | null = null;

  constructor(props: IMasterScreenWrapperProps) {
    super(props);
    this.state = {
      privateRouteReady: window.userInfo !== undefined,
      overlayStack: []
    };
  }

  protected abstract get anonymousPaths(): string[];
  protected abstract get MasterComponent(): React.ComponentType<any>;
  protected abstract get MasterProvider(): React.ComponentType<any>;
  protected abstract renderSwitchWrapper(): React.ReactNode;

  // KOA-8559: lowercased Names of the screens this wrapper can render inside the
  // overlay via openAs="currentOverlay" (the master's child screens). Returns null for
  // router-level wrappers — null means "not an overlay host", so they don't publish the
  // nav context and their behavior is unchanged. Inline-mount subclasses
  // (drawer/modal/floatingPanel) override this with the generated list of their children.
  protected get overlayScreenNames(): string[] | null {
    return null;
  }

  // KOA-8559: render the screen `screenName` inside the overlay (wrapped by the same
  // master, since this runs inside the wrapper's master tree). Overridden by the
  // generated inline wrapper with a dispatcher over the master's child screens.
  // `onClose` pops the overlay stack back one level.
  protected renderOverlayScreen(
    _screenName: string,
    _screenInputs: Record<string, unknown>,
    _onClose: () => void
  ): React.ReactNode {
    return null;
  }

  private get isInlineOverlayHost(): boolean {
    return this.overlayScreenNames !== null;
  }

  // Stable, lazily-built context value so consumers (the master menu / child screens
  // inside the overlay) don't re-render on unrelated wrapper updates.
  private get inlineOverlayNavValue(): IInlineOverlayNav {
    if (!this._inlineOverlayNavValue) {
      this._inlineOverlayNavValue = {
        canRender: this.canRenderOverlayScreen,
        push: this.pushOverlayScreen
      };
    }
    return this._inlineOverlayNavValue;
  }

  // When true, render master immediately and skip the privateRouteReady auth gate.
  // The router-level wrapper leaves this false (default) so master chrome doesn't flash
  // before login resolves. Inline-mount subclasses (drawer/modal/floatingPanel) override
  // to true: by definition they only mount inside an already-routed (already-authed)
  // parent screen, so the auth gate is meaningless and can incorrectly suppress master
  // when window.userInfo isn't readable at construction time for any reason.
  protected get forceReady(): boolean {
    return false;
  }

  componentDidMount() {
    if (this.state.privateRouteReady) return;
    this._handler = () => this.setState({ privateRouteReady: true });
    window.addEventListener("privateRouteContextReady", this._handler);
  }

  componentWillUnmount() {
    if (this._handler) {
      window.removeEventListener("privateRouteContextReady", this._handler);
      this._handler = null;
    }
  }

  private canRenderOverlayScreen = (screenName: string): boolean => {
    const names: string[] | null = this.overlayScreenNames;
    if (!names || !screenName) return false;
    return names.includes(screenName.toLowerCase());
  };

  private pushOverlayScreen = (screenName: string, screenInputs: Record<string, unknown>): void => {
    this.setState((prev) => ({
      overlayStack: [...prev.overlayStack, { screenName, screenInputs }]
    }));
  };

  private popOverlayScreen = (): void => {
    this.setState((prev) => ({
      overlayStack: prev.overlayStack.slice(0, -1)
    }));
  };

  // KOA-8559: the content rendered inside the master. When a screen has been pushed via
  // openAs="currentOverlay", render that screen (top of the overlay stack); otherwise
  // render the normal switch/children. Router-level wrappers are never overlay hosts, so
  // this always returns renderSwitchWrapper() for them.
  //
  // KOA-17999: `scopeKey` identifies WHICH child screen is currently visible inside the
  // master, and is used as the React key of the child's FormScope. It must change on
  // every child swap so the outgoing screen's Form instance is destroyed with it.
  private getVisibleChild(): IVisibleChild {
    const stack: IInlineOverlayEntry[] = this.state.overlayStack;
    if (this.isInlineOverlayHost && stack.length > 0) {
      const top: IInlineOverlayEntry = stack[stack.length - 1];
      return {
        content: this.renderOverlayScreen(top.screenName, top.screenInputs, this.popOverlayScreen),
        scopeKey: `overlay:${stack.length}:${top.screenName.toLowerCase()}`
      };
    }
    // Router-level wrapper: the inner <Switch> picks the child by path, so the path IS the
    // child identity. `search` is deliberately excluded — re-navigating to the same screen
    // with different screen inputs does not remount the screen component either, so its
    // form must survive too (same behaviour a master-less screen has).
    return { content: this.renderSwitchWrapper(), scopeKey: `route:${this.props.location?.pathname ?? ""}` };
  }

  private isPathAnonymous(): boolean {
    const currentPath = window.location.hash
      ? window.location.hash.replace(/^#/, "").split("?")[0]
      : (() => {
          const virtualDir = KMainFunctions.virtualDirectoryURL === "auto" ? "" : KMainFunctions.virtualDirectoryURL;
          return window.location.pathname.replace(virtualDir, "").split("?")[0];
        })();
    return this.anonymousPaths.some((p) => currentPath?.toLowerCase() === p);
  }

  render() {
    const { privateRouteReady } = this.state;
    const visibleChild: IVisibleChild = this.getVisibleChild();

    if (!this.forceReady && !privateRouteReady && !this.isPathAnonymous()) {
      return visibleChild.content;
    }

    const Master = this.MasterComponent;
    const Provider = this.MasterProvider;

    // KOA-17999: two nested scopes, not one shared form.
    //
    // The outer scope belongs to the master chrome. It lives as long as the wrapper does,
    // so a search box or filter in the master header keeps its value while the user moves
    // between child screens — which is the point of a master.
    //
    // The inner scope belongs to whichever child screen is on screen right now, and is
    // keyed by that child's identity. The wrapper's Route matches EVERY path of the master
    // group, so the wrapper (and with it the outer form) stays mounted across in-group
    // navigation; only the inner <Switch> swaps the screen. Without the keyed inner scope
    // the child's fields would keep writing into the master's long-lived form, and antd's
    // preserve={true} default would rehydrate them on the way back — a master-screened
    // screen would come back filled while a master-less one comes back empty.
    //
    // Child <Form.Item>s follow this scope because every generated child screen renders
    // its own <Form form={this.props.form} component={false}> (KOA-17205), which re-provides
    // antd's FieldContext for its subtree. So the child's imperative props.form and its
    // rendered fields still resolve to one and the same instance — the invariant KOA-16475
    // introduced the shared form for.
    //
    // KOA-18186: the inner scope links back to the master scope (linkParentScope) so a
    // successful child validation run can clear errors the master chrome is still showing
    // from an earlier run. The link is one-directional — the master scope has no handle to
    // any child form, so master-triggered runs keep off child fields (KOA-17999 isolation).
    const masterTree = (
      <FormScope>
        <Provider>
          <Master location={this.props.location} screenInputs={this.props.screenInputs}>
            <FormScope key={visibleChild.scopeKey} linkParentScope>
              {visibleChild.content}
            </FormScope>
          </Master>
        </Provider>
      </FormScope>
    );

    // KOA-8559: only the inline overlay wrapper publishes the overlay-nav handle, and
    // only to its own React subtree (master menu + child screen). A currentOverlay
    // navigate triggered from the page behind — or a maskless FloatPanel background —
    // reads the default null context and degrades to a normal currentPage navigate.
    if (this.isInlineOverlayHost) {
      return (
        <InlineOverlayNavContext.Provider value={this.inlineOverlayNavValue}>
          {masterTree}
        </InlineOverlayNavContext.Provider>
      );
    }

    return masterTree;
  }
}
