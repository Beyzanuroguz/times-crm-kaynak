import React from "react";
import { BrowserRouter, HashRouter, Switch } from "react-router-dom";
import { MasterScreenTop_ScreenProvider } from "../screens/masterscreentop/masterscreentop-context";
import { MasterScreen_ScreenProvider } from "../screens/masterscreen/masterscreen-context";
import { ResetPassword_Screen } from "../screens/resetpassword/resetpassword";
import { ForgotPassword_Screen } from "../screens/forgotpassword/forgotpassword";
import { VerificationCode_Screen } from "../screens/verificationcode/verificationcode";
import { CustomerChangeLog_Screen } from "../screens/customerchangelog/customerchangelog";
import { ContactSourceEdit_Screen } from "../screens/contactsourceedit/contactsourceedit";
import { SparePartsBasedReports_Screen } from "../screens/sparepartsbasedreports/sparepartsbasedreports";
import { TechnicalServiceReports_Screen } from "../screens/technicalservicereports/technicalservicereports";
import { ProductLogs_Screen } from "../screens/productlogs/productlogs";
import { NextStepAdd_Screen } from "../screens/nextstepadd/nextstepadd";
import { NextStepEdit_Screen } from "../screens/nextstepedit/nextstepedit";
import { NextStepList_Screen } from "../screens/nextsteplist/nextsteplist";
import { RoleList_Screen } from "../screens/rolelist/rolelist";
import { UserProfile_Screen } from "../screens/userprofile/userprofile";
import { SettingPanel_Screen } from "../screens/settingpanel/settingpanel";
import { PolisajBasedReports_Screen } from "../screens/polisajbasedreports/polisajbasedreports";
import { MonthlyAllocationcopy_Screen } from "../screens/monthlyallocationcopy/monthlyallocationcopy";
import { LoomisReports_Screen } from "../screens/loomisreports/loomisreports";
import { PurchaseBasedReports_Screen } from "../screens/purchasebasedreports/purchasebasedreports";
import { ImportList_Screen } from "../screens/importlist/importlist";
import { LeadDetailAddNote_Screen } from "../screens/leaddetailaddnote/leaddetailaddnote";
import { ProductDetail_Screen } from "../screens/productdetail/productdetail";
import { ContactSourceList_Screen } from "../screens/contactsourcelist/contactsourcelist";
import { ContactSourceAdd_Screen } from "../screens/contactsourceadd/contactsourceadd";
import { RolexMaterialReporting_Screen } from "../screens/rolexmaterialreporting/rolexmaterialreporting";
import { TudorBasedReporting_Screen } from "../screens/tudorbasedreporting/tudorbasedreporting";
import { Signup_Screen } from "../screens/signup/signup";
import { RolexOtherProductReporting_Screen } from "../screens/rolexotherproductreporting/rolexotherproductreporting";
import { StockDistribution_Screen } from "../screens/stockdistribution/stockdistribution";
import { LeadAddByExcelcopy_Screen } from "../screens/leadaddbyexcelcopy/leadaddbyexcelcopy";
import { ExecutionPlanScreen_Screen } from "../screens/executionplanscreen/executionplanscreen";
import { LeadDetailSalesPerson_Screen } from "../screens/leaddetailsalesperson/leaddetailsalesperson";
import { LeadRejectPopUp_Screen } from "../screens/leadrejectpopup/leadrejectpopup";
import { LeadRejectCustomerPopUp_Screen } from "../screens/leadrejectcustomerpopup/leadrejectcustomerpopup";
import { TransferDashboard_Screen } from "../screens/transferdashboard/transferdashboard";
import { TransferIslemGunlugu_Screen } from "../screens/transferislemgunlugu/transferislemgunlugu";
import { DistributionDetail_Screen } from "../screens/distributiondetail/distributiondetail";
import { TransferBekleyenHavuzu_Screen } from "../screens/transferbekleyenhavuzu/transferbekleyenhavuzu";
import { UserRoles_Screen } from "../screens/userroles/userroles";
import { ImportLeadMersin_Screen } from "../screens/importleadmersin/importleadmersin";
import { EntegrasyonHata_Screen } from "../screens/entegrasyonhata/entegrasyonhata";
import { OrderList_Screen } from "../screens/orderlist/orderlist";
import { DistributionDetailStore_Screen } from "../screens/distributiondetailstore/distributiondetailstore";
import { UrunVeMagazaStokDetay_Screen } from "../screens/urunvemagazastokdetay/urunvemagazastokdetay";
import { CreateTransferReceipt_Screen } from "../screens/createtransferreceipt/createtransferreceipt";
import { ReservationReject_Screen } from "../screens/reservationreject/reservationreject";
import { ReservationPopUp_Screen } from "../screens/reservationpopup/reservationpopup";
import { UserManagementcopy_Screen } from "../screens/usermanagementcopy/usermanagementcopy";
import { MasterScreenTop_Screen } from "../screens/masterscreentop/masterscreentop";
import { InComingTransferDetail_Screen } from "../screens/incomingtransferdetail/incomingtransferdetail";
import { LeadAddByExcelAI_Screen } from "../screens/leadaddbyexcelai/leadaddbyexcelai";
import { ReservationEdit_Screen } from "../screens/reservationedit/reservationedit";
import { StockListManager_Screen } from "../screens/stocklistmanager/stocklistmanager";
import { RolexBasedReporting_Screen } from "../screens/rolexbasedreporting/rolexbasedreporting";
import { ImportLeadAdana_Screen } from "../screens/importleadadana/importleadadana";
import { TransferRaporlari_Screen } from "../screens/transferraporlari/transferraporlari";
import { ReservationManagement_Screen } from "../screens/reservationmanagement/reservationmanagement";
import { CustomerDetailInfo_Screen } from "../screens/customerdetailinfo/customerdetailinfo";
import { ReferanceCreateNew_Screen } from "../screens/referancecreatenew/referancecreatenew";
import { UserCreatecopy_Screen } from "../screens/usercreatecopy/usercreatecopy";
import { DupontBasedReporting_Screen } from "../screens/dupontbasedreporting/dupontbasedreporting";
import { StockListStoreBase_Screen } from "../screens/stockliststorebase/stockliststorebase";
import { ImportLeadGaziantep_Screen } from "../screens/importleadgaziantep/importleadgaziantep";
import { TransferFisiHazirlama_Screen } from "../screens/transferfisihazirlama/transferfisihazirlama";
import { RolexFamilyReporting_Screen } from "../screens/rolexfamilyreporting/rolexfamilyreporting";
import { LeadList_Screen } from "../screens/leadlist/leadlist";
import { LeadFileDetail_Screen } from "../screens/leadfiledetail/leadfiledetail";
import { DNM0100TransferFisKarti_Screen } from "../screens/dnm0100transferfiskarti/dnm0100transferfiskarti";
import { RoleManagement_Screen } from "../screens/rolemanagement/rolemanagement";
import { MontBlancBasedReporting_Screen } from "../screens/montblancbasedreporting/montblancbasedreporting";
import { AlternativeInfo_Screen } from "../screens/alternativeinfo/alternativeinfo";
import { UserEdit_Screen } from "../screens/useredit/useredit";
import { ImportLeadAntalyaRolex_Screen } from "../screens/importleadantalyarolex/importleadantalyarolex";
import { TudorFamilyReporting_Screen } from "../screens/tudorfamilyreporting/tudorfamilyreporting";
import { DNM0100DetailScreen_Screen } from "../screens/dnm0100detailscreen/dnm0100detailscreen";
import { ReferanceCreatePost_Screen } from "../screens/referancecreatepost/referancecreatepost";
import { StokVeUrunArama_Screen } from "../screens/stokveurunarama/stokveurunarama";
import { CustomerDetailPage_Screen } from "../screens/customerdetailpage/customerdetailpage";
import { AnnualPortfolioList_Screen } from "../screens/annualportfoliolist/annualportfoliolist";
import { Signin_Screen } from "../screens/signin/signin";
import { RolexDiameterReporting_Screen } from "../screens/rolexdiameterreporting/rolexdiameterreporting";
import { ProductDistribution_Screen } from "../screens/productdistribution/productdistribution";
import { PopOnayBekleyen_Screen } from "../screens/poponaybekleyen/poponaybekleyen";
import { LeadDetailTemp_Screen } from "../screens/leaddetailtemp/leaddetailtemp";
import { AllLeadPendingDetail_Screen } from "../screens/allleadpendingdetail/allleadpendingdetail";
import { TransferFisleri_Screen } from "../screens/transferfisleri/transferfisleri";
import { OnayaGonderdigimSatislar_Screen } from "../screens/onayagonderdigimsatislar/onayagonderdigimsatislar";
import { ProductList_Screen } from "../screens/productlist/productlist";
import { TransferTalepleri_Screen } from "../screens/transfertalepleri/transfertalepleri";
import { LeadSatisBasariliPop_Screen } from "../screens/leadsatisbasarilipop/leadsatisbasarilipop";
import { DashBoardTempManager_Screen } from "../screens/dashboardtempmanager/dashboardtempmanager";
import { BosekranYusuf_Screen } from "../screens/bosekranyusuf/bosekranyusuf";
import { ReportCashNebim_Screen } from "../screens/reportcashnebim/reportcashnebim";
import { TerminPendingLead_Screen } from "../screens/terminpendinglead/terminpendinglead";
import { LeadAdd_Screen } from "../screens/leadadd/leadadd";
import { TalepSatisIslemi_Screen } from "../screens/talepsatisislemi/talepsatisislemi";
import { LeadAddTemp_Screen } from "../screens/leadaddtemp/leadaddtemp";
import { SatisBasariliPop_Screen } from "../screens/satisbasarilipop/satisbasarilipop";
import { DashBoardTempTopManager_Screen } from "../screens/dashboardtemptopmanager/dashboardtemptopmanager";
import { ROLEAUTH_Screen } from "../screens/roleauth/roleauth";
import { CustomerUpdatePost_Screen } from "../screens/customerupdatepost/customerupdatepost";
import { UcuncuKisiFaturaOnayDetayi_Screen } from "../screens/ucuncukisifaturaonaydetayi/ucuncukisifaturaonaydetayi";
import { TransferBildirimGonderimIzleme_Screen } from "../screens/transferbildirimgonderimizleme/transferbildirimgonderimizleme";
import { NotificationManager_Screen } from "../screens/notificationmanager/notificationmanager";
import { LeadAlternativeModelAdd_Screen } from "../screens/leadalternativemodeladd/leadalternativemodeladd";
import { AnnualPortfolioCreationStep1copycopy_Screen } from "../screens/annualportfoliocreationstep1copycopy/annualportfoliocreationstep1copycopy";
import { ReportSalesNebim_Screen } from "../screens/reportsalesnebim/reportsalesnebim";
import { ApprovedLeadList_Screen } from "../screens/approvedleadlist/approvedleadlist";
import { TransferFisiDetayi_Screen } from "../screens/transferfisidetayi/transferfisidetayi";
import { Deneme2copy_Screen } from "../screens/deneme2copy/deneme2copy";
import { PopTerminOnerisiBekleyen_Screen } from "../screens/popterminonerisibekleyen/popterminonerisibekleyen";
import { ReservationPopup1_Screen } from "../screens/reservationpopup1/reservationpopup1";
import { Deneme001_Screen } from "../screens/deneme001/deneme001";
import { TaskManagementTopManager_Screen } from "../screens/taskmanagementtopmanager/taskmanagementtopmanager";
import { ApproveLead_Screen } from "../screens/approvelead/approvelead";
import { SalesWeb_Screen } from "../screens/salesweb/salesweb";
import { ReservationPopUp2_Screen } from "../screens/reservationpopup2/reservationpopup2";
import { TransferFisKabul_Screen } from "../screens/transferfiskabul/transferfiskabul";
import { MusteriOnayPop_Screen } from "../screens/musterionaypop/musterionaypop";
import { StockListDetail_Screen } from "../screens/stocklistdetail/stocklistdetail";
import { YearlyStockEntry_Screen } from "../screens/yearlystockentry/yearlystockentry";
import { CustomerList_Screen } from "../screens/customerlist/customerlist";
import { CustomerErpLog_Screen } from "../screens/customererplog/customererplog";
import { YearlyAllocationcopy_Screen } from "../screens/yearlyallocationcopy/yearlyallocationcopy";
import { TransferTalepDetay_Screen } from "../screens/transfertalepdetay/transfertalepdetay";
import { ReportInventoryNebim_Screen } from "../screens/reportinventorynebim/reportinventorynebim";
import { CustomerCreatePost_Screen } from "../screens/customercreatepost/customercreatepost";
import { DistributionPool_Screen } from "../screens/distributionpool/distributionpool";
import { AllLeadPending_Screen } from "../screens/allleadpending/allleadpending";
import { LeadUpdate_Screen } from "../screens/leadupdate/leadupdate";
import { PopRezervOnayBekleyenPopup_Screen } from "../screens/poprezervonaybekleyenpopup/poprezervonaybekleyenpopup";
import { LeftMenu_Screen } from "../screens/leftmenu/leftmenu";
import { Kubrabosekran_Screen } from "../screens/kubrabosekran/kubrabosekran";
import { SatisIslemi_Screen } from "../screens/satisislemi/satisislemi";
import { LeadDetail_Screen } from "../screens/leaddetail/leaddetail";
import { DashBoardTemp_Screen } from "../screens/dashboardtemp/dashboardtemp";
import { ImportListDetail_Screen } from "../screens/importlistdetail/importlistdetail";
import { TalepDuzenlemeEkrani_Screen } from "../screens/talepduzenlemeekrani/talepduzenlemeekrani";
import { LeadAddChangeProduct_Screen } from "../screens/leadaddchangeproduct/leadaddchangeproduct";
import { LeadProductChange_Screen } from "../screens/leadproductchange/leadproductchange";
import { LeadListTemp_Screen } from "../screens/leadlisttemp/leadlisttemp";
import { TaskManagementPerson_Screen } from "../screens/taskmanagementperson/taskmanagementperson";
import { TransferTalepOnay_Screen } from "../screens/transfertaleponay/transfertaleponay";
import { AllLeadPendingTerminDegis_Screen } from "../screens/allleadpendingtermindegis/allleadpendingtermindegis";
import { TaskManagementManager_Screen } from "../screens/taskmanagementmanager/taskmanagementmanager";
import { ReservationPopUp3_Screen } from "../screens/reservationpopup3/reservationpopup3";
import { StockListStore_Screen } from "../screens/stockliststore/stockliststore";
import { LeadReport_Screen } from "../screens/leadreport/leadreport";
import { BildirimPopup_Screen } from "../screens/bildirimpopup/bildirimpopup";
import { DiscountLimit_Screen } from "../screens/discountlimit/discountlimit";
import { AddDiscountLimit_Screen } from "../screens/adddiscountlimit/adddiscountlimit";
import { MasterScreen_Screen } from "../screens/masterscreen/masterscreen";
import { FreeSalesWeb_Screen } from "../screens/freesalesweb/freesalesweb";
import { Deneme001Workspace_Screen } from "../screens/deneme001workspace/deneme001workspace";
import { BildirimlerBekleyenIsler_Screen } from "../screens/bildirimlerbekleyenisler/bildirimlerbekleyenisler";
import { TalebeAlternatifUrunEkle_Screen } from "../screens/talebealternatifurunekle/talebealternatifurunekle";
import { AllCustomerChangeLog_Screen } from "../screens/allcustomerchangelog/allcustomerchangelog";
import { TransferTalebiOlusturStok_Screen } from "../screens/transfertalebiolusturstok/transfertalebiolusturstok";
import { UcuncuKisiFaturaOnaylari_Screen } from "../screens/ucuncukisifaturaonaylari/ucuncukisifaturaonaylari";
import { TransferTalebiOlusturV2_Screen } from "../screens/transfertalebiolusturv2/transfertalebiolusturv2";



import LocalStorageService from "../auth/local-storage-service";
import { Redirect } from "../auth/redirect";
import { IAppMode, IAuthType } from "../bootstrapper";
import { NoMatch404 } from "../components/common/no-match-404";
import { Dashboard, ForgotPassword, Login, ResetPassword } from "../components/default_screens/index";
import { KuikaInfo } from "../components/default_screens/kuika-info";
import { MfeLogin } from "../components/mfe/mfe-login";
import { MsalLogin } from "../components/msal/msal-login";
import { MsalRedirect } from "../components/msal/msal-redirect";
import { NotificationRedirect } from "../components/notification/notification-redirect";
import { ScanCompareTest } from "../screens/scan-compare-test";
import { WFMailInteraction } from "../screens/wf-mail-interaction";
import confJson from "../shared/json/conf.json";
import { KMainFunctions } from "../shared/utilty/main-functions";
import { MasterScreenWrapper } from "./master-screen-wrapper";
import { PrivateRoute } from "./private-route";
import { Route } from "./route";

class MasterScreen_Screen_Wrapper extends MasterScreenWrapper {
  protected get anonymousPaths(): string[] { return []; }
  protected get MasterComponent(): React.ComponentType<any> { return MasterScreen_Screen; }
  protected get MasterProvider(): React.ComponentType<any> { return MasterScreen_ScreenProvider; }
  protected renderSwitchWrapper(): React.ReactNode {
    return (
      <Switch>
        <PrivateRoute exact path="/sparepartsbasedreports" component={SparePartsBasedReports_Screen} />
        <PrivateRoute exact path="/technicalservicereports" component={TechnicalServiceReports_Screen} />
        <PrivateRoute exact path="/nextsteplist" component={NextStepList_Screen} />
        <PrivateRoute exact path="/rolelist" component={RoleList_Screen} />
        <PrivateRoute exact path="/userprofile" component={UserProfile_Screen} />
        <PrivateRoute exact path="/polisajbasedreports" component={PolisajBasedReports_Screen} />
        <PrivateRoute exact path="/monthlyallocationcopy" component={MonthlyAllocationcopy_Screen} />
        <PrivateRoute exact path="/loomisreports" component={LoomisReports_Screen} />
        <PrivateRoute exact path="/purchasebasedreports" component={PurchaseBasedReports_Screen} />
        <PrivateRoute exact path="/importlist" component={ImportList_Screen} />
        <PrivateRoute exact path="/productdetail" component={ProductDetail_Screen} />
        <PrivateRoute exact path="/contactsourcelist" component={ContactSourceList_Screen} />
        <PrivateRoute exact path="/rolexmaterialreporting" component={RolexMaterialReporting_Screen} />
        <PrivateRoute exact path="/tudorbasedreporting" component={TudorBasedReporting_Screen} />
        <PrivateRoute exact path="/rolexotherproductreporting" component={RolexOtherProductReporting_Screen} />
        <PrivateRoute exact path="/stockdistribution" component={StockDistribution_Screen} />
        <PrivateRoute exact path="/leadaddbyexcelcopy" component={LeadAddByExcelcopy_Screen} />
        <PrivateRoute exact path="/distributiondetail" component={DistributionDetail_Screen} />
        <PrivateRoute exact path="/transferbekleyenhavuzu" component={TransferBekleyenHavuzu_Screen} />
        <PrivateRoute exact path="/orderlist" component={OrderList_Screen} />
        <PrivateRoute exact path="/distributiondetailstore" component={DistributionDetailStore_Screen} />
        <PrivateRoute exact path="/createtransferreceipt" component={CreateTransferReceipt_Screen} />
        <PrivateRoute exact path="/usermanagementcopy" component={UserManagementcopy_Screen} />
        <PrivateRoute exact path="/incomingtransferdetail" component={InComingTransferDetail_Screen} />
        <PrivateRoute exact path="/leadaddbyexcelai" component={LeadAddByExcelAI_Screen} />
        <PrivateRoute exact path="/stocklistmanager" component={StockListManager_Screen} />
        <PrivateRoute exact path="/rolexbasedreporting" component={RolexBasedReporting_Screen} />
        <PrivateRoute exact path="/reservationmanagement" component={ReservationManagement_Screen} />
        <PrivateRoute exact path="/dupontbasedreporting" component={DupontBasedReporting_Screen} />
        <PrivateRoute exact path="/stockliststorebase" component={StockListStoreBase_Screen} />
        <PrivateRoute exact path="/rolexfamilyreporting" component={RolexFamilyReporting_Screen} />
        <PrivateRoute exact path="/leadlist" component={LeadList_Screen} />
        <PrivateRoute exact path="/montblancbasedreporting" component={MontBlancBasedReporting_Screen} />
        <PrivateRoute exact path="/tudorfamilyreporting" component={TudorFamilyReporting_Screen} />
        <PrivateRoute exact path="/stokveurunarama" component={StokVeUrunArama_Screen} />
        <PrivateRoute exact path="/annualportfoliolist" component={AnnualPortfolioList_Screen} />
        <PrivateRoute exact path="/rolexdiameterreporting" component={RolexDiameterReporting_Screen} />
        <PrivateRoute exact path="/productdistribution" component={ProductDistribution_Screen} />
        <PrivateRoute exact path="/onayagonderdigimsatislar" component={OnayaGonderdigimSatislar_Screen} />
        <PrivateRoute exact path="/productlist" component={ProductList_Screen} />
        <PrivateRoute exact path="/transfertalepleri" component={TransferTalepleri_Screen} />
        <PrivateRoute exact path="/dashboardtempmanager" component={DashBoardTempManager_Screen} />
        <PrivateRoute exact path="/reportcashnebim" component={ReportCashNebim_Screen} />
        <PrivateRoute exact path="/leadadd" component={LeadAdd_Screen} />
        <PrivateRoute exact path="/leadaddtemp" component={LeadAddTemp_Screen} />
        <PrivateRoute exact path="/satisbasarilipop" component={SatisBasariliPop_Screen} />
        <PrivateRoute exact path="/dashboardtemptopmanager" component={DashBoardTempTopManager_Screen} />
        <PrivateRoute exact path="/notificationmanager" component={NotificationManager_Screen} />
        <PrivateRoute exact path="/annualportfoliocreationstep1copycopy" component={AnnualPortfolioCreationStep1copycopy_Screen} />
        <PrivateRoute exact path="/reportsalesnebim" component={ReportSalesNebim_Screen} />
        <PrivateRoute exact path="/approvedleadlist" component={ApprovedLeadList_Screen} />
        <PrivateRoute exact path="/taskmanagementtopmanager" component={TaskManagementTopManager_Screen} />
        <PrivateRoute exact path="/stocklistdetail" component={StockListDetail_Screen} />
        <PrivateRoute exact path="/yearlystockentry" component={YearlyStockEntry_Screen} />
        <PrivateRoute exact path="/customerlist" component={CustomerList_Screen} />
        <PrivateRoute exact path="/yearlyallocationcopy" component={YearlyAllocationcopy_Screen} />
        <PrivateRoute exact path="/reportinventorynebim" component={ReportInventoryNebim_Screen} />
        <PrivateRoute exact path="/distributionpool" component={DistributionPool_Screen} />
        <PrivateRoute exact path="/allleadpending" component={AllLeadPending_Screen} />
        <PrivateRoute exact path="/satisislemi" component={SatisIslemi_Screen} />
        <PrivateRoute exact path="/dashboardtemp" component={DashBoardTemp_Screen} />
        <PrivateRoute exact path="/importlistdetail" component={ImportListDetail_Screen} />
        <PrivateRoute exact path="/leadlisttemp" component={LeadListTemp_Screen} />
        <PrivateRoute exact path="/taskmanagementperson" component={TaskManagementPerson_Screen} />
        <PrivateRoute exact path="/taskmanagementmanager" component={TaskManagementManager_Screen} />
        <PrivateRoute exact path="/stockliststore" component={StockListStore_Screen} />
        <PrivateRoute exact path="/leadreport" component={LeadReport_Screen} />
        <PrivateRoute exact path="/discountlimit" component={DiscountLimit_Screen} />
        <PrivateRoute exact path="/freesalesweb" component={FreeSalesWeb_Screen} />
        <PrivateRoute exact path="/ucuncukisifaturaonaylari" component={UcuncuKisiFaturaOnaylari_Screen} />
      </Switch>
    );
  }
}



export interface IRouterState {}

export type IRouterType = "HashRouter" | "BrowserRouter";

export interface IRouterProps {
  authType: IAuthType;
  routerType?: IRouterType;
  external_access_token?: string;
  external_refresh_token?: string;
  external_user?: string;
  external_provider_type?: string;
  startingScreen?: string;
  appMode?: IAppMode;
  // Allow only screenInput_* props with specific typing
  [key: `screenInput_${string}`]: unknown;
}

declare let window: any;

// Runs before any router exists. No history entry is added: an entry left behind without the
// hash would send the back button to "/", where PrivateRoute pushes the user forward again.
// The host page's history.state is kept, and the URL comes from location.href because a
// relative "#/x" would resolve against a <base href>. The queued event is what a hash
// assignment announces; HashRouter ignores it because its location already matches.
function replaceHashBeforeRouterMount(hash: string): void {
  if (window.location.hash === hash) {
    return;
  }
  const oldURL: string = window.location.href;
  try {
    const url: URL = new URL(oldURL);
    url.hash = hash;
    window.history.replaceState(window.history.state, "", url.href);
  } catch {
    // The assignment still lands before HashRouter reads the hash; it only adds an entry.
    window.location.hash = hash;
    return;
  }
  window.setTimeout((): void => {
    window.dispatchEvent(new HashChangeEvent("hashchange", { oldURL, newURL: window.location.href }));
  }, 0);
}

export class Router extends React.Component<IRouterProps, IRouterState> {
  timerId: any = null;

  private hasNavigatedToStartingScreen: boolean = false;

  constructor(props: IRouterProps) {
    super(props);
    // A non-Kuika host page names the first screen with starting_screen. The route has to be in
    // the hash before HashRouter reads it on the first render: once "/" is on screen,
    // PrivateRoute's root check sends the user to their own starting screen before a later hash
    // write is processed.
    if (this.shouldNavigateToStartingScreen()) {
      this.hasNavigatedToStartingScreen = true;
      replaceHashBeforeRouterMount(this.getStartingScreenHash());
    }
  }

  componentDidMount = () => {
    // SET LANGUAGE TO HTML BODY
    const lang = LocalStorageService.getUserLanguage();
    if (lang) {
      const fixedLangAttributeValue = lang.replace("_", "-");
      document.body.setAttribute("lang", fixedLangAttributeValue);
    }
    // The constructor normally does this. It is reached only when the starting_screen attribute
    // arrives after the first render (componentDidMount re-runs itself below).
    if (this.shouldNavigateToStartingScreen()) {
      this.hasNavigatedToStartingScreen = true;
      this.navigateToStartingScreen();
    }

    window.onfocus = function () {
      if (window.kuika === undefined) {
        window.kuika = {};
      }
      window.kuika.isTabActive = true;
    };

    window.onblur = function () {
      if (window.kuika === undefined) {
        window.kuika = {};
      }
      window.kuika.isTabActive = false;
    };

    if (!window.styler_speed) {
      window.styler_speed = 20;
    } else if (window.styler_speed < 500) {
      window.styler_speed += 100;
    }

    if (window?.kuika?.activeKuikaComponent !== undefined) {
      return;
    }
    const runTimeout = () => {
      this.timerId = setTimeout(() => {
        const allFormItems: NodeListOf<HTMLElement> = document.querySelectorAll(".kFormItem");
        if (allFormItems) {
          allFormItems.forEach((formItem) => {
            if (formItem.getAttribute("data-display-affected") === "true") {
              return;
            }
            const antFormItemControlInputContent: HTMLElement = formItem.querySelector(
              ".ant-form-item-control .ant-form-item-control-input .ant-form-item-control-input-content"
            );
            const antFormItemControlInput: HTMLElement = formItem.querySelector(
              ".ant-form-item-control .ant-form-item-control-input"
            );
            const antFormItemControl: HTMLElement = formItem.querySelector(".ant-form-item-control");

            if (
              antFormItemControlInputContent &&
              antFormItemControlInputContent.children &&
              antFormItemControlInputContent.children.length > 0
            ) {
              const formChild: HTMLElement = antFormItemControlInputContent.children[0] as HTMLElement;
              let calculatedDisplay: string = formChild.style.display;
              if (
                calculatedDisplay &&
                antFormItemControl &&
                antFormItemControlInput &&
                antFormItemControlInputContent
              ) {
                if (calculatedDisplay === "inline-flex" || calculatedDisplay === "inline-block") {
                  calculatedDisplay = "";
                  formItem.style.width = formChild.style.width ?? "auto";
                  formItem.style.display = "inline-block";
                  formItem.setAttribute("data-display-affected", "true");
                }
              }
            }
          });
        }
        this.componentDidMount();
      }, window.styler_speed);
    };

    runTimeout();

    setTimeout(() => {
      clearTimeout(this.timerId);
    }, 10000);
  };

  private getScreenInputPropKeys = (): string[] => {
    return Object.keys(this.props || {}).filter((k) => k && k.startsWith("screenInput_"));
  };

  private buildScreenInputsFromProps = (): Record<string, unknown> => {
    const screenInputs: Record<string, unknown> = {};
    this.getScreenInputPropKeys().forEach((key) => {
      const inputName = key.substring("screenInput_".length);
      screenInputs[inputName] = this.props[key];
    });
    return screenInputs;
  };

  private shouldNavigateToStartingScreen = (): boolean => {
    // remount hands a missing attribute over as null, not undefined.
    const startingScreen: string = this.props.startingScreen ?? "";
    return this.props.appMode === "WebComponent" && startingScreen.length > 0 && !this.hasNavigatedToStartingScreen;
  };

  // "X", "/X", "#X" and "#/X" all become "#/X", the form HashRouter keeps as is. Without the slash
  // HashRouter rewrites the hash through location.replace, which drops the host entry's history.state.
  private getStartingScreenHash = (): string => {
    const startingScreen: string = this.props.startingScreen ?? "";
    const route: string = startingScreen.startsWith("#") ? startingScreen.slice(1) : startingScreen;
    const path: string = route.startsWith("/") ? route : `/${route}`;
    const params: URLSearchParams = new URLSearchParams();
    Object.entries(this.buildScreenInputsFromProps()).forEach(([name, value]: [string, unknown]): void => {
      if (value === undefined || value === null) {
        return;
      }
      params.append(name, typeof value === "string" ? value : JSON.stringify(value));
    });
    const query: string = params.toString();
    return query.length > 0 ? `#${path}?${query}` : `#${path}`;
  };

  // HashRouter is mounted by the time this runs, so it needs the hashchange a plain assignment fires.
  private navigateToStartingScreen = (): void => {
    try {
      const hash: string = this.getStartingScreenHash();

      if (window.location.hash !== hash) {
        window.location.hash = hash;
      }
    } catch (e) {
      console.error("Error navigating to starting screen:", e);
    }
  };

  render() {
    const KuikaRouter = this.KuikaRouter();
    return (
      <>
        <KuikaRouter>
          <Switch key="Switch">
                        <PrivateRoute exact path="/" component={ROLEAUTH_Screen} />
                        <Route path={["/sparepartsbasedreports", "/technicalservicereports", "/nextsteplist", "/rolelist", "/userprofile", "/polisajbasedreports", "/monthlyallocationcopy", "/loomisreports", "/purchasebasedreports", "/importlist", "/productdetail", "/contactsourcelist", "/rolexmaterialreporting", "/tudorbasedreporting", "/rolexotherproductreporting", "/stockdistribution", "/leadaddbyexcelcopy", "/distributiondetail", "/transferbekleyenhavuzu", "/orderlist", "/distributiondetailstore", "/createtransferreceipt", "/usermanagementcopy", "/incomingtransferdetail", "/leadaddbyexcelai", "/stocklistmanager", "/rolexbasedreporting", "/reservationmanagement", "/dupontbasedreporting", "/stockliststorebase", "/rolexfamilyreporting", "/leadlist", "/montblancbasedreporting", "/tudorfamilyreporting", "/stokveurunarama", "/annualportfoliolist", "/rolexdiameterreporting", "/productdistribution", "/onayagonderdigimsatislar", "/productlist", "/transfertalepleri", "/dashboardtempmanager", "/reportcashnebim", "/leadadd", "/leadaddtemp", "/satisbasarilipop", "/dashboardtemptopmanager", "/notificationmanager", "/annualportfoliocreationstep1copycopy", "/reportsalesnebim", "/approvedleadlist", "/taskmanagementtopmanager", "/stocklistdetail", "/yearlystockentry", "/customerlist", "/yearlyallocationcopy", "/reportinventorynebim", "/distributionpool", "/allleadpending", "/satisislemi", "/dashboardtemp", "/importlistdetail", "/leadlisttemp", "/taskmanagementperson", "/taskmanagementmanager", "/stockliststore", "/leadreport", "/discountlimit", "/freesalesweb", "/ucuncukisifaturaonaylari"]} component={MasterScreen_Screen_Wrapper} />
            <Route exact path="/resetpassword" component={ResetPassword_Screen} />
            <Route exact path="/forgotpassword" component={ForgotPassword_Screen} />
            <Route exact path="/verificationcode" component={VerificationCode_Screen} />
            <PrivateRoute exact path="/customerchangelog" component={CustomerChangeLog_Screen} />
            <PrivateRoute exact path="/contactsourceedit" component={ContactSourceEdit_Screen} />
            <PrivateRoute exact path="/productlogs" component={ProductLogs_Screen} />
            <PrivateRoute exact path="/nextstepadd" component={NextStepAdd_Screen} />
            <PrivateRoute exact path="/nextstepedit" component={NextStepEdit_Screen} />
            <PrivateRoute exact path="/settingpanel" component={SettingPanel_Screen} />
            <PrivateRoute exact path="/leaddetailaddnote" component={LeadDetailAddNote_Screen} />
            <PrivateRoute exact path="/contactsourceadd" component={ContactSourceAdd_Screen} />
            <Route exact path="/signup" component={Signup_Screen} />
            <PrivateRoute exact path="/executionplanscreen" component={ExecutionPlanScreen_Screen} />
            <PrivateRoute exact path="/leaddetailsalesperson" component={LeadDetailSalesPerson_Screen} />
            <PrivateRoute exact path="/leadrejectpopup" component={LeadRejectPopUp_Screen} />
            <PrivateRoute exact path="/leadrejectcustomerpopup" component={LeadRejectCustomerPopUp_Screen} />
            <PrivateRoute exact path="/transferdashboard" component={TransferDashboard_Screen} />
            <PrivateRoute exact path="/transferislemgunlugu" component={TransferIslemGunlugu_Screen} />
            <PrivateRoute exact path="/userroles" component={UserRoles_Screen} />
            <PrivateRoute exact path="/importleadmersin" component={ImportLeadMersin_Screen} />
            <PrivateRoute exact path="/entegrasyonhata" component={EntegrasyonHata_Screen} />
            <PrivateRoute exact path="/urunvemagazastokdetay" component={UrunVeMagazaStokDetay_Screen} />
            <PrivateRoute exact path="/reservationreject" component={ReservationReject_Screen} />
            <PrivateRoute exact path="/reservationpopup" component={ReservationPopUp_Screen} />
            <PrivateRoute exact path="/reservationedit" component={ReservationEdit_Screen} />
            <PrivateRoute exact path="/importleadadana" component={ImportLeadAdana_Screen} />
            <PrivateRoute exact path="/transferraporlari" component={TransferRaporlari_Screen} />
            <PrivateRoute exact path="/customerdetailinfo" component={CustomerDetailInfo_Screen} />
            <PrivateRoute exact path="/referancecreatenew" component={ReferanceCreateNew_Screen} />
            <PrivateRoute exact path="/usercreatecopy" component={UserCreatecopy_Screen} />
            <PrivateRoute exact path="/importleadgaziantep" component={ImportLeadGaziantep_Screen} />
            <PrivateRoute exact path="/transferfisihazirlama" component={TransferFisiHazirlama_Screen} />
            <PrivateRoute exact path="/leadfiledetail" component={LeadFileDetail_Screen} />
            <PrivateRoute exact path="/dnm0100transferfiskarti" component={DNM0100TransferFisKarti_Screen} />
            <PrivateRoute exact path="/rolemanagement" component={RoleManagement_Screen} />
            <PrivateRoute exact path="/alternativeinfo" component={AlternativeInfo_Screen} />
            <PrivateRoute exact path="/useredit" component={UserEdit_Screen} />
            <PrivateRoute exact path="/importleadantalyarolex" component={ImportLeadAntalyaRolex_Screen} />
            <PrivateRoute exact path="/dnm0100detailscreen" component={DNM0100DetailScreen_Screen} />
            <PrivateRoute exact path="/referancecreatepost" component={ReferanceCreatePost_Screen} />
            <PrivateRoute exact path="/customerdetailpage" component={CustomerDetailPage_Screen} />
            <Route exact path="/signin" component={this.LoginComponent()} />
            <Route exact path="/signin" component={Signin_Screen} />
            <PrivateRoute exact path="/poponaybekleyen" component={PopOnayBekleyen_Screen} />
            <PrivateRoute exact path="/leaddetailtemp" component={LeadDetailTemp_Screen} />
            <PrivateRoute exact path="/allleadpendingdetail" component={AllLeadPendingDetail_Screen} />
            <PrivateRoute exact path="/transferfisleri" component={TransferFisleri_Screen} />
            <PrivateRoute exact path="/leadsatisbasarilipop" component={LeadSatisBasariliPop_Screen} />
            <PrivateRoute exact path="/bosekranyusuf" component={BosekranYusuf_Screen} />
            <PrivateRoute exact path="/terminpendinglead" component={TerminPendingLead_Screen} />
            <PrivateRoute exact path="/talepsatisislemi" component={TalepSatisIslemi_Screen} />
            <PrivateRoute exact path="/roleauth" component={ROLEAUTH_Screen} />
            <PrivateRoute exact path="/customerupdatepost" component={CustomerUpdatePost_Screen} />
            <PrivateRoute exact path="/ucuncukisifaturaonaydetayi" component={UcuncuKisiFaturaOnayDetayi_Screen} />
            <PrivateRoute exact path="/transferbildirimgonderimizleme" component={TransferBildirimGonderimIzleme_Screen} />
            <PrivateRoute exact path="/leadalternativemodeladd" component={LeadAlternativeModelAdd_Screen} />
            <PrivateRoute exact path="/transferfisidetayi" component={TransferFisiDetayi_Screen} />
            <PrivateRoute exact path="/deneme2copy" component={Deneme2copy_Screen} />
            <PrivateRoute exact path="/popterminonerisibekleyen" component={PopTerminOnerisiBekleyen_Screen} />
            <PrivateRoute exact path="/reservationpopup1" component={ReservationPopup1_Screen} />
            <PrivateRoute exact path="/deneme001" component={Deneme001_Screen} />
            <PrivateRoute exact path="/approvelead" component={ApproveLead_Screen} />
            <PrivateRoute exact path="/salesweb" component={SalesWeb_Screen} />
            <PrivateRoute exact path="/reservationpopup2" component={ReservationPopUp2_Screen} />
            <PrivateRoute exact path="/transferfiskabul" component={TransferFisKabul_Screen} />
            <PrivateRoute exact path="/musterionaypop" component={MusteriOnayPop_Screen} />
            <PrivateRoute exact path="/customererplog" component={CustomerErpLog_Screen} />
            <PrivateRoute exact path="/transfertalepdetay" component={TransferTalepDetay_Screen} />
            <PrivateRoute exact path="/customercreatepost" component={CustomerCreatePost_Screen} />
            <PrivateRoute exact path="/leadupdate" component={LeadUpdate_Screen} />
            <PrivateRoute exact path="/poprezervonaybekleyenpopup" component={PopRezervOnayBekleyenPopup_Screen} />
            <PrivateRoute exact path="/leftmenu" component={LeftMenu_Screen} />
            <PrivateRoute exact path="/kubrabosekran" component={Kubrabosekran_Screen} />
            <PrivateRoute exact path="/leaddetail" component={LeadDetail_Screen} />
            <PrivateRoute exact path="/talepduzenlemeekrani" component={TalepDuzenlemeEkrani_Screen} />
            <PrivateRoute exact path="/leadaddchangeproduct" component={LeadAddChangeProduct_Screen} />
            <PrivateRoute exact path="/leadproductchange" component={LeadProductChange_Screen} />
            <PrivateRoute exact path="/transfertaleponay" component={TransferTalepOnay_Screen} />
            <PrivateRoute exact path="/allleadpendingtermindegis" component={AllLeadPendingTerminDegis_Screen} />
            <PrivateRoute exact path="/reservationpopup3" component={ReservationPopUp3_Screen} />
            <PrivateRoute exact path="/bildirimpopup" component={BildirimPopup_Screen} />
            <PrivateRoute exact path="/adddiscountlimit" component={AddDiscountLimit_Screen} />
            <PrivateRoute exact path="/deneme001workspace" component={Deneme001Workspace_Screen} />
            <PrivateRoute exact path="/bildirimlerbekleyenisler" component={BildirimlerBekleyenIsler_Screen} />
            <PrivateRoute exact path="/talebealternatifurunekle" component={TalebeAlternatifUrunEkle_Screen} />
            <PrivateRoute exact path="/allcustomerchangelog" component={AllCustomerChangeLog_Screen} />
            <PrivateRoute exact path="/transfertalebiolusturstok" component={TransferTalebiOlusturStok_Screen} />
            <PrivateRoute exact path="/transfertalebiolusturv2" component={TransferTalebiOlusturV2_Screen} />

            <Route path="/redirect" component={Redirect} />
            <Route path={"/login"} component={this.LoginComponent()} />
            
            
            <Route exact path="/forgotpassword" component={ForgotPassword} />
            <Route exact path="/resetpassword" component={ResetPassword} />
            <PrivateRoute exact path="/dashboard" component={Dashboard} />
            <Route exact path="/kuikainfo" component={KuikaInfo} />
            <Route exact path="/msalredirect" component={MsalRedirect} />
            <Route exact path="/wfmailinteraction" component={WFMailInteraction} />
            <PrivateRoute exact path="/scancomparetest" component={ScanCompareTest} />
            <Route exact path="/notificationredirect" component={NotificationRedirect} />
            <Route exact path="/logout" component={Redirect} />
            <Route path="*" component={NoMatch404} />
          </Switch>
        </KuikaRouter>
      </>
    );
  }

  KuikaRouter = () => {
    // Web component case
    let isWebComponentApp: any;
    isWebComponentApp = this.props.appMode === "WebComponent";
    if (
      confJson?.domainName !== undefined &&
      confJson?.applicationName !== undefined &&
      confJson?.applicationName !== "" &&
      window.kuika !== undefined &&
      window.kuika?.apps !== undefined &&
      window.kuika?.apps.length !== undefined &&
      window.kuika?.apps.length > 0
    ) {
      window.kuika?.apps.forEach((app: any) => {
        if (app.appName === confJson.applicationName && app.workspace === confJson.domainName) {
          isWebComponentApp = true;
        }
      });
    }
    if (window.kuika === undefined) {
      window.kuika = {};
    }
    window.kuika.isWebComponentApp = isWebComponentApp;

    // Embedded MFE containers need to know whose routing space window.location.hash
    // is: theirs (pathname-routed shell) or the shell's own. A hash-routed shell
    // means a hash is never a microapp deep link — see mfe-initial-navigation.ts.
    //
    // First writer wins: an embedded microapp bundle runs its own copy of this
    // Router (always a HashRouter) on the SAME window, and it must not overwrite the
    // shell's answer. The shell's route tree renders before it can load any bundle,
    // so the first write is always the outermost app's.
    const isHashRouted: boolean = isWebComponentApp === true || this.props.routerType === "HashRouter";
    // Module-scoped, unlike isShellHashRouted below: an embedded microapp runs its own copy of
    // this module, so each bundle's SiderMenu learns its own routing mode here.
    KMainFunctions.isHashRouted = isHashRouted;
    if (window.kuika.isShellHashRouted === undefined) {
      window.kuika.isShellHashRouted = isHashRouted;
    }

    if (isHashRouted) {
      return (props: any) => {
        return <HashRouter key="HashRouter">{props.children}</HashRouter>;
      };
    }
    return (props: any) => {
      if (KMainFunctions.virtualDirectoryURL === "auto" || window?.location?.protocol === "file:") {
        return <BrowserRouter key="BrowserRouter">{props.children}</BrowserRouter>;
      }
      return (
        <BrowserRouter basename={KMainFunctions.virtualDirectoryURL} key="BrowserRouter">
          {props.children}
        </BrowserRouter>
      );
    };
  };

  LoginComponent = () => {
    if (this.props.authType === "MSAL") {
      return MsalLogin;
    }

    const { external_access_token } = this.props;
    const { external_refresh_token } = this.props;
    const { external_user } = this.props;
    const { external_provider_type } = this.props;
    // A Kuika host injects external_access_token as a short-lived MFE handoff
    // JWT; no refresh_token is involved — the microapp's own backend mints its
    // session cookies once the token is redeemed. A non-Kuika host injects its
    // own token plus external_provider_type, naming the customer's
    // External1..External5 validator that will verify it.
    if (external_access_token !== null && external_access_token !== undefined && external_access_token !== "") {
      return (props: any) => {
        return (
          <MfeLogin
            external_user={external_user}
            external_access_token={external_access_token}
            external_refresh_token={external_refresh_token}
            external_provider_type={external_provider_type}
          ></MfeLogin>
        );
      };
    }

    if (this.props.authType === "Kuika") {
      return Signin_Screen;
    }
    return <></>;
  };
}
