import { CloseOutlined } from "@ant-design/icons";
import { Modal } from "antd/es";
import { PureComponent, ReactNode } from "react";
import { isMobile } from "react-device-detect";
import { connect } from "react-redux";
import { Redirect, Route } from "react-router-dom";
import { Camera, FACING_MODES, IMAGE_TYPES } from "../components/kuika-camera/kuika-camera";
import { ImportMappedExcelRuntime } from "../components/modals/import-mapped-excel-runtime/import-mapped-excel-runtime";
import { PaymentElementStripe } from "../components/web-components";
import { IIyzicoCheckoutFormResponseDto } from "../models/dto/iyzico.dto";
import {
  hideImportMappedExcelModal,
  hideIyzicoDrawer,
  hidePhotoTake,
  hideStripeDrawer,
  showImportMappedExcelModal,
  showIyzicoDrawer,
  showPhotoTake,
  showStripeDrawer
} from "../redux/modals/actions";
import { AppState } from "../redux/root-reducer";
import HelperService from "../services/helper-service";
import { UserService } from "../services/user-service";
import { KContext } from "../shared/hoc/with-context";
import { KNavigator, withHistory } from "../shared/hoc/with-history";
import { KuikaAppManager } from "../shared/utilty/kuika-app-manager";

declare let window: Window & { userInfo: any };

/** The slice of react-router's location that `withHistory` injects and this route reads. */
interface IRouteLocation {
  pathname: string;
}

interface PrivateRouteProps {
  component: any;
  exact?: boolean;
  path: string;
  photoTakeVisible?: any;
  hidePhotoTake?: any;
  stripeDrawerVisible?: any;
  iyzicoDrawerVisible?: any;
  hideStripeDrawer: any;
  hideIyzicoDrawer: any;
  stripeData?: any;
  stripeCallBack?: any;
  iyzicoCallBack?: any;
  iyzicoData?: any;
  screen?: any;
  futureUse?: any;
  navigator?: KNavigator;
  location?: IRouteLocation;
  isImportMappedExcelModalVisible?: boolean;
}

interface PrivateRouteState {
  context: KContext | undefined;
  authChecked: boolean;
}

class PrivateRoute extends PureComponent<PrivateRouteProps, PrivateRouteState> {
  constructor(props: PrivateRouteProps) {
    super(props);
    // If the session is already established (cookie + userInfo cached from a previous mount),
    // initialise context immediately so remounts don't flash the loading state.
    const hasVerifiedSession: boolean =
      KuikaAppManager.readLoginStateCookie("is_logged_in") === "1" && window.userInfo !== undefined;
    this.state = { context: hasVerifiedSession ? new KContext() : undefined, authChecked: hasVerifiedSession };
  }

  async componentDidMount() {
    const hasLoginHint: boolean = KuikaAppManager.readLoginStateCookie("is_logged_in") === "1";
    if (!hasLoginHint) {
      this.setState({ authChecked: true });
      return;
    }

    const shouldLoadUserInfo: boolean = !(this.props.path === "/redirect" && this.props.screen === undefined);
    if (shouldLoadUserInfo) {
      await UserService.GetUserInfo();
    }

    const hasVerifiedSession: boolean =
      KuikaAppManager.readLoginStateCookie("is_logged_in") === "1" && window.userInfo !== undefined;
    const nextContext: KContext | undefined = hasVerifiedSession ? (this.state.context ?? new KContext()) : undefined;
    this.setState({ context: nextContext, authChecked: true }, () => {
      if (hasVerifiedSession) {
        window.dispatchEvent(new CustomEvent("privateRouteContextReady"));
      }
    });

    // Ask the app's own router, not the document URL: a hash-routed app (embedded
    // MicroApp, widget, Electron shell) keeps its "/" in the hash while
    // window.location.pathname belongs to the host page.
    const routePathname: string = this.props.location?.pathname ?? "";

    if (routePathname === "/" && window.userInfo) {
      this.props.navigator?.gotoStartingScreen();
    }
  }

  handleClosePhoto = () => {
    const imgNode: HTMLImageElement = document
      .getElementsByClassName("react-html5-camera-photo")[0]
      .getElementsByTagName("img")[0];
    imgNode.src = "";
    this.props.hidePhotoTake();
  };

  renderStripeDrawer = () => {
    if (this.props.stripeDrawerVisible) {
      return (
        <Modal
          destroyOnClose
          onCancel={() => {
            this.props.screen.setState(
              { OpenStripePaymentDrawer: { isSuccess: false, errorMessage: "Action aborted by the user" } },
              () => {
                this.props.hideStripeDrawer();
                this.props.stripeCallBack();
              }
            );
          }}
          footer={null}
          open={this.props.stripeDrawerVisible}
        >
          <PaymentElementStripe
            stripeAction={this.props.stripeData}
            callback={this.props.stripeCallBack}
            screen={this.props.screen}
            futureUse={this.props.futureUse}
          />
        </Modal>
      );
    }
    return <></>;
  };

  renderIyzicoDrawer = () => {
    if (this.props.iyzicoDrawerVisible) {
      var timer;
      setTimeout(() => {
        const data = this.props.iyzicoData.data as IIyzicoCheckoutFormResponseDto;
        var checkoutFormContent = data.checkoutFormContent;
        var checkoutFormContent = checkoutFormContent.replace(
          /<script\s+type\s*=\s*"text\/javascript"\s*>|<\/script>/gi,
          ""
        );
        const iframe = document.getElementById("iyzipay-iframe") as any;
        const iframeWin = iframe.contentWindow || iframe;
        const iframeDoc = iframe.contentDocument || iframeWin.document;
        var scriptElement = iframeDoc.createElement("script");
        scriptElement.innerHTML = checkoutFormContent;
        iframeDoc.documentElement.addEventListener("popstate", () => alert("hi"));

        timer = setInterval(() => {
          const iframe = document.getElementById("iyzipay-iframe") as any;
          const iframeWin = iframe.contentWindow || iframe;
          try {
            var a = iframeWin.location.host;
            if (a === "") {
            } else {
              clearInterval(timer);
              this.props.screen.setState(
                {
                  IyzicoInitializeCheckoutForm: {
                    checkoutFormContent: data.checkoutFormContent,
                    token: data.token,
                    status: data.status,
                    statusCode: data.statusCode,
                    errorMessage: data.errorMessage,
                    conversationId: data.conversationId
                  }
                },
                () => {
                  this.props.hideIyzicoDrawer();
                  if (this.props.iyzicoCallBack) {
                    this.props.iyzicoCallBack();
                  }
                }
              );
            }
          } catch (error) {
            clearInterval(timer);
            this.props.screen.setState(
              {
                IyzicoInitializeCheckoutForm: {
                  checkoutFormContent: data.checkoutFormContent,
                  token: data.token,
                  status: data.status,
                  statusCode: data.statusCode,
                  errorMessage: data.errorMessage,
                  conversationId: data.conversationId
                }
              },
              () => {
                this.props.hideIyzicoDrawer();
                if (this.props.iyzicoCallBack) {
                  this.props.iyzicoCallBack();
                }
              }
            );
          }
        }, 50);
        iframeDoc.documentElement.appendChild(scriptElement);
      }, 1000);
      return (
        <Modal
          keyboard
          width={"100%"}
          destroyOnClose
          onCancel={() => {
            this.props.screen.setState(
              {
                IyzicoInitializeCheckoutForm: {
                  checkoutFormContent: "",
                  token: "",
                  status: "Aborted",
                  statusCode: 0,
                  errorMessage: "Action aborted by the user",
                  conversationId: ""
                }
              },
              () => {
                this.props.hideIyzicoDrawer();
                clearInterval(timer);
                if (this.props.iyzicoCallBack) {
                  this.props.iyzicoCallBack();
                }
              }
            );
          }}
          footer={null}
          open={this.props.iyzicoDrawerVisible}
        >
          <iframe
            height="800"
            width="100%"
            id="iyzipay-iframe"
            srcDoc="<div id='iyzipay-checkout-form' className='responsive'></div>"
          ></iframe>
        </Modal>
      );
    }
    return <></>;
  };

  renderPhotoTake = () => {
    if (!this.props.photoTakeVisible) {
      return <></>;
    }
    if (isMobile) {
      return (
        <>
          <CloseOutlined
            onClick={this.handleClosePhoto}
            style={{ position: "absolute", top: 60, fontSize: 40, zIndex: 99999, left: `calc(90vw)` }}
          />
          <Camera
            imageType={IMAGE_TYPES.JPG}
            isFullscreen
            isImageMirror={false}
            idealFacingMode={FACING_MODES.ENVIRONMENT}
          />
        </>
      );
    }
    return (
      <Modal
        destroyOnClose
        closable
        onCancel={this.handleClosePhoto}
        width="fit-content"
        footer={null}
        open={this.props.photoTakeVisible}
      >
        <Camera imageType={IMAGE_TYPES.JPG} isImageMirror={false} idealFacingMode={FACING_MODES.ENVIRONMENT} />
      </Modal>
    );
  };

  renderImportMappedExcel = () => {
    if (!this.props.isImportMappedExcelModalVisible) {
      return <></>;
    }
    return <ImportMappedExcelRuntime />;
  };

  render(): ReactNode {
    if (!this.state.authChecked) {
      return <div>Loading!</div>;
    }

    const routeContext: KContext | undefined = this.state.context;
    const hasVerifiedSession: boolean =
      KuikaAppManager.readLoginStateCookie("is_logged_in") === "1" &&
      window.userInfo !== undefined &&
      routeContext !== undefined;

    return (
      <>
        {hasVerifiedSession && this.renderPhotoTake()}
        {hasVerifiedSession && this.renderStripeDrawer()}
        {hasVerifiedSession && this.renderIyzicoDrawer()}
        {hasVerifiedSession && this.renderImportMappedExcel()}
        <Route
          exact={this.props.exact}
          path={this.props.path}
          render={(props) => {
            if (hasVerifiedSession) {
              return <this.props.component {...props} context={routeContext} />;
            }
            // Preserve the originally-requested URL as a ?redirectUri= query so the
            // login screen can send the user back after sign-in. Built from the live
            // browser location (incl. search + hash) to match the interceptor path,
            // so both route-guard and 401-driven redirects produce the same URL.
            const redirectUri: string =
              window.location.pathname + window.location.search + (window.location.hash ?? "");
            return (
              <Redirect
                to={{
                  pathname: "/signin",
                  search: HelperService.buildLoginRedirectQuery(redirectUri),
                  state: { from: props.location }
                }}
              />
            );
          }}
        />
      </>
    );
  }
}

export const PrivateRoute2 = ({ component: Component, ...rest }) => {
  return (
    <>
      <Route
        {...rest}
        render={(props) => {
          const hasVerifiedSession: boolean =
            KuikaAppManager.readLoginStateCookie("is_logged_in") === "1" && window.userInfo !== undefined;
          if (hasVerifiedSession) {
            return <Component {...props} />;
          }
          const redirectUri: string = window.location.pathname + window.location.search + (window.location.hash ?? "");
          return (
            <Redirect
              to={{
                pathname: "/signin",
                search: HelperService.buildLoginRedirectQuery(redirectUri),
                state: { from: props.location }
              }}
            />
          );
        }}
      />
    </>
  );
};

const mapStateToProps = (state: AppState) => {
  return {
    spinnerCount: state.spinnerReducer.spinnerCount,
    photoTakeVisible: state.photoTakeReducer.visible,
    stripeDrawerVisible: state.stripeDrawerReducer.visible,
    stripeData: state.stripeDrawerReducer.payload,
    stripeCallBack: state.stripeDrawerReducer.callback,
    iyzicoCallBack: state.iyzicoDrawerReducer.callback,
    screen: state.stripeDrawerReducer.screen ?? state.iyzicoDrawerReducer.screen,
    futureUse: state.stripeDrawerReducer.futureUse,
    iyzicoDrawerVisible: state.iyzicoDrawerReducer.visible,
    iyzicoData: state.iyzicoDrawerReducer.payload,
    isImportMappedExcelModalVisible: state.importMappedExcelModalReducer.visible ?? false
  };
};

const mapDispatchToProps = (dispatch) => ({
  showPhotoTake: () => dispatch(showPhotoTake()),
  hidePhotoTake: () => dispatch(hidePhotoTake()),
  showStripeDrawer: (data, callback, screen, futureUse) =>
    dispatch(showStripeDrawer(data, callback, screen, futureUse)),
  hideStripeDrawer: (data, callback, screen) => dispatch(hideStripeDrawer(data, callback, screen)),
  showIyzicoDrawer: (data, callback, that) => dispatch(showIyzicoDrawer(data, callback, that)),
  hideIyzicoDrawer: (data, callback, that) => dispatch(hideIyzicoDrawer(data, callback, that)),
  showImportMappedExcelModal: (dsId, tableName, primaryKey, columnMapping, parameters) =>
    dispatch(showImportMappedExcelModal(dsId, tableName, primaryKey, columnMapping, parameters)),
  hideImportMappedExcelModal: () => dispatch(hideImportMappedExcelModal())
});

const privateRoute = connect(mapStateToProps, mapDispatchToProps)(withHistory(PrivateRoute));
export { privateRoute as PrivateRoute };
