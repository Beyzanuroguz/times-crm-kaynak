import { act, render } from "@testing-library/react";
import React, { useContext } from "react";
import { IInlineOverlayNav, InlineOverlayNavContext, MasterScreenWrapper } from "../master-screen-wrapper";

interface IRecordedProps {
  location?: { search?: string; pathname?: string; state?: unknown };
  screenInputs?: Record<string, unknown>;
  children?: React.ReactNode;
}

let lastMasterProps: IRecordedProps | null = null;
// KOA-8559: capture the overlay-nav handle the wrapper publishes to its master subtree.
let capturedOverlayNav: IInlineOverlayNav | null = null;

const MockMaster: React.FC<IRecordedProps> = (props) => {
  lastMasterProps = props;
  capturedOverlayNav = useContext(InlineOverlayNavContext);
  return <div data-testid="master">{props.children}</div>;
};

const MockProvider: React.FC<{ children?: React.ReactNode }> = ({ children }) => <>{children}</>;

class TestWrapper extends MasterScreenWrapper {
  protected get anonymousPaths(): string[] {
    return [];
  }

  protected get MasterComponent(): React.ComponentType<IRecordedProps> {
    return MockMaster;
  }

  protected get MasterProvider(): React.ComponentType<{ children?: React.ReactNode }> {
    return MockProvider;
  }

  // forceReady skips the privateRouteReady auth gate so the master renders synchronously
  // in tests without needing to stub window.userInfo / the privateRouteContextReady event.
  protected get forceReady(): boolean {
    return true;
  }

  protected renderSwitchWrapper(): React.ReactNode {
    return <div data-testid="switch-content">switch</div>;
  }
}

describe("MasterScreenWrapper", () => {
  beforeEach(() => {
    lastMasterProps = null;
  });

  // KOA-17357: react-router-dom hands route props (match/location/history) to the routed
  // wrapper subclass. The wrapper must forward `location` to the Master component so the
  // master's `withScreenInput` HOC can resolve screen inputs from the URL.
  it("forwards the location prop from route props to the Master component", () => {
    const location: { search: string; pathname: string; state: { screenInputs: { x: number } } } = {
      search: "?BolgeMudurId=abc",
      pathname: "/auditmenu",
      state: { screenInputs: { x: 1 } }
    };

    render(<TestWrapper location={location} />);

    expect(lastMasterProps).not.toBeNull();
    expect(lastMasterProps?.location).toBe(location);
  });

  it("passes undefined location when the wrapper is mounted without route context", () => {
    render(<TestWrapper />);

    expect(lastMasterProps).not.toBeNull();
    expect(lastMasterProps?.location).toBeUndefined();
  });

  // KOA-17357: drawer/modal/floatingPanel (and any other non-currentPage / non-newTab /
  // non-newWindow openAs) mount via `*_InlineWrapper` with no Route context. The parent
  // screen passes `window.kuika.navigationScreenInputs` as a prop so the master's
  // `withScreenInput` HOC can populate via the `props.screenInputs` source.
  it("forwards the screenInputs prop to the Master component for inline mounts", () => {
    const screenInputs: Record<string, unknown> = {
      BolgeMudurId: "11111111-1111-1111-1111-111111111111",
      Count: 42
    };

    render(<TestWrapper screenInputs={screenInputs} />);

    expect(lastMasterProps).not.toBeNull();
    expect(lastMasterProps?.screenInputs).toBe(screenInputs);
  });

  it("forwards both location and screenInputs when both are provided", () => {
    const location: { search: string; pathname: string } = {
      search: "?foo=bar",
      pathname: "/x"
    };
    const screenInputs: Record<string, unknown> = { y: 1 };

    render(<TestWrapper location={location} screenInputs={screenInputs} />);

    expect(lastMasterProps?.location).toBe(location);
    expect(lastMasterProps?.screenInputs).toBe(screenInputs);
  });

  it("passes undefined screenInputs when the wrapper is route-mounted (currentPage path)", () => {
    const location: { pathname: string } = { pathname: "/x" };

    render(<TestWrapper location={location} />);

    expect(lastMasterProps?.location).toBe(location);
    expect(lastMasterProps?.screenInputs).toBeUndefined();
  });

  // KOA-8559: "Open in Current Overlay" host behavior. An inline-mount wrapper that
  // overrides overlayScreenNames publishes InlineOverlayNavContext to its master subtree
  // and swaps its visible child when push() is called; a router-level wrapper (default
  // overlayScreenNames === null) publishes nothing (context stays the default null).
  describe("inline overlay host (KOA-8559)", () => {
    let lastOverlayArgs: { screenName: string; hasOnClose: boolean } | null = null;

    class OverlayHostWrapper extends TestWrapper {
      protected get overlayScreenNames(): string[] | null {
        return ["profile", "orders"];
      }

      protected renderOverlayScreen(
        screenName: string,
        _screenInputs: Record<string, unknown>,
        onClose: () => void
      ): React.ReactNode {
        lastOverlayArgs = { screenName, hasOnClose: typeof onClose === "function" };
        return <div data-testid="overlay-screen">{screenName}</div>;
      }
    }

    beforeEach(() => {
      lastOverlayArgs = null;
      capturedOverlayNav = null;
    });

    it("publishes the overlay-nav handle to the master subtree when it is an overlay host", () => {
      render(<OverlayHostWrapper />);

      expect(capturedOverlayNav).not.toBeNull();
      expect(capturedOverlayNav?.canRender("Profile")).toBe(true);
      expect(capturedOverlayNav?.canRender("Unknown")).toBe(false);
      expect(typeof capturedOverlayNav?.push).toBe("function");
    });

    it("publishes no overlay-nav context for a router-level wrapper (overlayScreenNames === null)", () => {
      render(<TestWrapper />);
      expect(capturedOverlayNav).toBeNull();
    });

    it("renders the switch content until push() is called, then renders the pushed screen", () => {
      const { getByTestId, queryByTestId } = render(<OverlayHostWrapper />);

      // Initial mount: shows the normal switch content, not an overlay screen.
      expect(getByTestId("switch-content")).toBeTruthy();
      expect(queryByTestId("overlay-screen")).toBeNull();

      // Pushing swaps the visible child to renderOverlayScreen's output.
      act(() => {
        capturedOverlayNav?.push("orders", { Id: "1" });
      });

      expect(getByTestId("overlay-screen").textContent).toBe("orders");
      expect(queryByTestId("switch-content")).toBeNull();
      expect(lastOverlayArgs).toEqual({ screenName: "orders", hasOnClose: true });
    });
  });
});
