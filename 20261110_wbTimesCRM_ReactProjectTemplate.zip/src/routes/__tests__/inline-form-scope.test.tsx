import "@testing-library/jest-dom";
import { act, fireEvent, render } from "@testing-library/react";
import { Form } from "antd/es";
import type { FormInstance } from "antd/es/form";
import React, { useContext, useEffect } from "react";
import { InlineFormScope, MasterFormContext } from "../master-screen-wrapper";

// KOA-17353: InlineFormScope is what isolates the form scope for drawer / modal /
// floatingPanel child screens that have no master. The two structural guarantees that
// keep stale field values from rehydrating on reopen are:
//   1. The form delivered through MasterFormContext inside the scope is a different
//      instance from any outer MasterFormContext form. Otherwise the child's
//      <Form.Item>s would still bind to the app-level root form (the bug).
//   2. Each mount of InlineFormScope creates its own form instance. destroyOnClose
//      unmounts the scope on drawer close, so the next open allocates a fresh form
//      with no carry-over from the previous open.
// Real Form value behaviour (preserve / resetFields) lives in antd; this suite verifies
// the structural invariants the wrapper is responsible for. The antd module is mocked
// in tests, so we deliberately do not assert on field-value semantics here.

interface IFormCapture {
  form: FormInstance | null;
}

const FormConsumer: React.FC<{ capture: IFormCapture }> = ({ capture }) => {
  const ctx: { form: FormInstance | null } = useContext(MasterFormContext);
  useEffect(() => {
    capture.form = ctx.form;
  });
  return <span data-testid="consumer" />;
};

const OuterFormProvider: React.FC<{ capture: IFormCapture; children: React.ReactNode }> = ({ capture, children }) => {
  const [form] = Form.useForm();
  useEffect(() => {
    capture.form = form;
  }, [form, capture]);
  return <MasterFormContext.Provider value={{ form, parentForm: null }}>{children}</MasterFormContext.Provider>;
};

describe("InlineFormScope", () => {
  it("provides a form instance via MasterFormContext", () => {
    const inner: IFormCapture = { form: null };
    render(
      <InlineFormScope>
        <FormConsumer capture={inner} />
      </InlineFormScope>
    );
    expect(inner.form).not.toBeNull();
  });

  it("shadows an outer MasterFormContext with its own form instance", () => {
    const outer: IFormCapture = { form: null };
    const inner: IFormCapture = { form: null };
    render(
      <OuterFormProvider capture={outer}>
        <InlineFormScope>
          <FormConsumer capture={inner} />
        </InlineFormScope>
      </OuterFormProvider>
    );
    expect(outer.form).not.toBeNull();
    expect(inner.form).not.toBeNull();
    expect(inner.form).not.toBe(outer.form);
  });

  it("allocates a new form instance per mount (mirrors drawer destroyOnClose / reopen)", () => {
    const first: IFormCapture = { form: null };
    const second: IFormCapture = { form: null };

    const { unmount: unmountFirst } = render(
      <InlineFormScope>
        <FormConsumer capture={first} />
      </InlineFormScope>
    );
    expect(first.form).not.toBeNull();

    unmountFirst();

    render(
      <InlineFormScope>
        <FormConsumer capture={second} />
      </InlineFormScope>
    );
    expect(second.form).not.toBeNull();
    expect(second.form).not.toBe(first.form);
  });

  // KOA-17422 regression. The white-screen reproduction is: user clicks a button on
  // CalisanListe to open a master-less drawer (parent.setState({NavVisible: true})),
  // closes it by clicking the mask / pressing Esc (antd Drawer.onClose triggers
  // parent.setState({NavVisible: false}, callCallback)), then clicks the SAME button
  // again (parent.setState({NavVisible: true})). With KOA-17353's wrapping, the
  // generated JSX inside the drawer is `{NavVisible && <InlineFormScope>...</InlineFormScope>}`
  // — a state-driven conditional remount, not an explicit unmount() API call. This
  // test asserts the state-driven path yields a fresh form on the second open, which
  // is the structural guarantee that prevents the stale-field collision that surfaced
  // as a render-time crash (white screen) before KOA-17353 landed.
  it("KOA-17422: state-driven NavVisible toggle (mask close + same-button reopen) yields a fresh form on reopen", () => {
    const captured: (FormInstance | null)[] = [];

    const CaptureOnMount: React.FC = () => {
      const ctx: { form: FormInstance | null } = useContext(MasterFormContext);
      useEffect(() => {
        captured.push(ctx.form);
      }, [ctx.form]);
      return <span data-testid="drawer-child" />;
    };

    const DrawerLikeParent: React.FC = () => {
      const [navVisible, setNavVisible] = React.useState<boolean>(false);
      return (
        <>
          <button data-testid="open-btn" type="button" onClick={() => setNavVisible(true)} />
          <button data-testid="mask-close" type="button" onClick={() => setNavVisible(false)} />
          {navVisible && (
            <InlineFormScope>
              <CaptureOnMount />
            </InlineFormScope>
          )}
        </>
      );
    };

    const { getByTestId } = render(<DrawerLikeParent />);

    act(() => {
      fireEvent.click(getByTestId("open-btn"));
    });
    expect(captured.length).toBe(1);
    expect(captured[0]).not.toBeNull();
    const firstOpenForm: FormInstance | null = captured[0];

    act(() => {
      fireEvent.click(getByTestId("mask-close"));
    });

    act(() => {
      fireEvent.click(getByTestId("open-btn"));
    });
    expect(captured.length).toBe(2);
    expect(captured[1]).not.toBeNull();
    expect(captured[1]).not.toBe(firstOpenForm);
  });
});
