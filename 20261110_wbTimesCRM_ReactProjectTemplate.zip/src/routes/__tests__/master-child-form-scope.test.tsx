import "@testing-library/jest-dom";
import { act, fireEvent, render, screen } from "@testing-library/react";
import React from "react";
import { MemoryRouter, Route, Switch, useHistory } from "react-router-dom";

// KOA-17999. The bug: a screen that sits under a MasterScreen came back with its fields
// still filled after the user navigated away and back, while the same screen without a
// master came back empty. Cause: `withForm` handed every screen under the master the ONE
// Form instance owned by the wrapper, and the wrapper's Route matches every path of the
// master group, so that instance outlived each child screen. antd's <Form> defaults to
// preserve={true}, so the outgoing screen's values stayed in the store and rehydrated on
// return.
//
// These are value-level tests, so they need real form semantics. The global antd/es stub
// (src/__mocks__/antd/es.cjs) has no store at all — Form.Item is a <div> and useForm()
// returns a throwaway literal. antd's <Form>/<Form.Item> are thin wrappers over
// rc-field-form's <Form>/<Field>, so binding straight to rc-field-form reproduces the
// semantics that matter here (preserve default, initialValues-on-first-mount, store
// lifecycle) without dragging antd's style layer into jsdom.
jest.mock("antd/es", () => {
  const ReactActual = jest.requireActual("react");
  const rcFieldForm = jest.requireActual("rc-field-form");
  const FormShim = (props: unknown) => ReactActual.createElement(rcFieldForm.default, props);
  FormShim.useForm = rcFieldForm.useForm;
  FormShim.Item = rcFieldForm.Field;
  return { Form: FormShim };
});

/* eslint-disable import/first */
import { Form } from "antd/es";
import type { FormInstance } from "antd/es/form";
import { withForm } from "../../shared/hoc/with-form";
import { IInlineOverlayNav, InlineOverlayNavContext, MasterScreenWrapper } from "../master-screen-wrapper";
/* eslint-enable import/first */

interface IScreenProps {
  form?: FormInstance;
  screenName: string;
}

// Mirrors what React_UIGenerator emits for a CHILD screen: its own <Form> bound to
// props.form with component={false} (no nested <form> element), wrapping the screen's
// Form.Items. KOA-17205.
class ChildScreenBody extends React.Component<IScreenProps> {
  render() {
    const fieldName: string = `${this.props.screenName}_input_value`;
    return (
      <Form form={this.props.form} name="basic" component={false} initialValues={{ [fieldName]: "" }}>
        <Form.Item name={fieldName}>
          <input data-testid={`${this.props.screenName}-input`} />
        </Form.Item>
      </Form>
    );
  }
}

const ChildScreen = withForm(ChildScreenBody);

interface IMasterBodyProps extends IScreenProps {
  children?: React.ReactNode;
}

let capturedMasterForm: FormInstance | null = null;
let capturedChildForms: (FormInstance | null)[] = [];

// Mirrors what React_UIGenerator emits for a MASTER screen: a real <form> element bound
// to props.form, with the routed child rendered inside it.
class MasterBody extends React.Component<IMasterBodyProps> {
  render() {
    capturedMasterForm = this.props.form ?? null;
    return (
      <Form form={this.props.form} name="basic" initialValues={{ master_input_value: "" }}>
        <Form.Item name="master_input_value">
          <input data-testid="master-input" />
        </Form.Item>
        <div data-testid="master">{this.props.children}</div>
      </Form>
    );
  }
}

const MockMaster = withForm(MasterBody);

const MockProvider: React.FC<{ children?: React.ReactNode }> = ({ children }) => <>{children}</>;

// Records the form instance the child subtree actually resolves to, so the structural
// invariant (child scope !== master scope) can be asserted alongside the value behaviour.
const FormRecorder: React.FC<{ form?: FormInstance }> = ({ form }) => {
  React.useEffect(() => {
    capturedChildForms.push(form ?? null);
  }, [form]);
  return null;
};

const RecordingChild = withForm(FormRecorder);

const NavButton: React.FC<{ to: string; testId: string }> = ({ to, testId }) => {
  const history = useHistory();
  return <button type="button" data-testid={testId} onClick={() => history.push(to)} />;
};

class TestWrapper extends MasterScreenWrapper {
  protected get anonymousPaths(): string[] {
    return [];
  }

  protected get MasterComponent(): React.ComponentType<IMasterBodyProps> {
    return MockMaster;
  }

  protected get MasterProvider(): React.ComponentType<{ children?: React.ReactNode }> {
    return MockProvider;
  }

  // Skips the privateRouteReady auth gate so master renders synchronously in tests.
  protected get forceReady(): boolean {
    return true;
  }

  protected renderSwitchWrapper(): React.ReactNode {
    return (
      <Switch>
        <Route
          exact
          path="/tst"
          render={() => (
            <>
              <ChildScreen screenName="tst" />
              <RecordingChild screenName="tst" />
              <NavButton to="/homepage" testId="to-homepage" />
            </>
          )}
        />
        <Route
          exact
          path="/homepage"
          render={() => (
            <>
              <ChildScreen screenName="homepage" />
              <NavButton to="/tst" testId="to-tst" />
            </>
          )}
        />
      </Switch>
    );
  }
}

// The generated router mounts ONE wrapper Route for the whole master group (see
// ReactProjectGenerator's `<Route path={[...group paths]} component={Master_Wrapper} />`),
// so the wrapper stays mounted while the user moves between /tst and /homepage. Mirrors
// how src/routes/route.tsx spreads the route props onto the wrapper.
const renderMasterGroup = (Wrapper: typeof TestWrapper) =>
  render(
    <MemoryRouter initialEntries={["/tst"]}>
      <Switch>
        <Route
          path={["/tst", "/homepage"]}
          render={(routeProps) => <Wrapper location={{ pathname: routeProps.location.pathname }} />}
        />
      </Switch>
    </MemoryRouter>
  );

describe("MasterScreenWrapper child form scope (KOA-17999)", () => {
  beforeEach(() => {
    capturedMasterForm = null;
    capturedChildForms = [];
  });

  it("clears a child screen's fields when the user leaves it and comes back", () => {
    renderMasterGroup(TestWrapper);

    fireEvent.change(screen.getByTestId("tst-input"), { target: { value: "typed by the user" } });
    expect(screen.getByTestId("tst-input")).toHaveValue("typed by the user");

    fireEvent.click(screen.getByTestId("to-homepage"));
    expect(screen.queryByTestId("tst-input")).toBeNull();

    fireEvent.click(screen.getByTestId("to-tst"));
    expect(screen.getByTestId("tst-input")).toHaveValue("");
  });

  it("keeps the master's own fields across child navigation", () => {
    renderMasterGroup(TestWrapper);

    fireEvent.change(screen.getByTestId("master-input"), { target: { value: "master filter" } });

    fireEvent.click(screen.getByTestId("to-homepage"));
    expect(screen.getByTestId("master-input")).toHaveValue("master filter");

    fireEvent.click(screen.getByTestId("to-tst"));
    expect(screen.getByTestId("master-input")).toHaveValue("master filter");
  });

  it("gives the child screen a form instance of its own, distinct from the master's", () => {
    renderMasterGroup(TestWrapper);

    expect(capturedMasterForm).not.toBeNull();
    expect(capturedChildForms.length).toBeGreaterThan(0);
    expect(capturedChildForms[0]).not.toBeNull();
    expect(capturedChildForms[0]).not.toBe(capturedMasterForm);
  });

  it("allocates a fresh child form instance on every child swap", () => {
    renderMasterGroup(TestWrapper);

    const firstVisit: FormInstance | null = capturedChildForms[0];

    fireEvent.click(screen.getByTestId("to-homepage"));
    fireEvent.click(screen.getByTestId("to-tst"));

    const secondVisit: FormInstance | null = capturedChildForms[capturedChildForms.length - 1];
    expect(secondVisit).not.toBeNull();
    expect(secondVisit).not.toBe(firstVisit);
  });

  // A child screen's values must not bleed into a sibling that happens to reuse a field
  // name — the shared instance made every screen under the master share one namespace.
  it("does not leak a value into a sibling screen bound to the same field name", () => {
    class SameNameBody extends React.Component<IScreenProps> {
      render() {
        return (
          <Form form={this.props.form} name="basic" component={false} initialValues={{ shared_value: "" }}>
            <Form.Item name="shared_value">
              <input data-testid={`${this.props.screenName}-shared`} />
            </Form.Item>
          </Form>
        );
      }
    }
    const SameNameScreen = withForm(SameNameBody);

    class SameNameWrapper extends TestWrapper {
      protected renderSwitchWrapper(): React.ReactNode {
        return (
          <Switch>
            <Route
              exact
              path="/tst"
              render={() => (
                <>
                  <SameNameScreen screenName="tst" />
                  <NavButton to="/homepage" testId="to-homepage" />
                </>
              )}
            />
            <Route
              exact
              path="/homepage"
              render={() => (
                <>
                  <SameNameScreen screenName="homepage" />
                  <NavButton to="/tst" testId="to-tst" />
                </>
              )}
            />
          </Switch>
        );
      }
    }

    renderMasterGroup(SameNameWrapper);

    fireEvent.change(screen.getByTestId("tst-shared"), { target: { value: "from tst" } });
    fireEvent.click(screen.getByTestId("to-homepage"));

    expect(screen.getByTestId("homepage-shared")).toHaveValue("");
  });

  // KOA-8559: an overlay host swaps its visible child in place instead of routing. That
  // swap must scope the form the same way a route swap does.
  describe("inline overlay host", () => {
    let capturedOverlayNav: IInlineOverlayNav | null = null;

    const OverlayNavCapture: React.FC = () => {
      capturedOverlayNav = React.useContext(InlineOverlayNavContext);
      return null;
    };

    const OverlayMasterBody: React.FC<IMasterBodyProps> = (props) => (
      <>
        <OverlayNavCapture />
        <div data-testid="master">{props.children}</div>
      </>
    );

    class OverlayHostWrapper extends MasterScreenWrapper {
      protected get anonymousPaths(): string[] {
        return [];
      }

      protected get MasterComponent(): React.ComponentType<IMasterBodyProps> {
        return OverlayMasterBody;
      }

      protected get MasterProvider(): React.ComponentType<{ children?: React.ReactNode }> {
        return MockProvider;
      }

      protected get forceReady(): boolean {
        return true;
      }

      protected get overlayScreenNames(): string[] | null {
        return ["orders"];
      }

      protected renderOverlayScreen(
        screenName: string,
        _screenInputs: Record<string, unknown>,
        onClose: () => void
      ): React.ReactNode {
        return (
          <>
            <ChildScreen screenName={screenName} />
            <button type="button" data-testid="overlay-close" onClick={onClose} />
          </>
        );
      }

      protected renderSwitchWrapper(): React.ReactNode {
        return <ChildScreen screenName="tst" />;
      }
    }

    beforeEach(() => {
      capturedOverlayNav = null;
    });

    it("starts the pushed overlay screen with an empty form, and the screen it returns to too", () => {
      render(<OverlayHostWrapper />);

      fireEvent.change(screen.getByTestId("tst-input"), { target: { value: "typed in the overlay" } });

      act(() => {
        capturedOverlayNav?.push("orders", {});
      });

      expect(screen.getByTestId("orders-input")).toHaveValue("");
      expect(screen.queryByTestId("tst-input")).toBeNull();

      fireEvent.click(screen.getByTestId("overlay-close"));

      expect(screen.getByTestId("tst-input")).toHaveValue("");
    });
  });
});
