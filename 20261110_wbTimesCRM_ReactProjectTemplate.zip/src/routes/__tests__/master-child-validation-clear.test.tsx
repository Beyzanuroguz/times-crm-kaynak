import "@testing-library/jest-dom";
import { act, render } from "@testing-library/react";
import React from "react";
import { MemoryRouter, Route, Switch } from "react-router-dom";

// KOA-18186. The bug: with a required master-header field showing its validation error
// (set by the master's own button), a SUCCESSFUL save on the child screen left that
// error on screen indefinitely. KOA-17999 gave master and child separate form scopes,
// so the child's validation run — which is the only thing that runs on save — had no
// handle to the master's form and could never clear its stale errors. The fix links the
// child scope back to the master scope (parentForm) and makes handleValidations clear
// the master's stale errors when the child's run passes. These tests exercise the real
// antd form store semantics, so the global antd/es stub is re-mocked onto rc-field-form
// exactly like master-child-form-scope.test.tsx (KOA-17999) does.
jest.mock("antd/es", () => {
  const ReactActual = jest.requireActual("react");
  const rcFieldForm = jest.requireActual("rc-field-form");
  const FormShim = (props: unknown) => ReactActual.createElement(rcFieldForm.default, props);
  FormShim.useForm = rcFieldForm.useForm;
  FormShim.Item = rcFieldForm.Field;
  return { Form: FormShim };
});

/* eslint-disable import/first */
import { Form } from "antd/es";
import type { FormInstance } from "antd/es/form";
import { IValidationData } from "../../models/dto/validation-data";
import { withForm } from "../../shared/hoc/with-form";
import { KuikaAppManager } from "../../shared/utilty/kuika-app-manager";
import { MasterScreenWrapper } from "../master-screen-wrapper";
/* eslint-enable import/first */

interface ICapturedScreenForms {
  form: FormInstance | null;
  parentForm: FormInstance | null;
}

interface IScreenProps {
  form?: FormInstance;
  parentForm?: FormInstance | null;
  screenName: string;
}

interface IMasterBodyProps extends IScreenProps {
  children?: React.ReactNode;
}

const capturedMaster: ICapturedScreenForms = { form: null, parentForm: null };
const capturedChild: ICapturedScreenForms = { form: null, parentForm: null };

// Mirrors what React_UIGenerator emits for a MASTER screen: a real <form> element bound
// to props.form, the routed child rendered inside it. MasterSearch stands in for the
// required master-header field of the ticket.
class MasterBody extends React.Component<IMasterBodyProps> {
  render() {
    capturedMaster.form = this.props.form ?? null;
    capturedMaster.parentForm = this.props.parentForm ?? null;
    return (
      <Form form={this.props.form} name="basic" initialValues={{ master_search_value: "" }}>
        <Form.Item name="master_search_value">
          <input data-testid="master-search" />
        </Form.Item>
        <div data-testid="master">{this.props.children}</div>
      </Form>
    );
  }
}

// Mirrors a CHILD screen: its own <Form> bound to props.form with component={false}
// (KOA-17205). Soyad stands in for the child field the save validates.
class ChildScreenBody extends React.Component<IScreenProps> {
  render() {
    capturedChild.form = this.props.form ?? null;
    capturedChild.parentForm = this.props.parentForm ?? null;
    return (
      <Form form={this.props.form} name="basic" component={false} initialValues={{ tst_soyad_value: "" }}>
        <Form.Item name="tst_soyad_value">
          <input data-testid="soyad-input" />
        </Form.Item>
      </Form>
    );
  }
}

const MockMaster = withForm(MasterBody);
const ChildScreen = withForm(ChildScreenBody);
const MockProvider: React.FC<{ children?: React.ReactNode }> = ({ children }) => <>{children}</>;

class TestWrapper extends MasterScreenWrapper {
  protected get anonymousPaths(): string[] {
    return [];
  }

  protected get MasterComponent(): React.ComponentType<IMasterBodyProps> {
    return MockMaster;
  }

  protected get MasterProvider(): React.ComponentType<{ children?: React.ReactNode }> {
    return MockProvider;
  }

  protected get forceReady(): boolean {
    return true;
  }

  protected renderSwitchWrapper(): React.ReactNode {
    return (
      <Switch>
        <Route exact path="/tst" render={() => <ChildScreen screenName="tst" />} />
      </Switch>
    );
  }
}

interface IScreenStub {
  props: { form: FormInstance; parentForm: FormInstance | null };
  state: { spinnerCount: number };
  setState: jest.Mock;
}

// handleValidations touches screen.props.form / screen.props.parentForm and, on a
// failing run, hideSpinner(screen) → screen.setState. This is the whole surface the
// generated screen class exposes to it.
const screenStub = (form: FormInstance | null, parentForm: FormInstance | null): IScreenStub => ({
  props: { form: form as FormInstance, parentForm },
  state: { spinnerCount: 0 },
  setState: jest.fn()
});

const validation = (formName: string, message: string, isValid: boolean): IValidationData => ({
  isValid,
  condition: true,
  message,
  formName
});

const fieldErrors = (form: FormInstance | null, name: string): string[] => {
  const entry = form?.getFieldsError().find((f) => f.name.length === 1 && f.name[0] === name);
  return entry ? entry.errors : [];
};

const MASTER_ERROR = "Master arama alanı zorunludur";
const CHILD_ERROR = "Soyad alanı zorunludur";

// Reproduces the master button's failing run: MasterSearch empty + required.
const showMasterError = (): void => {
  const masterScreen: IScreenStub = screenStub(capturedMaster.form, capturedMaster.parentForm);
  act(() => {
    expect(
      KuikaAppManager.handleValidations(masterScreen, [validation("master_search_value", MASTER_ERROR, false)])
    ).toBe(true);
  });
  expect(fieldErrors(capturedMaster.form, "master_search_value")).toEqual([MASTER_ERROR]);
};

const renderMasterGroup = () =>
  render(
    <MemoryRouter initialEntries={["/tst"]}>
      <Switch>
        <Route
          path={["/tst"]}
          render={(routeProps) => <TestWrapper location={{ pathname: routeProps.location.pathname }} />}
        />
      </Switch>
    </MemoryRouter>
  );

describe("master/child stale validation error clearing (KOA-18186)", () => {
  beforeEach(() => {
    capturedMaster.form = null;
    capturedMaster.parentForm = null;
    capturedChild.form = null;
    capturedChild.parentForm = null;
  });

  it("links the child scope to the master's form and leaves the master scope unlinked", () => {
    renderMasterGroup();

    expect(capturedChild.form).not.toBeNull();
    expect(capturedMaster.form).not.toBeNull();
    expect(capturedChild.form).not.toBe(capturedMaster.form);
    // The directional link of the fix: child sees the master's form as parentForm...
    expect(capturedChild.parentForm).toBe(capturedMaster.form);
    // ...while the master chrome has no handle to any child form.
    expect(capturedMaster.parentForm).toBeNull();
  });

  it("clears the master's stale error when the child's validation run passes (the ticket)", () => {
    renderMasterGroup();
    showMasterError();

    // Kaydet: the child's own validation passes (Soyad filled), save proceeds.
    const childScreen: IScreenStub = screenStub(capturedChild.form, capturedChild.parentForm);
    let hasError = true;
    act(() => {
      hasError = KuikaAppManager.handleValidations(childScreen, [validation("tst_soyad_value", CHILD_ERROR, true)]);
    });

    expect(hasError).toBe(false);
    expect(fieldErrors(capturedMaster.form, "master_search_value")).toEqual([]);
  });

  it("does not touch the master's field VALUE when clearing its stale error", () => {
    renderMasterGroup();
    act(() => {
      capturedMaster.form?.setFieldsValue({ master_search_value: "deneme" });
    });
    showMasterError();

    const childScreen: IScreenStub = screenStub(capturedChild.form, capturedChild.parentForm);
    act(() => {
      KuikaAppManager.handleValidations(childScreen, [validation("tst_soyad_value", CHILD_ERROR, true)]);
    });

    expect(fieldErrors(capturedMaster.form, "master_search_value")).toEqual([]);
    expect(capturedMaster.form?.getFieldValue("master_search_value")).toBe("deneme");
  });

  it("keeps the master's error while the child's own run still fails", () => {
    renderMasterGroup();
    showMasterError();

    // Kaydet with Soyad empty: the child shows its own error; the page legitimately
    // displays both — nothing completed successfully yet.
    const childScreen: IScreenStub = screenStub(capturedChild.form, capturedChild.parentForm);
    let hasError = false;
    act(() => {
      hasError = KuikaAppManager.handleValidations(childScreen, [validation("tst_soyad_value", CHILD_ERROR, false)]);
    });

    expect(hasError).toBe(true);
    expect(fieldErrors(capturedChild.form, "tst_soyad_value")).toEqual([CHILD_ERROR]);
    expect(fieldErrors(capturedMaster.form, "master_search_value")).toEqual([MASTER_ERROR]);
  });

  it("does not clear the master's error on a child run that validated nothing", () => {
    // EVERY generated handler calls handleValidations — the template always declares
    // `let validations = []` — so PageInit, navigate buttons and other validation-less
    // actions all reach it with an empty array. Those runs completed nothing the user
    // asked to validate; they must not wipe the master's error as a click side effect.
    renderMasterGroup();
    showMasterError();

    const childScreen: IScreenStub = screenStub(capturedChild.form, capturedChild.parentForm);
    let hasError = true;
    act(() => {
      hasError = KuikaAppManager.handleValidations(childScreen, []);
    });

    expect(hasError).toBe(false);
    expect(fieldErrors(capturedMaster.form, "master_search_value")).toEqual([MASTER_ERROR]);
  });

  it("never lets a master run clear the child's error (KOA-17999 S7 isolation)", () => {
    renderMasterGroup();

    // Child shows its own error first (Kaydet with Soyad empty).
    const childScreen: IScreenStub = screenStub(capturedChild.form, capturedChild.parentForm);
    act(() => {
      KuikaAppManager.handleValidations(childScreen, [validation("tst_soyad_value", CHILD_ERROR, false)]);
    });
    expect(fieldErrors(capturedChild.form, "tst_soyad_value")).toEqual([CHILD_ERROR]);

    // Master Ara with MasterSearch filled: the master's run passes — it must not reach
    // into the child scope.
    const masterScreen: IScreenStub = screenStub(capturedMaster.form, capturedMaster.parentForm);
    act(() => {
      KuikaAppManager.handleValidations(masterScreen, [validation("master_search_value", MASTER_ERROR, true)]);
    });

    expect(fieldErrors(capturedChild.form, "tst_soyad_value")).toEqual([CHILD_ERROR]);
  });

  it("is a no-op for a screen with no enclosing master scope", () => {
    // A master-less screen mounts outside any FormScope: withForm hands it a local form
    // and a null parentForm. The passing run must not throw and must clear only its own
    // listed fields.
    const standaloneCapture: ICapturedScreenForms = { form: null, parentForm: null };

    class StandaloneBody extends React.Component<IScreenProps> {
      render() {
        standaloneCapture.form = this.props.form ?? null;
        standaloneCapture.parentForm = this.props.parentForm ?? null;
        return (
          <Form form={this.props.form} name="basic" initialValues={{ lone_value: "" }}>
            <Form.Item name="lone_value">
              <input data-testid="lone-input" />
            </Form.Item>
          </Form>
        );
      }
    }
    const StandaloneScreen = withForm(StandaloneBody);
    render(<StandaloneScreen screenName="lone" />);

    expect(standaloneCapture.parentForm).toBeNull();

    const loneScreen: IScreenStub = screenStub(standaloneCapture.form, standaloneCapture.parentForm);
    let hasError = true;
    act(() => {
      hasError = KuikaAppManager.handleValidations(loneScreen, [validation("lone_value", "x", true)]);
    });
    expect(hasError).toBe(false);
  });

  it("clears every stale master error, not just the first, when the child run passes", () => {
    // Two master-header fields errored by one master run; a successful child save must
    // sweep them both.
    class TwoFieldMasterBody extends React.Component<IMasterBodyProps> {
      render() {
        capturedMaster.form = this.props.form ?? null;
        capturedMaster.parentForm = this.props.parentForm ?? null;
        return (
          <Form
            form={this.props.form}
            name="basic"
            initialValues={{ master_search_value: "", master_filter_value: "" }}
          >
            <Form.Item name="master_search_value">
              <input data-testid="master-search" />
            </Form.Item>
            <Form.Item name="master_filter_value">
              <input data-testid="master-filter" />
            </Form.Item>
            <div data-testid="master">{this.props.children}</div>
          </Form>
        );
      }
    }
    const TwoFieldMaster = withForm(TwoFieldMasterBody);

    class TwoFieldWrapper extends TestWrapper {
      protected get MasterComponent(): React.ComponentType<IMasterBodyProps> {
        return TwoFieldMaster;
      }
    }

    render(
      <MemoryRouter initialEntries={["/tst"]}>
        <Switch>
          <Route
            path={["/tst"]}
            render={(routeProps) => <TwoFieldWrapper location={{ pathname: routeProps.location.pathname }} />}
          />
        </Switch>
      </MemoryRouter>
    );

    const masterScreen: IScreenStub = screenStub(capturedMaster.form, capturedMaster.parentForm);
    act(() => {
      KuikaAppManager.handleValidations(masterScreen, [
        validation("master_search_value", MASTER_ERROR, false),
        validation("master_filter_value", "Filtre zorunludur", false)
      ]);
    });
    expect(fieldErrors(capturedMaster.form, "master_search_value")).toEqual([MASTER_ERROR]);
    expect(fieldErrors(capturedMaster.form, "master_filter_value")).toEqual(["Filtre zorunludur"]);

    const childScreen: IScreenStub = screenStub(capturedChild.form, capturedChild.parentForm);
    act(() => {
      KuikaAppManager.handleValidations(childScreen, [validation("tst_soyad_value", CHILD_ERROR, true)]);
    });

    expect(fieldErrors(capturedMaster.form, "master_search_value")).toEqual([]);
    expect(fieldErrors(capturedMaster.form, "master_filter_value")).toEqual([]);
  });
});
