import { spawnSync, SpawnSyncReturns } from "child_process";
import * as fs from "fs";
import * as os from "os";
import * as path from "path";

/**
 * env.sh is the container bootstrap the generated Dockerfile runs before nginx: it
 * rebuilds env-config.js / env-config.json from the container environment. Until it
 * learned to read env.kuika it truncated everything the code generator had put into
 * the build's env-config.js (MAP_PROVIDER, AMAP_*, GOOGLE_MAPS_KEY, RECAPTCHA_SITE_KEY),
 * so an exported Amap project came up on Google Maps on the customer's own server.
 *
 * The script only ever runs in a Linux container, so this test needs a POSIX `sh` and
 * is skipped on Windows; it runs on the macOS/Linux developers' machines and in CI.
 */
interface EnvShRun {
  readonly status: number | null;
  readonly stderr: string;
  readonly js: string;
  readonly json: string;
  readonly windowEnv: Record<string, string>;
  readonly parsedJson: Record<string, string>;
}

const ENV_SH_PATH: string = path.resolve(__dirname, "..", "..", "env.sh");

function runEnvSh(envKuika: string | null, containerEnv: Record<string, string>): EnvShRun {
  const workDir: string = fs.mkdtempSync(path.join(os.tmpdir(), "kuika-env-sh-"));
  try {
    if (envKuika !== null) {
      fs.writeFileSync(path.join(workDir, "env.kuika"), envKuika, "utf8");
    }
    // PATH only: the script must see exactly the variables the test hands it.
    const env: Record<string, string> = { PATH: process.env.PATH ?? "", ...containerEnv };
    const result: SpawnSyncReturns<string> = spawnSync("sh", [ENV_SH_PATH], {
      cwd: workDir,
      env,
      encoding: "utf8"
    });
    const js: string = fs.readFileSync(path.join(workDir, "env-config.js"), "utf8");
    const json: string = fs.readFileSync(path.join(workDir, "env-config.json"), "utf8");
    const windowStub: { _env_?: Record<string, string> } = {};
    new Function("window", js)(windowStub);
    const parsedJson: Record<string, string> = JSON.parse(json) as Record<string, string>;
    return {
      status: result.status,
      stderr: result.stderr,
      js,
      json,
      windowEnv: windowStub._env_ ?? {},
      parsedJson
    };
  } finally {
    fs.rmSync(workDir, { recursive: true, force: true });
  }
}

const describeOnPosix: jest.Describe = process.platform === "win32" ? describe.skip : describe;

describeOnPosix("env.sh", () => {
  it("keeps the code generator's env.kuika defaults when the container sets nothing", () => {
    const run: EnvShRun = runEnvSh(
      "# written by codegen\nMAP_PROVIDER=Amap\nAMAP_KEY=key-1\nAMAP_SECURITY_JS_CODE=\n",
      {}
    );

    expect(run.status).toBe(0);
    expect(run.stderr).toBe("");
    expect(run.windowEnv).toEqual({
      MAP_PROVIDER: "Amap",
      AMAP_KEY: "key-1",
      AMAP_SECURITY_JS_CODE: ""
    });
  });

  it("lets a container env var override a build-time value, and writes both files identically", () => {
    const run: EnvShRun = runEnvSh("MAP_PROVIDER=Amap\nAMAP_KEY=build-time\nRECAPTCHA_SITE_KEY=from-file\n", {
      BACKEND_URL: "https://api.example.com",
      AMAP_KEY: "from-container"
    });

    expect(run.status).toBe(0);
    expect(run.windowEnv).toEqual({
      BACKEND_URL: "https://api.example.com",
      MAP_PROVIDER: "Amap",
      AMAP_KEY: "from-container",
      RECAPTCHA_SITE_KEY: "from-file"
    });
    expect(run.parsedJson).toEqual(run.windowEnv);
  });

  it("never writes a key twice when the container and env.kuika both carry it", () => {
    const run: EnvShRun = runEnvSh("RECAPTCHA_SITE_KEY=from-file\n", {
      RECAPTCHA_SITE_KEY: "from-container"
    });

    expect(run.windowEnv).toEqual({ RECAPTCHA_SITE_KEY: "from-container" });
    expect(run.js.match(/RECAPTCHA_SITE_KEY/g)).toHaveLength(1);
    expect(run.json.match(/RECAPTCHA_SITE_KEY/g)).toHaveLength(1);
  });

  it("behaves as before when there is no env.kuika", () => {
    const run: EnvShRun = runEnvSh(null, { BACKEND_URL: "https://api.example.com" });

    expect(run.status).toBe(0);
    expect(run.windowEnv).toEqual({ BACKEND_URL: "https://api.example.com" });
    expect(run.parsedJson).toEqual(run.windowEnv);
  });

  it("tolerates CRLF, comments, blank and malformed lines and keeps '=' inside values", () => {
    const run: EnvShRun = runEnvSh(
      "# comment\r\n\r\nMAP_PROVIDER=Amap\r\nAMAP_GEOCODING_BACKEND_REASON=no key = missing\r\nno-equals\r\nbad-key=x\r\n1STARTS_WITH_DIGIT=y\r\n",
      {}
    );

    expect(run.status).toBe(0);
    expect(run.windowEnv).toEqual({
      MAP_PROVIDER: "Amap",
      AMAP_GEOCODING_BACKEND_REASON: "no key = missing"
    });
    expect(run.js).not.toContain("\r");
  });
});
