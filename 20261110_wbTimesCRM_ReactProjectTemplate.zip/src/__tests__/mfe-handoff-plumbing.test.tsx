/**
 * The attribute a third-party host sets on <kuika-mfe-app> has to survive four
 * hops before it means anything: remount → web-component-init → bootstrapper →
 * (kuika-auth-app → router) → mfe-login. Every hop is a hand-written prop pass,
 * and a dropped one fails silently — the app renders, no request is made, and the
 * user sits on the login screen. The unit tests around MfeLogin and mfe-handoff
 * both start *after* those hops, so this file covers the hops themselves.
 *
 * `kuika-auth-app` is stubbed: importing it pulls the whole component library
 * (router → agent-frame → web-components → kuika/index), which the deliberately
 * minimal antd mock cannot satisfy. The stub records what the bootstrapper hands
 * down, so the hop is still asserted; the two hops below it (kuika-auth-app →
 * router → mfe-login) are literal pass-throughs covered by the live run.
 */
import { render, waitFor } from "@testing-library/react";

interface IStubbedAuthAppProps {
  external_provider_type?: string;
  external_access_token?: string;
  external_user?: string;
  external_refresh_token?: string;
}

let authAppProps: IStubbedAuthAppProps | null = null;

jest.mock("../app-types/kuika-auth-app", () => ({
  __esModule: true,
  default: (props: IStubbedAuthAppProps) => {
    authAppProps = props;
    return <div data-testid="auth-app" />;
  }
}));

jest.mock("../components/web-components/twin-dashboard/twin-chat-widget", () => ({
  TwinChatWidget: () => null
}));

jest.mock("../auth/mfe-handoff", () => ({
  redeemMfeHandoff: jest.fn(() => Promise.resolve({ succeeded: true, errorMessage: "" })),
  peekMfeHandoff: jest.fn(() => null),
  forgetMfeHandoff: jest.fn(),
  resetMfeHandoffState: jest.fn()
}));

jest.mock("../shared/utilty/kuika-app-manager", () => ({
  KuikaAppManager: {
    readLoginStateCookie: jest.fn(() => null),
    getLoginStateCookieKey: jest.fn(() => "test"),
    GetBackendUrl: jest.fn(() => "https://api.test.invalid/v1/api"),
    GetFrontEndSourceUrl: jest.fn(() => "https://app.test.invalid")
  }
}));

import { IMfeHandoffRequest, redeemMfeHandoff } from "../auth/mfe-handoff";
import { AppBootstrapper, IBootStrapperProps } from "../bootstrapper";
import { MFE_WEB_COMPONENT_ATTRIBUTES } from "../web-component-init";

const TOKEN: string = `${btoa(JSON.stringify({ alg: "HS256" }))}.${btoa(JSON.stringify({ UserName: "u" }))}.sig`;

const renderBootstrapper = (overrides: Partial<IBootStrapperProps>) =>
  render(
    <AppBootstrapper
      authType="Kuika"
      routerType="HashRouter"
      appMode="WebComponent"
      tagName="kuika-mfe-app"
      {...overrides}
    />
  );

describe("MFE handoff plumbing", () => {
  beforeEach(() => {
    jest.clearAllMocks();
    authAppProps = null;
    (redeemMfeHandoff as jest.Mock).mockResolvedValue({ succeeded: true, errorMessage: "" });
  });

  it("registers every attribute the bootstrapper reads — remount drops the rest", () => {
    // remount builds props by reducing over this exact array. An external_* prop
    // the bootstrapper consumes but that is missing here arrives as undefined.
    expect(MFE_WEB_COMPONENT_ATTRIBUTES).toEqual(
      expect.arrayContaining([
        "external_user",
        "external_access_token",
        "external_refresh_token",
        "external_provider_type",
        "starting_screen"
      ])
    );
  });

  it("carries the provider slot from the host attribute into the exchange", async () => {
    renderBootstrapper({
      external_access_token: TOKEN,
      external_provider_type: "External1",
      external_user: "user@example.com",
      external_refresh_token: "rt"
    });

    await waitFor(() => expect(redeemMfeHandoff).toHaveBeenCalledTimes(1));
    const request: IMfeHandoffRequest = (redeemMfeHandoff as jest.Mock).mock.calls[0][0];
    expect(request).toEqual({
      accessToken: TOKEN,
      providerTypeName: "External1",
      username: "user@example.com",
      refreshToken: "rt"
    });
  });

  it("hands the slot down to the next hop, not just to the exchange", async () => {
    // kuika-auth-app forwards this to Router, which forwards it to MfeLogin — the
    // /login fallback when redemption fails and PrivateRoute bounces.
    renderBootstrapper({
      external_access_token: TOKEN,
      external_provider_type: "External3",
      external_user: "user@example.com"
    });

    await waitFor(() => expect(authAppProps).not.toBeNull());
    expect(authAppProps?.external_provider_type).toBe("External3");
    expect(authAppProps?.external_access_token).toBe(TOKEN);
    expect(authAppProps?.external_user).toBe("user@example.com");
  });

  it("holds the route tree back until the exchange settles", async () => {
    let settle: (value: { succeeded: boolean; errorMessage: string }) => void = () => undefined;
    (redeemMfeHandoff as jest.Mock).mockReturnValue(
      new Promise((resolve) => {
        settle = resolve;
      })
    );

    const view = renderBootstrapper({
      external_access_token: TOKEN,
      external_provider_type: "External1"
    });

    // Nothing may render while the app's backend has no session: a screen's
    // componentDidMount would fire API calls into a 401 and bounce to /login.
    expect(view.container).toBeEmptyDOMElement();

    settle({ succeeded: true, errorMessage: "" });
    await waitFor(() => expect(view.container).not.toBeEmptyDOMElement());
  });

  it("does not exchange anything when the host passes no token", async () => {
    renderBootstrapper({ external_provider_type: "External1" });

    await waitFor(() => expect(redeemMfeHandoff).not.toHaveBeenCalled());
  });

  it("ignores a provider slot the whitelist does not know", async () => {
    renderBootstrapper({ external_access_token: TOKEN, external_provider_type: "__proto__" });

    await waitFor(() => expect(redeemMfeHandoff).not.toHaveBeenCalled());
  });

  it("exchanges a host token even when a previous user's session cookie is present", async () => {
    const { KuikaAppManager } = jest.requireMock("../shared/utilty/kuika-app-manager");
    (KuikaAppManager.readLoginStateCookie as jest.Mock).mockReturnValue("1");

    renderBootstrapper({ external_access_token: TOKEN, external_provider_type: "External1" });

    await waitFor(() => expect(redeemMfeHandoff).toHaveBeenCalledTimes(1));
  });
});
