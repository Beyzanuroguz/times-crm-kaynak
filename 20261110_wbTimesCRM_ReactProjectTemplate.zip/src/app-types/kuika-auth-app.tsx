import { ConfigProvider } from "antd/es";
import * as React from "react";
import { memo } from "react";
import PWAPrompt from "react-ios-pwa-prompt";
import { ReactNotifications } from "react-notifications-component";
import "react-notifications-component/dist/theme.css";
import { Provider } from "react-redux";
import "../auth/interceptors";
import { IAppMode, IAuthType } from "../bootstrapper";
import configureStore from "../redux/root-reducer";
import { IRouterType, Router } from "../routes/router";
import { reshowPendingUpdateNotice } from "../services/app-update-service";
import { ReactSystemFunctions } from "../shared/utilty/react-system-functions";

const store = configureStore();

interface IAppProps {
  routerType?: IRouterType;
  authType?: IAuthType;
  external_access_token?: string;
  external_refresh_token?: string;
  external_user?: string;
  external_provider_type?: string;
  startingScreen?: string;
  appMode?: IAppMode;
  [key: `screenInput_${string}`]: unknown;
}

// Rendered right after <ReactNotifications />, inside the same Suspense
// boundary, so its effect runs once the notification layer has registered
// itself with the store. An embedded micro app's root mounts every time the
// user enters a screen that shows it, so a "new version" notice raised while
// they were elsewhere gets its chance to render here (KOA-18736). No-op when
// nothing is pending or the strip is already on screen.
const PendingUpdateNoticeOnMount = (): null => {
  React.useEffect((): void => {
    reshowPendingUpdateNotice();
  }, []);
  return null;
};

const KuikaAuthApp = (props: IAppProps) => {
  let { authType } = props;
  if (authType == undefined) {
    authType = "Kuika";
  }

  // Extract only screenInput_* props safely
  const screenInputProps = {};
  Object.keys(props).forEach((key) => {
    if (key.startsWith("screenInput_")) {
      screenInputProps[key] = props[key];
    }
  });

  return (
    <>
      {/* <React.StrictMode> */}
      <React.Suspense fallback="Loading...">
        <Provider store={store}>
          <ReactNotifications />
          <PendingUpdateNoticeOnMount />
          <ConfigProvider locale={ReactSystemFunctions.getLocale()}>
            <PWAPrompt
              copyBody="This website has app functionality. Add it to your home screen to use it in fullscreen"
              copyClosePrompt="Close"
              permanentlyHideOnDismiss
            />
            <Router
              authType={authType}
              routerType={props.routerType}
              appMode={props.appMode}
              external_user={props.external_user}
              external_access_token={props.external_access_token}
              external_refresh_token={props.external_refresh_token}
              external_provider_type={props.external_provider_type}
              startingScreen={props.startingScreen}
              {...screenInputProps}
            />
          </ConfigProvider>
        </Provider>
      </React.Suspense>
      {/* </React.StrictMode> */}
    </>
  );
};

export default memo(KuikaAuthApp);
