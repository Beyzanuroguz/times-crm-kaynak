window._env_ = {
  ENV_TEST: "ENV_TEST_SAMPLE",
  GOOGLE_MAPS_KEY: "AIzaSyD8rAUvoq78UQ-hhBivIreESvzu-oEb7uw"
};
