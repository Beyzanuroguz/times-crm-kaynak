function CreateKuikaMfeApp(appConfig) {
  if (!appConfig || !appConfig.frontEndUrl) {
    console.log(
      'CreateKuikaMfeApp function parameter field format should be like "{ frontEndUrl: "https://localhost/virtualdirectory"}, { frontEndUrl: "https://localhost:port"}, "https://YourMicroFrontendApp.com"} etc.'
    );
    return;
  }
  if (appConfig.frontEndUrl.endsWith("/") === true || appConfig.frontEndUrl.endsWith("\\") === true) {
    appConfig.frontEndUrl = appConfig.frontEndUrl.slice(0, -1);
  }
  appConfig.frontEndUrl = appConfig.frontEndUrl + "/";
  const frontEndUrl = appConfig.frontEndUrl;
  const manifestPath = frontEndUrl + "asset-manifest.json";
  fetch(manifestPath)
    .then((response) => response.json())
    .then((manifest) => {
      AddDynamicKuikaStyleToHeader();
      if (window.kuika === undefined) {
        window.kuika = {};
      }
      if (window.kuika?.apps === undefined) {
        window.kuika.apps = [];
      }
      let updated = false;
      window.kuika?.apps.forEach((app) => {
        if (app?.appConfig?.frontEndUrl === frontEndUrl) {
          updated = true;
          app.manifest = manifest;
        }
      });
      if (updated === false) {
        window.kuika?.apps.push({ appConfig, manifest });
        MountApp(appConfig, manifest);
      }
    });
}

function MountApp(appConfig, manifest) {
  const frontEndUrl = appConfig.frontEndUrl;
  // Security: entry scripts must be same-origin as the manifest's frontEndUrl.
  var expectedOrigin = new URL(frontEndUrl, window.location.origin).origin;
  manifest?.entryFiles?.index?.js?.forEach((file) => {
    const path = frontEndUrl + file;
    AddScriptToHeader(path, true, { expectedOrigin: expectedOrigin });
  });
  manifest?.entryFiles?.index?.css?.forEach((file) => {
    const path = frontEndUrl + file;
    AddlinkToHeader(path, "stylesheet");
  });
  manifest?.entryFiles?.index?.ico?.forEach((file) => {
    const path = frontEndUrl + file;
    AddlinkToHeader(path, "icon", "image/png");
    AddlinkToHeader(path, "apple-touch-icon");
  });
  manifest?.entryFiles?.index?.url_3rd_js?.forEach((url) => {
    AddScriptToHeader(url, false, { allowThirdParty: true });
  });
}

function AddScriptToHeader(src, force, policy) {
  // Security: validate script URL to prevent code injection from compromised manifests.
  // Entry scripts must match the manifest origin (expectedOrigin); intentionally-external
  // third-party scripts must be https; everything else must be same-origin as the host.
  try {
    var parsedUrl = new URL(src, window.location.origin);
    if (parsedUrl.protocol !== "https:" && parsedUrl.protocol !== "http:") {
      console.error("MFE: Blocked script with disallowed protocol:", src);
      return;
    }
    var pol = policy || {};
    if (pol.expectedOrigin) {
      if (parsedUrl.origin !== pol.expectedOrigin) {
        console.error("MFE: Blocked cross-origin script:", src);
        return;
      }
    } else if (pol.allowThirdParty) {
      if (
        parsedUrl.protocol !== "https:" &&
        parsedUrl.hostname !== "localhost" &&
        parsedUrl.hostname !== "127.0.0.1"
      ) {
        console.error("MFE: Blocked insecure third-party script:", src);
        return;
      }
    } else if (parsedUrl.origin !== window.location.origin) {
      console.error("MFE: Blocked untrusted script:", src);
      return;
    }
  } catch (e) {
    console.error("MFE: Blocked invalid script URL:", src);
    return;
  }

  const scriptList = getScripts();
  var fileName = this.getFileNameFromSrc(src);
  const currentSrcipt = scriptList.find((s) => s === fileName);
  if (!currentSrcipt || force === true) {
    let script = document.createElement("script");
    script.src = src;
    script.crossorigin = "anonymous";
    script.referrerpolicy = "no-referrer";
    script.charset = "UTF-8";
    document.head.appendChild(script);
  }
}

function AddlinkToHeader(href, rel, type, force) {
  const linkList = getLinks();
  var fileName = this.getFileNameFromSrc(href);
  const currentLink = linkList.find((s) => s === fileName);
  if (!currentLink || force === true) {
    let link = document.createElement("link");
    if (type) link.type = type;
    link.rel = rel;
    link.href = href;
    link.crossorigin = "anonymous";
    document.head.appendChild(link);
  }
}

function AddDynamicKuikaStyleToHeader() {
  let dynamic_style = document.getElementById("dynamic_style");
  if (!dynamic_style) {
    let style = document.createElement("style");
    style.id = "dynamic_style";
    style.rel = "stylesheet";
    document.head.appendChild(style);
  }
}

function getLinks() {
  let linkElements = document.getElementsByTagName("link");
  let linkList = [];
  for (let i = 0; i < linkElements.length; i++) {
    let linkAttribute = linkElements[i].getAttribute("src");
    if (linkAttribute && linkAttribute !== "") {
      var linkFileName = getFileNameFromSrc(linkAttribute);
      linkList.push(linkFileName);
    }
  }
  return linkList;
}

function getScripts() {
  let scriptElements = document.getElementsByTagName("script");
  let scriptList = [];
  for (let i = 0; i < scriptElements.length; i++) {
    let srcAttribute = scriptElements[i].getAttribute("src");
    if (srcAttribute && srcAttribute !== "") {
      var scriptFileName = getFileNameFromSrc(srcAttribute);
      scriptList.push(scriptFileName);
    }
  }
  return scriptList;
}

function getFileNameFromSrc(src) {
  var scriptFileName = src.substring(src.lastIndexOf("/") + 1);
  return scriptFileName;
}
