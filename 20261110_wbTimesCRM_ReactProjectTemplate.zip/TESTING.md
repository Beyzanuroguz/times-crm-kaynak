# Testing Guide

This project uses Jest and React Testing Library for unit testing.

## Setup

The testing dependencies are already configured in `package.json`. To install them, run:

```bash
npm install
# or
yarn install
```

## Running Tests

### Run all tests

```bash
npm test
# or
yarn test
```

### Run tests in watch mode

```bash
npm run test:watch
# or
yarn test:watch
```

### Run tests with coverage

```bash
npm run test:coverage
# or
yarn test:coverage
```

## Test Structure

Tests are located alongside the components they test, following the naming convention:

- `ComponentName.test.tsx` for component tests
- `ComponentName.spec.tsx` for specification tests

## Example Test

The Button component test (`src/components/web-components/button/button.test.tsx`) demonstrates:

- Basic rendering tests
- Props validation
- Event handling
- Style application
- Icon positioning
- Edge cases
- Complex scenarios

## Testing Utilities

- **Jest**: Test runner and assertion library
- **React Testing Library**: Testing utilities for React components
- **@testing-library/jest-dom**: Additional matchers for DOM testing
- **@testing-library/user-event**: User interaction simulation

## Best Practices

1. Test behavior, not implementation details
2. Use descriptive test names
3. Group related tests with `describe` blocks
4. Mock external dependencies
5. Test edge cases and error conditions
6. Maintain good test coverage
