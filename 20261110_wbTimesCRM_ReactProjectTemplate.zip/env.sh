#!/bin/sh
# line endings must be \n, not \r\n !
#
# Materializes the app's runtime config into the two files the app reads. They
# carry the SAME values in two shapes, and both are required:
#
#   env-config.js    the PAGE's config — a <script> that assigns the single
#                    window-scoped `window._env_`. Only the app that OWNS the
#                    document can consume it.
#   env-config.json  the same values in fetchable form. A microapp is not a page:
#                    it is a bundle injected into the HOST's document, so it can
#                    never load its own env-config.js and used to inherit the
#                    host's `window._env_` — reading the parent's BACKEND_URL and
#                    never its own. The host's MFE loader fetches this file from
#                    the microapp's own deployment and registers it on that
#                    microapp's `window.kuika.apps` entry instead.
#
# Every key written to one file MUST be written to the other.
#
# Values come from two places; the container's environment wins:
#
#   1. container env vars — BACKEND_URL and RECAPTCHA_SITE_KEY, plus any key
#      that also appears in env.kuika (set it to override the build-time value).
#   2. ./env.kuika — `KEY=VALUE` lines the Kuika code generator wrote at build
#      time from the project's settings (map provider + keys, reCAPTCHA site
#      key). Those used to live only in the build's env-config.js, which this
#      script truncates — so every Docker deployment lost them, and an Amap
#      project silently came up on Google Maps. Now they are read back here.

JS_FILE=./env-config.js
JSON_FILE=./env-config.json
KUIKA_FILE=./env.kuika

echo "window._env_ = {" > "$JS_FILE"
echo "{" > "$JSON_FILE"

# Separator state. Object entries have to be comma-separated in BOTH files — the
# missing comma made env-config.js a SyntaxError whenever more than one variable
# was set, which left `window._env_` undefined and every value in it (BACKEND_URL
# included) silently ignored.
SEP=""
# Keys already written, space-delimited, so a key can never be emitted twice
# (a duplicate key is a JSON error for strict parsers).
WRITTEN=" "

append_entry() {
	key=$1
	value=$2
	case "$WRITTEN" in
		*" $key "*) return ;;
	esac
	WRITTEN="$WRITTEN$key "
	printf '%s\t%s: "%s"' "$SEP" "$key" "$value" >> "$JS_FILE"
	printf '%s  "%s": "%s"' "$SEP" "$key" "$value" >> "$JSON_FILE"
	SEP=",
"
}

# Container-only keys: written only when set.
if [ ! -z "$BACKEND_URL" ]
then
	append_entry "BACKEND_URL" "$BACKEND_URL"
fi
if [ ! -z "$RECAPTCHA_SITE_KEY" ]
then
	append_entry "RECAPTCHA_SITE_KEY" "$RECAPTCHA_SITE_KEY"
fi

# Build-time defaults from env.kuika. A container env var of the same name — even
# an empty one — replaces the file's value.
if [ -f "$KUIKA_FILE" ]
then
	CR=$(printf '\r')
	while IFS= read -r line || [ -n "$line" ]
	do
		line=${line%"$CR"}
		case "$line" in
			''|'#'*) continue ;;
			*=*) ;;
			*) continue ;;
		esac
		key=${line%%=*}
		value=${line#*=}
		# Only a shell identifier may reach eval below.
		case "$key" in
			''|[0-9]*|*[!A-Za-z0-9_]*) continue ;;
		esac
		eval "is_set=\${$key+x}"
		if [ -n "$is_set" ]
		then
			eval "value=\$$key"
		fi
		append_entry "$key" "$value"
	done < "$KUIKA_FILE"
fi

printf '\n}\n' >> "$JS_FILE"
printf '\n}\n' >> "$JSON_FILE"
