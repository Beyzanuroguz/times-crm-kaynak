# Check if package.json.bak does not exist or is writable
if [ ! -e package.json.bak ] || [ -w package.json.bak ]; then
    # Copy the contents of package.json to package.json.bak
    cp package.json package.json.bak
fi