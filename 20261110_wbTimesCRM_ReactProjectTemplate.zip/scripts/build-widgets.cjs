#!/usr/bin/env node

/**
 * Builds all widget packs in the src/widgets directory in parallel.
 * Each widget directory must have a package.json with @kuika/sdk installed.
 *
 * Security: Widget builds are sandboxed using @anthropic-ai/sandbox-runtime
 * with network isolation and filesystem restrictions.
 * On Windows, all builds run unsandboxed.
 */

const { spawn } = require("child_process");
const fs = require("fs");
const path = require("path");
const os = require("os");
const { Listr } = require("listr2");
const pLimit = require("p-limit");

// Lazy-loaded SandboxManager (ESM module)
let SandboxManager = null;

async function loadSandboxManager() {
  if (SandboxManager === null) {
    const module = await import("@anthropic-ai/sandbox-runtime");
    SandboxManager = module.SandboxManager;
  }
  return SandboxManager;
}

const WIDGETS_DIR = path.join(__dirname, "../src/widgets");
const CONCURRENCY_LIMIT = 4;
const DEFAULT_PACKAGE_MANAGER = "yarn";
const SUPPORTED_PACKAGE_MANAGERS = ["yarn", "npm", "pnpm", "bun"];
const IS_WINDOWS = os.platform() === "win32";

/**
 * Safely resolve a path, returning the original if it doesn't exist.
 */
function safeRealpathSync(p) {
  try {
    return fs.realpathSync(p);
  } catch {
    return p;
  }
}

/**
 * Create sandbox configuration for widget builds.
 * Blocks all network access and restricts filesystem access.
 */
function createSandboxConfig(widgetPaths) {
  const resolvedWidgetPaths = widgetPaths.map(safeRealpathSync);
  const widgetsDir = safeRealpathSync(WIDGETS_DIR);
  const projectRoot = path.dirname(path.dirname(widgetsDir));
  const cwd = process.cwd();
  const homeDir = os.homedir();

  return {
    network: {
      allowedDomains: [],
      deniedDomains: [],
      allowLocalBinding: true
    },
    filesystem: {
      denyRead: [path.join(homeDir, ".ssh"), path.join(homeDir, ".aws"), path.join(homeDir, ".gnupg")],
      allowWrite: [
        cwd,
        ...resolvedWidgetPaths,
        widgetsDir,
        projectRoot,
        "/tmp",
        os.tmpdir(),
        "/private/var/folders",
        "/private/tmp",
        path.join(homeDir, ".npm"),
        path.join(homeDir, ".yarn"),
        path.join(homeDir, ".pnpm-store"),
        path.join(homeDir, ".cache"),
        path.join(homeDir, ".node"),
        path.join(homeDir, ".node-gyp"),
        path.join(homeDir, ".angular"),
        homeDir
      ],
      denyWrite: []
    },
    enableWeakerNestedSandbox: true,
    allowPty: true
  };
}

/**
 * Build environment variables for sandboxed builds.
 */
function getSandboxEnv() {
  return {
    CHOKIDAR_USEPOLLING: "1",
    WATCHPACK_POLLING: "true",
    VITE_FORCE_POLLING: "1",
    XDG_CACHE_HOME: path.join(os.homedir(), ".cache"),
    npm_config_cache: path.join(os.homedir(), ".npm"),
    TMPDIR: os.tmpdir(),
    // Disable interactive prompts (critical for Angular CLI)
    CI: "true",
    NG_CLI_ANALYTICS: "false"
  };
}

/**
 * Check if sandbox is available on this platform.
 */
function isSandboxAvailable() {
  return !IS_WINDOWS;
}

/**
 * @anthropic-ai/sandbox-runtime resolves its mandatory deny list from
 * `process.cwd()` at the time `wrapWithSandbox` runs, then asks bwrap to
 * bind /dev/null over each entry. On servers we hit two failures:
 *
 *   1. `.claude` missing and bwrap can't create it as a mount point →
 *      "bwrap: Can't create file at .../.claude".
 *   2. `.git` exists as a *file* (gitlink / worktree pointer) so bwrap
 *      can't mkdir its children → "bwrap: Can't mkdir parents for
 *      .../.git/hooks: Not a directory".
 *
 * Workaround: before sandboxing, create `.claude/commands`, `.claude/agents`,
 * `.git/hooks`, and `.git/config` as real directories/files. If `.git` is a
 * regular file we stash it aside and restore it afterwards. Every mutation
 * is tracked in a LIFO undo list so `restoreSandboxCwd` can revert them
 * regardless of how the build exits (success, failure, signal).
 */
function prepareSandboxCwd(cwd) {
  const mutations = [];

  try {
    const claudeDir = path.join(cwd, ".claude");
    if (!fs.existsSync(claudeDir)) {
      fs.mkdirSync(claudeDir);
      mutations.push(() => fs.rmSync(claudeDir, { recursive: true, force: true }));
    }
    const claudeCommands = path.join(claudeDir, "commands");
    if (!fs.existsSync(claudeCommands)) {
      fs.mkdirSync(claudeCommands);
      mutations.push(() => fs.rmSync(claudeCommands, { recursive: true, force: true }));
    }
    const claudeAgents = path.join(claudeDir, "agents");
    if (!fs.existsSync(claudeAgents)) {
      fs.mkdirSync(claudeAgents);
      mutations.push(() => fs.rmSync(claudeAgents, { recursive: true, force: true }));
    }

    const gitPath = path.join(cwd, ".git");
    const gitStat = fs.existsSync(gitPath) ? fs.lstatSync(gitPath) : null;

    if (gitStat === null) {
      fs.mkdirSync(gitPath);
      mutations.push(() => fs.rmSync(gitPath, { recursive: true, force: true }));
    } else if (!gitStat.isDirectory()) {
      // `.git` is a gitlink file — move aside, replace with a temp dir,
      // and restore the original on cleanup.
      const gitBackup = `${gitPath}.kuika-sandbox-bak-${process.pid}`;
      fs.renameSync(gitPath, gitBackup);
      fs.mkdirSync(gitPath);
      mutations.push(() => {
        fs.rmSync(gitPath, { recursive: true, force: true });
        fs.renameSync(gitBackup, gitPath);
      });
    }

    const gitHooks = path.join(gitPath, "hooks");
    if (!fs.existsSync(gitHooks)) {
      fs.mkdirSync(gitHooks);
      mutations.push(() => fs.rmSync(gitHooks, { recursive: true, force: true }));
    }

    const gitConfig = path.join(gitPath, "config");
    if (!fs.existsSync(gitConfig)) {
      fs.writeFileSync(gitConfig, "");
      mutations.push(() => fs.rmSync(gitConfig, { force: true }));
    }
  } catch (err) {
    restoreSandboxCwd(mutations);
    throw err;
  }

  return mutations;
}

function restoreSandboxCwd(mutations) {
  while (mutations.length > 0) {
    const undo = mutations.pop();
    try {
      undo();
    } catch (err) {
      console.log(`Warning: sandbox cwd restore step failed: ${err.message}`);
    }
  }
}

/**
 * Get the package manager from package.json's packageManager field.
 */
function getPackageManager(widgetPath) {
  const packageJsonPath = path.join(widgetPath, "package.json");
  try {
    const packageJson = JSON.parse(fs.readFileSync(packageJsonPath, "utf-8"));
    if (packageJson.packageManager) {
      const pm = packageJson.packageManager.split("@")[0].toLowerCase();
      if (SUPPORTED_PACKAGE_MANAGERS.includes(pm)) {
        return pm;
      }
    }
  } catch {
    // Ignore errors, use default
  }
  return DEFAULT_PACKAGE_MANAGER;
}

/**
 * Ensure widget has build-mfe script. Migrates from build:mfe if needed.
 */
function ensureBuildScript(widgetPath) {
  const packageJsonPath = path.join(widgetPath, "package.json");
  const packageJson = JSON.parse(fs.readFileSync(packageJsonPath, "utf-8"));

  if (!packageJson.scripts) {
    packageJson.scripts = {};
  }

  if (packageJson.scripts["build-mfe"]) {
    return true;
  }

  if (packageJson.scripts["build:mfe"]) {
    delete packageJson.scripts["build:mfe"];
  }

  packageJson.scripts["build-mfe"] = "kuika build-mfe";
  fs.writeFileSync(packageJsonPath, `${JSON.stringify(packageJson, null, 2)}\n`);
  return true;
}

/**
 * Detect framework from package.json
 */
function detectFramework(widgetPath) {
  const packageJsonPath = path.join(widgetPath, "package.json");
  try {
    const packageJson = JSON.parse(fs.readFileSync(packageJsonPath, "utf-8"));
    const deps = { ...packageJson.dependencies, ...packageJson.devDependencies };
    if (deps["@angular/core"]) return "angular";
    if (deps.react) return "react";
    if (deps.vue) return "vue";
    if (deps.svelte) return "svelte";
    if (deps.angular) return "angularjs";
    return "unknown";
  } catch {
    return "unknown";
  }
}

/**
 * Run a shell command
 */
function runCommand(command, args, cwd) {
  return new Promise((resolve, reject) => {
    const proc = spawn(command, args, {
      cwd,
      shell: true,
      stdio: ["ignore", "pipe", "pipe"]
    });

    let stdout = "";
    let stderr = "";

    proc.stdout.on("data", (data) => {
      stdout += data.toString();
    });

    proc.stderr.on("data", (data) => {
      stderr += data.toString();
    });

    proc.on("close", (code, signal) => {
      if (code === 0) {
        resolve({ stdout, stderr });
      } else {
        const error = new Error(
          signal ? `Process killed by signal ${signal}` : `Command failed with exit code ${code}`
        );
        error.code = code;
        error.signal = signal;
        error.stdout = stdout;
        error.stderr = stderr;
        reject(error);
      }
    });

    proc.on("error", (err) => {
      reject(err);
    });
  });
}

/**
 * Record a build failure on the shared Listr ctx so the full stdout+stderr
 * can be dumped verbatim to stderr after tasks.run() finishes. Listr's
 * concurrent renderer swallows multi-line error strings, so we keep the
 * thrown error terse and print the full transcript ourselves afterwards.
 */
function recordFailure(ctx, widgetName, framework, phase, error) {
  const parts = [`${framework} ${phase} failed`];
  if (error.signal) {
    parts.push(`signal: ${error.signal}`);
  }
  if (error.code !== undefined && error.code !== null) {
    parts.push(`exit code: ${error.code}`);
  }
  const shortMessage = parts.join(", ");

  if (!ctx.failures) {
    ctx.failures = [];
  }
  ctx.failures.push({
    widgetName,
    framework,
    phase,
    shortMessage,
    stdout: typeof error.stdout === "string" ? error.stdout : "",
    stderr: typeof error.stderr === "string" ? error.stderr : "",
    message: error.message || String(error)
  });

  return new Error(shortMessage);
}

/**
 * Build a single widget with full sandbox-exec wrapping.
 * All frameworks use full sandbox isolation.
 */
async function buildWidgetSandboxed(ctx, widgetPath, widgetName, task) {
  const nodeModulesPath = path.join(widgetPath, "node_modules");
  const pm = getPackageManager(widgetPath);
  const framework = detectFramework(widgetPath);

  ensureBuildScript(widgetPath);

  // Install dependencies if needed (before sandboxing - needs network)
  if (!fs.existsSync(nodeModulesPath)) {
    task.output = `Installing dependencies (${pm})...`;
    try {
      await runCommand(pm, ["install"], widgetPath);
    } catch (error) {
      throw recordFailure(ctx, widgetName, framework, "install", error);
    }
  }

  // Build with full sandbox
  task.output = `Building ${framework} (sandboxed)...`;
  const command = `cd "${widgetPath}" && ${pm} run build-mfe`;
  const sandbox = await loadSandboxManager();
  const wrappedCommand = await sandbox.wrapWithSandbox(command);

  try {
    await new Promise((resolve, reject) => {
      const proc = spawn("sh", ["-c", wrappedCommand], {
        cwd: widgetPath,
        stdio: ["ignore", "pipe", "pipe"],
        env: { ...process.env, ...getSandboxEnv() }
      });

      let stdout = "";
      let stderr = "";

      proc.stdout.on("data", (data) => {
        stdout += data.toString();
      });

      proc.stderr.on("data", (data) => {
        stderr += data.toString();
      });

      proc.on("close", (code, signal) => {
        if (code === 0) {
          resolve({ stdout, stderr });
        } else {
          const error = new Error(
            signal ? `Process killed by signal ${signal}` : `Command failed with exit code ${code}`
          );
          error.code = code;
          error.signal = signal;
          error.stdout = stdout;
          error.stderr = stderr;
          reject(error);
        }
      });

      proc.on("error", (err) => {
        err.stdout = stdout;
        err.stderr = stderr;
        reject(err);
      });
    });
  } catch (error) {
    throw recordFailure(ctx, widgetName, framework, "build", error);
  }
}

/**
 * Build a single widget (unsandboxed fallback)
 */
async function buildWidgetUnsandboxed(ctx, widgetPath, widgetName, task) {
  const nodeModulesPath = path.join(widgetPath, "node_modules");
  const pm = getPackageManager(widgetPath);
  const framework = detectFramework(widgetPath);

  ensureBuildScript(widgetPath);

  // Install dependencies if needed
  if (!fs.existsSync(nodeModulesPath)) {
    task.output = `Installing dependencies (${pm})...`;
    try {
      await runCommand(pm, ["install"], widgetPath);
    } catch (error) {
      throw recordFailure(ctx, widgetName, framework, "install", error);
    }
  }

  // Run build
  task.output = `Building ${framework} (${pm})...`;
  try {
    await runCommand(pm, ["run", "build-mfe"], widgetPath);
  } catch (error) {
    throw recordFailure(ctx, widgetName, framework, "build", error);
  }
}

async function buildWidgets() {
  console.log("");

  if (!fs.existsSync(WIDGETS_DIR)) {
    console.log("No widgets directory found, skipping.\n");
    return;
  }

  const widgetDirs = fs.readdirSync(WIDGETS_DIR).filter((name) => {
    const widgetPath = path.join(WIDGETS_DIR, name);
    const packageJsonPath = path.join(widgetPath, "package.json");
    return fs.statSync(widgetPath).isDirectory() && fs.existsSync(packageJsonPath);
  });

  if (widgetDirs.length === 0) {
    console.log("No widget packages found, skipping.\n");
    return;
  }

  const widgetPaths = widgetDirs.map((dir) => path.join(WIDGETS_DIR, dir));
  const sandboxAvailable = isSandboxAvailable();

  if (IS_WINDOWS) {
    console.log("Warning: Windows detected - running builds without sandboxing\n");
  } else if (!sandboxAvailable) {
    console.log("Warning: Sandbox not supported - running builds without sandboxing\n");
  } else {
    console.log("Sandbox enabled (full process isolation)\n");
  }

  let sandboxMutations = null;
  let signalHandler = null;

  // Initialize sandbox if available
  if (sandboxAvailable) {
    sandboxMutations = prepareSandboxCwd(process.cwd());
    // Best-effort restore if the process is killed mid-build so we never
    // leave a stashed-aside `.git` gitlink behind.
    signalHandler = (signal) => {
      restoreSandboxCwd(sandboxMutations);
      process.exit(signal === "SIGINT" ? 130 : 143);
    };
    process.once("SIGINT", signalHandler);
    process.once("SIGTERM", signalHandler);

    const config = createSandboxConfig(widgetPaths);
    const sandbox = await loadSandboxManager();
    await sandbox.initialize(config);
  }

  const limit = pLimit(CONCURRENCY_LIMIT);

  const runCtx = { failures: [] };

  const tasks = new Listr(
    widgetDirs.map((widgetDir) => ({
      title: widgetDir,
      task: async (ctx, task) => {
        const widgetPath = path.join(WIDGETS_DIR, widgetDir);
        if (sandboxAvailable) {
          await limit(() => buildWidgetSandboxed(ctx, widgetPath, widgetDir, task));
        } else {
          await limit(() => buildWidgetUnsandboxed(ctx, widgetPath, widgetDir, task));
        }
      }
    })),
    {
      ctx: runCtx,
      concurrent: true,
      exitOnError: false,
      rendererOptions: {
        showTimer: true,
        collapseSubtasks: false,
        showSubtasks: true,
        suffixSkips: true
      }
    }
  );

  try {
    await tasks.run();
    console.log("");
  } catch {
    // Individual failures are still captured in runCtx.failures below.
  } finally {
    if (runCtx.failures && runCtx.failures.length > 0) {
      process.exitCode = 1;
      process.stderr.write("\n");
      for (const failure of runCtx.failures) {
        const header = `=== ${failure.widgetName} — ${failure.shortMessage} ===`;
        process.stderr.write(`${header}\n`);
        if (failure.stdout) {
          process.stderr.write("--- stdout ---\n");
          process.stderr.write(failure.stdout.endsWith("\n") ? failure.stdout : `${failure.stdout}\n`);
        }
        if (failure.stderr) {
          process.stderr.write("--- stderr ---\n");
          process.stderr.write(failure.stderr.endsWith("\n") ? failure.stderr : `${failure.stderr}\n`);
        }
        if (!failure.stdout && !failure.stderr && failure.message) {
          process.stderr.write(`${failure.message}\n`);
        }
        process.stderr.write(`${"=".repeat(header.length)}\n\n`);
      }
      process.stderr.write(`${runCtx.failures.length} widget build(s) failed.\n\n`);
    }
    // Cleanup sandbox resources before restoring cwd so any logging from
    // reset() still sees the real .git / .claude state.
    if (sandboxAvailable && SandboxManager !== null) {
      await SandboxManager.reset();
    }
    if (sandboxMutations !== null) {
      restoreSandboxCwd(sandboxMutations);
    }
    if (signalHandler !== null) {
      process.removeListener("SIGINT", signalHandler);
      process.removeListener("SIGTERM", signalHandler);
    }
  }
}

buildWidgets();
