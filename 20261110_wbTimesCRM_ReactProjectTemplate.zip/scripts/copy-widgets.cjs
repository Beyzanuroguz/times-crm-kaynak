#!/usr/bin/env node

/**
 * Copies widget dist-mfe folders to the build output after host app build completes.
 * This runs as a postbuild script to ensure widgets are included in the final output.
 */

const fs = require("fs");
const path = require("path");

const WIDGETS_DIR = path.join(__dirname, "../src/widgets");
const PUBLIC_DIR = path.join(__dirname, "../public");
const WIDGETS_OUTPUT_DIR = path.join(PUBLIC_DIR, "widgets");

/**
 * Gets the actual dist-mfe path, checking for Angular's browser subdirectory.
 */
function getActualDistMfePath(basePath) {
  const browserPath = path.join(basePath, "browser");
  if (fs.existsSync(browserPath) && fs.statSync(browserPath).isDirectory()) {
    return browserPath;
  }
  if (fs.existsSync(basePath) && fs.statSync(basePath).isDirectory()) {
    return basePath;
  }
  return null;
}

/**
 * Gets the packId from asset-manifest.json or falls back to folder name.
 */
function getPackId(distMfePath, folderName) {
  const manifestPath = path.join(distMfePath, "asset-manifest.json");
  if (fs.existsSync(manifestPath)) {
    try {
      const manifest = JSON.parse(fs.readFileSync(manifestPath, "utf-8"));
      if (manifest.widgets?.projectId) {
        return manifest.widgets.projectId;
      }
    } catch (e) {
      console.warn(`Failed to parse manifest at ${manifestPath}`);
    }
  }
  return folderName;
}

/**
 * Recursively copies a directory.
 */
function copyDir(src, dest) {
  fs.mkdirSync(dest, { recursive: true });
  const entries = fs.readdirSync(src, { withFileTypes: true });

  for (const entry of entries) {
    const srcPath = path.join(src, entry.name);
    const destPath = path.join(dest, entry.name);

    if (entry.isDirectory()) {
      copyDir(srcPath, destPath);
    } else {
      fs.copyFileSync(srcPath, destPath);
    }
  }
}

function copyWidgets() {
  if (!fs.existsSync(WIDGETS_DIR)) {
    console.log("No widgets directory found, skipping copy.\n");
    return;
  }

  if (!fs.existsSync(PUBLIC_DIR)) {
    console.log("Public directory not found, skipping widget copy.\n");
    return;
  }

  const widgetDirs = fs.readdirSync(WIDGETS_DIR).filter((name) => {
    const widgetPath = path.join(WIDGETS_DIR, name);
    return fs.statSync(widgetPath).isDirectory();
  });

  if (widgetDirs.length === 0) {
    console.log("No widgets found, skipping copy.\n");
    return;
  }

  console.log("\nCopying widgets to build output...");

  let copiedCount = 0;

  for (const widgetDir of widgetDirs) {
    const basePath = path.join(WIDGETS_DIR, widgetDir, "dist-mfe");
    const distMfePath = getActualDistMfePath(basePath);

    if (!distMfePath) {
      console.log(`  ⚠ ${widgetDir}: No dist-mfe found, skipping`);
      continue;
    }

    const packId = getPackId(distMfePath, widgetDir);
    const outputPath = path.join(WIDGETS_OUTPUT_DIR, packId);

    // Remove existing output directory if it exists
    if (fs.existsSync(outputPath)) {
      fs.rmSync(outputPath, { recursive: true, force: true });
    }

    copyDir(distMfePath, outputPath);
    console.log(`  ✓ ${widgetDir} -> widgets/${packId}`);
    copiedCount++;
  }

  console.log(`\nCopied ${copiedCount} widget(s) to public/widgets/\n`);
}

copyWidgets();
