# script.sh

while IFS= read -r line; do
  # If the line does not contain "export { , } from", "export { , , } from", "export { , , , } from", or similar expressions, print the line
  if [[ ! $line =~ export\ \{[[:space:],]*\}[[:space:]]*from ]]; then
    # Remove comma characters and print the line
    echo "${line//,/}"
  fi
done < src/components/web-components/index.ts > temp_file

# Replace the original file with the temporary file
mv temp_file src/components/web-components/index.ts

while IFS= read -r line; do
  # If the line does not contain "export { , } from", "export { , , } from", "export { , , , } from", or similar expressions, print the line
  if [[ ! $line =~ export\ \{[[:space:],]*\}[[:space:]]*from ]]; then
    # Remove comma characters and print the line
    echo "${line//,/}"
  fi
done < src/kuika/index.ts > temp_file

# Replace the original file with the temporary file
mv temp_file src/kuika/index.ts