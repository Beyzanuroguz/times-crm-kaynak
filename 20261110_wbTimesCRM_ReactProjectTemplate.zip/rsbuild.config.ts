import crypto from "node:crypto";
import fs from "node:fs";
import os from "node:os";
import path from "node:path";
import { InjectManifest } from "@aaroon/workbox-rspack-plugin";
import { defineConfig } from "@rsbuild/core";
import { pluginBasicSsl } from "@rsbuild/plugin-basic-ssl";
import { pluginReact } from "@rsbuild/plugin-react";
import { pluginSass } from "@rsbuild/plugin-sass";
import { RsdoctorRspackPlugin } from "@rsdoctor/rspack-plugin";
import { pluginHtmlMinifierTerser } from "rsbuild-plugin-html-minifier-terser";
import {
  IS_AGENT,
  IS_BUNDLE_ANALYZER_ENABLED,
  IS_DEV_SERVER,
  IS_PREVIEW,
  IS_PROD,
  IS_RSDOCTOR_ENABLED,
  IS_SSL_ENABLED,
  SERVER_URL
} from "./rsbuild/build-env";
import { RsBuildUtils, YarnWorkspaceUtils } from "./rsbuild/build-utils";
import { performanceConfig, splitChunks } from "./rsbuild/performance-config";
import pluginAntdDayjsToMoment from "./rsbuild/plugins/pluginAntdDayjsToMoment";
import { pluginAssetManifest } from "./rsbuild/plugins/pluginAssetManifest";
import pluginCompression from "./rsbuild/plugins/pluginCompression";
import pluginShellPluginNext from "./rsbuild/plugins/pluginShellPluginNext";
import { serverConfig } from "./rsbuild/server-config";
import { getWidgetMappings } from "./rsbuild/widget-utils";
import { MONACO_VS_PUBLIC_DIR } from "./src/shared/utilty/monaco-assets";

interface AdditionalManifestEntry {
  url: string;
  revision: string;
}

// Files in `public/` are copied to the dist root by rsbuild's built-in public
// directory handling, but they're not part of the rspack compilation that
// `InjectManifest` scans — so they're absent from `__WB_MANIFEST` unless we
// add them explicitly here. Without this the precache misses every static
// asset that isn't a hashed bundle (material-icons CSS+fonts, env-config.js,
// favicon, manifest, etc.), and offline-first-load fails for them no matter
// what runtime caching strategy the SW uses.
//
// Each entry needs a revision — a content hash so Workbox knows when the file
// has changed and refetches it on the next SW install. We compute MD5 from
// the file content at build time so the revision tracks the file's actual
// content, not just its name.
const PRECACHED_PUBLIC_FILES: readonly string[] = [
  "env-config.js",
  "manifest.json",
  "favicon.ico",
  "favicon-192x192.png",
  "favicon-512x512.png",
  "material-icons.min.css",
  "material-icons.woff2",
  "material-icons-outlined.woff2",
  "material-icons-round.woff2",
  "material-icons-sharp.woff2",
  "material-icons-two-tone.woff2",
  "font-awesome/css/all.min.css",
  "font-awesome/webfonts/fa-solid-900.woff2",
  "font-awesome/webfonts/fa-regular-400.woff2",
  "font-awesome/webfonts/fa-brands-400.woff2"
];

// Monaco is served from the app's own origin — see
// src/shared/utilty/monaco-loader-config.ts. Resolved from the installed
// package so the copied assets always match the `monaco-editor` version pinned
// in package.json.
const MONACO_VS_SOURCE_PATH: string = path.join(YarnWorkspaceUtils.getPackagePath("monaco-editor"), "min", "vs");

const computePublicFileRevision = (filename: string): string => {
  const filePath: string = path.join(__dirname, "public", filename);
  const contents: Buffer = fs.readFileSync(filePath);
  // Wrap in a fresh Uint8Array. @types/node 24+ types Buffer as
  // Uint8Array<ArrayBufferLike>, but crypto.update accepts only
  // Uint8Array<ArrayBuffer>; the generic widens through Buffer's
  // .slice(...).buffer and TS rejects the direct call.
  const bytes: Uint8Array = new Uint8Array(contents.buffer, contents.byteOffset, contents.byteLength);
  return crypto.createHash("md5").update(bytes).digest("hex");
};

const additionalPrecacheEntries: AdditionalManifestEntry[] = PRECACHED_PUBLIC_FILES.map(
  (filename: string): AdditionalManifestEntry => ({
    url: `/${filename}`,
    revision: computePublicFileRevision(filename)
  })
);

// Design-time UploadedImages bound to offline-supported screens are emitted by the code
// generator into public/offline-resources/{resourceId}.{ext}. Unlike env-config.js /
// index.html, this folder is NOT picked up by the build's manifest scan, so without an
// explicit precache entry the images are only runtime-cached on first fetch — which
// leaves offline-first broken for a screen that was never opened online. Enumerate the
// (flat) folder and precache each file with a content revision. This is safe to pass via
// additionalManifestEntries precisely BECAUSE the scan does not already include these
// URLs, so there is no `add-to-cache-list-conflicting-entries` risk (see the note below).
//
// The URL MUST carry the deploy base (SERVER_URL / assetPrefix), exactly like the scanned
// entries do. Workbox rewrites scanned manifest URLs with the bundler publicPath, but
// additionalManifestEntries are passed through verbatim — so we prepend SERVER_URL here by
// hand. SERVER_URL is the deploy base ("/", "/{virtualDir}/", or the dev host, always with
// a trailing slash; the code generator string-replaces the "/agent/" default in build-env).
// Without this, on a virtual-directory deploy the SW precaches "/offline-resources/x.png"
// (origin root) while the file is served at "/{virtualDir}/offline-resources/x.png" — the
// install fetch 404s (`bad-precaching-response`, aborting the whole precache), and the
// runtime <img> (resolved via getFrontEndUrl in KMainFunctions.resolveImageSrc) never
// finds it. Prefixing here keeps the precache key aligned with both the served file and
// the runtime image URL.
const collectOfflineResourcePrecacheEntries = (): AdditionalManifestEntry[] => {
  const offlineResourcesDir: string = path.join(__dirname, "public", "offline-resources");
  if (!fs.existsSync(offlineResourcesDir)) {
    return [];
  }
  return fs
    .readdirSync(offlineResourcesDir)
    .filter((name: string): boolean => fs.statSync(path.join(offlineResourcesDir, name)).isFile())
    .map((name: string): AdditionalManifestEntry => {
      const contents: Buffer = fs.readFileSync(path.join(offlineResourcesDir, name));
      const bytes: Uint8Array = new Uint8Array(contents.buffer, contents.byteOffset, contents.byteLength);
      return {
        url: `${SERVER_URL}offline-resources/${name}`,
        revision: crypto.createHash("md5").update(bytes).digest("hex")
      };
    });
};

// NOTE: public/ files (env-config.js, favicons, manifest.json, material-icons.*)
// are intentionally NOT added to the precache manifest here. The build's
// manifest scan already includes every emitted file — including the copied
// public/ assets — with the correct deploy base path and a content revision.
// A manual additionalManifestEntries list re-added them with a revision hashed
// from the TEMPLATE copy; for env-config.js (whose content is deploy-specific)
// that revision diverged from the scanned (deployed) one, producing
// `add-to-cache-list-conflicting-entries` → Workbox install aborts → the
// service worker goes redundant ("registers then disappears"). The scan is the
// single source of truth; do not reintroduce a parallel manual list.

export default defineConfig({
  mode: IS_PROD ? "production" : "development",
  plugins: [
    pluginReact(),
    pluginSass(),
    pluginHtmlMinifierTerser(),
    ...RsBuildUtils.enablePluginsOnCondition([pluginBasicSsl()], IS_SSL_ENABLED)
  ],
  html: {
    crossorigin: "anonymous",
    template: "./public/index.html",
    templateParameters: {
      // Remove the trailing slash from the SERVER_URL
      PUBLIC_URL: SERVER_URL.endsWith("/") ? SERVER_URL.slice(0, -1) : SERVER_URL
    }
  },
  source: {
    entry: { index: "./src/index.tsx" },
    // @kuika/runtime ships raw TypeScript source. In the monorepo the
    // workspace symlink resolves outside node_modules (compiled by default),
    // but in a generated app the file: dependency is installed under
    // node_modules, which rsbuild skips unless included explicitly.
    include: [/node_modules[\\/]@kuika[\\/]runtime/],
    define: {
      process: {
        env: {
          NODE_ENV: IS_PROD ? JSON.stringify("production") : JSON.stringify("development"),
          DEV_SERVER: JSON.stringify(IS_DEV_SERVER ? "true" : "false")
        }
      }
    }
  },
  resolve: {
    alias: {
      // @kuika/runtime is raw TS source bundled with the app: generated
      // apps carry it at ./vendor/runtime (file: dependency), the monorepo
      // keeps the workspace package at ../runtime. Both targets live outside
      // node_modules, so the build never depends on an install having linked it
      // (the build server's staged node_modules doesn't contain it).
      "@kuika/runtime": fs.existsSync(path.join(__dirname, "vendor", "runtime", "index.ts"))
        ? path.join(__dirname, "vendor", "runtime", "index.ts")
        : path.join(__dirname, "..", "runtime", "index.ts"),
      "trello-smooth-dnd": "kuika-smooth-dnd",
      react: YarnWorkspaceUtils.getPackagePath("react"),
      "react-dom": YarnWorkspaceUtils.getPackagePath("react-dom"),
      lodash: YarnWorkspaceUtils.getPackagePath("lodash"),
      classnames: YarnWorkspaceUtils.getPackagePath("classnames"),
      // Exact-match ($) on purpose so this dedupe alias never rewrites subpath imports.
      // react-trello's legacy "uuid/v1" deep import cannot resolve against the
      // security-pinned uuid@11 (resolutions force every uuid range to 11.x, so no
      // nested uuid@3 exists either) — it is mapped onto uuid@11's named v1 export below.
      uuid$: YarnWorkspaceUtils.getPackagePath("uuid"),
      "uuid/v1$": path.join(__dirname, "rsbuild", "uuid-v1-shim.ts"),
      "@ant-design/icons": YarnWorkspaceUtils.getPackagePath("@ant-design/icons"),
      "@babel/runtime": YarnWorkspaceUtils.getPackagePath("@babel/runtime"),
      "react-is": YarnWorkspaceUtils.getPackagePath("react-is"),
      "throttle-debounce": YarnWorkspaceUtils.getPackagePath("throttle-debounce"),
      "styled-components": YarnWorkspaceUtils.getPackagePath("styled-components"),
      redux: YarnWorkspaceUtils.getPackagePath("redux"),
      "react-redux": YarnWorkspaceUtils.getPackagePath("react-redux")
    }
  },
  dev: {
    assetPrefix: SERVER_URL
  },
  server: {
    ...serverConfig,
    setup: ({ server }) => {
      // Serve widget dist-mfe folders at /widgets/{packId}/ during dev
      const widgetsDir = path.join(__dirname, "./src/widgets");
      const mappings = getWidgetMappings(widgetsDir);

      // Create a single middleware that handles all widget routes.
      // server.setup runs before Rsbuild's default middlewares are registered,
      // so `use` here is equivalent to the v1 `setupMiddlewares.unshift` pattern.
      server.middlewares.use(
        (
          req: { url?: string },
          res: {
            setHeader: (name: string, value: string) => void;
            end: (data: Buffer | string) => void;
            statusCode: number;
          },
          next: () => void
        ) => {
          const url = req.url || "";

          if (url.startsWith("/widgets/")) {
            const pathParts = url.split("/").filter(Boolean);
            const packId = pathParts[1];

            const mapping = mappings.find((m) => m.packId === packId);

            if (mapping) {
              const filePath = pathParts.slice(2).join("/") || "index.html";
              const fullPath = path.join(mapping.distMfePath, filePath);

              if (fs.existsSync(fullPath) && fs.statSync(fullPath).isFile()) {
                const ext = path.extname(fullPath).toLowerCase();
                const mimeTypes: Record<string, string> = {
                  ".json": "application/json",
                  ".js": "application/javascript",
                  ".css": "text/css",
                  ".html": "text/html",
                  ".svg": "image/svg+xml",
                  ".png": "image/png",
                  ".jpg": "image/jpeg",
                  ".ico": "image/x-icon"
                };
                if (mimeTypes[ext]) {
                  res.setHeader("Content-Type", mimeTypes[ext]);
                }
                res.setHeader("Access-Control-Allow-Origin", "*");

                const content = fs.readFileSync(fullPath);
                res.end(content);
                return;
              }
            }
          }

          next();
        }
      );
    }
  },
  output: {
    assetPrefix: SERVER_URL,
    distPath: {
      root: "build"
    },
    filename: {
      js: IS_PROD ? "[name].[contenthash].js" : "[name].js",
      css: IS_PROD ? "[name].[contenthash].css" : "[name].css"
    },
    sourceMap: {
      js: "source-map",
      css: true
    },
    filenameHash: true,
    copy: [
      { from: "./public/env-config.js", to: "env-config.js" },
      // Fetchable twin of env-config.js, read by a HOST app to resolve an embedded
      // microapp's own runtime config (see env.sh). The template copy is `{}`;
      // env.sh rewrites it at container start. It ships so nginx's SPA fallback can
      // never answer the request with index.html.
      { from: "./public/env-config.json", to: "env-config.json" },
      { from: "./public/favicon.ico", to: "favicon.ico" },
      { from: "./public/favicon-192x192.png", to: "favicon-192x192.png" },
      { from: "./public/favicon-512x512.png", to: "favicon-512x512.png" },
      { from: "./public/manifest.json", to: "manifest.json" },
      { from: "./public/assets", to: "assets" },
      { from: "./public/images", to: "images" },
      { from: "./public/blank.html", to: "blank.html" },
      { from: "./public/crossdomain.xml", to: "crossdomain.xml" },
      { from: "./public/google_maps_pin.svg", to: "google_maps_pin.svg" },
      { from: "./public/kuika-mfe.js", to: "kuika-mfe.js" },
      { from: "./public/maps.svg", to: "maps.svg" },
      { from: "./public/video.svg", to: "video.svg" },
      { from: "./public/web.config", to: "web.config" },
      { from: "./public/webview.svg", to: "webview.svg" },
      { from: "./env.sh", to: "env.sh" },
      { from: "./env.kuika", to: "env.kuika" },
      { from: MONACO_VS_SOURCE_PATH, to: MONACO_VS_PUBLIC_DIR },
      { from: "./Dockerfile", to: "." },
      fs.existsSync(path.join(__dirname, "./.nginx")) && { from: path.join(__dirname, "./.nginx"), to: ".nginx" },
      // Copy widget packs from public/widgets to build/widgets/
      fs.existsSync(path.join(__dirname, "./public/widgets")) && { from: "./public/widgets", to: "widgets" }
    ].filter(Boolean),
    // 2025 baseline (web-platform-dx "widely available on 2025-05-01"),
    // matching Rsbuild 2.0 defaults. Smaller bundles, less polyfilling,
    // and no transpiling for features that all targeted browsers ship.
    overrideBrowserslist: ["chrome >= 107", "edge >= 107", "firefox >= 104", "safari >= 16"]
  },
  // (B) Preview build-cache: Rsbuild persistent filesystem cache so a preview generated after idle
  // reuses the prior frontend compile instead of rebuilding from scratch. Rides the single
  // PREVIEW_RUNTIME=k8s switch (same as the whole k8s preview runtime) and only for preview builds
  // -> systemd/on-prem and other envs are untouched. cacheDirectory lives in the OS temp, keyed by
  // the build cwd (per-app), OUTSIDE the per-generate temp wipe so it survives across generates.
  // buildDependencies invalidate the cache whenever this config or the perf config changes (stale guard).
  performance:
    IS_PROD || IS_PREVIEW
      ? {
          ...performanceConfig,
          ...(process.env.PREVIEW_RUNTIME === "k8s" && IS_PREVIEW
            ? {
                buildCache: {
                  cacheDirectory: path.join(
                    os.tmpdir(),
                    "kuika-build-cache",
                    crypto.createHash("md5").update(process.cwd()).digest("hex"),
                    "rsbuild"
                  ),
                  // Cache'i shared node_modules'a da bağla: Rspack node_modules'ı version-snapshot ile
                  // tutar → aynı sürüm altında IN-PLACE içerik değişimini kaçırabilir (stale vendor riski).
                  // Shared node_modules'ın content-marker'ını (.yarn-integrity = içerik-hash; yoksa
                  // yarn.lock/package.json) buildDependencies'e ekliyoruz → deps DEĞİŞİMİNDE (version-bump
                  // olsun olmasın) tüm cache invalidate olur. Marker sabitken maliyet = tek dosya hash'i,
                  // warm build süresini ETKİLEMEZ.
                  buildDependencies: (() => {
                    const deps = [__filename, path.join(__dirname, "rsbuild", "performance-config.ts")];
                    try {
                      const nm = fs.realpathSync(path.join(__dirname, "node_modules"));
                      for (const c of [
                        path.join(nm, ".yarn-integrity"),
                        path.join(path.dirname(nm), "yarn.lock"),
                        path.join(path.dirname(nm), "package.json")
                      ]) {
                        if (fs.existsSync(c)) {
                          deps.push(c);
                          break;
                        }
                      }
                    } catch {
                      /* shared node_modules yoksa yalnız config deps ile devam */
                    }
                    return deps;
                  })()
                }
              }
            : {})
        }
      : undefined,
  splitChunks: IS_PROD || IS_PREVIEW ? splitChunks : undefined,
  tools: {
    swc: (config) => {
      delete config.env;
      config.jsc.target = "es2022";
    },
    rspack: {
      plugins: [
        ...RsBuildUtils.enablePluginsOnCondition(pluginShellPluginNext.plugins, IS_PROD && !IS_PREVIEW && !IS_AGENT),
        ...RsBuildUtils.enablePluginsOnCondition(pluginCompression.plugins, IS_PROD && (!IS_PREVIEW || IS_AGENT)),
        pluginAssetManifest,
        pluginAntdDayjsToMoment,
        ...RsBuildUtils.enablePluginsOnCondition(
          [
            new InjectManifest({
              swSrc: "./src/sw.ts",
              swDest: "sw.js",
              // Large enough to cover unminified dev-mode entry/vendor chunks
              // (index.js, vendors-…j-…js can run 15-40 MB without
              // minification). Without a generous limit Workbox silently drops
              // them from the manifest, the precache route never matches them
              // online, and the SPA can't boot offline. Production-mode
              // bundles are much smaller; this just isn't a constraint we
              // need to pay for in either mode.
              maximumFileSizeToCacheInBytes: 100 * 1024 * 1024, // 100 MB
              // Precache the offline-screen UploadedImages the code generator dropped into
              // public/offline-resources/. Scoped to that folder ONLY — these URLs are not
              // in the manifest scan, so this reintroduces additionalManifestEntries without
              // the conflicting-entries problem that forced the general apparatus out (below).
              additionalManifestEntries: collectOfflineResourcePrecacheEntries(),
              // index.html is INCLUDED in precache so the SW always has an
              // HTML shell to serve on offline navigations — even on the
              // very first reload after install (when the original load was
              // uncontrolled and didn't populate the runtime `pages` cache).
              // The SW's setCatchHandler reaches it via matchPrecache().
              // The manual additionalManifestEntries apparatus is removed
              // (see note above): the build scan already includes public/
              // files — env-config.js and index.html included — with the
              // correct deploy base path and the *deployed* revision, so they
              // must NOT be excluded here or offline first-load breaks. We do
              // keep excluding pure deploy artifacts that are never app
              // assets and should never be precached/served.
              // The self-hosted Monaco payload (~15 MB of lazily-required AMD
              // chunks, one per language) is excluded on purpose: precaching it
              // would push the whole editor into every user's cache for a
              // feature most sessions never open. It is fetched on demand from
              // our own origin, which is all the air-gapped case requires.
              // env-config.json is deploy-specific and is only ever read by another
              // app over the network (with cache: "no-store"). A precached copy would
              // pin whatever this deployment published at SW-install time and hand
              // embedding hosts a stale BACKEND_URL after an env-var change.
              exclude: [
                /\.hot-update\./,
                /\.map$/,
                /env\.sh$/,
                /env\.kuika$/,
                /env-config\.json$/,
                /Dockerfile/,
                /\.nginx/,
                /web\.config$/,
                /^monaco-editor\//
              ]
            })
          ],
          !IS_DEV_SERVER
        ),
        ...RsBuildUtils.enablePluginsOnCondition(
          [new RsdoctorRspackPlugin({})],
          IS_BUNDLE_ANALYZER_ENABLED || IS_RSDOCTOR_ENABLED
        )
      ]
    },
    cssExtract: {
      pluginOptions: {
        chunkFilename: IS_PROD ? "[name].[contenthash].css" : "[name].css"
      }
    }
  }
});
