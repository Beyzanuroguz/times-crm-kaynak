# Check if package.json.bak exists and is writable
if [ -e package.json.bak ] && [ -w package.json.bak ]; then
    # Copy the contents of package.json.bak to package.json
    cp package.json.bak package.json

    # Check if package.json.bak still exists, then remove it
    [ -e package.json.bak ] && rm package.json.bak
fi