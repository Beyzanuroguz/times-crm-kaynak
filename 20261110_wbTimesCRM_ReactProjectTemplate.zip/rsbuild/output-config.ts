import { join } from "path";
import { Rspack } from "@rsbuild/core";
import { SERVER_URL } from "./build-env";

export const outputConfig: Rspack.Output = {
  library: {
    name: "wbTimesCRM",
    type: "window"
  },
  path: join(__dirname, "../build"),
  publicPath: SERVER_URL,
  filename: "[name].[contenthash].js",
  crossOriginLoading: "anonymous",
  clean: true
};
