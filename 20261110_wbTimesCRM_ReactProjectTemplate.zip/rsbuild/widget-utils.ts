import fs from "node:fs";
import path from "node:path";

export interface WidgetMapping {
  folderName: string;
  packId: string;
  distMfePath: string;
}

/**
 * Gets the actual dist-mfe path, checking for Angular's browser subdirectory.
 * Angular CLI outputs to dist-mfe/browser/, while React/Vue output directly to dist-mfe/
 */
function getActualDistMfePath(basePath: string): string | null {
  // Check for Angular's browser subdirectory first
  const browserPath = path.join(basePath, "browser");
  if (fs.existsSync(browserPath) && fs.statSync(browserPath).isDirectory()) {
    return browserPath;
  }
  // Fall back to direct dist-mfe path
  if (fs.existsSync(basePath) && fs.statSync(basePath).isDirectory()) {
    return basePath;
  }
  return null;
}

/**
 * Scans the widgets directory and returns mapping information for each widget pack.
 * Maps folder names to their packIds (from asset-manifest.json) and dist-mfe paths.
 * Handles both Angular (dist-mfe/browser/) and React/Vue (dist-mfe/) output structures.
 * @param widgetsDir - Absolute path to the widgets directory
 */
export function getWidgetMappings(widgetsDir: string): WidgetMapping[] {
  const resolvedWidgetsDir = path.resolve(widgetsDir);
  if (!fs.existsSync(resolvedWidgetsDir)) return [];

  return fs
    .readdirSync(resolvedWidgetsDir)
    .filter((name) => {
      const basePath = path.join(resolvedWidgetsDir, name, "dist-mfe");
      return getActualDistMfePath(basePath) !== null;
    })
    .map((name) => {
      const basePath = path.join(resolvedWidgetsDir, name, "dist-mfe");
      const distMfePath = getActualDistMfePath(basePath)!;
      const manifestPath = path.join(distMfePath, "asset-manifest.json");
      let packId = name; // fallback to folder name

      if (fs.existsSync(manifestPath)) {
        try {
          const manifest = JSON.parse(fs.readFileSync(manifestPath, "utf-8"));
          if (manifest.widgets?.projectId) {
            packId = manifest.widgets.projectId;
          }
        } catch (e) {
          console.warn(`Failed to parse widget manifest at ${manifestPath}:`, e);
        }
      }

      return { folderName: name, packId, distMfePath };
    });
}

/**
 * Returns copy patterns for rsbuild output.copy configuration.
 * Used to copy widget dist-mfe folders to the build output.
 * @param widgetsDir - Absolute path to the widgets directory
 * @param configDir - Directory where the config file is located (usually __dirname)
 */
export function getWidgetCopyPatterns(widgetsDir: string, configDir: string): Array<{ from: string; to: string }> {
  const mappings = getWidgetMappings(widgetsDir);
  const patterns: Array<{ from: string; to: string }> = [];

  mappings.forEach((w) => {
    // Convert absolute path to relative path from config directory
    const relativePath = path.relative(configDir, w.distMfePath);

    // Read all files/directories in the dist-mfe folder and create individual copy patterns
    const distMfeContents = fs.readdirSync(w.distMfePath);
    distMfeContents.forEach((item) => {
      const itemPath = path.join(w.distMfePath, item);
      const relativeItemPath = path.relative(configDir, itemPath);
      patterns.push({
        from: `./${relativeItemPath}`,
        to: `widgets/${w.packId}/${item}`
      });
    });
  });

  return patterns;
}
