import fs from "fs";
import path from "path";

export class YarnWorkspaceUtils {
  static getPackagePathFromProject(packageName: string): string | undefined {
    if (fs.existsSync(path.join(__dirname, "../node_modules/", packageName))) {
      return path.join(__dirname, "../node_modules/", packageName);
    }

    return undefined;
  }

  static getPackagePathFromWorkspace(packageName: string): string | undefined {
    if (fs.existsSync(path.join(__dirname, "../../../node_modules/", packageName))) {
      return path.join(__dirname, "../../../node_modules/", packageName);
    }

    return undefined;
  }

  static getPackagePath(packageName: string): string {
    let packagePath = YarnWorkspaceUtils.getPackagePathFromProject(packageName);

    if (!packagePath) {
      packagePath = YarnWorkspaceUtils.getPackagePathFromWorkspace(packageName);
    }

    if (!packagePath) {
      throw new Error(`Package ${packageName} not found`);
    }

    return packagePath;
  }
}

export class RsBuildUtils {
  static enablePluginsOnCondition(plugins: any[], condition: boolean) {
    return condition ? plugins : [];
  }
}
