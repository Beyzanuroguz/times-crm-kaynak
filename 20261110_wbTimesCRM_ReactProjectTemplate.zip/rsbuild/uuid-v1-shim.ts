// react-trello deep-imports "uuid/v1" — a uuid@3-era path that no longer exists in the
// security-pinned uuid@11 (package.json `resolutions` forces every uuid range, including
// react-trello's ^3.3.2, to 11.x — so a nested uuid@3 copy is never installed). uuid@11
// still exports the v1 algorithm as a named export; re-export it so the bundler can
// satisfy the legacy specifier from the single pinned copy. Wired up via the
// `"uuid/v1$"` resolve alias in rsbuild.config.ts.
import { v1 } from "uuid";

export default v1;
