import AntdDayjsToMoment from "@ant-design/moment-webpack-plugin";

export default new AntdDayjsToMoment();
