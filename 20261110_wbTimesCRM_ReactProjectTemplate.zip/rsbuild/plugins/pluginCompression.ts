import zlib from "zlib";
import CompressionPlugin from "compression-webpack-plugin";
import { IS_AGENT, IS_PREVIEW, IS_PROD } from "../build-env";

const pluginCompression = {
  plugins: [
    new CompressionPlugin({
      filename: "[path][base].br",
      algorithm: "brotliCompress",
      test: /\.(js|css|html|svg|woff2)$/,
      compressionOptions: {
        level: zlib.constants.BROTLI_MAX_QUALITY
      },
      threshold: 10240,
      minRatio: 0.8
    })
  ]
};

if (IS_PROD && !IS_PREVIEW && !IS_AGENT) {
  pluginCompression.plugins.push(
    new CompressionPlugin({
      filename: "[path][base].gz",
      algorithm: "gzip",
      test: /\.js$|\.css$|\.html$|\.woff2$/,
      threshold: 10240,
      minRatio: 0.8
    })
  );
}

export default pluginCompression;
