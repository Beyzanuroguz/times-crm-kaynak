import * as fs from "fs";
import * as path from "path";
import { ManifestPluginOptions, RspackManifestPlugin } from "rspack-manifest-plugin";
import { extractRoutePaths } from "../../src/components/web-components/mfe/microapp-route-paths";
import { outputConfig } from "../output-config";

// Interface for Native platform info from native-manifest.json
interface NativePlatformInfo {
  file: string;
  hash: string;
}

// Interface for Native manifest from native-manifest.json
interface NativeManifestFile {
  platforms: {
    [key: string]: NativePlatformInfo;
  };
  timestamp: string;
}

// Interface for Native section in asset manifest
interface NativeManifestSection {
  basePath: string;
  platforms: {
    [key: string]: NativePlatformInfo;
  };
}

// Try to read Native manifest from public directory
function readNativeManifest(): NativeManifestSection | undefined {
  const nativeManifestPath = path.join(process.cwd(), "public", "native", "kuika-core", "native-manifest.json");

  try {
    if (fs.existsSync(nativeManifestPath)) {
      const content = fs.readFileSync(nativeManifestPath, "utf-8");
      const nativeManifest: NativeManifestFile = JSON.parse(content);

      return {
        basePath: "native/kuika-core",
        platforms: nativeManifest.platforms
      };
    }
  } catch (error) {
    console.warn("Failed to read native-manifest.json:", error);
  }

  return undefined;
}

// Read on every emit so a dev-server rebuild after codegen picks up new screens.
// An unreadable router publishes no list, and a host then treats every route-shaped
// hash as before (see microapp-route-paths.ts).
function readRoutePaths(): string[] {
  const routerPath: string = path.join(process.cwd(), "src", "routes", "router.tsx");

  try {
    return extractRoutePaths(fs.readFileSync(routerPath, "utf-8"));
  } catch (error) {
    console.warn("Failed to read routes from router.tsx:", error);
    return [];
  }
}

const config: ManifestPluginOptions = {
  fileName: "asset-manifest.json",
  publicPath: outputConfig.publicPath as string,
  seed: {
    publicPath: outputConfig.publicPath,
    appName: "wbTimesCRM",
    workspace: "reslen_01",
    webComponentTag: "reslen-01-wb-times-crm",
    date: Date.now(),
    backendUrlOverride: "",
    microapps: [], // Will be populated by code generator
    widgets: [] // Will be populated by code generator
  },
  generate: (seed, files, entrypoints) => {
    const entryFiles: {
      [key: string]: { css: string[]; js: string[]; ico: string[]; fonts: string[]; url_3rd_js: string[] };
    } = {};

    // Helper function to extract relative path from file path
    const getRelativePath = (filePath: string): string => {
      const staticIndex = filePath.indexOf("static/");
      if (staticIndex !== -1) {
        return filePath.slice(staticIndex);
      }
      // Fallback: try to get just the filename if no static/ found
      const lastSlash = filePath.lastIndexOf("/");
      return lastSlash !== -1 ? filePath.slice(lastSlash + 1) : filePath;
    };

    // Extract font files from all emitted files (convert to relative paths)
    const fontExtensions = [".woff", ".woff2", ".ttf", ".eot", ".otf"];
    const fontFiles = files
      .filter((file) => fontExtensions.some((ext) => file.path.toLowerCase().endsWith(ext)))
      .map((file) => getRelativePath(file.path));

    // Extract image files from all emitted files (only from static/ directory with hashed names)
    const imageExtensions = [".png", ".jpg", ".jpeg", ".gif", ".svg", ".webp", ".ico", ".bmp"];
    const imageFiles = files
      .filter((file) => {
        const filePath = file.path.toLowerCase();
        // Only include images from static/ directory (processed/hashed assets)
        return filePath.includes("static/") && imageExtensions.some((ext) => filePath.endsWith(ext));
      })
      .map((file) => getRelativePath(file.path));

    Object.entries(entrypoints).forEach(([entry, chunks]) => {
      entryFiles[entry] = {
        css: ["material-icons.min.css", ...chunks.filter((x) => x.endsWith(".css"))],
        js: [...chunks].filter((x) => x.endsWith(".js") && x.match(/(?<!hot-update).js$/) && !x.match(/^nm.kuika.*$/)),
        ico: ["favicon.ico"],
        fonts: fontFiles,
        url_3rd_js: []
      };

      if (entry === "index") {
        entryFiles.app = { ...entryFiles[entry] };
      }
    });

    // Read Native manifest if available and include in output
    const nativeManifest = readNativeManifest();
    const routes: string[] = readRoutePaths();

    return {
      ...seed,
      entryFiles,
      images: imageFiles,
      ...(routes.length > 0 && { routes }),
      ...(nativeManifest && { native: nativeManifest })
    };
  }
  // writeToFileEmit: isDev && !isDevServer
};

export const pluginAssetManifest = new RspackManifestPlugin(config);
