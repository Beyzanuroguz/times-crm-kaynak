import WebpackShellPluginNext from "webpack-shell-plugin-next";

const config = {
  onBeforeBuild: {
    scripts: [
      "bash backup_packages.sh",
      "prettier --write --check src/screens",
      "knip --fix --include nsExports",
      "bash knip-clr.sh",
      "prettier --write --check src/components/web-components/index.ts",
      "prettier --write --check src/kuika/index.ts",
      'echo "                                                                      "',
      'echo "     ...Please wait!                                                  "',
      'echo "     ...Kuika low code platform building your app...                  "',
      'echo "                                                                      "'
    ],
    blocking: true
  },
  onBuildError: {
    scripts: [
      "bash recover_packages.sh",
      'echo "Sorry there was an error, if you don´t know the reason of the error you can contact the kuika team: https://www.kuika.com/company/contact-us"'
    ],
    blocking: true
  },
  onAfterDone: {
    scripts: [
      'echo "01000011 01101111 01100100 01101001 01101110 01100111 00100000 01001101 01100101 01100101 01110100 01110011 00100000 01001001 01101110 01101110 01101111 01110110 01100001 01110100 01101001 01101111 01101110 00100000 01110111 01101001 01110100 01101000 00100000 01001011 01110101 01101001 01101011 01100001 00100001"',
      'echo "                                                                                                                 "',
      'echo "                                                                                                                 "',
      'echo "     ..auKKKKKKKKKKKKKKKKKKKKKKKKKKKKua                                                                          "',
      'echo "    ..aKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKua                                                                        "',
      'echo "   ..aKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKu                                                                       "',
      'echo "   ..aKKKKKKKKKKKKKKKiiKKKKKKKKKKKKKKKKKKi                                                                       "',
      'echo "   ..aKKKKKKKKKKKii     iKKKKKKKKKKKKKKKKi     ..iKKK      KKKu              ..KKi ..aKK                         "',
      'echo "   ..aKKKKKKKKKi       aiKKiuuKKKKKKKKKKKi     ..iKKa    uKKKa               ..KKi ..iKK                         "',
      'echo "   ..aKKKKKKKi       aKKKa       uKKKKKKKi     ..iKKa  uKKKi   ..KKK   ..KKK       ..iKK    ..KK  ..Kuika...     "',
      'echo "   ..aKKKKKK        KKKa           KKKKKKi     ..iKKauKKKi     ..KKi   ..KKK ..KKK ..iKK  ..iKKK  ..iKKKKKKKKa   "',
      'echo "   ..aKKKKK        aKKi             KKKKKi     ..iKKKKKKa      ..KKi   ..KKK ..KKK ..iKK ..KKi        ..aaaKKK   "',
      'echo "   ..aKKKKKa        KKi            iKKKKKi     ..iKKiaKKKK     ..KKi   ..KKK ..KKK ..iKKKKK      ..aiKKKKKKKKK   "',
      'echo "   ..aKKKKKKu        KKKi        aiKKKKKKi     ..iKKa  aKKKu   ..KKi   ..KKK ..KKK ..iKKuaKKa    ..KKK     KKK   "',
      'echo "   ..aKKKKKKKKu        KKKKiaaauKKKKKKKKKi     ..iKKa    uKKKa ..KKKKKKiKKKK ..K&K ..iKK  ..iKKK ..KKKKKKKKKKK   "',
      'echo "   ..aKKKKKKKKKKKa       KKKKKKKKKKKKKKKKi     ..aKiK      iKKK ..iiKKKKKaii ..KKu ..aKi    ..KKK ..uKKKKiaiKi   "',
      'echo "   ..aKKKKKKKKKKKKKiuiiuKKKKKKKKKKKKKKKKKi                                                                       "',
      'echo "   ..aKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKa                                                                       "',
      'echo "    ..aKKKKKKKK www.kuika.com KKKKKKKKKKa                                                                        "',
      'echo "     ..aKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKa                                   .POWERED BY KUIKA LOW CODE PLATFORM.  "',
      'echo "                                                                            https://www.kuika.com/               "',
      'echo "                                                                                                                 "',
      'echo "                                                                                                                 "',
      'echo "01000011 01101111 01100100 01101001 01101110 01100111 00100000 01001101 01100101 01100101 01110100 01110011 00100000 01001001 01101110 01101110 01101111 01110110 01100001 01110100 01101001 01101111 01101110 00100000 01110111 01101001 01110100 01101000 00100000 01001011 01110101 01101001 01101011 01100001 00100001"'
    ],
    blocking: true
  }
};

export default {
  plugins: [new WebpackShellPluginNext(config)]
};
