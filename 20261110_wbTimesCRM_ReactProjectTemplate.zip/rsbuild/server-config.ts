import fs from "fs";
import { RsbuildConfig } from "@rsbuild/core";
import { IS_SSL_ENABLED, SERVER_PORT } from "./build-env";

export const serverConfig: RsbuildConfig["server"] = {
  host: "0.0.0.0",
  port: SERVER_PORT,
  headers: {
    "Access-Control-Allow-Origin": "*",
    "Access-Control-Allow-Methods": "GET, POST, PUT, DELETE, PATCH, OPTIONS",
    "Access-Control-Allow-Headers": "X-Requested-With, content-type, Authorization"
  },
  historyApiFallback: {
    // Disable fallback for widget and static asset requests
    rewrites: [
      // Widget requests should not fallback to index.html
      { from: /^\/widgets\//, to: (context) => context.parsedUrl.pathname as string }
    ],
    // Only apply fallback to HTML requests (not .json, .js, .css, etc.)
    disableDotRule: true
  },
  https:
    IS_SSL_ENABLED === true
      ? (() => {
          const certPath: string = "./certs/localhost_3002.crt";
          const keyPath: string = "./certs/localhost_3002.key";

          if (!fs.existsSync(certPath)) {
            throw new Error(`SSL is enabled but certificate file not found at: ${certPath}`);
          }

          if (!fs.existsSync(keyPath)) {
            throw new Error(`SSL is enabled but key file not found at: ${keyPath}`);
          }

          return {
            cert: fs.readFileSync(certPath, "utf8"),
            key: fs.readFileSync(keyPath, "utf8")
          };
        })()
      : undefined
};
