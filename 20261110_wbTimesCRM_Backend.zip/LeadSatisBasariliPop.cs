
using Kuika.Common;
using Kuika.Common.Attributes;
using Kuika.Common.Bases;
using Kuika.Common.Enums;
using Kuika.Common.Accessors;
using Kuika.Common.Json;
using Kuika.Common.Classes;
using Kuika.Common.Exceptions;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Kuika.Common.Helpers;
using Kuika.Common.Settings;
using System.Collections.Generic;
using System;
using Kuika.Common.Extensions;
using System.Linq;
using Kuika.Common.Rest;
using WorkflowCore.Interface;
using Kuika.Common.Interfaces;
using Kuika.Common.Workflow;
using Kuika.Common.Workflow.Extensions;
using Kuika.Common.Workflow.DTOs;
using Kuika.Common.Models;
using Kuika.Common.Menu.Response;
using Kuika.Common.Entities;
using System.Reflection;
using Newtonsoft.Json.Linq;
using Newtonsoft.Json;
using System.Net.Http;
using Iyzipay.Model.V2.Subscription;
using Kuika.Common.Payments.Iyzico;
using Kuika.Common.Payments.Param;
using Iyzipay;
using Kuika.Common.Searching.DTOs;
using Kuika.Common.Helpers.Sap;
using Kuika.Common.Mcp;
using Kuika.Common.Vision.DTOs;
using Kuika.Common.Audit;
using Kuika.Common.Payments.Mobile;
using Kuika.ThirdPartyApisCollection;

namespace Kuika.Reslen_01.Api
{
    [ApiExplorerSettings(GroupName = "all")]
    [Authorize]
    [ApiController]
    [Route("v1/api/LeadSatisBasariliPop")]
    public class LeadSatisBasariliPop_Controller : KControllerBase
    {
        private string appName = "wbTimesCRM";
        private Guid appId = Guid.Parse("0e8ecb48-8c52-463c-5db5-08de3ec441b1");
        private static string screenName = "LeadSatisBasariliPop";
        private Guid screenId = Guid.Parse("c101c1b7-5971-406c-877e-18ce9db09e36");
        private string connectionString { get { return Kuika.Common.KContext.GetConnectionString(); } }

        [HttpGet, Route("myroles")]
        public IActionResult GetMyRoles()
        {
            try
            {
                var result = KProviderManager.Authorization.GetMyRoles(appId, appName, screenId, screenName);
                return Ok(result);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new HttpExceptionDto() { Message = ex.Message, StackTrace = ex.StackTrace });
            }
        }


        [HttpPost, Route("LeadSatisBasariliPopPageInit")]
        public IActionResult LeadSatisBasariliPopPageInit(LeadSatisBasariliPopPageInit_Request request)
        {

            var result = new LeadSatisBasariliPopPageInit_Response();

            var prms_GetLeadSalesBasariliInfo_0 = new List<kSqlParameter>();
            prms_GetLeadSalesBasariliInfo_0.Add(new kSqlParameter() { Name = "SalesDraftId", Value = request.SalesDraftId_0 });
            using var auditGetLeadSalesBasariliInfo_0 = ActionAuditScope.Begin("97f08344-a9b5-ad5e-50d2-2aa877d74577", "GetLeadSalesBasariliInfo", applicationName: "wbTimesCRM", screenOrEndpointName: "LeadSatisBasariliPop");
            result.GetLeadSalesBasariliInfo = KPersister.Fetch(KContext.GetConnectionString(), @"

SELECT
    -- Lead No
    LeadNo = ISNULL(l.LeadCode, ''),
    LeadId = l.Id,


    -- Satış Personeli
    SatisPersoneli = ISNULL(tu.FullName, ''),
    -- Fatura Ref No
FaturaRefNo = ISNULL(sld.InvoiceNumber, ''),

    -- Satış Tarihi
    SatisTarihi = sld.InvoiceDate,

    -- Ürün
    Urun = ISNULL((
        SELECT STRING_AGG(x.ProductName, ', ')
        FROM
        (
            SELECT DISTINCT
                ProductName = ISNULL(sldd.ProductName, '')
            FROM tmscrq.TMSalesLeadDraftDetail sldd
            WHERE sldd.SalesDraftId = sld.Id
              AND ISNULL(sldd.ProductName, '') <> ''
        ) x
    ), ''),

    -- Seri No
    SeriNo = ISNULL((
        SELECT STRING_AGG(x.SeriNo, ', ')
        FROM
        (
            SELECT DISTINCT
                SeriNo = ISNULL(sldd.SeriNo, '')
            FROM tmscrq.TMSalesLeadDraftDetail sldd
            WHERE sldd.SalesDraftId = sld.Id
              AND ISNULL(sldd.SeriNo, '') <> ''
        ) x
    ), ''),

    -- Müşteri Adı
    MusteriAdi = LTRIM(RTRIM(
        ISNULL(c.Name, '') + ' ' + ISNULL(c.LastName, '')
    )),

    -- Telefon
    TelefonNo = ISNULL(c.Tel, ''),

    -- Satış Tutarı
    SatisTutari = ISNULL(sld.TotalAmountEUR, 0),

    -- Mağaza
    Magaza = ISNULL(ts.StoreDesc, ''),

    -- Ödeme Tipi
    -- Birden fazla ödeme varsa:
    -- Kredi Kartı, Banka, Nakit
    OdemeTipi = ISNULL((
        SELECT STRING_AGG(x.PaymentTypeDesc, ', ')
        FROM
        (
            SELECT DISTINCT
                PaymentTypeDesc =
                    ISNULL(
                        NULLIF(sldp.PaymentTypeDesc, ''),
                        NULLIF(sldp.PaymentType, '')
                    )
            FROM tmscrq.TMSalesLeadDraftPayment sldp
            WHERE sldp.SalesDraftId = sld.Id
              AND (
                    ISNULL(sldp.PaymentTypeDesc, '') <> ''
                    OR ISNULL(sldp.PaymentType, '') <> ''
                  )
        ) x
    ), ''),

    -- Lead Durumu
    Durum = ISNULL(lp.Name, '')

FROM tmscrq.TMSalesLeadDraft sld

LEFT JOIN tmscrq.TMLead l
    ON l.Id = sld.LeadId

LEFT JOIN tmscrq.TMCustomer c
    ON c.Id = sld.CustomerId

LEFT JOIN tmscrq.TMUser tu
    ON tu.Id = sld.SalesPersonId

LEFT JOIN tmscrq.TMStore ts
    ON ts.StoreCode = sld.StoreCode

LEFT JOIN tmscrq.TMLeadProcess lp
    ON lp.Id = l.ProcessID

WHERE sld.Id = @SalesDraftId;", new string[] { "LeadNo", "LeadId", "SatisPersoneli", "FaturaRefNo", "SatisTarihi", "Urun", "SeriNo", "MusteriAdi", "TelefonNo", "SatisTutari", "Magaza", "OdemeTipi", "Durum" }, prms_GetLeadSalesBasariliInfo_0.ToArray());
            ;


            return Ok(result);
        }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class LeadSatisBasariliPopPageInit_Request
    {
        public Guid? SalesDraftId_0 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class LeadSatisBasariliPopPageInit_Response
    {
        public KCommonEntityPage GetLeadSalesBasariliInfo { set; get; }

    }
}
