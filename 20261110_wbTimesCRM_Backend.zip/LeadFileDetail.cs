
using Kuika.Common;
using Kuika.Common.Attributes;
using Kuika.Common.Bases;
using Kuika.Common.Enums;
using Kuika.Common.Accessors;
using Kuika.Common.Json;
using Kuika.Common.Classes;
using Kuika.Common.Exceptions;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Kuika.Common.Helpers;
using Kuika.Common.Settings;
using System.Collections.Generic;
using System;
using Kuika.Common.Extensions;
using System.Linq;
using Kuika.Common.Rest;
using WorkflowCore.Interface;
using Kuika.Common.Interfaces;
using Kuika.Common.Workflow;
using Kuika.Common.Workflow.Extensions;
using Kuika.Common.Workflow.DTOs;
using Kuika.Common.Models;
using Kuika.Common.Menu.Response;
using Kuika.Common.Entities;
using System.Reflection;
using Newtonsoft.Json.Linq;
using Newtonsoft.Json;
using System.Net.Http;
using Iyzipay.Model.V2.Subscription;
using Kuika.Common.Payments.Iyzico;
using Kuika.Common.Payments.Param;
using Iyzipay;
using Kuika.Common.Searching.DTOs;
using Kuika.Common.Helpers.Sap;
using Kuika.Common.Mcp;
using Kuika.Common.Vision.DTOs;
using Kuika.Common.Audit;
using Kuika.Common.Payments.Mobile;
using Kuika.ThirdPartyApisCollection;

namespace Kuika.Reslen_01.Api
{
    [ApiExplorerSettings(GroupName = "all")]
    [Authorize]
    [ApiController]
    [Route("v1/api/LeadFileDetail")]
    public class LeadFileDetail_Controller : KControllerBase
    {
        private string appName = "wbTimesCRM";
        private Guid appId = Guid.Parse("0e8ecb48-8c52-463c-5db5-08de3ec441b1");
        private static string screenName = "LeadFileDetail";
        private Guid screenId = Guid.Parse("25557981-b431-450b-9316-becaabc93c6e");
        private string connectionString { get { return Kuika.Common.KContext.GetConnectionString(); } }

        [HttpGet, Route("myroles")]
        public IActionResult GetMyRoles()
        {
            try
            {
                var result = KProviderManager.Authorization.GetMyRoles(appId, appName, screenId, screenName);
                return Ok(result);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new HttpExceptionDto() { Message = ex.Message, StackTrace = ex.StackTrace });
            }
        }


        [HttpPost, Route("LeadFileDetailPageInit")]
        public IActionResult LeadFileDetailPageInit(LeadFileDetailPageInit_Request request)
        {

            var result = new LeadFileDetailPageInit_Response();

            var prms_TM_GetLeadFilesByNoteId_0 = new List<kSqlParameter>();
            prms_TM_GetLeadFilesByNoteId_0.Add(new kSqlParameter() { Name = "LeadId", Value = request.LeadId_0 });
            using var auditTM_GetLeadFilesByNoteId_0 = ActionAuditScope.Begin("048695e4-f199-4234-a869-110f60a5e0e9", "TM_GetLeadFilesByNoteId", applicationName: "wbTimesCRM", screenOrEndpointName: "LeadFileDetail");
            result.TM_GetLeadFilesByNoteId = KPersister.Fetch(KContext.GetConnectionString(), @"SELECT
    lf.Id,
    lf.CreatedAt,

    --------------------------------------------------
    -- 🔥 GÜNCELLENDİ (ID → AD SOYAD)
    --------------------------------------------------
    LTRIM(RTRIM(
        ISNULL(u.FirstName, '') +
        CASE
            WHEN u.LastName IS NOT NULL AND LTRIM(RTRIM(u.LastName)) <> ''
            THEN ' ' + u.LastName
            ELSE ''
        END
    )) AS CreatedBy,
    --------------------------------------------------

    lf.FileName,
    lf.FileSize,
    lf.FileType,
    lf.FileData,      
    lf.LeadNoteId

FROM tmscrq.TMLeadFile lf

--------------------------------------------------
-- 🔥 EKLENEN JOIN
--------------------------------------------------
LEFT JOIN dbo.KUser u 
    ON u.Id = lf.CreatedBy
--------------------------------------------------

WHERE lf.LeadId = @LeadId
  AND ISNULL(lf.IsDeleted, 0) = 0

ORDER BY lf.CreatedAt DESC;", new string[] { "Id", "CreatedAt", "CreatedBy", "FileName", "FileSize", "FileType", "FileData", "LeadNoteId" }, prms_TM_GetLeadFilesByNoteId_0.ToArray());
            ;

            var prms_TM_GetLeadNoteFileCounts_1 = new List<kSqlParameter>();
            prms_TM_GetLeadNoteFileCounts_1.Add(new kSqlParameter() { Name = "LeadId", Value = request.LeadId_1 });
            using var auditTM_GetLeadNoteFileCounts_1 = ActionAuditScope.Begin("be249c7f-8c7f-ae69-1150-292c48571d54", "TM_GetLeadNoteFileCounts", applicationName: "wbTimesCRM", screenOrEndpointName: "LeadFileDetail");
            result.TM_GetLeadNoteFileCounts = KPersister.Fetch(KContext.GetConnectionString(), @"SELECT
    (SELECT COUNT(*) 
     FROM tmscrq.TMLeadNote 
     WHERE LeadId = @LeadId AND ISNULL(IsDeleted,0)=0) AS NoteCount,

    (SELECT COUNT(*) 
     FROM tmscrq.TMLeadFile 
     WHERE LeadId = @LeadId AND ISNULL(IsDeleted,0)=0) AS FileCount;", new string[] { "NoteCount", "FileCount" }, prms_TM_GetLeadNoteFileCounts_1.ToArray());
            ;


            return Ok(result);
        }


        [HttpPost, Route("LeadFileDetailComponent_479603_onClick1_")]
        public IActionResult LeadFileDetailComponent_479603_onClick1_(LeadFileDetailComponent_479603_onClick1__Request request)
        {

            var result = new LeadFileDetailComponent_479603_onClick1__Response();

            var prms_TM_AddLeadFile_0 = new List<kSqlParameter>();
            prms_TM_AddLeadFile_0.Add(new kSqlParameter() { Name = "LeadId", Value = request.LeadId_0 });
            prms_TM_AddLeadFile_0.Add(new kSqlParameter() { Name = "CreatedBy", Value = Kuika.Common.KContext.CurrentUser?.Id });
            prms_TM_AddLeadFile_0.Add(new kSqlParameter() { Name = "FileData", Value = request.FileData_0 });
            prms_TM_AddLeadFile_0.Add(new kSqlParameter() { Name = "FileName", Value = request.FileName_0 });
            prms_TM_AddLeadFile_0.Add(new kSqlParameter() { Name = "FileSize", Value = request.FileSize_0 });
            prms_TM_AddLeadFile_0.Add(new kSqlParameter() { Name = "FileType", Value = request.FileType_0 });
            prms_TM_AddLeadFile_0.Add(new kSqlParameter() { Name = "LeadNoteId", Value = (null as object) });
            prms_TM_AddLeadFile_0.Add(new kSqlParameter() { Name = "TRANCOUNT", Value = "0".ConvertToType<Int32>() });
            using var auditTM_AddLeadFile_0 = ActionAuditScope.Begin("8bc2f982-1776-4a7d-f8bf-b1cd1c4bebe7", "TM_AddLeadFile", applicationName: "wbTimesCRM", screenOrEndpointName: "LeadFileDetail");
            result.TM_AddLeadFile = KPersister.Fetch(KContext.GetConnectionString(), @"BEGIN TRY
    BEGIN TRAN;

    -- 🔹 Lead kontrolü
    IF NOT EXISTS (
        SELECT 1 
        FROM tmscrq.TMLead
        WHERE Id = @LeadId
    )
    BEGIN
        RAISERROR(N'Geçersiz LeadId.',16,1);
    END;

    -- 🔹 INSERT
    INSERT INTO tmscrq.TMLeadFile
    (
        Id,
        CreatedAt,
        CreatedBy,
        FileData,
        FileName,
        FileSize,
        FileType,
        IsDeleted,
        LeadId,
        LeadNoteId
    )
    VALUES
    (
        NEWID(),
        SYSDATETIMEOFFSET(),
        @CreatedBy,
        @FileData,        -- 🔥 DOSYA DATA
        @FileName,
        @FileSize,
        @FileType,
        0,
        @LeadId,
        @LeadNoteId       -- NULL olabilir
    );

    COMMIT;

    SELECT 
        1 AS Success,
        N'Dosya başarıyla eklendi.' AS Message;

END TRY
BEGIN CATCH
    IF @@TRANCOUNT > 0 ROLLBACK;

    SELECT 
        0 AS Success,
        ERROR_MESSAGE() AS Message;
END CATCH;", new string[] { "Success", "Message" }, prms_TM_AddLeadFile_0.ToArray());
            ;


            return Ok(result);
        }


        [HttpPost, Route("LeadFileDetailComponent_929699_onClick")]
        public IActionResult LeadFileDetailComponent_929699_onClick(LeadFileDetailComponent_929699_onClick_Request request)
        {

            var result = new LeadFileDetailComponent_929699_onClick_Response();

            var prms_TM_DeleteLeadFile_0 = new List<kSqlParameter>();
            prms_TM_DeleteLeadFile_0.Add(new kSqlParameter() { Name = "FileId", Value = request.FileId_0 });
            prms_TM_DeleteLeadFile_0.Add(new kSqlParameter() { Name = "TRANCOUNT", Value = "0".ConvertToType<Int32>() });
            using var auditTM_DeleteLeadFile_0 = ActionAuditScope.Begin("952045c6-2518-b132-53a3-ff12bbfde2ae", "TM_DeleteLeadFile", applicationName: "wbTimesCRM", screenOrEndpointName: "LeadFileDetail");
            result.TM_DeleteLeadFile = KPersister.Fetch(KContext.GetConnectionString(), @"BEGIN TRY
    BEGIN TRAN;

    -- 🔹 Önce dosyayı bul (eşleşme için lazım)
    DECLARE @FileName NVARCHAR(500);
    DECLARE @FileSize BIGINT;
    DECLARE @CreatedBy UNIQUEIDENTIFIER;
    DECLARE @LeadId UNIQUEIDENTIFIER;

    SELECT 
        @FileName = FileName,
        @FileSize = FileSize,
        @CreatedBy = CreatedBy,
        @LeadId = LeadId
    FROM tmscrq.TMLeadFile
    WHERE Id = @FileId
      AND ISNULL(IsDeleted,0) = 0;

    -- 🔹 Eğer kayıt yoksa hata ver
    IF @FileName IS NULL
    BEGIN
        RAISERROR(N'Dosya bulunamadı.',16,1);
    END;

    -- 🔹 MAIN TABLO (TMLeadFile) SOFT DELETE
    UPDATE tmscrq.TMLeadFile
    SET IsDeleted = 1
    WHERE Id = @FileId;

    -- 🔹 TEMP TABLODA AYNI DOSYAYI BUL VE SİL
    UPDATE tmscrq.TMLeadFileTemp
    SET IsDeleted = 1
    WHERE FileName = @FileName
      AND FileSize = @FileSize
      AND CreatedBy = @CreatedBy
      AND LeadId = @LeadId
      AND ISNULL(IsDeleted,0) = 0;

    COMMIT;

    SELECT 
        1 AS Success,
        N'Dosya başarıyla silindi.' AS Message;

END TRY
BEGIN CATCH
    IF @@TRANCOUNT > 0 ROLLBACK;

    SELECT 
        0 AS Success,
        ERROR_MESSAGE() AS Message;
END CATCH;", new string[] { "Success", "Message" }, prms_TM_DeleteLeadFile_0.ToArray());
            ;

            var prms_TM_GetLeadFilesByNoteId_1 = new List<kSqlParameter>();
            prms_TM_GetLeadFilesByNoteId_1.Add(new kSqlParameter() { Name = "LeadId", Value = request.LeadId_1 });
            using var auditTM_GetLeadFilesByNoteId_1 = ActionAuditScope.Begin("eec6555f-afcc-87e0-f24c-28b0e256a2c1", "TM_GetLeadFilesByNoteId", applicationName: "wbTimesCRM", screenOrEndpointName: "LeadFileDetail");
            result.TM_GetLeadFilesByNoteId = KPersister.Fetch(KContext.GetConnectionString(), @"SELECT
    lf.Id,
    lf.CreatedAt,

    --------------------------------------------------
    -- 🔥 GÜNCELLENDİ (ID → AD SOYAD)
    --------------------------------------------------
    LTRIM(RTRIM(
        ISNULL(u.FirstName, '') +
        CASE
            WHEN u.LastName IS NOT NULL AND LTRIM(RTRIM(u.LastName)) <> ''
            THEN ' ' + u.LastName
            ELSE ''
        END
    )) AS CreatedBy,
    --------------------------------------------------

    lf.FileName,
    lf.FileSize,
    lf.FileType,
    lf.FileData,      
    lf.LeadNoteId

FROM tmscrq.TMLeadFile lf

--------------------------------------------------
-- 🔥 EKLENEN JOIN
--------------------------------------------------
LEFT JOIN dbo.KUser u 
    ON u.Id = lf.CreatedBy
--------------------------------------------------

WHERE lf.LeadId = @LeadId
  AND ISNULL(lf.IsDeleted, 0) = 0

ORDER BY lf.CreatedAt DESC;", new string[] { "Id", "CreatedAt", "CreatedBy", "FileName", "FileSize", "FileType", "FileData", "LeadNoteId" }, prms_TM_GetLeadFilesByNoteId_1.ToArray());
            ;


            return Ok(result);
        }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class LeadFileDetailPageInit_Request
    {
        public Guid? LeadId_0 { set; get; }
        public Guid? LeadId_1 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class LeadFileDetailPageInit_Response
    {
        public KCommonEntityPage TM_GetLeadFilesByNoteId { set; get; }

        public KCommonEntityPage TM_GetLeadNoteFileCounts { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class LeadFileDetailComponent_479603_onClick1__Request
    {
        public Guid? LeadId_0 { set; get; }
        public Guid? CreatedBy_0 { set; get; }
        public String FileData_0 { set; get; }
        public String FileName_0 { set; get; }
        public Int32? FileSize_0 { set; get; }
        public String FileType_0 { set; get; }
        public Guid? LeadNoteId_0 { set; get; }
        public Int32? TRANCOUNT_0 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class LeadFileDetailComponent_479603_onClick1__Response
    {
        public KCommonEntityPage TM_AddLeadFile { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class LeadFileDetailComponent_929699_onClick_Request
    {
        public Guid? FileId_0 { set; get; }
        public Int32? TRANCOUNT_0 { set; get; }
        public Guid? LeadId_1 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class LeadFileDetailComponent_929699_onClick_Response
    {
        public KCommonEntityPage TM_DeleteLeadFile { set; get; }

        public KCommonEntityPage TM_GetLeadFilesByNoteId { set; get; }

    }
}
