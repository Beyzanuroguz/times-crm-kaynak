
using System;
using Kuika.Common;
using Kuika.Common.Bases;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Kuika.Common.Interfaces;
using Kuika.Common.Menu.Request;
using Kuika.Common.Enums;
using Kuika.Common.Attributes;

namespace Kuika.App.Controllers
{   
    [ApiExplorerSettings(GroupName = "all")]   
    [ApiController]
    [Route("v1/api/[controller]")]
    public class MenuItemController : KControllerBase
    {

        #region ..Constructors..

        public MenuItemController() : base() { }

        #endregion

        #region ..Apis..

        [AllowAnonymous]
        [HttpGet("all")]
        public IActionResult GetAllMenuItems()
        {
            var result = KProviderManager.GetInstance<IMenuRegistry>().GetAllMenuItems();
            return Ok(result);
        }

        [Authorize]
        [KAuthorization(EGeneratedAppAccessCodes.get_authorized_menu_items)]
        [HttpGet("authorized")]
        public IActionResult GetAuthorizedMenuItems()
        {
            var result = KProviderManager.GetInstance<IMenuRegistry>().GetAuthorizedMenuItems();
            return Ok(result);
        }

        [Authorize]
        [KAuthorization(EGeneratedAppAccessCodes.save_menu_item)]
        [HttpPost()]
        public IActionResult SaveMenuItem([FromBody] MenuSaveRequest request)
        {
            KProviderManager.GetInstance<IMenuRegistry>().SaveMenuItem(request);
            return Ok();
        }

        [Authorize]
        [KAuthorization(EGeneratedAppAccessCodes.remove_menu)]
        [HttpDelete()]
        public IActionResult RemoveMenu([FromQuery] Guid id)
        {
            KProviderManager.GetInstance<IMenuRegistry>().RemoveMenuItem(id);
            return Ok();
        }        
        
        #endregion

    }
}