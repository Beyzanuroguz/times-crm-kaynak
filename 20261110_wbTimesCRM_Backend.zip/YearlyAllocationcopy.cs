
using Kuika.Common;
using Kuika.Common.Attributes;
using Kuika.Common.Bases;
using Kuika.Common.Enums;
using Kuika.Common.Accessors;
using Kuika.Common.Json;
using Kuika.Common.Classes;
using Kuika.Common.Exceptions;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Kuika.Common.Helpers;
using Kuika.Common.Settings;
using System.Collections.Generic;
using System;
using Kuika.Common.Extensions;
using System.Linq;
using Kuika.Common.Rest;
using WorkflowCore.Interface;
using Kuika.Common.Interfaces;
using Kuika.Common.Workflow;
using Kuika.Common.Workflow.Extensions;
using Kuika.Common.Workflow.DTOs;
using Kuika.Common.Models;
using Kuika.Common.Menu.Response;
using Kuika.Common.Entities;
using System.Reflection;
using Newtonsoft.Json.Linq;
using Newtonsoft.Json;
using System.Net.Http;
using Iyzipay.Model.V2.Subscription;
using Kuika.Common.Payments.Iyzico;
using Kuika.Common.Payments.Param;
using Iyzipay;
using Kuika.Common.Searching.DTOs;
using Kuika.Common.Helpers.Sap;
using Kuika.Common.Mcp;
using Kuika.Common.Vision.DTOs;
using Kuika.Common.Audit;
using Kuika.Common.Payments.Mobile;
using Kuika.ThirdPartyApisCollection;

namespace Kuika.Reslen_01.Api
{
    [ApiExplorerSettings(GroupName = "all")]
    [Authorize]
    [ApiController]
    [Route("v1/api/YearlyAllocationcopy")]
    public class YearlyAllocationcopy_Controller : KControllerBase
    {
        private string appName = "wbTimesCRM";
        private Guid appId = Guid.Parse("0e8ecb48-8c52-463c-5db5-08de3ec441b1");
        private static string screenName = "YearlyAllocationcopy";
        private Guid screenId = Guid.Parse("b74fbba4-3537-4cdd-86f8-774e9b8c2f68");
        private string connectionString { get { return Kuika.Common.KContext.GetConnectionString(); } }

        [HttpGet, Route("myroles")]
        public IActionResult GetMyRoles()
        {
            try
            {
                var result = KProviderManager.Authorization.GetMyRoles(appId, appName, screenId, screenName);
                return Ok(result);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new HttpExceptionDto() { Message = ex.Message, StackTrace = ex.StackTrace });
            }
        }


        [HttpPost, Route("YearlyAllocationcopyPageInit")]
        public IActionResult YearlyAllocationcopyPageInit(YearlyAllocationcopyPageInit_Request request)
        {

            var result = new YearlyAllocationcopyPageInit_Response();

            var prms_TM_TotalVerifyExcel_0 = new List<kSqlParameter>();
            prms_TM_TotalVerifyExcel_0.Add(new kSqlParameter() { Name = "Year", Value = request.Year_0 });
            using var auditTM_TotalVerifyExcel_0 = ActionAuditScope.Begin("18ae89d3-9086-1428-561b-d2305798c64b", "TM_TotalVerifyExcel", applicationName: "wbTimesCRM", screenOrEndpointName: "YearlyAllocationcopy");
            result.TM_TotalVerifyExcel = KPersister.Fetch(KContext.GetConnectionString(), @"

-- Tek sorguda tablo + kota kontrolü
SELECT 
    t.*,
    -- Tüm mağazaların toplamı
    (ISNULL(adana,0) + ISNULL(antalya,0) + ISNULL(gaziantep,0) + ISNULL(merkez,0) + ISNULL(mersin,0)) AS StoreTotal,
    -- Objective toplamı
    (ISNULL(objective,0) + ISNULL(objectiveDisinda,0)) AS ObjectiveTotal,
    -- Fark
    (ISNULL(objective,0) + ISNULL(objectiveDisinda,0)) 
      - (ISNULL(adana,0) + ISNULL(antalya,0) + ISNULL(gaziantep,0) + ISNULL(merkez,0) + ISNULL(mersin,0)) AS Diff,
    -- Kota durumu
    CASE 
        WHEN (ISNULL(objective,0) + ISNULL(objectiveDisinda,0)) 
             - (ISNULL(adana,0) + ISNULL(antalya,0) + ISNULL(gaziantep,0) + ISNULL(merkez,0) + ISNULL(mersin,0)) < 0
        THEN 'Kota aşımı: ' + CAST(ABS(
                 (ISNULL(objective,0) + ISNULL(objectiveDisinda,0)) 
                 - (ISNULL(adana,0) + ISNULL(antalya,0) + ISNULL(gaziantep,0) + ISNULL(merkez,0) + ISNULL(mersin,0))
             ) AS NVARCHAR(20)) + ' adet'
        ELSE 'Kota aşımı yok'
    END AS KotaDurumu,
    -- Result bit (1 = aşım, 0 = yok)
    CASE 
        WHEN (ISNULL(objective,0) + ISNULL(objectiveDisinda,0)) 
             - (ISNULL(adana,0) + ISNULL(antalya,0) + ISNULL(gaziantep,0) + ISNULL(merkez,0) + ISNULL(mersin,0)) < 0
        THEN 1
        ELSE 0
    END AS Result
FROM tmscrq.TM_ImportExcelPortfVerify t
WHERE UPPER(LTRIM(RTRIM(Reference))) = 'TOTAL'
  AND Yearn = @Year;
", new string[] { "Id", "Adana", "AdanaKalan", "Antalya", "AntalyaKalan", "Gaziantep", "GaziantepKalan", "Merkez", "MerkezKalan", "Mersin", "MersinKalan", "Objective", "ObjectiveDisinda", "Reference", "Yearn", "StoreTotal", "ObjectiveTotal", "Diff", "KotaDurumu", "Result" }, prms_TM_TotalVerifyExcel_0.ToArray());
            ;

            var prms_Action1_1 = new List<kSqlParameter>();
            prms_Action1_1.Add(new kSqlParameter() { Name = "Yearn", Value = request.Yearn_1 });
            prms_Action1_1.Add(new kSqlParameter() { Name = "RefNo", Value = (null as object) });
            using var auditAction1_1 = ActionAuditScope.Begin("af5e2e41-a515-ddcf-87a6-e73e6e1da5a9", "Action1", applicationName: "wbTimesCRM", screenOrEndpointName: "YearlyAllocationcopy");
            result.Action1 = KPersister.Fetch(KContext.GetConnectionString(), @"SELECT
    sas.RefNo AS UrunKodu,

    -- Yıllık Tahsis (ürün bazında)
    MAX(sas.AllocatedQuantity) AS YıllıkTahsisMiktarı,

    -- Kalan Stok = Tahsis - Toplam Kullanılan
    MAX(sas.AllocatedQuantity) - SUM(ISNULL(sas.UseStock, 0)) AS KalanStok,

    -- Mağaza Bazlı Kullanılan Stok
    SUM(CASE WHEN sas.StoreName = 'Merkez'     THEN ISNULL(sas.UseStock, 0) ELSE 0 END) AS MerkezOfis,
    SUM(CASE WHEN sas.StoreName = 'Gaziantep' THEN ISNULL(sas.UseStock, 0) ELSE 0 END) AS Gaziantep,
    SUM(CASE WHEN sas.StoreName = 'Antalya'   THEN ISNULL(sas.UseStock, 0) ELSE 0 END) AS Antalya,
    SUM(CASE WHEN sas.StoreName = 'Adana'     THEN ISNULL(sas.UseStock, 0) ELSE 0 END) AS Adana,
    SUM(CASE WHEN sas.StoreName = 'Mersin'    THEN ISNULL(sas.UseStock, 0) ELSE 0 END) AS Mersin

FROM tmscrq.TMStoreAnnualStock sas
WHERE sas.Yearn = @Yearn
  AND (@RefNo IS NULL OR sas.RefNo = @RefNo)
  AND sas.RefNo <> 'TOTAL'  -- TOTAL satırını hariç tut
GROUP BY sas.RefNo
ORDER BY sas.RefNo;
", new string[] { "UrunKodu", "YıllıkTahsisMiktarı", "KalanStok", "MerkezOfis", "Gaziantep", "Antalya", "Adana", "Mersin" }, prms_Action1_1.ToArray());
            ;

            var prms_TM_GetAnnualProductReferences_2 = new List<kSqlParameter>();
            prms_TM_GetAnnualProductReferences_2.Add(new kSqlParameter() { Name = "Yearn", Value = request.Yearn_2 });
            using var auditTM_GetAnnualProductReferences_2 = ActionAuditScope.Begin("30e3033a-5f78-8b13-1323-0f34e5bd9801", "TM_GetAnnualProductReferences", applicationName: "wbTimesCRM", screenOrEndpointName: "YearlyAllocationcopy");
            result.TM_GetAnnualProductReferences = KPersister.Fetch(KContext.GetConnectionString(), @"SELECT
    sas.RefNo
FROM tmscrq.TMStoreAnnualStock sas
WHERE sas.Yearn = @Yearn
GROUP BY sas.RefNo
ORDER BY sas.RefNo;
", new string[] { "RefNo" }, prms_TM_GetAnnualProductReferences_2.ToArray());
            ;

            var prms_TM_YearlyStockControlByStore_3 = new List<kSqlParameter>();
            prms_TM_YearlyStockControlByStore_3.Add(new kSqlParameter() { Name = "Year", Value = request.Year_3 });
            using var auditTM_YearlyStockControlByStore_3 = ActionAuditScope.Begin("0380b866-c27b-c16c-8685-bb231b72c5f5", "TM_YearlyStockControlByStore", applicationName: "wbTimesCRM", screenOrEndpointName: "YearlyAllocationcopy");
            result.TM_YearlyStockControlByStore = KPersister.Fetch(KContext.GetConnectionString(), @"
WITH StoreTotals AS (
    SELECT 
        'Adana' AS StoreName, SUM(ISNULL(UseStock,0)) AS TotalUsed
    FROM tmscrq.TMStoreAnnualStock
    WHERE Yearn = @Year AND StoreName = 'Adana' AND RefNo <> 'TOTAL'
    UNION ALL
    SELECT 'Antalya', SUM(ISNULL(UseStock,0))
    FROM tmscrq.TMStoreAnnualStock
    WHERE Yearn = @Year AND StoreName = 'Antalya' AND RefNo <> 'TOTAL'
    UNION ALL
    SELECT 'Gaziantep', SUM(ISNULL(UseStock,0))
    FROM tmscrq.TMStoreAnnualStock
    WHERE Yearn = @Year AND StoreName = 'Gaziantep' AND RefNo <> 'TOTAL'
    UNION ALL
    SELECT 'Merkez', SUM(ISNULL(UseStock,0))
    FROM tmscrq.TMStoreAnnualStock
    WHERE Yearn = @Year AND StoreName = 'Merkez' AND RefNo <> 'TOTAL'
    UNION ALL
    SELECT 'Mersin', SUM(ISNULL(UseStock,0))
    FROM tmscrq.TMStoreAnnualStock
    WHERE Yearn = @Year AND StoreName = 'Mersin' AND RefNo <> 'TOTAL'
)
SELECT 
    st.StoreName,
    st.TotalUsed AS KullanilanStok,
    CASE st.StoreName
        WHEN 'Adana' THEN imp.Adana
        WHEN 'Antalya' THEN imp.Antalya
        WHEN 'Gaziantep' THEN imp.Gaziantep
        WHEN 'Merkez' THEN imp.Merkez
        WHEN 'Mersin' THEN imp.Mersin
    END AS Kota,
    'Kota aşımı: ' + CAST(st.TotalUsed - 
        CASE st.StoreName
            WHEN 'Adana' THEN imp.Adana
            WHEN 'Antalya' THEN imp.Antalya
            WHEN 'Gaziantep' THEN imp.Gaziantep
            WHEN 'Merkez' THEN imp.Merkez
            WHEN 'Mersin' THEN imp.Mersin
        END AS NVARCHAR(20)) + ' adet' AS Message
FROM StoreTotals st
CROSS JOIN (
    SELECT *
    FROM tmscrq.TM_ImportExcelPortfVerify
    WHERE UPPER(LTRIM(RTRIM(Reference))) = 'TOTAL'
      AND Yearn = @Year
) imp
WHERE st.TotalUsed >
      CASE st.StoreName
          WHEN 'Adana' THEN imp.Adana
          WHEN 'Antalya' THEN imp.Antalya
          WHEN 'Gaziantep' THEN imp.Gaziantep
          WHEN 'Merkez' THEN imp.Merkez
          WHEN 'Mersin' THEN imp.Mersin
      END
ORDER BY 
    CASE st.StoreName
        WHEN 'Adana' THEN 1
        WHEN 'Antalya' THEN 2
        WHEN 'Gaziantep' THEN 3
        WHEN 'Merkez' THEN 4
        WHEN 'Mersin' THEN 5
    END;
", new string[] { "StoreName", "KullanilanStok", "Kota", "Message" }, prms_TM_YearlyStockControlByStore_3.ToArray());
            ;

            var prms_TM_GetYearlyStockByType_4 = new List<kSqlParameter>();
            prms_TM_GetYearlyStockByType_4.Add(new kSqlParameter() { Name = "Year", Value = request.Year_4 });
            using var auditTM_GetYearlyStockByType_4 = ActionAuditScope.Begin("90d0eab2-5376-5dc9-de7b-0f32315bd68b", "TM_GetYearlyStockByType", applicationName: "wbTimesCRM", screenOrEndpointName: "YearlyAllocationcopy");
            result.TM_GetYearlyStockByType = KPersister.Fetch(KContext.GetConnectionString(), @"WITH StockAgg AS
(
    SELECT
        -- TOTAL satırı
        SUM(CASE 
                WHEN UPPER(LTRIM(RTRIM(pas.RefNo))) = 'TOTAL' 
                THEN ISNULL(pas.Objective, 0) 
            END) AS ObjTotal,

        SUM(CASE 
                WHEN UPPER(LTRIM(RTRIM(pas.RefNo))) = 'TOTAL' 
                THEN ISNULL(pas.NonObjective, 0) 
            END) AS NonObjTotal,

        -- TOTAL HARİÇ satırlar
        SUM(CASE 
                WHEN UPPER(LTRIM(RTRIM(pas.RefNo))) <> 'TOTAL' 
                THEN ISNULL(pas.Objective, 0) 
            END) AS ObjUsed,

        SUM(CASE 
                WHEN UPPER(LTRIM(RTRIM(pas.RefNo))) <> 'TOTAL' 
                THEN ISNULL(pas.NonObjective, 0) 
            END) AS NonObjUsed
    FROM tmscrq.TMProductAnnualStock pas
    WHERE pas.Yearn = @Year
)

SELECT
    ObjTotal        AS ObjectiveTotalStock,
    ObjTotal-ObjUsed AS ObjectiveRemainingStock,

    NonObjTotal        AS NonObjectiveTotalStock,
    NonObjTotal-NonObjUsed AS NonObjectiveRemainingStock
FROM StockAgg;
", new string[] { "ObjectiveTotalStock", "ObjectiveRemainingStock", "NonObjectiveTotalStock", "NonObjectiveRemainingStock" }, prms_TM_GetYearlyStockByType_4.ToArray());
            ;


            return Ok(result);
        }


        [HttpPost, Route("YearlyAllocationcopyComponent_762005_onBlur")]
        public IActionResult YearlyAllocationcopyComponent_762005_onBlur(YearlyAllocationcopyComponent_762005_onBlur_Request request)
        {

            var result = new YearlyAllocationcopyComponent_762005_onBlur_Response();

            var prms_TM_StoreAnnualTotalUpdate_0 = new List<kSqlParameter>();
            prms_TM_StoreAnnualTotalUpdate_0.Add(new kSqlParameter() { Name = "StoreName", Value = "Adana".ConvertToType<String>() });
            prms_TM_StoreAnnualTotalUpdate_0.Add(new kSqlParameter() { Name = "Value", Value = request.Value_0 });
            prms_TM_StoreAnnualTotalUpdate_0.Add(new kSqlParameter() { Name = "Year", Value = request.Year_0 });
            using var auditTM_StoreAnnualTotalUpdate_0 = ActionAuditScope.Begin("dbb19ad4-3876-edc0-552c-61ba42257470", "TM_StoreAnnualTotalUpdate", applicationName: "wbTimesCRM", screenOrEndpointName: "YearlyAllocationcopy");
            result.TM_StoreAnnualTotalUpdate = KPersister.Save(KContext.GetConnectionString(), @"-----------------------------------------------------
-- Parametreler
-----------------------------------------------------
-- @Year        INT
-- @StoreName   NVARCHAR(100)
-- @Value       INT   -- güncellenecek değer
-----------------------------------------------------

BEGIN TRY
    BEGIN TRAN;

    -----------------------------------------------------
    -- TM_ImportExcelPortfVerify - TOTAL satırındaki mağaza
    -----------------------------------------------------
    UPDATE tmscrq.TM_ImportExcelPortfVerify
    SET
        Adana     = CASE WHEN @StoreName = 'Adana' THEN @Value ELSE Adana END,
        Antalya   = CASE WHEN @StoreName = 'Antalya' THEN @Value ELSE Antalya END,
        Gaziantep = CASE WHEN @StoreName = 'Gaziantep' THEN @Value ELSE Gaziantep END,
        Merkez    = CASE WHEN @StoreName = 'Merkez' THEN @Value ELSE Merkez END,
        Mersin    = CASE WHEN @StoreName = 'Mersin' THEN @Value ELSE Mersin END
    WHERE UPPER(LTRIM(RTRIM(Reference))) = 'TOTAL'
      AND Yearn = @Year;

    -----------------------------------------------------
    COMMIT TRAN;
END TRY
BEGIN CATCH
    ROLLBACK TRAN;
    THROW;
END CATCH;
", prms_TM_StoreAnnualTotalUpdate_0.ToArray());
            ;


            return Ok(result);
        }


        [HttpPost, Route("YearlyAllocationcopyComponent_520234_onBlur")]
        public IActionResult YearlyAllocationcopyComponent_520234_onBlur(YearlyAllocationcopyComponent_520234_onBlur_Request request)
        {

            var result = new YearlyAllocationcopyComponent_520234_onBlur_Response();

            var prms_TM_StoreAnnualTotalUpdate_0 = new List<kSqlParameter>();
            prms_TM_StoreAnnualTotalUpdate_0.Add(new kSqlParameter() { Name = "StoreName", Value = "Antalya".ConvertToType<String>() });
            prms_TM_StoreAnnualTotalUpdate_0.Add(new kSqlParameter() { Name = "Value", Value = request.Value_0 });
            prms_TM_StoreAnnualTotalUpdate_0.Add(new kSqlParameter() { Name = "Year", Value = request.Year_0 });
            using var auditTM_StoreAnnualTotalUpdate_0 = ActionAuditScope.Begin("11a4f594-7d95-2a8a-8bc8-5d78548a1ab5", "TM_StoreAnnualTotalUpdate", applicationName: "wbTimesCRM", screenOrEndpointName: "YearlyAllocationcopy");
            result.TM_StoreAnnualTotalUpdate = KPersister.Save(KContext.GetConnectionString(), @"-----------------------------------------------------
-- Parametreler
-----------------------------------------------------
-- @Year        INT
-- @StoreName   NVARCHAR(100)
-- @Value       INT   -- güncellenecek değer
-----------------------------------------------------

BEGIN TRY
    BEGIN TRAN;

    -----------------------------------------------------
    -- TM_ImportExcelPortfVerify - TOTAL satırındaki mağaza
    -----------------------------------------------------
    UPDATE tmscrq.TM_ImportExcelPortfVerify
    SET
        Adana     = CASE WHEN @StoreName = 'Adana' THEN @Value ELSE Adana END,
        Antalya   = CASE WHEN @StoreName = 'Antalya' THEN @Value ELSE Antalya END,
        Gaziantep = CASE WHEN @StoreName = 'Gaziantep' THEN @Value ELSE Gaziantep END,
        Merkez    = CASE WHEN @StoreName = 'Merkez' THEN @Value ELSE Merkez END,
        Mersin    = CASE WHEN @StoreName = 'Mersin' THEN @Value ELSE Mersin END
    WHERE UPPER(LTRIM(RTRIM(Reference))) = 'TOTAL'
      AND Yearn = @Year;

    -----------------------------------------------------
    COMMIT TRAN;
END TRY
BEGIN CATCH
    ROLLBACK TRAN;
    THROW;
END CATCH;
", prms_TM_StoreAnnualTotalUpdate_0.ToArray());
            ;


            return Ok(result);
        }


        [HttpPost, Route("YearlyAllocationcopyComponent_914243_onBlur")]
        public IActionResult YearlyAllocationcopyComponent_914243_onBlur(YearlyAllocationcopyComponent_914243_onBlur_Request request)
        {

            var result = new YearlyAllocationcopyComponent_914243_onBlur_Response();

            var prms_TM_StoreAnnualTotalUpdate_0 = new List<kSqlParameter>();
            prms_TM_StoreAnnualTotalUpdate_0.Add(new kSqlParameter() { Name = "StoreName", Value = "Gaziantep".ConvertToType<String>() });
            prms_TM_StoreAnnualTotalUpdate_0.Add(new kSqlParameter() { Name = "Value", Value = request.Value_0 });
            prms_TM_StoreAnnualTotalUpdate_0.Add(new kSqlParameter() { Name = "Year", Value = request.Year_0 });
            using var auditTM_StoreAnnualTotalUpdate_0 = ActionAuditScope.Begin("eafdb73f-5032-7ac5-0d23-39042048e885", "TM_StoreAnnualTotalUpdate", applicationName: "wbTimesCRM", screenOrEndpointName: "YearlyAllocationcopy");
            result.TM_StoreAnnualTotalUpdate = KPersister.Save(KContext.GetConnectionString(), @"-----------------------------------------------------
-- Parametreler
-----------------------------------------------------
-- @Year        INT
-- @StoreName   NVARCHAR(100)
-- @Value       INT   -- güncellenecek değer
-----------------------------------------------------

BEGIN TRY
    BEGIN TRAN;

    -----------------------------------------------------
    -- TM_ImportExcelPortfVerify - TOTAL satırındaki mağaza
    -----------------------------------------------------
    UPDATE tmscrq.TM_ImportExcelPortfVerify
    SET
        Adana     = CASE WHEN @StoreName = 'Adana' THEN @Value ELSE Adana END,
        Antalya   = CASE WHEN @StoreName = 'Antalya' THEN @Value ELSE Antalya END,
        Gaziantep = CASE WHEN @StoreName = 'Gaziantep' THEN @Value ELSE Gaziantep END,
        Merkez    = CASE WHEN @StoreName = 'Merkez' THEN @Value ELSE Merkez END,
        Mersin    = CASE WHEN @StoreName = 'Mersin' THEN @Value ELSE Mersin END
    WHERE UPPER(LTRIM(RTRIM(Reference))) = 'TOTAL'
      AND Yearn = @Year;

    -----------------------------------------------------
    COMMIT TRAN;
END TRY
BEGIN CATCH
    ROLLBACK TRAN;
    THROW;
END CATCH;
", prms_TM_StoreAnnualTotalUpdate_0.ToArray());
            ;


            return Ok(result);
        }


        [HttpPost, Route("YearlyAllocationcopyComponent_804414_onBlur")]
        public IActionResult YearlyAllocationcopyComponent_804414_onBlur(YearlyAllocationcopyComponent_804414_onBlur_Request request)
        {

            var result = new YearlyAllocationcopyComponent_804414_onBlur_Response();

            var prms_TM_StoreAnnualTotalUpdate_0 = new List<kSqlParameter>();
            prms_TM_StoreAnnualTotalUpdate_0.Add(new kSqlParameter() { Name = "StoreName", Value = "Mersin".ConvertToType<String>() });
            prms_TM_StoreAnnualTotalUpdate_0.Add(new kSqlParameter() { Name = "Value", Value = request.Value_0 });
            prms_TM_StoreAnnualTotalUpdate_0.Add(new kSqlParameter() { Name = "Year", Value = request.Year_0 });
            using var auditTM_StoreAnnualTotalUpdate_0 = ActionAuditScope.Begin("f7ad93a6-fe49-befa-1df8-a3146f4ca0da", "TM_StoreAnnualTotalUpdate", applicationName: "wbTimesCRM", screenOrEndpointName: "YearlyAllocationcopy");
            result.TM_StoreAnnualTotalUpdate = KPersister.Save(KContext.GetConnectionString(), @"-----------------------------------------------------
-- Parametreler
-----------------------------------------------------
-- @Year        INT
-- @StoreName   NVARCHAR(100)
-- @Value       INT   -- güncellenecek değer
-----------------------------------------------------

BEGIN TRY
    BEGIN TRAN;

    -----------------------------------------------------
    -- TM_ImportExcelPortfVerify - TOTAL satırındaki mağaza
    -----------------------------------------------------
    UPDATE tmscrq.TM_ImportExcelPortfVerify
    SET
        Adana     = CASE WHEN @StoreName = 'Adana' THEN @Value ELSE Adana END,
        Antalya   = CASE WHEN @StoreName = 'Antalya' THEN @Value ELSE Antalya END,
        Gaziantep = CASE WHEN @StoreName = 'Gaziantep' THEN @Value ELSE Gaziantep END,
        Merkez    = CASE WHEN @StoreName = 'Merkez' THEN @Value ELSE Merkez END,
        Mersin    = CASE WHEN @StoreName = 'Mersin' THEN @Value ELSE Mersin END
    WHERE UPPER(LTRIM(RTRIM(Reference))) = 'TOTAL'
      AND Yearn = @Year;

    -----------------------------------------------------
    COMMIT TRAN;
END TRY
BEGIN CATCH
    ROLLBACK TRAN;
    THROW;
END CATCH;
", prms_TM_StoreAnnualTotalUpdate_0.ToArray());
            ;


            return Ok(result);
        }


        [HttpPost, Route("YearlyAllocationcopyComponent_474310_onBlur")]
        public IActionResult YearlyAllocationcopyComponent_474310_onBlur(YearlyAllocationcopyComponent_474310_onBlur_Request request)
        {

            var result = new YearlyAllocationcopyComponent_474310_onBlur_Response();

            var prms_TM_StoreAnnualTotalUpdate_0 = new List<kSqlParameter>();
            prms_TM_StoreAnnualTotalUpdate_0.Add(new kSqlParameter() { Name = "StoreName", Value = "Merkez".ConvertToType<String>() });
            prms_TM_StoreAnnualTotalUpdate_0.Add(new kSqlParameter() { Name = "Value", Value = request.Value_0 });
            prms_TM_StoreAnnualTotalUpdate_0.Add(new kSqlParameter() { Name = "Year", Value = request.Year_0 });
            using var auditTM_StoreAnnualTotalUpdate_0 = ActionAuditScope.Begin("98e16cbb-7dd1-b099-f782-c20dacba5f38", "TM_StoreAnnualTotalUpdate", applicationName: "wbTimesCRM", screenOrEndpointName: "YearlyAllocationcopy");
            result.TM_StoreAnnualTotalUpdate = KPersister.Save(KContext.GetConnectionString(), @"-----------------------------------------------------
-- Parametreler
-----------------------------------------------------
-- @Year        INT
-- @StoreName   NVARCHAR(100)
-- @Value       INT   -- güncellenecek değer
-----------------------------------------------------

BEGIN TRY
    BEGIN TRAN;

    -----------------------------------------------------
    -- TM_ImportExcelPortfVerify - TOTAL satırındaki mağaza
    -----------------------------------------------------
    UPDATE tmscrq.TM_ImportExcelPortfVerify
    SET
        Adana     = CASE WHEN @StoreName = 'Adana' THEN @Value ELSE Adana END,
        Antalya   = CASE WHEN @StoreName = 'Antalya' THEN @Value ELSE Antalya END,
        Gaziantep = CASE WHEN @StoreName = 'Gaziantep' THEN @Value ELSE Gaziantep END,
        Merkez    = CASE WHEN @StoreName = 'Merkez' THEN @Value ELSE Merkez END,
        Mersin    = CASE WHEN @StoreName = 'Mersin' THEN @Value ELSE Mersin END
    WHERE UPPER(LTRIM(RTRIM(Reference))) = 'TOTAL'
      AND Yearn = @Year;

    -----------------------------------------------------
    COMMIT TRAN;
END TRY
BEGIN CATCH
    ROLLBACK TRAN;
    THROW;
END CATCH;
", prms_TM_StoreAnnualTotalUpdate_0.ToArray());
            ;


            return Ok(result);
        }


        [HttpPost, Route("YearlyAllocationcopyComponent_831638_onChange")]
        public IActionResult YearlyAllocationcopyComponent_831638_onChange(YearlyAllocationcopyComponent_831638_onChange_Request request)
        {

            var result = new YearlyAllocationcopyComponent_831638_onChange_Response();

            var prms_Action1_0 = new List<kSqlParameter>();
            prms_Action1_0.Add(new kSqlParameter() { Name = "Yearn", Value = request.Yearn_0 });
            prms_Action1_0.Add(new kSqlParameter() { Name = "RefNo", Value = request.RefNo_0 });
            using var auditAction1_0 = ActionAuditScope.Begin("4aa2696e-b66c-38d9-d3f8-0ae9596889cd", "Action1", applicationName: "wbTimesCRM", screenOrEndpointName: "YearlyAllocationcopy");
            result.Action1 = KPersister.Fetch(KContext.GetConnectionString(), @"SELECT
    sas.RefNo AS UrunKodu,

    -- Yıllık Tahsis (ürün bazında)
    MAX(sas.AllocatedQuantity) AS YıllıkTahsisMiktarı,

    -- Kalan Stok = Tahsis - Toplam Kullanılan
    MAX(sas.AllocatedQuantity) - SUM(ISNULL(sas.UseStock, 0)) AS KalanStok,

    -- Mağaza Bazlı Kullanılan Stok
    SUM(CASE WHEN sas.StoreName = 'Merkez'     THEN ISNULL(sas.UseStock, 0) ELSE 0 END) AS MerkezOfis,
    SUM(CASE WHEN sas.StoreName = 'Gaziantep' THEN ISNULL(sas.UseStock, 0) ELSE 0 END) AS Gaziantep,
    SUM(CASE WHEN sas.StoreName = 'Antalya'   THEN ISNULL(sas.UseStock, 0) ELSE 0 END) AS Antalya,
    SUM(CASE WHEN sas.StoreName = 'Adana'     THEN ISNULL(sas.UseStock, 0) ELSE 0 END) AS Adana,
    SUM(CASE WHEN sas.StoreName = 'Mersin'    THEN ISNULL(sas.UseStock, 0) ELSE 0 END) AS Mersin

FROM tmscrq.TMStoreAnnualStock sas
WHERE sas.Yearn = @Yearn
  AND (@RefNo IS NULL OR sas.RefNo = @RefNo)
  AND sas.RefNo <> 'TOTAL'  -- TOTAL satırını hariç tut
GROUP BY sas.RefNo
ORDER BY sas.RefNo;
", new string[] { "UrunKodu", "YıllıkTahsisMiktarı", "KalanStok", "MerkezOfis", "Gaziantep", "Antalya", "Adana", "Mersin" }, prms_Action1_0.ToArray());
            ;


            return Ok(result);
        }


        [HttpPost, Route("YearlyAllocationcopyComponent_831638_onChange1_")]
        public IActionResult YearlyAllocationcopyComponent_831638_onChange1_(YearlyAllocationcopyComponent_831638_onChange1__Request request)
        {

            var result = new YearlyAllocationcopyComponent_831638_onChange1__Response();

            var prms_Action1_0 = new List<kSqlParameter>();
            prms_Action1_0.Add(new kSqlParameter() { Name = "Yearn", Value = request.Yearn_0 });
            prms_Action1_0.Add(new kSqlParameter() { Name = "RefNo", Value = (null as object) });
            using var auditAction1_0 = ActionAuditScope.Begin("6703eb78-01b6-7815-6de5-671327927df7", "Action1", applicationName: "wbTimesCRM", screenOrEndpointName: "YearlyAllocationcopy");
            result.Action1 = KPersister.Fetch(KContext.GetConnectionString(), @"SELECT
    sas.RefNo AS UrunKodu,

    -- Yıllık Tahsis (ürün bazında)
    MAX(sas.AllocatedQuantity) AS YıllıkTahsisMiktarı,

    -- Kalan Stok = Tahsis - Toplam Kullanılan
    MAX(sas.AllocatedQuantity) - SUM(ISNULL(sas.UseStock, 0)) AS KalanStok,

    -- Mağaza Bazlı Kullanılan Stok
    SUM(CASE WHEN sas.StoreName = 'Merkez'     THEN ISNULL(sas.UseStock, 0) ELSE 0 END) AS MerkezOfis,
    SUM(CASE WHEN sas.StoreName = 'Gaziantep' THEN ISNULL(sas.UseStock, 0) ELSE 0 END) AS Gaziantep,
    SUM(CASE WHEN sas.StoreName = 'Antalya'   THEN ISNULL(sas.UseStock, 0) ELSE 0 END) AS Antalya,
    SUM(CASE WHEN sas.StoreName = 'Adana'     THEN ISNULL(sas.UseStock, 0) ELSE 0 END) AS Adana,
    SUM(CASE WHEN sas.StoreName = 'Mersin'    THEN ISNULL(sas.UseStock, 0) ELSE 0 END) AS Mersin

FROM tmscrq.TMStoreAnnualStock sas
WHERE sas.Yearn = @Yearn
  AND (@RefNo IS NULL OR sas.RefNo = @RefNo)
  AND sas.RefNo <> 'TOTAL'  -- TOTAL satırını hariç tut
GROUP BY sas.RefNo
ORDER BY sas.RefNo;
", new string[] { "UrunKodu", "YıllıkTahsisMiktarı", "KalanStok", "MerkezOfis", "Gaziantep", "Antalya", "Adana", "Mersin" }, prms_Action1_0.ToArray());
            ;


            return Ok(result);
        }


        [HttpPost, Route("YearlyAllocationcopyComponent_171380_onBlur")]
        public IActionResult YearlyAllocationcopyComponent_171380_onBlur(YearlyAllocationcopyComponent_171380_onBlur_Request request)
        {

            var result = new YearlyAllocationcopyComponent_171380_onBlur_Response();

            var prms_Action2_0 = new List<kSqlParameter>();
            prms_Action2_0.Add(new kSqlParameter() { Name = "StoreName", Value = "Adana".ConvertToType<String>() });
            prms_Action2_0.Add(new kSqlParameter() { Name = "RefNo", Value = request.RefNo_0 });
            prms_Action2_0.Add(new kSqlParameter() { Name = "Year", Value = request.Year_0 });
            prms_Action2_0.Add(new kSqlParameter() { Name = "UsedStock", Value = request.UsedStock_0 });
            using var auditAction2_0 = ActionAuditScope.Begin("56b6bfc4-1197-85ce-9941-8845088ce61b", "Action2", applicationName: "wbTimesCRM", screenOrEndpointName: "YearlyAllocationcopy");
            result.Action2 = KPersister.Save(KContext.GetConnectionString(), @"-----------------------------------------------------
-- Parametreler
-----------------------------------------------------
-- @RefNo       NVARCHAR(50)
-- @Year        INT
-- @StoreName   NVARCHAR(100)
-- @UsedStock   INT
-----------------------------------------------------

BEGIN TRY
    BEGIN TRAN;

    -----------------------------------------------------
    -- 1️⃣ TMStoreAnnualStock UsedStock overwrite
    -----------------------------------------------------
    UPDATE tmscrq.TMStoreAnnualStock
    SET UseStock = @UsedStock
    WHERE RefNo = @RefNo
      AND Yearn = @Year
      AND StoreName = @StoreName;

    -----------------------------------------------------
    -- 2️⃣ Aynı RefNo + Year için toplam kullanılan stok
    -----------------------------------------------------
    DECLARE @TotalUsed INT;

    SELECT 
        @TotalUsed = SUM(ISNULL(UseStock, 0))
    FROM tmscrq.TMStoreAnnualStock
    WHERE RefNo = @RefNo
      AND Yearn = @Year;

    -----------------------------------------------------
    -- 3️⃣ RemainingQuantity güncelle
    -----------------------------------------------------
    UPDATE tmscrq.TMStoreAnnualStock
    SET RemainingQuantity =
        CASE
            WHEN AllocatedQuantity - @TotalUsed < 0 THEN 0
            ELSE AllocatedQuantity - @TotalUsed
        END
    WHERE RefNo = @RefNo
      AND Yearn = @Year;

    -----------------------------------------------------
    -- 4️⃣ TMMonthlyStorePlan MonthlyTotal senkronla
    -----------------------------------------------------
    UPDATE mp
    SET mp.AllocatedQuantity = ISNULL(sas.UseStock, 0)
    FROM tmscrq.TMMonthlyStorePlan mp
    INNER JOIN tmscrq.TMStoreAnnualStock sas
        ON sas.RefNo = mp.RefNo
       AND sas.StoreName = mp.StoreName
       AND sas.Yearn = mp.Yearn
    WHERE mp.RefNo = @RefNo
      AND mp.StoreName = @StoreName
      AND mp.Yearn = @Year;

    -----------------------------------------------------
    -- 5️⃣ TM_ImportExcelPortfVerify (EN SON, sadece mağaza sütunu)
    -----------------------------------------------------
    UPDATE tmscrq.TM_ImportExcelPortfVerify
    SET
        Adana = CASE WHEN @StoreName = 'Adana' THEN @UsedStock ELSE Adana END,
        Antalya = CASE WHEN @StoreName = 'Antalya' THEN @UsedStock ELSE Antalya END,
        Gaziantep = CASE WHEN @StoreName = 'Gaziantep' THEN @UsedStock ELSE Gaziantep END,
        Merkez = CASE WHEN @StoreName = 'Merkez' THEN @UsedStock ELSE Merkez END,
        Mersin = CASE WHEN @StoreName = 'Mersin' THEN @UsedStock ELSE Mersin END
    WHERE Reference = @RefNo
      AND Yearn = @Year;

    -----------------------------------------------------
    COMMIT TRAN;
END TRY
BEGIN CATCH
    ROLLBACK TRAN;
    THROW;
END CATCH;
", prms_Action2_0.ToArray());
            ;


            return Ok(result);
        }


        [HttpPost, Route("YearlyAllocationcopyComponent_979362_onBlur")]
        public IActionResult YearlyAllocationcopyComponent_979362_onBlur(YearlyAllocationcopyComponent_979362_onBlur_Request request)
        {

            var result = new YearlyAllocationcopyComponent_979362_onBlur_Response();

            var prms_Action2_0 = new List<kSqlParameter>();
            prms_Action2_0.Add(new kSqlParameter() { Name = "StoreName", Value = "Antalya".ConvertToType<String>() });
            prms_Action2_0.Add(new kSqlParameter() { Name = "RefNo", Value = request.RefNo_0 });
            prms_Action2_0.Add(new kSqlParameter() { Name = "Year", Value = request.Year_0 });
            prms_Action2_0.Add(new kSqlParameter() { Name = "UsedStock", Value = request.UsedStock_0 });
            using var auditAction2_0 = ActionAuditScope.Begin("6ab058c0-5540-96ff-479e-d4f29c93cc3e", "Action2", applicationName: "wbTimesCRM", screenOrEndpointName: "YearlyAllocationcopy");
            result.Action2 = KPersister.Save(KContext.GetConnectionString(), @"-----------------------------------------------------
-- Parametreler
-----------------------------------------------------
-- @RefNo       NVARCHAR(50)
-- @Year        INT
-- @StoreName   NVARCHAR(100)
-- @UsedStock   INT
-----------------------------------------------------

BEGIN TRY
    BEGIN TRAN;

    -----------------------------------------------------
    -- 1️⃣ TMStoreAnnualStock UsedStock overwrite
    -----------------------------------------------------
    UPDATE tmscrq.TMStoreAnnualStock
    SET UseStock = @UsedStock
    WHERE RefNo = @RefNo
      AND Yearn = @Year
      AND StoreName = @StoreName;

    -----------------------------------------------------
    -- 2️⃣ Aynı RefNo + Year için toplam kullanılan stok
    -----------------------------------------------------
    DECLARE @TotalUsed INT;

    SELECT 
        @TotalUsed = SUM(ISNULL(UseStock, 0))
    FROM tmscrq.TMStoreAnnualStock
    WHERE RefNo = @RefNo
      AND Yearn = @Year;

    -----------------------------------------------------
    -- 3️⃣ RemainingQuantity güncelle
    -----------------------------------------------------
    UPDATE tmscrq.TMStoreAnnualStock
    SET RemainingQuantity =
        CASE
            WHEN AllocatedQuantity - @TotalUsed < 0 THEN 0
            ELSE AllocatedQuantity - @TotalUsed
        END
    WHERE RefNo = @RefNo
      AND Yearn = @Year;

    -----------------------------------------------------
    -- 4️⃣ TMMonthlyStorePlan MonthlyTotal senkronla
    -----------------------------------------------------
    UPDATE mp
    SET mp.AllocatedQuantity = ISNULL(sas.UseStock, 0)
    FROM tmscrq.TMMonthlyStorePlan mp
    INNER JOIN tmscrq.TMStoreAnnualStock sas
        ON sas.RefNo = mp.RefNo
       AND sas.StoreName = mp.StoreName
       AND sas.Yearn = mp.Yearn
    WHERE mp.RefNo = @RefNo
      AND mp.StoreName = @StoreName
      AND mp.Yearn = @Year;

    -----------------------------------------------------
    -- 5️⃣ TM_ImportExcelPortfVerify (EN SON, sadece mağaza sütunu)
    -----------------------------------------------------
    UPDATE tmscrq.TM_ImportExcelPortfVerify
    SET
        Adana = CASE WHEN @StoreName = 'Adana' THEN @UsedStock ELSE Adana END,
        Antalya = CASE WHEN @StoreName = 'Antalya' THEN @UsedStock ELSE Antalya END,
        Gaziantep = CASE WHEN @StoreName = 'Gaziantep' THEN @UsedStock ELSE Gaziantep END,
        Merkez = CASE WHEN @StoreName = 'Merkez' THEN @UsedStock ELSE Merkez END,
        Mersin = CASE WHEN @StoreName = 'Mersin' THEN @UsedStock ELSE Mersin END
    WHERE Reference = @RefNo
      AND Yearn = @Year;

    -----------------------------------------------------
    COMMIT TRAN;
END TRY
BEGIN CATCH
    ROLLBACK TRAN;
    THROW;
END CATCH;
", prms_Action2_0.ToArray());
            ;


            return Ok(result);
        }


        [HttpPost, Route("YearlyAllocationcopyComponent_946036_onBlur")]
        public IActionResult YearlyAllocationcopyComponent_946036_onBlur(YearlyAllocationcopyComponent_946036_onBlur_Request request)
        {

            var result = new YearlyAllocationcopyComponent_946036_onBlur_Response();

            var prms_Action2_0 = new List<kSqlParameter>();
            prms_Action2_0.Add(new kSqlParameter() { Name = "StoreName", Value = "Gaziantep".ConvertToType<String>() });
            prms_Action2_0.Add(new kSqlParameter() { Name = "RefNo", Value = request.RefNo_0 });
            prms_Action2_0.Add(new kSqlParameter() { Name = "Year", Value = request.Year_0 });
            prms_Action2_0.Add(new kSqlParameter() { Name = "UsedStock", Value = request.UsedStock_0 });
            using var auditAction2_0 = ActionAuditScope.Begin("bfd07759-49a9-9009-e440-0a3ce35e6907", "Action2", applicationName: "wbTimesCRM", screenOrEndpointName: "YearlyAllocationcopy");
            result.Action2 = KPersister.Save(KContext.GetConnectionString(), @"-----------------------------------------------------
-- Parametreler
-----------------------------------------------------
-- @RefNo       NVARCHAR(50)
-- @Year        INT
-- @StoreName   NVARCHAR(100)
-- @UsedStock   INT
-----------------------------------------------------

BEGIN TRY
    BEGIN TRAN;

    -----------------------------------------------------
    -- 1️⃣ TMStoreAnnualStock UsedStock overwrite
    -----------------------------------------------------
    UPDATE tmscrq.TMStoreAnnualStock
    SET UseStock = @UsedStock
    WHERE RefNo = @RefNo
      AND Yearn = @Year
      AND StoreName = @StoreName;

    -----------------------------------------------------
    -- 2️⃣ Aynı RefNo + Year için toplam kullanılan stok
    -----------------------------------------------------
    DECLARE @TotalUsed INT;

    SELECT 
        @TotalUsed = SUM(ISNULL(UseStock, 0))
    FROM tmscrq.TMStoreAnnualStock
    WHERE RefNo = @RefNo
      AND Yearn = @Year;

    -----------------------------------------------------
    -- 3️⃣ RemainingQuantity güncelle
    -----------------------------------------------------
    UPDATE tmscrq.TMStoreAnnualStock
    SET RemainingQuantity =
        CASE
            WHEN AllocatedQuantity - @TotalUsed < 0 THEN 0
            ELSE AllocatedQuantity - @TotalUsed
        END
    WHERE RefNo = @RefNo
      AND Yearn = @Year;

    -----------------------------------------------------
    -- 4️⃣ TMMonthlyStorePlan MonthlyTotal senkronla
    -----------------------------------------------------
    UPDATE mp
    SET mp.AllocatedQuantity = ISNULL(sas.UseStock, 0)
    FROM tmscrq.TMMonthlyStorePlan mp
    INNER JOIN tmscrq.TMStoreAnnualStock sas
        ON sas.RefNo = mp.RefNo
       AND sas.StoreName = mp.StoreName
       AND sas.Yearn = mp.Yearn
    WHERE mp.RefNo = @RefNo
      AND mp.StoreName = @StoreName
      AND mp.Yearn = @Year;

    -----------------------------------------------------
    -- 5️⃣ TM_ImportExcelPortfVerify (EN SON, sadece mağaza sütunu)
    -----------------------------------------------------
    UPDATE tmscrq.TM_ImportExcelPortfVerify
    SET
        Adana = CASE WHEN @StoreName = 'Adana' THEN @UsedStock ELSE Adana END,
        Antalya = CASE WHEN @StoreName = 'Antalya' THEN @UsedStock ELSE Antalya END,
        Gaziantep = CASE WHEN @StoreName = 'Gaziantep' THEN @UsedStock ELSE Gaziantep END,
        Merkez = CASE WHEN @StoreName = 'Merkez' THEN @UsedStock ELSE Merkez END,
        Mersin = CASE WHEN @StoreName = 'Mersin' THEN @UsedStock ELSE Mersin END
    WHERE Reference = @RefNo
      AND Yearn = @Year;

    -----------------------------------------------------
    COMMIT TRAN;
END TRY
BEGIN CATCH
    ROLLBACK TRAN;
    THROW;
END CATCH;
", prms_Action2_0.ToArray());
            ;


            return Ok(result);
        }


        [HttpPost, Route("YearlyAllocationcopyComponent_498350_onBlur")]
        public IActionResult YearlyAllocationcopyComponent_498350_onBlur(YearlyAllocationcopyComponent_498350_onBlur_Request request)
        {

            var result = new YearlyAllocationcopyComponent_498350_onBlur_Response();

            var prms_Action2_0 = new List<kSqlParameter>();
            prms_Action2_0.Add(new kSqlParameter() { Name = "StoreName", Value = "Mersin".ConvertToType<String>() });
            prms_Action2_0.Add(new kSqlParameter() { Name = "RefNo", Value = request.RefNo_0 });
            prms_Action2_0.Add(new kSqlParameter() { Name = "Year", Value = request.Year_0 });
            prms_Action2_0.Add(new kSqlParameter() { Name = "UsedStock", Value = request.UsedStock_0 });
            using var auditAction2_0 = ActionAuditScope.Begin("cb681b22-6e60-d2c1-b6eb-dbb09e8bfd91", "Action2", applicationName: "wbTimesCRM", screenOrEndpointName: "YearlyAllocationcopy");
            result.Action2 = KPersister.Save(KContext.GetConnectionString(), @"-----------------------------------------------------
-- Parametreler
-----------------------------------------------------
-- @RefNo       NVARCHAR(50)
-- @Year        INT
-- @StoreName   NVARCHAR(100)
-- @UsedStock   INT
-----------------------------------------------------

BEGIN TRY
    BEGIN TRAN;

    -----------------------------------------------------
    -- 1️⃣ TMStoreAnnualStock UsedStock overwrite
    -----------------------------------------------------
    UPDATE tmscrq.TMStoreAnnualStock
    SET UseStock = @UsedStock
    WHERE RefNo = @RefNo
      AND Yearn = @Year
      AND StoreName = @StoreName;

    -----------------------------------------------------
    -- 2️⃣ Aynı RefNo + Year için toplam kullanılan stok
    -----------------------------------------------------
    DECLARE @TotalUsed INT;

    SELECT 
        @TotalUsed = SUM(ISNULL(UseStock, 0))
    FROM tmscrq.TMStoreAnnualStock
    WHERE RefNo = @RefNo
      AND Yearn = @Year;

    -----------------------------------------------------
    -- 3️⃣ RemainingQuantity güncelle
    -----------------------------------------------------
    UPDATE tmscrq.TMStoreAnnualStock
    SET RemainingQuantity =
        CASE
            WHEN AllocatedQuantity - @TotalUsed < 0 THEN 0
            ELSE AllocatedQuantity - @TotalUsed
        END
    WHERE RefNo = @RefNo
      AND Yearn = @Year;

    -----------------------------------------------------
    -- 4️⃣ TMMonthlyStorePlan MonthlyTotal senkronla
    -----------------------------------------------------
    UPDATE mp
    SET mp.AllocatedQuantity = ISNULL(sas.UseStock, 0)
    FROM tmscrq.TMMonthlyStorePlan mp
    INNER JOIN tmscrq.TMStoreAnnualStock sas
        ON sas.RefNo = mp.RefNo
       AND sas.StoreName = mp.StoreName
       AND sas.Yearn = mp.Yearn
    WHERE mp.RefNo = @RefNo
      AND mp.StoreName = @StoreName
      AND mp.Yearn = @Year;

    -----------------------------------------------------
    -- 5️⃣ TM_ImportExcelPortfVerify (EN SON, sadece mağaza sütunu)
    -----------------------------------------------------
    UPDATE tmscrq.TM_ImportExcelPortfVerify
    SET
        Adana = CASE WHEN @StoreName = 'Adana' THEN @UsedStock ELSE Adana END,
        Antalya = CASE WHEN @StoreName = 'Antalya' THEN @UsedStock ELSE Antalya END,
        Gaziantep = CASE WHEN @StoreName = 'Gaziantep' THEN @UsedStock ELSE Gaziantep END,
        Merkez = CASE WHEN @StoreName = 'Merkez' THEN @UsedStock ELSE Merkez END,
        Mersin = CASE WHEN @StoreName = 'Mersin' THEN @UsedStock ELSE Mersin END
    WHERE Reference = @RefNo
      AND Yearn = @Year;

    -----------------------------------------------------
    COMMIT TRAN;
END TRY
BEGIN CATCH
    ROLLBACK TRAN;
    THROW;
END CATCH;
", prms_Action2_0.ToArray());
            ;


            return Ok(result);
        }


        [HttpPost, Route("YearlyAllocationcopyComponent_571122_onBlur")]
        public IActionResult YearlyAllocationcopyComponent_571122_onBlur(YearlyAllocationcopyComponent_571122_onBlur_Request request)
        {

            var result = new YearlyAllocationcopyComponent_571122_onBlur_Response();

            var prms_Action2_0 = new List<kSqlParameter>();
            prms_Action2_0.Add(new kSqlParameter() { Name = "StoreName", Value = "Merkez".ConvertToType<String>() });
            prms_Action2_0.Add(new kSqlParameter() { Name = "RefNo", Value = request.RefNo_0 });
            prms_Action2_0.Add(new kSqlParameter() { Name = "Year", Value = request.Year_0 });
            prms_Action2_0.Add(new kSqlParameter() { Name = "UsedStock", Value = request.UsedStock_0 });
            using var auditAction2_0 = ActionAuditScope.Begin("72ece349-6910-23d1-93ff-3fef947de468", "Action2", applicationName: "wbTimesCRM", screenOrEndpointName: "YearlyAllocationcopy");
            result.Action2 = KPersister.Save(KContext.GetConnectionString(), @"-----------------------------------------------------
-- Parametreler
-----------------------------------------------------
-- @RefNo       NVARCHAR(50)
-- @Year        INT
-- @StoreName   NVARCHAR(100)
-- @UsedStock   INT
-----------------------------------------------------

BEGIN TRY
    BEGIN TRAN;

    -----------------------------------------------------
    -- 1️⃣ TMStoreAnnualStock UsedStock overwrite
    -----------------------------------------------------
    UPDATE tmscrq.TMStoreAnnualStock
    SET UseStock = @UsedStock
    WHERE RefNo = @RefNo
      AND Yearn = @Year
      AND StoreName = @StoreName;

    -----------------------------------------------------
    -- 2️⃣ Aynı RefNo + Year için toplam kullanılan stok
    -----------------------------------------------------
    DECLARE @TotalUsed INT;

    SELECT 
        @TotalUsed = SUM(ISNULL(UseStock, 0))
    FROM tmscrq.TMStoreAnnualStock
    WHERE RefNo = @RefNo
      AND Yearn = @Year;

    -----------------------------------------------------
    -- 3️⃣ RemainingQuantity güncelle
    -----------------------------------------------------
    UPDATE tmscrq.TMStoreAnnualStock
    SET RemainingQuantity =
        CASE
            WHEN AllocatedQuantity - @TotalUsed < 0 THEN 0
            ELSE AllocatedQuantity - @TotalUsed
        END
    WHERE RefNo = @RefNo
      AND Yearn = @Year;

    -----------------------------------------------------
    -- 4️⃣ TMMonthlyStorePlan MonthlyTotal senkronla
    -----------------------------------------------------
    UPDATE mp
    SET mp.AllocatedQuantity = ISNULL(sas.UseStock, 0)
    FROM tmscrq.TMMonthlyStorePlan mp
    INNER JOIN tmscrq.TMStoreAnnualStock sas
        ON sas.RefNo = mp.RefNo
       AND sas.StoreName = mp.StoreName
       AND sas.Yearn = mp.Yearn
    WHERE mp.RefNo = @RefNo
      AND mp.StoreName = @StoreName
      AND mp.Yearn = @Year;

    -----------------------------------------------------
    -- 5️⃣ TM_ImportExcelPortfVerify (EN SON, sadece mağaza sütunu)
    -----------------------------------------------------
    UPDATE tmscrq.TM_ImportExcelPortfVerify
    SET
        Adana = CASE WHEN @StoreName = 'Adana' THEN @UsedStock ELSE Adana END,
        Antalya = CASE WHEN @StoreName = 'Antalya' THEN @UsedStock ELSE Antalya END,
        Gaziantep = CASE WHEN @StoreName = 'Gaziantep' THEN @UsedStock ELSE Gaziantep END,
        Merkez = CASE WHEN @StoreName = 'Merkez' THEN @UsedStock ELSE Merkez END,
        Mersin = CASE WHEN @StoreName = 'Mersin' THEN @UsedStock ELSE Mersin END
    WHERE Reference = @RefNo
      AND Yearn = @Year;

    -----------------------------------------------------
    COMMIT TRAN;
END TRY
BEGIN CATCH
    ROLLBACK TRAN;
    THROW;
END CATCH;
", prms_Action2_0.ToArray());
            ;


            return Ok(result);
        }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class YearlyAllocationcopyPageInit_Request
    {
        public String Year_0 { set; get; }
        public String Yearn_1 { set; get; }
        public String RefNo_1 { set; get; }
        public String Yearn_2 { set; get; }
        public String Year_3 { set; get; }
        public String Year_4 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class YearlyAllocationcopyPageInit_Response
    {
        public KCommonEntityPage TM_TotalVerifyExcel { set; get; }

        public KCommonEntityPage Action1 { set; get; }

        public KCommonEntityPage TM_GetAnnualProductReferences { set; get; }

        public KCommonEntityPage TM_YearlyStockControlByStore { set; get; }

        public KCommonEntityPage TM_GetYearlyStockByType { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class YearlyAllocationcopyComponent_762005_onBlur_Request
    {
        public String StoreName_0 { set; get; }
        public Int64? Value_0 { set; get; }
        public String Year_0 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class YearlyAllocationcopyComponent_762005_onBlur_Response
    {
        public int TM_StoreAnnualTotalUpdate { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class YearlyAllocationcopyComponent_520234_onBlur_Request
    {
        public String StoreName_0 { set; get; }
        public Int64? Value_0 { set; get; }
        public String Year_0 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class YearlyAllocationcopyComponent_520234_onBlur_Response
    {
        public int TM_StoreAnnualTotalUpdate { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class YearlyAllocationcopyComponent_914243_onBlur_Request
    {
        public String StoreName_0 { set; get; }
        public Int64? Value_0 { set; get; }
        public String Year_0 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class YearlyAllocationcopyComponent_914243_onBlur_Response
    {
        public int TM_StoreAnnualTotalUpdate { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class YearlyAllocationcopyComponent_804414_onBlur_Request
    {
        public String StoreName_0 { set; get; }
        public Int64? Value_0 { set; get; }
        public String Year_0 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class YearlyAllocationcopyComponent_804414_onBlur_Response
    {
        public int TM_StoreAnnualTotalUpdate { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class YearlyAllocationcopyComponent_474310_onBlur_Request
    {
        public String StoreName_0 { set; get; }
        public Int64? Value_0 { set; get; }
        public String Year_0 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class YearlyAllocationcopyComponent_474310_onBlur_Response
    {
        public int TM_StoreAnnualTotalUpdate { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class YearlyAllocationcopyComponent_831638_onChange_Request
    {
        public String Yearn_0 { set; get; }
        public String RefNo_0 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class YearlyAllocationcopyComponent_831638_onChange_Response
    {
        public KCommonEntityPage Action1 { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class YearlyAllocationcopyComponent_831638_onChange1__Request
    {
        public String Yearn_0 { set; get; }
        public String RefNo_0 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class YearlyAllocationcopyComponent_831638_onChange1__Response
    {
        public KCommonEntityPage Action1 { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class YearlyAllocationcopyComponent_171380_onBlur_Request
    {
        public String StoreName_0 { set; get; }
        public String RefNo_0 { set; get; }
        public String Year_0 { set; get; }
        public Int32? UsedStock_0 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class YearlyAllocationcopyComponent_171380_onBlur_Response
    {
        public int Action2 { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class YearlyAllocationcopyComponent_979362_onBlur_Request
    {
        public String StoreName_0 { set; get; }
        public String RefNo_0 { set; get; }
        public String Year_0 { set; get; }
        public Int32? UsedStock_0 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class YearlyAllocationcopyComponent_979362_onBlur_Response
    {
        public int Action2 { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class YearlyAllocationcopyComponent_946036_onBlur_Request
    {
        public String StoreName_0 { set; get; }
        public String RefNo_0 { set; get; }
        public String Year_0 { set; get; }
        public Int32? UsedStock_0 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class YearlyAllocationcopyComponent_946036_onBlur_Response
    {
        public int Action2 { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class YearlyAllocationcopyComponent_498350_onBlur_Request
    {
        public String StoreName_0 { set; get; }
        public String RefNo_0 { set; get; }
        public String Year_0 { set; get; }
        public Int32? UsedStock_0 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class YearlyAllocationcopyComponent_498350_onBlur_Response
    {
        public int Action2 { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class YearlyAllocationcopyComponent_571122_onBlur_Request
    {
        public String StoreName_0 { set; get; }
        public String RefNo_0 { set; get; }
        public String Year_0 { set; get; }
        public Int32? UsedStock_0 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class YearlyAllocationcopyComponent_571122_onBlur_Response
    {
        public int Action2 { set; get; }

    }
}
