
using Kuika.Common;
using Kuika.Common.Attributes;
using Kuika.Common.Bases;
using Kuika.Common.Enums;
using Kuika.Common.Accessors;
using Kuika.Common.Json;
using Kuika.Common.Classes;
using Kuika.Common.Exceptions;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Kuika.Common.Helpers;
using Kuika.Common.Settings;
using System.Collections.Generic;
using System;
using Kuika.Common.Extensions;
using System.Linq;
using Kuika.Common.Rest;
using WorkflowCore.Interface;
using Kuika.Common.Interfaces;
using Kuika.Common.Workflow;
using Kuika.Common.Workflow.Extensions;
using Kuika.Common.Workflow.DTOs;
using Kuika.Common.Models;
using Kuika.Common.Menu.Response;
using Kuika.Common.Entities;
using System.Reflection;
using Newtonsoft.Json.Linq;
using Newtonsoft.Json;
using System.Net.Http;
using Iyzipay.Model.V2.Subscription;
using Kuika.Common.Payments.Iyzico;
using Kuika.Common.Payments.Param;
using Iyzipay;
using Kuika.Common.Searching.DTOs;
using Kuika.Common.Helpers.Sap;
using Kuika.Common.Mcp;
using Kuika.Common.Vision.DTOs;
using Kuika.Common.Audit;
using Kuika.Common.Payments.Mobile;
using Kuika.ThirdPartyApisCollection;

namespace Kuika.Reslen_01.Api
{
    [ApiExplorerSettings(GroupName = "all")]
    [Authorize]
    [ApiController]
    [Route("v1/api/DashBoardTemp")]
    public class DashBoardTemp_Controller : KControllerBase
    {
        private string appName = "wbTimesCRM";
        private Guid appId = Guid.Parse("0e8ecb48-8c52-463c-5db5-08de3ec441b1");
        private static string screenName = "DashBoardTemp";
        private Guid screenId = Guid.Parse("2f71bd76-5b09-4afd-b4ed-bc5d00334c6b");
        private string connectionString { get { return Kuika.Common.KContext.GetConnectionString(); } }

        [HttpGet, Route("myroles")]
        public IActionResult GetMyRoles()
        {
            try
            {
                var result = KProviderManager.Authorization.GetMyRoles(appId, appName, screenId, screenName);
                return Ok(result);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new HttpExceptionDto() { Message = ex.Message, StackTrace = ex.StackTrace });
            }
        }


        [HttpPost, Route("DashBoardTempPageInit")]
        public IActionResult DashBoardTempPageInit(DashBoardTempPageInit_Request request)
        {

            KProviderManager.Authorization.IsAuthorizedForRoles(appId, appName, screenId, screenName, new List<string> { $"b4bfd39c-ac02-f442-c899-7a2374a45b47", "70de6cfc-6087-6059-59b4-0b5a8527af6b", "TimesSatisPersoneli", "TimesMagazaMuduru" });

            var result = new DashBoardTempPageInit_Response();

            var prms_TM_DefDashSummary_0 = new List<kSqlParameter>();
            prms_TM_DefDashSummary_0.Add(new kSqlParameter() { Name = "UserId", Value = Kuika.Common.KContext.CurrentUser?.Id });
            using var auditTM_DefDashSummary_0 = ActionAuditScope.Begin("124dbe47-ea35-3e5a-8fc0-975947e2a026", "TM_DefDashSummary", applicationName: "wbTimesCRM", screenOrEndpointName: "DashBoardTemp");
            result.TM_DefDashSummary = KPersister.Fetch(KContext.GetConnectionString(), @"SET NOCOUNT ON;

DECLARE @Today DATE = CAST(GETDATE() AS DATE);
DECLARE @StartOfMonth DATE = DATEFROMPARTS(YEAR(GETDATE()), MONTH(GETDATE()), 1);
DECLARE @EndOfMonth DATE = EOMONTH(GETDATE());

;WITH CurrentUserRoles AS
(
    SELECT
        CAST
        (
            CASE
                WHEN EXISTS
                (
                    SELECT 1
                    FROM dbo.KUserRole ur
                    INNER JOIN dbo.KRole r
                        ON r.Id = ur.KRole_Id
                    WHERE ur.KUser_Id = @UserId
                      AND ur.IsDeleted = 0
                      AND r.IsDeleted = 0
                      AND r.Name = 'TimesSatisPersoneli'
                )
                THEN 1
                ELSE 0
            END
        AS BIT) AS IsSatisPersoneli,

        CAST
        (
            CASE
                WHEN EXISTS
                (
                    SELECT 1
                    FROM dbo.KUserRole ur
                    INNER JOIN dbo.KRole r
                        ON r.Id = ur.KRole_Id
                    WHERE ur.KUser_Id = @UserId
                      AND ur.IsDeleted = 0
                      AND r.IsDeleted = 0
                      AND r.Name = 'TimesMagazaMuduru'
                )
                THEN 1
                ELSE 0
            END
        AS BIT) AS IsMagazaMuduru,

        CAST
        (
            CASE
                WHEN EXISTS
                (
                    SELECT 1
                    FROM dbo.KUserRole ur
                    INNER JOIN dbo.KRole r
                        ON r.Id = ur.KRole_Id
                    WHERE ur.KUser_Id = @UserId
                      AND ur.IsDeleted = 0
                      AND r.IsDeleted = 0
                      AND r.Name IN
                      (
                          'TimesYonetici',
                          'TimesUstYonetici'
                      )
                )
                THEN 1
                ELSE 0
            END
        AS BIT) AS IsUstYonetici
),

UserStores AS
(
    SELECT DISTINCT
        StoreId
    FROM tmscrq.TMUser
    WHERE KUserID=@UserId
),

AllUserRoleFlags AS
(
    SELECT
        ur.KUser_Id,

        MAX(CASE WHEN r.Name='TimesSatisPersoneli' THEN 1 ELSE 0 END) AS IsSatisPersoneli,
        MAX(CASE WHEN r.Name='TimesMagazaMuduru' THEN 1 ELSE 0 END) AS IsMagazaMuduru,
        MAX(CASE
                WHEN r.Name IN
                (
                    'TimesYonetici',
                    'TimesUstYonetici'
                )
                THEN 1
                ELSE 0
            END) AS IsUstYonetici

    FROM dbo.KUserRole ur
    INNER JOIN dbo.KRole r
        ON r.Id=ur.KRole_Id
    WHERE ur.IsDeleted=0
      AND r.IsDeleted=0
    GROUP BY ur.KUser_Id
),

ActiveReservation AS
(
    SELECT *
    FROM
    (
        SELECT
            r.*,

            ROW_NUMBER() OVER
            (
                PARTITION BY r.LeadId
                ORDER BY
                    r.ReservedAt DESC,
                    r.Id DESC
            ) AS RN

        FROM tmscrq.TMLeadReservation r
        WHERE r.IsActive=1
    ) X
    WHERE RN=1
),

LeadBase AS
(
    SELECT

        l.Id AS LeadId,
        l.CreatedAt,
        l.CreatedBy,
        l.ProcessId,
        l.StatuId,
        l.ProductId,
        l.StoreId,
        l.SalesPersonKUserId,
        l.EstimatedDate,

        COALESCE
        (
            l.StoreId,
            creator.StoreId
        ) AS EffectiveStoreId,

        p.CategoryName,

        CASE
            WHEN p.CategoryName LIKE '%1%' THEN 1
            WHEN p.CategoryName LIKE '%2%' THEN 2
            WHEN p.CategoryName LIKE '%3%' THEN 3
            ELSE 0
        END AS CategoryLevel,

        lp.Code AS ProcessCode,

        ar.Id AS ReservationId,
        ar.ReservedBy,
        ar.ReservedAt,

        ISNULL(ar.IsApproved,0) AS IsApproved,
        ISNULL(ar.IsRejected,0) AS IsRejected,

        CASE
            WHEN ar.Id IS NOT NULL
             AND ISNULL(ar.IsRejected,0)=0
            THEN 1
            ELSE 0
        END AS HasActiveReservation,

        CASE
            WHEN ar.Id IS NOT NULL
             AND ISNULL(ar.IsApproved,0)=1
             AND ISNULL(ar.IsRejected,0)=0
            THEN 1
            ELSE 0
        END AS HasApprovedReservation,

        CASE
            WHEN ar.Id IS NOT NULL
             AND ISNULL(ar.IsApproved,0)=0
             AND ISNULL(ar.IsRejected,0)=0
            THEN 1
            ELSE 0
        END AS HasPendingReservation

    FROM tmscrq.TMLead l

    LEFT JOIN tmscrq.TMUser creator
        ON creator.KUserID=l.CreatedBy

    LEFT JOIN tmscrq.TMProduct p
        ON p.Id=l.ProductId

    LEFT JOIN tmscrq.TMLeadProcess lp
        ON lp.Id=l.ProcessId

    LEFT JOIN ActiveReservation ar
        ON ar.LeadId=l.Id
)
,
StockTotals AS
(
    SELECT
        st.Id AS StoreId,
        p.Id AS ProductId,

        SUM(ISNULL(i.InventoryQty1,0)) AS ToplamStok

    FROM tmscrq.TMItemInventory i

    INNER JOIN tmscrq.TMProduct p
        ON UPPER(LTRIM(RTRIM(p.ProductCode)))
         = UPPER(LTRIM(RTRIM(i.ProductCode)))

    INNER JOIN tmscrq.TMStore st
        ON UPPER(LTRIM(RTRIM(st.StoreCode)))
         = UPPER(LTRIM(RTRIM(i.StoreCode)))

    WHERE i.OfficeDescription IS NOT NULL
      AND i.OfficeDescription <> N'Teknik Servis Ofis'

    GROUP BY
        st.Id,
        p.Id
),

ReservedStockCounts AS
(
    SELECT

        lb.EffectiveStoreId AS StoreId,
        lb.ProductId,

        COUNT(DISTINCT r.LeadId) AS RezerveStok

    FROM tmscrq.TMLeadReservation r

    INNER JOIN LeadBase lb
        ON lb.LeadId = r.LeadId

    WHERE r.IsActive=1
      AND lb.ProcessCode='DELIVERY_PENDING'

    GROUP BY
        lb.EffectiveStoreId,
        lb.ProductId
),

PendingReservationCounts AS
(
    SELECT

        lb.EffectiveStoreId AS StoreId,
        lb.ProductId,

        COUNT(DISTINCT r.LeadId) AS BekleyenRezervTalebi

    FROM tmscrq.TMLeadReservation r

    INNER JOIN LeadBase lb
        ON lb.LeadId=r.LeadId

    WHERE r.IsActive=1
      AND ISNULL(r.IsApproved,0)=0
      AND ISNULL(r.IsRejected,0)=0
      AND lb.ProcessCode='APPROVED'

    GROUP BY
        lb.EffectiveStoreId,
        lb.ProductId
),

StockStatus AS
(
    SELECT

        s.StoreId,
        s.ProductId,

        s.ToplamStok,

        ISNULL(r.RezerveStok,0) AS RezerveStok,

        ISNULL(p.BekleyenRezervTalebi,0) AS BekleyenRezervTalebi,

        CASE
            WHEN s.ToplamStok-ISNULL(r.RezerveStok,0)>0
            THEN s.ToplamStok-ISNULL(r.RezerveStok,0)
            ELSE 0
        END AS MusaitStok,

        CASE
            WHEN s.ToplamStok
                 -ISNULL(r.RezerveStok,0)
                 -ISNULL(p.BekleyenRezervTalebi,0)>0
            THEN s.ToplamStok
                 -ISNULL(r.RezerveStok,0)
                 -ISNULL(p.BekleyenRezervTalebi,0)
            ELSE 0
        END AS YeniRezervTalebiKapasitesi

    FROM StockTotals s

    LEFT JOIN ReservedStockCounts r
           ON r.StoreId=s.StoreId
          AND r.ProductId=s.ProductId

    LEFT JOIN PendingReservationCounts p
           ON p.StoreId=s.StoreId
          AND p.ProductId=s.ProductId
),

FifoQueue AS
(
    SELECT

        lb.LeadId,

        ROW_NUMBER() OVER
        (
            PARTITION BY
                lb.EffectiveStoreId,
                lb.ProductId
            ORDER BY
                lb.CreatedAt,
                lb.LeadId
        ) AS FifoSirasi

    FROM LeadBase lb

    WHERE lb.ProcessCode='APPROVED'
      AND lb.HasApprovedReservation=0
      AND lb.ProductId IS NOT NULL
      AND lb.EffectiveStoreId IS NOT NULL
      AND lb.CategoryLevel IN (1,2,3)
)
,
PriorityTaskKeys AS
(
    --------------------------------------------------
    -- 1. REZERV EDİLMEYİ BEKLEYEN
    --------------------------------------------------
    SELECT
        lb.LeadId,
        'WAITING_RESERVATION' AS TaskType
    FROM LeadBase lb

    CROSS JOIN CurrentUserRoles role

    INNER JOIN FifoQueue fifo
        ON fifo.LeadId = lb.LeadId

    INNER JOIN StockStatus stock
        ON stock.StoreId = lb.EffectiveStoreId
       AND stock.ProductId = lb.ProductId

    WHERE lb.ProcessCode='APPROVED'
      AND lb.HasActiveReservation=0

      -- kişisel görev
      AND
      (
            lb.CreatedBy=@UserId
         OR lb.SalesPersonKUserId=@UserId
      )

      -- FIFO
      AND stock.ToplamStok>0
      AND stock.MusaitStok>0
      AND fifo.FifoSirasi<=stock.MusaitStok

      -- rol
      AND
      (
            role.IsSatisPersoneli=1

         OR
         (
            role.IsMagazaMuduru=1
            AND EXISTS
            (
                SELECT 1
                FROM UserStores us
                WHERE us.StoreId=lb.EffectiveStoreId
            )
         )

         OR role.IsUstYonetici=1
      )

    UNION ALL

    --------------------------------------------------
    -- 2. REZERV ONAYI BEKLEYEN
    --------------------------------------------------
    SELECT
        lb.LeadId,
        'WAITING_APPROVAL'
    FROM LeadBase lb

    CROSS JOIN CurrentUserRoles role

    INNER JOIN FifoQueue fifo
        ON fifo.LeadId=lb.LeadId

    INNER JOIN StockStatus stock
        ON stock.StoreId=lb.EffectiveStoreId
       AND stock.ProductId=lb.ProductId

    LEFT JOIN AllUserRoleFlags rr
        ON rr.KUser_Id=lb.ReservedBy

    WHERE lb.ProcessCode='APPROVED'
      AND lb.HasPendingReservation=1
      AND lb.ReservedBy<>@UserId

      AND stock.MusaitStok>0
      AND fifo.FifoSirasi<=stock.MusaitStok

      AND
      (
            (
                role.IsMagazaMuduru=1
                AND lb.CategoryLevel=1
                AND rr.IsSatisPersoneli=1
                AND EXISTS
                (
                    SELECT 1
                    FROM UserStores us
                    WHERE us.StoreId=lb.EffectiveStoreId
                )
            )

         OR

            (
                role.IsUstYonetici=1
                AND lb.CategoryLevel IN (2,3)
                AND
                (
                    rr.IsSatisPersoneli=1
                    OR rr.IsMagazaMuduru=1
                )
            )
      )

    UNION ALL

    --------------------------------------------------
    -- 3. SATIŞA HAZIR
    --------------------------------------------------
    SELECT
        lb.LeadId,
        'READY_FOR_SALE'
    FROM LeadBase lb

    CROSS JOIN CurrentUserRoles role

    WHERE lb.ProcessCode='DELIVERY_PENDING'

      AND
      (
            lb.CreatedBy=@UserId
         OR lb.SalesPersonKUserId=@UserId
      )

      AND
      (
            role.IsSatisPersoneli=1

         OR
         (
            role.IsMagazaMuduru=1
            AND EXISTS
            (
                SELECT 1
                FROM UserStores us
                WHERE us.StoreId=lb.EffectiveStoreId
            )
         )

         OR role.IsUstYonetici=1
      )
)
SELECT

    --------------------------------------------------
    -- LEAD SAYILARI
    --------------------------------------------------
    COUNT(*) AS TotalLead,

    SUM
    (
        CASE
            WHEN lb.ProcessCode IN
            (
                'CREATED',
                'TERMIN_PENDING',
                'PENDING',
                'APPROVED',
                'DELIVERY_PENDING'
            )
            THEN 1
            ELSE 0
        END
    ) AS ActiveLead,

    SUM
    (
        CASE
            WHEN lb.ProcessCode IN
            (
                'CREATED',
                'TERMIN_PENDING',
                'PENDING',
                'APPROVED',
                'DELIVERY_PENDING'
            )
            THEN 1
            ELSE 0
        END
    ) AS AktifLeadler,

    --------------------------------------------------
    -- TERMİN
    --------------------------------------------------
    SUM
    (
        CASE
            WHEN lb.EstimatedDate>=@StartOfMonth
             AND lb.EstimatedDate<DATEADD(DAY,1,@EndOfMonth)
            THEN 1
            ELSE 0
        END
    ) AS BuAyinTerminleri,

    SUM
    (
        CASE
            WHEN lb.EstimatedDate<@Today
             AND lb.ProcessCode NOT IN
             (
                'DELIVERED',
                'CUSTOMER_DECLINED',
                'REJECTED',
                'CLOSED'
             )
            THEN 1
            ELSE 0
        END
    ) AS GecikenTerminler,

    --------------------------------------------------
    -- SÜREÇLER
    --------------------------------------------------
    SUM(CASE WHEN lb.ProcessCode='TERMIN_PENDING' THEN 1 ELSE 0 END) AS TerminBekleyenler,

    SUM(CASE WHEN lb.ProcessCode='PENDING' THEN 1 ELSE 0 END) AS OnayBekleyenler,

    SUM(CASE WHEN task.TaskType='WAITING_APPROVAL' THEN 1 ELSE 0 END) AS RezervOnayBekleyenler,

    SUM(CASE WHEN task.TaskType='READY_FOR_SALE' THEN 1 ELSE 0 END) AS SatisBekleyenler,

    SUM(CASE WHEN task.TaskType='WAITING_RESERVATION' THEN 1 ELSE 0 END) AS RezervEdilmeyiBekleyenler,

    SUM(CASE WHEN lb.ProcessCode='DELIVERED' THEN 1 ELSE 0 END) AS SatisiYapilanlar,

    SUM(CASE WHEN lb.ProcessCode='CUSTOMER_DECLINED' THEN 1 ELSE 0 END) AS MusteriIstemedi,

    SUM
    (
        CASE
            WHEN lb.EstimatedDate<@Today
             AND lb.ProcessCode NOT IN
             (
                'DELIVERED',
                'CUSTOMER_DECLINED',
                'REJECTED',
                'CLOSED'
             )
            THEN 1
            ELSE 0
        END
    ) AS GecikenLeadler

FROM LeadBase lb

LEFT JOIN PriorityTaskKeys task
    ON task.LeadId=lb.LeadId

WHERE
(
    --------------------------------------------------
    -- Üst yönetici
    --------------------------------------------------
    EXISTS
    (
        SELECT 1
        FROM CurrentUserRoles r
        WHERE r.IsUstYonetici=1
    )

    OR

    --------------------------------------------------
    -- Mağaza Müdürü
    --------------------------------------------------
    (
        EXISTS
        (
            SELECT 1
            FROM CurrentUserRoles r
            WHERE r.IsMagazaMuduru=1
        )

        AND EXISTS
        (
            SELECT 1
            FROM UserStores us
            WHERE us.StoreId=lb.EffectiveStoreId
        )
    )

    OR

    --------------------------------------------------
    -- Satış Personeli
    --------------------------------------------------
    (
        EXISTS
        (
            SELECT 1
            FROM CurrentUserRoles r
            WHERE r.IsSatisPersoneli=1
        )

        AND
        (
            lb.CreatedBy=@UserId
            OR lb.SalesPersonKUserId=@UserId
        )
    )
);", new string[] { "TotalLead", "ActiveLead", "AktifLeadler", "BuAyinTerminleri", "GecikenTerminler", "TerminBekleyenler", "OnayBekleyenler", "RezervOnayBekleyenler", "SatisBekleyenler", "RezervEdilmeyiBekleyenler", "SatisiYapilanlar", "MusteriIstemedi", "GecikenLeadler" }, prms_TM_DefDashSummary_0.ToArray());
            ;

            var prms_TMSalesPersonDashBoardTaskList_1 = new List<kSqlParameter>();
            prms_TMSalesPersonDashBoardTaskList_1.Add(new kSqlParameter() { Name = "UserId", Value = Kuika.Common.KContext.CurrentUser?.Id });
            prms_TMSalesPersonDashBoardTaskList_1.Add(new kSqlParameter() { Name = "TaskFilter", Value = request.TaskFilter_1 });
            using var auditTMSalesPersonDashBoardTaskList_1 = ActionAuditScope.Begin("ea808615-8266-d424-e2bc-185c2abc4884", "TMSalesPersonDashBoardTaskList", applicationName: "wbTimesCRM", screenOrEndpointName: "DashBoardTemp");
            result.TMSalesPersonDashBoardTaskList = KPersister.Fetch(KContext.GetConnectionString(), @"SET LANGUAGE Turkish;

;WITH CurrentUserRoles AS
(
    --------------------------------------------------
    -- GİRİŞ YAPAN KULLANICININ ROLLERİ
    --------------------------------------------------
    SELECT
        CAST(
            CASE
                WHEN EXISTS
                (
                    SELECT 1
                    FROM dbo.KUserRole ur
                    INNER JOIN dbo.KRole r
                        ON r.Id = ur.KRole_Id
                    WHERE ur.KUser_Id = @UserId
                      AND ur.IsDeleted = 0
                      AND r.IsDeleted = 0
                      AND r.Name = 'TimesSatisPersoneli'
                )
                THEN 1
                ELSE 0
            END
        AS BIT) AS IsSatisPersoneli,

        CAST(
            CASE
                WHEN EXISTS
                (
                    SELECT 1
                    FROM dbo.KUserRole ur
                    INNER JOIN dbo.KRole r
                        ON r.Id = ur.KRole_Id
                    WHERE ur.KUser_Id = @UserId
                      AND ur.IsDeleted = 0
                      AND r.IsDeleted = 0
                      AND r.Name = 'TimesMagazaMuduru'
                )
                THEN 1
                ELSE 0
            END
        AS BIT) AS IsMagazaMuduru,

        CAST(
            CASE
                WHEN EXISTS
                (
                    SELECT 1
                    FROM dbo.KUserRole ur
                    INNER JOIN dbo.KRole r
                        ON r.Id = ur.KRole_Id
                    WHERE ur.KUser_Id = @UserId
                      AND ur.IsDeleted = 0
                      AND r.IsDeleted = 0
                      AND r.Name IN
                      (
                          'TimesYonetici',
                          'TimesUstYonetici'
                      )
                )
                THEN 1
                ELSE 0
            END
        AS BIT) AS IsUstYonetici
),
UserStores AS
(
    --------------------------------------------------
    -- GİRİŞ YAPAN KULLANICININ MAĞAZALARI
    --------------------------------------------------
    SELECT DISTINCT
        tu.StoreId
    FROM tmscrq.TMUser tu
    WHERE tu.KUserID = @UserId
      AND tu.StoreId IS NOT NULL
),
AllUserRoleFlags AS
(
    --------------------------------------------------
    -- TÜM KULLANICILARIN ROL BİLGİLERİ
    -- REZERV TALEBİNİ KİMİN OLUŞTURDUĞUNU
    -- ROL BAZINDA BELİRLEMEK İÇİN KULLANILIR
    --------------------------------------------------
    SELECT
        ur.KUser_Id,

        MAX(
            CASE
                WHEN r.Name = 'TimesSatisPersoneli'
                THEN 1
                ELSE 0
            END
        ) AS IsSatisPersoneli,

        MAX(
            CASE
                WHEN r.Name = 'TimesMagazaMuduru'
                THEN 1
                ELSE 0
            END
        ) AS IsMagazaMuduru,

        MAX(
            CASE
                WHEN r.Name IN
                (
                    'TimesYonetici',
                    'TimesUstYonetici'
                )
                THEN 1
                ELSE 0
            END
        ) AS IsUstYonetici

    FROM dbo.KUserRole ur
    INNER JOIN dbo.KRole r
        ON r.Id = ur.KRole_Id
    WHERE ur.IsDeleted = 0
      AND r.IsDeleted = 0
      AND r.Name IN
      (
          'TimesSatisPersoneli',
          'TimesMagazaMuduru',
          'TimesYonetici',
          'TimesUstYonetici'
      )
    GROUP BY
        ur.KUser_Id
),
ActiveReservation AS
(
    --------------------------------------------------
    -- HER LEAD İÇİN SON AKTİF REZERVASYON KAYDI
    --------------------------------------------------
    SELECT
        reservationRow.Id AS ReservationId,
        reservationRow.LeadId,
        reservationRow.IsApproved,
        reservationRow.IsRejected,
        reservationRow.ReservationNote,
        reservationRow.ReservedAt,
        reservationRow.ReservedBy
    FROM
    (
        SELECT
            r.Id,
            r.LeadId,
            ISNULL(r.IsApproved, 0) AS IsApproved,
            ISNULL(r.IsRejected, 0) AS IsRejected,
            r.ReservationNote,
            r.ReservedAt,
            r.ReservedBy,

            ROW_NUMBER() OVER
            (
                PARTITION BY r.LeadId
                ORDER BY
                    r.ReservedAt DESC,
                    r.Id DESC
            ) AS RowNumber

        FROM tmscrq.TMLeadReservation r
        WHERE r.IsActive = 1
    ) reservationRow
    WHERE reservationRow.RowNumber = 1
),
LeadBase AS
(
    --------------------------------------------------
    -- LEAD ANA VERİ SETİ
    --------------------------------------------------
    SELECT
        l.Id AS LeadId,
        l.LeadCode,
        l.CreatedAt,
        l.CreatedBy,
        l.EstimatedDate,
        l.IsReserved,
        l.ProductId,
        l.SalesPersonKUserId,

        COALESCE(
            l.StoreId,
            creatorUser.StoreId
        ) AS EffectiveStoreId,

        p.ProductCode,
        p.ProductName,
        p.Brand,
        p.CategoryName,
        p.Referance,
        p.Dial,
        p.Bracelet,

        --------------------------------------------------
        -- KATEGORİ SEVİYESİ
        --------------------------------------------------
        CASE
            WHEN LTRIM(RTRIM(ISNULL(p.CategoryName, '')))
                 LIKE '%1%'
            THEN 1

            WHEN LTRIM(RTRIM(ISNULL(p.CategoryName, '')))
                 LIKE '%2%'
            THEN 2

            WHEN LTRIM(RTRIM(ISNULL(p.CategoryName, '')))
                 LIKE '%3%'
            THEN 3

            ELSE 0
        END AS CategoryLevel,

        cu.Name AS CustomerName,
        cu.LastName AS CustomerLastName,
        cu.CityName,
        cu.DistrictName,
        cu.CountryName,
        cu.Info AS CustomerInfo,
        cu.IsShopping,
        cu.Tel,
        cu.Email,

        cr.ContactResourceName,

        ls.Name AS LeadStatusName,

        ns.Name AS NextStepName,

        lp.Name AS ProcessName,
        lp.Code AS ProcessCode,
        lp.StepOrder,

        sp.FirstName AS SalesPersonFirstName,
        sp.LastName AS SalesPersonLastName,

        st.StoreCode,
        st.StoreDesc AS StoreName,

        ar.ReservationId,
        ar.IsApproved AS ReservationIsApproved,
        ar.IsRejected AS ReservationIsRejected,
        ar.ReservationNote,
        ar.ReservedAt,
        ar.ReservedBy,

        --------------------------------------------------
        -- AÇIK REZERVASYON VAR MI
        --------------------------------------------------
        CASE
            WHEN ar.ReservationId IS NOT NULL
             AND ISNULL(ar.IsRejected, 0) = 0
            THEN 1
            ELSE 0
        END AS HasActiveReservation,

        --------------------------------------------------
        -- ONAYLANMIŞ REZERVASYON VAR MI
        --------------------------------------------------
        CASE
            WHEN ar.ReservationId IS NOT NULL
             AND ISNULL(ar.IsApproved, 0) = 1
             AND ISNULL(ar.IsRejected, 0) = 0
            THEN 1
            ELSE 0
        END AS HasApprovedReservation,

        --------------------------------------------------
        -- ONAY BEKLEYEN REZERVASYON VAR MI
        --------------------------------------------------
        CASE
            WHEN ar.ReservationId IS NOT NULL
             AND ISNULL(ar.IsApproved, 0) = 0
             AND ISNULL(ar.IsRejected, 0) = 0
            THEN 1
            ELSE 0
        END AS HasPendingReservation,

        ISNULL(
            reservationUserRole.IsSatisPersoneli,
            0
        ) AS ReservedBySatisPersoneli,

        ISNULL(
            reservationUserRole.IsMagazaMuduru,
            0
        ) AS ReservedByMagazaMuduru,

        ISNULL(
            reservationUserRole.IsUstYonetici,
            0
        ) AS ReservedByUstYonetici

    FROM tmscrq.TMLead l

    LEFT JOIN tmscrq.TMUser creatorUser
        ON creatorUser.KUserID = l.CreatedBy

    LEFT JOIN tmscrq.TMCustomer cu
        ON cu.Id = l.CustomerId

    LEFT JOIN tmscrq.TMProduct p
        ON p.Id = l.ProductId

    LEFT JOIN tmscrq.TMContactResource cr
        ON cr.Id = l.ContactResourceId

    LEFT JOIN tmscrq.TMLeadStatu ls
        ON ls.Id = l.StatuId

    LEFT JOIN tmscrq.TMLeadNextStep ns
        ON ns.Id = l.NextStepId

    LEFT JOIN tmscrq.TMLeadProcess lp
        ON lp.Id = l.ProcessID

    LEFT JOIN dbo.KUser sp
        ON sp.Id = l.SalesPersonKUserId

    LEFT JOIN tmscrq.TMStore st
        ON st.Id = COALESCE(
            l.StoreId,
            creatorUser.StoreId
        )

    LEFT JOIN ActiveReservation ar
        ON ar.LeadId = l.Id

    LEFT JOIN AllUserRoleFlags reservationUserRole
        ON reservationUserRole.KUser_Id = ar.ReservedBy
),
StockTotals AS
(
    --------------------------------------------------
    -- MAĞAZA VE ÜRÜN BAZLI TOPLAM STOK
    --------------------------------------------------
    SELECT
        st.Id AS StoreId,
        p.Id AS ProductId,

        CAST(
            SUM(
                CAST(
                    ISNULL(i.InventoryQty1, 0)
                    AS DECIMAL(18, 2)
                )
            )
        AS DECIMAL(18, 2)) AS ToplamStok

    FROM tmscrq.TMItemInventory i

    INNER JOIN tmscrq.TMProduct p
        ON UPPER(LTRIM(RTRIM(p.ProductCode)))
         = UPPER(LTRIM(RTRIM(i.ProductCode)))

    INNER JOIN tmscrq.TMStore st
        ON UPPER(LTRIM(RTRIM(st.StoreCode)))
         = UPPER(LTRIM(RTRIM(i.StoreCode)))

    WHERE i.OfficeDescription IS NOT NULL
      AND i.OfficeDescription NOT IN
      (
          N'Teknik Servis Ofis'
      )

    GROUP BY
        st.Id,
        p.Id

    HAVING
        SUM(ISNULL(i.InventoryQty1, 0)) > 0
),
ReservedStockCounts AS
(
    --------------------------------------------------
    -- DELIVERY_PENDING SÜRECİNDEKİ
    -- AKTİF REZERVASYON SAYISI
    --------------------------------------------------
    SELECT
        COALESCE(
            l.StoreId,
            creatorUser.StoreId
        ) AS StoreId,

        l.ProductId,

        COUNT(
            DISTINCT r.LeadId
        ) AS RezerveStok

    FROM tmscrq.TMLeadReservation r

    INNER JOIN tmscrq.TMLead l
        ON l.Id = r.LeadId

    INNER JOIN tmscrq.TMLeadProcess lp
        ON lp.Id = l.ProcessID

    LEFT JOIN tmscrq.TMUser creatorUser
        ON creatorUser.KUserID = l.CreatedBy

    WHERE r.IsActive = 1
      AND lp.Code = 'DELIVERY_PENDING'

    GROUP BY
        COALESCE(
            l.StoreId,
            creatorUser.StoreId
        ),
        l.ProductId
),
PendingReservationCounts AS
(
    --------------------------------------------------
    -- APPROVED SÜRECİNDEKİ
    -- ONAY BEKLEYEN REZERV TALEBİ SAYISI
    --------------------------------------------------
    SELECT
        COALESCE(
            l.StoreId,
            creatorUser.StoreId
        ) AS StoreId,

        l.ProductId,

        COUNT(
            DISTINCT r.LeadId
        ) AS BekleyenRezervTalebi

    FROM tmscrq.TMLeadReservation r

    INNER JOIN tmscrq.TMLead l
        ON l.Id = r.LeadId

    INNER JOIN tmscrq.TMLeadProcess lp
        ON lp.Id = l.ProcessID

    LEFT JOIN tmscrq.TMUser creatorUser
        ON creatorUser.KUserID = l.CreatedBy

    WHERE r.IsActive = 1
      AND ISNULL(r.IsApproved, 0) = 0
      AND ISNULL(r.IsRejected, 0) = 0
      AND lp.Code = 'APPROVED'

    GROUP BY
        COALESCE(
            l.StoreId,
            creatorUser.StoreId
        ),
        l.ProductId
),
StockStatus AS
(
    --------------------------------------------------
    -- STOK VE REZERV KAPASİTESİ
    --------------------------------------------------
    SELECT
        stock.StoreId,
        stock.ProductId,
        stock.ToplamStok,

        ISNULL(
            reserved.RezerveStok,
            0
        ) AS RezerveStok,

        ISNULL(
            pending.BekleyenRezervTalebi,
            0
        ) AS BekleyenRezervTalebi,

        CASE
            WHEN
                stock.ToplamStok
                - ISNULL(reserved.RezerveStok, 0) > 0
            THEN
                stock.ToplamStok
                - ISNULL(reserved.RezerveStok, 0)
            ELSE 0
        END AS MusaitStok,

        CASE
            WHEN
                stock.ToplamStok
                - ISNULL(reserved.RezerveStok, 0)
                - ISNULL(pending.BekleyenRezervTalebi, 0) > 0
            THEN
                stock.ToplamStok
                - ISNULL(reserved.RezerveStok, 0)
                - ISNULL(pending.BekleyenRezervTalebi, 0)
            ELSE 0
        END AS YeniRezervTalebiKapasitesi

    FROM StockTotals stock

    LEFT JOIN ReservedStockCounts reserved
        ON reserved.StoreId = stock.StoreId
       AND reserved.ProductId = stock.ProductId

    LEFT JOIN PendingReservationCounts pending
        ON pending.StoreId = stock.StoreId
       AND pending.ProductId = stock.ProductId
),
FifoQueue AS
(
    --------------------------------------------------
    -- MAĞAZA VE ÜRÜN BAZLI FIFO SIRASI
    --
    -- APPROVED SÜRECİNDEKİ LEADLER
    -- EN ESKİDEN EN YENİYE SIRALANIR
    --------------------------------------------------
    SELECT
        lb.LeadId,

        ROW_NUMBER() OVER
        (
            PARTITION BY
                lb.EffectiveStoreId,
                lb.ProductId
            ORDER BY
                lb.CreatedAt ASC,
                lb.LeadCode ASC,
                lb.LeadId ASC
        ) AS FifoSirasi

    FROM LeadBase lb

    WHERE lb.ProcessCode = 'APPROVED'
      AND lb.HasApprovedReservation = 0
      AND lb.EffectiveStoreId IS NOT NULL
      AND lb.ProductId IS NOT NULL
      AND lb.CategoryLevel IN
      (
          1,
          2,
          3
      )
),
PriorityTaskKeys AS
(
    --------------------------------------------------
    -- 1. REZERV EDİLMEYİ BEKLEYEN
    --------------------------------------------------
    SELECT
        lb.LeadId,
        lb.ReservationId,

        N'Rezerv Edilmeyi Bekleyen'
            AS GorevTipi,

        CASE
            --------------------------------------------------
            -- ÜST YÖNETİCİ TÜM KATEGORİLERDE
            -- DOĞRUDAN REZERV YAPAR
            --------------------------------------------------
            WHEN currentRole.IsUstYonetici = 1
            THEN N'Doğrudan Rezerv Yap'

            --------------------------------------------------
            -- MAĞAZA MÜDÜRÜ KATEGORİ 1 İÇİN
            -- DOĞRUDAN REZERV YAPAR
            --------------------------------------------------
            WHEN currentRole.IsMagazaMuduru = 1
             AND lb.CategoryLevel = 1
            THEN N'Doğrudan Rezerv Yap'

            --------------------------------------------------
            -- SATIŞ PERSONELİ VE MAĞAZA MÜDÜRÜ
            -- DİĞER DURUMLARDA REZERV TALEBİ GÖNDERİR
            --------------------------------------------------
            ELSE N'Rezerv Talebi Gönder'
        END AS GorevAksiyonu,

        CASE
            WHEN currentRole.IsUstYonetici = 1
            THEN 'DIRECT_RESERVE'

            WHEN currentRole.IsMagazaMuduru = 1
             AND lb.CategoryLevel = 1
            THEN 'DIRECT_RESERVE'

            ELSE 'SEND_RESERVATION_REQUEST'
        END AS AksiyonKodu,

        3 AS GorevOnceligi,

        lb.CreatedAt AS GorevTarihi,

        fifo.FifoSirasi,

        stock.ToplamStok,
        stock.RezerveStok,
        stock.BekleyenRezervTalebi,
        stock.MusaitStok,
        stock.YeniRezervTalebiKapasitesi

    FROM LeadBase lb

    CROSS JOIN CurrentUserRoles currentRole

    INNER JOIN FifoQueue fifo
        ON fifo.LeadId = lb.LeadId

    INNER JOIN StockStatus stock
        ON stock.StoreId = lb.EffectiveStoreId
       AND stock.ProductId = lb.ProductId

    WHERE lb.ProcessCode = 'APPROVED'

      --------------------------------------------------
      -- DAHA ÖNCE AÇIK REZERV TALEBİ OLMAMALI
      --------------------------------------------------
      AND lb.HasActiveReservation = 0

      --------------------------------------------------
      -- KİŞİSEL GÖREV
      --
      -- SATIŞ DANIŞMANI VE MAĞAZA MÜDÜRÜ
      -- SADECE KENDİ LEADLERİ İÇİN
      -- REZERV İŞLEMİ YAPAR
      --------------------------------------------------
      AND
      (
          lb.SalesPersonKUserId = @UserId
          OR lb.CreatedBy = @UserId
      )

      --------------------------------------------------
      -- STOK BULUNMALI
      --------------------------------------------------
      AND stock.ToplamStok > 0
      AND stock.YeniRezervTalebiKapasitesi > 0

      --------------------------------------------------
      -- FIFO SIRASI KAPASİTE İÇİNDE BULUNMALI
      --------------------------------------------------
      AND fifo.FifoSirasi <= stock.YeniRezervTalebiKapasitesi

      --------------------------------------------------
      -- ROL VE MAĞAZA YETKİSİ
      --------------------------------------------------
      AND
      (
          currentRole.IsSatisPersoneli = 1

          OR

          (
              currentRole.IsMagazaMuduru = 1

              AND EXISTS
              (
                  SELECT 1
                  FROM UserStores userStore
                  WHERE userStore.StoreId = lb.EffectiveStoreId
              )
          )

          OR currentRole.IsUstYonetici = 1
      )

    UNION ALL

    --------------------------------------------------
    -- 2. REZERV ONAYI BEKLEYEN
    --------------------------------------------------
    SELECT
        lb.LeadId,
        lb.ReservationId,

        N'Rezerv Onayı Bekleyen'
            AS GorevTipi,

        N'Rezerv Talebini Onayla'
            AS GorevAksiyonu,

        'APPROVE_RESERVATION'
            AS AksiyonKodu,

        1 AS GorevOnceligi,

        COALESCE(
            lb.ReservedAt,
            lb.CreatedAt
        ) AS GorevTarihi,

        fifo.FifoSirasi,

        stock.ToplamStok,
        stock.RezerveStok,
        stock.BekleyenRezervTalebi,
        stock.MusaitStok,
        stock.YeniRezervTalebiKapasitesi

    FROM LeadBase lb

    CROSS JOIN CurrentUserRoles currentRole

    INNER JOIN FifoQueue fifo
        ON fifo.LeadId = lb.LeadId

    INNER JOIN StockStatus stock
        ON stock.StoreId = lb.EffectiveStoreId
       AND stock.ProductId = lb.ProductId

    WHERE lb.ProcessCode = 'APPROVED'

      --------------------------------------------------
      -- AKTİF VE ONAY BEKLEYEN REZERV TALEBİ
      --------------------------------------------------
      AND lb.HasPendingReservation = 1
      AND lb.ReservedBy IS NOT NULL

      --------------------------------------------------
      -- KULLANICI KENDİ TALEBİNİ ONAYLAYAMAZ
      --------------------------------------------------
      AND lb.ReservedBy <> @UserId

      --------------------------------------------------
      -- ONAYLANABİLECEK STOK BULUNMALI
      --------------------------------------------------
      AND stock.YeniRezervTalebiKapasitesi > 0

      --------------------------------------------------
      -- FIFO SIRASI KAPASİTE İÇİNDE OLMALI
      --------------------------------------------------
      AND fifo.FifoSirasi <= stock.YeniRezervTalebiKapasitesi

      AND
      (
          --------------------------------------------------
          -- MAĞAZA MÜDÜRÜ
          --
          -- KENDİ MAĞAZASINDAKİ TÜM SATIŞ
          -- PERSONELLERİNİN KATEGORİ 1
          -- REZERV TALEPLERİNİ ONAYLAR
          --------------------------------------------------
          (
              currentRole.IsMagazaMuduru = 1

              AND lb.CategoryLevel = 1

              AND lb.ReservedBySatisPersoneli = 1
              AND lb.ReservedByMagazaMuduru = 0

              AND EXISTS
              (
                  SELECT 1
                  FROM UserStores userStore
                  WHERE userStore.StoreId = lb.EffectiveStoreId
              )
          )

          OR

          --------------------------------------------------
          -- ÜST YÖNETİCİ
          --
          -- TÜM MAĞAZALARDAKİ KATEGORİ 2 VE
          -- KATEGORİ 3 REZERV TALEPLERİNİ ONAYLAR
          --------------------------------------------------
          (
              currentRole.IsUstYonetici = 1

              AND lb.CategoryLevel IN
              (
                  2,
                  3
              )

              AND
              (
                  lb.ReservedBySatisPersoneli = 1
                  OR lb.ReservedByMagazaMuduru = 1
              )
          )
      )

    UNION ALL

    --------------------------------------------------
    -- 3. SATIŞA HAZIR
    --------------------------------------------------
    SELECT
        lb.LeadId,
        lb.ReservationId,

        N'Satışa Hazır'
            AS GorevTipi,

        N'Teslim ve Satış İşlemini Tamamla'
            AS GorevAksiyonu,

        'COMPLETE_SALE'
            AS AksiyonKodu,

        2 AS GorevOnceligi,

        COALESCE(
            lb.ReservedAt,
            lb.CreatedAt
        ) AS GorevTarihi,

        CAST(NULL AS BIGINT)
            AS FifoSirasi,

        ISNULL(
            stock.ToplamStok,
            0
        ) AS ToplamStok,

        ISNULL(
            stock.RezerveStok,
            0
        ) AS RezerveStok,

        ISNULL(
            stock.BekleyenRezervTalebi,
            0
        ) AS BekleyenRezervTalebi,

        ISNULL(
            stock.MusaitStok,
            0
        ) AS MusaitStok,

        ISNULL(
            stock.YeniRezervTalebiKapasitesi,
            0
        ) AS YeniRezervTalebiKapasitesi

    FROM LeadBase lb

    CROSS JOIN CurrentUserRoles currentRole

    LEFT JOIN StockStatus stock
        ON stock.StoreId = lb.EffectiveStoreId
       AND stock.ProductId = lb.ProductId

    WHERE lb.ProcessCode = 'DELIVERY_PENDING'

      --------------------------------------------------
      -- SATIŞA HAZIR KAYIT KİŞİSEL GÖREVDİR
      --------------------------------------------------
      AND
      (
          lb.SalesPersonKUserId = @UserId
          OR lb.CreatedBy = @UserId
      )

      --------------------------------------------------
      -- ROL VE MAĞAZA YETKİSİ
      --------------------------------------------------
      AND
      (
          currentRole.IsSatisPersoneli = 1

          OR

          (
              currentRole.IsMagazaMuduru = 1

              AND EXISTS
              (
                  SELECT 1
                  FROM UserStores userStore
                  WHERE userStore.StoreId = lb.EffectiveStoreId
              )
          )

          OR currentRole.IsUstYonetici = 1
      )
)

--------------------------------------------------
-- SONUÇ (TOP 5 KAYIT, SAYFALAMA KALDIRILDI)
--------------------------------------------------
SELECT
    --------------------------------------------------
    -- GÖREV
    --------------------------------------------------
    task.GorevTipi,
    task.GorevAksiyonu,
    task.AksiyonKodu,
    task.GorevOnceligi,
    task.FifoSirasi,

    --------------------------------------------------
    -- AKSİYON GÖRÜNÜRLÜKLERİ
    --------------------------------------------------
    CAST(
        CASE
            WHEN task.AksiyonKodu = 'DIRECT_RESERVE'
            THEN 1
            ELSE 0
        END
    AS BIT) AS DogrudanRezervShow,

    CAST(
        CASE
            WHEN task.AksiyonKodu = 'SEND_RESERVATION_REQUEST'
            THEN 1
            ELSE 0
        END
    AS BIT) AS RezervTalebiGonderShow,

    CAST(
        CASE
            WHEN task.AksiyonKodu = 'APPROVE_RESERVATION'
            THEN 1
            ELSE 0
        END
    AS BIT) AS RezervOnaylaShow,

    CAST(
        CASE
            WHEN task.AksiyonKodu = 'COMPLETE_SALE'
            THEN 1
            ELSE 0
        END
    AS BIT) AS SatisYapShow,

    --------------------------------------------------
    -- STOK
    --------------------------------------------------
    task.ToplamStok,
    task.RezerveStok,
    task.BekleyenRezervTalebi,
    task.MusaitStok,
    task.YeniRezervTalebiKapasitesi,

    --------------------------------------------------
    -- REZERVASYON
    --------------------------------------------------
    task.ReservationId,
    lead.ReservedBy,
    lead.ReservedAt,

    ISNULL(
        NULLIF(
            LTRIM(RTRIM(lead.ReservationNote)),
            ''
        ),
        '-'
    ) AS ReservationNote,

    CASE
        WHEN lead.HasApprovedReservation = 1
        THEN N'Evet'

        WHEN lead.HasPendingReservation = 1
        THEN N'Onay Bekliyor'

        ELSE N'Hayır'
    END AS RezerveDurumu,

    --------------------------------------------------
    -- LEAD
    --------------------------------------------------
    lead.LeadId,
    lead.ProductId,
    lead.EffectiveStoreId AS StoreId,
    lead.SalesPersonKUserId,
    lead.CreatedBy,

    ISNULL(
        NULLIF(
            LTRIM(RTRIM(lead.LeadCode)),
            ''
        ),
        '-'
    ) AS LeadNumarasi,

    CONVERT(
        VARCHAR(10),
        lead.CreatedAt,
        103
    ) AS TalepTarihi,

    --------------------------------------------------
    -- ÜRÜN
    --------------------------------------------------
    ISNULL(
        NULLIF(
            LTRIM(RTRIM(lead.ProductName)),
            ''
        ),
        '-'
    ) AS ProductName,

    ISNULL(
        NULLIF(
            LTRIM(RTRIM(lead.Brand)),
            ''
        ),
        '-'
    ) AS Brand,

    ISNULL(
        NULLIF(
            LTRIM(RTRIM(lead.CategoryName)),
            ''
        ),
        '-'
    ) AS CategoryName,

    lead.CategoryLevel,

    ISNULL(
        NULLIF(
            LTRIM(RTRIM(lead.ProductCode)),
            ''
        ),
        '-'
    ) AS RefCode,

    ISNULL(
        NULLIF(
            LTRIM(RTRIM(lead.Referance)),
            ''
        ),
        '-'
    ) AS Referans,

    ISNULL(
        NULLIF(
            LTRIM(RTRIM(lead.Dial)),
            ''
        ),
        '-'
    ) AS Kadran,

    ISNULL(
        NULLIF(
            LTRIM(RTRIM(lead.Bracelet)),
            ''
        ),
        '-'
    ) AS Bilezik,

    --------------------------------------------------
    -- MÜŞTERİ
    --------------------------------------------------
    ISNULL(
        NULLIF(
            LTRIM(
                RTRIM(
                    ISNULL(lead.CustomerName, '')
                    + ' '
                    + ISNULL(lead.CustomerLastName, '')
                )
            ),
            ''
        ),
        '-'
    ) AS Musteri,

    ISNULL(
        NULLIF(
            LTRIM(RTRIM(lead.CityName)),
            ''
        ),
        '-'
    ) AS Lokasyon,

    ISNULL(
        NULLIF(
            LTRIM(RTRIM(lead.DistrictName)),
            ''
        ),
        '-'
    ) AS Ilce,

    ISNULL(
        NULLIF(
            LTRIM(RTRIM(lead.CountryName)),
            ''
        ),
        '-'
    ) AS Ulke,

    ISNULL(
        NULLIF(
            LTRIM(RTRIM(lead.CustomerInfo)),
            ''
        ),
        '-'
    ) AS MusteriInfo,

    CASE
        WHEN lead.IsShopping = 1
        THEN N'Evet'

        WHEN lead.IsShopping = 0
        THEN N'Hayır'

        ELSE '-'
    END AS AlisverisiVarMi,

    ISNULL(
        NULLIF(
            LTRIM(RTRIM(lead.Tel)),
            ''
        ),
        '-'
    ) AS IrtibatNumarasi,

    ISNULL(
        NULLIF(
            LTRIM(RTRIM(lead.Email)),
            ''
        ),
        '-'
    ) AS EmailAdresi,

    ISNULL(
        NULLIF(
            LTRIM(RTRIM(lead.ContactResourceName)),
            ''
        ),
        '-'
    ) AS IletisimKaynagi,

    --------------------------------------------------
    -- SATIŞ DANIŞMANI
    --------------------------------------------------
    ISNULL(
        NULLIF(
            LTRIM(
                RTRIM(
                    ISNULL(lead.SalesPersonFirstName, '')
                    + ' '
                    + ISNULL(lead.SalesPersonLastName, '')
                )
            ),
            ''
        ),
        '-'
    ) AS SatisDanismani,

    --------------------------------------------------
    -- TERMİN
    --------------------------------------------------
    ISNULL(
        CASE
            WHEN lead.EstimatedDate IS NOT NULL
            THEN
                CAST(
                    YEAR(lead.EstimatedDate)
                    AS VARCHAR(4)
                )
                + ' '
                + DATENAME(
                    MONTH,
                    lead.EstimatedDate
                )
            ELSE NULL
        END,
        '-'
    ) AS TerminTarihi,

    --------------------------------------------------
    -- TAKİP VE SÜREÇ
    --------------------------------------------------
    ISNULL(
        NULLIF(
            LTRIM(RTRIM(lead.LeadStatusName)),
            ''
        ),
        '-'
    ) AS LeadDurumu,

    ISNULL(
        NULLIF(
            LTRIM(RTRIM(lead.NextStepName)),
            ''
        ),
        '-'
    ) AS SonrakiAdim,

    ISNULL(
        NULLIF(
            LTRIM(RTRIM(lead.ProcessName)),
            ''
        ),
        '-'
    ) AS ProcessName,

    ISNULL(
        NULLIF(
            LTRIM(RTRIM(lead.ProcessCode)),
            ''
        ),
        '-'
    ) AS ProcessCode,

    lead.StepOrder,

    CAST(
        ISNULL(
            lead.StepOrder,
            0
        )
    AS INT) AS SelectedStepOrder,

    --------------------------------------------------
    -- MAĞAZA
    --------------------------------------------------
    ISNULL(
        NULLIF(
            LTRIM(RTRIM(lead.StoreCode)),
            ''
        ),
        '-'
    ) AS StoreCode,

    ISNULL(
        NULLIF(
            LTRIM(RTRIM(lead.StoreName)),
            ''
        ),
        '-'
    ) AS StoreName

FROM PriorityTaskKeys task

INNER JOIN LeadBase lead
    ON lead.LeadId = task.LeadId

WHERE
(
    @TaskFilter = 0

    OR (@TaskFilter = 1 AND task.GorevOnceligi = 3)

    OR (@TaskFilter = 2 AND task.GorevOnceligi = 2)

    OR (@TaskFilter = 3 AND task.GorevOnceligi = 1)
)

ORDER BY
    --------------------------------------------------
    -- 1. REZERV ONAYI
    -- 2. SATIŞA HAZIR
    -- 3. REZERV EDİLMEYİ BEKLEYEN
    --------------------------------------------------
    task.GorevOnceligi ASC,

    --------------------------------------------------
    -- ESKİ GÖREVLER ÖNCE
    --------------------------------------------------
    task.GorevTarihi ASC,

    lead.LeadCode ASC;", new string[] { "GorevTipi", "GorevAksiyonu", "AksiyonKodu", "GorevOnceligi", "FifoSirasi", "DogrudanRezervShow", "RezervTalebiGonderShow", "RezervOnaylaShow", "SatisYapShow", "ToplamStok", "RezerveStok", "BekleyenRezervTalebi", "MusaitStok", "YeniRezervTalebiKapasitesi", "ReservationId", "ReservedBy", "ReservedAt", "ReservationNote", "RezerveDurumu", "LeadId", "ProductId", "StoreId", "SalesPersonKUserId", "CreatedBy", "LeadNumarasi", "TalepTarihi", "ProductName", "Brand", "CategoryName", "CategoryLevel", "RefCode", "Referans", "Kadran", "Bilezik", "Musteri", "Lokasyon", "Ilce", "Ulke", "MusteriInfo", "AlisverisiVarMi", "IrtibatNumarasi", "EmailAdresi", "IletisimKaynagi", "SatisDanismani", "TerminTarihi", "LeadDurumu", "SonrakiAdim", "ProcessName", "ProcessCode", "StepOrder", "SelectedStepOrder", "StoreCode", "StoreName" }, prms_TMSalesPersonDashBoardTaskList_1.ToArray());
            ;

            var prms_TM_DefDashAnalysis_2 = new List<kSqlParameter>();
            prms_TM_DefDashAnalysis_2.Add(new kSqlParameter() { Name = "ThisMonth", Value = "0".ConvertToType<Int32>() });
            prms_TM_DefDashAnalysis_2.Add(new kSqlParameter() { Name = "UserId", Value = Kuika.Common.KContext.CurrentUser?.Id });
            using var auditTM_DefDashAnalysis_2 = ActionAuditScope.Begin("433156d9-5c3b-5b62-aca3-592269608235", "TM_DefDashAnalysis", applicationName: "wbTimesCRM", screenOrEndpointName: "DashBoardTemp");
            result.TM_DefDashAnalysis = KPersister.Fetch(KContext.GetConnectionString(), @"SET NOCOUNT ON;


DECLARE @StartDate DATETIMEOFFSET;
DECLARE @EndDate DATETIMEOFFSET;

IF @ThisMonth = 1
BEGIN
    SET @StartDate = DATEFROMPARTS(YEAR(GETDATE()), MONTH(GETDATE()), 1);
    SET @EndDate = DATEADD(MONTH, 1, @StartDate);
END
ELSE
BEGIN
    SET @StartDate = '1900-01-01';
    SET @EndDate = '2999-12-31';
END;

;WITH FilteredLead AS
(
    SELECT
        L.Id,
        L.StoreId,
        L.SalesPersonKUserId,
        P.Code AS ProcessCode
    FROM tmscrq.TMLead L
    INNER JOIN tmscrq.TMLeadProcess P ON P.Id = L.ProcessID
    WHERE L.CreatedAt >= @StartDate
      AND L.CreatedAt < @EndDate
      -- Yetki kontrolü
      AND (
          -- Yönetici / Üst Yönetici ise tüm lead'ler
          EXISTS (
              SELECT 1
              FROM dbo.KUserRole ur
              INNER JOIN dbo.KRole r ON r.Id = ur.KRole_Id
              WHERE ur.KUser_Id = @UserId
                AND ur.IsDeleted = 0
                AND r.IsDeleted = 0
                AND r.Name IN ('TimesYonetici', 'TimesUstYonetici')
          )
          OR
          -- Mağaza Müdürü ise kendi mağazasındaki lead'ler
          (
              EXISTS (
                  SELECT 1
                  FROM dbo.KUserRole ur
                  INNER JOIN dbo.KRole r ON r.Id = ur.KRole_Id
                  WHERE ur.KUser_Id = @UserId
                    AND ur.IsDeleted = 0
                    AND r.IsDeleted = 0
                    AND r.Name = 'TimesMagazaMuduru'
              )
              AND L.StoreId IN (
                  SELECT tu.StoreId
                  FROM tmscrq.TMUser tu
                  WHERE tu.KUserID = @UserId
              )
          )
          OR
          -- Satış Personeli ise kendi açtığı lead'ler
          (
              EXISTS (
                  SELECT 1
                  FROM dbo.KUserRole ur
                  INNER JOIN dbo.KRole r ON r.Id = ur.KRole_Id
                  WHERE ur.KUser_Id = @UserId
                    AND ur.IsDeleted = 0
                    AND r.IsDeleted = 0
                    AND r.Name = 'TimesSatisPersoneli'
              )
              AND L.SalesPersonKUserId = @UserId
          )
      )
),

PersonStats AS
(
    SELECT
        U.FullName,
        COUNT(*) AS TotalLead,
        SUM(CASE WHEN FL.ProcessCode = 'DELIVERED' THEN 1 ELSE 0 END) AS SoldLead,
        CAST(
            (100.0 * SUM(CASE WHEN FL.ProcessCode = 'DELIVERED' THEN 1 ELSE 0 END)) /
            NULLIF(COUNT(*),0)
        AS DECIMAL(18,2)) AS ConversionRate
    FROM FilteredLead FL
    INNER JOIN tmscrq.TMUser U ON U.KuserID = FL.SalesPersonKUserId
    GROUP BY U.FullName
),

BestPerson AS
(
    SELECT TOP 1
        FullName,
        TotalLead,
        SoldLead,
        ConversionRate
    FROM PersonStats
    WHERE TotalLead > 0
    ORDER BY ConversionRate DESC, SoldLead DESC, TotalLead DESC
),

StoreStats AS
(
    SELECT
        S.StoreDesc,
        COUNT(*) AS TotalLead,
        SUM(CASE WHEN FL.ProcessCode = 'DELIVERED' THEN 1 ELSE 0 END) AS SoldLead,
        CAST(
            (100.0 * SUM(CASE WHEN FL.ProcessCode = 'DELIVERED' THEN 1 ELSE 0 END)) /
            NULLIF(COUNT(*),0)
        AS DECIMAL(18,2)) AS ConversionRate
    FROM FilteredLead FL
    INNER JOIN tmscrq.TMStore S ON S.Id = FL.StoreId
    GROUP BY S.StoreDesc
),

BestStore AS
(
    SELECT TOP 1
        StoreDesc,
        TotalLead,
        SoldLead,
        ConversionRate
    FROM StoreStats
    WHERE TotalLead > 0
    ORDER BY ConversionRate DESC, SoldLead DESC, TotalLead DESC
)

SELECT
    BP.FullName               AS BestSalesPerson,
    BP.TotalLead              AS PersonTotalLead,
    BP.SoldLead               AS PersonSoldLead,
    BP.ConversionRate         AS PersonConversionRate,

    BS.StoreDesc              AS BestStore,
    BS.TotalLead              AS StoreTotalLead,
    BS.SoldLead               AS StoreSoldLead,
    BS.ConversionRate         AS StoreConversionRate
FROM BestPerson BP
CROSS JOIN BestStore BS;", new string[] { "BestSalesPerson", "PersonTotalLead", "PersonSoldLead", "PersonConversionRate", "BestStore", "StoreTotalLead", "StoreSoldLead", "StoreConversionRate" }, prms_TM_DefDashAnalysis_2.ToArray());
            ;

            var prms_TM_TopManagerDashboardLeadList_3 = new List<kSqlParameter>();
            prms_TM_TopManagerDashboardLeadList_3.Add(new kSqlParameter() { Name = "UserId", Value = Kuika.Common.KContext.CurrentUser?.Id });
            prms_TM_TopManagerDashboardLeadList_3.Add(new kSqlParameter() { Name = "MusteriAdi", Value = (null as object) });
            prms_TM_TopManagerDashboardLeadList_3.Add(new kSqlParameter() { Name = "ProductName", Value = (null as object) });
            prms_TM_TopManagerDashboardLeadList_3.Add(new kSqlParameter() { Name = "LeadCode", Value = (null as object) });
            prms_TM_TopManagerDashboardLeadList_3.Add(new kSqlParameter() { Name = "Tel", Value = (null as object) });
            prms_TM_TopManagerDashboardLeadList_3.Add(new kSqlParameter() { Name = "CategoryName", Value = (null as object) });
            prms_TM_TopManagerDashboardLeadList_3.Add(new kSqlParameter() { Name = "StoreIds", Value = (null as object) });
            prms_TM_TopManagerDashboardLeadList_3.Add(new kSqlParameter() { Name = "SatisDanismaniIds", Value = (null as object) });
            prms_TM_TopManagerDashboardLeadList_3.Add(new kSqlParameter() { Name = "ProcessCode", Value = (null as object) });
            prms_TM_TopManagerDashboardLeadList_3.Add(new kSqlParameter() { Name = "StepOrder", Value = "0".ConvertToType<Int32>() });
            prms_TM_TopManagerDashboardLeadList_3.Add(new kSqlParameter() { Name = "StartDate", Value = (null as object) });
            prms_TM_TopManagerDashboardLeadList_3.Add(new kSqlParameter() { Name = "EndDate", Value = (null as object) });
            using var auditTM_TopManagerDashboardLeadList_3 = ActionAuditScope.Begin("ba56f470-0dbc-a1f9-e7bd-5db3616783fd", "TM_TopManagerDashboardLeadList", applicationName: "wbTimesCRM", screenOrEndpointName: "DashBoardTemp");
            result.TM_TopManagerDashboardLeadList = KPersister.Fetch(KContext.GetConnectionString(), @"SET LANGUAGE Turkish;


SELECT
    CASE 
        WHEN EXISTS (
            SELECT 1 
            FROM tmscrq.TMLeadReservation r
            WHERE r.LeadId = l.Id
              AND r.IsActive = 1
              AND r.IsApproved = 1
        ) THEN N'Evet'
        WHEN EXISTS (
            SELECT 1 
            FROM tmscrq.TMLeadReservation r
            WHERE r.LeadId = l.Id
              AND r.IsActive = 1
              AND ISNULL(r.IsApproved,0) = 0
        ) THEN N'Onay Bekliyor'
        ELSE N'Hayır'
    END AS RezerveDurumu,
    l.Id AS LeadId,
    l.IsReserved,
    ISNULL(NULLIF(LTRIM(RTRIM(l.LeadCode)), ''), '-') AS LeadNumarasi,
    CONVERT(varchar(10), l.CreatedAt, 103) AS TalepTarihi,

    p.Id AS ProductId,
    ISNULL(NULLIF(LTRIM(RTRIM(p.ProductName)), ''), '-') AS ProductName,
    ISNULL(NULLIF(LTRIM(RTRIM(p.Bracelet)), ''), '-') AS Bilezik,
    ISNULL(NULLIF(LTRIM(RTRIM(p.Brand)), ''), '-') AS Brand,
    ISNULL(NULLIF(LTRIM(RTRIM(p.Dial)), ''), '-') AS Kadran,
    ISNULL(NULLIF(LTRIM(RTRIM(p.ProductCode)), ''), '-') AS RefCode,
    ISNULL(NULLIF(LTRIM(RTRIM(p.Referance)), ''), '-') AS Referans,

    ISNULL(
        NULLIF(
            LTRIM(RTRIM(ISNULL(cu.Name, '') + ' ' + ISNULL(cu.LastName, '')))
        , '')
    , '-') AS Musteri,

    ISNULL(NULLIF(LTRIM(RTRIM(cu.CityName)), ''), '-') AS Lokasyon,
    ISNULL(NULLIF(LTRIM(RTRIM(cu.DistrictName)), ''), '-') AS Ilce,
    ISNULL(NULLIF(LTRIM(RTRIM(cu.CountryName)), ''), '-') AS Ulke,
    ISNULL(NULLIF(LTRIM(RTRIM(cu.Info)), ''), '-') AS MusteriInfo,

    CASE
        WHEN cu.IsShopping = 1 THEN N'Evet'
        WHEN cu.IsShopping = 0 THEN N'Hayır'
        ELSE '-'
    END AS AlisverisiVarMi,

    ISNULL(NULLIF(LTRIM(RTRIM(cu.Tel)), ''), '-') AS IrtibatNumarasi,
    ISNULL(NULLIF(LTRIM(RTRIM(cu.Email)), ''), '-') AS EmailAdresi,

    ISNULL(NULLIF(LTRIM(RTRIM(cr.ContactResourceName)), ''), '-') AS IletisimKaynagi,

    ISNULL(NULLIF(LTRIM(RTRIM(p.CategoryName)), ''), '-') AS CategoryName,
    '-' AS CategoryCode,

    ISNULL(NULLIF(LTRIM(RTRIM(ls.Name)), ''), '-') AS LeadDurumu,
    ISNULL(NULLIF(LTRIM(RTRIM(ns.Name)), ''), '-') AS SonrakiAdim,

    ISNULL(NULLIF(LTRIM(RTRIM(lp.Name)), ''), '-') AS ProcessName,
    ISNULL(NULLIF(LTRIM(RTRIM(lp.Code)), ''), '-') AS ProcessCode,
    lp.StepOrder,
    
    CAST(ISNULL(@StepOrder, lp.StepOrder) AS INT) AS SelectedStepOrder,

    ISNULL(
        CASE
            WHEN l.EstimatedDate IS NOT NULL
            THEN CAST(YEAR(l.EstimatedDate) AS VARCHAR(4)) + ' ' + DATENAME(MONTH, l.EstimatedDate)
            ELSE NULL
        END,
        '-'
    ) AS TerminTarihi,

    ISNULL(
        NULLIF(
            LTRIM(RTRIM(ISNULL(sp.FirstName, '') + ' ' + ISNULL(sp.LastName, '')))
        , '')
    , '-') AS SatisDanismani,

    ISNULL(NULLIF(LTRIM(RTRIM(st.StoreDesc)), ''), '-') AS StoreName

FROM tmscrq.TMLead l
LEFT JOIN tmscrq.TMLeadStatu ls ON ls.Id = l.StatuId
LEFT JOIN tmscrq.TMCustomer cu ON cu.Id = l.CustomerId
LEFT JOIN tmscrq.TMProduct p ON p.Id = l.ProductId
LEFT JOIN tmscrq.TMContactResource cr ON cr.Id = l.ContactResourceId
LEFT JOIN dbo.KUser sp ON sp.Id = l.SalesPersonKUserId
LEFT JOIN tmscrq.TMStore st ON st.Id = l.StoreId
LEFT JOIN tmscrq.TMLeadProcess lp ON lp.Id = l.ProcessID
LEFT JOIN tmscrq.TMLeadNextStep ns ON ns.Id = l.NextStepId

WHERE
-- Yetkilendirme
(
    -- Yönetici / Üst Yönetici: Tüm lead'ler
    EXISTS (
        SELECT 1
        FROM dbo.KUserRole ur
        INNER JOIN dbo.KRole r ON r.Id = ur.KRole_Id
        WHERE ur.KUser_Id = @UserId
          AND ur.IsDeleted = 0
          AND r.IsDeleted = 0
          AND r.Name IN ('TimesYonetici', 'TimesUstYonetici')
    )

    OR

    -- Mağaza Müdürü: Kendi mağazasındaki tüm lead'ler
    (
        EXISTS (
            SELECT 1
            FROM dbo.KUserRole ur
            INNER JOIN dbo.KRole r ON r.Id = ur.KRole_Id
            WHERE ur.KUser_Id = @UserId
              AND ur.IsDeleted = 0
              AND r.IsDeleted = 0
              AND r.Name = 'TimesMagazaMuduru'
        )
        AND l.StoreId =
        (
            SELECT TOP 1 tu.StoreID
            FROM tmscrq.TMUser tu
            WHERE tu.KUserID = @UserId
        )
    )

    OR

    -- Satış Personeli: Sadece kendi açtığı lead'ler
    (
        EXISTS (
            SELECT 1
            FROM dbo.KUserRole ur
            INNER JOIN dbo.KRole r ON r.Id = ur.KRole_Id
            WHERE ur.KUser_Id = @UserId
              AND ur.IsDeleted = 0
              AND r.IsDeleted = 0
              AND r.Name = 'TimesSatisPersoneli'
        )
        AND l.SalesPersonKUserId = @UserId
    )
)

-- Müşteri Adı
AND
(
    @MusteriAdi IS NULL
    OR LTRIM(RTRIM(@MusteriAdi)) = ''
    OR UPPER(LTRIM(RTRIM(ISNULL(cu.Name,'') + ' ' + ISNULL(cu.LastName,''))))
       LIKE '%' + UPPER(LTRIM(RTRIM(@MusteriAdi))) + '%'
)

-- Ürün Adı
AND
(
    @ProductName IS NULL
    OR LTRIM(RTRIM(@ProductName)) = ''
    OR
    (
        CHARINDEX(',', @ProductName) > 0
        AND ISNULL(LTRIM(RTRIM(p.ProductName)), '') IN
        (
            SELECT LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', '')))
            FROM STRING_SPLIT(CAST(@ProductName AS NVARCHAR(MAX)), ',')
            WHERE LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', ''))) <> ''
        )
    )
    OR
    (
        CHARINDEX(',', @ProductName) = 0
        AND UPPER(ISNULL(LTRIM(RTRIM(p.ProductName)), ''))
            LIKE '%' + UPPER(LTRIM(RTRIM(@ProductName))) + '%'
    )
)

-- Lead Kodu
AND
(
    @LeadCode IS NULL
    OR LTRIM(RTRIM(@LeadCode)) = ''
    OR UPPER(ISNULL(LTRIM(RTRIM(l.LeadCode)), '')) LIKE '%' + UPPER(LTRIM(RTRIM(@LeadCode))) + '%'
)

-- Telefon
AND
(
    @Tel IS NULL
    OR LTRIM(RTRIM(@Tel)) = ''
    OR UPPER(ISNULL(LTRIM(RTRIM(cu.Tel)), '')) LIKE '%' + UPPER(LTRIM(RTRIM(@Tel))) + '%'
)

-- Kategori
AND
(
    @CategoryName IS NULL
    OR LTRIM(RTRIM(@CategoryName)) = ''
    OR UPPER(ISNULL(LTRIM(RTRIM(p.CategoryName)), '')) IN
    (
        SELECT UPPER(LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value,'""',''),'[',''),']',''))))
        FROM STRING_SPLIT(CAST(@CategoryName AS NVARCHAR(MAX)), ',')
        WHERE LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value,'""',''),'[',''),']',''))) <> ''
    )
)

-- Mağaza
AND
(
    @StoreIds IS NULL
    OR LTRIM(RTRIM(@StoreIds)) = ''
    OR EXISTS
    (
        SELECT 1
        FROM STRING_SPLIT(CAST(@StoreIds AS NVARCHAR(MAX)), ',') s
        WHERE l.StoreId = TRY_CONVERT
        (
            uniqueidentifier,
            LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(s.value, '""', ''), '[', ''), ']', '')))
        )
    )
)

-- Satış Danışmanı
AND
(
    @SatisDanismaniIds IS NULL
    OR LTRIM(RTRIM(@SatisDanismaniIds)) = ''
    OR EXISTS
    (
        SELECT 1
        FROM STRING_SPLIT(CAST(@SatisDanismaniIds AS NVARCHAR(MAX)), ',') s
        WHERE l.SalesPersonKUserId = TRY_CONVERT
        (
            uniqueidentifier,
            LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(s.value, '""', ''), '[', ''), ']', '')))
        )
    )
)

-- Süreç Kodu
AND
(
    @ProcessCode IS NULL
    OR LTRIM(RTRIM(@ProcessCode)) = ''
    OR UPPER(ISNULL(LTRIM(RTRIM(lp.Code)), '')) IN
    (
        SELECT UPPER(LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', ''))))
        FROM STRING_SPLIT(CAST(@ProcessCode AS NVARCHAR(MAX)), ',')
        WHERE LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', ''))) <> ''
    )
)

-- StepOrder Filtresi (genişletilmiş, -4 eklendi)
AND
(
    @StepOrder IS NULL
    OR @StepOrder = 0   -- Tümü

    -- Aktif: CREATED, TERMIN_PENDING, PENDING, APPROVED, DELIVERY_PENDING
    OR (@StepOrder = -1 AND lp.Code IN ('CREATED','TERMIN_PENDING','PENDING','APPROVED','DELIVERY_PENDING'))

    -- Bugün oluşturulanlar
    OR (
        @StepOrder = -2 
        AND l.CreatedAt >= CAST(GETDATE() AS DATE) 
        AND l.CreatedAt < DATEADD(day, 1, CAST(GETDATE() AS DATE))
    )

    -- Geciken (Termin Tarihi Geçmiş): EstimatedDate bugünden küçük ve sonuçlanmamış
    OR (
        @StepOrder = -3 
        AND l.EstimatedDate < CAST(GETDATE() AS DATE) 
        AND lp.Code NOT IN ('DELIVERED','CLOSED','CUSTOMER_DECLINED','REJECTED')
    )

    -- Bu ayın terminleri
    OR (
        @StepOrder = -4 
        AND l.EstimatedDate >= DATEFROMPARTS(YEAR(GETDATE()), MONTH(GETDATE()), 1)
        AND l.EstimatedDate < DATEADD(MONTH, 1, DATEFROMPARTS(YEAR(GETDATE()), MONTH(GETDATE()), 1))
    )

    -- Rezerv onay bekleyen
    OR (
        @StepOrder = 10 
        AND EXISTS (
            SELECT 1 
            FROM tmscrq.TMLeadReservation r 
            WHERE r.LeadId = l.Id 
              AND r.IsActive = 1 
              AND ISNULL(r.IsApproved,0) = 0
        )
    )

    -- Diğer pozitif StepOrder değerleri
    OR (
        @StepOrder NOT IN (0, -1, -2, -3, -4, 10) 
        AND lp.StepOrder = @StepOrder
    )
)

-- Başlangıç Tarihi
AND
(
    @StartDate IS NULL
    OR LTRIM(RTRIM(@StartDate)) = ''
    OR l.CreatedAt >= CONVERT(date, @StartDate)
)

-- Bitiş Tarihi
AND
(
    @EndDate IS NULL
    OR LTRIM(RTRIM(@EndDate)) = ''
    OR l.CreatedAt < DATEADD(day, 1, CONVERT(date, @EndDate))
)

ORDER BY l.CreatedAt DESC;", new string[] { "RezerveDurumu", "LeadId", "IsReserved", "LeadNumarasi", "TalepTarihi", "ProductId", "ProductName", "Bilezik", "Brand", "Kadran", "RefCode", "Referans", "Musteri", "Lokasyon", "Ilce", "Ulke", "MusteriInfo", "AlisverisiVarMi", "IrtibatNumarasi", "EmailAdresi", "IletisimKaynagi", "CategoryName", "CategoryCode", "LeadDurumu", "SonrakiAdim", "ProcessName", "ProcessCode", "StepOrder", "SelectedStepOrder", "TerminTarihi", "SatisDanismani", "StoreName" }, prms_TM_TopManagerDashboardLeadList_3.ToArray());
            ;

            var prms_TM_GetProductCategory_4 = new List<kSqlParameter>();
            using var auditTM_GetProductCategory_4 = ActionAuditScope.Begin("86496e83-76be-a6c9-13f1-89cc632b2c6d", "TM_GetProductCategory", applicationName: "wbTimesCRM", screenOrEndpointName: "DashBoardTemp");
            result.TM_GetProductCategory = KPersister.Fetch(KContext.GetConnectionString(), @"SELECT
    pc.CategoryName,
    pc.CategoryCode
FROM tmscrq.TMProductCategory pc
ORDER BY
    pc.CategoryName;", new string[] { "CategoryName", "CategoryCode" }, prms_TM_GetProductCategory_4.ToArray());
            ;

            var prms_TM_GetStore_5 = new List<kSqlParameter>();
            prms_TM_GetStore_5.Add(new kSqlParameter() { Name = "KUserId", Value = Kuika.Common.KContext.CurrentUser?.Id });
            using var auditTM_GetStore_5 = ActionAuditScope.Begin("02bf09dc-0760-4cfb-a092-c29f3e17b4f2", "TM_GetStore", applicationName: "wbTimesCRM", screenOrEndpointName: "DashBoardTemp");
            result.TM_GetStore = KPersister.Fetch(KContext.GetConnectionString(), @"WITH UserRoles AS (
    SELECT r.Name
    FROM KUserRole ur
    INNER JOIN KRole r 
        ON r.Id = ur.KRole_Id
    WHERE ur.KUser_Id = @KUserId
      AND ur.IsDeleted = 0
),
IsAdmin AS (
    SELECT CASE 
        WHEN EXISTS (
            SELECT 1 
            FROM UserRoles 
            WHERE Name = 'TimesUstYonetici'
        ) THEN 1 ELSE 0 END AS IsAdmin
)

SELECT
    s.Id,
    s.StoreDesc,
    s.StoreCode
FROM tmscrq.TMStore s
CROSS JOIN IsAdmin a
WHERE 
    -- sadece numeric store code
    TRY_CAST(s.StoreCode AS INT) IS NOT NULL

    AND (
        -- admin → full liste
        a.IsAdmin = 1

        -- diğerleri → sadece kendi storeları
        OR s.Id IN (
            SELECT tu.StoreID
            FROM tmscrq.TMUser tu
            WHERE tu.KuserID = @KUserId
        )
    )
ORDER BY TRY_CAST(s.StoreCode AS INT);", new string[] { "Id", "StoreDesc", "StoreCode" }, prms_TM_GetStore_5.ToArray());
            ;

            var prms_TM_GetSalesPerson_6 = new List<kSqlParameter>();
            prms_TM_GetSalesPerson_6.Add(new kSqlParameter() { Name = "KUserId", Value = Kuika.Common.KContext.CurrentUser?.Id });
            prms_TM_GetSalesPerson_6.Add(new kSqlParameter() { Name = "StoreId", Value = (null as object) });
            using var auditTM_GetSalesPerson_6 = ActionAuditScope.Begin("96b60eb6-0a2a-d8e9-7226-abf830b2e870", "TM_GetSalesPerson", applicationName: "wbTimesCRM", screenOrEndpointName: "DashBoardTemp");
            result.TM_GetSalesPerson = KPersister.Fetch(KContext.GetConnectionString(), @"-- SELECT 
--     KU.Id AS KUserId,

--     LTRIM(RTRIM(
--         ISNULL(KU.FirstName, '') + 
--         CASE 
--             WHEN KU.LastName IS NOT NULL AND KU.LastName <> '' 
--             THEN ' ' + KU.LastName 
--             ELSE '' 
--         END
--     )) AS FullName,

--     KU.IsDeleted,

--     STRING_AGG(R.Name, ', ') AS RoleNames,

--     TU.Id AS TMUserId,
--     TU.StoreID,
--     TS.StoreCode,
--     TS.StoreDesc

-- FROM dbo.KUser KU

-- INNER JOIN tmscrq.TMUser TU
--     ON TU.KUserID = KU.Id

-- LEFT JOIN tmscrq.TMStore TS
--     ON TS.Id = TU.StoreID

-- INNER JOIN dbo.KUserRole UR 
--     ON UR.KUser_Id = KU.Id

-- INNER JOIN dbo.KRole R 
--     ON R.Id = UR.KRole_Id
--     AND R.Name IN (
--         'TimesAdmin',
--         'TimesUstYonetici',
--         'TimesYonetici',
--         'TimesSatisPersoneli',
--         'TimesMagazaMuduru'
--     )

-- WHERE 
--     KU.IsDeleted = 0
--     AND UR.IsDeleted = 0
--     AND R.IsDeleted = 0
--     AND (
--         @StoreId IS NULL
--         OR TU.StoreID = @StoreId
--     )

-- GROUP BY 
--     KU.Id,
--     KU.FirstName,
--     KU.LastName,
--     KU.IsDeleted,
--     TU.Id,
--     TU.StoreID,
--     TS.StoreCode,
--     TS.StoreDesc

-- ORDER BY
--     FullName;

-------------------------------------------------



WITH UserRoles AS (
    SELECT r.Name
    FROM dbo.KUserRole ur
    INNER JOIN dbo.KRole r 
        ON r.Id = ur.KRole_Id
    WHERE ur.KUser_Id = @KUserId
      AND ur.IsDeleted = 0
      AND r.IsDeleted = 0
),
IsAdmin AS (
    SELECT CASE 
        WHEN EXISTS (
            SELECT 1 
            FROM UserRoles 
            WHERE Name = 'TimesUstYonetici'
        ) THEN 1 ELSE 0 END AS IsAdmin
),
MyStores AS (
    SELECT StoreID
    FROM tmscrq.TMUser
    WHERE KUserID = @KUserId
)

SELECT 
    KU.Id AS KUserId,

    LTRIM(RTRIM(
        ISNULL(KU.FirstName, '') + 
        CASE 
            WHEN KU.LastName IS NOT NULL AND KU.LastName <> '' 
            THEN ' ' + KU.LastName 
            ELSE '' 
        END
    )) AS FullName,

    STRING_AGG(R.Name, ', ') AS RoleNames,

    TU.Id AS TMUserId,
    TU.StoreID,
    TS.StoreCode,
    TS.StoreDesc

FROM dbo.KUser KU

INNER JOIN tmscrq.TMUser TU
    ON TU.KUserID = KU.Id

LEFT JOIN tmscrq.TMStore TS
    ON TS.Id = TU.StoreID

INNER JOIN dbo.KUserRole UR 
    ON UR.KUser_Id = KU.Id

INNER JOIN dbo.KRole R 
    ON R.Id = UR.KRole_Id
    AND R.Name IN (
        'TimesSatisPersoneli', 'TimesMagazaMuduru' -- sadece satış personelleri gelsin
    )

CROSS JOIN IsAdmin a

WHERE 
    KU.IsDeleted = 0
    AND UR.IsDeleted = 0
    AND R.IsDeleted = 0

    AND
    (
        -- 🔥 1. Store seçilmişse direkt store'a göre
        (
            @StoreId IS NOT NULL
            AND TU.StoreID = @StoreId
        )

        OR

        -- 🔥 2. Store seçilmemişse rol bazlı çalış
        (
            @StoreId IS NULL
            AND
            (
                -- üst yönetici → hepsi
                a.IsAdmin = 1

                -- diğerleri → kendi storeları
                OR TU.StoreID IN (SELECT StoreID FROM MyStores)
            )
        )
    )

GROUP BY 
    KU.Id,
    KU.FirstName,
    KU.LastName,
    TU.Id,
    TU.StoreID,
    TS.StoreCode,
    TS.StoreDesc

ORDER BY
    FullName;", new string[] { "KUserId", "FullName", "RoleNames", "TMUserId", "StoreID", "StoreCode", "StoreDesc" }, prms_TM_GetSalesPerson_6.ToArray());
            ;

            var prms_TM_GetLeadStatus_7 = new List<kSqlParameter>();
            using var auditTM_GetLeadStatus_7 = ActionAuditScope.Begin("5646dd3b-7ca0-80c0-312b-8690e6a91781", "TM_GetLeadStatus", applicationName: "wbTimesCRM", screenOrEndpointName: "DashBoardTemp");
            result.TM_GetLeadStatus = KPersister.Fetch(KContext.GetConnectionString(), @"SELECT *
FROM tmscrq.TMLeadStatu
WHERE Code IN ('FOLLOW_UP_1', 'FOLLOW_UP_2')
ORDER BY 
    CASE Code
        WHEN 'FOLLOW_UP_1' THEN 1
        WHEN 'FOLLOW_UP_2' THEN 2
    END;
", new string[] { "Id", "Code", "Name", "IsActive" }, prms_TM_GetLeadStatus_7.ToArray());
            ;

            var prms_TM_GetLeadProcess_8 = new List<kSqlParameter>();
            prms_TM_GetLeadProcess_8.Add(new kSqlParameter() { Name = "StepOrder", Value = "0".ConvertToType<Int32>() });
            using var auditTM_GetLeadProcess_8 = ActionAuditScope.Begin("7840e3b4-3241-4bec-cc94-20566c3838b5", "TM_GetLeadProcess", applicationName: "wbTimesCRM", screenOrEndpointName: "DashBoardTemp");
            result.TM_GetLeadProcess = KPersister.Fetch(KContext.GetConnectionString(), @"SELECT
    Id,
    Name,
    Code,
    Note,
    StepOrder
FROM tmscrq.TMLeadProcess
WHERE
    StepOrder IS NOT NULL
    AND StepOrder NOT IN (2, 8, 9)   -- 🔥 EKLENDİ
    AND (
        @StepOrder IS NULL
        OR @StepOrder = 0
        OR StepOrder = @StepOrder
    )
ORDER BY
    StepOrder;", new string[] { "Id", "Name", "Code", "Note", "StepOrder" }, prms_TM_GetLeadProcess_8.ToArray());
            ;

            var prms_TM_GetUserStoreInfo_9 = new List<kSqlParameter>();
            prms_TM_GetUserStoreInfo_9.Add(new kSqlParameter() { Name = "UserId", Value = Kuika.Common.KContext.CurrentUser?.Id });
            using var auditTM_GetUserStoreInfo_9 = ActionAuditScope.Begin("1f3b6c25-9c37-6374-3707-1d6e99660bce", "TM_GetUserStoreInfo", applicationName: "wbTimesCRM", screenOrEndpointName: "DashBoardTemp");
            result.TM_GetUserStoreInfo = KPersister.Fetch(KContext.GetConnectionString(), @"SELECT 
    ku.Id AS KUserId,
    ku.Username,
    ku.FirstName,
    ku.LastName,
    ku.CreatedAt,
    ku.IsDeleted,
    ku.CreatedUser_Id,

    st.StoreDesc AS SubeAdi

FROM dbo.KUser ku
LEFT JOIN tmscrq.TMUser tu
    ON tu.KUserID = ku.Id
LEFT JOIN tmscrq.TMStore st
    ON st.Id = tu.StoreId   -- ✅ DOĞRU BAĞLANTI

WHERE ku.Id = @UserId;
", new string[] { "KUserId", "Username", "FirstName", "LastName", "CreatedAt", "IsDeleted", "CreatedUser_Id", "SubeAdi" }, prms_TM_GetUserStoreInfo_9.ToArray());
            ;

            var prms_TM_UserRoleByUserId_10 = new List<kSqlParameter>();
            prms_TM_UserRoleByUserId_10.Add(new kSqlParameter() { Name = "UserID", Value = Kuika.Common.KContext.CurrentUser?.Id });
            using var auditTM_UserRoleByUserId_10 = ActionAuditScope.Begin("6f39769f-cce7-2ef2-af23-a066b1679959", "TM_UserRoleByUserId", applicationName: "wbTimesCRM", screenOrEndpointName: "DashBoardTemp");
            result.TM_UserRoleByUserId = KPersister.Fetch(KContext.GetConnectionString(), @"

SELECT 
    KU.Id AS UserId,
    KU.Username AS UserName,
    KU.FirstName AS FirstName,
    KU.LastName AS LastName,
    ISNULL(
    STRING_AGG(
        CASE 
            WHEN R.Name = 'TimesAdmin'           THEN N'Admin'
            WHEN R.Name = 'TimesUstYonetici'     THEN N'Üst Yönetici'
            WHEN R.Name = 'TimesYonetici'        THEN N'Yönetici'
            WHEN R.Name = 'TimesSatisPersoneli'  THEN N'Satış Personeli'
            WHEN R.Name = 'TimesMagazaMuduru'    THEN N'Mağaza Müdürü'
            ELSE NULL
        END,
        '  '
    ),
    'Rol Yok'
) AS RoleNames,
ISNULL( STRING_AGG( CASE WHEN R.Name IN ( 'TimesAdmin', 'TimesUstYonetici', 'TimesYonetici', 'TimesSatisPersoneli', 'TimesMagazaMuduru' ) THEN R.Name ELSE NULL END, ', ' ), 'Rol Yok' ) AS Role
FROM dbo.KUser KU
LEFT JOIN dbo.KUserRole UR 
    ON UR.KUser_Id = KU.Id AND UR.IsDeleted = 0
LEFT JOIN dbo.KRole R 
    ON R.Id = UR.KRole_Id AND R.IsDeleted = 0
WHERE KU.IsDeleted = 0
  AND KU.Id = @UserID
GROUP BY KU.Id,KU.UserName, KU.FirstName, KU.LastName;
", new string[] { "UserId", "UserName", "FirstName", "LastName", "RoleNames", "Role" }, prms_TM_UserRoleByUserId_10.ToArray());
            ;

            var prms_TM_LeadProcessCountGrafik_11 = new List<kSqlParameter>();
            prms_TM_LeadProcessCountGrafik_11.Add(new kSqlParameter() { Name = "UserId", Value = Kuika.Common.KContext.CurrentUser?.Id });
            prms_TM_LeadProcessCountGrafik_11.Add(new kSqlParameter() { Name = "StartDate", Value = (null as object) });
            prms_TM_LeadProcessCountGrafik_11.Add(new kSqlParameter() { Name = "EndDate", Value = (null as object) });
            using var auditTM_LeadProcessCountGrafik_11 = ActionAuditScope.Begin("b062622d-8408-798b-d186-c2d9d9681a60", "TM_LeadProcessCountGrafik", applicationName: "wbTimesCRM", screenOrEndpointName: "DashBoardTemp");
            result.TM_LeadProcessCountGrafik = KPersister.Fetch(KContext.GetConnectionString(), @"SET LANGUAGE Turkish;



SELECT
    ISNULL(lp.Code, '-') AS ProcessCode,
    ISNULL(lp.Name, '-') AS ProcessName,
    COUNT(l.Id) AS LeadCount
FROM tmscrq.TMLead l
LEFT JOIN tmscrq.TMLeadProcess lp ON lp.Id = l.ProcessID
WHERE
    -- Yetkilendirme
    (
        -- Yönetici / Üst Yönetici: tüm lead'ler
        EXISTS (
            SELECT 1
            FROM dbo.KUserRole ur
            INNER JOIN dbo.KRole r ON r.Id = ur.KRole_Id
            WHERE ur.KUser_Id = @UserId
              AND ur.IsDeleted = 0
              AND r.IsDeleted = 0
              AND r.Name IN ('TimesYonetici', 'TimesUstYonetici')
        )
        OR
        -- Mağaza Müdürü: kendi mağazasındaki lead'ler
        (
            EXISTS (
                SELECT 1
                FROM dbo.KUserRole ur
                INNER JOIN dbo.KRole r ON r.Id = ur.KRole_Id
                WHERE ur.KUser_Id = @UserId
                  AND ur.IsDeleted = 0
                  AND r.IsDeleted = 0
                  AND r.Name = 'TimesMagazaMuduru'
            )
            AND l.StoreId IN (
                SELECT tu.StoreId
                FROM tmscrq.TMUser tu
                WHERE tu.KUserID = @UserId
            )
        )
        OR
        -- Satış Personeli: yalnızca kendi açtığı lead'ler
        (
            EXISTS (
                SELECT 1
                FROM dbo.KUserRole ur
                INNER JOIN dbo.KRole r ON r.Id = ur.KRole_Id
                WHERE ur.KUser_Id = @UserId
                  AND ur.IsDeleted = 0
                  AND r.IsDeleted = 0
                  AND r.Name = 'TimesSatisPersoneli'
            )
            AND l.SalesPersonKUserId = @UserId
        )
    )
    -- Başlangıç tarihi
    AND (
        @StartDate IS NULL OR LTRIM(RTRIM(@StartDate)) = ''
        OR l.CreatedAt >= CONVERT(date, @StartDate)
    )
    -- Bitiş tarihi
    AND (
        @EndDate IS NULL OR LTRIM(RTRIM(@EndDate)) = ''
        OR l.CreatedAt < DATEADD(day, 1, CONVERT(date, @EndDate))
    )
GROUP BY lp.Code, lp.Name
ORDER BY LeadCount DESC;", new string[] { "ProcessCode", "ProcessName", "LeadCount" }, prms_TM_LeadProcessCountGrafik_11.ToArray());
            ;

            var prms_TM_CategoryGrafik_12 = new List<kSqlParameter>();
            prms_TM_CategoryGrafik_12.Add(new kSqlParameter() { Name = "UserId", Value = Kuika.Common.KContext.CurrentUser?.Id });
            prms_TM_CategoryGrafik_12.Add(new kSqlParameter() { Name = "StartDate", Value = (null as object) });
            prms_TM_CategoryGrafik_12.Add(new kSqlParameter() { Name = "EndDate", Value = (null as object) });
            using var auditTM_CategoryGrafik_12 = ActionAuditScope.Begin("7033380e-c4c8-ee36-ab0c-fe5974f915d4", "TM_CategoryGrafik", applicationName: "wbTimesCRM", screenOrEndpointName: "DashBoardTemp");
            result.TM_CategoryGrafik = KPersister.Fetch(KContext.GetConnectionString(), @"SET LANGUAGE Turkish;



SELECT
    ISNULL(p.CategoryName, '-') AS CategoryName,
    COUNT(l.Id) AS LeadCount
FROM tmscrq.TMLead l
LEFT JOIN tmscrq.TMProduct p ON p.Id = l.ProductId
WHERE
    -- Yetkilendirme
    (
        -- Yönetici / Üst Yönetici: tüm lead'ler
        EXISTS (
            SELECT 1
            FROM dbo.KUserRole ur
            INNER JOIN dbo.KRole r ON r.Id = ur.KRole_Id
            WHERE ur.KUser_Id = @UserId
              AND ur.IsDeleted = 0
              AND r.IsDeleted = 0
              AND r.Name IN ('TimesYonetici', 'TimesUstYonetici')
        )
        OR
        -- Mağaza Müdürü: kendi mağazasındaki lead'ler
        (
            EXISTS (
                SELECT 1
                FROM dbo.KUserRole ur
                INNER JOIN dbo.KRole r ON r.Id = ur.KRole_Id
                WHERE ur.KUser_Id = @UserId
                  AND ur.IsDeleted = 0
                  AND r.IsDeleted = 0
                  AND r.Name = 'TimesMagazaMuduru'
            )
            AND l.StoreId IN (
                SELECT tu.StoreId
                FROM tmscrq.TMUser tu
                WHERE tu.KUserID = @UserId
            )
        )
        OR
        -- Satış Personeli: yalnızca kendi açtığı lead'ler
        (
            EXISTS (
                SELECT 1
                FROM dbo.KUserRole ur
                INNER JOIN dbo.KRole r ON r.Id = ur.KRole_Id
                WHERE ur.KUser_Id = @UserId
                  AND ur.IsDeleted = 0
                  AND r.IsDeleted = 0
                  AND r.Name = 'TimesSatisPersoneli'
            )
            AND l.SalesPersonKUserId = @UserId
        )
    )
    -- Başlangıç tarihi
    AND (
        @StartDate IS NULL OR LTRIM(RTRIM(@StartDate)) = ''
        OR l.CreatedAt >= CONVERT(date, @StartDate)
    )
    -- Bitiş tarihi
    AND (
        @EndDate IS NULL OR LTRIM(RTRIM(@EndDate)) = ''
        OR l.CreatedAt < DATEADD(day, 1, CONVERT(date, @EndDate))
    )
GROUP BY p.CategoryName
ORDER BY LeadCount DESC;", new string[] { "CategoryName", "LeadCount" }, prms_TM_CategoryGrafik_12.ToArray());
            ;

            var prms_TM_SatisDonusumGrafik_13 = new List<kSqlParameter>();
            prms_TM_SatisDonusumGrafik_13.Add(new kSqlParameter() { Name = "UserId", Value = Kuika.Common.KContext.CurrentUser?.Id });
            prms_TM_SatisDonusumGrafik_13.Add(new kSqlParameter() { Name = "StartDate", Value = (null as object) });
            prms_TM_SatisDonusumGrafik_13.Add(new kSqlParameter() { Name = "EndDate", Value = (null as object) });
            using var auditTM_SatisDonusumGrafik_13 = ActionAuditScope.Begin("1fe75e89-275f-b042-fcdd-89a65dcd6595", "TM_SatisDonusumGrafik", applicationName: "wbTimesCRM", screenOrEndpointName: "DashBoardTemp");
            result.TM_SatisDonusumGrafik = KPersister.Fetch(KContext.GetConnectionString(), @"SET LANGUAGE Turkish;



SELECT
    COUNT(l.Id) AS ToplamLead,
    SUM(CASE WHEN lp.Code = 'DELIVERED' THEN 1 ELSE 0 END) AS SatisaDonusen,
    CAST(100.0 * SUM(CASE WHEN lp.Code = 'DELIVERED' THEN 1 ELSE 0 END) / NULLIF(COUNT(l.Id), 0) AS DECIMAL(10,2)) AS DonusumOrani
FROM tmscrq.TMLead l
LEFT JOIN tmscrq.TMLeadProcess lp ON lp.Id = l.ProcessID
WHERE
    -- Yetkilendirme
    (
        -- Yönetici / Üst Yönetici: tüm lead'ler
        EXISTS (
            SELECT 1
            FROM dbo.KUserRole ur
            INNER JOIN dbo.KRole r ON r.Id = ur.KRole_Id
            WHERE ur.KUser_Id = @UserId
              AND ur.IsDeleted = 0
              AND r.IsDeleted = 0
              AND r.Name IN ('TimesYonetici', 'TimesUstYonetici')
        )
        OR
        -- Mağaza Müdürü: kendi mağazasındaki lead'ler
        (
            EXISTS (
                SELECT 1
                FROM dbo.KUserRole ur
                INNER JOIN dbo.KRole r ON r.Id = ur.KRole_Id
                WHERE ur.KUser_Id = @UserId
                  AND ur.IsDeleted = 0
                  AND r.IsDeleted = 0
                  AND r.Name = 'TimesMagazaMuduru'
            )
            AND l.StoreId IN (
                SELECT tu.StoreId
                FROM tmscrq.TMUser tu
                WHERE tu.KUserID = @UserId
            )
        )
        OR
        -- Satış Personeli: yalnızca kendi açtığı lead'ler
        (
            EXISTS (
                SELECT 1
                FROM dbo.KUserRole ur
                INNER JOIN dbo.KRole r ON r.Id = ur.KRole_Id
                WHERE ur.KUser_Id = @UserId
                  AND ur.IsDeleted = 0
                  AND r.IsDeleted = 0
                  AND r.Name = 'TimesSatisPersoneli'
            )
            AND l.SalesPersonKUserId = @UserId
        )
    )
    -- Başlangıç tarihi
    AND (
        @StartDate IS NULL OR LTRIM(RTRIM(@StartDate)) = ''
        OR l.CreatedAt >= CONVERT(date, @StartDate)
    )
    -- Bitiş tarihi
    AND (
        @EndDate IS NULL OR LTRIM(RTRIM(@EndDate)) = ''
        OR l.CreatedAt < DATEADD(day, 1, CONVERT(date, @EndDate))
    );", new string[] { "ToplamLead", "SatisaDonusen", "DonusumOrani" }, prms_TM_SatisDonusumGrafik_13.ToArray());
            ;

            var prms_TM_GetSalesExchangesRate_14 = new List<kSqlParameter>();
            using var auditTM_GetSalesExchangesRate_14 = ActionAuditScope.Begin("a716b11f-57a4-1acc-1529-9add77e81155", "TM_GetSalesExchangesRate", applicationName: "wbTimesCRM", screenOrEndpointName: "DashBoardTemp");
            result.TM_GetSalesExchangesRate = KPersister.Fetch(KContext.GetConnectionString(), @"select * From tmscrq.TMSalesExchangeRate", new string[] { "Id", "CurrencyCode", "RateDate", "Rate" }, prms_TM_GetSalesExchangesRate_14.ToArray());
            ;


            return Ok(result);
        }


        [HttpPost, Route("DashBoardTempComponent_783535_onClick")]
        public IActionResult DashBoardTempComponent_783535_onClick(DashBoardTempComponent_783535_onClick_Request request)
        {

            KProviderManager.Authorization.IsAuthorizedForRoles(appId, appName, screenId, screenName, new List<string> { $"b4bfd39c-ac02-f442-c899-7a2374a45b47", "70de6cfc-6087-6059-59b4-0b5a8527af6b", "TimesSatisPersoneli", "TimesMagazaMuduru" });

            var result = new DashBoardTempComponent_783535_onClick_Response();

            var prms_TM_TopManagerDashboardLeadList_0 = new List<kSqlParameter>();
            prms_TM_TopManagerDashboardLeadList_0.Add(new kSqlParameter() { Name = "UserId", Value = Kuika.Common.KContext.CurrentUser?.Id });
            prms_TM_TopManagerDashboardLeadList_0.Add(new kSqlParameter() { Name = "MusteriAdi", Value = request.MusteriAdi_0 });
            prms_TM_TopManagerDashboardLeadList_0.Add(new kSqlParameter() { Name = "ProductName", Value = request.ProductName_0 });
            prms_TM_TopManagerDashboardLeadList_0.Add(new kSqlParameter() { Name = "LeadCode", Value = (null as object) });
            prms_TM_TopManagerDashboardLeadList_0.Add(new kSqlParameter() { Name = "Tel", Value = (null as object) });
            prms_TM_TopManagerDashboardLeadList_0.Add(new kSqlParameter() { Name = "CategoryName", Value = request.CategoryName_0 });
            prms_TM_TopManagerDashboardLeadList_0.Add(new kSqlParameter() { Name = "StoreIds", Value = request.StoreIds_0 });
            prms_TM_TopManagerDashboardLeadList_0.Add(new kSqlParameter() { Name = "SatisDanismaniIds", Value = request.SatisDanismaniIds_0 });
            prms_TM_TopManagerDashboardLeadList_0.Add(new kSqlParameter() { Name = "ProcessCode", Value = request.ProcessCode_0 });
            prms_TM_TopManagerDashboardLeadList_0.Add(new kSqlParameter() { Name = "StepOrder", Value = "-1".ConvertToType<Int32>() });
            prms_TM_TopManagerDashboardLeadList_0.Add(new kSqlParameter() { Name = "StartDate", Value = request.StartDate_0 });
            prms_TM_TopManagerDashboardLeadList_0.Add(new kSqlParameter() { Name = "EndDate", Value = request.EndDate_0 });
            using var auditTM_TopManagerDashboardLeadList_0 = ActionAuditScope.Begin("6b2a3752-83b3-6270-7e22-b9071dbfd367", "TM_TopManagerDashboardLeadList", applicationName: "wbTimesCRM", screenOrEndpointName: "DashBoardTemp");
            result.TM_TopManagerDashboardLeadList = KPersister.Fetch(KContext.GetConnectionString(), @"SET LANGUAGE Turkish;


SELECT
    CASE 
        WHEN EXISTS (
            SELECT 1 
            FROM tmscrq.TMLeadReservation r
            WHERE r.LeadId = l.Id
              AND r.IsActive = 1
              AND r.IsApproved = 1
        ) THEN N'Evet'
        WHEN EXISTS (
            SELECT 1 
            FROM tmscrq.TMLeadReservation r
            WHERE r.LeadId = l.Id
              AND r.IsActive = 1
              AND ISNULL(r.IsApproved,0) = 0
        ) THEN N'Onay Bekliyor'
        ELSE N'Hayır'
    END AS RezerveDurumu,
    l.Id AS LeadId,
    l.IsReserved,
    ISNULL(NULLIF(LTRIM(RTRIM(l.LeadCode)), ''), '-') AS LeadNumarasi,
    CONVERT(varchar(10), l.CreatedAt, 103) AS TalepTarihi,

    p.Id AS ProductId,
    ISNULL(NULLIF(LTRIM(RTRIM(p.ProductName)), ''), '-') AS ProductName,
    ISNULL(NULLIF(LTRIM(RTRIM(p.Bracelet)), ''), '-') AS Bilezik,
    ISNULL(NULLIF(LTRIM(RTRIM(p.Brand)), ''), '-') AS Brand,
    ISNULL(NULLIF(LTRIM(RTRIM(p.Dial)), ''), '-') AS Kadran,
    ISNULL(NULLIF(LTRIM(RTRIM(p.ProductCode)), ''), '-') AS RefCode,
    ISNULL(NULLIF(LTRIM(RTRIM(p.Referance)), ''), '-') AS Referans,

    ISNULL(
        NULLIF(
            LTRIM(RTRIM(ISNULL(cu.Name, '') + ' ' + ISNULL(cu.LastName, '')))
        , '')
    , '-') AS Musteri,

    ISNULL(NULLIF(LTRIM(RTRIM(cu.CityName)), ''), '-') AS Lokasyon,
    ISNULL(NULLIF(LTRIM(RTRIM(cu.DistrictName)), ''), '-') AS Ilce,
    ISNULL(NULLIF(LTRIM(RTRIM(cu.CountryName)), ''), '-') AS Ulke,
    ISNULL(NULLIF(LTRIM(RTRIM(cu.Info)), ''), '-') AS MusteriInfo,

    CASE
        WHEN cu.IsShopping = 1 THEN N'Evet'
        WHEN cu.IsShopping = 0 THEN N'Hayır'
        ELSE '-'
    END AS AlisverisiVarMi,

    ISNULL(NULLIF(LTRIM(RTRIM(cu.Tel)), ''), '-') AS IrtibatNumarasi,
    ISNULL(NULLIF(LTRIM(RTRIM(cu.Email)), ''), '-') AS EmailAdresi,

    ISNULL(NULLIF(LTRIM(RTRIM(cr.ContactResourceName)), ''), '-') AS IletisimKaynagi,

    ISNULL(NULLIF(LTRIM(RTRIM(p.CategoryName)), ''), '-') AS CategoryName,
    '-' AS CategoryCode,

    ISNULL(NULLIF(LTRIM(RTRIM(ls.Name)), ''), '-') AS LeadDurumu,
    ISNULL(NULLIF(LTRIM(RTRIM(ns.Name)), ''), '-') AS SonrakiAdim,

    ISNULL(NULLIF(LTRIM(RTRIM(lp.Name)), ''), '-') AS ProcessName,
    ISNULL(NULLIF(LTRIM(RTRIM(lp.Code)), ''), '-') AS ProcessCode,
    lp.StepOrder,
    
    CAST(ISNULL(@StepOrder, lp.StepOrder) AS INT) AS SelectedStepOrder,

    ISNULL(
        CASE
            WHEN l.EstimatedDate IS NOT NULL
            THEN CAST(YEAR(l.EstimatedDate) AS VARCHAR(4)) + ' ' + DATENAME(MONTH, l.EstimatedDate)
            ELSE NULL
        END,
        '-'
    ) AS TerminTarihi,

    ISNULL(
        NULLIF(
            LTRIM(RTRIM(ISNULL(sp.FirstName, '') + ' ' + ISNULL(sp.LastName, '')))
        , '')
    , '-') AS SatisDanismani,

    ISNULL(NULLIF(LTRIM(RTRIM(st.StoreDesc)), ''), '-') AS StoreName

FROM tmscrq.TMLead l
LEFT JOIN tmscrq.TMLeadStatu ls ON ls.Id = l.StatuId
LEFT JOIN tmscrq.TMCustomer cu ON cu.Id = l.CustomerId
LEFT JOIN tmscrq.TMProduct p ON p.Id = l.ProductId
LEFT JOIN tmscrq.TMContactResource cr ON cr.Id = l.ContactResourceId
LEFT JOIN dbo.KUser sp ON sp.Id = l.SalesPersonKUserId
LEFT JOIN tmscrq.TMStore st ON st.Id = l.StoreId
LEFT JOIN tmscrq.TMLeadProcess lp ON lp.Id = l.ProcessID
LEFT JOIN tmscrq.TMLeadNextStep ns ON ns.Id = l.NextStepId

WHERE
-- Yetkilendirme
(
    -- Yönetici / Üst Yönetici: Tüm lead'ler
    EXISTS (
        SELECT 1
        FROM dbo.KUserRole ur
        INNER JOIN dbo.KRole r ON r.Id = ur.KRole_Id
        WHERE ur.KUser_Id = @UserId
          AND ur.IsDeleted = 0
          AND r.IsDeleted = 0
          AND r.Name IN ('TimesYonetici', 'TimesUstYonetici')
    )

    OR

    -- Mağaza Müdürü: Kendi mağazasındaki tüm lead'ler
    (
        EXISTS (
            SELECT 1
            FROM dbo.KUserRole ur
            INNER JOIN dbo.KRole r ON r.Id = ur.KRole_Id
            WHERE ur.KUser_Id = @UserId
              AND ur.IsDeleted = 0
              AND r.IsDeleted = 0
              AND r.Name = 'TimesMagazaMuduru'
        )
        AND l.StoreId =
        (
            SELECT TOP 1 tu.StoreID
            FROM tmscrq.TMUser tu
            WHERE tu.KUserID = @UserId
        )
    )

    OR

    -- Satış Personeli: Sadece kendi açtığı lead'ler
    (
        EXISTS (
            SELECT 1
            FROM dbo.KUserRole ur
            INNER JOIN dbo.KRole r ON r.Id = ur.KRole_Id
            WHERE ur.KUser_Id = @UserId
              AND ur.IsDeleted = 0
              AND r.IsDeleted = 0
              AND r.Name = 'TimesSatisPersoneli'
        )
        AND l.SalesPersonKUserId = @UserId
    )
)

-- Müşteri Adı
AND
(
    @MusteriAdi IS NULL
    OR LTRIM(RTRIM(@MusteriAdi)) = ''
    OR UPPER(LTRIM(RTRIM(ISNULL(cu.Name,'') + ' ' + ISNULL(cu.LastName,''))))
       LIKE '%' + UPPER(LTRIM(RTRIM(@MusteriAdi))) + '%'
)

-- Ürün Adı
AND
(
    @ProductName IS NULL
    OR LTRIM(RTRIM(@ProductName)) = ''
    OR
    (
        CHARINDEX(',', @ProductName) > 0
        AND ISNULL(LTRIM(RTRIM(p.ProductName)), '') IN
        (
            SELECT LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', '')))
            FROM STRING_SPLIT(CAST(@ProductName AS NVARCHAR(MAX)), ',')
            WHERE LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', ''))) <> ''
        )
    )
    OR
    (
        CHARINDEX(',', @ProductName) = 0
        AND UPPER(ISNULL(LTRIM(RTRIM(p.ProductName)), ''))
            LIKE '%' + UPPER(LTRIM(RTRIM(@ProductName))) + '%'
    )
)

-- Lead Kodu
AND
(
    @LeadCode IS NULL
    OR LTRIM(RTRIM(@LeadCode)) = ''
    OR UPPER(ISNULL(LTRIM(RTRIM(l.LeadCode)), '')) LIKE '%' + UPPER(LTRIM(RTRIM(@LeadCode))) + '%'
)

-- Telefon
AND
(
    @Tel IS NULL
    OR LTRIM(RTRIM(@Tel)) = ''
    OR UPPER(ISNULL(LTRIM(RTRIM(cu.Tel)), '')) LIKE '%' + UPPER(LTRIM(RTRIM(@Tel))) + '%'
)

-- Kategori
AND
(
    @CategoryName IS NULL
    OR LTRIM(RTRIM(@CategoryName)) = ''
    OR UPPER(ISNULL(LTRIM(RTRIM(p.CategoryName)), '')) IN
    (
        SELECT UPPER(LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value,'""',''),'[',''),']',''))))
        FROM STRING_SPLIT(CAST(@CategoryName AS NVARCHAR(MAX)), ',')
        WHERE LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value,'""',''),'[',''),']',''))) <> ''
    )
)

-- Mağaza
AND
(
    @StoreIds IS NULL
    OR LTRIM(RTRIM(@StoreIds)) = ''
    OR EXISTS
    (
        SELECT 1
        FROM STRING_SPLIT(CAST(@StoreIds AS NVARCHAR(MAX)), ',') s
        WHERE l.StoreId = TRY_CONVERT
        (
            uniqueidentifier,
            LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(s.value, '""', ''), '[', ''), ']', '')))
        )
    )
)

-- Satış Danışmanı
AND
(
    @SatisDanismaniIds IS NULL
    OR LTRIM(RTRIM(@SatisDanismaniIds)) = ''
    OR EXISTS
    (
        SELECT 1
        FROM STRING_SPLIT(CAST(@SatisDanismaniIds AS NVARCHAR(MAX)), ',') s
        WHERE l.SalesPersonKUserId = TRY_CONVERT
        (
            uniqueidentifier,
            LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(s.value, '""', ''), '[', ''), ']', '')))
        )
    )
)

-- Süreç Kodu
AND
(
    @ProcessCode IS NULL
    OR LTRIM(RTRIM(@ProcessCode)) = ''
    OR UPPER(ISNULL(LTRIM(RTRIM(lp.Code)), '')) IN
    (
        SELECT UPPER(LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', ''))))
        FROM STRING_SPLIT(CAST(@ProcessCode AS NVARCHAR(MAX)), ',')
        WHERE LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', ''))) <> ''
    )
)

-- StepOrder Filtresi (genişletilmiş, -4 eklendi)
AND
(
    @StepOrder IS NULL
    OR @StepOrder = 0   -- Tümü

    -- Aktif: CREATED, TERMIN_PENDING, PENDING, APPROVED, DELIVERY_PENDING
    OR (@StepOrder = -1 AND lp.Code IN ('CREATED','TERMIN_PENDING','PENDING','APPROVED','DELIVERY_PENDING'))

    -- Bugün oluşturulanlar
    OR (
        @StepOrder = -2 
        AND l.CreatedAt >= CAST(GETDATE() AS DATE) 
        AND l.CreatedAt < DATEADD(day, 1, CAST(GETDATE() AS DATE))
    )

    -- Geciken (Termin Tarihi Geçmiş): EstimatedDate bugünden küçük ve sonuçlanmamış
    OR (
        @StepOrder = -3 
        AND l.EstimatedDate < CAST(GETDATE() AS DATE) 
        AND lp.Code NOT IN ('DELIVERED','CLOSED','CUSTOMER_DECLINED','REJECTED')
    )

    -- Bu ayın terminleri
    OR (
        @StepOrder = -4 
        AND l.EstimatedDate >= DATEFROMPARTS(YEAR(GETDATE()), MONTH(GETDATE()), 1)
        AND l.EstimatedDate < DATEADD(MONTH, 1, DATEFROMPARTS(YEAR(GETDATE()), MONTH(GETDATE()), 1))
    )

    -- Rezerv onay bekleyen
    OR (
        @StepOrder = 10 
        AND EXISTS (
            SELECT 1 
            FROM tmscrq.TMLeadReservation r 
            WHERE r.LeadId = l.Id 
              AND r.IsActive = 1 
              AND ISNULL(r.IsApproved,0) = 0
        )
    )

    -- Diğer pozitif StepOrder değerleri
    OR (
        @StepOrder NOT IN (0, -1, -2, -3, -4, 10) 
        AND lp.StepOrder = @StepOrder
    )
)

-- Başlangıç Tarihi
AND
(
    @StartDate IS NULL
    OR LTRIM(RTRIM(@StartDate)) = ''
    OR l.CreatedAt >= CONVERT(date, @StartDate)
)

-- Bitiş Tarihi
AND
(
    @EndDate IS NULL
    OR LTRIM(RTRIM(@EndDate)) = ''
    OR l.CreatedAt < DATEADD(day, 1, CONVERT(date, @EndDate))
)

ORDER BY l.CreatedAt DESC;", new string[] { "RezerveDurumu", "LeadId", "IsReserved", "LeadNumarasi", "TalepTarihi", "ProductId", "ProductName", "Bilezik", "Brand", "Kadran", "RefCode", "Referans", "Musteri", "Lokasyon", "Ilce", "Ulke", "MusteriInfo", "AlisverisiVarMi", "IrtibatNumarasi", "EmailAdresi", "IletisimKaynagi", "CategoryName", "CategoryCode", "LeadDurumu", "SonrakiAdim", "ProcessName", "ProcessCode", "StepOrder", "SelectedStepOrder", "TerminTarihi", "SatisDanismani", "StoreName" }, prms_TM_TopManagerDashboardLeadList_0.ToArray());
            ;


            return Ok(result);
        }


        [HttpPost, Route("DashBoardTempComponent_908387_onClick")]
        public IActionResult DashBoardTempComponent_908387_onClick(DashBoardTempComponent_908387_onClick_Request request)
        {

            KProviderManager.Authorization.IsAuthorizedForRoles(appId, appName, screenId, screenName, new List<string> { $"b4bfd39c-ac02-f442-c899-7a2374a45b47", "70de6cfc-6087-6059-59b4-0b5a8527af6b", "TimesSatisPersoneli", "TimesMagazaMuduru" });

            var result = new DashBoardTempComponent_908387_onClick_Response();

            var prms_TM_TopManagerDashboardLeadList_0 = new List<kSqlParameter>();
            prms_TM_TopManagerDashboardLeadList_0.Add(new kSqlParameter() { Name = "UserId", Value = Kuika.Common.KContext.CurrentUser?.Id });
            prms_TM_TopManagerDashboardLeadList_0.Add(new kSqlParameter() { Name = "MusteriAdi", Value = request.MusteriAdi_0 });
            prms_TM_TopManagerDashboardLeadList_0.Add(new kSqlParameter() { Name = "ProductName", Value = request.ProductName_0 });
            prms_TM_TopManagerDashboardLeadList_0.Add(new kSqlParameter() { Name = "LeadCode", Value = (null as object) });
            prms_TM_TopManagerDashboardLeadList_0.Add(new kSqlParameter() { Name = "Tel", Value = (null as object) });
            prms_TM_TopManagerDashboardLeadList_0.Add(new kSqlParameter() { Name = "CategoryName", Value = request.CategoryName_0 });
            prms_TM_TopManagerDashboardLeadList_0.Add(new kSqlParameter() { Name = "StoreIds", Value = request.StoreIds_0 });
            prms_TM_TopManagerDashboardLeadList_0.Add(new kSqlParameter() { Name = "SatisDanismaniIds", Value = request.SatisDanismaniIds_0 });
            prms_TM_TopManagerDashboardLeadList_0.Add(new kSqlParameter() { Name = "ProcessCode", Value = request.ProcessCode_0 });
            prms_TM_TopManagerDashboardLeadList_0.Add(new kSqlParameter() { Name = "StepOrder", Value = "-4".ConvertToType<Int32>() });
            prms_TM_TopManagerDashboardLeadList_0.Add(new kSqlParameter() { Name = "StartDate", Value = request.StartDate_0 });
            prms_TM_TopManagerDashboardLeadList_0.Add(new kSqlParameter() { Name = "EndDate", Value = request.EndDate_0 });
            using var auditTM_TopManagerDashboardLeadList_0 = ActionAuditScope.Begin("d45daf67-bf4e-3694-36ed-672c9e5047f5", "TM_TopManagerDashboardLeadList", applicationName: "wbTimesCRM", screenOrEndpointName: "DashBoardTemp");
            result.TM_TopManagerDashboardLeadList = KPersister.Fetch(KContext.GetConnectionString(), @"SET LANGUAGE Turkish;


SELECT
    CASE 
        WHEN EXISTS (
            SELECT 1 
            FROM tmscrq.TMLeadReservation r
            WHERE r.LeadId = l.Id
              AND r.IsActive = 1
              AND r.IsApproved = 1
        ) THEN N'Evet'
        WHEN EXISTS (
            SELECT 1 
            FROM tmscrq.TMLeadReservation r
            WHERE r.LeadId = l.Id
              AND r.IsActive = 1
              AND ISNULL(r.IsApproved,0) = 0
        ) THEN N'Onay Bekliyor'
        ELSE N'Hayır'
    END AS RezerveDurumu,
    l.Id AS LeadId,
    l.IsReserved,
    ISNULL(NULLIF(LTRIM(RTRIM(l.LeadCode)), ''), '-') AS LeadNumarasi,
    CONVERT(varchar(10), l.CreatedAt, 103) AS TalepTarihi,

    p.Id AS ProductId,
    ISNULL(NULLIF(LTRIM(RTRIM(p.ProductName)), ''), '-') AS ProductName,
    ISNULL(NULLIF(LTRIM(RTRIM(p.Bracelet)), ''), '-') AS Bilezik,
    ISNULL(NULLIF(LTRIM(RTRIM(p.Brand)), ''), '-') AS Brand,
    ISNULL(NULLIF(LTRIM(RTRIM(p.Dial)), ''), '-') AS Kadran,
    ISNULL(NULLIF(LTRIM(RTRIM(p.ProductCode)), ''), '-') AS RefCode,
    ISNULL(NULLIF(LTRIM(RTRIM(p.Referance)), ''), '-') AS Referans,

    ISNULL(
        NULLIF(
            LTRIM(RTRIM(ISNULL(cu.Name, '') + ' ' + ISNULL(cu.LastName, '')))
        , '')
    , '-') AS Musteri,

    ISNULL(NULLIF(LTRIM(RTRIM(cu.CityName)), ''), '-') AS Lokasyon,
    ISNULL(NULLIF(LTRIM(RTRIM(cu.DistrictName)), ''), '-') AS Ilce,
    ISNULL(NULLIF(LTRIM(RTRIM(cu.CountryName)), ''), '-') AS Ulke,
    ISNULL(NULLIF(LTRIM(RTRIM(cu.Info)), ''), '-') AS MusteriInfo,

    CASE
        WHEN cu.IsShopping = 1 THEN N'Evet'
        WHEN cu.IsShopping = 0 THEN N'Hayır'
        ELSE '-'
    END AS AlisverisiVarMi,

    ISNULL(NULLIF(LTRIM(RTRIM(cu.Tel)), ''), '-') AS IrtibatNumarasi,
    ISNULL(NULLIF(LTRIM(RTRIM(cu.Email)), ''), '-') AS EmailAdresi,

    ISNULL(NULLIF(LTRIM(RTRIM(cr.ContactResourceName)), ''), '-') AS IletisimKaynagi,

    ISNULL(NULLIF(LTRIM(RTRIM(p.CategoryName)), ''), '-') AS CategoryName,
    '-' AS CategoryCode,

    ISNULL(NULLIF(LTRIM(RTRIM(ls.Name)), ''), '-') AS LeadDurumu,
    ISNULL(NULLIF(LTRIM(RTRIM(ns.Name)), ''), '-') AS SonrakiAdim,

    ISNULL(NULLIF(LTRIM(RTRIM(lp.Name)), ''), '-') AS ProcessName,
    ISNULL(NULLIF(LTRIM(RTRIM(lp.Code)), ''), '-') AS ProcessCode,
    lp.StepOrder,
    
    CAST(ISNULL(@StepOrder, lp.StepOrder) AS INT) AS SelectedStepOrder,

    ISNULL(
        CASE
            WHEN l.EstimatedDate IS NOT NULL
            THEN CAST(YEAR(l.EstimatedDate) AS VARCHAR(4)) + ' ' + DATENAME(MONTH, l.EstimatedDate)
            ELSE NULL
        END,
        '-'
    ) AS TerminTarihi,

    ISNULL(
        NULLIF(
            LTRIM(RTRIM(ISNULL(sp.FirstName, '') + ' ' + ISNULL(sp.LastName, '')))
        , '')
    , '-') AS SatisDanismani,

    ISNULL(NULLIF(LTRIM(RTRIM(st.StoreDesc)), ''), '-') AS StoreName

FROM tmscrq.TMLead l
LEFT JOIN tmscrq.TMLeadStatu ls ON ls.Id = l.StatuId
LEFT JOIN tmscrq.TMCustomer cu ON cu.Id = l.CustomerId
LEFT JOIN tmscrq.TMProduct p ON p.Id = l.ProductId
LEFT JOIN tmscrq.TMContactResource cr ON cr.Id = l.ContactResourceId
LEFT JOIN dbo.KUser sp ON sp.Id = l.SalesPersonKUserId
LEFT JOIN tmscrq.TMStore st ON st.Id = l.StoreId
LEFT JOIN tmscrq.TMLeadProcess lp ON lp.Id = l.ProcessID
LEFT JOIN tmscrq.TMLeadNextStep ns ON ns.Id = l.NextStepId

WHERE
-- Yetkilendirme
(
    -- Yönetici / Üst Yönetici: Tüm lead'ler
    EXISTS (
        SELECT 1
        FROM dbo.KUserRole ur
        INNER JOIN dbo.KRole r ON r.Id = ur.KRole_Id
        WHERE ur.KUser_Id = @UserId
          AND ur.IsDeleted = 0
          AND r.IsDeleted = 0
          AND r.Name IN ('TimesYonetici', 'TimesUstYonetici')
    )

    OR

    -- Mağaza Müdürü: Kendi mağazasındaki tüm lead'ler
    (
        EXISTS (
            SELECT 1
            FROM dbo.KUserRole ur
            INNER JOIN dbo.KRole r ON r.Id = ur.KRole_Id
            WHERE ur.KUser_Id = @UserId
              AND ur.IsDeleted = 0
              AND r.IsDeleted = 0
              AND r.Name = 'TimesMagazaMuduru'
        )
        AND l.StoreId =
        (
            SELECT TOP 1 tu.StoreID
            FROM tmscrq.TMUser tu
            WHERE tu.KUserID = @UserId
        )
    )

    OR

    -- Satış Personeli: Sadece kendi açtığı lead'ler
    (
        EXISTS (
            SELECT 1
            FROM dbo.KUserRole ur
            INNER JOIN dbo.KRole r ON r.Id = ur.KRole_Id
            WHERE ur.KUser_Id = @UserId
              AND ur.IsDeleted = 0
              AND r.IsDeleted = 0
              AND r.Name = 'TimesSatisPersoneli'
        )
        AND l.SalesPersonKUserId = @UserId
    )
)

-- Müşteri Adı
AND
(
    @MusteriAdi IS NULL
    OR LTRIM(RTRIM(@MusteriAdi)) = ''
    OR UPPER(LTRIM(RTRIM(ISNULL(cu.Name,'') + ' ' + ISNULL(cu.LastName,''))))
       LIKE '%' + UPPER(LTRIM(RTRIM(@MusteriAdi))) + '%'
)

-- Ürün Adı
AND
(
    @ProductName IS NULL
    OR LTRIM(RTRIM(@ProductName)) = ''
    OR
    (
        CHARINDEX(',', @ProductName) > 0
        AND ISNULL(LTRIM(RTRIM(p.ProductName)), '') IN
        (
            SELECT LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', '')))
            FROM STRING_SPLIT(CAST(@ProductName AS NVARCHAR(MAX)), ',')
            WHERE LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', ''))) <> ''
        )
    )
    OR
    (
        CHARINDEX(',', @ProductName) = 0
        AND UPPER(ISNULL(LTRIM(RTRIM(p.ProductName)), ''))
            LIKE '%' + UPPER(LTRIM(RTRIM(@ProductName))) + '%'
    )
)

-- Lead Kodu
AND
(
    @LeadCode IS NULL
    OR LTRIM(RTRIM(@LeadCode)) = ''
    OR UPPER(ISNULL(LTRIM(RTRIM(l.LeadCode)), '')) LIKE '%' + UPPER(LTRIM(RTRIM(@LeadCode))) + '%'
)

-- Telefon
AND
(
    @Tel IS NULL
    OR LTRIM(RTRIM(@Tel)) = ''
    OR UPPER(ISNULL(LTRIM(RTRIM(cu.Tel)), '')) LIKE '%' + UPPER(LTRIM(RTRIM(@Tel))) + '%'
)

-- Kategori
AND
(
    @CategoryName IS NULL
    OR LTRIM(RTRIM(@CategoryName)) = ''
    OR UPPER(ISNULL(LTRIM(RTRIM(p.CategoryName)), '')) IN
    (
        SELECT UPPER(LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value,'""',''),'[',''),']',''))))
        FROM STRING_SPLIT(CAST(@CategoryName AS NVARCHAR(MAX)), ',')
        WHERE LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value,'""',''),'[',''),']',''))) <> ''
    )
)

-- Mağaza
AND
(
    @StoreIds IS NULL
    OR LTRIM(RTRIM(@StoreIds)) = ''
    OR EXISTS
    (
        SELECT 1
        FROM STRING_SPLIT(CAST(@StoreIds AS NVARCHAR(MAX)), ',') s
        WHERE l.StoreId = TRY_CONVERT
        (
            uniqueidentifier,
            LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(s.value, '""', ''), '[', ''), ']', '')))
        )
    )
)

-- Satış Danışmanı
AND
(
    @SatisDanismaniIds IS NULL
    OR LTRIM(RTRIM(@SatisDanismaniIds)) = ''
    OR EXISTS
    (
        SELECT 1
        FROM STRING_SPLIT(CAST(@SatisDanismaniIds AS NVARCHAR(MAX)), ',') s
        WHERE l.SalesPersonKUserId = TRY_CONVERT
        (
            uniqueidentifier,
            LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(s.value, '""', ''), '[', ''), ']', '')))
        )
    )
)

-- Süreç Kodu
AND
(
    @ProcessCode IS NULL
    OR LTRIM(RTRIM(@ProcessCode)) = ''
    OR UPPER(ISNULL(LTRIM(RTRIM(lp.Code)), '')) IN
    (
        SELECT UPPER(LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', ''))))
        FROM STRING_SPLIT(CAST(@ProcessCode AS NVARCHAR(MAX)), ',')
        WHERE LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', ''))) <> ''
    )
)

-- StepOrder Filtresi (genişletilmiş, -4 eklendi)
AND
(
    @StepOrder IS NULL
    OR @StepOrder = 0   -- Tümü

    -- Aktif: CREATED, TERMIN_PENDING, PENDING, APPROVED, DELIVERY_PENDING
    OR (@StepOrder = -1 AND lp.Code IN ('CREATED','TERMIN_PENDING','PENDING','APPROVED','DELIVERY_PENDING'))

    -- Bugün oluşturulanlar
    OR (
        @StepOrder = -2 
        AND l.CreatedAt >= CAST(GETDATE() AS DATE) 
        AND l.CreatedAt < DATEADD(day, 1, CAST(GETDATE() AS DATE))
    )

    -- Geciken (Termin Tarihi Geçmiş): EstimatedDate bugünden küçük ve sonuçlanmamış
    OR (
        @StepOrder = -3 
        AND l.EstimatedDate < CAST(GETDATE() AS DATE) 
        AND lp.Code NOT IN ('DELIVERED','CLOSED','CUSTOMER_DECLINED','REJECTED')
    )

    -- Bu ayın terminleri
    OR (
        @StepOrder = -4 
        AND l.EstimatedDate >= DATEFROMPARTS(YEAR(GETDATE()), MONTH(GETDATE()), 1)
        AND l.EstimatedDate < DATEADD(MONTH, 1, DATEFROMPARTS(YEAR(GETDATE()), MONTH(GETDATE()), 1))
    )

    -- Rezerv onay bekleyen
    OR (
        @StepOrder = 10 
        AND EXISTS (
            SELECT 1 
            FROM tmscrq.TMLeadReservation r 
            WHERE r.LeadId = l.Id 
              AND r.IsActive = 1 
              AND ISNULL(r.IsApproved,0) = 0
        )
    )

    -- Diğer pozitif StepOrder değerleri
    OR (
        @StepOrder NOT IN (0, -1, -2, -3, -4, 10) 
        AND lp.StepOrder = @StepOrder
    )
)

-- Başlangıç Tarihi
AND
(
    @StartDate IS NULL
    OR LTRIM(RTRIM(@StartDate)) = ''
    OR l.CreatedAt >= CONVERT(date, @StartDate)
)

-- Bitiş Tarihi
AND
(
    @EndDate IS NULL
    OR LTRIM(RTRIM(@EndDate)) = ''
    OR l.CreatedAt < DATEADD(day, 1, CONVERT(date, @EndDate))
)

ORDER BY l.CreatedAt DESC;", new string[] { "RezerveDurumu", "LeadId", "IsReserved", "LeadNumarasi", "TalepTarihi", "ProductId", "ProductName", "Bilezik", "Brand", "Kadran", "RefCode", "Referans", "Musteri", "Lokasyon", "Ilce", "Ulke", "MusteriInfo", "AlisverisiVarMi", "IrtibatNumarasi", "EmailAdresi", "IletisimKaynagi", "CategoryName", "CategoryCode", "LeadDurumu", "SonrakiAdim", "ProcessName", "ProcessCode", "StepOrder", "SelectedStepOrder", "TerminTarihi", "SatisDanismani", "StoreName" }, prms_TM_TopManagerDashboardLeadList_0.ToArray());
            ;


            return Ok(result);
        }


        [HttpPost, Route("DashBoardTempComponent_398231_onClick")]
        public IActionResult DashBoardTempComponent_398231_onClick(DashBoardTempComponent_398231_onClick_Request request)
        {

            KProviderManager.Authorization.IsAuthorizedForRoles(appId, appName, screenId, screenName, new List<string> { $"b4bfd39c-ac02-f442-c899-7a2374a45b47", "70de6cfc-6087-6059-59b4-0b5a8527af6b", "TimesSatisPersoneli", "TimesMagazaMuduru" });

            var result = new DashBoardTempComponent_398231_onClick_Response();

            var prms_TM_TopManagerDashboardLeadList_0 = new List<kSqlParameter>();
            prms_TM_TopManagerDashboardLeadList_0.Add(new kSqlParameter() { Name = "UserId", Value = Kuika.Common.KContext.CurrentUser?.Id });
            prms_TM_TopManagerDashboardLeadList_0.Add(new kSqlParameter() { Name = "MusteriAdi", Value = request.MusteriAdi_0 });
            prms_TM_TopManagerDashboardLeadList_0.Add(new kSqlParameter() { Name = "ProductName", Value = request.ProductName_0 });
            prms_TM_TopManagerDashboardLeadList_0.Add(new kSqlParameter() { Name = "LeadCode", Value = (null as object) });
            prms_TM_TopManagerDashboardLeadList_0.Add(new kSqlParameter() { Name = "Tel", Value = (null as object) });
            prms_TM_TopManagerDashboardLeadList_0.Add(new kSqlParameter() { Name = "CategoryName", Value = request.CategoryName_0 });
            prms_TM_TopManagerDashboardLeadList_0.Add(new kSqlParameter() { Name = "StoreIds", Value = request.StoreIds_0 });
            prms_TM_TopManagerDashboardLeadList_0.Add(new kSqlParameter() { Name = "SatisDanismaniIds", Value = request.SatisDanismaniIds_0 });
            prms_TM_TopManagerDashboardLeadList_0.Add(new kSqlParameter() { Name = "ProcessCode", Value = request.ProcessCode_0 });
            prms_TM_TopManagerDashboardLeadList_0.Add(new kSqlParameter() { Name = "StepOrder", Value = "-3".ConvertToType<Int32>() });
            prms_TM_TopManagerDashboardLeadList_0.Add(new kSqlParameter() { Name = "StartDate", Value = request.StartDate_0 });
            prms_TM_TopManagerDashboardLeadList_0.Add(new kSqlParameter() { Name = "EndDate", Value = request.EndDate_0 });
            using var auditTM_TopManagerDashboardLeadList_0 = ActionAuditScope.Begin("eb520cc8-47c4-edc2-e5f6-cb1715c3e935", "TM_TopManagerDashboardLeadList", applicationName: "wbTimesCRM", screenOrEndpointName: "DashBoardTemp");
            result.TM_TopManagerDashboardLeadList = KPersister.Fetch(KContext.GetConnectionString(), @"SET LANGUAGE Turkish;


SELECT
    CASE 
        WHEN EXISTS (
            SELECT 1 
            FROM tmscrq.TMLeadReservation r
            WHERE r.LeadId = l.Id
              AND r.IsActive = 1
              AND r.IsApproved = 1
        ) THEN N'Evet'
        WHEN EXISTS (
            SELECT 1 
            FROM tmscrq.TMLeadReservation r
            WHERE r.LeadId = l.Id
              AND r.IsActive = 1
              AND ISNULL(r.IsApproved,0) = 0
        ) THEN N'Onay Bekliyor'
        ELSE N'Hayır'
    END AS RezerveDurumu,
    l.Id AS LeadId,
    l.IsReserved,
    ISNULL(NULLIF(LTRIM(RTRIM(l.LeadCode)), ''), '-') AS LeadNumarasi,
    CONVERT(varchar(10), l.CreatedAt, 103) AS TalepTarihi,

    p.Id AS ProductId,
    ISNULL(NULLIF(LTRIM(RTRIM(p.ProductName)), ''), '-') AS ProductName,
    ISNULL(NULLIF(LTRIM(RTRIM(p.Bracelet)), ''), '-') AS Bilezik,
    ISNULL(NULLIF(LTRIM(RTRIM(p.Brand)), ''), '-') AS Brand,
    ISNULL(NULLIF(LTRIM(RTRIM(p.Dial)), ''), '-') AS Kadran,
    ISNULL(NULLIF(LTRIM(RTRIM(p.ProductCode)), ''), '-') AS RefCode,
    ISNULL(NULLIF(LTRIM(RTRIM(p.Referance)), ''), '-') AS Referans,

    ISNULL(
        NULLIF(
            LTRIM(RTRIM(ISNULL(cu.Name, '') + ' ' + ISNULL(cu.LastName, '')))
        , '')
    , '-') AS Musteri,

    ISNULL(NULLIF(LTRIM(RTRIM(cu.CityName)), ''), '-') AS Lokasyon,
    ISNULL(NULLIF(LTRIM(RTRIM(cu.DistrictName)), ''), '-') AS Ilce,
    ISNULL(NULLIF(LTRIM(RTRIM(cu.CountryName)), ''), '-') AS Ulke,
    ISNULL(NULLIF(LTRIM(RTRIM(cu.Info)), ''), '-') AS MusteriInfo,

    CASE
        WHEN cu.IsShopping = 1 THEN N'Evet'
        WHEN cu.IsShopping = 0 THEN N'Hayır'
        ELSE '-'
    END AS AlisverisiVarMi,

    ISNULL(NULLIF(LTRIM(RTRIM(cu.Tel)), ''), '-') AS IrtibatNumarasi,
    ISNULL(NULLIF(LTRIM(RTRIM(cu.Email)), ''), '-') AS EmailAdresi,

    ISNULL(NULLIF(LTRIM(RTRIM(cr.ContactResourceName)), ''), '-') AS IletisimKaynagi,

    ISNULL(NULLIF(LTRIM(RTRIM(p.CategoryName)), ''), '-') AS CategoryName,
    '-' AS CategoryCode,

    ISNULL(NULLIF(LTRIM(RTRIM(ls.Name)), ''), '-') AS LeadDurumu,
    ISNULL(NULLIF(LTRIM(RTRIM(ns.Name)), ''), '-') AS SonrakiAdim,

    ISNULL(NULLIF(LTRIM(RTRIM(lp.Name)), ''), '-') AS ProcessName,
    ISNULL(NULLIF(LTRIM(RTRIM(lp.Code)), ''), '-') AS ProcessCode,
    lp.StepOrder,
    
    CAST(ISNULL(@StepOrder, lp.StepOrder) AS INT) AS SelectedStepOrder,

    ISNULL(
        CASE
            WHEN l.EstimatedDate IS NOT NULL
            THEN CAST(YEAR(l.EstimatedDate) AS VARCHAR(4)) + ' ' + DATENAME(MONTH, l.EstimatedDate)
            ELSE NULL
        END,
        '-'
    ) AS TerminTarihi,

    ISNULL(
        NULLIF(
            LTRIM(RTRIM(ISNULL(sp.FirstName, '') + ' ' + ISNULL(sp.LastName, '')))
        , '')
    , '-') AS SatisDanismani,

    ISNULL(NULLIF(LTRIM(RTRIM(st.StoreDesc)), ''), '-') AS StoreName

FROM tmscrq.TMLead l
LEFT JOIN tmscrq.TMLeadStatu ls ON ls.Id = l.StatuId
LEFT JOIN tmscrq.TMCustomer cu ON cu.Id = l.CustomerId
LEFT JOIN tmscrq.TMProduct p ON p.Id = l.ProductId
LEFT JOIN tmscrq.TMContactResource cr ON cr.Id = l.ContactResourceId
LEFT JOIN dbo.KUser sp ON sp.Id = l.SalesPersonKUserId
LEFT JOIN tmscrq.TMStore st ON st.Id = l.StoreId
LEFT JOIN tmscrq.TMLeadProcess lp ON lp.Id = l.ProcessID
LEFT JOIN tmscrq.TMLeadNextStep ns ON ns.Id = l.NextStepId

WHERE
-- Yetkilendirme
(
    -- Yönetici / Üst Yönetici: Tüm lead'ler
    EXISTS (
        SELECT 1
        FROM dbo.KUserRole ur
        INNER JOIN dbo.KRole r ON r.Id = ur.KRole_Id
        WHERE ur.KUser_Id = @UserId
          AND ur.IsDeleted = 0
          AND r.IsDeleted = 0
          AND r.Name IN ('TimesYonetici', 'TimesUstYonetici')
    )

    OR

    -- Mağaza Müdürü: Kendi mağazasındaki tüm lead'ler
    (
        EXISTS (
            SELECT 1
            FROM dbo.KUserRole ur
            INNER JOIN dbo.KRole r ON r.Id = ur.KRole_Id
            WHERE ur.KUser_Id = @UserId
              AND ur.IsDeleted = 0
              AND r.IsDeleted = 0
              AND r.Name = 'TimesMagazaMuduru'
        )
        AND l.StoreId =
        (
            SELECT TOP 1 tu.StoreID
            FROM tmscrq.TMUser tu
            WHERE tu.KUserID = @UserId
        )
    )

    OR

    -- Satış Personeli: Sadece kendi açtığı lead'ler
    (
        EXISTS (
            SELECT 1
            FROM dbo.KUserRole ur
            INNER JOIN dbo.KRole r ON r.Id = ur.KRole_Id
            WHERE ur.KUser_Id = @UserId
              AND ur.IsDeleted = 0
              AND r.IsDeleted = 0
              AND r.Name = 'TimesSatisPersoneli'
        )
        AND l.SalesPersonKUserId = @UserId
    )
)

-- Müşteri Adı
AND
(
    @MusteriAdi IS NULL
    OR LTRIM(RTRIM(@MusteriAdi)) = ''
    OR UPPER(LTRIM(RTRIM(ISNULL(cu.Name,'') + ' ' + ISNULL(cu.LastName,''))))
       LIKE '%' + UPPER(LTRIM(RTRIM(@MusteriAdi))) + '%'
)

-- Ürün Adı
AND
(
    @ProductName IS NULL
    OR LTRIM(RTRIM(@ProductName)) = ''
    OR
    (
        CHARINDEX(',', @ProductName) > 0
        AND ISNULL(LTRIM(RTRIM(p.ProductName)), '') IN
        (
            SELECT LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', '')))
            FROM STRING_SPLIT(CAST(@ProductName AS NVARCHAR(MAX)), ',')
            WHERE LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', ''))) <> ''
        )
    )
    OR
    (
        CHARINDEX(',', @ProductName) = 0
        AND UPPER(ISNULL(LTRIM(RTRIM(p.ProductName)), ''))
            LIKE '%' + UPPER(LTRIM(RTRIM(@ProductName))) + '%'
    )
)

-- Lead Kodu
AND
(
    @LeadCode IS NULL
    OR LTRIM(RTRIM(@LeadCode)) = ''
    OR UPPER(ISNULL(LTRIM(RTRIM(l.LeadCode)), '')) LIKE '%' + UPPER(LTRIM(RTRIM(@LeadCode))) + '%'
)

-- Telefon
AND
(
    @Tel IS NULL
    OR LTRIM(RTRIM(@Tel)) = ''
    OR UPPER(ISNULL(LTRIM(RTRIM(cu.Tel)), '')) LIKE '%' + UPPER(LTRIM(RTRIM(@Tel))) + '%'
)

-- Kategori
AND
(
    @CategoryName IS NULL
    OR LTRIM(RTRIM(@CategoryName)) = ''
    OR UPPER(ISNULL(LTRIM(RTRIM(p.CategoryName)), '')) IN
    (
        SELECT UPPER(LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value,'""',''),'[',''),']',''))))
        FROM STRING_SPLIT(CAST(@CategoryName AS NVARCHAR(MAX)), ',')
        WHERE LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value,'""',''),'[',''),']',''))) <> ''
    )
)

-- Mağaza
AND
(
    @StoreIds IS NULL
    OR LTRIM(RTRIM(@StoreIds)) = ''
    OR EXISTS
    (
        SELECT 1
        FROM STRING_SPLIT(CAST(@StoreIds AS NVARCHAR(MAX)), ',') s
        WHERE l.StoreId = TRY_CONVERT
        (
            uniqueidentifier,
            LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(s.value, '""', ''), '[', ''), ']', '')))
        )
    )
)

-- Satış Danışmanı
AND
(
    @SatisDanismaniIds IS NULL
    OR LTRIM(RTRIM(@SatisDanismaniIds)) = ''
    OR EXISTS
    (
        SELECT 1
        FROM STRING_SPLIT(CAST(@SatisDanismaniIds AS NVARCHAR(MAX)), ',') s
        WHERE l.SalesPersonKUserId = TRY_CONVERT
        (
            uniqueidentifier,
            LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(s.value, '""', ''), '[', ''), ']', '')))
        )
    )
)

-- Süreç Kodu
AND
(
    @ProcessCode IS NULL
    OR LTRIM(RTRIM(@ProcessCode)) = ''
    OR UPPER(ISNULL(LTRIM(RTRIM(lp.Code)), '')) IN
    (
        SELECT UPPER(LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', ''))))
        FROM STRING_SPLIT(CAST(@ProcessCode AS NVARCHAR(MAX)), ',')
        WHERE LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', ''))) <> ''
    )
)

-- StepOrder Filtresi (genişletilmiş, -4 eklendi)
AND
(
    @StepOrder IS NULL
    OR @StepOrder = 0   -- Tümü

    -- Aktif: CREATED, TERMIN_PENDING, PENDING, APPROVED, DELIVERY_PENDING
    OR (@StepOrder = -1 AND lp.Code IN ('CREATED','TERMIN_PENDING','PENDING','APPROVED','DELIVERY_PENDING'))

    -- Bugün oluşturulanlar
    OR (
        @StepOrder = -2 
        AND l.CreatedAt >= CAST(GETDATE() AS DATE) 
        AND l.CreatedAt < DATEADD(day, 1, CAST(GETDATE() AS DATE))
    )

    -- Geciken (Termin Tarihi Geçmiş): EstimatedDate bugünden küçük ve sonuçlanmamış
    OR (
        @StepOrder = -3 
        AND l.EstimatedDate < CAST(GETDATE() AS DATE) 
        AND lp.Code NOT IN ('DELIVERED','CLOSED','CUSTOMER_DECLINED','REJECTED')
    )

    -- Bu ayın terminleri
    OR (
        @StepOrder = -4 
        AND l.EstimatedDate >= DATEFROMPARTS(YEAR(GETDATE()), MONTH(GETDATE()), 1)
        AND l.EstimatedDate < DATEADD(MONTH, 1, DATEFROMPARTS(YEAR(GETDATE()), MONTH(GETDATE()), 1))
    )

    -- Rezerv onay bekleyen
    OR (
        @StepOrder = 10 
        AND EXISTS (
            SELECT 1 
            FROM tmscrq.TMLeadReservation r 
            WHERE r.LeadId = l.Id 
              AND r.IsActive = 1 
              AND ISNULL(r.IsApproved,0) = 0
        )
    )

    -- Diğer pozitif StepOrder değerleri
    OR (
        @StepOrder NOT IN (0, -1, -2, -3, -4, 10) 
        AND lp.StepOrder = @StepOrder
    )
)

-- Başlangıç Tarihi
AND
(
    @StartDate IS NULL
    OR LTRIM(RTRIM(@StartDate)) = ''
    OR l.CreatedAt >= CONVERT(date, @StartDate)
)

-- Bitiş Tarihi
AND
(
    @EndDate IS NULL
    OR LTRIM(RTRIM(@EndDate)) = ''
    OR l.CreatedAt < DATEADD(day, 1, CONVERT(date, @EndDate))
)

ORDER BY l.CreatedAt DESC;", new string[] { "RezerveDurumu", "LeadId", "IsReserved", "LeadNumarasi", "TalepTarihi", "ProductId", "ProductName", "Bilezik", "Brand", "Kadran", "RefCode", "Referans", "Musteri", "Lokasyon", "Ilce", "Ulke", "MusteriInfo", "AlisverisiVarMi", "IrtibatNumarasi", "EmailAdresi", "IletisimKaynagi", "CategoryName", "CategoryCode", "LeadDurumu", "SonrakiAdim", "ProcessName", "ProcessCode", "StepOrder", "SelectedStepOrder", "TerminTarihi", "SatisDanismani", "StoreName" }, prms_TM_TopManagerDashboardLeadList_0.ToArray());
            ;


            return Ok(result);
        }


        [HttpPost, Route("DashBoardTempComponent_892106_onClick")]
        public IActionResult DashBoardTempComponent_892106_onClick(DashBoardTempComponent_892106_onClick_Request request)
        {

            KProviderManager.Authorization.IsAuthorizedForRoles(appId, appName, screenId, screenName, new List<string> { $"b4bfd39c-ac02-f442-c899-7a2374a45b47", "70de6cfc-6087-6059-59b4-0b5a8527af6b", "TimesSatisPersoneli", "TimesMagazaMuduru" });

            var result = new DashBoardTempComponent_892106_onClick_Response();

            var prms_TM_TopManagerDashboardLeadList_0 = new List<kSqlParameter>();
            prms_TM_TopManagerDashboardLeadList_0.Add(new kSqlParameter() { Name = "UserId", Value = Kuika.Common.KContext.CurrentUser?.Id });
            prms_TM_TopManagerDashboardLeadList_0.Add(new kSqlParameter() { Name = "MusteriAdi", Value = request.MusteriAdi_0 });
            prms_TM_TopManagerDashboardLeadList_0.Add(new kSqlParameter() { Name = "ProductName", Value = request.ProductName_0 });
            prms_TM_TopManagerDashboardLeadList_0.Add(new kSqlParameter() { Name = "LeadCode", Value = (null as object) });
            prms_TM_TopManagerDashboardLeadList_0.Add(new kSqlParameter() { Name = "Tel", Value = (null as object) });
            prms_TM_TopManagerDashboardLeadList_0.Add(new kSqlParameter() { Name = "CategoryName", Value = request.CategoryName_0 });
            prms_TM_TopManagerDashboardLeadList_0.Add(new kSqlParameter() { Name = "StoreIds", Value = request.StoreIds_0 });
            prms_TM_TopManagerDashboardLeadList_0.Add(new kSqlParameter() { Name = "SatisDanismaniIds", Value = request.SatisDanismaniIds_0 });
            prms_TM_TopManagerDashboardLeadList_0.Add(new kSqlParameter() { Name = "ProcessCode", Value = request.ProcessCode_0 });
            prms_TM_TopManagerDashboardLeadList_0.Add(new kSqlParameter() { Name = "StepOrder", Value = "3".ConvertToType<Int32>() });
            prms_TM_TopManagerDashboardLeadList_0.Add(new kSqlParameter() { Name = "StartDate", Value = request.StartDate_0 });
            prms_TM_TopManagerDashboardLeadList_0.Add(new kSqlParameter() { Name = "EndDate", Value = request.EndDate_0 });
            using var auditTM_TopManagerDashboardLeadList_0 = ActionAuditScope.Begin("72bed355-33e4-55b2-26e7-d9800057f860", "TM_TopManagerDashboardLeadList", applicationName: "wbTimesCRM", screenOrEndpointName: "DashBoardTemp");
            result.TM_TopManagerDashboardLeadList = KPersister.Fetch(KContext.GetConnectionString(), @"SET LANGUAGE Turkish;


SELECT
    CASE 
        WHEN EXISTS (
            SELECT 1 
            FROM tmscrq.TMLeadReservation r
            WHERE r.LeadId = l.Id
              AND r.IsActive = 1
              AND r.IsApproved = 1
        ) THEN N'Evet'
        WHEN EXISTS (
            SELECT 1 
            FROM tmscrq.TMLeadReservation r
            WHERE r.LeadId = l.Id
              AND r.IsActive = 1
              AND ISNULL(r.IsApproved,0) = 0
        ) THEN N'Onay Bekliyor'
        ELSE N'Hayır'
    END AS RezerveDurumu,
    l.Id AS LeadId,
    l.IsReserved,
    ISNULL(NULLIF(LTRIM(RTRIM(l.LeadCode)), ''), '-') AS LeadNumarasi,
    CONVERT(varchar(10), l.CreatedAt, 103) AS TalepTarihi,

    p.Id AS ProductId,
    ISNULL(NULLIF(LTRIM(RTRIM(p.ProductName)), ''), '-') AS ProductName,
    ISNULL(NULLIF(LTRIM(RTRIM(p.Bracelet)), ''), '-') AS Bilezik,
    ISNULL(NULLIF(LTRIM(RTRIM(p.Brand)), ''), '-') AS Brand,
    ISNULL(NULLIF(LTRIM(RTRIM(p.Dial)), ''), '-') AS Kadran,
    ISNULL(NULLIF(LTRIM(RTRIM(p.ProductCode)), ''), '-') AS RefCode,
    ISNULL(NULLIF(LTRIM(RTRIM(p.Referance)), ''), '-') AS Referans,

    ISNULL(
        NULLIF(
            LTRIM(RTRIM(ISNULL(cu.Name, '') + ' ' + ISNULL(cu.LastName, '')))
        , '')
    , '-') AS Musteri,

    ISNULL(NULLIF(LTRIM(RTRIM(cu.CityName)), ''), '-') AS Lokasyon,
    ISNULL(NULLIF(LTRIM(RTRIM(cu.DistrictName)), ''), '-') AS Ilce,
    ISNULL(NULLIF(LTRIM(RTRIM(cu.CountryName)), ''), '-') AS Ulke,
    ISNULL(NULLIF(LTRIM(RTRIM(cu.Info)), ''), '-') AS MusteriInfo,

    CASE
        WHEN cu.IsShopping = 1 THEN N'Evet'
        WHEN cu.IsShopping = 0 THEN N'Hayır'
        ELSE '-'
    END AS AlisverisiVarMi,

    ISNULL(NULLIF(LTRIM(RTRIM(cu.Tel)), ''), '-') AS IrtibatNumarasi,
    ISNULL(NULLIF(LTRIM(RTRIM(cu.Email)), ''), '-') AS EmailAdresi,

    ISNULL(NULLIF(LTRIM(RTRIM(cr.ContactResourceName)), ''), '-') AS IletisimKaynagi,

    ISNULL(NULLIF(LTRIM(RTRIM(p.CategoryName)), ''), '-') AS CategoryName,
    '-' AS CategoryCode,

    ISNULL(NULLIF(LTRIM(RTRIM(ls.Name)), ''), '-') AS LeadDurumu,
    ISNULL(NULLIF(LTRIM(RTRIM(ns.Name)), ''), '-') AS SonrakiAdim,

    ISNULL(NULLIF(LTRIM(RTRIM(lp.Name)), ''), '-') AS ProcessName,
    ISNULL(NULLIF(LTRIM(RTRIM(lp.Code)), ''), '-') AS ProcessCode,
    lp.StepOrder,
    
    CAST(ISNULL(@StepOrder, lp.StepOrder) AS INT) AS SelectedStepOrder,

    ISNULL(
        CASE
            WHEN l.EstimatedDate IS NOT NULL
            THEN CAST(YEAR(l.EstimatedDate) AS VARCHAR(4)) + ' ' + DATENAME(MONTH, l.EstimatedDate)
            ELSE NULL
        END,
        '-'
    ) AS TerminTarihi,

    ISNULL(
        NULLIF(
            LTRIM(RTRIM(ISNULL(sp.FirstName, '') + ' ' + ISNULL(sp.LastName, '')))
        , '')
    , '-') AS SatisDanismani,

    ISNULL(NULLIF(LTRIM(RTRIM(st.StoreDesc)), ''), '-') AS StoreName

FROM tmscrq.TMLead l
LEFT JOIN tmscrq.TMLeadStatu ls ON ls.Id = l.StatuId
LEFT JOIN tmscrq.TMCustomer cu ON cu.Id = l.CustomerId
LEFT JOIN tmscrq.TMProduct p ON p.Id = l.ProductId
LEFT JOIN tmscrq.TMContactResource cr ON cr.Id = l.ContactResourceId
LEFT JOIN dbo.KUser sp ON sp.Id = l.SalesPersonKUserId
LEFT JOIN tmscrq.TMStore st ON st.Id = l.StoreId
LEFT JOIN tmscrq.TMLeadProcess lp ON lp.Id = l.ProcessID
LEFT JOIN tmscrq.TMLeadNextStep ns ON ns.Id = l.NextStepId

WHERE
-- Yetkilendirme
(
    -- Yönetici / Üst Yönetici: Tüm lead'ler
    EXISTS (
        SELECT 1
        FROM dbo.KUserRole ur
        INNER JOIN dbo.KRole r ON r.Id = ur.KRole_Id
        WHERE ur.KUser_Id = @UserId
          AND ur.IsDeleted = 0
          AND r.IsDeleted = 0
          AND r.Name IN ('TimesYonetici', 'TimesUstYonetici')
    )

    OR

    -- Mağaza Müdürü: Kendi mağazasındaki tüm lead'ler
    (
        EXISTS (
            SELECT 1
            FROM dbo.KUserRole ur
            INNER JOIN dbo.KRole r ON r.Id = ur.KRole_Id
            WHERE ur.KUser_Id = @UserId
              AND ur.IsDeleted = 0
              AND r.IsDeleted = 0
              AND r.Name = 'TimesMagazaMuduru'
        )
        AND l.StoreId =
        (
            SELECT TOP 1 tu.StoreID
            FROM tmscrq.TMUser tu
            WHERE tu.KUserID = @UserId
        )
    )

    OR

    -- Satış Personeli: Sadece kendi açtığı lead'ler
    (
        EXISTS (
            SELECT 1
            FROM dbo.KUserRole ur
            INNER JOIN dbo.KRole r ON r.Id = ur.KRole_Id
            WHERE ur.KUser_Id = @UserId
              AND ur.IsDeleted = 0
              AND r.IsDeleted = 0
              AND r.Name = 'TimesSatisPersoneli'
        )
        AND l.SalesPersonKUserId = @UserId
    )
)

-- Müşteri Adı
AND
(
    @MusteriAdi IS NULL
    OR LTRIM(RTRIM(@MusteriAdi)) = ''
    OR UPPER(LTRIM(RTRIM(ISNULL(cu.Name,'') + ' ' + ISNULL(cu.LastName,''))))
       LIKE '%' + UPPER(LTRIM(RTRIM(@MusteriAdi))) + '%'
)

-- Ürün Adı
AND
(
    @ProductName IS NULL
    OR LTRIM(RTRIM(@ProductName)) = ''
    OR
    (
        CHARINDEX(',', @ProductName) > 0
        AND ISNULL(LTRIM(RTRIM(p.ProductName)), '') IN
        (
            SELECT LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', '')))
            FROM STRING_SPLIT(CAST(@ProductName AS NVARCHAR(MAX)), ',')
            WHERE LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', ''))) <> ''
        )
    )
    OR
    (
        CHARINDEX(',', @ProductName) = 0
        AND UPPER(ISNULL(LTRIM(RTRIM(p.ProductName)), ''))
            LIKE '%' + UPPER(LTRIM(RTRIM(@ProductName))) + '%'
    )
)

-- Lead Kodu
AND
(
    @LeadCode IS NULL
    OR LTRIM(RTRIM(@LeadCode)) = ''
    OR UPPER(ISNULL(LTRIM(RTRIM(l.LeadCode)), '')) LIKE '%' + UPPER(LTRIM(RTRIM(@LeadCode))) + '%'
)

-- Telefon
AND
(
    @Tel IS NULL
    OR LTRIM(RTRIM(@Tel)) = ''
    OR UPPER(ISNULL(LTRIM(RTRIM(cu.Tel)), '')) LIKE '%' + UPPER(LTRIM(RTRIM(@Tel))) + '%'
)

-- Kategori
AND
(
    @CategoryName IS NULL
    OR LTRIM(RTRIM(@CategoryName)) = ''
    OR UPPER(ISNULL(LTRIM(RTRIM(p.CategoryName)), '')) IN
    (
        SELECT UPPER(LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value,'""',''),'[',''),']',''))))
        FROM STRING_SPLIT(CAST(@CategoryName AS NVARCHAR(MAX)), ',')
        WHERE LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value,'""',''),'[',''),']',''))) <> ''
    )
)

-- Mağaza
AND
(
    @StoreIds IS NULL
    OR LTRIM(RTRIM(@StoreIds)) = ''
    OR EXISTS
    (
        SELECT 1
        FROM STRING_SPLIT(CAST(@StoreIds AS NVARCHAR(MAX)), ',') s
        WHERE l.StoreId = TRY_CONVERT
        (
            uniqueidentifier,
            LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(s.value, '""', ''), '[', ''), ']', '')))
        )
    )
)

-- Satış Danışmanı
AND
(
    @SatisDanismaniIds IS NULL
    OR LTRIM(RTRIM(@SatisDanismaniIds)) = ''
    OR EXISTS
    (
        SELECT 1
        FROM STRING_SPLIT(CAST(@SatisDanismaniIds AS NVARCHAR(MAX)), ',') s
        WHERE l.SalesPersonKUserId = TRY_CONVERT
        (
            uniqueidentifier,
            LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(s.value, '""', ''), '[', ''), ']', '')))
        )
    )
)

-- Süreç Kodu
AND
(
    @ProcessCode IS NULL
    OR LTRIM(RTRIM(@ProcessCode)) = ''
    OR UPPER(ISNULL(LTRIM(RTRIM(lp.Code)), '')) IN
    (
        SELECT UPPER(LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', ''))))
        FROM STRING_SPLIT(CAST(@ProcessCode AS NVARCHAR(MAX)), ',')
        WHERE LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', ''))) <> ''
    )
)

-- StepOrder Filtresi (genişletilmiş, -4 eklendi)
AND
(
    @StepOrder IS NULL
    OR @StepOrder = 0   -- Tümü

    -- Aktif: CREATED, TERMIN_PENDING, PENDING, APPROVED, DELIVERY_PENDING
    OR (@StepOrder = -1 AND lp.Code IN ('CREATED','TERMIN_PENDING','PENDING','APPROVED','DELIVERY_PENDING'))

    -- Bugün oluşturulanlar
    OR (
        @StepOrder = -2 
        AND l.CreatedAt >= CAST(GETDATE() AS DATE) 
        AND l.CreatedAt < DATEADD(day, 1, CAST(GETDATE() AS DATE))
    )

    -- Geciken (Termin Tarihi Geçmiş): EstimatedDate bugünden küçük ve sonuçlanmamış
    OR (
        @StepOrder = -3 
        AND l.EstimatedDate < CAST(GETDATE() AS DATE) 
        AND lp.Code NOT IN ('DELIVERED','CLOSED','CUSTOMER_DECLINED','REJECTED')
    )

    -- Bu ayın terminleri
    OR (
        @StepOrder = -4 
        AND l.EstimatedDate >= DATEFROMPARTS(YEAR(GETDATE()), MONTH(GETDATE()), 1)
        AND l.EstimatedDate < DATEADD(MONTH, 1, DATEFROMPARTS(YEAR(GETDATE()), MONTH(GETDATE()), 1))
    )

    -- Rezerv onay bekleyen
    OR (
        @StepOrder = 10 
        AND EXISTS (
            SELECT 1 
            FROM tmscrq.TMLeadReservation r 
            WHERE r.LeadId = l.Id 
              AND r.IsActive = 1 
              AND ISNULL(r.IsApproved,0) = 0
        )
    )

    -- Diğer pozitif StepOrder değerleri
    OR (
        @StepOrder NOT IN (0, -1, -2, -3, -4, 10) 
        AND lp.StepOrder = @StepOrder
    )
)

-- Başlangıç Tarihi
AND
(
    @StartDate IS NULL
    OR LTRIM(RTRIM(@StartDate)) = ''
    OR l.CreatedAt >= CONVERT(date, @StartDate)
)

-- Bitiş Tarihi
AND
(
    @EndDate IS NULL
    OR LTRIM(RTRIM(@EndDate)) = ''
    OR l.CreatedAt < DATEADD(day, 1, CONVERT(date, @EndDate))
)

ORDER BY l.CreatedAt DESC;", new string[] { "RezerveDurumu", "LeadId", "IsReserved", "LeadNumarasi", "TalepTarihi", "ProductId", "ProductName", "Bilezik", "Brand", "Kadran", "RefCode", "Referans", "Musteri", "Lokasyon", "Ilce", "Ulke", "MusteriInfo", "AlisverisiVarMi", "IrtibatNumarasi", "EmailAdresi", "IletisimKaynagi", "CategoryName", "CategoryCode", "LeadDurumu", "SonrakiAdim", "ProcessName", "ProcessCode", "StepOrder", "SelectedStepOrder", "TerminTarihi", "SatisDanismani", "StoreName" }, prms_TM_TopManagerDashboardLeadList_0.ToArray());
            ;


            return Ok(result);
        }


        [HttpPost, Route("DashBoardTempComponent_464762_onClick")]
        public IActionResult DashBoardTempComponent_464762_onClick(DashBoardTempComponent_464762_onClick_Request request)
        {

            KProviderManager.Authorization.IsAuthorizedForRoles(appId, appName, screenId, screenName, new List<string> { $"b4bfd39c-ac02-f442-c899-7a2374a45b47", "70de6cfc-6087-6059-59b4-0b5a8527af6b", "TimesSatisPersoneli", "TimesMagazaMuduru" });

            var result = new DashBoardTempComponent_464762_onClick_Response();

            var prms_TM_TopManagerDashboardLeadList_0 = new List<kSqlParameter>();
            prms_TM_TopManagerDashboardLeadList_0.Add(new kSqlParameter() { Name = "UserId", Value = Kuika.Common.KContext.CurrentUser?.Id });
            prms_TM_TopManagerDashboardLeadList_0.Add(new kSqlParameter() { Name = "MusteriAdi", Value = request.MusteriAdi_0 });
            prms_TM_TopManagerDashboardLeadList_0.Add(new kSqlParameter() { Name = "ProductName", Value = request.ProductName_0 });
            prms_TM_TopManagerDashboardLeadList_0.Add(new kSqlParameter() { Name = "LeadCode", Value = (null as object) });
            prms_TM_TopManagerDashboardLeadList_0.Add(new kSqlParameter() { Name = "Tel", Value = (null as object) });
            prms_TM_TopManagerDashboardLeadList_0.Add(new kSqlParameter() { Name = "CategoryName", Value = request.CategoryName_0 });
            prms_TM_TopManagerDashboardLeadList_0.Add(new kSqlParameter() { Name = "StoreIds", Value = request.StoreIds_0 });
            prms_TM_TopManagerDashboardLeadList_0.Add(new kSqlParameter() { Name = "SatisDanismaniIds", Value = request.SatisDanismaniIds_0 });
            prms_TM_TopManagerDashboardLeadList_0.Add(new kSqlParameter() { Name = "ProcessCode", Value = request.ProcessCode_0 });
            prms_TM_TopManagerDashboardLeadList_0.Add(new kSqlParameter() { Name = "StepOrder", Value = "10".ConvertToType<Int32>() });
            prms_TM_TopManagerDashboardLeadList_0.Add(new kSqlParameter() { Name = "StartDate", Value = request.StartDate_0 });
            prms_TM_TopManagerDashboardLeadList_0.Add(new kSqlParameter() { Name = "EndDate", Value = request.EndDate_0 });
            using var auditTM_TopManagerDashboardLeadList_0 = ActionAuditScope.Begin("0d672bdd-d09c-8458-c85a-efd723f6fe0e", "TM_TopManagerDashboardLeadList", applicationName: "wbTimesCRM", screenOrEndpointName: "DashBoardTemp");
            result.TM_TopManagerDashboardLeadList = KPersister.Fetch(KContext.GetConnectionString(), @"SET LANGUAGE Turkish;


SELECT
    CASE 
        WHEN EXISTS (
            SELECT 1 
            FROM tmscrq.TMLeadReservation r
            WHERE r.LeadId = l.Id
              AND r.IsActive = 1
              AND r.IsApproved = 1
        ) THEN N'Evet'
        WHEN EXISTS (
            SELECT 1 
            FROM tmscrq.TMLeadReservation r
            WHERE r.LeadId = l.Id
              AND r.IsActive = 1
              AND ISNULL(r.IsApproved,0) = 0
        ) THEN N'Onay Bekliyor'
        ELSE N'Hayır'
    END AS RezerveDurumu,
    l.Id AS LeadId,
    l.IsReserved,
    ISNULL(NULLIF(LTRIM(RTRIM(l.LeadCode)), ''), '-') AS LeadNumarasi,
    CONVERT(varchar(10), l.CreatedAt, 103) AS TalepTarihi,

    p.Id AS ProductId,
    ISNULL(NULLIF(LTRIM(RTRIM(p.ProductName)), ''), '-') AS ProductName,
    ISNULL(NULLIF(LTRIM(RTRIM(p.Bracelet)), ''), '-') AS Bilezik,
    ISNULL(NULLIF(LTRIM(RTRIM(p.Brand)), ''), '-') AS Brand,
    ISNULL(NULLIF(LTRIM(RTRIM(p.Dial)), ''), '-') AS Kadran,
    ISNULL(NULLIF(LTRIM(RTRIM(p.ProductCode)), ''), '-') AS RefCode,
    ISNULL(NULLIF(LTRIM(RTRIM(p.Referance)), ''), '-') AS Referans,

    ISNULL(
        NULLIF(
            LTRIM(RTRIM(ISNULL(cu.Name, '') + ' ' + ISNULL(cu.LastName, '')))
        , '')
    , '-') AS Musteri,

    ISNULL(NULLIF(LTRIM(RTRIM(cu.CityName)), ''), '-') AS Lokasyon,
    ISNULL(NULLIF(LTRIM(RTRIM(cu.DistrictName)), ''), '-') AS Ilce,
    ISNULL(NULLIF(LTRIM(RTRIM(cu.CountryName)), ''), '-') AS Ulke,
    ISNULL(NULLIF(LTRIM(RTRIM(cu.Info)), ''), '-') AS MusteriInfo,

    CASE
        WHEN cu.IsShopping = 1 THEN N'Evet'
        WHEN cu.IsShopping = 0 THEN N'Hayır'
        ELSE '-'
    END AS AlisverisiVarMi,

    ISNULL(NULLIF(LTRIM(RTRIM(cu.Tel)), ''), '-') AS IrtibatNumarasi,
    ISNULL(NULLIF(LTRIM(RTRIM(cu.Email)), ''), '-') AS EmailAdresi,

    ISNULL(NULLIF(LTRIM(RTRIM(cr.ContactResourceName)), ''), '-') AS IletisimKaynagi,

    ISNULL(NULLIF(LTRIM(RTRIM(p.CategoryName)), ''), '-') AS CategoryName,
    '-' AS CategoryCode,

    ISNULL(NULLIF(LTRIM(RTRIM(ls.Name)), ''), '-') AS LeadDurumu,
    ISNULL(NULLIF(LTRIM(RTRIM(ns.Name)), ''), '-') AS SonrakiAdim,

    ISNULL(NULLIF(LTRIM(RTRIM(lp.Name)), ''), '-') AS ProcessName,
    ISNULL(NULLIF(LTRIM(RTRIM(lp.Code)), ''), '-') AS ProcessCode,
    lp.StepOrder,
    
    CAST(ISNULL(@StepOrder, lp.StepOrder) AS INT) AS SelectedStepOrder,

    ISNULL(
        CASE
            WHEN l.EstimatedDate IS NOT NULL
            THEN CAST(YEAR(l.EstimatedDate) AS VARCHAR(4)) + ' ' + DATENAME(MONTH, l.EstimatedDate)
            ELSE NULL
        END,
        '-'
    ) AS TerminTarihi,

    ISNULL(
        NULLIF(
            LTRIM(RTRIM(ISNULL(sp.FirstName, '') + ' ' + ISNULL(sp.LastName, '')))
        , '')
    , '-') AS SatisDanismani,

    ISNULL(NULLIF(LTRIM(RTRIM(st.StoreDesc)), ''), '-') AS StoreName

FROM tmscrq.TMLead l
LEFT JOIN tmscrq.TMLeadStatu ls ON ls.Id = l.StatuId
LEFT JOIN tmscrq.TMCustomer cu ON cu.Id = l.CustomerId
LEFT JOIN tmscrq.TMProduct p ON p.Id = l.ProductId
LEFT JOIN tmscrq.TMContactResource cr ON cr.Id = l.ContactResourceId
LEFT JOIN dbo.KUser sp ON sp.Id = l.SalesPersonKUserId
LEFT JOIN tmscrq.TMStore st ON st.Id = l.StoreId
LEFT JOIN tmscrq.TMLeadProcess lp ON lp.Id = l.ProcessID
LEFT JOIN tmscrq.TMLeadNextStep ns ON ns.Id = l.NextStepId

WHERE
-- Yetkilendirme
(
    -- Yönetici / Üst Yönetici: Tüm lead'ler
    EXISTS (
        SELECT 1
        FROM dbo.KUserRole ur
        INNER JOIN dbo.KRole r ON r.Id = ur.KRole_Id
        WHERE ur.KUser_Id = @UserId
          AND ur.IsDeleted = 0
          AND r.IsDeleted = 0
          AND r.Name IN ('TimesYonetici', 'TimesUstYonetici')
    )

    OR

    -- Mağaza Müdürü: Kendi mağazasındaki tüm lead'ler
    (
        EXISTS (
            SELECT 1
            FROM dbo.KUserRole ur
            INNER JOIN dbo.KRole r ON r.Id = ur.KRole_Id
            WHERE ur.KUser_Id = @UserId
              AND ur.IsDeleted = 0
              AND r.IsDeleted = 0
              AND r.Name = 'TimesMagazaMuduru'
        )
        AND l.StoreId =
        (
            SELECT TOP 1 tu.StoreID
            FROM tmscrq.TMUser tu
            WHERE tu.KUserID = @UserId
        )
    )

    OR

    -- Satış Personeli: Sadece kendi açtığı lead'ler
    (
        EXISTS (
            SELECT 1
            FROM dbo.KUserRole ur
            INNER JOIN dbo.KRole r ON r.Id = ur.KRole_Id
            WHERE ur.KUser_Id = @UserId
              AND ur.IsDeleted = 0
              AND r.IsDeleted = 0
              AND r.Name = 'TimesSatisPersoneli'
        )
        AND l.SalesPersonKUserId = @UserId
    )
)

-- Müşteri Adı
AND
(
    @MusteriAdi IS NULL
    OR LTRIM(RTRIM(@MusteriAdi)) = ''
    OR UPPER(LTRIM(RTRIM(ISNULL(cu.Name,'') + ' ' + ISNULL(cu.LastName,''))))
       LIKE '%' + UPPER(LTRIM(RTRIM(@MusteriAdi))) + '%'
)

-- Ürün Adı
AND
(
    @ProductName IS NULL
    OR LTRIM(RTRIM(@ProductName)) = ''
    OR
    (
        CHARINDEX(',', @ProductName) > 0
        AND ISNULL(LTRIM(RTRIM(p.ProductName)), '') IN
        (
            SELECT LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', '')))
            FROM STRING_SPLIT(CAST(@ProductName AS NVARCHAR(MAX)), ',')
            WHERE LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', ''))) <> ''
        )
    )
    OR
    (
        CHARINDEX(',', @ProductName) = 0
        AND UPPER(ISNULL(LTRIM(RTRIM(p.ProductName)), ''))
            LIKE '%' + UPPER(LTRIM(RTRIM(@ProductName))) + '%'
    )
)

-- Lead Kodu
AND
(
    @LeadCode IS NULL
    OR LTRIM(RTRIM(@LeadCode)) = ''
    OR UPPER(ISNULL(LTRIM(RTRIM(l.LeadCode)), '')) LIKE '%' + UPPER(LTRIM(RTRIM(@LeadCode))) + '%'
)

-- Telefon
AND
(
    @Tel IS NULL
    OR LTRIM(RTRIM(@Tel)) = ''
    OR UPPER(ISNULL(LTRIM(RTRIM(cu.Tel)), '')) LIKE '%' + UPPER(LTRIM(RTRIM(@Tel))) + '%'
)

-- Kategori
AND
(
    @CategoryName IS NULL
    OR LTRIM(RTRIM(@CategoryName)) = ''
    OR UPPER(ISNULL(LTRIM(RTRIM(p.CategoryName)), '')) IN
    (
        SELECT UPPER(LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value,'""',''),'[',''),']',''))))
        FROM STRING_SPLIT(CAST(@CategoryName AS NVARCHAR(MAX)), ',')
        WHERE LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value,'""',''),'[',''),']',''))) <> ''
    )
)

-- Mağaza
AND
(
    @StoreIds IS NULL
    OR LTRIM(RTRIM(@StoreIds)) = ''
    OR EXISTS
    (
        SELECT 1
        FROM STRING_SPLIT(CAST(@StoreIds AS NVARCHAR(MAX)), ',') s
        WHERE l.StoreId = TRY_CONVERT
        (
            uniqueidentifier,
            LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(s.value, '""', ''), '[', ''), ']', '')))
        )
    )
)

-- Satış Danışmanı
AND
(
    @SatisDanismaniIds IS NULL
    OR LTRIM(RTRIM(@SatisDanismaniIds)) = ''
    OR EXISTS
    (
        SELECT 1
        FROM STRING_SPLIT(CAST(@SatisDanismaniIds AS NVARCHAR(MAX)), ',') s
        WHERE l.SalesPersonKUserId = TRY_CONVERT
        (
            uniqueidentifier,
            LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(s.value, '""', ''), '[', ''), ']', '')))
        )
    )
)

-- Süreç Kodu
AND
(
    @ProcessCode IS NULL
    OR LTRIM(RTRIM(@ProcessCode)) = ''
    OR UPPER(ISNULL(LTRIM(RTRIM(lp.Code)), '')) IN
    (
        SELECT UPPER(LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', ''))))
        FROM STRING_SPLIT(CAST(@ProcessCode AS NVARCHAR(MAX)), ',')
        WHERE LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', ''))) <> ''
    )
)

-- StepOrder Filtresi (genişletilmiş, -4 eklendi)
AND
(
    @StepOrder IS NULL
    OR @StepOrder = 0   -- Tümü

    -- Aktif: CREATED, TERMIN_PENDING, PENDING, APPROVED, DELIVERY_PENDING
    OR (@StepOrder = -1 AND lp.Code IN ('CREATED','TERMIN_PENDING','PENDING','APPROVED','DELIVERY_PENDING'))

    -- Bugün oluşturulanlar
    OR (
        @StepOrder = -2 
        AND l.CreatedAt >= CAST(GETDATE() AS DATE) 
        AND l.CreatedAt < DATEADD(day, 1, CAST(GETDATE() AS DATE))
    )

    -- Geciken (Termin Tarihi Geçmiş): EstimatedDate bugünden küçük ve sonuçlanmamış
    OR (
        @StepOrder = -3 
        AND l.EstimatedDate < CAST(GETDATE() AS DATE) 
        AND lp.Code NOT IN ('DELIVERED','CLOSED','CUSTOMER_DECLINED','REJECTED')
    )

    -- Bu ayın terminleri
    OR (
        @StepOrder = -4 
        AND l.EstimatedDate >= DATEFROMPARTS(YEAR(GETDATE()), MONTH(GETDATE()), 1)
        AND l.EstimatedDate < DATEADD(MONTH, 1, DATEFROMPARTS(YEAR(GETDATE()), MONTH(GETDATE()), 1))
    )

    -- Rezerv onay bekleyen
    OR (
        @StepOrder = 10 
        AND EXISTS (
            SELECT 1 
            FROM tmscrq.TMLeadReservation r 
            WHERE r.LeadId = l.Id 
              AND r.IsActive = 1 
              AND ISNULL(r.IsApproved,0) = 0
        )
    )

    -- Diğer pozitif StepOrder değerleri
    OR (
        @StepOrder NOT IN (0, -1, -2, -3, -4, 10) 
        AND lp.StepOrder = @StepOrder
    )
)

-- Başlangıç Tarihi
AND
(
    @StartDate IS NULL
    OR LTRIM(RTRIM(@StartDate)) = ''
    OR l.CreatedAt >= CONVERT(date, @StartDate)
)

-- Bitiş Tarihi
AND
(
    @EndDate IS NULL
    OR LTRIM(RTRIM(@EndDate)) = ''
    OR l.CreatedAt < DATEADD(day, 1, CONVERT(date, @EndDate))
)

ORDER BY l.CreatedAt DESC;", new string[] { "RezerveDurumu", "LeadId", "IsReserved", "LeadNumarasi", "TalepTarihi", "ProductId", "ProductName", "Bilezik", "Brand", "Kadran", "RefCode", "Referans", "Musteri", "Lokasyon", "Ilce", "Ulke", "MusteriInfo", "AlisverisiVarMi", "IrtibatNumarasi", "EmailAdresi", "IletisimKaynagi", "CategoryName", "CategoryCode", "LeadDurumu", "SonrakiAdim", "ProcessName", "ProcessCode", "StepOrder", "SelectedStepOrder", "TerminTarihi", "SatisDanismani", "StoreName" }, prms_TM_TopManagerDashboardLeadList_0.ToArray());
            ;


            return Ok(result);
        }


        [HttpPost, Route("DashBoardTempComponent_134969_onClick")]
        public IActionResult DashBoardTempComponent_134969_onClick(DashBoardTempComponent_134969_onClick_Request request)
        {

            KProviderManager.Authorization.IsAuthorizedForRoles(appId, appName, screenId, screenName, new List<string> { $"b4bfd39c-ac02-f442-c899-7a2374a45b47", "70de6cfc-6087-6059-59b4-0b5a8527af6b", "TimesSatisPersoneli", "TimesMagazaMuduru" });

            var result = new DashBoardTempComponent_134969_onClick_Response();

            var prms_TM_TopManagerDashboardLeadList_0 = new List<kSqlParameter>();
            prms_TM_TopManagerDashboardLeadList_0.Add(new kSqlParameter() { Name = "UserId", Value = Kuika.Common.KContext.CurrentUser?.Id });
            prms_TM_TopManagerDashboardLeadList_0.Add(new kSqlParameter() { Name = "MusteriAdi", Value = request.MusteriAdi_0 });
            prms_TM_TopManagerDashboardLeadList_0.Add(new kSqlParameter() { Name = "ProductName", Value = request.ProductName_0 });
            prms_TM_TopManagerDashboardLeadList_0.Add(new kSqlParameter() { Name = "LeadCode", Value = (null as object) });
            prms_TM_TopManagerDashboardLeadList_0.Add(new kSqlParameter() { Name = "Tel", Value = (null as object) });
            prms_TM_TopManagerDashboardLeadList_0.Add(new kSqlParameter() { Name = "CategoryName", Value = request.CategoryName_0 });
            prms_TM_TopManagerDashboardLeadList_0.Add(new kSqlParameter() { Name = "StoreIds", Value = request.StoreIds_0 });
            prms_TM_TopManagerDashboardLeadList_0.Add(new kSqlParameter() { Name = "SatisDanismaniIds", Value = request.SatisDanismaniIds_0 });
            prms_TM_TopManagerDashboardLeadList_0.Add(new kSqlParameter() { Name = "ProcessCode", Value = request.ProcessCode_0 });
            prms_TM_TopManagerDashboardLeadList_0.Add(new kSqlParameter() { Name = "StepOrder", Value = "6".ConvertToType<Int32>() });
            prms_TM_TopManagerDashboardLeadList_0.Add(new kSqlParameter() { Name = "StartDate", Value = request.StartDate_0 });
            prms_TM_TopManagerDashboardLeadList_0.Add(new kSqlParameter() { Name = "EndDate", Value = request.EndDate_0 });
            using var auditTM_TopManagerDashboardLeadList_0 = ActionAuditScope.Begin("894d929c-db55-a060-5305-85c8da69e8f0", "TM_TopManagerDashboardLeadList", applicationName: "wbTimesCRM", screenOrEndpointName: "DashBoardTemp");
            result.TM_TopManagerDashboardLeadList = KPersister.Fetch(KContext.GetConnectionString(), @"SET LANGUAGE Turkish;


SELECT
    CASE 
        WHEN EXISTS (
            SELECT 1 
            FROM tmscrq.TMLeadReservation r
            WHERE r.LeadId = l.Id
              AND r.IsActive = 1
              AND r.IsApproved = 1
        ) THEN N'Evet'
        WHEN EXISTS (
            SELECT 1 
            FROM tmscrq.TMLeadReservation r
            WHERE r.LeadId = l.Id
              AND r.IsActive = 1
              AND ISNULL(r.IsApproved,0) = 0
        ) THEN N'Onay Bekliyor'
        ELSE N'Hayır'
    END AS RezerveDurumu,
    l.Id AS LeadId,
    l.IsReserved,
    ISNULL(NULLIF(LTRIM(RTRIM(l.LeadCode)), ''), '-') AS LeadNumarasi,
    CONVERT(varchar(10), l.CreatedAt, 103) AS TalepTarihi,

    p.Id AS ProductId,
    ISNULL(NULLIF(LTRIM(RTRIM(p.ProductName)), ''), '-') AS ProductName,
    ISNULL(NULLIF(LTRIM(RTRIM(p.Bracelet)), ''), '-') AS Bilezik,
    ISNULL(NULLIF(LTRIM(RTRIM(p.Brand)), ''), '-') AS Brand,
    ISNULL(NULLIF(LTRIM(RTRIM(p.Dial)), ''), '-') AS Kadran,
    ISNULL(NULLIF(LTRIM(RTRIM(p.ProductCode)), ''), '-') AS RefCode,
    ISNULL(NULLIF(LTRIM(RTRIM(p.Referance)), ''), '-') AS Referans,

    ISNULL(
        NULLIF(
            LTRIM(RTRIM(ISNULL(cu.Name, '') + ' ' + ISNULL(cu.LastName, '')))
        , '')
    , '-') AS Musteri,

    ISNULL(NULLIF(LTRIM(RTRIM(cu.CityName)), ''), '-') AS Lokasyon,
    ISNULL(NULLIF(LTRIM(RTRIM(cu.DistrictName)), ''), '-') AS Ilce,
    ISNULL(NULLIF(LTRIM(RTRIM(cu.CountryName)), ''), '-') AS Ulke,
    ISNULL(NULLIF(LTRIM(RTRIM(cu.Info)), ''), '-') AS MusteriInfo,

    CASE
        WHEN cu.IsShopping = 1 THEN N'Evet'
        WHEN cu.IsShopping = 0 THEN N'Hayır'
        ELSE '-'
    END AS AlisverisiVarMi,

    ISNULL(NULLIF(LTRIM(RTRIM(cu.Tel)), ''), '-') AS IrtibatNumarasi,
    ISNULL(NULLIF(LTRIM(RTRIM(cu.Email)), ''), '-') AS EmailAdresi,

    ISNULL(NULLIF(LTRIM(RTRIM(cr.ContactResourceName)), ''), '-') AS IletisimKaynagi,

    ISNULL(NULLIF(LTRIM(RTRIM(p.CategoryName)), ''), '-') AS CategoryName,
    '-' AS CategoryCode,

    ISNULL(NULLIF(LTRIM(RTRIM(ls.Name)), ''), '-') AS LeadDurumu,
    ISNULL(NULLIF(LTRIM(RTRIM(ns.Name)), ''), '-') AS SonrakiAdim,

    ISNULL(NULLIF(LTRIM(RTRIM(lp.Name)), ''), '-') AS ProcessName,
    ISNULL(NULLIF(LTRIM(RTRIM(lp.Code)), ''), '-') AS ProcessCode,
    lp.StepOrder,
    
    CAST(ISNULL(@StepOrder, lp.StepOrder) AS INT) AS SelectedStepOrder,

    ISNULL(
        CASE
            WHEN l.EstimatedDate IS NOT NULL
            THEN CAST(YEAR(l.EstimatedDate) AS VARCHAR(4)) + ' ' + DATENAME(MONTH, l.EstimatedDate)
            ELSE NULL
        END,
        '-'
    ) AS TerminTarihi,

    ISNULL(
        NULLIF(
            LTRIM(RTRIM(ISNULL(sp.FirstName, '') + ' ' + ISNULL(sp.LastName, '')))
        , '')
    , '-') AS SatisDanismani,

    ISNULL(NULLIF(LTRIM(RTRIM(st.StoreDesc)), ''), '-') AS StoreName

FROM tmscrq.TMLead l
LEFT JOIN tmscrq.TMLeadStatu ls ON ls.Id = l.StatuId
LEFT JOIN tmscrq.TMCustomer cu ON cu.Id = l.CustomerId
LEFT JOIN tmscrq.TMProduct p ON p.Id = l.ProductId
LEFT JOIN tmscrq.TMContactResource cr ON cr.Id = l.ContactResourceId
LEFT JOIN dbo.KUser sp ON sp.Id = l.SalesPersonKUserId
LEFT JOIN tmscrq.TMStore st ON st.Id = l.StoreId
LEFT JOIN tmscrq.TMLeadProcess lp ON lp.Id = l.ProcessID
LEFT JOIN tmscrq.TMLeadNextStep ns ON ns.Id = l.NextStepId

WHERE
-- Yetkilendirme
(
    -- Yönetici / Üst Yönetici: Tüm lead'ler
    EXISTS (
        SELECT 1
        FROM dbo.KUserRole ur
        INNER JOIN dbo.KRole r ON r.Id = ur.KRole_Id
        WHERE ur.KUser_Id = @UserId
          AND ur.IsDeleted = 0
          AND r.IsDeleted = 0
          AND r.Name IN ('TimesYonetici', 'TimesUstYonetici')
    )

    OR

    -- Mağaza Müdürü: Kendi mağazasındaki tüm lead'ler
    (
        EXISTS (
            SELECT 1
            FROM dbo.KUserRole ur
            INNER JOIN dbo.KRole r ON r.Id = ur.KRole_Id
            WHERE ur.KUser_Id = @UserId
              AND ur.IsDeleted = 0
              AND r.IsDeleted = 0
              AND r.Name = 'TimesMagazaMuduru'
        )
        AND l.StoreId =
        (
            SELECT TOP 1 tu.StoreID
            FROM tmscrq.TMUser tu
            WHERE tu.KUserID = @UserId
        )
    )

    OR

    -- Satış Personeli: Sadece kendi açtığı lead'ler
    (
        EXISTS (
            SELECT 1
            FROM dbo.KUserRole ur
            INNER JOIN dbo.KRole r ON r.Id = ur.KRole_Id
            WHERE ur.KUser_Id = @UserId
              AND ur.IsDeleted = 0
              AND r.IsDeleted = 0
              AND r.Name = 'TimesSatisPersoneli'
        )
        AND l.SalesPersonKUserId = @UserId
    )
)

-- Müşteri Adı
AND
(
    @MusteriAdi IS NULL
    OR LTRIM(RTRIM(@MusteriAdi)) = ''
    OR UPPER(LTRIM(RTRIM(ISNULL(cu.Name,'') + ' ' + ISNULL(cu.LastName,''))))
       LIKE '%' + UPPER(LTRIM(RTRIM(@MusteriAdi))) + '%'
)

-- Ürün Adı
AND
(
    @ProductName IS NULL
    OR LTRIM(RTRIM(@ProductName)) = ''
    OR
    (
        CHARINDEX(',', @ProductName) > 0
        AND ISNULL(LTRIM(RTRIM(p.ProductName)), '') IN
        (
            SELECT LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', '')))
            FROM STRING_SPLIT(CAST(@ProductName AS NVARCHAR(MAX)), ',')
            WHERE LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', ''))) <> ''
        )
    )
    OR
    (
        CHARINDEX(',', @ProductName) = 0
        AND UPPER(ISNULL(LTRIM(RTRIM(p.ProductName)), ''))
            LIKE '%' + UPPER(LTRIM(RTRIM(@ProductName))) + '%'
    )
)

-- Lead Kodu
AND
(
    @LeadCode IS NULL
    OR LTRIM(RTRIM(@LeadCode)) = ''
    OR UPPER(ISNULL(LTRIM(RTRIM(l.LeadCode)), '')) LIKE '%' + UPPER(LTRIM(RTRIM(@LeadCode))) + '%'
)

-- Telefon
AND
(
    @Tel IS NULL
    OR LTRIM(RTRIM(@Tel)) = ''
    OR UPPER(ISNULL(LTRIM(RTRIM(cu.Tel)), '')) LIKE '%' + UPPER(LTRIM(RTRIM(@Tel))) + '%'
)

-- Kategori
AND
(
    @CategoryName IS NULL
    OR LTRIM(RTRIM(@CategoryName)) = ''
    OR UPPER(ISNULL(LTRIM(RTRIM(p.CategoryName)), '')) IN
    (
        SELECT UPPER(LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value,'""',''),'[',''),']',''))))
        FROM STRING_SPLIT(CAST(@CategoryName AS NVARCHAR(MAX)), ',')
        WHERE LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value,'""',''),'[',''),']',''))) <> ''
    )
)

-- Mağaza
AND
(
    @StoreIds IS NULL
    OR LTRIM(RTRIM(@StoreIds)) = ''
    OR EXISTS
    (
        SELECT 1
        FROM STRING_SPLIT(CAST(@StoreIds AS NVARCHAR(MAX)), ',') s
        WHERE l.StoreId = TRY_CONVERT
        (
            uniqueidentifier,
            LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(s.value, '""', ''), '[', ''), ']', '')))
        )
    )
)

-- Satış Danışmanı
AND
(
    @SatisDanismaniIds IS NULL
    OR LTRIM(RTRIM(@SatisDanismaniIds)) = ''
    OR EXISTS
    (
        SELECT 1
        FROM STRING_SPLIT(CAST(@SatisDanismaniIds AS NVARCHAR(MAX)), ',') s
        WHERE l.SalesPersonKUserId = TRY_CONVERT
        (
            uniqueidentifier,
            LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(s.value, '""', ''), '[', ''), ']', '')))
        )
    )
)

-- Süreç Kodu
AND
(
    @ProcessCode IS NULL
    OR LTRIM(RTRIM(@ProcessCode)) = ''
    OR UPPER(ISNULL(LTRIM(RTRIM(lp.Code)), '')) IN
    (
        SELECT UPPER(LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', ''))))
        FROM STRING_SPLIT(CAST(@ProcessCode AS NVARCHAR(MAX)), ',')
        WHERE LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', ''))) <> ''
    )
)

-- StepOrder Filtresi (genişletilmiş, -4 eklendi)
AND
(
    @StepOrder IS NULL
    OR @StepOrder = 0   -- Tümü

    -- Aktif: CREATED, TERMIN_PENDING, PENDING, APPROVED, DELIVERY_PENDING
    OR (@StepOrder = -1 AND lp.Code IN ('CREATED','TERMIN_PENDING','PENDING','APPROVED','DELIVERY_PENDING'))

    -- Bugün oluşturulanlar
    OR (
        @StepOrder = -2 
        AND l.CreatedAt >= CAST(GETDATE() AS DATE) 
        AND l.CreatedAt < DATEADD(day, 1, CAST(GETDATE() AS DATE))
    )

    -- Geciken (Termin Tarihi Geçmiş): EstimatedDate bugünden küçük ve sonuçlanmamış
    OR (
        @StepOrder = -3 
        AND l.EstimatedDate < CAST(GETDATE() AS DATE) 
        AND lp.Code NOT IN ('DELIVERED','CLOSED','CUSTOMER_DECLINED','REJECTED')
    )

    -- Bu ayın terminleri
    OR (
        @StepOrder = -4 
        AND l.EstimatedDate >= DATEFROMPARTS(YEAR(GETDATE()), MONTH(GETDATE()), 1)
        AND l.EstimatedDate < DATEADD(MONTH, 1, DATEFROMPARTS(YEAR(GETDATE()), MONTH(GETDATE()), 1))
    )

    -- Rezerv onay bekleyen
    OR (
        @StepOrder = 10 
        AND EXISTS (
            SELECT 1 
            FROM tmscrq.TMLeadReservation r 
            WHERE r.LeadId = l.Id 
              AND r.IsActive = 1 
              AND ISNULL(r.IsApproved,0) = 0
        )
    )

    -- Diğer pozitif StepOrder değerleri
    OR (
        @StepOrder NOT IN (0, -1, -2, -3, -4, 10) 
        AND lp.StepOrder = @StepOrder
    )
)

-- Başlangıç Tarihi
AND
(
    @StartDate IS NULL
    OR LTRIM(RTRIM(@StartDate)) = ''
    OR l.CreatedAt >= CONVERT(date, @StartDate)
)

-- Bitiş Tarihi
AND
(
    @EndDate IS NULL
    OR LTRIM(RTRIM(@EndDate)) = ''
    OR l.CreatedAt < DATEADD(day, 1, CONVERT(date, @EndDate))
)

ORDER BY l.CreatedAt DESC;", new string[] { "RezerveDurumu", "LeadId", "IsReserved", "LeadNumarasi", "TalepTarihi", "ProductId", "ProductName", "Bilezik", "Brand", "Kadran", "RefCode", "Referans", "Musteri", "Lokasyon", "Ilce", "Ulke", "MusteriInfo", "AlisverisiVarMi", "IrtibatNumarasi", "EmailAdresi", "IletisimKaynagi", "CategoryName", "CategoryCode", "LeadDurumu", "SonrakiAdim", "ProcessName", "ProcessCode", "StepOrder", "SelectedStepOrder", "TerminTarihi", "SatisDanismani", "StoreName" }, prms_TM_TopManagerDashboardLeadList_0.ToArray());
            ;


            return Ok(result);
        }


        [HttpPost, Route("DashBoardTempComponent_252890_onChange")]
        public IActionResult DashBoardTempComponent_252890_onChange(DashBoardTempComponent_252890_onChange_Request request)
        {

            KProviderManager.Authorization.IsAuthorizedForRoles(appId, appName, screenId, screenName, new List<string> { $"b4bfd39c-ac02-f442-c899-7a2374a45b47", "70de6cfc-6087-6059-59b4-0b5a8527af6b", "TimesSatisPersoneli", "TimesMagazaMuduru" });

            var result = new DashBoardTempComponent_252890_onChange_Response();

            var prms_TMSalesPersonDashBoardTaskList_0 = new List<kSqlParameter>();
            prms_TMSalesPersonDashBoardTaskList_0.Add(new kSqlParameter() { Name = "UserId", Value = Kuika.Common.KContext.CurrentUser?.Id });
            prms_TMSalesPersonDashBoardTaskList_0.Add(new kSqlParameter() { Name = "TaskFilter", Value = request.TaskFilter_0 });
            using var auditTMSalesPersonDashBoardTaskList_0 = ActionAuditScope.Begin("a8586a1d-f7ae-a1e6-c5fb-76d8e1ea86bf", "TMSalesPersonDashBoardTaskList", applicationName: "wbTimesCRM", screenOrEndpointName: "DashBoardTemp");
            result.TMSalesPersonDashBoardTaskList = KPersister.Fetch(KContext.GetConnectionString(), @"SET LANGUAGE Turkish;

;WITH CurrentUserRoles AS
(
    --------------------------------------------------
    -- GİRİŞ YAPAN KULLANICININ ROLLERİ
    --------------------------------------------------
    SELECT
        CAST(
            CASE
                WHEN EXISTS
                (
                    SELECT 1
                    FROM dbo.KUserRole ur
                    INNER JOIN dbo.KRole r
                        ON r.Id = ur.KRole_Id
                    WHERE ur.KUser_Id = @UserId
                      AND ur.IsDeleted = 0
                      AND r.IsDeleted = 0
                      AND r.Name = 'TimesSatisPersoneli'
                )
                THEN 1
                ELSE 0
            END
        AS BIT) AS IsSatisPersoneli,

        CAST(
            CASE
                WHEN EXISTS
                (
                    SELECT 1
                    FROM dbo.KUserRole ur
                    INNER JOIN dbo.KRole r
                        ON r.Id = ur.KRole_Id
                    WHERE ur.KUser_Id = @UserId
                      AND ur.IsDeleted = 0
                      AND r.IsDeleted = 0
                      AND r.Name = 'TimesMagazaMuduru'
                )
                THEN 1
                ELSE 0
            END
        AS BIT) AS IsMagazaMuduru,

        CAST(
            CASE
                WHEN EXISTS
                (
                    SELECT 1
                    FROM dbo.KUserRole ur
                    INNER JOIN dbo.KRole r
                        ON r.Id = ur.KRole_Id
                    WHERE ur.KUser_Id = @UserId
                      AND ur.IsDeleted = 0
                      AND r.IsDeleted = 0
                      AND r.Name IN
                      (
                          'TimesYonetici',
                          'TimesUstYonetici'
                      )
                )
                THEN 1
                ELSE 0
            END
        AS BIT) AS IsUstYonetici
),
UserStores AS
(
    --------------------------------------------------
    -- GİRİŞ YAPAN KULLANICININ MAĞAZALARI
    --------------------------------------------------
    SELECT DISTINCT
        tu.StoreId
    FROM tmscrq.TMUser tu
    WHERE tu.KUserID = @UserId
      AND tu.StoreId IS NOT NULL
),
AllUserRoleFlags AS
(
    --------------------------------------------------
    -- TÜM KULLANICILARIN ROL BİLGİLERİ
    -- REZERV TALEBİNİ KİMİN OLUŞTURDUĞUNU
    -- ROL BAZINDA BELİRLEMEK İÇİN KULLANILIR
    --------------------------------------------------
    SELECT
        ur.KUser_Id,

        MAX(
            CASE
                WHEN r.Name = 'TimesSatisPersoneli'
                THEN 1
                ELSE 0
            END
        ) AS IsSatisPersoneli,

        MAX(
            CASE
                WHEN r.Name = 'TimesMagazaMuduru'
                THEN 1
                ELSE 0
            END
        ) AS IsMagazaMuduru,

        MAX(
            CASE
                WHEN r.Name IN
                (
                    'TimesYonetici',
                    'TimesUstYonetici'
                )
                THEN 1
                ELSE 0
            END
        ) AS IsUstYonetici

    FROM dbo.KUserRole ur
    INNER JOIN dbo.KRole r
        ON r.Id = ur.KRole_Id
    WHERE ur.IsDeleted = 0
      AND r.IsDeleted = 0
      AND r.Name IN
      (
          'TimesSatisPersoneli',
          'TimesMagazaMuduru',
          'TimesYonetici',
          'TimesUstYonetici'
      )
    GROUP BY
        ur.KUser_Id
),
ActiveReservation AS
(
    --------------------------------------------------
    -- HER LEAD İÇİN SON AKTİF REZERVASYON KAYDI
    --------------------------------------------------
    SELECT
        reservationRow.Id AS ReservationId,
        reservationRow.LeadId,
        reservationRow.IsApproved,
        reservationRow.IsRejected,
        reservationRow.ReservationNote,
        reservationRow.ReservedAt,
        reservationRow.ReservedBy
    FROM
    (
        SELECT
            r.Id,
            r.LeadId,
            ISNULL(r.IsApproved, 0) AS IsApproved,
            ISNULL(r.IsRejected, 0) AS IsRejected,
            r.ReservationNote,
            r.ReservedAt,
            r.ReservedBy,

            ROW_NUMBER() OVER
            (
                PARTITION BY r.LeadId
                ORDER BY
                    r.ReservedAt DESC,
                    r.Id DESC
            ) AS RowNumber

        FROM tmscrq.TMLeadReservation r
        WHERE r.IsActive = 1
    ) reservationRow
    WHERE reservationRow.RowNumber = 1
),
LeadBase AS
(
    --------------------------------------------------
    -- LEAD ANA VERİ SETİ
    --------------------------------------------------
    SELECT
        l.Id AS LeadId,
        l.LeadCode,
        l.CreatedAt,
        l.CreatedBy,
        l.EstimatedDate,
        l.IsReserved,
        l.ProductId,
        l.SalesPersonKUserId,

        COALESCE(
            l.StoreId,
            creatorUser.StoreId
        ) AS EffectiveStoreId,

        p.ProductCode,
        p.ProductName,
        p.Brand,
        p.CategoryName,
        p.Referance,
        p.Dial,
        p.Bracelet,

        --------------------------------------------------
        -- KATEGORİ SEVİYESİ
        --------------------------------------------------
        CASE
            WHEN LTRIM(RTRIM(ISNULL(p.CategoryName, '')))
                 LIKE '%1%'
            THEN 1

            WHEN LTRIM(RTRIM(ISNULL(p.CategoryName, '')))
                 LIKE '%2%'
            THEN 2

            WHEN LTRIM(RTRIM(ISNULL(p.CategoryName, '')))
                 LIKE '%3%'
            THEN 3

            ELSE 0
        END AS CategoryLevel,

        cu.Name AS CustomerName,
        cu.LastName AS CustomerLastName,
        cu.CityName,
        cu.DistrictName,
        cu.CountryName,
        cu.Info AS CustomerInfo,
        cu.IsShopping,
        cu.Tel,
        cu.Email,

        cr.ContactResourceName,

        ls.Name AS LeadStatusName,

        ns.Name AS NextStepName,

        lp.Name AS ProcessName,
        lp.Code AS ProcessCode,
        lp.StepOrder,

        sp.FirstName AS SalesPersonFirstName,
        sp.LastName AS SalesPersonLastName,

        st.StoreCode,
        st.StoreDesc AS StoreName,

        ar.ReservationId,
        ar.IsApproved AS ReservationIsApproved,
        ar.IsRejected AS ReservationIsRejected,
        ar.ReservationNote,
        ar.ReservedAt,
        ar.ReservedBy,

        --------------------------------------------------
        -- AÇIK REZERVASYON VAR MI
        --------------------------------------------------
        CASE
            WHEN ar.ReservationId IS NOT NULL
             AND ISNULL(ar.IsRejected, 0) = 0
            THEN 1
            ELSE 0
        END AS HasActiveReservation,

        --------------------------------------------------
        -- ONAYLANMIŞ REZERVASYON VAR MI
        --------------------------------------------------
        CASE
            WHEN ar.ReservationId IS NOT NULL
             AND ISNULL(ar.IsApproved, 0) = 1
             AND ISNULL(ar.IsRejected, 0) = 0
            THEN 1
            ELSE 0
        END AS HasApprovedReservation,

        --------------------------------------------------
        -- ONAY BEKLEYEN REZERVASYON VAR MI
        --------------------------------------------------
        CASE
            WHEN ar.ReservationId IS NOT NULL
             AND ISNULL(ar.IsApproved, 0) = 0
             AND ISNULL(ar.IsRejected, 0) = 0
            THEN 1
            ELSE 0
        END AS HasPendingReservation,

        ISNULL(
            reservationUserRole.IsSatisPersoneli,
            0
        ) AS ReservedBySatisPersoneli,

        ISNULL(
            reservationUserRole.IsMagazaMuduru,
            0
        ) AS ReservedByMagazaMuduru,

        ISNULL(
            reservationUserRole.IsUstYonetici,
            0
        ) AS ReservedByUstYonetici

    FROM tmscrq.TMLead l

    LEFT JOIN tmscrq.TMUser creatorUser
        ON creatorUser.KUserID = l.CreatedBy

    LEFT JOIN tmscrq.TMCustomer cu
        ON cu.Id = l.CustomerId

    LEFT JOIN tmscrq.TMProduct p
        ON p.Id = l.ProductId

    LEFT JOIN tmscrq.TMContactResource cr
        ON cr.Id = l.ContactResourceId

    LEFT JOIN tmscrq.TMLeadStatu ls
        ON ls.Id = l.StatuId

    LEFT JOIN tmscrq.TMLeadNextStep ns
        ON ns.Id = l.NextStepId

    LEFT JOIN tmscrq.TMLeadProcess lp
        ON lp.Id = l.ProcessID

    LEFT JOIN dbo.KUser sp
        ON sp.Id = l.SalesPersonKUserId

    LEFT JOIN tmscrq.TMStore st
        ON st.Id = COALESCE(
            l.StoreId,
            creatorUser.StoreId
        )

    LEFT JOIN ActiveReservation ar
        ON ar.LeadId = l.Id

    LEFT JOIN AllUserRoleFlags reservationUserRole
        ON reservationUserRole.KUser_Id = ar.ReservedBy
),
StockTotals AS
(
    --------------------------------------------------
    -- MAĞAZA VE ÜRÜN BAZLI TOPLAM STOK
    --------------------------------------------------
    SELECT
        st.Id AS StoreId,
        p.Id AS ProductId,

        CAST(
            SUM(
                CAST(
                    ISNULL(i.InventoryQty1, 0)
                    AS DECIMAL(18, 2)
                )
            )
        AS DECIMAL(18, 2)) AS ToplamStok

    FROM tmscrq.TMItemInventory i

    INNER JOIN tmscrq.TMProduct p
        ON UPPER(LTRIM(RTRIM(p.ProductCode)))
         = UPPER(LTRIM(RTRIM(i.ProductCode)))

    INNER JOIN tmscrq.TMStore st
        ON UPPER(LTRIM(RTRIM(st.StoreCode)))
         = UPPER(LTRIM(RTRIM(i.StoreCode)))

    WHERE i.OfficeDescription IS NOT NULL
      AND i.OfficeDescription NOT IN
      (
          N'Teknik Servis Ofis'
      )

    GROUP BY
        st.Id,
        p.Id

    HAVING
        SUM(ISNULL(i.InventoryQty1, 0)) > 0
),
ReservedStockCounts AS
(
    --------------------------------------------------
    -- DELIVERY_PENDING SÜRECİNDEKİ
    -- AKTİF REZERVASYON SAYISI
    --------------------------------------------------
    SELECT
        COALESCE(
            l.StoreId,
            creatorUser.StoreId
        ) AS StoreId,

        l.ProductId,

        COUNT(
            DISTINCT r.LeadId
        ) AS RezerveStok

    FROM tmscrq.TMLeadReservation r

    INNER JOIN tmscrq.TMLead l
        ON l.Id = r.LeadId

    INNER JOIN tmscrq.TMLeadProcess lp
        ON lp.Id = l.ProcessID

    LEFT JOIN tmscrq.TMUser creatorUser
        ON creatorUser.KUserID = l.CreatedBy

    WHERE r.IsActive = 1
      AND lp.Code = 'DELIVERY_PENDING'

    GROUP BY
        COALESCE(
            l.StoreId,
            creatorUser.StoreId
        ),
        l.ProductId
),
PendingReservationCounts AS
(
    --------------------------------------------------
    -- APPROVED SÜRECİNDEKİ
    -- ONAY BEKLEYEN REZERV TALEBİ SAYISI
    --------------------------------------------------
    SELECT
        COALESCE(
            l.StoreId,
            creatorUser.StoreId
        ) AS StoreId,

        l.ProductId,

        COUNT(
            DISTINCT r.LeadId
        ) AS BekleyenRezervTalebi

    FROM tmscrq.TMLeadReservation r

    INNER JOIN tmscrq.TMLead l
        ON l.Id = r.LeadId

    INNER JOIN tmscrq.TMLeadProcess lp
        ON lp.Id = l.ProcessID

    LEFT JOIN tmscrq.TMUser creatorUser
        ON creatorUser.KUserID = l.CreatedBy

    WHERE r.IsActive = 1
      AND ISNULL(r.IsApproved, 0) = 0
      AND ISNULL(r.IsRejected, 0) = 0
      AND lp.Code = 'APPROVED'

    GROUP BY
        COALESCE(
            l.StoreId,
            creatorUser.StoreId
        ),
        l.ProductId
),
StockStatus AS
(
    --------------------------------------------------
    -- STOK VE REZERV KAPASİTESİ
    --------------------------------------------------
    SELECT
        stock.StoreId,
        stock.ProductId,
        stock.ToplamStok,

        ISNULL(
            reserved.RezerveStok,
            0
        ) AS RezerveStok,

        ISNULL(
            pending.BekleyenRezervTalebi,
            0
        ) AS BekleyenRezervTalebi,

        CASE
            WHEN
                stock.ToplamStok
                - ISNULL(reserved.RezerveStok, 0) > 0
            THEN
                stock.ToplamStok
                - ISNULL(reserved.RezerveStok, 0)
            ELSE 0
        END AS MusaitStok,

        CASE
            WHEN
                stock.ToplamStok
                - ISNULL(reserved.RezerveStok, 0)
                - ISNULL(pending.BekleyenRezervTalebi, 0) > 0
            THEN
                stock.ToplamStok
                - ISNULL(reserved.RezerveStok, 0)
                - ISNULL(pending.BekleyenRezervTalebi, 0)
            ELSE 0
        END AS YeniRezervTalebiKapasitesi

    FROM StockTotals stock

    LEFT JOIN ReservedStockCounts reserved
        ON reserved.StoreId = stock.StoreId
       AND reserved.ProductId = stock.ProductId

    LEFT JOIN PendingReservationCounts pending
        ON pending.StoreId = stock.StoreId
       AND pending.ProductId = stock.ProductId
),
FifoQueue AS
(
    --------------------------------------------------
    -- MAĞAZA VE ÜRÜN BAZLI FIFO SIRASI
    --
    -- APPROVED SÜRECİNDEKİ LEADLER
    -- EN ESKİDEN EN YENİYE SIRALANIR
    --------------------------------------------------
    SELECT
        lb.LeadId,

        ROW_NUMBER() OVER
        (
            PARTITION BY
                lb.EffectiveStoreId,
                lb.ProductId
            ORDER BY
                lb.CreatedAt ASC,
                lb.LeadCode ASC,
                lb.LeadId ASC
        ) AS FifoSirasi

    FROM LeadBase lb

    WHERE lb.ProcessCode = 'APPROVED'
      AND lb.HasApprovedReservation = 0
      AND lb.EffectiveStoreId IS NOT NULL
      AND lb.ProductId IS NOT NULL
      AND lb.CategoryLevel IN
      (
          1,
          2,
          3
      )
),
PriorityTaskKeys AS
(
    --------------------------------------------------
    -- 1. REZERV EDİLMEYİ BEKLEYEN
    --------------------------------------------------
    SELECT
        lb.LeadId,
        lb.ReservationId,

        N'Rezerv Edilmeyi Bekleyen'
            AS GorevTipi,

        CASE
            --------------------------------------------------
            -- ÜST YÖNETİCİ TÜM KATEGORİLERDE
            -- DOĞRUDAN REZERV YAPAR
            --------------------------------------------------
            WHEN currentRole.IsUstYonetici = 1
            THEN N'Doğrudan Rezerv Yap'

            --------------------------------------------------
            -- MAĞAZA MÜDÜRÜ KATEGORİ 1 İÇİN
            -- DOĞRUDAN REZERV YAPAR
            --------------------------------------------------
            WHEN currentRole.IsMagazaMuduru = 1
             AND lb.CategoryLevel = 1
            THEN N'Doğrudan Rezerv Yap'

            --------------------------------------------------
            -- SATIŞ PERSONELİ VE MAĞAZA MÜDÜRÜ
            -- DİĞER DURUMLARDA REZERV TALEBİ GÖNDERİR
            --------------------------------------------------
            ELSE N'Rezerv Talebi Gönder'
        END AS GorevAksiyonu,

        CASE
            WHEN currentRole.IsUstYonetici = 1
            THEN 'DIRECT_RESERVE'

            WHEN currentRole.IsMagazaMuduru = 1
             AND lb.CategoryLevel = 1
            THEN 'DIRECT_RESERVE'

            ELSE 'SEND_RESERVATION_REQUEST'
        END AS AksiyonKodu,

        3 AS GorevOnceligi,

        lb.CreatedAt AS GorevTarihi,

        fifo.FifoSirasi,

        stock.ToplamStok,
        stock.RezerveStok,
        stock.BekleyenRezervTalebi,
        stock.MusaitStok,
        stock.YeniRezervTalebiKapasitesi

    FROM LeadBase lb

    CROSS JOIN CurrentUserRoles currentRole

    INNER JOIN FifoQueue fifo
        ON fifo.LeadId = lb.LeadId

    INNER JOIN StockStatus stock
        ON stock.StoreId = lb.EffectiveStoreId
       AND stock.ProductId = lb.ProductId

    WHERE lb.ProcessCode = 'APPROVED'

      --------------------------------------------------
      -- DAHA ÖNCE AÇIK REZERV TALEBİ OLMAMALI
      --------------------------------------------------
      AND lb.HasActiveReservation = 0

      --------------------------------------------------
      -- KİŞİSEL GÖREV
      --
      -- SATIŞ DANIŞMANI VE MAĞAZA MÜDÜRÜ
      -- SADECE KENDİ LEADLERİ İÇİN
      -- REZERV İŞLEMİ YAPAR
      --------------------------------------------------
      AND
      (
          lb.SalesPersonKUserId = @UserId
          OR lb.CreatedBy = @UserId
      )

      --------------------------------------------------
      -- STOK BULUNMALI
      --------------------------------------------------
      AND stock.ToplamStok > 0
      AND stock.YeniRezervTalebiKapasitesi > 0

      --------------------------------------------------
      -- FIFO SIRASI KAPASİTE İÇİNDE BULUNMALI
      --------------------------------------------------
      AND fifo.FifoSirasi <= stock.YeniRezervTalebiKapasitesi

      --------------------------------------------------
      -- ROL VE MAĞAZA YETKİSİ
      --------------------------------------------------
      AND
      (
          currentRole.IsSatisPersoneli = 1

          OR

          (
              currentRole.IsMagazaMuduru = 1

              AND EXISTS
              (
                  SELECT 1
                  FROM UserStores userStore
                  WHERE userStore.StoreId = lb.EffectiveStoreId
              )
          )

          OR currentRole.IsUstYonetici = 1
      )

    UNION ALL

    --------------------------------------------------
    -- 2. REZERV ONAYI BEKLEYEN
    --------------------------------------------------
    SELECT
        lb.LeadId,
        lb.ReservationId,

        N'Rezerv Onayı Bekleyen'
            AS GorevTipi,

        N'Rezerv Talebini Onayla'
            AS GorevAksiyonu,

        'APPROVE_RESERVATION'
            AS AksiyonKodu,

        1 AS GorevOnceligi,

        COALESCE(
            lb.ReservedAt,
            lb.CreatedAt
        ) AS GorevTarihi,

        fifo.FifoSirasi,

        stock.ToplamStok,
        stock.RezerveStok,
        stock.BekleyenRezervTalebi,
        stock.MusaitStok,
        stock.YeniRezervTalebiKapasitesi

    FROM LeadBase lb

    CROSS JOIN CurrentUserRoles currentRole

    INNER JOIN FifoQueue fifo
        ON fifo.LeadId = lb.LeadId

    INNER JOIN StockStatus stock
        ON stock.StoreId = lb.EffectiveStoreId
       AND stock.ProductId = lb.ProductId

    WHERE lb.ProcessCode = 'APPROVED'

      --------------------------------------------------
      -- AKTİF VE ONAY BEKLEYEN REZERV TALEBİ
      --------------------------------------------------
      AND lb.HasPendingReservation = 1
      AND lb.ReservedBy IS NOT NULL

      --------------------------------------------------
      -- KULLANICI KENDİ TALEBİNİ ONAYLAYAMAZ
      --------------------------------------------------
      AND lb.ReservedBy <> @UserId

      --------------------------------------------------
      -- ONAYLANABİLECEK STOK BULUNMALI
      --------------------------------------------------
      AND stock.YeniRezervTalebiKapasitesi > 0

      --------------------------------------------------
      -- FIFO SIRASI KAPASİTE İÇİNDE OLMALI
      --------------------------------------------------
      AND fifo.FifoSirasi <= stock.YeniRezervTalebiKapasitesi

      AND
      (
          --------------------------------------------------
          -- MAĞAZA MÜDÜRÜ
          --
          -- KENDİ MAĞAZASINDAKİ TÜM SATIŞ
          -- PERSONELLERİNİN KATEGORİ 1
          -- REZERV TALEPLERİNİ ONAYLAR
          --------------------------------------------------
          (
              currentRole.IsMagazaMuduru = 1

              AND lb.CategoryLevel = 1

              AND lb.ReservedBySatisPersoneli = 1
              AND lb.ReservedByMagazaMuduru = 0

              AND EXISTS
              (
                  SELECT 1
                  FROM UserStores userStore
                  WHERE userStore.StoreId = lb.EffectiveStoreId
              )
          )

          OR

          --------------------------------------------------
          -- ÜST YÖNETİCİ
          --
          -- TÜM MAĞAZALARDAKİ KATEGORİ 2 VE
          -- KATEGORİ 3 REZERV TALEPLERİNİ ONAYLAR
          --------------------------------------------------
          (
              currentRole.IsUstYonetici = 1

              AND lb.CategoryLevel IN
              (
                  2,
                  3
              )

              AND
              (
                  lb.ReservedBySatisPersoneli = 1
                  OR lb.ReservedByMagazaMuduru = 1
              )
          )
      )

    UNION ALL

    --------------------------------------------------
    -- 3. SATIŞA HAZIR
    --------------------------------------------------
    SELECT
        lb.LeadId,
        lb.ReservationId,

        N'Satışa Hazır'
            AS GorevTipi,

        N'Teslim ve Satış İşlemini Tamamla'
            AS GorevAksiyonu,

        'COMPLETE_SALE'
            AS AksiyonKodu,

        2 AS GorevOnceligi,

        COALESCE(
            lb.ReservedAt,
            lb.CreatedAt
        ) AS GorevTarihi,

        CAST(NULL AS BIGINT)
            AS FifoSirasi,

        ISNULL(
            stock.ToplamStok,
            0
        ) AS ToplamStok,

        ISNULL(
            stock.RezerveStok,
            0
        ) AS RezerveStok,

        ISNULL(
            stock.BekleyenRezervTalebi,
            0
        ) AS BekleyenRezervTalebi,

        ISNULL(
            stock.MusaitStok,
            0
        ) AS MusaitStok,

        ISNULL(
            stock.YeniRezervTalebiKapasitesi,
            0
        ) AS YeniRezervTalebiKapasitesi

    FROM LeadBase lb

    CROSS JOIN CurrentUserRoles currentRole

    LEFT JOIN StockStatus stock
        ON stock.StoreId = lb.EffectiveStoreId
       AND stock.ProductId = lb.ProductId

    WHERE lb.ProcessCode = 'DELIVERY_PENDING'

      --------------------------------------------------
      -- SATIŞA HAZIR KAYIT KİŞİSEL GÖREVDİR
      --------------------------------------------------
      AND
      (
          lb.SalesPersonKUserId = @UserId
          OR lb.CreatedBy = @UserId
      )

      --------------------------------------------------
      -- ROL VE MAĞAZA YETKİSİ
      --------------------------------------------------
      AND
      (
          currentRole.IsSatisPersoneli = 1

          OR

          (
              currentRole.IsMagazaMuduru = 1

              AND EXISTS
              (
                  SELECT 1
                  FROM UserStores userStore
                  WHERE userStore.StoreId = lb.EffectiveStoreId
              )
          )

          OR currentRole.IsUstYonetici = 1
      )
)

--------------------------------------------------
-- SONUÇ (TOP 5 KAYIT, SAYFALAMA KALDIRILDI)
--------------------------------------------------
SELECT
    --------------------------------------------------
    -- GÖREV
    --------------------------------------------------
    task.GorevTipi,
    task.GorevAksiyonu,
    task.AksiyonKodu,
    task.GorevOnceligi,
    task.FifoSirasi,

    --------------------------------------------------
    -- AKSİYON GÖRÜNÜRLÜKLERİ
    --------------------------------------------------
    CAST(
        CASE
            WHEN task.AksiyonKodu = 'DIRECT_RESERVE'
            THEN 1
            ELSE 0
        END
    AS BIT) AS DogrudanRezervShow,

    CAST(
        CASE
            WHEN task.AksiyonKodu = 'SEND_RESERVATION_REQUEST'
            THEN 1
            ELSE 0
        END
    AS BIT) AS RezervTalebiGonderShow,

    CAST(
        CASE
            WHEN task.AksiyonKodu = 'APPROVE_RESERVATION'
            THEN 1
            ELSE 0
        END
    AS BIT) AS RezervOnaylaShow,

    CAST(
        CASE
            WHEN task.AksiyonKodu = 'COMPLETE_SALE'
            THEN 1
            ELSE 0
        END
    AS BIT) AS SatisYapShow,

    --------------------------------------------------
    -- STOK
    --------------------------------------------------
    task.ToplamStok,
    task.RezerveStok,
    task.BekleyenRezervTalebi,
    task.MusaitStok,
    task.YeniRezervTalebiKapasitesi,

    --------------------------------------------------
    -- REZERVASYON
    --------------------------------------------------
    task.ReservationId,
    lead.ReservedBy,
    lead.ReservedAt,

    ISNULL(
        NULLIF(
            LTRIM(RTRIM(lead.ReservationNote)),
            ''
        ),
        '-'
    ) AS ReservationNote,

    CASE
        WHEN lead.HasApprovedReservation = 1
        THEN N'Evet'

        WHEN lead.HasPendingReservation = 1
        THEN N'Onay Bekliyor'

        ELSE N'Hayır'
    END AS RezerveDurumu,

    --------------------------------------------------
    -- LEAD
    --------------------------------------------------
    lead.LeadId,
    lead.ProductId,
    lead.EffectiveStoreId AS StoreId,
    lead.SalesPersonKUserId,
    lead.CreatedBy,

    ISNULL(
        NULLIF(
            LTRIM(RTRIM(lead.LeadCode)),
            ''
        ),
        '-'
    ) AS LeadNumarasi,

    CONVERT(
        VARCHAR(10),
        lead.CreatedAt,
        103
    ) AS TalepTarihi,

    --------------------------------------------------
    -- ÜRÜN
    --------------------------------------------------
    ISNULL(
        NULLIF(
            LTRIM(RTRIM(lead.ProductName)),
            ''
        ),
        '-'
    ) AS ProductName,

    ISNULL(
        NULLIF(
            LTRIM(RTRIM(lead.Brand)),
            ''
        ),
        '-'
    ) AS Brand,

    ISNULL(
        NULLIF(
            LTRIM(RTRIM(lead.CategoryName)),
            ''
        ),
        '-'
    ) AS CategoryName,

    lead.CategoryLevel,

    ISNULL(
        NULLIF(
            LTRIM(RTRIM(lead.ProductCode)),
            ''
        ),
        '-'
    ) AS RefCode,

    ISNULL(
        NULLIF(
            LTRIM(RTRIM(lead.Referance)),
            ''
        ),
        '-'
    ) AS Referans,

    ISNULL(
        NULLIF(
            LTRIM(RTRIM(lead.Dial)),
            ''
        ),
        '-'
    ) AS Kadran,

    ISNULL(
        NULLIF(
            LTRIM(RTRIM(lead.Bracelet)),
            ''
        ),
        '-'
    ) AS Bilezik,

    --------------------------------------------------
    -- MÜŞTERİ
    --------------------------------------------------
    ISNULL(
        NULLIF(
            LTRIM(
                RTRIM(
                    ISNULL(lead.CustomerName, '')
                    + ' '
                    + ISNULL(lead.CustomerLastName, '')
                )
            ),
            ''
        ),
        '-'
    ) AS Musteri,

    ISNULL(
        NULLIF(
            LTRIM(RTRIM(lead.CityName)),
            ''
        ),
        '-'
    ) AS Lokasyon,

    ISNULL(
        NULLIF(
            LTRIM(RTRIM(lead.DistrictName)),
            ''
        ),
        '-'
    ) AS Ilce,

    ISNULL(
        NULLIF(
            LTRIM(RTRIM(lead.CountryName)),
            ''
        ),
        '-'
    ) AS Ulke,

    ISNULL(
        NULLIF(
            LTRIM(RTRIM(lead.CustomerInfo)),
            ''
        ),
        '-'
    ) AS MusteriInfo,

    CASE
        WHEN lead.IsShopping = 1
        THEN N'Evet'

        WHEN lead.IsShopping = 0
        THEN N'Hayır'

        ELSE '-'
    END AS AlisverisiVarMi,

    ISNULL(
        NULLIF(
            LTRIM(RTRIM(lead.Tel)),
            ''
        ),
        '-'
    ) AS IrtibatNumarasi,

    ISNULL(
        NULLIF(
            LTRIM(RTRIM(lead.Email)),
            ''
        ),
        '-'
    ) AS EmailAdresi,

    ISNULL(
        NULLIF(
            LTRIM(RTRIM(lead.ContactResourceName)),
            ''
        ),
        '-'
    ) AS IletisimKaynagi,

    --------------------------------------------------
    -- SATIŞ DANIŞMANI
    --------------------------------------------------
    ISNULL(
        NULLIF(
            LTRIM(
                RTRIM(
                    ISNULL(lead.SalesPersonFirstName, '')
                    + ' '
                    + ISNULL(lead.SalesPersonLastName, '')
                )
            ),
            ''
        ),
        '-'
    ) AS SatisDanismani,

    --------------------------------------------------
    -- TERMİN
    --------------------------------------------------
    ISNULL(
        CASE
            WHEN lead.EstimatedDate IS NOT NULL
            THEN
                CAST(
                    YEAR(lead.EstimatedDate)
                    AS VARCHAR(4)
                )
                + ' '
                + DATENAME(
                    MONTH,
                    lead.EstimatedDate
                )
            ELSE NULL
        END,
        '-'
    ) AS TerminTarihi,

    --------------------------------------------------
    -- TAKİP VE SÜREÇ
    --------------------------------------------------
    ISNULL(
        NULLIF(
            LTRIM(RTRIM(lead.LeadStatusName)),
            ''
        ),
        '-'
    ) AS LeadDurumu,

    ISNULL(
        NULLIF(
            LTRIM(RTRIM(lead.NextStepName)),
            ''
        ),
        '-'
    ) AS SonrakiAdim,

    ISNULL(
        NULLIF(
            LTRIM(RTRIM(lead.ProcessName)),
            ''
        ),
        '-'
    ) AS ProcessName,

    ISNULL(
        NULLIF(
            LTRIM(RTRIM(lead.ProcessCode)),
            ''
        ),
        '-'
    ) AS ProcessCode,

    lead.StepOrder,

    CAST(
        ISNULL(
            lead.StepOrder,
            0
        )
    AS INT) AS SelectedStepOrder,

    --------------------------------------------------
    -- MAĞAZA
    --------------------------------------------------
    ISNULL(
        NULLIF(
            LTRIM(RTRIM(lead.StoreCode)),
            ''
        ),
        '-'
    ) AS StoreCode,

    ISNULL(
        NULLIF(
            LTRIM(RTRIM(lead.StoreName)),
            ''
        ),
        '-'
    ) AS StoreName

FROM PriorityTaskKeys task

INNER JOIN LeadBase lead
    ON lead.LeadId = task.LeadId

WHERE
(
    @TaskFilter = 0

    OR (@TaskFilter = 1 AND task.GorevOnceligi = 3)

    OR (@TaskFilter = 2 AND task.GorevOnceligi = 2)

    OR (@TaskFilter = 3 AND task.GorevOnceligi = 1)
)

ORDER BY
    --------------------------------------------------
    -- 1. REZERV ONAYI
    -- 2. SATIŞA HAZIR
    -- 3. REZERV EDİLMEYİ BEKLEYEN
    --------------------------------------------------
    task.GorevOnceligi ASC,

    --------------------------------------------------
    -- ESKİ GÖREVLER ÖNCE
    --------------------------------------------------
    task.GorevTarihi ASC,

    lead.LeadCode ASC;", new string[] { "GorevTipi", "GorevAksiyonu", "AksiyonKodu", "GorevOnceligi", "FifoSirasi", "DogrudanRezervShow", "RezervTalebiGonderShow", "RezervOnaylaShow", "SatisYapShow", "ToplamStok", "RezerveStok", "BekleyenRezervTalebi", "MusaitStok", "YeniRezervTalebiKapasitesi", "ReservationId", "ReservedBy", "ReservedAt", "ReservationNote", "RezerveDurumu", "LeadId", "ProductId", "StoreId", "SalesPersonKUserId", "CreatedBy", "LeadNumarasi", "TalepTarihi", "ProductName", "Brand", "CategoryName", "CategoryLevel", "RefCode", "Referans", "Kadran", "Bilezik", "Musteri", "Lokasyon", "Ilce", "Ulke", "MusteriInfo", "AlisverisiVarMi", "IrtibatNumarasi", "EmailAdresi", "IletisimKaynagi", "SatisDanismani", "TerminTarihi", "LeadDurumu", "SonrakiAdim", "ProcessName", "ProcessCode", "StepOrder", "SelectedStepOrder", "StoreCode", "StoreName" }, prms_TMSalesPersonDashBoardTaskList_0.ToArray());
            ;


            return Ok(result);
        }


        [HttpPost, Route("DashBoardTempComponent_56981_onClick")]
        public IActionResult DashBoardTempComponent_56981_onClick(DashBoardTempComponent_56981_onClick_Request request)
        {

            KProviderManager.Authorization.IsAuthorizedForRoles(appId, appName, screenId, screenName, new List<string> { $"b4bfd39c-ac02-f442-c899-7a2374a45b47", "70de6cfc-6087-6059-59b4-0b5a8527af6b", "TimesSatisPersoneli", "TimesMagazaMuduru" });

            var result = new DashBoardTempComponent_56981_onClick_Response();

            var prms_TM_TopManagerDashboardLeadList_0 = new List<kSqlParameter>();
            prms_TM_TopManagerDashboardLeadList_0.Add(new kSqlParameter() { Name = "UserId", Value = Kuika.Common.KContext.CurrentUser?.Id });
            prms_TM_TopManagerDashboardLeadList_0.Add(new kSqlParameter() { Name = "MusteriAdi", Value = request.MusteriAdi_0 });
            prms_TM_TopManagerDashboardLeadList_0.Add(new kSqlParameter() { Name = "ProductName", Value = request.ProductName_0 });
            prms_TM_TopManagerDashboardLeadList_0.Add(new kSqlParameter() { Name = "LeadCode", Value = (null as object) });
            prms_TM_TopManagerDashboardLeadList_0.Add(new kSqlParameter() { Name = "Tel", Value = (null as object) });
            prms_TM_TopManagerDashboardLeadList_0.Add(new kSqlParameter() { Name = "CategoryName", Value = request.CategoryName_0 });
            prms_TM_TopManagerDashboardLeadList_0.Add(new kSqlParameter() { Name = "StoreIds", Value = request.StoreIds_0 });
            prms_TM_TopManagerDashboardLeadList_0.Add(new kSqlParameter() { Name = "SatisDanismaniIds", Value = request.SatisDanismaniIds_0 });
            prms_TM_TopManagerDashboardLeadList_0.Add(new kSqlParameter() { Name = "ProcessCode", Value = request.ProcessCode_0 });
            prms_TM_TopManagerDashboardLeadList_0.Add(new kSqlParameter() { Name = "StepOrder", Value = "0".ConvertToType<Int32>() });
            prms_TM_TopManagerDashboardLeadList_0.Add(new kSqlParameter() { Name = "StartDate", Value = request.StartDate_0 });
            prms_TM_TopManagerDashboardLeadList_0.Add(new kSqlParameter() { Name = "EndDate", Value = request.EndDate_0 });
            using var auditTM_TopManagerDashboardLeadList_0 = ActionAuditScope.Begin("b4151622-df72-5766-1de3-14f4c1b44156", "TM_TopManagerDashboardLeadList", applicationName: "wbTimesCRM", screenOrEndpointName: "DashBoardTemp");
            result.TM_TopManagerDashboardLeadList = KPersister.Fetch(KContext.GetConnectionString(), @"SET LANGUAGE Turkish;


SELECT
    CASE 
        WHEN EXISTS (
            SELECT 1 
            FROM tmscrq.TMLeadReservation r
            WHERE r.LeadId = l.Id
              AND r.IsActive = 1
              AND r.IsApproved = 1
        ) THEN N'Evet'
        WHEN EXISTS (
            SELECT 1 
            FROM tmscrq.TMLeadReservation r
            WHERE r.LeadId = l.Id
              AND r.IsActive = 1
              AND ISNULL(r.IsApproved,0) = 0
        ) THEN N'Onay Bekliyor'
        ELSE N'Hayır'
    END AS RezerveDurumu,
    l.Id AS LeadId,
    l.IsReserved,
    ISNULL(NULLIF(LTRIM(RTRIM(l.LeadCode)), ''), '-') AS LeadNumarasi,
    CONVERT(varchar(10), l.CreatedAt, 103) AS TalepTarihi,

    p.Id AS ProductId,
    ISNULL(NULLIF(LTRIM(RTRIM(p.ProductName)), ''), '-') AS ProductName,
    ISNULL(NULLIF(LTRIM(RTRIM(p.Bracelet)), ''), '-') AS Bilezik,
    ISNULL(NULLIF(LTRIM(RTRIM(p.Brand)), ''), '-') AS Brand,
    ISNULL(NULLIF(LTRIM(RTRIM(p.Dial)), ''), '-') AS Kadran,
    ISNULL(NULLIF(LTRIM(RTRIM(p.ProductCode)), ''), '-') AS RefCode,
    ISNULL(NULLIF(LTRIM(RTRIM(p.Referance)), ''), '-') AS Referans,

    ISNULL(
        NULLIF(
            LTRIM(RTRIM(ISNULL(cu.Name, '') + ' ' + ISNULL(cu.LastName, '')))
        , '')
    , '-') AS Musteri,

    ISNULL(NULLIF(LTRIM(RTRIM(cu.CityName)), ''), '-') AS Lokasyon,
    ISNULL(NULLIF(LTRIM(RTRIM(cu.DistrictName)), ''), '-') AS Ilce,
    ISNULL(NULLIF(LTRIM(RTRIM(cu.CountryName)), ''), '-') AS Ulke,
    ISNULL(NULLIF(LTRIM(RTRIM(cu.Info)), ''), '-') AS MusteriInfo,

    CASE
        WHEN cu.IsShopping = 1 THEN N'Evet'
        WHEN cu.IsShopping = 0 THEN N'Hayır'
        ELSE '-'
    END AS AlisverisiVarMi,

    ISNULL(NULLIF(LTRIM(RTRIM(cu.Tel)), ''), '-') AS IrtibatNumarasi,
    ISNULL(NULLIF(LTRIM(RTRIM(cu.Email)), ''), '-') AS EmailAdresi,

    ISNULL(NULLIF(LTRIM(RTRIM(cr.ContactResourceName)), ''), '-') AS IletisimKaynagi,

    ISNULL(NULLIF(LTRIM(RTRIM(p.CategoryName)), ''), '-') AS CategoryName,
    '-' AS CategoryCode,

    ISNULL(NULLIF(LTRIM(RTRIM(ls.Name)), ''), '-') AS LeadDurumu,
    ISNULL(NULLIF(LTRIM(RTRIM(ns.Name)), ''), '-') AS SonrakiAdim,

    ISNULL(NULLIF(LTRIM(RTRIM(lp.Name)), ''), '-') AS ProcessName,
    ISNULL(NULLIF(LTRIM(RTRIM(lp.Code)), ''), '-') AS ProcessCode,
    lp.StepOrder,
    
    CAST(ISNULL(@StepOrder, lp.StepOrder) AS INT) AS SelectedStepOrder,

    ISNULL(
        CASE
            WHEN l.EstimatedDate IS NOT NULL
            THEN CAST(YEAR(l.EstimatedDate) AS VARCHAR(4)) + ' ' + DATENAME(MONTH, l.EstimatedDate)
            ELSE NULL
        END,
        '-'
    ) AS TerminTarihi,

    ISNULL(
        NULLIF(
            LTRIM(RTRIM(ISNULL(sp.FirstName, '') + ' ' + ISNULL(sp.LastName, '')))
        , '')
    , '-') AS SatisDanismani,

    ISNULL(NULLIF(LTRIM(RTRIM(st.StoreDesc)), ''), '-') AS StoreName

FROM tmscrq.TMLead l
LEFT JOIN tmscrq.TMLeadStatu ls ON ls.Id = l.StatuId
LEFT JOIN tmscrq.TMCustomer cu ON cu.Id = l.CustomerId
LEFT JOIN tmscrq.TMProduct p ON p.Id = l.ProductId
LEFT JOIN tmscrq.TMContactResource cr ON cr.Id = l.ContactResourceId
LEFT JOIN dbo.KUser sp ON sp.Id = l.SalesPersonKUserId
LEFT JOIN tmscrq.TMStore st ON st.Id = l.StoreId
LEFT JOIN tmscrq.TMLeadProcess lp ON lp.Id = l.ProcessID
LEFT JOIN tmscrq.TMLeadNextStep ns ON ns.Id = l.NextStepId

WHERE
-- Yetkilendirme
(
    -- Yönetici / Üst Yönetici: Tüm lead'ler
    EXISTS (
        SELECT 1
        FROM dbo.KUserRole ur
        INNER JOIN dbo.KRole r ON r.Id = ur.KRole_Id
        WHERE ur.KUser_Id = @UserId
          AND ur.IsDeleted = 0
          AND r.IsDeleted = 0
          AND r.Name IN ('TimesYonetici', 'TimesUstYonetici')
    )

    OR

    -- Mağaza Müdürü: Kendi mağazasındaki tüm lead'ler
    (
        EXISTS (
            SELECT 1
            FROM dbo.KUserRole ur
            INNER JOIN dbo.KRole r ON r.Id = ur.KRole_Id
            WHERE ur.KUser_Id = @UserId
              AND ur.IsDeleted = 0
              AND r.IsDeleted = 0
              AND r.Name = 'TimesMagazaMuduru'
        )
        AND l.StoreId =
        (
            SELECT TOP 1 tu.StoreID
            FROM tmscrq.TMUser tu
            WHERE tu.KUserID = @UserId
        )
    )

    OR

    -- Satış Personeli: Sadece kendi açtığı lead'ler
    (
        EXISTS (
            SELECT 1
            FROM dbo.KUserRole ur
            INNER JOIN dbo.KRole r ON r.Id = ur.KRole_Id
            WHERE ur.KUser_Id = @UserId
              AND ur.IsDeleted = 0
              AND r.IsDeleted = 0
              AND r.Name = 'TimesSatisPersoneli'
        )
        AND l.SalesPersonKUserId = @UserId
    )
)

-- Müşteri Adı
AND
(
    @MusteriAdi IS NULL
    OR LTRIM(RTRIM(@MusteriAdi)) = ''
    OR UPPER(LTRIM(RTRIM(ISNULL(cu.Name,'') + ' ' + ISNULL(cu.LastName,''))))
       LIKE '%' + UPPER(LTRIM(RTRIM(@MusteriAdi))) + '%'
)

-- Ürün Adı
AND
(
    @ProductName IS NULL
    OR LTRIM(RTRIM(@ProductName)) = ''
    OR
    (
        CHARINDEX(',', @ProductName) > 0
        AND ISNULL(LTRIM(RTRIM(p.ProductName)), '') IN
        (
            SELECT LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', '')))
            FROM STRING_SPLIT(CAST(@ProductName AS NVARCHAR(MAX)), ',')
            WHERE LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', ''))) <> ''
        )
    )
    OR
    (
        CHARINDEX(',', @ProductName) = 0
        AND UPPER(ISNULL(LTRIM(RTRIM(p.ProductName)), ''))
            LIKE '%' + UPPER(LTRIM(RTRIM(@ProductName))) + '%'
    )
)

-- Lead Kodu
AND
(
    @LeadCode IS NULL
    OR LTRIM(RTRIM(@LeadCode)) = ''
    OR UPPER(ISNULL(LTRIM(RTRIM(l.LeadCode)), '')) LIKE '%' + UPPER(LTRIM(RTRIM(@LeadCode))) + '%'
)

-- Telefon
AND
(
    @Tel IS NULL
    OR LTRIM(RTRIM(@Tel)) = ''
    OR UPPER(ISNULL(LTRIM(RTRIM(cu.Tel)), '')) LIKE '%' + UPPER(LTRIM(RTRIM(@Tel))) + '%'
)

-- Kategori
AND
(
    @CategoryName IS NULL
    OR LTRIM(RTRIM(@CategoryName)) = ''
    OR UPPER(ISNULL(LTRIM(RTRIM(p.CategoryName)), '')) IN
    (
        SELECT UPPER(LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value,'""',''),'[',''),']',''))))
        FROM STRING_SPLIT(CAST(@CategoryName AS NVARCHAR(MAX)), ',')
        WHERE LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value,'""',''),'[',''),']',''))) <> ''
    )
)

-- Mağaza
AND
(
    @StoreIds IS NULL
    OR LTRIM(RTRIM(@StoreIds)) = ''
    OR EXISTS
    (
        SELECT 1
        FROM STRING_SPLIT(CAST(@StoreIds AS NVARCHAR(MAX)), ',') s
        WHERE l.StoreId = TRY_CONVERT
        (
            uniqueidentifier,
            LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(s.value, '""', ''), '[', ''), ']', '')))
        )
    )
)

-- Satış Danışmanı
AND
(
    @SatisDanismaniIds IS NULL
    OR LTRIM(RTRIM(@SatisDanismaniIds)) = ''
    OR EXISTS
    (
        SELECT 1
        FROM STRING_SPLIT(CAST(@SatisDanismaniIds AS NVARCHAR(MAX)), ',') s
        WHERE l.SalesPersonKUserId = TRY_CONVERT
        (
            uniqueidentifier,
            LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(s.value, '""', ''), '[', ''), ']', '')))
        )
    )
)

-- Süreç Kodu
AND
(
    @ProcessCode IS NULL
    OR LTRIM(RTRIM(@ProcessCode)) = ''
    OR UPPER(ISNULL(LTRIM(RTRIM(lp.Code)), '')) IN
    (
        SELECT UPPER(LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', ''))))
        FROM STRING_SPLIT(CAST(@ProcessCode AS NVARCHAR(MAX)), ',')
        WHERE LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', ''))) <> ''
    )
)

-- StepOrder Filtresi (genişletilmiş, -4 eklendi)
AND
(
    @StepOrder IS NULL
    OR @StepOrder = 0   -- Tümü

    -- Aktif: CREATED, TERMIN_PENDING, PENDING, APPROVED, DELIVERY_PENDING
    OR (@StepOrder = -1 AND lp.Code IN ('CREATED','TERMIN_PENDING','PENDING','APPROVED','DELIVERY_PENDING'))

    -- Bugün oluşturulanlar
    OR (
        @StepOrder = -2 
        AND l.CreatedAt >= CAST(GETDATE() AS DATE) 
        AND l.CreatedAt < DATEADD(day, 1, CAST(GETDATE() AS DATE))
    )

    -- Geciken (Termin Tarihi Geçmiş): EstimatedDate bugünden küçük ve sonuçlanmamış
    OR (
        @StepOrder = -3 
        AND l.EstimatedDate < CAST(GETDATE() AS DATE) 
        AND lp.Code NOT IN ('DELIVERED','CLOSED','CUSTOMER_DECLINED','REJECTED')
    )

    -- Bu ayın terminleri
    OR (
        @StepOrder = -4 
        AND l.EstimatedDate >= DATEFROMPARTS(YEAR(GETDATE()), MONTH(GETDATE()), 1)
        AND l.EstimatedDate < DATEADD(MONTH, 1, DATEFROMPARTS(YEAR(GETDATE()), MONTH(GETDATE()), 1))
    )

    -- Rezerv onay bekleyen
    OR (
        @StepOrder = 10 
        AND EXISTS (
            SELECT 1 
            FROM tmscrq.TMLeadReservation r 
            WHERE r.LeadId = l.Id 
              AND r.IsActive = 1 
              AND ISNULL(r.IsApproved,0) = 0
        )
    )

    -- Diğer pozitif StepOrder değerleri
    OR (
        @StepOrder NOT IN (0, -1, -2, -3, -4, 10) 
        AND lp.StepOrder = @StepOrder
    )
)

-- Başlangıç Tarihi
AND
(
    @StartDate IS NULL
    OR LTRIM(RTRIM(@StartDate)) = ''
    OR l.CreatedAt >= CONVERT(date, @StartDate)
)

-- Bitiş Tarihi
AND
(
    @EndDate IS NULL
    OR LTRIM(RTRIM(@EndDate)) = ''
    OR l.CreatedAt < DATEADD(day, 1, CONVERT(date, @EndDate))
)

ORDER BY l.CreatedAt DESC;", new string[] { "RezerveDurumu", "LeadId", "IsReserved", "LeadNumarasi", "TalepTarihi", "ProductId", "ProductName", "Bilezik", "Brand", "Kadran", "RefCode", "Referans", "Musteri", "Lokasyon", "Ilce", "Ulke", "MusteriInfo", "AlisverisiVarMi", "IrtibatNumarasi", "EmailAdresi", "IletisimKaynagi", "CategoryName", "CategoryCode", "LeadDurumu", "SonrakiAdim", "ProcessName", "ProcessCode", "StepOrder", "SelectedStepOrder", "TerminTarihi", "SatisDanismani", "StoreName" }, prms_TM_TopManagerDashboardLeadList_0.ToArray());
            ;


            return Ok(result);
        }


        [HttpPost, Route("DashBoardTempComponent_462456_onClick")]
        public IActionResult DashBoardTempComponent_462456_onClick(DashBoardTempComponent_462456_onClick_Request request)
        {

            KProviderManager.Authorization.IsAuthorizedForRoles(appId, appName, screenId, screenName, new List<string> { $"b4bfd39c-ac02-f442-c899-7a2374a45b47", "70de6cfc-6087-6059-59b4-0b5a8527af6b", "TimesSatisPersoneli", "TimesMagazaMuduru" });

            var result = new DashBoardTempComponent_462456_onClick_Response();

            var prms_TM_TopManagerDashboardLeadList_0 = new List<kSqlParameter>();
            prms_TM_TopManagerDashboardLeadList_0.Add(new kSqlParameter() { Name = "UserId", Value = Kuika.Common.KContext.CurrentUser?.Id });
            prms_TM_TopManagerDashboardLeadList_0.Add(new kSqlParameter() { Name = "MusteriAdi", Value = (null as object) });
            prms_TM_TopManagerDashboardLeadList_0.Add(new kSqlParameter() { Name = "ProductName", Value = (null as object) });
            prms_TM_TopManagerDashboardLeadList_0.Add(new kSqlParameter() { Name = "LeadCode", Value = (null as object) });
            prms_TM_TopManagerDashboardLeadList_0.Add(new kSqlParameter() { Name = "Tel", Value = (null as object) });
            prms_TM_TopManagerDashboardLeadList_0.Add(new kSqlParameter() { Name = "CategoryName", Value = (null as object) });
            prms_TM_TopManagerDashboardLeadList_0.Add(new kSqlParameter() { Name = "StoreIds", Value = (null as object) });
            prms_TM_TopManagerDashboardLeadList_0.Add(new kSqlParameter() { Name = "SatisDanismaniIds", Value = (null as object) });
            prms_TM_TopManagerDashboardLeadList_0.Add(new kSqlParameter() { Name = "ProcessCode", Value = (null as object) });
            prms_TM_TopManagerDashboardLeadList_0.Add(new kSqlParameter() { Name = "StepOrder", Value = "0".ConvertToType<Int32>() });
            prms_TM_TopManagerDashboardLeadList_0.Add(new kSqlParameter() { Name = "StartDate", Value = (null as object) });
            prms_TM_TopManagerDashboardLeadList_0.Add(new kSqlParameter() { Name = "EndDate", Value = (null as object) });
            using var auditTM_TopManagerDashboardLeadList_0 = ActionAuditScope.Begin("2822c995-0870-0525-25a6-24bb4ae631cc", "TM_TopManagerDashboardLeadList", applicationName: "wbTimesCRM", screenOrEndpointName: "DashBoardTemp");
            result.TM_TopManagerDashboardLeadList = KPersister.Fetch(KContext.GetConnectionString(), @"SET LANGUAGE Turkish;


SELECT
    CASE 
        WHEN EXISTS (
            SELECT 1 
            FROM tmscrq.TMLeadReservation r
            WHERE r.LeadId = l.Id
              AND r.IsActive = 1
              AND r.IsApproved = 1
        ) THEN N'Evet'
        WHEN EXISTS (
            SELECT 1 
            FROM tmscrq.TMLeadReservation r
            WHERE r.LeadId = l.Id
              AND r.IsActive = 1
              AND ISNULL(r.IsApproved,0) = 0
        ) THEN N'Onay Bekliyor'
        ELSE N'Hayır'
    END AS RezerveDurumu,
    l.Id AS LeadId,
    l.IsReserved,
    ISNULL(NULLIF(LTRIM(RTRIM(l.LeadCode)), ''), '-') AS LeadNumarasi,
    CONVERT(varchar(10), l.CreatedAt, 103) AS TalepTarihi,

    p.Id AS ProductId,
    ISNULL(NULLIF(LTRIM(RTRIM(p.ProductName)), ''), '-') AS ProductName,
    ISNULL(NULLIF(LTRIM(RTRIM(p.Bracelet)), ''), '-') AS Bilezik,
    ISNULL(NULLIF(LTRIM(RTRIM(p.Brand)), ''), '-') AS Brand,
    ISNULL(NULLIF(LTRIM(RTRIM(p.Dial)), ''), '-') AS Kadran,
    ISNULL(NULLIF(LTRIM(RTRIM(p.ProductCode)), ''), '-') AS RefCode,
    ISNULL(NULLIF(LTRIM(RTRIM(p.Referance)), ''), '-') AS Referans,

    ISNULL(
        NULLIF(
            LTRIM(RTRIM(ISNULL(cu.Name, '') + ' ' + ISNULL(cu.LastName, '')))
        , '')
    , '-') AS Musteri,

    ISNULL(NULLIF(LTRIM(RTRIM(cu.CityName)), ''), '-') AS Lokasyon,
    ISNULL(NULLIF(LTRIM(RTRIM(cu.DistrictName)), ''), '-') AS Ilce,
    ISNULL(NULLIF(LTRIM(RTRIM(cu.CountryName)), ''), '-') AS Ulke,
    ISNULL(NULLIF(LTRIM(RTRIM(cu.Info)), ''), '-') AS MusteriInfo,

    CASE
        WHEN cu.IsShopping = 1 THEN N'Evet'
        WHEN cu.IsShopping = 0 THEN N'Hayır'
        ELSE '-'
    END AS AlisverisiVarMi,

    ISNULL(NULLIF(LTRIM(RTRIM(cu.Tel)), ''), '-') AS IrtibatNumarasi,
    ISNULL(NULLIF(LTRIM(RTRIM(cu.Email)), ''), '-') AS EmailAdresi,

    ISNULL(NULLIF(LTRIM(RTRIM(cr.ContactResourceName)), ''), '-') AS IletisimKaynagi,

    ISNULL(NULLIF(LTRIM(RTRIM(p.CategoryName)), ''), '-') AS CategoryName,
    '-' AS CategoryCode,

    ISNULL(NULLIF(LTRIM(RTRIM(ls.Name)), ''), '-') AS LeadDurumu,
    ISNULL(NULLIF(LTRIM(RTRIM(ns.Name)), ''), '-') AS SonrakiAdim,

    ISNULL(NULLIF(LTRIM(RTRIM(lp.Name)), ''), '-') AS ProcessName,
    ISNULL(NULLIF(LTRIM(RTRIM(lp.Code)), ''), '-') AS ProcessCode,
    lp.StepOrder,
    
    CAST(ISNULL(@StepOrder, lp.StepOrder) AS INT) AS SelectedStepOrder,

    ISNULL(
        CASE
            WHEN l.EstimatedDate IS NOT NULL
            THEN CAST(YEAR(l.EstimatedDate) AS VARCHAR(4)) + ' ' + DATENAME(MONTH, l.EstimatedDate)
            ELSE NULL
        END,
        '-'
    ) AS TerminTarihi,

    ISNULL(
        NULLIF(
            LTRIM(RTRIM(ISNULL(sp.FirstName, '') + ' ' + ISNULL(sp.LastName, '')))
        , '')
    , '-') AS SatisDanismani,

    ISNULL(NULLIF(LTRIM(RTRIM(st.StoreDesc)), ''), '-') AS StoreName

FROM tmscrq.TMLead l
LEFT JOIN tmscrq.TMLeadStatu ls ON ls.Id = l.StatuId
LEFT JOIN tmscrq.TMCustomer cu ON cu.Id = l.CustomerId
LEFT JOIN tmscrq.TMProduct p ON p.Id = l.ProductId
LEFT JOIN tmscrq.TMContactResource cr ON cr.Id = l.ContactResourceId
LEFT JOIN dbo.KUser sp ON sp.Id = l.SalesPersonKUserId
LEFT JOIN tmscrq.TMStore st ON st.Id = l.StoreId
LEFT JOIN tmscrq.TMLeadProcess lp ON lp.Id = l.ProcessID
LEFT JOIN tmscrq.TMLeadNextStep ns ON ns.Id = l.NextStepId

WHERE
-- Yetkilendirme
(
    -- Yönetici / Üst Yönetici: Tüm lead'ler
    EXISTS (
        SELECT 1
        FROM dbo.KUserRole ur
        INNER JOIN dbo.KRole r ON r.Id = ur.KRole_Id
        WHERE ur.KUser_Id = @UserId
          AND ur.IsDeleted = 0
          AND r.IsDeleted = 0
          AND r.Name IN ('TimesYonetici', 'TimesUstYonetici')
    )

    OR

    -- Mağaza Müdürü: Kendi mağazasındaki tüm lead'ler
    (
        EXISTS (
            SELECT 1
            FROM dbo.KUserRole ur
            INNER JOIN dbo.KRole r ON r.Id = ur.KRole_Id
            WHERE ur.KUser_Id = @UserId
              AND ur.IsDeleted = 0
              AND r.IsDeleted = 0
              AND r.Name = 'TimesMagazaMuduru'
        )
        AND l.StoreId =
        (
            SELECT TOP 1 tu.StoreID
            FROM tmscrq.TMUser tu
            WHERE tu.KUserID = @UserId
        )
    )

    OR

    -- Satış Personeli: Sadece kendi açtığı lead'ler
    (
        EXISTS (
            SELECT 1
            FROM dbo.KUserRole ur
            INNER JOIN dbo.KRole r ON r.Id = ur.KRole_Id
            WHERE ur.KUser_Id = @UserId
              AND ur.IsDeleted = 0
              AND r.IsDeleted = 0
              AND r.Name = 'TimesSatisPersoneli'
        )
        AND l.SalesPersonKUserId = @UserId
    )
)

-- Müşteri Adı
AND
(
    @MusteriAdi IS NULL
    OR LTRIM(RTRIM(@MusteriAdi)) = ''
    OR UPPER(LTRIM(RTRIM(ISNULL(cu.Name,'') + ' ' + ISNULL(cu.LastName,''))))
       LIKE '%' + UPPER(LTRIM(RTRIM(@MusteriAdi))) + '%'
)

-- Ürün Adı
AND
(
    @ProductName IS NULL
    OR LTRIM(RTRIM(@ProductName)) = ''
    OR
    (
        CHARINDEX(',', @ProductName) > 0
        AND ISNULL(LTRIM(RTRIM(p.ProductName)), '') IN
        (
            SELECT LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', '')))
            FROM STRING_SPLIT(CAST(@ProductName AS NVARCHAR(MAX)), ',')
            WHERE LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', ''))) <> ''
        )
    )
    OR
    (
        CHARINDEX(',', @ProductName) = 0
        AND UPPER(ISNULL(LTRIM(RTRIM(p.ProductName)), ''))
            LIKE '%' + UPPER(LTRIM(RTRIM(@ProductName))) + '%'
    )
)

-- Lead Kodu
AND
(
    @LeadCode IS NULL
    OR LTRIM(RTRIM(@LeadCode)) = ''
    OR UPPER(ISNULL(LTRIM(RTRIM(l.LeadCode)), '')) LIKE '%' + UPPER(LTRIM(RTRIM(@LeadCode))) + '%'
)

-- Telefon
AND
(
    @Tel IS NULL
    OR LTRIM(RTRIM(@Tel)) = ''
    OR UPPER(ISNULL(LTRIM(RTRIM(cu.Tel)), '')) LIKE '%' + UPPER(LTRIM(RTRIM(@Tel))) + '%'
)

-- Kategori
AND
(
    @CategoryName IS NULL
    OR LTRIM(RTRIM(@CategoryName)) = ''
    OR UPPER(ISNULL(LTRIM(RTRIM(p.CategoryName)), '')) IN
    (
        SELECT UPPER(LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value,'""',''),'[',''),']',''))))
        FROM STRING_SPLIT(CAST(@CategoryName AS NVARCHAR(MAX)), ',')
        WHERE LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value,'""',''),'[',''),']',''))) <> ''
    )
)

-- Mağaza
AND
(
    @StoreIds IS NULL
    OR LTRIM(RTRIM(@StoreIds)) = ''
    OR EXISTS
    (
        SELECT 1
        FROM STRING_SPLIT(CAST(@StoreIds AS NVARCHAR(MAX)), ',') s
        WHERE l.StoreId = TRY_CONVERT
        (
            uniqueidentifier,
            LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(s.value, '""', ''), '[', ''), ']', '')))
        )
    )
)

-- Satış Danışmanı
AND
(
    @SatisDanismaniIds IS NULL
    OR LTRIM(RTRIM(@SatisDanismaniIds)) = ''
    OR EXISTS
    (
        SELECT 1
        FROM STRING_SPLIT(CAST(@SatisDanismaniIds AS NVARCHAR(MAX)), ',') s
        WHERE l.SalesPersonKUserId = TRY_CONVERT
        (
            uniqueidentifier,
            LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(s.value, '""', ''), '[', ''), ']', '')))
        )
    )
)

-- Süreç Kodu
AND
(
    @ProcessCode IS NULL
    OR LTRIM(RTRIM(@ProcessCode)) = ''
    OR UPPER(ISNULL(LTRIM(RTRIM(lp.Code)), '')) IN
    (
        SELECT UPPER(LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', ''))))
        FROM STRING_SPLIT(CAST(@ProcessCode AS NVARCHAR(MAX)), ',')
        WHERE LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', ''))) <> ''
    )
)

-- StepOrder Filtresi (genişletilmiş, -4 eklendi)
AND
(
    @StepOrder IS NULL
    OR @StepOrder = 0   -- Tümü

    -- Aktif: CREATED, TERMIN_PENDING, PENDING, APPROVED, DELIVERY_PENDING
    OR (@StepOrder = -1 AND lp.Code IN ('CREATED','TERMIN_PENDING','PENDING','APPROVED','DELIVERY_PENDING'))

    -- Bugün oluşturulanlar
    OR (
        @StepOrder = -2 
        AND l.CreatedAt >= CAST(GETDATE() AS DATE) 
        AND l.CreatedAt < DATEADD(day, 1, CAST(GETDATE() AS DATE))
    )

    -- Geciken (Termin Tarihi Geçmiş): EstimatedDate bugünden küçük ve sonuçlanmamış
    OR (
        @StepOrder = -3 
        AND l.EstimatedDate < CAST(GETDATE() AS DATE) 
        AND lp.Code NOT IN ('DELIVERED','CLOSED','CUSTOMER_DECLINED','REJECTED')
    )

    -- Bu ayın terminleri
    OR (
        @StepOrder = -4 
        AND l.EstimatedDate >= DATEFROMPARTS(YEAR(GETDATE()), MONTH(GETDATE()), 1)
        AND l.EstimatedDate < DATEADD(MONTH, 1, DATEFROMPARTS(YEAR(GETDATE()), MONTH(GETDATE()), 1))
    )

    -- Rezerv onay bekleyen
    OR (
        @StepOrder = 10 
        AND EXISTS (
            SELECT 1 
            FROM tmscrq.TMLeadReservation r 
            WHERE r.LeadId = l.Id 
              AND r.IsActive = 1 
              AND ISNULL(r.IsApproved,0) = 0
        )
    )

    -- Diğer pozitif StepOrder değerleri
    OR (
        @StepOrder NOT IN (0, -1, -2, -3, -4, 10) 
        AND lp.StepOrder = @StepOrder
    )
)

-- Başlangıç Tarihi
AND
(
    @StartDate IS NULL
    OR LTRIM(RTRIM(@StartDate)) = ''
    OR l.CreatedAt >= CONVERT(date, @StartDate)
)

-- Bitiş Tarihi
AND
(
    @EndDate IS NULL
    OR LTRIM(RTRIM(@EndDate)) = ''
    OR l.CreatedAt < DATEADD(day, 1, CONVERT(date, @EndDate))
)

ORDER BY l.CreatedAt DESC;", new string[] { "RezerveDurumu", "LeadId", "IsReserved", "LeadNumarasi", "TalepTarihi", "ProductId", "ProductName", "Bilezik", "Brand", "Kadran", "RefCode", "Referans", "Musteri", "Lokasyon", "Ilce", "Ulke", "MusteriInfo", "AlisverisiVarMi", "IrtibatNumarasi", "EmailAdresi", "IletisimKaynagi", "CategoryName", "CategoryCode", "LeadDurumu", "SonrakiAdim", "ProcessName", "ProcessCode", "StepOrder", "SelectedStepOrder", "TerminTarihi", "SatisDanismani", "StoreName" }, prms_TM_TopManagerDashboardLeadList_0.ToArray());
            ;


            return Ok(result);
        }


        [HttpPost, Route("DashBoardTempComponent_545586_onClick")]
        public IActionResult DashBoardTempComponent_545586_onClick(DashBoardTempComponent_545586_onClick_Request request)
        {

            KProviderManager.Authorization.IsAuthorizedForRoles(appId, appName, screenId, screenName, new List<string> { $"b4bfd39c-ac02-f442-c899-7a2374a45b47", "70de6cfc-6087-6059-59b4-0b5a8527af6b", "TimesSatisPersoneli", "TimesMagazaMuduru" });

            var result = new DashBoardTempComponent_545586_onClick_Response();

            var prms_TM_TopManagerDashboardLeadList_0 = new List<kSqlParameter>();
            prms_TM_TopManagerDashboardLeadList_0.Add(new kSqlParameter() { Name = "UserId", Value = Kuika.Common.KContext.CurrentUser?.Id });
            prms_TM_TopManagerDashboardLeadList_0.Add(new kSqlParameter() { Name = "MusteriAdi", Value = (null as object) });
            prms_TM_TopManagerDashboardLeadList_0.Add(new kSqlParameter() { Name = "ProductName", Value = (null as object) });
            prms_TM_TopManagerDashboardLeadList_0.Add(new kSqlParameter() { Name = "LeadCode", Value = (null as object) });
            prms_TM_TopManagerDashboardLeadList_0.Add(new kSqlParameter() { Name = "Tel", Value = (null as object) });
            prms_TM_TopManagerDashboardLeadList_0.Add(new kSqlParameter() { Name = "CategoryName", Value = (null as object) });
            prms_TM_TopManagerDashboardLeadList_0.Add(new kSqlParameter() { Name = "StoreIds", Value = (null as object) });
            prms_TM_TopManagerDashboardLeadList_0.Add(new kSqlParameter() { Name = "SatisDanismaniIds", Value = (null as object) });
            prms_TM_TopManagerDashboardLeadList_0.Add(new kSqlParameter() { Name = "ProcessCode", Value = (null as object) });
            prms_TM_TopManagerDashboardLeadList_0.Add(new kSqlParameter() { Name = "StepOrder", Value = "0".ConvertToType<Int32>() });
            prms_TM_TopManagerDashboardLeadList_0.Add(new kSqlParameter() { Name = "StartDate", Value = (null as object) });
            prms_TM_TopManagerDashboardLeadList_0.Add(new kSqlParameter() { Name = "EndDate", Value = (null as object) });
            using var auditTM_TopManagerDashboardLeadList_0 = ActionAuditScope.Begin("a4fec6ea-c916-ac83-135f-86b838861b6c", "TM_TopManagerDashboardLeadList", applicationName: "wbTimesCRM", screenOrEndpointName: "DashBoardTemp");
            result.TM_TopManagerDashboardLeadList = KPersister.Fetch(KContext.GetConnectionString(), @"SET LANGUAGE Turkish;


SELECT
    CASE 
        WHEN EXISTS (
            SELECT 1 
            FROM tmscrq.TMLeadReservation r
            WHERE r.LeadId = l.Id
              AND r.IsActive = 1
              AND r.IsApproved = 1
        ) THEN N'Evet'
        WHEN EXISTS (
            SELECT 1 
            FROM tmscrq.TMLeadReservation r
            WHERE r.LeadId = l.Id
              AND r.IsActive = 1
              AND ISNULL(r.IsApproved,0) = 0
        ) THEN N'Onay Bekliyor'
        ELSE N'Hayır'
    END AS RezerveDurumu,
    l.Id AS LeadId,
    l.IsReserved,
    ISNULL(NULLIF(LTRIM(RTRIM(l.LeadCode)), ''), '-') AS LeadNumarasi,
    CONVERT(varchar(10), l.CreatedAt, 103) AS TalepTarihi,

    p.Id AS ProductId,
    ISNULL(NULLIF(LTRIM(RTRIM(p.ProductName)), ''), '-') AS ProductName,
    ISNULL(NULLIF(LTRIM(RTRIM(p.Bracelet)), ''), '-') AS Bilezik,
    ISNULL(NULLIF(LTRIM(RTRIM(p.Brand)), ''), '-') AS Brand,
    ISNULL(NULLIF(LTRIM(RTRIM(p.Dial)), ''), '-') AS Kadran,
    ISNULL(NULLIF(LTRIM(RTRIM(p.ProductCode)), ''), '-') AS RefCode,
    ISNULL(NULLIF(LTRIM(RTRIM(p.Referance)), ''), '-') AS Referans,

    ISNULL(
        NULLIF(
            LTRIM(RTRIM(ISNULL(cu.Name, '') + ' ' + ISNULL(cu.LastName, '')))
        , '')
    , '-') AS Musteri,

    ISNULL(NULLIF(LTRIM(RTRIM(cu.CityName)), ''), '-') AS Lokasyon,
    ISNULL(NULLIF(LTRIM(RTRIM(cu.DistrictName)), ''), '-') AS Ilce,
    ISNULL(NULLIF(LTRIM(RTRIM(cu.CountryName)), ''), '-') AS Ulke,
    ISNULL(NULLIF(LTRIM(RTRIM(cu.Info)), ''), '-') AS MusteriInfo,

    CASE
        WHEN cu.IsShopping = 1 THEN N'Evet'
        WHEN cu.IsShopping = 0 THEN N'Hayır'
        ELSE '-'
    END AS AlisverisiVarMi,

    ISNULL(NULLIF(LTRIM(RTRIM(cu.Tel)), ''), '-') AS IrtibatNumarasi,
    ISNULL(NULLIF(LTRIM(RTRIM(cu.Email)), ''), '-') AS EmailAdresi,

    ISNULL(NULLIF(LTRIM(RTRIM(cr.ContactResourceName)), ''), '-') AS IletisimKaynagi,

    ISNULL(NULLIF(LTRIM(RTRIM(p.CategoryName)), ''), '-') AS CategoryName,
    '-' AS CategoryCode,

    ISNULL(NULLIF(LTRIM(RTRIM(ls.Name)), ''), '-') AS LeadDurumu,
    ISNULL(NULLIF(LTRIM(RTRIM(ns.Name)), ''), '-') AS SonrakiAdim,

    ISNULL(NULLIF(LTRIM(RTRIM(lp.Name)), ''), '-') AS ProcessName,
    ISNULL(NULLIF(LTRIM(RTRIM(lp.Code)), ''), '-') AS ProcessCode,
    lp.StepOrder,
    
    CAST(ISNULL(@StepOrder, lp.StepOrder) AS INT) AS SelectedStepOrder,

    ISNULL(
        CASE
            WHEN l.EstimatedDate IS NOT NULL
            THEN CAST(YEAR(l.EstimatedDate) AS VARCHAR(4)) + ' ' + DATENAME(MONTH, l.EstimatedDate)
            ELSE NULL
        END,
        '-'
    ) AS TerminTarihi,

    ISNULL(
        NULLIF(
            LTRIM(RTRIM(ISNULL(sp.FirstName, '') + ' ' + ISNULL(sp.LastName, '')))
        , '')
    , '-') AS SatisDanismani,

    ISNULL(NULLIF(LTRIM(RTRIM(st.StoreDesc)), ''), '-') AS StoreName

FROM tmscrq.TMLead l
LEFT JOIN tmscrq.TMLeadStatu ls ON ls.Id = l.StatuId
LEFT JOIN tmscrq.TMCustomer cu ON cu.Id = l.CustomerId
LEFT JOIN tmscrq.TMProduct p ON p.Id = l.ProductId
LEFT JOIN tmscrq.TMContactResource cr ON cr.Id = l.ContactResourceId
LEFT JOIN dbo.KUser sp ON sp.Id = l.SalesPersonKUserId
LEFT JOIN tmscrq.TMStore st ON st.Id = l.StoreId
LEFT JOIN tmscrq.TMLeadProcess lp ON lp.Id = l.ProcessID
LEFT JOIN tmscrq.TMLeadNextStep ns ON ns.Id = l.NextStepId

WHERE
-- Yetkilendirme
(
    -- Yönetici / Üst Yönetici: Tüm lead'ler
    EXISTS (
        SELECT 1
        FROM dbo.KUserRole ur
        INNER JOIN dbo.KRole r ON r.Id = ur.KRole_Id
        WHERE ur.KUser_Id = @UserId
          AND ur.IsDeleted = 0
          AND r.IsDeleted = 0
          AND r.Name IN ('TimesYonetici', 'TimesUstYonetici')
    )

    OR

    -- Mağaza Müdürü: Kendi mağazasındaki tüm lead'ler
    (
        EXISTS (
            SELECT 1
            FROM dbo.KUserRole ur
            INNER JOIN dbo.KRole r ON r.Id = ur.KRole_Id
            WHERE ur.KUser_Id = @UserId
              AND ur.IsDeleted = 0
              AND r.IsDeleted = 0
              AND r.Name = 'TimesMagazaMuduru'
        )
        AND l.StoreId =
        (
            SELECT TOP 1 tu.StoreID
            FROM tmscrq.TMUser tu
            WHERE tu.KUserID = @UserId
        )
    )

    OR

    -- Satış Personeli: Sadece kendi açtığı lead'ler
    (
        EXISTS (
            SELECT 1
            FROM dbo.KUserRole ur
            INNER JOIN dbo.KRole r ON r.Id = ur.KRole_Id
            WHERE ur.KUser_Id = @UserId
              AND ur.IsDeleted = 0
              AND r.IsDeleted = 0
              AND r.Name = 'TimesSatisPersoneli'
        )
        AND l.SalesPersonKUserId = @UserId
    )
)

-- Müşteri Adı
AND
(
    @MusteriAdi IS NULL
    OR LTRIM(RTRIM(@MusteriAdi)) = ''
    OR UPPER(LTRIM(RTRIM(ISNULL(cu.Name,'') + ' ' + ISNULL(cu.LastName,''))))
       LIKE '%' + UPPER(LTRIM(RTRIM(@MusteriAdi))) + '%'
)

-- Ürün Adı
AND
(
    @ProductName IS NULL
    OR LTRIM(RTRIM(@ProductName)) = ''
    OR
    (
        CHARINDEX(',', @ProductName) > 0
        AND ISNULL(LTRIM(RTRIM(p.ProductName)), '') IN
        (
            SELECT LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', '')))
            FROM STRING_SPLIT(CAST(@ProductName AS NVARCHAR(MAX)), ',')
            WHERE LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', ''))) <> ''
        )
    )
    OR
    (
        CHARINDEX(',', @ProductName) = 0
        AND UPPER(ISNULL(LTRIM(RTRIM(p.ProductName)), ''))
            LIKE '%' + UPPER(LTRIM(RTRIM(@ProductName))) + '%'
    )
)

-- Lead Kodu
AND
(
    @LeadCode IS NULL
    OR LTRIM(RTRIM(@LeadCode)) = ''
    OR UPPER(ISNULL(LTRIM(RTRIM(l.LeadCode)), '')) LIKE '%' + UPPER(LTRIM(RTRIM(@LeadCode))) + '%'
)

-- Telefon
AND
(
    @Tel IS NULL
    OR LTRIM(RTRIM(@Tel)) = ''
    OR UPPER(ISNULL(LTRIM(RTRIM(cu.Tel)), '')) LIKE '%' + UPPER(LTRIM(RTRIM(@Tel))) + '%'
)

-- Kategori
AND
(
    @CategoryName IS NULL
    OR LTRIM(RTRIM(@CategoryName)) = ''
    OR UPPER(ISNULL(LTRIM(RTRIM(p.CategoryName)), '')) IN
    (
        SELECT UPPER(LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value,'""',''),'[',''),']',''))))
        FROM STRING_SPLIT(CAST(@CategoryName AS NVARCHAR(MAX)), ',')
        WHERE LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value,'""',''),'[',''),']',''))) <> ''
    )
)

-- Mağaza
AND
(
    @StoreIds IS NULL
    OR LTRIM(RTRIM(@StoreIds)) = ''
    OR EXISTS
    (
        SELECT 1
        FROM STRING_SPLIT(CAST(@StoreIds AS NVARCHAR(MAX)), ',') s
        WHERE l.StoreId = TRY_CONVERT
        (
            uniqueidentifier,
            LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(s.value, '""', ''), '[', ''), ']', '')))
        )
    )
)

-- Satış Danışmanı
AND
(
    @SatisDanismaniIds IS NULL
    OR LTRIM(RTRIM(@SatisDanismaniIds)) = ''
    OR EXISTS
    (
        SELECT 1
        FROM STRING_SPLIT(CAST(@SatisDanismaniIds AS NVARCHAR(MAX)), ',') s
        WHERE l.SalesPersonKUserId = TRY_CONVERT
        (
            uniqueidentifier,
            LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(s.value, '""', ''), '[', ''), ']', '')))
        )
    )
)

-- Süreç Kodu
AND
(
    @ProcessCode IS NULL
    OR LTRIM(RTRIM(@ProcessCode)) = ''
    OR UPPER(ISNULL(LTRIM(RTRIM(lp.Code)), '')) IN
    (
        SELECT UPPER(LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', ''))))
        FROM STRING_SPLIT(CAST(@ProcessCode AS NVARCHAR(MAX)), ',')
        WHERE LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', ''))) <> ''
    )
)

-- StepOrder Filtresi (genişletilmiş, -4 eklendi)
AND
(
    @StepOrder IS NULL
    OR @StepOrder = 0   -- Tümü

    -- Aktif: CREATED, TERMIN_PENDING, PENDING, APPROVED, DELIVERY_PENDING
    OR (@StepOrder = -1 AND lp.Code IN ('CREATED','TERMIN_PENDING','PENDING','APPROVED','DELIVERY_PENDING'))

    -- Bugün oluşturulanlar
    OR (
        @StepOrder = -2 
        AND l.CreatedAt >= CAST(GETDATE() AS DATE) 
        AND l.CreatedAt < DATEADD(day, 1, CAST(GETDATE() AS DATE))
    )

    -- Geciken (Termin Tarihi Geçmiş): EstimatedDate bugünden küçük ve sonuçlanmamış
    OR (
        @StepOrder = -3 
        AND l.EstimatedDate < CAST(GETDATE() AS DATE) 
        AND lp.Code NOT IN ('DELIVERED','CLOSED','CUSTOMER_DECLINED','REJECTED')
    )

    -- Bu ayın terminleri
    OR (
        @StepOrder = -4 
        AND l.EstimatedDate >= DATEFROMPARTS(YEAR(GETDATE()), MONTH(GETDATE()), 1)
        AND l.EstimatedDate < DATEADD(MONTH, 1, DATEFROMPARTS(YEAR(GETDATE()), MONTH(GETDATE()), 1))
    )

    -- Rezerv onay bekleyen
    OR (
        @StepOrder = 10 
        AND EXISTS (
            SELECT 1 
            FROM tmscrq.TMLeadReservation r 
            WHERE r.LeadId = l.Id 
              AND r.IsActive = 1 
              AND ISNULL(r.IsApproved,0) = 0
        )
    )

    -- Diğer pozitif StepOrder değerleri
    OR (
        @StepOrder NOT IN (0, -1, -2, -3, -4, 10) 
        AND lp.StepOrder = @StepOrder
    )
)

-- Başlangıç Tarihi
AND
(
    @StartDate IS NULL
    OR LTRIM(RTRIM(@StartDate)) = ''
    OR l.CreatedAt >= CONVERT(date, @StartDate)
)

-- Bitiş Tarihi
AND
(
    @EndDate IS NULL
    OR LTRIM(RTRIM(@EndDate)) = ''
    OR l.CreatedAt < DATEADD(day, 1, CONVERT(date, @EndDate))
)

ORDER BY l.CreatedAt DESC;", new string[] { "RezerveDurumu", "LeadId", "IsReserved", "LeadNumarasi", "TalepTarihi", "ProductId", "ProductName", "Bilezik", "Brand", "Kadran", "RefCode", "Referans", "Musteri", "Lokasyon", "Ilce", "Ulke", "MusteriInfo", "AlisverisiVarMi", "IrtibatNumarasi", "EmailAdresi", "IletisimKaynagi", "CategoryName", "CategoryCode", "LeadDurumu", "SonrakiAdim", "ProcessName", "ProcessCode", "StepOrder", "SelectedStepOrder", "TerminTarihi", "SatisDanismani", "StoreName" }, prms_TM_TopManagerDashboardLeadList_0.ToArray());
            ;


            return Ok(result);
        }


        [HttpPost, Route("DashBoardTempComponent_77242_onClick")]
        public IActionResult DashBoardTempComponent_77242_onClick(DashBoardTempComponent_77242_onClick_Request request)
        {

            KProviderManager.Authorization.IsAuthorizedForRoles(appId, appName, screenId, screenName, new List<string> { $"b4bfd39c-ac02-f442-c899-7a2374a45b47", "70de6cfc-6087-6059-59b4-0b5a8527af6b", "TimesSatisPersoneli", "TimesMagazaMuduru" });

            var result = new DashBoardTempComponent_77242_onClick_Response();

            var prms_TM_TopManagerDashboardLeadList_0 = new List<kSqlParameter>();
            prms_TM_TopManagerDashboardLeadList_0.Add(new kSqlParameter() { Name = "UserId", Value = Kuika.Common.KContext.CurrentUser?.Id });
            prms_TM_TopManagerDashboardLeadList_0.Add(new kSqlParameter() { Name = "MusteriAdi", Value = (null as object) });
            prms_TM_TopManagerDashboardLeadList_0.Add(new kSqlParameter() { Name = "ProductName", Value = (null as object) });
            prms_TM_TopManagerDashboardLeadList_0.Add(new kSqlParameter() { Name = "LeadCode", Value = (null as object) });
            prms_TM_TopManagerDashboardLeadList_0.Add(new kSqlParameter() { Name = "Tel", Value = (null as object) });
            prms_TM_TopManagerDashboardLeadList_0.Add(new kSqlParameter() { Name = "CategoryName", Value = (null as object) });
            prms_TM_TopManagerDashboardLeadList_0.Add(new kSqlParameter() { Name = "StoreIds", Value = (null as object) });
            prms_TM_TopManagerDashboardLeadList_0.Add(new kSqlParameter() { Name = "SatisDanismaniIds", Value = (null as object) });
            prms_TM_TopManagerDashboardLeadList_0.Add(new kSqlParameter() { Name = "ProcessCode", Value = (null as object) });
            prms_TM_TopManagerDashboardLeadList_0.Add(new kSqlParameter() { Name = "StepOrder", Value = "-1".ConvertToType<Int32>() });
            prms_TM_TopManagerDashboardLeadList_0.Add(new kSqlParameter() { Name = "StartDate", Value = (null as object) });
            prms_TM_TopManagerDashboardLeadList_0.Add(new kSqlParameter() { Name = "EndDate", Value = (null as object) });
            using var auditTM_TopManagerDashboardLeadList_0 = ActionAuditScope.Begin("3224146f-61e3-f49e-14d9-8d5a2a5dcb59", "TM_TopManagerDashboardLeadList", applicationName: "wbTimesCRM", screenOrEndpointName: "DashBoardTemp");
            result.TM_TopManagerDashboardLeadList = KPersister.Fetch(KContext.GetConnectionString(), @"SET LANGUAGE Turkish;


SELECT
    CASE 
        WHEN EXISTS (
            SELECT 1 
            FROM tmscrq.TMLeadReservation r
            WHERE r.LeadId = l.Id
              AND r.IsActive = 1
              AND r.IsApproved = 1
        ) THEN N'Evet'
        WHEN EXISTS (
            SELECT 1 
            FROM tmscrq.TMLeadReservation r
            WHERE r.LeadId = l.Id
              AND r.IsActive = 1
              AND ISNULL(r.IsApproved,0) = 0
        ) THEN N'Onay Bekliyor'
        ELSE N'Hayır'
    END AS RezerveDurumu,
    l.Id AS LeadId,
    l.IsReserved,
    ISNULL(NULLIF(LTRIM(RTRIM(l.LeadCode)), ''), '-') AS LeadNumarasi,
    CONVERT(varchar(10), l.CreatedAt, 103) AS TalepTarihi,

    p.Id AS ProductId,
    ISNULL(NULLIF(LTRIM(RTRIM(p.ProductName)), ''), '-') AS ProductName,
    ISNULL(NULLIF(LTRIM(RTRIM(p.Bracelet)), ''), '-') AS Bilezik,
    ISNULL(NULLIF(LTRIM(RTRIM(p.Brand)), ''), '-') AS Brand,
    ISNULL(NULLIF(LTRIM(RTRIM(p.Dial)), ''), '-') AS Kadran,
    ISNULL(NULLIF(LTRIM(RTRIM(p.ProductCode)), ''), '-') AS RefCode,
    ISNULL(NULLIF(LTRIM(RTRIM(p.Referance)), ''), '-') AS Referans,

    ISNULL(
        NULLIF(
            LTRIM(RTRIM(ISNULL(cu.Name, '') + ' ' + ISNULL(cu.LastName, '')))
        , '')
    , '-') AS Musteri,

    ISNULL(NULLIF(LTRIM(RTRIM(cu.CityName)), ''), '-') AS Lokasyon,
    ISNULL(NULLIF(LTRIM(RTRIM(cu.DistrictName)), ''), '-') AS Ilce,
    ISNULL(NULLIF(LTRIM(RTRIM(cu.CountryName)), ''), '-') AS Ulke,
    ISNULL(NULLIF(LTRIM(RTRIM(cu.Info)), ''), '-') AS MusteriInfo,

    CASE
        WHEN cu.IsShopping = 1 THEN N'Evet'
        WHEN cu.IsShopping = 0 THEN N'Hayır'
        ELSE '-'
    END AS AlisverisiVarMi,

    ISNULL(NULLIF(LTRIM(RTRIM(cu.Tel)), ''), '-') AS IrtibatNumarasi,
    ISNULL(NULLIF(LTRIM(RTRIM(cu.Email)), ''), '-') AS EmailAdresi,

    ISNULL(NULLIF(LTRIM(RTRIM(cr.ContactResourceName)), ''), '-') AS IletisimKaynagi,

    ISNULL(NULLIF(LTRIM(RTRIM(p.CategoryName)), ''), '-') AS CategoryName,
    '-' AS CategoryCode,

    ISNULL(NULLIF(LTRIM(RTRIM(ls.Name)), ''), '-') AS LeadDurumu,
    ISNULL(NULLIF(LTRIM(RTRIM(ns.Name)), ''), '-') AS SonrakiAdim,

    ISNULL(NULLIF(LTRIM(RTRIM(lp.Name)), ''), '-') AS ProcessName,
    ISNULL(NULLIF(LTRIM(RTRIM(lp.Code)), ''), '-') AS ProcessCode,
    lp.StepOrder,
    
    CAST(ISNULL(@StepOrder, lp.StepOrder) AS INT) AS SelectedStepOrder,

    ISNULL(
        CASE
            WHEN l.EstimatedDate IS NOT NULL
            THEN CAST(YEAR(l.EstimatedDate) AS VARCHAR(4)) + ' ' + DATENAME(MONTH, l.EstimatedDate)
            ELSE NULL
        END,
        '-'
    ) AS TerminTarihi,

    ISNULL(
        NULLIF(
            LTRIM(RTRIM(ISNULL(sp.FirstName, '') + ' ' + ISNULL(sp.LastName, '')))
        , '')
    , '-') AS SatisDanismani,

    ISNULL(NULLIF(LTRIM(RTRIM(st.StoreDesc)), ''), '-') AS StoreName

FROM tmscrq.TMLead l
LEFT JOIN tmscrq.TMLeadStatu ls ON ls.Id = l.StatuId
LEFT JOIN tmscrq.TMCustomer cu ON cu.Id = l.CustomerId
LEFT JOIN tmscrq.TMProduct p ON p.Id = l.ProductId
LEFT JOIN tmscrq.TMContactResource cr ON cr.Id = l.ContactResourceId
LEFT JOIN dbo.KUser sp ON sp.Id = l.SalesPersonKUserId
LEFT JOIN tmscrq.TMStore st ON st.Id = l.StoreId
LEFT JOIN tmscrq.TMLeadProcess lp ON lp.Id = l.ProcessID
LEFT JOIN tmscrq.TMLeadNextStep ns ON ns.Id = l.NextStepId

WHERE
-- Yetkilendirme
(
    -- Yönetici / Üst Yönetici: Tüm lead'ler
    EXISTS (
        SELECT 1
        FROM dbo.KUserRole ur
        INNER JOIN dbo.KRole r ON r.Id = ur.KRole_Id
        WHERE ur.KUser_Id = @UserId
          AND ur.IsDeleted = 0
          AND r.IsDeleted = 0
          AND r.Name IN ('TimesYonetici', 'TimesUstYonetici')
    )

    OR

    -- Mağaza Müdürü: Kendi mağazasındaki tüm lead'ler
    (
        EXISTS (
            SELECT 1
            FROM dbo.KUserRole ur
            INNER JOIN dbo.KRole r ON r.Id = ur.KRole_Id
            WHERE ur.KUser_Id = @UserId
              AND ur.IsDeleted = 0
              AND r.IsDeleted = 0
              AND r.Name = 'TimesMagazaMuduru'
        )
        AND l.StoreId =
        (
            SELECT TOP 1 tu.StoreID
            FROM tmscrq.TMUser tu
            WHERE tu.KUserID = @UserId
        )
    )

    OR

    -- Satış Personeli: Sadece kendi açtığı lead'ler
    (
        EXISTS (
            SELECT 1
            FROM dbo.KUserRole ur
            INNER JOIN dbo.KRole r ON r.Id = ur.KRole_Id
            WHERE ur.KUser_Id = @UserId
              AND ur.IsDeleted = 0
              AND r.IsDeleted = 0
              AND r.Name = 'TimesSatisPersoneli'
        )
        AND l.SalesPersonKUserId = @UserId
    )
)

-- Müşteri Adı
AND
(
    @MusteriAdi IS NULL
    OR LTRIM(RTRIM(@MusteriAdi)) = ''
    OR UPPER(LTRIM(RTRIM(ISNULL(cu.Name,'') + ' ' + ISNULL(cu.LastName,''))))
       LIKE '%' + UPPER(LTRIM(RTRIM(@MusteriAdi))) + '%'
)

-- Ürün Adı
AND
(
    @ProductName IS NULL
    OR LTRIM(RTRIM(@ProductName)) = ''
    OR
    (
        CHARINDEX(',', @ProductName) > 0
        AND ISNULL(LTRIM(RTRIM(p.ProductName)), '') IN
        (
            SELECT LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', '')))
            FROM STRING_SPLIT(CAST(@ProductName AS NVARCHAR(MAX)), ',')
            WHERE LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', ''))) <> ''
        )
    )
    OR
    (
        CHARINDEX(',', @ProductName) = 0
        AND UPPER(ISNULL(LTRIM(RTRIM(p.ProductName)), ''))
            LIKE '%' + UPPER(LTRIM(RTRIM(@ProductName))) + '%'
    )
)

-- Lead Kodu
AND
(
    @LeadCode IS NULL
    OR LTRIM(RTRIM(@LeadCode)) = ''
    OR UPPER(ISNULL(LTRIM(RTRIM(l.LeadCode)), '')) LIKE '%' + UPPER(LTRIM(RTRIM(@LeadCode))) + '%'
)

-- Telefon
AND
(
    @Tel IS NULL
    OR LTRIM(RTRIM(@Tel)) = ''
    OR UPPER(ISNULL(LTRIM(RTRIM(cu.Tel)), '')) LIKE '%' + UPPER(LTRIM(RTRIM(@Tel))) + '%'
)

-- Kategori
AND
(
    @CategoryName IS NULL
    OR LTRIM(RTRIM(@CategoryName)) = ''
    OR UPPER(ISNULL(LTRIM(RTRIM(p.CategoryName)), '')) IN
    (
        SELECT UPPER(LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value,'""',''),'[',''),']',''))))
        FROM STRING_SPLIT(CAST(@CategoryName AS NVARCHAR(MAX)), ',')
        WHERE LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value,'""',''),'[',''),']',''))) <> ''
    )
)

-- Mağaza
AND
(
    @StoreIds IS NULL
    OR LTRIM(RTRIM(@StoreIds)) = ''
    OR EXISTS
    (
        SELECT 1
        FROM STRING_SPLIT(CAST(@StoreIds AS NVARCHAR(MAX)), ',') s
        WHERE l.StoreId = TRY_CONVERT
        (
            uniqueidentifier,
            LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(s.value, '""', ''), '[', ''), ']', '')))
        )
    )
)

-- Satış Danışmanı
AND
(
    @SatisDanismaniIds IS NULL
    OR LTRIM(RTRIM(@SatisDanismaniIds)) = ''
    OR EXISTS
    (
        SELECT 1
        FROM STRING_SPLIT(CAST(@SatisDanismaniIds AS NVARCHAR(MAX)), ',') s
        WHERE l.SalesPersonKUserId = TRY_CONVERT
        (
            uniqueidentifier,
            LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(s.value, '""', ''), '[', ''), ']', '')))
        )
    )
)

-- Süreç Kodu
AND
(
    @ProcessCode IS NULL
    OR LTRIM(RTRIM(@ProcessCode)) = ''
    OR UPPER(ISNULL(LTRIM(RTRIM(lp.Code)), '')) IN
    (
        SELECT UPPER(LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', ''))))
        FROM STRING_SPLIT(CAST(@ProcessCode AS NVARCHAR(MAX)), ',')
        WHERE LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', ''))) <> ''
    )
)

-- StepOrder Filtresi (genişletilmiş, -4 eklendi)
AND
(
    @StepOrder IS NULL
    OR @StepOrder = 0   -- Tümü

    -- Aktif: CREATED, TERMIN_PENDING, PENDING, APPROVED, DELIVERY_PENDING
    OR (@StepOrder = -1 AND lp.Code IN ('CREATED','TERMIN_PENDING','PENDING','APPROVED','DELIVERY_PENDING'))

    -- Bugün oluşturulanlar
    OR (
        @StepOrder = -2 
        AND l.CreatedAt >= CAST(GETDATE() AS DATE) 
        AND l.CreatedAt < DATEADD(day, 1, CAST(GETDATE() AS DATE))
    )

    -- Geciken (Termin Tarihi Geçmiş): EstimatedDate bugünden küçük ve sonuçlanmamış
    OR (
        @StepOrder = -3 
        AND l.EstimatedDate < CAST(GETDATE() AS DATE) 
        AND lp.Code NOT IN ('DELIVERED','CLOSED','CUSTOMER_DECLINED','REJECTED')
    )

    -- Bu ayın terminleri
    OR (
        @StepOrder = -4 
        AND l.EstimatedDate >= DATEFROMPARTS(YEAR(GETDATE()), MONTH(GETDATE()), 1)
        AND l.EstimatedDate < DATEADD(MONTH, 1, DATEFROMPARTS(YEAR(GETDATE()), MONTH(GETDATE()), 1))
    )

    -- Rezerv onay bekleyen
    OR (
        @StepOrder = 10 
        AND EXISTS (
            SELECT 1 
            FROM tmscrq.TMLeadReservation r 
            WHERE r.LeadId = l.Id 
              AND r.IsActive = 1 
              AND ISNULL(r.IsApproved,0) = 0
        )
    )

    -- Diğer pozitif StepOrder değerleri
    OR (
        @StepOrder NOT IN (0, -1, -2, -3, -4, 10) 
        AND lp.StepOrder = @StepOrder
    )
)

-- Başlangıç Tarihi
AND
(
    @StartDate IS NULL
    OR LTRIM(RTRIM(@StartDate)) = ''
    OR l.CreatedAt >= CONVERT(date, @StartDate)
)

-- Bitiş Tarihi
AND
(
    @EndDate IS NULL
    OR LTRIM(RTRIM(@EndDate)) = ''
    OR l.CreatedAt < DATEADD(day, 1, CONVERT(date, @EndDate))
)

ORDER BY l.CreatedAt DESC;", new string[] { "RezerveDurumu", "LeadId", "IsReserved", "LeadNumarasi", "TalepTarihi", "ProductId", "ProductName", "Bilezik", "Brand", "Kadran", "RefCode", "Referans", "Musteri", "Lokasyon", "Ilce", "Ulke", "MusteriInfo", "AlisverisiVarMi", "IrtibatNumarasi", "EmailAdresi", "IletisimKaynagi", "CategoryName", "CategoryCode", "LeadDurumu", "SonrakiAdim", "ProcessName", "ProcessCode", "StepOrder", "SelectedStepOrder", "TerminTarihi", "SatisDanismani", "StoreName" }, prms_TM_TopManagerDashboardLeadList_0.ToArray());
            ;


            return Ok(result);
        }


        [HttpPost, Route("DashBoardTempComponent_744094_onClick")]
        public IActionResult DashBoardTempComponent_744094_onClick(DashBoardTempComponent_744094_onClick_Request request)
        {

            KProviderManager.Authorization.IsAuthorizedForRoles(appId, appName, screenId, screenName, new List<string> { $"b4bfd39c-ac02-f442-c899-7a2374a45b47", "70de6cfc-6087-6059-59b4-0b5a8527af6b", "TimesSatisPersoneli", "TimesMagazaMuduru" });

            var result = new DashBoardTempComponent_744094_onClick_Response();

            var prms_TM_TopManagerDashboardLeadList_0 = new List<kSqlParameter>();
            prms_TM_TopManagerDashboardLeadList_0.Add(new kSqlParameter() { Name = "UserId", Value = Kuika.Common.KContext.CurrentUser?.Id });
            prms_TM_TopManagerDashboardLeadList_0.Add(new kSqlParameter() { Name = "MusteriAdi", Value = (null as object) });
            prms_TM_TopManagerDashboardLeadList_0.Add(new kSqlParameter() { Name = "ProductName", Value = (null as object) });
            prms_TM_TopManagerDashboardLeadList_0.Add(new kSqlParameter() { Name = "LeadCode", Value = (null as object) });
            prms_TM_TopManagerDashboardLeadList_0.Add(new kSqlParameter() { Name = "Tel", Value = (null as object) });
            prms_TM_TopManagerDashboardLeadList_0.Add(new kSqlParameter() { Name = "CategoryName", Value = (null as object) });
            prms_TM_TopManagerDashboardLeadList_0.Add(new kSqlParameter() { Name = "StoreIds", Value = (null as object) });
            prms_TM_TopManagerDashboardLeadList_0.Add(new kSqlParameter() { Name = "SatisDanismaniIds", Value = (null as object) });
            prms_TM_TopManagerDashboardLeadList_0.Add(new kSqlParameter() { Name = "ProcessCode", Value = (null as object) });
            prms_TM_TopManagerDashboardLeadList_0.Add(new kSqlParameter() { Name = "StepOrder", Value = "-2".ConvertToType<Int32>() });
            prms_TM_TopManagerDashboardLeadList_0.Add(new kSqlParameter() { Name = "StartDate", Value = (null as object) });
            prms_TM_TopManagerDashboardLeadList_0.Add(new kSqlParameter() { Name = "EndDate", Value = (null as object) });
            using var auditTM_TopManagerDashboardLeadList_0 = ActionAuditScope.Begin("138e3763-99a6-a4c2-62f0-a2ddfc9a2aa1", "TM_TopManagerDashboardLeadList", applicationName: "wbTimesCRM", screenOrEndpointName: "DashBoardTemp");
            result.TM_TopManagerDashboardLeadList = KPersister.Fetch(KContext.GetConnectionString(), @"SET LANGUAGE Turkish;


SELECT
    CASE 
        WHEN EXISTS (
            SELECT 1 
            FROM tmscrq.TMLeadReservation r
            WHERE r.LeadId = l.Id
              AND r.IsActive = 1
              AND r.IsApproved = 1
        ) THEN N'Evet'
        WHEN EXISTS (
            SELECT 1 
            FROM tmscrq.TMLeadReservation r
            WHERE r.LeadId = l.Id
              AND r.IsActive = 1
              AND ISNULL(r.IsApproved,0) = 0
        ) THEN N'Onay Bekliyor'
        ELSE N'Hayır'
    END AS RezerveDurumu,
    l.Id AS LeadId,
    l.IsReserved,
    ISNULL(NULLIF(LTRIM(RTRIM(l.LeadCode)), ''), '-') AS LeadNumarasi,
    CONVERT(varchar(10), l.CreatedAt, 103) AS TalepTarihi,

    p.Id AS ProductId,
    ISNULL(NULLIF(LTRIM(RTRIM(p.ProductName)), ''), '-') AS ProductName,
    ISNULL(NULLIF(LTRIM(RTRIM(p.Bracelet)), ''), '-') AS Bilezik,
    ISNULL(NULLIF(LTRIM(RTRIM(p.Brand)), ''), '-') AS Brand,
    ISNULL(NULLIF(LTRIM(RTRIM(p.Dial)), ''), '-') AS Kadran,
    ISNULL(NULLIF(LTRIM(RTRIM(p.ProductCode)), ''), '-') AS RefCode,
    ISNULL(NULLIF(LTRIM(RTRIM(p.Referance)), ''), '-') AS Referans,

    ISNULL(
        NULLIF(
            LTRIM(RTRIM(ISNULL(cu.Name, '') + ' ' + ISNULL(cu.LastName, '')))
        , '')
    , '-') AS Musteri,

    ISNULL(NULLIF(LTRIM(RTRIM(cu.CityName)), ''), '-') AS Lokasyon,
    ISNULL(NULLIF(LTRIM(RTRIM(cu.DistrictName)), ''), '-') AS Ilce,
    ISNULL(NULLIF(LTRIM(RTRIM(cu.CountryName)), ''), '-') AS Ulke,
    ISNULL(NULLIF(LTRIM(RTRIM(cu.Info)), ''), '-') AS MusteriInfo,

    CASE
        WHEN cu.IsShopping = 1 THEN N'Evet'
        WHEN cu.IsShopping = 0 THEN N'Hayır'
        ELSE '-'
    END AS AlisverisiVarMi,

    ISNULL(NULLIF(LTRIM(RTRIM(cu.Tel)), ''), '-') AS IrtibatNumarasi,
    ISNULL(NULLIF(LTRIM(RTRIM(cu.Email)), ''), '-') AS EmailAdresi,

    ISNULL(NULLIF(LTRIM(RTRIM(cr.ContactResourceName)), ''), '-') AS IletisimKaynagi,

    ISNULL(NULLIF(LTRIM(RTRIM(p.CategoryName)), ''), '-') AS CategoryName,
    '-' AS CategoryCode,

    ISNULL(NULLIF(LTRIM(RTRIM(ls.Name)), ''), '-') AS LeadDurumu,
    ISNULL(NULLIF(LTRIM(RTRIM(ns.Name)), ''), '-') AS SonrakiAdim,

    ISNULL(NULLIF(LTRIM(RTRIM(lp.Name)), ''), '-') AS ProcessName,
    ISNULL(NULLIF(LTRIM(RTRIM(lp.Code)), ''), '-') AS ProcessCode,
    lp.StepOrder,
    
    CAST(ISNULL(@StepOrder, lp.StepOrder) AS INT) AS SelectedStepOrder,

    ISNULL(
        CASE
            WHEN l.EstimatedDate IS NOT NULL
            THEN CAST(YEAR(l.EstimatedDate) AS VARCHAR(4)) + ' ' + DATENAME(MONTH, l.EstimatedDate)
            ELSE NULL
        END,
        '-'
    ) AS TerminTarihi,

    ISNULL(
        NULLIF(
            LTRIM(RTRIM(ISNULL(sp.FirstName, '') + ' ' + ISNULL(sp.LastName, '')))
        , '')
    , '-') AS SatisDanismani,

    ISNULL(NULLIF(LTRIM(RTRIM(st.StoreDesc)), ''), '-') AS StoreName

FROM tmscrq.TMLead l
LEFT JOIN tmscrq.TMLeadStatu ls ON ls.Id = l.StatuId
LEFT JOIN tmscrq.TMCustomer cu ON cu.Id = l.CustomerId
LEFT JOIN tmscrq.TMProduct p ON p.Id = l.ProductId
LEFT JOIN tmscrq.TMContactResource cr ON cr.Id = l.ContactResourceId
LEFT JOIN dbo.KUser sp ON sp.Id = l.SalesPersonKUserId
LEFT JOIN tmscrq.TMStore st ON st.Id = l.StoreId
LEFT JOIN tmscrq.TMLeadProcess lp ON lp.Id = l.ProcessID
LEFT JOIN tmscrq.TMLeadNextStep ns ON ns.Id = l.NextStepId

WHERE
-- Yetkilendirme
(
    -- Yönetici / Üst Yönetici: Tüm lead'ler
    EXISTS (
        SELECT 1
        FROM dbo.KUserRole ur
        INNER JOIN dbo.KRole r ON r.Id = ur.KRole_Id
        WHERE ur.KUser_Id = @UserId
          AND ur.IsDeleted = 0
          AND r.IsDeleted = 0
          AND r.Name IN ('TimesYonetici', 'TimesUstYonetici')
    )

    OR

    -- Mağaza Müdürü: Kendi mağazasındaki tüm lead'ler
    (
        EXISTS (
            SELECT 1
            FROM dbo.KUserRole ur
            INNER JOIN dbo.KRole r ON r.Id = ur.KRole_Id
            WHERE ur.KUser_Id = @UserId
              AND ur.IsDeleted = 0
              AND r.IsDeleted = 0
              AND r.Name = 'TimesMagazaMuduru'
        )
        AND l.StoreId =
        (
            SELECT TOP 1 tu.StoreID
            FROM tmscrq.TMUser tu
            WHERE tu.KUserID = @UserId
        )
    )

    OR

    -- Satış Personeli: Sadece kendi açtığı lead'ler
    (
        EXISTS (
            SELECT 1
            FROM dbo.KUserRole ur
            INNER JOIN dbo.KRole r ON r.Id = ur.KRole_Id
            WHERE ur.KUser_Id = @UserId
              AND ur.IsDeleted = 0
              AND r.IsDeleted = 0
              AND r.Name = 'TimesSatisPersoneli'
        )
        AND l.SalesPersonKUserId = @UserId
    )
)

-- Müşteri Adı
AND
(
    @MusteriAdi IS NULL
    OR LTRIM(RTRIM(@MusteriAdi)) = ''
    OR UPPER(LTRIM(RTRIM(ISNULL(cu.Name,'') + ' ' + ISNULL(cu.LastName,''))))
       LIKE '%' + UPPER(LTRIM(RTRIM(@MusteriAdi))) + '%'
)

-- Ürün Adı
AND
(
    @ProductName IS NULL
    OR LTRIM(RTRIM(@ProductName)) = ''
    OR
    (
        CHARINDEX(',', @ProductName) > 0
        AND ISNULL(LTRIM(RTRIM(p.ProductName)), '') IN
        (
            SELECT LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', '')))
            FROM STRING_SPLIT(CAST(@ProductName AS NVARCHAR(MAX)), ',')
            WHERE LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', ''))) <> ''
        )
    )
    OR
    (
        CHARINDEX(',', @ProductName) = 0
        AND UPPER(ISNULL(LTRIM(RTRIM(p.ProductName)), ''))
            LIKE '%' + UPPER(LTRIM(RTRIM(@ProductName))) + '%'
    )
)

-- Lead Kodu
AND
(
    @LeadCode IS NULL
    OR LTRIM(RTRIM(@LeadCode)) = ''
    OR UPPER(ISNULL(LTRIM(RTRIM(l.LeadCode)), '')) LIKE '%' + UPPER(LTRIM(RTRIM(@LeadCode))) + '%'
)

-- Telefon
AND
(
    @Tel IS NULL
    OR LTRIM(RTRIM(@Tel)) = ''
    OR UPPER(ISNULL(LTRIM(RTRIM(cu.Tel)), '')) LIKE '%' + UPPER(LTRIM(RTRIM(@Tel))) + '%'
)

-- Kategori
AND
(
    @CategoryName IS NULL
    OR LTRIM(RTRIM(@CategoryName)) = ''
    OR UPPER(ISNULL(LTRIM(RTRIM(p.CategoryName)), '')) IN
    (
        SELECT UPPER(LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value,'""',''),'[',''),']',''))))
        FROM STRING_SPLIT(CAST(@CategoryName AS NVARCHAR(MAX)), ',')
        WHERE LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value,'""',''),'[',''),']',''))) <> ''
    )
)

-- Mağaza
AND
(
    @StoreIds IS NULL
    OR LTRIM(RTRIM(@StoreIds)) = ''
    OR EXISTS
    (
        SELECT 1
        FROM STRING_SPLIT(CAST(@StoreIds AS NVARCHAR(MAX)), ',') s
        WHERE l.StoreId = TRY_CONVERT
        (
            uniqueidentifier,
            LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(s.value, '""', ''), '[', ''), ']', '')))
        )
    )
)

-- Satış Danışmanı
AND
(
    @SatisDanismaniIds IS NULL
    OR LTRIM(RTRIM(@SatisDanismaniIds)) = ''
    OR EXISTS
    (
        SELECT 1
        FROM STRING_SPLIT(CAST(@SatisDanismaniIds AS NVARCHAR(MAX)), ',') s
        WHERE l.SalesPersonKUserId = TRY_CONVERT
        (
            uniqueidentifier,
            LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(s.value, '""', ''), '[', ''), ']', '')))
        )
    )
)

-- Süreç Kodu
AND
(
    @ProcessCode IS NULL
    OR LTRIM(RTRIM(@ProcessCode)) = ''
    OR UPPER(ISNULL(LTRIM(RTRIM(lp.Code)), '')) IN
    (
        SELECT UPPER(LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', ''))))
        FROM STRING_SPLIT(CAST(@ProcessCode AS NVARCHAR(MAX)), ',')
        WHERE LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', ''))) <> ''
    )
)

-- StepOrder Filtresi (genişletilmiş, -4 eklendi)
AND
(
    @StepOrder IS NULL
    OR @StepOrder = 0   -- Tümü

    -- Aktif: CREATED, TERMIN_PENDING, PENDING, APPROVED, DELIVERY_PENDING
    OR (@StepOrder = -1 AND lp.Code IN ('CREATED','TERMIN_PENDING','PENDING','APPROVED','DELIVERY_PENDING'))

    -- Bugün oluşturulanlar
    OR (
        @StepOrder = -2 
        AND l.CreatedAt >= CAST(GETDATE() AS DATE) 
        AND l.CreatedAt < DATEADD(day, 1, CAST(GETDATE() AS DATE))
    )

    -- Geciken (Termin Tarihi Geçmiş): EstimatedDate bugünden küçük ve sonuçlanmamış
    OR (
        @StepOrder = -3 
        AND l.EstimatedDate < CAST(GETDATE() AS DATE) 
        AND lp.Code NOT IN ('DELIVERED','CLOSED','CUSTOMER_DECLINED','REJECTED')
    )

    -- Bu ayın terminleri
    OR (
        @StepOrder = -4 
        AND l.EstimatedDate >= DATEFROMPARTS(YEAR(GETDATE()), MONTH(GETDATE()), 1)
        AND l.EstimatedDate < DATEADD(MONTH, 1, DATEFROMPARTS(YEAR(GETDATE()), MONTH(GETDATE()), 1))
    )

    -- Rezerv onay bekleyen
    OR (
        @StepOrder = 10 
        AND EXISTS (
            SELECT 1 
            FROM tmscrq.TMLeadReservation r 
            WHERE r.LeadId = l.Id 
              AND r.IsActive = 1 
              AND ISNULL(r.IsApproved,0) = 0
        )
    )

    -- Diğer pozitif StepOrder değerleri
    OR (
        @StepOrder NOT IN (0, -1, -2, -3, -4, 10) 
        AND lp.StepOrder = @StepOrder
    )
)

-- Başlangıç Tarihi
AND
(
    @StartDate IS NULL
    OR LTRIM(RTRIM(@StartDate)) = ''
    OR l.CreatedAt >= CONVERT(date, @StartDate)
)

-- Bitiş Tarihi
AND
(
    @EndDate IS NULL
    OR LTRIM(RTRIM(@EndDate)) = ''
    OR l.CreatedAt < DATEADD(day, 1, CONVERT(date, @EndDate))
)

ORDER BY l.CreatedAt DESC;", new string[] { "RezerveDurumu", "LeadId", "IsReserved", "LeadNumarasi", "TalepTarihi", "ProductId", "ProductName", "Bilezik", "Brand", "Kadran", "RefCode", "Referans", "Musteri", "Lokasyon", "Ilce", "Ulke", "MusteriInfo", "AlisverisiVarMi", "IrtibatNumarasi", "EmailAdresi", "IletisimKaynagi", "CategoryName", "CategoryCode", "LeadDurumu", "SonrakiAdim", "ProcessName", "ProcessCode", "StepOrder", "SelectedStepOrder", "TerminTarihi", "SatisDanismani", "StoreName" }, prms_TM_TopManagerDashboardLeadList_0.ToArray());
            ;


            return Ok(result);
        }


        [HttpPost, Route("DashBoardTempComponent_551457_onClick")]
        public IActionResult DashBoardTempComponent_551457_onClick(DashBoardTempComponent_551457_onClick_Request request)
        {

            KProviderManager.Authorization.IsAuthorizedForRoles(appId, appName, screenId, screenName, new List<string> { $"b4bfd39c-ac02-f442-c899-7a2374a45b47", "70de6cfc-6087-6059-59b4-0b5a8527af6b", "TimesSatisPersoneli", "TimesMagazaMuduru" });

            var result = new DashBoardTempComponent_551457_onClick_Response();

            var prms_TM_TopManagerDashboardLeadList_0 = new List<kSqlParameter>();
            prms_TM_TopManagerDashboardLeadList_0.Add(new kSqlParameter() { Name = "UserId", Value = Kuika.Common.KContext.CurrentUser?.Id });
            prms_TM_TopManagerDashboardLeadList_0.Add(new kSqlParameter() { Name = "MusteriAdi", Value = (null as object) });
            prms_TM_TopManagerDashboardLeadList_0.Add(new kSqlParameter() { Name = "ProductName", Value = (null as object) });
            prms_TM_TopManagerDashboardLeadList_0.Add(new kSqlParameter() { Name = "LeadCode", Value = (null as object) });
            prms_TM_TopManagerDashboardLeadList_0.Add(new kSqlParameter() { Name = "Tel", Value = (null as object) });
            prms_TM_TopManagerDashboardLeadList_0.Add(new kSqlParameter() { Name = "CategoryName", Value = (null as object) });
            prms_TM_TopManagerDashboardLeadList_0.Add(new kSqlParameter() { Name = "StoreIds", Value = (null as object) });
            prms_TM_TopManagerDashboardLeadList_0.Add(new kSqlParameter() { Name = "SatisDanismaniIds", Value = (null as object) });
            prms_TM_TopManagerDashboardLeadList_0.Add(new kSqlParameter() { Name = "ProcessCode", Value = (null as object) });
            prms_TM_TopManagerDashboardLeadList_0.Add(new kSqlParameter() { Name = "StepOrder", Value = "-3".ConvertToType<Int32>() });
            prms_TM_TopManagerDashboardLeadList_0.Add(new kSqlParameter() { Name = "StartDate", Value = (null as object) });
            prms_TM_TopManagerDashboardLeadList_0.Add(new kSqlParameter() { Name = "EndDate", Value = (null as object) });
            using var auditTM_TopManagerDashboardLeadList_0 = ActionAuditScope.Begin("cd833ddf-4487-a53a-012b-deac0b7609fa", "TM_TopManagerDashboardLeadList", applicationName: "wbTimesCRM", screenOrEndpointName: "DashBoardTemp");
            result.TM_TopManagerDashboardLeadList = KPersister.Fetch(KContext.GetConnectionString(), @"SET LANGUAGE Turkish;


SELECT
    CASE 
        WHEN EXISTS (
            SELECT 1 
            FROM tmscrq.TMLeadReservation r
            WHERE r.LeadId = l.Id
              AND r.IsActive = 1
              AND r.IsApproved = 1
        ) THEN N'Evet'
        WHEN EXISTS (
            SELECT 1 
            FROM tmscrq.TMLeadReservation r
            WHERE r.LeadId = l.Id
              AND r.IsActive = 1
              AND ISNULL(r.IsApproved,0) = 0
        ) THEN N'Onay Bekliyor'
        ELSE N'Hayır'
    END AS RezerveDurumu,
    l.Id AS LeadId,
    l.IsReserved,
    ISNULL(NULLIF(LTRIM(RTRIM(l.LeadCode)), ''), '-') AS LeadNumarasi,
    CONVERT(varchar(10), l.CreatedAt, 103) AS TalepTarihi,

    p.Id AS ProductId,
    ISNULL(NULLIF(LTRIM(RTRIM(p.ProductName)), ''), '-') AS ProductName,
    ISNULL(NULLIF(LTRIM(RTRIM(p.Bracelet)), ''), '-') AS Bilezik,
    ISNULL(NULLIF(LTRIM(RTRIM(p.Brand)), ''), '-') AS Brand,
    ISNULL(NULLIF(LTRIM(RTRIM(p.Dial)), ''), '-') AS Kadran,
    ISNULL(NULLIF(LTRIM(RTRIM(p.ProductCode)), ''), '-') AS RefCode,
    ISNULL(NULLIF(LTRIM(RTRIM(p.Referance)), ''), '-') AS Referans,

    ISNULL(
        NULLIF(
            LTRIM(RTRIM(ISNULL(cu.Name, '') + ' ' + ISNULL(cu.LastName, '')))
        , '')
    , '-') AS Musteri,

    ISNULL(NULLIF(LTRIM(RTRIM(cu.CityName)), ''), '-') AS Lokasyon,
    ISNULL(NULLIF(LTRIM(RTRIM(cu.DistrictName)), ''), '-') AS Ilce,
    ISNULL(NULLIF(LTRIM(RTRIM(cu.CountryName)), ''), '-') AS Ulke,
    ISNULL(NULLIF(LTRIM(RTRIM(cu.Info)), ''), '-') AS MusteriInfo,

    CASE
        WHEN cu.IsShopping = 1 THEN N'Evet'
        WHEN cu.IsShopping = 0 THEN N'Hayır'
        ELSE '-'
    END AS AlisverisiVarMi,

    ISNULL(NULLIF(LTRIM(RTRIM(cu.Tel)), ''), '-') AS IrtibatNumarasi,
    ISNULL(NULLIF(LTRIM(RTRIM(cu.Email)), ''), '-') AS EmailAdresi,

    ISNULL(NULLIF(LTRIM(RTRIM(cr.ContactResourceName)), ''), '-') AS IletisimKaynagi,

    ISNULL(NULLIF(LTRIM(RTRIM(p.CategoryName)), ''), '-') AS CategoryName,
    '-' AS CategoryCode,

    ISNULL(NULLIF(LTRIM(RTRIM(ls.Name)), ''), '-') AS LeadDurumu,
    ISNULL(NULLIF(LTRIM(RTRIM(ns.Name)), ''), '-') AS SonrakiAdim,

    ISNULL(NULLIF(LTRIM(RTRIM(lp.Name)), ''), '-') AS ProcessName,
    ISNULL(NULLIF(LTRIM(RTRIM(lp.Code)), ''), '-') AS ProcessCode,
    lp.StepOrder,
    
    CAST(ISNULL(@StepOrder, lp.StepOrder) AS INT) AS SelectedStepOrder,

    ISNULL(
        CASE
            WHEN l.EstimatedDate IS NOT NULL
            THEN CAST(YEAR(l.EstimatedDate) AS VARCHAR(4)) + ' ' + DATENAME(MONTH, l.EstimatedDate)
            ELSE NULL
        END,
        '-'
    ) AS TerminTarihi,

    ISNULL(
        NULLIF(
            LTRIM(RTRIM(ISNULL(sp.FirstName, '') + ' ' + ISNULL(sp.LastName, '')))
        , '')
    , '-') AS SatisDanismani,

    ISNULL(NULLIF(LTRIM(RTRIM(st.StoreDesc)), ''), '-') AS StoreName

FROM tmscrq.TMLead l
LEFT JOIN tmscrq.TMLeadStatu ls ON ls.Id = l.StatuId
LEFT JOIN tmscrq.TMCustomer cu ON cu.Id = l.CustomerId
LEFT JOIN tmscrq.TMProduct p ON p.Id = l.ProductId
LEFT JOIN tmscrq.TMContactResource cr ON cr.Id = l.ContactResourceId
LEFT JOIN dbo.KUser sp ON sp.Id = l.SalesPersonKUserId
LEFT JOIN tmscrq.TMStore st ON st.Id = l.StoreId
LEFT JOIN tmscrq.TMLeadProcess lp ON lp.Id = l.ProcessID
LEFT JOIN tmscrq.TMLeadNextStep ns ON ns.Id = l.NextStepId

WHERE
-- Yetkilendirme
(
    -- Yönetici / Üst Yönetici: Tüm lead'ler
    EXISTS (
        SELECT 1
        FROM dbo.KUserRole ur
        INNER JOIN dbo.KRole r ON r.Id = ur.KRole_Id
        WHERE ur.KUser_Id = @UserId
          AND ur.IsDeleted = 0
          AND r.IsDeleted = 0
          AND r.Name IN ('TimesYonetici', 'TimesUstYonetici')
    )

    OR

    -- Mağaza Müdürü: Kendi mağazasındaki tüm lead'ler
    (
        EXISTS (
            SELECT 1
            FROM dbo.KUserRole ur
            INNER JOIN dbo.KRole r ON r.Id = ur.KRole_Id
            WHERE ur.KUser_Id = @UserId
              AND ur.IsDeleted = 0
              AND r.IsDeleted = 0
              AND r.Name = 'TimesMagazaMuduru'
        )
        AND l.StoreId =
        (
            SELECT TOP 1 tu.StoreID
            FROM tmscrq.TMUser tu
            WHERE tu.KUserID = @UserId
        )
    )

    OR

    -- Satış Personeli: Sadece kendi açtığı lead'ler
    (
        EXISTS (
            SELECT 1
            FROM dbo.KUserRole ur
            INNER JOIN dbo.KRole r ON r.Id = ur.KRole_Id
            WHERE ur.KUser_Id = @UserId
              AND ur.IsDeleted = 0
              AND r.IsDeleted = 0
              AND r.Name = 'TimesSatisPersoneli'
        )
        AND l.SalesPersonKUserId = @UserId
    )
)

-- Müşteri Adı
AND
(
    @MusteriAdi IS NULL
    OR LTRIM(RTRIM(@MusteriAdi)) = ''
    OR UPPER(LTRIM(RTRIM(ISNULL(cu.Name,'') + ' ' + ISNULL(cu.LastName,''))))
       LIKE '%' + UPPER(LTRIM(RTRIM(@MusteriAdi))) + '%'
)

-- Ürün Adı
AND
(
    @ProductName IS NULL
    OR LTRIM(RTRIM(@ProductName)) = ''
    OR
    (
        CHARINDEX(',', @ProductName) > 0
        AND ISNULL(LTRIM(RTRIM(p.ProductName)), '') IN
        (
            SELECT LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', '')))
            FROM STRING_SPLIT(CAST(@ProductName AS NVARCHAR(MAX)), ',')
            WHERE LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', ''))) <> ''
        )
    )
    OR
    (
        CHARINDEX(',', @ProductName) = 0
        AND UPPER(ISNULL(LTRIM(RTRIM(p.ProductName)), ''))
            LIKE '%' + UPPER(LTRIM(RTRIM(@ProductName))) + '%'
    )
)

-- Lead Kodu
AND
(
    @LeadCode IS NULL
    OR LTRIM(RTRIM(@LeadCode)) = ''
    OR UPPER(ISNULL(LTRIM(RTRIM(l.LeadCode)), '')) LIKE '%' + UPPER(LTRIM(RTRIM(@LeadCode))) + '%'
)

-- Telefon
AND
(
    @Tel IS NULL
    OR LTRIM(RTRIM(@Tel)) = ''
    OR UPPER(ISNULL(LTRIM(RTRIM(cu.Tel)), '')) LIKE '%' + UPPER(LTRIM(RTRIM(@Tel))) + '%'
)

-- Kategori
AND
(
    @CategoryName IS NULL
    OR LTRIM(RTRIM(@CategoryName)) = ''
    OR UPPER(ISNULL(LTRIM(RTRIM(p.CategoryName)), '')) IN
    (
        SELECT UPPER(LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value,'""',''),'[',''),']',''))))
        FROM STRING_SPLIT(CAST(@CategoryName AS NVARCHAR(MAX)), ',')
        WHERE LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value,'""',''),'[',''),']',''))) <> ''
    )
)

-- Mağaza
AND
(
    @StoreIds IS NULL
    OR LTRIM(RTRIM(@StoreIds)) = ''
    OR EXISTS
    (
        SELECT 1
        FROM STRING_SPLIT(CAST(@StoreIds AS NVARCHAR(MAX)), ',') s
        WHERE l.StoreId = TRY_CONVERT
        (
            uniqueidentifier,
            LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(s.value, '""', ''), '[', ''), ']', '')))
        )
    )
)

-- Satış Danışmanı
AND
(
    @SatisDanismaniIds IS NULL
    OR LTRIM(RTRIM(@SatisDanismaniIds)) = ''
    OR EXISTS
    (
        SELECT 1
        FROM STRING_SPLIT(CAST(@SatisDanismaniIds AS NVARCHAR(MAX)), ',') s
        WHERE l.SalesPersonKUserId = TRY_CONVERT
        (
            uniqueidentifier,
            LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(s.value, '""', ''), '[', ''), ']', '')))
        )
    )
)

-- Süreç Kodu
AND
(
    @ProcessCode IS NULL
    OR LTRIM(RTRIM(@ProcessCode)) = ''
    OR UPPER(ISNULL(LTRIM(RTRIM(lp.Code)), '')) IN
    (
        SELECT UPPER(LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', ''))))
        FROM STRING_SPLIT(CAST(@ProcessCode AS NVARCHAR(MAX)), ',')
        WHERE LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', ''))) <> ''
    )
)

-- StepOrder Filtresi (genişletilmiş, -4 eklendi)
AND
(
    @StepOrder IS NULL
    OR @StepOrder = 0   -- Tümü

    -- Aktif: CREATED, TERMIN_PENDING, PENDING, APPROVED, DELIVERY_PENDING
    OR (@StepOrder = -1 AND lp.Code IN ('CREATED','TERMIN_PENDING','PENDING','APPROVED','DELIVERY_PENDING'))

    -- Bugün oluşturulanlar
    OR (
        @StepOrder = -2 
        AND l.CreatedAt >= CAST(GETDATE() AS DATE) 
        AND l.CreatedAt < DATEADD(day, 1, CAST(GETDATE() AS DATE))
    )

    -- Geciken (Termin Tarihi Geçmiş): EstimatedDate bugünden küçük ve sonuçlanmamış
    OR (
        @StepOrder = -3 
        AND l.EstimatedDate < CAST(GETDATE() AS DATE) 
        AND lp.Code NOT IN ('DELIVERED','CLOSED','CUSTOMER_DECLINED','REJECTED')
    )

    -- Bu ayın terminleri
    OR (
        @StepOrder = -4 
        AND l.EstimatedDate >= DATEFROMPARTS(YEAR(GETDATE()), MONTH(GETDATE()), 1)
        AND l.EstimatedDate < DATEADD(MONTH, 1, DATEFROMPARTS(YEAR(GETDATE()), MONTH(GETDATE()), 1))
    )

    -- Rezerv onay bekleyen
    OR (
        @StepOrder = 10 
        AND EXISTS (
            SELECT 1 
            FROM tmscrq.TMLeadReservation r 
            WHERE r.LeadId = l.Id 
              AND r.IsActive = 1 
              AND ISNULL(r.IsApproved,0) = 0
        )
    )

    -- Diğer pozitif StepOrder değerleri
    OR (
        @StepOrder NOT IN (0, -1, -2, -3, -4, 10) 
        AND lp.StepOrder = @StepOrder
    )
)

-- Başlangıç Tarihi
AND
(
    @StartDate IS NULL
    OR LTRIM(RTRIM(@StartDate)) = ''
    OR l.CreatedAt >= CONVERT(date, @StartDate)
)

-- Bitiş Tarihi
AND
(
    @EndDate IS NULL
    OR LTRIM(RTRIM(@EndDate)) = ''
    OR l.CreatedAt < DATEADD(day, 1, CONVERT(date, @EndDate))
)

ORDER BY l.CreatedAt DESC;", new string[] { "RezerveDurumu", "LeadId", "IsReserved", "LeadNumarasi", "TalepTarihi", "ProductId", "ProductName", "Bilezik", "Brand", "Kadran", "RefCode", "Referans", "Musteri", "Lokasyon", "Ilce", "Ulke", "MusteriInfo", "AlisverisiVarMi", "IrtibatNumarasi", "EmailAdresi", "IletisimKaynagi", "CategoryName", "CategoryCode", "LeadDurumu", "SonrakiAdim", "ProcessName", "ProcessCode", "StepOrder", "SelectedStepOrder", "TerminTarihi", "SatisDanismani", "StoreName" }, prms_TM_TopManagerDashboardLeadList_0.ToArray());
            ;


            return Ok(result);
        }


        [HttpPost, Route("DashBoardTempComponent_4159_onClick")]
        public IActionResult DashBoardTempComponent_4159_onClick(DashBoardTempComponent_4159_onClick_Request request)
        {

            KProviderManager.Authorization.IsAuthorizedForRoles(appId, appName, screenId, screenName, new List<string> { $"b4bfd39c-ac02-f442-c899-7a2374a45b47", "70de6cfc-6087-6059-59b4-0b5a8527af6b", "TimesSatisPersoneli", "TimesMagazaMuduru" });

            var result = new DashBoardTempComponent_4159_onClick_Response();

            var prms_TM_TopManagerDashboardLeadList_0 = new List<kSqlParameter>();
            prms_TM_TopManagerDashboardLeadList_0.Add(new kSqlParameter() { Name = "UserId", Value = Kuika.Common.KContext.CurrentUser?.Id });
            prms_TM_TopManagerDashboardLeadList_0.Add(new kSqlParameter() { Name = "MusteriAdi", Value = (null as object) });
            prms_TM_TopManagerDashboardLeadList_0.Add(new kSqlParameter() { Name = "ProductName", Value = (null as object) });
            prms_TM_TopManagerDashboardLeadList_0.Add(new kSqlParameter() { Name = "LeadCode", Value = (null as object) });
            prms_TM_TopManagerDashboardLeadList_0.Add(new kSqlParameter() { Name = "Tel", Value = (null as object) });
            prms_TM_TopManagerDashboardLeadList_0.Add(new kSqlParameter() { Name = "CategoryName", Value = (null as object) });
            prms_TM_TopManagerDashboardLeadList_0.Add(new kSqlParameter() { Name = "StoreIds", Value = (null as object) });
            prms_TM_TopManagerDashboardLeadList_0.Add(new kSqlParameter() { Name = "SatisDanismaniIds", Value = (null as object) });
            prms_TM_TopManagerDashboardLeadList_0.Add(new kSqlParameter() { Name = "ProcessCode", Value = (null as object) });
            prms_TM_TopManagerDashboardLeadList_0.Add(new kSqlParameter() { Name = "StepOrder", Value = "2".ConvertToType<Int32>() });
            prms_TM_TopManagerDashboardLeadList_0.Add(new kSqlParameter() { Name = "StartDate", Value = (null as object) });
            prms_TM_TopManagerDashboardLeadList_0.Add(new kSqlParameter() { Name = "EndDate", Value = (null as object) });
            using var auditTM_TopManagerDashboardLeadList_0 = ActionAuditScope.Begin("f7fcb348-cef6-4743-7c0e-b0dface75d86", "TM_TopManagerDashboardLeadList", applicationName: "wbTimesCRM", screenOrEndpointName: "DashBoardTemp");
            result.TM_TopManagerDashboardLeadList = KPersister.Fetch(KContext.GetConnectionString(), @"SET LANGUAGE Turkish;


SELECT
    CASE 
        WHEN EXISTS (
            SELECT 1 
            FROM tmscrq.TMLeadReservation r
            WHERE r.LeadId = l.Id
              AND r.IsActive = 1
              AND r.IsApproved = 1
        ) THEN N'Evet'
        WHEN EXISTS (
            SELECT 1 
            FROM tmscrq.TMLeadReservation r
            WHERE r.LeadId = l.Id
              AND r.IsActive = 1
              AND ISNULL(r.IsApproved,0) = 0
        ) THEN N'Onay Bekliyor'
        ELSE N'Hayır'
    END AS RezerveDurumu,
    l.Id AS LeadId,
    l.IsReserved,
    ISNULL(NULLIF(LTRIM(RTRIM(l.LeadCode)), ''), '-') AS LeadNumarasi,
    CONVERT(varchar(10), l.CreatedAt, 103) AS TalepTarihi,

    p.Id AS ProductId,
    ISNULL(NULLIF(LTRIM(RTRIM(p.ProductName)), ''), '-') AS ProductName,
    ISNULL(NULLIF(LTRIM(RTRIM(p.Bracelet)), ''), '-') AS Bilezik,
    ISNULL(NULLIF(LTRIM(RTRIM(p.Brand)), ''), '-') AS Brand,
    ISNULL(NULLIF(LTRIM(RTRIM(p.Dial)), ''), '-') AS Kadran,
    ISNULL(NULLIF(LTRIM(RTRIM(p.ProductCode)), ''), '-') AS RefCode,
    ISNULL(NULLIF(LTRIM(RTRIM(p.Referance)), ''), '-') AS Referans,

    ISNULL(
        NULLIF(
            LTRIM(RTRIM(ISNULL(cu.Name, '') + ' ' + ISNULL(cu.LastName, '')))
        , '')
    , '-') AS Musteri,

    ISNULL(NULLIF(LTRIM(RTRIM(cu.CityName)), ''), '-') AS Lokasyon,
    ISNULL(NULLIF(LTRIM(RTRIM(cu.DistrictName)), ''), '-') AS Ilce,
    ISNULL(NULLIF(LTRIM(RTRIM(cu.CountryName)), ''), '-') AS Ulke,
    ISNULL(NULLIF(LTRIM(RTRIM(cu.Info)), ''), '-') AS MusteriInfo,

    CASE
        WHEN cu.IsShopping = 1 THEN N'Evet'
        WHEN cu.IsShopping = 0 THEN N'Hayır'
        ELSE '-'
    END AS AlisverisiVarMi,

    ISNULL(NULLIF(LTRIM(RTRIM(cu.Tel)), ''), '-') AS IrtibatNumarasi,
    ISNULL(NULLIF(LTRIM(RTRIM(cu.Email)), ''), '-') AS EmailAdresi,

    ISNULL(NULLIF(LTRIM(RTRIM(cr.ContactResourceName)), ''), '-') AS IletisimKaynagi,

    ISNULL(NULLIF(LTRIM(RTRIM(p.CategoryName)), ''), '-') AS CategoryName,
    '-' AS CategoryCode,

    ISNULL(NULLIF(LTRIM(RTRIM(ls.Name)), ''), '-') AS LeadDurumu,
    ISNULL(NULLIF(LTRIM(RTRIM(ns.Name)), ''), '-') AS SonrakiAdim,

    ISNULL(NULLIF(LTRIM(RTRIM(lp.Name)), ''), '-') AS ProcessName,
    ISNULL(NULLIF(LTRIM(RTRIM(lp.Code)), ''), '-') AS ProcessCode,
    lp.StepOrder,
    
    CAST(ISNULL(@StepOrder, lp.StepOrder) AS INT) AS SelectedStepOrder,

    ISNULL(
        CASE
            WHEN l.EstimatedDate IS NOT NULL
            THEN CAST(YEAR(l.EstimatedDate) AS VARCHAR(4)) + ' ' + DATENAME(MONTH, l.EstimatedDate)
            ELSE NULL
        END,
        '-'
    ) AS TerminTarihi,

    ISNULL(
        NULLIF(
            LTRIM(RTRIM(ISNULL(sp.FirstName, '') + ' ' + ISNULL(sp.LastName, '')))
        , '')
    , '-') AS SatisDanismani,

    ISNULL(NULLIF(LTRIM(RTRIM(st.StoreDesc)), ''), '-') AS StoreName

FROM tmscrq.TMLead l
LEFT JOIN tmscrq.TMLeadStatu ls ON ls.Id = l.StatuId
LEFT JOIN tmscrq.TMCustomer cu ON cu.Id = l.CustomerId
LEFT JOIN tmscrq.TMProduct p ON p.Id = l.ProductId
LEFT JOIN tmscrq.TMContactResource cr ON cr.Id = l.ContactResourceId
LEFT JOIN dbo.KUser sp ON sp.Id = l.SalesPersonKUserId
LEFT JOIN tmscrq.TMStore st ON st.Id = l.StoreId
LEFT JOIN tmscrq.TMLeadProcess lp ON lp.Id = l.ProcessID
LEFT JOIN tmscrq.TMLeadNextStep ns ON ns.Id = l.NextStepId

WHERE
-- Yetkilendirme
(
    -- Yönetici / Üst Yönetici: Tüm lead'ler
    EXISTS (
        SELECT 1
        FROM dbo.KUserRole ur
        INNER JOIN dbo.KRole r ON r.Id = ur.KRole_Id
        WHERE ur.KUser_Id = @UserId
          AND ur.IsDeleted = 0
          AND r.IsDeleted = 0
          AND r.Name IN ('TimesYonetici', 'TimesUstYonetici')
    )

    OR

    -- Mağaza Müdürü: Kendi mağazasındaki tüm lead'ler
    (
        EXISTS (
            SELECT 1
            FROM dbo.KUserRole ur
            INNER JOIN dbo.KRole r ON r.Id = ur.KRole_Id
            WHERE ur.KUser_Id = @UserId
              AND ur.IsDeleted = 0
              AND r.IsDeleted = 0
              AND r.Name = 'TimesMagazaMuduru'
        )
        AND l.StoreId =
        (
            SELECT TOP 1 tu.StoreID
            FROM tmscrq.TMUser tu
            WHERE tu.KUserID = @UserId
        )
    )

    OR

    -- Satış Personeli: Sadece kendi açtığı lead'ler
    (
        EXISTS (
            SELECT 1
            FROM dbo.KUserRole ur
            INNER JOIN dbo.KRole r ON r.Id = ur.KRole_Id
            WHERE ur.KUser_Id = @UserId
              AND ur.IsDeleted = 0
              AND r.IsDeleted = 0
              AND r.Name = 'TimesSatisPersoneli'
        )
        AND l.SalesPersonKUserId = @UserId
    )
)

-- Müşteri Adı
AND
(
    @MusteriAdi IS NULL
    OR LTRIM(RTRIM(@MusteriAdi)) = ''
    OR UPPER(LTRIM(RTRIM(ISNULL(cu.Name,'') + ' ' + ISNULL(cu.LastName,''))))
       LIKE '%' + UPPER(LTRIM(RTRIM(@MusteriAdi))) + '%'
)

-- Ürün Adı
AND
(
    @ProductName IS NULL
    OR LTRIM(RTRIM(@ProductName)) = ''
    OR
    (
        CHARINDEX(',', @ProductName) > 0
        AND ISNULL(LTRIM(RTRIM(p.ProductName)), '') IN
        (
            SELECT LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', '')))
            FROM STRING_SPLIT(CAST(@ProductName AS NVARCHAR(MAX)), ',')
            WHERE LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', ''))) <> ''
        )
    )
    OR
    (
        CHARINDEX(',', @ProductName) = 0
        AND UPPER(ISNULL(LTRIM(RTRIM(p.ProductName)), ''))
            LIKE '%' + UPPER(LTRIM(RTRIM(@ProductName))) + '%'
    )
)

-- Lead Kodu
AND
(
    @LeadCode IS NULL
    OR LTRIM(RTRIM(@LeadCode)) = ''
    OR UPPER(ISNULL(LTRIM(RTRIM(l.LeadCode)), '')) LIKE '%' + UPPER(LTRIM(RTRIM(@LeadCode))) + '%'
)

-- Telefon
AND
(
    @Tel IS NULL
    OR LTRIM(RTRIM(@Tel)) = ''
    OR UPPER(ISNULL(LTRIM(RTRIM(cu.Tel)), '')) LIKE '%' + UPPER(LTRIM(RTRIM(@Tel))) + '%'
)

-- Kategori
AND
(
    @CategoryName IS NULL
    OR LTRIM(RTRIM(@CategoryName)) = ''
    OR UPPER(ISNULL(LTRIM(RTRIM(p.CategoryName)), '')) IN
    (
        SELECT UPPER(LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value,'""',''),'[',''),']',''))))
        FROM STRING_SPLIT(CAST(@CategoryName AS NVARCHAR(MAX)), ',')
        WHERE LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value,'""',''),'[',''),']',''))) <> ''
    )
)

-- Mağaza
AND
(
    @StoreIds IS NULL
    OR LTRIM(RTRIM(@StoreIds)) = ''
    OR EXISTS
    (
        SELECT 1
        FROM STRING_SPLIT(CAST(@StoreIds AS NVARCHAR(MAX)), ',') s
        WHERE l.StoreId = TRY_CONVERT
        (
            uniqueidentifier,
            LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(s.value, '""', ''), '[', ''), ']', '')))
        )
    )
)

-- Satış Danışmanı
AND
(
    @SatisDanismaniIds IS NULL
    OR LTRIM(RTRIM(@SatisDanismaniIds)) = ''
    OR EXISTS
    (
        SELECT 1
        FROM STRING_SPLIT(CAST(@SatisDanismaniIds AS NVARCHAR(MAX)), ',') s
        WHERE l.SalesPersonKUserId = TRY_CONVERT
        (
            uniqueidentifier,
            LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(s.value, '""', ''), '[', ''), ']', '')))
        )
    )
)

-- Süreç Kodu
AND
(
    @ProcessCode IS NULL
    OR LTRIM(RTRIM(@ProcessCode)) = ''
    OR UPPER(ISNULL(LTRIM(RTRIM(lp.Code)), '')) IN
    (
        SELECT UPPER(LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', ''))))
        FROM STRING_SPLIT(CAST(@ProcessCode AS NVARCHAR(MAX)), ',')
        WHERE LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', ''))) <> ''
    )
)

-- StepOrder Filtresi (genişletilmiş, -4 eklendi)
AND
(
    @StepOrder IS NULL
    OR @StepOrder = 0   -- Tümü

    -- Aktif: CREATED, TERMIN_PENDING, PENDING, APPROVED, DELIVERY_PENDING
    OR (@StepOrder = -1 AND lp.Code IN ('CREATED','TERMIN_PENDING','PENDING','APPROVED','DELIVERY_PENDING'))

    -- Bugün oluşturulanlar
    OR (
        @StepOrder = -2 
        AND l.CreatedAt >= CAST(GETDATE() AS DATE) 
        AND l.CreatedAt < DATEADD(day, 1, CAST(GETDATE() AS DATE))
    )

    -- Geciken (Termin Tarihi Geçmiş): EstimatedDate bugünden küçük ve sonuçlanmamış
    OR (
        @StepOrder = -3 
        AND l.EstimatedDate < CAST(GETDATE() AS DATE) 
        AND lp.Code NOT IN ('DELIVERED','CLOSED','CUSTOMER_DECLINED','REJECTED')
    )

    -- Bu ayın terminleri
    OR (
        @StepOrder = -4 
        AND l.EstimatedDate >= DATEFROMPARTS(YEAR(GETDATE()), MONTH(GETDATE()), 1)
        AND l.EstimatedDate < DATEADD(MONTH, 1, DATEFROMPARTS(YEAR(GETDATE()), MONTH(GETDATE()), 1))
    )

    -- Rezerv onay bekleyen
    OR (
        @StepOrder = 10 
        AND EXISTS (
            SELECT 1 
            FROM tmscrq.TMLeadReservation r 
            WHERE r.LeadId = l.Id 
              AND r.IsActive = 1 
              AND ISNULL(r.IsApproved,0) = 0
        )
    )

    -- Diğer pozitif StepOrder değerleri
    OR (
        @StepOrder NOT IN (0, -1, -2, -3, -4, 10) 
        AND lp.StepOrder = @StepOrder
    )
)

-- Başlangıç Tarihi
AND
(
    @StartDate IS NULL
    OR LTRIM(RTRIM(@StartDate)) = ''
    OR l.CreatedAt >= CONVERT(date, @StartDate)
)

-- Bitiş Tarihi
AND
(
    @EndDate IS NULL
    OR LTRIM(RTRIM(@EndDate)) = ''
    OR l.CreatedAt < DATEADD(day, 1, CONVERT(date, @EndDate))
)

ORDER BY l.CreatedAt DESC;", new string[] { "RezerveDurumu", "LeadId", "IsReserved", "LeadNumarasi", "TalepTarihi", "ProductId", "ProductName", "Bilezik", "Brand", "Kadran", "RefCode", "Referans", "Musteri", "Lokasyon", "Ilce", "Ulke", "MusteriInfo", "AlisverisiVarMi", "IrtibatNumarasi", "EmailAdresi", "IletisimKaynagi", "CategoryName", "CategoryCode", "LeadDurumu", "SonrakiAdim", "ProcessName", "ProcessCode", "StepOrder", "SelectedStepOrder", "TerminTarihi", "SatisDanismani", "StoreName" }, prms_TM_TopManagerDashboardLeadList_0.ToArray());
            ;


            return Ok(result);
        }


        [HttpPost, Route("DashBoardTempComponent_397882_onClick")]
        public IActionResult DashBoardTempComponent_397882_onClick(DashBoardTempComponent_397882_onClick_Request request)
        {

            KProviderManager.Authorization.IsAuthorizedForRoles(appId, appName, screenId, screenName, new List<string> { $"b4bfd39c-ac02-f442-c899-7a2374a45b47", "70de6cfc-6087-6059-59b4-0b5a8527af6b", "TimesSatisPersoneli", "TimesMagazaMuduru" });

            var result = new DashBoardTempComponent_397882_onClick_Response();

            var prms_TM_TopManagerDashboardLeadList_0 = new List<kSqlParameter>();
            prms_TM_TopManagerDashboardLeadList_0.Add(new kSqlParameter() { Name = "UserId", Value = Kuika.Common.KContext.CurrentUser?.Id });
            prms_TM_TopManagerDashboardLeadList_0.Add(new kSqlParameter() { Name = "MusteriAdi", Value = (null as object) });
            prms_TM_TopManagerDashboardLeadList_0.Add(new kSqlParameter() { Name = "ProductName", Value = (null as object) });
            prms_TM_TopManagerDashboardLeadList_0.Add(new kSqlParameter() { Name = "LeadCode", Value = (null as object) });
            prms_TM_TopManagerDashboardLeadList_0.Add(new kSqlParameter() { Name = "Tel", Value = (null as object) });
            prms_TM_TopManagerDashboardLeadList_0.Add(new kSqlParameter() { Name = "CategoryName", Value = (null as object) });
            prms_TM_TopManagerDashboardLeadList_0.Add(new kSqlParameter() { Name = "StoreIds", Value = (null as object) });
            prms_TM_TopManagerDashboardLeadList_0.Add(new kSqlParameter() { Name = "SatisDanismaniIds", Value = (null as object) });
            prms_TM_TopManagerDashboardLeadList_0.Add(new kSqlParameter() { Name = "ProcessCode", Value = (null as object) });
            prms_TM_TopManagerDashboardLeadList_0.Add(new kSqlParameter() { Name = "StepOrder", Value = "3".ConvertToType<Int32>() });
            prms_TM_TopManagerDashboardLeadList_0.Add(new kSqlParameter() { Name = "StartDate", Value = (null as object) });
            prms_TM_TopManagerDashboardLeadList_0.Add(new kSqlParameter() { Name = "EndDate", Value = (null as object) });
            using var auditTM_TopManagerDashboardLeadList_0 = ActionAuditScope.Begin("0972cf50-e59a-d562-9452-6595465688cd", "TM_TopManagerDashboardLeadList", applicationName: "wbTimesCRM", screenOrEndpointName: "DashBoardTemp");
            result.TM_TopManagerDashboardLeadList = KPersister.Fetch(KContext.GetConnectionString(), @"SET LANGUAGE Turkish;


SELECT
    CASE 
        WHEN EXISTS (
            SELECT 1 
            FROM tmscrq.TMLeadReservation r
            WHERE r.LeadId = l.Id
              AND r.IsActive = 1
              AND r.IsApproved = 1
        ) THEN N'Evet'
        WHEN EXISTS (
            SELECT 1 
            FROM tmscrq.TMLeadReservation r
            WHERE r.LeadId = l.Id
              AND r.IsActive = 1
              AND ISNULL(r.IsApproved,0) = 0
        ) THEN N'Onay Bekliyor'
        ELSE N'Hayır'
    END AS RezerveDurumu,
    l.Id AS LeadId,
    l.IsReserved,
    ISNULL(NULLIF(LTRIM(RTRIM(l.LeadCode)), ''), '-') AS LeadNumarasi,
    CONVERT(varchar(10), l.CreatedAt, 103) AS TalepTarihi,

    p.Id AS ProductId,
    ISNULL(NULLIF(LTRIM(RTRIM(p.ProductName)), ''), '-') AS ProductName,
    ISNULL(NULLIF(LTRIM(RTRIM(p.Bracelet)), ''), '-') AS Bilezik,
    ISNULL(NULLIF(LTRIM(RTRIM(p.Brand)), ''), '-') AS Brand,
    ISNULL(NULLIF(LTRIM(RTRIM(p.Dial)), ''), '-') AS Kadran,
    ISNULL(NULLIF(LTRIM(RTRIM(p.ProductCode)), ''), '-') AS RefCode,
    ISNULL(NULLIF(LTRIM(RTRIM(p.Referance)), ''), '-') AS Referans,

    ISNULL(
        NULLIF(
            LTRIM(RTRIM(ISNULL(cu.Name, '') + ' ' + ISNULL(cu.LastName, '')))
        , '')
    , '-') AS Musteri,

    ISNULL(NULLIF(LTRIM(RTRIM(cu.CityName)), ''), '-') AS Lokasyon,
    ISNULL(NULLIF(LTRIM(RTRIM(cu.DistrictName)), ''), '-') AS Ilce,
    ISNULL(NULLIF(LTRIM(RTRIM(cu.CountryName)), ''), '-') AS Ulke,
    ISNULL(NULLIF(LTRIM(RTRIM(cu.Info)), ''), '-') AS MusteriInfo,

    CASE
        WHEN cu.IsShopping = 1 THEN N'Evet'
        WHEN cu.IsShopping = 0 THEN N'Hayır'
        ELSE '-'
    END AS AlisverisiVarMi,

    ISNULL(NULLIF(LTRIM(RTRIM(cu.Tel)), ''), '-') AS IrtibatNumarasi,
    ISNULL(NULLIF(LTRIM(RTRIM(cu.Email)), ''), '-') AS EmailAdresi,

    ISNULL(NULLIF(LTRIM(RTRIM(cr.ContactResourceName)), ''), '-') AS IletisimKaynagi,

    ISNULL(NULLIF(LTRIM(RTRIM(p.CategoryName)), ''), '-') AS CategoryName,
    '-' AS CategoryCode,

    ISNULL(NULLIF(LTRIM(RTRIM(ls.Name)), ''), '-') AS LeadDurumu,
    ISNULL(NULLIF(LTRIM(RTRIM(ns.Name)), ''), '-') AS SonrakiAdim,

    ISNULL(NULLIF(LTRIM(RTRIM(lp.Name)), ''), '-') AS ProcessName,
    ISNULL(NULLIF(LTRIM(RTRIM(lp.Code)), ''), '-') AS ProcessCode,
    lp.StepOrder,
    
    CAST(ISNULL(@StepOrder, lp.StepOrder) AS INT) AS SelectedStepOrder,

    ISNULL(
        CASE
            WHEN l.EstimatedDate IS NOT NULL
            THEN CAST(YEAR(l.EstimatedDate) AS VARCHAR(4)) + ' ' + DATENAME(MONTH, l.EstimatedDate)
            ELSE NULL
        END,
        '-'
    ) AS TerminTarihi,

    ISNULL(
        NULLIF(
            LTRIM(RTRIM(ISNULL(sp.FirstName, '') + ' ' + ISNULL(sp.LastName, '')))
        , '')
    , '-') AS SatisDanismani,

    ISNULL(NULLIF(LTRIM(RTRIM(st.StoreDesc)), ''), '-') AS StoreName

FROM tmscrq.TMLead l
LEFT JOIN tmscrq.TMLeadStatu ls ON ls.Id = l.StatuId
LEFT JOIN tmscrq.TMCustomer cu ON cu.Id = l.CustomerId
LEFT JOIN tmscrq.TMProduct p ON p.Id = l.ProductId
LEFT JOIN tmscrq.TMContactResource cr ON cr.Id = l.ContactResourceId
LEFT JOIN dbo.KUser sp ON sp.Id = l.SalesPersonKUserId
LEFT JOIN tmscrq.TMStore st ON st.Id = l.StoreId
LEFT JOIN tmscrq.TMLeadProcess lp ON lp.Id = l.ProcessID
LEFT JOIN tmscrq.TMLeadNextStep ns ON ns.Id = l.NextStepId

WHERE
-- Yetkilendirme
(
    -- Yönetici / Üst Yönetici: Tüm lead'ler
    EXISTS (
        SELECT 1
        FROM dbo.KUserRole ur
        INNER JOIN dbo.KRole r ON r.Id = ur.KRole_Id
        WHERE ur.KUser_Id = @UserId
          AND ur.IsDeleted = 0
          AND r.IsDeleted = 0
          AND r.Name IN ('TimesYonetici', 'TimesUstYonetici')
    )

    OR

    -- Mağaza Müdürü: Kendi mağazasındaki tüm lead'ler
    (
        EXISTS (
            SELECT 1
            FROM dbo.KUserRole ur
            INNER JOIN dbo.KRole r ON r.Id = ur.KRole_Id
            WHERE ur.KUser_Id = @UserId
              AND ur.IsDeleted = 0
              AND r.IsDeleted = 0
              AND r.Name = 'TimesMagazaMuduru'
        )
        AND l.StoreId =
        (
            SELECT TOP 1 tu.StoreID
            FROM tmscrq.TMUser tu
            WHERE tu.KUserID = @UserId
        )
    )

    OR

    -- Satış Personeli: Sadece kendi açtığı lead'ler
    (
        EXISTS (
            SELECT 1
            FROM dbo.KUserRole ur
            INNER JOIN dbo.KRole r ON r.Id = ur.KRole_Id
            WHERE ur.KUser_Id = @UserId
              AND ur.IsDeleted = 0
              AND r.IsDeleted = 0
              AND r.Name = 'TimesSatisPersoneli'
        )
        AND l.SalesPersonKUserId = @UserId
    )
)

-- Müşteri Adı
AND
(
    @MusteriAdi IS NULL
    OR LTRIM(RTRIM(@MusteriAdi)) = ''
    OR UPPER(LTRIM(RTRIM(ISNULL(cu.Name,'') + ' ' + ISNULL(cu.LastName,''))))
       LIKE '%' + UPPER(LTRIM(RTRIM(@MusteriAdi))) + '%'
)

-- Ürün Adı
AND
(
    @ProductName IS NULL
    OR LTRIM(RTRIM(@ProductName)) = ''
    OR
    (
        CHARINDEX(',', @ProductName) > 0
        AND ISNULL(LTRIM(RTRIM(p.ProductName)), '') IN
        (
            SELECT LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', '')))
            FROM STRING_SPLIT(CAST(@ProductName AS NVARCHAR(MAX)), ',')
            WHERE LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', ''))) <> ''
        )
    )
    OR
    (
        CHARINDEX(',', @ProductName) = 0
        AND UPPER(ISNULL(LTRIM(RTRIM(p.ProductName)), ''))
            LIKE '%' + UPPER(LTRIM(RTRIM(@ProductName))) + '%'
    )
)

-- Lead Kodu
AND
(
    @LeadCode IS NULL
    OR LTRIM(RTRIM(@LeadCode)) = ''
    OR UPPER(ISNULL(LTRIM(RTRIM(l.LeadCode)), '')) LIKE '%' + UPPER(LTRIM(RTRIM(@LeadCode))) + '%'
)

-- Telefon
AND
(
    @Tel IS NULL
    OR LTRIM(RTRIM(@Tel)) = ''
    OR UPPER(ISNULL(LTRIM(RTRIM(cu.Tel)), '')) LIKE '%' + UPPER(LTRIM(RTRIM(@Tel))) + '%'
)

-- Kategori
AND
(
    @CategoryName IS NULL
    OR LTRIM(RTRIM(@CategoryName)) = ''
    OR UPPER(ISNULL(LTRIM(RTRIM(p.CategoryName)), '')) IN
    (
        SELECT UPPER(LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value,'""',''),'[',''),']',''))))
        FROM STRING_SPLIT(CAST(@CategoryName AS NVARCHAR(MAX)), ',')
        WHERE LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value,'""',''),'[',''),']',''))) <> ''
    )
)

-- Mağaza
AND
(
    @StoreIds IS NULL
    OR LTRIM(RTRIM(@StoreIds)) = ''
    OR EXISTS
    (
        SELECT 1
        FROM STRING_SPLIT(CAST(@StoreIds AS NVARCHAR(MAX)), ',') s
        WHERE l.StoreId = TRY_CONVERT
        (
            uniqueidentifier,
            LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(s.value, '""', ''), '[', ''), ']', '')))
        )
    )
)

-- Satış Danışmanı
AND
(
    @SatisDanismaniIds IS NULL
    OR LTRIM(RTRIM(@SatisDanismaniIds)) = ''
    OR EXISTS
    (
        SELECT 1
        FROM STRING_SPLIT(CAST(@SatisDanismaniIds AS NVARCHAR(MAX)), ',') s
        WHERE l.SalesPersonKUserId = TRY_CONVERT
        (
            uniqueidentifier,
            LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(s.value, '""', ''), '[', ''), ']', '')))
        )
    )
)

-- Süreç Kodu
AND
(
    @ProcessCode IS NULL
    OR LTRIM(RTRIM(@ProcessCode)) = ''
    OR UPPER(ISNULL(LTRIM(RTRIM(lp.Code)), '')) IN
    (
        SELECT UPPER(LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', ''))))
        FROM STRING_SPLIT(CAST(@ProcessCode AS NVARCHAR(MAX)), ',')
        WHERE LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', ''))) <> ''
    )
)

-- StepOrder Filtresi (genişletilmiş, -4 eklendi)
AND
(
    @StepOrder IS NULL
    OR @StepOrder = 0   -- Tümü

    -- Aktif: CREATED, TERMIN_PENDING, PENDING, APPROVED, DELIVERY_PENDING
    OR (@StepOrder = -1 AND lp.Code IN ('CREATED','TERMIN_PENDING','PENDING','APPROVED','DELIVERY_PENDING'))

    -- Bugün oluşturulanlar
    OR (
        @StepOrder = -2 
        AND l.CreatedAt >= CAST(GETDATE() AS DATE) 
        AND l.CreatedAt < DATEADD(day, 1, CAST(GETDATE() AS DATE))
    )

    -- Geciken (Termin Tarihi Geçmiş): EstimatedDate bugünden küçük ve sonuçlanmamış
    OR (
        @StepOrder = -3 
        AND l.EstimatedDate < CAST(GETDATE() AS DATE) 
        AND lp.Code NOT IN ('DELIVERED','CLOSED','CUSTOMER_DECLINED','REJECTED')
    )

    -- Bu ayın terminleri
    OR (
        @StepOrder = -4 
        AND l.EstimatedDate >= DATEFROMPARTS(YEAR(GETDATE()), MONTH(GETDATE()), 1)
        AND l.EstimatedDate < DATEADD(MONTH, 1, DATEFROMPARTS(YEAR(GETDATE()), MONTH(GETDATE()), 1))
    )

    -- Rezerv onay bekleyen
    OR (
        @StepOrder = 10 
        AND EXISTS (
            SELECT 1 
            FROM tmscrq.TMLeadReservation r 
            WHERE r.LeadId = l.Id 
              AND r.IsActive = 1 
              AND ISNULL(r.IsApproved,0) = 0
        )
    )

    -- Diğer pozitif StepOrder değerleri
    OR (
        @StepOrder NOT IN (0, -1, -2, -3, -4, 10) 
        AND lp.StepOrder = @StepOrder
    )
)

-- Başlangıç Tarihi
AND
(
    @StartDate IS NULL
    OR LTRIM(RTRIM(@StartDate)) = ''
    OR l.CreatedAt >= CONVERT(date, @StartDate)
)

-- Bitiş Tarihi
AND
(
    @EndDate IS NULL
    OR LTRIM(RTRIM(@EndDate)) = ''
    OR l.CreatedAt < DATEADD(day, 1, CONVERT(date, @EndDate))
)

ORDER BY l.CreatedAt DESC;", new string[] { "RezerveDurumu", "LeadId", "IsReserved", "LeadNumarasi", "TalepTarihi", "ProductId", "ProductName", "Bilezik", "Brand", "Kadran", "RefCode", "Referans", "Musteri", "Lokasyon", "Ilce", "Ulke", "MusteriInfo", "AlisverisiVarMi", "IrtibatNumarasi", "EmailAdresi", "IletisimKaynagi", "CategoryName", "CategoryCode", "LeadDurumu", "SonrakiAdim", "ProcessName", "ProcessCode", "StepOrder", "SelectedStepOrder", "TerminTarihi", "SatisDanismani", "StoreName" }, prms_TM_TopManagerDashboardLeadList_0.ToArray());
            ;


            return Ok(result);
        }


        [HttpPost, Route("DashBoardTempComponent_489263_onClick")]
        public IActionResult DashBoardTempComponent_489263_onClick(DashBoardTempComponent_489263_onClick_Request request)
        {

            KProviderManager.Authorization.IsAuthorizedForRoles(appId, appName, screenId, screenName, new List<string> { $"b4bfd39c-ac02-f442-c899-7a2374a45b47", "70de6cfc-6087-6059-59b4-0b5a8527af6b", "TimesSatisPersoneli", "TimesMagazaMuduru" });

            var result = new DashBoardTempComponent_489263_onClick_Response();

            var prms_TM_TopManagerDashboardLeadList_0 = new List<kSqlParameter>();
            prms_TM_TopManagerDashboardLeadList_0.Add(new kSqlParameter() { Name = "UserId", Value = Kuika.Common.KContext.CurrentUser?.Id });
            prms_TM_TopManagerDashboardLeadList_0.Add(new kSqlParameter() { Name = "MusteriAdi", Value = (null as object) });
            prms_TM_TopManagerDashboardLeadList_0.Add(new kSqlParameter() { Name = "ProductName", Value = (null as object) });
            prms_TM_TopManagerDashboardLeadList_0.Add(new kSqlParameter() { Name = "LeadCode", Value = (null as object) });
            prms_TM_TopManagerDashboardLeadList_0.Add(new kSqlParameter() { Name = "Tel", Value = (null as object) });
            prms_TM_TopManagerDashboardLeadList_0.Add(new kSqlParameter() { Name = "CategoryName", Value = (null as object) });
            prms_TM_TopManagerDashboardLeadList_0.Add(new kSqlParameter() { Name = "StoreIds", Value = (null as object) });
            prms_TM_TopManagerDashboardLeadList_0.Add(new kSqlParameter() { Name = "SatisDanismaniIds", Value = (null as object) });
            prms_TM_TopManagerDashboardLeadList_0.Add(new kSqlParameter() { Name = "ProcessCode", Value = (null as object) });
            prms_TM_TopManagerDashboardLeadList_0.Add(new kSqlParameter() { Name = "StepOrder", Value = "10".ConvertToType<Int32>() });
            prms_TM_TopManagerDashboardLeadList_0.Add(new kSqlParameter() { Name = "StartDate", Value = (null as object) });
            prms_TM_TopManagerDashboardLeadList_0.Add(new kSqlParameter() { Name = "EndDate", Value = (null as object) });
            using var auditTM_TopManagerDashboardLeadList_0 = ActionAuditScope.Begin("5aff359a-391d-557a-9118-8bba928dcfca", "TM_TopManagerDashboardLeadList", applicationName: "wbTimesCRM", screenOrEndpointName: "DashBoardTemp");
            result.TM_TopManagerDashboardLeadList = KPersister.Fetch(KContext.GetConnectionString(), @"SET LANGUAGE Turkish;


SELECT
    CASE 
        WHEN EXISTS (
            SELECT 1 
            FROM tmscrq.TMLeadReservation r
            WHERE r.LeadId = l.Id
              AND r.IsActive = 1
              AND r.IsApproved = 1
        ) THEN N'Evet'
        WHEN EXISTS (
            SELECT 1 
            FROM tmscrq.TMLeadReservation r
            WHERE r.LeadId = l.Id
              AND r.IsActive = 1
              AND ISNULL(r.IsApproved,0) = 0
        ) THEN N'Onay Bekliyor'
        ELSE N'Hayır'
    END AS RezerveDurumu,
    l.Id AS LeadId,
    l.IsReserved,
    ISNULL(NULLIF(LTRIM(RTRIM(l.LeadCode)), ''), '-') AS LeadNumarasi,
    CONVERT(varchar(10), l.CreatedAt, 103) AS TalepTarihi,

    p.Id AS ProductId,
    ISNULL(NULLIF(LTRIM(RTRIM(p.ProductName)), ''), '-') AS ProductName,
    ISNULL(NULLIF(LTRIM(RTRIM(p.Bracelet)), ''), '-') AS Bilezik,
    ISNULL(NULLIF(LTRIM(RTRIM(p.Brand)), ''), '-') AS Brand,
    ISNULL(NULLIF(LTRIM(RTRIM(p.Dial)), ''), '-') AS Kadran,
    ISNULL(NULLIF(LTRIM(RTRIM(p.ProductCode)), ''), '-') AS RefCode,
    ISNULL(NULLIF(LTRIM(RTRIM(p.Referance)), ''), '-') AS Referans,

    ISNULL(
        NULLIF(
            LTRIM(RTRIM(ISNULL(cu.Name, '') + ' ' + ISNULL(cu.LastName, '')))
        , '')
    , '-') AS Musteri,

    ISNULL(NULLIF(LTRIM(RTRIM(cu.CityName)), ''), '-') AS Lokasyon,
    ISNULL(NULLIF(LTRIM(RTRIM(cu.DistrictName)), ''), '-') AS Ilce,
    ISNULL(NULLIF(LTRIM(RTRIM(cu.CountryName)), ''), '-') AS Ulke,
    ISNULL(NULLIF(LTRIM(RTRIM(cu.Info)), ''), '-') AS MusteriInfo,

    CASE
        WHEN cu.IsShopping = 1 THEN N'Evet'
        WHEN cu.IsShopping = 0 THEN N'Hayır'
        ELSE '-'
    END AS AlisverisiVarMi,

    ISNULL(NULLIF(LTRIM(RTRIM(cu.Tel)), ''), '-') AS IrtibatNumarasi,
    ISNULL(NULLIF(LTRIM(RTRIM(cu.Email)), ''), '-') AS EmailAdresi,

    ISNULL(NULLIF(LTRIM(RTRIM(cr.ContactResourceName)), ''), '-') AS IletisimKaynagi,

    ISNULL(NULLIF(LTRIM(RTRIM(p.CategoryName)), ''), '-') AS CategoryName,
    '-' AS CategoryCode,

    ISNULL(NULLIF(LTRIM(RTRIM(ls.Name)), ''), '-') AS LeadDurumu,
    ISNULL(NULLIF(LTRIM(RTRIM(ns.Name)), ''), '-') AS SonrakiAdim,

    ISNULL(NULLIF(LTRIM(RTRIM(lp.Name)), ''), '-') AS ProcessName,
    ISNULL(NULLIF(LTRIM(RTRIM(lp.Code)), ''), '-') AS ProcessCode,
    lp.StepOrder,
    
    CAST(ISNULL(@StepOrder, lp.StepOrder) AS INT) AS SelectedStepOrder,

    ISNULL(
        CASE
            WHEN l.EstimatedDate IS NOT NULL
            THEN CAST(YEAR(l.EstimatedDate) AS VARCHAR(4)) + ' ' + DATENAME(MONTH, l.EstimatedDate)
            ELSE NULL
        END,
        '-'
    ) AS TerminTarihi,

    ISNULL(
        NULLIF(
            LTRIM(RTRIM(ISNULL(sp.FirstName, '') + ' ' + ISNULL(sp.LastName, '')))
        , '')
    , '-') AS SatisDanismani,

    ISNULL(NULLIF(LTRIM(RTRIM(st.StoreDesc)), ''), '-') AS StoreName

FROM tmscrq.TMLead l
LEFT JOIN tmscrq.TMLeadStatu ls ON ls.Id = l.StatuId
LEFT JOIN tmscrq.TMCustomer cu ON cu.Id = l.CustomerId
LEFT JOIN tmscrq.TMProduct p ON p.Id = l.ProductId
LEFT JOIN tmscrq.TMContactResource cr ON cr.Id = l.ContactResourceId
LEFT JOIN dbo.KUser sp ON sp.Id = l.SalesPersonKUserId
LEFT JOIN tmscrq.TMStore st ON st.Id = l.StoreId
LEFT JOIN tmscrq.TMLeadProcess lp ON lp.Id = l.ProcessID
LEFT JOIN tmscrq.TMLeadNextStep ns ON ns.Id = l.NextStepId

WHERE
-- Yetkilendirme
(
    -- Yönetici / Üst Yönetici: Tüm lead'ler
    EXISTS (
        SELECT 1
        FROM dbo.KUserRole ur
        INNER JOIN dbo.KRole r ON r.Id = ur.KRole_Id
        WHERE ur.KUser_Id = @UserId
          AND ur.IsDeleted = 0
          AND r.IsDeleted = 0
          AND r.Name IN ('TimesYonetici', 'TimesUstYonetici')
    )

    OR

    -- Mağaza Müdürü: Kendi mağazasındaki tüm lead'ler
    (
        EXISTS (
            SELECT 1
            FROM dbo.KUserRole ur
            INNER JOIN dbo.KRole r ON r.Id = ur.KRole_Id
            WHERE ur.KUser_Id = @UserId
              AND ur.IsDeleted = 0
              AND r.IsDeleted = 0
              AND r.Name = 'TimesMagazaMuduru'
        )
        AND l.StoreId =
        (
            SELECT TOP 1 tu.StoreID
            FROM tmscrq.TMUser tu
            WHERE tu.KUserID = @UserId
        )
    )

    OR

    -- Satış Personeli: Sadece kendi açtığı lead'ler
    (
        EXISTS (
            SELECT 1
            FROM dbo.KUserRole ur
            INNER JOIN dbo.KRole r ON r.Id = ur.KRole_Id
            WHERE ur.KUser_Id = @UserId
              AND ur.IsDeleted = 0
              AND r.IsDeleted = 0
              AND r.Name = 'TimesSatisPersoneli'
        )
        AND l.SalesPersonKUserId = @UserId
    )
)

-- Müşteri Adı
AND
(
    @MusteriAdi IS NULL
    OR LTRIM(RTRIM(@MusteriAdi)) = ''
    OR UPPER(LTRIM(RTRIM(ISNULL(cu.Name,'') + ' ' + ISNULL(cu.LastName,''))))
       LIKE '%' + UPPER(LTRIM(RTRIM(@MusteriAdi))) + '%'
)

-- Ürün Adı
AND
(
    @ProductName IS NULL
    OR LTRIM(RTRIM(@ProductName)) = ''
    OR
    (
        CHARINDEX(',', @ProductName) > 0
        AND ISNULL(LTRIM(RTRIM(p.ProductName)), '') IN
        (
            SELECT LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', '')))
            FROM STRING_SPLIT(CAST(@ProductName AS NVARCHAR(MAX)), ',')
            WHERE LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', ''))) <> ''
        )
    )
    OR
    (
        CHARINDEX(',', @ProductName) = 0
        AND UPPER(ISNULL(LTRIM(RTRIM(p.ProductName)), ''))
            LIKE '%' + UPPER(LTRIM(RTRIM(@ProductName))) + '%'
    )
)

-- Lead Kodu
AND
(
    @LeadCode IS NULL
    OR LTRIM(RTRIM(@LeadCode)) = ''
    OR UPPER(ISNULL(LTRIM(RTRIM(l.LeadCode)), '')) LIKE '%' + UPPER(LTRIM(RTRIM(@LeadCode))) + '%'
)

-- Telefon
AND
(
    @Tel IS NULL
    OR LTRIM(RTRIM(@Tel)) = ''
    OR UPPER(ISNULL(LTRIM(RTRIM(cu.Tel)), '')) LIKE '%' + UPPER(LTRIM(RTRIM(@Tel))) + '%'
)

-- Kategori
AND
(
    @CategoryName IS NULL
    OR LTRIM(RTRIM(@CategoryName)) = ''
    OR UPPER(ISNULL(LTRIM(RTRIM(p.CategoryName)), '')) IN
    (
        SELECT UPPER(LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value,'""',''),'[',''),']',''))))
        FROM STRING_SPLIT(CAST(@CategoryName AS NVARCHAR(MAX)), ',')
        WHERE LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value,'""',''),'[',''),']',''))) <> ''
    )
)

-- Mağaza
AND
(
    @StoreIds IS NULL
    OR LTRIM(RTRIM(@StoreIds)) = ''
    OR EXISTS
    (
        SELECT 1
        FROM STRING_SPLIT(CAST(@StoreIds AS NVARCHAR(MAX)), ',') s
        WHERE l.StoreId = TRY_CONVERT
        (
            uniqueidentifier,
            LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(s.value, '""', ''), '[', ''), ']', '')))
        )
    )
)

-- Satış Danışmanı
AND
(
    @SatisDanismaniIds IS NULL
    OR LTRIM(RTRIM(@SatisDanismaniIds)) = ''
    OR EXISTS
    (
        SELECT 1
        FROM STRING_SPLIT(CAST(@SatisDanismaniIds AS NVARCHAR(MAX)), ',') s
        WHERE l.SalesPersonKUserId = TRY_CONVERT
        (
            uniqueidentifier,
            LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(s.value, '""', ''), '[', ''), ']', '')))
        )
    )
)

-- Süreç Kodu
AND
(
    @ProcessCode IS NULL
    OR LTRIM(RTRIM(@ProcessCode)) = ''
    OR UPPER(ISNULL(LTRIM(RTRIM(lp.Code)), '')) IN
    (
        SELECT UPPER(LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', ''))))
        FROM STRING_SPLIT(CAST(@ProcessCode AS NVARCHAR(MAX)), ',')
        WHERE LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', ''))) <> ''
    )
)

-- StepOrder Filtresi (genişletilmiş, -4 eklendi)
AND
(
    @StepOrder IS NULL
    OR @StepOrder = 0   -- Tümü

    -- Aktif: CREATED, TERMIN_PENDING, PENDING, APPROVED, DELIVERY_PENDING
    OR (@StepOrder = -1 AND lp.Code IN ('CREATED','TERMIN_PENDING','PENDING','APPROVED','DELIVERY_PENDING'))

    -- Bugün oluşturulanlar
    OR (
        @StepOrder = -2 
        AND l.CreatedAt >= CAST(GETDATE() AS DATE) 
        AND l.CreatedAt < DATEADD(day, 1, CAST(GETDATE() AS DATE))
    )

    -- Geciken (Termin Tarihi Geçmiş): EstimatedDate bugünden küçük ve sonuçlanmamış
    OR (
        @StepOrder = -3 
        AND l.EstimatedDate < CAST(GETDATE() AS DATE) 
        AND lp.Code NOT IN ('DELIVERED','CLOSED','CUSTOMER_DECLINED','REJECTED')
    )

    -- Bu ayın terminleri
    OR (
        @StepOrder = -4 
        AND l.EstimatedDate >= DATEFROMPARTS(YEAR(GETDATE()), MONTH(GETDATE()), 1)
        AND l.EstimatedDate < DATEADD(MONTH, 1, DATEFROMPARTS(YEAR(GETDATE()), MONTH(GETDATE()), 1))
    )

    -- Rezerv onay bekleyen
    OR (
        @StepOrder = 10 
        AND EXISTS (
            SELECT 1 
            FROM tmscrq.TMLeadReservation r 
            WHERE r.LeadId = l.Id 
              AND r.IsActive = 1 
              AND ISNULL(r.IsApproved,0) = 0
        )
    )

    -- Diğer pozitif StepOrder değerleri
    OR (
        @StepOrder NOT IN (0, -1, -2, -3, -4, 10) 
        AND lp.StepOrder = @StepOrder
    )
)

-- Başlangıç Tarihi
AND
(
    @StartDate IS NULL
    OR LTRIM(RTRIM(@StartDate)) = ''
    OR l.CreatedAt >= CONVERT(date, @StartDate)
)

-- Bitiş Tarihi
AND
(
    @EndDate IS NULL
    OR LTRIM(RTRIM(@EndDate)) = ''
    OR l.CreatedAt < DATEADD(day, 1, CONVERT(date, @EndDate))
)

ORDER BY l.CreatedAt DESC;", new string[] { "RezerveDurumu", "LeadId", "IsReserved", "LeadNumarasi", "TalepTarihi", "ProductId", "ProductName", "Bilezik", "Brand", "Kadran", "RefCode", "Referans", "Musteri", "Lokasyon", "Ilce", "Ulke", "MusteriInfo", "AlisverisiVarMi", "IrtibatNumarasi", "EmailAdresi", "IletisimKaynagi", "CategoryName", "CategoryCode", "LeadDurumu", "SonrakiAdim", "ProcessName", "ProcessCode", "StepOrder", "SelectedStepOrder", "TerminTarihi", "SatisDanismani", "StoreName" }, prms_TM_TopManagerDashboardLeadList_0.ToArray());
            ;


            return Ok(result);
        }


        [HttpPost, Route("DashBoardTempComponent_654813_onClick")]
        public IActionResult DashBoardTempComponent_654813_onClick(DashBoardTempComponent_654813_onClick_Request request)
        {

            KProviderManager.Authorization.IsAuthorizedForRoles(appId, appName, screenId, screenName, new List<string> { $"b4bfd39c-ac02-f442-c899-7a2374a45b47", "70de6cfc-6087-6059-59b4-0b5a8527af6b", "TimesSatisPersoneli", "TimesMagazaMuduru" });

            var result = new DashBoardTempComponent_654813_onClick_Response();

            var prms_TM_TopManagerDashboardLeadList_0 = new List<kSqlParameter>();
            prms_TM_TopManagerDashboardLeadList_0.Add(new kSqlParameter() { Name = "UserId", Value = Kuika.Common.KContext.CurrentUser?.Id });
            prms_TM_TopManagerDashboardLeadList_0.Add(new kSqlParameter() { Name = "MusteriAdi", Value = (null as object) });
            prms_TM_TopManagerDashboardLeadList_0.Add(new kSqlParameter() { Name = "ProductName", Value = (null as object) });
            prms_TM_TopManagerDashboardLeadList_0.Add(new kSqlParameter() { Name = "LeadCode", Value = (null as object) });
            prms_TM_TopManagerDashboardLeadList_0.Add(new kSqlParameter() { Name = "Tel", Value = (null as object) });
            prms_TM_TopManagerDashboardLeadList_0.Add(new kSqlParameter() { Name = "CategoryName", Value = (null as object) });
            prms_TM_TopManagerDashboardLeadList_0.Add(new kSqlParameter() { Name = "StoreIds", Value = (null as object) });
            prms_TM_TopManagerDashboardLeadList_0.Add(new kSqlParameter() { Name = "SatisDanismaniIds", Value = (null as object) });
            prms_TM_TopManagerDashboardLeadList_0.Add(new kSqlParameter() { Name = "ProcessCode", Value = (null as object) });
            prms_TM_TopManagerDashboardLeadList_0.Add(new kSqlParameter() { Name = "StepOrder", Value = "6".ConvertToType<Int32>() });
            prms_TM_TopManagerDashboardLeadList_0.Add(new kSqlParameter() { Name = "StartDate", Value = (null as object) });
            prms_TM_TopManagerDashboardLeadList_0.Add(new kSqlParameter() { Name = "EndDate", Value = (null as object) });
            using var auditTM_TopManagerDashboardLeadList_0 = ActionAuditScope.Begin("17516068-4fd1-23cc-290d-897ed7312e0e", "TM_TopManagerDashboardLeadList", applicationName: "wbTimesCRM", screenOrEndpointName: "DashBoardTemp");
            result.TM_TopManagerDashboardLeadList = KPersister.Fetch(KContext.GetConnectionString(), @"SET LANGUAGE Turkish;


SELECT
    CASE 
        WHEN EXISTS (
            SELECT 1 
            FROM tmscrq.TMLeadReservation r
            WHERE r.LeadId = l.Id
              AND r.IsActive = 1
              AND r.IsApproved = 1
        ) THEN N'Evet'
        WHEN EXISTS (
            SELECT 1 
            FROM tmscrq.TMLeadReservation r
            WHERE r.LeadId = l.Id
              AND r.IsActive = 1
              AND ISNULL(r.IsApproved,0) = 0
        ) THEN N'Onay Bekliyor'
        ELSE N'Hayır'
    END AS RezerveDurumu,
    l.Id AS LeadId,
    l.IsReserved,
    ISNULL(NULLIF(LTRIM(RTRIM(l.LeadCode)), ''), '-') AS LeadNumarasi,
    CONVERT(varchar(10), l.CreatedAt, 103) AS TalepTarihi,

    p.Id AS ProductId,
    ISNULL(NULLIF(LTRIM(RTRIM(p.ProductName)), ''), '-') AS ProductName,
    ISNULL(NULLIF(LTRIM(RTRIM(p.Bracelet)), ''), '-') AS Bilezik,
    ISNULL(NULLIF(LTRIM(RTRIM(p.Brand)), ''), '-') AS Brand,
    ISNULL(NULLIF(LTRIM(RTRIM(p.Dial)), ''), '-') AS Kadran,
    ISNULL(NULLIF(LTRIM(RTRIM(p.ProductCode)), ''), '-') AS RefCode,
    ISNULL(NULLIF(LTRIM(RTRIM(p.Referance)), ''), '-') AS Referans,

    ISNULL(
        NULLIF(
            LTRIM(RTRIM(ISNULL(cu.Name, '') + ' ' + ISNULL(cu.LastName, '')))
        , '')
    , '-') AS Musteri,

    ISNULL(NULLIF(LTRIM(RTRIM(cu.CityName)), ''), '-') AS Lokasyon,
    ISNULL(NULLIF(LTRIM(RTRIM(cu.DistrictName)), ''), '-') AS Ilce,
    ISNULL(NULLIF(LTRIM(RTRIM(cu.CountryName)), ''), '-') AS Ulke,
    ISNULL(NULLIF(LTRIM(RTRIM(cu.Info)), ''), '-') AS MusteriInfo,

    CASE
        WHEN cu.IsShopping = 1 THEN N'Evet'
        WHEN cu.IsShopping = 0 THEN N'Hayır'
        ELSE '-'
    END AS AlisverisiVarMi,

    ISNULL(NULLIF(LTRIM(RTRIM(cu.Tel)), ''), '-') AS IrtibatNumarasi,
    ISNULL(NULLIF(LTRIM(RTRIM(cu.Email)), ''), '-') AS EmailAdresi,

    ISNULL(NULLIF(LTRIM(RTRIM(cr.ContactResourceName)), ''), '-') AS IletisimKaynagi,

    ISNULL(NULLIF(LTRIM(RTRIM(p.CategoryName)), ''), '-') AS CategoryName,
    '-' AS CategoryCode,

    ISNULL(NULLIF(LTRIM(RTRIM(ls.Name)), ''), '-') AS LeadDurumu,
    ISNULL(NULLIF(LTRIM(RTRIM(ns.Name)), ''), '-') AS SonrakiAdim,

    ISNULL(NULLIF(LTRIM(RTRIM(lp.Name)), ''), '-') AS ProcessName,
    ISNULL(NULLIF(LTRIM(RTRIM(lp.Code)), ''), '-') AS ProcessCode,
    lp.StepOrder,
    
    CAST(ISNULL(@StepOrder, lp.StepOrder) AS INT) AS SelectedStepOrder,

    ISNULL(
        CASE
            WHEN l.EstimatedDate IS NOT NULL
            THEN CAST(YEAR(l.EstimatedDate) AS VARCHAR(4)) + ' ' + DATENAME(MONTH, l.EstimatedDate)
            ELSE NULL
        END,
        '-'
    ) AS TerminTarihi,

    ISNULL(
        NULLIF(
            LTRIM(RTRIM(ISNULL(sp.FirstName, '') + ' ' + ISNULL(sp.LastName, '')))
        , '')
    , '-') AS SatisDanismani,

    ISNULL(NULLIF(LTRIM(RTRIM(st.StoreDesc)), ''), '-') AS StoreName

FROM tmscrq.TMLead l
LEFT JOIN tmscrq.TMLeadStatu ls ON ls.Id = l.StatuId
LEFT JOIN tmscrq.TMCustomer cu ON cu.Id = l.CustomerId
LEFT JOIN tmscrq.TMProduct p ON p.Id = l.ProductId
LEFT JOIN tmscrq.TMContactResource cr ON cr.Id = l.ContactResourceId
LEFT JOIN dbo.KUser sp ON sp.Id = l.SalesPersonKUserId
LEFT JOIN tmscrq.TMStore st ON st.Id = l.StoreId
LEFT JOIN tmscrq.TMLeadProcess lp ON lp.Id = l.ProcessID
LEFT JOIN tmscrq.TMLeadNextStep ns ON ns.Id = l.NextStepId

WHERE
-- Yetkilendirme
(
    -- Yönetici / Üst Yönetici: Tüm lead'ler
    EXISTS (
        SELECT 1
        FROM dbo.KUserRole ur
        INNER JOIN dbo.KRole r ON r.Id = ur.KRole_Id
        WHERE ur.KUser_Id = @UserId
          AND ur.IsDeleted = 0
          AND r.IsDeleted = 0
          AND r.Name IN ('TimesYonetici', 'TimesUstYonetici')
    )

    OR

    -- Mağaza Müdürü: Kendi mağazasındaki tüm lead'ler
    (
        EXISTS (
            SELECT 1
            FROM dbo.KUserRole ur
            INNER JOIN dbo.KRole r ON r.Id = ur.KRole_Id
            WHERE ur.KUser_Id = @UserId
              AND ur.IsDeleted = 0
              AND r.IsDeleted = 0
              AND r.Name = 'TimesMagazaMuduru'
        )
        AND l.StoreId =
        (
            SELECT TOP 1 tu.StoreID
            FROM tmscrq.TMUser tu
            WHERE tu.KUserID = @UserId
        )
    )

    OR

    -- Satış Personeli: Sadece kendi açtığı lead'ler
    (
        EXISTS (
            SELECT 1
            FROM dbo.KUserRole ur
            INNER JOIN dbo.KRole r ON r.Id = ur.KRole_Id
            WHERE ur.KUser_Id = @UserId
              AND ur.IsDeleted = 0
              AND r.IsDeleted = 0
              AND r.Name = 'TimesSatisPersoneli'
        )
        AND l.SalesPersonKUserId = @UserId
    )
)

-- Müşteri Adı
AND
(
    @MusteriAdi IS NULL
    OR LTRIM(RTRIM(@MusteriAdi)) = ''
    OR UPPER(LTRIM(RTRIM(ISNULL(cu.Name,'') + ' ' + ISNULL(cu.LastName,''))))
       LIKE '%' + UPPER(LTRIM(RTRIM(@MusteriAdi))) + '%'
)

-- Ürün Adı
AND
(
    @ProductName IS NULL
    OR LTRIM(RTRIM(@ProductName)) = ''
    OR
    (
        CHARINDEX(',', @ProductName) > 0
        AND ISNULL(LTRIM(RTRIM(p.ProductName)), '') IN
        (
            SELECT LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', '')))
            FROM STRING_SPLIT(CAST(@ProductName AS NVARCHAR(MAX)), ',')
            WHERE LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', ''))) <> ''
        )
    )
    OR
    (
        CHARINDEX(',', @ProductName) = 0
        AND UPPER(ISNULL(LTRIM(RTRIM(p.ProductName)), ''))
            LIKE '%' + UPPER(LTRIM(RTRIM(@ProductName))) + '%'
    )
)

-- Lead Kodu
AND
(
    @LeadCode IS NULL
    OR LTRIM(RTRIM(@LeadCode)) = ''
    OR UPPER(ISNULL(LTRIM(RTRIM(l.LeadCode)), '')) LIKE '%' + UPPER(LTRIM(RTRIM(@LeadCode))) + '%'
)

-- Telefon
AND
(
    @Tel IS NULL
    OR LTRIM(RTRIM(@Tel)) = ''
    OR UPPER(ISNULL(LTRIM(RTRIM(cu.Tel)), '')) LIKE '%' + UPPER(LTRIM(RTRIM(@Tel))) + '%'
)

-- Kategori
AND
(
    @CategoryName IS NULL
    OR LTRIM(RTRIM(@CategoryName)) = ''
    OR UPPER(ISNULL(LTRIM(RTRIM(p.CategoryName)), '')) IN
    (
        SELECT UPPER(LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value,'""',''),'[',''),']',''))))
        FROM STRING_SPLIT(CAST(@CategoryName AS NVARCHAR(MAX)), ',')
        WHERE LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value,'""',''),'[',''),']',''))) <> ''
    )
)

-- Mağaza
AND
(
    @StoreIds IS NULL
    OR LTRIM(RTRIM(@StoreIds)) = ''
    OR EXISTS
    (
        SELECT 1
        FROM STRING_SPLIT(CAST(@StoreIds AS NVARCHAR(MAX)), ',') s
        WHERE l.StoreId = TRY_CONVERT
        (
            uniqueidentifier,
            LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(s.value, '""', ''), '[', ''), ']', '')))
        )
    )
)

-- Satış Danışmanı
AND
(
    @SatisDanismaniIds IS NULL
    OR LTRIM(RTRIM(@SatisDanismaniIds)) = ''
    OR EXISTS
    (
        SELECT 1
        FROM STRING_SPLIT(CAST(@SatisDanismaniIds AS NVARCHAR(MAX)), ',') s
        WHERE l.SalesPersonKUserId = TRY_CONVERT
        (
            uniqueidentifier,
            LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(s.value, '""', ''), '[', ''), ']', '')))
        )
    )
)

-- Süreç Kodu
AND
(
    @ProcessCode IS NULL
    OR LTRIM(RTRIM(@ProcessCode)) = ''
    OR UPPER(ISNULL(LTRIM(RTRIM(lp.Code)), '')) IN
    (
        SELECT UPPER(LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', ''))))
        FROM STRING_SPLIT(CAST(@ProcessCode AS NVARCHAR(MAX)), ',')
        WHERE LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', ''))) <> ''
    )
)

-- StepOrder Filtresi (genişletilmiş, -4 eklendi)
AND
(
    @StepOrder IS NULL
    OR @StepOrder = 0   -- Tümü

    -- Aktif: CREATED, TERMIN_PENDING, PENDING, APPROVED, DELIVERY_PENDING
    OR (@StepOrder = -1 AND lp.Code IN ('CREATED','TERMIN_PENDING','PENDING','APPROVED','DELIVERY_PENDING'))

    -- Bugün oluşturulanlar
    OR (
        @StepOrder = -2 
        AND l.CreatedAt >= CAST(GETDATE() AS DATE) 
        AND l.CreatedAt < DATEADD(day, 1, CAST(GETDATE() AS DATE))
    )

    -- Geciken (Termin Tarihi Geçmiş): EstimatedDate bugünden küçük ve sonuçlanmamış
    OR (
        @StepOrder = -3 
        AND l.EstimatedDate < CAST(GETDATE() AS DATE) 
        AND lp.Code NOT IN ('DELIVERED','CLOSED','CUSTOMER_DECLINED','REJECTED')
    )

    -- Bu ayın terminleri
    OR (
        @StepOrder = -4 
        AND l.EstimatedDate >= DATEFROMPARTS(YEAR(GETDATE()), MONTH(GETDATE()), 1)
        AND l.EstimatedDate < DATEADD(MONTH, 1, DATEFROMPARTS(YEAR(GETDATE()), MONTH(GETDATE()), 1))
    )

    -- Rezerv onay bekleyen
    OR (
        @StepOrder = 10 
        AND EXISTS (
            SELECT 1 
            FROM tmscrq.TMLeadReservation r 
            WHERE r.LeadId = l.Id 
              AND r.IsActive = 1 
              AND ISNULL(r.IsApproved,0) = 0
        )
    )

    -- Diğer pozitif StepOrder değerleri
    OR (
        @StepOrder NOT IN (0, -1, -2, -3, -4, 10) 
        AND lp.StepOrder = @StepOrder
    )
)

-- Başlangıç Tarihi
AND
(
    @StartDate IS NULL
    OR LTRIM(RTRIM(@StartDate)) = ''
    OR l.CreatedAt >= CONVERT(date, @StartDate)
)

-- Bitiş Tarihi
AND
(
    @EndDate IS NULL
    OR LTRIM(RTRIM(@EndDate)) = ''
    OR l.CreatedAt < DATEADD(day, 1, CONVERT(date, @EndDate))
)

ORDER BY l.CreatedAt DESC;", new string[] { "RezerveDurumu", "LeadId", "IsReserved", "LeadNumarasi", "TalepTarihi", "ProductId", "ProductName", "Bilezik", "Brand", "Kadran", "RefCode", "Referans", "Musteri", "Lokasyon", "Ilce", "Ulke", "MusteriInfo", "AlisverisiVarMi", "IrtibatNumarasi", "EmailAdresi", "IletisimKaynagi", "CategoryName", "CategoryCode", "LeadDurumu", "SonrakiAdim", "ProcessName", "ProcessCode", "StepOrder", "SelectedStepOrder", "TerminTarihi", "SatisDanismani", "StoreName" }, prms_TM_TopManagerDashboardLeadList_0.ToArray());
            ;


            return Ok(result);
        }


        [HttpPost, Route("DashBoardTempComponent_371503_onClick")]
        public IActionResult DashBoardTempComponent_371503_onClick(DashBoardTempComponent_371503_onClick_Request request)
        {

            KProviderManager.Authorization.IsAuthorizedForRoles(appId, appName, screenId, screenName, new List<string> { $"b4bfd39c-ac02-f442-c899-7a2374a45b47", "70de6cfc-6087-6059-59b4-0b5a8527af6b", "TimesSatisPersoneli", "TimesMagazaMuduru" });

            var result = new DashBoardTempComponent_371503_onClick_Response();

            var prms_TM_TopManagerDashboardLeadList_0 = new List<kSqlParameter>();
            prms_TM_TopManagerDashboardLeadList_0.Add(new kSqlParameter() { Name = "UserId", Value = Kuika.Common.KContext.CurrentUser?.Id });
            prms_TM_TopManagerDashboardLeadList_0.Add(new kSqlParameter() { Name = "MusteriAdi", Value = (null as object) });
            prms_TM_TopManagerDashboardLeadList_0.Add(new kSqlParameter() { Name = "ProductName", Value = (null as object) });
            prms_TM_TopManagerDashboardLeadList_0.Add(new kSqlParameter() { Name = "LeadCode", Value = (null as object) });
            prms_TM_TopManagerDashboardLeadList_0.Add(new kSqlParameter() { Name = "Tel", Value = (null as object) });
            prms_TM_TopManagerDashboardLeadList_0.Add(new kSqlParameter() { Name = "CategoryName", Value = (null as object) });
            prms_TM_TopManagerDashboardLeadList_0.Add(new kSqlParameter() { Name = "StoreIds", Value = (null as object) });
            prms_TM_TopManagerDashboardLeadList_0.Add(new kSqlParameter() { Name = "SatisDanismaniIds", Value = (null as object) });
            prms_TM_TopManagerDashboardLeadList_0.Add(new kSqlParameter() { Name = "ProcessCode", Value = (null as object) });
            prms_TM_TopManagerDashboardLeadList_0.Add(new kSqlParameter() { Name = "StepOrder", Value = "7".ConvertToType<Int32>() });
            prms_TM_TopManagerDashboardLeadList_0.Add(new kSqlParameter() { Name = "StartDate", Value = (null as object) });
            prms_TM_TopManagerDashboardLeadList_0.Add(new kSqlParameter() { Name = "EndDate", Value = (null as object) });
            using var auditTM_TopManagerDashboardLeadList_0 = ActionAuditScope.Begin("2aa8e82e-82dd-27af-b09c-ce58cdb1344b", "TM_TopManagerDashboardLeadList", applicationName: "wbTimesCRM", screenOrEndpointName: "DashBoardTemp");
            result.TM_TopManagerDashboardLeadList = KPersister.Fetch(KContext.GetConnectionString(), @"SET LANGUAGE Turkish;


SELECT
    CASE 
        WHEN EXISTS (
            SELECT 1 
            FROM tmscrq.TMLeadReservation r
            WHERE r.LeadId = l.Id
              AND r.IsActive = 1
              AND r.IsApproved = 1
        ) THEN N'Evet'
        WHEN EXISTS (
            SELECT 1 
            FROM tmscrq.TMLeadReservation r
            WHERE r.LeadId = l.Id
              AND r.IsActive = 1
              AND ISNULL(r.IsApproved,0) = 0
        ) THEN N'Onay Bekliyor'
        ELSE N'Hayır'
    END AS RezerveDurumu,
    l.Id AS LeadId,
    l.IsReserved,
    ISNULL(NULLIF(LTRIM(RTRIM(l.LeadCode)), ''), '-') AS LeadNumarasi,
    CONVERT(varchar(10), l.CreatedAt, 103) AS TalepTarihi,

    p.Id AS ProductId,
    ISNULL(NULLIF(LTRIM(RTRIM(p.ProductName)), ''), '-') AS ProductName,
    ISNULL(NULLIF(LTRIM(RTRIM(p.Bracelet)), ''), '-') AS Bilezik,
    ISNULL(NULLIF(LTRIM(RTRIM(p.Brand)), ''), '-') AS Brand,
    ISNULL(NULLIF(LTRIM(RTRIM(p.Dial)), ''), '-') AS Kadran,
    ISNULL(NULLIF(LTRIM(RTRIM(p.ProductCode)), ''), '-') AS RefCode,
    ISNULL(NULLIF(LTRIM(RTRIM(p.Referance)), ''), '-') AS Referans,

    ISNULL(
        NULLIF(
            LTRIM(RTRIM(ISNULL(cu.Name, '') + ' ' + ISNULL(cu.LastName, '')))
        , '')
    , '-') AS Musteri,

    ISNULL(NULLIF(LTRIM(RTRIM(cu.CityName)), ''), '-') AS Lokasyon,
    ISNULL(NULLIF(LTRIM(RTRIM(cu.DistrictName)), ''), '-') AS Ilce,
    ISNULL(NULLIF(LTRIM(RTRIM(cu.CountryName)), ''), '-') AS Ulke,
    ISNULL(NULLIF(LTRIM(RTRIM(cu.Info)), ''), '-') AS MusteriInfo,

    CASE
        WHEN cu.IsShopping = 1 THEN N'Evet'
        WHEN cu.IsShopping = 0 THEN N'Hayır'
        ELSE '-'
    END AS AlisverisiVarMi,

    ISNULL(NULLIF(LTRIM(RTRIM(cu.Tel)), ''), '-') AS IrtibatNumarasi,
    ISNULL(NULLIF(LTRIM(RTRIM(cu.Email)), ''), '-') AS EmailAdresi,

    ISNULL(NULLIF(LTRIM(RTRIM(cr.ContactResourceName)), ''), '-') AS IletisimKaynagi,

    ISNULL(NULLIF(LTRIM(RTRIM(p.CategoryName)), ''), '-') AS CategoryName,
    '-' AS CategoryCode,

    ISNULL(NULLIF(LTRIM(RTRIM(ls.Name)), ''), '-') AS LeadDurumu,
    ISNULL(NULLIF(LTRIM(RTRIM(ns.Name)), ''), '-') AS SonrakiAdim,

    ISNULL(NULLIF(LTRIM(RTRIM(lp.Name)), ''), '-') AS ProcessName,
    ISNULL(NULLIF(LTRIM(RTRIM(lp.Code)), ''), '-') AS ProcessCode,
    lp.StepOrder,
    
    CAST(ISNULL(@StepOrder, lp.StepOrder) AS INT) AS SelectedStepOrder,

    ISNULL(
        CASE
            WHEN l.EstimatedDate IS NOT NULL
            THEN CAST(YEAR(l.EstimatedDate) AS VARCHAR(4)) + ' ' + DATENAME(MONTH, l.EstimatedDate)
            ELSE NULL
        END,
        '-'
    ) AS TerminTarihi,

    ISNULL(
        NULLIF(
            LTRIM(RTRIM(ISNULL(sp.FirstName, '') + ' ' + ISNULL(sp.LastName, '')))
        , '')
    , '-') AS SatisDanismani,

    ISNULL(NULLIF(LTRIM(RTRIM(st.StoreDesc)), ''), '-') AS StoreName

FROM tmscrq.TMLead l
LEFT JOIN tmscrq.TMLeadStatu ls ON ls.Id = l.StatuId
LEFT JOIN tmscrq.TMCustomer cu ON cu.Id = l.CustomerId
LEFT JOIN tmscrq.TMProduct p ON p.Id = l.ProductId
LEFT JOIN tmscrq.TMContactResource cr ON cr.Id = l.ContactResourceId
LEFT JOIN dbo.KUser sp ON sp.Id = l.SalesPersonKUserId
LEFT JOIN tmscrq.TMStore st ON st.Id = l.StoreId
LEFT JOIN tmscrq.TMLeadProcess lp ON lp.Id = l.ProcessID
LEFT JOIN tmscrq.TMLeadNextStep ns ON ns.Id = l.NextStepId

WHERE
-- Yetkilendirme
(
    -- Yönetici / Üst Yönetici: Tüm lead'ler
    EXISTS (
        SELECT 1
        FROM dbo.KUserRole ur
        INNER JOIN dbo.KRole r ON r.Id = ur.KRole_Id
        WHERE ur.KUser_Id = @UserId
          AND ur.IsDeleted = 0
          AND r.IsDeleted = 0
          AND r.Name IN ('TimesYonetici', 'TimesUstYonetici')
    )

    OR

    -- Mağaza Müdürü: Kendi mağazasındaki tüm lead'ler
    (
        EXISTS (
            SELECT 1
            FROM dbo.KUserRole ur
            INNER JOIN dbo.KRole r ON r.Id = ur.KRole_Id
            WHERE ur.KUser_Id = @UserId
              AND ur.IsDeleted = 0
              AND r.IsDeleted = 0
              AND r.Name = 'TimesMagazaMuduru'
        )
        AND l.StoreId =
        (
            SELECT TOP 1 tu.StoreID
            FROM tmscrq.TMUser tu
            WHERE tu.KUserID = @UserId
        )
    )

    OR

    -- Satış Personeli: Sadece kendi açtığı lead'ler
    (
        EXISTS (
            SELECT 1
            FROM dbo.KUserRole ur
            INNER JOIN dbo.KRole r ON r.Id = ur.KRole_Id
            WHERE ur.KUser_Id = @UserId
              AND ur.IsDeleted = 0
              AND r.IsDeleted = 0
              AND r.Name = 'TimesSatisPersoneli'
        )
        AND l.SalesPersonKUserId = @UserId
    )
)

-- Müşteri Adı
AND
(
    @MusteriAdi IS NULL
    OR LTRIM(RTRIM(@MusteriAdi)) = ''
    OR UPPER(LTRIM(RTRIM(ISNULL(cu.Name,'') + ' ' + ISNULL(cu.LastName,''))))
       LIKE '%' + UPPER(LTRIM(RTRIM(@MusteriAdi))) + '%'
)

-- Ürün Adı
AND
(
    @ProductName IS NULL
    OR LTRIM(RTRIM(@ProductName)) = ''
    OR
    (
        CHARINDEX(',', @ProductName) > 0
        AND ISNULL(LTRIM(RTRIM(p.ProductName)), '') IN
        (
            SELECT LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', '')))
            FROM STRING_SPLIT(CAST(@ProductName AS NVARCHAR(MAX)), ',')
            WHERE LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', ''))) <> ''
        )
    )
    OR
    (
        CHARINDEX(',', @ProductName) = 0
        AND UPPER(ISNULL(LTRIM(RTRIM(p.ProductName)), ''))
            LIKE '%' + UPPER(LTRIM(RTRIM(@ProductName))) + '%'
    )
)

-- Lead Kodu
AND
(
    @LeadCode IS NULL
    OR LTRIM(RTRIM(@LeadCode)) = ''
    OR UPPER(ISNULL(LTRIM(RTRIM(l.LeadCode)), '')) LIKE '%' + UPPER(LTRIM(RTRIM(@LeadCode))) + '%'
)

-- Telefon
AND
(
    @Tel IS NULL
    OR LTRIM(RTRIM(@Tel)) = ''
    OR UPPER(ISNULL(LTRIM(RTRIM(cu.Tel)), '')) LIKE '%' + UPPER(LTRIM(RTRIM(@Tel))) + '%'
)

-- Kategori
AND
(
    @CategoryName IS NULL
    OR LTRIM(RTRIM(@CategoryName)) = ''
    OR UPPER(ISNULL(LTRIM(RTRIM(p.CategoryName)), '')) IN
    (
        SELECT UPPER(LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value,'""',''),'[',''),']',''))))
        FROM STRING_SPLIT(CAST(@CategoryName AS NVARCHAR(MAX)), ',')
        WHERE LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value,'""',''),'[',''),']',''))) <> ''
    )
)

-- Mağaza
AND
(
    @StoreIds IS NULL
    OR LTRIM(RTRIM(@StoreIds)) = ''
    OR EXISTS
    (
        SELECT 1
        FROM STRING_SPLIT(CAST(@StoreIds AS NVARCHAR(MAX)), ',') s
        WHERE l.StoreId = TRY_CONVERT
        (
            uniqueidentifier,
            LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(s.value, '""', ''), '[', ''), ']', '')))
        )
    )
)

-- Satış Danışmanı
AND
(
    @SatisDanismaniIds IS NULL
    OR LTRIM(RTRIM(@SatisDanismaniIds)) = ''
    OR EXISTS
    (
        SELECT 1
        FROM STRING_SPLIT(CAST(@SatisDanismaniIds AS NVARCHAR(MAX)), ',') s
        WHERE l.SalesPersonKUserId = TRY_CONVERT
        (
            uniqueidentifier,
            LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(s.value, '""', ''), '[', ''), ']', '')))
        )
    )
)

-- Süreç Kodu
AND
(
    @ProcessCode IS NULL
    OR LTRIM(RTRIM(@ProcessCode)) = ''
    OR UPPER(ISNULL(LTRIM(RTRIM(lp.Code)), '')) IN
    (
        SELECT UPPER(LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', ''))))
        FROM STRING_SPLIT(CAST(@ProcessCode AS NVARCHAR(MAX)), ',')
        WHERE LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', ''))) <> ''
    )
)

-- StepOrder Filtresi (genişletilmiş, -4 eklendi)
AND
(
    @StepOrder IS NULL
    OR @StepOrder = 0   -- Tümü

    -- Aktif: CREATED, TERMIN_PENDING, PENDING, APPROVED, DELIVERY_PENDING
    OR (@StepOrder = -1 AND lp.Code IN ('CREATED','TERMIN_PENDING','PENDING','APPROVED','DELIVERY_PENDING'))

    -- Bugün oluşturulanlar
    OR (
        @StepOrder = -2 
        AND l.CreatedAt >= CAST(GETDATE() AS DATE) 
        AND l.CreatedAt < DATEADD(day, 1, CAST(GETDATE() AS DATE))
    )

    -- Geciken (Termin Tarihi Geçmiş): EstimatedDate bugünden küçük ve sonuçlanmamış
    OR (
        @StepOrder = -3 
        AND l.EstimatedDate < CAST(GETDATE() AS DATE) 
        AND lp.Code NOT IN ('DELIVERED','CLOSED','CUSTOMER_DECLINED','REJECTED')
    )

    -- Bu ayın terminleri
    OR (
        @StepOrder = -4 
        AND l.EstimatedDate >= DATEFROMPARTS(YEAR(GETDATE()), MONTH(GETDATE()), 1)
        AND l.EstimatedDate < DATEADD(MONTH, 1, DATEFROMPARTS(YEAR(GETDATE()), MONTH(GETDATE()), 1))
    )

    -- Rezerv onay bekleyen
    OR (
        @StepOrder = 10 
        AND EXISTS (
            SELECT 1 
            FROM tmscrq.TMLeadReservation r 
            WHERE r.LeadId = l.Id 
              AND r.IsActive = 1 
              AND ISNULL(r.IsApproved,0) = 0
        )
    )

    -- Diğer pozitif StepOrder değerleri
    OR (
        @StepOrder NOT IN (0, -1, -2, -3, -4, 10) 
        AND lp.StepOrder = @StepOrder
    )
)

-- Başlangıç Tarihi
AND
(
    @StartDate IS NULL
    OR LTRIM(RTRIM(@StartDate)) = ''
    OR l.CreatedAt >= CONVERT(date, @StartDate)
)

-- Bitiş Tarihi
AND
(
    @EndDate IS NULL
    OR LTRIM(RTRIM(@EndDate)) = ''
    OR l.CreatedAt < DATEADD(day, 1, CONVERT(date, @EndDate))
)

ORDER BY l.CreatedAt DESC;", new string[] { "RezerveDurumu", "LeadId", "IsReserved", "LeadNumarasi", "TalepTarihi", "ProductId", "ProductName", "Bilezik", "Brand", "Kadran", "RefCode", "Referans", "Musteri", "Lokasyon", "Ilce", "Ulke", "MusteriInfo", "AlisverisiVarMi", "IrtibatNumarasi", "EmailAdresi", "IletisimKaynagi", "CategoryName", "CategoryCode", "LeadDurumu", "SonrakiAdim", "ProcessName", "ProcessCode", "StepOrder", "SelectedStepOrder", "TerminTarihi", "SatisDanismani", "StoreName" }, prms_TM_TopManagerDashboardLeadList_0.ToArray());
            ;


            return Ok(result);
        }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class DashBoardTempPageInit_Request
    {
        public Guid? UserId_0 { set; get; }
        public Guid? UserId_1 { set; get; }
        public Int32? TaskFilter_1 { set; get; }
        public Int32? ThisMonth_2 { set; get; }
        public Guid? UserId_2 { set; get; }
        public Guid? UserId_3 { set; get; }
        public String MusteriAdi_3 { set; get; }
        public String ProductName_3 { set; get; }
        public String LeadCode_3 { set; get; }
        public String Tel_3 { set; get; }
        public String CategoryName_3 { set; get; }
        public String StoreIds_3 { set; get; }
        public String SatisDanismaniIds_3 { set; get; }
        public String ProcessCode_3 { set; get; }
        public Int32? StepOrder_3 { set; get; }
        public DateTime? StartDate_3 { set; get; }
        public DateTime? EndDate_3 { set; get; }
        public Guid? KUserId_5 { set; get; }
        public Guid? KUserId_6 { set; get; }
        public Guid? StoreId_6 { set; get; }
        public Int32? StepOrder_8 { set; get; }
        public Guid? UserId_9 { set; get; }
        public Guid? UserID_10 { set; get; }
        public Guid? UserId_11 { set; get; }
        public DateTime? StartDate_11 { set; get; }
        public DateTime? EndDate_11 { set; get; }
        public Guid? UserId_12 { set; get; }
        public DateTime? StartDate_12 { set; get; }
        public DateTime? EndDate_12 { set; get; }
        public Guid? UserId_13 { set; get; }
        public DateTime? StartDate_13 { set; get; }
        public DateTime? EndDate_13 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class DashBoardTempPageInit_Response
    {
        public KCommonEntityPage TM_DefDashSummary { set; get; }

        public KCommonEntityPage TMSalesPersonDashBoardTaskList { set; get; }

        public KCommonEntityPage TM_DefDashAnalysis { set; get; }

        public KCommonEntityPage TM_TopManagerDashboardLeadList { set; get; }

        public KCommonEntityPage TM_GetProductCategory { set; get; }

        public KCommonEntityPage TM_GetStore { set; get; }

        public KCommonEntityPage TM_GetSalesPerson { set; get; }

        public KCommonEntityPage TM_GetLeadStatus { set; get; }

        public KCommonEntityPage TM_GetLeadProcess { set; get; }

        public KCommonEntityPage TM_GetUserStoreInfo { set; get; }

        public KCommonEntityPage TM_UserRoleByUserId { set; get; }

        public KCommonEntityPage TM_LeadProcessCountGrafik { set; get; }

        public KCommonEntityPage TM_CategoryGrafik { set; get; }

        public KCommonEntityPage TM_SatisDonusumGrafik { set; get; }

        public KCommonEntityPage TM_GetSalesExchangesRate { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class DashBoardTempComponent_783535_onClick_Request
    {
        public Guid? UserId_0 { set; get; }
        public String MusteriAdi_0 { set; get; }
        public String ProductName_0 { set; get; }
        public String LeadCode_0 { set; get; }
        public String Tel_0 { set; get; }
        public String CategoryName_0 { set; get; }
        public String StoreIds_0 { set; get; }
        public String SatisDanismaniIds_0 { set; get; }
        public String ProcessCode_0 { set; get; }
        public Int32? StepOrder_0 { set; get; }
        public DateTime? StartDate_0 { set; get; }
        public DateTime? EndDate_0 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class DashBoardTempComponent_783535_onClick_Response
    {
        public KCommonEntityPage TM_TopManagerDashboardLeadList { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class DashBoardTempComponent_908387_onClick_Request
    {
        public Guid? UserId_0 { set; get; }
        public String MusteriAdi_0 { set; get; }
        public String ProductName_0 { set; get; }
        public String LeadCode_0 { set; get; }
        public String Tel_0 { set; get; }
        public String CategoryName_0 { set; get; }
        public String StoreIds_0 { set; get; }
        public String SatisDanismaniIds_0 { set; get; }
        public String ProcessCode_0 { set; get; }
        public Int32? StepOrder_0 { set; get; }
        public DateTime? StartDate_0 { set; get; }
        public DateTime? EndDate_0 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class DashBoardTempComponent_908387_onClick_Response
    {
        public KCommonEntityPage TM_TopManagerDashboardLeadList { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class DashBoardTempComponent_398231_onClick_Request
    {
        public Guid? UserId_0 { set; get; }
        public String MusteriAdi_0 { set; get; }
        public String ProductName_0 { set; get; }
        public String LeadCode_0 { set; get; }
        public String Tel_0 { set; get; }
        public String CategoryName_0 { set; get; }
        public String StoreIds_0 { set; get; }
        public String SatisDanismaniIds_0 { set; get; }
        public String ProcessCode_0 { set; get; }
        public Int32? StepOrder_0 { set; get; }
        public DateTime? StartDate_0 { set; get; }
        public DateTime? EndDate_0 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class DashBoardTempComponent_398231_onClick_Response
    {
        public KCommonEntityPage TM_TopManagerDashboardLeadList { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class DashBoardTempComponent_892106_onClick_Request
    {
        public Guid? UserId_0 { set; get; }
        public String MusteriAdi_0 { set; get; }
        public String ProductName_0 { set; get; }
        public String LeadCode_0 { set; get; }
        public String Tel_0 { set; get; }
        public String CategoryName_0 { set; get; }
        public String StoreIds_0 { set; get; }
        public String SatisDanismaniIds_0 { set; get; }
        public String ProcessCode_0 { set; get; }
        public Int32? StepOrder_0 { set; get; }
        public DateTime? StartDate_0 { set; get; }
        public DateTime? EndDate_0 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class DashBoardTempComponent_892106_onClick_Response
    {
        public KCommonEntityPage TM_TopManagerDashboardLeadList { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class DashBoardTempComponent_464762_onClick_Request
    {
        public Guid? UserId_0 { set; get; }
        public String MusteriAdi_0 { set; get; }
        public String ProductName_0 { set; get; }
        public String LeadCode_0 { set; get; }
        public String Tel_0 { set; get; }
        public String CategoryName_0 { set; get; }
        public String StoreIds_0 { set; get; }
        public String SatisDanismaniIds_0 { set; get; }
        public String ProcessCode_0 { set; get; }
        public Int32? StepOrder_0 { set; get; }
        public DateTime? StartDate_0 { set; get; }
        public DateTime? EndDate_0 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class DashBoardTempComponent_464762_onClick_Response
    {
        public KCommonEntityPage TM_TopManagerDashboardLeadList { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class DashBoardTempComponent_134969_onClick_Request
    {
        public Guid? UserId_0 { set; get; }
        public String MusteriAdi_0 { set; get; }
        public String ProductName_0 { set; get; }
        public String LeadCode_0 { set; get; }
        public String Tel_0 { set; get; }
        public String CategoryName_0 { set; get; }
        public String StoreIds_0 { set; get; }
        public String SatisDanismaniIds_0 { set; get; }
        public String ProcessCode_0 { set; get; }
        public Int32? StepOrder_0 { set; get; }
        public DateTime? StartDate_0 { set; get; }
        public DateTime? EndDate_0 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class DashBoardTempComponent_134969_onClick_Response
    {
        public KCommonEntityPage TM_TopManagerDashboardLeadList { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class DashBoardTempComponent_252890_onChange_Request
    {
        public Guid? UserId_0 { set; get; }
        public Int32? TaskFilter_0 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class DashBoardTempComponent_252890_onChange_Response
    {
        public KCommonEntityPage TMSalesPersonDashBoardTaskList { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class DashBoardTempComponent_56981_onClick_Request
    {
        public Guid? UserId_0 { set; get; }
        public String MusteriAdi_0 { set; get; }
        public String ProductName_0 { set; get; }
        public String LeadCode_0 { set; get; }
        public String Tel_0 { set; get; }
        public String CategoryName_0 { set; get; }
        public String StoreIds_0 { set; get; }
        public String SatisDanismaniIds_0 { set; get; }
        public String ProcessCode_0 { set; get; }
        public Int32? StepOrder_0 { set; get; }
        public DateTime? StartDate_0 { set; get; }
        public DateTime? EndDate_0 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class DashBoardTempComponent_56981_onClick_Response
    {
        public KCommonEntityPage TM_TopManagerDashboardLeadList { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class DashBoardTempComponent_462456_onClick_Request
    {
        public Guid? UserId_0 { set; get; }
        public String MusteriAdi_0 { set; get; }
        public String ProductName_0 { set; get; }
        public String LeadCode_0 { set; get; }
        public String Tel_0 { set; get; }
        public String CategoryName_0 { set; get; }
        public String StoreIds_0 { set; get; }
        public String SatisDanismaniIds_0 { set; get; }
        public String ProcessCode_0 { set; get; }
        public Int32? StepOrder_0 { set; get; }
        public DateTime? StartDate_0 { set; get; }
        public DateTime? EndDate_0 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class DashBoardTempComponent_462456_onClick_Response
    {
        public KCommonEntityPage TM_TopManagerDashboardLeadList { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class DashBoardTempComponent_545586_onClick_Request
    {
        public Guid? UserId_0 { set; get; }
        public String MusteriAdi_0 { set; get; }
        public String ProductName_0 { set; get; }
        public String LeadCode_0 { set; get; }
        public String Tel_0 { set; get; }
        public String CategoryName_0 { set; get; }
        public String StoreIds_0 { set; get; }
        public String SatisDanismaniIds_0 { set; get; }
        public String ProcessCode_0 { set; get; }
        public Int32? StepOrder_0 { set; get; }
        public DateTime? StartDate_0 { set; get; }
        public DateTime? EndDate_0 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class DashBoardTempComponent_545586_onClick_Response
    {
        public KCommonEntityPage TM_TopManagerDashboardLeadList { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class DashBoardTempComponent_77242_onClick_Request
    {
        public Guid? UserId_0 { set; get; }
        public String MusteriAdi_0 { set; get; }
        public String ProductName_0 { set; get; }
        public String LeadCode_0 { set; get; }
        public String Tel_0 { set; get; }
        public String CategoryName_0 { set; get; }
        public String StoreIds_0 { set; get; }
        public String SatisDanismaniIds_0 { set; get; }
        public String ProcessCode_0 { set; get; }
        public Int32? StepOrder_0 { set; get; }
        public DateTime? StartDate_0 { set; get; }
        public DateTime? EndDate_0 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class DashBoardTempComponent_77242_onClick_Response
    {
        public KCommonEntityPage TM_TopManagerDashboardLeadList { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class DashBoardTempComponent_744094_onClick_Request
    {
        public Guid? UserId_0 { set; get; }
        public String MusteriAdi_0 { set; get; }
        public String ProductName_0 { set; get; }
        public String LeadCode_0 { set; get; }
        public String Tel_0 { set; get; }
        public String CategoryName_0 { set; get; }
        public String StoreIds_0 { set; get; }
        public String SatisDanismaniIds_0 { set; get; }
        public String ProcessCode_0 { set; get; }
        public Int32? StepOrder_0 { set; get; }
        public DateTime? StartDate_0 { set; get; }
        public DateTime? EndDate_0 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class DashBoardTempComponent_744094_onClick_Response
    {
        public KCommonEntityPage TM_TopManagerDashboardLeadList { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class DashBoardTempComponent_551457_onClick_Request
    {
        public Guid? UserId_0 { set; get; }
        public String MusteriAdi_0 { set; get; }
        public String ProductName_0 { set; get; }
        public String LeadCode_0 { set; get; }
        public String Tel_0 { set; get; }
        public String CategoryName_0 { set; get; }
        public String StoreIds_0 { set; get; }
        public String SatisDanismaniIds_0 { set; get; }
        public String ProcessCode_0 { set; get; }
        public Int32? StepOrder_0 { set; get; }
        public DateTime? StartDate_0 { set; get; }
        public DateTime? EndDate_0 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class DashBoardTempComponent_551457_onClick_Response
    {
        public KCommonEntityPage TM_TopManagerDashboardLeadList { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class DashBoardTempComponent_4159_onClick_Request
    {
        public Guid? UserId_0 { set; get; }
        public String MusteriAdi_0 { set; get; }
        public String ProductName_0 { set; get; }
        public String LeadCode_0 { set; get; }
        public String Tel_0 { set; get; }
        public String CategoryName_0 { set; get; }
        public String StoreIds_0 { set; get; }
        public String SatisDanismaniIds_0 { set; get; }
        public String ProcessCode_0 { set; get; }
        public Int32? StepOrder_0 { set; get; }
        public DateTime? StartDate_0 { set; get; }
        public DateTime? EndDate_0 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class DashBoardTempComponent_4159_onClick_Response
    {
        public KCommonEntityPage TM_TopManagerDashboardLeadList { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class DashBoardTempComponent_397882_onClick_Request
    {
        public Guid? UserId_0 { set; get; }
        public String MusteriAdi_0 { set; get; }
        public String ProductName_0 { set; get; }
        public String LeadCode_0 { set; get; }
        public String Tel_0 { set; get; }
        public String CategoryName_0 { set; get; }
        public String StoreIds_0 { set; get; }
        public String SatisDanismaniIds_0 { set; get; }
        public String ProcessCode_0 { set; get; }
        public Int32? StepOrder_0 { set; get; }
        public DateTime? StartDate_0 { set; get; }
        public DateTime? EndDate_0 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class DashBoardTempComponent_397882_onClick_Response
    {
        public KCommonEntityPage TM_TopManagerDashboardLeadList { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class DashBoardTempComponent_489263_onClick_Request
    {
        public Guid? UserId_0 { set; get; }
        public String MusteriAdi_0 { set; get; }
        public String ProductName_0 { set; get; }
        public String LeadCode_0 { set; get; }
        public String Tel_0 { set; get; }
        public String CategoryName_0 { set; get; }
        public String StoreIds_0 { set; get; }
        public String SatisDanismaniIds_0 { set; get; }
        public String ProcessCode_0 { set; get; }
        public Int32? StepOrder_0 { set; get; }
        public DateTime? StartDate_0 { set; get; }
        public DateTime? EndDate_0 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class DashBoardTempComponent_489263_onClick_Response
    {
        public KCommonEntityPage TM_TopManagerDashboardLeadList { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class DashBoardTempComponent_654813_onClick_Request
    {
        public Guid? UserId_0 { set; get; }
        public String MusteriAdi_0 { set; get; }
        public String ProductName_0 { set; get; }
        public String LeadCode_0 { set; get; }
        public String Tel_0 { set; get; }
        public String CategoryName_0 { set; get; }
        public String StoreIds_0 { set; get; }
        public String SatisDanismaniIds_0 { set; get; }
        public String ProcessCode_0 { set; get; }
        public Int32? StepOrder_0 { set; get; }
        public DateTime? StartDate_0 { set; get; }
        public DateTime? EndDate_0 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class DashBoardTempComponent_654813_onClick_Response
    {
        public KCommonEntityPage TM_TopManagerDashboardLeadList { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class DashBoardTempComponent_371503_onClick_Request
    {
        public Guid? UserId_0 { set; get; }
        public String MusteriAdi_0 { set; get; }
        public String ProductName_0 { set; get; }
        public String LeadCode_0 { set; get; }
        public String Tel_0 { set; get; }
        public String CategoryName_0 { set; get; }
        public String StoreIds_0 { set; get; }
        public String SatisDanismaniIds_0 { set; get; }
        public String ProcessCode_0 { set; get; }
        public Int32? StepOrder_0 { set; get; }
        public DateTime? StartDate_0 { set; get; }
        public DateTime? EndDate_0 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class DashBoardTempComponent_371503_onClick_Response
    {
        public KCommonEntityPage TM_TopManagerDashboardLeadList { set; get; }

    }
}
