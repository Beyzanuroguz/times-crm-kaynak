
using Kuika.Common;
using Kuika.Common.Attributes;
using Kuika.Common.Bases;
using Kuika.Common.Enums;
using Kuika.Common.Accessors;
using Kuika.Common.Json;
using Kuika.Common.Classes;
using Kuika.Common.Exceptions;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Kuika.Common.Helpers;
using Kuika.Common.Settings;
using System.Collections.Generic;
using System;
using Kuika.Common.Extensions;
using System.Linq;
using Kuika.Common.Rest;
using WorkflowCore.Interface;
using Kuika.Common.Interfaces;
using Kuika.Common.Workflow;
using Kuika.Common.Workflow.Extensions;
using Kuika.Common.Workflow.DTOs;
using Kuika.Common.Models;
using Kuika.Common.Menu.Response;
using Kuika.Common.Entities;
using System.Reflection;
using Newtonsoft.Json.Linq;
using Newtonsoft.Json;
using System.Net.Http;
using Iyzipay.Model.V2.Subscription;
using Kuika.Common.Payments.Iyzico;
using Kuika.Common.Payments.Param;
using Iyzipay;
using Kuika.Common.Searching.DTOs;
using Kuika.Common.Helpers.Sap;
using Kuika.Common.Mcp;
using Kuika.Common.Vision.DTOs;
using Kuika.Common.Audit;
using Kuika.Common.Payments.Mobile;
using Kuika.ThirdPartyApisCollection;

namespace Kuika.Reslen_01.Api
{
    [ApiExplorerSettings(GroupName = "all")]
    [Authorize]
    [ApiController]
    [Route("v1/api/TransferFisiDetayi")]
    public class TransferFisiDetayi_Controller : KControllerBase
    {
        private string appName = "wbTimesCRM";
        private Guid appId = Guid.Parse("0e8ecb48-8c52-463c-5db5-08de3ec441b1");
        private static string screenName = "TransferFisiDetayi";
        private Guid screenId = Guid.Parse("1f8d109f-26cc-4fdb-8af7-4fcb74672e7d");
        private string connectionString { get { return Kuika.Common.KContext.GetConnectionString(); } }

        [HttpGet, Route("myroles")]
        public IActionResult GetMyRoles()
        {
            try
            {
                var result = KProviderManager.Authorization.GetMyRoles(appId, appName, screenId, screenName);
                return Ok(result);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new HttpExceptionDto() { Message = ex.Message, StackTrace = ex.StackTrace });
            }
        }


        [HttpPost, Route("TransferFisiDetayiPageInit")]
        public IActionResult TransferFisiDetayiPageInit(TransferFisiDetayiPageInit_Request request)
        {

            var result = new TransferFisiDetayiPageInit_Response();

            var prms_TM_GetTransferERPDetail_0 = new List<kSqlParameter>();
            prms_TM_GetTransferERPDetail_0.Add(new kSqlParameter() { Name = "CurrentUsername", Value = Kuika.Common.KContext.CurrentUser?.Username });
            prms_TM_GetTransferERPDetail_0.Add(new kSqlParameter() { Name = "TransferERPHeaderId", Value = request.TransferERPHeaderId_0 });
            using var auditTM_GetTransferERPDetail_0 = ActionAuditScope.Begin("f4213fe1-908f-3f8a-5665-96eb8b9b73e4", "TM_GetTransferERPDetail", applicationName: "wbTimesCRM", screenOrEndpointName: "TransferFisiDetayi");
            result.TM_GetTransferERPDetail = KPersister.Fetch(KContext.GetConnectionString(), @"SET NOCOUNT ON;

SELECT TOP (1)

    --------------------------------------------------
    -- ERP HEADER
    --------------------------------------------------
    erpHeader.Id AS TransferERPHeaderId,
    erpHeader.TransferERPNumber,
    erpHeader.StatusId AS TransferERPStatusId,

    erpStatus.Code AS TransferERPStatusCode,
    erpStatus.Name AS TransferERPStatusName,

    --------------------------------------------------
    -- FİŞ ONAYLA BUTONU
    --
    -- SADECE:
    -- 1) ERP STATUS = WAITING_APPROVAL
    -- 2) NEBIM SHIPMENT HEADER ID VAR
    -- 3) CURRENT USER KAYNAK / TALEP EDİLEN MAĞAZADA
    --------------------------------------------------
    CASE
        WHEN erpStatus.Code = 'WAITING_APPROVAL'
             AND erpHeader.NebimShipmentHeaderId IS NOT NULL
             AND LTRIM(RTRIM(erpHeader.NebimShipmentHeaderId)) <> ''
             AND currentStore.StoreCode = requestLine.SourceStoreCode
        THEN CAST(1 AS BIT)
        ELSE CAST(0 AS BIT)
    END AS CanApproveSlip,

    --------------------------------------------------
    -- KABUL İŞLEMİNE GİT BUTONU
    --
    -- SADECE:
    -- 1) ERP STATUS = IN_TRANSIT
    -- 2) CURRENT USER ALICI / TALEP EDEN MAĞAZADA
    --------------------------------------------------
    CASE
        WHEN erpStatus.Code = 'IN_TRANSIT'
             AND currentStore.StoreCode = erpHeader.DestinationStoreCode
        THEN CAST(1 AS BIT)
        ELSE CAST(0 AS BIT)
    END AS CanGoToAcceptance,

    erpHeader.SourceStoreName,
    erpHeader.SourceOfficeCode,
    erpHeader.SourceWarehouseCode,

    erpHeader.DestinationStoreCode,
    erpHeader.DestinationStoreName,
    erpHeader.DestinationOfficeCode,
    erpHeader.DestinationWarehouseCode,

    erpHeader.TrackingNumber,
    erpHeader.NebimShipmentHeaderId,
    erpHeader.NebimShippingNumber,

    erpHeader.CreatedAt,
    erpHeader.CreatedBy,

    creator.FirstName + N' ' + creator.LastName AS CreatedByName,

    erpHeader.TransferredAt,
    erpHeader.TransferredBy,

    erpHeader.AcceptedAt,
    erpHeader.AcceptedBy,

    erpHeader.PdfGeneratedAt,

    --------------------------------------------------
    -- ERP LINE
    --------------------------------------------------
    erpLine.Id AS TransferERPLineId,

    erpLine.TransferRequestLineId,

    erpLine.ProductId,
    erpLine.ProductCode,
    erpLine.ProductName,

    erpLine.SerialNumber,
    erpLine.ScannedSerialNumber,

    erpLine.AcceptanceStatusCode,
    erpLine.AcceptanceReason,

    erpLine.AcceptedAt AS LineAcceptedAt,
    erpLine.AcceptedBy AS LineAcceptedBy,

    --------------------------------------------------
    -- REQUEST
    --------------------------------------------------
    requestLine.TransferRequestHeaderId,

    requestHeader.RequestNumber,

    requestLine.LineStatusId,

    lineStatus.Code AS LineStatusCode,
    lineStatus.Name AS LineStatusName,

    --------------------------------------------------
    -- CURRENT USER / STORE
    --
    -- DEBUG İÇİN DE DÖNDÜRÜYORUZ
    --------------------------------------------------
    currentTMUser.Id AS CurrentTMUserId,
    currentTMUser.UserName AS CurrentUserName,
    currentTMUser.Mail AS CurrentUserMail,

    currentStore.Id AS CurrentStoreId,
    currentStore.StoreCode AS CurrentStoreCode,
    currentStore.StoreDesc AS CurrentStoreName,
    currentStore.OfficeCode AS CurrentOfficeCode


FROM tmscrq.TMTransferERPHeader AS erpHeader

INNER JOIN tmscrq.TMTransferERPStatus AS erpStatus
    ON erpStatus.Id = erpHeader.StatusId

INNER JOIN tmscrq.TMTransferERPLine AS erpLine
    ON erpLine.TransferERPHeaderId = erpHeader.Id

LEFT JOIN tmscrq.TMTransferRequestLine AS requestLine
    ON requestLine.Id = erpLine.TransferRequestLineId

LEFT JOIN tmscrq.TMTransferRequestHeader AS requestHeader
    ON requestHeader.Id = requestLine.TransferRequestHeaderId

LEFT JOIN tmscrq.TMTransferRequestLineStatus AS lineStatus
    ON lineStatus.Id = requestLine.LineStatusId

LEFT JOIN dbo.KUser AS creator
    ON creator.Id = erpHeader.CreatedBy

--------------------------------------------------
-- CURRENT USER
--------------------------------------------------
LEFT JOIN tmscrq.TMUser AS currentTMUser
    ON (
        currentTMUser.UserName = @CurrentUsername
        OR currentTMUser.Mail = @CurrentUsername
    )

--------------------------------------------------
-- CURRENT USER STORE
--------------------------------------------------
LEFT JOIN tmscrq.TMStore AS currentStore
    ON currentStore.Id = currentTMUser.StoreID

WHERE erpHeader.Id = @TransferERPHeaderId;

/*


SET NOCOUNT ON;

SELECT TOP (1)

    --------------------------------------------------
    -- ERP HEADER
    --------------------------------------------------
    erpHeader.Id AS TransferERPHeaderId,
    erpHeader.TransferERPNumber,
    erpHeader.StatusId AS TransferERPStatusId,

    erpStatus.Code AS TransferERPStatusCode,
    erpStatus.Name AS TransferERPStatusName,

    erpHeader.SourceStoreName,
    erpHeader.SourceOfficeCode,
    erpHeader.SourceWarehouseCode,

    erpHeader.DestinationStoreCode,
    erpHeader.DestinationStoreName,
    erpHeader.DestinationOfficeCode,
    erpHeader.DestinationWarehouseCode,

    erpHeader.TrackingNumber,
    erpHeader.NebimShipmentHeaderId,
    erpHeader.NebimShippingNumber,

    erpHeader.CreatedAt,
    erpHeader.CreatedBy,

    creator.FirstName + N' ' + creator.LastName AS CreatedByName,

    erpHeader.TransferredAt,
    erpHeader.TransferredBy,

    erpHeader.AcceptedAt,
    erpHeader.AcceptedBy,

    erpHeader.PdfGeneratedAt,

    --------------------------------------------------
    -- ERP LINE
    --------------------------------------------------
    erpLine.Id AS TransferERPLineId,

    erpLine.TransferRequestLineId,

    erpLine.ProductId,
    erpLine.ProductCode,
    erpLine.ProductName,

    erpLine.SerialNumber,
    erpLine.ScannedSerialNumber,

    erpLine.AcceptanceStatusCode,
    erpLine.AcceptanceReason,

    erpLine.AcceptedAt AS LineAcceptedAt,
    erpLine.AcceptedBy AS LineAcceptedBy,

    --------------------------------------------------
    -- REQUEST
    --------------------------------------------------
    requestLine.TransferRequestHeaderId,

    requestHeader.RequestNumber,

    requestLine.LineStatusId,

    lineStatus.Code AS LineStatusCode,
    lineStatus.Name AS LineStatusName

FROM tmscrq.TMTransferERPHeader AS erpHeader

INNER JOIN tmscrq.TMTransferERPStatus AS erpStatus
    ON erpStatus.Id = erpHeader.StatusId

INNER JOIN tmscrq.TMTransferERPLine AS erpLine
    ON erpLine.TransferERPHeaderId = erpHeader.Id

LEFT JOIN tmscrq.TMTransferRequestLine AS requestLine
    ON requestLine.Id = erpLine.TransferRequestLineId

LEFT JOIN tmscrq.TMTransferRequestHeader AS requestHeader
    ON requestHeader.Id = requestLine.TransferRequestHeaderId

LEFT JOIN tmscrq.TMTransferRequestLineStatus AS lineStatus
    ON lineStatus.Id = requestLine.LineStatusId

LEFT JOIN dbo.KUser AS creator
    ON creator.Id = erpHeader.CreatedBy

WHERE erpHeader.Id = @TransferERPHeaderId;

*/", new string[] { "TransferERPHeaderId", "TransferERPNumber", "TransferERPStatusId", "TransferERPStatusCode", "TransferERPStatusName", "CanApproveSlip", "CanGoToAcceptance", "SourceStoreName", "SourceOfficeCode", "SourceWarehouseCode", "DestinationStoreCode", "DestinationStoreName", "DestinationOfficeCode", "DestinationWarehouseCode", "TrackingNumber", "NebimShipmentHeaderId", "NebimShippingNumber", "CreatedAt", "CreatedBy", "CreatedByName", "TransferredAt", "TransferredBy", "AcceptedAt", "AcceptedBy", "PdfGeneratedAt", "TransferERPLineId", "TransferRequestLineId", "ProductId", "ProductCode", "ProductName", "SerialNumber", "ScannedSerialNumber", "AcceptanceStatusCode", "AcceptanceReason", "LineAcceptedAt", "LineAcceptedBy", "TransferRequestHeaderId", "RequestNumber", "LineStatusId", "LineStatusCode", "LineStatusName", "CurrentTMUserId", "CurrentUserName", "CurrentUserMail", "CurrentStoreId", "CurrentStoreCode", "CurrentStoreName", "CurrentOfficeCode" }, prms_TM_GetTransferERPDetail_0.ToArray());
            ;


            return Ok(result);
        }


        [HttpPost, Route("TransferFisiDetayiComponent_1917891487_onClick")]
        public IActionResult TransferFisiDetayiComponent_1917891487_onClick(TransferFisiDetayiComponent_1917891487_onClick_Request request)
        {

            var result = new TransferFisiDetayiComponent_1917891487_onClick_Response();

            var prms_GetBase64Sql_0 = new List<kSqlParameter>();
            prms_GetBase64Sql_0.Add(new kSqlParameter() { Name = "TransferERPHeaderId", Value = request.TransferERPHeaderId_0 });
            using var auditGetBase64Sql_0 = ActionAuditScope.Begin("8cac0b0a-a099-c0bd-404e-35c6ae779ff5", "GetBase64Sql", applicationName: "wbTimesCRM", screenOrEndpointName: "TransferFisiDetayi");
            result.GetBase64Sql = KPersister.Fetch(KContext.GetConnectionString(), @"SELECT
    Base64Pdf
FROM tmscrq.TMTransferERPHeader
WHERE Id = @TransferERPHeaderId;", new string[] { "Base64Pdf" }, prms_GetBase64Sql_0.ToArray());
            ;


            using var auditDecode_1 = ActionAuditScope.Begin("21040cf9-d5c2-14d5-3ce6-cb136714a157", "Decode", applicationName: "wbTimesCRM", screenOrEndpointName: "TransferFisiDetayi");
            using var actionAuditDecode_1 = ActionAuditHelper.Begin("Decode", new { base64 = (result.GetBase64Sql.ResultList.FirstOrDefault()?.GetValueByFieldName("Base64Pdf")).ConvertToType<String>() });
            try
            {
                result.Decode = Kuika.ThirdPartyApisCollection.Base64ToHtml.Decode((result.GetBase64Sql.ResultList.FirstOrDefault()?.GetValueByFieldName("Base64Pdf")).ConvertToType<String>());
                actionAuditDecode_1.SetResult(result.Decode);
            }
            catch (Exception ex)
            {
                actionAuditDecode_1.SetException(ex);
                throw;
            }
;


            return Ok(result);
        }


        [HttpPost, Route("TransferFisiDetayiComponent_836453_onClick")]
        public IActionResult TransferFisiDetayiComponent_836453_onClick(TransferFisiDetayiComponent_836453_onClick_Request request)
        {

            var result = new TransferFisiDetayiComponent_836453_onClick_Response();


            using var auditKuika_EShipmentSerialNumberPrefix_0 = ActionAuditScope.Begin("36122fc8-f1a0-f086-6000-790fc7e7c577", "Kuika_EShipmentSerialNumberPrefix", applicationName: "wbTimesCRM", screenOrEndpointName: "TransferFisiDetayi");
            using var actionAuditKuika_EShipmentSerialNumberPrefix_0 = ActionAuditHelper.Begin("Kuika_EShipmentSerialNumberPrefix", new { OfficeCode = request.OfficeCode_0.ConvertToType<String>(), StoreCode = request.StoreCode_0.ConvertToType<String>() });
            try
            {
                result.Kuika_EShipmentSerialNumberPrefix = Kuika.ThirdPartyApisCollection.GetEShipmentPrefix.Kuika_EShipmentSerialNumberPrefix(request.OfficeCode_0.ConvertToType<String>(), request.StoreCode_0.ConvertToType<String>());
                actionAuditKuika_EShipmentSerialNumberPrefix_0.SetResult(result.Kuika_EShipmentSerialNumberPrefix);
            }
            catch (Exception ex)
            {
                actionAuditKuika_EShipmentSerialNumberPrefix_0.SetException(ex);
                throw;
            }
;


            using var auditSendEShipment_1 = ActionAuditScope.Begin("1cb40176-1f59-0a39-0ce0-21a519aefcd1", "SendEShipment", applicationName: "wbTimesCRM", screenOrEndpointName: "TransferFisiDetayi");
            using var actionAuditSendEShipment_1 = ActionAuditHelper.Begin("SendEShipment", new { shipmentHeaderId = request.shipmentHeaderId_1.ConvertToType<String>(), shippingDate = request.shippingDate_1.ConvertToType<String>(), prefix = (String)result.Kuika_EShipmentSerialNumberPrefix.FirstOrDefault()?.EShipmentPrefixCode.ConvertToType<String>(), queryName = "Times Seri Numaralı".ConvertToType<String>() });
            try
            {
                result.SendEShipment = Kuika.ThirdPartyApisCollection.TransferEShipmentPost.SendEShipment(request.shipmentHeaderId_1.ConvertToType<String>(), request.shippingDate_1.ConvertToType<String>(), (String)result.Kuika_EShipmentSerialNumberPrefix.FirstOrDefault()?.EShipmentPrefixCode.ConvertToType<String>(), "Times Seri Numaralı".ConvertToType<String>());
                actionAuditSendEShipment_1.SetResult(result.SendEShipment);
            }
            catch (Exception ex)
            {
                actionAuditSendEShipment_1.SetException(ex);
                throw;
            }
;

            var prms_TMTransferApprovePostAfterSql_2 = new List<kSqlParameter>();
            prms_TMTransferApprovePostAfterSql_2.Add(new kSqlParameter() { Name = "IsSuccess", Value = result.SendEShipment.IsSuccess });
            prms_TMTransferApprovePostAfterSql_2.Add(new kSqlParameter() { Name = "TransferERPHeaderId", Value = request.TransferERPHeaderId_2 });
            prms_TMTransferApprovePostAfterSql_2.Add(new kSqlParameter() { Name = "TransferRequestHeaderId", Value = request.TransferRequestHeaderId_2 });
            prms_TMTransferApprovePostAfterSql_2.Add(new kSqlParameter() { Name = "TransferRequestLineId", Value = request.TransferRequestLineId_2 });
            prms_TMTransferApprovePostAfterSql_2.Add(new kSqlParameter() { Name = "Request", Value = result.SendEShipment.Request });
            prms_TMTransferApprovePostAfterSql_2.Add(new kSqlParameter() { Name = "Response", Value = result.SendEShipment.Response });
            prms_TMTransferApprovePostAfterSql_2.Add(new kSqlParameter() { Name = "CurrentUsername", Value = Kuika.Common.KContext.CurrentUser?.Username });
            prms_TMTransferApprovePostAfterSql_2.Add(new kSqlParameter() { Name = "Base64Pdf", Value = result.SendEShipment.PrintResult });
            using var auditTMTransferApprovePostAfterSql_2 = ActionAuditScope.Begin("47c5b946-38bd-2cd1-ac11-8fd86be851a6", "TMTransferApprovePostAfterSql", applicationName: "wbTimesCRM", screenOrEndpointName: "TransferFisiDetayi");
            result.TMTransferApprovePostAfterSql = KPersister.Fetch(KContext.GetConnectionString(), @"SET NOCOUNT ON;
SET XACT_ABORT ON;
SET TRANSACTION ISOLATION LEVEL SERIALIZABLE;

------------------------------------------------------------
-- INPUTLAR
--
-- DIŞARIDAN:
-- @TransferERPHeaderId
-- @TransferRequestHeaderId
-- @TransferRequestLineId
-- @CurrentUsername
-- @Base64Pdf
--
-- C#:
-- @IsSuccess
-- @Request
-- @Response
------------------------------------------------------------


------------------------------------------------------------
-- VARIABLES
------------------------------------------------------------

DECLARE @CurrentUserId UNIQUEIDENTIFIER;

DECLARE @TransferERPHeaderIdLocal UNIQUEIDENTIFIER;
DECLARE @TransferRequestHeaderIdLocal UNIQUEIDENTIFIER;
DECLARE @TransferRequestLineIdLocal UNIQUEIDENTIFIER;

DECLARE @CurrentERPStatusCode NVARCHAR(100);
DECLARE @TransferInProgressStatusId UNIQUEIDENTIFIER;
DECLARE @WaitingApprovalStatusId UNIQUEIDENTIFIER;

DECLARE @NebimShipmentHeaderId NVARCHAR(400);
DECLARE @NebimShippingNumber NVARCHAR(400);

DECLARE @NormalizedUsername NVARCHAR(200);

DECLARE @PostIsSuccess INT = 0;

DECLARE @SqlSuccess BIT = 0;
DECLARE @SqlErrorMessage NVARCHAR(MAX) = NULL;


------------------------------------------------------------
-- ==========================================================
-- C# RESPONSE
-- ==========================================================
------------------------------------------------------------

SET @PostIsSuccess = ISNULL(@IsSuccess, 0);


------------------------------------------------------------
-- ==========================================================
-- DIŞARIDAN GELEN ID'LER
-- ==========================================================
------------------------------------------------------------

SET @TransferERPHeaderIdLocal =
    TRY_CONVERT(
        UNIQUEIDENTIFIER,
        @TransferERPHeaderId
    );

SET @TransferRequestHeaderIdLocal =
    TRY_CONVERT(
        UNIQUEIDENTIFIER,
        @TransferRequestHeaderId
    );

SET @TransferRequestLineIdLocal =
    TRY_CONVERT(
        UNIQUEIDENTIFIER,
        @TransferRequestLineId
    );


------------------------------------------------------------
-- ==========================================================
-- REQUEST'TEN NEBIM SHIPMENT HEADER ID
-- ==========================================================
------------------------------------------------------------

SET @NebimShipmentHeaderId =
    NULLIF(
        LTRIM(
            RTRIM(
                JSON_VALUE(
                    @Request,
                    '$.ShipmentHeaderID'
                )
            )
        ),
        N''
    );


------------------------------------------------------------
-- ==========================================================
-- RESPONSE'TAN NEBIM SHIPPING NUMBER
-- ==========================================================
------------------------------------------------------------

SET @NebimShippingNumber =
    NULLIF(
        LTRIM(
            RTRIM(
                JSON_VALUE(
                    @Response,
                    '$.ShippingNumber'
                )
            )
        ),
        N''
    );


------------------------------------------------------------
-- ==========================================================
-- CURRENT USER
-- ==========================================================
------------------------------------------------------------

SET @NormalizedUsername =
    LOWER(
        LTRIM(
            RTRIM(
                CAST(
                    @CurrentUsername AS NVARCHAR(200)
                )
            )
        )
    );


SELECT TOP (1)
    @CurrentUserId = userRecord.KuserID
FROM tmscrq.TMUser AS userRecord
WHERE
       LOWER(LTRIM(RTRIM(userRecord.UserName))) =
           @NormalizedUsername

    OR LOWER(LTRIM(RTRIM(userRecord.Mail))) =
           @NormalizedUsername

    OR LOWER(LTRIM(RTRIM(userRecord.UserName))) =
       CASE
           WHEN CHARINDEX(N'@', @NormalizedUsername) > 0
           THEN LEFT(
                    @NormalizedUsername,
                    CHARINDEX(
                        N'@',
                        @NormalizedUsername
                    ) - 1
                )
           ELSE @NormalizedUsername
       END;


------------------------------------------------------------
-- ==========================================================
-- TEMEL KONTROLLER
-- ==========================================================
------------------------------------------------------------

IF @CurrentUserId IS NULL
BEGIN
    SET @SqlErrorMessage =
        N'Kullanıcı bulunamadı.';
END;


IF @SqlErrorMessage IS NULL
   AND @TransferERPHeaderIdLocal IS NULL
BEGIN
    SET @SqlErrorMessage =
        N'TransferERPHeaderId boş veya geçersiz.';
END;


IF @SqlErrorMessage IS NULL
   AND @TransferRequestHeaderIdLocal IS NULL
BEGIN
    SET @SqlErrorMessage =
        N'TransferRequestHeaderId boş veya geçersiz.';
END;


IF @SqlErrorMessage IS NULL
   AND @TransferRequestLineIdLocal IS NULL
BEGIN
    SET @SqlErrorMessage =
        N'TransferRequestLineId boş veya geçersiz.';
END;


------------------------------------------------------------
-- ==========================================================
-- ERP HEADER KONTROL
-- ==========================================================
------------------------------------------------------------

IF @SqlErrorMessage IS NULL
BEGIN

    SELECT TOP (1)
        @CurrentERPStatusCode = erpStatus.Code
    FROM tmscrq.TMTransferERPHeader AS erpHeader
    INNER JOIN tmscrq.TMTransferERPStatus AS erpStatus
        ON erpStatus.Id = erpHeader.StatusId
    WHERE erpHeader.Id =
          @TransferERPHeaderIdLocal;


    IF @CurrentERPStatusCode IS NULL
    BEGIN

        SET @SqlErrorMessage =
            N'Transfer ERP Header bulunamadı.';

    END;

END;


------------------------------------------------------------
-- ==========================================================
-- WAITING_APPROVAL STATUS ID
-- ==========================================================
------------------------------------------------------------

IF @SqlErrorMessage IS NULL
BEGIN

    SELECT TOP (1)
        @WaitingApprovalStatusId = Id
    FROM tmscrq.TMTransferERPStatus
    WHERE Code = N'WAITING_APPROVAL'
      AND IsActive = 1;


    IF @WaitingApprovalStatusId IS NULL
    BEGIN

        SET @SqlErrorMessage =
            N'WAITING_APPROVAL statusu bulunamadı.';

    END;

END;


------------------------------------------------------------
-- ==========================================================
-- NEBIM BAŞARISIZ
--
-- BUSINESS UPDATE YOK
-- LOG AŞAĞIDA YAZILACAK
-- ==========================================================
------------------------------------------------------------

IF @SqlErrorMessage IS NULL
   AND @PostIsSuccess = 0
BEGIN

    SET @SqlErrorMessage =
        N'Nebim transfer onayı başarısız.';

END;


------------------------------------------------------------
-- ==========================================================
-- NEBIM BAŞARILI
--
-- WAITING_APPROVAL
--        ↓
-- IN_TRANSIT
-- ==========================================================
------------------------------------------------------------

IF @SqlErrorMessage IS NULL
   AND @PostIsSuccess = 1
BEGIN

    BEGIN TRY

        BEGIN TRANSACTION;


        ------------------------------------------------------
        -- STATUS KONTROLÜ
        ------------------------------------------------------

        IF ISNULL(
            @CurrentERPStatusCode,
            N''
        ) <> N'WAITING_APPROVAL'
        BEGIN

            THROW 50801,
                N'Transfer ERP kaydı WAITING_APPROVAL durumunda değil.',
                1;

        END;


        ------------------------------------------------------
        -- IN_TRANSIT STATUS ID
        ------------------------------------------------------

        SELECT TOP (1)
            @TransferInProgressStatusId = Id
        FROM tmscrq.TMTransferERPStatus
        WHERE Code = N'IN_TRANSIT'
          AND IsActive = 1;


        IF @TransferInProgressStatusId IS NULL
        BEGIN

            THROW 50802,
                N'IN_TRANSIT statusu bulunamadı.',
                1;

        END;


        ------------------------------------------------------
        -- ERP HEADER UPDATE
        --
        -- WAITING_APPROVAL
        --       ↓
        -- IN_TRANSIT
        ------------------------------------------------------

        UPDATE tmscrq.TMTransferERPHeader
        SET
            StatusId =
                @TransferInProgressStatusId,

            NebimShipmentHeaderId =
                @NebimShipmentHeaderId,

            NebimShippingNumber =
                COALESCE(
                    @NebimShippingNumber,
                    NebimShippingNumber
                ),

            Base64Pdf =
                COALESCE(
                    NULLIF(@Base64Pdf, N''),
                    Base64Pdf
                ),

            TransferredAt =
                SYSDATETIMEOFFSET(),

            TransferredBy =
                @CurrentUserId

        WHERE Id =
              @TransferERPHeaderIdLocal

          AND StatusId =
              @WaitingApprovalStatusId;


        IF @@ROWCOUNT = 0
        BEGIN

            THROW 50803,
                N'Transfer ERP Header IN_TRANSIT durumuna geçirilemedi.',
                1;

        END;


        ------------------------------------------------------
        -- REQUEST LINE DEĞİŞTİRİLMEYECEK
        ------------------------------------------------------


        ------------------------------------------------------
        -- REQUEST HEADER DEĞİŞTİRİLMEYECEK
        ------------------------------------------------------


        ------------------------------------------------------
        -- ERP LINE DEĞİŞTİRİLMEYECEK
        ------------------------------------------------------


        ------------------------------------------------------
        -- EVENT LOG
        ------------------------------------------------------

        INSERT INTO tmscrq.TMTransferEventLog
        (
            Id,
            CreatedAt,
            CreatedBy,
            Description,
            EntityTypeCode,
            EventTypeCode,
            NewValue,
            OldValue,
            TransferRequestHeaderId
        )
        VALUES
        (
            NEWID(),

            SYSDATETIMEOFFSET(),

            @CurrentUserId,

            N'Nebim transfer fişi onaylandı. '
            + N'ShipmentHeaderID: '
            + ISNULL(
                @NebimShipmentHeaderId,
                N''
              )
            + N' - ShippingNumber: '
            + ISNULL(
                @NebimShippingNumber,
                N''
              ),

            N'TRANSFER_ERP_HEADER',

            N'TRANSFER_APPROVED',

            N'IN_TRANSIT',

            N'WAITING_APPROVAL',

            @TransferRequestHeaderIdLocal
        );


        ------------------------------------------------------
        -- COMMIT
        ------------------------------------------------------

        COMMIT TRANSACTION;

        SET @SqlSuccess = 1;


    END TRY

    BEGIN CATCH

        IF XACT_STATE() <> 0
        BEGIN
            ROLLBACK TRANSACTION;
        END;


        SET @SqlSuccess = 0;

        SET @SqlErrorMessage =
            N'Transfer onay SQL işlemi başarısız oldu. '
            + N'SQL ERROR: '
            + ERROR_MESSAGE();

    END CATCH;

END;


------------------------------------------------------------
-- ==========================================================
-- APPROVAL LOG
--
-- NEBIM BAŞARILI / BAŞARISIZ
-- SQL BAŞARILI / BAŞARISIZ
-- HER DURUMDA LOG YAZILMAYA ÇALIŞILIR
--
-- tmscrq.TMTransferERPApprovalLog
-- ==========================================================
------------------------------------------------------------

BEGIN TRY

    INSERT INTO tmscrq.TMTransferERPApprovalLog
    (
        Id,
        CreatedAt,
        CreatedBy,
        ErrorMessage,
        IsSuccess,
        NebimShipmentHeaderId,
        NebimShippingNumber,
        Request,
        Response,
        TransferERPHeaderId,
        TransferRequestHeaderId,
        TransferRequestLineId
    )
    VALUES
    (
        NEWID(),

        SYSDATETIMEOFFSET(),

        @CurrentUserId,

        CASE
            WHEN @SqlSuccess = 0
            THEN @SqlErrorMessage
            ELSE NULL
        END,

        CASE
            WHEN
                @PostIsSuccess = 1
                AND @SqlSuccess = 1
            THEN 1
            ELSE 0
        END,

        @NebimShipmentHeaderId,

        @NebimShippingNumber,

        @Request,

        @Response,

        @TransferERPHeaderIdLocal,

        @TransferRequestHeaderIdLocal,

        @TransferRequestLineIdLocal
    );

END TRY

BEGIN CATCH

    SET @SqlErrorMessage =
        ISNULL(
            @SqlErrorMessage + N' | ',
            N''
        )
        + N'ApprovalLog INSERT ERROR: '
        + ERROR_MESSAGE();

END CATCH;


------------------------------------------------------------
-- ==========================================================
-- FINAL RESULT
-- ==========================================================
------------------------------------------------------------

SELECT

    CASE
        WHEN
            @PostIsSuccess = 1
            AND @SqlSuccess = 1
        THEN CAST(1 AS BIT)

        ELSE CAST(0 AS BIT)
    END AS Success,

    CASE
        WHEN
            @PostIsSuccess = 1
            AND @SqlSuccess = 1
        THEN
            N'Transfer başarıyla onaylandı.'

        ELSE
            ISNULL(
                @SqlErrorMessage,
                N'Nebim transfer onayı başarısız.'
            )
    END AS Message;", new string[] { "Success", "Message" }, prms_TMTransferApprovePostAfterSql_2.ToArray());
            ;


            return Ok(result);
        }


        [HttpPost, Route("TransferFisiDetayiComponent_661611_onChange")]
        public IActionResult TransferFisiDetayiComponent_661611_onChange(TransferFisiDetayiComponent_661611_onChange_Request request)
        {

            var result = new TransferFisiDetayiComponent_661611_onChange_Response();

            var prms_TM_GetTransferERPDetail_0 = new List<kSqlParameter>();
            prms_TM_GetTransferERPDetail_0.Add(new kSqlParameter() { Name = "CurrentUsername", Value = Kuika.Common.KContext.CurrentUser?.Username });
            prms_TM_GetTransferERPDetail_0.Add(new kSqlParameter() { Name = "TransferERPHeaderId", Value = request.TransferERPHeaderId_0 });
            using var auditTM_GetTransferERPDetail_0 = ActionAuditScope.Begin("97ba1e97-daa2-109d-5809-1bfa267d9ff6", "TM_GetTransferERPDetail", applicationName: "wbTimesCRM", screenOrEndpointName: "TransferFisiDetayi");
            result.TM_GetTransferERPDetail = KPersister.Fetch(KContext.GetConnectionString(), @"SET NOCOUNT ON;

SELECT TOP (1)

    --------------------------------------------------
    -- ERP HEADER
    --------------------------------------------------
    erpHeader.Id AS TransferERPHeaderId,
    erpHeader.TransferERPNumber,
    erpHeader.StatusId AS TransferERPStatusId,

    erpStatus.Code AS TransferERPStatusCode,
    erpStatus.Name AS TransferERPStatusName,

    --------------------------------------------------
    -- FİŞ ONAYLA BUTONU
    --
    -- SADECE:
    -- 1) ERP STATUS = WAITING_APPROVAL
    -- 2) NEBIM SHIPMENT HEADER ID VAR
    -- 3) CURRENT USER KAYNAK / TALEP EDİLEN MAĞAZADA
    --------------------------------------------------
    CASE
        WHEN erpStatus.Code = 'WAITING_APPROVAL'
             AND erpHeader.NebimShipmentHeaderId IS NOT NULL
             AND LTRIM(RTRIM(erpHeader.NebimShipmentHeaderId)) <> ''
             AND currentStore.StoreCode = requestLine.SourceStoreCode
        THEN CAST(1 AS BIT)
        ELSE CAST(0 AS BIT)
    END AS CanApproveSlip,

    --------------------------------------------------
    -- KABUL İŞLEMİNE GİT BUTONU
    --
    -- SADECE:
    -- 1) ERP STATUS = IN_TRANSIT
    -- 2) CURRENT USER ALICI / TALEP EDEN MAĞAZADA
    --------------------------------------------------
    CASE
        WHEN erpStatus.Code = 'IN_TRANSIT'
             AND currentStore.StoreCode = erpHeader.DestinationStoreCode
        THEN CAST(1 AS BIT)
        ELSE CAST(0 AS BIT)
    END AS CanGoToAcceptance,

    erpHeader.SourceStoreName,
    erpHeader.SourceOfficeCode,
    erpHeader.SourceWarehouseCode,

    erpHeader.DestinationStoreCode,
    erpHeader.DestinationStoreName,
    erpHeader.DestinationOfficeCode,
    erpHeader.DestinationWarehouseCode,

    erpHeader.TrackingNumber,
    erpHeader.NebimShipmentHeaderId,
    erpHeader.NebimShippingNumber,

    erpHeader.CreatedAt,
    erpHeader.CreatedBy,

    creator.FirstName + N' ' + creator.LastName AS CreatedByName,

    erpHeader.TransferredAt,
    erpHeader.TransferredBy,

    erpHeader.AcceptedAt,
    erpHeader.AcceptedBy,

    erpHeader.PdfGeneratedAt,

    --------------------------------------------------
    -- ERP LINE
    --------------------------------------------------
    erpLine.Id AS TransferERPLineId,

    erpLine.TransferRequestLineId,

    erpLine.ProductId,
    erpLine.ProductCode,
    erpLine.ProductName,

    erpLine.SerialNumber,
    erpLine.ScannedSerialNumber,

    erpLine.AcceptanceStatusCode,
    erpLine.AcceptanceReason,

    erpLine.AcceptedAt AS LineAcceptedAt,
    erpLine.AcceptedBy AS LineAcceptedBy,

    --------------------------------------------------
    -- REQUEST
    --------------------------------------------------
    requestLine.TransferRequestHeaderId,

    requestHeader.RequestNumber,

    requestLine.LineStatusId,

    lineStatus.Code AS LineStatusCode,
    lineStatus.Name AS LineStatusName,

    --------------------------------------------------
    -- CURRENT USER / STORE
    --
    -- DEBUG İÇİN DE DÖNDÜRÜYORUZ
    --------------------------------------------------
    currentTMUser.Id AS CurrentTMUserId,
    currentTMUser.UserName AS CurrentUserName,
    currentTMUser.Mail AS CurrentUserMail,

    currentStore.Id AS CurrentStoreId,
    currentStore.StoreCode AS CurrentStoreCode,
    currentStore.StoreDesc AS CurrentStoreName,
    currentStore.OfficeCode AS CurrentOfficeCode


FROM tmscrq.TMTransferERPHeader AS erpHeader

INNER JOIN tmscrq.TMTransferERPStatus AS erpStatus
    ON erpStatus.Id = erpHeader.StatusId

INNER JOIN tmscrq.TMTransferERPLine AS erpLine
    ON erpLine.TransferERPHeaderId = erpHeader.Id

LEFT JOIN tmscrq.TMTransferRequestLine AS requestLine
    ON requestLine.Id = erpLine.TransferRequestLineId

LEFT JOIN tmscrq.TMTransferRequestHeader AS requestHeader
    ON requestHeader.Id = requestLine.TransferRequestHeaderId

LEFT JOIN tmscrq.TMTransferRequestLineStatus AS lineStatus
    ON lineStatus.Id = requestLine.LineStatusId

LEFT JOIN dbo.KUser AS creator
    ON creator.Id = erpHeader.CreatedBy

--------------------------------------------------
-- CURRENT USER
--------------------------------------------------
LEFT JOIN tmscrq.TMUser AS currentTMUser
    ON (
        currentTMUser.UserName = @CurrentUsername
        OR currentTMUser.Mail = @CurrentUsername
    )

--------------------------------------------------
-- CURRENT USER STORE
--------------------------------------------------
LEFT JOIN tmscrq.TMStore AS currentStore
    ON currentStore.Id = currentTMUser.StoreID

WHERE erpHeader.Id = @TransferERPHeaderId;

/*


SET NOCOUNT ON;

SELECT TOP (1)

    --------------------------------------------------
    -- ERP HEADER
    --------------------------------------------------
    erpHeader.Id AS TransferERPHeaderId,
    erpHeader.TransferERPNumber,
    erpHeader.StatusId AS TransferERPStatusId,

    erpStatus.Code AS TransferERPStatusCode,
    erpStatus.Name AS TransferERPStatusName,

    erpHeader.SourceStoreName,
    erpHeader.SourceOfficeCode,
    erpHeader.SourceWarehouseCode,

    erpHeader.DestinationStoreCode,
    erpHeader.DestinationStoreName,
    erpHeader.DestinationOfficeCode,
    erpHeader.DestinationWarehouseCode,

    erpHeader.TrackingNumber,
    erpHeader.NebimShipmentHeaderId,
    erpHeader.NebimShippingNumber,

    erpHeader.CreatedAt,
    erpHeader.CreatedBy,

    creator.FirstName + N' ' + creator.LastName AS CreatedByName,

    erpHeader.TransferredAt,
    erpHeader.TransferredBy,

    erpHeader.AcceptedAt,
    erpHeader.AcceptedBy,

    erpHeader.PdfGeneratedAt,

    --------------------------------------------------
    -- ERP LINE
    --------------------------------------------------
    erpLine.Id AS TransferERPLineId,

    erpLine.TransferRequestLineId,

    erpLine.ProductId,
    erpLine.ProductCode,
    erpLine.ProductName,

    erpLine.SerialNumber,
    erpLine.ScannedSerialNumber,

    erpLine.AcceptanceStatusCode,
    erpLine.AcceptanceReason,

    erpLine.AcceptedAt AS LineAcceptedAt,
    erpLine.AcceptedBy AS LineAcceptedBy,

    --------------------------------------------------
    -- REQUEST
    --------------------------------------------------
    requestLine.TransferRequestHeaderId,

    requestHeader.RequestNumber,

    requestLine.LineStatusId,

    lineStatus.Code AS LineStatusCode,
    lineStatus.Name AS LineStatusName

FROM tmscrq.TMTransferERPHeader AS erpHeader

INNER JOIN tmscrq.TMTransferERPStatus AS erpStatus
    ON erpStatus.Id = erpHeader.StatusId

INNER JOIN tmscrq.TMTransferERPLine AS erpLine
    ON erpLine.TransferERPHeaderId = erpHeader.Id

LEFT JOIN tmscrq.TMTransferRequestLine AS requestLine
    ON requestLine.Id = erpLine.TransferRequestLineId

LEFT JOIN tmscrq.TMTransferRequestHeader AS requestHeader
    ON requestHeader.Id = requestLine.TransferRequestHeaderId

LEFT JOIN tmscrq.TMTransferRequestLineStatus AS lineStatus
    ON lineStatus.Id = requestLine.LineStatusId

LEFT JOIN dbo.KUser AS creator
    ON creator.Id = erpHeader.CreatedBy

WHERE erpHeader.Id = @TransferERPHeaderId;

*/", new string[] { "TransferERPHeaderId", "TransferERPNumber", "TransferERPStatusId", "TransferERPStatusCode", "TransferERPStatusName", "CanApproveSlip", "CanGoToAcceptance", "SourceStoreName", "SourceOfficeCode", "SourceWarehouseCode", "DestinationStoreCode", "DestinationStoreName", "DestinationOfficeCode", "DestinationWarehouseCode", "TrackingNumber", "NebimShipmentHeaderId", "NebimShippingNumber", "CreatedAt", "CreatedBy", "CreatedByName", "TransferredAt", "TransferredBy", "AcceptedAt", "AcceptedBy", "PdfGeneratedAt", "TransferERPLineId", "TransferRequestLineId", "ProductId", "ProductCode", "ProductName", "SerialNumber", "ScannedSerialNumber", "AcceptanceStatusCode", "AcceptanceReason", "LineAcceptedAt", "LineAcceptedBy", "TransferRequestHeaderId", "RequestNumber", "LineStatusId", "LineStatusCode", "LineStatusName", "CurrentTMUserId", "CurrentUserName", "CurrentUserMail", "CurrentStoreId", "CurrentStoreCode", "CurrentStoreName", "CurrentOfficeCode" }, prms_TM_GetTransferERPDetail_0.ToArray());
            ;


            return Ok(result);
        }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class TransferFisiDetayiPageInit_Request
    {
        public String CurrentUsername_0 { set; get; }
        public Guid? TransferERPHeaderId_0 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class TransferFisiDetayiPageInit_Response
    {
        public KCommonEntityPage TM_GetTransferERPDetail { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class TransferFisiDetayiComponent_1917891487_onClick_Request
    {
        public Guid? TransferERPHeaderId_0 { set; get; }
        public String? base64_1 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class TransferFisiDetayiComponent_1917891487_onClick_Response
    {
        public KCommonEntityPage GetBase64Sql { set; get; }

        public String Decode { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class TransferFisiDetayiComponent_836453_onClick_Request
    {
        public String? OfficeCode_0 { set; get; }
        public String? StoreCode_0 { set; get; }
        public String? shipmentHeaderId_1 { set; get; }
        public String? shippingDate_1 { set; get; }
        public String? prefix_1 { set; get; }
        public String? queryName_1 { set; get; }
        public Int32? IsSuccess_2 { set; get; }
        public Guid? TransferERPHeaderId_2 { set; get; }
        public Guid? TransferRequestHeaderId_2 { set; get; }
        public Guid? TransferRequestLineId_2 { set; get; }
        public String Request_2 { set; get; }
        public String Response_2 { set; get; }
        public String CurrentUsername_2 { set; get; }
        public String Base64Pdf_2 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class TransferFisiDetayiComponent_836453_onClick_Response
    {
        public System.Collections.Generic.IList<Kuika.ThirdPartyApisCollection.Kuika_EShipmentSerialNumberPrefixClass> Kuika_EShipmentSerialNumberPrefix { set; get; }

        public Kuika.ThirdPartyApisCollection.TransferEShipmentResponse SendEShipment { set; get; }

        public KCommonEntityPage TMTransferApprovePostAfterSql { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class TransferFisiDetayiComponent_661611_onChange_Request
    {
        public String CurrentUsername_0 { set; get; }
        public Guid? TransferERPHeaderId_0 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class TransferFisiDetayiComponent_661611_onChange_Response
    {
        public KCommonEntityPage TM_GetTransferERPDetail { set; get; }

    }
}
