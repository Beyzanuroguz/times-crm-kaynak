
using Kuika.Common;
using Kuika.Common.Attributes;
using Kuika.Common.Bases;
using Kuika.Common.Enums;
using Kuika.Common.Accessors;
using Kuika.Common.Json;
using Kuika.Common.Classes;
using Kuika.Common.Exceptions;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Kuika.Common.Helpers;
using Kuika.Common.Settings;
using System.Collections.Generic;
using System;
using Kuika.Common.Extensions;
using System.Linq;
using Kuika.Common.Rest;
using WorkflowCore.Interface;
using Kuika.Common.Interfaces;
using Kuika.Common.Workflow;
using Kuika.Common.Workflow.Extensions;
using Kuika.Common.Workflow.DTOs;
using Kuika.Common.Models;
using Kuika.Common.Menu.Response;
using Kuika.Common.Entities;
using System.Reflection;
using Newtonsoft.Json.Linq;
using Newtonsoft.Json;
using System.Net.Http;
using Iyzipay.Model.V2.Subscription;
using Kuika.Common.Payments.Iyzico;
using Kuika.Common.Payments.Param;
using Iyzipay;
using Kuika.Common.Searching.DTOs;
using Kuika.Common.Helpers.Sap;
using Kuika.Common.Mcp;
using Kuika.Common.Vision.DTOs;
using Kuika.Common.Audit;
using Kuika.Common.Payments.Mobile;
using Kuika.ThirdPartyApisCollection;

namespace Kuika.Reslen_01.Api
{
    [ApiExplorerSettings(GroupName = "all")]
    [Authorize]
    [ApiController]
    [Route("v1/api/ReportCashNebim")]
    public class ReportCashNebim_Controller : KControllerBase
    {
        private string appName = "wbTimesCRM";
        private Guid appId = Guid.Parse("0e8ecb48-8c52-463c-5db5-08de3ec441b1");
        private static string screenName = "ReportCashNebim";
        private Guid screenId = Guid.Parse("408f71ea-a491-484c-947b-222c2fd7f750");
        private string connectionString { get { return Kuika.Common.KContext.GetConnectionString(); } }

        [HttpGet, Route("myroles")]
        public IActionResult GetMyRoles()
        {
            try
            {
                var result = KProviderManager.Authorization.GetMyRoles(appId, appName, screenId, screenName);
                return Ok(result);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new HttpExceptionDto() { Message = ex.Message, StackTrace = ex.StackTrace });
            }
        }


        [HttpPost, Route("ReportCashNebimPageInit")]
        public IActionResult ReportCashNebimPageInit(ReportCashNebimPageInit_Request request)
        {

            var result = new ReportCashNebimPageInit_Response();


            using var auditConnect_0 = ActionAuditScope.Begin("1dbbfc98-0eda-6eb2-a815-0acb6635f72d", "Connect", applicationName: "wbTimesCRM", screenOrEndpointName: "ReportCashNebim");
            using var actionAuditConnect_0 = ActionAuditHelper.Begin("Connect", null);
            try
            {
                Kuika.ThirdPartyApisCollection.DBConnectCsharp.Connect();
            }
            catch (Exception ex)
            {
                actionAuditConnect_0.SetException(ex);
                throw;
            }
;


            return Ok(result);
        }


        [HttpPost, Route("ReportCashNebimComponent_903085484_onClick1_")]
        public IActionResult ReportCashNebimComponent_903085484_onClick1_(ReportCashNebimComponent_903085484_onClick1__Request request)
        {

            var result = new ReportCashNebimComponent_903085484_onClick1__Response();

            var prms_GetOfficeAndCompany_0 = new List<kSqlParameter>();
            prms_GetOfficeAndCompany_0.Add(new kSqlParameter() { Name = "KUserId", Value = Kuika.Common.KContext.CurrentUser?.Id });
            using var auditGetOfficeAndCompany_0 = ActionAuditScope.Begin("883c7532-69e3-8303-e520-08dda041d5e9", "GetOfficeAndCompany", applicationName: "wbTimesCRM", screenOrEndpointName: "ReportCashNebim");
            result.GetOfficeAndCompany = KPersister.Fetch(KContext.GetConnectionString(), @"SELECT TOP 1
    CompanyCode =
        CASE
            WHEN EXISTS (
                SELECT 1
                FROM dbo.KUserRole kur
                INNER JOIN dbo.KRole r
                    ON r.Id = kur.KRole_Id
                WHERE kur.KUser_Id = u.KuserID
                  AND kur.IsDeleted = 0
                  AND r.IsDeleted = 0
                  AND r.Name = 'TimesUstYonetici'
            )
            THEN '1'
            ELSE ISNULL(sp.CompanyCode, '')
        END,

    CompanyName = ISNULL(sp.CompanyName, ''),

    OfficeCode =
        CASE
            WHEN EXISTS (
                SELECT 1
                FROM dbo.KUserRole kur
                INNER JOIN dbo.KRole r
                    ON r.Id = kur.KRole_Id
                WHERE kur.KUser_Id = u.KuserID
                  AND kur.IsDeleted = 0
                  AND r.IsDeleted = 0
                  AND r.Name = 'TimesUstYonetici'
            )
            THEN 'M'
            ELSE ISNULL(sp.OfficeCode, '')
        END,

    StoreCode = ISNULL(sp.StoreCode, ''),

    StoreName = ISNULL(sp.StoreDescription, ''),

    OfficeName =
        CASE
            WHEN EXISTS (
                SELECT 1
                FROM dbo.KUserRole kur
                INNER JOIN dbo.KRole r
                    ON r.Id = kur.KRole_Id
                WHERE kur.KUser_Id = u.KuserID
                  AND kur.IsDeleted = 0
                  AND r.IsDeleted = 0
                  AND r.Name = 'TimesUstYonetici'
            )
            THEN 'Merkez Ofis'
            ELSE ISNULL(sp.OfficeDescription, '')
        END

FROM tmscrq.TMUser u

INNER JOIN tmscrq.TMSalesPersonInfo sp
    ON sp.SalesPersonCode = u.salesPersonCode

WHERE u.KUserID = @KUserId;", new string[] { "CompanyCode", "CompanyName", "OfficeCode", "StoreCode", "StoreName", "OfficeName" }, prms_GetOfficeAndCompany_0.ToArray());
            ;


            using var auditKuika_KasaRaporuSatisSiparisleri1_1 = ActionAuditScope.Begin("06c17a18-9a9f-ecee-3e94-e6508f9bd13d", "Kuika_KasaRaporuSatisSiparisleri1", applicationName: "wbTimesCRM", screenOrEndpointName: "ReportCashNebim");
            using var actionAuditKuika_KasaRaporuSatisSiparisleri1_1 = ActionAuditHelper.Begin("Kuika_KasaRaporuSatisSiparisleri1", new { Date = request.Date_1.ConvertToType<String>(), CompanyCode = (result.GetOfficeAndCompany.ResultList.FirstOrDefault()?.GetValueByFieldName("CompanyCode")).ConvertToType<Int32>(), OfficeCode = (result.GetOfficeAndCompany.ResultList.FirstOrDefault()?.GetValueByFieldName("OfficeCode")).ConvertToType<String>() });
            try
            {
                result.Kuika_KasaRaporuSatisSiparisleri1 = Kuika.ThirdPartyApisCollection.Reports3.Kuika_KasaRaporuSatisSiparisleri1(request.Date_1.ConvertToType<String>(), (result.GetOfficeAndCompany.ResultList.FirstOrDefault()?.GetValueByFieldName("CompanyCode")).ConvertToType<Int32>(), (result.GetOfficeAndCompany.ResultList.FirstOrDefault()?.GetValueByFieldName("OfficeCode")).ConvertToType<String>());
                actionAuditKuika_KasaRaporuSatisSiparisleri1_1.SetResult(result.Kuika_KasaRaporuSatisSiparisleri1);
            }
            catch (Exception ex)
            {
                actionAuditKuika_KasaRaporuSatisSiparisleri1_1.SetException(ex);
                throw;
            }
;


            using var auditKuika_SatisFaturalari2_2 = ActionAuditScope.Begin("7fd6cf00-b35e-a5b6-3e4f-10e1020858db", "Kuika_SatisFaturalari2", applicationName: "wbTimesCRM", screenOrEndpointName: "ReportCashNebim");
            using var actionAuditKuika_SatisFaturalari2_2 = ActionAuditHelper.Begin("Kuika_SatisFaturalari2", new { OperationDate = request.OperationDate_2.ConvertToType<String>(), CompanyCode = (result.GetOfficeAndCompany.ResultList.FirstOrDefault()?.GetValueByFieldName("CompanyCode")).ConvertToType<Int32>(), OfficeCode = (result.GetOfficeAndCompany.ResultList.FirstOrDefault()?.GetValueByFieldName("OfficeCode")).ConvertToType<String>() });
            try
            {
                result.Kuika_SatisFaturalari2 = Kuika.ThirdPartyApisCollection.Reports3.Kuika_SatisFaturalari2(request.OperationDate_2.ConvertToType<String>(), (result.GetOfficeAndCompany.ResultList.FirstOrDefault()?.GetValueByFieldName("CompanyCode")).ConvertToType<Int32>(), (result.GetOfficeAndCompany.ResultList.FirstOrDefault()?.GetValueByFieldName("OfficeCode")).ConvertToType<String>());
                actionAuditKuika_SatisFaturalari2_2.SetResult(result.Kuika_SatisFaturalari2);
            }
            catch (Exception ex)
            {
                actionAuditKuika_SatisFaturalari2_2.SetException(ex);
                throw;
            }
;


            using var auditKuika_NakitDevirler3_3 = ActionAuditScope.Begin("f2cdd2d7-f584-8184-d369-628be48e8029", "Kuika_NakitDevirler3", applicationName: "wbTimesCRM", screenOrEndpointName: "ReportCashNebim");
            using var actionAuditKuika_NakitDevirler3_3 = ActionAuditHelper.Begin("Kuika_NakitDevirler3", new { OperationDate = request.OperationDate_3.ConvertToType<String>(), CompanyCode = (result.GetOfficeAndCompany.ResultList.FirstOrDefault()?.GetValueByFieldName("CompanyCode")).ConvertToType<Int32>(), OfficeCode = (result.GetOfficeAndCompany.ResultList.FirstOrDefault()?.GetValueByFieldName("OfficeCode")).ConvertToType<String>() });
            try
            {
                result.Kuika_NakitDevirler3 = Kuika.ThirdPartyApisCollection.Reports3.Kuika_NakitDevirler3(request.OperationDate_3.ConvertToType<String>(), (result.GetOfficeAndCompany.ResultList.FirstOrDefault()?.GetValueByFieldName("CompanyCode")).ConvertToType<Int32>(), (result.GetOfficeAndCompany.ResultList.FirstOrDefault()?.GetValueByFieldName("OfficeCode")).ConvertToType<String>());
                actionAuditKuika_NakitDevirler3_3.SetResult(result.Kuika_NakitDevirler3);
            }
            catch (Exception ex)
            {
                actionAuditKuika_NakitDevirler3_3.SetException(ex);
                throw;
            }
;


            using var auditKuika_KrediKartiTahsilatlari4_4 = ActionAuditScope.Begin("60a047e2-cb80-547e-adea-bee633713cd7", "Kuika_KrediKartiTahsilatlari4", applicationName: "wbTimesCRM", screenOrEndpointName: "ReportCashNebim");
            using var actionAuditKuika_KrediKartiTahsilatlari4_4 = ActionAuditHelper.Begin("Kuika_KrediKartiTahsilatlari4", new { OperationDate = request.OperationDate_4.ConvertToType<String>(), CompanyCode = (result.GetOfficeAndCompany.ResultList.FirstOrDefault()?.GetValueByFieldName("CompanyCode")).ConvertToType<Int32>(), OfficeCode = (result.GetOfficeAndCompany.ResultList.FirstOrDefault()?.GetValueByFieldName("OfficeCode")).ConvertToType<String>() });
            try
            {
                result.Kuika_KrediKartiTahsilatlari4 = Kuika.ThirdPartyApisCollection.Reports3.Kuika_KrediKartiTahsilatlari4(request.OperationDate_4.ConvertToType<String>(), (result.GetOfficeAndCompany.ResultList.FirstOrDefault()?.GetValueByFieldName("CompanyCode")).ConvertToType<Int32>(), (result.GetOfficeAndCompany.ResultList.FirstOrDefault()?.GetValueByFieldName("OfficeCode")).ConvertToType<String>());
                actionAuditKuika_KrediKartiTahsilatlari4_4.SetResult(result.Kuika_KrediKartiTahsilatlari4);
            }
            catch (Exception ex)
            {
                actionAuditKuika_KrediKartiTahsilatlari4_4.SetException(ex);
                throw;
            }
;


            using var auditKuika_BankaKontrol5_5 = ActionAuditScope.Begin("b90ba420-8184-c557-5f6b-c2284f946074", "Kuika_BankaKontrol5", applicationName: "wbTimesCRM", screenOrEndpointName: "ReportCashNebim");
            using var actionAuditKuika_BankaKontrol5_5 = ActionAuditHelper.Begin("Kuika_BankaKontrol5", new { OperationDate = request.OperationDate_5.ConvertToType<String>(), CompanyCode = (result.GetOfficeAndCompany.ResultList.FirstOrDefault()?.GetValueByFieldName("CompanyCode")).ConvertToType<Int32>(), OfficeCode = (result.GetOfficeAndCompany.ResultList.FirstOrDefault()?.GetValueByFieldName("OfficeCode")).ConvertToType<String>() });
            try
            {
                result.Kuika_BankaKontrol5 = Kuika.ThirdPartyApisCollection.Reports3.Kuika_BankaKontrol5(request.OperationDate_5.ConvertToType<String>(), (result.GetOfficeAndCompany.ResultList.FirstOrDefault()?.GetValueByFieldName("CompanyCode")).ConvertToType<Int32>(), (result.GetOfficeAndCompany.ResultList.FirstOrDefault()?.GetValueByFieldName("OfficeCode")).ConvertToType<String>());
                actionAuditKuika_BankaKontrol5_5.SetResult(result.Kuika_BankaKontrol5);
            }
            catch (Exception ex)
            {
                actionAuditKuika_BankaKontrol5_5.SetException(ex);
                throw;
            }
;


            using var auditKuika_TedarikciPosCekimleri6_6 = ActionAuditScope.Begin("36309dd7-2992-586d-9e3a-de6fb247782b", "Kuika_TedarikciPosCekimleri6", applicationName: "wbTimesCRM", screenOrEndpointName: "ReportCashNebim");
            using var actionAuditKuika_TedarikciPosCekimleri6_6 = ActionAuditHelper.Begin("Kuika_TedarikciPosCekimleri6", new { OperationDate = request.OperationDate_6.ConvertToType<String>(), CompanyCode = (result.GetOfficeAndCompany.ResultList.FirstOrDefault()?.GetValueByFieldName("CompanyCode")).ConvertToType<Int32>(), OfficeCode = (result.GetOfficeAndCompany.ResultList.FirstOrDefault()?.GetValueByFieldName("OfficeCode")).ConvertToType<String>() });
            try
            {
                result.Kuika_TedarikciPosCekimleri6 = Kuika.ThirdPartyApisCollection.Reports3.Kuika_TedarikciPosCekimleri6(request.OperationDate_6.ConvertToType<String>(), (result.GetOfficeAndCompany.ResultList.FirstOrDefault()?.GetValueByFieldName("CompanyCode")).ConvertToType<Int32>(), (result.GetOfficeAndCompany.ResultList.FirstOrDefault()?.GetValueByFieldName("OfficeCode")).ConvertToType<String>());
                actionAuditKuika_TedarikciPosCekimleri6_6.SetResult(result.Kuika_TedarikciPosCekimleri6);
            }
            catch (Exception ex)
            {
                actionAuditKuika_TedarikciPosCekimleri6_6.SetException(ex);
                throw;
            }
;


            using var auditKuika_Orders7_7 = ActionAuditScope.Begin("ca6b4bbc-8020-a43c-5237-46d853ff0d6f", "Kuika_Orders7", applicationName: "wbTimesCRM", screenOrEndpointName: "ReportCashNebim");
            using var actionAuditKuika_Orders7_7 = ActionAuditHelper.Begin("Kuika_Orders7", new { OperationDate = request.OperationDate_7.ConvertToType<String>(), CompanyCode = (result.GetOfficeAndCompany.ResultList.FirstOrDefault()?.GetValueByFieldName("CompanyCode")).ConvertToType<Int32>(), OfficeCode = (result.GetOfficeAndCompany.ResultList.FirstOrDefault()?.GetValueByFieldName("OfficeCode")).ConvertToType<String>() });
            try
            {
                result.Kuika_Orders7 = Kuika.ThirdPartyApisCollection.Reports3.Kuika_Orders7(request.OperationDate_7.ConvertToType<String>(), (result.GetOfficeAndCompany.ResultList.FirstOrDefault()?.GetValueByFieldName("CompanyCode")).ConvertToType<Int32>(), (result.GetOfficeAndCompany.ResultList.FirstOrDefault()?.GetValueByFieldName("OfficeCode")).ConvertToType<String>());
                actionAuditKuika_Orders7_7.SetResult(result.Kuika_Orders7);
            }
            catch (Exception ex)
            {
                actionAuditKuika_Orders7_7.SetException(ex);
                throw;
            }
;


            using var auditKuika_Masraflar8_8 = ActionAuditScope.Begin("18f2025b-6d86-0ec4-b753-673a176afa7c", "Kuika_Masraflar8", applicationName: "wbTimesCRM", screenOrEndpointName: "ReportCashNebim");
            using var actionAuditKuika_Masraflar8_8 = ActionAuditHelper.Begin("Kuika_Masraflar8", new { OperationDate = request.OperationDate_8.ConvertToType<String>(), CompanyCode = (result.GetOfficeAndCompany.ResultList.FirstOrDefault()?.GetValueByFieldName("CompanyCode")).ConvertToType<Int32>(), OfficeCode = (result.GetOfficeAndCompany.ResultList.FirstOrDefault()?.GetValueByFieldName("OfficeCode")).ConvertToType<String>() });
            try
            {
                result.Kuika_Masraflar8 = Kuika.ThirdPartyApisCollection.Reports3.Kuika_Masraflar8(request.OperationDate_8.ConvertToType<String>(), (result.GetOfficeAndCompany.ResultList.FirstOrDefault()?.GetValueByFieldName("CompanyCode")).ConvertToType<Int32>(), (result.GetOfficeAndCompany.ResultList.FirstOrDefault()?.GetValueByFieldName("OfficeCode")).ConvertToType<String>());
                actionAuditKuika_Masraflar8_8.SetResult(result.Kuika_Masraflar8);
            }
            catch (Exception ex)
            {
                actionAuditKuika_Masraflar8_8.SetException(ex);
                throw;
            }
;


            using var auditKuika_CashDevir9_9 = ActionAuditScope.Begin("0ef52460-6025-9d4f-3ecb-8b9cd106c630", "Kuika_CashDevir9", applicationName: "wbTimesCRM", screenOrEndpointName: "ReportCashNebim");
            using var actionAuditKuika_CashDevir9_9 = ActionAuditHelper.Begin("Kuika_CashDevir9", new { OperationDate = request.OperationDate_9.ConvertToType<String>(), CompanyCode = (result.GetOfficeAndCompany.ResultList.FirstOrDefault()?.GetValueByFieldName("CompanyCode")).ConvertToType<Int32>(), OfficeCode = (result.GetOfficeAndCompany.ResultList.FirstOrDefault()?.GetValueByFieldName("OfficeCode")).ConvertToType<String>() });
            try
            {
                result.Kuika_CashDevir9 = Kuika.ThirdPartyApisCollection.Reports3.Kuika_CashDevir9(request.OperationDate_9.ConvertToType<String>(), (result.GetOfficeAndCompany.ResultList.FirstOrDefault()?.GetValueByFieldName("CompanyCode")).ConvertToType<Int32>(), (result.GetOfficeAndCompany.ResultList.FirstOrDefault()?.GetValueByFieldName("OfficeCode")).ConvertToType<String>());
                actionAuditKuika_CashDevir9_9.SetResult(result.Kuika_CashDevir9);
            }
            catch (Exception ex)
            {
                actionAuditKuika_CashDevir9_9.SetException(ex);
                throw;
            }
;


            using var auditKuika_KasaKalani10_10 = ActionAuditScope.Begin("ef52f1a5-1691-6a67-d93d-5a5cdecaf434", "Kuika_KasaKalani10", applicationName: "wbTimesCRM", screenOrEndpointName: "ReportCashNebim");
            using var actionAuditKuika_KasaKalani10_10 = ActionAuditHelper.Begin("Kuika_KasaKalani10", new { OperationDate = request.OperationDate_10.ConvertToType<String>(), CompanyCode = (result.GetOfficeAndCompany.ResultList.FirstOrDefault()?.GetValueByFieldName("CompanyCode")).ConvertToType<Int32>(), OfficeCode = (result.GetOfficeAndCompany.ResultList.FirstOrDefault()?.GetValueByFieldName("OfficeCode")).ConvertToType<String>() });
            try
            {
                result.Kuika_KasaKalani10 = Kuika.ThirdPartyApisCollection.Reports3.Kuika_KasaKalani10(request.OperationDate_10.ConvertToType<String>(), (result.GetOfficeAndCompany.ResultList.FirstOrDefault()?.GetValueByFieldName("CompanyCode")).ConvertToType<Int32>(), (result.GetOfficeAndCompany.ResultList.FirstOrDefault()?.GetValueByFieldName("OfficeCode")).ConvertToType<String>());
                actionAuditKuika_KasaKalani10_10.SetResult(result.Kuika_KasaKalani10);
            }
            catch (Exception ex)
            {
                actionAuditKuika_KasaKalani10_10.SetException(ex);
                throw;
            }
;


            return Ok(result);
        }


        [HttpPost, Route("ReportCashNebimComponent_2054284029_onClick")]
        public IActionResult ReportCashNebimComponent_2054284029_onClick(ReportCashNebimComponent_2054284029_onClick_Request request)
        {

            var result = new ReportCashNebimComponent_2054284029_onClick_Response();

            var prms_GetOfficeAndCompany_0 = new List<kSqlParameter>();
            prms_GetOfficeAndCompany_0.Add(new kSqlParameter() { Name = "KUserId", Value = Kuika.Common.KContext.CurrentUser?.Id });
            using var auditGetOfficeAndCompany_0 = ActionAuditScope.Begin("e720b613-c615-076a-789a-9b9e3e06f152", "GetOfficeAndCompany", applicationName: "wbTimesCRM", screenOrEndpointName: "ReportCashNebim");
            result.GetOfficeAndCompany = KPersister.Fetch(KContext.GetConnectionString(), @"SELECT TOP 1
    CompanyCode =
        CASE
            WHEN EXISTS (
                SELECT 1
                FROM dbo.KUserRole kur
                INNER JOIN dbo.KRole r
                    ON r.Id = kur.KRole_Id
                WHERE kur.KUser_Id = u.KuserID
                  AND kur.IsDeleted = 0
                  AND r.IsDeleted = 0
                  AND r.Name = 'TimesUstYonetici'
            )
            THEN '1'
            ELSE ISNULL(sp.CompanyCode, '')
        END,

    CompanyName = ISNULL(sp.CompanyName, ''),

    OfficeCode =
        CASE
            WHEN EXISTS (
                SELECT 1
                FROM dbo.KUserRole kur
                INNER JOIN dbo.KRole r
                    ON r.Id = kur.KRole_Id
                WHERE kur.KUser_Id = u.KuserID
                  AND kur.IsDeleted = 0
                  AND r.IsDeleted = 0
                  AND r.Name = 'TimesUstYonetici'
            )
            THEN 'M'
            ELSE ISNULL(sp.OfficeCode, '')
        END,

    StoreCode = ISNULL(sp.StoreCode, ''),

    StoreName = ISNULL(sp.StoreDescription, ''),

    OfficeName =
        CASE
            WHEN EXISTS (
                SELECT 1
                FROM dbo.KUserRole kur
                INNER JOIN dbo.KRole r
                    ON r.Id = kur.KRole_Id
                WHERE kur.KUser_Id = u.KuserID
                  AND kur.IsDeleted = 0
                  AND r.IsDeleted = 0
                  AND r.Name = 'TimesUstYonetici'
            )
            THEN 'Merkez Ofis'
            ELSE ISNULL(sp.OfficeDescription, '')
        END

FROM tmscrq.TMUser u

INNER JOIN tmscrq.TMSalesPersonInfo sp
    ON sp.SalesPersonCode = u.salesPersonCode

WHERE u.KUserID = @KUserId;", new string[] { "CompanyCode", "CompanyName", "OfficeCode", "StoreCode", "StoreName", "OfficeName" }, prms_GetOfficeAndCompany_0.ToArray());
            ;

            var pageName = "acb83dad-177b-4bcc-a400-fda7b31a1305".ConvertToType<String>();
            var screenParameter1 = new Dictionary<string, string>();
            screenParameter1.Add("Date", request.Date_1.ConvertToType<String>().ToString());
            screenParameter1.Add("CompanyCode", (result.GetOfficeAndCompany.ResultList.FirstOrDefault()?.GetValueByFieldName("CompanyCode")).ConvertToType<Int32?>().ToString());
            screenParameter1.Add("OfficeCode", (result.GetOfficeAndCompany.ResultList.FirstOrDefault()?.GetValueByFieldName("OfficeCode")).ConvertToType<String>().ToString());
            var report = new Kuika.Reslen_01.Api.KasaRaporuDokumForm_reportgenerator();
            //MethodInfo method = t.GetMethod("CreatePDF");
            //var methodReturn = method.Invoke(null, null);
            result.PrintReport = report.RenderPDF(screenParameter1); //
            ;


            return Ok(result);
        }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class ReportCashNebimPageInit_Request
    {
    }
}

namespace Kuika.Reslen_01.Api
{
    public class ReportCashNebimPageInit_Response
    {
    }
}

namespace Kuika.Reslen_01.Api
{
    public class ReportCashNebimComponent_903085484_onClick1__Request
    {
        public Guid? KUserId_0 { set; get; }
        public String? Date_1 { set; get; }
        public Int32? CompanyCode_1 { set; get; }
        public String? OfficeCode_1 { set; get; }
        public String? OperationDate_2 { set; get; }
        public Int32? CompanyCode_2 { set; get; }
        public String? OfficeCode_2 { set; get; }
        public String? OperationDate_3 { set; get; }
        public Int32? CompanyCode_3 { set; get; }
        public String? OfficeCode_3 { set; get; }
        public String? OperationDate_4 { set; get; }
        public Int32? CompanyCode_4 { set; get; }
        public String? OfficeCode_4 { set; get; }
        public String? OperationDate_5 { set; get; }
        public Int32? CompanyCode_5 { set; get; }
        public String? OfficeCode_5 { set; get; }
        public String? OperationDate_6 { set; get; }
        public Int32? CompanyCode_6 { set; get; }
        public String? OfficeCode_6 { set; get; }
        public String? OperationDate_7 { set; get; }
        public Int32? CompanyCode_7 { set; get; }
        public String? OfficeCode_7 { set; get; }
        public String? OperationDate_8 { set; get; }
        public Int32? CompanyCode_8 { set; get; }
        public String? OfficeCode_8 { set; get; }
        public String? OperationDate_9 { set; get; }
        public Int32? CompanyCode_9 { set; get; }
        public String? OfficeCode_9 { set; get; }
        public String? OperationDate_10 { set; get; }
        public Int32? CompanyCode_10 { set; get; }
        public String? OfficeCode_10 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class ReportCashNebimComponent_903085484_onClick1__Response
    {
        public KCommonEntityPage GetOfficeAndCompany { set; get; }

        public System.Collections.Generic.IList<Kuika.ThirdPartyApisCollection.Kuika_KasaRaporuSatisSiparisleri1Class> Kuika_KasaRaporuSatisSiparisleri1 { set; get; }

        public System.Collections.Generic.IList<Kuika.ThirdPartyApisCollection.Kuika_SatisFaturalari2Class> Kuika_SatisFaturalari2 { set; get; }

        public System.Collections.Generic.IList<Kuika.ThirdPartyApisCollection.Kuika_NakitDevirler3Class> Kuika_NakitDevirler3 { set; get; }

        public System.Collections.Generic.IList<Kuika.ThirdPartyApisCollection.Kuika_KrediKartiTahsilatlari4Class> Kuika_KrediKartiTahsilatlari4 { set; get; }

        public System.Collections.Generic.IList<Kuika.ThirdPartyApisCollection.Kuika_BankaKontrol5Class> Kuika_BankaKontrol5 { set; get; }

        public System.Collections.Generic.IList<Kuika.ThirdPartyApisCollection.Kuika_TedarikciPosCekimleri6Class> Kuika_TedarikciPosCekimleri6 { set; get; }

        public System.Collections.Generic.IList<Kuika.ThirdPartyApisCollection.Kuika_Orders7Class> Kuika_Orders7 { set; get; }

        public System.Collections.Generic.IList<Kuika.ThirdPartyApisCollection.Kuika_Masraflar8Class> Kuika_Masraflar8 { set; get; }

        public System.Collections.Generic.IList<Kuika.ThirdPartyApisCollection.Kuika_CashDevir9Class> Kuika_CashDevir9 { set; get; }

        public System.Collections.Generic.IList<Kuika.ThirdPartyApisCollection.Kuika_KasaKalani10Class> Kuika_KasaKalani10 { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class ReportCashNebimComponent_2054284029_onClick_Request
    {
        public Guid? KUserId_0 { set; get; }
        public String reportName_1 { set; get; }
        public String Date_1 { set; get; }
        public Int32? CompanyCode_1 { set; get; }
        public String OfficeCode_1 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class ReportCashNebimComponent_2054284029_onClick_Response
    {
        public KCommonEntityPage GetOfficeAndCompany { set; get; }

        public String PrintReport { set; get; }

    }
}
