
using Kuika.Common;
using Kuika.Common.Attributes;
using Kuika.Common.Bases;
using Kuika.Common.Enums;
using Kuika.Common.Accessors;
using Kuika.Common.Json;
using Kuika.Common.Classes;
using Kuika.Common.Exceptions;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Kuika.Common.Helpers;
using Kuika.Common.Settings;
using System.Collections.Generic;
using System;
using Kuika.Common.Extensions;
using System.Linq;
using Kuika.Common.Rest;
using WorkflowCore.Interface;
using Kuika.Common.Interfaces;
using Kuika.Common.Workflow;
using Kuika.Common.Workflow.Extensions;
using Kuika.Common.Workflow.DTOs;
using Kuika.Common.Models;
using Kuika.Common.Menu.Response;
using Kuika.Common.Entities;
using System.Reflection;
using Newtonsoft.Json.Linq;
using Newtonsoft.Json;
using System.Net.Http;
using Iyzipay.Model.V2.Subscription;
using Kuika.Common.Payments.Iyzico;
using Kuika.Common.Payments.Param;
using Iyzipay;
using Kuika.Common.Searching.DTOs;
using Kuika.Common.Helpers.Sap;
using Kuika.Common.Mcp;
using Kuika.Common.Vision.DTOs;
using Kuika.Common.Audit;
using Kuika.Common.Payments.Mobile;
using Kuika.ThirdPartyApisCollection;

namespace Kuika.Reslen_01.Api
{
    [ApiExplorerSettings(GroupName = "all")]
    [Authorize]
    [ApiController]
    [Route("v1/api/StockListStoreBase")]
    public class StockListStoreBase_Controller : KControllerBase
    {
        private string appName = "wbTimesCRM";
        private Guid appId = Guid.Parse("0e8ecb48-8c52-463c-5db5-08de3ec441b1");
        private static string screenName = "StockListStoreBase";
        private Guid screenId = Guid.Parse("efb4604a-6bf9-46e9-a0c9-a8c8518d3400");
        private string connectionString { get { return Kuika.Common.KContext.GetConnectionString(); } }

        [HttpGet, Route("myroles")]
        public IActionResult GetMyRoles()
        {
            try
            {
                var result = KProviderManager.Authorization.GetMyRoles(appId, appName, screenId, screenName);
                return Ok(result);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new HttpExceptionDto() { Message = ex.Message, StackTrace = ex.StackTrace });
            }
        }


        [HttpPost, Route("StockListStoreBasePageInit")]
        public IActionResult StockListStoreBasePageInit(StockListStoreBasePageInit_Request request)
        {

            var result = new StockListStoreBasePageInit_Response();

            var prms_TM_GetUserStoreCode_0 = new List<kSqlParameter>();
            prms_TM_GetUserStoreCode_0.Add(new kSqlParameter() { Name = "KUserId", Value = Kuika.Common.KContext.CurrentUser?.Id });
            using var auditTM_GetUserStoreCode_0 = ActionAuditScope.Begin("73156849-6177-181f-8376-e26775f4b660", "TM_GetUserStoreCode", applicationName: "wbTimesCRM", screenOrEndpointName: "StockListStoreBase");
            result.TM_GetUserStoreCode = KPersister.Fetch(KContext.GetConnectionString(), @"SELECT 
    st.Id AS StoreId,          
    st.StoreCode,
    st.StoreDesc AS StoreName
FROM tmscrq.TMUser tu
INNER JOIN tmscrq.TMStore st 
    ON st.Id = tu.StoreID
WHERE 
    tu.KUserID = @KUserId;", new string[] { "StoreId", "StoreCode", "StoreName" }, prms_TM_GetUserStoreCode_0.ToArray());
            ;

            var prms_TM_GetStoreDashboardSummary_1 = new List<kSqlParameter>();
            prms_TM_GetStoreDashboardSummary_1.Add(new kSqlParameter() { Name = "StoreCode", Value = result.TM_GetUserStoreCode.ResultList.FirstOrDefault()?.GetValueByFieldName("StoreCode") });
            prms_TM_GetStoreDashboardSummary_1.Add(new kSqlParameter() { Name = "UrunTipi", Value = (null as object) });
            prms_TM_GetStoreDashboardSummary_1.Add(new kSqlParameter() { Name = "Brand", Value = (null as object) });
            prms_TM_GetStoreDashboardSummary_1.Add(new kSqlParameter() { Name = "CategoryName", Value = (null as object) });
            prms_TM_GetStoreDashboardSummary_1.Add(new kSqlParameter() { Name = "ProductName", Value = (null as object) });
            prms_TM_GetStoreDashboardSummary_1.Add(new kSqlParameter() { Name = "Referance", Value = (null as object) });
            prms_TM_GetStoreDashboardSummary_1.Add(new kSqlParameter() { Name = "Dial", Value = (null as object) });
            prms_TM_GetStoreDashboardSummary_1.Add(new kSqlParameter() { Name = "Bracelet", Value = (null as object) });
            using var auditTM_GetStoreDashboardSummary_1 = ActionAuditScope.Begin("ca4890d0-137b-c444-74fb-f602c4005823", "TM_GetStoreDashboardSummary", applicationName: "wbTimesCRM", screenOrEndpointName: "StockListStoreBase");
            result.TM_GetStoreDashboardSummary = KPersister.Fetch(KContext.GetConnectionString(), @"DECLARE @StoreId UNIQUEIDENTIFIER;

SELECT @StoreId = Id 
FROM tmscrq.TMStore 
WHERE StoreCode = @StoreCode;

WITH ProductCategory AS (
    SELECT 
        i.storeCode,
        i.productCode,

        MAX(NULLIF(LTRIM(RTRIM(i.productAtt17Desc)), '')) AS CategoryName,

        SUM(ISNULL(i.InventoryQty1, 0)) AS Stok

    FROM tmscrq.TMItemInventory i

    -- 🔥 ARTIK TMProduct
    INNER JOIN tmscrq.TMProduct p 
        ON i.productCode = p.ProductCode

    WHERE 
        i.officeDescription IS NOT NULL
        AND i.officeDescription NOT IN ('Teknik Servis Ofis')
        AND i.storeCode = @StoreCode

        -- 🔥 ÜRÜN TİPİ
        AND (
            @UrunTipi IS NULL 
            OR @UrunTipi = '' 
            OR UPPER(LTRIM(RTRIM(i.ProductAtt02Desc))) = UPPER(LTRIM(RTRIM(@UrunTipi)))
        )

        -- 🔥 FİLTRELER
        AND (@Brand IS NULL OR @Brand = '' OR p.Brand = @Brand)
        AND (@CategoryName IS NULL OR @CategoryName = '' OR p.CategoryName = @CategoryName)
        AND (@ProductName IS NULL OR @ProductName = '' OR p.ProductName = @ProductName)
        AND (@Referance IS NULL OR @Referance = '' OR p.Referance = @Referance)
        AND (@Dial IS NULL OR @Dial = '' OR p.Dial = @Dial)
        AND (@Bracelet IS NULL OR @Bracelet = '' OR p.Bracelet = @Bracelet)

    GROUP BY 
        i.storeCode,
        i.productCode

    HAVING 
        SUM(ISNULL(i.InventoryQty1, 0)) > 0
),

-- 🔥 YENİ REZERVE SAYIMI
ReservedByStore AS (
    SELECT 
        COALESCE(l.StoreId, tu.StoreId) AS StoreId,
        COUNT(DISTINCT r.LeadId) AS ReservedCount
    FROM tmscrq.TMLeadReservation r

    INNER JOIN tmscrq.TMLead l 
        ON l.Id = r.LeadId

    INNER JOIN tmscrq.TMLeadProcess lp 
        ON lp.Id = l.ProcessID

    LEFT JOIN tmscrq.TMUser tu 
        ON tu.KUserID = l.CreatedBy

    WHERE 
        r.IsActive = 1
        --AND r.DeliveryDueDate > SYSDATETIMEOFFSET()  -- 🔥 DÜZELTİLDİ
        AND lp.Code = 'DELIVERY_PENDING'
        AND COALESCE(l.StoreId, tu.StoreId) = @StoreId

    GROUP BY 
        COALESCE(l.StoreId, tu.StoreId)
)

SELECT
    COUNT(*) AS ToplamUrunSayisi,

    COUNT(CASE WHEN CategoryName = 'Kategori 1' THEN 1 END) AS Kategori1,
    COUNT(CASE WHEN CategoryName = 'Kategori 2' THEN 1 END) AS Kategori2,
    COUNT(CASE WHEN CategoryName = 'Kategori 3' THEN 1 END) AS Kategori3,

    COUNT(CASE WHEN CategoryName IS NULL THEN 1 END) AS Kategorisiz,

    ISNULL((SELECT ReservedCount FROM ReservedByStore), 0) AS RezerveUrunSayisi

FROM ProductCategory;", new string[] { "ToplamUrunSayisi", "Kategori1", "Kategori2", "Kategori3", "Kategorisiz", "RezerveUrunSayisi" }, prms_TM_GetStoreDashboardSummary_1.ToArray());
            ;

            var prms_TM_GetInventoryByUserStore_2 = new List<kSqlParameter>();
            prms_TM_GetInventoryByUserStore_2.Add(new kSqlParameter() { Name = "StoreCode", Value = result.TM_GetUserStoreCode.ResultList.FirstOrDefault()?.GetValueByFieldName("StoreCode") });
            prms_TM_GetInventoryByUserStore_2.Add(new kSqlParameter() { Name = "UrunTipi", Value = (null as object) });
            prms_TM_GetInventoryByUserStore_2.Add(new kSqlParameter() { Name = "Brand", Value = (null as object) });
            prms_TM_GetInventoryByUserStore_2.Add(new kSqlParameter() { Name = "CategoryName", Value = (null as object) });
            prms_TM_GetInventoryByUserStore_2.Add(new kSqlParameter() { Name = "ProductName", Value = (null as object) });
            prms_TM_GetInventoryByUserStore_2.Add(new kSqlParameter() { Name = "Referance", Value = (null as object) });
            prms_TM_GetInventoryByUserStore_2.Add(new kSqlParameter() { Name = "Dial", Value = (null as object) });
            prms_TM_GetInventoryByUserStore_2.Add(new kSqlParameter() { Name = "Bracelet", Value = (null as object) });
            prms_TM_GetInventoryByUserStore_2.Add(new kSqlParameter() { Name = "Durum", Value = (null as object) });
            using var auditTM_GetInventoryByUserStore_2 = ActionAuditScope.Begin("0dd78305-2afb-753b-de65-adc8fa8ffb9c", "TM_GetInventoryByUserStore", applicationName: "wbTimesCRM", screenOrEndpointName: "StockListStoreBase");
            result.TM_GetInventoryByUserStore = KPersister.Fetch(KContext.GetConnectionString(), @"
--------------------------------------------------
-- 🔥 ANA SORGU
--------------------------------------------------
SELECT 
    i.officeDescription AS Ofis,
    i.storeCode,

    p.ProductCode,
    p.Brand,
    p.CategoryName,
    p.ProductName,
    p.Referance,
    p.Dial,
    p.Bracelet,

    --------------------------------------------------
    -- 🔥 STOK
    --------------------------------------------------
    SUM(ISNULL(i.InventoryQty1, 0)) AS ToplamStok,

    ISNULL(r.ReservedCount, 0) AS RezerveStok,

    SUM(ISNULL(i.InventoryQty1, 0)) - ISNULL(r.ReservedCount, 0) AS MusaitStok

FROM tmscrq.TMItemInventory i

INNER JOIN tmscrq.TMProduct p 
    ON i.productCode = p.ProductCode

--------------------------------------------------
-- 🔥 REZERVE
--------------------------------------------------
LEFT JOIN (
    SELECT 
        l.ProductId,
        COALESCE(l.StoreId, tu.StoreId) AS StoreId,
        COUNT(DISTINCT r.LeadId) AS ReservedCount
    FROM tmscrq.TMLeadReservation r

    INNER JOIN tmscrq.TMLead l 
        ON l.Id = r.LeadId

    INNER JOIN tmscrq.TMLeadProcess lp 
        ON lp.Id = l.ProcessID

    LEFT JOIN tmscrq.TMUser tu 
        ON tu.KUserID = l.CreatedBy

    WHERE 
        r.IsActive = 1
        AND lp.Code = 'DELIVERY_PENDING'

    GROUP BY 
        l.ProductId,
        COALESCE(l.StoreId, tu.StoreId)
) r 
    ON r.ProductId = p.Id
    AND r.StoreId = (
        SELECT Id 
        FROM tmscrq.TMStore 
        WHERE StoreCode = @StoreCode
    )

--------------------------------------------------
-- 🔥 FİLTRELER
--------------------------------------------------
WHERE 
    i.storeCode = @StoreCode
    AND i.officeDescription IS NOT NULL
    AND i.officeDescription NOT IN ('Teknik Servis Ofis')

    -- 🔥 ÜRÜN TİPİ
    AND (
        @UrunTipi IS NULL 
        OR @UrunTipi = '' 
        OR UPPER(LTRIM(RTRIM(i.ProductAtt02Desc))) = UPPER(LTRIM(RTRIM(@UrunTipi)))
    )

    -- 🔥 DİĞER FİLTRELER
    AND (@Brand IS NULL OR @Brand = '' OR p.Brand = @Brand)
    AND (@CategoryName IS NULL OR @CategoryName = '' OR p.CategoryName = @CategoryName)
    AND (@ProductName IS NULL OR @ProductName = '' OR p.ProductName = @ProductName)
    AND (@Referance IS NULL OR @Referance = '' OR p.Referance = @Referance)
    AND (@Dial IS NULL OR @Dial = '' OR p.Dial = @Dial)
    AND (@Bracelet IS NULL OR @Bracelet = '' OR p.Bracelet = @Bracelet)

--------------------------------------------------
-- 🔥 GROUP
--------------------------------------------------
GROUP BY 
    i.officeDescription,
    i.storeCode,
    p.ProductCode,
    p.Brand,
    p.CategoryName,
    p.ProductName,
    p.Referance,
    p.Dial,
    p.Bracelet,
    r.ReservedCount

--------------------------------------------------
-- 🔥 HAVING
--------------------------------------------------
HAVING 
    SUM(ISNULL(i.InventoryQty1, 0)) > 0

    AND (
        @Durum IS NULL

        -- 🔴 Rezerve olanlar
        OR (@Durum = 1 AND ISNULL(r.ReservedCount, 0) > 0)

        -- 🟢 Müsait olanlar
        OR (@Durum = 0 AND (SUM(ISNULL(i.InventoryQty1, 0)) - ISNULL(r.ReservedCount, 0)) > 0)
    )

--------------------------------------------------
-- 🔥 ORDER
--------------------------------------------------
ORDER BY 
    CASE 
        WHEN p.Brand = 'Rolex' THEN 1 
        WHEN p.Brand = 'Tudor' THEN 2 
        ELSE 3 
    END,
    ToplamStok ASC,
    p.ProductName;", new string[] { "Ofis", "storeCode", "ProductCode", "Brand", "CategoryName", "ProductName", "Referance", "Dial", "Bracelet", "ToplamStok", "RezerveStok", "MusaitStok" }, prms_TM_GetInventoryByUserStore_2.ToArray());
            ;

            var prms_TM_GetStockBrands_3 = new List<kSqlParameter>();
            prms_TM_GetStockBrands_3.Add(new kSqlParameter() { Name = "StoreCode", Value = result.TM_GetUserStoreCode.ResultList.FirstOrDefault()?.GetValueByFieldName("StoreCode") });
            using var auditTM_GetStockBrands_3 = ActionAuditScope.Begin("7d075565-f103-b26c-3da5-3e10dcf50def", "TM_GetStockBrands", applicationName: "wbTimesCRM", screenOrEndpointName: "StockListStoreBase");
            result.TM_GetStockBrands = KPersister.Fetch(KContext.GetConnectionString(), @"SELECT 
    p.Brand
FROM tmscrq.TMItemInventory i
INNER JOIN tmscrq.TMProductExcel p 
    ON i.productCode = p.ProductCode
WHERE 
    i.officeDescription IS NOT NULL
    AND i.officeDescription NOT IN ( 'Teknik Servis Ofis')
    AND ISNULL(i.InventoryQty1, 0) > 0
    AND i.storeCode = @StoreCode
GROUP BY 
    p.Brand
ORDER BY 
    CASE 
        WHEN p.Brand = 'Rolex' THEN 1
        WHEN p.Brand = 'Tudor' THEN 2
        ELSE 3
    END,
    p.Brand;", new string[] { "Brand" }, prms_TM_GetStockBrands_3.ToArray());
            ;

            var prms_TM_GetProductNamesByStore_4 = new List<kSqlParameter>();
            prms_TM_GetProductNamesByStore_4.Add(new kSqlParameter() { Name = "StoreCode", Value = result.TM_GetUserStoreCode.ResultList.FirstOrDefault()?.GetValueByFieldName("StoreCode") });
            using var auditTM_GetProductNamesByStore_4 = ActionAuditScope.Begin("67709ab5-05e9-0610-53e8-0be515d2e983", "TM_GetProductNamesByStore", applicationName: "wbTimesCRM", screenOrEndpointName: "StockListStoreBase");
            result.TM_GetProductNamesByStore = KPersister.Fetch(KContext.GetConnectionString(), @"SELECT DISTINCT
    p.ProductName
FROM tmscrq.TMItemInventory i
INNER JOIN tmscrq.TMProductExcel p 
    ON i.productCode = p.ProductCode
WHERE 
    ISNULL(i.InventoryQty1, 0) > 0
    AND i.storeCode = @StoreCode
ORDER BY 
    p.ProductName;", new string[] { "ProductName" }, prms_TM_GetProductNamesByStore_4.ToArray());
            ;

            var prms_TM_GetCategoriesByStore_5 = new List<kSqlParameter>();
            prms_TM_GetCategoriesByStore_5.Add(new kSqlParameter() { Name = "StoreCode", Value = result.TM_GetUserStoreCode.ResultList.FirstOrDefault()?.GetValueByFieldName("StoreCode") });
            using var auditTM_GetCategoriesByStore_5 = ActionAuditScope.Begin("a249df20-97ca-22a9-bc11-c088c33d0011", "TM_GetCategoriesByStore", applicationName: "wbTimesCRM", screenOrEndpointName: "StockListStoreBase");
            result.TM_GetCategoriesByStore = KPersister.Fetch(KContext.GetConnectionString(), @"SELECT DISTINCT
    p.CategoryName
FROM tmscrq.TMItemInventory i
INNER JOIN tmscrq.TMProduct p 
    ON i.productCode = p.ProductCode
WHERE 
    ISNULL(i.InventoryQty1, 0) > 0
    AND i.storeCode = @StoreCode
ORDER BY 
    p.CategoryName;", new string[] { "CategoryName" }, prms_TM_GetCategoriesByStore_5.ToArray());
            ;

            var prms_TM_GetReferencesByStore_6 = new List<kSqlParameter>();
            prms_TM_GetReferencesByStore_6.Add(new kSqlParameter() { Name = "StoreCode", Value = result.TM_GetUserStoreCode.ResultList.FirstOrDefault()?.GetValueByFieldName("StoreCode") });
            using var auditTM_GetReferencesByStore_6 = ActionAuditScope.Begin("7b197759-b6c8-82a4-d239-56bd88c25890", "TM_GetReferencesByStore", applicationName: "wbTimesCRM", screenOrEndpointName: "StockListStoreBase");
            result.TM_GetReferencesByStore = KPersister.Fetch(KContext.GetConnectionString(), @"SELECT DISTINCT
    p.Referance
FROM tmscrq.TMItemInventory i
INNER JOIN tmscrq.TMProductExcel p 
    ON i.productCode = p.ProductCode
WHERE 
    ISNULL(i.InventoryQty1, 0) > 0
    AND i.storeCode = @StoreCode
ORDER BY 
    p.Referance;", new string[] { "Referance" }, prms_TM_GetReferencesByStore_6.ToArray());
            ;

            var prms_TM_GetDialsByStore_7 = new List<kSqlParameter>();
            prms_TM_GetDialsByStore_7.Add(new kSqlParameter() { Name = "StoreCode", Value = result.TM_GetUserStoreCode.ResultList.FirstOrDefault()?.GetValueByFieldName("StoreCode") });
            using var auditTM_GetDialsByStore_7 = ActionAuditScope.Begin("09bbbb7e-0c06-5785-c39a-6532e3ea7fb3", "TM_GetDialsByStore", applicationName: "wbTimesCRM", screenOrEndpointName: "StockListStoreBase");
            result.TM_GetDialsByStore = KPersister.Fetch(KContext.GetConnectionString(), @"SELECT DISTINCT
    p.Dial
FROM tmscrq.TMItemInventory i
INNER JOIN tmscrq.TMProductExcel p 
    ON i.productCode = p.ProductCode
WHERE 
    ISNULL(i.InventoryQty1, 0) > 0
    AND i.storeCode = @StoreCode
    AND p.Dial IS NOT NULL
    AND p.Dial <> ''
ORDER BY 
    p.Dial;", new string[] { "Dial" }, prms_TM_GetDialsByStore_7.ToArray());
            ;

            var prms_TM_GetBraceletsByStore_8 = new List<kSqlParameter>();
            prms_TM_GetBraceletsByStore_8.Add(new kSqlParameter() { Name = "StoreCode", Value = result.TM_GetUserStoreCode.ResultList.FirstOrDefault()?.GetValueByFieldName("StoreCode") });
            using var auditTM_GetBraceletsByStore_8 = ActionAuditScope.Begin("2eafbac4-f748-0e5e-7c51-48ce3a17b5a1", "TM_GetBraceletsByStore", applicationName: "wbTimesCRM", screenOrEndpointName: "StockListStoreBase");
            result.TM_GetBraceletsByStore = KPersister.Fetch(KContext.GetConnectionString(), @"SELECT DISTINCT
    p.Bracelet
FROM tmscrq.TMItemInventory i
INNER JOIN tmscrq.TMProductExcel p 
    ON i.productCode = p.ProductCode
WHERE 
    ISNULL(i.InventoryQty1, 0) > 0
    AND i.storeCode = @StoreCode
    AND p.Bracelet IS NOT NULL
    AND p.Bracelet <> ''
ORDER BY 
    p.Bracelet;", new string[] { "Bracelet" }, prms_TM_GetBraceletsByStore_8.ToArray());
            ;

            var prms_TM_GetItemType_9 = new List<kSqlParameter>();
            prms_TM_GetItemType_9.Add(new kSqlParameter() { Name = "StoreCode", Value = result.TM_GetUserStoreCode.ResultList.FirstOrDefault()?.GetValueByFieldName("StoreCode") });
            using var auditTM_GetItemType_9 = ActionAuditScope.Begin("52dd436d-bf32-545b-7d9d-3829151b7814", "TM_GetItemType", applicationName: "wbTimesCRM", screenOrEndpointName: "StockListStoreBase");
            result.TM_GetItemType = KPersister.Fetch(KContext.GetConnectionString(), @"-- SELECT DISTINCT
--     i.ProductAtt02Desc AS UrunTipi
-- FROM tmscrq.TMItemInventory i

-- WHERE 
--     i.StoreCode = @StoreCode
--     AND i.InventoryQty1 > 0
--     AND i.ProductAtt02Desc IS NOT NULL
--     AND LTRIM(RTRIM(i.ProductAtt02Desc)) <> ''

-- ORDER BY 
--     i.ProductAtt02Desc;


SELECT DISTINCT
    i.ProductAtt02Desc AS UrunTipi,
    CASE 
        WHEN i.ProductAtt02Desc = 'Kol Saati' THEN 0
        ELSE 1
    END AS OrderPriority

FROM tmscrq.TMItemInventory i

WHERE 
    i.StoreCode = @StoreCode
    AND i.InventoryQty1 > 0
    AND i.ProductAtt02Desc IS NOT NULL
    AND LTRIM(RTRIM(i.ProductAtt02Desc)) <> ''

ORDER BY 
    OrderPriority,
    i.ProductAtt02Desc;", new string[] { "UrunTipi", "OrderPriority" }, prms_TM_GetItemType_9.ToArray());
            ;


            return Ok(result);
        }


        [HttpPost, Route("StockListStoreBaseComponent_356162_onChange")]
        public IActionResult StockListStoreBaseComponent_356162_onChange(StockListStoreBaseComponent_356162_onChange_Request request)
        {

            var result = new StockListStoreBaseComponent_356162_onChange_Response();

            var prms_TM_GetInventoryByUserStore_0 = new List<kSqlParameter>();
            prms_TM_GetInventoryByUserStore_0.Add(new kSqlParameter() { Name = "StoreCode", Value = request.StoreCode_0 });
            prms_TM_GetInventoryByUserStore_0.Add(new kSqlParameter() { Name = "UrunTipi", Value = request.UrunTipi_0 });
            prms_TM_GetInventoryByUserStore_0.Add(new kSqlParameter() { Name = "Brand", Value = request.Brand_0 });
            prms_TM_GetInventoryByUserStore_0.Add(new kSqlParameter() { Name = "CategoryName", Value = request.CategoryName_0 });
            prms_TM_GetInventoryByUserStore_0.Add(new kSqlParameter() { Name = "ProductName", Value = request.ProductName_0 });
            prms_TM_GetInventoryByUserStore_0.Add(new kSqlParameter() { Name = "Referance", Value = request.Referance_0 });
            prms_TM_GetInventoryByUserStore_0.Add(new kSqlParameter() { Name = "Dial", Value = request.Dial_0 });
            prms_TM_GetInventoryByUserStore_0.Add(new kSqlParameter() { Name = "Bracelet", Value = request.Bracelet_0 });
            prms_TM_GetInventoryByUserStore_0.Add(new kSqlParameter() { Name = "Durum", Value = request.Durum_0 });
            using var auditTM_GetInventoryByUserStore_0 = ActionAuditScope.Begin("e979ef86-ecd7-06dc-7e76-eb81d02af402", "TM_GetInventoryByUserStore", applicationName: "wbTimesCRM", screenOrEndpointName: "StockListStoreBase");
            result.TM_GetInventoryByUserStore = KPersister.Fetch(KContext.GetConnectionString(), @"
--------------------------------------------------
-- 🔥 ANA SORGU
--------------------------------------------------
SELECT 
    i.officeDescription AS Ofis,
    i.storeCode,

    p.ProductCode,
    p.Brand,
    p.CategoryName,
    p.ProductName,
    p.Referance,
    p.Dial,
    p.Bracelet,

    --------------------------------------------------
    -- 🔥 STOK
    --------------------------------------------------
    SUM(ISNULL(i.InventoryQty1, 0)) AS ToplamStok,

    ISNULL(r.ReservedCount, 0) AS RezerveStok,

    SUM(ISNULL(i.InventoryQty1, 0)) - ISNULL(r.ReservedCount, 0) AS MusaitStok

FROM tmscrq.TMItemInventory i

INNER JOIN tmscrq.TMProduct p 
    ON i.productCode = p.ProductCode

--------------------------------------------------
-- 🔥 REZERVE
--------------------------------------------------
LEFT JOIN (
    SELECT 
        l.ProductId,
        COALESCE(l.StoreId, tu.StoreId) AS StoreId,
        COUNT(DISTINCT r.LeadId) AS ReservedCount
    FROM tmscrq.TMLeadReservation r

    INNER JOIN tmscrq.TMLead l 
        ON l.Id = r.LeadId

    INNER JOIN tmscrq.TMLeadProcess lp 
        ON lp.Id = l.ProcessID

    LEFT JOIN tmscrq.TMUser tu 
        ON tu.KUserID = l.CreatedBy

    WHERE 
        r.IsActive = 1
        AND lp.Code = 'DELIVERY_PENDING'

    GROUP BY 
        l.ProductId,
        COALESCE(l.StoreId, tu.StoreId)
) r 
    ON r.ProductId = p.Id
    AND r.StoreId = (
        SELECT Id 
        FROM tmscrq.TMStore 
        WHERE StoreCode = @StoreCode
    )

--------------------------------------------------
-- 🔥 FİLTRELER
--------------------------------------------------
WHERE 
    i.storeCode = @StoreCode
    AND i.officeDescription IS NOT NULL
    AND i.officeDescription NOT IN ('Teknik Servis Ofis')

    -- 🔥 ÜRÜN TİPİ
    AND (
        @UrunTipi IS NULL 
        OR @UrunTipi = '' 
        OR UPPER(LTRIM(RTRIM(i.ProductAtt02Desc))) = UPPER(LTRIM(RTRIM(@UrunTipi)))
    )

    -- 🔥 DİĞER FİLTRELER
    AND (@Brand IS NULL OR @Brand = '' OR p.Brand = @Brand)
    AND (@CategoryName IS NULL OR @CategoryName = '' OR p.CategoryName = @CategoryName)
    AND (@ProductName IS NULL OR @ProductName = '' OR p.ProductName = @ProductName)
    AND (@Referance IS NULL OR @Referance = '' OR p.Referance = @Referance)
    AND (@Dial IS NULL OR @Dial = '' OR p.Dial = @Dial)
    AND (@Bracelet IS NULL OR @Bracelet = '' OR p.Bracelet = @Bracelet)

--------------------------------------------------
-- 🔥 GROUP
--------------------------------------------------
GROUP BY 
    i.officeDescription,
    i.storeCode,
    p.ProductCode,
    p.Brand,
    p.CategoryName,
    p.ProductName,
    p.Referance,
    p.Dial,
    p.Bracelet,
    r.ReservedCount

--------------------------------------------------
-- 🔥 HAVING
--------------------------------------------------
HAVING 
    SUM(ISNULL(i.InventoryQty1, 0)) > 0

    AND (
        @Durum IS NULL

        -- 🔴 Rezerve olanlar
        OR (@Durum = 1 AND ISNULL(r.ReservedCount, 0) > 0)

        -- 🟢 Müsait olanlar
        OR (@Durum = 0 AND (SUM(ISNULL(i.InventoryQty1, 0)) - ISNULL(r.ReservedCount, 0)) > 0)
    )

--------------------------------------------------
-- 🔥 ORDER
--------------------------------------------------
ORDER BY 
    CASE 
        WHEN p.Brand = 'Rolex' THEN 1 
        WHEN p.Brand = 'Tudor' THEN 2 
        ELSE 3 
    END,
    ToplamStok ASC,
    p.ProductName;", new string[] { "Ofis", "storeCode", "ProductCode", "Brand", "CategoryName", "ProductName", "Referance", "Dial", "Bracelet", "ToplamStok", "RezerveStok", "MusaitStok" }, prms_TM_GetInventoryByUserStore_0.ToArray());
            ;


            return Ok(result);
        }


        [HttpPost, Route("StockListStoreBaseComponent_190692_onChange")]
        public IActionResult StockListStoreBaseComponent_190692_onChange(StockListStoreBaseComponent_190692_onChange_Request request)
        {

            var result = new StockListStoreBaseComponent_190692_onChange_Response();

            var prms_TM_GetInventoryByUserStore_0 = new List<kSqlParameter>();
            prms_TM_GetInventoryByUserStore_0.Add(new kSqlParameter() { Name = "StoreCode", Value = request.StoreCode_0 });
            prms_TM_GetInventoryByUserStore_0.Add(new kSqlParameter() { Name = "UrunTipi", Value = request.UrunTipi_0 });
            prms_TM_GetInventoryByUserStore_0.Add(new kSqlParameter() { Name = "Brand", Value = request.Brand_0 });
            prms_TM_GetInventoryByUserStore_0.Add(new kSqlParameter() { Name = "CategoryName", Value = request.CategoryName_0 });
            prms_TM_GetInventoryByUserStore_0.Add(new kSqlParameter() { Name = "ProductName", Value = request.ProductName_0 });
            prms_TM_GetInventoryByUserStore_0.Add(new kSqlParameter() { Name = "Referance", Value = request.Referance_0 });
            prms_TM_GetInventoryByUserStore_0.Add(new kSqlParameter() { Name = "Dial", Value = request.Dial_0 });
            prms_TM_GetInventoryByUserStore_0.Add(new kSqlParameter() { Name = "Bracelet", Value = request.Bracelet_0 });
            prms_TM_GetInventoryByUserStore_0.Add(new kSqlParameter() { Name = "Durum", Value = request.Durum_0 });
            using var auditTM_GetInventoryByUserStore_0 = ActionAuditScope.Begin("626c6c01-c96c-531f-2f8a-459b15c88bca", "TM_GetInventoryByUserStore", applicationName: "wbTimesCRM", screenOrEndpointName: "StockListStoreBase");
            result.TM_GetInventoryByUserStore = KPersister.Fetch(KContext.GetConnectionString(), @"
--------------------------------------------------
-- 🔥 ANA SORGU
--------------------------------------------------
SELECT 
    i.officeDescription AS Ofis,
    i.storeCode,

    p.ProductCode,
    p.Brand,
    p.CategoryName,
    p.ProductName,
    p.Referance,
    p.Dial,
    p.Bracelet,

    --------------------------------------------------
    -- 🔥 STOK
    --------------------------------------------------
    SUM(ISNULL(i.InventoryQty1, 0)) AS ToplamStok,

    ISNULL(r.ReservedCount, 0) AS RezerveStok,

    SUM(ISNULL(i.InventoryQty1, 0)) - ISNULL(r.ReservedCount, 0) AS MusaitStok

FROM tmscrq.TMItemInventory i

INNER JOIN tmscrq.TMProduct p 
    ON i.productCode = p.ProductCode

--------------------------------------------------
-- 🔥 REZERVE
--------------------------------------------------
LEFT JOIN (
    SELECT 
        l.ProductId,
        COALESCE(l.StoreId, tu.StoreId) AS StoreId,
        COUNT(DISTINCT r.LeadId) AS ReservedCount
    FROM tmscrq.TMLeadReservation r

    INNER JOIN tmscrq.TMLead l 
        ON l.Id = r.LeadId

    INNER JOIN tmscrq.TMLeadProcess lp 
        ON lp.Id = l.ProcessID

    LEFT JOIN tmscrq.TMUser tu 
        ON tu.KUserID = l.CreatedBy

    WHERE 
        r.IsActive = 1
        AND lp.Code = 'DELIVERY_PENDING'

    GROUP BY 
        l.ProductId,
        COALESCE(l.StoreId, tu.StoreId)
) r 
    ON r.ProductId = p.Id
    AND r.StoreId = (
        SELECT Id 
        FROM tmscrq.TMStore 
        WHERE StoreCode = @StoreCode
    )

--------------------------------------------------
-- 🔥 FİLTRELER
--------------------------------------------------
WHERE 
    i.storeCode = @StoreCode
    AND i.officeDescription IS NOT NULL
    AND i.officeDescription NOT IN ('Teknik Servis Ofis')

    -- 🔥 ÜRÜN TİPİ
    AND (
        @UrunTipi IS NULL 
        OR @UrunTipi = '' 
        OR UPPER(LTRIM(RTRIM(i.ProductAtt02Desc))) = UPPER(LTRIM(RTRIM(@UrunTipi)))
    )

    -- 🔥 DİĞER FİLTRELER
    AND (@Brand IS NULL OR @Brand = '' OR p.Brand = @Brand)
    AND (@CategoryName IS NULL OR @CategoryName = '' OR p.CategoryName = @CategoryName)
    AND (@ProductName IS NULL OR @ProductName = '' OR p.ProductName = @ProductName)
    AND (@Referance IS NULL OR @Referance = '' OR p.Referance = @Referance)
    AND (@Dial IS NULL OR @Dial = '' OR p.Dial = @Dial)
    AND (@Bracelet IS NULL OR @Bracelet = '' OR p.Bracelet = @Bracelet)

--------------------------------------------------
-- 🔥 GROUP
--------------------------------------------------
GROUP BY 
    i.officeDescription,
    i.storeCode,
    p.ProductCode,
    p.Brand,
    p.CategoryName,
    p.ProductName,
    p.Referance,
    p.Dial,
    p.Bracelet,
    r.ReservedCount

--------------------------------------------------
-- 🔥 HAVING
--------------------------------------------------
HAVING 
    SUM(ISNULL(i.InventoryQty1, 0)) > 0

    AND (
        @Durum IS NULL

        -- 🔴 Rezerve olanlar
        OR (@Durum = 1 AND ISNULL(r.ReservedCount, 0) > 0)

        -- 🟢 Müsait olanlar
        OR (@Durum = 0 AND (SUM(ISNULL(i.InventoryQty1, 0)) - ISNULL(r.ReservedCount, 0)) > 0)
    )

--------------------------------------------------
-- 🔥 ORDER
--------------------------------------------------
ORDER BY 
    CASE 
        WHEN p.Brand = 'Rolex' THEN 1 
        WHEN p.Brand = 'Tudor' THEN 2 
        ELSE 3 
    END,
    ToplamStok ASC,
    p.ProductName;", new string[] { "Ofis", "storeCode", "ProductCode", "Brand", "CategoryName", "ProductName", "Referance", "Dial", "Bracelet", "ToplamStok", "RezerveStok", "MusaitStok" }, prms_TM_GetInventoryByUserStore_0.ToArray());
            ;


            return Ok(result);
        }


        [HttpPost, Route("StockListStoreBaseComponent_560082_onChange")]
        public IActionResult StockListStoreBaseComponent_560082_onChange(StockListStoreBaseComponent_560082_onChange_Request request)
        {

            var result = new StockListStoreBaseComponent_560082_onChange_Response();

            var prms_TM_GetInventoryByUserStore_0 = new List<kSqlParameter>();
            prms_TM_GetInventoryByUserStore_0.Add(new kSqlParameter() { Name = "StoreCode", Value = request.StoreCode_0 });
            prms_TM_GetInventoryByUserStore_0.Add(new kSqlParameter() { Name = "UrunTipi", Value = request.UrunTipi_0 });
            prms_TM_GetInventoryByUserStore_0.Add(new kSqlParameter() { Name = "Brand", Value = request.Brand_0 });
            prms_TM_GetInventoryByUserStore_0.Add(new kSqlParameter() { Name = "CategoryName", Value = request.CategoryName_0 });
            prms_TM_GetInventoryByUserStore_0.Add(new kSqlParameter() { Name = "ProductName", Value = request.ProductName_0 });
            prms_TM_GetInventoryByUserStore_0.Add(new kSqlParameter() { Name = "Referance", Value = request.Referance_0 });
            prms_TM_GetInventoryByUserStore_0.Add(new kSqlParameter() { Name = "Dial", Value = request.Dial_0 });
            prms_TM_GetInventoryByUserStore_0.Add(new kSqlParameter() { Name = "Bracelet", Value = request.Bracelet_0 });
            prms_TM_GetInventoryByUserStore_0.Add(new kSqlParameter() { Name = "Durum", Value = request.Durum_0 });
            using var auditTM_GetInventoryByUserStore_0 = ActionAuditScope.Begin("4b602f04-3192-bc11-5c21-87e51bcb1b57", "TM_GetInventoryByUserStore", applicationName: "wbTimesCRM", screenOrEndpointName: "StockListStoreBase");
            result.TM_GetInventoryByUserStore = KPersister.Fetch(KContext.GetConnectionString(), @"
--------------------------------------------------
-- 🔥 ANA SORGU
--------------------------------------------------
SELECT 
    i.officeDescription AS Ofis,
    i.storeCode,

    p.ProductCode,
    p.Brand,
    p.CategoryName,
    p.ProductName,
    p.Referance,
    p.Dial,
    p.Bracelet,

    --------------------------------------------------
    -- 🔥 STOK
    --------------------------------------------------
    SUM(ISNULL(i.InventoryQty1, 0)) AS ToplamStok,

    ISNULL(r.ReservedCount, 0) AS RezerveStok,

    SUM(ISNULL(i.InventoryQty1, 0)) - ISNULL(r.ReservedCount, 0) AS MusaitStok

FROM tmscrq.TMItemInventory i

INNER JOIN tmscrq.TMProduct p 
    ON i.productCode = p.ProductCode

--------------------------------------------------
-- 🔥 REZERVE
--------------------------------------------------
LEFT JOIN (
    SELECT 
        l.ProductId,
        COALESCE(l.StoreId, tu.StoreId) AS StoreId,
        COUNT(DISTINCT r.LeadId) AS ReservedCount
    FROM tmscrq.TMLeadReservation r

    INNER JOIN tmscrq.TMLead l 
        ON l.Id = r.LeadId

    INNER JOIN tmscrq.TMLeadProcess lp 
        ON lp.Id = l.ProcessID

    LEFT JOIN tmscrq.TMUser tu 
        ON tu.KUserID = l.CreatedBy

    WHERE 
        r.IsActive = 1
        AND lp.Code = 'DELIVERY_PENDING'

    GROUP BY 
        l.ProductId,
        COALESCE(l.StoreId, tu.StoreId)
) r 
    ON r.ProductId = p.Id
    AND r.StoreId = (
        SELECT Id 
        FROM tmscrq.TMStore 
        WHERE StoreCode = @StoreCode
    )

--------------------------------------------------
-- 🔥 FİLTRELER
--------------------------------------------------
WHERE 
    i.storeCode = @StoreCode
    AND i.officeDescription IS NOT NULL
    AND i.officeDescription NOT IN ('Teknik Servis Ofis')

    -- 🔥 ÜRÜN TİPİ
    AND (
        @UrunTipi IS NULL 
        OR @UrunTipi = '' 
        OR UPPER(LTRIM(RTRIM(i.ProductAtt02Desc))) = UPPER(LTRIM(RTRIM(@UrunTipi)))
    )

    -- 🔥 DİĞER FİLTRELER
    AND (@Brand IS NULL OR @Brand = '' OR p.Brand = @Brand)
    AND (@CategoryName IS NULL OR @CategoryName = '' OR p.CategoryName = @CategoryName)
    AND (@ProductName IS NULL OR @ProductName = '' OR p.ProductName = @ProductName)
    AND (@Referance IS NULL OR @Referance = '' OR p.Referance = @Referance)
    AND (@Dial IS NULL OR @Dial = '' OR p.Dial = @Dial)
    AND (@Bracelet IS NULL OR @Bracelet = '' OR p.Bracelet = @Bracelet)

--------------------------------------------------
-- 🔥 GROUP
--------------------------------------------------
GROUP BY 
    i.officeDescription,
    i.storeCode,
    p.ProductCode,
    p.Brand,
    p.CategoryName,
    p.ProductName,
    p.Referance,
    p.Dial,
    p.Bracelet,
    r.ReservedCount

--------------------------------------------------
-- 🔥 HAVING
--------------------------------------------------
HAVING 
    SUM(ISNULL(i.InventoryQty1, 0)) > 0

    AND (
        @Durum IS NULL

        -- 🔴 Rezerve olanlar
        OR (@Durum = 1 AND ISNULL(r.ReservedCount, 0) > 0)

        -- 🟢 Müsait olanlar
        OR (@Durum = 0 AND (SUM(ISNULL(i.InventoryQty1, 0)) - ISNULL(r.ReservedCount, 0)) > 0)
    )

--------------------------------------------------
-- 🔥 ORDER
--------------------------------------------------
ORDER BY 
    CASE 
        WHEN p.Brand = 'Rolex' THEN 1 
        WHEN p.Brand = 'Tudor' THEN 2 
        ELSE 3 
    END,
    ToplamStok ASC,
    p.ProductName;", new string[] { "Ofis", "storeCode", "ProductCode", "Brand", "CategoryName", "ProductName", "Referance", "Dial", "Bracelet", "ToplamStok", "RezerveStok", "MusaitStok" }, prms_TM_GetInventoryByUserStore_0.ToArray());
            ;


            return Ok(result);
        }


        [HttpPost, Route("StockListStoreBaseComponent_944323_onChange")]
        public IActionResult StockListStoreBaseComponent_944323_onChange(StockListStoreBaseComponent_944323_onChange_Request request)
        {

            var result = new StockListStoreBaseComponent_944323_onChange_Response();

            var prms_TM_GetInventoryByUserStore_0 = new List<kSqlParameter>();
            prms_TM_GetInventoryByUserStore_0.Add(new kSqlParameter() { Name = "StoreCode", Value = request.StoreCode_0 });
            prms_TM_GetInventoryByUserStore_0.Add(new kSqlParameter() { Name = "UrunTipi", Value = request.UrunTipi_0 });
            prms_TM_GetInventoryByUserStore_0.Add(new kSqlParameter() { Name = "Brand", Value = request.Brand_0 });
            prms_TM_GetInventoryByUserStore_0.Add(new kSqlParameter() { Name = "CategoryName", Value = request.CategoryName_0 });
            prms_TM_GetInventoryByUserStore_0.Add(new kSqlParameter() { Name = "ProductName", Value = request.ProductName_0 });
            prms_TM_GetInventoryByUserStore_0.Add(new kSqlParameter() { Name = "Referance", Value = request.Referance_0 });
            prms_TM_GetInventoryByUserStore_0.Add(new kSqlParameter() { Name = "Dial", Value = request.Dial_0 });
            prms_TM_GetInventoryByUserStore_0.Add(new kSqlParameter() { Name = "Bracelet", Value = request.Bracelet_0 });
            prms_TM_GetInventoryByUserStore_0.Add(new kSqlParameter() { Name = "Durum", Value = request.Durum_0 });
            using var auditTM_GetInventoryByUserStore_0 = ActionAuditScope.Begin("927ee7b3-f6b7-1c23-3f7c-e785ae668084", "TM_GetInventoryByUserStore", applicationName: "wbTimesCRM", screenOrEndpointName: "StockListStoreBase");
            result.TM_GetInventoryByUserStore = KPersister.Fetch(KContext.GetConnectionString(), @"
--------------------------------------------------
-- 🔥 ANA SORGU
--------------------------------------------------
SELECT 
    i.officeDescription AS Ofis,
    i.storeCode,

    p.ProductCode,
    p.Brand,
    p.CategoryName,
    p.ProductName,
    p.Referance,
    p.Dial,
    p.Bracelet,

    --------------------------------------------------
    -- 🔥 STOK
    --------------------------------------------------
    SUM(ISNULL(i.InventoryQty1, 0)) AS ToplamStok,

    ISNULL(r.ReservedCount, 0) AS RezerveStok,

    SUM(ISNULL(i.InventoryQty1, 0)) - ISNULL(r.ReservedCount, 0) AS MusaitStok

FROM tmscrq.TMItemInventory i

INNER JOIN tmscrq.TMProduct p 
    ON i.productCode = p.ProductCode

--------------------------------------------------
-- 🔥 REZERVE
--------------------------------------------------
LEFT JOIN (
    SELECT 
        l.ProductId,
        COALESCE(l.StoreId, tu.StoreId) AS StoreId,
        COUNT(DISTINCT r.LeadId) AS ReservedCount
    FROM tmscrq.TMLeadReservation r

    INNER JOIN tmscrq.TMLead l 
        ON l.Id = r.LeadId

    INNER JOIN tmscrq.TMLeadProcess lp 
        ON lp.Id = l.ProcessID

    LEFT JOIN tmscrq.TMUser tu 
        ON tu.KUserID = l.CreatedBy

    WHERE 
        r.IsActive = 1
        AND lp.Code = 'DELIVERY_PENDING'

    GROUP BY 
        l.ProductId,
        COALESCE(l.StoreId, tu.StoreId)
) r 
    ON r.ProductId = p.Id
    AND r.StoreId = (
        SELECT Id 
        FROM tmscrq.TMStore 
        WHERE StoreCode = @StoreCode
    )

--------------------------------------------------
-- 🔥 FİLTRELER
--------------------------------------------------
WHERE 
    i.storeCode = @StoreCode
    AND i.officeDescription IS NOT NULL
    AND i.officeDescription NOT IN ('Teknik Servis Ofis')

    -- 🔥 ÜRÜN TİPİ
    AND (
        @UrunTipi IS NULL 
        OR @UrunTipi = '' 
        OR UPPER(LTRIM(RTRIM(i.ProductAtt02Desc))) = UPPER(LTRIM(RTRIM(@UrunTipi)))
    )

    -- 🔥 DİĞER FİLTRELER
    AND (@Brand IS NULL OR @Brand = '' OR p.Brand = @Brand)
    AND (@CategoryName IS NULL OR @CategoryName = '' OR p.CategoryName = @CategoryName)
    AND (@ProductName IS NULL OR @ProductName = '' OR p.ProductName = @ProductName)
    AND (@Referance IS NULL OR @Referance = '' OR p.Referance = @Referance)
    AND (@Dial IS NULL OR @Dial = '' OR p.Dial = @Dial)
    AND (@Bracelet IS NULL OR @Bracelet = '' OR p.Bracelet = @Bracelet)

--------------------------------------------------
-- 🔥 GROUP
--------------------------------------------------
GROUP BY 
    i.officeDescription,
    i.storeCode,
    p.ProductCode,
    p.Brand,
    p.CategoryName,
    p.ProductName,
    p.Referance,
    p.Dial,
    p.Bracelet,
    r.ReservedCount

--------------------------------------------------
-- 🔥 HAVING
--------------------------------------------------
HAVING 
    SUM(ISNULL(i.InventoryQty1, 0)) > 0

    AND (
        @Durum IS NULL

        -- 🔴 Rezerve olanlar
        OR (@Durum = 1 AND ISNULL(r.ReservedCount, 0) > 0)

        -- 🟢 Müsait olanlar
        OR (@Durum = 0 AND (SUM(ISNULL(i.InventoryQty1, 0)) - ISNULL(r.ReservedCount, 0)) > 0)
    )

--------------------------------------------------
-- 🔥 ORDER
--------------------------------------------------
ORDER BY 
    CASE 
        WHEN p.Brand = 'Rolex' THEN 1 
        WHEN p.Brand = 'Tudor' THEN 2 
        ELSE 3 
    END,
    ToplamStok ASC,
    p.ProductName;", new string[] { "Ofis", "storeCode", "ProductCode", "Brand", "CategoryName", "ProductName", "Referance", "Dial", "Bracelet", "ToplamStok", "RezerveStok", "MusaitStok" }, prms_TM_GetInventoryByUserStore_0.ToArray());
            ;


            return Ok(result);
        }


        [HttpPost, Route("StockListStoreBaseComponent_944471_onChange")]
        public IActionResult StockListStoreBaseComponent_944471_onChange(StockListStoreBaseComponent_944471_onChange_Request request)
        {

            var result = new StockListStoreBaseComponent_944471_onChange_Response();

            var prms_TM_GetInventoryByUserStore_0 = new List<kSqlParameter>();
            prms_TM_GetInventoryByUserStore_0.Add(new kSqlParameter() { Name = "StoreCode", Value = request.StoreCode_0 });
            prms_TM_GetInventoryByUserStore_0.Add(new kSqlParameter() { Name = "UrunTipi", Value = request.UrunTipi_0 });
            prms_TM_GetInventoryByUserStore_0.Add(new kSqlParameter() { Name = "Brand", Value = request.Brand_0 });
            prms_TM_GetInventoryByUserStore_0.Add(new kSqlParameter() { Name = "CategoryName", Value = request.CategoryName_0 });
            prms_TM_GetInventoryByUserStore_0.Add(new kSqlParameter() { Name = "ProductName", Value = request.ProductName_0 });
            prms_TM_GetInventoryByUserStore_0.Add(new kSqlParameter() { Name = "Referance", Value = request.Referance_0 });
            prms_TM_GetInventoryByUserStore_0.Add(new kSqlParameter() { Name = "Dial", Value = request.Dial_0 });
            prms_TM_GetInventoryByUserStore_0.Add(new kSqlParameter() { Name = "Bracelet", Value = request.Bracelet_0 });
            prms_TM_GetInventoryByUserStore_0.Add(new kSqlParameter() { Name = "Durum", Value = request.Durum_0 });
            using var auditTM_GetInventoryByUserStore_0 = ActionAuditScope.Begin("99cf8a05-fb71-ca35-0366-e9756cd89e86", "TM_GetInventoryByUserStore", applicationName: "wbTimesCRM", screenOrEndpointName: "StockListStoreBase");
            result.TM_GetInventoryByUserStore = KPersister.Fetch(KContext.GetConnectionString(), @"
--------------------------------------------------
-- 🔥 ANA SORGU
--------------------------------------------------
SELECT 
    i.officeDescription AS Ofis,
    i.storeCode,

    p.ProductCode,
    p.Brand,
    p.CategoryName,
    p.ProductName,
    p.Referance,
    p.Dial,
    p.Bracelet,

    --------------------------------------------------
    -- 🔥 STOK
    --------------------------------------------------
    SUM(ISNULL(i.InventoryQty1, 0)) AS ToplamStok,

    ISNULL(r.ReservedCount, 0) AS RezerveStok,

    SUM(ISNULL(i.InventoryQty1, 0)) - ISNULL(r.ReservedCount, 0) AS MusaitStok

FROM tmscrq.TMItemInventory i

INNER JOIN tmscrq.TMProduct p 
    ON i.productCode = p.ProductCode

--------------------------------------------------
-- 🔥 REZERVE
--------------------------------------------------
LEFT JOIN (
    SELECT 
        l.ProductId,
        COALESCE(l.StoreId, tu.StoreId) AS StoreId,
        COUNT(DISTINCT r.LeadId) AS ReservedCount
    FROM tmscrq.TMLeadReservation r

    INNER JOIN tmscrq.TMLead l 
        ON l.Id = r.LeadId

    INNER JOIN tmscrq.TMLeadProcess lp 
        ON lp.Id = l.ProcessID

    LEFT JOIN tmscrq.TMUser tu 
        ON tu.KUserID = l.CreatedBy

    WHERE 
        r.IsActive = 1
        AND lp.Code = 'DELIVERY_PENDING'

    GROUP BY 
        l.ProductId,
        COALESCE(l.StoreId, tu.StoreId)
) r 
    ON r.ProductId = p.Id
    AND r.StoreId = (
        SELECT Id 
        FROM tmscrq.TMStore 
        WHERE StoreCode = @StoreCode
    )

--------------------------------------------------
-- 🔥 FİLTRELER
--------------------------------------------------
WHERE 
    i.storeCode = @StoreCode
    AND i.officeDescription IS NOT NULL
    AND i.officeDescription NOT IN ('Teknik Servis Ofis')

    -- 🔥 ÜRÜN TİPİ
    AND (
        @UrunTipi IS NULL 
        OR @UrunTipi = '' 
        OR UPPER(LTRIM(RTRIM(i.ProductAtt02Desc))) = UPPER(LTRIM(RTRIM(@UrunTipi)))
    )

    -- 🔥 DİĞER FİLTRELER
    AND (@Brand IS NULL OR @Brand = '' OR p.Brand = @Brand)
    AND (@CategoryName IS NULL OR @CategoryName = '' OR p.CategoryName = @CategoryName)
    AND (@ProductName IS NULL OR @ProductName = '' OR p.ProductName = @ProductName)
    AND (@Referance IS NULL OR @Referance = '' OR p.Referance = @Referance)
    AND (@Dial IS NULL OR @Dial = '' OR p.Dial = @Dial)
    AND (@Bracelet IS NULL OR @Bracelet = '' OR p.Bracelet = @Bracelet)

--------------------------------------------------
-- 🔥 GROUP
--------------------------------------------------
GROUP BY 
    i.officeDescription,
    i.storeCode,
    p.ProductCode,
    p.Brand,
    p.CategoryName,
    p.ProductName,
    p.Referance,
    p.Dial,
    p.Bracelet,
    r.ReservedCount

--------------------------------------------------
-- 🔥 HAVING
--------------------------------------------------
HAVING 
    SUM(ISNULL(i.InventoryQty1, 0)) > 0

    AND (
        @Durum IS NULL

        -- 🔴 Rezerve olanlar
        OR (@Durum = 1 AND ISNULL(r.ReservedCount, 0) > 0)

        -- 🟢 Müsait olanlar
        OR (@Durum = 0 AND (SUM(ISNULL(i.InventoryQty1, 0)) - ISNULL(r.ReservedCount, 0)) > 0)
    )

--------------------------------------------------
-- 🔥 ORDER
--------------------------------------------------
ORDER BY 
    CASE 
        WHEN p.Brand = 'Rolex' THEN 1 
        WHEN p.Brand = 'Tudor' THEN 2 
        ELSE 3 
    END,
    ToplamStok ASC,
    p.ProductName;", new string[] { "Ofis", "storeCode", "ProductCode", "Brand", "CategoryName", "ProductName", "Referance", "Dial", "Bracelet", "ToplamStok", "RezerveStok", "MusaitStok" }, prms_TM_GetInventoryByUserStore_0.ToArray());
            ;


            return Ok(result);
        }


        [HttpPost, Route("StockListStoreBaseComponent_651590_onChange")]
        public IActionResult StockListStoreBaseComponent_651590_onChange(StockListStoreBaseComponent_651590_onChange_Request request)
        {

            var result = new StockListStoreBaseComponent_651590_onChange_Response();

            var prms_TM_GetInventoryByUserStore_0 = new List<kSqlParameter>();
            prms_TM_GetInventoryByUserStore_0.Add(new kSqlParameter() { Name = "StoreCode", Value = request.StoreCode_0 });
            prms_TM_GetInventoryByUserStore_0.Add(new kSqlParameter() { Name = "UrunTipi", Value = request.UrunTipi_0 });
            prms_TM_GetInventoryByUserStore_0.Add(new kSqlParameter() { Name = "Brand", Value = request.Brand_0 });
            prms_TM_GetInventoryByUserStore_0.Add(new kSqlParameter() { Name = "CategoryName", Value = request.CategoryName_0 });
            prms_TM_GetInventoryByUserStore_0.Add(new kSqlParameter() { Name = "ProductName", Value = request.ProductName_0 });
            prms_TM_GetInventoryByUserStore_0.Add(new kSqlParameter() { Name = "Referance", Value = request.Referance_0 });
            prms_TM_GetInventoryByUserStore_0.Add(new kSqlParameter() { Name = "Dial", Value = request.Dial_0 });
            prms_TM_GetInventoryByUserStore_0.Add(new kSqlParameter() { Name = "Bracelet", Value = request.Bracelet_0 });
            prms_TM_GetInventoryByUserStore_0.Add(new kSqlParameter() { Name = "Durum", Value = request.Durum_0 });
            using var auditTM_GetInventoryByUserStore_0 = ActionAuditScope.Begin("1cde4538-1186-3c16-901b-a92fbfe9d240", "TM_GetInventoryByUserStore", applicationName: "wbTimesCRM", screenOrEndpointName: "StockListStoreBase");
            result.TM_GetInventoryByUserStore = KPersister.Fetch(KContext.GetConnectionString(), @"
--------------------------------------------------
-- 🔥 ANA SORGU
--------------------------------------------------
SELECT 
    i.officeDescription AS Ofis,
    i.storeCode,

    p.ProductCode,
    p.Brand,
    p.CategoryName,
    p.ProductName,
    p.Referance,
    p.Dial,
    p.Bracelet,

    --------------------------------------------------
    -- 🔥 STOK
    --------------------------------------------------
    SUM(ISNULL(i.InventoryQty1, 0)) AS ToplamStok,

    ISNULL(r.ReservedCount, 0) AS RezerveStok,

    SUM(ISNULL(i.InventoryQty1, 0)) - ISNULL(r.ReservedCount, 0) AS MusaitStok

FROM tmscrq.TMItemInventory i

INNER JOIN tmscrq.TMProduct p 
    ON i.productCode = p.ProductCode

--------------------------------------------------
-- 🔥 REZERVE
--------------------------------------------------
LEFT JOIN (
    SELECT 
        l.ProductId,
        COALESCE(l.StoreId, tu.StoreId) AS StoreId,
        COUNT(DISTINCT r.LeadId) AS ReservedCount
    FROM tmscrq.TMLeadReservation r

    INNER JOIN tmscrq.TMLead l 
        ON l.Id = r.LeadId

    INNER JOIN tmscrq.TMLeadProcess lp 
        ON lp.Id = l.ProcessID

    LEFT JOIN tmscrq.TMUser tu 
        ON tu.KUserID = l.CreatedBy

    WHERE 
        r.IsActive = 1
        AND lp.Code = 'DELIVERY_PENDING'

    GROUP BY 
        l.ProductId,
        COALESCE(l.StoreId, tu.StoreId)
) r 
    ON r.ProductId = p.Id
    AND r.StoreId = (
        SELECT Id 
        FROM tmscrq.TMStore 
        WHERE StoreCode = @StoreCode
    )

--------------------------------------------------
-- 🔥 FİLTRELER
--------------------------------------------------
WHERE 
    i.storeCode = @StoreCode
    AND i.officeDescription IS NOT NULL
    AND i.officeDescription NOT IN ('Teknik Servis Ofis')

    -- 🔥 ÜRÜN TİPİ
    AND (
        @UrunTipi IS NULL 
        OR @UrunTipi = '' 
        OR UPPER(LTRIM(RTRIM(i.ProductAtt02Desc))) = UPPER(LTRIM(RTRIM(@UrunTipi)))
    )

    -- 🔥 DİĞER FİLTRELER
    AND (@Brand IS NULL OR @Brand = '' OR p.Brand = @Brand)
    AND (@CategoryName IS NULL OR @CategoryName = '' OR p.CategoryName = @CategoryName)
    AND (@ProductName IS NULL OR @ProductName = '' OR p.ProductName = @ProductName)
    AND (@Referance IS NULL OR @Referance = '' OR p.Referance = @Referance)
    AND (@Dial IS NULL OR @Dial = '' OR p.Dial = @Dial)
    AND (@Bracelet IS NULL OR @Bracelet = '' OR p.Bracelet = @Bracelet)

--------------------------------------------------
-- 🔥 GROUP
--------------------------------------------------
GROUP BY 
    i.officeDescription,
    i.storeCode,
    p.ProductCode,
    p.Brand,
    p.CategoryName,
    p.ProductName,
    p.Referance,
    p.Dial,
    p.Bracelet,
    r.ReservedCount

--------------------------------------------------
-- 🔥 HAVING
--------------------------------------------------
HAVING 
    SUM(ISNULL(i.InventoryQty1, 0)) > 0

    AND (
        @Durum IS NULL

        -- 🔴 Rezerve olanlar
        OR (@Durum = 1 AND ISNULL(r.ReservedCount, 0) > 0)

        -- 🟢 Müsait olanlar
        OR (@Durum = 0 AND (SUM(ISNULL(i.InventoryQty1, 0)) - ISNULL(r.ReservedCount, 0)) > 0)
    )

--------------------------------------------------
-- 🔥 ORDER
--------------------------------------------------
ORDER BY 
    CASE 
        WHEN p.Brand = 'Rolex' THEN 1 
        WHEN p.Brand = 'Tudor' THEN 2 
        ELSE 3 
    END,
    ToplamStok ASC,
    p.ProductName;", new string[] { "Ofis", "storeCode", "ProductCode", "Brand", "CategoryName", "ProductName", "Referance", "Dial", "Bracelet", "ToplamStok", "RezerveStok", "MusaitStok" }, prms_TM_GetInventoryByUserStore_0.ToArray());
            ;


            return Ok(result);
        }


        [HttpPost, Route("StockListStoreBaseComponent_831544_onChange")]
        public IActionResult StockListStoreBaseComponent_831544_onChange(StockListStoreBaseComponent_831544_onChange_Request request)
        {

            var result = new StockListStoreBaseComponent_831544_onChange_Response();

            var prms_TM_GetInventoryByUserStore_0 = new List<kSqlParameter>();
            prms_TM_GetInventoryByUserStore_0.Add(new kSqlParameter() { Name = "StoreCode", Value = request.StoreCode_0 });
            prms_TM_GetInventoryByUserStore_0.Add(new kSqlParameter() { Name = "UrunTipi", Value = request.UrunTipi_0 });
            prms_TM_GetInventoryByUserStore_0.Add(new kSqlParameter() { Name = "Brand", Value = request.Brand_0 });
            prms_TM_GetInventoryByUserStore_0.Add(new kSqlParameter() { Name = "CategoryName", Value = request.CategoryName_0 });
            prms_TM_GetInventoryByUserStore_0.Add(new kSqlParameter() { Name = "ProductName", Value = request.ProductName_0 });
            prms_TM_GetInventoryByUserStore_0.Add(new kSqlParameter() { Name = "Referance", Value = request.Referance_0 });
            prms_TM_GetInventoryByUserStore_0.Add(new kSqlParameter() { Name = "Dial", Value = request.Dial_0 });
            prms_TM_GetInventoryByUserStore_0.Add(new kSqlParameter() { Name = "Bracelet", Value = request.Bracelet_0 });
            prms_TM_GetInventoryByUserStore_0.Add(new kSqlParameter() { Name = "Durum", Value = request.Durum_0 });
            using var auditTM_GetInventoryByUserStore_0 = ActionAuditScope.Begin("748d102a-ba40-4fe8-1f6f-236c2c97e557", "TM_GetInventoryByUserStore", applicationName: "wbTimesCRM", screenOrEndpointName: "StockListStoreBase");
            result.TM_GetInventoryByUserStore = KPersister.Fetch(KContext.GetConnectionString(), @"
--------------------------------------------------
-- 🔥 ANA SORGU
--------------------------------------------------
SELECT 
    i.officeDescription AS Ofis,
    i.storeCode,

    p.ProductCode,
    p.Brand,
    p.CategoryName,
    p.ProductName,
    p.Referance,
    p.Dial,
    p.Bracelet,

    --------------------------------------------------
    -- 🔥 STOK
    --------------------------------------------------
    SUM(ISNULL(i.InventoryQty1, 0)) AS ToplamStok,

    ISNULL(r.ReservedCount, 0) AS RezerveStok,

    SUM(ISNULL(i.InventoryQty1, 0)) - ISNULL(r.ReservedCount, 0) AS MusaitStok

FROM tmscrq.TMItemInventory i

INNER JOIN tmscrq.TMProduct p 
    ON i.productCode = p.ProductCode

--------------------------------------------------
-- 🔥 REZERVE
--------------------------------------------------
LEFT JOIN (
    SELECT 
        l.ProductId,
        COALESCE(l.StoreId, tu.StoreId) AS StoreId,
        COUNT(DISTINCT r.LeadId) AS ReservedCount
    FROM tmscrq.TMLeadReservation r

    INNER JOIN tmscrq.TMLead l 
        ON l.Id = r.LeadId

    INNER JOIN tmscrq.TMLeadProcess lp 
        ON lp.Id = l.ProcessID

    LEFT JOIN tmscrq.TMUser tu 
        ON tu.KUserID = l.CreatedBy

    WHERE 
        r.IsActive = 1
        AND lp.Code = 'DELIVERY_PENDING'

    GROUP BY 
        l.ProductId,
        COALESCE(l.StoreId, tu.StoreId)
) r 
    ON r.ProductId = p.Id
    AND r.StoreId = (
        SELECT Id 
        FROM tmscrq.TMStore 
        WHERE StoreCode = @StoreCode
    )

--------------------------------------------------
-- 🔥 FİLTRELER
--------------------------------------------------
WHERE 
    i.storeCode = @StoreCode
    AND i.officeDescription IS NOT NULL
    AND i.officeDescription NOT IN ('Teknik Servis Ofis')

    -- 🔥 ÜRÜN TİPİ
    AND (
        @UrunTipi IS NULL 
        OR @UrunTipi = '' 
        OR UPPER(LTRIM(RTRIM(i.ProductAtt02Desc))) = UPPER(LTRIM(RTRIM(@UrunTipi)))
    )

    -- 🔥 DİĞER FİLTRELER
    AND (@Brand IS NULL OR @Brand = '' OR p.Brand = @Brand)
    AND (@CategoryName IS NULL OR @CategoryName = '' OR p.CategoryName = @CategoryName)
    AND (@ProductName IS NULL OR @ProductName = '' OR p.ProductName = @ProductName)
    AND (@Referance IS NULL OR @Referance = '' OR p.Referance = @Referance)
    AND (@Dial IS NULL OR @Dial = '' OR p.Dial = @Dial)
    AND (@Bracelet IS NULL OR @Bracelet = '' OR p.Bracelet = @Bracelet)

--------------------------------------------------
-- 🔥 GROUP
--------------------------------------------------
GROUP BY 
    i.officeDescription,
    i.storeCode,
    p.ProductCode,
    p.Brand,
    p.CategoryName,
    p.ProductName,
    p.Referance,
    p.Dial,
    p.Bracelet,
    r.ReservedCount

--------------------------------------------------
-- 🔥 HAVING
--------------------------------------------------
HAVING 
    SUM(ISNULL(i.InventoryQty1, 0)) > 0

    AND (
        @Durum IS NULL

        -- 🔴 Rezerve olanlar
        OR (@Durum = 1 AND ISNULL(r.ReservedCount, 0) > 0)

        -- 🟢 Müsait olanlar
        OR (@Durum = 0 AND (SUM(ISNULL(i.InventoryQty1, 0)) - ISNULL(r.ReservedCount, 0)) > 0)
    )

--------------------------------------------------
-- 🔥 ORDER
--------------------------------------------------
ORDER BY 
    CASE 
        WHEN p.Brand = 'Rolex' THEN 1 
        WHEN p.Brand = 'Tudor' THEN 2 
        ELSE 3 
    END,
    ToplamStok ASC,
    p.ProductName;", new string[] { "Ofis", "storeCode", "ProductCode", "Brand", "CategoryName", "ProductName", "Referance", "Dial", "Bracelet", "ToplamStok", "RezerveStok", "MusaitStok" }, prms_TM_GetInventoryByUserStore_0.ToArray());
            ;


            return Ok(result);
        }


        [HttpPost, Route("StockListStoreBaseComponent_466548_onChange")]
        public IActionResult StockListStoreBaseComponent_466548_onChange(StockListStoreBaseComponent_466548_onChange_Request request)
        {

            var result = new StockListStoreBaseComponent_466548_onChange_Response();

            var prms_TM_GetInventoryByUserStore_0 = new List<kSqlParameter>();
            prms_TM_GetInventoryByUserStore_0.Add(new kSqlParameter() { Name = "StoreCode", Value = request.StoreCode_0 });
            prms_TM_GetInventoryByUserStore_0.Add(new kSqlParameter() { Name = "UrunTipi", Value = request.UrunTipi_0 });
            prms_TM_GetInventoryByUserStore_0.Add(new kSqlParameter() { Name = "Brand", Value = request.Brand_0 });
            prms_TM_GetInventoryByUserStore_0.Add(new kSqlParameter() { Name = "CategoryName", Value = request.CategoryName_0 });
            prms_TM_GetInventoryByUserStore_0.Add(new kSqlParameter() { Name = "ProductName", Value = request.ProductName_0 });
            prms_TM_GetInventoryByUserStore_0.Add(new kSqlParameter() { Name = "Referance", Value = request.Referance_0 });
            prms_TM_GetInventoryByUserStore_0.Add(new kSqlParameter() { Name = "Dial", Value = request.Dial_0 });
            prms_TM_GetInventoryByUserStore_0.Add(new kSqlParameter() { Name = "Bracelet", Value = request.Bracelet_0 });
            prms_TM_GetInventoryByUserStore_0.Add(new kSqlParameter() { Name = "Durum", Value = request.Durum_0 });
            using var auditTM_GetInventoryByUserStore_0 = ActionAuditScope.Begin("c9df7a3b-c754-3fec-e5ce-adc858f09941", "TM_GetInventoryByUserStore", applicationName: "wbTimesCRM", screenOrEndpointName: "StockListStoreBase");
            result.TM_GetInventoryByUserStore = KPersister.Fetch(KContext.GetConnectionString(), @"
--------------------------------------------------
-- 🔥 ANA SORGU
--------------------------------------------------
SELECT 
    i.officeDescription AS Ofis,
    i.storeCode,

    p.ProductCode,
    p.Brand,
    p.CategoryName,
    p.ProductName,
    p.Referance,
    p.Dial,
    p.Bracelet,

    --------------------------------------------------
    -- 🔥 STOK
    --------------------------------------------------
    SUM(ISNULL(i.InventoryQty1, 0)) AS ToplamStok,

    ISNULL(r.ReservedCount, 0) AS RezerveStok,

    SUM(ISNULL(i.InventoryQty1, 0)) - ISNULL(r.ReservedCount, 0) AS MusaitStok

FROM tmscrq.TMItemInventory i

INNER JOIN tmscrq.TMProduct p 
    ON i.productCode = p.ProductCode

--------------------------------------------------
-- 🔥 REZERVE
--------------------------------------------------
LEFT JOIN (
    SELECT 
        l.ProductId,
        COALESCE(l.StoreId, tu.StoreId) AS StoreId,
        COUNT(DISTINCT r.LeadId) AS ReservedCount
    FROM tmscrq.TMLeadReservation r

    INNER JOIN tmscrq.TMLead l 
        ON l.Id = r.LeadId

    INNER JOIN tmscrq.TMLeadProcess lp 
        ON lp.Id = l.ProcessID

    LEFT JOIN tmscrq.TMUser tu 
        ON tu.KUserID = l.CreatedBy

    WHERE 
        r.IsActive = 1
        AND lp.Code = 'DELIVERY_PENDING'

    GROUP BY 
        l.ProductId,
        COALESCE(l.StoreId, tu.StoreId)
) r 
    ON r.ProductId = p.Id
    AND r.StoreId = (
        SELECT Id 
        FROM tmscrq.TMStore 
        WHERE StoreCode = @StoreCode
    )

--------------------------------------------------
-- 🔥 FİLTRELER
--------------------------------------------------
WHERE 
    i.storeCode = @StoreCode
    AND i.officeDescription IS NOT NULL
    AND i.officeDescription NOT IN ('Teknik Servis Ofis')

    -- 🔥 ÜRÜN TİPİ
    AND (
        @UrunTipi IS NULL 
        OR @UrunTipi = '' 
        OR UPPER(LTRIM(RTRIM(i.ProductAtt02Desc))) = UPPER(LTRIM(RTRIM(@UrunTipi)))
    )

    -- 🔥 DİĞER FİLTRELER
    AND (@Brand IS NULL OR @Brand = '' OR p.Brand = @Brand)
    AND (@CategoryName IS NULL OR @CategoryName = '' OR p.CategoryName = @CategoryName)
    AND (@ProductName IS NULL OR @ProductName = '' OR p.ProductName = @ProductName)
    AND (@Referance IS NULL OR @Referance = '' OR p.Referance = @Referance)
    AND (@Dial IS NULL OR @Dial = '' OR p.Dial = @Dial)
    AND (@Bracelet IS NULL OR @Bracelet = '' OR p.Bracelet = @Bracelet)

--------------------------------------------------
-- 🔥 GROUP
--------------------------------------------------
GROUP BY 
    i.officeDescription,
    i.storeCode,
    p.ProductCode,
    p.Brand,
    p.CategoryName,
    p.ProductName,
    p.Referance,
    p.Dial,
    p.Bracelet,
    r.ReservedCount

--------------------------------------------------
-- 🔥 HAVING
--------------------------------------------------
HAVING 
    SUM(ISNULL(i.InventoryQty1, 0)) > 0

    AND (
        @Durum IS NULL

        -- 🔴 Rezerve olanlar
        OR (@Durum = 1 AND ISNULL(r.ReservedCount, 0) > 0)

        -- 🟢 Müsait olanlar
        OR (@Durum = 0 AND (SUM(ISNULL(i.InventoryQty1, 0)) - ISNULL(r.ReservedCount, 0)) > 0)
    )

--------------------------------------------------
-- 🔥 ORDER
--------------------------------------------------
ORDER BY 
    CASE 
        WHEN p.Brand = 'Rolex' THEN 1 
        WHEN p.Brand = 'Tudor' THEN 2 
        ELSE 3 
    END,
    ToplamStok ASC,
    p.ProductName;", new string[] { "Ofis", "storeCode", "ProductCode", "Brand", "CategoryName", "ProductName", "Referance", "Dial", "Bracelet", "ToplamStok", "RezerveStok", "MusaitStok" }, prms_TM_GetInventoryByUserStore_0.ToArray());
            ;


            return Ok(result);
        }


        [HttpPost, Route("StockListStoreBaseComponent_702276_onClick1_")]
        public IActionResult StockListStoreBaseComponent_702276_onClick1_(StockListStoreBaseComponent_702276_onClick1__Request request)
        {

            var result = new StockListStoreBaseComponent_702276_onClick1__Response();

            var prms_TM_GetInventoryByUserStore_0 = new List<kSqlParameter>();
            prms_TM_GetInventoryByUserStore_0.Add(new kSqlParameter() { Name = "StoreCode", Value = request.StoreCode_0 });
            prms_TM_GetInventoryByUserStore_0.Add(new kSqlParameter() { Name = "UrunTipi", Value = (null as object) });
            prms_TM_GetInventoryByUserStore_0.Add(new kSqlParameter() { Name = "Brand", Value = (null as object) });
            prms_TM_GetInventoryByUserStore_0.Add(new kSqlParameter() { Name = "CategoryName", Value = (null as object) });
            prms_TM_GetInventoryByUserStore_0.Add(new kSqlParameter() { Name = "ProductName", Value = (null as object) });
            prms_TM_GetInventoryByUserStore_0.Add(new kSqlParameter() { Name = "Referance", Value = (null as object) });
            prms_TM_GetInventoryByUserStore_0.Add(new kSqlParameter() { Name = "Dial", Value = (null as object) });
            prms_TM_GetInventoryByUserStore_0.Add(new kSqlParameter() { Name = "Bracelet", Value = (null as object) });
            prms_TM_GetInventoryByUserStore_0.Add(new kSqlParameter() { Name = "Durum", Value = (null as object) });
            using var auditTM_GetInventoryByUserStore_0 = ActionAuditScope.Begin("8c53bc39-51fe-e672-8669-e2bc4b33bebe", "TM_GetInventoryByUserStore", applicationName: "wbTimesCRM", screenOrEndpointName: "StockListStoreBase");
            result.TM_GetInventoryByUserStore = KPersister.Fetch(KContext.GetConnectionString(), @"
--------------------------------------------------
-- 🔥 ANA SORGU
--------------------------------------------------
SELECT 
    i.officeDescription AS Ofis,
    i.storeCode,

    p.ProductCode,
    p.Brand,
    p.CategoryName,
    p.ProductName,
    p.Referance,
    p.Dial,
    p.Bracelet,

    --------------------------------------------------
    -- 🔥 STOK
    --------------------------------------------------
    SUM(ISNULL(i.InventoryQty1, 0)) AS ToplamStok,

    ISNULL(r.ReservedCount, 0) AS RezerveStok,

    SUM(ISNULL(i.InventoryQty1, 0)) - ISNULL(r.ReservedCount, 0) AS MusaitStok

FROM tmscrq.TMItemInventory i

INNER JOIN tmscrq.TMProduct p 
    ON i.productCode = p.ProductCode

--------------------------------------------------
-- 🔥 REZERVE
--------------------------------------------------
LEFT JOIN (
    SELECT 
        l.ProductId,
        COALESCE(l.StoreId, tu.StoreId) AS StoreId,
        COUNT(DISTINCT r.LeadId) AS ReservedCount
    FROM tmscrq.TMLeadReservation r

    INNER JOIN tmscrq.TMLead l 
        ON l.Id = r.LeadId

    INNER JOIN tmscrq.TMLeadProcess lp 
        ON lp.Id = l.ProcessID

    LEFT JOIN tmscrq.TMUser tu 
        ON tu.KUserID = l.CreatedBy

    WHERE 
        r.IsActive = 1
        AND lp.Code = 'DELIVERY_PENDING'

    GROUP BY 
        l.ProductId,
        COALESCE(l.StoreId, tu.StoreId)
) r 
    ON r.ProductId = p.Id
    AND r.StoreId = (
        SELECT Id 
        FROM tmscrq.TMStore 
        WHERE StoreCode = @StoreCode
    )

--------------------------------------------------
-- 🔥 FİLTRELER
--------------------------------------------------
WHERE 
    i.storeCode = @StoreCode
    AND i.officeDescription IS NOT NULL
    AND i.officeDescription NOT IN ('Teknik Servis Ofis')

    -- 🔥 ÜRÜN TİPİ
    AND (
        @UrunTipi IS NULL 
        OR @UrunTipi = '' 
        OR UPPER(LTRIM(RTRIM(i.ProductAtt02Desc))) = UPPER(LTRIM(RTRIM(@UrunTipi)))
    )

    -- 🔥 DİĞER FİLTRELER
    AND (@Brand IS NULL OR @Brand = '' OR p.Brand = @Brand)
    AND (@CategoryName IS NULL OR @CategoryName = '' OR p.CategoryName = @CategoryName)
    AND (@ProductName IS NULL OR @ProductName = '' OR p.ProductName = @ProductName)
    AND (@Referance IS NULL OR @Referance = '' OR p.Referance = @Referance)
    AND (@Dial IS NULL OR @Dial = '' OR p.Dial = @Dial)
    AND (@Bracelet IS NULL OR @Bracelet = '' OR p.Bracelet = @Bracelet)

--------------------------------------------------
-- 🔥 GROUP
--------------------------------------------------
GROUP BY 
    i.officeDescription,
    i.storeCode,
    p.ProductCode,
    p.Brand,
    p.CategoryName,
    p.ProductName,
    p.Referance,
    p.Dial,
    p.Bracelet,
    r.ReservedCount

--------------------------------------------------
-- 🔥 HAVING
--------------------------------------------------
HAVING 
    SUM(ISNULL(i.InventoryQty1, 0)) > 0

    AND (
        @Durum IS NULL

        -- 🔴 Rezerve olanlar
        OR (@Durum = 1 AND ISNULL(r.ReservedCount, 0) > 0)

        -- 🟢 Müsait olanlar
        OR (@Durum = 0 AND (SUM(ISNULL(i.InventoryQty1, 0)) - ISNULL(r.ReservedCount, 0)) > 0)
    )

--------------------------------------------------
-- 🔥 ORDER
--------------------------------------------------
ORDER BY 
    CASE 
        WHEN p.Brand = 'Rolex' THEN 1 
        WHEN p.Brand = 'Tudor' THEN 2 
        ELSE 3 
    END,
    ToplamStok ASC,
    p.ProductName;", new string[] { "Ofis", "storeCode", "ProductCode", "Brand", "CategoryName", "ProductName", "Referance", "Dial", "Bracelet", "ToplamStok", "RezerveStok", "MusaitStok" }, prms_TM_GetInventoryByUserStore_0.ToArray());
            ;


            return Ok(result);
        }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class StockListStoreBasePageInit_Request
    {
        public Guid? KUserId_0 { set; get; }
        public String StoreCode_1 { set; get; }
        public String UrunTipi_1 { set; get; }
        public String Brand_1 { set; get; }
        public String CategoryName_1 { set; get; }
        public String ProductName_1 { set; get; }
        public String Referance_1 { set; get; }
        public String Dial_1 { set; get; }
        public String Bracelet_1 { set; get; }
        public String StoreCode_2 { set; get; }
        public String UrunTipi_2 { set; get; }
        public String Brand_2 { set; get; }
        public String CategoryName_2 { set; get; }
        public String ProductName_2 { set; get; }
        public String Referance_2 { set; get; }
        public String Dial_2 { set; get; }
        public String Bracelet_2 { set; get; }
        public Int32? Durum_2 { set; get; }
        public String StoreCode_3 { set; get; }
        public String StoreCode_4 { set; get; }
        public String StoreCode_5 { set; get; }
        public String StoreCode_6 { set; get; }
        public String StoreCode_7 { set; get; }
        public String StoreCode_8 { set; get; }
        public String StoreCode_9 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class StockListStoreBasePageInit_Response
    {
        public KCommonEntityPage TM_GetUserStoreCode { set; get; }

        public KCommonEntityPage TM_GetStoreDashboardSummary { set; get; }

        public KCommonEntityPage TM_GetInventoryByUserStore { set; get; }

        public KCommonEntityPage TM_GetStockBrands { set; get; }

        public KCommonEntityPage TM_GetProductNamesByStore { set; get; }

        public KCommonEntityPage TM_GetCategoriesByStore { set; get; }

        public KCommonEntityPage TM_GetReferencesByStore { set; get; }

        public KCommonEntityPage TM_GetDialsByStore { set; get; }

        public KCommonEntityPage TM_GetBraceletsByStore { set; get; }

        public KCommonEntityPage TM_GetItemType { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class StockListStoreBaseComponent_356162_onChange_Request
    {
        public String StoreCode_0 { set; get; }
        public String UrunTipi_0 { set; get; }
        public String Brand_0 { set; get; }
        public String CategoryName_0 { set; get; }
        public String ProductName_0 { set; get; }
        public String Referance_0 { set; get; }
        public String Dial_0 { set; get; }
        public String Bracelet_0 { set; get; }
        public Int32? Durum_0 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class StockListStoreBaseComponent_356162_onChange_Response
    {
        public KCommonEntityPage TM_GetInventoryByUserStore { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class StockListStoreBaseComponent_190692_onChange_Request
    {
        public String StoreCode_0 { set; get; }
        public String UrunTipi_0 { set; get; }
        public String Brand_0 { set; get; }
        public String CategoryName_0 { set; get; }
        public String ProductName_0 { set; get; }
        public String Referance_0 { set; get; }
        public String Dial_0 { set; get; }
        public String Bracelet_0 { set; get; }
        public Int32? Durum_0 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class StockListStoreBaseComponent_190692_onChange_Response
    {
        public KCommonEntityPage TM_GetInventoryByUserStore { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class StockListStoreBaseComponent_560082_onChange_Request
    {
        public String StoreCode_0 { set; get; }
        public String UrunTipi_0 { set; get; }
        public String Brand_0 { set; get; }
        public String CategoryName_0 { set; get; }
        public String ProductName_0 { set; get; }
        public String Referance_0 { set; get; }
        public String Dial_0 { set; get; }
        public String Bracelet_0 { set; get; }
        public Int32? Durum_0 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class StockListStoreBaseComponent_560082_onChange_Response
    {
        public KCommonEntityPage TM_GetInventoryByUserStore { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class StockListStoreBaseComponent_944323_onChange_Request
    {
        public String StoreCode_0 { set; get; }
        public String UrunTipi_0 { set; get; }
        public String Brand_0 { set; get; }
        public String CategoryName_0 { set; get; }
        public String ProductName_0 { set; get; }
        public String Referance_0 { set; get; }
        public String Dial_0 { set; get; }
        public String Bracelet_0 { set; get; }
        public Int32? Durum_0 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class StockListStoreBaseComponent_944323_onChange_Response
    {
        public KCommonEntityPage TM_GetInventoryByUserStore { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class StockListStoreBaseComponent_944471_onChange_Request
    {
        public String StoreCode_0 { set; get; }
        public String UrunTipi_0 { set; get; }
        public String Brand_0 { set; get; }
        public String CategoryName_0 { set; get; }
        public String ProductName_0 { set; get; }
        public String Referance_0 { set; get; }
        public String Dial_0 { set; get; }
        public String Bracelet_0 { set; get; }
        public Int32? Durum_0 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class StockListStoreBaseComponent_944471_onChange_Response
    {
        public KCommonEntityPage TM_GetInventoryByUserStore { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class StockListStoreBaseComponent_651590_onChange_Request
    {
        public String StoreCode_0 { set; get; }
        public String UrunTipi_0 { set; get; }
        public String Brand_0 { set; get; }
        public String CategoryName_0 { set; get; }
        public String ProductName_0 { set; get; }
        public String Referance_0 { set; get; }
        public String Dial_0 { set; get; }
        public String Bracelet_0 { set; get; }
        public Int32? Durum_0 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class StockListStoreBaseComponent_651590_onChange_Response
    {
        public KCommonEntityPage TM_GetInventoryByUserStore { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class StockListStoreBaseComponent_831544_onChange_Request
    {
        public String StoreCode_0 { set; get; }
        public String UrunTipi_0 { set; get; }
        public String Brand_0 { set; get; }
        public String CategoryName_0 { set; get; }
        public String ProductName_0 { set; get; }
        public String Referance_0 { set; get; }
        public String Dial_0 { set; get; }
        public String Bracelet_0 { set; get; }
        public Int32? Durum_0 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class StockListStoreBaseComponent_831544_onChange_Response
    {
        public KCommonEntityPage TM_GetInventoryByUserStore { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class StockListStoreBaseComponent_466548_onChange_Request
    {
        public String StoreCode_0 { set; get; }
        public String UrunTipi_0 { set; get; }
        public String Brand_0 { set; get; }
        public String CategoryName_0 { set; get; }
        public String ProductName_0 { set; get; }
        public String Referance_0 { set; get; }
        public String Dial_0 { set; get; }
        public String Bracelet_0 { set; get; }
        public Int32? Durum_0 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class StockListStoreBaseComponent_466548_onChange_Response
    {
        public KCommonEntityPage TM_GetInventoryByUserStore { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class StockListStoreBaseComponent_702276_onClick1__Request
    {
        public String StoreCode_0 { set; get; }
        public String UrunTipi_0 { set; get; }
        public String Brand_0 { set; get; }
        public String CategoryName_0 { set; get; }
        public String ProductName_0 { set; get; }
        public String Referance_0 { set; get; }
        public String Dial_0 { set; get; }
        public String Bracelet_0 { set; get; }
        public Int32? Durum_0 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class StockListStoreBaseComponent_702276_onClick1__Response
    {
        public KCommonEntityPage TM_GetInventoryByUserStore { set; get; }

    }
}
