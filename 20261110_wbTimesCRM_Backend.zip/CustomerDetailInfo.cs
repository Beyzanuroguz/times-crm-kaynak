
using Kuika.Common;
using Kuika.Common.Attributes;
using Kuika.Common.Bases;
using Kuika.Common.Enums;
using Kuika.Common.Accessors;
using Kuika.Common.Json;
using Kuika.Common.Classes;
using Kuika.Common.Exceptions;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Kuika.Common.Helpers;
using Kuika.Common.Settings;
using System.Collections.Generic;
using System;
using Kuika.Common.Extensions;
using System.Linq;
using Kuika.Common.Rest;
using WorkflowCore.Interface;
using Kuika.Common.Interfaces;
using Kuika.Common.Workflow;
using Kuika.Common.Workflow.Extensions;
using Kuika.Common.Workflow.DTOs;
using Kuika.Common.Models;
using Kuika.Common.Menu.Response;
using Kuika.Common.Entities;
using System.Reflection;
using Newtonsoft.Json.Linq;
using Newtonsoft.Json;
using System.Net.Http;
using Iyzipay.Model.V2.Subscription;
using Kuika.Common.Payments.Iyzico;
using Kuika.Common.Payments.Param;
using Iyzipay;
using Kuika.Common.Searching.DTOs;
using Kuika.Common.Helpers.Sap;
using Kuika.Common.Mcp;
using Kuika.Common.Vision.DTOs;
using Kuika.Common.Audit;
using Kuika.Common.Payments.Mobile;
using Kuika.ThirdPartyApisCollection;

namespace Kuika.Reslen_01.Api
{
    [ApiExplorerSettings(GroupName = "all")]
    [Authorize]
    [ApiController]
    [Route("v1/api/CustomerDetailInfo")]
    public class CustomerDetailInfo_Controller : KControllerBase
    {
        private string appName = "wbTimesCRM";
        private Guid appId = Guid.Parse("0e8ecb48-8c52-463c-5db5-08de3ec441b1");
        private static string screenName = "CustomerDetailInfo";
        private Guid screenId = Guid.Parse("db485e8f-db8f-448e-8a75-9583a7901946");
        private string connectionString { get { return Kuika.Common.KContext.GetConnectionString(); } }

        [HttpGet, Route("myroles")]
        public IActionResult GetMyRoles()
        {
            try
            {
                var result = KProviderManager.Authorization.GetMyRoles(appId, appName, screenId, screenName);
                return Ok(result);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new HttpExceptionDto() { Message = ex.Message, StackTrace = ex.StackTrace });
            }
        }


        [HttpPost, Route("CustomerDetailInfoPageInit")]
        public IActionResult CustomerDetailInfoPageInit(CustomerDetailInfoPageInit_Request request)
        {

            KProviderManager.Authorization.IsAuthorizedForRoles(appId, appName, screenId, screenName, new List<string> { $"cdb536b0-6297-155f-d446-8453d8a60304", "4da1f213-c8e4-0b50-5c84-02fd13f1a622", "b4bfd39c-ac02-f442-c899-7a2374a45b47", "70de6cfc-6087-6059-59b4-0b5a8527af6b", "TimesYonetici", "TimesUstYonetici", "TimesSatisPersoneli", "TimesMagazaMuduru" });

            var result = new CustomerDetailInfoPageInit_Response();

            var prms_TM_GetAllCustomerLead_0 = new List<kSqlParameter>();
            prms_TM_GetAllCustomerLead_0.Add(new kSqlParameter() { Name = "CustomerId", Value = request.CustomerId_0 });
            using var auditTM_GetAllCustomerLead_0 = ActionAuditScope.Begin("64e2bc12-3fff-8b67-853e-09e2f4336783", "TM_GetAllCustomerLead", applicationName: "wbTimesCRM", screenOrEndpointName: "CustomerDetailInfo");
            result.TM_GetAllCustomerLead = KPersister.Fetch(KContext.GetConnectionString(), @"SELECT
    l.Id AS LeadId,
    l.LeadCode AS LeadCode,

    CASE 
        WHEN l.CreatedAt IS NULL THEN '-'
        ELSE FORMAT(l.CreatedAt, 'dd MMMM yyyy', 'tr-TR')
    END AS CreatedAt,

    COALESCE(
        NULLIF(
            LTRIM(RTRIM(
                ISNULL(cu.Name, '') +
                CASE 
                    WHEN cu.LastName IS NOT NULL 
                         AND LTRIM(RTRIM(cu.LastName)) <> '' 
                    THEN ' ' + LTRIM(RTRIM(cu.LastName))
                    ELSE '' 
                END
            )),
            ''
        ),
        NULLIF(LTRIM(RTRIM(cu.CurrAccDescription)), ''),
        ''
    ) AS Musteri,

    cu.Tel,
    cu.NationalID,
    cu.Email,
    cu.PasaportNo,

    cu.CityName AS Lokasyon,
    st.StoreDesc AS Magaza,
    ls.Name AS LeadDurumu,

    CASE 
        WHEN l.EstimatedDate IS NULL THEN '-'
        ELSE FORMAT(l.EstimatedDate, 'yyyy MMMM', 'tr-TR')
    END AS EstimatedDate,

    p.Brand AS ProductBrand,
    p.Referance AS ProductRefNo,
    p.Dial AS ProductDial,
    p.Bracelet AS ProductBracelet,

    LTRIM(RTRIM(
        ISNULL(p.Dial, '') +
        CASE 
            WHEN p.Dial IS NOT NULL 
                 AND p.Bracelet IS NOT NULL 
            THEN ' / '
            ELSE ''
        END +
        ISNULL(p.Bracelet, '')
    )) AS DialAndBrac,

    p.ProductName AS ProductDisplay,

    ku.FirstName + ' ' + ku.LastName AS CreatedByUser,

    pr.Name AS ProcessName,
    pr.Code AS ProcessCode,
    pr.StepOrder AS ProcessStep

FROM tmscrq.TMLead l

LEFT JOIN tmscrq.TMCustomer cu
    ON cu.Id = l.CustomerId

LEFT JOIN tmscrq.TMLeadStatu ls
    ON ls.Id = l.StatuId

LEFT JOIN tmscrq.TMUser tu
    ON tu.KUserID = l.CreatedBy

LEFT JOIN tmscrq.TMStore st
    ON st.Id = tu.StoreId

LEFT JOIN tmscrq.TMProduct p
    ON p.Id = l.ProductId

LEFT JOIN dbo.KUser ku
    ON ku.Id = l.CreatedBy

LEFT JOIN tmscrq.TMLeadProcess pr
    ON pr.Id = l.ProcessID

WHERE
    l.CustomerId = @CustomerId

ORDER BY
    l.CreatedAt DESC;", new string[] { "LeadId", "LeadCode", "CreatedAt", "Musteri", "Tel", "NationalID", "Email", "PasaportNo", "Lokasyon", "Magaza", "LeadDurumu", "EstimatedDate", "ProductBrand", "ProductRefNo", "ProductDial", "ProductBracelet", "DialAndBrac", "ProductDisplay", "CreatedByUser", "ProcessName", "ProcessCode", "ProcessStep" }, prms_TM_GetAllCustomerLead_0.ToArray());
            ;


            using var auditGetUsdEurForexSelling_1 = ActionAuditScope.Begin("2e3fdda2-e663-08ac-f3ef-80cc09a4a215", "GetUsdEurForexSelling", applicationName: "wbTimesCRM", screenOrEndpointName: "CustomerDetailInfo");
            using var actionAuditGetUsdEurForexSelling_1 = ActionAuditHelper.Begin("GetUsdEurForexSelling", null);
            try
            {
                result.GetUsdEurForexSelling = Kuika.ThirdPartyApisCollection.TcmbCurrencyFetcher.GetUsdEurForexSelling();
                actionAuditGetUsdEurForexSelling_1.SetResult(result.GetUsdEurForexSelling);
            }
            catch (Exception ex)
            {
                actionAuditGetUsdEurForexSelling_1.SetException(ex);
                throw;
            }
;


            using var auditGetCustomerDetail_2 = ActionAuditScope.Begin("616dc5c7-8718-7822-9573-f59c3e370c8b", "GetCustomerDetail", applicationName: "wbTimesCRM", screenOrEndpointName: "CustomerDetailInfo");
            using var actionAuditGetCustomerDetail_2 = ActionAuditHelper.Begin("GetCustomerDetail", new { customerCode = request.customerCode_2.ConvertToType<String>(), usdRate = (Decimal)result.GetUsdEurForexSelling.UsdForexSelling.ConvertToType<Decimal>(), eurRate = (Decimal)result.GetUsdEurForexSelling.EurForexSelling.ConvertToType<Decimal>() });
            try
            {
                result.GetCustomerDetail = Kuika.ThirdPartyApisCollection.GetKuikaCustomerDetail.GetCustomerDetail(request.customerCode_2.ConvertToType<String>(), (Decimal)result.GetUsdEurForexSelling.UsdForexSelling.ConvertToType<Decimal>(), (Decimal)result.GetUsdEurForexSelling.EurForexSelling.ConvertToType<Decimal>());
                actionAuditGetCustomerDetail_2.SetResult(result.GetCustomerDetail);
            }
            catch (Exception ex)
            {
                actionAuditGetCustomerDetail_2.SetException(ex);
                throw;
            }
;


            return Ok(result);
        }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class CustomerDetailInfoPageInit_Request
    {
        public Guid? CustomerId_0 { set; get; }
        public String? customerCode_2 { set; get; }
        public Decimal? usdRate_2 { set; get; }
        public Decimal? eurRate_2 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class CustomerDetailInfoPageInit_Response
    {
        public KCommonEntityPage TM_GetAllCustomerLead { set; get; }

        public Kuika.ThirdPartyApisCollection.TcmbUsdEurForexSellingDto GetUsdEurForexSelling { set; get; }

        public System.Collections.Generic.IList<Kuika.ThirdPartyApisCollection.KuikaCustomerDetailModel> GetCustomerDetail { set; get; }

    }
}
