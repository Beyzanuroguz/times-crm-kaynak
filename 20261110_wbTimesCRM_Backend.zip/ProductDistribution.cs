
using Kuika.Common;
using Kuika.Common.Attributes;
using Kuika.Common.Bases;
using Kuika.Common.Enums;
using Kuika.Common.Accessors;
using Kuika.Common.Json;
using Kuika.Common.Classes;
using Kuika.Common.Exceptions;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Kuika.Common.Helpers;
using Kuika.Common.Settings;
using System.Collections.Generic;
using System;
using Kuika.Common.Extensions;
using System.Linq;
using Kuika.Common.Rest;
using WorkflowCore.Interface;
using Kuika.Common.Interfaces;
using Kuika.Common.Workflow;
using Kuika.Common.Workflow.Extensions;
using Kuika.Common.Workflow.DTOs;
using Kuika.Common.Models;
using Kuika.Common.Menu.Response;
using Kuika.Common.Entities;
using System.Reflection;
using Newtonsoft.Json.Linq;
using Newtonsoft.Json;
using System.Net.Http;
using Iyzipay.Model.V2.Subscription;
using Kuika.Common.Payments.Iyzico;
using Kuika.Common.Payments.Param;
using Iyzipay;
using Kuika.Common.Searching.DTOs;
using Kuika.Common.Helpers.Sap;
using Kuika.Common.Mcp;
using Kuika.Common.Vision.DTOs;
using Kuika.Common.Audit;
using Kuika.Common.Payments.Mobile;
using Kuika.ThirdPartyApisCollection;

namespace Kuika.Reslen_01.Api
{
    [ApiExplorerSettings(GroupName = "all")]
    [Authorize]
    [ApiController]
    [Route("v1/api/ProductDistribution")]
    public class ProductDistribution_Controller : KControllerBase
    {
        private string appName = "wbTimesCRM";
        private Guid appId = Guid.Parse("0e8ecb48-8c52-463c-5db5-08de3ec441b1");
        private static string screenName = "ProductDistribution";
        private Guid screenId = Guid.Parse("c6a00e04-1d1e-45eb-a72a-0229b988cf19");
        private string connectionString { get { return Kuika.Common.KContext.GetConnectionString(); } }

        [HttpGet, Route("myroles")]
        public IActionResult GetMyRoles()
        {
            try
            {
                var result = KProviderManager.Authorization.GetMyRoles(appId, appName, screenId, screenName);
                return Ok(result);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new HttpExceptionDto() { Message = ex.Message, StackTrace = ex.StackTrace });
            }
        }


        [HttpPost, Route("ProductDistributionPageInit")]
        public IActionResult ProductDistributionPageInit(ProductDistributionPageInit_Request request)
        {

            var result = new ProductDistributionPageInit_Response();

            var prms_TM_GetProductDetail_0 = new List<kSqlParameter>();
            prms_TM_GetProductDetail_0.Add(new kSqlParameter() { Name = "ProductCode", Value = request.ProductCode_0 });
            using var auditTM_GetProductDetail_0 = ActionAuditScope.Begin("8ef4ebb6-44d5-adb8-8a9b-3be2dcfa92ff", "TM_GetProductDetail", applicationName: "wbTimesCRM", screenOrEndpointName: "ProductDistribution");
            result.TM_GetProductDetail = KPersister.Fetch(KContext.GetConnectionString(), @"SELECT 
    p.ProductName,
    p.ProductCode,      -- 🔥 RMC / ürün kodu
    p.Brand,
    p.Referance,
    p.Dial,
    p.Bracelet

FROM tmscrq.TMProduct p

WHERE 
    p.ProductCode = @ProductCode;", new string[] { "ProductName", "ProductCode", "Brand", "Referance", "Dial", "Bracelet" }, prms_TM_GetProductDetail_0.ToArray());
            ;

            var prms_TM_GetLeadsByProductAndStore_1 = new List<kSqlParameter>();
            prms_TM_GetLeadsByProductAndStore_1.Add(new kSqlParameter() { Name = "StoreCode", Value = "001".ConvertToType<String>() });
            prms_TM_GetLeadsByProductAndStore_1.Add(new kSqlParameter() { Name = "ProductCode", Value = request.ProductCode_1 });
            using var auditTM_GetLeadsByProductAndStore_1 = ActionAuditScope.Begin("18d76740-504e-edeb-9161-a185f3a271ea", "TM_GetLeadsByProductAndStore", applicationName: "wbTimesCRM", screenOrEndpointName: "ProductDistribution");
            result.TM_GetLeadsByProductAndStore = KPersister.Fetch(KContext.GetConnectionString(), @"SELECT 
    l.Id AS LeadId,
    l.LeadCode,

    --------------------------------------------------
    -- 🔥 TERMIN (MOCK NİSAN 2026)
    --------------------------------------------------
    FORMAT(DATEFROMPARTS(2026,4,1), 'yyyy') + ' ' + N'Nisan' 
    AS TahminiTeslimat,

    --------------------------------------------------
    -- 🚨 GECİKMİŞ Mİ (MOCK'A GÖRE)
    --------------------------------------------------
    CASE 
        WHEN DATEFROMPARTS(2026,4,1) < GETDATE() THEN 1
        ELSE 0
    END AS IsOverdue,

    LTRIM(RTRIM(
        COALESCE(c.Name, '') + ' ' + COALESCE(c.LastName, '')
    )) AS MusteriAdi,

    COALESCE(c.Tel, '-') AS Telefon

FROM tmscrq.TMLead l

INNER JOIN tmscrq.TMCustomer c 
    ON c.Id = l.CustomerId

INNER JOIN tmscrq.TMProduct p
    ON p.Id = l.ProductId

INNER JOIN tmscrq.TMLeadProcess lp 
    ON lp.Id = l.ProcessID

LEFT JOIN tmscrq.TMUser tu 
    ON tu.KUserID = l.CreatedBy

LEFT JOIN tmscrq.TMStore st 
    ON st.Id = COALESCE(l.StoreId, tu.StoreId)

WHERE 
    st.StoreCode = @StoreCode
    AND lp.Code = 'APPROVED'
    AND p.ProductCode = @ProductCode

ORDER BY 
    l.CreatedAt DESC;", new string[] { "LeadId", "LeadCode", "TahminiTeslimat", "IsOverdue", "MusteriAdi", "Telefon" }, prms_TM_GetLeadsByProductAndStore_1.ToArray());
            ;

            var prms_TM_GetImportVsApprovedLeadSummary_2 = new List<kSqlParameter>();
            prms_TM_GetImportVsApprovedLeadSummary_2.Add(new kSqlParameter() { Name = "HeaderId", Value = request.HeaderId_2 });
            prms_TM_GetImportVsApprovedLeadSummary_2.Add(new kSqlParameter() { Name = "ProductCode", Value = request.ProductCode_2 });
            using var auditTM_GetImportVsApprovedLeadSummary_2 = ActionAuditScope.Begin("17471fa7-1f0a-bded-9524-235ed6c6c977", "TM_GetImportVsApprovedLeadSummary", applicationName: "wbTimesCRM", screenOrEndpointName: "ProductDistribution");
            result.TM_GetImportVsApprovedLeadSummary = KPersister.Fetch(KContext.GetConnectionString(), @"SELECT 

    --------------------------------------------------
    -- 🔥 IMPORT MİKTARI
    --------------------------------------------------
    ISNULL((
        SELECT SUM(l.Quantity)
        FROM tmscrq.TMImportLine l
        WHERE 
            l.HeaderID = @HeaderId
            AND l.ItemCode = @ProductCode
    ),0) AS ImportQuantity,

    --------------------------------------------------
    -- 🔥 ONAYLI LEAD SAYISI
    --------------------------------------------------
    ISNULL((
        SELECT COUNT(*)
        FROM tmscrq.TMLead ld
        INNER JOIN tmscrq.TMProduct p 
            ON p.Id = ld.ProductId
        INNER JOIN tmscrq.TMLeadProcess lp 
            ON lp.Id = ld.ProcessID   -- 🔥 senin doğru kolon buydu
        WHERE 
            p.ProductCode = @ProductCode
            AND lp.Code = 'APPROVED'
    ),0) AS ApprovedLeadCount;", new string[] { "ImportQuantity", "ApprovedLeadCount" }, prms_TM_GetImportVsApprovedLeadSummary_2.ToArray());
            ;

            var prms_TM_GetProductStockByStoreExceptSelected_3 = new List<kSqlParameter>();
            prms_TM_GetProductStockByStoreExceptSelected_3.Add(new kSqlParameter() { Name = "ProductCode", Value = request.ProductCode_3 });
            using var auditTM_GetProductStockByStoreExceptSelected_3 = ActionAuditScope.Begin("0de6166a-d00f-98cb-16c5-8e4edc3ff100", "TM_GetProductStockByStoreExceptSelected", applicationName: "wbTimesCRM", screenOrEndpointName: "ProductDistribution");
            result.TM_GetProductStockByStoreExceptSelected = KPersister.Fetch(KContext.GetConnectionString(), @"
;WITH Stock AS
(
    SELECT 
        i.StoreCode,

        -- 🔥 BOŞLARI ELE + TEK DOĞRU DEĞERİ AL
        MAX(
            CASE 
                WHEN LTRIM(RTRIM(ISNULL(i.StoreDescription,''))) <> '' 
                THEN i.StoreDescription
                ELSE NULL
            END
        ) AS StoreDescription,

        SUM(ISNULL(i.InventoryQty1, 0)) AS StokMiktari
    FROM tmscrq.TMItemInventory i
    WHERE 
        i.ProductCode = @ProductCode
        AND i.StoreCode <> '005'
    GROUP BY 
        i.StoreCode
),

Reserve AS
(
    SELECT 
        s.StoreCode,
        COUNT(l.Id) AS RezerveMiktari
    FROM tmscrq.TMLead l
    INNER JOIN tmscrq.TMProduct p 
        ON p.Id = l.ProductId
    INNER JOIN tmscrq.TMLeadProcess lp 
        ON lp.Id = l.StatuId
    INNER JOIN tmscrq.TMStore s 
        ON s.Id = l.StoreId
    WHERE 
        p.ProductCode = @ProductCode
        AND ISNULL(l.IsReserved,0) = 1
        AND lp.Code = 'DELIVERED'
    GROUP BY 
        s.StoreCode
)

SELECT 
    st.StoreCode,

    -- 🔥 GARANTİ MAĞAZA ADI
    ISNULL(st.StoreDescription, '-') AS MagazaAdi,

    st.StokMiktari,

    ISNULL(r.RezerveMiktari, 0) AS RezerveMiktari,

    -- 🔥 NET STOK
    st.StokMiktari - ISNULL(r.RezerveMiktari, 0) AS KullanilabilirStok

FROM Stock st

LEFT JOIN Reserve r
    ON r.StoreCode = st.StoreCode

WHERE 
    st.StokMiktari > 0

ORDER BY 
    st.StokMiktari DESC;", new string[] { "StoreCode", "MagazaAdi", "StokMiktari", "RezerveMiktari", "KullanilabilirStok" }, prms_TM_GetProductStockByStoreExceptSelected_3.ToArray());
            ;

            var prms_TM_GetLeadsByProductAndStore_4 = new List<kSqlParameter>();
            prms_TM_GetLeadsByProductAndStore_4.Add(new kSqlParameter() { Name = "StoreCode", Value = "001".ConvertToType<String>() });
            prms_TM_GetLeadsByProductAndStore_4.Add(new kSqlParameter() { Name = "ProductCode", Value = request.ProductCode_4 });
            using var auditTM_GetLeadsByProductAndStore_4 = ActionAuditScope.Begin("0b4a82bc-77ad-3306-405f-2349184a49a9", "TM_GetLeadsByProductAndStore", applicationName: "wbTimesCRM", screenOrEndpointName: "ProductDistribution");
            result.TM_GetLeadsByProductAndStore = KPersister.Fetch(KContext.GetConnectionString(), @"SELECT 
    l.Id AS LeadId,
    l.LeadCode,

    --------------------------------------------------
    -- 🔥 TERMIN (MOCK NİSAN 2026)
    --------------------------------------------------
    FORMAT(DATEFROMPARTS(2026,4,1), 'yyyy') + ' ' + N'Nisan' 
    AS TahminiTeslimat,

    --------------------------------------------------
    -- 🚨 GECİKMİŞ Mİ (MOCK'A GÖRE)
    --------------------------------------------------
    CASE 
        WHEN DATEFROMPARTS(2026,4,1) < GETDATE() THEN 1
        ELSE 0
    END AS IsOverdue,

    LTRIM(RTRIM(
        COALESCE(c.Name, '') + ' ' + COALESCE(c.LastName, '')
    )) AS MusteriAdi,

    COALESCE(c.Tel, '-') AS Telefon

FROM tmscrq.TMLead l

INNER JOIN tmscrq.TMCustomer c 
    ON c.Id = l.CustomerId

INNER JOIN tmscrq.TMProduct p
    ON p.Id = l.ProductId

INNER JOIN tmscrq.TMLeadProcess lp 
    ON lp.Id = l.ProcessID

LEFT JOIN tmscrq.TMUser tu 
    ON tu.KUserID = l.CreatedBy

LEFT JOIN tmscrq.TMStore st 
    ON st.Id = COALESCE(l.StoreId, tu.StoreId)

WHERE 
    st.StoreCode = @StoreCode
    AND lp.Code = 'APPROVED'
    AND p.ProductCode = @ProductCode

ORDER BY 
    l.CreatedAt DESC;", new string[] { "LeadId", "LeadCode", "TahminiTeslimat", "IsOverdue", "MusteriAdi", "Telefon" }, prms_TM_GetLeadsByProductAndStore_4.ToArray());
            ;

            var prms_TM_GetDistributionDraft_5 = new List<kSqlParameter>();
            using var auditTM_GetDistributionDraft_5 = ActionAuditScope.Begin("5bd9927c-e67b-b8ab-4bfd-05eb52639122", "TM_GetDistributionDraft", applicationName: "wbTimesCRM", screenOrEndpointName: "ProductDistribution");
            result.TM_GetDistributionDraft = KPersister.Fetch(KContext.GetConnectionString(), @"SELECT 
    d.Id,
    d.StoreCode,
    s.StoreDesc AS StoreName,
    d.Quantity
FROM tmscrq.TMDistributionDraft d
LEFT JOIN tmscrq.TMStore s 
    ON s.StoreCode = d.StoreCode
ORDER BY 
    s.StoreDesc;", new string[] { "Id", "StoreCode", "StoreName", "Quantity" }, prms_TM_GetDistributionDraft_5.ToArray());
            ;


            return Ok(result);
        }


        [HttpPost, Route("ProductDistributionComponent_787660_onChange")]
        public IActionResult ProductDistributionComponent_787660_onChange(ProductDistributionComponent_787660_onChange_Request request)
        {

            var result = new ProductDistributionComponent_787660_onChange_Response();

            var prms_TM_GetLeadsByProductAndStore_0 = new List<kSqlParameter>();
            prms_TM_GetLeadsByProductAndStore_0.Add(new kSqlParameter() { Name = "StoreCode", Value = "001".ConvertToType<String>() });
            prms_TM_GetLeadsByProductAndStore_0.Add(new kSqlParameter() { Name = "ProductCode", Value = request.ProductCode_0 });
            using var auditTM_GetLeadsByProductAndStore_0 = ActionAuditScope.Begin("4dc04cc2-3f7f-fad8-6cc2-d6b9f96f0d9b", "TM_GetLeadsByProductAndStore", applicationName: "wbTimesCRM", screenOrEndpointName: "ProductDistribution");
            result.TM_GetLeadsByProductAndStore = KPersister.Fetch(KContext.GetConnectionString(), @"SELECT 
    l.Id AS LeadId,
    l.LeadCode,

    --------------------------------------------------
    -- 🔥 TERMIN (MOCK NİSAN 2026)
    --------------------------------------------------
    FORMAT(DATEFROMPARTS(2026,4,1), 'yyyy') + ' ' + N'Nisan' 
    AS TahminiTeslimat,

    --------------------------------------------------
    -- 🚨 GECİKMİŞ Mİ (MOCK'A GÖRE)
    --------------------------------------------------
    CASE 
        WHEN DATEFROMPARTS(2026,4,1) < GETDATE() THEN 1
        ELSE 0
    END AS IsOverdue,

    LTRIM(RTRIM(
        COALESCE(c.Name, '') + ' ' + COALESCE(c.LastName, '')
    )) AS MusteriAdi,

    COALESCE(c.Tel, '-') AS Telefon

FROM tmscrq.TMLead l

INNER JOIN tmscrq.TMCustomer c 
    ON c.Id = l.CustomerId

INNER JOIN tmscrq.TMProduct p
    ON p.Id = l.ProductId

INNER JOIN tmscrq.TMLeadProcess lp 
    ON lp.Id = l.ProcessID

LEFT JOIN tmscrq.TMUser tu 
    ON tu.KUserID = l.CreatedBy

LEFT JOIN tmscrq.TMStore st 
    ON st.Id = COALESCE(l.StoreId, tu.StoreId)

WHERE 
    st.StoreCode = @StoreCode
    AND lp.Code = 'APPROVED'
    AND p.ProductCode = @ProductCode

ORDER BY 
    l.CreatedAt DESC;", new string[] { "LeadId", "LeadCode", "TahminiTeslimat", "IsOverdue", "MusteriAdi", "Telefon" }, prms_TM_GetLeadsByProductAndStore_0.ToArray());
            ;


            return Ok(result);
        }


        [HttpPost, Route("ProductDistributionComponent_543048_onActive")]
        public IActionResult ProductDistributionComponent_543048_onActive(ProductDistributionComponent_543048_onActive_Request request)
        {

            var result = new ProductDistributionComponent_543048_onActive_Response();

            var prms_TM_GetLeadsByProductAndStore_0 = new List<kSqlParameter>();
            prms_TM_GetLeadsByProductAndStore_0.Add(new kSqlParameter() { Name = "StoreCode", Value = "004".ConvertToType<String>() });
            prms_TM_GetLeadsByProductAndStore_0.Add(new kSqlParameter() { Name = "ProductCode", Value = request.ProductCode_0 });
            using var auditTM_GetLeadsByProductAndStore_0 = ActionAuditScope.Begin("cd45d694-fdb3-8c4d-04f8-5595bec3d9d2", "TM_GetLeadsByProductAndStore", applicationName: "wbTimesCRM", screenOrEndpointName: "ProductDistribution");
            result.TM_GetLeadsByProductAndStore = KPersister.Fetch(KContext.GetConnectionString(), @"SELECT 
    l.Id AS LeadId,
    l.LeadCode,

    --------------------------------------------------
    -- 🔥 TERMIN (MOCK NİSAN 2026)
    --------------------------------------------------
    FORMAT(DATEFROMPARTS(2026,4,1), 'yyyy') + ' ' + N'Nisan' 
    AS TahminiTeslimat,

    --------------------------------------------------
    -- 🚨 GECİKMİŞ Mİ (MOCK'A GÖRE)
    --------------------------------------------------
    CASE 
        WHEN DATEFROMPARTS(2026,4,1) < GETDATE() THEN 1
        ELSE 0
    END AS IsOverdue,

    LTRIM(RTRIM(
        COALESCE(c.Name, '') + ' ' + COALESCE(c.LastName, '')
    )) AS MusteriAdi,

    COALESCE(c.Tel, '-') AS Telefon

FROM tmscrq.TMLead l

INNER JOIN tmscrq.TMCustomer c 
    ON c.Id = l.CustomerId

INNER JOIN tmscrq.TMProduct p
    ON p.Id = l.ProductId

INNER JOIN tmscrq.TMLeadProcess lp 
    ON lp.Id = l.ProcessID

LEFT JOIN tmscrq.TMUser tu 
    ON tu.KUserID = l.CreatedBy

LEFT JOIN tmscrq.TMStore st 
    ON st.Id = COALESCE(l.StoreId, tu.StoreId)

WHERE 
    st.StoreCode = @StoreCode
    AND lp.Code = 'APPROVED'
    AND p.ProductCode = @ProductCode

ORDER BY 
    l.CreatedAt DESC;", new string[] { "LeadId", "LeadCode", "TahminiTeslimat", "IsOverdue", "MusteriAdi", "Telefon" }, prms_TM_GetLeadsByProductAndStore_0.ToArray());
            ;


            return Ok(result);
        }


        [HttpPost, Route("ProductDistributionComponent_530875_onActive")]
        public IActionResult ProductDistributionComponent_530875_onActive(ProductDistributionComponent_530875_onActive_Request request)
        {

            var result = new ProductDistributionComponent_530875_onActive_Response();

            var prms_TM_GetLeadsByProductAndStore_0 = new List<kSqlParameter>();
            prms_TM_GetLeadsByProductAndStore_0.Add(new kSqlParameter() { Name = "StoreCode", Value = "005".ConvertToType<String>() });
            prms_TM_GetLeadsByProductAndStore_0.Add(new kSqlParameter() { Name = "ProductCode", Value = request.ProductCode_0 });
            using var auditTM_GetLeadsByProductAndStore_0 = ActionAuditScope.Begin("7f418663-3754-b94f-31a3-c0993cdf7f50", "TM_GetLeadsByProductAndStore", applicationName: "wbTimesCRM", screenOrEndpointName: "ProductDistribution");
            result.TM_GetLeadsByProductAndStore = KPersister.Fetch(KContext.GetConnectionString(), @"SELECT 
    l.Id AS LeadId,
    l.LeadCode,

    --------------------------------------------------
    -- 🔥 TERMIN (MOCK NİSAN 2026)
    --------------------------------------------------
    FORMAT(DATEFROMPARTS(2026,4,1), 'yyyy') + ' ' + N'Nisan' 
    AS TahminiTeslimat,

    --------------------------------------------------
    -- 🚨 GECİKMİŞ Mİ (MOCK'A GÖRE)
    --------------------------------------------------
    CASE 
        WHEN DATEFROMPARTS(2026,4,1) < GETDATE() THEN 1
        ELSE 0
    END AS IsOverdue,

    LTRIM(RTRIM(
        COALESCE(c.Name, '') + ' ' + COALESCE(c.LastName, '')
    )) AS MusteriAdi,

    COALESCE(c.Tel, '-') AS Telefon

FROM tmscrq.TMLead l

INNER JOIN tmscrq.TMCustomer c 
    ON c.Id = l.CustomerId

INNER JOIN tmscrq.TMProduct p
    ON p.Id = l.ProductId

INNER JOIN tmscrq.TMLeadProcess lp 
    ON lp.Id = l.ProcessID

LEFT JOIN tmscrq.TMUser tu 
    ON tu.KUserID = l.CreatedBy

LEFT JOIN tmscrq.TMStore st 
    ON st.Id = COALESCE(l.StoreId, tu.StoreId)

WHERE 
    st.StoreCode = @StoreCode
    AND lp.Code = 'APPROVED'
    AND p.ProductCode = @ProductCode

ORDER BY 
    l.CreatedAt DESC;", new string[] { "LeadId", "LeadCode", "TahminiTeslimat", "IsOverdue", "MusteriAdi", "Telefon" }, prms_TM_GetLeadsByProductAndStore_0.ToArray());
            ;


            return Ok(result);
        }


        [HttpPost, Route("ProductDistributionComponent_439903_onActive")]
        public IActionResult ProductDistributionComponent_439903_onActive(ProductDistributionComponent_439903_onActive_Request request)
        {

            var result = new ProductDistributionComponent_439903_onActive_Response();

            var prms_TM_GetLeadsByProductAndStore_0 = new List<kSqlParameter>();
            prms_TM_GetLeadsByProductAndStore_0.Add(new kSqlParameter() { Name = "StoreCode", Value = "003".ConvertToType<String>() });
            prms_TM_GetLeadsByProductAndStore_0.Add(new kSqlParameter() { Name = "ProductCode", Value = request.ProductCode_0 });
            using var auditTM_GetLeadsByProductAndStore_0 = ActionAuditScope.Begin("d87e3586-494d-3138-5798-cb6d87e24f91", "TM_GetLeadsByProductAndStore", applicationName: "wbTimesCRM", screenOrEndpointName: "ProductDistribution");
            result.TM_GetLeadsByProductAndStore = KPersister.Fetch(KContext.GetConnectionString(), @"SELECT 
    l.Id AS LeadId,
    l.LeadCode,

    --------------------------------------------------
    -- 🔥 TERMIN (MOCK NİSAN 2026)
    --------------------------------------------------
    FORMAT(DATEFROMPARTS(2026,4,1), 'yyyy') + ' ' + N'Nisan' 
    AS TahminiTeslimat,

    --------------------------------------------------
    -- 🚨 GECİKMİŞ Mİ (MOCK'A GÖRE)
    --------------------------------------------------
    CASE 
        WHEN DATEFROMPARTS(2026,4,1) < GETDATE() THEN 1
        ELSE 0
    END AS IsOverdue,

    LTRIM(RTRIM(
        COALESCE(c.Name, '') + ' ' + COALESCE(c.LastName, '')
    )) AS MusteriAdi,

    COALESCE(c.Tel, '-') AS Telefon

FROM tmscrq.TMLead l

INNER JOIN tmscrq.TMCustomer c 
    ON c.Id = l.CustomerId

INNER JOIN tmscrq.TMProduct p
    ON p.Id = l.ProductId

INNER JOIN tmscrq.TMLeadProcess lp 
    ON lp.Id = l.ProcessID

LEFT JOIN tmscrq.TMUser tu 
    ON tu.KUserID = l.CreatedBy

LEFT JOIN tmscrq.TMStore st 
    ON st.Id = COALESCE(l.StoreId, tu.StoreId)

WHERE 
    st.StoreCode = @StoreCode
    AND lp.Code = 'APPROVED'
    AND p.ProductCode = @ProductCode

ORDER BY 
    l.CreatedAt DESC;", new string[] { "LeadId", "LeadCode", "TahminiTeslimat", "IsOverdue", "MusteriAdi", "Telefon" }, prms_TM_GetLeadsByProductAndStore_0.ToArray());
            ;


            return Ok(result);
        }


        [HttpPost, Route("ProductDistributionComponent_925270_onActive")]
        public IActionResult ProductDistributionComponent_925270_onActive(ProductDistributionComponent_925270_onActive_Request request)
        {

            var result = new ProductDistributionComponent_925270_onActive_Response();

            var prms_TM_GetLeadsByProductAndStore_0 = new List<kSqlParameter>();
            prms_TM_GetLeadsByProductAndStore_0.Add(new kSqlParameter() { Name = "StoreCode", Value = "002".ConvertToType<String>() });
            prms_TM_GetLeadsByProductAndStore_0.Add(new kSqlParameter() { Name = "ProductCode", Value = request.ProductCode_0 });
            using var auditTM_GetLeadsByProductAndStore_0 = ActionAuditScope.Begin("ab287ee3-f22c-f148-6815-0a7577e40e26", "TM_GetLeadsByProductAndStore", applicationName: "wbTimesCRM", screenOrEndpointName: "ProductDistribution");
            result.TM_GetLeadsByProductAndStore = KPersister.Fetch(KContext.GetConnectionString(), @"SELECT 
    l.Id AS LeadId,
    l.LeadCode,

    --------------------------------------------------
    -- 🔥 TERMIN (MOCK NİSAN 2026)
    --------------------------------------------------
    FORMAT(DATEFROMPARTS(2026,4,1), 'yyyy') + ' ' + N'Nisan' 
    AS TahminiTeslimat,

    --------------------------------------------------
    -- 🚨 GECİKMİŞ Mİ (MOCK'A GÖRE)
    --------------------------------------------------
    CASE 
        WHEN DATEFROMPARTS(2026,4,1) < GETDATE() THEN 1
        ELSE 0
    END AS IsOverdue,

    LTRIM(RTRIM(
        COALESCE(c.Name, '') + ' ' + COALESCE(c.LastName, '')
    )) AS MusteriAdi,

    COALESCE(c.Tel, '-') AS Telefon

FROM tmscrq.TMLead l

INNER JOIN tmscrq.TMCustomer c 
    ON c.Id = l.CustomerId

INNER JOIN tmscrq.TMProduct p
    ON p.Id = l.ProductId

INNER JOIN tmscrq.TMLeadProcess lp 
    ON lp.Id = l.ProcessID

LEFT JOIN tmscrq.TMUser tu 
    ON tu.KUserID = l.CreatedBy

LEFT JOIN tmscrq.TMStore st 
    ON st.Id = COALESCE(l.StoreId, tu.StoreId)

WHERE 
    st.StoreCode = @StoreCode
    AND lp.Code = 'APPROVED'
    AND p.ProductCode = @ProductCode

ORDER BY 
    l.CreatedAt DESC;", new string[] { "LeadId", "LeadCode", "TahminiTeslimat", "IsOverdue", "MusteriAdi", "Telefon" }, prms_TM_GetLeadsByProductAndStore_0.ToArray());
            ;


            return Ok(result);
        }


        [HttpPost, Route("ProductDistributionComponent_859573_onBlur")]
        public IActionResult ProductDistributionComponent_859573_onBlur(ProductDistributionComponent_859573_onBlur_Request request)
        {

            var result = new ProductDistributionComponent_859573_onBlur_Response();

            var prms_TM_UpdateDraftQuantity_0 = new List<kSqlParameter>();
            prms_TM_UpdateDraftQuantity_0.Add(new kSqlParameter() { Name = "StoreCode", Value = request.StoreCode_0 });
            prms_TM_UpdateDraftQuantity_0.Add(new kSqlParameter() { Name = "Quantity", Value = request.Quantity_0 });
            using var auditTM_UpdateDraftQuantity_0 = ActionAuditScope.Begin("0c4f7a4c-1f90-15aa-213b-76bef47f90c3", "TM_UpdateDraftQuantity", applicationName: "wbTimesCRM", screenOrEndpointName: "ProductDistribution");
            result.TM_UpdateDraftQuantity = KPersister.Fetch(KContext.GetConnectionString(), @"DECLARE @Success INT = 0;
DECLARE @Message NVARCHAR(200) = '';

-- 🔥 FIX
DECLARE @StoreCodeOut NVARCHAR(50) = @StoreCode;
DECLARE @QuantityOut INT = @Quantity;

BEGIN TRY

    --------------------------------------------------
    -- 🔥 KAYIT VAR MI?
    --------------------------------------------------
    IF NOT EXISTS (
        SELECT 1
        FROM tmscrq.TMDistributionDraft
        WHERE StoreCode = @StoreCode
    )
    BEGIN
        SET @Success = 0;
        SET @Message = N'Mağaza kaydı draft tablosunda bulunamadı.';
    END
    ELSE
    BEGIN

        --------------------------------------------------
        -- 🔥 UPDATE
        --------------------------------------------------
        UPDATE tmscrq.TMDistributionDraft
        SET Quantity = @Quantity
        WHERE StoreCode = @StoreCode;

        SET @Success = 1;
        SET @Message = N'Miktar başarıyla güncellendi.';
    END

END TRY
BEGIN CATCH
    SET @Success = 0;
    SET @Message = ERROR_MESSAGE();
END CATCH;

--------------------------------------------------
-- 🔥 TEK SELECT (FIXED)
--------------------------------------------------
SELECT 
    @Success AS Success,
    @Message AS Message,
    @StoreCodeOut AS StoreCode,
    @QuantityOut AS UpdatedQuantity;", new string[] { "Success", "Message", "StoreCode", "UpdatedQuantity" }, prms_TM_UpdateDraftQuantity_0.ToArray());
            ;


            return Ok(result);
        }


        [HttpPost, Route("ProductDistributionComponent_642149_onClick")]
        public IActionResult ProductDistributionComponent_642149_onClick(ProductDistributionComponent_642149_onClick_Request request)
        {

            var result = new ProductDistributionComponent_642149_onClick_Response();

            var prms_TM_UpsertDistributionPool_0 = new List<kSqlParameter>();
            prms_TM_UpsertDistributionPool_0.Add(new kSqlParameter() { Name = "HeaderId", Value = request.HeaderId_0 });
            prms_TM_UpsertDistributionPool_0.Add(new kSqlParameter() { Name = "ProductCode", Value = request.ProductCode_0 });
            prms_TM_UpsertDistributionPool_0.Add(new kSqlParameter() { Name = "UserId", Value = Kuika.Common.KContext.CurrentUser?.Id });
            using var auditTM_UpsertDistributionPool_0 = ActionAuditScope.Begin("8b9a0b44-a645-3e59-065c-df217673af42", "TM_UpsertDistributionPool", applicationName: "wbTimesCRM", screenOrEndpointName: "ProductDistribution");
            result.TM_UpsertDistributionPool = KPersister.Fetch(KContext.GetConnectionString(), @"DECLARE @Success INT = 0;
DECLARE @Message NVARCHAR(200) = '';

DECLARE @ImportQuantity INT = 0;
DECLARE @DraftTotal INT = 0;

BEGIN TRY

    --------------------------------------------------
    -- 🔥 HEADER VAR MI?
    --------------------------------------------------
    IF NOT EXISTS (
        SELECT 1 
        FROM tmscrq.TMImportHeader
        WHERE HeaderID = @HeaderId
    )
    BEGIN
        SET @Success = 0;
        SET @Message = N'Geçersiz HeaderId gönderildi.';
    END
    ELSE
    BEGIN

        --------------------------------------------------
        -- 🔥 IMPORT QUANTITY
        --------------------------------------------------
        SELECT @ImportQuantity = ISNULL(SUM(Quantity),0)
        FROM tmscrq.TMImportLine
        WHERE 
            HeaderID = @HeaderId
            AND ItemCode = @ProductCode;

        IF @ImportQuantity = 0
        BEGIN
            SET @Success = 0;
            SET @Message = N'İthalat satırı bulunamadı.';
        END
        ELSE
        BEGIN

            --------------------------------------------------
            -- 🔥 DRAFT TOPLAM
            --------------------------------------------------
            SELECT @DraftTotal = ISNULL(SUM(Quantity),0)
            FROM tmscrq.TMDistributionDraft;

            --------------------------------------------------
            -- 🔥 EŞİTLİK KONTROLÜ
            --------------------------------------------------
            IF @DraftTotal <> @ImportQuantity
            BEGIN
                SET @Success = 0;
                SET @Message = 
                    N'Dağıtım toplamı ithalat miktarına eşit olmalıdır. '
                    + N'İthalat: ' + CAST(@ImportQuantity AS NVARCHAR)
                    + N' / Dağıtım: ' + CAST(@DraftTotal AS NVARCHAR);
            END
            ELSE
            BEGIN

                --------------------------------------------------
                -- 🔥 UPSERT (DUPLICATE ENGELLE)
                --------------------------------------------------
                MERGE tmscrq.TMDistributionPool AS target
                USING (
                    SELECT 
                        d.StoreCode,
                        d.Quantity
                    FROM tmscrq.TMDistributionDraft d
                    WHERE d.Quantity > 0
                ) AS source
                ON 
                    target.HeaderId = @HeaderId
                    AND target.ProductCode = @ProductCode
                    AND target.TargetStoreCode = source.StoreCode

                WHEN MATCHED THEN
                    UPDATE SET 
                        target.Quantity = source.Quantity,
                        target.CreatedAt = SYSDATETIMEOFFSET(),
                        target.CreatedBy = @UserId

                WHEN NOT MATCHED THEN
                    INSERT
                    (
                        Id,
                        CreatedAt,
                        CreatedBy,
                        HeaderId,
                        ProductCode,
                        Quantity,
                        TargetStoreCode
                    )
                    VALUES
                    (
                        NEWID(),
                        SYSDATETIMEOFFSET(),
                        @UserId,
                        @HeaderId,
                        @ProductCode,
                        source.Quantity,
                        source.StoreCode
                    );

                --------------------------------------------------
                -- 🔥 DRAFT RESET
                --------------------------------------------------
                UPDATE tmscrq.TMDistributionDraft
                SET Quantity = 0;

                --------------------------------------------------
                -- 🔥 SUCCESS
                --------------------------------------------------
                SET @Success = 1;
                SET @Message = N'Dağıtım başarıyla oluşturuldu.';
            END
        END
    END

END TRY
BEGIN CATCH
    SET @Success = 0;
    SET @Message = ERROR_MESSAGE();
END CATCH;

--------------------------------------------------
-- 🔥 TEK SELECT
--------------------------------------------------
SELECT 
    @Success AS Success,
    @Message AS Message,
    @ImportQuantity AS ImportQuantity,
    @DraftTotal AS DraftTotal,
    (@ImportQuantity - @DraftTotal) AS Difference;", new string[] { "Success", "Message", "ImportQuantity", "DraftTotal", "Difference" }, prms_TM_UpsertDistributionPool_0.ToArray());
            ;


            return Ok(result);
        }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class ProductDistributionPageInit_Request
    {
        public String ProductCode_0 { set; get; }
        public String StoreCode_1 { set; get; }
        public String ProductCode_1 { set; get; }
        public String HeaderId_2 { set; get; }
        public String ProductCode_2 { set; get; }
        public String ProductCode_3 { set; get; }
        public String StoreCode_4 { set; get; }
        public String ProductCode_4 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class ProductDistributionPageInit_Response
    {
        public KCommonEntityPage TM_GetProductDetail { set; get; }

        public KCommonEntityPage TM_GetLeadsByProductAndStore { set; get; }

        public KCommonEntityPage TM_GetImportVsApprovedLeadSummary { set; get; }

        public KCommonEntityPage TM_GetProductStockByStoreExceptSelected { set; get; }

        public KCommonEntityPage TM_GetDistributionDraft { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class ProductDistributionComponent_787660_onChange_Request
    {
        public String StoreCode_0 { set; get; }
        public String ProductCode_0 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class ProductDistributionComponent_787660_onChange_Response
    {
        public KCommonEntityPage TM_GetLeadsByProductAndStore { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class ProductDistributionComponent_543048_onActive_Request
    {
        public String StoreCode_0 { set; get; }
        public String ProductCode_0 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class ProductDistributionComponent_543048_onActive_Response
    {
        public KCommonEntityPage TM_GetLeadsByProductAndStore { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class ProductDistributionComponent_530875_onActive_Request
    {
        public String StoreCode_0 { set; get; }
        public String ProductCode_0 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class ProductDistributionComponent_530875_onActive_Response
    {
        public KCommonEntityPage TM_GetLeadsByProductAndStore { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class ProductDistributionComponent_439903_onActive_Request
    {
        public String StoreCode_0 { set; get; }
        public String ProductCode_0 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class ProductDistributionComponent_439903_onActive_Response
    {
        public KCommonEntityPage TM_GetLeadsByProductAndStore { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class ProductDistributionComponent_925270_onActive_Request
    {
        public String StoreCode_0 { set; get; }
        public String ProductCode_0 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class ProductDistributionComponent_925270_onActive_Response
    {
        public KCommonEntityPage TM_GetLeadsByProductAndStore { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class ProductDistributionComponent_859573_onBlur_Request
    {
        public String StoreCode_0 { set; get; }
        public Int32? Quantity_0 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class ProductDistributionComponent_859573_onBlur_Response
    {
        public KCommonEntityPage TM_UpdateDraftQuantity { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class ProductDistributionComponent_642149_onClick_Request
    {
        public String HeaderId_0 { set; get; }
        public String ProductCode_0 { set; get; }
        public Guid? UserId_0 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class ProductDistributionComponent_642149_onClick_Response
    {
        public KCommonEntityPage TM_UpsertDistributionPool { set; get; }

    }
}
