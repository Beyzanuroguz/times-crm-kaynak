
using Kuika.Common;
using Kuika.Common.Attributes;
using Kuika.Common.Bases;
using Kuika.Common.Enums;
using Kuika.Common.Accessors;
using Kuika.Common.Json;
using Kuika.Common.Classes;
using Kuika.Common.Exceptions;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Kuika.Common.Helpers;
using Kuika.Common.Settings;
using System.Collections.Generic;
using System;
using Kuika.Common.Extensions;
using System.Linq;
using Kuika.Common.Rest;
using WorkflowCore.Interface;
using Kuika.Common.Interfaces;
using Kuika.Common.Workflow;
using Kuika.Common.Workflow.Extensions;
using Kuika.Common.Workflow.DTOs;
using Kuika.Common.Models;
using Kuika.Common.Menu.Response;
using Kuika.Common.Entities;
using System.Reflection;
using Newtonsoft.Json.Linq;
using Newtonsoft.Json;
using System.Net.Http;
using Iyzipay.Model.V2.Subscription;
using Kuika.Common.Payments.Iyzico;
using Kuika.Common.Payments.Param;
using Iyzipay;
using Kuika.Common.Searching.DTOs;
using Kuika.Common.Helpers.Sap;
using Kuika.Common.Mcp;
using Kuika.Common.Vision.DTOs;
using Kuika.Common.Audit;
using Kuika.Common.Payments.Mobile;
using Kuika.ThirdPartyApisCollection;

namespace Kuika.Reslen_01.Api
{
    [ApiExplorerSettings(GroupName = "all")]
    [Authorize]
    [ApiController]
    [Route("v1/api/OrderList")]
    public class OrderList_Controller : KControllerBase
    {
        private string appName = "wbTimesCRM";
        private Guid appId = Guid.Parse("0e8ecb48-8c52-463c-5db5-08de3ec441b1");
        private static string screenName = "OrderList";
        private Guid screenId = Guid.Parse("0ec4cdfe-dcf6-4ddd-a90b-3eb310d8fc35");
        private string connectionString { get { return Kuika.Common.KContext.GetConnectionString(); } }

        [HttpGet, Route("myroles")]
        public IActionResult GetMyRoles()
        {
            try
            {
                var result = KProviderManager.Authorization.GetMyRoles(appId, appName, screenId, screenName);
                return Ok(result);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new HttpExceptionDto() { Message = ex.Message, StackTrace = ex.StackTrace });
            }
        }


        [HttpPost, Route("OrderListComponent_632278_onChange")]
        public IActionResult OrderListComponent_632278_onChange(OrderListComponent_632278_onChange_Request request)
        {

            KProviderManager.Authorization.IsAuthorizedForRoles(appId, appName, screenId, screenName, new List<string> { $"cdb536b0-6297-155f-d446-8453d8a60304", "4da1f213-c8e4-0b50-5c84-02fd13f1a622", "b4bfd39c-ac02-f442-c899-7a2374a45b47", "70de6cfc-6087-6059-59b4-0b5a8527af6b", "c4e882ef-977d-f613-7694-230ac83919d2", "TimesYonetici", "TimesUstYonetici", "TimesSatisPersoneli", "TimesMagazaMuduru", "TimesAdmin" });

            var result = new OrderListComponent_632278_onChange_Response();

            var prms_TM_GetAllCustomer_0 = new List<kSqlParameter>();
            prms_TM_GetAllCustomer_0.Add(new kSqlParameter() { Name = "Ad", Value = request.Ad_0 });
            prms_TM_GetAllCustomer_0.Add(new kSqlParameter() { Name = "CurrAccCode", Value = request.CurrAccCode_0 });
            prms_TM_GetAllCustomer_0.Add(new kSqlParameter() { Name = "NationalID", Value = request.NationalID_0 });
            prms_TM_GetAllCustomer_0.Add(new kSqlParameter() { Name = "Tel", Value = request.Tel_0 });
            prms_TM_GetAllCustomer_0.Add(new kSqlParameter() { Name = "Email", Value = string.Empty });
            prms_TM_GetAllCustomer_0.Add(new kSqlParameter() { Name = "Location", Value = string.Empty });
            prms_TM_GetAllCustomer_0.Add(new kSqlParameter() { Name = "IsShopping", Value = request.IsShopping_0 });
            using var auditTM_GetAllCustomer_0 = ActionAuditScope.Begin("8b3b20b0-6314-a901-877e-df4c2b9e3399", "TM_GetAllCustomer", applicationName: "wbTimesCRM", screenOrEndpointName: "OrderList");
            result.TM_GetAllCustomer = KPersister.Fetch(KContext.GetConnectionString(), @"-- ============================================================
-- DT-047 · TM_GetAllCustomer — GUNCEL HALI
-- Ekran: OrderList — Siparis Listesi
--
-- UI response kolonlari degismedi.
-- CurrAccDescription sadece:
--   1) Name fallback
--   2) isim kalite filtresi
--   3) Ad arama filtresi
--   4) siralama
-- icin kullaniliyor.
-- ============================================================

-- PARAM TEMİZLEME
SET @Ad = NULLIF(LTRIM(RTRIM(@Ad)), '');
SET @CurrAccCode = NULLIF(LTRIM(RTRIM(@CurrAccCode)), '');
SET @NationalID = NULLIF(LTRIM(RTRIM(@NationalID)), '');
SET @Tel = NULLIF(LTRIM(RTRIM(@Tel)), '');
SET @Email = NULLIF(LTRIM(RTRIM(@Email)), '');
SET @Location = NULLIF(LTRIM(RTRIM(@Location)), '');

--------------------------------------------------
-- IsShopping FIX (string → bit)
--------------------------------------------------
DECLARE @IsShoppingBit BIT = NULL;

SET @IsShoppingBit = 
    CASE 
        WHEN @IsShopping = '1' THEN 1
        WHEN @IsShopping = '0' THEN 0
        ELSE NULL
    END;

--------------------------------------------------
-- SELECT
--------------------------------------------------
SELECT
    c.Id AS CustomerId,

    --------------------------------------------------
    -- Name
    -- Name + LastName bos ise CurrAccDescription fallback
    --------------------------------------------------
    CASE
        WHEN NULLIF(
            LTRIM(RTRIM(
                ISNULL(c.Name, '') +
                CASE
                    WHEN c.LastName IS NOT NULL
                         AND LTRIM(RTRIM(c.LastName)) <> ''
                    THEN ' ' + LTRIM(RTRIM(c.LastName))
                    ELSE ''
                END
            )),
            ''
        ) IS NOT NULL
        THEN
            LTRIM(RTRIM(
                ISNULL(c.Name, '') +
                CASE
                    WHEN c.LastName IS NOT NULL
                         AND LTRIM(RTRIM(c.LastName)) <> ''
                    THEN ' ' + LTRIM(RTRIM(c.LastName))
                    ELSE ''
                END
            ))

        WHEN NULLIF(LTRIM(RTRIM(c.CurrAccDescription)), '') IS NOT NULL
        THEN LTRIM(RTRIM(c.CurrAccDescription))

        ELSE '-'
    END AS Name,

    CASE
        WHEN ISNULL(LTRIM(RTRIM(c.LastName)), '') = ''
        THEN '-'
        ELSE LTRIM(RTRIM(c.LastName))
    END AS LastName,

    CASE
        WHEN ISNULL(LTRIM(RTRIM(c.Email)), '') = ''
        THEN '-'
        ELSE LTRIM(RTRIM(c.Email))
    END AS Email,

    CASE
        WHEN ISNULL(LTRIM(RTRIM(c.Tel)), '') = ''
        THEN '-'
        ELSE LTRIM(RTRIM(c.Tel))
    END AS Tel,

    CASE
        WHEN ISNULL(LTRIM(RTRIM(c.Info)), '') = ''
        THEN '-'
        ELSE LTRIM(RTRIM(c.Info))
    END AS Info,

    CASE
        WHEN ISNULL(LTRIM(RTRIM(c.CurrAccCode)), '') = ''
        THEN '-'
        ELSE LTRIM(RTRIM(c.CurrAccCode))
    END AS CurrAccCode,

    CASE
        WHEN ISNULL(LTRIM(RTRIM(c.NationalID)), '') = ''
        THEN '-'
        ELSE LTRIM(RTRIM(c.NationalID))
    END AS NationalID,

    CASE
        WHEN ISNULL(LTRIM(RTRIM(c.Address)), '') = ''
        THEN '-'
        ELSE LTRIM(RTRIM(c.Address))
    END AS Address,

    CASE
        WHEN ISNULL(LTRIM(RTRIM(c.DistrictName)), '') = ''
        THEN '-'
        ELSE LTRIM(RTRIM(c.DistrictName))
    END AS DistrictName,

    CASE
        WHEN c.IsShopping = 1 THEN N'Evet'
        ELSE N'Hayır'
    END AS IsShoppingText,

    --------------------------------------------------
    -- Location
    --------------------------------------------------
    CASE 
        WHEN 
            (c.CountryName IS NULL OR LTRIM(RTRIM(c.CountryName)) = '') 
            AND
            (c.CityName IS NULL OR LTRIM(RTRIM(c.CityName)) = '')
        THEN '-'

        WHEN c.CountryName IS NOT NULL
             AND c.CityName IS NOT NULL
        THEN
            LTRIM(RTRIM(c.CountryName))
            + ' / ' +
            LTRIM(RTRIM(c.CityName))

        WHEN c.CountryName IS NOT NULL
        THEN LTRIM(RTRIM(c.CountryName))

        WHEN c.CityName IS NOT NULL
        THEN LTRIM(RTRIM(c.CityName))

        ELSE '-'
    END AS Location

FROM tmscrq.TMCustomer c

--------------------------------------------------
-- WHERE
--------------------------------------------------
WHERE
    c.IsDeleted = 0

    --------------------------------------------------
    -- ISIM KALITE FILTRESI
    --------------------------------------------------
    AND
    (
        (
            NULLIF(
                LTRIM(RTRIM(
                    ISNULL(c.Name, '')
                    + ISNULL(c.LastName, '')
                )),
                ''
            ) IS NOT NULL

            AND LTRIM(RTRIM(ISNULL(c.Name, '')))
                NOT IN ('-', '.', '""""')

            AND LTRIM(RTRIM(ISNULL(c.Name, '')))
                <> LTRIM(RTRIM(ISNULL(c.CurrAccCode, '')))

            AND
            (
                ISNULL(c.Name, '')
                + ' '
                + ISNULL(c.LastName, '')
            ) LIKE '%[A-Za-zÇŞİÖÜĞçşıöüğ]%'
        )

        OR

        (
            NULLIF(
                LTRIM(RTRIM(c.CurrAccDescription)),
                ''
            ) IS NOT NULL

            AND LTRIM(RTRIM(c.CurrAccDescription))
                NOT IN ('-', '.', '""""')

            AND LTRIM(RTRIM(c.CurrAccDescription))
                <> LTRIM(RTRIM(ISNULL(c.CurrAccCode, '')))

            AND c.CurrAccDescription
                LIKE '%[A-Za-zÇŞİÖÜĞçşıöüğ]%'
        )
    )

    --------------------------------------------------
    -- AD FILTRESI
    --------------------------------------------------
    AND
    (
        @Ad IS NULL 
        OR
        (
            (ISNULL(c.Name, '') + ' ' + ISNULL(c.LastName, ''))
                LIKE '%' + @Ad + '%'

            OR c.Name
                LIKE '%' + @Ad + '%'

            OR c.LastName
                LIKE '%' + @Ad + '%'

            OR c.CurrAccDescription
                LIKE '%' + @Ad + '%'
        )
    )

    AND
    (
        @CurrAccCode IS NULL
        OR c.CurrAccCode LIKE '%' + @CurrAccCode + '%'
    )

    AND
    (
        @NationalID IS NULL
        OR c.NationalID LIKE '%' + @NationalID + '%'
    )

    AND
    (
        @Tel IS NULL
        OR c.Tel LIKE '%' + @Tel + '%'
    )

    AND
    (
        @IsShoppingBit IS NULL
        OR c.IsShopping = @IsShoppingBit
    )

    AND
    (
        @Email IS NULL
        OR c.Email LIKE '%' + @Email + '%'
    )

    --------------------------------------------------
    -- Location FILTER
    --------------------------------------------------
    AND
    (
        @Location IS NULL
        OR
        (
            ISNULL(c.CountryName, '')
                LIKE '%' + @Location + '%'

            OR ISNULL(c.CityName, '')
                LIKE '%' + @Location + '%'

            OR
            (
                ISNULL(c.CountryName, '')
                + ' '
                + ISNULL(c.CityName, '')
            ) LIKE '%' + @Location + '%'
        )
    )

--------------------------------------------------
-- ORDER
--------------------------------------------------
ORDER BY
    CASE
        WHEN c.IsShopping = 1 THEN 0
        ELSE 1
    END,

    COALESCE(
        NULLIF(
            LTRIM(RTRIM(
                ISNULL(c.Name, '')
                + ' '
                + ISNULL(c.LastName, '')
            )),
            ''
        ),
        NULLIF(
            LTRIM(RTRIM(c.CurrAccDescription)),
            ''
        )
    ) ASC,

    c.Id ASC;", new string[] { "CustomerId", "Name", "LastName", "Email", "Tel", "Info", "CurrAccCode", "NationalID", "Address", "DistrictName", "IsShoppingText", "Location" }, prms_TM_GetAllCustomer_0.ToArray());
            ;


            return Ok(result);
        }


        [HttpPost, Route("OrderListComponent_877365_onClick1_")]
        public IActionResult OrderListComponent_877365_onClick1_(OrderListComponent_877365_onClick1__Request request)
        {

            KProviderManager.Authorization.IsAuthorizedForRoles(appId, appName, screenId, screenName, new List<string> { $"cdb536b0-6297-155f-d446-8453d8a60304", "4da1f213-c8e4-0b50-5c84-02fd13f1a622", "b4bfd39c-ac02-f442-c899-7a2374a45b47", "70de6cfc-6087-6059-59b4-0b5a8527af6b", "c4e882ef-977d-f613-7694-230ac83919d2", "TimesYonetici", "TimesUstYonetici", "TimesSatisPersoneli", "TimesMagazaMuduru", "TimesAdmin" });

            var result = new OrderListComponent_877365_onClick1__Response();

            var prms_TM_GetAllCustomer_0 = new List<kSqlParameter>();
            prms_TM_GetAllCustomer_0.Add(new kSqlParameter() { Name = "Ad", Value = string.Empty });
            prms_TM_GetAllCustomer_0.Add(new kSqlParameter() { Name = "CurrAccCode", Value = string.Empty });
            prms_TM_GetAllCustomer_0.Add(new kSqlParameter() { Name = "NationalID", Value = string.Empty });
            prms_TM_GetAllCustomer_0.Add(new kSqlParameter() { Name = "Tel", Value = string.Empty });
            prms_TM_GetAllCustomer_0.Add(new kSqlParameter() { Name = "Email", Value = string.Empty });
            prms_TM_GetAllCustomer_0.Add(new kSqlParameter() { Name = "Location", Value = string.Empty });
            prms_TM_GetAllCustomer_0.Add(new kSqlParameter() { Name = "IsShopping", Value = string.Empty });
            using var auditTM_GetAllCustomer_0 = ActionAuditScope.Begin("98f1c191-5eaf-11a1-c283-2b6604eb41f2", "TM_GetAllCustomer", applicationName: "wbTimesCRM", screenOrEndpointName: "OrderList");
            result.TM_GetAllCustomer = KPersister.Fetch(KContext.GetConnectionString(), @"-- ============================================================
-- DT-047 · TM_GetAllCustomer — GUNCEL HALI
-- Ekran: OrderList — Siparis Listesi
--
-- UI response kolonlari degismedi.
-- CurrAccDescription sadece:
--   1) Name fallback
--   2) isim kalite filtresi
--   3) Ad arama filtresi
--   4) siralama
-- icin kullaniliyor.
-- ============================================================

-- PARAM TEMİZLEME
SET @Ad = NULLIF(LTRIM(RTRIM(@Ad)), '');
SET @CurrAccCode = NULLIF(LTRIM(RTRIM(@CurrAccCode)), '');
SET @NationalID = NULLIF(LTRIM(RTRIM(@NationalID)), '');
SET @Tel = NULLIF(LTRIM(RTRIM(@Tel)), '');
SET @Email = NULLIF(LTRIM(RTRIM(@Email)), '');
SET @Location = NULLIF(LTRIM(RTRIM(@Location)), '');

--------------------------------------------------
-- IsShopping FIX (string → bit)
--------------------------------------------------
DECLARE @IsShoppingBit BIT = NULL;

SET @IsShoppingBit = 
    CASE 
        WHEN @IsShopping = '1' THEN 1
        WHEN @IsShopping = '0' THEN 0
        ELSE NULL
    END;

--------------------------------------------------
-- SELECT
--------------------------------------------------
SELECT
    c.Id AS CustomerId,

    --------------------------------------------------
    -- Name
    -- Name + LastName bos ise CurrAccDescription fallback
    --------------------------------------------------
    CASE
        WHEN NULLIF(
            LTRIM(RTRIM(
                ISNULL(c.Name, '') +
                CASE
                    WHEN c.LastName IS NOT NULL
                         AND LTRIM(RTRIM(c.LastName)) <> ''
                    THEN ' ' + LTRIM(RTRIM(c.LastName))
                    ELSE ''
                END
            )),
            ''
        ) IS NOT NULL
        THEN
            LTRIM(RTRIM(
                ISNULL(c.Name, '') +
                CASE
                    WHEN c.LastName IS NOT NULL
                         AND LTRIM(RTRIM(c.LastName)) <> ''
                    THEN ' ' + LTRIM(RTRIM(c.LastName))
                    ELSE ''
                END
            ))

        WHEN NULLIF(LTRIM(RTRIM(c.CurrAccDescription)), '') IS NOT NULL
        THEN LTRIM(RTRIM(c.CurrAccDescription))

        ELSE '-'
    END AS Name,

    CASE
        WHEN ISNULL(LTRIM(RTRIM(c.LastName)), '') = ''
        THEN '-'
        ELSE LTRIM(RTRIM(c.LastName))
    END AS LastName,

    CASE
        WHEN ISNULL(LTRIM(RTRIM(c.Email)), '') = ''
        THEN '-'
        ELSE LTRIM(RTRIM(c.Email))
    END AS Email,

    CASE
        WHEN ISNULL(LTRIM(RTRIM(c.Tel)), '') = ''
        THEN '-'
        ELSE LTRIM(RTRIM(c.Tel))
    END AS Tel,

    CASE
        WHEN ISNULL(LTRIM(RTRIM(c.Info)), '') = ''
        THEN '-'
        ELSE LTRIM(RTRIM(c.Info))
    END AS Info,

    CASE
        WHEN ISNULL(LTRIM(RTRIM(c.CurrAccCode)), '') = ''
        THEN '-'
        ELSE LTRIM(RTRIM(c.CurrAccCode))
    END AS CurrAccCode,

    CASE
        WHEN ISNULL(LTRIM(RTRIM(c.NationalID)), '') = ''
        THEN '-'
        ELSE LTRIM(RTRIM(c.NationalID))
    END AS NationalID,

    CASE
        WHEN ISNULL(LTRIM(RTRIM(c.Address)), '') = ''
        THEN '-'
        ELSE LTRIM(RTRIM(c.Address))
    END AS Address,

    CASE
        WHEN ISNULL(LTRIM(RTRIM(c.DistrictName)), '') = ''
        THEN '-'
        ELSE LTRIM(RTRIM(c.DistrictName))
    END AS DistrictName,

    CASE
        WHEN c.IsShopping = 1 THEN N'Evet'
        ELSE N'Hayır'
    END AS IsShoppingText,

    --------------------------------------------------
    -- Location
    --------------------------------------------------
    CASE 
        WHEN 
            (c.CountryName IS NULL OR LTRIM(RTRIM(c.CountryName)) = '') 
            AND
            (c.CityName IS NULL OR LTRIM(RTRIM(c.CityName)) = '')
        THEN '-'

        WHEN c.CountryName IS NOT NULL
             AND c.CityName IS NOT NULL
        THEN
            LTRIM(RTRIM(c.CountryName))
            + ' / ' +
            LTRIM(RTRIM(c.CityName))

        WHEN c.CountryName IS NOT NULL
        THEN LTRIM(RTRIM(c.CountryName))

        WHEN c.CityName IS NOT NULL
        THEN LTRIM(RTRIM(c.CityName))

        ELSE '-'
    END AS Location

FROM tmscrq.TMCustomer c

--------------------------------------------------
-- WHERE
--------------------------------------------------
WHERE
    c.IsDeleted = 0

    --------------------------------------------------
    -- ISIM KALITE FILTRESI
    --------------------------------------------------
    AND
    (
        (
            NULLIF(
                LTRIM(RTRIM(
                    ISNULL(c.Name, '')
                    + ISNULL(c.LastName, '')
                )),
                ''
            ) IS NOT NULL

            AND LTRIM(RTRIM(ISNULL(c.Name, '')))
                NOT IN ('-', '.', '""""')

            AND LTRIM(RTRIM(ISNULL(c.Name, '')))
                <> LTRIM(RTRIM(ISNULL(c.CurrAccCode, '')))

            AND
            (
                ISNULL(c.Name, '')
                + ' '
                + ISNULL(c.LastName, '')
            ) LIKE '%[A-Za-zÇŞİÖÜĞçşıöüğ]%'
        )

        OR

        (
            NULLIF(
                LTRIM(RTRIM(c.CurrAccDescription)),
                ''
            ) IS NOT NULL

            AND LTRIM(RTRIM(c.CurrAccDescription))
                NOT IN ('-', '.', '""""')

            AND LTRIM(RTRIM(c.CurrAccDescription))
                <> LTRIM(RTRIM(ISNULL(c.CurrAccCode, '')))

            AND c.CurrAccDescription
                LIKE '%[A-Za-zÇŞİÖÜĞçşıöüğ]%'
        )
    )

    --------------------------------------------------
    -- AD FILTRESI
    --------------------------------------------------
    AND
    (
        @Ad IS NULL 
        OR
        (
            (ISNULL(c.Name, '') + ' ' + ISNULL(c.LastName, ''))
                LIKE '%' + @Ad + '%'

            OR c.Name
                LIKE '%' + @Ad + '%'

            OR c.LastName
                LIKE '%' + @Ad + '%'

            OR c.CurrAccDescription
                LIKE '%' + @Ad + '%'
        )
    )

    AND
    (
        @CurrAccCode IS NULL
        OR c.CurrAccCode LIKE '%' + @CurrAccCode + '%'
    )

    AND
    (
        @NationalID IS NULL
        OR c.NationalID LIKE '%' + @NationalID + '%'
    )

    AND
    (
        @Tel IS NULL
        OR c.Tel LIKE '%' + @Tel + '%'
    )

    AND
    (
        @IsShoppingBit IS NULL
        OR c.IsShopping = @IsShoppingBit
    )

    AND
    (
        @Email IS NULL
        OR c.Email LIKE '%' + @Email + '%'
    )

    --------------------------------------------------
    -- Location FILTER
    --------------------------------------------------
    AND
    (
        @Location IS NULL
        OR
        (
            ISNULL(c.CountryName, '')
                LIKE '%' + @Location + '%'

            OR ISNULL(c.CityName, '')
                LIKE '%' + @Location + '%'

            OR
            (
                ISNULL(c.CountryName, '')
                + ' '
                + ISNULL(c.CityName, '')
            ) LIKE '%' + @Location + '%'
        )
    )

--------------------------------------------------
-- ORDER
--------------------------------------------------
ORDER BY
    CASE
        WHEN c.IsShopping = 1 THEN 0
        ELSE 1
    END,

    COALESCE(
        NULLIF(
            LTRIM(RTRIM(
                ISNULL(c.Name, '')
                + ' '
                + ISNULL(c.LastName, '')
            )),
            ''
        ),
        NULLIF(
            LTRIM(RTRIM(c.CurrAccDescription)),
            ''
        )
    ) ASC,

    c.Id ASC;", new string[] { "CustomerId", "Name", "LastName", "Email", "Tel", "Info", "CurrAccCode", "NationalID", "Address", "DistrictName", "IsShoppingText", "Location" }, prms_TM_GetAllCustomer_0.ToArray());
            ;


            return Ok(result);
        }


        [HttpPost, Route("OrderListComponent_389420_onClick")]
        public IActionResult OrderListComponent_389420_onClick(OrderListComponent_389420_onClick_Request request)
        {

            KProviderManager.Authorization.IsAuthorizedForRoles(appId, appName, screenId, screenName, new List<string> { $"cdb536b0-6297-155f-d446-8453d8a60304", "4da1f213-c8e4-0b50-5c84-02fd13f1a622", "b4bfd39c-ac02-f442-c899-7a2374a45b47", "70de6cfc-6087-6059-59b4-0b5a8527af6b", "c4e882ef-977d-f613-7694-230ac83919d2", "TimesYonetici", "TimesUstYonetici", "TimesSatisPersoneli", "TimesMagazaMuduru", "TimesAdmin" });

            var result = new OrderListComponent_389420_onClick_Response();

            var prms_TM_OrderList_0 = new List<kSqlParameter>();
            prms_TM_OrderList_0.Add(new kSqlParameter() { Name = "Year", Value = request.Year_0 });
            using var auditTM_OrderList_0 = ActionAuditScope.Begin("4ded0401-c376-99d7-4b22-d5163c138489", "TM_OrderList", applicationName: "wbTimesCRM", screenOrEndpointName: "OrderList");
            result.TM_OrderList = KPersister.Fetch(KContext.GetConnectionString(), @"--------------------------------------------------
-- Parametreler
--------------------------------------------------


DECLARE @EstimatedDate NVARCHAR(30);
SET @EstimatedDate = @Year

--------------------------------------------------
-- Lead Listesi
--------------------------------------------------
SELECT
    l.Id        AS LeadId,
    l.CreatedAt,
    l.EstimatedDate,

    -- Ürün
    p.Brand,
    p.ProductCode,
    p.ProductName,

    -- Müşteri
    COALESCE(
        NULLIF(
            cu.Ad +
            CASE 
                WHEN cu.Soyad IS NOT NULL AND cu.Soyad <> '' 
                THEN ' ' + cu.Soyad 
                ELSE '' 
            END, ''
        ), '-'
    ) AS MusteriAdi,

    -- Lokasyon

    -- Lead Durumları
    lp.Name AS ProcessName,

    -- Oluşturan Kullanıcı
    COALESCE(ku.FirstName + N' ' + ku.LastName, '-') AS CreatedByUser,

    -- Mağaza
    COALESCE(NULLIF(st.StoreDesc, ''), '-') AS StoreName

FROM tmscrq.TMLead l
INNER JOIN tmscrq.TMLeadProcess lp ON lp.Id = l.ProcessID
LEFT  JOIN tmscrq.TMProductExcel p ON p.Id = l.ProductId
LEFT  JOIN tmscrq.TMCustomer cu ON cu.Id = l.CustomerId
LEFT  JOIN tmscrq.TMCity city ON city.Id = cu.CityId
LEFT  JOIN dbo.KUser ku ON ku.Id = l.CreatedBy
LEFT  JOIN tmscrq.TMUser tu ON tu.KUserID = ku.Id
LEFT  JOIN tmscrq.TMStore st ON st.Id = tu.StoreId

WHERE lp.Name = N'Onaylandı'
  AND LTRIM(RTRIM(l.EstimatedDate)) = @EstimatedDate

ORDER BY l.CreatedAt DESC;
", new string[] { "LeadId", "CreatedAt", "EstimatedDate", "Brand", "ProductCode", "ProductName", "MusteriAdi", "ProcessName", "CreatedByUser", "StoreName" }, prms_TM_OrderList_0.ToArray());
            ;


            return Ok(result);
        }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class OrderListComponent_632278_onChange_Request
    {
        public String Ad_0 { set; get; }
        public String CurrAccCode_0 { set; get; }
        public String NationalID_0 { set; get; }
        public String Tel_0 { set; get; }
        public String Email_0 { set; get; }
        public String Location_0 { set; get; }
        public String IsShopping_0 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class OrderListComponent_632278_onChange_Response
    {
        public KCommonEntityPage TM_GetAllCustomer { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class OrderListComponent_877365_onClick1__Request
    {
        public String Ad_0 { set; get; }
        public String CurrAccCode_0 { set; get; }
        public String NationalID_0 { set; get; }
        public String Tel_0 { set; get; }
        public String Email_0 { set; get; }
        public String Location_0 { set; get; }
        public String IsShopping_0 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class OrderListComponent_877365_onClick1__Response
    {
        public KCommonEntityPage TM_GetAllCustomer { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class OrderListComponent_389420_onClick_Request
    {
        public String Year_0 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class OrderListComponent_389420_onClick_Response
    {
        public KCommonEntityPage TM_OrderList { set; get; }

    }
}
