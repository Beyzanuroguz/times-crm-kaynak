
using Kuika.Common;
using Kuika.Common.Attributes;
using Kuika.Common.Bases;
using Kuika.Common.Enums;
using Kuika.Common.Accessors;
using Kuika.Common.Json;
using Kuika.Common.Classes;
using Kuika.Common.Exceptions;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Kuika.Common.Helpers;
using Kuika.Common.Settings;
using System.Collections.Generic;
using System;
using Kuika.Common.Extensions;
using System.Linq;
using Kuika.Common.Rest;
using WorkflowCore.Interface;
using Kuika.Common.Interfaces;
using Kuika.Common.Workflow;
using Kuika.Common.Workflow.Extensions;
using Kuika.Common.Workflow.DTOs;
using Kuika.Common.Models;
using Kuika.Common.Menu.Response;
using Kuika.Common.Entities;
using System.Reflection;
using Newtonsoft.Json.Linq;
using Newtonsoft.Json;
using System.Net.Http;
using Iyzipay.Model.V2.Subscription;
using Kuika.Common.Payments.Iyzico;
using Kuika.Common.Payments.Param;
using Iyzipay;
using Kuika.Common.Searching.DTOs;
using Kuika.Common.Helpers.Sap;
using Kuika.Common.Mcp;
using Kuika.Common.Vision.DTOs;
using Kuika.Common.Audit;
using Kuika.Common.Payments.Mobile;
using Kuika.ThirdPartyApisCollection;

namespace Kuika.Reslen_01.Api
{
    [ApiExplorerSettings(GroupName = "all")]
    [Authorize]
    [ApiController]
    [Route("v1/api/deneme2copy")]
    public class deneme2copy_Controller : KControllerBase
    {
        private string appName = "wbTimesCRM";
        private Guid appId = Guid.Parse("0e8ecb48-8c52-463c-5db5-08de3ec441b1");
        private static string screenName = "deneme2copy";
        private Guid screenId = Guid.Parse("09874965-a124-428f-b591-5048ddc92580");
        private string connectionString { get { return Kuika.Common.KContext.GetConnectionString(); } }

        [HttpGet, Route("myroles")]
        public IActionResult GetMyRoles()
        {
            try
            {
                var result = KProviderManager.Authorization.GetMyRoles(appId, appName, screenId, screenName);
                return Ok(result);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new HttpExceptionDto() { Message = ex.Message, StackTrace = ex.StackTrace });
            }
        }


        [HttpPost, Route("deneme2copyPageInit")]
        public IActionResult deneme2copyPageInit(deneme2copyPageInit_Request request)
        {

            KProviderManager.Authorization.IsAuthorizedForRoles(appId, appName, screenId, screenName, new List<string> { $"d6658aef-a188-d73c-9c42-e40f55e18bdb", "_SystemAdmin" });

            var result = new deneme2copyPageInit_Response();

            var prms_GetKuikTest_0 = new List<kSqlParameter>();
            using var auditGetKuikTest_0 = ActionAuditScope.Begin("3662658f-2890-fa87-4c04-fb65e6b1e9b2", "GetKuikTest", applicationName: "wbTimesCRM", screenOrEndpointName: "deneme2copy");
            result.GetKuikTest = KPersister.Fetch(KContext.GetConnectionString(), @"SELECT * FROM tmscrq.KuikTest", new string[] { "Id", "Base64Data" }, prms_GetKuikTest_0.ToArray());
            ;


            return Ok(result);
        }


        [HttpPost, Route("deneme2copyComponent_65828_onClick")]
        public IActionResult deneme2copyComponent_65828_onClick(deneme2copyComponent_65828_onClick_Request request)
        {

            KProviderManager.Authorization.IsAuthorizedForRoles(appId, appName, screenId, screenName, new List<string> { $"d6658aef-a188-d73c-9c42-e40f55e18bdb", "_SystemAdmin" });

            var result = new deneme2copyComponent_65828_onClick_Response();


            using var auditSyncProductExcel_0 = ActionAuditScope.Begin("14d746e1-4789-7c77-f13a-5f23d2bc8466", "SyncProductExcel", applicationName: "wbTimesCRM", screenOrEndpointName: "deneme2copy");
            using var actionAuditSyncProductExcel_0 = ActionAuditHelper.Begin("SyncProductExcel", null);
            try
            {
                result.SyncProductExcel = Kuika.ThirdPartyApisCollection.GetItemExcel.SyncProductExcel(connectionString);
                actionAuditSyncProductExcel_0.SetResult(result.SyncProductExcel);
            }
            catch (Exception ex)
            {
                actionAuditSyncProductExcel_0.SetException(ex);
                throw;
            }
;

            var prms_TMProductMergeUpdate_1 = new List<kSqlParameter>();
            using var auditTMProductMergeUpdate_1 = ActionAuditScope.Begin("04a987dd-66f6-d975-655d-ce81ba9a8b47", "TMProductMergeUpdate", applicationName: "wbTimesCRM", screenOrEndpointName: "deneme2copy");
            result.TMProductMergeUpdate = KPersister.Save(KContext.GetConnectionString(), @"UPDATE T
SET
    T.Bracelet     = S.Bracelet,
    T.Brand        = S.Brand,
    T.CategoryName = COALESCE(NULLIF(LTRIM(RTRIM(S.CategoryName)), ''), 'DEFAULT'),
    T.Dial         = S.Dial,
    T.ProductName  = S.ProductName,
    T.Referance    = S.Referance,
    T.RMCCode      = S.RMCCode,
    T.IsDeleted    = 0,
    T.IsInNebim    = 1
FROM tmscrq.TMProduct T
INNER JOIN tmscrq.TMProductExcel S
    ON T.ProductCode = S.ProductCode
WHERE
    ISNULL(T.Bracelet,'')     <> ISNULL(S.Bracelet,'') OR
    ISNULL(T.Brand,'')        <> ISNULL(S.Brand,'') OR
    ISNULL(T.CategoryName,'') <> ISNULL(S.CategoryName,'') OR
    ISNULL(T.Dial,'')         <> ISNULL(S.Dial,'') OR
    ISNULL(T.ProductName,'')  <> ISNULL(S.ProductName,'') OR
    ISNULL(T.Referance,'')    <> ISNULL(S.Referance,'') OR
    ISNULL(T.RMCCode,'')      <> ISNULL(S.RMCCode,'') OR
    ISNULL(T.IsDeleted, 0)    <> 0 OR
    ISNULL(T.IsInNebim, 1)    <> 1;


UPDATE tmscrq.TMProduct
SET CategoryName = 'DEFAULT'
WHERE CategoryName IS NULL OR CategoryName = '';", prms_TMProductMergeUpdate_1.ToArray());
            ;

            var prms_TMProductMergeInsert_2 = new List<kSqlParameter>();
            using var auditTMProductMergeInsert_2 = ActionAuditScope.Begin("1691e1bf-050f-5a4f-9cbe-a60ac5d19e28", "TMProductMergeInsert", applicationName: "wbTimesCRM", screenOrEndpointName: "deneme2copy");
            result.TMProductMergeInsert = KPersister.Save(KContext.GetConnectionString(), @"INSERT INTO tmscrq.TMProduct
(
    Id,
    Bracelet,
    Brand,
    CategoryName,
    Dial,
    ProductCode,
    ProductName,
    Referance,
    RMCCode,
    IsDeleted,
    IsInNebim
)
SELECT
    NEWID(),
    S.Bracelet,
    S.Brand,
    COALESCE(NULLIF(LTRIM(RTRIM(S.CategoryName)), ''), 'DEFAULT'),
    S.Dial,
    S.ProductCode,
    S.ProductName,
    S.Referance,
    S.RMCCode,
    0,
    1
FROM tmscrq.TMProductExcel S
WHERE
    S.ProductCode IS NOT NULL
    AND LTRIM(RTRIM(S.ProductCode)) <> ''
    AND NOT EXISTS
    (
        SELECT 1
        FROM tmscrq.TMProduct T
        WHERE T.ProductCode = S.ProductCode
    );", prms_TMProductMergeInsert_2.ToArray());
            ;

            var prms_TMProductMergeSoftDeleted_3 = new List<kSqlParameter>();
            using var auditTMProductMergeSoftDeleted_3 = ActionAuditScope.Begin("63315fc8-13f7-ee5c-6cc6-eda4e6237f8b", "TMProductMergeSoftDeleted", applicationName: "wbTimesCRM", screenOrEndpointName: "deneme2copy");
            result.TMProductMergeSoftDeleted = KPersister.Save(KContext.GetConnectionString(), @"UPDATE T
SET
    T.IsDeleted = 1,
    T.IsInNebim = 0
FROM tmscrq.TMProduct T
WHERE NOT EXISTS
(
    SELECT 1
    FROM tmscrq.TMProductExcel S
    WHERE S.ProductCode = T.ProductCode
)
AND
(
    ISNULL(T.IsDeleted, 0) <> 1
    OR ISNULL(T.IsInNebim, 1) <> 0
);", prms_TMProductMergeSoftDeleted_3.ToArray());
            ;


            return Ok(result);
        }


        [HttpPost, Route("deneme2copyComponent_996716_onClick")]
        public IActionResult deneme2copyComponent_996716_onClick(deneme2copyComponent_996716_onClick_Request request)
        {

            KProviderManager.Authorization.IsAuthorizedForRoles(appId, appName, screenId, screenName, new List<string> { $"d6658aef-a188-d73c-9c42-e40f55e18bdb", "_SystemAdmin" });

            var result = new deneme2copyComponent_996716_onClick_Response();


            using var auditConnect_0 = ActionAuditScope.Begin("cb00aa22-80f8-f620-07e7-9af9b091ca3d", "Connect", applicationName: "wbTimesCRM", screenOrEndpointName: "deneme2copy");
            using var actionAuditConnect_0 = ActionAuditHelper.Begin("Connect", null);
            try
            {
                Kuika.ThirdPartyApisCollection.DBConnectCsharp.Connect();
            }
            catch (Exception ex)
            {
                actionAuditConnect_0.SetException(ex);
                throw;
            }
;


            using var auditSyncCustomers_1 = ActionAuditScope.Begin("d1fbcbba-d432-3456-f2dc-c23db5ab12a9", "SyncCustomers", applicationName: "wbTimesCRM", screenOrEndpointName: "deneme2copy");
            using var actionAuditSyncCustomers_1 = ActionAuditHelper.Begin("SyncCustomers", null);
            try
            {
                result.SyncCustomers = Kuika.ThirdPartyApisCollection.GetCustomer.SyncCustomers(connectionString);
                actionAuditSyncCustomers_1.SetResult(result.SyncCustomers);
            }
            catch (Exception ex)
            {
                actionAuditSyncCustomers_1.SetException(ex);
                throw;
            }
;


            return Ok(result);
        }


        [HttpPost, Route("deneme2copyComponent_1429256652_onClick")]
        public IActionResult deneme2copyComponent_1429256652_onClick(deneme2copyComponent_1429256652_onClick_Request request)
        {

            KProviderManager.Authorization.IsAuthorizedForRoles(appId, appName, screenId, screenName, new List<string> { $"d6658aef-a188-d73c-9c42-e40f55e18bdb", "_SystemAdmin" });

            var result = new deneme2copyComponent_1429256652_onClick_Response();


            using var auditConnect_0 = ActionAuditScope.Begin("cb4ecac5-d812-d977-2c39-7a789c139ef1", "Connect", applicationName: "wbTimesCRM", screenOrEndpointName: "deneme2copy");
            using var actionAuditConnect_0 = ActionAuditHelper.Begin("Connect", null);
            try
            {
                Kuika.ThirdPartyApisCollection.DBConnectCsharp.Connect();
            }
            catch (Exception ex)
            {
                actionAuditConnect_0.SetException(ex);
                throw;
            }
;


            return Ok(result);
        }


        [HttpPost, Route("deneme2copyComponent_781327937_onClick")]
        public IActionResult deneme2copyComponent_781327937_onClick(deneme2copyComponent_781327937_onClick_Request request)
        {

            KProviderManager.Authorization.IsAuthorizedForRoles(appId, appName, screenId, screenName, new List<string> { $"d6658aef-a188-d73c-9c42-e40f55e18bdb", "_SystemAdmin" });

            var result = new deneme2copyComponent_781327937_onClick_Response();

            var prms_GetKuikTest_0 = new List<kSqlParameter>();
            using var auditGetKuikTest_0 = ActionAuditScope.Begin("bef4addd-1e99-d2bd-2a48-3483663d6277", "GetKuikTest", applicationName: "wbTimesCRM", screenOrEndpointName: "deneme2copy");
            result.GetKuikTest = KPersister.Fetch(KContext.GetConnectionString(), @"SELECT * FROM tmscrq.KuikTest", new string[] { "Id", "Base64Data" }, prms_GetKuikTest_0.ToArray());
            ;


            using var auditConvert_1 = ActionAuditScope.Begin("bd1739f1-5d55-fc42-f045-ac9277e854ca", "Convert", applicationName: "wbTimesCRM", screenOrEndpointName: "deneme2copy");
            using var actionAuditConvert_1 = ActionAuditHelper.Begin("Convert", new { htmlBase64 = (result.GetKuikTest.ResultList.FirstOrDefault()?.GetValueByFieldName("Base64Data")).ConvertToType<String>() });
            try
            {
                result.Convert = Kuika.ThirdPartyApisCollection.Base64ToPdf.Convert((result.GetKuikTest.ResultList.FirstOrDefault()?.GetValueByFieldName("Base64Data")).ConvertToType<String>());
                actionAuditConvert_1.SetResult(result.Convert);
            }
            catch (Exception ex)
            {
                actionAuditConvert_1.SetException(ex);
                throw;
            }
;


            return Ok(result);
        }


        [HttpPost, Route("deneme2copyComponent_577176_onClick")]
        public IActionResult deneme2copyComponent_577176_onClick(deneme2copyComponent_577176_onClick_Request request)
        {

            KProviderManager.Authorization.IsAuthorizedForRoles(appId, appName, screenId, screenName, new List<string> { $"d6658aef-a188-d73c-9c42-e40f55e18bdb", "_SystemAdmin" });

            var result = new deneme2copyComponent_577176_onClick_Response();


            using var auditDecode_0 = ActionAuditScope.Begin("6812a23a-f3a0-5230-60b9-f8cb0d8ac809", "Decode", applicationName: "wbTimesCRM", screenOrEndpointName: "deneme2copy");
            using var actionAuditDecode_0 = ActionAuditHelper.Begin("Decode", new { base64 = request.base64_0.ConvertToType<String>() });
            try
            {
                result.Decode = Kuika.ThirdPartyApisCollection.Base64ToHtml.Decode(request.base64_0.ConvertToType<String>());
                actionAuditDecode_0.SetResult(result.Decode);
            }
            catch (Exception ex)
            {
                actionAuditDecode_0.SetException(ex);
                throw;
            }
;


            return Ok(result);
        }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class deneme2copyPageInit_Request
    {
    }
}

namespace Kuika.Reslen_01.Api
{
    public class deneme2copyPageInit_Response
    {
        public KCommonEntityPage GetKuikTest { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class deneme2copyComponent_65828_onClick_Request
    {
    }
}

namespace Kuika.Reslen_01.Api
{
    public class deneme2copyComponent_65828_onClick_Response
    {
        public String SyncProductExcel { set; get; }

        public int TMProductMergeUpdate { set; get; }

        public int TMProductMergeInsert { set; get; }

        public int TMProductMergeSoftDeleted { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class deneme2copyComponent_996716_onClick_Request
    {
    }
}

namespace Kuika.Reslen_01.Api
{
    public class deneme2copyComponent_996716_onClick_Response
    {
        public String SyncCustomers { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class deneme2copyComponent_1429256652_onClick_Request
    {
    }
}

namespace Kuika.Reslen_01.Api
{
    public class deneme2copyComponent_1429256652_onClick_Response
    {
    }
}

namespace Kuika.Reslen_01.Api
{
    public class deneme2copyComponent_781327937_onClick_Request
    {
        public String? htmlBase64_1 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class deneme2copyComponent_781327937_onClick_Response
    {
        public KCommonEntityPage GetKuikTest { set; get; }

        public String Convert { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class deneme2copyComponent_577176_onClick_Request
    {
        public String? base64_0 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class deneme2copyComponent_577176_onClick_Response
    {
        public String Decode { set; get; }

    }
}
