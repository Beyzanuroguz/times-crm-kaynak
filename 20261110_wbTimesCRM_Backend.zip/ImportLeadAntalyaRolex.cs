
using Kuika.Common;
using Kuika.Common.Attributes;
using Kuika.Common.Bases;
using Kuika.Common.Enums;
using Kuika.Common.Accessors;
using Kuika.Common.Json;
using Kuika.Common.Classes;
using Kuika.Common.Exceptions;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Kuika.Common.Helpers;
using Kuika.Common.Settings;
using System.Collections.Generic;
using System;
using Kuika.Common.Extensions;
using System.Linq;
using Kuika.Common.Rest;
using WorkflowCore.Interface;
using Kuika.Common.Interfaces;
using Kuika.Common.Workflow;
using Kuika.Common.Workflow.Extensions;
using Kuika.Common.Workflow.DTOs;
using Kuika.Common.Models;
using Kuika.Common.Menu.Response;
using Kuika.Common.Entities;
using System.Reflection;
using Newtonsoft.Json.Linq;
using Newtonsoft.Json;
using System.Net.Http;
using Iyzipay.Model.V2.Subscription;
using Kuika.Common.Payments.Iyzico;
using Kuika.Common.Payments.Param;
using Iyzipay;
using Kuika.Common.Searching.DTOs;
using Kuika.Common.Helpers.Sap;
using Kuika.Common.Mcp;
using Kuika.Common.Vision.DTOs;
using Kuika.Common.Audit;
using Kuika.Common.Payments.Mobile;
using Kuika.ThirdPartyApisCollection;

namespace Kuika.Reslen_01.Api
{
    [ApiExplorerSettings(GroupName = "all")]
    [Authorize]
    [ApiController]
    [Route("v1/api/ImportLeadAntalyaRolex")]
    public class ImportLeadAntalyaRolex_Controller : KControllerBase
    {
        private string appName = "wbTimesCRM";
        private Guid appId = Guid.Parse("0e8ecb48-8c52-463c-5db5-08de3ec441b1");
        private static string screenName = "ImportLeadAntalyaRolex";
        private Guid screenId = Guid.Parse("064736b7-f803-42f0-9e40-e1642100f60e");
        private string connectionString { get { return Kuika.Common.KContext.GetConnectionString(); } }

        [HttpGet, Route("myroles")]
        public IActionResult GetMyRoles()
        {
            try
            {
                var result = KProviderManager.Authorization.GetMyRoles(appId, appName, screenId, screenName);
                return Ok(result);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new HttpExceptionDto() { Message = ex.Message, StackTrace = ex.StackTrace });
            }
        }


        [HttpPost, Route("ImportLeadAntalyaRolexComponent_960361_onClick1_")]
        public IActionResult ImportLeadAntalyaRolexComponent_960361_onClick1_(ImportLeadAntalyaRolexComponent_960361_onClick1__Request request)
        {

            var result = new ImportLeadAntalyaRolexComponent_960361_onClick1__Response();


            using var auditImportExcelBase64_0 = ActionAuditScope.Begin("ec60b1df-4a68-c48c-5107-8bc25082a9e7", "ImportExcelBase64", applicationName: "wbTimesCRM", screenOrEndpointName: "ImportLeadAntalyaRolex");
            using var actionAuditImportExcelBase64_0 = ActionAuditHelper.Begin("ImportExcelBase64", new { excelBase64 = request.excelBase64_0.ConvertToType<String>(), tableName = "ImportLeadAntalyaRolex".ConvertToType<String>(), primaryKeyName = "".ConvertToType<String>() });
            try
            {
                result.ImportExcelBase64 = Kuika.Common.Helpers.CsSystemFunctions.ImportExcelBase64(request.excelBase64_0.ConvertToType<String>(), "ImportLeadAntalyaRolex".ConvertToType<String>(), "".ConvertToType<String>());
                actionAuditImportExcelBase64_0.SetResult(result.ImportExcelBase64);
            }
            catch (Exception ex)
            {
                actionAuditImportExcelBase64_0.SetException(ex);
                throw;
            }
;


            return Ok(result);
        }


        [HttpPost, Route("ImportLeadAntalyaRolexComponent_775546_onClick")]
        public IActionResult ImportLeadAntalyaRolexComponent_775546_onClick(ImportLeadAntalyaRolexComponent_775546_onClick_Request request)
        {

            var result = new ImportLeadAntalyaRolexComponent_775546_onClick_Response();

            var prms_ImportAntalyaRolexCustomerCount_0 = new List<kSqlParameter>();
            using var auditImportAntalyaRolexCustomerCount_0 = ActionAuditScope.Begin("7edaa1fa-4557-c2ea-978d-37dbf0bd530e", "ImportAntalyaRolexCustomerCount", applicationName: "wbTimesCRM", screenOrEndpointName: "ImportLeadAntalyaRolex");
            result.ImportAntalyaRolexCustomerCount = KPersister.Fetch(KContext.GetConnectionString(), @"WITH
ImportNorm AS (
    SELECT
        I.*,
        RIGHT(
            REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(
                ISNULL(I.Irtibat_Numaras_, ''), '+90', ''), ' ', ''), '-', ''), '(', ''), ')', ''), '.', ''),
            10
        ) AS Phone10,
        LOWER(LTRIM(RTRIM(ISNULL(I.E_Mail_Adresi, '')))) AS EmailNorm
    FROM tmscrq.ImportLeadAntalyaRolex I
),
CustNorm AS (
    SELECT
        TC.Id,
        RIGHT(
            REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(
                ISNULL(TC.Tel, ''), '+90', ''), ' ', ''), '-', ''), '(', ''), ')', ''), '.', ''),
            10
        ) AS Phone10,
        LOWER(LTRIM(RTRIM(ISNULL(TC.Email, '')))) AS EmailNorm
    FROM tmscrq.TMCustomer TC
),
PhoneCounts AS (
    SELECT Phone10, COUNT(*) AS PhoneCount
    FROM CustNorm
    GROUP BY Phone10
),
Matched AS (
    SELECT
        I.Id AS ImportId,
        CASE WHEN C.Id IS NOT NULL THEN N'Açılmış' ELSE N'Açılmamış' END AS Durum
    FROM ImportNorm I
    LEFT JOIN PhoneCounts PC ON PC.Phone10 = I.Phone10
    OUTER APPLY (
        SELECT TOP (1) TC.Id
        FROM CustNorm TC
        WHERE
            (PC.PhoneCount = 1 AND TC.Phone10 = I.Phone10)
            OR (PC.PhoneCount > 1 AND I.EmailNorm <> '' AND TC.Phone10 = I.Phone10 AND TC.EmailNorm = I.EmailNorm)
            OR (PC.PhoneCount = 0 AND I.EmailNorm <> '' AND TC.EmailNorm = I.EmailNorm)
        ORDER BY
            CASE
                WHEN PC.PhoneCount = 1 AND TC.Phone10 = I.Phone10 THEN 1
                WHEN PC.PhoneCount > 1 AND I.EmailNorm <> '' AND TC.Phone10 = I.Phone10 AND TC.EmailNorm = I.EmailNorm THEN 2
                ELSE 3
            END
    ) C
)
SELECT Durum, COUNT(*) AS Adet
FROM Matched
GROUP BY Durum
ORDER BY Durum DESC;", new string[] { "Durum", "Adet" }, prms_ImportAntalyaRolexCustomerCount_0.ToArray());
            ;


            return Ok(result);
        }


        [HttpPost, Route("ImportLeadAntalyaRolexComponent_903244_onClick")]
        public IActionResult ImportLeadAntalyaRolexComponent_903244_onClick(ImportLeadAntalyaRolexComponent_903244_onClick_Request request)
        {

            var result = new ImportLeadAntalyaRolexComponent_903244_onClick_Response();

            var prms_ImportLeadAntalyaRolexList_0 = new List<kSqlParameter>();
            using var auditImportLeadAntalyaRolexList_0 = ActionAuditScope.Begin("146abe44-526b-afbc-9ccf-55c98de7b021", "ImportLeadAntalyaRolexList", applicationName: "wbTimesCRM", screenOrEndpointName: "ImportLeadAntalyaRolex");
            result.ImportLeadAntalyaRolexList = KPersister.Fetch(KContext.GetConnectionString(), @"WITH
-- 1. Import tablosunun normalize edilmiş telefon ve e-posta bilgileri
ImportNorm AS (
    SELECT
        I.*,
        RIGHT(
            REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(
                ISNULL(I.Irtibat_Numaras_, ''), '+90', ''), ' ', ''), '-', ''), '(', ''), ')', ''), '.', ''),
            10
        ) AS Phone10,
        LOWER(LTRIM(RTRIM(ISNULL(I.E_Mail_Adresi, '')))) AS EmailNorm
    FROM tmscrq.ImportLeadAntalyaRolex I
),

-- 2. TMCustomer tablosunun normalize edilmiş telefon ve e-posta bilgileri
CustNorm AS (
    SELECT
        TC.Id,
        TC.CurrAccCode,
        TC.Tel,
        TC.Email,
        RIGHT(
            REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(
                ISNULL(TC.Tel, ''), '+90', ''), ' ', ''), '-', ''), '(', ''), ')', ''), '.', ''),
            10
        ) AS Phone10,
        LOWER(LTRIM(RTRIM(ISNULL(TC.Email, '')))) AS EmailNorm
    FROM tmscrq.TMCustomer TC
),

-- 3. Her normalize telefon numarasına ait müşteri sayısı
PhoneCounts AS (
    SELECT
        Phone10,
        COUNT(*) AS PhoneCount
    FROM CustNorm
    GROUP BY Phone10
)

SELECT
    I.*,

    -------------------------------------------------------
    -- SİSTEMDE BULUNAN MÜŞTERİ
    -------------------------------------------------------
    C.Id AS CustomerId,
    C.CurrAccCode,

    -------------------------------------------------------
    -- AD VE SOYAD (Import tablosundan üretilecek)
    -------------------------------------------------------
    CASE
        WHEN CHARINDEX(' ', I.Musteri) > 0
            THEN LEFT(I.Musteri, CHARINDEX(' ', I.Musteri) - 1)
        ELSE I.Musteri
    END AS Name,

    CASE
        WHEN CHARINDEX(' ', I.Musteri) > 0
            THEN SUBSTRING(I.Musteri, CHARINDEX(' ', I.Musteri) + 1, LEN(I.Musteri))
        ELSE ''
    END AS LastName,

    C.Tel AS SistemTelefon,
    C.Email AS SistemMail,

    -------------------------------------------------------
    -- DURUM
    -------------------------------------------------------
    CASE
        WHEN C.Id IS NULL THEN N'Açılmamış'
        ELSE N'Açılmış'
    END AS Durum,

    -------------------------------------------------------
    -- KULLANICIYA GÖSTERİLECEK EŞLEŞME TİPİ
    -------------------------------------------------------
    CASE
        WHEN PC.PhoneCount = 1 THEN N'Telefon'
        WHEN PC.PhoneCount > 1 AND C.Id IS NOT NULL THEN N'Telefon + E-Mail'
        WHEN PC.PhoneCount = 0 AND C.Id IS NOT NULL THEN N'E-Mail'
        ELSE N'Eşleşmedi'
    END AS EslesmeTipi,

    -------------------------------------------------------
    -- C# TARAFINDA KULLANILACAK MATCH TYPE
    -------------------------------------------------------
    CASE
        WHEN PC.PhoneCount = 1 THEN 'PHONE'
        WHEN PC.PhoneCount > 1 AND C.Id IS NOT NULL THEN 'PHONE_EMAIL'
        WHEN PC.PhoneCount = 0 AND C.Id IS NOT NULL THEN 'EMAIL'
        ELSE 'NEW'
    END AS MatchType,

    -------------------------------------------------------
    -- TOPLAM SATIR SAYISI
    -------------------------------------------------------
    COUNT(*) OVER() AS TotalRows

FROM ImportNorm I
LEFT JOIN PhoneCounts PC ON PC.Phone10 = I.Phone10
OUTER APPLY (
    SELECT TOP (1) *
    FROM CustNorm TC
    WHERE
        ---------------------------------------------------
        -- TELEFON TEK İSE DİREKT EŞLEŞTİR
        ---------------------------------------------------
        (PC.PhoneCount = 1 AND TC.Phone10 = I.Phone10)
        OR
        ---------------------------------------------------
        -- TELEFON BİRDEN FAZLA İSE TELEFON + MAIL
        ---------------------------------------------------
        (PC.PhoneCount > 1
         AND I.EmailNorm <> ''
         AND TC.Phone10 = I.Phone10
         AND TC.EmailNorm = I.EmailNorm)
        OR
        ---------------------------------------------------
        -- TELEFON BULUNAMADIYSA MAIL İLE EŞLEŞTİR
        ---------------------------------------------------
        (PC.PhoneCount = 0
         AND I.EmailNorm <> ''
         AND TC.EmailNorm = I.EmailNorm)
    ORDER BY
        CASE
            WHEN PC.PhoneCount = 1  AND TC.Phone10 = I.Phone10 THEN 1
            WHEN PC.PhoneCount > 1
                 AND I.EmailNorm <> ''
                 AND TC.Phone10 = I.Phone10
                 AND TC.EmailNorm = I.EmailNorm THEN 2
            ELSE 3
        END
) C

-------------------------------------------------------
-- SON SIRALAMA
-------------------------------------------------------
ORDER BY
    CASE
        WHEN C.Id IS NULL THEN 0
        ELSE 1
    END,
    I.Musteri ASC;", new string[] { "Id", "Talep_Tarihi", "Referans", "Ref", "Kadran", "Bilezik", "Musteri", "Musteri_info", "Lokasyon", "Iletisim_Kaynag_", "Al_sverisi_var_m____", "Lead_Durumu", "Sonraki_Ad_m", "Irtibat_Numaras_", "E_Mail_Adresi", "Tahmini_teslimat", "Sonuc", "Sat_s_Dan_sman_", "Phone10", "EmailNorm", "CustomerId", "CurrAccCode", "Name", "LastName", "SistemTelefon", "SistemMail", "Durum", "EslesmeTipi", "MatchType", "TotalRows" }, prms_ImportLeadAntalyaRolexList_0.ToArray());
            ;


            return Ok(result);
        }


        [HttpPost, Route("ImportLeadAntalyaRolexComponent_903244_onClick_foreach1")]
        public IActionResult ImportLeadAntalyaRolexComponent_903244_onClick_foreach1(ImportLeadAntalyaRolexComponent_903244_onClick_foreach1_Request request)
        {

            var result = new ImportLeadAntalyaRolexComponent_903244_onClick_foreach1_Response();


            using var auditImportCustomer2_0 = ActionAuditScope.Begin("d624aace-aa8e-e16d-463e-dc20986415d2", "ImportCustomer2", applicationName: "wbTimesCRM", screenOrEndpointName: "ImportLeadAntalyaRolex");
            using var actionAuditImportCustomer2_0 = ActionAuditHelper.Begin("ImportCustomer2", new { ad = request.ad_0.ConvertToType<String>(), soyad = request.soyad_0.ConvertToType<String>(), telefon = request.telefon_0.ConvertToType<String>(), email = request.email_0.ConvertToType<String>(), tcKimlikNo = "11111111111".ConvertToType<String>(), lokasyon = request.lokasyon_0.ConvertToType<String>(), musteriInfo = request.musteriInfo_0.ConvertToType<String>(), matchType = request.matchType_0.ConvertToType<String>(), customerId = request.customerId_0.ConvertToType<Guid?>(), currAccCode = request.currAccCode_0.ConvertToType<String>(), sourceType = "ExcelAntalyaRolexOto".ConvertToType<String>(), createdBy = Kuika.Common.KContext.CurrentUser?.Id.ConvertToType<Guid?>() });
            try
            {
                result.ImportCustomer2 = Kuika.ThirdPartyApisCollection.CustomerImportCreate2.ImportCustomer2(connectionString, request.ad_0.ConvertToType<String>(), request.soyad_0.ConvertToType<String>(), request.telefon_0.ConvertToType<String>(), request.email_0.ConvertToType<String>(), "11111111111".ConvertToType<String>(), request.lokasyon_0.ConvertToType<String>(), request.musteriInfo_0.ConvertToType<String>(), request.matchType_0.ConvertToType<String>(), request.customerId_0.ConvertToType<Guid?>(), request.currAccCode_0.ConvertToType<String>(), "ExcelAntalyaRolexOto".ConvertToType<String>(), Kuika.Common.KContext.CurrentUser?.Id.ConvertToType<Guid?>());
                actionAuditImportCustomer2_0.SetResult(result.ImportCustomer2);
            }
            catch (Exception ex)
            {
                actionAuditImportCustomer2_0.SetException(ex);
                throw;
            }
;


            return Ok(result);
        }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class ImportLeadAntalyaRolexComponent_960361_onClick1__Request
    {
        public String excelBase64_0 { set; get; }
        public String tableName_0 { set; get; }
        public String primaryKeyName_0 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class ImportLeadAntalyaRolexComponent_960361_onClick1__Response
    {
        public String ImportExcelBase64 { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class ImportLeadAntalyaRolexComponent_775546_onClick_Request
    {
    }
}

namespace Kuika.Reslen_01.Api
{
    public class ImportLeadAntalyaRolexComponent_775546_onClick_Response
    {
        public KCommonEntityPage ImportAntalyaRolexCustomerCount { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class ImportLeadAntalyaRolexComponent_903244_onClick_Request
    {
    }
}

namespace Kuika.Reslen_01.Api
{
    public class ImportLeadAntalyaRolexComponent_903244_onClick_Response
    {
        public KCommonEntityPage ImportLeadAntalyaRolexList { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class ImportLeadAntalyaRolexComponent_903244_onClick_foreach1_Request
    {
        public String? ad_0 { set; get; }
        public String? soyad_0 { set; get; }
        public String? telefon_0 { set; get; }
        public String? email_0 { set; get; }
        public String? tcKimlikNo_0 { set; get; }
        public String? lokasyon_0 { set; get; }
        public String? musteriInfo_0 { set; get; }
        public String? matchType_0 { set; get; }
        public Guid? customerId_0 { set; get; }
        public String? currAccCode_0 { set; get; }
        public String? sourceType_0 { set; get; }
        public Guid? createdBy_0 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class ImportLeadAntalyaRolexComponent_903244_onClick_foreach1_Response
    {
        public String ImportCustomer2 { set; get; }

    }
}
