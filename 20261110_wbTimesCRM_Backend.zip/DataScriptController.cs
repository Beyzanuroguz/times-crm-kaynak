
using Kuika.Common;
using Kuika.Common.Accessors;
using Kuika.Common.Bases;
using Kuika.Common.Entities;
using Kuika.Common.Extensions;
using Kuika.Common.Helpers;
using Kuika.Common.Interfaces;
using Kuika.Common.Settings;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;

namespace Kuika.App.Controllers
{
    [ApiExplorerSettings(GroupName = "all")]
    [Authorize]
    [ApiController]
    [Route("v1/api/[controller]")]
    public class DataScriptController : KControllerBase
    {
        // Operator drops one-time .sql files here (relative to the app base directory);
        // CsProjectFileGenerator copies the folder into the publish output.
        private const string DataScriptsFolderName = "DataScripts";

        #region ..Constructors..

        public DataScriptController() : base() { }

        #endregion ..Constructors..

        #region ..Apis..

        // Lists the *.sql files in DataScripts/ together with, for each one, whether it already ran
        // in THIS app (and if so who ran it and when) — read from the KDataScriptExecution journal.
        [HttpGet("list")]
        public IActionResult List()
        {
            var names = DirectoryHelper.ListSqlFileNames(DataScriptsFolderName);
            try
            {
                var appId = GetAppId();
                var connectionString = KContext.GetConnectionString();

                var files = new List<object>();
                foreach (var name in names)
                {
                    var journal = TryGetJournalEntry(connectionString, appId, name);
                    if (journal == null)
                    {
                        files.Add(new { fileName = name, executed = false });
                    }
                    else
                    {
                        files.Add(new { fileName = name, executed = true, executedAt = journal.ExecutedAt, executedBy = journal.ExecutedByUserName });
                    }
                }
                return Ok(new { files });
            }
            catch (Exception ex)
            {
                // Journal unreadable (e.g. the KDataScriptExecution table has not been migrated yet):
                // still return the file names so the operator can see what is there; the executed-state
                // annotation is just omitted rather than failing the whole listing.
                var warn = ex.ToDetailMessage();
                KProviderManager.GetInstance<ILogServiceBase>()?.Log(new KLog(), "warning", warn, "DataScriptController.List", ex);
                return Ok(new { files = names.Select(n => new { fileName = n }).ToList(), warning = $"Could not read the execution journal ({warn}). File names are listed without run status." });
            }
        }

        // Runs ONE named script from DataScripts/ in a single transaction against the app's own
        // database. The script's statements AND the journal row that marks it done are saved in the
        // SAME transaction, so it is atomically exactly-once: any error rolls back both (nothing runs,
        // nothing is marked) and the DB message is returned so it can be fixed and retried.
        [HttpPost("execute")]
        public IActionResult Execute([FromQuery] string fileName)
        {
            if (string.IsNullOrWhiteSpace(fileName))
            {
                return BadRequest(new { error = "Provide 'fileName' (see GET /v1/api/DataScript/list for available scripts)." });
            }

            try
            {
                var folderPath = DirectoryHelper.ToDirectoryPath(DataScriptsFolderName);
                var names = DirectoryHelper.ListSqlFileNames(DataScriptsFolderName);

                if (!names.Any(n => string.Equals(n, fileName, StringComparison.Ordinal)))
                {
                    var available = string.Join(',', names);
                    return BadRequest(new { error = $"Script '{fileName}' not found in DataScripts. Available: [{available}]" });
                }

                var appId = GetAppId();
                var connectionString = KContext.GetConnectionString();

                // Already ran for this app -> refuse. The journal (not a file rename) is the source of
                // truth, so this holds across container recreation / read-only FS / multiple replicas.
                // If this read throws (e.g. journal table missing) we fail below rather than run, so a
                // script is never executed while its run-once state is unknown.
                var previous = TryGetJournalEntry(connectionString, appId, fileName);
                if (previous != null)
                {
                    return Ok(new { status = "already_processed", fileName = fileName, executedAt = previous.ExecutedAt, executedBy = previous.ExecutedByUserName, message = $"'{fileName}' was already executed for this app; it will not run again." });
                }

                var content = System.IO.File.ReadAllText(Path.Combine(folderPath, fileName));

                // Data-only contract: reject the whole file (nothing runs, no transaction opened) if
                // any statement starts with a schema/permission/USE/EXEC keyword. Schema changes
                // belong to the migration endpoint. Best-effort guard - see FindDisallowedKeyword.
                var disallowedKeyword = SqlScriptHelper.FindDisallowedKeyword(content);
                if (!string.IsNullOrEmpty(disallowedKeyword))
                {
                    return BadRequest(new { status = "rejected", fileName = fileName, keyword = disallowedKeyword, error = $"Script contains a '{disallowedKeyword}' statement, which is not allowed here. Data scripts must not contain DDL (schema), DCL (permission), USE or EXEC/EXECUTE statements. Please review your script." });
                }

                var commands = SqlScriptHelper.SplitSqlBatches(content)
                    .Select(batch => new kDbCommand() { SqlCommand = batch })
                    .ToList();
                if (commands.Count == 0)
                {
                    return Ok(new { status = "empty", message = $"'{fileName}' has no SQL to run; it was not recorded as executed." });
                }

                // Journal INSERT appended to the SAME command list -> same transaction as the DML above.
                // ESqlScript resolves to the right dialect (SQL Server / PostgreSQL / Oracle); Id and
                // ExecutedAt are produced in C# rather than by any database-specific SQL function, so
                // nothing is SQL-Server-only and the run works on every supported database.
                var appName = GetAppName();
                var userId = KContext.CurrentUserId;
                var userName = KContext.CurrentUser?.Username;
                commands.Add(new kDbCommand()
                {
                    ESqlScript = s => s.InsertDataScriptExecution,
                    Parameters = new List<kSqlParameter>()
                    {
                        new kSqlParameter() { Name = "Id", Value = Guid.NewGuid() },
                        new kSqlParameter() { Name = "AppId", Value = appId },
                        new kSqlParameter() { Name = "AppName", Value = appName },
                        new kSqlParameter() { Name = "FileName", Value = fileName },
                        new kSqlParameter() { Name = "ExecutedAt", Value = DateTimeOffset.Now },
                        new kSqlParameter() { Name = "ExecutedByUserId", Value = userId },
                        new kSqlParameter() { Name = "ExecutedByUserName", Value = userName },
                    }
                });

                KPersister.Save(connectionString, commands); // script batches + journal row, one transaction
                return Ok(new { status = "executed", executed = fileName, executedBy = userName });
            }
            catch (Exception ex)
            {
                // One clean failure path for every fault: script SQL error (the transaction is rolled
                // back, so nothing is applied and nothing is journaled), file read / IO error, or an
                // unreadable journal. Never surfaces a raw 500 — fix the cause and call /execute again.
                var errorDetail = ex.ToDetailMessage();
                KProviderManager.GetInstance<ILogServiceBase>()?.Log(new KLog(), "error", errorDetail, "DataScriptController.Execute", ex);
                return BadRequest(new { status = "failed", fileName = fileName, error = errorDetail });
            }
        }

        #endregion ..Apis..

        #region ..Privates..

        // A journal row for (appId, fileName), or null when the script has not run for this app.
        private static KDataScriptJournalEntry TryGetJournalEntry(string connectionString, string appId, string fileName)
        {
            var command = new kDbCommand()
            {
                ESqlScript = s => s.CheckDataScriptExecuted,
                Parameters = new List<kSqlParameter>()
                {
                    new kSqlParameter() { Name = "AppId", Value = appId },
                    new kSqlParameter() { Name = "FileName", Value = fileName },
                }
            };

            var row = KPersister.Fetch(connectionString, command).ResultList.FirstOrDefault();
            if (row == null)
                return null;

            return new KDataScriptJournalEntry
            {
                ExecutedAt = row.GetValueByFieldName("ExecutedAt")?.ToString(),
                ExecutedByUserName = row.GetValueByFieldName("ExecutedByUserName")?.ToString(),
            };
        }

        // Coalesced to empty string so the (AppId, FileName) dedup works even when AppId is unset:
        // SQL Server treats NULL = NULL as unknown, so a null AppId would never match a stored null.
        private static string GetAppId()
        {
            return ConfigurationHelper.GetSettings<AppSettingsBase>()?.AppId ?? string.Empty;
        }

        private static string GetAppName()
        {
            return ConfigurationHelper.GetSettings<AppSettingsBase>()?.AppName;
        }

        private class KDataScriptJournalEntry
        {
            public string ExecutedAt { get; set; }
            public string ExecutedByUserName { get; set; }
        }

        #endregion ..Privates..
    }
}
