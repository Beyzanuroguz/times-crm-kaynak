
using Kuika.Common;
using Kuika.Common.Attributes;
using Kuika.Common.Bases;
using Kuika.Common.Enums;
using Kuika.Common.Accessors;
using Kuika.Common.Json;
using Kuika.Common.Classes;
using Kuika.Common.Exceptions;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Kuika.Common.Helpers;
using Kuika.Common.Settings;
using System.Collections.Generic;
using System;
using Kuika.Common.Extensions;
using System.Linq;
using Kuika.Common.Rest;
using WorkflowCore.Interface;
using Kuika.Common.Interfaces;
using Kuika.Common.Workflow;
using Kuika.Common.Workflow.Extensions;
using Kuika.Common.Workflow.DTOs;
using Kuika.Common.Models;
using Kuika.Common.Menu.Response;
using Kuika.Common.Entities;
using System.Reflection;
using Newtonsoft.Json.Linq;
using Newtonsoft.Json;
using System.Net.Http;
using Iyzipay.Model.V2.Subscription;
using Kuika.Common.Payments.Iyzico;
using Kuika.Common.Payments.Param;
using Iyzipay;
using Kuika.Common.Searching.DTOs;
using Kuika.Common.Helpers.Sap;
using Kuika.Common.Mcp;
using Kuika.Common.Vision.DTOs;
using Kuika.Common.Audit;
using Kuika.Common.Payments.Mobile;
using Kuika.ThirdPartyApisCollection;

namespace Kuika.Reslen_01.Api
{
    [ApiExplorerSettings(GroupName = "all")]
    [Authorize]
    [ApiController]
    [Route("v1/api/RolexOtherProductReporting")]
    public class RolexOtherProductReporting_Controller : KControllerBase
    {
        private string appName = "wbTimesCRM";
        private Guid appId = Guid.Parse("0e8ecb48-8c52-463c-5db5-08de3ec441b1");
        private static string screenName = "RolexOtherProductReporting";
        private Guid screenId = Guid.Parse("1e658766-4c3d-4c11-9a33-3daf2868e69f");
        private string connectionString { get { return Kuika.Common.KContext.GetConnectionString(); } }

        [HttpGet, Route("myroles")]
        public IActionResult GetMyRoles()
        {
            try
            {
                var result = KProviderManager.Authorization.GetMyRoles(appId, appName, screenId, screenName);
                return Ok(result);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new HttpExceptionDto() { Message = ex.Message, StackTrace = ex.StackTrace });
            }
        }


        [HttpPost, Route("RolexOtherProductReportingPageInit")]
        public IActionResult RolexOtherProductReportingPageInit(RolexOtherProductReportingPageInit_Request request)
        {

            var result = new RolexOtherProductReportingPageInit_Response();


            using var auditKuikaY_RolexGrupAylikSatisKarsilastirma_S1_0 = ActionAuditScope.Begin("c1ec394e-140c-c7df-20de-874cca72ff93", "KuikaY_RolexGrupAylikSatisKarsilastirma_S1", applicationName: "wbTimesCRM", screenOrEndpointName: "RolexOtherProductReporting");
            using var actionAuditKuikaY_RolexGrupAylikSatisKarsilastirma_S1_0 = ActionAuditHelper.Begin("KuikaY_RolexGrupAylikSatisKarsilastirma_S1", new { Brand = "Rolex".ConvertToType<String>(), ProductGroup = "Kol Düğmesi".ConvertToType<String>(), Year1 = request.Year1_0.ConvertToType<Int32>(), Year2 = request.Year2_0.ConvertToType<Int32>() });
            try
            {
                result.KuikaY_RolexGrupAylikSatisKarsilastirma_S1 = Kuika.ThirdPartyApisCollection.Reports.KuikaY_RolexGrupAylikSatisKarsilastirma("Rolex".ConvertToType<String>(), "Kol Düğmesi".ConvertToType<String>(), request.Year1_0.ConvertToType<Int32>(), request.Year2_0.ConvertToType<Int32>());
                actionAuditKuikaY_RolexGrupAylikSatisKarsilastirma_S1_0.SetResult(result.KuikaY_RolexGrupAylikSatisKarsilastirma_S1);
            }
            catch (Exception ex)
            {
                actionAuditKuikaY_RolexGrupAylikSatisKarsilastirma_S1_0.SetException(ex);
                throw;
            }
;


            using var auditKuikaY_RolexGrupAylikSatisKarsilastirma_S2_1 = ActionAuditScope.Begin("37ce5c64-4488-a25a-fe74-72773ffeeb92", "KuikaY_RolexGrupAylikSatisKarsilastirma_S2", applicationName: "wbTimesCRM", screenOrEndpointName: "RolexOtherProductReporting");
            using var actionAuditKuikaY_RolexGrupAylikSatisKarsilastirma_S2_1 = ActionAuditHelper.Begin("KuikaY_RolexGrupAylikSatisKarsilastirma_S2", new { Brand = "Rolex".ConvertToType<String>(), ProductGroup = "Kitap".ConvertToType<String>(), Year1 = request.Year1_1.ConvertToType<Int32>(), Year2 = request.Year2_1.ConvertToType<Int32>() });
            try
            {
                result.KuikaY_RolexGrupAylikSatisKarsilastirma_S2 = Kuika.ThirdPartyApisCollection.Reports.KuikaY_RolexGrupAylikSatisKarsilastirma("Rolex".ConvertToType<String>(), "Kitap".ConvertToType<String>(), request.Year1_1.ConvertToType<Int32>(), request.Year2_1.ConvertToType<Int32>());
                actionAuditKuikaY_RolexGrupAylikSatisKarsilastirma_S2_1.SetResult(result.KuikaY_RolexGrupAylikSatisKarsilastirma_S2);
            }
            catch (Exception ex)
            {
                actionAuditKuikaY_RolexGrupAylikSatisKarsilastirma_S2_1.SetException(ex);
                throw;
            }
;


            using var auditKuikaY_RolexGrupAylikSatisKarsilastirma_S3_2 = ActionAuditScope.Begin("f78a616d-c7f3-cf58-79ad-db4dd7cb6464", "KuikaY_RolexGrupAylikSatisKarsilastirma_S3", applicationName: "wbTimesCRM", screenOrEndpointName: "RolexOtherProductReporting");
            using var actionAuditKuikaY_RolexGrupAylikSatisKarsilastirma_S3_2 = ActionAuditHelper.Begin("KuikaY_RolexGrupAylikSatisKarsilastirma_S3", new { Brand = "Rolex".ConvertToType<String>(), ProductGroup = "Masa Saati".ConvertToType<String>(), Year1 = request.Year1_2.ConvertToType<Int32>(), Year2 = request.Year2_2.ConvertToType<Int32>() });
            try
            {
                result.KuikaY_RolexGrupAylikSatisKarsilastirma_S3 = Kuika.ThirdPartyApisCollection.Reports.KuikaY_RolexGrupAylikSatisKarsilastirma("Rolex".ConvertToType<String>(), "Masa Saati".ConvertToType<String>(), request.Year1_2.ConvertToType<Int32>(), request.Year2_2.ConvertToType<Int32>());
                actionAuditKuikaY_RolexGrupAylikSatisKarsilastirma_S3_2.SetResult(result.KuikaY_RolexGrupAylikSatisKarsilastirma_S3);
            }
            catch (Exception ex)
            {
                actionAuditKuikaY_RolexGrupAylikSatisKarsilastirma_S3_2.SetException(ex);
                throw;
            }
;


            return Ok(result);
        }


        [HttpPost, Route("RolexOtherProductReportingComponent_616475_onClick")]
        public IActionResult RolexOtherProductReportingComponent_616475_onClick(RolexOtherProductReportingComponent_616475_onClick_Request request)
        {

            var result = new RolexOtherProductReportingComponent_616475_onClick_Response();


            using var auditExportExcel_0 = ActionAuditScope.Begin("24d8eae7-765d-4afe-52b6-0ca67c9556ed", "ExportExcel", applicationName: "wbTimesCRM", screenOrEndpointName: "RolexOtherProductReporting");
            using var actionAuditExportExcel_0 = ActionAuditHelper.Begin("ExportExcel", new { value = request.value_0.ConvertToType<Object>(), header = "Rolex Kol Düğmesi 2 Yıl Arası Karşılaştırmalı Ay Bazlı Rapor".ConvertToType<String>(), footer = "".ConvertToType<String>(), columns = "".ConvertToType<String>() });
            try
            {
                result.ExportExcel = Kuika.Common.Helpers.CsSystemFunctions.ExportExcel(request.value_0.ConvertToType<Object>(), "Rolex Kol Düğmesi 2 Yıl Arası Karşılaştırmalı Ay Bazlı Rapor".ConvertToType<String>(), "".ConvertToType<String>(), "".ConvertToType<String>());
                actionAuditExportExcel_0.SetResult(result.ExportExcel);
            }
            catch (Exception ex)
            {
                actionAuditExportExcel_0.SetException(ex);
                throw;
            }
;


            return Ok(result);
        }


        [HttpPost, Route("RolexOtherProductReportingComponent_80364_onClick")]
        public IActionResult RolexOtherProductReportingComponent_80364_onClick(RolexOtherProductReportingComponent_80364_onClick_Request request)
        {

            var result = new RolexOtherProductReportingComponent_80364_onClick_Response();


            using var auditExportExcel_0 = ActionAuditScope.Begin("85c42302-8059-3197-4865-6aa3d26a5c79", "ExportExcel", applicationName: "wbTimesCRM", screenOrEndpointName: "RolexOtherProductReporting");
            using var actionAuditExportExcel_0 = ActionAuditHelper.Begin("ExportExcel", new { value = request.value_0.ConvertToType<Object>(), header = "Rolex Kol Düğmesi 2 Yıl Arası Karşılaştırmalı Ocak Ayı Raporu".ConvertToType<String>(), footer = "".ConvertToType<String>(), columns = "Magaza,Ocak2025,Ocak2026,OcakDegisim".ConvertToType<String>() });
            try
            {
                result.ExportExcel = Kuika.Common.Helpers.CsSystemFunctions.ExportExcel(request.value_0.ConvertToType<Object>(), "Rolex Kol Düğmesi 2 Yıl Arası Karşılaştırmalı Ocak Ayı Raporu".ConvertToType<String>(), "".ConvertToType<String>(), "Magaza,Ocak2025,Ocak2026,OcakDegisim".ConvertToType<String>());
                actionAuditExportExcel_0.SetResult(result.ExportExcel);
            }
            catch (Exception ex)
            {
                actionAuditExportExcel_0.SetException(ex);
                throw;
            }
;


            return Ok(result);
        }


        [HttpPost, Route("RolexOtherProductReportingComponent_701801_onClick")]
        public IActionResult RolexOtherProductReportingComponent_701801_onClick(RolexOtherProductReportingComponent_701801_onClick_Request request)
        {

            var result = new RolexOtherProductReportingComponent_701801_onClick_Response();


            using var auditExportExcel_0 = ActionAuditScope.Begin("afeb7d16-4d54-a385-6fe1-21612ef9ce6b", "ExportExcel", applicationName: "wbTimesCRM", screenOrEndpointName: "RolexOtherProductReporting");
            using var actionAuditExportExcel_0 = ActionAuditHelper.Begin("ExportExcel", new { value = request.value_0.ConvertToType<Object>(), header = "Rolex Kol Düğmesi 2 Yıl Arası Karşılaştırmalı Şubat Ayı Raporu".ConvertToType<String>(), footer = "".ConvertToType<String>(), columns = "Magaza,Subat2025,Subat2026,SubatDegisim".ConvertToType<String>() });
            try
            {
                result.ExportExcel = Kuika.Common.Helpers.CsSystemFunctions.ExportExcel(request.value_0.ConvertToType<Object>(), "Rolex Kol Düğmesi 2 Yıl Arası Karşılaştırmalı Şubat Ayı Raporu".ConvertToType<String>(), "".ConvertToType<String>(), "Magaza,Subat2025,Subat2026,SubatDegisim".ConvertToType<String>());
                actionAuditExportExcel_0.SetResult(result.ExportExcel);
            }
            catch (Exception ex)
            {
                actionAuditExportExcel_0.SetException(ex);
                throw;
            }
;


            return Ok(result);
        }


        [HttpPost, Route("RolexOtherProductReportingComponent_601127_onClick")]
        public IActionResult RolexOtherProductReportingComponent_601127_onClick(RolexOtherProductReportingComponent_601127_onClick_Request request)
        {

            var result = new RolexOtherProductReportingComponent_601127_onClick_Response();


            using var auditExportExcel_0 = ActionAuditScope.Begin("e38776e7-743c-2bdb-69c6-f87a90cb7019", "ExportExcel", applicationName: "wbTimesCRM", screenOrEndpointName: "RolexOtherProductReporting");
            using var actionAuditExportExcel_0 = ActionAuditHelper.Begin("ExportExcel", new { value = request.value_0.ConvertToType<Object>(), header = "Rolex Kol Düğmesi 2 Yıl Arası Karşılaştırmalı Mart Ayı Raporu".ConvertToType<String>(), footer = "".ConvertToType<String>(), columns = "Magaza,Mart2025,Mart2026,MartDegisim".ConvertToType<String>() });
            try
            {
                result.ExportExcel = Kuika.Common.Helpers.CsSystemFunctions.ExportExcel(request.value_0.ConvertToType<Object>(), "Rolex Kol Düğmesi 2 Yıl Arası Karşılaştırmalı Mart Ayı Raporu".ConvertToType<String>(), "".ConvertToType<String>(), "Magaza,Mart2025,Mart2026,MartDegisim".ConvertToType<String>());
                actionAuditExportExcel_0.SetResult(result.ExportExcel);
            }
            catch (Exception ex)
            {
                actionAuditExportExcel_0.SetException(ex);
                throw;
            }
;


            return Ok(result);
        }


        [HttpPost, Route("RolexOtherProductReportingComponent_545006_onClick")]
        public IActionResult RolexOtherProductReportingComponent_545006_onClick(RolexOtherProductReportingComponent_545006_onClick_Request request)
        {

            var result = new RolexOtherProductReportingComponent_545006_onClick_Response();


            using var auditExportExcel_0 = ActionAuditScope.Begin("784ea9b7-8f49-9ed4-9a9e-eac2bd7292b3", "ExportExcel", applicationName: "wbTimesCRM", screenOrEndpointName: "RolexOtherProductReporting");
            using var actionAuditExportExcel_0 = ActionAuditHelper.Begin("ExportExcel", new { value = request.value_0.ConvertToType<Object>(), header = "Rolex Kol Düğmesi 2 Yıl Arası Karşılaştırmalı Nisan Ayı Raporu".ConvertToType<String>(), footer = "".ConvertToType<String>(), columns = "Magaza,Nisan2025,Nisan2026,NisanDegisim".ConvertToType<String>() });
            try
            {
                result.ExportExcel = Kuika.Common.Helpers.CsSystemFunctions.ExportExcel(request.value_0.ConvertToType<Object>(), "Rolex Kol Düğmesi 2 Yıl Arası Karşılaştırmalı Nisan Ayı Raporu".ConvertToType<String>(), "".ConvertToType<String>(), "Magaza,Nisan2025,Nisan2026,NisanDegisim".ConvertToType<String>());
                actionAuditExportExcel_0.SetResult(result.ExportExcel);
            }
            catch (Exception ex)
            {
                actionAuditExportExcel_0.SetException(ex);
                throw;
            }
;


            return Ok(result);
        }


        [HttpPost, Route("RolexOtherProductReportingComponent_824313_onClick")]
        public IActionResult RolexOtherProductReportingComponent_824313_onClick(RolexOtherProductReportingComponent_824313_onClick_Request request)
        {

            var result = new RolexOtherProductReportingComponent_824313_onClick_Response();


            using var auditExportExcel_0 = ActionAuditScope.Begin("c51613dc-a650-2e7d-7be9-d26b20fd6e94", "ExportExcel", applicationName: "wbTimesCRM", screenOrEndpointName: "RolexOtherProductReporting");
            using var actionAuditExportExcel_0 = ActionAuditHelper.Begin("ExportExcel", new { value = request.value_0.ConvertToType<Object>(), header = "Rolex Kol Düğmesi 2 Yıl Arası Karşılaştırmalı Mayıs Ayı Raporu".ConvertToType<String>(), footer = "".ConvertToType<String>(), columns = "Magaza,Mayis2025,Mayis2026,MayisDegisim".ConvertToType<String>() });
            try
            {
                result.ExportExcel = Kuika.Common.Helpers.CsSystemFunctions.ExportExcel(request.value_0.ConvertToType<Object>(), "Rolex Kol Düğmesi 2 Yıl Arası Karşılaştırmalı Mayıs Ayı Raporu".ConvertToType<String>(), "".ConvertToType<String>(), "Magaza,Mayis2025,Mayis2026,MayisDegisim".ConvertToType<String>());
                actionAuditExportExcel_0.SetResult(result.ExportExcel);
            }
            catch (Exception ex)
            {
                actionAuditExportExcel_0.SetException(ex);
                throw;
            }
;


            return Ok(result);
        }


        [HttpPost, Route("RolexOtherProductReportingComponent_551578_onClick")]
        public IActionResult RolexOtherProductReportingComponent_551578_onClick(RolexOtherProductReportingComponent_551578_onClick_Request request)
        {

            var result = new RolexOtherProductReportingComponent_551578_onClick_Response();


            using var auditExportExcel_0 = ActionAuditScope.Begin("a49f16bf-b265-98eb-398c-4e185e166a90", "ExportExcel", applicationName: "wbTimesCRM", screenOrEndpointName: "RolexOtherProductReporting");
            using var actionAuditExportExcel_0 = ActionAuditHelper.Begin("ExportExcel", new { value = request.value_0.ConvertToType<Object>(), header = "Rolex Kol Düğmesi 2 Yıl Arası Karşılaştırmalı Haziran Ayı Raporu".ConvertToType<String>(), footer = "".ConvertToType<String>(), columns = "Magaza,Haziran2025,Haziran2026,HaziranDegisim".ConvertToType<String>() });
            try
            {
                result.ExportExcel = Kuika.Common.Helpers.CsSystemFunctions.ExportExcel(request.value_0.ConvertToType<Object>(), "Rolex Kol Düğmesi 2 Yıl Arası Karşılaştırmalı Haziran Ayı Raporu".ConvertToType<String>(), "".ConvertToType<String>(), "Magaza,Haziran2025,Haziran2026,HaziranDegisim".ConvertToType<String>());
                actionAuditExportExcel_0.SetResult(result.ExportExcel);
            }
            catch (Exception ex)
            {
                actionAuditExportExcel_0.SetException(ex);
                throw;
            }
;


            return Ok(result);
        }


        [HttpPost, Route("RolexOtherProductReportingComponent_386843_onClick")]
        public IActionResult RolexOtherProductReportingComponent_386843_onClick(RolexOtherProductReportingComponent_386843_onClick_Request request)
        {

            var result = new RolexOtherProductReportingComponent_386843_onClick_Response();


            using var auditExportExcel_0 = ActionAuditScope.Begin("54920fe1-929d-c170-131c-c262ec54be4a", "ExportExcel", applicationName: "wbTimesCRM", screenOrEndpointName: "RolexOtherProductReporting");
            using var actionAuditExportExcel_0 = ActionAuditHelper.Begin("ExportExcel", new { value = request.value_0.ConvertToType<Object>(), header = "Rolex Kol Düğmesi 2 Yıl Arası Karşılaştırmalı Ocak Ayı Raporu".ConvertToType<String>(), footer = "".ConvertToType<String>(), columns = "Magaza,Temmuz2025,Temmuz2026,TemmuzDegisim".ConvertToType<String>() });
            try
            {
                result.ExportExcel = Kuika.Common.Helpers.CsSystemFunctions.ExportExcel(request.value_0.ConvertToType<Object>(), "Rolex Kol Düğmesi 2 Yıl Arası Karşılaştırmalı Ocak Ayı Raporu".ConvertToType<String>(), "".ConvertToType<String>(), "Magaza,Temmuz2025,Temmuz2026,TemmuzDegisim".ConvertToType<String>());
                actionAuditExportExcel_0.SetResult(result.ExportExcel);
            }
            catch (Exception ex)
            {
                actionAuditExportExcel_0.SetException(ex);
                throw;
            }
;


            return Ok(result);
        }


        [HttpPost, Route("RolexOtherProductReportingComponent_693420_onClick")]
        public IActionResult RolexOtherProductReportingComponent_693420_onClick(RolexOtherProductReportingComponent_693420_onClick_Request request)
        {

            var result = new RolexOtherProductReportingComponent_693420_onClick_Response();


            using var auditExportExcel_0 = ActionAuditScope.Begin("160d8eda-c2fa-55b3-bb81-8bd297cdca03", "ExportExcel", applicationName: "wbTimesCRM", screenOrEndpointName: "RolexOtherProductReporting");
            using var actionAuditExportExcel_0 = ActionAuditHelper.Begin("ExportExcel", new { value = request.value_0.ConvertToType<Object>(), header = "Rolex Kol Düğmesi 2 Yıl Arası Karşılaştırmalı Ağustos Ayı Raporu".ConvertToType<String>(), footer = "".ConvertToType<String>(), columns = "Magaza,Agustos2025,Agustos2026,AgustosDegisim".ConvertToType<String>() });
            try
            {
                result.ExportExcel = Kuika.Common.Helpers.CsSystemFunctions.ExportExcel(request.value_0.ConvertToType<Object>(), "Rolex Kol Düğmesi 2 Yıl Arası Karşılaştırmalı Ağustos Ayı Raporu".ConvertToType<String>(), "".ConvertToType<String>(), "Magaza,Agustos2025,Agustos2026,AgustosDegisim".ConvertToType<String>());
                actionAuditExportExcel_0.SetResult(result.ExportExcel);
            }
            catch (Exception ex)
            {
                actionAuditExportExcel_0.SetException(ex);
                throw;
            }
;


            return Ok(result);
        }


        [HttpPost, Route("RolexOtherProductReportingComponent_4525_onClick")]
        public IActionResult RolexOtherProductReportingComponent_4525_onClick(RolexOtherProductReportingComponent_4525_onClick_Request request)
        {

            var result = new RolexOtherProductReportingComponent_4525_onClick_Response();


            using var auditExportExcel_0 = ActionAuditScope.Begin("1a7eb943-3c9e-4b90-b99a-90a4b4cfdf3a", "ExportExcel", applicationName: "wbTimesCRM", screenOrEndpointName: "RolexOtherProductReporting");
            using var actionAuditExportExcel_0 = ActionAuditHelper.Begin("ExportExcel", new { value = request.value_0.ConvertToType<Object>(), header = "Rolex Kol Düğmesi 2 Yıl Arası Karşılaştırmalı Eylül Ayı Raporu".ConvertToType<String>(), footer = "".ConvertToType<String>(), columns = "Magaza,Eylul2025,Eylul2026,EylulDegisim".ConvertToType<String>() });
            try
            {
                result.ExportExcel = Kuika.Common.Helpers.CsSystemFunctions.ExportExcel(request.value_0.ConvertToType<Object>(), "Rolex Kol Düğmesi 2 Yıl Arası Karşılaştırmalı Eylül Ayı Raporu".ConvertToType<String>(), "".ConvertToType<String>(), "Magaza,Eylul2025,Eylul2026,EylulDegisim".ConvertToType<String>());
                actionAuditExportExcel_0.SetResult(result.ExportExcel);
            }
            catch (Exception ex)
            {
                actionAuditExportExcel_0.SetException(ex);
                throw;
            }
;


            return Ok(result);
        }


        [HttpPost, Route("RolexOtherProductReportingComponent_213735_onClick")]
        public IActionResult RolexOtherProductReportingComponent_213735_onClick(RolexOtherProductReportingComponent_213735_onClick_Request request)
        {

            var result = new RolexOtherProductReportingComponent_213735_onClick_Response();


            using var auditExportExcel_0 = ActionAuditScope.Begin("e1896bea-c09d-d46f-684c-dc328023eca3", "ExportExcel", applicationName: "wbTimesCRM", screenOrEndpointName: "RolexOtherProductReporting");
            using var actionAuditExportExcel_0 = ActionAuditHelper.Begin("ExportExcel", new { value = request.value_0.ConvertToType<Object>(), header = "Rolex Kol Düğmesi 2 Yıl Arası Karşılaştırmalı Ekim Ayı Raporu".ConvertToType<String>(), footer = "".ConvertToType<String>(), columns = "Magaza,Ekim2025,Ekim2026,EkimDegisim".ConvertToType<String>() });
            try
            {
                result.ExportExcel = Kuika.Common.Helpers.CsSystemFunctions.ExportExcel(request.value_0.ConvertToType<Object>(), "Rolex Kol Düğmesi 2 Yıl Arası Karşılaştırmalı Ekim Ayı Raporu".ConvertToType<String>(), "".ConvertToType<String>(), "Magaza,Ekim2025,Ekim2026,EkimDegisim".ConvertToType<String>());
                actionAuditExportExcel_0.SetResult(result.ExportExcel);
            }
            catch (Exception ex)
            {
                actionAuditExportExcel_0.SetException(ex);
                throw;
            }
;


            return Ok(result);
        }


        [HttpPost, Route("RolexOtherProductReportingComponent_27453_onClick")]
        public IActionResult RolexOtherProductReportingComponent_27453_onClick(RolexOtherProductReportingComponent_27453_onClick_Request request)
        {

            var result = new RolexOtherProductReportingComponent_27453_onClick_Response();


            using var auditExportExcel_0 = ActionAuditScope.Begin("8a055e14-f916-4fa1-ef3d-8b72afdf6669", "ExportExcel", applicationName: "wbTimesCRM", screenOrEndpointName: "RolexOtherProductReporting");
            using var actionAuditExportExcel_0 = ActionAuditHelper.Begin("ExportExcel", new { value = request.value_0.ConvertToType<Object>(), header = "Rolex Kol Düğmesi 2 Yıl Arası Karşılaştırmalı Kasım Ayı Raporu".ConvertToType<String>(), footer = "".ConvertToType<String>(), columns = "Magaza,Kasim2025,Kasim2026,KasimDegisim".ConvertToType<String>() });
            try
            {
                result.ExportExcel = Kuika.Common.Helpers.CsSystemFunctions.ExportExcel(request.value_0.ConvertToType<Object>(), "Rolex Kol Düğmesi 2 Yıl Arası Karşılaştırmalı Kasım Ayı Raporu".ConvertToType<String>(), "".ConvertToType<String>(), "Magaza,Kasim2025,Kasim2026,KasimDegisim".ConvertToType<String>());
                actionAuditExportExcel_0.SetResult(result.ExportExcel);
            }
            catch (Exception ex)
            {
                actionAuditExportExcel_0.SetException(ex);
                throw;
            }
;


            return Ok(result);
        }


        [HttpPost, Route("RolexOtherProductReportingComponent_603178_onClick")]
        public IActionResult RolexOtherProductReportingComponent_603178_onClick(RolexOtherProductReportingComponent_603178_onClick_Request request)
        {

            var result = new RolexOtherProductReportingComponent_603178_onClick_Response();


            using var auditExportExcel_0 = ActionAuditScope.Begin("c75abcce-1eb0-2b29-f033-0564ab97fc52", "ExportExcel", applicationName: "wbTimesCRM", screenOrEndpointName: "RolexOtherProductReporting");
            using var actionAuditExportExcel_0 = ActionAuditHelper.Begin("ExportExcel", new { value = request.value_0.ConvertToType<Object>(), header = "Rolex Kol Düğmesi 2 Yıl Arası Karşılaştırmalı Aralık Ayı Raporu".ConvertToType<String>(), footer = "".ConvertToType<String>(), columns = "Magaza,Aralik2025,Aralik2026,AralikDegisim".ConvertToType<String>() });
            try
            {
                result.ExportExcel = Kuika.Common.Helpers.CsSystemFunctions.ExportExcel(request.value_0.ConvertToType<Object>(), "Rolex Kol Düğmesi 2 Yıl Arası Karşılaştırmalı Aralık Ayı Raporu".ConvertToType<String>(), "".ConvertToType<String>(), "Magaza,Aralik2025,Aralik2026,AralikDegisim".ConvertToType<String>());
                actionAuditExportExcel_0.SetResult(result.ExportExcel);
            }
            catch (Exception ex)
            {
                actionAuditExportExcel_0.SetException(ex);
                throw;
            }
;


            return Ok(result);
        }


        [HttpPost, Route("RolexOtherProductReportingComponent_736558_onClick")]
        public IActionResult RolexOtherProductReportingComponent_736558_onClick(RolexOtherProductReportingComponent_736558_onClick_Request request)
        {

            var result = new RolexOtherProductReportingComponent_736558_onClick_Response();


            using var auditKuikaY_RolexGrupAylikSatisKarsilastirma_S2_0 = ActionAuditScope.Begin("22025ae5-2f02-f99a-8f23-b159edc6f229", "KuikaY_RolexGrupAylikSatisKarsilastirma_S2", applicationName: "wbTimesCRM", screenOrEndpointName: "RolexOtherProductReporting");
            using var actionAuditKuikaY_RolexGrupAylikSatisKarsilastirma_S2_0 = ActionAuditHelper.Begin("KuikaY_RolexGrupAylikSatisKarsilastirma_S2", new { Brand = "Rolex".ConvertToType<String>(), ProductGroup = "Kitap".ConvertToType<String>(), Year1 = request.Year1_0.ConvertToType<Int32>(), Year2 = request.Year2_0.ConvertToType<Int32>() });
            try
            {
                result.KuikaY_RolexGrupAylikSatisKarsilastirma_S2 = Kuika.ThirdPartyApisCollection.Reports.KuikaY_RolexGrupAylikSatisKarsilastirma("Rolex".ConvertToType<String>(), "Kitap".ConvertToType<String>(), request.Year1_0.ConvertToType<Int32>(), request.Year2_0.ConvertToType<Int32>());
                actionAuditKuikaY_RolexGrupAylikSatisKarsilastirma_S2_0.SetResult(result.KuikaY_RolexGrupAylikSatisKarsilastirma_S2);
            }
            catch (Exception ex)
            {
                actionAuditKuikaY_RolexGrupAylikSatisKarsilastirma_S2_0.SetException(ex);
                throw;
            }
;


            return Ok(result);
        }


        [HttpPost, Route("RolexOtherProductReportingComponent_338196_onClick")]
        public IActionResult RolexOtherProductReportingComponent_338196_onClick(RolexOtherProductReportingComponent_338196_onClick_Request request)
        {

            var result = new RolexOtherProductReportingComponent_338196_onClick_Response();


            using var auditExportExcel_0 = ActionAuditScope.Begin("1d2d033b-377a-ab9c-ba07-d6b8ca42cfac", "ExportExcel", applicationName: "wbTimesCRM", screenOrEndpointName: "RolexOtherProductReporting");
            using var actionAuditExportExcel_0 = ActionAuditHelper.Begin("ExportExcel", new { value = request.value_0.ConvertToType<Object>(), header = "Rolex Kitap 2 Yıl Arası Karşılaştırmalı Ay Bazlı Rapor".ConvertToType<String>(), footer = "".ConvertToType<String>(), columns = "".ConvertToType<String>() });
            try
            {
                result.ExportExcel = Kuika.Common.Helpers.CsSystemFunctions.ExportExcel(request.value_0.ConvertToType<Object>(), "Rolex Kitap 2 Yıl Arası Karşılaştırmalı Ay Bazlı Rapor".ConvertToType<String>(), "".ConvertToType<String>(), "".ConvertToType<String>());
                actionAuditExportExcel_0.SetResult(result.ExportExcel);
            }
            catch (Exception ex)
            {
                actionAuditExportExcel_0.SetException(ex);
                throw;
            }
;


            return Ok(result);
        }


        [HttpPost, Route("RolexOtherProductReportingComponent_447049_onClick")]
        public IActionResult RolexOtherProductReportingComponent_447049_onClick(RolexOtherProductReportingComponent_447049_onClick_Request request)
        {

            var result = new RolexOtherProductReportingComponent_447049_onClick_Response();


            using var auditExportExcel_0 = ActionAuditScope.Begin("39160aa1-a5f1-c5d8-2bbb-c33033762a80", "ExportExcel", applicationName: "wbTimesCRM", screenOrEndpointName: "RolexOtherProductReporting");
            using var actionAuditExportExcel_0 = ActionAuditHelper.Begin("ExportExcel", new { value = request.value_0.ConvertToType<Object>(), header = "Rolex Kitap 2 Yıl Arası Karşılaştırmalı Ocak Ayı Raporu".ConvertToType<String>(), footer = "".ConvertToType<String>(), columns = "Magaza,Ocak2025,Ocak2026,OcakDegisim".ConvertToType<String>() });
            try
            {
                result.ExportExcel = Kuika.Common.Helpers.CsSystemFunctions.ExportExcel(request.value_0.ConvertToType<Object>(), "Rolex Kitap 2 Yıl Arası Karşılaştırmalı Ocak Ayı Raporu".ConvertToType<String>(), "".ConvertToType<String>(), "Magaza,Ocak2025,Ocak2026,OcakDegisim".ConvertToType<String>());
                actionAuditExportExcel_0.SetResult(result.ExportExcel);
            }
            catch (Exception ex)
            {
                actionAuditExportExcel_0.SetException(ex);
                throw;
            }
;


            return Ok(result);
        }


        [HttpPost, Route("RolexOtherProductReportingComponent_124225_onClick")]
        public IActionResult RolexOtherProductReportingComponent_124225_onClick(RolexOtherProductReportingComponent_124225_onClick_Request request)
        {

            var result = new RolexOtherProductReportingComponent_124225_onClick_Response();


            using var auditExportExcel_0 = ActionAuditScope.Begin("755cf25c-d9ae-a712-6b14-a4046f3402c1", "ExportExcel", applicationName: "wbTimesCRM", screenOrEndpointName: "RolexOtherProductReporting");
            using var actionAuditExportExcel_0 = ActionAuditHelper.Begin("ExportExcel", new { value = request.value_0.ConvertToType<Object>(), header = "Rolex Kitap 2 Yıl Arası Karşılaştırmalı Şubat Ayı Raporu".ConvertToType<String>(), footer = "".ConvertToType<String>(), columns = "Magaza,Subat2025,Subat2026,SubatDegisim".ConvertToType<String>() });
            try
            {
                result.ExportExcel = Kuika.Common.Helpers.CsSystemFunctions.ExportExcel(request.value_0.ConvertToType<Object>(), "Rolex Kitap 2 Yıl Arası Karşılaştırmalı Şubat Ayı Raporu".ConvertToType<String>(), "".ConvertToType<String>(), "Magaza,Subat2025,Subat2026,SubatDegisim".ConvertToType<String>());
                actionAuditExportExcel_0.SetResult(result.ExportExcel);
            }
            catch (Exception ex)
            {
                actionAuditExportExcel_0.SetException(ex);
                throw;
            }
;


            return Ok(result);
        }


        [HttpPost, Route("RolexOtherProductReportingComponent_865445_onClick")]
        public IActionResult RolexOtherProductReportingComponent_865445_onClick(RolexOtherProductReportingComponent_865445_onClick_Request request)
        {

            var result = new RolexOtherProductReportingComponent_865445_onClick_Response();


            using var auditExportExcel_0 = ActionAuditScope.Begin("0f4a633b-d7b5-11c9-587e-8c8af73c448e", "ExportExcel", applicationName: "wbTimesCRM", screenOrEndpointName: "RolexOtherProductReporting");
            using var actionAuditExportExcel_0 = ActionAuditHelper.Begin("ExportExcel", new { value = request.value_0.ConvertToType<Object>(), header = "Rolex Kitap 2 Yıl Arası Karşılaştırmalı Mart Ayı Raporu".ConvertToType<String>(), footer = "".ConvertToType<String>(), columns = "Magaza,Mart2025,Mart2026,MartDegisim".ConvertToType<String>() });
            try
            {
                result.ExportExcel = Kuika.Common.Helpers.CsSystemFunctions.ExportExcel(request.value_0.ConvertToType<Object>(), "Rolex Kitap 2 Yıl Arası Karşılaştırmalı Mart Ayı Raporu".ConvertToType<String>(), "".ConvertToType<String>(), "Magaza,Mart2025,Mart2026,MartDegisim".ConvertToType<String>());
                actionAuditExportExcel_0.SetResult(result.ExportExcel);
            }
            catch (Exception ex)
            {
                actionAuditExportExcel_0.SetException(ex);
                throw;
            }
;


            return Ok(result);
        }


        [HttpPost, Route("RolexOtherProductReportingComponent_172862_onClick")]
        public IActionResult RolexOtherProductReportingComponent_172862_onClick(RolexOtherProductReportingComponent_172862_onClick_Request request)
        {

            var result = new RolexOtherProductReportingComponent_172862_onClick_Response();


            using var auditExportExcel_0 = ActionAuditScope.Begin("b5cef540-2cbb-17e8-2f96-1d41daf7cabd", "ExportExcel", applicationName: "wbTimesCRM", screenOrEndpointName: "RolexOtherProductReporting");
            using var actionAuditExportExcel_0 = ActionAuditHelper.Begin("ExportExcel", new { value = request.value_0.ConvertToType<Object>(), header = "Rolex Kitap 2 Yıl Arası Karşılaştırmalı Nisan Ayı Raporu".ConvertToType<String>(), footer = "".ConvertToType<String>(), columns = "Magaza,Nisan2025,Nisan2026,NisanDegisim".ConvertToType<String>() });
            try
            {
                result.ExportExcel = Kuika.Common.Helpers.CsSystemFunctions.ExportExcel(request.value_0.ConvertToType<Object>(), "Rolex Kitap 2 Yıl Arası Karşılaştırmalı Nisan Ayı Raporu".ConvertToType<String>(), "".ConvertToType<String>(), "Magaza,Nisan2025,Nisan2026,NisanDegisim".ConvertToType<String>());
                actionAuditExportExcel_0.SetResult(result.ExportExcel);
            }
            catch (Exception ex)
            {
                actionAuditExportExcel_0.SetException(ex);
                throw;
            }
;


            return Ok(result);
        }


        [HttpPost, Route("RolexOtherProductReportingComponent_851110_onClick")]
        public IActionResult RolexOtherProductReportingComponent_851110_onClick(RolexOtherProductReportingComponent_851110_onClick_Request request)
        {

            var result = new RolexOtherProductReportingComponent_851110_onClick_Response();


            using var auditExportExcel_0 = ActionAuditScope.Begin("5f5a5945-0603-5d73-17d0-47c378072005", "ExportExcel", applicationName: "wbTimesCRM", screenOrEndpointName: "RolexOtherProductReporting");
            using var actionAuditExportExcel_0 = ActionAuditHelper.Begin("ExportExcel", new { value = request.value_0.ConvertToType<Object>(), header = "Rolex Kitap 2 Yıl Arası Karşılaştırmalı Mayıs Ayı Raporu".ConvertToType<String>(), footer = "".ConvertToType<String>(), columns = "Magaza,Mayis2025,Mayis2026,MayisDegisim".ConvertToType<String>() });
            try
            {
                result.ExportExcel = Kuika.Common.Helpers.CsSystemFunctions.ExportExcel(request.value_0.ConvertToType<Object>(), "Rolex Kitap 2 Yıl Arası Karşılaştırmalı Mayıs Ayı Raporu".ConvertToType<String>(), "".ConvertToType<String>(), "Magaza,Mayis2025,Mayis2026,MayisDegisim".ConvertToType<String>());
                actionAuditExportExcel_0.SetResult(result.ExportExcel);
            }
            catch (Exception ex)
            {
                actionAuditExportExcel_0.SetException(ex);
                throw;
            }
;


            return Ok(result);
        }


        [HttpPost, Route("RolexOtherProductReportingComponent_56305_onClick")]
        public IActionResult RolexOtherProductReportingComponent_56305_onClick(RolexOtherProductReportingComponent_56305_onClick_Request request)
        {

            var result = new RolexOtherProductReportingComponent_56305_onClick_Response();


            using var auditExportExcel_0 = ActionAuditScope.Begin("7f9d136b-106d-bdae-5091-876a51aa58e2", "ExportExcel", applicationName: "wbTimesCRM", screenOrEndpointName: "RolexOtherProductReporting");
            using var actionAuditExportExcel_0 = ActionAuditHelper.Begin("ExportExcel", new { value = request.value_0.ConvertToType<Object>(), header = "Rolex Kitap 2 Yıl Arası Karşılaştırmalı Haziran Ayı Raporu".ConvertToType<String>(), footer = "".ConvertToType<String>(), columns = "Magaza,Haziran2025,Haziran2026,HaziranDegisim".ConvertToType<String>() });
            try
            {
                result.ExportExcel = Kuika.Common.Helpers.CsSystemFunctions.ExportExcel(request.value_0.ConvertToType<Object>(), "Rolex Kitap 2 Yıl Arası Karşılaştırmalı Haziran Ayı Raporu".ConvertToType<String>(), "".ConvertToType<String>(), "Magaza,Haziran2025,Haziran2026,HaziranDegisim".ConvertToType<String>());
                actionAuditExportExcel_0.SetResult(result.ExportExcel);
            }
            catch (Exception ex)
            {
                actionAuditExportExcel_0.SetException(ex);
                throw;
            }
;


            return Ok(result);
        }


        [HttpPost, Route("RolexOtherProductReportingComponent_280884_onClick")]
        public IActionResult RolexOtherProductReportingComponent_280884_onClick(RolexOtherProductReportingComponent_280884_onClick_Request request)
        {

            var result = new RolexOtherProductReportingComponent_280884_onClick_Response();


            using var auditExportExcel_0 = ActionAuditScope.Begin("6bc6b07e-fda8-5a2d-ad30-3442b00d5390", "ExportExcel", applicationName: "wbTimesCRM", screenOrEndpointName: "RolexOtherProductReporting");
            using var actionAuditExportExcel_0 = ActionAuditHelper.Begin("ExportExcel", new { value = request.value_0.ConvertToType<Object>(), header = "Rolex Kitap 2 Yıl Arası Karşılaştırmalı Temmuz Ayı Raporu".ConvertToType<String>(), footer = "".ConvertToType<String>(), columns = "Magaza,Temmuz2025,Temmuz2026,TemmuzDegisim".ConvertToType<String>() });
            try
            {
                result.ExportExcel = Kuika.Common.Helpers.CsSystemFunctions.ExportExcel(request.value_0.ConvertToType<Object>(), "Rolex Kitap 2 Yıl Arası Karşılaştırmalı Temmuz Ayı Raporu".ConvertToType<String>(), "".ConvertToType<String>(), "Magaza,Temmuz2025,Temmuz2026,TemmuzDegisim".ConvertToType<String>());
                actionAuditExportExcel_0.SetResult(result.ExportExcel);
            }
            catch (Exception ex)
            {
                actionAuditExportExcel_0.SetException(ex);
                throw;
            }
;


            return Ok(result);
        }


        [HttpPost, Route("RolexOtherProductReportingComponent_856979_onClick")]
        public IActionResult RolexOtherProductReportingComponent_856979_onClick(RolexOtherProductReportingComponent_856979_onClick_Request request)
        {

            var result = new RolexOtherProductReportingComponent_856979_onClick_Response();


            using var auditExportExcel_0 = ActionAuditScope.Begin("4c61f11b-8127-b74c-3a7a-baf92b22c66a", "ExportExcel", applicationName: "wbTimesCRM", screenOrEndpointName: "RolexOtherProductReporting");
            using var actionAuditExportExcel_0 = ActionAuditHelper.Begin("ExportExcel", new { value = request.value_0.ConvertToType<Object>(), header = "Rolex Kitap 2 Yıl Arası Karşılaştırmalı Ağustos Ayı Raporu".ConvertToType<String>(), footer = "".ConvertToType<String>(), columns = "Magaza,Agustos2025,Agustos2026,AgustosDegisim".ConvertToType<String>() });
            try
            {
                result.ExportExcel = Kuika.Common.Helpers.CsSystemFunctions.ExportExcel(request.value_0.ConvertToType<Object>(), "Rolex Kitap 2 Yıl Arası Karşılaştırmalı Ağustos Ayı Raporu".ConvertToType<String>(), "".ConvertToType<String>(), "Magaza,Agustos2025,Agustos2026,AgustosDegisim".ConvertToType<String>());
                actionAuditExportExcel_0.SetResult(result.ExportExcel);
            }
            catch (Exception ex)
            {
                actionAuditExportExcel_0.SetException(ex);
                throw;
            }
;


            return Ok(result);
        }


        [HttpPost, Route("RolexOtherProductReportingComponent_609731_onClick")]
        public IActionResult RolexOtherProductReportingComponent_609731_onClick(RolexOtherProductReportingComponent_609731_onClick_Request request)
        {

            var result = new RolexOtherProductReportingComponent_609731_onClick_Response();


            using var auditExportExcel_0 = ActionAuditScope.Begin("863157f0-81ca-3b5b-17aa-59c183ef9392", "ExportExcel", applicationName: "wbTimesCRM", screenOrEndpointName: "RolexOtherProductReporting");
            using var actionAuditExportExcel_0 = ActionAuditHelper.Begin("ExportExcel", new { value = request.value_0.ConvertToType<Object>(), header = "Rolex Kitap 2 Yıl Arası Karşılaştırmalı Eylül Ayı Raporu".ConvertToType<String>(), footer = "".ConvertToType<String>(), columns = "Magaza,Eylul2025,Eylul2026,EylulDegisim".ConvertToType<String>() });
            try
            {
                result.ExportExcel = Kuika.Common.Helpers.CsSystemFunctions.ExportExcel(request.value_0.ConvertToType<Object>(), "Rolex Kitap 2 Yıl Arası Karşılaştırmalı Eylül Ayı Raporu".ConvertToType<String>(), "".ConvertToType<String>(), "Magaza,Eylul2025,Eylul2026,EylulDegisim".ConvertToType<String>());
                actionAuditExportExcel_0.SetResult(result.ExportExcel);
            }
            catch (Exception ex)
            {
                actionAuditExportExcel_0.SetException(ex);
                throw;
            }
;


            return Ok(result);
        }


        [HttpPost, Route("RolexOtherProductReportingComponent_446473_onClick")]
        public IActionResult RolexOtherProductReportingComponent_446473_onClick(RolexOtherProductReportingComponent_446473_onClick_Request request)
        {

            var result = new RolexOtherProductReportingComponent_446473_onClick_Response();


            using var auditExportExcel_0 = ActionAuditScope.Begin("5277f970-63f0-c87a-551d-040796892a2b", "ExportExcel", applicationName: "wbTimesCRM", screenOrEndpointName: "RolexOtherProductReporting");
            using var actionAuditExportExcel_0 = ActionAuditHelper.Begin("ExportExcel", new { value = request.value_0.ConvertToType<Object>(), header = "Rolex Kitap 2 Yıl Arası Karşılaştırmalı Ekim Ayı Raporu".ConvertToType<String>(), footer = "".ConvertToType<String>(), columns = "Magaza,Ekim2025,Ekim2026,EkimDegisim".ConvertToType<String>() });
            try
            {
                result.ExportExcel = Kuika.Common.Helpers.CsSystemFunctions.ExportExcel(request.value_0.ConvertToType<Object>(), "Rolex Kitap 2 Yıl Arası Karşılaştırmalı Ekim Ayı Raporu".ConvertToType<String>(), "".ConvertToType<String>(), "Magaza,Ekim2025,Ekim2026,EkimDegisim".ConvertToType<String>());
                actionAuditExportExcel_0.SetResult(result.ExportExcel);
            }
            catch (Exception ex)
            {
                actionAuditExportExcel_0.SetException(ex);
                throw;
            }
;


            return Ok(result);
        }


        [HttpPost, Route("RolexOtherProductReportingComponent_487226_onClick")]
        public IActionResult RolexOtherProductReportingComponent_487226_onClick(RolexOtherProductReportingComponent_487226_onClick_Request request)
        {

            var result = new RolexOtherProductReportingComponent_487226_onClick_Response();


            using var auditExportExcel_0 = ActionAuditScope.Begin("6a025f2a-71dc-73de-ce1e-4d19885494cb", "ExportExcel", applicationName: "wbTimesCRM", screenOrEndpointName: "RolexOtherProductReporting");
            using var actionAuditExportExcel_0 = ActionAuditHelper.Begin("ExportExcel", new { value = request.value_0.ConvertToType<Object>(), header = "Rolex Kitap 2 Yıl Arası Karşılaştırmalı Kasım Ayı Raporu".ConvertToType<String>(), footer = "".ConvertToType<String>(), columns = "Magaza,Kasim2025,Kasim2026,KasimDegisim".ConvertToType<String>() });
            try
            {
                result.ExportExcel = Kuika.Common.Helpers.CsSystemFunctions.ExportExcel(request.value_0.ConvertToType<Object>(), "Rolex Kitap 2 Yıl Arası Karşılaştırmalı Kasım Ayı Raporu".ConvertToType<String>(), "".ConvertToType<String>(), "Magaza,Kasim2025,Kasim2026,KasimDegisim".ConvertToType<String>());
                actionAuditExportExcel_0.SetResult(result.ExportExcel);
            }
            catch (Exception ex)
            {
                actionAuditExportExcel_0.SetException(ex);
                throw;
            }
;


            return Ok(result);
        }


        [HttpPost, Route("RolexOtherProductReportingComponent_376198_onClick")]
        public IActionResult RolexOtherProductReportingComponent_376198_onClick(RolexOtherProductReportingComponent_376198_onClick_Request request)
        {

            var result = new RolexOtherProductReportingComponent_376198_onClick_Response();


            using var auditExportExcel_0 = ActionAuditScope.Begin("3d25285f-1af1-f1f9-111f-e8647ddc44ef", "ExportExcel", applicationName: "wbTimesCRM", screenOrEndpointName: "RolexOtherProductReporting");
            using var actionAuditExportExcel_0 = ActionAuditHelper.Begin("ExportExcel", new { value = request.value_0.ConvertToType<Object>(), header = "Rolex Kitap 2 Yıl Arası Karşılaştırmalı Aralık Ayı Raporu".ConvertToType<String>(), footer = "".ConvertToType<String>(), columns = "Magaza,Aralik2025,Aralik2026,AralikDegisim".ConvertToType<String>() });
            try
            {
                result.ExportExcel = Kuika.Common.Helpers.CsSystemFunctions.ExportExcel(request.value_0.ConvertToType<Object>(), "Rolex Kitap 2 Yıl Arası Karşılaştırmalı Aralık Ayı Raporu".ConvertToType<String>(), "".ConvertToType<String>(), "Magaza,Aralik2025,Aralik2026,AralikDegisim".ConvertToType<String>());
                actionAuditExportExcel_0.SetResult(result.ExportExcel);
            }
            catch (Exception ex)
            {
                actionAuditExportExcel_0.SetException(ex);
                throw;
            }
;


            return Ok(result);
        }


        [HttpPost, Route("RolexOtherProductReportingComponent_558385_onClick")]
        public IActionResult RolexOtherProductReportingComponent_558385_onClick(RolexOtherProductReportingComponent_558385_onClick_Request request)
        {

            var result = new RolexOtherProductReportingComponent_558385_onClick_Response();


            using var auditKuikaY_RolexGrupAylikSatisKarsilastirma_S3_0 = ActionAuditScope.Begin("b46f5627-404f-7837-2e77-886d29b6a1a6", "KuikaY_RolexGrupAylikSatisKarsilastirma_S3", applicationName: "wbTimesCRM", screenOrEndpointName: "RolexOtherProductReporting");
            using var actionAuditKuikaY_RolexGrupAylikSatisKarsilastirma_S3_0 = ActionAuditHelper.Begin("KuikaY_RolexGrupAylikSatisKarsilastirma_S3", new { Brand = "Rolex".ConvertToType<String>(), ProductGroup = "Masa Saati".ConvertToType<String>(), Year1 = request.Year1_0.ConvertToType<Int32>(), Year2 = request.Year2_0.ConvertToType<Int32>() });
            try
            {
                result.KuikaY_RolexGrupAylikSatisKarsilastirma_S3 = Kuika.ThirdPartyApisCollection.Reports.KuikaY_RolexGrupAylikSatisKarsilastirma("Rolex".ConvertToType<String>(), "Masa Saati".ConvertToType<String>(), request.Year1_0.ConvertToType<Int32>(), request.Year2_0.ConvertToType<Int32>());
                actionAuditKuikaY_RolexGrupAylikSatisKarsilastirma_S3_0.SetResult(result.KuikaY_RolexGrupAylikSatisKarsilastirma_S3);
            }
            catch (Exception ex)
            {
                actionAuditKuikaY_RolexGrupAylikSatisKarsilastirma_S3_0.SetException(ex);
                throw;
            }
;


            return Ok(result);
        }


        [HttpPost, Route("RolexOtherProductReportingComponent_142785_onClick")]
        public IActionResult RolexOtherProductReportingComponent_142785_onClick(RolexOtherProductReportingComponent_142785_onClick_Request request)
        {

            var result = new RolexOtherProductReportingComponent_142785_onClick_Response();


            using var auditExportExcel_0 = ActionAuditScope.Begin("86b3477d-ec8c-fb42-374b-f8def6b84646", "ExportExcel", applicationName: "wbTimesCRM", screenOrEndpointName: "RolexOtherProductReporting");
            using var actionAuditExportExcel_0 = ActionAuditHelper.Begin("ExportExcel", new { value = request.value_0.ConvertToType<Object>(), header = "Rolex Masa Saati 2 Yıl Arası Karşılaştırmalı Ay Bazlı Rapor".ConvertToType<String>(), footer = "".ConvertToType<String>(), columns = "".ConvertToType<String>() });
            try
            {
                result.ExportExcel = Kuika.Common.Helpers.CsSystemFunctions.ExportExcel(request.value_0.ConvertToType<Object>(), "Rolex Masa Saati 2 Yıl Arası Karşılaştırmalı Ay Bazlı Rapor".ConvertToType<String>(), "".ConvertToType<String>(), "".ConvertToType<String>());
                actionAuditExportExcel_0.SetResult(result.ExportExcel);
            }
            catch (Exception ex)
            {
                actionAuditExportExcel_0.SetException(ex);
                throw;
            }
;


            return Ok(result);
        }


        [HttpPost, Route("RolexOtherProductReportingComponent_408362_onClick")]
        public IActionResult RolexOtherProductReportingComponent_408362_onClick(RolexOtherProductReportingComponent_408362_onClick_Request request)
        {

            var result = new RolexOtherProductReportingComponent_408362_onClick_Response();


            using var auditExportExcel_0 = ActionAuditScope.Begin("8ceda530-0580-cd9c-c8a7-d38a27bd85c6", "ExportExcel", applicationName: "wbTimesCRM", screenOrEndpointName: "RolexOtherProductReporting");
            using var actionAuditExportExcel_0 = ActionAuditHelper.Begin("ExportExcel", new { value = request.value_0.ConvertToType<Object>(), header = "Rolex Masa Saati 2 Yıl Arası Karşılaştırmalı Ocak Ayı Raporu".ConvertToType<String>(), footer = "".ConvertToType<String>(), columns = "Magaza,Ocak2025,Ocak2026,OcakDegisim".ConvertToType<String>() });
            try
            {
                result.ExportExcel = Kuika.Common.Helpers.CsSystemFunctions.ExportExcel(request.value_0.ConvertToType<Object>(), "Rolex Masa Saati 2 Yıl Arası Karşılaştırmalı Ocak Ayı Raporu".ConvertToType<String>(), "".ConvertToType<String>(), "Magaza,Ocak2025,Ocak2026,OcakDegisim".ConvertToType<String>());
                actionAuditExportExcel_0.SetResult(result.ExportExcel);
            }
            catch (Exception ex)
            {
                actionAuditExportExcel_0.SetException(ex);
                throw;
            }
;


            return Ok(result);
        }


        [HttpPost, Route("RolexOtherProductReportingComponent_243711_onClick")]
        public IActionResult RolexOtherProductReportingComponent_243711_onClick(RolexOtherProductReportingComponent_243711_onClick_Request request)
        {

            var result = new RolexOtherProductReportingComponent_243711_onClick_Response();


            using var auditExportExcel_0 = ActionAuditScope.Begin("e94f2e88-4e6b-aa2a-8974-5a485e9731b5", "ExportExcel", applicationName: "wbTimesCRM", screenOrEndpointName: "RolexOtherProductReporting");
            using var actionAuditExportExcel_0 = ActionAuditHelper.Begin("ExportExcel", new { value = request.value_0.ConvertToType<Object>(), header = "Rolex Masa Saati 2 Yıl Arası Karşılaştırmalı Şubat Ayı Raporu".ConvertToType<String>(), footer = "".ConvertToType<String>(), columns = "Magaza,Subat2025,Subat2026,SubatDegisim".ConvertToType<String>() });
            try
            {
                result.ExportExcel = Kuika.Common.Helpers.CsSystemFunctions.ExportExcel(request.value_0.ConvertToType<Object>(), "Rolex Masa Saati 2 Yıl Arası Karşılaştırmalı Şubat Ayı Raporu".ConvertToType<String>(), "".ConvertToType<String>(), "Magaza,Subat2025,Subat2026,SubatDegisim".ConvertToType<String>());
                actionAuditExportExcel_0.SetResult(result.ExportExcel);
            }
            catch (Exception ex)
            {
                actionAuditExportExcel_0.SetException(ex);
                throw;
            }
;


            return Ok(result);
        }


        [HttpPost, Route("RolexOtherProductReportingComponent_101219_onClick")]
        public IActionResult RolexOtherProductReportingComponent_101219_onClick(RolexOtherProductReportingComponent_101219_onClick_Request request)
        {

            var result = new RolexOtherProductReportingComponent_101219_onClick_Response();


            using var auditExportExcel_0 = ActionAuditScope.Begin("91ce5608-cfcb-ab85-673e-be4731fca3ee", "ExportExcel", applicationName: "wbTimesCRM", screenOrEndpointName: "RolexOtherProductReporting");
            using var actionAuditExportExcel_0 = ActionAuditHelper.Begin("ExportExcel", new { value = request.value_0.ConvertToType<Object>(), header = "Rolex Masa Saati 2 Yıl Arası Karşılaştırmalı Mart Ayı Raporu".ConvertToType<String>(), footer = "".ConvertToType<String>(), columns = "Magaza,Mart2025,Mart2026,MartDegisim".ConvertToType<String>() });
            try
            {
                result.ExportExcel = Kuika.Common.Helpers.CsSystemFunctions.ExportExcel(request.value_0.ConvertToType<Object>(), "Rolex Masa Saati 2 Yıl Arası Karşılaştırmalı Mart Ayı Raporu".ConvertToType<String>(), "".ConvertToType<String>(), "Magaza,Mart2025,Mart2026,MartDegisim".ConvertToType<String>());
                actionAuditExportExcel_0.SetResult(result.ExportExcel);
            }
            catch (Exception ex)
            {
                actionAuditExportExcel_0.SetException(ex);
                throw;
            }
;


            return Ok(result);
        }


        [HttpPost, Route("RolexOtherProductReportingComponent_141570_onClick")]
        public IActionResult RolexOtherProductReportingComponent_141570_onClick(RolexOtherProductReportingComponent_141570_onClick_Request request)
        {

            var result = new RolexOtherProductReportingComponent_141570_onClick_Response();


            using var auditExportExcel_0 = ActionAuditScope.Begin("3b82d23e-025d-95b1-6fed-43f50776bb4c", "ExportExcel", applicationName: "wbTimesCRM", screenOrEndpointName: "RolexOtherProductReporting");
            using var actionAuditExportExcel_0 = ActionAuditHelper.Begin("ExportExcel", new { value = request.value_0.ConvertToType<Object>(), header = "Rolex Masa Saati 2 Yıl Arası Karşılaştırmalı Nisan Ayı Raporu".ConvertToType<String>(), footer = "".ConvertToType<String>(), columns = "Magaza,Nisan2025,Nisan2026,NisanDegisim".ConvertToType<String>() });
            try
            {
                result.ExportExcel = Kuika.Common.Helpers.CsSystemFunctions.ExportExcel(request.value_0.ConvertToType<Object>(), "Rolex Masa Saati 2 Yıl Arası Karşılaştırmalı Nisan Ayı Raporu".ConvertToType<String>(), "".ConvertToType<String>(), "Magaza,Nisan2025,Nisan2026,NisanDegisim".ConvertToType<String>());
                actionAuditExportExcel_0.SetResult(result.ExportExcel);
            }
            catch (Exception ex)
            {
                actionAuditExportExcel_0.SetException(ex);
                throw;
            }
;


            return Ok(result);
        }


        [HttpPost, Route("RolexOtherProductReportingComponent_388935_onClick")]
        public IActionResult RolexOtherProductReportingComponent_388935_onClick(RolexOtherProductReportingComponent_388935_onClick_Request request)
        {

            var result = new RolexOtherProductReportingComponent_388935_onClick_Response();


            using var auditExportExcel_0 = ActionAuditScope.Begin("a9e4350f-1ec8-c9d0-6628-0ea74512782f", "ExportExcel", applicationName: "wbTimesCRM", screenOrEndpointName: "RolexOtherProductReporting");
            using var actionAuditExportExcel_0 = ActionAuditHelper.Begin("ExportExcel", new { value = request.value_0.ConvertToType<Object>(), header = "Rolex Masa Saati 2 Yıl Arası Karşılaştırmalı Mayıs Ayı Raporu".ConvertToType<String>(), footer = "".ConvertToType<String>(), columns = "Magaza,Mayis2025,Mayis2026,MayisDegisim".ConvertToType<String>() });
            try
            {
                result.ExportExcel = Kuika.Common.Helpers.CsSystemFunctions.ExportExcel(request.value_0.ConvertToType<Object>(), "Rolex Masa Saati 2 Yıl Arası Karşılaştırmalı Mayıs Ayı Raporu".ConvertToType<String>(), "".ConvertToType<String>(), "Magaza,Mayis2025,Mayis2026,MayisDegisim".ConvertToType<String>());
                actionAuditExportExcel_0.SetResult(result.ExportExcel);
            }
            catch (Exception ex)
            {
                actionAuditExportExcel_0.SetException(ex);
                throw;
            }
;


            return Ok(result);
        }


        [HttpPost, Route("RolexOtherProductReportingComponent_790629_onClick")]
        public IActionResult RolexOtherProductReportingComponent_790629_onClick(RolexOtherProductReportingComponent_790629_onClick_Request request)
        {

            var result = new RolexOtherProductReportingComponent_790629_onClick_Response();


            using var auditExportExcel_0 = ActionAuditScope.Begin("d3daf30c-dacd-8856-2192-23bd1047a9d9", "ExportExcel", applicationName: "wbTimesCRM", screenOrEndpointName: "RolexOtherProductReporting");
            using var actionAuditExportExcel_0 = ActionAuditHelper.Begin("ExportExcel", new { value = request.value_0.ConvertToType<Object>(), header = "Rolex Masa Saati 2 Yıl Arası Karşılaştırmalı Haziran Ayı Raporu".ConvertToType<String>(), footer = "".ConvertToType<String>(), columns = "Magaza,Haziran2025,Haziran2026,HaziranDegisim".ConvertToType<String>() });
            try
            {
                result.ExportExcel = Kuika.Common.Helpers.CsSystemFunctions.ExportExcel(request.value_0.ConvertToType<Object>(), "Rolex Masa Saati 2 Yıl Arası Karşılaştırmalı Haziran Ayı Raporu".ConvertToType<String>(), "".ConvertToType<String>(), "Magaza,Haziran2025,Haziran2026,HaziranDegisim".ConvertToType<String>());
                actionAuditExportExcel_0.SetResult(result.ExportExcel);
            }
            catch (Exception ex)
            {
                actionAuditExportExcel_0.SetException(ex);
                throw;
            }
;


            return Ok(result);
        }


        [HttpPost, Route("RolexOtherProductReportingComponent_731922_onClick")]
        public IActionResult RolexOtherProductReportingComponent_731922_onClick(RolexOtherProductReportingComponent_731922_onClick_Request request)
        {

            var result = new RolexOtherProductReportingComponent_731922_onClick_Response();


            using var auditExportExcel_0 = ActionAuditScope.Begin("ddd527d7-b462-2cb3-25ef-5744c401e435", "ExportExcel", applicationName: "wbTimesCRM", screenOrEndpointName: "RolexOtherProductReporting");
            using var actionAuditExportExcel_0 = ActionAuditHelper.Begin("ExportExcel", new { value = request.value_0.ConvertToType<Object>(), header = "Rolex Masa Saati 2 Yıl Arası Karşılaştırmalı Temmuz Ayı Raporu".ConvertToType<String>(), footer = "".ConvertToType<String>(), columns = "Magaza,Temmuz2025,Temmuz2026,TemmuzDegisim".ConvertToType<String>() });
            try
            {
                result.ExportExcel = Kuika.Common.Helpers.CsSystemFunctions.ExportExcel(request.value_0.ConvertToType<Object>(), "Rolex Masa Saati 2 Yıl Arası Karşılaştırmalı Temmuz Ayı Raporu".ConvertToType<String>(), "".ConvertToType<String>(), "Magaza,Temmuz2025,Temmuz2026,TemmuzDegisim".ConvertToType<String>());
                actionAuditExportExcel_0.SetResult(result.ExportExcel);
            }
            catch (Exception ex)
            {
                actionAuditExportExcel_0.SetException(ex);
                throw;
            }
;


            return Ok(result);
        }


        [HttpPost, Route("RolexOtherProductReportingComponent_724984_onClick")]
        public IActionResult RolexOtherProductReportingComponent_724984_onClick(RolexOtherProductReportingComponent_724984_onClick_Request request)
        {

            var result = new RolexOtherProductReportingComponent_724984_onClick_Response();


            using var auditExportExcel_0 = ActionAuditScope.Begin("95384254-fca0-4ac4-68b0-6f7f735a71ea", "ExportExcel", applicationName: "wbTimesCRM", screenOrEndpointName: "RolexOtherProductReporting");
            using var actionAuditExportExcel_0 = ActionAuditHelper.Begin("ExportExcel", new { value = request.value_0.ConvertToType<Object>(), header = "Rolex Masa Saati 2 Yıl Arası Karşılaştırmalı Ağustos Ayı Raporu".ConvertToType<String>(), footer = "".ConvertToType<String>(), columns = "Magaza,Agustos2025,Agustos2026,AgustosDegisim".ConvertToType<String>() });
            try
            {
                result.ExportExcel = Kuika.Common.Helpers.CsSystemFunctions.ExportExcel(request.value_0.ConvertToType<Object>(), "Rolex Masa Saati 2 Yıl Arası Karşılaştırmalı Ağustos Ayı Raporu".ConvertToType<String>(), "".ConvertToType<String>(), "Magaza,Agustos2025,Agustos2026,AgustosDegisim".ConvertToType<String>());
                actionAuditExportExcel_0.SetResult(result.ExportExcel);
            }
            catch (Exception ex)
            {
                actionAuditExportExcel_0.SetException(ex);
                throw;
            }
;


            return Ok(result);
        }


        [HttpPost, Route("RolexOtherProductReportingComponent_265717_onClick")]
        public IActionResult RolexOtherProductReportingComponent_265717_onClick(RolexOtherProductReportingComponent_265717_onClick_Request request)
        {

            var result = new RolexOtherProductReportingComponent_265717_onClick_Response();


            using var auditExportExcel_0 = ActionAuditScope.Begin("f444f172-1d7a-2bda-4e08-e99d1460db60", "ExportExcel", applicationName: "wbTimesCRM", screenOrEndpointName: "RolexOtherProductReporting");
            using var actionAuditExportExcel_0 = ActionAuditHelper.Begin("ExportExcel", new { value = request.value_0.ConvertToType<Object>(), header = "Rolex Masa Saati 2 Yıl Arası Karşılaştırmalı Eylül Ayı Raporu".ConvertToType<String>(), footer = "".ConvertToType<String>(), columns = "Magaza,Eylul2025,Eylul2026,EylulDegisim".ConvertToType<String>() });
            try
            {
                result.ExportExcel = Kuika.Common.Helpers.CsSystemFunctions.ExportExcel(request.value_0.ConvertToType<Object>(), "Rolex Masa Saati 2 Yıl Arası Karşılaştırmalı Eylül Ayı Raporu".ConvertToType<String>(), "".ConvertToType<String>(), "Magaza,Eylul2025,Eylul2026,EylulDegisim".ConvertToType<String>());
                actionAuditExportExcel_0.SetResult(result.ExportExcel);
            }
            catch (Exception ex)
            {
                actionAuditExportExcel_0.SetException(ex);
                throw;
            }
;


            return Ok(result);
        }


        [HttpPost, Route("RolexOtherProductReportingComponent_737833_onClick")]
        public IActionResult RolexOtherProductReportingComponent_737833_onClick(RolexOtherProductReportingComponent_737833_onClick_Request request)
        {

            var result = new RolexOtherProductReportingComponent_737833_onClick_Response();


            using var auditExportExcel_0 = ActionAuditScope.Begin("596659b1-480f-bcd1-d16d-1922ba5c835f", "ExportExcel", applicationName: "wbTimesCRM", screenOrEndpointName: "RolexOtherProductReporting");
            using var actionAuditExportExcel_0 = ActionAuditHelper.Begin("ExportExcel", new { value = request.value_0.ConvertToType<Object>(), header = "Rolex Masa Saati 2 Yıl Arası Karşılaştırmalı Ekim Ayı Raporu".ConvertToType<String>(), footer = "".ConvertToType<String>(), columns = "Magaza,Ekim2025,Ekim2026,EkimDegisim".ConvertToType<String>() });
            try
            {
                result.ExportExcel = Kuika.Common.Helpers.CsSystemFunctions.ExportExcel(request.value_0.ConvertToType<Object>(), "Rolex Masa Saati 2 Yıl Arası Karşılaştırmalı Ekim Ayı Raporu".ConvertToType<String>(), "".ConvertToType<String>(), "Magaza,Ekim2025,Ekim2026,EkimDegisim".ConvertToType<String>());
                actionAuditExportExcel_0.SetResult(result.ExportExcel);
            }
            catch (Exception ex)
            {
                actionAuditExportExcel_0.SetException(ex);
                throw;
            }
;


            return Ok(result);
        }


        [HttpPost, Route("RolexOtherProductReportingComponent_64314_onClick")]
        public IActionResult RolexOtherProductReportingComponent_64314_onClick(RolexOtherProductReportingComponent_64314_onClick_Request request)
        {

            var result = new RolexOtherProductReportingComponent_64314_onClick_Response();


            using var auditExportExcel_0 = ActionAuditScope.Begin("70529b78-f5ab-016d-d16a-d02e11ea7120", "ExportExcel", applicationName: "wbTimesCRM", screenOrEndpointName: "RolexOtherProductReporting");
            using var actionAuditExportExcel_0 = ActionAuditHelper.Begin("ExportExcel", new { value = request.value_0.ConvertToType<Object>(), header = "Rolex Masa Saati 2 Yıl Arası Karşılaştırmalı Kasım Ayı Raporu".ConvertToType<String>(), footer = "".ConvertToType<String>(), columns = "Magaza,Kasim2025,Kasim2026,KasimDegisim".ConvertToType<String>() });
            try
            {
                result.ExportExcel = Kuika.Common.Helpers.CsSystemFunctions.ExportExcel(request.value_0.ConvertToType<Object>(), "Rolex Masa Saati 2 Yıl Arası Karşılaştırmalı Kasım Ayı Raporu".ConvertToType<String>(), "".ConvertToType<String>(), "Magaza,Kasim2025,Kasim2026,KasimDegisim".ConvertToType<String>());
                actionAuditExportExcel_0.SetResult(result.ExportExcel);
            }
            catch (Exception ex)
            {
                actionAuditExportExcel_0.SetException(ex);
                throw;
            }
;


            return Ok(result);
        }


        [HttpPost, Route("RolexOtherProductReportingComponent_188388_onClick")]
        public IActionResult RolexOtherProductReportingComponent_188388_onClick(RolexOtherProductReportingComponent_188388_onClick_Request request)
        {

            var result = new RolexOtherProductReportingComponent_188388_onClick_Response();


            using var auditExportExcel_0 = ActionAuditScope.Begin("2b847d67-37e4-f831-c0ed-4485bf9e8786", "ExportExcel", applicationName: "wbTimesCRM", screenOrEndpointName: "RolexOtherProductReporting");
            using var actionAuditExportExcel_0 = ActionAuditHelper.Begin("ExportExcel", new { value = request.value_0.ConvertToType<Object>(), header = "Rolex Masa Saati 2 Yıl Arası Karşılaştırmalı Aralık Ayı Raporu".ConvertToType<String>(), footer = "".ConvertToType<String>(), columns = "Magaza,Aralik2025,Aralik2026,AralikDegisim".ConvertToType<String>() });
            try
            {
                result.ExportExcel = Kuika.Common.Helpers.CsSystemFunctions.ExportExcel(request.value_0.ConvertToType<Object>(), "Rolex Masa Saati 2 Yıl Arası Karşılaştırmalı Aralık Ayı Raporu".ConvertToType<String>(), "".ConvertToType<String>(), "Magaza,Aralik2025,Aralik2026,AralikDegisim".ConvertToType<String>());
                actionAuditExportExcel_0.SetResult(result.ExportExcel);
            }
            catch (Exception ex)
            {
                actionAuditExportExcel_0.SetException(ex);
                throw;
            }
;


            return Ok(result);
        }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class RolexOtherProductReportingPageInit_Request
    {
        public String? Brand_0 { set; get; }
        public String? ProductGroup_0 { set; get; }
        public Int32? Year1_0 { set; get; }
        public Int32? Year2_0 { set; get; }
        public String? Brand_1 { set; get; }
        public String? ProductGroup_1 { set; get; }
        public Int32? Year1_1 { set; get; }
        public Int32? Year2_1 { set; get; }
        public String? Brand_2 { set; get; }
        public String? ProductGroup_2 { set; get; }
        public Int32? Year1_2 { set; get; }
        public Int32? Year2_2 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class RolexOtherProductReportingPageInit_Response
    {
        public System.Collections.Generic.IList<Kuika.ThirdPartyApisCollection.KuikaY_RolexGrupAylikSatisKarsilastirmaClass> KuikaY_RolexGrupAylikSatisKarsilastirma_S1 { set; get; }

        public System.Collections.Generic.IList<Kuika.ThirdPartyApisCollection.KuikaY_RolexGrupAylikSatisKarsilastirmaClass> KuikaY_RolexGrupAylikSatisKarsilastirma_S2 { set; get; }

        public System.Collections.Generic.IList<Kuika.ThirdPartyApisCollection.KuikaY_RolexGrupAylikSatisKarsilastirmaClass> KuikaY_RolexGrupAylikSatisKarsilastirma_S3 { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class RolexOtherProductReportingComponent_616475_onClick_Request
    {
        public Object value_0 { set; get; }
        public String header_0 { set; get; }
        public String footer_0 { set; get; }
        public String columns_0 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class RolexOtherProductReportingComponent_616475_onClick_Response
    {
        public KuikaCommonRestResult ExportExcel { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class RolexOtherProductReportingComponent_80364_onClick_Request
    {
        public Object value_0 { set; get; }
        public String header_0 { set; get; }
        public String footer_0 { set; get; }
        public String columns_0 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class RolexOtherProductReportingComponent_80364_onClick_Response
    {
        public KuikaCommonRestResult ExportExcel { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class RolexOtherProductReportingComponent_701801_onClick_Request
    {
        public Object value_0 { set; get; }
        public String header_0 { set; get; }
        public String footer_0 { set; get; }
        public String columns_0 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class RolexOtherProductReportingComponent_701801_onClick_Response
    {
        public KuikaCommonRestResult ExportExcel { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class RolexOtherProductReportingComponent_601127_onClick_Request
    {
        public Object value_0 { set; get; }
        public String header_0 { set; get; }
        public String footer_0 { set; get; }
        public String columns_0 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class RolexOtherProductReportingComponent_601127_onClick_Response
    {
        public KuikaCommonRestResult ExportExcel { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class RolexOtherProductReportingComponent_545006_onClick_Request
    {
        public Object value_0 { set; get; }
        public String header_0 { set; get; }
        public String footer_0 { set; get; }
        public String columns_0 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class RolexOtherProductReportingComponent_545006_onClick_Response
    {
        public KuikaCommonRestResult ExportExcel { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class RolexOtherProductReportingComponent_824313_onClick_Request
    {
        public Object value_0 { set; get; }
        public String header_0 { set; get; }
        public String footer_0 { set; get; }
        public String columns_0 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class RolexOtherProductReportingComponent_824313_onClick_Response
    {
        public KuikaCommonRestResult ExportExcel { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class RolexOtherProductReportingComponent_551578_onClick_Request
    {
        public Object value_0 { set; get; }
        public String header_0 { set; get; }
        public String footer_0 { set; get; }
        public String columns_0 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class RolexOtherProductReportingComponent_551578_onClick_Response
    {
        public KuikaCommonRestResult ExportExcel { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class RolexOtherProductReportingComponent_386843_onClick_Request
    {
        public Object value_0 { set; get; }
        public String header_0 { set; get; }
        public String footer_0 { set; get; }
        public String columns_0 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class RolexOtherProductReportingComponent_386843_onClick_Response
    {
        public KuikaCommonRestResult ExportExcel { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class RolexOtherProductReportingComponent_693420_onClick_Request
    {
        public Object value_0 { set; get; }
        public String header_0 { set; get; }
        public String footer_0 { set; get; }
        public String columns_0 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class RolexOtherProductReportingComponent_693420_onClick_Response
    {
        public KuikaCommonRestResult ExportExcel { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class RolexOtherProductReportingComponent_4525_onClick_Request
    {
        public Object value_0 { set; get; }
        public String header_0 { set; get; }
        public String footer_0 { set; get; }
        public String columns_0 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class RolexOtherProductReportingComponent_4525_onClick_Response
    {
        public KuikaCommonRestResult ExportExcel { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class RolexOtherProductReportingComponent_213735_onClick_Request
    {
        public Object value_0 { set; get; }
        public String header_0 { set; get; }
        public String footer_0 { set; get; }
        public String columns_0 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class RolexOtherProductReportingComponent_213735_onClick_Response
    {
        public KuikaCommonRestResult ExportExcel { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class RolexOtherProductReportingComponent_27453_onClick_Request
    {
        public Object value_0 { set; get; }
        public String header_0 { set; get; }
        public String footer_0 { set; get; }
        public String columns_0 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class RolexOtherProductReportingComponent_27453_onClick_Response
    {
        public KuikaCommonRestResult ExportExcel { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class RolexOtherProductReportingComponent_603178_onClick_Request
    {
        public Object value_0 { set; get; }
        public String header_0 { set; get; }
        public String footer_0 { set; get; }
        public String columns_0 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class RolexOtherProductReportingComponent_603178_onClick_Response
    {
        public KuikaCommonRestResult ExportExcel { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class RolexOtherProductReportingComponent_736558_onClick_Request
    {
        public String? Brand_0 { set; get; }
        public String? ProductGroup_0 { set; get; }
        public Int32? Year1_0 { set; get; }
        public Int32? Year2_0 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class RolexOtherProductReportingComponent_736558_onClick_Response
    {
        public System.Collections.Generic.IList<Kuika.ThirdPartyApisCollection.KuikaY_RolexGrupAylikSatisKarsilastirmaClass> KuikaY_RolexGrupAylikSatisKarsilastirma_S2 { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class RolexOtherProductReportingComponent_338196_onClick_Request
    {
        public Object value_0 { set; get; }
        public String header_0 { set; get; }
        public String footer_0 { set; get; }
        public String columns_0 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class RolexOtherProductReportingComponent_338196_onClick_Response
    {
        public KuikaCommonRestResult ExportExcel { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class RolexOtherProductReportingComponent_447049_onClick_Request
    {
        public Object value_0 { set; get; }
        public String header_0 { set; get; }
        public String footer_0 { set; get; }
        public String columns_0 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class RolexOtherProductReportingComponent_447049_onClick_Response
    {
        public KuikaCommonRestResult ExportExcel { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class RolexOtherProductReportingComponent_124225_onClick_Request
    {
        public Object value_0 { set; get; }
        public String header_0 { set; get; }
        public String footer_0 { set; get; }
        public String columns_0 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class RolexOtherProductReportingComponent_124225_onClick_Response
    {
        public KuikaCommonRestResult ExportExcel { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class RolexOtherProductReportingComponent_865445_onClick_Request
    {
        public Object value_0 { set; get; }
        public String header_0 { set; get; }
        public String footer_0 { set; get; }
        public String columns_0 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class RolexOtherProductReportingComponent_865445_onClick_Response
    {
        public KuikaCommonRestResult ExportExcel { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class RolexOtherProductReportingComponent_172862_onClick_Request
    {
        public Object value_0 { set; get; }
        public String header_0 { set; get; }
        public String footer_0 { set; get; }
        public String columns_0 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class RolexOtherProductReportingComponent_172862_onClick_Response
    {
        public KuikaCommonRestResult ExportExcel { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class RolexOtherProductReportingComponent_851110_onClick_Request
    {
        public Object value_0 { set; get; }
        public String header_0 { set; get; }
        public String footer_0 { set; get; }
        public String columns_0 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class RolexOtherProductReportingComponent_851110_onClick_Response
    {
        public KuikaCommonRestResult ExportExcel { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class RolexOtherProductReportingComponent_56305_onClick_Request
    {
        public Object value_0 { set; get; }
        public String header_0 { set; get; }
        public String footer_0 { set; get; }
        public String columns_0 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class RolexOtherProductReportingComponent_56305_onClick_Response
    {
        public KuikaCommonRestResult ExportExcel { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class RolexOtherProductReportingComponent_280884_onClick_Request
    {
        public Object value_0 { set; get; }
        public String header_0 { set; get; }
        public String footer_0 { set; get; }
        public String columns_0 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class RolexOtherProductReportingComponent_280884_onClick_Response
    {
        public KuikaCommonRestResult ExportExcel { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class RolexOtherProductReportingComponent_856979_onClick_Request
    {
        public Object value_0 { set; get; }
        public String header_0 { set; get; }
        public String footer_0 { set; get; }
        public String columns_0 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class RolexOtherProductReportingComponent_856979_onClick_Response
    {
        public KuikaCommonRestResult ExportExcel { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class RolexOtherProductReportingComponent_609731_onClick_Request
    {
        public Object value_0 { set; get; }
        public String header_0 { set; get; }
        public String footer_0 { set; get; }
        public String columns_0 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class RolexOtherProductReportingComponent_609731_onClick_Response
    {
        public KuikaCommonRestResult ExportExcel { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class RolexOtherProductReportingComponent_446473_onClick_Request
    {
        public Object value_0 { set; get; }
        public String header_0 { set; get; }
        public String footer_0 { set; get; }
        public String columns_0 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class RolexOtherProductReportingComponent_446473_onClick_Response
    {
        public KuikaCommonRestResult ExportExcel { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class RolexOtherProductReportingComponent_487226_onClick_Request
    {
        public Object value_0 { set; get; }
        public String header_0 { set; get; }
        public String footer_0 { set; get; }
        public String columns_0 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class RolexOtherProductReportingComponent_487226_onClick_Response
    {
        public KuikaCommonRestResult ExportExcel { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class RolexOtherProductReportingComponent_376198_onClick_Request
    {
        public Object value_0 { set; get; }
        public String header_0 { set; get; }
        public String footer_0 { set; get; }
        public String columns_0 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class RolexOtherProductReportingComponent_376198_onClick_Response
    {
        public KuikaCommonRestResult ExportExcel { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class RolexOtherProductReportingComponent_558385_onClick_Request
    {
        public String? Brand_0 { set; get; }
        public String? ProductGroup_0 { set; get; }
        public Int32? Year1_0 { set; get; }
        public Int32? Year2_0 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class RolexOtherProductReportingComponent_558385_onClick_Response
    {
        public System.Collections.Generic.IList<Kuika.ThirdPartyApisCollection.KuikaY_RolexGrupAylikSatisKarsilastirmaClass> KuikaY_RolexGrupAylikSatisKarsilastirma_S3 { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class RolexOtherProductReportingComponent_142785_onClick_Request
    {
        public Object value_0 { set; get; }
        public String header_0 { set; get; }
        public String footer_0 { set; get; }
        public String columns_0 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class RolexOtherProductReportingComponent_142785_onClick_Response
    {
        public KuikaCommonRestResult ExportExcel { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class RolexOtherProductReportingComponent_408362_onClick_Request
    {
        public Object value_0 { set; get; }
        public String header_0 { set; get; }
        public String footer_0 { set; get; }
        public String columns_0 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class RolexOtherProductReportingComponent_408362_onClick_Response
    {
        public KuikaCommonRestResult ExportExcel { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class RolexOtherProductReportingComponent_243711_onClick_Request
    {
        public Object value_0 { set; get; }
        public String header_0 { set; get; }
        public String footer_0 { set; get; }
        public String columns_0 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class RolexOtherProductReportingComponent_243711_onClick_Response
    {
        public KuikaCommonRestResult ExportExcel { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class RolexOtherProductReportingComponent_101219_onClick_Request
    {
        public Object value_0 { set; get; }
        public String header_0 { set; get; }
        public String footer_0 { set; get; }
        public String columns_0 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class RolexOtherProductReportingComponent_101219_onClick_Response
    {
        public KuikaCommonRestResult ExportExcel { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class RolexOtherProductReportingComponent_141570_onClick_Request
    {
        public Object value_0 { set; get; }
        public String header_0 { set; get; }
        public String footer_0 { set; get; }
        public String columns_0 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class RolexOtherProductReportingComponent_141570_onClick_Response
    {
        public KuikaCommonRestResult ExportExcel { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class RolexOtherProductReportingComponent_388935_onClick_Request
    {
        public Object value_0 { set; get; }
        public String header_0 { set; get; }
        public String footer_0 { set; get; }
        public String columns_0 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class RolexOtherProductReportingComponent_388935_onClick_Response
    {
        public KuikaCommonRestResult ExportExcel { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class RolexOtherProductReportingComponent_790629_onClick_Request
    {
        public Object value_0 { set; get; }
        public String header_0 { set; get; }
        public String footer_0 { set; get; }
        public String columns_0 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class RolexOtherProductReportingComponent_790629_onClick_Response
    {
        public KuikaCommonRestResult ExportExcel { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class RolexOtherProductReportingComponent_731922_onClick_Request
    {
        public Object value_0 { set; get; }
        public String header_0 { set; get; }
        public String footer_0 { set; get; }
        public String columns_0 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class RolexOtherProductReportingComponent_731922_onClick_Response
    {
        public KuikaCommonRestResult ExportExcel { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class RolexOtherProductReportingComponent_724984_onClick_Request
    {
        public Object value_0 { set; get; }
        public String header_0 { set; get; }
        public String footer_0 { set; get; }
        public String columns_0 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class RolexOtherProductReportingComponent_724984_onClick_Response
    {
        public KuikaCommonRestResult ExportExcel { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class RolexOtherProductReportingComponent_265717_onClick_Request
    {
        public Object value_0 { set; get; }
        public String header_0 { set; get; }
        public String footer_0 { set; get; }
        public String columns_0 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class RolexOtherProductReportingComponent_265717_onClick_Response
    {
        public KuikaCommonRestResult ExportExcel { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class RolexOtherProductReportingComponent_737833_onClick_Request
    {
        public Object value_0 { set; get; }
        public String header_0 { set; get; }
        public String footer_0 { set; get; }
        public String columns_0 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class RolexOtherProductReportingComponent_737833_onClick_Response
    {
        public KuikaCommonRestResult ExportExcel { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class RolexOtherProductReportingComponent_64314_onClick_Request
    {
        public Object value_0 { set; get; }
        public String header_0 { set; get; }
        public String footer_0 { set; get; }
        public String columns_0 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class RolexOtherProductReportingComponent_64314_onClick_Response
    {
        public KuikaCommonRestResult ExportExcel { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class RolexOtherProductReportingComponent_188388_onClick_Request
    {
        public Object value_0 { set; get; }
        public String header_0 { set; get; }
        public String footer_0 { set; get; }
        public String columns_0 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class RolexOtherProductReportingComponent_188388_onClick_Response
    {
        public KuikaCommonRestResult ExportExcel { set; get; }

    }
}
