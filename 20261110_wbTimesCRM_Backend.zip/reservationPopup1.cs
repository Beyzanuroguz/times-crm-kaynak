
using Kuika.Common;
using Kuika.Common.Attributes;
using Kuika.Common.Bases;
using Kuika.Common.Enums;
using Kuika.Common.Accessors;
using Kuika.Common.Json;
using Kuika.Common.Classes;
using Kuika.Common.Exceptions;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Kuika.Common.Helpers;
using Kuika.Common.Settings;
using System.Collections.Generic;
using System;
using Kuika.Common.Extensions;
using System.Linq;
using Kuika.Common.Rest;
using WorkflowCore.Interface;
using Kuika.Common.Interfaces;
using Kuika.Common.Workflow;
using Kuika.Common.Workflow.Extensions;
using Kuika.Common.Workflow.DTOs;
using Kuika.Common.Models;
using Kuika.Common.Menu.Response;
using Kuika.Common.Entities;
using System.Reflection;
using Newtonsoft.Json.Linq;
using Newtonsoft.Json;
using System.Net.Http;
using Iyzipay.Model.V2.Subscription;
using Kuika.Common.Payments.Iyzico;
using Kuika.Common.Payments.Param;
using Iyzipay;
using Kuika.Common.Searching.DTOs;
using Kuika.Common.Helpers.Sap;
using Kuika.Common.Mcp;
using Kuika.Common.Vision.DTOs;
using Kuika.Common.Audit;
using Kuika.Common.Payments.Mobile;
using Kuika.ThirdPartyApisCollection;

namespace Kuika.Reslen_01.Api
{
    [ApiExplorerSettings(GroupName = "all")]
    [Authorize]
    [ApiController]
    [Route("v1/api/reservationPopup1")]
    public class reservationPopup1_Controller : KControllerBase
    {
        private string appName = "wbTimesCRM";
        private Guid appId = Guid.Parse("0e8ecb48-8c52-463c-5db5-08de3ec441b1");
        private static string screenName = "reservationPopup1";
        private Guid screenId = Guid.Parse("ddce2084-4157-4c5c-a19a-5137fb26bea0");
        private string connectionString { get { return Kuika.Common.KContext.GetConnectionString(); } }

        [HttpGet, Route("myroles")]
        public IActionResult GetMyRoles()
        {
            try
            {
                var result = KProviderManager.Authorization.GetMyRoles(appId, appName, screenId, screenName);
                return Ok(result);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new HttpExceptionDto() { Message = ex.Message, StackTrace = ex.StackTrace });
            }
        }


        [HttpPost, Route("reservationPopup1PageInit")]
        public IActionResult reservationPopup1PageInit(reservationPopup1PageInit_Request request)
        {

            var result = new reservationPopup1PageInit_Response();

            var prms_TMGetProductDetailStockByLeadId_0 = new List<kSqlParameter>();
            prms_TMGetProductDetailStockByLeadId_0.Add(new kSqlParameter() { Name = "LeadId", Value = request.LeadId_0 });
            using var auditTMGetProductDetailStockByLeadId_0 = ActionAuditScope.Begin("a3c491ff-e659-b7cc-91dd-a2f46b8d7d02", "TMGetProductDetailStockByLeadId", applicationName: "wbTimesCRM", screenOrEndpointName: "reservationPopup1");
            result.TMGetProductDetailStockByLeadId = KPersister.Fetch(KContext.GetConnectionString(), @"DECLARE @StoreId UNIQUEIDENTIFIER;
DECLARE @ProductId UNIQUEIDENTIFIER;
DECLARE @StoreCode NVARCHAR(50);

--------------------------------------------------
-- LEAD ÜZERİNDEN ÜRÜN VE MAĞAZA
--------------------------------------------------
SELECT
    @ProductId = l.ProductId,
    @StoreId = COALESCE(l.StoreId, tu.StoreId)
FROM tmscrq.TMLead l
LEFT JOIN tmscrq.TMUser tu
    ON tu.KUserID = l.CreatedBy
WHERE l.Id = @LeadId;

SELECT
    @StoreCode = StoreCode
FROM tmscrq.TMStore
WHERE Id = @StoreId;

DECLARE @ReservedCount INT = 0;
DECLARE @PendingReservationCount INT = 0;

--------------------------------------------------
-- REZERVE STOK (DELIVERY_PENDING)
--------------------------------------------------
SELECT
    @ReservedCount = COUNT(DISTINCT r.LeadId)
FROM tmscrq.TMLeadReservation r
INNER JOIN tmscrq.TMLead l
    ON l.Id = r.LeadId
INNER JOIN tmscrq.TMLeadProcess lp
    ON lp.Id = l.ProcessID
LEFT JOIN tmscrq.TMUser tu
    ON tu.KUserID = l.CreatedBy
WHERE r.IsActive = 1
  AND lp.Code = 'DELIVERY_PENDING'
  AND COALESCE(l.StoreId, tu.StoreId) = @StoreId
  AND l.ProductId = @ProductId;

--------------------------------------------------
-- ONAY BEKLEYEN REZERV TALEPLERİ
--------------------------------------------------
SELECT
    @PendingReservationCount = COUNT(DISTINCT r.LeadId)
FROM tmscrq.TMLeadReservation r
INNER JOIN tmscrq.TMLead l
    ON l.Id = r.LeadId
INNER JOIN tmscrq.TMLeadProcess lp
    ON lp.Id = l.ProcessID
LEFT JOIN tmscrq.TMUser tu
    ON tu.KUserID = l.CreatedBy
WHERE r.IsActive = 1
  AND ISNULL(r.IsApproved,0)=0
  AND ISNULL(r.IsRejected,0)=0
  AND lp.Code='APPROVED'
  AND COALESCE(l.StoreId, tu.StoreId)=@StoreId
  AND l.ProductId=@ProductId;

--------------------------------------------------
-- SONUÇ
--------------------------------------------------
SELECT

    p.Id AS ProductId,
    p.ProductCode,
    p.ProductName,
    p.CategoryName,
    p.Referance,
    p.Dial,
    p.Bracelet,

    ISNULL(SUM(i.InventoryQty1),0) AS ToplamStok,

    ISNULL(@ReservedCount,0) AS RezerveStok,

    ISNULL(@PendingReservationCount,0) AS BekleyenRezervTalebi,

    CASE
        WHEN ISNULL(SUM(i.InventoryQty1),0)-ISNULL(@ReservedCount,0) > 0
        THEN ISNULL(SUM(i.InventoryQty1),0)-ISNULL(@ReservedCount,0)
        ELSE 0
    END AS MusaitStok,

    CASE
        WHEN ISNULL(SUM(i.InventoryQty1),0)
             -ISNULL(@ReservedCount,0)
             -ISNULL(@PendingReservationCount,0) > 0
        THEN ISNULL(SUM(i.InventoryQty1),0)
             -ISNULL(@ReservedCount,0)
             -ISNULL(@PendingReservationCount,0)
        ELSE 0
    END AS YeniRezervTalebiKapasitesi

FROM tmscrq.TMProduct p

LEFT JOIN tmscrq.TMItemInventory i
    ON UPPER(LTRIM(RTRIM(i.ProductCode)))
       = UPPER(LTRIM(RTRIM(p.ProductCode)))
   AND UPPER(LTRIM(RTRIM(i.StoreCode)))
       = UPPER(LTRIM(RTRIM(@StoreCode)))
   AND i.OfficeDescription IS NOT NULL
   AND i.OfficeDescription <> N'Teknik Servis Ofis'

WHERE p.Id = @ProductId

GROUP BY
    p.Id,
    p.ProductCode,
    p.ProductName,
    p.CategoryName,
    p.Referance,
    p.Dial,
    p.Bracelet;", new string[] { "ProductId", "ProductCode", "ProductName", "CategoryName", "Referance", "Dial", "Bracelet", "ToplamStok", "RezerveStok", "BekleyenRezervTalebi", "MusaitStok", "YeniRezervTalebiKapasitesi" }, prms_TMGetProductDetailStockByLeadId_0.ToArray());
            ;

            var prms_TM_GetLeadById_1 = new List<kSqlParameter>();
            prms_TM_GetLeadById_1.Add(new kSqlParameter() { Name = "LeadId", Value = request.LeadId_1 });
            using var auditTM_GetLeadById_1 = ActionAuditScope.Begin("1a3de630-baeb-ee7b-c3d9-88f0d7583ca0", "TM_GetLeadById", applicationName: "wbTimesCRM", screenOrEndpointName: "reservationPopup1");
            result.TM_GetLeadById = KPersister.Fetch(KContext.GetConnectionString(), @"SET NOCOUNT ON;

SELECT
    l.Id AS LeadId,

    l.CustomerId,
    l.ProductId,
    l.StoreId,
    l.SalesPersonKUserId,

    -- Eski kolon adı korunuyor


    -- Yeni referans kişi ID'si
    l.ReferencePersonID,

    l.ContactResourceId,
    l.ProcessID,

    ISNULL(NULLIF(LTRIM(RTRIM(l.LeadCode)), ''), '-') AS LeadCode,

    LTRIM(RTRIM(
        ISNULL(c.Name, '') +
        CASE
            WHEN c.LastName IS NOT NULL
                 AND LTRIM(RTRIM(c.LastName)) <> ''
            THEN ' ' + c.LastName
            ELSE ''
        END
    )) AS MusteriAdi,

    ISNULL(NULLIF(LTRIM(RTRIM(c.Tel)), ''), '-') AS TelefonNo,
    ISNULL(NULLIF(LTRIM(RTRIM(c.Email)), ''), '-') AS MusteriMail,
    ISNULL(NULLIF(LTRIM(RTRIM(c.Info)), ''), '-') AS MusteriInfo,
    ISNULL(NULLIF(LTRIM(RTRIM(c.CurrAccCode)), ''), '-') AS CurrAccCode,

    -- ============================================================
    -- REFERANS
    -- TMReference yerine TMReferencePerson kullanılıyor
    -- ÇIKTI KOLON İSİMLERİ DEĞİŞTİRİLMEDİ
    -- ============================================================

    LTRIM(RTRIM(
        ISNULL(r.Name, '') +
        CASE
            WHEN r.LastName IS NOT NULL
                 AND LTRIM(RTRIM(r.LastName)) <> ''
            THEN ' ' + r.LastName
            ELSE ''
        END
    )) AS ReferansAdi,

    -- TMReference.Note yerine TMReferencePerson.Info
    ISNULL(NULLIF(LTRIM(RTRIM(r.Info)), ''), '-') AS ReferansNote,

    -- TMReference.ReferenceNationalID yerine TMReferencePerson.NationalID
    ISNULL(NULLIF(LTRIM(RTRIM(r.NationalID)), ''), '-') AS ReferansKimlikNo,
       ISNULL(NULLIF(LTRIM(RTRIM(r.Tel)), ''), '-') AS ReferansTelefonNo,

    ISNULL(NULLIF(LTRIM(RTRIM(r.CurrAccCode)), ''), '-') AS ReferansCurrAccCode,

    ISNULL(c.IsShopping, 0) AS AlisverisYaptiMi,

    CASE
        WHEN c.CountryName IS NULL
             AND c.CityName IS NULL
            THEN '-'

        WHEN c.CityName IS NULL
            THEN c.CountryName

        WHEN c.CountryName IS NULL
            THEN c.CityName

        ELSE c.CountryName + ' / ' + c.CityName
    END AS Lokasyon,

    ISNULL(NULLIF(LTRIM(RTRIM(c.DistrictName)), ''), '-') AS Ilce,

    ISNULL(
        NULLIF(LTRIM(RTRIM(cr.ContactResourceName)), ''),
        '-'
    ) AS IletisimKaynagi,

    ISNULL(NULLIF(LTRIM(RTRIM(p.ProductName)), ''), '-') AS UrunAdi,
    ISNULL(NULLIF(LTRIM(RTRIM(p.Brand)), ''), '-') AS Brand,
    ISNULL(NULLIF(LTRIM(RTRIM(p.Referance)), ''), '-') AS Referans,
    ISNULL(NULLIF(LTRIM(RTRIM(p.Dial)), ''), '-') AS Kadran,
    ISNULL(NULLIF(LTRIM(RTRIM(p.Bracelet)), ''), '-') AS Bilezik,

    LTRIM(RTRIM(st.StoreCode)) AS StoreCode,
    LTRIM(RTRIM(p.ProductCode)) AS ProductCode,

    FORMAT(
        l.CreatedAt
        AT TIME ZONE 'UTC'
        AT TIME ZONE 'Turkey Standard Time',
        'dd MMMM yyyy',
        'tr-TR'
    ) AS TalepOlusturmaTarihi,

    YEAR(l.EstimatedDate) AS TerminYil,

    FORMAT(
        l.EstimatedDate,
        'MMMM',
        'tr-TR'
    ) AS TerminAy,

    MONTH(l.EstimatedDate) AS TerminAyValue,

    FORMAT(
        l.EstimatedDate,
        'yyyy MMMM',
        'tr-TR'
    ) AS TerminTarihi,

    ISNULL(
        NULLIF(LTRIM(RTRIM(ls.Name)), ''),
        '-'
    ) AS TakipDurumu,

    COALESCE(
        NULLIF(ns.Name, ''),
        '-'
    ) AS SonrakiAdim,

    FORMAT(
        LastProcessLog.CreatedAt
        AT TIME ZONE 'UTC'
        AT TIME ZONE 'Turkey Standard Time',
        'dd MMMM yyyy',
        'tr-TR'
    ) AS SonStatuDegisikligi,

    ISNULL(lp.Code, '-') AS ProcessCode,
    ISNULL(lp.Name, '-') AS ProcessName,

    ISNULL(
        NULLIF(LTRIM(RTRIM(st.StoreDesc)), ''),
        '-'
    ) AS Magaza,

    LTRIM(RTRIM(
        ISNULL(sp.FirstName, '') +
        CASE
            WHEN sp.LastName IS NOT NULL
                 AND LTRIM(RTRIM(sp.LastName)) <> ''
            THEN ' ' + sp.LastName
            ELSE ''
        END
    )) AS SatisPersoneli,

    ISNULL(
        NULLIF(LTRIM(RTRIM(l.LeadNote)), ''),
        '-'
    ) AS TalepNotu,

    ISNULL(
        NULLIF(LTRIM(RTRIM(l.LeadRejectedNote)), ''),
        '-'
    ) AS RedNotu,

    ISNULL(
        NULLIF(LTRIM(RTRIM(p.CategoryName)), ''),
        '-'
    ) AS CategoryName,

    ReservationInfo.RezerveEdenKisi,

    --------------------------------------------------
    -- APPROVED RESERVATION
    --------------------------------------------------

    ISNULL(
        ApprovedReservation.HasApproved,
        0
    ) AS HasApprovedReservation,

    ApprovedReservation.ReservationNote
        AS ApprovedReservationNote,

    CONVERT(
        VARCHAR(19),
        ApprovedReservation.ReservedAt,
        120
    ) AS ApprovedReservationDate,

    ISNULL(l.IsReserved, 0) AS IsReserved,

    --------------------------------------------------
    -- RESERVATION STATUS
    --------------------------------------------------

    ISNULL(
        ReservationStatus.RezervDurumu,
        N'Hayır'
    ) AS RezervDurumu


FROM tmscrq.TMLead l

LEFT JOIN tmscrq.TMCustomer c
    ON c.Id = l.CustomerId

-- ============================================================
-- YENİ REFERANS YAPISI
-- TMReference KULLANILMIYOR
-- ============================================================

LEFT JOIN tmscrq.TMReferencePerson r
    ON r.Id = l.ReferencePersonID

LEFT JOIN tmscrq.TMProduct p
    ON p.Id = l.ProductId

LEFT JOIN tmscrq.TMLeadStatu ls
    ON ls.Id = l.StatuId

LEFT JOIN tmscrq.TMStore st
    ON st.Id = l.StoreId

LEFT JOIN dbo.KUser sp
    ON sp.Id = l.SalesPersonKUserId

LEFT JOIN tmscrq.TMLeadProcess lp
    ON lp.Id = l.ProcessID

LEFT JOIN tmscrq.TMContactResource cr
    ON cr.Id = l.ContactResourceId

LEFT JOIN tmscrq.TMLeadNextStep ns
    ON ns.Id = l.NextStepId


-- ============================================================
-- SON PROCESS LOG
-- ============================================================

OUTER APPLY
(
    SELECT TOP 1
        pl.CreatedAt
    FROM tmscrq.TMLeadProcessLog pl
    WHERE pl.LeadId = l.Id
    ORDER BY pl.CreatedAt DESC
) LastProcessLog


-- ============================================================
-- REZERVE EDEN KİŞİ
-- ============================================================

OUTER APPLY
(
    SELECT TOP 1

        LTRIM(RTRIM(
            ISNULL(u2.FirstName, '') +
            ' ' +
            ISNULL(u2.LastName, '')
        )) AS RezerveEdenKisi

    FROM tmscrq.TMLeadReservation r

    LEFT JOIN dbo.KUser u2
        ON u2.Id = r.ReservedBy

    WHERE r.LeadId = l.Id
      AND r.IsActive = 1

    ORDER BY r.ReservedAt DESC

) ReservationInfo


-- ============================================================
-- APPROVED RESERVATION
-- ============================================================

OUTER APPLY
(
    SELECT TOP 1

        1 AS HasApproved,

        r.ReservationNote,

        r.ReservedAt

    FROM tmscrq.TMLeadReservation r

    WHERE r.LeadId = l.Id
      AND r.IsActive = 1
      AND r.IsApproved = 1

    ORDER BY r.ReservedAt DESC

) ApprovedReservation


-- ============================================================
-- REZERVASYON DURUMU
-- ============================================================

OUTER APPLY
(
    SELECT

        CASE

            WHEN EXISTS
            (
                SELECT 1
                FROM tmscrq.TMLeadReservation
                WHERE LeadId = l.Id
                  AND IsActive = 1
                  AND IsApproved = 1
            )
            THEN N'Evet'


            WHEN EXISTS
            (
                SELECT 1
                FROM tmscrq.TMLeadReservation
                WHERE LeadId = l.Id
                  AND IsActive = 1
                  AND ISNULL(IsApproved, 0) = 0
            )
            THEN N'Onay Bekliyor'


            ELSE N'Hayır'

        END AS RezervDurumu

) ReservationStatus


WHERE l.Id = @LeadId;", new string[] { "LeadId", "CustomerId", "ProductId", "StoreId", "SalesPersonKUserId", "ReferencePersonID", "ContactResourceId", "ProcessID", "LeadCode", "MusteriAdi", "TelefonNo", "MusteriMail", "MusteriInfo", "CurrAccCode", "ReferansAdi", "ReferansNote", "ReferansKimlikNo", "ReferansTelefonNo", "ReferansCurrAccCode", "AlisverisYaptiMi", "Lokasyon", "Ilce", "IletisimKaynagi", "UrunAdi", "Brand", "Referans", "Kadran", "Bilezik", "StoreCode", "ProductCode", "TalepOlusturmaTarihi", "TerminYil", "TerminAy", "TerminAyValue", "TerminTarihi", "TakipDurumu", "SonrakiAdim", "SonStatuDegisikligi", "ProcessCode", "ProcessName", "Magaza", "SatisPersoneli", "TalepNotu", "RedNotu", "CategoryName", "RezerveEdenKisi", "HasApprovedReservation", "ApprovedReservationNote", "ApprovedReservationDate", "IsReserved", "RezervDurumu" }, prms_TM_GetLeadById_1.ToArray());
            ;

            var prms_TM_CheckLeadPriorityNew_2 = new List<kSqlParameter>();
            prms_TM_CheckLeadPriorityNew_2.Add(new kSqlParameter() { Name = "LeadId", Value = request.LeadId_2 });
            using var auditTM_CheckLeadPriorityNew_2 = ActionAuditScope.Begin("23b45d7e-582a-3d81-7c95-7a2cb6e500cf", "TM_CheckLeadPriorityNew", applicationName: "wbTimesCRM", screenOrEndpointName: "reservationPopup1");
            result.TM_CheckLeadPriorityNew = KPersister.Fetch(KContext.GetConnectionString(), @"DECLARE @Warning INT = 0;
DECLARE @WarningMessage NVARCHAR(500) = '';

DECLARE @CurrentEstimatedDate DATETIMEOFFSET;
DECLARE @ProductId UNIQUEIDENTIFIER;
DECLARE @StoreId UNIQUEIDENTIFIER;

--------------------------------------------------
-- LEAD'DEN ÜRÜN, MAĞAZA VE TERMİN BİLGİSİ
--------------------------------------------------
SELECT
    @CurrentEstimatedDate = l.EstimatedDate,
    @ProductId = l.ProductId,
    @StoreId = COALESCE(l.StoreId, tu.StoreId)
FROM tmscrq.TMLead l
LEFT JOIN tmscrq.TMUser tu
    ON tu.KUserID = l.CreatedBy
WHERE l.Id = @LeadId;

--------------------------------------------------
-- AKTİF REZERVASYON
--------------------------------------------------
;WITH ActiveReservation AS
(
    SELECT
        x.LeadId,
        x.IsApproved,
        x.IsRejected
    FROM
    (
        SELECT
            r.LeadId,
            ISNULL(r.IsApproved,0) AS IsApproved,
            ISNULL(r.IsRejected,0) AS IsRejected,
            ROW_NUMBER() OVER
            (
                PARTITION BY r.LeadId
                ORDER BY
                    r.ReservedAt DESC,
                    r.Id DESC
            ) AS RN
        FROM tmscrq.TMLeadReservation r
        WHERE r.IsActive = 1
    ) x
    WHERE x.RN = 1
)

--------------------------------------------------
-- WARNING
--------------------------------------------------
SELECT TOP 1
    @Warning = 1,
    @WarningMessage =
        N'Bu ürüne ait daha erken termin tarihine sahip talep(ler) bulunmaktadır.'
FROM tmscrq.TMLead l
INNER JOIN tmscrq.TMLeadProcess lp
    ON lp.Id = l.ProcessID
LEFT JOIN tmscrq.TMUser tu
    ON tu.KUserID = l.CreatedBy
LEFT JOIN ActiveReservation ar
    ON ar.LeadId = l.Id
WHERE
    COALESCE(l.StoreId,tu.StoreId)=@StoreId
    AND l.ProductId=@ProductId
    AND lp.Code='APPROVED'
    AND l.Id<>@LeadId
    AND l.EstimatedDate<@CurrentEstimatedDate
    AND
    (
        ar.LeadId IS NULL
        OR ISNULL(ar.IsRejected,0)=1
    );

--------------------------------------------------
-- WARNING SONUCU
--------------------------------------------------
SELECT
    @Warning AS Warning,
    @WarningMessage AS WarningMessage;

--------------------------------------------------
-- DETAY LİSTESİ
--------------------------------------------------
SELECT
    l.Id,
    l.LeadCode,
    FORMAT(l.EstimatedDate,'yyyy MMMM','tr-TR') AS TerminTarihi,
    LTRIM(RTRIM(ISNULL(cu.Name,'') + ' ' + ISNULL(cu.LastName,''))) AS Musteri,
    cu.Tel
FROM tmscrq.TMLead l
INNER JOIN tmscrq.TMCustomer cu
    ON cu.Id=l.CustomerId
INNER JOIN tmscrq.TMLeadProcess lp
    ON lp.Id=l.ProcessID
LEFT JOIN tmscrq.TMUser tu
    ON tu.KUserID=l.CreatedBy
LEFT JOIN ActiveReservation ar
    ON ar.LeadId=l.Id
WHERE
    COALESCE(l.StoreId,tu.StoreId)=@StoreId
    AND l.ProductId=@ProductId
    AND lp.Code='APPROVED'
    AND l.Id<>@LeadId
    AND l.EstimatedDate<@CurrentEstimatedDate
    AND
    (
        ar.LeadId IS NULL
        OR ISNULL(ar.IsRejected,0)=1
    )
ORDER BY
    l.EstimatedDate ASC;", new string[] { "Warning", "WarningMessage" }, prms_TM_CheckLeadPriorityNew_2.ToArray());
            ;


            return Ok(result);
        }


        [HttpPost, Route("reservationPopup1Component_815956_onClick")]
        public IActionResult reservationPopup1Component_815956_onClick(reservationPopup1Component_815956_onClick_Request request)
        {

            var result = new reservationPopup1Component_815956_onClick_Response();

            var prms_TM_ReserveLead_0 = new List<kSqlParameter>();
            prms_TM_ReserveLead_0.Add(new kSqlParameter() { Name = "LeadId", Value = request.LeadId_0 });
            prms_TM_ReserveLead_0.Add(new kSqlParameter() { Name = "UserId", Value = Kuika.Common.KContext.CurrentUser?.Id });
            prms_TM_ReserveLead_0.Add(new kSqlParameter() { Name = "Note", Value = request.Note_0 });
            using var auditTM_ReserveLead_0 = ActionAuditScope.Begin("6a40fb83-131d-0766-c0c2-b0e335a2685f", "TM_ReserveLead", applicationName: "wbTimesCRM", screenOrEndpointName: "reservationPopup1");
            result.TM_ReserveLead = KPersister.Fetch(KContext.GetConnectionString(), @"DECLARE @Success INT = 0;
DECLARE @Message NVARCHAR(200) = '';

DECLARE @IsApproved BIT = 0;
DECLARE @Kategori NVARCHAR(100);

DECLARE @IsMagazaMuduru BIT = 0;
DECLARE @IsYonetici BIT = 0;
DECLARE @IsUstYonetici BIT = 0;
DECLARE @IsSatisPersoneli BIT = 0;

DECLARE @ReservationId UNIQUEIDENTIFIER = NEWID();

BEGIN TRY
    BEGIN TRAN

    --------------------------------------------------
    -- 🔥 KATEGORİ ÇEK
    --------------------------------------------------
    SELECT 
        @Kategori = p.CategoryName
    FROM tmscrq.TMLead l
    INNER JOIN tmscrq.TMProduct p ON p.Id = l.ProductId
    WHERE l.Id = @LeadId;

    --------------------------------------------------
    -- 🔥 ROLLER
    --------------------------------------------------
    IF EXISTS (
        SELECT 1 FROM dbo.KUserRole kur
        INNER JOIN dbo.KRole kr ON kr.Id = kur.KRole_Id
        WHERE kur.KUser_Id = @UserId 
          AND kr.Name = 'TimesMagazaMuduru'
          AND ISNULL(kur.IsDeleted,0)=0 
          AND ISNULL(kr.IsDeleted,0)=0
    )
    SET @IsMagazaMuduru = 1;

    IF EXISTS (
        SELECT 1 FROM dbo.KUserRole kur
        INNER JOIN dbo.KRole kr ON kr.Id = kur.KRole_Id
        WHERE kur.KUser_Id = @UserId 
          AND kr.Name = 'TimesYonetici'
          AND ISNULL(kur.IsDeleted,0)=0 
          AND ISNULL(kr.IsDeleted,0)=0
    )
    SET @IsYonetici = 1;

    IF EXISTS (
        SELECT 1 FROM dbo.KUserRole kur
        INNER JOIN dbo.KRole kr ON kr.Id = kur.KRole_Id
        WHERE kur.KUser_Id = @UserId 
          AND kr.Name = 'TimesUstYonetici'
          AND ISNULL(kur.IsDeleted,0)=0 
          AND ISNULL(kr.IsDeleted,0)=0
    )
    SET @IsUstYonetici = 1;

    IF EXISTS (
        SELECT 1 FROM dbo.KUserRole kur
        INNER JOIN dbo.KRole kr ON kr.Id = kur.KRole_Id
        WHERE kur.KUser_Id = @UserId 
          AND kr.Name = 'TimesSatisPersoneli'
          AND ISNULL(kur.IsDeleted,0)=0 
          AND ISNULL(kr.IsDeleted,0)=0
    )
    SET @IsSatisPersoneli = 1;

    --------------------------------------------------
    -- 🔥 ISAPPROVED LOGIC
    --------------------------------------------------
    SET @IsApproved =
    CASE
        WHEN @IsSatisPersoneli = 1 THEN 0
        WHEN @IsMagazaMuduru = 1 AND @Kategori = 'Kategori 1' THEN 1
        WHEN @IsMagazaMuduru = 1 AND @Kategori IN ('Kategori 2','Kategori 3') THEN 0
        WHEN @IsYonetici = 1 OR @IsUstYonetici = 1 THEN 1
        ELSE 0
    END;

    --------------------------------------------------
    -- 🔥 AKTİF REZERV KONTROLÜ
    --------------------------------------------------
    IF EXISTS (
        SELECT 1
        FROM tmscrq.TMLeadReservation WITH (UPDLOCK, HOLDLOCK)
        WHERE LeadId = @LeadId
          AND IsActive = 1
    )
    BEGIN
        ROLLBACK;
        SET @Success = 0;
        SET @Message = N'Bu kayıt zaten rezerve edilmiş.';
    END
    ELSE
    BEGIN
        --------------------------------------------------
        -- 🔹 Lead update
        --------------------------------------------------
        UPDATE tmscrq.TMLead
        SET IsReserved = 1
        WHERE Id = @LeadId;

        --------------------------------------------------
        -- 🔹 Reservation INSERT
        --------------------------------------------------
        INSERT INTO tmscrq.TMLeadReservation (
            Id,
            LeadId,
            ReservedBy,
            ReservedAt,
            ReservationNote,
            IsActive,
            IsApproved
        )
        VALUES (
            @ReservationId,
            @LeadId,
            @UserId,
            SYSDATETIMEOFFSET(),
            @Note,
            1,
            @IsApproved
        );

        --------------------------------------------------
        -- 🔥 PROCESS UPDATE (EKLENDİ)
        --------------------------------------------------
        IF @IsApproved = 1
        BEGIN
            DECLARE @DeliveryPendingProcessId UNIQUEIDENTIFIER;

            SELECT TOP 1 @DeliveryPendingProcessId = Id
            FROM tmscrq.TMLeadProcess
            WHERE Code = 'DELIVERY_PENDING';

            UPDATE tmscrq.TMLead
            SET ProcessID = @DeliveryPendingProcessId
            WHERE Id = @LeadId;

            --------------------------------------------------
            -- 🔥 PROCESS LOG
            --------------------------------------------------
            INSERT INTO tmscrq.TMLeadProcessLog
            (
                Id,
                CreatedAt,
                CreatedBy,
                IsApproved,
                LeadId,
                Note,
                ProcessId
            )
            VALUES
            (
                NEWID(),
                SYSDATETIMEOFFSET(),
                @UserId,
                1,
                @LeadId,
                N'Talep teslim bekliyor sürecine alındı',
                @DeliveryPendingProcessId
            );
        END

        --------------------------------------------------
        -- 🔥 RESERVATION LOG
        --------------------------------------------------
        INSERT INTO tmscrq.TMLeadReservationLog
        (
            Id,
            ActionType,
            CreatedAt,
            CreatedBy,
            OldValue,
            NewValue,
            Note,
            ReservationId
        )
        VALUES
        (
            NEWID(),
            N'Rezerv Oluşturuldu',
            SYSDATETIMEOFFSET(),
            @UserId,
            N'Rezerve Değil',
            CASE 
                WHEN @IsApproved = 1 THEN N'Rezerve Edildi (Onaylandı)'
                ELSE N'Rezerve Edildi (Onay Bekliyor)'
            END,
            @Note,
            @ReservationId
        );

        --------------------------------------------------
        -- 🔹 LEAD LOG
        --------------------------------------------------
        INSERT INTO tmscrq.TMLeadUpdateLog
        (
            Id,
            ColumnName,
            LeadId,
            NewValue,
            OldValue,
            UpdatedAt,
            UpdatedBy
        )
        VALUES
        (
            NEWID(),
            N'Rezerv Durumu',
            @LeadId,
            CASE 
                WHEN @IsApproved = 1 THEN N'Rezerve Edildi (Onaylandı)'
                ELSE N'Rezerve Edildi (Onay Bekliyor)'
            END,
            N'Rezerve Değil',
            SYSDATETIME(),
            @UserId
        );

        COMMIT;

        SET @Success = 1;

        SET @Message = 
        CASE 
            WHEN @IsApproved = 1 THEN N'Rezerv oluşturuldu ve otomatik onaylandı.'
            ELSE N'Rezerv oluşturuldu, onay bekliyor.'
        END;
    END

END TRY
BEGIN CATCH
    ROLLBACK;
    SET @Success = 0;
    SET @Message = ERROR_MESSAGE();
END CATCH

SELECT 
    @Success AS Success,
    @Message AS Message;", new string[] { "Success", "Message" }, prms_TM_ReserveLead_0.ToArray());
            ;


            return Ok(result);
        }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class reservationPopup1PageInit_Request
    {
        public Guid? LeadId_0 { set; get; }
        public Guid? LeadId_1 { set; get; }
        public Guid? LeadId_2 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class reservationPopup1PageInit_Response
    {
        public KCommonEntityPage TMGetProductDetailStockByLeadId { set; get; }

        public KCommonEntityPage TM_GetLeadById { set; get; }

        public KCommonEntityPage TM_CheckLeadPriorityNew { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class reservationPopup1Component_815956_onClick_Request
    {
        public Guid? LeadId_0 { set; get; }
        public Guid? UserId_0 { set; get; }
        public String Note_0 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class reservationPopup1Component_815956_onClick_Response
    {
        public KCommonEntityPage TM_ReserveLead { set; get; }

    }
}
