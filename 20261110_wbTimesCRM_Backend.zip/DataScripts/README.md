# DataScripts

Run data (DML) SQL scripts after deployment WITHOUT direct database access. Each
script is run on demand, by name, and recorded so it will not run twice.

## How it works
- After exporting the app, add your `*.sql` files here — e.g. `insert_lookups.sql`.
  Put a single statement or a whole batch in one file; it's up to you. Prefix names
  with `01_`, `02_`, … if you care about the order shown by /list.
- After deploy, an authenticated user:
  1. `GET  /v1/api/DataScript/list`                          -> see script names + whether each already ran (who / when)
  2. `POST /v1/api/DataScript/execute?fileName=insert_lookups.sql`  -> run that one
- Each `/execute` runs ONE named file's statements in a SINGLE transaction. In that same
  transaction a row is written to the internal `KDataScriptExecution` table recording the
  app, file name, timestamp and the user who ran it. On any error the transaction rolls
  back — neither the data nor the record is written — and the message is returned so you
  can fix and retry.
- A script that already ran for this app will NOT run again — `/execute` returns an
  "already executed" message with who ran it and when. `/list` shows the same audit.

## Important
- Run-once is enforced by the `KDataScriptExecution` journal table in the app's database,
  NOT by renaming files. It therefore survives container recreation, read-only/ephemeral
  filesystems and multi-replica deployments — a script runs exactly once per app.
- **Do NOT rename a script that has already run.** Run-once is keyed on the file NAME, so a
  renamed file is treated as a brand-new, not-yet-run script and WILL execute again (risking a
  double run). For the same reason, editing an already-run file does not make it run again — to
  apply new or corrected SQL, add it under a NEW name (e.g. `insert_lookups_v2.sql`). You can
  see which scripts have already run (and who ran them, and when) with
  `GET /v1/api/DataScript/list`.
- Use this for data (INSERT / UPDATE / DELETE), not schema changes.
- **Data statements only — DDL is rejected.** A file whose statement starts with a schema keyword
  (`CREATE`, `ALTER`, `DROP`, `TRUNCATE`, `RENAME`), a permission keyword (`GRANT`, `REVOKE`,
  `DENY`), `USE`, or `EXEC` / `EXECUTE` is refused BEFORE anything runs — the response names the
  offending keyword (e.g. `"Script contains a 'DROP' statement…"`). Write `INSERT` / `UPDATE` /
  `DELETE` (with `SELECT` / `WITH` / `DECLARE` / `SET` as needed); for schema changes use the
  migration endpoint. (`EXEC` is refused because it can run arbitrary DDL, e.g. `EXEC('DROP …')` or
  `EXEC sp_rename …`.)

## Transactions — the endpoint already handles this for you
Every `/execute` runs the WHOLE file — all of its statements PLUS the run record — inside a
SINGLE database transaction. **You do not need to add your own transaction.** If any statement
fails, the transaction is rolled back (nothing is applied and nothing is recorded) and the error
message is returned, so you can fix the script and run it again. On success everything commits
together, atomically.

If you still want explicit control, use the standard defensive pattern — it nests correctly
inside the wrapping transaction and behaves as expected:
```sql
BEGIN TRY
    BEGIN TRAN;
        -- your INSERT / UPDATE / DELETE
    COMMIT TRAN;
END TRY
BEGIN CATCH
    IF @@TRANCOUNT > 0 ROLLBACK TRAN;
    THROW;
END CATCH
```
**Do NOT write a bare `ROLLBACK` / `COMMIT`** — one that has no matching `BEGIN TRAN` of its own
and does not re-throw. A bare `ROLLBACK` cancels the endpoint's wrapping transaction; the run
record is then written afterwards, so the script would be marked as executed even though its data
was rolled back (and it would never run again). Let the endpoint manage the transaction, or use
the guarded pattern above.

## Write your SQL in your database's own dialect
The file's contents are sent to the database **verbatim** — the platform does not translate
SQL between engines. Write each script in the dialect of the database this app runs on
(SQL Server, PostgreSQL or Oracle). If the SQL is not valid for that engine, the whole run
is rolled back (nothing is applied and nothing is journaled) and the database's error message
is returned — fix the script and call `/execute` again.
- **Statement separation:** on SQL Server you may separate batches with a `GO` line; on
  PostgreSQL and Oracle use `;` (the whole file runs as one batch).
- **Functions/keywords are engine-specific:** e.g. `NEWID()` / `GETDATE()` / `TOP` / `[brackets]`
  are SQL Server only. PostgreSQL uses `gen_random_uuid()` / `now()` / `LIMIT` / `"quotes"`;
  Oracle uses `SYS_GUID()` / `SYSTIMESTAMP` / `ROWNUM` / `"quotes"`.
- **Identifier casing (PostgreSQL & Oracle):** Kuika creates tables with **quoted, mixed-case**
  names (e.g. `"dbo"."KTable"`, column `"MyColumn"`). Unquoted identifiers are folded to a
  different case by these engines and will NOT match, so you must quote them to match how Kuika
  created them:
  - PostgreSQL: `insert into "dbo"."KTable" ("MyColumn") values ('x');`
  - Oracle:     `insert into "KTable" ("MyColumn") values ('x');`
  - SQL Server: `insert into KTable (MyColumn) values ('x');`  -- case-insensitive, no quoting needed
