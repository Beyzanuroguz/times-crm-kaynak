
using System;
using System.Threading.Tasks;
using Kuika.Common;
using Kuika.Common.Attributes;
using Kuika.Common.Bases;
using Kuika.Common.Accessors;
using Kuika.Common.Json;
using Kuika.Common.Classes;
using Kuika.Common.Exceptions;
using Kuika.Common.Interfaces;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Kuika.Common.Helpers;
using Kuika.Common.Settings;
using System.Collections.Generic;
using Kuika.Common.Extensions;
using System.Linq;
using Kuika.Common.Rest;
using WorkflowCore.Interface;
using Kuika.Common.Workflow;
using Kuika.Common.Workflow.Extensions;
using Kuika.Common.Workflow.DTOs;
using Kuika.Common.Models;
using Kuika.Common.Entities;
using Kuika.Common.Scheduler.Attributes;
using Kuika.Common.Scheduler.Interfaces;
using Kuika.Common.Scheduler.Extensions;
using Quartz;
using Kuika.Common.Scheduler.DTOs;
using Iyzipay.Model.V2.Subscription;
using Kuika.Common.Payments.Iyzico;
using Kuika.Common.Payments.Param;
using Kuika.Common.Audit;
using Kuika.Common.Mcp;
using Kuika.ThirdPartyApisCollection;


namespace Kuika.Reslen_01.Job.Api
{
    [DisallowConcurrentExecution]
    [SchedulerJob("51ded79a-33bf-b3b9-88a4-b4986a6a903b", "ERPCONNECT", "0/1 0/30 * ? * * *", "Europe/London")]
    public class ERPCONNECT : ISchedulerJob
    {

        #region ..Properties..

        Guid ISchedulerJob.Id => Guid.Parse("51ded79a-33bf-b3b9-88a4-b4986a6a903b") ;

        string ISchedulerJob.Name => "ERPCONNECT";

        string ISchedulerJob.Description => "ERPCONNECT";

        private string appName = "wbTimesCRM";
        private Guid appId = Guid.Parse("0e8ecb48-8c52-463c-5db5-08de3ec441b1");

        private string connectionString { get { return Kuika.Common.KContext.GetConnectionString(); } }

        #endregion

        #region ..Publics..

        public System.Threading.Tasks.Task Execute(IJobExecutionContext context)
        {
            var log = new SchedulerJobExecutionLog();
            log.StartDate = DateTime.Now;
            try
            {
                var request = new ERPCONNECT_Request()
                {
                    			date_8 = (DateTime.Now.ConvertToType<DateTime>()),
			date_9 = (DateTime.Now.ConvertToType<DateTime>())
                };
                Inner_Execute(request);
                log.IsSuccess = true;
                return System.Threading.Tasks.Task.CompletedTask;
            }
            catch (Exception ex)
            {
                var sTrace = ex.StackTrace ?? string.Empty;
                log.ResultMessage = $"{ex.Message}{Environment.NewLine}StackTrace: {sTrace}";
                log.IsSuccess = false;
                JobExecutionException executionException = new(ex)
                {
                    UnscheduleFiringTrigger = false
                };
                return System.Threading.Tasks.Task.CompletedTask;
                //throw executionException;
            }
            finally
            {
                log.FinishDate = DateTime.Now;
                this.LogJobExecution(log);
            }
        }

        private ERPCONNECT_Response Inner_Execute(ERPCONNECT_Request request)
        {
            var result = new ERPCONNECT_Response();
            			  
            using var auditConnect_0 = ActionAuditScope.Begin("56d9b5a9-0c32-d23b-d4ee-8faf1e75d5a1", "Connect", applicationName: "wbTimesCRM", screenOrEndpointName: "ERPCONNECT");
            using var actionAuditConnect_0 = ActionAuditHelper.Begin("Connect", null);
            try
            {
                Kuika.ThirdPartyApisCollection.DBConnectCsharp.Connect();
            }
            catch (Exception ex)
            {
                actionAuditConnect_0.SetException(ex);
                throw;
            }
;
			  
            using var auditSyncProductExcel_1 = ActionAuditScope.Begin("7ea836b7-7c76-08d5-fcd0-8934d3f9e4eb", "SyncProductExcel", applicationName: "wbTimesCRM", screenOrEndpointName: "ERPCONNECT");
            using var actionAuditSyncProductExcel_1 = ActionAuditHelper.Begin("SyncProductExcel", null);
            try
            {
                result.SyncProductExcel = Kuika.ThirdPartyApisCollection.GetItemExcel.SyncProductExcel(connectionString);
                actionAuditSyncProductExcel_1.SetResult(result.SyncProductExcel);
            }
            catch (Exception ex)
            {
                actionAuditSyncProductExcel_1.SetException(ex);
                throw;
            }
;
			           var prms_TMProductMergeInsert_2 = new List<kSqlParameter>();
         using var auditTMProductMergeInsert_2 = ActionAuditScope.Begin("af36634d-f5d7-417d-a6e0-b97978c27bb2", "TMProductMergeInsert", applicationName: "wbTimesCRM", screenOrEndpointName: "ERPCONNECT");
            result.TMProductMergeInsert = KPersister.Save(KContext.GetConnectionString(), @"INSERT INTO tmscrq.TMProduct
(
    Id,
    Bracelet,
    Brand,
    CategoryName,
    Dial,
    ProductCode,
    ProductName,
    Referance,
    RMCCode,
    IsDeleted,
    IsInNebim
)
SELECT
    NEWID(),
    S.Bracelet,
    S.Brand,
    COALESCE(NULLIF(LTRIM(RTRIM(S.CategoryName)), ''), 'DEFAULT'),
    S.Dial,
    S.ProductCode,
    S.ProductName,
    S.Referance,
    S.RMCCode,
    0,
    1
FROM tmscrq.TMProductExcel S
WHERE
    S.ProductCode IS NOT NULL
    AND LTRIM(RTRIM(S.ProductCode)) <> ''
    AND NOT EXISTS
    (
        SELECT 1
        FROM tmscrq.TMProduct T
        WHERE T.ProductCode = S.ProductCode
    );", prms_TMProductMergeInsert_2.ToArray());
;
			           var prms_TMProductMergeUpdate_3 = new List<kSqlParameter>();
         using var auditTMProductMergeUpdate_3 = ActionAuditScope.Begin("82d44d09-8a30-e8f6-8c46-cd99b3722fa3", "TMProductMergeUpdate", applicationName: "wbTimesCRM", screenOrEndpointName: "ERPCONNECT");
            result.TMProductMergeUpdate = KPersister.Save(KContext.GetConnectionString(), @"UPDATE T
SET
    T.Bracelet     = S.Bracelet,
    T.Brand        = S.Brand,
    T.CategoryName = COALESCE(NULLIF(LTRIM(RTRIM(S.CategoryName)), ''), 'DEFAULT'),
    T.Dial         = S.Dial,
    T.ProductName  = S.ProductName,
    T.Referance    = S.Referance,
    T.RMCCode      = S.RMCCode,
    T.IsDeleted    = 0,
    T.IsInNebim    = 1
FROM tmscrq.TMProduct T
INNER JOIN tmscrq.TMProductExcel S
    ON T.ProductCode = S.ProductCode
WHERE
    ISNULL(T.Bracelet,'')     <> ISNULL(S.Bracelet,'') OR
    ISNULL(T.Brand,'')        <> ISNULL(S.Brand,'') OR
    ISNULL(T.CategoryName,'') <> ISNULL(S.CategoryName,'') OR
    ISNULL(T.Dial,'')         <> ISNULL(S.Dial,'') OR
    ISNULL(T.ProductName,'')  <> ISNULL(S.ProductName,'') OR
    ISNULL(T.Referance,'')    <> ISNULL(S.Referance,'') OR
    ISNULL(T.RMCCode,'')      <> ISNULL(S.RMCCode,'') OR
    ISNULL(T.IsDeleted, 0)    <> 0 OR
    ISNULL(T.IsInNebim, 1)    <> 1;


UPDATE tmscrq.TMProduct
SET CategoryName = 'DEFAULT'
WHERE CategoryName IS NULL OR CategoryName = '';", prms_TMProductMergeUpdate_3.ToArray());
;
			           var prms_TMProductMergeSoftDeleted_4 = new List<kSqlParameter>();
         using var auditTMProductMergeSoftDeleted_4 = ActionAuditScope.Begin("de2ab1b0-478b-fcf1-f36c-8597a24661e2", "TMProductMergeSoftDeleted", applicationName: "wbTimesCRM", screenOrEndpointName: "ERPCONNECT");
            result.TMProductMergeSoftDeleted = KPersister.Save(KContext.GetConnectionString(), @"UPDATE T
SET
    T.IsDeleted = 1,
    T.IsInNebim = 0
FROM tmscrq.TMProduct T
WHERE NOT EXISTS
(
    SELECT 1
    FROM tmscrq.TMProductExcel S
    WHERE S.ProductCode = T.ProductCode
)
AND
(
    ISNULL(T.IsDeleted, 0) <> 1
    OR ISNULL(T.IsInNebim, 1) <> 0
);", prms_TMProductMergeSoftDeleted_4.ToArray());
;
			  
            using var auditSyncSalesPaymentList_5 = ActionAuditScope.Begin("4946576f-5f4e-e573-a166-621640afd2e5", "SyncSalesPaymentList", applicationName: "wbTimesCRM", screenOrEndpointName: "ERPCONNECT");
            using var actionAuditSyncSalesPaymentList_5 = ActionAuditHelper.Begin("SyncSalesPaymentList", null);
            try
            {
                result.SyncSalesPaymentList = Kuika.ThirdPartyApisCollection.SalesPaymentList.SyncSalesPaymentList(connectionString);
                actionAuditSyncSalesPaymentList_5.SetResult(result.SyncSalesPaymentList);
            }
            catch (Exception ex)
            {
                actionAuditSyncSalesPaymentList_5.SetException(ex);
                throw;
            }
;
			           var prms_TMSalesPaymentListMerge_6 = new List<kSqlParameter>();
         using var auditTMSalesPaymentListMerge_6 = ActionAuditScope.Begin("a49ef328-454b-8149-5c79-7416ef0b62b8", "TMSalesPaymentListMerge", applicationName: "wbTimesCRM", screenOrEndpointName: "ERPCONNECT");
            result.TMSalesPaymentListMerge = KPersister.Save(KContext.GetConnectionString(), @"-- 1 Güncelle
UPDATE T
SET
    T.CurrAccDescription = S.CurrAccDescription,
    T.CurrencyCode = S.CurrencyCode,
    T.PaymentTypeDesc = S.PaymentTypeDesc,
    T.IsDeleted = 0
FROM tmscrq.TMSalesPaymentList T
INNER JOIN tmscrq.TMSalesPaymentListTemp S
    ON T.PaymentType = S.PaymentType
   AND T.CurrAccCode = S.CurrAccCode
   AND T.OfficeCode = S.OfficeCode;

-- 2 Yeni kayıtlar
INSERT INTO tmscrq.TMSalesPaymentList
(
    Id,
    CurrAccCode,
    CurrAccDescription,
    CurrencyCode,
    OfficeCode,
    PaymentType,
    PaymentTypeDesc,
    IsDeleted
)
SELECT
    NEWID(),
    S.CurrAccCode,
    S.CurrAccDescription,
    S.CurrencyCode,
    S.OfficeCode,
    S.PaymentType,
    S.PaymentTypeDesc,
    0
FROM tmscrq.TMSalesPaymentListTemp S
WHERE NOT EXISTS
(
    SELECT 1
    FROM tmscrq.TMSalesPaymentList T
    WHERE T.PaymentType = S.PaymentType
      AND T.CurrAccCode = S.CurrAccCode
      AND T.OfficeCode = S.OfficeCode
);

-- 3 Silinenleri pasife çek
UPDATE T
SET IsDeleted = 1
FROM tmscrq.TMSalesPaymentList T
WHERE NOT EXISTS
(
    SELECT 1
    FROM tmscrq.TMSalesPaymentListTemp S
    WHERE T.PaymentType = S.PaymentType
      AND T.CurrAccCode = S.CurrAccCode
      AND T.OfficeCode = S.OfficeCode
);", prms_TMSalesPaymentListMerge_6.ToArray());
;
			  
            using var auditGetTransfersAndSave_7 = ActionAuditScope.Begin("a46ccaff-d3da-1645-5961-16eb6a5e3695", "GetTransfersAndSave", applicationName: "wbTimesCRM", screenOrEndpointName: "ERPCONNECT");
            using var actionAuditGetTransfersAndSave_7 = ActionAuditHelper.Begin("GetTransfersAndSave", null);
            try
            {
                result.GetTransfersAndSave = Kuika.ThirdPartyApisCollection.GetTransferAndSave.GetTransfersAndSave(connectionString);
                actionAuditGetTransfersAndSave_7.SetResult(result.GetTransfersAndSave);
            }
            catch (Exception ex)
            {
                actionAuditGetTransfersAndSave_7.SetException(ex);
                throw;
            }
;
			  
            using var auditKuika_ExchangeRates_8 = ActionAuditScope.Begin("c8c7dfa4-c09c-ba50-c59e-ca62f741e811", "Kuika_ExchangeRates", applicationName: "wbTimesCRM", screenOrEndpointName: "ERPCONNECT");
            using var actionAuditKuika_ExchangeRates_8 = ActionAuditHelper.Begin("Kuika_ExchangeRates", new { date = System.DateTimeOffset.Now.ConvertToType<DateTime>() });
            try
            {
                result.Kuika_ExchangeRates = Kuika.ThirdPartyApisCollection.ExchangeRates.Kuika_ExchangeRates(System.DateTimeOffset.Now.ConvertToType<DateTime>());
                actionAuditKuika_ExchangeRates_8.SetResult(result.Kuika_ExchangeRates);
            }
            catch (Exception ex)
            {
                actionAuditKuika_ExchangeRates_8.SetException(ex);
                throw;
            }
;
			  
            using var auditSyncRates_9 = ActionAuditScope.Begin("78e2913c-b1d0-6971-f64c-b42231125997", "SyncRates", applicationName: "wbTimesCRM", screenOrEndpointName: "ERPCONNECT");
            using var actionAuditSyncRates_9 = ActionAuditHelper.Begin("SyncRates", new { date = System.DateTimeOffset.Now.ConvertToType<DateTime>() });
            try
            {
                result.SyncRates = Kuika.ThirdPartyApisCollection.SyncExchangeRates.SyncRates(connectionString, System.DateTimeOffset.Now.ConvertToType<DateTime>());
                actionAuditSyncRates_9.SetResult(result.SyncRates);
            }
            catch (Exception ex)
            {
                actionAuditSyncRates_9.SetException(ex);
                throw;
            }
;
			  
            using var auditSyncStores_10 = ActionAuditScope.Begin("3f97e31b-0368-eae2-d1de-b1917796b196", "SyncStores", applicationName: "wbTimesCRM", screenOrEndpointName: "ERPCONNECT");
            using var actionAuditSyncStores_10 = ActionAuditHelper.Begin("SyncStores", null);
            try
            {
                result.SyncStores = Kuika.ThirdPartyApisCollection.GetStore.SyncStores(connectionString);
                actionAuditSyncStores_10.SetResult(result.SyncStores);
            }
            catch (Exception ex)
            {
                actionAuditSyncStores_10.SetException(ex);
                throw;
            }
;
			           var prms_TM_ExpireLeadReservations_11 = new List<kSqlParameter>();
         using var auditTM_ExpireLeadReservations_11 = ActionAuditScope.Begin("61c243c1-345d-0ea0-e7e1-8a8b0ed65654", "TM_ExpireLeadReservations", applicationName: "wbTimesCRM", screenOrEndpointName: "ERPCONNECT");
            result.TM_ExpireLeadReservations = KPersister.Save(KContext.GetConnectionString(), @"DECLARE @ApprovedProcessId UNIQUEIDENTIFIER;
DECLARE @DeliveredProcessId UNIQUEIDENTIFIER;

SELECT @ApprovedProcessId = Id 
FROM tmscrq.TMLeadProcess 
WHERE Code = 'APPROVED';

SELECT @DeliveredProcessId = Id 
FROM tmscrq.TMLeadProcess 
WHERE Code = 'DELIVERED';

BEGIN TRAN

-- 🔹 1. Reservation pasif
UPDATE r
SET r.IsActive = 0
FROM tmscrq.TMLeadReservation r
INNER JOIN tmscrq.TMLead l ON l.Id = r.LeadId
WHERE 
    r.IsActive = 1
    AND r.DeliveryDueDate <= SYSDATETIMEOFFSET()
    AND l.ProcessID <> @DeliveredProcessId;

-- 🔹 2. Lead update (🔥 IsActive KONTROLÜ KALDIRILDI)
UPDATE l
SET 
    l.IsReserved = 0,
    l.ProcessID = @ApprovedProcessId
FROM tmscrq.TMLead l
INNER JOIN tmscrq.TMLeadReservation r 
    ON r.LeadId = l.Id
WHERE 
    r.DeliveryDueDate <= SYSDATETIMEOFFSET()
    AND l.ProcessID <> @DeliveredProcessId;

-- 🔹 3. Log (🔥 IsActive KONTROLÜ KALDIRILDI)
INSERT INTO tmscrq.TMLeadProcessLog (
    Id,
    CreatedAt,
    CreatedBy,
    IsApproved,
    LeadId,
    Note,
    ProcessId
)
SELECT DISTINCT
    NEWID(),
    SYSDATETIMEOFFSET(),
    NULL,
    1,
    l.Id,
    N'Rezerv süresi dolduğu için otomatik iptal edildi.',
    @ApprovedProcessId
FROM tmscrq.TMLead l
INNER JOIN tmscrq.TMLeadReservation r 
    ON r.LeadId = l.Id
WHERE 
    r.DeliveryDueDate <= SYSDATETIMEOFFSET()
    AND l.ProcessID <> @DeliveredProcessId;

COMMIT;", prms_TM_ExpireLeadReservations_11.ToArray());
;
			  
            using var auditGetContacts_12 = ActionAuditScope.Begin("2a2a2d8c-0223-dc86-aa31-dc041f00bf8c", "GetContacts", applicationName: "wbTimesCRM", screenOrEndpointName: "ERPCONNECT");
            using var actionAuditGetContacts_12 = ActionAuditHelper.Begin("GetContacts", null);
            try
            {
                result.GetContacts = Kuika.ThirdPartyApisCollection.GetCurrAccContactInfo.GetContacts(connectionString);
                actionAuditGetContacts_12.SetResult(result.GetContacts);
            }
            catch (Exception ex)
            {
                actionAuditGetContacts_12.SetException(ex);
                throw;
            }
;
			  
            using var auditKuika_CurrAccAttribute_13 = ActionAuditScope.Begin("12b57896-465e-a9fe-6d10-1b3aa0ec84e8", "Kuika_CurrAccAttribute", applicationName: "wbTimesCRM", screenOrEndpointName: "ERPCONNECT");
            using var actionAuditKuika_CurrAccAttribute_13 = ActionAuditHelper.Begin("Kuika_CurrAccAttribute", null);
            try
            {
                result.Kuika_CurrAccAttribute = Kuika.ThirdPartyApisCollection.GetCustomerAttribute.Kuika_CurrAccAttribute();
                actionAuditKuika_CurrAccAttribute_13.SetResult(result.Kuika_CurrAccAttribute);
            }
            catch (Exception ex)
            {
                actionAuditKuika_CurrAccAttribute_13.SetException(ex);
                throw;
            }
;
			  
            using var auditGetSalesPersons_14 = ActionAuditScope.Begin("50766b44-bbe8-6753-5bf2-ec7183bb6c36", "GetSalesPersons", applicationName: "wbTimesCRM", screenOrEndpointName: "ERPCONNECT");
            using var actionAuditGetSalesPersons_14 = ActionAuditHelper.Begin("GetSalesPersons", null);
            try
            {
                result.GetSalesPersons = Kuika.ThirdPartyApisCollection.GetSalesPerson.GetSalesPersons(connectionString);
                actionAuditGetSalesPersons_14.SetResult(result.GetSalesPersons);
            }
            catch (Exception ex)
            {
                actionAuditGetSalesPersons_14.SetException(ex);
                throw;
            }
;

            return result;
        }

        #endregion

    }
}

namespace Kuika.Reslen_01.Job.Api
{
    public class ERPCONNECT_Request 
    {
      public DateTime? date_8 { set; get; } 
      public DateTime? date_9 { set; get; } 
    }
}


namespace Kuika.Reslen_01.Job.Api
{
    public class ERPCONNECT_Response 
    {
      public String SyncProductExcel { set; get; }

      public int TMProductMergeInsert { set; get; }

      public int TMProductMergeUpdate { set; get; }

      public int TMProductMergeSoftDeleted { set; get; }

      public String SyncSalesPaymentList { set; get; }

      public int TMSalesPaymentListMerge { set; get; }

      public System.Collections.Generic.IList<Kuika.ThirdPartyApisCollection.TMTransferModel> GetTransfersAndSave { set; get; }

      public System.Collections.Generic.IList<Kuika.ThirdPartyApisCollection.Kuika_ExchangeRateModel> Kuika_ExchangeRates { set; get; }

      public String SyncRates { set; get; }

      public String SyncStores { set; get; }

      public int TM_ExpireLeadReservations { set; get; }

      public System.Collections.Generic.IList<Kuika.ThirdPartyApisCollection.CurrAccContactModel> GetContacts { set; get; }

      public System.Collections.Generic.IList<Kuika.ThirdPartyApisCollection.Kuika_CurrAccAttributeModel> Kuika_CurrAccAttribute { set; get; }

      public System.Collections.Generic.IList<Kuika.ThirdPartyApisCollection.SalesPersonInfo> GetSalesPersons { set; get; }

    }
}


