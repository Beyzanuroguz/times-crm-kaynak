
using System;
using System.Threading.Tasks;
using Kuika.Common;
using Kuika.Common.Attributes;
using Kuika.Common.Bases;
using Kuika.Common.Accessors;
using Kuika.Common.Json;
using Kuika.Common.Classes;
using Kuika.Common.Exceptions;
using Kuika.Common.Interfaces;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Kuika.Common.Helpers;
using Kuika.Common.Settings;
using System.Collections.Generic;
using Kuika.Common.Extensions;
using System.Linq;
using Kuika.Common.Rest;
using WorkflowCore.Interface;
using Kuika.Common.Workflow;
using Kuika.Common.Workflow.Extensions;
using Kuika.Common.Workflow.DTOs;
using Kuika.Common.Models;
using Kuika.Common.Entities;
using Kuika.Common.Scheduler.Attributes;
using Kuika.Common.Scheduler.Interfaces;
using Kuika.Common.Scheduler.Extensions;
using Quartz;
using Kuika.Common.Scheduler.DTOs;
using Iyzipay.Model.V2.Subscription;
using Kuika.Common.Payments.Iyzico;
using Kuika.Common.Payments.Param;
using Kuika.Common.Audit;
using Kuika.Common.Mcp;
using Kuika.ThirdPartyApisCollection;


namespace Kuika.Reslen_01.Job.Api
{
    [DisallowConcurrentExecution]
    [SchedulerJob("39902d82-714c-0ba8-694c-6085b36ea5ec", "InventoryMerge", "0 0/3 * ? * * *", "Europe/London")]
    public class InventoryMerge : ISchedulerJob
    {

        #region ..Properties..

        Guid ISchedulerJob.Id => Guid.Parse("39902d82-714c-0ba8-694c-6085b36ea5ec") ;

        string ISchedulerJob.Name => "InventoryMerge";

        string ISchedulerJob.Description => "InventoryMerge";

        private string appName = "wbTimesCRM";
        private Guid appId = Guid.Parse("0e8ecb48-8c52-463c-5db5-08de3ec441b1");

        private string connectionString { get { return Kuika.Common.KContext.GetConnectionString(); } }

        #endregion

        #region ..Publics..

        public System.Threading.Tasks.Task Execute(IJobExecutionContext context)
        {
            var log = new SchedulerJobExecutionLog();
            log.StartDate = DateTime.Now;
            try
            {
                var request = new InventoryMerge_Request()
                {
                    			TRANCOUNT_2 = (0.ConvertToType<Int32?>())
                };
                Inner_Execute(request);
                log.IsSuccess = true;
                return System.Threading.Tasks.Task.CompletedTask;
            }
            catch (Exception ex)
            {
                var sTrace = ex.StackTrace ?? string.Empty;
                log.ResultMessage = $"{ex.Message}{Environment.NewLine}StackTrace: {sTrace}";
                log.IsSuccess = false;
                JobExecutionException executionException = new(ex)
                {
                    UnscheduleFiringTrigger = false
                };
                return System.Threading.Tasks.Task.CompletedTask;
                //throw executionException;
            }
            finally
            {
                log.FinishDate = DateTime.Now;
                this.LogJobExecution(log);
            }
        }

        private InventoryMerge_Response Inner_Execute(InventoryMerge_Request request)
        {
            var result = new InventoryMerge_Response();
            			  
            using var auditConnect_0 = ActionAuditScope.Begin("e931c7cf-5548-f7c1-a64d-31f4b784e096", "Connect", applicationName: "wbTimesCRM", screenOrEndpointName: "InventoryMerge");
            using var actionAuditConnect_0 = ActionAuditHelper.Begin("Connect", null);
            try
            {
                Kuika.ThirdPartyApisCollection.DBConnectCsharp.Connect();
            }
            catch (Exception ex)
            {
                actionAuditConnect_0.SetException(ex);
                throw;
            }
;
			  
            using var auditGetItems_1 = ActionAuditScope.Begin("5bcf3035-bd62-8022-dcc9-522f8a5d2374", "GetItems", applicationName: "wbTimesCRM", screenOrEndpointName: "InventoryMerge");
            using var actionAuditGetItems_1 = ActionAuditHelper.Begin("GetItems", null);
            try
            {
                result.GetItems = Kuika.ThirdPartyApisCollection.GetItemInventory1.GetItems(connectionString);
                actionAuditGetItems_1.SetResult(result.GetItems);
            }
            catch (Exception ex)
            {
                actionAuditGetItems_1.SetException(ex);
                throw;
            }
;
			           var prms_TM_ItemInventoryMerge_2 = new List<kSqlParameter>();
         prms_TM_ItemInventoryMerge_2.Add(new kSqlParameter() { Name = "TRANCOUNT", Value = "0".ConvertToType<Int32>()});
         using var auditTM_ItemInventoryMerge_2 = ActionAuditScope.Begin("0247dc86-b5bd-b62e-50f9-d37558bcc618", "TM_ItemInventoryMerge", applicationName: "wbTimesCRM", screenOrEndpointName: "InventoryMerge");
            result.TM_ItemInventoryMerge = KPersister.Save(KContext.GetConnectionString(), @"BEGIN TRAN;

BEGIN TRY

    /* ============================================================
       1. VARSA GÜNCELLE
       ============================================================ */

    UPDATE TARGET
    SET
        TARGET.ColorCode = SOURCE.ColorCode,
        TARGET.ColorDescription = SOURCE.ColorDescription,
        TARGET.CompanyCode = SOURCE.CompanyCode,
        TARGET.InventoryQty1 = SOURCE.InventoryQty1,
        TARGET.ItemDim1Code = SOURCE.ItemDim1Code,
        TARGET.OfficeCode = SOURCE.OfficeCode,
        TARGET.OfficeDescription = SOURCE.OfficeDescription,
        TARGET.ProductAtt01Desc = SOURCE.ProductAtt01Desc,
        TARGET.ProductAtt02Desc = SOURCE.ProductAtt02Desc,
        TARGET.ProductAtt03Desc = SOURCE.ProductAtt03Desc,
        TARGET.ProductAtt04Desc = SOURCE.ProductAtt04Desc,
        TARGET.ProductAtt05Desc = SOURCE.ProductAtt05Desc,
        TARGET.ProductAtt06Desc = SOURCE.ProductAtt06Desc,
        TARGET.ProductAtt07Desc = SOURCE.ProductAtt07Desc,
        TARGET.ProductAtt08Desc = SOURCE.ProductAtt08Desc,
        TARGET.ProductAtt09Desc = SOURCE.ProductAtt09Desc,
        TARGET.ProductAtt10Desc = SOURCE.ProductAtt10Desc,
        TARGET.ProductAtt11Desc = SOURCE.ProductAtt11Desc,
        TARGET.ProductAtt12Desc = SOURCE.ProductAtt12Desc,
        TARGET.ProductAtt13Desc = SOURCE.ProductAtt13Desc,
        TARGET.ProductAtt14Desc = SOURCE.ProductAtt14Desc,
        TARGET.ProductAtt15Desc = SOURCE.ProductAtt15Desc,
        TARGET.ProductAtt16Desc = SOURCE.ProductAtt16Desc,
        TARGET.ProductAtt17Desc = SOURCE.ProductAtt17Desc,
        TARGET.ProductDescription = SOURCE.ProductDescription,
        TARGET.StoreDescription = SOURCE.StoreDescription,
        TARGET.WareHouseDescription = SOURCE.WareHouseDescription
    FROM tmscrq.TMItemInventory AS TARGET
    INNER JOIN tmscrq.TMItemInventoryTemp AS SOURCE
        ON TARGET.ProductCode = SOURCE.ProductCode
        AND ISNULL(TARGET.StoreCode, '') = ISNULL(SOURCE.StoreCode, '')
        AND ISNULL(TARGET.WareHouseCode, '') = ISNULL(SOURCE.WareHouseCode, '');


    /* ============================================================
       2. MAIN'DE YOKSA INSERT
       ============================================================ */

    INSERT INTO tmscrq.TMItemInventory
    (
        Id,
        ColorCode,
        ColorDescription,
        CompanyCode,
        CreatedAt,
        InventoryQty1,
        ItemDim1Code,
        OfficeCode,
        OfficeDescription,
        ProductAtt01Desc,
        ProductAtt02Desc,
        ProductAtt03Desc,
        ProductAtt04Desc,
        ProductAtt05Desc,
        ProductAtt06Desc,
        ProductAtt07Desc,
        ProductAtt08Desc,
        ProductAtt09Desc,
        ProductAtt10Desc,
        ProductAtt11Desc,
        ProductAtt12Desc,
        ProductAtt13Desc,
        ProductAtt14Desc,
        ProductAtt15Desc,
        ProductAtt16Desc,
        ProductAtt17Desc,
        ProductCode,
        ProductDescription,
        StoreCode,
        StoreDescription,
        WareHouseCode,
        WareHouseDescription
    )
    SELECT
        NEWID(),
        SOURCE.ColorCode,
        SOURCE.ColorDescription,
        SOURCE.CompanyCode,
        SYSDATETIMEOFFSET(),
        SOURCE.InventoryQty1,
        SOURCE.ItemDim1Code,
        SOURCE.OfficeCode,
        SOURCE.OfficeDescription,
        SOURCE.ProductAtt01Desc,
        SOURCE.ProductAtt02Desc,
        SOURCE.ProductAtt03Desc,
        SOURCE.ProductAtt04Desc,
        SOURCE.ProductAtt05Desc,
        SOURCE.ProductAtt06Desc,
        SOURCE.ProductAtt07Desc,
        SOURCE.ProductAtt08Desc,
        SOURCE.ProductAtt09Desc,
        SOURCE.ProductAtt10Desc,
        SOURCE.ProductAtt11Desc,
        SOURCE.ProductAtt12Desc,
        SOURCE.ProductAtt13Desc,
        SOURCE.ProductAtt14Desc,
        SOURCE.ProductAtt15Desc,
        SOURCE.ProductAtt16Desc,
        SOURCE.ProductAtt17Desc,
        SOURCE.ProductCode,
        SOURCE.ProductDescription,
        SOURCE.StoreCode,
        SOURCE.StoreDescription,
        SOURCE.WareHouseCode,
        SOURCE.WareHouseDescription
    FROM tmscrq.TMItemInventoryTemp AS SOURCE
    WHERE NOT EXISTS
    (
        SELECT 1
        FROM tmscrq.TMItemInventory AS TARGET
        WHERE TARGET.ProductCode = SOURCE.ProductCode
          AND ISNULL(TARGET.StoreCode, '') = ISNULL(SOURCE.StoreCode, '')
          AND ISNULL(TARGET.WareHouseCode, '') = ISNULL(SOURCE.WareHouseCode, '')
    );


    /* ============================================================
       3. TEMP'TE YOKSA MAIN'DEN SİL
       ============================================================ */

    DELETE TARGET
    FROM tmscrq.TMItemInventory AS TARGET
    WHERE NOT EXISTS
    (
        SELECT 1
        FROM tmscrq.TMItemInventoryTemp AS SOURCE
        WHERE TARGET.ProductCode = SOURCE.ProductCode
          AND ISNULL(TARGET.StoreCode, '') = ISNULL(SOURCE.StoreCode, '')
          AND ISNULL(TARGET.WareHouseCode, '') = ISNULL(SOURCE.WareHouseCode, '')
    );


    COMMIT TRAN;

END TRY

BEGIN CATCH

    IF @@TRANCOUNT > 0
        ROLLBACK TRAN;

    THROW;

END CATCH;", prms_TM_ItemInventoryMerge_2.ToArray());
;

            return result;
        }

        #endregion

    }
}

namespace Kuika.Reslen_01.Job.Api
{
    public class InventoryMerge_Request 
    {
      public Int32? TRANCOUNT_2 { set; get; } 
    }
}


namespace Kuika.Reslen_01.Job.Api
{
    public class InventoryMerge_Response 
    {
      public System.Collections.Generic.IList<Kuika.ThirdPartyApisCollection.ItemInventoryModel1> GetItems { set; get; }

      public int TM_ItemInventoryMerge { set; get; }

    }
}


