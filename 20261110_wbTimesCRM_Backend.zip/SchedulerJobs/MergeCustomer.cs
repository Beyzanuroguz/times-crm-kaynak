
using System;
using System.Threading.Tasks;
using Kuika.Common;
using Kuika.Common.Attributes;
using Kuika.Common.Bases;
using Kuika.Common.Accessors;
using Kuika.Common.Json;
using Kuika.Common.Classes;
using Kuika.Common.Exceptions;
using Kuika.Common.Interfaces;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Kuika.Common.Helpers;
using Kuika.Common.Settings;
using System.Collections.Generic;
using Kuika.Common.Extensions;
using System.Linq;
using Kuika.Common.Rest;
using WorkflowCore.Interface;
using Kuika.Common.Workflow;
using Kuika.Common.Workflow.Extensions;
using Kuika.Common.Workflow.DTOs;
using Kuika.Common.Models;
using Kuika.Common.Entities;
using Kuika.Common.Scheduler.Attributes;
using Kuika.Common.Scheduler.Interfaces;
using Kuika.Common.Scheduler.Extensions;
using Quartz;
using Kuika.Common.Scheduler.DTOs;
using Iyzipay.Model.V2.Subscription;
using Kuika.Common.Payments.Iyzico;
using Kuika.Common.Payments.Param;
using Kuika.Common.Audit;
using Kuika.Common.Mcp;
using Kuika.ThirdPartyApisCollection;


namespace Kuika.Reslen_01.Job.Api
{
    [DisallowConcurrentExecution]
    [SchedulerJob("067e7fb4-28c5-f2d9-4d99-e90848bb74ed", "MergeCustomer", "0/1 0/20 * ? * * *", "Europe/London")]
    public class MergeCustomer : ISchedulerJob
    {

        #region ..Properties..

        Guid ISchedulerJob.Id => Guid.Parse("067e7fb4-28c5-f2d9-4d99-e90848bb74ed") ;

        string ISchedulerJob.Name => "MergeCustomer";

        string ISchedulerJob.Description => "MergeCustomer";

        private string appName = "wbTimesCRM";
        private Guid appId = Guid.Parse("0e8ecb48-8c52-463c-5db5-08de3ec441b1");

        private string connectionString { get { return Kuika.Common.KContext.GetConnectionString(); } }

        #endregion

        #region ..Publics..

        public System.Threading.Tasks.Task Execute(IJobExecutionContext context)
        {
            var log = new SchedulerJobExecutionLog();
            log.StartDate = DateTime.Now;
            try
            {
                var request = new MergeCustomer_Request()
                {
                    
                };
                Inner_Execute(request);
                log.IsSuccess = true;
                return System.Threading.Tasks.Task.CompletedTask;
            }
            catch (Exception ex)
            {
                var sTrace = ex.StackTrace ?? string.Empty;
                log.ResultMessage = $"{ex.Message}{Environment.NewLine}StackTrace: {sTrace}";
                log.IsSuccess = false;
                JobExecutionException executionException = new(ex)
                {
                    UnscheduleFiringTrigger = false
                };
                return System.Threading.Tasks.Task.CompletedTask;
                //throw executionException;
            }
            finally
            {
                log.FinishDate = DateTime.Now;
                this.LogJobExecution(log);
            }
        }

        private MergeCustomer_Response Inner_Execute(MergeCustomer_Request request)
        {
            var result = new MergeCustomer_Response();
            			  
            using var auditConnect_0 = ActionAuditScope.Begin("3b3ea9b2-d8d3-f641-c4f1-63c95e787d9f", "Connect", applicationName: "wbTimesCRM", screenOrEndpointName: "MergeCustomer");
            using var actionAuditConnect_0 = ActionAuditHelper.Begin("Connect", null);
            try
            {
                Kuika.ThirdPartyApisCollection.DBConnectCsharp.Connect();
            }
            catch (Exception ex)
            {
                actionAuditConnect_0.SetException(ex);
                throw;
            }
;
			  
            using var auditSyncCustomers_1 = ActionAuditScope.Begin("014b9a54-62cd-4d80-4a2d-9324fdb94f75", "SyncCustomers", applicationName: "wbTimesCRM", screenOrEndpointName: "MergeCustomer");
            using var actionAuditSyncCustomers_1 = ActionAuditHelper.Begin("SyncCustomers", null);
            try
            {
                result.SyncCustomers = Kuika.ThirdPartyApisCollection.GetCustomer.SyncCustomers(connectionString);
                actionAuditSyncCustomers_1.SetResult(result.SyncCustomers);
            }
            catch (Exception ex)
            {
                actionAuditSyncCustomers_1.SetException(ex);
                throw;
            }
;
			           var prms_TM_CustomerMergeUpdate_2 = new List<kSqlParameter>();
         using var auditTM_CustomerMergeUpdate_2 = ActionAuditScope.Begin("483a0d70-fc82-2c6c-da29-7bf0ce6109e7", "TM_CustomerMergeUpdate", applicationName: "wbTimesCRM", screenOrEndpointName: "MergeCustomer");
            result.TM_CustomerMergeUpdate = KPersister.Save(KContext.GetConnectionString(), @"UPDATE T
SET
    T.Name                  = S.Name,
    T.LastName              = S.LastName,
    T.CurrAccDescription    = S.CurrAccDescription,
    T.Address               = S.Address,
    T.BirthDate             = S.BirthDate,

    T.CityName              = S.CityName,
    T.CityCode              = S.CityCode,

    T.CountryName           = S.CountryName,
    T.CountryCode           = S.CountryCode,

    T.StateCode             = S.StateCode,

    T.DistrictCode          = S.DistrictCode,
    T.DistrictName          = S.DistrictName,

    T.Email                 = S.Email,
    T.EmailID               = S.EmailID,

    T.Tel                   = S.Tel,
    T.TelID                 = S.TelID,

    T.MobilePhoneID         = S.MobilePhoneID,
    T.PostalAddressID       = S.PostalAddressID,

    T.IsShopping            = S.IsShopping,
    T.IsEInvoice            = S.IsEInvoice,

    T.NationalID            = S.NationalID,
    T.PasaportNo            = S.PasaportNo,
    T.PasaportCountryCode   = S.PasaportCountryCode,
    T.PasaportCountryDescription = S.PasaportCountryDescription,
    T.PassaportIssueDate    = S.PassaportIssueDate,

    T.TaxNumber             = S.TaxNumber,

    T.IsIndividual          = S.IsIndividual,
    T.AccountTypeDesc       = S.AccountTypeDesc,
    T.TaxOfficeActualCode   = S.TaxOfficeActualCode,
    T.TaxOfficeDesc         = S.TaxOfficeDesc,

    T.CustomerType          = S.CustomerType,
    T.CustomerTypeCode      = S.CustomerTypeCode,

    -- Nebim'de tekrar varsa aktif
    T.IsDeleted             = 0

FROM tmscrq.TMCustomer T
INNER JOIN tmscrq.TMCustomerTemp S
    ON T.CurrAccCode = S.CurrAccCode;", prms_TM_CustomerMergeUpdate_2.ToArray());
;
			           var prms_TM_CustomerMergeInsert_3 = new List<kSqlParameter>();
         using var auditTM_CustomerMergeInsert_3 = ActionAuditScope.Begin("e5d6a28a-2bd6-116d-64ec-41c8ec480aa1", "TM_CustomerMergeInsert", applicationName: "wbTimesCRM", screenOrEndpointName: "MergeCustomer");
            result.TM_CustomerMergeInsert = KPersister.Save(KContext.GetConnectionString(), @"INSERT INTO tmscrq.TMCustomer (
    Id,
    Name,
    LastName,
    CurrAccDescription,
    Address,
    BirthDate,

    CityName,
    CityCode,

    CountryName,
    CountryCode,

    StateCode,

    DistrictCode,
    DistrictName,

    CurrAccCode,

    Email,
    EmailID,

    Tel,
    TelID,

    MobilePhoneID,
    PostalAddressID,

    IsShopping,
    IsEInvoice,

    NationalID,

    PasaportNo,
    PasaportCountryCode,
    PasaportCountryDescription,
    PassaportIssueDate,

    TaxNumber,

    IsIndividual,
    AccountTypeDesc,
    TaxOfficeActualCode,
    TaxOfficeDesc,

    CustomerType,
    CustomerTypeCode
)
SELECT
    NEWID(),
    S.Name,
    S.LastName,
    S.CurrAccDescription,
    S.Address,
    S.BirthDate,

    S.CityName,
    S.CityCode,

    S.CountryName,
    S.CountryCode,

    S.StateCode,

    S.DistrictCode,
    S.DistrictName,

    S.CurrAccCode,

    S.Email,
    S.EmailID,

    S.Tel,
    S.TelID,

    S.MobilePhoneID,
    S.PostalAddressID,

    S.IsShopping,
    S.IsEInvoice,

    S.NationalID,

    S.PasaportNo,
    S.PasaportCountryCode,
    S.PasaportCountryDescription,
    S.PassaportIssueDate,

    S.TaxNumber,

    S.IsIndividual,
    S.AccountTypeDesc,
    S.TaxOfficeActualCode,
    S.TaxOfficeDesc,

    S.CustomerType,
    S.CustomerTypeCode
FROM tmscrq.TMCustomerTemp S
LEFT JOIN tmscrq.TMCustomer T
    ON T.CurrAccCode = S.CurrAccCode
WHERE T.Id IS NULL;", prms_TM_CustomerMergeInsert_3.ToArray());
;
			           var prms_TM_CustomerMergeSoftDelete_4 = new List<kSqlParameter>();
         using var auditTM_CustomerMergeSoftDelete_4 = ActionAuditScope.Begin("38df52e4-2948-04bc-d615-4c19a332ee0c", "TM_CustomerMergeSoftDelete", applicationName: "wbTimesCRM", screenOrEndpointName: "MergeCustomer");
            result.TM_CustomerMergeSoftDelete = KPersister.Save(KContext.GetConnectionString(), @"UPDATE T
SET T.IsDeleted = 1
FROM tmscrq.TMCustomer T
LEFT JOIN tmscrq.TMCustomerTemp S
    ON S.CurrAccCode = T.CurrAccCode
WHERE S.CurrAccCode IS NULL
  AND T.CurrAccCode IS NOT NULL
  AND LTRIM(RTRIM(T.CurrAccCode)) <> ''
  AND T.IsDeleted = 0;", prms_TM_CustomerMergeSoftDelete_4.ToArray());
;

            return result;
        }

        #endregion

    }
}

namespace Kuika.Reslen_01.Job.Api
{
    public class MergeCustomer_Request 
    {
    }
}


namespace Kuika.Reslen_01.Job.Api
{
    public class MergeCustomer_Response 
    {
      public String SyncCustomers { set; get; }

      public int TM_CustomerMergeUpdate { set; get; }

      public int TM_CustomerMergeInsert { set; get; }

      public int TM_CustomerMergeSoftDelete { set; get; }

    }
}


