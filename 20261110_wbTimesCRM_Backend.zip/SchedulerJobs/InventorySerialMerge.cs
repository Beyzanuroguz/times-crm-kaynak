
using System;
using System.Threading.Tasks;
using Kuika.Common;
using Kuika.Common.Attributes;
using Kuika.Common.Bases;
using Kuika.Common.Accessors;
using Kuika.Common.Json;
using Kuika.Common.Classes;
using Kuika.Common.Exceptions;
using Kuika.Common.Interfaces;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Kuika.Common.Helpers;
using Kuika.Common.Settings;
using System.Collections.Generic;
using Kuika.Common.Extensions;
using System.Linq;
using Kuika.Common.Rest;
using WorkflowCore.Interface;
using Kuika.Common.Workflow;
using Kuika.Common.Workflow.Extensions;
using Kuika.Common.Workflow.DTOs;
using Kuika.Common.Models;
using Kuika.Common.Entities;
using Kuika.Common.Scheduler.Attributes;
using Kuika.Common.Scheduler.Interfaces;
using Kuika.Common.Scheduler.Extensions;
using Quartz;
using Kuika.Common.Scheduler.DTOs;
using Iyzipay.Model.V2.Subscription;
using Kuika.Common.Payments.Iyzico;
using Kuika.Common.Payments.Param;
using Kuika.Common.Audit;
using Kuika.Common.Mcp;
using Kuika.ThirdPartyApisCollection;


namespace Kuika.Reslen_01.Job.Api
{
    [DisallowConcurrentExecution]
    [SchedulerJob("3900e6b6-3406-b1e8-9f97-a7dd61f59ddc", "InventorySerialMerge", "0 0/3 * ? * * *", "Europe/London")]
    public class InventorySerialMerge : ISchedulerJob
    {

        #region ..Properties..

        Guid ISchedulerJob.Id => Guid.Parse("3900e6b6-3406-b1e8-9f97-a7dd61f59ddc") ;

        string ISchedulerJob.Name => "InventorySerialMerge";

        string ISchedulerJob.Description => "InventorySerialMerge";

        private string appName = "wbTimesCRM";
        private Guid appId = Guid.Parse("0e8ecb48-8c52-463c-5db5-08de3ec441b1");

        private string connectionString { get { return Kuika.Common.KContext.GetConnectionString(); } }

        #endregion

        #region ..Publics..

        public System.Threading.Tasks.Task Execute(IJobExecutionContext context)
        {
            var log = new SchedulerJobExecutionLog();
            log.StartDate = DateTime.Now;
            try
            {
                var request = new InventorySerialMerge_Request()
                {
                    
                };
                Inner_Execute(request);
                log.IsSuccess = true;
                return System.Threading.Tasks.Task.CompletedTask;
            }
            catch (Exception ex)
            {
                var sTrace = ex.StackTrace ?? string.Empty;
                log.ResultMessage = $"{ex.Message}{Environment.NewLine}StackTrace: {sTrace}";
                log.IsSuccess = false;
                JobExecutionException executionException = new(ex)
                {
                    UnscheduleFiringTrigger = false
                };
                return System.Threading.Tasks.Task.CompletedTask;
                //throw executionException;
            }
            finally
            {
                log.FinishDate = DateTime.Now;
                this.LogJobExecution(log);
            }
        }

        private InventorySerialMerge_Response Inner_Execute(InventorySerialMerge_Request request)
        {
            var result = new InventorySerialMerge_Response();
            			  
            using var auditConnect_0 = ActionAuditScope.Begin("fe6cb983-2504-81cf-04f5-efc1772e4988", "Connect", applicationName: "wbTimesCRM", screenOrEndpointName: "InventorySerialMerge");
            using var actionAuditConnect_0 = ActionAuditHelper.Begin("Connect", null);
            try
            {
                Kuika.ThirdPartyApisCollection.DBConnectCsharp.Connect();
            }
            catch (Exception ex)
            {
                actionAuditConnect_0.SetException(ex);
                throw;
            }
;
			  
            using var auditGetItemsSerial_1 = ActionAuditScope.Begin("dc8d5340-94cc-cff0-fd3b-5709e2a5c1fc", "GetItemsSerial", applicationName: "wbTimesCRM", screenOrEndpointName: "InventorySerialMerge");
            using var actionAuditGetItemsSerial_1 = ActionAuditHelper.Begin("GetItemsSerial", null);
            try
            {
                result.GetItemsSerial = Kuika.ThirdPartyApisCollection.GetItemSerialInventory.GetItemsSerial(connectionString);
                actionAuditGetItemsSerial_1.SetResult(result.GetItemsSerial);
            }
            catch (Exception ex)
            {
                actionAuditGetItemsSerial_1.SetException(ex);
                throw;
            }
;
			           var prms_TM_ItemSerialInventoryMerge_2 = new List<kSqlParameter>();
         using var auditTM_ItemSerialInventoryMerge_2 = ActionAuditScope.Begin("26538f1f-5490-b579-9bc6-34733e6eb695", "TM_ItemSerialInventoryMerge", applicationName: "wbTimesCRM", screenOrEndpointName: "InventorySerialMerge");
            result.TM_ItemSerialInventoryMerge = KPersister.Save(KContext.GetConnectionString(), @"BEGIN TRAN;

-- 1. TEMP'te olan seri numaralarını UPDATE et
UPDATE T
SET
    T.CompanyCode = S.CompanyCode,
    T.InventoryQty1 = S.InventoryQty1,
    T.OfficeCode = S.OfficeCode,
    T.OfficeDescription = S.OfficeDescription,
    T.ProductCode = S.ProductCode,
    T.ProductDescription = S.ProductDescription,
    T.StoreCode = S.StoreCode,
    T.StoreDescription = S.StoreDescription,
    T.WarehouseCode = S.WarehouseCode,
    T.WarehouseDescription = S.WarehouseDescription
FROM tmscrq.TMItemSerialInventory AS T
INNER JOIN tmscrq.TMItemSerialInventoryTemp AS S
    ON T.SerialNumber = S.SerialNumber;


-- 2. MAIN'de olmayan seri numaralarını INSERT et
INSERT INTO tmscrq.TMItemSerialInventory
(
    Id,
    CompanyCode,
    InventoryQty1,
    OfficeCode,
    OfficeDescription,
    ProductCode,
    ProductDescription,
    SerialNumber,
    StoreCode,
    StoreDescription,
    WarehouseCode,
    WarehouseDescription
)
SELECT
    NEWID(),
    S.CompanyCode,
    S.InventoryQty1,
    S.OfficeCode,
    S.OfficeDescription,
    S.ProductCode,
    S.ProductDescription,
    S.SerialNumber,
    S.StoreCode,
    S.StoreDescription,
    S.WarehouseCode,
    S.WarehouseDescription
FROM tmscrq.TMItemSerialInventoryTemp AS S
WHERE NOT EXISTS
(
    SELECT 1
    FROM tmscrq.TMItemSerialInventory AS T
    WHERE T.SerialNumber = S.SerialNumber
);


-- 3. TEMP'te olmayan seri numaralarını MAIN'den sil
DELETE T
FROM tmscrq.TMItemSerialInventory AS T
WHERE NOT EXISTS
(
    SELECT 1
    FROM tmscrq.TMItemSerialInventoryTemp AS S
    WHERE S.SerialNumber = T.SerialNumber
);

COMMIT;", prms_TM_ItemSerialInventoryMerge_2.ToArray());
;

            return result;
        }

        #endregion

    }
}

namespace Kuika.Reslen_01.Job.Api
{
    public class InventorySerialMerge_Request 
    {
    }
}


namespace Kuika.Reslen_01.Job.Api
{
    public class InventorySerialMerge_Response 
    {
      public System.Collections.Generic.IList<Kuika.ThirdPartyApisCollection.ItemSerialInventoryInfo> GetItemsSerial { set; get; }

      public int TM_ItemSerialInventoryMerge { set; get; }

    }
}


