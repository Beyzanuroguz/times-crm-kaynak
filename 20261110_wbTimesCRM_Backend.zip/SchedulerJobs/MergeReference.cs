
using System;
using System.Threading.Tasks;
using Kuika.Common;
using Kuika.Common.Attributes;
using Kuika.Common.Bases;
using Kuika.Common.Accessors;
using Kuika.Common.Json;
using Kuika.Common.Classes;
using Kuika.Common.Exceptions;
using Kuika.Common.Interfaces;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Kuika.Common.Helpers;
using Kuika.Common.Settings;
using System.Collections.Generic;
using Kuika.Common.Extensions;
using System.Linq;
using Kuika.Common.Rest;
using WorkflowCore.Interface;
using Kuika.Common.Workflow;
using Kuika.Common.Workflow.Extensions;
using Kuika.Common.Workflow.DTOs;
using Kuika.Common.Models;
using Kuika.Common.Entities;
using Kuika.Common.Scheduler.Attributes;
using Kuika.Common.Scheduler.Interfaces;
using Kuika.Common.Scheduler.Extensions;
using Quartz;
using Kuika.Common.Scheduler.DTOs;
using Iyzipay.Model.V2.Subscription;
using Kuika.Common.Payments.Iyzico;
using Kuika.Common.Payments.Param;
using Kuika.Common.Audit;
using Kuika.Common.Mcp;
using Kuika.ThirdPartyApisCollection;


namespace Kuika.Reslen_01.Job.Api
{
    [DisallowConcurrentExecution]
    [SchedulerJob("9bc4996d-c7a8-3d6e-7514-3dd9431349ab", "MergeReference", "0/1 0/30 * ? * * *", "Europe/London")]
    public class MergeReference : ISchedulerJob
    {

        #region ..Properties..

        Guid ISchedulerJob.Id => Guid.Parse("9bc4996d-c7a8-3d6e-7514-3dd9431349ab") ;

        string ISchedulerJob.Name => "MergeReference";

        string ISchedulerJob.Description => "MergeReference";

        private string appName = "wbTimesCRM";
        private Guid appId = Guid.Parse("0e8ecb48-8c52-463c-5db5-08de3ec441b1");

        private string connectionString { get { return Kuika.Common.KContext.GetConnectionString(); } }

        #endregion

        #region ..Publics..

        public System.Threading.Tasks.Task Execute(IJobExecutionContext context)
        {
            var log = new SchedulerJobExecutionLog();
            log.StartDate = DateTime.Now;
            try
            {
                var request = new MergeReference_Request()
                {
                    
                };
                Inner_Execute(request);
                log.IsSuccess = true;
                return System.Threading.Tasks.Task.CompletedTask;
            }
            catch (Exception ex)
            {
                var sTrace = ex.StackTrace ?? string.Empty;
                log.ResultMessage = $"{ex.Message}{Environment.NewLine}StackTrace: {sTrace}";
                log.IsSuccess = false;
                JobExecutionException executionException = new(ex)
                {
                    UnscheduleFiringTrigger = false
                };
                return System.Threading.Tasks.Task.CompletedTask;
                //throw executionException;
            }
            finally
            {
                log.FinishDate = DateTime.Now;
                this.LogJobExecution(log);
            }
        }

        private MergeReference_Response Inner_Execute(MergeReference_Request request)
        {
            var result = new MergeReference_Response();
            			  
            using var auditConnect_0 = ActionAuditScope.Begin("b8e9c488-4f03-2239-f0bc-8fca2cb39eed", "Connect", applicationName: "wbTimesCRM", screenOrEndpointName: "MergeReference");
            using var actionAuditConnect_0 = ActionAuditHelper.Begin("Connect", null);
            try
            {
                Kuika.ThirdPartyApisCollection.DBConnectCsharp.Connect();
            }
            catch (Exception ex)
            {
                actionAuditConnect_0.SetException(ex);
                throw;
            }
;
			           var prms_CustomerReferanceMerge_1 = new List<kSqlParameter>();
         using var auditCustomerReferanceMerge_1 = ActionAuditScope.Begin("76b61493-e83c-81d7-051a-4648bea0d932", "CustomerReferanceMerge", applicationName: "wbTimesCRM", screenOrEndpointName: "MergeReference");
            result.CustomerReferanceMerge = KPersister.Fetch(KContext.GetConnectionString(), @"SET NOCOUNT ON;

MERGE tmscrq.TMReferencePerson AS TARGET

USING
(
    SELECT
        c.Id,
        c.Address,
        c.BirthDate,
        c.CityCode,
        c.CityName,
        c.CountryCode,
        c.CountryName,
        c.CurrAccCode,
        c.CustomerType,
        c.CustomerTypeCode,
        c.DistrictCode,
        c.DistrictName,
        c.Email,
        c.EmailID,
        c.GenderCode,
        c.Info,
        c.IsEInvoice,
        c.IsShopping,
        c.LastName,
        c.MobilePhoneID,
        c.Name,
        c.NationalID,
        c.PasaportCountryCode,
        c.PasaportCountryDescription,
        c.PasaportNo,
        c.PassaportIssueDate,
        c.PostalAddressID,
        c.StateCode,
        c.StateName,
        c.TaxNumber,
        c.Tel,
        c.TelID,

        MATCHED_REF.Id AS MatchedReferencePersonId

    FROM tmscrq.TMCustomer c

    OUTER APPLY
    (
        SELECT TOP 1
            rp.Id

        FROM tmscrq.TMReferencePerson rp

        WHERE
            (
                /* =====================================================
                   1. ÖNCELİK: TELEFON
                   Müşterinin telefonu varsa sadece telefon eşleşmesi
                   üzerinden referans aranır.
                   ===================================================== */

                NULLIF(LTRIM(RTRIM(c.Tel)), '') IS NOT NULL

                AND

                NULLIF(LTRIM(RTRIM(rp.Tel)), '') IS NOT NULL

                AND

                RIGHT
                (
                    REPLACE(
                        REPLACE(
                            REPLACE(
                                REPLACE(
                                    REPLACE(
                                        REPLACE(
                                            LTRIM(RTRIM(c.Tel)),
                                            '+90',
                                            ''
                                        ),
                                        ' ',
                                        ''
                                    ),
                                    '-',
                                    ''
                                ),
                                '(',
                                ''
                            ),
                            ')',
                            ''
                        ),
                        '.',
                        ''
                    ),
                    10
                )

                =

                RIGHT
                (
                    REPLACE(
                        REPLACE(
                            REPLACE(
                                REPLACE(
                                    REPLACE(
                                        REPLACE(
                                            LTRIM(RTRIM(rp.Tel)),
                                            '+90',
                                            ''
                                        ),
                                        ' ',
                                        ''
                                    ),
                                    '-',
                                    ''
                                ),
                                '(',
                                ''
                            ),
                            ')',
                            ''
                        ),
                        '.',
                        ''
                    ),
                    10
                )
            )

            OR

            (
                /* =====================================================
                   2. ÖNCELİK: E-MAIL
                   Telefon yoksa e-mail üzerinden eşleşme yapılır.
                   ===================================================== */

                NULLIF(LTRIM(RTRIM(c.Tel)), '') IS NULL

                AND

                NULLIF(LTRIM(RTRIM(c.Email)), '') IS NOT NULL

                AND

                NULLIF(LTRIM(RTRIM(rp.Email)), '') IS NOT NULL

                AND

                LOWER(LTRIM(RTRIM(c.Email)))
                =
                LOWER(LTRIM(RTRIM(rp.Email)))
            )

        ORDER BY
            CASE

                /* Telefon eşleşmesi */
                WHEN
                    NULLIF(LTRIM(RTRIM(c.Tel)), '') IS NOT NULL
                    AND
                    NULLIF(LTRIM(RTRIM(rp.Tel)), '') IS NOT NULL
                    AND

                    RIGHT
                    (
                        REPLACE(
                            REPLACE(
                                REPLACE(
                                    REPLACE(
                                        REPLACE(
                                            REPLACE(
                                                LTRIM(RTRIM(c.Tel)),
                                                '+90',
                                                ''
                                            ),
                                            ' ',
                                            ''
                                        ),
                                        '-',
                                        ''
                                    ),
                                    '(',
                                    ''
                                ),
                                ')',
                                ''
                            ),
                            '.',
                            ''
                        ),
                        10
                    )

                    =

                    RIGHT
                    (
                        REPLACE(
                            REPLACE(
                                REPLACE(
                                    REPLACE(
                                        REPLACE(
                                            REPLACE(
                                                LTRIM(RTRIM(rp.Tel)),
                                                '+90',
                                                ''
                                            ),
                                            ' ',
                                            ''
                                        ),
                                        '-',
                                        ''
                                    ),
                                    '(',
                                    ''
                                ),
                                ')',
                                ''
                            ),
                            '.',
                            ''
                        ),
                        10
                    )

                THEN 1


                /* E-mail eşleşmesi */
                WHEN
                    NULLIF(LTRIM(RTRIM(c.Tel)), '') IS NULL

                    AND

                    NULLIF(LTRIM(RTRIM(c.Email)), '') IS NOT NULL

                    AND

                    NULLIF(LTRIM(RTRIM(rp.Email)), '') IS NOT NULL

                    AND

                    LOWER(LTRIM(RTRIM(c.Email)))
                    =
                    LOWER(LTRIM(RTRIM(rp.Email)))

                THEN 2

                ELSE 99

            END,
            rp.Id

    ) MATCHED_REF

) AS SOURCE

ON TARGET.Id = SOURCE.MatchedReferencePersonId


/* ============================================================
   EŞLEŞEN KAYIT
   ============================================================ */

WHEN MATCHED THEN

    UPDATE SET

        TARGET.Address =
            SOURCE.Address,

        TARGET.BirthDate =
            SOURCE.BirthDate,

        TARGET.CityCode =
            SOURCE.CityCode,

        TARGET.CityName =
            SOURCE.CityName,

        TARGET.CountryCode =
            SOURCE.CountryCode,

        TARGET.CountryName =
            SOURCE.CountryName,

        TARGET.CurrAccCode =
            SOURCE.CurrAccCode,

        TARGET.CustomerType =
            SOURCE.CustomerType,

        TARGET.CustomerTypeCode =
            SOURCE.CustomerTypeCode,

        TARGET.DistrictCode =
            SOURCE.DistrictCode,

        TARGET.DistrictName =
            SOURCE.DistrictName,

        TARGET.Email =
            SOURCE.Email,

        TARGET.EmailID =
            SOURCE.EmailID,

        TARGET.GenderCode =
            SOURCE.GenderCode,

        TARGET.Info =
            SOURCE.Info,

        TARGET.IsEInvoice =
            SOURCE.IsEInvoice,

        TARGET.IsShopping =
            SOURCE.IsShopping,

        TARGET.LastName =
            SOURCE.LastName,

        TARGET.MobilePhoneID =
            SOURCE.MobilePhoneID,

        TARGET.Name =
            SOURCE.Name,

        TARGET.NationalID =
            SOURCE.NationalID,

        TARGET.PasaportCountryCode =
            SOURCE.PasaportCountryCode,

        TARGET.PasaportCountryDescription =
            SOURCE.PasaportCountryDescription,

        TARGET.PasaportNo =
            SOURCE.PasaportNo,

        TARGET.PassaportIssueDate =
            SOURCE.PassaportIssueDate,

        TARGET.PostalAddressID =
            SOURCE.PostalAddressID,

        TARGET.StateCode =
            SOURCE.StateCode,

        TARGET.StateName =
            SOURCE.StateName,

        TARGET.TaxNumber =
            SOURCE.TaxNumber,

        TARGET.Tel =
            SOURCE.Tel,

        TARGET.TelID =
            SOURCE.TelID


/* ============================================================
   EŞLEŞME YOKSA YENİ REFERANS KİŞİ OLUŞTUR
   ============================================================ */

WHEN NOT MATCHED BY TARGET THEN

    INSERT
    (
        Id,
        Address,
        BirthDate,
        CityCode,
        CityName,
        CountryCode,
        CountryName,
        CurrAccCode,
        CustomerType,
        CustomerTypeCode,
        DistrictCode,
        DistrictName,
        Email,
        EmailID,
        GenderCode,
        Info,
        IsEInvoice,
        IsShopping,
        LastName,
        MobilePhoneID,
        Name,
        NationalID,
        PasaportCountryCode,
        PasaportCountryDescription,
        PasaportNo,
        PassaportIssueDate,
        PostalAddressID,
        StateCode,
        StateName,
        TaxNumber,
        Tel,
        TelID
    )

    VALUES
    (
        SOURCE.Id,
        SOURCE.Address,
        SOURCE.BirthDate,
        SOURCE.CityCode,
        SOURCE.CityName,
        SOURCE.CountryCode,
        SOURCE.CountryName,
        SOURCE.CurrAccCode,
        SOURCE.CustomerType,
        SOURCE.CustomerTypeCode,
        SOURCE.DistrictCode,
        SOURCE.DistrictName,
        SOURCE.Email,
        SOURCE.EmailID,
        SOURCE.GenderCode,
        SOURCE.Info,
        SOURCE.IsEInvoice,
        SOURCE.IsShopping,
        SOURCE.LastName,
        SOURCE.MobilePhoneID,
        SOURCE.Name,
        SOURCE.NationalID,
        SOURCE.PasaportCountryCode,
        SOURCE.PasaportCountryDescription,
        SOURCE.PasaportNo,
        SOURCE.PassaportIssueDate,
        SOURCE.PostalAddressID,
        SOURCE.StateCode,
        SOURCE.StateName,
        SOURCE.TaxNumber,
        SOURCE.Tel,
        SOURCE.TelID
    );


SELECT
    'TMReferencePerson Merge tamamlandı.' AS Result;", new string[] { "Result" }, prms_CustomerReferanceMerge_1.ToArray());
;

            return result;
        }

        #endregion

    }
}

namespace Kuika.Reslen_01.Job.Api
{
    public class MergeReference_Request 
    {
    }
}


namespace Kuika.Reslen_01.Job.Api
{
    public class MergeReference_Response 
    {
      public KCommonEntityPage CustomerReferanceMerge { set; get; }

    }
}


