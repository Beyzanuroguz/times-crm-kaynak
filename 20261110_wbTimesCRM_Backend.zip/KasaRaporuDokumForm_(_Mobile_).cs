using System.Linq;
using System.IO;
using iText.Kernel.Pdf;
using iText.Layout;
using iText.Kernel.Geom;
using System;
using iText.Layout.Element;
using System.Collections.Generic;
using iText.IO.Image;
using iText.Layout.Borders;
using iText.Kernel.Colors;
using iText.Kernel.Events;
using iText.Layout.Renderer;
using iText.Layout.Layout;
using iText.Kernel.Pdf.Canvas;
using iText.Kernel.Pdf.Canvas.Draw;
using iText.Kernel.Pdf.Extgstate;
using iText.Barcodes;
using iText.Kernel.Pdf.Xobject;
using static Kuika.Common.ReportDesigner.ReportDesignerEvents;
using iText.IO.Font;
using iText.Kernel.Font;
using iText.Layout.Properties;
using Kuika.Common.Helpers;
using Kuika.Common.ReportDesigner;
using Kuika.Common.Extensions;
using Kuika.Common;

namespace Kuika.Reslen_01.Api
{
   public class KasaRaporuDokumForm_reportgenerator
   {
        private KasaRaporuDokumForm_reportgenerator_Controller controller = new KasaRaporuDokumForm_reportgenerator_Controller();

        private string emptyImageBase64 = "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAPoAAAD6CAAAAACthwXhAAAAAmJLR0QA/4ePzL8AAAQTSURBVHja7dzbUuJYFIDhfv9H+cNRwXYcFRWl7AAexgMIdkPTIc8xF6J4iA6t1TXu5F9XFLCr8plkZa+9WX5JCxtfpEuXLl26dOnSpUuXLl26dOnSpUuXLl26dOnSpUuXLl26dOnSpUuXLl26dOnSpUuXLl26dOnSpUuXLl26dOnSpUuXLl26dOnSpUuXLl26dOnSpUuXLl26dOnSpUuXLl26dOnFo49Ou/FvRvd0FD593q/zrqj3krDpkybvjuYkZPqkBlRbR53fjKNWFahNwqXPG1Dqzd81tBtBMwmW3ofS8L2DByXoBUuvf+jgu7AWKn0E1fkHbpcKjAOln0LrI+N34TRQegydj4zvQBwo/RiO/8/x0qVL/3T0m3aj1mhdFo+e7C0qls1pwejJ14dqrTYtFv0QaA2n46MINgtFnzzUKdcRXBaJ3oOt5fytVST6PpwsC55Gkeg7cLF4OYVakegHyyplAM0i0c9gPXkoU9tFos8qsJcsqlxGhXqu94D1+KK/CewVbCLbfpjNbSZFK1/6FQCizrx4ldvs7GBnvz/Nb+U2Pj8dzv/In+6T068aALWT4tHjaJHKWknB6MdApbVXA3bmhaIfAVuzNJ23gb+TAtEPl+Bj4K9fhaG3ge37Ux0Dm7Ni0Od7T5NbDGzMikC/kz9ObX2g+fPxV7/H+/vdH3mjz3eAg6dJ/SSCxnLulhxEANHhPFf0+TbQfv44O49g/d4+e1iMfpr+AqcnW2RuNf9TgrW7K/xnE9g+6W8Bm79yQ++8Ik/TywjqP9I0nTYg6melv7DpdV49/KsS1G7v5KeZKSBsOtB97eNBGarX6xCdZaaA4On91z8flCGC6CIzBYROj978HdCoAkSXmSkgePrOm1+4rULp+ln6u0sBeVuleX7Sq1C+zroNauN800cVKN+8fH9YhspNnunDykL4Im4qUB7mlz4oQ/X2jevhOq/0q2U2y8p/NShd55P++BmWFd9rELXySD9/PHPJttchyiH96Xw1OybrkD/6SQTN6X+Nnqzlj/5yeSo7ptW80bvA11UWZNNOuPTMVoCVl6KDbgXIagBZfQMiTXfhLFD6+GXbz9Hq205Bt/2k9edrNE92YVa4X4Jt9kp7EA0encZ9YHdV+SB6c4nnk9OTJkTd+2v+5S7MW1d7HMFGuI2dd+28ld1OHMdx3AQ2vq3Uv97ZrQTezvuxJu6NoJu40zTprb0PvtYPvHU/TdN0fBYvutJX7l+Pz8Z//rj8Nx3SpUuXLl26dOnSpUuXLl26dOnSpUuXLl26dOnSpUuXLl26dOnSpUuXLl26dOnSpUuXLl26dOnSpUuXLl26dOnSpUuXLl26dOnSpUuXLl26dOnSpUuXLl26dOnSpUuXLl269E8T/wKjvFaYggLelQAAAABJRU5ErkJggg==";
        private float pxToPtFactor = 72f / 96f;
        private float totalHeight = 0;
        private float pageStartY = 0;
        private float? canvasWidth = 794;
        private float? canvasHeight = 2646;
        private float currentPageHeight = 0;
        // Runtime position tracking: each tracked element + its design-time label is collected here,
        // then logged at the end of RenderPDF via the element's iText OccupiedArea (post-layout actual
        // bbox). Useful to compare against the codegen-time POSITION DEBUG REPORT at the bottom of
        // this file: matches confirm SetFixedPosition was honored; mismatches indicate cell flow or
        // margin behavior diverged from intent.
        private List<(string id, IElement elem)> _trackedElements = new List<(string, IElement)>();
        public string RenderPDF(Dictionary<string, string> screenInputs)
        {
            canvasWidth = 794;
            canvasHeight = 2646;
            float headerHeight = 0;
            bool isHeaderFirstPageOnly = false;
            float footerHeight = 0;
            FooterBottomFillEventHandler footerBottomFillHandler = null;
            double topPadding = 0 * pxToPtFactor;
            double bottomPadding = 0 * pxToPtFactor;
            double leftPadding = 0 * pxToPtFactor;
            double rightPadding = 0 * pxToPtFactor;
            var totalPagesFillIns = new List<Action>();
            var currentPageUpdaters = new List<Action<int>>();
            using var stream = new MemoryStream();
            var writer = new PdfWriter(stream);
            var pdf = new PdfDocument(writer);
            canvasWidth ??= PageSize.A4.GetWidth();
            canvasHeight ??= PageSize.A4.GetHeight();
            if (canvasWidth.HasValue) canvasWidth = canvasWidth.Value * pxToPtFactor;
            if (canvasHeight.HasValue) canvasHeight = canvasHeight.Value * pxToPtFactor;
            var document = new Document(pdf, new PageSize(canvasWidth.Value, canvasHeight.Value));

                var localVar = new KasaRaporuDokumFormPageInit_Request{			OperationDate_1 = (("20260818".ConvertToType<String>()).ConvertToType<String>()),
			CompanyCode_1 = (1.ConvertToType<Int32>()),
			OfficeCode_1 = (("M01".ConvertToType<String>()).ConvertToType<String>()),
			Date_2 = (("20260818".ConvertToType<String>()).ConvertToType<String>()),
			CompanyCode_2 = (1.ConvertToType<Int32>()),
			OfficeCode_2 = (("M01".ConvertToType<String>()).ConvertToType<String>()),
			OperationDate_3 = (("20260818".ConvertToType<String>()).ConvertToType<String>()),
			CompanyCode_3 = (1.ConvertToType<Int32>()),
			OfficeCode_3 = (("M01".ConvertToType<String>()).ConvertToType<String>()),
			OperationDate_4 = (("20260818".ConvertToType<String>()).ConvertToType<String>()),
			CompanyCode_4 = (1.ConvertToType<Int32>()),
			OfficeCode_4 = (("M01".ConvertToType<String>()).ConvertToType<String>()),
			OperationDate_5 = (("20260818".ConvertToType<String>()).ConvertToType<String>()),
			CompanyCode_5 = (1.ConvertToType<Int32>()),
			OfficeCode_5 = (("M01".ConvertToType<String>()).ConvertToType<String>()),
			OperationDate_6 = (("20260818".ConvertToType<String>()).ConvertToType<String>()),
			CompanyCode_6 = (1.ConvertToType<Int32>()),
			OfficeCode_6 = (("M01".ConvertToType<String>()).ConvertToType<String>()),
			OperationDate_7 = (("20260818".ConvertToType<String>()).ConvertToType<String>()),
			CompanyCode_7 = (1.ConvertToType<Int32>()),
			OfficeCode_7 = (("M01".ConvertToType<String>()).ConvertToType<String>()),
			OperationDate_8 = (("20260818".ConvertToType<String>()).ConvertToType<String>()),
			CompanyCode_8 = (1.ConvertToType<Int32>()),
			OfficeCode_8 = (("M01".ConvertToType<String>()).ConvertToType<String>())};

                var result = controller.KasaRaporuDokumFormPageInit(localVar);
                string materialFontPath = "Fonts/materialdesignicons.ttf";
                PdfFont materialFont = PdfFontFactory.CreateFont(materialFontPath, PdfEncodings.IDENTITY_H);

                // The CJK fallback face is excluded here on purpose: this dictionary is rebuilt on EVERY
                // RenderPDF call and eagerly parses every font program in it, so pulling an 8 MB CJK font
                // through it would tax reports that contain no Chinese at all. It is loaded at most once
                // per document, and only if some run actually needs it, via the Lazy below.
                var fontDictionary = Directory.GetFiles("Fonts")
                    .Where(x => !string.Equals(new FileInfo(x).Name, ReportFontFallback.FallbackFontFileName, StringComparison.OrdinalIgnoreCase))
                    .ToDictionary(x =>  System.IO.Path.GetFileNameWithoutExtension(new FileInfo(x).Name),
                                                                                y => PdfFontFactory.CreateFont(y, PdfEncodings.IDENTITY_H));

                // A PdfFont binds to the document it is first used in, so this must be per-render and must
                // never become static. Lazy => an all-Latin report never touches the file.
                var cjkFallbackFont = new Lazy<PdfFont>(() => ReportFontFallback.CreateFallbackFont());

            
            
            var pageBackgroundHandler = new PageBackgroundEventHandler(new DeviceRgb(255f/255f, 255f/255f, 255f/255f));
            pdf.AddEventHandler(PdfDocumentEvent.END_PAGE, pageBackgroundHandler);
        
            
            
            
            float pageHeaderHeight = 0;
            float pageFooterHeight = 0;

            
            

            document.SetMargins(pageHeaderHeight, 0, pageFooterHeight, 0);


            // Ensure first page exists before any PdfCanvas drawing
            if (pdf.GetNumberOfPages() == 0)
            {
                pdf.AddNewPage(new PageSize(canvasWidth.Value, canvasHeight.Value));
            }

            // No page breaks - using default canvas height behavior


            //Box1
            Table box_kasaraporudokumform_1299815389 = new Table(1).SetWidth(780f * pxToPtFactor).SetHeight(110f * pxToPtFactor)
            .SetFontColor(new DeviceRgb(0, 0, 0), 1f)
            .SetFontSize(20 * pxToPtFactor)
            .SetVisible(true);
            if (box_kasaraporudokumform_1299815389.IsVisible()) {{
            var box_kasaraporudokumform_1299815389_pageLeftX = (double)(10f * pxToPtFactor) ;
            var box_kasaraporudokumform_1299815389_pageTopY = 0d;
            var box_kasaraporudokumform_1299815389_deferredAdds = new List<IBlockElement>();
            if (!false) {
            // Calculate page-relative Y position
            var box_kasaraporudokumform_1299815389_absoluteY = Math.Abs(20f * pxToPtFactor);
            var box_kasaraporudokumform_1299815389_pageRelativeY = box_kasaraporudokumform_1299815389_absoluteY - pageStartY;
            int box_kasaraporudokumform_1299815389_targetPage = pdf.GetNumberOfPages();
            
            box_kasaraporudokumform_1299815389.SetFixedPosition(box_kasaraporudokumform_1299815389_targetPage, 10f * pxToPtFactor , ((currentPageHeight > 0 ? currentPageHeight : canvasHeight.Value) - (box_kasaraporudokumform_1299815389_pageRelativeY + Math.Abs(110f * pxToPtFactor))) , 780f * pxToPtFactor);
            box_kasaraporudokumform_1299815389_pageTopY = ((double)(currentPageHeight > 0 ? currentPageHeight : canvasHeight.Value) - box_kasaraporudokumform_1299815389_pageRelativeY) ;
            } else {
            box_kasaraporudokumform_1299815389.SetFixedPosition(10f * pxToPtFactor , ((currentPageHeight > 0 ? currentPageHeight : canvasHeight.Value) - (totalHeight + Math.Abs(20f * pxToPtFactor) + Math.Abs(110f * pxToPtFactor))) , 780f * pxToPtFactor);
            box_kasaraporudokumform_1299815389_pageTopY = ((double)(currentPageHeight > 0 ? currentPageHeight : canvasHeight.Value) - (totalHeight + Math.Abs(20f * pxToPtFactor))) ;
            }
            box_kasaraporudokumform_1299815389.SetBorder(Border.NO_BORDER);
            box_kasaraporudokumform_1299815389.SetBorderBottom(Border.NO_BORDER);
            box_kasaraporudokumform_1299815389.SetBorderTop(Border.NO_BORDER);
            box_kasaraporudokumform_1299815389.SetBorderRight(Border.NO_BORDER);
            box_kasaraporudokumform_1299815389.SetBorderLeft(Border.NO_BORDER);
            box_kasaraporudokumform_1299815389.SetBorderRadius(new BorderRadius(0f * pxToPtFactor));
            var heightOf_box_kasaraporudokumform_1299815389 = box_kasaraporudokumform_1299815389.GetHeight();
            Cell kasaraporudokumform_1299815389_cell = new Cell();
            kasaraporudokumform_1299815389_cell.SetBackgroundColor(new DeviceRgb(255, 255, 255), 1f);
            kasaraporudokumform_1299815389_cell.SetBorder(Border.NO_BORDER);
            
            // NOTE: Box always uses SetFixedPosition above (both branches), so it does not
            // contribute to flow. The legacy "totalHeight + height > canvasHeight" areaBreak
            // that lived here was reading totalHeight produced by previous flow elements
            // (e.g. multi-page ReportTables) and spuriously creating a new page + bumping
            // pageStartY, which broke pageRelativeY for every subsequent element. Removed.

            // No page breaks - using default canvas height behavior


            //Label1
            var label_kasaraporudokumform_1356889249_effectiveWidth = 110f * pxToPtFactor > 0 ? 110f * pxToPtFactor : (canvasWidth.Value - (20f * pxToPtFactor));
            Paragraph label_kasaraporudokumform_1356889249 = new Paragraph(@"İşlem Tarihi         :")
            .SetFontSize(12 * pxToPtFactor)
            .SetFont(fontDictionary["poppins_regular"])
            .WithGlyphFallback(fontDictionary, "poppins_regular", () => cjkFallbackFont.Value)
            .SetTextAlignment(TextAlignment.LEFT)
            
            .SetParagraphWidthAndExtendHeightIfNotFit(document, label_kasaraporudokumform_1356889249_effectiveWidth, 20f * pxToPtFactor, false, false || false)
            .SetMultipliedLeading(0.875f);
            

            if (20f * pxToPtFactor == 0f)
            {
                label_kasaraporudokumform_1356889249.SetMaxHeight((110f * pxToPtFactor) - Math.Abs(30f * pxToPtFactor));
            }

            label_kasaraporudokumform_1356889249.SetMarginBottom(0 * pxToPtFactor).SetMarginTop(0f);
            var label_kasaraporudokumform_1356889249_paragraphHeight = label_kasaraporudokumform_1356889249.GetHeightOfParagraph(document);
            var label_kasaraporudokumform_1356889249_vAlignOffset = 0f;
            label_kasaraporudokumform_1356889249_vAlignOffset = Math.Max(0f, (20f * pxToPtFactor - label_kasaraporudokumform_1356889249_paragraphHeight) / 2f);
            label_kasaraporudokumform_1356889249.SetMarginLeft(0 * pxToPtFactor)
            .SetMarginTop((0 * pxToPtFactor) + label_kasaraporudokumform_1356889249_vAlignOffset).SetMarginRight(0 * pxToPtFactor)
            .SetFontColor(new DeviceRgb(68, 68, 68), 1f)
            .SetVisible(true);
            
            if (false)
			{
				Paragraph label_kasaraporudokumform_1356889249_inside = new Paragraph(@"İşlem Tarihi         :")
			   .SetFontSize(12 * pxToPtFactor)
               .SetFont(fontDictionary["poppins_regular"])
			   .WithGlyphFallback(fontDictionary, "poppins_regular", () => cjkFallbackFont.Value)
			   .SetFontColor(new DeviceRgb(68, 68, 68), 1f)
			   
			   .SetRotationAngle(0);
				label_kasaraporudokumform_1356889249.Add(label_kasaraporudokumform_1356889249_inside);
			}
            var label_kasaraporudokumform_1356889249_renderHeight = 20f * pxToPtFactor > 0 ? 20f * pxToPtFactor : label_kasaraporudokumform_1356889249_paragraphHeight;
            // Actual div height accounts for paragraph margins that may expand the Div beyond MinHeight
            // paragraphHeight was measured with MarginTop=0, but actual MarginTop = paddingTop + vAlignOffset
            var label_kasaraporudokumform_1356889249_divHeight = Math.Max(label_kasaraporudokumform_1356889249_renderHeight, label_kasaraporudokumform_1356889249_paragraphHeight + (0 * pxToPtFactor) + label_kasaraporudokumform_1356889249_vAlignOffset);
            var div_label_kasaraporudokumform_1356889249 = new Div();
            div_label_kasaraporudokumform_1356889249.SetMinHeight(label_kasaraporudokumform_1356889249_renderHeight);
            div_label_kasaraporudokumform_1356889249.SetBackgroundColor(new DeviceRgb(0, 0, 0), 0f);
            div_label_kasaraporudokumform_1356889249.SetBorderBottom(new SolidBorder(new DeviceRgb(217, 217, 217), 1 * pxToPtFactor, 1f));
            div_label_kasaraporudokumform_1356889249.SetBorderTop(new SolidBorder(new DeviceRgb(217, 217, 217), 1 * pxToPtFactor, 1f));
            div_label_kasaraporudokumform_1356889249.SetBorderRight(new SolidBorder(new DeviceRgb(217, 217, 217), 1 * pxToPtFactor, 1f));
            div_label_kasaraporudokumform_1356889249.SetBorderLeft(new SolidBorder(new DeviceRgb(217, 217, 217), 1 * pxToPtFactor, 1f));
            div_label_kasaraporudokumform_1356889249.SetBorderRadius(new BorderRadius(0f * pxToPtFactor));
            div_label_kasaraporudokumform_1356889249.Add(label_kasaraporudokumform_1356889249);
            
            // Label/Icon inside Box: use box page coordinates for absolute positioning
            var label_kasaraporudokumform_1356889249_yPos = box_kasaraporudokumform_1299815389_pageTopY - (10f * pxToPtFactor) - label_kasaraporudokumform_1356889249_divHeight;
            div_label_kasaraporudokumform_1356889249.SetFixedPosition((float)(box_kasaraporudokumform_1299815389_pageLeftX + (10f * pxToPtFactor)), (float)label_kasaraporudokumform_1356889249_yPos, label_kasaraporudokumform_1356889249_effectiveWidth);
            div_label_kasaraporudokumform_1356889249.SetVisible(true);
            box_kasaraporudokumform_1299815389_deferredAdds.Add(div_label_kasaraporudokumform_1356889249);


            //Label5
            var label_kasaraporudokumform_867425154_effectiveWidth = 630f * pxToPtFactor > 0 ? 630f * pxToPtFactor : (canvasWidth.Value - (130f * pxToPtFactor));
            Paragraph label_kasaraporudokumform_867425154 = new Paragraph(@"")
            .SetFontSize(12 * pxToPtFactor)
            .SetFont(fontDictionary["poppins_regular"])
            .WithGlyphFallback(fontDictionary, "poppins_regular", () => cjkFallbackFont.Value)
            .SetTextAlignment(TextAlignment.LEFT)
            
            .SetParagraphWidthAndExtendHeightIfNotFit(document, label_kasaraporudokumform_867425154_effectiveWidth, 20f * pxToPtFactor, false, false || false)
            .SetMultipliedLeading(0.875f);
            

            if (20f * pxToPtFactor == 0f)
            {
                label_kasaraporudokumform_867425154.SetMaxHeight((110f * pxToPtFactor) - Math.Abs(30f * pxToPtFactor));
            }

            label_kasaraporudokumform_867425154.SetMarginBottom(0 * pxToPtFactor).SetMarginTop(0f);
            var label_kasaraporudokumform_867425154_paragraphHeight = label_kasaraporudokumform_867425154.GetHeightOfParagraph(document);
            var label_kasaraporudokumform_867425154_vAlignOffset = 0f;
            label_kasaraporudokumform_867425154_vAlignOffset = Math.Max(0f, (20f * pxToPtFactor - label_kasaraporudokumform_867425154_paragraphHeight) / 2f);
            label_kasaraporudokumform_867425154.SetMarginLeft(0 * pxToPtFactor)
            .SetMarginTop((0 * pxToPtFactor) + label_kasaraporudokumform_867425154_vAlignOffset).SetMarginRight(0 * pxToPtFactor)
            .SetFontColor(new DeviceRgb(68, 68, 68), 1f)
            .SetVisible(true);
            
            if (false)
			{
				Paragraph label_kasaraporudokumform_867425154_inside = new Paragraph(@"")
			   .SetFontSize(12 * pxToPtFactor)
               .SetFont(fontDictionary["poppins_regular"])
			   .WithGlyphFallback(fontDictionary, "poppins_regular", () => cjkFallbackFont.Value)
			   .SetFontColor(new DeviceRgb(68, 68, 68), 1f)
			   
			   .SetRotationAngle(0);
				label_kasaraporudokumform_867425154.Add(label_kasaraporudokumform_867425154_inside);
			}
            var label_kasaraporudokumform_867425154_renderHeight = 20f * pxToPtFactor > 0 ? 20f * pxToPtFactor : label_kasaraporudokumform_867425154_paragraphHeight;
            // Actual div height accounts for paragraph margins that may expand the Div beyond MinHeight
            // paragraphHeight was measured with MarginTop=0, but actual MarginTop = paddingTop + vAlignOffset
            var label_kasaraporudokumform_867425154_divHeight = Math.Max(label_kasaraporudokumform_867425154_renderHeight, label_kasaraporudokumform_867425154_paragraphHeight + (0 * pxToPtFactor) + label_kasaraporudokumform_867425154_vAlignOffset);
            var div_label_kasaraporudokumform_867425154 = new Div();
            div_label_kasaraporudokumform_867425154.SetMinHeight(label_kasaraporudokumform_867425154_renderHeight);
            div_label_kasaraporudokumform_867425154.SetBackgroundColor(new DeviceRgb(0, 0, 0), 0f);
            div_label_kasaraporudokumform_867425154.SetBorderBottom(new SolidBorder(new DeviceRgb(217, 217, 217), 1 * pxToPtFactor, 1f));
            div_label_kasaraporudokumform_867425154.SetBorderTop(new SolidBorder(new DeviceRgb(217, 217, 217), 1 * pxToPtFactor, 1f));
            div_label_kasaraporudokumform_867425154.SetBorderRight(new SolidBorder(new DeviceRgb(217, 217, 217), 1 * pxToPtFactor, 1f));
            div_label_kasaraporudokumform_867425154.SetBorderLeft(new SolidBorder(new DeviceRgb(217, 217, 217), 1 * pxToPtFactor, 1f));
            div_label_kasaraporudokumform_867425154.SetBorderRadius(new BorderRadius(0f * pxToPtFactor));
            div_label_kasaraporudokumform_867425154.Add(label_kasaraporudokumform_867425154);
            
            // Label/Icon inside Box: use box page coordinates for absolute positioning
            var label_kasaraporudokumform_867425154_yPos = box_kasaraporudokumform_1299815389_pageTopY - (10f * pxToPtFactor) - label_kasaraporudokumform_867425154_divHeight;
            div_label_kasaraporudokumform_867425154.SetFixedPosition((float)(box_kasaraporudokumform_1299815389_pageLeftX + (120f * pxToPtFactor)), (float)label_kasaraporudokumform_867425154_yPos, label_kasaraporudokumform_867425154_effectiveWidth);
            div_label_kasaraporudokumform_867425154.SetVisible(true);
            box_kasaraporudokumform_1299815389_deferredAdds.Add(div_label_kasaraporudokumform_867425154);


            //Label2
            var label_kasaraporudokumform_1748108357_effectiveWidth = 110f * pxToPtFactor > 0 ? 110f * pxToPtFactor : (canvasWidth.Value - (20f * pxToPtFactor));
            Paragraph label_kasaraporudokumform_1748108357 = new Paragraph(@"Kasa Tarihi           :")
            .SetFontSize(12 * pxToPtFactor)
            .SetFont(fontDictionary["poppins_regular"])
            .WithGlyphFallback(fontDictionary, "poppins_regular", () => cjkFallbackFont.Value)
            .SetTextAlignment(TextAlignment.LEFT)
            
            .SetParagraphWidthAndExtendHeightIfNotFit(document, label_kasaraporudokumform_1748108357_effectiveWidth, 20f * pxToPtFactor, false, false || false)
            .SetMultipliedLeading(0.875f);
            

            if (20f * pxToPtFactor == 0f)
            {
                label_kasaraporudokumform_1748108357.SetMaxHeight((110f * pxToPtFactor) - Math.Abs(50f * pxToPtFactor));
            }

            label_kasaraporudokumform_1748108357.SetMarginBottom(0 * pxToPtFactor).SetMarginTop(0f);
            var label_kasaraporudokumform_1748108357_paragraphHeight = label_kasaraporudokumform_1748108357.GetHeightOfParagraph(document);
            var label_kasaraporudokumform_1748108357_vAlignOffset = 0f;
            label_kasaraporudokumform_1748108357_vAlignOffset = Math.Max(0f, (20f * pxToPtFactor - label_kasaraporudokumform_1748108357_paragraphHeight) / 2f);
            label_kasaraporudokumform_1748108357.SetMarginLeft(0 * pxToPtFactor)
            .SetMarginTop((0 * pxToPtFactor) + label_kasaraporudokumform_1748108357_vAlignOffset).SetMarginRight(0 * pxToPtFactor)
            .SetFontColor(new DeviceRgb(68, 68, 68), 1f)
            .SetVisible(true);
            
            if (false)
			{
				Paragraph label_kasaraporudokumform_1748108357_inside = new Paragraph(@"Kasa Tarihi           :")
			   .SetFontSize(12 * pxToPtFactor)
               .SetFont(fontDictionary["poppins_regular"])
			   .WithGlyphFallback(fontDictionary, "poppins_regular", () => cjkFallbackFont.Value)
			   .SetFontColor(new DeviceRgb(68, 68, 68), 1f)
			   
			   .SetRotationAngle(0);
				label_kasaraporudokumform_1748108357.Add(label_kasaraporudokumform_1748108357_inside);
			}
            var label_kasaraporudokumform_1748108357_renderHeight = 20f * pxToPtFactor > 0 ? 20f * pxToPtFactor : label_kasaraporudokumform_1748108357_paragraphHeight;
            // Actual div height accounts for paragraph margins that may expand the Div beyond MinHeight
            // paragraphHeight was measured with MarginTop=0, but actual MarginTop = paddingTop + vAlignOffset
            var label_kasaraporudokumform_1748108357_divHeight = Math.Max(label_kasaraporudokumform_1748108357_renderHeight, label_kasaraporudokumform_1748108357_paragraphHeight + (0 * pxToPtFactor) + label_kasaraporudokumform_1748108357_vAlignOffset);
            var div_label_kasaraporudokumform_1748108357 = new Div();
            div_label_kasaraporudokumform_1748108357.SetMinHeight(label_kasaraporudokumform_1748108357_renderHeight);
            div_label_kasaraporudokumform_1748108357.SetBackgroundColor(new DeviceRgb(0, 0, 0), 0f);
            div_label_kasaraporudokumform_1748108357.SetBorderBottom(new SolidBorder(new DeviceRgb(217, 217, 217), 1 * pxToPtFactor, 1f));
            div_label_kasaraporudokumform_1748108357.SetBorderTop(new SolidBorder(new DeviceRgb(217, 217, 217), 1 * pxToPtFactor, 1f));
            div_label_kasaraporudokumform_1748108357.SetBorderRight(new SolidBorder(new DeviceRgb(217, 217, 217), 1 * pxToPtFactor, 1f));
            div_label_kasaraporudokumform_1748108357.SetBorderLeft(new SolidBorder(new DeviceRgb(217, 217, 217), 1 * pxToPtFactor, 1f));
            div_label_kasaraporudokumform_1748108357.SetBorderRadius(new BorderRadius(0f * pxToPtFactor));
            div_label_kasaraporudokumform_1748108357.Add(label_kasaraporudokumform_1748108357);
            
            // Label/Icon inside Box: use box page coordinates for absolute positioning
            var label_kasaraporudokumform_1748108357_yPos = box_kasaraporudokumform_1299815389_pageTopY - (30f * pxToPtFactor) - label_kasaraporudokumform_1748108357_divHeight;
            div_label_kasaraporudokumform_1748108357.SetFixedPosition((float)(box_kasaraporudokumform_1299815389_pageLeftX + (10f * pxToPtFactor)), (float)label_kasaraporudokumform_1748108357_yPos, label_kasaraporudokumform_1748108357_effectiveWidth);
            div_label_kasaraporudokumform_1748108357.SetVisible(true);
            box_kasaraporudokumform_1299815389_deferredAdds.Add(div_label_kasaraporudokumform_1748108357);


            //Label3
            var label_kasaraporudokumform_988980285_effectiveWidth = 110f * pxToPtFactor > 0 ? 110f * pxToPtFactor : (canvasWidth.Value - (20f * pxToPtFactor));
            Paragraph label_kasaraporudokumform_988980285 = new Paragraph(@"Şirket Adı :")
            .SetFontSize(12 * pxToPtFactor)
            .SetFont(fontDictionary["poppins_regular"])
            .WithGlyphFallback(fontDictionary, "poppins_regular", () => cjkFallbackFont.Value)
            .SetTextAlignment(TextAlignment.LEFT)
            
            .SetParagraphWidthAndExtendHeightIfNotFit(document, label_kasaraporudokumform_988980285_effectiveWidth, 20f * pxToPtFactor, false, false || false)
            .SetMultipliedLeading(0.875f);
            

            if (20f * pxToPtFactor == 0f)
            {
                label_kasaraporudokumform_988980285.SetMaxHeight((110f * pxToPtFactor) - Math.Abs(70f * pxToPtFactor));
            }

            label_kasaraporudokumform_988980285.SetMarginBottom(0 * pxToPtFactor).SetMarginTop(0f);
            var label_kasaraporudokumform_988980285_paragraphHeight = label_kasaraporudokumform_988980285.GetHeightOfParagraph(document);
            var label_kasaraporudokumform_988980285_vAlignOffset = 0f;
            label_kasaraporudokumform_988980285_vAlignOffset = Math.Max(0f, (20f * pxToPtFactor - label_kasaraporudokumform_988980285_paragraphHeight) / 2f);
            label_kasaraporudokumform_988980285.SetMarginLeft(0 * pxToPtFactor)
            .SetMarginTop((0 * pxToPtFactor) + label_kasaraporudokumform_988980285_vAlignOffset).SetMarginRight(0 * pxToPtFactor)
            .SetFontColor(new DeviceRgb(68, 68, 68), 1f)
            .SetVisible(true);
            
            if (false)
			{
				Paragraph label_kasaraporudokumform_988980285_inside = new Paragraph(@"Şirket Adı :")
			   .SetFontSize(12 * pxToPtFactor)
               .SetFont(fontDictionary["poppins_regular"])
			   .WithGlyphFallback(fontDictionary, "poppins_regular", () => cjkFallbackFont.Value)
			   .SetFontColor(new DeviceRgb(68, 68, 68), 1f)
			   
			   .SetRotationAngle(0);
				label_kasaraporudokumform_988980285.Add(label_kasaraporudokumform_988980285_inside);
			}
            var label_kasaraporudokumform_988980285_renderHeight = 20f * pxToPtFactor > 0 ? 20f * pxToPtFactor : label_kasaraporudokumform_988980285_paragraphHeight;
            // Actual div height accounts for paragraph margins that may expand the Div beyond MinHeight
            // paragraphHeight was measured with MarginTop=0, but actual MarginTop = paddingTop + vAlignOffset
            var label_kasaraporudokumform_988980285_divHeight = Math.Max(label_kasaraporudokumform_988980285_renderHeight, label_kasaraporudokumform_988980285_paragraphHeight + (0 * pxToPtFactor) + label_kasaraporudokumform_988980285_vAlignOffset);
            var div_label_kasaraporudokumform_988980285 = new Div();
            div_label_kasaraporudokumform_988980285.SetMinHeight(label_kasaraporudokumform_988980285_renderHeight);
            div_label_kasaraporudokumform_988980285.SetBackgroundColor(new DeviceRgb(0, 0, 0), 0f);
            div_label_kasaraporudokumform_988980285.SetBorderBottom(new SolidBorder(new DeviceRgb(217, 217, 217), 1 * pxToPtFactor, 1f));
            div_label_kasaraporudokumform_988980285.SetBorderTop(new SolidBorder(new DeviceRgb(217, 217, 217), 1 * pxToPtFactor, 1f));
            div_label_kasaraporudokumform_988980285.SetBorderRight(new SolidBorder(new DeviceRgb(217, 217, 217), 1 * pxToPtFactor, 1f));
            div_label_kasaraporudokumform_988980285.SetBorderLeft(new SolidBorder(new DeviceRgb(217, 217, 217), 1 * pxToPtFactor, 1f));
            div_label_kasaraporudokumform_988980285.SetBorderRadius(new BorderRadius(0f * pxToPtFactor));
            div_label_kasaraporudokumform_988980285.Add(label_kasaraporudokumform_988980285);
            
            // Label/Icon inside Box: use box page coordinates for absolute positioning
            var label_kasaraporudokumform_988980285_yPos = box_kasaraporudokumform_1299815389_pageTopY - (50f * pxToPtFactor) - label_kasaraporudokumform_988980285_divHeight;
            div_label_kasaraporudokumform_988980285.SetFixedPosition((float)(box_kasaraporudokumform_1299815389_pageLeftX + (10f * pxToPtFactor)), (float)label_kasaraporudokumform_988980285_yPos, label_kasaraporudokumform_988980285_effectiveWidth);
            div_label_kasaraporudokumform_988980285.SetVisible(true);
            box_kasaraporudokumform_1299815389_deferredAdds.Add(div_label_kasaraporudokumform_988980285);


            //Label4
            var label_kasaraporudokumform_783326511_effectiveWidth = 110f * pxToPtFactor > 0 ? 110f * pxToPtFactor : (canvasWidth.Value - (20f * pxToPtFactor));
            Paragraph label_kasaraporudokumform_783326511 = new Paragraph(@"Şube Kodu :")
            .SetFontSize(12 * pxToPtFactor)
            .SetFont(fontDictionary["poppins_regular"])
            .WithGlyphFallback(fontDictionary, "poppins_regular", () => cjkFallbackFont.Value)
            .SetTextAlignment(TextAlignment.LEFT)
            
            .SetParagraphWidthAndExtendHeightIfNotFit(document, label_kasaraporudokumform_783326511_effectiveWidth, 20f * pxToPtFactor, false, false || false)
            .SetMultipliedLeading(0.875f);
            

            if (20f * pxToPtFactor == 0f)
            {
                label_kasaraporudokumform_783326511.SetMaxHeight((110f * pxToPtFactor) - Math.Abs(90f * pxToPtFactor));
            }

            label_kasaraporudokumform_783326511.SetMarginBottom(0 * pxToPtFactor).SetMarginTop(0f);
            var label_kasaraporudokumform_783326511_paragraphHeight = label_kasaraporudokumform_783326511.GetHeightOfParagraph(document);
            var label_kasaraporudokumform_783326511_vAlignOffset = 0f;
            label_kasaraporudokumform_783326511_vAlignOffset = Math.Max(0f, (20f * pxToPtFactor - label_kasaraporudokumform_783326511_paragraphHeight) / 2f);
            label_kasaraporudokumform_783326511.SetMarginLeft(0 * pxToPtFactor)
            .SetMarginTop((0 * pxToPtFactor) + label_kasaraporudokumform_783326511_vAlignOffset).SetMarginRight(0 * pxToPtFactor)
            .SetFontColor(new DeviceRgb(68, 68, 68), 1f)
            .SetVisible(true);
            
            if (false)
			{
				Paragraph label_kasaraporudokumform_783326511_inside = new Paragraph(@"Şube Kodu :")
			   .SetFontSize(12 * pxToPtFactor)
               .SetFont(fontDictionary["poppins_regular"])
			   .WithGlyphFallback(fontDictionary, "poppins_regular", () => cjkFallbackFont.Value)
			   .SetFontColor(new DeviceRgb(68, 68, 68), 1f)
			   
			   .SetRotationAngle(0);
				label_kasaraporudokumform_783326511.Add(label_kasaraporudokumform_783326511_inside);
			}
            var label_kasaraporudokumform_783326511_renderHeight = 20f * pxToPtFactor > 0 ? 20f * pxToPtFactor : label_kasaraporudokumform_783326511_paragraphHeight;
            // Actual div height accounts for paragraph margins that may expand the Div beyond MinHeight
            // paragraphHeight was measured with MarginTop=0, but actual MarginTop = paddingTop + vAlignOffset
            var label_kasaraporudokumform_783326511_divHeight = Math.Max(label_kasaraporudokumform_783326511_renderHeight, label_kasaraporudokumform_783326511_paragraphHeight + (0 * pxToPtFactor) + label_kasaraporudokumform_783326511_vAlignOffset);
            var div_label_kasaraporudokumform_783326511 = new Div();
            div_label_kasaraporudokumform_783326511.SetMinHeight(label_kasaraporudokumform_783326511_renderHeight);
            div_label_kasaraporudokumform_783326511.SetBackgroundColor(new DeviceRgb(0, 0, 0), 0f);
            div_label_kasaraporudokumform_783326511.SetBorderBottom(new SolidBorder(new DeviceRgb(217, 217, 217), 1 * pxToPtFactor, 1f));
            div_label_kasaraporudokumform_783326511.SetBorderTop(new SolidBorder(new DeviceRgb(217, 217, 217), 1 * pxToPtFactor, 1f));
            div_label_kasaraporudokumform_783326511.SetBorderRight(new SolidBorder(new DeviceRgb(217, 217, 217), 1 * pxToPtFactor, 1f));
            div_label_kasaraporudokumform_783326511.SetBorderLeft(new SolidBorder(new DeviceRgb(217, 217, 217), 1 * pxToPtFactor, 1f));
            div_label_kasaraporudokumform_783326511.SetBorderRadius(new BorderRadius(0f * pxToPtFactor));
            div_label_kasaraporudokumform_783326511.Add(label_kasaraporudokumform_783326511);
            
            // Label/Icon inside Box: use box page coordinates for absolute positioning
            var label_kasaraporudokumform_783326511_yPos = box_kasaraporudokumform_1299815389_pageTopY - (70f * pxToPtFactor) - label_kasaraporudokumform_783326511_divHeight;
            div_label_kasaraporudokumform_783326511.SetFixedPosition((float)(box_kasaraporudokumform_1299815389_pageLeftX + (10f * pxToPtFactor)), (float)label_kasaraporudokumform_783326511_yPos, label_kasaraporudokumform_783326511_effectiveWidth);
            div_label_kasaraporudokumform_783326511.SetVisible(true);
            box_kasaraporudokumform_1299815389_deferredAdds.Add(div_label_kasaraporudokumform_783326511);

            kasaraporudokumform_1299815389_cell.SetVisible(box_kasaraporudokumform_1299815389.IsVisible());
            box_kasaraporudokumform_1299815389.AddCell(kasaraporudokumform_1299815389_cell);
            
            document.Add(box_kasaraporudokumform_1299815389);
            foreach (var deferredElem in box_kasaraporudokumform_1299815389_deferredAdds) document.Add(deferredElem);
            }}


            //Box3
            Table box_kasaraporudokumform_1453904397 = new Table(1).SetWidth(780f * pxToPtFactor).SetHeight(270f * pxToPtFactor)
            .SetFontColor(new DeviceRgb(0, 0, 0), 1f)
            .SetFontSize(20 * pxToPtFactor)
            .SetVisible(true);
            if (box_kasaraporudokumform_1453904397.IsVisible()) {{
            var box_kasaraporudokumform_1453904397_pageLeftX = (double)(10f * pxToPtFactor) ;
            var box_kasaraporudokumform_1453904397_pageTopY = 0d;
            var box_kasaraporudokumform_1453904397_deferredAdds = new List<IBlockElement>();
            if (!false) {
            // Calculate page-relative Y position
            var box_kasaraporudokumform_1453904397_absoluteY = Math.Abs(170f * pxToPtFactor);
            var box_kasaraporudokumform_1453904397_pageRelativeY = box_kasaraporudokumform_1453904397_absoluteY - pageStartY;
            int box_kasaraporudokumform_1453904397_targetPage = pdf.GetNumberOfPages();
            
            box_kasaraporudokumform_1453904397.SetFixedPosition(box_kasaraporudokumform_1453904397_targetPage, 10f * pxToPtFactor , ((currentPageHeight > 0 ? currentPageHeight : canvasHeight.Value) - (box_kasaraporudokumform_1453904397_pageRelativeY + Math.Abs(270f * pxToPtFactor))) , 780f * pxToPtFactor);
            box_kasaraporudokumform_1453904397_pageTopY = ((double)(currentPageHeight > 0 ? currentPageHeight : canvasHeight.Value) - box_kasaraporudokumform_1453904397_pageRelativeY) ;
            } else {
            box_kasaraporudokumform_1453904397.SetFixedPosition(10f * pxToPtFactor , ((currentPageHeight > 0 ? currentPageHeight : canvasHeight.Value) - (totalHeight + Math.Abs(170f * pxToPtFactor) + Math.Abs(270f * pxToPtFactor))) , 780f * pxToPtFactor);
            box_kasaraporudokumform_1453904397_pageTopY = ((double)(currentPageHeight > 0 ? currentPageHeight : canvasHeight.Value) - (totalHeight + Math.Abs(170f * pxToPtFactor))) ;
            }
            box_kasaraporudokumform_1453904397.SetBorder(Border.NO_BORDER);
            box_kasaraporudokumform_1453904397.SetBorderBottom(Border.NO_BORDER);
            box_kasaraporudokumform_1453904397.SetBorderTop(Border.NO_BORDER);
            box_kasaraporudokumform_1453904397.SetBorderRight(Border.NO_BORDER);
            box_kasaraporudokumform_1453904397.SetBorderLeft(Border.NO_BORDER);
            box_kasaraporudokumform_1453904397.SetBorderRadius(new BorderRadius(6f * pxToPtFactor));
            var heightOf_box_kasaraporudokumform_1453904397 = box_kasaraporudokumform_1453904397.GetHeight();
            Cell kasaraporudokumform_1453904397_cell = new Cell();
            kasaraporudokumform_1453904397_cell.SetBackgroundColor(new DeviceRgb(255, 255, 255), 0f);
            kasaraporudokumform_1453904397_cell.SetBorder(Border.NO_BORDER);
            
            // NOTE: Box always uses SetFixedPosition above (both branches), so it does not
            // contribute to flow. The legacy "totalHeight + height > canvasHeight" areaBreak
            // that lived here was reading totalHeight produced by previous flow elements
            // (e.g. multi-page ReportTables) and spuriously creating a new page + bumping
            // pageStartY, which broke pageRelativeY for every subsequent element. Removed.

            // No page breaks - using default canvas height behavior


            //ReportTable1
            
            var kasaraporudokumform_1665150132IsVisible = true;
            var kasaraporudokumform_1665150132BackgroundColor = new DeviceRgb(0, 0, 0);
            var kasaraporudokumform_1665150132BackgroundColorOpacity = 0f;
            var widths_kasaraporudokumform_1665150132 = new List<float>();
widths_kasaraporudokumform_1665150132.Add(90.71f * pxToPtFactor);
widths_kasaraporudokumform_1665150132.Add(143.62f * pxToPtFactor);
widths_kasaraporudokumform_1665150132.Add(75.59f * pxToPtFactor);
widths_kasaraporudokumform_1665150132.Add(102.05f * pxToPtFactor);
widths_kasaraporudokumform_1665150132.Add(37.8f * pxToPtFactor);
widths_kasaraporudokumform_1665150132.Add(68.03f * pxToPtFactor);
widths_kasaraporudokumform_1665150132.Add(34.02f * pxToPtFactor);
widths_kasaraporudokumform_1665150132.Add(75.59f * pxToPtFactor);
widths_kasaraporudokumform_1665150132.Add(86.93f * pxToPtFactor);
var designWidth_kasaraporudokumform_1665150132 = 714.33f * pxToPtFactor;
var tableWidth_kasaraporudokumform_1665150132 = (widths_kasaraporudokumform_1665150132.Sum() / designWidth_kasaraporudokumform_1665150132) * (714.33f * pxToPtFactor);

            Table kasaraporudokumform_1665150132 = new Table(widths_kasaraporudokumform_1665150132.ToArray()).SetWidth(tableWidth_kasaraporudokumform_1665150132)
            .SetBackgroundColor(kasaraporudokumform_1665150132BackgroundColor, kasaraporudokumform_1665150132BackgroundColorOpacity)
            .SetVisible(kasaraporudokumform_1665150132IsVisible)
            .SetMarginBottom(0 * pxToPtFactor)
            .SetMarginLeft(0 * pxToPtFactor)
            .SetMarginTop(0 * pxToPtFactor)
            .SetMarginRight(0 * pxToPtFactor);
            
            kasaraporudokumform_1665150132.SetBorderBottom(new SolidBorder(new DeviceRgb(218, 218, 218), 1 * pxToPtFactor, 1f));
            kasaraporudokumform_1665150132.SetBorderTop(new SolidBorder(new DeviceRgb(218, 218, 218), 1 * pxToPtFactor, 1f));
            kasaraporudokumform_1665150132.SetBorderRight(new SolidBorder(new DeviceRgb(218, 218, 218), 1 * pxToPtFactor, 1f));
            kasaraporudokumform_1665150132.SetBorderLeft(new SolidBorder(new DeviceRgb(218, 218, 218), 1 * pxToPtFactor, 1f));
            kasaraporudokumform_1665150132.SetBorderRadius(new BorderRadius(0f * pxToPtFactor));
            kasaraporudokumform_1665150132.SetFixedLayout();
            Color kasaraporudokumform_1665150132borderColor = new DeviceRgb(240, 240, 240);
            Border kasaraporudokumform_1665150132leftBorder = new SolidBorder(kasaraporudokumform_1665150132borderColor, 1 * pxToPtFactor);
            if (kasaraporudokumform_1665150132IsVisible)
            {
                
            List<String> columnValueNames_kasaraporudokumform_1665150132 = new List<String>() {"CurrAccDescription", "ItemDescription", "DeliveryDate", "SalesPersonName", "Doc_TaxBase", "Doc_NetAmount", "Doc_Vat", "Doc_NetAmount", "Loc_NetAmount"};
            
            var kasaraporudokumform_1665150132_ColumTitlesPropValue = "";
            var kasaraporudokumform_1665150132_ColumnTitles = new List<string>();
            if(kasaraporudokumform_1665150132_ColumTitlesPropValue != null) {
               kasaraporudokumform_1665150132_ColumnTitles = kasaraporudokumform_1665150132_ColumTitlesPropValue.ToString()?.Split(";", StringSplitOptions.RemoveEmptyEntries).ToList();
            }
        
            
            Cell cell_0 = new Cell(1, 1);
            //cell_0.SetBorder(iText.Layout.Borders.Border.NO_BORDER)
            cell_0.SetBackgroundColor(new DeviceRgb(0, 0, 0), 0f);
            cell_0.SetBorderBottom(Border.NO_BORDER);
            cell_0.SetBorderTop(Border.NO_BORDER);
            cell_0.SetBorderRight(Border.NO_BORDER);
            cell_0.SetBorderLeft(Border.NO_BORDER);
            cell_0.SetBorderRadius(new BorderRadius(0f * pxToPtFactor));
            
            
            cell_0.SetPaddingBottom(0 * pxToPtFactor).SetPaddingLeft(0 * pxToPtFactor)
            .SetPaddingTop(0 * pxToPtFactor).SetPaddingRight(0 * pxToPtFactor).SetFontSize(14 * pxToPtFactor)
            .SetFont(fontDictionary["poppins_regular"]).SetFontColor(new DeviceRgb(155, 155, 155), 1f)
            .SetTextAlignment(iText.Layout.Properties.TextAlignment.LEFT);
            var headerParagraph_0 = new Paragraph((kasaraporudokumform_1665150132_ColumnTitles is { Count: >= (0 + 1) } ? kasaraporudokumform_1665150132_ColumnTitles[0] : kasaraporudokumform_1665150132_ColumnTitles.Any() ? "" : ("Müşteri".ConvertToType<String>())))
            
            .WithGlyphFallback(fontDictionary, "poppins_regular", () => cjkFallbackFont.Value);
            cell_0.Add(headerParagraph_0);
            
            cell_0.SetVisible(true);
            kasaraporudokumform_1665150132.AddHeaderCell(cell_0);


            Cell cell_1 = new Cell(1, 1);
            //cell_1.SetBorder(iText.Layout.Borders.Border.NO_BORDER)
            cell_1.SetBackgroundColor(new DeviceRgb(0, 0, 0), 0f);
            cell_1.SetBorderBottom(Border.NO_BORDER);
            cell_1.SetBorderTop(Border.NO_BORDER);
            cell_1.SetBorderRight(Border.NO_BORDER);
            cell_1.SetBorderLeft(Border.NO_BORDER);
            cell_1.SetBorderRadius(new BorderRadius(0f * pxToPtFactor));
            
            if(true){cell_1.SetBorderLeft(kasaraporudokumform_1665150132leftBorder);}
            cell_1.SetPaddingBottom(0 * pxToPtFactor).SetPaddingLeft(0 * pxToPtFactor)
            .SetPaddingTop(0 * pxToPtFactor).SetPaddingRight(0 * pxToPtFactor).SetFontSize(14 * pxToPtFactor)
            .SetFont(fontDictionary["poppins_regular"]).SetFontColor(new DeviceRgb(155, 155, 155), 1f)
            .SetTextAlignment(iText.Layout.Properties.TextAlignment.LEFT);
            var headerParagraph_1 = new Paragraph((kasaraporudokumform_1665150132_ColumnTitles is { Count: >= (1 + 1) } ? kasaraporudokumform_1665150132_ColumnTitles[1] : kasaraporudokumform_1665150132_ColumnTitles.Any() ? "" : ("Ürün Adı".ConvertToType<String>())))
            
            .WithGlyphFallback(fontDictionary, "poppins_regular", () => cjkFallbackFont.Value);
            cell_1.Add(headerParagraph_1);
            
            cell_1.SetVisible(true);
            kasaraporudokumform_1665150132.AddHeaderCell(cell_1);


            Cell cell_2 = new Cell(1, 1);
            //cell_2.SetBorder(iText.Layout.Borders.Border.NO_BORDER)
            cell_2.SetBackgroundColor(new DeviceRgb(0, 0, 0), 0f);
            cell_2.SetBorderBottom(Border.NO_BORDER);
            cell_2.SetBorderTop(Border.NO_BORDER);
            cell_2.SetBorderRight(Border.NO_BORDER);
            cell_2.SetBorderLeft(Border.NO_BORDER);
            cell_2.SetBorderRadius(new BorderRadius(0f * pxToPtFactor));
            
            if(true){cell_2.SetBorderLeft(kasaraporudokumform_1665150132leftBorder);}
            cell_2.SetPaddingBottom(0 * pxToPtFactor).SetPaddingLeft(0 * pxToPtFactor)
            .SetPaddingTop(0 * pxToPtFactor).SetPaddingRight(0 * pxToPtFactor).SetFontSize(14 * pxToPtFactor)
            .SetFont(fontDictionary["poppins_regular"]).SetFontColor(new DeviceRgb(155, 155, 155), 1f)
            .SetTextAlignment(iText.Layout.Properties.TextAlignment.LEFT);
            var headerParagraph_2 = new Paragraph((kasaraporudokumform_1665150132_ColumnTitles is { Count: >= (2 + 1) } ? kasaraporudokumform_1665150132_ColumnTitles[2] : kasaraporudokumform_1665150132_ColumnTitles.Any() ? "" : ("Teslim Tarihi".ConvertToType<String>())))
            
            .WithGlyphFallback(fontDictionary, "poppins_regular", () => cjkFallbackFont.Value);
            cell_2.Add(headerParagraph_2);
            
            cell_2.SetVisible(true);
            kasaraporudokumform_1665150132.AddHeaderCell(cell_2);


            Cell cell_3 = new Cell(1, 1);
            //cell_3.SetBorder(iText.Layout.Borders.Border.NO_BORDER)
            cell_3.SetBackgroundColor(new DeviceRgb(0, 0, 0), 0f);
            cell_3.SetBorderBottom(Border.NO_BORDER);
            cell_3.SetBorderTop(Border.NO_BORDER);
            cell_3.SetBorderRight(Border.NO_BORDER);
            cell_3.SetBorderLeft(Border.NO_BORDER);
            cell_3.SetBorderRadius(new BorderRadius(0f * pxToPtFactor));
            
            if(true){cell_3.SetBorderLeft(kasaraporudokumform_1665150132leftBorder);}
            cell_3.SetPaddingBottom(0 * pxToPtFactor).SetPaddingLeft(0 * pxToPtFactor)
            .SetPaddingTop(0 * pxToPtFactor).SetPaddingRight(0 * pxToPtFactor).SetFontSize(14 * pxToPtFactor)
            .SetFont(fontDictionary["poppins_regular"]).SetFontColor(new DeviceRgb(155, 155, 155), 1f)
            .SetTextAlignment(iText.Layout.Properties.TextAlignment.LEFT);
            var headerParagraph_3 = new Paragraph((kasaraporudokumform_1665150132_ColumnTitles is { Count: >= (3 + 1) } ? kasaraporudokumform_1665150132_ColumnTitles[3] : kasaraporudokumform_1665150132_ColumnTitles.Any() ? "" : ("Satış Sorumlusu".ConvertToType<String>())))
            
            .WithGlyphFallback(fontDictionary, "poppins_regular", () => cjkFallbackFont.Value);
            cell_3.Add(headerParagraph_3);
            
            cell_3.SetVisible(true);
            kasaraporudokumform_1665150132.AddHeaderCell(cell_3);


            Cell cell_4 = new Cell(1, 1);
            //cell_4.SetBorder(iText.Layout.Borders.Border.NO_BORDER)
            cell_4.SetBackgroundColor(new DeviceRgb(0, 0, 0), 0f);
            cell_4.SetBorderBottom(Border.NO_BORDER);
            cell_4.SetBorderTop(Border.NO_BORDER);
            cell_4.SetBorderRight(Border.NO_BORDER);
            cell_4.SetBorderLeft(Border.NO_BORDER);
            cell_4.SetBorderRadius(new BorderRadius(0f * pxToPtFactor));
            
            if(true){cell_4.SetBorderLeft(kasaraporudokumform_1665150132leftBorder);}
            cell_4.SetPaddingBottom(0 * pxToPtFactor).SetPaddingLeft(0 * pxToPtFactor)
            .SetPaddingTop(0 * pxToPtFactor).SetPaddingRight(0 * pxToPtFactor).SetFontSize(14 * pxToPtFactor)
            .SetFont(fontDictionary["poppins_regular"]).SetFontColor(new DeviceRgb(155, 155, 155), 1f)
            .SetTextAlignment(iText.Layout.Properties.TextAlignment.LEFT);
            var headerParagraph_4 = new Paragraph((kasaraporudokumform_1665150132_ColumnTitles is { Count: >= (4 + 1) } ? kasaraporudokumform_1665150132_ColumnTitles[4] : kasaraporudokumform_1665150132_ColumnTitles.Any() ? "" : ("Liste Fiyatı".ConvertToType<String>())))
            
            .WithGlyphFallback(fontDictionary, "poppins_regular", () => cjkFallbackFont.Value);
            cell_4.Add(headerParagraph_4);
            
            cell_4.SetVisible(true);
            kasaraporudokumform_1665150132.AddHeaderCell(cell_4);


            Cell cell_5 = new Cell(1, 1);
            //cell_5.SetBorder(iText.Layout.Borders.Border.NO_BORDER)
            cell_5.SetBackgroundColor(new DeviceRgb(0, 0, 0), 0f);
            cell_5.SetBorderBottom(Border.NO_BORDER);
            cell_5.SetBorderTop(Border.NO_BORDER);
            cell_5.SetBorderRight(Border.NO_BORDER);
            cell_5.SetBorderLeft(Border.NO_BORDER);
            cell_5.SetBorderRadius(new BorderRadius(0f * pxToPtFactor));
            
            if(true){cell_5.SetBorderLeft(kasaraporudokumform_1665150132leftBorder);}
            cell_5.SetPaddingBottom(0 * pxToPtFactor).SetPaddingLeft(0 * pxToPtFactor)
            .SetPaddingTop(0 * pxToPtFactor).SetPaddingRight(0 * pxToPtFactor).SetFontSize(14 * pxToPtFactor)
            .SetFont(fontDictionary["poppins_regular"]).SetFontColor(new DeviceRgb(155, 155, 155), 1f)
            .SetTextAlignment(iText.Layout.Properties.TextAlignment.LEFT);
            var headerParagraph_5 = new Paragraph((kasaraporudokumform_1665150132_ColumnTitles is { Count: >= (5 + 1) } ? kasaraporudokumform_1665150132_ColumnTitles[5] : kasaraporudokumform_1665150132_ColumnTitles.Any() ? "" : ("TRY Fiyatı".ConvertToType<String>())))
            
            .WithGlyphFallback(fontDictionary, "poppins_regular", () => cjkFallbackFont.Value);
            cell_5.Add(headerParagraph_5);
            
            cell_5.SetVisible(true);
            kasaraporudokumform_1665150132.AddHeaderCell(cell_5);


            Cell cell_6 = new Cell(1, 1);
            //cell_6.SetBorder(iText.Layout.Borders.Border.NO_BORDER)
            cell_6.SetBackgroundColor(new DeviceRgb(0, 0, 0), 0f);
            cell_6.SetBorderBottom(Border.NO_BORDER);
            cell_6.SetBorderTop(Border.NO_BORDER);
            cell_6.SetBorderRight(Border.NO_BORDER);
            cell_6.SetBorderLeft(Border.NO_BORDER);
            cell_6.SetBorderRadius(new BorderRadius(0f * pxToPtFactor));
            
            if(true){cell_6.SetBorderLeft(kasaraporudokumform_1665150132leftBorder);}
            cell_6.SetPaddingBottom(0 * pxToPtFactor).SetPaddingLeft(0 * pxToPtFactor)
            .SetPaddingTop(0 * pxToPtFactor).SetPaddingRight(0 * pxToPtFactor).SetFontSize(14 * pxToPtFactor)
            .SetFont(fontDictionary["poppins_regular"]).SetFontColor(new DeviceRgb(155, 155, 155), 1f)
            .SetTextAlignment(iText.Layout.Properties.TextAlignment.LEFT);
            var headerParagraph_6 = new Paragraph((kasaraporudokumform_1665150132_ColumnTitles is { Count: >= (6 + 1) } ? kasaraporudokumform_1665150132_ColumnTitles[6] : kasaraporudokumform_1665150132_ColumnTitles.Any() ? "" : ("%".ConvertToType<String>())))
            
            .WithGlyphFallback(fontDictionary, "poppins_regular", () => cjkFallbackFont.Value);
            cell_6.Add(headerParagraph_6);
            
            cell_6.SetVisible(true);
            kasaraporudokumform_1665150132.AddHeaderCell(cell_6);


            Cell cell_7 = new Cell(1, 1);
            //cell_7.SetBorder(iText.Layout.Borders.Border.NO_BORDER)
            cell_7.SetBackgroundColor(new DeviceRgb(0, 0, 0), 0f);
            cell_7.SetBorderBottom(Border.NO_BORDER);
            cell_7.SetBorderTop(Border.NO_BORDER);
            cell_7.SetBorderRight(Border.NO_BORDER);
            cell_7.SetBorderLeft(Border.NO_BORDER);
            cell_7.SetBorderRadius(new BorderRadius(0f * pxToPtFactor));
            
            if(true){cell_7.SetBorderLeft(kasaraporudokumform_1665150132leftBorder);}
            cell_7.SetPaddingBottom(0 * pxToPtFactor).SetPaddingLeft(0 * pxToPtFactor)
            .SetPaddingTop(0 * pxToPtFactor).SetPaddingRight(0 * pxToPtFactor).SetFontSize(14 * pxToPtFactor)
            .SetFont(fontDictionary["poppins_regular"]).SetFontColor(new DeviceRgb(155, 155, 155), 1f)
            .SetTextAlignment(iText.Layout.Properties.TextAlignment.LEFT);
            var headerParagraph_7 = new Paragraph((kasaraporudokumform_1665150132_ColumnTitles is { Count: >= (7 + 1) } ? kasaraporudokumform_1665150132_ColumnTitles[7] : kasaraporudokumform_1665150132_ColumnTitles.Any() ? "" : ("Satış Tutarı".ConvertToType<String>())))
            
            .WithGlyphFallback(fontDictionary, "poppins_regular", () => cjkFallbackFont.Value);
            cell_7.Add(headerParagraph_7);
            
            cell_7.SetVisible(true);
            kasaraporudokumform_1665150132.AddHeaderCell(cell_7);


            Cell cell_8 = new Cell(1, 1);
            //cell_8.SetBorder(iText.Layout.Borders.Border.NO_BORDER)
            cell_8.SetBackgroundColor(new DeviceRgb(0, 0, 0), 0f);
            cell_8.SetBorderBottom(Border.NO_BORDER);
            cell_8.SetBorderTop(Border.NO_BORDER);
            cell_8.SetBorderRight(Border.NO_BORDER);
            cell_8.SetBorderLeft(Border.NO_BORDER);
            cell_8.SetBorderRadius(new BorderRadius(0f * pxToPtFactor));
            
            if(true){cell_8.SetBorderLeft(kasaraporudokumform_1665150132leftBorder);}
            cell_8.SetPaddingBottom(0 * pxToPtFactor).SetPaddingLeft(0 * pxToPtFactor)
            .SetPaddingTop(0 * pxToPtFactor).SetPaddingRight(0 * pxToPtFactor).SetFontSize(14 * pxToPtFactor)
            .SetFont(fontDictionary["poppins_regular"]).SetFontColor(new DeviceRgb(155, 155, 155), 1f)
            .SetTextAlignment(iText.Layout.Properties.TextAlignment.LEFT);
            var headerParagraph_8 = new Paragraph((kasaraporudokumform_1665150132_ColumnTitles is { Count: >= (8 + 1) } ? kasaraporudokumform_1665150132_ColumnTitles[8] : kasaraporudokumform_1665150132_ColumnTitles.Any() ? "" : ("Satış Tutarı TRY".ConvertToType<String>())))
            
            .WithGlyphFallback(fontDictionary, "poppins_regular", () => cjkFallbackFont.Value);
            cell_8.Add(headerParagraph_8);
            
            cell_8.SetVisible(true);
            kasaraporudokumform_1665150132.AddHeaderCell(cell_8);


            
            var rowBackgroundColor = new DeviceRgb(0, 0, 0);
            var rowOpacity = 0;
            var isStriped = false;
            Color stripedColor = new DeviceRgb(245, 247, 250);
            for(int i = 0; i < result.Kuika_Orders7.Count; i++)
              {
                  var item = result.Kuika_Orders7[i];
                  Color backgroundColor = new DeviceRgb(255, 255, 255);
                  float backgroundColorOpacity = 0f;

                  if (kasaraporudokumform_1665150132BackgroundColorOpacity == 1) {{
                        backgroundColor = kasaraporudokumform_1665150132BackgroundColor;
                        backgroundColorOpacity = 1f;
                  }}

                  if (rowOpacity == 1) {{
                        backgroundColor = rowBackgroundColor;
                        backgroundColorOpacity = 1f;
                  }}

                  if (isStriped && i % 2 != 0) {{
                        backgroundColor = stripedColor;
                        backgroundColorOpacity = 1f;
                  }}

                  
                
            var colData_01779749566 = new Paragraph(item.CurrAccDescription.ToFormattedString("", "", "") ?? "")
            .SetMarginBottom(0 * pxToPtFactor).SetMarginLeft(0 * pxToPtFactor)
            .SetMarginTop(0 * pxToPtFactor).SetMarginRight(0 * pxToPtFactor)
            .SetFontColor(new DeviceRgb(68, 68, 68), 1f)
            .SetBackgroundColor(new DeviceRgb(0, 0, 0), 0f)
            .SetFontSize(12 * pxToPtFactor)
            .SetFont(fontDictionary["poppins_regular"])
            .WithGlyphFallback(fontDictionary, "poppins_regular", () => cjkFallbackFont.Value)
            
            .SetParagraphWidthAndExtendHeightIfNotFit(document, 31.57f * pxToPtFactor, 20f * pxToPtFactor, true)
            .SetVisible(true)
            .SetVerticalAlignment(VerticalAlignment.TOP)
            .SetHorizontalAlignment(HorizontalAlignment.LEFT)
            .SetTextAlignment(TextAlignment.LEFT)
            .SetMultipliedLeading(1f);
            
colData_01779749566.SetVisible(true);

                Cell cell_1779749566 = new Cell(1, 1);
                var cell_1779749566BackgroundColor = new DeviceRgb(0, 0, 0);
                var cell_1779749566BackgroundColorOpacity = 0;
                
                cell_1779749566.SetMinHeight(40 * pxToPtFactor);
                //cell_1779749566.SetBorder(iText.Layout.Borders.Border.NO_BORDER);
                cell_1779749566.SetBorderBottom(Border.NO_BORDER);
                cell_1779749566.SetBorderTop(Border.NO_BORDER);
                cell_1779749566.SetBorderRight(Border.NO_BORDER);
                cell_1779749566.SetBorderLeft(Border.NO_BORDER);
                cell_1779749566.SetBorderRadius(new BorderRadius(0f * pxToPtFactor));
                //cell_1779749566.Add(colData_1779749566);
                if (cell_1779749566BackgroundColorOpacity == 1)
                    cell_1779749566.SetBackgroundColor(cell_1779749566BackgroundColor);
                else if (backgroundColorOpacity == 1)
                    cell_1779749566.SetBackgroundColor(backgroundColor);
                cell_1779749566.SetVerticalAlignment(iText.Layout.Properties.VerticalAlignment.TOP);
                cell_1779749566.SetTextAlignment(iText.Layout.Properties.TextAlignment.LEFT);
                cell_1779749566.SetPaddingBottom(0 * pxToPtFactor).SetPaddingLeft(0 * pxToPtFactor)
                .SetPaddingTop(0 * pxToPtFactor).SetPaddingRight(0 * pxToPtFactor);
                
                kasaraporudokumform_1665150132.AddCell(cell_1779749566);

cell_1779749566.Add(colData_01779749566);

                
            var colData_02109879499 = new Paragraph(item.ItemDescription.ToFormattedString("", "", "") ?? "")
            .SetMarginBottom(0 * pxToPtFactor).SetMarginLeft(0 * pxToPtFactor)
            .SetMarginTop(0 * pxToPtFactor).SetMarginRight(0 * pxToPtFactor)
            .SetFontColor(new DeviceRgb(68, 68, 68), 1f)
            .SetBackgroundColor(new DeviceRgb(0, 0, 0), 0f)
            .SetFontSize(12 * pxToPtFactor)
            .SetFont(fontDictionary["poppins_regular"])
            .WithGlyphFallback(fontDictionary, "poppins_regular", () => cjkFallbackFont.Value)
            
            .SetParagraphWidthAndExtendHeightIfNotFit(document, 31.57f * pxToPtFactor, 20f * pxToPtFactor, true)
            .SetVisible(true)
            .SetVerticalAlignment(VerticalAlignment.TOP)
            .SetHorizontalAlignment(HorizontalAlignment.LEFT)
            .SetTextAlignment(TextAlignment.LEFT)
            .SetMultipliedLeading(1f);
            
colData_02109879499.SetVisible(true);

                Cell cell_2109879499 = new Cell(1, 1);
                var cell_2109879499BackgroundColor = new DeviceRgb(0, 0, 0);
                var cell_2109879499BackgroundColorOpacity = 0;
                
                cell_2109879499.SetMinHeight(40 * pxToPtFactor);
                //cell_2109879499.SetBorder(iText.Layout.Borders.Border.NO_BORDER);
                cell_2109879499.SetBorderBottom(Border.NO_BORDER);
                cell_2109879499.SetBorderTop(Border.NO_BORDER);
                cell_2109879499.SetBorderRight(Border.NO_BORDER);
                cell_2109879499.SetBorderLeft(Border.NO_BORDER);
                cell_2109879499.SetBorderRadius(new BorderRadius(0f * pxToPtFactor));
                //cell_2109879499.Add(colData_2109879499);
                if (cell_2109879499BackgroundColorOpacity == 1)
                    cell_2109879499.SetBackgroundColor(cell_2109879499BackgroundColor);
                else if (backgroundColorOpacity == 1)
                    cell_2109879499.SetBackgroundColor(backgroundColor);
                cell_2109879499.SetVerticalAlignment(iText.Layout.Properties.VerticalAlignment.TOP);
                cell_2109879499.SetTextAlignment(iText.Layout.Properties.TextAlignment.LEFT);
                cell_2109879499.SetPaddingBottom(0 * pxToPtFactor).SetPaddingLeft(0 * pxToPtFactor)
                .SetPaddingTop(0 * pxToPtFactor).SetPaddingRight(0 * pxToPtFactor);
                
                kasaraporudokumform_1665150132.AddCell(cell_2109879499);

cell_2109879499.Add(colData_02109879499);

                
            var colData_0205681808 = new Paragraph(item.DeliveryDate.ToFormattedString("", "", "") ?? "")
            .SetMarginBottom(0 * pxToPtFactor).SetMarginLeft(0 * pxToPtFactor)
            .SetMarginTop(0 * pxToPtFactor).SetMarginRight(0 * pxToPtFactor)
            .SetFontColor(new DeviceRgb(68, 68, 68), 1f)
            .SetBackgroundColor(new DeviceRgb(0, 0, 0), 0f)
            .SetFontSize(12 * pxToPtFactor)
            .SetFont(fontDictionary["poppins_regular"])
            .WithGlyphFallback(fontDictionary, "poppins_regular", () => cjkFallbackFont.Value)
            
            .SetParagraphWidthAndExtendHeightIfNotFit(document, 31.57f * pxToPtFactor, 20f * pxToPtFactor, true)
            .SetVisible(true)
            .SetVerticalAlignment(VerticalAlignment.TOP)
            .SetHorizontalAlignment(HorizontalAlignment.LEFT)
            .SetTextAlignment(TextAlignment.LEFT)
            .SetMultipliedLeading(1f);
            
colData_0205681808.SetVisible(true);

                Cell cell_205681808 = new Cell(1, 1);
                var cell_205681808BackgroundColor = new DeviceRgb(0, 0, 0);
                var cell_205681808BackgroundColorOpacity = 0;
                
                cell_205681808.SetMinHeight(40 * pxToPtFactor);
                //cell_205681808.SetBorder(iText.Layout.Borders.Border.NO_BORDER);
                cell_205681808.SetBorderBottom(Border.NO_BORDER);
                cell_205681808.SetBorderTop(Border.NO_BORDER);
                cell_205681808.SetBorderRight(Border.NO_BORDER);
                cell_205681808.SetBorderLeft(Border.NO_BORDER);
                cell_205681808.SetBorderRadius(new BorderRadius(0f * pxToPtFactor));
                //cell_205681808.Add(colData_205681808);
                if (cell_205681808BackgroundColorOpacity == 1)
                    cell_205681808.SetBackgroundColor(cell_205681808BackgroundColor);
                else if (backgroundColorOpacity == 1)
                    cell_205681808.SetBackgroundColor(backgroundColor);
                cell_205681808.SetVerticalAlignment(iText.Layout.Properties.VerticalAlignment.TOP);
                cell_205681808.SetTextAlignment(iText.Layout.Properties.TextAlignment.LEFT);
                cell_205681808.SetPaddingBottom(0 * pxToPtFactor).SetPaddingLeft(0 * pxToPtFactor)
                .SetPaddingTop(0 * pxToPtFactor).SetPaddingRight(0 * pxToPtFactor);
                
                kasaraporudokumform_1665150132.AddCell(cell_205681808);

cell_205681808.Add(colData_0205681808);

                
            var colData_0648078440 = new Paragraph(item.SalesPersonName.ToFormattedString("", "", "") ?? "")
            .SetMarginBottom(0 * pxToPtFactor).SetMarginLeft(0 * pxToPtFactor)
            .SetMarginTop(0 * pxToPtFactor).SetMarginRight(0 * pxToPtFactor)
            .SetFontColor(new DeviceRgb(68, 68, 68), 1f)
            .SetBackgroundColor(new DeviceRgb(0, 0, 0), 0f)
            .SetFontSize(12 * pxToPtFactor)
            .SetFont(fontDictionary["poppins_regular"])
            .WithGlyphFallback(fontDictionary, "poppins_regular", () => cjkFallbackFont.Value)
            
            .SetParagraphWidthAndExtendHeightIfNotFit(document, 31.57f * pxToPtFactor, 20f * pxToPtFactor, true)
            .SetVisible(true)
            .SetVerticalAlignment(VerticalAlignment.TOP)
            .SetHorizontalAlignment(HorizontalAlignment.LEFT)
            .SetTextAlignment(TextAlignment.LEFT)
            .SetMultipliedLeading(1f);
            
colData_0648078440.SetVisible(true);

                Cell cell_648078440 = new Cell(1, 1);
                var cell_648078440BackgroundColor = new DeviceRgb(0, 0, 0);
                var cell_648078440BackgroundColorOpacity = 0;
                
                cell_648078440.SetMinHeight(40 * pxToPtFactor);
                //cell_648078440.SetBorder(iText.Layout.Borders.Border.NO_BORDER);
                cell_648078440.SetBorderBottom(Border.NO_BORDER);
                cell_648078440.SetBorderTop(Border.NO_BORDER);
                cell_648078440.SetBorderRight(Border.NO_BORDER);
                cell_648078440.SetBorderLeft(Border.NO_BORDER);
                cell_648078440.SetBorderRadius(new BorderRadius(0f * pxToPtFactor));
                //cell_648078440.Add(colData_648078440);
                if (cell_648078440BackgroundColorOpacity == 1)
                    cell_648078440.SetBackgroundColor(cell_648078440BackgroundColor);
                else if (backgroundColorOpacity == 1)
                    cell_648078440.SetBackgroundColor(backgroundColor);
                cell_648078440.SetVerticalAlignment(iText.Layout.Properties.VerticalAlignment.TOP);
                cell_648078440.SetTextAlignment(iText.Layout.Properties.TextAlignment.LEFT);
                cell_648078440.SetPaddingBottom(0 * pxToPtFactor).SetPaddingLeft(0 * pxToPtFactor)
                .SetPaddingTop(0 * pxToPtFactor).SetPaddingRight(0 * pxToPtFactor);
                
                kasaraporudokumform_1665150132.AddCell(cell_648078440);

cell_648078440.Add(colData_0648078440);

                
            var colData_03537238 = new Paragraph(item.Doc_TaxBase.ToFormattedString("", "", "") ?? "")
            .SetMarginBottom(0 * pxToPtFactor).SetMarginLeft(0 * pxToPtFactor)
            .SetMarginTop(0 * pxToPtFactor).SetMarginRight(0 * pxToPtFactor)
            .SetFontColor(new DeviceRgb(68, 68, 68), 1f)
            .SetBackgroundColor(new DeviceRgb(0, 0, 0), 0f)
            .SetFontSize(12 * pxToPtFactor)
            .SetFont(fontDictionary["poppins_regular"])
            .WithGlyphFallback(fontDictionary, "poppins_regular", () => cjkFallbackFont.Value)
            
            .SetParagraphWidthAndExtendHeightIfNotFit(document, 31.57f * pxToPtFactor, 20f * pxToPtFactor, true)
            .SetVisible(true)
            .SetVerticalAlignment(VerticalAlignment.TOP)
            .SetHorizontalAlignment(HorizontalAlignment.LEFT)
            .SetTextAlignment(TextAlignment.LEFT)
            .SetMultipliedLeading(1f);
            
colData_03537238.SetVisible(true);

                Cell cell_3537238 = new Cell(1, 1);
                var cell_3537238BackgroundColor = new DeviceRgb(0, 0, 0);
                var cell_3537238BackgroundColorOpacity = 0;
                
                cell_3537238.SetMinHeight(40 * pxToPtFactor);
                //cell_3537238.SetBorder(iText.Layout.Borders.Border.NO_BORDER);
                cell_3537238.SetBorderBottom(Border.NO_BORDER);
                cell_3537238.SetBorderTop(Border.NO_BORDER);
                cell_3537238.SetBorderRight(Border.NO_BORDER);
                cell_3537238.SetBorderLeft(Border.NO_BORDER);
                cell_3537238.SetBorderRadius(new BorderRadius(0f * pxToPtFactor));
                //cell_3537238.Add(colData_3537238);
                if (cell_3537238BackgroundColorOpacity == 1)
                    cell_3537238.SetBackgroundColor(cell_3537238BackgroundColor);
                else if (backgroundColorOpacity == 1)
                    cell_3537238.SetBackgroundColor(backgroundColor);
                cell_3537238.SetVerticalAlignment(iText.Layout.Properties.VerticalAlignment.TOP);
                cell_3537238.SetTextAlignment(iText.Layout.Properties.TextAlignment.LEFT);
                cell_3537238.SetPaddingBottom(0 * pxToPtFactor).SetPaddingLeft(0 * pxToPtFactor)
                .SetPaddingTop(0 * pxToPtFactor).SetPaddingRight(0 * pxToPtFactor);
                
                kasaraporudokumform_1665150132.AddCell(cell_3537238);

cell_3537238.Add(colData_03537238);

                
            var colData_0530236539 = new Paragraph(item.Doc_NetAmount.ToFormattedString("", "", "") ?? "")
            .SetMarginBottom(0 * pxToPtFactor).SetMarginLeft(0 * pxToPtFactor)
            .SetMarginTop(0 * pxToPtFactor).SetMarginRight(0 * pxToPtFactor)
            .SetFontColor(new DeviceRgb(68, 68, 68), 1f)
            .SetBackgroundColor(new DeviceRgb(0, 0, 0), 0f)
            .SetFontSize(12 * pxToPtFactor)
            .SetFont(fontDictionary["poppins_regular"])
            .WithGlyphFallback(fontDictionary, "poppins_regular", () => cjkFallbackFont.Value)
            
            .SetParagraphWidthAndExtendHeightIfNotFit(document, 31.57f * pxToPtFactor, 20f * pxToPtFactor, true)
            .SetVisible(true)
            .SetVerticalAlignment(VerticalAlignment.TOP)
            .SetHorizontalAlignment(HorizontalAlignment.LEFT)
            .SetTextAlignment(TextAlignment.LEFT)
            .SetMultipliedLeading(1f);
            
colData_0530236539.SetVisible(true);

                Cell cell_530236539 = new Cell(1, 1);
                var cell_530236539BackgroundColor = new DeviceRgb(0, 0, 0);
                var cell_530236539BackgroundColorOpacity = 0;
                
                cell_530236539.SetMinHeight(40 * pxToPtFactor);
                //cell_530236539.SetBorder(iText.Layout.Borders.Border.NO_BORDER);
                cell_530236539.SetBorderBottom(Border.NO_BORDER);
                cell_530236539.SetBorderTop(Border.NO_BORDER);
                cell_530236539.SetBorderRight(Border.NO_BORDER);
                cell_530236539.SetBorderLeft(Border.NO_BORDER);
                cell_530236539.SetBorderRadius(new BorderRadius(0f * pxToPtFactor));
                //cell_530236539.Add(colData_530236539);
                if (cell_530236539BackgroundColorOpacity == 1)
                    cell_530236539.SetBackgroundColor(cell_530236539BackgroundColor);
                else if (backgroundColorOpacity == 1)
                    cell_530236539.SetBackgroundColor(backgroundColor);
                cell_530236539.SetVerticalAlignment(iText.Layout.Properties.VerticalAlignment.TOP);
                cell_530236539.SetTextAlignment(iText.Layout.Properties.TextAlignment.LEFT);
                cell_530236539.SetPaddingBottom(0 * pxToPtFactor).SetPaddingLeft(0 * pxToPtFactor)
                .SetPaddingTop(0 * pxToPtFactor).SetPaddingRight(0 * pxToPtFactor);
                
                kasaraporudokumform_1665150132.AddCell(cell_530236539);

cell_530236539.Add(colData_0530236539);

                
            var colData_01253338228 = new Paragraph(item.Doc_Vat.ToFormattedString("", "", "") ?? "")
            .SetMarginBottom(0 * pxToPtFactor).SetMarginLeft(0 * pxToPtFactor)
            .SetMarginTop(0 * pxToPtFactor).SetMarginRight(0 * pxToPtFactor)
            .SetFontColor(new DeviceRgb(68, 68, 68), 1f)
            .SetBackgroundColor(new DeviceRgb(0, 0, 0), 0f)
            .SetFontSize(12 * pxToPtFactor)
            .SetFont(fontDictionary["poppins_regular"])
            .WithGlyphFallback(fontDictionary, "poppins_regular", () => cjkFallbackFont.Value)
            
            .SetParagraphWidthAndExtendHeightIfNotFit(document, 31.57f * pxToPtFactor, 20f * pxToPtFactor, true)
            .SetVisible(true)
            .SetVerticalAlignment(VerticalAlignment.TOP)
            .SetHorizontalAlignment(HorizontalAlignment.LEFT)
            .SetTextAlignment(TextAlignment.LEFT)
            .SetMultipliedLeading(1f);
            
colData_01253338228.SetVisible(true);

                Cell cell_1253338228 = new Cell(1, 1);
                var cell_1253338228BackgroundColor = new DeviceRgb(0, 0, 0);
                var cell_1253338228BackgroundColorOpacity = 0;
                
                cell_1253338228.SetMinHeight(40 * pxToPtFactor);
                //cell_1253338228.SetBorder(iText.Layout.Borders.Border.NO_BORDER);
                cell_1253338228.SetBorderBottom(Border.NO_BORDER);
                cell_1253338228.SetBorderTop(Border.NO_BORDER);
                cell_1253338228.SetBorderRight(Border.NO_BORDER);
                cell_1253338228.SetBorderLeft(Border.NO_BORDER);
                cell_1253338228.SetBorderRadius(new BorderRadius(0f * pxToPtFactor));
                //cell_1253338228.Add(colData_1253338228);
                if (cell_1253338228BackgroundColorOpacity == 1)
                    cell_1253338228.SetBackgroundColor(cell_1253338228BackgroundColor);
                else if (backgroundColorOpacity == 1)
                    cell_1253338228.SetBackgroundColor(backgroundColor);
                cell_1253338228.SetVerticalAlignment(iText.Layout.Properties.VerticalAlignment.TOP);
                cell_1253338228.SetTextAlignment(iText.Layout.Properties.TextAlignment.LEFT);
                cell_1253338228.SetPaddingBottom(0 * pxToPtFactor).SetPaddingLeft(0 * pxToPtFactor)
                .SetPaddingTop(0 * pxToPtFactor).SetPaddingRight(0 * pxToPtFactor);
                
                kasaraporudokumform_1665150132.AddCell(cell_1253338228);

cell_1253338228.Add(colData_01253338228);

                
            var colData_037011358 = new Paragraph(item.Doc_NetAmount.ToFormattedString("", "", "") ?? "")
            .SetMarginBottom(0 * pxToPtFactor).SetMarginLeft(0 * pxToPtFactor)
            .SetMarginTop(0 * pxToPtFactor).SetMarginRight(0 * pxToPtFactor)
            .SetFontColor(new DeviceRgb(68, 68, 68), 1f)
            .SetBackgroundColor(new DeviceRgb(0, 0, 0), 0f)
            .SetFontSize(12 * pxToPtFactor)
            .SetFont(fontDictionary["poppins_regular"])
            .WithGlyphFallback(fontDictionary, "poppins_regular", () => cjkFallbackFont.Value)
            
            .SetParagraphWidthAndExtendHeightIfNotFit(document, 31.57f * pxToPtFactor, 20f * pxToPtFactor, true)
            .SetVisible(true)
            .SetVerticalAlignment(VerticalAlignment.TOP)
            .SetHorizontalAlignment(HorizontalAlignment.LEFT)
            .SetTextAlignment(TextAlignment.LEFT)
            .SetMultipliedLeading(1f);
            
colData_037011358.SetVisible(true);

                Cell cell_37011358 = new Cell(1, 1);
                var cell_37011358BackgroundColor = new DeviceRgb(0, 0, 0);
                var cell_37011358BackgroundColorOpacity = 0;
                
                cell_37011358.SetMinHeight(40 * pxToPtFactor);
                //cell_37011358.SetBorder(iText.Layout.Borders.Border.NO_BORDER);
                cell_37011358.SetBorderBottom(Border.NO_BORDER);
                cell_37011358.SetBorderTop(Border.NO_BORDER);
                cell_37011358.SetBorderRight(Border.NO_BORDER);
                cell_37011358.SetBorderLeft(Border.NO_BORDER);
                cell_37011358.SetBorderRadius(new BorderRadius(0f * pxToPtFactor));
                //cell_37011358.Add(colData_37011358);
                if (cell_37011358BackgroundColorOpacity == 1)
                    cell_37011358.SetBackgroundColor(cell_37011358BackgroundColor);
                else if (backgroundColorOpacity == 1)
                    cell_37011358.SetBackgroundColor(backgroundColor);
                cell_37011358.SetVerticalAlignment(iText.Layout.Properties.VerticalAlignment.TOP);
                cell_37011358.SetTextAlignment(iText.Layout.Properties.TextAlignment.LEFT);
                cell_37011358.SetPaddingBottom(0 * pxToPtFactor).SetPaddingLeft(0 * pxToPtFactor)
                .SetPaddingTop(0 * pxToPtFactor).SetPaddingRight(0 * pxToPtFactor);
                
                kasaraporudokumform_1665150132.AddCell(cell_37011358);

cell_37011358.Add(colData_037011358);

                
            var colData_0162064520 = new Paragraph(item.Loc_NetAmount.ToFormattedString("", "", "") ?? "")
            .SetMarginBottom(0 * pxToPtFactor).SetMarginLeft(0 * pxToPtFactor)
            .SetMarginTop(0 * pxToPtFactor).SetMarginRight(0 * pxToPtFactor)
            .SetFontColor(new DeviceRgb(68, 68, 68), 1f)
            .SetBackgroundColor(new DeviceRgb(0, 0, 0), 0f)
            .SetFontSize(12 * pxToPtFactor)
            .SetFont(fontDictionary["poppins_regular"])
            .WithGlyphFallback(fontDictionary, "poppins_regular", () => cjkFallbackFont.Value)
            
            .SetParagraphWidthAndExtendHeightIfNotFit(document, 31.57f * pxToPtFactor, 20f * pxToPtFactor, true)
            .SetVisible(true)
            .SetVerticalAlignment(VerticalAlignment.TOP)
            .SetHorizontalAlignment(HorizontalAlignment.LEFT)
            .SetTextAlignment(TextAlignment.LEFT)
            .SetMultipliedLeading(1f);
            
colData_0162064520.SetVisible(true);

                Cell cell_162064520 = new Cell(1, 1);
                var cell_162064520BackgroundColor = new DeviceRgb(0, 0, 0);
                var cell_162064520BackgroundColorOpacity = 0;
                
                cell_162064520.SetMinHeight(40 * pxToPtFactor);
                //cell_162064520.SetBorder(iText.Layout.Borders.Border.NO_BORDER);
                cell_162064520.SetBorderBottom(Border.NO_BORDER);
                cell_162064520.SetBorderTop(Border.NO_BORDER);
                cell_162064520.SetBorderRight(Border.NO_BORDER);
                cell_162064520.SetBorderLeft(Border.NO_BORDER);
                cell_162064520.SetBorderRadius(new BorderRadius(0f * pxToPtFactor));
                //cell_162064520.Add(colData_162064520);
                if (cell_162064520BackgroundColorOpacity == 1)
                    cell_162064520.SetBackgroundColor(cell_162064520BackgroundColor);
                else if (backgroundColorOpacity == 1)
                    cell_162064520.SetBackgroundColor(backgroundColor);
                cell_162064520.SetVerticalAlignment(iText.Layout.Properties.VerticalAlignment.TOP);
                cell_162064520.SetTextAlignment(iText.Layout.Properties.TextAlignment.LEFT);
                cell_162064520.SetPaddingBottom(0 * pxToPtFactor).SetPaddingLeft(0 * pxToPtFactor)
                .SetPaddingTop(0 * pxToPtFactor).SetPaddingRight(0 * pxToPtFactor);
                
                kasaraporudokumform_1665150132.AddCell(cell_162064520);

cell_162064520.Add(colData_0162064520);

              }



            kasaraporudokumform_1665150132.SetMarginLeft(10f * pxToPtFactor + 0f * pxToPtFactor);
            if (Math.Abs(210f * pxToPtFactor) > 0) {{
               kasaraporudokumform_1665150132.SetMarginTop(Math.Abs(210f * pxToPtFactor) + 0f * pxToPtFactor);
            }}
            kasaraporudokumform_1453904397_cell.Add(kasaraporudokumform_1665150132);
        }

   
            kasaraporudokumform_1453904397_cell.SetVisible(box_kasaraporudokumform_1453904397.IsVisible());
            box_kasaraporudokumform_1453904397.AddCell(kasaraporudokumform_1453904397_cell);
            
            // Draw rounded rectangle with PdfCanvas for border-radius support
            {
                var boxX = 10f * pxToPtFactor;
                var boxAbsY = Math.Abs(170f * pxToPtFactor);
                var boxPageRelY = boxAbsY - pageStartY;
                var boxY = ((currentPageHeight > 0 ? currentPageHeight : canvasHeight.Value) - (boxPageRelY + Math.Abs(270f * pxToPtFactor)));
                var boxW = 780f * pxToPtFactor;
                var boxH = 270f * pxToPtFactor;
                var boxRadiusTL = 6f * pxToPtFactor;
                var boxRadiusTR = 6f * pxToPtFactor;
                var boxRadiusBR = 6f * pxToPtFactor;
                var boxRadiusBL = 6f * pxToPtFactor;
                float kappaTL = boxRadiusTL * 0.5522848f;
                float kappaTR = boxRadiusTR * 0.5522848f;
                float kappaBR = boxRadiusBR * 0.5522848f;
                float kappaBL = boxRadiusBL * 0.5522848f;
                var currentPage = pdf.GetPage(pdf.GetNumberOfPages());
                var pdfCanvas = new PdfCanvas(currentPage);

                // Draw rounded background with alpha support
                pdfCanvas.SaveState();
                pdfCanvas.SetExtGState(new PdfExtGState().SetFillOpacity(1f));
                pdfCanvas.SetFillColor(new DeviceRgb(255, 255, 255));
                pdfCanvas.MoveTo(boxX + boxRadiusBL, boxY);
                pdfCanvas.LineTo(boxX + boxW - boxRadiusBR, boxY);
                if (boxRadiusBR > 0) pdfCanvas.CurveTo(boxX + boxW - boxRadiusBR + kappaBR, boxY, boxX + boxW, boxY + boxRadiusBR - kappaBR, boxX + boxW, boxY + boxRadiusBR);
                pdfCanvas.LineTo(boxX + boxW, boxY + boxH - boxRadiusTR);
                if (boxRadiusTR > 0) pdfCanvas.CurveTo(boxX + boxW, boxY + boxH - boxRadiusTR + kappaTR, boxX + boxW - boxRadiusTR + kappaTR, boxY + boxH, boxX + boxW - boxRadiusTR, boxY + boxH);
                pdfCanvas.LineTo(boxX + boxRadiusTL, boxY + boxH);
                if (boxRadiusTL > 0) pdfCanvas.CurveTo(boxX + boxRadiusTL - kappaTL, boxY + boxH, boxX, boxY + boxH - boxRadiusTL + kappaTL, boxX, boxY + boxH - boxRadiusTL);
                pdfCanvas.LineTo(boxX, boxY + boxRadiusBL);
                if (boxRadiusBL > 0) pdfCanvas.CurveTo(boxX, boxY + boxRadiusBL - kappaBL, boxX + boxRadiusBL - kappaBL, boxY, boxX + boxRadiusBL, boxY);
                pdfCanvas.ClosePath();
                pdfCanvas.Fill();
                pdfCanvas.RestoreState();

                // Draw individual border edges with per-side widths
                var rrBorderColor = new DeviceRgb(238, 242, 246);
                float rrBorderTop = 1f * pxToPtFactor;
                float rrBorderRight = 1f * pxToPtFactor;
                float rrBorderBottom = 1f * pxToPtFactor;
                float rrBorderLeft = 1f * pxToPtFactor;

                // Top border (uses TL and TR corners)
                if (rrBorderTop > 0)
                {
                    pdfCanvas.SaveState();
                    pdfCanvas.SetExtGState(new PdfExtGState().SetStrokeOpacity(1f));
                    pdfCanvas.SetStrokeColor(rrBorderColor);
                    pdfCanvas.SetLineWidth(rrBorderTop);
                    pdfCanvas.MoveTo(boxX + boxRadiusTL, boxY + boxH);
                    pdfCanvas.LineTo(boxX + boxW - boxRadiusTR, boxY + boxH);
                    if (boxRadiusTR > 0) pdfCanvas.CurveTo(boxX + boxW - boxRadiusTR + kappaTR, boxY + boxH, boxX + boxW, boxY + boxH - boxRadiusTR + kappaTR, boxX + boxW, boxY + boxH - boxRadiusTR);
                    pdfCanvas.Stroke();
                    pdfCanvas.RestoreState();
                }

                // Right border (uses TR and BR corners)
                if (rrBorderRight > 0)
                {
                    pdfCanvas.SaveState();
                    pdfCanvas.SetExtGState(new PdfExtGState().SetStrokeOpacity(1f));
                    pdfCanvas.SetStrokeColor(rrBorderColor);
                    pdfCanvas.SetLineWidth(rrBorderRight);
                    pdfCanvas.MoveTo(boxX + boxW, boxY + boxH - boxRadiusTR);
                    pdfCanvas.LineTo(boxX + boxW, boxY + boxRadiusBR);
                    if (boxRadiusBR > 0) pdfCanvas.CurveTo(boxX + boxW, boxY + boxRadiusBR - kappaBR, boxX + boxW - boxRadiusBR + kappaBR, boxY, boxX + boxW - boxRadiusBR, boxY);
                    pdfCanvas.Stroke();
                    pdfCanvas.RestoreState();
                }

                // Bottom border (uses BR and BL corners)
                if (rrBorderBottom > 0)
                {
                    pdfCanvas.SaveState();
                    pdfCanvas.SetExtGState(new PdfExtGState().SetStrokeOpacity(1f));
                    pdfCanvas.SetStrokeColor(rrBorderColor);
                    pdfCanvas.SetLineWidth(rrBorderBottom);
                    pdfCanvas.MoveTo(boxX + boxW - boxRadiusBR, boxY);
                    pdfCanvas.LineTo(boxX + boxRadiusBL, boxY);
                    if (boxRadiusBL > 0) pdfCanvas.CurveTo(boxX + boxRadiusBL - kappaBL, boxY, boxX, boxY + boxRadiusBL - kappaBL, boxX, boxY + boxRadiusBL);
                    pdfCanvas.Stroke();
                    pdfCanvas.RestoreState();
                }

                // Left border (uses BL and TL corners)
                if (rrBorderLeft > 0)
                {
                    pdfCanvas.SaveState();
                    pdfCanvas.SetExtGState(new PdfExtGState().SetStrokeOpacity(1f));
                    pdfCanvas.SetStrokeColor(rrBorderColor);
                    pdfCanvas.SetLineWidth(rrBorderLeft);
                    pdfCanvas.MoveTo(boxX, boxY + boxRadiusBL);
                    pdfCanvas.LineTo(boxX, boxY + boxH - boxRadiusTL);
                    if (boxRadiusTL > 0) pdfCanvas.CurveTo(boxX, boxY + boxH - boxRadiusTL + kappaTL, boxX + boxRadiusTL - kappaTL, boxY + boxH, boxX + boxRadiusTL, boxY + boxH);
                    pdfCanvas.Stroke();
                    pdfCanvas.RestoreState();
                }
            }
            document.Add(box_kasaraporudokumform_1453904397);
            foreach (var deferredElem in box_kasaraporudokumform_1453904397_deferredAdds) document.Add(deferredElem);
            }}


            //Box2
            Table box_kasaraporudokumform_1456958834 = new Table(1).SetWidth(790f * pxToPtFactor).SetHeight(30f * pxToPtFactor)
            .SetFontColor(new DeviceRgb(0, 0, 0), 1f)
            .SetFontSize(20 * pxToPtFactor)
            .SetVisible(true);
            if (box_kasaraporudokumform_1456958834.IsVisible()) {{
            var box_kasaraporudokumform_1456958834_pageLeftX = (double)(10f * pxToPtFactor) ;
            var box_kasaraporudokumform_1456958834_pageTopY = 0d;
            var box_kasaraporudokumform_1456958834_deferredAdds = new List<IBlockElement>();
            if (!false) {
            // Calculate page-relative Y position
            var box_kasaraporudokumform_1456958834_absoluteY = Math.Abs(170f * pxToPtFactor);
            var box_kasaraporudokumform_1456958834_pageRelativeY = box_kasaraporudokumform_1456958834_absoluteY - pageStartY;
            int box_kasaraporudokumform_1456958834_targetPage = pdf.GetNumberOfPages();
            
            box_kasaraporudokumform_1456958834.SetFixedPosition(box_kasaraporudokumform_1456958834_targetPage, 10f * pxToPtFactor , ((currentPageHeight > 0 ? currentPageHeight : canvasHeight.Value) - (box_kasaraporudokumform_1456958834_pageRelativeY + Math.Abs(30f * pxToPtFactor))) , 790f * pxToPtFactor);
            box_kasaraporudokumform_1456958834_pageTopY = ((double)(currentPageHeight > 0 ? currentPageHeight : canvasHeight.Value) - box_kasaraporudokumform_1456958834_pageRelativeY) ;
            } else {
            box_kasaraporudokumform_1456958834.SetFixedPosition(10f * pxToPtFactor , ((currentPageHeight > 0 ? currentPageHeight : canvasHeight.Value) - (totalHeight + Math.Abs(170f * pxToPtFactor) + Math.Abs(30f * pxToPtFactor))) , 790f * pxToPtFactor);
            box_kasaraporudokumform_1456958834_pageTopY = ((double)(currentPageHeight > 0 ? currentPageHeight : canvasHeight.Value) - (totalHeight + Math.Abs(170f * pxToPtFactor))) ;
            }
            box_kasaraporudokumform_1456958834.SetBorder(Border.NO_BORDER);
            box_kasaraporudokumform_1456958834.SetBorderBottom(Border.NO_BORDER);
            box_kasaraporudokumform_1456958834.SetBorderTop(Border.NO_BORDER);
            box_kasaraporudokumform_1456958834.SetBorderRight(Border.NO_BORDER);
            box_kasaraporudokumform_1456958834.SetBorderLeft(Border.NO_BORDER);
            box_kasaraporudokumform_1456958834.SetBorderRadius(new BorderRadius(6f * pxToPtFactor));
            var heightOf_box_kasaraporudokumform_1456958834 = box_kasaraporudokumform_1456958834.GetHeight();
            Cell kasaraporudokumform_1456958834_cell = new Cell();
            kasaraporudokumform_1456958834_cell.SetBackgroundColor(new DeviceRgb(114, 194, 64), 0f);
            kasaraporudokumform_1456958834_cell.SetBorder(Border.NO_BORDER);
            
            // NOTE: Box always uses SetFixedPosition above (both branches), so it does not
            // contribute to flow. The legacy "totalHeight + height > canvasHeight" areaBreak
            // that lived here was reading totalHeight produced by previous flow elements
            // (e.g. multi-page ReportTables) and spuriously creating a new page + bumping
            // pageStartY, which broke pageRelativeY for every subsequent element. Removed.

            // No page breaks - using default canvas height behavior


            //Label9
            var label_kasaraporudokumform_714180733_effectiveWidth = 780f * pxToPtFactor > 0 ? 780f * pxToPtFactor : (canvasWidth.Value - (10f * pxToPtFactor));
            Paragraph label_kasaraporudokumform_714180733 = new Paragraph(@"Satış Siparişleri")
            .SetFontSize(15 * pxToPtFactor)
            .SetFont(fontDictionary["poppins_bold"])
            .WithGlyphFallback(fontDictionary, "poppins_bold", () => cjkFallbackFont.Value)
            .SetTextAlignment(TextAlignment.CENTER)
            
            .SetParagraphWidthAndExtendHeightIfNotFit(document, label_kasaraporudokumform_714180733_effectiveWidth, 20f * pxToPtFactor, false, false || false)
            .SetMultipliedLeading(0.875f);
            

            if (20f * pxToPtFactor == 0f)
            {
                label_kasaraporudokumform_714180733.SetMaxHeight((30f * pxToPtFactor) - Math.Abs(170f * pxToPtFactor));
            }

            label_kasaraporudokumform_714180733.SetMarginBottom(0 * pxToPtFactor).SetMarginTop(0f);
            var label_kasaraporudokumform_714180733_paragraphHeight = label_kasaraporudokumform_714180733.GetHeightOfParagraph(document);
            var label_kasaraporudokumform_714180733_vAlignOffset = 0f;
            label_kasaraporudokumform_714180733_vAlignOffset = Math.Max(0f, (20f * pxToPtFactor - label_kasaraporudokumform_714180733_paragraphHeight) / 2f);
            label_kasaraporudokumform_714180733.SetMarginLeft(0 * pxToPtFactor)
            .SetMarginTop((0 * pxToPtFactor) + label_kasaraporudokumform_714180733_vAlignOffset).SetMarginRight(0 * pxToPtFactor)
            .SetFontColor(new DeviceRgb(255, 255, 255), 1f)
            .SetVisible(true);
            
            if (false)
			{
				Paragraph label_kasaraporudokumform_714180733_inside = new Paragraph(@"Satış Siparişleri")
			   .SetFontSize(15 * pxToPtFactor)
               .SetFont(fontDictionary["poppins_bold"])
			   .WithGlyphFallback(fontDictionary, "poppins_bold", () => cjkFallbackFont.Value)
			   .SetFontColor(new DeviceRgb(255, 255, 255), 1f)
			   
			   .SetRotationAngle(0);
				label_kasaraporudokumform_714180733.Add(label_kasaraporudokumform_714180733_inside);
			}
            var label_kasaraporudokumform_714180733_renderHeight = 20f * pxToPtFactor > 0 ? 20f * pxToPtFactor : label_kasaraporudokumform_714180733_paragraphHeight;
            // Actual div height accounts for paragraph margins that may expand the Div beyond MinHeight
            // paragraphHeight was measured with MarginTop=0, but actual MarginTop = paddingTop + vAlignOffset
            var label_kasaraporudokumform_714180733_divHeight = Math.Max(label_kasaraporudokumform_714180733_renderHeight, label_kasaraporudokumform_714180733_paragraphHeight + (0 * pxToPtFactor) + label_kasaraporudokumform_714180733_vAlignOffset);
            var div_label_kasaraporudokumform_714180733 = new Div();
            div_label_kasaraporudokumform_714180733.SetMinHeight(label_kasaraporudokumform_714180733_renderHeight);
            div_label_kasaraporudokumform_714180733.SetBackgroundColor(new DeviceRgb(0, 0, 0), 0f);
            div_label_kasaraporudokumform_714180733.SetBorderBottom(Border.NO_BORDER);
            div_label_kasaraporudokumform_714180733.SetBorderTop(Border.NO_BORDER);
            div_label_kasaraporudokumform_714180733.SetBorderRight(Border.NO_BORDER);
            div_label_kasaraporudokumform_714180733.SetBorderLeft(Border.NO_BORDER);
            div_label_kasaraporudokumform_714180733.SetBorderRadius(new BorderRadius(0f * pxToPtFactor));
            div_label_kasaraporudokumform_714180733.Add(label_kasaraporudokumform_714180733);
            
            // Label/Icon inside Box: use box page coordinates for absolute positioning
            var label_kasaraporudokumform_714180733_yPos = box_kasaraporudokumform_1456958834_pageTopY - (0f * pxToPtFactor) - label_kasaraporudokumform_714180733_divHeight;
            div_label_kasaraporudokumform_714180733.SetFixedPosition((float)(box_kasaraporudokumform_1456958834_pageLeftX + (0f * pxToPtFactor)), (float)label_kasaraporudokumform_714180733_yPos, label_kasaraporudokumform_714180733_effectiveWidth);
            div_label_kasaraporudokumform_714180733.SetVisible(true);
            box_kasaraporudokumform_1456958834_deferredAdds.Add(div_label_kasaraporudokumform_714180733);

            kasaraporudokumform_1456958834_cell.SetVisible(box_kasaraporudokumform_1456958834.IsVisible());
            box_kasaraporudokumform_1456958834.AddCell(kasaraporudokumform_1456958834_cell);
            
            // Draw rounded rectangle with PdfCanvas for border-radius support
            {
                var boxX = 10f * pxToPtFactor;
                var boxAbsY = Math.Abs(170f * pxToPtFactor);
                var boxPageRelY = boxAbsY - pageStartY;
                var boxY = ((currentPageHeight > 0 ? currentPageHeight : canvasHeight.Value) - (boxPageRelY + Math.Abs(30f * pxToPtFactor)));
                var boxW = 790f * pxToPtFactor;
                var boxH = 30f * pxToPtFactor;
                var boxRadiusTL = 6f * pxToPtFactor;
                var boxRadiusTR = 6f * pxToPtFactor;
                var boxRadiusBR = 6f * pxToPtFactor;
                var boxRadiusBL = 6f * pxToPtFactor;
                float kappaTL = boxRadiusTL * 0.5522848f;
                float kappaTR = boxRadiusTR * 0.5522848f;
                float kappaBR = boxRadiusBR * 0.5522848f;
                float kappaBL = boxRadiusBL * 0.5522848f;
                var currentPage = pdf.GetPage(pdf.GetNumberOfPages());
                var pdfCanvas = new PdfCanvas(currentPage);

                // Draw rounded background with alpha support
                pdfCanvas.SaveState();
                pdfCanvas.SetExtGState(new PdfExtGState().SetFillOpacity(1f));
                pdfCanvas.SetFillColor(new DeviceRgb(114, 194, 64));
                pdfCanvas.MoveTo(boxX + boxRadiusBL, boxY);
                pdfCanvas.LineTo(boxX + boxW - boxRadiusBR, boxY);
                if (boxRadiusBR > 0) pdfCanvas.CurveTo(boxX + boxW - boxRadiusBR + kappaBR, boxY, boxX + boxW, boxY + boxRadiusBR - kappaBR, boxX + boxW, boxY + boxRadiusBR);
                pdfCanvas.LineTo(boxX + boxW, boxY + boxH - boxRadiusTR);
                if (boxRadiusTR > 0) pdfCanvas.CurveTo(boxX + boxW, boxY + boxH - boxRadiusTR + kappaTR, boxX + boxW - boxRadiusTR + kappaTR, boxY + boxH, boxX + boxW - boxRadiusTR, boxY + boxH);
                pdfCanvas.LineTo(boxX + boxRadiusTL, boxY + boxH);
                if (boxRadiusTL > 0) pdfCanvas.CurveTo(boxX + boxRadiusTL - kappaTL, boxY + boxH, boxX, boxY + boxH - boxRadiusTL + kappaTL, boxX, boxY + boxH - boxRadiusTL);
                pdfCanvas.LineTo(boxX, boxY + boxRadiusBL);
                if (boxRadiusBL > 0) pdfCanvas.CurveTo(boxX, boxY + boxRadiusBL - kappaBL, boxX + boxRadiusBL - kappaBL, boxY, boxX + boxRadiusBL, boxY);
                pdfCanvas.ClosePath();
                pdfCanvas.Fill();
                pdfCanvas.RestoreState();

                // Draw individual border edges with per-side widths
                var rrBorderColor = new DeviceRgb(114, 194, 64);
                float rrBorderTop = 1f * pxToPtFactor;
                float rrBorderRight = 1f * pxToPtFactor;
                float rrBorderBottom = 1f * pxToPtFactor;
                float rrBorderLeft = 1f * pxToPtFactor;

                // Top border (uses TL and TR corners)
                if (rrBorderTop > 0)
                {
                    pdfCanvas.SaveState();
                    pdfCanvas.SetExtGState(new PdfExtGState().SetStrokeOpacity(1f));
                    pdfCanvas.SetStrokeColor(rrBorderColor);
                    pdfCanvas.SetLineWidth(rrBorderTop);
                    pdfCanvas.MoveTo(boxX + boxRadiusTL, boxY + boxH);
                    pdfCanvas.LineTo(boxX + boxW - boxRadiusTR, boxY + boxH);
                    if (boxRadiusTR > 0) pdfCanvas.CurveTo(boxX + boxW - boxRadiusTR + kappaTR, boxY + boxH, boxX + boxW, boxY + boxH - boxRadiusTR + kappaTR, boxX + boxW, boxY + boxH - boxRadiusTR);
                    pdfCanvas.Stroke();
                    pdfCanvas.RestoreState();
                }

                // Right border (uses TR and BR corners)
                if (rrBorderRight > 0)
                {
                    pdfCanvas.SaveState();
                    pdfCanvas.SetExtGState(new PdfExtGState().SetStrokeOpacity(1f));
                    pdfCanvas.SetStrokeColor(rrBorderColor);
                    pdfCanvas.SetLineWidth(rrBorderRight);
                    pdfCanvas.MoveTo(boxX + boxW, boxY + boxH - boxRadiusTR);
                    pdfCanvas.LineTo(boxX + boxW, boxY + boxRadiusBR);
                    if (boxRadiusBR > 0) pdfCanvas.CurveTo(boxX + boxW, boxY + boxRadiusBR - kappaBR, boxX + boxW - boxRadiusBR + kappaBR, boxY, boxX + boxW - boxRadiusBR, boxY);
                    pdfCanvas.Stroke();
                    pdfCanvas.RestoreState();
                }

                // Bottom border (uses BR and BL corners)
                if (rrBorderBottom > 0)
                {
                    pdfCanvas.SaveState();
                    pdfCanvas.SetExtGState(new PdfExtGState().SetStrokeOpacity(1f));
                    pdfCanvas.SetStrokeColor(rrBorderColor);
                    pdfCanvas.SetLineWidth(rrBorderBottom);
                    pdfCanvas.MoveTo(boxX + boxW - boxRadiusBR, boxY);
                    pdfCanvas.LineTo(boxX + boxRadiusBL, boxY);
                    if (boxRadiusBL > 0) pdfCanvas.CurveTo(boxX + boxRadiusBL - kappaBL, boxY, boxX, boxY + boxRadiusBL - kappaBL, boxX, boxY + boxRadiusBL);
                    pdfCanvas.Stroke();
                    pdfCanvas.RestoreState();
                }

                // Left border (uses BL and TL corners)
                if (rrBorderLeft > 0)
                {
                    pdfCanvas.SaveState();
                    pdfCanvas.SetExtGState(new PdfExtGState().SetStrokeOpacity(1f));
                    pdfCanvas.SetStrokeColor(rrBorderColor);
                    pdfCanvas.SetLineWidth(rrBorderLeft);
                    pdfCanvas.MoveTo(boxX, boxY + boxRadiusBL);
                    pdfCanvas.LineTo(boxX, boxY + boxH - boxRadiusTL);
                    if (boxRadiusTL > 0) pdfCanvas.CurveTo(boxX, boxY + boxH - boxRadiusTL + kappaTL, boxX + boxRadiusTL - kappaTL, boxY + boxH, boxX + boxRadiusTL, boxY + boxH);
                    pdfCanvas.Stroke();
                    pdfCanvas.RestoreState();
                }
            }
            document.Add(box_kasaraporudokumform_1456958834);
            foreach (var deferredElem in box_kasaraporudokumform_1456958834_deferredAdds) document.Add(deferredElem);
            }}


            //Box4
            Table box_kasaraporudokumform_16424345 = new Table(1).SetWidth(780f * pxToPtFactor).SetHeight(218f * pxToPtFactor)
            .SetFontColor(new DeviceRgb(0, 0, 0), 1f)
            .SetFontSize(20 * pxToPtFactor)
            .SetVisible(true);
            if (box_kasaraporudokumform_16424345.IsVisible()) {{
            var box_kasaraporudokumform_16424345_pageLeftX = (double)(10f * pxToPtFactor) ;
            var box_kasaraporudokumform_16424345_pageTopY = 0d;
            var box_kasaraporudokumform_16424345_deferredAdds = new List<IBlockElement>();
            if (!false) {
            // Calculate page-relative Y position
            var box_kasaraporudokumform_16424345_absoluteY = Math.Abs(460f * pxToPtFactor);
            var box_kasaraporudokumform_16424345_pageRelativeY = box_kasaraporudokumform_16424345_absoluteY - pageStartY;
            int box_kasaraporudokumform_16424345_targetPage = pdf.GetNumberOfPages();
            
            box_kasaraporudokumform_16424345.SetFixedPosition(box_kasaraporudokumform_16424345_targetPage, 10f * pxToPtFactor , ((currentPageHeight > 0 ? currentPageHeight : canvasHeight.Value) - (box_kasaraporudokumform_16424345_pageRelativeY + Math.Abs(218f * pxToPtFactor))) , 780f * pxToPtFactor);
            box_kasaraporudokumform_16424345_pageTopY = ((double)(currentPageHeight > 0 ? currentPageHeight : canvasHeight.Value) - box_kasaraporudokumform_16424345_pageRelativeY) ;
            } else {
            box_kasaraporudokumform_16424345.SetFixedPosition(10f * pxToPtFactor , ((currentPageHeight > 0 ? currentPageHeight : canvasHeight.Value) - (totalHeight + Math.Abs(460f * pxToPtFactor) + Math.Abs(218f * pxToPtFactor))) , 780f * pxToPtFactor);
            box_kasaraporudokumform_16424345_pageTopY = ((double)(currentPageHeight > 0 ? currentPageHeight : canvasHeight.Value) - (totalHeight + Math.Abs(460f * pxToPtFactor))) ;
            }
            box_kasaraporudokumform_16424345.SetBorder(Border.NO_BORDER);
            box_kasaraporudokumform_16424345.SetBorderBottom(Border.NO_BORDER);
            box_kasaraporudokumform_16424345.SetBorderTop(Border.NO_BORDER);
            box_kasaraporudokumform_16424345.SetBorderRight(Border.NO_BORDER);
            box_kasaraporudokumform_16424345.SetBorderLeft(Border.NO_BORDER);
            box_kasaraporudokumform_16424345.SetBorderRadius(new BorderRadius(6f * pxToPtFactor));
            var heightOf_box_kasaraporudokumform_16424345 = box_kasaraporudokumform_16424345.GetHeight();
            Cell kasaraporudokumform_16424345_cell = new Cell();
            kasaraporudokumform_16424345_cell.SetBackgroundColor(new DeviceRgb(255, 255, 255), 0f);
            kasaraporudokumform_16424345_cell.SetBorder(Border.NO_BORDER);
            
            // NOTE: Box always uses SetFixedPosition above (both branches), so it does not
            // contribute to flow. The legacy "totalHeight + height > canvasHeight" areaBreak
            // that lived here was reading totalHeight produced by previous flow elements
            // (e.g. multi-page ReportTables) and spuriously creating a new page + bumping
            // pageStartY, which broke pageRelativeY for every subsequent element. Removed.

            // No page breaks - using default canvas height behavior


            //ReportTable2
            
            var kasaraporudokumform_1142931966IsVisible = true;
            var kasaraporudokumform_1142931966BackgroundColor = new DeviceRgb(0, 0, 0);
            var kasaraporudokumform_1142931966BackgroundColorOpacity = 0f;
            var widths_kasaraporudokumform_1142931966 = new List<float>();
widths_kasaraporudokumform_1142931966.Add(90.71f * pxToPtFactor);
widths_kasaraporudokumform_1142931966.Add(86.93f * pxToPtFactor);
widths_kasaraporudokumform_1142931966.Add(139.84f * pxToPtFactor);
widths_kasaraporudokumform_1142931966.Add(75.59f * pxToPtFactor);
widths_kasaraporudokumform_1142931966.Add(37.8f * pxToPtFactor);
widths_kasaraporudokumform_1142931966.Add(68.03f * pxToPtFactor);
widths_kasaraporudokumform_1142931966.Add(37.8f * pxToPtFactor);
widths_kasaraporudokumform_1142931966.Add(79.37007874015748f * pxToPtFactor);
widths_kasaraporudokumform_1142931966.Add(102.05f * pxToPtFactor);
var designWidth_kasaraporudokumform_1142931966 = 718.11f * pxToPtFactor;
var tableWidth_kasaraporudokumform_1142931966 = (widths_kasaraporudokumform_1142931966.Sum() / designWidth_kasaraporudokumform_1142931966) * (718.11f * pxToPtFactor);

            Table kasaraporudokumform_1142931966 = new Table(widths_kasaraporudokumform_1142931966.ToArray()).SetWidth(tableWidth_kasaraporudokumform_1142931966)
            .SetBackgroundColor(kasaraporudokumform_1142931966BackgroundColor, kasaraporudokumform_1142931966BackgroundColorOpacity)
            .SetVisible(kasaraporudokumform_1142931966IsVisible)
            .SetMarginBottom(0 * pxToPtFactor)
            .SetMarginLeft(0 * pxToPtFactor)
            .SetMarginTop(0 * pxToPtFactor)
            .SetMarginRight(0 * pxToPtFactor);
            
            kasaraporudokumform_1142931966.SetBorderBottom(new SolidBorder(new DeviceRgb(218, 218, 218), 1 * pxToPtFactor, 1f));
            kasaraporudokumform_1142931966.SetBorderTop(new SolidBorder(new DeviceRgb(218, 218, 218), 1 * pxToPtFactor, 1f));
            kasaraporudokumform_1142931966.SetBorderRight(new SolidBorder(new DeviceRgb(218, 218, 218), 1 * pxToPtFactor, 1f));
            kasaraporudokumform_1142931966.SetBorderLeft(new SolidBorder(new DeviceRgb(218, 218, 218), 1 * pxToPtFactor, 1f));
            kasaraporudokumform_1142931966.SetBorderRadius(new BorderRadius(0f * pxToPtFactor));
            kasaraporudokumform_1142931966.SetFixedLayout();
            Color kasaraporudokumform_1142931966borderColor = new DeviceRgb(240, 240, 240);
            Border kasaraporudokumform_1142931966leftBorder = new SolidBorder(kasaraporudokumform_1142931966borderColor, 1 * pxToPtFactor);
            if (kasaraporudokumform_1142931966IsVisible)
            {
                
            List<String> columnValueNames_kasaraporudokumform_1142931966 = new List<String>() {"CurrAccDescription", "EInvoiceNumber", "ItemDescription", "ÜrünSeriNumarası", "Doc_CurrencyCode", "Doc_NetAmount", "Doc_LDiscountVITotal", "Doc_NetAmount", "Loc_NetAmount"};
            
            var kasaraporudokumform_1142931966_ColumTitlesPropValue = "";
            var kasaraporudokumform_1142931966_ColumnTitles = new List<string>();
            if(kasaraporudokumform_1142931966_ColumTitlesPropValue != null) {
               kasaraporudokumform_1142931966_ColumnTitles = kasaraporudokumform_1142931966_ColumTitlesPropValue.ToString()?.Split(";", StringSplitOptions.RemoveEmptyEntries).ToList();
            }
        
            
            Cell cell_0 = new Cell(1, 1);
            //cell_0.SetBorder(iText.Layout.Borders.Border.NO_BORDER)
            cell_0.SetBackgroundColor(new DeviceRgb(0, 0, 0), 0f);
            cell_0.SetBorderBottom(Border.NO_BORDER);
            cell_0.SetBorderTop(Border.NO_BORDER);
            cell_0.SetBorderRight(Border.NO_BORDER);
            cell_0.SetBorderLeft(Border.NO_BORDER);
            cell_0.SetBorderRadius(new BorderRadius(0f * pxToPtFactor));
            
            
            cell_0.SetPaddingBottom(0 * pxToPtFactor).SetPaddingLeft(0 * pxToPtFactor)
            .SetPaddingTop(0 * pxToPtFactor).SetPaddingRight(0 * pxToPtFactor).SetFontSize(14 * pxToPtFactor)
            .SetFont(fontDictionary["poppins_regular"]).SetFontColor(new DeviceRgb(155, 155, 155), 1f)
            .SetTextAlignment(iText.Layout.Properties.TextAlignment.LEFT);
            var headerParagraph_0 = new Paragraph((kasaraporudokumform_1142931966_ColumnTitles is { Count: >= (0 + 1) } ? kasaraporudokumform_1142931966_ColumnTitles[0] : kasaraporudokumform_1142931966_ColumnTitles.Any() ? "" : ("Müşteri Adı".ConvertToType<String>())))
            
            .WithGlyphFallback(fontDictionary, "poppins_regular", () => cjkFallbackFont.Value);
            cell_0.Add(headerParagraph_0);
            
            cell_0.SetVisible(true);
            kasaraporudokumform_1142931966.AddHeaderCell(cell_0);


            Cell cell_1 = new Cell(1, 1);
            //cell_1.SetBorder(iText.Layout.Borders.Border.NO_BORDER)
            cell_1.SetBackgroundColor(new DeviceRgb(0, 0, 0), 0f);
            cell_1.SetBorderBottom(Border.NO_BORDER);
            cell_1.SetBorderTop(Border.NO_BORDER);
            cell_1.SetBorderRight(Border.NO_BORDER);
            cell_1.SetBorderLeft(Border.NO_BORDER);
            cell_1.SetBorderRadius(new BorderRadius(0f * pxToPtFactor));
            
            if(true){cell_1.SetBorderLeft(kasaraporudokumform_1142931966leftBorder);}
            cell_1.SetPaddingBottom(0 * pxToPtFactor).SetPaddingLeft(0 * pxToPtFactor)
            .SetPaddingTop(0 * pxToPtFactor).SetPaddingRight(0 * pxToPtFactor).SetFontSize(14 * pxToPtFactor)
            .SetFont(fontDictionary["poppins_regular"]).SetFontColor(new DeviceRgb(155, 155, 155), 1f)
            .SetTextAlignment(iText.Layout.Properties.TextAlignment.LEFT);
            var headerParagraph_1 = new Paragraph((kasaraporudokumform_1142931966_ColumnTitles is { Count: >= (1 + 1) } ? kasaraporudokumform_1142931966_ColumnTitles[1] : kasaraporudokumform_1142931966_ColumnTitles.Any() ? "" : ("E-Fatura Numarası".ConvertToType<String>())))
            
            .WithGlyphFallback(fontDictionary, "poppins_regular", () => cjkFallbackFont.Value);
            cell_1.Add(headerParagraph_1);
            
            cell_1.SetVisible(true);
            kasaraporudokumform_1142931966.AddHeaderCell(cell_1);


            Cell cell_2 = new Cell(1, 1);
            //cell_2.SetBorder(iText.Layout.Borders.Border.NO_BORDER)
            cell_2.SetBackgroundColor(new DeviceRgb(0, 0, 0), 0f);
            cell_2.SetBorderBottom(Border.NO_BORDER);
            cell_2.SetBorderTop(Border.NO_BORDER);
            cell_2.SetBorderRight(Border.NO_BORDER);
            cell_2.SetBorderLeft(Border.NO_BORDER);
            cell_2.SetBorderRadius(new BorderRadius(0f * pxToPtFactor));
            
            if(true){cell_2.SetBorderLeft(kasaraporudokumform_1142931966leftBorder);}
            cell_2.SetPaddingBottom(0 * pxToPtFactor).SetPaddingLeft(0 * pxToPtFactor)
            .SetPaddingTop(0 * pxToPtFactor).SetPaddingRight(0 * pxToPtFactor).SetFontSize(14 * pxToPtFactor)
            .SetFont(fontDictionary["poppins_regular"]).SetFontColor(new DeviceRgb(155, 155, 155), 1f)
            .SetTextAlignment(iText.Layout.Properties.TextAlignment.LEFT);
            var headerParagraph_2 = new Paragraph((kasaraporudokumform_1142931966_ColumnTitles is { Count: >= (2 + 1) } ? kasaraporudokumform_1142931966_ColumnTitles[2] : kasaraporudokumform_1142931966_ColumnTitles.Any() ? "" : ("Ürün Adı".ConvertToType<String>())))
            
            .WithGlyphFallback(fontDictionary, "poppins_regular", () => cjkFallbackFont.Value);
            cell_2.Add(headerParagraph_2);
            
            cell_2.SetVisible(true);
            kasaraporudokumform_1142931966.AddHeaderCell(cell_2);


            Cell cell_3 = new Cell(1, 1);
            //cell_3.SetBorder(iText.Layout.Borders.Border.NO_BORDER)
            cell_3.SetBackgroundColor(new DeviceRgb(0, 0, 0), 0f);
            cell_3.SetBorderBottom(Border.NO_BORDER);
            cell_3.SetBorderTop(Border.NO_BORDER);
            cell_3.SetBorderRight(Border.NO_BORDER);
            cell_3.SetBorderLeft(Border.NO_BORDER);
            cell_3.SetBorderRadius(new BorderRadius(0f * pxToPtFactor));
            
            if(true){cell_3.SetBorderLeft(kasaraporudokumform_1142931966leftBorder);}
            cell_3.SetPaddingBottom(0 * pxToPtFactor).SetPaddingLeft(0 * pxToPtFactor)
            .SetPaddingTop(0 * pxToPtFactor).SetPaddingRight(0 * pxToPtFactor).SetFontSize(14 * pxToPtFactor)
            .SetFont(fontDictionary["poppins_regular"]).SetFontColor(new DeviceRgb(155, 155, 155), 1f)
            .SetTextAlignment(iText.Layout.Properties.TextAlignment.LEFT);
            var headerParagraph_3 = new Paragraph((kasaraporudokumform_1142931966_ColumnTitles is { Count: >= (3 + 1) } ? kasaraporudokumform_1142931966_ColumnTitles[3] : kasaraporudokumform_1142931966_ColumnTitles.Any() ? "" : ("Seri Numarası".ConvertToType<String>())))
            
            .WithGlyphFallback(fontDictionary, "poppins_regular", () => cjkFallbackFont.Value);
            cell_3.Add(headerParagraph_3);
            
            cell_3.SetVisible(true);
            kasaraporudokumform_1142931966.AddHeaderCell(cell_3);


            Cell cell_4 = new Cell(1, 1);
            //cell_4.SetBorder(iText.Layout.Borders.Border.NO_BORDER)
            cell_4.SetBackgroundColor(new DeviceRgb(0, 0, 0), 0f);
            cell_4.SetBorderBottom(Border.NO_BORDER);
            cell_4.SetBorderTop(Border.NO_BORDER);
            cell_4.SetBorderRight(Border.NO_BORDER);
            cell_4.SetBorderLeft(Border.NO_BORDER);
            cell_4.SetBorderRadius(new BorderRadius(0f * pxToPtFactor));
            
            if(true){cell_4.SetBorderLeft(kasaraporudokumform_1142931966leftBorder);}
            cell_4.SetPaddingBottom(0 * pxToPtFactor).SetPaddingLeft(0 * pxToPtFactor)
            .SetPaddingTop(0 * pxToPtFactor).SetPaddingRight(0 * pxToPtFactor).SetFontSize(14 * pxToPtFactor)
            .SetFont(fontDictionary["poppins_regular"]).SetFontColor(new DeviceRgb(155, 155, 155), 1f)
            .SetTextAlignment(iText.Layout.Properties.TextAlignment.LEFT);
            var headerParagraph_4 = new Paragraph((kasaraporudokumform_1142931966_ColumnTitles is { Count: >= (4 + 1) } ? kasaraporudokumform_1142931966_ColumnTitles[4] : kasaraporudokumform_1142931966_ColumnTitles.Any() ? "" : ("DVZ".ConvertToType<String>())))
            
            .WithGlyphFallback(fontDictionary, "poppins_regular", () => cjkFallbackFont.Value);
            cell_4.Add(headerParagraph_4);
            
            cell_4.SetVisible(true);
            kasaraporudokumform_1142931966.AddHeaderCell(cell_4);


            Cell cell_5 = new Cell(1, 1);
            //cell_5.SetBorder(iText.Layout.Borders.Border.NO_BORDER)
            cell_5.SetBackgroundColor(new DeviceRgb(0, 0, 0), 0f);
            cell_5.SetBorderBottom(Border.NO_BORDER);
            cell_5.SetBorderTop(Border.NO_BORDER);
            cell_5.SetBorderRight(Border.NO_BORDER);
            cell_5.SetBorderLeft(Border.NO_BORDER);
            cell_5.SetBorderRadius(new BorderRadius(0f * pxToPtFactor));
            
            if(true){cell_5.SetBorderLeft(kasaraporudokumform_1142931966leftBorder);}
            cell_5.SetPaddingBottom(0 * pxToPtFactor).SetPaddingLeft(0 * pxToPtFactor)
            .SetPaddingTop(0 * pxToPtFactor).SetPaddingRight(0 * pxToPtFactor).SetFontSize(14 * pxToPtFactor)
            .SetFont(fontDictionary["poppins_regular"]).SetFontColor(new DeviceRgb(155, 155, 155), 1f)
            .SetTextAlignment(iText.Layout.Properties.TextAlignment.LEFT);
            var headerParagraph_5 = new Paragraph((kasaraporudokumform_1142931966_ColumnTitles is { Count: >= (5 + 1) } ? kasaraporudokumform_1142931966_ColumnTitles[5] : kasaraporudokumform_1142931966_ColumnTitles.Any() ? "" : ("Liste Fiyatı".ConvertToType<String>())))
            
            .WithGlyphFallback(fontDictionary, "poppins_regular", () => cjkFallbackFont.Value);
            cell_5.Add(headerParagraph_5);
            
            cell_5.SetVisible(true);
            kasaraporudokumform_1142931966.AddHeaderCell(cell_5);


            Cell cell_6 = new Cell(1, 1);
            //cell_6.SetBorder(iText.Layout.Borders.Border.NO_BORDER)
            cell_6.SetBackgroundColor(new DeviceRgb(0, 0, 0), 0f);
            cell_6.SetBorderBottom(Border.NO_BORDER);
            cell_6.SetBorderTop(Border.NO_BORDER);
            cell_6.SetBorderRight(Border.NO_BORDER);
            cell_6.SetBorderLeft(Border.NO_BORDER);
            cell_6.SetBorderRadius(new BorderRadius(0f * pxToPtFactor));
            
            if(true){cell_6.SetBorderLeft(kasaraporudokumform_1142931966leftBorder);}
            cell_6.SetPaddingBottom(0 * pxToPtFactor).SetPaddingLeft(0 * pxToPtFactor)
            .SetPaddingTop(0 * pxToPtFactor).SetPaddingRight(0 * pxToPtFactor).SetFontSize(14 * pxToPtFactor)
            .SetFont(fontDictionary["poppins_regular"]).SetFontColor(new DeviceRgb(155, 155, 155), 1f)
            .SetTextAlignment(iText.Layout.Properties.TextAlignment.LEFT);
            var headerParagraph_6 = new Paragraph((kasaraporudokumform_1142931966_ColumnTitles is { Count: >= (6 + 1) } ? kasaraporudokumform_1142931966_ColumnTitles[6] : kasaraporudokumform_1142931966_ColumnTitles.Any() ? "" : ("%".ConvertToType<String>())))
            
            .WithGlyphFallback(fontDictionary, "poppins_regular", () => cjkFallbackFont.Value);
            cell_6.Add(headerParagraph_6);
            
            cell_6.SetVisible(true);
            kasaraporudokumform_1142931966.AddHeaderCell(cell_6);


            Cell cell_7 = new Cell(1, 1);
            //cell_7.SetBorder(iText.Layout.Borders.Border.NO_BORDER)
            cell_7.SetBackgroundColor(new DeviceRgb(0, 0, 0), 0f);
            cell_7.SetBorderBottom(Border.NO_BORDER);
            cell_7.SetBorderTop(Border.NO_BORDER);
            cell_7.SetBorderRight(Border.NO_BORDER);
            cell_7.SetBorderLeft(Border.NO_BORDER);
            cell_7.SetBorderRadius(new BorderRadius(0f * pxToPtFactor));
            
            if(true){cell_7.SetBorderLeft(kasaraporudokumform_1142931966leftBorder);}
            cell_7.SetPaddingBottom(0 * pxToPtFactor).SetPaddingLeft(0 * pxToPtFactor)
            .SetPaddingTop(0 * pxToPtFactor).SetPaddingRight(0 * pxToPtFactor).SetFontSize(14 * pxToPtFactor)
            .SetFont(fontDictionary["poppins_regular"]).SetFontColor(new DeviceRgb(155, 155, 155), 1f)
            .SetTextAlignment(iText.Layout.Properties.TextAlignment.LEFT);
            var headerParagraph_7 = new Paragraph((kasaraporudokumform_1142931966_ColumnTitles is { Count: >= (7 + 1) } ? kasaraporudokumform_1142931966_ColumnTitles[7] : kasaraporudokumform_1142931966_ColumnTitles.Any() ? "" : ("Tutar".ConvertToType<String>())))
            
            .WithGlyphFallback(fontDictionary, "poppins_regular", () => cjkFallbackFont.Value);
            cell_7.Add(headerParagraph_7);
            
            cell_7.SetVisible(true);
            kasaraporudokumform_1142931966.AddHeaderCell(cell_7);


            Cell cell_8 = new Cell(1, 1);
            //cell_8.SetBorder(iText.Layout.Borders.Border.NO_BORDER)
            cell_8.SetBackgroundColor(new DeviceRgb(0, 0, 0), 0f);
            cell_8.SetBorderBottom(Border.NO_BORDER);
            cell_8.SetBorderTop(Border.NO_BORDER);
            cell_8.SetBorderRight(Border.NO_BORDER);
            cell_8.SetBorderLeft(Border.NO_BORDER);
            cell_8.SetBorderRadius(new BorderRadius(0f * pxToPtFactor));
            
            if(true){cell_8.SetBorderLeft(kasaraporudokumform_1142931966leftBorder);}
            cell_8.SetPaddingBottom(0 * pxToPtFactor).SetPaddingLeft(0 * pxToPtFactor)
            .SetPaddingTop(0 * pxToPtFactor).SetPaddingRight(0 * pxToPtFactor).SetFontSize(14 * pxToPtFactor)
            .SetFont(fontDictionary["poppins_regular"]).SetFontColor(new DeviceRgb(155, 155, 155), 1f)
            .SetTextAlignment(iText.Layout.Properties.TextAlignment.LEFT);
            var headerParagraph_8 = new Paragraph((kasaraporudokumform_1142931966_ColumnTitles is { Count: >= (8 + 1) } ? kasaraporudokumform_1142931966_ColumnTitles[8] : kasaraporudokumform_1142931966_ColumnTitles.Any() ? "" : ("Tutar TRY".ConvertToType<String>())))
            
            .WithGlyphFallback(fontDictionary, "poppins_regular", () => cjkFallbackFont.Value);
            cell_8.Add(headerParagraph_8);
            
            cell_8.SetVisible(true);
            kasaraporudokumform_1142931966.AddHeaderCell(cell_8);


            
            var rowBackgroundColor = new DeviceRgb(0, 0, 0);
            var rowOpacity = 0;
            var isStriped = false;
            Color stripedColor = new DeviceRgb(245, 247, 250);
            for(int i = 0; i < result.Kuika_KasaRaporuSatisSiparisleri1.Count; i++)
              {
                  var item = result.Kuika_KasaRaporuSatisSiparisleri1[i];
                  Color backgroundColor = new DeviceRgb(255, 255, 255);
                  float backgroundColorOpacity = 0f;

                  if (kasaraporudokumform_1142931966BackgroundColorOpacity == 1) {{
                        backgroundColor = kasaraporudokumform_1142931966BackgroundColor;
                        backgroundColorOpacity = 1f;
                  }}

                  if (rowOpacity == 1) {{
                        backgroundColor = rowBackgroundColor;
                        backgroundColorOpacity = 1f;
                  }}

                  if (isStriped && i % 2 != 0) {{
                        backgroundColor = stripedColor;
                        backgroundColorOpacity = 1f;
                  }}

                  
                
            var colData_0103366484 = new Paragraph(item.CurrAccDescription.ToFormattedString("", "", "") ?? "")
            .SetMarginBottom(0 * pxToPtFactor).SetMarginLeft(0 * pxToPtFactor)
            .SetMarginTop(0 * pxToPtFactor).SetMarginRight(0 * pxToPtFactor)
            .SetFontColor(new DeviceRgb(68, 68, 68), 1f)
            .SetBackgroundColor(new DeviceRgb(0, 0, 0), 0f)
            .SetFontSize(12 * pxToPtFactor)
            .SetFont(fontDictionary["poppins_regular"])
            .WithGlyphFallback(fontDictionary, "poppins_regular", () => cjkFallbackFont.Value)
            
            .SetParagraphWidthAndExtendHeightIfNotFit(document, 31.57f * pxToPtFactor, 20f * pxToPtFactor, true)
            .SetVisible(true)
            .SetVerticalAlignment(VerticalAlignment.TOP)
            .SetHorizontalAlignment(HorizontalAlignment.LEFT)
            .SetTextAlignment(TextAlignment.LEFT)
            .SetMultipliedLeading(1f);
            
colData_0103366484.SetVisible(true);

                Cell cell_103366484 = new Cell(1, 1);
                var cell_103366484BackgroundColor = new DeviceRgb(0, 0, 0);
                var cell_103366484BackgroundColorOpacity = 0;
                
                cell_103366484.SetMinHeight(40 * pxToPtFactor);
                //cell_103366484.SetBorder(iText.Layout.Borders.Border.NO_BORDER);
                cell_103366484.SetBorderBottom(Border.NO_BORDER);
                cell_103366484.SetBorderTop(Border.NO_BORDER);
                cell_103366484.SetBorderRight(Border.NO_BORDER);
                cell_103366484.SetBorderLeft(Border.NO_BORDER);
                cell_103366484.SetBorderRadius(new BorderRadius(0f * pxToPtFactor));
                //cell_103366484.Add(colData_103366484);
                if (cell_103366484BackgroundColorOpacity == 1)
                    cell_103366484.SetBackgroundColor(cell_103366484BackgroundColor);
                else if (backgroundColorOpacity == 1)
                    cell_103366484.SetBackgroundColor(backgroundColor);
                cell_103366484.SetVerticalAlignment(iText.Layout.Properties.VerticalAlignment.TOP);
                cell_103366484.SetTextAlignment(iText.Layout.Properties.TextAlignment.LEFT);
                cell_103366484.SetPaddingBottom(0 * pxToPtFactor).SetPaddingLeft(0 * pxToPtFactor)
                .SetPaddingTop(0 * pxToPtFactor).SetPaddingRight(0 * pxToPtFactor);
                
                kasaraporudokumform_1142931966.AddCell(cell_103366484);

cell_103366484.Add(colData_0103366484);

                
            var colData_01128039060 = new Paragraph(item.EInvoiceNumber.ToFormattedString("", "", "") ?? "")
            .SetMarginBottom(0 * pxToPtFactor).SetMarginLeft(0 * pxToPtFactor)
            .SetMarginTop(0 * pxToPtFactor).SetMarginRight(0 * pxToPtFactor)
            .SetFontColor(new DeviceRgb(68, 68, 68), 1f)
            .SetBackgroundColor(new DeviceRgb(0, 0, 0), 0f)
            .SetFontSize(12 * pxToPtFactor)
            .SetFont(fontDictionary["poppins_regular"])
            .WithGlyphFallback(fontDictionary, "poppins_regular", () => cjkFallbackFont.Value)
            
            .SetParagraphWidthAndExtendHeightIfNotFit(document, 31.57f * pxToPtFactor, 20f * pxToPtFactor, true)
            .SetVisible(true)
            .SetVerticalAlignment(VerticalAlignment.TOP)
            .SetHorizontalAlignment(HorizontalAlignment.LEFT)
            .SetTextAlignment(TextAlignment.LEFT)
            .SetMultipliedLeading(1f);
            
colData_01128039060.SetVisible(true);

                Cell cell_1128039060 = new Cell(1, 1);
                var cell_1128039060BackgroundColor = new DeviceRgb(0, 0, 0);
                var cell_1128039060BackgroundColorOpacity = 0;
                
                cell_1128039060.SetMinHeight(40 * pxToPtFactor);
                //cell_1128039060.SetBorder(iText.Layout.Borders.Border.NO_BORDER);
                cell_1128039060.SetBorderBottom(Border.NO_BORDER);
                cell_1128039060.SetBorderTop(Border.NO_BORDER);
                cell_1128039060.SetBorderRight(Border.NO_BORDER);
                cell_1128039060.SetBorderLeft(Border.NO_BORDER);
                cell_1128039060.SetBorderRadius(new BorderRadius(0f * pxToPtFactor));
                //cell_1128039060.Add(colData_1128039060);
                if (cell_1128039060BackgroundColorOpacity == 1)
                    cell_1128039060.SetBackgroundColor(cell_1128039060BackgroundColor);
                else if (backgroundColorOpacity == 1)
                    cell_1128039060.SetBackgroundColor(backgroundColor);
                cell_1128039060.SetVerticalAlignment(iText.Layout.Properties.VerticalAlignment.TOP);
                cell_1128039060.SetTextAlignment(iText.Layout.Properties.TextAlignment.LEFT);
                cell_1128039060.SetPaddingBottom(0 * pxToPtFactor).SetPaddingLeft(0 * pxToPtFactor)
                .SetPaddingTop(0 * pxToPtFactor).SetPaddingRight(0 * pxToPtFactor);
                
                kasaraporudokumform_1142931966.AddCell(cell_1128039060);

cell_1128039060.Add(colData_01128039060);

                
            var colData_01518003240 = new Paragraph(item.ItemDescription.ToFormattedString("", "", "") ?? "")
            .SetMarginBottom(0 * pxToPtFactor).SetMarginLeft(0 * pxToPtFactor)
            .SetMarginTop(0 * pxToPtFactor).SetMarginRight(0 * pxToPtFactor)
            .SetFontColor(new DeviceRgb(68, 68, 68), 1f)
            .SetBackgroundColor(new DeviceRgb(0, 0, 0), 0f)
            .SetFontSize(12 * pxToPtFactor)
            .SetFont(fontDictionary["poppins_regular"])
            .WithGlyphFallback(fontDictionary, "poppins_regular", () => cjkFallbackFont.Value)
            
            .SetParagraphWidthAndExtendHeightIfNotFit(document, 25.2f * pxToPtFactor, 20f * pxToPtFactor, true)
            .SetVisible(true)
            .SetVerticalAlignment(VerticalAlignment.TOP)
            .SetHorizontalAlignment(HorizontalAlignment.LEFT)
            .SetTextAlignment(TextAlignment.LEFT)
            .SetMultipliedLeading(1f);
            
colData_01518003240.SetVisible(true);

                Cell cell_1518003240 = new Cell(1, 1);
                var cell_1518003240BackgroundColor = new DeviceRgb(0, 0, 0);
                var cell_1518003240BackgroundColorOpacity = 0;
                
                cell_1518003240.SetMinHeight(40 * pxToPtFactor);
                //cell_1518003240.SetBorder(iText.Layout.Borders.Border.NO_BORDER);
                cell_1518003240.SetBorderBottom(Border.NO_BORDER);
                cell_1518003240.SetBorderTop(Border.NO_BORDER);
                cell_1518003240.SetBorderRight(Border.NO_BORDER);
                cell_1518003240.SetBorderLeft(Border.NO_BORDER);
                cell_1518003240.SetBorderRadius(new BorderRadius(0f * pxToPtFactor));
                //cell_1518003240.Add(colData_1518003240);
                if (cell_1518003240BackgroundColorOpacity == 1)
                    cell_1518003240.SetBackgroundColor(cell_1518003240BackgroundColor);
                else if (backgroundColorOpacity == 1)
                    cell_1518003240.SetBackgroundColor(backgroundColor);
                cell_1518003240.SetVerticalAlignment(iText.Layout.Properties.VerticalAlignment.TOP);
                cell_1518003240.SetTextAlignment(iText.Layout.Properties.TextAlignment.LEFT);
                cell_1518003240.SetPaddingBottom(0 * pxToPtFactor).SetPaddingLeft(0 * pxToPtFactor)
                .SetPaddingTop(0 * pxToPtFactor).SetPaddingRight(0 * pxToPtFactor);
                
                kasaraporudokumform_1142931966.AddCell(cell_1518003240);

cell_1518003240.Add(colData_01518003240);

                
            var colData_0215937438 = new Paragraph(item.ÜrünSeriNumarası.ToFormattedString("", "", "") ?? "")
            .SetMarginBottom(0 * pxToPtFactor).SetMarginLeft(0 * pxToPtFactor)
            .SetMarginTop(0 * pxToPtFactor).SetMarginRight(0 * pxToPtFactor)
            .SetFontColor(new DeviceRgb(68, 68, 68), 1f)
            .SetBackgroundColor(new DeviceRgb(0, 0, 0), 0f)
            .SetFontSize(12 * pxToPtFactor)
            .SetFont(fontDictionary["poppins_regular"])
            .WithGlyphFallback(fontDictionary, "poppins_regular", () => cjkFallbackFont.Value)
            
            .SetParagraphWidthAndExtendHeightIfNotFit(document, 22.67f * pxToPtFactor, 20f * pxToPtFactor, true)
            .SetVisible(true)
            .SetVerticalAlignment(VerticalAlignment.TOP)
            .SetHorizontalAlignment(HorizontalAlignment.LEFT)
            .SetTextAlignment(TextAlignment.LEFT)
            .SetMultipliedLeading(1f);
            
colData_0215937438.SetVisible(true);

                Cell cell_215937438 = new Cell(1, 1);
                var cell_215937438BackgroundColor = new DeviceRgb(0, 0, 0);
                var cell_215937438BackgroundColorOpacity = 0;
                
                cell_215937438.SetMinHeight(40 * pxToPtFactor);
                //cell_215937438.SetBorder(iText.Layout.Borders.Border.NO_BORDER);
                cell_215937438.SetBorderBottom(Border.NO_BORDER);
                cell_215937438.SetBorderTop(Border.NO_BORDER);
                cell_215937438.SetBorderRight(Border.NO_BORDER);
                cell_215937438.SetBorderLeft(Border.NO_BORDER);
                cell_215937438.SetBorderRadius(new BorderRadius(0f * pxToPtFactor));
                //cell_215937438.Add(colData_215937438);
                if (cell_215937438BackgroundColorOpacity == 1)
                    cell_215937438.SetBackgroundColor(cell_215937438BackgroundColor);
                else if (backgroundColorOpacity == 1)
                    cell_215937438.SetBackgroundColor(backgroundColor);
                cell_215937438.SetVerticalAlignment(iText.Layout.Properties.VerticalAlignment.TOP);
                cell_215937438.SetTextAlignment(iText.Layout.Properties.TextAlignment.LEFT);
                cell_215937438.SetPaddingBottom(0 * pxToPtFactor).SetPaddingLeft(0 * pxToPtFactor)
                .SetPaddingTop(0 * pxToPtFactor).SetPaddingRight(0 * pxToPtFactor);
                
                kasaraporudokumform_1142931966.AddCell(cell_215937438);

cell_215937438.Add(colData_0215937438);

                
            var colData_013084380 = new Paragraph(item.Doc_CurrencyCode.ToFormattedString("", "", "") ?? "")
            .SetMarginBottom(0 * pxToPtFactor).SetMarginLeft(0 * pxToPtFactor)
            .SetMarginTop(0 * pxToPtFactor).SetMarginRight(0 * pxToPtFactor)
            .SetFontColor(new DeviceRgb(68, 68, 68), 1f)
            .SetBackgroundColor(new DeviceRgb(0, 0, 0), 0f)
            .SetFontSize(12 * pxToPtFactor)
            .SetFont(fontDictionary["poppins_regular"])
            .WithGlyphFallback(fontDictionary, "poppins_regular", () => cjkFallbackFont.Value)
            
            .SetParagraphWidthAndExtendHeightIfNotFit(document, 31.57f * pxToPtFactor, 20f * pxToPtFactor, true)
            .SetVisible(true)
            .SetVerticalAlignment(VerticalAlignment.TOP)
            .SetHorizontalAlignment(HorizontalAlignment.LEFT)
            .SetTextAlignment(TextAlignment.LEFT)
            .SetMultipliedLeading(1f);
            
colData_013084380.SetVisible(true);

                Cell cell_13084380 = new Cell(1, 1);
                var cell_13084380BackgroundColor = new DeviceRgb(0, 0, 0);
                var cell_13084380BackgroundColorOpacity = 0;
                
                cell_13084380.SetMinHeight(40 * pxToPtFactor);
                //cell_13084380.SetBorder(iText.Layout.Borders.Border.NO_BORDER);
                cell_13084380.SetBorderBottom(Border.NO_BORDER);
                cell_13084380.SetBorderTop(Border.NO_BORDER);
                cell_13084380.SetBorderRight(Border.NO_BORDER);
                cell_13084380.SetBorderLeft(Border.NO_BORDER);
                cell_13084380.SetBorderRadius(new BorderRadius(0f * pxToPtFactor));
                //cell_13084380.Add(colData_13084380);
                if (cell_13084380BackgroundColorOpacity == 1)
                    cell_13084380.SetBackgroundColor(cell_13084380BackgroundColor);
                else if (backgroundColorOpacity == 1)
                    cell_13084380.SetBackgroundColor(backgroundColor);
                cell_13084380.SetVerticalAlignment(iText.Layout.Properties.VerticalAlignment.TOP);
                cell_13084380.SetTextAlignment(iText.Layout.Properties.TextAlignment.LEFT);
                cell_13084380.SetPaddingBottom(0 * pxToPtFactor).SetPaddingLeft(0 * pxToPtFactor)
                .SetPaddingTop(0 * pxToPtFactor).SetPaddingRight(0 * pxToPtFactor);
                
                kasaraporudokumform_1142931966.AddCell(cell_13084380);

cell_13084380.Add(colData_013084380);

                
            var colData_0702238840 = new Paragraph(item.Doc_NetAmount.ToFormattedString("", "", "") ?? "")
            .SetMarginBottom(0 * pxToPtFactor).SetMarginLeft(0 * pxToPtFactor)
            .SetMarginTop(0 * pxToPtFactor).SetMarginRight(0 * pxToPtFactor)
            .SetFontColor(new DeviceRgb(68, 68, 68), 1f)
            .SetBackgroundColor(new DeviceRgb(0, 0, 0), 0f)
            .SetFontSize(12 * pxToPtFactor)
            .SetFont(fontDictionary["poppins_regular"])
            .WithGlyphFallback(fontDictionary, "poppins_regular", () => cjkFallbackFont.Value)
            
            .SetParagraphWidthAndExtendHeightIfNotFit(document, 26.45f * pxToPtFactor, 20f * pxToPtFactor, true)
            .SetVisible(true)
            .SetVerticalAlignment(VerticalAlignment.TOP)
            .SetHorizontalAlignment(HorizontalAlignment.LEFT)
            .SetTextAlignment(TextAlignment.LEFT)
            .SetMultipliedLeading(1f);
            
colData_0702238840.SetVisible(true);

                Cell cell_702238840 = new Cell(1, 1);
                var cell_702238840BackgroundColor = new DeviceRgb(0, 0, 0);
                var cell_702238840BackgroundColorOpacity = 0;
                
                cell_702238840.SetMinHeight(40 * pxToPtFactor);
                //cell_702238840.SetBorder(iText.Layout.Borders.Border.NO_BORDER);
                cell_702238840.SetBorderBottom(Border.NO_BORDER);
                cell_702238840.SetBorderTop(Border.NO_BORDER);
                cell_702238840.SetBorderRight(Border.NO_BORDER);
                cell_702238840.SetBorderLeft(Border.NO_BORDER);
                cell_702238840.SetBorderRadius(new BorderRadius(0f * pxToPtFactor));
                //cell_702238840.Add(colData_702238840);
                if (cell_702238840BackgroundColorOpacity == 1)
                    cell_702238840.SetBackgroundColor(cell_702238840BackgroundColor);
                else if (backgroundColorOpacity == 1)
                    cell_702238840.SetBackgroundColor(backgroundColor);
                cell_702238840.SetVerticalAlignment(iText.Layout.Properties.VerticalAlignment.TOP);
                cell_702238840.SetTextAlignment(iText.Layout.Properties.TextAlignment.LEFT);
                cell_702238840.SetPaddingBottom(0 * pxToPtFactor).SetPaddingLeft(0 * pxToPtFactor)
                .SetPaddingTop(0 * pxToPtFactor).SetPaddingRight(0 * pxToPtFactor);
                
                kasaraporudokumform_1142931966.AddCell(cell_702238840);

cell_702238840.Add(colData_0702238840);

                
            var colData_0965510972 = new Paragraph(item.Doc_LDiscountVITotal.ToFormattedString("", "", "") ?? "")
            .SetMarginBottom(0 * pxToPtFactor).SetMarginLeft(0 * pxToPtFactor)
            .SetMarginTop(0 * pxToPtFactor).SetMarginRight(0 * pxToPtFactor)
            .SetFontColor(new DeviceRgb(68, 68, 68), 1f)
            .SetBackgroundColor(new DeviceRgb(0, 0, 0), 0f)
            .SetFontSize(12 * pxToPtFactor)
            .SetFont(fontDictionary["poppins_regular"])
            .WithGlyphFallback(fontDictionary, "poppins_regular", () => cjkFallbackFont.Value)
            
            .SetParagraphWidthAndExtendHeightIfNotFit(document, 31.57f * pxToPtFactor, 20f * pxToPtFactor, true)
            .SetVisible(true)
            .SetVerticalAlignment(VerticalAlignment.TOP)
            .SetHorizontalAlignment(HorizontalAlignment.LEFT)
            .SetTextAlignment(TextAlignment.LEFT)
            .SetMultipliedLeading(1f);
            
colData_0965510972.SetVisible(true);

                Cell cell_965510972 = new Cell(1, 1);
                var cell_965510972BackgroundColor = new DeviceRgb(0, 0, 0);
                var cell_965510972BackgroundColorOpacity = 0;
                
                cell_965510972.SetMinHeight(40 * pxToPtFactor);
                //cell_965510972.SetBorder(iText.Layout.Borders.Border.NO_BORDER);
                cell_965510972.SetBorderBottom(Border.NO_BORDER);
                cell_965510972.SetBorderTop(Border.NO_BORDER);
                cell_965510972.SetBorderRight(Border.NO_BORDER);
                cell_965510972.SetBorderLeft(Border.NO_BORDER);
                cell_965510972.SetBorderRadius(new BorderRadius(0f * pxToPtFactor));
                //cell_965510972.Add(colData_965510972);
                if (cell_965510972BackgroundColorOpacity == 1)
                    cell_965510972.SetBackgroundColor(cell_965510972BackgroundColor);
                else if (backgroundColorOpacity == 1)
                    cell_965510972.SetBackgroundColor(backgroundColor);
                cell_965510972.SetVerticalAlignment(iText.Layout.Properties.VerticalAlignment.TOP);
                cell_965510972.SetTextAlignment(iText.Layout.Properties.TextAlignment.LEFT);
                cell_965510972.SetPaddingBottom(0 * pxToPtFactor).SetPaddingLeft(0 * pxToPtFactor)
                .SetPaddingTop(0 * pxToPtFactor).SetPaddingRight(0 * pxToPtFactor);
                
                kasaraporudokumform_1142931966.AddCell(cell_965510972);

cell_965510972.Add(colData_0965510972);

                
            var colData_02085514905 = new Paragraph(item.Doc_NetAmount.ToFormattedString("", "", "") ?? "")
            .SetMarginBottom(0 * pxToPtFactor).SetMarginLeft(0 * pxToPtFactor)
            .SetMarginTop(0 * pxToPtFactor).SetMarginRight(0 * pxToPtFactor)
            .SetFontColor(new DeviceRgb(68, 68, 68), 1f)
            .SetBackgroundColor(new DeviceRgb(0, 0, 0), 0f)
            .SetFontSize(12 * pxToPtFactor)
            .SetFont(fontDictionary["poppins_regular"])
            .WithGlyphFallback(fontDictionary, "poppins_regular", () => cjkFallbackFont.Value)
            
            .SetParagraphWidthAndExtendHeightIfNotFit(document, 31.57f * pxToPtFactor, 20f * pxToPtFactor, true)
            .SetVisible(true)
            .SetVerticalAlignment(VerticalAlignment.TOP)
            .SetHorizontalAlignment(HorizontalAlignment.LEFT)
            .SetTextAlignment(TextAlignment.LEFT)
            .SetMultipliedLeading(1f);
            
colData_02085514905.SetVisible(true);

                Cell cell_2085514905 = new Cell(1, 1);
                var cell_2085514905BackgroundColor = new DeviceRgb(0, 0, 0);
                var cell_2085514905BackgroundColorOpacity = 0;
                
                cell_2085514905.SetMinHeight(40 * pxToPtFactor);
                //cell_2085514905.SetBorder(iText.Layout.Borders.Border.NO_BORDER);
                cell_2085514905.SetBorderBottom(Border.NO_BORDER);
                cell_2085514905.SetBorderTop(Border.NO_BORDER);
                cell_2085514905.SetBorderRight(Border.NO_BORDER);
                cell_2085514905.SetBorderLeft(Border.NO_BORDER);
                cell_2085514905.SetBorderRadius(new BorderRadius(0f * pxToPtFactor));
                //cell_2085514905.Add(colData_2085514905);
                if (cell_2085514905BackgroundColorOpacity == 1)
                    cell_2085514905.SetBackgroundColor(cell_2085514905BackgroundColor);
                else if (backgroundColorOpacity == 1)
                    cell_2085514905.SetBackgroundColor(backgroundColor);
                cell_2085514905.SetVerticalAlignment(iText.Layout.Properties.VerticalAlignment.TOP);
                cell_2085514905.SetTextAlignment(iText.Layout.Properties.TextAlignment.LEFT);
                cell_2085514905.SetPaddingBottom(0 * pxToPtFactor).SetPaddingLeft(0 * pxToPtFactor)
                .SetPaddingTop(0 * pxToPtFactor).SetPaddingRight(0 * pxToPtFactor);
                
                kasaraporudokumform_1142931966.AddCell(cell_2085514905);

cell_2085514905.Add(colData_02085514905);

                
            var colData_01970500514 = new Paragraph(item.Loc_NetAmount.ToFormattedString("", "", "") ?? "")
            .SetMarginBottom(0 * pxToPtFactor).SetMarginLeft(0 * pxToPtFactor)
            .SetMarginTop(0 * pxToPtFactor).SetMarginRight(0 * pxToPtFactor)
            .SetFontColor(new DeviceRgb(68, 68, 68), 1f)
            .SetBackgroundColor(new DeviceRgb(0, 0, 0), 0f)
            .SetFontSize(12 * pxToPtFactor)
            .SetFont(fontDictionary["poppins_regular"])
            .WithGlyphFallback(fontDictionary, "poppins_regular", () => cjkFallbackFont.Value)
            
            .SetParagraphWidthAndExtendHeightIfNotFit(document, 31.57f * pxToPtFactor, 20f * pxToPtFactor, true)
            .SetVisible(true)
            .SetVerticalAlignment(VerticalAlignment.TOP)
            .SetHorizontalAlignment(HorizontalAlignment.LEFT)
            .SetTextAlignment(TextAlignment.LEFT)
            .SetMultipliedLeading(1f);
            
colData_01970500514.SetVisible(true);

                Cell cell_1970500514 = new Cell(1, 1);
                var cell_1970500514BackgroundColor = new DeviceRgb(0, 0, 0);
                var cell_1970500514BackgroundColorOpacity = 0;
                
                cell_1970500514.SetMinHeight(40 * pxToPtFactor);
                //cell_1970500514.SetBorder(iText.Layout.Borders.Border.NO_BORDER);
                cell_1970500514.SetBorderBottom(Border.NO_BORDER);
                cell_1970500514.SetBorderTop(Border.NO_BORDER);
                cell_1970500514.SetBorderRight(Border.NO_BORDER);
                cell_1970500514.SetBorderLeft(Border.NO_BORDER);
                cell_1970500514.SetBorderRadius(new BorderRadius(0f * pxToPtFactor));
                //cell_1970500514.Add(colData_1970500514);
                if (cell_1970500514BackgroundColorOpacity == 1)
                    cell_1970500514.SetBackgroundColor(cell_1970500514BackgroundColor);
                else if (backgroundColorOpacity == 1)
                    cell_1970500514.SetBackgroundColor(backgroundColor);
                cell_1970500514.SetVerticalAlignment(iText.Layout.Properties.VerticalAlignment.TOP);
                cell_1970500514.SetTextAlignment(iText.Layout.Properties.TextAlignment.LEFT);
                cell_1970500514.SetPaddingBottom(0 * pxToPtFactor).SetPaddingLeft(0 * pxToPtFactor)
                .SetPaddingTop(0 * pxToPtFactor).SetPaddingRight(0 * pxToPtFactor);
                
                kasaraporudokumform_1142931966.AddCell(cell_1970500514);

cell_1970500514.Add(colData_01970500514);

              }



            kasaraporudokumform_1142931966.SetMarginLeft(10f * pxToPtFactor + 0f * pxToPtFactor);
            if (Math.Abs(500f * pxToPtFactor) > 0) {{
               kasaraporudokumform_1142931966.SetMarginTop(Math.Abs(500f * pxToPtFactor) + 0f * pxToPtFactor);
            }}
            kasaraporudokumform_16424345_cell.Add(kasaraporudokumform_1142931966);
        }

   
            kasaraporudokumform_16424345_cell.SetVisible(box_kasaraporudokumform_16424345.IsVisible());
            box_kasaraporudokumform_16424345.AddCell(kasaraporudokumform_16424345_cell);
            
            // Draw rounded rectangle with PdfCanvas for border-radius support
            {
                var boxX = 10f * pxToPtFactor;
                var boxAbsY = Math.Abs(460f * pxToPtFactor);
                var boxPageRelY = boxAbsY - pageStartY;
                var boxY = ((currentPageHeight > 0 ? currentPageHeight : canvasHeight.Value) - (boxPageRelY + Math.Abs(218f * pxToPtFactor)));
                var boxW = 780f * pxToPtFactor;
                var boxH = 218f * pxToPtFactor;
                var boxRadiusTL = 6f * pxToPtFactor;
                var boxRadiusTR = 6f * pxToPtFactor;
                var boxRadiusBR = 6f * pxToPtFactor;
                var boxRadiusBL = 6f * pxToPtFactor;
                float kappaTL = boxRadiusTL * 0.5522848f;
                float kappaTR = boxRadiusTR * 0.5522848f;
                float kappaBR = boxRadiusBR * 0.5522848f;
                float kappaBL = boxRadiusBL * 0.5522848f;
                var currentPage = pdf.GetPage(pdf.GetNumberOfPages());
                var pdfCanvas = new PdfCanvas(currentPage);

                // Draw rounded background with alpha support
                pdfCanvas.SaveState();
                pdfCanvas.SetExtGState(new PdfExtGState().SetFillOpacity(1f));
                pdfCanvas.SetFillColor(new DeviceRgb(255, 255, 255));
                pdfCanvas.MoveTo(boxX + boxRadiusBL, boxY);
                pdfCanvas.LineTo(boxX + boxW - boxRadiusBR, boxY);
                if (boxRadiusBR > 0) pdfCanvas.CurveTo(boxX + boxW - boxRadiusBR + kappaBR, boxY, boxX + boxW, boxY + boxRadiusBR - kappaBR, boxX + boxW, boxY + boxRadiusBR);
                pdfCanvas.LineTo(boxX + boxW, boxY + boxH - boxRadiusTR);
                if (boxRadiusTR > 0) pdfCanvas.CurveTo(boxX + boxW, boxY + boxH - boxRadiusTR + kappaTR, boxX + boxW - boxRadiusTR + kappaTR, boxY + boxH, boxX + boxW - boxRadiusTR, boxY + boxH);
                pdfCanvas.LineTo(boxX + boxRadiusTL, boxY + boxH);
                if (boxRadiusTL > 0) pdfCanvas.CurveTo(boxX + boxRadiusTL - kappaTL, boxY + boxH, boxX, boxY + boxH - boxRadiusTL + kappaTL, boxX, boxY + boxH - boxRadiusTL);
                pdfCanvas.LineTo(boxX, boxY + boxRadiusBL);
                if (boxRadiusBL > 0) pdfCanvas.CurveTo(boxX, boxY + boxRadiusBL - kappaBL, boxX + boxRadiusBL - kappaBL, boxY, boxX + boxRadiusBL, boxY);
                pdfCanvas.ClosePath();
                pdfCanvas.Fill();
                pdfCanvas.RestoreState();

                // Draw individual border edges with per-side widths
                var rrBorderColor = new DeviceRgb(238, 242, 246);
                float rrBorderTop = 1f * pxToPtFactor;
                float rrBorderRight = 1f * pxToPtFactor;
                float rrBorderBottom = 1f * pxToPtFactor;
                float rrBorderLeft = 1f * pxToPtFactor;

                // Top border (uses TL and TR corners)
                if (rrBorderTop > 0)
                {
                    pdfCanvas.SaveState();
                    pdfCanvas.SetExtGState(new PdfExtGState().SetStrokeOpacity(1f));
                    pdfCanvas.SetStrokeColor(rrBorderColor);
                    pdfCanvas.SetLineWidth(rrBorderTop);
                    pdfCanvas.MoveTo(boxX + boxRadiusTL, boxY + boxH);
                    pdfCanvas.LineTo(boxX + boxW - boxRadiusTR, boxY + boxH);
                    if (boxRadiusTR > 0) pdfCanvas.CurveTo(boxX + boxW - boxRadiusTR + kappaTR, boxY + boxH, boxX + boxW, boxY + boxH - boxRadiusTR + kappaTR, boxX + boxW, boxY + boxH - boxRadiusTR);
                    pdfCanvas.Stroke();
                    pdfCanvas.RestoreState();
                }

                // Right border (uses TR and BR corners)
                if (rrBorderRight > 0)
                {
                    pdfCanvas.SaveState();
                    pdfCanvas.SetExtGState(new PdfExtGState().SetStrokeOpacity(1f));
                    pdfCanvas.SetStrokeColor(rrBorderColor);
                    pdfCanvas.SetLineWidth(rrBorderRight);
                    pdfCanvas.MoveTo(boxX + boxW, boxY + boxH - boxRadiusTR);
                    pdfCanvas.LineTo(boxX + boxW, boxY + boxRadiusBR);
                    if (boxRadiusBR > 0) pdfCanvas.CurveTo(boxX + boxW, boxY + boxRadiusBR - kappaBR, boxX + boxW - boxRadiusBR + kappaBR, boxY, boxX + boxW - boxRadiusBR, boxY);
                    pdfCanvas.Stroke();
                    pdfCanvas.RestoreState();
                }

                // Bottom border (uses BR and BL corners)
                if (rrBorderBottom > 0)
                {
                    pdfCanvas.SaveState();
                    pdfCanvas.SetExtGState(new PdfExtGState().SetStrokeOpacity(1f));
                    pdfCanvas.SetStrokeColor(rrBorderColor);
                    pdfCanvas.SetLineWidth(rrBorderBottom);
                    pdfCanvas.MoveTo(boxX + boxW - boxRadiusBR, boxY);
                    pdfCanvas.LineTo(boxX + boxRadiusBL, boxY);
                    if (boxRadiusBL > 0) pdfCanvas.CurveTo(boxX + boxRadiusBL - kappaBL, boxY, boxX, boxY + boxRadiusBL - kappaBL, boxX, boxY + boxRadiusBL);
                    pdfCanvas.Stroke();
                    pdfCanvas.RestoreState();
                }

                // Left border (uses BL and TL corners)
                if (rrBorderLeft > 0)
                {
                    pdfCanvas.SaveState();
                    pdfCanvas.SetExtGState(new PdfExtGState().SetStrokeOpacity(1f));
                    pdfCanvas.SetStrokeColor(rrBorderColor);
                    pdfCanvas.SetLineWidth(rrBorderLeft);
                    pdfCanvas.MoveTo(boxX, boxY + boxRadiusBL);
                    pdfCanvas.LineTo(boxX, boxY + boxH - boxRadiusTL);
                    if (boxRadiusTL > 0) pdfCanvas.CurveTo(boxX, boxY + boxH - boxRadiusTL + kappaTL, boxX + boxRadiusTL - kappaTL, boxY + boxH, boxX + boxRadiusTL, boxY + boxH);
                    pdfCanvas.Stroke();
                    pdfCanvas.RestoreState();
                }
            }
            document.Add(box_kasaraporudokumform_16424345);
            foreach (var deferredElem in box_kasaraporudokumform_16424345_deferredAdds) document.Add(deferredElem);
            }}


            //Box5
            Table box_kasaraporudokumform_1880948553 = new Table(1).SetWidth(790f * pxToPtFactor).SetHeight(30f * pxToPtFactor)
            .SetFontColor(new DeviceRgb(0, 0, 0), 1f)
            .SetFontSize(20 * pxToPtFactor)
            .SetVisible(true);
            if (box_kasaraporudokumform_1880948553.IsVisible()) {{
            var box_kasaraporudokumform_1880948553_pageLeftX = (double)(10f * pxToPtFactor) ;
            var box_kasaraporudokumform_1880948553_pageTopY = 0d;
            var box_kasaraporudokumform_1880948553_deferredAdds = new List<IBlockElement>();
            if (!false) {
            // Calculate page-relative Y position
            var box_kasaraporudokumform_1880948553_absoluteY = Math.Abs(460f * pxToPtFactor);
            var box_kasaraporudokumform_1880948553_pageRelativeY = box_kasaraporudokumform_1880948553_absoluteY - pageStartY;
            int box_kasaraporudokumform_1880948553_targetPage = pdf.GetNumberOfPages();
            
            box_kasaraporudokumform_1880948553.SetFixedPosition(box_kasaraporudokumform_1880948553_targetPage, 10f * pxToPtFactor , ((currentPageHeight > 0 ? currentPageHeight : canvasHeight.Value) - (box_kasaraporudokumform_1880948553_pageRelativeY + Math.Abs(30f * pxToPtFactor))) , 790f * pxToPtFactor);
            box_kasaraporudokumform_1880948553_pageTopY = ((double)(currentPageHeight > 0 ? currentPageHeight : canvasHeight.Value) - box_kasaraporudokumform_1880948553_pageRelativeY) ;
            } else {
            box_kasaraporudokumform_1880948553.SetFixedPosition(10f * pxToPtFactor , ((currentPageHeight > 0 ? currentPageHeight : canvasHeight.Value) - (totalHeight + Math.Abs(460f * pxToPtFactor) + Math.Abs(30f * pxToPtFactor))) , 790f * pxToPtFactor);
            box_kasaraporudokumform_1880948553_pageTopY = ((double)(currentPageHeight > 0 ? currentPageHeight : canvasHeight.Value) - (totalHeight + Math.Abs(460f * pxToPtFactor))) ;
            }
            box_kasaraporudokumform_1880948553.SetBorder(Border.NO_BORDER);
            box_kasaraporudokumform_1880948553.SetBorderBottom(Border.NO_BORDER);
            box_kasaraporudokumform_1880948553.SetBorderTop(Border.NO_BORDER);
            box_kasaraporudokumform_1880948553.SetBorderRight(Border.NO_BORDER);
            box_kasaraporudokumform_1880948553.SetBorderLeft(Border.NO_BORDER);
            box_kasaraporudokumform_1880948553.SetBorderRadius(new BorderRadius(6f * pxToPtFactor));
            var heightOf_box_kasaraporudokumform_1880948553 = box_kasaraporudokumform_1880948553.GetHeight();
            Cell kasaraporudokumform_1880948553_cell = new Cell();
            kasaraporudokumform_1880948553_cell.SetBackgroundColor(new DeviceRgb(114, 194, 64), 0f);
            kasaraporudokumform_1880948553_cell.SetBorder(Border.NO_BORDER);
            
            // NOTE: Box always uses SetFixedPosition above (both branches), so it does not
            // contribute to flow. The legacy "totalHeight + height > canvasHeight" areaBreak
            // that lived here was reading totalHeight produced by previous flow elements
            // (e.g. multi-page ReportTables) and spuriously creating a new page + bumping
            // pageStartY, which broke pageRelativeY for every subsequent element. Removed.

            // No page breaks - using default canvas height behavior


            //Label10
            var label_kasaraporudokumform_1650705290_effectiveWidth = 780f * pxToPtFactor > 0 ? 780f * pxToPtFactor : (canvasWidth.Value - (10f * pxToPtFactor));
            Paragraph label_kasaraporudokumform_1650705290 = new Paragraph(@"Satış Faturaları")
            .SetFontSize(15 * pxToPtFactor)
            .SetFont(fontDictionary["poppins_bold"])
            .WithGlyphFallback(fontDictionary, "poppins_bold", () => cjkFallbackFont.Value)
            .SetTextAlignment(TextAlignment.CENTER)
            
            .SetParagraphWidthAndExtendHeightIfNotFit(document, label_kasaraporudokumform_1650705290_effectiveWidth, 20f * pxToPtFactor, false, false || false)
            .SetMultipliedLeading(0.875f);
            

            if (20f * pxToPtFactor == 0f)
            {
                label_kasaraporudokumform_1650705290.SetMaxHeight((30f * pxToPtFactor) - Math.Abs(460f * pxToPtFactor));
            }

            label_kasaraporudokumform_1650705290.SetMarginBottom(0 * pxToPtFactor).SetMarginTop(0f);
            var label_kasaraporudokumform_1650705290_paragraphHeight = label_kasaraporudokumform_1650705290.GetHeightOfParagraph(document);
            var label_kasaraporudokumform_1650705290_vAlignOffset = 0f;
            label_kasaraporudokumform_1650705290_vAlignOffset = Math.Max(0f, (20f * pxToPtFactor - label_kasaraporudokumform_1650705290_paragraphHeight) / 2f);
            label_kasaraporudokumform_1650705290.SetMarginLeft(0 * pxToPtFactor)
            .SetMarginTop((0 * pxToPtFactor) + label_kasaraporudokumform_1650705290_vAlignOffset).SetMarginRight(0 * pxToPtFactor)
            .SetFontColor(new DeviceRgb(255, 255, 255), 1f)
            .SetVisible(true);
            
            if (false)
			{
				Paragraph label_kasaraporudokumform_1650705290_inside = new Paragraph(@"Satış Faturaları")
			   .SetFontSize(15 * pxToPtFactor)
               .SetFont(fontDictionary["poppins_bold"])
			   .WithGlyphFallback(fontDictionary, "poppins_bold", () => cjkFallbackFont.Value)
			   .SetFontColor(new DeviceRgb(255, 255, 255), 1f)
			   
			   .SetRotationAngle(0);
				label_kasaraporudokumform_1650705290.Add(label_kasaraporudokumform_1650705290_inside);
			}
            var label_kasaraporudokumform_1650705290_renderHeight = 20f * pxToPtFactor > 0 ? 20f * pxToPtFactor : label_kasaraporudokumform_1650705290_paragraphHeight;
            // Actual div height accounts for paragraph margins that may expand the Div beyond MinHeight
            // paragraphHeight was measured with MarginTop=0, but actual MarginTop = paddingTop + vAlignOffset
            var label_kasaraporudokumform_1650705290_divHeight = Math.Max(label_kasaraporudokumform_1650705290_renderHeight, label_kasaraporudokumform_1650705290_paragraphHeight + (0 * pxToPtFactor) + label_kasaraporudokumform_1650705290_vAlignOffset);
            var div_label_kasaraporudokumform_1650705290 = new Div();
            div_label_kasaraporudokumform_1650705290.SetMinHeight(label_kasaraporudokumform_1650705290_renderHeight);
            div_label_kasaraporudokumform_1650705290.SetBackgroundColor(new DeviceRgb(0, 0, 0), 0f);
            div_label_kasaraporudokumform_1650705290.SetBorderBottom(Border.NO_BORDER);
            div_label_kasaraporudokumform_1650705290.SetBorderTop(Border.NO_BORDER);
            div_label_kasaraporudokumform_1650705290.SetBorderRight(Border.NO_BORDER);
            div_label_kasaraporudokumform_1650705290.SetBorderLeft(Border.NO_BORDER);
            div_label_kasaraporudokumform_1650705290.SetBorderRadius(new BorderRadius(0f * pxToPtFactor));
            div_label_kasaraporudokumform_1650705290.Add(label_kasaraporudokumform_1650705290);
            
            // Label/Icon inside Box: use box page coordinates for absolute positioning
            var label_kasaraporudokumform_1650705290_yPos = box_kasaraporudokumform_1880948553_pageTopY - (0f * pxToPtFactor) - label_kasaraporudokumform_1650705290_divHeight;
            div_label_kasaraporudokumform_1650705290.SetFixedPosition((float)(box_kasaraporudokumform_1880948553_pageLeftX + (0f * pxToPtFactor)), (float)label_kasaraporudokumform_1650705290_yPos, label_kasaraporudokumform_1650705290_effectiveWidth);
            div_label_kasaraporudokumform_1650705290.SetVisible(true);
            box_kasaraporudokumform_1880948553_deferredAdds.Add(div_label_kasaraporudokumform_1650705290);

            kasaraporudokumform_1880948553_cell.SetVisible(box_kasaraporudokumform_1880948553.IsVisible());
            box_kasaraporudokumform_1880948553.AddCell(kasaraporudokumform_1880948553_cell);
            
            // Draw rounded rectangle with PdfCanvas for border-radius support
            {
                var boxX = 10f * pxToPtFactor;
                var boxAbsY = Math.Abs(460f * pxToPtFactor);
                var boxPageRelY = boxAbsY - pageStartY;
                var boxY = ((currentPageHeight > 0 ? currentPageHeight : canvasHeight.Value) - (boxPageRelY + Math.Abs(30f * pxToPtFactor)));
                var boxW = 790f * pxToPtFactor;
                var boxH = 30f * pxToPtFactor;
                var boxRadiusTL = 6f * pxToPtFactor;
                var boxRadiusTR = 6f * pxToPtFactor;
                var boxRadiusBR = 6f * pxToPtFactor;
                var boxRadiusBL = 6f * pxToPtFactor;
                float kappaTL = boxRadiusTL * 0.5522848f;
                float kappaTR = boxRadiusTR * 0.5522848f;
                float kappaBR = boxRadiusBR * 0.5522848f;
                float kappaBL = boxRadiusBL * 0.5522848f;
                var currentPage = pdf.GetPage(pdf.GetNumberOfPages());
                var pdfCanvas = new PdfCanvas(currentPage);

                // Draw rounded background with alpha support
                pdfCanvas.SaveState();
                pdfCanvas.SetExtGState(new PdfExtGState().SetFillOpacity(1f));
                pdfCanvas.SetFillColor(new DeviceRgb(114, 194, 64));
                pdfCanvas.MoveTo(boxX + boxRadiusBL, boxY);
                pdfCanvas.LineTo(boxX + boxW - boxRadiusBR, boxY);
                if (boxRadiusBR > 0) pdfCanvas.CurveTo(boxX + boxW - boxRadiusBR + kappaBR, boxY, boxX + boxW, boxY + boxRadiusBR - kappaBR, boxX + boxW, boxY + boxRadiusBR);
                pdfCanvas.LineTo(boxX + boxW, boxY + boxH - boxRadiusTR);
                if (boxRadiusTR > 0) pdfCanvas.CurveTo(boxX + boxW, boxY + boxH - boxRadiusTR + kappaTR, boxX + boxW - boxRadiusTR + kappaTR, boxY + boxH, boxX + boxW - boxRadiusTR, boxY + boxH);
                pdfCanvas.LineTo(boxX + boxRadiusTL, boxY + boxH);
                if (boxRadiusTL > 0) pdfCanvas.CurveTo(boxX + boxRadiusTL - kappaTL, boxY + boxH, boxX, boxY + boxH - boxRadiusTL + kappaTL, boxX, boxY + boxH - boxRadiusTL);
                pdfCanvas.LineTo(boxX, boxY + boxRadiusBL);
                if (boxRadiusBL > 0) pdfCanvas.CurveTo(boxX, boxY + boxRadiusBL - kappaBL, boxX + boxRadiusBL - kappaBL, boxY, boxX + boxRadiusBL, boxY);
                pdfCanvas.ClosePath();
                pdfCanvas.Fill();
                pdfCanvas.RestoreState();

                // Draw individual border edges with per-side widths
                var rrBorderColor = new DeviceRgb(114, 194, 64);
                float rrBorderTop = 1f * pxToPtFactor;
                float rrBorderRight = 1f * pxToPtFactor;
                float rrBorderBottom = 1f * pxToPtFactor;
                float rrBorderLeft = 1f * pxToPtFactor;

                // Top border (uses TL and TR corners)
                if (rrBorderTop > 0)
                {
                    pdfCanvas.SaveState();
                    pdfCanvas.SetExtGState(new PdfExtGState().SetStrokeOpacity(1f));
                    pdfCanvas.SetStrokeColor(rrBorderColor);
                    pdfCanvas.SetLineWidth(rrBorderTop);
                    pdfCanvas.MoveTo(boxX + boxRadiusTL, boxY + boxH);
                    pdfCanvas.LineTo(boxX + boxW - boxRadiusTR, boxY + boxH);
                    if (boxRadiusTR > 0) pdfCanvas.CurveTo(boxX + boxW - boxRadiusTR + kappaTR, boxY + boxH, boxX + boxW, boxY + boxH - boxRadiusTR + kappaTR, boxX + boxW, boxY + boxH - boxRadiusTR);
                    pdfCanvas.Stroke();
                    pdfCanvas.RestoreState();
                }

                // Right border (uses TR and BR corners)
                if (rrBorderRight > 0)
                {
                    pdfCanvas.SaveState();
                    pdfCanvas.SetExtGState(new PdfExtGState().SetStrokeOpacity(1f));
                    pdfCanvas.SetStrokeColor(rrBorderColor);
                    pdfCanvas.SetLineWidth(rrBorderRight);
                    pdfCanvas.MoveTo(boxX + boxW, boxY + boxH - boxRadiusTR);
                    pdfCanvas.LineTo(boxX + boxW, boxY + boxRadiusBR);
                    if (boxRadiusBR > 0) pdfCanvas.CurveTo(boxX + boxW, boxY + boxRadiusBR - kappaBR, boxX + boxW - boxRadiusBR + kappaBR, boxY, boxX + boxW - boxRadiusBR, boxY);
                    pdfCanvas.Stroke();
                    pdfCanvas.RestoreState();
                }

                // Bottom border (uses BR and BL corners)
                if (rrBorderBottom > 0)
                {
                    pdfCanvas.SaveState();
                    pdfCanvas.SetExtGState(new PdfExtGState().SetStrokeOpacity(1f));
                    pdfCanvas.SetStrokeColor(rrBorderColor);
                    pdfCanvas.SetLineWidth(rrBorderBottom);
                    pdfCanvas.MoveTo(boxX + boxW - boxRadiusBR, boxY);
                    pdfCanvas.LineTo(boxX + boxRadiusBL, boxY);
                    if (boxRadiusBL > 0) pdfCanvas.CurveTo(boxX + boxRadiusBL - kappaBL, boxY, boxX, boxY + boxRadiusBL - kappaBL, boxX, boxY + boxRadiusBL);
                    pdfCanvas.Stroke();
                    pdfCanvas.RestoreState();
                }

                // Left border (uses BL and TL corners)
                if (rrBorderLeft > 0)
                {
                    pdfCanvas.SaveState();
                    pdfCanvas.SetExtGState(new PdfExtGState().SetStrokeOpacity(1f));
                    pdfCanvas.SetStrokeColor(rrBorderColor);
                    pdfCanvas.SetLineWidth(rrBorderLeft);
                    pdfCanvas.MoveTo(boxX, boxY + boxRadiusBL);
                    pdfCanvas.LineTo(boxX, boxY + boxH - boxRadiusTL);
                    if (boxRadiusTL > 0) pdfCanvas.CurveTo(boxX, boxY + boxH - boxRadiusTL + kappaTL, boxX + boxRadiusTL - kappaTL, boxY + boxH, boxX + boxRadiusTL, boxY + boxH);
                    pdfCanvas.Stroke();
                    pdfCanvas.RestoreState();
                }
            }
            document.Add(box_kasaraporudokumform_1880948553);
            foreach (var deferredElem in box_kasaraporudokumform_1880948553_deferredAdds) document.Add(deferredElem);
            }}


            //Box6
            Table box_kasaraporudokumform_2074596522 = new Table(1).SetWidth(780f * pxToPtFactor).SetHeight(219f * pxToPtFactor)
            .SetFontColor(new DeviceRgb(0, 0, 0), 1f)
            .SetFontSize(20 * pxToPtFactor)
            .SetVisible(true);
            if (box_kasaraporudokumform_2074596522.IsVisible()) {{
            var box_kasaraporudokumform_2074596522_pageLeftX = (double)(10f * pxToPtFactor) ;
            var box_kasaraporudokumform_2074596522_pageTopY = 0d;
            var box_kasaraporudokumform_2074596522_deferredAdds = new List<IBlockElement>();
            if (!false) {
            // Calculate page-relative Y position
            var box_kasaraporudokumform_2074596522_absoluteY = Math.Abs(750f * pxToPtFactor);
            var box_kasaraporudokumform_2074596522_pageRelativeY = box_kasaraporudokumform_2074596522_absoluteY - pageStartY;
            int box_kasaraporudokumform_2074596522_targetPage = pdf.GetNumberOfPages();
            
            box_kasaraporudokumform_2074596522.SetFixedPosition(box_kasaraporudokumform_2074596522_targetPage, 10f * pxToPtFactor , ((currentPageHeight > 0 ? currentPageHeight : canvasHeight.Value) - (box_kasaraporudokumform_2074596522_pageRelativeY + Math.Abs(219f * pxToPtFactor))) , 780f * pxToPtFactor);
            box_kasaraporudokumform_2074596522_pageTopY = ((double)(currentPageHeight > 0 ? currentPageHeight : canvasHeight.Value) - box_kasaraporudokumform_2074596522_pageRelativeY) ;
            } else {
            box_kasaraporudokumform_2074596522.SetFixedPosition(10f * pxToPtFactor , ((currentPageHeight > 0 ? currentPageHeight : canvasHeight.Value) - (totalHeight + Math.Abs(750f * pxToPtFactor) + Math.Abs(219f * pxToPtFactor))) , 780f * pxToPtFactor);
            box_kasaraporudokumform_2074596522_pageTopY = ((double)(currentPageHeight > 0 ? currentPageHeight : canvasHeight.Value) - (totalHeight + Math.Abs(750f * pxToPtFactor))) ;
            }
            box_kasaraporudokumform_2074596522.SetBorder(Border.NO_BORDER);
            box_kasaraporudokumform_2074596522.SetBorderBottom(Border.NO_BORDER);
            box_kasaraporudokumform_2074596522.SetBorderTop(Border.NO_BORDER);
            box_kasaraporudokumform_2074596522.SetBorderRight(Border.NO_BORDER);
            box_kasaraporudokumform_2074596522.SetBorderLeft(Border.NO_BORDER);
            box_kasaraporudokumform_2074596522.SetBorderRadius(new BorderRadius(6f * pxToPtFactor));
            var heightOf_box_kasaraporudokumform_2074596522 = box_kasaraporudokumform_2074596522.GetHeight();
            Cell kasaraporudokumform_2074596522_cell = new Cell();
            kasaraporudokumform_2074596522_cell.SetBackgroundColor(new DeviceRgb(255, 255, 255), 0f);
            kasaraporudokumform_2074596522_cell.SetBorder(Border.NO_BORDER);
            
            // NOTE: Box always uses SetFixedPosition above (both branches), so it does not
            // contribute to flow. The legacy "totalHeight + height > canvasHeight" areaBreak
            // that lived here was reading totalHeight produced by previous flow elements
            // (e.g. multi-page ReportTables) and spuriously creating a new page + bumping
            // pageStartY, which broke pageRelativeY for every subsequent element. Removed.

            // No page breaks - using default canvas height behavior


            //Box7
            Table box_kasaraporudokumform_672114386 = new Table(1).SetWidth(790f * pxToPtFactor).SetHeight(30f * pxToPtFactor)
            .SetFontColor(new DeviceRgb(0, 0, 0), 1f)
            .SetFontSize(20 * pxToPtFactor)
            .SetVisible(true);
            if (box_kasaraporudokumform_672114386.IsVisible()) {{
            var box_kasaraporudokumform_672114386_pageLeftX = (double)(10f * pxToPtFactor) ;
            var box_kasaraporudokumform_672114386_pageTopY = 0d;
            var box_kasaraporudokumform_672114386_deferredAdds = new List<IBlockElement>();
            if (!false) {
            // Calculate page-relative Y position
            var box_kasaraporudokumform_672114386_absoluteY = Math.Abs(750f * pxToPtFactor);
            var box_kasaraporudokumform_672114386_pageRelativeY = box_kasaraporudokumform_672114386_absoluteY - pageStartY;
            int box_kasaraporudokumform_672114386_targetPage = pdf.GetNumberOfPages();
            
            box_kasaraporudokumform_672114386.SetFixedPosition(box_kasaraporudokumform_672114386_targetPage, 10f * pxToPtFactor , ((currentPageHeight > 0 ? currentPageHeight : canvasHeight.Value) - (box_kasaraporudokumform_672114386_pageRelativeY + Math.Abs(30f * pxToPtFactor))) , 790f * pxToPtFactor);
            box_kasaraporudokumform_672114386_pageTopY = ((double)(currentPageHeight > 0 ? currentPageHeight : canvasHeight.Value) - box_kasaraporudokumform_672114386_pageRelativeY) ;
            } else {
            box_kasaraporudokumform_672114386.SetFixedPosition(10f * pxToPtFactor , ((currentPageHeight > 0 ? currentPageHeight : canvasHeight.Value) - (totalHeight + Math.Abs(750f * pxToPtFactor) + Math.Abs(30f * pxToPtFactor))) , 790f * pxToPtFactor);
            box_kasaraporudokumform_672114386_pageTopY = ((double)(currentPageHeight > 0 ? currentPageHeight : canvasHeight.Value) - (totalHeight + Math.Abs(750f * pxToPtFactor))) ;
            }
            box_kasaraporudokumform_672114386.SetBorder(Border.NO_BORDER);
            box_kasaraporudokumform_672114386.SetBorderBottom(Border.NO_BORDER);
            box_kasaraporudokumform_672114386.SetBorderTop(Border.NO_BORDER);
            box_kasaraporudokumform_672114386.SetBorderRight(Border.NO_BORDER);
            box_kasaraporudokumform_672114386.SetBorderLeft(Border.NO_BORDER);
            box_kasaraporudokumform_672114386.SetBorderRadius(new BorderRadius(6f * pxToPtFactor));
            var heightOf_box_kasaraporudokumform_672114386 = box_kasaraporudokumform_672114386.GetHeight();
            Cell kasaraporudokumform_672114386_cell = new Cell();
            kasaraporudokumform_672114386_cell.SetBackgroundColor(new DeviceRgb(114, 194, 64), 0f);
            kasaraporudokumform_672114386_cell.SetBorder(Border.NO_BORDER);
            
            // NOTE: Box always uses SetFixedPosition above (both branches), so it does not
            // contribute to flow. The legacy "totalHeight + height > canvasHeight" areaBreak
            // that lived here was reading totalHeight produced by previous flow elements
            // (e.g. multi-page ReportTables) and spuriously creating a new page + bumping
            // pageStartY, which broke pageRelativeY for every subsequent element. Removed.

            // No page breaks - using default canvas height behavior


            //Label11
            var label_kasaraporudokumform_988109796_effectiveWidth = 780f * pxToPtFactor > 0 ? 780f * pxToPtFactor : (canvasWidth.Value - (10f * pxToPtFactor));
            Paragraph label_kasaraporudokumform_988109796 = new Paragraph(@"Nakit Devirler")
            .SetFontSize(15 * pxToPtFactor)
            .SetFont(fontDictionary["poppins_bold"])
            .WithGlyphFallback(fontDictionary, "poppins_bold", () => cjkFallbackFont.Value)
            .SetTextAlignment(TextAlignment.CENTER)
            
            .SetParagraphWidthAndExtendHeightIfNotFit(document, label_kasaraporudokumform_988109796_effectiveWidth, 20f * pxToPtFactor, false, false || false)
            .SetMultipliedLeading(0.875f);
            

            if (20f * pxToPtFactor == 0f)
            {
                label_kasaraporudokumform_988109796.SetMaxHeight((30f * pxToPtFactor) - Math.Abs(750f * pxToPtFactor));
            }

            label_kasaraporudokumform_988109796.SetMarginBottom(0 * pxToPtFactor).SetMarginTop(0f);
            var label_kasaraporudokumform_988109796_paragraphHeight = label_kasaraporudokumform_988109796.GetHeightOfParagraph(document);
            var label_kasaraporudokumform_988109796_vAlignOffset = 0f;
            label_kasaraporudokumform_988109796_vAlignOffset = Math.Max(0f, (20f * pxToPtFactor - label_kasaraporudokumform_988109796_paragraphHeight) / 2f);
            label_kasaraporudokumform_988109796.SetMarginLeft(0 * pxToPtFactor)
            .SetMarginTop((0 * pxToPtFactor) + label_kasaraporudokumform_988109796_vAlignOffset).SetMarginRight(0 * pxToPtFactor)
            .SetFontColor(new DeviceRgb(255, 255, 255), 1f)
            .SetVisible(true);
            
            if (false)
			{
				Paragraph label_kasaraporudokumform_988109796_inside = new Paragraph(@"Nakit Devirler")
			   .SetFontSize(15 * pxToPtFactor)
               .SetFont(fontDictionary["poppins_bold"])
			   .WithGlyphFallback(fontDictionary, "poppins_bold", () => cjkFallbackFont.Value)
			   .SetFontColor(new DeviceRgb(255, 255, 255), 1f)
			   
			   .SetRotationAngle(0);
				label_kasaraporudokumform_988109796.Add(label_kasaraporudokumform_988109796_inside);
			}
            var label_kasaraporudokumform_988109796_renderHeight = 20f * pxToPtFactor > 0 ? 20f * pxToPtFactor : label_kasaraporudokumform_988109796_paragraphHeight;
            // Actual div height accounts for paragraph margins that may expand the Div beyond MinHeight
            // paragraphHeight was measured with MarginTop=0, but actual MarginTop = paddingTop + vAlignOffset
            var label_kasaraporudokumform_988109796_divHeight = Math.Max(label_kasaraporudokumform_988109796_renderHeight, label_kasaraporudokumform_988109796_paragraphHeight + (0 * pxToPtFactor) + label_kasaraporudokumform_988109796_vAlignOffset);
            var div_label_kasaraporudokumform_988109796 = new Div();
            div_label_kasaraporudokumform_988109796.SetMinHeight(label_kasaraporudokumform_988109796_renderHeight);
            div_label_kasaraporudokumform_988109796.SetBackgroundColor(new DeviceRgb(0, 0, 0), 0f);
            div_label_kasaraporudokumform_988109796.SetBorderBottom(Border.NO_BORDER);
            div_label_kasaraporudokumform_988109796.SetBorderTop(Border.NO_BORDER);
            div_label_kasaraporudokumform_988109796.SetBorderRight(Border.NO_BORDER);
            div_label_kasaraporudokumform_988109796.SetBorderLeft(Border.NO_BORDER);
            div_label_kasaraporudokumform_988109796.SetBorderRadius(new BorderRadius(0f * pxToPtFactor));
            div_label_kasaraporudokumform_988109796.Add(label_kasaraporudokumform_988109796);
            
            // Label/Icon inside Box: use box page coordinates for absolute positioning
            var label_kasaraporudokumform_988109796_yPos = box_kasaraporudokumform_672114386_pageTopY - (0f * pxToPtFactor) - label_kasaraporudokumform_988109796_divHeight;
            div_label_kasaraporudokumform_988109796.SetFixedPosition((float)(box_kasaraporudokumform_672114386_pageLeftX + (0f * pxToPtFactor)), (float)label_kasaraporudokumform_988109796_yPos, label_kasaraporudokumform_988109796_effectiveWidth);
            div_label_kasaraporudokumform_988109796.SetVisible(true);
            box_kasaraporudokumform_672114386_deferredAdds.Add(div_label_kasaraporudokumform_988109796);

            kasaraporudokumform_672114386_cell.SetVisible(box_kasaraporudokumform_672114386.IsVisible());
            box_kasaraporudokumform_672114386.AddCell(kasaraporudokumform_672114386_cell);
            
            // Draw rounded rectangle with PdfCanvas for border-radius support
            {
                var boxX = 10f * pxToPtFactor;
                var boxAbsY = Math.Abs(750f * pxToPtFactor);
                var boxPageRelY = boxAbsY - pageStartY;
                var boxY = ((currentPageHeight > 0 ? currentPageHeight : canvasHeight.Value) - (boxPageRelY + Math.Abs(30f * pxToPtFactor)));
                var boxW = 790f * pxToPtFactor;
                var boxH = 30f * pxToPtFactor;
                var boxRadiusTL = 6f * pxToPtFactor;
                var boxRadiusTR = 6f * pxToPtFactor;
                var boxRadiusBR = 6f * pxToPtFactor;
                var boxRadiusBL = 6f * pxToPtFactor;
                float kappaTL = boxRadiusTL * 0.5522848f;
                float kappaTR = boxRadiusTR * 0.5522848f;
                float kappaBR = boxRadiusBR * 0.5522848f;
                float kappaBL = boxRadiusBL * 0.5522848f;
                var currentPage = pdf.GetPage(pdf.GetNumberOfPages());
                var pdfCanvas = new PdfCanvas(currentPage);

                // Draw rounded background with alpha support
                pdfCanvas.SaveState();
                pdfCanvas.SetExtGState(new PdfExtGState().SetFillOpacity(1f));
                pdfCanvas.SetFillColor(new DeviceRgb(114, 194, 64));
                pdfCanvas.MoveTo(boxX + boxRadiusBL, boxY);
                pdfCanvas.LineTo(boxX + boxW - boxRadiusBR, boxY);
                if (boxRadiusBR > 0) pdfCanvas.CurveTo(boxX + boxW - boxRadiusBR + kappaBR, boxY, boxX + boxW, boxY + boxRadiusBR - kappaBR, boxX + boxW, boxY + boxRadiusBR);
                pdfCanvas.LineTo(boxX + boxW, boxY + boxH - boxRadiusTR);
                if (boxRadiusTR > 0) pdfCanvas.CurveTo(boxX + boxW, boxY + boxH - boxRadiusTR + kappaTR, boxX + boxW - boxRadiusTR + kappaTR, boxY + boxH, boxX + boxW - boxRadiusTR, boxY + boxH);
                pdfCanvas.LineTo(boxX + boxRadiusTL, boxY + boxH);
                if (boxRadiusTL > 0) pdfCanvas.CurveTo(boxX + boxRadiusTL - kappaTL, boxY + boxH, boxX, boxY + boxH - boxRadiusTL + kappaTL, boxX, boxY + boxH - boxRadiusTL);
                pdfCanvas.LineTo(boxX, boxY + boxRadiusBL);
                if (boxRadiusBL > 0) pdfCanvas.CurveTo(boxX, boxY + boxRadiusBL - kappaBL, boxX + boxRadiusBL - kappaBL, boxY, boxX + boxRadiusBL, boxY);
                pdfCanvas.ClosePath();
                pdfCanvas.Fill();
                pdfCanvas.RestoreState();

                // Draw individual border edges with per-side widths
                var rrBorderColor = new DeviceRgb(114, 194, 64);
                float rrBorderTop = 1f * pxToPtFactor;
                float rrBorderRight = 1f * pxToPtFactor;
                float rrBorderBottom = 1f * pxToPtFactor;
                float rrBorderLeft = 1f * pxToPtFactor;

                // Top border (uses TL and TR corners)
                if (rrBorderTop > 0)
                {
                    pdfCanvas.SaveState();
                    pdfCanvas.SetExtGState(new PdfExtGState().SetStrokeOpacity(1f));
                    pdfCanvas.SetStrokeColor(rrBorderColor);
                    pdfCanvas.SetLineWidth(rrBorderTop);
                    pdfCanvas.MoveTo(boxX + boxRadiusTL, boxY + boxH);
                    pdfCanvas.LineTo(boxX + boxW - boxRadiusTR, boxY + boxH);
                    if (boxRadiusTR > 0) pdfCanvas.CurveTo(boxX + boxW - boxRadiusTR + kappaTR, boxY + boxH, boxX + boxW, boxY + boxH - boxRadiusTR + kappaTR, boxX + boxW, boxY + boxH - boxRadiusTR);
                    pdfCanvas.Stroke();
                    pdfCanvas.RestoreState();
                }

                // Right border (uses TR and BR corners)
                if (rrBorderRight > 0)
                {
                    pdfCanvas.SaveState();
                    pdfCanvas.SetExtGState(new PdfExtGState().SetStrokeOpacity(1f));
                    pdfCanvas.SetStrokeColor(rrBorderColor);
                    pdfCanvas.SetLineWidth(rrBorderRight);
                    pdfCanvas.MoveTo(boxX + boxW, boxY + boxH - boxRadiusTR);
                    pdfCanvas.LineTo(boxX + boxW, boxY + boxRadiusBR);
                    if (boxRadiusBR > 0) pdfCanvas.CurveTo(boxX + boxW, boxY + boxRadiusBR - kappaBR, boxX + boxW - boxRadiusBR + kappaBR, boxY, boxX + boxW - boxRadiusBR, boxY);
                    pdfCanvas.Stroke();
                    pdfCanvas.RestoreState();
                }

                // Bottom border (uses BR and BL corners)
                if (rrBorderBottom > 0)
                {
                    pdfCanvas.SaveState();
                    pdfCanvas.SetExtGState(new PdfExtGState().SetStrokeOpacity(1f));
                    pdfCanvas.SetStrokeColor(rrBorderColor);
                    pdfCanvas.SetLineWidth(rrBorderBottom);
                    pdfCanvas.MoveTo(boxX + boxW - boxRadiusBR, boxY);
                    pdfCanvas.LineTo(boxX + boxRadiusBL, boxY);
                    if (boxRadiusBL > 0) pdfCanvas.CurveTo(boxX + boxRadiusBL - kappaBL, boxY, boxX, boxY + boxRadiusBL - kappaBL, boxX, boxY + boxRadiusBL);
                    pdfCanvas.Stroke();
                    pdfCanvas.RestoreState();
                }

                // Left border (uses BL and TL corners)
                if (rrBorderLeft > 0)
                {
                    pdfCanvas.SaveState();
                    pdfCanvas.SetExtGState(new PdfExtGState().SetStrokeOpacity(1f));
                    pdfCanvas.SetStrokeColor(rrBorderColor);
                    pdfCanvas.SetLineWidth(rrBorderLeft);
                    pdfCanvas.MoveTo(boxX, boxY + boxRadiusBL);
                    pdfCanvas.LineTo(boxX, boxY + boxH - boxRadiusTL);
                    if (boxRadiusTL > 0) pdfCanvas.CurveTo(boxX, boxY + boxH - boxRadiusTL + kappaTL, boxX + boxRadiusTL - kappaTL, boxY + boxH, boxX + boxRadiusTL, boxY + boxH);
                    pdfCanvas.Stroke();
                    pdfCanvas.RestoreState();
                }
            }
            box_kasaraporudokumform_2074596522_deferredAdds.Add(box_kasaraporudokumform_672114386);
            box_kasaraporudokumform_2074596522_deferredAdds.AddRange(box_kasaraporudokumform_672114386_deferredAdds);
            }}


            //ReportTable3
            
            var kasaraporudokumform_1829869165IsVisible = true;
            var kasaraporudokumform_1829869165BackgroundColor = new DeviceRgb(0, 0, 0);
            var kasaraporudokumform_1829869165BackgroundColorOpacity = 0f;
            var widths_kasaraporudokumform_1829869165 = new List<float>();
widths_kasaraporudokumform_1829869165.Add(113.39f * pxToPtFactor);
widths_kasaraporudokumform_1829869165.Add(234.33f * pxToPtFactor);
widths_kasaraporudokumform_1829869165.Add(83.15f * pxToPtFactor);
widths_kasaraporudokumform_1829869165.Add(128.5f * pxToPtFactor);
widths_kasaraporudokumform_1829869165.Add(158.74f * pxToPtFactor);
var designWidth_kasaraporudokumform_1829869165 = 718.11f * pxToPtFactor;
var tableWidth_kasaraporudokumform_1829869165 = (widths_kasaraporudokumform_1829869165.Sum() / designWidth_kasaraporudokumform_1829869165) * (718.11f * pxToPtFactor);

            Table kasaraporudokumform_1829869165 = new Table(widths_kasaraporudokumform_1829869165.ToArray()).SetWidth(tableWidth_kasaraporudokumform_1829869165)
            .SetBackgroundColor(kasaraporudokumform_1829869165BackgroundColor, kasaraporudokumform_1829869165BackgroundColorOpacity)
            .SetVisible(kasaraporudokumform_1829869165IsVisible)
            .SetMarginBottom(0 * pxToPtFactor)
            .SetMarginLeft(0 * pxToPtFactor)
            .SetMarginTop(0 * pxToPtFactor)
            .SetMarginRight(0 * pxToPtFactor);
            
            kasaraporudokumform_1829869165.SetBorderBottom(new SolidBorder(new DeviceRgb(218, 218, 218), 1 * pxToPtFactor, 1f));
            kasaraporudokumform_1829869165.SetBorderTop(new SolidBorder(new DeviceRgb(218, 218, 218), 1 * pxToPtFactor, 1f));
            kasaraporudokumform_1829869165.SetBorderRight(new SolidBorder(new DeviceRgb(218, 218, 218), 1 * pxToPtFactor, 1f));
            kasaraporudokumform_1829869165.SetBorderLeft(new SolidBorder(new DeviceRgb(218, 218, 218), 1 * pxToPtFactor, 1f));
            kasaraporudokumform_1829869165.SetBorderRadius(new BorderRadius(0f * pxToPtFactor));
            kasaraporudokumform_1829869165.SetFixedLayout();
            Color kasaraporudokumform_1829869165borderColor = new DeviceRgb(240, 240, 240);
            Border kasaraporudokumform_1829869165leftBorder = new SolidBorder(kasaraporudokumform_1829869165borderColor, 1 * pxToPtFactor);
            if (kasaraporudokumform_1829869165IsVisible)
            {
                
            List<String> columnValueNames_kasaraporudokumform_1829869165 = new List<String>() {"CurrAccCode", "CurrAccDescription", "Doc_CurrencyCode", "Doc_Amount", "Loc_Amount"};
            
            var kasaraporudokumform_1829869165_ColumTitlesPropValue = "";
            var kasaraporudokumform_1829869165_ColumnTitles = new List<string>();
            if(kasaraporudokumform_1829869165_ColumTitlesPropValue != null) {
               kasaraporudokumform_1829869165_ColumnTitles = kasaraporudokumform_1829869165_ColumTitlesPropValue.ToString()?.Split(";", StringSplitOptions.RemoveEmptyEntries).ToList();
            }
        
            
            Cell cell_0 = new Cell(1, 1);
            //cell_0.SetBorder(iText.Layout.Borders.Border.NO_BORDER)
            cell_0.SetBackgroundColor(new DeviceRgb(0, 0, 0), 0f);
            cell_0.SetBorderBottom(Border.NO_BORDER);
            cell_0.SetBorderTop(Border.NO_BORDER);
            cell_0.SetBorderRight(Border.NO_BORDER);
            cell_0.SetBorderLeft(Border.NO_BORDER);
            cell_0.SetBorderRadius(new BorderRadius(0f * pxToPtFactor));
            
            
            cell_0.SetPaddingBottom(0 * pxToPtFactor).SetPaddingLeft(0 * pxToPtFactor)
            .SetPaddingTop(0 * pxToPtFactor).SetPaddingRight(0 * pxToPtFactor).SetFontSize(14 * pxToPtFactor)
            .SetFont(fontDictionary["poppins_regular"]).SetFontColor(new DeviceRgb(155, 155, 155), 1f)
            .SetTextAlignment(iText.Layout.Properties.TextAlignment.LEFT);
            var headerParagraph_0 = new Paragraph((kasaraporudokumform_1829869165_ColumnTitles is { Count: >= (0 + 1) } ? kasaraporudokumform_1829869165_ColumnTitles[0] : kasaraporudokumform_1829869165_ColumnTitles.Any() ? "" : ("Kasa Kodu".ConvertToType<String>())))
            
            .WithGlyphFallback(fontDictionary, "poppins_regular", () => cjkFallbackFont.Value);
            cell_0.Add(headerParagraph_0);
            
            cell_0.SetVisible(true);
            kasaraporudokumform_1829869165.AddHeaderCell(cell_0);


            Cell cell_1 = new Cell(1, 1);
            //cell_1.SetBorder(iText.Layout.Borders.Border.NO_BORDER)
            cell_1.SetBackgroundColor(new DeviceRgb(0, 0, 0), 0f);
            cell_1.SetBorderBottom(Border.NO_BORDER);
            cell_1.SetBorderTop(Border.NO_BORDER);
            cell_1.SetBorderRight(Border.NO_BORDER);
            cell_1.SetBorderLeft(Border.NO_BORDER);
            cell_1.SetBorderRadius(new BorderRadius(0f * pxToPtFactor));
            
            if(true){cell_1.SetBorderLeft(kasaraporudokumform_1829869165leftBorder);}
            cell_1.SetPaddingBottom(0 * pxToPtFactor).SetPaddingLeft(0 * pxToPtFactor)
            .SetPaddingTop(0 * pxToPtFactor).SetPaddingRight(0 * pxToPtFactor).SetFontSize(14 * pxToPtFactor)
            .SetFont(fontDictionary["poppins_regular"]).SetFontColor(new DeviceRgb(155, 155, 155), 1f)
            .SetTextAlignment(iText.Layout.Properties.TextAlignment.LEFT);
            var headerParagraph_1 = new Paragraph((kasaraporudokumform_1829869165_ColumnTitles is { Count: >= (1 + 1) } ? kasaraporudokumform_1829869165_ColumnTitles[1] : kasaraporudokumform_1829869165_ColumnTitles.Any() ? "" : ("Kasa Adı".ConvertToType<String>())))
            
            .WithGlyphFallback(fontDictionary, "poppins_regular", () => cjkFallbackFont.Value);
            cell_1.Add(headerParagraph_1);
            
            cell_1.SetVisible(true);
            kasaraporudokumform_1829869165.AddHeaderCell(cell_1);


            Cell cell_2 = new Cell(1, 1);
            //cell_2.SetBorder(iText.Layout.Borders.Border.NO_BORDER)
            cell_2.SetBackgroundColor(new DeviceRgb(0, 0, 0), 0f);
            cell_2.SetBorderBottom(Border.NO_BORDER);
            cell_2.SetBorderTop(Border.NO_BORDER);
            cell_2.SetBorderRight(Border.NO_BORDER);
            cell_2.SetBorderLeft(Border.NO_BORDER);
            cell_2.SetBorderRadius(new BorderRadius(0f * pxToPtFactor));
            
            if(true){cell_2.SetBorderLeft(kasaraporudokumform_1829869165leftBorder);}
            cell_2.SetPaddingBottom(0 * pxToPtFactor).SetPaddingLeft(0 * pxToPtFactor)
            .SetPaddingTop(0 * pxToPtFactor).SetPaddingRight(0 * pxToPtFactor).SetFontSize(14 * pxToPtFactor)
            .SetFont(fontDictionary["poppins_regular"]).SetFontColor(new DeviceRgb(155, 155, 155), 1f)
            .SetTextAlignment(iText.Layout.Properties.TextAlignment.LEFT);
            var headerParagraph_2 = new Paragraph((kasaraporudokumform_1829869165_ColumnTitles is { Count: >= (2 + 1) } ? kasaraporudokumform_1829869165_ColumnTitles[2] : kasaraporudokumform_1829869165_ColumnTitles.Any() ? "" : ("Para Birimi".ConvertToType<String>())))
            
            .WithGlyphFallback(fontDictionary, "poppins_regular", () => cjkFallbackFont.Value);
            cell_2.Add(headerParagraph_2);
            
            cell_2.SetVisible(true);
            kasaraporudokumform_1829869165.AddHeaderCell(cell_2);


            Cell cell_3 = new Cell(1, 1);
            //cell_3.SetBorder(iText.Layout.Borders.Border.NO_BORDER)
            cell_3.SetBackgroundColor(new DeviceRgb(0, 0, 0), 0f);
            cell_3.SetBorderBottom(Border.NO_BORDER);
            cell_3.SetBorderTop(Border.NO_BORDER);
            cell_3.SetBorderRight(Border.NO_BORDER);
            cell_3.SetBorderLeft(Border.NO_BORDER);
            cell_3.SetBorderRadius(new BorderRadius(0f * pxToPtFactor));
            
            if(true){cell_3.SetBorderLeft(kasaraporudokumform_1829869165leftBorder);}
            cell_3.SetPaddingBottom(0 * pxToPtFactor).SetPaddingLeft(0 * pxToPtFactor)
            .SetPaddingTop(0 * pxToPtFactor).SetPaddingRight(0 * pxToPtFactor).SetFontSize(14 * pxToPtFactor)
            .SetFont(fontDictionary["poppins_regular"]).SetFontColor(new DeviceRgb(155, 155, 155), 1f)
            .SetTextAlignment(iText.Layout.Properties.TextAlignment.LEFT);
            var headerParagraph_3 = new Paragraph((kasaraporudokumform_1829869165_ColumnTitles is { Count: >= (3 + 1) } ? kasaraporudokumform_1829869165_ColumnTitles[3] : kasaraporudokumform_1829869165_ColumnTitles.Any() ? "" : ("Devir Bakiyesi".ConvertToType<String>())))
            
            .WithGlyphFallback(fontDictionary, "poppins_regular", () => cjkFallbackFont.Value);
            cell_3.Add(headerParagraph_3);
            
            cell_3.SetVisible(true);
            kasaraporudokumform_1829869165.AddHeaderCell(cell_3);


            Cell cell_4 = new Cell(1, 1);
            //cell_4.SetBorder(iText.Layout.Borders.Border.NO_BORDER)
            cell_4.SetBackgroundColor(new DeviceRgb(0, 0, 0), 0f);
            cell_4.SetBorderBottom(Border.NO_BORDER);
            cell_4.SetBorderTop(Border.NO_BORDER);
            cell_4.SetBorderRight(Border.NO_BORDER);
            cell_4.SetBorderLeft(Border.NO_BORDER);
            cell_4.SetBorderRadius(new BorderRadius(0f * pxToPtFactor));
            
            if(true){cell_4.SetBorderLeft(kasaraporudokumform_1829869165leftBorder);}
            cell_4.SetPaddingBottom(0 * pxToPtFactor).SetPaddingLeft(0 * pxToPtFactor)
            .SetPaddingTop(0 * pxToPtFactor).SetPaddingRight(0 * pxToPtFactor).SetFontSize(14 * pxToPtFactor)
            .SetFont(fontDictionary["poppins_regular"]).SetFontColor(new DeviceRgb(155, 155, 155), 1f)
            .SetTextAlignment(iText.Layout.Properties.TextAlignment.LEFT);
            var headerParagraph_4 = new Paragraph((kasaraporudokumform_1829869165_ColumnTitles is { Count: >= (4 + 1) } ? kasaraporudokumform_1829869165_ColumnTitles[4] : kasaraporudokumform_1829869165_ColumnTitles.Any() ? "" : ("Devir Bakiyesi TRY ".ConvertToType<String>())))
            
            .WithGlyphFallback(fontDictionary, "poppins_regular", () => cjkFallbackFont.Value);
            cell_4.Add(headerParagraph_4);
            
            cell_4.SetVisible(true);
            kasaraporudokumform_1829869165.AddHeaderCell(cell_4);


            
            var rowBackgroundColor = new DeviceRgb(0, 0, 0);
            var rowOpacity = 0;
            var isStriped = false;
            Color stripedColor = new DeviceRgb(245, 247, 250);
            for(int i = 0; i < result.Kuika_NakitDevirler3.Count; i++)
              {
                  var item = result.Kuika_NakitDevirler3[i];
                  Color backgroundColor = new DeviceRgb(255, 255, 255);
                  float backgroundColorOpacity = 0f;

                  if (kasaraporudokumform_1829869165BackgroundColorOpacity == 1) {{
                        backgroundColor = kasaraporudokumform_1829869165BackgroundColor;
                        backgroundColorOpacity = 1f;
                  }}

                  if (rowOpacity == 1) {{
                        backgroundColor = rowBackgroundColor;
                        backgroundColorOpacity = 1f;
                  }}

                  if (isStriped && i % 2 != 0) {{
                        backgroundColor = stripedColor;
                        backgroundColorOpacity = 1f;
                  }}

                  
                
            var colData_0547130812 = new Paragraph(item.CurrAccCode.ToFormattedString("", "", "") ?? "")
            .SetMarginBottom(0 * pxToPtFactor).SetMarginLeft(0 * pxToPtFactor)
            .SetMarginTop(0 * pxToPtFactor).SetMarginRight(0 * pxToPtFactor)
            .SetFontColor(new DeviceRgb(68, 68, 68), 1f)
            .SetBackgroundColor(new DeviceRgb(0, 0, 0), 0f)
            .SetFontSize(12 * pxToPtFactor)
            .SetFont(fontDictionary["poppins_regular"])
            .WithGlyphFallback(fontDictionary, "poppins_regular", () => cjkFallbackFont.Value)
            
            .SetParagraphWidthAndExtendHeightIfNotFit(document, 31.57f * pxToPtFactor, 20f * pxToPtFactor, true)
            .SetVisible(true)
            .SetVerticalAlignment(VerticalAlignment.TOP)
            .SetHorizontalAlignment(HorizontalAlignment.LEFT)
            .SetTextAlignment(TextAlignment.LEFT)
            .SetMultipliedLeading(1f);
            
colData_0547130812.SetVisible(true);

                Cell cell_547130812 = new Cell(1, 1);
                var cell_547130812BackgroundColor = new DeviceRgb(0, 0, 0);
                var cell_547130812BackgroundColorOpacity = 0;
                
                cell_547130812.SetMinHeight(40 * pxToPtFactor);
                //cell_547130812.SetBorder(iText.Layout.Borders.Border.NO_BORDER);
                cell_547130812.SetBorderBottom(Border.NO_BORDER);
                cell_547130812.SetBorderTop(Border.NO_BORDER);
                cell_547130812.SetBorderRight(Border.NO_BORDER);
                cell_547130812.SetBorderLeft(Border.NO_BORDER);
                cell_547130812.SetBorderRadius(new BorderRadius(0f * pxToPtFactor));
                //cell_547130812.Add(colData_547130812);
                if (cell_547130812BackgroundColorOpacity == 1)
                    cell_547130812.SetBackgroundColor(cell_547130812BackgroundColor);
                else if (backgroundColorOpacity == 1)
                    cell_547130812.SetBackgroundColor(backgroundColor);
                cell_547130812.SetVerticalAlignment(iText.Layout.Properties.VerticalAlignment.TOP);
                cell_547130812.SetTextAlignment(iText.Layout.Properties.TextAlignment.LEFT);
                cell_547130812.SetPaddingBottom(0 * pxToPtFactor).SetPaddingLeft(0 * pxToPtFactor)
                .SetPaddingTop(0 * pxToPtFactor).SetPaddingRight(0 * pxToPtFactor);
                
                kasaraporudokumform_1829869165.AddCell(cell_547130812);

cell_547130812.Add(colData_0547130812);

                
            var colData_01428598571 = new Paragraph(item.CurrAccDescription.ToFormattedString("", "", "") ?? "")
            .SetMarginBottom(0 * pxToPtFactor).SetMarginLeft(0 * pxToPtFactor)
            .SetMarginTop(0 * pxToPtFactor).SetMarginRight(0 * pxToPtFactor)
            .SetFontColor(new DeviceRgb(68, 68, 68), 1f)
            .SetBackgroundColor(new DeviceRgb(0, 0, 0), 0f)
            .SetFontSize(12 * pxToPtFactor)
            .SetFont(fontDictionary["poppins_regular"])
            .WithGlyphFallback(fontDictionary, "poppins_regular", () => cjkFallbackFont.Value)
            
            .SetParagraphWidthAndExtendHeightIfNotFit(document, 31.57f * pxToPtFactor, 20f * pxToPtFactor, true)
            .SetVisible(true)
            .SetVerticalAlignment(VerticalAlignment.TOP)
            .SetHorizontalAlignment(HorizontalAlignment.LEFT)
            .SetTextAlignment(TextAlignment.LEFT)
            .SetMultipliedLeading(1f);
            
colData_01428598571.SetVisible(true);

                Cell cell_1428598571 = new Cell(1, 1);
                var cell_1428598571BackgroundColor = new DeviceRgb(0, 0, 0);
                var cell_1428598571BackgroundColorOpacity = 0;
                
                cell_1428598571.SetMinHeight(40 * pxToPtFactor);
                //cell_1428598571.SetBorder(iText.Layout.Borders.Border.NO_BORDER);
                cell_1428598571.SetBorderBottom(Border.NO_BORDER);
                cell_1428598571.SetBorderTop(Border.NO_BORDER);
                cell_1428598571.SetBorderRight(Border.NO_BORDER);
                cell_1428598571.SetBorderLeft(Border.NO_BORDER);
                cell_1428598571.SetBorderRadius(new BorderRadius(0f * pxToPtFactor));
                //cell_1428598571.Add(colData_1428598571);
                if (cell_1428598571BackgroundColorOpacity == 1)
                    cell_1428598571.SetBackgroundColor(cell_1428598571BackgroundColor);
                else if (backgroundColorOpacity == 1)
                    cell_1428598571.SetBackgroundColor(backgroundColor);
                cell_1428598571.SetVerticalAlignment(iText.Layout.Properties.VerticalAlignment.TOP);
                cell_1428598571.SetTextAlignment(iText.Layout.Properties.TextAlignment.LEFT);
                cell_1428598571.SetPaddingBottom(0 * pxToPtFactor).SetPaddingLeft(0 * pxToPtFactor)
                .SetPaddingTop(0 * pxToPtFactor).SetPaddingRight(0 * pxToPtFactor);
                
                kasaraporudokumform_1829869165.AddCell(cell_1428598571);

cell_1428598571.Add(colData_01428598571);

                
            var colData_01797034471 = new Paragraph(item.Doc_CurrencyCode.ToFormattedString("", "", "") ?? "")
            .SetMarginBottom(0 * pxToPtFactor).SetMarginLeft(0 * pxToPtFactor)
            .SetMarginTop(0 * pxToPtFactor).SetMarginRight(0 * pxToPtFactor)
            .SetFontColor(new DeviceRgb(68, 68, 68), 1f)
            .SetBackgroundColor(new DeviceRgb(0, 0, 0), 0f)
            .SetFontSize(12 * pxToPtFactor)
            .SetFont(fontDictionary["poppins_regular"])
            .WithGlyphFallback(fontDictionary, "poppins_regular", () => cjkFallbackFont.Value)
            
            .SetParagraphWidthAndExtendHeightIfNotFit(document, 31.57f * pxToPtFactor, 20f * pxToPtFactor, true)
            .SetVisible(true)
            .SetVerticalAlignment(VerticalAlignment.TOP)
            .SetHorizontalAlignment(HorizontalAlignment.LEFT)
            .SetTextAlignment(TextAlignment.LEFT)
            .SetMultipliedLeading(1f);
            
colData_01797034471.SetVisible(true);

                Cell cell_1797034471 = new Cell(1, 1);
                var cell_1797034471BackgroundColor = new DeviceRgb(0, 0, 0);
                var cell_1797034471BackgroundColorOpacity = 0;
                
                cell_1797034471.SetMinHeight(40 * pxToPtFactor);
                //cell_1797034471.SetBorder(iText.Layout.Borders.Border.NO_BORDER);
                cell_1797034471.SetBorderBottom(Border.NO_BORDER);
                cell_1797034471.SetBorderTop(Border.NO_BORDER);
                cell_1797034471.SetBorderRight(Border.NO_BORDER);
                cell_1797034471.SetBorderLeft(Border.NO_BORDER);
                cell_1797034471.SetBorderRadius(new BorderRadius(0f * pxToPtFactor));
                //cell_1797034471.Add(colData_1797034471);
                if (cell_1797034471BackgroundColorOpacity == 1)
                    cell_1797034471.SetBackgroundColor(cell_1797034471BackgroundColor);
                else if (backgroundColorOpacity == 1)
                    cell_1797034471.SetBackgroundColor(backgroundColor);
                cell_1797034471.SetVerticalAlignment(iText.Layout.Properties.VerticalAlignment.TOP);
                cell_1797034471.SetTextAlignment(iText.Layout.Properties.TextAlignment.LEFT);
                cell_1797034471.SetPaddingBottom(0 * pxToPtFactor).SetPaddingLeft(0 * pxToPtFactor)
                .SetPaddingTop(0 * pxToPtFactor).SetPaddingRight(0 * pxToPtFactor);
                
                kasaraporudokumform_1829869165.AddCell(cell_1797034471);

cell_1797034471.Add(colData_01797034471);

                
            var colData_01931573215 = new Paragraph(item.Doc_Amount.ToFormattedString("", "", "") ?? "")
            .SetMarginBottom(0 * pxToPtFactor).SetMarginLeft(0 * pxToPtFactor)
            .SetMarginTop(0 * pxToPtFactor).SetMarginRight(0 * pxToPtFactor)
            .SetFontColor(new DeviceRgb(68, 68, 68), 1f)
            .SetBackgroundColor(new DeviceRgb(0, 0, 0), 0f)
            .SetFontSize(12 * pxToPtFactor)
            .SetFont(fontDictionary["poppins_regular"])
            .WithGlyphFallback(fontDictionary, "poppins_regular", () => cjkFallbackFont.Value)
            
            .SetParagraphWidthAndExtendHeightIfNotFit(document, 31.57f * pxToPtFactor, 20f * pxToPtFactor, true)
            .SetVisible(true)
            .SetVerticalAlignment(VerticalAlignment.TOP)
            .SetHorizontalAlignment(HorizontalAlignment.LEFT)
            .SetTextAlignment(TextAlignment.LEFT)
            .SetMultipliedLeading(1f);
            
colData_01931573215.SetVisible(true);

                Cell cell_1931573215 = new Cell(1, 1);
                var cell_1931573215BackgroundColor = new DeviceRgb(0, 0, 0);
                var cell_1931573215BackgroundColorOpacity = 0;
                
                cell_1931573215.SetMinHeight(40 * pxToPtFactor);
                //cell_1931573215.SetBorder(iText.Layout.Borders.Border.NO_BORDER);
                cell_1931573215.SetBorderBottom(Border.NO_BORDER);
                cell_1931573215.SetBorderTop(Border.NO_BORDER);
                cell_1931573215.SetBorderRight(Border.NO_BORDER);
                cell_1931573215.SetBorderLeft(Border.NO_BORDER);
                cell_1931573215.SetBorderRadius(new BorderRadius(0f * pxToPtFactor));
                //cell_1931573215.Add(colData_1931573215);
                if (cell_1931573215BackgroundColorOpacity == 1)
                    cell_1931573215.SetBackgroundColor(cell_1931573215BackgroundColor);
                else if (backgroundColorOpacity == 1)
                    cell_1931573215.SetBackgroundColor(backgroundColor);
                cell_1931573215.SetVerticalAlignment(iText.Layout.Properties.VerticalAlignment.TOP);
                cell_1931573215.SetTextAlignment(iText.Layout.Properties.TextAlignment.LEFT);
                cell_1931573215.SetPaddingBottom(0 * pxToPtFactor).SetPaddingLeft(0 * pxToPtFactor)
                .SetPaddingTop(0 * pxToPtFactor).SetPaddingRight(0 * pxToPtFactor);
                
                kasaraporudokumform_1829869165.AddCell(cell_1931573215);

cell_1931573215.Add(colData_01931573215);

                
            var colData_01053646608 = new Paragraph(item.Loc_Amount.ToFormattedString("", "", "") ?? "")
            .SetMarginBottom(0 * pxToPtFactor).SetMarginLeft(0 * pxToPtFactor)
            .SetMarginTop(0 * pxToPtFactor).SetMarginRight(0 * pxToPtFactor)
            .SetFontColor(new DeviceRgb(68, 68, 68), 1f)
            .SetBackgroundColor(new DeviceRgb(0, 0, 0), 0f)
            .SetFontSize(12 * pxToPtFactor)
            .SetFont(fontDictionary["poppins_regular"])
            .WithGlyphFallback(fontDictionary, "poppins_regular", () => cjkFallbackFont.Value)
            
            .SetParagraphWidthAndExtendHeightIfNotFit(document, 31.57f * pxToPtFactor, 20f * pxToPtFactor, true)
            .SetVisible(true)
            .SetVerticalAlignment(VerticalAlignment.TOP)
            .SetHorizontalAlignment(HorizontalAlignment.LEFT)
            .SetTextAlignment(TextAlignment.LEFT)
            .SetMultipliedLeading(1f);
            
colData_01053646608.SetVisible(true);

                Cell cell_1053646608 = new Cell(1, 1);
                var cell_1053646608BackgroundColor = new DeviceRgb(0, 0, 0);
                var cell_1053646608BackgroundColorOpacity = 0;
                
                cell_1053646608.SetMinHeight(40 * pxToPtFactor);
                //cell_1053646608.SetBorder(iText.Layout.Borders.Border.NO_BORDER);
                cell_1053646608.SetBorderBottom(Border.NO_BORDER);
                cell_1053646608.SetBorderTop(Border.NO_BORDER);
                cell_1053646608.SetBorderRight(Border.NO_BORDER);
                cell_1053646608.SetBorderLeft(Border.NO_BORDER);
                cell_1053646608.SetBorderRadius(new BorderRadius(0f * pxToPtFactor));
                //cell_1053646608.Add(colData_1053646608);
                if (cell_1053646608BackgroundColorOpacity == 1)
                    cell_1053646608.SetBackgroundColor(cell_1053646608BackgroundColor);
                else if (backgroundColorOpacity == 1)
                    cell_1053646608.SetBackgroundColor(backgroundColor);
                cell_1053646608.SetVerticalAlignment(iText.Layout.Properties.VerticalAlignment.TOP);
                cell_1053646608.SetTextAlignment(iText.Layout.Properties.TextAlignment.LEFT);
                cell_1053646608.SetPaddingBottom(0 * pxToPtFactor).SetPaddingLeft(0 * pxToPtFactor)
                .SetPaddingTop(0 * pxToPtFactor).SetPaddingRight(0 * pxToPtFactor);
                
                kasaraporudokumform_1829869165.AddCell(cell_1053646608);

cell_1053646608.Add(colData_01053646608);

              }



            kasaraporudokumform_1829869165.SetMarginLeft(10f * pxToPtFactor + 0f * pxToPtFactor);
            if (Math.Abs(790f * pxToPtFactor) > 0) {{
               kasaraporudokumform_1829869165.SetMarginTop(Math.Abs(790f * pxToPtFactor) + 0f * pxToPtFactor);
            }}
            kasaraporudokumform_2074596522_cell.Add(kasaraporudokumform_1829869165);
        }

   
            kasaraporudokumform_2074596522_cell.SetVisible(box_kasaraporudokumform_2074596522.IsVisible());
            box_kasaraporudokumform_2074596522.AddCell(kasaraporudokumform_2074596522_cell);
            
            // Draw rounded rectangle with PdfCanvas for border-radius support
            {
                var boxX = 10f * pxToPtFactor;
                var boxAbsY = Math.Abs(750f * pxToPtFactor);
                var boxPageRelY = boxAbsY - pageStartY;
                var boxY = ((currentPageHeight > 0 ? currentPageHeight : canvasHeight.Value) - (boxPageRelY + Math.Abs(219f * pxToPtFactor)));
                var boxW = 780f * pxToPtFactor;
                var boxH = 219f * pxToPtFactor;
                var boxRadiusTL = 6f * pxToPtFactor;
                var boxRadiusTR = 6f * pxToPtFactor;
                var boxRadiusBR = 6f * pxToPtFactor;
                var boxRadiusBL = 6f * pxToPtFactor;
                float kappaTL = boxRadiusTL * 0.5522848f;
                float kappaTR = boxRadiusTR * 0.5522848f;
                float kappaBR = boxRadiusBR * 0.5522848f;
                float kappaBL = boxRadiusBL * 0.5522848f;
                var currentPage = pdf.GetPage(pdf.GetNumberOfPages());
                var pdfCanvas = new PdfCanvas(currentPage);

                // Draw rounded background with alpha support
                pdfCanvas.SaveState();
                pdfCanvas.SetExtGState(new PdfExtGState().SetFillOpacity(1f));
                pdfCanvas.SetFillColor(new DeviceRgb(255, 255, 255));
                pdfCanvas.MoveTo(boxX + boxRadiusBL, boxY);
                pdfCanvas.LineTo(boxX + boxW - boxRadiusBR, boxY);
                if (boxRadiusBR > 0) pdfCanvas.CurveTo(boxX + boxW - boxRadiusBR + kappaBR, boxY, boxX + boxW, boxY + boxRadiusBR - kappaBR, boxX + boxW, boxY + boxRadiusBR);
                pdfCanvas.LineTo(boxX + boxW, boxY + boxH - boxRadiusTR);
                if (boxRadiusTR > 0) pdfCanvas.CurveTo(boxX + boxW, boxY + boxH - boxRadiusTR + kappaTR, boxX + boxW - boxRadiusTR + kappaTR, boxY + boxH, boxX + boxW - boxRadiusTR, boxY + boxH);
                pdfCanvas.LineTo(boxX + boxRadiusTL, boxY + boxH);
                if (boxRadiusTL > 0) pdfCanvas.CurveTo(boxX + boxRadiusTL - kappaTL, boxY + boxH, boxX, boxY + boxH - boxRadiusTL + kappaTL, boxX, boxY + boxH - boxRadiusTL);
                pdfCanvas.LineTo(boxX, boxY + boxRadiusBL);
                if (boxRadiusBL > 0) pdfCanvas.CurveTo(boxX, boxY + boxRadiusBL - kappaBL, boxX + boxRadiusBL - kappaBL, boxY, boxX + boxRadiusBL, boxY);
                pdfCanvas.ClosePath();
                pdfCanvas.Fill();
                pdfCanvas.RestoreState();

                // Draw individual border edges with per-side widths
                var rrBorderColor = new DeviceRgb(238, 242, 246);
                float rrBorderTop = 1f * pxToPtFactor;
                float rrBorderRight = 1f * pxToPtFactor;
                float rrBorderBottom = 1f * pxToPtFactor;
                float rrBorderLeft = 1f * pxToPtFactor;

                // Top border (uses TL and TR corners)
                if (rrBorderTop > 0)
                {
                    pdfCanvas.SaveState();
                    pdfCanvas.SetExtGState(new PdfExtGState().SetStrokeOpacity(1f));
                    pdfCanvas.SetStrokeColor(rrBorderColor);
                    pdfCanvas.SetLineWidth(rrBorderTop);
                    pdfCanvas.MoveTo(boxX + boxRadiusTL, boxY + boxH);
                    pdfCanvas.LineTo(boxX + boxW - boxRadiusTR, boxY + boxH);
                    if (boxRadiusTR > 0) pdfCanvas.CurveTo(boxX + boxW - boxRadiusTR + kappaTR, boxY + boxH, boxX + boxW, boxY + boxH - boxRadiusTR + kappaTR, boxX + boxW, boxY + boxH - boxRadiusTR);
                    pdfCanvas.Stroke();
                    pdfCanvas.RestoreState();
                }

                // Right border (uses TR and BR corners)
                if (rrBorderRight > 0)
                {
                    pdfCanvas.SaveState();
                    pdfCanvas.SetExtGState(new PdfExtGState().SetStrokeOpacity(1f));
                    pdfCanvas.SetStrokeColor(rrBorderColor);
                    pdfCanvas.SetLineWidth(rrBorderRight);
                    pdfCanvas.MoveTo(boxX + boxW, boxY + boxH - boxRadiusTR);
                    pdfCanvas.LineTo(boxX + boxW, boxY + boxRadiusBR);
                    if (boxRadiusBR > 0) pdfCanvas.CurveTo(boxX + boxW, boxY + boxRadiusBR - kappaBR, boxX + boxW - boxRadiusBR + kappaBR, boxY, boxX + boxW - boxRadiusBR, boxY);
                    pdfCanvas.Stroke();
                    pdfCanvas.RestoreState();
                }

                // Bottom border (uses BR and BL corners)
                if (rrBorderBottom > 0)
                {
                    pdfCanvas.SaveState();
                    pdfCanvas.SetExtGState(new PdfExtGState().SetStrokeOpacity(1f));
                    pdfCanvas.SetStrokeColor(rrBorderColor);
                    pdfCanvas.SetLineWidth(rrBorderBottom);
                    pdfCanvas.MoveTo(boxX + boxW - boxRadiusBR, boxY);
                    pdfCanvas.LineTo(boxX + boxRadiusBL, boxY);
                    if (boxRadiusBL > 0) pdfCanvas.CurveTo(boxX + boxRadiusBL - kappaBL, boxY, boxX, boxY + boxRadiusBL - kappaBL, boxX, boxY + boxRadiusBL);
                    pdfCanvas.Stroke();
                    pdfCanvas.RestoreState();
                }

                // Left border (uses BL and TL corners)
                if (rrBorderLeft > 0)
                {
                    pdfCanvas.SaveState();
                    pdfCanvas.SetExtGState(new PdfExtGState().SetStrokeOpacity(1f));
                    pdfCanvas.SetStrokeColor(rrBorderColor);
                    pdfCanvas.SetLineWidth(rrBorderLeft);
                    pdfCanvas.MoveTo(boxX, boxY + boxRadiusBL);
                    pdfCanvas.LineTo(boxX, boxY + boxH - boxRadiusTL);
                    if (boxRadiusTL > 0) pdfCanvas.CurveTo(boxX, boxY + boxH - boxRadiusTL + kappaTL, boxX + boxRadiusTL - kappaTL, boxY + boxH, boxX + boxRadiusTL, boxY + boxH);
                    pdfCanvas.Stroke();
                    pdfCanvas.RestoreState();
                }
            }
            document.Add(box_kasaraporudokumform_2074596522);
            foreach (var deferredElem in box_kasaraporudokumform_2074596522_deferredAdds) document.Add(deferredElem);
            }}


            //Box8
            Table box_kasaraporudokumform_1250919818 = new Table(1).SetWidth(780f * pxToPtFactor).SetHeight(222f * pxToPtFactor)
            .SetFontColor(new DeviceRgb(0, 0, 0), 1f)
            .SetFontSize(20 * pxToPtFactor)
            .SetVisible(true);
            if (box_kasaraporudokumform_1250919818.IsVisible()) {{
            var box_kasaraporudokumform_1250919818_pageLeftX = (double)(10f * pxToPtFactor) ;
            var box_kasaraporudokumform_1250919818_pageTopY = 0d;
            var box_kasaraporudokumform_1250919818_deferredAdds = new List<IBlockElement>();
            if (!false) {
            // Calculate page-relative Y position
            var box_kasaraporudokumform_1250919818_absoluteY = Math.Abs(1040f * pxToPtFactor);
            var box_kasaraporudokumform_1250919818_pageRelativeY = box_kasaraporudokumform_1250919818_absoluteY - pageStartY;
            int box_kasaraporudokumform_1250919818_targetPage = pdf.GetNumberOfPages();
            
            box_kasaraporudokumform_1250919818.SetFixedPosition(box_kasaraporudokumform_1250919818_targetPage, 10f * pxToPtFactor , ((currentPageHeight > 0 ? currentPageHeight : canvasHeight.Value) - (box_kasaraporudokumform_1250919818_pageRelativeY + Math.Abs(222f * pxToPtFactor))) , 780f * pxToPtFactor);
            box_kasaraporudokumform_1250919818_pageTopY = ((double)(currentPageHeight > 0 ? currentPageHeight : canvasHeight.Value) - box_kasaraporudokumform_1250919818_pageRelativeY) ;
            } else {
            box_kasaraporudokumform_1250919818.SetFixedPosition(10f * pxToPtFactor , ((currentPageHeight > 0 ? currentPageHeight : canvasHeight.Value) - (totalHeight + Math.Abs(1040f * pxToPtFactor) + Math.Abs(222f * pxToPtFactor))) , 780f * pxToPtFactor);
            box_kasaraporudokumform_1250919818_pageTopY = ((double)(currentPageHeight > 0 ? currentPageHeight : canvasHeight.Value) - (totalHeight + Math.Abs(1040f * pxToPtFactor))) ;
            }
            box_kasaraporudokumform_1250919818.SetBorder(Border.NO_BORDER);
            box_kasaraporudokumform_1250919818.SetBorderBottom(Border.NO_BORDER);
            box_kasaraporudokumform_1250919818.SetBorderTop(Border.NO_BORDER);
            box_kasaraporudokumform_1250919818.SetBorderRight(Border.NO_BORDER);
            box_kasaraporudokumform_1250919818.SetBorderLeft(Border.NO_BORDER);
            box_kasaraporudokumform_1250919818.SetBorderRadius(new BorderRadius(6f * pxToPtFactor));
            var heightOf_box_kasaraporudokumform_1250919818 = box_kasaraporudokumform_1250919818.GetHeight();
            Cell kasaraporudokumform_1250919818_cell = new Cell();
            kasaraporudokumform_1250919818_cell.SetBackgroundColor(new DeviceRgb(255, 255, 255), 0f);
            kasaraporudokumform_1250919818_cell.SetBorder(Border.NO_BORDER);
            
            // NOTE: Box always uses SetFixedPosition above (both branches), so it does not
            // contribute to flow. The legacy "totalHeight + height > canvasHeight" areaBreak
            // that lived here was reading totalHeight produced by previous flow elements
            // (e.g. multi-page ReportTables) and spuriously creating a new page + bumping
            // pageStartY, which broke pageRelativeY for every subsequent element. Removed.

            // No page breaks - using default canvas height behavior


            //Box9
            Table box_kasaraporudokumform_1541802986 = new Table(1).SetWidth(790f * pxToPtFactor).SetHeight(30f * pxToPtFactor)
            .SetFontColor(new DeviceRgb(0, 0, 0), 1f)
            .SetFontSize(20 * pxToPtFactor)
            .SetVisible(true);
            if (box_kasaraporudokumform_1541802986.IsVisible()) {{
            var box_kasaraporudokumform_1541802986_pageLeftX = (double)(10f * pxToPtFactor) ;
            var box_kasaraporudokumform_1541802986_pageTopY = 0d;
            var box_kasaraporudokumform_1541802986_deferredAdds = new List<IBlockElement>();
            if (!false) {
            // Calculate page-relative Y position
            var box_kasaraporudokumform_1541802986_absoluteY = Math.Abs(1040f * pxToPtFactor);
            var box_kasaraporudokumform_1541802986_pageRelativeY = box_kasaraporudokumform_1541802986_absoluteY - pageStartY;
            int box_kasaraporudokumform_1541802986_targetPage = pdf.GetNumberOfPages();
            
            box_kasaraporudokumform_1541802986.SetFixedPosition(box_kasaraporudokumform_1541802986_targetPage, 10f * pxToPtFactor , ((currentPageHeight > 0 ? currentPageHeight : canvasHeight.Value) - (box_kasaraporudokumform_1541802986_pageRelativeY + Math.Abs(30f * pxToPtFactor))) , 790f * pxToPtFactor);
            box_kasaraporudokumform_1541802986_pageTopY = ((double)(currentPageHeight > 0 ? currentPageHeight : canvasHeight.Value) - box_kasaraporudokumform_1541802986_pageRelativeY) ;
            } else {
            box_kasaraporudokumform_1541802986.SetFixedPosition(10f * pxToPtFactor , ((currentPageHeight > 0 ? currentPageHeight : canvasHeight.Value) - (totalHeight + Math.Abs(1040f * pxToPtFactor) + Math.Abs(30f * pxToPtFactor))) , 790f * pxToPtFactor);
            box_kasaraporudokumform_1541802986_pageTopY = ((double)(currentPageHeight > 0 ? currentPageHeight : canvasHeight.Value) - (totalHeight + Math.Abs(1040f * pxToPtFactor))) ;
            }
            box_kasaraporudokumform_1541802986.SetBorder(Border.NO_BORDER);
            box_kasaraporudokumform_1541802986.SetBorderBottom(Border.NO_BORDER);
            box_kasaraporudokumform_1541802986.SetBorderTop(Border.NO_BORDER);
            box_kasaraporudokumform_1541802986.SetBorderRight(Border.NO_BORDER);
            box_kasaraporudokumform_1541802986.SetBorderLeft(Border.NO_BORDER);
            box_kasaraporudokumform_1541802986.SetBorderRadius(new BorderRadius(6f * pxToPtFactor));
            var heightOf_box_kasaraporudokumform_1541802986 = box_kasaraporudokumform_1541802986.GetHeight();
            Cell kasaraporudokumform_1541802986_cell = new Cell();
            kasaraporudokumform_1541802986_cell.SetBackgroundColor(new DeviceRgb(114, 194, 64), 0f);
            kasaraporudokumform_1541802986_cell.SetBorder(Border.NO_BORDER);
            
            // NOTE: Box always uses SetFixedPosition above (both branches), so it does not
            // contribute to flow. The legacy "totalHeight + height > canvasHeight" areaBreak
            // that lived here was reading totalHeight produced by previous flow elements
            // (e.g. multi-page ReportTables) and spuriously creating a new page + bumping
            // pageStartY, which broke pageRelativeY for every subsequent element. Removed.

            // No page breaks - using default canvas height behavior


            //Label12
            var label_kasaraporudokumform_1705791012_effectiveWidth = 780f * pxToPtFactor > 0 ? 780f * pxToPtFactor : (canvasWidth.Value - (10f * pxToPtFactor));
            Paragraph label_kasaraporudokumform_1705791012 = new Paragraph(@"Nakit Tahsilatlar")
            .SetFontSize(15 * pxToPtFactor)
            .SetFont(fontDictionary["poppins_bold"])
            .WithGlyphFallback(fontDictionary, "poppins_bold", () => cjkFallbackFont.Value)
            .SetTextAlignment(TextAlignment.CENTER)
            
            .SetParagraphWidthAndExtendHeightIfNotFit(document, label_kasaraporudokumform_1705791012_effectiveWidth, 20f * pxToPtFactor, false, false || false)
            .SetMultipliedLeading(0.875f);
            

            if (20f * pxToPtFactor == 0f)
            {
                label_kasaraporudokumform_1705791012.SetMaxHeight((30f * pxToPtFactor) - Math.Abs(1040f * pxToPtFactor));
            }

            label_kasaraporudokumform_1705791012.SetMarginBottom(0 * pxToPtFactor).SetMarginTop(0f);
            var label_kasaraporudokumform_1705791012_paragraphHeight = label_kasaraporudokumform_1705791012.GetHeightOfParagraph(document);
            var label_kasaraporudokumform_1705791012_vAlignOffset = 0f;
            label_kasaraporudokumform_1705791012_vAlignOffset = Math.Max(0f, (20f * pxToPtFactor - label_kasaraporudokumform_1705791012_paragraphHeight) / 2f);
            label_kasaraporudokumform_1705791012.SetMarginLeft(0 * pxToPtFactor)
            .SetMarginTop((0 * pxToPtFactor) + label_kasaraporudokumform_1705791012_vAlignOffset).SetMarginRight(0 * pxToPtFactor)
            .SetFontColor(new DeviceRgb(255, 255, 255), 1f)
            .SetVisible(true);
            
            if (false)
			{
				Paragraph label_kasaraporudokumform_1705791012_inside = new Paragraph(@"Nakit Tahsilatlar")
			   .SetFontSize(15 * pxToPtFactor)
               .SetFont(fontDictionary["poppins_bold"])
			   .WithGlyphFallback(fontDictionary, "poppins_bold", () => cjkFallbackFont.Value)
			   .SetFontColor(new DeviceRgb(255, 255, 255), 1f)
			   
			   .SetRotationAngle(0);
				label_kasaraporudokumform_1705791012.Add(label_kasaraporudokumform_1705791012_inside);
			}
            var label_kasaraporudokumform_1705791012_renderHeight = 20f * pxToPtFactor > 0 ? 20f * pxToPtFactor : label_kasaraporudokumform_1705791012_paragraphHeight;
            // Actual div height accounts for paragraph margins that may expand the Div beyond MinHeight
            // paragraphHeight was measured with MarginTop=0, but actual MarginTop = paddingTop + vAlignOffset
            var label_kasaraporudokumform_1705791012_divHeight = Math.Max(label_kasaraporudokumform_1705791012_renderHeight, label_kasaraporudokumform_1705791012_paragraphHeight + (0 * pxToPtFactor) + label_kasaraporudokumform_1705791012_vAlignOffset);
            var div_label_kasaraporudokumform_1705791012 = new Div();
            div_label_kasaraporudokumform_1705791012.SetMinHeight(label_kasaraporudokumform_1705791012_renderHeight);
            div_label_kasaraporudokumform_1705791012.SetBackgroundColor(new DeviceRgb(0, 0, 0), 0f);
            div_label_kasaraporudokumform_1705791012.SetBorderBottom(Border.NO_BORDER);
            div_label_kasaraporudokumform_1705791012.SetBorderTop(Border.NO_BORDER);
            div_label_kasaraporudokumform_1705791012.SetBorderRight(Border.NO_BORDER);
            div_label_kasaraporudokumform_1705791012.SetBorderLeft(Border.NO_BORDER);
            div_label_kasaraporudokumform_1705791012.SetBorderRadius(new BorderRadius(0f * pxToPtFactor));
            div_label_kasaraporudokumform_1705791012.Add(label_kasaraporudokumform_1705791012);
            
            // Label/Icon inside Box: use box page coordinates for absolute positioning
            var label_kasaraporudokumform_1705791012_yPos = box_kasaraporudokumform_1541802986_pageTopY - (0f * pxToPtFactor) - label_kasaraporudokumform_1705791012_divHeight;
            div_label_kasaraporudokumform_1705791012.SetFixedPosition((float)(box_kasaraporudokumform_1541802986_pageLeftX + (0f * pxToPtFactor)), (float)label_kasaraporudokumform_1705791012_yPos, label_kasaraporudokumform_1705791012_effectiveWidth);
            div_label_kasaraporudokumform_1705791012.SetVisible(true);
            box_kasaraporudokumform_1541802986_deferredAdds.Add(div_label_kasaraporudokumform_1705791012);

            kasaraporudokumform_1541802986_cell.SetVisible(box_kasaraporudokumform_1541802986.IsVisible());
            box_kasaraporudokumform_1541802986.AddCell(kasaraporudokumform_1541802986_cell);
            
            // Draw rounded rectangle with PdfCanvas for border-radius support
            {
                var boxX = 10f * pxToPtFactor;
                var boxAbsY = Math.Abs(1040f * pxToPtFactor);
                var boxPageRelY = boxAbsY - pageStartY;
                var boxY = ((currentPageHeight > 0 ? currentPageHeight : canvasHeight.Value) - (boxPageRelY + Math.Abs(30f * pxToPtFactor)));
                var boxW = 790f * pxToPtFactor;
                var boxH = 30f * pxToPtFactor;
                var boxRadiusTL = 6f * pxToPtFactor;
                var boxRadiusTR = 6f * pxToPtFactor;
                var boxRadiusBR = 6f * pxToPtFactor;
                var boxRadiusBL = 6f * pxToPtFactor;
                float kappaTL = boxRadiusTL * 0.5522848f;
                float kappaTR = boxRadiusTR * 0.5522848f;
                float kappaBR = boxRadiusBR * 0.5522848f;
                float kappaBL = boxRadiusBL * 0.5522848f;
                var currentPage = pdf.GetPage(pdf.GetNumberOfPages());
                var pdfCanvas = new PdfCanvas(currentPage);

                // Draw rounded background with alpha support
                pdfCanvas.SaveState();
                pdfCanvas.SetExtGState(new PdfExtGState().SetFillOpacity(1f));
                pdfCanvas.SetFillColor(new DeviceRgb(114, 194, 64));
                pdfCanvas.MoveTo(boxX + boxRadiusBL, boxY);
                pdfCanvas.LineTo(boxX + boxW - boxRadiusBR, boxY);
                if (boxRadiusBR > 0) pdfCanvas.CurveTo(boxX + boxW - boxRadiusBR + kappaBR, boxY, boxX + boxW, boxY + boxRadiusBR - kappaBR, boxX + boxW, boxY + boxRadiusBR);
                pdfCanvas.LineTo(boxX + boxW, boxY + boxH - boxRadiusTR);
                if (boxRadiusTR > 0) pdfCanvas.CurveTo(boxX + boxW, boxY + boxH - boxRadiusTR + kappaTR, boxX + boxW - boxRadiusTR + kappaTR, boxY + boxH, boxX + boxW - boxRadiusTR, boxY + boxH);
                pdfCanvas.LineTo(boxX + boxRadiusTL, boxY + boxH);
                if (boxRadiusTL > 0) pdfCanvas.CurveTo(boxX + boxRadiusTL - kappaTL, boxY + boxH, boxX, boxY + boxH - boxRadiusTL + kappaTL, boxX, boxY + boxH - boxRadiusTL);
                pdfCanvas.LineTo(boxX, boxY + boxRadiusBL);
                if (boxRadiusBL > 0) pdfCanvas.CurveTo(boxX, boxY + boxRadiusBL - kappaBL, boxX + boxRadiusBL - kappaBL, boxY, boxX + boxRadiusBL, boxY);
                pdfCanvas.ClosePath();
                pdfCanvas.Fill();
                pdfCanvas.RestoreState();

                // Draw individual border edges with per-side widths
                var rrBorderColor = new DeviceRgb(114, 194, 64);
                float rrBorderTop = 1f * pxToPtFactor;
                float rrBorderRight = 1f * pxToPtFactor;
                float rrBorderBottom = 1f * pxToPtFactor;
                float rrBorderLeft = 1f * pxToPtFactor;

                // Top border (uses TL and TR corners)
                if (rrBorderTop > 0)
                {
                    pdfCanvas.SaveState();
                    pdfCanvas.SetExtGState(new PdfExtGState().SetStrokeOpacity(1f));
                    pdfCanvas.SetStrokeColor(rrBorderColor);
                    pdfCanvas.SetLineWidth(rrBorderTop);
                    pdfCanvas.MoveTo(boxX + boxRadiusTL, boxY + boxH);
                    pdfCanvas.LineTo(boxX + boxW - boxRadiusTR, boxY + boxH);
                    if (boxRadiusTR > 0) pdfCanvas.CurveTo(boxX + boxW - boxRadiusTR + kappaTR, boxY + boxH, boxX + boxW, boxY + boxH - boxRadiusTR + kappaTR, boxX + boxW, boxY + boxH - boxRadiusTR);
                    pdfCanvas.Stroke();
                    pdfCanvas.RestoreState();
                }

                // Right border (uses TR and BR corners)
                if (rrBorderRight > 0)
                {
                    pdfCanvas.SaveState();
                    pdfCanvas.SetExtGState(new PdfExtGState().SetStrokeOpacity(1f));
                    pdfCanvas.SetStrokeColor(rrBorderColor);
                    pdfCanvas.SetLineWidth(rrBorderRight);
                    pdfCanvas.MoveTo(boxX + boxW, boxY + boxH - boxRadiusTR);
                    pdfCanvas.LineTo(boxX + boxW, boxY + boxRadiusBR);
                    if (boxRadiusBR > 0) pdfCanvas.CurveTo(boxX + boxW, boxY + boxRadiusBR - kappaBR, boxX + boxW - boxRadiusBR + kappaBR, boxY, boxX + boxW - boxRadiusBR, boxY);
                    pdfCanvas.Stroke();
                    pdfCanvas.RestoreState();
                }

                // Bottom border (uses BR and BL corners)
                if (rrBorderBottom > 0)
                {
                    pdfCanvas.SaveState();
                    pdfCanvas.SetExtGState(new PdfExtGState().SetStrokeOpacity(1f));
                    pdfCanvas.SetStrokeColor(rrBorderColor);
                    pdfCanvas.SetLineWidth(rrBorderBottom);
                    pdfCanvas.MoveTo(boxX + boxW - boxRadiusBR, boxY);
                    pdfCanvas.LineTo(boxX + boxRadiusBL, boxY);
                    if (boxRadiusBL > 0) pdfCanvas.CurveTo(boxX + boxRadiusBL - kappaBL, boxY, boxX, boxY + boxRadiusBL - kappaBL, boxX, boxY + boxRadiusBL);
                    pdfCanvas.Stroke();
                    pdfCanvas.RestoreState();
                }

                // Left border (uses BL and TL corners)
                if (rrBorderLeft > 0)
                {
                    pdfCanvas.SaveState();
                    pdfCanvas.SetExtGState(new PdfExtGState().SetStrokeOpacity(1f));
                    pdfCanvas.SetStrokeColor(rrBorderColor);
                    pdfCanvas.SetLineWidth(rrBorderLeft);
                    pdfCanvas.MoveTo(boxX, boxY + boxRadiusBL);
                    pdfCanvas.LineTo(boxX, boxY + boxH - boxRadiusTL);
                    if (boxRadiusTL > 0) pdfCanvas.CurveTo(boxX, boxY + boxH - boxRadiusTL + kappaTL, boxX + boxRadiusTL - kappaTL, boxY + boxH, boxX + boxRadiusTL, boxY + boxH);
                    pdfCanvas.Stroke();
                    pdfCanvas.RestoreState();
                }
            }
            box_kasaraporudokumform_1250919818_deferredAdds.Add(box_kasaraporudokumform_1541802986);
            box_kasaraporudokumform_1250919818_deferredAdds.AddRange(box_kasaraporudokumform_1541802986_deferredAdds);
            }}


            //ReportTable4
            
            var kasaraporudokumform_1724250516IsVisible = true;
            var kasaraporudokumform_1724250516BackgroundColor = new DeviceRgb(0, 0, 0);
            var kasaraporudokumform_1724250516BackgroundColorOpacity = 0f;
            var widths_kasaraporudokumform_1724250516 = new List<float>();
widths_kasaraporudokumform_1724250516.Add(105.83f * pxToPtFactor);
widths_kasaraporudokumform_1724250516.Add(204.09f * pxToPtFactor);
widths_kasaraporudokumform_1724250516.Add(128.5f * pxToPtFactor);
widths_kasaraporudokumform_1724250516.Add(128.5f * pxToPtFactor);
widths_kasaraporudokumform_1724250516.Add(158.74f * pxToPtFactor);
var designWidth_kasaraporudokumform_1724250516 = 725.67f * pxToPtFactor;
var tableWidth_kasaraporudokumform_1724250516 = (widths_kasaraporudokumform_1724250516.Sum() / designWidth_kasaraporudokumform_1724250516) * (725.67f * pxToPtFactor);

            Table kasaraporudokumform_1724250516 = new Table(widths_kasaraporudokumform_1724250516.ToArray()).SetWidth(tableWidth_kasaraporudokumform_1724250516)
            .SetBackgroundColor(kasaraporudokumform_1724250516BackgroundColor, kasaraporudokumform_1724250516BackgroundColorOpacity)
            .SetVisible(kasaraporudokumform_1724250516IsVisible)
            .SetMarginBottom(0 * pxToPtFactor)
            .SetMarginLeft(0 * pxToPtFactor)
            .SetMarginTop(0 * pxToPtFactor)
            .SetMarginRight(0 * pxToPtFactor);
            
            kasaraporudokumform_1724250516.SetBorderBottom(new SolidBorder(new DeviceRgb(218, 218, 218), 1 * pxToPtFactor, 1f));
            kasaraporudokumform_1724250516.SetBorderTop(new SolidBorder(new DeviceRgb(218, 218, 218), 1 * pxToPtFactor, 1f));
            kasaraporudokumform_1724250516.SetBorderRight(new SolidBorder(new DeviceRgb(218, 218, 218), 1 * pxToPtFactor, 1f));
            kasaraporudokumform_1724250516.SetBorderLeft(new SolidBorder(new DeviceRgb(218, 218, 218), 1 * pxToPtFactor, 1f));
            kasaraporudokumform_1724250516.SetBorderRadius(new BorderRadius(0f * pxToPtFactor));
            kasaraporudokumform_1724250516.SetFixedLayout();
            Color kasaraporudokumform_1724250516borderColor = new DeviceRgb(240, 240, 240);
            Border kasaraporudokumform_1724250516leftBorder = new SolidBorder(kasaraporudokumform_1724250516borderColor, 1 * pxToPtFactor);
            if (kasaraporudokumform_1724250516IsVisible)
            {
                
            List<String> columnValueNames_kasaraporudokumform_1724250516 = new List<String>() {"CurrAccCode", "CurrAccDescription", "KasaHesabiAdi", "Tahsil", "Tahsil1"};
            
            var kasaraporudokumform_1724250516_ColumTitlesPropValue = "";
            var kasaraporudokumform_1724250516_ColumnTitles = new List<string>();
            if(kasaraporudokumform_1724250516_ColumTitlesPropValue != null) {
               kasaraporudokumform_1724250516_ColumnTitles = kasaraporudokumform_1724250516_ColumTitlesPropValue.ToString()?.Split(";", StringSplitOptions.RemoveEmptyEntries).ToList();
            }
        
            
            Cell cell_0 = new Cell(1, 1);
            //cell_0.SetBorder(iText.Layout.Borders.Border.NO_BORDER)
            cell_0.SetBackgroundColor(new DeviceRgb(0, 0, 0), 0f);
            cell_0.SetBorderBottom(Border.NO_BORDER);
            cell_0.SetBorderTop(Border.NO_BORDER);
            cell_0.SetBorderRight(Border.NO_BORDER);
            cell_0.SetBorderLeft(Border.NO_BORDER);
            cell_0.SetBorderRadius(new BorderRadius(0f * pxToPtFactor));
            
            
            cell_0.SetPaddingBottom(0 * pxToPtFactor).SetPaddingLeft(0 * pxToPtFactor)
            .SetPaddingTop(0 * pxToPtFactor).SetPaddingRight(0 * pxToPtFactor).SetFontSize(14 * pxToPtFactor)
            .SetFont(fontDictionary["poppins_regular"]).SetFontColor(new DeviceRgb(155, 155, 155), 1f)
            .SetTextAlignment(iText.Layout.Properties.TextAlignment.LEFT);
            var headerParagraph_0 = new Paragraph((kasaraporudokumform_1724250516_ColumnTitles is { Count: >= (0 + 1) } ? kasaraporudokumform_1724250516_ColumnTitles[0] : kasaraporudokumform_1724250516_ColumnTitles.Any() ? "" : ("Müşteri Kodu".ConvertToType<String>())))
            
            .WithGlyphFallback(fontDictionary, "poppins_regular", () => cjkFallbackFont.Value);
            cell_0.Add(headerParagraph_0);
            
            cell_0.SetVisible(true);
            kasaraporudokumform_1724250516.AddHeaderCell(cell_0);


            Cell cell_1 = new Cell(1, 1);
            //cell_1.SetBorder(iText.Layout.Borders.Border.NO_BORDER)
            cell_1.SetBackgroundColor(new DeviceRgb(0, 0, 0), 0f);
            cell_1.SetBorderBottom(Border.NO_BORDER);
            cell_1.SetBorderTop(Border.NO_BORDER);
            cell_1.SetBorderRight(Border.NO_BORDER);
            cell_1.SetBorderLeft(Border.NO_BORDER);
            cell_1.SetBorderRadius(new BorderRadius(0f * pxToPtFactor));
            
            if(true){cell_1.SetBorderLeft(kasaraporudokumform_1724250516leftBorder);}
            cell_1.SetPaddingBottom(0 * pxToPtFactor).SetPaddingLeft(0 * pxToPtFactor)
            .SetPaddingTop(0 * pxToPtFactor).SetPaddingRight(0 * pxToPtFactor).SetFontSize(14 * pxToPtFactor)
            .SetFont(fontDictionary["poppins_regular"]).SetFontColor(new DeviceRgb(155, 155, 155), 1f)
            .SetTextAlignment(iText.Layout.Properties.TextAlignment.LEFT);
            var headerParagraph_1 = new Paragraph((kasaraporudokumform_1724250516_ColumnTitles is { Count: >= (1 + 1) } ? kasaraporudokumform_1724250516_ColumnTitles[1] : kasaraporudokumform_1724250516_ColumnTitles.Any() ? "" : ("Müşteri Adı".ConvertToType<String>())))
            
            .WithGlyphFallback(fontDictionary, "poppins_regular", () => cjkFallbackFont.Value);
            cell_1.Add(headerParagraph_1);
            
            cell_1.SetVisible(true);
            kasaraporudokumform_1724250516.AddHeaderCell(cell_1);


            Cell cell_2 = new Cell(1, 1);
            //cell_2.SetBorder(iText.Layout.Borders.Border.NO_BORDER)
            cell_2.SetBackgroundColor(new DeviceRgb(0, 0, 0), 0f);
            cell_2.SetBorderBottom(Border.NO_BORDER);
            cell_2.SetBorderTop(Border.NO_BORDER);
            cell_2.SetBorderRight(Border.NO_BORDER);
            cell_2.SetBorderLeft(Border.NO_BORDER);
            cell_2.SetBorderRadius(new BorderRadius(0f * pxToPtFactor));
            
            if(true){cell_2.SetBorderLeft(kasaraporudokumform_1724250516leftBorder);}
            cell_2.SetPaddingBottom(0 * pxToPtFactor).SetPaddingLeft(0 * pxToPtFactor)
            .SetPaddingTop(0 * pxToPtFactor).SetPaddingRight(0 * pxToPtFactor).SetFontSize(14 * pxToPtFactor)
            .SetFont(fontDictionary["poppins_regular"]).SetFontColor(new DeviceRgb(155, 155, 155), 1f)
            .SetTextAlignment(iText.Layout.Properties.TextAlignment.LEFT);
            var headerParagraph_2 = new Paragraph((kasaraporudokumform_1724250516_ColumnTitles is { Count: >= (2 + 1) } ? kasaraporudokumform_1724250516_ColumnTitles[2] : kasaraporudokumform_1724250516_ColumnTitles.Any() ? "" : ("Kasa Adı".ConvertToType<String>())))
            
            .WithGlyphFallback(fontDictionary, "poppins_regular", () => cjkFallbackFont.Value);
            cell_2.Add(headerParagraph_2);
            
            cell_2.SetVisible(true);
            kasaraporudokumform_1724250516.AddHeaderCell(cell_2);


            Cell cell_3 = new Cell(1, 1);
            //cell_3.SetBorder(iText.Layout.Borders.Border.NO_BORDER)
            cell_3.SetBackgroundColor(new DeviceRgb(0, 0, 0), 0f);
            cell_3.SetBorderBottom(Border.NO_BORDER);
            cell_3.SetBorderTop(Border.NO_BORDER);
            cell_3.SetBorderRight(Border.NO_BORDER);
            cell_3.SetBorderLeft(Border.NO_BORDER);
            cell_3.SetBorderRadius(new BorderRadius(0f * pxToPtFactor));
            
            if(true){cell_3.SetBorderLeft(kasaraporudokumform_1724250516leftBorder);}
            cell_3.SetPaddingBottom(0 * pxToPtFactor).SetPaddingLeft(0 * pxToPtFactor)
            .SetPaddingTop(0 * pxToPtFactor).SetPaddingRight(0 * pxToPtFactor).SetFontSize(14 * pxToPtFactor)
            .SetFont(fontDictionary["poppins_regular"]).SetFontColor(new DeviceRgb(155, 155, 155), 1f)
            .SetTextAlignment(iText.Layout.Properties.TextAlignment.LEFT);
            var headerParagraph_3 = new Paragraph((kasaraporudokumform_1724250516_ColumnTitles is { Count: >= (3 + 1) } ? kasaraporudokumform_1724250516_ColumnTitles[3] : kasaraporudokumform_1724250516_ColumnTitles.Any() ? "" : ("Peşin Tahsilat".ConvertToType<String>())))
            
            .WithGlyphFallback(fontDictionary, "poppins_regular", () => cjkFallbackFont.Value);
            cell_3.Add(headerParagraph_3);
            
            cell_3.SetVisible(true);
            kasaraporudokumform_1724250516.AddHeaderCell(cell_3);


            Cell cell_4 = new Cell(1, 1);
            //cell_4.SetBorder(iText.Layout.Borders.Border.NO_BORDER)
            cell_4.SetBackgroundColor(new DeviceRgb(0, 0, 0), 0f);
            cell_4.SetBorderBottom(Border.NO_BORDER);
            cell_4.SetBorderTop(Border.NO_BORDER);
            cell_4.SetBorderRight(Border.NO_BORDER);
            cell_4.SetBorderLeft(Border.NO_BORDER);
            cell_4.SetBorderRadius(new BorderRadius(0f * pxToPtFactor));
            
            if(true){cell_4.SetBorderLeft(kasaraporudokumform_1724250516leftBorder);}
            cell_4.SetPaddingBottom(0 * pxToPtFactor).SetPaddingLeft(0 * pxToPtFactor)
            .SetPaddingTop(0 * pxToPtFactor).SetPaddingRight(0 * pxToPtFactor).SetFontSize(14 * pxToPtFactor)
            .SetFont(fontDictionary["poppins_regular"]).SetFontColor(new DeviceRgb(155, 155, 155), 1f)
            .SetTextAlignment(iText.Layout.Properties.TextAlignment.LEFT);
            var headerParagraph_4 = new Paragraph((kasaraporudokumform_1724250516_ColumnTitles is { Count: >= (4 + 1) } ? kasaraporudokumform_1724250516_ColumnTitles[4] : kasaraporudokumform_1724250516_ColumnTitles.Any() ? "" : ("Peşin Tahsilat TRY ".ConvertToType<String>())))
            
            .WithGlyphFallback(fontDictionary, "poppins_regular", () => cjkFallbackFont.Value);
            cell_4.Add(headerParagraph_4);
            
            cell_4.SetVisible(true);
            kasaraporudokumform_1724250516.AddHeaderCell(cell_4);


            
            var rowBackgroundColor = new DeviceRgb(0, 0, 0);
            var rowOpacity = 0;
            var isStriped = false;
            Color stripedColor = new DeviceRgb(245, 247, 250);
            for(int i = 0; i < result.Kuika_BankaKontrol5.Count; i++)
              {
                  var item = result.Kuika_BankaKontrol5[i];
                  Color backgroundColor = new DeviceRgb(255, 255, 255);
                  float backgroundColorOpacity = 0f;

                  if (kasaraporudokumform_1724250516BackgroundColorOpacity == 1) {{
                        backgroundColor = kasaraporudokumform_1724250516BackgroundColor;
                        backgroundColorOpacity = 1f;
                  }}

                  if (rowOpacity == 1) {{
                        backgroundColor = rowBackgroundColor;
                        backgroundColorOpacity = 1f;
                  }}

                  if (isStriped && i % 2 != 0) {{
                        backgroundColor = stripedColor;
                        backgroundColorOpacity = 1f;
                  }}

                  
                
            var colData_01705705327 = new Paragraph(item.CurrAccCode.ToFormattedString("", "", "") ?? "")
            .SetMarginBottom(0 * pxToPtFactor).SetMarginLeft(0 * pxToPtFactor)
            .SetMarginTop(0 * pxToPtFactor).SetMarginRight(0 * pxToPtFactor)
            .SetFontColor(new DeviceRgb(68, 68, 68), 1f)
            .SetBackgroundColor(new DeviceRgb(0, 0, 0), 0f)
            .SetFontSize(12 * pxToPtFactor)
            .SetFont(fontDictionary["poppins_regular"])
            .WithGlyphFallback(fontDictionary, "poppins_regular", () => cjkFallbackFont.Value)
            
            .SetParagraphWidthAndExtendHeightIfNotFit(document, 31.57f * pxToPtFactor, 20f * pxToPtFactor, true)
            .SetVisible(true)
            .SetVerticalAlignment(VerticalAlignment.TOP)
            .SetHorizontalAlignment(HorizontalAlignment.LEFT)
            .SetTextAlignment(TextAlignment.LEFT)
            .SetMultipliedLeading(1f);
            
colData_01705705327.SetVisible(true);

                Cell cell_1705705327 = new Cell(1, 1);
                var cell_1705705327BackgroundColor = new DeviceRgb(0, 0, 0);
                var cell_1705705327BackgroundColorOpacity = 0;
                
                cell_1705705327.SetMinHeight(40 * pxToPtFactor);
                //cell_1705705327.SetBorder(iText.Layout.Borders.Border.NO_BORDER);
                cell_1705705327.SetBorderBottom(Border.NO_BORDER);
                cell_1705705327.SetBorderTop(Border.NO_BORDER);
                cell_1705705327.SetBorderRight(Border.NO_BORDER);
                cell_1705705327.SetBorderLeft(Border.NO_BORDER);
                cell_1705705327.SetBorderRadius(new BorderRadius(0f * pxToPtFactor));
                //cell_1705705327.Add(colData_1705705327);
                if (cell_1705705327BackgroundColorOpacity == 1)
                    cell_1705705327.SetBackgroundColor(cell_1705705327BackgroundColor);
                else if (backgroundColorOpacity == 1)
                    cell_1705705327.SetBackgroundColor(backgroundColor);
                cell_1705705327.SetVerticalAlignment(iText.Layout.Properties.VerticalAlignment.TOP);
                cell_1705705327.SetTextAlignment(iText.Layout.Properties.TextAlignment.LEFT);
                cell_1705705327.SetPaddingBottom(0 * pxToPtFactor).SetPaddingLeft(0 * pxToPtFactor)
                .SetPaddingTop(0 * pxToPtFactor).SetPaddingRight(0 * pxToPtFactor);
                
                kasaraporudokumform_1724250516.AddCell(cell_1705705327);

cell_1705705327.Add(colData_01705705327);

                
            var colData_0451842826 = new Paragraph(item.CurrAccDescription.ToFormattedString("", "", "") ?? "")
            .SetMarginBottom(0 * pxToPtFactor).SetMarginLeft(0 * pxToPtFactor)
            .SetMarginTop(0 * pxToPtFactor).SetMarginRight(0 * pxToPtFactor)
            .SetFontColor(new DeviceRgb(68, 68, 68), 1f)
            .SetBackgroundColor(new DeviceRgb(0, 0, 0), 0f)
            .SetFontSize(12 * pxToPtFactor)
            .SetFont(fontDictionary["poppins_regular"])
            .WithGlyphFallback(fontDictionary, "poppins_regular", () => cjkFallbackFont.Value)
            
            .SetParagraphWidthAndExtendHeightIfNotFit(document, 31.57f * pxToPtFactor, 20f * pxToPtFactor, true)
            .SetVisible(true)
            .SetVerticalAlignment(VerticalAlignment.TOP)
            .SetHorizontalAlignment(HorizontalAlignment.LEFT)
            .SetTextAlignment(TextAlignment.LEFT)
            .SetMultipliedLeading(1f);
            
colData_0451842826.SetVisible(true);

                Cell cell_451842826 = new Cell(1, 1);
                var cell_451842826BackgroundColor = new DeviceRgb(0, 0, 0);
                var cell_451842826BackgroundColorOpacity = 0;
                
                cell_451842826.SetMinHeight(40 * pxToPtFactor);
                //cell_451842826.SetBorder(iText.Layout.Borders.Border.NO_BORDER);
                cell_451842826.SetBorderBottom(Border.NO_BORDER);
                cell_451842826.SetBorderTop(Border.NO_BORDER);
                cell_451842826.SetBorderRight(Border.NO_BORDER);
                cell_451842826.SetBorderLeft(Border.NO_BORDER);
                cell_451842826.SetBorderRadius(new BorderRadius(0f * pxToPtFactor));
                //cell_451842826.Add(colData_451842826);
                if (cell_451842826BackgroundColorOpacity == 1)
                    cell_451842826.SetBackgroundColor(cell_451842826BackgroundColor);
                else if (backgroundColorOpacity == 1)
                    cell_451842826.SetBackgroundColor(backgroundColor);
                cell_451842826.SetVerticalAlignment(iText.Layout.Properties.VerticalAlignment.TOP);
                cell_451842826.SetTextAlignment(iText.Layout.Properties.TextAlignment.LEFT);
                cell_451842826.SetPaddingBottom(0 * pxToPtFactor).SetPaddingLeft(0 * pxToPtFactor)
                .SetPaddingTop(0 * pxToPtFactor).SetPaddingRight(0 * pxToPtFactor);
                
                kasaraporudokumform_1724250516.AddCell(cell_451842826);

cell_451842826.Add(colData_0451842826);

                
            var colData_01480425673 = new Paragraph(item.KasaHesabiAdi.ToFormattedString("", "", "") ?? "")
            .SetMarginBottom(0 * pxToPtFactor).SetMarginLeft(0 * pxToPtFactor)
            .SetMarginTop(0 * pxToPtFactor).SetMarginRight(0 * pxToPtFactor)
            .SetFontColor(new DeviceRgb(68, 68, 68), 1f)
            .SetBackgroundColor(new DeviceRgb(0, 0, 0), 0f)
            .SetFontSize(12 * pxToPtFactor)
            .SetFont(fontDictionary["poppins_regular"])
            .WithGlyphFallback(fontDictionary, "poppins_regular", () => cjkFallbackFont.Value)
            
            .SetParagraphWidthAndExtendHeightIfNotFit(document, 31.57f * pxToPtFactor, 20f * pxToPtFactor, true)
            .SetVisible(true)
            .SetVerticalAlignment(VerticalAlignment.TOP)
            .SetHorizontalAlignment(HorizontalAlignment.LEFT)
            .SetTextAlignment(TextAlignment.LEFT)
            .SetMultipliedLeading(1f);
            
colData_01480425673.SetVisible(true);

                Cell cell_1480425673 = new Cell(1, 1);
                var cell_1480425673BackgroundColor = new DeviceRgb(0, 0, 0);
                var cell_1480425673BackgroundColorOpacity = 0;
                
                cell_1480425673.SetMinHeight(40 * pxToPtFactor);
                //cell_1480425673.SetBorder(iText.Layout.Borders.Border.NO_BORDER);
                cell_1480425673.SetBorderBottom(Border.NO_BORDER);
                cell_1480425673.SetBorderTop(Border.NO_BORDER);
                cell_1480425673.SetBorderRight(Border.NO_BORDER);
                cell_1480425673.SetBorderLeft(Border.NO_BORDER);
                cell_1480425673.SetBorderRadius(new BorderRadius(0f * pxToPtFactor));
                //cell_1480425673.Add(colData_1480425673);
                if (cell_1480425673BackgroundColorOpacity == 1)
                    cell_1480425673.SetBackgroundColor(cell_1480425673BackgroundColor);
                else if (backgroundColorOpacity == 1)
                    cell_1480425673.SetBackgroundColor(backgroundColor);
                cell_1480425673.SetVerticalAlignment(iText.Layout.Properties.VerticalAlignment.TOP);
                cell_1480425673.SetTextAlignment(iText.Layout.Properties.TextAlignment.LEFT);
                cell_1480425673.SetPaddingBottom(0 * pxToPtFactor).SetPaddingLeft(0 * pxToPtFactor)
                .SetPaddingTop(0 * pxToPtFactor).SetPaddingRight(0 * pxToPtFactor);
                
                kasaraporudokumform_1724250516.AddCell(cell_1480425673);

cell_1480425673.Add(colData_01480425673);

                
            var colData_0196816091 = new Paragraph(item.Tahsil.ToFormattedString("", "", "") ?? "")
            .SetMarginBottom(0 * pxToPtFactor).SetMarginLeft(0 * pxToPtFactor)
            .SetMarginTop(0 * pxToPtFactor).SetMarginRight(0 * pxToPtFactor)
            .SetFontColor(new DeviceRgb(68, 68, 68), 1f)
            .SetBackgroundColor(new DeviceRgb(0, 0, 0), 0f)
            .SetFontSize(12 * pxToPtFactor)
            .SetFont(fontDictionary["poppins_regular"])
            .WithGlyphFallback(fontDictionary, "poppins_regular", () => cjkFallbackFont.Value)
            
            .SetParagraphWidthAndExtendHeightIfNotFit(document, 31.57f * pxToPtFactor, 20f * pxToPtFactor, true)
            .SetVisible(true)
            .SetVerticalAlignment(VerticalAlignment.TOP)
            .SetHorizontalAlignment(HorizontalAlignment.LEFT)
            .SetTextAlignment(TextAlignment.LEFT)
            .SetMultipliedLeading(1f);
            
colData_0196816091.SetVisible(true);

                Cell cell_196816091 = new Cell(1, 1);
                var cell_196816091BackgroundColor = new DeviceRgb(0, 0, 0);
                var cell_196816091BackgroundColorOpacity = 0;
                
                cell_196816091.SetMinHeight(40 * pxToPtFactor);
                //cell_196816091.SetBorder(iText.Layout.Borders.Border.NO_BORDER);
                cell_196816091.SetBorderBottom(Border.NO_BORDER);
                cell_196816091.SetBorderTop(Border.NO_BORDER);
                cell_196816091.SetBorderRight(Border.NO_BORDER);
                cell_196816091.SetBorderLeft(Border.NO_BORDER);
                cell_196816091.SetBorderRadius(new BorderRadius(0f * pxToPtFactor));
                //cell_196816091.Add(colData_196816091);
                if (cell_196816091BackgroundColorOpacity == 1)
                    cell_196816091.SetBackgroundColor(cell_196816091BackgroundColor);
                else if (backgroundColorOpacity == 1)
                    cell_196816091.SetBackgroundColor(backgroundColor);
                cell_196816091.SetVerticalAlignment(iText.Layout.Properties.VerticalAlignment.TOP);
                cell_196816091.SetTextAlignment(iText.Layout.Properties.TextAlignment.LEFT);
                cell_196816091.SetPaddingBottom(0 * pxToPtFactor).SetPaddingLeft(0 * pxToPtFactor)
                .SetPaddingTop(0 * pxToPtFactor).SetPaddingRight(0 * pxToPtFactor);
                
                kasaraporudokumform_1724250516.AddCell(cell_196816091);

cell_196816091.Add(colData_0196816091);

                
            var colData_070753872 = new Paragraph(item.Tahsil1.ToFormattedString("", "", "") ?? "")
            .SetMarginBottom(0 * pxToPtFactor).SetMarginLeft(0 * pxToPtFactor)
            .SetMarginTop(0 * pxToPtFactor).SetMarginRight(0 * pxToPtFactor)
            .SetFontColor(new DeviceRgb(68, 68, 68), 1f)
            .SetBackgroundColor(new DeviceRgb(0, 0, 0), 0f)
            .SetFontSize(12 * pxToPtFactor)
            .SetFont(fontDictionary["poppins_regular"])
            .WithGlyphFallback(fontDictionary, "poppins_regular", () => cjkFallbackFont.Value)
            
            .SetParagraphWidthAndExtendHeightIfNotFit(document, 31.49f * pxToPtFactor, 20f * pxToPtFactor, true)
            .SetVisible(true)
            .SetVerticalAlignment(VerticalAlignment.TOP)
            .SetHorizontalAlignment(HorizontalAlignment.LEFT)
            .SetTextAlignment(TextAlignment.LEFT)
            .SetMultipliedLeading(1f);
            
colData_070753872.SetVisible(true);

                Cell cell_70753872 = new Cell(1, 1);
                var cell_70753872BackgroundColor = new DeviceRgb(0, 0, 0);
                var cell_70753872BackgroundColorOpacity = 0;
                
                cell_70753872.SetMinHeight(40 * pxToPtFactor);
                //cell_70753872.SetBorder(iText.Layout.Borders.Border.NO_BORDER);
                cell_70753872.SetBorderBottom(Border.NO_BORDER);
                cell_70753872.SetBorderTop(Border.NO_BORDER);
                cell_70753872.SetBorderRight(Border.NO_BORDER);
                cell_70753872.SetBorderLeft(Border.NO_BORDER);
                cell_70753872.SetBorderRadius(new BorderRadius(0f * pxToPtFactor));
                //cell_70753872.Add(colData_70753872);
                if (cell_70753872BackgroundColorOpacity == 1)
                    cell_70753872.SetBackgroundColor(cell_70753872BackgroundColor);
                else if (backgroundColorOpacity == 1)
                    cell_70753872.SetBackgroundColor(backgroundColor);
                cell_70753872.SetVerticalAlignment(iText.Layout.Properties.VerticalAlignment.TOP);
                cell_70753872.SetTextAlignment(iText.Layout.Properties.TextAlignment.LEFT);
                cell_70753872.SetPaddingBottom(0 * pxToPtFactor).SetPaddingLeft(0 * pxToPtFactor)
                .SetPaddingTop(0 * pxToPtFactor).SetPaddingRight(0 * pxToPtFactor);
                
                kasaraporudokumform_1724250516.AddCell(cell_70753872);

cell_70753872.Add(colData_070753872);

              }



            kasaraporudokumform_1724250516.SetMarginLeft(10f * pxToPtFactor + 0f * pxToPtFactor);
            if (Math.Abs(1080f * pxToPtFactor) > 0) {{
               kasaraporudokumform_1724250516.SetMarginTop(Math.Abs(1080f * pxToPtFactor) + 0f * pxToPtFactor);
            }}
            kasaraporudokumform_1250919818_cell.Add(kasaraporudokumform_1724250516);
        }

   
            kasaraporudokumform_1250919818_cell.SetVisible(box_kasaraporudokumform_1250919818.IsVisible());
            box_kasaraporudokumform_1250919818.AddCell(kasaraporudokumform_1250919818_cell);
            
            // Draw rounded rectangle with PdfCanvas for border-radius support
            {
                var boxX = 10f * pxToPtFactor;
                var boxAbsY = Math.Abs(1040f * pxToPtFactor);
                var boxPageRelY = boxAbsY - pageStartY;
                var boxY = ((currentPageHeight > 0 ? currentPageHeight : canvasHeight.Value) - (boxPageRelY + Math.Abs(222f * pxToPtFactor)));
                var boxW = 780f * pxToPtFactor;
                var boxH = 222f * pxToPtFactor;
                var boxRadiusTL = 6f * pxToPtFactor;
                var boxRadiusTR = 6f * pxToPtFactor;
                var boxRadiusBR = 6f * pxToPtFactor;
                var boxRadiusBL = 6f * pxToPtFactor;
                float kappaTL = boxRadiusTL * 0.5522848f;
                float kappaTR = boxRadiusTR * 0.5522848f;
                float kappaBR = boxRadiusBR * 0.5522848f;
                float kappaBL = boxRadiusBL * 0.5522848f;
                var currentPage = pdf.GetPage(pdf.GetNumberOfPages());
                var pdfCanvas = new PdfCanvas(currentPage);

                // Draw rounded background with alpha support
                pdfCanvas.SaveState();
                pdfCanvas.SetExtGState(new PdfExtGState().SetFillOpacity(1f));
                pdfCanvas.SetFillColor(new DeviceRgb(255, 255, 255));
                pdfCanvas.MoveTo(boxX + boxRadiusBL, boxY);
                pdfCanvas.LineTo(boxX + boxW - boxRadiusBR, boxY);
                if (boxRadiusBR > 0) pdfCanvas.CurveTo(boxX + boxW - boxRadiusBR + kappaBR, boxY, boxX + boxW, boxY + boxRadiusBR - kappaBR, boxX + boxW, boxY + boxRadiusBR);
                pdfCanvas.LineTo(boxX + boxW, boxY + boxH - boxRadiusTR);
                if (boxRadiusTR > 0) pdfCanvas.CurveTo(boxX + boxW, boxY + boxH - boxRadiusTR + kappaTR, boxX + boxW - boxRadiusTR + kappaTR, boxY + boxH, boxX + boxW - boxRadiusTR, boxY + boxH);
                pdfCanvas.LineTo(boxX + boxRadiusTL, boxY + boxH);
                if (boxRadiusTL > 0) pdfCanvas.CurveTo(boxX + boxRadiusTL - kappaTL, boxY + boxH, boxX, boxY + boxH - boxRadiusTL + kappaTL, boxX, boxY + boxH - boxRadiusTL);
                pdfCanvas.LineTo(boxX, boxY + boxRadiusBL);
                if (boxRadiusBL > 0) pdfCanvas.CurveTo(boxX, boxY + boxRadiusBL - kappaBL, boxX + boxRadiusBL - kappaBL, boxY, boxX + boxRadiusBL, boxY);
                pdfCanvas.ClosePath();
                pdfCanvas.Fill();
                pdfCanvas.RestoreState();

                // Draw individual border edges with per-side widths
                var rrBorderColor = new DeviceRgb(238, 242, 246);
                float rrBorderTop = 1f * pxToPtFactor;
                float rrBorderRight = 1f * pxToPtFactor;
                float rrBorderBottom = 1f * pxToPtFactor;
                float rrBorderLeft = 1f * pxToPtFactor;

                // Top border (uses TL and TR corners)
                if (rrBorderTop > 0)
                {
                    pdfCanvas.SaveState();
                    pdfCanvas.SetExtGState(new PdfExtGState().SetStrokeOpacity(1f));
                    pdfCanvas.SetStrokeColor(rrBorderColor);
                    pdfCanvas.SetLineWidth(rrBorderTop);
                    pdfCanvas.MoveTo(boxX + boxRadiusTL, boxY + boxH);
                    pdfCanvas.LineTo(boxX + boxW - boxRadiusTR, boxY + boxH);
                    if (boxRadiusTR > 0) pdfCanvas.CurveTo(boxX + boxW - boxRadiusTR + kappaTR, boxY + boxH, boxX + boxW, boxY + boxH - boxRadiusTR + kappaTR, boxX + boxW, boxY + boxH - boxRadiusTR);
                    pdfCanvas.Stroke();
                    pdfCanvas.RestoreState();
                }

                // Right border (uses TR and BR corners)
                if (rrBorderRight > 0)
                {
                    pdfCanvas.SaveState();
                    pdfCanvas.SetExtGState(new PdfExtGState().SetStrokeOpacity(1f));
                    pdfCanvas.SetStrokeColor(rrBorderColor);
                    pdfCanvas.SetLineWidth(rrBorderRight);
                    pdfCanvas.MoveTo(boxX + boxW, boxY + boxH - boxRadiusTR);
                    pdfCanvas.LineTo(boxX + boxW, boxY + boxRadiusBR);
                    if (boxRadiusBR > 0) pdfCanvas.CurveTo(boxX + boxW, boxY + boxRadiusBR - kappaBR, boxX + boxW - boxRadiusBR + kappaBR, boxY, boxX + boxW - boxRadiusBR, boxY);
                    pdfCanvas.Stroke();
                    pdfCanvas.RestoreState();
                }

                // Bottom border (uses BR and BL corners)
                if (rrBorderBottom > 0)
                {
                    pdfCanvas.SaveState();
                    pdfCanvas.SetExtGState(new PdfExtGState().SetStrokeOpacity(1f));
                    pdfCanvas.SetStrokeColor(rrBorderColor);
                    pdfCanvas.SetLineWidth(rrBorderBottom);
                    pdfCanvas.MoveTo(boxX + boxW - boxRadiusBR, boxY);
                    pdfCanvas.LineTo(boxX + boxRadiusBL, boxY);
                    if (boxRadiusBL > 0) pdfCanvas.CurveTo(boxX + boxRadiusBL - kappaBL, boxY, boxX, boxY + boxRadiusBL - kappaBL, boxX, boxY + boxRadiusBL);
                    pdfCanvas.Stroke();
                    pdfCanvas.RestoreState();
                }

                // Left border (uses BL and TL corners)
                if (rrBorderLeft > 0)
                {
                    pdfCanvas.SaveState();
                    pdfCanvas.SetExtGState(new PdfExtGState().SetStrokeOpacity(1f));
                    pdfCanvas.SetStrokeColor(rrBorderColor);
                    pdfCanvas.SetLineWidth(rrBorderLeft);
                    pdfCanvas.MoveTo(boxX, boxY + boxRadiusBL);
                    pdfCanvas.LineTo(boxX, boxY + boxH - boxRadiusTL);
                    if (boxRadiusTL > 0) pdfCanvas.CurveTo(boxX, boxY + boxH - boxRadiusTL + kappaTL, boxX + boxRadiusTL - kappaTL, boxY + boxH, boxX + boxRadiusTL, boxY + boxH);
                    pdfCanvas.Stroke();
                    pdfCanvas.RestoreState();
                }
            }
            document.Add(box_kasaraporudokumform_1250919818);
            foreach (var deferredElem in box_kasaraporudokumform_1250919818_deferredAdds) document.Add(deferredElem);
            }}


            //Box10
            Table box_kasaraporudokumform_821829304 = new Table(1).SetWidth(780f * pxToPtFactor).SetHeight(218f * pxToPtFactor)
            .SetFontColor(new DeviceRgb(0, 0, 0), 1f)
            .SetFontSize(20 * pxToPtFactor)
            .SetVisible(true);
            if (box_kasaraporudokumform_821829304.IsVisible()) {{
            var box_kasaraporudokumform_821829304_pageLeftX = (double)(10f * pxToPtFactor) ;
            var box_kasaraporudokumform_821829304_pageTopY = 0d;
            var box_kasaraporudokumform_821829304_deferredAdds = new List<IBlockElement>();
            if (!false) {
            // Calculate page-relative Y position
            var box_kasaraporudokumform_821829304_absoluteY = Math.Abs(1320f * pxToPtFactor);
            var box_kasaraporudokumform_821829304_pageRelativeY = box_kasaraporudokumform_821829304_absoluteY - pageStartY;
            int box_kasaraporudokumform_821829304_targetPage = pdf.GetNumberOfPages();
            
            box_kasaraporudokumform_821829304.SetFixedPosition(box_kasaraporudokumform_821829304_targetPage, 10f * pxToPtFactor , ((currentPageHeight > 0 ? currentPageHeight : canvasHeight.Value) - (box_kasaraporudokumform_821829304_pageRelativeY + Math.Abs(218f * pxToPtFactor))) , 780f * pxToPtFactor);
            box_kasaraporudokumform_821829304_pageTopY = ((double)(currentPageHeight > 0 ? currentPageHeight : canvasHeight.Value) - box_kasaraporudokumform_821829304_pageRelativeY) ;
            } else {
            box_kasaraporudokumform_821829304.SetFixedPosition(10f * pxToPtFactor , ((currentPageHeight > 0 ? currentPageHeight : canvasHeight.Value) - (totalHeight + Math.Abs(1320f * pxToPtFactor) + Math.Abs(218f * pxToPtFactor))) , 780f * pxToPtFactor);
            box_kasaraporudokumform_821829304_pageTopY = ((double)(currentPageHeight > 0 ? currentPageHeight : canvasHeight.Value) - (totalHeight + Math.Abs(1320f * pxToPtFactor))) ;
            }
            box_kasaraporudokumform_821829304.SetBorder(Border.NO_BORDER);
            box_kasaraporudokumform_821829304.SetBorderBottom(Border.NO_BORDER);
            box_kasaraporudokumform_821829304.SetBorderTop(Border.NO_BORDER);
            box_kasaraporudokumform_821829304.SetBorderRight(Border.NO_BORDER);
            box_kasaraporudokumform_821829304.SetBorderLeft(Border.NO_BORDER);
            box_kasaraporudokumform_821829304.SetBorderRadius(new BorderRadius(6f * pxToPtFactor));
            var heightOf_box_kasaraporudokumform_821829304 = box_kasaraporudokumform_821829304.GetHeight();
            Cell kasaraporudokumform_821829304_cell = new Cell();
            kasaraporudokumform_821829304_cell.SetBackgroundColor(new DeviceRgb(255, 255, 255), 0f);
            kasaraporudokumform_821829304_cell.SetBorder(Border.NO_BORDER);
            
            // NOTE: Box always uses SetFixedPosition above (both branches), so it does not
            // contribute to flow. The legacy "totalHeight + height > canvasHeight" areaBreak
            // that lived here was reading totalHeight produced by previous flow elements
            // (e.g. multi-page ReportTables) and spuriously creating a new page + bumping
            // pageStartY, which broke pageRelativeY for every subsequent element. Removed.

            // No page breaks - using default canvas height behavior


            //Box11
            Table box_kasaraporudokumform_480965570 = new Table(1).SetWidth(790f * pxToPtFactor).SetHeight(30f * pxToPtFactor)
            .SetFontColor(new DeviceRgb(0, 0, 0), 1f)
            .SetFontSize(20 * pxToPtFactor)
            .SetVisible(true);
            if (box_kasaraporudokumform_480965570.IsVisible()) {{
            var box_kasaraporudokumform_480965570_pageLeftX = (double)(10f * pxToPtFactor) ;
            var box_kasaraporudokumform_480965570_pageTopY = 0d;
            var box_kasaraporudokumform_480965570_deferredAdds = new List<IBlockElement>();
            if (!false) {
            // Calculate page-relative Y position
            var box_kasaraporudokumform_480965570_absoluteY = Math.Abs(1320f * pxToPtFactor);
            var box_kasaraporudokumform_480965570_pageRelativeY = box_kasaraporudokumform_480965570_absoluteY - pageStartY;
            int box_kasaraporudokumform_480965570_targetPage = pdf.GetNumberOfPages();
            
            box_kasaraporudokumform_480965570.SetFixedPosition(box_kasaraporudokumform_480965570_targetPage, 10f * pxToPtFactor , ((currentPageHeight > 0 ? currentPageHeight : canvasHeight.Value) - (box_kasaraporudokumform_480965570_pageRelativeY + Math.Abs(30f * pxToPtFactor))) , 790f * pxToPtFactor);
            box_kasaraporudokumform_480965570_pageTopY = ((double)(currentPageHeight > 0 ? currentPageHeight : canvasHeight.Value) - box_kasaraporudokumform_480965570_pageRelativeY) ;
            } else {
            box_kasaraporudokumform_480965570.SetFixedPosition(10f * pxToPtFactor , ((currentPageHeight > 0 ? currentPageHeight : canvasHeight.Value) - (totalHeight + Math.Abs(1320f * pxToPtFactor) + Math.Abs(30f * pxToPtFactor))) , 790f * pxToPtFactor);
            box_kasaraporudokumform_480965570_pageTopY = ((double)(currentPageHeight > 0 ? currentPageHeight : canvasHeight.Value) - (totalHeight + Math.Abs(1320f * pxToPtFactor))) ;
            }
            box_kasaraporudokumform_480965570.SetBorder(Border.NO_BORDER);
            box_kasaraporudokumform_480965570.SetBorderBottom(Border.NO_BORDER);
            box_kasaraporudokumform_480965570.SetBorderTop(Border.NO_BORDER);
            box_kasaraporudokumform_480965570.SetBorderRight(Border.NO_BORDER);
            box_kasaraporudokumform_480965570.SetBorderLeft(Border.NO_BORDER);
            box_kasaraporudokumform_480965570.SetBorderRadius(new BorderRadius(6f * pxToPtFactor));
            var heightOf_box_kasaraporudokumform_480965570 = box_kasaraporudokumform_480965570.GetHeight();
            Cell kasaraporudokumform_480965570_cell = new Cell();
            kasaraporudokumform_480965570_cell.SetBackgroundColor(new DeviceRgb(114, 194, 64), 0f);
            kasaraporudokumform_480965570_cell.SetBorder(Border.NO_BORDER);
            
            // NOTE: Box always uses SetFixedPosition above (both branches), so it does not
            // contribute to flow. The legacy "totalHeight + height > canvasHeight" areaBreak
            // that lived here was reading totalHeight produced by previous flow elements
            // (e.g. multi-page ReportTables) and spuriously creating a new page + bumping
            // pageStartY, which broke pageRelativeY for every subsequent element. Removed.

            // No page breaks - using default canvas height behavior


            //Label13
            var label_kasaraporudokumform_78206758_effectiveWidth = 780f * pxToPtFactor > 0 ? 780f * pxToPtFactor : (canvasWidth.Value - (10f * pxToPtFactor));
            Paragraph label_kasaraporudokumform_78206758 = new Paragraph(@"Kasadan Bankaya Çıkış İşlemleri")
            .SetFontSize(15 * pxToPtFactor)
            .SetFont(fontDictionary["poppins_bold"])
            .WithGlyphFallback(fontDictionary, "poppins_bold", () => cjkFallbackFont.Value)
            .SetTextAlignment(TextAlignment.CENTER)
            
            .SetParagraphWidthAndExtendHeightIfNotFit(document, label_kasaraporudokumform_78206758_effectiveWidth, 20f * pxToPtFactor, false, false || false)
            .SetMultipliedLeading(0.875f);
            

            if (20f * pxToPtFactor == 0f)
            {
                label_kasaraporudokumform_78206758.SetMaxHeight((30f * pxToPtFactor) - Math.Abs(1320f * pxToPtFactor));
            }

            label_kasaraporudokumform_78206758.SetMarginBottom(0 * pxToPtFactor).SetMarginTop(0f);
            var label_kasaraporudokumform_78206758_paragraphHeight = label_kasaraporudokumform_78206758.GetHeightOfParagraph(document);
            var label_kasaraporudokumform_78206758_vAlignOffset = 0f;
            label_kasaraporudokumform_78206758_vAlignOffset = Math.Max(0f, (20f * pxToPtFactor - label_kasaraporudokumform_78206758_paragraphHeight) / 2f);
            label_kasaraporudokumform_78206758.SetMarginLeft(0 * pxToPtFactor)
            .SetMarginTop((0 * pxToPtFactor) + label_kasaraporudokumform_78206758_vAlignOffset).SetMarginRight(0 * pxToPtFactor)
            .SetFontColor(new DeviceRgb(255, 255, 255), 1f)
            .SetVisible(true);
            
            if (false)
			{
				Paragraph label_kasaraporudokumform_78206758_inside = new Paragraph(@"Kasadan Bankaya Çıkış İşlemleri")
			   .SetFontSize(15 * pxToPtFactor)
               .SetFont(fontDictionary["poppins_bold"])
			   .WithGlyphFallback(fontDictionary, "poppins_bold", () => cjkFallbackFont.Value)
			   .SetFontColor(new DeviceRgb(255, 255, 255), 1f)
			   
			   .SetRotationAngle(0);
				label_kasaraporudokumform_78206758.Add(label_kasaraporudokumform_78206758_inside);
			}
            var label_kasaraporudokumform_78206758_renderHeight = 20f * pxToPtFactor > 0 ? 20f * pxToPtFactor : label_kasaraporudokumform_78206758_paragraphHeight;
            // Actual div height accounts for paragraph margins that may expand the Div beyond MinHeight
            // paragraphHeight was measured with MarginTop=0, but actual MarginTop = paddingTop + vAlignOffset
            var label_kasaraporudokumform_78206758_divHeight = Math.Max(label_kasaraporudokumform_78206758_renderHeight, label_kasaraporudokumform_78206758_paragraphHeight + (0 * pxToPtFactor) + label_kasaraporudokumform_78206758_vAlignOffset);
            var div_label_kasaraporudokumform_78206758 = new Div();
            div_label_kasaraporudokumform_78206758.SetMinHeight(label_kasaraporudokumform_78206758_renderHeight);
            div_label_kasaraporudokumform_78206758.SetBackgroundColor(new DeviceRgb(0, 0, 0), 0f);
            div_label_kasaraporudokumform_78206758.SetBorderBottom(Border.NO_BORDER);
            div_label_kasaraporudokumform_78206758.SetBorderTop(Border.NO_BORDER);
            div_label_kasaraporudokumform_78206758.SetBorderRight(Border.NO_BORDER);
            div_label_kasaraporudokumform_78206758.SetBorderLeft(Border.NO_BORDER);
            div_label_kasaraporudokumform_78206758.SetBorderRadius(new BorderRadius(0f * pxToPtFactor));
            div_label_kasaraporudokumform_78206758.Add(label_kasaraporudokumform_78206758);
            
            // Label/Icon inside Box: use box page coordinates for absolute positioning
            var label_kasaraporudokumform_78206758_yPos = box_kasaraporudokumform_480965570_pageTopY - (0f * pxToPtFactor) - label_kasaraporudokumform_78206758_divHeight;
            div_label_kasaraporudokumform_78206758.SetFixedPosition((float)(box_kasaraporudokumform_480965570_pageLeftX + (0f * pxToPtFactor)), (float)label_kasaraporudokumform_78206758_yPos, label_kasaraporudokumform_78206758_effectiveWidth);
            div_label_kasaraporudokumform_78206758.SetVisible(true);
            box_kasaraporudokumform_480965570_deferredAdds.Add(div_label_kasaraporudokumform_78206758);

            kasaraporudokumform_480965570_cell.SetVisible(box_kasaraporudokumform_480965570.IsVisible());
            box_kasaraporudokumform_480965570.AddCell(kasaraporudokumform_480965570_cell);
            
            // Draw rounded rectangle with PdfCanvas for border-radius support
            {
                var boxX = 10f * pxToPtFactor;
                var boxAbsY = Math.Abs(1320f * pxToPtFactor);
                var boxPageRelY = boxAbsY - pageStartY;
                var boxY = ((currentPageHeight > 0 ? currentPageHeight : canvasHeight.Value) - (boxPageRelY + Math.Abs(30f * pxToPtFactor)));
                var boxW = 790f * pxToPtFactor;
                var boxH = 30f * pxToPtFactor;
                var boxRadiusTL = 6f * pxToPtFactor;
                var boxRadiusTR = 6f * pxToPtFactor;
                var boxRadiusBR = 6f * pxToPtFactor;
                var boxRadiusBL = 6f * pxToPtFactor;
                float kappaTL = boxRadiusTL * 0.5522848f;
                float kappaTR = boxRadiusTR * 0.5522848f;
                float kappaBR = boxRadiusBR * 0.5522848f;
                float kappaBL = boxRadiusBL * 0.5522848f;
                var currentPage = pdf.GetPage(pdf.GetNumberOfPages());
                var pdfCanvas = new PdfCanvas(currentPage);

                // Draw rounded background with alpha support
                pdfCanvas.SaveState();
                pdfCanvas.SetExtGState(new PdfExtGState().SetFillOpacity(1f));
                pdfCanvas.SetFillColor(new DeviceRgb(114, 194, 64));
                pdfCanvas.MoveTo(boxX + boxRadiusBL, boxY);
                pdfCanvas.LineTo(boxX + boxW - boxRadiusBR, boxY);
                if (boxRadiusBR > 0) pdfCanvas.CurveTo(boxX + boxW - boxRadiusBR + kappaBR, boxY, boxX + boxW, boxY + boxRadiusBR - kappaBR, boxX + boxW, boxY + boxRadiusBR);
                pdfCanvas.LineTo(boxX + boxW, boxY + boxH - boxRadiusTR);
                if (boxRadiusTR > 0) pdfCanvas.CurveTo(boxX + boxW, boxY + boxH - boxRadiusTR + kappaTR, boxX + boxW - boxRadiusTR + kappaTR, boxY + boxH, boxX + boxW - boxRadiusTR, boxY + boxH);
                pdfCanvas.LineTo(boxX + boxRadiusTL, boxY + boxH);
                if (boxRadiusTL > 0) pdfCanvas.CurveTo(boxX + boxRadiusTL - kappaTL, boxY + boxH, boxX, boxY + boxH - boxRadiusTL + kappaTL, boxX, boxY + boxH - boxRadiusTL);
                pdfCanvas.LineTo(boxX, boxY + boxRadiusBL);
                if (boxRadiusBL > 0) pdfCanvas.CurveTo(boxX, boxY + boxRadiusBL - kappaBL, boxX + boxRadiusBL - kappaBL, boxY, boxX + boxRadiusBL, boxY);
                pdfCanvas.ClosePath();
                pdfCanvas.Fill();
                pdfCanvas.RestoreState();

                // Draw individual border edges with per-side widths
                var rrBorderColor = new DeviceRgb(114, 194, 64);
                float rrBorderTop = 1f * pxToPtFactor;
                float rrBorderRight = 1f * pxToPtFactor;
                float rrBorderBottom = 1f * pxToPtFactor;
                float rrBorderLeft = 1f * pxToPtFactor;

                // Top border (uses TL and TR corners)
                if (rrBorderTop > 0)
                {
                    pdfCanvas.SaveState();
                    pdfCanvas.SetExtGState(new PdfExtGState().SetStrokeOpacity(1f));
                    pdfCanvas.SetStrokeColor(rrBorderColor);
                    pdfCanvas.SetLineWidth(rrBorderTop);
                    pdfCanvas.MoveTo(boxX + boxRadiusTL, boxY + boxH);
                    pdfCanvas.LineTo(boxX + boxW - boxRadiusTR, boxY + boxH);
                    if (boxRadiusTR > 0) pdfCanvas.CurveTo(boxX + boxW - boxRadiusTR + kappaTR, boxY + boxH, boxX + boxW, boxY + boxH - boxRadiusTR + kappaTR, boxX + boxW, boxY + boxH - boxRadiusTR);
                    pdfCanvas.Stroke();
                    pdfCanvas.RestoreState();
                }

                // Right border (uses TR and BR corners)
                if (rrBorderRight > 0)
                {
                    pdfCanvas.SaveState();
                    pdfCanvas.SetExtGState(new PdfExtGState().SetStrokeOpacity(1f));
                    pdfCanvas.SetStrokeColor(rrBorderColor);
                    pdfCanvas.SetLineWidth(rrBorderRight);
                    pdfCanvas.MoveTo(boxX + boxW, boxY + boxH - boxRadiusTR);
                    pdfCanvas.LineTo(boxX + boxW, boxY + boxRadiusBR);
                    if (boxRadiusBR > 0) pdfCanvas.CurveTo(boxX + boxW, boxY + boxRadiusBR - kappaBR, boxX + boxW - boxRadiusBR + kappaBR, boxY, boxX + boxW - boxRadiusBR, boxY);
                    pdfCanvas.Stroke();
                    pdfCanvas.RestoreState();
                }

                // Bottom border (uses BR and BL corners)
                if (rrBorderBottom > 0)
                {
                    pdfCanvas.SaveState();
                    pdfCanvas.SetExtGState(new PdfExtGState().SetStrokeOpacity(1f));
                    pdfCanvas.SetStrokeColor(rrBorderColor);
                    pdfCanvas.SetLineWidth(rrBorderBottom);
                    pdfCanvas.MoveTo(boxX + boxW - boxRadiusBR, boxY);
                    pdfCanvas.LineTo(boxX + boxRadiusBL, boxY);
                    if (boxRadiusBL > 0) pdfCanvas.CurveTo(boxX + boxRadiusBL - kappaBL, boxY, boxX, boxY + boxRadiusBL - kappaBL, boxX, boxY + boxRadiusBL);
                    pdfCanvas.Stroke();
                    pdfCanvas.RestoreState();
                }

                // Left border (uses BL and TL corners)
                if (rrBorderLeft > 0)
                {
                    pdfCanvas.SaveState();
                    pdfCanvas.SetExtGState(new PdfExtGState().SetStrokeOpacity(1f));
                    pdfCanvas.SetStrokeColor(rrBorderColor);
                    pdfCanvas.SetLineWidth(rrBorderLeft);
                    pdfCanvas.MoveTo(boxX, boxY + boxRadiusBL);
                    pdfCanvas.LineTo(boxX, boxY + boxH - boxRadiusTL);
                    if (boxRadiusTL > 0) pdfCanvas.CurveTo(boxX, boxY + boxH - boxRadiusTL + kappaTL, boxX + boxRadiusTL - kappaTL, boxY + boxH, boxX + boxRadiusTL, boxY + boxH);
                    pdfCanvas.Stroke();
                    pdfCanvas.RestoreState();
                }
            }
            box_kasaraporudokumform_821829304_deferredAdds.Add(box_kasaraporudokumform_480965570);
            box_kasaraporudokumform_821829304_deferredAdds.AddRange(box_kasaraporudokumform_480965570_deferredAdds);
            }}


            //ReportTable5
            
            var kasaraporudokumform_488257375IsVisible = true;
            var kasaraporudokumform_488257375BackgroundColor = new DeviceRgb(0, 0, 0);
            var kasaraporudokumform_488257375BackgroundColorOpacity = 0f;
            var widths_kasaraporudokumform_488257375 = new List<float>();
widths_kasaraporudokumform_488257375.Add(102.05f * pxToPtFactor);
widths_kasaraporudokumform_488257375.Add(158.74f * pxToPtFactor);
widths_kasaraporudokumform_488257375.Add(143.62f * pxToPtFactor);
widths_kasaraporudokumform_488257375.Add(143.62f * pxToPtFactor);
widths_kasaraporudokumform_488257375.Add(75.59f * pxToPtFactor);
widths_kasaraporudokumform_488257375.Add(94.49f * pxToPtFactor);
var designWidth_kasaraporudokumform_488257375 = 718.11f * pxToPtFactor;
var tableWidth_kasaraporudokumform_488257375 = (widths_kasaraporudokumform_488257375.Sum() / designWidth_kasaraporudokumform_488257375) * (718.11f * pxToPtFactor);

            Table kasaraporudokumform_488257375 = new Table(widths_kasaraporudokumform_488257375.ToArray()).SetWidth(tableWidth_kasaraporudokumform_488257375)
            .SetBackgroundColor(kasaraporudokumform_488257375BackgroundColor, kasaraporudokumform_488257375BackgroundColorOpacity)
            .SetVisible(kasaraporudokumform_488257375IsVisible)
            .SetMarginBottom(0 * pxToPtFactor)
            .SetMarginLeft(0 * pxToPtFactor)
            .SetMarginTop(0 * pxToPtFactor)
            .SetMarginRight(0 * pxToPtFactor);
            
            kasaraporudokumform_488257375.SetBorderBottom(new SolidBorder(new DeviceRgb(218, 218, 218), 1 * pxToPtFactor, 1f));
            kasaraporudokumform_488257375.SetBorderTop(new SolidBorder(new DeviceRgb(218, 218, 218), 1 * pxToPtFactor, 1f));
            kasaraporudokumform_488257375.SetBorderRight(new SolidBorder(new DeviceRgb(218, 218, 218), 1 * pxToPtFactor, 1f));
            kasaraporudokumform_488257375.SetBorderLeft(new SolidBorder(new DeviceRgb(218, 218, 218), 1 * pxToPtFactor, 1f));
            kasaraporudokumform_488257375.SetBorderRadius(new BorderRadius(0f * pxToPtFactor));
            kasaraporudokumform_488257375.SetFixedLayout();
            Color kasaraporudokumform_488257375borderColor = new DeviceRgb(240, 240, 240);
            Border kasaraporudokumform_488257375leftBorder = new SolidBorder(kasaraporudokumform_488257375borderColor, 1 * pxToPtFactor);
            if (kasaraporudokumform_488257375IsVisible)
            {
                
            List<String> columnValueNames_kasaraporudokumform_488257375 = new List<String>() {"CashCurrAccCode", "KasaHesabiAdi", "CurrAccDescription", "LineDescription", "Tediye", "Tediye1"};
            
            var kasaraporudokumform_488257375_ColumTitlesPropValue = "";
            var kasaraporudokumform_488257375_ColumnTitles = new List<string>();
            if(kasaraporudokumform_488257375_ColumTitlesPropValue != null) {
               kasaraporudokumform_488257375_ColumnTitles = kasaraporudokumform_488257375_ColumTitlesPropValue.ToString()?.Split(";", StringSplitOptions.RemoveEmptyEntries).ToList();
            }
        
            
            Cell cell_0 = new Cell(1, 1);
            //cell_0.SetBorder(iText.Layout.Borders.Border.NO_BORDER)
            cell_0.SetBackgroundColor(new DeviceRgb(0, 0, 0), 0f);
            cell_0.SetBorderBottom(Border.NO_BORDER);
            cell_0.SetBorderTop(Border.NO_BORDER);
            cell_0.SetBorderRight(Border.NO_BORDER);
            cell_0.SetBorderLeft(Border.NO_BORDER);
            cell_0.SetBorderRadius(new BorderRadius(0f * pxToPtFactor));
            
            
            cell_0.SetPaddingBottom(0 * pxToPtFactor).SetPaddingLeft(0 * pxToPtFactor)
            .SetPaddingTop(0 * pxToPtFactor).SetPaddingRight(0 * pxToPtFactor).SetFontSize(14 * pxToPtFactor)
            .SetFont(fontDictionary["poppins_regular"]).SetFontColor(new DeviceRgb(155, 155, 155), 1f)
            .SetTextAlignment(iText.Layout.Properties.TextAlignment.LEFT);
            var headerParagraph_0 = new Paragraph((kasaraporudokumform_488257375_ColumnTitles is { Count: >= (0 + 1) } ? kasaraporudokumform_488257375_ColumnTitles[0] : kasaraporudokumform_488257375_ColumnTitles.Any() ? "" : ("Kasa Kodu".ConvertToType<String>())))
            
            .WithGlyphFallback(fontDictionary, "poppins_regular", () => cjkFallbackFont.Value);
            cell_0.Add(headerParagraph_0);
            
            cell_0.SetVisible(true);
            kasaraporudokumform_488257375.AddHeaderCell(cell_0);


            Cell cell_1 = new Cell(1, 1);
            //cell_1.SetBorder(iText.Layout.Borders.Border.NO_BORDER)
            cell_1.SetBackgroundColor(new DeviceRgb(0, 0, 0), 0f);
            cell_1.SetBorderBottom(Border.NO_BORDER);
            cell_1.SetBorderTop(Border.NO_BORDER);
            cell_1.SetBorderRight(Border.NO_BORDER);
            cell_1.SetBorderLeft(Border.NO_BORDER);
            cell_1.SetBorderRadius(new BorderRadius(0f * pxToPtFactor));
            
            if(true){cell_1.SetBorderLeft(kasaraporudokumform_488257375leftBorder);}
            cell_1.SetPaddingBottom(0 * pxToPtFactor).SetPaddingLeft(0 * pxToPtFactor)
            .SetPaddingTop(0 * pxToPtFactor).SetPaddingRight(0 * pxToPtFactor).SetFontSize(14 * pxToPtFactor)
            .SetFont(fontDictionary["poppins_regular"]).SetFontColor(new DeviceRgb(155, 155, 155), 1f)
            .SetTextAlignment(iText.Layout.Properties.TextAlignment.LEFT);
            var headerParagraph_1 = new Paragraph((kasaraporudokumform_488257375_ColumnTitles is { Count: >= (1 + 1) } ? kasaraporudokumform_488257375_ColumnTitles[1] : kasaraporudokumform_488257375_ColumnTitles.Any() ? "" : ("Kasa Adı".ConvertToType<String>())))
            
            .WithGlyphFallback(fontDictionary, "poppins_regular", () => cjkFallbackFont.Value);
            cell_1.Add(headerParagraph_1);
            
            cell_1.SetVisible(true);
            kasaraporudokumform_488257375.AddHeaderCell(cell_1);


            Cell cell_2 = new Cell(1, 1);
            //cell_2.SetBorder(iText.Layout.Borders.Border.NO_BORDER)
            cell_2.SetBackgroundColor(new DeviceRgb(0, 0, 0), 0f);
            cell_2.SetBorderBottom(Border.NO_BORDER);
            cell_2.SetBorderTop(Border.NO_BORDER);
            cell_2.SetBorderRight(Border.NO_BORDER);
            cell_2.SetBorderLeft(Border.NO_BORDER);
            cell_2.SetBorderRadius(new BorderRadius(0f * pxToPtFactor));
            
            if(true){cell_2.SetBorderLeft(kasaraporudokumform_488257375leftBorder);}
            cell_2.SetPaddingBottom(0 * pxToPtFactor).SetPaddingLeft(0 * pxToPtFactor)
            .SetPaddingTop(0 * pxToPtFactor).SetPaddingRight(0 * pxToPtFactor).SetFontSize(14 * pxToPtFactor)
            .SetFont(fontDictionary["poppins_regular"]).SetFontColor(new DeviceRgb(155, 155, 155), 1f)
            .SetTextAlignment(iText.Layout.Properties.TextAlignment.LEFT);
            var headerParagraph_2 = new Paragraph((kasaraporudokumform_488257375_ColumnTitles is { Count: >= (2 + 1) } ? kasaraporudokumform_488257375_ColumnTitles[2] : kasaraporudokumform_488257375_ColumnTitles.Any() ? "" : ("Banka Adı".ConvertToType<String>())))
            
            .WithGlyphFallback(fontDictionary, "poppins_regular", () => cjkFallbackFont.Value);
            cell_2.Add(headerParagraph_2);
            
            cell_2.SetVisible(true);
            kasaraporudokumform_488257375.AddHeaderCell(cell_2);


            Cell cell_3 = new Cell(1, 1);
            //cell_3.SetBorder(iText.Layout.Borders.Border.NO_BORDER)
            cell_3.SetBackgroundColor(new DeviceRgb(0, 0, 0), 0f);
            cell_3.SetBorderBottom(Border.NO_BORDER);
            cell_3.SetBorderTop(Border.NO_BORDER);
            cell_3.SetBorderRight(Border.NO_BORDER);
            cell_3.SetBorderLeft(Border.NO_BORDER);
            cell_3.SetBorderRadius(new BorderRadius(0f * pxToPtFactor));
            
            if(true){cell_3.SetBorderLeft(kasaraporudokumform_488257375leftBorder);}
            cell_3.SetPaddingBottom(0 * pxToPtFactor).SetPaddingLeft(0 * pxToPtFactor)
            .SetPaddingTop(0 * pxToPtFactor).SetPaddingRight(0 * pxToPtFactor).SetFontSize(14 * pxToPtFactor)
            .SetFont(fontDictionary["poppins_regular"]).SetFontColor(new DeviceRgb(155, 155, 155), 1f)
            .SetTextAlignment(iText.Layout.Properties.TextAlignment.LEFT);
            var headerParagraph_3 = new Paragraph((kasaraporudokumform_488257375_ColumnTitles is { Count: >= (3 + 1) } ? kasaraporudokumform_488257375_ColumnTitles[3] : kasaraporudokumform_488257375_ColumnTitles.Any() ? "" : ("Açıklama".ConvertToType<String>())))
            
            .WithGlyphFallback(fontDictionary, "poppins_regular", () => cjkFallbackFont.Value);
            cell_3.Add(headerParagraph_3);
            
            cell_3.SetVisible(true);
            kasaraporudokumform_488257375.AddHeaderCell(cell_3);


            Cell cell_4 = new Cell(1, 1);
            //cell_4.SetBorder(iText.Layout.Borders.Border.NO_BORDER)
            cell_4.SetBackgroundColor(new DeviceRgb(0, 0, 0), 0f);
            cell_4.SetBorderBottom(Border.NO_BORDER);
            cell_4.SetBorderTop(Border.NO_BORDER);
            cell_4.SetBorderRight(Border.NO_BORDER);
            cell_4.SetBorderLeft(Border.NO_BORDER);
            cell_4.SetBorderRadius(new BorderRadius(0f * pxToPtFactor));
            
            if(true){cell_4.SetBorderLeft(kasaraporudokumform_488257375leftBorder);}
            cell_4.SetPaddingBottom(0 * pxToPtFactor).SetPaddingLeft(0 * pxToPtFactor)
            .SetPaddingTop(0 * pxToPtFactor).SetPaddingRight(0 * pxToPtFactor).SetFontSize(14 * pxToPtFactor)
            .SetFont(fontDictionary["poppins_regular"]).SetFontColor(new DeviceRgb(155, 155, 155), 1f)
            .SetTextAlignment(iText.Layout.Properties.TextAlignment.LEFT);
            var headerParagraph_4 = new Paragraph((kasaraporudokumform_488257375_ColumnTitles is { Count: >= (4 + 1) } ? kasaraporudokumform_488257375_ColumnTitles[4] : kasaraporudokumform_488257375_ColumnTitles.Any() ? "" : ("Tutar".ConvertToType<String>())))
            
            .WithGlyphFallback(fontDictionary, "poppins_regular", () => cjkFallbackFont.Value);
            cell_4.Add(headerParagraph_4);
            
            cell_4.SetVisible(true);
            kasaraporudokumform_488257375.AddHeaderCell(cell_4);


            Cell cell_5 = new Cell(1, 1);
            //cell_5.SetBorder(iText.Layout.Borders.Border.NO_BORDER)
            cell_5.SetBackgroundColor(new DeviceRgb(0, 0, 0), 0f);
            cell_5.SetBorderBottom(Border.NO_BORDER);
            cell_5.SetBorderTop(Border.NO_BORDER);
            cell_5.SetBorderRight(Border.NO_BORDER);
            cell_5.SetBorderLeft(Border.NO_BORDER);
            cell_5.SetBorderRadius(new BorderRadius(0f * pxToPtFactor));
            
            if(true){cell_5.SetBorderLeft(kasaraporudokumform_488257375leftBorder);}
            cell_5.SetPaddingBottom(0 * pxToPtFactor).SetPaddingLeft(0 * pxToPtFactor)
            .SetPaddingTop(0 * pxToPtFactor).SetPaddingRight(0 * pxToPtFactor).SetFontSize(14 * pxToPtFactor)
            .SetFont(fontDictionary["poppins_regular"]).SetFontColor(new DeviceRgb(155, 155, 155), 1f)
            .SetTextAlignment(iText.Layout.Properties.TextAlignment.LEFT);
            var headerParagraph_5 = new Paragraph((kasaraporudokumform_488257375_ColumnTitles is { Count: >= (5 + 1) } ? kasaraporudokumform_488257375_ColumnTitles[5] : kasaraporudokumform_488257375_ColumnTitles.Any() ? "" : ("Tutar TRY ".ConvertToType<String>())))
            
            .WithGlyphFallback(fontDictionary, "poppins_regular", () => cjkFallbackFont.Value);
            cell_5.Add(headerParagraph_5);
            
            cell_5.SetVisible(true);
            kasaraporudokumform_488257375.AddHeaderCell(cell_5);


            
            var rowBackgroundColor = new DeviceRgb(0, 0, 0);
            var rowOpacity = 0;
            var isStriped = false;
            Color stripedColor = new DeviceRgb(245, 247, 250);
            for(int i = 0; i < result.Kuika_BankaKontrol5.Count; i++)
              {
                  var item = result.Kuika_BankaKontrol5[i];
                  Color backgroundColor = new DeviceRgb(255, 255, 255);
                  float backgroundColorOpacity = 0f;

                  if (kasaraporudokumform_488257375BackgroundColorOpacity == 1) {{
                        backgroundColor = kasaraporudokumform_488257375BackgroundColor;
                        backgroundColorOpacity = 1f;
                  }}

                  if (rowOpacity == 1) {{
                        backgroundColor = rowBackgroundColor;
                        backgroundColorOpacity = 1f;
                  }}

                  if (isStriped && i % 2 != 0) {{
                        backgroundColor = stripedColor;
                        backgroundColorOpacity = 1f;
                  }}

                  
                
            var colData_01564775084 = new Paragraph(item.CashCurrAccCode.ToFormattedString("", "", "") ?? "")
            .SetMarginBottom(0 * pxToPtFactor).SetMarginLeft(0 * pxToPtFactor)
            .SetMarginTop(0 * pxToPtFactor).SetMarginRight(0 * pxToPtFactor)
            .SetFontColor(new DeviceRgb(68, 68, 68), 1f)
            .SetBackgroundColor(new DeviceRgb(0, 0, 0), 0f)
            .SetFontSize(12 * pxToPtFactor)
            .SetFont(fontDictionary["poppins_regular"])
            .WithGlyphFallback(fontDictionary, "poppins_regular", () => cjkFallbackFont.Value)
            
            .SetParagraphWidthAndExtendHeightIfNotFit(document, 31.57f * pxToPtFactor, 20f * pxToPtFactor, true)
            .SetVisible(true)
            .SetVerticalAlignment(VerticalAlignment.TOP)
            .SetHorizontalAlignment(HorizontalAlignment.LEFT)
            .SetTextAlignment(TextAlignment.LEFT)
            .SetMultipliedLeading(1f);
            
colData_01564775084.SetVisible(true);

                Cell cell_1564775084 = new Cell(1, 1);
                var cell_1564775084BackgroundColor = new DeviceRgb(0, 0, 0);
                var cell_1564775084BackgroundColorOpacity = 0;
                
                cell_1564775084.SetMinHeight(40 * pxToPtFactor);
                //cell_1564775084.SetBorder(iText.Layout.Borders.Border.NO_BORDER);
                cell_1564775084.SetBorderBottom(Border.NO_BORDER);
                cell_1564775084.SetBorderTop(Border.NO_BORDER);
                cell_1564775084.SetBorderRight(Border.NO_BORDER);
                cell_1564775084.SetBorderLeft(Border.NO_BORDER);
                cell_1564775084.SetBorderRadius(new BorderRadius(0f * pxToPtFactor));
                //cell_1564775084.Add(colData_1564775084);
                if (cell_1564775084BackgroundColorOpacity == 1)
                    cell_1564775084.SetBackgroundColor(cell_1564775084BackgroundColor);
                else if (backgroundColorOpacity == 1)
                    cell_1564775084.SetBackgroundColor(backgroundColor);
                cell_1564775084.SetVerticalAlignment(iText.Layout.Properties.VerticalAlignment.TOP);
                cell_1564775084.SetTextAlignment(iText.Layout.Properties.TextAlignment.LEFT);
                cell_1564775084.SetPaddingBottom(0 * pxToPtFactor).SetPaddingLeft(0 * pxToPtFactor)
                .SetPaddingTop(0 * pxToPtFactor).SetPaddingRight(0 * pxToPtFactor);
                
                kasaraporudokumform_488257375.AddCell(cell_1564775084);

cell_1564775084.Add(colData_01564775084);

                
            var colData_01880794081 = new Paragraph(item.KasaHesabiAdi.ToFormattedString("", "", "") ?? "")
            .SetMarginBottom(0 * pxToPtFactor).SetMarginLeft(0 * pxToPtFactor)
            .SetMarginTop(0 * pxToPtFactor).SetMarginRight(0 * pxToPtFactor)
            .SetFontColor(new DeviceRgb(68, 68, 68), 1f)
            .SetBackgroundColor(new DeviceRgb(0, 0, 0), 0f)
            .SetFontSize(12 * pxToPtFactor)
            .SetFont(fontDictionary["poppins_regular"])
            .WithGlyphFallback(fontDictionary, "poppins_regular", () => cjkFallbackFont.Value)
            
            .SetParagraphWidthAndExtendHeightIfNotFit(document, 31.57f * pxToPtFactor, 20f * pxToPtFactor, true)
            .SetVisible(true)
            .SetVerticalAlignment(VerticalAlignment.TOP)
            .SetHorizontalAlignment(HorizontalAlignment.LEFT)
            .SetTextAlignment(TextAlignment.LEFT)
            .SetMultipliedLeading(1f);
            
colData_01880794081.SetVisible(true);

                Cell cell_1880794081 = new Cell(1, 1);
                var cell_1880794081BackgroundColor = new DeviceRgb(0, 0, 0);
                var cell_1880794081BackgroundColorOpacity = 0;
                
                cell_1880794081.SetMinHeight(40 * pxToPtFactor);
                //cell_1880794081.SetBorder(iText.Layout.Borders.Border.NO_BORDER);
                cell_1880794081.SetBorderBottom(Border.NO_BORDER);
                cell_1880794081.SetBorderTop(Border.NO_BORDER);
                cell_1880794081.SetBorderRight(Border.NO_BORDER);
                cell_1880794081.SetBorderLeft(Border.NO_BORDER);
                cell_1880794081.SetBorderRadius(new BorderRadius(0f * pxToPtFactor));
                //cell_1880794081.Add(colData_1880794081);
                if (cell_1880794081BackgroundColorOpacity == 1)
                    cell_1880794081.SetBackgroundColor(cell_1880794081BackgroundColor);
                else if (backgroundColorOpacity == 1)
                    cell_1880794081.SetBackgroundColor(backgroundColor);
                cell_1880794081.SetVerticalAlignment(iText.Layout.Properties.VerticalAlignment.TOP);
                cell_1880794081.SetTextAlignment(iText.Layout.Properties.TextAlignment.LEFT);
                cell_1880794081.SetPaddingBottom(0 * pxToPtFactor).SetPaddingLeft(0 * pxToPtFactor)
                .SetPaddingTop(0 * pxToPtFactor).SetPaddingRight(0 * pxToPtFactor);
                
                kasaraporudokumform_488257375.AddCell(cell_1880794081);

cell_1880794081.Add(colData_01880794081);

                
            var colData_01134503315 = new Paragraph(item.CurrAccDescription.ToFormattedString("", "", "") ?? "")
            .SetMarginBottom(0 * pxToPtFactor).SetMarginLeft(0 * pxToPtFactor)
            .SetMarginTop(0 * pxToPtFactor).SetMarginRight(0 * pxToPtFactor)
            .SetFontColor(new DeviceRgb(68, 68, 68), 1f)
            .SetBackgroundColor(new DeviceRgb(0, 0, 0), 0f)
            .SetFontSize(12 * pxToPtFactor)
            .SetFont(fontDictionary["poppins_regular"])
            .WithGlyphFallback(fontDictionary, "poppins_regular", () => cjkFallbackFont.Value)
            
            .SetParagraphWidthAndExtendHeightIfNotFit(document, 31.57f * pxToPtFactor, 20f * pxToPtFactor, true)
            .SetVisible(true)
            .SetVerticalAlignment(VerticalAlignment.TOP)
            .SetHorizontalAlignment(HorizontalAlignment.LEFT)
            .SetTextAlignment(TextAlignment.LEFT)
            .SetMultipliedLeading(1f);
            
colData_01134503315.SetVisible(true);

                Cell cell_1134503315 = new Cell(1, 1);
                var cell_1134503315BackgroundColor = new DeviceRgb(0, 0, 0);
                var cell_1134503315BackgroundColorOpacity = 0;
                
                cell_1134503315.SetMinHeight(40 * pxToPtFactor);
                //cell_1134503315.SetBorder(iText.Layout.Borders.Border.NO_BORDER);
                cell_1134503315.SetBorderBottom(Border.NO_BORDER);
                cell_1134503315.SetBorderTop(Border.NO_BORDER);
                cell_1134503315.SetBorderRight(Border.NO_BORDER);
                cell_1134503315.SetBorderLeft(Border.NO_BORDER);
                cell_1134503315.SetBorderRadius(new BorderRadius(0f * pxToPtFactor));
                //cell_1134503315.Add(colData_1134503315);
                if (cell_1134503315BackgroundColorOpacity == 1)
                    cell_1134503315.SetBackgroundColor(cell_1134503315BackgroundColor);
                else if (backgroundColorOpacity == 1)
                    cell_1134503315.SetBackgroundColor(backgroundColor);
                cell_1134503315.SetVerticalAlignment(iText.Layout.Properties.VerticalAlignment.TOP);
                cell_1134503315.SetTextAlignment(iText.Layout.Properties.TextAlignment.LEFT);
                cell_1134503315.SetPaddingBottom(0 * pxToPtFactor).SetPaddingLeft(0 * pxToPtFactor)
                .SetPaddingTop(0 * pxToPtFactor).SetPaddingRight(0 * pxToPtFactor);
                
                kasaraporudokumform_488257375.AddCell(cell_1134503315);

cell_1134503315.Add(colData_01134503315);

                
            var colData_0180948662 = new Paragraph(item.LineDescription.ToFormattedString("", "", "") ?? "")
            .SetMarginBottom(0 * pxToPtFactor).SetMarginLeft(0 * pxToPtFactor)
            .SetMarginTop(0 * pxToPtFactor).SetMarginRight(0 * pxToPtFactor)
            .SetFontColor(new DeviceRgb(68, 68, 68), 1f)
            .SetBackgroundColor(new DeviceRgb(0, 0, 0), 0f)
            .SetFontSize(12 * pxToPtFactor)
            .SetFont(fontDictionary["poppins_regular"])
            .WithGlyphFallback(fontDictionary, "poppins_regular", () => cjkFallbackFont.Value)
            
            .SetParagraphWidthAndExtendHeightIfNotFit(document, 31.57f * pxToPtFactor, 20f * pxToPtFactor, true)
            .SetVisible(true)
            .SetVerticalAlignment(VerticalAlignment.TOP)
            .SetHorizontalAlignment(HorizontalAlignment.LEFT)
            .SetTextAlignment(TextAlignment.LEFT)
            .SetMultipliedLeading(1f);
            
colData_0180948662.SetVisible(true);

                Cell cell_180948662 = new Cell(1, 1);
                var cell_180948662BackgroundColor = new DeviceRgb(0, 0, 0);
                var cell_180948662BackgroundColorOpacity = 0;
                
                cell_180948662.SetMinHeight(40 * pxToPtFactor);
                //cell_180948662.SetBorder(iText.Layout.Borders.Border.NO_BORDER);
                cell_180948662.SetBorderBottom(Border.NO_BORDER);
                cell_180948662.SetBorderTop(Border.NO_BORDER);
                cell_180948662.SetBorderRight(Border.NO_BORDER);
                cell_180948662.SetBorderLeft(Border.NO_BORDER);
                cell_180948662.SetBorderRadius(new BorderRadius(0f * pxToPtFactor));
                //cell_180948662.Add(colData_180948662);
                if (cell_180948662BackgroundColorOpacity == 1)
                    cell_180948662.SetBackgroundColor(cell_180948662BackgroundColor);
                else if (backgroundColorOpacity == 1)
                    cell_180948662.SetBackgroundColor(backgroundColor);
                cell_180948662.SetVerticalAlignment(iText.Layout.Properties.VerticalAlignment.TOP);
                cell_180948662.SetTextAlignment(iText.Layout.Properties.TextAlignment.LEFT);
                cell_180948662.SetPaddingBottom(0 * pxToPtFactor).SetPaddingLeft(0 * pxToPtFactor)
                .SetPaddingTop(0 * pxToPtFactor).SetPaddingRight(0 * pxToPtFactor);
                
                kasaraporudokumform_488257375.AddCell(cell_180948662);

cell_180948662.Add(colData_0180948662);

                
            var colData_01039010653 = new Paragraph(item.Tediye.ToFormattedString("", "", "") ?? "")
            .SetMarginBottom(0 * pxToPtFactor).SetMarginLeft(0 * pxToPtFactor)
            .SetMarginTop(0 * pxToPtFactor).SetMarginRight(0 * pxToPtFactor)
            .SetFontColor(new DeviceRgb(68, 68, 68), 1f)
            .SetBackgroundColor(new DeviceRgb(0, 0, 0), 0f)
            .SetFontSize(12 * pxToPtFactor)
            .SetFont(fontDictionary["poppins_regular"])
            .WithGlyphFallback(fontDictionary, "poppins_regular", () => cjkFallbackFont.Value)
            
            .SetParagraphWidthAndExtendHeightIfNotFit(document, 31.57f * pxToPtFactor, 20f * pxToPtFactor, true)
            .SetVisible(true)
            .SetVerticalAlignment(VerticalAlignment.TOP)
            .SetHorizontalAlignment(HorizontalAlignment.LEFT)
            .SetTextAlignment(TextAlignment.LEFT)
            .SetMultipliedLeading(1f);
            
colData_01039010653.SetVisible(true);

                Cell cell_1039010653 = new Cell(1, 1);
                var cell_1039010653BackgroundColor = new DeviceRgb(0, 0, 0);
                var cell_1039010653BackgroundColorOpacity = 0;
                
                cell_1039010653.SetMinHeight(40 * pxToPtFactor);
                //cell_1039010653.SetBorder(iText.Layout.Borders.Border.NO_BORDER);
                cell_1039010653.SetBorderBottom(Border.NO_BORDER);
                cell_1039010653.SetBorderTop(Border.NO_BORDER);
                cell_1039010653.SetBorderRight(Border.NO_BORDER);
                cell_1039010653.SetBorderLeft(Border.NO_BORDER);
                cell_1039010653.SetBorderRadius(new BorderRadius(0f * pxToPtFactor));
                //cell_1039010653.Add(colData_1039010653);
                if (cell_1039010653BackgroundColorOpacity == 1)
                    cell_1039010653.SetBackgroundColor(cell_1039010653BackgroundColor);
                else if (backgroundColorOpacity == 1)
                    cell_1039010653.SetBackgroundColor(backgroundColor);
                cell_1039010653.SetVerticalAlignment(iText.Layout.Properties.VerticalAlignment.TOP);
                cell_1039010653.SetTextAlignment(iText.Layout.Properties.TextAlignment.LEFT);
                cell_1039010653.SetPaddingBottom(0 * pxToPtFactor).SetPaddingLeft(0 * pxToPtFactor)
                .SetPaddingTop(0 * pxToPtFactor).SetPaddingRight(0 * pxToPtFactor);
                
                kasaraporudokumform_488257375.AddCell(cell_1039010653);

cell_1039010653.Add(colData_01039010653);

                
            var colData_01012149165 = new Paragraph(item.Tediye1.ToFormattedString("", "", "") ?? "")
            .SetMarginBottom(0 * pxToPtFactor).SetMarginLeft(0 * pxToPtFactor)
            .SetMarginTop(0 * pxToPtFactor).SetMarginRight(0 * pxToPtFactor)
            .SetFontColor(new DeviceRgb(68, 68, 68), 1f)
            .SetBackgroundColor(new DeviceRgb(0, 0, 0), 0f)
            .SetFontSize(12 * pxToPtFactor)
            .SetFont(fontDictionary["poppins_regular"])
            .WithGlyphFallback(fontDictionary, "poppins_regular", () => cjkFallbackFont.Value)
            
            .SetParagraphWidthAndExtendHeightIfNotFit(document, 31.57f * pxToPtFactor, 20f * pxToPtFactor, true)
            .SetVisible(true)
            .SetVerticalAlignment(VerticalAlignment.TOP)
            .SetHorizontalAlignment(HorizontalAlignment.LEFT)
            .SetTextAlignment(TextAlignment.LEFT)
            .SetMultipliedLeading(1f);
            
colData_01012149165.SetVisible(true);

                Cell cell_1012149165 = new Cell(1, 1);
                var cell_1012149165BackgroundColor = new DeviceRgb(0, 0, 0);
                var cell_1012149165BackgroundColorOpacity = 0;
                
                cell_1012149165.SetMinHeight(40 * pxToPtFactor);
                //cell_1012149165.SetBorder(iText.Layout.Borders.Border.NO_BORDER);
                cell_1012149165.SetBorderBottom(Border.NO_BORDER);
                cell_1012149165.SetBorderTop(Border.NO_BORDER);
                cell_1012149165.SetBorderRight(Border.NO_BORDER);
                cell_1012149165.SetBorderLeft(Border.NO_BORDER);
                cell_1012149165.SetBorderRadius(new BorderRadius(0f * pxToPtFactor));
                //cell_1012149165.Add(colData_1012149165);
                if (cell_1012149165BackgroundColorOpacity == 1)
                    cell_1012149165.SetBackgroundColor(cell_1012149165BackgroundColor);
                else if (backgroundColorOpacity == 1)
                    cell_1012149165.SetBackgroundColor(backgroundColor);
                cell_1012149165.SetVerticalAlignment(iText.Layout.Properties.VerticalAlignment.TOP);
                cell_1012149165.SetTextAlignment(iText.Layout.Properties.TextAlignment.LEFT);
                cell_1012149165.SetPaddingBottom(0 * pxToPtFactor).SetPaddingLeft(0 * pxToPtFactor)
                .SetPaddingTop(0 * pxToPtFactor).SetPaddingRight(0 * pxToPtFactor);
                
                kasaraporudokumform_488257375.AddCell(cell_1012149165);

cell_1012149165.Add(colData_01012149165);

              }



            kasaraporudokumform_488257375.SetMarginLeft(10f * pxToPtFactor + 0f * pxToPtFactor);
            if (Math.Abs(1360f * pxToPtFactor) > 0) {{
               kasaraporudokumform_488257375.SetMarginTop(Math.Abs(1360f * pxToPtFactor) + 0f * pxToPtFactor);
            }}
            kasaraporudokumform_821829304_cell.Add(kasaraporudokumform_488257375);
        }

   
            kasaraporudokumform_821829304_cell.SetVisible(box_kasaraporudokumform_821829304.IsVisible());
            box_kasaraporudokumform_821829304.AddCell(kasaraporudokumform_821829304_cell);
            
            // Draw rounded rectangle with PdfCanvas for border-radius support
            {
                var boxX = 10f * pxToPtFactor;
                var boxAbsY = Math.Abs(1320f * pxToPtFactor);
                var boxPageRelY = boxAbsY - pageStartY;
                var boxY = ((currentPageHeight > 0 ? currentPageHeight : canvasHeight.Value) - (boxPageRelY + Math.Abs(218f * pxToPtFactor)));
                var boxW = 780f * pxToPtFactor;
                var boxH = 218f * pxToPtFactor;
                var boxRadiusTL = 6f * pxToPtFactor;
                var boxRadiusTR = 6f * pxToPtFactor;
                var boxRadiusBR = 6f * pxToPtFactor;
                var boxRadiusBL = 6f * pxToPtFactor;
                float kappaTL = boxRadiusTL * 0.5522848f;
                float kappaTR = boxRadiusTR * 0.5522848f;
                float kappaBR = boxRadiusBR * 0.5522848f;
                float kappaBL = boxRadiusBL * 0.5522848f;
                var currentPage = pdf.GetPage(pdf.GetNumberOfPages());
                var pdfCanvas = new PdfCanvas(currentPage);

                // Draw rounded background with alpha support
                pdfCanvas.SaveState();
                pdfCanvas.SetExtGState(new PdfExtGState().SetFillOpacity(1f));
                pdfCanvas.SetFillColor(new DeviceRgb(255, 255, 255));
                pdfCanvas.MoveTo(boxX + boxRadiusBL, boxY);
                pdfCanvas.LineTo(boxX + boxW - boxRadiusBR, boxY);
                if (boxRadiusBR > 0) pdfCanvas.CurveTo(boxX + boxW - boxRadiusBR + kappaBR, boxY, boxX + boxW, boxY + boxRadiusBR - kappaBR, boxX + boxW, boxY + boxRadiusBR);
                pdfCanvas.LineTo(boxX + boxW, boxY + boxH - boxRadiusTR);
                if (boxRadiusTR > 0) pdfCanvas.CurveTo(boxX + boxW, boxY + boxH - boxRadiusTR + kappaTR, boxX + boxW - boxRadiusTR + kappaTR, boxY + boxH, boxX + boxW - boxRadiusTR, boxY + boxH);
                pdfCanvas.LineTo(boxX + boxRadiusTL, boxY + boxH);
                if (boxRadiusTL > 0) pdfCanvas.CurveTo(boxX + boxRadiusTL - kappaTL, boxY + boxH, boxX, boxY + boxH - boxRadiusTL + kappaTL, boxX, boxY + boxH - boxRadiusTL);
                pdfCanvas.LineTo(boxX, boxY + boxRadiusBL);
                if (boxRadiusBL > 0) pdfCanvas.CurveTo(boxX, boxY + boxRadiusBL - kappaBL, boxX + boxRadiusBL - kappaBL, boxY, boxX + boxRadiusBL, boxY);
                pdfCanvas.ClosePath();
                pdfCanvas.Fill();
                pdfCanvas.RestoreState();

                // Draw individual border edges with per-side widths
                var rrBorderColor = new DeviceRgb(238, 242, 246);
                float rrBorderTop = 1f * pxToPtFactor;
                float rrBorderRight = 1f * pxToPtFactor;
                float rrBorderBottom = 1f * pxToPtFactor;
                float rrBorderLeft = 1f * pxToPtFactor;

                // Top border (uses TL and TR corners)
                if (rrBorderTop > 0)
                {
                    pdfCanvas.SaveState();
                    pdfCanvas.SetExtGState(new PdfExtGState().SetStrokeOpacity(1f));
                    pdfCanvas.SetStrokeColor(rrBorderColor);
                    pdfCanvas.SetLineWidth(rrBorderTop);
                    pdfCanvas.MoveTo(boxX + boxRadiusTL, boxY + boxH);
                    pdfCanvas.LineTo(boxX + boxW - boxRadiusTR, boxY + boxH);
                    if (boxRadiusTR > 0) pdfCanvas.CurveTo(boxX + boxW - boxRadiusTR + kappaTR, boxY + boxH, boxX + boxW, boxY + boxH - boxRadiusTR + kappaTR, boxX + boxW, boxY + boxH - boxRadiusTR);
                    pdfCanvas.Stroke();
                    pdfCanvas.RestoreState();
                }

                // Right border (uses TR and BR corners)
                if (rrBorderRight > 0)
                {
                    pdfCanvas.SaveState();
                    pdfCanvas.SetExtGState(new PdfExtGState().SetStrokeOpacity(1f));
                    pdfCanvas.SetStrokeColor(rrBorderColor);
                    pdfCanvas.SetLineWidth(rrBorderRight);
                    pdfCanvas.MoveTo(boxX + boxW, boxY + boxH - boxRadiusTR);
                    pdfCanvas.LineTo(boxX + boxW, boxY + boxRadiusBR);
                    if (boxRadiusBR > 0) pdfCanvas.CurveTo(boxX + boxW, boxY + boxRadiusBR - kappaBR, boxX + boxW - boxRadiusBR + kappaBR, boxY, boxX + boxW - boxRadiusBR, boxY);
                    pdfCanvas.Stroke();
                    pdfCanvas.RestoreState();
                }

                // Bottom border (uses BR and BL corners)
                if (rrBorderBottom > 0)
                {
                    pdfCanvas.SaveState();
                    pdfCanvas.SetExtGState(new PdfExtGState().SetStrokeOpacity(1f));
                    pdfCanvas.SetStrokeColor(rrBorderColor);
                    pdfCanvas.SetLineWidth(rrBorderBottom);
                    pdfCanvas.MoveTo(boxX + boxW - boxRadiusBR, boxY);
                    pdfCanvas.LineTo(boxX + boxRadiusBL, boxY);
                    if (boxRadiusBL > 0) pdfCanvas.CurveTo(boxX + boxRadiusBL - kappaBL, boxY, boxX, boxY + boxRadiusBL - kappaBL, boxX, boxY + boxRadiusBL);
                    pdfCanvas.Stroke();
                    pdfCanvas.RestoreState();
                }

                // Left border (uses BL and TL corners)
                if (rrBorderLeft > 0)
                {
                    pdfCanvas.SaveState();
                    pdfCanvas.SetExtGState(new PdfExtGState().SetStrokeOpacity(1f));
                    pdfCanvas.SetStrokeColor(rrBorderColor);
                    pdfCanvas.SetLineWidth(rrBorderLeft);
                    pdfCanvas.MoveTo(boxX, boxY + boxRadiusBL);
                    pdfCanvas.LineTo(boxX, boxY + boxH - boxRadiusTL);
                    if (boxRadiusTL > 0) pdfCanvas.CurveTo(boxX, boxY + boxH - boxRadiusTL + kappaTL, boxX + boxRadiusTL - kappaTL, boxY + boxH, boxX + boxRadiusTL, boxY + boxH);
                    pdfCanvas.Stroke();
                    pdfCanvas.RestoreState();
                }
            }
            document.Add(box_kasaraporudokumform_821829304);
            foreach (var deferredElem in box_kasaraporudokumform_821829304_deferredAdds) document.Add(deferredElem);
            }}


            //Box12
            Table box_kasaraporudokumform_2024004537 = new Table(1).SetWidth(780f * pxToPtFactor).SetHeight(218f * pxToPtFactor)
            .SetFontColor(new DeviceRgb(0, 0, 0), 1f)
            .SetFontSize(20 * pxToPtFactor)
            .SetVisible(true);
            if (box_kasaraporudokumform_2024004537.IsVisible()) {{
            var box_kasaraporudokumform_2024004537_pageLeftX = (double)(5f * pxToPtFactor) ;
            var box_kasaraporudokumform_2024004537_pageTopY = 0d;
            var box_kasaraporudokumform_2024004537_deferredAdds = new List<IBlockElement>();
            if (!false) {
            // Calculate page-relative Y position
            var box_kasaraporudokumform_2024004537_absoluteY = Math.Abs(1583.5f * pxToPtFactor);
            var box_kasaraporudokumform_2024004537_pageRelativeY = box_kasaraporudokumform_2024004537_absoluteY - pageStartY;
            int box_kasaraporudokumform_2024004537_targetPage = pdf.GetNumberOfPages();
            
            box_kasaraporudokumform_2024004537.SetFixedPosition(box_kasaraporudokumform_2024004537_targetPage, 5f * pxToPtFactor , ((currentPageHeight > 0 ? currentPageHeight : canvasHeight.Value) - (box_kasaraporudokumform_2024004537_pageRelativeY + Math.Abs(218f * pxToPtFactor))) , 780f * pxToPtFactor);
            box_kasaraporudokumform_2024004537_pageTopY = ((double)(currentPageHeight > 0 ? currentPageHeight : canvasHeight.Value) - box_kasaraporudokumform_2024004537_pageRelativeY) ;
            } else {
            box_kasaraporudokumform_2024004537.SetFixedPosition(5f * pxToPtFactor , ((currentPageHeight > 0 ? currentPageHeight : canvasHeight.Value) - (totalHeight + Math.Abs(1583.5f * pxToPtFactor) + Math.Abs(218f * pxToPtFactor))) , 780f * pxToPtFactor);
            box_kasaraporudokumform_2024004537_pageTopY = ((double)(currentPageHeight > 0 ? currentPageHeight : canvasHeight.Value) - (totalHeight + Math.Abs(1583.5f * pxToPtFactor))) ;
            }
            box_kasaraporudokumform_2024004537.SetBorder(Border.NO_BORDER);
            box_kasaraporudokumform_2024004537.SetBorderBottom(Border.NO_BORDER);
            box_kasaraporudokumform_2024004537.SetBorderTop(Border.NO_BORDER);
            box_kasaraporudokumform_2024004537.SetBorderRight(Border.NO_BORDER);
            box_kasaraporudokumform_2024004537.SetBorderLeft(Border.NO_BORDER);
            box_kasaraporudokumform_2024004537.SetBorderRadius(new BorderRadius(6f * pxToPtFactor));
            var heightOf_box_kasaraporudokumform_2024004537 = box_kasaraporudokumform_2024004537.GetHeight();
            Cell kasaraporudokumform_2024004537_cell = new Cell();
            kasaraporudokumform_2024004537_cell.SetBackgroundColor(new DeviceRgb(255, 255, 255), 0f);
            kasaraporudokumform_2024004537_cell.SetBorder(Border.NO_BORDER);
            
            // NOTE: Box always uses SetFixedPosition above (both branches), so it does not
            // contribute to flow. The legacy "totalHeight + height > canvasHeight" areaBreak
            // that lived here was reading totalHeight produced by previous flow elements
            // (e.g. multi-page ReportTables) and spuriously creating a new page + bumping
            // pageStartY, which broke pageRelativeY for every subsequent element. Removed.

            // No page breaks - using default canvas height behavior


            //Box13
            Table box_kasaraporudokumform_162401159 = new Table(1).SetWidth(790f * pxToPtFactor).SetHeight(30f * pxToPtFactor)
            .SetFontColor(new DeviceRgb(0, 0, 0), 1f)
            .SetFontSize(20 * pxToPtFactor)
            .SetVisible(true);
            if (box_kasaraporudokumform_162401159.IsVisible()) {{
            var box_kasaraporudokumform_162401159_pageLeftX = (double)(5f * pxToPtFactor) ;
            var box_kasaraporudokumform_162401159_pageTopY = 0d;
            var box_kasaraporudokumform_162401159_deferredAdds = new List<IBlockElement>();
            if (!false) {
            // Calculate page-relative Y position
            var box_kasaraporudokumform_162401159_absoluteY = Math.Abs(1583.5f * pxToPtFactor);
            var box_kasaraporudokumform_162401159_pageRelativeY = box_kasaraporudokumform_162401159_absoluteY - pageStartY;
            int box_kasaraporudokumform_162401159_targetPage = pdf.GetNumberOfPages();
            
            box_kasaraporudokumform_162401159.SetFixedPosition(box_kasaraporudokumform_162401159_targetPage, 5f * pxToPtFactor , ((currentPageHeight > 0 ? currentPageHeight : canvasHeight.Value) - (box_kasaraporudokumform_162401159_pageRelativeY + Math.Abs(30f * pxToPtFactor))) , 790f * pxToPtFactor);
            box_kasaraporudokumform_162401159_pageTopY = ((double)(currentPageHeight > 0 ? currentPageHeight : canvasHeight.Value) - box_kasaraporudokumform_162401159_pageRelativeY) ;
            } else {
            box_kasaraporudokumform_162401159.SetFixedPosition(5f * pxToPtFactor , ((currentPageHeight > 0 ? currentPageHeight : canvasHeight.Value) - (totalHeight + Math.Abs(1583.5f * pxToPtFactor) + Math.Abs(30f * pxToPtFactor))) , 790f * pxToPtFactor);
            box_kasaraporudokumform_162401159_pageTopY = ((double)(currentPageHeight > 0 ? currentPageHeight : canvasHeight.Value) - (totalHeight + Math.Abs(1583.5f * pxToPtFactor))) ;
            }
            box_kasaraporudokumform_162401159.SetBorder(Border.NO_BORDER);
            box_kasaraporudokumform_162401159.SetBorderBottom(Border.NO_BORDER);
            box_kasaraporudokumform_162401159.SetBorderTop(Border.NO_BORDER);
            box_kasaraporudokumform_162401159.SetBorderRight(Border.NO_BORDER);
            box_kasaraporudokumform_162401159.SetBorderLeft(Border.NO_BORDER);
            box_kasaraporudokumform_162401159.SetBorderRadius(new BorderRadius(6f * pxToPtFactor));
            var heightOf_box_kasaraporudokumform_162401159 = box_kasaraporudokumform_162401159.GetHeight();
            Cell kasaraporudokumform_162401159_cell = new Cell();
            kasaraporudokumform_162401159_cell.SetBackgroundColor(new DeviceRgb(114, 194, 64), 0f);
            kasaraporudokumform_162401159_cell.SetBorder(Border.NO_BORDER);
            
            // NOTE: Box always uses SetFixedPosition above (both branches), so it does not
            // contribute to flow. The legacy "totalHeight + height > canvasHeight" areaBreak
            // that lived here was reading totalHeight produced by previous flow elements
            // (e.g. multi-page ReportTables) and spuriously creating a new page + bumping
            // pageStartY, which broke pageRelativeY for every subsequent element. Removed.

            // No page breaks - using default canvas height behavior


            //Label14
            var label_kasaraporudokumform_775361310_effectiveWidth = 780f * pxToPtFactor > 0 ? 780f * pxToPtFactor : (canvasWidth.Value - (5f * pxToPtFactor));
            Paragraph label_kasaraporudokumform_775361310 = new Paragraph(@"Gün Sonu Kasa Bakiyesi")
            .SetFontSize(15 * pxToPtFactor)
            .SetFont(fontDictionary["poppins_bold"])
            .WithGlyphFallback(fontDictionary, "poppins_bold", () => cjkFallbackFont.Value)
            .SetTextAlignment(TextAlignment.CENTER)
            
            .SetParagraphWidthAndExtendHeightIfNotFit(document, label_kasaraporudokumform_775361310_effectiveWidth, 20f * pxToPtFactor, false, false || false)
            .SetMultipliedLeading(0.875f);
            

            if (20f * pxToPtFactor == 0f)
            {
                label_kasaraporudokumform_775361310.SetMaxHeight((30f * pxToPtFactor) - Math.Abs(1583.5f * pxToPtFactor));
            }

            label_kasaraporudokumform_775361310.SetMarginBottom(0 * pxToPtFactor).SetMarginTop(0f);
            var label_kasaraporudokumform_775361310_paragraphHeight = label_kasaraporudokumform_775361310.GetHeightOfParagraph(document);
            var label_kasaraporudokumform_775361310_vAlignOffset = 0f;
            label_kasaraporudokumform_775361310_vAlignOffset = Math.Max(0f, (20f * pxToPtFactor - label_kasaraporudokumform_775361310_paragraphHeight) / 2f);
            label_kasaraporudokumform_775361310.SetMarginLeft(0 * pxToPtFactor)
            .SetMarginTop((0 * pxToPtFactor) + label_kasaraporudokumform_775361310_vAlignOffset).SetMarginRight(0 * pxToPtFactor)
            .SetFontColor(new DeviceRgb(255, 255, 255), 1f)
            .SetVisible(true);
            
            if (false)
			{
				Paragraph label_kasaraporudokumform_775361310_inside = new Paragraph(@"Gün Sonu Kasa Bakiyesi")
			   .SetFontSize(15 * pxToPtFactor)
               .SetFont(fontDictionary["poppins_bold"])
			   .WithGlyphFallback(fontDictionary, "poppins_bold", () => cjkFallbackFont.Value)
			   .SetFontColor(new DeviceRgb(255, 255, 255), 1f)
			   
			   .SetRotationAngle(0);
				label_kasaraporudokumform_775361310.Add(label_kasaraporudokumform_775361310_inside);
			}
            var label_kasaraporudokumform_775361310_renderHeight = 20f * pxToPtFactor > 0 ? 20f * pxToPtFactor : label_kasaraporudokumform_775361310_paragraphHeight;
            // Actual div height accounts for paragraph margins that may expand the Div beyond MinHeight
            // paragraphHeight was measured with MarginTop=0, but actual MarginTop = paddingTop + vAlignOffset
            var label_kasaraporudokumform_775361310_divHeight = Math.Max(label_kasaraporudokumform_775361310_renderHeight, label_kasaraporudokumform_775361310_paragraphHeight + (0 * pxToPtFactor) + label_kasaraporudokumform_775361310_vAlignOffset);
            var div_label_kasaraporudokumform_775361310 = new Div();
            div_label_kasaraporudokumform_775361310.SetMinHeight(label_kasaraporudokumform_775361310_renderHeight);
            div_label_kasaraporudokumform_775361310.SetBackgroundColor(new DeviceRgb(0, 0, 0), 0f);
            div_label_kasaraporudokumform_775361310.SetBorderBottom(Border.NO_BORDER);
            div_label_kasaraporudokumform_775361310.SetBorderTop(Border.NO_BORDER);
            div_label_kasaraporudokumform_775361310.SetBorderRight(Border.NO_BORDER);
            div_label_kasaraporudokumform_775361310.SetBorderLeft(Border.NO_BORDER);
            div_label_kasaraporudokumform_775361310.SetBorderRadius(new BorderRadius(0f * pxToPtFactor));
            div_label_kasaraporudokumform_775361310.Add(label_kasaraporudokumform_775361310);
            
            // Label/Icon inside Box: use box page coordinates for absolute positioning
            var label_kasaraporudokumform_775361310_yPos = box_kasaraporudokumform_162401159_pageTopY - (0f * pxToPtFactor) - label_kasaraporudokumform_775361310_divHeight;
            div_label_kasaraporudokumform_775361310.SetFixedPosition((float)(box_kasaraporudokumform_162401159_pageLeftX + (0f * pxToPtFactor)), (float)label_kasaraporudokumform_775361310_yPos, label_kasaraporudokumform_775361310_effectiveWidth);
            div_label_kasaraporudokumform_775361310.SetVisible(true);
            box_kasaraporudokumform_162401159_deferredAdds.Add(div_label_kasaraporudokumform_775361310);

            kasaraporudokumform_162401159_cell.SetVisible(box_kasaraporudokumform_162401159.IsVisible());
            box_kasaraporudokumform_162401159.AddCell(kasaraporudokumform_162401159_cell);
            
            // Draw rounded rectangle with PdfCanvas for border-radius support
            {
                var boxX = 5f * pxToPtFactor;
                var boxAbsY = Math.Abs(1583.5f * pxToPtFactor);
                var boxPageRelY = boxAbsY - pageStartY;
                var boxY = ((currentPageHeight > 0 ? currentPageHeight : canvasHeight.Value) - (boxPageRelY + Math.Abs(30f * pxToPtFactor)));
                var boxW = 790f * pxToPtFactor;
                var boxH = 30f * pxToPtFactor;
                var boxRadiusTL = 6f * pxToPtFactor;
                var boxRadiusTR = 6f * pxToPtFactor;
                var boxRadiusBR = 6f * pxToPtFactor;
                var boxRadiusBL = 6f * pxToPtFactor;
                float kappaTL = boxRadiusTL * 0.5522848f;
                float kappaTR = boxRadiusTR * 0.5522848f;
                float kappaBR = boxRadiusBR * 0.5522848f;
                float kappaBL = boxRadiusBL * 0.5522848f;
                var currentPage = pdf.GetPage(pdf.GetNumberOfPages());
                var pdfCanvas = new PdfCanvas(currentPage);

                // Draw rounded background with alpha support
                pdfCanvas.SaveState();
                pdfCanvas.SetExtGState(new PdfExtGState().SetFillOpacity(1f));
                pdfCanvas.SetFillColor(new DeviceRgb(114, 194, 64));
                pdfCanvas.MoveTo(boxX + boxRadiusBL, boxY);
                pdfCanvas.LineTo(boxX + boxW - boxRadiusBR, boxY);
                if (boxRadiusBR > 0) pdfCanvas.CurveTo(boxX + boxW - boxRadiusBR + kappaBR, boxY, boxX + boxW, boxY + boxRadiusBR - kappaBR, boxX + boxW, boxY + boxRadiusBR);
                pdfCanvas.LineTo(boxX + boxW, boxY + boxH - boxRadiusTR);
                if (boxRadiusTR > 0) pdfCanvas.CurveTo(boxX + boxW, boxY + boxH - boxRadiusTR + kappaTR, boxX + boxW - boxRadiusTR + kappaTR, boxY + boxH, boxX + boxW - boxRadiusTR, boxY + boxH);
                pdfCanvas.LineTo(boxX + boxRadiusTL, boxY + boxH);
                if (boxRadiusTL > 0) pdfCanvas.CurveTo(boxX + boxRadiusTL - kappaTL, boxY + boxH, boxX, boxY + boxH - boxRadiusTL + kappaTL, boxX, boxY + boxH - boxRadiusTL);
                pdfCanvas.LineTo(boxX, boxY + boxRadiusBL);
                if (boxRadiusBL > 0) pdfCanvas.CurveTo(boxX, boxY + boxRadiusBL - kappaBL, boxX + boxRadiusBL - kappaBL, boxY, boxX + boxRadiusBL, boxY);
                pdfCanvas.ClosePath();
                pdfCanvas.Fill();
                pdfCanvas.RestoreState();

                // Draw individual border edges with per-side widths
                var rrBorderColor = new DeviceRgb(114, 194, 64);
                float rrBorderTop = 1f * pxToPtFactor;
                float rrBorderRight = 1f * pxToPtFactor;
                float rrBorderBottom = 1f * pxToPtFactor;
                float rrBorderLeft = 1f * pxToPtFactor;

                // Top border (uses TL and TR corners)
                if (rrBorderTop > 0)
                {
                    pdfCanvas.SaveState();
                    pdfCanvas.SetExtGState(new PdfExtGState().SetStrokeOpacity(1f));
                    pdfCanvas.SetStrokeColor(rrBorderColor);
                    pdfCanvas.SetLineWidth(rrBorderTop);
                    pdfCanvas.MoveTo(boxX + boxRadiusTL, boxY + boxH);
                    pdfCanvas.LineTo(boxX + boxW - boxRadiusTR, boxY + boxH);
                    if (boxRadiusTR > 0) pdfCanvas.CurveTo(boxX + boxW - boxRadiusTR + kappaTR, boxY + boxH, boxX + boxW, boxY + boxH - boxRadiusTR + kappaTR, boxX + boxW, boxY + boxH - boxRadiusTR);
                    pdfCanvas.Stroke();
                    pdfCanvas.RestoreState();
                }

                // Right border (uses TR and BR corners)
                if (rrBorderRight > 0)
                {
                    pdfCanvas.SaveState();
                    pdfCanvas.SetExtGState(new PdfExtGState().SetStrokeOpacity(1f));
                    pdfCanvas.SetStrokeColor(rrBorderColor);
                    pdfCanvas.SetLineWidth(rrBorderRight);
                    pdfCanvas.MoveTo(boxX + boxW, boxY + boxH - boxRadiusTR);
                    pdfCanvas.LineTo(boxX + boxW, boxY + boxRadiusBR);
                    if (boxRadiusBR > 0) pdfCanvas.CurveTo(boxX + boxW, boxY + boxRadiusBR - kappaBR, boxX + boxW - boxRadiusBR + kappaBR, boxY, boxX + boxW - boxRadiusBR, boxY);
                    pdfCanvas.Stroke();
                    pdfCanvas.RestoreState();
                }

                // Bottom border (uses BR and BL corners)
                if (rrBorderBottom > 0)
                {
                    pdfCanvas.SaveState();
                    pdfCanvas.SetExtGState(new PdfExtGState().SetStrokeOpacity(1f));
                    pdfCanvas.SetStrokeColor(rrBorderColor);
                    pdfCanvas.SetLineWidth(rrBorderBottom);
                    pdfCanvas.MoveTo(boxX + boxW - boxRadiusBR, boxY);
                    pdfCanvas.LineTo(boxX + boxRadiusBL, boxY);
                    if (boxRadiusBL > 0) pdfCanvas.CurveTo(boxX + boxRadiusBL - kappaBL, boxY, boxX, boxY + boxRadiusBL - kappaBL, boxX, boxY + boxRadiusBL);
                    pdfCanvas.Stroke();
                    pdfCanvas.RestoreState();
                }

                // Left border (uses BL and TL corners)
                if (rrBorderLeft > 0)
                {
                    pdfCanvas.SaveState();
                    pdfCanvas.SetExtGState(new PdfExtGState().SetStrokeOpacity(1f));
                    pdfCanvas.SetStrokeColor(rrBorderColor);
                    pdfCanvas.SetLineWidth(rrBorderLeft);
                    pdfCanvas.MoveTo(boxX, boxY + boxRadiusBL);
                    pdfCanvas.LineTo(boxX, boxY + boxH - boxRadiusTL);
                    if (boxRadiusTL > 0) pdfCanvas.CurveTo(boxX, boxY + boxH - boxRadiusTL + kappaTL, boxX + boxRadiusTL - kappaTL, boxY + boxH, boxX + boxRadiusTL, boxY + boxH);
                    pdfCanvas.Stroke();
                    pdfCanvas.RestoreState();
                }
            }
            box_kasaraporudokumform_2024004537_deferredAdds.Add(box_kasaraporudokumform_162401159);
            box_kasaraporudokumform_2024004537_deferredAdds.AddRange(box_kasaraporudokumform_162401159_deferredAdds);
            }}


            //ReportTable6
            
            var kasaraporudokumform_1931465243IsVisible = true;
            var kasaraporudokumform_1931465243BackgroundColor = new DeviceRgb(0, 0, 0);
            var kasaraporudokumform_1931465243BackgroundColorOpacity = 0f;
            var widths_kasaraporudokumform_1931465243 = new List<float>();
widths_kasaraporudokumform_1931465243.Add(113.39f * pxToPtFactor);
widths_kasaraporudokumform_1931465243.Add(234.33f * pxToPtFactor);
widths_kasaraporudokumform_1931465243.Add(83.15f * pxToPtFactor);
widths_kasaraporudokumform_1931465243.Add(128.5f * pxToPtFactor);
widths_kasaraporudokumform_1931465243.Add(158.74f * pxToPtFactor);
var designWidth_kasaraporudokumform_1931465243 = 718.11f * pxToPtFactor;
var tableWidth_kasaraporudokumform_1931465243 = (widths_kasaraporudokumform_1931465243.Sum() / designWidth_kasaraporudokumform_1931465243) * (718.11f * pxToPtFactor);

            Table kasaraporudokumform_1931465243 = new Table(widths_kasaraporudokumform_1931465243.ToArray()).SetWidth(tableWidth_kasaraporudokumform_1931465243)
            .SetBackgroundColor(kasaraporudokumform_1931465243BackgroundColor, kasaraporudokumform_1931465243BackgroundColorOpacity)
            .SetVisible(kasaraporudokumform_1931465243IsVisible)
            .SetMarginBottom(0 * pxToPtFactor)
            .SetMarginLeft(0 * pxToPtFactor)
            .SetMarginTop(0 * pxToPtFactor)
            .SetMarginRight(0 * pxToPtFactor);
            
            kasaraporudokumform_1931465243.SetBorderBottom(new SolidBorder(new DeviceRgb(218, 218, 218), 1 * pxToPtFactor, 1f));
            kasaraporudokumform_1931465243.SetBorderTop(new SolidBorder(new DeviceRgb(218, 218, 218), 1 * pxToPtFactor, 1f));
            kasaraporudokumform_1931465243.SetBorderRight(new SolidBorder(new DeviceRgb(218, 218, 218), 1 * pxToPtFactor, 1f));
            kasaraporudokumform_1931465243.SetBorderLeft(new SolidBorder(new DeviceRgb(218, 218, 218), 1 * pxToPtFactor, 1f));
            kasaraporudokumform_1931465243.SetBorderRadius(new BorderRadius(0f * pxToPtFactor));
            kasaraporudokumform_1931465243.SetFixedLayout();
            Color kasaraporudokumform_1931465243borderColor = new DeviceRgb(240, 240, 240);
            Border kasaraporudokumform_1931465243leftBorder = new SolidBorder(kasaraporudokumform_1931465243borderColor, 1 * pxToPtFactor);
            if (kasaraporudokumform_1931465243IsVisible)
            {
                
            List<String> columnValueNames_kasaraporudokumform_1931465243 = new List<String>() {"CurrAccCode", "CurrAccDescription", "CurrencyCode", "Balance", "Balance1"};
            
            var kasaraporudokumform_1931465243_ColumTitlesPropValue = "";
            var kasaraporudokumform_1931465243_ColumnTitles = new List<string>();
            if(kasaraporudokumform_1931465243_ColumTitlesPropValue != null) {
               kasaraporudokumform_1931465243_ColumnTitles = kasaraporudokumform_1931465243_ColumTitlesPropValue.ToString()?.Split(";", StringSplitOptions.RemoveEmptyEntries).ToList();
            }
        
            
            Cell cell_0 = new Cell(1, 1);
            //cell_0.SetBorder(iText.Layout.Borders.Border.NO_BORDER)
            cell_0.SetBackgroundColor(new DeviceRgb(0, 0, 0), 0f);
            cell_0.SetBorderBottom(Border.NO_BORDER);
            cell_0.SetBorderTop(Border.NO_BORDER);
            cell_0.SetBorderRight(Border.NO_BORDER);
            cell_0.SetBorderLeft(Border.NO_BORDER);
            cell_0.SetBorderRadius(new BorderRadius(0f * pxToPtFactor));
            
            
            cell_0.SetPaddingBottom(0 * pxToPtFactor).SetPaddingLeft(0 * pxToPtFactor)
            .SetPaddingTop(0 * pxToPtFactor).SetPaddingRight(0 * pxToPtFactor).SetFontSize(14 * pxToPtFactor)
            .SetFont(fontDictionary["poppins_regular"]).SetFontColor(new DeviceRgb(155, 155, 155), 1f)
            .SetTextAlignment(iText.Layout.Properties.TextAlignment.LEFT);
            var headerParagraph_0 = new Paragraph((kasaraporudokumform_1931465243_ColumnTitles is { Count: >= (0 + 1) } ? kasaraporudokumform_1931465243_ColumnTitles[0] : kasaraporudokumform_1931465243_ColumnTitles.Any() ? "" : ("Kasa Kodu".ConvertToType<String>())))
            
            .WithGlyphFallback(fontDictionary, "poppins_regular", () => cjkFallbackFont.Value);
            cell_0.Add(headerParagraph_0);
            
            cell_0.SetVisible(true);
            kasaraporudokumform_1931465243.AddHeaderCell(cell_0);


            Cell cell_1 = new Cell(1, 1);
            //cell_1.SetBorder(iText.Layout.Borders.Border.NO_BORDER)
            cell_1.SetBackgroundColor(new DeviceRgb(0, 0, 0), 0f);
            cell_1.SetBorderBottom(Border.NO_BORDER);
            cell_1.SetBorderTop(Border.NO_BORDER);
            cell_1.SetBorderRight(Border.NO_BORDER);
            cell_1.SetBorderLeft(Border.NO_BORDER);
            cell_1.SetBorderRadius(new BorderRadius(0f * pxToPtFactor));
            
            if(true){cell_1.SetBorderLeft(kasaraporudokumform_1931465243leftBorder);}
            cell_1.SetPaddingBottom(0 * pxToPtFactor).SetPaddingLeft(0 * pxToPtFactor)
            .SetPaddingTop(0 * pxToPtFactor).SetPaddingRight(0 * pxToPtFactor).SetFontSize(14 * pxToPtFactor)
            .SetFont(fontDictionary["poppins_regular"]).SetFontColor(new DeviceRgb(155, 155, 155), 1f)
            .SetTextAlignment(iText.Layout.Properties.TextAlignment.LEFT);
            var headerParagraph_1 = new Paragraph((kasaraporudokumform_1931465243_ColumnTitles is { Count: >= (1 + 1) } ? kasaraporudokumform_1931465243_ColumnTitles[1] : kasaraporudokumform_1931465243_ColumnTitles.Any() ? "" : ("Kasa Adı".ConvertToType<String>())))
            
            .WithGlyphFallback(fontDictionary, "poppins_regular", () => cjkFallbackFont.Value);
            cell_1.Add(headerParagraph_1);
            
            cell_1.SetVisible(true);
            kasaraporudokumform_1931465243.AddHeaderCell(cell_1);


            Cell cell_2 = new Cell(1, 1);
            //cell_2.SetBorder(iText.Layout.Borders.Border.NO_BORDER)
            cell_2.SetBackgroundColor(new DeviceRgb(0, 0, 0), 0f);
            cell_2.SetBorderBottom(Border.NO_BORDER);
            cell_2.SetBorderTop(Border.NO_BORDER);
            cell_2.SetBorderRight(Border.NO_BORDER);
            cell_2.SetBorderLeft(Border.NO_BORDER);
            cell_2.SetBorderRadius(new BorderRadius(0f * pxToPtFactor));
            
            if(true){cell_2.SetBorderLeft(kasaraporudokumform_1931465243leftBorder);}
            cell_2.SetPaddingBottom(0 * pxToPtFactor).SetPaddingLeft(0 * pxToPtFactor)
            .SetPaddingTop(0 * pxToPtFactor).SetPaddingRight(0 * pxToPtFactor).SetFontSize(14 * pxToPtFactor)
            .SetFont(fontDictionary["poppins_regular"]).SetFontColor(new DeviceRgb(155, 155, 155), 1f)
            .SetTextAlignment(iText.Layout.Properties.TextAlignment.LEFT);
            var headerParagraph_2 = new Paragraph((kasaraporudokumform_1931465243_ColumnTitles is { Count: >= (2 + 1) } ? kasaraporudokumform_1931465243_ColumnTitles[2] : kasaraporudokumform_1931465243_ColumnTitles.Any() ? "" : ("Para Birimi".ConvertToType<String>())))
            
            .WithGlyphFallback(fontDictionary, "poppins_regular", () => cjkFallbackFont.Value);
            cell_2.Add(headerParagraph_2);
            
            cell_2.SetVisible(true);
            kasaraporudokumform_1931465243.AddHeaderCell(cell_2);


            Cell cell_3 = new Cell(1, 1);
            //cell_3.SetBorder(iText.Layout.Borders.Border.NO_BORDER)
            cell_3.SetBackgroundColor(new DeviceRgb(0, 0, 0), 0f);
            cell_3.SetBorderBottom(Border.NO_BORDER);
            cell_3.SetBorderTop(Border.NO_BORDER);
            cell_3.SetBorderRight(Border.NO_BORDER);
            cell_3.SetBorderLeft(Border.NO_BORDER);
            cell_3.SetBorderRadius(new BorderRadius(0f * pxToPtFactor));
            
            if(true){cell_3.SetBorderLeft(kasaraporudokumform_1931465243leftBorder);}
            cell_3.SetPaddingBottom(0 * pxToPtFactor).SetPaddingLeft(0 * pxToPtFactor)
            .SetPaddingTop(0 * pxToPtFactor).SetPaddingRight(0 * pxToPtFactor).SetFontSize(14 * pxToPtFactor)
            .SetFont(fontDictionary["poppins_regular"]).SetFontColor(new DeviceRgb(155, 155, 155), 1f)
            .SetTextAlignment(iText.Layout.Properties.TextAlignment.LEFT);
            var headerParagraph_3 = new Paragraph((kasaraporudokumform_1931465243_ColumnTitles is { Count: >= (3 + 1) } ? kasaraporudokumform_1931465243_ColumnTitles[3] : kasaraporudokumform_1931465243_ColumnTitles.Any() ? "" : ("Devir Bakiyesi".ConvertToType<String>())))
            
            .WithGlyphFallback(fontDictionary, "poppins_regular", () => cjkFallbackFont.Value);
            cell_3.Add(headerParagraph_3);
            
            cell_3.SetVisible(true);
            kasaraporudokumform_1931465243.AddHeaderCell(cell_3);


            Cell cell_4 = new Cell(1, 1);
            //cell_4.SetBorder(iText.Layout.Borders.Border.NO_BORDER)
            cell_4.SetBackgroundColor(new DeviceRgb(0, 0, 0), 0f);
            cell_4.SetBorderBottom(Border.NO_BORDER);
            cell_4.SetBorderTop(Border.NO_BORDER);
            cell_4.SetBorderRight(Border.NO_BORDER);
            cell_4.SetBorderLeft(Border.NO_BORDER);
            cell_4.SetBorderRadius(new BorderRadius(0f * pxToPtFactor));
            
            if(true){cell_4.SetBorderLeft(kasaraporudokumform_1931465243leftBorder);}
            cell_4.SetPaddingBottom(0 * pxToPtFactor).SetPaddingLeft(0 * pxToPtFactor)
            .SetPaddingTop(0 * pxToPtFactor).SetPaddingRight(0 * pxToPtFactor).SetFontSize(14 * pxToPtFactor)
            .SetFont(fontDictionary["poppins_regular"]).SetFontColor(new DeviceRgb(155, 155, 155), 1f)
            .SetTextAlignment(iText.Layout.Properties.TextAlignment.LEFT);
            var headerParagraph_4 = new Paragraph((kasaraporudokumform_1931465243_ColumnTitles is { Count: >= (4 + 1) } ? kasaraporudokumform_1931465243_ColumnTitles[4] : kasaraporudokumform_1931465243_ColumnTitles.Any() ? "" : ("Devir Bakiyesi TRY".ConvertToType<String>())))
            
            .WithGlyphFallback(fontDictionary, "poppins_regular", () => cjkFallbackFont.Value);
            cell_4.Add(headerParagraph_4);
            
            cell_4.SetVisible(true);
            kasaraporudokumform_1931465243.AddHeaderCell(cell_4);


            
            var rowBackgroundColor = new DeviceRgb(0, 0, 0);
            var rowOpacity = 0;
            var isStriped = false;
            Color stripedColor = new DeviceRgb(245, 247, 250);
            for(int i = 0; i < result.Kuika_KasaKalani10.Count; i++)
              {
                  var item = result.Kuika_KasaKalani10[i];
                  Color backgroundColor = new DeviceRgb(255, 255, 255);
                  float backgroundColorOpacity = 0f;

                  if (kasaraporudokumform_1931465243BackgroundColorOpacity == 1) {{
                        backgroundColor = kasaraporudokumform_1931465243BackgroundColor;
                        backgroundColorOpacity = 1f;
                  }}

                  if (rowOpacity == 1) {{
                        backgroundColor = rowBackgroundColor;
                        backgroundColorOpacity = 1f;
                  }}

                  if (isStriped && i % 2 != 0) {{
                        backgroundColor = stripedColor;
                        backgroundColorOpacity = 1f;
                  }}

                  
                
            var colData_0191572351 = new Paragraph(item.CurrAccCode.ToFormattedString("", "", "") ?? "")
            .SetMarginBottom(0 * pxToPtFactor).SetMarginLeft(0 * pxToPtFactor)
            .SetMarginTop(0 * pxToPtFactor).SetMarginRight(0 * pxToPtFactor)
            .SetFontColor(new DeviceRgb(68, 68, 68), 1f)
            .SetBackgroundColor(new DeviceRgb(0, 0, 0), 0f)
            .SetFontSize(12 * pxToPtFactor)
            .SetFont(fontDictionary["poppins_regular"])
            .WithGlyphFallback(fontDictionary, "poppins_regular", () => cjkFallbackFont.Value)
            
            .SetParagraphWidthAndExtendHeightIfNotFit(document, 31.57f * pxToPtFactor, 20f * pxToPtFactor, true)
            .SetVisible(true)
            .SetVerticalAlignment(VerticalAlignment.TOP)
            .SetHorizontalAlignment(HorizontalAlignment.LEFT)
            .SetTextAlignment(TextAlignment.LEFT)
            .SetMultipliedLeading(1f);
            
colData_0191572351.SetVisible(true);

                Cell cell_191572351 = new Cell(1, 1);
                var cell_191572351BackgroundColor = new DeviceRgb(0, 0, 0);
                var cell_191572351BackgroundColorOpacity = 0;
                
                cell_191572351.SetMinHeight(40 * pxToPtFactor);
                //cell_191572351.SetBorder(iText.Layout.Borders.Border.NO_BORDER);
                cell_191572351.SetBorderBottom(Border.NO_BORDER);
                cell_191572351.SetBorderTop(Border.NO_BORDER);
                cell_191572351.SetBorderRight(Border.NO_BORDER);
                cell_191572351.SetBorderLeft(Border.NO_BORDER);
                cell_191572351.SetBorderRadius(new BorderRadius(0f * pxToPtFactor));
                //cell_191572351.Add(colData_191572351);
                if (cell_191572351BackgroundColorOpacity == 1)
                    cell_191572351.SetBackgroundColor(cell_191572351BackgroundColor);
                else if (backgroundColorOpacity == 1)
                    cell_191572351.SetBackgroundColor(backgroundColor);
                cell_191572351.SetVerticalAlignment(iText.Layout.Properties.VerticalAlignment.TOP);
                cell_191572351.SetTextAlignment(iText.Layout.Properties.TextAlignment.LEFT);
                cell_191572351.SetPaddingBottom(0 * pxToPtFactor).SetPaddingLeft(0 * pxToPtFactor)
                .SetPaddingTop(0 * pxToPtFactor).SetPaddingRight(0 * pxToPtFactor);
                
                kasaraporudokumform_1931465243.AddCell(cell_191572351);

cell_191572351.Add(colData_0191572351);

                
            var colData_0171232099 = new Paragraph(item.CurrAccDescription.ToFormattedString("", "", "") ?? "")
            .SetMarginBottom(0 * pxToPtFactor).SetMarginLeft(0 * pxToPtFactor)
            .SetMarginTop(0 * pxToPtFactor).SetMarginRight(0 * pxToPtFactor)
            .SetFontColor(new DeviceRgb(68, 68, 68), 1f)
            .SetBackgroundColor(new DeviceRgb(0, 0, 0), 0f)
            .SetFontSize(12 * pxToPtFactor)
            .SetFont(fontDictionary["poppins_regular"])
            .WithGlyphFallback(fontDictionary, "poppins_regular", () => cjkFallbackFont.Value)
            
            .SetParagraphWidthAndExtendHeightIfNotFit(document, 28.34f * pxToPtFactor, 20f * pxToPtFactor, true)
            .SetVisible(true)
            .SetVerticalAlignment(VerticalAlignment.TOP)
            .SetHorizontalAlignment(HorizontalAlignment.LEFT)
            .SetTextAlignment(TextAlignment.LEFT)
            .SetMultipliedLeading(1f);
            
colData_0171232099.SetVisible(true);

                Cell cell_171232099 = new Cell(1, 1);
                var cell_171232099BackgroundColor = new DeviceRgb(0, 0, 0);
                var cell_171232099BackgroundColorOpacity = 0;
                
                cell_171232099.SetMinHeight(40 * pxToPtFactor);
                //cell_171232099.SetBorder(iText.Layout.Borders.Border.NO_BORDER);
                cell_171232099.SetBorderBottom(Border.NO_BORDER);
                cell_171232099.SetBorderTop(Border.NO_BORDER);
                cell_171232099.SetBorderRight(Border.NO_BORDER);
                cell_171232099.SetBorderLeft(Border.NO_BORDER);
                cell_171232099.SetBorderRadius(new BorderRadius(0f * pxToPtFactor));
                //cell_171232099.Add(colData_171232099);
                if (cell_171232099BackgroundColorOpacity == 1)
                    cell_171232099.SetBackgroundColor(cell_171232099BackgroundColor);
                else if (backgroundColorOpacity == 1)
                    cell_171232099.SetBackgroundColor(backgroundColor);
                cell_171232099.SetVerticalAlignment(iText.Layout.Properties.VerticalAlignment.TOP);
                cell_171232099.SetTextAlignment(iText.Layout.Properties.TextAlignment.LEFT);
                cell_171232099.SetPaddingBottom(0 * pxToPtFactor).SetPaddingLeft(0 * pxToPtFactor)
                .SetPaddingTop(0 * pxToPtFactor).SetPaddingRight(0 * pxToPtFactor);
                
                kasaraporudokumform_1931465243.AddCell(cell_171232099);

cell_171232099.Add(colData_0171232099);

                
            var colData_01688905510 = new Paragraph(item.CurrencyCode.ToFormattedString("", "", "") ?? "")
            .SetMarginBottom(0 * pxToPtFactor).SetMarginLeft(0 * pxToPtFactor)
            .SetMarginTop(0 * pxToPtFactor).SetMarginRight(0 * pxToPtFactor)
            .SetFontColor(new DeviceRgb(68, 68, 68), 1f)
            .SetBackgroundColor(new DeviceRgb(0, 0, 0), 0f)
            .SetFontSize(12 * pxToPtFactor)
            .SetFont(fontDictionary["poppins_regular"])
            .WithGlyphFallback(fontDictionary, "poppins_regular", () => cjkFallbackFont.Value)
            
            .SetParagraphWidthAndExtendHeightIfNotFit(document, 31.57f * pxToPtFactor, 20f * pxToPtFactor, true)
            .SetVisible(true)
            .SetVerticalAlignment(VerticalAlignment.TOP)
            .SetHorizontalAlignment(HorizontalAlignment.LEFT)
            .SetTextAlignment(TextAlignment.LEFT)
            .SetMultipliedLeading(1f);
            
colData_01688905510.SetVisible(true);

                Cell cell_1688905510 = new Cell(1, 1);
                var cell_1688905510BackgroundColor = new DeviceRgb(0, 0, 0);
                var cell_1688905510BackgroundColorOpacity = 0;
                
                cell_1688905510.SetMinHeight(40 * pxToPtFactor);
                //cell_1688905510.SetBorder(iText.Layout.Borders.Border.NO_BORDER);
                cell_1688905510.SetBorderBottom(Border.NO_BORDER);
                cell_1688905510.SetBorderTop(Border.NO_BORDER);
                cell_1688905510.SetBorderRight(Border.NO_BORDER);
                cell_1688905510.SetBorderLeft(Border.NO_BORDER);
                cell_1688905510.SetBorderRadius(new BorderRadius(0f * pxToPtFactor));
                //cell_1688905510.Add(colData_1688905510);
                if (cell_1688905510BackgroundColorOpacity == 1)
                    cell_1688905510.SetBackgroundColor(cell_1688905510BackgroundColor);
                else if (backgroundColorOpacity == 1)
                    cell_1688905510.SetBackgroundColor(backgroundColor);
                cell_1688905510.SetVerticalAlignment(iText.Layout.Properties.VerticalAlignment.TOP);
                cell_1688905510.SetTextAlignment(iText.Layout.Properties.TextAlignment.LEFT);
                cell_1688905510.SetPaddingBottom(0 * pxToPtFactor).SetPaddingLeft(0 * pxToPtFactor)
                .SetPaddingTop(0 * pxToPtFactor).SetPaddingRight(0 * pxToPtFactor);
                
                kasaraporudokumform_1931465243.AddCell(cell_1688905510);

cell_1688905510.Add(colData_01688905510);

                
            var colData_01098003979 = new Paragraph(item.Balance.ToFormattedString("", "", "") ?? "")
            .SetMarginBottom(0 * pxToPtFactor).SetMarginLeft(0 * pxToPtFactor)
            .SetMarginTop(0 * pxToPtFactor).SetMarginRight(0 * pxToPtFactor)
            .SetFontColor(new DeviceRgb(68, 68, 68), 1f)
            .SetBackgroundColor(new DeviceRgb(0, 0, 0), 0f)
            .SetFontSize(12 * pxToPtFactor)
            .SetFont(fontDictionary["poppins_regular"])
            .WithGlyphFallback(fontDictionary, "poppins_regular", () => cjkFallbackFont.Value)
            
            .SetParagraphWidthAndExtendHeightIfNotFit(document, 31.57f * pxToPtFactor, 20f * pxToPtFactor, true)
            .SetVisible(true)
            .SetVerticalAlignment(VerticalAlignment.TOP)
            .SetHorizontalAlignment(HorizontalAlignment.LEFT)
            .SetTextAlignment(TextAlignment.LEFT)
            .SetMultipliedLeading(1f);
            
colData_01098003979.SetVisible(true);

                Cell cell_1098003979 = new Cell(1, 1);
                var cell_1098003979BackgroundColor = new DeviceRgb(0, 0, 0);
                var cell_1098003979BackgroundColorOpacity = 0;
                
                cell_1098003979.SetMinHeight(40 * pxToPtFactor);
                //cell_1098003979.SetBorder(iText.Layout.Borders.Border.NO_BORDER);
                cell_1098003979.SetBorderBottom(Border.NO_BORDER);
                cell_1098003979.SetBorderTop(Border.NO_BORDER);
                cell_1098003979.SetBorderRight(Border.NO_BORDER);
                cell_1098003979.SetBorderLeft(Border.NO_BORDER);
                cell_1098003979.SetBorderRadius(new BorderRadius(0f * pxToPtFactor));
                //cell_1098003979.Add(colData_1098003979);
                if (cell_1098003979BackgroundColorOpacity == 1)
                    cell_1098003979.SetBackgroundColor(cell_1098003979BackgroundColor);
                else if (backgroundColorOpacity == 1)
                    cell_1098003979.SetBackgroundColor(backgroundColor);
                cell_1098003979.SetVerticalAlignment(iText.Layout.Properties.VerticalAlignment.TOP);
                cell_1098003979.SetTextAlignment(iText.Layout.Properties.TextAlignment.LEFT);
                cell_1098003979.SetPaddingBottom(0 * pxToPtFactor).SetPaddingLeft(0 * pxToPtFactor)
                .SetPaddingTop(0 * pxToPtFactor).SetPaddingRight(0 * pxToPtFactor);
                
                kasaraporudokumform_1931465243.AddCell(cell_1098003979);

cell_1098003979.Add(colData_01098003979);

                
            var colData_0297289034 = new Paragraph(item.Balance1.ToFormattedString("", "", "") ?? "")
            .SetMarginBottom(0 * pxToPtFactor).SetMarginLeft(0 * pxToPtFactor)
            .SetMarginTop(0 * pxToPtFactor).SetMarginRight(0 * pxToPtFactor)
            .SetFontColor(new DeviceRgb(68, 68, 68), 1f)
            .SetBackgroundColor(new DeviceRgb(0, 0, 0), 0f)
            .SetFontSize(12 * pxToPtFactor)
            .SetFont(fontDictionary["poppins_regular"])
            .WithGlyphFallback(fontDictionary, "poppins_regular", () => cjkFallbackFont.Value)
            
            .SetParagraphWidthAndExtendHeightIfNotFit(document, 31.57f * pxToPtFactor, 20f * pxToPtFactor, true)
            .SetVisible(true)
            .SetVerticalAlignment(VerticalAlignment.TOP)
            .SetHorizontalAlignment(HorizontalAlignment.LEFT)
            .SetTextAlignment(TextAlignment.LEFT)
            .SetMultipliedLeading(1f);
            
colData_0297289034.SetVisible(true);

                Cell cell_297289034 = new Cell(1, 1);
                var cell_297289034BackgroundColor = new DeviceRgb(0, 0, 0);
                var cell_297289034BackgroundColorOpacity = 0;
                
                cell_297289034.SetMinHeight(40 * pxToPtFactor);
                //cell_297289034.SetBorder(iText.Layout.Borders.Border.NO_BORDER);
                cell_297289034.SetBorderBottom(Border.NO_BORDER);
                cell_297289034.SetBorderTop(Border.NO_BORDER);
                cell_297289034.SetBorderRight(Border.NO_BORDER);
                cell_297289034.SetBorderLeft(Border.NO_BORDER);
                cell_297289034.SetBorderRadius(new BorderRadius(0f * pxToPtFactor));
                //cell_297289034.Add(colData_297289034);
                if (cell_297289034BackgroundColorOpacity == 1)
                    cell_297289034.SetBackgroundColor(cell_297289034BackgroundColor);
                else if (backgroundColorOpacity == 1)
                    cell_297289034.SetBackgroundColor(backgroundColor);
                cell_297289034.SetVerticalAlignment(iText.Layout.Properties.VerticalAlignment.TOP);
                cell_297289034.SetTextAlignment(iText.Layout.Properties.TextAlignment.LEFT);
                cell_297289034.SetPaddingBottom(0 * pxToPtFactor).SetPaddingLeft(0 * pxToPtFactor)
                .SetPaddingTop(0 * pxToPtFactor).SetPaddingRight(0 * pxToPtFactor);
                
                kasaraporudokumform_1931465243.AddCell(cell_297289034);

cell_297289034.Add(colData_0297289034);

              }



            kasaraporudokumform_1931465243.SetMarginLeft(10f * pxToPtFactor + 0f * pxToPtFactor);
            if (Math.Abs(1623.5f * pxToPtFactor) > 0) {{
               kasaraporudokumform_1931465243.SetMarginTop(Math.Abs(1623.5f * pxToPtFactor) + 0f * pxToPtFactor);
            }}
            kasaraporudokumform_2024004537_cell.Add(kasaraporudokumform_1931465243);
        }

   
            kasaraporudokumform_2024004537_cell.SetVisible(box_kasaraporudokumform_2024004537.IsVisible());
            box_kasaraporudokumform_2024004537.AddCell(kasaraporudokumform_2024004537_cell);
            
            // Draw rounded rectangle with PdfCanvas for border-radius support
            {
                var boxX = 5f * pxToPtFactor;
                var boxAbsY = Math.Abs(1583.5f * pxToPtFactor);
                var boxPageRelY = boxAbsY - pageStartY;
                var boxY = ((currentPageHeight > 0 ? currentPageHeight : canvasHeight.Value) - (boxPageRelY + Math.Abs(218f * pxToPtFactor)));
                var boxW = 780f * pxToPtFactor;
                var boxH = 218f * pxToPtFactor;
                var boxRadiusTL = 6f * pxToPtFactor;
                var boxRadiusTR = 6f * pxToPtFactor;
                var boxRadiusBR = 6f * pxToPtFactor;
                var boxRadiusBL = 6f * pxToPtFactor;
                float kappaTL = boxRadiusTL * 0.5522848f;
                float kappaTR = boxRadiusTR * 0.5522848f;
                float kappaBR = boxRadiusBR * 0.5522848f;
                float kappaBL = boxRadiusBL * 0.5522848f;
                var currentPage = pdf.GetPage(pdf.GetNumberOfPages());
                var pdfCanvas = new PdfCanvas(currentPage);

                // Draw rounded background with alpha support
                pdfCanvas.SaveState();
                pdfCanvas.SetExtGState(new PdfExtGState().SetFillOpacity(1f));
                pdfCanvas.SetFillColor(new DeviceRgb(255, 255, 255));
                pdfCanvas.MoveTo(boxX + boxRadiusBL, boxY);
                pdfCanvas.LineTo(boxX + boxW - boxRadiusBR, boxY);
                if (boxRadiusBR > 0) pdfCanvas.CurveTo(boxX + boxW - boxRadiusBR + kappaBR, boxY, boxX + boxW, boxY + boxRadiusBR - kappaBR, boxX + boxW, boxY + boxRadiusBR);
                pdfCanvas.LineTo(boxX + boxW, boxY + boxH - boxRadiusTR);
                if (boxRadiusTR > 0) pdfCanvas.CurveTo(boxX + boxW, boxY + boxH - boxRadiusTR + kappaTR, boxX + boxW - boxRadiusTR + kappaTR, boxY + boxH, boxX + boxW - boxRadiusTR, boxY + boxH);
                pdfCanvas.LineTo(boxX + boxRadiusTL, boxY + boxH);
                if (boxRadiusTL > 0) pdfCanvas.CurveTo(boxX + boxRadiusTL - kappaTL, boxY + boxH, boxX, boxY + boxH - boxRadiusTL + kappaTL, boxX, boxY + boxH - boxRadiusTL);
                pdfCanvas.LineTo(boxX, boxY + boxRadiusBL);
                if (boxRadiusBL > 0) pdfCanvas.CurveTo(boxX, boxY + boxRadiusBL - kappaBL, boxX + boxRadiusBL - kappaBL, boxY, boxX + boxRadiusBL, boxY);
                pdfCanvas.ClosePath();
                pdfCanvas.Fill();
                pdfCanvas.RestoreState();

                // Draw individual border edges with per-side widths
                var rrBorderColor = new DeviceRgb(238, 242, 246);
                float rrBorderTop = 1f * pxToPtFactor;
                float rrBorderRight = 1f * pxToPtFactor;
                float rrBorderBottom = 1f * pxToPtFactor;
                float rrBorderLeft = 1f * pxToPtFactor;

                // Top border (uses TL and TR corners)
                if (rrBorderTop > 0)
                {
                    pdfCanvas.SaveState();
                    pdfCanvas.SetExtGState(new PdfExtGState().SetStrokeOpacity(1f));
                    pdfCanvas.SetStrokeColor(rrBorderColor);
                    pdfCanvas.SetLineWidth(rrBorderTop);
                    pdfCanvas.MoveTo(boxX + boxRadiusTL, boxY + boxH);
                    pdfCanvas.LineTo(boxX + boxW - boxRadiusTR, boxY + boxH);
                    if (boxRadiusTR > 0) pdfCanvas.CurveTo(boxX + boxW - boxRadiusTR + kappaTR, boxY + boxH, boxX + boxW, boxY + boxH - boxRadiusTR + kappaTR, boxX + boxW, boxY + boxH - boxRadiusTR);
                    pdfCanvas.Stroke();
                    pdfCanvas.RestoreState();
                }

                // Right border (uses TR and BR corners)
                if (rrBorderRight > 0)
                {
                    pdfCanvas.SaveState();
                    pdfCanvas.SetExtGState(new PdfExtGState().SetStrokeOpacity(1f));
                    pdfCanvas.SetStrokeColor(rrBorderColor);
                    pdfCanvas.SetLineWidth(rrBorderRight);
                    pdfCanvas.MoveTo(boxX + boxW, boxY + boxH - boxRadiusTR);
                    pdfCanvas.LineTo(boxX + boxW, boxY + boxRadiusBR);
                    if (boxRadiusBR > 0) pdfCanvas.CurveTo(boxX + boxW, boxY + boxRadiusBR - kappaBR, boxX + boxW - boxRadiusBR + kappaBR, boxY, boxX + boxW - boxRadiusBR, boxY);
                    pdfCanvas.Stroke();
                    pdfCanvas.RestoreState();
                }

                // Bottom border (uses BR and BL corners)
                if (rrBorderBottom > 0)
                {
                    pdfCanvas.SaveState();
                    pdfCanvas.SetExtGState(new PdfExtGState().SetStrokeOpacity(1f));
                    pdfCanvas.SetStrokeColor(rrBorderColor);
                    pdfCanvas.SetLineWidth(rrBorderBottom);
                    pdfCanvas.MoveTo(boxX + boxW - boxRadiusBR, boxY);
                    pdfCanvas.LineTo(boxX + boxRadiusBL, boxY);
                    if (boxRadiusBL > 0) pdfCanvas.CurveTo(boxX + boxRadiusBL - kappaBL, boxY, boxX, boxY + boxRadiusBL - kappaBL, boxX, boxY + boxRadiusBL);
                    pdfCanvas.Stroke();
                    pdfCanvas.RestoreState();
                }

                // Left border (uses BL and TL corners)
                if (rrBorderLeft > 0)
                {
                    pdfCanvas.SaveState();
                    pdfCanvas.SetExtGState(new PdfExtGState().SetStrokeOpacity(1f));
                    pdfCanvas.SetStrokeColor(rrBorderColor);
                    pdfCanvas.SetLineWidth(rrBorderLeft);
                    pdfCanvas.MoveTo(boxX, boxY + boxRadiusBL);
                    pdfCanvas.LineTo(boxX, boxY + boxH - boxRadiusTL);
                    if (boxRadiusTL > 0) pdfCanvas.CurveTo(boxX, boxY + boxH - boxRadiusTL + kappaTL, boxX + boxRadiusTL - kappaTL, boxY + boxH, boxX + boxRadiusTL, boxY + boxH);
                    pdfCanvas.Stroke();
                    pdfCanvas.RestoreState();
                }
            }
            document.Add(box_kasaraporudokumform_2024004537);
            foreach (var deferredElem in box_kasaraporudokumform_2024004537_deferredAdds) document.Add(deferredElem);
            }}


            //Box14
            Table box_kasaraporudokumform_1132402720 = new Table(1).SetWidth(780f * pxToPtFactor).SetHeight(218f * pxToPtFactor)
            .SetFontColor(new DeviceRgb(0, 0, 0), 1f)
            .SetFontSize(20 * pxToPtFactor)
            .SetVisible(true);
            if (box_kasaraporudokumform_1132402720.IsVisible()) {{
            var box_kasaraporudokumform_1132402720_pageLeftX = (double)(5f * pxToPtFactor) ;
            var box_kasaraporudokumform_1132402720_pageTopY = 0d;
            var box_kasaraporudokumform_1132402720_deferredAdds = new List<IBlockElement>();
            if (!false) {
            // Calculate page-relative Y position
            var box_kasaraporudokumform_1132402720_absoluteY = Math.Abs(1847f * pxToPtFactor);
            var box_kasaraporudokumform_1132402720_pageRelativeY = box_kasaraporudokumform_1132402720_absoluteY - pageStartY;
            int box_kasaraporudokumform_1132402720_targetPage = pdf.GetNumberOfPages();
            
            box_kasaraporudokumform_1132402720.SetFixedPosition(box_kasaraporudokumform_1132402720_targetPage, 5f * pxToPtFactor , ((currentPageHeight > 0 ? currentPageHeight : canvasHeight.Value) - (box_kasaraporudokumform_1132402720_pageRelativeY + Math.Abs(218f * pxToPtFactor))) , 780f * pxToPtFactor);
            box_kasaraporudokumform_1132402720_pageTopY = ((double)(currentPageHeight > 0 ? currentPageHeight : canvasHeight.Value) - box_kasaraporudokumform_1132402720_pageRelativeY) ;
            } else {
            box_kasaraporudokumform_1132402720.SetFixedPosition(5f * pxToPtFactor , ((currentPageHeight > 0 ? currentPageHeight : canvasHeight.Value) - (totalHeight + Math.Abs(1847f * pxToPtFactor) + Math.Abs(218f * pxToPtFactor))) , 780f * pxToPtFactor);
            box_kasaraporudokumform_1132402720_pageTopY = ((double)(currentPageHeight > 0 ? currentPageHeight : canvasHeight.Value) - (totalHeight + Math.Abs(1847f * pxToPtFactor))) ;
            }
            box_kasaraporudokumform_1132402720.SetBorder(Border.NO_BORDER);
            box_kasaraporudokumform_1132402720.SetBorderBottom(Border.NO_BORDER);
            box_kasaraporudokumform_1132402720.SetBorderTop(Border.NO_BORDER);
            box_kasaraporudokumform_1132402720.SetBorderRight(Border.NO_BORDER);
            box_kasaraporudokumform_1132402720.SetBorderLeft(Border.NO_BORDER);
            box_kasaraporudokumform_1132402720.SetBorderRadius(new BorderRadius(6f * pxToPtFactor));
            var heightOf_box_kasaraporudokumform_1132402720 = box_kasaraporudokumform_1132402720.GetHeight();
            Cell kasaraporudokumform_1132402720_cell = new Cell();
            kasaraporudokumform_1132402720_cell.SetBackgroundColor(new DeviceRgb(255, 255, 255), 0f);
            kasaraporudokumform_1132402720_cell.SetBorder(Border.NO_BORDER);
            
            // NOTE: Box always uses SetFixedPosition above (both branches), so it does not
            // contribute to flow. The legacy "totalHeight + height > canvasHeight" areaBreak
            // that lived here was reading totalHeight produced by previous flow elements
            // (e.g. multi-page ReportTables) and spuriously creating a new page + bumping
            // pageStartY, which broke pageRelativeY for every subsequent element. Removed.

            // No page breaks - using default canvas height behavior


            //Box15
            Table box_kasaraporudokumform_631743576 = new Table(1).SetWidth(790f * pxToPtFactor).SetHeight(30f * pxToPtFactor)
            .SetFontColor(new DeviceRgb(0, 0, 0), 1f)
            .SetFontSize(20 * pxToPtFactor)
            .SetVisible(true);
            if (box_kasaraporudokumform_631743576.IsVisible()) {{
            var box_kasaraporudokumform_631743576_pageLeftX = (double)(5f * pxToPtFactor) ;
            var box_kasaraporudokumform_631743576_pageTopY = 0d;
            var box_kasaraporudokumform_631743576_deferredAdds = new List<IBlockElement>();
            if (!false) {
            // Calculate page-relative Y position
            var box_kasaraporudokumform_631743576_absoluteY = Math.Abs(1847f * pxToPtFactor);
            var box_kasaraporudokumform_631743576_pageRelativeY = box_kasaraporudokumform_631743576_absoluteY - pageStartY;
            int box_kasaraporudokumform_631743576_targetPage = pdf.GetNumberOfPages();
            
            box_kasaraporudokumform_631743576.SetFixedPosition(box_kasaraporudokumform_631743576_targetPage, 5f * pxToPtFactor , ((currentPageHeight > 0 ? currentPageHeight : canvasHeight.Value) - (box_kasaraporudokumform_631743576_pageRelativeY + Math.Abs(30f * pxToPtFactor))) , 790f * pxToPtFactor);
            box_kasaraporudokumform_631743576_pageTopY = ((double)(currentPageHeight > 0 ? currentPageHeight : canvasHeight.Value) - box_kasaraporudokumform_631743576_pageRelativeY) ;
            } else {
            box_kasaraporudokumform_631743576.SetFixedPosition(5f * pxToPtFactor , ((currentPageHeight > 0 ? currentPageHeight : canvasHeight.Value) - (totalHeight + Math.Abs(1847f * pxToPtFactor) + Math.Abs(30f * pxToPtFactor))) , 790f * pxToPtFactor);
            box_kasaraporudokumform_631743576_pageTopY = ((double)(currentPageHeight > 0 ? currentPageHeight : canvasHeight.Value) - (totalHeight + Math.Abs(1847f * pxToPtFactor))) ;
            }
            box_kasaraporudokumform_631743576.SetBorder(Border.NO_BORDER);
            box_kasaraporudokumform_631743576.SetBorderBottom(Border.NO_BORDER);
            box_kasaraporudokumform_631743576.SetBorderTop(Border.NO_BORDER);
            box_kasaraporudokumform_631743576.SetBorderRight(Border.NO_BORDER);
            box_kasaraporudokumform_631743576.SetBorderLeft(Border.NO_BORDER);
            box_kasaraporudokumform_631743576.SetBorderRadius(new BorderRadius(6f * pxToPtFactor));
            var heightOf_box_kasaraporudokumform_631743576 = box_kasaraporudokumform_631743576.GetHeight();
            Cell kasaraporudokumform_631743576_cell = new Cell();
            kasaraporudokumform_631743576_cell.SetBackgroundColor(new DeviceRgb(114, 194, 64), 0f);
            kasaraporudokumform_631743576_cell.SetBorder(Border.NO_BORDER);
            
            // NOTE: Box always uses SetFixedPosition above (both branches), so it does not
            // contribute to flow. The legacy "totalHeight + height > canvasHeight" areaBreak
            // that lived here was reading totalHeight produced by previous flow elements
            // (e.g. multi-page ReportTables) and spuriously creating a new page + bumping
            // pageStartY, which broke pageRelativeY for every subsequent element. Removed.

            // No page breaks - using default canvas height behavior


            //Label15
            var label_kasaraporudokumform_593235873_effectiveWidth = 780f * pxToPtFactor > 0 ? 780f * pxToPtFactor : (canvasWidth.Value - (5f * pxToPtFactor));
            Paragraph label_kasaraporudokumform_593235873 = new Paragraph(@"Kredi Kartı Tahsilatları ")
            .SetFontSize(15 * pxToPtFactor)
            .SetFont(fontDictionary["poppins_bold"])
            .WithGlyphFallback(fontDictionary, "poppins_bold", () => cjkFallbackFont.Value)
            .SetTextAlignment(TextAlignment.CENTER)
            
            .SetParagraphWidthAndExtendHeightIfNotFit(document, label_kasaraporudokumform_593235873_effectiveWidth, 20f * pxToPtFactor, false, false || false)
            .SetMultipliedLeading(0.875f);
            

            if (20f * pxToPtFactor == 0f)
            {
                label_kasaraporudokumform_593235873.SetMaxHeight((30f * pxToPtFactor) - Math.Abs(1847f * pxToPtFactor));
            }

            label_kasaraporudokumform_593235873.SetMarginBottom(0 * pxToPtFactor).SetMarginTop(0f);
            var label_kasaraporudokumform_593235873_paragraphHeight = label_kasaraporudokumform_593235873.GetHeightOfParagraph(document);
            var label_kasaraporudokumform_593235873_vAlignOffset = 0f;
            label_kasaraporudokumform_593235873_vAlignOffset = Math.Max(0f, (20f * pxToPtFactor - label_kasaraporudokumform_593235873_paragraphHeight) / 2f);
            label_kasaraporudokumform_593235873.SetMarginLeft(0 * pxToPtFactor)
            .SetMarginTop((0 * pxToPtFactor) + label_kasaraporudokumform_593235873_vAlignOffset).SetMarginRight(0 * pxToPtFactor)
            .SetFontColor(new DeviceRgb(255, 255, 255), 1f)
            .SetVisible(true);
            
            if (false)
			{
				Paragraph label_kasaraporudokumform_593235873_inside = new Paragraph(@"Kredi Kartı Tahsilatları ")
			   .SetFontSize(15 * pxToPtFactor)
               .SetFont(fontDictionary["poppins_bold"])
			   .WithGlyphFallback(fontDictionary, "poppins_bold", () => cjkFallbackFont.Value)
			   .SetFontColor(new DeviceRgb(255, 255, 255), 1f)
			   
			   .SetRotationAngle(0);
				label_kasaraporudokumform_593235873.Add(label_kasaraporudokumform_593235873_inside);
			}
            var label_kasaraporudokumform_593235873_renderHeight = 20f * pxToPtFactor > 0 ? 20f * pxToPtFactor : label_kasaraporudokumform_593235873_paragraphHeight;
            // Actual div height accounts for paragraph margins that may expand the Div beyond MinHeight
            // paragraphHeight was measured with MarginTop=0, but actual MarginTop = paddingTop + vAlignOffset
            var label_kasaraporudokumform_593235873_divHeight = Math.Max(label_kasaraporudokumform_593235873_renderHeight, label_kasaraporudokumform_593235873_paragraphHeight + (0 * pxToPtFactor) + label_kasaraporudokumform_593235873_vAlignOffset);
            var div_label_kasaraporudokumform_593235873 = new Div();
            div_label_kasaraporudokumform_593235873.SetMinHeight(label_kasaraporudokumform_593235873_renderHeight);
            div_label_kasaraporudokumform_593235873.SetBackgroundColor(new DeviceRgb(0, 0, 0), 0f);
            div_label_kasaraporudokumform_593235873.SetBorderBottom(Border.NO_BORDER);
            div_label_kasaraporudokumform_593235873.SetBorderTop(Border.NO_BORDER);
            div_label_kasaraporudokumform_593235873.SetBorderRight(Border.NO_BORDER);
            div_label_kasaraporudokumform_593235873.SetBorderLeft(Border.NO_BORDER);
            div_label_kasaraporudokumform_593235873.SetBorderRadius(new BorderRadius(0f * pxToPtFactor));
            div_label_kasaraporudokumform_593235873.Add(label_kasaraporudokumform_593235873);
            
            // Label/Icon inside Box: use box page coordinates for absolute positioning
            var label_kasaraporudokumform_593235873_yPos = box_kasaraporudokumform_631743576_pageTopY - (0f * pxToPtFactor) - label_kasaraporudokumform_593235873_divHeight;
            div_label_kasaraporudokumform_593235873.SetFixedPosition((float)(box_kasaraporudokumform_631743576_pageLeftX + (0f * pxToPtFactor)), (float)label_kasaraporudokumform_593235873_yPos, label_kasaraporudokumform_593235873_effectiveWidth);
            div_label_kasaraporudokumform_593235873.SetVisible(true);
            box_kasaraporudokumform_631743576_deferredAdds.Add(div_label_kasaraporudokumform_593235873);

            kasaraporudokumform_631743576_cell.SetVisible(box_kasaraporudokumform_631743576.IsVisible());
            box_kasaraporudokumform_631743576.AddCell(kasaraporudokumform_631743576_cell);
            
            // Draw rounded rectangle with PdfCanvas for border-radius support
            {
                var boxX = 5f * pxToPtFactor;
                var boxAbsY = Math.Abs(1847f * pxToPtFactor);
                var boxPageRelY = boxAbsY - pageStartY;
                var boxY = ((currentPageHeight > 0 ? currentPageHeight : canvasHeight.Value) - (boxPageRelY + Math.Abs(30f * pxToPtFactor)));
                var boxW = 790f * pxToPtFactor;
                var boxH = 30f * pxToPtFactor;
                var boxRadiusTL = 6f * pxToPtFactor;
                var boxRadiusTR = 6f * pxToPtFactor;
                var boxRadiusBR = 6f * pxToPtFactor;
                var boxRadiusBL = 6f * pxToPtFactor;
                float kappaTL = boxRadiusTL * 0.5522848f;
                float kappaTR = boxRadiusTR * 0.5522848f;
                float kappaBR = boxRadiusBR * 0.5522848f;
                float kappaBL = boxRadiusBL * 0.5522848f;
                var currentPage = pdf.GetPage(pdf.GetNumberOfPages());
                var pdfCanvas = new PdfCanvas(currentPage);

                // Draw rounded background with alpha support
                pdfCanvas.SaveState();
                pdfCanvas.SetExtGState(new PdfExtGState().SetFillOpacity(1f));
                pdfCanvas.SetFillColor(new DeviceRgb(114, 194, 64));
                pdfCanvas.MoveTo(boxX + boxRadiusBL, boxY);
                pdfCanvas.LineTo(boxX + boxW - boxRadiusBR, boxY);
                if (boxRadiusBR > 0) pdfCanvas.CurveTo(boxX + boxW - boxRadiusBR + kappaBR, boxY, boxX + boxW, boxY + boxRadiusBR - kappaBR, boxX + boxW, boxY + boxRadiusBR);
                pdfCanvas.LineTo(boxX + boxW, boxY + boxH - boxRadiusTR);
                if (boxRadiusTR > 0) pdfCanvas.CurveTo(boxX + boxW, boxY + boxH - boxRadiusTR + kappaTR, boxX + boxW - boxRadiusTR + kappaTR, boxY + boxH, boxX + boxW - boxRadiusTR, boxY + boxH);
                pdfCanvas.LineTo(boxX + boxRadiusTL, boxY + boxH);
                if (boxRadiusTL > 0) pdfCanvas.CurveTo(boxX + boxRadiusTL - kappaTL, boxY + boxH, boxX, boxY + boxH - boxRadiusTL + kappaTL, boxX, boxY + boxH - boxRadiusTL);
                pdfCanvas.LineTo(boxX, boxY + boxRadiusBL);
                if (boxRadiusBL > 0) pdfCanvas.CurveTo(boxX, boxY + boxRadiusBL - kappaBL, boxX + boxRadiusBL - kappaBL, boxY, boxX + boxRadiusBL, boxY);
                pdfCanvas.ClosePath();
                pdfCanvas.Fill();
                pdfCanvas.RestoreState();

                // Draw individual border edges with per-side widths
                var rrBorderColor = new DeviceRgb(114, 194, 64);
                float rrBorderTop = 1f * pxToPtFactor;
                float rrBorderRight = 1f * pxToPtFactor;
                float rrBorderBottom = 1f * pxToPtFactor;
                float rrBorderLeft = 1f * pxToPtFactor;

                // Top border (uses TL and TR corners)
                if (rrBorderTop > 0)
                {
                    pdfCanvas.SaveState();
                    pdfCanvas.SetExtGState(new PdfExtGState().SetStrokeOpacity(1f));
                    pdfCanvas.SetStrokeColor(rrBorderColor);
                    pdfCanvas.SetLineWidth(rrBorderTop);
                    pdfCanvas.MoveTo(boxX + boxRadiusTL, boxY + boxH);
                    pdfCanvas.LineTo(boxX + boxW - boxRadiusTR, boxY + boxH);
                    if (boxRadiusTR > 0) pdfCanvas.CurveTo(boxX + boxW - boxRadiusTR + kappaTR, boxY + boxH, boxX + boxW, boxY + boxH - boxRadiusTR + kappaTR, boxX + boxW, boxY + boxH - boxRadiusTR);
                    pdfCanvas.Stroke();
                    pdfCanvas.RestoreState();
                }

                // Right border (uses TR and BR corners)
                if (rrBorderRight > 0)
                {
                    pdfCanvas.SaveState();
                    pdfCanvas.SetExtGState(new PdfExtGState().SetStrokeOpacity(1f));
                    pdfCanvas.SetStrokeColor(rrBorderColor);
                    pdfCanvas.SetLineWidth(rrBorderRight);
                    pdfCanvas.MoveTo(boxX + boxW, boxY + boxH - boxRadiusTR);
                    pdfCanvas.LineTo(boxX + boxW, boxY + boxRadiusBR);
                    if (boxRadiusBR > 0) pdfCanvas.CurveTo(boxX + boxW, boxY + boxRadiusBR - kappaBR, boxX + boxW - boxRadiusBR + kappaBR, boxY, boxX + boxW - boxRadiusBR, boxY);
                    pdfCanvas.Stroke();
                    pdfCanvas.RestoreState();
                }

                // Bottom border (uses BR and BL corners)
                if (rrBorderBottom > 0)
                {
                    pdfCanvas.SaveState();
                    pdfCanvas.SetExtGState(new PdfExtGState().SetStrokeOpacity(1f));
                    pdfCanvas.SetStrokeColor(rrBorderColor);
                    pdfCanvas.SetLineWidth(rrBorderBottom);
                    pdfCanvas.MoveTo(boxX + boxW - boxRadiusBR, boxY);
                    pdfCanvas.LineTo(boxX + boxRadiusBL, boxY);
                    if (boxRadiusBL > 0) pdfCanvas.CurveTo(boxX + boxRadiusBL - kappaBL, boxY, boxX, boxY + boxRadiusBL - kappaBL, boxX, boxY + boxRadiusBL);
                    pdfCanvas.Stroke();
                    pdfCanvas.RestoreState();
                }

                // Left border (uses BL and TL corners)
                if (rrBorderLeft > 0)
                {
                    pdfCanvas.SaveState();
                    pdfCanvas.SetExtGState(new PdfExtGState().SetStrokeOpacity(1f));
                    pdfCanvas.SetStrokeColor(rrBorderColor);
                    pdfCanvas.SetLineWidth(rrBorderLeft);
                    pdfCanvas.MoveTo(boxX, boxY + boxRadiusBL);
                    pdfCanvas.LineTo(boxX, boxY + boxH - boxRadiusTL);
                    if (boxRadiusTL > 0) pdfCanvas.CurveTo(boxX, boxY + boxH - boxRadiusTL + kappaTL, boxX + boxRadiusTL - kappaTL, boxY + boxH, boxX + boxRadiusTL, boxY + boxH);
                    pdfCanvas.Stroke();
                    pdfCanvas.RestoreState();
                }
            }
            box_kasaraporudokumform_1132402720_deferredAdds.Add(box_kasaraporudokumform_631743576);
            box_kasaraporudokumform_1132402720_deferredAdds.AddRange(box_kasaraporudokumform_631743576_deferredAdds);
            }}


            //ReportTable7
            
            var kasaraporudokumform_846385438IsVisible = true;
            var kasaraporudokumform_846385438BackgroundColor = new DeviceRgb(0, 0, 0);
            var kasaraporudokumform_846385438BackgroundColorOpacity = 0f;
            var widths_kasaraporudokumform_846385438 = new List<float>();
widths_kasaraporudokumform_846385438.Add(98.27f * pxToPtFactor);
widths_kasaraporudokumform_846385438.Add(132.28f * pxToPtFactor);
widths_kasaraporudokumform_846385438.Add(117.17f * pxToPtFactor);
widths_kasaraporudokumform_846385438.Add(139.84f * pxToPtFactor);
widths_kasaraporudokumform_846385438.Add(75.59f * pxToPtFactor);
widths_kasaraporudokumform_846385438.Add(79.37007874015748f * pxToPtFactor);
widths_kasaraporudokumform_846385438.Add(90.71f * pxToPtFactor);
var designWidth_kasaraporudokumform_846385438 = 733.23f * pxToPtFactor;
var tableWidth_kasaraporudokumform_846385438 = (widths_kasaraporudokumform_846385438.Sum() / designWidth_kasaraporudokumform_846385438) * (733.23f * pxToPtFactor);

            Table kasaraporudokumform_846385438 = new Table(widths_kasaraporudokumform_846385438.ToArray()).SetWidth(tableWidth_kasaraporudokumform_846385438)
            .SetBackgroundColor(kasaraporudokumform_846385438BackgroundColor, kasaraporudokumform_846385438BackgroundColorOpacity)
            .SetVisible(kasaraporudokumform_846385438IsVisible)
            .SetMarginBottom(0 * pxToPtFactor)
            .SetMarginLeft(0 * pxToPtFactor)
            .SetMarginTop(0 * pxToPtFactor)
            .SetMarginRight(0 * pxToPtFactor);
            
            kasaraporudokumform_846385438.SetBorderBottom(new SolidBorder(new DeviceRgb(218, 218, 218), 1 * pxToPtFactor, 1f));
            kasaraporudokumform_846385438.SetBorderTop(new SolidBorder(new DeviceRgb(218, 218, 218), 1 * pxToPtFactor, 1f));
            kasaraporudokumform_846385438.SetBorderRight(new SolidBorder(new DeviceRgb(218, 218, 218), 1 * pxToPtFactor, 1f));
            kasaraporudokumform_846385438.SetBorderLeft(new SolidBorder(new DeviceRgb(218, 218, 218), 1 * pxToPtFactor, 1f));
            kasaraporudokumform_846385438.SetBorderRadius(new BorderRadius(0f * pxToPtFactor));
            kasaraporudokumform_846385438.SetFixedLayout();
            Color kasaraporudokumform_846385438borderColor = new DeviceRgb(240, 240, 240);
            Border kasaraporudokumform_846385438leftBorder = new SolidBorder(kasaraporudokumform_846385438borderColor, 1 * pxToPtFactor);
            if (kasaraporudokumform_846385438IsVisible)
            {
                
            List<String> columnValueNames_kasaraporudokumform_846385438 = new List<String>() {"CurrAccCode", "CurrAccDescription", "CustomerAtt02Desc", "PosHesabiAdi", "CurrAccCurrencyCode", "CurrAccAmount", "Doc_Amount"};
            
            var kasaraporudokumform_846385438_ColumTitlesPropValue = "";
            var kasaraporudokumform_846385438_ColumnTitles = new List<string>();
            if(kasaraporudokumform_846385438_ColumTitlesPropValue != null) {
               kasaraporudokumform_846385438_ColumnTitles = kasaraporudokumform_846385438_ColumTitlesPropValue.ToString()?.Split(";", StringSplitOptions.RemoveEmptyEntries).ToList();
            }
        
            
            Cell cell_0 = new Cell(1, 1);
            //cell_0.SetBorder(iText.Layout.Borders.Border.NO_BORDER)
            cell_0.SetBackgroundColor(new DeviceRgb(0, 0, 0), 0f);
            cell_0.SetBorderBottom(Border.NO_BORDER);
            cell_0.SetBorderTop(Border.NO_BORDER);
            cell_0.SetBorderRight(Border.NO_BORDER);
            cell_0.SetBorderLeft(Border.NO_BORDER);
            cell_0.SetBorderRadius(new BorderRadius(0f * pxToPtFactor));
            
            
            cell_0.SetPaddingBottom(0 * pxToPtFactor).SetPaddingLeft(0 * pxToPtFactor)
            .SetPaddingTop(0 * pxToPtFactor).SetPaddingRight(0 * pxToPtFactor).SetFontSize(14 * pxToPtFactor)
            .SetFont(fontDictionary["poppins_regular"]).SetFontColor(new DeviceRgb(155, 155, 155), 1f)
            .SetTextAlignment(iText.Layout.Properties.TextAlignment.LEFT);
            var headerParagraph_0 = new Paragraph((kasaraporudokumform_846385438_ColumnTitles is { Count: >= (0 + 1) } ? kasaraporudokumform_846385438_ColumnTitles[0] : kasaraporudokumform_846385438_ColumnTitles.Any() ? "" : ("Müşteri Kodu".ConvertToType<String>())))
            
            .WithGlyphFallback(fontDictionary, "poppins_regular", () => cjkFallbackFont.Value);
            cell_0.Add(headerParagraph_0);
            
            cell_0.SetVisible(true);
            kasaraporudokumform_846385438.AddHeaderCell(cell_0);


            Cell cell_1 = new Cell(1, 1);
            //cell_1.SetBorder(iText.Layout.Borders.Border.NO_BORDER)
            cell_1.SetBackgroundColor(new DeviceRgb(0, 0, 0), 0f);
            cell_1.SetBorderBottom(Border.NO_BORDER);
            cell_1.SetBorderTop(Border.NO_BORDER);
            cell_1.SetBorderRight(Border.NO_BORDER);
            cell_1.SetBorderLeft(Border.NO_BORDER);
            cell_1.SetBorderRadius(new BorderRadius(0f * pxToPtFactor));
            
            if(true){cell_1.SetBorderLeft(kasaraporudokumform_846385438leftBorder);}
            cell_1.SetPaddingBottom(0 * pxToPtFactor).SetPaddingLeft(0 * pxToPtFactor)
            .SetPaddingTop(0 * pxToPtFactor).SetPaddingRight(0 * pxToPtFactor).SetFontSize(14 * pxToPtFactor)
            .SetFont(fontDictionary["poppins_regular"]).SetFontColor(new DeviceRgb(155, 155, 155), 1f)
            .SetTextAlignment(iText.Layout.Properties.TextAlignment.LEFT);
            var headerParagraph_1 = new Paragraph((kasaraporudokumform_846385438_ColumnTitles is { Count: >= (1 + 1) } ? kasaraporudokumform_846385438_ColumnTitles[1] : kasaraporudokumform_846385438_ColumnTitles.Any() ? "" : ("Müşteri Adı".ConvertToType<String>())))
            
            .WithGlyphFallback(fontDictionary, "poppins_regular", () => cjkFallbackFont.Value);
            cell_1.Add(headerParagraph_1);
            
            cell_1.SetVisible(true);
            kasaraporudokumform_846385438.AddHeaderCell(cell_1);


            Cell cell_2 = new Cell(1, 1);
            //cell_2.SetBorder(iText.Layout.Borders.Border.NO_BORDER)
            cell_2.SetBackgroundColor(new DeviceRgb(0, 0, 0), 0f);
            cell_2.SetBorderBottom(Border.NO_BORDER);
            cell_2.SetBorderTop(Border.NO_BORDER);
            cell_2.SetBorderRight(Border.NO_BORDER);
            cell_2.SetBorderLeft(Border.NO_BORDER);
            cell_2.SetBorderRadius(new BorderRadius(0f * pxToPtFactor));
            
            if(true){cell_2.SetBorderLeft(kasaraporudokumform_846385438leftBorder);}
            cell_2.SetPaddingBottom(0 * pxToPtFactor).SetPaddingLeft(0 * pxToPtFactor)
            .SetPaddingTop(0 * pxToPtFactor).SetPaddingRight(0 * pxToPtFactor).SetFontSize(14 * pxToPtFactor)
            .SetFont(fontDictionary["poppins_regular"]).SetFontColor(new DeviceRgb(155, 155, 155), 1f)
            .SetTextAlignment(iText.Layout.Properties.TextAlignment.LEFT);
            var headerParagraph_2 = new Paragraph((kasaraporudokumform_846385438_ColumnTitles is { Count: >= (2 + 1) } ? kasaraporudokumform_846385438_ColumnTitles[2] : kasaraporudokumform_846385438_ColumnTitles.Any() ? "" : ("Satış Temsilcisi".ConvertToType<String>())))
            
            .WithGlyphFallback(fontDictionary, "poppins_regular", () => cjkFallbackFont.Value);
            cell_2.Add(headerParagraph_2);
            
            cell_2.SetVisible(true);
            kasaraporudokumform_846385438.AddHeaderCell(cell_2);


            Cell cell_3 = new Cell(1, 1);
            //cell_3.SetBorder(iText.Layout.Borders.Border.NO_BORDER)
            cell_3.SetBackgroundColor(new DeviceRgb(0, 0, 0), 0f);
            cell_3.SetBorderBottom(Border.NO_BORDER);
            cell_3.SetBorderTop(Border.NO_BORDER);
            cell_3.SetBorderRight(Border.NO_BORDER);
            cell_3.SetBorderLeft(Border.NO_BORDER);
            cell_3.SetBorderRadius(new BorderRadius(0f * pxToPtFactor));
            
            if(true){cell_3.SetBorderLeft(kasaraporudokumform_846385438leftBorder);}
            cell_3.SetPaddingBottom(0 * pxToPtFactor).SetPaddingLeft(0 * pxToPtFactor)
            .SetPaddingTop(0 * pxToPtFactor).SetPaddingRight(0 * pxToPtFactor).SetFontSize(14 * pxToPtFactor)
            .SetFont(fontDictionary["poppins_regular"]).SetFontColor(new DeviceRgb(155, 155, 155), 1f)
            .SetTextAlignment(iText.Layout.Properties.TextAlignment.LEFT);
            var headerParagraph_3 = new Paragraph((kasaraporudokumform_846385438_ColumnTitles is { Count: >= (3 + 1) } ? kasaraporudokumform_846385438_ColumnTitles[3] : kasaraporudokumform_846385438_ColumnTitles.Any() ? "" : ("POS Banka Adı".ConvertToType<String>())))
            
            .WithGlyphFallback(fontDictionary, "poppins_regular", () => cjkFallbackFont.Value);
            cell_3.Add(headerParagraph_3);
            
            cell_3.SetVisible(true);
            kasaraporudokumform_846385438.AddHeaderCell(cell_3);


            Cell cell_4 = new Cell(1, 1);
            //cell_4.SetBorder(iText.Layout.Borders.Border.NO_BORDER)
            cell_4.SetBackgroundColor(new DeviceRgb(0, 0, 0), 0f);
            cell_4.SetBorderBottom(Border.NO_BORDER);
            cell_4.SetBorderTop(Border.NO_BORDER);
            cell_4.SetBorderRight(Border.NO_BORDER);
            cell_4.SetBorderLeft(Border.NO_BORDER);
            cell_4.SetBorderRadius(new BorderRadius(0f * pxToPtFactor));
            
            if(true){cell_4.SetBorderLeft(kasaraporudokumform_846385438leftBorder);}
            cell_4.SetPaddingBottom(0 * pxToPtFactor).SetPaddingLeft(0 * pxToPtFactor)
            .SetPaddingTop(0 * pxToPtFactor).SetPaddingRight(0 * pxToPtFactor).SetFontSize(14 * pxToPtFactor)
            .SetFont(fontDictionary["poppins_regular"]).SetFontColor(new DeviceRgb(155, 155, 155), 1f)
            .SetTextAlignment(iText.Layout.Properties.TextAlignment.LEFT);
            var headerParagraph_4 = new Paragraph((kasaraporudokumform_846385438_ColumnTitles is { Count: >= (4 + 1) } ? kasaraporudokumform_846385438_ColumnTitles[4] : kasaraporudokumform_846385438_ColumnTitles.Any() ? "" : ("Para Birimi".ConvertToType<String>())))
            
            .WithGlyphFallback(fontDictionary, "poppins_regular", () => cjkFallbackFont.Value);
            cell_4.Add(headerParagraph_4);
            
            cell_4.SetVisible(true);
            kasaraporudokumform_846385438.AddHeaderCell(cell_4);


            Cell cell_5 = new Cell(1, 1);
            //cell_5.SetBorder(iText.Layout.Borders.Border.NO_BORDER)
            cell_5.SetBackgroundColor(new DeviceRgb(0, 0, 0), 0f);
            cell_5.SetBorderBottom(Border.NO_BORDER);
            cell_5.SetBorderTop(Border.NO_BORDER);
            cell_5.SetBorderRight(Border.NO_BORDER);
            cell_5.SetBorderLeft(Border.NO_BORDER);
            cell_5.SetBorderRadius(new BorderRadius(0f * pxToPtFactor));
            
            if(true){cell_5.SetBorderLeft(kasaraporudokumform_846385438leftBorder);}
            cell_5.SetPaddingBottom(0 * pxToPtFactor).SetPaddingLeft(0 * pxToPtFactor)
            .SetPaddingTop(0 * pxToPtFactor).SetPaddingRight(0 * pxToPtFactor).SetFontSize(14 * pxToPtFactor)
            .SetFont(fontDictionary["poppins_regular"]).SetFontColor(new DeviceRgb(155, 155, 155), 1f)
            .SetTextAlignment(iText.Layout.Properties.TextAlignment.LEFT);
            var headerParagraph_5 = new Paragraph((kasaraporudokumform_846385438_ColumnTitles is { Count: >= (5 + 1) } ? kasaraporudokumform_846385438_ColumnTitles[5] : kasaraporudokumform_846385438_ColumnTitles.Any() ? "" : ("Tutar".ConvertToType<String>())))
            
            .WithGlyphFallback(fontDictionary, "poppins_regular", () => cjkFallbackFont.Value);
            cell_5.Add(headerParagraph_5);
            
            cell_5.SetVisible(true);
            kasaraporudokumform_846385438.AddHeaderCell(cell_5);


            Cell cell_6 = new Cell(1, 1);
            //cell_6.SetBorder(iText.Layout.Borders.Border.NO_BORDER)
            cell_6.SetBackgroundColor(new DeviceRgb(0, 0, 0), 0f);
            cell_6.SetBorderBottom(Border.NO_BORDER);
            cell_6.SetBorderTop(Border.NO_BORDER);
            cell_6.SetBorderRight(Border.NO_BORDER);
            cell_6.SetBorderLeft(Border.NO_BORDER);
            cell_6.SetBorderRadius(new BorderRadius(0f * pxToPtFactor));
            
            if(true){cell_6.SetBorderLeft(kasaraporudokumform_846385438leftBorder);}
            cell_6.SetPaddingBottom(0 * pxToPtFactor).SetPaddingLeft(0 * pxToPtFactor)
            .SetPaddingTop(0 * pxToPtFactor).SetPaddingRight(0 * pxToPtFactor).SetFontSize(14 * pxToPtFactor)
            .SetFont(fontDictionary["poppins_regular"]).SetFontColor(new DeviceRgb(155, 155, 155), 1f)
            .SetTextAlignment(iText.Layout.Properties.TextAlignment.LEFT);
            var headerParagraph_6 = new Paragraph((kasaraporudokumform_846385438_ColumnTitles is { Count: >= (6 + 1) } ? kasaraporudokumform_846385438_ColumnTitles[6] : kasaraporudokumform_846385438_ColumnTitles.Any() ? "" : ("Tutar TL".ConvertToType<String>())))
            
            .WithGlyphFallback(fontDictionary, "poppins_regular", () => cjkFallbackFont.Value);
            cell_6.Add(headerParagraph_6);
            
            cell_6.SetVisible(true);
            kasaraporudokumform_846385438.AddHeaderCell(cell_6);


            
            var rowBackgroundColor = new DeviceRgb(0, 0, 0);
            var rowOpacity = 0;
            var isStriped = false;
            Color stripedColor = new DeviceRgb(245, 247, 250);
            for(int i = 0; i < result.Kuika_KrediKartiTahsilatlari4.Count; i++)
              {
                  var item = result.Kuika_KrediKartiTahsilatlari4[i];
                  Color backgroundColor = new DeviceRgb(255, 255, 255);
                  float backgroundColorOpacity = 0f;

                  if (kasaraporudokumform_846385438BackgroundColorOpacity == 1) {{
                        backgroundColor = kasaraporudokumform_846385438BackgroundColor;
                        backgroundColorOpacity = 1f;
                  }}

                  if (rowOpacity == 1) {{
                        backgroundColor = rowBackgroundColor;
                        backgroundColorOpacity = 1f;
                  }}

                  if (isStriped && i % 2 != 0) {{
                        backgroundColor = stripedColor;
                        backgroundColorOpacity = 1f;
                  }}

                  
                
            var colData_02066364691 = new Paragraph(item.CurrAccCode.ToFormattedString("", "", "") ?? "")
            .SetMarginBottom(0 * pxToPtFactor).SetMarginLeft(0 * pxToPtFactor)
            .SetMarginTop(0 * pxToPtFactor).SetMarginRight(0 * pxToPtFactor)
            .SetFontColor(new DeviceRgb(68, 68, 68), 1f)
            .SetBackgroundColor(new DeviceRgb(0, 0, 0), 0f)
            .SetFontSize(12 * pxToPtFactor)
            .SetFont(fontDictionary["poppins_regular"])
            .WithGlyphFallback(fontDictionary, "poppins_regular", () => cjkFallbackFont.Value)
            
            .SetParagraphWidthAndExtendHeightIfNotFit(document, 31.57f * pxToPtFactor, 20f * pxToPtFactor, true)
            .SetVisible(true)
            .SetVerticalAlignment(VerticalAlignment.TOP)
            .SetHorizontalAlignment(HorizontalAlignment.LEFT)
            .SetTextAlignment(TextAlignment.LEFT)
            .SetMultipliedLeading(1f);
            
colData_02066364691.SetVisible(true);

                Cell cell_2066364691 = new Cell(1, 1);
                var cell_2066364691BackgroundColor = new DeviceRgb(0, 0, 0);
                var cell_2066364691BackgroundColorOpacity = 0;
                
                cell_2066364691.SetMinHeight(40 * pxToPtFactor);
                //cell_2066364691.SetBorder(iText.Layout.Borders.Border.NO_BORDER);
                cell_2066364691.SetBorderBottom(Border.NO_BORDER);
                cell_2066364691.SetBorderTop(Border.NO_BORDER);
                cell_2066364691.SetBorderRight(Border.NO_BORDER);
                cell_2066364691.SetBorderLeft(Border.NO_BORDER);
                cell_2066364691.SetBorderRadius(new BorderRadius(0f * pxToPtFactor));
                //cell_2066364691.Add(colData_2066364691);
                if (cell_2066364691BackgroundColorOpacity == 1)
                    cell_2066364691.SetBackgroundColor(cell_2066364691BackgroundColor);
                else if (backgroundColorOpacity == 1)
                    cell_2066364691.SetBackgroundColor(backgroundColor);
                cell_2066364691.SetVerticalAlignment(iText.Layout.Properties.VerticalAlignment.TOP);
                cell_2066364691.SetTextAlignment(iText.Layout.Properties.TextAlignment.LEFT);
                cell_2066364691.SetPaddingBottom(0 * pxToPtFactor).SetPaddingLeft(0 * pxToPtFactor)
                .SetPaddingTop(0 * pxToPtFactor).SetPaddingRight(0 * pxToPtFactor);
                
                kasaraporudokumform_846385438.AddCell(cell_2066364691);

cell_2066364691.Add(colData_02066364691);

                
            var colData_01590705026 = new Paragraph(item.CurrAccDescription.ToFormattedString("", "", "") ?? "")
            .SetMarginBottom(0 * pxToPtFactor).SetMarginLeft(0 * pxToPtFactor)
            .SetMarginTop(0 * pxToPtFactor).SetMarginRight(0 * pxToPtFactor)
            .SetFontColor(new DeviceRgb(68, 68, 68), 1f)
            .SetBackgroundColor(new DeviceRgb(0, 0, 0), 0f)
            .SetFontSize(12 * pxToPtFactor)
            .SetFont(fontDictionary["poppins_regular"])
            .WithGlyphFallback(fontDictionary, "poppins_regular", () => cjkFallbackFont.Value)
            
            .SetParagraphWidthAndExtendHeightIfNotFit(document, 31.57f * pxToPtFactor, 20f * pxToPtFactor, true)
            .SetVisible(true)
            .SetVerticalAlignment(VerticalAlignment.TOP)
            .SetHorizontalAlignment(HorizontalAlignment.LEFT)
            .SetTextAlignment(TextAlignment.LEFT)
            .SetMultipliedLeading(1f);
            
colData_01590705026.SetVisible(true);

                Cell cell_1590705026 = new Cell(1, 1);
                var cell_1590705026BackgroundColor = new DeviceRgb(0, 0, 0);
                var cell_1590705026BackgroundColorOpacity = 0;
                
                cell_1590705026.SetMinHeight(40 * pxToPtFactor);
                //cell_1590705026.SetBorder(iText.Layout.Borders.Border.NO_BORDER);
                cell_1590705026.SetBorderBottom(Border.NO_BORDER);
                cell_1590705026.SetBorderTop(Border.NO_BORDER);
                cell_1590705026.SetBorderRight(Border.NO_BORDER);
                cell_1590705026.SetBorderLeft(Border.NO_BORDER);
                cell_1590705026.SetBorderRadius(new BorderRadius(0f * pxToPtFactor));
                //cell_1590705026.Add(colData_1590705026);
                if (cell_1590705026BackgroundColorOpacity == 1)
                    cell_1590705026.SetBackgroundColor(cell_1590705026BackgroundColor);
                else if (backgroundColorOpacity == 1)
                    cell_1590705026.SetBackgroundColor(backgroundColor);
                cell_1590705026.SetVerticalAlignment(iText.Layout.Properties.VerticalAlignment.TOP);
                cell_1590705026.SetTextAlignment(iText.Layout.Properties.TextAlignment.LEFT);
                cell_1590705026.SetPaddingBottom(0 * pxToPtFactor).SetPaddingLeft(0 * pxToPtFactor)
                .SetPaddingTop(0 * pxToPtFactor).SetPaddingRight(0 * pxToPtFactor);
                
                kasaraporudokumform_846385438.AddCell(cell_1590705026);

cell_1590705026.Add(colData_01590705026);

                
            var colData_0531192142 = new Paragraph(item.CustomerAtt02Desc.ToFormattedString("", "", "") ?? "")
            .SetMarginBottom(0 * pxToPtFactor).SetMarginLeft(0 * pxToPtFactor)
            .SetMarginTop(0 * pxToPtFactor).SetMarginRight(0 * pxToPtFactor)
            .SetFontColor(new DeviceRgb(68, 68, 68), 1f)
            .SetBackgroundColor(new DeviceRgb(0, 0, 0), 0f)
            .SetFontSize(12 * pxToPtFactor)
            .SetFont(fontDictionary["poppins_regular"])
            .WithGlyphFallback(fontDictionary, "poppins_regular", () => cjkFallbackFont.Value)
            
            .SetParagraphWidthAndExtendHeightIfNotFit(document, 31.57f * pxToPtFactor, 20f * pxToPtFactor, true)
            .SetVisible(true)
            .SetVerticalAlignment(VerticalAlignment.TOP)
            .SetHorizontalAlignment(HorizontalAlignment.LEFT)
            .SetTextAlignment(TextAlignment.LEFT)
            .SetMultipliedLeading(1f);
            
colData_0531192142.SetVisible(true);

                Cell cell_531192142 = new Cell(1, 1);
                var cell_531192142BackgroundColor = new DeviceRgb(0, 0, 0);
                var cell_531192142BackgroundColorOpacity = 0;
                
                cell_531192142.SetMinHeight(40 * pxToPtFactor);
                //cell_531192142.SetBorder(iText.Layout.Borders.Border.NO_BORDER);
                cell_531192142.SetBorderBottom(Border.NO_BORDER);
                cell_531192142.SetBorderTop(Border.NO_BORDER);
                cell_531192142.SetBorderRight(Border.NO_BORDER);
                cell_531192142.SetBorderLeft(Border.NO_BORDER);
                cell_531192142.SetBorderRadius(new BorderRadius(0f * pxToPtFactor));
                //cell_531192142.Add(colData_531192142);
                if (cell_531192142BackgroundColorOpacity == 1)
                    cell_531192142.SetBackgroundColor(cell_531192142BackgroundColor);
                else if (backgroundColorOpacity == 1)
                    cell_531192142.SetBackgroundColor(backgroundColor);
                cell_531192142.SetVerticalAlignment(iText.Layout.Properties.VerticalAlignment.TOP);
                cell_531192142.SetTextAlignment(iText.Layout.Properties.TextAlignment.LEFT);
                cell_531192142.SetPaddingBottom(0 * pxToPtFactor).SetPaddingLeft(0 * pxToPtFactor)
                .SetPaddingTop(0 * pxToPtFactor).SetPaddingRight(0 * pxToPtFactor);
                
                kasaraporudokumform_846385438.AddCell(cell_531192142);

cell_531192142.Add(colData_0531192142);

                
            var colData_01881762071 = new Paragraph(item.PosHesabiAdi.ToFormattedString("", "", "") ?? "")
            .SetMarginBottom(0 * pxToPtFactor).SetMarginLeft(0 * pxToPtFactor)
            .SetMarginTop(0 * pxToPtFactor).SetMarginRight(0 * pxToPtFactor)
            .SetFontColor(new DeviceRgb(68, 68, 68), 1f)
            .SetBackgroundColor(new DeviceRgb(0, 0, 0), 0f)
            .SetFontSize(12 * pxToPtFactor)
            .SetFont(fontDictionary["poppins_regular"])
            .WithGlyphFallback(fontDictionary, "poppins_regular", () => cjkFallbackFont.Value)
            
            .SetParagraphWidthAndExtendHeightIfNotFit(document, 31.57f * pxToPtFactor, 20f * pxToPtFactor, true)
            .SetVisible(true)
            .SetVerticalAlignment(VerticalAlignment.TOP)
            .SetHorizontalAlignment(HorizontalAlignment.LEFT)
            .SetTextAlignment(TextAlignment.LEFT)
            .SetMultipliedLeading(1f);
            
colData_01881762071.SetVisible(true);

                Cell cell_1881762071 = new Cell(1, 1);
                var cell_1881762071BackgroundColor = new DeviceRgb(0, 0, 0);
                var cell_1881762071BackgroundColorOpacity = 0;
                
                cell_1881762071.SetMinHeight(40 * pxToPtFactor);
                //cell_1881762071.SetBorder(iText.Layout.Borders.Border.NO_BORDER);
                cell_1881762071.SetBorderBottom(Border.NO_BORDER);
                cell_1881762071.SetBorderTop(Border.NO_BORDER);
                cell_1881762071.SetBorderRight(Border.NO_BORDER);
                cell_1881762071.SetBorderLeft(Border.NO_BORDER);
                cell_1881762071.SetBorderRadius(new BorderRadius(0f * pxToPtFactor));
                //cell_1881762071.Add(colData_1881762071);
                if (cell_1881762071BackgroundColorOpacity == 1)
                    cell_1881762071.SetBackgroundColor(cell_1881762071BackgroundColor);
                else if (backgroundColorOpacity == 1)
                    cell_1881762071.SetBackgroundColor(backgroundColor);
                cell_1881762071.SetVerticalAlignment(iText.Layout.Properties.VerticalAlignment.TOP);
                cell_1881762071.SetTextAlignment(iText.Layout.Properties.TextAlignment.LEFT);
                cell_1881762071.SetPaddingBottom(0 * pxToPtFactor).SetPaddingLeft(0 * pxToPtFactor)
                .SetPaddingTop(0 * pxToPtFactor).SetPaddingRight(0 * pxToPtFactor);
                
                kasaraporudokumform_846385438.AddCell(cell_1881762071);

cell_1881762071.Add(colData_01881762071);

                
            var colData_01553388845 = new Paragraph(item.CurrAccCurrencyCode.ToFormattedString("", "", "") ?? "")
            .SetMarginBottom(0 * pxToPtFactor).SetMarginLeft(0 * pxToPtFactor)
            .SetMarginTop(0 * pxToPtFactor).SetMarginRight(0 * pxToPtFactor)
            .SetFontColor(new DeviceRgb(68, 68, 68), 1f)
            .SetBackgroundColor(new DeviceRgb(0, 0, 0), 0f)
            .SetFontSize(12 * pxToPtFactor)
            .SetFont(fontDictionary["poppins_regular"])
            .WithGlyphFallback(fontDictionary, "poppins_regular", () => cjkFallbackFont.Value)
            
            .SetParagraphWidthAndExtendHeightIfNotFit(document, 31.57f * pxToPtFactor, 20f * pxToPtFactor, true)
            .SetVisible(true)
            .SetVerticalAlignment(VerticalAlignment.TOP)
            .SetHorizontalAlignment(HorizontalAlignment.LEFT)
            .SetTextAlignment(TextAlignment.LEFT)
            .SetMultipliedLeading(1f);
            
colData_01553388845.SetVisible(true);

                Cell cell_1553388845 = new Cell(1, 1);
                var cell_1553388845BackgroundColor = new DeviceRgb(0, 0, 0);
                var cell_1553388845BackgroundColorOpacity = 0;
                
                cell_1553388845.SetMinHeight(40 * pxToPtFactor);
                //cell_1553388845.SetBorder(iText.Layout.Borders.Border.NO_BORDER);
                cell_1553388845.SetBorderBottom(Border.NO_BORDER);
                cell_1553388845.SetBorderTop(Border.NO_BORDER);
                cell_1553388845.SetBorderRight(Border.NO_BORDER);
                cell_1553388845.SetBorderLeft(Border.NO_BORDER);
                cell_1553388845.SetBorderRadius(new BorderRadius(0f * pxToPtFactor));
                //cell_1553388845.Add(colData_1553388845);
                if (cell_1553388845BackgroundColorOpacity == 1)
                    cell_1553388845.SetBackgroundColor(cell_1553388845BackgroundColor);
                else if (backgroundColorOpacity == 1)
                    cell_1553388845.SetBackgroundColor(backgroundColor);
                cell_1553388845.SetVerticalAlignment(iText.Layout.Properties.VerticalAlignment.TOP);
                cell_1553388845.SetTextAlignment(iText.Layout.Properties.TextAlignment.LEFT);
                cell_1553388845.SetPaddingBottom(0 * pxToPtFactor).SetPaddingLeft(0 * pxToPtFactor)
                .SetPaddingTop(0 * pxToPtFactor).SetPaddingRight(0 * pxToPtFactor);
                
                kasaraporudokumform_846385438.AddCell(cell_1553388845);

cell_1553388845.Add(colData_01553388845);

                
            var colData_0918763336 = new Paragraph(item.CurrAccAmount.ToFormattedString("", "", "") ?? "")
            .SetMarginBottom(0 * pxToPtFactor).SetMarginLeft(0 * pxToPtFactor)
            .SetMarginTop(0 * pxToPtFactor).SetMarginRight(0 * pxToPtFactor)
            .SetFontColor(new DeviceRgb(68, 68, 68), 1f)
            .SetBackgroundColor(new DeviceRgb(0, 0, 0), 0f)
            .SetFontSize(12 * pxToPtFactor)
            .SetFont(fontDictionary["poppins_regular"])
            .WithGlyphFallback(fontDictionary, "poppins_regular", () => cjkFallbackFont.Value)
            
            .SetParagraphWidthAndExtendHeightIfNotFit(document, 31.57f * pxToPtFactor, 20f * pxToPtFactor, true)
            .SetVisible(true)
            .SetVerticalAlignment(VerticalAlignment.TOP)
            .SetHorizontalAlignment(HorizontalAlignment.LEFT)
            .SetTextAlignment(TextAlignment.LEFT)
            .SetMultipliedLeading(1f);
            
colData_0918763336.SetVisible(true);

                Cell cell_918763336 = new Cell(1, 1);
                var cell_918763336BackgroundColor = new DeviceRgb(0, 0, 0);
                var cell_918763336BackgroundColorOpacity = 0;
                
                cell_918763336.SetMinHeight(40 * pxToPtFactor);
                //cell_918763336.SetBorder(iText.Layout.Borders.Border.NO_BORDER);
                cell_918763336.SetBorderBottom(Border.NO_BORDER);
                cell_918763336.SetBorderTop(Border.NO_BORDER);
                cell_918763336.SetBorderRight(Border.NO_BORDER);
                cell_918763336.SetBorderLeft(Border.NO_BORDER);
                cell_918763336.SetBorderRadius(new BorderRadius(0f * pxToPtFactor));
                //cell_918763336.Add(colData_918763336);
                if (cell_918763336BackgroundColorOpacity == 1)
                    cell_918763336.SetBackgroundColor(cell_918763336BackgroundColor);
                else if (backgroundColorOpacity == 1)
                    cell_918763336.SetBackgroundColor(backgroundColor);
                cell_918763336.SetVerticalAlignment(iText.Layout.Properties.VerticalAlignment.TOP);
                cell_918763336.SetTextAlignment(iText.Layout.Properties.TextAlignment.LEFT);
                cell_918763336.SetPaddingBottom(0 * pxToPtFactor).SetPaddingLeft(0 * pxToPtFactor)
                .SetPaddingTop(0 * pxToPtFactor).SetPaddingRight(0 * pxToPtFactor);
                
                kasaraporudokumform_846385438.AddCell(cell_918763336);

cell_918763336.Add(colData_0918763336);

                
            var colData_0576203977 = new Paragraph(item.Doc_Amount.ToFormattedString("", "", "") ?? "")
            .SetMarginBottom(0 * pxToPtFactor).SetMarginLeft(0 * pxToPtFactor)
            .SetMarginTop(0 * pxToPtFactor).SetMarginRight(0 * pxToPtFactor)
            .SetFontColor(new DeviceRgb(68, 68, 68), 1f)
            .SetBackgroundColor(new DeviceRgb(0, 0, 0), 0f)
            .SetFontSize(12 * pxToPtFactor)
            .SetFont(fontDictionary["poppins_regular"])
            .WithGlyphFallback(fontDictionary, "poppins_regular", () => cjkFallbackFont.Value)
            
            .SetParagraphWidthAndExtendHeightIfNotFit(document, 31.57f * pxToPtFactor, 20f * pxToPtFactor, true)
            .SetVisible(true)
            .SetVerticalAlignment(VerticalAlignment.TOP)
            .SetHorizontalAlignment(HorizontalAlignment.LEFT)
            .SetTextAlignment(TextAlignment.LEFT)
            .SetMultipliedLeading(1f);
            
colData_0576203977.SetVisible(true);

                Cell cell_576203977 = new Cell(1, 1);
                var cell_576203977BackgroundColor = new DeviceRgb(0, 0, 0);
                var cell_576203977BackgroundColorOpacity = 0;
                
                cell_576203977.SetMinHeight(40 * pxToPtFactor);
                //cell_576203977.SetBorder(iText.Layout.Borders.Border.NO_BORDER);
                cell_576203977.SetBorderBottom(Border.NO_BORDER);
                cell_576203977.SetBorderTop(Border.NO_BORDER);
                cell_576203977.SetBorderRight(Border.NO_BORDER);
                cell_576203977.SetBorderLeft(Border.NO_BORDER);
                cell_576203977.SetBorderRadius(new BorderRadius(0f * pxToPtFactor));
                //cell_576203977.Add(colData_576203977);
                if (cell_576203977BackgroundColorOpacity == 1)
                    cell_576203977.SetBackgroundColor(cell_576203977BackgroundColor);
                else if (backgroundColorOpacity == 1)
                    cell_576203977.SetBackgroundColor(backgroundColor);
                cell_576203977.SetVerticalAlignment(iText.Layout.Properties.VerticalAlignment.TOP);
                cell_576203977.SetTextAlignment(iText.Layout.Properties.TextAlignment.LEFT);
                cell_576203977.SetPaddingBottom(0 * pxToPtFactor).SetPaddingLeft(0 * pxToPtFactor)
                .SetPaddingTop(0 * pxToPtFactor).SetPaddingRight(0 * pxToPtFactor);
                
                kasaraporudokumform_846385438.AddCell(cell_576203977);

cell_576203977.Add(colData_0576203977);

              }



            kasaraporudokumform_846385438.SetMarginLeft(10f * pxToPtFactor + 0f * pxToPtFactor);
            if (Math.Abs(1887f * pxToPtFactor) > 0) {{
               kasaraporudokumform_846385438.SetMarginTop(Math.Abs(1887f * pxToPtFactor) + 0f * pxToPtFactor);
            }}
            kasaraporudokumform_1132402720_cell.Add(kasaraporudokumform_846385438);
        }

   
            kasaraporudokumform_1132402720_cell.SetVisible(box_kasaraporudokumform_1132402720.IsVisible());
            box_kasaraporudokumform_1132402720.AddCell(kasaraporudokumform_1132402720_cell);
            
            // Draw rounded rectangle with PdfCanvas for border-radius support
            {
                var boxX = 5f * pxToPtFactor;
                var boxAbsY = Math.Abs(1847f * pxToPtFactor);
                var boxPageRelY = boxAbsY - pageStartY;
                var boxY = ((currentPageHeight > 0 ? currentPageHeight : canvasHeight.Value) - (boxPageRelY + Math.Abs(218f * pxToPtFactor)));
                var boxW = 780f * pxToPtFactor;
                var boxH = 218f * pxToPtFactor;
                var boxRadiusTL = 6f * pxToPtFactor;
                var boxRadiusTR = 6f * pxToPtFactor;
                var boxRadiusBR = 6f * pxToPtFactor;
                var boxRadiusBL = 6f * pxToPtFactor;
                float kappaTL = boxRadiusTL * 0.5522848f;
                float kappaTR = boxRadiusTR * 0.5522848f;
                float kappaBR = boxRadiusBR * 0.5522848f;
                float kappaBL = boxRadiusBL * 0.5522848f;
                var currentPage = pdf.GetPage(pdf.GetNumberOfPages());
                var pdfCanvas = new PdfCanvas(currentPage);

                // Draw rounded background with alpha support
                pdfCanvas.SaveState();
                pdfCanvas.SetExtGState(new PdfExtGState().SetFillOpacity(1f));
                pdfCanvas.SetFillColor(new DeviceRgb(255, 255, 255));
                pdfCanvas.MoveTo(boxX + boxRadiusBL, boxY);
                pdfCanvas.LineTo(boxX + boxW - boxRadiusBR, boxY);
                if (boxRadiusBR > 0) pdfCanvas.CurveTo(boxX + boxW - boxRadiusBR + kappaBR, boxY, boxX + boxW, boxY + boxRadiusBR - kappaBR, boxX + boxW, boxY + boxRadiusBR);
                pdfCanvas.LineTo(boxX + boxW, boxY + boxH - boxRadiusTR);
                if (boxRadiusTR > 0) pdfCanvas.CurveTo(boxX + boxW, boxY + boxH - boxRadiusTR + kappaTR, boxX + boxW - boxRadiusTR + kappaTR, boxY + boxH, boxX + boxW - boxRadiusTR, boxY + boxH);
                pdfCanvas.LineTo(boxX + boxRadiusTL, boxY + boxH);
                if (boxRadiusTL > 0) pdfCanvas.CurveTo(boxX + boxRadiusTL - kappaTL, boxY + boxH, boxX, boxY + boxH - boxRadiusTL + kappaTL, boxX, boxY + boxH - boxRadiusTL);
                pdfCanvas.LineTo(boxX, boxY + boxRadiusBL);
                if (boxRadiusBL > 0) pdfCanvas.CurveTo(boxX, boxY + boxRadiusBL - kappaBL, boxX + boxRadiusBL - kappaBL, boxY, boxX + boxRadiusBL, boxY);
                pdfCanvas.ClosePath();
                pdfCanvas.Fill();
                pdfCanvas.RestoreState();

                // Draw individual border edges with per-side widths
                var rrBorderColor = new DeviceRgb(238, 242, 246);
                float rrBorderTop = 1f * pxToPtFactor;
                float rrBorderRight = 1f * pxToPtFactor;
                float rrBorderBottom = 1f * pxToPtFactor;
                float rrBorderLeft = 1f * pxToPtFactor;

                // Top border (uses TL and TR corners)
                if (rrBorderTop > 0)
                {
                    pdfCanvas.SaveState();
                    pdfCanvas.SetExtGState(new PdfExtGState().SetStrokeOpacity(1f));
                    pdfCanvas.SetStrokeColor(rrBorderColor);
                    pdfCanvas.SetLineWidth(rrBorderTop);
                    pdfCanvas.MoveTo(boxX + boxRadiusTL, boxY + boxH);
                    pdfCanvas.LineTo(boxX + boxW - boxRadiusTR, boxY + boxH);
                    if (boxRadiusTR > 0) pdfCanvas.CurveTo(boxX + boxW - boxRadiusTR + kappaTR, boxY + boxH, boxX + boxW, boxY + boxH - boxRadiusTR + kappaTR, boxX + boxW, boxY + boxH - boxRadiusTR);
                    pdfCanvas.Stroke();
                    pdfCanvas.RestoreState();
                }

                // Right border (uses TR and BR corners)
                if (rrBorderRight > 0)
                {
                    pdfCanvas.SaveState();
                    pdfCanvas.SetExtGState(new PdfExtGState().SetStrokeOpacity(1f));
                    pdfCanvas.SetStrokeColor(rrBorderColor);
                    pdfCanvas.SetLineWidth(rrBorderRight);
                    pdfCanvas.MoveTo(boxX + boxW, boxY + boxH - boxRadiusTR);
                    pdfCanvas.LineTo(boxX + boxW, boxY + boxRadiusBR);
                    if (boxRadiusBR > 0) pdfCanvas.CurveTo(boxX + boxW, boxY + boxRadiusBR - kappaBR, boxX + boxW - boxRadiusBR + kappaBR, boxY, boxX + boxW - boxRadiusBR, boxY);
                    pdfCanvas.Stroke();
                    pdfCanvas.RestoreState();
                }

                // Bottom border (uses BR and BL corners)
                if (rrBorderBottom > 0)
                {
                    pdfCanvas.SaveState();
                    pdfCanvas.SetExtGState(new PdfExtGState().SetStrokeOpacity(1f));
                    pdfCanvas.SetStrokeColor(rrBorderColor);
                    pdfCanvas.SetLineWidth(rrBorderBottom);
                    pdfCanvas.MoveTo(boxX + boxW - boxRadiusBR, boxY);
                    pdfCanvas.LineTo(boxX + boxRadiusBL, boxY);
                    if (boxRadiusBL > 0) pdfCanvas.CurveTo(boxX + boxRadiusBL - kappaBL, boxY, boxX, boxY + boxRadiusBL - kappaBL, boxX, boxY + boxRadiusBL);
                    pdfCanvas.Stroke();
                    pdfCanvas.RestoreState();
                }

                // Left border (uses BL and TL corners)
                if (rrBorderLeft > 0)
                {
                    pdfCanvas.SaveState();
                    pdfCanvas.SetExtGState(new PdfExtGState().SetStrokeOpacity(1f));
                    pdfCanvas.SetStrokeColor(rrBorderColor);
                    pdfCanvas.SetLineWidth(rrBorderLeft);
                    pdfCanvas.MoveTo(boxX, boxY + boxRadiusBL);
                    pdfCanvas.LineTo(boxX, boxY + boxH - boxRadiusTL);
                    if (boxRadiusTL > 0) pdfCanvas.CurveTo(boxX, boxY + boxH - boxRadiusTL + kappaTL, boxX + boxRadiusTL - kappaTL, boxY + boxH, boxX + boxRadiusTL, boxY + boxH);
                    pdfCanvas.Stroke();
                    pdfCanvas.RestoreState();
                }
            }
            document.Add(box_kasaraporudokumform_1132402720);
            foreach (var deferredElem in box_kasaraporudokumform_1132402720_deferredAdds) document.Add(deferredElem);
            }}


            //Box16
            Table box_kasaraporudokumform_651570007 = new Table(1).SetWidth(780f * pxToPtFactor).SetHeight(218f * pxToPtFactor)
            .SetFontColor(new DeviceRgb(0, 0, 0), 1f)
            .SetFontSize(20 * pxToPtFactor)
            .SetVisible(true);
            if (box_kasaraporudokumform_651570007.IsVisible()) {{
            var box_kasaraporudokumform_651570007_pageLeftX = (double)(2f * pxToPtFactor) ;
            var box_kasaraporudokumform_651570007_pageTopY = 0d;
            var box_kasaraporudokumform_651570007_deferredAdds = new List<IBlockElement>();
            if (!false) {
            // Calculate page-relative Y position
            var box_kasaraporudokumform_651570007_absoluteY = Math.Abs(2089.5f * pxToPtFactor);
            var box_kasaraporudokumform_651570007_pageRelativeY = box_kasaraporudokumform_651570007_absoluteY - pageStartY;
            int box_kasaraporudokumform_651570007_targetPage = pdf.GetNumberOfPages();
            
            box_kasaraporudokumform_651570007.SetFixedPosition(box_kasaraporudokumform_651570007_targetPage, 2f * pxToPtFactor , ((currentPageHeight > 0 ? currentPageHeight : canvasHeight.Value) - (box_kasaraporudokumform_651570007_pageRelativeY + Math.Abs(218f * pxToPtFactor))) , 780f * pxToPtFactor);
            box_kasaraporudokumform_651570007_pageTopY = ((double)(currentPageHeight > 0 ? currentPageHeight : canvasHeight.Value) - box_kasaraporudokumform_651570007_pageRelativeY) ;
            } else {
            box_kasaraporudokumform_651570007.SetFixedPosition(2f * pxToPtFactor , ((currentPageHeight > 0 ? currentPageHeight : canvasHeight.Value) - (totalHeight + Math.Abs(2089.5f * pxToPtFactor) + Math.Abs(218f * pxToPtFactor))) , 780f * pxToPtFactor);
            box_kasaraporudokumform_651570007_pageTopY = ((double)(currentPageHeight > 0 ? currentPageHeight : canvasHeight.Value) - (totalHeight + Math.Abs(2089.5f * pxToPtFactor))) ;
            }
            box_kasaraporudokumform_651570007.SetBorder(Border.NO_BORDER);
            box_kasaraporudokumform_651570007.SetBorderBottom(Border.NO_BORDER);
            box_kasaraporudokumform_651570007.SetBorderTop(Border.NO_BORDER);
            box_kasaraporudokumform_651570007.SetBorderRight(Border.NO_BORDER);
            box_kasaraporudokumform_651570007.SetBorderLeft(Border.NO_BORDER);
            box_kasaraporudokumform_651570007.SetBorderRadius(new BorderRadius(6f * pxToPtFactor));
            var heightOf_box_kasaraporudokumform_651570007 = box_kasaraporudokumform_651570007.GetHeight();
            Cell kasaraporudokumform_651570007_cell = new Cell();
            kasaraporudokumform_651570007_cell.SetBackgroundColor(new DeviceRgb(255, 255, 255), 0f);
            kasaraporudokumform_651570007_cell.SetBorder(Border.NO_BORDER);
            
            // NOTE: Box always uses SetFixedPosition above (both branches), so it does not
            // contribute to flow. The legacy "totalHeight + height > canvasHeight" areaBreak
            // that lived here was reading totalHeight produced by previous flow elements
            // (e.g. multi-page ReportTables) and spuriously creating a new page + bumping
            // pageStartY, which broke pageRelativeY for every subsequent element. Removed.

            // No page breaks - using default canvas height behavior


            //Box17
            Table box_kasaraporudokumform_978732856 = new Table(1).SetWidth(790f * pxToPtFactor).SetHeight(30f * pxToPtFactor)
            .SetFontColor(new DeviceRgb(0, 0, 0), 1f)
            .SetFontSize(20 * pxToPtFactor)
            .SetVisible(true);
            if (box_kasaraporudokumform_978732856.IsVisible()) {{
            var box_kasaraporudokumform_978732856_pageLeftX = (double)(2f * pxToPtFactor) ;
            var box_kasaraporudokumform_978732856_pageTopY = 0d;
            var box_kasaraporudokumform_978732856_deferredAdds = new List<IBlockElement>();
            if (!false) {
            // Calculate page-relative Y position
            var box_kasaraporudokumform_978732856_absoluteY = Math.Abs(2089.5f * pxToPtFactor);
            var box_kasaraporudokumform_978732856_pageRelativeY = box_kasaraporudokumform_978732856_absoluteY - pageStartY;
            int box_kasaraporudokumform_978732856_targetPage = pdf.GetNumberOfPages();
            
            box_kasaraporudokumform_978732856.SetFixedPosition(box_kasaraporudokumform_978732856_targetPage, 2f * pxToPtFactor , ((currentPageHeight > 0 ? currentPageHeight : canvasHeight.Value) - (box_kasaraporudokumform_978732856_pageRelativeY + Math.Abs(30f * pxToPtFactor))) , 790f * pxToPtFactor);
            box_kasaraporudokumform_978732856_pageTopY = ((double)(currentPageHeight > 0 ? currentPageHeight : canvasHeight.Value) - box_kasaraporudokumform_978732856_pageRelativeY) ;
            } else {
            box_kasaraporudokumform_978732856.SetFixedPosition(2f * pxToPtFactor , ((currentPageHeight > 0 ? currentPageHeight : canvasHeight.Value) - (totalHeight + Math.Abs(2089.5f * pxToPtFactor) + Math.Abs(30f * pxToPtFactor))) , 790f * pxToPtFactor);
            box_kasaraporudokumform_978732856_pageTopY = ((double)(currentPageHeight > 0 ? currentPageHeight : canvasHeight.Value) - (totalHeight + Math.Abs(2089.5f * pxToPtFactor))) ;
            }
            box_kasaraporudokumform_978732856.SetBorder(Border.NO_BORDER);
            box_kasaraporudokumform_978732856.SetBorderBottom(Border.NO_BORDER);
            box_kasaraporudokumform_978732856.SetBorderTop(Border.NO_BORDER);
            box_kasaraporudokumform_978732856.SetBorderRight(Border.NO_BORDER);
            box_kasaraporudokumform_978732856.SetBorderLeft(Border.NO_BORDER);
            box_kasaraporudokumform_978732856.SetBorderRadius(new BorderRadius(6f * pxToPtFactor));
            var heightOf_box_kasaraporudokumform_978732856 = box_kasaraporudokumform_978732856.GetHeight();
            Cell kasaraporudokumform_978732856_cell = new Cell();
            kasaraporudokumform_978732856_cell.SetBackgroundColor(new DeviceRgb(114, 194, 64), 0f);
            kasaraporudokumform_978732856_cell.SetBorder(Border.NO_BORDER);
            
            // NOTE: Box always uses SetFixedPosition above (both branches), so it does not
            // contribute to flow. The legacy "totalHeight + height > canvasHeight" areaBreak
            // that lived here was reading totalHeight produced by previous flow elements
            // (e.g. multi-page ReportTables) and spuriously creating a new page + bumping
            // pageStartY, which broke pageRelativeY for every subsequent element. Removed.

            // No page breaks - using default canvas height behavior


            //Label16
            var label_kasaraporudokumform_797062728_effectiveWidth = 780f * pxToPtFactor > 0 ? 780f * pxToPtFactor : (canvasWidth.Value - (2f * pxToPtFactor));
            Paragraph label_kasaraporudokumform_797062728 = new Paragraph(@"Banka Tahsilatları ")
            .SetFontSize(15 * pxToPtFactor)
            .SetFont(fontDictionary["poppins_bold"])
            .WithGlyphFallback(fontDictionary, "poppins_bold", () => cjkFallbackFont.Value)
            .SetTextAlignment(TextAlignment.CENTER)
            
            .SetParagraphWidthAndExtendHeightIfNotFit(document, label_kasaraporudokumform_797062728_effectiveWidth, 20f * pxToPtFactor, false, false || false)
            .SetMultipliedLeading(0.875f);
            

            if (20f * pxToPtFactor == 0f)
            {
                label_kasaraporudokumform_797062728.SetMaxHeight((30f * pxToPtFactor) - Math.Abs(2089.5f * pxToPtFactor));
            }

            label_kasaraporudokumform_797062728.SetMarginBottom(0 * pxToPtFactor).SetMarginTop(0f);
            var label_kasaraporudokumform_797062728_paragraphHeight = label_kasaraporudokumform_797062728.GetHeightOfParagraph(document);
            var label_kasaraporudokumform_797062728_vAlignOffset = 0f;
            label_kasaraporudokumform_797062728_vAlignOffset = Math.Max(0f, (20f * pxToPtFactor - label_kasaraporudokumform_797062728_paragraphHeight) / 2f);
            label_kasaraporudokumform_797062728.SetMarginLeft(0 * pxToPtFactor)
            .SetMarginTop((0 * pxToPtFactor) + label_kasaraporudokumform_797062728_vAlignOffset).SetMarginRight(0 * pxToPtFactor)
            .SetFontColor(new DeviceRgb(255, 255, 255), 1f)
            .SetVisible(true);
            
            if (false)
			{
				Paragraph label_kasaraporudokumform_797062728_inside = new Paragraph(@"Banka Tahsilatları ")
			   .SetFontSize(15 * pxToPtFactor)
               .SetFont(fontDictionary["poppins_bold"])
			   .WithGlyphFallback(fontDictionary, "poppins_bold", () => cjkFallbackFont.Value)
			   .SetFontColor(new DeviceRgb(255, 255, 255), 1f)
			   
			   .SetRotationAngle(0);
				label_kasaraporudokumform_797062728.Add(label_kasaraporudokumform_797062728_inside);
			}
            var label_kasaraporudokumform_797062728_renderHeight = 20f * pxToPtFactor > 0 ? 20f * pxToPtFactor : label_kasaraporudokumform_797062728_paragraphHeight;
            // Actual div height accounts for paragraph margins that may expand the Div beyond MinHeight
            // paragraphHeight was measured with MarginTop=0, but actual MarginTop = paddingTop + vAlignOffset
            var label_kasaraporudokumform_797062728_divHeight = Math.Max(label_kasaraporudokumform_797062728_renderHeight, label_kasaraporudokumform_797062728_paragraphHeight + (0 * pxToPtFactor) + label_kasaraporudokumform_797062728_vAlignOffset);
            var div_label_kasaraporudokumform_797062728 = new Div();
            div_label_kasaraporudokumform_797062728.SetMinHeight(label_kasaraporudokumform_797062728_renderHeight);
            div_label_kasaraporudokumform_797062728.SetBackgroundColor(new DeviceRgb(0, 0, 0), 0f);
            div_label_kasaraporudokumform_797062728.SetBorderBottom(Border.NO_BORDER);
            div_label_kasaraporudokumform_797062728.SetBorderTop(Border.NO_BORDER);
            div_label_kasaraporudokumform_797062728.SetBorderRight(Border.NO_BORDER);
            div_label_kasaraporudokumform_797062728.SetBorderLeft(Border.NO_BORDER);
            div_label_kasaraporudokumform_797062728.SetBorderRadius(new BorderRadius(0f * pxToPtFactor));
            div_label_kasaraporudokumform_797062728.Add(label_kasaraporudokumform_797062728);
            
            // Label/Icon inside Box: use box page coordinates for absolute positioning
            var label_kasaraporudokumform_797062728_yPos = box_kasaraporudokumform_978732856_pageTopY - (0f * pxToPtFactor) - label_kasaraporudokumform_797062728_divHeight;
            div_label_kasaraporudokumform_797062728.SetFixedPosition((float)(box_kasaraporudokumform_978732856_pageLeftX + (0f * pxToPtFactor)), (float)label_kasaraporudokumform_797062728_yPos, label_kasaraporudokumform_797062728_effectiveWidth);
            div_label_kasaraporudokumform_797062728.SetVisible(true);
            box_kasaraporudokumform_978732856_deferredAdds.Add(div_label_kasaraporudokumform_797062728);

            kasaraporudokumform_978732856_cell.SetVisible(box_kasaraporudokumform_978732856.IsVisible());
            box_kasaraporudokumform_978732856.AddCell(kasaraporudokumform_978732856_cell);
            
            // Draw rounded rectangle with PdfCanvas for border-radius support
            {
                var boxX = 2f * pxToPtFactor;
                var boxAbsY = Math.Abs(2089.5f * pxToPtFactor);
                var boxPageRelY = boxAbsY - pageStartY;
                var boxY = ((currentPageHeight > 0 ? currentPageHeight : canvasHeight.Value) - (boxPageRelY + Math.Abs(30f * pxToPtFactor)));
                var boxW = 790f * pxToPtFactor;
                var boxH = 30f * pxToPtFactor;
                var boxRadiusTL = 6f * pxToPtFactor;
                var boxRadiusTR = 6f * pxToPtFactor;
                var boxRadiusBR = 6f * pxToPtFactor;
                var boxRadiusBL = 6f * pxToPtFactor;
                float kappaTL = boxRadiusTL * 0.5522848f;
                float kappaTR = boxRadiusTR * 0.5522848f;
                float kappaBR = boxRadiusBR * 0.5522848f;
                float kappaBL = boxRadiusBL * 0.5522848f;
                var currentPage = pdf.GetPage(pdf.GetNumberOfPages());
                var pdfCanvas = new PdfCanvas(currentPage);

                // Draw rounded background with alpha support
                pdfCanvas.SaveState();
                pdfCanvas.SetExtGState(new PdfExtGState().SetFillOpacity(1f));
                pdfCanvas.SetFillColor(new DeviceRgb(114, 194, 64));
                pdfCanvas.MoveTo(boxX + boxRadiusBL, boxY);
                pdfCanvas.LineTo(boxX + boxW - boxRadiusBR, boxY);
                if (boxRadiusBR > 0) pdfCanvas.CurveTo(boxX + boxW - boxRadiusBR + kappaBR, boxY, boxX + boxW, boxY + boxRadiusBR - kappaBR, boxX + boxW, boxY + boxRadiusBR);
                pdfCanvas.LineTo(boxX + boxW, boxY + boxH - boxRadiusTR);
                if (boxRadiusTR > 0) pdfCanvas.CurveTo(boxX + boxW, boxY + boxH - boxRadiusTR + kappaTR, boxX + boxW - boxRadiusTR + kappaTR, boxY + boxH, boxX + boxW - boxRadiusTR, boxY + boxH);
                pdfCanvas.LineTo(boxX + boxRadiusTL, boxY + boxH);
                if (boxRadiusTL > 0) pdfCanvas.CurveTo(boxX + boxRadiusTL - kappaTL, boxY + boxH, boxX, boxY + boxH - boxRadiusTL + kappaTL, boxX, boxY + boxH - boxRadiusTL);
                pdfCanvas.LineTo(boxX, boxY + boxRadiusBL);
                if (boxRadiusBL > 0) pdfCanvas.CurveTo(boxX, boxY + boxRadiusBL - kappaBL, boxX + boxRadiusBL - kappaBL, boxY, boxX + boxRadiusBL, boxY);
                pdfCanvas.ClosePath();
                pdfCanvas.Fill();
                pdfCanvas.RestoreState();

                // Draw individual border edges with per-side widths
                var rrBorderColor = new DeviceRgb(114, 194, 64);
                float rrBorderTop = 1f * pxToPtFactor;
                float rrBorderRight = 1f * pxToPtFactor;
                float rrBorderBottom = 1f * pxToPtFactor;
                float rrBorderLeft = 1f * pxToPtFactor;

                // Top border (uses TL and TR corners)
                if (rrBorderTop > 0)
                {
                    pdfCanvas.SaveState();
                    pdfCanvas.SetExtGState(new PdfExtGState().SetStrokeOpacity(1f));
                    pdfCanvas.SetStrokeColor(rrBorderColor);
                    pdfCanvas.SetLineWidth(rrBorderTop);
                    pdfCanvas.MoveTo(boxX + boxRadiusTL, boxY + boxH);
                    pdfCanvas.LineTo(boxX + boxW - boxRadiusTR, boxY + boxH);
                    if (boxRadiusTR > 0) pdfCanvas.CurveTo(boxX + boxW - boxRadiusTR + kappaTR, boxY + boxH, boxX + boxW, boxY + boxH - boxRadiusTR + kappaTR, boxX + boxW, boxY + boxH - boxRadiusTR);
                    pdfCanvas.Stroke();
                    pdfCanvas.RestoreState();
                }

                // Right border (uses TR and BR corners)
                if (rrBorderRight > 0)
                {
                    pdfCanvas.SaveState();
                    pdfCanvas.SetExtGState(new PdfExtGState().SetStrokeOpacity(1f));
                    pdfCanvas.SetStrokeColor(rrBorderColor);
                    pdfCanvas.SetLineWidth(rrBorderRight);
                    pdfCanvas.MoveTo(boxX + boxW, boxY + boxH - boxRadiusTR);
                    pdfCanvas.LineTo(boxX + boxW, boxY + boxRadiusBR);
                    if (boxRadiusBR > 0) pdfCanvas.CurveTo(boxX + boxW, boxY + boxRadiusBR - kappaBR, boxX + boxW - boxRadiusBR + kappaBR, boxY, boxX + boxW - boxRadiusBR, boxY);
                    pdfCanvas.Stroke();
                    pdfCanvas.RestoreState();
                }

                // Bottom border (uses BR and BL corners)
                if (rrBorderBottom > 0)
                {
                    pdfCanvas.SaveState();
                    pdfCanvas.SetExtGState(new PdfExtGState().SetStrokeOpacity(1f));
                    pdfCanvas.SetStrokeColor(rrBorderColor);
                    pdfCanvas.SetLineWidth(rrBorderBottom);
                    pdfCanvas.MoveTo(boxX + boxW - boxRadiusBR, boxY);
                    pdfCanvas.LineTo(boxX + boxRadiusBL, boxY);
                    if (boxRadiusBL > 0) pdfCanvas.CurveTo(boxX + boxRadiusBL - kappaBL, boxY, boxX, boxY + boxRadiusBL - kappaBL, boxX, boxY + boxRadiusBL);
                    pdfCanvas.Stroke();
                    pdfCanvas.RestoreState();
                }

                // Left border (uses BL and TL corners)
                if (rrBorderLeft > 0)
                {
                    pdfCanvas.SaveState();
                    pdfCanvas.SetExtGState(new PdfExtGState().SetStrokeOpacity(1f));
                    pdfCanvas.SetStrokeColor(rrBorderColor);
                    pdfCanvas.SetLineWidth(rrBorderLeft);
                    pdfCanvas.MoveTo(boxX, boxY + boxRadiusBL);
                    pdfCanvas.LineTo(boxX, boxY + boxH - boxRadiusTL);
                    if (boxRadiusTL > 0) pdfCanvas.CurveTo(boxX, boxY + boxH - boxRadiusTL + kappaTL, boxX + boxRadiusTL - kappaTL, boxY + boxH, boxX + boxRadiusTL, boxY + boxH);
                    pdfCanvas.Stroke();
                    pdfCanvas.RestoreState();
                }
            }
            box_kasaraporudokumform_651570007_deferredAdds.Add(box_kasaraporudokumform_978732856);
            box_kasaraporudokumform_651570007_deferredAdds.AddRange(box_kasaraporudokumform_978732856_deferredAdds);
            }}


            //ReportTable8
            
            var kasaraporudokumform_1715142869IsVisible = true;
            var kasaraporudokumform_1715142869BackgroundColor = new DeviceRgb(0, 0, 0);
            var kasaraporudokumform_1715142869BackgroundColorOpacity = 0f;
            var widths_kasaraporudokumform_1715142869 = new List<float>();
widths_kasaraporudokumform_1715142869.Add(98.27f * pxToPtFactor);
widths_kasaraporudokumform_1715142869.Add(173.86f * pxToPtFactor);
widths_kasaraporudokumform_1715142869.Add(132.28f * pxToPtFactor);
widths_kasaraporudokumform_1715142869.Add(158.74f * pxToPtFactor);
widths_kasaraporudokumform_1715142869.Add(83.15f * pxToPtFactor);
widths_kasaraporudokumform_1715142869.Add(83.15f * pxToPtFactor);
var designWidth_kasaraporudokumform_1715142869 = 729.45f * pxToPtFactor;
var tableWidth_kasaraporudokumform_1715142869 = (widths_kasaraporudokumform_1715142869.Sum() / designWidth_kasaraporudokumform_1715142869) * (729.45f * pxToPtFactor);

            Table kasaraporudokumform_1715142869 = new Table(widths_kasaraporudokumform_1715142869.ToArray()).SetWidth(tableWidth_kasaraporudokumform_1715142869)
            .SetBackgroundColor(kasaraporudokumform_1715142869BackgroundColor, kasaraporudokumform_1715142869BackgroundColorOpacity)
            .SetVisible(kasaraporudokumform_1715142869IsVisible)
            .SetMarginBottom(0 * pxToPtFactor)
            .SetMarginLeft(0 * pxToPtFactor)
            .SetMarginTop(0 * pxToPtFactor)
            .SetMarginRight(0 * pxToPtFactor);
            
            kasaraporudokumform_1715142869.SetBorderBottom(new SolidBorder(new DeviceRgb(218, 218, 218), 1 * pxToPtFactor, 1f));
            kasaraporudokumform_1715142869.SetBorderTop(new SolidBorder(new DeviceRgb(218, 218, 218), 1 * pxToPtFactor, 1f));
            kasaraporudokumform_1715142869.SetBorderRight(new SolidBorder(new DeviceRgb(218, 218, 218), 1 * pxToPtFactor, 1f));
            kasaraporudokumform_1715142869.SetBorderLeft(new SolidBorder(new DeviceRgb(218, 218, 218), 1 * pxToPtFactor, 1f));
            kasaraporudokumform_1715142869.SetBorderRadius(new BorderRadius(0f * pxToPtFactor));
            kasaraporudokumform_1715142869.SetFixedLayout();
            Color kasaraporudokumform_1715142869borderColor = new DeviceRgb(240, 240, 240);
            Border kasaraporudokumform_1715142869leftBorder = new SolidBorder(kasaraporudokumform_1715142869borderColor, 1 * pxToPtFactor);
            if (kasaraporudokumform_1715142869IsVisible)
            {
                
            List<String> columnValueNames_kasaraporudokumform_1715142869 = new List<String>() {"CurrAccCode", "CurrAccDescription", "DocumentNumber", "KasaHesabiAdi", "Loc_Amount", "Doc_Amount"};
            
            var kasaraporudokumform_1715142869_ColumTitlesPropValue = "";
            var kasaraporudokumform_1715142869_ColumnTitles = new List<string>();
            if(kasaraporudokumform_1715142869_ColumTitlesPropValue != null) {
               kasaraporudokumform_1715142869_ColumnTitles = kasaraporudokumform_1715142869_ColumTitlesPropValue.ToString()?.Split(";", StringSplitOptions.RemoveEmptyEntries).ToList();
            }
        
            
            Cell cell_0 = new Cell(1, 1);
            //cell_0.SetBorder(iText.Layout.Borders.Border.NO_BORDER)
            cell_0.SetBackgroundColor(new DeviceRgb(0, 0, 0), 0f);
            cell_0.SetBorderBottom(Border.NO_BORDER);
            cell_0.SetBorderTop(Border.NO_BORDER);
            cell_0.SetBorderRight(Border.NO_BORDER);
            cell_0.SetBorderLeft(Border.NO_BORDER);
            cell_0.SetBorderRadius(new BorderRadius(0f * pxToPtFactor));
            
            
            cell_0.SetPaddingBottom(0 * pxToPtFactor).SetPaddingLeft(0 * pxToPtFactor)
            .SetPaddingTop(0 * pxToPtFactor).SetPaddingRight(0 * pxToPtFactor).SetFontSize(14 * pxToPtFactor)
            .SetFont(fontDictionary["poppins_regular"]).SetFontColor(new DeviceRgb(155, 155, 155), 1f)
            .SetTextAlignment(iText.Layout.Properties.TextAlignment.LEFT);
            var headerParagraph_0 = new Paragraph((kasaraporudokumform_1715142869_ColumnTitles is { Count: >= (0 + 1) } ? kasaraporudokumform_1715142869_ColumnTitles[0] : kasaraporudokumform_1715142869_ColumnTitles.Any() ? "" : ("Müşteri Kodu".ConvertToType<String>())))
            
            .WithGlyphFallback(fontDictionary, "poppins_regular", () => cjkFallbackFont.Value);
            cell_0.Add(headerParagraph_0);
            
            cell_0.SetVisible(true);
            kasaraporudokumform_1715142869.AddHeaderCell(cell_0);


            Cell cell_1 = new Cell(1, 1);
            //cell_1.SetBorder(iText.Layout.Borders.Border.NO_BORDER)
            cell_1.SetBackgroundColor(new DeviceRgb(0, 0, 0), 0f);
            cell_1.SetBorderBottom(Border.NO_BORDER);
            cell_1.SetBorderTop(Border.NO_BORDER);
            cell_1.SetBorderRight(Border.NO_BORDER);
            cell_1.SetBorderLeft(Border.NO_BORDER);
            cell_1.SetBorderRadius(new BorderRadius(0f * pxToPtFactor));
            
            if(true){cell_1.SetBorderLeft(kasaraporudokumform_1715142869leftBorder);}
            cell_1.SetPaddingBottom(0 * pxToPtFactor).SetPaddingLeft(0 * pxToPtFactor)
            .SetPaddingTop(0 * pxToPtFactor).SetPaddingRight(0 * pxToPtFactor).SetFontSize(14 * pxToPtFactor)
            .SetFont(fontDictionary["poppins_regular"]).SetFontColor(new DeviceRgb(155, 155, 155), 1f)
            .SetTextAlignment(iText.Layout.Properties.TextAlignment.LEFT);
            var headerParagraph_1 = new Paragraph((kasaraporudokumform_1715142869_ColumnTitles is { Count: >= (1 + 1) } ? kasaraporudokumform_1715142869_ColumnTitles[1] : kasaraporudokumform_1715142869_ColumnTitles.Any() ? "" : ("Müşteri Adı".ConvertToType<String>())))
            
            .WithGlyphFallback(fontDictionary, "poppins_regular", () => cjkFallbackFont.Value);
            cell_1.Add(headerParagraph_1);
            
            cell_1.SetVisible(true);
            kasaraporudokumform_1715142869.AddHeaderCell(cell_1);


            Cell cell_2 = new Cell(1, 1);
            //cell_2.SetBorder(iText.Layout.Borders.Border.NO_BORDER)
            cell_2.SetBackgroundColor(new DeviceRgb(0, 0, 0), 0f);
            cell_2.SetBorderBottom(Border.NO_BORDER);
            cell_2.SetBorderTop(Border.NO_BORDER);
            cell_2.SetBorderRight(Border.NO_BORDER);
            cell_2.SetBorderLeft(Border.NO_BORDER);
            cell_2.SetBorderRadius(new BorderRadius(0f * pxToPtFactor));
            
            if(true){cell_2.SetBorderLeft(kasaraporudokumform_1715142869leftBorder);}
            cell_2.SetPaddingBottom(0 * pxToPtFactor).SetPaddingLeft(0 * pxToPtFactor)
            .SetPaddingTop(0 * pxToPtFactor).SetPaddingRight(0 * pxToPtFactor).SetFontSize(14 * pxToPtFactor)
            .SetFont(fontDictionary["poppins_regular"]).SetFontColor(new DeviceRgb(155, 155, 155), 1f)
            .SetTextAlignment(iText.Layout.Properties.TextAlignment.LEFT);
            var headerParagraph_2 = new Paragraph((kasaraporudokumform_1715142869_ColumnTitles is { Count: >= (2 + 1) } ? kasaraporudokumform_1715142869_ColumnTitles[2] : kasaraporudokumform_1715142869_ColumnTitles.Any() ? "" : ("Dekont Numarası".ConvertToType<String>())))
            
            .WithGlyphFallback(fontDictionary, "poppins_regular", () => cjkFallbackFont.Value);
            cell_2.Add(headerParagraph_2);
            
            cell_2.SetVisible(true);
            kasaraporudokumform_1715142869.AddHeaderCell(cell_2);


            Cell cell_3 = new Cell(1, 1);
            //cell_3.SetBorder(iText.Layout.Borders.Border.NO_BORDER)
            cell_3.SetBackgroundColor(new DeviceRgb(0, 0, 0), 0f);
            cell_3.SetBorderBottom(Border.NO_BORDER);
            cell_3.SetBorderTop(Border.NO_BORDER);
            cell_3.SetBorderRight(Border.NO_BORDER);
            cell_3.SetBorderLeft(Border.NO_BORDER);
            cell_3.SetBorderRadius(new BorderRadius(0f * pxToPtFactor));
            
            if(true){cell_3.SetBorderLeft(kasaraporudokumform_1715142869leftBorder);}
            cell_3.SetPaddingBottom(0 * pxToPtFactor).SetPaddingLeft(0 * pxToPtFactor)
            .SetPaddingTop(0 * pxToPtFactor).SetPaddingRight(0 * pxToPtFactor).SetFontSize(14 * pxToPtFactor)
            .SetFont(fontDictionary["poppins_regular"]).SetFontColor(new DeviceRgb(155, 155, 155), 1f)
            .SetTextAlignment(iText.Layout.Properties.TextAlignment.LEFT);
            var headerParagraph_3 = new Paragraph((kasaraporudokumform_1715142869_ColumnTitles is { Count: >= (3 + 1) } ? kasaraporudokumform_1715142869_ColumnTitles[3] : kasaraporudokumform_1715142869_ColumnTitles.Any() ? "" : ("Banka Adı".ConvertToType<String>())))
            
            .WithGlyphFallback(fontDictionary, "poppins_regular", () => cjkFallbackFont.Value);
            cell_3.Add(headerParagraph_3);
            
            cell_3.SetVisible(true);
            kasaraporudokumform_1715142869.AddHeaderCell(cell_3);


            Cell cell_4 = new Cell(1, 1);
            //cell_4.SetBorder(iText.Layout.Borders.Border.NO_BORDER)
            cell_4.SetBackgroundColor(new DeviceRgb(0, 0, 0), 0f);
            cell_4.SetBorderBottom(Border.NO_BORDER);
            cell_4.SetBorderTop(Border.NO_BORDER);
            cell_4.SetBorderRight(Border.NO_BORDER);
            cell_4.SetBorderLeft(Border.NO_BORDER);
            cell_4.SetBorderRadius(new BorderRadius(0f * pxToPtFactor));
            
            if(true){cell_4.SetBorderLeft(kasaraporudokumform_1715142869leftBorder);}
            cell_4.SetPaddingBottom(0 * pxToPtFactor).SetPaddingLeft(0 * pxToPtFactor)
            .SetPaddingTop(0 * pxToPtFactor).SetPaddingRight(0 * pxToPtFactor).SetFontSize(14 * pxToPtFactor)
            .SetFont(fontDictionary["poppins_regular"]).SetFontColor(new DeviceRgb(155, 155, 155), 1f)
            .SetTextAlignment(iText.Layout.Properties.TextAlignment.LEFT);
            var headerParagraph_4 = new Paragraph((kasaraporudokumform_1715142869_ColumnTitles is { Count: >= (4 + 1) } ? kasaraporudokumform_1715142869_ColumnTitles[4] : kasaraporudokumform_1715142869_ColumnTitles.Any() ? "" : ("TRY".ConvertToType<String>())))
            
            .WithGlyphFallback(fontDictionary, "poppins_regular", () => cjkFallbackFont.Value);
            cell_4.Add(headerParagraph_4);
            
            cell_4.SetVisible(true);
            kasaraporudokumform_1715142869.AddHeaderCell(cell_4);


            Cell cell_5 = new Cell(1, 1);
            //cell_5.SetBorder(iText.Layout.Borders.Border.NO_BORDER)
            cell_5.SetBackgroundColor(new DeviceRgb(0, 0, 0), 0f);
            cell_5.SetBorderBottom(Border.NO_BORDER);
            cell_5.SetBorderTop(Border.NO_BORDER);
            cell_5.SetBorderRight(Border.NO_BORDER);
            cell_5.SetBorderLeft(Border.NO_BORDER);
            cell_5.SetBorderRadius(new BorderRadius(0f * pxToPtFactor));
            
            if(true){cell_5.SetBorderLeft(kasaraporudokumform_1715142869leftBorder);}
            cell_5.SetPaddingBottom(0 * pxToPtFactor).SetPaddingLeft(0 * pxToPtFactor)
            .SetPaddingTop(0 * pxToPtFactor).SetPaddingRight(0 * pxToPtFactor).SetFontSize(14 * pxToPtFactor)
            .SetFont(fontDictionary["poppins_regular"]).SetFontColor(new DeviceRgb(155, 155, 155), 1f)
            .SetTextAlignment(iText.Layout.Properties.TextAlignment.LEFT);
            var headerParagraph_5 = new Paragraph((kasaraporudokumform_1715142869_ColumnTitles is { Count: >= (5 + 1) } ? kasaraporudokumform_1715142869_ColumnTitles[5] : kasaraporudokumform_1715142869_ColumnTitles.Any() ? "" : ("DVZ".ConvertToType<String>())))
            
            .WithGlyphFallback(fontDictionary, "poppins_regular", () => cjkFallbackFont.Value);
            cell_5.Add(headerParagraph_5);
            
            cell_5.SetVisible(true);
            kasaraporudokumform_1715142869.AddHeaderCell(cell_5);


            
            var rowBackgroundColor = new DeviceRgb(0, 0, 0);
            var rowOpacity = 0;
            var isStriped = false;
            Color stripedColor = new DeviceRgb(245, 247, 250);
            for(int i = 0; i < result.Kuika_NakitDevirler3.Count; i++)
              {
                  var item = result.Kuika_NakitDevirler3[i];
                  Color backgroundColor = new DeviceRgb(255, 255, 255);
                  float backgroundColorOpacity = 0f;

                  if (kasaraporudokumform_1715142869BackgroundColorOpacity == 1) {{
                        backgroundColor = kasaraporudokumform_1715142869BackgroundColor;
                        backgroundColorOpacity = 1f;
                  }}

                  if (rowOpacity == 1) {{
                        backgroundColor = rowBackgroundColor;
                        backgroundColorOpacity = 1f;
                  }}

                  if (isStriped && i % 2 != 0) {{
                        backgroundColor = stripedColor;
                        backgroundColorOpacity = 1f;
                  }}

                  
                
            var colData_0999434120 = new Paragraph(item.CurrAccCode.ToFormattedString("", "", "") ?? "")
            .SetMarginBottom(0 * pxToPtFactor).SetMarginLeft(0 * pxToPtFactor)
            .SetMarginTop(0 * pxToPtFactor).SetMarginRight(0 * pxToPtFactor)
            .SetFontColor(new DeviceRgb(68, 68, 68), 1f)
            .SetBackgroundColor(new DeviceRgb(0, 0, 0), 0f)
            .SetFontSize(12 * pxToPtFactor)
            .SetFont(fontDictionary["poppins_regular"])
            .WithGlyphFallback(fontDictionary, "poppins_regular", () => cjkFallbackFont.Value)
            
            .SetParagraphWidthAndExtendHeightIfNotFit(document, 31.57f * pxToPtFactor, 20f * pxToPtFactor, true)
            .SetVisible(true)
            .SetVerticalAlignment(VerticalAlignment.TOP)
            .SetHorizontalAlignment(HorizontalAlignment.LEFT)
            .SetTextAlignment(TextAlignment.LEFT)
            .SetMultipliedLeading(1f);
            
colData_0999434120.SetVisible(true);

                Cell cell_999434120 = new Cell(1, 1);
                var cell_999434120BackgroundColor = new DeviceRgb(0, 0, 0);
                var cell_999434120BackgroundColorOpacity = 0;
                
                cell_999434120.SetMinHeight(40 * pxToPtFactor);
                //cell_999434120.SetBorder(iText.Layout.Borders.Border.NO_BORDER);
                cell_999434120.SetBorderBottom(Border.NO_BORDER);
                cell_999434120.SetBorderTop(Border.NO_BORDER);
                cell_999434120.SetBorderRight(Border.NO_BORDER);
                cell_999434120.SetBorderLeft(Border.NO_BORDER);
                cell_999434120.SetBorderRadius(new BorderRadius(0f * pxToPtFactor));
                //cell_999434120.Add(colData_999434120);
                if (cell_999434120BackgroundColorOpacity == 1)
                    cell_999434120.SetBackgroundColor(cell_999434120BackgroundColor);
                else if (backgroundColorOpacity == 1)
                    cell_999434120.SetBackgroundColor(backgroundColor);
                cell_999434120.SetVerticalAlignment(iText.Layout.Properties.VerticalAlignment.TOP);
                cell_999434120.SetTextAlignment(iText.Layout.Properties.TextAlignment.LEFT);
                cell_999434120.SetPaddingBottom(0 * pxToPtFactor).SetPaddingLeft(0 * pxToPtFactor)
                .SetPaddingTop(0 * pxToPtFactor).SetPaddingRight(0 * pxToPtFactor);
                
                kasaraporudokumform_1715142869.AddCell(cell_999434120);

cell_999434120.Add(colData_0999434120);

                
            var colData_0595415129 = new Paragraph(item.CurrAccDescription.ToFormattedString("", "", "") ?? "")
            .SetMarginBottom(0 * pxToPtFactor).SetMarginLeft(0 * pxToPtFactor)
            .SetMarginTop(0 * pxToPtFactor).SetMarginRight(0 * pxToPtFactor)
            .SetFontColor(new DeviceRgb(68, 68, 68), 1f)
            .SetBackgroundColor(new DeviceRgb(0, 0, 0), 0f)
            .SetFontSize(12 * pxToPtFactor)
            .SetFont(fontDictionary["poppins_regular"])
            .WithGlyphFallback(fontDictionary, "poppins_regular", () => cjkFallbackFont.Value)
            
            .SetParagraphWidthAndExtendHeightIfNotFit(document, 31.57f * pxToPtFactor, 20f * pxToPtFactor, true)
            .SetVisible(true)
            .SetVerticalAlignment(VerticalAlignment.TOP)
            .SetHorizontalAlignment(HorizontalAlignment.LEFT)
            .SetTextAlignment(TextAlignment.LEFT)
            .SetMultipliedLeading(1f);
            
colData_0595415129.SetVisible(true);

                Cell cell_595415129 = new Cell(1, 1);
                var cell_595415129BackgroundColor = new DeviceRgb(0, 0, 0);
                var cell_595415129BackgroundColorOpacity = 0;
                
                cell_595415129.SetMinHeight(40 * pxToPtFactor);
                //cell_595415129.SetBorder(iText.Layout.Borders.Border.NO_BORDER);
                cell_595415129.SetBorderBottom(Border.NO_BORDER);
                cell_595415129.SetBorderTop(Border.NO_BORDER);
                cell_595415129.SetBorderRight(Border.NO_BORDER);
                cell_595415129.SetBorderLeft(Border.NO_BORDER);
                cell_595415129.SetBorderRadius(new BorderRadius(0f * pxToPtFactor));
                //cell_595415129.Add(colData_595415129);
                if (cell_595415129BackgroundColorOpacity == 1)
                    cell_595415129.SetBackgroundColor(cell_595415129BackgroundColor);
                else if (backgroundColorOpacity == 1)
                    cell_595415129.SetBackgroundColor(backgroundColor);
                cell_595415129.SetVerticalAlignment(iText.Layout.Properties.VerticalAlignment.TOP);
                cell_595415129.SetTextAlignment(iText.Layout.Properties.TextAlignment.LEFT);
                cell_595415129.SetPaddingBottom(0 * pxToPtFactor).SetPaddingLeft(0 * pxToPtFactor)
                .SetPaddingTop(0 * pxToPtFactor).SetPaddingRight(0 * pxToPtFactor);
                
                kasaraporudokumform_1715142869.AddCell(cell_595415129);

cell_595415129.Add(colData_0595415129);

                
            var colData_0151301383 = new Paragraph(item.DocumentNumber.ToFormattedString("", "", "") ?? "")
            .SetMarginBottom(0 * pxToPtFactor).SetMarginLeft(0 * pxToPtFactor)
            .SetMarginTop(0 * pxToPtFactor).SetMarginRight(0 * pxToPtFactor)
            .SetFontColor(new DeviceRgb(68, 68, 68), 1f)
            .SetBackgroundColor(new DeviceRgb(0, 0, 0), 0f)
            .SetFontSize(12 * pxToPtFactor)
            .SetFont(fontDictionary["poppins_regular"])
            .WithGlyphFallback(fontDictionary, "poppins_regular", () => cjkFallbackFont.Value)
            
            .SetParagraphWidthAndExtendHeightIfNotFit(document, 31.57f * pxToPtFactor, 20f * pxToPtFactor, true)
            .SetVisible(true)
            .SetVerticalAlignment(VerticalAlignment.TOP)
            .SetHorizontalAlignment(HorizontalAlignment.LEFT)
            .SetTextAlignment(TextAlignment.LEFT)
            .SetMultipliedLeading(1f);
            
colData_0151301383.SetVisible(true);

                Cell cell_151301383 = new Cell(1, 1);
                var cell_151301383BackgroundColor = new DeviceRgb(0, 0, 0);
                var cell_151301383BackgroundColorOpacity = 0;
                
                cell_151301383.SetMinHeight(40 * pxToPtFactor);
                //cell_151301383.SetBorder(iText.Layout.Borders.Border.NO_BORDER);
                cell_151301383.SetBorderBottom(Border.NO_BORDER);
                cell_151301383.SetBorderTop(Border.NO_BORDER);
                cell_151301383.SetBorderRight(Border.NO_BORDER);
                cell_151301383.SetBorderLeft(Border.NO_BORDER);
                cell_151301383.SetBorderRadius(new BorderRadius(0f * pxToPtFactor));
                //cell_151301383.Add(colData_151301383);
                if (cell_151301383BackgroundColorOpacity == 1)
                    cell_151301383.SetBackgroundColor(cell_151301383BackgroundColor);
                else if (backgroundColorOpacity == 1)
                    cell_151301383.SetBackgroundColor(backgroundColor);
                cell_151301383.SetVerticalAlignment(iText.Layout.Properties.VerticalAlignment.TOP);
                cell_151301383.SetTextAlignment(iText.Layout.Properties.TextAlignment.LEFT);
                cell_151301383.SetPaddingBottom(0 * pxToPtFactor).SetPaddingLeft(0 * pxToPtFactor)
                .SetPaddingTop(0 * pxToPtFactor).SetPaddingRight(0 * pxToPtFactor);
                
                kasaraporudokumform_1715142869.AddCell(cell_151301383);

cell_151301383.Add(colData_0151301383);

                
            var colData_0289997241 = new Paragraph(item.KasaHesabiAdi.ToFormattedString("", "", "") ?? "")
            .SetMarginBottom(0 * pxToPtFactor).SetMarginLeft(0 * pxToPtFactor)
            .SetMarginTop(0 * pxToPtFactor).SetMarginRight(0 * pxToPtFactor)
            .SetFontColor(new DeviceRgb(68, 68, 68), 1f)
            .SetBackgroundColor(new DeviceRgb(0, 0, 0), 0f)
            .SetFontSize(12 * pxToPtFactor)
            .SetFont(fontDictionary["poppins_regular"])
            .WithGlyphFallback(fontDictionary, "poppins_regular", () => cjkFallbackFont.Value)
            
            .SetParagraphWidthAndExtendHeightIfNotFit(document, 31.57f * pxToPtFactor, 20f * pxToPtFactor, true)
            .SetVisible(true)
            .SetVerticalAlignment(VerticalAlignment.TOP)
            .SetHorizontalAlignment(HorizontalAlignment.LEFT)
            .SetTextAlignment(TextAlignment.LEFT)
            .SetMultipliedLeading(1f);
            
colData_0289997241.SetVisible(true);

                Cell cell_289997241 = new Cell(1, 1);
                var cell_289997241BackgroundColor = new DeviceRgb(0, 0, 0);
                var cell_289997241BackgroundColorOpacity = 0;
                
                cell_289997241.SetMinHeight(40 * pxToPtFactor);
                //cell_289997241.SetBorder(iText.Layout.Borders.Border.NO_BORDER);
                cell_289997241.SetBorderBottom(Border.NO_BORDER);
                cell_289997241.SetBorderTop(Border.NO_BORDER);
                cell_289997241.SetBorderRight(Border.NO_BORDER);
                cell_289997241.SetBorderLeft(Border.NO_BORDER);
                cell_289997241.SetBorderRadius(new BorderRadius(0f * pxToPtFactor));
                //cell_289997241.Add(colData_289997241);
                if (cell_289997241BackgroundColorOpacity == 1)
                    cell_289997241.SetBackgroundColor(cell_289997241BackgroundColor);
                else if (backgroundColorOpacity == 1)
                    cell_289997241.SetBackgroundColor(backgroundColor);
                cell_289997241.SetVerticalAlignment(iText.Layout.Properties.VerticalAlignment.TOP);
                cell_289997241.SetTextAlignment(iText.Layout.Properties.TextAlignment.LEFT);
                cell_289997241.SetPaddingBottom(0 * pxToPtFactor).SetPaddingLeft(0 * pxToPtFactor)
                .SetPaddingTop(0 * pxToPtFactor).SetPaddingRight(0 * pxToPtFactor);
                
                kasaraporudokumform_1715142869.AddCell(cell_289997241);

cell_289997241.Add(colData_0289997241);

                
            var colData_01063604837 = new Paragraph(item.Loc_Amount.ToFormattedString("", "", "") ?? "")
            .SetMarginBottom(0 * pxToPtFactor).SetMarginLeft(0 * pxToPtFactor)
            .SetMarginTop(0 * pxToPtFactor).SetMarginRight(0 * pxToPtFactor)
            .SetFontColor(new DeviceRgb(68, 68, 68), 1f)
            .SetBackgroundColor(new DeviceRgb(0, 0, 0), 0f)
            .SetFontSize(12 * pxToPtFactor)
            .SetFont(fontDictionary["poppins_regular"])
            .WithGlyphFallback(fontDictionary, "poppins_regular", () => cjkFallbackFont.Value)
            
            .SetParagraphWidthAndExtendHeightIfNotFit(document, 31.57f * pxToPtFactor, 20f * pxToPtFactor, true)
            .SetVisible(true)
            .SetVerticalAlignment(VerticalAlignment.TOP)
            .SetHorizontalAlignment(HorizontalAlignment.LEFT)
            .SetTextAlignment(TextAlignment.LEFT)
            .SetMultipliedLeading(1f);
            
colData_01063604837.SetVisible(true);

                Cell cell_1063604837 = new Cell(1, 1);
                var cell_1063604837BackgroundColor = new DeviceRgb(0, 0, 0);
                var cell_1063604837BackgroundColorOpacity = 0;
                
                cell_1063604837.SetMinHeight(40 * pxToPtFactor);
                //cell_1063604837.SetBorder(iText.Layout.Borders.Border.NO_BORDER);
                cell_1063604837.SetBorderBottom(Border.NO_BORDER);
                cell_1063604837.SetBorderTop(Border.NO_BORDER);
                cell_1063604837.SetBorderRight(Border.NO_BORDER);
                cell_1063604837.SetBorderLeft(Border.NO_BORDER);
                cell_1063604837.SetBorderRadius(new BorderRadius(0f * pxToPtFactor));
                //cell_1063604837.Add(colData_1063604837);
                if (cell_1063604837BackgroundColorOpacity == 1)
                    cell_1063604837.SetBackgroundColor(cell_1063604837BackgroundColor);
                else if (backgroundColorOpacity == 1)
                    cell_1063604837.SetBackgroundColor(backgroundColor);
                cell_1063604837.SetVerticalAlignment(iText.Layout.Properties.VerticalAlignment.TOP);
                cell_1063604837.SetTextAlignment(iText.Layout.Properties.TextAlignment.LEFT);
                cell_1063604837.SetPaddingBottom(0 * pxToPtFactor).SetPaddingLeft(0 * pxToPtFactor)
                .SetPaddingTop(0 * pxToPtFactor).SetPaddingRight(0 * pxToPtFactor);
                
                kasaraporudokumform_1715142869.AddCell(cell_1063604837);

cell_1063604837.Add(colData_01063604837);

                
            var colData_0961420050 = new Paragraph(item.Doc_Amount.ToFormattedString("", "", "") ?? "")
            .SetMarginBottom(0 * pxToPtFactor).SetMarginLeft(0 * pxToPtFactor)
            .SetMarginTop(0 * pxToPtFactor).SetMarginRight(0 * pxToPtFactor)
            .SetFontColor(new DeviceRgb(68, 68, 68), 1f)
            .SetBackgroundColor(new DeviceRgb(0, 0, 0), 0f)
            .SetFontSize(12 * pxToPtFactor)
            .SetFont(fontDictionary["poppins_regular"])
            .WithGlyphFallback(fontDictionary, "poppins_regular", () => cjkFallbackFont.Value)
            
            .SetParagraphWidthAndExtendHeightIfNotFit(document, 31.57f * pxToPtFactor, 20f * pxToPtFactor, true)
            .SetVisible(true)
            .SetVerticalAlignment(VerticalAlignment.TOP)
            .SetHorizontalAlignment(HorizontalAlignment.LEFT)
            .SetTextAlignment(TextAlignment.LEFT)
            .SetMultipliedLeading(1f);
            
colData_0961420050.SetVisible(true);

                Cell cell_961420050 = new Cell(1, 1);
                var cell_961420050BackgroundColor = new DeviceRgb(0, 0, 0);
                var cell_961420050BackgroundColorOpacity = 0;
                
                cell_961420050.SetMinHeight(40 * pxToPtFactor);
                //cell_961420050.SetBorder(iText.Layout.Borders.Border.NO_BORDER);
                cell_961420050.SetBorderBottom(Border.NO_BORDER);
                cell_961420050.SetBorderTop(Border.NO_BORDER);
                cell_961420050.SetBorderRight(Border.NO_BORDER);
                cell_961420050.SetBorderLeft(Border.NO_BORDER);
                cell_961420050.SetBorderRadius(new BorderRadius(0f * pxToPtFactor));
                //cell_961420050.Add(colData_961420050);
                if (cell_961420050BackgroundColorOpacity == 1)
                    cell_961420050.SetBackgroundColor(cell_961420050BackgroundColor);
                else if (backgroundColorOpacity == 1)
                    cell_961420050.SetBackgroundColor(backgroundColor);
                cell_961420050.SetVerticalAlignment(iText.Layout.Properties.VerticalAlignment.TOP);
                cell_961420050.SetTextAlignment(iText.Layout.Properties.TextAlignment.LEFT);
                cell_961420050.SetPaddingBottom(0 * pxToPtFactor).SetPaddingLeft(0 * pxToPtFactor)
                .SetPaddingTop(0 * pxToPtFactor).SetPaddingRight(0 * pxToPtFactor);
                
                kasaraporudokumform_1715142869.AddCell(cell_961420050);

cell_961420050.Add(colData_0961420050);

              }



            kasaraporudokumform_1715142869.SetMarginLeft(10f * pxToPtFactor + 0f * pxToPtFactor);
            if (Math.Abs(2129.5f * pxToPtFactor) > 0) {{
               kasaraporudokumform_1715142869.SetMarginTop(Math.Abs(2129.5f * pxToPtFactor) + 0f * pxToPtFactor);
            }}
            kasaraporudokumform_651570007_cell.Add(kasaraporudokumform_1715142869);
        }

   
            kasaraporudokumform_651570007_cell.SetVisible(box_kasaraporudokumform_651570007.IsVisible());
            box_kasaraporudokumform_651570007.AddCell(kasaraporudokumform_651570007_cell);
            
            // Draw rounded rectangle with PdfCanvas for border-radius support
            {
                var boxX = 2f * pxToPtFactor;
                var boxAbsY = Math.Abs(2089.5f * pxToPtFactor);
                var boxPageRelY = boxAbsY - pageStartY;
                var boxY = ((currentPageHeight > 0 ? currentPageHeight : canvasHeight.Value) - (boxPageRelY + Math.Abs(218f * pxToPtFactor)));
                var boxW = 780f * pxToPtFactor;
                var boxH = 218f * pxToPtFactor;
                var boxRadiusTL = 6f * pxToPtFactor;
                var boxRadiusTR = 6f * pxToPtFactor;
                var boxRadiusBR = 6f * pxToPtFactor;
                var boxRadiusBL = 6f * pxToPtFactor;
                float kappaTL = boxRadiusTL * 0.5522848f;
                float kappaTR = boxRadiusTR * 0.5522848f;
                float kappaBR = boxRadiusBR * 0.5522848f;
                float kappaBL = boxRadiusBL * 0.5522848f;
                var currentPage = pdf.GetPage(pdf.GetNumberOfPages());
                var pdfCanvas = new PdfCanvas(currentPage);

                // Draw rounded background with alpha support
                pdfCanvas.SaveState();
                pdfCanvas.SetExtGState(new PdfExtGState().SetFillOpacity(1f));
                pdfCanvas.SetFillColor(new DeviceRgb(255, 255, 255));
                pdfCanvas.MoveTo(boxX + boxRadiusBL, boxY);
                pdfCanvas.LineTo(boxX + boxW - boxRadiusBR, boxY);
                if (boxRadiusBR > 0) pdfCanvas.CurveTo(boxX + boxW - boxRadiusBR + kappaBR, boxY, boxX + boxW, boxY + boxRadiusBR - kappaBR, boxX + boxW, boxY + boxRadiusBR);
                pdfCanvas.LineTo(boxX + boxW, boxY + boxH - boxRadiusTR);
                if (boxRadiusTR > 0) pdfCanvas.CurveTo(boxX + boxW, boxY + boxH - boxRadiusTR + kappaTR, boxX + boxW - boxRadiusTR + kappaTR, boxY + boxH, boxX + boxW - boxRadiusTR, boxY + boxH);
                pdfCanvas.LineTo(boxX + boxRadiusTL, boxY + boxH);
                if (boxRadiusTL > 0) pdfCanvas.CurveTo(boxX + boxRadiusTL - kappaTL, boxY + boxH, boxX, boxY + boxH - boxRadiusTL + kappaTL, boxX, boxY + boxH - boxRadiusTL);
                pdfCanvas.LineTo(boxX, boxY + boxRadiusBL);
                if (boxRadiusBL > 0) pdfCanvas.CurveTo(boxX, boxY + boxRadiusBL - kappaBL, boxX + boxRadiusBL - kappaBL, boxY, boxX + boxRadiusBL, boxY);
                pdfCanvas.ClosePath();
                pdfCanvas.Fill();
                pdfCanvas.RestoreState();

                // Draw individual border edges with per-side widths
                var rrBorderColor = new DeviceRgb(238, 242, 246);
                float rrBorderTop = 1f * pxToPtFactor;
                float rrBorderRight = 1f * pxToPtFactor;
                float rrBorderBottom = 1f * pxToPtFactor;
                float rrBorderLeft = 1f * pxToPtFactor;

                // Top border (uses TL and TR corners)
                if (rrBorderTop > 0)
                {
                    pdfCanvas.SaveState();
                    pdfCanvas.SetExtGState(new PdfExtGState().SetStrokeOpacity(1f));
                    pdfCanvas.SetStrokeColor(rrBorderColor);
                    pdfCanvas.SetLineWidth(rrBorderTop);
                    pdfCanvas.MoveTo(boxX + boxRadiusTL, boxY + boxH);
                    pdfCanvas.LineTo(boxX + boxW - boxRadiusTR, boxY + boxH);
                    if (boxRadiusTR > 0) pdfCanvas.CurveTo(boxX + boxW - boxRadiusTR + kappaTR, boxY + boxH, boxX + boxW, boxY + boxH - boxRadiusTR + kappaTR, boxX + boxW, boxY + boxH - boxRadiusTR);
                    pdfCanvas.Stroke();
                    pdfCanvas.RestoreState();
                }

                // Right border (uses TR and BR corners)
                if (rrBorderRight > 0)
                {
                    pdfCanvas.SaveState();
                    pdfCanvas.SetExtGState(new PdfExtGState().SetStrokeOpacity(1f));
                    pdfCanvas.SetStrokeColor(rrBorderColor);
                    pdfCanvas.SetLineWidth(rrBorderRight);
                    pdfCanvas.MoveTo(boxX + boxW, boxY + boxH - boxRadiusTR);
                    pdfCanvas.LineTo(boxX + boxW, boxY + boxRadiusBR);
                    if (boxRadiusBR > 0) pdfCanvas.CurveTo(boxX + boxW, boxY + boxRadiusBR - kappaBR, boxX + boxW - boxRadiusBR + kappaBR, boxY, boxX + boxW - boxRadiusBR, boxY);
                    pdfCanvas.Stroke();
                    pdfCanvas.RestoreState();
                }

                // Bottom border (uses BR and BL corners)
                if (rrBorderBottom > 0)
                {
                    pdfCanvas.SaveState();
                    pdfCanvas.SetExtGState(new PdfExtGState().SetStrokeOpacity(1f));
                    pdfCanvas.SetStrokeColor(rrBorderColor);
                    pdfCanvas.SetLineWidth(rrBorderBottom);
                    pdfCanvas.MoveTo(boxX + boxW - boxRadiusBR, boxY);
                    pdfCanvas.LineTo(boxX + boxRadiusBL, boxY);
                    if (boxRadiusBL > 0) pdfCanvas.CurveTo(boxX + boxRadiusBL - kappaBL, boxY, boxX, boxY + boxRadiusBL - kappaBL, boxX, boxY + boxRadiusBL);
                    pdfCanvas.Stroke();
                    pdfCanvas.RestoreState();
                }

                // Left border (uses BL and TL corners)
                if (rrBorderLeft > 0)
                {
                    pdfCanvas.SaveState();
                    pdfCanvas.SetExtGState(new PdfExtGState().SetStrokeOpacity(1f));
                    pdfCanvas.SetStrokeColor(rrBorderColor);
                    pdfCanvas.SetLineWidth(rrBorderLeft);
                    pdfCanvas.MoveTo(boxX, boxY + boxRadiusBL);
                    pdfCanvas.LineTo(boxX, boxY + boxH - boxRadiusTL);
                    if (boxRadiusTL > 0) pdfCanvas.CurveTo(boxX, boxY + boxH - boxRadiusTL + kappaTL, boxX + boxRadiusTL - kappaTL, boxY + boxH, boxX + boxRadiusTL, boxY + boxH);
                    pdfCanvas.Stroke();
                    pdfCanvas.RestoreState();
                }
            }
            document.Add(box_kasaraporudokumform_651570007);
            foreach (var deferredElem in box_kasaraporudokumform_651570007_deferredAdds) document.Add(deferredElem);
            }}


            //Box18
            Table box_kasaraporudokumform_1043939447 = new Table(1).SetWidth(780f * pxToPtFactor).SetHeight(218f * pxToPtFactor)
            .SetFontColor(new DeviceRgb(0, 0, 0), 1f)
            .SetFontSize(20 * pxToPtFactor)
            .SetVisible(true);
            if (box_kasaraporudokumform_1043939447.IsVisible()) {{
            var box_kasaraporudokumform_1043939447_pageLeftX = (double)(5f * pxToPtFactor) ;
            var box_kasaraporudokumform_1043939447_pageTopY = 0d;
            var box_kasaraporudokumform_1043939447_deferredAdds = new List<IBlockElement>();
            if (!false) {
            // Calculate page-relative Y position
            var box_kasaraporudokumform_1043939447_absoluteY = Math.Abs(2335.5f * pxToPtFactor);
            var box_kasaraporudokumform_1043939447_pageRelativeY = box_kasaraporudokumform_1043939447_absoluteY - pageStartY;
            int box_kasaraporudokumform_1043939447_targetPage = pdf.GetNumberOfPages();
            
            box_kasaraporudokumform_1043939447.SetFixedPosition(box_kasaraporudokumform_1043939447_targetPage, 5f * pxToPtFactor , ((currentPageHeight > 0 ? currentPageHeight : canvasHeight.Value) - (box_kasaraporudokumform_1043939447_pageRelativeY + Math.Abs(218f * pxToPtFactor))) , 780f * pxToPtFactor);
            box_kasaraporudokumform_1043939447_pageTopY = ((double)(currentPageHeight > 0 ? currentPageHeight : canvasHeight.Value) - box_kasaraporudokumform_1043939447_pageRelativeY) ;
            } else {
            box_kasaraporudokumform_1043939447.SetFixedPosition(5f * pxToPtFactor , ((currentPageHeight > 0 ? currentPageHeight : canvasHeight.Value) - (totalHeight + Math.Abs(2335.5f * pxToPtFactor) + Math.Abs(218f * pxToPtFactor))) , 780f * pxToPtFactor);
            box_kasaraporudokumform_1043939447_pageTopY = ((double)(currentPageHeight > 0 ? currentPageHeight : canvasHeight.Value) - (totalHeight + Math.Abs(2335.5f * pxToPtFactor))) ;
            }
            box_kasaraporudokumform_1043939447.SetBorder(Border.NO_BORDER);
            box_kasaraporudokumform_1043939447.SetBorderBottom(Border.NO_BORDER);
            box_kasaraporudokumform_1043939447.SetBorderTop(Border.NO_BORDER);
            box_kasaraporudokumform_1043939447.SetBorderRight(Border.NO_BORDER);
            box_kasaraporudokumform_1043939447.SetBorderLeft(Border.NO_BORDER);
            box_kasaraporudokumform_1043939447.SetBorderRadius(new BorderRadius(6f * pxToPtFactor));
            var heightOf_box_kasaraporudokumform_1043939447 = box_kasaraporudokumform_1043939447.GetHeight();
            Cell kasaraporudokumform_1043939447_cell = new Cell();
            kasaraporudokumform_1043939447_cell.SetBackgroundColor(new DeviceRgb(255, 255, 255), 0f);
            kasaraporudokumform_1043939447_cell.SetBorder(Border.NO_BORDER);
            
            // NOTE: Box always uses SetFixedPosition above (both branches), so it does not
            // contribute to flow. The legacy "totalHeight + height > canvasHeight" areaBreak
            // that lived here was reading totalHeight produced by previous flow elements
            // (e.g. multi-page ReportTables) and spuriously creating a new page + bumping
            // pageStartY, which broke pageRelativeY for every subsequent element. Removed.

            // No page breaks - using default canvas height behavior


            //Box19
            Table box_kasaraporudokumform_223133739 = new Table(1).SetWidth(790f * pxToPtFactor).SetHeight(30f * pxToPtFactor)
            .SetFontColor(new DeviceRgb(0, 0, 0), 1f)
            .SetFontSize(20 * pxToPtFactor)
            .SetVisible(true);
            if (box_kasaraporudokumform_223133739.IsVisible()) {{
            var box_kasaraporudokumform_223133739_pageLeftX = (double)(5f * pxToPtFactor) ;
            var box_kasaraporudokumform_223133739_pageTopY = 0d;
            var box_kasaraporudokumform_223133739_deferredAdds = new List<IBlockElement>();
            if (!false) {
            // Calculate page-relative Y position
            var box_kasaraporudokumform_223133739_absoluteY = Math.Abs(2335.5f * pxToPtFactor);
            var box_kasaraporudokumform_223133739_pageRelativeY = box_kasaraporudokumform_223133739_absoluteY - pageStartY;
            int box_kasaraporudokumform_223133739_targetPage = pdf.GetNumberOfPages();
            
            box_kasaraporudokumform_223133739.SetFixedPosition(box_kasaraporudokumform_223133739_targetPage, 5f * pxToPtFactor , ((currentPageHeight > 0 ? currentPageHeight : canvasHeight.Value) - (box_kasaraporudokumform_223133739_pageRelativeY + Math.Abs(30f * pxToPtFactor))) , 790f * pxToPtFactor);
            box_kasaraporudokumform_223133739_pageTopY = ((double)(currentPageHeight > 0 ? currentPageHeight : canvasHeight.Value) - box_kasaraporudokumform_223133739_pageRelativeY) ;
            } else {
            box_kasaraporudokumform_223133739.SetFixedPosition(5f * pxToPtFactor , ((currentPageHeight > 0 ? currentPageHeight : canvasHeight.Value) - (totalHeight + Math.Abs(2335.5f * pxToPtFactor) + Math.Abs(30f * pxToPtFactor))) , 790f * pxToPtFactor);
            box_kasaraporudokumform_223133739_pageTopY = ((double)(currentPageHeight > 0 ? currentPageHeight : canvasHeight.Value) - (totalHeight + Math.Abs(2335.5f * pxToPtFactor))) ;
            }
            box_kasaraporudokumform_223133739.SetBorder(Border.NO_BORDER);
            box_kasaraporudokumform_223133739.SetBorderBottom(Border.NO_BORDER);
            box_kasaraporudokumform_223133739.SetBorderTop(Border.NO_BORDER);
            box_kasaraporudokumform_223133739.SetBorderRight(Border.NO_BORDER);
            box_kasaraporudokumform_223133739.SetBorderLeft(Border.NO_BORDER);
            box_kasaraporudokumform_223133739.SetBorderRadius(new BorderRadius(6f * pxToPtFactor));
            var heightOf_box_kasaraporudokumform_223133739 = box_kasaraporudokumform_223133739.GetHeight();
            Cell kasaraporudokumform_223133739_cell = new Cell();
            kasaraporudokumform_223133739_cell.SetBackgroundColor(new DeviceRgb(114, 194, 64), 0f);
            kasaraporudokumform_223133739_cell.SetBorder(Border.NO_BORDER);
            
            // NOTE: Box always uses SetFixedPosition above (both branches), so it does not
            // contribute to flow. The legacy "totalHeight + height > canvasHeight" areaBreak
            // that lived here was reading totalHeight produced by previous flow elements
            // (e.g. multi-page ReportTables) and spuriously creating a new page + bumping
            // pageStartY, which broke pageRelativeY for every subsequent element. Removed.

            // No page breaks - using default canvas height behavior


            //Label17
            var label_kasaraporudokumform_342112443_effectiveWidth = 780f * pxToPtFactor > 0 ? 780f * pxToPtFactor : (canvasWidth.Value - (5f * pxToPtFactor));
            Paragraph label_kasaraporudokumform_342112443 = new Paragraph(@"Masraf Dökümü")
            .SetFontSize(15 * pxToPtFactor)
            .SetFont(fontDictionary["poppins_bold"])
            .WithGlyphFallback(fontDictionary, "poppins_bold", () => cjkFallbackFont.Value)
            .SetTextAlignment(TextAlignment.CENTER)
            
            .SetParagraphWidthAndExtendHeightIfNotFit(document, label_kasaraporudokumform_342112443_effectiveWidth, 20f * pxToPtFactor, false, false || false)
            .SetMultipliedLeading(0.875f);
            

            if (20f * pxToPtFactor == 0f)
            {
                label_kasaraporudokumform_342112443.SetMaxHeight((30f * pxToPtFactor) - Math.Abs(2335.5f * pxToPtFactor));
            }

            label_kasaraporudokumform_342112443.SetMarginBottom(0 * pxToPtFactor).SetMarginTop(0f);
            var label_kasaraporudokumform_342112443_paragraphHeight = label_kasaraporudokumform_342112443.GetHeightOfParagraph(document);
            var label_kasaraporudokumform_342112443_vAlignOffset = 0f;
            label_kasaraporudokumform_342112443_vAlignOffset = Math.Max(0f, (20f * pxToPtFactor - label_kasaraporudokumform_342112443_paragraphHeight) / 2f);
            label_kasaraporudokumform_342112443.SetMarginLeft(0 * pxToPtFactor)
            .SetMarginTop((0 * pxToPtFactor) + label_kasaraporudokumform_342112443_vAlignOffset).SetMarginRight(0 * pxToPtFactor)
            .SetFontColor(new DeviceRgb(255, 255, 255), 1f)
            .SetVisible(true);
            
            if (false)
			{
				Paragraph label_kasaraporudokumform_342112443_inside = new Paragraph(@"Masraf Dökümü")
			   .SetFontSize(15 * pxToPtFactor)
               .SetFont(fontDictionary["poppins_bold"])
			   .WithGlyphFallback(fontDictionary, "poppins_bold", () => cjkFallbackFont.Value)
			   .SetFontColor(new DeviceRgb(255, 255, 255), 1f)
			   
			   .SetRotationAngle(0);
				label_kasaraporudokumform_342112443.Add(label_kasaraporudokumform_342112443_inside);
			}
            var label_kasaraporudokumform_342112443_renderHeight = 20f * pxToPtFactor > 0 ? 20f * pxToPtFactor : label_kasaraporudokumform_342112443_paragraphHeight;
            // Actual div height accounts for paragraph margins that may expand the Div beyond MinHeight
            // paragraphHeight was measured with MarginTop=0, but actual MarginTop = paddingTop + vAlignOffset
            var label_kasaraporudokumform_342112443_divHeight = Math.Max(label_kasaraporudokumform_342112443_renderHeight, label_kasaraporudokumform_342112443_paragraphHeight + (0 * pxToPtFactor) + label_kasaraporudokumform_342112443_vAlignOffset);
            var div_label_kasaraporudokumform_342112443 = new Div();
            div_label_kasaraporudokumform_342112443.SetMinHeight(label_kasaraporudokumform_342112443_renderHeight);
            div_label_kasaraporudokumform_342112443.SetBackgroundColor(new DeviceRgb(0, 0, 0), 0f);
            div_label_kasaraporudokumform_342112443.SetBorderBottom(Border.NO_BORDER);
            div_label_kasaraporudokumform_342112443.SetBorderTop(Border.NO_BORDER);
            div_label_kasaraporudokumform_342112443.SetBorderRight(Border.NO_BORDER);
            div_label_kasaraporudokumform_342112443.SetBorderLeft(Border.NO_BORDER);
            div_label_kasaraporudokumform_342112443.SetBorderRadius(new BorderRadius(0f * pxToPtFactor));
            div_label_kasaraporudokumform_342112443.Add(label_kasaraporudokumform_342112443);
            
            // Label/Icon inside Box: use box page coordinates for absolute positioning
            var label_kasaraporudokumform_342112443_yPos = box_kasaraporudokumform_223133739_pageTopY - (0f * pxToPtFactor) - label_kasaraporudokumform_342112443_divHeight;
            div_label_kasaraporudokumform_342112443.SetFixedPosition((float)(box_kasaraporudokumform_223133739_pageLeftX + (0f * pxToPtFactor)), (float)label_kasaraporudokumform_342112443_yPos, label_kasaraporudokumform_342112443_effectiveWidth);
            div_label_kasaraporudokumform_342112443.SetVisible(true);
            box_kasaraporudokumform_223133739_deferredAdds.Add(div_label_kasaraporudokumform_342112443);

            kasaraporudokumform_223133739_cell.SetVisible(box_kasaraporudokumform_223133739.IsVisible());
            box_kasaraporudokumform_223133739.AddCell(kasaraporudokumform_223133739_cell);
            
            // Draw rounded rectangle with PdfCanvas for border-radius support
            {
                var boxX = 5f * pxToPtFactor;
                var boxAbsY = Math.Abs(2335.5f * pxToPtFactor);
                var boxPageRelY = boxAbsY - pageStartY;
                var boxY = ((currentPageHeight > 0 ? currentPageHeight : canvasHeight.Value) - (boxPageRelY + Math.Abs(30f * pxToPtFactor)));
                var boxW = 790f * pxToPtFactor;
                var boxH = 30f * pxToPtFactor;
                var boxRadiusTL = 6f * pxToPtFactor;
                var boxRadiusTR = 6f * pxToPtFactor;
                var boxRadiusBR = 6f * pxToPtFactor;
                var boxRadiusBL = 6f * pxToPtFactor;
                float kappaTL = boxRadiusTL * 0.5522848f;
                float kappaTR = boxRadiusTR * 0.5522848f;
                float kappaBR = boxRadiusBR * 0.5522848f;
                float kappaBL = boxRadiusBL * 0.5522848f;
                var currentPage = pdf.GetPage(pdf.GetNumberOfPages());
                var pdfCanvas = new PdfCanvas(currentPage);

                // Draw rounded background with alpha support
                pdfCanvas.SaveState();
                pdfCanvas.SetExtGState(new PdfExtGState().SetFillOpacity(1f));
                pdfCanvas.SetFillColor(new DeviceRgb(114, 194, 64));
                pdfCanvas.MoveTo(boxX + boxRadiusBL, boxY);
                pdfCanvas.LineTo(boxX + boxW - boxRadiusBR, boxY);
                if (boxRadiusBR > 0) pdfCanvas.CurveTo(boxX + boxW - boxRadiusBR + kappaBR, boxY, boxX + boxW, boxY + boxRadiusBR - kappaBR, boxX + boxW, boxY + boxRadiusBR);
                pdfCanvas.LineTo(boxX + boxW, boxY + boxH - boxRadiusTR);
                if (boxRadiusTR > 0) pdfCanvas.CurveTo(boxX + boxW, boxY + boxH - boxRadiusTR + kappaTR, boxX + boxW - boxRadiusTR + kappaTR, boxY + boxH, boxX + boxW - boxRadiusTR, boxY + boxH);
                pdfCanvas.LineTo(boxX + boxRadiusTL, boxY + boxH);
                if (boxRadiusTL > 0) pdfCanvas.CurveTo(boxX + boxRadiusTL - kappaTL, boxY + boxH, boxX, boxY + boxH - boxRadiusTL + kappaTL, boxX, boxY + boxH - boxRadiusTL);
                pdfCanvas.LineTo(boxX, boxY + boxRadiusBL);
                if (boxRadiusBL > 0) pdfCanvas.CurveTo(boxX, boxY + boxRadiusBL - kappaBL, boxX + boxRadiusBL - kappaBL, boxY, boxX + boxRadiusBL, boxY);
                pdfCanvas.ClosePath();
                pdfCanvas.Fill();
                pdfCanvas.RestoreState();

                // Draw individual border edges with per-side widths
                var rrBorderColor = new DeviceRgb(114, 194, 64);
                float rrBorderTop = 1f * pxToPtFactor;
                float rrBorderRight = 1f * pxToPtFactor;
                float rrBorderBottom = 1f * pxToPtFactor;
                float rrBorderLeft = 1f * pxToPtFactor;

                // Top border (uses TL and TR corners)
                if (rrBorderTop > 0)
                {
                    pdfCanvas.SaveState();
                    pdfCanvas.SetExtGState(new PdfExtGState().SetStrokeOpacity(1f));
                    pdfCanvas.SetStrokeColor(rrBorderColor);
                    pdfCanvas.SetLineWidth(rrBorderTop);
                    pdfCanvas.MoveTo(boxX + boxRadiusTL, boxY + boxH);
                    pdfCanvas.LineTo(boxX + boxW - boxRadiusTR, boxY + boxH);
                    if (boxRadiusTR > 0) pdfCanvas.CurveTo(boxX + boxW - boxRadiusTR + kappaTR, boxY + boxH, boxX + boxW, boxY + boxH - boxRadiusTR + kappaTR, boxX + boxW, boxY + boxH - boxRadiusTR);
                    pdfCanvas.Stroke();
                    pdfCanvas.RestoreState();
                }

                // Right border (uses TR and BR corners)
                if (rrBorderRight > 0)
                {
                    pdfCanvas.SaveState();
                    pdfCanvas.SetExtGState(new PdfExtGState().SetStrokeOpacity(1f));
                    pdfCanvas.SetStrokeColor(rrBorderColor);
                    pdfCanvas.SetLineWidth(rrBorderRight);
                    pdfCanvas.MoveTo(boxX + boxW, boxY + boxH - boxRadiusTR);
                    pdfCanvas.LineTo(boxX + boxW, boxY + boxRadiusBR);
                    if (boxRadiusBR > 0) pdfCanvas.CurveTo(boxX + boxW, boxY + boxRadiusBR - kappaBR, boxX + boxW - boxRadiusBR + kappaBR, boxY, boxX + boxW - boxRadiusBR, boxY);
                    pdfCanvas.Stroke();
                    pdfCanvas.RestoreState();
                }

                // Bottom border (uses BR and BL corners)
                if (rrBorderBottom > 0)
                {
                    pdfCanvas.SaveState();
                    pdfCanvas.SetExtGState(new PdfExtGState().SetStrokeOpacity(1f));
                    pdfCanvas.SetStrokeColor(rrBorderColor);
                    pdfCanvas.SetLineWidth(rrBorderBottom);
                    pdfCanvas.MoveTo(boxX + boxW - boxRadiusBR, boxY);
                    pdfCanvas.LineTo(boxX + boxRadiusBL, boxY);
                    if (boxRadiusBL > 0) pdfCanvas.CurveTo(boxX + boxRadiusBL - kappaBL, boxY, boxX, boxY + boxRadiusBL - kappaBL, boxX, boxY + boxRadiusBL);
                    pdfCanvas.Stroke();
                    pdfCanvas.RestoreState();
                }

                // Left border (uses BL and TL corners)
                if (rrBorderLeft > 0)
                {
                    pdfCanvas.SaveState();
                    pdfCanvas.SetExtGState(new PdfExtGState().SetStrokeOpacity(1f));
                    pdfCanvas.SetStrokeColor(rrBorderColor);
                    pdfCanvas.SetLineWidth(rrBorderLeft);
                    pdfCanvas.MoveTo(boxX, boxY + boxRadiusBL);
                    pdfCanvas.LineTo(boxX, boxY + boxH - boxRadiusTL);
                    if (boxRadiusTL > 0) pdfCanvas.CurveTo(boxX, boxY + boxH - boxRadiusTL + kappaTL, boxX + boxRadiusTL - kappaTL, boxY + boxH, boxX + boxRadiusTL, boxY + boxH);
                    pdfCanvas.Stroke();
                    pdfCanvas.RestoreState();
                }
            }
            box_kasaraporudokumform_1043939447_deferredAdds.Add(box_kasaraporudokumform_223133739);
            box_kasaraporudokumform_1043939447_deferredAdds.AddRange(box_kasaraporudokumform_223133739_deferredAdds);
            }}


            //ReportTable9
            
            var kasaraporudokumform_919442845IsVisible = true;
            var kasaraporudokumform_919442845BackgroundColor = new DeviceRgb(0, 0, 0);
            var kasaraporudokumform_919442845BackgroundColorOpacity = 0f;
            var widths_kasaraporudokumform_919442845 = new List<float>();
widths_kasaraporudokumform_919442845.Add(83.15f * pxToPtFactor);
widths_kasaraporudokumform_919442845.Add(147.4f * pxToPtFactor);
widths_kasaraporudokumform_919442845.Add(120.94f * pxToPtFactor);
widths_kasaraporudokumform_919442845.Add(151.18f * pxToPtFactor);
widths_kasaraporudokumform_919442845.Add(37.8f * pxToPtFactor);
widths_kasaraporudokumform_919442845.Add(94.49f * pxToPtFactor);
widths_kasaraporudokumform_919442845.Add(83.15f * pxToPtFactor);
var designWidth_kasaraporudokumform_919442845 = 718.11f * pxToPtFactor;
var tableWidth_kasaraporudokumform_919442845 = (widths_kasaraporudokumform_919442845.Sum() / designWidth_kasaraporudokumform_919442845) * (718.11f * pxToPtFactor);

            Table kasaraporudokumform_919442845 = new Table(widths_kasaraporudokumform_919442845.ToArray()).SetWidth(tableWidth_kasaraporudokumform_919442845)
            .SetBackgroundColor(kasaraporudokumform_919442845BackgroundColor, kasaraporudokumform_919442845BackgroundColorOpacity)
            .SetVisible(kasaraporudokumform_919442845IsVisible)
            .SetMarginBottom(0 * pxToPtFactor)
            .SetMarginLeft(0 * pxToPtFactor)
            .SetMarginTop(0 * pxToPtFactor)
            .SetMarginRight(0 * pxToPtFactor);
            
            kasaraporudokumform_919442845.SetBorderBottom(new SolidBorder(new DeviceRgb(218, 218, 218), 1 * pxToPtFactor, 1f));
            kasaraporudokumform_919442845.SetBorderTop(new SolidBorder(new DeviceRgb(218, 218, 218), 1 * pxToPtFactor, 1f));
            kasaraporudokumform_919442845.SetBorderRight(new SolidBorder(new DeviceRgb(218, 218, 218), 1 * pxToPtFactor, 1f));
            kasaraporudokumform_919442845.SetBorderLeft(new SolidBorder(new DeviceRgb(218, 218, 218), 1 * pxToPtFactor, 1f));
            kasaraporudokumform_919442845.SetBorderRadius(new BorderRadius(0f * pxToPtFactor));
            kasaraporudokumform_919442845.SetFixedLayout();
            Color kasaraporudokumform_919442845borderColor = new DeviceRgb(240, 240, 240);
            Border kasaraporudokumform_919442845leftBorder = new SolidBorder(kasaraporudokumform_919442845borderColor, 1 * pxToPtFactor);
            if (kasaraporudokumform_919442845IsVisible)
            {
                
            List<String> columnValueNames_kasaraporudokumform_919442845 = new List<String>() {"InvoiceNumberEP", "VendorDescription", "ItemDescription", "LineDescription", "Doc_CurrencyCode", "Doc_Amount", "Loc_Amount"};
            
            var kasaraporudokumform_919442845_ColumTitlesPropValue = "";
            var kasaraporudokumform_919442845_ColumnTitles = new List<string>();
            if(kasaraporudokumform_919442845_ColumTitlesPropValue != null) {
               kasaraporudokumform_919442845_ColumnTitles = kasaraporudokumform_919442845_ColumTitlesPropValue.ToString()?.Split(";", StringSplitOptions.RemoveEmptyEntries).ToList();
            }
        
            
            Cell cell_0 = new Cell(1, 1);
            //cell_0.SetBorder(iText.Layout.Borders.Border.NO_BORDER)
            cell_0.SetBackgroundColor(new DeviceRgb(0, 0, 0), 0f);
            cell_0.SetBorderBottom(Border.NO_BORDER);
            cell_0.SetBorderTop(Border.NO_BORDER);
            cell_0.SetBorderRight(Border.NO_BORDER);
            cell_0.SetBorderLeft(Border.NO_BORDER);
            cell_0.SetBorderRadius(new BorderRadius(0f * pxToPtFactor));
            
            
            cell_0.SetPaddingBottom(0 * pxToPtFactor).SetPaddingLeft(0 * pxToPtFactor)
            .SetPaddingTop(0 * pxToPtFactor).SetPaddingRight(0 * pxToPtFactor).SetFontSize(14 * pxToPtFactor)
            .SetFont(fontDictionary["poppins_regular"]).SetFontColor(new DeviceRgb(155, 155, 155), 1f)
            .SetTextAlignment(iText.Layout.Properties.TextAlignment.LEFT);
            var headerParagraph_0 = new Paragraph((kasaraporudokumform_919442845_ColumnTitles is { Count: >= (0 + 1) } ? kasaraporudokumform_919442845_ColumnTitles[0] : kasaraporudokumform_919442845_ColumnTitles.Any() ? "" : ("Evrak No".ConvertToType<String>())))
            
            .WithGlyphFallback(fontDictionary, "poppins_regular", () => cjkFallbackFont.Value);
            cell_0.Add(headerParagraph_0);
            
            cell_0.SetVisible(true);
            kasaraporudokumform_919442845.AddHeaderCell(cell_0);


            Cell cell_1 = new Cell(1, 1);
            //cell_1.SetBorder(iText.Layout.Borders.Border.NO_BORDER)
            cell_1.SetBackgroundColor(new DeviceRgb(0, 0, 0), 0f);
            cell_1.SetBorderBottom(Border.NO_BORDER);
            cell_1.SetBorderTop(Border.NO_BORDER);
            cell_1.SetBorderRight(Border.NO_BORDER);
            cell_1.SetBorderLeft(Border.NO_BORDER);
            cell_1.SetBorderRadius(new BorderRadius(0f * pxToPtFactor));
            
            if(true){cell_1.SetBorderLeft(kasaraporudokumform_919442845leftBorder);}
            cell_1.SetPaddingBottom(0 * pxToPtFactor).SetPaddingLeft(0 * pxToPtFactor)
            .SetPaddingTop(0 * pxToPtFactor).SetPaddingRight(0 * pxToPtFactor).SetFontSize(14 * pxToPtFactor)
            .SetFont(fontDictionary["poppins_regular"]).SetFontColor(new DeviceRgb(155, 155, 155), 1f)
            .SetTextAlignment(iText.Layout.Properties.TextAlignment.LEFT);
            var headerParagraph_1 = new Paragraph((kasaraporudokumform_919442845_ColumnTitles is { Count: >= (1 + 1) } ? kasaraporudokumform_919442845_ColumnTitles[1] : kasaraporudokumform_919442845_ColumnTitles.Any() ? "" : ("Cari Ünvanı".ConvertToType<String>())))
            
            .WithGlyphFallback(fontDictionary, "poppins_regular", () => cjkFallbackFont.Value);
            cell_1.Add(headerParagraph_1);
            
            cell_1.SetVisible(true);
            kasaraporudokumform_919442845.AddHeaderCell(cell_1);


            Cell cell_2 = new Cell(1, 1);
            //cell_2.SetBorder(iText.Layout.Borders.Border.NO_BORDER)
            cell_2.SetBackgroundColor(new DeviceRgb(0, 0, 0), 0f);
            cell_2.SetBorderBottom(Border.NO_BORDER);
            cell_2.SetBorderTop(Border.NO_BORDER);
            cell_2.SetBorderRight(Border.NO_BORDER);
            cell_2.SetBorderLeft(Border.NO_BORDER);
            cell_2.SetBorderRadius(new BorderRadius(0f * pxToPtFactor));
            
            if(true){cell_2.SetBorderLeft(kasaraporudokumform_919442845leftBorder);}
            cell_2.SetPaddingBottom(0 * pxToPtFactor).SetPaddingLeft(0 * pxToPtFactor)
            .SetPaddingTop(0 * pxToPtFactor).SetPaddingRight(0 * pxToPtFactor).SetFontSize(14 * pxToPtFactor)
            .SetFont(fontDictionary["poppins_regular"]).SetFontColor(new DeviceRgb(155, 155, 155), 1f)
            .SetTextAlignment(iText.Layout.Properties.TextAlignment.LEFT);
            var headerParagraph_2 = new Paragraph((kasaraporudokumform_919442845_ColumnTitles is { Count: >= (2 + 1) } ? kasaraporudokumform_919442845_ColumnTitles[2] : kasaraporudokumform_919442845_ColumnTitles.Any() ? "" : ("Masraf Adı".ConvertToType<String>())))
            
            .WithGlyphFallback(fontDictionary, "poppins_regular", () => cjkFallbackFont.Value);
            cell_2.Add(headerParagraph_2);
            
            cell_2.SetVisible(true);
            kasaraporudokumform_919442845.AddHeaderCell(cell_2);


            Cell cell_3 = new Cell(1, 1);
            //cell_3.SetBorder(iText.Layout.Borders.Border.NO_BORDER)
            cell_3.SetBackgroundColor(new DeviceRgb(0, 0, 0), 0f);
            cell_3.SetBorderBottom(Border.NO_BORDER);
            cell_3.SetBorderTop(Border.NO_BORDER);
            cell_3.SetBorderRight(Border.NO_BORDER);
            cell_3.SetBorderLeft(Border.NO_BORDER);
            cell_3.SetBorderRadius(new BorderRadius(0f * pxToPtFactor));
            
            if(true){cell_3.SetBorderLeft(kasaraporudokumform_919442845leftBorder);}
            cell_3.SetPaddingBottom(0 * pxToPtFactor).SetPaddingLeft(0 * pxToPtFactor)
            .SetPaddingTop(0 * pxToPtFactor).SetPaddingRight(0 * pxToPtFactor).SetFontSize(14 * pxToPtFactor)
            .SetFont(fontDictionary["poppins_regular"]).SetFontColor(new DeviceRgb(155, 155, 155), 1f)
            .SetTextAlignment(iText.Layout.Properties.TextAlignment.LEFT);
            var headerParagraph_3 = new Paragraph((kasaraporudokumform_919442845_ColumnTitles is { Count: >= (3 + 1) } ? kasaraporudokumform_919442845_ColumnTitles[3] : kasaraporudokumform_919442845_ColumnTitles.Any() ? "" : ("Açıklama".ConvertToType<String>())))
            
            .WithGlyphFallback(fontDictionary, "poppins_regular", () => cjkFallbackFont.Value);
            cell_3.Add(headerParagraph_3);
            
            cell_3.SetVisible(true);
            kasaraporudokumform_919442845.AddHeaderCell(cell_3);


            Cell cell_4 = new Cell(1, 1);
            //cell_4.SetBorder(iText.Layout.Borders.Border.NO_BORDER)
            cell_4.SetBackgroundColor(new DeviceRgb(0, 0, 0), 0f);
            cell_4.SetBorderBottom(Border.NO_BORDER);
            cell_4.SetBorderTop(Border.NO_BORDER);
            cell_4.SetBorderRight(Border.NO_BORDER);
            cell_4.SetBorderLeft(Border.NO_BORDER);
            cell_4.SetBorderRadius(new BorderRadius(0f * pxToPtFactor));
            
            if(true){cell_4.SetBorderLeft(kasaraporudokumform_919442845leftBorder);}
            cell_4.SetPaddingBottom(0 * pxToPtFactor).SetPaddingLeft(0 * pxToPtFactor)
            .SetPaddingTop(0 * pxToPtFactor).SetPaddingRight(0 * pxToPtFactor).SetFontSize(14 * pxToPtFactor)
            .SetFont(fontDictionary["poppins_regular"]).SetFontColor(new DeviceRgb(155, 155, 155), 1f)
            .SetTextAlignment(iText.Layout.Properties.TextAlignment.LEFT);
            var headerParagraph_4 = new Paragraph((kasaraporudokumform_919442845_ColumnTitles is { Count: >= (4 + 1) } ? kasaraporudokumform_919442845_ColumnTitles[4] : kasaraporudokumform_919442845_ColumnTitles.Any() ? "" : ("DVZ".ConvertToType<String>())))
            
            .WithGlyphFallback(fontDictionary, "poppins_regular", () => cjkFallbackFont.Value);
            cell_4.Add(headerParagraph_4);
            
            cell_4.SetVisible(true);
            kasaraporudokumform_919442845.AddHeaderCell(cell_4);


            Cell cell_5 = new Cell(1, 1);
            //cell_5.SetBorder(iText.Layout.Borders.Border.NO_BORDER)
            cell_5.SetBackgroundColor(new DeviceRgb(0, 0, 0), 0f);
            cell_5.SetBorderBottom(Border.NO_BORDER);
            cell_5.SetBorderTop(Border.NO_BORDER);
            cell_5.SetBorderRight(Border.NO_BORDER);
            cell_5.SetBorderLeft(Border.NO_BORDER);
            cell_5.SetBorderRadius(new BorderRadius(0f * pxToPtFactor));
            
            if(true){cell_5.SetBorderLeft(kasaraporudokumform_919442845leftBorder);}
            cell_5.SetPaddingBottom(0 * pxToPtFactor).SetPaddingLeft(0 * pxToPtFactor)
            .SetPaddingTop(0 * pxToPtFactor).SetPaddingRight(0 * pxToPtFactor).SetFontSize(14 * pxToPtFactor)
            .SetFont(fontDictionary["poppins_regular"]).SetFontColor(new DeviceRgb(155, 155, 155), 1f)
            .SetTextAlignment(iText.Layout.Properties.TextAlignment.LEFT);
            var headerParagraph_5 = new Paragraph((kasaraporudokumform_919442845_ColumnTitles is { Count: >= (5 + 1) } ? kasaraporudokumform_919442845_ColumnTitles[5] : kasaraporudokumform_919442845_ColumnTitles.Any() ? "" : ("Tutar".ConvertToType<String>())))
            
            .WithGlyphFallback(fontDictionary, "poppins_regular", () => cjkFallbackFont.Value);
            cell_5.Add(headerParagraph_5);
            
            cell_5.SetVisible(true);
            kasaraporudokumform_919442845.AddHeaderCell(cell_5);


            Cell cell_6 = new Cell(1, 1);
            //cell_6.SetBorder(iText.Layout.Borders.Border.NO_BORDER)
            cell_6.SetBackgroundColor(new DeviceRgb(0, 0, 0), 0f);
            cell_6.SetBorderBottom(Border.NO_BORDER);
            cell_6.SetBorderTop(Border.NO_BORDER);
            cell_6.SetBorderRight(Border.NO_BORDER);
            cell_6.SetBorderLeft(Border.NO_BORDER);
            cell_6.SetBorderRadius(new BorderRadius(0f * pxToPtFactor));
            
            if(true){cell_6.SetBorderLeft(kasaraporudokumform_919442845leftBorder);}
            cell_6.SetPaddingBottom(0 * pxToPtFactor).SetPaddingLeft(0 * pxToPtFactor)
            .SetPaddingTop(0 * pxToPtFactor).SetPaddingRight(0 * pxToPtFactor).SetFontSize(14 * pxToPtFactor)
            .SetFont(fontDictionary["poppins_regular"]).SetFontColor(new DeviceRgb(155, 155, 155), 1f)
            .SetTextAlignment(iText.Layout.Properties.TextAlignment.LEFT);
            var headerParagraph_6 = new Paragraph((kasaraporudokumform_919442845_ColumnTitles is { Count: >= (6 + 1) } ? kasaraporudokumform_919442845_ColumnTitles[6] : kasaraporudokumform_919442845_ColumnTitles.Any() ? "" : ("Tutar TRY".ConvertToType<String>())))
            
            .WithGlyphFallback(fontDictionary, "poppins_regular", () => cjkFallbackFont.Value);
            cell_6.Add(headerParagraph_6);
            
            cell_6.SetVisible(true);
            kasaraporudokumform_919442845.AddHeaderCell(cell_6);


            
            var rowBackgroundColor = new DeviceRgb(0, 0, 0);
            var rowOpacity = 0;
            var isStriped = false;
            Color stripedColor = new DeviceRgb(245, 247, 250);
            for(int i = 0; i < result.Kuika_Masraflar8.Count; i++)
              {
                  var item = result.Kuika_Masraflar8[i];
                  Color backgroundColor = new DeviceRgb(255, 255, 255);
                  float backgroundColorOpacity = 0f;

                  if (kasaraporudokumform_919442845BackgroundColorOpacity == 1) {{
                        backgroundColor = kasaraporudokumform_919442845BackgroundColor;
                        backgroundColorOpacity = 1f;
                  }}

                  if (rowOpacity == 1) {{
                        backgroundColor = rowBackgroundColor;
                        backgroundColorOpacity = 1f;
                  }}

                  if (isStriped && i % 2 != 0) {{
                        backgroundColor = stripedColor;
                        backgroundColorOpacity = 1f;
                  }}

                  
                
            var colData_01800714103 = new Paragraph(item.InvoiceNumberEP.ToFormattedString("", "", "") ?? "")
            .SetMarginBottom(0 * pxToPtFactor).SetMarginLeft(0 * pxToPtFactor)
            .SetMarginTop(0 * pxToPtFactor).SetMarginRight(0 * pxToPtFactor)
            .SetFontColor(new DeviceRgb(68, 68, 68), 1f)
            .SetBackgroundColor(new DeviceRgb(0, 0, 0), 0f)
            .SetFontSize(12 * pxToPtFactor)
            .SetFont(fontDictionary["poppins_regular"])
            .WithGlyphFallback(fontDictionary, "poppins_regular", () => cjkFallbackFont.Value)
            
            .SetParagraphWidthAndExtendHeightIfNotFit(document, 0f * pxToPtFactor, 20f * pxToPtFactor, true)
            .SetVisible(true)
            .SetVerticalAlignment(VerticalAlignment.TOP)
            .SetHorizontalAlignment(HorizontalAlignment.LEFT)
            .SetTextAlignment(TextAlignment.LEFT)
            .SetMultipliedLeading(1f);
            
colData_01800714103.SetVisible(true);

                Cell cell_1800714103 = new Cell(1, 1);
                var cell_1800714103BackgroundColor = new DeviceRgb(0, 0, 0);
                var cell_1800714103BackgroundColorOpacity = 0;
                
                cell_1800714103.SetMinHeight(40 * pxToPtFactor);
                //cell_1800714103.SetBorder(iText.Layout.Borders.Border.NO_BORDER);
                cell_1800714103.SetBorderBottom(Border.NO_BORDER);
                cell_1800714103.SetBorderTop(Border.NO_BORDER);
                cell_1800714103.SetBorderRight(Border.NO_BORDER);
                cell_1800714103.SetBorderLeft(Border.NO_BORDER);
                cell_1800714103.SetBorderRadius(new BorderRadius(0f * pxToPtFactor));
                //cell_1800714103.Add(colData_1800714103);
                if (cell_1800714103BackgroundColorOpacity == 1)
                    cell_1800714103.SetBackgroundColor(cell_1800714103BackgroundColor);
                else if (backgroundColorOpacity == 1)
                    cell_1800714103.SetBackgroundColor(backgroundColor);
                cell_1800714103.SetVerticalAlignment(iText.Layout.Properties.VerticalAlignment.TOP);
                cell_1800714103.SetTextAlignment(iText.Layout.Properties.TextAlignment.LEFT);
                cell_1800714103.SetPaddingBottom(0 * pxToPtFactor).SetPaddingLeft(0 * pxToPtFactor)
                .SetPaddingTop(0 * pxToPtFactor).SetPaddingRight(0 * pxToPtFactor);
                
                kasaraporudokumform_919442845.AddCell(cell_1800714103);

cell_1800714103.Add(colData_01800714103);

                
            var colData_0461099737 = new Paragraph(item.VendorDescription.ToFormattedString("", "", "") ?? "")
            .SetMarginBottom(0 * pxToPtFactor).SetMarginLeft(0 * pxToPtFactor)
            .SetMarginTop(0 * pxToPtFactor).SetMarginRight(0 * pxToPtFactor)
            .SetFontColor(new DeviceRgb(68, 68, 68), 1f)
            .SetBackgroundColor(new DeviceRgb(0, 0, 0), 0f)
            .SetFontSize(12 * pxToPtFactor)
            .SetFont(fontDictionary["poppins_regular"])
            .WithGlyphFallback(fontDictionary, "poppins_regular", () => cjkFallbackFont.Value)
            
            .SetParagraphWidthAndExtendHeightIfNotFit(document, 0f * pxToPtFactor, 20f * pxToPtFactor, true)
            .SetVisible(true)
            .SetVerticalAlignment(VerticalAlignment.TOP)
            .SetHorizontalAlignment(HorizontalAlignment.LEFT)
            .SetTextAlignment(TextAlignment.LEFT)
            .SetMultipliedLeading(1f);
            
colData_0461099737.SetVisible(true);

                Cell cell_461099737 = new Cell(1, 1);
                var cell_461099737BackgroundColor = new DeviceRgb(0, 0, 0);
                var cell_461099737BackgroundColorOpacity = 0;
                
                cell_461099737.SetMinHeight(40 * pxToPtFactor);
                //cell_461099737.SetBorder(iText.Layout.Borders.Border.NO_BORDER);
                cell_461099737.SetBorderBottom(Border.NO_BORDER);
                cell_461099737.SetBorderTop(Border.NO_BORDER);
                cell_461099737.SetBorderRight(Border.NO_BORDER);
                cell_461099737.SetBorderLeft(Border.NO_BORDER);
                cell_461099737.SetBorderRadius(new BorderRadius(0f * pxToPtFactor));
                //cell_461099737.Add(colData_461099737);
                if (cell_461099737BackgroundColorOpacity == 1)
                    cell_461099737.SetBackgroundColor(cell_461099737BackgroundColor);
                else if (backgroundColorOpacity == 1)
                    cell_461099737.SetBackgroundColor(backgroundColor);
                cell_461099737.SetVerticalAlignment(iText.Layout.Properties.VerticalAlignment.TOP);
                cell_461099737.SetTextAlignment(iText.Layout.Properties.TextAlignment.LEFT);
                cell_461099737.SetPaddingBottom(0 * pxToPtFactor).SetPaddingLeft(0 * pxToPtFactor)
                .SetPaddingTop(0 * pxToPtFactor).SetPaddingRight(0 * pxToPtFactor);
                
                kasaraporudokumform_919442845.AddCell(cell_461099737);

cell_461099737.Add(colData_0461099737);

                
            var colData_0527224063 = new Paragraph(item.ItemDescription.ToFormattedString("", "", "") ?? "")
            .SetMarginBottom(0 * pxToPtFactor).SetMarginLeft(0 * pxToPtFactor)
            .SetMarginTop(0 * pxToPtFactor).SetMarginRight(0 * pxToPtFactor)
            .SetFontColor(new DeviceRgb(68, 68, 68), 1f)
            .SetBackgroundColor(new DeviceRgb(0, 0, 0), 0f)
            .SetFontSize(12 * pxToPtFactor)
            .SetFont(fontDictionary["poppins_regular"])
            .WithGlyphFallback(fontDictionary, "poppins_regular", () => cjkFallbackFont.Value)
            
            .SetParagraphWidthAndExtendHeightIfNotFit(document, 0f * pxToPtFactor, 20f * pxToPtFactor, true)
            .SetVisible(true)
            .SetVerticalAlignment(VerticalAlignment.TOP)
            .SetHorizontalAlignment(HorizontalAlignment.LEFT)
            .SetTextAlignment(TextAlignment.LEFT)
            .SetMultipliedLeading(1f);
            
colData_0527224063.SetVisible(true);

                Cell cell_527224063 = new Cell(1, 1);
                var cell_527224063BackgroundColor = new DeviceRgb(0, 0, 0);
                var cell_527224063BackgroundColorOpacity = 0;
                
                cell_527224063.SetMinHeight(40 * pxToPtFactor);
                //cell_527224063.SetBorder(iText.Layout.Borders.Border.NO_BORDER);
                cell_527224063.SetBorderBottom(Border.NO_BORDER);
                cell_527224063.SetBorderTop(Border.NO_BORDER);
                cell_527224063.SetBorderRight(Border.NO_BORDER);
                cell_527224063.SetBorderLeft(Border.NO_BORDER);
                cell_527224063.SetBorderRadius(new BorderRadius(0f * pxToPtFactor));
                //cell_527224063.Add(colData_527224063);
                if (cell_527224063BackgroundColorOpacity == 1)
                    cell_527224063.SetBackgroundColor(cell_527224063BackgroundColor);
                else if (backgroundColorOpacity == 1)
                    cell_527224063.SetBackgroundColor(backgroundColor);
                cell_527224063.SetVerticalAlignment(iText.Layout.Properties.VerticalAlignment.TOP);
                cell_527224063.SetTextAlignment(iText.Layout.Properties.TextAlignment.LEFT);
                cell_527224063.SetPaddingBottom(0 * pxToPtFactor).SetPaddingLeft(0 * pxToPtFactor)
                .SetPaddingTop(0 * pxToPtFactor).SetPaddingRight(0 * pxToPtFactor);
                
                kasaraporudokumform_919442845.AddCell(cell_527224063);

cell_527224063.Add(colData_0527224063);

                
            var colData_0510116910 = new Paragraph(item.LineDescription.ToFormattedString("", "", "") ?? "")
            .SetMarginBottom(0 * pxToPtFactor).SetMarginLeft(0 * pxToPtFactor)
            .SetMarginTop(0 * pxToPtFactor).SetMarginRight(0 * pxToPtFactor)
            .SetFontColor(new DeviceRgb(68, 68, 68), 1f)
            .SetBackgroundColor(new DeviceRgb(0, 0, 0), 0f)
            .SetFontSize(12 * pxToPtFactor)
            .SetFont(fontDictionary["poppins_regular"])
            .WithGlyphFallback(fontDictionary, "poppins_regular", () => cjkFallbackFont.Value)
            
            .SetParagraphWidthAndExtendHeightIfNotFit(document, 24.19f * pxToPtFactor, 20f * pxToPtFactor, true)
            .SetVisible(true)
            .SetVerticalAlignment(VerticalAlignment.TOP)
            .SetHorizontalAlignment(HorizontalAlignment.LEFT)
            .SetTextAlignment(TextAlignment.LEFT)
            .SetMultipliedLeading(1f);
            
colData_0510116910.SetVisible(true);

                Cell cell_510116910 = new Cell(1, 1);
                var cell_510116910BackgroundColor = new DeviceRgb(0, 0, 0);
                var cell_510116910BackgroundColorOpacity = 0;
                
                cell_510116910.SetMinHeight(40 * pxToPtFactor);
                //cell_510116910.SetBorder(iText.Layout.Borders.Border.NO_BORDER);
                cell_510116910.SetBorderBottom(Border.NO_BORDER);
                cell_510116910.SetBorderTop(Border.NO_BORDER);
                cell_510116910.SetBorderRight(Border.NO_BORDER);
                cell_510116910.SetBorderLeft(Border.NO_BORDER);
                cell_510116910.SetBorderRadius(new BorderRadius(0f * pxToPtFactor));
                //cell_510116910.Add(colData_510116910);
                if (cell_510116910BackgroundColorOpacity == 1)
                    cell_510116910.SetBackgroundColor(cell_510116910BackgroundColor);
                else if (backgroundColorOpacity == 1)
                    cell_510116910.SetBackgroundColor(backgroundColor);
                cell_510116910.SetVerticalAlignment(iText.Layout.Properties.VerticalAlignment.TOP);
                cell_510116910.SetTextAlignment(iText.Layout.Properties.TextAlignment.LEFT);
                cell_510116910.SetPaddingBottom(0 * pxToPtFactor).SetPaddingLeft(0 * pxToPtFactor)
                .SetPaddingTop(0 * pxToPtFactor).SetPaddingRight(0 * pxToPtFactor);
                
                kasaraporudokumform_919442845.AddCell(cell_510116910);

cell_510116910.Add(colData_0510116910);

                
            var colData_0308370722 = new Paragraph(item.Doc_CurrencyCode.ToFormattedString("", "", "") ?? "")
            .SetMarginBottom(0 * pxToPtFactor).SetMarginLeft(0 * pxToPtFactor)
            .SetMarginTop(0 * pxToPtFactor).SetMarginRight(0 * pxToPtFactor)
            .SetFontColor(new DeviceRgb(68, 68, 68), 1f)
            .SetBackgroundColor(new DeviceRgb(0, 0, 0), 0f)
            .SetFontSize(12 * pxToPtFactor)
            .SetFont(fontDictionary["poppins_regular"])
            .WithGlyphFallback(fontDictionary, "poppins_regular", () => cjkFallbackFont.Value)
            
            .SetParagraphWidthAndExtendHeightIfNotFit(document, 30.23f * pxToPtFactor, 20f * pxToPtFactor, true)
            .SetVisible(true)
            .SetVerticalAlignment(VerticalAlignment.TOP)
            .SetHorizontalAlignment(HorizontalAlignment.LEFT)
            .SetTextAlignment(TextAlignment.LEFT)
            .SetMultipliedLeading(1f);
            
colData_0308370722.SetVisible(true);

                Cell cell_308370722 = new Cell(1, 1);
                var cell_308370722BackgroundColor = new DeviceRgb(0, 0, 0);
                var cell_308370722BackgroundColorOpacity = 0;
                
                cell_308370722.SetMinHeight(40 * pxToPtFactor);
                //cell_308370722.SetBorder(iText.Layout.Borders.Border.NO_BORDER);
                cell_308370722.SetBorderBottom(Border.NO_BORDER);
                cell_308370722.SetBorderTop(Border.NO_BORDER);
                cell_308370722.SetBorderRight(Border.NO_BORDER);
                cell_308370722.SetBorderLeft(Border.NO_BORDER);
                cell_308370722.SetBorderRadius(new BorderRadius(0f * pxToPtFactor));
                //cell_308370722.Add(colData_308370722);
                if (cell_308370722BackgroundColorOpacity == 1)
                    cell_308370722.SetBackgroundColor(cell_308370722BackgroundColor);
                else if (backgroundColorOpacity == 1)
                    cell_308370722.SetBackgroundColor(backgroundColor);
                cell_308370722.SetVerticalAlignment(iText.Layout.Properties.VerticalAlignment.TOP);
                cell_308370722.SetTextAlignment(iText.Layout.Properties.TextAlignment.LEFT);
                cell_308370722.SetPaddingBottom(0 * pxToPtFactor).SetPaddingLeft(0 * pxToPtFactor)
                .SetPaddingTop(0 * pxToPtFactor).SetPaddingRight(0 * pxToPtFactor);
                
                kasaraporudokumform_919442845.AddCell(cell_308370722);

cell_308370722.Add(colData_0308370722);

                
            var colData_0783770003 = new Paragraph(item.Doc_Amount.ToFormattedString("", "", "") ?? "")
            .SetMarginBottom(0 * pxToPtFactor).SetMarginLeft(0 * pxToPtFactor)
            .SetMarginTop(0 * pxToPtFactor).SetMarginRight(0 * pxToPtFactor)
            .SetFontColor(new DeviceRgb(68, 68, 68), 1f)
            .SetBackgroundColor(new DeviceRgb(0, 0, 0), 0f)
            .SetFontSize(12 * pxToPtFactor)
            .SetFont(fontDictionary["poppins_regular"])
            .WithGlyphFallback(fontDictionary, "poppins_regular", () => cjkFallbackFont.Value)
            
            .SetParagraphWidthAndExtendHeightIfNotFit(document, 31.57f * pxToPtFactor, 20f * pxToPtFactor, true)
            .SetVisible(true)
            .SetVerticalAlignment(VerticalAlignment.TOP)
            .SetHorizontalAlignment(HorizontalAlignment.LEFT)
            .SetTextAlignment(TextAlignment.LEFT)
            .SetMultipliedLeading(1f);
            
colData_0783770003.SetVisible(true);

                Cell cell_783770003 = new Cell(1, 1);
                var cell_783770003BackgroundColor = new DeviceRgb(0, 0, 0);
                var cell_783770003BackgroundColorOpacity = 0;
                
                cell_783770003.SetMinHeight(40 * pxToPtFactor);
                //cell_783770003.SetBorder(iText.Layout.Borders.Border.NO_BORDER);
                cell_783770003.SetBorderBottom(Border.NO_BORDER);
                cell_783770003.SetBorderTop(Border.NO_BORDER);
                cell_783770003.SetBorderRight(Border.NO_BORDER);
                cell_783770003.SetBorderLeft(Border.NO_BORDER);
                cell_783770003.SetBorderRadius(new BorderRadius(0f * pxToPtFactor));
                //cell_783770003.Add(colData_783770003);
                if (cell_783770003BackgroundColorOpacity == 1)
                    cell_783770003.SetBackgroundColor(cell_783770003BackgroundColor);
                else if (backgroundColorOpacity == 1)
                    cell_783770003.SetBackgroundColor(backgroundColor);
                cell_783770003.SetVerticalAlignment(iText.Layout.Properties.VerticalAlignment.TOP);
                cell_783770003.SetTextAlignment(iText.Layout.Properties.TextAlignment.LEFT);
                cell_783770003.SetPaddingBottom(0 * pxToPtFactor).SetPaddingLeft(0 * pxToPtFactor)
                .SetPaddingTop(0 * pxToPtFactor).SetPaddingRight(0 * pxToPtFactor);
                
                kasaraporudokumform_919442845.AddCell(cell_783770003);

cell_783770003.Add(colData_0783770003);

                
            var colData_0105788782 = new Paragraph(item.Loc_Amount.ToFormattedString("", "", "") ?? "")
            .SetMarginBottom(0 * pxToPtFactor).SetMarginLeft(0 * pxToPtFactor)
            .SetMarginTop(0 * pxToPtFactor).SetMarginRight(0 * pxToPtFactor)
            .SetFontColor(new DeviceRgb(68, 68, 68), 1f)
            .SetBackgroundColor(new DeviceRgb(0, 0, 0), 0f)
            .SetFontSize(12 * pxToPtFactor)
            .SetFont(fontDictionary["poppins_regular"])
            .WithGlyphFallback(fontDictionary, "poppins_regular", () => cjkFallbackFont.Value)
            
            .SetParagraphWidthAndExtendHeightIfNotFit(document, 31.57f * pxToPtFactor, 20f * pxToPtFactor, true)
            .SetVisible(true)
            .SetVerticalAlignment(VerticalAlignment.TOP)
            .SetHorizontalAlignment(HorizontalAlignment.LEFT)
            .SetTextAlignment(TextAlignment.LEFT)
            .SetMultipliedLeading(1f);
            
colData_0105788782.SetVisible(true);

                Cell cell_105788782 = new Cell(1, 1);
                var cell_105788782BackgroundColor = new DeviceRgb(0, 0, 0);
                var cell_105788782BackgroundColorOpacity = 0;
                
                cell_105788782.SetMinHeight(40 * pxToPtFactor);
                //cell_105788782.SetBorder(iText.Layout.Borders.Border.NO_BORDER);
                cell_105788782.SetBorderBottom(Border.NO_BORDER);
                cell_105788782.SetBorderTop(Border.NO_BORDER);
                cell_105788782.SetBorderRight(Border.NO_BORDER);
                cell_105788782.SetBorderLeft(Border.NO_BORDER);
                cell_105788782.SetBorderRadius(new BorderRadius(0f * pxToPtFactor));
                //cell_105788782.Add(colData_105788782);
                if (cell_105788782BackgroundColorOpacity == 1)
                    cell_105788782.SetBackgroundColor(cell_105788782BackgroundColor);
                else if (backgroundColorOpacity == 1)
                    cell_105788782.SetBackgroundColor(backgroundColor);
                cell_105788782.SetVerticalAlignment(iText.Layout.Properties.VerticalAlignment.TOP);
                cell_105788782.SetTextAlignment(iText.Layout.Properties.TextAlignment.LEFT);
                cell_105788782.SetPaddingBottom(0 * pxToPtFactor).SetPaddingLeft(0 * pxToPtFactor)
                .SetPaddingTop(0 * pxToPtFactor).SetPaddingRight(0 * pxToPtFactor);
                
                kasaraporudokumform_919442845.AddCell(cell_105788782);

cell_105788782.Add(colData_0105788782);

              }



            kasaraporudokumform_919442845.SetMarginLeft(10f * pxToPtFactor + 0f * pxToPtFactor);
            if (Math.Abs(2375.5f * pxToPtFactor) > 0) {{
               kasaraporudokumform_919442845.SetMarginTop(Math.Abs(2375.5f * pxToPtFactor) + 0f * pxToPtFactor);
            }}
            kasaraporudokumform_1043939447_cell.Add(kasaraporudokumform_919442845);
        }

   
            kasaraporudokumform_1043939447_cell.SetVisible(box_kasaraporudokumform_1043939447.IsVisible());
            box_kasaraporudokumform_1043939447.AddCell(kasaraporudokumform_1043939447_cell);
            
            // Draw rounded rectangle with PdfCanvas for border-radius support
            {
                var boxX = 5f * pxToPtFactor;
                var boxAbsY = Math.Abs(2335.5f * pxToPtFactor);
                var boxPageRelY = boxAbsY - pageStartY;
                var boxY = ((currentPageHeight > 0 ? currentPageHeight : canvasHeight.Value) - (boxPageRelY + Math.Abs(218f * pxToPtFactor)));
                var boxW = 780f * pxToPtFactor;
                var boxH = 218f * pxToPtFactor;
                var boxRadiusTL = 6f * pxToPtFactor;
                var boxRadiusTR = 6f * pxToPtFactor;
                var boxRadiusBR = 6f * pxToPtFactor;
                var boxRadiusBL = 6f * pxToPtFactor;
                float kappaTL = boxRadiusTL * 0.5522848f;
                float kappaTR = boxRadiusTR * 0.5522848f;
                float kappaBR = boxRadiusBR * 0.5522848f;
                float kappaBL = boxRadiusBL * 0.5522848f;
                var currentPage = pdf.GetPage(pdf.GetNumberOfPages());
                var pdfCanvas = new PdfCanvas(currentPage);

                // Draw rounded background with alpha support
                pdfCanvas.SaveState();
                pdfCanvas.SetExtGState(new PdfExtGState().SetFillOpacity(1f));
                pdfCanvas.SetFillColor(new DeviceRgb(255, 255, 255));
                pdfCanvas.MoveTo(boxX + boxRadiusBL, boxY);
                pdfCanvas.LineTo(boxX + boxW - boxRadiusBR, boxY);
                if (boxRadiusBR > 0) pdfCanvas.CurveTo(boxX + boxW - boxRadiusBR + kappaBR, boxY, boxX + boxW, boxY + boxRadiusBR - kappaBR, boxX + boxW, boxY + boxRadiusBR);
                pdfCanvas.LineTo(boxX + boxW, boxY + boxH - boxRadiusTR);
                if (boxRadiusTR > 0) pdfCanvas.CurveTo(boxX + boxW, boxY + boxH - boxRadiusTR + kappaTR, boxX + boxW - boxRadiusTR + kappaTR, boxY + boxH, boxX + boxW - boxRadiusTR, boxY + boxH);
                pdfCanvas.LineTo(boxX + boxRadiusTL, boxY + boxH);
                if (boxRadiusTL > 0) pdfCanvas.CurveTo(boxX + boxRadiusTL - kappaTL, boxY + boxH, boxX, boxY + boxH - boxRadiusTL + kappaTL, boxX, boxY + boxH - boxRadiusTL);
                pdfCanvas.LineTo(boxX, boxY + boxRadiusBL);
                if (boxRadiusBL > 0) pdfCanvas.CurveTo(boxX, boxY + boxRadiusBL - kappaBL, boxX + boxRadiusBL - kappaBL, boxY, boxX + boxRadiusBL, boxY);
                pdfCanvas.ClosePath();
                pdfCanvas.Fill();
                pdfCanvas.RestoreState();

                // Draw individual border edges with per-side widths
                var rrBorderColor = new DeviceRgb(238, 242, 246);
                float rrBorderTop = 1f * pxToPtFactor;
                float rrBorderRight = 1f * pxToPtFactor;
                float rrBorderBottom = 1f * pxToPtFactor;
                float rrBorderLeft = 1f * pxToPtFactor;

                // Top border (uses TL and TR corners)
                if (rrBorderTop > 0)
                {
                    pdfCanvas.SaveState();
                    pdfCanvas.SetExtGState(new PdfExtGState().SetStrokeOpacity(1f));
                    pdfCanvas.SetStrokeColor(rrBorderColor);
                    pdfCanvas.SetLineWidth(rrBorderTop);
                    pdfCanvas.MoveTo(boxX + boxRadiusTL, boxY + boxH);
                    pdfCanvas.LineTo(boxX + boxW - boxRadiusTR, boxY + boxH);
                    if (boxRadiusTR > 0) pdfCanvas.CurveTo(boxX + boxW - boxRadiusTR + kappaTR, boxY + boxH, boxX + boxW, boxY + boxH - boxRadiusTR + kappaTR, boxX + boxW, boxY + boxH - boxRadiusTR);
                    pdfCanvas.Stroke();
                    pdfCanvas.RestoreState();
                }

                // Right border (uses TR and BR corners)
                if (rrBorderRight > 0)
                {
                    pdfCanvas.SaveState();
                    pdfCanvas.SetExtGState(new PdfExtGState().SetStrokeOpacity(1f));
                    pdfCanvas.SetStrokeColor(rrBorderColor);
                    pdfCanvas.SetLineWidth(rrBorderRight);
                    pdfCanvas.MoveTo(boxX + boxW, boxY + boxH - boxRadiusTR);
                    pdfCanvas.LineTo(boxX + boxW, boxY + boxRadiusBR);
                    if (boxRadiusBR > 0) pdfCanvas.CurveTo(boxX + boxW, boxY + boxRadiusBR - kappaBR, boxX + boxW - boxRadiusBR + kappaBR, boxY, boxX + boxW - boxRadiusBR, boxY);
                    pdfCanvas.Stroke();
                    pdfCanvas.RestoreState();
                }

                // Bottom border (uses BR and BL corners)
                if (rrBorderBottom > 0)
                {
                    pdfCanvas.SaveState();
                    pdfCanvas.SetExtGState(new PdfExtGState().SetStrokeOpacity(1f));
                    pdfCanvas.SetStrokeColor(rrBorderColor);
                    pdfCanvas.SetLineWidth(rrBorderBottom);
                    pdfCanvas.MoveTo(boxX + boxW - boxRadiusBR, boxY);
                    pdfCanvas.LineTo(boxX + boxRadiusBL, boxY);
                    if (boxRadiusBL > 0) pdfCanvas.CurveTo(boxX + boxRadiusBL - kappaBL, boxY, boxX, boxY + boxRadiusBL - kappaBL, boxX, boxY + boxRadiusBL);
                    pdfCanvas.Stroke();
                    pdfCanvas.RestoreState();
                }

                // Left border (uses BL and TL corners)
                if (rrBorderLeft > 0)
                {
                    pdfCanvas.SaveState();
                    pdfCanvas.SetExtGState(new PdfExtGState().SetStrokeOpacity(1f));
                    pdfCanvas.SetStrokeColor(rrBorderColor);
                    pdfCanvas.SetLineWidth(rrBorderLeft);
                    pdfCanvas.MoveTo(boxX, boxY + boxRadiusBL);
                    pdfCanvas.LineTo(boxX, boxY + boxH - boxRadiusTL);
                    if (boxRadiusTL > 0) pdfCanvas.CurveTo(boxX, boxY + boxH - boxRadiusTL + kappaTL, boxX + boxRadiusTL - kappaTL, boxY + boxH, boxX + boxRadiusTL, boxY + boxH);
                    pdfCanvas.Stroke();
                    pdfCanvas.RestoreState();
                }
            }
            document.Add(box_kasaraporudokumform_1043939447);
            foreach (var deferredElem in box_kasaraporudokumform_1043939447_deferredAdds) document.Add(deferredElem);
            }}


            
            

            foreach (var totalPagesFillIn in totalPagesFillIns) { totalPagesFillIn(); }

            document.Close();

            // Runtime position log: only emitted when the codegen runs as the designated debug user.
            // For everyone else this is just a no-op placeholder so no log file is ever written.
            // After Close() the layout is finalized — each tracked element's renderer (if iText set
            // one during Add) has a fully computed OccupiedArea. We can safely query bbox here.
            // runtime position log disabled (not the configured debug user)

            return "data:application/pdf;base64," + Convert.ToBase64String(stream.ToArray());
        }

        private int GetCurrentPageNumber(PdfDocument pdf)
        {
            return pdf.GetNumberOfPages() > 0 ? pdf.GetNumberOfPages() : 1;
        }

        public BackgroundImage GetBackgroundImage(string guid, string imageFit)
        {
            var imageBase64 = File.ReadAllText($"Resources/{guid}");
            if (string.IsNullOrEmpty(imageBase64))
            {
                imageBase64 = emptyImageBase64;
            }
            ImageData imageData = ImageDataFactory.Create(Convert.FromBase64String(imageBase64.Split(',')[imageBase64.Split(',').Length - 1]));
            var background = new BackgroundImage.Builder().SetImage(new PdfImageXObject(imageData));

            switch (imageFit)
            {
                case "fit":
                    var fitSize = new BackgroundSize();
                    fitSize.SetBackgroundSizeToCover();
                    background.SetBackgroundSize(fitSize);
                    background.SetBackgroundRepeat(new BackgroundRepeat(BackgroundRepeat.BackgroundRepeatValue.NO_REPEAT));
                    break;
                case "repeat":
                default:
                    var repeatSize = new BackgroundSize();
                    repeatSize.SetBackgroundSizeToContain();
                    background.SetBackgroundSize(repeatSize);
                    background.SetBackgroundRepeat(new BackgroundRepeat(BackgroundRepeat.BackgroundRepeatValue.REPEAT));
                    break;
                case "stretch":
                    background.SetBackgroundRepeat(new BackgroundRepeat(BackgroundRepeat.BackgroundRepeatValue.ROUND));
                    break;
            }
            return background.Build();
        }

        private void IncreaseAndUpdateTotalHeight(float toBeAddedHeight, Document document)
        {
            totalHeight += toBeAddedHeight;
            var pageHeight = canvasHeight ?? PageSize.A4.GetHeight();
            if (totalHeight > pageHeight)
            {
                //document.GetRenderer().GetCurrentArea().GetBBox().GetHeight() is remaning page height
                totalHeight = pageHeight - document.GetRenderer().GetCurrentArea().GetBBox().GetHeight();
            }
        }

        // Writes the actual iText render position (post-layout OccupiedArea) of each tracked element.
        // iText 7 gotcha: IBlockElement.GetRenderer() *creates a fresh renderer on each call* if no
        // SetNextRenderer was used — meaning OccupiedArea is always null on the element directly. The
        // renderer iText actually used during layout lives in the document's render tree, so we
        // traverse document.GetRenderer() recursively and build a Map<IBlockElement, IRenderer> by
        // matching IRenderer.GetModelElement() back to our tracked references. Called AFTER
        // document.Close() so the entire layout (including deferred page-break/flow resolution) is
        // finalized — renderers carry their final OccupiedArea bboxes at that point.
        private void WritePositionRuntimeLog(string logFilePath, string screenName, Document document, float headerHeightPx)
        {
            try
            {
                // Runtime gate: only write the log when the generated app is bound to localhost. On
                // on-prem deployments the URLs are real domains or 0.0.0.0 — none of those match. This
                // is the second gate (the first is codegen-time IsPositionDebugUser); together they
                // ensure no log file is ever created outside the debug user's local dev machine even
                // if a debug-user-built binary somehow ships elsewhere.
                var aspNetCoreUrls = System.Environment.GetEnvironmentVariable("ASPNETCORE_URLS") ?? "";
                var isLocalhost = aspNetCoreUrls.IndexOf("localhost", System.StringComparison.OrdinalIgnoreCase) >= 0
                    || aspNetCoreUrls.Contains("127.0.0.1");
                if (!isLocalhost)
                {
                    return;
                }

                var pageHeight = canvasHeight ?? PageSize.A4.GetHeight();
                var sb = new System.Text.StringBuilder();
                sb.AppendLine("===== ACTUAL iText RENDER POSITIONS (runtime) =====");
                sb.AppendLine($"Screen: {screenName}");
                sb.AppendLine($"Page height (pts): {pageHeight}");
                sb.AppendLine($"Header height (px design): {headerHeightPx}  →  pts: {headerHeightPx * pxToPtFactor}");
                sb.AppendLine($"Tracked elements: {_trackedElements.Count}");
                sb.AppendLine();

                // Walk the document render tree and build a lookup from model element → its renderer.
                var rendererByModel = new System.Collections.Generic.Dictionary<object, iText.Layout.Renderer.IRenderer>();
                CollectRenderers(document.GetRenderer(), rendererByModel);
                sb.AppendLine($"Render-tree nodes mapped: {rendererByModel.Count}");
                sb.AppendLine();
                sb.AppendLine("Columns: id | x_pts | y_bottom_pts | w_pts | h_pts | y_top_pts (= pageH - y_bottom - h) | y_top_px (px design)");
                sb.AppendLine();

                foreach (var (id, elem) in _trackedElements)
                {
                    try
                    {
                        iText.Layout.Renderer.IRenderer renderer = null;
                        rendererByModel.TryGetValue(elem, out renderer);
                        var occupied = renderer?.GetOccupiedArea();
                        var bbox = occupied?.GetBBox();
                        if (bbox != null)
                        {
                            var yTopPts = pageHeight - bbox.GetY() - bbox.GetHeight();
                            var yTopPx = yTopPts / pxToPtFactor;
                            sb.AppendLine($"[{id}] x={bbox.GetX():F2} y_bottom={bbox.GetY():F2} w={bbox.GetWidth():F2} h={bbox.GetHeight():F2} y_top={yTopPts:F2}pts ({yTopPx:F2}px)");
                        }
                        else if (renderer == null)
                        {
                            sb.AppendLine($"[{id}] NO_RENDERER (not found in document render tree — possibly absolute-positioned outside doc flow, or never laid out)");
                        }
                        else
                        {
                            sb.AppendLine($"[{id}] NO_OCCUPIED_AREA (renderer found but layout area is null)");
                        }
                    }
                    catch (System.Exception ex)
                    {
                        sb.AppendLine($"[{id}] ERROR querying position: {ex.Message}");
                    }
                }
                sb.AppendLine("===== END ACTUAL POSITIONS =====");
                // Ensure target directory exists. Codegen passes a per-domain/per-project path under
                // RunConfig/Backend so the log sits beside the generated .cs files.
                var dir = System.IO.Path.GetDirectoryName(logFilePath);
                if (!string.IsNullOrEmpty(dir) && !System.IO.Directory.Exists(dir))
                {
                    System.IO.Directory.CreateDirectory(dir);
                }
                System.IO.File.WriteAllText(logFilePath, sb.ToString());
            }
            catch (System.Exception)
            {
                // swallow — runtime logging must not break PDF generation
            }
        }

        // Recursively walk the iText render tree, capturing the (modelElement → renderer) mapping
        // for each node that wraps an IBlockElement we may have tracked.
        private void CollectRenderers(iText.Layout.Renderer.IRenderer renderer, System.Collections.Generic.Dictionary<object, iText.Layout.Renderer.IRenderer> map)
        {
            if (renderer == null) return;
            try
            {
                var model = renderer.GetModelElement();
                if (model != null && !map.ContainsKey(model))
                {
                    map[model] = renderer;
                }
                var children = renderer.GetChildRenderers();
                if (children != null)
                {
                    foreach (var child in children)
                    {
                        CollectRenderers(child, map);
                    }
                }
            }
            catch (System.Exception)
            {
                // ignore broken nodes — best-effort traversal
            }
        }

        /// <summary>
        /// Event handler to render footer elements with absolute positioning on each page
        /// </summary>
        private class FooterElementsEventHandler : IEventHandler
        {
            private Document _document;
            private List<Div> _footerElements;
            private bool _lastPageOnly;
            private int _totalPages;
            private float _lastPageBottomOffset;
            private List<Action<int>> _currentPageUpdaters;

            public FooterElementsEventHandler(Document document, List<Div> footerElements, bool lastPageOnly, int totalPages, float lastPageBottomOffset = 0, List<Action<int>> currentPageUpdaters = null)
            {
                _document = document;
                _footerElements = footerElements;
                _lastPageOnly = lastPageOnly;
                _totalPages = totalPages;
                _lastPageBottomOffset = lastPageBottomOffset;
                _currentPageUpdaters = currentPageUpdaters;
            }

            public void HandleEvent(Event @event)
            {
                PdfDocumentEvent docEvent = (PdfDocumentEvent)@event;
                PdfDocument pdfDoc = docEvent.GetDocument();
                PdfPage page = docEvent.GetPage();
                int currentPage = pdfDoc.GetPageNumber(page);

                // If lastPageOnly is true, only render on the last page
                if (_lastPageOnly)
                {
                    if (_totalPages == 0 || currentPage != _totalPages)
                    {
                        return;
                    }
                }

                bool isLastPage = _totalPages > 0 && currentPage == _totalPages;
                float bottomOffset = isLastPage ? _lastPageBottomOffset : 0;

                RenderOnPage(pdfDoc, page, bottomOffset);
            }

            public void RenderOnLastPage(PdfDocument pdfDoc)
            {
                int lastPageNumber = pdfDoc.GetNumberOfPages();
                if (lastPageNumber > 0 && _footerElements.Count > 0)
                {
                    PdfPage lastPage = pdfDoc.GetPage(lastPageNumber);
                    RenderOnPage(pdfDoc, lastPage, 0);
                }
            }

            private void RenderOnPage(PdfDocument pdfDoc, PdfPage page, float bottomOffset)
            {
                // Refresh per-page dynamic content (e.g. current page number) before re-rendering.
                if (_currentPageUpdaters != null)
                {
                    int cp = pdfDoc.GetPageNumber(page);
                    foreach (var updater in _currentPageUpdaters) updater(cp);
                }
                Rectangle pageSize = page.GetPageSize();
                PdfCanvas pdfCanvas = new PdfCanvas(page.NewContentStreamAfter(), page.GetResources(), pdfDoc);
                Canvas canvas = new Canvas(pdfCanvas, pageSize);
                foreach (var element in _footerElements)
                {
                    // On last page, shift elements up by footer height
                    if (bottomOffset > 0)
                    {
                        element.SetMarginBottom(bottomOffset);
                    }
                    canvas.Add(element);
                }
                canvas.Close();
            }
        }

        /// <summary>
        /// Event handler to render header elements with absolute positioning on each page
        /// </summary>
        private class HeaderElementsEventHandler : IEventHandler
        {
            private Document _document;
            private List<(IBlockElement element, float xPos, float topOffset, float width, float elementHeight)> _headerElementsData;
            private bool _firstPageOnly;
            private float _headerHeight;
            private float _firstPageTopOffset;
            private List<Action<int>> _currentPageUpdaters;

            public HeaderElementsEventHandler(Document document, List<(IBlockElement element, float xPos, float topOffset, float width, float elementHeight)> headerElementsData, bool firstPageOnly, float headerHeight, float firstPageTopOffset = 0, List<Action<int>> currentPageUpdaters = null)
            {
                _document = document;
                _headerElementsData = headerElementsData;
                _firstPageOnly = firstPageOnly;
                _headerHeight = headerHeight;
                _firstPageTopOffset = firstPageTopOffset;
                _currentPageUpdaters = currentPageUpdaters;
            }

            public void HandleEvent(Event @event)
            {
                PdfDocumentEvent docEvent = (PdfDocumentEvent)@event;
                PdfDocument pdfDoc = docEvent.GetDocument();
                PdfPage page = docEvent.GetPage();
                int currentPage = pdfDoc.GetPageNumber(page);

                // If firstPageOnly is true, only render on the first page
                if (_firstPageOnly)
                {
                    if (currentPage != 1)
                    {
                        return;
                    }
                }

                // Refresh per-page dynamic content (e.g. current page number) before re-rendering
                // the header element. The element is re-laid-out fresh on every page via canvas.Add,
                // so mutating the paragraph text here makes each page show its own page number.
                if (_currentPageUpdaters != null)
                    foreach (var updater in _currentPageUpdaters) updater(currentPage);

                Rectangle pageSize = page.GetPageSize();
                float pageHeight = pageSize.GetHeight();
                float topOffset_extra = currentPage == 1 ? _firstPageTopOffset : 0;
                PdfCanvas pdfCanvas = new PdfCanvas(page.NewContentStreamAfter(), page.GetResources(), pdfDoc);
                Canvas canvas = new Canvas(pdfCanvas, pageSize);
                foreach (var (element, xPos, topOffset, width, elementHeight) in _headerElementsData)
                {
                    // Calculate Y position based on actual page height
                    // Y = pageHeight - topOffset - elementHeight (position from bottom)
                    // On first page, shift down by firstPageTopOffset (regular header height)
                    float yPos = pageHeight - topOffset - elementHeight - topOffset_extra;
                    // Create a new Div to wrap the element with correct positioning
                    var div = new Div();
                    div.Add(element);
                    div.SetFixedPosition(xPos, yPos, width);
                    canvas.Add(div);
                }
                canvas.Close();
            }
        }
    }
}


        