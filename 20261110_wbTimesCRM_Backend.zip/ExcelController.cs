
using System;
using Kuika.Common;
using Kuika.Common.Workflow;
using Kuika.Common.Bases;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Kuika.Common.Interfaces;
using Kuika.Common.Applications.Request;
using Kuika.Common.Applications.Enum;
using Kuika.Common.Enums;
using Kuika.Common.Attributes;
using Kuika.Common.Models;
using Kuika.Common.Helpers;

namespace Kuika.App.Controllers;

[ApiExplorerSettings(GroupName = "all")]
[Authorize]
[ApiController]
[Route("v1/api/[controller]")]
public class ExcelController : KControllerBase
{

    #region ..Constructors..

    public ExcelController() : base() { }

    #endregion

    #region ..Apis..

    [HttpPost("import")]
    public IActionResult ImportMappedExcel([FromBody] ImportMappedExcelRequest request)
    {
        var result = CsSystemFunctions.ImportMappedExcel(request);
        return Ok(result);
    }

    [HttpPost("import-file")]
    public IActionResult ImportMappedExcelFromFile([FromBody] ImportMappedExcelFileRequest request)
    {
        var result = CsSystemFunctions.ImportMappedExcelFromFile(request);
        return Ok(result);
    }

    [HttpPost("metadata")]
    public IActionResult GetExcelFileMetadata([FromBody] ExcelFileMetadataRequest request)
    {
        var result = CsSystemFunctions.GetExcelFileMetadata(request);
        return Ok(result);
    }

    #endregion
}
