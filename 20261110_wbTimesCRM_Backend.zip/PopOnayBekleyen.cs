
using Kuika.Common;
using Kuika.Common.Attributes;
using Kuika.Common.Bases;
using Kuika.Common.Enums;
using Kuika.Common.Accessors;
using Kuika.Common.Json;
using Kuika.Common.Classes;
using Kuika.Common.Exceptions;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Kuika.Common.Helpers;
using Kuika.Common.Settings;
using System.Collections.Generic;
using System;
using Kuika.Common.Extensions;
using System.Linq;
using Kuika.Common.Rest;
using WorkflowCore.Interface;
using Kuika.Common.Interfaces;
using Kuika.Common.Workflow;
using Kuika.Common.Workflow.Extensions;
using Kuika.Common.Workflow.DTOs;
using Kuika.Common.Models;
using Kuika.Common.Menu.Response;
using Kuika.Common.Entities;
using System.Reflection;
using Newtonsoft.Json.Linq;
using Newtonsoft.Json;
using System.Net.Http;
using Iyzipay.Model.V2.Subscription;
using Kuika.Common.Payments.Iyzico;
using Kuika.Common.Payments.Param;
using Iyzipay;
using Kuika.Common.Searching.DTOs;
using Kuika.Common.Helpers.Sap;
using Kuika.Common.Mcp;
using Kuika.Common.Vision.DTOs;
using Kuika.Common.Audit;
using Kuika.Common.Payments.Mobile;
using Kuika.ThirdPartyApisCollection;

namespace Kuika.Reslen_01.Api
{
    [ApiExplorerSettings(GroupName = "all")]
    [Authorize]
    [ApiController]
    [Route("v1/api/PopOnayBekleyen")]
    public class PopOnayBekleyen_Controller : KControllerBase
    {
        private string appName = "wbTimesCRM";
        private Guid appId = Guid.Parse("0e8ecb48-8c52-463c-5db5-08de3ec441b1");
        private static string screenName = "PopOnayBekleyen";
        private Guid screenId = Guid.Parse("32788d63-64e9-4d59-91b6-09aea7eba82c");
        private string connectionString { get { return Kuika.Common.KContext.GetConnectionString(); } }

        [HttpGet, Route("myroles")]
        public IActionResult GetMyRoles()
        {
            try
            {
                var result = KProviderManager.Authorization.GetMyRoles(appId, appName, screenId, screenName);
                return Ok(result);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new HttpExceptionDto() { Message = ex.Message, StackTrace = ex.StackTrace });
            }
        }


        [HttpPost, Route("PopOnayBekleyenPageInit")]
        public IActionResult PopOnayBekleyenPageInit(PopOnayBekleyenPageInit_Request request)
        {

            var result = new PopOnayBekleyenPageInit_Response();

            var prms_TM_GetLeadById_0 = new List<kSqlParameter>();
            prms_TM_GetLeadById_0.Add(new kSqlParameter() { Name = "LeadId", Value = request.LeadId_0 });
            using var auditTM_GetLeadById_0 = ActionAuditScope.Begin("132ad11a-cd28-4011-6335-cbe01b57f1cf", "TM_GetLeadById", applicationName: "wbTimesCRM", screenOrEndpointName: "PopOnayBekleyen");
            result.TM_GetLeadById = KPersister.Fetch(KContext.GetConnectionString(), @"SET NOCOUNT ON;

SELECT
    l.Id AS LeadId,

    l.CustomerId,
    l.ProductId,
    l.StoreId,
    l.SalesPersonKUserId,

    -- Eski kolon adı korunuyor


    -- Yeni referans kişi ID'si
    l.ReferencePersonID,

    l.ContactResourceId,
    l.ProcessID,

    ISNULL(NULLIF(LTRIM(RTRIM(l.LeadCode)), ''), '-') AS LeadCode,

    LTRIM(RTRIM(
        ISNULL(c.Name, '') +
        CASE
            WHEN c.LastName IS NOT NULL
                 AND LTRIM(RTRIM(c.LastName)) <> ''
            THEN ' ' + c.LastName
            ELSE ''
        END
    )) AS MusteriAdi,

    ISNULL(NULLIF(LTRIM(RTRIM(c.Tel)), ''), '-') AS TelefonNo,
    ISNULL(NULLIF(LTRIM(RTRIM(c.Email)), ''), '-') AS MusteriMail,
    ISNULL(NULLIF(LTRIM(RTRIM(c.Info)), ''), '-') AS MusteriInfo,
    ISNULL(NULLIF(LTRIM(RTRIM(c.CurrAccCode)), ''), '-') AS CurrAccCode,

    -- ============================================================
    -- REFERANS
    -- TMReference yerine TMReferencePerson kullanılıyor
    -- ÇIKTI KOLON İSİMLERİ DEĞİŞTİRİLMEDİ
    -- ============================================================

    LTRIM(RTRIM(
        ISNULL(r.Name, '') +
        CASE
            WHEN r.LastName IS NOT NULL
                 AND LTRIM(RTRIM(r.LastName)) <> ''
            THEN ' ' + r.LastName
            ELSE ''
        END
    )) AS ReferansAdi,

    -- TMReference.Note yerine TMReferencePerson.Info
    ISNULL(NULLIF(LTRIM(RTRIM(r.Info)), ''), '-') AS ReferansNote,

    -- TMReference.ReferenceNationalID yerine TMReferencePerson.NationalID
    ISNULL(NULLIF(LTRIM(RTRIM(r.NationalID)), ''), '-') AS ReferansKimlikNo,
       ISNULL(NULLIF(LTRIM(RTRIM(r.Tel)), ''), '-') AS ReferansTelefonNo,

    ISNULL(NULLIF(LTRIM(RTRIM(r.CurrAccCode)), ''), '-') AS ReferansCurrAccCode,

    ISNULL(c.IsShopping, 0) AS AlisverisYaptiMi,

    CASE
        WHEN c.CountryName IS NULL
             AND c.CityName IS NULL
            THEN '-'

        WHEN c.CityName IS NULL
            THEN c.CountryName

        WHEN c.CountryName IS NULL
            THEN c.CityName

        ELSE c.CountryName + ' / ' + c.CityName
    END AS Lokasyon,

    ISNULL(NULLIF(LTRIM(RTRIM(c.DistrictName)), ''), '-') AS Ilce,

    ISNULL(
        NULLIF(LTRIM(RTRIM(cr.ContactResourceName)), ''),
        '-'
    ) AS IletisimKaynagi,

    ISNULL(NULLIF(LTRIM(RTRIM(p.ProductName)), ''), '-') AS UrunAdi,
    ISNULL(NULLIF(LTRIM(RTRIM(p.Brand)), ''), '-') AS Brand,
    ISNULL(NULLIF(LTRIM(RTRIM(p.Referance)), ''), '-') AS Referans,
    ISNULL(NULLIF(LTRIM(RTRIM(p.Dial)), ''), '-') AS Kadran,
    ISNULL(NULLIF(LTRIM(RTRIM(p.Bracelet)), ''), '-') AS Bilezik,

    LTRIM(RTRIM(st.StoreCode)) AS StoreCode,
    LTRIM(RTRIM(p.ProductCode)) AS ProductCode,

    FORMAT(
        l.CreatedAt
        AT TIME ZONE 'UTC'
        AT TIME ZONE 'Turkey Standard Time',
        'dd MMMM yyyy',
        'tr-TR'
    ) AS TalepOlusturmaTarihi,

    YEAR(l.EstimatedDate) AS TerminYil,

    FORMAT(
        l.EstimatedDate,
        'MMMM',
        'tr-TR'
    ) AS TerminAy,

    MONTH(l.EstimatedDate) AS TerminAyValue,

    FORMAT(
        l.EstimatedDate,
        'yyyy MMMM',
        'tr-TR'
    ) AS TerminTarihi,

    ISNULL(
        NULLIF(LTRIM(RTRIM(ls.Name)), ''),
        '-'
    ) AS TakipDurumu,

    COALESCE(
        NULLIF(ns.Name, ''),
        '-'
    ) AS SonrakiAdim,

    FORMAT(
        LastProcessLog.CreatedAt
        AT TIME ZONE 'UTC'
        AT TIME ZONE 'Turkey Standard Time',
        'dd MMMM yyyy',
        'tr-TR'
    ) AS SonStatuDegisikligi,

    ISNULL(lp.Code, '-') AS ProcessCode,
    ISNULL(lp.Name, '-') AS ProcessName,

    ISNULL(
        NULLIF(LTRIM(RTRIM(st.StoreDesc)), ''),
        '-'
    ) AS Magaza,

    LTRIM(RTRIM(
        ISNULL(sp.FirstName, '') +
        CASE
            WHEN sp.LastName IS NOT NULL
                 AND LTRIM(RTRIM(sp.LastName)) <> ''
            THEN ' ' + sp.LastName
            ELSE ''
        END
    )) AS SatisPersoneli,

    ISNULL(
        NULLIF(LTRIM(RTRIM(l.LeadNote)), ''),
        '-'
    ) AS TalepNotu,

    ISNULL(
        NULLIF(LTRIM(RTRIM(l.LeadRejectedNote)), ''),
        '-'
    ) AS RedNotu,

    ISNULL(
        NULLIF(LTRIM(RTRIM(p.CategoryName)), ''),
        '-'
    ) AS CategoryName,

    ReservationInfo.RezerveEdenKisi,

    --------------------------------------------------
    -- APPROVED RESERVATION
    --------------------------------------------------

    ISNULL(
        ApprovedReservation.HasApproved,
        0
    ) AS HasApprovedReservation,

    ApprovedReservation.ReservationNote
        AS ApprovedReservationNote,

    CONVERT(
        VARCHAR(19),
        ApprovedReservation.ReservedAt,
        120
    ) AS ApprovedReservationDate,

    ISNULL(l.IsReserved, 0) AS IsReserved,

    --------------------------------------------------
    -- RESERVATION STATUS
    --------------------------------------------------

    ISNULL(
        ReservationStatus.RezervDurumu,
        N'Hayır'
    ) AS RezervDurumu


FROM tmscrq.TMLead l

LEFT JOIN tmscrq.TMCustomer c
    ON c.Id = l.CustomerId

-- ============================================================
-- YENİ REFERANS YAPISI
-- TMReference KULLANILMIYOR
-- ============================================================

LEFT JOIN tmscrq.TMReferencePerson r
    ON r.Id = l.ReferencePersonID

LEFT JOIN tmscrq.TMProduct p
    ON p.Id = l.ProductId

LEFT JOIN tmscrq.TMLeadStatu ls
    ON ls.Id = l.StatuId

LEFT JOIN tmscrq.TMStore st
    ON st.Id = l.StoreId

LEFT JOIN dbo.KUser sp
    ON sp.Id = l.SalesPersonKUserId

LEFT JOIN tmscrq.TMLeadProcess lp
    ON lp.Id = l.ProcessID

LEFT JOIN tmscrq.TMContactResource cr
    ON cr.Id = l.ContactResourceId

LEFT JOIN tmscrq.TMLeadNextStep ns
    ON ns.Id = l.NextStepId


-- ============================================================
-- SON PROCESS LOG
-- ============================================================

OUTER APPLY
(
    SELECT TOP 1
        pl.CreatedAt
    FROM tmscrq.TMLeadProcessLog pl
    WHERE pl.LeadId = l.Id
    ORDER BY pl.CreatedAt DESC
) LastProcessLog


-- ============================================================
-- REZERVE EDEN KİŞİ
-- ============================================================

OUTER APPLY
(
    SELECT TOP 1

        LTRIM(RTRIM(
            ISNULL(u2.FirstName, '') +
            ' ' +
            ISNULL(u2.LastName, '')
        )) AS RezerveEdenKisi

    FROM tmscrq.TMLeadReservation r

    LEFT JOIN dbo.KUser u2
        ON u2.Id = r.ReservedBy

    WHERE r.LeadId = l.Id
      AND r.IsActive = 1

    ORDER BY r.ReservedAt DESC

) ReservationInfo


-- ============================================================
-- APPROVED RESERVATION
-- ============================================================

OUTER APPLY
(
    SELECT TOP 1

        1 AS HasApproved,

        r.ReservationNote,

        r.ReservedAt

    FROM tmscrq.TMLeadReservation r

    WHERE r.LeadId = l.Id
      AND r.IsActive = 1
      AND r.IsApproved = 1

    ORDER BY r.ReservedAt DESC

) ApprovedReservation


-- ============================================================
-- REZERVASYON DURUMU
-- ============================================================

OUTER APPLY
(
    SELECT

        CASE

            WHEN EXISTS
            (
                SELECT 1
                FROM tmscrq.TMLeadReservation
                WHERE LeadId = l.Id
                  AND IsActive = 1
                  AND IsApproved = 1
            )
            THEN N'Evet'


            WHEN EXISTS
            (
                SELECT 1
                FROM tmscrq.TMLeadReservation
                WHERE LeadId = l.Id
                  AND IsActive = 1
                  AND ISNULL(IsApproved, 0) = 0
            )
            THEN N'Onay Bekliyor'


            ELSE N'Hayır'

        END AS RezervDurumu

) ReservationStatus


WHERE l.Id = @LeadId;", new string[] { "LeadId", "CustomerId", "ProductId", "StoreId", "SalesPersonKUserId", "ReferencePersonID", "ContactResourceId", "ProcessID", "LeadCode", "MusteriAdi", "TelefonNo", "MusteriMail", "MusteriInfo", "CurrAccCode", "ReferansAdi", "ReferansNote", "ReferansKimlikNo", "ReferansTelefonNo", "ReferansCurrAccCode", "AlisverisYaptiMi", "Lokasyon", "Ilce", "IletisimKaynagi", "UrunAdi", "Brand", "Referans", "Kadran", "Bilezik", "StoreCode", "ProductCode", "TalepOlusturmaTarihi", "TerminYil", "TerminAy", "TerminAyValue", "TerminTarihi", "TakipDurumu", "SonrakiAdim", "SonStatuDegisikligi", "ProcessCode", "ProcessName", "Magaza", "SatisPersoneli", "TalepNotu", "RedNotu", "CategoryName", "RezerveEdenKisi", "HasApprovedReservation", "ApprovedReservationNote", "ApprovedReservationDate", "IsReserved", "RezervDurumu" }, prms_TM_GetLeadById_0.ToArray());
            ;

            var prms_TMLeadSuggestion_1 = new List<kSqlParameter>();
            prms_TMLeadSuggestion_1.Add(new kSqlParameter() { Name = "LeadId", Value = request.LeadId_1 });
            using var auditTMLeadSuggestion_1 = ActionAuditScope.Begin("cd05c1ea-8f80-246d-06ba-5f2b3e2d0333", "TMLeadSuggestion", applicationName: "wbTimesCRM", screenOrEndpointName: "PopOnayBekleyen");
            result.TMLeadSuggestion = KPersister.Fetch(KContext.GetConnectionString(), @"SET NOCOUNT ON;

SELECT TOP 1

    CAST(1 AS BIT) AS HasTerminProposal,

    tep.Id AS ProposalId,

    -------------------------------------------------------
    -- Kartın en üstündeki yazı
    -------------------------------------------------------
    CASE MONTH(tep.ProposedDate)
        WHEN 1 THEN N'Ocak'
        WHEN 2 THEN N'Şubat'
        WHEN 3 THEN N'Mart'
        WHEN 4 THEN N'Nisan'
        WHEN 5 THEN N'Mayıs'
        WHEN 6 THEN N'Haziran'
        WHEN 7 THEN N'Temmuz'
        WHEN 8 THEN N'Ağustos'
        WHEN 9 THEN N'Eylül'
        WHEN 10 THEN N'Ekim'
        WHEN 11 THEN N'Kasım'
        WHEN 12 THEN N'Aralık'
    END
    + N' ' +
    CAST(YEAR(tep.ProposedDate) AS NVARCHAR(4))
    AS TerminOneriText,

    -------------------------------------------------------
    -- Dropdownlar
    -------------------------------------------------------
    YEAR(tep.ProposedDate) AS TerminYil,

    MONTH(tep.ProposedDate) AS TerminAy,

    CASE MONTH(tep.ProposedDate)
        WHEN 1 THEN N'Ocak'
        WHEN 2 THEN N'Şubat'
        WHEN 3 THEN N'Mart'
        WHEN 4 THEN N'Nisan'
        WHEN 5 THEN N'Mayıs'
        WHEN 6 THEN N'Haziran'
        WHEN 7 THEN N'Temmuz'
        WHEN 8 THEN N'Ağustos'
        WHEN 9 THEN N'Eylül'
        WHEN 10 THEN N'Ekim'
        WHEN 11 THEN N'Kasım'
        WHEN 12 THEN N'Aralık'
    END AS TerminAyAdi,

    -------------------------------------------------------
    -- Öneri Tarihi
    -------------------------------------------------------
    FORMAT(tep.ProposedAt,'dd MMMM yyyy','tr-TR') AS OneriTarihi,

    -------------------------------------------------------
    -- Öneri Notu
    -------------------------------------------------------
    ISNULL(tep.ProposalNote,'-') AS OneriNotu,

    -------------------------------------------------------
    -- Açıklama
    -------------------------------------------------------
    ISNULL(st.StoreDesc,'-')
        + N' Mağaza Müdürü '
        + LTRIM(RTRIM(ISNULL(ku.FirstName,'') + N' ' + ISNULL(ku.LastName,'')))
        + N' '
        + ISNULL(l.LeadCode,'-')
        + N' Kodlu Lead için Termin Tarihini '
        + CASE MONTH(tep.ProposedDate)
                WHEN 1 THEN N'Ocak'
                WHEN 2 THEN N'Şubat'
                WHEN 3 THEN N'Mart'
                WHEN 4 THEN N'Nisan'
                WHEN 5 THEN N'Mayıs'
                WHEN 6 THEN N'Haziran'
                WHEN 7 THEN N'Temmuz'
                WHEN 8 THEN N'Ağustos'
                WHEN 9 THEN N'Eylül'
                WHEN 10 THEN N'Ekim'
                WHEN 11 THEN N'Kasım'
                WHEN 12 THEN N'Aralık'
          END
        + N' '
        + CAST(YEAR(tep.ProposedDate) AS NVARCHAR(4))
        + N' olarak önerdi.'
        AS TerminOneriAciklama

FROM tmscrq.TMLeadEstimatedDateProposal tep

INNER JOIN tmscrq.TMLead l
    ON l.Id = tep.LeadId

LEFT JOIN tmscrq.TMStore st
    ON st.Id = l.StoreId

LEFT JOIN dbo.KUser ku
    ON ku.Id = tep.ProposedBy

WHERE tep.LeadId = @LeadId
  AND tep.IsActive = 1

ORDER BY
    tep.ProposedAt DESC,
    tep.CreatedAt DESC;", new string[] { "HasTerminProposal", "ProposalId", "TerminOneriText", "TerminYil", "TerminAy", "TerminAyAdi", "OneriTarihi", "OneriNotu", "TerminOneriAciklama" }, prms_TMLeadSuggestion_1.ToArray());
            ;

            var prms_TMApproveLeadAndReservation_2 = new List<kSqlParameter>();
            prms_TMApproveLeadAndReservation_2.Add(new kSqlParameter() { Name = "UserId", Value = Kuika.Common.KContext.CurrentUser?.Id });
            prms_TMApproveLeadAndReservation_2.Add(new kSqlParameter() { Name = "LeadId", Value = request.LeadId_2 });
            using var auditTMApproveLeadAndReservation_2 = ActionAuditScope.Begin("2d47d3e1-95fe-3d52-12cd-9a98ef4d2d35", "TMApproveLeadAndReservation", applicationName: "wbTimesCRM", screenOrEndpointName: "PopOnayBekleyen");
            result.TMApproveLeadAndReservation = KPersister.Fetch(KContext.GetConnectionString(), @"SET LANGUAGE Turkish;

--------------------------------------------------
-- PARAMETRELER
--------------------------------------------------
-- @UserId UNIQUEIDENTIFIER
-- @LeadId  UNIQUEIDENTIFIER   -- YENİ: Sadece bu lead için hesaplama yapılacak

--------------------------------------------------
-- GİRİŞ YAPAN KULLANICININ ROLLERİ
--------------------------------------------------
;WITH CurrentUserRoles AS
(
    SELECT
        CAST(
            CASE WHEN EXISTS
            (
                SELECT 1 FROM dbo.KUserRole ur
                INNER JOIN dbo.KRole r ON r.Id = ur.KRole_Id
                WHERE ur.KUser_Id = @UserId
                  AND ur.IsDeleted = 0 AND r.IsDeleted = 0
                  AND r.Name = 'TimesMagazaMuduru'
            ) THEN 1 ELSE 0 END
        AS BIT) AS IsMagazaMuduru,

        CAST(
            CASE WHEN EXISTS
            (
                SELECT 1 FROM dbo.KUserRole ur
                INNER JOIN dbo.KRole r ON r.Id = ur.KRole_Id
                WHERE ur.KUser_Id = @UserId
                  AND ur.IsDeleted = 0 AND r.IsDeleted = 0
                  AND r.Name = 'TimesYonetici'
            ) THEN 1 ELSE 0 END
        AS BIT) AS IsYonetici,

        CAST(
            CASE WHEN EXISTS
            (
                SELECT 1 FROM dbo.KUserRole ur
                INNER JOIN dbo.KRole r ON r.Id = ur.KRole_Id
                WHERE ur.KUser_Id = @UserId
                  AND ur.IsDeleted = 0 AND r.IsDeleted = 0
                  AND r.Name = 'TimesUstYonetici'
            ) THEN 1 ELSE 0 END
        AS BIT) AS IsUstYonetici,

        CAST(
            CASE WHEN EXISTS
            (
                SELECT 1 FROM dbo.KUserRole ur
                INNER JOIN dbo.KRole r ON r.Id = ur.KRole_Id
                WHERE ur.KUser_Id = @UserId
                  AND ur.IsDeleted = 0 AND r.IsDeleted = 0
                  AND r.Name = 'TimesSatisPersoneli'
            ) THEN 1 ELSE 0 END
        AS BIT) AS IsSatisPersoneli
),
--------------------------------------------------
-- KULLANICININ MAĞAZALARI
--------------------------------------------------
UserStores AS
(
    SELECT DISTINCT tu.StoreId
    FROM tmscrq.TMUser tu
    WHERE tu.KUserID = @UserId
      AND tu.StoreId IS NOT NULL
),
--------------------------------------------------
-- REZERVASYON ÖZETİ
--------------------------------------------------
ReservationSummary AS
(
    SELECT
        x.LeadId, x.Id AS ReservationId, x.ReservedBy, x.ReservedAt, x.ReservationNote,
        CASE WHEN x.IsApproved = 1 AND ISNULL(x.IsRejected,0)=0 THEN 1 ELSE 0 END AS HasApprovedReservation,
        CASE WHEN x.IsApproved = 0 AND ISNULL(x.IsRejected,0)=0 THEN 1 ELSE 0 END AS HasPendingReservation,
        CASE WHEN ISNULL(x.IsRejected,0)=0 THEN 1 ELSE 0 END AS HasActiveReservation
    FROM
    (
        SELECT *,
               ROW_NUMBER() OVER (PARTITION BY LeadId ORDER BY ReservedAt DESC, Id DESC) rn
        FROM tmscrq.TMLeadReservation WHERE IsActive = 1
    ) x
    WHERE x.rn = 1
),
--------------------------------------------------
-- LEAD ANA VERİ SETİ (SADECE @LeadId İÇİN FİLTRELENDİ)
--------------------------------------------------
LeadBase AS
(
    SELECT
        l.Id AS LeadId,
        l.LeadCode,
        l.CreatedAt,
        l.CreatedBy,
        l.EstimatedDate,
        l.IsReserved,
        l.ProductId,
        l.SalesPersonKUserId,
        l.StoreId AS LeadStoreId,
        COALESCE(l.StoreId, creatorUser.StoreId) AS EffectiveStoreId,
        l.ProcessId,
        l.StatuId,
        l.NextStepId,
        creatorUser.StoreId AS CreatedByStoreId,

        p.ProductCode, p.ProductName, p.Brand, p.CategoryName,
        p.Referance, p.Dial, p.Bracelet,

        c.CategoryNormalized,
        CASE
            WHEN c.CategoryNormalized IN ('KATEGORİ 1','KATEGORİ1') THEN 1
            WHEN c.CategoryNormalized IN ('KATEGORİ 2','KATEGORİ2') THEN 2
            WHEN c.CategoryNormalized IN ('KATEGORİ 3','KATEGORİ3') THEN 3
            ELSE 0
        END AS CategoryLevel,

        cu.Name AS CustomerName, cu.LastName AS CustomerLastName,
        cu.CityName, cu.DistrictName, cu.CountryName,
        cu.Info AS CustomerInfo, cu.IsShopping, cu.Tel, cu.Email,

        cr.ContactResourceName,
        ls.Name AS LeadStatusName,
        ns.Name AS NextStepName,

        lp.Name AS ProcessName, lp.Code AS ProcessCode, lp.StepOrder,

        sp.FirstName AS SalesPersonFirstName, sp.LastName AS SalesPersonLastName,

        st.StoreCode, st.StoreDesc AS StoreName,

        res.ReservationId, res.ReservedBy, res.ReservedAt, res.ReservationNote,
        res.HasApprovedReservation, res.HasPendingReservation, res.HasActiveReservation
    FROM tmscrq.TMLead l
    LEFT JOIN tmscrq.TMUser creatorUser ON creatorUser.KUserID = l.CreatedBy
    LEFT JOIN tmscrq.TMCustomer cu ON cu.Id = l.CustomerId
    LEFT JOIN tmscrq.TMProduct p ON p.Id = l.ProductId
    CROSS APPLY (
        SELECT CategoryNormalized = UPPER(LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(ISNULL(p.CategoryName,''),'-',' '),'  ',' '),'KATEGORI','KATEGORİ'))))
    ) c
    LEFT JOIN tmscrq.TMContactResource cr ON cr.Id = l.ContactResourceId
    LEFT JOIN tmscrq.TMLeadStatu ls ON ls.Id = l.StatuId
    LEFT JOIN tmscrq.TMLeadNextStep ns ON ns.Id = l.NextStepId
    LEFT JOIN tmscrq.TMLeadProcess lp ON lp.Id = l.ProcessId
    LEFT JOIN dbo.KUser sp ON sp.Id = l.SalesPersonKUserId
    LEFT JOIN tmscrq.TMStore st ON st.Id = COALESCE(l.StoreId, creatorUser.StoreId)
    LEFT JOIN ReservationSummary res ON res.LeadId = l.Id
    WHERE l.Id = @LeadId   -- <<<<< SADECE BELİRTİLEN LEAD
),
--------------------------------------------------
-- TOPLAM STOK (ilgili ürün ve mağaza için hesaplanır)
--------------------------------------------------
StockTotals AS
(
    SELECT
        st.Id AS StoreId, p.Id AS ProductId,
        CAST(SUM(CAST(ISNULL(i.InventoryQty1,0) AS DECIMAL(18,2))) AS DECIMAL(18,2)) AS ToplamStok
    FROM tmscrq.TMItemInventory i
    INNER JOIN tmscrq.TMProduct p ON UPPER(LTRIM(RTRIM(p.ProductCode))) = UPPER(LTRIM(RTRIM(i.ProductCode)))
    INNER JOIN tmscrq.TMStore st ON UPPER(LTRIM(RTRIM(st.StoreCode))) = UPPER(LTRIM(RTRIM(i.StoreCode)))
    -- Sadece LeadBase'deki ürün ve mağaza için stok getir
    INNER JOIN LeadBase lb ON lb.ProductId = p.Id AND lb.EffectiveStoreId = st.Id
    WHERE i.OfficeDescription IS NOT NULL AND i.OfficeDescription NOT IN (N'Teknik Servis Ofis')
    GROUP BY st.Id, p.Id
    HAVING SUM(ISNULL(i.InventoryQty1,0)) > 0
),
--------------------------------------------------
-- REZERVE EDİLMİŞ STOK
--------------------------------------------------
ReservedStockCounts AS
(
    SELECT lb.EffectiveStoreId AS StoreId, lb.ProductId, COUNT(DISTINCT lb.LeadId) AS RezerveStok
    FROM LeadBase lb
    WHERE lb.ProcessCode = 'DELIVERY_PENDING'
      AND lb.HasActiveReservation = 1 AND lb.HasApprovedReservation = 1
    GROUP BY lb.EffectiveStoreId, lb.ProductId
),
--------------------------------------------------
-- ONAY BEKLEYEN REZERV TALEPLERİ
--------------------------------------------------
PendingReservationCounts AS
(
    SELECT lb.EffectiveStoreId AS StoreId, lb.ProductId, COUNT(DISTINCT lb.LeadId) AS BekleyenRezervTalebi
    FROM LeadBase lb
    WHERE lb.ProcessCode = 'APPROVED' AND lb.HasPendingReservation = 1
    GROUP BY lb.EffectiveStoreId, lb.ProductId
),
--------------------------------------------------
-- STOK DURUMU
--------------------------------------------------
StockStatus AS
(
    SELECT
        stock.StoreId, stock.ProductId, stock.ToplamStok,
        ISNULL(reserved.RezerveStok,0) AS RezerveStok,
        ISNULL(pending.BekleyenRezervTalebi,0) AS BekleyenRezervTalebi,
        CASE WHEN stock.ToplamStok - ISNULL(reserved.RezerveStok,0) > 0
             THEN stock.ToplamStok - ISNULL(reserved.RezerveStok,0) ELSE 0 END AS MusaitStok,
        CASE WHEN stock.ToplamStok - ISNULL(reserved.RezerveStok,0) - ISNULL(pending.BekleyenRezervTalebi,0) > 0
             THEN stock.ToplamStok - ISNULL(reserved.RezerveStok,0) - ISNULL(pending.BekleyenRezervTalebi,0) ELSE 0 END AS YeniRezervTalebiKapasitesi
    FROM StockTotals stock
    LEFT JOIN ReservedStockCounts reserved ON reserved.StoreId = stock.StoreId AND reserved.ProductId = stock.ProductId
    LEFT JOIN PendingReservationCounts pending ON pending.StoreId = stock.StoreId AND pending.ProductId = stock.ProductId
),
--------------------------------------------------
-- FIFO SIRASI (APPROVED)
--------------------------------------------------
FifoQueue AS
(
    SELECT
        lb.LeadId,
        ROW_NUMBER() OVER (PARTITION BY lb.EffectiveStoreId, lb.ProductId ORDER BY lb.CreatedAt, lb.LeadCode, lb.LeadId) AS FifoSirasi
    FROM LeadBase lb
    WHERE lb.ProcessCode = 'APPROVED'
      AND lb.EffectiveStoreId IS NOT NULL AND lb.ProductId IS NOT NULL
      AND lb.CategoryLevel IN (1,2,3)
      AND NOT EXISTS (SELECT 1 FROM LeadBase lb2 WHERE lb2.LeadId = lb.LeadId AND lb2.ProcessCode = 'DELIVERY_PENDING')
      AND NOT EXISTS (SELECT 1 FROM tmscrq.TMLeadReservation r WHERE r.LeadId = lb.LeadId AND r.IsActive = 1 AND ISNULL(r.IsRejected,0)=1)
),
--------------------------------------------------
-- FIFO SIRASI (APPROVED + PENDING) – DEĞİŞTİRİLDİ
--------------------------------------------------
FifoQueueExtended AS
(
    SELECT
        lb.LeadId,
        ROW_NUMBER() OVER (PARTITION BY lb.EffectiveStoreId, lb.ProductId ORDER BY lb.CreatedAt, lb.LeadCode, lb.LeadId) AS FifoSirasi
    FROM LeadBase lb
    WHERE lb.ProcessCode IN ('APPROVED','PENDING')   -- DEĞİŞTİRİLDİ
      AND lb.EffectiveStoreId IS NOT NULL AND lb.ProductId IS NOT NULL
      AND lb.CategoryLevel IN (1,2,3)
      AND NOT EXISTS (SELECT 1 FROM LeadBase lb2 WHERE lb2.LeadId = lb.LeadId AND lb2.ProcessCode = 'DELIVERY_PENDING')
      AND NOT EXISTS (SELECT 1 FROM tmscrq.TMLeadReservation r WHERE r.LeadId = lb.LeadId AND r.IsActive = 1 AND ISNULL(r.IsRejected,0)=1)
),
--------------------------------------------------
-- CAN RESERVE (FIFO + STOK + REZERVASYON DURUMU) – DEĞİŞTİRİLDİ
--------------------------------------------------
CanReserveStatus AS
(
    SELECT
        lb.LeadId,
        CASE
            WHEN lb.ProcessCode NOT IN ('APPROVED', 'PENDING') THEN 0   -- DEĞİŞTİRİLDİ
            WHEN lb.HasActiveReservation = 1 THEN 0
            WHEN fifo_ext.FifoSirasi IS NULL THEN 0
            WHEN lb.CategoryLevel = 1
                 AND (ISNULL(stock.MusaitStok, 0) <= 0
                      OR fifo_ext.FifoSirasi > ISNULL(stock.MusaitStok, 0)) THEN 0
            WHEN lb.CategoryLevel IN (2, 3)
                 AND (ISNULL(stock.YeniRezervTalebiKapasitesi, 0) <= 0
                      OR fifo_ext.FifoSirasi > ISNULL(stock.YeniRezervTalebiKapasitesi, 0)) THEN 0
            ELSE 1
        END AS CanReserve
    FROM LeadBase lb
    LEFT JOIN FifoQueueExtended fifo_ext ON fifo_ext.LeadId = lb.LeadId
    LEFT JOIN StockStatus stock ON stock.StoreId = lb.EffectiveStoreId
                              AND stock.ProductId = lb.ProductId
    WHERE lb.ProcessCode IN ('APPROVED', 'PENDING')   -- DEĞİŞTİRİLDİ
),
--------------------------------------------------
-- GÖREV LİSTESİ (Yalnızca bu lead için)
--------------------------------------------------
TaskList AS
(
    -- 1. REZERVE ONAYI BEKLEYEN (PRIORITY 1)
    SELECT
        lb.LeadId, lb.ReservationId, 'ONAY_BEKLEYEN' AS TaskType, 'Rezerve Onayı Bekliyor' AS TaskTitle,
        1 AS TaskPriority, 'APPROVE_RESERVATION' AS ActionCode, 'Rezerv Talebini Onayla' AS ActionText,
        CASE WHEN (currentRole.IsYonetici=1 OR currentRole.IsUstYonetici=1) THEN 1
             WHEN currentRole.IsMagazaMuduru=1 AND lb.CategoryLevel=1 THEN 1 ELSE 0 END AS ApproveReservationShow,
        0 AS ReserveShow, 0 AS SendReservationRequestShow, 0 AS CompleteSaleShow,
        0 AS SetEstimateShow, 0 AS SendEstimateRequestShow,
        lb.CreatedAt AS TaskDate, lb.EffectiveStoreId AS TaskStoreId,
        NULL AS FifoSirasi, NULL AS ToplamStok, NULL AS RezerveStok, NULL AS BekleyenRezervTalebi,
        NULL AS MusaitStok, NULL AS YeniRezervTalebiKapasitesi,
        lb.ReservedBy, lb.ReservedAt, lb.ReservationNote,
        lb.HasApprovedReservation, lb.HasPendingReservation, lb.HasActiveReservation
    FROM LeadBase lb
    CROSS JOIN CurrentUserRoles currentRole
    WHERE lb.ProcessCode = 'APPROVED'
      AND lb.HasPendingReservation = 1 AND lb.ReservedBy IS NOT NULL AND lb.ReservedBy <> @UserId
      AND ( (currentRole.IsYonetici=1 OR currentRole.IsUstYonetici=1)
            OR (currentRole.IsMagazaMuduru=1 AND lb.CategoryLevel=1 AND EXISTS (SELECT 1 FROM UserStores us WHERE us.StoreId = lb.EffectiveStoreId)) )

    UNION ALL

    -- 2. TESLİM BEKLEYEN (PRIORITY 2)
    SELECT
        lb.LeadId, lb.ReservationId, 'TESLIM_BEKLEYEN' AS TaskType, 'Satışa Hazır' AS TaskTitle,
        2 AS TaskPriority, 'COMPLETE_SALE' AS ActionCode, 'Satışı Tamamla' AS ActionText,
        0,0,0,1,0,0,
        lb.CreatedAt, lb.EffectiveStoreId,
        NULL,NULL,NULL,NULL,NULL,NULL,
        lb.ReservedBy, lb.ReservedAt, lb.ReservationNote,
        lb.HasApprovedReservation, lb.HasPendingReservation, lb.HasActiveReservation
    FROM LeadBase lb
    CROSS JOIN CurrentUserRoles currentRole
    WHERE lb.ProcessCode = 'DELIVERY_PENDING'
      AND lb.HasActiveReservation = 1 AND lb.HasApprovedReservation = 1
      AND ( (currentRole.IsMagazaMuduru=1 AND EXISTS (SELECT 1 FROM UserStores us WHERE us.StoreId = lb.EffectiveStoreId))
            OR (currentRole.IsYonetici=1 OR currentRole.IsUstYonetici=1) )

    UNION ALL

    -- 3. TERMİN ÖNERİSİ BEKLEYEN (PRIORITY 3)
    SELECT
        lb.LeadId, lb.ReservationId, 'TERMIN_ONERI' AS TaskType,
        CASE WHEN (currentRole.IsYonetici=1 OR currentRole.IsUstYonetici=1) THEN 'Termin Ver ve Onayla'
             WHEN currentRole.IsMagazaMuduru=1 AND lb.CategoryLevel=1 THEN 'Termin Ver ve Onayla'
             WHEN currentRole.IsMagazaMuduru=1 AND lb.CategoryLevel IN (2,3) THEN 'Termin Önerisi Gönder'
             ELSE '-' END AS TaskTitle,
        3 AS TaskPriority,
        CASE WHEN (currentRole.IsYonetici=1 OR currentRole.IsUstYonetici=1) THEN 'SET_ESTIMATE'
             WHEN currentRole.IsMagazaMuduru=1 AND lb.CategoryLevel=1 THEN 'SET_ESTIMATE'
             WHEN currentRole.IsMagazaMuduru=1 AND lb.CategoryLevel IN (2,3) THEN 'SEND_ESTIMATE_REQUEST'
             ELSE NULL END AS ActionCode,
        CASE WHEN (currentRole.IsYonetici=1 OR currentRole.IsUstYonetici=1) THEN 'Termin Ver ve Onayla'
             WHEN currentRole.IsMagazaMuduru=1 AND lb.CategoryLevel=1 THEN 'Termin Ver ve Onayla'
             WHEN currentRole.IsMagazaMuduru=1 AND lb.CategoryLevel IN (2,3) THEN 'Termin Önerisi Gönder'
             ELSE '-' END AS ActionText,
        0,0,0,0,
        CASE WHEN (currentRole.IsYonetici=1 OR currentRole.IsUstYonetici=1) THEN 1
             WHEN currentRole.IsMagazaMuduru=1 AND lb.CategoryLevel=1 THEN 1 ELSE 0 END AS SetEstimateShow,
        CASE WHEN currentRole.IsMagazaMuduru=1 AND lb.CategoryLevel IN (2,3) THEN 1 ELSE 0 END AS SendEstimateRequestShow,
        lb.CreatedAt, lb.EffectiveStoreId,
        NULL,NULL,NULL,NULL,NULL,NULL,
        lb.ReservedBy, lb.ReservedAt, lb.ReservationNote,
        lb.HasApprovedReservation, lb.HasPendingReservation, lb.HasActiveReservation
    FROM LeadBase lb
    CROSS JOIN CurrentUserRoles currentRole
    WHERE lb.ProcessCode IN ('PENDING','TERMIN_PENDING')
      AND ( (currentRole.IsMagazaMuduru=1 AND EXISTS (SELECT 1 FROM UserStores us WHERE us.StoreId = lb.EffectiveStoreId))
            OR (currentRole.IsYonetici=1 OR currentRole.IsUstYonetici=1) )

    UNION ALL

    -- 4. REZERV BEKLEYEN (PRIORITY 4)
    SELECT
        lb.LeadId, lb.ReservationId, 'REZERV_BEKLEYEN' AS TaskType,
        CASE WHEN (currentRole.IsYonetici=1 OR currentRole.IsUstYonetici=1) THEN 'Rezerve Et'
             WHEN currentRole.IsMagazaMuduru=1 AND lb.CategoryLevel=1 THEN 'Rezerve Et'
             WHEN currentRole.IsMagazaMuduru=1 AND lb.CategoryLevel IN (2,3) THEN 'Rezerv Talebi Gönder'
             ELSE '-' END AS TaskTitle,
        4 AS TaskPriority,
        CASE WHEN (currentRole.IsYonetici=1 OR currentRole.IsUstYonetici=1) THEN 'DIRECT_RESERVE'
             WHEN currentRole.IsMagazaMuduru=1 AND lb.CategoryLevel=1 THEN 'DIRECT_RESERVE'
             WHEN currentRole.IsMagazaMuduru=1 AND lb.CategoryLevel IN (2,3) THEN 'SEND_RESERVATION_REQUEST'
             ELSE NULL END AS ActionCode,
        CASE WHEN (currentRole.IsYonetici=1 OR currentRole.IsUstYonetici=1) THEN 'Rezerve Et'
             WHEN currentRole.IsMagazaMuduru=1 AND lb.CategoryLevel=1 THEN 'Rezerve Et'
             WHEN currentRole.IsMagazaMuduru=1 AND lb.CategoryLevel IN (2,3) THEN 'Rezerv Talebi Gönder'
             ELSE '-' END AS ActionText,
        0 AS ApproveReservationShow,
        CASE WHEN (currentRole.IsYonetici=1 OR currentRole.IsUstYonetici=1) THEN 1
             WHEN currentRole.IsMagazaMuduru=1 AND lb.CategoryLevel=1 THEN 1 ELSE 0 END AS ReserveShow,
        CASE WHEN currentRole.IsMagazaMuduru=1 AND lb.CategoryLevel IN (2,3) THEN 1 ELSE 0 END AS SendReservationRequestShow,
        0,0,0,
        lb.CreatedAt, lb.EffectiveStoreId,
        fifo.FifoSirasi,
        ISNULL(stock.ToplamStok,0), ISNULL(stock.RezerveStok,0), ISNULL(stock.BekleyenRezervTalebi,0),
        ISNULL(stock.MusaitStok,0), ISNULL(stock.YeniRezervTalebiKapasitesi,0),
        lb.ReservedBy, lb.ReservedAt, lb.ReservationNote,
        lb.HasApprovedReservation, lb.HasPendingReservation, lb.HasActiveReservation
    FROM LeadBase lb
    CROSS JOIN CurrentUserRoles currentRole
    INNER JOIN FifoQueue fifo ON fifo.LeadId = lb.LeadId
    LEFT JOIN StockStatus stock ON stock.StoreId = lb.EffectiveStoreId AND stock.ProductId = lb.ProductId
    WHERE lb.ProcessCode = 'APPROVED'
      AND lb.CategoryLevel IN (1,2,3)
      AND lb.HasActiveReservation = 0
      AND (
           ( (currentRole.IsYonetici=1 OR currentRole.IsUstYonetici=1) 
             AND ISNULL(stock.MusaitStok,0) > 0 AND fifo.FifoSirasi <= ISNULL(stock.MusaitStok,0) )
           OR
           ( currentRole.IsMagazaMuduru = 1 AND lb.CategoryLevel = 1
             AND ISNULL(stock.MusaitStok,0) > 0 AND fifo.FifoSirasi <= ISNULL(stock.MusaitStok,0) )
           OR
           ( currentRole.IsMagazaMuduru = 1 AND lb.CategoryLevel IN (2,3)
             AND ISNULL(stock.YeniRezervTalebiKapasitesi,0) > 0 AND fifo.FifoSirasi <= ISNULL(stock.YeniRezervTalebiKapasitesi,0) )
      )
      AND ( (currentRole.IsMagazaMuduru = 1 AND EXISTS (SELECT 1 FROM UserStores us WHERE us.StoreId = lb.EffectiveStoreId))
            OR (currentRole.IsYonetici=1 OR currentRole.IsUstYonetici=1) )
)

--------------------------------------------------
-- ANA SORGU (Tek lead döner)
--------------------------------------------------
SELECT
    task.TaskType,
    task.TaskTitle,
    CASE WHEN currentRole.IsMagazaMuduru = 1 THEN 1 ELSE 0 END AS ShowTerminOnerisiFilter,
    task.TaskPriority,
    task.ActionCode,
    task.ActionText,

    task.ApproveReservationShow,
    task.ReserveShow,
    task.SendReservationRequestShow,
    task.CompleteSaleShow,
    task.SetEstimateShow,
    task.SendEstimateRequestShow,

CAST(
    CASE
        -- Sadece PENDING sürecinde çalışır – DEĞİŞTİRİLDİ
        WHEN lead.ProcessCode <> 'PENDING' THEN 0   -- DEĞİŞTİRİLDİ

        -- Aktif rezerv varsa tekrar gösterme
        WHEN lead.HasActiveReservation = 1 THEN 0

        -- FIFO / Stok uygun değilse gösterme
        WHEN ISNULL(crs.CanReserve,0) = 0 THEN 0

        -- Yönetici / Üst Yönetici
        WHEN currentRole.IsYonetici = 1
          OR currentRole.IsUstYonetici = 1
        THEN 1

        -- Mağaza Müdürü sadece Kategori 1
        WHEN currentRole.IsMagazaMuduru = 1
         AND lead.CategoryLevel = 1
        THEN 1

        ELSE 0
    END
AS BIT) AS ApproveAndReserveShow,

    task.ToplamStok, task.RezerveStok, task.BekleyenRezervTalebi,
    task.MusaitStok, task.YeniRezervTalebiKapasitesi, task.FifoSirasi,

    task.ReservationId, task.ReservedBy, task.ReservedAt,
    ISNULL(NULLIF(LTRIM(RTRIM(task.ReservationNote)),''),'-') AS ReservationNote,
    CASE
        WHEN task.HasApprovedReservation = 1 THEN N'Evet'
        WHEN task.HasPendingReservation = 1 THEN N'Onay Bekliyor'
        ELSE N'Hayır'
    END AS RezerveDurumu,

    lead.LeadId, lead.LeadCode AS LeadNumarasi, lead.ProductId,
    task.TaskStoreId AS StoreId, lead.SalesPersonKUserId, lead.CreatedBy,
    CONVERT(VARCHAR(10), lead.CreatedAt, 103) AS TalepTarihi,
    lead.CreatedAt, lead.IsReserved,

    ISNULL(NULLIF(LTRIM(RTRIM(lead.ProductName)),''),'-') AS ProductName,
    ISNULL(NULLIF(LTRIM(RTRIM(lead.ProductCode)),''),'-') AS ProductCode,
    ISNULL(NULLIF(LTRIM(RTRIM(lead.ProductCode)),''),'-') AS RefCode,
    ISNULL(NULLIF(LTRIM(RTRIM(lead.Brand)),''),'-') AS Brand,
    ISNULL(NULLIF(LTRIM(RTRIM(lead.CategoryName)),''),'-') AS CategoryName,
    lead.CategoryLevel,
    '-' AS CategoryCode,
    ISNULL(NULLIF(LTRIM(RTRIM(lead.Referance)),''),'-') AS Referans,
    ISNULL(NULLIF(LTRIM(RTRIM(lead.Dial)),''),'-') AS Kadran,
    ISNULL(NULLIF(LTRIM(RTRIM(lead.Bracelet)),''),'-') AS Bilezik,

    ISNULL(NULLIF(LTRIM(RTRIM(ISNULL(lead.CustomerName,'') + ' ' + ISNULL(lead.CustomerLastName,''))),''),'-') AS Musteri,
    ISNULL(NULLIF(LTRIM(RTRIM(lead.CityName)),''),'-') AS Lokasyon,
    ISNULL(NULLIF(LTRIM(RTRIM(lead.DistrictName)),''),'-') AS Ilce,
    ISNULL(NULLIF(LTRIM(RTRIM(lead.CountryName)),''),'-') AS Ulke,
    ISNULL(NULLIF(LTRIM(RTRIM(lead.CustomerInfo)),''),'-') AS MusteriInfo,
    CASE WHEN lead.IsShopping = 1 THEN N'Evet' WHEN lead.IsShopping = 0 THEN N'Hayır' ELSE '-' END AS AlisverisiVarMi,
    ISNULL(NULLIF(LTRIM(RTRIM(lead.Tel)),''),'-') AS IrtibatNumarasi,
    ISNULL(NULLIF(LTRIM(RTRIM(lead.Email)),''),'-') AS EmailAdresi,
    ISNULL(NULLIF(LTRIM(RTRIM(lead.ContactResourceName)),''),'-') AS IletisimKaynagi,

    ISNULL(NULLIF(LTRIM(RTRIM(ISNULL(lead.SalesPersonFirstName,'') + ' ' + ISNULL(lead.SalesPersonLastName,''))),''),'-') AS SatisDanismani,

    ISNULL(
        CASE WHEN lead.EstimatedDate IS NOT NULL
             THEN CAST(YEAR(lead.EstimatedDate) AS VARCHAR(4)) + ' ' + DATENAME(MONTH, lead.EstimatedDate)
             ELSE NULL END, '-') AS TerminTarihi,
    lead.EstimatedDate,

    ISNULL(NULLIF(LTRIM(RTRIM(lead.LeadStatusName)),''),'-') AS LeadDurumu,
    ISNULL(NULLIF(LTRIM(RTRIM(lead.NextStepName)),''),'-') AS SonrakiAdim,
    ISNULL(NULLIF(LTRIM(RTRIM(lead.ProcessName)),''),'-') AS ProcessName,
    ISNULL(NULLIF(LTRIM(RTRIM(lead.ProcessCode)),''),'-') AS ProcessCode,
    lead.StepOrder, lead.StepOrder AS SelectedStepOrder,

    ISNULL(NULLIF(LTRIM(RTRIM(lead.StoreCode)),''),'-') AS StoreCode,
    ISNULL(NULLIF(LTRIM(RTRIM(lead.StoreName)),''),'-') AS StoreName

FROM TaskList task
INNER JOIN LeadBase lead ON lead.LeadId = task.LeadId
CROSS JOIN CurrentUserRoles currentRole
LEFT JOIN CanReserveStatus crs ON crs.LeadId = lead.LeadId

OPTION (RECOMPILE);", new string[] { "TaskType", "TaskTitle", "ShowTerminOnerisiFilter", "TaskPriority", "ActionCode", "ActionText", "ApproveReservationShow", "ReserveShow", "SendReservationRequestShow", "CompleteSaleShow", "SetEstimateShow", "SendEstimateRequestShow", "ApproveAndReserveShow", "ToplamStok", "RezerveStok", "BekleyenRezervTalebi", "MusaitStok", "YeniRezervTalebiKapasitesi", "FifoSirasi", "ReservationId", "ReservedBy", "ReservedAt", "ReservationNote", "RezerveDurumu", "LeadId", "LeadNumarasi", "ProductId", "StoreId", "SalesPersonKUserId", "CreatedBy", "TalepTarihi", "CreatedAt", "IsReserved", "ProductName", "ProductCode", "RefCode", "Brand", "CategoryName", "CategoryLevel", "CategoryCode", "Referans", "Kadran", "Bilezik", "Musteri", "Lokasyon", "Ilce", "Ulke", "MusteriInfo", "AlisverisiVarMi", "IrtibatNumarasi", "EmailAdresi", "IletisimKaynagi", "SatisDanismani", "TerminTarihi", "EstimatedDate", "LeadDurumu", "SonrakiAdim", "ProcessName", "ProcessCode", "StepOrder", "SelectedStepOrder", "StoreCode", "StoreName" }, prms_TMApproveLeadAndReservation_2.ToArray());
            ;


            return Ok(result);
        }


        [HttpPost, Route("PopOnayBekleyenComponent_134041_onClick")]
        public IActionResult PopOnayBekleyenComponent_134041_onClick(PopOnayBekleyenComponent_134041_onClick_Request request)
        {

            var result = new PopOnayBekleyenComponent_134041_onClick_Response();

            var prms_TM_CreateLeadApproveLog_0 = new List<kSqlParameter>();
            prms_TM_CreateLeadApproveLog_0.Add(new kSqlParameter() { Name = "EstimatedYear", Value = request.EstimatedYear_0 });
            prms_TM_CreateLeadApproveLog_0.Add(new kSqlParameter() { Name = "EstimatedMonth", Value = request.EstimatedMonth_0 });
            prms_TM_CreateLeadApproveLog_0.Add(new kSqlParameter() { Name = "LeadId", Value = request.LeadId_0 });
            prms_TM_CreateLeadApproveLog_0.Add(new kSqlParameter() { Name = "UserId", Value = Kuika.Common.KContext.CurrentUser?.Id });
            using var auditTM_CreateLeadApproveLog_0 = ActionAuditScope.Begin("4cf879f8-0336-1172-0aa3-a78004b67958", "TM_CreateLeadApproveLog", applicationName: "wbTimesCRM", screenOrEndpointName: "PopOnayBekleyen");
            result.TM_CreateLeadApproveLog = KPersister.Fetch(KContext.GetConnectionString(), @"DECLARE @ApprovedProcessId UNIQUEIDENTIFIER;
DECLARE @ParsedDate DATETIME;

--------------------------------------------------
-- APPROVED process ID
--------------------------------------------------
SELECT @ApprovedProcessId = Id
FROM tmscrq.TMLeadProcess
WHERE Code = 'APPROVED';

IF @ApprovedProcessId IS NULL
    THROW 50002, 'APPROVED process tanımı bulunamadı.', 1;

--------------------------------------------------
-- 🔥 DATETIME OLUŞTUR
--------------------------------------------------
IF @EstimatedYear IS NOT NULL 
   AND @EstimatedMonth IS NOT NULL
BEGIN
    SET @ParsedDate = DATEFROMPARTS(
        @EstimatedYear,
        @EstimatedMonth,
        1
    );
END

--------------------------------------------------
-- 🔥 GEÇMİŞ TARİH KONTROLÜ
--------------------------------------------------
IF @EstimatedYear IS NOT NULL 
   AND @EstimatedMonth IS NOT NULL
BEGIN
    IF (
           @EstimatedYear < YEAR(GETDATE())
        OR (
               @EstimatedYear = YEAR(GETDATE()) 
           AND @EstimatedMonth < MONTH(GETDATE())
           )
    )
    BEGIN
        THROW 50004, N'Geçmiş bir aya termin verilemez.', 1;
    END

    IF @ParsedDate < DATEFROMPARTS(
                            YEAR(GETDATE()),
                            MONTH(GETDATE()),
                            1
                        )
    BEGIN
        THROW 50004, N'Geçmiş tarihe termin verilemez.', 1;
    END
END

--------------------------------------------------
-- TRY / CATCH
--------------------------------------------------
BEGIN TRY
    BEGIN TRAN;

    UPDATE l
    SET
        EstimatedDate = COALESCE(
                            l.EstimatedDate,
                            @ParsedDate
                        ),
        ProcessID = @ApprovedProcessId
    FROM tmscrq.TMLead l
    WHERE l.Id = @LeadId;

    IF @@ROWCOUNT = 0
        THROW 50001, 'Lead bulunamadı, onaylama yapılamadı.', 1;

    --------------------------------------------------
    -- 🔥 LOG
    --------------------------------------------------
    INSERT INTO tmscrq.TMLeadProcessLog
    (
        Id,
        LeadId,
        ProcessId,
        Note,
        CreatedBy,
        CreatedAt
    )
    VALUES
    (
        NEWID(),
        @LeadId,
        @ApprovedProcessId,
        CASE 
            WHEN @ParsedDate IS NOT NULL
                THEN N'Onaylandı. Termin Tarihi: '
                     + FORMAT(@ParsedDate, 'yyyy MMMM', 'tr-TR')
            ELSE N'Onaylandı'
        END,
        @UserId,
        SYSDATETIME()
    );

    --------------------------------------------------
    -- SUCCESS
    --------------------------------------------------
    SELECT 
        1 AS Success,
        N'Lead başarıyla onaylandı.' AS Message;

    COMMIT;

END TRY
BEGIN CATCH

    IF @@TRANCOUNT > 0
        ROLLBACK;

    THROW;

END CATCH;

--------------------------------------------------
-- LOG LİSTESİ
--------------------------------------------------
SELECT
    lpl.LeadId,
    p.Name AS ProcessName,
    lpl.Note,
    lpl.CreatedAt
FROM tmscrq.TMLeadProcessLog lpl

INNER JOIN tmscrq.TMLeadProcess p
    ON lpl.ProcessId = p.Id

WHERE lpl.LeadId = @LeadId

ORDER BY 
    p.StepOrder ASC,
    lpl.CreatedAt ASC;", new string[] { "Success", "Message" }, prms_TM_CreateLeadApproveLog_0.ToArray());
            ;


            return Ok(result);
        }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class PopOnayBekleyenPageInit_Request
    {
        public Guid? LeadId_0 { set; get; }
        public Guid? LeadId_1 { set; get; }
        public Guid? UserId_2 { set; get; }
        public Guid? LeadId_2 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class PopOnayBekleyenPageInit_Response
    {
        public KCommonEntityPage TM_GetLeadById { set; get; }

        public KCommonEntityPage TMLeadSuggestion { set; get; }

        public KCommonEntityPage TMApproveLeadAndReservation { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class PopOnayBekleyenComponent_134041_onClick_Request
    {
        public Int32? EstimatedYear_0 { set; get; }
        public Int32? EstimatedMonth_0 { set; get; }
        public Guid? LeadId_0 { set; get; }
        public Guid? UserId_0 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class PopOnayBekleyenComponent_134041_onClick_Response
    {
        public KCommonEntityPage TM_CreateLeadApproveLog { set; get; }

    }
}
