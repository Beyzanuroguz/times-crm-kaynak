
using System;
using System.Linq;
using Kuika.Common;
using Kuika.Common.Bases;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Kuika.Common.Interfaces;
using Kuika.Common.Models;
using Kuika.Common.Rest;
using Kuika.Common.Enums;
using Kuika.Common.Attributes;
using Kuika.Common.Extensions;
using Kuika.Common.Workflow.DTOs;
using System.Collections.Generic;
using System.Net;
using Kuika.Common.Helpers;
using System.Threading.Tasks;
using System.Threading;

namespace Kuika.App.Controllers
{
    [ApiExplorerSettings(GroupName = "all")]
    [ApiController]
    [Route("v1/api/[controller]")]
    public class WorkflowsController : KControllerBase
    {

        #region ..Constructors..

        public WorkflowsController() : base() { }

        #endregion

        #region ..Apis..

        [Authorize]
        [HttpGet("navigationparameters/{stepId}")]
        public IActionResult GetNavigationParameters(string stepId, [FromQuery] bool? isCallerMicroApp)
        {
            if(isCallerMicroApp == null)
                isCallerMicroApp = false;
            var result = KProviderManager.GetInstance<IWorkflowService>().GetNavigationInfo(stepId, (bool)isCallerMicroApp);
            if (result.AssignedUserId != null && result.AssignedUserId != KContext.CurrentUserId.ToString())
            {
                var agent = KProviderManager.GetInstance<IAuthentication>().GetAgent(result.AssignedUserId);
                if (agent == null || (agent != null && agent.Id != KContext.CurrentUserId))
                    result.AssignedUserId = null;
            }
            return Ok(result);
        }

        [Authorize]
        [HttpGet("stepscreen/{processId}/{stepId}")]
        [HttpGet("stepscreen/{processId}/{stepId}/{appId}")]
        public IActionResult GetStepScreen(string processId, string stepId, string? appId)
        {
            var result = AppHelper.GetScreenNameByStepKey(processId, stepId.ToLowerInvariant());
            if (appId == null || appId == KContext.CurrentProjectId.ToString())
                return Ok(result);
            else
            {
                // cheeck if this app is a microApp in shellApp
                var shellApp = KProviderManager.GetInstance<IApplicationRegistry>().GetShellApplication(
                    new Common.Applications.Request.ApplicationRequest()
                    {
                        ProjectId = Guid.Parse(appId),
                        ApplicationType = Common.Applications.Enum.EApplicationTypes.Backend
                    }
                );
                if (shellApp != null)
                {
                    var app = KProviderManager.GetInstance<IApplicationRegistry>().GetApplication(
                        new Common.Applications.Request.ApplicationRequest()
                        {
                            ProjectId = Guid.Parse(appId),
                            ApplicationType = Common.Applications.Enum.EApplicationTypes.Backend
                        }
                    );
                    var shellScreen = shellApp.ExtraData.MicroApps.FirstOrDefault(m => m.ReferenceProjectId.ToString() == appId  && string.IsNullOrEmpty(m.StartingScreenName));
                    var externalScreenRequest = new GenericRestApiResquestModel();
                    externalScreenRequest.Headers.Add("Content-Type", "application/json");
                    HttpContext.Request.Headers.TryGetValue("Authorization", out var tokenToPass);
                    string authToForward = tokenToPass.ToString();
                    if (string.IsNullOrEmpty(authToForward))
                    {
                        var cookieToken = CookieTokenHelper.GetAccessTokenFromCookie(HttpContext.Request);
                        if (!string.IsNullOrEmpty(cookieToken))
                        {
                            authToForward = $"Bearer {cookieToken}";
                        }
                    }
                    externalScreenRequest.Headers.Add("Authorization", authToForward);
                    externalScreenRequest.MethodType = RestSharp.Method.Get;
                    externalScreenRequest.Url = $"{app.BaseUrl}/v1/api/workflows/stepscreen/{processId}/{stepId}/{appId}";

                    var response = KuikaRestClient.CallRestApi<string>(externalScreenRequest);
                    result = $"{shellScreen?.ContainingScreen}#/{response}";

                }
                return Ok(result);
            }
        }

        [Authorize]
        [HttpGet("stepdata/{stepId}")]
        public IActionResult GetTaskInstanceParameters(string stepId)
        {
            var result = KProviderManager.GetInstance<IWorkflowService>().GetStepDataInfo(stepId, KContext.CurrentUserId.ToString());
            // if(result.AssignedUserId != null  && result.AssignedUserId != KContext.CurrentUserId.ToString())
            // {
            //     var agent = KProviderManager.GetInstance<IAuthentication>().GetAgent(result.AssignedUserId);
            //     result.AssignedUserId = agent == null ? null : agent.Id.ToString();
            // }
            return Ok(result);
        }

        //For requests from clients
        [Authorize]
        [HttpPost("stepInteractions")]
        public IActionResult GetStepInteractionInfo([FromBody] List<string> stepIds, [FromHeader(Name = "Authorization")] string authorization)
        {
            if (string.IsNullOrEmpty(authorization))
            {
                var cookieToken = CookieTokenHelper.GetAccessTokenFromCookie(HttpContext.Request);
                if (!string.IsNullOrEmpty(cookieToken))
                {
                    authorization = $"Bearer {cookieToken}";
                }
            }

            var interactionInfoList = KProviderManager.GetInstance<IWorkflowService>().GetStepKeys(stepIds);
            var localInfo = interactionInfoList.Where(s => s.Value.AppId == null || s.Value.AppId == "" || s.Value.AppId == KContext.CurrentProjectId.ToString()).ToDictionary(i => i.Key, i => i.Value);
            if (localInfo != null || localInfo.Count != 0)
            {
                localInfo = AppHelper.AppendUserInteractions(localInfo);
            }

            var externalApps = interactionInfoList.Where(s => s.Value.AppId != null && s.Value.AppId != KContext.CurrentProjectId.ToString()).Select(s => s.Value.AppId).Distinct().ToList();
            if (externalApps?.Count > 0)
            {
                var externalQueryTasks = new List<Task>();
                foreach (var extApp in externalApps)
                {
                    var app = KProviderManager.GetInstance<IApplicationRegistry>().GetApplication(
                        new Common.Applications.Request.ApplicationRequest()
                        {
                            ProjectId = Guid.Parse(extApp),
                            ApplicationType = Common.Applications.Enum.EApplicationTypes.Backend
                        }
                        );
                    if (app != null)
                    {
                        Task otherAppQueryTask = Task.Factory.StartNew(() =>
                        {
                            var externalInteractionRequest = new GenericRestApiResquestModel();
                            externalInteractionRequest.Headers.Add("Content-Type", "application/json");
                            externalInteractionRequest.Headers.Add("Authorization", authorization);
                            externalInteractionRequest.MethodType = RestSharp.Method.Post;
                            externalInteractionRequest.Url = $"{app.BaseUrl}/v1/api/workflows/internalStepInteractions";
                            externalInteractionRequest.BodyObject = interactionInfoList.Where(s => s.Value.AppId == extApp).ToDictionary(i => i.Key, i => i.Value);

                            var response = KuikaRestClient.CallRestApi<Dictionary<string, InteractionInfo>>(externalInteractionRequest);
                            if (response != null && response.Count > 0)
                            {
                                foreach (var (key, value) in response)
                                    interactionInfoList[key] = value;
                            }
                        }, CancellationToken.None, TaskCreationOptions.LongRunning, TaskScheduler.Default);
                        externalQueryTasks.Add(otherAppQueryTask);
                    }
                }
                Task.WaitAll(externalQueryTasks.ToArray());
            }
            return Ok(interactionInfoList);
        }

        // For requests from other apps
        [Authorize]
        [HttpPost("internalStepInteractions")]
        public IActionResult GetInternalInteractions([FromBody] Dictionary<string, InteractionInfo> instanceInfos)
        {
            var result = AppHelper.AppendUserInteractions(instanceInfos);
            return Ok(result);
        }

        [HttpGet, Route("mailInteraction")]
		public IActionResult MailInteraction([FromQuery] string workflowStepInstanceId, [FromQuery] string userId, [FromQuery] Dictionary<string, string> queryParams)
		{
            try
            {
                var workFlowRequest = new UserActionRequest();
                workFlowRequest.CompletedUser = userId;
                workFlowRequest.Parameters.Add("OutcomeMessage", "".ConvertToType<String>());
                workFlowRequest.Key = workflowStepInstanceId.ConvertToType<String>();

                foreach (var param in queryParams)
                {
                    workFlowRequest.Parameters.Add(param.Key, param.Value.ConvertToType<String>());
                }

                var response = KProviderManager.GetInstance<IWorkflowService>().ResumeProcess(workFlowRequest);
                if (response.Success)
                {
                    return Ok();
                }

                return StatusCode((int)HttpStatusCode.BadRequest);
            }
            catch (Exception)
            {
                return StatusCode((int)HttpStatusCode.InternalServerError);
            }
		}

        [Authorize]
		[HttpGet("workflowWithSteps/{instanceId}")]
		public IActionResult GetWorkflowWithSteps(string instanceId)
		{
			var result = CsSystemFunctions.GetExecutionPointersAndWorkflowByInstanceId(instanceId);
			return Ok(result);
		}

        [Authorize]
        [HttpPost("usertasks")]
        public IActionResult GetUserTasks([FromBody] PendingTasksRequest request)
        {
            var result = CsSystemFunctions.GetUserTasks(
                request.ShowPool,
                request.ShowClaimed,
                request.App,
                request.ProcessDefinitionId,
                request.User,
                request.Page,
                request.PageSize,
                request.SearchKey,
                request.CreatedFrom,
                request.CreatedTo,
                request.OnlyOverDue,
                request.SortBy,
                request.FieldToReturn
            );
            return Ok(result);
        }

        [Authorize]
        [HttpPost("startexternalprocess/{processId}")]
        public IActionResult StartExternalProcess(string processId, [FromBody] SendStartExternalProjectRequestDto requestDto)
        {

            var result = KProviderManager.GetInstance<IWorkflowService>().StartExternalProcess(processId, getAllWfInfos(), requestDto);
            return Ok(result);
        }

        private List<WorkflowInfoDto> getAllWfInfos()
        {
            
            var allWfInfos = new List<WorkflowInfoDto>();
            
return allWfInfos;

        }

        #endregion
    }
}