
using Kuika.Common;
using Kuika.Common.Attributes;
using Kuika.Common.Bases;
using Kuika.Common.Enums;
using Kuika.Common.Accessors;
using Kuika.Common.Json;
using Kuika.Common.Classes;
using Kuika.Common.Exceptions;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Kuika.Common.Helpers;
using Kuika.Common.Settings;
using System.Collections.Generic;
using System;
using Kuika.Common.Extensions;
using System.Linq;
using Kuika.Common.Rest;
using WorkflowCore.Interface;
using Kuika.Common.Interfaces;
using Kuika.Common.Workflow;
using Kuika.Common.Workflow.Extensions;
using Kuika.Common.Workflow.DTOs;
using Kuika.Common.Models;
using Kuika.Common.Menu.Response;
using Kuika.Common.Entities;
using System.Reflection;
using Newtonsoft.Json.Linq;
using Newtonsoft.Json;
using System.Net.Http;
using Iyzipay.Model.V2.Subscription;
using Kuika.Common.Payments.Iyzico;
using Kuika.Common.Payments.Param;
using Iyzipay;
using Kuika.Common.Searching.DTOs;
using Kuika.Common.Helpers.Sap;
using Kuika.Common.Mcp;
using Kuika.Common.Vision.DTOs;
using Kuika.Common.Audit;
using Kuika.Common.Payments.Mobile;
using Kuika.ThirdPartyApisCollection;

namespace Kuika.Reslen_01.Api
{
    [ApiExplorerSettings(GroupName = "all")]
    [Authorize]
    [ApiController]
    [Route("v1/api/ImportList")]
    public class ImportList_Controller : KControllerBase
    {
        private string appName = "wbTimesCRM";
        private Guid appId = Guid.Parse("0e8ecb48-8c52-463c-5db5-08de3ec441b1");
        private static string screenName = "ImportList";
        private Guid screenId = Guid.Parse("7644944c-b753-497b-a51f-124c7ff2f77e");
        private string connectionString { get { return Kuika.Common.KContext.GetConnectionString(); } }

        [HttpGet, Route("myroles")]
        public IActionResult GetMyRoles()
        {
            try
            {
                var result = KProviderManager.Authorization.GetMyRoles(appId, appName, screenId, screenName);
                return Ok(result);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new HttpExceptionDto() { Message = ex.Message, StackTrace = ex.StackTrace });
            }
        }


        [HttpPost, Route("ImportListPageInit")]
        public IActionResult ImportListPageInit(ImportListPageInit_Request request)
        {

            var result = new ImportListPageInit_Response();


            using var auditConnect_0 = ActionAuditScope.Begin("d1fdf7a0-0102-eed5-0eee-81082869d86e", "Connect", applicationName: "wbTimesCRM", screenOrEndpointName: "ImportList");
            using var actionAuditConnect_0 = ActionAuditHelper.Begin("Connect", null);
            try
            {
                Kuika.ThirdPartyApisCollection.DBConnectCsharp.Connect();
            }
            catch (Exception ex)
            {
                actionAuditConnect_0.SetException(ex);
                throw;
            }
;

            var prms_TM_GetCurrentMonthDateRange_1 = new List<kSqlParameter>();
            using var auditTM_GetCurrentMonthDateRange_1 = ActionAuditScope.Begin("3ab14695-1f1d-fcaa-0055-ddfb1753fb50", "TM_GetCurrentMonthDateRange", applicationName: "wbTimesCRM", screenOrEndpointName: "ImportList");
            result.TM_GetCurrentMonthDateRange = KPersister.Fetch(KContext.GetConnectionString(), @"SET NOCOUNT ON;

SELECT
    -- 📅 Ayın ilk günü
    DATEFROMPARTS(YEAR(GETDATE()), MONTH(GETDATE()), 1) AS AyinIlkGunu,

    -- 📅 Ayın son günü
    EOMONTH(GETDATE()) AS AyinSonGunu;", new string[] { "AyinIlkGunu", "AyinSonGunu" }, prms_TM_GetCurrentMonthDateRange_1.ToArray());
            ;


            using var auditGetImportHeaders_2 = ActionAuditScope.Begin("13635899-6d42-c9db-8bf6-6ca6136fd384", "GetImportHeaders", applicationName: "wbTimesCRM", screenOrEndpointName: "ImportList");
            using var actionAuditGetImportHeaders_2 = ActionAuditHelper.Begin("GetImportHeaders", new { startDate = (result.TM_GetCurrentMonthDateRange.ResultList.FirstOrDefault()?.GetValueByFieldName("AyinIlkGunu")).ConvertToType<DateTime>(), endDate = (result.TM_GetCurrentMonthDateRange.ResultList.FirstOrDefault()?.GetValueByFieldName("AyinSonGunu")).ConvertToType<DateTime>() });
            try
            {
                result.GetImportHeaders = Kuika.ThirdPartyApisCollection.GetImportHeader.GetImportHeaders(connectionString, (result.TM_GetCurrentMonthDateRange.ResultList.FirstOrDefault()?.GetValueByFieldName("AyinIlkGunu")).ConvertToType<DateTime>(), (result.TM_GetCurrentMonthDateRange.ResultList.FirstOrDefault()?.GetValueByFieldName("AyinSonGunu")).ConvertToType<DateTime>());
                actionAuditGetImportHeaders_2.SetResult(result.GetImportHeaders);
            }
            catch (Exception ex)
            {
                actionAuditGetImportHeaders_2.SetException(ex);
                throw;
            }
;

            var prms_TM_GetImportHeader_3 = new List<kSqlParameter>();
            using var auditTM_GetImportHeader_3 = ActionAuditScope.Begin("27ed4717-3e7c-f0e2-57c3-437f2af8a56b", "TM_GetImportHeader", applicationName: "wbTimesCRM", screenOrEndpointName: "ImportList");
            result.TM_GetImportHeader = KPersister.Fetch(KContext.GetConnectionString(), @"SELECT 
    h.Id,
    h.HeaderID,

    h.Description,
    h.ImportFileNumber,

    -- 📅 TARİH
    CONVERT(VARCHAR(10), h.InvoiceDate, 104) AS InvoiceDate,

    h.InvoiceNumber,

    -- 🕒 SAAT
    CONVERT(VARCHAR(8), h.InvoiceTime, 108) AS InvoiceTime,

    h.IsReturn,
    h.OfficeCode,
    h.SeriesNumber,
    h.VendorCode,
    h.VendorDescription,

    --------------------------------------------------
    -- 🔥 TOPLAM İTHALAT
    --------------------------------------------------
    ISNULL(imp.TotalImport, 0) AS TotalImportQuantity,

    --------------------------------------------------
    -- 🔥 DAĞITILAN
    --------------------------------------------------
    ISNULL(pool.TotalDistributed, 0) AS DistributedQuantity,

    --------------------------------------------------
    -- 🔥 KALAN
    --------------------------------------------------
    ISNULL(imp.TotalImport, 0) - ISNULL(pool.TotalDistributed, 0) AS RemainingQuantity,

    --------------------------------------------------
    -- 🔥 DURUM
    --------------------------------------------------
    CASE 
        WHEN ISNULL(pool.TotalDistributed, 0) = 0 THEN N'Bekliyor'
        WHEN ISNULL(pool.TotalDistributed, 0) < ISNULL(imp.TotalImport, 0) THEN N'Kısmi Dağıtıldı'
        WHEN ISNULL(pool.TotalDistributed, 0) >= ISNULL(imp.TotalImport, 0) THEN N'Dağıtıldı'
        ELSE N'-'
    END AS Status

FROM tmscrq.TMImportHeader h WITH (NOLOCK)

--------------------------------------------------
-- 🔥 IMPORT TOPLAM
--------------------------------------------------
LEFT JOIN
(
    SELECT 
        HeaderID,
        SUM(Quantity) AS TotalImport
    FROM tmscrq.TMImportLine
    GROUP BY HeaderID
) imp
    ON imp.HeaderID = h.HeaderID

--------------------------------------------------
-- 🔥 POOL TOPLAM
--------------------------------------------------
LEFT JOIN
(
    SELECT 
        HeaderId,
        SUM(Quantity) AS TotalDistributed
    FROM tmscrq.TMDistributionPool
    GROUP BY HeaderId
) pool
    ON pool.HeaderId = h.HeaderID   -- 🔥 string match

--------------------------------------------------
-- 🔥 SIRALAMA
--------------------------------------------------
ORDER BY h.InvoiceDate DESC;", new string[] { "Id", "HeaderID", "Description", "ImportFileNumber", "InvoiceDate", "InvoiceNumber", "InvoiceTime", "IsReturn", "OfficeCode", "SeriesNumber", "VendorCode", "VendorDescription", "TotalImportQuantity", "DistributedQuantity", "RemainingQuantity", "Status" }, prms_TM_GetImportHeader_3.ToArray());
            ;


            return Ok(result);
        }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class ImportListPageInit_Request
    {
        public DateTime? startDate_2 { set; get; }
        public DateTime? endDate_2 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class ImportListPageInit_Response
    {
        public KCommonEntityPage TM_GetCurrentMonthDateRange { set; get; }

        public System.Collections.Generic.IList<Kuika.ThirdPartyApisCollection.ImportHeaderModel> GetImportHeaders { set; get; }

        public KCommonEntityPage TM_GetImportHeader { set; get; }

    }
}
