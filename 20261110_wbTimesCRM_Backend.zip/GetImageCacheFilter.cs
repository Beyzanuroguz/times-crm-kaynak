
using System;
using Kuika.Common;
using Kuika.Common.Accessors;
using Kuika.Common.Extensions;
using Kuika.Common.Helpers;
using Kuika.Common.Settings;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Filters;
using Microsoft.AspNetCore.Http.Extensions;

namespace Kuika.App;

[AttributeUsage(AttributeTargets.Class | AttributeTargets.Method, AllowMultiple = false)]
public class GetImageCacheFilter : ActionFilterAttribute
{
    public override void OnActionExecuting(ActionExecutingContext context)
    {
        try
        {
            var schemaName = context.ActionArguments["schemaname"].ToString();
            if (string.IsNullOrEmpty(schemaName))
            {
                schemaName = "dbo";
            }
            var timestamp = KPersister.GetTimestampFromImageTable(
                KContext.GetConnectionString(),
                schemaName,
                context.ActionArguments["tablename"].ToString(),
                context.ActionArguments["columnname"].ToString(),
                context.ActionArguments["id"].ToString());
            if (timestamp == null)
            {
                base.OnActionExecuting(context);
                return;
            }

            var width = context.HttpContext.Request.Query.ContainsKey("width")
                ? context.HttpContext.Request.Query["width"].ToString()
                : string.Empty;
            var height = context.HttpContext.Request.Query.ContainsKey("height")
                ? context.HttpContext.Request.Query["height"].ToString()
                : string.Empty;
            var imageFit = context.HttpContext.Request.Query.ContainsKey("imageFit")
                ? context.HttpContext.Request.Query["imageFit"].ToString()
                : string.Empty;
            var redirectQueryString = !string.IsNullOrEmpty(width) && !string.IsNullOrEmpty(height)
                ? $"?width={width}&height={height}&imageFit={imageFit}"
                : string.Empty;

            var timeStampString = Convert.ToBase64String(timestamp, Base64FormattingOptions.None);
            timeStampString = Microsoft.IdentityModel.Tokens.Base64UrlEncoder.Encode(timeStampString);
            var backendUrl = ConfigurationHelper.GetSettings<AppSettingsBase>().BaseUrl;
            if (string.IsNullOrEmpty(backendUrl))
            {
                context.Result = new RedirectToActionResult("GetImageByTimestamp", "Image",
                    string.IsNullOrEmpty(redirectQueryString)
                        ? new
                        {
                            tablename = context.ActionArguments["tablename"].ToString(),
                            columnname = context.ActionArguments["columnname"]?.ToString(),
                            id = context.ActionArguments["id"].ToString(),
                            timestamp = timeStampString,
                        }
                        : new
                        {
                            tablename = context.ActionArguments["tablename"].ToString(),
                            columnname = context.ActionArguments["columnname"]?.ToString(),
                            id = context.ActionArguments["id"].ToString(),
                            timestamp = timeStampString,
                            width,
                            height,
                            imageFit
                        });
            }
            else
            {
                if (backendUrl.Contains("/v1/api"))
                {
                    backendUrl = !backendUrl.EndsWith("/") ? $"{backendUrl}/" : $"{backendUrl}";
                }
                else
                {
                    backendUrl = !backendUrl.EndsWith("/") ? $"{backendUrl}/v1/api/" : $"{backendUrl}v1/api/";
                }

                var redirectUrl =
                    $"{backendUrl}Image/{schemaName}/{context.ActionArguments["tablename"]}/{context.ActionArguments["columnname"]}/{context.ActionArguments["id"]}/{timeStampString}{redirectQueryString}";

                context.Result = new RedirectResult(redirectUrl);
            }
        }
        catch (Exception e)
        {
            Console.WriteLine(e);
            base.OnActionExecuting(context);
        }
    }
}