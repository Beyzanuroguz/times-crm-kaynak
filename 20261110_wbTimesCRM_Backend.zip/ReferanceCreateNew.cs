
using Kuika.Common;
using Kuika.Common.Attributes;
using Kuika.Common.Bases;
using Kuika.Common.Enums;
using Kuika.Common.Accessors;
using Kuika.Common.Json;
using Kuika.Common.Classes;
using Kuika.Common.Exceptions;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Kuika.Common.Helpers;
using Kuika.Common.Settings;
using System.Collections.Generic;
using System;
using Kuika.Common.Extensions;
using System.Linq;
using Kuika.Common.Rest;
using WorkflowCore.Interface;
using Kuika.Common.Interfaces;
using Kuika.Common.Workflow;
using Kuika.Common.Workflow.Extensions;
using Kuika.Common.Workflow.DTOs;
using Kuika.Common.Models;
using Kuika.Common.Menu.Response;
using Kuika.Common.Entities;
using System.Reflection;
using Newtonsoft.Json.Linq;
using Newtonsoft.Json;
using System.Net.Http;
using Iyzipay.Model.V2.Subscription;
using Kuika.Common.Payments.Iyzico;
using Kuika.Common.Payments.Param;
using Iyzipay;
using Kuika.Common.Searching.DTOs;
using Kuika.Common.Helpers.Sap;
using Kuika.Common.Mcp;
using Kuika.Common.Vision.DTOs;
using Kuika.Common.Audit;
using Kuika.Common.Payments.Mobile;
using Kuika.ThirdPartyApisCollection;

namespace Kuika.Reslen_01.Api
{
    [ApiExplorerSettings(GroupName = "all")]
    [Authorize]
    [ApiController]
    [Route("v1/api/ReferanceCreateNew")]
    public class ReferanceCreateNew_Controller : KControllerBase
    {
        private string appName = "wbTimesCRM";
        private Guid appId = Guid.Parse("0e8ecb48-8c52-463c-5db5-08de3ec441b1");
        private static string screenName = "ReferanceCreateNew";
        private Guid screenId = Guid.Parse("f3575342-4d2f-4be5-8f7d-9cc839bee755");
        private string connectionString { get { return Kuika.Common.KContext.GetConnectionString(); } }

        [HttpGet, Route("myroles")]
        public IActionResult GetMyRoles()
        {
            try
            {
                var result = KProviderManager.Authorization.GetMyRoles(appId, appName, screenId, screenName);
                return Ok(result);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new HttpExceptionDto() { Message = ex.Message, StackTrace = ex.StackTrace });
            }
        }


        [HttpPost, Route("ReferanceCreateNewPageInit")]
        public IActionResult ReferanceCreateNewPageInit(ReferanceCreateNewPageInit_Request request)
        {

            KProviderManager.Authorization.IsAuthorizedForRoles(appId, appName, screenId, screenName, new List<string> { $"c4e882ef-977d-f613-7694-230ac83919d2", "cdb536b0-6297-155f-d446-8453d8a60304", "4da1f213-c8e4-0b50-5c84-02fd13f1a622", "b4bfd39c-ac02-f442-c899-7a2374a45b47", "70de6cfc-6087-6059-59b4-0b5a8527af6b", "TimesYonetici", "TimesUstYonetici", "TimesSatisPersoneli", "TimesMagazaMuduru", "TimesAdmin" });

            var result = new ReferanceCreateNewPageInit_Response();


            using var auditKuika_CurrAccAttribute_0 = ActionAuditScope.Begin("7803476e-a34e-2a1d-fbae-81343ecc8d50", "Kuika_CurrAccAttribute", applicationName: "wbTimesCRM", screenOrEndpointName: "ReferanceCreateNew");
            using var actionAuditKuika_CurrAccAttribute_0 = ActionAuditHelper.Begin("Kuika_CurrAccAttribute", null);
            try
            {
                result.Kuika_CurrAccAttribute = Kuika.ThirdPartyApisCollection.GetCustomerAttribute.Kuika_CurrAccAttribute();
                actionAuditKuika_CurrAccAttribute_0.SetResult(result.Kuika_CurrAccAttribute);
            }
            catch (Exception ex)
            {
                actionAuditKuika_CurrAccAttribute_0.SetException(ex);
                throw;
            }
;

            var prms_TM_GetCountry_1 = new List<kSqlParameter>();
            using var auditTM_GetCountry_1 = ActionAuditScope.Begin("7d7f90f7-4920-73ee-7cdf-614cd76bb35b", "TM_GetCountry", applicationName: "wbTimesCRM", screenOrEndpointName: "ReferanceCreateNew");
            result.TM_GetCountry = KPersister.Fetch(KContext.GetConnectionString(), @"SELECT DISTINCT
    CountryCode,
    CountryName
FROM tmscrq.TM_NebimLocations
ORDER BY CountryName", new string[] { "CountryCode", "CountryName" }, prms_TM_GetCountry_1.ToArray());
            ;


            return Ok(result);
        }


        [HttpPost, Route("ReferanceCreateNewComponent_941270_onChange")]
        public IActionResult ReferanceCreateNewComponent_941270_onChange(ReferanceCreateNewComponent_941270_onChange_Request request)
        {

            KProviderManager.Authorization.IsAuthorizedForRoles(appId, appName, screenId, screenName, new List<string> { $"c4e882ef-977d-f613-7694-230ac83919d2", "cdb536b0-6297-155f-d446-8453d8a60304", "4da1f213-c8e4-0b50-5c84-02fd13f1a622", "b4bfd39c-ac02-f442-c899-7a2374a45b47", "70de6cfc-6087-6059-59b4-0b5a8527af6b", "TimesYonetici", "TimesUstYonetici", "TimesSatisPersoneli", "TimesMagazaMuduru", "TimesAdmin" });

            var result = new ReferanceCreateNewComponent_941270_onChange_Response();

            var prms_TM_GetCitySql_0 = new List<kSqlParameter>();
            prms_TM_GetCitySql_0.Add(new kSqlParameter() { Name = "CountryCode", Value = request.CountryCode_0 });
            using var auditTM_GetCitySql_0 = ActionAuditScope.Begin("d9056930-a0cc-a32c-b3f1-532556c06b7d", "TM_GetCitySql", applicationName: "wbTimesCRM", screenOrEndpointName: "ReferanceCreateNew");
            result.TM_GetCitySql = KPersister.Fetch(KContext.GetConnectionString(), @"SELECT DISTINCT
    CityCode,
    CityName
FROM tmscrq.TM_NebimLocations
WHERE CountryCode = @CountryCode
ORDER BY CityName", new string[] { "CityCode", "CityName" }, prms_TM_GetCitySql_0.ToArray());
            ;


            return Ok(result);
        }


        [HttpPost, Route("ReferanceCreateNewComponent_846303_onChange")]
        public IActionResult ReferanceCreateNewComponent_846303_onChange(ReferanceCreateNewComponent_846303_onChange_Request request)
        {

            KProviderManager.Authorization.IsAuthorizedForRoles(appId, appName, screenId, screenName, new List<string> { $"c4e882ef-977d-f613-7694-230ac83919d2", "cdb536b0-6297-155f-d446-8453d8a60304", "4da1f213-c8e4-0b50-5c84-02fd13f1a622", "b4bfd39c-ac02-f442-c899-7a2374a45b47", "70de6cfc-6087-6059-59b4-0b5a8527af6b", "TimesYonetici", "TimesUstYonetici", "TimesSatisPersoneli", "TimesMagazaMuduru", "TimesAdmin" });

            var result = new ReferanceCreateNewComponent_846303_onChange_Response();

            var prms_TM_GetDistrict_0 = new List<kSqlParameter>();
            prms_TM_GetDistrict_0.Add(new kSqlParameter() { Name = "CityCode", Value = request.CityCode_0 });
            using var auditTM_GetDistrict_0 = ActionAuditScope.Begin("b76a589a-29db-1396-cdd0-60a19a914b92", "TM_GetDistrict", applicationName: "wbTimesCRM", screenOrEndpointName: "ReferanceCreateNew");
            result.TM_GetDistrict = KPersister.Fetch(KContext.GetConnectionString(), @"SELECT
    DistrictCode,
    DistrictName
FROM tmscrq.TM_NebimLocations
WHERE CityCode = @CityCode
ORDER BY DistrictName", new string[] { "DistrictCode", "DistrictName" }, prms_TM_GetDistrict_0.ToArray());
            ;


            return Ok(result);
        }


        [HttpPost, Route("ReferanceCreateNewComponent_42731_onClick")]
        public IActionResult ReferanceCreateNewComponent_42731_onClick(ReferanceCreateNewComponent_42731_onClick_Request request)
        {

            KProviderManager.Authorization.IsAuthorizedForRoles(appId, appName, screenId, screenName, new List<string> { $"c4e882ef-977d-f613-7694-230ac83919d2", "cdb536b0-6297-155f-d446-8453d8a60304", "4da1f213-c8e4-0b50-5c84-02fd13f1a622", "b4bfd39c-ac02-f442-c899-7a2374a45b47", "70de6cfc-6087-6059-59b4-0b5a8527af6b", "TimesYonetici", "TimesUstYonetici", "TimesSatisPersoneli", "TimesMagazaMuduru", "TimesAdmin" });

            var result = new ReferanceCreateNewComponent_42731_onClick_Response();

            var prms_TMReferanceCreateNew_0 = new List<kSqlParameter>();
            prms_TMReferanceCreateNew_0.Add(new kSqlParameter() { Name = "Name", Value = request.Name_0 });
            prms_TMReferanceCreateNew_0.Add(new kSqlParameter() { Name = "LastName", Value = request.LastName_0 });
            prms_TMReferanceCreateNew_0.Add(new kSqlParameter() { Name = "Tel", Value = request.Tel_0 });
            prms_TMReferanceCreateNew_0.Add(new kSqlParameter() { Name = "Address", Value = request.Address_0 });
            prms_TMReferanceCreateNew_0.Add(new kSqlParameter() { Name = "BirthDate", Value = request.BirthDate_0 });
            prms_TMReferanceCreateNew_0.Add(new kSqlParameter() { Name = "CityCode", Value = request.CityCode_0 });
            prms_TMReferanceCreateNew_0.Add(new kSqlParameter() { Name = "CityName", Value = request.CityName_0 });
            prms_TMReferanceCreateNew_0.Add(new kSqlParameter() { Name = "CountryCode", Value = request.CountryCode_0 });
            prms_TMReferanceCreateNew_0.Add(new kSqlParameter() { Name = "CountryName", Value = request.CountryName_0 });
            prms_TMReferanceCreateNew_0.Add(new kSqlParameter() { Name = "CustomerType", Value = request.CustomerType_0 });
            prms_TMReferanceCreateNew_0.Add(new kSqlParameter() { Name = "CustomerTypeCode", Value = request.CustomerTypeCode_0 });
            prms_TMReferanceCreateNew_0.Add(new kSqlParameter() { Name = "DistrictCode", Value = request.DistrictCode_0 });
            prms_TMReferanceCreateNew_0.Add(new kSqlParameter() { Name = "DistrictName", Value = request.DistrictName_0 });
            prms_TMReferanceCreateNew_0.Add(new kSqlParameter() { Name = "Email", Value = request.Email_0 });
            prms_TMReferanceCreateNew_0.Add(new kSqlParameter() { Name = "GenderCode", Value = request.GenderCode_0 });
            prms_TMReferanceCreateNew_0.Add(new kSqlParameter() { Name = "Info", Value = request.Info_0 });
            prms_TMReferanceCreateNew_0.Add(new kSqlParameter() { Name = "IsEInvoice", Value = false });
            prms_TMReferanceCreateNew_0.Add(new kSqlParameter() { Name = "IsShopping", Value = false });
            prms_TMReferanceCreateNew_0.Add(new kSqlParameter() { Name = "NationalID", Value = request.NationalID_0 });
            prms_TMReferanceCreateNew_0.Add(new kSqlParameter() { Name = "PasaportCountryCode", Value = request.PasaportCountryCode_0 });
            prms_TMReferanceCreateNew_0.Add(new kSqlParameter() { Name = "PasaportCountryDescription", Value = request.PasaportCountryDescription_0 });
            prms_TMReferanceCreateNew_0.Add(new kSqlParameter() { Name = "PasaportNo", Value = request.PasaportNo_0 });
            prms_TMReferanceCreateNew_0.Add(new kSqlParameter() { Name = "PassaportIssueDate", Value = request.PassaportIssueDate_0 });
            prms_TMReferanceCreateNew_0.Add(new kSqlParameter() { Name = "StateCode", Value = string.Empty });
            prms_TMReferanceCreateNew_0.Add(new kSqlParameter() { Name = "StateName", Value = string.Empty });
            prms_TMReferanceCreateNew_0.Add(new kSqlParameter() { Name = "TaxNumber", Value = request.TaxNumber_0 });
            using var auditTMReferanceCreateNew_0 = ActionAuditScope.Begin("30b21f4f-ab7f-a247-6b57-8c05dfa2da70", "TMReferanceCreateNew", applicationName: "wbTimesCRM", screenOrEndpointName: "ReferanceCreateNew");
            result.TMReferanceCreateNew = KPersister.Fetch(KContext.GetConnectionString(), @"SET NOCOUNT ON;

DECLARE @Id UNIQUEIDENTIFIER = NEWID();

BEGIN TRY

    -- Ad zorunlu
    IF NULLIF(LTRIM(RTRIM(@Name)), '') IS NULL
    BEGIN
        SELECT
            CAST(0 AS INT) AS Success,
            N'Ad alanı zorunludur.' AS Message;

        RETURN;
    END;


    -- Soyad zorunlu
    IF NULLIF(LTRIM(RTRIM(@LastName)), '') IS NULL
    BEGIN
        SELECT
            CAST(0 AS INT) AS Success,
            N'Soyad alanı zorunludur.' AS Message;

        RETURN;
    END;


    -- Telefon zorunlu
    IF NULLIF(LTRIM(RTRIM(@Tel)), '') IS NULL
    BEGIN
        SELECT
            CAST(0 AS INT) AS Success,
            N'Telefon numarası zorunludur.' AS Message;

        RETURN;
    END;


    INSERT INTO tmscrq.TMReferencePerson
    (
        Id,

        Address,
        BirthDate,

        CityCode,
        CityName,

        CountryCode,
        CountryName,

        CurrAccCode,

        CustomerType,
        CustomerTypeCode,

        DistrictCode,
        DistrictName,

        Email,
        EmailID,

        GenderCode,
        Info,

        IsEInvoice,
        IsShopping,

        LastName,
        MobilePhoneID,

        Name,
        NationalID,

        PasaportCountryCode,
        PasaportCountryDescription,
        PasaportNo,
        PassaportIssueDate,

        PostalAddressID,

        StateCode,
        StateName,

        TaxNumber,

        Tel,
        TelID
    )
    VALUES
    (
        @Id,

        NULLIF(LTRIM(RTRIM(@Address)), ''),
        @BirthDate,

        NULLIF(LTRIM(RTRIM(@CityCode)), ''),
        NULLIF(LTRIM(RTRIM(@CityName)), ''),

        NULLIF(LTRIM(RTRIM(@CountryCode)), ''),
        NULLIF(LTRIM(RTRIM(@CountryName)), ''),

        -- Nebim müşterisi olmadığı için
        NULL,

        NULLIF(LTRIM(RTRIM(@CustomerType)), ''),
        NULLIF(LTRIM(RTRIM(@CustomerTypeCode)), ''),

        NULLIF(LTRIM(RTRIM(@DistrictCode)), ''),
        NULLIF(LTRIM(RTRIM(@DistrictName)), ''),

        NULLIF(LTRIM(RTRIM(@Email)), ''),

        -- Nebim oluşturduktan sonra gelecek
        NULL,

        NULLIF(LTRIM(RTRIM(@GenderCode)), ''),
        NULLIF(LTRIM(RTRIM(@Info)), ''),

        @IsEInvoice,
        @IsShopping,

        LTRIM(RTRIM(@LastName)),

        -- Nebim oluşturduktan sonra gelecek
        NULL,

        LTRIM(RTRIM(@Name)),
        NULLIF(LTRIM(RTRIM(@NationalID)), ''),

        NULLIF(LTRIM(RTRIM(@PasaportCountryCode)), ''),
        NULLIF(LTRIM(RTRIM(@PasaportCountryDescription)), ''),
        NULLIF(LTRIM(RTRIM(@PasaportNo)), ''),
        @PassaportIssueDate,

        -- Nebim oluşturduktan sonra gelecek
        NULL,

        NULLIF(LTRIM(RTRIM(@StateCode)), ''),
        NULLIF(LTRIM(RTRIM(@StateName)), ''),

        NULLIF(LTRIM(RTRIM(@TaxNumber)), ''),

        LTRIM(RTRIM(@Tel)),

        -- Nebim oluşturduktan sonra gelecek
        NULL
    );


    SELECT
        CAST(1 AS INT) AS Success,
        N'Referans kişi başarıyla oluşturuldu.' AS Message;

END TRY

BEGIN CATCH

    SELECT
        CAST(0 AS INT) AS Success,
        ERROR_MESSAGE() AS Message;

END CATCH;", new string[] { "Success", "Message" }, prms_TMReferanceCreateNew_0.ToArray());
            ;


            return Ok(result);
        }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class ReferanceCreateNewPageInit_Request
    {
    }
}

namespace Kuika.Reslen_01.Api
{
    public class ReferanceCreateNewPageInit_Response
    {
        public System.Collections.Generic.IList<Kuika.ThirdPartyApisCollection.Kuika_CurrAccAttributeModel> Kuika_CurrAccAttribute { set; get; }

        public KCommonEntityPage TM_GetCountry { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class ReferanceCreateNewComponent_941270_onChange_Request
    {
        public String CountryCode_0 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class ReferanceCreateNewComponent_941270_onChange_Response
    {
        public KCommonEntityPage TM_GetCitySql { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class ReferanceCreateNewComponent_846303_onChange_Request
    {
        public String CityCode_0 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class ReferanceCreateNewComponent_846303_onChange_Response
    {
        public KCommonEntityPage TM_GetDistrict { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class ReferanceCreateNewComponent_42731_onClick_Request
    {
        public String Name_0 { set; get; }
        public String LastName_0 { set; get; }
        public String Tel_0 { set; get; }
        public String Address_0 { set; get; }
        public DateTimeOffset? BirthDate_0 { set; get; }
        public String CityCode_0 { set; get; }
        public String CityName_0 { set; get; }
        public String CountryCode_0 { set; get; }
        public String CountryName_0 { set; get; }
        public String CustomerType_0 { set; get; }
        public String CustomerTypeCode_0 { set; get; }
        public String DistrictCode_0 { set; get; }
        public String DistrictName_0 { set; get; }
        public String Email_0 { set; get; }
        public String GenderCode_0 { set; get; }
        public String Info_0 { set; get; }
        public Boolean? IsEInvoice_0 { set; get; }
        public Boolean? IsShopping_0 { set; get; }
        public String NationalID_0 { set; get; }
        public String PasaportCountryCode_0 { set; get; }
        public String PasaportCountryDescription_0 { set; get; }
        public String PasaportNo_0 { set; get; }
        public String PassaportIssueDate_0 { set; get; }
        public String StateCode_0 { set; get; }
        public String StateName_0 { set; get; }
        public String TaxNumber_0 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class ReferanceCreateNewComponent_42731_onClick_Response
    {
        public KCommonEntityPage TMReferanceCreateNew { set; get; }

    }
}
