using Microsoft.ClearScript.V8;
using System;
using System.Collections.Generic;
using System.Text.Json;

namespace Kuika.Reslen_01.Api
{
    public static class HtmlA4Printer
    {
        public static string Open(string html)
        {
            var engine = JsActionEngine.GetEngine();
            engine.Script.html = html;
            var result = engine.Evaluate("HtmlA4Printer.Open(html)");
            return result is string typed ? typed : default;
        }

    }
}
