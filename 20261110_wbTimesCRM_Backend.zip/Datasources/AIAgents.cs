
using System;
using System.Collections.Generic;
using System.Linq;
using System.IO;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;
using Kuika.Common.Exceptions;
using Kuika.Common.Extensions;
using Kuika.Common.Helpers;
using Kuika.Common.Json;
using Kuika.Common.Mcp;
using Kuika.Common.Rest;
using Kuika.Common.Settings;
using Kuika.Common.OpenAI;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using Google.Cloud.AIPlatform.V1;
using Kuika.ThirdPartyApisCollection;

namespace Kuika.Reslen_01.AiAgent;

public static class AIAgents
{

    #region ..Fields..

    private static string _url = null;

    #endregion

    #region ..Publics..

    
    public static Agent_AI_Agent1_Result AI_Agent1(string mert)
    {
        var request = new AI_Agent1_AgentRequest();
        var headers = new Dictionary<string, string>();
        AgentCommonResult commonResult = null;

        
        request.mert = mert;

        
        

        try
        {
          commonResult = KuikaRestClient.AgentPost<AgentCommonResult>($"{GetBaseAddress()}/AI_Agent1", request, headers);
        }
        catch (Exception ex)
        {
            if (ex.Message.StartsWith("Connection refused"))
                throw new Exception("The AI agent service is currently unreachable. Please wait a few seconds and try again");
            CheckOpenAIKey(ex);
            throw;
        }

        if (commonResult.tasks_output == null)
            throw new Exception("The AI agent service returned an invalid response.");

        var result = new Agent_AI_Agent1_Result();
        try
        {
            
        var CustomerIdFormatValidator_Result = commonResult.tasks_output.FirstOrDefault(f => f.agent.Trim().Replace("\n","") == "Excel Naming Convention Validator")?.output;
        result.CustomerIdFormatValidator_Result = ParseAgentResult<Agent_AI_Agent1_Result_CustomerIdFormatValidator_Result>(CustomerIdFormatValidator_Result);

        }
        finally
        {
            
        }

        return result;
    }



    #endregion

    #region ..Privates..

    private static string DecodeBase64ToFile(string base64String)
    {
        // Projenin kök dizinine git (bin/Debug/net8.0 gibi dizinlerden çık)
        string projectDir = Directory.GetParent(AppDomain.CurrentDomain.BaseDirectory).Parent.Parent.Parent.FullName;

        // AiAgent klasörüne kaydet
        string saveDir = Path.Combine(projectDir, "AiAgent");
        if (!Directory.Exists(saveDir))
            Directory.CreateDirectory(saveDir);

        // Dosya uzantısını belirle
        string extension = GetFileExtensionFromBase64(base64String);
        string uniqueFileName = $"{Guid.NewGuid()}{extension}";
        string filePath = Path.Combine(saveDir, uniqueFileName);

        // Base64'ü çözüp dosyaya yaz
        string base64Data = base64String.Contains(",") ? base64String.Split(',')[1] : base64String;
        byte[] fileBytes = Convert.FromBase64String(base64Data);
        File.WriteAllBytes(filePath, fileBytes);

        return filePath;
    }

    // Base64 içindeki MIME türünden dosya uzantısını çıkaran yardımcı metot
    private static string GetFileExtensionFromBase64(string base64String)
    {
        try
        {
            string mimeType = "";
            if (base64String.StartsWith("data:"))
            {
                string[] parts = base64String.Split(',');
                if (parts.Length > 1)
                {
                    string header = parts[0]; // "data:image/png;base64"
                    mimeType = header.Split(';')[0].Replace("data:", "");
                }
            }

            var extensionMap = new Dictionary<string, string>
        {
            { "application/pdf", ".pdf" },
            { "application/vnd.openxmlformats-officedocument.wordprocessingml.document", ".docx" },
            { "application/msword", ".doc" },
            { "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", ".xlsx" },
            { "application/vnd.ms-excel", ".xls" },
            { "application/vnd.openxmlformats-officedocument.presentationml.presentation", ".pptx" },
            { "application/vnd.ms-powerpoint", ".ppt" },
            { "image/jpeg", ".jpg" },
            { "image/png", ".png" },
            { "text/plain", ".txt" },
            { "text/csv", ".csv" },
            { "application/zip", ".zip" },
            { "application/json", ".json" }
        };

            return extensionMap.ContainsKey(mimeType) ? extensionMap[mimeType] : ".dat"; // Bilinmeyen türler için ".dat" kullan
        }
        catch
        {
            return ".dat"; // Hata olursa bilinmeyen dosya uzantısı olarak kaydedilir
        }
    }

    private static string EncodeFileToBase64(string filePath)
    {
        // Eğer dosya yolu "./" ile başlıyorsa, proje dizinine göre ayarla
        if (filePath.StartsWith("./"))
        {
            string projectDir = Directory.GetParent(AppDomain.CurrentDomain.BaseDirectory).FullName;
            string saveDir = Path.Combine(projectDir, "AiAgent/src");
            filePath = Path.Combine(saveDir, filePath.TrimStart('.', '/'));
        }

        if (!File.Exists(filePath))
            throw new FileNotFoundException("Dosya bulunamadı.", filePath);

        string base64String;
        try
        {
            byte[] fileBytes = File.ReadAllBytes(filePath);
            base64String = Convert.ToBase64String(fileBytes);
        }
        finally
        {
            try
            {
                File.Delete(filePath);
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Dosya silinemedi: {filePath} | Hata: {ex.Message}");
            }
        }

        // MIME türünü belirle
        string mimeType = GetMimeTypeFromExtension(Path.GetExtension(filePath));

        return $"data:{mimeType};base64,{base64String}";
    }

    // Dosya uzantısına göre MIME türünü döndüren yardımcı metot
    private static string GetMimeTypeFromExtension(string extension)
    {
        var mimeTypes = new Dictionary<string, string>
    {
        { ".pdf", "application/pdf" },
        { ".docx", "application/vnd.openxmlformats-officedocument.wordprocessingml.document" },
        { ".doc", "application/msword" },
        { ".xlsx", "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet" },
        { ".xls", "application/vnd.ms-excel" },
        { ".pptx", "application/vnd.openxmlformats-officedocument.presentationml.presentation" },
        { ".ppt", "application/vnd.ms-powerpoint" },
        { ".jpg", "image/jpeg" },
        { ".jpeg", "image/jpeg" },
        { ".png", "image/png" },
        { ".txt", "text/plain" },
        { ".csv", "text/csv" },
        { ".zip", "application/zip" },
        { ".json", "application/json" }
    };

        return mimeTypes.TryGetValue(extension.ToLower(), out string mimeType) ? mimeType : "application/octet-stream";
    }

    private static string GetBaseAddress()
    {
        if(_url == null)
            _url = ConfigurationHelper.GetSettings<AiAgentSettings>().ServiceBaseUrl;
        return _url;
    }

    private static T ParseAgentResult<T>(string result)
    {
        try
        {
            return KJSonSerializerBasic.Instance.Deserialize<T>(result);
        }
        catch (Newtonsoft.Json.JsonException ex)
        {
            throw new KException(
                $"There is a problem related to agent. Task output is: {result}");
        }
    }

    private static void CheckOpenAIKey(Exception ex)
    {
        var encryptedOpenAIKey = ConfigurationHelper.GetSettings<OpenAISettings>().ApiKey;

        if (string.IsNullOrEmpty(encryptedOpenAIKey))
            throw new KException(KExceptionMessages.Instance.KV1214);

        if (!ex.Message.Contains("openai"))
            return;

        var openAIKey = CryptographyHelper.DecryptSHA(encryptedOpenAIKey);

        Task.Run(async () => await IsOpenApiKeyValid(openAIKey)).GetAwaiter().GetResult();
    }

    private static async Task<bool> IsOpenApiKeyValid(string apiKey)
    {
        using var httpClient = new HttpClient();
        httpClient.DefaultRequestHeaders.Add("Authorization", $"Bearer {apiKey}");
        string apiUrl = "https://api.openai.com/v1/chat/completions";

        var requestPayload = new
        {
            model = "gpt-4o-mini",
            messages = new[] { new { role = "user", content = "Say this is a test!" }},
            temperature = 0.7
        };

        string jsonPayload = JsonConvert.SerializeObject(requestPayload);

        try
        {
            var response = await httpClient.PostAsync(apiUrl, new StringContent(jsonPayload, Encoding.UTF8, "application/json"));
            string responseContent = await response.Content.ReadAsStringAsync();

            if (response.IsSuccessStatusCode)
                return true;

            JObject jsonObject = JObject.Parse(responseContent);
            string message = jsonObject["error"]["message"].ToString();

            if (response.ReasonPhrase == "Unauthorized" && message.StartsWith("Incorrect API key provided"))
                throw new KException(KExceptionMessages.Instance.KV1195);

            if (response.ReasonPhrase == "Unauthorized" && message.StartsWith("You have insufficient permissions"))
                throw new KException(KExceptionMessages.Instance.KV1196);

            throw new KException(KExceptionMessages.Instance.KV1204);
        }

        catch (Exception ex)
        {
            throw;
        }
    }

    private static void CheckGoogleServiceAccountCredentials(Exception ex)
    {
        var serviceAccountJsonContent = KOpenAI.GetServiceAccountJson();
        if (serviceAccountJsonContent == null || String.IsNullOrEmpty(serviceAccountJsonContent))
            throw new Exception(KExceptionMessages.Instance.KV1197);

        serviceAccountJsonContent = Encoding.UTF8.GetString(Convert.FromBase64String(serviceAccountJsonContent));
        Task.Run(async () => await IsGoogleServiceAccountCredentialsValid(serviceAccountJsonContent)).GetAwaiter().GetResult();
    }

    private static async Task<bool> IsGoogleServiceAccountCredentialsValid(string serviceAccountCredentials)
    {
        if (!serviceAccountCredentials.Contains("\"type\"") || !serviceAccountCredentials.Contains("\"project_id\"") || !serviceAccountCredentials.Contains("\"private_key_id\""))
        {
            throw new Exception(KExceptionMessages.Instance.KV1198);
        }

        JObject jsonObject = JObject.Parse(serviceAccountCredentials);
        string projectId = jsonObject["project_id"].ToString();
        var baseOpenAIClient = KOpenAI.Instance;

        try
        {
            PredictionServiceClient client = new PredictionServiceClientBuilder
            {
                Endpoint = KOpenAI.GetVertexEndpoint(baseOpenAIClient.location),
                JsonCredentials = serviceAccountCredentials
            }.Build();

            var generateContentRequest = new GenerateContentRequest
            {
                Model = KOpenAI.GetVertexModelResource(projectId, baseOpenAIClient.location, baseOpenAIClient.publisher, baseOpenAIClient.aimodel),
                Contents = {
                    new Content
                    {
                        Role = "USER",
                        Parts = { new Part { Text = "hey" }}
                    }
                }
            };

            GenerateContentResponse response = await client.GenerateContentAsync(generateContentRequest);
        }
        catch (Exception ex)
        {
            var (_, friendlyMessage) = ex.ReturnUserFriendlyMessageIfExceptionIsGoogleServiceAccountCredentialRelated();
                throw new Exception(friendlyMessage);
            return false;
        }

        return true;
    }

    private static void CheckSerperKey()
    {
        var encryptedSerperKey = ConfigurationHelper.GetSettings<SerperToolSettings>().ApiKey;

        if (string.IsNullOrEmpty(encryptedSerperKey))
            throw new KException(KExceptionMessages.Instance.KV1210);

        var serperKey = CryptographyHelper.DecryptSHA(encryptedSerperKey);

        Task.Run(async () => await IsSerperKeyValid(serperKey)).GetAwaiter().GetResult();
    }

    private static async Task<bool> IsSerperKeyValid(string apiKey)
    {
        using var httpClient = new HttpClient();
        httpClient.DefaultRequestHeaders.Add("X-API-KEY", apiKey);
        string apiUrl = "https://google.serper.dev/account";

        try
        {
            var response = await httpClient.GetAsync(apiUrl);
            var responseContent = await response.Content.ReadAsStringAsync();

            JObject jsonObject = JObject.Parse(responseContent);

            if (response.IsSuccessStatusCode)
            {
                int? balance = jsonObject.Value<int>("balance");

                if (balance.HasValue && balance.Value <= 0)
                    throw new KException(KExceptionMessages.Instance.KV1220);

                return true;
            }

            // Handle error responses
            string? message = jsonObject.Value<string>("message");

            // Check for invalid/unauthorized key (403 Forbidden with Unauthorized message)
            if ((int)response.StatusCode == 403 && !string.IsNullOrEmpty(message) &&
                (message.Contains("Unauthorized") || message.Contains("Invalid API key")))
            {
                throw new KException(KExceptionMessages.Instance.KV1219);
            }
            // Check for quota/rate limit issues (429 or specific quota messages)
            else if ((int)response.StatusCode == 429 ||
                     (!string.IsNullOrEmpty(message) &&
                      (message.Contains("quota") || message.Contains("limit") || message.Contains("insufficient credits"))))
            {
                throw new KException(KExceptionMessages.Instance.KV1220);
            }
            else
            {
                // Generic error
                throw new KException(string.Format(KExceptionMessages.Instance.KV1221, message ?? "Unknown error"));
            }
        }

        catch (Exception ex)
        {
            throw;
        }
    }

    #endregion

}

public class AgentCommonResult
{
    public List<AgentTaskCommonResult> tasks_output { get; set; }
}

public class AgentTaskCommonResult
{
    public string agent { get; set; }
    public string expected_output { get; set; }
    public string output { get; set; } // JSON Result
    public string task_description { get; set; }
}

public class AI_Agent1_AgentRequest 
{
  public string mert { set; get; }
}




    public class Agent_AI_Agent1_Result 
    {
      public Agent_AI_Agent1_Result_CustomerIdFormatValidator_Result CustomerIdFormatValidator_Result { set; get; }
    }


    public class Agent_AI_Agent1_Result_CustomerIdFormatValidator_Result 
    {
      public System.Collections.Generic.List<Agent_AI_Agent1_Result_CustomerIdFormatValidator_Result_InvalidCustomerEntry> invalid_customers { set; get; }
    }


    public class Agent_AI_Agent1_Result_CustomerIdFormatValidator_Result_InvalidCustomerEntry 
    {
      public Int32? row_number { set; get; }
      public string customer_id { set; get; }
    }



