using System;
using Microsoft.ClearScript.V8;

namespace Kuika.Reslen_01.Api
{
    internal static class JsActionEngine
    {
        private const string _allJsCode = @"""use strict"";
class HtmlA4Printer {
    static Open(html) {
        if (!html || html.trim() === """") {
            return ""HTML boş."";
        }
        try {
            // ------------------------------------------------------------
            // 1. HTML içinden ETTN değerini bul
            // ------------------------------------------------------------
            const ettn = this.extractEttn(html);
            // ------------------------------------------------------------
            // 2. QR'ı bizim kodumuzla PNG Base64 olarak üret
            // ------------------------------------------------------------
            let qrDataUrl = """";
            if (ettn) {
                const qrText = `""ETTN"":""${ettn}""`;
                qrDataUrl = this.createQrPng(qrText);
            }
            // ------------------------------------------------------------
            // 3. Orijinal HTML'deki SCRIPT'leri kaldır
            //
            // Önemli:
            // Gelen HTML'in içinde zaten QRCode.js var.
            // Onu artık kullanmıyoruz.
            // ------------------------------------------------------------
            let cleanedHtml = html.replace(/<script\b[^>]*>[\s\S]*?<\/script>/gi, """");
            // ------------------------------------------------------------
            // 4. QR placeholder'ını gerçek PNG ile değiştir
            // ------------------------------------------------------------
            if (qrDataUrl) {
                const qrHtml = `<div id=""qrcode"" style=""width:100px;height:100px;margin:0 auto;"">
                        <img
                            src=""${qrDataUrl}""
                            style=""
                                width:100px;
                                height:100px;
                                display:block;
                            ""
                        />
                    </div>`;
                cleanedHtml = cleanedHtml.replace(/<div\b[^>]*id=[""']qrcode[""'][^>]*>[\s\S]*?<\/div>/i, qrHtml);
            }
            // ------------------------------------------------------------
            // 5. Gelen HTML içindeki STYLE bloklarını al
            // ------------------------------------------------------------
            const styleMatches = cleanedHtml.match(/<style\b[^>]*>[\s\S]*?<\/style>/gi);
            const originalStyles = styleMatches ? styleMatches.join(""\n"") : """";
            // ------------------------------------------------------------
            // 6. BODY içeriğini al
            // ------------------------------------------------------------
            let bodyContent = """";
            const bodyMatch = cleanedHtml.match(/<body\b[^>]*>([\s\S]*?)<\/body>/i);
            if (bodyMatch && bodyMatch[1]) {
                bodyContent = bodyMatch[1];
            }
            else {
                bodyContent = cleanedHtml
                    .replace(/<!DOCTYPE[\s\S]*?>/gi, """")
                    .replace(/<html\b[^>]*>/gi, """")
                    .replace(/<\/html>/gi, """")
                    .replace(/<head\b[^>]*>[\s\S]*?<\/head>/gi, """")
                    .replace(/<body\b[^>]*>/gi, """")
                    .replace(/<\/body>/gi, """")
                    .replace(/<style\b[^>]*>[\s\S]*?<\/style>/gi, """");
            }
            // ------------------------------------------------------------
            // 7. A4 HTML
            //
            // Gelen doküman yaklaşık 800px tasarlanmış.
            // A4 iç kullanılabilir alana scale ediyoruz.
            // ------------------------------------------------------------
            const finalHtml = `
<!DOCTYPE html>
<html>
<head>

<meta charset=""UTF-8"">

${originalStyles}

<style>

    @page {
        size: A4 portrait;
        margin: 0;
    }

    html,
    body {
        margin: 0 !important;
        padding: 0 !important;
        background: #d9d9d9 !important;
    }

    .kuika-a4-page {
        width: 210mm;
        min-height: 297mm;

        box-sizing: border-box;

        margin: 0 auto;

        /*
         * A4 kenar boşlukları
         */
        padding:
            14mm
            10mm
            14mm
            10mm;

        background: white;

        overflow: hidden;
    }

    .kuika-a4-content {

        /*
         * Gelen e-İrsaliye HTML'i yaklaşık 800px genişlikte.
         */
        width: 800px;

        /*
         * 190mm kullanılabilir A4 genişliğine oturtuyoruz.
         *
         * 190mm yaklaşık 718px.
         * 718 / 800 ≈ 0.897
         */
        transform: scale(0.89);

        transform-origin: top left;
    }


    /*
     * QR'ın bulunduğu hücrede düzgün ortalanması
     */
    #qrcode {
        display: flex !important;
        align-items: center !important;
        justify-content: center !important;

        width: 100px !important;
        height: 100px !important;

        margin-left: auto !important;
        margin-right: auto !important;
    }

    #qrcode img {
        width: 100px !important;
        height: 100px !important;

        object-fit: contain !important;
    }


    /*
     * Yazdırma/PDF sırasında gri arka planı kaldır.
     */
    @media print {

        html,
        body {
            background: white !important;
        }

        .kuika-a4-page {
            margin: 0 !important;
        }
    }

</style>

</head>

<body>

<div class=""kuika-a4-page"">

    <div class=""kuika-a4-content"">
        ${bodyContent}
    </div>

</div>

</body>
</html>
`;
            // ------------------------------------------------------------
            // 8. Standalone pencere
            // ------------------------------------------------------------
            const targetWindow = window.open("""", ""_blank"");
            if (!targetWindow) {
                return ""Yeni pencere açılamadı. Popup engellenmiş olabilir."";
            }
            targetWindow.document.open();
            targetWindow.document.write(finalHtml);
            targetWindow.document.close();
            return ettn ? ""OK - QR üretildi. ETTN: "" + ettn : ""OK - HTML açıldı ancak ETTN bulunamadı."";
        }
        catch (error) {
            return ""Hata: "" + (error && error.message ? error.message : String(error));
        }
    }
    // ================================================================
    // ETTN BUL
    // ================================================================
    static extractEttn(html) {
        /*
         * Öncelikle:
         *
         * ""ETTN"":""C041...""
         */
        let match = html.match(/[""']?ETTN[""']?\s*:\s*[""']([0-9A-Fa-f-]+)[""']/i);
        if (match && match[1]) {
            return match[1].trim();
        }
        /*
         * İkinci ihtimal:
         *
         * ETTN: C041...
         */
        match = html.match(/ETTN(?:&nbsp;|\s)*:(?:&nbsp;|\s|<[^>]+>)*([0-9A-Fa-f-]{30,})/i);
        if (match && match[1]) {
            return match[1].trim();
        }
        /*
         * UUID fallback
         */
        match = html.match(/[0-9A-Fa-f]{8}-[0-9A-Fa-f]{4}-[0-9A-Fa-f]{4}-[0-9A-Fa-f]{4}-[0-9A-Fa-f]{12}/);
        if (match && match[0]) {
            return match[0];
        }
        return """";
    }
    // ================================================================
    // QR PNG ÜRET
    //
    // Version 4
    // Error correction: M
    //
    // Bu e-İrsaliye ETTN yapısı için yeterli.
    // Harici library kullanmaz.
    // ================================================================
    static createQrPng(text) {
        const matrix = this.createQrMatrix(text);
        const quietZone = 4;
        const pixelSize = 5;
        const qrSize = matrix.length;
        const canvasSize = (qrSize + quietZone * 2) * pixelSize;
        const canvas = document.createElement(""canvas"");
        canvas.width = canvasSize;
        canvas.height = canvasSize;
        const context = canvas.getContext(""2d"");
        if (!context) {
            throw new Error(""Canvas context oluşturulamadı."");
        }
        // Beyaz arka plan
        context.fillStyle = ""#FFFFFF"";
        context.fillRect(0, 0, canvasSize, canvasSize);
        // QR modülleri
        context.fillStyle = ""#000000"";
        for (let row = 0; row < qrSize; row++) {
            for (let col = 0; col < qrSize; col++) {
                if (!matrix[row][col]) {
                    continue;
                }
                context.fillRect((col + quietZone) * pixelSize, (row + quietZone) * pixelSize, pixelSize, pixelSize);
            }
        }
        return canvas.toDataURL(""image/png"");
    }
    // ================================================================
    // QR MATRIX
    // ================================================================
    static createQrMatrix(text) {
        /*
         * QR Version 4
         *
         * 33x33
         *
         * EC Level M
         *
         * Data:
         * 2 RS Block
         * 32 data byte / block
         * 18 ECC byte / block
         */
        const version = 4;
        const size = version * 4 + 17;
        const dataBytes = this.createDataBytes(text);
        const blocks = [dataBytes.slice(0, 32), dataBytes.slice(32, 64)];
        const eccBlocks = [];
        for (let i = 0; i < blocks.length; i++) {
            eccBlocks.push(this.rsEncode(blocks[i], 18));
        }
        // ------------------------------------------------------------
        // Interleave data
        // ------------------------------------------------------------
        const codewords = [];
        for (let i = 0; i < 32; i++) {
            codewords.push(blocks[0][i]);
            codewords.push(blocks[1][i]);
        }
        // ------------------------------------------------------------
        // Interleave ECC
        // ------------------------------------------------------------
        for (let i = 0; i < 18; i++) {
            codewords.push(eccBlocks[0][i]);
            codewords.push(eccBlocks[1][i]);
        }
        // ------------------------------------------------------------
        // En uygun maskeyi seç
        // ------------------------------------------------------------
        let bestMatrix = null;
        let bestScore = Number.MAX_VALUE;
        for (let mask = 0; mask < 8; mask++) {
            const matrix = this.buildMatrix(size, codewords, mask);
            const score = this.calculatePenalty(matrix);
            if (score < bestScore) {
                bestScore = score;
                bestMatrix = matrix;
            }
        }
        if (!bestMatrix) {
            throw new Error(""QR matrisi oluşturulamadı."");
        }
        const result = [];
        for (let r = 0; r < size; r++) {
            result[r] = [];
            for (let c = 0; c < size; c++) {
                result[r][c] = bestMatrix[r][c] === true;
            }
        }
        return result;
    }
    // ================================================================
    // DATA BYTES
    // ================================================================
    static createDataBytes(text) {
        const bytes = this.utf8Bytes(text);
        /*
         * Version 4-M:
         *
         * toplam data codeword = 64
         */
        const capacity = 64;
        const bits = [];
        // BYTE mode = 0100
        this.pushBits(bits, 4, 4);
        // Version 1-9 için
        // BYTE mode length = 8 bit
        this.pushBits(bits, bytes.length, 8);
        for (let i = 0; i < bytes.length; i++) {
            this.pushBits(bits, bytes[i], 8);
        }
        const maxBits = capacity * 8;
        if (bits.length > maxBits) {
            throw new Error(""QR verisi Version 4-M kapasitesini aşıyor."");
        }
        // Terminator
        const terminator = Math.min(4, maxBits - bits.length);
        for (let i = 0; i < terminator; i++) {
            bits.push(0);
        }
        // Byte boundary
        while (bits.length % 8 !== 0) {
            bits.push(0);
        }
        const result = [];
        for (let i = 0; i < bits.length; i += 8) {
            let value = 0;
            for (let j = 0; j < 8; j++) {
                value = (value << 1) | bits[i + j];
            }
            result.push(value);
        }
        // Padding
        let toggle = true;
        while (result.length < capacity) {
            result.push(toggle ? 0xec : 0x11);
            toggle = !toggle;
        }
        return result;
    }
    static pushBits(target, value, length) {
        for (let i = length - 1; i >= 0; i--) {
            target.push((value >>> i) & 1);
        }
    }
    static utf8Bytes(text) {
        const result = [];
        for (let i = 0; i < text.length; i++) {
            let code = text.charCodeAt(i);
            if (code < 0x80) {
                result.push(code);
            }
            else if (code < 0x800) {
                result.push(0xc0 | (code >> 6));
                result.push(0x80 | (code & 0x3f));
            }
            else {
                result.push(0xe0 | (code >> 12));
                result.push(0x80 | ((code >> 6) & 0x3f));
                result.push(0x80 | (code & 0x3f));
            }
        }
        return result;
    }
    // ================================================================
    // REED SOLOMON
    // ================================================================
    static rsEncode(data, eccLength) {
        const tables = this.createGaloisTables();
        const exp = tables.exp;
        const log = tables.log;
        let generator = [1];
        for (let i = 0; i < eccLength; i++) {
            generator = this.polyMultiply(generator, [1, exp[i]], exp, log);
        }
        const message = data.slice();
        for (let i = 0; i < eccLength; i++) {
            message.push(0);
        }
        for (let i = 0; i < data.length; i++) {
            const coefficient = message[i];
            if (coefficient === 0) {
                continue;
            }
            const logValue = log[coefficient];
            for (let j = 0; j < generator.length; j++) {
                const g = generator[j];
                if (g === 0) {
                    continue;
                }
                message[i + j] ^= exp[(log[g] + logValue) % 255];
            }
        }
        return message.slice(data.length);
    }
    static createGaloisTables() {
        const exp = new Array(512);
        const log = new Array(256);
        let value = 1;
        for (let i = 0; i < 255; i++) {
            exp[i] = value;
            log[value] = i;
            value <<= 1;
            if (value & 0x100) {
                value ^= 0x11d;
            }
        }
        for (let i = 255; i < 512; i++) {
            exp[i] = exp[i - 255];
        }
        return {
            exp,
            log,
        };
    }
    static polyMultiply(a, b, exp, log) {
        const result = new Array(a.length + b.length - 1).fill(0);
        for (let i = 0; i < a.length; i++) {
            for (let j = 0; j < b.length; j++) {
                if (a[i] === 0 || b[j] === 0) {
                    continue;
                }
                result[i + j] ^= exp[(log[a[i]] + log[b[j]]) % 255];
            }
        }
        return result;
    }
    // ================================================================
    // QR MATRIX BUILD
    // ================================================================
    static buildMatrix(size, codewords, mask) {
        const modules = [];
        for (let r = 0; r < size; r++) {
            modules[r] = new Array(size).fill(null);
        }
        // Finder patterns
        this.placeFinder(modules, 0, 0);
        this.placeFinder(modules, size - 7, 0);
        this.placeFinder(modules, 0, size - 7);
        // Alignment pattern
        // Version 4 => [6, 26]
        const alignment = [6, 26];
        for (let i = 0; i < alignment.length; i++) {
            for (let j = 0; j < alignment.length; j++) {
                const row = alignment[i];
                const col = alignment[j];
                if (modules[row][col] !== null) {
                    continue;
                }
                this.placeAlignment(modules, row, col);
            }
        }
        // Timing patterns
        for (let i = 8; i < size - 8; i++) {
            if (modules[i][6] === null) {
                modules[i][6] = i % 2 === 0;
            }
            if (modules[6][i] === null) {
                modules[6][i] = i % 2 === 0;
            }
        }
        // Format info
        this.placeFormatInfo(modules, mask);
        // Data
        this.mapData(modules, codewords, mask);
        return modules;
    }
    static placeFinder(modules, row, col) {
        const size = modules.length;
        for (let r = -1; r <= 7; r++) {
            for (let c = -1; c <= 7; c++) {
                const rr = row + r;
                const cc = col + c;
                if (rr < 0 || cc < 0 || rr >= size || cc >= size) {
                    continue;
                }
                const dark = r >= 0 &&
                    r <= 6 &&
                    c >= 0 &&
                    c <= 6 &&
                    (r === 0 || r === 6 || c === 0 || c === 6 || (r >= 2 && r <= 4 && c >= 2 && c <= 4));
                modules[rr][cc] = dark;
            }
        }
    }
    static placeAlignment(modules, row, col) {
        for (let r = -2; r <= 2; r++) {
            for (let c = -2; c <= 2; c++) {
                modules[row + r][col + c] = Math.abs(r) === 2 || Math.abs(c) === 2 || (r === 0 && c === 0);
            }
        }
    }
    // ================================================================
    // FORMAT INFO
    //
    // EC Level M = 00
    // ================================================================
    static placeFormatInfo(modules, mask) {
        const size = modules.length;
        const data = mask;
        const bits = this.bchFormat(data);
        for (let i = 0; i < 15; i++) {
            const dark = ((bits >> i) & 1) === 1;
            // Vertical
            if (i < 6) {
                modules[i][8] = dark;
            }
            else if (i < 8) {
                modules[i + 1][8] = dark;
            }
            else {
                modules[size - 15 + i][8] = dark;
            }
            // Horizontal
            if (i < 8) {
                modules[8][size - i - 1] = dark;
            }
            else if (i === 8) {
                modules[8][7] = dark;
            }
            else {
                modules[8][14 - i] = dark;
            }
        }
        // Fixed dark module
        modules[size - 8][8] = true;
    }
    static bchFormat(data) {
        const G15 = 0x537;
        const G15Mask = 0x5412;
        let d = data << 10;
        while (this.bchDigit(d) - this.bchDigit(G15) >= 0) {
            d ^= G15 << (this.bchDigit(d) - this.bchDigit(G15));
        }
        return ((data << 10) | d) ^ G15Mask;
    }
    static bchDigit(data) {
        let digit = 0;
        while (data !== 0) {
            digit++;
            data >>>= 1;
        }
        return digit;
    }
    // ================================================================
    // DATA MAP
    // ================================================================
    static mapData(modules, codewords, mask) {
        const size = modules.length;
        let row = size - 1;
        let direction = -1;
        let byteIndex = 0;
        let bitIndex = 7;
        for (let col = size - 1; col > 0; col -= 2) {
            if (col === 6) {
                col--;
            }
            while (true) {
                for (let offset = 0; offset < 2; offset++) {
                    const currentCol = col - offset;
                    if (modules[row][currentCol] !== null) {
                        continue;
                    }
                    let dark = false;
                    if (byteIndex < codewords.length) {
                        dark = ((codewords[byteIndex] >>> bitIndex) & 1) === 1;
                    }
                    if (this.maskBit(mask, row, currentCol)) {
                        dark = !dark;
                    }
                    modules[row][currentCol] = dark;
                    bitIndex--;
                    if (bitIndex < 0) {
                        byteIndex++;
                        bitIndex = 7;
                    }
                }
                row += direction;
                if (row < 0 || row >= size) {
                    row -= direction;
                    direction = -direction;
                    break;
                }
            }
        }
    }
    static maskBit(mask, row, col) {
        switch (mask) {
            case 0:
                return (row + col) % 2 === 0;
            case 1:
                return row % 2 === 0;
            case 2:
                return col % 3 === 0;
            case 3:
                return (row + col) % 3 === 0;
            case 4:
                return (Math.floor(row / 2) + Math.floor(col / 3)) % 2 === 0;
            case 5:
                return ((row * col) % 2) + ((row * col) % 3) === 0;
            case 6:
                return (((row * col) % 2) + ((row * col) % 3)) % 2 === 0;
            case 7:
                return (((row * col) % 3) + ((row + col) % 2)) % 2 === 0;
        }
        return false;
    }
    // ================================================================
    // MASK PENALTY
    // ================================================================
    static calculatePenalty(modules) {
        const size = modules.length;
        let penalty = 0;
        // ------------------------------------------------------------
        // Same-color neighbours
        // ------------------------------------------------------------
        for (let row = 0; row < size; row++) {
            for (let col = 0; col < size; col++) {
                let same = 0;
                const current = modules[row][col];
                for (let r = -1; r <= 1; r++) {
                    for (let c = -1; c <= 1; c++) {
                        if (r === 0 && c === 0) {
                            continue;
                        }
                        const rr = row + r;
                        const cc = col + c;
                        if (rr < 0 || cc < 0 || rr >= size || cc >= size) {
                            continue;
                        }
                        if (modules[rr][cc] === current) {
                            same++;
                        }
                    }
                }
                if (same > 5) {
                    penalty += 3 + same - 5;
                }
            }
        }
        // ------------------------------------------------------------
        // 2x2 blocks
        // ------------------------------------------------------------
        for (let row = 0; row < size - 1; row++) {
            for (let col = 0; col < size - 1; col++) {
                let count = 0;
                if (modules[row][col])
                    count++;
                if (modules[row + 1][col])
                    count++;
                if (modules[row][col + 1])
                    count++;
                if (modules[row + 1][col + 1])
                    count++;
                if (count === 0 || count === 4) {
                    penalty += 3;
                }
            }
        }
        // ------------------------------------------------------------
        // Finder-like pattern
        // ------------------------------------------------------------
        for (let row = 0; row < size; row++) {
            for (let col = 0; col < size - 6; col++) {
                if (modules[row][col] &&
                    !modules[row][col + 1] &&
                    modules[row][col + 2] &&
                    modules[row][col + 3] &&
                    modules[row][col + 4] &&
                    !modules[row][col + 5] &&
                    modules[row][col + 6]) {
                    penalty += 40;
                }
            }
        }
        for (let col = 0; col < size; col++) {
            for (let row = 0; row < size - 6; row++) {
                if (modules[row][col] &&
                    !modules[row + 1][col] &&
                    modules[row + 2][col] &&
                    modules[row + 3][col] &&
                    modules[row + 4][col] &&
                    !modules[row + 5][col] &&
                    modules[row + 6][col]) {
                    penalty += 40;
                }
            }
        }
        // ------------------------------------------------------------
        // Dark ratio
        // ------------------------------------------------------------
        let darkCount = 0;
        for (let row = 0; row < size; row++) {
            for (let col = 0; col < size; col++) {
                if (modules[row][col]) {
                    darkCount++;
                }
            }
        }
        const total = size * size;
        const ratio = Math.abs((darkCount * 100) / total - 50) / 5;
        penalty += Math.floor(ratio) * 10;
        return penalty;
    }
}

";

        [ThreadStatic] private static V8ScriptEngine _engine;

        public static V8ScriptEngine GetEngine()
        {
            if (_engine == null)
            {
                _engine = new V8ScriptEngine();
                _engine.Execute(_allJsCode);
            }
            return _engine;
        }
    }
}
