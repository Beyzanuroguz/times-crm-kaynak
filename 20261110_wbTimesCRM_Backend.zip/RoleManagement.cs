
using Kuika.Common;
using Kuika.Common.Attributes;
using Kuika.Common.Bases;
using Kuika.Common.Enums;
using Kuika.Common.Accessors;
using Kuika.Common.Json;
using Kuika.Common.Classes;
using Kuika.Common.Exceptions;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Kuika.Common.Helpers;
using Kuika.Common.Settings;
using System.Collections.Generic;
using System;
using Kuika.Common.Extensions;
using System.Linq;
using Kuika.Common.Rest;
using WorkflowCore.Interface;
using Kuika.Common.Interfaces;
using Kuika.Common.Workflow;
using Kuika.Common.Workflow.Extensions;
using Kuika.Common.Workflow.DTOs;
using Kuika.Common.Models;
using Kuika.Common.Menu.Response;
using Kuika.Common.Entities;
using System.Reflection;
using Newtonsoft.Json.Linq;
using Newtonsoft.Json;
using System.Net.Http;
using Iyzipay.Model.V2.Subscription;
using Kuika.Common.Payments.Iyzico;
using Kuika.Common.Payments.Param;
using Iyzipay;
using Kuika.Common.Searching.DTOs;
using Kuika.Common.Helpers.Sap;
using Kuika.Common.Mcp;
using Kuika.Common.Vision.DTOs;
using Kuika.Common.Audit;
using Kuika.Common.Payments.Mobile;
using Kuika.ThirdPartyApisCollection;

namespace Kuika.Reslen_01.Api
{
    [ApiExplorerSettings(GroupName = "all")]
    [Authorize]
    [ApiController]
    [Route("v1/api/RoleManagement")]
    public class RoleManagement_Controller : KControllerBase
    {
        private string appName = "wbTimesCRM";
        private Guid appId = Guid.Parse("0e8ecb48-8c52-463c-5db5-08de3ec441b1");
        private static string screenName = "RoleManagement";
        private Guid screenId = Guid.Parse("01d7a7bb-7b9f-46c8-bd38-c1af5174ce5e");
        private string connectionString { get { return Kuika.Common.KContext.GetConnectionString(); } }

        [HttpGet, Route("myroles")]
        public IActionResult GetMyRoles()
        {
            try
            {
                var result = KProviderManager.Authorization.GetMyRoles(appId, appName, screenId, screenName);
                return Ok(result);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new HttpExceptionDto() { Message = ex.Message, StackTrace = ex.StackTrace });
            }
        }


        [HttpPost, Route("RoleManagementPageInit")]
        public IActionResult RoleManagementPageInit(RoleManagementPageInit_Request request)
        {

            KProviderManager.Authorization.IsAuthorizedForRoles(appId, appName, screenId, screenName, new List<string> { $"c4e882ef-977d-f613-7694-230ac83919d2", "TimesAdmin" });

            var result = new RoleManagementPageInit_Response();


            using var auditGetUserById_0 = ActionAuditScope.Begin("320b8f9a-ee6f-7648-f09a-4a696b0abf99", "GetUserById", applicationName: "wbTimesCRM", screenOrEndpointName: "RoleManagement");
            using var actionAuditGetUserById_0 = ActionAuditHelper.Begin("GetUserById", new { id = request.id_0.ConvertToType<Guid?>() });
            try
            {
                result.GetUserById = Kuika.Common.Helpers.CsSystemFunctions.GetUserById(request.id_0.ConvertToType<Guid?>());
                actionAuditGetUserById_0.SetResult(result.GetUserById);
            }
            catch (Exception ex)
            {
                actionAuditGetUserById_0.SetException(ex);
                throw;
            }
;

            var prms_TM_GetRoleUserById_1 = new List<kSqlParameter>();
            prms_TM_GetRoleUserById_1.Add(new kSqlParameter() { Name = "Id", Value = request.Id_1 });
            using var auditTM_GetRoleUserById_1 = ActionAuditScope.Begin("60b91c6e-5cc7-cd15-519d-fe73ad8cddb2", "TM_GetRoleUserById", applicationName: "wbTimesCRM", screenOrEndpointName: "RoleManagement");
            result.TM_GetRoleUserById = KPersister.Fetch(KContext.GetConnectionString(), @"SELECT
    KU.Id AS UserId,
    KU.Username AS UserName,
    KU.FirstName + ' ' + KU.LastName AS FullName,
    KU.IsDeleted,
    ISNULL(R.Name, 'Rol Yok') AS RoleName,
    TU.Id AS TMUserId,
    TU.KUserID,
    TU.StoreId,
    TU.OfficeCode,
    TU.OfficeDescription,
    TU.SalesPersonCode,
    TS.StoreDesc AS StoreDescription
FROM dbo.KUser KU
LEFT JOIN dbo.KUserRole UR
    ON UR.KUser_Id = KU.Id
LEFT JOIN dbo.KRole R
    ON R.Id = UR.KRole_Id
    AND R.Name IN ('TimesAdmin','TimesUstYonetici','TimesYonetici','TimesSatisPersoneli','TimesMagazaMuduru')
LEFT JOIN tmscrq.TMUser TU
    ON TU.KUserID = KU.Id
LEFT JOIN tmscrq.TMStore TS
    ON TS.Id = TU.StoreId
WHERE KU.Id = @Id
  AND (
        R.Id IS NOT NULL
        OR NOT EXISTS (
            SELECT 1 
            FROM dbo.KUserRole UR2
            INNER JOIN dbo.KRole R2 ON R2.Id = UR2.KRole_Id
            WHERE UR2.KUser_Id = KU.Id
              AND R2.Name IN ('TimesAdmin','TimesUstYonetici','TimesYonetici','TimesSatisPersoneli','TimesMagazaMuduru')
        )
      );
", new string[] { "UserId", "UserName", "FullName", "IsDeleted", "RoleName", "TMUserId", "KUserID", "StoreId", "OfficeCode", "OfficeDescription", "SalesPersonCode", "StoreDescription" }, prms_TM_GetRoleUserById_1.ToArray());
            ;

            var prms_TM_GetUserMissingRoles_2 = new List<kSqlParameter>();
            prms_TM_GetUserMissingRoles_2.Add(new kSqlParameter() { Name = "Id", Value = request.Id_2 });
            using var auditTM_GetUserMissingRoles_2 = ActionAuditScope.Begin("ae7ea882-87a6-15dd-b38b-651f5112bae2", "TM_GetUserMissingRoles", applicationName: "wbTimesCRM", screenOrEndpointName: "RoleManagement");
            result.TM_GetUserMissingRoles = KPersister.Fetch(KContext.GetConnectionString(), @"

SELECT 
    R.Id AS RoleId,
    R.Name AS RoleName
FROM dbo.KRole R
WHERE R.IsDeleted = 0
  AND R.Name IN (
        'TimesAdmin',
        'TimesUstYonetici',
        'TimesYonetici',
        'TimesSatisPersoneli',
        'TimesMagazaMuduru'
  )
  AND NOT EXISTS (
      SELECT 1
      FROM dbo.KUserRole UR
      WHERE UR.KUser_Id = @Id
        AND UR.KRole_Id = R.Id
  );
", new string[] { "RoleId", "RoleName" }, prms_TM_GetUserMissingRoles_2.ToArray());
            ;


            return Ok(result);
        }


        [HttpPost, Route("RoleManagementComponent_450654_onClick")]
        public IActionResult RoleManagementComponent_450654_onClick(RoleManagementComponent_450654_onClick_Request request)
        {

            KProviderManager.Authorization.IsAuthorizedForRoles(appId, appName, screenId, screenName, new List<string> { $"c4e882ef-977d-f613-7694-230ac83919d2", "TimesAdmin" });

            var result = new RoleManagementComponent_450654_onClick_Response();

            var prms_TM_RemoveUserFromRole_0 = new List<kSqlParameter>();
            prms_TM_RemoveUserFromRole_0.Add(new kSqlParameter() { Name = "Username", Value = request.Username_0 });
            prms_TM_RemoveUserFromRole_0.Add(new kSqlParameter() { Name = "RoleNames", Value = request.RoleNames_0 });
            using var auditTM_RemoveUserFromRole_0 = ActionAuditScope.Begin("47b5f9f1-e5c8-d7ee-1a74-8226d144b579", "TM_RemoveUserFromRole", applicationName: "wbTimesCRM", screenOrEndpointName: "RoleManagement");
            result.TM_RemoveUserFromRole = KPersister.Save(KContext.GetConnectionString(), @"-- Kuika'dan @Username ve @RoleNames gelmiş kabul ediyoruz
-- @RoleNames örn: 'Rol1,Rol2,Rol3'

DECLARE @UserId UNIQUEIDENTIFIER;

-- Kullanıcı Id bul
SELECT @UserId = Id
FROM dbo.KUser
WHERE Username = @Username
  AND IsDeleted = 0;

IF @UserId IS NULL
BEGIN
    RAISERROR('Kullanıcı bulunamadı', 16, 1);
    RETURN;
END

-- Parametreyi XML'e çevirip ayırıyoruz
DECLARE @xmlRoles XML = CAST('<r>' + REPLACE(@RoleNames, ',', '</r><r>') + '</r>' AS XML);

;WITH RoleList AS
(
    SELECT T.c.value('.', 'NVARCHAR(100)') AS RoleName
    FROM @xmlRoles.nodes('/r') T(c)
)
DELETE UR
FROM dbo.KUserRole UR
INNER JOIN dbo.KRole R
    ON R.Id = UR.KRole_Id
INNER JOIN RoleList RL
    ON RL.RoleName = R.Name
WHERE UR.KUser_Id = @UserId;
", prms_TM_RemoveUserFromRole_0.ToArray());
            ;


            return Ok(result);
        }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class RoleManagementPageInit_Request
    {
        public Guid? id_0 { set; get; }
        public Guid? Id_1 { set; get; }
        public Guid? Id_2 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class RoleManagementPageInit_Response
    {
        public UserInfoModel GetUserById { set; get; }

        public KCommonEntityPage TM_GetRoleUserById { set; get; }

        public KCommonEntityPage TM_GetUserMissingRoles { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class RoleManagementComponent_450654_onClick_Request
    {
        public String Username_0 { set; get; }
        public String RoleNames_0 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class RoleManagementComponent_450654_onClick_Response
    {
        public int TM_RemoveUserFromRole { set; get; }

    }
}
