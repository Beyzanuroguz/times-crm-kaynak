
using Kuika.Common;
using Kuika.Common.Attributes;
using Kuika.Common.Bases;
using Kuika.Common.Enums;
using Kuika.Common.Accessors;
using Kuika.Common.Json;
using Kuika.Common.Classes;
using Kuika.Common.Exceptions;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Kuika.Common.Helpers;
using Kuika.Common.Settings;
using System.Collections.Generic;
using System;
using Kuika.Common.Extensions;
using System.Linq;
using Kuika.Common.Rest;
using WorkflowCore.Interface;
using Kuika.Common.Interfaces;
using Kuika.Common.Workflow;
using Kuika.Common.Workflow.Extensions;
using Kuika.Common.Workflow.DTOs;
using Kuika.Common.Models;
using Kuika.Common.Menu.Response;
using Kuika.Common.Entities;
using System.Reflection;
using Newtonsoft.Json.Linq;
using Newtonsoft.Json;
using System.Net.Http;
using Iyzipay.Model.V2.Subscription;
using Kuika.Common.Payments.Iyzico;
using Kuika.Common.Payments.Param;
using Iyzipay;
using Kuika.Common.Searching.DTOs;
using Kuika.Common.Helpers.Sap;
using Kuika.Common.Mcp;
using Kuika.Common.Vision.DTOs;
using Kuika.Common.Audit;
using Kuika.Common.Payments.Mobile;
using Kuika.ThirdPartyApisCollection;

namespace Kuika.Reslen_01.Api
{
    [ApiExplorerSettings(GroupName = "all")]
    [Authorize]
    [ApiController]
    [Route("v1/api/LeadList")]
    public class LeadList_Controller : KControllerBase
    {
        private string appName = "wbTimesCRM";
        private Guid appId = Guid.Parse("0e8ecb48-8c52-463c-5db5-08de3ec441b1");
        private static string screenName = "LeadList";
        private Guid screenId = Guid.Parse("2e1780e4-e80d-48e0-a08b-baf9bf9d2c6e");
        private string connectionString { get { return Kuika.Common.KContext.GetConnectionString(); } }

        [HttpGet, Route("myroles")]
        public IActionResult GetMyRoles()
        {
            try
            {
                var result = KProviderManager.Authorization.GetMyRoles(appId, appName, screenId, screenName);
                return Ok(result);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new HttpExceptionDto() { Message = ex.Message, StackTrace = ex.StackTrace });
            }
        }


        [HttpPost, Route("LeadListPageInit")]
        public IActionResult LeadListPageInit(LeadListPageInit_Request request)
        {

            KProviderManager.Authorization.IsAuthorizedForRoles(appId, appName, screenId, screenName, new List<string> { $"70de6cfc-6087-6059-59b4-0b5a8527af6b", "4da1f213-c8e4-0b50-5c84-02fd13f1a622", "c4e882ef-977d-f613-7694-230ac83919d2", "b4bfd39c-ac02-f442-c899-7a2374a45b47", "cdb536b0-6297-155f-d446-8453d8a60304", "TimesYonetici", "TimesUstYonetici", "TimesSatisPersoneli", "TimesMagazaMuduru", "TimesAdmin" });

            var result = new LeadListPageInit_Response();

            var prms_TM_GetLeads_0 = new List<kSqlParameter>();
            prms_TM_GetLeads_0.Add(new kSqlParameter() { Name = "StepOrder", Value = (null as object) });
            prms_TM_GetLeads_0.Add(new kSqlParameter() { Name = "UserId", Value = Kuika.Common.KContext.CurrentUser?.Id });
            prms_TM_GetLeads_0.Add(new kSqlParameter() { Name = "MusteriAdi", Value = (null as object) });
            prms_TM_GetLeads_0.Add(new kSqlParameter() { Name = "ProductName", Value = (null as object) });
            prms_TM_GetLeads_0.Add(new kSqlParameter() { Name = "LeadCode", Value = (null as object) });
            prms_TM_GetLeads_0.Add(new kSqlParameter() { Name = "Tel", Value = (null as object) });
            prms_TM_GetLeads_0.Add(new kSqlParameter() { Name = "CategoryName", Value = (null as object) });
            prms_TM_GetLeads_0.Add(new kSqlParameter() { Name = "StoreIds", Value = (null as object) });
            prms_TM_GetLeads_0.Add(new kSqlParameter() { Name = "SatisDanismaniIds", Value = (null as object) });
            prms_TM_GetLeads_0.Add(new kSqlParameter() { Name = "ProcessCode", Value = (null as object) });
            prms_TM_GetLeads_0.Add(new kSqlParameter() { Name = "StartDate", Value = (null as object) });
            prms_TM_GetLeads_0.Add(new kSqlParameter() { Name = "EndDate", Value = (null as object) });
            using var auditTM_GetLeads_0 = ActionAuditScope.Begin("2f563932-42db-3495-a726-477e22bf027e", "TM_GetLeads", applicationName: "wbTimesCRM", screenOrEndpointName: "LeadList");
            result.TM_GetLeads = KPersister.Fetch(KContext.GetConnectionString(), @"-- SET LANGUAGE Turkish;

-- SELECT
-- CASE 
--     WHEN EXISTS (
--         SELECT 1 
--         FROM tmscrq.TMLeadReservation r
--         WHERE r.LeadId = l.Id
--           AND r.IsActive = 1
--           AND r.IsApproved = 1
--     ) THEN N'Evet'

--     WHEN EXISTS (
--         SELECT 1 
--         FROM tmscrq.TMLeadReservation r
--         WHERE r.LeadId = l.Id
--           AND r.IsActive = 1
--           AND ISNULL(r.IsApproved,0) = 0
--     ) THEN N'Onay Bekliyor'

--     ELSE N'Hayır'
-- END AS RezerveDurumu,
--     l.Id AS LeadId,
--     l.IsReserved,
--     ISNULL(NULLIF(LTRIM(RTRIM(l.LeadCode)), ''), '-') AS LeadNumarasi,
--     CONVERT(varchar(10), l.CreatedAt, 103) AS TalepTarihi,

--     p.Id AS ProductId,
--     ISNULL(NULLIF(LTRIM(RTRIM(p.ProductName)), ''), '-') AS ProductName,
--     ISNULL(NULLIF(LTRIM(RTRIM(p.Bracelet)), ''), '-') AS Bilezik,
--     ISNULL(NULLIF(LTRIM(RTRIM(p.Brand)), ''), '-') AS Brand,
--     ISNULL(NULLIF(LTRIM(RTRIM(p.Dial)), ''), '-') AS Kadran,
--     ISNULL(NULLIF(LTRIM(RTRIM(p.ProductCode)), ''), '-') AS RefCode,
--     ISNULL(NULLIF(LTRIM(RTRIM(p.Referance)), ''), '-') AS Referans,

--     ISNULL(
--         NULLIF(
--             LTRIM(RTRIM(ISNULL(cu.Name, '') + ' ' + ISNULL(cu.LastName, '')))
--         , '')
--     , '-') AS Musteri,

--     ISNULL(NULLIF(LTRIM(RTRIM(cu.CityName)), ''), '-') AS Lokasyon,
--     ISNULL(NULLIF(LTRIM(RTRIM(cu.DistrictName)), ''), '-') AS Ilce,
--     ISNULL(NULLIF(LTRIM(RTRIM(cu.CountryName)), ''), '-') AS Ulke,
--     ISNULL(NULLIF(LTRIM(RTRIM(cu.Info)), ''), '-') AS MusteriInfo,

--     CASE
--         WHEN cu.IsShopping = 1 THEN N'Evet'
--         WHEN cu.IsShopping = 0 THEN N'Hayır'
--         ELSE '-'
--     END AS AlisverisiVarMi,

--     ISNULL(NULLIF(LTRIM(RTRIM(cu.Tel)), ''), '-') AS IrtibatNumarasi,
--     ISNULL(NULLIF(LTRIM(RTRIM(cu.Email)), ''), '-') AS EmailAdresi,

--     ISNULL(NULLIF(LTRIM(RTRIM(cr.ContactResourceName)), ''), '-') AS IletisimKaynagi,

--     ISNULL(NULLIF(LTRIM(RTRIM(p.CategoryName)), ''), '-') AS CategoryName,
--     '-' AS CategoryCode,

--     ISNULL(NULLIF(LTRIM(RTRIM(ls.Name)), ''), '-') AS LeadDurumu,
--     ISNULL(NULLIF(LTRIM(RTRIM(ns.Name)), ''), '-') AS SonrakiAdim,

--     ISNULL(NULLIF(LTRIM(RTRIM(lp.Name)), ''), '-') AS ProcessName,
--     ISNULL(NULLIF(LTRIM(RTRIM(lp.Code)), ''), '-') AS ProcessCode,
--     lp.StepOrder,
-- CASE
--     WHEN EXISTS
--     (
--         SELECT 1
--         FROM tmscrq.TMLeadReservation r
--         WHERE r.LeadId = l.Id
--           AND r.IsActive = 1
--           AND ISNULL(r.IsApproved,0) = 0
--     )
--     THEN 10
--     ELSE lp.StepOrder
-- END AS SelectedStepOrder,

--     ISNULL(
--         CASE
--             WHEN l.EstimatedDate IS NOT NULL
--             THEN CAST(YEAR(l.EstimatedDate) AS VARCHAR(4)) + ' ' + DATENAME(MONTH, l.EstimatedDate)
--             ELSE NULL
--         END,
--         '-'
--     ) AS TerminTarihi,

--     ISNULL(
--         NULLIF(
--             LTRIM(RTRIM(ISNULL(sp.FirstName, '') + ' ' + ISNULL(sp.LastName, '')))
--         , '')
--     , '-') AS SatisDanismani,

--     ISNULL(NULLIF(LTRIM(RTRIM(st.StoreDesc)), ''), '-') AS StoreName

-- FROM tmscrq.TMLead l
-- LEFT JOIN tmscrq.TMLeadStatu ls
--     ON ls.Id = l.StatuId
-- LEFT JOIN tmscrq.TMCustomer cu
--     ON cu.Id = l.CustomerId
-- LEFT JOIN tmscrq.TMProduct p
--     ON p.Id = l.ProductId
-- LEFT JOIN tmscrq.TMContactResource cr
--     ON cr.Id = l.ContactResourceId
-- LEFT JOIN dbo.KUser sp
--     ON sp.Id = l.SalesPersonKUserId
-- LEFT JOIN tmscrq.TMStore st
--     ON st.Id = l.StoreId
-- LEFT JOIN tmscrq.TMLeadProcess lp
--     ON lp.Id = l.ProcessID
-- LEFT JOIN tmscrq.TMLeadNextStep ns
--     ON ns.Id = l.NextStepId

-- WHERE
-- (
--     EXISTS
--     (
--         SELECT 1
--         FROM dbo.KUserRole ur
--         INNER JOIN dbo.KRole r
--             ON r.Id = ur.KRole_Id
--         WHERE ur.KUser_Id = @UserId
--           AND ur.IsDeleted = 0
--           AND r.IsDeleted = 0
--           AND r.Name IN ('TimesYonetici', 'TimesUstYonetici')
--     )
--     OR
--     (
--         EXISTS
--         (
--             SELECT 1
--             FROM dbo.KUserRole ur
--             INNER JOIN dbo.KRole r
--                 ON r.Id = ur.KRole_Id
--             WHERE ur.KUser_Id = @UserId
--               AND ur.IsDeleted = 0
--               AND r.IsDeleted = 0
--               AND r.Name IN ('TimesMagazaMuduru', 'TimesSatisPersoneli')
--         )
--         AND EXISTS
--         (
--             SELECT 1
--             FROM tmscrq.TMUser tu
--             WHERE tu.KUserID = @UserId
--               AND tu.StoreId = l.StoreId
--         )
--     )
-- )

-- AND
-- (
--     @MusteriAdi IS NULL
--     OR LTRIM(RTRIM(@MusteriAdi)) = ''
--     OR UPPER(LTRIM(RTRIM(ISNULL(cu.Name,'') + ' ' + ISNULL(cu.LastName,''))))
--        LIKE '%' + UPPER(LTRIM(RTRIM(@MusteriAdi))) + '%'
-- )

-- AND
-- (
--     @ProductName IS NULL
--     OR LTRIM(RTRIM(@ProductName)) = ''
--     OR
--     (
--         CHARINDEX(',', @ProductName) > 0
--         AND ISNULL(LTRIM(RTRIM(p.ProductName)), '') IN
--         (
--             SELECT LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', '')))
--             FROM STRING_SPLIT(CAST(@ProductName AS NVARCHAR(MAX)), ',')
--             WHERE LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', ''))) <> ''
--         )
--     )
--     OR
--     (
--         CHARINDEX(',', @ProductName) = 0
--         AND UPPER(ISNULL(LTRIM(RTRIM(p.ProductName)), ''))
--             LIKE '%' + UPPER(LTRIM(RTRIM(@ProductName))) + '%'
--     )
-- )

-- AND
-- (
--     @LeadCode IS NULL
--     OR LTRIM(RTRIM(@LeadCode)) = ''
--     OR UPPER(ISNULL(LTRIM(RTRIM(l.LeadCode)), '')) LIKE '%' + UPPER(LTRIM(RTRIM(@LeadCode))) + '%'
-- )

-- AND
-- (
--     @Tel IS NULL
--     OR LTRIM(RTRIM(@Tel)) = ''
--     OR UPPER(ISNULL(LTRIM(RTRIM(cu.Tel)), '')) LIKE '%' + UPPER(LTRIM(RTRIM(@Tel))) + '%'
-- )

-- -- AND
-- -- (
-- --     @CategoryName IS NULL
-- --     OR LTRIM(RTRIM(@CategoryName)) = ''
-- --     OR
-- --     (
-- --         EXISTS
-- --         (
-- --             SELECT 1
-- --             FROM STRING_SPLIT(CAST(@CategoryName AS NVARCHAR(MAX)), ',') c
-- --             WHERE UPPER(LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(c.value, '""', ''), '[', ''), ']', '')))) = 'DEFAULT'
-- --         )
-- --         AND (p.CategoryName IS NULL OR LTRIM(RTRIM(p.CategoryName)) = '')
-- --     )
-- --     OR UPPER(ISNULL(LTRIM(RTRIM(p.CategoryName)), '')) IN
-- --     (
-- --         SELECT UPPER(LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', ''))))
-- --         FROM STRING_SPLIT(CAST(@CategoryName AS NVARCHAR(MAX)), ',')
-- --         WHERE LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', ''))) <> ''
-- --           AND UPPER(LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', '')))) <> 'DEFAULT'
-- --     )
-- -- )

-- AND
-- (
--     @CategoryName IS NULL
--     OR LTRIM(RTRIM(@CategoryName)) = ''
--     OR UPPER(ISNULL(LTRIM(RTRIM(p.CategoryName)), '')) IN
--     (
--         SELECT UPPER(LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value,'""',''),'[',''),']',''))))
--         FROM STRING_SPLIT(CAST(@CategoryName AS NVARCHAR(MAX)), ',')
--         WHERE LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value,'""',''),'[',''),']',''))) <> ''
--     )
-- )

-- AND
-- (
--     @StoreIds IS NULL
--     OR LTRIM(RTRIM(@StoreIds)) = ''
--     OR EXISTS
--     (
--         SELECT 1
--         FROM STRING_SPLIT(CAST(@StoreIds AS NVARCHAR(MAX)), ',') s
--         WHERE l.StoreId = TRY_CONVERT
--         (
--             uniqueidentifier,
--             LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(s.value, '""', ''), '[', ''), ']', '')))
--         )
--     )
-- )

-- AND
-- (
--     @SatisDanismaniIds IS NULL
--     OR LTRIM(RTRIM(@SatisDanismaniIds)) = ''
--     OR EXISTS
--     (
--         SELECT 1
--         FROM STRING_SPLIT(CAST(@SatisDanismaniIds AS NVARCHAR(MAX)), ',') s
--         WHERE l.SalesPersonKUserId = TRY_CONVERT
--         (
--             uniqueidentifier,
--             LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(s.value, '""', ''), '[', ''), ']', '')))
--         )
--     )
-- )

-- AND
-- (
--     @ProcessCode IS NULL
--     OR LTRIM(RTRIM(@ProcessCode)) = ''
--     OR UPPER(ISNULL(LTRIM(RTRIM(lp.Code)), '')) IN
--     (
--         SELECT UPPER(LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', ''))))
--         FROM STRING_SPLIT(CAST(@ProcessCode AS NVARCHAR(MAX)), ',')
--         WHERE LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', ''))) <> ''
--     )
-- )

-- AND
-- (
--     @StepOrder IS NULL

--     OR
--     (
--         @StepOrder = 10
--         AND EXISTS
--         (
--             SELECT 1
--             FROM tmscrq.TMLeadReservation r
--             WHERE r.LeadId = l.Id
--               AND r.IsActive = 1
--               AND ISNULL(r.IsApproved,0) = 0
--         )
--     )

--     OR
--     (
--         @StepOrder <> 10
--         AND lp.StepOrder = @StepOrder
--     )
-- )

-- AND
-- (
--     @StartDate IS NULL
--     OR LTRIM(RTRIM(@StartDate)) = ''
--     OR l.CreatedAt >= CONVERT(date, @StartDate)
-- )

-- AND
-- (
--     @EndDate IS NULL
--     OR LTRIM(RTRIM(@EndDate)) = ''
--     OR l.CreatedAt < DATEADD(day, 1, CONVERT(date, @EndDate))
-- )

-- ORDER BY l.CreatedAt DESC;

------------------------++++++++++++++++++++++++-------------------
-- SET LANGUAGE Turkish;

-- SELECT
-- CASE 
--     WHEN EXISTS (
--         SELECT 1 
--         FROM tmscrq.TMLeadReservation r
--         WHERE r.LeadId = l.Id
--           AND r.IsActive = 1
--           AND r.IsApproved = 1
--     ) THEN N'Evet'

--     WHEN EXISTS (
--         SELECT 1 
--         FROM tmscrq.TMLeadReservation r
--         WHERE r.LeadId = l.Id
--           AND r.IsActive = 1
--           AND ISNULL(r.IsApproved,0) = 0
--     ) THEN N'Onay Bekliyor'

--     ELSE N'Hayır'
-- END AS RezerveDurumu,
--     l.Id AS LeadId,
--     l.IsReserved,
--     ISNULL(NULLIF(LTRIM(RTRIM(l.LeadCode)), ''), '-') AS LeadNumarasi,
--     CONVERT(varchar(10), l.CreatedAt, 103) AS TalepTarihi,

--     p.Id AS ProductId,
--     ISNULL(NULLIF(LTRIM(RTRIM(p.ProductName)), ''), '-') AS ProductName,
--     ISNULL(NULLIF(LTRIM(RTRIM(p.Bracelet)), ''), '-') AS Bilezik,
--     ISNULL(NULLIF(LTRIM(RTRIM(p.Brand)), ''), '-') AS Brand,
--     ISNULL(NULLIF(LTRIM(RTRIM(p.Dial)), ''), '-') AS Kadran,
--     ISNULL(NULLIF(LTRIM(RTRIM(p.ProductCode)), ''), '-') AS RefCode,
--     ISNULL(NULLIF(LTRIM(RTRIM(p.Referance)), ''), '-') AS Referans,

--     ISNULL(
--         NULLIF(
--             LTRIM(RTRIM(ISNULL(cu.Name, '') + ' ' + ISNULL(cu.LastName, '')))
--         , '')
--     , '-') AS Musteri,

--     ISNULL(NULLIF(LTRIM(RTRIM(cu.CityName)), ''), '-') AS Lokasyon,
--     ISNULL(NULLIF(LTRIM(RTRIM(cu.DistrictName)), ''), '-') AS Ilce,
--     ISNULL(NULLIF(LTRIM(RTRIM(cu.CountryName)), ''), '-') AS Ulke,
--     ISNULL(NULLIF(LTRIM(RTRIM(cu.Info)), ''), '-') AS MusteriInfo,

--     CASE
--         WHEN cu.IsShopping = 1 THEN N'Evet'
--         WHEN cu.IsShopping = 0 THEN N'Hayır'
--         ELSE '-'
--     END AS AlisverisiVarMi,

--     ISNULL(NULLIF(LTRIM(RTRIM(cu.Tel)), ''), '-') AS IrtibatNumarasi,
--     ISNULL(NULLIF(LTRIM(RTRIM(cu.Email)), ''), '-') AS EmailAdresi,

--     ISNULL(NULLIF(LTRIM(RTRIM(cr.ContactResourceName)), ''), '-') AS IletisimKaynagi,

--     ISNULL(NULLIF(LTRIM(RTRIM(p.CategoryName)), ''), '-') AS CategoryName,
--     '-' AS CategoryCode,

--     ISNULL(NULLIF(LTRIM(RTRIM(ls.Name)), ''), '-') AS LeadDurumu,
--     ISNULL(NULLIF(LTRIM(RTRIM(ns.Name)), ''), '-') AS SonrakiAdim,

--     ISNULL(NULLIF(LTRIM(RTRIM(lp.Name)), ''), '-') AS ProcessName,
--     ISNULL(NULLIF(LTRIM(RTRIM(lp.Code)), ''), '-') AS ProcessCode,
--     lp.StepOrder,
    
--     -- DÜZELTİLEN ALAN: SelectedStepOrder
--     CASE
--         WHEN EXISTS
--         (
--             SELECT 1
--             FROM tmscrq.TMLeadReservation r
--             WHERE r.LeadId = l.Id
--               AND r.IsActive = 1
--               AND ISNULL(r.IsApproved,0) = 0
--         )
--         THEN 10
--         ELSE lp.StepOrder
--     END AS SelectedStepOrder,

--     ISNULL(
--         CASE
--             WHEN l.EstimatedDate IS NOT NULL
--             THEN CAST(YEAR(l.EstimatedDate) AS VARCHAR(4)) + ' ' + DATENAME(MONTH, l.EstimatedDate)
--             ELSE NULL
--         END,
--         '-'
--     ) AS TerminTarihi,

--     ISNULL(
--         NULLIF(
--             LTRIM(RTRIM(ISNULL(sp.FirstName, '') + ' ' + ISNULL(sp.LastName, '')))
--         , '')
--     , '-') AS SatisDanismani,

--     ISNULL(NULLIF(LTRIM(RTRIM(st.StoreDesc)), ''), '-') AS StoreName

-- FROM tmscrq.TMLead l
-- LEFT JOIN tmscrq.TMLeadStatu ls
--     ON ls.Id = l.StatuId
-- LEFT JOIN tmscrq.TMCustomer cu
--     ON cu.Id = l.CustomerId
-- LEFT JOIN tmscrq.TMProduct p
--     ON p.Id = l.ProductId
-- LEFT JOIN tmscrq.TMContactResource cr
--     ON cr.Id = l.ContactResourceId
-- LEFT JOIN dbo.KUser sp
--     ON sp.Id = l.SalesPersonKUserId
-- LEFT JOIN tmscrq.TMStore st
--     ON st.Id = l.StoreId
-- LEFT JOIN tmscrq.TMLeadProcess lp
--     ON lp.Id = l.ProcessID
-- LEFT JOIN tmscrq.TMLeadNextStep ns
--     ON ns.Id = l.NextStepId

-- WHERE
-- (
--     EXISTS
--     (
--         SELECT 1
--         FROM dbo.KUserRole ur
--         INNER JOIN dbo.KRole r
--             ON r.Id = ur.KRole_Id
--         WHERE ur.KUser_Id = @UserId
--           AND ur.IsDeleted = 0
--           AND r.IsDeleted = 0
--           AND r.Name IN ('TimesYonetici', 'TimesUstYonetici')
--     )
--     OR
--     (
--         EXISTS
--         (
--             SELECT 1
--             FROM dbo.KUserRole ur
--             INNER JOIN dbo.KRole r
--                 ON r.Id = ur.KRole_Id
--             WHERE ur.KUser_Id = @UserId
--               AND ur.IsDeleted = 0
--               AND r.IsDeleted = 0
--               AND r.Name IN ('TimesMagazaMuduru', 'TimesSatisPersoneli')
--         )
--         AND EXISTS
--         (
--             SELECT 1
--             FROM tmscrq.TMUser tu
--             WHERE tu.KUserID = @UserId
--               AND tu.StoreId = l.StoreId
--         )
--     )
-- )

-- AND
-- (
--     @MusteriAdi IS NULL
--     OR LTRIM(RTRIM(@MusteriAdi)) = ''
--     OR UPPER(LTRIM(RTRIM(ISNULL(cu.Name,'') + ' ' + ISNULL(cu.LastName,''))))
--        LIKE '%' + UPPER(LTRIM(RTRIM(@MusteriAdi))) + '%'
-- )

-- AND
-- (
--     @ProductName IS NULL
--     OR LTRIM(RTRIM(@ProductName)) = ''
--     OR
--     (
--         CHARINDEX(',', @ProductName) > 0
--         AND ISNULL(LTRIM(RTRIM(p.ProductName)), '') IN
--         (
--             SELECT LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', '')))
--             FROM STRING_SPLIT(CAST(@ProductName AS NVARCHAR(MAX)), ',')
--             WHERE LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', ''))) <> ''
--         )
--     )
--     OR
--     (
--         CHARINDEX(',', @ProductName) = 0
--         AND UPPER(ISNULL(LTRIM(RTRIM(p.ProductName)), ''))
--             LIKE '%' + UPPER(LTRIM(RTRIM(@ProductName))) + '%'
--     )
-- )

-- AND
-- (
--     @LeadCode IS NULL
--     OR LTRIM(RTRIM(@LeadCode)) = ''
--     OR UPPER(ISNULL(LTRIM(RTRIM(l.LeadCode)), '')) LIKE '%' + UPPER(LTRIM(RTRIM(@LeadCode))) + '%'
-- )

-- AND
-- (
--     @Tel IS NULL
--     OR LTRIM(RTRIM(@Tel)) = ''
--     OR UPPER(ISNULL(LTRIM(RTRIM(cu.Tel)), '')) LIKE '%' + UPPER(LTRIM(RTRIM(@Tel))) + '%'
-- )

-- AND
-- (
--     @CategoryName IS NULL
--     OR LTRIM(RTRIM(@CategoryName)) = ''
--     OR UPPER(ISNULL(LTRIM(RTRIM(p.CategoryName)), '')) IN
--     (
--         SELECT UPPER(LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value,'""',''),'[',''),']',''))))
--         FROM STRING_SPLIT(CAST(@CategoryName AS NVARCHAR(MAX)), ',')
--         WHERE LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value,'""',''),'[',''),']',''))) <> ''
--     )
-- )

-- AND
-- (
--     @StoreIds IS NULL
--     OR LTRIM(RTRIM(@StoreIds)) = ''
--     OR EXISTS
--     (
--         SELECT 1
--         FROM STRING_SPLIT(CAST(@StoreIds AS NVARCHAR(MAX)), ',') s
--         WHERE l.StoreId = TRY_CONVERT
--         (
--             uniqueidentifier,
--             LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(s.value, '""', ''), '[', ''), ']', '')))
--         )
--     )
-- )

-- AND
-- (
--     @SatisDanismaniIds IS NULL
--     OR LTRIM(RTRIM(@SatisDanismaniIds)) = ''
--     OR EXISTS
--     (
--         SELECT 1
--         FROM STRING_SPLIT(CAST(@SatisDanismaniIds AS NVARCHAR(MAX)), ',') s
--         WHERE l.SalesPersonKUserId = TRY_CONVERT
--         (
--             uniqueidentifier,
--             LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(s.value, '""', ''), '[', ''), ']', '')))
--         )
--     )
-- )

-- AND
-- (
--     @ProcessCode IS NULL
--     OR LTRIM(RTRIM(@ProcessCode)) = ''
--     OR UPPER(ISNULL(LTRIM(RTRIM(lp.Code)), '')) IN
--     (
--         SELECT UPPER(LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', ''))))
--         FROM STRING_SPLIT(CAST(@ProcessCode AS NVARCHAR(MAX)), ',')
--         WHERE LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', ''))) <> ''
--     )
-- )

-- -- DÜZELTİLEN ALAN: @StepOrder Filtresi (tek blok)
-- AND
-- (
--     @StepOrder IS NULL

--     OR

--     (
--         @StepOrder = 10
--         AND EXISTS
--         (
--             SELECT 1
--             FROM tmscrq.TMLeadReservation r
--             WHERE r.LeadId = l.Id
--               AND r.IsActive = 1
--               AND ISNULL(r.IsApproved,0) = 0
--         )
--     )

--     OR

--     (
--         @StepOrder <> 10
--         AND lp.StepOrder = @StepOrder
--     )
-- )

-- AND
-- (
--     @StartDate IS NULL
--     OR LTRIM(RTRIM(@StartDate)) = ''
--     OR l.CreatedAt >= CONVERT(date, @StartDate)
-- )

-- AND
-- (
--     @EndDate IS NULL
--     OR LTRIM(RTRIM(@EndDate)) = ''
--     OR l.CreatedAt < DATEADD(day, 1, CONVERT(date, @EndDate))
-- )

-- ORDER BY l.CreatedAt DESC;



SET LANGUAGE Turkish;

SELECT
CASE 
    WHEN EXISTS (
        SELECT 1 
        FROM tmscrq.TMLeadReservation r
        WHERE r.LeadId = l.Id
          AND r.IsActive = 1
          AND r.IsApproved = 1
    ) THEN N'Evet'

    WHEN EXISTS (
        SELECT 1 
        FROM tmscrq.TMLeadReservation r
        WHERE r.LeadId = l.Id
          AND r.IsActive = 1
          AND ISNULL(r.IsApproved,0) = 0
    ) THEN N'Onay Bekliyor'

    ELSE N'Hayır'
END AS RezerveDurumu,
    l.Id AS LeadId,
    l.IsReserved,
    ISNULL(NULLIF(LTRIM(RTRIM(l.LeadCode)), ''), '-') AS LeadNumarasi,
     FORMAT(l.CreatedAt, 'dd MMMM yyyy', 'tr-TR') AS TalepTarihi,

    p.Id AS ProductId,
    ISNULL(NULLIF(LTRIM(RTRIM(p.ProductName)), ''), '-') AS ProductName,
    ISNULL(NULLIF(LTRIM(RTRIM(p.Bracelet)), ''), '-') AS Bilezik,
    ISNULL(NULLIF(LTRIM(RTRIM(p.Brand)), ''), '-') AS Brand,
    ISNULL(NULLIF(LTRIM(RTRIM(p.Dial)), ''), '-') AS Kadran,
    ISNULL(NULLIF(LTRIM(RTRIM(p.ProductCode)), ''), '-') AS RefCode,
    ISNULL(NULLIF(LTRIM(RTRIM(p.Referance)), ''), '-') AS Referans,

    ISNULL(
        NULLIF(
            LTRIM(RTRIM(ISNULL(cu.Name, '') + ' ' + ISNULL(cu.LastName, '')))
        , '')
    , '-') AS Musteri,

    ISNULL(NULLIF(LTRIM(RTRIM(cu.CityName)), ''), '-') AS Lokasyon,
    ISNULL(NULLIF(LTRIM(RTRIM(cu.DistrictName)), ''), '-') AS Ilce,
    ISNULL(NULLIF(LTRIM(RTRIM(cu.CountryName)), ''), '-') AS Ulke,
    ISNULL(NULLIF(LTRIM(RTRIM(cu.Info)), ''), '-') AS MusteriInfo,

    CASE
        WHEN cu.IsShopping = 1 THEN N'Evet'
        WHEN cu.IsShopping = 0 THEN N'Hayır'
        ELSE '-'
    END AS AlisverisiVarMi,

    ISNULL(NULLIF(LTRIM(RTRIM(cu.Tel)), ''), '-') AS IrtibatNumarasi,
    ISNULL(NULLIF(LTRIM(RTRIM(cu.Email)), ''), '-') AS EmailAdresi,

    ISNULL(NULLIF(LTRIM(RTRIM(cr.ContactResourceName)), ''), '-') AS IletisimKaynagi,

    ISNULL(NULLIF(LTRIM(RTRIM(p.CategoryName)), ''), '-') AS CategoryName,
    '-' AS CategoryCode,

    ISNULL(NULLIF(LTRIM(RTRIM(ls.Name)), ''), '-') AS LeadDurumu,
    ISNULL(NULLIF(LTRIM(RTRIM(ns.Name)), ''), '-') AS SonrakiAdim,

    ISNULL(NULLIF(LTRIM(RTRIM(lp.Name)), ''), '-') AS ProcessName,
    ISNULL(NULLIF(LTRIM(RTRIM(lp.Code)), ''), '-') AS ProcessCode,
    lp.StepOrder,
    
    -- DÜZELTİLEN ALAN: SelectedStepOrder
    CASE
        WHEN EXISTS
        (
            SELECT 1
            FROM tmscrq.TMLeadReservation r
            WHERE r.LeadId = l.Id
              AND r.IsActive = 1
              AND ISNULL(r.IsApproved,0) = 0
        )
        THEN 10
        ELSE lp.StepOrder
    END AS SelectedStepOrder,

    ISNULL(
        CASE
            WHEN l.EstimatedDate IS NOT NULL
            THEN CAST(YEAR(l.EstimatedDate) AS VARCHAR(4)) + ' ' + DATENAME(MONTH, l.EstimatedDate)
            ELSE NULL
        END,
        '-'
    ) AS TerminTarihi,

    ISNULL(
        NULLIF(
            LTRIM(RTRIM(ISNULL(sp.FirstName, '') + ' ' + ISNULL(sp.LastName, '')))
        , '')
    , '-') AS SatisDanismani,

    ISNULL(NULLIF(LTRIM(RTRIM(st.StoreDesc)), ''), '-') AS StoreName

FROM tmscrq.TMLead l
LEFT JOIN tmscrq.TMLeadStatu ls
    ON ls.Id = l.StatuId
LEFT JOIN tmscrq.TMCustomer cu
    ON cu.Id = l.CustomerId
LEFT JOIN tmscrq.TMProduct p
    ON p.Id = l.ProductId
LEFT JOIN tmscrq.TMContactResource cr
    ON cr.Id = l.ContactResourceId
LEFT JOIN dbo.KUser sp
    ON sp.Id = l.SalesPersonKUserId
LEFT JOIN tmscrq.TMStore st
    ON st.Id = l.StoreId
LEFT JOIN tmscrq.TMLeadProcess lp
    ON lp.Id = l.ProcessID
LEFT JOIN tmscrq.TMLeadNextStep ns
    ON ns.Id = l.NextStepId

WHERE
(
    EXISTS
    (
        SELECT 1
        FROM dbo.KUserRole ur
        INNER JOIN dbo.KRole r
            ON r.Id = ur.KRole_Id
        WHERE ur.KUser_Id = @UserId
          AND ur.IsDeleted = 0
          AND r.IsDeleted = 0
          AND r.Name IN ('TimesYonetici', 'TimesUstYonetici')
    )
    OR
    (
        EXISTS
        (
            SELECT 1
            FROM dbo.KUserRole ur
            INNER JOIN dbo.KRole r
                ON r.Id = ur.KRole_Id
            WHERE ur.KUser_Id = @UserId
              AND ur.IsDeleted = 0
              AND r.IsDeleted = 0
              AND r.Name IN ('TimesMagazaMuduru', 'TimesSatisPersoneli')
        )
        AND EXISTS
        (
            SELECT 1
            FROM tmscrq.TMUser tu
            WHERE tu.KUserID = @UserId
              AND tu.StoreId = l.StoreId
        )
    )
)

AND
(
    ISNULL(@MusteriAdi, '') = ''
    OR UPPER(ISNULL(cu.Name, '')) LIKE '%' + UPPER(LTRIM(RTRIM(@MusteriAdi))) + '%'
    OR UPPER(ISNULL(cu.LastName, '')) LIKE '%' + UPPER(LTRIM(RTRIM(@MusteriAdi))) + '%'
    OR UPPER(
        ISNULL(cu.Name, '') + ' ' + ISNULL(cu.LastName, '')
    ) LIKE '%' + UPPER(LTRIM(RTRIM(@MusteriAdi))) + '%'
)

AND
(
    @ProductName IS NULL
    OR LTRIM(RTRIM(@ProductName)) = ''
    OR
    (
        CHARINDEX(',', @ProductName) > 0
        AND ISNULL(LTRIM(RTRIM(p.ProductName)), '') IN
        (
            SELECT LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', '')))
            FROM STRING_SPLIT(CAST(@ProductName AS NVARCHAR(MAX)), ',')
            WHERE LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', ''))) <> ''
        )
    )
    OR
    (
        CHARINDEX(',', @ProductName) = 0
        AND UPPER(ISNULL(LTRIM(RTRIM(p.ProductName)), ''))
            LIKE '%' + UPPER(LTRIM(RTRIM(@ProductName))) + '%'
    )
)

AND
(
    ISNULL(@LeadCode, '') = ''
    OR UPPER(ISNULL(l.LeadCode, ''))
        LIKE '%' + UPPER(LTRIM(RTRIM(@LeadCode))) + '%'
    OR REPLACE(
        REPLACE(
            REPLACE(
                UPPER(ISNULL(l.LeadCode, '')),
                '-', ''
            ),
            ' ', ''
        ),
        '/', ''
    )
    LIKE '%' +
    REPLACE(
        REPLACE(
            REPLACE(
                UPPER(LTRIM(RTRIM(@LeadCode))),
                '-', ''
            ),
            ' ', ''
        ),
        '/', ''
    )
    + '%'
)

AND
(
    @Tel IS NULL
    OR LTRIM(RTRIM(@Tel)) = ''
    OR UPPER(ISNULL(LTRIM(RTRIM(cu.Tel)), '')) LIKE '%' + UPPER(LTRIM(RTRIM(@Tel))) + '%'
)

AND
(
    @CategoryName IS NULL
    OR LTRIM(RTRIM(@CategoryName)) = ''
    OR UPPER(ISNULL(LTRIM(RTRIM(p.CategoryName)), '')) IN
    (
        SELECT UPPER(LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value,'""',''),'[',''),']',''))))
        FROM STRING_SPLIT(CAST(@CategoryName AS NVARCHAR(MAX)), ',')
        WHERE LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value,'""',''),'[',''),']',''))) <> ''
    )
)

AND
(
    @StoreIds IS NULL
    OR LTRIM(RTRIM(@StoreIds)) = ''
    OR EXISTS
    (
        SELECT 1
        FROM STRING_SPLIT(CAST(@StoreIds AS NVARCHAR(MAX)), ',') s
        WHERE l.StoreId = TRY_CONVERT
        (
            uniqueidentifier,
            LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(s.value, '""', ''), '[', ''), ']', '')))
        )
    )
)

AND
(
    @SatisDanismaniIds IS NULL
    OR LTRIM(RTRIM(@SatisDanismaniIds)) = ''
    OR EXISTS
    (
        SELECT 1
        FROM STRING_SPLIT(CAST(@SatisDanismaniIds AS NVARCHAR(MAX)), ',') s
        WHERE l.SalesPersonKUserId = TRY_CONVERT
        (
            uniqueidentifier,
            LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(s.value, '""', ''), '[', ''), ']', '')))
        )
    )
)

AND
(
    ISNULL(@ProcessCode, '') = ''
    OR EXISTS
    (
        SELECT 1
        FROM STRING_SPLIT(
            CONVERT(NVARCHAR(MAX), @ProcessCode),
            ','
        ) AS s
        WHERE
            UPPER(LTRIM(RTRIM(s.value))) =
            UPPER(LTRIM(RTRIM(ISNULL(lp.Code, ''))))
    )
)

-- DÜZELTİLEN ALAN: @StepOrder Filtresi (0 verilince tümü gelsin)
AND
(
    @StepOrder IS NULL
    OR @StepOrder = 0  -- 👈 YENİ EKLENDI: 0 verilince tüm kayıtlar gelir
    OR
    (
        @StepOrder = 10
        AND EXISTS
        (
            SELECT 1
            FROM tmscrq.TMLeadReservation r
            WHERE r.LeadId = l.Id
              AND r.IsActive = 1
              AND ISNULL(r.IsApproved,0) = 0
        )
    )
    OR
    (
        @StepOrder <> 10
        AND lp.StepOrder = @StepOrder
    )
)

AND
(
    @StartDate IS NULL
    OR LTRIM(RTRIM(@StartDate)) = ''
    OR l.CreatedAt >= CONVERT(date, @StartDate)
)

AND
(
    @EndDate IS NULL
    OR LTRIM(RTRIM(@EndDate)) = ''
    OR l.CreatedAt < DATEADD(day, 1, CONVERT(date, @EndDate))
)

ORDER BY l.CreatedAt DESC;", new string[] { "RezerveDurumu", "LeadId", "IsReserved", "LeadNumarasi", "TalepTarihi", "ProductId", "ProductName", "Bilezik", "Brand", "Kadran", "RefCode", "Referans", "Musteri", "Lokasyon", "Ilce", "Ulke", "MusteriInfo", "AlisverisiVarMi", "IrtibatNumarasi", "EmailAdresi", "IletisimKaynagi", "CategoryName", "CategoryCode", "LeadDurumu", "SonrakiAdim", "ProcessName", "ProcessCode", "StepOrder", "SelectedStepOrder", "TerminTarihi", "SatisDanismani", "StoreName" }, prms_TM_GetLeads_0.ToArray());
            ;

            var prms_TMLeadProcessCountSummary_1 = new List<kSqlParameter>();
            prms_TMLeadProcessCountSummary_1.Add(new kSqlParameter() { Name = "UserId", Value = Kuika.Common.KContext.CurrentUser?.Id });
            prms_TMLeadProcessCountSummary_1.Add(new kSqlParameter() { Name = "MusteriAdi", Value = (null as object) });
            prms_TMLeadProcessCountSummary_1.Add(new kSqlParameter() { Name = "ProductName", Value = (null as object) });
            prms_TMLeadProcessCountSummary_1.Add(new kSqlParameter() { Name = "LeadCode", Value = (null as object) });
            prms_TMLeadProcessCountSummary_1.Add(new kSqlParameter() { Name = "Tel", Value = (null as object) });
            prms_TMLeadProcessCountSummary_1.Add(new kSqlParameter() { Name = "CategoryName", Value = (null as object) });
            prms_TMLeadProcessCountSummary_1.Add(new kSqlParameter() { Name = "StoreIds", Value = (null as object) });
            prms_TMLeadProcessCountSummary_1.Add(new kSqlParameter() { Name = "SatisDanismaniIds", Value = (null as object) });
            prms_TMLeadProcessCountSummary_1.Add(new kSqlParameter() { Name = "ProcessCode", Value = (null as object) });
            prms_TMLeadProcessCountSummary_1.Add(new kSqlParameter() { Name = "StartDate", Value = (null as object) });
            prms_TMLeadProcessCountSummary_1.Add(new kSqlParameter() { Name = "EndDate", Value = (null as object) });
            using var auditTMLeadProcessCountSummary_1 = ActionAuditScope.Begin("41780011-a005-a8d3-d047-e7da972ca656", "TMLeadProcessCountSummary", applicationName: "wbTimesCRM", screenOrEndpointName: "LeadList");
            result.TMLeadProcessCountSummary = KPersister.Fetch(KContext.GetConnectionString(), @"-- SELECT
--     COUNT(*) AS ToplamTalepSayisi,

--     SUM(CASE WHEN lp.Code = 'PENDING' THEN 1 ELSE 0 END) AS OnayBekleyenSayisi,
--     SUM(CASE WHEN lp.Code = 'TERMIN_PENDING' THEN 1 ELSE 0 END) AS TerminBekleyenSayisi,
--     SUM(CASE WHEN lp.Code = 'APPROVED' THEN 1 ELSE 0 END) AS OnaylananSayisi,
--     SUM(CASE WHEN lp.Code = 'REJECTED' THEN 1 ELSE 0 END) AS ReddedilenSayisi,
--     SUM(CASE WHEN lp.Code = 'DELIVERY_PENDING' THEN 1 ELSE 0 END) AS TeslimEdilecekSayisi,
--     SUM(CASE WHEN lp.Code = 'DELIVERED' THEN 1 ELSE 0 END) AS TeslimEdildiSayisi

-- FROM tmscrq.TMLead l
-- LEFT JOIN tmscrq.TMCustomer cu
--     ON cu.Id = l.CustomerId
-- LEFT JOIN tmscrq.TMProduct p
--     ON p.Id = l.ProductId
-- LEFT JOIN dbo.KUser sp
--     ON sp.Id = l.SalesPersonKUserId
-- LEFT JOIN tmscrq.TMLeadProcess lp
--     ON lp.Id = l.ProcessID

-- WHERE
-- (
--     EXISTS
--     (
--         SELECT 1
--         FROM dbo.KUserRole ur
--         INNER JOIN dbo.KRole r
--             ON r.Id = ur.KRole_Id
--         WHERE ur.KUser_Id = @UserId
--           AND ur.IsDeleted = 0
--           AND r.IsDeleted = 0
--           AND r.Name IN ('TimesYonetici', 'TimesUstYonetici')
--     )
--     OR
--     (
--         EXISTS
--         (
--             SELECT 1
--             FROM dbo.KUserRole ur
--             INNER JOIN dbo.KRole r
--                 ON r.Id = ur.KRole_Id
--             WHERE ur.KUser_Id = @UserId
--               AND ur.IsDeleted = 0
--               AND r.IsDeleted = 0
--               AND r.Name IN ('TimesMagazaMuduru', 'TimesSatisPersoneli')
--         )
--         AND EXISTS
--         (
--             SELECT 1
--             FROM tmscrq.TMUser tu
--             WHERE tu.KUserID = @UserId
--               AND tu.StoreId = l.StoreId
--         )
--     )
-- )

-- AND
-- (
--     @MusteriAdi IS NULL
--     OR LTRIM(RTRIM(@MusteriAdi)) = ''
--     OR UPPER(LTRIM(RTRIM(ISNULL(cu.Name, '') + ' ' + ISNULL(cu.LastName, ''))))
--        LIKE '%' + UPPER(LTRIM(RTRIM(@MusteriAdi))) + '%'
-- )

-- AND
-- (
--     @ProductName IS NULL
--     OR LTRIM(RTRIM(@ProductName)) = ''
--     OR
--     (
--         CHARINDEX(',', @ProductName) > 0
--         AND ISNULL(LTRIM(RTRIM(p.ProductName)), '') IN
--         (
--             SELECT LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', '')))
--             FROM STRING_SPLIT(CAST(@ProductName AS NVARCHAR(MAX)), ',')
--             WHERE LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', ''))) <> ''
--         )
--     )
--     OR
--     (
--         CHARINDEX(',', @ProductName) = 0
--         AND UPPER(ISNULL(LTRIM(RTRIM(p.ProductName)), ''))
--             LIKE '%' + UPPER(LTRIM(RTRIM(@ProductName))) + '%'
--     )
-- )

-- AND
-- (
--     @LeadCode IS NULL
--     OR LTRIM(RTRIM(@LeadCode)) = ''
--     OR UPPER(ISNULL(LTRIM(RTRIM(l.LeadCode)), '')) LIKE '%' + UPPER(LTRIM(RTRIM(@LeadCode))) + '%'
-- )

-- AND
-- (
--     @Tel IS NULL
--     OR LTRIM(RTRIM(@Tel)) = ''
--     OR UPPER(ISNULL(LTRIM(RTRIM(cu.Tel)), '')) LIKE '%' + UPPER(LTRIM(RTRIM(@Tel))) + '%'
-- )

-- AND
-- (
--     @CategoryName IS NULL
--     OR LTRIM(RTRIM(@CategoryName)) = ''
--     OR
--     (
--         EXISTS
--         (
--             SELECT 1
--             FROM STRING_SPLIT(CAST(@CategoryName AS NVARCHAR(MAX)), ',') c
--             WHERE UPPER(LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(c.value, '""', ''), '[', ''), ']', '')))) = 'DEFAULT'
--         )
--         AND (p.CategoryName IS NULL OR LTRIM(RTRIM(p.CategoryName)) = '')
--     )
--     OR UPPER(ISNULL(LTRIM(RTRIM(p.CategoryName)), '')) IN
--     (
--         SELECT UPPER(LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', ''))))
--         FROM STRING_SPLIT(CAST(@CategoryName AS NVARCHAR(MAX)), ',')
--         WHERE LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', ''))) <> ''
--           AND UPPER(LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', '')))) <> 'DEFAULT'
--     )
-- )

-- AND
-- (
--     @StoreIds IS NULL
--     OR LTRIM(RTRIM(@StoreIds)) = ''
--     OR EXISTS
--     (
--         SELECT 1
--         FROM STRING_SPLIT(CAST(@StoreIds AS NVARCHAR(MAX)), ',') s
--         WHERE l.StoreId = TRY_CONVERT
--         (
--             uniqueidentifier,
--             LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(s.value, '""', ''), '[', ''), ']', '')))
--         )
--     )
-- )

-- AND
-- (
--     @SatisDanismaniIds IS NULL
--     OR LTRIM(RTRIM(@SatisDanismaniIds)) = ''
--     OR EXISTS
--     (
--         SELECT 1
--         FROM STRING_SPLIT(CAST(@SatisDanismaniIds AS NVARCHAR(MAX)), ',') s
--         WHERE l.SalesPersonKUserId = TRY_CONVERT
--         (
--             uniqueidentifier,
--             LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(s.value, '""', ''), '[', ''), ']', '')))
--         )
--     )
-- )

-- AND
-- (
--     @ProcessCode IS NULL
--     OR LTRIM(RTRIM(@ProcessCode)) = ''
--     OR UPPER(ISNULL(LTRIM(RTRIM(lp.Code)), '')) IN
--     (
--         SELECT UPPER(LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', ''))))
--         FROM STRING_SPLIT(CAST(@ProcessCode AS NVARCHAR(MAX)), ',')
--         WHERE LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', ''))) <> ''
--     )
-- )

-- AND
-- (
--     @StartDate IS NULL
--     OR LTRIM(RTRIM(@StartDate)) = ''
--     OR l.CreatedAt >= CONVERT(date, @StartDate)
-- )

-- AND
-- (
--     @EndDate IS NULL
--     OR LTRIM(RTRIM(@EndDate)) = ''
--     OR l.CreatedAt < DATEADD(day, 1, CONVERT(date, @EndDate))
-- );

-------------------------------------------------------------

DECLARE @KUserId UNIQUEIDENTIFIER = @UserId;

WITH UserRoles AS (
    SELECT r.Name
    FROM dbo.KUserRole ur
    INNER JOIN dbo.KRole r 
        ON r.Id = ur.KRole_Id
    WHERE ur.KUser_Id = @KUserId
      AND ur.IsDeleted = 0
      AND r.IsDeleted = 0
),
IsAdmin AS (
    SELECT CASE 
        WHEN EXISTS (
            SELECT 1 
            FROM UserRoles 
            WHERE Name = 'TimesUstYonetici'
        ) THEN 1 ELSE 0 END AS IsAdmin
)

SELECT
    COUNT(*) AS ToplamTalepSayisi,

    SUM(CASE WHEN lp.Code = 'PENDING' THEN 1 ELSE 0 END) AS OnayBekleyenSayisi,
    SUM(CASE WHEN lp.Code = 'TERMIN_PENDING' THEN 1 ELSE 0 END) AS TerminBekleyenSayisi,
    SUM(CASE WHEN lp.Code = 'APPROVED' THEN 1 ELSE 0 END) AS OnaylananSayisi,
    SUM(CASE WHEN lp.Code = 'REJECTED' THEN 1 ELSE 0 END) AS ReddedilenSayisi,
    SUM(CASE WHEN lp.Code = 'DELIVERY_PENDING' THEN 1 ELSE 0 END) AS TeslimEdilecekSayisi,
    SUM(CASE WHEN lp.Code = 'DELIVERED' THEN 1 ELSE 0 END) AS TeslimEdildiSayisi

FROM tmscrq.TMLead l
LEFT JOIN tmscrq.TMCustomer cu
    ON cu.Id = l.CustomerId
LEFT JOIN tmscrq.TMProduct p
    ON p.Id = l.ProductId
LEFT JOIN dbo.KUser sp
    ON sp.Id = l.SalesPersonKUserId
LEFT JOIN tmscrq.TMLeadProcess lp
    ON lp.Id = l.ProcessID

CROSS JOIN IsAdmin a

WHERE
(
    -- admin → full
    a.IsAdmin = 1

    -- diğerleri → sadece kendi mağazaları
    OR EXISTS
    (
        SELECT 1
        FROM tmscrq.TMUser tu
        WHERE tu.KUserID = @KUserId
          AND tu.StoreId = l.StoreId
    )
)

-- 🔽 AŞAĞISI SENİN ORİJİNAL FİLTRELER (HİÇ DOKUNMADIM)

AND
(
    @MusteriAdi IS NULL
    OR LTRIM(RTRIM(@MusteriAdi)) = ''
    OR UPPER(LTRIM(RTRIM(ISNULL(cu.Name, '') + ' ' + ISNULL(cu.LastName, ''))))
       LIKE '%' + UPPER(LTRIM(RTRIM(@MusteriAdi))) + '%'
)

AND
(
    @ProductName IS NULL
    OR LTRIM(RTRIM(@ProductName)) = ''
    OR
    (
        CHARINDEX(',', @ProductName) > 0
        AND ISNULL(LTRIM(RTRIM(p.ProductName)), '') IN
        (
            SELECT LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', '')))
            FROM STRING_SPLIT(CAST(@ProductName AS NVARCHAR(MAX)), ',')
        )
    )
    OR
    (
        CHARINDEX(',', @ProductName) = 0
        AND UPPER(ISNULL(LTRIM(RTRIM(p.ProductName)), ''))
            LIKE '%' + UPPER(LTRIM(RTRIM(@ProductName))) + '%'
    )
)

AND
(
    @LeadCode IS NULL
    OR LTRIM(RTRIM(@LeadCode)) = ''
    OR UPPER(ISNULL(LTRIM(RTRIM(l.LeadCode)), '')) LIKE '%' + UPPER(LTRIM(RTRIM(@LeadCode))) + '%'
)

AND
(
    @Tel IS NULL
    OR LTRIM(RTRIM(@Tel)) = ''
    OR UPPER(ISNULL(LTRIM(RTRIM(cu.Tel)), '')) LIKE '%' + UPPER(LTRIM(RTRIM(@Tel))) + '%'
)

AND
(
    @CategoryName IS NULL
    OR LTRIM(RTRIM(@CategoryName)) = ''
    OR
    (
        EXISTS
        (
            SELECT 1
            FROM STRING_SPLIT(CAST(@CategoryName AS NVARCHAR(MAX)), ',') c
            WHERE UPPER(LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(c.value, '""', ''), '[', ''), ']', '')))) = 'DEFAULT'
        )
        AND (p.CategoryName IS NULL OR LTRIM(RTRIM(p.CategoryName)) = '')
    )
    OR UPPER(ISNULL(LTRIM(RTRIM(p.CategoryName)), '')) IN
    (
        SELECT UPPER(LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', ''))))
        FROM STRING_SPLIT(CAST(@CategoryName AS NVARCHAR(MAX)), ',')
    )
)

AND
(
    @StoreIds IS NULL
    OR LTRIM(RTRIM(@StoreIds)) = ''
    OR EXISTS
    (
        SELECT 1
        FROM STRING_SPLIT(CAST(@StoreIds AS NVARCHAR(MAX)), ',') s
        WHERE l.StoreId = TRY_CONVERT
        (
            uniqueidentifier,
            LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(s.value, '""', ''), '[', ''), ']', '')))
        )
    )
)

AND
(
    @SatisDanismaniIds IS NULL
    OR LTRIM(RTRIM(@SatisDanismaniIds)) = ''
    OR EXISTS
    (
        SELECT 1
        FROM STRING_SPLIT(CAST(@SatisDanismaniIds AS NVARCHAR(MAX)), ',') s
        WHERE l.SalesPersonKUserId = TRY_CONVERT
        (
            uniqueidentifier,
            LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(s.value, '""', ''), '[', ''), ']', '')))
        )
    )
)

AND
(
    @ProcessCode IS NULL
    OR LTRIM(RTRIM(@ProcessCode)) = ''
    OR UPPER(ISNULL(LTRIM(RTRIM(lp.Code)), '')) IN
    (
        SELECT UPPER(LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', ''))))
        FROM STRING_SPLIT(CAST(@ProcessCode AS NVARCHAR(MAX)), ',')
    )
)

AND
(
    @StartDate IS NULL
    OR LTRIM(RTRIM(@StartDate)) = ''
    OR l.CreatedAt >= CONVERT(date, @StartDate)
)

AND
(
    @EndDate IS NULL
    OR LTRIM(RTRIM(@EndDate)) = ''
    OR l.CreatedAt < DATEADD(day, 1, CONVERT(date, @EndDate))
);", new string[] { "ToplamTalepSayisi", "OnayBekleyenSayisi", "TerminBekleyenSayisi", "OnaylananSayisi", "ReddedilenSayisi", "TeslimEdilecekSayisi", "TeslimEdildiSayisi" }, prms_TMLeadProcessCountSummary_1.ToArray());
            ;

            var prms_TM_GetProductCategory_2 = new List<kSqlParameter>();
            using var auditTM_GetProductCategory_2 = ActionAuditScope.Begin("ae4efc0f-9d47-e86b-f1ee-6649b67e443d", "TM_GetProductCategory", applicationName: "wbTimesCRM", screenOrEndpointName: "LeadList");
            result.TM_GetProductCategory = KPersister.Fetch(KContext.GetConnectionString(), @"SELECT
    pc.CategoryName,
    pc.CategoryCode
FROM tmscrq.TMProductCategory pc
ORDER BY
    pc.CategoryName;", new string[] { "CategoryName", "CategoryCode" }, prms_TM_GetProductCategory_2.ToArray());
            ;

            var prms_TM_GetProductReferanceFilter_3 = new List<kSqlParameter>();
            using var auditTM_GetProductReferanceFilter_3 = ActionAuditScope.Begin("d5fd63ae-0c1f-2328-00a5-3edd55de0a44", "TM_GetProductReferanceFilter", applicationName: "wbTimesCRM", screenOrEndpointName: "LeadList");
            result.TM_GetProductReferanceFilter = KPersister.Fetch(KContext.GetConnectionString(), @"SELECT DISTINCT
    p.ProductName,
    p.Brand,
    p.Referance
FROM tmscrq.TMLead l
INNER JOIN tmscrq.TMProduct p ON p.Id = l.ProductId
WHERE p.Brand IN ('Tudor', 'Rolex')
and IsDeleted=0
ORDER BY p.Brand, p.ProductName;
", new string[] { "ProductName", "Brand", "Referance" }, prms_TM_GetProductReferanceFilter_3.ToArray());
            ;

            var prms_TM_GetCustomerByName_4 = new List<kSqlParameter>();
            using var auditTM_GetCustomerByName_4 = ActionAuditScope.Begin("47eaefee-44f7-082d-5776-053737904a0b", "TM_GetCustomerByName", applicationName: "wbTimesCRM", screenOrEndpointName: "LeadList");
            result.TM_GetCustomerByName = KPersister.Fetch(KContext.GetConnectionString(), @"-- ============================================================
-- DT-047 · TM_GetCustomerByName — GUNCEL HALI
-- Ekran: FreeSalesWeb, LeadAdd, LeadAddByExcelAI, LeadAddByExcelcopy,
--         LeadAddChangeProduct, LeadAddTemp, LeadDetailSalesPerson,
--         LeadList, LeadListTemp, LeadUpdate, SalesWeb,
--         SatisIslemi, TalepSatisIslemi
--
-- UI response kolonlari degismedi.
-- CurrAccDescription sadece:
--   1) FullName fallback
--   2) isim kalite filtresi
-- icin kullaniliyor.
-- ============================================================

SELECT
    Id,

    CONCAT_WS(
        ' ',

        COALESCE(
            NULLIF(
                LTRIM(RTRIM(
                    ISNULL(Name, '') +
                    CASE
                        WHEN LastName IS NOT NULL
                             AND LTRIM(RTRIM(LastName)) <> ''
                        THEN ' ' + LTRIM(RTRIM(LastName))
                        ELSE ''
                    END
                )),
                ''
            ),
            NULLIF(LTRIM(RTRIM(CurrAccDescription)), ''),
            ''
        ),

        Tel,
        NationalID
    ) AS FullName,

    Tel        AS TelefonNum,
    NationalID AS TC

FROM tmscrq.TMCustomer

WHERE
    IsDeleted = 0

    --------------------------------------------------
    -- ISIM KALITE FILTRESI
    --------------------------------------------------
    AND
    (
        (
            NULLIF(
                LTRIM(RTRIM(
                    ISNULL(Name, '')
                    + ISNULL(LastName, '')
                )),
                ''
            ) IS NOT NULL

            AND LTRIM(RTRIM(ISNULL(Name, '')))
                NOT IN ('-', '.', '""""')

            AND LTRIM(RTRIM(ISNULL(Name, '')))
                <> LTRIM(RTRIM(ISNULL(CurrAccCode, '')))

            AND
            (
                ISNULL(Name, '')
                + ' '
                + ISNULL(LastName, '')
            ) LIKE '%[A-Za-zÇŞİÖÜĞçşıöüğ]%'
        )

        OR

        (
            NULLIF(
                LTRIM(RTRIM(CurrAccDescription)),
                ''
            ) IS NOT NULL

            AND LTRIM(RTRIM(CurrAccDescription))
                NOT IN ('-', '.', '""""')

            AND LTRIM(RTRIM(CurrAccDescription))
                <> LTRIM(RTRIM(ISNULL(CurrAccCode, '')))

            AND CurrAccDescription
                LIKE '%[A-Za-zÇŞİÖÜĞçşıöüğ]%'
        )
    )

ORDER BY
    FullName ASC;", new string[] { "Id", "FullName", "TelefonNum", "TC" }, prms_TM_GetCustomerByName_4.ToArray());
            ;

            var prms_TM_GetStore_5 = new List<kSqlParameter>();
            prms_TM_GetStore_5.Add(new kSqlParameter() { Name = "KUserId", Value = Kuika.Common.KContext.CurrentUser?.Id });
            using var auditTM_GetStore_5 = ActionAuditScope.Begin("b5f529e0-e6d6-ebee-ab3f-a2ed7c169492", "TM_GetStore", applicationName: "wbTimesCRM", screenOrEndpointName: "LeadList");
            result.TM_GetStore = KPersister.Fetch(KContext.GetConnectionString(), @"WITH UserRoles AS (
    SELECT r.Name
    FROM KUserRole ur
    INNER JOIN KRole r 
        ON r.Id = ur.KRole_Id
    WHERE ur.KUser_Id = @KUserId
      AND ur.IsDeleted = 0
),
IsAdmin AS (
    SELECT CASE 
        WHEN EXISTS (
            SELECT 1 
            FROM UserRoles 
            WHERE Name = 'TimesUstYonetici'
        ) THEN 1 ELSE 0 END AS IsAdmin
)

SELECT
    s.Id,
    s.StoreDesc,
    s.StoreCode
FROM tmscrq.TMStore s
CROSS JOIN IsAdmin a
WHERE 
    -- sadece numeric store code
    TRY_CAST(s.StoreCode AS INT) IS NOT NULL

    AND (
        -- admin → full liste
        a.IsAdmin = 1

        -- diğerleri → sadece kendi storeları
        OR s.Id IN (
            SELECT tu.StoreID
            FROM tmscrq.TMUser tu
            WHERE tu.KuserID = @KUserId
        )
    )
ORDER BY TRY_CAST(s.StoreCode AS INT);", new string[] { "Id", "StoreDesc", "StoreCode" }, prms_TM_GetStore_5.ToArray());
            ;

            var prms_TM_GetSalesPerson_6 = new List<kSqlParameter>();
            prms_TM_GetSalesPerson_6.Add(new kSqlParameter() { Name = "KUserId", Value = Kuika.Common.KContext.CurrentUser?.Id });
            prms_TM_GetSalesPerson_6.Add(new kSqlParameter() { Name = "StoreId", Value = (null as object) });
            using var auditTM_GetSalesPerson_6 = ActionAuditScope.Begin("4e3a69ad-0bdf-d1e3-70f2-5a205db9b256", "TM_GetSalesPerson", applicationName: "wbTimesCRM", screenOrEndpointName: "LeadList");
            result.TM_GetSalesPerson = KPersister.Fetch(KContext.GetConnectionString(), @"-- SELECT 
--     KU.Id AS KUserId,

--     LTRIM(RTRIM(
--         ISNULL(KU.FirstName, '') + 
--         CASE 
--             WHEN KU.LastName IS NOT NULL AND KU.LastName <> '' 
--             THEN ' ' + KU.LastName 
--             ELSE '' 
--         END
--     )) AS FullName,

--     KU.IsDeleted,

--     STRING_AGG(R.Name, ', ') AS RoleNames,

--     TU.Id AS TMUserId,
--     TU.StoreID,
--     TS.StoreCode,
--     TS.StoreDesc

-- FROM dbo.KUser KU

-- INNER JOIN tmscrq.TMUser TU
--     ON TU.KUserID = KU.Id

-- LEFT JOIN tmscrq.TMStore TS
--     ON TS.Id = TU.StoreID

-- INNER JOIN dbo.KUserRole UR 
--     ON UR.KUser_Id = KU.Id

-- INNER JOIN dbo.KRole R 
--     ON R.Id = UR.KRole_Id
--     AND R.Name IN (
--         'TimesAdmin',
--         'TimesUstYonetici',
--         'TimesYonetici',
--         'TimesSatisPersoneli',
--         'TimesMagazaMuduru'
--     )

-- WHERE 
--     KU.IsDeleted = 0
--     AND UR.IsDeleted = 0
--     AND R.IsDeleted = 0
--     AND (
--         @StoreId IS NULL
--         OR TU.StoreID = @StoreId
--     )

-- GROUP BY 
--     KU.Id,
--     KU.FirstName,
--     KU.LastName,
--     KU.IsDeleted,
--     TU.Id,
--     TU.StoreID,
--     TS.StoreCode,
--     TS.StoreDesc

-- ORDER BY
--     FullName;

-------------------------------------------------



WITH UserRoles AS (
    SELECT r.Name
    FROM dbo.KUserRole ur
    INNER JOIN dbo.KRole r 
        ON r.Id = ur.KRole_Id
    WHERE ur.KUser_Id = @KUserId
      AND ur.IsDeleted = 0
      AND r.IsDeleted = 0
),
IsAdmin AS (
    SELECT CASE 
        WHEN EXISTS (
            SELECT 1 
            FROM UserRoles 
            WHERE Name = 'TimesUstYonetici'
        ) THEN 1 ELSE 0 END AS IsAdmin
),
MyStores AS (
    SELECT StoreID
    FROM tmscrq.TMUser
    WHERE KUserID = @KUserId
)

SELECT 
    KU.Id AS KUserId,

    LTRIM(RTRIM(
        ISNULL(KU.FirstName, '') + 
        CASE 
            WHEN KU.LastName IS NOT NULL AND KU.LastName <> '' 
            THEN ' ' + KU.LastName 
            ELSE '' 
        END
    )) AS FullName,

    STRING_AGG(R.Name, ', ') AS RoleNames,

    TU.Id AS TMUserId,
    TU.StoreID,
    TS.StoreCode,
    TS.StoreDesc

FROM dbo.KUser KU

INNER JOIN tmscrq.TMUser TU
    ON TU.KUserID = KU.Id

LEFT JOIN tmscrq.TMStore TS
    ON TS.Id = TU.StoreID

INNER JOIN dbo.KUserRole UR 
    ON UR.KUser_Id = KU.Id

INNER JOIN dbo.KRole R 
    ON R.Id = UR.KRole_Id
    AND R.Name IN (
        'TimesSatisPersoneli', 'TimesMagazaMuduru' -- sadece satış personelleri gelsin
    )

CROSS JOIN IsAdmin a

WHERE 
    KU.IsDeleted = 0
    AND UR.IsDeleted = 0
    AND R.IsDeleted = 0

    AND
    (
        -- 🔥 1. Store seçilmişse direkt store'a göre
        (
            @StoreId IS NOT NULL
            AND TU.StoreID = @StoreId
        )

        OR

        -- 🔥 2. Store seçilmemişse rol bazlı çalış
        (
            @StoreId IS NULL
            AND
            (
                -- üst yönetici → hepsi
                a.IsAdmin = 1

                -- diğerleri → kendi storeları
                OR TU.StoreID IN (SELECT StoreID FROM MyStores)
            )
        )
    )

GROUP BY 
    KU.Id,
    KU.FirstName,
    KU.LastName,
    TU.Id,
    TU.StoreID,
    TS.StoreCode,
    TS.StoreDesc

ORDER BY
    FullName;", new string[] { "KUserId", "FullName", "RoleNames", "TMUserId", "StoreID", "StoreCode", "StoreDesc" }, prms_TM_GetSalesPerson_6.ToArray());
            ;

            var prms_TM_GetLeadStatus_7 = new List<kSqlParameter>();
            using var auditTM_GetLeadStatus_7 = ActionAuditScope.Begin("b8e23527-65cf-c502-27f5-bace9158ac76", "TM_GetLeadStatus", applicationName: "wbTimesCRM", screenOrEndpointName: "LeadList");
            result.TM_GetLeadStatus = KPersister.Fetch(KContext.GetConnectionString(), @"SELECT *
FROM tmscrq.TMLeadStatu
WHERE Code IN ('FOLLOW_UP_1', 'FOLLOW_UP_2')
ORDER BY 
    CASE Code
        WHEN 'FOLLOW_UP_1' THEN 1
        WHEN 'FOLLOW_UP_2' THEN 2
    END;
", new string[] { "Id", "Code", "Name", "IsActive" }, prms_TM_GetLeadStatus_7.ToArray());
            ;

            var prms_TM_GetLeadProcess_8 = new List<kSqlParameter>();
            prms_TM_GetLeadProcess_8.Add(new kSqlParameter() { Name = "StepOrder", Value = "0".ConvertToType<Int32>() });
            using var auditTM_GetLeadProcess_8 = ActionAuditScope.Begin("a37107ab-78c7-95a6-59f3-70332a9ee4bd", "TM_GetLeadProcess", applicationName: "wbTimesCRM", screenOrEndpointName: "LeadList");
            result.TM_GetLeadProcess = KPersister.Fetch(KContext.GetConnectionString(), @"SELECT
    Id,
    Name,
    Code,
    Note,
    StepOrder
FROM tmscrq.TMLeadProcess
WHERE
    StepOrder IS NOT NULL
    AND StepOrder NOT IN (2, 8, 9)   -- 🔥 EKLENDİ
    AND (
        @StepOrder IS NULL
        OR @StepOrder = 0
        OR StepOrder = @StepOrder
    )
ORDER BY
    StepOrder;", new string[] { "Id", "Name", "Code", "Note", "StepOrder" }, prms_TM_GetLeadProcess_8.ToArray());
            ;

            var prms_TMGetProductAllLeadsMultiSelect_9 = new List<kSqlParameter>();
            using var auditTMGetProductAllLeadsMultiSelect_9 = ActionAuditScope.Begin("76c683db-5bab-2738-efe8-637e83dac8d0", "TMGetProductAllLeadsMultiSelect", applicationName: "wbTimesCRM", screenOrEndpointName: "LeadList");
            result.TMGetProductAllLeadsMultiSelect = KPersister.Fetch(KContext.GetConnectionString(), @"SELECT DISTINCT
    LTRIM(RTRIM(p.ProductName)) AS ProductName
FROM tmscrq.TMLead l
INNER JOIN tmscrq.TMProduct p ON p.Id = l.ProductId
WHERE 
    NULLIF(LTRIM(RTRIM(p.ProductName)), '') IS NOT NULL
    and IsDeleted=0
ORDER BY ProductName", new string[] { "ProductName" }, prms_TMGetProductAllLeadsMultiSelect_9.ToArray());
            ;


            return Ok(result);
        }


        [HttpPost, Route("LeadListComponent_361899_onClick")]
        public IActionResult LeadListComponent_361899_onClick(LeadListComponent_361899_onClick_Request request)
        {

            KProviderManager.Authorization.IsAuthorizedForRoles(appId, appName, screenId, screenName, new List<string> { $"70de6cfc-6087-6059-59b4-0b5a8527af6b", "4da1f213-c8e4-0b50-5c84-02fd13f1a622", "c4e882ef-977d-f613-7694-230ac83919d2", "b4bfd39c-ac02-f442-c899-7a2374a45b47", "cdb536b0-6297-155f-d446-8453d8a60304", "TimesYonetici", "TimesUstYonetici", "TimesSatisPersoneli", "TimesMagazaMuduru", "TimesAdmin" });

            var result = new LeadListComponent_361899_onClick_Response();

            var prms_TM_GetLeads_0 = new List<kSqlParameter>();
            prms_TM_GetLeads_0.Add(new kSqlParameter() { Name = "StepOrder", Value = (null as object) });
            prms_TM_GetLeads_0.Add(new kSqlParameter() { Name = "UserId", Value = Kuika.Common.KContext.CurrentUser?.Id });
            prms_TM_GetLeads_0.Add(new kSqlParameter() { Name = "MusteriAdi", Value = request.MusteriAdi_0 });
            prms_TM_GetLeads_0.Add(new kSqlParameter() { Name = "ProductName", Value = request.ProductName_0 });
            prms_TM_GetLeads_0.Add(new kSqlParameter() { Name = "LeadCode", Value = request.LeadCode_0 });
            prms_TM_GetLeads_0.Add(new kSqlParameter() { Name = "Tel", Value = request.Tel_0 });
            prms_TM_GetLeads_0.Add(new kSqlParameter() { Name = "CategoryName", Value = request.CategoryName_0 });
            prms_TM_GetLeads_0.Add(new kSqlParameter() { Name = "StoreIds", Value = request.StoreIds_0 });
            prms_TM_GetLeads_0.Add(new kSqlParameter() { Name = "SatisDanismaniIds", Value = request.SatisDanismaniIds_0 });
            prms_TM_GetLeads_0.Add(new kSqlParameter() { Name = "ProcessCode", Value = request.ProcessCode_0 });
            prms_TM_GetLeads_0.Add(new kSqlParameter() { Name = "StartDate", Value = request.StartDate_0 });
            prms_TM_GetLeads_0.Add(new kSqlParameter() { Name = "EndDate", Value = request.EndDate_0 });
            using var auditTM_GetLeads_0 = ActionAuditScope.Begin("d8844dab-9f7b-899c-f68b-d80ef5c88391", "TM_GetLeads", applicationName: "wbTimesCRM", screenOrEndpointName: "LeadList");
            result.TM_GetLeads = KPersister.Fetch(KContext.GetConnectionString(), @"-- SET LANGUAGE Turkish;

-- SELECT
-- CASE 
--     WHEN EXISTS (
--         SELECT 1 
--         FROM tmscrq.TMLeadReservation r
--         WHERE r.LeadId = l.Id
--           AND r.IsActive = 1
--           AND r.IsApproved = 1
--     ) THEN N'Evet'

--     WHEN EXISTS (
--         SELECT 1 
--         FROM tmscrq.TMLeadReservation r
--         WHERE r.LeadId = l.Id
--           AND r.IsActive = 1
--           AND ISNULL(r.IsApproved,0) = 0
--     ) THEN N'Onay Bekliyor'

--     ELSE N'Hayır'
-- END AS RezerveDurumu,
--     l.Id AS LeadId,
--     l.IsReserved,
--     ISNULL(NULLIF(LTRIM(RTRIM(l.LeadCode)), ''), '-') AS LeadNumarasi,
--     CONVERT(varchar(10), l.CreatedAt, 103) AS TalepTarihi,

--     p.Id AS ProductId,
--     ISNULL(NULLIF(LTRIM(RTRIM(p.ProductName)), ''), '-') AS ProductName,
--     ISNULL(NULLIF(LTRIM(RTRIM(p.Bracelet)), ''), '-') AS Bilezik,
--     ISNULL(NULLIF(LTRIM(RTRIM(p.Brand)), ''), '-') AS Brand,
--     ISNULL(NULLIF(LTRIM(RTRIM(p.Dial)), ''), '-') AS Kadran,
--     ISNULL(NULLIF(LTRIM(RTRIM(p.ProductCode)), ''), '-') AS RefCode,
--     ISNULL(NULLIF(LTRIM(RTRIM(p.Referance)), ''), '-') AS Referans,

--     ISNULL(
--         NULLIF(
--             LTRIM(RTRIM(ISNULL(cu.Name, '') + ' ' + ISNULL(cu.LastName, '')))
--         , '')
--     , '-') AS Musteri,

--     ISNULL(NULLIF(LTRIM(RTRIM(cu.CityName)), ''), '-') AS Lokasyon,
--     ISNULL(NULLIF(LTRIM(RTRIM(cu.DistrictName)), ''), '-') AS Ilce,
--     ISNULL(NULLIF(LTRIM(RTRIM(cu.CountryName)), ''), '-') AS Ulke,
--     ISNULL(NULLIF(LTRIM(RTRIM(cu.Info)), ''), '-') AS MusteriInfo,

--     CASE
--         WHEN cu.IsShopping = 1 THEN N'Evet'
--         WHEN cu.IsShopping = 0 THEN N'Hayır'
--         ELSE '-'
--     END AS AlisverisiVarMi,

--     ISNULL(NULLIF(LTRIM(RTRIM(cu.Tel)), ''), '-') AS IrtibatNumarasi,
--     ISNULL(NULLIF(LTRIM(RTRIM(cu.Email)), ''), '-') AS EmailAdresi,

--     ISNULL(NULLIF(LTRIM(RTRIM(cr.ContactResourceName)), ''), '-') AS IletisimKaynagi,

--     ISNULL(NULLIF(LTRIM(RTRIM(p.CategoryName)), ''), '-') AS CategoryName,
--     '-' AS CategoryCode,

--     ISNULL(NULLIF(LTRIM(RTRIM(ls.Name)), ''), '-') AS LeadDurumu,
--     ISNULL(NULLIF(LTRIM(RTRIM(ns.Name)), ''), '-') AS SonrakiAdim,

--     ISNULL(NULLIF(LTRIM(RTRIM(lp.Name)), ''), '-') AS ProcessName,
--     ISNULL(NULLIF(LTRIM(RTRIM(lp.Code)), ''), '-') AS ProcessCode,
--     lp.StepOrder,
-- CASE
--     WHEN EXISTS
--     (
--         SELECT 1
--         FROM tmscrq.TMLeadReservation r
--         WHERE r.LeadId = l.Id
--           AND r.IsActive = 1
--           AND ISNULL(r.IsApproved,0) = 0
--     )
--     THEN 10
--     ELSE lp.StepOrder
-- END AS SelectedStepOrder,

--     ISNULL(
--         CASE
--             WHEN l.EstimatedDate IS NOT NULL
--             THEN CAST(YEAR(l.EstimatedDate) AS VARCHAR(4)) + ' ' + DATENAME(MONTH, l.EstimatedDate)
--             ELSE NULL
--         END,
--         '-'
--     ) AS TerminTarihi,

--     ISNULL(
--         NULLIF(
--             LTRIM(RTRIM(ISNULL(sp.FirstName, '') + ' ' + ISNULL(sp.LastName, '')))
--         , '')
--     , '-') AS SatisDanismani,

--     ISNULL(NULLIF(LTRIM(RTRIM(st.StoreDesc)), ''), '-') AS StoreName

-- FROM tmscrq.TMLead l
-- LEFT JOIN tmscrq.TMLeadStatu ls
--     ON ls.Id = l.StatuId
-- LEFT JOIN tmscrq.TMCustomer cu
--     ON cu.Id = l.CustomerId
-- LEFT JOIN tmscrq.TMProduct p
--     ON p.Id = l.ProductId
-- LEFT JOIN tmscrq.TMContactResource cr
--     ON cr.Id = l.ContactResourceId
-- LEFT JOIN dbo.KUser sp
--     ON sp.Id = l.SalesPersonKUserId
-- LEFT JOIN tmscrq.TMStore st
--     ON st.Id = l.StoreId
-- LEFT JOIN tmscrq.TMLeadProcess lp
--     ON lp.Id = l.ProcessID
-- LEFT JOIN tmscrq.TMLeadNextStep ns
--     ON ns.Id = l.NextStepId

-- WHERE
-- (
--     EXISTS
--     (
--         SELECT 1
--         FROM dbo.KUserRole ur
--         INNER JOIN dbo.KRole r
--             ON r.Id = ur.KRole_Id
--         WHERE ur.KUser_Id = @UserId
--           AND ur.IsDeleted = 0
--           AND r.IsDeleted = 0
--           AND r.Name IN ('TimesYonetici', 'TimesUstYonetici')
--     )
--     OR
--     (
--         EXISTS
--         (
--             SELECT 1
--             FROM dbo.KUserRole ur
--             INNER JOIN dbo.KRole r
--                 ON r.Id = ur.KRole_Id
--             WHERE ur.KUser_Id = @UserId
--               AND ur.IsDeleted = 0
--               AND r.IsDeleted = 0
--               AND r.Name IN ('TimesMagazaMuduru', 'TimesSatisPersoneli')
--         )
--         AND EXISTS
--         (
--             SELECT 1
--             FROM tmscrq.TMUser tu
--             WHERE tu.KUserID = @UserId
--               AND tu.StoreId = l.StoreId
--         )
--     )
-- )

-- AND
-- (
--     @MusteriAdi IS NULL
--     OR LTRIM(RTRIM(@MusteriAdi)) = ''
--     OR UPPER(LTRIM(RTRIM(ISNULL(cu.Name,'') + ' ' + ISNULL(cu.LastName,''))))
--        LIKE '%' + UPPER(LTRIM(RTRIM(@MusteriAdi))) + '%'
-- )

-- AND
-- (
--     @ProductName IS NULL
--     OR LTRIM(RTRIM(@ProductName)) = ''
--     OR
--     (
--         CHARINDEX(',', @ProductName) > 0
--         AND ISNULL(LTRIM(RTRIM(p.ProductName)), '') IN
--         (
--             SELECT LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', '')))
--             FROM STRING_SPLIT(CAST(@ProductName AS NVARCHAR(MAX)), ',')
--             WHERE LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', ''))) <> ''
--         )
--     )
--     OR
--     (
--         CHARINDEX(',', @ProductName) = 0
--         AND UPPER(ISNULL(LTRIM(RTRIM(p.ProductName)), ''))
--             LIKE '%' + UPPER(LTRIM(RTRIM(@ProductName))) + '%'
--     )
-- )

-- AND
-- (
--     @LeadCode IS NULL
--     OR LTRIM(RTRIM(@LeadCode)) = ''
--     OR UPPER(ISNULL(LTRIM(RTRIM(l.LeadCode)), '')) LIKE '%' + UPPER(LTRIM(RTRIM(@LeadCode))) + '%'
-- )

-- AND
-- (
--     @Tel IS NULL
--     OR LTRIM(RTRIM(@Tel)) = ''
--     OR UPPER(ISNULL(LTRIM(RTRIM(cu.Tel)), '')) LIKE '%' + UPPER(LTRIM(RTRIM(@Tel))) + '%'
-- )

-- -- AND
-- -- (
-- --     @CategoryName IS NULL
-- --     OR LTRIM(RTRIM(@CategoryName)) = ''
-- --     OR
-- --     (
-- --         EXISTS
-- --         (
-- --             SELECT 1
-- --             FROM STRING_SPLIT(CAST(@CategoryName AS NVARCHAR(MAX)), ',') c
-- --             WHERE UPPER(LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(c.value, '""', ''), '[', ''), ']', '')))) = 'DEFAULT'
-- --         )
-- --         AND (p.CategoryName IS NULL OR LTRIM(RTRIM(p.CategoryName)) = '')
-- --     )
-- --     OR UPPER(ISNULL(LTRIM(RTRIM(p.CategoryName)), '')) IN
-- --     (
-- --         SELECT UPPER(LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', ''))))
-- --         FROM STRING_SPLIT(CAST(@CategoryName AS NVARCHAR(MAX)), ',')
-- --         WHERE LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', ''))) <> ''
-- --           AND UPPER(LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', '')))) <> 'DEFAULT'
-- --     )
-- -- )

-- AND
-- (
--     @CategoryName IS NULL
--     OR LTRIM(RTRIM(@CategoryName)) = ''
--     OR UPPER(ISNULL(LTRIM(RTRIM(p.CategoryName)), '')) IN
--     (
--         SELECT UPPER(LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value,'""',''),'[',''),']',''))))
--         FROM STRING_SPLIT(CAST(@CategoryName AS NVARCHAR(MAX)), ',')
--         WHERE LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value,'""',''),'[',''),']',''))) <> ''
--     )
-- )

-- AND
-- (
--     @StoreIds IS NULL
--     OR LTRIM(RTRIM(@StoreIds)) = ''
--     OR EXISTS
--     (
--         SELECT 1
--         FROM STRING_SPLIT(CAST(@StoreIds AS NVARCHAR(MAX)), ',') s
--         WHERE l.StoreId = TRY_CONVERT
--         (
--             uniqueidentifier,
--             LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(s.value, '""', ''), '[', ''), ']', '')))
--         )
--     )
-- )

-- AND
-- (
--     @SatisDanismaniIds IS NULL
--     OR LTRIM(RTRIM(@SatisDanismaniIds)) = ''
--     OR EXISTS
--     (
--         SELECT 1
--         FROM STRING_SPLIT(CAST(@SatisDanismaniIds AS NVARCHAR(MAX)), ',') s
--         WHERE l.SalesPersonKUserId = TRY_CONVERT
--         (
--             uniqueidentifier,
--             LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(s.value, '""', ''), '[', ''), ']', '')))
--         )
--     )
-- )

-- AND
-- (
--     @ProcessCode IS NULL
--     OR LTRIM(RTRIM(@ProcessCode)) = ''
--     OR UPPER(ISNULL(LTRIM(RTRIM(lp.Code)), '')) IN
--     (
--         SELECT UPPER(LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', ''))))
--         FROM STRING_SPLIT(CAST(@ProcessCode AS NVARCHAR(MAX)), ',')
--         WHERE LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', ''))) <> ''
--     )
-- )

-- AND
-- (
--     @StepOrder IS NULL

--     OR
--     (
--         @StepOrder = 10
--         AND EXISTS
--         (
--             SELECT 1
--             FROM tmscrq.TMLeadReservation r
--             WHERE r.LeadId = l.Id
--               AND r.IsActive = 1
--               AND ISNULL(r.IsApproved,0) = 0
--         )
--     )

--     OR
--     (
--         @StepOrder <> 10
--         AND lp.StepOrder = @StepOrder
--     )
-- )

-- AND
-- (
--     @StartDate IS NULL
--     OR LTRIM(RTRIM(@StartDate)) = ''
--     OR l.CreatedAt >= CONVERT(date, @StartDate)
-- )

-- AND
-- (
--     @EndDate IS NULL
--     OR LTRIM(RTRIM(@EndDate)) = ''
--     OR l.CreatedAt < DATEADD(day, 1, CONVERT(date, @EndDate))
-- )

-- ORDER BY l.CreatedAt DESC;

------------------------++++++++++++++++++++++++-------------------
-- SET LANGUAGE Turkish;

-- SELECT
-- CASE 
--     WHEN EXISTS (
--         SELECT 1 
--         FROM tmscrq.TMLeadReservation r
--         WHERE r.LeadId = l.Id
--           AND r.IsActive = 1
--           AND r.IsApproved = 1
--     ) THEN N'Evet'

--     WHEN EXISTS (
--         SELECT 1 
--         FROM tmscrq.TMLeadReservation r
--         WHERE r.LeadId = l.Id
--           AND r.IsActive = 1
--           AND ISNULL(r.IsApproved,0) = 0
--     ) THEN N'Onay Bekliyor'

--     ELSE N'Hayır'
-- END AS RezerveDurumu,
--     l.Id AS LeadId,
--     l.IsReserved,
--     ISNULL(NULLIF(LTRIM(RTRIM(l.LeadCode)), ''), '-') AS LeadNumarasi,
--     CONVERT(varchar(10), l.CreatedAt, 103) AS TalepTarihi,

--     p.Id AS ProductId,
--     ISNULL(NULLIF(LTRIM(RTRIM(p.ProductName)), ''), '-') AS ProductName,
--     ISNULL(NULLIF(LTRIM(RTRIM(p.Bracelet)), ''), '-') AS Bilezik,
--     ISNULL(NULLIF(LTRIM(RTRIM(p.Brand)), ''), '-') AS Brand,
--     ISNULL(NULLIF(LTRIM(RTRIM(p.Dial)), ''), '-') AS Kadran,
--     ISNULL(NULLIF(LTRIM(RTRIM(p.ProductCode)), ''), '-') AS RefCode,
--     ISNULL(NULLIF(LTRIM(RTRIM(p.Referance)), ''), '-') AS Referans,

--     ISNULL(
--         NULLIF(
--             LTRIM(RTRIM(ISNULL(cu.Name, '') + ' ' + ISNULL(cu.LastName, '')))
--         , '')
--     , '-') AS Musteri,

--     ISNULL(NULLIF(LTRIM(RTRIM(cu.CityName)), ''), '-') AS Lokasyon,
--     ISNULL(NULLIF(LTRIM(RTRIM(cu.DistrictName)), ''), '-') AS Ilce,
--     ISNULL(NULLIF(LTRIM(RTRIM(cu.CountryName)), ''), '-') AS Ulke,
--     ISNULL(NULLIF(LTRIM(RTRIM(cu.Info)), ''), '-') AS MusteriInfo,

--     CASE
--         WHEN cu.IsShopping = 1 THEN N'Evet'
--         WHEN cu.IsShopping = 0 THEN N'Hayır'
--         ELSE '-'
--     END AS AlisverisiVarMi,

--     ISNULL(NULLIF(LTRIM(RTRIM(cu.Tel)), ''), '-') AS IrtibatNumarasi,
--     ISNULL(NULLIF(LTRIM(RTRIM(cu.Email)), ''), '-') AS EmailAdresi,

--     ISNULL(NULLIF(LTRIM(RTRIM(cr.ContactResourceName)), ''), '-') AS IletisimKaynagi,

--     ISNULL(NULLIF(LTRIM(RTRIM(p.CategoryName)), ''), '-') AS CategoryName,
--     '-' AS CategoryCode,

--     ISNULL(NULLIF(LTRIM(RTRIM(ls.Name)), ''), '-') AS LeadDurumu,
--     ISNULL(NULLIF(LTRIM(RTRIM(ns.Name)), ''), '-') AS SonrakiAdim,

--     ISNULL(NULLIF(LTRIM(RTRIM(lp.Name)), ''), '-') AS ProcessName,
--     ISNULL(NULLIF(LTRIM(RTRIM(lp.Code)), ''), '-') AS ProcessCode,
--     lp.StepOrder,
    
--     -- DÜZELTİLEN ALAN: SelectedStepOrder
--     CASE
--         WHEN EXISTS
--         (
--             SELECT 1
--             FROM tmscrq.TMLeadReservation r
--             WHERE r.LeadId = l.Id
--               AND r.IsActive = 1
--               AND ISNULL(r.IsApproved,0) = 0
--         )
--         THEN 10
--         ELSE lp.StepOrder
--     END AS SelectedStepOrder,

--     ISNULL(
--         CASE
--             WHEN l.EstimatedDate IS NOT NULL
--             THEN CAST(YEAR(l.EstimatedDate) AS VARCHAR(4)) + ' ' + DATENAME(MONTH, l.EstimatedDate)
--             ELSE NULL
--         END,
--         '-'
--     ) AS TerminTarihi,

--     ISNULL(
--         NULLIF(
--             LTRIM(RTRIM(ISNULL(sp.FirstName, '') + ' ' + ISNULL(sp.LastName, '')))
--         , '')
--     , '-') AS SatisDanismani,

--     ISNULL(NULLIF(LTRIM(RTRIM(st.StoreDesc)), ''), '-') AS StoreName

-- FROM tmscrq.TMLead l
-- LEFT JOIN tmscrq.TMLeadStatu ls
--     ON ls.Id = l.StatuId
-- LEFT JOIN tmscrq.TMCustomer cu
--     ON cu.Id = l.CustomerId
-- LEFT JOIN tmscrq.TMProduct p
--     ON p.Id = l.ProductId
-- LEFT JOIN tmscrq.TMContactResource cr
--     ON cr.Id = l.ContactResourceId
-- LEFT JOIN dbo.KUser sp
--     ON sp.Id = l.SalesPersonKUserId
-- LEFT JOIN tmscrq.TMStore st
--     ON st.Id = l.StoreId
-- LEFT JOIN tmscrq.TMLeadProcess lp
--     ON lp.Id = l.ProcessID
-- LEFT JOIN tmscrq.TMLeadNextStep ns
--     ON ns.Id = l.NextStepId

-- WHERE
-- (
--     EXISTS
--     (
--         SELECT 1
--         FROM dbo.KUserRole ur
--         INNER JOIN dbo.KRole r
--             ON r.Id = ur.KRole_Id
--         WHERE ur.KUser_Id = @UserId
--           AND ur.IsDeleted = 0
--           AND r.IsDeleted = 0
--           AND r.Name IN ('TimesYonetici', 'TimesUstYonetici')
--     )
--     OR
--     (
--         EXISTS
--         (
--             SELECT 1
--             FROM dbo.KUserRole ur
--             INNER JOIN dbo.KRole r
--                 ON r.Id = ur.KRole_Id
--             WHERE ur.KUser_Id = @UserId
--               AND ur.IsDeleted = 0
--               AND r.IsDeleted = 0
--               AND r.Name IN ('TimesMagazaMuduru', 'TimesSatisPersoneli')
--         )
--         AND EXISTS
--         (
--             SELECT 1
--             FROM tmscrq.TMUser tu
--             WHERE tu.KUserID = @UserId
--               AND tu.StoreId = l.StoreId
--         )
--     )
-- )

-- AND
-- (
--     @MusteriAdi IS NULL
--     OR LTRIM(RTRIM(@MusteriAdi)) = ''
--     OR UPPER(LTRIM(RTRIM(ISNULL(cu.Name,'') + ' ' + ISNULL(cu.LastName,''))))
--        LIKE '%' + UPPER(LTRIM(RTRIM(@MusteriAdi))) + '%'
-- )

-- AND
-- (
--     @ProductName IS NULL
--     OR LTRIM(RTRIM(@ProductName)) = ''
--     OR
--     (
--         CHARINDEX(',', @ProductName) > 0
--         AND ISNULL(LTRIM(RTRIM(p.ProductName)), '') IN
--         (
--             SELECT LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', '')))
--             FROM STRING_SPLIT(CAST(@ProductName AS NVARCHAR(MAX)), ',')
--             WHERE LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', ''))) <> ''
--         )
--     )
--     OR
--     (
--         CHARINDEX(',', @ProductName) = 0
--         AND UPPER(ISNULL(LTRIM(RTRIM(p.ProductName)), ''))
--             LIKE '%' + UPPER(LTRIM(RTRIM(@ProductName))) + '%'
--     )
-- )

-- AND
-- (
--     @LeadCode IS NULL
--     OR LTRIM(RTRIM(@LeadCode)) = ''
--     OR UPPER(ISNULL(LTRIM(RTRIM(l.LeadCode)), '')) LIKE '%' + UPPER(LTRIM(RTRIM(@LeadCode))) + '%'
-- )

-- AND
-- (
--     @Tel IS NULL
--     OR LTRIM(RTRIM(@Tel)) = ''
--     OR UPPER(ISNULL(LTRIM(RTRIM(cu.Tel)), '')) LIKE '%' + UPPER(LTRIM(RTRIM(@Tel))) + '%'
-- )

-- AND
-- (
--     @CategoryName IS NULL
--     OR LTRIM(RTRIM(@CategoryName)) = ''
--     OR UPPER(ISNULL(LTRIM(RTRIM(p.CategoryName)), '')) IN
--     (
--         SELECT UPPER(LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value,'""',''),'[',''),']',''))))
--         FROM STRING_SPLIT(CAST(@CategoryName AS NVARCHAR(MAX)), ',')
--         WHERE LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value,'""',''),'[',''),']',''))) <> ''
--     )
-- )

-- AND
-- (
--     @StoreIds IS NULL
--     OR LTRIM(RTRIM(@StoreIds)) = ''
--     OR EXISTS
--     (
--         SELECT 1
--         FROM STRING_SPLIT(CAST(@StoreIds AS NVARCHAR(MAX)), ',') s
--         WHERE l.StoreId = TRY_CONVERT
--         (
--             uniqueidentifier,
--             LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(s.value, '""', ''), '[', ''), ']', '')))
--         )
--     )
-- )

-- AND
-- (
--     @SatisDanismaniIds IS NULL
--     OR LTRIM(RTRIM(@SatisDanismaniIds)) = ''
--     OR EXISTS
--     (
--         SELECT 1
--         FROM STRING_SPLIT(CAST(@SatisDanismaniIds AS NVARCHAR(MAX)), ',') s
--         WHERE l.SalesPersonKUserId = TRY_CONVERT
--         (
--             uniqueidentifier,
--             LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(s.value, '""', ''), '[', ''), ']', '')))
--         )
--     )
-- )

-- AND
-- (
--     @ProcessCode IS NULL
--     OR LTRIM(RTRIM(@ProcessCode)) = ''
--     OR UPPER(ISNULL(LTRIM(RTRIM(lp.Code)), '')) IN
--     (
--         SELECT UPPER(LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', ''))))
--         FROM STRING_SPLIT(CAST(@ProcessCode AS NVARCHAR(MAX)), ',')
--         WHERE LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', ''))) <> ''
--     )
-- )

-- -- DÜZELTİLEN ALAN: @StepOrder Filtresi (tek blok)
-- AND
-- (
--     @StepOrder IS NULL

--     OR

--     (
--         @StepOrder = 10
--         AND EXISTS
--         (
--             SELECT 1
--             FROM tmscrq.TMLeadReservation r
--             WHERE r.LeadId = l.Id
--               AND r.IsActive = 1
--               AND ISNULL(r.IsApproved,0) = 0
--         )
--     )

--     OR

--     (
--         @StepOrder <> 10
--         AND lp.StepOrder = @StepOrder
--     )
-- )

-- AND
-- (
--     @StartDate IS NULL
--     OR LTRIM(RTRIM(@StartDate)) = ''
--     OR l.CreatedAt >= CONVERT(date, @StartDate)
-- )

-- AND
-- (
--     @EndDate IS NULL
--     OR LTRIM(RTRIM(@EndDate)) = ''
--     OR l.CreatedAt < DATEADD(day, 1, CONVERT(date, @EndDate))
-- )

-- ORDER BY l.CreatedAt DESC;



SET LANGUAGE Turkish;

SELECT
CASE 
    WHEN EXISTS (
        SELECT 1 
        FROM tmscrq.TMLeadReservation r
        WHERE r.LeadId = l.Id
          AND r.IsActive = 1
          AND r.IsApproved = 1
    ) THEN N'Evet'

    WHEN EXISTS (
        SELECT 1 
        FROM tmscrq.TMLeadReservation r
        WHERE r.LeadId = l.Id
          AND r.IsActive = 1
          AND ISNULL(r.IsApproved,0) = 0
    ) THEN N'Onay Bekliyor'

    ELSE N'Hayır'
END AS RezerveDurumu,
    l.Id AS LeadId,
    l.IsReserved,
    ISNULL(NULLIF(LTRIM(RTRIM(l.LeadCode)), ''), '-') AS LeadNumarasi,
     FORMAT(l.CreatedAt, 'dd MMMM yyyy', 'tr-TR') AS TalepTarihi,

    p.Id AS ProductId,
    ISNULL(NULLIF(LTRIM(RTRIM(p.ProductName)), ''), '-') AS ProductName,
    ISNULL(NULLIF(LTRIM(RTRIM(p.Bracelet)), ''), '-') AS Bilezik,
    ISNULL(NULLIF(LTRIM(RTRIM(p.Brand)), ''), '-') AS Brand,
    ISNULL(NULLIF(LTRIM(RTRIM(p.Dial)), ''), '-') AS Kadran,
    ISNULL(NULLIF(LTRIM(RTRIM(p.ProductCode)), ''), '-') AS RefCode,
    ISNULL(NULLIF(LTRIM(RTRIM(p.Referance)), ''), '-') AS Referans,

    ISNULL(
        NULLIF(
            LTRIM(RTRIM(ISNULL(cu.Name, '') + ' ' + ISNULL(cu.LastName, '')))
        , '')
    , '-') AS Musteri,

    ISNULL(NULLIF(LTRIM(RTRIM(cu.CityName)), ''), '-') AS Lokasyon,
    ISNULL(NULLIF(LTRIM(RTRIM(cu.DistrictName)), ''), '-') AS Ilce,
    ISNULL(NULLIF(LTRIM(RTRIM(cu.CountryName)), ''), '-') AS Ulke,
    ISNULL(NULLIF(LTRIM(RTRIM(cu.Info)), ''), '-') AS MusteriInfo,

    CASE
        WHEN cu.IsShopping = 1 THEN N'Evet'
        WHEN cu.IsShopping = 0 THEN N'Hayır'
        ELSE '-'
    END AS AlisverisiVarMi,

    ISNULL(NULLIF(LTRIM(RTRIM(cu.Tel)), ''), '-') AS IrtibatNumarasi,
    ISNULL(NULLIF(LTRIM(RTRIM(cu.Email)), ''), '-') AS EmailAdresi,

    ISNULL(NULLIF(LTRIM(RTRIM(cr.ContactResourceName)), ''), '-') AS IletisimKaynagi,

    ISNULL(NULLIF(LTRIM(RTRIM(p.CategoryName)), ''), '-') AS CategoryName,
    '-' AS CategoryCode,

    ISNULL(NULLIF(LTRIM(RTRIM(ls.Name)), ''), '-') AS LeadDurumu,
    ISNULL(NULLIF(LTRIM(RTRIM(ns.Name)), ''), '-') AS SonrakiAdim,

    ISNULL(NULLIF(LTRIM(RTRIM(lp.Name)), ''), '-') AS ProcessName,
    ISNULL(NULLIF(LTRIM(RTRIM(lp.Code)), ''), '-') AS ProcessCode,
    lp.StepOrder,
    
    -- DÜZELTİLEN ALAN: SelectedStepOrder
    CASE
        WHEN EXISTS
        (
            SELECT 1
            FROM tmscrq.TMLeadReservation r
            WHERE r.LeadId = l.Id
              AND r.IsActive = 1
              AND ISNULL(r.IsApproved,0) = 0
        )
        THEN 10
        ELSE lp.StepOrder
    END AS SelectedStepOrder,

    ISNULL(
        CASE
            WHEN l.EstimatedDate IS NOT NULL
            THEN CAST(YEAR(l.EstimatedDate) AS VARCHAR(4)) + ' ' + DATENAME(MONTH, l.EstimatedDate)
            ELSE NULL
        END,
        '-'
    ) AS TerminTarihi,

    ISNULL(
        NULLIF(
            LTRIM(RTRIM(ISNULL(sp.FirstName, '') + ' ' + ISNULL(sp.LastName, '')))
        , '')
    , '-') AS SatisDanismani,

    ISNULL(NULLIF(LTRIM(RTRIM(st.StoreDesc)), ''), '-') AS StoreName

FROM tmscrq.TMLead l
LEFT JOIN tmscrq.TMLeadStatu ls
    ON ls.Id = l.StatuId
LEFT JOIN tmscrq.TMCustomer cu
    ON cu.Id = l.CustomerId
LEFT JOIN tmscrq.TMProduct p
    ON p.Id = l.ProductId
LEFT JOIN tmscrq.TMContactResource cr
    ON cr.Id = l.ContactResourceId
LEFT JOIN dbo.KUser sp
    ON sp.Id = l.SalesPersonKUserId
LEFT JOIN tmscrq.TMStore st
    ON st.Id = l.StoreId
LEFT JOIN tmscrq.TMLeadProcess lp
    ON lp.Id = l.ProcessID
LEFT JOIN tmscrq.TMLeadNextStep ns
    ON ns.Id = l.NextStepId

WHERE
(
    EXISTS
    (
        SELECT 1
        FROM dbo.KUserRole ur
        INNER JOIN dbo.KRole r
            ON r.Id = ur.KRole_Id
        WHERE ur.KUser_Id = @UserId
          AND ur.IsDeleted = 0
          AND r.IsDeleted = 0
          AND r.Name IN ('TimesYonetici', 'TimesUstYonetici')
    )
    OR
    (
        EXISTS
        (
            SELECT 1
            FROM dbo.KUserRole ur
            INNER JOIN dbo.KRole r
                ON r.Id = ur.KRole_Id
            WHERE ur.KUser_Id = @UserId
              AND ur.IsDeleted = 0
              AND r.IsDeleted = 0
              AND r.Name IN ('TimesMagazaMuduru', 'TimesSatisPersoneli')
        )
        AND EXISTS
        (
            SELECT 1
            FROM tmscrq.TMUser tu
            WHERE tu.KUserID = @UserId
              AND tu.StoreId = l.StoreId
        )
    )
)

AND
(
    ISNULL(@MusteriAdi, '') = ''
    OR UPPER(ISNULL(cu.Name, '')) LIKE '%' + UPPER(LTRIM(RTRIM(@MusteriAdi))) + '%'
    OR UPPER(ISNULL(cu.LastName, '')) LIKE '%' + UPPER(LTRIM(RTRIM(@MusteriAdi))) + '%'
    OR UPPER(
        ISNULL(cu.Name, '') + ' ' + ISNULL(cu.LastName, '')
    ) LIKE '%' + UPPER(LTRIM(RTRIM(@MusteriAdi))) + '%'
)

AND
(
    @ProductName IS NULL
    OR LTRIM(RTRIM(@ProductName)) = ''
    OR
    (
        CHARINDEX(',', @ProductName) > 0
        AND ISNULL(LTRIM(RTRIM(p.ProductName)), '') IN
        (
            SELECT LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', '')))
            FROM STRING_SPLIT(CAST(@ProductName AS NVARCHAR(MAX)), ',')
            WHERE LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', ''))) <> ''
        )
    )
    OR
    (
        CHARINDEX(',', @ProductName) = 0
        AND UPPER(ISNULL(LTRIM(RTRIM(p.ProductName)), ''))
            LIKE '%' + UPPER(LTRIM(RTRIM(@ProductName))) + '%'
    )
)

AND
(
    ISNULL(@LeadCode, '') = ''
    OR UPPER(ISNULL(l.LeadCode, ''))
        LIKE '%' + UPPER(LTRIM(RTRIM(@LeadCode))) + '%'
    OR REPLACE(
        REPLACE(
            REPLACE(
                UPPER(ISNULL(l.LeadCode, '')),
                '-', ''
            ),
            ' ', ''
        ),
        '/', ''
    )
    LIKE '%' +
    REPLACE(
        REPLACE(
            REPLACE(
                UPPER(LTRIM(RTRIM(@LeadCode))),
                '-', ''
            ),
            ' ', ''
        ),
        '/', ''
    )
    + '%'
)

AND
(
    @Tel IS NULL
    OR LTRIM(RTRIM(@Tel)) = ''
    OR UPPER(ISNULL(LTRIM(RTRIM(cu.Tel)), '')) LIKE '%' + UPPER(LTRIM(RTRIM(@Tel))) + '%'
)

AND
(
    @CategoryName IS NULL
    OR LTRIM(RTRIM(@CategoryName)) = ''
    OR UPPER(ISNULL(LTRIM(RTRIM(p.CategoryName)), '')) IN
    (
        SELECT UPPER(LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value,'""',''),'[',''),']',''))))
        FROM STRING_SPLIT(CAST(@CategoryName AS NVARCHAR(MAX)), ',')
        WHERE LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value,'""',''),'[',''),']',''))) <> ''
    )
)

AND
(
    @StoreIds IS NULL
    OR LTRIM(RTRIM(@StoreIds)) = ''
    OR EXISTS
    (
        SELECT 1
        FROM STRING_SPLIT(CAST(@StoreIds AS NVARCHAR(MAX)), ',') s
        WHERE l.StoreId = TRY_CONVERT
        (
            uniqueidentifier,
            LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(s.value, '""', ''), '[', ''), ']', '')))
        )
    )
)

AND
(
    @SatisDanismaniIds IS NULL
    OR LTRIM(RTRIM(@SatisDanismaniIds)) = ''
    OR EXISTS
    (
        SELECT 1
        FROM STRING_SPLIT(CAST(@SatisDanismaniIds AS NVARCHAR(MAX)), ',') s
        WHERE l.SalesPersonKUserId = TRY_CONVERT
        (
            uniqueidentifier,
            LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(s.value, '""', ''), '[', ''), ']', '')))
        )
    )
)

AND
(
    ISNULL(@ProcessCode, '') = ''
    OR EXISTS
    (
        SELECT 1
        FROM STRING_SPLIT(
            CONVERT(NVARCHAR(MAX), @ProcessCode),
            ','
        ) AS s
        WHERE
            UPPER(LTRIM(RTRIM(s.value))) =
            UPPER(LTRIM(RTRIM(ISNULL(lp.Code, ''))))
    )
)

-- DÜZELTİLEN ALAN: @StepOrder Filtresi (0 verilince tümü gelsin)
AND
(
    @StepOrder IS NULL
    OR @StepOrder = 0  -- 👈 YENİ EKLENDI: 0 verilince tüm kayıtlar gelir
    OR
    (
        @StepOrder = 10
        AND EXISTS
        (
            SELECT 1
            FROM tmscrq.TMLeadReservation r
            WHERE r.LeadId = l.Id
              AND r.IsActive = 1
              AND ISNULL(r.IsApproved,0) = 0
        )
    )
    OR
    (
        @StepOrder <> 10
        AND lp.StepOrder = @StepOrder
    )
)

AND
(
    @StartDate IS NULL
    OR LTRIM(RTRIM(@StartDate)) = ''
    OR l.CreatedAt >= CONVERT(date, @StartDate)
)

AND
(
    @EndDate IS NULL
    OR LTRIM(RTRIM(@EndDate)) = ''
    OR l.CreatedAt < DATEADD(day, 1, CONVERT(date, @EndDate))
)

ORDER BY l.CreatedAt DESC;", new string[] { "RezerveDurumu", "LeadId", "IsReserved", "LeadNumarasi", "TalepTarihi", "ProductId", "ProductName", "Bilezik", "Brand", "Kadran", "RefCode", "Referans", "Musteri", "Lokasyon", "Ilce", "Ulke", "MusteriInfo", "AlisverisiVarMi", "IrtibatNumarasi", "EmailAdresi", "IletisimKaynagi", "CategoryName", "CategoryCode", "LeadDurumu", "SonrakiAdim", "ProcessName", "ProcessCode", "StepOrder", "SelectedStepOrder", "TerminTarihi", "SatisDanismani", "StoreName" }, prms_TM_GetLeads_0.ToArray());
            ;


            return Ok(result);
        }


        [HttpPost, Route("LeadListComponent_470282_onClick")]
        public IActionResult LeadListComponent_470282_onClick(LeadListComponent_470282_onClick_Request request)
        {

            KProviderManager.Authorization.IsAuthorizedForRoles(appId, appName, screenId, screenName, new List<string> { $"70de6cfc-6087-6059-59b4-0b5a8527af6b", "4da1f213-c8e4-0b50-5c84-02fd13f1a622", "c4e882ef-977d-f613-7694-230ac83919d2", "b4bfd39c-ac02-f442-c899-7a2374a45b47", "cdb536b0-6297-155f-d446-8453d8a60304", "TimesYonetici", "TimesUstYonetici", "TimesSatisPersoneli", "TimesMagazaMuduru", "TimesAdmin" });

            var result = new LeadListComponent_470282_onClick_Response();

            var prms_TM_GetLeads_0 = new List<kSqlParameter>();
            prms_TM_GetLeads_0.Add(new kSqlParameter() { Name = "StepOrder", Value = "3".ConvertToType<Int32>() });
            prms_TM_GetLeads_0.Add(new kSqlParameter() { Name = "UserId", Value = Kuika.Common.KContext.CurrentUser?.Id });
            prms_TM_GetLeads_0.Add(new kSqlParameter() { Name = "MusteriAdi", Value = request.MusteriAdi_0 });
            prms_TM_GetLeads_0.Add(new kSqlParameter() { Name = "ProductName", Value = request.ProductName_0 });
            prms_TM_GetLeads_0.Add(new kSqlParameter() { Name = "LeadCode", Value = request.LeadCode_0 });
            prms_TM_GetLeads_0.Add(new kSqlParameter() { Name = "Tel", Value = request.Tel_0 });
            prms_TM_GetLeads_0.Add(new kSqlParameter() { Name = "CategoryName", Value = request.CategoryName_0 });
            prms_TM_GetLeads_0.Add(new kSqlParameter() { Name = "StoreIds", Value = request.StoreIds_0 });
            prms_TM_GetLeads_0.Add(new kSqlParameter() { Name = "SatisDanismaniIds", Value = request.SatisDanismaniIds_0 });
            prms_TM_GetLeads_0.Add(new kSqlParameter() { Name = "ProcessCode", Value = request.ProcessCode_0 });
            prms_TM_GetLeads_0.Add(new kSqlParameter() { Name = "StartDate", Value = request.StartDate_0 });
            prms_TM_GetLeads_0.Add(new kSqlParameter() { Name = "EndDate", Value = request.EndDate_0 });
            using var auditTM_GetLeads_0 = ActionAuditScope.Begin("27bbb825-0744-8928-aab5-a71cba8ac631", "TM_GetLeads", applicationName: "wbTimesCRM", screenOrEndpointName: "LeadList");
            result.TM_GetLeads = KPersister.Fetch(KContext.GetConnectionString(), @"-- SET LANGUAGE Turkish;

-- SELECT
-- CASE 
--     WHEN EXISTS (
--         SELECT 1 
--         FROM tmscrq.TMLeadReservation r
--         WHERE r.LeadId = l.Id
--           AND r.IsActive = 1
--           AND r.IsApproved = 1
--     ) THEN N'Evet'

--     WHEN EXISTS (
--         SELECT 1 
--         FROM tmscrq.TMLeadReservation r
--         WHERE r.LeadId = l.Id
--           AND r.IsActive = 1
--           AND ISNULL(r.IsApproved,0) = 0
--     ) THEN N'Onay Bekliyor'

--     ELSE N'Hayır'
-- END AS RezerveDurumu,
--     l.Id AS LeadId,
--     l.IsReserved,
--     ISNULL(NULLIF(LTRIM(RTRIM(l.LeadCode)), ''), '-') AS LeadNumarasi,
--     CONVERT(varchar(10), l.CreatedAt, 103) AS TalepTarihi,

--     p.Id AS ProductId,
--     ISNULL(NULLIF(LTRIM(RTRIM(p.ProductName)), ''), '-') AS ProductName,
--     ISNULL(NULLIF(LTRIM(RTRIM(p.Bracelet)), ''), '-') AS Bilezik,
--     ISNULL(NULLIF(LTRIM(RTRIM(p.Brand)), ''), '-') AS Brand,
--     ISNULL(NULLIF(LTRIM(RTRIM(p.Dial)), ''), '-') AS Kadran,
--     ISNULL(NULLIF(LTRIM(RTRIM(p.ProductCode)), ''), '-') AS RefCode,
--     ISNULL(NULLIF(LTRIM(RTRIM(p.Referance)), ''), '-') AS Referans,

--     ISNULL(
--         NULLIF(
--             LTRIM(RTRIM(ISNULL(cu.Name, '') + ' ' + ISNULL(cu.LastName, '')))
--         , '')
--     , '-') AS Musteri,

--     ISNULL(NULLIF(LTRIM(RTRIM(cu.CityName)), ''), '-') AS Lokasyon,
--     ISNULL(NULLIF(LTRIM(RTRIM(cu.DistrictName)), ''), '-') AS Ilce,
--     ISNULL(NULLIF(LTRIM(RTRIM(cu.CountryName)), ''), '-') AS Ulke,
--     ISNULL(NULLIF(LTRIM(RTRIM(cu.Info)), ''), '-') AS MusteriInfo,

--     CASE
--         WHEN cu.IsShopping = 1 THEN N'Evet'
--         WHEN cu.IsShopping = 0 THEN N'Hayır'
--         ELSE '-'
--     END AS AlisverisiVarMi,

--     ISNULL(NULLIF(LTRIM(RTRIM(cu.Tel)), ''), '-') AS IrtibatNumarasi,
--     ISNULL(NULLIF(LTRIM(RTRIM(cu.Email)), ''), '-') AS EmailAdresi,

--     ISNULL(NULLIF(LTRIM(RTRIM(cr.ContactResourceName)), ''), '-') AS IletisimKaynagi,

--     ISNULL(NULLIF(LTRIM(RTRIM(p.CategoryName)), ''), '-') AS CategoryName,
--     '-' AS CategoryCode,

--     ISNULL(NULLIF(LTRIM(RTRIM(ls.Name)), ''), '-') AS LeadDurumu,
--     ISNULL(NULLIF(LTRIM(RTRIM(ns.Name)), ''), '-') AS SonrakiAdim,

--     ISNULL(NULLIF(LTRIM(RTRIM(lp.Name)), ''), '-') AS ProcessName,
--     ISNULL(NULLIF(LTRIM(RTRIM(lp.Code)), ''), '-') AS ProcessCode,
--     lp.StepOrder,
-- CASE
--     WHEN EXISTS
--     (
--         SELECT 1
--         FROM tmscrq.TMLeadReservation r
--         WHERE r.LeadId = l.Id
--           AND r.IsActive = 1
--           AND ISNULL(r.IsApproved,0) = 0
--     )
--     THEN 10
--     ELSE lp.StepOrder
-- END AS SelectedStepOrder,

--     ISNULL(
--         CASE
--             WHEN l.EstimatedDate IS NOT NULL
--             THEN CAST(YEAR(l.EstimatedDate) AS VARCHAR(4)) + ' ' + DATENAME(MONTH, l.EstimatedDate)
--             ELSE NULL
--         END,
--         '-'
--     ) AS TerminTarihi,

--     ISNULL(
--         NULLIF(
--             LTRIM(RTRIM(ISNULL(sp.FirstName, '') + ' ' + ISNULL(sp.LastName, '')))
--         , '')
--     , '-') AS SatisDanismani,

--     ISNULL(NULLIF(LTRIM(RTRIM(st.StoreDesc)), ''), '-') AS StoreName

-- FROM tmscrq.TMLead l
-- LEFT JOIN tmscrq.TMLeadStatu ls
--     ON ls.Id = l.StatuId
-- LEFT JOIN tmscrq.TMCustomer cu
--     ON cu.Id = l.CustomerId
-- LEFT JOIN tmscrq.TMProduct p
--     ON p.Id = l.ProductId
-- LEFT JOIN tmscrq.TMContactResource cr
--     ON cr.Id = l.ContactResourceId
-- LEFT JOIN dbo.KUser sp
--     ON sp.Id = l.SalesPersonKUserId
-- LEFT JOIN tmscrq.TMStore st
--     ON st.Id = l.StoreId
-- LEFT JOIN tmscrq.TMLeadProcess lp
--     ON lp.Id = l.ProcessID
-- LEFT JOIN tmscrq.TMLeadNextStep ns
--     ON ns.Id = l.NextStepId

-- WHERE
-- (
--     EXISTS
--     (
--         SELECT 1
--         FROM dbo.KUserRole ur
--         INNER JOIN dbo.KRole r
--             ON r.Id = ur.KRole_Id
--         WHERE ur.KUser_Id = @UserId
--           AND ur.IsDeleted = 0
--           AND r.IsDeleted = 0
--           AND r.Name IN ('TimesYonetici', 'TimesUstYonetici')
--     )
--     OR
--     (
--         EXISTS
--         (
--             SELECT 1
--             FROM dbo.KUserRole ur
--             INNER JOIN dbo.KRole r
--                 ON r.Id = ur.KRole_Id
--             WHERE ur.KUser_Id = @UserId
--               AND ur.IsDeleted = 0
--               AND r.IsDeleted = 0
--               AND r.Name IN ('TimesMagazaMuduru', 'TimesSatisPersoneli')
--         )
--         AND EXISTS
--         (
--             SELECT 1
--             FROM tmscrq.TMUser tu
--             WHERE tu.KUserID = @UserId
--               AND tu.StoreId = l.StoreId
--         )
--     )
-- )

-- AND
-- (
--     @MusteriAdi IS NULL
--     OR LTRIM(RTRIM(@MusteriAdi)) = ''
--     OR UPPER(LTRIM(RTRIM(ISNULL(cu.Name,'') + ' ' + ISNULL(cu.LastName,''))))
--        LIKE '%' + UPPER(LTRIM(RTRIM(@MusteriAdi))) + '%'
-- )

-- AND
-- (
--     @ProductName IS NULL
--     OR LTRIM(RTRIM(@ProductName)) = ''
--     OR
--     (
--         CHARINDEX(',', @ProductName) > 0
--         AND ISNULL(LTRIM(RTRIM(p.ProductName)), '') IN
--         (
--             SELECT LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', '')))
--             FROM STRING_SPLIT(CAST(@ProductName AS NVARCHAR(MAX)), ',')
--             WHERE LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', ''))) <> ''
--         )
--     )
--     OR
--     (
--         CHARINDEX(',', @ProductName) = 0
--         AND UPPER(ISNULL(LTRIM(RTRIM(p.ProductName)), ''))
--             LIKE '%' + UPPER(LTRIM(RTRIM(@ProductName))) + '%'
--     )
-- )

-- AND
-- (
--     @LeadCode IS NULL
--     OR LTRIM(RTRIM(@LeadCode)) = ''
--     OR UPPER(ISNULL(LTRIM(RTRIM(l.LeadCode)), '')) LIKE '%' + UPPER(LTRIM(RTRIM(@LeadCode))) + '%'
-- )

-- AND
-- (
--     @Tel IS NULL
--     OR LTRIM(RTRIM(@Tel)) = ''
--     OR UPPER(ISNULL(LTRIM(RTRIM(cu.Tel)), '')) LIKE '%' + UPPER(LTRIM(RTRIM(@Tel))) + '%'
-- )

-- -- AND
-- -- (
-- --     @CategoryName IS NULL
-- --     OR LTRIM(RTRIM(@CategoryName)) = ''
-- --     OR
-- --     (
-- --         EXISTS
-- --         (
-- --             SELECT 1
-- --             FROM STRING_SPLIT(CAST(@CategoryName AS NVARCHAR(MAX)), ',') c
-- --             WHERE UPPER(LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(c.value, '""', ''), '[', ''), ']', '')))) = 'DEFAULT'
-- --         )
-- --         AND (p.CategoryName IS NULL OR LTRIM(RTRIM(p.CategoryName)) = '')
-- --     )
-- --     OR UPPER(ISNULL(LTRIM(RTRIM(p.CategoryName)), '')) IN
-- --     (
-- --         SELECT UPPER(LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', ''))))
-- --         FROM STRING_SPLIT(CAST(@CategoryName AS NVARCHAR(MAX)), ',')
-- --         WHERE LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', ''))) <> ''
-- --           AND UPPER(LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', '')))) <> 'DEFAULT'
-- --     )
-- -- )

-- AND
-- (
--     @CategoryName IS NULL
--     OR LTRIM(RTRIM(@CategoryName)) = ''
--     OR UPPER(ISNULL(LTRIM(RTRIM(p.CategoryName)), '')) IN
--     (
--         SELECT UPPER(LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value,'""',''),'[',''),']',''))))
--         FROM STRING_SPLIT(CAST(@CategoryName AS NVARCHAR(MAX)), ',')
--         WHERE LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value,'""',''),'[',''),']',''))) <> ''
--     )
-- )

-- AND
-- (
--     @StoreIds IS NULL
--     OR LTRIM(RTRIM(@StoreIds)) = ''
--     OR EXISTS
--     (
--         SELECT 1
--         FROM STRING_SPLIT(CAST(@StoreIds AS NVARCHAR(MAX)), ',') s
--         WHERE l.StoreId = TRY_CONVERT
--         (
--             uniqueidentifier,
--             LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(s.value, '""', ''), '[', ''), ']', '')))
--         )
--     )
-- )

-- AND
-- (
--     @SatisDanismaniIds IS NULL
--     OR LTRIM(RTRIM(@SatisDanismaniIds)) = ''
--     OR EXISTS
--     (
--         SELECT 1
--         FROM STRING_SPLIT(CAST(@SatisDanismaniIds AS NVARCHAR(MAX)), ',') s
--         WHERE l.SalesPersonKUserId = TRY_CONVERT
--         (
--             uniqueidentifier,
--             LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(s.value, '""', ''), '[', ''), ']', '')))
--         )
--     )
-- )

-- AND
-- (
--     @ProcessCode IS NULL
--     OR LTRIM(RTRIM(@ProcessCode)) = ''
--     OR UPPER(ISNULL(LTRIM(RTRIM(lp.Code)), '')) IN
--     (
--         SELECT UPPER(LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', ''))))
--         FROM STRING_SPLIT(CAST(@ProcessCode AS NVARCHAR(MAX)), ',')
--         WHERE LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', ''))) <> ''
--     )
-- )

-- AND
-- (
--     @StepOrder IS NULL

--     OR
--     (
--         @StepOrder = 10
--         AND EXISTS
--         (
--             SELECT 1
--             FROM tmscrq.TMLeadReservation r
--             WHERE r.LeadId = l.Id
--               AND r.IsActive = 1
--               AND ISNULL(r.IsApproved,0) = 0
--         )
--     )

--     OR
--     (
--         @StepOrder <> 10
--         AND lp.StepOrder = @StepOrder
--     )
-- )

-- AND
-- (
--     @StartDate IS NULL
--     OR LTRIM(RTRIM(@StartDate)) = ''
--     OR l.CreatedAt >= CONVERT(date, @StartDate)
-- )

-- AND
-- (
--     @EndDate IS NULL
--     OR LTRIM(RTRIM(@EndDate)) = ''
--     OR l.CreatedAt < DATEADD(day, 1, CONVERT(date, @EndDate))
-- )

-- ORDER BY l.CreatedAt DESC;

------------------------++++++++++++++++++++++++-------------------
-- SET LANGUAGE Turkish;

-- SELECT
-- CASE 
--     WHEN EXISTS (
--         SELECT 1 
--         FROM tmscrq.TMLeadReservation r
--         WHERE r.LeadId = l.Id
--           AND r.IsActive = 1
--           AND r.IsApproved = 1
--     ) THEN N'Evet'

--     WHEN EXISTS (
--         SELECT 1 
--         FROM tmscrq.TMLeadReservation r
--         WHERE r.LeadId = l.Id
--           AND r.IsActive = 1
--           AND ISNULL(r.IsApproved,0) = 0
--     ) THEN N'Onay Bekliyor'

--     ELSE N'Hayır'
-- END AS RezerveDurumu,
--     l.Id AS LeadId,
--     l.IsReserved,
--     ISNULL(NULLIF(LTRIM(RTRIM(l.LeadCode)), ''), '-') AS LeadNumarasi,
--     CONVERT(varchar(10), l.CreatedAt, 103) AS TalepTarihi,

--     p.Id AS ProductId,
--     ISNULL(NULLIF(LTRIM(RTRIM(p.ProductName)), ''), '-') AS ProductName,
--     ISNULL(NULLIF(LTRIM(RTRIM(p.Bracelet)), ''), '-') AS Bilezik,
--     ISNULL(NULLIF(LTRIM(RTRIM(p.Brand)), ''), '-') AS Brand,
--     ISNULL(NULLIF(LTRIM(RTRIM(p.Dial)), ''), '-') AS Kadran,
--     ISNULL(NULLIF(LTRIM(RTRIM(p.ProductCode)), ''), '-') AS RefCode,
--     ISNULL(NULLIF(LTRIM(RTRIM(p.Referance)), ''), '-') AS Referans,

--     ISNULL(
--         NULLIF(
--             LTRIM(RTRIM(ISNULL(cu.Name, '') + ' ' + ISNULL(cu.LastName, '')))
--         , '')
--     , '-') AS Musteri,

--     ISNULL(NULLIF(LTRIM(RTRIM(cu.CityName)), ''), '-') AS Lokasyon,
--     ISNULL(NULLIF(LTRIM(RTRIM(cu.DistrictName)), ''), '-') AS Ilce,
--     ISNULL(NULLIF(LTRIM(RTRIM(cu.CountryName)), ''), '-') AS Ulke,
--     ISNULL(NULLIF(LTRIM(RTRIM(cu.Info)), ''), '-') AS MusteriInfo,

--     CASE
--         WHEN cu.IsShopping = 1 THEN N'Evet'
--         WHEN cu.IsShopping = 0 THEN N'Hayır'
--         ELSE '-'
--     END AS AlisverisiVarMi,

--     ISNULL(NULLIF(LTRIM(RTRIM(cu.Tel)), ''), '-') AS IrtibatNumarasi,
--     ISNULL(NULLIF(LTRIM(RTRIM(cu.Email)), ''), '-') AS EmailAdresi,

--     ISNULL(NULLIF(LTRIM(RTRIM(cr.ContactResourceName)), ''), '-') AS IletisimKaynagi,

--     ISNULL(NULLIF(LTRIM(RTRIM(p.CategoryName)), ''), '-') AS CategoryName,
--     '-' AS CategoryCode,

--     ISNULL(NULLIF(LTRIM(RTRIM(ls.Name)), ''), '-') AS LeadDurumu,
--     ISNULL(NULLIF(LTRIM(RTRIM(ns.Name)), ''), '-') AS SonrakiAdim,

--     ISNULL(NULLIF(LTRIM(RTRIM(lp.Name)), ''), '-') AS ProcessName,
--     ISNULL(NULLIF(LTRIM(RTRIM(lp.Code)), ''), '-') AS ProcessCode,
--     lp.StepOrder,
    
--     -- DÜZELTİLEN ALAN: SelectedStepOrder
--     CASE
--         WHEN EXISTS
--         (
--             SELECT 1
--             FROM tmscrq.TMLeadReservation r
--             WHERE r.LeadId = l.Id
--               AND r.IsActive = 1
--               AND ISNULL(r.IsApproved,0) = 0
--         )
--         THEN 10
--         ELSE lp.StepOrder
--     END AS SelectedStepOrder,

--     ISNULL(
--         CASE
--             WHEN l.EstimatedDate IS NOT NULL
--             THEN CAST(YEAR(l.EstimatedDate) AS VARCHAR(4)) + ' ' + DATENAME(MONTH, l.EstimatedDate)
--             ELSE NULL
--         END,
--         '-'
--     ) AS TerminTarihi,

--     ISNULL(
--         NULLIF(
--             LTRIM(RTRIM(ISNULL(sp.FirstName, '') + ' ' + ISNULL(sp.LastName, '')))
--         , '')
--     , '-') AS SatisDanismani,

--     ISNULL(NULLIF(LTRIM(RTRIM(st.StoreDesc)), ''), '-') AS StoreName

-- FROM tmscrq.TMLead l
-- LEFT JOIN tmscrq.TMLeadStatu ls
--     ON ls.Id = l.StatuId
-- LEFT JOIN tmscrq.TMCustomer cu
--     ON cu.Id = l.CustomerId
-- LEFT JOIN tmscrq.TMProduct p
--     ON p.Id = l.ProductId
-- LEFT JOIN tmscrq.TMContactResource cr
--     ON cr.Id = l.ContactResourceId
-- LEFT JOIN dbo.KUser sp
--     ON sp.Id = l.SalesPersonKUserId
-- LEFT JOIN tmscrq.TMStore st
--     ON st.Id = l.StoreId
-- LEFT JOIN tmscrq.TMLeadProcess lp
--     ON lp.Id = l.ProcessID
-- LEFT JOIN tmscrq.TMLeadNextStep ns
--     ON ns.Id = l.NextStepId

-- WHERE
-- (
--     EXISTS
--     (
--         SELECT 1
--         FROM dbo.KUserRole ur
--         INNER JOIN dbo.KRole r
--             ON r.Id = ur.KRole_Id
--         WHERE ur.KUser_Id = @UserId
--           AND ur.IsDeleted = 0
--           AND r.IsDeleted = 0
--           AND r.Name IN ('TimesYonetici', 'TimesUstYonetici')
--     )
--     OR
--     (
--         EXISTS
--         (
--             SELECT 1
--             FROM dbo.KUserRole ur
--             INNER JOIN dbo.KRole r
--                 ON r.Id = ur.KRole_Id
--             WHERE ur.KUser_Id = @UserId
--               AND ur.IsDeleted = 0
--               AND r.IsDeleted = 0
--               AND r.Name IN ('TimesMagazaMuduru', 'TimesSatisPersoneli')
--         )
--         AND EXISTS
--         (
--             SELECT 1
--             FROM tmscrq.TMUser tu
--             WHERE tu.KUserID = @UserId
--               AND tu.StoreId = l.StoreId
--         )
--     )
-- )

-- AND
-- (
--     @MusteriAdi IS NULL
--     OR LTRIM(RTRIM(@MusteriAdi)) = ''
--     OR UPPER(LTRIM(RTRIM(ISNULL(cu.Name,'') + ' ' + ISNULL(cu.LastName,''))))
--        LIKE '%' + UPPER(LTRIM(RTRIM(@MusteriAdi))) + '%'
-- )

-- AND
-- (
--     @ProductName IS NULL
--     OR LTRIM(RTRIM(@ProductName)) = ''
--     OR
--     (
--         CHARINDEX(',', @ProductName) > 0
--         AND ISNULL(LTRIM(RTRIM(p.ProductName)), '') IN
--         (
--             SELECT LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', '')))
--             FROM STRING_SPLIT(CAST(@ProductName AS NVARCHAR(MAX)), ',')
--             WHERE LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', ''))) <> ''
--         )
--     )
--     OR
--     (
--         CHARINDEX(',', @ProductName) = 0
--         AND UPPER(ISNULL(LTRIM(RTRIM(p.ProductName)), ''))
--             LIKE '%' + UPPER(LTRIM(RTRIM(@ProductName))) + '%'
--     )
-- )

-- AND
-- (
--     @LeadCode IS NULL
--     OR LTRIM(RTRIM(@LeadCode)) = ''
--     OR UPPER(ISNULL(LTRIM(RTRIM(l.LeadCode)), '')) LIKE '%' + UPPER(LTRIM(RTRIM(@LeadCode))) + '%'
-- )

-- AND
-- (
--     @Tel IS NULL
--     OR LTRIM(RTRIM(@Tel)) = ''
--     OR UPPER(ISNULL(LTRIM(RTRIM(cu.Tel)), '')) LIKE '%' + UPPER(LTRIM(RTRIM(@Tel))) + '%'
-- )

-- AND
-- (
--     @CategoryName IS NULL
--     OR LTRIM(RTRIM(@CategoryName)) = ''
--     OR UPPER(ISNULL(LTRIM(RTRIM(p.CategoryName)), '')) IN
--     (
--         SELECT UPPER(LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value,'""',''),'[',''),']',''))))
--         FROM STRING_SPLIT(CAST(@CategoryName AS NVARCHAR(MAX)), ',')
--         WHERE LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value,'""',''),'[',''),']',''))) <> ''
--     )
-- )

-- AND
-- (
--     @StoreIds IS NULL
--     OR LTRIM(RTRIM(@StoreIds)) = ''
--     OR EXISTS
--     (
--         SELECT 1
--         FROM STRING_SPLIT(CAST(@StoreIds AS NVARCHAR(MAX)), ',') s
--         WHERE l.StoreId = TRY_CONVERT
--         (
--             uniqueidentifier,
--             LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(s.value, '""', ''), '[', ''), ']', '')))
--         )
--     )
-- )

-- AND
-- (
--     @SatisDanismaniIds IS NULL
--     OR LTRIM(RTRIM(@SatisDanismaniIds)) = ''
--     OR EXISTS
--     (
--         SELECT 1
--         FROM STRING_SPLIT(CAST(@SatisDanismaniIds AS NVARCHAR(MAX)), ',') s
--         WHERE l.SalesPersonKUserId = TRY_CONVERT
--         (
--             uniqueidentifier,
--             LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(s.value, '""', ''), '[', ''), ']', '')))
--         )
--     )
-- )

-- AND
-- (
--     @ProcessCode IS NULL
--     OR LTRIM(RTRIM(@ProcessCode)) = ''
--     OR UPPER(ISNULL(LTRIM(RTRIM(lp.Code)), '')) IN
--     (
--         SELECT UPPER(LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', ''))))
--         FROM STRING_SPLIT(CAST(@ProcessCode AS NVARCHAR(MAX)), ',')
--         WHERE LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', ''))) <> ''
--     )
-- )

-- -- DÜZELTİLEN ALAN: @StepOrder Filtresi (tek blok)
-- AND
-- (
--     @StepOrder IS NULL

--     OR

--     (
--         @StepOrder = 10
--         AND EXISTS
--         (
--             SELECT 1
--             FROM tmscrq.TMLeadReservation r
--             WHERE r.LeadId = l.Id
--               AND r.IsActive = 1
--               AND ISNULL(r.IsApproved,0) = 0
--         )
--     )

--     OR

--     (
--         @StepOrder <> 10
--         AND lp.StepOrder = @StepOrder
--     )
-- )

-- AND
-- (
--     @StartDate IS NULL
--     OR LTRIM(RTRIM(@StartDate)) = ''
--     OR l.CreatedAt >= CONVERT(date, @StartDate)
-- )

-- AND
-- (
--     @EndDate IS NULL
--     OR LTRIM(RTRIM(@EndDate)) = ''
--     OR l.CreatedAt < DATEADD(day, 1, CONVERT(date, @EndDate))
-- )

-- ORDER BY l.CreatedAt DESC;



SET LANGUAGE Turkish;

SELECT
CASE 
    WHEN EXISTS (
        SELECT 1 
        FROM tmscrq.TMLeadReservation r
        WHERE r.LeadId = l.Id
          AND r.IsActive = 1
          AND r.IsApproved = 1
    ) THEN N'Evet'

    WHEN EXISTS (
        SELECT 1 
        FROM tmscrq.TMLeadReservation r
        WHERE r.LeadId = l.Id
          AND r.IsActive = 1
          AND ISNULL(r.IsApproved,0) = 0
    ) THEN N'Onay Bekliyor'

    ELSE N'Hayır'
END AS RezerveDurumu,
    l.Id AS LeadId,
    l.IsReserved,
    ISNULL(NULLIF(LTRIM(RTRIM(l.LeadCode)), ''), '-') AS LeadNumarasi,
     FORMAT(l.CreatedAt, 'dd MMMM yyyy', 'tr-TR') AS TalepTarihi,

    p.Id AS ProductId,
    ISNULL(NULLIF(LTRIM(RTRIM(p.ProductName)), ''), '-') AS ProductName,
    ISNULL(NULLIF(LTRIM(RTRIM(p.Bracelet)), ''), '-') AS Bilezik,
    ISNULL(NULLIF(LTRIM(RTRIM(p.Brand)), ''), '-') AS Brand,
    ISNULL(NULLIF(LTRIM(RTRIM(p.Dial)), ''), '-') AS Kadran,
    ISNULL(NULLIF(LTRIM(RTRIM(p.ProductCode)), ''), '-') AS RefCode,
    ISNULL(NULLIF(LTRIM(RTRIM(p.Referance)), ''), '-') AS Referans,

    ISNULL(
        NULLIF(
            LTRIM(RTRIM(ISNULL(cu.Name, '') + ' ' + ISNULL(cu.LastName, '')))
        , '')
    , '-') AS Musteri,

    ISNULL(NULLIF(LTRIM(RTRIM(cu.CityName)), ''), '-') AS Lokasyon,
    ISNULL(NULLIF(LTRIM(RTRIM(cu.DistrictName)), ''), '-') AS Ilce,
    ISNULL(NULLIF(LTRIM(RTRIM(cu.CountryName)), ''), '-') AS Ulke,
    ISNULL(NULLIF(LTRIM(RTRIM(cu.Info)), ''), '-') AS MusteriInfo,

    CASE
        WHEN cu.IsShopping = 1 THEN N'Evet'
        WHEN cu.IsShopping = 0 THEN N'Hayır'
        ELSE '-'
    END AS AlisverisiVarMi,

    ISNULL(NULLIF(LTRIM(RTRIM(cu.Tel)), ''), '-') AS IrtibatNumarasi,
    ISNULL(NULLIF(LTRIM(RTRIM(cu.Email)), ''), '-') AS EmailAdresi,

    ISNULL(NULLIF(LTRIM(RTRIM(cr.ContactResourceName)), ''), '-') AS IletisimKaynagi,

    ISNULL(NULLIF(LTRIM(RTRIM(p.CategoryName)), ''), '-') AS CategoryName,
    '-' AS CategoryCode,

    ISNULL(NULLIF(LTRIM(RTRIM(ls.Name)), ''), '-') AS LeadDurumu,
    ISNULL(NULLIF(LTRIM(RTRIM(ns.Name)), ''), '-') AS SonrakiAdim,

    ISNULL(NULLIF(LTRIM(RTRIM(lp.Name)), ''), '-') AS ProcessName,
    ISNULL(NULLIF(LTRIM(RTRIM(lp.Code)), ''), '-') AS ProcessCode,
    lp.StepOrder,
    
    -- DÜZELTİLEN ALAN: SelectedStepOrder
    CASE
        WHEN EXISTS
        (
            SELECT 1
            FROM tmscrq.TMLeadReservation r
            WHERE r.LeadId = l.Id
              AND r.IsActive = 1
              AND ISNULL(r.IsApproved,0) = 0
        )
        THEN 10
        ELSE lp.StepOrder
    END AS SelectedStepOrder,

    ISNULL(
        CASE
            WHEN l.EstimatedDate IS NOT NULL
            THEN CAST(YEAR(l.EstimatedDate) AS VARCHAR(4)) + ' ' + DATENAME(MONTH, l.EstimatedDate)
            ELSE NULL
        END,
        '-'
    ) AS TerminTarihi,

    ISNULL(
        NULLIF(
            LTRIM(RTRIM(ISNULL(sp.FirstName, '') + ' ' + ISNULL(sp.LastName, '')))
        , '')
    , '-') AS SatisDanismani,

    ISNULL(NULLIF(LTRIM(RTRIM(st.StoreDesc)), ''), '-') AS StoreName

FROM tmscrq.TMLead l
LEFT JOIN tmscrq.TMLeadStatu ls
    ON ls.Id = l.StatuId
LEFT JOIN tmscrq.TMCustomer cu
    ON cu.Id = l.CustomerId
LEFT JOIN tmscrq.TMProduct p
    ON p.Id = l.ProductId
LEFT JOIN tmscrq.TMContactResource cr
    ON cr.Id = l.ContactResourceId
LEFT JOIN dbo.KUser sp
    ON sp.Id = l.SalesPersonKUserId
LEFT JOIN tmscrq.TMStore st
    ON st.Id = l.StoreId
LEFT JOIN tmscrq.TMLeadProcess lp
    ON lp.Id = l.ProcessID
LEFT JOIN tmscrq.TMLeadNextStep ns
    ON ns.Id = l.NextStepId

WHERE
(
    EXISTS
    (
        SELECT 1
        FROM dbo.KUserRole ur
        INNER JOIN dbo.KRole r
            ON r.Id = ur.KRole_Id
        WHERE ur.KUser_Id = @UserId
          AND ur.IsDeleted = 0
          AND r.IsDeleted = 0
          AND r.Name IN ('TimesYonetici', 'TimesUstYonetici')
    )
    OR
    (
        EXISTS
        (
            SELECT 1
            FROM dbo.KUserRole ur
            INNER JOIN dbo.KRole r
                ON r.Id = ur.KRole_Id
            WHERE ur.KUser_Id = @UserId
              AND ur.IsDeleted = 0
              AND r.IsDeleted = 0
              AND r.Name IN ('TimesMagazaMuduru', 'TimesSatisPersoneli')
        )
        AND EXISTS
        (
            SELECT 1
            FROM tmscrq.TMUser tu
            WHERE tu.KUserID = @UserId
              AND tu.StoreId = l.StoreId
        )
    )
)

AND
(
    ISNULL(@MusteriAdi, '') = ''
    OR UPPER(ISNULL(cu.Name, '')) LIKE '%' + UPPER(LTRIM(RTRIM(@MusteriAdi))) + '%'
    OR UPPER(ISNULL(cu.LastName, '')) LIKE '%' + UPPER(LTRIM(RTRIM(@MusteriAdi))) + '%'
    OR UPPER(
        ISNULL(cu.Name, '') + ' ' + ISNULL(cu.LastName, '')
    ) LIKE '%' + UPPER(LTRIM(RTRIM(@MusteriAdi))) + '%'
)

AND
(
    @ProductName IS NULL
    OR LTRIM(RTRIM(@ProductName)) = ''
    OR
    (
        CHARINDEX(',', @ProductName) > 0
        AND ISNULL(LTRIM(RTRIM(p.ProductName)), '') IN
        (
            SELECT LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', '')))
            FROM STRING_SPLIT(CAST(@ProductName AS NVARCHAR(MAX)), ',')
            WHERE LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', ''))) <> ''
        )
    )
    OR
    (
        CHARINDEX(',', @ProductName) = 0
        AND UPPER(ISNULL(LTRIM(RTRIM(p.ProductName)), ''))
            LIKE '%' + UPPER(LTRIM(RTRIM(@ProductName))) + '%'
    )
)

AND
(
    ISNULL(@LeadCode, '') = ''
    OR UPPER(ISNULL(l.LeadCode, ''))
        LIKE '%' + UPPER(LTRIM(RTRIM(@LeadCode))) + '%'
    OR REPLACE(
        REPLACE(
            REPLACE(
                UPPER(ISNULL(l.LeadCode, '')),
                '-', ''
            ),
            ' ', ''
        ),
        '/', ''
    )
    LIKE '%' +
    REPLACE(
        REPLACE(
            REPLACE(
                UPPER(LTRIM(RTRIM(@LeadCode))),
                '-', ''
            ),
            ' ', ''
        ),
        '/', ''
    )
    + '%'
)

AND
(
    @Tel IS NULL
    OR LTRIM(RTRIM(@Tel)) = ''
    OR UPPER(ISNULL(LTRIM(RTRIM(cu.Tel)), '')) LIKE '%' + UPPER(LTRIM(RTRIM(@Tel))) + '%'
)

AND
(
    @CategoryName IS NULL
    OR LTRIM(RTRIM(@CategoryName)) = ''
    OR UPPER(ISNULL(LTRIM(RTRIM(p.CategoryName)), '')) IN
    (
        SELECT UPPER(LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value,'""',''),'[',''),']',''))))
        FROM STRING_SPLIT(CAST(@CategoryName AS NVARCHAR(MAX)), ',')
        WHERE LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value,'""',''),'[',''),']',''))) <> ''
    )
)

AND
(
    @StoreIds IS NULL
    OR LTRIM(RTRIM(@StoreIds)) = ''
    OR EXISTS
    (
        SELECT 1
        FROM STRING_SPLIT(CAST(@StoreIds AS NVARCHAR(MAX)), ',') s
        WHERE l.StoreId = TRY_CONVERT
        (
            uniqueidentifier,
            LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(s.value, '""', ''), '[', ''), ']', '')))
        )
    )
)

AND
(
    @SatisDanismaniIds IS NULL
    OR LTRIM(RTRIM(@SatisDanismaniIds)) = ''
    OR EXISTS
    (
        SELECT 1
        FROM STRING_SPLIT(CAST(@SatisDanismaniIds AS NVARCHAR(MAX)), ',') s
        WHERE l.SalesPersonKUserId = TRY_CONVERT
        (
            uniqueidentifier,
            LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(s.value, '""', ''), '[', ''), ']', '')))
        )
    )
)

AND
(
    ISNULL(@ProcessCode, '') = ''
    OR EXISTS
    (
        SELECT 1
        FROM STRING_SPLIT(
            CONVERT(NVARCHAR(MAX), @ProcessCode),
            ','
        ) AS s
        WHERE
            UPPER(LTRIM(RTRIM(s.value))) =
            UPPER(LTRIM(RTRIM(ISNULL(lp.Code, ''))))
    )
)

-- DÜZELTİLEN ALAN: @StepOrder Filtresi (0 verilince tümü gelsin)
AND
(
    @StepOrder IS NULL
    OR @StepOrder = 0  -- 👈 YENİ EKLENDI: 0 verilince tüm kayıtlar gelir
    OR
    (
        @StepOrder = 10
        AND EXISTS
        (
            SELECT 1
            FROM tmscrq.TMLeadReservation r
            WHERE r.LeadId = l.Id
              AND r.IsActive = 1
              AND ISNULL(r.IsApproved,0) = 0
        )
    )
    OR
    (
        @StepOrder <> 10
        AND lp.StepOrder = @StepOrder
    )
)

AND
(
    @StartDate IS NULL
    OR LTRIM(RTRIM(@StartDate)) = ''
    OR l.CreatedAt >= CONVERT(date, @StartDate)
)

AND
(
    @EndDate IS NULL
    OR LTRIM(RTRIM(@EndDate)) = ''
    OR l.CreatedAt < DATEADD(day, 1, CONVERT(date, @EndDate))
)

ORDER BY l.CreatedAt DESC;", new string[] { "RezerveDurumu", "LeadId", "IsReserved", "LeadNumarasi", "TalepTarihi", "ProductId", "ProductName", "Bilezik", "Brand", "Kadran", "RefCode", "Referans", "Musteri", "Lokasyon", "Ilce", "Ulke", "MusteriInfo", "AlisverisiVarMi", "IrtibatNumarasi", "EmailAdresi", "IletisimKaynagi", "CategoryName", "CategoryCode", "LeadDurumu", "SonrakiAdim", "ProcessName", "ProcessCode", "StepOrder", "SelectedStepOrder", "TerminTarihi", "SatisDanismani", "StoreName" }, prms_TM_GetLeads_0.ToArray());
            ;


            return Ok(result);
        }


        [HttpPost, Route("LeadListComponent_576136_onClick")]
        public IActionResult LeadListComponent_576136_onClick(LeadListComponent_576136_onClick_Request request)
        {

            KProviderManager.Authorization.IsAuthorizedForRoles(appId, appName, screenId, screenName, new List<string> { $"70de6cfc-6087-6059-59b4-0b5a8527af6b", "4da1f213-c8e4-0b50-5c84-02fd13f1a622", "c4e882ef-977d-f613-7694-230ac83919d2", "b4bfd39c-ac02-f442-c899-7a2374a45b47", "cdb536b0-6297-155f-d446-8453d8a60304", "TimesYonetici", "TimesUstYonetici", "TimesSatisPersoneli", "TimesMagazaMuduru", "TimesAdmin" });

            var result = new LeadListComponent_576136_onClick_Response();

            var prms_TM_GetLeads_0 = new List<kSqlParameter>();
            prms_TM_GetLeads_0.Add(new kSqlParameter() { Name = "StepOrder", Value = "2".ConvertToType<Int32>() });
            prms_TM_GetLeads_0.Add(new kSqlParameter() { Name = "UserId", Value = Kuika.Common.KContext.CurrentUser?.Id });
            prms_TM_GetLeads_0.Add(new kSqlParameter() { Name = "MusteriAdi", Value = request.MusteriAdi_0 });
            prms_TM_GetLeads_0.Add(new kSqlParameter() { Name = "ProductName", Value = request.ProductName_0 });
            prms_TM_GetLeads_0.Add(new kSqlParameter() { Name = "LeadCode", Value = request.LeadCode_0 });
            prms_TM_GetLeads_0.Add(new kSqlParameter() { Name = "Tel", Value = request.Tel_0 });
            prms_TM_GetLeads_0.Add(new kSqlParameter() { Name = "CategoryName", Value = request.CategoryName_0 });
            prms_TM_GetLeads_0.Add(new kSqlParameter() { Name = "StoreIds", Value = request.StoreIds_0 });
            prms_TM_GetLeads_0.Add(new kSqlParameter() { Name = "SatisDanismaniIds", Value = request.SatisDanismaniIds_0 });
            prms_TM_GetLeads_0.Add(new kSqlParameter() { Name = "ProcessCode", Value = request.ProcessCode_0 });
            prms_TM_GetLeads_0.Add(new kSqlParameter() { Name = "StartDate", Value = request.StartDate_0 });
            prms_TM_GetLeads_0.Add(new kSqlParameter() { Name = "EndDate", Value = request.EndDate_0 });
            using var auditTM_GetLeads_0 = ActionAuditScope.Begin("816a07e4-a2ea-f6ef-fd52-731b1adddd5b", "TM_GetLeads", applicationName: "wbTimesCRM", screenOrEndpointName: "LeadList");
            result.TM_GetLeads = KPersister.Fetch(KContext.GetConnectionString(), @"-- SET LANGUAGE Turkish;

-- SELECT
-- CASE 
--     WHEN EXISTS (
--         SELECT 1 
--         FROM tmscrq.TMLeadReservation r
--         WHERE r.LeadId = l.Id
--           AND r.IsActive = 1
--           AND r.IsApproved = 1
--     ) THEN N'Evet'

--     WHEN EXISTS (
--         SELECT 1 
--         FROM tmscrq.TMLeadReservation r
--         WHERE r.LeadId = l.Id
--           AND r.IsActive = 1
--           AND ISNULL(r.IsApproved,0) = 0
--     ) THEN N'Onay Bekliyor'

--     ELSE N'Hayır'
-- END AS RezerveDurumu,
--     l.Id AS LeadId,
--     l.IsReserved,
--     ISNULL(NULLIF(LTRIM(RTRIM(l.LeadCode)), ''), '-') AS LeadNumarasi,
--     CONVERT(varchar(10), l.CreatedAt, 103) AS TalepTarihi,

--     p.Id AS ProductId,
--     ISNULL(NULLIF(LTRIM(RTRIM(p.ProductName)), ''), '-') AS ProductName,
--     ISNULL(NULLIF(LTRIM(RTRIM(p.Bracelet)), ''), '-') AS Bilezik,
--     ISNULL(NULLIF(LTRIM(RTRIM(p.Brand)), ''), '-') AS Brand,
--     ISNULL(NULLIF(LTRIM(RTRIM(p.Dial)), ''), '-') AS Kadran,
--     ISNULL(NULLIF(LTRIM(RTRIM(p.ProductCode)), ''), '-') AS RefCode,
--     ISNULL(NULLIF(LTRIM(RTRIM(p.Referance)), ''), '-') AS Referans,

--     ISNULL(
--         NULLIF(
--             LTRIM(RTRIM(ISNULL(cu.Name, '') + ' ' + ISNULL(cu.LastName, '')))
--         , '')
--     , '-') AS Musteri,

--     ISNULL(NULLIF(LTRIM(RTRIM(cu.CityName)), ''), '-') AS Lokasyon,
--     ISNULL(NULLIF(LTRIM(RTRIM(cu.DistrictName)), ''), '-') AS Ilce,
--     ISNULL(NULLIF(LTRIM(RTRIM(cu.CountryName)), ''), '-') AS Ulke,
--     ISNULL(NULLIF(LTRIM(RTRIM(cu.Info)), ''), '-') AS MusteriInfo,

--     CASE
--         WHEN cu.IsShopping = 1 THEN N'Evet'
--         WHEN cu.IsShopping = 0 THEN N'Hayır'
--         ELSE '-'
--     END AS AlisverisiVarMi,

--     ISNULL(NULLIF(LTRIM(RTRIM(cu.Tel)), ''), '-') AS IrtibatNumarasi,
--     ISNULL(NULLIF(LTRIM(RTRIM(cu.Email)), ''), '-') AS EmailAdresi,

--     ISNULL(NULLIF(LTRIM(RTRIM(cr.ContactResourceName)), ''), '-') AS IletisimKaynagi,

--     ISNULL(NULLIF(LTRIM(RTRIM(p.CategoryName)), ''), '-') AS CategoryName,
--     '-' AS CategoryCode,

--     ISNULL(NULLIF(LTRIM(RTRIM(ls.Name)), ''), '-') AS LeadDurumu,
--     ISNULL(NULLIF(LTRIM(RTRIM(ns.Name)), ''), '-') AS SonrakiAdim,

--     ISNULL(NULLIF(LTRIM(RTRIM(lp.Name)), ''), '-') AS ProcessName,
--     ISNULL(NULLIF(LTRIM(RTRIM(lp.Code)), ''), '-') AS ProcessCode,
--     lp.StepOrder,
-- CASE
--     WHEN EXISTS
--     (
--         SELECT 1
--         FROM tmscrq.TMLeadReservation r
--         WHERE r.LeadId = l.Id
--           AND r.IsActive = 1
--           AND ISNULL(r.IsApproved,0) = 0
--     )
--     THEN 10
--     ELSE lp.StepOrder
-- END AS SelectedStepOrder,

--     ISNULL(
--         CASE
--             WHEN l.EstimatedDate IS NOT NULL
--             THEN CAST(YEAR(l.EstimatedDate) AS VARCHAR(4)) + ' ' + DATENAME(MONTH, l.EstimatedDate)
--             ELSE NULL
--         END,
--         '-'
--     ) AS TerminTarihi,

--     ISNULL(
--         NULLIF(
--             LTRIM(RTRIM(ISNULL(sp.FirstName, '') + ' ' + ISNULL(sp.LastName, '')))
--         , '')
--     , '-') AS SatisDanismani,

--     ISNULL(NULLIF(LTRIM(RTRIM(st.StoreDesc)), ''), '-') AS StoreName

-- FROM tmscrq.TMLead l
-- LEFT JOIN tmscrq.TMLeadStatu ls
--     ON ls.Id = l.StatuId
-- LEFT JOIN tmscrq.TMCustomer cu
--     ON cu.Id = l.CustomerId
-- LEFT JOIN tmscrq.TMProduct p
--     ON p.Id = l.ProductId
-- LEFT JOIN tmscrq.TMContactResource cr
--     ON cr.Id = l.ContactResourceId
-- LEFT JOIN dbo.KUser sp
--     ON sp.Id = l.SalesPersonKUserId
-- LEFT JOIN tmscrq.TMStore st
--     ON st.Id = l.StoreId
-- LEFT JOIN tmscrq.TMLeadProcess lp
--     ON lp.Id = l.ProcessID
-- LEFT JOIN tmscrq.TMLeadNextStep ns
--     ON ns.Id = l.NextStepId

-- WHERE
-- (
--     EXISTS
--     (
--         SELECT 1
--         FROM dbo.KUserRole ur
--         INNER JOIN dbo.KRole r
--             ON r.Id = ur.KRole_Id
--         WHERE ur.KUser_Id = @UserId
--           AND ur.IsDeleted = 0
--           AND r.IsDeleted = 0
--           AND r.Name IN ('TimesYonetici', 'TimesUstYonetici')
--     )
--     OR
--     (
--         EXISTS
--         (
--             SELECT 1
--             FROM dbo.KUserRole ur
--             INNER JOIN dbo.KRole r
--                 ON r.Id = ur.KRole_Id
--             WHERE ur.KUser_Id = @UserId
--               AND ur.IsDeleted = 0
--               AND r.IsDeleted = 0
--               AND r.Name IN ('TimesMagazaMuduru', 'TimesSatisPersoneli')
--         )
--         AND EXISTS
--         (
--             SELECT 1
--             FROM tmscrq.TMUser tu
--             WHERE tu.KUserID = @UserId
--               AND tu.StoreId = l.StoreId
--         )
--     )
-- )

-- AND
-- (
--     @MusteriAdi IS NULL
--     OR LTRIM(RTRIM(@MusteriAdi)) = ''
--     OR UPPER(LTRIM(RTRIM(ISNULL(cu.Name,'') + ' ' + ISNULL(cu.LastName,''))))
--        LIKE '%' + UPPER(LTRIM(RTRIM(@MusteriAdi))) + '%'
-- )

-- AND
-- (
--     @ProductName IS NULL
--     OR LTRIM(RTRIM(@ProductName)) = ''
--     OR
--     (
--         CHARINDEX(',', @ProductName) > 0
--         AND ISNULL(LTRIM(RTRIM(p.ProductName)), '') IN
--         (
--             SELECT LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', '')))
--             FROM STRING_SPLIT(CAST(@ProductName AS NVARCHAR(MAX)), ',')
--             WHERE LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', ''))) <> ''
--         )
--     )
--     OR
--     (
--         CHARINDEX(',', @ProductName) = 0
--         AND UPPER(ISNULL(LTRIM(RTRIM(p.ProductName)), ''))
--             LIKE '%' + UPPER(LTRIM(RTRIM(@ProductName))) + '%'
--     )
-- )

-- AND
-- (
--     @LeadCode IS NULL
--     OR LTRIM(RTRIM(@LeadCode)) = ''
--     OR UPPER(ISNULL(LTRIM(RTRIM(l.LeadCode)), '')) LIKE '%' + UPPER(LTRIM(RTRIM(@LeadCode))) + '%'
-- )

-- AND
-- (
--     @Tel IS NULL
--     OR LTRIM(RTRIM(@Tel)) = ''
--     OR UPPER(ISNULL(LTRIM(RTRIM(cu.Tel)), '')) LIKE '%' + UPPER(LTRIM(RTRIM(@Tel))) + '%'
-- )

-- -- AND
-- -- (
-- --     @CategoryName IS NULL
-- --     OR LTRIM(RTRIM(@CategoryName)) = ''
-- --     OR
-- --     (
-- --         EXISTS
-- --         (
-- --             SELECT 1
-- --             FROM STRING_SPLIT(CAST(@CategoryName AS NVARCHAR(MAX)), ',') c
-- --             WHERE UPPER(LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(c.value, '""', ''), '[', ''), ']', '')))) = 'DEFAULT'
-- --         )
-- --         AND (p.CategoryName IS NULL OR LTRIM(RTRIM(p.CategoryName)) = '')
-- --     )
-- --     OR UPPER(ISNULL(LTRIM(RTRIM(p.CategoryName)), '')) IN
-- --     (
-- --         SELECT UPPER(LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', ''))))
-- --         FROM STRING_SPLIT(CAST(@CategoryName AS NVARCHAR(MAX)), ',')
-- --         WHERE LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', ''))) <> ''
-- --           AND UPPER(LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', '')))) <> 'DEFAULT'
-- --     )
-- -- )

-- AND
-- (
--     @CategoryName IS NULL
--     OR LTRIM(RTRIM(@CategoryName)) = ''
--     OR UPPER(ISNULL(LTRIM(RTRIM(p.CategoryName)), '')) IN
--     (
--         SELECT UPPER(LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value,'""',''),'[',''),']',''))))
--         FROM STRING_SPLIT(CAST(@CategoryName AS NVARCHAR(MAX)), ',')
--         WHERE LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value,'""',''),'[',''),']',''))) <> ''
--     )
-- )

-- AND
-- (
--     @StoreIds IS NULL
--     OR LTRIM(RTRIM(@StoreIds)) = ''
--     OR EXISTS
--     (
--         SELECT 1
--         FROM STRING_SPLIT(CAST(@StoreIds AS NVARCHAR(MAX)), ',') s
--         WHERE l.StoreId = TRY_CONVERT
--         (
--             uniqueidentifier,
--             LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(s.value, '""', ''), '[', ''), ']', '')))
--         )
--     )
-- )

-- AND
-- (
--     @SatisDanismaniIds IS NULL
--     OR LTRIM(RTRIM(@SatisDanismaniIds)) = ''
--     OR EXISTS
--     (
--         SELECT 1
--         FROM STRING_SPLIT(CAST(@SatisDanismaniIds AS NVARCHAR(MAX)), ',') s
--         WHERE l.SalesPersonKUserId = TRY_CONVERT
--         (
--             uniqueidentifier,
--             LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(s.value, '""', ''), '[', ''), ']', '')))
--         )
--     )
-- )

-- AND
-- (
--     @ProcessCode IS NULL
--     OR LTRIM(RTRIM(@ProcessCode)) = ''
--     OR UPPER(ISNULL(LTRIM(RTRIM(lp.Code)), '')) IN
--     (
--         SELECT UPPER(LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', ''))))
--         FROM STRING_SPLIT(CAST(@ProcessCode AS NVARCHAR(MAX)), ',')
--         WHERE LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', ''))) <> ''
--     )
-- )

-- AND
-- (
--     @StepOrder IS NULL

--     OR
--     (
--         @StepOrder = 10
--         AND EXISTS
--         (
--             SELECT 1
--             FROM tmscrq.TMLeadReservation r
--             WHERE r.LeadId = l.Id
--               AND r.IsActive = 1
--               AND ISNULL(r.IsApproved,0) = 0
--         )
--     )

--     OR
--     (
--         @StepOrder <> 10
--         AND lp.StepOrder = @StepOrder
--     )
-- )

-- AND
-- (
--     @StartDate IS NULL
--     OR LTRIM(RTRIM(@StartDate)) = ''
--     OR l.CreatedAt >= CONVERT(date, @StartDate)
-- )

-- AND
-- (
--     @EndDate IS NULL
--     OR LTRIM(RTRIM(@EndDate)) = ''
--     OR l.CreatedAt < DATEADD(day, 1, CONVERT(date, @EndDate))
-- )

-- ORDER BY l.CreatedAt DESC;

------------------------++++++++++++++++++++++++-------------------
-- SET LANGUAGE Turkish;

-- SELECT
-- CASE 
--     WHEN EXISTS (
--         SELECT 1 
--         FROM tmscrq.TMLeadReservation r
--         WHERE r.LeadId = l.Id
--           AND r.IsActive = 1
--           AND r.IsApproved = 1
--     ) THEN N'Evet'

--     WHEN EXISTS (
--         SELECT 1 
--         FROM tmscrq.TMLeadReservation r
--         WHERE r.LeadId = l.Id
--           AND r.IsActive = 1
--           AND ISNULL(r.IsApproved,0) = 0
--     ) THEN N'Onay Bekliyor'

--     ELSE N'Hayır'
-- END AS RezerveDurumu,
--     l.Id AS LeadId,
--     l.IsReserved,
--     ISNULL(NULLIF(LTRIM(RTRIM(l.LeadCode)), ''), '-') AS LeadNumarasi,
--     CONVERT(varchar(10), l.CreatedAt, 103) AS TalepTarihi,

--     p.Id AS ProductId,
--     ISNULL(NULLIF(LTRIM(RTRIM(p.ProductName)), ''), '-') AS ProductName,
--     ISNULL(NULLIF(LTRIM(RTRIM(p.Bracelet)), ''), '-') AS Bilezik,
--     ISNULL(NULLIF(LTRIM(RTRIM(p.Brand)), ''), '-') AS Brand,
--     ISNULL(NULLIF(LTRIM(RTRIM(p.Dial)), ''), '-') AS Kadran,
--     ISNULL(NULLIF(LTRIM(RTRIM(p.ProductCode)), ''), '-') AS RefCode,
--     ISNULL(NULLIF(LTRIM(RTRIM(p.Referance)), ''), '-') AS Referans,

--     ISNULL(
--         NULLIF(
--             LTRIM(RTRIM(ISNULL(cu.Name, '') + ' ' + ISNULL(cu.LastName, '')))
--         , '')
--     , '-') AS Musteri,

--     ISNULL(NULLIF(LTRIM(RTRIM(cu.CityName)), ''), '-') AS Lokasyon,
--     ISNULL(NULLIF(LTRIM(RTRIM(cu.DistrictName)), ''), '-') AS Ilce,
--     ISNULL(NULLIF(LTRIM(RTRIM(cu.CountryName)), ''), '-') AS Ulke,
--     ISNULL(NULLIF(LTRIM(RTRIM(cu.Info)), ''), '-') AS MusteriInfo,

--     CASE
--         WHEN cu.IsShopping = 1 THEN N'Evet'
--         WHEN cu.IsShopping = 0 THEN N'Hayır'
--         ELSE '-'
--     END AS AlisverisiVarMi,

--     ISNULL(NULLIF(LTRIM(RTRIM(cu.Tel)), ''), '-') AS IrtibatNumarasi,
--     ISNULL(NULLIF(LTRIM(RTRIM(cu.Email)), ''), '-') AS EmailAdresi,

--     ISNULL(NULLIF(LTRIM(RTRIM(cr.ContactResourceName)), ''), '-') AS IletisimKaynagi,

--     ISNULL(NULLIF(LTRIM(RTRIM(p.CategoryName)), ''), '-') AS CategoryName,
--     '-' AS CategoryCode,

--     ISNULL(NULLIF(LTRIM(RTRIM(ls.Name)), ''), '-') AS LeadDurumu,
--     ISNULL(NULLIF(LTRIM(RTRIM(ns.Name)), ''), '-') AS SonrakiAdim,

--     ISNULL(NULLIF(LTRIM(RTRIM(lp.Name)), ''), '-') AS ProcessName,
--     ISNULL(NULLIF(LTRIM(RTRIM(lp.Code)), ''), '-') AS ProcessCode,
--     lp.StepOrder,
    
--     -- DÜZELTİLEN ALAN: SelectedStepOrder
--     CASE
--         WHEN EXISTS
--         (
--             SELECT 1
--             FROM tmscrq.TMLeadReservation r
--             WHERE r.LeadId = l.Id
--               AND r.IsActive = 1
--               AND ISNULL(r.IsApproved,0) = 0
--         )
--         THEN 10
--         ELSE lp.StepOrder
--     END AS SelectedStepOrder,

--     ISNULL(
--         CASE
--             WHEN l.EstimatedDate IS NOT NULL
--             THEN CAST(YEAR(l.EstimatedDate) AS VARCHAR(4)) + ' ' + DATENAME(MONTH, l.EstimatedDate)
--             ELSE NULL
--         END,
--         '-'
--     ) AS TerminTarihi,

--     ISNULL(
--         NULLIF(
--             LTRIM(RTRIM(ISNULL(sp.FirstName, '') + ' ' + ISNULL(sp.LastName, '')))
--         , '')
--     , '-') AS SatisDanismani,

--     ISNULL(NULLIF(LTRIM(RTRIM(st.StoreDesc)), ''), '-') AS StoreName

-- FROM tmscrq.TMLead l
-- LEFT JOIN tmscrq.TMLeadStatu ls
--     ON ls.Id = l.StatuId
-- LEFT JOIN tmscrq.TMCustomer cu
--     ON cu.Id = l.CustomerId
-- LEFT JOIN tmscrq.TMProduct p
--     ON p.Id = l.ProductId
-- LEFT JOIN tmscrq.TMContactResource cr
--     ON cr.Id = l.ContactResourceId
-- LEFT JOIN dbo.KUser sp
--     ON sp.Id = l.SalesPersonKUserId
-- LEFT JOIN tmscrq.TMStore st
--     ON st.Id = l.StoreId
-- LEFT JOIN tmscrq.TMLeadProcess lp
--     ON lp.Id = l.ProcessID
-- LEFT JOIN tmscrq.TMLeadNextStep ns
--     ON ns.Id = l.NextStepId

-- WHERE
-- (
--     EXISTS
--     (
--         SELECT 1
--         FROM dbo.KUserRole ur
--         INNER JOIN dbo.KRole r
--             ON r.Id = ur.KRole_Id
--         WHERE ur.KUser_Id = @UserId
--           AND ur.IsDeleted = 0
--           AND r.IsDeleted = 0
--           AND r.Name IN ('TimesYonetici', 'TimesUstYonetici')
--     )
--     OR
--     (
--         EXISTS
--         (
--             SELECT 1
--             FROM dbo.KUserRole ur
--             INNER JOIN dbo.KRole r
--                 ON r.Id = ur.KRole_Id
--             WHERE ur.KUser_Id = @UserId
--               AND ur.IsDeleted = 0
--               AND r.IsDeleted = 0
--               AND r.Name IN ('TimesMagazaMuduru', 'TimesSatisPersoneli')
--         )
--         AND EXISTS
--         (
--             SELECT 1
--             FROM tmscrq.TMUser tu
--             WHERE tu.KUserID = @UserId
--               AND tu.StoreId = l.StoreId
--         )
--     )
-- )

-- AND
-- (
--     @MusteriAdi IS NULL
--     OR LTRIM(RTRIM(@MusteriAdi)) = ''
--     OR UPPER(LTRIM(RTRIM(ISNULL(cu.Name,'') + ' ' + ISNULL(cu.LastName,''))))
--        LIKE '%' + UPPER(LTRIM(RTRIM(@MusteriAdi))) + '%'
-- )

-- AND
-- (
--     @ProductName IS NULL
--     OR LTRIM(RTRIM(@ProductName)) = ''
--     OR
--     (
--         CHARINDEX(',', @ProductName) > 0
--         AND ISNULL(LTRIM(RTRIM(p.ProductName)), '') IN
--         (
--             SELECT LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', '')))
--             FROM STRING_SPLIT(CAST(@ProductName AS NVARCHAR(MAX)), ',')
--             WHERE LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', ''))) <> ''
--         )
--     )
--     OR
--     (
--         CHARINDEX(',', @ProductName) = 0
--         AND UPPER(ISNULL(LTRIM(RTRIM(p.ProductName)), ''))
--             LIKE '%' + UPPER(LTRIM(RTRIM(@ProductName))) + '%'
--     )
-- )

-- AND
-- (
--     @LeadCode IS NULL
--     OR LTRIM(RTRIM(@LeadCode)) = ''
--     OR UPPER(ISNULL(LTRIM(RTRIM(l.LeadCode)), '')) LIKE '%' + UPPER(LTRIM(RTRIM(@LeadCode))) + '%'
-- )

-- AND
-- (
--     @Tel IS NULL
--     OR LTRIM(RTRIM(@Tel)) = ''
--     OR UPPER(ISNULL(LTRIM(RTRIM(cu.Tel)), '')) LIKE '%' + UPPER(LTRIM(RTRIM(@Tel))) + '%'
-- )

-- AND
-- (
--     @CategoryName IS NULL
--     OR LTRIM(RTRIM(@CategoryName)) = ''
--     OR UPPER(ISNULL(LTRIM(RTRIM(p.CategoryName)), '')) IN
--     (
--         SELECT UPPER(LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value,'""',''),'[',''),']',''))))
--         FROM STRING_SPLIT(CAST(@CategoryName AS NVARCHAR(MAX)), ',')
--         WHERE LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value,'""',''),'[',''),']',''))) <> ''
--     )
-- )

-- AND
-- (
--     @StoreIds IS NULL
--     OR LTRIM(RTRIM(@StoreIds)) = ''
--     OR EXISTS
--     (
--         SELECT 1
--         FROM STRING_SPLIT(CAST(@StoreIds AS NVARCHAR(MAX)), ',') s
--         WHERE l.StoreId = TRY_CONVERT
--         (
--             uniqueidentifier,
--             LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(s.value, '""', ''), '[', ''), ']', '')))
--         )
--     )
-- )

-- AND
-- (
--     @SatisDanismaniIds IS NULL
--     OR LTRIM(RTRIM(@SatisDanismaniIds)) = ''
--     OR EXISTS
--     (
--         SELECT 1
--         FROM STRING_SPLIT(CAST(@SatisDanismaniIds AS NVARCHAR(MAX)), ',') s
--         WHERE l.SalesPersonKUserId = TRY_CONVERT
--         (
--             uniqueidentifier,
--             LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(s.value, '""', ''), '[', ''), ']', '')))
--         )
--     )
-- )

-- AND
-- (
--     @ProcessCode IS NULL
--     OR LTRIM(RTRIM(@ProcessCode)) = ''
--     OR UPPER(ISNULL(LTRIM(RTRIM(lp.Code)), '')) IN
--     (
--         SELECT UPPER(LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', ''))))
--         FROM STRING_SPLIT(CAST(@ProcessCode AS NVARCHAR(MAX)), ',')
--         WHERE LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', ''))) <> ''
--     )
-- )

-- -- DÜZELTİLEN ALAN: @StepOrder Filtresi (tek blok)
-- AND
-- (
--     @StepOrder IS NULL

--     OR

--     (
--         @StepOrder = 10
--         AND EXISTS
--         (
--             SELECT 1
--             FROM tmscrq.TMLeadReservation r
--             WHERE r.LeadId = l.Id
--               AND r.IsActive = 1
--               AND ISNULL(r.IsApproved,0) = 0
--         )
--     )

--     OR

--     (
--         @StepOrder <> 10
--         AND lp.StepOrder = @StepOrder
--     )
-- )

-- AND
-- (
--     @StartDate IS NULL
--     OR LTRIM(RTRIM(@StartDate)) = ''
--     OR l.CreatedAt >= CONVERT(date, @StartDate)
-- )

-- AND
-- (
--     @EndDate IS NULL
--     OR LTRIM(RTRIM(@EndDate)) = ''
--     OR l.CreatedAt < DATEADD(day, 1, CONVERT(date, @EndDate))
-- )

-- ORDER BY l.CreatedAt DESC;



SET LANGUAGE Turkish;

SELECT
CASE 
    WHEN EXISTS (
        SELECT 1 
        FROM tmscrq.TMLeadReservation r
        WHERE r.LeadId = l.Id
          AND r.IsActive = 1
          AND r.IsApproved = 1
    ) THEN N'Evet'

    WHEN EXISTS (
        SELECT 1 
        FROM tmscrq.TMLeadReservation r
        WHERE r.LeadId = l.Id
          AND r.IsActive = 1
          AND ISNULL(r.IsApproved,0) = 0
    ) THEN N'Onay Bekliyor'

    ELSE N'Hayır'
END AS RezerveDurumu,
    l.Id AS LeadId,
    l.IsReserved,
    ISNULL(NULLIF(LTRIM(RTRIM(l.LeadCode)), ''), '-') AS LeadNumarasi,
     FORMAT(l.CreatedAt, 'dd MMMM yyyy', 'tr-TR') AS TalepTarihi,

    p.Id AS ProductId,
    ISNULL(NULLIF(LTRIM(RTRIM(p.ProductName)), ''), '-') AS ProductName,
    ISNULL(NULLIF(LTRIM(RTRIM(p.Bracelet)), ''), '-') AS Bilezik,
    ISNULL(NULLIF(LTRIM(RTRIM(p.Brand)), ''), '-') AS Brand,
    ISNULL(NULLIF(LTRIM(RTRIM(p.Dial)), ''), '-') AS Kadran,
    ISNULL(NULLIF(LTRIM(RTRIM(p.ProductCode)), ''), '-') AS RefCode,
    ISNULL(NULLIF(LTRIM(RTRIM(p.Referance)), ''), '-') AS Referans,

    ISNULL(
        NULLIF(
            LTRIM(RTRIM(ISNULL(cu.Name, '') + ' ' + ISNULL(cu.LastName, '')))
        , '')
    , '-') AS Musteri,

    ISNULL(NULLIF(LTRIM(RTRIM(cu.CityName)), ''), '-') AS Lokasyon,
    ISNULL(NULLIF(LTRIM(RTRIM(cu.DistrictName)), ''), '-') AS Ilce,
    ISNULL(NULLIF(LTRIM(RTRIM(cu.CountryName)), ''), '-') AS Ulke,
    ISNULL(NULLIF(LTRIM(RTRIM(cu.Info)), ''), '-') AS MusteriInfo,

    CASE
        WHEN cu.IsShopping = 1 THEN N'Evet'
        WHEN cu.IsShopping = 0 THEN N'Hayır'
        ELSE '-'
    END AS AlisverisiVarMi,

    ISNULL(NULLIF(LTRIM(RTRIM(cu.Tel)), ''), '-') AS IrtibatNumarasi,
    ISNULL(NULLIF(LTRIM(RTRIM(cu.Email)), ''), '-') AS EmailAdresi,

    ISNULL(NULLIF(LTRIM(RTRIM(cr.ContactResourceName)), ''), '-') AS IletisimKaynagi,

    ISNULL(NULLIF(LTRIM(RTRIM(p.CategoryName)), ''), '-') AS CategoryName,
    '-' AS CategoryCode,

    ISNULL(NULLIF(LTRIM(RTRIM(ls.Name)), ''), '-') AS LeadDurumu,
    ISNULL(NULLIF(LTRIM(RTRIM(ns.Name)), ''), '-') AS SonrakiAdim,

    ISNULL(NULLIF(LTRIM(RTRIM(lp.Name)), ''), '-') AS ProcessName,
    ISNULL(NULLIF(LTRIM(RTRIM(lp.Code)), ''), '-') AS ProcessCode,
    lp.StepOrder,
    
    -- DÜZELTİLEN ALAN: SelectedStepOrder
    CASE
        WHEN EXISTS
        (
            SELECT 1
            FROM tmscrq.TMLeadReservation r
            WHERE r.LeadId = l.Id
              AND r.IsActive = 1
              AND ISNULL(r.IsApproved,0) = 0
        )
        THEN 10
        ELSE lp.StepOrder
    END AS SelectedStepOrder,

    ISNULL(
        CASE
            WHEN l.EstimatedDate IS NOT NULL
            THEN CAST(YEAR(l.EstimatedDate) AS VARCHAR(4)) + ' ' + DATENAME(MONTH, l.EstimatedDate)
            ELSE NULL
        END,
        '-'
    ) AS TerminTarihi,

    ISNULL(
        NULLIF(
            LTRIM(RTRIM(ISNULL(sp.FirstName, '') + ' ' + ISNULL(sp.LastName, '')))
        , '')
    , '-') AS SatisDanismani,

    ISNULL(NULLIF(LTRIM(RTRIM(st.StoreDesc)), ''), '-') AS StoreName

FROM tmscrq.TMLead l
LEFT JOIN tmscrq.TMLeadStatu ls
    ON ls.Id = l.StatuId
LEFT JOIN tmscrq.TMCustomer cu
    ON cu.Id = l.CustomerId
LEFT JOIN tmscrq.TMProduct p
    ON p.Id = l.ProductId
LEFT JOIN tmscrq.TMContactResource cr
    ON cr.Id = l.ContactResourceId
LEFT JOIN dbo.KUser sp
    ON sp.Id = l.SalesPersonKUserId
LEFT JOIN tmscrq.TMStore st
    ON st.Id = l.StoreId
LEFT JOIN tmscrq.TMLeadProcess lp
    ON lp.Id = l.ProcessID
LEFT JOIN tmscrq.TMLeadNextStep ns
    ON ns.Id = l.NextStepId

WHERE
(
    EXISTS
    (
        SELECT 1
        FROM dbo.KUserRole ur
        INNER JOIN dbo.KRole r
            ON r.Id = ur.KRole_Id
        WHERE ur.KUser_Id = @UserId
          AND ur.IsDeleted = 0
          AND r.IsDeleted = 0
          AND r.Name IN ('TimesYonetici', 'TimesUstYonetici')
    )
    OR
    (
        EXISTS
        (
            SELECT 1
            FROM dbo.KUserRole ur
            INNER JOIN dbo.KRole r
                ON r.Id = ur.KRole_Id
            WHERE ur.KUser_Id = @UserId
              AND ur.IsDeleted = 0
              AND r.IsDeleted = 0
              AND r.Name IN ('TimesMagazaMuduru', 'TimesSatisPersoneli')
        )
        AND EXISTS
        (
            SELECT 1
            FROM tmscrq.TMUser tu
            WHERE tu.KUserID = @UserId
              AND tu.StoreId = l.StoreId
        )
    )
)

AND
(
    ISNULL(@MusteriAdi, '') = ''
    OR UPPER(ISNULL(cu.Name, '')) LIKE '%' + UPPER(LTRIM(RTRIM(@MusteriAdi))) + '%'
    OR UPPER(ISNULL(cu.LastName, '')) LIKE '%' + UPPER(LTRIM(RTRIM(@MusteriAdi))) + '%'
    OR UPPER(
        ISNULL(cu.Name, '') + ' ' + ISNULL(cu.LastName, '')
    ) LIKE '%' + UPPER(LTRIM(RTRIM(@MusteriAdi))) + '%'
)

AND
(
    @ProductName IS NULL
    OR LTRIM(RTRIM(@ProductName)) = ''
    OR
    (
        CHARINDEX(',', @ProductName) > 0
        AND ISNULL(LTRIM(RTRIM(p.ProductName)), '') IN
        (
            SELECT LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', '')))
            FROM STRING_SPLIT(CAST(@ProductName AS NVARCHAR(MAX)), ',')
            WHERE LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', ''))) <> ''
        )
    )
    OR
    (
        CHARINDEX(',', @ProductName) = 0
        AND UPPER(ISNULL(LTRIM(RTRIM(p.ProductName)), ''))
            LIKE '%' + UPPER(LTRIM(RTRIM(@ProductName))) + '%'
    )
)

AND
(
    ISNULL(@LeadCode, '') = ''
    OR UPPER(ISNULL(l.LeadCode, ''))
        LIKE '%' + UPPER(LTRIM(RTRIM(@LeadCode))) + '%'
    OR REPLACE(
        REPLACE(
            REPLACE(
                UPPER(ISNULL(l.LeadCode, '')),
                '-', ''
            ),
            ' ', ''
        ),
        '/', ''
    )
    LIKE '%' +
    REPLACE(
        REPLACE(
            REPLACE(
                UPPER(LTRIM(RTRIM(@LeadCode))),
                '-', ''
            ),
            ' ', ''
        ),
        '/', ''
    )
    + '%'
)

AND
(
    @Tel IS NULL
    OR LTRIM(RTRIM(@Tel)) = ''
    OR UPPER(ISNULL(LTRIM(RTRIM(cu.Tel)), '')) LIKE '%' + UPPER(LTRIM(RTRIM(@Tel))) + '%'
)

AND
(
    @CategoryName IS NULL
    OR LTRIM(RTRIM(@CategoryName)) = ''
    OR UPPER(ISNULL(LTRIM(RTRIM(p.CategoryName)), '')) IN
    (
        SELECT UPPER(LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value,'""',''),'[',''),']',''))))
        FROM STRING_SPLIT(CAST(@CategoryName AS NVARCHAR(MAX)), ',')
        WHERE LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value,'""',''),'[',''),']',''))) <> ''
    )
)

AND
(
    @StoreIds IS NULL
    OR LTRIM(RTRIM(@StoreIds)) = ''
    OR EXISTS
    (
        SELECT 1
        FROM STRING_SPLIT(CAST(@StoreIds AS NVARCHAR(MAX)), ',') s
        WHERE l.StoreId = TRY_CONVERT
        (
            uniqueidentifier,
            LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(s.value, '""', ''), '[', ''), ']', '')))
        )
    )
)

AND
(
    @SatisDanismaniIds IS NULL
    OR LTRIM(RTRIM(@SatisDanismaniIds)) = ''
    OR EXISTS
    (
        SELECT 1
        FROM STRING_SPLIT(CAST(@SatisDanismaniIds AS NVARCHAR(MAX)), ',') s
        WHERE l.SalesPersonKUserId = TRY_CONVERT
        (
            uniqueidentifier,
            LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(s.value, '""', ''), '[', ''), ']', '')))
        )
    )
)

AND
(
    ISNULL(@ProcessCode, '') = ''
    OR EXISTS
    (
        SELECT 1
        FROM STRING_SPLIT(
            CONVERT(NVARCHAR(MAX), @ProcessCode),
            ','
        ) AS s
        WHERE
            UPPER(LTRIM(RTRIM(s.value))) =
            UPPER(LTRIM(RTRIM(ISNULL(lp.Code, ''))))
    )
)

-- DÜZELTİLEN ALAN: @StepOrder Filtresi (0 verilince tümü gelsin)
AND
(
    @StepOrder IS NULL
    OR @StepOrder = 0  -- 👈 YENİ EKLENDI: 0 verilince tüm kayıtlar gelir
    OR
    (
        @StepOrder = 10
        AND EXISTS
        (
            SELECT 1
            FROM tmscrq.TMLeadReservation r
            WHERE r.LeadId = l.Id
              AND r.IsActive = 1
              AND ISNULL(r.IsApproved,0) = 0
        )
    )
    OR
    (
        @StepOrder <> 10
        AND lp.StepOrder = @StepOrder
    )
)

AND
(
    @StartDate IS NULL
    OR LTRIM(RTRIM(@StartDate)) = ''
    OR l.CreatedAt >= CONVERT(date, @StartDate)
)

AND
(
    @EndDate IS NULL
    OR LTRIM(RTRIM(@EndDate)) = ''
    OR l.CreatedAt < DATEADD(day, 1, CONVERT(date, @EndDate))
)

ORDER BY l.CreatedAt DESC;", new string[] { "RezerveDurumu", "LeadId", "IsReserved", "LeadNumarasi", "TalepTarihi", "ProductId", "ProductName", "Bilezik", "Brand", "Kadran", "RefCode", "Referans", "Musteri", "Lokasyon", "Ilce", "Ulke", "MusteriInfo", "AlisverisiVarMi", "IrtibatNumarasi", "EmailAdresi", "IletisimKaynagi", "CategoryName", "CategoryCode", "LeadDurumu", "SonrakiAdim", "ProcessName", "ProcessCode", "StepOrder", "SelectedStepOrder", "TerminTarihi", "SatisDanismani", "StoreName" }, prms_TM_GetLeads_0.ToArray());
            ;


            return Ok(result);
        }


        [HttpPost, Route("LeadListComponent_399191_onClick")]
        public IActionResult LeadListComponent_399191_onClick(LeadListComponent_399191_onClick_Request request)
        {

            KProviderManager.Authorization.IsAuthorizedForRoles(appId, appName, screenId, screenName, new List<string> { $"70de6cfc-6087-6059-59b4-0b5a8527af6b", "4da1f213-c8e4-0b50-5c84-02fd13f1a622", "c4e882ef-977d-f613-7694-230ac83919d2", "b4bfd39c-ac02-f442-c899-7a2374a45b47", "cdb536b0-6297-155f-d446-8453d8a60304", "TimesYonetici", "TimesUstYonetici", "TimesSatisPersoneli", "TimesMagazaMuduru", "TimesAdmin" });

            var result = new LeadListComponent_399191_onClick_Response();

            var prms_TM_GetLeads_0 = new List<kSqlParameter>();
            prms_TM_GetLeads_0.Add(new kSqlParameter() { Name = "StepOrder", Value = "4".ConvertToType<Int32>() });
            prms_TM_GetLeads_0.Add(new kSqlParameter() { Name = "UserId", Value = Kuika.Common.KContext.CurrentUser?.Id });
            prms_TM_GetLeads_0.Add(new kSqlParameter() { Name = "MusteriAdi", Value = request.MusteriAdi_0 });
            prms_TM_GetLeads_0.Add(new kSqlParameter() { Name = "ProductName", Value = request.ProductName_0 });
            prms_TM_GetLeads_0.Add(new kSqlParameter() { Name = "LeadCode", Value = request.LeadCode_0 });
            prms_TM_GetLeads_0.Add(new kSqlParameter() { Name = "Tel", Value = request.Tel_0 });
            prms_TM_GetLeads_0.Add(new kSqlParameter() { Name = "CategoryName", Value = request.CategoryName_0 });
            prms_TM_GetLeads_0.Add(new kSqlParameter() { Name = "StoreIds", Value = request.StoreIds_0 });
            prms_TM_GetLeads_0.Add(new kSqlParameter() { Name = "SatisDanismaniIds", Value = request.SatisDanismaniIds_0 });
            prms_TM_GetLeads_0.Add(new kSqlParameter() { Name = "ProcessCode", Value = request.ProcessCode_0 });
            prms_TM_GetLeads_0.Add(new kSqlParameter() { Name = "StartDate", Value = request.StartDate_0 });
            prms_TM_GetLeads_0.Add(new kSqlParameter() { Name = "EndDate", Value = request.EndDate_0 });
            using var auditTM_GetLeads_0 = ActionAuditScope.Begin("3e90543d-e741-ce95-21ba-c4798c0096a2", "TM_GetLeads", applicationName: "wbTimesCRM", screenOrEndpointName: "LeadList");
            result.TM_GetLeads = KPersister.Fetch(KContext.GetConnectionString(), @"-- SET LANGUAGE Turkish;

-- SELECT
-- CASE 
--     WHEN EXISTS (
--         SELECT 1 
--         FROM tmscrq.TMLeadReservation r
--         WHERE r.LeadId = l.Id
--           AND r.IsActive = 1
--           AND r.IsApproved = 1
--     ) THEN N'Evet'

--     WHEN EXISTS (
--         SELECT 1 
--         FROM tmscrq.TMLeadReservation r
--         WHERE r.LeadId = l.Id
--           AND r.IsActive = 1
--           AND ISNULL(r.IsApproved,0) = 0
--     ) THEN N'Onay Bekliyor'

--     ELSE N'Hayır'
-- END AS RezerveDurumu,
--     l.Id AS LeadId,
--     l.IsReserved,
--     ISNULL(NULLIF(LTRIM(RTRIM(l.LeadCode)), ''), '-') AS LeadNumarasi,
--     CONVERT(varchar(10), l.CreatedAt, 103) AS TalepTarihi,

--     p.Id AS ProductId,
--     ISNULL(NULLIF(LTRIM(RTRIM(p.ProductName)), ''), '-') AS ProductName,
--     ISNULL(NULLIF(LTRIM(RTRIM(p.Bracelet)), ''), '-') AS Bilezik,
--     ISNULL(NULLIF(LTRIM(RTRIM(p.Brand)), ''), '-') AS Brand,
--     ISNULL(NULLIF(LTRIM(RTRIM(p.Dial)), ''), '-') AS Kadran,
--     ISNULL(NULLIF(LTRIM(RTRIM(p.ProductCode)), ''), '-') AS RefCode,
--     ISNULL(NULLIF(LTRIM(RTRIM(p.Referance)), ''), '-') AS Referans,

--     ISNULL(
--         NULLIF(
--             LTRIM(RTRIM(ISNULL(cu.Name, '') + ' ' + ISNULL(cu.LastName, '')))
--         , '')
--     , '-') AS Musteri,

--     ISNULL(NULLIF(LTRIM(RTRIM(cu.CityName)), ''), '-') AS Lokasyon,
--     ISNULL(NULLIF(LTRIM(RTRIM(cu.DistrictName)), ''), '-') AS Ilce,
--     ISNULL(NULLIF(LTRIM(RTRIM(cu.CountryName)), ''), '-') AS Ulke,
--     ISNULL(NULLIF(LTRIM(RTRIM(cu.Info)), ''), '-') AS MusteriInfo,

--     CASE
--         WHEN cu.IsShopping = 1 THEN N'Evet'
--         WHEN cu.IsShopping = 0 THEN N'Hayır'
--         ELSE '-'
--     END AS AlisverisiVarMi,

--     ISNULL(NULLIF(LTRIM(RTRIM(cu.Tel)), ''), '-') AS IrtibatNumarasi,
--     ISNULL(NULLIF(LTRIM(RTRIM(cu.Email)), ''), '-') AS EmailAdresi,

--     ISNULL(NULLIF(LTRIM(RTRIM(cr.ContactResourceName)), ''), '-') AS IletisimKaynagi,

--     ISNULL(NULLIF(LTRIM(RTRIM(p.CategoryName)), ''), '-') AS CategoryName,
--     '-' AS CategoryCode,

--     ISNULL(NULLIF(LTRIM(RTRIM(ls.Name)), ''), '-') AS LeadDurumu,
--     ISNULL(NULLIF(LTRIM(RTRIM(ns.Name)), ''), '-') AS SonrakiAdim,

--     ISNULL(NULLIF(LTRIM(RTRIM(lp.Name)), ''), '-') AS ProcessName,
--     ISNULL(NULLIF(LTRIM(RTRIM(lp.Code)), ''), '-') AS ProcessCode,
--     lp.StepOrder,
-- CASE
--     WHEN EXISTS
--     (
--         SELECT 1
--         FROM tmscrq.TMLeadReservation r
--         WHERE r.LeadId = l.Id
--           AND r.IsActive = 1
--           AND ISNULL(r.IsApproved,0) = 0
--     )
--     THEN 10
--     ELSE lp.StepOrder
-- END AS SelectedStepOrder,

--     ISNULL(
--         CASE
--             WHEN l.EstimatedDate IS NOT NULL
--             THEN CAST(YEAR(l.EstimatedDate) AS VARCHAR(4)) + ' ' + DATENAME(MONTH, l.EstimatedDate)
--             ELSE NULL
--         END,
--         '-'
--     ) AS TerminTarihi,

--     ISNULL(
--         NULLIF(
--             LTRIM(RTRIM(ISNULL(sp.FirstName, '') + ' ' + ISNULL(sp.LastName, '')))
--         , '')
--     , '-') AS SatisDanismani,

--     ISNULL(NULLIF(LTRIM(RTRIM(st.StoreDesc)), ''), '-') AS StoreName

-- FROM tmscrq.TMLead l
-- LEFT JOIN tmscrq.TMLeadStatu ls
--     ON ls.Id = l.StatuId
-- LEFT JOIN tmscrq.TMCustomer cu
--     ON cu.Id = l.CustomerId
-- LEFT JOIN tmscrq.TMProduct p
--     ON p.Id = l.ProductId
-- LEFT JOIN tmscrq.TMContactResource cr
--     ON cr.Id = l.ContactResourceId
-- LEFT JOIN dbo.KUser sp
--     ON sp.Id = l.SalesPersonKUserId
-- LEFT JOIN tmscrq.TMStore st
--     ON st.Id = l.StoreId
-- LEFT JOIN tmscrq.TMLeadProcess lp
--     ON lp.Id = l.ProcessID
-- LEFT JOIN tmscrq.TMLeadNextStep ns
--     ON ns.Id = l.NextStepId

-- WHERE
-- (
--     EXISTS
--     (
--         SELECT 1
--         FROM dbo.KUserRole ur
--         INNER JOIN dbo.KRole r
--             ON r.Id = ur.KRole_Id
--         WHERE ur.KUser_Id = @UserId
--           AND ur.IsDeleted = 0
--           AND r.IsDeleted = 0
--           AND r.Name IN ('TimesYonetici', 'TimesUstYonetici')
--     )
--     OR
--     (
--         EXISTS
--         (
--             SELECT 1
--             FROM dbo.KUserRole ur
--             INNER JOIN dbo.KRole r
--                 ON r.Id = ur.KRole_Id
--             WHERE ur.KUser_Id = @UserId
--               AND ur.IsDeleted = 0
--               AND r.IsDeleted = 0
--               AND r.Name IN ('TimesMagazaMuduru', 'TimesSatisPersoneli')
--         )
--         AND EXISTS
--         (
--             SELECT 1
--             FROM tmscrq.TMUser tu
--             WHERE tu.KUserID = @UserId
--               AND tu.StoreId = l.StoreId
--         )
--     )
-- )

-- AND
-- (
--     @MusteriAdi IS NULL
--     OR LTRIM(RTRIM(@MusteriAdi)) = ''
--     OR UPPER(LTRIM(RTRIM(ISNULL(cu.Name,'') + ' ' + ISNULL(cu.LastName,''))))
--        LIKE '%' + UPPER(LTRIM(RTRIM(@MusteriAdi))) + '%'
-- )

-- AND
-- (
--     @ProductName IS NULL
--     OR LTRIM(RTRIM(@ProductName)) = ''
--     OR
--     (
--         CHARINDEX(',', @ProductName) > 0
--         AND ISNULL(LTRIM(RTRIM(p.ProductName)), '') IN
--         (
--             SELECT LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', '')))
--             FROM STRING_SPLIT(CAST(@ProductName AS NVARCHAR(MAX)), ',')
--             WHERE LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', ''))) <> ''
--         )
--     )
--     OR
--     (
--         CHARINDEX(',', @ProductName) = 0
--         AND UPPER(ISNULL(LTRIM(RTRIM(p.ProductName)), ''))
--             LIKE '%' + UPPER(LTRIM(RTRIM(@ProductName))) + '%'
--     )
-- )

-- AND
-- (
--     @LeadCode IS NULL
--     OR LTRIM(RTRIM(@LeadCode)) = ''
--     OR UPPER(ISNULL(LTRIM(RTRIM(l.LeadCode)), '')) LIKE '%' + UPPER(LTRIM(RTRIM(@LeadCode))) + '%'
-- )

-- AND
-- (
--     @Tel IS NULL
--     OR LTRIM(RTRIM(@Tel)) = ''
--     OR UPPER(ISNULL(LTRIM(RTRIM(cu.Tel)), '')) LIKE '%' + UPPER(LTRIM(RTRIM(@Tel))) + '%'
-- )

-- -- AND
-- -- (
-- --     @CategoryName IS NULL
-- --     OR LTRIM(RTRIM(@CategoryName)) = ''
-- --     OR
-- --     (
-- --         EXISTS
-- --         (
-- --             SELECT 1
-- --             FROM STRING_SPLIT(CAST(@CategoryName AS NVARCHAR(MAX)), ',') c
-- --             WHERE UPPER(LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(c.value, '""', ''), '[', ''), ']', '')))) = 'DEFAULT'
-- --         )
-- --         AND (p.CategoryName IS NULL OR LTRIM(RTRIM(p.CategoryName)) = '')
-- --     )
-- --     OR UPPER(ISNULL(LTRIM(RTRIM(p.CategoryName)), '')) IN
-- --     (
-- --         SELECT UPPER(LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', ''))))
-- --         FROM STRING_SPLIT(CAST(@CategoryName AS NVARCHAR(MAX)), ',')
-- --         WHERE LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', ''))) <> ''
-- --           AND UPPER(LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', '')))) <> 'DEFAULT'
-- --     )
-- -- )

-- AND
-- (
--     @CategoryName IS NULL
--     OR LTRIM(RTRIM(@CategoryName)) = ''
--     OR UPPER(ISNULL(LTRIM(RTRIM(p.CategoryName)), '')) IN
--     (
--         SELECT UPPER(LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value,'""',''),'[',''),']',''))))
--         FROM STRING_SPLIT(CAST(@CategoryName AS NVARCHAR(MAX)), ',')
--         WHERE LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value,'""',''),'[',''),']',''))) <> ''
--     )
-- )

-- AND
-- (
--     @StoreIds IS NULL
--     OR LTRIM(RTRIM(@StoreIds)) = ''
--     OR EXISTS
--     (
--         SELECT 1
--         FROM STRING_SPLIT(CAST(@StoreIds AS NVARCHAR(MAX)), ',') s
--         WHERE l.StoreId = TRY_CONVERT
--         (
--             uniqueidentifier,
--             LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(s.value, '""', ''), '[', ''), ']', '')))
--         )
--     )
-- )

-- AND
-- (
--     @SatisDanismaniIds IS NULL
--     OR LTRIM(RTRIM(@SatisDanismaniIds)) = ''
--     OR EXISTS
--     (
--         SELECT 1
--         FROM STRING_SPLIT(CAST(@SatisDanismaniIds AS NVARCHAR(MAX)), ',') s
--         WHERE l.SalesPersonKUserId = TRY_CONVERT
--         (
--             uniqueidentifier,
--             LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(s.value, '""', ''), '[', ''), ']', '')))
--         )
--     )
-- )

-- AND
-- (
--     @ProcessCode IS NULL
--     OR LTRIM(RTRIM(@ProcessCode)) = ''
--     OR UPPER(ISNULL(LTRIM(RTRIM(lp.Code)), '')) IN
--     (
--         SELECT UPPER(LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', ''))))
--         FROM STRING_SPLIT(CAST(@ProcessCode AS NVARCHAR(MAX)), ',')
--         WHERE LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', ''))) <> ''
--     )
-- )

-- AND
-- (
--     @StepOrder IS NULL

--     OR
--     (
--         @StepOrder = 10
--         AND EXISTS
--         (
--             SELECT 1
--             FROM tmscrq.TMLeadReservation r
--             WHERE r.LeadId = l.Id
--               AND r.IsActive = 1
--               AND ISNULL(r.IsApproved,0) = 0
--         )
--     )

--     OR
--     (
--         @StepOrder <> 10
--         AND lp.StepOrder = @StepOrder
--     )
-- )

-- AND
-- (
--     @StartDate IS NULL
--     OR LTRIM(RTRIM(@StartDate)) = ''
--     OR l.CreatedAt >= CONVERT(date, @StartDate)
-- )

-- AND
-- (
--     @EndDate IS NULL
--     OR LTRIM(RTRIM(@EndDate)) = ''
--     OR l.CreatedAt < DATEADD(day, 1, CONVERT(date, @EndDate))
-- )

-- ORDER BY l.CreatedAt DESC;

------------------------++++++++++++++++++++++++-------------------
-- SET LANGUAGE Turkish;

-- SELECT
-- CASE 
--     WHEN EXISTS (
--         SELECT 1 
--         FROM tmscrq.TMLeadReservation r
--         WHERE r.LeadId = l.Id
--           AND r.IsActive = 1
--           AND r.IsApproved = 1
--     ) THEN N'Evet'

--     WHEN EXISTS (
--         SELECT 1 
--         FROM tmscrq.TMLeadReservation r
--         WHERE r.LeadId = l.Id
--           AND r.IsActive = 1
--           AND ISNULL(r.IsApproved,0) = 0
--     ) THEN N'Onay Bekliyor'

--     ELSE N'Hayır'
-- END AS RezerveDurumu,
--     l.Id AS LeadId,
--     l.IsReserved,
--     ISNULL(NULLIF(LTRIM(RTRIM(l.LeadCode)), ''), '-') AS LeadNumarasi,
--     CONVERT(varchar(10), l.CreatedAt, 103) AS TalepTarihi,

--     p.Id AS ProductId,
--     ISNULL(NULLIF(LTRIM(RTRIM(p.ProductName)), ''), '-') AS ProductName,
--     ISNULL(NULLIF(LTRIM(RTRIM(p.Bracelet)), ''), '-') AS Bilezik,
--     ISNULL(NULLIF(LTRIM(RTRIM(p.Brand)), ''), '-') AS Brand,
--     ISNULL(NULLIF(LTRIM(RTRIM(p.Dial)), ''), '-') AS Kadran,
--     ISNULL(NULLIF(LTRIM(RTRIM(p.ProductCode)), ''), '-') AS RefCode,
--     ISNULL(NULLIF(LTRIM(RTRIM(p.Referance)), ''), '-') AS Referans,

--     ISNULL(
--         NULLIF(
--             LTRIM(RTRIM(ISNULL(cu.Name, '') + ' ' + ISNULL(cu.LastName, '')))
--         , '')
--     , '-') AS Musteri,

--     ISNULL(NULLIF(LTRIM(RTRIM(cu.CityName)), ''), '-') AS Lokasyon,
--     ISNULL(NULLIF(LTRIM(RTRIM(cu.DistrictName)), ''), '-') AS Ilce,
--     ISNULL(NULLIF(LTRIM(RTRIM(cu.CountryName)), ''), '-') AS Ulke,
--     ISNULL(NULLIF(LTRIM(RTRIM(cu.Info)), ''), '-') AS MusteriInfo,

--     CASE
--         WHEN cu.IsShopping = 1 THEN N'Evet'
--         WHEN cu.IsShopping = 0 THEN N'Hayır'
--         ELSE '-'
--     END AS AlisverisiVarMi,

--     ISNULL(NULLIF(LTRIM(RTRIM(cu.Tel)), ''), '-') AS IrtibatNumarasi,
--     ISNULL(NULLIF(LTRIM(RTRIM(cu.Email)), ''), '-') AS EmailAdresi,

--     ISNULL(NULLIF(LTRIM(RTRIM(cr.ContactResourceName)), ''), '-') AS IletisimKaynagi,

--     ISNULL(NULLIF(LTRIM(RTRIM(p.CategoryName)), ''), '-') AS CategoryName,
--     '-' AS CategoryCode,

--     ISNULL(NULLIF(LTRIM(RTRIM(ls.Name)), ''), '-') AS LeadDurumu,
--     ISNULL(NULLIF(LTRIM(RTRIM(ns.Name)), ''), '-') AS SonrakiAdim,

--     ISNULL(NULLIF(LTRIM(RTRIM(lp.Name)), ''), '-') AS ProcessName,
--     ISNULL(NULLIF(LTRIM(RTRIM(lp.Code)), ''), '-') AS ProcessCode,
--     lp.StepOrder,
    
--     -- DÜZELTİLEN ALAN: SelectedStepOrder
--     CASE
--         WHEN EXISTS
--         (
--             SELECT 1
--             FROM tmscrq.TMLeadReservation r
--             WHERE r.LeadId = l.Id
--               AND r.IsActive = 1
--               AND ISNULL(r.IsApproved,0) = 0
--         )
--         THEN 10
--         ELSE lp.StepOrder
--     END AS SelectedStepOrder,

--     ISNULL(
--         CASE
--             WHEN l.EstimatedDate IS NOT NULL
--             THEN CAST(YEAR(l.EstimatedDate) AS VARCHAR(4)) + ' ' + DATENAME(MONTH, l.EstimatedDate)
--             ELSE NULL
--         END,
--         '-'
--     ) AS TerminTarihi,

--     ISNULL(
--         NULLIF(
--             LTRIM(RTRIM(ISNULL(sp.FirstName, '') + ' ' + ISNULL(sp.LastName, '')))
--         , '')
--     , '-') AS SatisDanismani,

--     ISNULL(NULLIF(LTRIM(RTRIM(st.StoreDesc)), ''), '-') AS StoreName

-- FROM tmscrq.TMLead l
-- LEFT JOIN tmscrq.TMLeadStatu ls
--     ON ls.Id = l.StatuId
-- LEFT JOIN tmscrq.TMCustomer cu
--     ON cu.Id = l.CustomerId
-- LEFT JOIN tmscrq.TMProduct p
--     ON p.Id = l.ProductId
-- LEFT JOIN tmscrq.TMContactResource cr
--     ON cr.Id = l.ContactResourceId
-- LEFT JOIN dbo.KUser sp
--     ON sp.Id = l.SalesPersonKUserId
-- LEFT JOIN tmscrq.TMStore st
--     ON st.Id = l.StoreId
-- LEFT JOIN tmscrq.TMLeadProcess lp
--     ON lp.Id = l.ProcessID
-- LEFT JOIN tmscrq.TMLeadNextStep ns
--     ON ns.Id = l.NextStepId

-- WHERE
-- (
--     EXISTS
--     (
--         SELECT 1
--         FROM dbo.KUserRole ur
--         INNER JOIN dbo.KRole r
--             ON r.Id = ur.KRole_Id
--         WHERE ur.KUser_Id = @UserId
--           AND ur.IsDeleted = 0
--           AND r.IsDeleted = 0
--           AND r.Name IN ('TimesYonetici', 'TimesUstYonetici')
--     )
--     OR
--     (
--         EXISTS
--         (
--             SELECT 1
--             FROM dbo.KUserRole ur
--             INNER JOIN dbo.KRole r
--                 ON r.Id = ur.KRole_Id
--             WHERE ur.KUser_Id = @UserId
--               AND ur.IsDeleted = 0
--               AND r.IsDeleted = 0
--               AND r.Name IN ('TimesMagazaMuduru', 'TimesSatisPersoneli')
--         )
--         AND EXISTS
--         (
--             SELECT 1
--             FROM tmscrq.TMUser tu
--             WHERE tu.KUserID = @UserId
--               AND tu.StoreId = l.StoreId
--         )
--     )
-- )

-- AND
-- (
--     @MusteriAdi IS NULL
--     OR LTRIM(RTRIM(@MusteriAdi)) = ''
--     OR UPPER(LTRIM(RTRIM(ISNULL(cu.Name,'') + ' ' + ISNULL(cu.LastName,''))))
--        LIKE '%' + UPPER(LTRIM(RTRIM(@MusteriAdi))) + '%'
-- )

-- AND
-- (
--     @ProductName IS NULL
--     OR LTRIM(RTRIM(@ProductName)) = ''
--     OR
--     (
--         CHARINDEX(',', @ProductName) > 0
--         AND ISNULL(LTRIM(RTRIM(p.ProductName)), '') IN
--         (
--             SELECT LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', '')))
--             FROM STRING_SPLIT(CAST(@ProductName AS NVARCHAR(MAX)), ',')
--             WHERE LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', ''))) <> ''
--         )
--     )
--     OR
--     (
--         CHARINDEX(',', @ProductName) = 0
--         AND UPPER(ISNULL(LTRIM(RTRIM(p.ProductName)), ''))
--             LIKE '%' + UPPER(LTRIM(RTRIM(@ProductName))) + '%'
--     )
-- )

-- AND
-- (
--     @LeadCode IS NULL
--     OR LTRIM(RTRIM(@LeadCode)) = ''
--     OR UPPER(ISNULL(LTRIM(RTRIM(l.LeadCode)), '')) LIKE '%' + UPPER(LTRIM(RTRIM(@LeadCode))) + '%'
-- )

-- AND
-- (
--     @Tel IS NULL
--     OR LTRIM(RTRIM(@Tel)) = ''
--     OR UPPER(ISNULL(LTRIM(RTRIM(cu.Tel)), '')) LIKE '%' + UPPER(LTRIM(RTRIM(@Tel))) + '%'
-- )

-- AND
-- (
--     @CategoryName IS NULL
--     OR LTRIM(RTRIM(@CategoryName)) = ''
--     OR UPPER(ISNULL(LTRIM(RTRIM(p.CategoryName)), '')) IN
--     (
--         SELECT UPPER(LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value,'""',''),'[',''),']',''))))
--         FROM STRING_SPLIT(CAST(@CategoryName AS NVARCHAR(MAX)), ',')
--         WHERE LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value,'""',''),'[',''),']',''))) <> ''
--     )
-- )

-- AND
-- (
--     @StoreIds IS NULL
--     OR LTRIM(RTRIM(@StoreIds)) = ''
--     OR EXISTS
--     (
--         SELECT 1
--         FROM STRING_SPLIT(CAST(@StoreIds AS NVARCHAR(MAX)), ',') s
--         WHERE l.StoreId = TRY_CONVERT
--         (
--             uniqueidentifier,
--             LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(s.value, '""', ''), '[', ''), ']', '')))
--         )
--     )
-- )

-- AND
-- (
--     @SatisDanismaniIds IS NULL
--     OR LTRIM(RTRIM(@SatisDanismaniIds)) = ''
--     OR EXISTS
--     (
--         SELECT 1
--         FROM STRING_SPLIT(CAST(@SatisDanismaniIds AS NVARCHAR(MAX)), ',') s
--         WHERE l.SalesPersonKUserId = TRY_CONVERT
--         (
--             uniqueidentifier,
--             LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(s.value, '""', ''), '[', ''), ']', '')))
--         )
--     )
-- )

-- AND
-- (
--     @ProcessCode IS NULL
--     OR LTRIM(RTRIM(@ProcessCode)) = ''
--     OR UPPER(ISNULL(LTRIM(RTRIM(lp.Code)), '')) IN
--     (
--         SELECT UPPER(LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', ''))))
--         FROM STRING_SPLIT(CAST(@ProcessCode AS NVARCHAR(MAX)), ',')
--         WHERE LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', ''))) <> ''
--     )
-- )

-- -- DÜZELTİLEN ALAN: @StepOrder Filtresi (tek blok)
-- AND
-- (
--     @StepOrder IS NULL

--     OR

--     (
--         @StepOrder = 10
--         AND EXISTS
--         (
--             SELECT 1
--             FROM tmscrq.TMLeadReservation r
--             WHERE r.LeadId = l.Id
--               AND r.IsActive = 1
--               AND ISNULL(r.IsApproved,0) = 0
--         )
--     )

--     OR

--     (
--         @StepOrder <> 10
--         AND lp.StepOrder = @StepOrder
--     )
-- )

-- AND
-- (
--     @StartDate IS NULL
--     OR LTRIM(RTRIM(@StartDate)) = ''
--     OR l.CreatedAt >= CONVERT(date, @StartDate)
-- )

-- AND
-- (
--     @EndDate IS NULL
--     OR LTRIM(RTRIM(@EndDate)) = ''
--     OR l.CreatedAt < DATEADD(day, 1, CONVERT(date, @EndDate))
-- )

-- ORDER BY l.CreatedAt DESC;



SET LANGUAGE Turkish;

SELECT
CASE 
    WHEN EXISTS (
        SELECT 1 
        FROM tmscrq.TMLeadReservation r
        WHERE r.LeadId = l.Id
          AND r.IsActive = 1
          AND r.IsApproved = 1
    ) THEN N'Evet'

    WHEN EXISTS (
        SELECT 1 
        FROM tmscrq.TMLeadReservation r
        WHERE r.LeadId = l.Id
          AND r.IsActive = 1
          AND ISNULL(r.IsApproved,0) = 0
    ) THEN N'Onay Bekliyor'

    ELSE N'Hayır'
END AS RezerveDurumu,
    l.Id AS LeadId,
    l.IsReserved,
    ISNULL(NULLIF(LTRIM(RTRIM(l.LeadCode)), ''), '-') AS LeadNumarasi,
     FORMAT(l.CreatedAt, 'dd MMMM yyyy', 'tr-TR') AS TalepTarihi,

    p.Id AS ProductId,
    ISNULL(NULLIF(LTRIM(RTRIM(p.ProductName)), ''), '-') AS ProductName,
    ISNULL(NULLIF(LTRIM(RTRIM(p.Bracelet)), ''), '-') AS Bilezik,
    ISNULL(NULLIF(LTRIM(RTRIM(p.Brand)), ''), '-') AS Brand,
    ISNULL(NULLIF(LTRIM(RTRIM(p.Dial)), ''), '-') AS Kadran,
    ISNULL(NULLIF(LTRIM(RTRIM(p.ProductCode)), ''), '-') AS RefCode,
    ISNULL(NULLIF(LTRIM(RTRIM(p.Referance)), ''), '-') AS Referans,

    ISNULL(
        NULLIF(
            LTRIM(RTRIM(ISNULL(cu.Name, '') + ' ' + ISNULL(cu.LastName, '')))
        , '')
    , '-') AS Musteri,

    ISNULL(NULLIF(LTRIM(RTRIM(cu.CityName)), ''), '-') AS Lokasyon,
    ISNULL(NULLIF(LTRIM(RTRIM(cu.DistrictName)), ''), '-') AS Ilce,
    ISNULL(NULLIF(LTRIM(RTRIM(cu.CountryName)), ''), '-') AS Ulke,
    ISNULL(NULLIF(LTRIM(RTRIM(cu.Info)), ''), '-') AS MusteriInfo,

    CASE
        WHEN cu.IsShopping = 1 THEN N'Evet'
        WHEN cu.IsShopping = 0 THEN N'Hayır'
        ELSE '-'
    END AS AlisverisiVarMi,

    ISNULL(NULLIF(LTRIM(RTRIM(cu.Tel)), ''), '-') AS IrtibatNumarasi,
    ISNULL(NULLIF(LTRIM(RTRIM(cu.Email)), ''), '-') AS EmailAdresi,

    ISNULL(NULLIF(LTRIM(RTRIM(cr.ContactResourceName)), ''), '-') AS IletisimKaynagi,

    ISNULL(NULLIF(LTRIM(RTRIM(p.CategoryName)), ''), '-') AS CategoryName,
    '-' AS CategoryCode,

    ISNULL(NULLIF(LTRIM(RTRIM(ls.Name)), ''), '-') AS LeadDurumu,
    ISNULL(NULLIF(LTRIM(RTRIM(ns.Name)), ''), '-') AS SonrakiAdim,

    ISNULL(NULLIF(LTRIM(RTRIM(lp.Name)), ''), '-') AS ProcessName,
    ISNULL(NULLIF(LTRIM(RTRIM(lp.Code)), ''), '-') AS ProcessCode,
    lp.StepOrder,
    
    -- DÜZELTİLEN ALAN: SelectedStepOrder
    CASE
        WHEN EXISTS
        (
            SELECT 1
            FROM tmscrq.TMLeadReservation r
            WHERE r.LeadId = l.Id
              AND r.IsActive = 1
              AND ISNULL(r.IsApproved,0) = 0
        )
        THEN 10
        ELSE lp.StepOrder
    END AS SelectedStepOrder,

    ISNULL(
        CASE
            WHEN l.EstimatedDate IS NOT NULL
            THEN CAST(YEAR(l.EstimatedDate) AS VARCHAR(4)) + ' ' + DATENAME(MONTH, l.EstimatedDate)
            ELSE NULL
        END,
        '-'
    ) AS TerminTarihi,

    ISNULL(
        NULLIF(
            LTRIM(RTRIM(ISNULL(sp.FirstName, '') + ' ' + ISNULL(sp.LastName, '')))
        , '')
    , '-') AS SatisDanismani,

    ISNULL(NULLIF(LTRIM(RTRIM(st.StoreDesc)), ''), '-') AS StoreName

FROM tmscrq.TMLead l
LEFT JOIN tmscrq.TMLeadStatu ls
    ON ls.Id = l.StatuId
LEFT JOIN tmscrq.TMCustomer cu
    ON cu.Id = l.CustomerId
LEFT JOIN tmscrq.TMProduct p
    ON p.Id = l.ProductId
LEFT JOIN tmscrq.TMContactResource cr
    ON cr.Id = l.ContactResourceId
LEFT JOIN dbo.KUser sp
    ON sp.Id = l.SalesPersonKUserId
LEFT JOIN tmscrq.TMStore st
    ON st.Id = l.StoreId
LEFT JOIN tmscrq.TMLeadProcess lp
    ON lp.Id = l.ProcessID
LEFT JOIN tmscrq.TMLeadNextStep ns
    ON ns.Id = l.NextStepId

WHERE
(
    EXISTS
    (
        SELECT 1
        FROM dbo.KUserRole ur
        INNER JOIN dbo.KRole r
            ON r.Id = ur.KRole_Id
        WHERE ur.KUser_Id = @UserId
          AND ur.IsDeleted = 0
          AND r.IsDeleted = 0
          AND r.Name IN ('TimesYonetici', 'TimesUstYonetici')
    )
    OR
    (
        EXISTS
        (
            SELECT 1
            FROM dbo.KUserRole ur
            INNER JOIN dbo.KRole r
                ON r.Id = ur.KRole_Id
            WHERE ur.KUser_Id = @UserId
              AND ur.IsDeleted = 0
              AND r.IsDeleted = 0
              AND r.Name IN ('TimesMagazaMuduru', 'TimesSatisPersoneli')
        )
        AND EXISTS
        (
            SELECT 1
            FROM tmscrq.TMUser tu
            WHERE tu.KUserID = @UserId
              AND tu.StoreId = l.StoreId
        )
    )
)

AND
(
    ISNULL(@MusteriAdi, '') = ''
    OR UPPER(ISNULL(cu.Name, '')) LIKE '%' + UPPER(LTRIM(RTRIM(@MusteriAdi))) + '%'
    OR UPPER(ISNULL(cu.LastName, '')) LIKE '%' + UPPER(LTRIM(RTRIM(@MusteriAdi))) + '%'
    OR UPPER(
        ISNULL(cu.Name, '') + ' ' + ISNULL(cu.LastName, '')
    ) LIKE '%' + UPPER(LTRIM(RTRIM(@MusteriAdi))) + '%'
)

AND
(
    @ProductName IS NULL
    OR LTRIM(RTRIM(@ProductName)) = ''
    OR
    (
        CHARINDEX(',', @ProductName) > 0
        AND ISNULL(LTRIM(RTRIM(p.ProductName)), '') IN
        (
            SELECT LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', '')))
            FROM STRING_SPLIT(CAST(@ProductName AS NVARCHAR(MAX)), ',')
            WHERE LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', ''))) <> ''
        )
    )
    OR
    (
        CHARINDEX(',', @ProductName) = 0
        AND UPPER(ISNULL(LTRIM(RTRIM(p.ProductName)), ''))
            LIKE '%' + UPPER(LTRIM(RTRIM(@ProductName))) + '%'
    )
)

AND
(
    ISNULL(@LeadCode, '') = ''
    OR UPPER(ISNULL(l.LeadCode, ''))
        LIKE '%' + UPPER(LTRIM(RTRIM(@LeadCode))) + '%'
    OR REPLACE(
        REPLACE(
            REPLACE(
                UPPER(ISNULL(l.LeadCode, '')),
                '-', ''
            ),
            ' ', ''
        ),
        '/', ''
    )
    LIKE '%' +
    REPLACE(
        REPLACE(
            REPLACE(
                UPPER(LTRIM(RTRIM(@LeadCode))),
                '-', ''
            ),
            ' ', ''
        ),
        '/', ''
    )
    + '%'
)

AND
(
    @Tel IS NULL
    OR LTRIM(RTRIM(@Tel)) = ''
    OR UPPER(ISNULL(LTRIM(RTRIM(cu.Tel)), '')) LIKE '%' + UPPER(LTRIM(RTRIM(@Tel))) + '%'
)

AND
(
    @CategoryName IS NULL
    OR LTRIM(RTRIM(@CategoryName)) = ''
    OR UPPER(ISNULL(LTRIM(RTRIM(p.CategoryName)), '')) IN
    (
        SELECT UPPER(LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value,'""',''),'[',''),']',''))))
        FROM STRING_SPLIT(CAST(@CategoryName AS NVARCHAR(MAX)), ',')
        WHERE LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value,'""',''),'[',''),']',''))) <> ''
    )
)

AND
(
    @StoreIds IS NULL
    OR LTRIM(RTRIM(@StoreIds)) = ''
    OR EXISTS
    (
        SELECT 1
        FROM STRING_SPLIT(CAST(@StoreIds AS NVARCHAR(MAX)), ',') s
        WHERE l.StoreId = TRY_CONVERT
        (
            uniqueidentifier,
            LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(s.value, '""', ''), '[', ''), ']', '')))
        )
    )
)

AND
(
    @SatisDanismaniIds IS NULL
    OR LTRIM(RTRIM(@SatisDanismaniIds)) = ''
    OR EXISTS
    (
        SELECT 1
        FROM STRING_SPLIT(CAST(@SatisDanismaniIds AS NVARCHAR(MAX)), ',') s
        WHERE l.SalesPersonKUserId = TRY_CONVERT
        (
            uniqueidentifier,
            LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(s.value, '""', ''), '[', ''), ']', '')))
        )
    )
)

AND
(
    ISNULL(@ProcessCode, '') = ''
    OR EXISTS
    (
        SELECT 1
        FROM STRING_SPLIT(
            CONVERT(NVARCHAR(MAX), @ProcessCode),
            ','
        ) AS s
        WHERE
            UPPER(LTRIM(RTRIM(s.value))) =
            UPPER(LTRIM(RTRIM(ISNULL(lp.Code, ''))))
    )
)

-- DÜZELTİLEN ALAN: @StepOrder Filtresi (0 verilince tümü gelsin)
AND
(
    @StepOrder IS NULL
    OR @StepOrder = 0  -- 👈 YENİ EKLENDI: 0 verilince tüm kayıtlar gelir
    OR
    (
        @StepOrder = 10
        AND EXISTS
        (
            SELECT 1
            FROM tmscrq.TMLeadReservation r
            WHERE r.LeadId = l.Id
              AND r.IsActive = 1
              AND ISNULL(r.IsApproved,0) = 0
        )
    )
    OR
    (
        @StepOrder <> 10
        AND lp.StepOrder = @StepOrder
    )
)

AND
(
    @StartDate IS NULL
    OR LTRIM(RTRIM(@StartDate)) = ''
    OR l.CreatedAt >= CONVERT(date, @StartDate)
)

AND
(
    @EndDate IS NULL
    OR LTRIM(RTRIM(@EndDate)) = ''
    OR l.CreatedAt < DATEADD(day, 1, CONVERT(date, @EndDate))
)

ORDER BY l.CreatedAt DESC;", new string[] { "RezerveDurumu", "LeadId", "IsReserved", "LeadNumarasi", "TalepTarihi", "ProductId", "ProductName", "Bilezik", "Brand", "Kadran", "RefCode", "Referans", "Musteri", "Lokasyon", "Ilce", "Ulke", "MusteriInfo", "AlisverisiVarMi", "IrtibatNumarasi", "EmailAdresi", "IletisimKaynagi", "CategoryName", "CategoryCode", "LeadDurumu", "SonrakiAdim", "ProcessName", "ProcessCode", "StepOrder", "SelectedStepOrder", "TerminTarihi", "SatisDanismani", "StoreName" }, prms_TM_GetLeads_0.ToArray());
            ;


            return Ok(result);
        }


        [HttpPost, Route("LeadListComponent_398408_onClick")]
        public IActionResult LeadListComponent_398408_onClick(LeadListComponent_398408_onClick_Request request)
        {

            KProviderManager.Authorization.IsAuthorizedForRoles(appId, appName, screenId, screenName, new List<string> { $"70de6cfc-6087-6059-59b4-0b5a8527af6b", "4da1f213-c8e4-0b50-5c84-02fd13f1a622", "c4e882ef-977d-f613-7694-230ac83919d2", "b4bfd39c-ac02-f442-c899-7a2374a45b47", "cdb536b0-6297-155f-d446-8453d8a60304", "TimesYonetici", "TimesUstYonetici", "TimesSatisPersoneli", "TimesMagazaMuduru", "TimesAdmin" });

            var result = new LeadListComponent_398408_onClick_Response();

            var prms_TM_GetLeads_0 = new List<kSqlParameter>();
            prms_TM_GetLeads_0.Add(new kSqlParameter() { Name = "StepOrder", Value = "5".ConvertToType<Int32>() });
            prms_TM_GetLeads_0.Add(new kSqlParameter() { Name = "UserId", Value = Kuika.Common.KContext.CurrentUser?.Id });
            prms_TM_GetLeads_0.Add(new kSqlParameter() { Name = "MusteriAdi", Value = request.MusteriAdi_0 });
            prms_TM_GetLeads_0.Add(new kSqlParameter() { Name = "ProductName", Value = request.ProductName_0 });
            prms_TM_GetLeads_0.Add(new kSqlParameter() { Name = "LeadCode", Value = request.LeadCode_0 });
            prms_TM_GetLeads_0.Add(new kSqlParameter() { Name = "Tel", Value = request.Tel_0 });
            prms_TM_GetLeads_0.Add(new kSqlParameter() { Name = "CategoryName", Value = request.CategoryName_0 });
            prms_TM_GetLeads_0.Add(new kSqlParameter() { Name = "StoreIds", Value = request.StoreIds_0 });
            prms_TM_GetLeads_0.Add(new kSqlParameter() { Name = "SatisDanismaniIds", Value = request.SatisDanismaniIds_0 });
            prms_TM_GetLeads_0.Add(new kSqlParameter() { Name = "ProcessCode", Value = request.ProcessCode_0 });
            prms_TM_GetLeads_0.Add(new kSqlParameter() { Name = "StartDate", Value = request.StartDate_0 });
            prms_TM_GetLeads_0.Add(new kSqlParameter() { Name = "EndDate", Value = request.EndDate_0 });
            using var auditTM_GetLeads_0 = ActionAuditScope.Begin("d1fad405-f054-cbb3-fd95-f84f2fcc30f1", "TM_GetLeads", applicationName: "wbTimesCRM", screenOrEndpointName: "LeadList");
            result.TM_GetLeads = KPersister.Fetch(KContext.GetConnectionString(), @"-- SET LANGUAGE Turkish;

-- SELECT
-- CASE 
--     WHEN EXISTS (
--         SELECT 1 
--         FROM tmscrq.TMLeadReservation r
--         WHERE r.LeadId = l.Id
--           AND r.IsActive = 1
--           AND r.IsApproved = 1
--     ) THEN N'Evet'

--     WHEN EXISTS (
--         SELECT 1 
--         FROM tmscrq.TMLeadReservation r
--         WHERE r.LeadId = l.Id
--           AND r.IsActive = 1
--           AND ISNULL(r.IsApproved,0) = 0
--     ) THEN N'Onay Bekliyor'

--     ELSE N'Hayır'
-- END AS RezerveDurumu,
--     l.Id AS LeadId,
--     l.IsReserved,
--     ISNULL(NULLIF(LTRIM(RTRIM(l.LeadCode)), ''), '-') AS LeadNumarasi,
--     CONVERT(varchar(10), l.CreatedAt, 103) AS TalepTarihi,

--     p.Id AS ProductId,
--     ISNULL(NULLIF(LTRIM(RTRIM(p.ProductName)), ''), '-') AS ProductName,
--     ISNULL(NULLIF(LTRIM(RTRIM(p.Bracelet)), ''), '-') AS Bilezik,
--     ISNULL(NULLIF(LTRIM(RTRIM(p.Brand)), ''), '-') AS Brand,
--     ISNULL(NULLIF(LTRIM(RTRIM(p.Dial)), ''), '-') AS Kadran,
--     ISNULL(NULLIF(LTRIM(RTRIM(p.ProductCode)), ''), '-') AS RefCode,
--     ISNULL(NULLIF(LTRIM(RTRIM(p.Referance)), ''), '-') AS Referans,

--     ISNULL(
--         NULLIF(
--             LTRIM(RTRIM(ISNULL(cu.Name, '') + ' ' + ISNULL(cu.LastName, '')))
--         , '')
--     , '-') AS Musteri,

--     ISNULL(NULLIF(LTRIM(RTRIM(cu.CityName)), ''), '-') AS Lokasyon,
--     ISNULL(NULLIF(LTRIM(RTRIM(cu.DistrictName)), ''), '-') AS Ilce,
--     ISNULL(NULLIF(LTRIM(RTRIM(cu.CountryName)), ''), '-') AS Ulke,
--     ISNULL(NULLIF(LTRIM(RTRIM(cu.Info)), ''), '-') AS MusteriInfo,

--     CASE
--         WHEN cu.IsShopping = 1 THEN N'Evet'
--         WHEN cu.IsShopping = 0 THEN N'Hayır'
--         ELSE '-'
--     END AS AlisverisiVarMi,

--     ISNULL(NULLIF(LTRIM(RTRIM(cu.Tel)), ''), '-') AS IrtibatNumarasi,
--     ISNULL(NULLIF(LTRIM(RTRIM(cu.Email)), ''), '-') AS EmailAdresi,

--     ISNULL(NULLIF(LTRIM(RTRIM(cr.ContactResourceName)), ''), '-') AS IletisimKaynagi,

--     ISNULL(NULLIF(LTRIM(RTRIM(p.CategoryName)), ''), '-') AS CategoryName,
--     '-' AS CategoryCode,

--     ISNULL(NULLIF(LTRIM(RTRIM(ls.Name)), ''), '-') AS LeadDurumu,
--     ISNULL(NULLIF(LTRIM(RTRIM(ns.Name)), ''), '-') AS SonrakiAdim,

--     ISNULL(NULLIF(LTRIM(RTRIM(lp.Name)), ''), '-') AS ProcessName,
--     ISNULL(NULLIF(LTRIM(RTRIM(lp.Code)), ''), '-') AS ProcessCode,
--     lp.StepOrder,
-- CASE
--     WHEN EXISTS
--     (
--         SELECT 1
--         FROM tmscrq.TMLeadReservation r
--         WHERE r.LeadId = l.Id
--           AND r.IsActive = 1
--           AND ISNULL(r.IsApproved,0) = 0
--     )
--     THEN 10
--     ELSE lp.StepOrder
-- END AS SelectedStepOrder,

--     ISNULL(
--         CASE
--             WHEN l.EstimatedDate IS NOT NULL
--             THEN CAST(YEAR(l.EstimatedDate) AS VARCHAR(4)) + ' ' + DATENAME(MONTH, l.EstimatedDate)
--             ELSE NULL
--         END,
--         '-'
--     ) AS TerminTarihi,

--     ISNULL(
--         NULLIF(
--             LTRIM(RTRIM(ISNULL(sp.FirstName, '') + ' ' + ISNULL(sp.LastName, '')))
--         , '')
--     , '-') AS SatisDanismani,

--     ISNULL(NULLIF(LTRIM(RTRIM(st.StoreDesc)), ''), '-') AS StoreName

-- FROM tmscrq.TMLead l
-- LEFT JOIN tmscrq.TMLeadStatu ls
--     ON ls.Id = l.StatuId
-- LEFT JOIN tmscrq.TMCustomer cu
--     ON cu.Id = l.CustomerId
-- LEFT JOIN tmscrq.TMProduct p
--     ON p.Id = l.ProductId
-- LEFT JOIN tmscrq.TMContactResource cr
--     ON cr.Id = l.ContactResourceId
-- LEFT JOIN dbo.KUser sp
--     ON sp.Id = l.SalesPersonKUserId
-- LEFT JOIN tmscrq.TMStore st
--     ON st.Id = l.StoreId
-- LEFT JOIN tmscrq.TMLeadProcess lp
--     ON lp.Id = l.ProcessID
-- LEFT JOIN tmscrq.TMLeadNextStep ns
--     ON ns.Id = l.NextStepId

-- WHERE
-- (
--     EXISTS
--     (
--         SELECT 1
--         FROM dbo.KUserRole ur
--         INNER JOIN dbo.KRole r
--             ON r.Id = ur.KRole_Id
--         WHERE ur.KUser_Id = @UserId
--           AND ur.IsDeleted = 0
--           AND r.IsDeleted = 0
--           AND r.Name IN ('TimesYonetici', 'TimesUstYonetici')
--     )
--     OR
--     (
--         EXISTS
--         (
--             SELECT 1
--             FROM dbo.KUserRole ur
--             INNER JOIN dbo.KRole r
--                 ON r.Id = ur.KRole_Id
--             WHERE ur.KUser_Id = @UserId
--               AND ur.IsDeleted = 0
--               AND r.IsDeleted = 0
--               AND r.Name IN ('TimesMagazaMuduru', 'TimesSatisPersoneli')
--         )
--         AND EXISTS
--         (
--             SELECT 1
--             FROM tmscrq.TMUser tu
--             WHERE tu.KUserID = @UserId
--               AND tu.StoreId = l.StoreId
--         )
--     )
-- )

-- AND
-- (
--     @MusteriAdi IS NULL
--     OR LTRIM(RTRIM(@MusteriAdi)) = ''
--     OR UPPER(LTRIM(RTRIM(ISNULL(cu.Name,'') + ' ' + ISNULL(cu.LastName,''))))
--        LIKE '%' + UPPER(LTRIM(RTRIM(@MusteriAdi))) + '%'
-- )

-- AND
-- (
--     @ProductName IS NULL
--     OR LTRIM(RTRIM(@ProductName)) = ''
--     OR
--     (
--         CHARINDEX(',', @ProductName) > 0
--         AND ISNULL(LTRIM(RTRIM(p.ProductName)), '') IN
--         (
--             SELECT LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', '')))
--             FROM STRING_SPLIT(CAST(@ProductName AS NVARCHAR(MAX)), ',')
--             WHERE LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', ''))) <> ''
--         )
--     )
--     OR
--     (
--         CHARINDEX(',', @ProductName) = 0
--         AND UPPER(ISNULL(LTRIM(RTRIM(p.ProductName)), ''))
--             LIKE '%' + UPPER(LTRIM(RTRIM(@ProductName))) + '%'
--     )
-- )

-- AND
-- (
--     @LeadCode IS NULL
--     OR LTRIM(RTRIM(@LeadCode)) = ''
--     OR UPPER(ISNULL(LTRIM(RTRIM(l.LeadCode)), '')) LIKE '%' + UPPER(LTRIM(RTRIM(@LeadCode))) + '%'
-- )

-- AND
-- (
--     @Tel IS NULL
--     OR LTRIM(RTRIM(@Tel)) = ''
--     OR UPPER(ISNULL(LTRIM(RTRIM(cu.Tel)), '')) LIKE '%' + UPPER(LTRIM(RTRIM(@Tel))) + '%'
-- )

-- -- AND
-- -- (
-- --     @CategoryName IS NULL
-- --     OR LTRIM(RTRIM(@CategoryName)) = ''
-- --     OR
-- --     (
-- --         EXISTS
-- --         (
-- --             SELECT 1
-- --             FROM STRING_SPLIT(CAST(@CategoryName AS NVARCHAR(MAX)), ',') c
-- --             WHERE UPPER(LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(c.value, '""', ''), '[', ''), ']', '')))) = 'DEFAULT'
-- --         )
-- --         AND (p.CategoryName IS NULL OR LTRIM(RTRIM(p.CategoryName)) = '')
-- --     )
-- --     OR UPPER(ISNULL(LTRIM(RTRIM(p.CategoryName)), '')) IN
-- --     (
-- --         SELECT UPPER(LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', ''))))
-- --         FROM STRING_SPLIT(CAST(@CategoryName AS NVARCHAR(MAX)), ',')
-- --         WHERE LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', ''))) <> ''
-- --           AND UPPER(LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', '')))) <> 'DEFAULT'
-- --     )
-- -- )

-- AND
-- (
--     @CategoryName IS NULL
--     OR LTRIM(RTRIM(@CategoryName)) = ''
--     OR UPPER(ISNULL(LTRIM(RTRIM(p.CategoryName)), '')) IN
--     (
--         SELECT UPPER(LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value,'""',''),'[',''),']',''))))
--         FROM STRING_SPLIT(CAST(@CategoryName AS NVARCHAR(MAX)), ',')
--         WHERE LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value,'""',''),'[',''),']',''))) <> ''
--     )
-- )

-- AND
-- (
--     @StoreIds IS NULL
--     OR LTRIM(RTRIM(@StoreIds)) = ''
--     OR EXISTS
--     (
--         SELECT 1
--         FROM STRING_SPLIT(CAST(@StoreIds AS NVARCHAR(MAX)), ',') s
--         WHERE l.StoreId = TRY_CONVERT
--         (
--             uniqueidentifier,
--             LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(s.value, '""', ''), '[', ''), ']', '')))
--         )
--     )
-- )

-- AND
-- (
--     @SatisDanismaniIds IS NULL
--     OR LTRIM(RTRIM(@SatisDanismaniIds)) = ''
--     OR EXISTS
--     (
--         SELECT 1
--         FROM STRING_SPLIT(CAST(@SatisDanismaniIds AS NVARCHAR(MAX)), ',') s
--         WHERE l.SalesPersonKUserId = TRY_CONVERT
--         (
--             uniqueidentifier,
--             LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(s.value, '""', ''), '[', ''), ']', '')))
--         )
--     )
-- )

-- AND
-- (
--     @ProcessCode IS NULL
--     OR LTRIM(RTRIM(@ProcessCode)) = ''
--     OR UPPER(ISNULL(LTRIM(RTRIM(lp.Code)), '')) IN
--     (
--         SELECT UPPER(LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', ''))))
--         FROM STRING_SPLIT(CAST(@ProcessCode AS NVARCHAR(MAX)), ',')
--         WHERE LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', ''))) <> ''
--     )
-- )

-- AND
-- (
--     @StepOrder IS NULL

--     OR
--     (
--         @StepOrder = 10
--         AND EXISTS
--         (
--             SELECT 1
--             FROM tmscrq.TMLeadReservation r
--             WHERE r.LeadId = l.Id
--               AND r.IsActive = 1
--               AND ISNULL(r.IsApproved,0) = 0
--         )
--     )

--     OR
--     (
--         @StepOrder <> 10
--         AND lp.StepOrder = @StepOrder
--     )
-- )

-- AND
-- (
--     @StartDate IS NULL
--     OR LTRIM(RTRIM(@StartDate)) = ''
--     OR l.CreatedAt >= CONVERT(date, @StartDate)
-- )

-- AND
-- (
--     @EndDate IS NULL
--     OR LTRIM(RTRIM(@EndDate)) = ''
--     OR l.CreatedAt < DATEADD(day, 1, CONVERT(date, @EndDate))
-- )

-- ORDER BY l.CreatedAt DESC;

------------------------++++++++++++++++++++++++-------------------
-- SET LANGUAGE Turkish;

-- SELECT
-- CASE 
--     WHEN EXISTS (
--         SELECT 1 
--         FROM tmscrq.TMLeadReservation r
--         WHERE r.LeadId = l.Id
--           AND r.IsActive = 1
--           AND r.IsApproved = 1
--     ) THEN N'Evet'

--     WHEN EXISTS (
--         SELECT 1 
--         FROM tmscrq.TMLeadReservation r
--         WHERE r.LeadId = l.Id
--           AND r.IsActive = 1
--           AND ISNULL(r.IsApproved,0) = 0
--     ) THEN N'Onay Bekliyor'

--     ELSE N'Hayır'
-- END AS RezerveDurumu,
--     l.Id AS LeadId,
--     l.IsReserved,
--     ISNULL(NULLIF(LTRIM(RTRIM(l.LeadCode)), ''), '-') AS LeadNumarasi,
--     CONVERT(varchar(10), l.CreatedAt, 103) AS TalepTarihi,

--     p.Id AS ProductId,
--     ISNULL(NULLIF(LTRIM(RTRIM(p.ProductName)), ''), '-') AS ProductName,
--     ISNULL(NULLIF(LTRIM(RTRIM(p.Bracelet)), ''), '-') AS Bilezik,
--     ISNULL(NULLIF(LTRIM(RTRIM(p.Brand)), ''), '-') AS Brand,
--     ISNULL(NULLIF(LTRIM(RTRIM(p.Dial)), ''), '-') AS Kadran,
--     ISNULL(NULLIF(LTRIM(RTRIM(p.ProductCode)), ''), '-') AS RefCode,
--     ISNULL(NULLIF(LTRIM(RTRIM(p.Referance)), ''), '-') AS Referans,

--     ISNULL(
--         NULLIF(
--             LTRIM(RTRIM(ISNULL(cu.Name, '') + ' ' + ISNULL(cu.LastName, '')))
--         , '')
--     , '-') AS Musteri,

--     ISNULL(NULLIF(LTRIM(RTRIM(cu.CityName)), ''), '-') AS Lokasyon,
--     ISNULL(NULLIF(LTRIM(RTRIM(cu.DistrictName)), ''), '-') AS Ilce,
--     ISNULL(NULLIF(LTRIM(RTRIM(cu.CountryName)), ''), '-') AS Ulke,
--     ISNULL(NULLIF(LTRIM(RTRIM(cu.Info)), ''), '-') AS MusteriInfo,

--     CASE
--         WHEN cu.IsShopping = 1 THEN N'Evet'
--         WHEN cu.IsShopping = 0 THEN N'Hayır'
--         ELSE '-'
--     END AS AlisverisiVarMi,

--     ISNULL(NULLIF(LTRIM(RTRIM(cu.Tel)), ''), '-') AS IrtibatNumarasi,
--     ISNULL(NULLIF(LTRIM(RTRIM(cu.Email)), ''), '-') AS EmailAdresi,

--     ISNULL(NULLIF(LTRIM(RTRIM(cr.ContactResourceName)), ''), '-') AS IletisimKaynagi,

--     ISNULL(NULLIF(LTRIM(RTRIM(p.CategoryName)), ''), '-') AS CategoryName,
--     '-' AS CategoryCode,

--     ISNULL(NULLIF(LTRIM(RTRIM(ls.Name)), ''), '-') AS LeadDurumu,
--     ISNULL(NULLIF(LTRIM(RTRIM(ns.Name)), ''), '-') AS SonrakiAdim,

--     ISNULL(NULLIF(LTRIM(RTRIM(lp.Name)), ''), '-') AS ProcessName,
--     ISNULL(NULLIF(LTRIM(RTRIM(lp.Code)), ''), '-') AS ProcessCode,
--     lp.StepOrder,
    
--     -- DÜZELTİLEN ALAN: SelectedStepOrder
--     CASE
--         WHEN EXISTS
--         (
--             SELECT 1
--             FROM tmscrq.TMLeadReservation r
--             WHERE r.LeadId = l.Id
--               AND r.IsActive = 1
--               AND ISNULL(r.IsApproved,0) = 0
--         )
--         THEN 10
--         ELSE lp.StepOrder
--     END AS SelectedStepOrder,

--     ISNULL(
--         CASE
--             WHEN l.EstimatedDate IS NOT NULL
--             THEN CAST(YEAR(l.EstimatedDate) AS VARCHAR(4)) + ' ' + DATENAME(MONTH, l.EstimatedDate)
--             ELSE NULL
--         END,
--         '-'
--     ) AS TerminTarihi,

--     ISNULL(
--         NULLIF(
--             LTRIM(RTRIM(ISNULL(sp.FirstName, '') + ' ' + ISNULL(sp.LastName, '')))
--         , '')
--     , '-') AS SatisDanismani,

--     ISNULL(NULLIF(LTRIM(RTRIM(st.StoreDesc)), ''), '-') AS StoreName

-- FROM tmscrq.TMLead l
-- LEFT JOIN tmscrq.TMLeadStatu ls
--     ON ls.Id = l.StatuId
-- LEFT JOIN tmscrq.TMCustomer cu
--     ON cu.Id = l.CustomerId
-- LEFT JOIN tmscrq.TMProduct p
--     ON p.Id = l.ProductId
-- LEFT JOIN tmscrq.TMContactResource cr
--     ON cr.Id = l.ContactResourceId
-- LEFT JOIN dbo.KUser sp
--     ON sp.Id = l.SalesPersonKUserId
-- LEFT JOIN tmscrq.TMStore st
--     ON st.Id = l.StoreId
-- LEFT JOIN tmscrq.TMLeadProcess lp
--     ON lp.Id = l.ProcessID
-- LEFT JOIN tmscrq.TMLeadNextStep ns
--     ON ns.Id = l.NextStepId

-- WHERE
-- (
--     EXISTS
--     (
--         SELECT 1
--         FROM dbo.KUserRole ur
--         INNER JOIN dbo.KRole r
--             ON r.Id = ur.KRole_Id
--         WHERE ur.KUser_Id = @UserId
--           AND ur.IsDeleted = 0
--           AND r.IsDeleted = 0
--           AND r.Name IN ('TimesYonetici', 'TimesUstYonetici')
--     )
--     OR
--     (
--         EXISTS
--         (
--             SELECT 1
--             FROM dbo.KUserRole ur
--             INNER JOIN dbo.KRole r
--                 ON r.Id = ur.KRole_Id
--             WHERE ur.KUser_Id = @UserId
--               AND ur.IsDeleted = 0
--               AND r.IsDeleted = 0
--               AND r.Name IN ('TimesMagazaMuduru', 'TimesSatisPersoneli')
--         )
--         AND EXISTS
--         (
--             SELECT 1
--             FROM tmscrq.TMUser tu
--             WHERE tu.KUserID = @UserId
--               AND tu.StoreId = l.StoreId
--         )
--     )
-- )

-- AND
-- (
--     @MusteriAdi IS NULL
--     OR LTRIM(RTRIM(@MusteriAdi)) = ''
--     OR UPPER(LTRIM(RTRIM(ISNULL(cu.Name,'') + ' ' + ISNULL(cu.LastName,''))))
--        LIKE '%' + UPPER(LTRIM(RTRIM(@MusteriAdi))) + '%'
-- )

-- AND
-- (
--     @ProductName IS NULL
--     OR LTRIM(RTRIM(@ProductName)) = ''
--     OR
--     (
--         CHARINDEX(',', @ProductName) > 0
--         AND ISNULL(LTRIM(RTRIM(p.ProductName)), '') IN
--         (
--             SELECT LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', '')))
--             FROM STRING_SPLIT(CAST(@ProductName AS NVARCHAR(MAX)), ',')
--             WHERE LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', ''))) <> ''
--         )
--     )
--     OR
--     (
--         CHARINDEX(',', @ProductName) = 0
--         AND UPPER(ISNULL(LTRIM(RTRIM(p.ProductName)), ''))
--             LIKE '%' + UPPER(LTRIM(RTRIM(@ProductName))) + '%'
--     )
-- )

-- AND
-- (
--     @LeadCode IS NULL
--     OR LTRIM(RTRIM(@LeadCode)) = ''
--     OR UPPER(ISNULL(LTRIM(RTRIM(l.LeadCode)), '')) LIKE '%' + UPPER(LTRIM(RTRIM(@LeadCode))) + '%'
-- )

-- AND
-- (
--     @Tel IS NULL
--     OR LTRIM(RTRIM(@Tel)) = ''
--     OR UPPER(ISNULL(LTRIM(RTRIM(cu.Tel)), '')) LIKE '%' + UPPER(LTRIM(RTRIM(@Tel))) + '%'
-- )

-- AND
-- (
--     @CategoryName IS NULL
--     OR LTRIM(RTRIM(@CategoryName)) = ''
--     OR UPPER(ISNULL(LTRIM(RTRIM(p.CategoryName)), '')) IN
--     (
--         SELECT UPPER(LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value,'""',''),'[',''),']',''))))
--         FROM STRING_SPLIT(CAST(@CategoryName AS NVARCHAR(MAX)), ',')
--         WHERE LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value,'""',''),'[',''),']',''))) <> ''
--     )
-- )

-- AND
-- (
--     @StoreIds IS NULL
--     OR LTRIM(RTRIM(@StoreIds)) = ''
--     OR EXISTS
--     (
--         SELECT 1
--         FROM STRING_SPLIT(CAST(@StoreIds AS NVARCHAR(MAX)), ',') s
--         WHERE l.StoreId = TRY_CONVERT
--         (
--             uniqueidentifier,
--             LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(s.value, '""', ''), '[', ''), ']', '')))
--         )
--     )
-- )

-- AND
-- (
--     @SatisDanismaniIds IS NULL
--     OR LTRIM(RTRIM(@SatisDanismaniIds)) = ''
--     OR EXISTS
--     (
--         SELECT 1
--         FROM STRING_SPLIT(CAST(@SatisDanismaniIds AS NVARCHAR(MAX)), ',') s
--         WHERE l.SalesPersonKUserId = TRY_CONVERT
--         (
--             uniqueidentifier,
--             LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(s.value, '""', ''), '[', ''), ']', '')))
--         )
--     )
-- )

-- AND
-- (
--     @ProcessCode IS NULL
--     OR LTRIM(RTRIM(@ProcessCode)) = ''
--     OR UPPER(ISNULL(LTRIM(RTRIM(lp.Code)), '')) IN
--     (
--         SELECT UPPER(LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', ''))))
--         FROM STRING_SPLIT(CAST(@ProcessCode AS NVARCHAR(MAX)), ',')
--         WHERE LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', ''))) <> ''
--     )
-- )

-- -- DÜZELTİLEN ALAN: @StepOrder Filtresi (tek blok)
-- AND
-- (
--     @StepOrder IS NULL

--     OR

--     (
--         @StepOrder = 10
--         AND EXISTS
--         (
--             SELECT 1
--             FROM tmscrq.TMLeadReservation r
--             WHERE r.LeadId = l.Id
--               AND r.IsActive = 1
--               AND ISNULL(r.IsApproved,0) = 0
--         )
--     )

--     OR

--     (
--         @StepOrder <> 10
--         AND lp.StepOrder = @StepOrder
--     )
-- )

-- AND
-- (
--     @StartDate IS NULL
--     OR LTRIM(RTRIM(@StartDate)) = ''
--     OR l.CreatedAt >= CONVERT(date, @StartDate)
-- )

-- AND
-- (
--     @EndDate IS NULL
--     OR LTRIM(RTRIM(@EndDate)) = ''
--     OR l.CreatedAt < DATEADD(day, 1, CONVERT(date, @EndDate))
-- )

-- ORDER BY l.CreatedAt DESC;



SET LANGUAGE Turkish;

SELECT
CASE 
    WHEN EXISTS (
        SELECT 1 
        FROM tmscrq.TMLeadReservation r
        WHERE r.LeadId = l.Id
          AND r.IsActive = 1
          AND r.IsApproved = 1
    ) THEN N'Evet'

    WHEN EXISTS (
        SELECT 1 
        FROM tmscrq.TMLeadReservation r
        WHERE r.LeadId = l.Id
          AND r.IsActive = 1
          AND ISNULL(r.IsApproved,0) = 0
    ) THEN N'Onay Bekliyor'

    ELSE N'Hayır'
END AS RezerveDurumu,
    l.Id AS LeadId,
    l.IsReserved,
    ISNULL(NULLIF(LTRIM(RTRIM(l.LeadCode)), ''), '-') AS LeadNumarasi,
     FORMAT(l.CreatedAt, 'dd MMMM yyyy', 'tr-TR') AS TalepTarihi,

    p.Id AS ProductId,
    ISNULL(NULLIF(LTRIM(RTRIM(p.ProductName)), ''), '-') AS ProductName,
    ISNULL(NULLIF(LTRIM(RTRIM(p.Bracelet)), ''), '-') AS Bilezik,
    ISNULL(NULLIF(LTRIM(RTRIM(p.Brand)), ''), '-') AS Brand,
    ISNULL(NULLIF(LTRIM(RTRIM(p.Dial)), ''), '-') AS Kadran,
    ISNULL(NULLIF(LTRIM(RTRIM(p.ProductCode)), ''), '-') AS RefCode,
    ISNULL(NULLIF(LTRIM(RTRIM(p.Referance)), ''), '-') AS Referans,

    ISNULL(
        NULLIF(
            LTRIM(RTRIM(ISNULL(cu.Name, '') + ' ' + ISNULL(cu.LastName, '')))
        , '')
    , '-') AS Musteri,

    ISNULL(NULLIF(LTRIM(RTRIM(cu.CityName)), ''), '-') AS Lokasyon,
    ISNULL(NULLIF(LTRIM(RTRIM(cu.DistrictName)), ''), '-') AS Ilce,
    ISNULL(NULLIF(LTRIM(RTRIM(cu.CountryName)), ''), '-') AS Ulke,
    ISNULL(NULLIF(LTRIM(RTRIM(cu.Info)), ''), '-') AS MusteriInfo,

    CASE
        WHEN cu.IsShopping = 1 THEN N'Evet'
        WHEN cu.IsShopping = 0 THEN N'Hayır'
        ELSE '-'
    END AS AlisverisiVarMi,

    ISNULL(NULLIF(LTRIM(RTRIM(cu.Tel)), ''), '-') AS IrtibatNumarasi,
    ISNULL(NULLIF(LTRIM(RTRIM(cu.Email)), ''), '-') AS EmailAdresi,

    ISNULL(NULLIF(LTRIM(RTRIM(cr.ContactResourceName)), ''), '-') AS IletisimKaynagi,

    ISNULL(NULLIF(LTRIM(RTRIM(p.CategoryName)), ''), '-') AS CategoryName,
    '-' AS CategoryCode,

    ISNULL(NULLIF(LTRIM(RTRIM(ls.Name)), ''), '-') AS LeadDurumu,
    ISNULL(NULLIF(LTRIM(RTRIM(ns.Name)), ''), '-') AS SonrakiAdim,

    ISNULL(NULLIF(LTRIM(RTRIM(lp.Name)), ''), '-') AS ProcessName,
    ISNULL(NULLIF(LTRIM(RTRIM(lp.Code)), ''), '-') AS ProcessCode,
    lp.StepOrder,
    
    -- DÜZELTİLEN ALAN: SelectedStepOrder
    CASE
        WHEN EXISTS
        (
            SELECT 1
            FROM tmscrq.TMLeadReservation r
            WHERE r.LeadId = l.Id
              AND r.IsActive = 1
              AND ISNULL(r.IsApproved,0) = 0
        )
        THEN 10
        ELSE lp.StepOrder
    END AS SelectedStepOrder,

    ISNULL(
        CASE
            WHEN l.EstimatedDate IS NOT NULL
            THEN CAST(YEAR(l.EstimatedDate) AS VARCHAR(4)) + ' ' + DATENAME(MONTH, l.EstimatedDate)
            ELSE NULL
        END,
        '-'
    ) AS TerminTarihi,

    ISNULL(
        NULLIF(
            LTRIM(RTRIM(ISNULL(sp.FirstName, '') + ' ' + ISNULL(sp.LastName, '')))
        , '')
    , '-') AS SatisDanismani,

    ISNULL(NULLIF(LTRIM(RTRIM(st.StoreDesc)), ''), '-') AS StoreName

FROM tmscrq.TMLead l
LEFT JOIN tmscrq.TMLeadStatu ls
    ON ls.Id = l.StatuId
LEFT JOIN tmscrq.TMCustomer cu
    ON cu.Id = l.CustomerId
LEFT JOIN tmscrq.TMProduct p
    ON p.Id = l.ProductId
LEFT JOIN tmscrq.TMContactResource cr
    ON cr.Id = l.ContactResourceId
LEFT JOIN dbo.KUser sp
    ON sp.Id = l.SalesPersonKUserId
LEFT JOIN tmscrq.TMStore st
    ON st.Id = l.StoreId
LEFT JOIN tmscrq.TMLeadProcess lp
    ON lp.Id = l.ProcessID
LEFT JOIN tmscrq.TMLeadNextStep ns
    ON ns.Id = l.NextStepId

WHERE
(
    EXISTS
    (
        SELECT 1
        FROM dbo.KUserRole ur
        INNER JOIN dbo.KRole r
            ON r.Id = ur.KRole_Id
        WHERE ur.KUser_Id = @UserId
          AND ur.IsDeleted = 0
          AND r.IsDeleted = 0
          AND r.Name IN ('TimesYonetici', 'TimesUstYonetici')
    )
    OR
    (
        EXISTS
        (
            SELECT 1
            FROM dbo.KUserRole ur
            INNER JOIN dbo.KRole r
                ON r.Id = ur.KRole_Id
            WHERE ur.KUser_Id = @UserId
              AND ur.IsDeleted = 0
              AND r.IsDeleted = 0
              AND r.Name IN ('TimesMagazaMuduru', 'TimesSatisPersoneli')
        )
        AND EXISTS
        (
            SELECT 1
            FROM tmscrq.TMUser tu
            WHERE tu.KUserID = @UserId
              AND tu.StoreId = l.StoreId
        )
    )
)

AND
(
    ISNULL(@MusteriAdi, '') = ''
    OR UPPER(ISNULL(cu.Name, '')) LIKE '%' + UPPER(LTRIM(RTRIM(@MusteriAdi))) + '%'
    OR UPPER(ISNULL(cu.LastName, '')) LIKE '%' + UPPER(LTRIM(RTRIM(@MusteriAdi))) + '%'
    OR UPPER(
        ISNULL(cu.Name, '') + ' ' + ISNULL(cu.LastName, '')
    ) LIKE '%' + UPPER(LTRIM(RTRIM(@MusteriAdi))) + '%'
)

AND
(
    @ProductName IS NULL
    OR LTRIM(RTRIM(@ProductName)) = ''
    OR
    (
        CHARINDEX(',', @ProductName) > 0
        AND ISNULL(LTRIM(RTRIM(p.ProductName)), '') IN
        (
            SELECT LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', '')))
            FROM STRING_SPLIT(CAST(@ProductName AS NVARCHAR(MAX)), ',')
            WHERE LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', ''))) <> ''
        )
    )
    OR
    (
        CHARINDEX(',', @ProductName) = 0
        AND UPPER(ISNULL(LTRIM(RTRIM(p.ProductName)), ''))
            LIKE '%' + UPPER(LTRIM(RTRIM(@ProductName))) + '%'
    )
)

AND
(
    ISNULL(@LeadCode, '') = ''
    OR UPPER(ISNULL(l.LeadCode, ''))
        LIKE '%' + UPPER(LTRIM(RTRIM(@LeadCode))) + '%'
    OR REPLACE(
        REPLACE(
            REPLACE(
                UPPER(ISNULL(l.LeadCode, '')),
                '-', ''
            ),
            ' ', ''
        ),
        '/', ''
    )
    LIKE '%' +
    REPLACE(
        REPLACE(
            REPLACE(
                UPPER(LTRIM(RTRIM(@LeadCode))),
                '-', ''
            ),
            ' ', ''
        ),
        '/', ''
    )
    + '%'
)

AND
(
    @Tel IS NULL
    OR LTRIM(RTRIM(@Tel)) = ''
    OR UPPER(ISNULL(LTRIM(RTRIM(cu.Tel)), '')) LIKE '%' + UPPER(LTRIM(RTRIM(@Tel))) + '%'
)

AND
(
    @CategoryName IS NULL
    OR LTRIM(RTRIM(@CategoryName)) = ''
    OR UPPER(ISNULL(LTRIM(RTRIM(p.CategoryName)), '')) IN
    (
        SELECT UPPER(LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value,'""',''),'[',''),']',''))))
        FROM STRING_SPLIT(CAST(@CategoryName AS NVARCHAR(MAX)), ',')
        WHERE LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value,'""',''),'[',''),']',''))) <> ''
    )
)

AND
(
    @StoreIds IS NULL
    OR LTRIM(RTRIM(@StoreIds)) = ''
    OR EXISTS
    (
        SELECT 1
        FROM STRING_SPLIT(CAST(@StoreIds AS NVARCHAR(MAX)), ',') s
        WHERE l.StoreId = TRY_CONVERT
        (
            uniqueidentifier,
            LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(s.value, '""', ''), '[', ''), ']', '')))
        )
    )
)

AND
(
    @SatisDanismaniIds IS NULL
    OR LTRIM(RTRIM(@SatisDanismaniIds)) = ''
    OR EXISTS
    (
        SELECT 1
        FROM STRING_SPLIT(CAST(@SatisDanismaniIds AS NVARCHAR(MAX)), ',') s
        WHERE l.SalesPersonKUserId = TRY_CONVERT
        (
            uniqueidentifier,
            LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(s.value, '""', ''), '[', ''), ']', '')))
        )
    )
)

AND
(
    ISNULL(@ProcessCode, '') = ''
    OR EXISTS
    (
        SELECT 1
        FROM STRING_SPLIT(
            CONVERT(NVARCHAR(MAX), @ProcessCode),
            ','
        ) AS s
        WHERE
            UPPER(LTRIM(RTRIM(s.value))) =
            UPPER(LTRIM(RTRIM(ISNULL(lp.Code, ''))))
    )
)

-- DÜZELTİLEN ALAN: @StepOrder Filtresi (0 verilince tümü gelsin)
AND
(
    @StepOrder IS NULL
    OR @StepOrder = 0  -- 👈 YENİ EKLENDI: 0 verilince tüm kayıtlar gelir
    OR
    (
        @StepOrder = 10
        AND EXISTS
        (
            SELECT 1
            FROM tmscrq.TMLeadReservation r
            WHERE r.LeadId = l.Id
              AND r.IsActive = 1
              AND ISNULL(r.IsApproved,0) = 0
        )
    )
    OR
    (
        @StepOrder <> 10
        AND lp.StepOrder = @StepOrder
    )
)

AND
(
    @StartDate IS NULL
    OR LTRIM(RTRIM(@StartDate)) = ''
    OR l.CreatedAt >= CONVERT(date, @StartDate)
)

AND
(
    @EndDate IS NULL
    OR LTRIM(RTRIM(@EndDate)) = ''
    OR l.CreatedAt < DATEADD(day, 1, CONVERT(date, @EndDate))
)

ORDER BY l.CreatedAt DESC;", new string[] { "RezerveDurumu", "LeadId", "IsReserved", "LeadNumarasi", "TalepTarihi", "ProductId", "ProductName", "Bilezik", "Brand", "Kadran", "RefCode", "Referans", "Musteri", "Lokasyon", "Ilce", "Ulke", "MusteriInfo", "AlisverisiVarMi", "IrtibatNumarasi", "EmailAdresi", "IletisimKaynagi", "CategoryName", "CategoryCode", "LeadDurumu", "SonrakiAdim", "ProcessName", "ProcessCode", "StepOrder", "SelectedStepOrder", "TerminTarihi", "SatisDanismani", "StoreName" }, prms_TM_GetLeads_0.ToArray());
            ;


            return Ok(result);
        }


        [HttpPost, Route("LeadListComponent_416933_onClick")]
        public IActionResult LeadListComponent_416933_onClick(LeadListComponent_416933_onClick_Request request)
        {

            KProviderManager.Authorization.IsAuthorizedForRoles(appId, appName, screenId, screenName, new List<string> { $"70de6cfc-6087-6059-59b4-0b5a8527af6b", "4da1f213-c8e4-0b50-5c84-02fd13f1a622", "c4e882ef-977d-f613-7694-230ac83919d2", "b4bfd39c-ac02-f442-c899-7a2374a45b47", "cdb536b0-6297-155f-d446-8453d8a60304", "TimesYonetici", "TimesUstYonetici", "TimesSatisPersoneli", "TimesMagazaMuduru", "TimesAdmin" });

            var result = new LeadListComponent_416933_onClick_Response();

            var prms_TM_GetLeads_0 = new List<kSqlParameter>();
            prms_TM_GetLeads_0.Add(new kSqlParameter() { Name = "StepOrder", Value = "6".ConvertToType<Int32>() });
            prms_TM_GetLeads_0.Add(new kSqlParameter() { Name = "UserId", Value = Kuika.Common.KContext.CurrentUser?.Id });
            prms_TM_GetLeads_0.Add(new kSqlParameter() { Name = "MusteriAdi", Value = request.MusteriAdi_0 });
            prms_TM_GetLeads_0.Add(new kSqlParameter() { Name = "ProductName", Value = request.ProductName_0 });
            prms_TM_GetLeads_0.Add(new kSqlParameter() { Name = "LeadCode", Value = request.LeadCode_0 });
            prms_TM_GetLeads_0.Add(new kSqlParameter() { Name = "Tel", Value = request.Tel_0 });
            prms_TM_GetLeads_0.Add(new kSqlParameter() { Name = "CategoryName", Value = request.CategoryName_0 });
            prms_TM_GetLeads_0.Add(new kSqlParameter() { Name = "StoreIds", Value = request.StoreIds_0 });
            prms_TM_GetLeads_0.Add(new kSqlParameter() { Name = "SatisDanismaniIds", Value = request.SatisDanismaniIds_0 });
            prms_TM_GetLeads_0.Add(new kSqlParameter() { Name = "ProcessCode", Value = request.ProcessCode_0 });
            prms_TM_GetLeads_0.Add(new kSqlParameter() { Name = "StartDate", Value = request.StartDate_0 });
            prms_TM_GetLeads_0.Add(new kSqlParameter() { Name = "EndDate", Value = request.EndDate_0 });
            using var auditTM_GetLeads_0 = ActionAuditScope.Begin("40189a41-de6e-73c4-668d-e3070cb8fb42", "TM_GetLeads", applicationName: "wbTimesCRM", screenOrEndpointName: "LeadList");
            result.TM_GetLeads = KPersister.Fetch(KContext.GetConnectionString(), @"-- SET LANGUAGE Turkish;

-- SELECT
-- CASE 
--     WHEN EXISTS (
--         SELECT 1 
--         FROM tmscrq.TMLeadReservation r
--         WHERE r.LeadId = l.Id
--           AND r.IsActive = 1
--           AND r.IsApproved = 1
--     ) THEN N'Evet'

--     WHEN EXISTS (
--         SELECT 1 
--         FROM tmscrq.TMLeadReservation r
--         WHERE r.LeadId = l.Id
--           AND r.IsActive = 1
--           AND ISNULL(r.IsApproved,0) = 0
--     ) THEN N'Onay Bekliyor'

--     ELSE N'Hayır'
-- END AS RezerveDurumu,
--     l.Id AS LeadId,
--     l.IsReserved,
--     ISNULL(NULLIF(LTRIM(RTRIM(l.LeadCode)), ''), '-') AS LeadNumarasi,
--     CONVERT(varchar(10), l.CreatedAt, 103) AS TalepTarihi,

--     p.Id AS ProductId,
--     ISNULL(NULLIF(LTRIM(RTRIM(p.ProductName)), ''), '-') AS ProductName,
--     ISNULL(NULLIF(LTRIM(RTRIM(p.Bracelet)), ''), '-') AS Bilezik,
--     ISNULL(NULLIF(LTRIM(RTRIM(p.Brand)), ''), '-') AS Brand,
--     ISNULL(NULLIF(LTRIM(RTRIM(p.Dial)), ''), '-') AS Kadran,
--     ISNULL(NULLIF(LTRIM(RTRIM(p.ProductCode)), ''), '-') AS RefCode,
--     ISNULL(NULLIF(LTRIM(RTRIM(p.Referance)), ''), '-') AS Referans,

--     ISNULL(
--         NULLIF(
--             LTRIM(RTRIM(ISNULL(cu.Name, '') + ' ' + ISNULL(cu.LastName, '')))
--         , '')
--     , '-') AS Musteri,

--     ISNULL(NULLIF(LTRIM(RTRIM(cu.CityName)), ''), '-') AS Lokasyon,
--     ISNULL(NULLIF(LTRIM(RTRIM(cu.DistrictName)), ''), '-') AS Ilce,
--     ISNULL(NULLIF(LTRIM(RTRIM(cu.CountryName)), ''), '-') AS Ulke,
--     ISNULL(NULLIF(LTRIM(RTRIM(cu.Info)), ''), '-') AS MusteriInfo,

--     CASE
--         WHEN cu.IsShopping = 1 THEN N'Evet'
--         WHEN cu.IsShopping = 0 THEN N'Hayır'
--         ELSE '-'
--     END AS AlisverisiVarMi,

--     ISNULL(NULLIF(LTRIM(RTRIM(cu.Tel)), ''), '-') AS IrtibatNumarasi,
--     ISNULL(NULLIF(LTRIM(RTRIM(cu.Email)), ''), '-') AS EmailAdresi,

--     ISNULL(NULLIF(LTRIM(RTRIM(cr.ContactResourceName)), ''), '-') AS IletisimKaynagi,

--     ISNULL(NULLIF(LTRIM(RTRIM(p.CategoryName)), ''), '-') AS CategoryName,
--     '-' AS CategoryCode,

--     ISNULL(NULLIF(LTRIM(RTRIM(ls.Name)), ''), '-') AS LeadDurumu,
--     ISNULL(NULLIF(LTRIM(RTRIM(ns.Name)), ''), '-') AS SonrakiAdim,

--     ISNULL(NULLIF(LTRIM(RTRIM(lp.Name)), ''), '-') AS ProcessName,
--     ISNULL(NULLIF(LTRIM(RTRIM(lp.Code)), ''), '-') AS ProcessCode,
--     lp.StepOrder,
-- CASE
--     WHEN EXISTS
--     (
--         SELECT 1
--         FROM tmscrq.TMLeadReservation r
--         WHERE r.LeadId = l.Id
--           AND r.IsActive = 1
--           AND ISNULL(r.IsApproved,0) = 0
--     )
--     THEN 10
--     ELSE lp.StepOrder
-- END AS SelectedStepOrder,

--     ISNULL(
--         CASE
--             WHEN l.EstimatedDate IS NOT NULL
--             THEN CAST(YEAR(l.EstimatedDate) AS VARCHAR(4)) + ' ' + DATENAME(MONTH, l.EstimatedDate)
--             ELSE NULL
--         END,
--         '-'
--     ) AS TerminTarihi,

--     ISNULL(
--         NULLIF(
--             LTRIM(RTRIM(ISNULL(sp.FirstName, '') + ' ' + ISNULL(sp.LastName, '')))
--         , '')
--     , '-') AS SatisDanismani,

--     ISNULL(NULLIF(LTRIM(RTRIM(st.StoreDesc)), ''), '-') AS StoreName

-- FROM tmscrq.TMLead l
-- LEFT JOIN tmscrq.TMLeadStatu ls
--     ON ls.Id = l.StatuId
-- LEFT JOIN tmscrq.TMCustomer cu
--     ON cu.Id = l.CustomerId
-- LEFT JOIN tmscrq.TMProduct p
--     ON p.Id = l.ProductId
-- LEFT JOIN tmscrq.TMContactResource cr
--     ON cr.Id = l.ContactResourceId
-- LEFT JOIN dbo.KUser sp
--     ON sp.Id = l.SalesPersonKUserId
-- LEFT JOIN tmscrq.TMStore st
--     ON st.Id = l.StoreId
-- LEFT JOIN tmscrq.TMLeadProcess lp
--     ON lp.Id = l.ProcessID
-- LEFT JOIN tmscrq.TMLeadNextStep ns
--     ON ns.Id = l.NextStepId

-- WHERE
-- (
--     EXISTS
--     (
--         SELECT 1
--         FROM dbo.KUserRole ur
--         INNER JOIN dbo.KRole r
--             ON r.Id = ur.KRole_Id
--         WHERE ur.KUser_Id = @UserId
--           AND ur.IsDeleted = 0
--           AND r.IsDeleted = 0
--           AND r.Name IN ('TimesYonetici', 'TimesUstYonetici')
--     )
--     OR
--     (
--         EXISTS
--         (
--             SELECT 1
--             FROM dbo.KUserRole ur
--             INNER JOIN dbo.KRole r
--                 ON r.Id = ur.KRole_Id
--             WHERE ur.KUser_Id = @UserId
--               AND ur.IsDeleted = 0
--               AND r.IsDeleted = 0
--               AND r.Name IN ('TimesMagazaMuduru', 'TimesSatisPersoneli')
--         )
--         AND EXISTS
--         (
--             SELECT 1
--             FROM tmscrq.TMUser tu
--             WHERE tu.KUserID = @UserId
--               AND tu.StoreId = l.StoreId
--         )
--     )
-- )

-- AND
-- (
--     @MusteriAdi IS NULL
--     OR LTRIM(RTRIM(@MusteriAdi)) = ''
--     OR UPPER(LTRIM(RTRIM(ISNULL(cu.Name,'') + ' ' + ISNULL(cu.LastName,''))))
--        LIKE '%' + UPPER(LTRIM(RTRIM(@MusteriAdi))) + '%'
-- )

-- AND
-- (
--     @ProductName IS NULL
--     OR LTRIM(RTRIM(@ProductName)) = ''
--     OR
--     (
--         CHARINDEX(',', @ProductName) > 0
--         AND ISNULL(LTRIM(RTRIM(p.ProductName)), '') IN
--         (
--             SELECT LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', '')))
--             FROM STRING_SPLIT(CAST(@ProductName AS NVARCHAR(MAX)), ',')
--             WHERE LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', ''))) <> ''
--         )
--     )
--     OR
--     (
--         CHARINDEX(',', @ProductName) = 0
--         AND UPPER(ISNULL(LTRIM(RTRIM(p.ProductName)), ''))
--             LIKE '%' + UPPER(LTRIM(RTRIM(@ProductName))) + '%'
--     )
-- )

-- AND
-- (
--     @LeadCode IS NULL
--     OR LTRIM(RTRIM(@LeadCode)) = ''
--     OR UPPER(ISNULL(LTRIM(RTRIM(l.LeadCode)), '')) LIKE '%' + UPPER(LTRIM(RTRIM(@LeadCode))) + '%'
-- )

-- AND
-- (
--     @Tel IS NULL
--     OR LTRIM(RTRIM(@Tel)) = ''
--     OR UPPER(ISNULL(LTRIM(RTRIM(cu.Tel)), '')) LIKE '%' + UPPER(LTRIM(RTRIM(@Tel))) + '%'
-- )

-- -- AND
-- -- (
-- --     @CategoryName IS NULL
-- --     OR LTRIM(RTRIM(@CategoryName)) = ''
-- --     OR
-- --     (
-- --         EXISTS
-- --         (
-- --             SELECT 1
-- --             FROM STRING_SPLIT(CAST(@CategoryName AS NVARCHAR(MAX)), ',') c
-- --             WHERE UPPER(LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(c.value, '""', ''), '[', ''), ']', '')))) = 'DEFAULT'
-- --         )
-- --         AND (p.CategoryName IS NULL OR LTRIM(RTRIM(p.CategoryName)) = '')
-- --     )
-- --     OR UPPER(ISNULL(LTRIM(RTRIM(p.CategoryName)), '')) IN
-- --     (
-- --         SELECT UPPER(LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', ''))))
-- --         FROM STRING_SPLIT(CAST(@CategoryName AS NVARCHAR(MAX)), ',')
-- --         WHERE LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', ''))) <> ''
-- --           AND UPPER(LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', '')))) <> 'DEFAULT'
-- --     )
-- -- )

-- AND
-- (
--     @CategoryName IS NULL
--     OR LTRIM(RTRIM(@CategoryName)) = ''
--     OR UPPER(ISNULL(LTRIM(RTRIM(p.CategoryName)), '')) IN
--     (
--         SELECT UPPER(LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value,'""',''),'[',''),']',''))))
--         FROM STRING_SPLIT(CAST(@CategoryName AS NVARCHAR(MAX)), ',')
--         WHERE LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value,'""',''),'[',''),']',''))) <> ''
--     )
-- )

-- AND
-- (
--     @StoreIds IS NULL
--     OR LTRIM(RTRIM(@StoreIds)) = ''
--     OR EXISTS
--     (
--         SELECT 1
--         FROM STRING_SPLIT(CAST(@StoreIds AS NVARCHAR(MAX)), ',') s
--         WHERE l.StoreId = TRY_CONVERT
--         (
--             uniqueidentifier,
--             LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(s.value, '""', ''), '[', ''), ']', '')))
--         )
--     )
-- )

-- AND
-- (
--     @SatisDanismaniIds IS NULL
--     OR LTRIM(RTRIM(@SatisDanismaniIds)) = ''
--     OR EXISTS
--     (
--         SELECT 1
--         FROM STRING_SPLIT(CAST(@SatisDanismaniIds AS NVARCHAR(MAX)), ',') s
--         WHERE l.SalesPersonKUserId = TRY_CONVERT
--         (
--             uniqueidentifier,
--             LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(s.value, '""', ''), '[', ''), ']', '')))
--         )
--     )
-- )

-- AND
-- (
--     @ProcessCode IS NULL
--     OR LTRIM(RTRIM(@ProcessCode)) = ''
--     OR UPPER(ISNULL(LTRIM(RTRIM(lp.Code)), '')) IN
--     (
--         SELECT UPPER(LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', ''))))
--         FROM STRING_SPLIT(CAST(@ProcessCode AS NVARCHAR(MAX)), ',')
--         WHERE LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', ''))) <> ''
--     )
-- )

-- AND
-- (
--     @StepOrder IS NULL

--     OR
--     (
--         @StepOrder = 10
--         AND EXISTS
--         (
--             SELECT 1
--             FROM tmscrq.TMLeadReservation r
--             WHERE r.LeadId = l.Id
--               AND r.IsActive = 1
--               AND ISNULL(r.IsApproved,0) = 0
--         )
--     )

--     OR
--     (
--         @StepOrder <> 10
--         AND lp.StepOrder = @StepOrder
--     )
-- )

-- AND
-- (
--     @StartDate IS NULL
--     OR LTRIM(RTRIM(@StartDate)) = ''
--     OR l.CreatedAt >= CONVERT(date, @StartDate)
-- )

-- AND
-- (
--     @EndDate IS NULL
--     OR LTRIM(RTRIM(@EndDate)) = ''
--     OR l.CreatedAt < DATEADD(day, 1, CONVERT(date, @EndDate))
-- )

-- ORDER BY l.CreatedAt DESC;

------------------------++++++++++++++++++++++++-------------------
-- SET LANGUAGE Turkish;

-- SELECT
-- CASE 
--     WHEN EXISTS (
--         SELECT 1 
--         FROM tmscrq.TMLeadReservation r
--         WHERE r.LeadId = l.Id
--           AND r.IsActive = 1
--           AND r.IsApproved = 1
--     ) THEN N'Evet'

--     WHEN EXISTS (
--         SELECT 1 
--         FROM tmscrq.TMLeadReservation r
--         WHERE r.LeadId = l.Id
--           AND r.IsActive = 1
--           AND ISNULL(r.IsApproved,0) = 0
--     ) THEN N'Onay Bekliyor'

--     ELSE N'Hayır'
-- END AS RezerveDurumu,
--     l.Id AS LeadId,
--     l.IsReserved,
--     ISNULL(NULLIF(LTRIM(RTRIM(l.LeadCode)), ''), '-') AS LeadNumarasi,
--     CONVERT(varchar(10), l.CreatedAt, 103) AS TalepTarihi,

--     p.Id AS ProductId,
--     ISNULL(NULLIF(LTRIM(RTRIM(p.ProductName)), ''), '-') AS ProductName,
--     ISNULL(NULLIF(LTRIM(RTRIM(p.Bracelet)), ''), '-') AS Bilezik,
--     ISNULL(NULLIF(LTRIM(RTRIM(p.Brand)), ''), '-') AS Brand,
--     ISNULL(NULLIF(LTRIM(RTRIM(p.Dial)), ''), '-') AS Kadran,
--     ISNULL(NULLIF(LTRIM(RTRIM(p.ProductCode)), ''), '-') AS RefCode,
--     ISNULL(NULLIF(LTRIM(RTRIM(p.Referance)), ''), '-') AS Referans,

--     ISNULL(
--         NULLIF(
--             LTRIM(RTRIM(ISNULL(cu.Name, '') + ' ' + ISNULL(cu.LastName, '')))
--         , '')
--     , '-') AS Musteri,

--     ISNULL(NULLIF(LTRIM(RTRIM(cu.CityName)), ''), '-') AS Lokasyon,
--     ISNULL(NULLIF(LTRIM(RTRIM(cu.DistrictName)), ''), '-') AS Ilce,
--     ISNULL(NULLIF(LTRIM(RTRIM(cu.CountryName)), ''), '-') AS Ulke,
--     ISNULL(NULLIF(LTRIM(RTRIM(cu.Info)), ''), '-') AS MusteriInfo,

--     CASE
--         WHEN cu.IsShopping = 1 THEN N'Evet'
--         WHEN cu.IsShopping = 0 THEN N'Hayır'
--         ELSE '-'
--     END AS AlisverisiVarMi,

--     ISNULL(NULLIF(LTRIM(RTRIM(cu.Tel)), ''), '-') AS IrtibatNumarasi,
--     ISNULL(NULLIF(LTRIM(RTRIM(cu.Email)), ''), '-') AS EmailAdresi,

--     ISNULL(NULLIF(LTRIM(RTRIM(cr.ContactResourceName)), ''), '-') AS IletisimKaynagi,

--     ISNULL(NULLIF(LTRIM(RTRIM(p.CategoryName)), ''), '-') AS CategoryName,
--     '-' AS CategoryCode,

--     ISNULL(NULLIF(LTRIM(RTRIM(ls.Name)), ''), '-') AS LeadDurumu,
--     ISNULL(NULLIF(LTRIM(RTRIM(ns.Name)), ''), '-') AS SonrakiAdim,

--     ISNULL(NULLIF(LTRIM(RTRIM(lp.Name)), ''), '-') AS ProcessName,
--     ISNULL(NULLIF(LTRIM(RTRIM(lp.Code)), ''), '-') AS ProcessCode,
--     lp.StepOrder,
    
--     -- DÜZELTİLEN ALAN: SelectedStepOrder
--     CASE
--         WHEN EXISTS
--         (
--             SELECT 1
--             FROM tmscrq.TMLeadReservation r
--             WHERE r.LeadId = l.Id
--               AND r.IsActive = 1
--               AND ISNULL(r.IsApproved,0) = 0
--         )
--         THEN 10
--         ELSE lp.StepOrder
--     END AS SelectedStepOrder,

--     ISNULL(
--         CASE
--             WHEN l.EstimatedDate IS NOT NULL
--             THEN CAST(YEAR(l.EstimatedDate) AS VARCHAR(4)) + ' ' + DATENAME(MONTH, l.EstimatedDate)
--             ELSE NULL
--         END,
--         '-'
--     ) AS TerminTarihi,

--     ISNULL(
--         NULLIF(
--             LTRIM(RTRIM(ISNULL(sp.FirstName, '') + ' ' + ISNULL(sp.LastName, '')))
--         , '')
--     , '-') AS SatisDanismani,

--     ISNULL(NULLIF(LTRIM(RTRIM(st.StoreDesc)), ''), '-') AS StoreName

-- FROM tmscrq.TMLead l
-- LEFT JOIN tmscrq.TMLeadStatu ls
--     ON ls.Id = l.StatuId
-- LEFT JOIN tmscrq.TMCustomer cu
--     ON cu.Id = l.CustomerId
-- LEFT JOIN tmscrq.TMProduct p
--     ON p.Id = l.ProductId
-- LEFT JOIN tmscrq.TMContactResource cr
--     ON cr.Id = l.ContactResourceId
-- LEFT JOIN dbo.KUser sp
--     ON sp.Id = l.SalesPersonKUserId
-- LEFT JOIN tmscrq.TMStore st
--     ON st.Id = l.StoreId
-- LEFT JOIN tmscrq.TMLeadProcess lp
--     ON lp.Id = l.ProcessID
-- LEFT JOIN tmscrq.TMLeadNextStep ns
--     ON ns.Id = l.NextStepId

-- WHERE
-- (
--     EXISTS
--     (
--         SELECT 1
--         FROM dbo.KUserRole ur
--         INNER JOIN dbo.KRole r
--             ON r.Id = ur.KRole_Id
--         WHERE ur.KUser_Id = @UserId
--           AND ur.IsDeleted = 0
--           AND r.IsDeleted = 0
--           AND r.Name IN ('TimesYonetici', 'TimesUstYonetici')
--     )
--     OR
--     (
--         EXISTS
--         (
--             SELECT 1
--             FROM dbo.KUserRole ur
--             INNER JOIN dbo.KRole r
--                 ON r.Id = ur.KRole_Id
--             WHERE ur.KUser_Id = @UserId
--               AND ur.IsDeleted = 0
--               AND r.IsDeleted = 0
--               AND r.Name IN ('TimesMagazaMuduru', 'TimesSatisPersoneli')
--         )
--         AND EXISTS
--         (
--             SELECT 1
--             FROM tmscrq.TMUser tu
--             WHERE tu.KUserID = @UserId
--               AND tu.StoreId = l.StoreId
--         )
--     )
-- )

-- AND
-- (
--     @MusteriAdi IS NULL
--     OR LTRIM(RTRIM(@MusteriAdi)) = ''
--     OR UPPER(LTRIM(RTRIM(ISNULL(cu.Name,'') + ' ' + ISNULL(cu.LastName,''))))
--        LIKE '%' + UPPER(LTRIM(RTRIM(@MusteriAdi))) + '%'
-- )

-- AND
-- (
--     @ProductName IS NULL
--     OR LTRIM(RTRIM(@ProductName)) = ''
--     OR
--     (
--         CHARINDEX(',', @ProductName) > 0
--         AND ISNULL(LTRIM(RTRIM(p.ProductName)), '') IN
--         (
--             SELECT LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', '')))
--             FROM STRING_SPLIT(CAST(@ProductName AS NVARCHAR(MAX)), ',')
--             WHERE LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', ''))) <> ''
--         )
--     )
--     OR
--     (
--         CHARINDEX(',', @ProductName) = 0
--         AND UPPER(ISNULL(LTRIM(RTRIM(p.ProductName)), ''))
--             LIKE '%' + UPPER(LTRIM(RTRIM(@ProductName))) + '%'
--     )
-- )

-- AND
-- (
--     @LeadCode IS NULL
--     OR LTRIM(RTRIM(@LeadCode)) = ''
--     OR UPPER(ISNULL(LTRIM(RTRIM(l.LeadCode)), '')) LIKE '%' + UPPER(LTRIM(RTRIM(@LeadCode))) + '%'
-- )

-- AND
-- (
--     @Tel IS NULL
--     OR LTRIM(RTRIM(@Tel)) = ''
--     OR UPPER(ISNULL(LTRIM(RTRIM(cu.Tel)), '')) LIKE '%' + UPPER(LTRIM(RTRIM(@Tel))) + '%'
-- )

-- AND
-- (
--     @CategoryName IS NULL
--     OR LTRIM(RTRIM(@CategoryName)) = ''
--     OR UPPER(ISNULL(LTRIM(RTRIM(p.CategoryName)), '')) IN
--     (
--         SELECT UPPER(LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value,'""',''),'[',''),']',''))))
--         FROM STRING_SPLIT(CAST(@CategoryName AS NVARCHAR(MAX)), ',')
--         WHERE LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value,'""',''),'[',''),']',''))) <> ''
--     )
-- )

-- AND
-- (
--     @StoreIds IS NULL
--     OR LTRIM(RTRIM(@StoreIds)) = ''
--     OR EXISTS
--     (
--         SELECT 1
--         FROM STRING_SPLIT(CAST(@StoreIds AS NVARCHAR(MAX)), ',') s
--         WHERE l.StoreId = TRY_CONVERT
--         (
--             uniqueidentifier,
--             LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(s.value, '""', ''), '[', ''), ']', '')))
--         )
--     )
-- )

-- AND
-- (
--     @SatisDanismaniIds IS NULL
--     OR LTRIM(RTRIM(@SatisDanismaniIds)) = ''
--     OR EXISTS
--     (
--         SELECT 1
--         FROM STRING_SPLIT(CAST(@SatisDanismaniIds AS NVARCHAR(MAX)), ',') s
--         WHERE l.SalesPersonKUserId = TRY_CONVERT
--         (
--             uniqueidentifier,
--             LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(s.value, '""', ''), '[', ''), ']', '')))
--         )
--     )
-- )

-- AND
-- (
--     @ProcessCode IS NULL
--     OR LTRIM(RTRIM(@ProcessCode)) = ''
--     OR UPPER(ISNULL(LTRIM(RTRIM(lp.Code)), '')) IN
--     (
--         SELECT UPPER(LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', ''))))
--         FROM STRING_SPLIT(CAST(@ProcessCode AS NVARCHAR(MAX)), ',')
--         WHERE LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', ''))) <> ''
--     )
-- )

-- -- DÜZELTİLEN ALAN: @StepOrder Filtresi (tek blok)
-- AND
-- (
--     @StepOrder IS NULL

--     OR

--     (
--         @StepOrder = 10
--         AND EXISTS
--         (
--             SELECT 1
--             FROM tmscrq.TMLeadReservation r
--             WHERE r.LeadId = l.Id
--               AND r.IsActive = 1
--               AND ISNULL(r.IsApproved,0) = 0
--         )
--     )

--     OR

--     (
--         @StepOrder <> 10
--         AND lp.StepOrder = @StepOrder
--     )
-- )

-- AND
-- (
--     @StartDate IS NULL
--     OR LTRIM(RTRIM(@StartDate)) = ''
--     OR l.CreatedAt >= CONVERT(date, @StartDate)
-- )

-- AND
-- (
--     @EndDate IS NULL
--     OR LTRIM(RTRIM(@EndDate)) = ''
--     OR l.CreatedAt < DATEADD(day, 1, CONVERT(date, @EndDate))
-- )

-- ORDER BY l.CreatedAt DESC;



SET LANGUAGE Turkish;

SELECT
CASE 
    WHEN EXISTS (
        SELECT 1 
        FROM tmscrq.TMLeadReservation r
        WHERE r.LeadId = l.Id
          AND r.IsActive = 1
          AND r.IsApproved = 1
    ) THEN N'Evet'

    WHEN EXISTS (
        SELECT 1 
        FROM tmscrq.TMLeadReservation r
        WHERE r.LeadId = l.Id
          AND r.IsActive = 1
          AND ISNULL(r.IsApproved,0) = 0
    ) THEN N'Onay Bekliyor'

    ELSE N'Hayır'
END AS RezerveDurumu,
    l.Id AS LeadId,
    l.IsReserved,
    ISNULL(NULLIF(LTRIM(RTRIM(l.LeadCode)), ''), '-') AS LeadNumarasi,
     FORMAT(l.CreatedAt, 'dd MMMM yyyy', 'tr-TR') AS TalepTarihi,

    p.Id AS ProductId,
    ISNULL(NULLIF(LTRIM(RTRIM(p.ProductName)), ''), '-') AS ProductName,
    ISNULL(NULLIF(LTRIM(RTRIM(p.Bracelet)), ''), '-') AS Bilezik,
    ISNULL(NULLIF(LTRIM(RTRIM(p.Brand)), ''), '-') AS Brand,
    ISNULL(NULLIF(LTRIM(RTRIM(p.Dial)), ''), '-') AS Kadran,
    ISNULL(NULLIF(LTRIM(RTRIM(p.ProductCode)), ''), '-') AS RefCode,
    ISNULL(NULLIF(LTRIM(RTRIM(p.Referance)), ''), '-') AS Referans,

    ISNULL(
        NULLIF(
            LTRIM(RTRIM(ISNULL(cu.Name, '') + ' ' + ISNULL(cu.LastName, '')))
        , '')
    , '-') AS Musteri,

    ISNULL(NULLIF(LTRIM(RTRIM(cu.CityName)), ''), '-') AS Lokasyon,
    ISNULL(NULLIF(LTRIM(RTRIM(cu.DistrictName)), ''), '-') AS Ilce,
    ISNULL(NULLIF(LTRIM(RTRIM(cu.CountryName)), ''), '-') AS Ulke,
    ISNULL(NULLIF(LTRIM(RTRIM(cu.Info)), ''), '-') AS MusteriInfo,

    CASE
        WHEN cu.IsShopping = 1 THEN N'Evet'
        WHEN cu.IsShopping = 0 THEN N'Hayır'
        ELSE '-'
    END AS AlisverisiVarMi,

    ISNULL(NULLIF(LTRIM(RTRIM(cu.Tel)), ''), '-') AS IrtibatNumarasi,
    ISNULL(NULLIF(LTRIM(RTRIM(cu.Email)), ''), '-') AS EmailAdresi,

    ISNULL(NULLIF(LTRIM(RTRIM(cr.ContactResourceName)), ''), '-') AS IletisimKaynagi,

    ISNULL(NULLIF(LTRIM(RTRIM(p.CategoryName)), ''), '-') AS CategoryName,
    '-' AS CategoryCode,

    ISNULL(NULLIF(LTRIM(RTRIM(ls.Name)), ''), '-') AS LeadDurumu,
    ISNULL(NULLIF(LTRIM(RTRIM(ns.Name)), ''), '-') AS SonrakiAdim,

    ISNULL(NULLIF(LTRIM(RTRIM(lp.Name)), ''), '-') AS ProcessName,
    ISNULL(NULLIF(LTRIM(RTRIM(lp.Code)), ''), '-') AS ProcessCode,
    lp.StepOrder,
    
    -- DÜZELTİLEN ALAN: SelectedStepOrder
    CASE
        WHEN EXISTS
        (
            SELECT 1
            FROM tmscrq.TMLeadReservation r
            WHERE r.LeadId = l.Id
              AND r.IsActive = 1
              AND ISNULL(r.IsApproved,0) = 0
        )
        THEN 10
        ELSE lp.StepOrder
    END AS SelectedStepOrder,

    ISNULL(
        CASE
            WHEN l.EstimatedDate IS NOT NULL
            THEN CAST(YEAR(l.EstimatedDate) AS VARCHAR(4)) + ' ' + DATENAME(MONTH, l.EstimatedDate)
            ELSE NULL
        END,
        '-'
    ) AS TerminTarihi,

    ISNULL(
        NULLIF(
            LTRIM(RTRIM(ISNULL(sp.FirstName, '') + ' ' + ISNULL(sp.LastName, '')))
        , '')
    , '-') AS SatisDanismani,

    ISNULL(NULLIF(LTRIM(RTRIM(st.StoreDesc)), ''), '-') AS StoreName

FROM tmscrq.TMLead l
LEFT JOIN tmscrq.TMLeadStatu ls
    ON ls.Id = l.StatuId
LEFT JOIN tmscrq.TMCustomer cu
    ON cu.Id = l.CustomerId
LEFT JOIN tmscrq.TMProduct p
    ON p.Id = l.ProductId
LEFT JOIN tmscrq.TMContactResource cr
    ON cr.Id = l.ContactResourceId
LEFT JOIN dbo.KUser sp
    ON sp.Id = l.SalesPersonKUserId
LEFT JOIN tmscrq.TMStore st
    ON st.Id = l.StoreId
LEFT JOIN tmscrq.TMLeadProcess lp
    ON lp.Id = l.ProcessID
LEFT JOIN tmscrq.TMLeadNextStep ns
    ON ns.Id = l.NextStepId

WHERE
(
    EXISTS
    (
        SELECT 1
        FROM dbo.KUserRole ur
        INNER JOIN dbo.KRole r
            ON r.Id = ur.KRole_Id
        WHERE ur.KUser_Id = @UserId
          AND ur.IsDeleted = 0
          AND r.IsDeleted = 0
          AND r.Name IN ('TimesYonetici', 'TimesUstYonetici')
    )
    OR
    (
        EXISTS
        (
            SELECT 1
            FROM dbo.KUserRole ur
            INNER JOIN dbo.KRole r
                ON r.Id = ur.KRole_Id
            WHERE ur.KUser_Id = @UserId
              AND ur.IsDeleted = 0
              AND r.IsDeleted = 0
              AND r.Name IN ('TimesMagazaMuduru', 'TimesSatisPersoneli')
        )
        AND EXISTS
        (
            SELECT 1
            FROM tmscrq.TMUser tu
            WHERE tu.KUserID = @UserId
              AND tu.StoreId = l.StoreId
        )
    )
)

AND
(
    ISNULL(@MusteriAdi, '') = ''
    OR UPPER(ISNULL(cu.Name, '')) LIKE '%' + UPPER(LTRIM(RTRIM(@MusteriAdi))) + '%'
    OR UPPER(ISNULL(cu.LastName, '')) LIKE '%' + UPPER(LTRIM(RTRIM(@MusteriAdi))) + '%'
    OR UPPER(
        ISNULL(cu.Name, '') + ' ' + ISNULL(cu.LastName, '')
    ) LIKE '%' + UPPER(LTRIM(RTRIM(@MusteriAdi))) + '%'
)

AND
(
    @ProductName IS NULL
    OR LTRIM(RTRIM(@ProductName)) = ''
    OR
    (
        CHARINDEX(',', @ProductName) > 0
        AND ISNULL(LTRIM(RTRIM(p.ProductName)), '') IN
        (
            SELECT LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', '')))
            FROM STRING_SPLIT(CAST(@ProductName AS NVARCHAR(MAX)), ',')
            WHERE LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', ''))) <> ''
        )
    )
    OR
    (
        CHARINDEX(',', @ProductName) = 0
        AND UPPER(ISNULL(LTRIM(RTRIM(p.ProductName)), ''))
            LIKE '%' + UPPER(LTRIM(RTRIM(@ProductName))) + '%'
    )
)

AND
(
    ISNULL(@LeadCode, '') = ''
    OR UPPER(ISNULL(l.LeadCode, ''))
        LIKE '%' + UPPER(LTRIM(RTRIM(@LeadCode))) + '%'
    OR REPLACE(
        REPLACE(
            REPLACE(
                UPPER(ISNULL(l.LeadCode, '')),
                '-', ''
            ),
            ' ', ''
        ),
        '/', ''
    )
    LIKE '%' +
    REPLACE(
        REPLACE(
            REPLACE(
                UPPER(LTRIM(RTRIM(@LeadCode))),
                '-', ''
            ),
            ' ', ''
        ),
        '/', ''
    )
    + '%'
)

AND
(
    @Tel IS NULL
    OR LTRIM(RTRIM(@Tel)) = ''
    OR UPPER(ISNULL(LTRIM(RTRIM(cu.Tel)), '')) LIKE '%' + UPPER(LTRIM(RTRIM(@Tel))) + '%'
)

AND
(
    @CategoryName IS NULL
    OR LTRIM(RTRIM(@CategoryName)) = ''
    OR UPPER(ISNULL(LTRIM(RTRIM(p.CategoryName)), '')) IN
    (
        SELECT UPPER(LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value,'""',''),'[',''),']',''))))
        FROM STRING_SPLIT(CAST(@CategoryName AS NVARCHAR(MAX)), ',')
        WHERE LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value,'""',''),'[',''),']',''))) <> ''
    )
)

AND
(
    @StoreIds IS NULL
    OR LTRIM(RTRIM(@StoreIds)) = ''
    OR EXISTS
    (
        SELECT 1
        FROM STRING_SPLIT(CAST(@StoreIds AS NVARCHAR(MAX)), ',') s
        WHERE l.StoreId = TRY_CONVERT
        (
            uniqueidentifier,
            LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(s.value, '""', ''), '[', ''), ']', '')))
        )
    )
)

AND
(
    @SatisDanismaniIds IS NULL
    OR LTRIM(RTRIM(@SatisDanismaniIds)) = ''
    OR EXISTS
    (
        SELECT 1
        FROM STRING_SPLIT(CAST(@SatisDanismaniIds AS NVARCHAR(MAX)), ',') s
        WHERE l.SalesPersonKUserId = TRY_CONVERT
        (
            uniqueidentifier,
            LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(s.value, '""', ''), '[', ''), ']', '')))
        )
    )
)

AND
(
    ISNULL(@ProcessCode, '') = ''
    OR EXISTS
    (
        SELECT 1
        FROM STRING_SPLIT(
            CONVERT(NVARCHAR(MAX), @ProcessCode),
            ','
        ) AS s
        WHERE
            UPPER(LTRIM(RTRIM(s.value))) =
            UPPER(LTRIM(RTRIM(ISNULL(lp.Code, ''))))
    )
)

-- DÜZELTİLEN ALAN: @StepOrder Filtresi (0 verilince tümü gelsin)
AND
(
    @StepOrder IS NULL
    OR @StepOrder = 0  -- 👈 YENİ EKLENDI: 0 verilince tüm kayıtlar gelir
    OR
    (
        @StepOrder = 10
        AND EXISTS
        (
            SELECT 1
            FROM tmscrq.TMLeadReservation r
            WHERE r.LeadId = l.Id
              AND r.IsActive = 1
              AND ISNULL(r.IsApproved,0) = 0
        )
    )
    OR
    (
        @StepOrder <> 10
        AND lp.StepOrder = @StepOrder
    )
)

AND
(
    @StartDate IS NULL
    OR LTRIM(RTRIM(@StartDate)) = ''
    OR l.CreatedAt >= CONVERT(date, @StartDate)
)

AND
(
    @EndDate IS NULL
    OR LTRIM(RTRIM(@EndDate)) = ''
    OR l.CreatedAt < DATEADD(day, 1, CONVERT(date, @EndDate))
)

ORDER BY l.CreatedAt DESC;", new string[] { "RezerveDurumu", "LeadId", "IsReserved", "LeadNumarasi", "TalepTarihi", "ProductId", "ProductName", "Bilezik", "Brand", "Kadran", "RefCode", "Referans", "Musteri", "Lokasyon", "Ilce", "Ulke", "MusteriInfo", "AlisverisiVarMi", "IrtibatNumarasi", "EmailAdresi", "IletisimKaynagi", "CategoryName", "CategoryCode", "LeadDurumu", "SonrakiAdim", "ProcessName", "ProcessCode", "StepOrder", "SelectedStepOrder", "TerminTarihi", "SatisDanismani", "StoreName" }, prms_TM_GetLeads_0.ToArray());
            ;


            return Ok(result);
        }


        [HttpPost, Route("LeadListComponent_634059_onClick")]
        public IActionResult LeadListComponent_634059_onClick(LeadListComponent_634059_onClick_Request request)
        {

            KProviderManager.Authorization.IsAuthorizedForRoles(appId, appName, screenId, screenName, new List<string> { $"70de6cfc-6087-6059-59b4-0b5a8527af6b", "4da1f213-c8e4-0b50-5c84-02fd13f1a622", "c4e882ef-977d-f613-7694-230ac83919d2", "b4bfd39c-ac02-f442-c899-7a2374a45b47", "cdb536b0-6297-155f-d446-8453d8a60304", "TimesYonetici", "TimesUstYonetici", "TimesSatisPersoneli", "TimesMagazaMuduru", "TimesAdmin" });

            var result = new LeadListComponent_634059_onClick_Response();

            var prms_TM_GetLeads_0 = new List<kSqlParameter>();
            prms_TM_GetLeads_0.Add(new kSqlParameter() { Name = "StepOrder", Value = "7".ConvertToType<Int32>() });
            prms_TM_GetLeads_0.Add(new kSqlParameter() { Name = "UserId", Value = Kuika.Common.KContext.CurrentUser?.Id });
            prms_TM_GetLeads_0.Add(new kSqlParameter() { Name = "MusteriAdi", Value = request.MusteriAdi_0 });
            prms_TM_GetLeads_0.Add(new kSqlParameter() { Name = "ProductName", Value = request.ProductName_0 });
            prms_TM_GetLeads_0.Add(new kSqlParameter() { Name = "LeadCode", Value = request.LeadCode_0 });
            prms_TM_GetLeads_0.Add(new kSqlParameter() { Name = "Tel", Value = request.Tel_0 });
            prms_TM_GetLeads_0.Add(new kSqlParameter() { Name = "CategoryName", Value = request.CategoryName_0 });
            prms_TM_GetLeads_0.Add(new kSqlParameter() { Name = "StoreIds", Value = request.StoreIds_0 });
            prms_TM_GetLeads_0.Add(new kSqlParameter() { Name = "SatisDanismaniIds", Value = request.SatisDanismaniIds_0 });
            prms_TM_GetLeads_0.Add(new kSqlParameter() { Name = "ProcessCode", Value = request.ProcessCode_0 });
            prms_TM_GetLeads_0.Add(new kSqlParameter() { Name = "StartDate", Value = request.StartDate_0 });
            prms_TM_GetLeads_0.Add(new kSqlParameter() { Name = "EndDate", Value = request.EndDate_0 });
            using var auditTM_GetLeads_0 = ActionAuditScope.Begin("cef2a1d8-d37c-06ac-a3f6-c4c31cffbcbe", "TM_GetLeads", applicationName: "wbTimesCRM", screenOrEndpointName: "LeadList");
            result.TM_GetLeads = KPersister.Fetch(KContext.GetConnectionString(), @"-- SET LANGUAGE Turkish;

-- SELECT
-- CASE 
--     WHEN EXISTS (
--         SELECT 1 
--         FROM tmscrq.TMLeadReservation r
--         WHERE r.LeadId = l.Id
--           AND r.IsActive = 1
--           AND r.IsApproved = 1
--     ) THEN N'Evet'

--     WHEN EXISTS (
--         SELECT 1 
--         FROM tmscrq.TMLeadReservation r
--         WHERE r.LeadId = l.Id
--           AND r.IsActive = 1
--           AND ISNULL(r.IsApproved,0) = 0
--     ) THEN N'Onay Bekliyor'

--     ELSE N'Hayır'
-- END AS RezerveDurumu,
--     l.Id AS LeadId,
--     l.IsReserved,
--     ISNULL(NULLIF(LTRIM(RTRIM(l.LeadCode)), ''), '-') AS LeadNumarasi,
--     CONVERT(varchar(10), l.CreatedAt, 103) AS TalepTarihi,

--     p.Id AS ProductId,
--     ISNULL(NULLIF(LTRIM(RTRIM(p.ProductName)), ''), '-') AS ProductName,
--     ISNULL(NULLIF(LTRIM(RTRIM(p.Bracelet)), ''), '-') AS Bilezik,
--     ISNULL(NULLIF(LTRIM(RTRIM(p.Brand)), ''), '-') AS Brand,
--     ISNULL(NULLIF(LTRIM(RTRIM(p.Dial)), ''), '-') AS Kadran,
--     ISNULL(NULLIF(LTRIM(RTRIM(p.ProductCode)), ''), '-') AS RefCode,
--     ISNULL(NULLIF(LTRIM(RTRIM(p.Referance)), ''), '-') AS Referans,

--     ISNULL(
--         NULLIF(
--             LTRIM(RTRIM(ISNULL(cu.Name, '') + ' ' + ISNULL(cu.LastName, '')))
--         , '')
--     , '-') AS Musteri,

--     ISNULL(NULLIF(LTRIM(RTRIM(cu.CityName)), ''), '-') AS Lokasyon,
--     ISNULL(NULLIF(LTRIM(RTRIM(cu.DistrictName)), ''), '-') AS Ilce,
--     ISNULL(NULLIF(LTRIM(RTRIM(cu.CountryName)), ''), '-') AS Ulke,
--     ISNULL(NULLIF(LTRIM(RTRIM(cu.Info)), ''), '-') AS MusteriInfo,

--     CASE
--         WHEN cu.IsShopping = 1 THEN N'Evet'
--         WHEN cu.IsShopping = 0 THEN N'Hayır'
--         ELSE '-'
--     END AS AlisverisiVarMi,

--     ISNULL(NULLIF(LTRIM(RTRIM(cu.Tel)), ''), '-') AS IrtibatNumarasi,
--     ISNULL(NULLIF(LTRIM(RTRIM(cu.Email)), ''), '-') AS EmailAdresi,

--     ISNULL(NULLIF(LTRIM(RTRIM(cr.ContactResourceName)), ''), '-') AS IletisimKaynagi,

--     ISNULL(NULLIF(LTRIM(RTRIM(p.CategoryName)), ''), '-') AS CategoryName,
--     '-' AS CategoryCode,

--     ISNULL(NULLIF(LTRIM(RTRIM(ls.Name)), ''), '-') AS LeadDurumu,
--     ISNULL(NULLIF(LTRIM(RTRIM(ns.Name)), ''), '-') AS SonrakiAdim,

--     ISNULL(NULLIF(LTRIM(RTRIM(lp.Name)), ''), '-') AS ProcessName,
--     ISNULL(NULLIF(LTRIM(RTRIM(lp.Code)), ''), '-') AS ProcessCode,
--     lp.StepOrder,
-- CASE
--     WHEN EXISTS
--     (
--         SELECT 1
--         FROM tmscrq.TMLeadReservation r
--         WHERE r.LeadId = l.Id
--           AND r.IsActive = 1
--           AND ISNULL(r.IsApproved,0) = 0
--     )
--     THEN 10
--     ELSE lp.StepOrder
-- END AS SelectedStepOrder,

--     ISNULL(
--         CASE
--             WHEN l.EstimatedDate IS NOT NULL
--             THEN CAST(YEAR(l.EstimatedDate) AS VARCHAR(4)) + ' ' + DATENAME(MONTH, l.EstimatedDate)
--             ELSE NULL
--         END,
--         '-'
--     ) AS TerminTarihi,

--     ISNULL(
--         NULLIF(
--             LTRIM(RTRIM(ISNULL(sp.FirstName, '') + ' ' + ISNULL(sp.LastName, '')))
--         , '')
--     , '-') AS SatisDanismani,

--     ISNULL(NULLIF(LTRIM(RTRIM(st.StoreDesc)), ''), '-') AS StoreName

-- FROM tmscrq.TMLead l
-- LEFT JOIN tmscrq.TMLeadStatu ls
--     ON ls.Id = l.StatuId
-- LEFT JOIN tmscrq.TMCustomer cu
--     ON cu.Id = l.CustomerId
-- LEFT JOIN tmscrq.TMProduct p
--     ON p.Id = l.ProductId
-- LEFT JOIN tmscrq.TMContactResource cr
--     ON cr.Id = l.ContactResourceId
-- LEFT JOIN dbo.KUser sp
--     ON sp.Id = l.SalesPersonKUserId
-- LEFT JOIN tmscrq.TMStore st
--     ON st.Id = l.StoreId
-- LEFT JOIN tmscrq.TMLeadProcess lp
--     ON lp.Id = l.ProcessID
-- LEFT JOIN tmscrq.TMLeadNextStep ns
--     ON ns.Id = l.NextStepId

-- WHERE
-- (
--     EXISTS
--     (
--         SELECT 1
--         FROM dbo.KUserRole ur
--         INNER JOIN dbo.KRole r
--             ON r.Id = ur.KRole_Id
--         WHERE ur.KUser_Id = @UserId
--           AND ur.IsDeleted = 0
--           AND r.IsDeleted = 0
--           AND r.Name IN ('TimesYonetici', 'TimesUstYonetici')
--     )
--     OR
--     (
--         EXISTS
--         (
--             SELECT 1
--             FROM dbo.KUserRole ur
--             INNER JOIN dbo.KRole r
--                 ON r.Id = ur.KRole_Id
--             WHERE ur.KUser_Id = @UserId
--               AND ur.IsDeleted = 0
--               AND r.IsDeleted = 0
--               AND r.Name IN ('TimesMagazaMuduru', 'TimesSatisPersoneli')
--         )
--         AND EXISTS
--         (
--             SELECT 1
--             FROM tmscrq.TMUser tu
--             WHERE tu.KUserID = @UserId
--               AND tu.StoreId = l.StoreId
--         )
--     )
-- )

-- AND
-- (
--     @MusteriAdi IS NULL
--     OR LTRIM(RTRIM(@MusteriAdi)) = ''
--     OR UPPER(LTRIM(RTRIM(ISNULL(cu.Name,'') + ' ' + ISNULL(cu.LastName,''))))
--        LIKE '%' + UPPER(LTRIM(RTRIM(@MusteriAdi))) + '%'
-- )

-- AND
-- (
--     @ProductName IS NULL
--     OR LTRIM(RTRIM(@ProductName)) = ''
--     OR
--     (
--         CHARINDEX(',', @ProductName) > 0
--         AND ISNULL(LTRIM(RTRIM(p.ProductName)), '') IN
--         (
--             SELECT LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', '')))
--             FROM STRING_SPLIT(CAST(@ProductName AS NVARCHAR(MAX)), ',')
--             WHERE LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', ''))) <> ''
--         )
--     )
--     OR
--     (
--         CHARINDEX(',', @ProductName) = 0
--         AND UPPER(ISNULL(LTRIM(RTRIM(p.ProductName)), ''))
--             LIKE '%' + UPPER(LTRIM(RTRIM(@ProductName))) + '%'
--     )
-- )

-- AND
-- (
--     @LeadCode IS NULL
--     OR LTRIM(RTRIM(@LeadCode)) = ''
--     OR UPPER(ISNULL(LTRIM(RTRIM(l.LeadCode)), '')) LIKE '%' + UPPER(LTRIM(RTRIM(@LeadCode))) + '%'
-- )

-- AND
-- (
--     @Tel IS NULL
--     OR LTRIM(RTRIM(@Tel)) = ''
--     OR UPPER(ISNULL(LTRIM(RTRIM(cu.Tel)), '')) LIKE '%' + UPPER(LTRIM(RTRIM(@Tel))) + '%'
-- )

-- -- AND
-- -- (
-- --     @CategoryName IS NULL
-- --     OR LTRIM(RTRIM(@CategoryName)) = ''
-- --     OR
-- --     (
-- --         EXISTS
-- --         (
-- --             SELECT 1
-- --             FROM STRING_SPLIT(CAST(@CategoryName AS NVARCHAR(MAX)), ',') c
-- --             WHERE UPPER(LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(c.value, '""', ''), '[', ''), ']', '')))) = 'DEFAULT'
-- --         )
-- --         AND (p.CategoryName IS NULL OR LTRIM(RTRIM(p.CategoryName)) = '')
-- --     )
-- --     OR UPPER(ISNULL(LTRIM(RTRIM(p.CategoryName)), '')) IN
-- --     (
-- --         SELECT UPPER(LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', ''))))
-- --         FROM STRING_SPLIT(CAST(@CategoryName AS NVARCHAR(MAX)), ',')
-- --         WHERE LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', ''))) <> ''
-- --           AND UPPER(LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', '')))) <> 'DEFAULT'
-- --     )
-- -- )

-- AND
-- (
--     @CategoryName IS NULL
--     OR LTRIM(RTRIM(@CategoryName)) = ''
--     OR UPPER(ISNULL(LTRIM(RTRIM(p.CategoryName)), '')) IN
--     (
--         SELECT UPPER(LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value,'""',''),'[',''),']',''))))
--         FROM STRING_SPLIT(CAST(@CategoryName AS NVARCHAR(MAX)), ',')
--         WHERE LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value,'""',''),'[',''),']',''))) <> ''
--     )
-- )

-- AND
-- (
--     @StoreIds IS NULL
--     OR LTRIM(RTRIM(@StoreIds)) = ''
--     OR EXISTS
--     (
--         SELECT 1
--         FROM STRING_SPLIT(CAST(@StoreIds AS NVARCHAR(MAX)), ',') s
--         WHERE l.StoreId = TRY_CONVERT
--         (
--             uniqueidentifier,
--             LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(s.value, '""', ''), '[', ''), ']', '')))
--         )
--     )
-- )

-- AND
-- (
--     @SatisDanismaniIds IS NULL
--     OR LTRIM(RTRIM(@SatisDanismaniIds)) = ''
--     OR EXISTS
--     (
--         SELECT 1
--         FROM STRING_SPLIT(CAST(@SatisDanismaniIds AS NVARCHAR(MAX)), ',') s
--         WHERE l.SalesPersonKUserId = TRY_CONVERT
--         (
--             uniqueidentifier,
--             LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(s.value, '""', ''), '[', ''), ']', '')))
--         )
--     )
-- )

-- AND
-- (
--     @ProcessCode IS NULL
--     OR LTRIM(RTRIM(@ProcessCode)) = ''
--     OR UPPER(ISNULL(LTRIM(RTRIM(lp.Code)), '')) IN
--     (
--         SELECT UPPER(LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', ''))))
--         FROM STRING_SPLIT(CAST(@ProcessCode AS NVARCHAR(MAX)), ',')
--         WHERE LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', ''))) <> ''
--     )
-- )

-- AND
-- (
--     @StepOrder IS NULL

--     OR
--     (
--         @StepOrder = 10
--         AND EXISTS
--         (
--             SELECT 1
--             FROM tmscrq.TMLeadReservation r
--             WHERE r.LeadId = l.Id
--               AND r.IsActive = 1
--               AND ISNULL(r.IsApproved,0) = 0
--         )
--     )

--     OR
--     (
--         @StepOrder <> 10
--         AND lp.StepOrder = @StepOrder
--     )
-- )

-- AND
-- (
--     @StartDate IS NULL
--     OR LTRIM(RTRIM(@StartDate)) = ''
--     OR l.CreatedAt >= CONVERT(date, @StartDate)
-- )

-- AND
-- (
--     @EndDate IS NULL
--     OR LTRIM(RTRIM(@EndDate)) = ''
--     OR l.CreatedAt < DATEADD(day, 1, CONVERT(date, @EndDate))
-- )

-- ORDER BY l.CreatedAt DESC;

------------------------++++++++++++++++++++++++-------------------
-- SET LANGUAGE Turkish;

-- SELECT
-- CASE 
--     WHEN EXISTS (
--         SELECT 1 
--         FROM tmscrq.TMLeadReservation r
--         WHERE r.LeadId = l.Id
--           AND r.IsActive = 1
--           AND r.IsApproved = 1
--     ) THEN N'Evet'

--     WHEN EXISTS (
--         SELECT 1 
--         FROM tmscrq.TMLeadReservation r
--         WHERE r.LeadId = l.Id
--           AND r.IsActive = 1
--           AND ISNULL(r.IsApproved,0) = 0
--     ) THEN N'Onay Bekliyor'

--     ELSE N'Hayır'
-- END AS RezerveDurumu,
--     l.Id AS LeadId,
--     l.IsReserved,
--     ISNULL(NULLIF(LTRIM(RTRIM(l.LeadCode)), ''), '-') AS LeadNumarasi,
--     CONVERT(varchar(10), l.CreatedAt, 103) AS TalepTarihi,

--     p.Id AS ProductId,
--     ISNULL(NULLIF(LTRIM(RTRIM(p.ProductName)), ''), '-') AS ProductName,
--     ISNULL(NULLIF(LTRIM(RTRIM(p.Bracelet)), ''), '-') AS Bilezik,
--     ISNULL(NULLIF(LTRIM(RTRIM(p.Brand)), ''), '-') AS Brand,
--     ISNULL(NULLIF(LTRIM(RTRIM(p.Dial)), ''), '-') AS Kadran,
--     ISNULL(NULLIF(LTRIM(RTRIM(p.ProductCode)), ''), '-') AS RefCode,
--     ISNULL(NULLIF(LTRIM(RTRIM(p.Referance)), ''), '-') AS Referans,

--     ISNULL(
--         NULLIF(
--             LTRIM(RTRIM(ISNULL(cu.Name, '') + ' ' + ISNULL(cu.LastName, '')))
--         , '')
--     , '-') AS Musteri,

--     ISNULL(NULLIF(LTRIM(RTRIM(cu.CityName)), ''), '-') AS Lokasyon,
--     ISNULL(NULLIF(LTRIM(RTRIM(cu.DistrictName)), ''), '-') AS Ilce,
--     ISNULL(NULLIF(LTRIM(RTRIM(cu.CountryName)), ''), '-') AS Ulke,
--     ISNULL(NULLIF(LTRIM(RTRIM(cu.Info)), ''), '-') AS MusteriInfo,

--     CASE
--         WHEN cu.IsShopping = 1 THEN N'Evet'
--         WHEN cu.IsShopping = 0 THEN N'Hayır'
--         ELSE '-'
--     END AS AlisverisiVarMi,

--     ISNULL(NULLIF(LTRIM(RTRIM(cu.Tel)), ''), '-') AS IrtibatNumarasi,
--     ISNULL(NULLIF(LTRIM(RTRIM(cu.Email)), ''), '-') AS EmailAdresi,

--     ISNULL(NULLIF(LTRIM(RTRIM(cr.ContactResourceName)), ''), '-') AS IletisimKaynagi,

--     ISNULL(NULLIF(LTRIM(RTRIM(p.CategoryName)), ''), '-') AS CategoryName,
--     '-' AS CategoryCode,

--     ISNULL(NULLIF(LTRIM(RTRIM(ls.Name)), ''), '-') AS LeadDurumu,
--     ISNULL(NULLIF(LTRIM(RTRIM(ns.Name)), ''), '-') AS SonrakiAdim,

--     ISNULL(NULLIF(LTRIM(RTRIM(lp.Name)), ''), '-') AS ProcessName,
--     ISNULL(NULLIF(LTRIM(RTRIM(lp.Code)), ''), '-') AS ProcessCode,
--     lp.StepOrder,
    
--     -- DÜZELTİLEN ALAN: SelectedStepOrder
--     CASE
--         WHEN EXISTS
--         (
--             SELECT 1
--             FROM tmscrq.TMLeadReservation r
--             WHERE r.LeadId = l.Id
--               AND r.IsActive = 1
--               AND ISNULL(r.IsApproved,0) = 0
--         )
--         THEN 10
--         ELSE lp.StepOrder
--     END AS SelectedStepOrder,

--     ISNULL(
--         CASE
--             WHEN l.EstimatedDate IS NOT NULL
--             THEN CAST(YEAR(l.EstimatedDate) AS VARCHAR(4)) + ' ' + DATENAME(MONTH, l.EstimatedDate)
--             ELSE NULL
--         END,
--         '-'
--     ) AS TerminTarihi,

--     ISNULL(
--         NULLIF(
--             LTRIM(RTRIM(ISNULL(sp.FirstName, '') + ' ' + ISNULL(sp.LastName, '')))
--         , '')
--     , '-') AS SatisDanismani,

--     ISNULL(NULLIF(LTRIM(RTRIM(st.StoreDesc)), ''), '-') AS StoreName

-- FROM tmscrq.TMLead l
-- LEFT JOIN tmscrq.TMLeadStatu ls
--     ON ls.Id = l.StatuId
-- LEFT JOIN tmscrq.TMCustomer cu
--     ON cu.Id = l.CustomerId
-- LEFT JOIN tmscrq.TMProduct p
--     ON p.Id = l.ProductId
-- LEFT JOIN tmscrq.TMContactResource cr
--     ON cr.Id = l.ContactResourceId
-- LEFT JOIN dbo.KUser sp
--     ON sp.Id = l.SalesPersonKUserId
-- LEFT JOIN tmscrq.TMStore st
--     ON st.Id = l.StoreId
-- LEFT JOIN tmscrq.TMLeadProcess lp
--     ON lp.Id = l.ProcessID
-- LEFT JOIN tmscrq.TMLeadNextStep ns
--     ON ns.Id = l.NextStepId

-- WHERE
-- (
--     EXISTS
--     (
--         SELECT 1
--         FROM dbo.KUserRole ur
--         INNER JOIN dbo.KRole r
--             ON r.Id = ur.KRole_Id
--         WHERE ur.KUser_Id = @UserId
--           AND ur.IsDeleted = 0
--           AND r.IsDeleted = 0
--           AND r.Name IN ('TimesYonetici', 'TimesUstYonetici')
--     )
--     OR
--     (
--         EXISTS
--         (
--             SELECT 1
--             FROM dbo.KUserRole ur
--             INNER JOIN dbo.KRole r
--                 ON r.Id = ur.KRole_Id
--             WHERE ur.KUser_Id = @UserId
--               AND ur.IsDeleted = 0
--               AND r.IsDeleted = 0
--               AND r.Name IN ('TimesMagazaMuduru', 'TimesSatisPersoneli')
--         )
--         AND EXISTS
--         (
--             SELECT 1
--             FROM tmscrq.TMUser tu
--             WHERE tu.KUserID = @UserId
--               AND tu.StoreId = l.StoreId
--         )
--     )
-- )

-- AND
-- (
--     @MusteriAdi IS NULL
--     OR LTRIM(RTRIM(@MusteriAdi)) = ''
--     OR UPPER(LTRIM(RTRIM(ISNULL(cu.Name,'') + ' ' + ISNULL(cu.LastName,''))))
--        LIKE '%' + UPPER(LTRIM(RTRIM(@MusteriAdi))) + '%'
-- )

-- AND
-- (
--     @ProductName IS NULL
--     OR LTRIM(RTRIM(@ProductName)) = ''
--     OR
--     (
--         CHARINDEX(',', @ProductName) > 0
--         AND ISNULL(LTRIM(RTRIM(p.ProductName)), '') IN
--         (
--             SELECT LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', '')))
--             FROM STRING_SPLIT(CAST(@ProductName AS NVARCHAR(MAX)), ',')
--             WHERE LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', ''))) <> ''
--         )
--     )
--     OR
--     (
--         CHARINDEX(',', @ProductName) = 0
--         AND UPPER(ISNULL(LTRIM(RTRIM(p.ProductName)), ''))
--             LIKE '%' + UPPER(LTRIM(RTRIM(@ProductName))) + '%'
--     )
-- )

-- AND
-- (
--     @LeadCode IS NULL
--     OR LTRIM(RTRIM(@LeadCode)) = ''
--     OR UPPER(ISNULL(LTRIM(RTRIM(l.LeadCode)), '')) LIKE '%' + UPPER(LTRIM(RTRIM(@LeadCode))) + '%'
-- )

-- AND
-- (
--     @Tel IS NULL
--     OR LTRIM(RTRIM(@Tel)) = ''
--     OR UPPER(ISNULL(LTRIM(RTRIM(cu.Tel)), '')) LIKE '%' + UPPER(LTRIM(RTRIM(@Tel))) + '%'
-- )

-- AND
-- (
--     @CategoryName IS NULL
--     OR LTRIM(RTRIM(@CategoryName)) = ''
--     OR UPPER(ISNULL(LTRIM(RTRIM(p.CategoryName)), '')) IN
--     (
--         SELECT UPPER(LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value,'""',''),'[',''),']',''))))
--         FROM STRING_SPLIT(CAST(@CategoryName AS NVARCHAR(MAX)), ',')
--         WHERE LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value,'""',''),'[',''),']',''))) <> ''
--     )
-- )

-- AND
-- (
--     @StoreIds IS NULL
--     OR LTRIM(RTRIM(@StoreIds)) = ''
--     OR EXISTS
--     (
--         SELECT 1
--         FROM STRING_SPLIT(CAST(@StoreIds AS NVARCHAR(MAX)), ',') s
--         WHERE l.StoreId = TRY_CONVERT
--         (
--             uniqueidentifier,
--             LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(s.value, '""', ''), '[', ''), ']', '')))
--         )
--     )
-- )

-- AND
-- (
--     @SatisDanismaniIds IS NULL
--     OR LTRIM(RTRIM(@SatisDanismaniIds)) = ''
--     OR EXISTS
--     (
--         SELECT 1
--         FROM STRING_SPLIT(CAST(@SatisDanismaniIds AS NVARCHAR(MAX)), ',') s
--         WHERE l.SalesPersonKUserId = TRY_CONVERT
--         (
--             uniqueidentifier,
--             LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(s.value, '""', ''), '[', ''), ']', '')))
--         )
--     )
-- )

-- AND
-- (
--     @ProcessCode IS NULL
--     OR LTRIM(RTRIM(@ProcessCode)) = ''
--     OR UPPER(ISNULL(LTRIM(RTRIM(lp.Code)), '')) IN
--     (
--         SELECT UPPER(LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', ''))))
--         FROM STRING_SPLIT(CAST(@ProcessCode AS NVARCHAR(MAX)), ',')
--         WHERE LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', ''))) <> ''
--     )
-- )

-- -- DÜZELTİLEN ALAN: @StepOrder Filtresi (tek blok)
-- AND
-- (
--     @StepOrder IS NULL

--     OR

--     (
--         @StepOrder = 10
--         AND EXISTS
--         (
--             SELECT 1
--             FROM tmscrq.TMLeadReservation r
--             WHERE r.LeadId = l.Id
--               AND r.IsActive = 1
--               AND ISNULL(r.IsApproved,0) = 0
--         )
--     )

--     OR

--     (
--         @StepOrder <> 10
--         AND lp.StepOrder = @StepOrder
--     )
-- )

-- AND
-- (
--     @StartDate IS NULL
--     OR LTRIM(RTRIM(@StartDate)) = ''
--     OR l.CreatedAt >= CONVERT(date, @StartDate)
-- )

-- AND
-- (
--     @EndDate IS NULL
--     OR LTRIM(RTRIM(@EndDate)) = ''
--     OR l.CreatedAt < DATEADD(day, 1, CONVERT(date, @EndDate))
-- )

-- ORDER BY l.CreatedAt DESC;



SET LANGUAGE Turkish;

SELECT
CASE 
    WHEN EXISTS (
        SELECT 1 
        FROM tmscrq.TMLeadReservation r
        WHERE r.LeadId = l.Id
          AND r.IsActive = 1
          AND r.IsApproved = 1
    ) THEN N'Evet'

    WHEN EXISTS (
        SELECT 1 
        FROM tmscrq.TMLeadReservation r
        WHERE r.LeadId = l.Id
          AND r.IsActive = 1
          AND ISNULL(r.IsApproved,0) = 0
    ) THEN N'Onay Bekliyor'

    ELSE N'Hayır'
END AS RezerveDurumu,
    l.Id AS LeadId,
    l.IsReserved,
    ISNULL(NULLIF(LTRIM(RTRIM(l.LeadCode)), ''), '-') AS LeadNumarasi,
     FORMAT(l.CreatedAt, 'dd MMMM yyyy', 'tr-TR') AS TalepTarihi,

    p.Id AS ProductId,
    ISNULL(NULLIF(LTRIM(RTRIM(p.ProductName)), ''), '-') AS ProductName,
    ISNULL(NULLIF(LTRIM(RTRIM(p.Bracelet)), ''), '-') AS Bilezik,
    ISNULL(NULLIF(LTRIM(RTRIM(p.Brand)), ''), '-') AS Brand,
    ISNULL(NULLIF(LTRIM(RTRIM(p.Dial)), ''), '-') AS Kadran,
    ISNULL(NULLIF(LTRIM(RTRIM(p.ProductCode)), ''), '-') AS RefCode,
    ISNULL(NULLIF(LTRIM(RTRIM(p.Referance)), ''), '-') AS Referans,

    ISNULL(
        NULLIF(
            LTRIM(RTRIM(ISNULL(cu.Name, '') + ' ' + ISNULL(cu.LastName, '')))
        , '')
    , '-') AS Musteri,

    ISNULL(NULLIF(LTRIM(RTRIM(cu.CityName)), ''), '-') AS Lokasyon,
    ISNULL(NULLIF(LTRIM(RTRIM(cu.DistrictName)), ''), '-') AS Ilce,
    ISNULL(NULLIF(LTRIM(RTRIM(cu.CountryName)), ''), '-') AS Ulke,
    ISNULL(NULLIF(LTRIM(RTRIM(cu.Info)), ''), '-') AS MusteriInfo,

    CASE
        WHEN cu.IsShopping = 1 THEN N'Evet'
        WHEN cu.IsShopping = 0 THEN N'Hayır'
        ELSE '-'
    END AS AlisverisiVarMi,

    ISNULL(NULLIF(LTRIM(RTRIM(cu.Tel)), ''), '-') AS IrtibatNumarasi,
    ISNULL(NULLIF(LTRIM(RTRIM(cu.Email)), ''), '-') AS EmailAdresi,

    ISNULL(NULLIF(LTRIM(RTRIM(cr.ContactResourceName)), ''), '-') AS IletisimKaynagi,

    ISNULL(NULLIF(LTRIM(RTRIM(p.CategoryName)), ''), '-') AS CategoryName,
    '-' AS CategoryCode,

    ISNULL(NULLIF(LTRIM(RTRIM(ls.Name)), ''), '-') AS LeadDurumu,
    ISNULL(NULLIF(LTRIM(RTRIM(ns.Name)), ''), '-') AS SonrakiAdim,

    ISNULL(NULLIF(LTRIM(RTRIM(lp.Name)), ''), '-') AS ProcessName,
    ISNULL(NULLIF(LTRIM(RTRIM(lp.Code)), ''), '-') AS ProcessCode,
    lp.StepOrder,
    
    -- DÜZELTİLEN ALAN: SelectedStepOrder
    CASE
        WHEN EXISTS
        (
            SELECT 1
            FROM tmscrq.TMLeadReservation r
            WHERE r.LeadId = l.Id
              AND r.IsActive = 1
              AND ISNULL(r.IsApproved,0) = 0
        )
        THEN 10
        ELSE lp.StepOrder
    END AS SelectedStepOrder,

    ISNULL(
        CASE
            WHEN l.EstimatedDate IS NOT NULL
            THEN CAST(YEAR(l.EstimatedDate) AS VARCHAR(4)) + ' ' + DATENAME(MONTH, l.EstimatedDate)
            ELSE NULL
        END,
        '-'
    ) AS TerminTarihi,

    ISNULL(
        NULLIF(
            LTRIM(RTRIM(ISNULL(sp.FirstName, '') + ' ' + ISNULL(sp.LastName, '')))
        , '')
    , '-') AS SatisDanismani,

    ISNULL(NULLIF(LTRIM(RTRIM(st.StoreDesc)), ''), '-') AS StoreName

FROM tmscrq.TMLead l
LEFT JOIN tmscrq.TMLeadStatu ls
    ON ls.Id = l.StatuId
LEFT JOIN tmscrq.TMCustomer cu
    ON cu.Id = l.CustomerId
LEFT JOIN tmscrq.TMProduct p
    ON p.Id = l.ProductId
LEFT JOIN tmscrq.TMContactResource cr
    ON cr.Id = l.ContactResourceId
LEFT JOIN dbo.KUser sp
    ON sp.Id = l.SalesPersonKUserId
LEFT JOIN tmscrq.TMStore st
    ON st.Id = l.StoreId
LEFT JOIN tmscrq.TMLeadProcess lp
    ON lp.Id = l.ProcessID
LEFT JOIN tmscrq.TMLeadNextStep ns
    ON ns.Id = l.NextStepId

WHERE
(
    EXISTS
    (
        SELECT 1
        FROM dbo.KUserRole ur
        INNER JOIN dbo.KRole r
            ON r.Id = ur.KRole_Id
        WHERE ur.KUser_Id = @UserId
          AND ur.IsDeleted = 0
          AND r.IsDeleted = 0
          AND r.Name IN ('TimesYonetici', 'TimesUstYonetici')
    )
    OR
    (
        EXISTS
        (
            SELECT 1
            FROM dbo.KUserRole ur
            INNER JOIN dbo.KRole r
                ON r.Id = ur.KRole_Id
            WHERE ur.KUser_Id = @UserId
              AND ur.IsDeleted = 0
              AND r.IsDeleted = 0
              AND r.Name IN ('TimesMagazaMuduru', 'TimesSatisPersoneli')
        )
        AND EXISTS
        (
            SELECT 1
            FROM tmscrq.TMUser tu
            WHERE tu.KUserID = @UserId
              AND tu.StoreId = l.StoreId
        )
    )
)

AND
(
    ISNULL(@MusteriAdi, '') = ''
    OR UPPER(ISNULL(cu.Name, '')) LIKE '%' + UPPER(LTRIM(RTRIM(@MusteriAdi))) + '%'
    OR UPPER(ISNULL(cu.LastName, '')) LIKE '%' + UPPER(LTRIM(RTRIM(@MusteriAdi))) + '%'
    OR UPPER(
        ISNULL(cu.Name, '') + ' ' + ISNULL(cu.LastName, '')
    ) LIKE '%' + UPPER(LTRIM(RTRIM(@MusteriAdi))) + '%'
)

AND
(
    @ProductName IS NULL
    OR LTRIM(RTRIM(@ProductName)) = ''
    OR
    (
        CHARINDEX(',', @ProductName) > 0
        AND ISNULL(LTRIM(RTRIM(p.ProductName)), '') IN
        (
            SELECT LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', '')))
            FROM STRING_SPLIT(CAST(@ProductName AS NVARCHAR(MAX)), ',')
            WHERE LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', ''))) <> ''
        )
    )
    OR
    (
        CHARINDEX(',', @ProductName) = 0
        AND UPPER(ISNULL(LTRIM(RTRIM(p.ProductName)), ''))
            LIKE '%' + UPPER(LTRIM(RTRIM(@ProductName))) + '%'
    )
)

AND
(
    ISNULL(@LeadCode, '') = ''
    OR UPPER(ISNULL(l.LeadCode, ''))
        LIKE '%' + UPPER(LTRIM(RTRIM(@LeadCode))) + '%'
    OR REPLACE(
        REPLACE(
            REPLACE(
                UPPER(ISNULL(l.LeadCode, '')),
                '-', ''
            ),
            ' ', ''
        ),
        '/', ''
    )
    LIKE '%' +
    REPLACE(
        REPLACE(
            REPLACE(
                UPPER(LTRIM(RTRIM(@LeadCode))),
                '-', ''
            ),
            ' ', ''
        ),
        '/', ''
    )
    + '%'
)

AND
(
    @Tel IS NULL
    OR LTRIM(RTRIM(@Tel)) = ''
    OR UPPER(ISNULL(LTRIM(RTRIM(cu.Tel)), '')) LIKE '%' + UPPER(LTRIM(RTRIM(@Tel))) + '%'
)

AND
(
    @CategoryName IS NULL
    OR LTRIM(RTRIM(@CategoryName)) = ''
    OR UPPER(ISNULL(LTRIM(RTRIM(p.CategoryName)), '')) IN
    (
        SELECT UPPER(LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value,'""',''),'[',''),']',''))))
        FROM STRING_SPLIT(CAST(@CategoryName AS NVARCHAR(MAX)), ',')
        WHERE LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value,'""',''),'[',''),']',''))) <> ''
    )
)

AND
(
    @StoreIds IS NULL
    OR LTRIM(RTRIM(@StoreIds)) = ''
    OR EXISTS
    (
        SELECT 1
        FROM STRING_SPLIT(CAST(@StoreIds AS NVARCHAR(MAX)), ',') s
        WHERE l.StoreId = TRY_CONVERT
        (
            uniqueidentifier,
            LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(s.value, '""', ''), '[', ''), ']', '')))
        )
    )
)

AND
(
    @SatisDanismaniIds IS NULL
    OR LTRIM(RTRIM(@SatisDanismaniIds)) = ''
    OR EXISTS
    (
        SELECT 1
        FROM STRING_SPLIT(CAST(@SatisDanismaniIds AS NVARCHAR(MAX)), ',') s
        WHERE l.SalesPersonKUserId = TRY_CONVERT
        (
            uniqueidentifier,
            LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(s.value, '""', ''), '[', ''), ']', '')))
        )
    )
)

AND
(
    ISNULL(@ProcessCode, '') = ''
    OR EXISTS
    (
        SELECT 1
        FROM STRING_SPLIT(
            CONVERT(NVARCHAR(MAX), @ProcessCode),
            ','
        ) AS s
        WHERE
            UPPER(LTRIM(RTRIM(s.value))) =
            UPPER(LTRIM(RTRIM(ISNULL(lp.Code, ''))))
    )
)

-- DÜZELTİLEN ALAN: @StepOrder Filtresi (0 verilince tümü gelsin)
AND
(
    @StepOrder IS NULL
    OR @StepOrder = 0  -- 👈 YENİ EKLENDI: 0 verilince tüm kayıtlar gelir
    OR
    (
        @StepOrder = 10
        AND EXISTS
        (
            SELECT 1
            FROM tmscrq.TMLeadReservation r
            WHERE r.LeadId = l.Id
              AND r.IsActive = 1
              AND ISNULL(r.IsApproved,0) = 0
        )
    )
    OR
    (
        @StepOrder <> 10
        AND lp.StepOrder = @StepOrder
    )
)

AND
(
    @StartDate IS NULL
    OR LTRIM(RTRIM(@StartDate)) = ''
    OR l.CreatedAt >= CONVERT(date, @StartDate)
)

AND
(
    @EndDate IS NULL
    OR LTRIM(RTRIM(@EndDate)) = ''
    OR l.CreatedAt < DATEADD(day, 1, CONVERT(date, @EndDate))
)

ORDER BY l.CreatedAt DESC;", new string[] { "RezerveDurumu", "LeadId", "IsReserved", "LeadNumarasi", "TalepTarihi", "ProductId", "ProductName", "Bilezik", "Brand", "Kadran", "RefCode", "Referans", "Musteri", "Lokasyon", "Ilce", "Ulke", "MusteriInfo", "AlisverisiVarMi", "IrtibatNumarasi", "EmailAdresi", "IletisimKaynagi", "CategoryName", "CategoryCode", "LeadDurumu", "SonrakiAdim", "ProcessName", "ProcessCode", "StepOrder", "SelectedStepOrder", "TerminTarihi", "SatisDanismani", "StoreName" }, prms_TM_GetLeads_0.ToArray());
            ;


            return Ok(result);
        }


        [HttpPost, Route("LeadListComponent_288211_onChange")]
        public IActionResult LeadListComponent_288211_onChange(LeadListComponent_288211_onChange_Request request)
        {

            KProviderManager.Authorization.IsAuthorizedForRoles(appId, appName, screenId, screenName, new List<string> { $"70de6cfc-6087-6059-59b4-0b5a8527af6b", "4da1f213-c8e4-0b50-5c84-02fd13f1a622", "c4e882ef-977d-f613-7694-230ac83919d2", "b4bfd39c-ac02-f442-c899-7a2374a45b47", "cdb536b0-6297-155f-d446-8453d8a60304", "TimesYonetici", "TimesUstYonetici", "TimesSatisPersoneli", "TimesMagazaMuduru", "TimesAdmin" });

            var result = new LeadListComponent_288211_onChange_Response();

            var prms_TM_GetLeads_0 = new List<kSqlParameter>();
            prms_TM_GetLeads_0.Add(new kSqlParameter() { Name = "StepOrder", Value = request.StepOrder_0 });
            prms_TM_GetLeads_0.Add(new kSqlParameter() { Name = "UserId", Value = Kuika.Common.KContext.CurrentUser?.Id });
            prms_TM_GetLeads_0.Add(new kSqlParameter() { Name = "MusteriAdi", Value = request.MusteriAdi_0 });
            prms_TM_GetLeads_0.Add(new kSqlParameter() { Name = "ProductName", Value = request.ProductName_0 });
            prms_TM_GetLeads_0.Add(new kSqlParameter() { Name = "LeadCode", Value = request.LeadCode_0 });
            prms_TM_GetLeads_0.Add(new kSqlParameter() { Name = "Tel", Value = request.Tel_0 });
            prms_TM_GetLeads_0.Add(new kSqlParameter() { Name = "CategoryName", Value = request.CategoryName_0 });
            prms_TM_GetLeads_0.Add(new kSqlParameter() { Name = "StoreIds", Value = request.StoreIds_0 });
            prms_TM_GetLeads_0.Add(new kSqlParameter() { Name = "SatisDanismaniIds", Value = request.SatisDanismaniIds_0 });
            prms_TM_GetLeads_0.Add(new kSqlParameter() { Name = "ProcessCode", Value = request.ProcessCode_0 });
            prms_TM_GetLeads_0.Add(new kSqlParameter() { Name = "StartDate", Value = request.StartDate_0 });
            prms_TM_GetLeads_0.Add(new kSqlParameter() { Name = "EndDate", Value = request.EndDate_0 });
            using var auditTM_GetLeads_0 = ActionAuditScope.Begin("94cb237f-e784-08e7-91a9-6af33cbca77a", "TM_GetLeads", applicationName: "wbTimesCRM", screenOrEndpointName: "LeadList");
            result.TM_GetLeads = KPersister.Fetch(KContext.GetConnectionString(), @"-- SET LANGUAGE Turkish;

-- SELECT
-- CASE 
--     WHEN EXISTS (
--         SELECT 1 
--         FROM tmscrq.TMLeadReservation r
--         WHERE r.LeadId = l.Id
--           AND r.IsActive = 1
--           AND r.IsApproved = 1
--     ) THEN N'Evet'

--     WHEN EXISTS (
--         SELECT 1 
--         FROM tmscrq.TMLeadReservation r
--         WHERE r.LeadId = l.Id
--           AND r.IsActive = 1
--           AND ISNULL(r.IsApproved,0) = 0
--     ) THEN N'Onay Bekliyor'

--     ELSE N'Hayır'
-- END AS RezerveDurumu,
--     l.Id AS LeadId,
--     l.IsReserved,
--     ISNULL(NULLIF(LTRIM(RTRIM(l.LeadCode)), ''), '-') AS LeadNumarasi,
--     CONVERT(varchar(10), l.CreatedAt, 103) AS TalepTarihi,

--     p.Id AS ProductId,
--     ISNULL(NULLIF(LTRIM(RTRIM(p.ProductName)), ''), '-') AS ProductName,
--     ISNULL(NULLIF(LTRIM(RTRIM(p.Bracelet)), ''), '-') AS Bilezik,
--     ISNULL(NULLIF(LTRIM(RTRIM(p.Brand)), ''), '-') AS Brand,
--     ISNULL(NULLIF(LTRIM(RTRIM(p.Dial)), ''), '-') AS Kadran,
--     ISNULL(NULLIF(LTRIM(RTRIM(p.ProductCode)), ''), '-') AS RefCode,
--     ISNULL(NULLIF(LTRIM(RTRIM(p.Referance)), ''), '-') AS Referans,

--     ISNULL(
--         NULLIF(
--             LTRIM(RTRIM(ISNULL(cu.Name, '') + ' ' + ISNULL(cu.LastName, '')))
--         , '')
--     , '-') AS Musteri,

--     ISNULL(NULLIF(LTRIM(RTRIM(cu.CityName)), ''), '-') AS Lokasyon,
--     ISNULL(NULLIF(LTRIM(RTRIM(cu.DistrictName)), ''), '-') AS Ilce,
--     ISNULL(NULLIF(LTRIM(RTRIM(cu.CountryName)), ''), '-') AS Ulke,
--     ISNULL(NULLIF(LTRIM(RTRIM(cu.Info)), ''), '-') AS MusteriInfo,

--     CASE
--         WHEN cu.IsShopping = 1 THEN N'Evet'
--         WHEN cu.IsShopping = 0 THEN N'Hayır'
--         ELSE '-'
--     END AS AlisverisiVarMi,

--     ISNULL(NULLIF(LTRIM(RTRIM(cu.Tel)), ''), '-') AS IrtibatNumarasi,
--     ISNULL(NULLIF(LTRIM(RTRIM(cu.Email)), ''), '-') AS EmailAdresi,

--     ISNULL(NULLIF(LTRIM(RTRIM(cr.ContactResourceName)), ''), '-') AS IletisimKaynagi,

--     ISNULL(NULLIF(LTRIM(RTRIM(p.CategoryName)), ''), '-') AS CategoryName,
--     '-' AS CategoryCode,

--     ISNULL(NULLIF(LTRIM(RTRIM(ls.Name)), ''), '-') AS LeadDurumu,
--     ISNULL(NULLIF(LTRIM(RTRIM(ns.Name)), ''), '-') AS SonrakiAdim,

--     ISNULL(NULLIF(LTRIM(RTRIM(lp.Name)), ''), '-') AS ProcessName,
--     ISNULL(NULLIF(LTRIM(RTRIM(lp.Code)), ''), '-') AS ProcessCode,
--     lp.StepOrder,
-- CASE
--     WHEN EXISTS
--     (
--         SELECT 1
--         FROM tmscrq.TMLeadReservation r
--         WHERE r.LeadId = l.Id
--           AND r.IsActive = 1
--           AND ISNULL(r.IsApproved,0) = 0
--     )
--     THEN 10
--     ELSE lp.StepOrder
-- END AS SelectedStepOrder,

--     ISNULL(
--         CASE
--             WHEN l.EstimatedDate IS NOT NULL
--             THEN CAST(YEAR(l.EstimatedDate) AS VARCHAR(4)) + ' ' + DATENAME(MONTH, l.EstimatedDate)
--             ELSE NULL
--         END,
--         '-'
--     ) AS TerminTarihi,

--     ISNULL(
--         NULLIF(
--             LTRIM(RTRIM(ISNULL(sp.FirstName, '') + ' ' + ISNULL(sp.LastName, '')))
--         , '')
--     , '-') AS SatisDanismani,

--     ISNULL(NULLIF(LTRIM(RTRIM(st.StoreDesc)), ''), '-') AS StoreName

-- FROM tmscrq.TMLead l
-- LEFT JOIN tmscrq.TMLeadStatu ls
--     ON ls.Id = l.StatuId
-- LEFT JOIN tmscrq.TMCustomer cu
--     ON cu.Id = l.CustomerId
-- LEFT JOIN tmscrq.TMProduct p
--     ON p.Id = l.ProductId
-- LEFT JOIN tmscrq.TMContactResource cr
--     ON cr.Id = l.ContactResourceId
-- LEFT JOIN dbo.KUser sp
--     ON sp.Id = l.SalesPersonKUserId
-- LEFT JOIN tmscrq.TMStore st
--     ON st.Id = l.StoreId
-- LEFT JOIN tmscrq.TMLeadProcess lp
--     ON lp.Id = l.ProcessID
-- LEFT JOIN tmscrq.TMLeadNextStep ns
--     ON ns.Id = l.NextStepId

-- WHERE
-- (
--     EXISTS
--     (
--         SELECT 1
--         FROM dbo.KUserRole ur
--         INNER JOIN dbo.KRole r
--             ON r.Id = ur.KRole_Id
--         WHERE ur.KUser_Id = @UserId
--           AND ur.IsDeleted = 0
--           AND r.IsDeleted = 0
--           AND r.Name IN ('TimesYonetici', 'TimesUstYonetici')
--     )
--     OR
--     (
--         EXISTS
--         (
--             SELECT 1
--             FROM dbo.KUserRole ur
--             INNER JOIN dbo.KRole r
--                 ON r.Id = ur.KRole_Id
--             WHERE ur.KUser_Id = @UserId
--               AND ur.IsDeleted = 0
--               AND r.IsDeleted = 0
--               AND r.Name IN ('TimesMagazaMuduru', 'TimesSatisPersoneli')
--         )
--         AND EXISTS
--         (
--             SELECT 1
--             FROM tmscrq.TMUser tu
--             WHERE tu.KUserID = @UserId
--               AND tu.StoreId = l.StoreId
--         )
--     )
-- )

-- AND
-- (
--     @MusteriAdi IS NULL
--     OR LTRIM(RTRIM(@MusteriAdi)) = ''
--     OR UPPER(LTRIM(RTRIM(ISNULL(cu.Name,'') + ' ' + ISNULL(cu.LastName,''))))
--        LIKE '%' + UPPER(LTRIM(RTRIM(@MusteriAdi))) + '%'
-- )

-- AND
-- (
--     @ProductName IS NULL
--     OR LTRIM(RTRIM(@ProductName)) = ''
--     OR
--     (
--         CHARINDEX(',', @ProductName) > 0
--         AND ISNULL(LTRIM(RTRIM(p.ProductName)), '') IN
--         (
--             SELECT LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', '')))
--             FROM STRING_SPLIT(CAST(@ProductName AS NVARCHAR(MAX)), ',')
--             WHERE LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', ''))) <> ''
--         )
--     )
--     OR
--     (
--         CHARINDEX(',', @ProductName) = 0
--         AND UPPER(ISNULL(LTRIM(RTRIM(p.ProductName)), ''))
--             LIKE '%' + UPPER(LTRIM(RTRIM(@ProductName))) + '%'
--     )
-- )

-- AND
-- (
--     @LeadCode IS NULL
--     OR LTRIM(RTRIM(@LeadCode)) = ''
--     OR UPPER(ISNULL(LTRIM(RTRIM(l.LeadCode)), '')) LIKE '%' + UPPER(LTRIM(RTRIM(@LeadCode))) + '%'
-- )

-- AND
-- (
--     @Tel IS NULL
--     OR LTRIM(RTRIM(@Tel)) = ''
--     OR UPPER(ISNULL(LTRIM(RTRIM(cu.Tel)), '')) LIKE '%' + UPPER(LTRIM(RTRIM(@Tel))) + '%'
-- )

-- -- AND
-- -- (
-- --     @CategoryName IS NULL
-- --     OR LTRIM(RTRIM(@CategoryName)) = ''
-- --     OR
-- --     (
-- --         EXISTS
-- --         (
-- --             SELECT 1
-- --             FROM STRING_SPLIT(CAST(@CategoryName AS NVARCHAR(MAX)), ',') c
-- --             WHERE UPPER(LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(c.value, '""', ''), '[', ''), ']', '')))) = 'DEFAULT'
-- --         )
-- --         AND (p.CategoryName IS NULL OR LTRIM(RTRIM(p.CategoryName)) = '')
-- --     )
-- --     OR UPPER(ISNULL(LTRIM(RTRIM(p.CategoryName)), '')) IN
-- --     (
-- --         SELECT UPPER(LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', ''))))
-- --         FROM STRING_SPLIT(CAST(@CategoryName AS NVARCHAR(MAX)), ',')
-- --         WHERE LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', ''))) <> ''
-- --           AND UPPER(LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', '')))) <> 'DEFAULT'
-- --     )
-- -- )

-- AND
-- (
--     @CategoryName IS NULL
--     OR LTRIM(RTRIM(@CategoryName)) = ''
--     OR UPPER(ISNULL(LTRIM(RTRIM(p.CategoryName)), '')) IN
--     (
--         SELECT UPPER(LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value,'""',''),'[',''),']',''))))
--         FROM STRING_SPLIT(CAST(@CategoryName AS NVARCHAR(MAX)), ',')
--         WHERE LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value,'""',''),'[',''),']',''))) <> ''
--     )
-- )

-- AND
-- (
--     @StoreIds IS NULL
--     OR LTRIM(RTRIM(@StoreIds)) = ''
--     OR EXISTS
--     (
--         SELECT 1
--         FROM STRING_SPLIT(CAST(@StoreIds AS NVARCHAR(MAX)), ',') s
--         WHERE l.StoreId = TRY_CONVERT
--         (
--             uniqueidentifier,
--             LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(s.value, '""', ''), '[', ''), ']', '')))
--         )
--     )
-- )

-- AND
-- (
--     @SatisDanismaniIds IS NULL
--     OR LTRIM(RTRIM(@SatisDanismaniIds)) = ''
--     OR EXISTS
--     (
--         SELECT 1
--         FROM STRING_SPLIT(CAST(@SatisDanismaniIds AS NVARCHAR(MAX)), ',') s
--         WHERE l.SalesPersonKUserId = TRY_CONVERT
--         (
--             uniqueidentifier,
--             LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(s.value, '""', ''), '[', ''), ']', '')))
--         )
--     )
-- )

-- AND
-- (
--     @ProcessCode IS NULL
--     OR LTRIM(RTRIM(@ProcessCode)) = ''
--     OR UPPER(ISNULL(LTRIM(RTRIM(lp.Code)), '')) IN
--     (
--         SELECT UPPER(LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', ''))))
--         FROM STRING_SPLIT(CAST(@ProcessCode AS NVARCHAR(MAX)), ',')
--         WHERE LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', ''))) <> ''
--     )
-- )

-- AND
-- (
--     @StepOrder IS NULL

--     OR
--     (
--         @StepOrder = 10
--         AND EXISTS
--         (
--             SELECT 1
--             FROM tmscrq.TMLeadReservation r
--             WHERE r.LeadId = l.Id
--               AND r.IsActive = 1
--               AND ISNULL(r.IsApproved,0) = 0
--         )
--     )

--     OR
--     (
--         @StepOrder <> 10
--         AND lp.StepOrder = @StepOrder
--     )
-- )

-- AND
-- (
--     @StartDate IS NULL
--     OR LTRIM(RTRIM(@StartDate)) = ''
--     OR l.CreatedAt >= CONVERT(date, @StartDate)
-- )

-- AND
-- (
--     @EndDate IS NULL
--     OR LTRIM(RTRIM(@EndDate)) = ''
--     OR l.CreatedAt < DATEADD(day, 1, CONVERT(date, @EndDate))
-- )

-- ORDER BY l.CreatedAt DESC;

------------------------++++++++++++++++++++++++-------------------
-- SET LANGUAGE Turkish;

-- SELECT
-- CASE 
--     WHEN EXISTS (
--         SELECT 1 
--         FROM tmscrq.TMLeadReservation r
--         WHERE r.LeadId = l.Id
--           AND r.IsActive = 1
--           AND r.IsApproved = 1
--     ) THEN N'Evet'

--     WHEN EXISTS (
--         SELECT 1 
--         FROM tmscrq.TMLeadReservation r
--         WHERE r.LeadId = l.Id
--           AND r.IsActive = 1
--           AND ISNULL(r.IsApproved,0) = 0
--     ) THEN N'Onay Bekliyor'

--     ELSE N'Hayır'
-- END AS RezerveDurumu,
--     l.Id AS LeadId,
--     l.IsReserved,
--     ISNULL(NULLIF(LTRIM(RTRIM(l.LeadCode)), ''), '-') AS LeadNumarasi,
--     CONVERT(varchar(10), l.CreatedAt, 103) AS TalepTarihi,

--     p.Id AS ProductId,
--     ISNULL(NULLIF(LTRIM(RTRIM(p.ProductName)), ''), '-') AS ProductName,
--     ISNULL(NULLIF(LTRIM(RTRIM(p.Bracelet)), ''), '-') AS Bilezik,
--     ISNULL(NULLIF(LTRIM(RTRIM(p.Brand)), ''), '-') AS Brand,
--     ISNULL(NULLIF(LTRIM(RTRIM(p.Dial)), ''), '-') AS Kadran,
--     ISNULL(NULLIF(LTRIM(RTRIM(p.ProductCode)), ''), '-') AS RefCode,
--     ISNULL(NULLIF(LTRIM(RTRIM(p.Referance)), ''), '-') AS Referans,

--     ISNULL(
--         NULLIF(
--             LTRIM(RTRIM(ISNULL(cu.Name, '') + ' ' + ISNULL(cu.LastName, '')))
--         , '')
--     , '-') AS Musteri,

--     ISNULL(NULLIF(LTRIM(RTRIM(cu.CityName)), ''), '-') AS Lokasyon,
--     ISNULL(NULLIF(LTRIM(RTRIM(cu.DistrictName)), ''), '-') AS Ilce,
--     ISNULL(NULLIF(LTRIM(RTRIM(cu.CountryName)), ''), '-') AS Ulke,
--     ISNULL(NULLIF(LTRIM(RTRIM(cu.Info)), ''), '-') AS MusteriInfo,

--     CASE
--         WHEN cu.IsShopping = 1 THEN N'Evet'
--         WHEN cu.IsShopping = 0 THEN N'Hayır'
--         ELSE '-'
--     END AS AlisverisiVarMi,

--     ISNULL(NULLIF(LTRIM(RTRIM(cu.Tel)), ''), '-') AS IrtibatNumarasi,
--     ISNULL(NULLIF(LTRIM(RTRIM(cu.Email)), ''), '-') AS EmailAdresi,

--     ISNULL(NULLIF(LTRIM(RTRIM(cr.ContactResourceName)), ''), '-') AS IletisimKaynagi,

--     ISNULL(NULLIF(LTRIM(RTRIM(p.CategoryName)), ''), '-') AS CategoryName,
--     '-' AS CategoryCode,

--     ISNULL(NULLIF(LTRIM(RTRIM(ls.Name)), ''), '-') AS LeadDurumu,
--     ISNULL(NULLIF(LTRIM(RTRIM(ns.Name)), ''), '-') AS SonrakiAdim,

--     ISNULL(NULLIF(LTRIM(RTRIM(lp.Name)), ''), '-') AS ProcessName,
--     ISNULL(NULLIF(LTRIM(RTRIM(lp.Code)), ''), '-') AS ProcessCode,
--     lp.StepOrder,
    
--     -- DÜZELTİLEN ALAN: SelectedStepOrder
--     CASE
--         WHEN EXISTS
--         (
--             SELECT 1
--             FROM tmscrq.TMLeadReservation r
--             WHERE r.LeadId = l.Id
--               AND r.IsActive = 1
--               AND ISNULL(r.IsApproved,0) = 0
--         )
--         THEN 10
--         ELSE lp.StepOrder
--     END AS SelectedStepOrder,

--     ISNULL(
--         CASE
--             WHEN l.EstimatedDate IS NOT NULL
--             THEN CAST(YEAR(l.EstimatedDate) AS VARCHAR(4)) + ' ' + DATENAME(MONTH, l.EstimatedDate)
--             ELSE NULL
--         END,
--         '-'
--     ) AS TerminTarihi,

--     ISNULL(
--         NULLIF(
--             LTRIM(RTRIM(ISNULL(sp.FirstName, '') + ' ' + ISNULL(sp.LastName, '')))
--         , '')
--     , '-') AS SatisDanismani,

--     ISNULL(NULLIF(LTRIM(RTRIM(st.StoreDesc)), ''), '-') AS StoreName

-- FROM tmscrq.TMLead l
-- LEFT JOIN tmscrq.TMLeadStatu ls
--     ON ls.Id = l.StatuId
-- LEFT JOIN tmscrq.TMCustomer cu
--     ON cu.Id = l.CustomerId
-- LEFT JOIN tmscrq.TMProduct p
--     ON p.Id = l.ProductId
-- LEFT JOIN tmscrq.TMContactResource cr
--     ON cr.Id = l.ContactResourceId
-- LEFT JOIN dbo.KUser sp
--     ON sp.Id = l.SalesPersonKUserId
-- LEFT JOIN tmscrq.TMStore st
--     ON st.Id = l.StoreId
-- LEFT JOIN tmscrq.TMLeadProcess lp
--     ON lp.Id = l.ProcessID
-- LEFT JOIN tmscrq.TMLeadNextStep ns
--     ON ns.Id = l.NextStepId

-- WHERE
-- (
--     EXISTS
--     (
--         SELECT 1
--         FROM dbo.KUserRole ur
--         INNER JOIN dbo.KRole r
--             ON r.Id = ur.KRole_Id
--         WHERE ur.KUser_Id = @UserId
--           AND ur.IsDeleted = 0
--           AND r.IsDeleted = 0
--           AND r.Name IN ('TimesYonetici', 'TimesUstYonetici')
--     )
--     OR
--     (
--         EXISTS
--         (
--             SELECT 1
--             FROM dbo.KUserRole ur
--             INNER JOIN dbo.KRole r
--                 ON r.Id = ur.KRole_Id
--             WHERE ur.KUser_Id = @UserId
--               AND ur.IsDeleted = 0
--               AND r.IsDeleted = 0
--               AND r.Name IN ('TimesMagazaMuduru', 'TimesSatisPersoneli')
--         )
--         AND EXISTS
--         (
--             SELECT 1
--             FROM tmscrq.TMUser tu
--             WHERE tu.KUserID = @UserId
--               AND tu.StoreId = l.StoreId
--         )
--     )
-- )

-- AND
-- (
--     @MusteriAdi IS NULL
--     OR LTRIM(RTRIM(@MusteriAdi)) = ''
--     OR UPPER(LTRIM(RTRIM(ISNULL(cu.Name,'') + ' ' + ISNULL(cu.LastName,''))))
--        LIKE '%' + UPPER(LTRIM(RTRIM(@MusteriAdi))) + '%'
-- )

-- AND
-- (
--     @ProductName IS NULL
--     OR LTRIM(RTRIM(@ProductName)) = ''
--     OR
--     (
--         CHARINDEX(',', @ProductName) > 0
--         AND ISNULL(LTRIM(RTRIM(p.ProductName)), '') IN
--         (
--             SELECT LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', '')))
--             FROM STRING_SPLIT(CAST(@ProductName AS NVARCHAR(MAX)), ',')
--             WHERE LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', ''))) <> ''
--         )
--     )
--     OR
--     (
--         CHARINDEX(',', @ProductName) = 0
--         AND UPPER(ISNULL(LTRIM(RTRIM(p.ProductName)), ''))
--             LIKE '%' + UPPER(LTRIM(RTRIM(@ProductName))) + '%'
--     )
-- )

-- AND
-- (
--     @LeadCode IS NULL
--     OR LTRIM(RTRIM(@LeadCode)) = ''
--     OR UPPER(ISNULL(LTRIM(RTRIM(l.LeadCode)), '')) LIKE '%' + UPPER(LTRIM(RTRIM(@LeadCode))) + '%'
-- )

-- AND
-- (
--     @Tel IS NULL
--     OR LTRIM(RTRIM(@Tel)) = ''
--     OR UPPER(ISNULL(LTRIM(RTRIM(cu.Tel)), '')) LIKE '%' + UPPER(LTRIM(RTRIM(@Tel))) + '%'
-- )

-- AND
-- (
--     @CategoryName IS NULL
--     OR LTRIM(RTRIM(@CategoryName)) = ''
--     OR UPPER(ISNULL(LTRIM(RTRIM(p.CategoryName)), '')) IN
--     (
--         SELECT UPPER(LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value,'""',''),'[',''),']',''))))
--         FROM STRING_SPLIT(CAST(@CategoryName AS NVARCHAR(MAX)), ',')
--         WHERE LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value,'""',''),'[',''),']',''))) <> ''
--     )
-- )

-- AND
-- (
--     @StoreIds IS NULL
--     OR LTRIM(RTRIM(@StoreIds)) = ''
--     OR EXISTS
--     (
--         SELECT 1
--         FROM STRING_SPLIT(CAST(@StoreIds AS NVARCHAR(MAX)), ',') s
--         WHERE l.StoreId = TRY_CONVERT
--         (
--             uniqueidentifier,
--             LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(s.value, '""', ''), '[', ''), ']', '')))
--         )
--     )
-- )

-- AND
-- (
--     @SatisDanismaniIds IS NULL
--     OR LTRIM(RTRIM(@SatisDanismaniIds)) = ''
--     OR EXISTS
--     (
--         SELECT 1
--         FROM STRING_SPLIT(CAST(@SatisDanismaniIds AS NVARCHAR(MAX)), ',') s
--         WHERE l.SalesPersonKUserId = TRY_CONVERT
--         (
--             uniqueidentifier,
--             LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(s.value, '""', ''), '[', ''), ']', '')))
--         )
--     )
-- )

-- AND
-- (
--     @ProcessCode IS NULL
--     OR LTRIM(RTRIM(@ProcessCode)) = ''
--     OR UPPER(ISNULL(LTRIM(RTRIM(lp.Code)), '')) IN
--     (
--         SELECT UPPER(LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', ''))))
--         FROM STRING_SPLIT(CAST(@ProcessCode AS NVARCHAR(MAX)), ',')
--         WHERE LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', ''))) <> ''
--     )
-- )

-- -- DÜZELTİLEN ALAN: @StepOrder Filtresi (tek blok)
-- AND
-- (
--     @StepOrder IS NULL

--     OR

--     (
--         @StepOrder = 10
--         AND EXISTS
--         (
--             SELECT 1
--             FROM tmscrq.TMLeadReservation r
--             WHERE r.LeadId = l.Id
--               AND r.IsActive = 1
--               AND ISNULL(r.IsApproved,0) = 0
--         )
--     )

--     OR

--     (
--         @StepOrder <> 10
--         AND lp.StepOrder = @StepOrder
--     )
-- )

-- AND
-- (
--     @StartDate IS NULL
--     OR LTRIM(RTRIM(@StartDate)) = ''
--     OR l.CreatedAt >= CONVERT(date, @StartDate)
-- )

-- AND
-- (
--     @EndDate IS NULL
--     OR LTRIM(RTRIM(@EndDate)) = ''
--     OR l.CreatedAt < DATEADD(day, 1, CONVERT(date, @EndDate))
-- )

-- ORDER BY l.CreatedAt DESC;



SET LANGUAGE Turkish;

SELECT
CASE 
    WHEN EXISTS (
        SELECT 1 
        FROM tmscrq.TMLeadReservation r
        WHERE r.LeadId = l.Id
          AND r.IsActive = 1
          AND r.IsApproved = 1
    ) THEN N'Evet'

    WHEN EXISTS (
        SELECT 1 
        FROM tmscrq.TMLeadReservation r
        WHERE r.LeadId = l.Id
          AND r.IsActive = 1
          AND ISNULL(r.IsApproved,0) = 0
    ) THEN N'Onay Bekliyor'

    ELSE N'Hayır'
END AS RezerveDurumu,
    l.Id AS LeadId,
    l.IsReserved,
    ISNULL(NULLIF(LTRIM(RTRIM(l.LeadCode)), ''), '-') AS LeadNumarasi,
     FORMAT(l.CreatedAt, 'dd MMMM yyyy', 'tr-TR') AS TalepTarihi,

    p.Id AS ProductId,
    ISNULL(NULLIF(LTRIM(RTRIM(p.ProductName)), ''), '-') AS ProductName,
    ISNULL(NULLIF(LTRIM(RTRIM(p.Bracelet)), ''), '-') AS Bilezik,
    ISNULL(NULLIF(LTRIM(RTRIM(p.Brand)), ''), '-') AS Brand,
    ISNULL(NULLIF(LTRIM(RTRIM(p.Dial)), ''), '-') AS Kadran,
    ISNULL(NULLIF(LTRIM(RTRIM(p.ProductCode)), ''), '-') AS RefCode,
    ISNULL(NULLIF(LTRIM(RTRIM(p.Referance)), ''), '-') AS Referans,

    ISNULL(
        NULLIF(
            LTRIM(RTRIM(ISNULL(cu.Name, '') + ' ' + ISNULL(cu.LastName, '')))
        , '')
    , '-') AS Musteri,

    ISNULL(NULLIF(LTRIM(RTRIM(cu.CityName)), ''), '-') AS Lokasyon,
    ISNULL(NULLIF(LTRIM(RTRIM(cu.DistrictName)), ''), '-') AS Ilce,
    ISNULL(NULLIF(LTRIM(RTRIM(cu.CountryName)), ''), '-') AS Ulke,
    ISNULL(NULLIF(LTRIM(RTRIM(cu.Info)), ''), '-') AS MusteriInfo,

    CASE
        WHEN cu.IsShopping = 1 THEN N'Evet'
        WHEN cu.IsShopping = 0 THEN N'Hayır'
        ELSE '-'
    END AS AlisverisiVarMi,

    ISNULL(NULLIF(LTRIM(RTRIM(cu.Tel)), ''), '-') AS IrtibatNumarasi,
    ISNULL(NULLIF(LTRIM(RTRIM(cu.Email)), ''), '-') AS EmailAdresi,

    ISNULL(NULLIF(LTRIM(RTRIM(cr.ContactResourceName)), ''), '-') AS IletisimKaynagi,

    ISNULL(NULLIF(LTRIM(RTRIM(p.CategoryName)), ''), '-') AS CategoryName,
    '-' AS CategoryCode,

    ISNULL(NULLIF(LTRIM(RTRIM(ls.Name)), ''), '-') AS LeadDurumu,
    ISNULL(NULLIF(LTRIM(RTRIM(ns.Name)), ''), '-') AS SonrakiAdim,

    ISNULL(NULLIF(LTRIM(RTRIM(lp.Name)), ''), '-') AS ProcessName,
    ISNULL(NULLIF(LTRIM(RTRIM(lp.Code)), ''), '-') AS ProcessCode,
    lp.StepOrder,
    
    -- DÜZELTİLEN ALAN: SelectedStepOrder
    CASE
        WHEN EXISTS
        (
            SELECT 1
            FROM tmscrq.TMLeadReservation r
            WHERE r.LeadId = l.Id
              AND r.IsActive = 1
              AND ISNULL(r.IsApproved,0) = 0
        )
        THEN 10
        ELSE lp.StepOrder
    END AS SelectedStepOrder,

    ISNULL(
        CASE
            WHEN l.EstimatedDate IS NOT NULL
            THEN CAST(YEAR(l.EstimatedDate) AS VARCHAR(4)) + ' ' + DATENAME(MONTH, l.EstimatedDate)
            ELSE NULL
        END,
        '-'
    ) AS TerminTarihi,

    ISNULL(
        NULLIF(
            LTRIM(RTRIM(ISNULL(sp.FirstName, '') + ' ' + ISNULL(sp.LastName, '')))
        , '')
    , '-') AS SatisDanismani,

    ISNULL(NULLIF(LTRIM(RTRIM(st.StoreDesc)), ''), '-') AS StoreName

FROM tmscrq.TMLead l
LEFT JOIN tmscrq.TMLeadStatu ls
    ON ls.Id = l.StatuId
LEFT JOIN tmscrq.TMCustomer cu
    ON cu.Id = l.CustomerId
LEFT JOIN tmscrq.TMProduct p
    ON p.Id = l.ProductId
LEFT JOIN tmscrq.TMContactResource cr
    ON cr.Id = l.ContactResourceId
LEFT JOIN dbo.KUser sp
    ON sp.Id = l.SalesPersonKUserId
LEFT JOIN tmscrq.TMStore st
    ON st.Id = l.StoreId
LEFT JOIN tmscrq.TMLeadProcess lp
    ON lp.Id = l.ProcessID
LEFT JOIN tmscrq.TMLeadNextStep ns
    ON ns.Id = l.NextStepId

WHERE
(
    EXISTS
    (
        SELECT 1
        FROM dbo.KUserRole ur
        INNER JOIN dbo.KRole r
            ON r.Id = ur.KRole_Id
        WHERE ur.KUser_Id = @UserId
          AND ur.IsDeleted = 0
          AND r.IsDeleted = 0
          AND r.Name IN ('TimesYonetici', 'TimesUstYonetici')
    )
    OR
    (
        EXISTS
        (
            SELECT 1
            FROM dbo.KUserRole ur
            INNER JOIN dbo.KRole r
                ON r.Id = ur.KRole_Id
            WHERE ur.KUser_Id = @UserId
              AND ur.IsDeleted = 0
              AND r.IsDeleted = 0
              AND r.Name IN ('TimesMagazaMuduru', 'TimesSatisPersoneli')
        )
        AND EXISTS
        (
            SELECT 1
            FROM tmscrq.TMUser tu
            WHERE tu.KUserID = @UserId
              AND tu.StoreId = l.StoreId
        )
    )
)

AND
(
    ISNULL(@MusteriAdi, '') = ''
    OR UPPER(ISNULL(cu.Name, '')) LIKE '%' + UPPER(LTRIM(RTRIM(@MusteriAdi))) + '%'
    OR UPPER(ISNULL(cu.LastName, '')) LIKE '%' + UPPER(LTRIM(RTRIM(@MusteriAdi))) + '%'
    OR UPPER(
        ISNULL(cu.Name, '') + ' ' + ISNULL(cu.LastName, '')
    ) LIKE '%' + UPPER(LTRIM(RTRIM(@MusteriAdi))) + '%'
)

AND
(
    @ProductName IS NULL
    OR LTRIM(RTRIM(@ProductName)) = ''
    OR
    (
        CHARINDEX(',', @ProductName) > 0
        AND ISNULL(LTRIM(RTRIM(p.ProductName)), '') IN
        (
            SELECT LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', '')))
            FROM STRING_SPLIT(CAST(@ProductName AS NVARCHAR(MAX)), ',')
            WHERE LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', ''))) <> ''
        )
    )
    OR
    (
        CHARINDEX(',', @ProductName) = 0
        AND UPPER(ISNULL(LTRIM(RTRIM(p.ProductName)), ''))
            LIKE '%' + UPPER(LTRIM(RTRIM(@ProductName))) + '%'
    )
)

AND
(
    ISNULL(@LeadCode, '') = ''
    OR UPPER(ISNULL(l.LeadCode, ''))
        LIKE '%' + UPPER(LTRIM(RTRIM(@LeadCode))) + '%'
    OR REPLACE(
        REPLACE(
            REPLACE(
                UPPER(ISNULL(l.LeadCode, '')),
                '-', ''
            ),
            ' ', ''
        ),
        '/', ''
    )
    LIKE '%' +
    REPLACE(
        REPLACE(
            REPLACE(
                UPPER(LTRIM(RTRIM(@LeadCode))),
                '-', ''
            ),
            ' ', ''
        ),
        '/', ''
    )
    + '%'
)

AND
(
    @Tel IS NULL
    OR LTRIM(RTRIM(@Tel)) = ''
    OR UPPER(ISNULL(LTRIM(RTRIM(cu.Tel)), '')) LIKE '%' + UPPER(LTRIM(RTRIM(@Tel))) + '%'
)

AND
(
    @CategoryName IS NULL
    OR LTRIM(RTRIM(@CategoryName)) = ''
    OR UPPER(ISNULL(LTRIM(RTRIM(p.CategoryName)), '')) IN
    (
        SELECT UPPER(LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value,'""',''),'[',''),']',''))))
        FROM STRING_SPLIT(CAST(@CategoryName AS NVARCHAR(MAX)), ',')
        WHERE LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value,'""',''),'[',''),']',''))) <> ''
    )
)

AND
(
    @StoreIds IS NULL
    OR LTRIM(RTRIM(@StoreIds)) = ''
    OR EXISTS
    (
        SELECT 1
        FROM STRING_SPLIT(CAST(@StoreIds AS NVARCHAR(MAX)), ',') s
        WHERE l.StoreId = TRY_CONVERT
        (
            uniqueidentifier,
            LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(s.value, '""', ''), '[', ''), ']', '')))
        )
    )
)

AND
(
    @SatisDanismaniIds IS NULL
    OR LTRIM(RTRIM(@SatisDanismaniIds)) = ''
    OR EXISTS
    (
        SELECT 1
        FROM STRING_SPLIT(CAST(@SatisDanismaniIds AS NVARCHAR(MAX)), ',') s
        WHERE l.SalesPersonKUserId = TRY_CONVERT
        (
            uniqueidentifier,
            LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(s.value, '""', ''), '[', ''), ']', '')))
        )
    )
)

AND
(
    ISNULL(@ProcessCode, '') = ''
    OR EXISTS
    (
        SELECT 1
        FROM STRING_SPLIT(
            CONVERT(NVARCHAR(MAX), @ProcessCode),
            ','
        ) AS s
        WHERE
            UPPER(LTRIM(RTRIM(s.value))) =
            UPPER(LTRIM(RTRIM(ISNULL(lp.Code, ''))))
    )
)

-- DÜZELTİLEN ALAN: @StepOrder Filtresi (0 verilince tümü gelsin)
AND
(
    @StepOrder IS NULL
    OR @StepOrder = 0  -- 👈 YENİ EKLENDI: 0 verilince tüm kayıtlar gelir
    OR
    (
        @StepOrder = 10
        AND EXISTS
        (
            SELECT 1
            FROM tmscrq.TMLeadReservation r
            WHERE r.LeadId = l.Id
              AND r.IsActive = 1
              AND ISNULL(r.IsApproved,0) = 0
        )
    )
    OR
    (
        @StepOrder <> 10
        AND lp.StepOrder = @StepOrder
    )
)

AND
(
    @StartDate IS NULL
    OR LTRIM(RTRIM(@StartDate)) = ''
    OR l.CreatedAt >= CONVERT(date, @StartDate)
)

AND
(
    @EndDate IS NULL
    OR LTRIM(RTRIM(@EndDate)) = ''
    OR l.CreatedAt < DATEADD(day, 1, CONVERT(date, @EndDate))
)

ORDER BY l.CreatedAt DESC;", new string[] { "RezerveDurumu", "LeadId", "IsReserved", "LeadNumarasi", "TalepTarihi", "ProductId", "ProductName", "Bilezik", "Brand", "Kadran", "RefCode", "Referans", "Musteri", "Lokasyon", "Ilce", "Ulke", "MusteriInfo", "AlisverisiVarMi", "IrtibatNumarasi", "EmailAdresi", "IletisimKaynagi", "CategoryName", "CategoryCode", "LeadDurumu", "SonrakiAdim", "ProcessName", "ProcessCode", "StepOrder", "SelectedStepOrder", "TerminTarihi", "SatisDanismani", "StoreName" }, prms_TM_GetLeads_0.ToArray());
            ;

            var prms_TMLeadProcessCountSummary_1 = new List<kSqlParameter>();
            prms_TMLeadProcessCountSummary_1.Add(new kSqlParameter() { Name = "UserId", Value = Kuika.Common.KContext.CurrentUser?.Id });
            prms_TMLeadProcessCountSummary_1.Add(new kSqlParameter() { Name = "MusteriAdi", Value = request.MusteriAdi_1 });
            prms_TMLeadProcessCountSummary_1.Add(new kSqlParameter() { Name = "ProductName", Value = request.ProductName_1 });
            prms_TMLeadProcessCountSummary_1.Add(new kSqlParameter() { Name = "LeadCode", Value = request.LeadCode_1 });
            prms_TMLeadProcessCountSummary_1.Add(new kSqlParameter() { Name = "Tel", Value = request.Tel_1 });
            prms_TMLeadProcessCountSummary_1.Add(new kSqlParameter() { Name = "CategoryName", Value = request.CategoryName_1 });
            prms_TMLeadProcessCountSummary_1.Add(new kSqlParameter() { Name = "StoreIds", Value = request.StoreIds_1 });
            prms_TMLeadProcessCountSummary_1.Add(new kSqlParameter() { Name = "SatisDanismaniIds", Value = request.SatisDanismaniIds_1 });
            prms_TMLeadProcessCountSummary_1.Add(new kSqlParameter() { Name = "ProcessCode", Value = request.ProcessCode_1 });
            prms_TMLeadProcessCountSummary_1.Add(new kSqlParameter() { Name = "StartDate", Value = request.StartDate_1 });
            prms_TMLeadProcessCountSummary_1.Add(new kSqlParameter() { Name = "EndDate", Value = request.EndDate_1 });
            using var auditTMLeadProcessCountSummary_1 = ActionAuditScope.Begin("053d9657-1b26-8ccc-3957-343867946267", "TMLeadProcessCountSummary", applicationName: "wbTimesCRM", screenOrEndpointName: "LeadList");
            result.TMLeadProcessCountSummary = KPersister.Fetch(KContext.GetConnectionString(), @"-- SELECT
--     COUNT(*) AS ToplamTalepSayisi,

--     SUM(CASE WHEN lp.Code = 'PENDING' THEN 1 ELSE 0 END) AS OnayBekleyenSayisi,
--     SUM(CASE WHEN lp.Code = 'TERMIN_PENDING' THEN 1 ELSE 0 END) AS TerminBekleyenSayisi,
--     SUM(CASE WHEN lp.Code = 'APPROVED' THEN 1 ELSE 0 END) AS OnaylananSayisi,
--     SUM(CASE WHEN lp.Code = 'REJECTED' THEN 1 ELSE 0 END) AS ReddedilenSayisi,
--     SUM(CASE WHEN lp.Code = 'DELIVERY_PENDING' THEN 1 ELSE 0 END) AS TeslimEdilecekSayisi,
--     SUM(CASE WHEN lp.Code = 'DELIVERED' THEN 1 ELSE 0 END) AS TeslimEdildiSayisi

-- FROM tmscrq.TMLead l
-- LEFT JOIN tmscrq.TMCustomer cu
--     ON cu.Id = l.CustomerId
-- LEFT JOIN tmscrq.TMProduct p
--     ON p.Id = l.ProductId
-- LEFT JOIN dbo.KUser sp
--     ON sp.Id = l.SalesPersonKUserId
-- LEFT JOIN tmscrq.TMLeadProcess lp
--     ON lp.Id = l.ProcessID

-- WHERE
-- (
--     EXISTS
--     (
--         SELECT 1
--         FROM dbo.KUserRole ur
--         INNER JOIN dbo.KRole r
--             ON r.Id = ur.KRole_Id
--         WHERE ur.KUser_Id = @UserId
--           AND ur.IsDeleted = 0
--           AND r.IsDeleted = 0
--           AND r.Name IN ('TimesYonetici', 'TimesUstYonetici')
--     )
--     OR
--     (
--         EXISTS
--         (
--             SELECT 1
--             FROM dbo.KUserRole ur
--             INNER JOIN dbo.KRole r
--                 ON r.Id = ur.KRole_Id
--             WHERE ur.KUser_Id = @UserId
--               AND ur.IsDeleted = 0
--               AND r.IsDeleted = 0
--               AND r.Name IN ('TimesMagazaMuduru', 'TimesSatisPersoneli')
--         )
--         AND EXISTS
--         (
--             SELECT 1
--             FROM tmscrq.TMUser tu
--             WHERE tu.KUserID = @UserId
--               AND tu.StoreId = l.StoreId
--         )
--     )
-- )

-- AND
-- (
--     @MusteriAdi IS NULL
--     OR LTRIM(RTRIM(@MusteriAdi)) = ''
--     OR UPPER(LTRIM(RTRIM(ISNULL(cu.Name, '') + ' ' + ISNULL(cu.LastName, ''))))
--        LIKE '%' + UPPER(LTRIM(RTRIM(@MusteriAdi))) + '%'
-- )

-- AND
-- (
--     @ProductName IS NULL
--     OR LTRIM(RTRIM(@ProductName)) = ''
--     OR
--     (
--         CHARINDEX(',', @ProductName) > 0
--         AND ISNULL(LTRIM(RTRIM(p.ProductName)), '') IN
--         (
--             SELECT LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', '')))
--             FROM STRING_SPLIT(CAST(@ProductName AS NVARCHAR(MAX)), ',')
--             WHERE LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', ''))) <> ''
--         )
--     )
--     OR
--     (
--         CHARINDEX(',', @ProductName) = 0
--         AND UPPER(ISNULL(LTRIM(RTRIM(p.ProductName)), ''))
--             LIKE '%' + UPPER(LTRIM(RTRIM(@ProductName))) + '%'
--     )
-- )

-- AND
-- (
--     @LeadCode IS NULL
--     OR LTRIM(RTRIM(@LeadCode)) = ''
--     OR UPPER(ISNULL(LTRIM(RTRIM(l.LeadCode)), '')) LIKE '%' + UPPER(LTRIM(RTRIM(@LeadCode))) + '%'
-- )

-- AND
-- (
--     @Tel IS NULL
--     OR LTRIM(RTRIM(@Tel)) = ''
--     OR UPPER(ISNULL(LTRIM(RTRIM(cu.Tel)), '')) LIKE '%' + UPPER(LTRIM(RTRIM(@Tel))) + '%'
-- )

-- AND
-- (
--     @CategoryName IS NULL
--     OR LTRIM(RTRIM(@CategoryName)) = ''
--     OR
--     (
--         EXISTS
--         (
--             SELECT 1
--             FROM STRING_SPLIT(CAST(@CategoryName AS NVARCHAR(MAX)), ',') c
--             WHERE UPPER(LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(c.value, '""', ''), '[', ''), ']', '')))) = 'DEFAULT'
--         )
--         AND (p.CategoryName IS NULL OR LTRIM(RTRIM(p.CategoryName)) = '')
--     )
--     OR UPPER(ISNULL(LTRIM(RTRIM(p.CategoryName)), '')) IN
--     (
--         SELECT UPPER(LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', ''))))
--         FROM STRING_SPLIT(CAST(@CategoryName AS NVARCHAR(MAX)), ',')
--         WHERE LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', ''))) <> ''
--           AND UPPER(LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', '')))) <> 'DEFAULT'
--     )
-- )

-- AND
-- (
--     @StoreIds IS NULL
--     OR LTRIM(RTRIM(@StoreIds)) = ''
--     OR EXISTS
--     (
--         SELECT 1
--         FROM STRING_SPLIT(CAST(@StoreIds AS NVARCHAR(MAX)), ',') s
--         WHERE l.StoreId = TRY_CONVERT
--         (
--             uniqueidentifier,
--             LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(s.value, '""', ''), '[', ''), ']', '')))
--         )
--     )
-- )

-- AND
-- (
--     @SatisDanismaniIds IS NULL
--     OR LTRIM(RTRIM(@SatisDanismaniIds)) = ''
--     OR EXISTS
--     (
--         SELECT 1
--         FROM STRING_SPLIT(CAST(@SatisDanismaniIds AS NVARCHAR(MAX)), ',') s
--         WHERE l.SalesPersonKUserId = TRY_CONVERT
--         (
--             uniqueidentifier,
--             LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(s.value, '""', ''), '[', ''), ']', '')))
--         )
--     )
-- )

-- AND
-- (
--     @ProcessCode IS NULL
--     OR LTRIM(RTRIM(@ProcessCode)) = ''
--     OR UPPER(ISNULL(LTRIM(RTRIM(lp.Code)), '')) IN
--     (
--         SELECT UPPER(LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', ''))))
--         FROM STRING_SPLIT(CAST(@ProcessCode AS NVARCHAR(MAX)), ',')
--         WHERE LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', ''))) <> ''
--     )
-- )

-- AND
-- (
--     @StartDate IS NULL
--     OR LTRIM(RTRIM(@StartDate)) = ''
--     OR l.CreatedAt >= CONVERT(date, @StartDate)
-- )

-- AND
-- (
--     @EndDate IS NULL
--     OR LTRIM(RTRIM(@EndDate)) = ''
--     OR l.CreatedAt < DATEADD(day, 1, CONVERT(date, @EndDate))
-- );

-------------------------------------------------------------

DECLARE @KUserId UNIQUEIDENTIFIER = @UserId;

WITH UserRoles AS (
    SELECT r.Name
    FROM dbo.KUserRole ur
    INNER JOIN dbo.KRole r 
        ON r.Id = ur.KRole_Id
    WHERE ur.KUser_Id = @KUserId
      AND ur.IsDeleted = 0
      AND r.IsDeleted = 0
),
IsAdmin AS (
    SELECT CASE 
        WHEN EXISTS (
            SELECT 1 
            FROM UserRoles 
            WHERE Name = 'TimesUstYonetici'
        ) THEN 1 ELSE 0 END AS IsAdmin
)

SELECT
    COUNT(*) AS ToplamTalepSayisi,

    SUM(CASE WHEN lp.Code = 'PENDING' THEN 1 ELSE 0 END) AS OnayBekleyenSayisi,
    SUM(CASE WHEN lp.Code = 'TERMIN_PENDING' THEN 1 ELSE 0 END) AS TerminBekleyenSayisi,
    SUM(CASE WHEN lp.Code = 'APPROVED' THEN 1 ELSE 0 END) AS OnaylananSayisi,
    SUM(CASE WHEN lp.Code = 'REJECTED' THEN 1 ELSE 0 END) AS ReddedilenSayisi,
    SUM(CASE WHEN lp.Code = 'DELIVERY_PENDING' THEN 1 ELSE 0 END) AS TeslimEdilecekSayisi,
    SUM(CASE WHEN lp.Code = 'DELIVERED' THEN 1 ELSE 0 END) AS TeslimEdildiSayisi

FROM tmscrq.TMLead l
LEFT JOIN tmscrq.TMCustomer cu
    ON cu.Id = l.CustomerId
LEFT JOIN tmscrq.TMProduct p
    ON p.Id = l.ProductId
LEFT JOIN dbo.KUser sp
    ON sp.Id = l.SalesPersonKUserId
LEFT JOIN tmscrq.TMLeadProcess lp
    ON lp.Id = l.ProcessID

CROSS JOIN IsAdmin a

WHERE
(
    -- admin → full
    a.IsAdmin = 1

    -- diğerleri → sadece kendi mağazaları
    OR EXISTS
    (
        SELECT 1
        FROM tmscrq.TMUser tu
        WHERE tu.KUserID = @KUserId
          AND tu.StoreId = l.StoreId
    )
)

-- 🔽 AŞAĞISI SENİN ORİJİNAL FİLTRELER (HİÇ DOKUNMADIM)

AND
(
    @MusteriAdi IS NULL
    OR LTRIM(RTRIM(@MusteriAdi)) = ''
    OR UPPER(LTRIM(RTRIM(ISNULL(cu.Name, '') + ' ' + ISNULL(cu.LastName, ''))))
       LIKE '%' + UPPER(LTRIM(RTRIM(@MusteriAdi))) + '%'
)

AND
(
    @ProductName IS NULL
    OR LTRIM(RTRIM(@ProductName)) = ''
    OR
    (
        CHARINDEX(',', @ProductName) > 0
        AND ISNULL(LTRIM(RTRIM(p.ProductName)), '') IN
        (
            SELECT LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', '')))
            FROM STRING_SPLIT(CAST(@ProductName AS NVARCHAR(MAX)), ',')
        )
    )
    OR
    (
        CHARINDEX(',', @ProductName) = 0
        AND UPPER(ISNULL(LTRIM(RTRIM(p.ProductName)), ''))
            LIKE '%' + UPPER(LTRIM(RTRIM(@ProductName))) + '%'
    )
)

AND
(
    @LeadCode IS NULL
    OR LTRIM(RTRIM(@LeadCode)) = ''
    OR UPPER(ISNULL(LTRIM(RTRIM(l.LeadCode)), '')) LIKE '%' + UPPER(LTRIM(RTRIM(@LeadCode))) + '%'
)

AND
(
    @Tel IS NULL
    OR LTRIM(RTRIM(@Tel)) = ''
    OR UPPER(ISNULL(LTRIM(RTRIM(cu.Tel)), '')) LIKE '%' + UPPER(LTRIM(RTRIM(@Tel))) + '%'
)

AND
(
    @CategoryName IS NULL
    OR LTRIM(RTRIM(@CategoryName)) = ''
    OR
    (
        EXISTS
        (
            SELECT 1
            FROM STRING_SPLIT(CAST(@CategoryName AS NVARCHAR(MAX)), ',') c
            WHERE UPPER(LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(c.value, '""', ''), '[', ''), ']', '')))) = 'DEFAULT'
        )
        AND (p.CategoryName IS NULL OR LTRIM(RTRIM(p.CategoryName)) = '')
    )
    OR UPPER(ISNULL(LTRIM(RTRIM(p.CategoryName)), '')) IN
    (
        SELECT UPPER(LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', ''))))
        FROM STRING_SPLIT(CAST(@CategoryName AS NVARCHAR(MAX)), ',')
    )
)

AND
(
    @StoreIds IS NULL
    OR LTRIM(RTRIM(@StoreIds)) = ''
    OR EXISTS
    (
        SELECT 1
        FROM STRING_SPLIT(CAST(@StoreIds AS NVARCHAR(MAX)), ',') s
        WHERE l.StoreId = TRY_CONVERT
        (
            uniqueidentifier,
            LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(s.value, '""', ''), '[', ''), ']', '')))
        )
    )
)

AND
(
    @SatisDanismaniIds IS NULL
    OR LTRIM(RTRIM(@SatisDanismaniIds)) = ''
    OR EXISTS
    (
        SELECT 1
        FROM STRING_SPLIT(CAST(@SatisDanismaniIds AS NVARCHAR(MAX)), ',') s
        WHERE l.SalesPersonKUserId = TRY_CONVERT
        (
            uniqueidentifier,
            LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(s.value, '""', ''), '[', ''), ']', '')))
        )
    )
)

AND
(
    @ProcessCode IS NULL
    OR LTRIM(RTRIM(@ProcessCode)) = ''
    OR UPPER(ISNULL(LTRIM(RTRIM(lp.Code)), '')) IN
    (
        SELECT UPPER(LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', ''))))
        FROM STRING_SPLIT(CAST(@ProcessCode AS NVARCHAR(MAX)), ',')
    )
)

AND
(
    @StartDate IS NULL
    OR LTRIM(RTRIM(@StartDate)) = ''
    OR l.CreatedAt >= CONVERT(date, @StartDate)
)

AND
(
    @EndDate IS NULL
    OR LTRIM(RTRIM(@EndDate)) = ''
    OR l.CreatedAt < DATEADD(day, 1, CONVERT(date, @EndDate))
);", new string[] { "ToplamTalepSayisi", "OnayBekleyenSayisi", "TerminBekleyenSayisi", "OnaylananSayisi", "ReddedilenSayisi", "TeslimEdilecekSayisi", "TeslimEdildiSayisi" }, prms_TMLeadProcessCountSummary_1.ToArray());
            ;


            return Ok(result);
        }


        [HttpPost, Route("LeadListComponent_776113_onChange")]
        public IActionResult LeadListComponent_776113_onChange(LeadListComponent_776113_onChange_Request request)
        {

            KProviderManager.Authorization.IsAuthorizedForRoles(appId, appName, screenId, screenName, new List<string> { $"70de6cfc-6087-6059-59b4-0b5a8527af6b", "4da1f213-c8e4-0b50-5c84-02fd13f1a622", "c4e882ef-977d-f613-7694-230ac83919d2", "b4bfd39c-ac02-f442-c899-7a2374a45b47", "cdb536b0-6297-155f-d446-8453d8a60304", "TimesYonetici", "TimesUstYonetici", "TimesSatisPersoneli", "TimesMagazaMuduru", "TimesAdmin" });

            var result = new LeadListComponent_776113_onChange_Response();

            var prms_TM_GetLeads_0 = new List<kSqlParameter>();
            prms_TM_GetLeads_0.Add(new kSqlParameter() { Name = "StepOrder", Value = request.StepOrder_0 });
            prms_TM_GetLeads_0.Add(new kSqlParameter() { Name = "UserId", Value = Kuika.Common.KContext.CurrentUser?.Id });
            prms_TM_GetLeads_0.Add(new kSqlParameter() { Name = "MusteriAdi", Value = request.MusteriAdi_0 });
            prms_TM_GetLeads_0.Add(new kSqlParameter() { Name = "ProductName", Value = request.ProductName_0 });
            prms_TM_GetLeads_0.Add(new kSqlParameter() { Name = "LeadCode", Value = request.LeadCode_0 });
            prms_TM_GetLeads_0.Add(new kSqlParameter() { Name = "Tel", Value = request.Tel_0 });
            prms_TM_GetLeads_0.Add(new kSqlParameter() { Name = "CategoryName", Value = request.CategoryName_0 });
            prms_TM_GetLeads_0.Add(new kSqlParameter() { Name = "StoreIds", Value = request.StoreIds_0 });
            prms_TM_GetLeads_0.Add(new kSqlParameter() { Name = "SatisDanismaniIds", Value = request.SatisDanismaniIds_0 });
            prms_TM_GetLeads_0.Add(new kSqlParameter() { Name = "ProcessCode", Value = request.ProcessCode_0 });
            prms_TM_GetLeads_0.Add(new kSqlParameter() { Name = "StartDate", Value = request.StartDate_0 });
            prms_TM_GetLeads_0.Add(new kSqlParameter() { Name = "EndDate", Value = request.EndDate_0 });
            using var auditTM_GetLeads_0 = ActionAuditScope.Begin("91b07322-ce00-0776-5533-7b37d78b25ca", "TM_GetLeads", applicationName: "wbTimesCRM", screenOrEndpointName: "LeadList");
            result.TM_GetLeads = KPersister.Fetch(KContext.GetConnectionString(), @"-- SET LANGUAGE Turkish;

-- SELECT
-- CASE 
--     WHEN EXISTS (
--         SELECT 1 
--         FROM tmscrq.TMLeadReservation r
--         WHERE r.LeadId = l.Id
--           AND r.IsActive = 1
--           AND r.IsApproved = 1
--     ) THEN N'Evet'

--     WHEN EXISTS (
--         SELECT 1 
--         FROM tmscrq.TMLeadReservation r
--         WHERE r.LeadId = l.Id
--           AND r.IsActive = 1
--           AND ISNULL(r.IsApproved,0) = 0
--     ) THEN N'Onay Bekliyor'

--     ELSE N'Hayır'
-- END AS RezerveDurumu,
--     l.Id AS LeadId,
--     l.IsReserved,
--     ISNULL(NULLIF(LTRIM(RTRIM(l.LeadCode)), ''), '-') AS LeadNumarasi,
--     CONVERT(varchar(10), l.CreatedAt, 103) AS TalepTarihi,

--     p.Id AS ProductId,
--     ISNULL(NULLIF(LTRIM(RTRIM(p.ProductName)), ''), '-') AS ProductName,
--     ISNULL(NULLIF(LTRIM(RTRIM(p.Bracelet)), ''), '-') AS Bilezik,
--     ISNULL(NULLIF(LTRIM(RTRIM(p.Brand)), ''), '-') AS Brand,
--     ISNULL(NULLIF(LTRIM(RTRIM(p.Dial)), ''), '-') AS Kadran,
--     ISNULL(NULLIF(LTRIM(RTRIM(p.ProductCode)), ''), '-') AS RefCode,
--     ISNULL(NULLIF(LTRIM(RTRIM(p.Referance)), ''), '-') AS Referans,

--     ISNULL(
--         NULLIF(
--             LTRIM(RTRIM(ISNULL(cu.Name, '') + ' ' + ISNULL(cu.LastName, '')))
--         , '')
--     , '-') AS Musteri,

--     ISNULL(NULLIF(LTRIM(RTRIM(cu.CityName)), ''), '-') AS Lokasyon,
--     ISNULL(NULLIF(LTRIM(RTRIM(cu.DistrictName)), ''), '-') AS Ilce,
--     ISNULL(NULLIF(LTRIM(RTRIM(cu.CountryName)), ''), '-') AS Ulke,
--     ISNULL(NULLIF(LTRIM(RTRIM(cu.Info)), ''), '-') AS MusteriInfo,

--     CASE
--         WHEN cu.IsShopping = 1 THEN N'Evet'
--         WHEN cu.IsShopping = 0 THEN N'Hayır'
--         ELSE '-'
--     END AS AlisverisiVarMi,

--     ISNULL(NULLIF(LTRIM(RTRIM(cu.Tel)), ''), '-') AS IrtibatNumarasi,
--     ISNULL(NULLIF(LTRIM(RTRIM(cu.Email)), ''), '-') AS EmailAdresi,

--     ISNULL(NULLIF(LTRIM(RTRIM(cr.ContactResourceName)), ''), '-') AS IletisimKaynagi,

--     ISNULL(NULLIF(LTRIM(RTRIM(p.CategoryName)), ''), '-') AS CategoryName,
--     '-' AS CategoryCode,

--     ISNULL(NULLIF(LTRIM(RTRIM(ls.Name)), ''), '-') AS LeadDurumu,
--     ISNULL(NULLIF(LTRIM(RTRIM(ns.Name)), ''), '-') AS SonrakiAdim,

--     ISNULL(NULLIF(LTRIM(RTRIM(lp.Name)), ''), '-') AS ProcessName,
--     ISNULL(NULLIF(LTRIM(RTRIM(lp.Code)), ''), '-') AS ProcessCode,
--     lp.StepOrder,
-- CASE
--     WHEN EXISTS
--     (
--         SELECT 1
--         FROM tmscrq.TMLeadReservation r
--         WHERE r.LeadId = l.Id
--           AND r.IsActive = 1
--           AND ISNULL(r.IsApproved,0) = 0
--     )
--     THEN 10
--     ELSE lp.StepOrder
-- END AS SelectedStepOrder,

--     ISNULL(
--         CASE
--             WHEN l.EstimatedDate IS NOT NULL
--             THEN CAST(YEAR(l.EstimatedDate) AS VARCHAR(4)) + ' ' + DATENAME(MONTH, l.EstimatedDate)
--             ELSE NULL
--         END,
--         '-'
--     ) AS TerminTarihi,

--     ISNULL(
--         NULLIF(
--             LTRIM(RTRIM(ISNULL(sp.FirstName, '') + ' ' + ISNULL(sp.LastName, '')))
--         , '')
--     , '-') AS SatisDanismani,

--     ISNULL(NULLIF(LTRIM(RTRIM(st.StoreDesc)), ''), '-') AS StoreName

-- FROM tmscrq.TMLead l
-- LEFT JOIN tmscrq.TMLeadStatu ls
--     ON ls.Id = l.StatuId
-- LEFT JOIN tmscrq.TMCustomer cu
--     ON cu.Id = l.CustomerId
-- LEFT JOIN tmscrq.TMProduct p
--     ON p.Id = l.ProductId
-- LEFT JOIN tmscrq.TMContactResource cr
--     ON cr.Id = l.ContactResourceId
-- LEFT JOIN dbo.KUser sp
--     ON sp.Id = l.SalesPersonKUserId
-- LEFT JOIN tmscrq.TMStore st
--     ON st.Id = l.StoreId
-- LEFT JOIN tmscrq.TMLeadProcess lp
--     ON lp.Id = l.ProcessID
-- LEFT JOIN tmscrq.TMLeadNextStep ns
--     ON ns.Id = l.NextStepId

-- WHERE
-- (
--     EXISTS
--     (
--         SELECT 1
--         FROM dbo.KUserRole ur
--         INNER JOIN dbo.KRole r
--             ON r.Id = ur.KRole_Id
--         WHERE ur.KUser_Id = @UserId
--           AND ur.IsDeleted = 0
--           AND r.IsDeleted = 0
--           AND r.Name IN ('TimesYonetici', 'TimesUstYonetici')
--     )
--     OR
--     (
--         EXISTS
--         (
--             SELECT 1
--             FROM dbo.KUserRole ur
--             INNER JOIN dbo.KRole r
--                 ON r.Id = ur.KRole_Id
--             WHERE ur.KUser_Id = @UserId
--               AND ur.IsDeleted = 0
--               AND r.IsDeleted = 0
--               AND r.Name IN ('TimesMagazaMuduru', 'TimesSatisPersoneli')
--         )
--         AND EXISTS
--         (
--             SELECT 1
--             FROM tmscrq.TMUser tu
--             WHERE tu.KUserID = @UserId
--               AND tu.StoreId = l.StoreId
--         )
--     )
-- )

-- AND
-- (
--     @MusteriAdi IS NULL
--     OR LTRIM(RTRIM(@MusteriAdi)) = ''
--     OR UPPER(LTRIM(RTRIM(ISNULL(cu.Name,'') + ' ' + ISNULL(cu.LastName,''))))
--        LIKE '%' + UPPER(LTRIM(RTRIM(@MusteriAdi))) + '%'
-- )

-- AND
-- (
--     @ProductName IS NULL
--     OR LTRIM(RTRIM(@ProductName)) = ''
--     OR
--     (
--         CHARINDEX(',', @ProductName) > 0
--         AND ISNULL(LTRIM(RTRIM(p.ProductName)), '') IN
--         (
--             SELECT LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', '')))
--             FROM STRING_SPLIT(CAST(@ProductName AS NVARCHAR(MAX)), ',')
--             WHERE LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', ''))) <> ''
--         )
--     )
--     OR
--     (
--         CHARINDEX(',', @ProductName) = 0
--         AND UPPER(ISNULL(LTRIM(RTRIM(p.ProductName)), ''))
--             LIKE '%' + UPPER(LTRIM(RTRIM(@ProductName))) + '%'
--     )
-- )

-- AND
-- (
--     @LeadCode IS NULL
--     OR LTRIM(RTRIM(@LeadCode)) = ''
--     OR UPPER(ISNULL(LTRIM(RTRIM(l.LeadCode)), '')) LIKE '%' + UPPER(LTRIM(RTRIM(@LeadCode))) + '%'
-- )

-- AND
-- (
--     @Tel IS NULL
--     OR LTRIM(RTRIM(@Tel)) = ''
--     OR UPPER(ISNULL(LTRIM(RTRIM(cu.Tel)), '')) LIKE '%' + UPPER(LTRIM(RTRIM(@Tel))) + '%'
-- )

-- -- AND
-- -- (
-- --     @CategoryName IS NULL
-- --     OR LTRIM(RTRIM(@CategoryName)) = ''
-- --     OR
-- --     (
-- --         EXISTS
-- --         (
-- --             SELECT 1
-- --             FROM STRING_SPLIT(CAST(@CategoryName AS NVARCHAR(MAX)), ',') c
-- --             WHERE UPPER(LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(c.value, '""', ''), '[', ''), ']', '')))) = 'DEFAULT'
-- --         )
-- --         AND (p.CategoryName IS NULL OR LTRIM(RTRIM(p.CategoryName)) = '')
-- --     )
-- --     OR UPPER(ISNULL(LTRIM(RTRIM(p.CategoryName)), '')) IN
-- --     (
-- --         SELECT UPPER(LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', ''))))
-- --         FROM STRING_SPLIT(CAST(@CategoryName AS NVARCHAR(MAX)), ',')
-- --         WHERE LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', ''))) <> ''
-- --           AND UPPER(LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', '')))) <> 'DEFAULT'
-- --     )
-- -- )

-- AND
-- (
--     @CategoryName IS NULL
--     OR LTRIM(RTRIM(@CategoryName)) = ''
--     OR UPPER(ISNULL(LTRIM(RTRIM(p.CategoryName)), '')) IN
--     (
--         SELECT UPPER(LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value,'""',''),'[',''),']',''))))
--         FROM STRING_SPLIT(CAST(@CategoryName AS NVARCHAR(MAX)), ',')
--         WHERE LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value,'""',''),'[',''),']',''))) <> ''
--     )
-- )

-- AND
-- (
--     @StoreIds IS NULL
--     OR LTRIM(RTRIM(@StoreIds)) = ''
--     OR EXISTS
--     (
--         SELECT 1
--         FROM STRING_SPLIT(CAST(@StoreIds AS NVARCHAR(MAX)), ',') s
--         WHERE l.StoreId = TRY_CONVERT
--         (
--             uniqueidentifier,
--             LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(s.value, '""', ''), '[', ''), ']', '')))
--         )
--     )
-- )

-- AND
-- (
--     @SatisDanismaniIds IS NULL
--     OR LTRIM(RTRIM(@SatisDanismaniIds)) = ''
--     OR EXISTS
--     (
--         SELECT 1
--         FROM STRING_SPLIT(CAST(@SatisDanismaniIds AS NVARCHAR(MAX)), ',') s
--         WHERE l.SalesPersonKUserId = TRY_CONVERT
--         (
--             uniqueidentifier,
--             LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(s.value, '""', ''), '[', ''), ']', '')))
--         )
--     )
-- )

-- AND
-- (
--     @ProcessCode IS NULL
--     OR LTRIM(RTRIM(@ProcessCode)) = ''
--     OR UPPER(ISNULL(LTRIM(RTRIM(lp.Code)), '')) IN
--     (
--         SELECT UPPER(LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', ''))))
--         FROM STRING_SPLIT(CAST(@ProcessCode AS NVARCHAR(MAX)), ',')
--         WHERE LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', ''))) <> ''
--     )
-- )

-- AND
-- (
--     @StepOrder IS NULL

--     OR
--     (
--         @StepOrder = 10
--         AND EXISTS
--         (
--             SELECT 1
--             FROM tmscrq.TMLeadReservation r
--             WHERE r.LeadId = l.Id
--               AND r.IsActive = 1
--               AND ISNULL(r.IsApproved,0) = 0
--         )
--     )

--     OR
--     (
--         @StepOrder <> 10
--         AND lp.StepOrder = @StepOrder
--     )
-- )

-- AND
-- (
--     @StartDate IS NULL
--     OR LTRIM(RTRIM(@StartDate)) = ''
--     OR l.CreatedAt >= CONVERT(date, @StartDate)
-- )

-- AND
-- (
--     @EndDate IS NULL
--     OR LTRIM(RTRIM(@EndDate)) = ''
--     OR l.CreatedAt < DATEADD(day, 1, CONVERT(date, @EndDate))
-- )

-- ORDER BY l.CreatedAt DESC;

------------------------++++++++++++++++++++++++-------------------
-- SET LANGUAGE Turkish;

-- SELECT
-- CASE 
--     WHEN EXISTS (
--         SELECT 1 
--         FROM tmscrq.TMLeadReservation r
--         WHERE r.LeadId = l.Id
--           AND r.IsActive = 1
--           AND r.IsApproved = 1
--     ) THEN N'Evet'

--     WHEN EXISTS (
--         SELECT 1 
--         FROM tmscrq.TMLeadReservation r
--         WHERE r.LeadId = l.Id
--           AND r.IsActive = 1
--           AND ISNULL(r.IsApproved,0) = 0
--     ) THEN N'Onay Bekliyor'

--     ELSE N'Hayır'
-- END AS RezerveDurumu,
--     l.Id AS LeadId,
--     l.IsReserved,
--     ISNULL(NULLIF(LTRIM(RTRIM(l.LeadCode)), ''), '-') AS LeadNumarasi,
--     CONVERT(varchar(10), l.CreatedAt, 103) AS TalepTarihi,

--     p.Id AS ProductId,
--     ISNULL(NULLIF(LTRIM(RTRIM(p.ProductName)), ''), '-') AS ProductName,
--     ISNULL(NULLIF(LTRIM(RTRIM(p.Bracelet)), ''), '-') AS Bilezik,
--     ISNULL(NULLIF(LTRIM(RTRIM(p.Brand)), ''), '-') AS Brand,
--     ISNULL(NULLIF(LTRIM(RTRIM(p.Dial)), ''), '-') AS Kadran,
--     ISNULL(NULLIF(LTRIM(RTRIM(p.ProductCode)), ''), '-') AS RefCode,
--     ISNULL(NULLIF(LTRIM(RTRIM(p.Referance)), ''), '-') AS Referans,

--     ISNULL(
--         NULLIF(
--             LTRIM(RTRIM(ISNULL(cu.Name, '') + ' ' + ISNULL(cu.LastName, '')))
--         , '')
--     , '-') AS Musteri,

--     ISNULL(NULLIF(LTRIM(RTRIM(cu.CityName)), ''), '-') AS Lokasyon,
--     ISNULL(NULLIF(LTRIM(RTRIM(cu.DistrictName)), ''), '-') AS Ilce,
--     ISNULL(NULLIF(LTRIM(RTRIM(cu.CountryName)), ''), '-') AS Ulke,
--     ISNULL(NULLIF(LTRIM(RTRIM(cu.Info)), ''), '-') AS MusteriInfo,

--     CASE
--         WHEN cu.IsShopping = 1 THEN N'Evet'
--         WHEN cu.IsShopping = 0 THEN N'Hayır'
--         ELSE '-'
--     END AS AlisverisiVarMi,

--     ISNULL(NULLIF(LTRIM(RTRIM(cu.Tel)), ''), '-') AS IrtibatNumarasi,
--     ISNULL(NULLIF(LTRIM(RTRIM(cu.Email)), ''), '-') AS EmailAdresi,

--     ISNULL(NULLIF(LTRIM(RTRIM(cr.ContactResourceName)), ''), '-') AS IletisimKaynagi,

--     ISNULL(NULLIF(LTRIM(RTRIM(p.CategoryName)), ''), '-') AS CategoryName,
--     '-' AS CategoryCode,

--     ISNULL(NULLIF(LTRIM(RTRIM(ls.Name)), ''), '-') AS LeadDurumu,
--     ISNULL(NULLIF(LTRIM(RTRIM(ns.Name)), ''), '-') AS SonrakiAdim,

--     ISNULL(NULLIF(LTRIM(RTRIM(lp.Name)), ''), '-') AS ProcessName,
--     ISNULL(NULLIF(LTRIM(RTRIM(lp.Code)), ''), '-') AS ProcessCode,
--     lp.StepOrder,
    
--     -- DÜZELTİLEN ALAN: SelectedStepOrder
--     CASE
--         WHEN EXISTS
--         (
--             SELECT 1
--             FROM tmscrq.TMLeadReservation r
--             WHERE r.LeadId = l.Id
--               AND r.IsActive = 1
--               AND ISNULL(r.IsApproved,0) = 0
--         )
--         THEN 10
--         ELSE lp.StepOrder
--     END AS SelectedStepOrder,

--     ISNULL(
--         CASE
--             WHEN l.EstimatedDate IS NOT NULL
--             THEN CAST(YEAR(l.EstimatedDate) AS VARCHAR(4)) + ' ' + DATENAME(MONTH, l.EstimatedDate)
--             ELSE NULL
--         END,
--         '-'
--     ) AS TerminTarihi,

--     ISNULL(
--         NULLIF(
--             LTRIM(RTRIM(ISNULL(sp.FirstName, '') + ' ' + ISNULL(sp.LastName, '')))
--         , '')
--     , '-') AS SatisDanismani,

--     ISNULL(NULLIF(LTRIM(RTRIM(st.StoreDesc)), ''), '-') AS StoreName

-- FROM tmscrq.TMLead l
-- LEFT JOIN tmscrq.TMLeadStatu ls
--     ON ls.Id = l.StatuId
-- LEFT JOIN tmscrq.TMCustomer cu
--     ON cu.Id = l.CustomerId
-- LEFT JOIN tmscrq.TMProduct p
--     ON p.Id = l.ProductId
-- LEFT JOIN tmscrq.TMContactResource cr
--     ON cr.Id = l.ContactResourceId
-- LEFT JOIN dbo.KUser sp
--     ON sp.Id = l.SalesPersonKUserId
-- LEFT JOIN tmscrq.TMStore st
--     ON st.Id = l.StoreId
-- LEFT JOIN tmscrq.TMLeadProcess lp
--     ON lp.Id = l.ProcessID
-- LEFT JOIN tmscrq.TMLeadNextStep ns
--     ON ns.Id = l.NextStepId

-- WHERE
-- (
--     EXISTS
--     (
--         SELECT 1
--         FROM dbo.KUserRole ur
--         INNER JOIN dbo.KRole r
--             ON r.Id = ur.KRole_Id
--         WHERE ur.KUser_Id = @UserId
--           AND ur.IsDeleted = 0
--           AND r.IsDeleted = 0
--           AND r.Name IN ('TimesYonetici', 'TimesUstYonetici')
--     )
--     OR
--     (
--         EXISTS
--         (
--             SELECT 1
--             FROM dbo.KUserRole ur
--             INNER JOIN dbo.KRole r
--                 ON r.Id = ur.KRole_Id
--             WHERE ur.KUser_Id = @UserId
--               AND ur.IsDeleted = 0
--               AND r.IsDeleted = 0
--               AND r.Name IN ('TimesMagazaMuduru', 'TimesSatisPersoneli')
--         )
--         AND EXISTS
--         (
--             SELECT 1
--             FROM tmscrq.TMUser tu
--             WHERE tu.KUserID = @UserId
--               AND tu.StoreId = l.StoreId
--         )
--     )
-- )

-- AND
-- (
--     @MusteriAdi IS NULL
--     OR LTRIM(RTRIM(@MusteriAdi)) = ''
--     OR UPPER(LTRIM(RTRIM(ISNULL(cu.Name,'') + ' ' + ISNULL(cu.LastName,''))))
--        LIKE '%' + UPPER(LTRIM(RTRIM(@MusteriAdi))) + '%'
-- )

-- AND
-- (
--     @ProductName IS NULL
--     OR LTRIM(RTRIM(@ProductName)) = ''
--     OR
--     (
--         CHARINDEX(',', @ProductName) > 0
--         AND ISNULL(LTRIM(RTRIM(p.ProductName)), '') IN
--         (
--             SELECT LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', '')))
--             FROM STRING_SPLIT(CAST(@ProductName AS NVARCHAR(MAX)), ',')
--             WHERE LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', ''))) <> ''
--         )
--     )
--     OR
--     (
--         CHARINDEX(',', @ProductName) = 0
--         AND UPPER(ISNULL(LTRIM(RTRIM(p.ProductName)), ''))
--             LIKE '%' + UPPER(LTRIM(RTRIM(@ProductName))) + '%'
--     )
-- )

-- AND
-- (
--     @LeadCode IS NULL
--     OR LTRIM(RTRIM(@LeadCode)) = ''
--     OR UPPER(ISNULL(LTRIM(RTRIM(l.LeadCode)), '')) LIKE '%' + UPPER(LTRIM(RTRIM(@LeadCode))) + '%'
-- )

-- AND
-- (
--     @Tel IS NULL
--     OR LTRIM(RTRIM(@Tel)) = ''
--     OR UPPER(ISNULL(LTRIM(RTRIM(cu.Tel)), '')) LIKE '%' + UPPER(LTRIM(RTRIM(@Tel))) + '%'
-- )

-- AND
-- (
--     @CategoryName IS NULL
--     OR LTRIM(RTRIM(@CategoryName)) = ''
--     OR UPPER(ISNULL(LTRIM(RTRIM(p.CategoryName)), '')) IN
--     (
--         SELECT UPPER(LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value,'""',''),'[',''),']',''))))
--         FROM STRING_SPLIT(CAST(@CategoryName AS NVARCHAR(MAX)), ',')
--         WHERE LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value,'""',''),'[',''),']',''))) <> ''
--     )
-- )

-- AND
-- (
--     @StoreIds IS NULL
--     OR LTRIM(RTRIM(@StoreIds)) = ''
--     OR EXISTS
--     (
--         SELECT 1
--         FROM STRING_SPLIT(CAST(@StoreIds AS NVARCHAR(MAX)), ',') s
--         WHERE l.StoreId = TRY_CONVERT
--         (
--             uniqueidentifier,
--             LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(s.value, '""', ''), '[', ''), ']', '')))
--         )
--     )
-- )

-- AND
-- (
--     @SatisDanismaniIds IS NULL
--     OR LTRIM(RTRIM(@SatisDanismaniIds)) = ''
--     OR EXISTS
--     (
--         SELECT 1
--         FROM STRING_SPLIT(CAST(@SatisDanismaniIds AS NVARCHAR(MAX)), ',') s
--         WHERE l.SalesPersonKUserId = TRY_CONVERT
--         (
--             uniqueidentifier,
--             LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(s.value, '""', ''), '[', ''), ']', '')))
--         )
--     )
-- )

-- AND
-- (
--     @ProcessCode IS NULL
--     OR LTRIM(RTRIM(@ProcessCode)) = ''
--     OR UPPER(ISNULL(LTRIM(RTRIM(lp.Code)), '')) IN
--     (
--         SELECT UPPER(LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', ''))))
--         FROM STRING_SPLIT(CAST(@ProcessCode AS NVARCHAR(MAX)), ',')
--         WHERE LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', ''))) <> ''
--     )
-- )

-- -- DÜZELTİLEN ALAN: @StepOrder Filtresi (tek blok)
-- AND
-- (
--     @StepOrder IS NULL

--     OR

--     (
--         @StepOrder = 10
--         AND EXISTS
--         (
--             SELECT 1
--             FROM tmscrq.TMLeadReservation r
--             WHERE r.LeadId = l.Id
--               AND r.IsActive = 1
--               AND ISNULL(r.IsApproved,0) = 0
--         )
--     )

--     OR

--     (
--         @StepOrder <> 10
--         AND lp.StepOrder = @StepOrder
--     )
-- )

-- AND
-- (
--     @StartDate IS NULL
--     OR LTRIM(RTRIM(@StartDate)) = ''
--     OR l.CreatedAt >= CONVERT(date, @StartDate)
-- )

-- AND
-- (
--     @EndDate IS NULL
--     OR LTRIM(RTRIM(@EndDate)) = ''
--     OR l.CreatedAt < DATEADD(day, 1, CONVERT(date, @EndDate))
-- )

-- ORDER BY l.CreatedAt DESC;



SET LANGUAGE Turkish;

SELECT
CASE 
    WHEN EXISTS (
        SELECT 1 
        FROM tmscrq.TMLeadReservation r
        WHERE r.LeadId = l.Id
          AND r.IsActive = 1
          AND r.IsApproved = 1
    ) THEN N'Evet'

    WHEN EXISTS (
        SELECT 1 
        FROM tmscrq.TMLeadReservation r
        WHERE r.LeadId = l.Id
          AND r.IsActive = 1
          AND ISNULL(r.IsApproved,0) = 0
    ) THEN N'Onay Bekliyor'

    ELSE N'Hayır'
END AS RezerveDurumu,
    l.Id AS LeadId,
    l.IsReserved,
    ISNULL(NULLIF(LTRIM(RTRIM(l.LeadCode)), ''), '-') AS LeadNumarasi,
     FORMAT(l.CreatedAt, 'dd MMMM yyyy', 'tr-TR') AS TalepTarihi,

    p.Id AS ProductId,
    ISNULL(NULLIF(LTRIM(RTRIM(p.ProductName)), ''), '-') AS ProductName,
    ISNULL(NULLIF(LTRIM(RTRIM(p.Bracelet)), ''), '-') AS Bilezik,
    ISNULL(NULLIF(LTRIM(RTRIM(p.Brand)), ''), '-') AS Brand,
    ISNULL(NULLIF(LTRIM(RTRIM(p.Dial)), ''), '-') AS Kadran,
    ISNULL(NULLIF(LTRIM(RTRIM(p.ProductCode)), ''), '-') AS RefCode,
    ISNULL(NULLIF(LTRIM(RTRIM(p.Referance)), ''), '-') AS Referans,

    ISNULL(
        NULLIF(
            LTRIM(RTRIM(ISNULL(cu.Name, '') + ' ' + ISNULL(cu.LastName, '')))
        , '')
    , '-') AS Musteri,

    ISNULL(NULLIF(LTRIM(RTRIM(cu.CityName)), ''), '-') AS Lokasyon,
    ISNULL(NULLIF(LTRIM(RTRIM(cu.DistrictName)), ''), '-') AS Ilce,
    ISNULL(NULLIF(LTRIM(RTRIM(cu.CountryName)), ''), '-') AS Ulke,
    ISNULL(NULLIF(LTRIM(RTRIM(cu.Info)), ''), '-') AS MusteriInfo,

    CASE
        WHEN cu.IsShopping = 1 THEN N'Evet'
        WHEN cu.IsShopping = 0 THEN N'Hayır'
        ELSE '-'
    END AS AlisverisiVarMi,

    ISNULL(NULLIF(LTRIM(RTRIM(cu.Tel)), ''), '-') AS IrtibatNumarasi,
    ISNULL(NULLIF(LTRIM(RTRIM(cu.Email)), ''), '-') AS EmailAdresi,

    ISNULL(NULLIF(LTRIM(RTRIM(cr.ContactResourceName)), ''), '-') AS IletisimKaynagi,

    ISNULL(NULLIF(LTRIM(RTRIM(p.CategoryName)), ''), '-') AS CategoryName,
    '-' AS CategoryCode,

    ISNULL(NULLIF(LTRIM(RTRIM(ls.Name)), ''), '-') AS LeadDurumu,
    ISNULL(NULLIF(LTRIM(RTRIM(ns.Name)), ''), '-') AS SonrakiAdim,

    ISNULL(NULLIF(LTRIM(RTRIM(lp.Name)), ''), '-') AS ProcessName,
    ISNULL(NULLIF(LTRIM(RTRIM(lp.Code)), ''), '-') AS ProcessCode,
    lp.StepOrder,
    
    -- DÜZELTİLEN ALAN: SelectedStepOrder
    CASE
        WHEN EXISTS
        (
            SELECT 1
            FROM tmscrq.TMLeadReservation r
            WHERE r.LeadId = l.Id
              AND r.IsActive = 1
              AND ISNULL(r.IsApproved,0) = 0
        )
        THEN 10
        ELSE lp.StepOrder
    END AS SelectedStepOrder,

    ISNULL(
        CASE
            WHEN l.EstimatedDate IS NOT NULL
            THEN CAST(YEAR(l.EstimatedDate) AS VARCHAR(4)) + ' ' + DATENAME(MONTH, l.EstimatedDate)
            ELSE NULL
        END,
        '-'
    ) AS TerminTarihi,

    ISNULL(
        NULLIF(
            LTRIM(RTRIM(ISNULL(sp.FirstName, '') + ' ' + ISNULL(sp.LastName, '')))
        , '')
    , '-') AS SatisDanismani,

    ISNULL(NULLIF(LTRIM(RTRIM(st.StoreDesc)), ''), '-') AS StoreName

FROM tmscrq.TMLead l
LEFT JOIN tmscrq.TMLeadStatu ls
    ON ls.Id = l.StatuId
LEFT JOIN tmscrq.TMCustomer cu
    ON cu.Id = l.CustomerId
LEFT JOIN tmscrq.TMProduct p
    ON p.Id = l.ProductId
LEFT JOIN tmscrq.TMContactResource cr
    ON cr.Id = l.ContactResourceId
LEFT JOIN dbo.KUser sp
    ON sp.Id = l.SalesPersonKUserId
LEFT JOIN tmscrq.TMStore st
    ON st.Id = l.StoreId
LEFT JOIN tmscrq.TMLeadProcess lp
    ON lp.Id = l.ProcessID
LEFT JOIN tmscrq.TMLeadNextStep ns
    ON ns.Id = l.NextStepId

WHERE
(
    EXISTS
    (
        SELECT 1
        FROM dbo.KUserRole ur
        INNER JOIN dbo.KRole r
            ON r.Id = ur.KRole_Id
        WHERE ur.KUser_Id = @UserId
          AND ur.IsDeleted = 0
          AND r.IsDeleted = 0
          AND r.Name IN ('TimesYonetici', 'TimesUstYonetici')
    )
    OR
    (
        EXISTS
        (
            SELECT 1
            FROM dbo.KUserRole ur
            INNER JOIN dbo.KRole r
                ON r.Id = ur.KRole_Id
            WHERE ur.KUser_Id = @UserId
              AND ur.IsDeleted = 0
              AND r.IsDeleted = 0
              AND r.Name IN ('TimesMagazaMuduru', 'TimesSatisPersoneli')
        )
        AND EXISTS
        (
            SELECT 1
            FROM tmscrq.TMUser tu
            WHERE tu.KUserID = @UserId
              AND tu.StoreId = l.StoreId
        )
    )
)

AND
(
    ISNULL(@MusteriAdi, '') = ''
    OR UPPER(ISNULL(cu.Name, '')) LIKE '%' + UPPER(LTRIM(RTRIM(@MusteriAdi))) + '%'
    OR UPPER(ISNULL(cu.LastName, '')) LIKE '%' + UPPER(LTRIM(RTRIM(@MusteriAdi))) + '%'
    OR UPPER(
        ISNULL(cu.Name, '') + ' ' + ISNULL(cu.LastName, '')
    ) LIKE '%' + UPPER(LTRIM(RTRIM(@MusteriAdi))) + '%'
)

AND
(
    @ProductName IS NULL
    OR LTRIM(RTRIM(@ProductName)) = ''
    OR
    (
        CHARINDEX(',', @ProductName) > 0
        AND ISNULL(LTRIM(RTRIM(p.ProductName)), '') IN
        (
            SELECT LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', '')))
            FROM STRING_SPLIT(CAST(@ProductName AS NVARCHAR(MAX)), ',')
            WHERE LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', ''))) <> ''
        )
    )
    OR
    (
        CHARINDEX(',', @ProductName) = 0
        AND UPPER(ISNULL(LTRIM(RTRIM(p.ProductName)), ''))
            LIKE '%' + UPPER(LTRIM(RTRIM(@ProductName))) + '%'
    )
)

AND
(
    ISNULL(@LeadCode, '') = ''
    OR UPPER(ISNULL(l.LeadCode, ''))
        LIKE '%' + UPPER(LTRIM(RTRIM(@LeadCode))) + '%'
    OR REPLACE(
        REPLACE(
            REPLACE(
                UPPER(ISNULL(l.LeadCode, '')),
                '-', ''
            ),
            ' ', ''
        ),
        '/', ''
    )
    LIKE '%' +
    REPLACE(
        REPLACE(
            REPLACE(
                UPPER(LTRIM(RTRIM(@LeadCode))),
                '-', ''
            ),
            ' ', ''
        ),
        '/', ''
    )
    + '%'
)

AND
(
    @Tel IS NULL
    OR LTRIM(RTRIM(@Tel)) = ''
    OR UPPER(ISNULL(LTRIM(RTRIM(cu.Tel)), '')) LIKE '%' + UPPER(LTRIM(RTRIM(@Tel))) + '%'
)

AND
(
    @CategoryName IS NULL
    OR LTRIM(RTRIM(@CategoryName)) = ''
    OR UPPER(ISNULL(LTRIM(RTRIM(p.CategoryName)), '')) IN
    (
        SELECT UPPER(LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value,'""',''),'[',''),']',''))))
        FROM STRING_SPLIT(CAST(@CategoryName AS NVARCHAR(MAX)), ',')
        WHERE LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value,'""',''),'[',''),']',''))) <> ''
    )
)

AND
(
    @StoreIds IS NULL
    OR LTRIM(RTRIM(@StoreIds)) = ''
    OR EXISTS
    (
        SELECT 1
        FROM STRING_SPLIT(CAST(@StoreIds AS NVARCHAR(MAX)), ',') s
        WHERE l.StoreId = TRY_CONVERT
        (
            uniqueidentifier,
            LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(s.value, '""', ''), '[', ''), ']', '')))
        )
    )
)

AND
(
    @SatisDanismaniIds IS NULL
    OR LTRIM(RTRIM(@SatisDanismaniIds)) = ''
    OR EXISTS
    (
        SELECT 1
        FROM STRING_SPLIT(CAST(@SatisDanismaniIds AS NVARCHAR(MAX)), ',') s
        WHERE l.SalesPersonKUserId = TRY_CONVERT
        (
            uniqueidentifier,
            LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(s.value, '""', ''), '[', ''), ']', '')))
        )
    )
)

AND
(
    ISNULL(@ProcessCode, '') = ''
    OR EXISTS
    (
        SELECT 1
        FROM STRING_SPLIT(
            CONVERT(NVARCHAR(MAX), @ProcessCode),
            ','
        ) AS s
        WHERE
            UPPER(LTRIM(RTRIM(s.value))) =
            UPPER(LTRIM(RTRIM(ISNULL(lp.Code, ''))))
    )
)

-- DÜZELTİLEN ALAN: @StepOrder Filtresi (0 verilince tümü gelsin)
AND
(
    @StepOrder IS NULL
    OR @StepOrder = 0  -- 👈 YENİ EKLENDI: 0 verilince tüm kayıtlar gelir
    OR
    (
        @StepOrder = 10
        AND EXISTS
        (
            SELECT 1
            FROM tmscrq.TMLeadReservation r
            WHERE r.LeadId = l.Id
              AND r.IsActive = 1
              AND ISNULL(r.IsApproved,0) = 0
        )
    )
    OR
    (
        @StepOrder <> 10
        AND lp.StepOrder = @StepOrder
    )
)

AND
(
    @StartDate IS NULL
    OR LTRIM(RTRIM(@StartDate)) = ''
    OR l.CreatedAt >= CONVERT(date, @StartDate)
)

AND
(
    @EndDate IS NULL
    OR LTRIM(RTRIM(@EndDate)) = ''
    OR l.CreatedAt < DATEADD(day, 1, CONVERT(date, @EndDate))
)

ORDER BY l.CreatedAt DESC;", new string[] { "RezerveDurumu", "LeadId", "IsReserved", "LeadNumarasi", "TalepTarihi", "ProductId", "ProductName", "Bilezik", "Brand", "Kadran", "RefCode", "Referans", "Musteri", "Lokasyon", "Ilce", "Ulke", "MusteriInfo", "AlisverisiVarMi", "IrtibatNumarasi", "EmailAdresi", "IletisimKaynagi", "CategoryName", "CategoryCode", "LeadDurumu", "SonrakiAdim", "ProcessName", "ProcessCode", "StepOrder", "SelectedStepOrder", "TerminTarihi", "SatisDanismani", "StoreName" }, prms_TM_GetLeads_0.ToArray());
            ;

            var prms_TMLeadProcessCountSummary_1 = new List<kSqlParameter>();
            prms_TMLeadProcessCountSummary_1.Add(new kSqlParameter() { Name = "UserId", Value = Kuika.Common.KContext.CurrentUser?.Id });
            prms_TMLeadProcessCountSummary_1.Add(new kSqlParameter() { Name = "MusteriAdi", Value = request.MusteriAdi_1 });
            prms_TMLeadProcessCountSummary_1.Add(new kSqlParameter() { Name = "ProductName", Value = request.ProductName_1 });
            prms_TMLeadProcessCountSummary_1.Add(new kSqlParameter() { Name = "LeadCode", Value = request.LeadCode_1 });
            prms_TMLeadProcessCountSummary_1.Add(new kSqlParameter() { Name = "Tel", Value = request.Tel_1 });
            prms_TMLeadProcessCountSummary_1.Add(new kSqlParameter() { Name = "CategoryName", Value = request.CategoryName_1 });
            prms_TMLeadProcessCountSummary_1.Add(new kSqlParameter() { Name = "StoreIds", Value = request.StoreIds_1 });
            prms_TMLeadProcessCountSummary_1.Add(new kSqlParameter() { Name = "SatisDanismaniIds", Value = request.SatisDanismaniIds_1 });
            prms_TMLeadProcessCountSummary_1.Add(new kSqlParameter() { Name = "ProcessCode", Value = request.ProcessCode_1 });
            prms_TMLeadProcessCountSummary_1.Add(new kSqlParameter() { Name = "StartDate", Value = request.StartDate_1 });
            prms_TMLeadProcessCountSummary_1.Add(new kSqlParameter() { Name = "EndDate", Value = request.EndDate_1 });
            using var auditTMLeadProcessCountSummary_1 = ActionAuditScope.Begin("2cefaf06-422a-cc03-94bd-526fb72e9a95", "TMLeadProcessCountSummary", applicationName: "wbTimesCRM", screenOrEndpointName: "LeadList");
            result.TMLeadProcessCountSummary = KPersister.Fetch(KContext.GetConnectionString(), @"-- SELECT
--     COUNT(*) AS ToplamTalepSayisi,

--     SUM(CASE WHEN lp.Code = 'PENDING' THEN 1 ELSE 0 END) AS OnayBekleyenSayisi,
--     SUM(CASE WHEN lp.Code = 'TERMIN_PENDING' THEN 1 ELSE 0 END) AS TerminBekleyenSayisi,
--     SUM(CASE WHEN lp.Code = 'APPROVED' THEN 1 ELSE 0 END) AS OnaylananSayisi,
--     SUM(CASE WHEN lp.Code = 'REJECTED' THEN 1 ELSE 0 END) AS ReddedilenSayisi,
--     SUM(CASE WHEN lp.Code = 'DELIVERY_PENDING' THEN 1 ELSE 0 END) AS TeslimEdilecekSayisi,
--     SUM(CASE WHEN lp.Code = 'DELIVERED' THEN 1 ELSE 0 END) AS TeslimEdildiSayisi

-- FROM tmscrq.TMLead l
-- LEFT JOIN tmscrq.TMCustomer cu
--     ON cu.Id = l.CustomerId
-- LEFT JOIN tmscrq.TMProduct p
--     ON p.Id = l.ProductId
-- LEFT JOIN dbo.KUser sp
--     ON sp.Id = l.SalesPersonKUserId
-- LEFT JOIN tmscrq.TMLeadProcess lp
--     ON lp.Id = l.ProcessID

-- WHERE
-- (
--     EXISTS
--     (
--         SELECT 1
--         FROM dbo.KUserRole ur
--         INNER JOIN dbo.KRole r
--             ON r.Id = ur.KRole_Id
--         WHERE ur.KUser_Id = @UserId
--           AND ur.IsDeleted = 0
--           AND r.IsDeleted = 0
--           AND r.Name IN ('TimesYonetici', 'TimesUstYonetici')
--     )
--     OR
--     (
--         EXISTS
--         (
--             SELECT 1
--             FROM dbo.KUserRole ur
--             INNER JOIN dbo.KRole r
--                 ON r.Id = ur.KRole_Id
--             WHERE ur.KUser_Id = @UserId
--               AND ur.IsDeleted = 0
--               AND r.IsDeleted = 0
--               AND r.Name IN ('TimesMagazaMuduru', 'TimesSatisPersoneli')
--         )
--         AND EXISTS
--         (
--             SELECT 1
--             FROM tmscrq.TMUser tu
--             WHERE tu.KUserID = @UserId
--               AND tu.StoreId = l.StoreId
--         )
--     )
-- )

-- AND
-- (
--     @MusteriAdi IS NULL
--     OR LTRIM(RTRIM(@MusteriAdi)) = ''
--     OR UPPER(LTRIM(RTRIM(ISNULL(cu.Name, '') + ' ' + ISNULL(cu.LastName, ''))))
--        LIKE '%' + UPPER(LTRIM(RTRIM(@MusteriAdi))) + '%'
-- )

-- AND
-- (
--     @ProductName IS NULL
--     OR LTRIM(RTRIM(@ProductName)) = ''
--     OR
--     (
--         CHARINDEX(',', @ProductName) > 0
--         AND ISNULL(LTRIM(RTRIM(p.ProductName)), '') IN
--         (
--             SELECT LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', '')))
--             FROM STRING_SPLIT(CAST(@ProductName AS NVARCHAR(MAX)), ',')
--             WHERE LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', ''))) <> ''
--         )
--     )
--     OR
--     (
--         CHARINDEX(',', @ProductName) = 0
--         AND UPPER(ISNULL(LTRIM(RTRIM(p.ProductName)), ''))
--             LIKE '%' + UPPER(LTRIM(RTRIM(@ProductName))) + '%'
--     )
-- )

-- AND
-- (
--     @LeadCode IS NULL
--     OR LTRIM(RTRIM(@LeadCode)) = ''
--     OR UPPER(ISNULL(LTRIM(RTRIM(l.LeadCode)), '')) LIKE '%' + UPPER(LTRIM(RTRIM(@LeadCode))) + '%'
-- )

-- AND
-- (
--     @Tel IS NULL
--     OR LTRIM(RTRIM(@Tel)) = ''
--     OR UPPER(ISNULL(LTRIM(RTRIM(cu.Tel)), '')) LIKE '%' + UPPER(LTRIM(RTRIM(@Tel))) + '%'
-- )

-- AND
-- (
--     @CategoryName IS NULL
--     OR LTRIM(RTRIM(@CategoryName)) = ''
--     OR
--     (
--         EXISTS
--         (
--             SELECT 1
--             FROM STRING_SPLIT(CAST(@CategoryName AS NVARCHAR(MAX)), ',') c
--             WHERE UPPER(LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(c.value, '""', ''), '[', ''), ']', '')))) = 'DEFAULT'
--         )
--         AND (p.CategoryName IS NULL OR LTRIM(RTRIM(p.CategoryName)) = '')
--     )
--     OR UPPER(ISNULL(LTRIM(RTRIM(p.CategoryName)), '')) IN
--     (
--         SELECT UPPER(LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', ''))))
--         FROM STRING_SPLIT(CAST(@CategoryName AS NVARCHAR(MAX)), ',')
--         WHERE LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', ''))) <> ''
--           AND UPPER(LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', '')))) <> 'DEFAULT'
--     )
-- )

-- AND
-- (
--     @StoreIds IS NULL
--     OR LTRIM(RTRIM(@StoreIds)) = ''
--     OR EXISTS
--     (
--         SELECT 1
--         FROM STRING_SPLIT(CAST(@StoreIds AS NVARCHAR(MAX)), ',') s
--         WHERE l.StoreId = TRY_CONVERT
--         (
--             uniqueidentifier,
--             LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(s.value, '""', ''), '[', ''), ']', '')))
--         )
--     )
-- )

-- AND
-- (
--     @SatisDanismaniIds IS NULL
--     OR LTRIM(RTRIM(@SatisDanismaniIds)) = ''
--     OR EXISTS
--     (
--         SELECT 1
--         FROM STRING_SPLIT(CAST(@SatisDanismaniIds AS NVARCHAR(MAX)), ',') s
--         WHERE l.SalesPersonKUserId = TRY_CONVERT
--         (
--             uniqueidentifier,
--             LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(s.value, '""', ''), '[', ''), ']', '')))
--         )
--     )
-- )

-- AND
-- (
--     @ProcessCode IS NULL
--     OR LTRIM(RTRIM(@ProcessCode)) = ''
--     OR UPPER(ISNULL(LTRIM(RTRIM(lp.Code)), '')) IN
--     (
--         SELECT UPPER(LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', ''))))
--         FROM STRING_SPLIT(CAST(@ProcessCode AS NVARCHAR(MAX)), ',')
--         WHERE LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', ''))) <> ''
--     )
-- )

-- AND
-- (
--     @StartDate IS NULL
--     OR LTRIM(RTRIM(@StartDate)) = ''
--     OR l.CreatedAt >= CONVERT(date, @StartDate)
-- )

-- AND
-- (
--     @EndDate IS NULL
--     OR LTRIM(RTRIM(@EndDate)) = ''
--     OR l.CreatedAt < DATEADD(day, 1, CONVERT(date, @EndDate))
-- );

-------------------------------------------------------------

DECLARE @KUserId UNIQUEIDENTIFIER = @UserId;

WITH UserRoles AS (
    SELECT r.Name
    FROM dbo.KUserRole ur
    INNER JOIN dbo.KRole r 
        ON r.Id = ur.KRole_Id
    WHERE ur.KUser_Id = @KUserId
      AND ur.IsDeleted = 0
      AND r.IsDeleted = 0
),
IsAdmin AS (
    SELECT CASE 
        WHEN EXISTS (
            SELECT 1 
            FROM UserRoles 
            WHERE Name = 'TimesUstYonetici'
        ) THEN 1 ELSE 0 END AS IsAdmin
)

SELECT
    COUNT(*) AS ToplamTalepSayisi,

    SUM(CASE WHEN lp.Code = 'PENDING' THEN 1 ELSE 0 END) AS OnayBekleyenSayisi,
    SUM(CASE WHEN lp.Code = 'TERMIN_PENDING' THEN 1 ELSE 0 END) AS TerminBekleyenSayisi,
    SUM(CASE WHEN lp.Code = 'APPROVED' THEN 1 ELSE 0 END) AS OnaylananSayisi,
    SUM(CASE WHEN lp.Code = 'REJECTED' THEN 1 ELSE 0 END) AS ReddedilenSayisi,
    SUM(CASE WHEN lp.Code = 'DELIVERY_PENDING' THEN 1 ELSE 0 END) AS TeslimEdilecekSayisi,
    SUM(CASE WHEN lp.Code = 'DELIVERED' THEN 1 ELSE 0 END) AS TeslimEdildiSayisi

FROM tmscrq.TMLead l
LEFT JOIN tmscrq.TMCustomer cu
    ON cu.Id = l.CustomerId
LEFT JOIN tmscrq.TMProduct p
    ON p.Id = l.ProductId
LEFT JOIN dbo.KUser sp
    ON sp.Id = l.SalesPersonKUserId
LEFT JOIN tmscrq.TMLeadProcess lp
    ON lp.Id = l.ProcessID

CROSS JOIN IsAdmin a

WHERE
(
    -- admin → full
    a.IsAdmin = 1

    -- diğerleri → sadece kendi mağazaları
    OR EXISTS
    (
        SELECT 1
        FROM tmscrq.TMUser tu
        WHERE tu.KUserID = @KUserId
          AND tu.StoreId = l.StoreId
    )
)

-- 🔽 AŞAĞISI SENİN ORİJİNAL FİLTRELER (HİÇ DOKUNMADIM)

AND
(
    @MusteriAdi IS NULL
    OR LTRIM(RTRIM(@MusteriAdi)) = ''
    OR UPPER(LTRIM(RTRIM(ISNULL(cu.Name, '') + ' ' + ISNULL(cu.LastName, ''))))
       LIKE '%' + UPPER(LTRIM(RTRIM(@MusteriAdi))) + '%'
)

AND
(
    @ProductName IS NULL
    OR LTRIM(RTRIM(@ProductName)) = ''
    OR
    (
        CHARINDEX(',', @ProductName) > 0
        AND ISNULL(LTRIM(RTRIM(p.ProductName)), '') IN
        (
            SELECT LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', '')))
            FROM STRING_SPLIT(CAST(@ProductName AS NVARCHAR(MAX)), ',')
        )
    )
    OR
    (
        CHARINDEX(',', @ProductName) = 0
        AND UPPER(ISNULL(LTRIM(RTRIM(p.ProductName)), ''))
            LIKE '%' + UPPER(LTRIM(RTRIM(@ProductName))) + '%'
    )
)

AND
(
    @LeadCode IS NULL
    OR LTRIM(RTRIM(@LeadCode)) = ''
    OR UPPER(ISNULL(LTRIM(RTRIM(l.LeadCode)), '')) LIKE '%' + UPPER(LTRIM(RTRIM(@LeadCode))) + '%'
)

AND
(
    @Tel IS NULL
    OR LTRIM(RTRIM(@Tel)) = ''
    OR UPPER(ISNULL(LTRIM(RTRIM(cu.Tel)), '')) LIKE '%' + UPPER(LTRIM(RTRIM(@Tel))) + '%'
)

AND
(
    @CategoryName IS NULL
    OR LTRIM(RTRIM(@CategoryName)) = ''
    OR
    (
        EXISTS
        (
            SELECT 1
            FROM STRING_SPLIT(CAST(@CategoryName AS NVARCHAR(MAX)), ',') c
            WHERE UPPER(LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(c.value, '""', ''), '[', ''), ']', '')))) = 'DEFAULT'
        )
        AND (p.CategoryName IS NULL OR LTRIM(RTRIM(p.CategoryName)) = '')
    )
    OR UPPER(ISNULL(LTRIM(RTRIM(p.CategoryName)), '')) IN
    (
        SELECT UPPER(LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', ''))))
        FROM STRING_SPLIT(CAST(@CategoryName AS NVARCHAR(MAX)), ',')
    )
)

AND
(
    @StoreIds IS NULL
    OR LTRIM(RTRIM(@StoreIds)) = ''
    OR EXISTS
    (
        SELECT 1
        FROM STRING_SPLIT(CAST(@StoreIds AS NVARCHAR(MAX)), ',') s
        WHERE l.StoreId = TRY_CONVERT
        (
            uniqueidentifier,
            LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(s.value, '""', ''), '[', ''), ']', '')))
        )
    )
)

AND
(
    @SatisDanismaniIds IS NULL
    OR LTRIM(RTRIM(@SatisDanismaniIds)) = ''
    OR EXISTS
    (
        SELECT 1
        FROM STRING_SPLIT(CAST(@SatisDanismaniIds AS NVARCHAR(MAX)), ',') s
        WHERE l.SalesPersonKUserId = TRY_CONVERT
        (
            uniqueidentifier,
            LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(s.value, '""', ''), '[', ''), ']', '')))
        )
    )
)

AND
(
    @ProcessCode IS NULL
    OR LTRIM(RTRIM(@ProcessCode)) = ''
    OR UPPER(ISNULL(LTRIM(RTRIM(lp.Code)), '')) IN
    (
        SELECT UPPER(LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', ''))))
        FROM STRING_SPLIT(CAST(@ProcessCode AS NVARCHAR(MAX)), ',')
    )
)

AND
(
    @StartDate IS NULL
    OR LTRIM(RTRIM(@StartDate)) = ''
    OR l.CreatedAt >= CONVERT(date, @StartDate)
)

AND
(
    @EndDate IS NULL
    OR LTRIM(RTRIM(@EndDate)) = ''
    OR l.CreatedAt < DATEADD(day, 1, CONVERT(date, @EndDate))
);", new string[] { "ToplamTalepSayisi", "OnayBekleyenSayisi", "TerminBekleyenSayisi", "OnaylananSayisi", "ReddedilenSayisi", "TeslimEdilecekSayisi", "TeslimEdildiSayisi" }, prms_TMLeadProcessCountSummary_1.ToArray());
            ;


            return Ok(result);
        }


        [HttpPost, Route("LeadListComponent_576673_onChange")]
        public IActionResult LeadListComponent_576673_onChange(LeadListComponent_576673_onChange_Request request)
        {

            KProviderManager.Authorization.IsAuthorizedForRoles(appId, appName, screenId, screenName, new List<string> { $"70de6cfc-6087-6059-59b4-0b5a8527af6b", "4da1f213-c8e4-0b50-5c84-02fd13f1a622", "c4e882ef-977d-f613-7694-230ac83919d2", "b4bfd39c-ac02-f442-c899-7a2374a45b47", "cdb536b0-6297-155f-d446-8453d8a60304", "TimesYonetici", "TimesUstYonetici", "TimesSatisPersoneli", "TimesMagazaMuduru", "TimesAdmin" });

            var result = new LeadListComponent_576673_onChange_Response();

            var prms_TM_GetLeads_0 = new List<kSqlParameter>();
            prms_TM_GetLeads_0.Add(new kSqlParameter() { Name = "StepOrder", Value = request.StepOrder_0 });
            prms_TM_GetLeads_0.Add(new kSqlParameter() { Name = "UserId", Value = Kuika.Common.KContext.CurrentUser?.Id });
            prms_TM_GetLeads_0.Add(new kSqlParameter() { Name = "MusteriAdi", Value = request.MusteriAdi_0 });
            prms_TM_GetLeads_0.Add(new kSqlParameter() { Name = "ProductName", Value = request.ProductName_0 });
            prms_TM_GetLeads_0.Add(new kSqlParameter() { Name = "LeadCode", Value = request.LeadCode_0 });
            prms_TM_GetLeads_0.Add(new kSqlParameter() { Name = "Tel", Value = request.Tel_0 });
            prms_TM_GetLeads_0.Add(new kSqlParameter() { Name = "CategoryName", Value = request.CategoryName_0 });
            prms_TM_GetLeads_0.Add(new kSqlParameter() { Name = "StoreIds", Value = request.StoreIds_0 });
            prms_TM_GetLeads_0.Add(new kSqlParameter() { Name = "SatisDanismaniIds", Value = request.SatisDanismaniIds_0 });
            prms_TM_GetLeads_0.Add(new kSqlParameter() { Name = "ProcessCode", Value = request.ProcessCode_0 });
            prms_TM_GetLeads_0.Add(new kSqlParameter() { Name = "StartDate", Value = request.StartDate_0 });
            prms_TM_GetLeads_0.Add(new kSqlParameter() { Name = "EndDate", Value = request.EndDate_0 });
            using var auditTM_GetLeads_0 = ActionAuditScope.Begin("5b595ae2-2217-8668-f025-c3b8add2dd0d", "TM_GetLeads", applicationName: "wbTimesCRM", screenOrEndpointName: "LeadList");
            result.TM_GetLeads = KPersister.Fetch(KContext.GetConnectionString(), @"-- SET LANGUAGE Turkish;

-- SELECT
-- CASE 
--     WHEN EXISTS (
--         SELECT 1 
--         FROM tmscrq.TMLeadReservation r
--         WHERE r.LeadId = l.Id
--           AND r.IsActive = 1
--           AND r.IsApproved = 1
--     ) THEN N'Evet'

--     WHEN EXISTS (
--         SELECT 1 
--         FROM tmscrq.TMLeadReservation r
--         WHERE r.LeadId = l.Id
--           AND r.IsActive = 1
--           AND ISNULL(r.IsApproved,0) = 0
--     ) THEN N'Onay Bekliyor'

--     ELSE N'Hayır'
-- END AS RezerveDurumu,
--     l.Id AS LeadId,
--     l.IsReserved,
--     ISNULL(NULLIF(LTRIM(RTRIM(l.LeadCode)), ''), '-') AS LeadNumarasi,
--     CONVERT(varchar(10), l.CreatedAt, 103) AS TalepTarihi,

--     p.Id AS ProductId,
--     ISNULL(NULLIF(LTRIM(RTRIM(p.ProductName)), ''), '-') AS ProductName,
--     ISNULL(NULLIF(LTRIM(RTRIM(p.Bracelet)), ''), '-') AS Bilezik,
--     ISNULL(NULLIF(LTRIM(RTRIM(p.Brand)), ''), '-') AS Brand,
--     ISNULL(NULLIF(LTRIM(RTRIM(p.Dial)), ''), '-') AS Kadran,
--     ISNULL(NULLIF(LTRIM(RTRIM(p.ProductCode)), ''), '-') AS RefCode,
--     ISNULL(NULLIF(LTRIM(RTRIM(p.Referance)), ''), '-') AS Referans,

--     ISNULL(
--         NULLIF(
--             LTRIM(RTRIM(ISNULL(cu.Name, '') + ' ' + ISNULL(cu.LastName, '')))
--         , '')
--     , '-') AS Musteri,

--     ISNULL(NULLIF(LTRIM(RTRIM(cu.CityName)), ''), '-') AS Lokasyon,
--     ISNULL(NULLIF(LTRIM(RTRIM(cu.DistrictName)), ''), '-') AS Ilce,
--     ISNULL(NULLIF(LTRIM(RTRIM(cu.CountryName)), ''), '-') AS Ulke,
--     ISNULL(NULLIF(LTRIM(RTRIM(cu.Info)), ''), '-') AS MusteriInfo,

--     CASE
--         WHEN cu.IsShopping = 1 THEN N'Evet'
--         WHEN cu.IsShopping = 0 THEN N'Hayır'
--         ELSE '-'
--     END AS AlisverisiVarMi,

--     ISNULL(NULLIF(LTRIM(RTRIM(cu.Tel)), ''), '-') AS IrtibatNumarasi,
--     ISNULL(NULLIF(LTRIM(RTRIM(cu.Email)), ''), '-') AS EmailAdresi,

--     ISNULL(NULLIF(LTRIM(RTRIM(cr.ContactResourceName)), ''), '-') AS IletisimKaynagi,

--     ISNULL(NULLIF(LTRIM(RTRIM(p.CategoryName)), ''), '-') AS CategoryName,
--     '-' AS CategoryCode,

--     ISNULL(NULLIF(LTRIM(RTRIM(ls.Name)), ''), '-') AS LeadDurumu,
--     ISNULL(NULLIF(LTRIM(RTRIM(ns.Name)), ''), '-') AS SonrakiAdim,

--     ISNULL(NULLIF(LTRIM(RTRIM(lp.Name)), ''), '-') AS ProcessName,
--     ISNULL(NULLIF(LTRIM(RTRIM(lp.Code)), ''), '-') AS ProcessCode,
--     lp.StepOrder,
-- CASE
--     WHEN EXISTS
--     (
--         SELECT 1
--         FROM tmscrq.TMLeadReservation r
--         WHERE r.LeadId = l.Id
--           AND r.IsActive = 1
--           AND ISNULL(r.IsApproved,0) = 0
--     )
--     THEN 10
--     ELSE lp.StepOrder
-- END AS SelectedStepOrder,

--     ISNULL(
--         CASE
--             WHEN l.EstimatedDate IS NOT NULL
--             THEN CAST(YEAR(l.EstimatedDate) AS VARCHAR(4)) + ' ' + DATENAME(MONTH, l.EstimatedDate)
--             ELSE NULL
--         END,
--         '-'
--     ) AS TerminTarihi,

--     ISNULL(
--         NULLIF(
--             LTRIM(RTRIM(ISNULL(sp.FirstName, '') + ' ' + ISNULL(sp.LastName, '')))
--         , '')
--     , '-') AS SatisDanismani,

--     ISNULL(NULLIF(LTRIM(RTRIM(st.StoreDesc)), ''), '-') AS StoreName

-- FROM tmscrq.TMLead l
-- LEFT JOIN tmscrq.TMLeadStatu ls
--     ON ls.Id = l.StatuId
-- LEFT JOIN tmscrq.TMCustomer cu
--     ON cu.Id = l.CustomerId
-- LEFT JOIN tmscrq.TMProduct p
--     ON p.Id = l.ProductId
-- LEFT JOIN tmscrq.TMContactResource cr
--     ON cr.Id = l.ContactResourceId
-- LEFT JOIN dbo.KUser sp
--     ON sp.Id = l.SalesPersonKUserId
-- LEFT JOIN tmscrq.TMStore st
--     ON st.Id = l.StoreId
-- LEFT JOIN tmscrq.TMLeadProcess lp
--     ON lp.Id = l.ProcessID
-- LEFT JOIN tmscrq.TMLeadNextStep ns
--     ON ns.Id = l.NextStepId

-- WHERE
-- (
--     EXISTS
--     (
--         SELECT 1
--         FROM dbo.KUserRole ur
--         INNER JOIN dbo.KRole r
--             ON r.Id = ur.KRole_Id
--         WHERE ur.KUser_Id = @UserId
--           AND ur.IsDeleted = 0
--           AND r.IsDeleted = 0
--           AND r.Name IN ('TimesYonetici', 'TimesUstYonetici')
--     )
--     OR
--     (
--         EXISTS
--         (
--             SELECT 1
--             FROM dbo.KUserRole ur
--             INNER JOIN dbo.KRole r
--                 ON r.Id = ur.KRole_Id
--             WHERE ur.KUser_Id = @UserId
--               AND ur.IsDeleted = 0
--               AND r.IsDeleted = 0
--               AND r.Name IN ('TimesMagazaMuduru', 'TimesSatisPersoneli')
--         )
--         AND EXISTS
--         (
--             SELECT 1
--             FROM tmscrq.TMUser tu
--             WHERE tu.KUserID = @UserId
--               AND tu.StoreId = l.StoreId
--         )
--     )
-- )

-- AND
-- (
--     @MusteriAdi IS NULL
--     OR LTRIM(RTRIM(@MusteriAdi)) = ''
--     OR UPPER(LTRIM(RTRIM(ISNULL(cu.Name,'') + ' ' + ISNULL(cu.LastName,''))))
--        LIKE '%' + UPPER(LTRIM(RTRIM(@MusteriAdi))) + '%'
-- )

-- AND
-- (
--     @ProductName IS NULL
--     OR LTRIM(RTRIM(@ProductName)) = ''
--     OR
--     (
--         CHARINDEX(',', @ProductName) > 0
--         AND ISNULL(LTRIM(RTRIM(p.ProductName)), '') IN
--         (
--             SELECT LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', '')))
--             FROM STRING_SPLIT(CAST(@ProductName AS NVARCHAR(MAX)), ',')
--             WHERE LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', ''))) <> ''
--         )
--     )
--     OR
--     (
--         CHARINDEX(',', @ProductName) = 0
--         AND UPPER(ISNULL(LTRIM(RTRIM(p.ProductName)), ''))
--             LIKE '%' + UPPER(LTRIM(RTRIM(@ProductName))) + '%'
--     )
-- )

-- AND
-- (
--     @LeadCode IS NULL
--     OR LTRIM(RTRIM(@LeadCode)) = ''
--     OR UPPER(ISNULL(LTRIM(RTRIM(l.LeadCode)), '')) LIKE '%' + UPPER(LTRIM(RTRIM(@LeadCode))) + '%'
-- )

-- AND
-- (
--     @Tel IS NULL
--     OR LTRIM(RTRIM(@Tel)) = ''
--     OR UPPER(ISNULL(LTRIM(RTRIM(cu.Tel)), '')) LIKE '%' + UPPER(LTRIM(RTRIM(@Tel))) + '%'
-- )

-- -- AND
-- -- (
-- --     @CategoryName IS NULL
-- --     OR LTRIM(RTRIM(@CategoryName)) = ''
-- --     OR
-- --     (
-- --         EXISTS
-- --         (
-- --             SELECT 1
-- --             FROM STRING_SPLIT(CAST(@CategoryName AS NVARCHAR(MAX)), ',') c
-- --             WHERE UPPER(LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(c.value, '""', ''), '[', ''), ']', '')))) = 'DEFAULT'
-- --         )
-- --         AND (p.CategoryName IS NULL OR LTRIM(RTRIM(p.CategoryName)) = '')
-- --     )
-- --     OR UPPER(ISNULL(LTRIM(RTRIM(p.CategoryName)), '')) IN
-- --     (
-- --         SELECT UPPER(LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', ''))))
-- --         FROM STRING_SPLIT(CAST(@CategoryName AS NVARCHAR(MAX)), ',')
-- --         WHERE LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', ''))) <> ''
-- --           AND UPPER(LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', '')))) <> 'DEFAULT'
-- --     )
-- -- )

-- AND
-- (
--     @CategoryName IS NULL
--     OR LTRIM(RTRIM(@CategoryName)) = ''
--     OR UPPER(ISNULL(LTRIM(RTRIM(p.CategoryName)), '')) IN
--     (
--         SELECT UPPER(LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value,'""',''),'[',''),']',''))))
--         FROM STRING_SPLIT(CAST(@CategoryName AS NVARCHAR(MAX)), ',')
--         WHERE LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value,'""',''),'[',''),']',''))) <> ''
--     )
-- )

-- AND
-- (
--     @StoreIds IS NULL
--     OR LTRIM(RTRIM(@StoreIds)) = ''
--     OR EXISTS
--     (
--         SELECT 1
--         FROM STRING_SPLIT(CAST(@StoreIds AS NVARCHAR(MAX)), ',') s
--         WHERE l.StoreId = TRY_CONVERT
--         (
--             uniqueidentifier,
--             LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(s.value, '""', ''), '[', ''), ']', '')))
--         )
--     )
-- )

-- AND
-- (
--     @SatisDanismaniIds IS NULL
--     OR LTRIM(RTRIM(@SatisDanismaniIds)) = ''
--     OR EXISTS
--     (
--         SELECT 1
--         FROM STRING_SPLIT(CAST(@SatisDanismaniIds AS NVARCHAR(MAX)), ',') s
--         WHERE l.SalesPersonKUserId = TRY_CONVERT
--         (
--             uniqueidentifier,
--             LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(s.value, '""', ''), '[', ''), ']', '')))
--         )
--     )
-- )

-- AND
-- (
--     @ProcessCode IS NULL
--     OR LTRIM(RTRIM(@ProcessCode)) = ''
--     OR UPPER(ISNULL(LTRIM(RTRIM(lp.Code)), '')) IN
--     (
--         SELECT UPPER(LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', ''))))
--         FROM STRING_SPLIT(CAST(@ProcessCode AS NVARCHAR(MAX)), ',')
--         WHERE LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', ''))) <> ''
--     )
-- )

-- AND
-- (
--     @StepOrder IS NULL

--     OR
--     (
--         @StepOrder = 10
--         AND EXISTS
--         (
--             SELECT 1
--             FROM tmscrq.TMLeadReservation r
--             WHERE r.LeadId = l.Id
--               AND r.IsActive = 1
--               AND ISNULL(r.IsApproved,0) = 0
--         )
--     )

--     OR
--     (
--         @StepOrder <> 10
--         AND lp.StepOrder = @StepOrder
--     )
-- )

-- AND
-- (
--     @StartDate IS NULL
--     OR LTRIM(RTRIM(@StartDate)) = ''
--     OR l.CreatedAt >= CONVERT(date, @StartDate)
-- )

-- AND
-- (
--     @EndDate IS NULL
--     OR LTRIM(RTRIM(@EndDate)) = ''
--     OR l.CreatedAt < DATEADD(day, 1, CONVERT(date, @EndDate))
-- )

-- ORDER BY l.CreatedAt DESC;

------------------------++++++++++++++++++++++++-------------------
-- SET LANGUAGE Turkish;

-- SELECT
-- CASE 
--     WHEN EXISTS (
--         SELECT 1 
--         FROM tmscrq.TMLeadReservation r
--         WHERE r.LeadId = l.Id
--           AND r.IsActive = 1
--           AND r.IsApproved = 1
--     ) THEN N'Evet'

--     WHEN EXISTS (
--         SELECT 1 
--         FROM tmscrq.TMLeadReservation r
--         WHERE r.LeadId = l.Id
--           AND r.IsActive = 1
--           AND ISNULL(r.IsApproved,0) = 0
--     ) THEN N'Onay Bekliyor'

--     ELSE N'Hayır'
-- END AS RezerveDurumu,
--     l.Id AS LeadId,
--     l.IsReserved,
--     ISNULL(NULLIF(LTRIM(RTRIM(l.LeadCode)), ''), '-') AS LeadNumarasi,
--     CONVERT(varchar(10), l.CreatedAt, 103) AS TalepTarihi,

--     p.Id AS ProductId,
--     ISNULL(NULLIF(LTRIM(RTRIM(p.ProductName)), ''), '-') AS ProductName,
--     ISNULL(NULLIF(LTRIM(RTRIM(p.Bracelet)), ''), '-') AS Bilezik,
--     ISNULL(NULLIF(LTRIM(RTRIM(p.Brand)), ''), '-') AS Brand,
--     ISNULL(NULLIF(LTRIM(RTRIM(p.Dial)), ''), '-') AS Kadran,
--     ISNULL(NULLIF(LTRIM(RTRIM(p.ProductCode)), ''), '-') AS RefCode,
--     ISNULL(NULLIF(LTRIM(RTRIM(p.Referance)), ''), '-') AS Referans,

--     ISNULL(
--         NULLIF(
--             LTRIM(RTRIM(ISNULL(cu.Name, '') + ' ' + ISNULL(cu.LastName, '')))
--         , '')
--     , '-') AS Musteri,

--     ISNULL(NULLIF(LTRIM(RTRIM(cu.CityName)), ''), '-') AS Lokasyon,
--     ISNULL(NULLIF(LTRIM(RTRIM(cu.DistrictName)), ''), '-') AS Ilce,
--     ISNULL(NULLIF(LTRIM(RTRIM(cu.CountryName)), ''), '-') AS Ulke,
--     ISNULL(NULLIF(LTRIM(RTRIM(cu.Info)), ''), '-') AS MusteriInfo,

--     CASE
--         WHEN cu.IsShopping = 1 THEN N'Evet'
--         WHEN cu.IsShopping = 0 THEN N'Hayır'
--         ELSE '-'
--     END AS AlisverisiVarMi,

--     ISNULL(NULLIF(LTRIM(RTRIM(cu.Tel)), ''), '-') AS IrtibatNumarasi,
--     ISNULL(NULLIF(LTRIM(RTRIM(cu.Email)), ''), '-') AS EmailAdresi,

--     ISNULL(NULLIF(LTRIM(RTRIM(cr.ContactResourceName)), ''), '-') AS IletisimKaynagi,

--     ISNULL(NULLIF(LTRIM(RTRIM(p.CategoryName)), ''), '-') AS CategoryName,
--     '-' AS CategoryCode,

--     ISNULL(NULLIF(LTRIM(RTRIM(ls.Name)), ''), '-') AS LeadDurumu,
--     ISNULL(NULLIF(LTRIM(RTRIM(ns.Name)), ''), '-') AS SonrakiAdim,

--     ISNULL(NULLIF(LTRIM(RTRIM(lp.Name)), ''), '-') AS ProcessName,
--     ISNULL(NULLIF(LTRIM(RTRIM(lp.Code)), ''), '-') AS ProcessCode,
--     lp.StepOrder,
    
--     -- DÜZELTİLEN ALAN: SelectedStepOrder
--     CASE
--         WHEN EXISTS
--         (
--             SELECT 1
--             FROM tmscrq.TMLeadReservation r
--             WHERE r.LeadId = l.Id
--               AND r.IsActive = 1
--               AND ISNULL(r.IsApproved,0) = 0
--         )
--         THEN 10
--         ELSE lp.StepOrder
--     END AS SelectedStepOrder,

--     ISNULL(
--         CASE
--             WHEN l.EstimatedDate IS NOT NULL
--             THEN CAST(YEAR(l.EstimatedDate) AS VARCHAR(4)) + ' ' + DATENAME(MONTH, l.EstimatedDate)
--             ELSE NULL
--         END,
--         '-'
--     ) AS TerminTarihi,

--     ISNULL(
--         NULLIF(
--             LTRIM(RTRIM(ISNULL(sp.FirstName, '') + ' ' + ISNULL(sp.LastName, '')))
--         , '')
--     , '-') AS SatisDanismani,

--     ISNULL(NULLIF(LTRIM(RTRIM(st.StoreDesc)), ''), '-') AS StoreName

-- FROM tmscrq.TMLead l
-- LEFT JOIN tmscrq.TMLeadStatu ls
--     ON ls.Id = l.StatuId
-- LEFT JOIN tmscrq.TMCustomer cu
--     ON cu.Id = l.CustomerId
-- LEFT JOIN tmscrq.TMProduct p
--     ON p.Id = l.ProductId
-- LEFT JOIN tmscrq.TMContactResource cr
--     ON cr.Id = l.ContactResourceId
-- LEFT JOIN dbo.KUser sp
--     ON sp.Id = l.SalesPersonKUserId
-- LEFT JOIN tmscrq.TMStore st
--     ON st.Id = l.StoreId
-- LEFT JOIN tmscrq.TMLeadProcess lp
--     ON lp.Id = l.ProcessID
-- LEFT JOIN tmscrq.TMLeadNextStep ns
--     ON ns.Id = l.NextStepId

-- WHERE
-- (
--     EXISTS
--     (
--         SELECT 1
--         FROM dbo.KUserRole ur
--         INNER JOIN dbo.KRole r
--             ON r.Id = ur.KRole_Id
--         WHERE ur.KUser_Id = @UserId
--           AND ur.IsDeleted = 0
--           AND r.IsDeleted = 0
--           AND r.Name IN ('TimesYonetici', 'TimesUstYonetici')
--     )
--     OR
--     (
--         EXISTS
--         (
--             SELECT 1
--             FROM dbo.KUserRole ur
--             INNER JOIN dbo.KRole r
--                 ON r.Id = ur.KRole_Id
--             WHERE ur.KUser_Id = @UserId
--               AND ur.IsDeleted = 0
--               AND r.IsDeleted = 0
--               AND r.Name IN ('TimesMagazaMuduru', 'TimesSatisPersoneli')
--         )
--         AND EXISTS
--         (
--             SELECT 1
--             FROM tmscrq.TMUser tu
--             WHERE tu.KUserID = @UserId
--               AND tu.StoreId = l.StoreId
--         )
--     )
-- )

-- AND
-- (
--     @MusteriAdi IS NULL
--     OR LTRIM(RTRIM(@MusteriAdi)) = ''
--     OR UPPER(LTRIM(RTRIM(ISNULL(cu.Name,'') + ' ' + ISNULL(cu.LastName,''))))
--        LIKE '%' + UPPER(LTRIM(RTRIM(@MusteriAdi))) + '%'
-- )

-- AND
-- (
--     @ProductName IS NULL
--     OR LTRIM(RTRIM(@ProductName)) = ''
--     OR
--     (
--         CHARINDEX(',', @ProductName) > 0
--         AND ISNULL(LTRIM(RTRIM(p.ProductName)), '') IN
--         (
--             SELECT LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', '')))
--             FROM STRING_SPLIT(CAST(@ProductName AS NVARCHAR(MAX)), ',')
--             WHERE LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', ''))) <> ''
--         )
--     )
--     OR
--     (
--         CHARINDEX(',', @ProductName) = 0
--         AND UPPER(ISNULL(LTRIM(RTRIM(p.ProductName)), ''))
--             LIKE '%' + UPPER(LTRIM(RTRIM(@ProductName))) + '%'
--     )
-- )

-- AND
-- (
--     @LeadCode IS NULL
--     OR LTRIM(RTRIM(@LeadCode)) = ''
--     OR UPPER(ISNULL(LTRIM(RTRIM(l.LeadCode)), '')) LIKE '%' + UPPER(LTRIM(RTRIM(@LeadCode))) + '%'
-- )

-- AND
-- (
--     @Tel IS NULL
--     OR LTRIM(RTRIM(@Tel)) = ''
--     OR UPPER(ISNULL(LTRIM(RTRIM(cu.Tel)), '')) LIKE '%' + UPPER(LTRIM(RTRIM(@Tel))) + '%'
-- )

-- AND
-- (
--     @CategoryName IS NULL
--     OR LTRIM(RTRIM(@CategoryName)) = ''
--     OR UPPER(ISNULL(LTRIM(RTRIM(p.CategoryName)), '')) IN
--     (
--         SELECT UPPER(LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value,'""',''),'[',''),']',''))))
--         FROM STRING_SPLIT(CAST(@CategoryName AS NVARCHAR(MAX)), ',')
--         WHERE LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value,'""',''),'[',''),']',''))) <> ''
--     )
-- )

-- AND
-- (
--     @StoreIds IS NULL
--     OR LTRIM(RTRIM(@StoreIds)) = ''
--     OR EXISTS
--     (
--         SELECT 1
--         FROM STRING_SPLIT(CAST(@StoreIds AS NVARCHAR(MAX)), ',') s
--         WHERE l.StoreId = TRY_CONVERT
--         (
--             uniqueidentifier,
--             LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(s.value, '""', ''), '[', ''), ']', '')))
--         )
--     )
-- )

-- AND
-- (
--     @SatisDanismaniIds IS NULL
--     OR LTRIM(RTRIM(@SatisDanismaniIds)) = ''
--     OR EXISTS
--     (
--         SELECT 1
--         FROM STRING_SPLIT(CAST(@SatisDanismaniIds AS NVARCHAR(MAX)), ',') s
--         WHERE l.SalesPersonKUserId = TRY_CONVERT
--         (
--             uniqueidentifier,
--             LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(s.value, '""', ''), '[', ''), ']', '')))
--         )
--     )
-- )

-- AND
-- (
--     @ProcessCode IS NULL
--     OR LTRIM(RTRIM(@ProcessCode)) = ''
--     OR UPPER(ISNULL(LTRIM(RTRIM(lp.Code)), '')) IN
--     (
--         SELECT UPPER(LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', ''))))
--         FROM STRING_SPLIT(CAST(@ProcessCode AS NVARCHAR(MAX)), ',')
--         WHERE LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', ''))) <> ''
--     )
-- )

-- -- DÜZELTİLEN ALAN: @StepOrder Filtresi (tek blok)
-- AND
-- (
--     @StepOrder IS NULL

--     OR

--     (
--         @StepOrder = 10
--         AND EXISTS
--         (
--             SELECT 1
--             FROM tmscrq.TMLeadReservation r
--             WHERE r.LeadId = l.Id
--               AND r.IsActive = 1
--               AND ISNULL(r.IsApproved,0) = 0
--         )
--     )

--     OR

--     (
--         @StepOrder <> 10
--         AND lp.StepOrder = @StepOrder
--     )
-- )

-- AND
-- (
--     @StartDate IS NULL
--     OR LTRIM(RTRIM(@StartDate)) = ''
--     OR l.CreatedAt >= CONVERT(date, @StartDate)
-- )

-- AND
-- (
--     @EndDate IS NULL
--     OR LTRIM(RTRIM(@EndDate)) = ''
--     OR l.CreatedAt < DATEADD(day, 1, CONVERT(date, @EndDate))
-- )

-- ORDER BY l.CreatedAt DESC;



SET LANGUAGE Turkish;

SELECT
CASE 
    WHEN EXISTS (
        SELECT 1 
        FROM tmscrq.TMLeadReservation r
        WHERE r.LeadId = l.Id
          AND r.IsActive = 1
          AND r.IsApproved = 1
    ) THEN N'Evet'

    WHEN EXISTS (
        SELECT 1 
        FROM tmscrq.TMLeadReservation r
        WHERE r.LeadId = l.Id
          AND r.IsActive = 1
          AND ISNULL(r.IsApproved,0) = 0
    ) THEN N'Onay Bekliyor'

    ELSE N'Hayır'
END AS RezerveDurumu,
    l.Id AS LeadId,
    l.IsReserved,
    ISNULL(NULLIF(LTRIM(RTRIM(l.LeadCode)), ''), '-') AS LeadNumarasi,
     FORMAT(l.CreatedAt, 'dd MMMM yyyy', 'tr-TR') AS TalepTarihi,

    p.Id AS ProductId,
    ISNULL(NULLIF(LTRIM(RTRIM(p.ProductName)), ''), '-') AS ProductName,
    ISNULL(NULLIF(LTRIM(RTRIM(p.Bracelet)), ''), '-') AS Bilezik,
    ISNULL(NULLIF(LTRIM(RTRIM(p.Brand)), ''), '-') AS Brand,
    ISNULL(NULLIF(LTRIM(RTRIM(p.Dial)), ''), '-') AS Kadran,
    ISNULL(NULLIF(LTRIM(RTRIM(p.ProductCode)), ''), '-') AS RefCode,
    ISNULL(NULLIF(LTRIM(RTRIM(p.Referance)), ''), '-') AS Referans,

    ISNULL(
        NULLIF(
            LTRIM(RTRIM(ISNULL(cu.Name, '') + ' ' + ISNULL(cu.LastName, '')))
        , '')
    , '-') AS Musteri,

    ISNULL(NULLIF(LTRIM(RTRIM(cu.CityName)), ''), '-') AS Lokasyon,
    ISNULL(NULLIF(LTRIM(RTRIM(cu.DistrictName)), ''), '-') AS Ilce,
    ISNULL(NULLIF(LTRIM(RTRIM(cu.CountryName)), ''), '-') AS Ulke,
    ISNULL(NULLIF(LTRIM(RTRIM(cu.Info)), ''), '-') AS MusteriInfo,

    CASE
        WHEN cu.IsShopping = 1 THEN N'Evet'
        WHEN cu.IsShopping = 0 THEN N'Hayır'
        ELSE '-'
    END AS AlisverisiVarMi,

    ISNULL(NULLIF(LTRIM(RTRIM(cu.Tel)), ''), '-') AS IrtibatNumarasi,
    ISNULL(NULLIF(LTRIM(RTRIM(cu.Email)), ''), '-') AS EmailAdresi,

    ISNULL(NULLIF(LTRIM(RTRIM(cr.ContactResourceName)), ''), '-') AS IletisimKaynagi,

    ISNULL(NULLIF(LTRIM(RTRIM(p.CategoryName)), ''), '-') AS CategoryName,
    '-' AS CategoryCode,

    ISNULL(NULLIF(LTRIM(RTRIM(ls.Name)), ''), '-') AS LeadDurumu,
    ISNULL(NULLIF(LTRIM(RTRIM(ns.Name)), ''), '-') AS SonrakiAdim,

    ISNULL(NULLIF(LTRIM(RTRIM(lp.Name)), ''), '-') AS ProcessName,
    ISNULL(NULLIF(LTRIM(RTRIM(lp.Code)), ''), '-') AS ProcessCode,
    lp.StepOrder,
    
    -- DÜZELTİLEN ALAN: SelectedStepOrder
    CASE
        WHEN EXISTS
        (
            SELECT 1
            FROM tmscrq.TMLeadReservation r
            WHERE r.LeadId = l.Id
              AND r.IsActive = 1
              AND ISNULL(r.IsApproved,0) = 0
        )
        THEN 10
        ELSE lp.StepOrder
    END AS SelectedStepOrder,

    ISNULL(
        CASE
            WHEN l.EstimatedDate IS NOT NULL
            THEN CAST(YEAR(l.EstimatedDate) AS VARCHAR(4)) + ' ' + DATENAME(MONTH, l.EstimatedDate)
            ELSE NULL
        END,
        '-'
    ) AS TerminTarihi,

    ISNULL(
        NULLIF(
            LTRIM(RTRIM(ISNULL(sp.FirstName, '') + ' ' + ISNULL(sp.LastName, '')))
        , '')
    , '-') AS SatisDanismani,

    ISNULL(NULLIF(LTRIM(RTRIM(st.StoreDesc)), ''), '-') AS StoreName

FROM tmscrq.TMLead l
LEFT JOIN tmscrq.TMLeadStatu ls
    ON ls.Id = l.StatuId
LEFT JOIN tmscrq.TMCustomer cu
    ON cu.Id = l.CustomerId
LEFT JOIN tmscrq.TMProduct p
    ON p.Id = l.ProductId
LEFT JOIN tmscrq.TMContactResource cr
    ON cr.Id = l.ContactResourceId
LEFT JOIN dbo.KUser sp
    ON sp.Id = l.SalesPersonKUserId
LEFT JOIN tmscrq.TMStore st
    ON st.Id = l.StoreId
LEFT JOIN tmscrq.TMLeadProcess lp
    ON lp.Id = l.ProcessID
LEFT JOIN tmscrq.TMLeadNextStep ns
    ON ns.Id = l.NextStepId

WHERE
(
    EXISTS
    (
        SELECT 1
        FROM dbo.KUserRole ur
        INNER JOIN dbo.KRole r
            ON r.Id = ur.KRole_Id
        WHERE ur.KUser_Id = @UserId
          AND ur.IsDeleted = 0
          AND r.IsDeleted = 0
          AND r.Name IN ('TimesYonetici', 'TimesUstYonetici')
    )
    OR
    (
        EXISTS
        (
            SELECT 1
            FROM dbo.KUserRole ur
            INNER JOIN dbo.KRole r
                ON r.Id = ur.KRole_Id
            WHERE ur.KUser_Id = @UserId
              AND ur.IsDeleted = 0
              AND r.IsDeleted = 0
              AND r.Name IN ('TimesMagazaMuduru', 'TimesSatisPersoneli')
        )
        AND EXISTS
        (
            SELECT 1
            FROM tmscrq.TMUser tu
            WHERE tu.KUserID = @UserId
              AND tu.StoreId = l.StoreId
        )
    )
)

AND
(
    ISNULL(@MusteriAdi, '') = ''
    OR UPPER(ISNULL(cu.Name, '')) LIKE '%' + UPPER(LTRIM(RTRIM(@MusteriAdi))) + '%'
    OR UPPER(ISNULL(cu.LastName, '')) LIKE '%' + UPPER(LTRIM(RTRIM(@MusteriAdi))) + '%'
    OR UPPER(
        ISNULL(cu.Name, '') + ' ' + ISNULL(cu.LastName, '')
    ) LIKE '%' + UPPER(LTRIM(RTRIM(@MusteriAdi))) + '%'
)

AND
(
    @ProductName IS NULL
    OR LTRIM(RTRIM(@ProductName)) = ''
    OR
    (
        CHARINDEX(',', @ProductName) > 0
        AND ISNULL(LTRIM(RTRIM(p.ProductName)), '') IN
        (
            SELECT LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', '')))
            FROM STRING_SPLIT(CAST(@ProductName AS NVARCHAR(MAX)), ',')
            WHERE LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', ''))) <> ''
        )
    )
    OR
    (
        CHARINDEX(',', @ProductName) = 0
        AND UPPER(ISNULL(LTRIM(RTRIM(p.ProductName)), ''))
            LIKE '%' + UPPER(LTRIM(RTRIM(@ProductName))) + '%'
    )
)

AND
(
    ISNULL(@LeadCode, '') = ''
    OR UPPER(ISNULL(l.LeadCode, ''))
        LIKE '%' + UPPER(LTRIM(RTRIM(@LeadCode))) + '%'
    OR REPLACE(
        REPLACE(
            REPLACE(
                UPPER(ISNULL(l.LeadCode, '')),
                '-', ''
            ),
            ' ', ''
        ),
        '/', ''
    )
    LIKE '%' +
    REPLACE(
        REPLACE(
            REPLACE(
                UPPER(LTRIM(RTRIM(@LeadCode))),
                '-', ''
            ),
            ' ', ''
        ),
        '/', ''
    )
    + '%'
)

AND
(
    @Tel IS NULL
    OR LTRIM(RTRIM(@Tel)) = ''
    OR UPPER(ISNULL(LTRIM(RTRIM(cu.Tel)), '')) LIKE '%' + UPPER(LTRIM(RTRIM(@Tel))) + '%'
)

AND
(
    @CategoryName IS NULL
    OR LTRIM(RTRIM(@CategoryName)) = ''
    OR UPPER(ISNULL(LTRIM(RTRIM(p.CategoryName)), '')) IN
    (
        SELECT UPPER(LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value,'""',''),'[',''),']',''))))
        FROM STRING_SPLIT(CAST(@CategoryName AS NVARCHAR(MAX)), ',')
        WHERE LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value,'""',''),'[',''),']',''))) <> ''
    )
)

AND
(
    @StoreIds IS NULL
    OR LTRIM(RTRIM(@StoreIds)) = ''
    OR EXISTS
    (
        SELECT 1
        FROM STRING_SPLIT(CAST(@StoreIds AS NVARCHAR(MAX)), ',') s
        WHERE l.StoreId = TRY_CONVERT
        (
            uniqueidentifier,
            LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(s.value, '""', ''), '[', ''), ']', '')))
        )
    )
)

AND
(
    @SatisDanismaniIds IS NULL
    OR LTRIM(RTRIM(@SatisDanismaniIds)) = ''
    OR EXISTS
    (
        SELECT 1
        FROM STRING_SPLIT(CAST(@SatisDanismaniIds AS NVARCHAR(MAX)), ',') s
        WHERE l.SalesPersonKUserId = TRY_CONVERT
        (
            uniqueidentifier,
            LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(s.value, '""', ''), '[', ''), ']', '')))
        )
    )
)

AND
(
    ISNULL(@ProcessCode, '') = ''
    OR EXISTS
    (
        SELECT 1
        FROM STRING_SPLIT(
            CONVERT(NVARCHAR(MAX), @ProcessCode),
            ','
        ) AS s
        WHERE
            UPPER(LTRIM(RTRIM(s.value))) =
            UPPER(LTRIM(RTRIM(ISNULL(lp.Code, ''))))
    )
)

-- DÜZELTİLEN ALAN: @StepOrder Filtresi (0 verilince tümü gelsin)
AND
(
    @StepOrder IS NULL
    OR @StepOrder = 0  -- 👈 YENİ EKLENDI: 0 verilince tüm kayıtlar gelir
    OR
    (
        @StepOrder = 10
        AND EXISTS
        (
            SELECT 1
            FROM tmscrq.TMLeadReservation r
            WHERE r.LeadId = l.Id
              AND r.IsActive = 1
              AND ISNULL(r.IsApproved,0) = 0
        )
    )
    OR
    (
        @StepOrder <> 10
        AND lp.StepOrder = @StepOrder
    )
)

AND
(
    @StartDate IS NULL
    OR LTRIM(RTRIM(@StartDate)) = ''
    OR l.CreatedAt >= CONVERT(date, @StartDate)
)

AND
(
    @EndDate IS NULL
    OR LTRIM(RTRIM(@EndDate)) = ''
    OR l.CreatedAt < DATEADD(day, 1, CONVERT(date, @EndDate))
)

ORDER BY l.CreatedAt DESC;", new string[] { "RezerveDurumu", "LeadId", "IsReserved", "LeadNumarasi", "TalepTarihi", "ProductId", "ProductName", "Bilezik", "Brand", "Kadran", "RefCode", "Referans", "Musteri", "Lokasyon", "Ilce", "Ulke", "MusteriInfo", "AlisverisiVarMi", "IrtibatNumarasi", "EmailAdresi", "IletisimKaynagi", "CategoryName", "CategoryCode", "LeadDurumu", "SonrakiAdim", "ProcessName", "ProcessCode", "StepOrder", "SelectedStepOrder", "TerminTarihi", "SatisDanismani", "StoreName" }, prms_TM_GetLeads_0.ToArray());
            ;

            var prms_TMLeadProcessCountSummary_1 = new List<kSqlParameter>();
            prms_TMLeadProcessCountSummary_1.Add(new kSqlParameter() { Name = "UserId", Value = Kuika.Common.KContext.CurrentUser?.Id });
            prms_TMLeadProcessCountSummary_1.Add(new kSqlParameter() { Name = "MusteriAdi", Value = request.MusteriAdi_1 });
            prms_TMLeadProcessCountSummary_1.Add(new kSqlParameter() { Name = "ProductName", Value = request.ProductName_1 });
            prms_TMLeadProcessCountSummary_1.Add(new kSqlParameter() { Name = "LeadCode", Value = request.LeadCode_1 });
            prms_TMLeadProcessCountSummary_1.Add(new kSqlParameter() { Name = "Tel", Value = request.Tel_1 });
            prms_TMLeadProcessCountSummary_1.Add(new kSqlParameter() { Name = "CategoryName", Value = request.CategoryName_1 });
            prms_TMLeadProcessCountSummary_1.Add(new kSqlParameter() { Name = "StoreIds", Value = request.StoreIds_1 });
            prms_TMLeadProcessCountSummary_1.Add(new kSqlParameter() { Name = "SatisDanismaniIds", Value = request.SatisDanismaniIds_1 });
            prms_TMLeadProcessCountSummary_1.Add(new kSqlParameter() { Name = "ProcessCode", Value = request.ProcessCode_1 });
            prms_TMLeadProcessCountSummary_1.Add(new kSqlParameter() { Name = "StartDate", Value = request.StartDate_1 });
            prms_TMLeadProcessCountSummary_1.Add(new kSqlParameter() { Name = "EndDate", Value = request.EndDate_1 });
            using var auditTMLeadProcessCountSummary_1 = ActionAuditScope.Begin("f6242f42-2d00-4ee7-d027-1131265b21e3", "TMLeadProcessCountSummary", applicationName: "wbTimesCRM", screenOrEndpointName: "LeadList");
            result.TMLeadProcessCountSummary = KPersister.Fetch(KContext.GetConnectionString(), @"-- SELECT
--     COUNT(*) AS ToplamTalepSayisi,

--     SUM(CASE WHEN lp.Code = 'PENDING' THEN 1 ELSE 0 END) AS OnayBekleyenSayisi,
--     SUM(CASE WHEN lp.Code = 'TERMIN_PENDING' THEN 1 ELSE 0 END) AS TerminBekleyenSayisi,
--     SUM(CASE WHEN lp.Code = 'APPROVED' THEN 1 ELSE 0 END) AS OnaylananSayisi,
--     SUM(CASE WHEN lp.Code = 'REJECTED' THEN 1 ELSE 0 END) AS ReddedilenSayisi,
--     SUM(CASE WHEN lp.Code = 'DELIVERY_PENDING' THEN 1 ELSE 0 END) AS TeslimEdilecekSayisi,
--     SUM(CASE WHEN lp.Code = 'DELIVERED' THEN 1 ELSE 0 END) AS TeslimEdildiSayisi

-- FROM tmscrq.TMLead l
-- LEFT JOIN tmscrq.TMCustomer cu
--     ON cu.Id = l.CustomerId
-- LEFT JOIN tmscrq.TMProduct p
--     ON p.Id = l.ProductId
-- LEFT JOIN dbo.KUser sp
--     ON sp.Id = l.SalesPersonKUserId
-- LEFT JOIN tmscrq.TMLeadProcess lp
--     ON lp.Id = l.ProcessID

-- WHERE
-- (
--     EXISTS
--     (
--         SELECT 1
--         FROM dbo.KUserRole ur
--         INNER JOIN dbo.KRole r
--             ON r.Id = ur.KRole_Id
--         WHERE ur.KUser_Id = @UserId
--           AND ur.IsDeleted = 0
--           AND r.IsDeleted = 0
--           AND r.Name IN ('TimesYonetici', 'TimesUstYonetici')
--     )
--     OR
--     (
--         EXISTS
--         (
--             SELECT 1
--             FROM dbo.KUserRole ur
--             INNER JOIN dbo.KRole r
--                 ON r.Id = ur.KRole_Id
--             WHERE ur.KUser_Id = @UserId
--               AND ur.IsDeleted = 0
--               AND r.IsDeleted = 0
--               AND r.Name IN ('TimesMagazaMuduru', 'TimesSatisPersoneli')
--         )
--         AND EXISTS
--         (
--             SELECT 1
--             FROM tmscrq.TMUser tu
--             WHERE tu.KUserID = @UserId
--               AND tu.StoreId = l.StoreId
--         )
--     )
-- )

-- AND
-- (
--     @MusteriAdi IS NULL
--     OR LTRIM(RTRIM(@MusteriAdi)) = ''
--     OR UPPER(LTRIM(RTRIM(ISNULL(cu.Name, '') + ' ' + ISNULL(cu.LastName, ''))))
--        LIKE '%' + UPPER(LTRIM(RTRIM(@MusteriAdi))) + '%'
-- )

-- AND
-- (
--     @ProductName IS NULL
--     OR LTRIM(RTRIM(@ProductName)) = ''
--     OR
--     (
--         CHARINDEX(',', @ProductName) > 0
--         AND ISNULL(LTRIM(RTRIM(p.ProductName)), '') IN
--         (
--             SELECT LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', '')))
--             FROM STRING_SPLIT(CAST(@ProductName AS NVARCHAR(MAX)), ',')
--             WHERE LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', ''))) <> ''
--         )
--     )
--     OR
--     (
--         CHARINDEX(',', @ProductName) = 0
--         AND UPPER(ISNULL(LTRIM(RTRIM(p.ProductName)), ''))
--             LIKE '%' + UPPER(LTRIM(RTRIM(@ProductName))) + '%'
--     )
-- )

-- AND
-- (
--     @LeadCode IS NULL
--     OR LTRIM(RTRIM(@LeadCode)) = ''
--     OR UPPER(ISNULL(LTRIM(RTRIM(l.LeadCode)), '')) LIKE '%' + UPPER(LTRIM(RTRIM(@LeadCode))) + '%'
-- )

-- AND
-- (
--     @Tel IS NULL
--     OR LTRIM(RTRIM(@Tel)) = ''
--     OR UPPER(ISNULL(LTRIM(RTRIM(cu.Tel)), '')) LIKE '%' + UPPER(LTRIM(RTRIM(@Tel))) + '%'
-- )

-- AND
-- (
--     @CategoryName IS NULL
--     OR LTRIM(RTRIM(@CategoryName)) = ''
--     OR
--     (
--         EXISTS
--         (
--             SELECT 1
--             FROM STRING_SPLIT(CAST(@CategoryName AS NVARCHAR(MAX)), ',') c
--             WHERE UPPER(LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(c.value, '""', ''), '[', ''), ']', '')))) = 'DEFAULT'
--         )
--         AND (p.CategoryName IS NULL OR LTRIM(RTRIM(p.CategoryName)) = '')
--     )
--     OR UPPER(ISNULL(LTRIM(RTRIM(p.CategoryName)), '')) IN
--     (
--         SELECT UPPER(LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', ''))))
--         FROM STRING_SPLIT(CAST(@CategoryName AS NVARCHAR(MAX)), ',')
--         WHERE LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', ''))) <> ''
--           AND UPPER(LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', '')))) <> 'DEFAULT'
--     )
-- )

-- AND
-- (
--     @StoreIds IS NULL
--     OR LTRIM(RTRIM(@StoreIds)) = ''
--     OR EXISTS
--     (
--         SELECT 1
--         FROM STRING_SPLIT(CAST(@StoreIds AS NVARCHAR(MAX)), ',') s
--         WHERE l.StoreId = TRY_CONVERT
--         (
--             uniqueidentifier,
--             LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(s.value, '""', ''), '[', ''), ']', '')))
--         )
--     )
-- )

-- AND
-- (
--     @SatisDanismaniIds IS NULL
--     OR LTRIM(RTRIM(@SatisDanismaniIds)) = ''
--     OR EXISTS
--     (
--         SELECT 1
--         FROM STRING_SPLIT(CAST(@SatisDanismaniIds AS NVARCHAR(MAX)), ',') s
--         WHERE l.SalesPersonKUserId = TRY_CONVERT
--         (
--             uniqueidentifier,
--             LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(s.value, '""', ''), '[', ''), ']', '')))
--         )
--     )
-- )

-- AND
-- (
--     @ProcessCode IS NULL
--     OR LTRIM(RTRIM(@ProcessCode)) = ''
--     OR UPPER(ISNULL(LTRIM(RTRIM(lp.Code)), '')) IN
--     (
--         SELECT UPPER(LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', ''))))
--         FROM STRING_SPLIT(CAST(@ProcessCode AS NVARCHAR(MAX)), ',')
--         WHERE LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', ''))) <> ''
--     )
-- )

-- AND
-- (
--     @StartDate IS NULL
--     OR LTRIM(RTRIM(@StartDate)) = ''
--     OR l.CreatedAt >= CONVERT(date, @StartDate)
-- )

-- AND
-- (
--     @EndDate IS NULL
--     OR LTRIM(RTRIM(@EndDate)) = ''
--     OR l.CreatedAt < DATEADD(day, 1, CONVERT(date, @EndDate))
-- );

-------------------------------------------------------------

DECLARE @KUserId UNIQUEIDENTIFIER = @UserId;

WITH UserRoles AS (
    SELECT r.Name
    FROM dbo.KUserRole ur
    INNER JOIN dbo.KRole r 
        ON r.Id = ur.KRole_Id
    WHERE ur.KUser_Id = @KUserId
      AND ur.IsDeleted = 0
      AND r.IsDeleted = 0
),
IsAdmin AS (
    SELECT CASE 
        WHEN EXISTS (
            SELECT 1 
            FROM UserRoles 
            WHERE Name = 'TimesUstYonetici'
        ) THEN 1 ELSE 0 END AS IsAdmin
)

SELECT
    COUNT(*) AS ToplamTalepSayisi,

    SUM(CASE WHEN lp.Code = 'PENDING' THEN 1 ELSE 0 END) AS OnayBekleyenSayisi,
    SUM(CASE WHEN lp.Code = 'TERMIN_PENDING' THEN 1 ELSE 0 END) AS TerminBekleyenSayisi,
    SUM(CASE WHEN lp.Code = 'APPROVED' THEN 1 ELSE 0 END) AS OnaylananSayisi,
    SUM(CASE WHEN lp.Code = 'REJECTED' THEN 1 ELSE 0 END) AS ReddedilenSayisi,
    SUM(CASE WHEN lp.Code = 'DELIVERY_PENDING' THEN 1 ELSE 0 END) AS TeslimEdilecekSayisi,
    SUM(CASE WHEN lp.Code = 'DELIVERED' THEN 1 ELSE 0 END) AS TeslimEdildiSayisi

FROM tmscrq.TMLead l
LEFT JOIN tmscrq.TMCustomer cu
    ON cu.Id = l.CustomerId
LEFT JOIN tmscrq.TMProduct p
    ON p.Id = l.ProductId
LEFT JOIN dbo.KUser sp
    ON sp.Id = l.SalesPersonKUserId
LEFT JOIN tmscrq.TMLeadProcess lp
    ON lp.Id = l.ProcessID

CROSS JOIN IsAdmin a

WHERE
(
    -- admin → full
    a.IsAdmin = 1

    -- diğerleri → sadece kendi mağazaları
    OR EXISTS
    (
        SELECT 1
        FROM tmscrq.TMUser tu
        WHERE tu.KUserID = @KUserId
          AND tu.StoreId = l.StoreId
    )
)

-- 🔽 AŞAĞISI SENİN ORİJİNAL FİLTRELER (HİÇ DOKUNMADIM)

AND
(
    @MusteriAdi IS NULL
    OR LTRIM(RTRIM(@MusteriAdi)) = ''
    OR UPPER(LTRIM(RTRIM(ISNULL(cu.Name, '') + ' ' + ISNULL(cu.LastName, ''))))
       LIKE '%' + UPPER(LTRIM(RTRIM(@MusteriAdi))) + '%'
)

AND
(
    @ProductName IS NULL
    OR LTRIM(RTRIM(@ProductName)) = ''
    OR
    (
        CHARINDEX(',', @ProductName) > 0
        AND ISNULL(LTRIM(RTRIM(p.ProductName)), '') IN
        (
            SELECT LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', '')))
            FROM STRING_SPLIT(CAST(@ProductName AS NVARCHAR(MAX)), ',')
        )
    )
    OR
    (
        CHARINDEX(',', @ProductName) = 0
        AND UPPER(ISNULL(LTRIM(RTRIM(p.ProductName)), ''))
            LIKE '%' + UPPER(LTRIM(RTRIM(@ProductName))) + '%'
    )
)

AND
(
    @LeadCode IS NULL
    OR LTRIM(RTRIM(@LeadCode)) = ''
    OR UPPER(ISNULL(LTRIM(RTRIM(l.LeadCode)), '')) LIKE '%' + UPPER(LTRIM(RTRIM(@LeadCode))) + '%'
)

AND
(
    @Tel IS NULL
    OR LTRIM(RTRIM(@Tel)) = ''
    OR UPPER(ISNULL(LTRIM(RTRIM(cu.Tel)), '')) LIKE '%' + UPPER(LTRIM(RTRIM(@Tel))) + '%'
)

AND
(
    @CategoryName IS NULL
    OR LTRIM(RTRIM(@CategoryName)) = ''
    OR
    (
        EXISTS
        (
            SELECT 1
            FROM STRING_SPLIT(CAST(@CategoryName AS NVARCHAR(MAX)), ',') c
            WHERE UPPER(LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(c.value, '""', ''), '[', ''), ']', '')))) = 'DEFAULT'
        )
        AND (p.CategoryName IS NULL OR LTRIM(RTRIM(p.CategoryName)) = '')
    )
    OR UPPER(ISNULL(LTRIM(RTRIM(p.CategoryName)), '')) IN
    (
        SELECT UPPER(LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', ''))))
        FROM STRING_SPLIT(CAST(@CategoryName AS NVARCHAR(MAX)), ',')
    )
)

AND
(
    @StoreIds IS NULL
    OR LTRIM(RTRIM(@StoreIds)) = ''
    OR EXISTS
    (
        SELECT 1
        FROM STRING_SPLIT(CAST(@StoreIds AS NVARCHAR(MAX)), ',') s
        WHERE l.StoreId = TRY_CONVERT
        (
            uniqueidentifier,
            LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(s.value, '""', ''), '[', ''), ']', '')))
        )
    )
)

AND
(
    @SatisDanismaniIds IS NULL
    OR LTRIM(RTRIM(@SatisDanismaniIds)) = ''
    OR EXISTS
    (
        SELECT 1
        FROM STRING_SPLIT(CAST(@SatisDanismaniIds AS NVARCHAR(MAX)), ',') s
        WHERE l.SalesPersonKUserId = TRY_CONVERT
        (
            uniqueidentifier,
            LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(s.value, '""', ''), '[', ''), ']', '')))
        )
    )
)

AND
(
    @ProcessCode IS NULL
    OR LTRIM(RTRIM(@ProcessCode)) = ''
    OR UPPER(ISNULL(LTRIM(RTRIM(lp.Code)), '')) IN
    (
        SELECT UPPER(LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', ''))))
        FROM STRING_SPLIT(CAST(@ProcessCode AS NVARCHAR(MAX)), ',')
    )
)

AND
(
    @StartDate IS NULL
    OR LTRIM(RTRIM(@StartDate)) = ''
    OR l.CreatedAt >= CONVERT(date, @StartDate)
)

AND
(
    @EndDate IS NULL
    OR LTRIM(RTRIM(@EndDate)) = ''
    OR l.CreatedAt < DATEADD(day, 1, CONVERT(date, @EndDate))
);", new string[] { "ToplamTalepSayisi", "OnayBekleyenSayisi", "TerminBekleyenSayisi", "OnaylananSayisi", "ReddedilenSayisi", "TeslimEdilecekSayisi", "TeslimEdildiSayisi" }, prms_TMLeadProcessCountSummary_1.ToArray());
            ;


            return Ok(result);
        }


        [HttpPost, Route("LeadListComponent_836823_onChange")]
        public IActionResult LeadListComponent_836823_onChange(LeadListComponent_836823_onChange_Request request)
        {

            KProviderManager.Authorization.IsAuthorizedForRoles(appId, appName, screenId, screenName, new List<string> { $"70de6cfc-6087-6059-59b4-0b5a8527af6b", "4da1f213-c8e4-0b50-5c84-02fd13f1a622", "c4e882ef-977d-f613-7694-230ac83919d2", "b4bfd39c-ac02-f442-c899-7a2374a45b47", "cdb536b0-6297-155f-d446-8453d8a60304", "TimesYonetici", "TimesUstYonetici", "TimesSatisPersoneli", "TimesMagazaMuduru", "TimesAdmin" });

            var result = new LeadListComponent_836823_onChange_Response();

            var prms_TM_GetLeads_0 = new List<kSqlParameter>();
            prms_TM_GetLeads_0.Add(new kSqlParameter() { Name = "StepOrder", Value = request.StepOrder_0 });
            prms_TM_GetLeads_0.Add(new kSqlParameter() { Name = "UserId", Value = Kuika.Common.KContext.CurrentUser?.Id });
            prms_TM_GetLeads_0.Add(new kSqlParameter() { Name = "MusteriAdi", Value = request.MusteriAdi_0 });
            prms_TM_GetLeads_0.Add(new kSqlParameter() { Name = "ProductName", Value = request.ProductName_0 });
            prms_TM_GetLeads_0.Add(new kSqlParameter() { Name = "LeadCode", Value = request.LeadCode_0 });
            prms_TM_GetLeads_0.Add(new kSqlParameter() { Name = "Tel", Value = request.Tel_0 });
            prms_TM_GetLeads_0.Add(new kSqlParameter() { Name = "CategoryName", Value = request.CategoryName_0 });
            prms_TM_GetLeads_0.Add(new kSqlParameter() { Name = "StoreIds", Value = request.StoreIds_0 });
            prms_TM_GetLeads_0.Add(new kSqlParameter() { Name = "SatisDanismaniIds", Value = request.SatisDanismaniIds_0 });
            prms_TM_GetLeads_0.Add(new kSqlParameter() { Name = "ProcessCode", Value = request.ProcessCode_0 });
            prms_TM_GetLeads_0.Add(new kSqlParameter() { Name = "StartDate", Value = request.StartDate_0 });
            prms_TM_GetLeads_0.Add(new kSqlParameter() { Name = "EndDate", Value = request.EndDate_0 });
            using var auditTM_GetLeads_0 = ActionAuditScope.Begin("47794849-569d-219a-64c4-c219f0bcd94f", "TM_GetLeads", applicationName: "wbTimesCRM", screenOrEndpointName: "LeadList");
            result.TM_GetLeads = KPersister.Fetch(KContext.GetConnectionString(), @"-- SET LANGUAGE Turkish;

-- SELECT
-- CASE 
--     WHEN EXISTS (
--         SELECT 1 
--         FROM tmscrq.TMLeadReservation r
--         WHERE r.LeadId = l.Id
--           AND r.IsActive = 1
--           AND r.IsApproved = 1
--     ) THEN N'Evet'

--     WHEN EXISTS (
--         SELECT 1 
--         FROM tmscrq.TMLeadReservation r
--         WHERE r.LeadId = l.Id
--           AND r.IsActive = 1
--           AND ISNULL(r.IsApproved,0) = 0
--     ) THEN N'Onay Bekliyor'

--     ELSE N'Hayır'
-- END AS RezerveDurumu,
--     l.Id AS LeadId,
--     l.IsReserved,
--     ISNULL(NULLIF(LTRIM(RTRIM(l.LeadCode)), ''), '-') AS LeadNumarasi,
--     CONVERT(varchar(10), l.CreatedAt, 103) AS TalepTarihi,

--     p.Id AS ProductId,
--     ISNULL(NULLIF(LTRIM(RTRIM(p.ProductName)), ''), '-') AS ProductName,
--     ISNULL(NULLIF(LTRIM(RTRIM(p.Bracelet)), ''), '-') AS Bilezik,
--     ISNULL(NULLIF(LTRIM(RTRIM(p.Brand)), ''), '-') AS Brand,
--     ISNULL(NULLIF(LTRIM(RTRIM(p.Dial)), ''), '-') AS Kadran,
--     ISNULL(NULLIF(LTRIM(RTRIM(p.ProductCode)), ''), '-') AS RefCode,
--     ISNULL(NULLIF(LTRIM(RTRIM(p.Referance)), ''), '-') AS Referans,

--     ISNULL(
--         NULLIF(
--             LTRIM(RTRIM(ISNULL(cu.Name, '') + ' ' + ISNULL(cu.LastName, '')))
--         , '')
--     , '-') AS Musteri,

--     ISNULL(NULLIF(LTRIM(RTRIM(cu.CityName)), ''), '-') AS Lokasyon,
--     ISNULL(NULLIF(LTRIM(RTRIM(cu.DistrictName)), ''), '-') AS Ilce,
--     ISNULL(NULLIF(LTRIM(RTRIM(cu.CountryName)), ''), '-') AS Ulke,
--     ISNULL(NULLIF(LTRIM(RTRIM(cu.Info)), ''), '-') AS MusteriInfo,

--     CASE
--         WHEN cu.IsShopping = 1 THEN N'Evet'
--         WHEN cu.IsShopping = 0 THEN N'Hayır'
--         ELSE '-'
--     END AS AlisverisiVarMi,

--     ISNULL(NULLIF(LTRIM(RTRIM(cu.Tel)), ''), '-') AS IrtibatNumarasi,
--     ISNULL(NULLIF(LTRIM(RTRIM(cu.Email)), ''), '-') AS EmailAdresi,

--     ISNULL(NULLIF(LTRIM(RTRIM(cr.ContactResourceName)), ''), '-') AS IletisimKaynagi,

--     ISNULL(NULLIF(LTRIM(RTRIM(p.CategoryName)), ''), '-') AS CategoryName,
--     '-' AS CategoryCode,

--     ISNULL(NULLIF(LTRIM(RTRIM(ls.Name)), ''), '-') AS LeadDurumu,
--     ISNULL(NULLIF(LTRIM(RTRIM(ns.Name)), ''), '-') AS SonrakiAdim,

--     ISNULL(NULLIF(LTRIM(RTRIM(lp.Name)), ''), '-') AS ProcessName,
--     ISNULL(NULLIF(LTRIM(RTRIM(lp.Code)), ''), '-') AS ProcessCode,
--     lp.StepOrder,
-- CASE
--     WHEN EXISTS
--     (
--         SELECT 1
--         FROM tmscrq.TMLeadReservation r
--         WHERE r.LeadId = l.Id
--           AND r.IsActive = 1
--           AND ISNULL(r.IsApproved,0) = 0
--     )
--     THEN 10
--     ELSE lp.StepOrder
-- END AS SelectedStepOrder,

--     ISNULL(
--         CASE
--             WHEN l.EstimatedDate IS NOT NULL
--             THEN CAST(YEAR(l.EstimatedDate) AS VARCHAR(4)) + ' ' + DATENAME(MONTH, l.EstimatedDate)
--             ELSE NULL
--         END,
--         '-'
--     ) AS TerminTarihi,

--     ISNULL(
--         NULLIF(
--             LTRIM(RTRIM(ISNULL(sp.FirstName, '') + ' ' + ISNULL(sp.LastName, '')))
--         , '')
--     , '-') AS SatisDanismani,

--     ISNULL(NULLIF(LTRIM(RTRIM(st.StoreDesc)), ''), '-') AS StoreName

-- FROM tmscrq.TMLead l
-- LEFT JOIN tmscrq.TMLeadStatu ls
--     ON ls.Id = l.StatuId
-- LEFT JOIN tmscrq.TMCustomer cu
--     ON cu.Id = l.CustomerId
-- LEFT JOIN tmscrq.TMProduct p
--     ON p.Id = l.ProductId
-- LEFT JOIN tmscrq.TMContactResource cr
--     ON cr.Id = l.ContactResourceId
-- LEFT JOIN dbo.KUser sp
--     ON sp.Id = l.SalesPersonKUserId
-- LEFT JOIN tmscrq.TMStore st
--     ON st.Id = l.StoreId
-- LEFT JOIN tmscrq.TMLeadProcess lp
--     ON lp.Id = l.ProcessID
-- LEFT JOIN tmscrq.TMLeadNextStep ns
--     ON ns.Id = l.NextStepId

-- WHERE
-- (
--     EXISTS
--     (
--         SELECT 1
--         FROM dbo.KUserRole ur
--         INNER JOIN dbo.KRole r
--             ON r.Id = ur.KRole_Id
--         WHERE ur.KUser_Id = @UserId
--           AND ur.IsDeleted = 0
--           AND r.IsDeleted = 0
--           AND r.Name IN ('TimesYonetici', 'TimesUstYonetici')
--     )
--     OR
--     (
--         EXISTS
--         (
--             SELECT 1
--             FROM dbo.KUserRole ur
--             INNER JOIN dbo.KRole r
--                 ON r.Id = ur.KRole_Id
--             WHERE ur.KUser_Id = @UserId
--               AND ur.IsDeleted = 0
--               AND r.IsDeleted = 0
--               AND r.Name IN ('TimesMagazaMuduru', 'TimesSatisPersoneli')
--         )
--         AND EXISTS
--         (
--             SELECT 1
--             FROM tmscrq.TMUser tu
--             WHERE tu.KUserID = @UserId
--               AND tu.StoreId = l.StoreId
--         )
--     )
-- )

-- AND
-- (
--     @MusteriAdi IS NULL
--     OR LTRIM(RTRIM(@MusteriAdi)) = ''
--     OR UPPER(LTRIM(RTRIM(ISNULL(cu.Name,'') + ' ' + ISNULL(cu.LastName,''))))
--        LIKE '%' + UPPER(LTRIM(RTRIM(@MusteriAdi))) + '%'
-- )

-- AND
-- (
--     @ProductName IS NULL
--     OR LTRIM(RTRIM(@ProductName)) = ''
--     OR
--     (
--         CHARINDEX(',', @ProductName) > 0
--         AND ISNULL(LTRIM(RTRIM(p.ProductName)), '') IN
--         (
--             SELECT LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', '')))
--             FROM STRING_SPLIT(CAST(@ProductName AS NVARCHAR(MAX)), ',')
--             WHERE LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', ''))) <> ''
--         )
--     )
--     OR
--     (
--         CHARINDEX(',', @ProductName) = 0
--         AND UPPER(ISNULL(LTRIM(RTRIM(p.ProductName)), ''))
--             LIKE '%' + UPPER(LTRIM(RTRIM(@ProductName))) + '%'
--     )
-- )

-- AND
-- (
--     @LeadCode IS NULL
--     OR LTRIM(RTRIM(@LeadCode)) = ''
--     OR UPPER(ISNULL(LTRIM(RTRIM(l.LeadCode)), '')) LIKE '%' + UPPER(LTRIM(RTRIM(@LeadCode))) + '%'
-- )

-- AND
-- (
--     @Tel IS NULL
--     OR LTRIM(RTRIM(@Tel)) = ''
--     OR UPPER(ISNULL(LTRIM(RTRIM(cu.Tel)), '')) LIKE '%' + UPPER(LTRIM(RTRIM(@Tel))) + '%'
-- )

-- -- AND
-- -- (
-- --     @CategoryName IS NULL
-- --     OR LTRIM(RTRIM(@CategoryName)) = ''
-- --     OR
-- --     (
-- --         EXISTS
-- --         (
-- --             SELECT 1
-- --             FROM STRING_SPLIT(CAST(@CategoryName AS NVARCHAR(MAX)), ',') c
-- --             WHERE UPPER(LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(c.value, '""', ''), '[', ''), ']', '')))) = 'DEFAULT'
-- --         )
-- --         AND (p.CategoryName IS NULL OR LTRIM(RTRIM(p.CategoryName)) = '')
-- --     )
-- --     OR UPPER(ISNULL(LTRIM(RTRIM(p.CategoryName)), '')) IN
-- --     (
-- --         SELECT UPPER(LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', ''))))
-- --         FROM STRING_SPLIT(CAST(@CategoryName AS NVARCHAR(MAX)), ',')
-- --         WHERE LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', ''))) <> ''
-- --           AND UPPER(LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', '')))) <> 'DEFAULT'
-- --     )
-- -- )

-- AND
-- (
--     @CategoryName IS NULL
--     OR LTRIM(RTRIM(@CategoryName)) = ''
--     OR UPPER(ISNULL(LTRIM(RTRIM(p.CategoryName)), '')) IN
--     (
--         SELECT UPPER(LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value,'""',''),'[',''),']',''))))
--         FROM STRING_SPLIT(CAST(@CategoryName AS NVARCHAR(MAX)), ',')
--         WHERE LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value,'""',''),'[',''),']',''))) <> ''
--     )
-- )

-- AND
-- (
--     @StoreIds IS NULL
--     OR LTRIM(RTRIM(@StoreIds)) = ''
--     OR EXISTS
--     (
--         SELECT 1
--         FROM STRING_SPLIT(CAST(@StoreIds AS NVARCHAR(MAX)), ',') s
--         WHERE l.StoreId = TRY_CONVERT
--         (
--             uniqueidentifier,
--             LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(s.value, '""', ''), '[', ''), ']', '')))
--         )
--     )
-- )

-- AND
-- (
--     @SatisDanismaniIds IS NULL
--     OR LTRIM(RTRIM(@SatisDanismaniIds)) = ''
--     OR EXISTS
--     (
--         SELECT 1
--         FROM STRING_SPLIT(CAST(@SatisDanismaniIds AS NVARCHAR(MAX)), ',') s
--         WHERE l.SalesPersonKUserId = TRY_CONVERT
--         (
--             uniqueidentifier,
--             LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(s.value, '""', ''), '[', ''), ']', '')))
--         )
--     )
-- )

-- AND
-- (
--     @ProcessCode IS NULL
--     OR LTRIM(RTRIM(@ProcessCode)) = ''
--     OR UPPER(ISNULL(LTRIM(RTRIM(lp.Code)), '')) IN
--     (
--         SELECT UPPER(LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', ''))))
--         FROM STRING_SPLIT(CAST(@ProcessCode AS NVARCHAR(MAX)), ',')
--         WHERE LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', ''))) <> ''
--     )
-- )

-- AND
-- (
--     @StepOrder IS NULL

--     OR
--     (
--         @StepOrder = 10
--         AND EXISTS
--         (
--             SELECT 1
--             FROM tmscrq.TMLeadReservation r
--             WHERE r.LeadId = l.Id
--               AND r.IsActive = 1
--               AND ISNULL(r.IsApproved,0) = 0
--         )
--     )

--     OR
--     (
--         @StepOrder <> 10
--         AND lp.StepOrder = @StepOrder
--     )
-- )

-- AND
-- (
--     @StartDate IS NULL
--     OR LTRIM(RTRIM(@StartDate)) = ''
--     OR l.CreatedAt >= CONVERT(date, @StartDate)
-- )

-- AND
-- (
--     @EndDate IS NULL
--     OR LTRIM(RTRIM(@EndDate)) = ''
--     OR l.CreatedAt < DATEADD(day, 1, CONVERT(date, @EndDate))
-- )

-- ORDER BY l.CreatedAt DESC;

------------------------++++++++++++++++++++++++-------------------
-- SET LANGUAGE Turkish;

-- SELECT
-- CASE 
--     WHEN EXISTS (
--         SELECT 1 
--         FROM tmscrq.TMLeadReservation r
--         WHERE r.LeadId = l.Id
--           AND r.IsActive = 1
--           AND r.IsApproved = 1
--     ) THEN N'Evet'

--     WHEN EXISTS (
--         SELECT 1 
--         FROM tmscrq.TMLeadReservation r
--         WHERE r.LeadId = l.Id
--           AND r.IsActive = 1
--           AND ISNULL(r.IsApproved,0) = 0
--     ) THEN N'Onay Bekliyor'

--     ELSE N'Hayır'
-- END AS RezerveDurumu,
--     l.Id AS LeadId,
--     l.IsReserved,
--     ISNULL(NULLIF(LTRIM(RTRIM(l.LeadCode)), ''), '-') AS LeadNumarasi,
--     CONVERT(varchar(10), l.CreatedAt, 103) AS TalepTarihi,

--     p.Id AS ProductId,
--     ISNULL(NULLIF(LTRIM(RTRIM(p.ProductName)), ''), '-') AS ProductName,
--     ISNULL(NULLIF(LTRIM(RTRIM(p.Bracelet)), ''), '-') AS Bilezik,
--     ISNULL(NULLIF(LTRIM(RTRIM(p.Brand)), ''), '-') AS Brand,
--     ISNULL(NULLIF(LTRIM(RTRIM(p.Dial)), ''), '-') AS Kadran,
--     ISNULL(NULLIF(LTRIM(RTRIM(p.ProductCode)), ''), '-') AS RefCode,
--     ISNULL(NULLIF(LTRIM(RTRIM(p.Referance)), ''), '-') AS Referans,

--     ISNULL(
--         NULLIF(
--             LTRIM(RTRIM(ISNULL(cu.Name, '') + ' ' + ISNULL(cu.LastName, '')))
--         , '')
--     , '-') AS Musteri,

--     ISNULL(NULLIF(LTRIM(RTRIM(cu.CityName)), ''), '-') AS Lokasyon,
--     ISNULL(NULLIF(LTRIM(RTRIM(cu.DistrictName)), ''), '-') AS Ilce,
--     ISNULL(NULLIF(LTRIM(RTRIM(cu.CountryName)), ''), '-') AS Ulke,
--     ISNULL(NULLIF(LTRIM(RTRIM(cu.Info)), ''), '-') AS MusteriInfo,

--     CASE
--         WHEN cu.IsShopping = 1 THEN N'Evet'
--         WHEN cu.IsShopping = 0 THEN N'Hayır'
--         ELSE '-'
--     END AS AlisverisiVarMi,

--     ISNULL(NULLIF(LTRIM(RTRIM(cu.Tel)), ''), '-') AS IrtibatNumarasi,
--     ISNULL(NULLIF(LTRIM(RTRIM(cu.Email)), ''), '-') AS EmailAdresi,

--     ISNULL(NULLIF(LTRIM(RTRIM(cr.ContactResourceName)), ''), '-') AS IletisimKaynagi,

--     ISNULL(NULLIF(LTRIM(RTRIM(p.CategoryName)), ''), '-') AS CategoryName,
--     '-' AS CategoryCode,

--     ISNULL(NULLIF(LTRIM(RTRIM(ls.Name)), ''), '-') AS LeadDurumu,
--     ISNULL(NULLIF(LTRIM(RTRIM(ns.Name)), ''), '-') AS SonrakiAdim,

--     ISNULL(NULLIF(LTRIM(RTRIM(lp.Name)), ''), '-') AS ProcessName,
--     ISNULL(NULLIF(LTRIM(RTRIM(lp.Code)), ''), '-') AS ProcessCode,
--     lp.StepOrder,
    
--     -- DÜZELTİLEN ALAN: SelectedStepOrder
--     CASE
--         WHEN EXISTS
--         (
--             SELECT 1
--             FROM tmscrq.TMLeadReservation r
--             WHERE r.LeadId = l.Id
--               AND r.IsActive = 1
--               AND ISNULL(r.IsApproved,0) = 0
--         )
--         THEN 10
--         ELSE lp.StepOrder
--     END AS SelectedStepOrder,

--     ISNULL(
--         CASE
--             WHEN l.EstimatedDate IS NOT NULL
--             THEN CAST(YEAR(l.EstimatedDate) AS VARCHAR(4)) + ' ' + DATENAME(MONTH, l.EstimatedDate)
--             ELSE NULL
--         END,
--         '-'
--     ) AS TerminTarihi,

--     ISNULL(
--         NULLIF(
--             LTRIM(RTRIM(ISNULL(sp.FirstName, '') + ' ' + ISNULL(sp.LastName, '')))
--         , '')
--     , '-') AS SatisDanismani,

--     ISNULL(NULLIF(LTRIM(RTRIM(st.StoreDesc)), ''), '-') AS StoreName

-- FROM tmscrq.TMLead l
-- LEFT JOIN tmscrq.TMLeadStatu ls
--     ON ls.Id = l.StatuId
-- LEFT JOIN tmscrq.TMCustomer cu
--     ON cu.Id = l.CustomerId
-- LEFT JOIN tmscrq.TMProduct p
--     ON p.Id = l.ProductId
-- LEFT JOIN tmscrq.TMContactResource cr
--     ON cr.Id = l.ContactResourceId
-- LEFT JOIN dbo.KUser sp
--     ON sp.Id = l.SalesPersonKUserId
-- LEFT JOIN tmscrq.TMStore st
--     ON st.Id = l.StoreId
-- LEFT JOIN tmscrq.TMLeadProcess lp
--     ON lp.Id = l.ProcessID
-- LEFT JOIN tmscrq.TMLeadNextStep ns
--     ON ns.Id = l.NextStepId

-- WHERE
-- (
--     EXISTS
--     (
--         SELECT 1
--         FROM dbo.KUserRole ur
--         INNER JOIN dbo.KRole r
--             ON r.Id = ur.KRole_Id
--         WHERE ur.KUser_Id = @UserId
--           AND ur.IsDeleted = 0
--           AND r.IsDeleted = 0
--           AND r.Name IN ('TimesYonetici', 'TimesUstYonetici')
--     )
--     OR
--     (
--         EXISTS
--         (
--             SELECT 1
--             FROM dbo.KUserRole ur
--             INNER JOIN dbo.KRole r
--                 ON r.Id = ur.KRole_Id
--             WHERE ur.KUser_Id = @UserId
--               AND ur.IsDeleted = 0
--               AND r.IsDeleted = 0
--               AND r.Name IN ('TimesMagazaMuduru', 'TimesSatisPersoneli')
--         )
--         AND EXISTS
--         (
--             SELECT 1
--             FROM tmscrq.TMUser tu
--             WHERE tu.KUserID = @UserId
--               AND tu.StoreId = l.StoreId
--         )
--     )
-- )

-- AND
-- (
--     @MusteriAdi IS NULL
--     OR LTRIM(RTRIM(@MusteriAdi)) = ''
--     OR UPPER(LTRIM(RTRIM(ISNULL(cu.Name,'') + ' ' + ISNULL(cu.LastName,''))))
--        LIKE '%' + UPPER(LTRIM(RTRIM(@MusteriAdi))) + '%'
-- )

-- AND
-- (
--     @ProductName IS NULL
--     OR LTRIM(RTRIM(@ProductName)) = ''
--     OR
--     (
--         CHARINDEX(',', @ProductName) > 0
--         AND ISNULL(LTRIM(RTRIM(p.ProductName)), '') IN
--         (
--             SELECT LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', '')))
--             FROM STRING_SPLIT(CAST(@ProductName AS NVARCHAR(MAX)), ',')
--             WHERE LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', ''))) <> ''
--         )
--     )
--     OR
--     (
--         CHARINDEX(',', @ProductName) = 0
--         AND UPPER(ISNULL(LTRIM(RTRIM(p.ProductName)), ''))
--             LIKE '%' + UPPER(LTRIM(RTRIM(@ProductName))) + '%'
--     )
-- )

-- AND
-- (
--     @LeadCode IS NULL
--     OR LTRIM(RTRIM(@LeadCode)) = ''
--     OR UPPER(ISNULL(LTRIM(RTRIM(l.LeadCode)), '')) LIKE '%' + UPPER(LTRIM(RTRIM(@LeadCode))) + '%'
-- )

-- AND
-- (
--     @Tel IS NULL
--     OR LTRIM(RTRIM(@Tel)) = ''
--     OR UPPER(ISNULL(LTRIM(RTRIM(cu.Tel)), '')) LIKE '%' + UPPER(LTRIM(RTRIM(@Tel))) + '%'
-- )

-- AND
-- (
--     @CategoryName IS NULL
--     OR LTRIM(RTRIM(@CategoryName)) = ''
--     OR UPPER(ISNULL(LTRIM(RTRIM(p.CategoryName)), '')) IN
--     (
--         SELECT UPPER(LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value,'""',''),'[',''),']',''))))
--         FROM STRING_SPLIT(CAST(@CategoryName AS NVARCHAR(MAX)), ',')
--         WHERE LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value,'""',''),'[',''),']',''))) <> ''
--     )
-- )

-- AND
-- (
--     @StoreIds IS NULL
--     OR LTRIM(RTRIM(@StoreIds)) = ''
--     OR EXISTS
--     (
--         SELECT 1
--         FROM STRING_SPLIT(CAST(@StoreIds AS NVARCHAR(MAX)), ',') s
--         WHERE l.StoreId = TRY_CONVERT
--         (
--             uniqueidentifier,
--             LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(s.value, '""', ''), '[', ''), ']', '')))
--         )
--     )
-- )

-- AND
-- (
--     @SatisDanismaniIds IS NULL
--     OR LTRIM(RTRIM(@SatisDanismaniIds)) = ''
--     OR EXISTS
--     (
--         SELECT 1
--         FROM STRING_SPLIT(CAST(@SatisDanismaniIds AS NVARCHAR(MAX)), ',') s
--         WHERE l.SalesPersonKUserId = TRY_CONVERT
--         (
--             uniqueidentifier,
--             LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(s.value, '""', ''), '[', ''), ']', '')))
--         )
--     )
-- )

-- AND
-- (
--     @ProcessCode IS NULL
--     OR LTRIM(RTRIM(@ProcessCode)) = ''
--     OR UPPER(ISNULL(LTRIM(RTRIM(lp.Code)), '')) IN
--     (
--         SELECT UPPER(LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', ''))))
--         FROM STRING_SPLIT(CAST(@ProcessCode AS NVARCHAR(MAX)), ',')
--         WHERE LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', ''))) <> ''
--     )
-- )

-- -- DÜZELTİLEN ALAN: @StepOrder Filtresi (tek blok)
-- AND
-- (
--     @StepOrder IS NULL

--     OR

--     (
--         @StepOrder = 10
--         AND EXISTS
--         (
--             SELECT 1
--             FROM tmscrq.TMLeadReservation r
--             WHERE r.LeadId = l.Id
--               AND r.IsActive = 1
--               AND ISNULL(r.IsApproved,0) = 0
--         )
--     )

--     OR

--     (
--         @StepOrder <> 10
--         AND lp.StepOrder = @StepOrder
--     )
-- )

-- AND
-- (
--     @StartDate IS NULL
--     OR LTRIM(RTRIM(@StartDate)) = ''
--     OR l.CreatedAt >= CONVERT(date, @StartDate)
-- )

-- AND
-- (
--     @EndDate IS NULL
--     OR LTRIM(RTRIM(@EndDate)) = ''
--     OR l.CreatedAt < DATEADD(day, 1, CONVERT(date, @EndDate))
-- )

-- ORDER BY l.CreatedAt DESC;



SET LANGUAGE Turkish;

SELECT
CASE 
    WHEN EXISTS (
        SELECT 1 
        FROM tmscrq.TMLeadReservation r
        WHERE r.LeadId = l.Id
          AND r.IsActive = 1
          AND r.IsApproved = 1
    ) THEN N'Evet'

    WHEN EXISTS (
        SELECT 1 
        FROM tmscrq.TMLeadReservation r
        WHERE r.LeadId = l.Id
          AND r.IsActive = 1
          AND ISNULL(r.IsApproved,0) = 0
    ) THEN N'Onay Bekliyor'

    ELSE N'Hayır'
END AS RezerveDurumu,
    l.Id AS LeadId,
    l.IsReserved,
    ISNULL(NULLIF(LTRIM(RTRIM(l.LeadCode)), ''), '-') AS LeadNumarasi,
     FORMAT(l.CreatedAt, 'dd MMMM yyyy', 'tr-TR') AS TalepTarihi,

    p.Id AS ProductId,
    ISNULL(NULLIF(LTRIM(RTRIM(p.ProductName)), ''), '-') AS ProductName,
    ISNULL(NULLIF(LTRIM(RTRIM(p.Bracelet)), ''), '-') AS Bilezik,
    ISNULL(NULLIF(LTRIM(RTRIM(p.Brand)), ''), '-') AS Brand,
    ISNULL(NULLIF(LTRIM(RTRIM(p.Dial)), ''), '-') AS Kadran,
    ISNULL(NULLIF(LTRIM(RTRIM(p.ProductCode)), ''), '-') AS RefCode,
    ISNULL(NULLIF(LTRIM(RTRIM(p.Referance)), ''), '-') AS Referans,

    ISNULL(
        NULLIF(
            LTRIM(RTRIM(ISNULL(cu.Name, '') + ' ' + ISNULL(cu.LastName, '')))
        , '')
    , '-') AS Musteri,

    ISNULL(NULLIF(LTRIM(RTRIM(cu.CityName)), ''), '-') AS Lokasyon,
    ISNULL(NULLIF(LTRIM(RTRIM(cu.DistrictName)), ''), '-') AS Ilce,
    ISNULL(NULLIF(LTRIM(RTRIM(cu.CountryName)), ''), '-') AS Ulke,
    ISNULL(NULLIF(LTRIM(RTRIM(cu.Info)), ''), '-') AS MusteriInfo,

    CASE
        WHEN cu.IsShopping = 1 THEN N'Evet'
        WHEN cu.IsShopping = 0 THEN N'Hayır'
        ELSE '-'
    END AS AlisverisiVarMi,

    ISNULL(NULLIF(LTRIM(RTRIM(cu.Tel)), ''), '-') AS IrtibatNumarasi,
    ISNULL(NULLIF(LTRIM(RTRIM(cu.Email)), ''), '-') AS EmailAdresi,

    ISNULL(NULLIF(LTRIM(RTRIM(cr.ContactResourceName)), ''), '-') AS IletisimKaynagi,

    ISNULL(NULLIF(LTRIM(RTRIM(p.CategoryName)), ''), '-') AS CategoryName,
    '-' AS CategoryCode,

    ISNULL(NULLIF(LTRIM(RTRIM(ls.Name)), ''), '-') AS LeadDurumu,
    ISNULL(NULLIF(LTRIM(RTRIM(ns.Name)), ''), '-') AS SonrakiAdim,

    ISNULL(NULLIF(LTRIM(RTRIM(lp.Name)), ''), '-') AS ProcessName,
    ISNULL(NULLIF(LTRIM(RTRIM(lp.Code)), ''), '-') AS ProcessCode,
    lp.StepOrder,
    
    -- DÜZELTİLEN ALAN: SelectedStepOrder
    CASE
        WHEN EXISTS
        (
            SELECT 1
            FROM tmscrq.TMLeadReservation r
            WHERE r.LeadId = l.Id
              AND r.IsActive = 1
              AND ISNULL(r.IsApproved,0) = 0
        )
        THEN 10
        ELSE lp.StepOrder
    END AS SelectedStepOrder,

    ISNULL(
        CASE
            WHEN l.EstimatedDate IS NOT NULL
            THEN CAST(YEAR(l.EstimatedDate) AS VARCHAR(4)) + ' ' + DATENAME(MONTH, l.EstimatedDate)
            ELSE NULL
        END,
        '-'
    ) AS TerminTarihi,

    ISNULL(
        NULLIF(
            LTRIM(RTRIM(ISNULL(sp.FirstName, '') + ' ' + ISNULL(sp.LastName, '')))
        , '')
    , '-') AS SatisDanismani,

    ISNULL(NULLIF(LTRIM(RTRIM(st.StoreDesc)), ''), '-') AS StoreName

FROM tmscrq.TMLead l
LEFT JOIN tmscrq.TMLeadStatu ls
    ON ls.Id = l.StatuId
LEFT JOIN tmscrq.TMCustomer cu
    ON cu.Id = l.CustomerId
LEFT JOIN tmscrq.TMProduct p
    ON p.Id = l.ProductId
LEFT JOIN tmscrq.TMContactResource cr
    ON cr.Id = l.ContactResourceId
LEFT JOIN dbo.KUser sp
    ON sp.Id = l.SalesPersonKUserId
LEFT JOIN tmscrq.TMStore st
    ON st.Id = l.StoreId
LEFT JOIN tmscrq.TMLeadProcess lp
    ON lp.Id = l.ProcessID
LEFT JOIN tmscrq.TMLeadNextStep ns
    ON ns.Id = l.NextStepId

WHERE
(
    EXISTS
    (
        SELECT 1
        FROM dbo.KUserRole ur
        INNER JOIN dbo.KRole r
            ON r.Id = ur.KRole_Id
        WHERE ur.KUser_Id = @UserId
          AND ur.IsDeleted = 0
          AND r.IsDeleted = 0
          AND r.Name IN ('TimesYonetici', 'TimesUstYonetici')
    )
    OR
    (
        EXISTS
        (
            SELECT 1
            FROM dbo.KUserRole ur
            INNER JOIN dbo.KRole r
                ON r.Id = ur.KRole_Id
            WHERE ur.KUser_Id = @UserId
              AND ur.IsDeleted = 0
              AND r.IsDeleted = 0
              AND r.Name IN ('TimesMagazaMuduru', 'TimesSatisPersoneli')
        )
        AND EXISTS
        (
            SELECT 1
            FROM tmscrq.TMUser tu
            WHERE tu.KUserID = @UserId
              AND tu.StoreId = l.StoreId
        )
    )
)

AND
(
    ISNULL(@MusteriAdi, '') = ''
    OR UPPER(ISNULL(cu.Name, '')) LIKE '%' + UPPER(LTRIM(RTRIM(@MusteriAdi))) + '%'
    OR UPPER(ISNULL(cu.LastName, '')) LIKE '%' + UPPER(LTRIM(RTRIM(@MusteriAdi))) + '%'
    OR UPPER(
        ISNULL(cu.Name, '') + ' ' + ISNULL(cu.LastName, '')
    ) LIKE '%' + UPPER(LTRIM(RTRIM(@MusteriAdi))) + '%'
)

AND
(
    @ProductName IS NULL
    OR LTRIM(RTRIM(@ProductName)) = ''
    OR
    (
        CHARINDEX(',', @ProductName) > 0
        AND ISNULL(LTRIM(RTRIM(p.ProductName)), '') IN
        (
            SELECT LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', '')))
            FROM STRING_SPLIT(CAST(@ProductName AS NVARCHAR(MAX)), ',')
            WHERE LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', ''))) <> ''
        )
    )
    OR
    (
        CHARINDEX(',', @ProductName) = 0
        AND UPPER(ISNULL(LTRIM(RTRIM(p.ProductName)), ''))
            LIKE '%' + UPPER(LTRIM(RTRIM(@ProductName))) + '%'
    )
)

AND
(
    ISNULL(@LeadCode, '') = ''
    OR UPPER(ISNULL(l.LeadCode, ''))
        LIKE '%' + UPPER(LTRIM(RTRIM(@LeadCode))) + '%'
    OR REPLACE(
        REPLACE(
            REPLACE(
                UPPER(ISNULL(l.LeadCode, '')),
                '-', ''
            ),
            ' ', ''
        ),
        '/', ''
    )
    LIKE '%' +
    REPLACE(
        REPLACE(
            REPLACE(
                UPPER(LTRIM(RTRIM(@LeadCode))),
                '-', ''
            ),
            ' ', ''
        ),
        '/', ''
    )
    + '%'
)

AND
(
    @Tel IS NULL
    OR LTRIM(RTRIM(@Tel)) = ''
    OR UPPER(ISNULL(LTRIM(RTRIM(cu.Tel)), '')) LIKE '%' + UPPER(LTRIM(RTRIM(@Tel))) + '%'
)

AND
(
    @CategoryName IS NULL
    OR LTRIM(RTRIM(@CategoryName)) = ''
    OR UPPER(ISNULL(LTRIM(RTRIM(p.CategoryName)), '')) IN
    (
        SELECT UPPER(LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value,'""',''),'[',''),']',''))))
        FROM STRING_SPLIT(CAST(@CategoryName AS NVARCHAR(MAX)), ',')
        WHERE LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value,'""',''),'[',''),']',''))) <> ''
    )
)

AND
(
    @StoreIds IS NULL
    OR LTRIM(RTRIM(@StoreIds)) = ''
    OR EXISTS
    (
        SELECT 1
        FROM STRING_SPLIT(CAST(@StoreIds AS NVARCHAR(MAX)), ',') s
        WHERE l.StoreId = TRY_CONVERT
        (
            uniqueidentifier,
            LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(s.value, '""', ''), '[', ''), ']', '')))
        )
    )
)

AND
(
    @SatisDanismaniIds IS NULL
    OR LTRIM(RTRIM(@SatisDanismaniIds)) = ''
    OR EXISTS
    (
        SELECT 1
        FROM STRING_SPLIT(CAST(@SatisDanismaniIds AS NVARCHAR(MAX)), ',') s
        WHERE l.SalesPersonKUserId = TRY_CONVERT
        (
            uniqueidentifier,
            LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(s.value, '""', ''), '[', ''), ']', '')))
        )
    )
)

AND
(
    ISNULL(@ProcessCode, '') = ''
    OR EXISTS
    (
        SELECT 1
        FROM STRING_SPLIT(
            CONVERT(NVARCHAR(MAX), @ProcessCode),
            ','
        ) AS s
        WHERE
            UPPER(LTRIM(RTRIM(s.value))) =
            UPPER(LTRIM(RTRIM(ISNULL(lp.Code, ''))))
    )
)

-- DÜZELTİLEN ALAN: @StepOrder Filtresi (0 verilince tümü gelsin)
AND
(
    @StepOrder IS NULL
    OR @StepOrder = 0  -- 👈 YENİ EKLENDI: 0 verilince tüm kayıtlar gelir
    OR
    (
        @StepOrder = 10
        AND EXISTS
        (
            SELECT 1
            FROM tmscrq.TMLeadReservation r
            WHERE r.LeadId = l.Id
              AND r.IsActive = 1
              AND ISNULL(r.IsApproved,0) = 0
        )
    )
    OR
    (
        @StepOrder <> 10
        AND lp.StepOrder = @StepOrder
    )
)

AND
(
    @StartDate IS NULL
    OR LTRIM(RTRIM(@StartDate)) = ''
    OR l.CreatedAt >= CONVERT(date, @StartDate)
)

AND
(
    @EndDate IS NULL
    OR LTRIM(RTRIM(@EndDate)) = ''
    OR l.CreatedAt < DATEADD(day, 1, CONVERT(date, @EndDate))
)

ORDER BY l.CreatedAt DESC;", new string[] { "RezerveDurumu", "LeadId", "IsReserved", "LeadNumarasi", "TalepTarihi", "ProductId", "ProductName", "Bilezik", "Brand", "Kadran", "RefCode", "Referans", "Musteri", "Lokasyon", "Ilce", "Ulke", "MusteriInfo", "AlisverisiVarMi", "IrtibatNumarasi", "EmailAdresi", "IletisimKaynagi", "CategoryName", "CategoryCode", "LeadDurumu", "SonrakiAdim", "ProcessName", "ProcessCode", "StepOrder", "SelectedStepOrder", "TerminTarihi", "SatisDanismani", "StoreName" }, prms_TM_GetLeads_0.ToArray());
            ;

            var prms_TMLeadProcessCountSummary_1 = new List<kSqlParameter>();
            prms_TMLeadProcessCountSummary_1.Add(new kSqlParameter() { Name = "UserId", Value = Kuika.Common.KContext.CurrentUser?.Id });
            prms_TMLeadProcessCountSummary_1.Add(new kSqlParameter() { Name = "MusteriAdi", Value = request.MusteriAdi_1 });
            prms_TMLeadProcessCountSummary_1.Add(new kSqlParameter() { Name = "ProductName", Value = request.ProductName_1 });
            prms_TMLeadProcessCountSummary_1.Add(new kSqlParameter() { Name = "LeadCode", Value = request.LeadCode_1 });
            prms_TMLeadProcessCountSummary_1.Add(new kSqlParameter() { Name = "Tel", Value = request.Tel_1 });
            prms_TMLeadProcessCountSummary_1.Add(new kSqlParameter() { Name = "CategoryName", Value = request.CategoryName_1 });
            prms_TMLeadProcessCountSummary_1.Add(new kSqlParameter() { Name = "StoreIds", Value = request.StoreIds_1 });
            prms_TMLeadProcessCountSummary_1.Add(new kSqlParameter() { Name = "SatisDanismaniIds", Value = request.SatisDanismaniIds_1 });
            prms_TMLeadProcessCountSummary_1.Add(new kSqlParameter() { Name = "ProcessCode", Value = request.ProcessCode_1 });
            prms_TMLeadProcessCountSummary_1.Add(new kSqlParameter() { Name = "StartDate", Value = request.StartDate_1 });
            prms_TMLeadProcessCountSummary_1.Add(new kSqlParameter() { Name = "EndDate", Value = request.EndDate_1 });
            using var auditTMLeadProcessCountSummary_1 = ActionAuditScope.Begin("e4c3c376-79bf-840e-2ba0-6a62d568032d", "TMLeadProcessCountSummary", applicationName: "wbTimesCRM", screenOrEndpointName: "LeadList");
            result.TMLeadProcessCountSummary = KPersister.Fetch(KContext.GetConnectionString(), @"-- SELECT
--     COUNT(*) AS ToplamTalepSayisi,

--     SUM(CASE WHEN lp.Code = 'PENDING' THEN 1 ELSE 0 END) AS OnayBekleyenSayisi,
--     SUM(CASE WHEN lp.Code = 'TERMIN_PENDING' THEN 1 ELSE 0 END) AS TerminBekleyenSayisi,
--     SUM(CASE WHEN lp.Code = 'APPROVED' THEN 1 ELSE 0 END) AS OnaylananSayisi,
--     SUM(CASE WHEN lp.Code = 'REJECTED' THEN 1 ELSE 0 END) AS ReddedilenSayisi,
--     SUM(CASE WHEN lp.Code = 'DELIVERY_PENDING' THEN 1 ELSE 0 END) AS TeslimEdilecekSayisi,
--     SUM(CASE WHEN lp.Code = 'DELIVERED' THEN 1 ELSE 0 END) AS TeslimEdildiSayisi

-- FROM tmscrq.TMLead l
-- LEFT JOIN tmscrq.TMCustomer cu
--     ON cu.Id = l.CustomerId
-- LEFT JOIN tmscrq.TMProduct p
--     ON p.Id = l.ProductId
-- LEFT JOIN dbo.KUser sp
--     ON sp.Id = l.SalesPersonKUserId
-- LEFT JOIN tmscrq.TMLeadProcess lp
--     ON lp.Id = l.ProcessID

-- WHERE
-- (
--     EXISTS
--     (
--         SELECT 1
--         FROM dbo.KUserRole ur
--         INNER JOIN dbo.KRole r
--             ON r.Id = ur.KRole_Id
--         WHERE ur.KUser_Id = @UserId
--           AND ur.IsDeleted = 0
--           AND r.IsDeleted = 0
--           AND r.Name IN ('TimesYonetici', 'TimesUstYonetici')
--     )
--     OR
--     (
--         EXISTS
--         (
--             SELECT 1
--             FROM dbo.KUserRole ur
--             INNER JOIN dbo.KRole r
--                 ON r.Id = ur.KRole_Id
--             WHERE ur.KUser_Id = @UserId
--               AND ur.IsDeleted = 0
--               AND r.IsDeleted = 0
--               AND r.Name IN ('TimesMagazaMuduru', 'TimesSatisPersoneli')
--         )
--         AND EXISTS
--         (
--             SELECT 1
--             FROM tmscrq.TMUser tu
--             WHERE tu.KUserID = @UserId
--               AND tu.StoreId = l.StoreId
--         )
--     )
-- )

-- AND
-- (
--     @MusteriAdi IS NULL
--     OR LTRIM(RTRIM(@MusteriAdi)) = ''
--     OR UPPER(LTRIM(RTRIM(ISNULL(cu.Name, '') + ' ' + ISNULL(cu.LastName, ''))))
--        LIKE '%' + UPPER(LTRIM(RTRIM(@MusteriAdi))) + '%'
-- )

-- AND
-- (
--     @ProductName IS NULL
--     OR LTRIM(RTRIM(@ProductName)) = ''
--     OR
--     (
--         CHARINDEX(',', @ProductName) > 0
--         AND ISNULL(LTRIM(RTRIM(p.ProductName)), '') IN
--         (
--             SELECT LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', '')))
--             FROM STRING_SPLIT(CAST(@ProductName AS NVARCHAR(MAX)), ',')
--             WHERE LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', ''))) <> ''
--         )
--     )
--     OR
--     (
--         CHARINDEX(',', @ProductName) = 0
--         AND UPPER(ISNULL(LTRIM(RTRIM(p.ProductName)), ''))
--             LIKE '%' + UPPER(LTRIM(RTRIM(@ProductName))) + '%'
--     )
-- )

-- AND
-- (
--     @LeadCode IS NULL
--     OR LTRIM(RTRIM(@LeadCode)) = ''
--     OR UPPER(ISNULL(LTRIM(RTRIM(l.LeadCode)), '')) LIKE '%' + UPPER(LTRIM(RTRIM(@LeadCode))) + '%'
-- )

-- AND
-- (
--     @Tel IS NULL
--     OR LTRIM(RTRIM(@Tel)) = ''
--     OR UPPER(ISNULL(LTRIM(RTRIM(cu.Tel)), '')) LIKE '%' + UPPER(LTRIM(RTRIM(@Tel))) + '%'
-- )

-- AND
-- (
--     @CategoryName IS NULL
--     OR LTRIM(RTRIM(@CategoryName)) = ''
--     OR
--     (
--         EXISTS
--         (
--             SELECT 1
--             FROM STRING_SPLIT(CAST(@CategoryName AS NVARCHAR(MAX)), ',') c
--             WHERE UPPER(LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(c.value, '""', ''), '[', ''), ']', '')))) = 'DEFAULT'
--         )
--         AND (p.CategoryName IS NULL OR LTRIM(RTRIM(p.CategoryName)) = '')
--     )
--     OR UPPER(ISNULL(LTRIM(RTRIM(p.CategoryName)), '')) IN
--     (
--         SELECT UPPER(LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', ''))))
--         FROM STRING_SPLIT(CAST(@CategoryName AS NVARCHAR(MAX)), ',')
--         WHERE LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', ''))) <> ''
--           AND UPPER(LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', '')))) <> 'DEFAULT'
--     )
-- )

-- AND
-- (
--     @StoreIds IS NULL
--     OR LTRIM(RTRIM(@StoreIds)) = ''
--     OR EXISTS
--     (
--         SELECT 1
--         FROM STRING_SPLIT(CAST(@StoreIds AS NVARCHAR(MAX)), ',') s
--         WHERE l.StoreId = TRY_CONVERT
--         (
--             uniqueidentifier,
--             LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(s.value, '""', ''), '[', ''), ']', '')))
--         )
--     )
-- )

-- AND
-- (
--     @SatisDanismaniIds IS NULL
--     OR LTRIM(RTRIM(@SatisDanismaniIds)) = ''
--     OR EXISTS
--     (
--         SELECT 1
--         FROM STRING_SPLIT(CAST(@SatisDanismaniIds AS NVARCHAR(MAX)), ',') s
--         WHERE l.SalesPersonKUserId = TRY_CONVERT
--         (
--             uniqueidentifier,
--             LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(s.value, '""', ''), '[', ''), ']', '')))
--         )
--     )
-- )

-- AND
-- (
--     @ProcessCode IS NULL
--     OR LTRIM(RTRIM(@ProcessCode)) = ''
--     OR UPPER(ISNULL(LTRIM(RTRIM(lp.Code)), '')) IN
--     (
--         SELECT UPPER(LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', ''))))
--         FROM STRING_SPLIT(CAST(@ProcessCode AS NVARCHAR(MAX)), ',')
--         WHERE LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', ''))) <> ''
--     )
-- )

-- AND
-- (
--     @StartDate IS NULL
--     OR LTRIM(RTRIM(@StartDate)) = ''
--     OR l.CreatedAt >= CONVERT(date, @StartDate)
-- )

-- AND
-- (
--     @EndDate IS NULL
--     OR LTRIM(RTRIM(@EndDate)) = ''
--     OR l.CreatedAt < DATEADD(day, 1, CONVERT(date, @EndDate))
-- );

-------------------------------------------------------------

DECLARE @KUserId UNIQUEIDENTIFIER = @UserId;

WITH UserRoles AS (
    SELECT r.Name
    FROM dbo.KUserRole ur
    INNER JOIN dbo.KRole r 
        ON r.Id = ur.KRole_Id
    WHERE ur.KUser_Id = @KUserId
      AND ur.IsDeleted = 0
      AND r.IsDeleted = 0
),
IsAdmin AS (
    SELECT CASE 
        WHEN EXISTS (
            SELECT 1 
            FROM UserRoles 
            WHERE Name = 'TimesUstYonetici'
        ) THEN 1 ELSE 0 END AS IsAdmin
)

SELECT
    COUNT(*) AS ToplamTalepSayisi,

    SUM(CASE WHEN lp.Code = 'PENDING' THEN 1 ELSE 0 END) AS OnayBekleyenSayisi,
    SUM(CASE WHEN lp.Code = 'TERMIN_PENDING' THEN 1 ELSE 0 END) AS TerminBekleyenSayisi,
    SUM(CASE WHEN lp.Code = 'APPROVED' THEN 1 ELSE 0 END) AS OnaylananSayisi,
    SUM(CASE WHEN lp.Code = 'REJECTED' THEN 1 ELSE 0 END) AS ReddedilenSayisi,
    SUM(CASE WHEN lp.Code = 'DELIVERY_PENDING' THEN 1 ELSE 0 END) AS TeslimEdilecekSayisi,
    SUM(CASE WHEN lp.Code = 'DELIVERED' THEN 1 ELSE 0 END) AS TeslimEdildiSayisi

FROM tmscrq.TMLead l
LEFT JOIN tmscrq.TMCustomer cu
    ON cu.Id = l.CustomerId
LEFT JOIN tmscrq.TMProduct p
    ON p.Id = l.ProductId
LEFT JOIN dbo.KUser sp
    ON sp.Id = l.SalesPersonKUserId
LEFT JOIN tmscrq.TMLeadProcess lp
    ON lp.Id = l.ProcessID

CROSS JOIN IsAdmin a

WHERE
(
    -- admin → full
    a.IsAdmin = 1

    -- diğerleri → sadece kendi mağazaları
    OR EXISTS
    (
        SELECT 1
        FROM tmscrq.TMUser tu
        WHERE tu.KUserID = @KUserId
          AND tu.StoreId = l.StoreId
    )
)

-- 🔽 AŞAĞISI SENİN ORİJİNAL FİLTRELER (HİÇ DOKUNMADIM)

AND
(
    @MusteriAdi IS NULL
    OR LTRIM(RTRIM(@MusteriAdi)) = ''
    OR UPPER(LTRIM(RTRIM(ISNULL(cu.Name, '') + ' ' + ISNULL(cu.LastName, ''))))
       LIKE '%' + UPPER(LTRIM(RTRIM(@MusteriAdi))) + '%'
)

AND
(
    @ProductName IS NULL
    OR LTRIM(RTRIM(@ProductName)) = ''
    OR
    (
        CHARINDEX(',', @ProductName) > 0
        AND ISNULL(LTRIM(RTRIM(p.ProductName)), '') IN
        (
            SELECT LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', '')))
            FROM STRING_SPLIT(CAST(@ProductName AS NVARCHAR(MAX)), ',')
        )
    )
    OR
    (
        CHARINDEX(',', @ProductName) = 0
        AND UPPER(ISNULL(LTRIM(RTRIM(p.ProductName)), ''))
            LIKE '%' + UPPER(LTRIM(RTRIM(@ProductName))) + '%'
    )
)

AND
(
    @LeadCode IS NULL
    OR LTRIM(RTRIM(@LeadCode)) = ''
    OR UPPER(ISNULL(LTRIM(RTRIM(l.LeadCode)), '')) LIKE '%' + UPPER(LTRIM(RTRIM(@LeadCode))) + '%'
)

AND
(
    @Tel IS NULL
    OR LTRIM(RTRIM(@Tel)) = ''
    OR UPPER(ISNULL(LTRIM(RTRIM(cu.Tel)), '')) LIKE '%' + UPPER(LTRIM(RTRIM(@Tel))) + '%'
)

AND
(
    @CategoryName IS NULL
    OR LTRIM(RTRIM(@CategoryName)) = ''
    OR
    (
        EXISTS
        (
            SELECT 1
            FROM STRING_SPLIT(CAST(@CategoryName AS NVARCHAR(MAX)), ',') c
            WHERE UPPER(LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(c.value, '""', ''), '[', ''), ']', '')))) = 'DEFAULT'
        )
        AND (p.CategoryName IS NULL OR LTRIM(RTRIM(p.CategoryName)) = '')
    )
    OR UPPER(ISNULL(LTRIM(RTRIM(p.CategoryName)), '')) IN
    (
        SELECT UPPER(LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', ''))))
        FROM STRING_SPLIT(CAST(@CategoryName AS NVARCHAR(MAX)), ',')
    )
)

AND
(
    @StoreIds IS NULL
    OR LTRIM(RTRIM(@StoreIds)) = ''
    OR EXISTS
    (
        SELECT 1
        FROM STRING_SPLIT(CAST(@StoreIds AS NVARCHAR(MAX)), ',') s
        WHERE l.StoreId = TRY_CONVERT
        (
            uniqueidentifier,
            LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(s.value, '""', ''), '[', ''), ']', '')))
        )
    )
)

AND
(
    @SatisDanismaniIds IS NULL
    OR LTRIM(RTRIM(@SatisDanismaniIds)) = ''
    OR EXISTS
    (
        SELECT 1
        FROM STRING_SPLIT(CAST(@SatisDanismaniIds AS NVARCHAR(MAX)), ',') s
        WHERE l.SalesPersonKUserId = TRY_CONVERT
        (
            uniqueidentifier,
            LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(s.value, '""', ''), '[', ''), ']', '')))
        )
    )
)

AND
(
    @ProcessCode IS NULL
    OR LTRIM(RTRIM(@ProcessCode)) = ''
    OR UPPER(ISNULL(LTRIM(RTRIM(lp.Code)), '')) IN
    (
        SELECT UPPER(LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', ''))))
        FROM STRING_SPLIT(CAST(@ProcessCode AS NVARCHAR(MAX)), ',')
    )
)

AND
(
    @StartDate IS NULL
    OR LTRIM(RTRIM(@StartDate)) = ''
    OR l.CreatedAt >= CONVERT(date, @StartDate)
)

AND
(
    @EndDate IS NULL
    OR LTRIM(RTRIM(@EndDate)) = ''
    OR l.CreatedAt < DATEADD(day, 1, CONVERT(date, @EndDate))
);", new string[] { "ToplamTalepSayisi", "OnayBekleyenSayisi", "TerminBekleyenSayisi", "OnaylananSayisi", "ReddedilenSayisi", "TeslimEdilecekSayisi", "TeslimEdildiSayisi" }, prms_TMLeadProcessCountSummary_1.ToArray());
            ;


            return Ok(result);
        }


        [HttpPost, Route("LeadListComponent_314150_onChange")]
        public IActionResult LeadListComponent_314150_onChange(LeadListComponent_314150_onChange_Request request)
        {

            KProviderManager.Authorization.IsAuthorizedForRoles(appId, appName, screenId, screenName, new List<string> { $"70de6cfc-6087-6059-59b4-0b5a8527af6b", "4da1f213-c8e4-0b50-5c84-02fd13f1a622", "c4e882ef-977d-f613-7694-230ac83919d2", "b4bfd39c-ac02-f442-c899-7a2374a45b47", "cdb536b0-6297-155f-d446-8453d8a60304", "TimesYonetici", "TimesUstYonetici", "TimesSatisPersoneli", "TimesMagazaMuduru", "TimesAdmin" });

            var result = new LeadListComponent_314150_onChange_Response();

            var prms_TM_GetLeads_0 = new List<kSqlParameter>();
            prms_TM_GetLeads_0.Add(new kSqlParameter() { Name = "StepOrder", Value = request.StepOrder_0 });
            prms_TM_GetLeads_0.Add(new kSqlParameter() { Name = "UserId", Value = Kuika.Common.KContext.CurrentUser?.Id });
            prms_TM_GetLeads_0.Add(new kSqlParameter() { Name = "MusteriAdi", Value = request.MusteriAdi_0 });
            prms_TM_GetLeads_0.Add(new kSqlParameter() { Name = "ProductName", Value = request.ProductName_0 });
            prms_TM_GetLeads_0.Add(new kSqlParameter() { Name = "LeadCode", Value = request.LeadCode_0 });
            prms_TM_GetLeads_0.Add(new kSqlParameter() { Name = "Tel", Value = request.Tel_0 });
            prms_TM_GetLeads_0.Add(new kSqlParameter() { Name = "CategoryName", Value = request.CategoryName_0 });
            prms_TM_GetLeads_0.Add(new kSqlParameter() { Name = "StoreIds", Value = request.StoreIds_0 });
            prms_TM_GetLeads_0.Add(new kSqlParameter() { Name = "SatisDanismaniIds", Value = request.SatisDanismaniIds_0 });
            prms_TM_GetLeads_0.Add(new kSqlParameter() { Name = "ProcessCode", Value = request.ProcessCode_0 });
            prms_TM_GetLeads_0.Add(new kSqlParameter() { Name = "StartDate", Value = request.StartDate_0 });
            prms_TM_GetLeads_0.Add(new kSqlParameter() { Name = "EndDate", Value = request.EndDate_0 });
            using var auditTM_GetLeads_0 = ActionAuditScope.Begin("bc1e74cf-1556-c65f-2110-67773bbfb0a8", "TM_GetLeads", applicationName: "wbTimesCRM", screenOrEndpointName: "LeadList");
            result.TM_GetLeads = KPersister.Fetch(KContext.GetConnectionString(), @"-- SET LANGUAGE Turkish;

-- SELECT
-- CASE 
--     WHEN EXISTS (
--         SELECT 1 
--         FROM tmscrq.TMLeadReservation r
--         WHERE r.LeadId = l.Id
--           AND r.IsActive = 1
--           AND r.IsApproved = 1
--     ) THEN N'Evet'

--     WHEN EXISTS (
--         SELECT 1 
--         FROM tmscrq.TMLeadReservation r
--         WHERE r.LeadId = l.Id
--           AND r.IsActive = 1
--           AND ISNULL(r.IsApproved,0) = 0
--     ) THEN N'Onay Bekliyor'

--     ELSE N'Hayır'
-- END AS RezerveDurumu,
--     l.Id AS LeadId,
--     l.IsReserved,
--     ISNULL(NULLIF(LTRIM(RTRIM(l.LeadCode)), ''), '-') AS LeadNumarasi,
--     CONVERT(varchar(10), l.CreatedAt, 103) AS TalepTarihi,

--     p.Id AS ProductId,
--     ISNULL(NULLIF(LTRIM(RTRIM(p.ProductName)), ''), '-') AS ProductName,
--     ISNULL(NULLIF(LTRIM(RTRIM(p.Bracelet)), ''), '-') AS Bilezik,
--     ISNULL(NULLIF(LTRIM(RTRIM(p.Brand)), ''), '-') AS Brand,
--     ISNULL(NULLIF(LTRIM(RTRIM(p.Dial)), ''), '-') AS Kadran,
--     ISNULL(NULLIF(LTRIM(RTRIM(p.ProductCode)), ''), '-') AS RefCode,
--     ISNULL(NULLIF(LTRIM(RTRIM(p.Referance)), ''), '-') AS Referans,

--     ISNULL(
--         NULLIF(
--             LTRIM(RTRIM(ISNULL(cu.Name, '') + ' ' + ISNULL(cu.LastName, '')))
--         , '')
--     , '-') AS Musteri,

--     ISNULL(NULLIF(LTRIM(RTRIM(cu.CityName)), ''), '-') AS Lokasyon,
--     ISNULL(NULLIF(LTRIM(RTRIM(cu.DistrictName)), ''), '-') AS Ilce,
--     ISNULL(NULLIF(LTRIM(RTRIM(cu.CountryName)), ''), '-') AS Ulke,
--     ISNULL(NULLIF(LTRIM(RTRIM(cu.Info)), ''), '-') AS MusteriInfo,

--     CASE
--         WHEN cu.IsShopping = 1 THEN N'Evet'
--         WHEN cu.IsShopping = 0 THEN N'Hayır'
--         ELSE '-'
--     END AS AlisverisiVarMi,

--     ISNULL(NULLIF(LTRIM(RTRIM(cu.Tel)), ''), '-') AS IrtibatNumarasi,
--     ISNULL(NULLIF(LTRIM(RTRIM(cu.Email)), ''), '-') AS EmailAdresi,

--     ISNULL(NULLIF(LTRIM(RTRIM(cr.ContactResourceName)), ''), '-') AS IletisimKaynagi,

--     ISNULL(NULLIF(LTRIM(RTRIM(p.CategoryName)), ''), '-') AS CategoryName,
--     '-' AS CategoryCode,

--     ISNULL(NULLIF(LTRIM(RTRIM(ls.Name)), ''), '-') AS LeadDurumu,
--     ISNULL(NULLIF(LTRIM(RTRIM(ns.Name)), ''), '-') AS SonrakiAdim,

--     ISNULL(NULLIF(LTRIM(RTRIM(lp.Name)), ''), '-') AS ProcessName,
--     ISNULL(NULLIF(LTRIM(RTRIM(lp.Code)), ''), '-') AS ProcessCode,
--     lp.StepOrder,
-- CASE
--     WHEN EXISTS
--     (
--         SELECT 1
--         FROM tmscrq.TMLeadReservation r
--         WHERE r.LeadId = l.Id
--           AND r.IsActive = 1
--           AND ISNULL(r.IsApproved,0) = 0
--     )
--     THEN 10
--     ELSE lp.StepOrder
-- END AS SelectedStepOrder,

--     ISNULL(
--         CASE
--             WHEN l.EstimatedDate IS NOT NULL
--             THEN CAST(YEAR(l.EstimatedDate) AS VARCHAR(4)) + ' ' + DATENAME(MONTH, l.EstimatedDate)
--             ELSE NULL
--         END,
--         '-'
--     ) AS TerminTarihi,

--     ISNULL(
--         NULLIF(
--             LTRIM(RTRIM(ISNULL(sp.FirstName, '') + ' ' + ISNULL(sp.LastName, '')))
--         , '')
--     , '-') AS SatisDanismani,

--     ISNULL(NULLIF(LTRIM(RTRIM(st.StoreDesc)), ''), '-') AS StoreName

-- FROM tmscrq.TMLead l
-- LEFT JOIN tmscrq.TMLeadStatu ls
--     ON ls.Id = l.StatuId
-- LEFT JOIN tmscrq.TMCustomer cu
--     ON cu.Id = l.CustomerId
-- LEFT JOIN tmscrq.TMProduct p
--     ON p.Id = l.ProductId
-- LEFT JOIN tmscrq.TMContactResource cr
--     ON cr.Id = l.ContactResourceId
-- LEFT JOIN dbo.KUser sp
--     ON sp.Id = l.SalesPersonKUserId
-- LEFT JOIN tmscrq.TMStore st
--     ON st.Id = l.StoreId
-- LEFT JOIN tmscrq.TMLeadProcess lp
--     ON lp.Id = l.ProcessID
-- LEFT JOIN tmscrq.TMLeadNextStep ns
--     ON ns.Id = l.NextStepId

-- WHERE
-- (
--     EXISTS
--     (
--         SELECT 1
--         FROM dbo.KUserRole ur
--         INNER JOIN dbo.KRole r
--             ON r.Id = ur.KRole_Id
--         WHERE ur.KUser_Id = @UserId
--           AND ur.IsDeleted = 0
--           AND r.IsDeleted = 0
--           AND r.Name IN ('TimesYonetici', 'TimesUstYonetici')
--     )
--     OR
--     (
--         EXISTS
--         (
--             SELECT 1
--             FROM dbo.KUserRole ur
--             INNER JOIN dbo.KRole r
--                 ON r.Id = ur.KRole_Id
--             WHERE ur.KUser_Id = @UserId
--               AND ur.IsDeleted = 0
--               AND r.IsDeleted = 0
--               AND r.Name IN ('TimesMagazaMuduru', 'TimesSatisPersoneli')
--         )
--         AND EXISTS
--         (
--             SELECT 1
--             FROM tmscrq.TMUser tu
--             WHERE tu.KUserID = @UserId
--               AND tu.StoreId = l.StoreId
--         )
--     )
-- )

-- AND
-- (
--     @MusteriAdi IS NULL
--     OR LTRIM(RTRIM(@MusteriAdi)) = ''
--     OR UPPER(LTRIM(RTRIM(ISNULL(cu.Name,'') + ' ' + ISNULL(cu.LastName,''))))
--        LIKE '%' + UPPER(LTRIM(RTRIM(@MusteriAdi))) + '%'
-- )

-- AND
-- (
--     @ProductName IS NULL
--     OR LTRIM(RTRIM(@ProductName)) = ''
--     OR
--     (
--         CHARINDEX(',', @ProductName) > 0
--         AND ISNULL(LTRIM(RTRIM(p.ProductName)), '') IN
--         (
--             SELECT LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', '')))
--             FROM STRING_SPLIT(CAST(@ProductName AS NVARCHAR(MAX)), ',')
--             WHERE LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', ''))) <> ''
--         )
--     )
--     OR
--     (
--         CHARINDEX(',', @ProductName) = 0
--         AND UPPER(ISNULL(LTRIM(RTRIM(p.ProductName)), ''))
--             LIKE '%' + UPPER(LTRIM(RTRIM(@ProductName))) + '%'
--     )
-- )

-- AND
-- (
--     @LeadCode IS NULL
--     OR LTRIM(RTRIM(@LeadCode)) = ''
--     OR UPPER(ISNULL(LTRIM(RTRIM(l.LeadCode)), '')) LIKE '%' + UPPER(LTRIM(RTRIM(@LeadCode))) + '%'
-- )

-- AND
-- (
--     @Tel IS NULL
--     OR LTRIM(RTRIM(@Tel)) = ''
--     OR UPPER(ISNULL(LTRIM(RTRIM(cu.Tel)), '')) LIKE '%' + UPPER(LTRIM(RTRIM(@Tel))) + '%'
-- )

-- -- AND
-- -- (
-- --     @CategoryName IS NULL
-- --     OR LTRIM(RTRIM(@CategoryName)) = ''
-- --     OR
-- --     (
-- --         EXISTS
-- --         (
-- --             SELECT 1
-- --             FROM STRING_SPLIT(CAST(@CategoryName AS NVARCHAR(MAX)), ',') c
-- --             WHERE UPPER(LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(c.value, '""', ''), '[', ''), ']', '')))) = 'DEFAULT'
-- --         )
-- --         AND (p.CategoryName IS NULL OR LTRIM(RTRIM(p.CategoryName)) = '')
-- --     )
-- --     OR UPPER(ISNULL(LTRIM(RTRIM(p.CategoryName)), '')) IN
-- --     (
-- --         SELECT UPPER(LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', ''))))
-- --         FROM STRING_SPLIT(CAST(@CategoryName AS NVARCHAR(MAX)), ',')
-- --         WHERE LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', ''))) <> ''
-- --           AND UPPER(LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', '')))) <> 'DEFAULT'
-- --     )
-- -- )

-- AND
-- (
--     @CategoryName IS NULL
--     OR LTRIM(RTRIM(@CategoryName)) = ''
--     OR UPPER(ISNULL(LTRIM(RTRIM(p.CategoryName)), '')) IN
--     (
--         SELECT UPPER(LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value,'""',''),'[',''),']',''))))
--         FROM STRING_SPLIT(CAST(@CategoryName AS NVARCHAR(MAX)), ',')
--         WHERE LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value,'""',''),'[',''),']',''))) <> ''
--     )
-- )

-- AND
-- (
--     @StoreIds IS NULL
--     OR LTRIM(RTRIM(@StoreIds)) = ''
--     OR EXISTS
--     (
--         SELECT 1
--         FROM STRING_SPLIT(CAST(@StoreIds AS NVARCHAR(MAX)), ',') s
--         WHERE l.StoreId = TRY_CONVERT
--         (
--             uniqueidentifier,
--             LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(s.value, '""', ''), '[', ''), ']', '')))
--         )
--     )
-- )

-- AND
-- (
--     @SatisDanismaniIds IS NULL
--     OR LTRIM(RTRIM(@SatisDanismaniIds)) = ''
--     OR EXISTS
--     (
--         SELECT 1
--         FROM STRING_SPLIT(CAST(@SatisDanismaniIds AS NVARCHAR(MAX)), ',') s
--         WHERE l.SalesPersonKUserId = TRY_CONVERT
--         (
--             uniqueidentifier,
--             LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(s.value, '""', ''), '[', ''), ']', '')))
--         )
--     )
-- )

-- AND
-- (
--     @ProcessCode IS NULL
--     OR LTRIM(RTRIM(@ProcessCode)) = ''
--     OR UPPER(ISNULL(LTRIM(RTRIM(lp.Code)), '')) IN
--     (
--         SELECT UPPER(LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', ''))))
--         FROM STRING_SPLIT(CAST(@ProcessCode AS NVARCHAR(MAX)), ',')
--         WHERE LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', ''))) <> ''
--     )
-- )

-- AND
-- (
--     @StepOrder IS NULL

--     OR
--     (
--         @StepOrder = 10
--         AND EXISTS
--         (
--             SELECT 1
--             FROM tmscrq.TMLeadReservation r
--             WHERE r.LeadId = l.Id
--               AND r.IsActive = 1
--               AND ISNULL(r.IsApproved,0) = 0
--         )
--     )

--     OR
--     (
--         @StepOrder <> 10
--         AND lp.StepOrder = @StepOrder
--     )
-- )

-- AND
-- (
--     @StartDate IS NULL
--     OR LTRIM(RTRIM(@StartDate)) = ''
--     OR l.CreatedAt >= CONVERT(date, @StartDate)
-- )

-- AND
-- (
--     @EndDate IS NULL
--     OR LTRIM(RTRIM(@EndDate)) = ''
--     OR l.CreatedAt < DATEADD(day, 1, CONVERT(date, @EndDate))
-- )

-- ORDER BY l.CreatedAt DESC;

------------------------++++++++++++++++++++++++-------------------
-- SET LANGUAGE Turkish;

-- SELECT
-- CASE 
--     WHEN EXISTS (
--         SELECT 1 
--         FROM tmscrq.TMLeadReservation r
--         WHERE r.LeadId = l.Id
--           AND r.IsActive = 1
--           AND r.IsApproved = 1
--     ) THEN N'Evet'

--     WHEN EXISTS (
--         SELECT 1 
--         FROM tmscrq.TMLeadReservation r
--         WHERE r.LeadId = l.Id
--           AND r.IsActive = 1
--           AND ISNULL(r.IsApproved,0) = 0
--     ) THEN N'Onay Bekliyor'

--     ELSE N'Hayır'
-- END AS RezerveDurumu,
--     l.Id AS LeadId,
--     l.IsReserved,
--     ISNULL(NULLIF(LTRIM(RTRIM(l.LeadCode)), ''), '-') AS LeadNumarasi,
--     CONVERT(varchar(10), l.CreatedAt, 103) AS TalepTarihi,

--     p.Id AS ProductId,
--     ISNULL(NULLIF(LTRIM(RTRIM(p.ProductName)), ''), '-') AS ProductName,
--     ISNULL(NULLIF(LTRIM(RTRIM(p.Bracelet)), ''), '-') AS Bilezik,
--     ISNULL(NULLIF(LTRIM(RTRIM(p.Brand)), ''), '-') AS Brand,
--     ISNULL(NULLIF(LTRIM(RTRIM(p.Dial)), ''), '-') AS Kadran,
--     ISNULL(NULLIF(LTRIM(RTRIM(p.ProductCode)), ''), '-') AS RefCode,
--     ISNULL(NULLIF(LTRIM(RTRIM(p.Referance)), ''), '-') AS Referans,

--     ISNULL(
--         NULLIF(
--             LTRIM(RTRIM(ISNULL(cu.Name, '') + ' ' + ISNULL(cu.LastName, '')))
--         , '')
--     , '-') AS Musteri,

--     ISNULL(NULLIF(LTRIM(RTRIM(cu.CityName)), ''), '-') AS Lokasyon,
--     ISNULL(NULLIF(LTRIM(RTRIM(cu.DistrictName)), ''), '-') AS Ilce,
--     ISNULL(NULLIF(LTRIM(RTRIM(cu.CountryName)), ''), '-') AS Ulke,
--     ISNULL(NULLIF(LTRIM(RTRIM(cu.Info)), ''), '-') AS MusteriInfo,

--     CASE
--         WHEN cu.IsShopping = 1 THEN N'Evet'
--         WHEN cu.IsShopping = 0 THEN N'Hayır'
--         ELSE '-'
--     END AS AlisverisiVarMi,

--     ISNULL(NULLIF(LTRIM(RTRIM(cu.Tel)), ''), '-') AS IrtibatNumarasi,
--     ISNULL(NULLIF(LTRIM(RTRIM(cu.Email)), ''), '-') AS EmailAdresi,

--     ISNULL(NULLIF(LTRIM(RTRIM(cr.ContactResourceName)), ''), '-') AS IletisimKaynagi,

--     ISNULL(NULLIF(LTRIM(RTRIM(p.CategoryName)), ''), '-') AS CategoryName,
--     '-' AS CategoryCode,

--     ISNULL(NULLIF(LTRIM(RTRIM(ls.Name)), ''), '-') AS LeadDurumu,
--     ISNULL(NULLIF(LTRIM(RTRIM(ns.Name)), ''), '-') AS SonrakiAdim,

--     ISNULL(NULLIF(LTRIM(RTRIM(lp.Name)), ''), '-') AS ProcessName,
--     ISNULL(NULLIF(LTRIM(RTRIM(lp.Code)), ''), '-') AS ProcessCode,
--     lp.StepOrder,
    
--     -- DÜZELTİLEN ALAN: SelectedStepOrder
--     CASE
--         WHEN EXISTS
--         (
--             SELECT 1
--             FROM tmscrq.TMLeadReservation r
--             WHERE r.LeadId = l.Id
--               AND r.IsActive = 1
--               AND ISNULL(r.IsApproved,0) = 0
--         )
--         THEN 10
--         ELSE lp.StepOrder
--     END AS SelectedStepOrder,

--     ISNULL(
--         CASE
--             WHEN l.EstimatedDate IS NOT NULL
--             THEN CAST(YEAR(l.EstimatedDate) AS VARCHAR(4)) + ' ' + DATENAME(MONTH, l.EstimatedDate)
--             ELSE NULL
--         END,
--         '-'
--     ) AS TerminTarihi,

--     ISNULL(
--         NULLIF(
--             LTRIM(RTRIM(ISNULL(sp.FirstName, '') + ' ' + ISNULL(sp.LastName, '')))
--         , '')
--     , '-') AS SatisDanismani,

--     ISNULL(NULLIF(LTRIM(RTRIM(st.StoreDesc)), ''), '-') AS StoreName

-- FROM tmscrq.TMLead l
-- LEFT JOIN tmscrq.TMLeadStatu ls
--     ON ls.Id = l.StatuId
-- LEFT JOIN tmscrq.TMCustomer cu
--     ON cu.Id = l.CustomerId
-- LEFT JOIN tmscrq.TMProduct p
--     ON p.Id = l.ProductId
-- LEFT JOIN tmscrq.TMContactResource cr
--     ON cr.Id = l.ContactResourceId
-- LEFT JOIN dbo.KUser sp
--     ON sp.Id = l.SalesPersonKUserId
-- LEFT JOIN tmscrq.TMStore st
--     ON st.Id = l.StoreId
-- LEFT JOIN tmscrq.TMLeadProcess lp
--     ON lp.Id = l.ProcessID
-- LEFT JOIN tmscrq.TMLeadNextStep ns
--     ON ns.Id = l.NextStepId

-- WHERE
-- (
--     EXISTS
--     (
--         SELECT 1
--         FROM dbo.KUserRole ur
--         INNER JOIN dbo.KRole r
--             ON r.Id = ur.KRole_Id
--         WHERE ur.KUser_Id = @UserId
--           AND ur.IsDeleted = 0
--           AND r.IsDeleted = 0
--           AND r.Name IN ('TimesYonetici', 'TimesUstYonetici')
--     )
--     OR
--     (
--         EXISTS
--         (
--             SELECT 1
--             FROM dbo.KUserRole ur
--             INNER JOIN dbo.KRole r
--                 ON r.Id = ur.KRole_Id
--             WHERE ur.KUser_Id = @UserId
--               AND ur.IsDeleted = 0
--               AND r.IsDeleted = 0
--               AND r.Name IN ('TimesMagazaMuduru', 'TimesSatisPersoneli')
--         )
--         AND EXISTS
--         (
--             SELECT 1
--             FROM tmscrq.TMUser tu
--             WHERE tu.KUserID = @UserId
--               AND tu.StoreId = l.StoreId
--         )
--     )
-- )

-- AND
-- (
--     @MusteriAdi IS NULL
--     OR LTRIM(RTRIM(@MusteriAdi)) = ''
--     OR UPPER(LTRIM(RTRIM(ISNULL(cu.Name,'') + ' ' + ISNULL(cu.LastName,''))))
--        LIKE '%' + UPPER(LTRIM(RTRIM(@MusteriAdi))) + '%'
-- )

-- AND
-- (
--     @ProductName IS NULL
--     OR LTRIM(RTRIM(@ProductName)) = ''
--     OR
--     (
--         CHARINDEX(',', @ProductName) > 0
--         AND ISNULL(LTRIM(RTRIM(p.ProductName)), '') IN
--         (
--             SELECT LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', '')))
--             FROM STRING_SPLIT(CAST(@ProductName AS NVARCHAR(MAX)), ',')
--             WHERE LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', ''))) <> ''
--         )
--     )
--     OR
--     (
--         CHARINDEX(',', @ProductName) = 0
--         AND UPPER(ISNULL(LTRIM(RTRIM(p.ProductName)), ''))
--             LIKE '%' + UPPER(LTRIM(RTRIM(@ProductName))) + '%'
--     )
-- )

-- AND
-- (
--     @LeadCode IS NULL
--     OR LTRIM(RTRIM(@LeadCode)) = ''
--     OR UPPER(ISNULL(LTRIM(RTRIM(l.LeadCode)), '')) LIKE '%' + UPPER(LTRIM(RTRIM(@LeadCode))) + '%'
-- )

-- AND
-- (
--     @Tel IS NULL
--     OR LTRIM(RTRIM(@Tel)) = ''
--     OR UPPER(ISNULL(LTRIM(RTRIM(cu.Tel)), '')) LIKE '%' + UPPER(LTRIM(RTRIM(@Tel))) + '%'
-- )

-- AND
-- (
--     @CategoryName IS NULL
--     OR LTRIM(RTRIM(@CategoryName)) = ''
--     OR UPPER(ISNULL(LTRIM(RTRIM(p.CategoryName)), '')) IN
--     (
--         SELECT UPPER(LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value,'""',''),'[',''),']',''))))
--         FROM STRING_SPLIT(CAST(@CategoryName AS NVARCHAR(MAX)), ',')
--         WHERE LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value,'""',''),'[',''),']',''))) <> ''
--     )
-- )

-- AND
-- (
--     @StoreIds IS NULL
--     OR LTRIM(RTRIM(@StoreIds)) = ''
--     OR EXISTS
--     (
--         SELECT 1
--         FROM STRING_SPLIT(CAST(@StoreIds AS NVARCHAR(MAX)), ',') s
--         WHERE l.StoreId = TRY_CONVERT
--         (
--             uniqueidentifier,
--             LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(s.value, '""', ''), '[', ''), ']', '')))
--         )
--     )
-- )

-- AND
-- (
--     @SatisDanismaniIds IS NULL
--     OR LTRIM(RTRIM(@SatisDanismaniIds)) = ''
--     OR EXISTS
--     (
--         SELECT 1
--         FROM STRING_SPLIT(CAST(@SatisDanismaniIds AS NVARCHAR(MAX)), ',') s
--         WHERE l.SalesPersonKUserId = TRY_CONVERT
--         (
--             uniqueidentifier,
--             LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(s.value, '""', ''), '[', ''), ']', '')))
--         )
--     )
-- )

-- AND
-- (
--     @ProcessCode IS NULL
--     OR LTRIM(RTRIM(@ProcessCode)) = ''
--     OR UPPER(ISNULL(LTRIM(RTRIM(lp.Code)), '')) IN
--     (
--         SELECT UPPER(LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', ''))))
--         FROM STRING_SPLIT(CAST(@ProcessCode AS NVARCHAR(MAX)), ',')
--         WHERE LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', ''))) <> ''
--     )
-- )

-- -- DÜZELTİLEN ALAN: @StepOrder Filtresi (tek blok)
-- AND
-- (
--     @StepOrder IS NULL

--     OR

--     (
--         @StepOrder = 10
--         AND EXISTS
--         (
--             SELECT 1
--             FROM tmscrq.TMLeadReservation r
--             WHERE r.LeadId = l.Id
--               AND r.IsActive = 1
--               AND ISNULL(r.IsApproved,0) = 0
--         )
--     )

--     OR

--     (
--         @StepOrder <> 10
--         AND lp.StepOrder = @StepOrder
--     )
-- )

-- AND
-- (
--     @StartDate IS NULL
--     OR LTRIM(RTRIM(@StartDate)) = ''
--     OR l.CreatedAt >= CONVERT(date, @StartDate)
-- )

-- AND
-- (
--     @EndDate IS NULL
--     OR LTRIM(RTRIM(@EndDate)) = ''
--     OR l.CreatedAt < DATEADD(day, 1, CONVERT(date, @EndDate))
-- )

-- ORDER BY l.CreatedAt DESC;



SET LANGUAGE Turkish;

SELECT
CASE 
    WHEN EXISTS (
        SELECT 1 
        FROM tmscrq.TMLeadReservation r
        WHERE r.LeadId = l.Id
          AND r.IsActive = 1
          AND r.IsApproved = 1
    ) THEN N'Evet'

    WHEN EXISTS (
        SELECT 1 
        FROM tmscrq.TMLeadReservation r
        WHERE r.LeadId = l.Id
          AND r.IsActive = 1
          AND ISNULL(r.IsApproved,0) = 0
    ) THEN N'Onay Bekliyor'

    ELSE N'Hayır'
END AS RezerveDurumu,
    l.Id AS LeadId,
    l.IsReserved,
    ISNULL(NULLIF(LTRIM(RTRIM(l.LeadCode)), ''), '-') AS LeadNumarasi,
     FORMAT(l.CreatedAt, 'dd MMMM yyyy', 'tr-TR') AS TalepTarihi,

    p.Id AS ProductId,
    ISNULL(NULLIF(LTRIM(RTRIM(p.ProductName)), ''), '-') AS ProductName,
    ISNULL(NULLIF(LTRIM(RTRIM(p.Bracelet)), ''), '-') AS Bilezik,
    ISNULL(NULLIF(LTRIM(RTRIM(p.Brand)), ''), '-') AS Brand,
    ISNULL(NULLIF(LTRIM(RTRIM(p.Dial)), ''), '-') AS Kadran,
    ISNULL(NULLIF(LTRIM(RTRIM(p.ProductCode)), ''), '-') AS RefCode,
    ISNULL(NULLIF(LTRIM(RTRIM(p.Referance)), ''), '-') AS Referans,

    ISNULL(
        NULLIF(
            LTRIM(RTRIM(ISNULL(cu.Name, '') + ' ' + ISNULL(cu.LastName, '')))
        , '')
    , '-') AS Musteri,

    ISNULL(NULLIF(LTRIM(RTRIM(cu.CityName)), ''), '-') AS Lokasyon,
    ISNULL(NULLIF(LTRIM(RTRIM(cu.DistrictName)), ''), '-') AS Ilce,
    ISNULL(NULLIF(LTRIM(RTRIM(cu.CountryName)), ''), '-') AS Ulke,
    ISNULL(NULLIF(LTRIM(RTRIM(cu.Info)), ''), '-') AS MusteriInfo,

    CASE
        WHEN cu.IsShopping = 1 THEN N'Evet'
        WHEN cu.IsShopping = 0 THEN N'Hayır'
        ELSE '-'
    END AS AlisverisiVarMi,

    ISNULL(NULLIF(LTRIM(RTRIM(cu.Tel)), ''), '-') AS IrtibatNumarasi,
    ISNULL(NULLIF(LTRIM(RTRIM(cu.Email)), ''), '-') AS EmailAdresi,

    ISNULL(NULLIF(LTRIM(RTRIM(cr.ContactResourceName)), ''), '-') AS IletisimKaynagi,

    ISNULL(NULLIF(LTRIM(RTRIM(p.CategoryName)), ''), '-') AS CategoryName,
    '-' AS CategoryCode,

    ISNULL(NULLIF(LTRIM(RTRIM(ls.Name)), ''), '-') AS LeadDurumu,
    ISNULL(NULLIF(LTRIM(RTRIM(ns.Name)), ''), '-') AS SonrakiAdim,

    ISNULL(NULLIF(LTRIM(RTRIM(lp.Name)), ''), '-') AS ProcessName,
    ISNULL(NULLIF(LTRIM(RTRIM(lp.Code)), ''), '-') AS ProcessCode,
    lp.StepOrder,
    
    -- DÜZELTİLEN ALAN: SelectedStepOrder
    CASE
        WHEN EXISTS
        (
            SELECT 1
            FROM tmscrq.TMLeadReservation r
            WHERE r.LeadId = l.Id
              AND r.IsActive = 1
              AND ISNULL(r.IsApproved,0) = 0
        )
        THEN 10
        ELSE lp.StepOrder
    END AS SelectedStepOrder,

    ISNULL(
        CASE
            WHEN l.EstimatedDate IS NOT NULL
            THEN CAST(YEAR(l.EstimatedDate) AS VARCHAR(4)) + ' ' + DATENAME(MONTH, l.EstimatedDate)
            ELSE NULL
        END,
        '-'
    ) AS TerminTarihi,

    ISNULL(
        NULLIF(
            LTRIM(RTRIM(ISNULL(sp.FirstName, '') + ' ' + ISNULL(sp.LastName, '')))
        , '')
    , '-') AS SatisDanismani,

    ISNULL(NULLIF(LTRIM(RTRIM(st.StoreDesc)), ''), '-') AS StoreName

FROM tmscrq.TMLead l
LEFT JOIN tmscrq.TMLeadStatu ls
    ON ls.Id = l.StatuId
LEFT JOIN tmscrq.TMCustomer cu
    ON cu.Id = l.CustomerId
LEFT JOIN tmscrq.TMProduct p
    ON p.Id = l.ProductId
LEFT JOIN tmscrq.TMContactResource cr
    ON cr.Id = l.ContactResourceId
LEFT JOIN dbo.KUser sp
    ON sp.Id = l.SalesPersonKUserId
LEFT JOIN tmscrq.TMStore st
    ON st.Id = l.StoreId
LEFT JOIN tmscrq.TMLeadProcess lp
    ON lp.Id = l.ProcessID
LEFT JOIN tmscrq.TMLeadNextStep ns
    ON ns.Id = l.NextStepId

WHERE
(
    EXISTS
    (
        SELECT 1
        FROM dbo.KUserRole ur
        INNER JOIN dbo.KRole r
            ON r.Id = ur.KRole_Id
        WHERE ur.KUser_Id = @UserId
          AND ur.IsDeleted = 0
          AND r.IsDeleted = 0
          AND r.Name IN ('TimesYonetici', 'TimesUstYonetici')
    )
    OR
    (
        EXISTS
        (
            SELECT 1
            FROM dbo.KUserRole ur
            INNER JOIN dbo.KRole r
                ON r.Id = ur.KRole_Id
            WHERE ur.KUser_Id = @UserId
              AND ur.IsDeleted = 0
              AND r.IsDeleted = 0
              AND r.Name IN ('TimesMagazaMuduru', 'TimesSatisPersoneli')
        )
        AND EXISTS
        (
            SELECT 1
            FROM tmscrq.TMUser tu
            WHERE tu.KUserID = @UserId
              AND tu.StoreId = l.StoreId
        )
    )
)

AND
(
    ISNULL(@MusteriAdi, '') = ''
    OR UPPER(ISNULL(cu.Name, '')) LIKE '%' + UPPER(LTRIM(RTRIM(@MusteriAdi))) + '%'
    OR UPPER(ISNULL(cu.LastName, '')) LIKE '%' + UPPER(LTRIM(RTRIM(@MusteriAdi))) + '%'
    OR UPPER(
        ISNULL(cu.Name, '') + ' ' + ISNULL(cu.LastName, '')
    ) LIKE '%' + UPPER(LTRIM(RTRIM(@MusteriAdi))) + '%'
)

AND
(
    @ProductName IS NULL
    OR LTRIM(RTRIM(@ProductName)) = ''
    OR
    (
        CHARINDEX(',', @ProductName) > 0
        AND ISNULL(LTRIM(RTRIM(p.ProductName)), '') IN
        (
            SELECT LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', '')))
            FROM STRING_SPLIT(CAST(@ProductName AS NVARCHAR(MAX)), ',')
            WHERE LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', ''))) <> ''
        )
    )
    OR
    (
        CHARINDEX(',', @ProductName) = 0
        AND UPPER(ISNULL(LTRIM(RTRIM(p.ProductName)), ''))
            LIKE '%' + UPPER(LTRIM(RTRIM(@ProductName))) + '%'
    )
)

AND
(
    ISNULL(@LeadCode, '') = ''
    OR UPPER(ISNULL(l.LeadCode, ''))
        LIKE '%' + UPPER(LTRIM(RTRIM(@LeadCode))) + '%'
    OR REPLACE(
        REPLACE(
            REPLACE(
                UPPER(ISNULL(l.LeadCode, '')),
                '-', ''
            ),
            ' ', ''
        ),
        '/', ''
    )
    LIKE '%' +
    REPLACE(
        REPLACE(
            REPLACE(
                UPPER(LTRIM(RTRIM(@LeadCode))),
                '-', ''
            ),
            ' ', ''
        ),
        '/', ''
    )
    + '%'
)

AND
(
    @Tel IS NULL
    OR LTRIM(RTRIM(@Tel)) = ''
    OR UPPER(ISNULL(LTRIM(RTRIM(cu.Tel)), '')) LIKE '%' + UPPER(LTRIM(RTRIM(@Tel))) + '%'
)

AND
(
    @CategoryName IS NULL
    OR LTRIM(RTRIM(@CategoryName)) = ''
    OR UPPER(ISNULL(LTRIM(RTRIM(p.CategoryName)), '')) IN
    (
        SELECT UPPER(LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value,'""',''),'[',''),']',''))))
        FROM STRING_SPLIT(CAST(@CategoryName AS NVARCHAR(MAX)), ',')
        WHERE LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value,'""',''),'[',''),']',''))) <> ''
    )
)

AND
(
    @StoreIds IS NULL
    OR LTRIM(RTRIM(@StoreIds)) = ''
    OR EXISTS
    (
        SELECT 1
        FROM STRING_SPLIT(CAST(@StoreIds AS NVARCHAR(MAX)), ',') s
        WHERE l.StoreId = TRY_CONVERT
        (
            uniqueidentifier,
            LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(s.value, '""', ''), '[', ''), ']', '')))
        )
    )
)

AND
(
    @SatisDanismaniIds IS NULL
    OR LTRIM(RTRIM(@SatisDanismaniIds)) = ''
    OR EXISTS
    (
        SELECT 1
        FROM STRING_SPLIT(CAST(@SatisDanismaniIds AS NVARCHAR(MAX)), ',') s
        WHERE l.SalesPersonKUserId = TRY_CONVERT
        (
            uniqueidentifier,
            LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(s.value, '""', ''), '[', ''), ']', '')))
        )
    )
)

AND
(
    ISNULL(@ProcessCode, '') = ''
    OR EXISTS
    (
        SELECT 1
        FROM STRING_SPLIT(
            CONVERT(NVARCHAR(MAX), @ProcessCode),
            ','
        ) AS s
        WHERE
            UPPER(LTRIM(RTRIM(s.value))) =
            UPPER(LTRIM(RTRIM(ISNULL(lp.Code, ''))))
    )
)

-- DÜZELTİLEN ALAN: @StepOrder Filtresi (0 verilince tümü gelsin)
AND
(
    @StepOrder IS NULL
    OR @StepOrder = 0  -- 👈 YENİ EKLENDI: 0 verilince tüm kayıtlar gelir
    OR
    (
        @StepOrder = 10
        AND EXISTS
        (
            SELECT 1
            FROM tmscrq.TMLeadReservation r
            WHERE r.LeadId = l.Id
              AND r.IsActive = 1
              AND ISNULL(r.IsApproved,0) = 0
        )
    )
    OR
    (
        @StepOrder <> 10
        AND lp.StepOrder = @StepOrder
    )
)

AND
(
    @StartDate IS NULL
    OR LTRIM(RTRIM(@StartDate)) = ''
    OR l.CreatedAt >= CONVERT(date, @StartDate)
)

AND
(
    @EndDate IS NULL
    OR LTRIM(RTRIM(@EndDate)) = ''
    OR l.CreatedAt < DATEADD(day, 1, CONVERT(date, @EndDate))
)

ORDER BY l.CreatedAt DESC;", new string[] { "RezerveDurumu", "LeadId", "IsReserved", "LeadNumarasi", "TalepTarihi", "ProductId", "ProductName", "Bilezik", "Brand", "Kadran", "RefCode", "Referans", "Musteri", "Lokasyon", "Ilce", "Ulke", "MusteriInfo", "AlisverisiVarMi", "IrtibatNumarasi", "EmailAdresi", "IletisimKaynagi", "CategoryName", "CategoryCode", "LeadDurumu", "SonrakiAdim", "ProcessName", "ProcessCode", "StepOrder", "SelectedStepOrder", "TerminTarihi", "SatisDanismani", "StoreName" }, prms_TM_GetLeads_0.ToArray());
            ;

            var prms_TMLeadProcessCountSummary_1 = new List<kSqlParameter>();
            prms_TMLeadProcessCountSummary_1.Add(new kSqlParameter() { Name = "UserId", Value = Kuika.Common.KContext.CurrentUser?.Id });
            prms_TMLeadProcessCountSummary_1.Add(new kSqlParameter() { Name = "MusteriAdi", Value = request.MusteriAdi_1 });
            prms_TMLeadProcessCountSummary_1.Add(new kSqlParameter() { Name = "ProductName", Value = request.ProductName_1 });
            prms_TMLeadProcessCountSummary_1.Add(new kSqlParameter() { Name = "LeadCode", Value = request.LeadCode_1 });
            prms_TMLeadProcessCountSummary_1.Add(new kSqlParameter() { Name = "Tel", Value = request.Tel_1 });
            prms_TMLeadProcessCountSummary_1.Add(new kSqlParameter() { Name = "CategoryName", Value = request.CategoryName_1 });
            prms_TMLeadProcessCountSummary_1.Add(new kSqlParameter() { Name = "StoreIds", Value = request.StoreIds_1 });
            prms_TMLeadProcessCountSummary_1.Add(new kSqlParameter() { Name = "SatisDanismaniIds", Value = request.SatisDanismaniIds_1 });
            prms_TMLeadProcessCountSummary_1.Add(new kSqlParameter() { Name = "ProcessCode", Value = request.ProcessCode_1 });
            prms_TMLeadProcessCountSummary_1.Add(new kSqlParameter() { Name = "StartDate", Value = request.StartDate_1 });
            prms_TMLeadProcessCountSummary_1.Add(new kSqlParameter() { Name = "EndDate", Value = request.EndDate_1 });
            using var auditTMLeadProcessCountSummary_1 = ActionAuditScope.Begin("880c0ec6-6a25-a6a8-d855-45b94fe460f8", "TMLeadProcessCountSummary", applicationName: "wbTimesCRM", screenOrEndpointName: "LeadList");
            result.TMLeadProcessCountSummary = KPersister.Fetch(KContext.GetConnectionString(), @"-- SELECT
--     COUNT(*) AS ToplamTalepSayisi,

--     SUM(CASE WHEN lp.Code = 'PENDING' THEN 1 ELSE 0 END) AS OnayBekleyenSayisi,
--     SUM(CASE WHEN lp.Code = 'TERMIN_PENDING' THEN 1 ELSE 0 END) AS TerminBekleyenSayisi,
--     SUM(CASE WHEN lp.Code = 'APPROVED' THEN 1 ELSE 0 END) AS OnaylananSayisi,
--     SUM(CASE WHEN lp.Code = 'REJECTED' THEN 1 ELSE 0 END) AS ReddedilenSayisi,
--     SUM(CASE WHEN lp.Code = 'DELIVERY_PENDING' THEN 1 ELSE 0 END) AS TeslimEdilecekSayisi,
--     SUM(CASE WHEN lp.Code = 'DELIVERED' THEN 1 ELSE 0 END) AS TeslimEdildiSayisi

-- FROM tmscrq.TMLead l
-- LEFT JOIN tmscrq.TMCustomer cu
--     ON cu.Id = l.CustomerId
-- LEFT JOIN tmscrq.TMProduct p
--     ON p.Id = l.ProductId
-- LEFT JOIN dbo.KUser sp
--     ON sp.Id = l.SalesPersonKUserId
-- LEFT JOIN tmscrq.TMLeadProcess lp
--     ON lp.Id = l.ProcessID

-- WHERE
-- (
--     EXISTS
--     (
--         SELECT 1
--         FROM dbo.KUserRole ur
--         INNER JOIN dbo.KRole r
--             ON r.Id = ur.KRole_Id
--         WHERE ur.KUser_Id = @UserId
--           AND ur.IsDeleted = 0
--           AND r.IsDeleted = 0
--           AND r.Name IN ('TimesYonetici', 'TimesUstYonetici')
--     )
--     OR
--     (
--         EXISTS
--         (
--             SELECT 1
--             FROM dbo.KUserRole ur
--             INNER JOIN dbo.KRole r
--                 ON r.Id = ur.KRole_Id
--             WHERE ur.KUser_Id = @UserId
--               AND ur.IsDeleted = 0
--               AND r.IsDeleted = 0
--               AND r.Name IN ('TimesMagazaMuduru', 'TimesSatisPersoneli')
--         )
--         AND EXISTS
--         (
--             SELECT 1
--             FROM tmscrq.TMUser tu
--             WHERE tu.KUserID = @UserId
--               AND tu.StoreId = l.StoreId
--         )
--     )
-- )

-- AND
-- (
--     @MusteriAdi IS NULL
--     OR LTRIM(RTRIM(@MusteriAdi)) = ''
--     OR UPPER(LTRIM(RTRIM(ISNULL(cu.Name, '') + ' ' + ISNULL(cu.LastName, ''))))
--        LIKE '%' + UPPER(LTRIM(RTRIM(@MusteriAdi))) + '%'
-- )

-- AND
-- (
--     @ProductName IS NULL
--     OR LTRIM(RTRIM(@ProductName)) = ''
--     OR
--     (
--         CHARINDEX(',', @ProductName) > 0
--         AND ISNULL(LTRIM(RTRIM(p.ProductName)), '') IN
--         (
--             SELECT LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', '')))
--             FROM STRING_SPLIT(CAST(@ProductName AS NVARCHAR(MAX)), ',')
--             WHERE LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', ''))) <> ''
--         )
--     )
--     OR
--     (
--         CHARINDEX(',', @ProductName) = 0
--         AND UPPER(ISNULL(LTRIM(RTRIM(p.ProductName)), ''))
--             LIKE '%' + UPPER(LTRIM(RTRIM(@ProductName))) + '%'
--     )
-- )

-- AND
-- (
--     @LeadCode IS NULL
--     OR LTRIM(RTRIM(@LeadCode)) = ''
--     OR UPPER(ISNULL(LTRIM(RTRIM(l.LeadCode)), '')) LIKE '%' + UPPER(LTRIM(RTRIM(@LeadCode))) + '%'
-- )

-- AND
-- (
--     @Tel IS NULL
--     OR LTRIM(RTRIM(@Tel)) = ''
--     OR UPPER(ISNULL(LTRIM(RTRIM(cu.Tel)), '')) LIKE '%' + UPPER(LTRIM(RTRIM(@Tel))) + '%'
-- )

-- AND
-- (
--     @CategoryName IS NULL
--     OR LTRIM(RTRIM(@CategoryName)) = ''
--     OR
--     (
--         EXISTS
--         (
--             SELECT 1
--             FROM STRING_SPLIT(CAST(@CategoryName AS NVARCHAR(MAX)), ',') c
--             WHERE UPPER(LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(c.value, '""', ''), '[', ''), ']', '')))) = 'DEFAULT'
--         )
--         AND (p.CategoryName IS NULL OR LTRIM(RTRIM(p.CategoryName)) = '')
--     )
--     OR UPPER(ISNULL(LTRIM(RTRIM(p.CategoryName)), '')) IN
--     (
--         SELECT UPPER(LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', ''))))
--         FROM STRING_SPLIT(CAST(@CategoryName AS NVARCHAR(MAX)), ',')
--         WHERE LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', ''))) <> ''
--           AND UPPER(LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', '')))) <> 'DEFAULT'
--     )
-- )

-- AND
-- (
--     @StoreIds IS NULL
--     OR LTRIM(RTRIM(@StoreIds)) = ''
--     OR EXISTS
--     (
--         SELECT 1
--         FROM STRING_SPLIT(CAST(@StoreIds AS NVARCHAR(MAX)), ',') s
--         WHERE l.StoreId = TRY_CONVERT
--         (
--             uniqueidentifier,
--             LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(s.value, '""', ''), '[', ''), ']', '')))
--         )
--     )
-- )

-- AND
-- (
--     @SatisDanismaniIds IS NULL
--     OR LTRIM(RTRIM(@SatisDanismaniIds)) = ''
--     OR EXISTS
--     (
--         SELECT 1
--         FROM STRING_SPLIT(CAST(@SatisDanismaniIds AS NVARCHAR(MAX)), ',') s
--         WHERE l.SalesPersonKUserId = TRY_CONVERT
--         (
--             uniqueidentifier,
--             LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(s.value, '""', ''), '[', ''), ']', '')))
--         )
--     )
-- )

-- AND
-- (
--     @ProcessCode IS NULL
--     OR LTRIM(RTRIM(@ProcessCode)) = ''
--     OR UPPER(ISNULL(LTRIM(RTRIM(lp.Code)), '')) IN
--     (
--         SELECT UPPER(LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', ''))))
--         FROM STRING_SPLIT(CAST(@ProcessCode AS NVARCHAR(MAX)), ',')
--         WHERE LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', ''))) <> ''
--     )
-- )

-- AND
-- (
--     @StartDate IS NULL
--     OR LTRIM(RTRIM(@StartDate)) = ''
--     OR l.CreatedAt >= CONVERT(date, @StartDate)
-- )

-- AND
-- (
--     @EndDate IS NULL
--     OR LTRIM(RTRIM(@EndDate)) = ''
--     OR l.CreatedAt < DATEADD(day, 1, CONVERT(date, @EndDate))
-- );

-------------------------------------------------------------

DECLARE @KUserId UNIQUEIDENTIFIER = @UserId;

WITH UserRoles AS (
    SELECT r.Name
    FROM dbo.KUserRole ur
    INNER JOIN dbo.KRole r 
        ON r.Id = ur.KRole_Id
    WHERE ur.KUser_Id = @KUserId
      AND ur.IsDeleted = 0
      AND r.IsDeleted = 0
),
IsAdmin AS (
    SELECT CASE 
        WHEN EXISTS (
            SELECT 1 
            FROM UserRoles 
            WHERE Name = 'TimesUstYonetici'
        ) THEN 1 ELSE 0 END AS IsAdmin
)

SELECT
    COUNT(*) AS ToplamTalepSayisi,

    SUM(CASE WHEN lp.Code = 'PENDING' THEN 1 ELSE 0 END) AS OnayBekleyenSayisi,
    SUM(CASE WHEN lp.Code = 'TERMIN_PENDING' THEN 1 ELSE 0 END) AS TerminBekleyenSayisi,
    SUM(CASE WHEN lp.Code = 'APPROVED' THEN 1 ELSE 0 END) AS OnaylananSayisi,
    SUM(CASE WHEN lp.Code = 'REJECTED' THEN 1 ELSE 0 END) AS ReddedilenSayisi,
    SUM(CASE WHEN lp.Code = 'DELIVERY_PENDING' THEN 1 ELSE 0 END) AS TeslimEdilecekSayisi,
    SUM(CASE WHEN lp.Code = 'DELIVERED' THEN 1 ELSE 0 END) AS TeslimEdildiSayisi

FROM tmscrq.TMLead l
LEFT JOIN tmscrq.TMCustomer cu
    ON cu.Id = l.CustomerId
LEFT JOIN tmscrq.TMProduct p
    ON p.Id = l.ProductId
LEFT JOIN dbo.KUser sp
    ON sp.Id = l.SalesPersonKUserId
LEFT JOIN tmscrq.TMLeadProcess lp
    ON lp.Id = l.ProcessID

CROSS JOIN IsAdmin a

WHERE
(
    -- admin → full
    a.IsAdmin = 1

    -- diğerleri → sadece kendi mağazaları
    OR EXISTS
    (
        SELECT 1
        FROM tmscrq.TMUser tu
        WHERE tu.KUserID = @KUserId
          AND tu.StoreId = l.StoreId
    )
)

-- 🔽 AŞAĞISI SENİN ORİJİNAL FİLTRELER (HİÇ DOKUNMADIM)

AND
(
    @MusteriAdi IS NULL
    OR LTRIM(RTRIM(@MusteriAdi)) = ''
    OR UPPER(LTRIM(RTRIM(ISNULL(cu.Name, '') + ' ' + ISNULL(cu.LastName, ''))))
       LIKE '%' + UPPER(LTRIM(RTRIM(@MusteriAdi))) + '%'
)

AND
(
    @ProductName IS NULL
    OR LTRIM(RTRIM(@ProductName)) = ''
    OR
    (
        CHARINDEX(',', @ProductName) > 0
        AND ISNULL(LTRIM(RTRIM(p.ProductName)), '') IN
        (
            SELECT LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', '')))
            FROM STRING_SPLIT(CAST(@ProductName AS NVARCHAR(MAX)), ',')
        )
    )
    OR
    (
        CHARINDEX(',', @ProductName) = 0
        AND UPPER(ISNULL(LTRIM(RTRIM(p.ProductName)), ''))
            LIKE '%' + UPPER(LTRIM(RTRIM(@ProductName))) + '%'
    )
)

AND
(
    @LeadCode IS NULL
    OR LTRIM(RTRIM(@LeadCode)) = ''
    OR UPPER(ISNULL(LTRIM(RTRIM(l.LeadCode)), '')) LIKE '%' + UPPER(LTRIM(RTRIM(@LeadCode))) + '%'
)

AND
(
    @Tel IS NULL
    OR LTRIM(RTRIM(@Tel)) = ''
    OR UPPER(ISNULL(LTRIM(RTRIM(cu.Tel)), '')) LIKE '%' + UPPER(LTRIM(RTRIM(@Tel))) + '%'
)

AND
(
    @CategoryName IS NULL
    OR LTRIM(RTRIM(@CategoryName)) = ''
    OR
    (
        EXISTS
        (
            SELECT 1
            FROM STRING_SPLIT(CAST(@CategoryName AS NVARCHAR(MAX)), ',') c
            WHERE UPPER(LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(c.value, '""', ''), '[', ''), ']', '')))) = 'DEFAULT'
        )
        AND (p.CategoryName IS NULL OR LTRIM(RTRIM(p.CategoryName)) = '')
    )
    OR UPPER(ISNULL(LTRIM(RTRIM(p.CategoryName)), '')) IN
    (
        SELECT UPPER(LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', ''))))
        FROM STRING_SPLIT(CAST(@CategoryName AS NVARCHAR(MAX)), ',')
    )
)

AND
(
    @StoreIds IS NULL
    OR LTRIM(RTRIM(@StoreIds)) = ''
    OR EXISTS
    (
        SELECT 1
        FROM STRING_SPLIT(CAST(@StoreIds AS NVARCHAR(MAX)), ',') s
        WHERE l.StoreId = TRY_CONVERT
        (
            uniqueidentifier,
            LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(s.value, '""', ''), '[', ''), ']', '')))
        )
    )
)

AND
(
    @SatisDanismaniIds IS NULL
    OR LTRIM(RTRIM(@SatisDanismaniIds)) = ''
    OR EXISTS
    (
        SELECT 1
        FROM STRING_SPLIT(CAST(@SatisDanismaniIds AS NVARCHAR(MAX)), ',') s
        WHERE l.SalesPersonKUserId = TRY_CONVERT
        (
            uniqueidentifier,
            LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(s.value, '""', ''), '[', ''), ']', '')))
        )
    )
)

AND
(
    @ProcessCode IS NULL
    OR LTRIM(RTRIM(@ProcessCode)) = ''
    OR UPPER(ISNULL(LTRIM(RTRIM(lp.Code)), '')) IN
    (
        SELECT UPPER(LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', ''))))
        FROM STRING_SPLIT(CAST(@ProcessCode AS NVARCHAR(MAX)), ',')
    )
)

AND
(
    @StartDate IS NULL
    OR LTRIM(RTRIM(@StartDate)) = ''
    OR l.CreatedAt >= CONVERT(date, @StartDate)
)

AND
(
    @EndDate IS NULL
    OR LTRIM(RTRIM(@EndDate)) = ''
    OR l.CreatedAt < DATEADD(day, 1, CONVERT(date, @EndDate))
);", new string[] { "ToplamTalepSayisi", "OnayBekleyenSayisi", "TerminBekleyenSayisi", "OnaylananSayisi", "ReddedilenSayisi", "TeslimEdilecekSayisi", "TeslimEdildiSayisi" }, prms_TMLeadProcessCountSummary_1.ToArray());
            ;


            return Ok(result);
        }


        [HttpPost, Route("LeadListComponent_872239_onChange")]
        public IActionResult LeadListComponent_872239_onChange(LeadListComponent_872239_onChange_Request request)
        {

            KProviderManager.Authorization.IsAuthorizedForRoles(appId, appName, screenId, screenName, new List<string> { $"70de6cfc-6087-6059-59b4-0b5a8527af6b", "4da1f213-c8e4-0b50-5c84-02fd13f1a622", "c4e882ef-977d-f613-7694-230ac83919d2", "b4bfd39c-ac02-f442-c899-7a2374a45b47", "cdb536b0-6297-155f-d446-8453d8a60304", "TimesYonetici", "TimesUstYonetici", "TimesSatisPersoneli", "TimesMagazaMuduru", "TimesAdmin" });

            var result = new LeadListComponent_872239_onChange_Response();

            var prms_TM_GetLeads_0 = new List<kSqlParameter>();
            prms_TM_GetLeads_0.Add(new kSqlParameter() { Name = "StepOrder", Value = request.StepOrder_0 });
            prms_TM_GetLeads_0.Add(new kSqlParameter() { Name = "UserId", Value = Kuika.Common.KContext.CurrentUser?.Id });
            prms_TM_GetLeads_0.Add(new kSqlParameter() { Name = "MusteriAdi", Value = request.MusteriAdi_0 });
            prms_TM_GetLeads_0.Add(new kSqlParameter() { Name = "ProductName", Value = request.ProductName_0 });
            prms_TM_GetLeads_0.Add(new kSqlParameter() { Name = "LeadCode", Value = request.LeadCode_0 });
            prms_TM_GetLeads_0.Add(new kSqlParameter() { Name = "Tel", Value = request.Tel_0 });
            prms_TM_GetLeads_0.Add(new kSqlParameter() { Name = "CategoryName", Value = request.CategoryName_0 });
            prms_TM_GetLeads_0.Add(new kSqlParameter() { Name = "StoreIds", Value = request.StoreIds_0 });
            prms_TM_GetLeads_0.Add(new kSqlParameter() { Name = "SatisDanismaniIds", Value = request.SatisDanismaniIds_0 });
            prms_TM_GetLeads_0.Add(new kSqlParameter() { Name = "ProcessCode", Value = request.ProcessCode_0 });
            prms_TM_GetLeads_0.Add(new kSqlParameter() { Name = "StartDate", Value = request.StartDate_0 });
            prms_TM_GetLeads_0.Add(new kSqlParameter() { Name = "EndDate", Value = request.EndDate_0 });
            using var auditTM_GetLeads_0 = ActionAuditScope.Begin("3b4edac1-b7b3-e994-9a71-bf8703b3892c", "TM_GetLeads", applicationName: "wbTimesCRM", screenOrEndpointName: "LeadList");
            result.TM_GetLeads = KPersister.Fetch(KContext.GetConnectionString(), @"-- SET LANGUAGE Turkish;

-- SELECT
-- CASE 
--     WHEN EXISTS (
--         SELECT 1 
--         FROM tmscrq.TMLeadReservation r
--         WHERE r.LeadId = l.Id
--           AND r.IsActive = 1
--           AND r.IsApproved = 1
--     ) THEN N'Evet'

--     WHEN EXISTS (
--         SELECT 1 
--         FROM tmscrq.TMLeadReservation r
--         WHERE r.LeadId = l.Id
--           AND r.IsActive = 1
--           AND ISNULL(r.IsApproved,0) = 0
--     ) THEN N'Onay Bekliyor'

--     ELSE N'Hayır'
-- END AS RezerveDurumu,
--     l.Id AS LeadId,
--     l.IsReserved,
--     ISNULL(NULLIF(LTRIM(RTRIM(l.LeadCode)), ''), '-') AS LeadNumarasi,
--     CONVERT(varchar(10), l.CreatedAt, 103) AS TalepTarihi,

--     p.Id AS ProductId,
--     ISNULL(NULLIF(LTRIM(RTRIM(p.ProductName)), ''), '-') AS ProductName,
--     ISNULL(NULLIF(LTRIM(RTRIM(p.Bracelet)), ''), '-') AS Bilezik,
--     ISNULL(NULLIF(LTRIM(RTRIM(p.Brand)), ''), '-') AS Brand,
--     ISNULL(NULLIF(LTRIM(RTRIM(p.Dial)), ''), '-') AS Kadran,
--     ISNULL(NULLIF(LTRIM(RTRIM(p.ProductCode)), ''), '-') AS RefCode,
--     ISNULL(NULLIF(LTRIM(RTRIM(p.Referance)), ''), '-') AS Referans,

--     ISNULL(
--         NULLIF(
--             LTRIM(RTRIM(ISNULL(cu.Name, '') + ' ' + ISNULL(cu.LastName, '')))
--         , '')
--     , '-') AS Musteri,

--     ISNULL(NULLIF(LTRIM(RTRIM(cu.CityName)), ''), '-') AS Lokasyon,
--     ISNULL(NULLIF(LTRIM(RTRIM(cu.DistrictName)), ''), '-') AS Ilce,
--     ISNULL(NULLIF(LTRIM(RTRIM(cu.CountryName)), ''), '-') AS Ulke,
--     ISNULL(NULLIF(LTRIM(RTRIM(cu.Info)), ''), '-') AS MusteriInfo,

--     CASE
--         WHEN cu.IsShopping = 1 THEN N'Evet'
--         WHEN cu.IsShopping = 0 THEN N'Hayır'
--         ELSE '-'
--     END AS AlisverisiVarMi,

--     ISNULL(NULLIF(LTRIM(RTRIM(cu.Tel)), ''), '-') AS IrtibatNumarasi,
--     ISNULL(NULLIF(LTRIM(RTRIM(cu.Email)), ''), '-') AS EmailAdresi,

--     ISNULL(NULLIF(LTRIM(RTRIM(cr.ContactResourceName)), ''), '-') AS IletisimKaynagi,

--     ISNULL(NULLIF(LTRIM(RTRIM(p.CategoryName)), ''), '-') AS CategoryName,
--     '-' AS CategoryCode,

--     ISNULL(NULLIF(LTRIM(RTRIM(ls.Name)), ''), '-') AS LeadDurumu,
--     ISNULL(NULLIF(LTRIM(RTRIM(ns.Name)), ''), '-') AS SonrakiAdim,

--     ISNULL(NULLIF(LTRIM(RTRIM(lp.Name)), ''), '-') AS ProcessName,
--     ISNULL(NULLIF(LTRIM(RTRIM(lp.Code)), ''), '-') AS ProcessCode,
--     lp.StepOrder,
-- CASE
--     WHEN EXISTS
--     (
--         SELECT 1
--         FROM tmscrq.TMLeadReservation r
--         WHERE r.LeadId = l.Id
--           AND r.IsActive = 1
--           AND ISNULL(r.IsApproved,0) = 0
--     )
--     THEN 10
--     ELSE lp.StepOrder
-- END AS SelectedStepOrder,

--     ISNULL(
--         CASE
--             WHEN l.EstimatedDate IS NOT NULL
--             THEN CAST(YEAR(l.EstimatedDate) AS VARCHAR(4)) + ' ' + DATENAME(MONTH, l.EstimatedDate)
--             ELSE NULL
--         END,
--         '-'
--     ) AS TerminTarihi,

--     ISNULL(
--         NULLIF(
--             LTRIM(RTRIM(ISNULL(sp.FirstName, '') + ' ' + ISNULL(sp.LastName, '')))
--         , '')
--     , '-') AS SatisDanismani,

--     ISNULL(NULLIF(LTRIM(RTRIM(st.StoreDesc)), ''), '-') AS StoreName

-- FROM tmscrq.TMLead l
-- LEFT JOIN tmscrq.TMLeadStatu ls
--     ON ls.Id = l.StatuId
-- LEFT JOIN tmscrq.TMCustomer cu
--     ON cu.Id = l.CustomerId
-- LEFT JOIN tmscrq.TMProduct p
--     ON p.Id = l.ProductId
-- LEFT JOIN tmscrq.TMContactResource cr
--     ON cr.Id = l.ContactResourceId
-- LEFT JOIN dbo.KUser sp
--     ON sp.Id = l.SalesPersonKUserId
-- LEFT JOIN tmscrq.TMStore st
--     ON st.Id = l.StoreId
-- LEFT JOIN tmscrq.TMLeadProcess lp
--     ON lp.Id = l.ProcessID
-- LEFT JOIN tmscrq.TMLeadNextStep ns
--     ON ns.Id = l.NextStepId

-- WHERE
-- (
--     EXISTS
--     (
--         SELECT 1
--         FROM dbo.KUserRole ur
--         INNER JOIN dbo.KRole r
--             ON r.Id = ur.KRole_Id
--         WHERE ur.KUser_Id = @UserId
--           AND ur.IsDeleted = 0
--           AND r.IsDeleted = 0
--           AND r.Name IN ('TimesYonetici', 'TimesUstYonetici')
--     )
--     OR
--     (
--         EXISTS
--         (
--             SELECT 1
--             FROM dbo.KUserRole ur
--             INNER JOIN dbo.KRole r
--                 ON r.Id = ur.KRole_Id
--             WHERE ur.KUser_Id = @UserId
--               AND ur.IsDeleted = 0
--               AND r.IsDeleted = 0
--               AND r.Name IN ('TimesMagazaMuduru', 'TimesSatisPersoneli')
--         )
--         AND EXISTS
--         (
--             SELECT 1
--             FROM tmscrq.TMUser tu
--             WHERE tu.KUserID = @UserId
--               AND tu.StoreId = l.StoreId
--         )
--     )
-- )

-- AND
-- (
--     @MusteriAdi IS NULL
--     OR LTRIM(RTRIM(@MusteriAdi)) = ''
--     OR UPPER(LTRIM(RTRIM(ISNULL(cu.Name,'') + ' ' + ISNULL(cu.LastName,''))))
--        LIKE '%' + UPPER(LTRIM(RTRIM(@MusteriAdi))) + '%'
-- )

-- AND
-- (
--     @ProductName IS NULL
--     OR LTRIM(RTRIM(@ProductName)) = ''
--     OR
--     (
--         CHARINDEX(',', @ProductName) > 0
--         AND ISNULL(LTRIM(RTRIM(p.ProductName)), '') IN
--         (
--             SELECT LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', '')))
--             FROM STRING_SPLIT(CAST(@ProductName AS NVARCHAR(MAX)), ',')
--             WHERE LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', ''))) <> ''
--         )
--     )
--     OR
--     (
--         CHARINDEX(',', @ProductName) = 0
--         AND UPPER(ISNULL(LTRIM(RTRIM(p.ProductName)), ''))
--             LIKE '%' + UPPER(LTRIM(RTRIM(@ProductName))) + '%'
--     )
-- )

-- AND
-- (
--     @LeadCode IS NULL
--     OR LTRIM(RTRIM(@LeadCode)) = ''
--     OR UPPER(ISNULL(LTRIM(RTRIM(l.LeadCode)), '')) LIKE '%' + UPPER(LTRIM(RTRIM(@LeadCode))) + '%'
-- )

-- AND
-- (
--     @Tel IS NULL
--     OR LTRIM(RTRIM(@Tel)) = ''
--     OR UPPER(ISNULL(LTRIM(RTRIM(cu.Tel)), '')) LIKE '%' + UPPER(LTRIM(RTRIM(@Tel))) + '%'
-- )

-- -- AND
-- -- (
-- --     @CategoryName IS NULL
-- --     OR LTRIM(RTRIM(@CategoryName)) = ''
-- --     OR
-- --     (
-- --         EXISTS
-- --         (
-- --             SELECT 1
-- --             FROM STRING_SPLIT(CAST(@CategoryName AS NVARCHAR(MAX)), ',') c
-- --             WHERE UPPER(LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(c.value, '""', ''), '[', ''), ']', '')))) = 'DEFAULT'
-- --         )
-- --         AND (p.CategoryName IS NULL OR LTRIM(RTRIM(p.CategoryName)) = '')
-- --     )
-- --     OR UPPER(ISNULL(LTRIM(RTRIM(p.CategoryName)), '')) IN
-- --     (
-- --         SELECT UPPER(LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', ''))))
-- --         FROM STRING_SPLIT(CAST(@CategoryName AS NVARCHAR(MAX)), ',')
-- --         WHERE LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', ''))) <> ''
-- --           AND UPPER(LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', '')))) <> 'DEFAULT'
-- --     )
-- -- )

-- AND
-- (
--     @CategoryName IS NULL
--     OR LTRIM(RTRIM(@CategoryName)) = ''
--     OR UPPER(ISNULL(LTRIM(RTRIM(p.CategoryName)), '')) IN
--     (
--         SELECT UPPER(LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value,'""',''),'[',''),']',''))))
--         FROM STRING_SPLIT(CAST(@CategoryName AS NVARCHAR(MAX)), ',')
--         WHERE LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value,'""',''),'[',''),']',''))) <> ''
--     )
-- )

-- AND
-- (
--     @StoreIds IS NULL
--     OR LTRIM(RTRIM(@StoreIds)) = ''
--     OR EXISTS
--     (
--         SELECT 1
--         FROM STRING_SPLIT(CAST(@StoreIds AS NVARCHAR(MAX)), ',') s
--         WHERE l.StoreId = TRY_CONVERT
--         (
--             uniqueidentifier,
--             LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(s.value, '""', ''), '[', ''), ']', '')))
--         )
--     )
-- )

-- AND
-- (
--     @SatisDanismaniIds IS NULL
--     OR LTRIM(RTRIM(@SatisDanismaniIds)) = ''
--     OR EXISTS
--     (
--         SELECT 1
--         FROM STRING_SPLIT(CAST(@SatisDanismaniIds AS NVARCHAR(MAX)), ',') s
--         WHERE l.SalesPersonKUserId = TRY_CONVERT
--         (
--             uniqueidentifier,
--             LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(s.value, '""', ''), '[', ''), ']', '')))
--         )
--     )
-- )

-- AND
-- (
--     @ProcessCode IS NULL
--     OR LTRIM(RTRIM(@ProcessCode)) = ''
--     OR UPPER(ISNULL(LTRIM(RTRIM(lp.Code)), '')) IN
--     (
--         SELECT UPPER(LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', ''))))
--         FROM STRING_SPLIT(CAST(@ProcessCode AS NVARCHAR(MAX)), ',')
--         WHERE LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', ''))) <> ''
--     )
-- )

-- AND
-- (
--     @StepOrder IS NULL

--     OR
--     (
--         @StepOrder = 10
--         AND EXISTS
--         (
--             SELECT 1
--             FROM tmscrq.TMLeadReservation r
--             WHERE r.LeadId = l.Id
--               AND r.IsActive = 1
--               AND ISNULL(r.IsApproved,0) = 0
--         )
--     )

--     OR
--     (
--         @StepOrder <> 10
--         AND lp.StepOrder = @StepOrder
--     )
-- )

-- AND
-- (
--     @StartDate IS NULL
--     OR LTRIM(RTRIM(@StartDate)) = ''
--     OR l.CreatedAt >= CONVERT(date, @StartDate)
-- )

-- AND
-- (
--     @EndDate IS NULL
--     OR LTRIM(RTRIM(@EndDate)) = ''
--     OR l.CreatedAt < DATEADD(day, 1, CONVERT(date, @EndDate))
-- )

-- ORDER BY l.CreatedAt DESC;

------------------------++++++++++++++++++++++++-------------------
-- SET LANGUAGE Turkish;

-- SELECT
-- CASE 
--     WHEN EXISTS (
--         SELECT 1 
--         FROM tmscrq.TMLeadReservation r
--         WHERE r.LeadId = l.Id
--           AND r.IsActive = 1
--           AND r.IsApproved = 1
--     ) THEN N'Evet'

--     WHEN EXISTS (
--         SELECT 1 
--         FROM tmscrq.TMLeadReservation r
--         WHERE r.LeadId = l.Id
--           AND r.IsActive = 1
--           AND ISNULL(r.IsApproved,0) = 0
--     ) THEN N'Onay Bekliyor'

--     ELSE N'Hayır'
-- END AS RezerveDurumu,
--     l.Id AS LeadId,
--     l.IsReserved,
--     ISNULL(NULLIF(LTRIM(RTRIM(l.LeadCode)), ''), '-') AS LeadNumarasi,
--     CONVERT(varchar(10), l.CreatedAt, 103) AS TalepTarihi,

--     p.Id AS ProductId,
--     ISNULL(NULLIF(LTRIM(RTRIM(p.ProductName)), ''), '-') AS ProductName,
--     ISNULL(NULLIF(LTRIM(RTRIM(p.Bracelet)), ''), '-') AS Bilezik,
--     ISNULL(NULLIF(LTRIM(RTRIM(p.Brand)), ''), '-') AS Brand,
--     ISNULL(NULLIF(LTRIM(RTRIM(p.Dial)), ''), '-') AS Kadran,
--     ISNULL(NULLIF(LTRIM(RTRIM(p.ProductCode)), ''), '-') AS RefCode,
--     ISNULL(NULLIF(LTRIM(RTRIM(p.Referance)), ''), '-') AS Referans,

--     ISNULL(
--         NULLIF(
--             LTRIM(RTRIM(ISNULL(cu.Name, '') + ' ' + ISNULL(cu.LastName, '')))
--         , '')
--     , '-') AS Musteri,

--     ISNULL(NULLIF(LTRIM(RTRIM(cu.CityName)), ''), '-') AS Lokasyon,
--     ISNULL(NULLIF(LTRIM(RTRIM(cu.DistrictName)), ''), '-') AS Ilce,
--     ISNULL(NULLIF(LTRIM(RTRIM(cu.CountryName)), ''), '-') AS Ulke,
--     ISNULL(NULLIF(LTRIM(RTRIM(cu.Info)), ''), '-') AS MusteriInfo,

--     CASE
--         WHEN cu.IsShopping = 1 THEN N'Evet'
--         WHEN cu.IsShopping = 0 THEN N'Hayır'
--         ELSE '-'
--     END AS AlisverisiVarMi,

--     ISNULL(NULLIF(LTRIM(RTRIM(cu.Tel)), ''), '-') AS IrtibatNumarasi,
--     ISNULL(NULLIF(LTRIM(RTRIM(cu.Email)), ''), '-') AS EmailAdresi,

--     ISNULL(NULLIF(LTRIM(RTRIM(cr.ContactResourceName)), ''), '-') AS IletisimKaynagi,

--     ISNULL(NULLIF(LTRIM(RTRIM(p.CategoryName)), ''), '-') AS CategoryName,
--     '-' AS CategoryCode,

--     ISNULL(NULLIF(LTRIM(RTRIM(ls.Name)), ''), '-') AS LeadDurumu,
--     ISNULL(NULLIF(LTRIM(RTRIM(ns.Name)), ''), '-') AS SonrakiAdim,

--     ISNULL(NULLIF(LTRIM(RTRIM(lp.Name)), ''), '-') AS ProcessName,
--     ISNULL(NULLIF(LTRIM(RTRIM(lp.Code)), ''), '-') AS ProcessCode,
--     lp.StepOrder,
    
--     -- DÜZELTİLEN ALAN: SelectedStepOrder
--     CASE
--         WHEN EXISTS
--         (
--             SELECT 1
--             FROM tmscrq.TMLeadReservation r
--             WHERE r.LeadId = l.Id
--               AND r.IsActive = 1
--               AND ISNULL(r.IsApproved,0) = 0
--         )
--         THEN 10
--         ELSE lp.StepOrder
--     END AS SelectedStepOrder,

--     ISNULL(
--         CASE
--             WHEN l.EstimatedDate IS NOT NULL
--             THEN CAST(YEAR(l.EstimatedDate) AS VARCHAR(4)) + ' ' + DATENAME(MONTH, l.EstimatedDate)
--             ELSE NULL
--         END,
--         '-'
--     ) AS TerminTarihi,

--     ISNULL(
--         NULLIF(
--             LTRIM(RTRIM(ISNULL(sp.FirstName, '') + ' ' + ISNULL(sp.LastName, '')))
--         , '')
--     , '-') AS SatisDanismani,

--     ISNULL(NULLIF(LTRIM(RTRIM(st.StoreDesc)), ''), '-') AS StoreName

-- FROM tmscrq.TMLead l
-- LEFT JOIN tmscrq.TMLeadStatu ls
--     ON ls.Id = l.StatuId
-- LEFT JOIN tmscrq.TMCustomer cu
--     ON cu.Id = l.CustomerId
-- LEFT JOIN tmscrq.TMProduct p
--     ON p.Id = l.ProductId
-- LEFT JOIN tmscrq.TMContactResource cr
--     ON cr.Id = l.ContactResourceId
-- LEFT JOIN dbo.KUser sp
--     ON sp.Id = l.SalesPersonKUserId
-- LEFT JOIN tmscrq.TMStore st
--     ON st.Id = l.StoreId
-- LEFT JOIN tmscrq.TMLeadProcess lp
--     ON lp.Id = l.ProcessID
-- LEFT JOIN tmscrq.TMLeadNextStep ns
--     ON ns.Id = l.NextStepId

-- WHERE
-- (
--     EXISTS
--     (
--         SELECT 1
--         FROM dbo.KUserRole ur
--         INNER JOIN dbo.KRole r
--             ON r.Id = ur.KRole_Id
--         WHERE ur.KUser_Id = @UserId
--           AND ur.IsDeleted = 0
--           AND r.IsDeleted = 0
--           AND r.Name IN ('TimesYonetici', 'TimesUstYonetici')
--     )
--     OR
--     (
--         EXISTS
--         (
--             SELECT 1
--             FROM dbo.KUserRole ur
--             INNER JOIN dbo.KRole r
--                 ON r.Id = ur.KRole_Id
--             WHERE ur.KUser_Id = @UserId
--               AND ur.IsDeleted = 0
--               AND r.IsDeleted = 0
--               AND r.Name IN ('TimesMagazaMuduru', 'TimesSatisPersoneli')
--         )
--         AND EXISTS
--         (
--             SELECT 1
--             FROM tmscrq.TMUser tu
--             WHERE tu.KUserID = @UserId
--               AND tu.StoreId = l.StoreId
--         )
--     )
-- )

-- AND
-- (
--     @MusteriAdi IS NULL
--     OR LTRIM(RTRIM(@MusteriAdi)) = ''
--     OR UPPER(LTRIM(RTRIM(ISNULL(cu.Name,'') + ' ' + ISNULL(cu.LastName,''))))
--        LIKE '%' + UPPER(LTRIM(RTRIM(@MusteriAdi))) + '%'
-- )

-- AND
-- (
--     @ProductName IS NULL
--     OR LTRIM(RTRIM(@ProductName)) = ''
--     OR
--     (
--         CHARINDEX(',', @ProductName) > 0
--         AND ISNULL(LTRIM(RTRIM(p.ProductName)), '') IN
--         (
--             SELECT LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', '')))
--             FROM STRING_SPLIT(CAST(@ProductName AS NVARCHAR(MAX)), ',')
--             WHERE LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', ''))) <> ''
--         )
--     )
--     OR
--     (
--         CHARINDEX(',', @ProductName) = 0
--         AND UPPER(ISNULL(LTRIM(RTRIM(p.ProductName)), ''))
--             LIKE '%' + UPPER(LTRIM(RTRIM(@ProductName))) + '%'
--     )
-- )

-- AND
-- (
--     @LeadCode IS NULL
--     OR LTRIM(RTRIM(@LeadCode)) = ''
--     OR UPPER(ISNULL(LTRIM(RTRIM(l.LeadCode)), '')) LIKE '%' + UPPER(LTRIM(RTRIM(@LeadCode))) + '%'
-- )

-- AND
-- (
--     @Tel IS NULL
--     OR LTRIM(RTRIM(@Tel)) = ''
--     OR UPPER(ISNULL(LTRIM(RTRIM(cu.Tel)), '')) LIKE '%' + UPPER(LTRIM(RTRIM(@Tel))) + '%'
-- )

-- AND
-- (
--     @CategoryName IS NULL
--     OR LTRIM(RTRIM(@CategoryName)) = ''
--     OR UPPER(ISNULL(LTRIM(RTRIM(p.CategoryName)), '')) IN
--     (
--         SELECT UPPER(LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value,'""',''),'[',''),']',''))))
--         FROM STRING_SPLIT(CAST(@CategoryName AS NVARCHAR(MAX)), ',')
--         WHERE LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value,'""',''),'[',''),']',''))) <> ''
--     )
-- )

-- AND
-- (
--     @StoreIds IS NULL
--     OR LTRIM(RTRIM(@StoreIds)) = ''
--     OR EXISTS
--     (
--         SELECT 1
--         FROM STRING_SPLIT(CAST(@StoreIds AS NVARCHAR(MAX)), ',') s
--         WHERE l.StoreId = TRY_CONVERT
--         (
--             uniqueidentifier,
--             LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(s.value, '""', ''), '[', ''), ']', '')))
--         )
--     )
-- )

-- AND
-- (
--     @SatisDanismaniIds IS NULL
--     OR LTRIM(RTRIM(@SatisDanismaniIds)) = ''
--     OR EXISTS
--     (
--         SELECT 1
--         FROM STRING_SPLIT(CAST(@SatisDanismaniIds AS NVARCHAR(MAX)), ',') s
--         WHERE l.SalesPersonKUserId = TRY_CONVERT
--         (
--             uniqueidentifier,
--             LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(s.value, '""', ''), '[', ''), ']', '')))
--         )
--     )
-- )

-- AND
-- (
--     @ProcessCode IS NULL
--     OR LTRIM(RTRIM(@ProcessCode)) = ''
--     OR UPPER(ISNULL(LTRIM(RTRIM(lp.Code)), '')) IN
--     (
--         SELECT UPPER(LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', ''))))
--         FROM STRING_SPLIT(CAST(@ProcessCode AS NVARCHAR(MAX)), ',')
--         WHERE LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', ''))) <> ''
--     )
-- )

-- -- DÜZELTİLEN ALAN: @StepOrder Filtresi (tek blok)
-- AND
-- (
--     @StepOrder IS NULL

--     OR

--     (
--         @StepOrder = 10
--         AND EXISTS
--         (
--             SELECT 1
--             FROM tmscrq.TMLeadReservation r
--             WHERE r.LeadId = l.Id
--               AND r.IsActive = 1
--               AND ISNULL(r.IsApproved,0) = 0
--         )
--     )

--     OR

--     (
--         @StepOrder <> 10
--         AND lp.StepOrder = @StepOrder
--     )
-- )

-- AND
-- (
--     @StartDate IS NULL
--     OR LTRIM(RTRIM(@StartDate)) = ''
--     OR l.CreatedAt >= CONVERT(date, @StartDate)
-- )

-- AND
-- (
--     @EndDate IS NULL
--     OR LTRIM(RTRIM(@EndDate)) = ''
--     OR l.CreatedAt < DATEADD(day, 1, CONVERT(date, @EndDate))
-- )

-- ORDER BY l.CreatedAt DESC;



SET LANGUAGE Turkish;

SELECT
CASE 
    WHEN EXISTS (
        SELECT 1 
        FROM tmscrq.TMLeadReservation r
        WHERE r.LeadId = l.Id
          AND r.IsActive = 1
          AND r.IsApproved = 1
    ) THEN N'Evet'

    WHEN EXISTS (
        SELECT 1 
        FROM tmscrq.TMLeadReservation r
        WHERE r.LeadId = l.Id
          AND r.IsActive = 1
          AND ISNULL(r.IsApproved,0) = 0
    ) THEN N'Onay Bekliyor'

    ELSE N'Hayır'
END AS RezerveDurumu,
    l.Id AS LeadId,
    l.IsReserved,
    ISNULL(NULLIF(LTRIM(RTRIM(l.LeadCode)), ''), '-') AS LeadNumarasi,
     FORMAT(l.CreatedAt, 'dd MMMM yyyy', 'tr-TR') AS TalepTarihi,

    p.Id AS ProductId,
    ISNULL(NULLIF(LTRIM(RTRIM(p.ProductName)), ''), '-') AS ProductName,
    ISNULL(NULLIF(LTRIM(RTRIM(p.Bracelet)), ''), '-') AS Bilezik,
    ISNULL(NULLIF(LTRIM(RTRIM(p.Brand)), ''), '-') AS Brand,
    ISNULL(NULLIF(LTRIM(RTRIM(p.Dial)), ''), '-') AS Kadran,
    ISNULL(NULLIF(LTRIM(RTRIM(p.ProductCode)), ''), '-') AS RefCode,
    ISNULL(NULLIF(LTRIM(RTRIM(p.Referance)), ''), '-') AS Referans,

    ISNULL(
        NULLIF(
            LTRIM(RTRIM(ISNULL(cu.Name, '') + ' ' + ISNULL(cu.LastName, '')))
        , '')
    , '-') AS Musteri,

    ISNULL(NULLIF(LTRIM(RTRIM(cu.CityName)), ''), '-') AS Lokasyon,
    ISNULL(NULLIF(LTRIM(RTRIM(cu.DistrictName)), ''), '-') AS Ilce,
    ISNULL(NULLIF(LTRIM(RTRIM(cu.CountryName)), ''), '-') AS Ulke,
    ISNULL(NULLIF(LTRIM(RTRIM(cu.Info)), ''), '-') AS MusteriInfo,

    CASE
        WHEN cu.IsShopping = 1 THEN N'Evet'
        WHEN cu.IsShopping = 0 THEN N'Hayır'
        ELSE '-'
    END AS AlisverisiVarMi,

    ISNULL(NULLIF(LTRIM(RTRIM(cu.Tel)), ''), '-') AS IrtibatNumarasi,
    ISNULL(NULLIF(LTRIM(RTRIM(cu.Email)), ''), '-') AS EmailAdresi,

    ISNULL(NULLIF(LTRIM(RTRIM(cr.ContactResourceName)), ''), '-') AS IletisimKaynagi,

    ISNULL(NULLIF(LTRIM(RTRIM(p.CategoryName)), ''), '-') AS CategoryName,
    '-' AS CategoryCode,

    ISNULL(NULLIF(LTRIM(RTRIM(ls.Name)), ''), '-') AS LeadDurumu,
    ISNULL(NULLIF(LTRIM(RTRIM(ns.Name)), ''), '-') AS SonrakiAdim,

    ISNULL(NULLIF(LTRIM(RTRIM(lp.Name)), ''), '-') AS ProcessName,
    ISNULL(NULLIF(LTRIM(RTRIM(lp.Code)), ''), '-') AS ProcessCode,
    lp.StepOrder,
    
    -- DÜZELTİLEN ALAN: SelectedStepOrder
    CASE
        WHEN EXISTS
        (
            SELECT 1
            FROM tmscrq.TMLeadReservation r
            WHERE r.LeadId = l.Id
              AND r.IsActive = 1
              AND ISNULL(r.IsApproved,0) = 0
        )
        THEN 10
        ELSE lp.StepOrder
    END AS SelectedStepOrder,

    ISNULL(
        CASE
            WHEN l.EstimatedDate IS NOT NULL
            THEN CAST(YEAR(l.EstimatedDate) AS VARCHAR(4)) + ' ' + DATENAME(MONTH, l.EstimatedDate)
            ELSE NULL
        END,
        '-'
    ) AS TerminTarihi,

    ISNULL(
        NULLIF(
            LTRIM(RTRIM(ISNULL(sp.FirstName, '') + ' ' + ISNULL(sp.LastName, '')))
        , '')
    , '-') AS SatisDanismani,

    ISNULL(NULLIF(LTRIM(RTRIM(st.StoreDesc)), ''), '-') AS StoreName

FROM tmscrq.TMLead l
LEFT JOIN tmscrq.TMLeadStatu ls
    ON ls.Id = l.StatuId
LEFT JOIN tmscrq.TMCustomer cu
    ON cu.Id = l.CustomerId
LEFT JOIN tmscrq.TMProduct p
    ON p.Id = l.ProductId
LEFT JOIN tmscrq.TMContactResource cr
    ON cr.Id = l.ContactResourceId
LEFT JOIN dbo.KUser sp
    ON sp.Id = l.SalesPersonKUserId
LEFT JOIN tmscrq.TMStore st
    ON st.Id = l.StoreId
LEFT JOIN tmscrq.TMLeadProcess lp
    ON lp.Id = l.ProcessID
LEFT JOIN tmscrq.TMLeadNextStep ns
    ON ns.Id = l.NextStepId

WHERE
(
    EXISTS
    (
        SELECT 1
        FROM dbo.KUserRole ur
        INNER JOIN dbo.KRole r
            ON r.Id = ur.KRole_Id
        WHERE ur.KUser_Id = @UserId
          AND ur.IsDeleted = 0
          AND r.IsDeleted = 0
          AND r.Name IN ('TimesYonetici', 'TimesUstYonetici')
    )
    OR
    (
        EXISTS
        (
            SELECT 1
            FROM dbo.KUserRole ur
            INNER JOIN dbo.KRole r
                ON r.Id = ur.KRole_Id
            WHERE ur.KUser_Id = @UserId
              AND ur.IsDeleted = 0
              AND r.IsDeleted = 0
              AND r.Name IN ('TimesMagazaMuduru', 'TimesSatisPersoneli')
        )
        AND EXISTS
        (
            SELECT 1
            FROM tmscrq.TMUser tu
            WHERE tu.KUserID = @UserId
              AND tu.StoreId = l.StoreId
        )
    )
)

AND
(
    ISNULL(@MusteriAdi, '') = ''
    OR UPPER(ISNULL(cu.Name, '')) LIKE '%' + UPPER(LTRIM(RTRIM(@MusteriAdi))) + '%'
    OR UPPER(ISNULL(cu.LastName, '')) LIKE '%' + UPPER(LTRIM(RTRIM(@MusteriAdi))) + '%'
    OR UPPER(
        ISNULL(cu.Name, '') + ' ' + ISNULL(cu.LastName, '')
    ) LIKE '%' + UPPER(LTRIM(RTRIM(@MusteriAdi))) + '%'
)

AND
(
    @ProductName IS NULL
    OR LTRIM(RTRIM(@ProductName)) = ''
    OR
    (
        CHARINDEX(',', @ProductName) > 0
        AND ISNULL(LTRIM(RTRIM(p.ProductName)), '') IN
        (
            SELECT LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', '')))
            FROM STRING_SPLIT(CAST(@ProductName AS NVARCHAR(MAX)), ',')
            WHERE LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', ''))) <> ''
        )
    )
    OR
    (
        CHARINDEX(',', @ProductName) = 0
        AND UPPER(ISNULL(LTRIM(RTRIM(p.ProductName)), ''))
            LIKE '%' + UPPER(LTRIM(RTRIM(@ProductName))) + '%'
    )
)

AND
(
    ISNULL(@LeadCode, '') = ''
    OR UPPER(ISNULL(l.LeadCode, ''))
        LIKE '%' + UPPER(LTRIM(RTRIM(@LeadCode))) + '%'
    OR REPLACE(
        REPLACE(
            REPLACE(
                UPPER(ISNULL(l.LeadCode, '')),
                '-', ''
            ),
            ' ', ''
        ),
        '/', ''
    )
    LIKE '%' +
    REPLACE(
        REPLACE(
            REPLACE(
                UPPER(LTRIM(RTRIM(@LeadCode))),
                '-', ''
            ),
            ' ', ''
        ),
        '/', ''
    )
    + '%'
)

AND
(
    @Tel IS NULL
    OR LTRIM(RTRIM(@Tel)) = ''
    OR UPPER(ISNULL(LTRIM(RTRIM(cu.Tel)), '')) LIKE '%' + UPPER(LTRIM(RTRIM(@Tel))) + '%'
)

AND
(
    @CategoryName IS NULL
    OR LTRIM(RTRIM(@CategoryName)) = ''
    OR UPPER(ISNULL(LTRIM(RTRIM(p.CategoryName)), '')) IN
    (
        SELECT UPPER(LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value,'""',''),'[',''),']',''))))
        FROM STRING_SPLIT(CAST(@CategoryName AS NVARCHAR(MAX)), ',')
        WHERE LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value,'""',''),'[',''),']',''))) <> ''
    )
)

AND
(
    @StoreIds IS NULL
    OR LTRIM(RTRIM(@StoreIds)) = ''
    OR EXISTS
    (
        SELECT 1
        FROM STRING_SPLIT(CAST(@StoreIds AS NVARCHAR(MAX)), ',') s
        WHERE l.StoreId = TRY_CONVERT
        (
            uniqueidentifier,
            LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(s.value, '""', ''), '[', ''), ']', '')))
        )
    )
)

AND
(
    @SatisDanismaniIds IS NULL
    OR LTRIM(RTRIM(@SatisDanismaniIds)) = ''
    OR EXISTS
    (
        SELECT 1
        FROM STRING_SPLIT(CAST(@SatisDanismaniIds AS NVARCHAR(MAX)), ',') s
        WHERE l.SalesPersonKUserId = TRY_CONVERT
        (
            uniqueidentifier,
            LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(s.value, '""', ''), '[', ''), ']', '')))
        )
    )
)

AND
(
    ISNULL(@ProcessCode, '') = ''
    OR EXISTS
    (
        SELECT 1
        FROM STRING_SPLIT(
            CONVERT(NVARCHAR(MAX), @ProcessCode),
            ','
        ) AS s
        WHERE
            UPPER(LTRIM(RTRIM(s.value))) =
            UPPER(LTRIM(RTRIM(ISNULL(lp.Code, ''))))
    )
)

-- DÜZELTİLEN ALAN: @StepOrder Filtresi (0 verilince tümü gelsin)
AND
(
    @StepOrder IS NULL
    OR @StepOrder = 0  -- 👈 YENİ EKLENDI: 0 verilince tüm kayıtlar gelir
    OR
    (
        @StepOrder = 10
        AND EXISTS
        (
            SELECT 1
            FROM tmscrq.TMLeadReservation r
            WHERE r.LeadId = l.Id
              AND r.IsActive = 1
              AND ISNULL(r.IsApproved,0) = 0
        )
    )
    OR
    (
        @StepOrder <> 10
        AND lp.StepOrder = @StepOrder
    )
)

AND
(
    @StartDate IS NULL
    OR LTRIM(RTRIM(@StartDate)) = ''
    OR l.CreatedAt >= CONVERT(date, @StartDate)
)

AND
(
    @EndDate IS NULL
    OR LTRIM(RTRIM(@EndDate)) = ''
    OR l.CreatedAt < DATEADD(day, 1, CONVERT(date, @EndDate))
)

ORDER BY l.CreatedAt DESC;", new string[] { "RezerveDurumu", "LeadId", "IsReserved", "LeadNumarasi", "TalepTarihi", "ProductId", "ProductName", "Bilezik", "Brand", "Kadran", "RefCode", "Referans", "Musteri", "Lokasyon", "Ilce", "Ulke", "MusteriInfo", "AlisverisiVarMi", "IrtibatNumarasi", "EmailAdresi", "IletisimKaynagi", "CategoryName", "CategoryCode", "LeadDurumu", "SonrakiAdim", "ProcessName", "ProcessCode", "StepOrder", "SelectedStepOrder", "TerminTarihi", "SatisDanismani", "StoreName" }, prms_TM_GetLeads_0.ToArray());
            ;

            var prms_TMLeadProcessCountSummary_1 = new List<kSqlParameter>();
            prms_TMLeadProcessCountSummary_1.Add(new kSqlParameter() { Name = "UserId", Value = Kuika.Common.KContext.CurrentUser?.Id });
            prms_TMLeadProcessCountSummary_1.Add(new kSqlParameter() { Name = "MusteriAdi", Value = request.MusteriAdi_1 });
            prms_TMLeadProcessCountSummary_1.Add(new kSqlParameter() { Name = "ProductName", Value = request.ProductName_1 });
            prms_TMLeadProcessCountSummary_1.Add(new kSqlParameter() { Name = "LeadCode", Value = request.LeadCode_1 });
            prms_TMLeadProcessCountSummary_1.Add(new kSqlParameter() { Name = "Tel", Value = request.Tel_1 });
            prms_TMLeadProcessCountSummary_1.Add(new kSqlParameter() { Name = "CategoryName", Value = request.CategoryName_1 });
            prms_TMLeadProcessCountSummary_1.Add(new kSqlParameter() { Name = "StoreIds", Value = request.StoreIds_1 });
            prms_TMLeadProcessCountSummary_1.Add(new kSqlParameter() { Name = "SatisDanismaniIds", Value = request.SatisDanismaniIds_1 });
            prms_TMLeadProcessCountSummary_1.Add(new kSqlParameter() { Name = "ProcessCode", Value = request.ProcessCode_1 });
            prms_TMLeadProcessCountSummary_1.Add(new kSqlParameter() { Name = "StartDate", Value = request.StartDate_1 });
            prms_TMLeadProcessCountSummary_1.Add(new kSqlParameter() { Name = "EndDate", Value = request.EndDate_1 });
            using var auditTMLeadProcessCountSummary_1 = ActionAuditScope.Begin("58004845-31fd-c1d0-e4f9-a02a8cce4b06", "TMLeadProcessCountSummary", applicationName: "wbTimesCRM", screenOrEndpointName: "LeadList");
            result.TMLeadProcessCountSummary = KPersister.Fetch(KContext.GetConnectionString(), @"-- SELECT
--     COUNT(*) AS ToplamTalepSayisi,

--     SUM(CASE WHEN lp.Code = 'PENDING' THEN 1 ELSE 0 END) AS OnayBekleyenSayisi,
--     SUM(CASE WHEN lp.Code = 'TERMIN_PENDING' THEN 1 ELSE 0 END) AS TerminBekleyenSayisi,
--     SUM(CASE WHEN lp.Code = 'APPROVED' THEN 1 ELSE 0 END) AS OnaylananSayisi,
--     SUM(CASE WHEN lp.Code = 'REJECTED' THEN 1 ELSE 0 END) AS ReddedilenSayisi,
--     SUM(CASE WHEN lp.Code = 'DELIVERY_PENDING' THEN 1 ELSE 0 END) AS TeslimEdilecekSayisi,
--     SUM(CASE WHEN lp.Code = 'DELIVERED' THEN 1 ELSE 0 END) AS TeslimEdildiSayisi

-- FROM tmscrq.TMLead l
-- LEFT JOIN tmscrq.TMCustomer cu
--     ON cu.Id = l.CustomerId
-- LEFT JOIN tmscrq.TMProduct p
--     ON p.Id = l.ProductId
-- LEFT JOIN dbo.KUser sp
--     ON sp.Id = l.SalesPersonKUserId
-- LEFT JOIN tmscrq.TMLeadProcess lp
--     ON lp.Id = l.ProcessID

-- WHERE
-- (
--     EXISTS
--     (
--         SELECT 1
--         FROM dbo.KUserRole ur
--         INNER JOIN dbo.KRole r
--             ON r.Id = ur.KRole_Id
--         WHERE ur.KUser_Id = @UserId
--           AND ur.IsDeleted = 0
--           AND r.IsDeleted = 0
--           AND r.Name IN ('TimesYonetici', 'TimesUstYonetici')
--     )
--     OR
--     (
--         EXISTS
--         (
--             SELECT 1
--             FROM dbo.KUserRole ur
--             INNER JOIN dbo.KRole r
--                 ON r.Id = ur.KRole_Id
--             WHERE ur.KUser_Id = @UserId
--               AND ur.IsDeleted = 0
--               AND r.IsDeleted = 0
--               AND r.Name IN ('TimesMagazaMuduru', 'TimesSatisPersoneli')
--         )
--         AND EXISTS
--         (
--             SELECT 1
--             FROM tmscrq.TMUser tu
--             WHERE tu.KUserID = @UserId
--               AND tu.StoreId = l.StoreId
--         )
--     )
-- )

-- AND
-- (
--     @MusteriAdi IS NULL
--     OR LTRIM(RTRIM(@MusteriAdi)) = ''
--     OR UPPER(LTRIM(RTRIM(ISNULL(cu.Name, '') + ' ' + ISNULL(cu.LastName, ''))))
--        LIKE '%' + UPPER(LTRIM(RTRIM(@MusteriAdi))) + '%'
-- )

-- AND
-- (
--     @ProductName IS NULL
--     OR LTRIM(RTRIM(@ProductName)) = ''
--     OR
--     (
--         CHARINDEX(',', @ProductName) > 0
--         AND ISNULL(LTRIM(RTRIM(p.ProductName)), '') IN
--         (
--             SELECT LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', '')))
--             FROM STRING_SPLIT(CAST(@ProductName AS NVARCHAR(MAX)), ',')
--             WHERE LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', ''))) <> ''
--         )
--     )
--     OR
--     (
--         CHARINDEX(',', @ProductName) = 0
--         AND UPPER(ISNULL(LTRIM(RTRIM(p.ProductName)), ''))
--             LIKE '%' + UPPER(LTRIM(RTRIM(@ProductName))) + '%'
--     )
-- )

-- AND
-- (
--     @LeadCode IS NULL
--     OR LTRIM(RTRIM(@LeadCode)) = ''
--     OR UPPER(ISNULL(LTRIM(RTRIM(l.LeadCode)), '')) LIKE '%' + UPPER(LTRIM(RTRIM(@LeadCode))) + '%'
-- )

-- AND
-- (
--     @Tel IS NULL
--     OR LTRIM(RTRIM(@Tel)) = ''
--     OR UPPER(ISNULL(LTRIM(RTRIM(cu.Tel)), '')) LIKE '%' + UPPER(LTRIM(RTRIM(@Tel))) + '%'
-- )

-- AND
-- (
--     @CategoryName IS NULL
--     OR LTRIM(RTRIM(@CategoryName)) = ''
--     OR
--     (
--         EXISTS
--         (
--             SELECT 1
--             FROM STRING_SPLIT(CAST(@CategoryName AS NVARCHAR(MAX)), ',') c
--             WHERE UPPER(LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(c.value, '""', ''), '[', ''), ']', '')))) = 'DEFAULT'
--         )
--         AND (p.CategoryName IS NULL OR LTRIM(RTRIM(p.CategoryName)) = '')
--     )
--     OR UPPER(ISNULL(LTRIM(RTRIM(p.CategoryName)), '')) IN
--     (
--         SELECT UPPER(LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', ''))))
--         FROM STRING_SPLIT(CAST(@CategoryName AS NVARCHAR(MAX)), ',')
--         WHERE LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', ''))) <> ''
--           AND UPPER(LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', '')))) <> 'DEFAULT'
--     )
-- )

-- AND
-- (
--     @StoreIds IS NULL
--     OR LTRIM(RTRIM(@StoreIds)) = ''
--     OR EXISTS
--     (
--         SELECT 1
--         FROM STRING_SPLIT(CAST(@StoreIds AS NVARCHAR(MAX)), ',') s
--         WHERE l.StoreId = TRY_CONVERT
--         (
--             uniqueidentifier,
--             LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(s.value, '""', ''), '[', ''), ']', '')))
--         )
--     )
-- )

-- AND
-- (
--     @SatisDanismaniIds IS NULL
--     OR LTRIM(RTRIM(@SatisDanismaniIds)) = ''
--     OR EXISTS
--     (
--         SELECT 1
--         FROM STRING_SPLIT(CAST(@SatisDanismaniIds AS NVARCHAR(MAX)), ',') s
--         WHERE l.SalesPersonKUserId = TRY_CONVERT
--         (
--             uniqueidentifier,
--             LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(s.value, '""', ''), '[', ''), ']', '')))
--         )
--     )
-- )

-- AND
-- (
--     @ProcessCode IS NULL
--     OR LTRIM(RTRIM(@ProcessCode)) = ''
--     OR UPPER(ISNULL(LTRIM(RTRIM(lp.Code)), '')) IN
--     (
--         SELECT UPPER(LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', ''))))
--         FROM STRING_SPLIT(CAST(@ProcessCode AS NVARCHAR(MAX)), ',')
--         WHERE LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', ''))) <> ''
--     )
-- )

-- AND
-- (
--     @StartDate IS NULL
--     OR LTRIM(RTRIM(@StartDate)) = ''
--     OR l.CreatedAt >= CONVERT(date, @StartDate)
-- )

-- AND
-- (
--     @EndDate IS NULL
--     OR LTRIM(RTRIM(@EndDate)) = ''
--     OR l.CreatedAt < DATEADD(day, 1, CONVERT(date, @EndDate))
-- );

-------------------------------------------------------------

DECLARE @KUserId UNIQUEIDENTIFIER = @UserId;

WITH UserRoles AS (
    SELECT r.Name
    FROM dbo.KUserRole ur
    INNER JOIN dbo.KRole r 
        ON r.Id = ur.KRole_Id
    WHERE ur.KUser_Id = @KUserId
      AND ur.IsDeleted = 0
      AND r.IsDeleted = 0
),
IsAdmin AS (
    SELECT CASE 
        WHEN EXISTS (
            SELECT 1 
            FROM UserRoles 
            WHERE Name = 'TimesUstYonetici'
        ) THEN 1 ELSE 0 END AS IsAdmin
)

SELECT
    COUNT(*) AS ToplamTalepSayisi,

    SUM(CASE WHEN lp.Code = 'PENDING' THEN 1 ELSE 0 END) AS OnayBekleyenSayisi,
    SUM(CASE WHEN lp.Code = 'TERMIN_PENDING' THEN 1 ELSE 0 END) AS TerminBekleyenSayisi,
    SUM(CASE WHEN lp.Code = 'APPROVED' THEN 1 ELSE 0 END) AS OnaylananSayisi,
    SUM(CASE WHEN lp.Code = 'REJECTED' THEN 1 ELSE 0 END) AS ReddedilenSayisi,
    SUM(CASE WHEN lp.Code = 'DELIVERY_PENDING' THEN 1 ELSE 0 END) AS TeslimEdilecekSayisi,
    SUM(CASE WHEN lp.Code = 'DELIVERED' THEN 1 ELSE 0 END) AS TeslimEdildiSayisi

FROM tmscrq.TMLead l
LEFT JOIN tmscrq.TMCustomer cu
    ON cu.Id = l.CustomerId
LEFT JOIN tmscrq.TMProduct p
    ON p.Id = l.ProductId
LEFT JOIN dbo.KUser sp
    ON sp.Id = l.SalesPersonKUserId
LEFT JOIN tmscrq.TMLeadProcess lp
    ON lp.Id = l.ProcessID

CROSS JOIN IsAdmin a

WHERE
(
    -- admin → full
    a.IsAdmin = 1

    -- diğerleri → sadece kendi mağazaları
    OR EXISTS
    (
        SELECT 1
        FROM tmscrq.TMUser tu
        WHERE tu.KUserID = @KUserId
          AND tu.StoreId = l.StoreId
    )
)

-- 🔽 AŞAĞISI SENİN ORİJİNAL FİLTRELER (HİÇ DOKUNMADIM)

AND
(
    @MusteriAdi IS NULL
    OR LTRIM(RTRIM(@MusteriAdi)) = ''
    OR UPPER(LTRIM(RTRIM(ISNULL(cu.Name, '') + ' ' + ISNULL(cu.LastName, ''))))
       LIKE '%' + UPPER(LTRIM(RTRIM(@MusteriAdi))) + '%'
)

AND
(
    @ProductName IS NULL
    OR LTRIM(RTRIM(@ProductName)) = ''
    OR
    (
        CHARINDEX(',', @ProductName) > 0
        AND ISNULL(LTRIM(RTRIM(p.ProductName)), '') IN
        (
            SELECT LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', '')))
            FROM STRING_SPLIT(CAST(@ProductName AS NVARCHAR(MAX)), ',')
        )
    )
    OR
    (
        CHARINDEX(',', @ProductName) = 0
        AND UPPER(ISNULL(LTRIM(RTRIM(p.ProductName)), ''))
            LIKE '%' + UPPER(LTRIM(RTRIM(@ProductName))) + '%'
    )
)

AND
(
    @LeadCode IS NULL
    OR LTRIM(RTRIM(@LeadCode)) = ''
    OR UPPER(ISNULL(LTRIM(RTRIM(l.LeadCode)), '')) LIKE '%' + UPPER(LTRIM(RTRIM(@LeadCode))) + '%'
)

AND
(
    @Tel IS NULL
    OR LTRIM(RTRIM(@Tel)) = ''
    OR UPPER(ISNULL(LTRIM(RTRIM(cu.Tel)), '')) LIKE '%' + UPPER(LTRIM(RTRIM(@Tel))) + '%'
)

AND
(
    @CategoryName IS NULL
    OR LTRIM(RTRIM(@CategoryName)) = ''
    OR
    (
        EXISTS
        (
            SELECT 1
            FROM STRING_SPLIT(CAST(@CategoryName AS NVARCHAR(MAX)), ',') c
            WHERE UPPER(LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(c.value, '""', ''), '[', ''), ']', '')))) = 'DEFAULT'
        )
        AND (p.CategoryName IS NULL OR LTRIM(RTRIM(p.CategoryName)) = '')
    )
    OR UPPER(ISNULL(LTRIM(RTRIM(p.CategoryName)), '')) IN
    (
        SELECT UPPER(LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', ''))))
        FROM STRING_SPLIT(CAST(@CategoryName AS NVARCHAR(MAX)), ',')
    )
)

AND
(
    @StoreIds IS NULL
    OR LTRIM(RTRIM(@StoreIds)) = ''
    OR EXISTS
    (
        SELECT 1
        FROM STRING_SPLIT(CAST(@StoreIds AS NVARCHAR(MAX)), ',') s
        WHERE l.StoreId = TRY_CONVERT
        (
            uniqueidentifier,
            LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(s.value, '""', ''), '[', ''), ']', '')))
        )
    )
)

AND
(
    @SatisDanismaniIds IS NULL
    OR LTRIM(RTRIM(@SatisDanismaniIds)) = ''
    OR EXISTS
    (
        SELECT 1
        FROM STRING_SPLIT(CAST(@SatisDanismaniIds AS NVARCHAR(MAX)), ',') s
        WHERE l.SalesPersonKUserId = TRY_CONVERT
        (
            uniqueidentifier,
            LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(s.value, '""', ''), '[', ''), ']', '')))
        )
    )
)

AND
(
    @ProcessCode IS NULL
    OR LTRIM(RTRIM(@ProcessCode)) = ''
    OR UPPER(ISNULL(LTRIM(RTRIM(lp.Code)), '')) IN
    (
        SELECT UPPER(LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', ''))))
        FROM STRING_SPLIT(CAST(@ProcessCode AS NVARCHAR(MAX)), ',')
    )
)

AND
(
    @StartDate IS NULL
    OR LTRIM(RTRIM(@StartDate)) = ''
    OR l.CreatedAt >= CONVERT(date, @StartDate)
)

AND
(
    @EndDate IS NULL
    OR LTRIM(RTRIM(@EndDate)) = ''
    OR l.CreatedAt < DATEADD(day, 1, CONVERT(date, @EndDate))
);", new string[] { "ToplamTalepSayisi", "OnayBekleyenSayisi", "TerminBekleyenSayisi", "OnaylananSayisi", "ReddedilenSayisi", "TeslimEdilecekSayisi", "TeslimEdildiSayisi" }, prms_TMLeadProcessCountSummary_1.ToArray());
            ;


            return Ok(result);
        }


        [HttpPost, Route("LeadListComponent_161661_onChange")]
        public IActionResult LeadListComponent_161661_onChange(LeadListComponent_161661_onChange_Request request)
        {

            KProviderManager.Authorization.IsAuthorizedForRoles(appId, appName, screenId, screenName, new List<string> { $"70de6cfc-6087-6059-59b4-0b5a8527af6b", "4da1f213-c8e4-0b50-5c84-02fd13f1a622", "c4e882ef-977d-f613-7694-230ac83919d2", "b4bfd39c-ac02-f442-c899-7a2374a45b47", "cdb536b0-6297-155f-d446-8453d8a60304", "TimesYonetici", "TimesUstYonetici", "TimesSatisPersoneli", "TimesMagazaMuduru", "TimesAdmin" });

            var result = new LeadListComponent_161661_onChange_Response();

            var prms_TM_GetLeads_0 = new List<kSqlParameter>();
            prms_TM_GetLeads_0.Add(new kSqlParameter() { Name = "StepOrder", Value = request.StepOrder_0 });
            prms_TM_GetLeads_0.Add(new kSqlParameter() { Name = "UserId", Value = Kuika.Common.KContext.CurrentUser?.Id });
            prms_TM_GetLeads_0.Add(new kSqlParameter() { Name = "MusteriAdi", Value = request.MusteriAdi_0 });
            prms_TM_GetLeads_0.Add(new kSqlParameter() { Name = "ProductName", Value = request.ProductName_0 });
            prms_TM_GetLeads_0.Add(new kSqlParameter() { Name = "LeadCode", Value = request.LeadCode_0 });
            prms_TM_GetLeads_0.Add(new kSqlParameter() { Name = "Tel", Value = request.Tel_0 });
            prms_TM_GetLeads_0.Add(new kSqlParameter() { Name = "CategoryName", Value = request.CategoryName_0 });
            prms_TM_GetLeads_0.Add(new kSqlParameter() { Name = "StoreIds", Value = request.StoreIds_0 });
            prms_TM_GetLeads_0.Add(new kSqlParameter() { Name = "SatisDanismaniIds", Value = request.SatisDanismaniIds_0 });
            prms_TM_GetLeads_0.Add(new kSqlParameter() { Name = "ProcessCode", Value = request.ProcessCode_0 });
            prms_TM_GetLeads_0.Add(new kSqlParameter() { Name = "StartDate", Value = request.StartDate_0 });
            prms_TM_GetLeads_0.Add(new kSqlParameter() { Name = "EndDate", Value = request.EndDate_0 });
            using var auditTM_GetLeads_0 = ActionAuditScope.Begin("c0153e61-ccbf-92ad-18fd-9a270d210ac5", "TM_GetLeads", applicationName: "wbTimesCRM", screenOrEndpointName: "LeadList");
            result.TM_GetLeads = KPersister.Fetch(KContext.GetConnectionString(), @"-- SET LANGUAGE Turkish;

-- SELECT
-- CASE 
--     WHEN EXISTS (
--         SELECT 1 
--         FROM tmscrq.TMLeadReservation r
--         WHERE r.LeadId = l.Id
--           AND r.IsActive = 1
--           AND r.IsApproved = 1
--     ) THEN N'Evet'

--     WHEN EXISTS (
--         SELECT 1 
--         FROM tmscrq.TMLeadReservation r
--         WHERE r.LeadId = l.Id
--           AND r.IsActive = 1
--           AND ISNULL(r.IsApproved,0) = 0
--     ) THEN N'Onay Bekliyor'

--     ELSE N'Hayır'
-- END AS RezerveDurumu,
--     l.Id AS LeadId,
--     l.IsReserved,
--     ISNULL(NULLIF(LTRIM(RTRIM(l.LeadCode)), ''), '-') AS LeadNumarasi,
--     CONVERT(varchar(10), l.CreatedAt, 103) AS TalepTarihi,

--     p.Id AS ProductId,
--     ISNULL(NULLIF(LTRIM(RTRIM(p.ProductName)), ''), '-') AS ProductName,
--     ISNULL(NULLIF(LTRIM(RTRIM(p.Bracelet)), ''), '-') AS Bilezik,
--     ISNULL(NULLIF(LTRIM(RTRIM(p.Brand)), ''), '-') AS Brand,
--     ISNULL(NULLIF(LTRIM(RTRIM(p.Dial)), ''), '-') AS Kadran,
--     ISNULL(NULLIF(LTRIM(RTRIM(p.ProductCode)), ''), '-') AS RefCode,
--     ISNULL(NULLIF(LTRIM(RTRIM(p.Referance)), ''), '-') AS Referans,

--     ISNULL(
--         NULLIF(
--             LTRIM(RTRIM(ISNULL(cu.Name, '') + ' ' + ISNULL(cu.LastName, '')))
--         , '')
--     , '-') AS Musteri,

--     ISNULL(NULLIF(LTRIM(RTRIM(cu.CityName)), ''), '-') AS Lokasyon,
--     ISNULL(NULLIF(LTRIM(RTRIM(cu.DistrictName)), ''), '-') AS Ilce,
--     ISNULL(NULLIF(LTRIM(RTRIM(cu.CountryName)), ''), '-') AS Ulke,
--     ISNULL(NULLIF(LTRIM(RTRIM(cu.Info)), ''), '-') AS MusteriInfo,

--     CASE
--         WHEN cu.IsShopping = 1 THEN N'Evet'
--         WHEN cu.IsShopping = 0 THEN N'Hayır'
--         ELSE '-'
--     END AS AlisverisiVarMi,

--     ISNULL(NULLIF(LTRIM(RTRIM(cu.Tel)), ''), '-') AS IrtibatNumarasi,
--     ISNULL(NULLIF(LTRIM(RTRIM(cu.Email)), ''), '-') AS EmailAdresi,

--     ISNULL(NULLIF(LTRIM(RTRIM(cr.ContactResourceName)), ''), '-') AS IletisimKaynagi,

--     ISNULL(NULLIF(LTRIM(RTRIM(p.CategoryName)), ''), '-') AS CategoryName,
--     '-' AS CategoryCode,

--     ISNULL(NULLIF(LTRIM(RTRIM(ls.Name)), ''), '-') AS LeadDurumu,
--     ISNULL(NULLIF(LTRIM(RTRIM(ns.Name)), ''), '-') AS SonrakiAdim,

--     ISNULL(NULLIF(LTRIM(RTRIM(lp.Name)), ''), '-') AS ProcessName,
--     ISNULL(NULLIF(LTRIM(RTRIM(lp.Code)), ''), '-') AS ProcessCode,
--     lp.StepOrder,
-- CASE
--     WHEN EXISTS
--     (
--         SELECT 1
--         FROM tmscrq.TMLeadReservation r
--         WHERE r.LeadId = l.Id
--           AND r.IsActive = 1
--           AND ISNULL(r.IsApproved,0) = 0
--     )
--     THEN 10
--     ELSE lp.StepOrder
-- END AS SelectedStepOrder,

--     ISNULL(
--         CASE
--             WHEN l.EstimatedDate IS NOT NULL
--             THEN CAST(YEAR(l.EstimatedDate) AS VARCHAR(4)) + ' ' + DATENAME(MONTH, l.EstimatedDate)
--             ELSE NULL
--         END,
--         '-'
--     ) AS TerminTarihi,

--     ISNULL(
--         NULLIF(
--             LTRIM(RTRIM(ISNULL(sp.FirstName, '') + ' ' + ISNULL(sp.LastName, '')))
--         , '')
--     , '-') AS SatisDanismani,

--     ISNULL(NULLIF(LTRIM(RTRIM(st.StoreDesc)), ''), '-') AS StoreName

-- FROM tmscrq.TMLead l
-- LEFT JOIN tmscrq.TMLeadStatu ls
--     ON ls.Id = l.StatuId
-- LEFT JOIN tmscrq.TMCustomer cu
--     ON cu.Id = l.CustomerId
-- LEFT JOIN tmscrq.TMProduct p
--     ON p.Id = l.ProductId
-- LEFT JOIN tmscrq.TMContactResource cr
--     ON cr.Id = l.ContactResourceId
-- LEFT JOIN dbo.KUser sp
--     ON sp.Id = l.SalesPersonKUserId
-- LEFT JOIN tmscrq.TMStore st
--     ON st.Id = l.StoreId
-- LEFT JOIN tmscrq.TMLeadProcess lp
--     ON lp.Id = l.ProcessID
-- LEFT JOIN tmscrq.TMLeadNextStep ns
--     ON ns.Id = l.NextStepId

-- WHERE
-- (
--     EXISTS
--     (
--         SELECT 1
--         FROM dbo.KUserRole ur
--         INNER JOIN dbo.KRole r
--             ON r.Id = ur.KRole_Id
--         WHERE ur.KUser_Id = @UserId
--           AND ur.IsDeleted = 0
--           AND r.IsDeleted = 0
--           AND r.Name IN ('TimesYonetici', 'TimesUstYonetici')
--     )
--     OR
--     (
--         EXISTS
--         (
--             SELECT 1
--             FROM dbo.KUserRole ur
--             INNER JOIN dbo.KRole r
--                 ON r.Id = ur.KRole_Id
--             WHERE ur.KUser_Id = @UserId
--               AND ur.IsDeleted = 0
--               AND r.IsDeleted = 0
--               AND r.Name IN ('TimesMagazaMuduru', 'TimesSatisPersoneli')
--         )
--         AND EXISTS
--         (
--             SELECT 1
--             FROM tmscrq.TMUser tu
--             WHERE tu.KUserID = @UserId
--               AND tu.StoreId = l.StoreId
--         )
--     )
-- )

-- AND
-- (
--     @MusteriAdi IS NULL
--     OR LTRIM(RTRIM(@MusteriAdi)) = ''
--     OR UPPER(LTRIM(RTRIM(ISNULL(cu.Name,'') + ' ' + ISNULL(cu.LastName,''))))
--        LIKE '%' + UPPER(LTRIM(RTRIM(@MusteriAdi))) + '%'
-- )

-- AND
-- (
--     @ProductName IS NULL
--     OR LTRIM(RTRIM(@ProductName)) = ''
--     OR
--     (
--         CHARINDEX(',', @ProductName) > 0
--         AND ISNULL(LTRIM(RTRIM(p.ProductName)), '') IN
--         (
--             SELECT LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', '')))
--             FROM STRING_SPLIT(CAST(@ProductName AS NVARCHAR(MAX)), ',')
--             WHERE LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', ''))) <> ''
--         )
--     )
--     OR
--     (
--         CHARINDEX(',', @ProductName) = 0
--         AND UPPER(ISNULL(LTRIM(RTRIM(p.ProductName)), ''))
--             LIKE '%' + UPPER(LTRIM(RTRIM(@ProductName))) + '%'
--     )
-- )

-- AND
-- (
--     @LeadCode IS NULL
--     OR LTRIM(RTRIM(@LeadCode)) = ''
--     OR UPPER(ISNULL(LTRIM(RTRIM(l.LeadCode)), '')) LIKE '%' + UPPER(LTRIM(RTRIM(@LeadCode))) + '%'
-- )

-- AND
-- (
--     @Tel IS NULL
--     OR LTRIM(RTRIM(@Tel)) = ''
--     OR UPPER(ISNULL(LTRIM(RTRIM(cu.Tel)), '')) LIKE '%' + UPPER(LTRIM(RTRIM(@Tel))) + '%'
-- )

-- -- AND
-- -- (
-- --     @CategoryName IS NULL
-- --     OR LTRIM(RTRIM(@CategoryName)) = ''
-- --     OR
-- --     (
-- --         EXISTS
-- --         (
-- --             SELECT 1
-- --             FROM STRING_SPLIT(CAST(@CategoryName AS NVARCHAR(MAX)), ',') c
-- --             WHERE UPPER(LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(c.value, '""', ''), '[', ''), ']', '')))) = 'DEFAULT'
-- --         )
-- --         AND (p.CategoryName IS NULL OR LTRIM(RTRIM(p.CategoryName)) = '')
-- --     )
-- --     OR UPPER(ISNULL(LTRIM(RTRIM(p.CategoryName)), '')) IN
-- --     (
-- --         SELECT UPPER(LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', ''))))
-- --         FROM STRING_SPLIT(CAST(@CategoryName AS NVARCHAR(MAX)), ',')
-- --         WHERE LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', ''))) <> ''
-- --           AND UPPER(LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', '')))) <> 'DEFAULT'
-- --     )
-- -- )

-- AND
-- (
--     @CategoryName IS NULL
--     OR LTRIM(RTRIM(@CategoryName)) = ''
--     OR UPPER(ISNULL(LTRIM(RTRIM(p.CategoryName)), '')) IN
--     (
--         SELECT UPPER(LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value,'""',''),'[',''),']',''))))
--         FROM STRING_SPLIT(CAST(@CategoryName AS NVARCHAR(MAX)), ',')
--         WHERE LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value,'""',''),'[',''),']',''))) <> ''
--     )
-- )

-- AND
-- (
--     @StoreIds IS NULL
--     OR LTRIM(RTRIM(@StoreIds)) = ''
--     OR EXISTS
--     (
--         SELECT 1
--         FROM STRING_SPLIT(CAST(@StoreIds AS NVARCHAR(MAX)), ',') s
--         WHERE l.StoreId = TRY_CONVERT
--         (
--             uniqueidentifier,
--             LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(s.value, '""', ''), '[', ''), ']', '')))
--         )
--     )
-- )

-- AND
-- (
--     @SatisDanismaniIds IS NULL
--     OR LTRIM(RTRIM(@SatisDanismaniIds)) = ''
--     OR EXISTS
--     (
--         SELECT 1
--         FROM STRING_SPLIT(CAST(@SatisDanismaniIds AS NVARCHAR(MAX)), ',') s
--         WHERE l.SalesPersonKUserId = TRY_CONVERT
--         (
--             uniqueidentifier,
--             LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(s.value, '""', ''), '[', ''), ']', '')))
--         )
--     )
-- )

-- AND
-- (
--     @ProcessCode IS NULL
--     OR LTRIM(RTRIM(@ProcessCode)) = ''
--     OR UPPER(ISNULL(LTRIM(RTRIM(lp.Code)), '')) IN
--     (
--         SELECT UPPER(LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', ''))))
--         FROM STRING_SPLIT(CAST(@ProcessCode AS NVARCHAR(MAX)), ',')
--         WHERE LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', ''))) <> ''
--     )
-- )

-- AND
-- (
--     @StepOrder IS NULL

--     OR
--     (
--         @StepOrder = 10
--         AND EXISTS
--         (
--             SELECT 1
--             FROM tmscrq.TMLeadReservation r
--             WHERE r.LeadId = l.Id
--               AND r.IsActive = 1
--               AND ISNULL(r.IsApproved,0) = 0
--         )
--     )

--     OR
--     (
--         @StepOrder <> 10
--         AND lp.StepOrder = @StepOrder
--     )
-- )

-- AND
-- (
--     @StartDate IS NULL
--     OR LTRIM(RTRIM(@StartDate)) = ''
--     OR l.CreatedAt >= CONVERT(date, @StartDate)
-- )

-- AND
-- (
--     @EndDate IS NULL
--     OR LTRIM(RTRIM(@EndDate)) = ''
--     OR l.CreatedAt < DATEADD(day, 1, CONVERT(date, @EndDate))
-- )

-- ORDER BY l.CreatedAt DESC;

------------------------++++++++++++++++++++++++-------------------
-- SET LANGUAGE Turkish;

-- SELECT
-- CASE 
--     WHEN EXISTS (
--         SELECT 1 
--         FROM tmscrq.TMLeadReservation r
--         WHERE r.LeadId = l.Id
--           AND r.IsActive = 1
--           AND r.IsApproved = 1
--     ) THEN N'Evet'

--     WHEN EXISTS (
--         SELECT 1 
--         FROM tmscrq.TMLeadReservation r
--         WHERE r.LeadId = l.Id
--           AND r.IsActive = 1
--           AND ISNULL(r.IsApproved,0) = 0
--     ) THEN N'Onay Bekliyor'

--     ELSE N'Hayır'
-- END AS RezerveDurumu,
--     l.Id AS LeadId,
--     l.IsReserved,
--     ISNULL(NULLIF(LTRIM(RTRIM(l.LeadCode)), ''), '-') AS LeadNumarasi,
--     CONVERT(varchar(10), l.CreatedAt, 103) AS TalepTarihi,

--     p.Id AS ProductId,
--     ISNULL(NULLIF(LTRIM(RTRIM(p.ProductName)), ''), '-') AS ProductName,
--     ISNULL(NULLIF(LTRIM(RTRIM(p.Bracelet)), ''), '-') AS Bilezik,
--     ISNULL(NULLIF(LTRIM(RTRIM(p.Brand)), ''), '-') AS Brand,
--     ISNULL(NULLIF(LTRIM(RTRIM(p.Dial)), ''), '-') AS Kadran,
--     ISNULL(NULLIF(LTRIM(RTRIM(p.ProductCode)), ''), '-') AS RefCode,
--     ISNULL(NULLIF(LTRIM(RTRIM(p.Referance)), ''), '-') AS Referans,

--     ISNULL(
--         NULLIF(
--             LTRIM(RTRIM(ISNULL(cu.Name, '') + ' ' + ISNULL(cu.LastName, '')))
--         , '')
--     , '-') AS Musteri,

--     ISNULL(NULLIF(LTRIM(RTRIM(cu.CityName)), ''), '-') AS Lokasyon,
--     ISNULL(NULLIF(LTRIM(RTRIM(cu.DistrictName)), ''), '-') AS Ilce,
--     ISNULL(NULLIF(LTRIM(RTRIM(cu.CountryName)), ''), '-') AS Ulke,
--     ISNULL(NULLIF(LTRIM(RTRIM(cu.Info)), ''), '-') AS MusteriInfo,

--     CASE
--         WHEN cu.IsShopping = 1 THEN N'Evet'
--         WHEN cu.IsShopping = 0 THEN N'Hayır'
--         ELSE '-'
--     END AS AlisverisiVarMi,

--     ISNULL(NULLIF(LTRIM(RTRIM(cu.Tel)), ''), '-') AS IrtibatNumarasi,
--     ISNULL(NULLIF(LTRIM(RTRIM(cu.Email)), ''), '-') AS EmailAdresi,

--     ISNULL(NULLIF(LTRIM(RTRIM(cr.ContactResourceName)), ''), '-') AS IletisimKaynagi,

--     ISNULL(NULLIF(LTRIM(RTRIM(p.CategoryName)), ''), '-') AS CategoryName,
--     '-' AS CategoryCode,

--     ISNULL(NULLIF(LTRIM(RTRIM(ls.Name)), ''), '-') AS LeadDurumu,
--     ISNULL(NULLIF(LTRIM(RTRIM(ns.Name)), ''), '-') AS SonrakiAdim,

--     ISNULL(NULLIF(LTRIM(RTRIM(lp.Name)), ''), '-') AS ProcessName,
--     ISNULL(NULLIF(LTRIM(RTRIM(lp.Code)), ''), '-') AS ProcessCode,
--     lp.StepOrder,
    
--     -- DÜZELTİLEN ALAN: SelectedStepOrder
--     CASE
--         WHEN EXISTS
--         (
--             SELECT 1
--             FROM tmscrq.TMLeadReservation r
--             WHERE r.LeadId = l.Id
--               AND r.IsActive = 1
--               AND ISNULL(r.IsApproved,0) = 0
--         )
--         THEN 10
--         ELSE lp.StepOrder
--     END AS SelectedStepOrder,

--     ISNULL(
--         CASE
--             WHEN l.EstimatedDate IS NOT NULL
--             THEN CAST(YEAR(l.EstimatedDate) AS VARCHAR(4)) + ' ' + DATENAME(MONTH, l.EstimatedDate)
--             ELSE NULL
--         END,
--         '-'
--     ) AS TerminTarihi,

--     ISNULL(
--         NULLIF(
--             LTRIM(RTRIM(ISNULL(sp.FirstName, '') + ' ' + ISNULL(sp.LastName, '')))
--         , '')
--     , '-') AS SatisDanismani,

--     ISNULL(NULLIF(LTRIM(RTRIM(st.StoreDesc)), ''), '-') AS StoreName

-- FROM tmscrq.TMLead l
-- LEFT JOIN tmscrq.TMLeadStatu ls
--     ON ls.Id = l.StatuId
-- LEFT JOIN tmscrq.TMCustomer cu
--     ON cu.Id = l.CustomerId
-- LEFT JOIN tmscrq.TMProduct p
--     ON p.Id = l.ProductId
-- LEFT JOIN tmscrq.TMContactResource cr
--     ON cr.Id = l.ContactResourceId
-- LEFT JOIN dbo.KUser sp
--     ON sp.Id = l.SalesPersonKUserId
-- LEFT JOIN tmscrq.TMStore st
--     ON st.Id = l.StoreId
-- LEFT JOIN tmscrq.TMLeadProcess lp
--     ON lp.Id = l.ProcessID
-- LEFT JOIN tmscrq.TMLeadNextStep ns
--     ON ns.Id = l.NextStepId

-- WHERE
-- (
--     EXISTS
--     (
--         SELECT 1
--         FROM dbo.KUserRole ur
--         INNER JOIN dbo.KRole r
--             ON r.Id = ur.KRole_Id
--         WHERE ur.KUser_Id = @UserId
--           AND ur.IsDeleted = 0
--           AND r.IsDeleted = 0
--           AND r.Name IN ('TimesYonetici', 'TimesUstYonetici')
--     )
--     OR
--     (
--         EXISTS
--         (
--             SELECT 1
--             FROM dbo.KUserRole ur
--             INNER JOIN dbo.KRole r
--                 ON r.Id = ur.KRole_Id
--             WHERE ur.KUser_Id = @UserId
--               AND ur.IsDeleted = 0
--               AND r.IsDeleted = 0
--               AND r.Name IN ('TimesMagazaMuduru', 'TimesSatisPersoneli')
--         )
--         AND EXISTS
--         (
--             SELECT 1
--             FROM tmscrq.TMUser tu
--             WHERE tu.KUserID = @UserId
--               AND tu.StoreId = l.StoreId
--         )
--     )
-- )

-- AND
-- (
--     @MusteriAdi IS NULL
--     OR LTRIM(RTRIM(@MusteriAdi)) = ''
--     OR UPPER(LTRIM(RTRIM(ISNULL(cu.Name,'') + ' ' + ISNULL(cu.LastName,''))))
--        LIKE '%' + UPPER(LTRIM(RTRIM(@MusteriAdi))) + '%'
-- )

-- AND
-- (
--     @ProductName IS NULL
--     OR LTRIM(RTRIM(@ProductName)) = ''
--     OR
--     (
--         CHARINDEX(',', @ProductName) > 0
--         AND ISNULL(LTRIM(RTRIM(p.ProductName)), '') IN
--         (
--             SELECT LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', '')))
--             FROM STRING_SPLIT(CAST(@ProductName AS NVARCHAR(MAX)), ',')
--             WHERE LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', ''))) <> ''
--         )
--     )
--     OR
--     (
--         CHARINDEX(',', @ProductName) = 0
--         AND UPPER(ISNULL(LTRIM(RTRIM(p.ProductName)), ''))
--             LIKE '%' + UPPER(LTRIM(RTRIM(@ProductName))) + '%'
--     )
-- )

-- AND
-- (
--     @LeadCode IS NULL
--     OR LTRIM(RTRIM(@LeadCode)) = ''
--     OR UPPER(ISNULL(LTRIM(RTRIM(l.LeadCode)), '')) LIKE '%' + UPPER(LTRIM(RTRIM(@LeadCode))) + '%'
-- )

-- AND
-- (
--     @Tel IS NULL
--     OR LTRIM(RTRIM(@Tel)) = ''
--     OR UPPER(ISNULL(LTRIM(RTRIM(cu.Tel)), '')) LIKE '%' + UPPER(LTRIM(RTRIM(@Tel))) + '%'
-- )

-- AND
-- (
--     @CategoryName IS NULL
--     OR LTRIM(RTRIM(@CategoryName)) = ''
--     OR UPPER(ISNULL(LTRIM(RTRIM(p.CategoryName)), '')) IN
--     (
--         SELECT UPPER(LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value,'""',''),'[',''),']',''))))
--         FROM STRING_SPLIT(CAST(@CategoryName AS NVARCHAR(MAX)), ',')
--         WHERE LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value,'""',''),'[',''),']',''))) <> ''
--     )
-- )

-- AND
-- (
--     @StoreIds IS NULL
--     OR LTRIM(RTRIM(@StoreIds)) = ''
--     OR EXISTS
--     (
--         SELECT 1
--         FROM STRING_SPLIT(CAST(@StoreIds AS NVARCHAR(MAX)), ',') s
--         WHERE l.StoreId = TRY_CONVERT
--         (
--             uniqueidentifier,
--             LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(s.value, '""', ''), '[', ''), ']', '')))
--         )
--     )
-- )

-- AND
-- (
--     @SatisDanismaniIds IS NULL
--     OR LTRIM(RTRIM(@SatisDanismaniIds)) = ''
--     OR EXISTS
--     (
--         SELECT 1
--         FROM STRING_SPLIT(CAST(@SatisDanismaniIds AS NVARCHAR(MAX)), ',') s
--         WHERE l.SalesPersonKUserId = TRY_CONVERT
--         (
--             uniqueidentifier,
--             LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(s.value, '""', ''), '[', ''), ']', '')))
--         )
--     )
-- )

-- AND
-- (
--     @ProcessCode IS NULL
--     OR LTRIM(RTRIM(@ProcessCode)) = ''
--     OR UPPER(ISNULL(LTRIM(RTRIM(lp.Code)), '')) IN
--     (
--         SELECT UPPER(LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', ''))))
--         FROM STRING_SPLIT(CAST(@ProcessCode AS NVARCHAR(MAX)), ',')
--         WHERE LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', ''))) <> ''
--     )
-- )

-- -- DÜZELTİLEN ALAN: @StepOrder Filtresi (tek blok)
-- AND
-- (
--     @StepOrder IS NULL

--     OR

--     (
--         @StepOrder = 10
--         AND EXISTS
--         (
--             SELECT 1
--             FROM tmscrq.TMLeadReservation r
--             WHERE r.LeadId = l.Id
--               AND r.IsActive = 1
--               AND ISNULL(r.IsApproved,0) = 0
--         )
--     )

--     OR

--     (
--         @StepOrder <> 10
--         AND lp.StepOrder = @StepOrder
--     )
-- )

-- AND
-- (
--     @StartDate IS NULL
--     OR LTRIM(RTRIM(@StartDate)) = ''
--     OR l.CreatedAt >= CONVERT(date, @StartDate)
-- )

-- AND
-- (
--     @EndDate IS NULL
--     OR LTRIM(RTRIM(@EndDate)) = ''
--     OR l.CreatedAt < DATEADD(day, 1, CONVERT(date, @EndDate))
-- )

-- ORDER BY l.CreatedAt DESC;



SET LANGUAGE Turkish;

SELECT
CASE 
    WHEN EXISTS (
        SELECT 1 
        FROM tmscrq.TMLeadReservation r
        WHERE r.LeadId = l.Id
          AND r.IsActive = 1
          AND r.IsApproved = 1
    ) THEN N'Evet'

    WHEN EXISTS (
        SELECT 1 
        FROM tmscrq.TMLeadReservation r
        WHERE r.LeadId = l.Id
          AND r.IsActive = 1
          AND ISNULL(r.IsApproved,0) = 0
    ) THEN N'Onay Bekliyor'

    ELSE N'Hayır'
END AS RezerveDurumu,
    l.Id AS LeadId,
    l.IsReserved,
    ISNULL(NULLIF(LTRIM(RTRIM(l.LeadCode)), ''), '-') AS LeadNumarasi,
     FORMAT(l.CreatedAt, 'dd MMMM yyyy', 'tr-TR') AS TalepTarihi,

    p.Id AS ProductId,
    ISNULL(NULLIF(LTRIM(RTRIM(p.ProductName)), ''), '-') AS ProductName,
    ISNULL(NULLIF(LTRIM(RTRIM(p.Bracelet)), ''), '-') AS Bilezik,
    ISNULL(NULLIF(LTRIM(RTRIM(p.Brand)), ''), '-') AS Brand,
    ISNULL(NULLIF(LTRIM(RTRIM(p.Dial)), ''), '-') AS Kadran,
    ISNULL(NULLIF(LTRIM(RTRIM(p.ProductCode)), ''), '-') AS RefCode,
    ISNULL(NULLIF(LTRIM(RTRIM(p.Referance)), ''), '-') AS Referans,

    ISNULL(
        NULLIF(
            LTRIM(RTRIM(ISNULL(cu.Name, '') + ' ' + ISNULL(cu.LastName, '')))
        , '')
    , '-') AS Musteri,

    ISNULL(NULLIF(LTRIM(RTRIM(cu.CityName)), ''), '-') AS Lokasyon,
    ISNULL(NULLIF(LTRIM(RTRIM(cu.DistrictName)), ''), '-') AS Ilce,
    ISNULL(NULLIF(LTRIM(RTRIM(cu.CountryName)), ''), '-') AS Ulke,
    ISNULL(NULLIF(LTRIM(RTRIM(cu.Info)), ''), '-') AS MusteriInfo,

    CASE
        WHEN cu.IsShopping = 1 THEN N'Evet'
        WHEN cu.IsShopping = 0 THEN N'Hayır'
        ELSE '-'
    END AS AlisverisiVarMi,

    ISNULL(NULLIF(LTRIM(RTRIM(cu.Tel)), ''), '-') AS IrtibatNumarasi,
    ISNULL(NULLIF(LTRIM(RTRIM(cu.Email)), ''), '-') AS EmailAdresi,

    ISNULL(NULLIF(LTRIM(RTRIM(cr.ContactResourceName)), ''), '-') AS IletisimKaynagi,

    ISNULL(NULLIF(LTRIM(RTRIM(p.CategoryName)), ''), '-') AS CategoryName,
    '-' AS CategoryCode,

    ISNULL(NULLIF(LTRIM(RTRIM(ls.Name)), ''), '-') AS LeadDurumu,
    ISNULL(NULLIF(LTRIM(RTRIM(ns.Name)), ''), '-') AS SonrakiAdim,

    ISNULL(NULLIF(LTRIM(RTRIM(lp.Name)), ''), '-') AS ProcessName,
    ISNULL(NULLIF(LTRIM(RTRIM(lp.Code)), ''), '-') AS ProcessCode,
    lp.StepOrder,
    
    -- DÜZELTİLEN ALAN: SelectedStepOrder
    CASE
        WHEN EXISTS
        (
            SELECT 1
            FROM tmscrq.TMLeadReservation r
            WHERE r.LeadId = l.Id
              AND r.IsActive = 1
              AND ISNULL(r.IsApproved,0) = 0
        )
        THEN 10
        ELSE lp.StepOrder
    END AS SelectedStepOrder,

    ISNULL(
        CASE
            WHEN l.EstimatedDate IS NOT NULL
            THEN CAST(YEAR(l.EstimatedDate) AS VARCHAR(4)) + ' ' + DATENAME(MONTH, l.EstimatedDate)
            ELSE NULL
        END,
        '-'
    ) AS TerminTarihi,

    ISNULL(
        NULLIF(
            LTRIM(RTRIM(ISNULL(sp.FirstName, '') + ' ' + ISNULL(sp.LastName, '')))
        , '')
    , '-') AS SatisDanismani,

    ISNULL(NULLIF(LTRIM(RTRIM(st.StoreDesc)), ''), '-') AS StoreName

FROM tmscrq.TMLead l
LEFT JOIN tmscrq.TMLeadStatu ls
    ON ls.Id = l.StatuId
LEFT JOIN tmscrq.TMCustomer cu
    ON cu.Id = l.CustomerId
LEFT JOIN tmscrq.TMProduct p
    ON p.Id = l.ProductId
LEFT JOIN tmscrq.TMContactResource cr
    ON cr.Id = l.ContactResourceId
LEFT JOIN dbo.KUser sp
    ON sp.Id = l.SalesPersonKUserId
LEFT JOIN tmscrq.TMStore st
    ON st.Id = l.StoreId
LEFT JOIN tmscrq.TMLeadProcess lp
    ON lp.Id = l.ProcessID
LEFT JOIN tmscrq.TMLeadNextStep ns
    ON ns.Id = l.NextStepId

WHERE
(
    EXISTS
    (
        SELECT 1
        FROM dbo.KUserRole ur
        INNER JOIN dbo.KRole r
            ON r.Id = ur.KRole_Id
        WHERE ur.KUser_Id = @UserId
          AND ur.IsDeleted = 0
          AND r.IsDeleted = 0
          AND r.Name IN ('TimesYonetici', 'TimesUstYonetici')
    )
    OR
    (
        EXISTS
        (
            SELECT 1
            FROM dbo.KUserRole ur
            INNER JOIN dbo.KRole r
                ON r.Id = ur.KRole_Id
            WHERE ur.KUser_Id = @UserId
              AND ur.IsDeleted = 0
              AND r.IsDeleted = 0
              AND r.Name IN ('TimesMagazaMuduru', 'TimesSatisPersoneli')
        )
        AND EXISTS
        (
            SELECT 1
            FROM tmscrq.TMUser tu
            WHERE tu.KUserID = @UserId
              AND tu.StoreId = l.StoreId
        )
    )
)

AND
(
    ISNULL(@MusteriAdi, '') = ''
    OR UPPER(ISNULL(cu.Name, '')) LIKE '%' + UPPER(LTRIM(RTRIM(@MusteriAdi))) + '%'
    OR UPPER(ISNULL(cu.LastName, '')) LIKE '%' + UPPER(LTRIM(RTRIM(@MusteriAdi))) + '%'
    OR UPPER(
        ISNULL(cu.Name, '') + ' ' + ISNULL(cu.LastName, '')
    ) LIKE '%' + UPPER(LTRIM(RTRIM(@MusteriAdi))) + '%'
)

AND
(
    @ProductName IS NULL
    OR LTRIM(RTRIM(@ProductName)) = ''
    OR
    (
        CHARINDEX(',', @ProductName) > 0
        AND ISNULL(LTRIM(RTRIM(p.ProductName)), '') IN
        (
            SELECT LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', '')))
            FROM STRING_SPLIT(CAST(@ProductName AS NVARCHAR(MAX)), ',')
            WHERE LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', ''))) <> ''
        )
    )
    OR
    (
        CHARINDEX(',', @ProductName) = 0
        AND UPPER(ISNULL(LTRIM(RTRIM(p.ProductName)), ''))
            LIKE '%' + UPPER(LTRIM(RTRIM(@ProductName))) + '%'
    )
)

AND
(
    ISNULL(@LeadCode, '') = ''
    OR UPPER(ISNULL(l.LeadCode, ''))
        LIKE '%' + UPPER(LTRIM(RTRIM(@LeadCode))) + '%'
    OR REPLACE(
        REPLACE(
            REPLACE(
                UPPER(ISNULL(l.LeadCode, '')),
                '-', ''
            ),
            ' ', ''
        ),
        '/', ''
    )
    LIKE '%' +
    REPLACE(
        REPLACE(
            REPLACE(
                UPPER(LTRIM(RTRIM(@LeadCode))),
                '-', ''
            ),
            ' ', ''
        ),
        '/', ''
    )
    + '%'
)

AND
(
    @Tel IS NULL
    OR LTRIM(RTRIM(@Tel)) = ''
    OR UPPER(ISNULL(LTRIM(RTRIM(cu.Tel)), '')) LIKE '%' + UPPER(LTRIM(RTRIM(@Tel))) + '%'
)

AND
(
    @CategoryName IS NULL
    OR LTRIM(RTRIM(@CategoryName)) = ''
    OR UPPER(ISNULL(LTRIM(RTRIM(p.CategoryName)), '')) IN
    (
        SELECT UPPER(LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value,'""',''),'[',''),']',''))))
        FROM STRING_SPLIT(CAST(@CategoryName AS NVARCHAR(MAX)), ',')
        WHERE LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value,'""',''),'[',''),']',''))) <> ''
    )
)

AND
(
    @StoreIds IS NULL
    OR LTRIM(RTRIM(@StoreIds)) = ''
    OR EXISTS
    (
        SELECT 1
        FROM STRING_SPLIT(CAST(@StoreIds AS NVARCHAR(MAX)), ',') s
        WHERE l.StoreId = TRY_CONVERT
        (
            uniqueidentifier,
            LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(s.value, '""', ''), '[', ''), ']', '')))
        )
    )
)

AND
(
    @SatisDanismaniIds IS NULL
    OR LTRIM(RTRIM(@SatisDanismaniIds)) = ''
    OR EXISTS
    (
        SELECT 1
        FROM STRING_SPLIT(CAST(@SatisDanismaniIds AS NVARCHAR(MAX)), ',') s
        WHERE l.SalesPersonKUserId = TRY_CONVERT
        (
            uniqueidentifier,
            LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(s.value, '""', ''), '[', ''), ']', '')))
        )
    )
)

AND
(
    ISNULL(@ProcessCode, '') = ''
    OR EXISTS
    (
        SELECT 1
        FROM STRING_SPLIT(
            CONVERT(NVARCHAR(MAX), @ProcessCode),
            ','
        ) AS s
        WHERE
            UPPER(LTRIM(RTRIM(s.value))) =
            UPPER(LTRIM(RTRIM(ISNULL(lp.Code, ''))))
    )
)

-- DÜZELTİLEN ALAN: @StepOrder Filtresi (0 verilince tümü gelsin)
AND
(
    @StepOrder IS NULL
    OR @StepOrder = 0  -- 👈 YENİ EKLENDI: 0 verilince tüm kayıtlar gelir
    OR
    (
        @StepOrder = 10
        AND EXISTS
        (
            SELECT 1
            FROM tmscrq.TMLeadReservation r
            WHERE r.LeadId = l.Id
              AND r.IsActive = 1
              AND ISNULL(r.IsApproved,0) = 0
        )
    )
    OR
    (
        @StepOrder <> 10
        AND lp.StepOrder = @StepOrder
    )
)

AND
(
    @StartDate IS NULL
    OR LTRIM(RTRIM(@StartDate)) = ''
    OR l.CreatedAt >= CONVERT(date, @StartDate)
)

AND
(
    @EndDate IS NULL
    OR LTRIM(RTRIM(@EndDate)) = ''
    OR l.CreatedAt < DATEADD(day, 1, CONVERT(date, @EndDate))
)

ORDER BY l.CreatedAt DESC;", new string[] { "RezerveDurumu", "LeadId", "IsReserved", "LeadNumarasi", "TalepTarihi", "ProductId", "ProductName", "Bilezik", "Brand", "Kadran", "RefCode", "Referans", "Musteri", "Lokasyon", "Ilce", "Ulke", "MusteriInfo", "AlisverisiVarMi", "IrtibatNumarasi", "EmailAdresi", "IletisimKaynagi", "CategoryName", "CategoryCode", "LeadDurumu", "SonrakiAdim", "ProcessName", "ProcessCode", "StepOrder", "SelectedStepOrder", "TerminTarihi", "SatisDanismani", "StoreName" }, prms_TM_GetLeads_0.ToArray());
            ;

            var prms_TMLeadProcessCountSummary_1 = new List<kSqlParameter>();
            prms_TMLeadProcessCountSummary_1.Add(new kSqlParameter() { Name = "UserId", Value = Kuika.Common.KContext.CurrentUser?.Id });
            prms_TMLeadProcessCountSummary_1.Add(new kSqlParameter() { Name = "MusteriAdi", Value = request.MusteriAdi_1 });
            prms_TMLeadProcessCountSummary_1.Add(new kSqlParameter() { Name = "ProductName", Value = request.ProductName_1 });
            prms_TMLeadProcessCountSummary_1.Add(new kSqlParameter() { Name = "LeadCode", Value = request.LeadCode_1 });
            prms_TMLeadProcessCountSummary_1.Add(new kSqlParameter() { Name = "Tel", Value = request.Tel_1 });
            prms_TMLeadProcessCountSummary_1.Add(new kSqlParameter() { Name = "CategoryName", Value = request.CategoryName_1 });
            prms_TMLeadProcessCountSummary_1.Add(new kSqlParameter() { Name = "StoreIds", Value = request.StoreIds_1 });
            prms_TMLeadProcessCountSummary_1.Add(new kSqlParameter() { Name = "SatisDanismaniIds", Value = request.SatisDanismaniIds_1 });
            prms_TMLeadProcessCountSummary_1.Add(new kSqlParameter() { Name = "ProcessCode", Value = request.ProcessCode_1 });
            prms_TMLeadProcessCountSummary_1.Add(new kSqlParameter() { Name = "StartDate", Value = request.StartDate_1 });
            prms_TMLeadProcessCountSummary_1.Add(new kSqlParameter() { Name = "EndDate", Value = request.EndDate_1 });
            using var auditTMLeadProcessCountSummary_1 = ActionAuditScope.Begin("97dd7bce-782b-5d5a-1b44-5194930e6b56", "TMLeadProcessCountSummary", applicationName: "wbTimesCRM", screenOrEndpointName: "LeadList");
            result.TMLeadProcessCountSummary = KPersister.Fetch(KContext.GetConnectionString(), @"-- SELECT
--     COUNT(*) AS ToplamTalepSayisi,

--     SUM(CASE WHEN lp.Code = 'PENDING' THEN 1 ELSE 0 END) AS OnayBekleyenSayisi,
--     SUM(CASE WHEN lp.Code = 'TERMIN_PENDING' THEN 1 ELSE 0 END) AS TerminBekleyenSayisi,
--     SUM(CASE WHEN lp.Code = 'APPROVED' THEN 1 ELSE 0 END) AS OnaylananSayisi,
--     SUM(CASE WHEN lp.Code = 'REJECTED' THEN 1 ELSE 0 END) AS ReddedilenSayisi,
--     SUM(CASE WHEN lp.Code = 'DELIVERY_PENDING' THEN 1 ELSE 0 END) AS TeslimEdilecekSayisi,
--     SUM(CASE WHEN lp.Code = 'DELIVERED' THEN 1 ELSE 0 END) AS TeslimEdildiSayisi

-- FROM tmscrq.TMLead l
-- LEFT JOIN tmscrq.TMCustomer cu
--     ON cu.Id = l.CustomerId
-- LEFT JOIN tmscrq.TMProduct p
--     ON p.Id = l.ProductId
-- LEFT JOIN dbo.KUser sp
--     ON sp.Id = l.SalesPersonKUserId
-- LEFT JOIN tmscrq.TMLeadProcess lp
--     ON lp.Id = l.ProcessID

-- WHERE
-- (
--     EXISTS
--     (
--         SELECT 1
--         FROM dbo.KUserRole ur
--         INNER JOIN dbo.KRole r
--             ON r.Id = ur.KRole_Id
--         WHERE ur.KUser_Id = @UserId
--           AND ur.IsDeleted = 0
--           AND r.IsDeleted = 0
--           AND r.Name IN ('TimesYonetici', 'TimesUstYonetici')
--     )
--     OR
--     (
--         EXISTS
--         (
--             SELECT 1
--             FROM dbo.KUserRole ur
--             INNER JOIN dbo.KRole r
--                 ON r.Id = ur.KRole_Id
--             WHERE ur.KUser_Id = @UserId
--               AND ur.IsDeleted = 0
--               AND r.IsDeleted = 0
--               AND r.Name IN ('TimesMagazaMuduru', 'TimesSatisPersoneli')
--         )
--         AND EXISTS
--         (
--             SELECT 1
--             FROM tmscrq.TMUser tu
--             WHERE tu.KUserID = @UserId
--               AND tu.StoreId = l.StoreId
--         )
--     )
-- )

-- AND
-- (
--     @MusteriAdi IS NULL
--     OR LTRIM(RTRIM(@MusteriAdi)) = ''
--     OR UPPER(LTRIM(RTRIM(ISNULL(cu.Name, '') + ' ' + ISNULL(cu.LastName, ''))))
--        LIKE '%' + UPPER(LTRIM(RTRIM(@MusteriAdi))) + '%'
-- )

-- AND
-- (
--     @ProductName IS NULL
--     OR LTRIM(RTRIM(@ProductName)) = ''
--     OR
--     (
--         CHARINDEX(',', @ProductName) > 0
--         AND ISNULL(LTRIM(RTRIM(p.ProductName)), '') IN
--         (
--             SELECT LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', '')))
--             FROM STRING_SPLIT(CAST(@ProductName AS NVARCHAR(MAX)), ',')
--             WHERE LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', ''))) <> ''
--         )
--     )
--     OR
--     (
--         CHARINDEX(',', @ProductName) = 0
--         AND UPPER(ISNULL(LTRIM(RTRIM(p.ProductName)), ''))
--             LIKE '%' + UPPER(LTRIM(RTRIM(@ProductName))) + '%'
--     )
-- )

-- AND
-- (
--     @LeadCode IS NULL
--     OR LTRIM(RTRIM(@LeadCode)) = ''
--     OR UPPER(ISNULL(LTRIM(RTRIM(l.LeadCode)), '')) LIKE '%' + UPPER(LTRIM(RTRIM(@LeadCode))) + '%'
-- )

-- AND
-- (
--     @Tel IS NULL
--     OR LTRIM(RTRIM(@Tel)) = ''
--     OR UPPER(ISNULL(LTRIM(RTRIM(cu.Tel)), '')) LIKE '%' + UPPER(LTRIM(RTRIM(@Tel))) + '%'
-- )

-- AND
-- (
--     @CategoryName IS NULL
--     OR LTRIM(RTRIM(@CategoryName)) = ''
--     OR
--     (
--         EXISTS
--         (
--             SELECT 1
--             FROM STRING_SPLIT(CAST(@CategoryName AS NVARCHAR(MAX)), ',') c
--             WHERE UPPER(LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(c.value, '""', ''), '[', ''), ']', '')))) = 'DEFAULT'
--         )
--         AND (p.CategoryName IS NULL OR LTRIM(RTRIM(p.CategoryName)) = '')
--     )
--     OR UPPER(ISNULL(LTRIM(RTRIM(p.CategoryName)), '')) IN
--     (
--         SELECT UPPER(LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', ''))))
--         FROM STRING_SPLIT(CAST(@CategoryName AS NVARCHAR(MAX)), ',')
--         WHERE LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', ''))) <> ''
--           AND UPPER(LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', '')))) <> 'DEFAULT'
--     )
-- )

-- AND
-- (
--     @StoreIds IS NULL
--     OR LTRIM(RTRIM(@StoreIds)) = ''
--     OR EXISTS
--     (
--         SELECT 1
--         FROM STRING_SPLIT(CAST(@StoreIds AS NVARCHAR(MAX)), ',') s
--         WHERE l.StoreId = TRY_CONVERT
--         (
--             uniqueidentifier,
--             LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(s.value, '""', ''), '[', ''), ']', '')))
--         )
--     )
-- )

-- AND
-- (
--     @SatisDanismaniIds IS NULL
--     OR LTRIM(RTRIM(@SatisDanismaniIds)) = ''
--     OR EXISTS
--     (
--         SELECT 1
--         FROM STRING_SPLIT(CAST(@SatisDanismaniIds AS NVARCHAR(MAX)), ',') s
--         WHERE l.SalesPersonKUserId = TRY_CONVERT
--         (
--             uniqueidentifier,
--             LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(s.value, '""', ''), '[', ''), ']', '')))
--         )
--     )
-- )

-- AND
-- (
--     @ProcessCode IS NULL
--     OR LTRIM(RTRIM(@ProcessCode)) = ''
--     OR UPPER(ISNULL(LTRIM(RTRIM(lp.Code)), '')) IN
--     (
--         SELECT UPPER(LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', ''))))
--         FROM STRING_SPLIT(CAST(@ProcessCode AS NVARCHAR(MAX)), ',')
--         WHERE LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', ''))) <> ''
--     )
-- )

-- AND
-- (
--     @StartDate IS NULL
--     OR LTRIM(RTRIM(@StartDate)) = ''
--     OR l.CreatedAt >= CONVERT(date, @StartDate)
-- )

-- AND
-- (
--     @EndDate IS NULL
--     OR LTRIM(RTRIM(@EndDate)) = ''
--     OR l.CreatedAt < DATEADD(day, 1, CONVERT(date, @EndDate))
-- );

-------------------------------------------------------------

DECLARE @KUserId UNIQUEIDENTIFIER = @UserId;

WITH UserRoles AS (
    SELECT r.Name
    FROM dbo.KUserRole ur
    INNER JOIN dbo.KRole r 
        ON r.Id = ur.KRole_Id
    WHERE ur.KUser_Id = @KUserId
      AND ur.IsDeleted = 0
      AND r.IsDeleted = 0
),
IsAdmin AS (
    SELECT CASE 
        WHEN EXISTS (
            SELECT 1 
            FROM UserRoles 
            WHERE Name = 'TimesUstYonetici'
        ) THEN 1 ELSE 0 END AS IsAdmin
)

SELECT
    COUNT(*) AS ToplamTalepSayisi,

    SUM(CASE WHEN lp.Code = 'PENDING' THEN 1 ELSE 0 END) AS OnayBekleyenSayisi,
    SUM(CASE WHEN lp.Code = 'TERMIN_PENDING' THEN 1 ELSE 0 END) AS TerminBekleyenSayisi,
    SUM(CASE WHEN lp.Code = 'APPROVED' THEN 1 ELSE 0 END) AS OnaylananSayisi,
    SUM(CASE WHEN lp.Code = 'REJECTED' THEN 1 ELSE 0 END) AS ReddedilenSayisi,
    SUM(CASE WHEN lp.Code = 'DELIVERY_PENDING' THEN 1 ELSE 0 END) AS TeslimEdilecekSayisi,
    SUM(CASE WHEN lp.Code = 'DELIVERED' THEN 1 ELSE 0 END) AS TeslimEdildiSayisi

FROM tmscrq.TMLead l
LEFT JOIN tmscrq.TMCustomer cu
    ON cu.Id = l.CustomerId
LEFT JOIN tmscrq.TMProduct p
    ON p.Id = l.ProductId
LEFT JOIN dbo.KUser sp
    ON sp.Id = l.SalesPersonKUserId
LEFT JOIN tmscrq.TMLeadProcess lp
    ON lp.Id = l.ProcessID

CROSS JOIN IsAdmin a

WHERE
(
    -- admin → full
    a.IsAdmin = 1

    -- diğerleri → sadece kendi mağazaları
    OR EXISTS
    (
        SELECT 1
        FROM tmscrq.TMUser tu
        WHERE tu.KUserID = @KUserId
          AND tu.StoreId = l.StoreId
    )
)

-- 🔽 AŞAĞISI SENİN ORİJİNAL FİLTRELER (HİÇ DOKUNMADIM)

AND
(
    @MusteriAdi IS NULL
    OR LTRIM(RTRIM(@MusteriAdi)) = ''
    OR UPPER(LTRIM(RTRIM(ISNULL(cu.Name, '') + ' ' + ISNULL(cu.LastName, ''))))
       LIKE '%' + UPPER(LTRIM(RTRIM(@MusteriAdi))) + '%'
)

AND
(
    @ProductName IS NULL
    OR LTRIM(RTRIM(@ProductName)) = ''
    OR
    (
        CHARINDEX(',', @ProductName) > 0
        AND ISNULL(LTRIM(RTRIM(p.ProductName)), '') IN
        (
            SELECT LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', '')))
            FROM STRING_SPLIT(CAST(@ProductName AS NVARCHAR(MAX)), ',')
        )
    )
    OR
    (
        CHARINDEX(',', @ProductName) = 0
        AND UPPER(ISNULL(LTRIM(RTRIM(p.ProductName)), ''))
            LIKE '%' + UPPER(LTRIM(RTRIM(@ProductName))) + '%'
    )
)

AND
(
    @LeadCode IS NULL
    OR LTRIM(RTRIM(@LeadCode)) = ''
    OR UPPER(ISNULL(LTRIM(RTRIM(l.LeadCode)), '')) LIKE '%' + UPPER(LTRIM(RTRIM(@LeadCode))) + '%'
)

AND
(
    @Tel IS NULL
    OR LTRIM(RTRIM(@Tel)) = ''
    OR UPPER(ISNULL(LTRIM(RTRIM(cu.Tel)), '')) LIKE '%' + UPPER(LTRIM(RTRIM(@Tel))) + '%'
)

AND
(
    @CategoryName IS NULL
    OR LTRIM(RTRIM(@CategoryName)) = ''
    OR
    (
        EXISTS
        (
            SELECT 1
            FROM STRING_SPLIT(CAST(@CategoryName AS NVARCHAR(MAX)), ',') c
            WHERE UPPER(LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(c.value, '""', ''), '[', ''), ']', '')))) = 'DEFAULT'
        )
        AND (p.CategoryName IS NULL OR LTRIM(RTRIM(p.CategoryName)) = '')
    )
    OR UPPER(ISNULL(LTRIM(RTRIM(p.CategoryName)), '')) IN
    (
        SELECT UPPER(LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', ''))))
        FROM STRING_SPLIT(CAST(@CategoryName AS NVARCHAR(MAX)), ',')
    )
)

AND
(
    @StoreIds IS NULL
    OR LTRIM(RTRIM(@StoreIds)) = ''
    OR EXISTS
    (
        SELECT 1
        FROM STRING_SPLIT(CAST(@StoreIds AS NVARCHAR(MAX)), ',') s
        WHERE l.StoreId = TRY_CONVERT
        (
            uniqueidentifier,
            LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(s.value, '""', ''), '[', ''), ']', '')))
        )
    )
)

AND
(
    @SatisDanismaniIds IS NULL
    OR LTRIM(RTRIM(@SatisDanismaniIds)) = ''
    OR EXISTS
    (
        SELECT 1
        FROM STRING_SPLIT(CAST(@SatisDanismaniIds AS NVARCHAR(MAX)), ',') s
        WHERE l.SalesPersonKUserId = TRY_CONVERT
        (
            uniqueidentifier,
            LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(s.value, '""', ''), '[', ''), ']', '')))
        )
    )
)

AND
(
    @ProcessCode IS NULL
    OR LTRIM(RTRIM(@ProcessCode)) = ''
    OR UPPER(ISNULL(LTRIM(RTRIM(lp.Code)), '')) IN
    (
        SELECT UPPER(LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', ''))))
        FROM STRING_SPLIT(CAST(@ProcessCode AS NVARCHAR(MAX)), ',')
    )
)

AND
(
    @StartDate IS NULL
    OR LTRIM(RTRIM(@StartDate)) = ''
    OR l.CreatedAt >= CONVERT(date, @StartDate)
)

AND
(
    @EndDate IS NULL
    OR LTRIM(RTRIM(@EndDate)) = ''
    OR l.CreatedAt < DATEADD(day, 1, CONVERT(date, @EndDate))
);", new string[] { "ToplamTalepSayisi", "OnayBekleyenSayisi", "TerminBekleyenSayisi", "OnaylananSayisi", "ReddedilenSayisi", "TeslimEdilecekSayisi", "TeslimEdildiSayisi" }, prms_TMLeadProcessCountSummary_1.ToArray());
            ;


            return Ok(result);
        }


        [HttpPost, Route("LeadListComponent_937502_onClick")]
        public IActionResult LeadListComponent_937502_onClick(LeadListComponent_937502_onClick_Request request)
        {

            KProviderManager.Authorization.IsAuthorizedForRoles(appId, appName, screenId, screenName, new List<string> { $"70de6cfc-6087-6059-59b4-0b5a8527af6b", "4da1f213-c8e4-0b50-5c84-02fd13f1a622", "c4e882ef-977d-f613-7694-230ac83919d2", "b4bfd39c-ac02-f442-c899-7a2374a45b47", "cdb536b0-6297-155f-d446-8453d8a60304", "TimesYonetici", "TimesUstYonetici", "TimesSatisPersoneli", "TimesMagazaMuduru", "TimesAdmin" });

            var result = new LeadListComponent_937502_onClick_Response();

            var prms_TM_GetLeads_0 = new List<kSqlParameter>();
            prms_TM_GetLeads_0.Add(new kSqlParameter() { Name = "StepOrder", Value = request.StepOrder_0 });
            prms_TM_GetLeads_0.Add(new kSqlParameter() { Name = "UserId", Value = Kuika.Common.KContext.CurrentUser?.Id });
            prms_TM_GetLeads_0.Add(new kSqlParameter() { Name = "MusteriAdi", Value = request.MusteriAdi_0 });
            prms_TM_GetLeads_0.Add(new kSqlParameter() { Name = "ProductName", Value = request.ProductName_0 });
            prms_TM_GetLeads_0.Add(new kSqlParameter() { Name = "LeadCode", Value = request.LeadCode_0 });
            prms_TM_GetLeads_0.Add(new kSqlParameter() { Name = "Tel", Value = request.Tel_0 });
            prms_TM_GetLeads_0.Add(new kSqlParameter() { Name = "CategoryName", Value = request.CategoryName_0 });
            prms_TM_GetLeads_0.Add(new kSqlParameter() { Name = "StoreIds", Value = request.StoreIds_0 });
            prms_TM_GetLeads_0.Add(new kSqlParameter() { Name = "SatisDanismaniIds", Value = request.SatisDanismaniIds_0 });
            prms_TM_GetLeads_0.Add(new kSqlParameter() { Name = "ProcessCode", Value = request.ProcessCode_0 });
            prms_TM_GetLeads_0.Add(new kSqlParameter() { Name = "StartDate", Value = request.StartDate_0 });
            prms_TM_GetLeads_0.Add(new kSqlParameter() { Name = "EndDate", Value = request.EndDate_0 });
            using var auditTM_GetLeads_0 = ActionAuditScope.Begin("6662a31b-f1e3-4f06-23eb-68f7370028f6", "TM_GetLeads", applicationName: "wbTimesCRM", screenOrEndpointName: "LeadList");
            result.TM_GetLeads = KPersister.Fetch(KContext.GetConnectionString(), @"-- SET LANGUAGE Turkish;

-- SELECT
-- CASE 
--     WHEN EXISTS (
--         SELECT 1 
--         FROM tmscrq.TMLeadReservation r
--         WHERE r.LeadId = l.Id
--           AND r.IsActive = 1
--           AND r.IsApproved = 1
--     ) THEN N'Evet'

--     WHEN EXISTS (
--         SELECT 1 
--         FROM tmscrq.TMLeadReservation r
--         WHERE r.LeadId = l.Id
--           AND r.IsActive = 1
--           AND ISNULL(r.IsApproved,0) = 0
--     ) THEN N'Onay Bekliyor'

--     ELSE N'Hayır'
-- END AS RezerveDurumu,
--     l.Id AS LeadId,
--     l.IsReserved,
--     ISNULL(NULLIF(LTRIM(RTRIM(l.LeadCode)), ''), '-') AS LeadNumarasi,
--     CONVERT(varchar(10), l.CreatedAt, 103) AS TalepTarihi,

--     p.Id AS ProductId,
--     ISNULL(NULLIF(LTRIM(RTRIM(p.ProductName)), ''), '-') AS ProductName,
--     ISNULL(NULLIF(LTRIM(RTRIM(p.Bracelet)), ''), '-') AS Bilezik,
--     ISNULL(NULLIF(LTRIM(RTRIM(p.Brand)), ''), '-') AS Brand,
--     ISNULL(NULLIF(LTRIM(RTRIM(p.Dial)), ''), '-') AS Kadran,
--     ISNULL(NULLIF(LTRIM(RTRIM(p.ProductCode)), ''), '-') AS RefCode,
--     ISNULL(NULLIF(LTRIM(RTRIM(p.Referance)), ''), '-') AS Referans,

--     ISNULL(
--         NULLIF(
--             LTRIM(RTRIM(ISNULL(cu.Name, '') + ' ' + ISNULL(cu.LastName, '')))
--         , '')
--     , '-') AS Musteri,

--     ISNULL(NULLIF(LTRIM(RTRIM(cu.CityName)), ''), '-') AS Lokasyon,
--     ISNULL(NULLIF(LTRIM(RTRIM(cu.DistrictName)), ''), '-') AS Ilce,
--     ISNULL(NULLIF(LTRIM(RTRIM(cu.CountryName)), ''), '-') AS Ulke,
--     ISNULL(NULLIF(LTRIM(RTRIM(cu.Info)), ''), '-') AS MusteriInfo,

--     CASE
--         WHEN cu.IsShopping = 1 THEN N'Evet'
--         WHEN cu.IsShopping = 0 THEN N'Hayır'
--         ELSE '-'
--     END AS AlisverisiVarMi,

--     ISNULL(NULLIF(LTRIM(RTRIM(cu.Tel)), ''), '-') AS IrtibatNumarasi,
--     ISNULL(NULLIF(LTRIM(RTRIM(cu.Email)), ''), '-') AS EmailAdresi,

--     ISNULL(NULLIF(LTRIM(RTRIM(cr.ContactResourceName)), ''), '-') AS IletisimKaynagi,

--     ISNULL(NULLIF(LTRIM(RTRIM(p.CategoryName)), ''), '-') AS CategoryName,
--     '-' AS CategoryCode,

--     ISNULL(NULLIF(LTRIM(RTRIM(ls.Name)), ''), '-') AS LeadDurumu,
--     ISNULL(NULLIF(LTRIM(RTRIM(ns.Name)), ''), '-') AS SonrakiAdim,

--     ISNULL(NULLIF(LTRIM(RTRIM(lp.Name)), ''), '-') AS ProcessName,
--     ISNULL(NULLIF(LTRIM(RTRIM(lp.Code)), ''), '-') AS ProcessCode,
--     lp.StepOrder,
-- CASE
--     WHEN EXISTS
--     (
--         SELECT 1
--         FROM tmscrq.TMLeadReservation r
--         WHERE r.LeadId = l.Id
--           AND r.IsActive = 1
--           AND ISNULL(r.IsApproved,0) = 0
--     )
--     THEN 10
--     ELSE lp.StepOrder
-- END AS SelectedStepOrder,

--     ISNULL(
--         CASE
--             WHEN l.EstimatedDate IS NOT NULL
--             THEN CAST(YEAR(l.EstimatedDate) AS VARCHAR(4)) + ' ' + DATENAME(MONTH, l.EstimatedDate)
--             ELSE NULL
--         END,
--         '-'
--     ) AS TerminTarihi,

--     ISNULL(
--         NULLIF(
--             LTRIM(RTRIM(ISNULL(sp.FirstName, '') + ' ' + ISNULL(sp.LastName, '')))
--         , '')
--     , '-') AS SatisDanismani,

--     ISNULL(NULLIF(LTRIM(RTRIM(st.StoreDesc)), ''), '-') AS StoreName

-- FROM tmscrq.TMLead l
-- LEFT JOIN tmscrq.TMLeadStatu ls
--     ON ls.Id = l.StatuId
-- LEFT JOIN tmscrq.TMCustomer cu
--     ON cu.Id = l.CustomerId
-- LEFT JOIN tmscrq.TMProduct p
--     ON p.Id = l.ProductId
-- LEFT JOIN tmscrq.TMContactResource cr
--     ON cr.Id = l.ContactResourceId
-- LEFT JOIN dbo.KUser sp
--     ON sp.Id = l.SalesPersonKUserId
-- LEFT JOIN tmscrq.TMStore st
--     ON st.Id = l.StoreId
-- LEFT JOIN tmscrq.TMLeadProcess lp
--     ON lp.Id = l.ProcessID
-- LEFT JOIN tmscrq.TMLeadNextStep ns
--     ON ns.Id = l.NextStepId

-- WHERE
-- (
--     EXISTS
--     (
--         SELECT 1
--         FROM dbo.KUserRole ur
--         INNER JOIN dbo.KRole r
--             ON r.Id = ur.KRole_Id
--         WHERE ur.KUser_Id = @UserId
--           AND ur.IsDeleted = 0
--           AND r.IsDeleted = 0
--           AND r.Name IN ('TimesYonetici', 'TimesUstYonetici')
--     )
--     OR
--     (
--         EXISTS
--         (
--             SELECT 1
--             FROM dbo.KUserRole ur
--             INNER JOIN dbo.KRole r
--                 ON r.Id = ur.KRole_Id
--             WHERE ur.KUser_Id = @UserId
--               AND ur.IsDeleted = 0
--               AND r.IsDeleted = 0
--               AND r.Name IN ('TimesMagazaMuduru', 'TimesSatisPersoneli')
--         )
--         AND EXISTS
--         (
--             SELECT 1
--             FROM tmscrq.TMUser tu
--             WHERE tu.KUserID = @UserId
--               AND tu.StoreId = l.StoreId
--         )
--     )
-- )

-- AND
-- (
--     @MusteriAdi IS NULL
--     OR LTRIM(RTRIM(@MusteriAdi)) = ''
--     OR UPPER(LTRIM(RTRIM(ISNULL(cu.Name,'') + ' ' + ISNULL(cu.LastName,''))))
--        LIKE '%' + UPPER(LTRIM(RTRIM(@MusteriAdi))) + '%'
-- )

-- AND
-- (
--     @ProductName IS NULL
--     OR LTRIM(RTRIM(@ProductName)) = ''
--     OR
--     (
--         CHARINDEX(',', @ProductName) > 0
--         AND ISNULL(LTRIM(RTRIM(p.ProductName)), '') IN
--         (
--             SELECT LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', '')))
--             FROM STRING_SPLIT(CAST(@ProductName AS NVARCHAR(MAX)), ',')
--             WHERE LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', ''))) <> ''
--         )
--     )
--     OR
--     (
--         CHARINDEX(',', @ProductName) = 0
--         AND UPPER(ISNULL(LTRIM(RTRIM(p.ProductName)), ''))
--             LIKE '%' + UPPER(LTRIM(RTRIM(@ProductName))) + '%'
--     )
-- )

-- AND
-- (
--     @LeadCode IS NULL
--     OR LTRIM(RTRIM(@LeadCode)) = ''
--     OR UPPER(ISNULL(LTRIM(RTRIM(l.LeadCode)), '')) LIKE '%' + UPPER(LTRIM(RTRIM(@LeadCode))) + '%'
-- )

-- AND
-- (
--     @Tel IS NULL
--     OR LTRIM(RTRIM(@Tel)) = ''
--     OR UPPER(ISNULL(LTRIM(RTRIM(cu.Tel)), '')) LIKE '%' + UPPER(LTRIM(RTRIM(@Tel))) + '%'
-- )

-- -- AND
-- -- (
-- --     @CategoryName IS NULL
-- --     OR LTRIM(RTRIM(@CategoryName)) = ''
-- --     OR
-- --     (
-- --         EXISTS
-- --         (
-- --             SELECT 1
-- --             FROM STRING_SPLIT(CAST(@CategoryName AS NVARCHAR(MAX)), ',') c
-- --             WHERE UPPER(LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(c.value, '""', ''), '[', ''), ']', '')))) = 'DEFAULT'
-- --         )
-- --         AND (p.CategoryName IS NULL OR LTRIM(RTRIM(p.CategoryName)) = '')
-- --     )
-- --     OR UPPER(ISNULL(LTRIM(RTRIM(p.CategoryName)), '')) IN
-- --     (
-- --         SELECT UPPER(LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', ''))))
-- --         FROM STRING_SPLIT(CAST(@CategoryName AS NVARCHAR(MAX)), ',')
-- --         WHERE LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', ''))) <> ''
-- --           AND UPPER(LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', '')))) <> 'DEFAULT'
-- --     )
-- -- )

-- AND
-- (
--     @CategoryName IS NULL
--     OR LTRIM(RTRIM(@CategoryName)) = ''
--     OR UPPER(ISNULL(LTRIM(RTRIM(p.CategoryName)), '')) IN
--     (
--         SELECT UPPER(LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value,'""',''),'[',''),']',''))))
--         FROM STRING_SPLIT(CAST(@CategoryName AS NVARCHAR(MAX)), ',')
--         WHERE LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value,'""',''),'[',''),']',''))) <> ''
--     )
-- )

-- AND
-- (
--     @StoreIds IS NULL
--     OR LTRIM(RTRIM(@StoreIds)) = ''
--     OR EXISTS
--     (
--         SELECT 1
--         FROM STRING_SPLIT(CAST(@StoreIds AS NVARCHAR(MAX)), ',') s
--         WHERE l.StoreId = TRY_CONVERT
--         (
--             uniqueidentifier,
--             LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(s.value, '""', ''), '[', ''), ']', '')))
--         )
--     )
-- )

-- AND
-- (
--     @SatisDanismaniIds IS NULL
--     OR LTRIM(RTRIM(@SatisDanismaniIds)) = ''
--     OR EXISTS
--     (
--         SELECT 1
--         FROM STRING_SPLIT(CAST(@SatisDanismaniIds AS NVARCHAR(MAX)), ',') s
--         WHERE l.SalesPersonKUserId = TRY_CONVERT
--         (
--             uniqueidentifier,
--             LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(s.value, '""', ''), '[', ''), ']', '')))
--         )
--     )
-- )

-- AND
-- (
--     @ProcessCode IS NULL
--     OR LTRIM(RTRIM(@ProcessCode)) = ''
--     OR UPPER(ISNULL(LTRIM(RTRIM(lp.Code)), '')) IN
--     (
--         SELECT UPPER(LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', ''))))
--         FROM STRING_SPLIT(CAST(@ProcessCode AS NVARCHAR(MAX)), ',')
--         WHERE LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', ''))) <> ''
--     )
-- )

-- AND
-- (
--     @StepOrder IS NULL

--     OR
--     (
--         @StepOrder = 10
--         AND EXISTS
--         (
--             SELECT 1
--             FROM tmscrq.TMLeadReservation r
--             WHERE r.LeadId = l.Id
--               AND r.IsActive = 1
--               AND ISNULL(r.IsApproved,0) = 0
--         )
--     )

--     OR
--     (
--         @StepOrder <> 10
--         AND lp.StepOrder = @StepOrder
--     )
-- )

-- AND
-- (
--     @StartDate IS NULL
--     OR LTRIM(RTRIM(@StartDate)) = ''
--     OR l.CreatedAt >= CONVERT(date, @StartDate)
-- )

-- AND
-- (
--     @EndDate IS NULL
--     OR LTRIM(RTRIM(@EndDate)) = ''
--     OR l.CreatedAt < DATEADD(day, 1, CONVERT(date, @EndDate))
-- )

-- ORDER BY l.CreatedAt DESC;

------------------------++++++++++++++++++++++++-------------------
-- SET LANGUAGE Turkish;

-- SELECT
-- CASE 
--     WHEN EXISTS (
--         SELECT 1 
--         FROM tmscrq.TMLeadReservation r
--         WHERE r.LeadId = l.Id
--           AND r.IsActive = 1
--           AND r.IsApproved = 1
--     ) THEN N'Evet'

--     WHEN EXISTS (
--         SELECT 1 
--         FROM tmscrq.TMLeadReservation r
--         WHERE r.LeadId = l.Id
--           AND r.IsActive = 1
--           AND ISNULL(r.IsApproved,0) = 0
--     ) THEN N'Onay Bekliyor'

--     ELSE N'Hayır'
-- END AS RezerveDurumu,
--     l.Id AS LeadId,
--     l.IsReserved,
--     ISNULL(NULLIF(LTRIM(RTRIM(l.LeadCode)), ''), '-') AS LeadNumarasi,
--     CONVERT(varchar(10), l.CreatedAt, 103) AS TalepTarihi,

--     p.Id AS ProductId,
--     ISNULL(NULLIF(LTRIM(RTRIM(p.ProductName)), ''), '-') AS ProductName,
--     ISNULL(NULLIF(LTRIM(RTRIM(p.Bracelet)), ''), '-') AS Bilezik,
--     ISNULL(NULLIF(LTRIM(RTRIM(p.Brand)), ''), '-') AS Brand,
--     ISNULL(NULLIF(LTRIM(RTRIM(p.Dial)), ''), '-') AS Kadran,
--     ISNULL(NULLIF(LTRIM(RTRIM(p.ProductCode)), ''), '-') AS RefCode,
--     ISNULL(NULLIF(LTRIM(RTRIM(p.Referance)), ''), '-') AS Referans,

--     ISNULL(
--         NULLIF(
--             LTRIM(RTRIM(ISNULL(cu.Name, '') + ' ' + ISNULL(cu.LastName, '')))
--         , '')
--     , '-') AS Musteri,

--     ISNULL(NULLIF(LTRIM(RTRIM(cu.CityName)), ''), '-') AS Lokasyon,
--     ISNULL(NULLIF(LTRIM(RTRIM(cu.DistrictName)), ''), '-') AS Ilce,
--     ISNULL(NULLIF(LTRIM(RTRIM(cu.CountryName)), ''), '-') AS Ulke,
--     ISNULL(NULLIF(LTRIM(RTRIM(cu.Info)), ''), '-') AS MusteriInfo,

--     CASE
--         WHEN cu.IsShopping = 1 THEN N'Evet'
--         WHEN cu.IsShopping = 0 THEN N'Hayır'
--         ELSE '-'
--     END AS AlisverisiVarMi,

--     ISNULL(NULLIF(LTRIM(RTRIM(cu.Tel)), ''), '-') AS IrtibatNumarasi,
--     ISNULL(NULLIF(LTRIM(RTRIM(cu.Email)), ''), '-') AS EmailAdresi,

--     ISNULL(NULLIF(LTRIM(RTRIM(cr.ContactResourceName)), ''), '-') AS IletisimKaynagi,

--     ISNULL(NULLIF(LTRIM(RTRIM(p.CategoryName)), ''), '-') AS CategoryName,
--     '-' AS CategoryCode,

--     ISNULL(NULLIF(LTRIM(RTRIM(ls.Name)), ''), '-') AS LeadDurumu,
--     ISNULL(NULLIF(LTRIM(RTRIM(ns.Name)), ''), '-') AS SonrakiAdim,

--     ISNULL(NULLIF(LTRIM(RTRIM(lp.Name)), ''), '-') AS ProcessName,
--     ISNULL(NULLIF(LTRIM(RTRIM(lp.Code)), ''), '-') AS ProcessCode,
--     lp.StepOrder,
    
--     -- DÜZELTİLEN ALAN: SelectedStepOrder
--     CASE
--         WHEN EXISTS
--         (
--             SELECT 1
--             FROM tmscrq.TMLeadReservation r
--             WHERE r.LeadId = l.Id
--               AND r.IsActive = 1
--               AND ISNULL(r.IsApproved,0) = 0
--         )
--         THEN 10
--         ELSE lp.StepOrder
--     END AS SelectedStepOrder,

--     ISNULL(
--         CASE
--             WHEN l.EstimatedDate IS NOT NULL
--             THEN CAST(YEAR(l.EstimatedDate) AS VARCHAR(4)) + ' ' + DATENAME(MONTH, l.EstimatedDate)
--             ELSE NULL
--         END,
--         '-'
--     ) AS TerminTarihi,

--     ISNULL(
--         NULLIF(
--             LTRIM(RTRIM(ISNULL(sp.FirstName, '') + ' ' + ISNULL(sp.LastName, '')))
--         , '')
--     , '-') AS SatisDanismani,

--     ISNULL(NULLIF(LTRIM(RTRIM(st.StoreDesc)), ''), '-') AS StoreName

-- FROM tmscrq.TMLead l
-- LEFT JOIN tmscrq.TMLeadStatu ls
--     ON ls.Id = l.StatuId
-- LEFT JOIN tmscrq.TMCustomer cu
--     ON cu.Id = l.CustomerId
-- LEFT JOIN tmscrq.TMProduct p
--     ON p.Id = l.ProductId
-- LEFT JOIN tmscrq.TMContactResource cr
--     ON cr.Id = l.ContactResourceId
-- LEFT JOIN dbo.KUser sp
--     ON sp.Id = l.SalesPersonKUserId
-- LEFT JOIN tmscrq.TMStore st
--     ON st.Id = l.StoreId
-- LEFT JOIN tmscrq.TMLeadProcess lp
--     ON lp.Id = l.ProcessID
-- LEFT JOIN tmscrq.TMLeadNextStep ns
--     ON ns.Id = l.NextStepId

-- WHERE
-- (
--     EXISTS
--     (
--         SELECT 1
--         FROM dbo.KUserRole ur
--         INNER JOIN dbo.KRole r
--             ON r.Id = ur.KRole_Id
--         WHERE ur.KUser_Id = @UserId
--           AND ur.IsDeleted = 0
--           AND r.IsDeleted = 0
--           AND r.Name IN ('TimesYonetici', 'TimesUstYonetici')
--     )
--     OR
--     (
--         EXISTS
--         (
--             SELECT 1
--             FROM dbo.KUserRole ur
--             INNER JOIN dbo.KRole r
--                 ON r.Id = ur.KRole_Id
--             WHERE ur.KUser_Id = @UserId
--               AND ur.IsDeleted = 0
--               AND r.IsDeleted = 0
--               AND r.Name IN ('TimesMagazaMuduru', 'TimesSatisPersoneli')
--         )
--         AND EXISTS
--         (
--             SELECT 1
--             FROM tmscrq.TMUser tu
--             WHERE tu.KUserID = @UserId
--               AND tu.StoreId = l.StoreId
--         )
--     )
-- )

-- AND
-- (
--     @MusteriAdi IS NULL
--     OR LTRIM(RTRIM(@MusteriAdi)) = ''
--     OR UPPER(LTRIM(RTRIM(ISNULL(cu.Name,'') + ' ' + ISNULL(cu.LastName,''))))
--        LIKE '%' + UPPER(LTRIM(RTRIM(@MusteriAdi))) + '%'
-- )

-- AND
-- (
--     @ProductName IS NULL
--     OR LTRIM(RTRIM(@ProductName)) = ''
--     OR
--     (
--         CHARINDEX(',', @ProductName) > 0
--         AND ISNULL(LTRIM(RTRIM(p.ProductName)), '') IN
--         (
--             SELECT LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', '')))
--             FROM STRING_SPLIT(CAST(@ProductName AS NVARCHAR(MAX)), ',')
--             WHERE LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', ''))) <> ''
--         )
--     )
--     OR
--     (
--         CHARINDEX(',', @ProductName) = 0
--         AND UPPER(ISNULL(LTRIM(RTRIM(p.ProductName)), ''))
--             LIKE '%' + UPPER(LTRIM(RTRIM(@ProductName))) + '%'
--     )
-- )

-- AND
-- (
--     @LeadCode IS NULL
--     OR LTRIM(RTRIM(@LeadCode)) = ''
--     OR UPPER(ISNULL(LTRIM(RTRIM(l.LeadCode)), '')) LIKE '%' + UPPER(LTRIM(RTRIM(@LeadCode))) + '%'
-- )

-- AND
-- (
--     @Tel IS NULL
--     OR LTRIM(RTRIM(@Tel)) = ''
--     OR UPPER(ISNULL(LTRIM(RTRIM(cu.Tel)), '')) LIKE '%' + UPPER(LTRIM(RTRIM(@Tel))) + '%'
-- )

-- AND
-- (
--     @CategoryName IS NULL
--     OR LTRIM(RTRIM(@CategoryName)) = ''
--     OR UPPER(ISNULL(LTRIM(RTRIM(p.CategoryName)), '')) IN
--     (
--         SELECT UPPER(LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value,'""',''),'[',''),']',''))))
--         FROM STRING_SPLIT(CAST(@CategoryName AS NVARCHAR(MAX)), ',')
--         WHERE LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value,'""',''),'[',''),']',''))) <> ''
--     )
-- )

-- AND
-- (
--     @StoreIds IS NULL
--     OR LTRIM(RTRIM(@StoreIds)) = ''
--     OR EXISTS
--     (
--         SELECT 1
--         FROM STRING_SPLIT(CAST(@StoreIds AS NVARCHAR(MAX)), ',') s
--         WHERE l.StoreId = TRY_CONVERT
--         (
--             uniqueidentifier,
--             LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(s.value, '""', ''), '[', ''), ']', '')))
--         )
--     )
-- )

-- AND
-- (
--     @SatisDanismaniIds IS NULL
--     OR LTRIM(RTRIM(@SatisDanismaniIds)) = ''
--     OR EXISTS
--     (
--         SELECT 1
--         FROM STRING_SPLIT(CAST(@SatisDanismaniIds AS NVARCHAR(MAX)), ',') s
--         WHERE l.SalesPersonKUserId = TRY_CONVERT
--         (
--             uniqueidentifier,
--             LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(s.value, '""', ''), '[', ''), ']', '')))
--         )
--     )
-- )

-- AND
-- (
--     @ProcessCode IS NULL
--     OR LTRIM(RTRIM(@ProcessCode)) = ''
--     OR UPPER(ISNULL(LTRIM(RTRIM(lp.Code)), '')) IN
--     (
--         SELECT UPPER(LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', ''))))
--         FROM STRING_SPLIT(CAST(@ProcessCode AS NVARCHAR(MAX)), ',')
--         WHERE LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', ''))) <> ''
--     )
-- )

-- -- DÜZELTİLEN ALAN: @StepOrder Filtresi (tek blok)
-- AND
-- (
--     @StepOrder IS NULL

--     OR

--     (
--         @StepOrder = 10
--         AND EXISTS
--         (
--             SELECT 1
--             FROM tmscrq.TMLeadReservation r
--             WHERE r.LeadId = l.Id
--               AND r.IsActive = 1
--               AND ISNULL(r.IsApproved,0) = 0
--         )
--     )

--     OR

--     (
--         @StepOrder <> 10
--         AND lp.StepOrder = @StepOrder
--     )
-- )

-- AND
-- (
--     @StartDate IS NULL
--     OR LTRIM(RTRIM(@StartDate)) = ''
--     OR l.CreatedAt >= CONVERT(date, @StartDate)
-- )

-- AND
-- (
--     @EndDate IS NULL
--     OR LTRIM(RTRIM(@EndDate)) = ''
--     OR l.CreatedAt < DATEADD(day, 1, CONVERT(date, @EndDate))
-- )

-- ORDER BY l.CreatedAt DESC;



SET LANGUAGE Turkish;

SELECT
CASE 
    WHEN EXISTS (
        SELECT 1 
        FROM tmscrq.TMLeadReservation r
        WHERE r.LeadId = l.Id
          AND r.IsActive = 1
          AND r.IsApproved = 1
    ) THEN N'Evet'

    WHEN EXISTS (
        SELECT 1 
        FROM tmscrq.TMLeadReservation r
        WHERE r.LeadId = l.Id
          AND r.IsActive = 1
          AND ISNULL(r.IsApproved,0) = 0
    ) THEN N'Onay Bekliyor'

    ELSE N'Hayır'
END AS RezerveDurumu,
    l.Id AS LeadId,
    l.IsReserved,
    ISNULL(NULLIF(LTRIM(RTRIM(l.LeadCode)), ''), '-') AS LeadNumarasi,
     FORMAT(l.CreatedAt, 'dd MMMM yyyy', 'tr-TR') AS TalepTarihi,

    p.Id AS ProductId,
    ISNULL(NULLIF(LTRIM(RTRIM(p.ProductName)), ''), '-') AS ProductName,
    ISNULL(NULLIF(LTRIM(RTRIM(p.Bracelet)), ''), '-') AS Bilezik,
    ISNULL(NULLIF(LTRIM(RTRIM(p.Brand)), ''), '-') AS Brand,
    ISNULL(NULLIF(LTRIM(RTRIM(p.Dial)), ''), '-') AS Kadran,
    ISNULL(NULLIF(LTRIM(RTRIM(p.ProductCode)), ''), '-') AS RefCode,
    ISNULL(NULLIF(LTRIM(RTRIM(p.Referance)), ''), '-') AS Referans,

    ISNULL(
        NULLIF(
            LTRIM(RTRIM(ISNULL(cu.Name, '') + ' ' + ISNULL(cu.LastName, '')))
        , '')
    , '-') AS Musteri,

    ISNULL(NULLIF(LTRIM(RTRIM(cu.CityName)), ''), '-') AS Lokasyon,
    ISNULL(NULLIF(LTRIM(RTRIM(cu.DistrictName)), ''), '-') AS Ilce,
    ISNULL(NULLIF(LTRIM(RTRIM(cu.CountryName)), ''), '-') AS Ulke,
    ISNULL(NULLIF(LTRIM(RTRIM(cu.Info)), ''), '-') AS MusteriInfo,

    CASE
        WHEN cu.IsShopping = 1 THEN N'Evet'
        WHEN cu.IsShopping = 0 THEN N'Hayır'
        ELSE '-'
    END AS AlisverisiVarMi,

    ISNULL(NULLIF(LTRIM(RTRIM(cu.Tel)), ''), '-') AS IrtibatNumarasi,
    ISNULL(NULLIF(LTRIM(RTRIM(cu.Email)), ''), '-') AS EmailAdresi,

    ISNULL(NULLIF(LTRIM(RTRIM(cr.ContactResourceName)), ''), '-') AS IletisimKaynagi,

    ISNULL(NULLIF(LTRIM(RTRIM(p.CategoryName)), ''), '-') AS CategoryName,
    '-' AS CategoryCode,

    ISNULL(NULLIF(LTRIM(RTRIM(ls.Name)), ''), '-') AS LeadDurumu,
    ISNULL(NULLIF(LTRIM(RTRIM(ns.Name)), ''), '-') AS SonrakiAdim,

    ISNULL(NULLIF(LTRIM(RTRIM(lp.Name)), ''), '-') AS ProcessName,
    ISNULL(NULLIF(LTRIM(RTRIM(lp.Code)), ''), '-') AS ProcessCode,
    lp.StepOrder,
    
    -- DÜZELTİLEN ALAN: SelectedStepOrder
    CASE
        WHEN EXISTS
        (
            SELECT 1
            FROM tmscrq.TMLeadReservation r
            WHERE r.LeadId = l.Id
              AND r.IsActive = 1
              AND ISNULL(r.IsApproved,0) = 0
        )
        THEN 10
        ELSE lp.StepOrder
    END AS SelectedStepOrder,

    ISNULL(
        CASE
            WHEN l.EstimatedDate IS NOT NULL
            THEN CAST(YEAR(l.EstimatedDate) AS VARCHAR(4)) + ' ' + DATENAME(MONTH, l.EstimatedDate)
            ELSE NULL
        END,
        '-'
    ) AS TerminTarihi,

    ISNULL(
        NULLIF(
            LTRIM(RTRIM(ISNULL(sp.FirstName, '') + ' ' + ISNULL(sp.LastName, '')))
        , '')
    , '-') AS SatisDanismani,

    ISNULL(NULLIF(LTRIM(RTRIM(st.StoreDesc)), ''), '-') AS StoreName

FROM tmscrq.TMLead l
LEFT JOIN tmscrq.TMLeadStatu ls
    ON ls.Id = l.StatuId
LEFT JOIN tmscrq.TMCustomer cu
    ON cu.Id = l.CustomerId
LEFT JOIN tmscrq.TMProduct p
    ON p.Id = l.ProductId
LEFT JOIN tmscrq.TMContactResource cr
    ON cr.Id = l.ContactResourceId
LEFT JOIN dbo.KUser sp
    ON sp.Id = l.SalesPersonKUserId
LEFT JOIN tmscrq.TMStore st
    ON st.Id = l.StoreId
LEFT JOIN tmscrq.TMLeadProcess lp
    ON lp.Id = l.ProcessID
LEFT JOIN tmscrq.TMLeadNextStep ns
    ON ns.Id = l.NextStepId

WHERE
(
    EXISTS
    (
        SELECT 1
        FROM dbo.KUserRole ur
        INNER JOIN dbo.KRole r
            ON r.Id = ur.KRole_Id
        WHERE ur.KUser_Id = @UserId
          AND ur.IsDeleted = 0
          AND r.IsDeleted = 0
          AND r.Name IN ('TimesYonetici', 'TimesUstYonetici')
    )
    OR
    (
        EXISTS
        (
            SELECT 1
            FROM dbo.KUserRole ur
            INNER JOIN dbo.KRole r
                ON r.Id = ur.KRole_Id
            WHERE ur.KUser_Id = @UserId
              AND ur.IsDeleted = 0
              AND r.IsDeleted = 0
              AND r.Name IN ('TimesMagazaMuduru', 'TimesSatisPersoneli')
        )
        AND EXISTS
        (
            SELECT 1
            FROM tmscrq.TMUser tu
            WHERE tu.KUserID = @UserId
              AND tu.StoreId = l.StoreId
        )
    )
)

AND
(
    ISNULL(@MusteriAdi, '') = ''
    OR UPPER(ISNULL(cu.Name, '')) LIKE '%' + UPPER(LTRIM(RTRIM(@MusteriAdi))) + '%'
    OR UPPER(ISNULL(cu.LastName, '')) LIKE '%' + UPPER(LTRIM(RTRIM(@MusteriAdi))) + '%'
    OR UPPER(
        ISNULL(cu.Name, '') + ' ' + ISNULL(cu.LastName, '')
    ) LIKE '%' + UPPER(LTRIM(RTRIM(@MusteriAdi))) + '%'
)

AND
(
    @ProductName IS NULL
    OR LTRIM(RTRIM(@ProductName)) = ''
    OR
    (
        CHARINDEX(',', @ProductName) > 0
        AND ISNULL(LTRIM(RTRIM(p.ProductName)), '') IN
        (
            SELECT LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', '')))
            FROM STRING_SPLIT(CAST(@ProductName AS NVARCHAR(MAX)), ',')
            WHERE LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', ''))) <> ''
        )
    )
    OR
    (
        CHARINDEX(',', @ProductName) = 0
        AND UPPER(ISNULL(LTRIM(RTRIM(p.ProductName)), ''))
            LIKE '%' + UPPER(LTRIM(RTRIM(@ProductName))) + '%'
    )
)

AND
(
    ISNULL(@LeadCode, '') = ''
    OR UPPER(ISNULL(l.LeadCode, ''))
        LIKE '%' + UPPER(LTRIM(RTRIM(@LeadCode))) + '%'
    OR REPLACE(
        REPLACE(
            REPLACE(
                UPPER(ISNULL(l.LeadCode, '')),
                '-', ''
            ),
            ' ', ''
        ),
        '/', ''
    )
    LIKE '%' +
    REPLACE(
        REPLACE(
            REPLACE(
                UPPER(LTRIM(RTRIM(@LeadCode))),
                '-', ''
            ),
            ' ', ''
        ),
        '/', ''
    )
    + '%'
)

AND
(
    @Tel IS NULL
    OR LTRIM(RTRIM(@Tel)) = ''
    OR UPPER(ISNULL(LTRIM(RTRIM(cu.Tel)), '')) LIKE '%' + UPPER(LTRIM(RTRIM(@Tel))) + '%'
)

AND
(
    @CategoryName IS NULL
    OR LTRIM(RTRIM(@CategoryName)) = ''
    OR UPPER(ISNULL(LTRIM(RTRIM(p.CategoryName)), '')) IN
    (
        SELECT UPPER(LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value,'""',''),'[',''),']',''))))
        FROM STRING_SPLIT(CAST(@CategoryName AS NVARCHAR(MAX)), ',')
        WHERE LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value,'""',''),'[',''),']',''))) <> ''
    )
)

AND
(
    @StoreIds IS NULL
    OR LTRIM(RTRIM(@StoreIds)) = ''
    OR EXISTS
    (
        SELECT 1
        FROM STRING_SPLIT(CAST(@StoreIds AS NVARCHAR(MAX)), ',') s
        WHERE l.StoreId = TRY_CONVERT
        (
            uniqueidentifier,
            LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(s.value, '""', ''), '[', ''), ']', '')))
        )
    )
)

AND
(
    @SatisDanismaniIds IS NULL
    OR LTRIM(RTRIM(@SatisDanismaniIds)) = ''
    OR EXISTS
    (
        SELECT 1
        FROM STRING_SPLIT(CAST(@SatisDanismaniIds AS NVARCHAR(MAX)), ',') s
        WHERE l.SalesPersonKUserId = TRY_CONVERT
        (
            uniqueidentifier,
            LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(s.value, '""', ''), '[', ''), ']', '')))
        )
    )
)

AND
(
    ISNULL(@ProcessCode, '') = ''
    OR EXISTS
    (
        SELECT 1
        FROM STRING_SPLIT(
            CONVERT(NVARCHAR(MAX), @ProcessCode),
            ','
        ) AS s
        WHERE
            UPPER(LTRIM(RTRIM(s.value))) =
            UPPER(LTRIM(RTRIM(ISNULL(lp.Code, ''))))
    )
)

-- DÜZELTİLEN ALAN: @StepOrder Filtresi (0 verilince tümü gelsin)
AND
(
    @StepOrder IS NULL
    OR @StepOrder = 0  -- 👈 YENİ EKLENDI: 0 verilince tüm kayıtlar gelir
    OR
    (
        @StepOrder = 10
        AND EXISTS
        (
            SELECT 1
            FROM tmscrq.TMLeadReservation r
            WHERE r.LeadId = l.Id
              AND r.IsActive = 1
              AND ISNULL(r.IsApproved,0) = 0
        )
    )
    OR
    (
        @StepOrder <> 10
        AND lp.StepOrder = @StepOrder
    )
)

AND
(
    @StartDate IS NULL
    OR LTRIM(RTRIM(@StartDate)) = ''
    OR l.CreatedAt >= CONVERT(date, @StartDate)
)

AND
(
    @EndDate IS NULL
    OR LTRIM(RTRIM(@EndDate)) = ''
    OR l.CreatedAt < DATEADD(day, 1, CONVERT(date, @EndDate))
)

ORDER BY l.CreatedAt DESC;", new string[] { "RezerveDurumu", "LeadId", "IsReserved", "LeadNumarasi", "TalepTarihi", "ProductId", "ProductName", "Bilezik", "Brand", "Kadran", "RefCode", "Referans", "Musteri", "Lokasyon", "Ilce", "Ulke", "MusteriInfo", "AlisverisiVarMi", "IrtibatNumarasi", "EmailAdresi", "IletisimKaynagi", "CategoryName", "CategoryCode", "LeadDurumu", "SonrakiAdim", "ProcessName", "ProcessCode", "StepOrder", "SelectedStepOrder", "TerminTarihi", "SatisDanismani", "StoreName" }, prms_TM_GetLeads_0.ToArray());
            ;

            var prms_TMLeadProcessCountSummary_1 = new List<kSqlParameter>();
            prms_TMLeadProcessCountSummary_1.Add(new kSqlParameter() { Name = "UserId", Value = Kuika.Common.KContext.CurrentUser?.Id });
            prms_TMLeadProcessCountSummary_1.Add(new kSqlParameter() { Name = "MusteriAdi", Value = request.MusteriAdi_1 });
            prms_TMLeadProcessCountSummary_1.Add(new kSqlParameter() { Name = "ProductName", Value = request.ProductName_1 });
            prms_TMLeadProcessCountSummary_1.Add(new kSqlParameter() { Name = "LeadCode", Value = request.LeadCode_1 });
            prms_TMLeadProcessCountSummary_1.Add(new kSqlParameter() { Name = "Tel", Value = request.Tel_1 });
            prms_TMLeadProcessCountSummary_1.Add(new kSqlParameter() { Name = "CategoryName", Value = request.CategoryName_1 });
            prms_TMLeadProcessCountSummary_1.Add(new kSqlParameter() { Name = "StoreIds", Value = request.StoreIds_1 });
            prms_TMLeadProcessCountSummary_1.Add(new kSqlParameter() { Name = "SatisDanismaniIds", Value = request.SatisDanismaniIds_1 });
            prms_TMLeadProcessCountSummary_1.Add(new kSqlParameter() { Name = "ProcessCode", Value = request.ProcessCode_1 });
            prms_TMLeadProcessCountSummary_1.Add(new kSqlParameter() { Name = "StartDate", Value = request.StartDate_1 });
            prms_TMLeadProcessCountSummary_1.Add(new kSqlParameter() { Name = "EndDate", Value = request.EndDate_1 });
            using var auditTMLeadProcessCountSummary_1 = ActionAuditScope.Begin("137bfac4-4cf3-f2c6-2735-c33f4b8de051", "TMLeadProcessCountSummary", applicationName: "wbTimesCRM", screenOrEndpointName: "LeadList");
            result.TMLeadProcessCountSummary = KPersister.Fetch(KContext.GetConnectionString(), @"-- SELECT
--     COUNT(*) AS ToplamTalepSayisi,

--     SUM(CASE WHEN lp.Code = 'PENDING' THEN 1 ELSE 0 END) AS OnayBekleyenSayisi,
--     SUM(CASE WHEN lp.Code = 'TERMIN_PENDING' THEN 1 ELSE 0 END) AS TerminBekleyenSayisi,
--     SUM(CASE WHEN lp.Code = 'APPROVED' THEN 1 ELSE 0 END) AS OnaylananSayisi,
--     SUM(CASE WHEN lp.Code = 'REJECTED' THEN 1 ELSE 0 END) AS ReddedilenSayisi,
--     SUM(CASE WHEN lp.Code = 'DELIVERY_PENDING' THEN 1 ELSE 0 END) AS TeslimEdilecekSayisi,
--     SUM(CASE WHEN lp.Code = 'DELIVERED' THEN 1 ELSE 0 END) AS TeslimEdildiSayisi

-- FROM tmscrq.TMLead l
-- LEFT JOIN tmscrq.TMCustomer cu
--     ON cu.Id = l.CustomerId
-- LEFT JOIN tmscrq.TMProduct p
--     ON p.Id = l.ProductId
-- LEFT JOIN dbo.KUser sp
--     ON sp.Id = l.SalesPersonKUserId
-- LEFT JOIN tmscrq.TMLeadProcess lp
--     ON lp.Id = l.ProcessID

-- WHERE
-- (
--     EXISTS
--     (
--         SELECT 1
--         FROM dbo.KUserRole ur
--         INNER JOIN dbo.KRole r
--             ON r.Id = ur.KRole_Id
--         WHERE ur.KUser_Id = @UserId
--           AND ur.IsDeleted = 0
--           AND r.IsDeleted = 0
--           AND r.Name IN ('TimesYonetici', 'TimesUstYonetici')
--     )
--     OR
--     (
--         EXISTS
--         (
--             SELECT 1
--             FROM dbo.KUserRole ur
--             INNER JOIN dbo.KRole r
--                 ON r.Id = ur.KRole_Id
--             WHERE ur.KUser_Id = @UserId
--               AND ur.IsDeleted = 0
--               AND r.IsDeleted = 0
--               AND r.Name IN ('TimesMagazaMuduru', 'TimesSatisPersoneli')
--         )
--         AND EXISTS
--         (
--             SELECT 1
--             FROM tmscrq.TMUser tu
--             WHERE tu.KUserID = @UserId
--               AND tu.StoreId = l.StoreId
--         )
--     )
-- )

-- AND
-- (
--     @MusteriAdi IS NULL
--     OR LTRIM(RTRIM(@MusteriAdi)) = ''
--     OR UPPER(LTRIM(RTRIM(ISNULL(cu.Name, '') + ' ' + ISNULL(cu.LastName, ''))))
--        LIKE '%' + UPPER(LTRIM(RTRIM(@MusteriAdi))) + '%'
-- )

-- AND
-- (
--     @ProductName IS NULL
--     OR LTRIM(RTRIM(@ProductName)) = ''
--     OR
--     (
--         CHARINDEX(',', @ProductName) > 0
--         AND ISNULL(LTRIM(RTRIM(p.ProductName)), '') IN
--         (
--             SELECT LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', '')))
--             FROM STRING_SPLIT(CAST(@ProductName AS NVARCHAR(MAX)), ',')
--             WHERE LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', ''))) <> ''
--         )
--     )
--     OR
--     (
--         CHARINDEX(',', @ProductName) = 0
--         AND UPPER(ISNULL(LTRIM(RTRIM(p.ProductName)), ''))
--             LIKE '%' + UPPER(LTRIM(RTRIM(@ProductName))) + '%'
--     )
-- )

-- AND
-- (
--     @LeadCode IS NULL
--     OR LTRIM(RTRIM(@LeadCode)) = ''
--     OR UPPER(ISNULL(LTRIM(RTRIM(l.LeadCode)), '')) LIKE '%' + UPPER(LTRIM(RTRIM(@LeadCode))) + '%'
-- )

-- AND
-- (
--     @Tel IS NULL
--     OR LTRIM(RTRIM(@Tel)) = ''
--     OR UPPER(ISNULL(LTRIM(RTRIM(cu.Tel)), '')) LIKE '%' + UPPER(LTRIM(RTRIM(@Tel))) + '%'
-- )

-- AND
-- (
--     @CategoryName IS NULL
--     OR LTRIM(RTRIM(@CategoryName)) = ''
--     OR
--     (
--         EXISTS
--         (
--             SELECT 1
--             FROM STRING_SPLIT(CAST(@CategoryName AS NVARCHAR(MAX)), ',') c
--             WHERE UPPER(LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(c.value, '""', ''), '[', ''), ']', '')))) = 'DEFAULT'
--         )
--         AND (p.CategoryName IS NULL OR LTRIM(RTRIM(p.CategoryName)) = '')
--     )
--     OR UPPER(ISNULL(LTRIM(RTRIM(p.CategoryName)), '')) IN
--     (
--         SELECT UPPER(LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', ''))))
--         FROM STRING_SPLIT(CAST(@CategoryName AS NVARCHAR(MAX)), ',')
--         WHERE LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', ''))) <> ''
--           AND UPPER(LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', '')))) <> 'DEFAULT'
--     )
-- )

-- AND
-- (
--     @StoreIds IS NULL
--     OR LTRIM(RTRIM(@StoreIds)) = ''
--     OR EXISTS
--     (
--         SELECT 1
--         FROM STRING_SPLIT(CAST(@StoreIds AS NVARCHAR(MAX)), ',') s
--         WHERE l.StoreId = TRY_CONVERT
--         (
--             uniqueidentifier,
--             LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(s.value, '""', ''), '[', ''), ']', '')))
--         )
--     )
-- )

-- AND
-- (
--     @SatisDanismaniIds IS NULL
--     OR LTRIM(RTRIM(@SatisDanismaniIds)) = ''
--     OR EXISTS
--     (
--         SELECT 1
--         FROM STRING_SPLIT(CAST(@SatisDanismaniIds AS NVARCHAR(MAX)), ',') s
--         WHERE l.SalesPersonKUserId = TRY_CONVERT
--         (
--             uniqueidentifier,
--             LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(s.value, '""', ''), '[', ''), ']', '')))
--         )
--     )
-- )

-- AND
-- (
--     @ProcessCode IS NULL
--     OR LTRIM(RTRIM(@ProcessCode)) = ''
--     OR UPPER(ISNULL(LTRIM(RTRIM(lp.Code)), '')) IN
--     (
--         SELECT UPPER(LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', ''))))
--         FROM STRING_SPLIT(CAST(@ProcessCode AS NVARCHAR(MAX)), ',')
--         WHERE LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', ''))) <> ''
--     )
-- )

-- AND
-- (
--     @StartDate IS NULL
--     OR LTRIM(RTRIM(@StartDate)) = ''
--     OR l.CreatedAt >= CONVERT(date, @StartDate)
-- )

-- AND
-- (
--     @EndDate IS NULL
--     OR LTRIM(RTRIM(@EndDate)) = ''
--     OR l.CreatedAt < DATEADD(day, 1, CONVERT(date, @EndDate))
-- );

-------------------------------------------------------------

DECLARE @KUserId UNIQUEIDENTIFIER = @UserId;

WITH UserRoles AS (
    SELECT r.Name
    FROM dbo.KUserRole ur
    INNER JOIN dbo.KRole r 
        ON r.Id = ur.KRole_Id
    WHERE ur.KUser_Id = @KUserId
      AND ur.IsDeleted = 0
      AND r.IsDeleted = 0
),
IsAdmin AS (
    SELECT CASE 
        WHEN EXISTS (
            SELECT 1 
            FROM UserRoles 
            WHERE Name = 'TimesUstYonetici'
        ) THEN 1 ELSE 0 END AS IsAdmin
)

SELECT
    COUNT(*) AS ToplamTalepSayisi,

    SUM(CASE WHEN lp.Code = 'PENDING' THEN 1 ELSE 0 END) AS OnayBekleyenSayisi,
    SUM(CASE WHEN lp.Code = 'TERMIN_PENDING' THEN 1 ELSE 0 END) AS TerminBekleyenSayisi,
    SUM(CASE WHEN lp.Code = 'APPROVED' THEN 1 ELSE 0 END) AS OnaylananSayisi,
    SUM(CASE WHEN lp.Code = 'REJECTED' THEN 1 ELSE 0 END) AS ReddedilenSayisi,
    SUM(CASE WHEN lp.Code = 'DELIVERY_PENDING' THEN 1 ELSE 0 END) AS TeslimEdilecekSayisi,
    SUM(CASE WHEN lp.Code = 'DELIVERED' THEN 1 ELSE 0 END) AS TeslimEdildiSayisi

FROM tmscrq.TMLead l
LEFT JOIN tmscrq.TMCustomer cu
    ON cu.Id = l.CustomerId
LEFT JOIN tmscrq.TMProduct p
    ON p.Id = l.ProductId
LEFT JOIN dbo.KUser sp
    ON sp.Id = l.SalesPersonKUserId
LEFT JOIN tmscrq.TMLeadProcess lp
    ON lp.Id = l.ProcessID

CROSS JOIN IsAdmin a

WHERE
(
    -- admin → full
    a.IsAdmin = 1

    -- diğerleri → sadece kendi mağazaları
    OR EXISTS
    (
        SELECT 1
        FROM tmscrq.TMUser tu
        WHERE tu.KUserID = @KUserId
          AND tu.StoreId = l.StoreId
    )
)

-- 🔽 AŞAĞISI SENİN ORİJİNAL FİLTRELER (HİÇ DOKUNMADIM)

AND
(
    @MusteriAdi IS NULL
    OR LTRIM(RTRIM(@MusteriAdi)) = ''
    OR UPPER(LTRIM(RTRIM(ISNULL(cu.Name, '') + ' ' + ISNULL(cu.LastName, ''))))
       LIKE '%' + UPPER(LTRIM(RTRIM(@MusteriAdi))) + '%'
)

AND
(
    @ProductName IS NULL
    OR LTRIM(RTRIM(@ProductName)) = ''
    OR
    (
        CHARINDEX(',', @ProductName) > 0
        AND ISNULL(LTRIM(RTRIM(p.ProductName)), '') IN
        (
            SELECT LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', '')))
            FROM STRING_SPLIT(CAST(@ProductName AS NVARCHAR(MAX)), ',')
        )
    )
    OR
    (
        CHARINDEX(',', @ProductName) = 0
        AND UPPER(ISNULL(LTRIM(RTRIM(p.ProductName)), ''))
            LIKE '%' + UPPER(LTRIM(RTRIM(@ProductName))) + '%'
    )
)

AND
(
    @LeadCode IS NULL
    OR LTRIM(RTRIM(@LeadCode)) = ''
    OR UPPER(ISNULL(LTRIM(RTRIM(l.LeadCode)), '')) LIKE '%' + UPPER(LTRIM(RTRIM(@LeadCode))) + '%'
)

AND
(
    @Tel IS NULL
    OR LTRIM(RTRIM(@Tel)) = ''
    OR UPPER(ISNULL(LTRIM(RTRIM(cu.Tel)), '')) LIKE '%' + UPPER(LTRIM(RTRIM(@Tel))) + '%'
)

AND
(
    @CategoryName IS NULL
    OR LTRIM(RTRIM(@CategoryName)) = ''
    OR
    (
        EXISTS
        (
            SELECT 1
            FROM STRING_SPLIT(CAST(@CategoryName AS NVARCHAR(MAX)), ',') c
            WHERE UPPER(LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(c.value, '""', ''), '[', ''), ']', '')))) = 'DEFAULT'
        )
        AND (p.CategoryName IS NULL OR LTRIM(RTRIM(p.CategoryName)) = '')
    )
    OR UPPER(ISNULL(LTRIM(RTRIM(p.CategoryName)), '')) IN
    (
        SELECT UPPER(LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', ''))))
        FROM STRING_SPLIT(CAST(@CategoryName AS NVARCHAR(MAX)), ',')
    )
)

AND
(
    @StoreIds IS NULL
    OR LTRIM(RTRIM(@StoreIds)) = ''
    OR EXISTS
    (
        SELECT 1
        FROM STRING_SPLIT(CAST(@StoreIds AS NVARCHAR(MAX)), ',') s
        WHERE l.StoreId = TRY_CONVERT
        (
            uniqueidentifier,
            LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(s.value, '""', ''), '[', ''), ']', '')))
        )
    )
)

AND
(
    @SatisDanismaniIds IS NULL
    OR LTRIM(RTRIM(@SatisDanismaniIds)) = ''
    OR EXISTS
    (
        SELECT 1
        FROM STRING_SPLIT(CAST(@SatisDanismaniIds AS NVARCHAR(MAX)), ',') s
        WHERE l.SalesPersonKUserId = TRY_CONVERT
        (
            uniqueidentifier,
            LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(s.value, '""', ''), '[', ''), ']', '')))
        )
    )
)

AND
(
    @ProcessCode IS NULL
    OR LTRIM(RTRIM(@ProcessCode)) = ''
    OR UPPER(ISNULL(LTRIM(RTRIM(lp.Code)), '')) IN
    (
        SELECT UPPER(LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', ''))))
        FROM STRING_SPLIT(CAST(@ProcessCode AS NVARCHAR(MAX)), ',')
    )
)

AND
(
    @StartDate IS NULL
    OR LTRIM(RTRIM(@StartDate)) = ''
    OR l.CreatedAt >= CONVERT(date, @StartDate)
)

AND
(
    @EndDate IS NULL
    OR LTRIM(RTRIM(@EndDate)) = ''
    OR l.CreatedAt < DATEADD(day, 1, CONVERT(date, @EndDate))
);", new string[] { "ToplamTalepSayisi", "OnayBekleyenSayisi", "TerminBekleyenSayisi", "OnaylananSayisi", "ReddedilenSayisi", "TeslimEdilecekSayisi", "TeslimEdildiSayisi" }, prms_TMLeadProcessCountSummary_1.ToArray());
            ;


            return Ok(result);
        }


        [HttpPost, Route("LeadListComponent_873248_onClick1_")]
        public IActionResult LeadListComponent_873248_onClick1_(LeadListComponent_873248_onClick1__Request request)
        {

            KProviderManager.Authorization.IsAuthorizedForRoles(appId, appName, screenId, screenName, new List<string> { $"70de6cfc-6087-6059-59b4-0b5a8527af6b", "4da1f213-c8e4-0b50-5c84-02fd13f1a622", "c4e882ef-977d-f613-7694-230ac83919d2", "b4bfd39c-ac02-f442-c899-7a2374a45b47", "cdb536b0-6297-155f-d446-8453d8a60304", "TimesYonetici", "TimesUstYonetici", "TimesSatisPersoneli", "TimesMagazaMuduru", "TimesAdmin" });

            var result = new LeadListComponent_873248_onClick1__Response();

            var prms_TM_GetLeads_0 = new List<kSqlParameter>();
            prms_TM_GetLeads_0.Add(new kSqlParameter() { Name = "StepOrder", Value = (null as object) });
            prms_TM_GetLeads_0.Add(new kSqlParameter() { Name = "UserId", Value = Kuika.Common.KContext.CurrentUser?.Id });
            prms_TM_GetLeads_0.Add(new kSqlParameter() { Name = "MusteriAdi", Value = request.MusteriAdi_0 });
            prms_TM_GetLeads_0.Add(new kSqlParameter() { Name = "ProductName", Value = request.ProductName_0 });
            prms_TM_GetLeads_0.Add(new kSqlParameter() { Name = "LeadCode", Value = request.LeadCode_0 });
            prms_TM_GetLeads_0.Add(new kSqlParameter() { Name = "Tel", Value = request.Tel_0 });
            prms_TM_GetLeads_0.Add(new kSqlParameter() { Name = "CategoryName", Value = request.CategoryName_0 });
            prms_TM_GetLeads_0.Add(new kSqlParameter() { Name = "StoreIds", Value = request.StoreIds_0 });
            prms_TM_GetLeads_0.Add(new kSqlParameter() { Name = "SatisDanismaniIds", Value = request.SatisDanismaniIds_0 });
            prms_TM_GetLeads_0.Add(new kSqlParameter() { Name = "ProcessCode", Value = request.ProcessCode_0 });
            prms_TM_GetLeads_0.Add(new kSqlParameter() { Name = "StartDate", Value = request.StartDate_0 });
            prms_TM_GetLeads_0.Add(new kSqlParameter() { Name = "EndDate", Value = request.EndDate_0 });
            using var auditTM_GetLeads_0 = ActionAuditScope.Begin("3c76f695-28f7-207c-1a5e-da75966a69a5", "TM_GetLeads", applicationName: "wbTimesCRM", screenOrEndpointName: "LeadList");
            result.TM_GetLeads = KPersister.Fetch(KContext.GetConnectionString(), @"-- SET LANGUAGE Turkish;

-- SELECT
-- CASE 
--     WHEN EXISTS (
--         SELECT 1 
--         FROM tmscrq.TMLeadReservation r
--         WHERE r.LeadId = l.Id
--           AND r.IsActive = 1
--           AND r.IsApproved = 1
--     ) THEN N'Evet'

--     WHEN EXISTS (
--         SELECT 1 
--         FROM tmscrq.TMLeadReservation r
--         WHERE r.LeadId = l.Id
--           AND r.IsActive = 1
--           AND ISNULL(r.IsApproved,0) = 0
--     ) THEN N'Onay Bekliyor'

--     ELSE N'Hayır'
-- END AS RezerveDurumu,
--     l.Id AS LeadId,
--     l.IsReserved,
--     ISNULL(NULLIF(LTRIM(RTRIM(l.LeadCode)), ''), '-') AS LeadNumarasi,
--     CONVERT(varchar(10), l.CreatedAt, 103) AS TalepTarihi,

--     p.Id AS ProductId,
--     ISNULL(NULLIF(LTRIM(RTRIM(p.ProductName)), ''), '-') AS ProductName,
--     ISNULL(NULLIF(LTRIM(RTRIM(p.Bracelet)), ''), '-') AS Bilezik,
--     ISNULL(NULLIF(LTRIM(RTRIM(p.Brand)), ''), '-') AS Brand,
--     ISNULL(NULLIF(LTRIM(RTRIM(p.Dial)), ''), '-') AS Kadran,
--     ISNULL(NULLIF(LTRIM(RTRIM(p.ProductCode)), ''), '-') AS RefCode,
--     ISNULL(NULLIF(LTRIM(RTRIM(p.Referance)), ''), '-') AS Referans,

--     ISNULL(
--         NULLIF(
--             LTRIM(RTRIM(ISNULL(cu.Name, '') + ' ' + ISNULL(cu.LastName, '')))
--         , '')
--     , '-') AS Musteri,

--     ISNULL(NULLIF(LTRIM(RTRIM(cu.CityName)), ''), '-') AS Lokasyon,
--     ISNULL(NULLIF(LTRIM(RTRIM(cu.DistrictName)), ''), '-') AS Ilce,
--     ISNULL(NULLIF(LTRIM(RTRIM(cu.CountryName)), ''), '-') AS Ulke,
--     ISNULL(NULLIF(LTRIM(RTRIM(cu.Info)), ''), '-') AS MusteriInfo,

--     CASE
--         WHEN cu.IsShopping = 1 THEN N'Evet'
--         WHEN cu.IsShopping = 0 THEN N'Hayır'
--         ELSE '-'
--     END AS AlisverisiVarMi,

--     ISNULL(NULLIF(LTRIM(RTRIM(cu.Tel)), ''), '-') AS IrtibatNumarasi,
--     ISNULL(NULLIF(LTRIM(RTRIM(cu.Email)), ''), '-') AS EmailAdresi,

--     ISNULL(NULLIF(LTRIM(RTRIM(cr.ContactResourceName)), ''), '-') AS IletisimKaynagi,

--     ISNULL(NULLIF(LTRIM(RTRIM(p.CategoryName)), ''), '-') AS CategoryName,
--     '-' AS CategoryCode,

--     ISNULL(NULLIF(LTRIM(RTRIM(ls.Name)), ''), '-') AS LeadDurumu,
--     ISNULL(NULLIF(LTRIM(RTRIM(ns.Name)), ''), '-') AS SonrakiAdim,

--     ISNULL(NULLIF(LTRIM(RTRIM(lp.Name)), ''), '-') AS ProcessName,
--     ISNULL(NULLIF(LTRIM(RTRIM(lp.Code)), ''), '-') AS ProcessCode,
--     lp.StepOrder,
-- CASE
--     WHEN EXISTS
--     (
--         SELECT 1
--         FROM tmscrq.TMLeadReservation r
--         WHERE r.LeadId = l.Id
--           AND r.IsActive = 1
--           AND ISNULL(r.IsApproved,0) = 0
--     )
--     THEN 10
--     ELSE lp.StepOrder
-- END AS SelectedStepOrder,

--     ISNULL(
--         CASE
--             WHEN l.EstimatedDate IS NOT NULL
--             THEN CAST(YEAR(l.EstimatedDate) AS VARCHAR(4)) + ' ' + DATENAME(MONTH, l.EstimatedDate)
--             ELSE NULL
--         END,
--         '-'
--     ) AS TerminTarihi,

--     ISNULL(
--         NULLIF(
--             LTRIM(RTRIM(ISNULL(sp.FirstName, '') + ' ' + ISNULL(sp.LastName, '')))
--         , '')
--     , '-') AS SatisDanismani,

--     ISNULL(NULLIF(LTRIM(RTRIM(st.StoreDesc)), ''), '-') AS StoreName

-- FROM tmscrq.TMLead l
-- LEFT JOIN tmscrq.TMLeadStatu ls
--     ON ls.Id = l.StatuId
-- LEFT JOIN tmscrq.TMCustomer cu
--     ON cu.Id = l.CustomerId
-- LEFT JOIN tmscrq.TMProduct p
--     ON p.Id = l.ProductId
-- LEFT JOIN tmscrq.TMContactResource cr
--     ON cr.Id = l.ContactResourceId
-- LEFT JOIN dbo.KUser sp
--     ON sp.Id = l.SalesPersonKUserId
-- LEFT JOIN tmscrq.TMStore st
--     ON st.Id = l.StoreId
-- LEFT JOIN tmscrq.TMLeadProcess lp
--     ON lp.Id = l.ProcessID
-- LEFT JOIN tmscrq.TMLeadNextStep ns
--     ON ns.Id = l.NextStepId

-- WHERE
-- (
--     EXISTS
--     (
--         SELECT 1
--         FROM dbo.KUserRole ur
--         INNER JOIN dbo.KRole r
--             ON r.Id = ur.KRole_Id
--         WHERE ur.KUser_Id = @UserId
--           AND ur.IsDeleted = 0
--           AND r.IsDeleted = 0
--           AND r.Name IN ('TimesYonetici', 'TimesUstYonetici')
--     )
--     OR
--     (
--         EXISTS
--         (
--             SELECT 1
--             FROM dbo.KUserRole ur
--             INNER JOIN dbo.KRole r
--                 ON r.Id = ur.KRole_Id
--             WHERE ur.KUser_Id = @UserId
--               AND ur.IsDeleted = 0
--               AND r.IsDeleted = 0
--               AND r.Name IN ('TimesMagazaMuduru', 'TimesSatisPersoneli')
--         )
--         AND EXISTS
--         (
--             SELECT 1
--             FROM tmscrq.TMUser tu
--             WHERE tu.KUserID = @UserId
--               AND tu.StoreId = l.StoreId
--         )
--     )
-- )

-- AND
-- (
--     @MusteriAdi IS NULL
--     OR LTRIM(RTRIM(@MusteriAdi)) = ''
--     OR UPPER(LTRIM(RTRIM(ISNULL(cu.Name,'') + ' ' + ISNULL(cu.LastName,''))))
--        LIKE '%' + UPPER(LTRIM(RTRIM(@MusteriAdi))) + '%'
-- )

-- AND
-- (
--     @ProductName IS NULL
--     OR LTRIM(RTRIM(@ProductName)) = ''
--     OR
--     (
--         CHARINDEX(',', @ProductName) > 0
--         AND ISNULL(LTRIM(RTRIM(p.ProductName)), '') IN
--         (
--             SELECT LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', '')))
--             FROM STRING_SPLIT(CAST(@ProductName AS NVARCHAR(MAX)), ',')
--             WHERE LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', ''))) <> ''
--         )
--     )
--     OR
--     (
--         CHARINDEX(',', @ProductName) = 0
--         AND UPPER(ISNULL(LTRIM(RTRIM(p.ProductName)), ''))
--             LIKE '%' + UPPER(LTRIM(RTRIM(@ProductName))) + '%'
--     )
-- )

-- AND
-- (
--     @LeadCode IS NULL
--     OR LTRIM(RTRIM(@LeadCode)) = ''
--     OR UPPER(ISNULL(LTRIM(RTRIM(l.LeadCode)), '')) LIKE '%' + UPPER(LTRIM(RTRIM(@LeadCode))) + '%'
-- )

-- AND
-- (
--     @Tel IS NULL
--     OR LTRIM(RTRIM(@Tel)) = ''
--     OR UPPER(ISNULL(LTRIM(RTRIM(cu.Tel)), '')) LIKE '%' + UPPER(LTRIM(RTRIM(@Tel))) + '%'
-- )

-- -- AND
-- -- (
-- --     @CategoryName IS NULL
-- --     OR LTRIM(RTRIM(@CategoryName)) = ''
-- --     OR
-- --     (
-- --         EXISTS
-- --         (
-- --             SELECT 1
-- --             FROM STRING_SPLIT(CAST(@CategoryName AS NVARCHAR(MAX)), ',') c
-- --             WHERE UPPER(LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(c.value, '""', ''), '[', ''), ']', '')))) = 'DEFAULT'
-- --         )
-- --         AND (p.CategoryName IS NULL OR LTRIM(RTRIM(p.CategoryName)) = '')
-- --     )
-- --     OR UPPER(ISNULL(LTRIM(RTRIM(p.CategoryName)), '')) IN
-- --     (
-- --         SELECT UPPER(LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', ''))))
-- --         FROM STRING_SPLIT(CAST(@CategoryName AS NVARCHAR(MAX)), ',')
-- --         WHERE LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', ''))) <> ''
-- --           AND UPPER(LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', '')))) <> 'DEFAULT'
-- --     )
-- -- )

-- AND
-- (
--     @CategoryName IS NULL
--     OR LTRIM(RTRIM(@CategoryName)) = ''
--     OR UPPER(ISNULL(LTRIM(RTRIM(p.CategoryName)), '')) IN
--     (
--         SELECT UPPER(LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value,'""',''),'[',''),']',''))))
--         FROM STRING_SPLIT(CAST(@CategoryName AS NVARCHAR(MAX)), ',')
--         WHERE LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value,'""',''),'[',''),']',''))) <> ''
--     )
-- )

-- AND
-- (
--     @StoreIds IS NULL
--     OR LTRIM(RTRIM(@StoreIds)) = ''
--     OR EXISTS
--     (
--         SELECT 1
--         FROM STRING_SPLIT(CAST(@StoreIds AS NVARCHAR(MAX)), ',') s
--         WHERE l.StoreId = TRY_CONVERT
--         (
--             uniqueidentifier,
--             LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(s.value, '""', ''), '[', ''), ']', '')))
--         )
--     )
-- )

-- AND
-- (
--     @SatisDanismaniIds IS NULL
--     OR LTRIM(RTRIM(@SatisDanismaniIds)) = ''
--     OR EXISTS
--     (
--         SELECT 1
--         FROM STRING_SPLIT(CAST(@SatisDanismaniIds AS NVARCHAR(MAX)), ',') s
--         WHERE l.SalesPersonKUserId = TRY_CONVERT
--         (
--             uniqueidentifier,
--             LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(s.value, '""', ''), '[', ''), ']', '')))
--         )
--     )
-- )

-- AND
-- (
--     @ProcessCode IS NULL
--     OR LTRIM(RTRIM(@ProcessCode)) = ''
--     OR UPPER(ISNULL(LTRIM(RTRIM(lp.Code)), '')) IN
--     (
--         SELECT UPPER(LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', ''))))
--         FROM STRING_SPLIT(CAST(@ProcessCode AS NVARCHAR(MAX)), ',')
--         WHERE LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', ''))) <> ''
--     )
-- )

-- AND
-- (
--     @StepOrder IS NULL

--     OR
--     (
--         @StepOrder = 10
--         AND EXISTS
--         (
--             SELECT 1
--             FROM tmscrq.TMLeadReservation r
--             WHERE r.LeadId = l.Id
--               AND r.IsActive = 1
--               AND ISNULL(r.IsApproved,0) = 0
--         )
--     )

--     OR
--     (
--         @StepOrder <> 10
--         AND lp.StepOrder = @StepOrder
--     )
-- )

-- AND
-- (
--     @StartDate IS NULL
--     OR LTRIM(RTRIM(@StartDate)) = ''
--     OR l.CreatedAt >= CONVERT(date, @StartDate)
-- )

-- AND
-- (
--     @EndDate IS NULL
--     OR LTRIM(RTRIM(@EndDate)) = ''
--     OR l.CreatedAt < DATEADD(day, 1, CONVERT(date, @EndDate))
-- )

-- ORDER BY l.CreatedAt DESC;

------------------------++++++++++++++++++++++++-------------------
-- SET LANGUAGE Turkish;

-- SELECT
-- CASE 
--     WHEN EXISTS (
--         SELECT 1 
--         FROM tmscrq.TMLeadReservation r
--         WHERE r.LeadId = l.Id
--           AND r.IsActive = 1
--           AND r.IsApproved = 1
--     ) THEN N'Evet'

--     WHEN EXISTS (
--         SELECT 1 
--         FROM tmscrq.TMLeadReservation r
--         WHERE r.LeadId = l.Id
--           AND r.IsActive = 1
--           AND ISNULL(r.IsApproved,0) = 0
--     ) THEN N'Onay Bekliyor'

--     ELSE N'Hayır'
-- END AS RezerveDurumu,
--     l.Id AS LeadId,
--     l.IsReserved,
--     ISNULL(NULLIF(LTRIM(RTRIM(l.LeadCode)), ''), '-') AS LeadNumarasi,
--     CONVERT(varchar(10), l.CreatedAt, 103) AS TalepTarihi,

--     p.Id AS ProductId,
--     ISNULL(NULLIF(LTRIM(RTRIM(p.ProductName)), ''), '-') AS ProductName,
--     ISNULL(NULLIF(LTRIM(RTRIM(p.Bracelet)), ''), '-') AS Bilezik,
--     ISNULL(NULLIF(LTRIM(RTRIM(p.Brand)), ''), '-') AS Brand,
--     ISNULL(NULLIF(LTRIM(RTRIM(p.Dial)), ''), '-') AS Kadran,
--     ISNULL(NULLIF(LTRIM(RTRIM(p.ProductCode)), ''), '-') AS RefCode,
--     ISNULL(NULLIF(LTRIM(RTRIM(p.Referance)), ''), '-') AS Referans,

--     ISNULL(
--         NULLIF(
--             LTRIM(RTRIM(ISNULL(cu.Name, '') + ' ' + ISNULL(cu.LastName, '')))
--         , '')
--     , '-') AS Musteri,

--     ISNULL(NULLIF(LTRIM(RTRIM(cu.CityName)), ''), '-') AS Lokasyon,
--     ISNULL(NULLIF(LTRIM(RTRIM(cu.DistrictName)), ''), '-') AS Ilce,
--     ISNULL(NULLIF(LTRIM(RTRIM(cu.CountryName)), ''), '-') AS Ulke,
--     ISNULL(NULLIF(LTRIM(RTRIM(cu.Info)), ''), '-') AS MusteriInfo,

--     CASE
--         WHEN cu.IsShopping = 1 THEN N'Evet'
--         WHEN cu.IsShopping = 0 THEN N'Hayır'
--         ELSE '-'
--     END AS AlisverisiVarMi,

--     ISNULL(NULLIF(LTRIM(RTRIM(cu.Tel)), ''), '-') AS IrtibatNumarasi,
--     ISNULL(NULLIF(LTRIM(RTRIM(cu.Email)), ''), '-') AS EmailAdresi,

--     ISNULL(NULLIF(LTRIM(RTRIM(cr.ContactResourceName)), ''), '-') AS IletisimKaynagi,

--     ISNULL(NULLIF(LTRIM(RTRIM(p.CategoryName)), ''), '-') AS CategoryName,
--     '-' AS CategoryCode,

--     ISNULL(NULLIF(LTRIM(RTRIM(ls.Name)), ''), '-') AS LeadDurumu,
--     ISNULL(NULLIF(LTRIM(RTRIM(ns.Name)), ''), '-') AS SonrakiAdim,

--     ISNULL(NULLIF(LTRIM(RTRIM(lp.Name)), ''), '-') AS ProcessName,
--     ISNULL(NULLIF(LTRIM(RTRIM(lp.Code)), ''), '-') AS ProcessCode,
--     lp.StepOrder,
    
--     -- DÜZELTİLEN ALAN: SelectedStepOrder
--     CASE
--         WHEN EXISTS
--         (
--             SELECT 1
--             FROM tmscrq.TMLeadReservation r
--             WHERE r.LeadId = l.Id
--               AND r.IsActive = 1
--               AND ISNULL(r.IsApproved,0) = 0
--         )
--         THEN 10
--         ELSE lp.StepOrder
--     END AS SelectedStepOrder,

--     ISNULL(
--         CASE
--             WHEN l.EstimatedDate IS NOT NULL
--             THEN CAST(YEAR(l.EstimatedDate) AS VARCHAR(4)) + ' ' + DATENAME(MONTH, l.EstimatedDate)
--             ELSE NULL
--         END,
--         '-'
--     ) AS TerminTarihi,

--     ISNULL(
--         NULLIF(
--             LTRIM(RTRIM(ISNULL(sp.FirstName, '') + ' ' + ISNULL(sp.LastName, '')))
--         , '')
--     , '-') AS SatisDanismani,

--     ISNULL(NULLIF(LTRIM(RTRIM(st.StoreDesc)), ''), '-') AS StoreName

-- FROM tmscrq.TMLead l
-- LEFT JOIN tmscrq.TMLeadStatu ls
--     ON ls.Id = l.StatuId
-- LEFT JOIN tmscrq.TMCustomer cu
--     ON cu.Id = l.CustomerId
-- LEFT JOIN tmscrq.TMProduct p
--     ON p.Id = l.ProductId
-- LEFT JOIN tmscrq.TMContactResource cr
--     ON cr.Id = l.ContactResourceId
-- LEFT JOIN dbo.KUser sp
--     ON sp.Id = l.SalesPersonKUserId
-- LEFT JOIN tmscrq.TMStore st
--     ON st.Id = l.StoreId
-- LEFT JOIN tmscrq.TMLeadProcess lp
--     ON lp.Id = l.ProcessID
-- LEFT JOIN tmscrq.TMLeadNextStep ns
--     ON ns.Id = l.NextStepId

-- WHERE
-- (
--     EXISTS
--     (
--         SELECT 1
--         FROM dbo.KUserRole ur
--         INNER JOIN dbo.KRole r
--             ON r.Id = ur.KRole_Id
--         WHERE ur.KUser_Id = @UserId
--           AND ur.IsDeleted = 0
--           AND r.IsDeleted = 0
--           AND r.Name IN ('TimesYonetici', 'TimesUstYonetici')
--     )
--     OR
--     (
--         EXISTS
--         (
--             SELECT 1
--             FROM dbo.KUserRole ur
--             INNER JOIN dbo.KRole r
--                 ON r.Id = ur.KRole_Id
--             WHERE ur.KUser_Id = @UserId
--               AND ur.IsDeleted = 0
--               AND r.IsDeleted = 0
--               AND r.Name IN ('TimesMagazaMuduru', 'TimesSatisPersoneli')
--         )
--         AND EXISTS
--         (
--             SELECT 1
--             FROM tmscrq.TMUser tu
--             WHERE tu.KUserID = @UserId
--               AND tu.StoreId = l.StoreId
--         )
--     )
-- )

-- AND
-- (
--     @MusteriAdi IS NULL
--     OR LTRIM(RTRIM(@MusteriAdi)) = ''
--     OR UPPER(LTRIM(RTRIM(ISNULL(cu.Name,'') + ' ' + ISNULL(cu.LastName,''))))
--        LIKE '%' + UPPER(LTRIM(RTRIM(@MusteriAdi))) + '%'
-- )

-- AND
-- (
--     @ProductName IS NULL
--     OR LTRIM(RTRIM(@ProductName)) = ''
--     OR
--     (
--         CHARINDEX(',', @ProductName) > 0
--         AND ISNULL(LTRIM(RTRIM(p.ProductName)), '') IN
--         (
--             SELECT LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', '')))
--             FROM STRING_SPLIT(CAST(@ProductName AS NVARCHAR(MAX)), ',')
--             WHERE LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', ''))) <> ''
--         )
--     )
--     OR
--     (
--         CHARINDEX(',', @ProductName) = 0
--         AND UPPER(ISNULL(LTRIM(RTRIM(p.ProductName)), ''))
--             LIKE '%' + UPPER(LTRIM(RTRIM(@ProductName))) + '%'
--     )
-- )

-- AND
-- (
--     @LeadCode IS NULL
--     OR LTRIM(RTRIM(@LeadCode)) = ''
--     OR UPPER(ISNULL(LTRIM(RTRIM(l.LeadCode)), '')) LIKE '%' + UPPER(LTRIM(RTRIM(@LeadCode))) + '%'
-- )

-- AND
-- (
--     @Tel IS NULL
--     OR LTRIM(RTRIM(@Tel)) = ''
--     OR UPPER(ISNULL(LTRIM(RTRIM(cu.Tel)), '')) LIKE '%' + UPPER(LTRIM(RTRIM(@Tel))) + '%'
-- )

-- AND
-- (
--     @CategoryName IS NULL
--     OR LTRIM(RTRIM(@CategoryName)) = ''
--     OR UPPER(ISNULL(LTRIM(RTRIM(p.CategoryName)), '')) IN
--     (
--         SELECT UPPER(LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value,'""',''),'[',''),']',''))))
--         FROM STRING_SPLIT(CAST(@CategoryName AS NVARCHAR(MAX)), ',')
--         WHERE LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value,'""',''),'[',''),']',''))) <> ''
--     )
-- )

-- AND
-- (
--     @StoreIds IS NULL
--     OR LTRIM(RTRIM(@StoreIds)) = ''
--     OR EXISTS
--     (
--         SELECT 1
--         FROM STRING_SPLIT(CAST(@StoreIds AS NVARCHAR(MAX)), ',') s
--         WHERE l.StoreId = TRY_CONVERT
--         (
--             uniqueidentifier,
--             LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(s.value, '""', ''), '[', ''), ']', '')))
--         )
--     )
-- )

-- AND
-- (
--     @SatisDanismaniIds IS NULL
--     OR LTRIM(RTRIM(@SatisDanismaniIds)) = ''
--     OR EXISTS
--     (
--         SELECT 1
--         FROM STRING_SPLIT(CAST(@SatisDanismaniIds AS NVARCHAR(MAX)), ',') s
--         WHERE l.SalesPersonKUserId = TRY_CONVERT
--         (
--             uniqueidentifier,
--             LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(s.value, '""', ''), '[', ''), ']', '')))
--         )
--     )
-- )

-- AND
-- (
--     @ProcessCode IS NULL
--     OR LTRIM(RTRIM(@ProcessCode)) = ''
--     OR UPPER(ISNULL(LTRIM(RTRIM(lp.Code)), '')) IN
--     (
--         SELECT UPPER(LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', ''))))
--         FROM STRING_SPLIT(CAST(@ProcessCode AS NVARCHAR(MAX)), ',')
--         WHERE LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', ''))) <> ''
--     )
-- )

-- -- DÜZELTİLEN ALAN: @StepOrder Filtresi (tek blok)
-- AND
-- (
--     @StepOrder IS NULL

--     OR

--     (
--         @StepOrder = 10
--         AND EXISTS
--         (
--             SELECT 1
--             FROM tmscrq.TMLeadReservation r
--             WHERE r.LeadId = l.Id
--               AND r.IsActive = 1
--               AND ISNULL(r.IsApproved,0) = 0
--         )
--     )

--     OR

--     (
--         @StepOrder <> 10
--         AND lp.StepOrder = @StepOrder
--     )
-- )

-- AND
-- (
--     @StartDate IS NULL
--     OR LTRIM(RTRIM(@StartDate)) = ''
--     OR l.CreatedAt >= CONVERT(date, @StartDate)
-- )

-- AND
-- (
--     @EndDate IS NULL
--     OR LTRIM(RTRIM(@EndDate)) = ''
--     OR l.CreatedAt < DATEADD(day, 1, CONVERT(date, @EndDate))
-- )

-- ORDER BY l.CreatedAt DESC;



SET LANGUAGE Turkish;

SELECT
CASE 
    WHEN EXISTS (
        SELECT 1 
        FROM tmscrq.TMLeadReservation r
        WHERE r.LeadId = l.Id
          AND r.IsActive = 1
          AND r.IsApproved = 1
    ) THEN N'Evet'

    WHEN EXISTS (
        SELECT 1 
        FROM tmscrq.TMLeadReservation r
        WHERE r.LeadId = l.Id
          AND r.IsActive = 1
          AND ISNULL(r.IsApproved,0) = 0
    ) THEN N'Onay Bekliyor'

    ELSE N'Hayır'
END AS RezerveDurumu,
    l.Id AS LeadId,
    l.IsReserved,
    ISNULL(NULLIF(LTRIM(RTRIM(l.LeadCode)), ''), '-') AS LeadNumarasi,
     FORMAT(l.CreatedAt, 'dd MMMM yyyy', 'tr-TR') AS TalepTarihi,

    p.Id AS ProductId,
    ISNULL(NULLIF(LTRIM(RTRIM(p.ProductName)), ''), '-') AS ProductName,
    ISNULL(NULLIF(LTRIM(RTRIM(p.Bracelet)), ''), '-') AS Bilezik,
    ISNULL(NULLIF(LTRIM(RTRIM(p.Brand)), ''), '-') AS Brand,
    ISNULL(NULLIF(LTRIM(RTRIM(p.Dial)), ''), '-') AS Kadran,
    ISNULL(NULLIF(LTRIM(RTRIM(p.ProductCode)), ''), '-') AS RefCode,
    ISNULL(NULLIF(LTRIM(RTRIM(p.Referance)), ''), '-') AS Referans,

    ISNULL(
        NULLIF(
            LTRIM(RTRIM(ISNULL(cu.Name, '') + ' ' + ISNULL(cu.LastName, '')))
        , '')
    , '-') AS Musteri,

    ISNULL(NULLIF(LTRIM(RTRIM(cu.CityName)), ''), '-') AS Lokasyon,
    ISNULL(NULLIF(LTRIM(RTRIM(cu.DistrictName)), ''), '-') AS Ilce,
    ISNULL(NULLIF(LTRIM(RTRIM(cu.CountryName)), ''), '-') AS Ulke,
    ISNULL(NULLIF(LTRIM(RTRIM(cu.Info)), ''), '-') AS MusteriInfo,

    CASE
        WHEN cu.IsShopping = 1 THEN N'Evet'
        WHEN cu.IsShopping = 0 THEN N'Hayır'
        ELSE '-'
    END AS AlisverisiVarMi,

    ISNULL(NULLIF(LTRIM(RTRIM(cu.Tel)), ''), '-') AS IrtibatNumarasi,
    ISNULL(NULLIF(LTRIM(RTRIM(cu.Email)), ''), '-') AS EmailAdresi,

    ISNULL(NULLIF(LTRIM(RTRIM(cr.ContactResourceName)), ''), '-') AS IletisimKaynagi,

    ISNULL(NULLIF(LTRIM(RTRIM(p.CategoryName)), ''), '-') AS CategoryName,
    '-' AS CategoryCode,

    ISNULL(NULLIF(LTRIM(RTRIM(ls.Name)), ''), '-') AS LeadDurumu,
    ISNULL(NULLIF(LTRIM(RTRIM(ns.Name)), ''), '-') AS SonrakiAdim,

    ISNULL(NULLIF(LTRIM(RTRIM(lp.Name)), ''), '-') AS ProcessName,
    ISNULL(NULLIF(LTRIM(RTRIM(lp.Code)), ''), '-') AS ProcessCode,
    lp.StepOrder,
    
    -- DÜZELTİLEN ALAN: SelectedStepOrder
    CASE
        WHEN EXISTS
        (
            SELECT 1
            FROM tmscrq.TMLeadReservation r
            WHERE r.LeadId = l.Id
              AND r.IsActive = 1
              AND ISNULL(r.IsApproved,0) = 0
        )
        THEN 10
        ELSE lp.StepOrder
    END AS SelectedStepOrder,

    ISNULL(
        CASE
            WHEN l.EstimatedDate IS NOT NULL
            THEN CAST(YEAR(l.EstimatedDate) AS VARCHAR(4)) + ' ' + DATENAME(MONTH, l.EstimatedDate)
            ELSE NULL
        END,
        '-'
    ) AS TerminTarihi,

    ISNULL(
        NULLIF(
            LTRIM(RTRIM(ISNULL(sp.FirstName, '') + ' ' + ISNULL(sp.LastName, '')))
        , '')
    , '-') AS SatisDanismani,

    ISNULL(NULLIF(LTRIM(RTRIM(st.StoreDesc)), ''), '-') AS StoreName

FROM tmscrq.TMLead l
LEFT JOIN tmscrq.TMLeadStatu ls
    ON ls.Id = l.StatuId
LEFT JOIN tmscrq.TMCustomer cu
    ON cu.Id = l.CustomerId
LEFT JOIN tmscrq.TMProduct p
    ON p.Id = l.ProductId
LEFT JOIN tmscrq.TMContactResource cr
    ON cr.Id = l.ContactResourceId
LEFT JOIN dbo.KUser sp
    ON sp.Id = l.SalesPersonKUserId
LEFT JOIN tmscrq.TMStore st
    ON st.Id = l.StoreId
LEFT JOIN tmscrq.TMLeadProcess lp
    ON lp.Id = l.ProcessID
LEFT JOIN tmscrq.TMLeadNextStep ns
    ON ns.Id = l.NextStepId

WHERE
(
    EXISTS
    (
        SELECT 1
        FROM dbo.KUserRole ur
        INNER JOIN dbo.KRole r
            ON r.Id = ur.KRole_Id
        WHERE ur.KUser_Id = @UserId
          AND ur.IsDeleted = 0
          AND r.IsDeleted = 0
          AND r.Name IN ('TimesYonetici', 'TimesUstYonetici')
    )
    OR
    (
        EXISTS
        (
            SELECT 1
            FROM dbo.KUserRole ur
            INNER JOIN dbo.KRole r
                ON r.Id = ur.KRole_Id
            WHERE ur.KUser_Id = @UserId
              AND ur.IsDeleted = 0
              AND r.IsDeleted = 0
              AND r.Name IN ('TimesMagazaMuduru', 'TimesSatisPersoneli')
        )
        AND EXISTS
        (
            SELECT 1
            FROM tmscrq.TMUser tu
            WHERE tu.KUserID = @UserId
              AND tu.StoreId = l.StoreId
        )
    )
)

AND
(
    ISNULL(@MusteriAdi, '') = ''
    OR UPPER(ISNULL(cu.Name, '')) LIKE '%' + UPPER(LTRIM(RTRIM(@MusteriAdi))) + '%'
    OR UPPER(ISNULL(cu.LastName, '')) LIKE '%' + UPPER(LTRIM(RTRIM(@MusteriAdi))) + '%'
    OR UPPER(
        ISNULL(cu.Name, '') + ' ' + ISNULL(cu.LastName, '')
    ) LIKE '%' + UPPER(LTRIM(RTRIM(@MusteriAdi))) + '%'
)

AND
(
    @ProductName IS NULL
    OR LTRIM(RTRIM(@ProductName)) = ''
    OR
    (
        CHARINDEX(',', @ProductName) > 0
        AND ISNULL(LTRIM(RTRIM(p.ProductName)), '') IN
        (
            SELECT LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', '')))
            FROM STRING_SPLIT(CAST(@ProductName AS NVARCHAR(MAX)), ',')
            WHERE LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', ''))) <> ''
        )
    )
    OR
    (
        CHARINDEX(',', @ProductName) = 0
        AND UPPER(ISNULL(LTRIM(RTRIM(p.ProductName)), ''))
            LIKE '%' + UPPER(LTRIM(RTRIM(@ProductName))) + '%'
    )
)

AND
(
    ISNULL(@LeadCode, '') = ''
    OR UPPER(ISNULL(l.LeadCode, ''))
        LIKE '%' + UPPER(LTRIM(RTRIM(@LeadCode))) + '%'
    OR REPLACE(
        REPLACE(
            REPLACE(
                UPPER(ISNULL(l.LeadCode, '')),
                '-', ''
            ),
            ' ', ''
        ),
        '/', ''
    )
    LIKE '%' +
    REPLACE(
        REPLACE(
            REPLACE(
                UPPER(LTRIM(RTRIM(@LeadCode))),
                '-', ''
            ),
            ' ', ''
        ),
        '/', ''
    )
    + '%'
)

AND
(
    @Tel IS NULL
    OR LTRIM(RTRIM(@Tel)) = ''
    OR UPPER(ISNULL(LTRIM(RTRIM(cu.Tel)), '')) LIKE '%' + UPPER(LTRIM(RTRIM(@Tel))) + '%'
)

AND
(
    @CategoryName IS NULL
    OR LTRIM(RTRIM(@CategoryName)) = ''
    OR UPPER(ISNULL(LTRIM(RTRIM(p.CategoryName)), '')) IN
    (
        SELECT UPPER(LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value,'""',''),'[',''),']',''))))
        FROM STRING_SPLIT(CAST(@CategoryName AS NVARCHAR(MAX)), ',')
        WHERE LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value,'""',''),'[',''),']',''))) <> ''
    )
)

AND
(
    @StoreIds IS NULL
    OR LTRIM(RTRIM(@StoreIds)) = ''
    OR EXISTS
    (
        SELECT 1
        FROM STRING_SPLIT(CAST(@StoreIds AS NVARCHAR(MAX)), ',') s
        WHERE l.StoreId = TRY_CONVERT
        (
            uniqueidentifier,
            LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(s.value, '""', ''), '[', ''), ']', '')))
        )
    )
)

AND
(
    @SatisDanismaniIds IS NULL
    OR LTRIM(RTRIM(@SatisDanismaniIds)) = ''
    OR EXISTS
    (
        SELECT 1
        FROM STRING_SPLIT(CAST(@SatisDanismaniIds AS NVARCHAR(MAX)), ',') s
        WHERE l.SalesPersonKUserId = TRY_CONVERT
        (
            uniqueidentifier,
            LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(s.value, '""', ''), '[', ''), ']', '')))
        )
    )
)

AND
(
    ISNULL(@ProcessCode, '') = ''
    OR EXISTS
    (
        SELECT 1
        FROM STRING_SPLIT(
            CONVERT(NVARCHAR(MAX), @ProcessCode),
            ','
        ) AS s
        WHERE
            UPPER(LTRIM(RTRIM(s.value))) =
            UPPER(LTRIM(RTRIM(ISNULL(lp.Code, ''))))
    )
)

-- DÜZELTİLEN ALAN: @StepOrder Filtresi (0 verilince tümü gelsin)
AND
(
    @StepOrder IS NULL
    OR @StepOrder = 0  -- 👈 YENİ EKLENDI: 0 verilince tüm kayıtlar gelir
    OR
    (
        @StepOrder = 10
        AND EXISTS
        (
            SELECT 1
            FROM tmscrq.TMLeadReservation r
            WHERE r.LeadId = l.Id
              AND r.IsActive = 1
              AND ISNULL(r.IsApproved,0) = 0
        )
    )
    OR
    (
        @StepOrder <> 10
        AND lp.StepOrder = @StepOrder
    )
)

AND
(
    @StartDate IS NULL
    OR LTRIM(RTRIM(@StartDate)) = ''
    OR l.CreatedAt >= CONVERT(date, @StartDate)
)

AND
(
    @EndDate IS NULL
    OR LTRIM(RTRIM(@EndDate)) = ''
    OR l.CreatedAt < DATEADD(day, 1, CONVERT(date, @EndDate))
)

ORDER BY l.CreatedAt DESC;", new string[] { "RezerveDurumu", "LeadId", "IsReserved", "LeadNumarasi", "TalepTarihi", "ProductId", "ProductName", "Bilezik", "Brand", "Kadran", "RefCode", "Referans", "Musteri", "Lokasyon", "Ilce", "Ulke", "MusteriInfo", "AlisverisiVarMi", "IrtibatNumarasi", "EmailAdresi", "IletisimKaynagi", "CategoryName", "CategoryCode", "LeadDurumu", "SonrakiAdim", "ProcessName", "ProcessCode", "StepOrder", "SelectedStepOrder", "TerminTarihi", "SatisDanismani", "StoreName" }, prms_TM_GetLeads_0.ToArray());
            ;

            var prms_TMLeadProcessCountSummary_1 = new List<kSqlParameter>();
            prms_TMLeadProcessCountSummary_1.Add(new kSqlParameter() { Name = "UserId", Value = Kuika.Common.KContext.CurrentUser?.Id });
            prms_TMLeadProcessCountSummary_1.Add(new kSqlParameter() { Name = "MusteriAdi", Value = request.MusteriAdi_1 });
            prms_TMLeadProcessCountSummary_1.Add(new kSqlParameter() { Name = "ProductName", Value = request.ProductName_1 });
            prms_TMLeadProcessCountSummary_1.Add(new kSqlParameter() { Name = "LeadCode", Value = request.LeadCode_1 });
            prms_TMLeadProcessCountSummary_1.Add(new kSqlParameter() { Name = "Tel", Value = request.Tel_1 });
            prms_TMLeadProcessCountSummary_1.Add(new kSqlParameter() { Name = "CategoryName", Value = request.CategoryName_1 });
            prms_TMLeadProcessCountSummary_1.Add(new kSqlParameter() { Name = "StoreIds", Value = request.StoreIds_1 });
            prms_TMLeadProcessCountSummary_1.Add(new kSqlParameter() { Name = "SatisDanismaniIds", Value = request.SatisDanismaniIds_1 });
            prms_TMLeadProcessCountSummary_1.Add(new kSqlParameter() { Name = "ProcessCode", Value = request.ProcessCode_1 });
            prms_TMLeadProcessCountSummary_1.Add(new kSqlParameter() { Name = "StartDate", Value = request.StartDate_1 });
            prms_TMLeadProcessCountSummary_1.Add(new kSqlParameter() { Name = "EndDate", Value = request.EndDate_1 });
            using var auditTMLeadProcessCountSummary_1 = ActionAuditScope.Begin("546ee3a2-5334-c490-6d68-9336891b7a23", "TMLeadProcessCountSummary", applicationName: "wbTimesCRM", screenOrEndpointName: "LeadList");
            result.TMLeadProcessCountSummary = KPersister.Fetch(KContext.GetConnectionString(), @"-- SELECT
--     COUNT(*) AS ToplamTalepSayisi,

--     SUM(CASE WHEN lp.Code = 'PENDING' THEN 1 ELSE 0 END) AS OnayBekleyenSayisi,
--     SUM(CASE WHEN lp.Code = 'TERMIN_PENDING' THEN 1 ELSE 0 END) AS TerminBekleyenSayisi,
--     SUM(CASE WHEN lp.Code = 'APPROVED' THEN 1 ELSE 0 END) AS OnaylananSayisi,
--     SUM(CASE WHEN lp.Code = 'REJECTED' THEN 1 ELSE 0 END) AS ReddedilenSayisi,
--     SUM(CASE WHEN lp.Code = 'DELIVERY_PENDING' THEN 1 ELSE 0 END) AS TeslimEdilecekSayisi,
--     SUM(CASE WHEN lp.Code = 'DELIVERED' THEN 1 ELSE 0 END) AS TeslimEdildiSayisi

-- FROM tmscrq.TMLead l
-- LEFT JOIN tmscrq.TMCustomer cu
--     ON cu.Id = l.CustomerId
-- LEFT JOIN tmscrq.TMProduct p
--     ON p.Id = l.ProductId
-- LEFT JOIN dbo.KUser sp
--     ON sp.Id = l.SalesPersonKUserId
-- LEFT JOIN tmscrq.TMLeadProcess lp
--     ON lp.Id = l.ProcessID

-- WHERE
-- (
--     EXISTS
--     (
--         SELECT 1
--         FROM dbo.KUserRole ur
--         INNER JOIN dbo.KRole r
--             ON r.Id = ur.KRole_Id
--         WHERE ur.KUser_Id = @UserId
--           AND ur.IsDeleted = 0
--           AND r.IsDeleted = 0
--           AND r.Name IN ('TimesYonetici', 'TimesUstYonetici')
--     )
--     OR
--     (
--         EXISTS
--         (
--             SELECT 1
--             FROM dbo.KUserRole ur
--             INNER JOIN dbo.KRole r
--                 ON r.Id = ur.KRole_Id
--             WHERE ur.KUser_Id = @UserId
--               AND ur.IsDeleted = 0
--               AND r.IsDeleted = 0
--               AND r.Name IN ('TimesMagazaMuduru', 'TimesSatisPersoneli')
--         )
--         AND EXISTS
--         (
--             SELECT 1
--             FROM tmscrq.TMUser tu
--             WHERE tu.KUserID = @UserId
--               AND tu.StoreId = l.StoreId
--         )
--     )
-- )

-- AND
-- (
--     @MusteriAdi IS NULL
--     OR LTRIM(RTRIM(@MusteriAdi)) = ''
--     OR UPPER(LTRIM(RTRIM(ISNULL(cu.Name, '') + ' ' + ISNULL(cu.LastName, ''))))
--        LIKE '%' + UPPER(LTRIM(RTRIM(@MusteriAdi))) + '%'
-- )

-- AND
-- (
--     @ProductName IS NULL
--     OR LTRIM(RTRIM(@ProductName)) = ''
--     OR
--     (
--         CHARINDEX(',', @ProductName) > 0
--         AND ISNULL(LTRIM(RTRIM(p.ProductName)), '') IN
--         (
--             SELECT LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', '')))
--             FROM STRING_SPLIT(CAST(@ProductName AS NVARCHAR(MAX)), ',')
--             WHERE LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', ''))) <> ''
--         )
--     )
--     OR
--     (
--         CHARINDEX(',', @ProductName) = 0
--         AND UPPER(ISNULL(LTRIM(RTRIM(p.ProductName)), ''))
--             LIKE '%' + UPPER(LTRIM(RTRIM(@ProductName))) + '%'
--     )
-- )

-- AND
-- (
--     @LeadCode IS NULL
--     OR LTRIM(RTRIM(@LeadCode)) = ''
--     OR UPPER(ISNULL(LTRIM(RTRIM(l.LeadCode)), '')) LIKE '%' + UPPER(LTRIM(RTRIM(@LeadCode))) + '%'
-- )

-- AND
-- (
--     @Tel IS NULL
--     OR LTRIM(RTRIM(@Tel)) = ''
--     OR UPPER(ISNULL(LTRIM(RTRIM(cu.Tel)), '')) LIKE '%' + UPPER(LTRIM(RTRIM(@Tel))) + '%'
-- )

-- AND
-- (
--     @CategoryName IS NULL
--     OR LTRIM(RTRIM(@CategoryName)) = ''
--     OR
--     (
--         EXISTS
--         (
--             SELECT 1
--             FROM STRING_SPLIT(CAST(@CategoryName AS NVARCHAR(MAX)), ',') c
--             WHERE UPPER(LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(c.value, '""', ''), '[', ''), ']', '')))) = 'DEFAULT'
--         )
--         AND (p.CategoryName IS NULL OR LTRIM(RTRIM(p.CategoryName)) = '')
--     )
--     OR UPPER(ISNULL(LTRIM(RTRIM(p.CategoryName)), '')) IN
--     (
--         SELECT UPPER(LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', ''))))
--         FROM STRING_SPLIT(CAST(@CategoryName AS NVARCHAR(MAX)), ',')
--         WHERE LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', ''))) <> ''
--           AND UPPER(LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', '')))) <> 'DEFAULT'
--     )
-- )

-- AND
-- (
--     @StoreIds IS NULL
--     OR LTRIM(RTRIM(@StoreIds)) = ''
--     OR EXISTS
--     (
--         SELECT 1
--         FROM STRING_SPLIT(CAST(@StoreIds AS NVARCHAR(MAX)), ',') s
--         WHERE l.StoreId = TRY_CONVERT
--         (
--             uniqueidentifier,
--             LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(s.value, '""', ''), '[', ''), ']', '')))
--         )
--     )
-- )

-- AND
-- (
--     @SatisDanismaniIds IS NULL
--     OR LTRIM(RTRIM(@SatisDanismaniIds)) = ''
--     OR EXISTS
--     (
--         SELECT 1
--         FROM STRING_SPLIT(CAST(@SatisDanismaniIds AS NVARCHAR(MAX)), ',') s
--         WHERE l.SalesPersonKUserId = TRY_CONVERT
--         (
--             uniqueidentifier,
--             LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(s.value, '""', ''), '[', ''), ']', '')))
--         )
--     )
-- )

-- AND
-- (
--     @ProcessCode IS NULL
--     OR LTRIM(RTRIM(@ProcessCode)) = ''
--     OR UPPER(ISNULL(LTRIM(RTRIM(lp.Code)), '')) IN
--     (
--         SELECT UPPER(LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', ''))))
--         FROM STRING_SPLIT(CAST(@ProcessCode AS NVARCHAR(MAX)), ',')
--         WHERE LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', ''))) <> ''
--     )
-- )

-- AND
-- (
--     @StartDate IS NULL
--     OR LTRIM(RTRIM(@StartDate)) = ''
--     OR l.CreatedAt >= CONVERT(date, @StartDate)
-- )

-- AND
-- (
--     @EndDate IS NULL
--     OR LTRIM(RTRIM(@EndDate)) = ''
--     OR l.CreatedAt < DATEADD(day, 1, CONVERT(date, @EndDate))
-- );

-------------------------------------------------------------

DECLARE @KUserId UNIQUEIDENTIFIER = @UserId;

WITH UserRoles AS (
    SELECT r.Name
    FROM dbo.KUserRole ur
    INNER JOIN dbo.KRole r 
        ON r.Id = ur.KRole_Id
    WHERE ur.KUser_Id = @KUserId
      AND ur.IsDeleted = 0
      AND r.IsDeleted = 0
),
IsAdmin AS (
    SELECT CASE 
        WHEN EXISTS (
            SELECT 1 
            FROM UserRoles 
            WHERE Name = 'TimesUstYonetici'
        ) THEN 1 ELSE 0 END AS IsAdmin
)

SELECT
    COUNT(*) AS ToplamTalepSayisi,

    SUM(CASE WHEN lp.Code = 'PENDING' THEN 1 ELSE 0 END) AS OnayBekleyenSayisi,
    SUM(CASE WHEN lp.Code = 'TERMIN_PENDING' THEN 1 ELSE 0 END) AS TerminBekleyenSayisi,
    SUM(CASE WHEN lp.Code = 'APPROVED' THEN 1 ELSE 0 END) AS OnaylananSayisi,
    SUM(CASE WHEN lp.Code = 'REJECTED' THEN 1 ELSE 0 END) AS ReddedilenSayisi,
    SUM(CASE WHEN lp.Code = 'DELIVERY_PENDING' THEN 1 ELSE 0 END) AS TeslimEdilecekSayisi,
    SUM(CASE WHEN lp.Code = 'DELIVERED' THEN 1 ELSE 0 END) AS TeslimEdildiSayisi

FROM tmscrq.TMLead l
LEFT JOIN tmscrq.TMCustomer cu
    ON cu.Id = l.CustomerId
LEFT JOIN tmscrq.TMProduct p
    ON p.Id = l.ProductId
LEFT JOIN dbo.KUser sp
    ON sp.Id = l.SalesPersonKUserId
LEFT JOIN tmscrq.TMLeadProcess lp
    ON lp.Id = l.ProcessID

CROSS JOIN IsAdmin a

WHERE
(
    -- admin → full
    a.IsAdmin = 1

    -- diğerleri → sadece kendi mağazaları
    OR EXISTS
    (
        SELECT 1
        FROM tmscrq.TMUser tu
        WHERE tu.KUserID = @KUserId
          AND tu.StoreId = l.StoreId
    )
)

-- 🔽 AŞAĞISI SENİN ORİJİNAL FİLTRELER (HİÇ DOKUNMADIM)

AND
(
    @MusteriAdi IS NULL
    OR LTRIM(RTRIM(@MusteriAdi)) = ''
    OR UPPER(LTRIM(RTRIM(ISNULL(cu.Name, '') + ' ' + ISNULL(cu.LastName, ''))))
       LIKE '%' + UPPER(LTRIM(RTRIM(@MusteriAdi))) + '%'
)

AND
(
    @ProductName IS NULL
    OR LTRIM(RTRIM(@ProductName)) = ''
    OR
    (
        CHARINDEX(',', @ProductName) > 0
        AND ISNULL(LTRIM(RTRIM(p.ProductName)), '') IN
        (
            SELECT LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', '')))
            FROM STRING_SPLIT(CAST(@ProductName AS NVARCHAR(MAX)), ',')
        )
    )
    OR
    (
        CHARINDEX(',', @ProductName) = 0
        AND UPPER(ISNULL(LTRIM(RTRIM(p.ProductName)), ''))
            LIKE '%' + UPPER(LTRIM(RTRIM(@ProductName))) + '%'
    )
)

AND
(
    @LeadCode IS NULL
    OR LTRIM(RTRIM(@LeadCode)) = ''
    OR UPPER(ISNULL(LTRIM(RTRIM(l.LeadCode)), '')) LIKE '%' + UPPER(LTRIM(RTRIM(@LeadCode))) + '%'
)

AND
(
    @Tel IS NULL
    OR LTRIM(RTRIM(@Tel)) = ''
    OR UPPER(ISNULL(LTRIM(RTRIM(cu.Tel)), '')) LIKE '%' + UPPER(LTRIM(RTRIM(@Tel))) + '%'
)

AND
(
    @CategoryName IS NULL
    OR LTRIM(RTRIM(@CategoryName)) = ''
    OR
    (
        EXISTS
        (
            SELECT 1
            FROM STRING_SPLIT(CAST(@CategoryName AS NVARCHAR(MAX)), ',') c
            WHERE UPPER(LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(c.value, '""', ''), '[', ''), ']', '')))) = 'DEFAULT'
        )
        AND (p.CategoryName IS NULL OR LTRIM(RTRIM(p.CategoryName)) = '')
    )
    OR UPPER(ISNULL(LTRIM(RTRIM(p.CategoryName)), '')) IN
    (
        SELECT UPPER(LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', ''))))
        FROM STRING_SPLIT(CAST(@CategoryName AS NVARCHAR(MAX)), ',')
    )
)

AND
(
    @StoreIds IS NULL
    OR LTRIM(RTRIM(@StoreIds)) = ''
    OR EXISTS
    (
        SELECT 1
        FROM STRING_SPLIT(CAST(@StoreIds AS NVARCHAR(MAX)), ',') s
        WHERE l.StoreId = TRY_CONVERT
        (
            uniqueidentifier,
            LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(s.value, '""', ''), '[', ''), ']', '')))
        )
    )
)

AND
(
    @SatisDanismaniIds IS NULL
    OR LTRIM(RTRIM(@SatisDanismaniIds)) = ''
    OR EXISTS
    (
        SELECT 1
        FROM STRING_SPLIT(CAST(@SatisDanismaniIds AS NVARCHAR(MAX)), ',') s
        WHERE l.SalesPersonKUserId = TRY_CONVERT
        (
            uniqueidentifier,
            LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(s.value, '""', ''), '[', ''), ']', '')))
        )
    )
)

AND
(
    @ProcessCode IS NULL
    OR LTRIM(RTRIM(@ProcessCode)) = ''
    OR UPPER(ISNULL(LTRIM(RTRIM(lp.Code)), '')) IN
    (
        SELECT UPPER(LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', ''))))
        FROM STRING_SPLIT(CAST(@ProcessCode AS NVARCHAR(MAX)), ',')
    )
)

AND
(
    @StartDate IS NULL
    OR LTRIM(RTRIM(@StartDate)) = ''
    OR l.CreatedAt >= CONVERT(date, @StartDate)
)

AND
(
    @EndDate IS NULL
    OR LTRIM(RTRIM(@EndDate)) = ''
    OR l.CreatedAt < DATEADD(day, 1, CONVERT(date, @EndDate))
);", new string[] { "ToplamTalepSayisi", "OnayBekleyenSayisi", "TerminBekleyenSayisi", "OnaylananSayisi", "ReddedilenSayisi", "TeslimEdilecekSayisi", "TeslimEdildiSayisi" }, prms_TMLeadProcessCountSummary_1.ToArray());
            ;


            return Ok(result);
        }


        [HttpPost, Route("LeadListComponent_60588_onChange")]
        public IActionResult LeadListComponent_60588_onChange(LeadListComponent_60588_onChange_Request request)
        {

            KProviderManager.Authorization.IsAuthorizedForRoles(appId, appName, screenId, screenName, new List<string> { $"70de6cfc-6087-6059-59b4-0b5a8527af6b", "4da1f213-c8e4-0b50-5c84-02fd13f1a622", "c4e882ef-977d-f613-7694-230ac83919d2", "b4bfd39c-ac02-f442-c899-7a2374a45b47", "cdb536b0-6297-155f-d446-8453d8a60304", "TimesYonetici", "TimesUstYonetici", "TimesSatisPersoneli", "TimesMagazaMuduru", "TimesAdmin" });

            var result = new LeadListComponent_60588_onChange_Response();

            var prms_TM_GetLeads_0 = new List<kSqlParameter>();
            prms_TM_GetLeads_0.Add(new kSqlParameter() { Name = "StepOrder", Value = request.StepOrder_0 });
            prms_TM_GetLeads_0.Add(new kSqlParameter() { Name = "UserId", Value = Kuika.Common.KContext.CurrentUser?.Id });
            prms_TM_GetLeads_0.Add(new kSqlParameter() { Name = "MusteriAdi", Value = request.MusteriAdi_0 });
            prms_TM_GetLeads_0.Add(new kSqlParameter() { Name = "ProductName", Value = request.ProductName_0 });
            prms_TM_GetLeads_0.Add(new kSqlParameter() { Name = "LeadCode", Value = request.LeadCode_0 });
            prms_TM_GetLeads_0.Add(new kSqlParameter() { Name = "Tel", Value = request.Tel_0 });
            prms_TM_GetLeads_0.Add(new kSqlParameter() { Name = "CategoryName", Value = request.CategoryName_0 });
            prms_TM_GetLeads_0.Add(new kSqlParameter() { Name = "StoreIds", Value = request.StoreIds_0 });
            prms_TM_GetLeads_0.Add(new kSqlParameter() { Name = "SatisDanismaniIds", Value = request.SatisDanismaniIds_0 });
            prms_TM_GetLeads_0.Add(new kSqlParameter() { Name = "ProcessCode", Value = request.ProcessCode_0 });
            prms_TM_GetLeads_0.Add(new kSqlParameter() { Name = "StartDate", Value = request.StartDate_0 });
            prms_TM_GetLeads_0.Add(new kSqlParameter() { Name = "EndDate", Value = request.EndDate_0 });
            using var auditTM_GetLeads_0 = ActionAuditScope.Begin("79bac5e6-21d7-9838-b2ca-83192a433d94", "TM_GetLeads", applicationName: "wbTimesCRM", screenOrEndpointName: "LeadList");
            result.TM_GetLeads = KPersister.Fetch(KContext.GetConnectionString(), @"-- SET LANGUAGE Turkish;

-- SELECT
-- CASE 
--     WHEN EXISTS (
--         SELECT 1 
--         FROM tmscrq.TMLeadReservation r
--         WHERE r.LeadId = l.Id
--           AND r.IsActive = 1
--           AND r.IsApproved = 1
--     ) THEN N'Evet'

--     WHEN EXISTS (
--         SELECT 1 
--         FROM tmscrq.TMLeadReservation r
--         WHERE r.LeadId = l.Id
--           AND r.IsActive = 1
--           AND ISNULL(r.IsApproved,0) = 0
--     ) THEN N'Onay Bekliyor'

--     ELSE N'Hayır'
-- END AS RezerveDurumu,
--     l.Id AS LeadId,
--     l.IsReserved,
--     ISNULL(NULLIF(LTRIM(RTRIM(l.LeadCode)), ''), '-') AS LeadNumarasi,
--     CONVERT(varchar(10), l.CreatedAt, 103) AS TalepTarihi,

--     p.Id AS ProductId,
--     ISNULL(NULLIF(LTRIM(RTRIM(p.ProductName)), ''), '-') AS ProductName,
--     ISNULL(NULLIF(LTRIM(RTRIM(p.Bracelet)), ''), '-') AS Bilezik,
--     ISNULL(NULLIF(LTRIM(RTRIM(p.Brand)), ''), '-') AS Brand,
--     ISNULL(NULLIF(LTRIM(RTRIM(p.Dial)), ''), '-') AS Kadran,
--     ISNULL(NULLIF(LTRIM(RTRIM(p.ProductCode)), ''), '-') AS RefCode,
--     ISNULL(NULLIF(LTRIM(RTRIM(p.Referance)), ''), '-') AS Referans,

--     ISNULL(
--         NULLIF(
--             LTRIM(RTRIM(ISNULL(cu.Name, '') + ' ' + ISNULL(cu.LastName, '')))
--         , '')
--     , '-') AS Musteri,

--     ISNULL(NULLIF(LTRIM(RTRIM(cu.CityName)), ''), '-') AS Lokasyon,
--     ISNULL(NULLIF(LTRIM(RTRIM(cu.DistrictName)), ''), '-') AS Ilce,
--     ISNULL(NULLIF(LTRIM(RTRIM(cu.CountryName)), ''), '-') AS Ulke,
--     ISNULL(NULLIF(LTRIM(RTRIM(cu.Info)), ''), '-') AS MusteriInfo,

--     CASE
--         WHEN cu.IsShopping = 1 THEN N'Evet'
--         WHEN cu.IsShopping = 0 THEN N'Hayır'
--         ELSE '-'
--     END AS AlisverisiVarMi,

--     ISNULL(NULLIF(LTRIM(RTRIM(cu.Tel)), ''), '-') AS IrtibatNumarasi,
--     ISNULL(NULLIF(LTRIM(RTRIM(cu.Email)), ''), '-') AS EmailAdresi,

--     ISNULL(NULLIF(LTRIM(RTRIM(cr.ContactResourceName)), ''), '-') AS IletisimKaynagi,

--     ISNULL(NULLIF(LTRIM(RTRIM(p.CategoryName)), ''), '-') AS CategoryName,
--     '-' AS CategoryCode,

--     ISNULL(NULLIF(LTRIM(RTRIM(ls.Name)), ''), '-') AS LeadDurumu,
--     ISNULL(NULLIF(LTRIM(RTRIM(ns.Name)), ''), '-') AS SonrakiAdim,

--     ISNULL(NULLIF(LTRIM(RTRIM(lp.Name)), ''), '-') AS ProcessName,
--     ISNULL(NULLIF(LTRIM(RTRIM(lp.Code)), ''), '-') AS ProcessCode,
--     lp.StepOrder,
-- CASE
--     WHEN EXISTS
--     (
--         SELECT 1
--         FROM tmscrq.TMLeadReservation r
--         WHERE r.LeadId = l.Id
--           AND r.IsActive = 1
--           AND ISNULL(r.IsApproved,0) = 0
--     )
--     THEN 10
--     ELSE lp.StepOrder
-- END AS SelectedStepOrder,

--     ISNULL(
--         CASE
--             WHEN l.EstimatedDate IS NOT NULL
--             THEN CAST(YEAR(l.EstimatedDate) AS VARCHAR(4)) + ' ' + DATENAME(MONTH, l.EstimatedDate)
--             ELSE NULL
--         END,
--         '-'
--     ) AS TerminTarihi,

--     ISNULL(
--         NULLIF(
--             LTRIM(RTRIM(ISNULL(sp.FirstName, '') + ' ' + ISNULL(sp.LastName, '')))
--         , '')
--     , '-') AS SatisDanismani,

--     ISNULL(NULLIF(LTRIM(RTRIM(st.StoreDesc)), ''), '-') AS StoreName

-- FROM tmscrq.TMLead l
-- LEFT JOIN tmscrq.TMLeadStatu ls
--     ON ls.Id = l.StatuId
-- LEFT JOIN tmscrq.TMCustomer cu
--     ON cu.Id = l.CustomerId
-- LEFT JOIN tmscrq.TMProduct p
--     ON p.Id = l.ProductId
-- LEFT JOIN tmscrq.TMContactResource cr
--     ON cr.Id = l.ContactResourceId
-- LEFT JOIN dbo.KUser sp
--     ON sp.Id = l.SalesPersonKUserId
-- LEFT JOIN tmscrq.TMStore st
--     ON st.Id = l.StoreId
-- LEFT JOIN tmscrq.TMLeadProcess lp
--     ON lp.Id = l.ProcessID
-- LEFT JOIN tmscrq.TMLeadNextStep ns
--     ON ns.Id = l.NextStepId

-- WHERE
-- (
--     EXISTS
--     (
--         SELECT 1
--         FROM dbo.KUserRole ur
--         INNER JOIN dbo.KRole r
--             ON r.Id = ur.KRole_Id
--         WHERE ur.KUser_Id = @UserId
--           AND ur.IsDeleted = 0
--           AND r.IsDeleted = 0
--           AND r.Name IN ('TimesYonetici', 'TimesUstYonetici')
--     )
--     OR
--     (
--         EXISTS
--         (
--             SELECT 1
--             FROM dbo.KUserRole ur
--             INNER JOIN dbo.KRole r
--                 ON r.Id = ur.KRole_Id
--             WHERE ur.KUser_Id = @UserId
--               AND ur.IsDeleted = 0
--               AND r.IsDeleted = 0
--               AND r.Name IN ('TimesMagazaMuduru', 'TimesSatisPersoneli')
--         )
--         AND EXISTS
--         (
--             SELECT 1
--             FROM tmscrq.TMUser tu
--             WHERE tu.KUserID = @UserId
--               AND tu.StoreId = l.StoreId
--         )
--     )
-- )

-- AND
-- (
--     @MusteriAdi IS NULL
--     OR LTRIM(RTRIM(@MusteriAdi)) = ''
--     OR UPPER(LTRIM(RTRIM(ISNULL(cu.Name,'') + ' ' + ISNULL(cu.LastName,''))))
--        LIKE '%' + UPPER(LTRIM(RTRIM(@MusteriAdi))) + '%'
-- )

-- AND
-- (
--     @ProductName IS NULL
--     OR LTRIM(RTRIM(@ProductName)) = ''
--     OR
--     (
--         CHARINDEX(',', @ProductName) > 0
--         AND ISNULL(LTRIM(RTRIM(p.ProductName)), '') IN
--         (
--             SELECT LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', '')))
--             FROM STRING_SPLIT(CAST(@ProductName AS NVARCHAR(MAX)), ',')
--             WHERE LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', ''))) <> ''
--         )
--     )
--     OR
--     (
--         CHARINDEX(',', @ProductName) = 0
--         AND UPPER(ISNULL(LTRIM(RTRIM(p.ProductName)), ''))
--             LIKE '%' + UPPER(LTRIM(RTRIM(@ProductName))) + '%'
--     )
-- )

-- AND
-- (
--     @LeadCode IS NULL
--     OR LTRIM(RTRIM(@LeadCode)) = ''
--     OR UPPER(ISNULL(LTRIM(RTRIM(l.LeadCode)), '')) LIKE '%' + UPPER(LTRIM(RTRIM(@LeadCode))) + '%'
-- )

-- AND
-- (
--     @Tel IS NULL
--     OR LTRIM(RTRIM(@Tel)) = ''
--     OR UPPER(ISNULL(LTRIM(RTRIM(cu.Tel)), '')) LIKE '%' + UPPER(LTRIM(RTRIM(@Tel))) + '%'
-- )

-- -- AND
-- -- (
-- --     @CategoryName IS NULL
-- --     OR LTRIM(RTRIM(@CategoryName)) = ''
-- --     OR
-- --     (
-- --         EXISTS
-- --         (
-- --             SELECT 1
-- --             FROM STRING_SPLIT(CAST(@CategoryName AS NVARCHAR(MAX)), ',') c
-- --             WHERE UPPER(LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(c.value, '""', ''), '[', ''), ']', '')))) = 'DEFAULT'
-- --         )
-- --         AND (p.CategoryName IS NULL OR LTRIM(RTRIM(p.CategoryName)) = '')
-- --     )
-- --     OR UPPER(ISNULL(LTRIM(RTRIM(p.CategoryName)), '')) IN
-- --     (
-- --         SELECT UPPER(LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', ''))))
-- --         FROM STRING_SPLIT(CAST(@CategoryName AS NVARCHAR(MAX)), ',')
-- --         WHERE LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', ''))) <> ''
-- --           AND UPPER(LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', '')))) <> 'DEFAULT'
-- --     )
-- -- )

-- AND
-- (
--     @CategoryName IS NULL
--     OR LTRIM(RTRIM(@CategoryName)) = ''
--     OR UPPER(ISNULL(LTRIM(RTRIM(p.CategoryName)), '')) IN
--     (
--         SELECT UPPER(LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value,'""',''),'[',''),']',''))))
--         FROM STRING_SPLIT(CAST(@CategoryName AS NVARCHAR(MAX)), ',')
--         WHERE LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value,'""',''),'[',''),']',''))) <> ''
--     )
-- )

-- AND
-- (
--     @StoreIds IS NULL
--     OR LTRIM(RTRIM(@StoreIds)) = ''
--     OR EXISTS
--     (
--         SELECT 1
--         FROM STRING_SPLIT(CAST(@StoreIds AS NVARCHAR(MAX)), ',') s
--         WHERE l.StoreId = TRY_CONVERT
--         (
--             uniqueidentifier,
--             LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(s.value, '""', ''), '[', ''), ']', '')))
--         )
--     )
-- )

-- AND
-- (
--     @SatisDanismaniIds IS NULL
--     OR LTRIM(RTRIM(@SatisDanismaniIds)) = ''
--     OR EXISTS
--     (
--         SELECT 1
--         FROM STRING_SPLIT(CAST(@SatisDanismaniIds AS NVARCHAR(MAX)), ',') s
--         WHERE l.SalesPersonKUserId = TRY_CONVERT
--         (
--             uniqueidentifier,
--             LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(s.value, '""', ''), '[', ''), ']', '')))
--         )
--     )
-- )

-- AND
-- (
--     @ProcessCode IS NULL
--     OR LTRIM(RTRIM(@ProcessCode)) = ''
--     OR UPPER(ISNULL(LTRIM(RTRIM(lp.Code)), '')) IN
--     (
--         SELECT UPPER(LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', ''))))
--         FROM STRING_SPLIT(CAST(@ProcessCode AS NVARCHAR(MAX)), ',')
--         WHERE LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', ''))) <> ''
--     )
-- )

-- AND
-- (
--     @StepOrder IS NULL

--     OR
--     (
--         @StepOrder = 10
--         AND EXISTS
--         (
--             SELECT 1
--             FROM tmscrq.TMLeadReservation r
--             WHERE r.LeadId = l.Id
--               AND r.IsActive = 1
--               AND ISNULL(r.IsApproved,0) = 0
--         )
--     )

--     OR
--     (
--         @StepOrder <> 10
--         AND lp.StepOrder = @StepOrder
--     )
-- )

-- AND
-- (
--     @StartDate IS NULL
--     OR LTRIM(RTRIM(@StartDate)) = ''
--     OR l.CreatedAt >= CONVERT(date, @StartDate)
-- )

-- AND
-- (
--     @EndDate IS NULL
--     OR LTRIM(RTRIM(@EndDate)) = ''
--     OR l.CreatedAt < DATEADD(day, 1, CONVERT(date, @EndDate))
-- )

-- ORDER BY l.CreatedAt DESC;

------------------------++++++++++++++++++++++++-------------------
-- SET LANGUAGE Turkish;

-- SELECT
-- CASE 
--     WHEN EXISTS (
--         SELECT 1 
--         FROM tmscrq.TMLeadReservation r
--         WHERE r.LeadId = l.Id
--           AND r.IsActive = 1
--           AND r.IsApproved = 1
--     ) THEN N'Evet'

--     WHEN EXISTS (
--         SELECT 1 
--         FROM tmscrq.TMLeadReservation r
--         WHERE r.LeadId = l.Id
--           AND r.IsActive = 1
--           AND ISNULL(r.IsApproved,0) = 0
--     ) THEN N'Onay Bekliyor'

--     ELSE N'Hayır'
-- END AS RezerveDurumu,
--     l.Id AS LeadId,
--     l.IsReserved,
--     ISNULL(NULLIF(LTRIM(RTRIM(l.LeadCode)), ''), '-') AS LeadNumarasi,
--     CONVERT(varchar(10), l.CreatedAt, 103) AS TalepTarihi,

--     p.Id AS ProductId,
--     ISNULL(NULLIF(LTRIM(RTRIM(p.ProductName)), ''), '-') AS ProductName,
--     ISNULL(NULLIF(LTRIM(RTRIM(p.Bracelet)), ''), '-') AS Bilezik,
--     ISNULL(NULLIF(LTRIM(RTRIM(p.Brand)), ''), '-') AS Brand,
--     ISNULL(NULLIF(LTRIM(RTRIM(p.Dial)), ''), '-') AS Kadran,
--     ISNULL(NULLIF(LTRIM(RTRIM(p.ProductCode)), ''), '-') AS RefCode,
--     ISNULL(NULLIF(LTRIM(RTRIM(p.Referance)), ''), '-') AS Referans,

--     ISNULL(
--         NULLIF(
--             LTRIM(RTRIM(ISNULL(cu.Name, '') + ' ' + ISNULL(cu.LastName, '')))
--         , '')
--     , '-') AS Musteri,

--     ISNULL(NULLIF(LTRIM(RTRIM(cu.CityName)), ''), '-') AS Lokasyon,
--     ISNULL(NULLIF(LTRIM(RTRIM(cu.DistrictName)), ''), '-') AS Ilce,
--     ISNULL(NULLIF(LTRIM(RTRIM(cu.CountryName)), ''), '-') AS Ulke,
--     ISNULL(NULLIF(LTRIM(RTRIM(cu.Info)), ''), '-') AS MusteriInfo,

--     CASE
--         WHEN cu.IsShopping = 1 THEN N'Evet'
--         WHEN cu.IsShopping = 0 THEN N'Hayır'
--         ELSE '-'
--     END AS AlisverisiVarMi,

--     ISNULL(NULLIF(LTRIM(RTRIM(cu.Tel)), ''), '-') AS IrtibatNumarasi,
--     ISNULL(NULLIF(LTRIM(RTRIM(cu.Email)), ''), '-') AS EmailAdresi,

--     ISNULL(NULLIF(LTRIM(RTRIM(cr.ContactResourceName)), ''), '-') AS IletisimKaynagi,

--     ISNULL(NULLIF(LTRIM(RTRIM(p.CategoryName)), ''), '-') AS CategoryName,
--     '-' AS CategoryCode,

--     ISNULL(NULLIF(LTRIM(RTRIM(ls.Name)), ''), '-') AS LeadDurumu,
--     ISNULL(NULLIF(LTRIM(RTRIM(ns.Name)), ''), '-') AS SonrakiAdim,

--     ISNULL(NULLIF(LTRIM(RTRIM(lp.Name)), ''), '-') AS ProcessName,
--     ISNULL(NULLIF(LTRIM(RTRIM(lp.Code)), ''), '-') AS ProcessCode,
--     lp.StepOrder,
    
--     -- DÜZELTİLEN ALAN: SelectedStepOrder
--     CASE
--         WHEN EXISTS
--         (
--             SELECT 1
--             FROM tmscrq.TMLeadReservation r
--             WHERE r.LeadId = l.Id
--               AND r.IsActive = 1
--               AND ISNULL(r.IsApproved,0) = 0
--         )
--         THEN 10
--         ELSE lp.StepOrder
--     END AS SelectedStepOrder,

--     ISNULL(
--         CASE
--             WHEN l.EstimatedDate IS NOT NULL
--             THEN CAST(YEAR(l.EstimatedDate) AS VARCHAR(4)) + ' ' + DATENAME(MONTH, l.EstimatedDate)
--             ELSE NULL
--         END,
--         '-'
--     ) AS TerminTarihi,

--     ISNULL(
--         NULLIF(
--             LTRIM(RTRIM(ISNULL(sp.FirstName, '') + ' ' + ISNULL(sp.LastName, '')))
--         , '')
--     , '-') AS SatisDanismani,

--     ISNULL(NULLIF(LTRIM(RTRIM(st.StoreDesc)), ''), '-') AS StoreName

-- FROM tmscrq.TMLead l
-- LEFT JOIN tmscrq.TMLeadStatu ls
--     ON ls.Id = l.StatuId
-- LEFT JOIN tmscrq.TMCustomer cu
--     ON cu.Id = l.CustomerId
-- LEFT JOIN tmscrq.TMProduct p
--     ON p.Id = l.ProductId
-- LEFT JOIN tmscrq.TMContactResource cr
--     ON cr.Id = l.ContactResourceId
-- LEFT JOIN dbo.KUser sp
--     ON sp.Id = l.SalesPersonKUserId
-- LEFT JOIN tmscrq.TMStore st
--     ON st.Id = l.StoreId
-- LEFT JOIN tmscrq.TMLeadProcess lp
--     ON lp.Id = l.ProcessID
-- LEFT JOIN tmscrq.TMLeadNextStep ns
--     ON ns.Id = l.NextStepId

-- WHERE
-- (
--     EXISTS
--     (
--         SELECT 1
--         FROM dbo.KUserRole ur
--         INNER JOIN dbo.KRole r
--             ON r.Id = ur.KRole_Id
--         WHERE ur.KUser_Id = @UserId
--           AND ur.IsDeleted = 0
--           AND r.IsDeleted = 0
--           AND r.Name IN ('TimesYonetici', 'TimesUstYonetici')
--     )
--     OR
--     (
--         EXISTS
--         (
--             SELECT 1
--             FROM dbo.KUserRole ur
--             INNER JOIN dbo.KRole r
--                 ON r.Id = ur.KRole_Id
--             WHERE ur.KUser_Id = @UserId
--               AND ur.IsDeleted = 0
--               AND r.IsDeleted = 0
--               AND r.Name IN ('TimesMagazaMuduru', 'TimesSatisPersoneli')
--         )
--         AND EXISTS
--         (
--             SELECT 1
--             FROM tmscrq.TMUser tu
--             WHERE tu.KUserID = @UserId
--               AND tu.StoreId = l.StoreId
--         )
--     )
-- )

-- AND
-- (
--     @MusteriAdi IS NULL
--     OR LTRIM(RTRIM(@MusteriAdi)) = ''
--     OR UPPER(LTRIM(RTRIM(ISNULL(cu.Name,'') + ' ' + ISNULL(cu.LastName,''))))
--        LIKE '%' + UPPER(LTRIM(RTRIM(@MusteriAdi))) + '%'
-- )

-- AND
-- (
--     @ProductName IS NULL
--     OR LTRIM(RTRIM(@ProductName)) = ''
--     OR
--     (
--         CHARINDEX(',', @ProductName) > 0
--         AND ISNULL(LTRIM(RTRIM(p.ProductName)), '') IN
--         (
--             SELECT LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', '')))
--             FROM STRING_SPLIT(CAST(@ProductName AS NVARCHAR(MAX)), ',')
--             WHERE LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', ''))) <> ''
--         )
--     )
--     OR
--     (
--         CHARINDEX(',', @ProductName) = 0
--         AND UPPER(ISNULL(LTRIM(RTRIM(p.ProductName)), ''))
--             LIKE '%' + UPPER(LTRIM(RTRIM(@ProductName))) + '%'
--     )
-- )

-- AND
-- (
--     @LeadCode IS NULL
--     OR LTRIM(RTRIM(@LeadCode)) = ''
--     OR UPPER(ISNULL(LTRIM(RTRIM(l.LeadCode)), '')) LIKE '%' + UPPER(LTRIM(RTRIM(@LeadCode))) + '%'
-- )

-- AND
-- (
--     @Tel IS NULL
--     OR LTRIM(RTRIM(@Tel)) = ''
--     OR UPPER(ISNULL(LTRIM(RTRIM(cu.Tel)), '')) LIKE '%' + UPPER(LTRIM(RTRIM(@Tel))) + '%'
-- )

-- AND
-- (
--     @CategoryName IS NULL
--     OR LTRIM(RTRIM(@CategoryName)) = ''
--     OR UPPER(ISNULL(LTRIM(RTRIM(p.CategoryName)), '')) IN
--     (
--         SELECT UPPER(LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value,'""',''),'[',''),']',''))))
--         FROM STRING_SPLIT(CAST(@CategoryName AS NVARCHAR(MAX)), ',')
--         WHERE LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value,'""',''),'[',''),']',''))) <> ''
--     )
-- )

-- AND
-- (
--     @StoreIds IS NULL
--     OR LTRIM(RTRIM(@StoreIds)) = ''
--     OR EXISTS
--     (
--         SELECT 1
--         FROM STRING_SPLIT(CAST(@StoreIds AS NVARCHAR(MAX)), ',') s
--         WHERE l.StoreId = TRY_CONVERT
--         (
--             uniqueidentifier,
--             LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(s.value, '""', ''), '[', ''), ']', '')))
--         )
--     )
-- )

-- AND
-- (
--     @SatisDanismaniIds IS NULL
--     OR LTRIM(RTRIM(@SatisDanismaniIds)) = ''
--     OR EXISTS
--     (
--         SELECT 1
--         FROM STRING_SPLIT(CAST(@SatisDanismaniIds AS NVARCHAR(MAX)), ',') s
--         WHERE l.SalesPersonKUserId = TRY_CONVERT
--         (
--             uniqueidentifier,
--             LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(s.value, '""', ''), '[', ''), ']', '')))
--         )
--     )
-- )

-- AND
-- (
--     @ProcessCode IS NULL
--     OR LTRIM(RTRIM(@ProcessCode)) = ''
--     OR UPPER(ISNULL(LTRIM(RTRIM(lp.Code)), '')) IN
--     (
--         SELECT UPPER(LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', ''))))
--         FROM STRING_SPLIT(CAST(@ProcessCode AS NVARCHAR(MAX)), ',')
--         WHERE LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', ''))) <> ''
--     )
-- )

-- -- DÜZELTİLEN ALAN: @StepOrder Filtresi (tek blok)
-- AND
-- (
--     @StepOrder IS NULL

--     OR

--     (
--         @StepOrder = 10
--         AND EXISTS
--         (
--             SELECT 1
--             FROM tmscrq.TMLeadReservation r
--             WHERE r.LeadId = l.Id
--               AND r.IsActive = 1
--               AND ISNULL(r.IsApproved,0) = 0
--         )
--     )

--     OR

--     (
--         @StepOrder <> 10
--         AND lp.StepOrder = @StepOrder
--     )
-- )

-- AND
-- (
--     @StartDate IS NULL
--     OR LTRIM(RTRIM(@StartDate)) = ''
--     OR l.CreatedAt >= CONVERT(date, @StartDate)
-- )

-- AND
-- (
--     @EndDate IS NULL
--     OR LTRIM(RTRIM(@EndDate)) = ''
--     OR l.CreatedAt < DATEADD(day, 1, CONVERT(date, @EndDate))
-- )

-- ORDER BY l.CreatedAt DESC;



SET LANGUAGE Turkish;

SELECT
CASE 
    WHEN EXISTS (
        SELECT 1 
        FROM tmscrq.TMLeadReservation r
        WHERE r.LeadId = l.Id
          AND r.IsActive = 1
          AND r.IsApproved = 1
    ) THEN N'Evet'

    WHEN EXISTS (
        SELECT 1 
        FROM tmscrq.TMLeadReservation r
        WHERE r.LeadId = l.Id
          AND r.IsActive = 1
          AND ISNULL(r.IsApproved,0) = 0
    ) THEN N'Onay Bekliyor'

    ELSE N'Hayır'
END AS RezerveDurumu,
    l.Id AS LeadId,
    l.IsReserved,
    ISNULL(NULLIF(LTRIM(RTRIM(l.LeadCode)), ''), '-') AS LeadNumarasi,
     FORMAT(l.CreatedAt, 'dd MMMM yyyy', 'tr-TR') AS TalepTarihi,

    p.Id AS ProductId,
    ISNULL(NULLIF(LTRIM(RTRIM(p.ProductName)), ''), '-') AS ProductName,
    ISNULL(NULLIF(LTRIM(RTRIM(p.Bracelet)), ''), '-') AS Bilezik,
    ISNULL(NULLIF(LTRIM(RTRIM(p.Brand)), ''), '-') AS Brand,
    ISNULL(NULLIF(LTRIM(RTRIM(p.Dial)), ''), '-') AS Kadran,
    ISNULL(NULLIF(LTRIM(RTRIM(p.ProductCode)), ''), '-') AS RefCode,
    ISNULL(NULLIF(LTRIM(RTRIM(p.Referance)), ''), '-') AS Referans,

    ISNULL(
        NULLIF(
            LTRIM(RTRIM(ISNULL(cu.Name, '') + ' ' + ISNULL(cu.LastName, '')))
        , '')
    , '-') AS Musteri,

    ISNULL(NULLIF(LTRIM(RTRIM(cu.CityName)), ''), '-') AS Lokasyon,
    ISNULL(NULLIF(LTRIM(RTRIM(cu.DistrictName)), ''), '-') AS Ilce,
    ISNULL(NULLIF(LTRIM(RTRIM(cu.CountryName)), ''), '-') AS Ulke,
    ISNULL(NULLIF(LTRIM(RTRIM(cu.Info)), ''), '-') AS MusteriInfo,

    CASE
        WHEN cu.IsShopping = 1 THEN N'Evet'
        WHEN cu.IsShopping = 0 THEN N'Hayır'
        ELSE '-'
    END AS AlisverisiVarMi,

    ISNULL(NULLIF(LTRIM(RTRIM(cu.Tel)), ''), '-') AS IrtibatNumarasi,
    ISNULL(NULLIF(LTRIM(RTRIM(cu.Email)), ''), '-') AS EmailAdresi,

    ISNULL(NULLIF(LTRIM(RTRIM(cr.ContactResourceName)), ''), '-') AS IletisimKaynagi,

    ISNULL(NULLIF(LTRIM(RTRIM(p.CategoryName)), ''), '-') AS CategoryName,
    '-' AS CategoryCode,

    ISNULL(NULLIF(LTRIM(RTRIM(ls.Name)), ''), '-') AS LeadDurumu,
    ISNULL(NULLIF(LTRIM(RTRIM(ns.Name)), ''), '-') AS SonrakiAdim,

    ISNULL(NULLIF(LTRIM(RTRIM(lp.Name)), ''), '-') AS ProcessName,
    ISNULL(NULLIF(LTRIM(RTRIM(lp.Code)), ''), '-') AS ProcessCode,
    lp.StepOrder,
    
    -- DÜZELTİLEN ALAN: SelectedStepOrder
    CASE
        WHEN EXISTS
        (
            SELECT 1
            FROM tmscrq.TMLeadReservation r
            WHERE r.LeadId = l.Id
              AND r.IsActive = 1
              AND ISNULL(r.IsApproved,0) = 0
        )
        THEN 10
        ELSE lp.StepOrder
    END AS SelectedStepOrder,

    ISNULL(
        CASE
            WHEN l.EstimatedDate IS NOT NULL
            THEN CAST(YEAR(l.EstimatedDate) AS VARCHAR(4)) + ' ' + DATENAME(MONTH, l.EstimatedDate)
            ELSE NULL
        END,
        '-'
    ) AS TerminTarihi,

    ISNULL(
        NULLIF(
            LTRIM(RTRIM(ISNULL(sp.FirstName, '') + ' ' + ISNULL(sp.LastName, '')))
        , '')
    , '-') AS SatisDanismani,

    ISNULL(NULLIF(LTRIM(RTRIM(st.StoreDesc)), ''), '-') AS StoreName

FROM tmscrq.TMLead l
LEFT JOIN tmscrq.TMLeadStatu ls
    ON ls.Id = l.StatuId
LEFT JOIN tmscrq.TMCustomer cu
    ON cu.Id = l.CustomerId
LEFT JOIN tmscrq.TMProduct p
    ON p.Id = l.ProductId
LEFT JOIN tmscrq.TMContactResource cr
    ON cr.Id = l.ContactResourceId
LEFT JOIN dbo.KUser sp
    ON sp.Id = l.SalesPersonKUserId
LEFT JOIN tmscrq.TMStore st
    ON st.Id = l.StoreId
LEFT JOIN tmscrq.TMLeadProcess lp
    ON lp.Id = l.ProcessID
LEFT JOIN tmscrq.TMLeadNextStep ns
    ON ns.Id = l.NextStepId

WHERE
(
    EXISTS
    (
        SELECT 1
        FROM dbo.KUserRole ur
        INNER JOIN dbo.KRole r
            ON r.Id = ur.KRole_Id
        WHERE ur.KUser_Id = @UserId
          AND ur.IsDeleted = 0
          AND r.IsDeleted = 0
          AND r.Name IN ('TimesYonetici', 'TimesUstYonetici')
    )
    OR
    (
        EXISTS
        (
            SELECT 1
            FROM dbo.KUserRole ur
            INNER JOIN dbo.KRole r
                ON r.Id = ur.KRole_Id
            WHERE ur.KUser_Id = @UserId
              AND ur.IsDeleted = 0
              AND r.IsDeleted = 0
              AND r.Name IN ('TimesMagazaMuduru', 'TimesSatisPersoneli')
        )
        AND EXISTS
        (
            SELECT 1
            FROM tmscrq.TMUser tu
            WHERE tu.KUserID = @UserId
              AND tu.StoreId = l.StoreId
        )
    )
)

AND
(
    ISNULL(@MusteriAdi, '') = ''
    OR UPPER(ISNULL(cu.Name, '')) LIKE '%' + UPPER(LTRIM(RTRIM(@MusteriAdi))) + '%'
    OR UPPER(ISNULL(cu.LastName, '')) LIKE '%' + UPPER(LTRIM(RTRIM(@MusteriAdi))) + '%'
    OR UPPER(
        ISNULL(cu.Name, '') + ' ' + ISNULL(cu.LastName, '')
    ) LIKE '%' + UPPER(LTRIM(RTRIM(@MusteriAdi))) + '%'
)

AND
(
    @ProductName IS NULL
    OR LTRIM(RTRIM(@ProductName)) = ''
    OR
    (
        CHARINDEX(',', @ProductName) > 0
        AND ISNULL(LTRIM(RTRIM(p.ProductName)), '') IN
        (
            SELECT LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', '')))
            FROM STRING_SPLIT(CAST(@ProductName AS NVARCHAR(MAX)), ',')
            WHERE LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', ''))) <> ''
        )
    )
    OR
    (
        CHARINDEX(',', @ProductName) = 0
        AND UPPER(ISNULL(LTRIM(RTRIM(p.ProductName)), ''))
            LIKE '%' + UPPER(LTRIM(RTRIM(@ProductName))) + '%'
    )
)

AND
(
    ISNULL(@LeadCode, '') = ''
    OR UPPER(ISNULL(l.LeadCode, ''))
        LIKE '%' + UPPER(LTRIM(RTRIM(@LeadCode))) + '%'
    OR REPLACE(
        REPLACE(
            REPLACE(
                UPPER(ISNULL(l.LeadCode, '')),
                '-', ''
            ),
            ' ', ''
        ),
        '/', ''
    )
    LIKE '%' +
    REPLACE(
        REPLACE(
            REPLACE(
                UPPER(LTRIM(RTRIM(@LeadCode))),
                '-', ''
            ),
            ' ', ''
        ),
        '/', ''
    )
    + '%'
)

AND
(
    @Tel IS NULL
    OR LTRIM(RTRIM(@Tel)) = ''
    OR UPPER(ISNULL(LTRIM(RTRIM(cu.Tel)), '')) LIKE '%' + UPPER(LTRIM(RTRIM(@Tel))) + '%'
)

AND
(
    @CategoryName IS NULL
    OR LTRIM(RTRIM(@CategoryName)) = ''
    OR UPPER(ISNULL(LTRIM(RTRIM(p.CategoryName)), '')) IN
    (
        SELECT UPPER(LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value,'""',''),'[',''),']',''))))
        FROM STRING_SPLIT(CAST(@CategoryName AS NVARCHAR(MAX)), ',')
        WHERE LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value,'""',''),'[',''),']',''))) <> ''
    )
)

AND
(
    @StoreIds IS NULL
    OR LTRIM(RTRIM(@StoreIds)) = ''
    OR EXISTS
    (
        SELECT 1
        FROM STRING_SPLIT(CAST(@StoreIds AS NVARCHAR(MAX)), ',') s
        WHERE l.StoreId = TRY_CONVERT
        (
            uniqueidentifier,
            LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(s.value, '""', ''), '[', ''), ']', '')))
        )
    )
)

AND
(
    @SatisDanismaniIds IS NULL
    OR LTRIM(RTRIM(@SatisDanismaniIds)) = ''
    OR EXISTS
    (
        SELECT 1
        FROM STRING_SPLIT(CAST(@SatisDanismaniIds AS NVARCHAR(MAX)), ',') s
        WHERE l.SalesPersonKUserId = TRY_CONVERT
        (
            uniqueidentifier,
            LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(s.value, '""', ''), '[', ''), ']', '')))
        )
    )
)

AND
(
    ISNULL(@ProcessCode, '') = ''
    OR EXISTS
    (
        SELECT 1
        FROM STRING_SPLIT(
            CONVERT(NVARCHAR(MAX), @ProcessCode),
            ','
        ) AS s
        WHERE
            UPPER(LTRIM(RTRIM(s.value))) =
            UPPER(LTRIM(RTRIM(ISNULL(lp.Code, ''))))
    )
)

-- DÜZELTİLEN ALAN: @StepOrder Filtresi (0 verilince tümü gelsin)
AND
(
    @StepOrder IS NULL
    OR @StepOrder = 0  -- 👈 YENİ EKLENDI: 0 verilince tüm kayıtlar gelir
    OR
    (
        @StepOrder = 10
        AND EXISTS
        (
            SELECT 1
            FROM tmscrq.TMLeadReservation r
            WHERE r.LeadId = l.Id
              AND r.IsActive = 1
              AND ISNULL(r.IsApproved,0) = 0
        )
    )
    OR
    (
        @StepOrder <> 10
        AND lp.StepOrder = @StepOrder
    )
)

AND
(
    @StartDate IS NULL
    OR LTRIM(RTRIM(@StartDate)) = ''
    OR l.CreatedAt >= CONVERT(date, @StartDate)
)

AND
(
    @EndDate IS NULL
    OR LTRIM(RTRIM(@EndDate)) = ''
    OR l.CreatedAt < DATEADD(day, 1, CONVERT(date, @EndDate))
)

ORDER BY l.CreatedAt DESC;", new string[] { "RezerveDurumu", "LeadId", "IsReserved", "LeadNumarasi", "TalepTarihi", "ProductId", "ProductName", "Bilezik", "Brand", "Kadran", "RefCode", "Referans", "Musteri", "Lokasyon", "Ilce", "Ulke", "MusteriInfo", "AlisverisiVarMi", "IrtibatNumarasi", "EmailAdresi", "IletisimKaynagi", "CategoryName", "CategoryCode", "LeadDurumu", "SonrakiAdim", "ProcessName", "ProcessCode", "StepOrder", "SelectedStepOrder", "TerminTarihi", "SatisDanismani", "StoreName" }, prms_TM_GetLeads_0.ToArray());
            ;


            return Ok(result);
        }


        [HttpPost, Route("LeadListComponent_17950_onClick1_")]
        public IActionResult LeadListComponent_17950_onClick1_(LeadListComponent_17950_onClick1__Request request)
        {

            KProviderManager.Authorization.IsAuthorizedForRoles(appId, appName, screenId, screenName, new List<string> { $"70de6cfc-6087-6059-59b4-0b5a8527af6b", "4da1f213-c8e4-0b50-5c84-02fd13f1a622", "c4e882ef-977d-f613-7694-230ac83919d2", "b4bfd39c-ac02-f442-c899-7a2374a45b47", "cdb536b0-6297-155f-d446-8453d8a60304", "TimesYonetici", "TimesUstYonetici", "TimesSatisPersoneli", "TimesMagazaMuduru", "TimesAdmin" });

            var result = new LeadListComponent_17950_onClick1__Response();

            var prms_TM_GetLeads_0 = new List<kSqlParameter>();
            prms_TM_GetLeads_0.Add(new kSqlParameter() { Name = "StepOrder", Value = request.StepOrder_0 });
            prms_TM_GetLeads_0.Add(new kSqlParameter() { Name = "UserId", Value = Kuika.Common.KContext.CurrentUser?.Id });
            prms_TM_GetLeads_0.Add(new kSqlParameter() { Name = "MusteriAdi", Value = request.MusteriAdi_0 });
            prms_TM_GetLeads_0.Add(new kSqlParameter() { Name = "ProductName", Value = request.ProductName_0 });
            prms_TM_GetLeads_0.Add(new kSqlParameter() { Name = "LeadCode", Value = string.Empty });
            prms_TM_GetLeads_0.Add(new kSqlParameter() { Name = "Tel", Value = request.Tel_0 });
            prms_TM_GetLeads_0.Add(new kSqlParameter() { Name = "CategoryName", Value = request.CategoryName_0 });
            prms_TM_GetLeads_0.Add(new kSqlParameter() { Name = "StoreIds", Value = request.StoreIds_0 });
            prms_TM_GetLeads_0.Add(new kSqlParameter() { Name = "SatisDanismaniIds", Value = request.SatisDanismaniIds_0 });
            prms_TM_GetLeads_0.Add(new kSqlParameter() { Name = "ProcessCode", Value = request.ProcessCode_0 });
            prms_TM_GetLeads_0.Add(new kSqlParameter() { Name = "StartDate", Value = request.StartDate_0 });
            prms_TM_GetLeads_0.Add(new kSqlParameter() { Name = "EndDate", Value = request.EndDate_0 });
            using var auditTM_GetLeads_0 = ActionAuditScope.Begin("c7d930c6-1066-8451-e203-1d8155f571bb", "TM_GetLeads", applicationName: "wbTimesCRM", screenOrEndpointName: "LeadList");
            result.TM_GetLeads = KPersister.Fetch(KContext.GetConnectionString(), @"-- SET LANGUAGE Turkish;

-- SELECT
-- CASE 
--     WHEN EXISTS (
--         SELECT 1 
--         FROM tmscrq.TMLeadReservation r
--         WHERE r.LeadId = l.Id
--           AND r.IsActive = 1
--           AND r.IsApproved = 1
--     ) THEN N'Evet'

--     WHEN EXISTS (
--         SELECT 1 
--         FROM tmscrq.TMLeadReservation r
--         WHERE r.LeadId = l.Id
--           AND r.IsActive = 1
--           AND ISNULL(r.IsApproved,0) = 0
--     ) THEN N'Onay Bekliyor'

--     ELSE N'Hayır'
-- END AS RezerveDurumu,
--     l.Id AS LeadId,
--     l.IsReserved,
--     ISNULL(NULLIF(LTRIM(RTRIM(l.LeadCode)), ''), '-') AS LeadNumarasi,
--     CONVERT(varchar(10), l.CreatedAt, 103) AS TalepTarihi,

--     p.Id AS ProductId,
--     ISNULL(NULLIF(LTRIM(RTRIM(p.ProductName)), ''), '-') AS ProductName,
--     ISNULL(NULLIF(LTRIM(RTRIM(p.Bracelet)), ''), '-') AS Bilezik,
--     ISNULL(NULLIF(LTRIM(RTRIM(p.Brand)), ''), '-') AS Brand,
--     ISNULL(NULLIF(LTRIM(RTRIM(p.Dial)), ''), '-') AS Kadran,
--     ISNULL(NULLIF(LTRIM(RTRIM(p.ProductCode)), ''), '-') AS RefCode,
--     ISNULL(NULLIF(LTRIM(RTRIM(p.Referance)), ''), '-') AS Referans,

--     ISNULL(
--         NULLIF(
--             LTRIM(RTRIM(ISNULL(cu.Name, '') + ' ' + ISNULL(cu.LastName, '')))
--         , '')
--     , '-') AS Musteri,

--     ISNULL(NULLIF(LTRIM(RTRIM(cu.CityName)), ''), '-') AS Lokasyon,
--     ISNULL(NULLIF(LTRIM(RTRIM(cu.DistrictName)), ''), '-') AS Ilce,
--     ISNULL(NULLIF(LTRIM(RTRIM(cu.CountryName)), ''), '-') AS Ulke,
--     ISNULL(NULLIF(LTRIM(RTRIM(cu.Info)), ''), '-') AS MusteriInfo,

--     CASE
--         WHEN cu.IsShopping = 1 THEN N'Evet'
--         WHEN cu.IsShopping = 0 THEN N'Hayır'
--         ELSE '-'
--     END AS AlisverisiVarMi,

--     ISNULL(NULLIF(LTRIM(RTRIM(cu.Tel)), ''), '-') AS IrtibatNumarasi,
--     ISNULL(NULLIF(LTRIM(RTRIM(cu.Email)), ''), '-') AS EmailAdresi,

--     ISNULL(NULLIF(LTRIM(RTRIM(cr.ContactResourceName)), ''), '-') AS IletisimKaynagi,

--     ISNULL(NULLIF(LTRIM(RTRIM(p.CategoryName)), ''), '-') AS CategoryName,
--     '-' AS CategoryCode,

--     ISNULL(NULLIF(LTRIM(RTRIM(ls.Name)), ''), '-') AS LeadDurumu,
--     ISNULL(NULLIF(LTRIM(RTRIM(ns.Name)), ''), '-') AS SonrakiAdim,

--     ISNULL(NULLIF(LTRIM(RTRIM(lp.Name)), ''), '-') AS ProcessName,
--     ISNULL(NULLIF(LTRIM(RTRIM(lp.Code)), ''), '-') AS ProcessCode,
--     lp.StepOrder,
-- CASE
--     WHEN EXISTS
--     (
--         SELECT 1
--         FROM tmscrq.TMLeadReservation r
--         WHERE r.LeadId = l.Id
--           AND r.IsActive = 1
--           AND ISNULL(r.IsApproved,0) = 0
--     )
--     THEN 10
--     ELSE lp.StepOrder
-- END AS SelectedStepOrder,

--     ISNULL(
--         CASE
--             WHEN l.EstimatedDate IS NOT NULL
--             THEN CAST(YEAR(l.EstimatedDate) AS VARCHAR(4)) + ' ' + DATENAME(MONTH, l.EstimatedDate)
--             ELSE NULL
--         END,
--         '-'
--     ) AS TerminTarihi,

--     ISNULL(
--         NULLIF(
--             LTRIM(RTRIM(ISNULL(sp.FirstName, '') + ' ' + ISNULL(sp.LastName, '')))
--         , '')
--     , '-') AS SatisDanismani,

--     ISNULL(NULLIF(LTRIM(RTRIM(st.StoreDesc)), ''), '-') AS StoreName

-- FROM tmscrq.TMLead l
-- LEFT JOIN tmscrq.TMLeadStatu ls
--     ON ls.Id = l.StatuId
-- LEFT JOIN tmscrq.TMCustomer cu
--     ON cu.Id = l.CustomerId
-- LEFT JOIN tmscrq.TMProduct p
--     ON p.Id = l.ProductId
-- LEFT JOIN tmscrq.TMContactResource cr
--     ON cr.Id = l.ContactResourceId
-- LEFT JOIN dbo.KUser sp
--     ON sp.Id = l.SalesPersonKUserId
-- LEFT JOIN tmscrq.TMStore st
--     ON st.Id = l.StoreId
-- LEFT JOIN tmscrq.TMLeadProcess lp
--     ON lp.Id = l.ProcessID
-- LEFT JOIN tmscrq.TMLeadNextStep ns
--     ON ns.Id = l.NextStepId

-- WHERE
-- (
--     EXISTS
--     (
--         SELECT 1
--         FROM dbo.KUserRole ur
--         INNER JOIN dbo.KRole r
--             ON r.Id = ur.KRole_Id
--         WHERE ur.KUser_Id = @UserId
--           AND ur.IsDeleted = 0
--           AND r.IsDeleted = 0
--           AND r.Name IN ('TimesYonetici', 'TimesUstYonetici')
--     )
--     OR
--     (
--         EXISTS
--         (
--             SELECT 1
--             FROM dbo.KUserRole ur
--             INNER JOIN dbo.KRole r
--                 ON r.Id = ur.KRole_Id
--             WHERE ur.KUser_Id = @UserId
--               AND ur.IsDeleted = 0
--               AND r.IsDeleted = 0
--               AND r.Name IN ('TimesMagazaMuduru', 'TimesSatisPersoneli')
--         )
--         AND EXISTS
--         (
--             SELECT 1
--             FROM tmscrq.TMUser tu
--             WHERE tu.KUserID = @UserId
--               AND tu.StoreId = l.StoreId
--         )
--     )
-- )

-- AND
-- (
--     @MusteriAdi IS NULL
--     OR LTRIM(RTRIM(@MusteriAdi)) = ''
--     OR UPPER(LTRIM(RTRIM(ISNULL(cu.Name,'') + ' ' + ISNULL(cu.LastName,''))))
--        LIKE '%' + UPPER(LTRIM(RTRIM(@MusteriAdi))) + '%'
-- )

-- AND
-- (
--     @ProductName IS NULL
--     OR LTRIM(RTRIM(@ProductName)) = ''
--     OR
--     (
--         CHARINDEX(',', @ProductName) > 0
--         AND ISNULL(LTRIM(RTRIM(p.ProductName)), '') IN
--         (
--             SELECT LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', '')))
--             FROM STRING_SPLIT(CAST(@ProductName AS NVARCHAR(MAX)), ',')
--             WHERE LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', ''))) <> ''
--         )
--     )
--     OR
--     (
--         CHARINDEX(',', @ProductName) = 0
--         AND UPPER(ISNULL(LTRIM(RTRIM(p.ProductName)), ''))
--             LIKE '%' + UPPER(LTRIM(RTRIM(@ProductName))) + '%'
--     )
-- )

-- AND
-- (
--     @LeadCode IS NULL
--     OR LTRIM(RTRIM(@LeadCode)) = ''
--     OR UPPER(ISNULL(LTRIM(RTRIM(l.LeadCode)), '')) LIKE '%' + UPPER(LTRIM(RTRIM(@LeadCode))) + '%'
-- )

-- AND
-- (
--     @Tel IS NULL
--     OR LTRIM(RTRIM(@Tel)) = ''
--     OR UPPER(ISNULL(LTRIM(RTRIM(cu.Tel)), '')) LIKE '%' + UPPER(LTRIM(RTRIM(@Tel))) + '%'
-- )

-- -- AND
-- -- (
-- --     @CategoryName IS NULL
-- --     OR LTRIM(RTRIM(@CategoryName)) = ''
-- --     OR
-- --     (
-- --         EXISTS
-- --         (
-- --             SELECT 1
-- --             FROM STRING_SPLIT(CAST(@CategoryName AS NVARCHAR(MAX)), ',') c
-- --             WHERE UPPER(LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(c.value, '""', ''), '[', ''), ']', '')))) = 'DEFAULT'
-- --         )
-- --         AND (p.CategoryName IS NULL OR LTRIM(RTRIM(p.CategoryName)) = '')
-- --     )
-- --     OR UPPER(ISNULL(LTRIM(RTRIM(p.CategoryName)), '')) IN
-- --     (
-- --         SELECT UPPER(LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', ''))))
-- --         FROM STRING_SPLIT(CAST(@CategoryName AS NVARCHAR(MAX)), ',')
-- --         WHERE LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', ''))) <> ''
-- --           AND UPPER(LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', '')))) <> 'DEFAULT'
-- --     )
-- -- )

-- AND
-- (
--     @CategoryName IS NULL
--     OR LTRIM(RTRIM(@CategoryName)) = ''
--     OR UPPER(ISNULL(LTRIM(RTRIM(p.CategoryName)), '')) IN
--     (
--         SELECT UPPER(LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value,'""',''),'[',''),']',''))))
--         FROM STRING_SPLIT(CAST(@CategoryName AS NVARCHAR(MAX)), ',')
--         WHERE LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value,'""',''),'[',''),']',''))) <> ''
--     )
-- )

-- AND
-- (
--     @StoreIds IS NULL
--     OR LTRIM(RTRIM(@StoreIds)) = ''
--     OR EXISTS
--     (
--         SELECT 1
--         FROM STRING_SPLIT(CAST(@StoreIds AS NVARCHAR(MAX)), ',') s
--         WHERE l.StoreId = TRY_CONVERT
--         (
--             uniqueidentifier,
--             LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(s.value, '""', ''), '[', ''), ']', '')))
--         )
--     )
-- )

-- AND
-- (
--     @SatisDanismaniIds IS NULL
--     OR LTRIM(RTRIM(@SatisDanismaniIds)) = ''
--     OR EXISTS
--     (
--         SELECT 1
--         FROM STRING_SPLIT(CAST(@SatisDanismaniIds AS NVARCHAR(MAX)), ',') s
--         WHERE l.SalesPersonKUserId = TRY_CONVERT
--         (
--             uniqueidentifier,
--             LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(s.value, '""', ''), '[', ''), ']', '')))
--         )
--     )
-- )

-- AND
-- (
--     @ProcessCode IS NULL
--     OR LTRIM(RTRIM(@ProcessCode)) = ''
--     OR UPPER(ISNULL(LTRIM(RTRIM(lp.Code)), '')) IN
--     (
--         SELECT UPPER(LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', ''))))
--         FROM STRING_SPLIT(CAST(@ProcessCode AS NVARCHAR(MAX)), ',')
--         WHERE LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', ''))) <> ''
--     )
-- )

-- AND
-- (
--     @StepOrder IS NULL

--     OR
--     (
--         @StepOrder = 10
--         AND EXISTS
--         (
--             SELECT 1
--             FROM tmscrq.TMLeadReservation r
--             WHERE r.LeadId = l.Id
--               AND r.IsActive = 1
--               AND ISNULL(r.IsApproved,0) = 0
--         )
--     )

--     OR
--     (
--         @StepOrder <> 10
--         AND lp.StepOrder = @StepOrder
--     )
-- )

-- AND
-- (
--     @StartDate IS NULL
--     OR LTRIM(RTRIM(@StartDate)) = ''
--     OR l.CreatedAt >= CONVERT(date, @StartDate)
-- )

-- AND
-- (
--     @EndDate IS NULL
--     OR LTRIM(RTRIM(@EndDate)) = ''
--     OR l.CreatedAt < DATEADD(day, 1, CONVERT(date, @EndDate))
-- )

-- ORDER BY l.CreatedAt DESC;

------------------------++++++++++++++++++++++++-------------------
-- SET LANGUAGE Turkish;

-- SELECT
-- CASE 
--     WHEN EXISTS (
--         SELECT 1 
--         FROM tmscrq.TMLeadReservation r
--         WHERE r.LeadId = l.Id
--           AND r.IsActive = 1
--           AND r.IsApproved = 1
--     ) THEN N'Evet'

--     WHEN EXISTS (
--         SELECT 1 
--         FROM tmscrq.TMLeadReservation r
--         WHERE r.LeadId = l.Id
--           AND r.IsActive = 1
--           AND ISNULL(r.IsApproved,0) = 0
--     ) THEN N'Onay Bekliyor'

--     ELSE N'Hayır'
-- END AS RezerveDurumu,
--     l.Id AS LeadId,
--     l.IsReserved,
--     ISNULL(NULLIF(LTRIM(RTRIM(l.LeadCode)), ''), '-') AS LeadNumarasi,
--     CONVERT(varchar(10), l.CreatedAt, 103) AS TalepTarihi,

--     p.Id AS ProductId,
--     ISNULL(NULLIF(LTRIM(RTRIM(p.ProductName)), ''), '-') AS ProductName,
--     ISNULL(NULLIF(LTRIM(RTRIM(p.Bracelet)), ''), '-') AS Bilezik,
--     ISNULL(NULLIF(LTRIM(RTRIM(p.Brand)), ''), '-') AS Brand,
--     ISNULL(NULLIF(LTRIM(RTRIM(p.Dial)), ''), '-') AS Kadran,
--     ISNULL(NULLIF(LTRIM(RTRIM(p.ProductCode)), ''), '-') AS RefCode,
--     ISNULL(NULLIF(LTRIM(RTRIM(p.Referance)), ''), '-') AS Referans,

--     ISNULL(
--         NULLIF(
--             LTRIM(RTRIM(ISNULL(cu.Name, '') + ' ' + ISNULL(cu.LastName, '')))
--         , '')
--     , '-') AS Musteri,

--     ISNULL(NULLIF(LTRIM(RTRIM(cu.CityName)), ''), '-') AS Lokasyon,
--     ISNULL(NULLIF(LTRIM(RTRIM(cu.DistrictName)), ''), '-') AS Ilce,
--     ISNULL(NULLIF(LTRIM(RTRIM(cu.CountryName)), ''), '-') AS Ulke,
--     ISNULL(NULLIF(LTRIM(RTRIM(cu.Info)), ''), '-') AS MusteriInfo,

--     CASE
--         WHEN cu.IsShopping = 1 THEN N'Evet'
--         WHEN cu.IsShopping = 0 THEN N'Hayır'
--         ELSE '-'
--     END AS AlisverisiVarMi,

--     ISNULL(NULLIF(LTRIM(RTRIM(cu.Tel)), ''), '-') AS IrtibatNumarasi,
--     ISNULL(NULLIF(LTRIM(RTRIM(cu.Email)), ''), '-') AS EmailAdresi,

--     ISNULL(NULLIF(LTRIM(RTRIM(cr.ContactResourceName)), ''), '-') AS IletisimKaynagi,

--     ISNULL(NULLIF(LTRIM(RTRIM(p.CategoryName)), ''), '-') AS CategoryName,
--     '-' AS CategoryCode,

--     ISNULL(NULLIF(LTRIM(RTRIM(ls.Name)), ''), '-') AS LeadDurumu,
--     ISNULL(NULLIF(LTRIM(RTRIM(ns.Name)), ''), '-') AS SonrakiAdim,

--     ISNULL(NULLIF(LTRIM(RTRIM(lp.Name)), ''), '-') AS ProcessName,
--     ISNULL(NULLIF(LTRIM(RTRIM(lp.Code)), ''), '-') AS ProcessCode,
--     lp.StepOrder,
    
--     -- DÜZELTİLEN ALAN: SelectedStepOrder
--     CASE
--         WHEN EXISTS
--         (
--             SELECT 1
--             FROM tmscrq.TMLeadReservation r
--             WHERE r.LeadId = l.Id
--               AND r.IsActive = 1
--               AND ISNULL(r.IsApproved,0) = 0
--         )
--         THEN 10
--         ELSE lp.StepOrder
--     END AS SelectedStepOrder,

--     ISNULL(
--         CASE
--             WHEN l.EstimatedDate IS NOT NULL
--             THEN CAST(YEAR(l.EstimatedDate) AS VARCHAR(4)) + ' ' + DATENAME(MONTH, l.EstimatedDate)
--             ELSE NULL
--         END,
--         '-'
--     ) AS TerminTarihi,

--     ISNULL(
--         NULLIF(
--             LTRIM(RTRIM(ISNULL(sp.FirstName, '') + ' ' + ISNULL(sp.LastName, '')))
--         , '')
--     , '-') AS SatisDanismani,

--     ISNULL(NULLIF(LTRIM(RTRIM(st.StoreDesc)), ''), '-') AS StoreName

-- FROM tmscrq.TMLead l
-- LEFT JOIN tmscrq.TMLeadStatu ls
--     ON ls.Id = l.StatuId
-- LEFT JOIN tmscrq.TMCustomer cu
--     ON cu.Id = l.CustomerId
-- LEFT JOIN tmscrq.TMProduct p
--     ON p.Id = l.ProductId
-- LEFT JOIN tmscrq.TMContactResource cr
--     ON cr.Id = l.ContactResourceId
-- LEFT JOIN dbo.KUser sp
--     ON sp.Id = l.SalesPersonKUserId
-- LEFT JOIN tmscrq.TMStore st
--     ON st.Id = l.StoreId
-- LEFT JOIN tmscrq.TMLeadProcess lp
--     ON lp.Id = l.ProcessID
-- LEFT JOIN tmscrq.TMLeadNextStep ns
--     ON ns.Id = l.NextStepId

-- WHERE
-- (
--     EXISTS
--     (
--         SELECT 1
--         FROM dbo.KUserRole ur
--         INNER JOIN dbo.KRole r
--             ON r.Id = ur.KRole_Id
--         WHERE ur.KUser_Id = @UserId
--           AND ur.IsDeleted = 0
--           AND r.IsDeleted = 0
--           AND r.Name IN ('TimesYonetici', 'TimesUstYonetici')
--     )
--     OR
--     (
--         EXISTS
--         (
--             SELECT 1
--             FROM dbo.KUserRole ur
--             INNER JOIN dbo.KRole r
--                 ON r.Id = ur.KRole_Id
--             WHERE ur.KUser_Id = @UserId
--               AND ur.IsDeleted = 0
--               AND r.IsDeleted = 0
--               AND r.Name IN ('TimesMagazaMuduru', 'TimesSatisPersoneli')
--         )
--         AND EXISTS
--         (
--             SELECT 1
--             FROM tmscrq.TMUser tu
--             WHERE tu.KUserID = @UserId
--               AND tu.StoreId = l.StoreId
--         )
--     )
-- )

-- AND
-- (
--     @MusteriAdi IS NULL
--     OR LTRIM(RTRIM(@MusteriAdi)) = ''
--     OR UPPER(LTRIM(RTRIM(ISNULL(cu.Name,'') + ' ' + ISNULL(cu.LastName,''))))
--        LIKE '%' + UPPER(LTRIM(RTRIM(@MusteriAdi))) + '%'
-- )

-- AND
-- (
--     @ProductName IS NULL
--     OR LTRIM(RTRIM(@ProductName)) = ''
--     OR
--     (
--         CHARINDEX(',', @ProductName) > 0
--         AND ISNULL(LTRIM(RTRIM(p.ProductName)), '') IN
--         (
--             SELECT LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', '')))
--             FROM STRING_SPLIT(CAST(@ProductName AS NVARCHAR(MAX)), ',')
--             WHERE LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', ''))) <> ''
--         )
--     )
--     OR
--     (
--         CHARINDEX(',', @ProductName) = 0
--         AND UPPER(ISNULL(LTRIM(RTRIM(p.ProductName)), ''))
--             LIKE '%' + UPPER(LTRIM(RTRIM(@ProductName))) + '%'
--     )
-- )

-- AND
-- (
--     @LeadCode IS NULL
--     OR LTRIM(RTRIM(@LeadCode)) = ''
--     OR UPPER(ISNULL(LTRIM(RTRIM(l.LeadCode)), '')) LIKE '%' + UPPER(LTRIM(RTRIM(@LeadCode))) + '%'
-- )

-- AND
-- (
--     @Tel IS NULL
--     OR LTRIM(RTRIM(@Tel)) = ''
--     OR UPPER(ISNULL(LTRIM(RTRIM(cu.Tel)), '')) LIKE '%' + UPPER(LTRIM(RTRIM(@Tel))) + '%'
-- )

-- AND
-- (
--     @CategoryName IS NULL
--     OR LTRIM(RTRIM(@CategoryName)) = ''
--     OR UPPER(ISNULL(LTRIM(RTRIM(p.CategoryName)), '')) IN
--     (
--         SELECT UPPER(LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value,'""',''),'[',''),']',''))))
--         FROM STRING_SPLIT(CAST(@CategoryName AS NVARCHAR(MAX)), ',')
--         WHERE LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value,'""',''),'[',''),']',''))) <> ''
--     )
-- )

-- AND
-- (
--     @StoreIds IS NULL
--     OR LTRIM(RTRIM(@StoreIds)) = ''
--     OR EXISTS
--     (
--         SELECT 1
--         FROM STRING_SPLIT(CAST(@StoreIds AS NVARCHAR(MAX)), ',') s
--         WHERE l.StoreId = TRY_CONVERT
--         (
--             uniqueidentifier,
--             LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(s.value, '""', ''), '[', ''), ']', '')))
--         )
--     )
-- )

-- AND
-- (
--     @SatisDanismaniIds IS NULL
--     OR LTRIM(RTRIM(@SatisDanismaniIds)) = ''
--     OR EXISTS
--     (
--         SELECT 1
--         FROM STRING_SPLIT(CAST(@SatisDanismaniIds AS NVARCHAR(MAX)), ',') s
--         WHERE l.SalesPersonKUserId = TRY_CONVERT
--         (
--             uniqueidentifier,
--             LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(s.value, '""', ''), '[', ''), ']', '')))
--         )
--     )
-- )

-- AND
-- (
--     @ProcessCode IS NULL
--     OR LTRIM(RTRIM(@ProcessCode)) = ''
--     OR UPPER(ISNULL(LTRIM(RTRIM(lp.Code)), '')) IN
--     (
--         SELECT UPPER(LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', ''))))
--         FROM STRING_SPLIT(CAST(@ProcessCode AS NVARCHAR(MAX)), ',')
--         WHERE LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', ''))) <> ''
--     )
-- )

-- -- DÜZELTİLEN ALAN: @StepOrder Filtresi (tek blok)
-- AND
-- (
--     @StepOrder IS NULL

--     OR

--     (
--         @StepOrder = 10
--         AND EXISTS
--         (
--             SELECT 1
--             FROM tmscrq.TMLeadReservation r
--             WHERE r.LeadId = l.Id
--               AND r.IsActive = 1
--               AND ISNULL(r.IsApproved,0) = 0
--         )
--     )

--     OR

--     (
--         @StepOrder <> 10
--         AND lp.StepOrder = @StepOrder
--     )
-- )

-- AND
-- (
--     @StartDate IS NULL
--     OR LTRIM(RTRIM(@StartDate)) = ''
--     OR l.CreatedAt >= CONVERT(date, @StartDate)
-- )

-- AND
-- (
--     @EndDate IS NULL
--     OR LTRIM(RTRIM(@EndDate)) = ''
--     OR l.CreatedAt < DATEADD(day, 1, CONVERT(date, @EndDate))
-- )

-- ORDER BY l.CreatedAt DESC;



SET LANGUAGE Turkish;

SELECT
CASE 
    WHEN EXISTS (
        SELECT 1 
        FROM tmscrq.TMLeadReservation r
        WHERE r.LeadId = l.Id
          AND r.IsActive = 1
          AND r.IsApproved = 1
    ) THEN N'Evet'

    WHEN EXISTS (
        SELECT 1 
        FROM tmscrq.TMLeadReservation r
        WHERE r.LeadId = l.Id
          AND r.IsActive = 1
          AND ISNULL(r.IsApproved,0) = 0
    ) THEN N'Onay Bekliyor'

    ELSE N'Hayır'
END AS RezerveDurumu,
    l.Id AS LeadId,
    l.IsReserved,
    ISNULL(NULLIF(LTRIM(RTRIM(l.LeadCode)), ''), '-') AS LeadNumarasi,
     FORMAT(l.CreatedAt, 'dd MMMM yyyy', 'tr-TR') AS TalepTarihi,

    p.Id AS ProductId,
    ISNULL(NULLIF(LTRIM(RTRIM(p.ProductName)), ''), '-') AS ProductName,
    ISNULL(NULLIF(LTRIM(RTRIM(p.Bracelet)), ''), '-') AS Bilezik,
    ISNULL(NULLIF(LTRIM(RTRIM(p.Brand)), ''), '-') AS Brand,
    ISNULL(NULLIF(LTRIM(RTRIM(p.Dial)), ''), '-') AS Kadran,
    ISNULL(NULLIF(LTRIM(RTRIM(p.ProductCode)), ''), '-') AS RefCode,
    ISNULL(NULLIF(LTRIM(RTRIM(p.Referance)), ''), '-') AS Referans,

    ISNULL(
        NULLIF(
            LTRIM(RTRIM(ISNULL(cu.Name, '') + ' ' + ISNULL(cu.LastName, '')))
        , '')
    , '-') AS Musteri,

    ISNULL(NULLIF(LTRIM(RTRIM(cu.CityName)), ''), '-') AS Lokasyon,
    ISNULL(NULLIF(LTRIM(RTRIM(cu.DistrictName)), ''), '-') AS Ilce,
    ISNULL(NULLIF(LTRIM(RTRIM(cu.CountryName)), ''), '-') AS Ulke,
    ISNULL(NULLIF(LTRIM(RTRIM(cu.Info)), ''), '-') AS MusteriInfo,

    CASE
        WHEN cu.IsShopping = 1 THEN N'Evet'
        WHEN cu.IsShopping = 0 THEN N'Hayır'
        ELSE '-'
    END AS AlisverisiVarMi,

    ISNULL(NULLIF(LTRIM(RTRIM(cu.Tel)), ''), '-') AS IrtibatNumarasi,
    ISNULL(NULLIF(LTRIM(RTRIM(cu.Email)), ''), '-') AS EmailAdresi,

    ISNULL(NULLIF(LTRIM(RTRIM(cr.ContactResourceName)), ''), '-') AS IletisimKaynagi,

    ISNULL(NULLIF(LTRIM(RTRIM(p.CategoryName)), ''), '-') AS CategoryName,
    '-' AS CategoryCode,

    ISNULL(NULLIF(LTRIM(RTRIM(ls.Name)), ''), '-') AS LeadDurumu,
    ISNULL(NULLIF(LTRIM(RTRIM(ns.Name)), ''), '-') AS SonrakiAdim,

    ISNULL(NULLIF(LTRIM(RTRIM(lp.Name)), ''), '-') AS ProcessName,
    ISNULL(NULLIF(LTRIM(RTRIM(lp.Code)), ''), '-') AS ProcessCode,
    lp.StepOrder,
    
    -- DÜZELTİLEN ALAN: SelectedStepOrder
    CASE
        WHEN EXISTS
        (
            SELECT 1
            FROM tmscrq.TMLeadReservation r
            WHERE r.LeadId = l.Id
              AND r.IsActive = 1
              AND ISNULL(r.IsApproved,0) = 0
        )
        THEN 10
        ELSE lp.StepOrder
    END AS SelectedStepOrder,

    ISNULL(
        CASE
            WHEN l.EstimatedDate IS NOT NULL
            THEN CAST(YEAR(l.EstimatedDate) AS VARCHAR(4)) + ' ' + DATENAME(MONTH, l.EstimatedDate)
            ELSE NULL
        END,
        '-'
    ) AS TerminTarihi,

    ISNULL(
        NULLIF(
            LTRIM(RTRIM(ISNULL(sp.FirstName, '') + ' ' + ISNULL(sp.LastName, '')))
        , '')
    , '-') AS SatisDanismani,

    ISNULL(NULLIF(LTRIM(RTRIM(st.StoreDesc)), ''), '-') AS StoreName

FROM tmscrq.TMLead l
LEFT JOIN tmscrq.TMLeadStatu ls
    ON ls.Id = l.StatuId
LEFT JOIN tmscrq.TMCustomer cu
    ON cu.Id = l.CustomerId
LEFT JOIN tmscrq.TMProduct p
    ON p.Id = l.ProductId
LEFT JOIN tmscrq.TMContactResource cr
    ON cr.Id = l.ContactResourceId
LEFT JOIN dbo.KUser sp
    ON sp.Id = l.SalesPersonKUserId
LEFT JOIN tmscrq.TMStore st
    ON st.Id = l.StoreId
LEFT JOIN tmscrq.TMLeadProcess lp
    ON lp.Id = l.ProcessID
LEFT JOIN tmscrq.TMLeadNextStep ns
    ON ns.Id = l.NextStepId

WHERE
(
    EXISTS
    (
        SELECT 1
        FROM dbo.KUserRole ur
        INNER JOIN dbo.KRole r
            ON r.Id = ur.KRole_Id
        WHERE ur.KUser_Id = @UserId
          AND ur.IsDeleted = 0
          AND r.IsDeleted = 0
          AND r.Name IN ('TimesYonetici', 'TimesUstYonetici')
    )
    OR
    (
        EXISTS
        (
            SELECT 1
            FROM dbo.KUserRole ur
            INNER JOIN dbo.KRole r
                ON r.Id = ur.KRole_Id
            WHERE ur.KUser_Id = @UserId
              AND ur.IsDeleted = 0
              AND r.IsDeleted = 0
              AND r.Name IN ('TimesMagazaMuduru', 'TimesSatisPersoneli')
        )
        AND EXISTS
        (
            SELECT 1
            FROM tmscrq.TMUser tu
            WHERE tu.KUserID = @UserId
              AND tu.StoreId = l.StoreId
        )
    )
)

AND
(
    ISNULL(@MusteriAdi, '') = ''
    OR UPPER(ISNULL(cu.Name, '')) LIKE '%' + UPPER(LTRIM(RTRIM(@MusteriAdi))) + '%'
    OR UPPER(ISNULL(cu.LastName, '')) LIKE '%' + UPPER(LTRIM(RTRIM(@MusteriAdi))) + '%'
    OR UPPER(
        ISNULL(cu.Name, '') + ' ' + ISNULL(cu.LastName, '')
    ) LIKE '%' + UPPER(LTRIM(RTRIM(@MusteriAdi))) + '%'
)

AND
(
    @ProductName IS NULL
    OR LTRIM(RTRIM(@ProductName)) = ''
    OR
    (
        CHARINDEX(',', @ProductName) > 0
        AND ISNULL(LTRIM(RTRIM(p.ProductName)), '') IN
        (
            SELECT LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', '')))
            FROM STRING_SPLIT(CAST(@ProductName AS NVARCHAR(MAX)), ',')
            WHERE LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', ''))) <> ''
        )
    )
    OR
    (
        CHARINDEX(',', @ProductName) = 0
        AND UPPER(ISNULL(LTRIM(RTRIM(p.ProductName)), ''))
            LIKE '%' + UPPER(LTRIM(RTRIM(@ProductName))) + '%'
    )
)

AND
(
    ISNULL(@LeadCode, '') = ''
    OR UPPER(ISNULL(l.LeadCode, ''))
        LIKE '%' + UPPER(LTRIM(RTRIM(@LeadCode))) + '%'
    OR REPLACE(
        REPLACE(
            REPLACE(
                UPPER(ISNULL(l.LeadCode, '')),
                '-', ''
            ),
            ' ', ''
        ),
        '/', ''
    )
    LIKE '%' +
    REPLACE(
        REPLACE(
            REPLACE(
                UPPER(LTRIM(RTRIM(@LeadCode))),
                '-', ''
            ),
            ' ', ''
        ),
        '/', ''
    )
    + '%'
)

AND
(
    @Tel IS NULL
    OR LTRIM(RTRIM(@Tel)) = ''
    OR UPPER(ISNULL(LTRIM(RTRIM(cu.Tel)), '')) LIKE '%' + UPPER(LTRIM(RTRIM(@Tel))) + '%'
)

AND
(
    @CategoryName IS NULL
    OR LTRIM(RTRIM(@CategoryName)) = ''
    OR UPPER(ISNULL(LTRIM(RTRIM(p.CategoryName)), '')) IN
    (
        SELECT UPPER(LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value,'""',''),'[',''),']',''))))
        FROM STRING_SPLIT(CAST(@CategoryName AS NVARCHAR(MAX)), ',')
        WHERE LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value,'""',''),'[',''),']',''))) <> ''
    )
)

AND
(
    @StoreIds IS NULL
    OR LTRIM(RTRIM(@StoreIds)) = ''
    OR EXISTS
    (
        SELECT 1
        FROM STRING_SPLIT(CAST(@StoreIds AS NVARCHAR(MAX)), ',') s
        WHERE l.StoreId = TRY_CONVERT
        (
            uniqueidentifier,
            LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(s.value, '""', ''), '[', ''), ']', '')))
        )
    )
)

AND
(
    @SatisDanismaniIds IS NULL
    OR LTRIM(RTRIM(@SatisDanismaniIds)) = ''
    OR EXISTS
    (
        SELECT 1
        FROM STRING_SPLIT(CAST(@SatisDanismaniIds AS NVARCHAR(MAX)), ',') s
        WHERE l.SalesPersonKUserId = TRY_CONVERT
        (
            uniqueidentifier,
            LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(s.value, '""', ''), '[', ''), ']', '')))
        )
    )
)

AND
(
    ISNULL(@ProcessCode, '') = ''
    OR EXISTS
    (
        SELECT 1
        FROM STRING_SPLIT(
            CONVERT(NVARCHAR(MAX), @ProcessCode),
            ','
        ) AS s
        WHERE
            UPPER(LTRIM(RTRIM(s.value))) =
            UPPER(LTRIM(RTRIM(ISNULL(lp.Code, ''))))
    )
)

-- DÜZELTİLEN ALAN: @StepOrder Filtresi (0 verilince tümü gelsin)
AND
(
    @StepOrder IS NULL
    OR @StepOrder = 0  -- 👈 YENİ EKLENDI: 0 verilince tüm kayıtlar gelir
    OR
    (
        @StepOrder = 10
        AND EXISTS
        (
            SELECT 1
            FROM tmscrq.TMLeadReservation r
            WHERE r.LeadId = l.Id
              AND r.IsActive = 1
              AND ISNULL(r.IsApproved,0) = 0
        )
    )
    OR
    (
        @StepOrder <> 10
        AND lp.StepOrder = @StepOrder
    )
)

AND
(
    @StartDate IS NULL
    OR LTRIM(RTRIM(@StartDate)) = ''
    OR l.CreatedAt >= CONVERT(date, @StartDate)
)

AND
(
    @EndDate IS NULL
    OR LTRIM(RTRIM(@EndDate)) = ''
    OR l.CreatedAt < DATEADD(day, 1, CONVERT(date, @EndDate))
)

ORDER BY l.CreatedAt DESC;", new string[] { "RezerveDurumu", "LeadId", "IsReserved", "LeadNumarasi", "TalepTarihi", "ProductId", "ProductName", "Bilezik", "Brand", "Kadran", "RefCode", "Referans", "Musteri", "Lokasyon", "Ilce", "Ulke", "MusteriInfo", "AlisverisiVarMi", "IrtibatNumarasi", "EmailAdresi", "IletisimKaynagi", "CategoryName", "CategoryCode", "LeadDurumu", "SonrakiAdim", "ProcessName", "ProcessCode", "StepOrder", "SelectedStepOrder", "TerminTarihi", "SatisDanismani", "StoreName" }, prms_TM_GetLeads_0.ToArray());
            ;


            return Ok(result);
        }


        [HttpPost, Route("LeadListComponent_378811_onClick")]
        public IActionResult LeadListComponent_378811_onClick(LeadListComponent_378811_onClick_Request request)
        {

            KProviderManager.Authorization.IsAuthorizedForRoles(appId, appName, screenId, screenName, new List<string> { $"70de6cfc-6087-6059-59b4-0b5a8527af6b", "4da1f213-c8e4-0b50-5c84-02fd13f1a622", "c4e882ef-977d-f613-7694-230ac83919d2", "b4bfd39c-ac02-f442-c899-7a2374a45b47", "cdb536b0-6297-155f-d446-8453d8a60304", "TimesYonetici", "TimesUstYonetici", "TimesSatisPersoneli", "TimesMagazaMuduru", "TimesAdmin" });

            var result = new LeadListComponent_378811_onClick_Response();


            using var auditExportExcel_0 = ActionAuditScope.Begin("21e3829b-9297-9b06-7518-ab9dc8d16741", "ExportExcel", applicationName: "wbTimesCRM", screenOrEndpointName: "LeadList");
            using var actionAuditExportExcel_0 = ActionAuditHelper.Begin("ExportExcel", new { value = request.value_0.ConvertToType<Object>(), header = "".ConvertToType<String>(), footer = "".ConvertToType<String>(), columns = "TalepTarihi,Referans,Kadran,Bilezik,Musteri,MusteriInfo,Lokasyon,IletisimKaynagi,LeadDurumu,SonrakiAdim,IrtibatNumarasi,EmailAdresi,ProcessName,SatisDanismani,AlisverisiVarMi,TerminTarihi".ConvertToType<String>() });
            try
            {
                result.ExportExcel = Kuika.Common.Helpers.CsSystemFunctions.ExportExcel(request.value_0.ConvertToType<Object>(), "".ConvertToType<String>(), "".ConvertToType<String>(), "TalepTarihi,Referans,Kadran,Bilezik,Musteri,MusteriInfo,Lokasyon,IletisimKaynagi,LeadDurumu,SonrakiAdim,IrtibatNumarasi,EmailAdresi,ProcessName,SatisDanismani,AlisverisiVarMi,TerminTarihi".ConvertToType<String>());
                actionAuditExportExcel_0.SetResult(result.ExportExcel);
            }
            catch (Exception ex)
            {
                actionAuditExportExcel_0.SetException(ex);
                throw;
            }
;


            return Ok(result);
        }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class LeadListPageInit_Request
    {
        public Int32? StepOrder_0 { set; get; }
        public Guid? UserId_0 { set; get; }
        public String MusteriAdi_0 { set; get; }
        public String ProductName_0 { set; get; }
        public String LeadCode_0 { set; get; }
        public String Tel_0 { set; get; }
        public String CategoryName_0 { set; get; }
        public String StoreIds_0 { set; get; }
        public String SatisDanismaniIds_0 { set; get; }
        public String ProcessCode_0 { set; get; }
        public DateTime? StartDate_0 { set; get; }
        public DateTime? EndDate_0 { set; get; }
        public Guid? UserId_1 { set; get; }
        public String MusteriAdi_1 { set; get; }
        public String ProductName_1 { set; get; }
        public String LeadCode_1 { set; get; }
        public String Tel_1 { set; get; }
        public String CategoryName_1 { set; get; }
        public String StoreIds_1 { set; get; }
        public String SatisDanismaniIds_1 { set; get; }
        public String ProcessCode_1 { set; get; }
        public DateTime? StartDate_1 { set; get; }
        public DateTime? EndDate_1 { set; get; }
        public Guid? KUserId_5 { set; get; }
        public Guid? KUserId_6 { set; get; }
        public Guid? StoreId_6 { set; get; }
        public Int32? StepOrder_8 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class LeadListPageInit_Response
    {
        public KCommonEntityPage TM_GetLeads { set; get; }

        public KCommonEntityPage TMLeadProcessCountSummary { set; get; }

        public KCommonEntityPage TM_GetProductCategory { set; get; }

        public KCommonEntityPage TM_GetProductReferanceFilter { set; get; }

        public KCommonEntityPage TM_GetCustomerByName { set; get; }

        public KCommonEntityPage TM_GetStore { set; get; }

        public KCommonEntityPage TM_GetSalesPerson { set; get; }

        public KCommonEntityPage TM_GetLeadStatus { set; get; }

        public KCommonEntityPage TM_GetLeadProcess { set; get; }

        public KCommonEntityPage TMGetProductAllLeadsMultiSelect { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class LeadListComponent_361899_onClick_Request
    {
        public Int32? StepOrder_0 { set; get; }
        public Guid? UserId_0 { set; get; }
        public String MusteriAdi_0 { set; get; }
        public String ProductName_0 { set; get; }
        public String LeadCode_0 { set; get; }
        public String Tel_0 { set; get; }
        public String CategoryName_0 { set; get; }
        public String StoreIds_0 { set; get; }
        public String SatisDanismaniIds_0 { set; get; }
        public String ProcessCode_0 { set; get; }
        public DateTime? StartDate_0 { set; get; }
        public DateTime? EndDate_0 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class LeadListComponent_361899_onClick_Response
    {
        public KCommonEntityPage TM_GetLeads { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class LeadListComponent_470282_onClick_Request
    {
        public Int32? StepOrder_0 { set; get; }
        public Guid? UserId_0 { set; get; }
        public String MusteriAdi_0 { set; get; }
        public String ProductName_0 { set; get; }
        public String LeadCode_0 { set; get; }
        public String Tel_0 { set; get; }
        public String CategoryName_0 { set; get; }
        public String StoreIds_0 { set; get; }
        public String SatisDanismaniIds_0 { set; get; }
        public String ProcessCode_0 { set; get; }
        public DateTime? StartDate_0 { set; get; }
        public DateTime? EndDate_0 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class LeadListComponent_470282_onClick_Response
    {
        public KCommonEntityPage TM_GetLeads { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class LeadListComponent_576136_onClick_Request
    {
        public Int32? StepOrder_0 { set; get; }
        public Guid? UserId_0 { set; get; }
        public String MusteriAdi_0 { set; get; }
        public String ProductName_0 { set; get; }
        public String LeadCode_0 { set; get; }
        public String Tel_0 { set; get; }
        public String CategoryName_0 { set; get; }
        public String StoreIds_0 { set; get; }
        public String SatisDanismaniIds_0 { set; get; }
        public String ProcessCode_0 { set; get; }
        public DateTime? StartDate_0 { set; get; }
        public DateTime? EndDate_0 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class LeadListComponent_576136_onClick_Response
    {
        public KCommonEntityPage TM_GetLeads { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class LeadListComponent_399191_onClick_Request
    {
        public Int32? StepOrder_0 { set; get; }
        public Guid? UserId_0 { set; get; }
        public String MusteriAdi_0 { set; get; }
        public String ProductName_0 { set; get; }
        public String LeadCode_0 { set; get; }
        public String Tel_0 { set; get; }
        public String CategoryName_0 { set; get; }
        public String StoreIds_0 { set; get; }
        public String SatisDanismaniIds_0 { set; get; }
        public String ProcessCode_0 { set; get; }
        public DateTime? StartDate_0 { set; get; }
        public DateTime? EndDate_0 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class LeadListComponent_399191_onClick_Response
    {
        public KCommonEntityPage TM_GetLeads { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class LeadListComponent_398408_onClick_Request
    {
        public Int32? StepOrder_0 { set; get; }
        public Guid? UserId_0 { set; get; }
        public String MusteriAdi_0 { set; get; }
        public String ProductName_0 { set; get; }
        public String LeadCode_0 { set; get; }
        public String Tel_0 { set; get; }
        public String CategoryName_0 { set; get; }
        public String StoreIds_0 { set; get; }
        public String SatisDanismaniIds_0 { set; get; }
        public String ProcessCode_0 { set; get; }
        public DateTime? StartDate_0 { set; get; }
        public DateTime? EndDate_0 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class LeadListComponent_398408_onClick_Response
    {
        public KCommonEntityPage TM_GetLeads { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class LeadListComponent_416933_onClick_Request
    {
        public Int32? StepOrder_0 { set; get; }
        public Guid? UserId_0 { set; get; }
        public String MusteriAdi_0 { set; get; }
        public String ProductName_0 { set; get; }
        public String LeadCode_0 { set; get; }
        public String Tel_0 { set; get; }
        public String CategoryName_0 { set; get; }
        public String StoreIds_0 { set; get; }
        public String SatisDanismaniIds_0 { set; get; }
        public String ProcessCode_0 { set; get; }
        public DateTime? StartDate_0 { set; get; }
        public DateTime? EndDate_0 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class LeadListComponent_416933_onClick_Response
    {
        public KCommonEntityPage TM_GetLeads { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class LeadListComponent_634059_onClick_Request
    {
        public Int32? StepOrder_0 { set; get; }
        public Guid? UserId_0 { set; get; }
        public String MusteriAdi_0 { set; get; }
        public String ProductName_0 { set; get; }
        public String LeadCode_0 { set; get; }
        public String Tel_0 { set; get; }
        public String CategoryName_0 { set; get; }
        public String StoreIds_0 { set; get; }
        public String SatisDanismaniIds_0 { set; get; }
        public String ProcessCode_0 { set; get; }
        public DateTime? StartDate_0 { set; get; }
        public DateTime? EndDate_0 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class LeadListComponent_634059_onClick_Response
    {
        public KCommonEntityPage TM_GetLeads { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class LeadListComponent_288211_onChange_Request
    {
        public Int32? StepOrder_0 { set; get; }
        public Guid? UserId_0 { set; get; }
        public String MusteriAdi_0 { set; get; }
        public String ProductName_0 { set; get; }
        public String LeadCode_0 { set; get; }
        public String Tel_0 { set; get; }
        public String CategoryName_0 { set; get; }
        public String StoreIds_0 { set; get; }
        public String SatisDanismaniIds_0 { set; get; }
        public String ProcessCode_0 { set; get; }
        public DateTime? StartDate_0 { set; get; }
        public DateTime? EndDate_0 { set; get; }
        public Guid? UserId_1 { set; get; }
        public String MusteriAdi_1 { set; get; }
        public String ProductName_1 { set; get; }
        public String LeadCode_1 { set; get; }
        public String Tel_1 { set; get; }
        public String CategoryName_1 { set; get; }
        public String StoreIds_1 { set; get; }
        public String SatisDanismaniIds_1 { set; get; }
        public String ProcessCode_1 { set; get; }
        public DateTime? StartDate_1 { set; get; }
        public DateTime? EndDate_1 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class LeadListComponent_288211_onChange_Response
    {
        public KCommonEntityPage TM_GetLeads { set; get; }

        public KCommonEntityPage TMLeadProcessCountSummary { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class LeadListComponent_776113_onChange_Request
    {
        public Int32? StepOrder_0 { set; get; }
        public Guid? UserId_0 { set; get; }
        public String MusteriAdi_0 { set; get; }
        public String ProductName_0 { set; get; }
        public String LeadCode_0 { set; get; }
        public String Tel_0 { set; get; }
        public String CategoryName_0 { set; get; }
        public String StoreIds_0 { set; get; }
        public String SatisDanismaniIds_0 { set; get; }
        public String ProcessCode_0 { set; get; }
        public DateTime? StartDate_0 { set; get; }
        public DateTime? EndDate_0 { set; get; }
        public Guid? UserId_1 { set; get; }
        public String MusteriAdi_1 { set; get; }
        public String ProductName_1 { set; get; }
        public String LeadCode_1 { set; get; }
        public String Tel_1 { set; get; }
        public String CategoryName_1 { set; get; }
        public String StoreIds_1 { set; get; }
        public String SatisDanismaniIds_1 { set; get; }
        public String ProcessCode_1 { set; get; }
        public DateTime? StartDate_1 { set; get; }
        public DateTime? EndDate_1 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class LeadListComponent_776113_onChange_Response
    {
        public KCommonEntityPage TM_GetLeads { set; get; }

        public KCommonEntityPage TMLeadProcessCountSummary { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class LeadListComponent_576673_onChange_Request
    {
        public Int32? StepOrder_0 { set; get; }
        public Guid? UserId_0 { set; get; }
        public String MusteriAdi_0 { set; get; }
        public String ProductName_0 { set; get; }
        public String LeadCode_0 { set; get; }
        public String Tel_0 { set; get; }
        public String CategoryName_0 { set; get; }
        public String StoreIds_0 { set; get; }
        public String SatisDanismaniIds_0 { set; get; }
        public String ProcessCode_0 { set; get; }
        public DateTime? StartDate_0 { set; get; }
        public DateTime? EndDate_0 { set; get; }
        public Guid? UserId_1 { set; get; }
        public String MusteriAdi_1 { set; get; }
        public String ProductName_1 { set; get; }
        public String LeadCode_1 { set; get; }
        public String Tel_1 { set; get; }
        public String CategoryName_1 { set; get; }
        public String StoreIds_1 { set; get; }
        public String SatisDanismaniIds_1 { set; get; }
        public String ProcessCode_1 { set; get; }
        public DateTime? StartDate_1 { set; get; }
        public DateTime? EndDate_1 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class LeadListComponent_576673_onChange_Response
    {
        public KCommonEntityPage TM_GetLeads { set; get; }

        public KCommonEntityPage TMLeadProcessCountSummary { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class LeadListComponent_836823_onChange_Request
    {
        public Int32? StepOrder_0 { set; get; }
        public Guid? UserId_0 { set; get; }
        public String MusteriAdi_0 { set; get; }
        public String ProductName_0 { set; get; }
        public String LeadCode_0 { set; get; }
        public String Tel_0 { set; get; }
        public String CategoryName_0 { set; get; }
        public String StoreIds_0 { set; get; }
        public String SatisDanismaniIds_0 { set; get; }
        public String ProcessCode_0 { set; get; }
        public DateTime? StartDate_0 { set; get; }
        public DateTime? EndDate_0 { set; get; }
        public Guid? UserId_1 { set; get; }
        public String MusteriAdi_1 { set; get; }
        public String ProductName_1 { set; get; }
        public String LeadCode_1 { set; get; }
        public String Tel_1 { set; get; }
        public String CategoryName_1 { set; get; }
        public String StoreIds_1 { set; get; }
        public String SatisDanismaniIds_1 { set; get; }
        public String ProcessCode_1 { set; get; }
        public DateTime? StartDate_1 { set; get; }
        public DateTime? EndDate_1 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class LeadListComponent_836823_onChange_Response
    {
        public KCommonEntityPage TM_GetLeads { set; get; }

        public KCommonEntityPage TMLeadProcessCountSummary { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class LeadListComponent_314150_onChange_Request
    {
        public Int32? StepOrder_0 { set; get; }
        public Guid? UserId_0 { set; get; }
        public String MusteriAdi_0 { set; get; }
        public String ProductName_0 { set; get; }
        public String LeadCode_0 { set; get; }
        public String Tel_0 { set; get; }
        public String CategoryName_0 { set; get; }
        public String StoreIds_0 { set; get; }
        public String SatisDanismaniIds_0 { set; get; }
        public String ProcessCode_0 { set; get; }
        public DateTime? StartDate_0 { set; get; }
        public DateTime? EndDate_0 { set; get; }
        public Guid? UserId_1 { set; get; }
        public String MusteriAdi_1 { set; get; }
        public String ProductName_1 { set; get; }
        public String LeadCode_1 { set; get; }
        public String Tel_1 { set; get; }
        public String CategoryName_1 { set; get; }
        public String StoreIds_1 { set; get; }
        public String SatisDanismaniIds_1 { set; get; }
        public String ProcessCode_1 { set; get; }
        public DateTime? StartDate_1 { set; get; }
        public DateTime? EndDate_1 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class LeadListComponent_314150_onChange_Response
    {
        public KCommonEntityPage TM_GetLeads { set; get; }

        public KCommonEntityPage TMLeadProcessCountSummary { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class LeadListComponent_872239_onChange_Request
    {
        public Int32? StepOrder_0 { set; get; }
        public Guid? UserId_0 { set; get; }
        public String MusteriAdi_0 { set; get; }
        public String ProductName_0 { set; get; }
        public String LeadCode_0 { set; get; }
        public String Tel_0 { set; get; }
        public String CategoryName_0 { set; get; }
        public String StoreIds_0 { set; get; }
        public String SatisDanismaniIds_0 { set; get; }
        public String ProcessCode_0 { set; get; }
        public DateTime? StartDate_0 { set; get; }
        public DateTime? EndDate_0 { set; get; }
        public Guid? UserId_1 { set; get; }
        public String MusteriAdi_1 { set; get; }
        public String ProductName_1 { set; get; }
        public String LeadCode_1 { set; get; }
        public String Tel_1 { set; get; }
        public String CategoryName_1 { set; get; }
        public String StoreIds_1 { set; get; }
        public String SatisDanismaniIds_1 { set; get; }
        public String ProcessCode_1 { set; get; }
        public DateTime? StartDate_1 { set; get; }
        public DateTime? EndDate_1 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class LeadListComponent_872239_onChange_Response
    {
        public KCommonEntityPage TM_GetLeads { set; get; }

        public KCommonEntityPage TMLeadProcessCountSummary { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class LeadListComponent_161661_onChange_Request
    {
        public Int32? StepOrder_0 { set; get; }
        public Guid? UserId_0 { set; get; }
        public String MusteriAdi_0 { set; get; }
        public String ProductName_0 { set; get; }
        public String LeadCode_0 { set; get; }
        public String Tel_0 { set; get; }
        public String CategoryName_0 { set; get; }
        public String StoreIds_0 { set; get; }
        public String SatisDanismaniIds_0 { set; get; }
        public String ProcessCode_0 { set; get; }
        public DateTime? StartDate_0 { set; get; }
        public DateTime? EndDate_0 { set; get; }
        public Guid? UserId_1 { set; get; }
        public String MusteriAdi_1 { set; get; }
        public String ProductName_1 { set; get; }
        public String LeadCode_1 { set; get; }
        public String Tel_1 { set; get; }
        public String CategoryName_1 { set; get; }
        public String StoreIds_1 { set; get; }
        public String SatisDanismaniIds_1 { set; get; }
        public String ProcessCode_1 { set; get; }
        public DateTime? StartDate_1 { set; get; }
        public DateTime? EndDate_1 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class LeadListComponent_161661_onChange_Response
    {
        public KCommonEntityPage TM_GetLeads { set; get; }

        public KCommonEntityPage TMLeadProcessCountSummary { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class LeadListComponent_937502_onClick_Request
    {
        public Int32? StepOrder_0 { set; get; }
        public Guid? UserId_0 { set; get; }
        public String MusteriAdi_0 { set; get; }
        public String ProductName_0 { set; get; }
        public String LeadCode_0 { set; get; }
        public String Tel_0 { set; get; }
        public String CategoryName_0 { set; get; }
        public String StoreIds_0 { set; get; }
        public String SatisDanismaniIds_0 { set; get; }
        public String ProcessCode_0 { set; get; }
        public DateTime? StartDate_0 { set; get; }
        public DateTime? EndDate_0 { set; get; }
        public Guid? UserId_1 { set; get; }
        public String MusteriAdi_1 { set; get; }
        public String ProductName_1 { set; get; }
        public String LeadCode_1 { set; get; }
        public String Tel_1 { set; get; }
        public String CategoryName_1 { set; get; }
        public String StoreIds_1 { set; get; }
        public String SatisDanismaniIds_1 { set; get; }
        public String ProcessCode_1 { set; get; }
        public DateTime? StartDate_1 { set; get; }
        public DateTime? EndDate_1 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class LeadListComponent_937502_onClick_Response
    {
        public KCommonEntityPage TM_GetLeads { set; get; }

        public KCommonEntityPage TMLeadProcessCountSummary { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class LeadListComponent_873248_onClick1__Request
    {
        public Int32? StepOrder_0 { set; get; }
        public Guid? UserId_0 { set; get; }
        public String MusteriAdi_0 { set; get; }
        public String ProductName_0 { set; get; }
        public String LeadCode_0 { set; get; }
        public String Tel_0 { set; get; }
        public String CategoryName_0 { set; get; }
        public String StoreIds_0 { set; get; }
        public String SatisDanismaniIds_0 { set; get; }
        public String ProcessCode_0 { set; get; }
        public DateTime? StartDate_0 { set; get; }
        public DateTime? EndDate_0 { set; get; }
        public Guid? UserId_1 { set; get; }
        public String MusteriAdi_1 { set; get; }
        public String ProductName_1 { set; get; }
        public String LeadCode_1 { set; get; }
        public String Tel_1 { set; get; }
        public String CategoryName_1 { set; get; }
        public String StoreIds_1 { set; get; }
        public String SatisDanismaniIds_1 { set; get; }
        public String ProcessCode_1 { set; get; }
        public DateTime? StartDate_1 { set; get; }
        public DateTime? EndDate_1 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class LeadListComponent_873248_onClick1__Response
    {
        public KCommonEntityPage TM_GetLeads { set; get; }

        public KCommonEntityPage TMLeadProcessCountSummary { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class LeadListComponent_60588_onChange_Request
    {
        public Int32? StepOrder_0 { set; get; }
        public Guid? UserId_0 { set; get; }
        public String MusteriAdi_0 { set; get; }
        public String ProductName_0 { set; get; }
        public String LeadCode_0 { set; get; }
        public String Tel_0 { set; get; }
        public String CategoryName_0 { set; get; }
        public String StoreIds_0 { set; get; }
        public String SatisDanismaniIds_0 { set; get; }
        public String ProcessCode_0 { set; get; }
        public DateTime? StartDate_0 { set; get; }
        public DateTime? EndDate_0 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class LeadListComponent_60588_onChange_Response
    {
        public KCommonEntityPage TM_GetLeads { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class LeadListComponent_17950_onClick1__Request
    {
        public Int32? StepOrder_0 { set; get; }
        public Guid? UserId_0 { set; get; }
        public String MusteriAdi_0 { set; get; }
        public String ProductName_0 { set; get; }
        public String LeadCode_0 { set; get; }
        public String Tel_0 { set; get; }
        public String CategoryName_0 { set; get; }
        public String StoreIds_0 { set; get; }
        public String SatisDanismaniIds_0 { set; get; }
        public String ProcessCode_0 { set; get; }
        public DateTime? StartDate_0 { set; get; }
        public DateTime? EndDate_0 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class LeadListComponent_17950_onClick1__Response
    {
        public KCommonEntityPage TM_GetLeads { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class LeadListComponent_378811_onClick_Request
    {
        public Object value_0 { set; get; }
        public String header_0 { set; get; }
        public String footer_0 { set; get; }
        public String columns_0 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class LeadListComponent_378811_onClick_Response
    {
        public KuikaCommonRestResult ExportExcel { set; get; }

    }
}
