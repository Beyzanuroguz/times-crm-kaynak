
using Microsoft.AspNetCore.Hosting;
using Microsoft.Extensions.Hosting;

namespace Kuika.App
{
    public class Program
    {
        public static void Main(string[] args)
        {
            Kuika.Common.Isolation.SatelliteLoader.Initialize();
            CreateHostBuilder(args).Build().Run();
        }

        public static IHostBuilder CreateHostBuilder(string[] args) =>
            Host.CreateDefaultBuilder(args)
                .ConfigureWebHostDefaults(webBuilder =>
                {
                    webBuilder.UseStartup<Startup>();
                });
    }
}