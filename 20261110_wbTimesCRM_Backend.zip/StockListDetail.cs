
using Kuika.Common;
using Kuika.Common.Attributes;
using Kuika.Common.Bases;
using Kuika.Common.Enums;
using Kuika.Common.Accessors;
using Kuika.Common.Json;
using Kuika.Common.Classes;
using Kuika.Common.Exceptions;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Kuika.Common.Helpers;
using Kuika.Common.Settings;
using System.Collections.Generic;
using System;
using Kuika.Common.Extensions;
using System.Linq;
using Kuika.Common.Rest;
using WorkflowCore.Interface;
using Kuika.Common.Interfaces;
using Kuika.Common.Workflow;
using Kuika.Common.Workflow.Extensions;
using Kuika.Common.Workflow.DTOs;
using Kuika.Common.Models;
using Kuika.Common.Menu.Response;
using Kuika.Common.Entities;
using System.Reflection;
using Newtonsoft.Json.Linq;
using Newtonsoft.Json;
using System.Net.Http;
using Iyzipay.Model.V2.Subscription;
using Kuika.Common.Payments.Iyzico;
using Kuika.Common.Payments.Param;
using Iyzipay;
using Kuika.Common.Searching.DTOs;
using Kuika.Common.Helpers.Sap;
using Kuika.Common.Mcp;
using Kuika.Common.Vision.DTOs;
using Kuika.Common.Audit;
using Kuika.Common.Payments.Mobile;
using Kuika.ThirdPartyApisCollection;

namespace Kuika.Reslen_01.Api
{
    [ApiExplorerSettings(GroupName = "all")]
    [Authorize]
    [ApiController]
    [Route("v1/api/StockListDetail")]
    public class StockListDetail_Controller : KControllerBase
    {
        private string appName = "wbTimesCRM";
        private Guid appId = Guid.Parse("0e8ecb48-8c52-463c-5db5-08de3ec441b1");
        private static string screenName = "StockListDetail";
        private Guid screenId = Guid.Parse("43c9f758-5447-4db5-af1e-6f61fb36d660");
        private string connectionString { get { return Kuika.Common.KContext.GetConnectionString(); } }

        [HttpGet, Route("myroles")]
        public IActionResult GetMyRoles()
        {
            try
            {
                var result = KProviderManager.Authorization.GetMyRoles(appId, appName, screenId, screenName);
                return Ok(result);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new HttpExceptionDto() { Message = ex.Message, StackTrace = ex.StackTrace });
            }
        }


        [HttpPost, Route("StockListDetailPageInit")]
        public IActionResult StockListDetailPageInit(StockListDetailPageInit_Request request)
        {

            var result = new StockListDetailPageInit_Response();

            var prms_TM_UserRoleByUserId_0 = new List<kSqlParameter>();
            prms_TM_UserRoleByUserId_0.Add(new kSqlParameter() { Name = "UserID", Value = Kuika.Common.KContext.CurrentUser?.Id });
            using var auditTM_UserRoleByUserId_0 = ActionAuditScope.Begin("eaf52e1d-e163-8be4-bb82-4a13f613fb9d", "TM_UserRoleByUserId", applicationName: "wbTimesCRM", screenOrEndpointName: "StockListDetail");
            result.TM_UserRoleByUserId = KPersister.Fetch(KContext.GetConnectionString(), @"

SELECT 
    KU.Id AS UserId,
    KU.Username AS UserName,
    KU.FirstName AS FirstName,
    KU.LastName AS LastName,
    ISNULL(
    STRING_AGG(
        CASE 
            WHEN R.Name = 'TimesAdmin'           THEN N'Admin'
            WHEN R.Name = 'TimesUstYonetici'     THEN N'Üst Yönetici'
            WHEN R.Name = 'TimesYonetici'        THEN N'Yönetici'
            WHEN R.Name = 'TimesSatisPersoneli'  THEN N'Satış Personeli'
            WHEN R.Name = 'TimesMagazaMuduru'    THEN N'Mağaza Müdürü'
            ELSE NULL
        END,
        '  '
    ),
    'Rol Yok'
) AS RoleNames,
ISNULL( STRING_AGG( CASE WHEN R.Name IN ( 'TimesAdmin', 'TimesUstYonetici', 'TimesYonetici', 'TimesSatisPersoneli', 'TimesMagazaMuduru' ) THEN R.Name ELSE NULL END, ', ' ), 'Rol Yok' ) AS Role
FROM dbo.KUser KU
LEFT JOIN dbo.KUserRole UR 
    ON UR.KUser_Id = KU.Id AND UR.IsDeleted = 0
LEFT JOIN dbo.KRole R 
    ON R.Id = UR.KRole_Id AND R.IsDeleted = 0
WHERE KU.IsDeleted = 0
  AND KU.Id = @UserID
GROUP BY KU.Id,KU.UserName, KU.FirstName, KU.LastName;
", new string[] { "UserId", "UserName", "FirstName", "LastName", "RoleNames", "Role" }, prms_TM_UserRoleByUserId_0.ToArray());
            ;

            var prms_TM_GetProductDetailByStoreAndProduct_1 = new List<kSqlParameter>();
            prms_TM_GetProductDetailByStoreAndProduct_1.Add(new kSqlParameter() { Name = "StoreCode", Value = request.StoreCode_1 });
            prms_TM_GetProductDetailByStoreAndProduct_1.Add(new kSqlParameter() { Name = "ProductCode", Value = request.ProductCode_1 });
            using var auditTM_GetProductDetailByStoreAndProduct_1 = ActionAuditScope.Begin("f76017e9-295f-df45-ae7b-6d570e4f8b6f", "TM_GetProductDetailByStoreAndProduct", applicationName: "wbTimesCRM", screenOrEndpointName: "StockListDetail");
            result.TM_GetProductDetailByStoreAndProduct = KPersister.Fetch(KContext.GetConnectionString(), @"DECLARE @StoreId UNIQUEIDENTIFIER;
DECLARE @ProductId UNIQUEIDENTIFIER;

SELECT @StoreId = Id 
FROM tmscrq.TMStore 
WHERE StoreCode = @StoreCode;

SELECT @ProductId = Id
FROM tmscrq.TMProduct
WHERE ProductCode = @ProductCode;

DECLARE @ReservedCount INT;

-- 🔥 REZERVE HESAP (DUE KALDIRILDI)
SELECT @ReservedCount = COUNT(DISTINCT r.LeadId)
FROM tmscrq.TMLeadReservation r
INNER JOIN tmscrq.TMLead l 
    ON l.Id = r.LeadId
INNER JOIN tmscrq.TMLeadProcess lp 
    ON lp.Id = l.ProcessID
LEFT JOIN tmscrq.TMUser tu 
    ON tu.KUserID = l.CreatedBy
WHERE 
    r.IsActive = 1
    -- ❌ DeliveryDueDate kaldırıldı
    AND lp.Code = 'DELIVERY_PENDING'
    AND COALESCE(l.StoreId, tu.StoreId) = @StoreId
    AND l.ProductId = @ProductId;

SET @ReservedCount = ISNULL(@ReservedCount, 0);

SELECT 
    @ProductId AS ProductId,

    i.officeDescription AS Ofis,
    p.CategoryName,
    p.ProductName,
    p.Referance,
    p.Dial,
    p.Bracelet,

    ISNULL(SUM(i.InventoryQty1), 0) AS ToplamStok,

    @ReservedCount AS RezerveStok,

    ISNULL(SUM(i.InventoryQty1), 0) - @ReservedCount AS MusaitStok

FROM tmscrq.TMProduct p

LEFT JOIN tmscrq.TMItemInventory i 
    ON i.productCode = p.ProductCode
    AND i.storeCode = @StoreCode
    AND i.officeDescription IS NOT NULL
    AND i.officeDescription NOT IN ('Teknik Servis Ofis')

WHERE 
    p.ProductCode = @ProductCode

GROUP BY 
    i.officeDescription,
    p.CategoryName,
    p.ProductName,
    p.Referance,
    p.Dial,
    p.Bracelet

ORDER BY 
    i.officeDescription;", new string[] { "ProductId", "Ofis", "CategoryName", "ProductName", "Referance", "Dial", "Bracelet", "ToplamStok", "RezerveStok", "MusaitStok" }, prms_TM_GetProductDetailByStoreAndProduct_1.ToArray());
            ;

            var prms_TM_GetAvailableLeadsForReservation_2 = new List<kSqlParameter>();
            prms_TM_GetAvailableLeadsForReservation_2.Add(new kSqlParameter() { Name = "StoreCode", Value = request.StoreCode_2 });
            prms_TM_GetAvailableLeadsForReservation_2.Add(new kSqlParameter() { Name = "ProductId", Value = result.TM_GetProductDetailByStoreAndProduct.ResultList.FirstOrDefault()?.GetValueByFieldName("ProductId") });
            prms_TM_GetAvailableLeadsForReservation_2.Add(new kSqlParameter() { Name = "SearchText", Value = (null as object) });
            using var auditTM_GetAvailableLeadsForReservation_2 = ActionAuditScope.Begin("277e3351-257a-0ba3-5a62-ed5c8a2c6fd5", "TM_GetAvailableLeadsForReservation", applicationName: "wbTimesCRM", screenOrEndpointName: "StockListDetail");
            result.TM_GetAvailableLeadsForReservation = KPersister.Fetch(KContext.GetConnectionString(), @"SELECT 
    l.Id,
    l.LeadCode,

    LTRIM(RTRIM(
        COALESCE(cu.Name, '') + ' ' + COALESCE(cu.LastName, '')
    )) AS Musteri,

    COALESCE(cu.Tel, '-') AS Telefon,
    COALESCE(cu.Email, '-') AS Email,

    l.CreatedAt AS TalepTarihi,
    FORMAT(l.EstimatedDate, 'yyyy MMMM', 'tr-TR') AS TerminTarihi,

    lp.Code AS ProcessCode,
    lp.Name AS ProcessName,

    l.ProductId

FROM tmscrq.TMLead l

INNER JOIN tmscrq.TMCustomer cu 
    ON cu.Id = l.CustomerId

INNER JOIN tmscrq.TMLeadProcess lp 
    ON lp.Id = l.ProcessID

INNER JOIN tmscrq.TMStore st 
    ON st.Id = l.StoreId

WHERE 
    LTRIM(RTRIM(st.StoreCode)) = LTRIM(RTRIM(@StoreCode))

    AND lp.Code = 'APPROVED'

    -- 🔥 DOĞRU REZERV KONTROLÜ
    AND NOT EXISTS (
        SELECT 1
        FROM tmscrq.TMLeadReservation r
        WHERE r.LeadId = l.Id
          AND r.IsActive = 1
          AND ISNULL(r.IsRejected,0) = 0
    )

    AND l.ProductId = @ProductId

    AND (
        @SearchText IS NULL OR @SearchText = ''
        OR (cu.Name + ' ' + cu.LastName) LIKE '%' + @SearchText + '%'
        OR cu.Tel LIKE '%' + @SearchText + '%'
    )

ORDER BY l.CreatedAt DESC;", new string[] { "Id", "LeadCode", "Musteri", "Telefon", "Email", "TalepTarihi", "TerminTarihi", "ProcessCode", "ProcessName", "ProductId" }, prms_TM_GetAvailableLeadsForReservation_2.ToArray());
            ;

            var prms_TM_GetReservedLeadsByStoreCode_3 = new List<kSqlParameter>();
            prms_TM_GetReservedLeadsByStoreCode_3.Add(new kSqlParameter() { Name = "StoreCode", Value = request.StoreCode_3 });
            prms_TM_GetReservedLeadsByStoreCode_3.Add(new kSqlParameter() { Name = "ProductId", Value = result.TM_GetProductDetailByStoreAndProduct.ResultList.FirstOrDefault()?.GetValueByFieldName("ProductId") });
            prms_TM_GetReservedLeadsByStoreCode_3.Add(new kSqlParameter() { Name = "SearchText", Value = (null as object) });
            using var auditTM_GetReservedLeadsByStoreCode_3 = ActionAuditScope.Begin("0133fe07-8079-c66e-c9d6-cd661fc4265a", "TM_GetReservedLeadsByStoreCode", applicationName: "wbTimesCRM", screenOrEndpointName: "StockListDetail");
            result.TM_GetReservedLeadsByStoreCode = KPersister.Fetch(KContext.GetConnectionString(), @"SELECT 
    l.Id,
    l.LeadCode,

    LTRIM(RTRIM(
        COALESCE(cu.Name, '') + ' ' + COALESCE(cu.LastName, '')
    )) AS Musteri,

    COALESCE(cu.Tel, '-') AS Telefon,
    COALESCE(cu.Email, '-') AS Email,

    CONVERT(date, l.EstimatedDate) AS TerminTarihi,

    r.ReservedAt AS RezervBaslangic,

    COALESCE(r.ReservationNote, '-') AS RezervNotu,

    COALESCE(ku.FirstName + ' ' + ku.LastName, '-') AS ReservedBy,

    lp.Name AS ProcessName,

    l.ProductId,

    CASE 
        WHEN r.IsApproved = 1 THEN 1
        ELSE 0
    END AS ReserveStatus

FROM tmscrq.TMLead l

INNER JOIN tmscrq.TMCustomer cu 
    ON cu.Id = l.CustomerId

INNER JOIN tmscrq.TMLeadProcess lp 
    ON lp.Id = l.ProcessID

OUTER APPLY
(
    SELECT TOP 1 *
    FROM tmscrq.TMLeadReservation r
    WHERE r.LeadId = l.Id
      AND r.IsActive = 1
    ORDER BY r.ReservedAt DESC
) r

LEFT JOIN dbo.KUser ku 
    ON ku.Id = r.ReservedBy

LEFT JOIN tmscrq.TMUser tu 
    ON tu.KUserID = l.CreatedBy

LEFT JOIN tmscrq.TMStore st 
    ON st.Id = COALESCE(l.StoreId, tu.StoreId)

WHERE 
    st.StoreCode = @StoreCode

    -- 🔥 FIX BURADA
    AND lp.Code NOT IN ('DELIVERED','REJECTED')

    AND l.ProductId = @ProductId

    AND r.Id IS NOT NULL

    AND (
        @SearchText IS NULL OR @SearchText = ''
        OR (cu.Name + ' ' + cu.LastName) LIKE '%' + @SearchText + '%'
        OR cu.Tel LIKE '%' + @SearchText + '%'
    )

ORDER BY 
    r.ReservedAt DESC;", new string[] { "Id", "LeadCode", "Musteri", "Telefon", "Email", "TerminTarihi", "RezervBaslangic", "RezervNotu", "ReservedBy", "ProcessName", "ProductId", "ReserveStatus" }, prms_TM_GetReservedLeadsByStoreCode_3.ToArray());
            ;

            var prms_TM_GetReserveShowByProductCode_4 = new List<kSqlParameter>();
            prms_TM_GetReserveShowByProductCode_4.Add(new kSqlParameter() { Name = "UserRole", Value = result.TM_UserRoleByUserId.ResultList.FirstOrDefault()?.GetValueByFieldName("RoleNames") });
            prms_TM_GetReserveShowByProductCode_4.Add(new kSqlParameter() { Name = "ProductCode", Value = request.ProductCode_4 });
            using var auditTM_GetReserveShowByProductCode_4 = ActionAuditScope.Begin("39a43136-c078-2bca-e659-f10f20657316", "TM_GetReserveShowByProductCode", applicationName: "wbTimesCRM", screenOrEndpointName: "StockListDetail");
            result.TM_GetReserveShowByProductCode = KPersister.Fetch(KContext.GetConnectionString(), @"DECLARE @Show INT;

SELECT 
    @Show =
    CASE 
        -- 🔹 TUDOR
        WHEN p.Brand = 'Tudor'
             AND @UserRole IN (N'Mağaza Müdürü', N'Yönetici', N'Üst Yönetici')
        THEN 1

        -- 🔹 ROLEX KATEGORİ 1
        WHEN p.Brand = 'Rolex'
             AND p.CategoryName = N'Kategori 1'
             AND @UserRole IN (N'Mağaza Müdürü', N'Yönetici', N'Üst Yönetici')
        THEN 1

        -- 🔹 ROLEX KATEGORİ 2-3
        WHEN p.Brand = 'Rolex'
             AND p.CategoryName IN (N'Kategori 2', N'Kategori 3')
             AND @UserRole IN (N'Yönetici', N'Üst Yönetici')
        THEN 1

        ELSE 0
    END

FROM tmscrq.TMProduct p
WHERE p.ProductCode = @ProductCode;

SELECT @Show AS ReserveShow;", new string[] { "ReserveShow" }, prms_TM_GetReserveShowByProductCode_4.ToArray());
            ;


            return Ok(result);
        }


        [HttpPost, Route("StockListDetailComponent_988953_onChange")]
        public IActionResult StockListDetailComponent_988953_onChange(StockListDetailComponent_988953_onChange_Request request)
        {

            var result = new StockListDetailComponent_988953_onChange_Response();

            var prms_TM_GetAvailableLeadsForReservation_0 = new List<kSqlParameter>();
            prms_TM_GetAvailableLeadsForReservation_0.Add(new kSqlParameter() { Name = "StoreCode", Value = request.StoreCode_0 });
            prms_TM_GetAvailableLeadsForReservation_0.Add(new kSqlParameter() { Name = "ProductId", Value = request.ProductId_0 });
            prms_TM_GetAvailableLeadsForReservation_0.Add(new kSqlParameter() { Name = "SearchText", Value = request.SearchText_0 });
            using var auditTM_GetAvailableLeadsForReservation_0 = ActionAuditScope.Begin("bc799322-0765-331a-576a-6dc0cf3e54bb", "TM_GetAvailableLeadsForReservation", applicationName: "wbTimesCRM", screenOrEndpointName: "StockListDetail");
            result.TM_GetAvailableLeadsForReservation = KPersister.Fetch(KContext.GetConnectionString(), @"SELECT 
    l.Id,
    l.LeadCode,

    LTRIM(RTRIM(
        COALESCE(cu.Name, '') + ' ' + COALESCE(cu.LastName, '')
    )) AS Musteri,

    COALESCE(cu.Tel, '-') AS Telefon,
    COALESCE(cu.Email, '-') AS Email,

    l.CreatedAt AS TalepTarihi,
    FORMAT(l.EstimatedDate, 'yyyy MMMM', 'tr-TR') AS TerminTarihi,

    lp.Code AS ProcessCode,
    lp.Name AS ProcessName,

    l.ProductId

FROM tmscrq.TMLead l

INNER JOIN tmscrq.TMCustomer cu 
    ON cu.Id = l.CustomerId

INNER JOIN tmscrq.TMLeadProcess lp 
    ON lp.Id = l.ProcessID

INNER JOIN tmscrq.TMStore st 
    ON st.Id = l.StoreId

WHERE 
    LTRIM(RTRIM(st.StoreCode)) = LTRIM(RTRIM(@StoreCode))

    AND lp.Code = 'APPROVED'

    -- 🔥 DOĞRU REZERV KONTROLÜ
    AND NOT EXISTS (
        SELECT 1
        FROM tmscrq.TMLeadReservation r
        WHERE r.LeadId = l.Id
          AND r.IsActive = 1
          AND ISNULL(r.IsRejected,0) = 0
    )

    AND l.ProductId = @ProductId

    AND (
        @SearchText IS NULL OR @SearchText = ''
        OR (cu.Name + ' ' + cu.LastName) LIKE '%' + @SearchText + '%'
        OR cu.Tel LIKE '%' + @SearchText + '%'
    )

ORDER BY l.CreatedAt DESC;", new string[] { "Id", "LeadCode", "Musteri", "Telefon", "Email", "TalepTarihi", "TerminTarihi", "ProcessCode", "ProcessName", "ProductId" }, prms_TM_GetAvailableLeadsForReservation_0.ToArray());
            ;


            return Ok(result);
        }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class StockListDetailPageInit_Request
    {
        public Guid? UserID_0 { set; get; }
        public String StoreCode_1 { set; get; }
        public String ProductCode_1 { set; get; }
        public String StoreCode_2 { set; get; }
        public Guid? ProductId_2 { set; get; }
        public String SearchText_2 { set; get; }
        public String StoreCode_3 { set; get; }
        public Guid? ProductId_3 { set; get; }
        public String SearchText_3 { set; get; }
        public String UserRole_4 { set; get; }
        public String ProductCode_4 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class StockListDetailPageInit_Response
    {
        public KCommonEntityPage TM_UserRoleByUserId { set; get; }

        public KCommonEntityPage TM_GetProductDetailByStoreAndProduct { set; get; }

        public KCommonEntityPage TM_GetAvailableLeadsForReservation { set; get; }

        public KCommonEntityPage TM_GetReservedLeadsByStoreCode { set; get; }

        public KCommonEntityPage TM_GetReserveShowByProductCode { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class StockListDetailComponent_988953_onChange_Request
    {
        public String StoreCode_0 { set; get; }
        public Guid? ProductId_0 { set; get; }
        public String SearchText_0 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class StockListDetailComponent_988953_onChange_Response
    {
        public KCommonEntityPage TM_GetAvailableLeadsForReservation { set; get; }

    }
}
