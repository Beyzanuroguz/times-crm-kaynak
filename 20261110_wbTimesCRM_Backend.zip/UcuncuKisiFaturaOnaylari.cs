
using Kuika.Common;
using Kuika.Common.Attributes;
using Kuika.Common.Bases;
using Kuika.Common.Enums;
using Kuika.Common.Accessors;
using Kuika.Common.Json;
using Kuika.Common.Classes;
using Kuika.Common.Exceptions;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Kuika.Common.Helpers;
using Kuika.Common.Settings;
using System.Collections.Generic;
using System;
using Kuika.Common.Extensions;
using System.Linq;
using Kuika.Common.Rest;
using WorkflowCore.Interface;
using Kuika.Common.Interfaces;
using Kuika.Common.Workflow;
using Kuika.Common.Workflow.Extensions;
using Kuika.Common.Workflow.DTOs;
using Kuika.Common.Models;
using Kuika.Common.Menu.Response;
using Kuika.Common.Entities;
using System.Reflection;
using Newtonsoft.Json.Linq;
using Newtonsoft.Json;
using System.Net.Http;
using Iyzipay.Model.V2.Subscription;
using Kuika.Common.Payments.Iyzico;
using Kuika.Common.Payments.Param;
using Iyzipay;
using Kuika.Common.Searching.DTOs;
using Kuika.Common.Helpers.Sap;
using Kuika.Common.Mcp;
using Kuika.Common.Vision.DTOs;
using Kuika.Common.Audit;
using Kuika.Common.Payments.Mobile;
using Kuika.ThirdPartyApisCollection;

namespace Kuika.Reslen_01.Api
{
    [ApiExplorerSettings(GroupName = "all")]
    [Authorize]
    [ApiController]
    [Route("v1/api/UcuncuKisiFaturaOnaylari")]
    public class UcuncuKisiFaturaOnaylari_Controller : KControllerBase
    {
        private string appName = "wbTimesCRM";
        private Guid appId = Guid.Parse("0e8ecb48-8c52-463c-5db5-08de3ec441b1");
        private static string screenName = "UcuncuKisiFaturaOnaylari";
        private Guid screenId = Guid.Parse("8c74c18f-2864-4b9f-ad45-f4dd4f1a4c0d");
        private string connectionString { get { return Kuika.Common.KContext.GetConnectionString(); } }

        [HttpGet, Route("myroles")]
        public IActionResult GetMyRoles()
        {
            try
            {
                var result = KProviderManager.Authorization.GetMyRoles(appId, appName, screenId, screenName);
                return Ok(result);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new HttpExceptionDto() { Message = ex.Message, StackTrace = ex.StackTrace });
            }
        }


        [HttpPost, Route("UcuncuKisiFaturaOnaylariPageInit")]
        public IActionResult UcuncuKisiFaturaOnaylariPageInit(UcuncuKisiFaturaOnaylariPageInit_Request request)
        {

            var result = new UcuncuKisiFaturaOnaylariPageInit_Response();

            var prms_TM_GetPendingThirdPartyInvoiceApprovals_0 = new List<kSqlParameter>();
            prms_TM_GetPendingThirdPartyInvoiceApprovals_0.Add(new kSqlParameter() { Name = "CurrentUserId", Value = Kuika.Common.KContext.CurrentUser?.Id });
            using var auditTM_GetPendingThirdPartyInvoiceApprovals_0 = ActionAuditScope.Begin("f1a6a5c8-1d55-1967-93fb-f2140221767f", "TM_GetPendingThirdPartyInvoiceApprovals", applicationName: "wbTimesCRM", screenOrEndpointName: "UcuncuKisiFaturaOnaylari");
            result.TM_GetPendingThirdPartyInvoiceApprovals = KPersister.Fetch(KContext.GetConnectionString(), @"SET NOCOUNT ON;

DECLARE @IsTopManager BIT = 0;

IF EXISTS
(
    SELECT 1
    FROM dbo.KUserRole AS UR

    INNER JOIN dbo.KRole AS R
        ON R.Id = UR.KRole_Id

    WHERE UR.KUser_Id = @CurrentUserId
      AND ISNULL(UR.IsDeleted, 0) = 0
      AND ISNULL(R.IsDeleted, 0) = 0
      AND R.Name = N'TimesUstYonetici'
)
BEGIN
    SET @IsTopManager = 1;
END;

SELECT
    A.Id AS ApprovalId,
    A.SalesDraftId,
    A.SalesLeadDraftId,
    LeadDraft.LeadId,
    LeadRecord.LeadCode,
    A.RequestedAt,

    CASE
        WHEN A.SalesLeadDraftId IS NOT NULL THEN N'LEAD'
        ELSE N'DIRECT'
    END AS SaleFlowType,

    CASE
        WHEN A.SalesLeadDraftId IS NOT NULL THEN N'Talep Satışı'
        ELSE N'Normal Satış'
    END AS SaleFlowTypeText,

    ------------------------------------------------------------
    -- HAM KODLAR
    ------------------------------------------------------------
    A.Status AS ApprovalStatusCode,
    A.SourceType AS SourceTypeCode,
    A.PersonType AS PersonTypeCode,
    A.InvoiceExecutionStatus,

    ------------------------------------------------------------
    -- MEVCUT UI ALANLARI: TÜRKÇE GÖRÜNTÜ DEĞERLERİ
    ------------------------------------------------------------
    CASE UPPER(LTRIM(RTRIM(ISNULL(A.Status, N''))))
        WHEN N'DRAFT'    THEN N'Onaya Gönderilmedi'
        WHEN N'PENDING'  THEN N'Onay Bekliyor'
        WHEN N'APPROVED' THEN N'Onaylandı'
        WHEN N'REJECTED' THEN N'Reddedildi'
        ELSE ISNULL(A.Status, N'-')
    END AS Status,

    CASE UPPER(LTRIM(RTRIM(ISNULL(A.Status, N''))))
        WHEN N'DRAFT'    THEN N'Onaya Gönderilmedi'
        WHEN N'PENDING'  THEN N'Onay Bekliyor'
        WHEN N'APPROVED' THEN N'Onaylandı'
        WHEN N'REJECTED' THEN N'Reddedildi'
        ELSE ISNULL(A.Status, N'-')
    END AS ApprovalStatusText,

    CASE UPPER(LTRIM(RTRIM(ISNULL(A.PersonType, N''))))
        WHEN N'PERSON'  THEN N'Gerçek Kişi'
        WHEN N'COMPANY' THEN N'Şirket'
        ELSE ISNULL(A.PersonType, N'-')
    END AS PersonType,

    CASE UPPER(LTRIM(RTRIM(ISNULL(A.PersonType, N''))))
        WHEN N'PERSON'  THEN N'Gerçek Kişi'
        WHEN N'COMPANY' THEN N'Şirket'
        ELSE ISNULL(A.PersonType, N'-')
    END AS PersonTypeText,

    CASE UPPER(LTRIM(RTRIM(ISNULL(A.SourceType, N''))))
        WHEN N'CUSTOMER' THEN N'Müşteri Listesinden Seçildi'
        WHEN N'MANUAL'   THEN N'Manuel Girildi'
        ELSE ISNULL(A.SourceType, N'-')
    END AS SourceTypeText,

    ------------------------------------------------------------
    -- 3. KİŞİ
    ------------------------------------------------------------
    CASE
        WHEN UPPER(LTRIM(RTRIM(ISNULL(A.PersonType, N'')))) = N'COMPANY'
            THEN COALESCE(NULLIF(LTRIM(RTRIM(A.CompanyName)), N''), N'-')
        ELSE COALESCE(
            NULLIF(
                LTRIM(
                    RTRIM(
                        CONCAT(
                            ISNULL(A.FirstName, N''),
                            N' ',
                            ISNULL(A.LastName, N'')
                        )
                    )
                ),
                N''
            ),
            N'-'
        )
    END AS ThirdPartyFullName,

    A.IdentityNumber,
    A.TaxNumber,
    A.TaxOfficeCode,
    A.Address,
    A.CountryCode,
    A.StateCode,
    A.CityCode,
    A.DistrictCode,
    A.ThirdPartyCustomerCode,
    A.BillingPostalAddressId,

    ------------------------------------------------------------
    -- NORMAL VEYA TALEP SATIŞ TASLAĞINDAN ORTAK ALANLAR
    ------------------------------------------------------------
    COALESCE(DirectDraft.InvoiceType, LeadDraft.InvoiceType) AS InvoiceType,
    COALESCE(DirectDraft.TotalAmountEUR, LeadDraft.TotalAmountEUR) AS TotalAmountEUR,
    COALESCE(DirectDraft.CurrencyCode, LeadDraft.CurrencyCode) AS CurrencyCode,
    COALESCE(DirectDraft.StoreCode, LeadDraft.StoreCode) AS StoreCode,

    OriginalCustomer.CurrAccCode AS OriginalCustomerCode,

    COALESCE(
        NULLIF(
            LTRIM(
                RTRIM(
                    ISNULL(OriginalCustomer.Name, N'')
                    + CASE
                        WHEN NULLIF(
                            LTRIM(RTRIM(ISNULL(OriginalCustomer.LastName, N''))),
                            N''
                        ) IS NOT NULL
                            THEN N' ' + LTRIM(RTRIM(OriginalCustomer.LastName))
                        ELSE N''
                      END
                )
            ),
            N''
        ),
        NULLIF(LTRIM(RTRIM(OriginalCustomer.CurrAccDescription)), N''),
        NULLIF(LTRIM(RTRIM(OriginalCustomer.CurrAccCode)), N''),
        N'-'
    ) AS OriginalCustomerFullName,

    COALESCE(
        NULLIF(LTRIM(RTRIM(Store.StoreDesc)), N''),
        NULLIF(
            LTRIM(
                RTRIM(
                    COALESCE(DirectDraft.StoreCode, LeadDraft.StoreCode)
                )
            ),
            N''
        ),
        N'-'
    ) AS StoreName,

    ------------------------------------------------------------
    -- TALEP EDEN
    ------------------------------------------------------------
    RequestUser.UserName AS RequestedByUserName,

    COALESCE(
        NULLIF(
            LTRIM(
                RTRIM(
                    CONCAT(
                        ISNULL(RequestUser.FirstName, N''),
                        N' ',
                        ISNULL(RequestUser.LastName, N'')
                    )
                )
            ),
            N''
        ),
        RequestUser.UserName,
        N'-'
    ) AS RequestedByFullName,

    CAST(
        CASE
            WHEN @IsTopManager = 1
             AND A.Status = N'PENDING'
             AND
             (
                 (A.SalesDraftId IS NOT NULL
                  AND ISNULL(DirectDraft.IsCompleted, 0) = 0)
                 OR
                 (A.SalesLeadDraftId IS NOT NULL
                  AND ISNULL(LeadDraft.IsCompleted, 0) = 0)
             )
                THEN 1
            ELSE 0
        END
        AS BIT
    ) AS CanDecide

FROM tmscrq.TMThirdPartyInvoiceApproval AS A

LEFT JOIN tmscrq.TMSalesDraft AS DirectDraft
    ON DirectDraft.Id = A.SalesDraftId

LEFT JOIN tmscrq.TMSalesLeadDraft AS LeadDraft
    ON LeadDraft.Id = A.SalesLeadDraftId

LEFT JOIN tmscrq.TMLead AS LeadRecord
    ON LeadRecord.Id = LeadDraft.LeadId

LEFT JOIN tmscrq.TMCustomer AS OriginalCustomer
    ON OriginalCustomer.Id =
       COALESCE(DirectDraft.CustomerId, LeadDraft.CustomerId)

LEFT JOIN tmscrq.TMStore AS Store
    ON Store.StoreCode =
       COALESCE(DirectDraft.StoreCode, LeadDraft.StoreCode)

INNER JOIN dbo.KUser AS RequestUser
    ON RequestUser.Id = A.RequestedBy

WHERE @IsTopManager = 1
  AND A.Status = N'PENDING'
  AND A.RequestedAt IS NOT NULL
  AND
  (
      (A.SalesDraftId IS NOT NULL
       AND DirectDraft.Id IS NOT NULL
       AND ISNULL(DirectDraft.IsCompleted, 0) = 0)
      OR
      (A.SalesLeadDraftId IS NOT NULL
       AND LeadDraft.Id IS NOT NULL
       AND ISNULL(LeadDraft.IsCompleted, 0) = 0)
  )
  -- Aynı talep (LeadId) başka bir taslak üzerinden tamamlandıysa
  -- eski onay yöneticinin bekleyen listesinde de gösterilmez.
  AND NOT
  (
      A.SalesLeadDraftId IS NOT NULL
      AND EXISTS
      (
          SELECT 1
          FROM tmscrq.TMSalesLeadDraft AS CompletedLeadDraft
          WHERE CompletedLeadDraft.LeadId = LeadDraft.LeadId
            AND CompletedLeadDraft.Id <> LeadDraft.Id
            AND ISNULL(CompletedLeadDraft.IsCompleted, 0) = 1
            AND NULLIF(LTRIM(RTRIM(CompletedLeadDraft.InvoiceNumber)), N'') IS NOT NULL
      )
  )
ORDER BY A.RequestedAt ASC;
", new string[] { "ApprovalId", "SalesDraftId", "SalesLeadDraftId", "LeadId", "LeadCode", "RequestedAt", "SaleFlowType", "SaleFlowTypeText", "ApprovalStatusCode", "SourceTypeCode", "PersonTypeCode", "InvoiceExecutionStatus", "Status", "ApprovalStatusText", "PersonType", "PersonTypeText", "SourceTypeText", "ThirdPartyFullName", "IdentityNumber", "TaxNumber", "TaxOfficeCode", "Address", "CountryCode", "StateCode", "CityCode", "DistrictCode", "ThirdPartyCustomerCode", "BillingPostalAddressId", "InvoiceType", "TotalAmountEUR", "CurrencyCode", "StoreCode", "OriginalCustomerCode", "OriginalCustomerFullName", "StoreName", "RequestedByUserName", "RequestedByFullName", "CanDecide" }, prms_TM_GetPendingThirdPartyInvoiceApprovals_0.ToArray());
            ;


            return Ok(result);
        }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class UcuncuKisiFaturaOnaylariPageInit_Request
    {
        public Guid? CurrentUserId_0 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class UcuncuKisiFaturaOnaylariPageInit_Response
    {
        public KCommonEntityPage TM_GetPendingThirdPartyInvoiceApprovals { set; get; }

    }
}
