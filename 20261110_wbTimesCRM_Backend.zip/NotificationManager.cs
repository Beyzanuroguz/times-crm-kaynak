
using Kuika.Common;
using Kuika.Common.Attributes;
using Kuika.Common.Bases;
using Kuika.Common.Enums;
using Kuika.Common.Accessors;
using Kuika.Common.Json;
using Kuika.Common.Classes;
using Kuika.Common.Exceptions;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Kuika.Common.Helpers;
using Kuika.Common.Settings;
using System.Collections.Generic;
using System;
using Kuika.Common.Extensions;
using System.Linq;
using Kuika.Common.Rest;
using WorkflowCore.Interface;
using Kuika.Common.Interfaces;
using Kuika.Common.Workflow;
using Kuika.Common.Workflow.Extensions;
using Kuika.Common.Workflow.DTOs;
using Kuika.Common.Models;
using Kuika.Common.Menu.Response;
using Kuika.Common.Entities;
using System.Reflection;
using Newtonsoft.Json.Linq;
using Newtonsoft.Json;
using System.Net.Http;
using Iyzipay.Model.V2.Subscription;
using Kuika.Common.Payments.Iyzico;
using Kuika.Common.Payments.Param;
using Iyzipay;
using Kuika.Common.Searching.DTOs;
using Kuika.Common.Helpers.Sap;
using Kuika.Common.Mcp;
using Kuika.Common.Vision.DTOs;
using Kuika.Common.Audit;
using Kuika.Common.Payments.Mobile;
using Kuika.ThirdPartyApisCollection;

namespace Kuika.Reslen_01.Api
{
    [ApiExplorerSettings(GroupName = "all")]
    [Authorize]
    [ApiController]
    [Route("v1/api/NotificationManager")]
    public class NotificationManager_Controller : KControllerBase
    {
        private string appName = "wbTimesCRM";
        private Guid appId = Guid.Parse("0e8ecb48-8c52-463c-5db5-08de3ec441b1");
        private static string screenName = "NotificationManager";
        private Guid screenId = Guid.Parse("31ee8b62-5a15-4cd4-91c5-3cea4b1f0ffc");
        private string connectionString { get { return Kuika.Common.KContext.GetConnectionString(); } }

        [HttpGet, Route("myroles")]
        public IActionResult GetMyRoles()
        {
            try
            {
                var result = KProviderManager.Authorization.GetMyRoles(appId, appName, screenId, screenName);
                return Ok(result);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new HttpExceptionDto() { Message = ex.Message, StackTrace = ex.StackTrace });
            }
        }


        [HttpPost, Route("NotificationManagerPageInit")]
        public IActionResult NotificationManagerPageInit(NotificationManagerPageInit_Request request)
        {

            KProviderManager.Authorization.IsAuthorizedForRoles(appId, appName, screenId, screenName, new List<string> { $"4da1f213-c8e4-0b50-5c84-02fd13f1a622", "TimesUstYonetici" });

            var result = new NotificationManagerPageInit_Response();

            var prms_NotifListStatuChange_0 = new List<kSqlParameter>();
            prms_NotifListStatuChange_0.Add(new kSqlParameter() { Name = "DateFilter", Value = "6".ConvertToType<Int32>() });
            prms_NotifListStatuChange_0.Add(new kSqlParameter() { Name = "KUserId", Value = Kuika.Common.KContext.CurrentUser?.Id });
            prms_NotifListStatuChange_0.Add(new kSqlParameter() { Name = "NotificationTypeFilter", Value = "ALL".ConvertToType<String>() });
            prms_NotifListStatuChange_0.Add(new kSqlParameter() { Name = "ShowUnreadOnly", Value = "False".ConvertToType<Boolean>() });
            using var auditNotifListStatuChange_0 = ActionAuditScope.Begin("63b116c4-5f43-1127-27e9-ae3a61f3cdf2", "NotifListStatuChange", applicationName: "wbTimesCRM", screenOrEndpointName: "NotificationManager");
            result.NotifListStatuChange = KPersister.Fetch(KContext.GetConnectionString(), @"/*

DECLARE @StartDate DATETIME;

SET @StartDate =
CASE @DateFilter
    WHEN 1 THEN DATEADD(HOUR,-1,GETDATE())     
    WHEN 2 THEN DATEADD(HOUR,-6,GETDATE())     
    WHEN 3 THEN DATEADD(HOUR,-24,GETDATE())    
    WHEN 4 THEN DATEADD(DAY,-7,GETDATE())      
    WHEN 5 THEN DATEADD(DAY,-30,GETDATE())     
    WHEN 6 THEN '1900-01-01'                   
    ELSE '1900-01-01'
END;

------------------------------------------------------

SELECT *
FROM
(

    --------------------------------------------------
    -- 🔵 PROCESS LOG
    --------------------------------------------------
    SELECT
        NEWID() AS NotificationId,

        l.Id AS LeadId,
        l.LeadCode,
        l.ReferenceID,

        ku.FirstName + ' ' + ku.LastName AS ActionUser,
        ts.StoreDesc AS StoreName,

        STRING_AGG(
            CASE r.Name
                WHEN 'TimesAdmin' THEN 'Admin'
                WHEN 'TimesUstYonetici' THEN 'Üst Yönetici'
                WHEN 'TimesYonetici' THEN 'Yönetici'
                WHEN 'TimesSatisPersoneli' THEN 'Satış Personeli'
                WHEN 'TimesMagazaMuduru' THEN 'Mağaza Müdürü'
                ELSE r.Name
            END,' '
        ) AS RoleName,

        p.ProductName,
        p.Brand,
        p.CategoryName,

        c.Name + ' ' + c.LastName AS CustomerName,

        'PROCESS' AS NotificationType,

        lp.Name AS Title,
        lpl.Note AS Description,

        lpl.CreatedAt AS ActionDate,

        'ProcessChange' AS Category

    FROM tmscrq.TMLeadProcessLog lpl

    INNER JOIN tmscrq.TMLead l 
        ON l.Id = lpl.LeadId

    INNER JOIN tmscrq.TMLeadProcess lp 
        ON lp.Id = lpl.ProcessId

    INNER JOIN dbo.KUser ku 
        ON ku.Id = lpl.CreatedBy

    LEFT JOIN tmscrq.TMUser tu 
        ON tu.KuserID = ku.Id

    LEFT JOIN tmscrq.TMStore ts 
        ON ts.Id = tu.StoreID

    LEFT JOIN dbo.KUserRole ur 
        ON ur.KUser_Id = ku.Id

    LEFT JOIN dbo.KRole r 
        ON r.Id = ur.KRole_Id

    LEFT JOIN tmscrq.TMProduct p 
        ON p.Id = l.ProductId

    LEFT JOIN tmscrq.TMCustomer c 
        ON c.Id = l.CustomerId

    WHERE lpl.CreatedAt >= @StartDate

    GROUP BY
        l.Id,
        l.LeadCode,
        l.ReferenceID,
        ku.FirstName,
        ku.LastName,
        ts.StoreDesc,
        p.ProductName,
        p.Brand,
        p.CategoryName,
        c.Name,
        c.LastName,
        lp.Name,
        lpl.Note,
        lpl.CreatedAt

    UNION ALL

    --------------------------------------------------
    -- 🟢 UPDATE LOG
    --------------------------------------------------
    SELECT
        NEWID() AS NotificationId,

        l.Id AS LeadId,
        l.LeadCode,
        l.ReferenceID,

        ku.FirstName + ' ' + ku.LastName AS ActionUser,
        ts.StoreDesc AS StoreName,

        STRING_AGG(
            CASE r.Name
                WHEN 'TimesAdmin' THEN 'Admin'
                WHEN 'TimesUstYonetici' THEN 'Üst Yönetici'
                WHEN 'TimesYonetici' THEN 'Yönetici'
                WHEN 'TimesSatisPersoneli' THEN 'Satış Personeli'
                WHEN 'TimesMagazaMuduru' THEN 'Mağaza Müdürü'
                ELSE r.Name
            END,' '
        ) AS RoleName,

        p.ProductName,
        p.Brand,
        p.CategoryName,

        c.Name + ' ' + c.LastName AS CustomerName,

        'UPDATE' AS NotificationType,

        --------------------------------------------------
        -- TITLE
        --------------------------------------------------
        CASE
            WHEN lul.ColumnName = 'StatuId' THEN 'Alan Güncellendi: Statu'
            WHEN lul.ColumnName = 'ProcessID' THEN 'Alan Güncellendi: Süreç'
            WHEN lul.ColumnName = 'NextStep' THEN 'Alan Güncellendi: Sonraki Adım'
            WHEN lul.ColumnName = 'ContactResourceId' THEN 'Alan Güncellendi: İletişim Kaynağı'
            WHEN lul.ColumnName = 'SalesPersonKUserId' THEN 'Alan Güncellendi: Satış Personeli'
            WHEN lul.ColumnName = 'StoreId' THEN 'Alan Güncellendi: Mağaza'
            ELSE CONCAT('Alan Güncellendi: ', lul.ColumnName)
        END AS Title,

        --------------------------------------------------
        -- DESCRIPTION
        --------------------------------------------------
        CASE 

            ------------------------------------------------
            -- STATU
            ------------------------------------------------
            WHEN lul.ColumnName = 'StatuId' THEN
                CONCAT(
                    ISNULL((
                        SELECT TOP 1 Name
                        FROM tmscrq.TMLeadStatu
                        WHERE 
                            Id = TRY_CAST(lul.OldValue AS UNIQUEIDENTIFIER)
                            OR Code = lul.OldValue
                    ), '-'),
                    ' → ',
                    ISNULL((
                        SELECT TOP 1 Name
                        FROM tmscrq.TMLeadStatu
                        WHERE 
                            Id = TRY_CAST(lul.NewValue AS UNIQUEIDENTIFIER)
                            OR Code = lul.NewValue
                    ), '-')
                )

            ------------------------------------------------
            -- İLETİŞİM KAYNAĞI
            ------------------------------------------------
            WHEN lul.ColumnName = 'ContactResourceId' THEN
                CONCAT(
                    ISNULL((
                        SELECT TOP 1 ContactResourceName
                        FROM tmscrq.TMContactResource
                        WHERE 
                            Id = TRY_CAST(lul.OldValue AS UNIQUEIDENTIFIER)
                            OR ContactResourceCode = lul.OldValue
                    ), '-'),
                    ' → ',
                    ISNULL((
                        SELECT TOP 1 ContactResourceName
                        FROM tmscrq.TMContactResource
                        WHERE 
                            Id = TRY_CAST(lul.NewValue AS UNIQUEIDENTIFIER)
                            OR ContactResourceCode = lul.NewValue
                    ), '-')
                )

            ------------------------------------------------
            -- SATIŞ PERSONELİ
            ------------------------------------------------
            WHEN lul.ColumnName = 'SalesPersonKUserId' THEN
                CONCAT(
                    ISNULL((
                        SELECT TOP 1 
                            FirstName + ' ' + LastName
                        FROM dbo.KUser
                        WHERE 
                            Id = TRY_CAST(lul.OldValue AS UNIQUEIDENTIFIER)
                    ), '-'),
                    ' → ',
                    ISNULL((
                        SELECT TOP 1 
                            FirstName + ' ' + LastName
                        FROM dbo.KUser
                        WHERE 
                            Id = TRY_CAST(lul.NewValue AS UNIQUEIDENTIFIER)
                    ), '-')
                )

            ------------------------------------------------
            -- MAĞAZA
            ------------------------------------------------
            WHEN lul.ColumnName = 'StoreId' THEN
                CONCAT(
                    ISNULL((
                        SELECT TOP 1 StoreDesc
                        FROM tmscrq.TMStore
                        WHERE 
                            Id = TRY_CAST(lul.OldValue AS UNIQUEIDENTIFIER)
                    ), '-'),
                    ' → ',
                    ISNULL((
                        SELECT TOP 1 StoreDesc
                        FROM tmscrq.TMStore
                        WHERE 
                            Id = TRY_CAST(lul.NewValue AS UNIQUEIDENTIFIER)
                    ), '-')
                )

            ------------------------------------------------
            -- PROCESS
            ------------------------------------------------
            WHEN lul.ColumnName = 'ProcessID' THEN
                CONCAT(
                    ISNULL((
                        SELECT TOP 1 Name
                        FROM tmscrq.TMLeadProcess
                        WHERE 
                            Id = TRY_CAST(lul.OldValue AS UNIQUEIDENTIFIER)
                            OR Code = lul.OldValue
                    ), '-'),
                    ' → ',
                    ISNULL((
                        SELECT TOP 1 Name
                        FROM tmscrq.TMLeadProcess
                        WHERE 
                            Id = TRY_CAST(lul.NewValue AS UNIQUEIDENTIFIER)
                            OR Code = lul.NewValue
                    ), '-')
                )

            ------------------------------------------------
            -- NEXT STEP
            ------------------------------------------------
            WHEN lul.ColumnName = 'NextStep' THEN
                CONCAT(
                    ISNULL((
                        SELECT TOP 1 Name
                        FROM tmscrq.TMLeadNextStep
                        WHERE Code = lul.OldValue
                    ), '-'),
                    ' → ',
                    ISNULL((
                        SELECT TOP 1 Name
                        FROM tmscrq.TMLeadNextStep
                        WHERE Code = lul.NewValue
                    ), '-')
                )

            ------------------------------------------------
            -- DEFAULT
            ------------------------------------------------
            ELSE
                CONCAT(
                    ISNULL(lul.OldValue,'-'),
                    ' → ',
                    ISNULL(lul.NewValue,'-')
                )

        END AS Description,

        lul.UpdatedAt AS ActionDate,

        --------------------------------------------------
        -- CATEGORY
        --------------------------------------------------
        CASE 
            WHEN lul.ColumnName = 'StatuId' THEN 'StatusChange'
            WHEN lul.ColumnName = 'EstimatedDate' THEN 'DateChange'
            WHEN lul.ColumnName = 'ContactResourceId' THEN 'ContactChange'
            WHEN lul.ColumnName = 'SalesPersonKUserId' THEN 'SalesPersonChange'
            WHEN lul.ColumnName = 'StoreId' THEN 'StoreChange'
            WHEN lul.ColumnName = 'ProcessID' THEN 'ProcessChange'
            WHEN lul.ColumnName = 'NextStep' THEN 'NextStepChange'
            ELSE 'FieldUpdate'
        END AS Category

    FROM tmscrq.TMLeadUpdateLog lul

    INNER JOIN tmscrq.TMLead l 
        ON l.Id = lul.LeadId

    INNER JOIN dbo.KUser ku 
        ON ku.Id = lul.UpdatedBy

    LEFT JOIN tmscrq.TMUser tu 
        ON tu.KuserID = ku.Id

    LEFT JOIN tmscrq.TMStore ts 
        ON ts.Id = tu.StoreID

    LEFT JOIN dbo.KUserRole ur 
        ON ur.KUser_Id = ku.Id

    LEFT JOIN dbo.KRole r 
        ON r.Id = ur.KRole_Id

    LEFT JOIN tmscrq.TMProduct p 
        ON p.Id = l.ProductId

    LEFT JOIN tmscrq.TMCustomer c 
        ON c.Id = l.CustomerId

    WHERE lul.UpdatedAt >= @StartDate

    GROUP BY
        l.Id,
        l.LeadCode,
        l.ReferenceID,
        ku.FirstName,
        ku.LastName,
        ts.StoreDesc,
        p.ProductName,
        p.Brand,
        p.CategoryName,
        c.Name,
        c.LastName,
        lul.ColumnName,
        lul.OldValue,
        lul.NewValue,
        lul.UpdatedAt

) X

ORDER BY ActionDate DESC;

*/

SET NOCOUNT ON;

DECLARE @StartDate DATETIME;
DECLARE @LastReadDate DATETIMEOFFSET;


------------------------------------------------------------
-- TARİH FİLTRESİ
------------------------------------------------------------
SET @StartDate =
CASE @DateFilter
    WHEN 1 THEN DATEADD(HOUR, -1, GETDATE())
    WHEN 2 THEN DATEADD(HOUR, -6, GETDATE())
    WHEN 3 THEN DATEADD(HOUR, -24, GETDATE())
    WHEN 4 THEN DATEADD(DAY, -7, GETDATE())
    WHEN 5 THEN DATEADD(DAY, -30, GETDATE())
    WHEN 6 THEN '1900-01-01'
    ELSE '1900-01-01'
END;


------------------------------------------------------------
-- KULLANICININ SON OKUMA TARİHİ
-- SADECE READ-ONLY
------------------------------------------------------------
SELECT
    @LastReadDate = LastReadDate
FROM tmscrq.TMNotificationRead
WHERE KUserId = @KUserId;


IF @LastReadDate IS NULL
BEGIN
    SET @LastReadDate =
        CAST('1900-01-01' AS DATETIMEOFFSET);
END;


------------------------------------------------------------
-- BİLDİRİMLER
------------------------------------------------------------
SELECT
    X.*,


    ----------------------------------------------------------
    -- UI İÇİN OKUNABİLİR BAŞLIK
    ----------------------------------------------------------
    CASE X.Category

        WHEN 'PROCESS_CHANGE'
            THEN N'Süreç Güncellendi'

        WHEN 'STATUS_CHANGE'
            THEN N'Durum Güncellendi'

        WHEN 'DATE_CHANGE'
            THEN N'Termin Tarihi Güncellendi'

        WHEN 'RESERVATION_CREATED'
            THEN N'Rezervasyon Oluşturuldu'

        WHEN 'RESERVATION_REJECTED'
            THEN N'Rezervasyon Reddedildi'

        WHEN 'RESERVATION_CUSTOMER_DECLINED'
            THEN N'Müşteri Rezervasyondan Vazgeçti'

        WHEN 'RESERVATION_UPDATE'
            THEN N'Rezervasyon Güncellendi'

        WHEN 'DATE_PROPOSAL'
            THEN N'Termin Önerisi Oluşturuldu'

        WHEN 'SALE_COMPLETED'
            THEN N'Satış Gerçekleşti'

        ELSE X.Title

    END AS DisplayTitle,


    ----------------------------------------------------------
    -- UI İÇİN OKUNABİLİR MESAJ
    ----------------------------------------------------------
    CASE X.Category

        ------------------------------------------------------
        -- SÜREÇ
        ------------------------------------------------------
        WHEN 'PROCESS_CHANGE'
            THEN CONCAT(
                ISNULL(X.LeadCode, N'Talep'),
                N' numaralı talebin süreci ',
                ISNULL(X.Description, N'güncellendi'),
                N'.'
            )

        ------------------------------------------------------
        -- DURUM
        ------------------------------------------------------
        WHEN 'STATUS_CHANGE'
            THEN CONCAT(
                ISNULL(X.LeadCode, N'Talep'),
                N' numaralı talebin durumu güncellendi: ',
                ISNULL(X.Description, N'-'),
                N'.'
            )

        ------------------------------------------------------
        -- TERMİN TARİHİ
        ------------------------------------------------------
        WHEN 'DATE_CHANGE'
            THEN CONCAT(
                ISNULL(X.LeadCode, N'Talep'),
                N' numaralı talebin termin tarihi güncellendi: ',
                ISNULL(X.Description, N'-'),
                N'.'
            )

        ------------------------------------------------------
        -- REZERVASYON OLUŞTURULDU
        ------------------------------------------------------
        WHEN 'RESERVATION_CREATED'
            THEN CONCAT(
                ISNULL(X.LeadCode, N'Talep'),
                N' numaralı talep için rezervasyon oluşturuldu.'
            )

        ------------------------------------------------------
        -- REZERVASYON REDDEDİLDİ
        ------------------------------------------------------
        WHEN 'RESERVATION_REJECTED'
            THEN CONCAT(
                ISNULL(X.LeadCode, N'Talep'),
                N' numaralı talebe ait rezervasyon reddedildi.'
            )

        ------------------------------------------------------
        -- MÜŞTERİ VAZGEÇTİ
        ------------------------------------------------------
        WHEN 'RESERVATION_CUSTOMER_DECLINED'
            THEN CONCAT(
                ISNULL(X.LeadCode, N'Talep'),
                N' numaralı talepte müşteri rezervasyondan vazgeçti.'
            )

        ------------------------------------------------------
        -- REZERVASYON GÜNCELLENDİ
        ------------------------------------------------------
        WHEN 'RESERVATION_UPDATE'
            THEN CONCAT(
                ISNULL(X.LeadCode, N'Talep'),
                N' numaralı talebin rezervasyon bilgisi güncellendi.'
            )

        ------------------------------------------------------
        -- TERMİN ÖNERİSİ
        ------------------------------------------------------
        WHEN 'DATE_PROPOSAL'
            THEN CONCAT(
                ISNULL(X.LeadCode, N'Talep'),
                N' numaralı talep için termin önerisi oluşturuldu',
                CASE
                    WHEN NULLIF(
                        LTRIM(
                            RTRIM(
                                ISNULL(X.Description, '')
                            )
                        ),
                        ''
                    ) IS NOT NULL
                    THEN CONCAT(
                        N': ',
                        X.Description
                    )
                    ELSE N'.'
                END
            )

        ------------------------------------------------------
        -- SATIŞ
        ------------------------------------------------------
        WHEN 'SALE_COMPLETED'
            THEN X.Description

        ------------------------------------------------------
        -- DİĞER
        ------------------------------------------------------
        ELSE ISNULL(
            X.Description,
            N'-'
        )

    END AS DisplayMessage,


    ----------------------------------------------------------
    -- UI İÇİN OKUNDU BİLGİSİ
    ----------------------------------------------------------
    CASE
        WHEN X.ActionDate > @LastReadDate
            THEN CAST(0 AS BIT)
        ELSE CAST(1 AS BIT)
    END AS IsRead


FROM
(

    ----------------------------------------------------------
    -- 1. SÜREÇ HAREKETLERİ
    ----------------------------------------------------------
    SELECT
        lpl.Id AS NotificationId,

        l.Id AS LeadId,
        l.LeadCode,
        l.ReferencePersonID AS ReferenceID,

        CONCAT(
            ISNULL(ku.FirstName, ''),
            CASE
                WHEN NULLIF(ku.LastName, '') IS NOT NULL
                    THEN ' '
                ELSE ''
            END,
            ISNULL(ku.LastName, '')
        ) AS ActionUser,

        ts.StoreDesc AS StoreName,

        ISNULL
        (
            (
                SELECT STRING_AGG
                (
                    CASE kr.Name
                        WHEN 'TimesAdmin'
                            THEN 'Admin'

                        WHEN 'TimesUstYonetici'
                            THEN 'Üst Yönetici'

                        WHEN 'TimesYonetici'
                            THEN 'Yönetici'

                        WHEN 'TimesSatisPersoneli'
                            THEN 'Satış Personeli'

                        WHEN 'TimesMagazaMuduru'
                            THEN 'Mağaza Müdürü'

                        ELSE kr.Name
                    END,
                    ' '
                )

                FROM dbo.KUserRole kur

                INNER JOIN dbo.KRole kr
                    ON kr.Id = kur.KRole_Id

                WHERE kur.KUser_Id = ku.Id
            ),
            '-'
        ) AS RoleName,

        p.ProductName,
        p.Brand,
        p.CategoryName,

        LTRIM
        (
            RTRIM
            (
                CONCAT(
                    ISNULL(c.Name, ''),

                    CASE
                        WHEN NULLIF(c.LastName, '') IS NOT NULL
                            THEN ' '
                        ELSE ''
                    END,

                    ISNULL(c.LastName, '')
                )
            )
        ) AS CustomerName,

        'PROCESS' AS NotificationType,

        N'Süreç Değişti' AS Title,

        CASE
            WHEN NULLIF(
                LTRIM(RTRIM(lpl.Note)),
                ''
            ) IS NOT NULL

            THEN CONCAT(
                lp.Name,
                ' - ',
                lpl.Note
            )

            ELSE lp.Name

        END AS Description,

        lpl.CreatedAt AS ActionDate,

        'PROCESS_CHANGE' AS Category

    FROM tmscrq.TMLeadProcessLog lpl

    INNER JOIN tmscrq.TMLead l
        ON l.Id = lpl.LeadId

    INNER JOIN tmscrq.TMLeadProcess lp
        ON lp.Id = lpl.ProcessId

    LEFT JOIN dbo.KUser ku
        ON ku.Id = lpl.CreatedBy

    LEFT JOIN tmscrq.TMUser tu
        ON tu.KuserID = ku.Id

    LEFT JOIN tmscrq.TMStore ts
        ON ts.Id = tu.StoreID

    LEFT JOIN tmscrq.TMProduct p
        ON p.Id = l.ProductId

    LEFT JOIN tmscrq.TMCustomer c
        ON c.Id = l.CustomerId

    WHERE lpl.CreatedAt >= @StartDate


    UNION ALL


    ----------------------------------------------------------
    -- 2. LEAD ALAN GÜNCELLEMELERİ
    ----------------------------------------------------------
    SELECT
        lul.Id AS NotificationId,

        l.Id AS LeadId,
        l.LeadCode,
        l.ReferencePersonID AS ReferenceID,

        CONCAT(
            ISNULL(ku.FirstName, ''),
            CASE
                WHEN NULLIF(ku.LastName, '') IS NOT NULL
                    THEN ' '
                ELSE ''
            END,
            ISNULL(ku.LastName, '')
        ) AS ActionUser,

        ts.StoreDesc AS StoreName,

        ISNULL
        (
            (
                SELECT STRING_AGG
                (
                    CASE kr.Name
                        WHEN 'TimesAdmin'
                            THEN 'Admin'

                        WHEN 'TimesUstYonetici'
                            THEN 'Üst Yönetici'

                        WHEN 'TimesYonetici'
                            THEN 'Yönetici'

                        WHEN 'TimesSatisPersoneli'
                            THEN 'Satış Personeli'

                        WHEN 'TimesMagazaMuduru'
                            THEN 'Mağaza Müdürü'

                        ELSE kr.Name
                    END,
                    ' '
                )

                FROM dbo.KUserRole kur

                INNER JOIN dbo.KRole kr
                    ON kr.Id = kur.KRole_Id

                WHERE kur.KUser_Id = ku.Id
            ),
            '-'
        ) AS RoleName,

        p.ProductName,
        p.Brand,
        p.CategoryName,

        LTRIM
        (
            RTRIM
            (
                CONCAT(
                    ISNULL(c.Name, ''),

                    CASE
                        WHEN NULLIF(c.LastName, '') IS NOT NULL
                            THEN ' '
                        ELSE ''
                    END,

                    ISNULL(c.LastName, '')
                )
            )
        ) AS CustomerName,

        'UPDATE' AS NotificationType,

        CASE
            WHEN lul.ColumnName IN
            (
                N'Durum',
                'StatuId'
            )
            THEN N'Durum Güncellendi'

            WHEN lul.ColumnName IN
            (
                N'Termin Tarihi',
                'EstimatedDate'
            )
            THEN N'Termin Tarihi Güncellendi'

            ELSE CONCAT(
                N'Alan Güncellendi: ',
                lul.ColumnName
            )

        END AS Title,


        ------------------------------------------------------
        -- DESCRIPTION
        ------------------------------------------------------
        CASE

            --------------------------------------------------
            -- DURUM
            --------------------------------------------------
            WHEN lul.ColumnName IN
            (
                N'Durum',
                'StatuId'
            )
            THEN CONCAT(

                ISNULL(
                    (
                        SELECT TOP 1
                            ls.Name

                        FROM tmscrq.TMLeadStatu ls

                        WHERE
                               ls.Id =
                               TRY_CAST(
                                   lul.OldValue
                                   AS UNIQUEIDENTIFIER
                               )

                            OR ls.Code =
                               lul.OldValue
                    ),

                    ISNULL(
                        lul.OldValue,
                        '-'
                    )
                ),

                ' → ',

                ISNULL(
                    (
                        SELECT TOP 1
                            ls.Name

                        FROM tmscrq.TMLeadStatu ls

                        WHERE
                               ls.Id =
                               TRY_CAST(
                                   lul.NewValue
                                   AS UNIQUEIDENTIFIER
                               )

                            OR ls.Code =
                               lul.NewValue
                    ),

                    ISNULL(
                        lul.NewValue,
                        '-'
                    )
                )
            )


            --------------------------------------------------
            -- TERMİN TARİHİ
            --------------------------------------------------
            WHEN lul.ColumnName IN
            (
                N'Termin Tarihi',
                'EstimatedDate'
            )
            THEN CONCAT(
                ISNULL(
                    lul.OldValue,
                    '-'
                ),
                ' → ',
                ISNULL(
                    lul.NewValue,
                    '-'
                )
            )


            --------------------------------------------------
            -- DİĞER
            --------------------------------------------------
            ELSE CONCAT(
                ISNULL(
                    lul.OldValue,
                    '-'
                ),
                ' → ',
                ISNULL(
                    lul.NewValue,
                    '-'
                )
            )

        END AS Description,

        lul.UpdatedAt AS ActionDate,

        CASE
            WHEN lul.ColumnName IN
            (
                N'Durum',
                'StatuId'
            )
            THEN 'STATUS_CHANGE'

            WHEN lul.ColumnName IN
            (
                N'Termin Tarihi',
                'EstimatedDate'
            )
            THEN 'DATE_CHANGE'

            ELSE 'FIELD_UPDATE'

        END AS Category

    FROM tmscrq.TMLeadUpdateLog lul

    INNER JOIN tmscrq.TMLead l
        ON l.Id = lul.LeadId

    LEFT JOIN dbo.KUser ku
        ON ku.Id = lul.UpdatedBy

    LEFT JOIN tmscrq.TMUser tu
        ON tu.KuserID = ku.Id

    LEFT JOIN tmscrq.TMStore ts
        ON ts.Id = tu.StoreID

    LEFT JOIN tmscrq.TMProduct p
        ON p.Id = l.ProductId

    LEFT JOIN tmscrq.TMCustomer c
        ON c.Id = l.CustomerId

    WHERE lul.UpdatedAt >= @StartDate

      ------------------------------------------------------
      -- Süreç kendi ProcessLog kaynağından geliyor
      ------------------------------------------------------
      AND lul.ColumnName NOT IN
      (
          N'Süreç',
          'ProcessID'
      )

      ------------------------------------------------------
      -- Rezervasyon kendi ReservationLog kaynağından geliyor
      ------------------------------------------------------
      AND lul.ColumnName NOT IN
      (
          N'Rezerv Durumu'
      )


    UNION ALL


    ----------------------------------------------------------
    -- 3. REZERVASYON HAREKETLERİ
    ----------------------------------------------------------
    SELECT
        rl.Id AS NotificationId,

        l.Id AS LeadId,
        l.LeadCode,
        l.ReferencePersonID AS ReferenceID,

        CONCAT(
            ISNULL(ku.FirstName, ''),
            CASE
                WHEN NULLIF(ku.LastName, '') IS NOT NULL
                    THEN ' '
                ELSE ''
            END,
            ISNULL(ku.LastName, '')
        ) AS ActionUser,

        ts.StoreDesc AS StoreName,

        ISNULL
        (
            (
                SELECT STRING_AGG
                (
                    CASE kr.Name
                        WHEN 'TimesAdmin'
                            THEN 'Admin'

                        WHEN 'TimesUstYonetici'
                            THEN 'Üst Yönetici'

                        WHEN 'TimesYonetici'
                            THEN 'Yönetici'

                        WHEN 'TimesSatisPersoneli'
                            THEN 'Satış Personeli'

                        WHEN 'TimesMagazaMuduru'
                            THEN 'Mağaza Müdürü'

                        ELSE kr.Name
                    END,
                    ' '
                )

                FROM dbo.KUserRole kur

                INNER JOIN dbo.KRole kr
                    ON kr.Id = kur.KRole_Id

                WHERE kur.KUser_Id = ku.Id
            ),
            '-'
        ) AS RoleName,

        p.ProductName,
        p.Brand,
        p.CategoryName,

        LTRIM
        (
            RTRIM
            (
                CONCAT(
                    ISNULL(c.Name, ''),

                    CASE
                        WHEN NULLIF(c.LastName, '') IS NOT NULL
                            THEN ' '
                        ELSE ''
                    END,

                    ISNULL(c.LastName, '')
                )
            )
        ) AS CustomerName,

        'RESERVATION' AS NotificationType,

        CASE
            WHEN UPPER(
                LTRIM(
                    RTRIM(
                        rl.ActionType
                    )
                )
            ) = 'REJECTED'

            THEN N'Rezervasyon Reddedildi'


            WHEN UPPER(
                LTRIM(
                    RTRIM(
                        rl.ActionType
                    )
                )
            ) = 'CUSTOMER_DECLINED'

            THEN N'Müşteri Rezervasyondan Vazgeçti'


            WHEN rl.ActionType =
                 N'Rezerv Oluşturuldu'

            THEN N'Rezervasyon Oluşturuldu'


            ELSE ISNULL(
                rl.ActionType,
                N'Rezervasyon Güncellendi'
            )

        END AS Title,


        CASE
            WHEN NULLIF(
                LTRIM(
                    RTRIM(
                        rl.Note
                    )
                ),
                ''
            ) IS NOT NULL

            THEN CONCAT(
                ISNULL(
                    rl.OldValue,
                    '-'
                ),
                ' → ',
                ISNULL(
                    rl.NewValue,
                    '-'
                ),
                ' · ',
                rl.Note
            )

            ELSE CONCAT(
                ISNULL(
                    rl.OldValue,
                    '-'
                ),
                ' → ',
                ISNULL(
                    rl.NewValue,
                    '-'
                )
            )

        END AS Description,

        rl.CreatedAt AS ActionDate,


        CASE
            WHEN UPPER(
                LTRIM(
                    RTRIM(
                        rl.ActionType
                    )
                )
            ) = 'REJECTED'

            THEN 'RESERVATION_REJECTED'


            WHEN UPPER(
                LTRIM(
                    RTRIM(
                        rl.ActionType
                    )
                )
            ) = 'CUSTOMER_DECLINED'

            THEN 'RESERVATION_CUSTOMER_DECLINED'


            WHEN rl.ActionType =
                 N'Rezerv Oluşturuldu'

            THEN 'RESERVATION_CREATED'


            ELSE 'RESERVATION_UPDATE'

        END AS Category


    FROM tmscrq.TMLeadReservationLog rl

    INNER JOIN tmscrq.TMLeadReservation r
        ON r.Id = rl.ReservationId

    INNER JOIN tmscrq.TMLead l
        ON l.Id = r.LeadId

    LEFT JOIN dbo.KUser ku
        ON ku.Id = rl.CreatedBy

    LEFT JOIN tmscrq.TMUser tu
        ON tu.KuserID = ku.Id

    LEFT JOIN tmscrq.TMStore ts
        ON ts.Id = tu.StoreID

    LEFT JOIN tmscrq.TMProduct p
        ON p.Id = l.ProductId

    LEFT JOIN tmscrq.TMCustomer c
        ON c.Id = l.CustomerId

    WHERE rl.CreatedAt >= @StartDate


    UNION ALL


    ----------------------------------------------------------
    -- 4. TERMİN ÖNERİLERİ
    ----------------------------------------------------------
    SELECT
        pl.Id AS NotificationId,

        l.Id AS LeadId,
        l.LeadCode,
        l.ReferencePersonID AS ReferenceID,

        CONCAT(
            ISNULL(ku.FirstName, ''),
            CASE
                WHEN NULLIF(ku.LastName, '') IS NOT NULL
                    THEN ' '
                ELSE ''
            END,
            ISNULL(ku.LastName, '')
        ) AS ActionUser,

        ts.StoreDesc AS StoreName,

        ISNULL
        (
            (
                SELECT STRING_AGG
                (
                    CASE kr.Name
                        WHEN 'TimesAdmin'
                            THEN 'Admin'

                        WHEN 'TimesUstYonetici'
                            THEN 'Üst Yönetici'

                        WHEN 'TimesYonetici'
                            THEN 'Yönetici'

                        WHEN 'TimesSatisPersoneli'
                            THEN 'Satış Personeli'

                        WHEN 'TimesMagazaMuduru'
                            THEN 'Mağaza Müdürü'

                        ELSE kr.Name
                    END,
                    ' '
                )

                FROM dbo.KUserRole kur

                INNER JOIN dbo.KRole kr
                    ON kr.Id = kur.KRole_Id

                WHERE kur.KUser_Id = ku.Id
            ),
            '-'
        ) AS RoleName,

        p.ProductName,
        p.Brand,
        p.CategoryName,

        LTRIM
        (
            RTRIM
            (
                CONCAT(
                    ISNULL(c.Name, ''),

                    CASE
                        WHEN NULLIF(c.LastName, '') IS NOT NULL
                            THEN ' '
                        ELSE ''
                    END,

                    ISNULL(c.LastName, '')
                )
            )
        ) AS CustomerName,

        'DATE_PROPOSAL'
            AS NotificationType,

        CASE
            WHEN UPPER(
                LTRIM(
                    RTRIM(
                        pl.ActionType
                    )
                )
            ) = 'CREATE'

            THEN N'Termin Önerisi Oluşturuldu'

            ELSE N'Termin Önerisi Güncellendi'

        END AS Title,


        CASE
            WHEN NULLIF(
                LTRIM(
                    RTRIM(
                        pl.Note
                    )
                ),
                ''
            ) IS NOT NULL

            THEN CONCAT(
                ISNULL(
                    pl.NewValue,
                    '-'
                ),
                ' · ',
                pl.Note
            )

            ELSE ISNULL(
                pl.NewValue,
                '-'
            )

        END AS Description,

        pl.CreatedAt AS ActionDate,

        'DATE_PROPOSAL' AS Category


    FROM tmscrq.TMLeadEstimatedDateProposalLog pl

    INNER JOIN tmscrq.TMLeadEstimatedDateProposal proposal
        ON proposal.Id = pl.ProposalId

    INNER JOIN tmscrq.TMLead l
        ON l.Id = proposal.LeadId

    LEFT JOIN dbo.KUser ku
        ON ku.Id = pl.CreatedBy

    LEFT JOIN tmscrq.TMUser tu
        ON tu.KuserID = ku.Id

    LEFT JOIN tmscrq.TMStore ts
        ON ts.Id = tu.StoreID

    LEFT JOIN tmscrq.TMProduct p
        ON p.Id = l.ProductId

    LEFT JOIN tmscrq.TMCustomer c
        ON c.Id = l.CustomerId

    WHERE pl.CreatedAt >= @StartDate


    UNION ALL


    ----------------------------------------------------------
    -- 5. TAMAMLANAN SATIŞLAR
    ----------------------------------------------------------
    SELECT
        sd.Id AS NotificationId,

        l.Id AS LeadId,
        l.LeadCode,
        l.ReferencePersonID AS ReferenceID,

        CONCAT(
            ISNULL(ku.FirstName, ''),
            CASE
                WHEN NULLIF(ku.LastName, '') IS NOT NULL
                    THEN ' '
                ELSE ''
            END,
            ISNULL(ku.LastName, '')
        ) AS ActionUser,

        ts.StoreDesc AS StoreName,

        ISNULL
        (
            (
                SELECT STRING_AGG
                (
                    CASE kr.Name
                        WHEN 'TimesAdmin'
                            THEN 'Admin'

                        WHEN 'TimesUstYonetici'
                            THEN 'Üst Yönetici'

                        WHEN 'TimesYonetici'
                            THEN 'Yönetici'

                        WHEN 'TimesSatisPersoneli'
                            THEN 'Satış Personeli'

                        WHEN 'TimesMagazaMuduru'
                            THEN 'Mağaza Müdürü'

                        ELSE kr.Name
                    END,
                    ' '
                )

                FROM dbo.KUserRole kur

                INNER JOIN dbo.KRole kr
                    ON kr.Id = kur.KRole_Id

                WHERE kur.KUser_Id = ku.Id
            ),
            '-'
        ) AS RoleName,

        p.ProductName,
        p.Brand,
        p.CategoryName,

        LTRIM
        (
            RTRIM
            (
                CONCAT(
                    ISNULL(c.Name, ''),

                    CASE
                        WHEN NULLIF(c.LastName, '') IS NOT NULL
                            THEN ' '
                        ELSE ''
                    END,

                    ISNULL(c.LastName, '')
                )
            )
        ) AS CustomerName,

        'SALE' AS NotificationType,

        N'Satış Gerçekleşti' AS Title,

        CONCAT(
            N'Talep ',
            ISNULL(
                l.LeadCode,
                '-'
            ),
            N' için satış tamamlandı. Fatura No: ',
            ISNULL(
                sd.InvoiceNumber,
                '-'
            )
        ) AS Description,

        COALESCE(
            sd.InvoiceDate,
            sd.CreatedAt
        ) AS ActionDate,

        'SALE_COMPLETED'
            AS Category


    FROM tmscrq.TMSalesLeadDraft sd

    INNER JOIN tmscrq.TMLead l
        ON l.Id = sd.LeadId

    LEFT JOIN dbo.KUser ku
        ON ku.Id = sd.KUserID

    LEFT JOIN tmscrq.TMUser tu
        ON tu.KuserID = ku.Id

    LEFT JOIN tmscrq.TMStore ts
        ON ts.Id = tu.StoreID

    LEFT JOIN tmscrq.TMProduct p
        ON p.Id = l.ProductId

    LEFT JOIN tmscrq.TMCustomer c
        ON c.Id = l.CustomerId

    WHERE sd.IsCompleted = 1

      AND NULLIF(
            LTRIM(
                RTRIM(
                    sd.InvoiceNumber
                )
            ),
            ''
          ) IS NOT NULL

      AND COALESCE(
            sd.InvoiceDate,
            sd.CreatedAt
          ) >= @StartDate

) X


------------------------------------------------------------
-- BİLDİRİM TİPİ FİLTRESİ
------------------------------------------------------------
WHERE
(
       NULLIF(
           LTRIM(
               RTRIM(
                   @NotificationTypeFilter
               )
           ),
           ''
       ) IS NULL

    OR @NotificationTypeFilter = 'ALL'

    OR X.NotificationType =
       @NotificationTypeFilter
)


------------------------------------------------------------
-- TÜMÜ / OKUNMAMIŞ FİLTRESİ
------------------------------------------------------------
AND
(
       ISNULL(
           @ShowUnreadOnly,
           0
       ) = 0

    OR X.ActionDate > @LastReadDate
)


------------------------------------------------------------
-- EN YENİ EN ÜSTTE
------------------------------------------------------------
ORDER BY X.ActionDate DESC;", new string[] { "NotificationId", "LeadId", "LeadCode", "ReferenceID", "ActionUser", "StoreName", "RoleName", "ProductName", "Brand", "CategoryName", "CustomerName", "NotificationType", "Title", "Description", "ActionDate", "Category", "DisplayTitle", "DisplayMessage", "IsRead" }, prms_NotifListStatuChange_0.ToArray());
            ;

            var prms_TM_CountRefresh_1 = new List<kSqlParameter>();
            prms_TM_CountRefresh_1.Add(new kSqlParameter() { Name = "KUserId", Value = Kuika.Common.KContext.CurrentUser?.Id });
            using var auditTM_CountRefresh_1 = ActionAuditScope.Begin("87f1ffca-3411-eb70-8b77-13e109ed26d1", "TM_CountRefresh", applicationName: "wbTimesCRM", screenOrEndpointName: "NotificationManager");
            result.TM_CountRefresh = KPersister.Save(KContext.GetConnectionString(), @"IF EXISTS (
    SELECT 1 
    FROM tmscrq.TMNotificationRead
    WHERE KUserId = @KUserId
)
BEGIN
    UPDATE tmscrq.TMNotificationRead
    SET LastReadDate = GETDATE()
    WHERE KUserId = @KUserId
END
ELSE
BEGIN
    INSERT INTO tmscrq.TMNotificationRead
    (
        Id,
        KUserId,
        LastReadDate
    )
    VALUES
    (
        NEWID(),
        @KUserId,
        GETDATE()
    )
END", prms_TM_CountRefresh_1.ToArray());
            ;

            var prms_TMBadgerCount_2 = new List<kSqlParameter>();
            prms_TMBadgerCount_2.Add(new kSqlParameter() { Name = "KUserId", Value = Kuika.Common.KContext.CurrentUser?.Id });
            using var auditTMBadgerCount_2 = ActionAuditScope.Begin("f5ad884b-f582-b9c8-35a0-687ee6bf0b7c", "TMBadgerCount", applicationName: "wbTimesCRM", screenOrEndpointName: "NotificationManager");
            result.TMBadgerCount = KPersister.Fetch(KContext.GetConnectionString(), @"/*
DECLARE @LastReadDate DATETIME

SELECT @LastReadDate = LastReadDate
FROM tmscrq.TMNotificationRead
WHERE KUserId = @KUserId

IF @LastReadDate IS NULL
    SET @LastReadDate = '1900-01-01'

SELECT COUNT(*) AS NotificationCount
FROM
(
    SELECT lpl.Id
    FROM tmscrq.TMLeadProcessLog lpl
    INNER JOIN tmscrq.TMLeadProcess lp 
        ON lp.Id = lpl.ProcessId
    WHERE lp.Code IN ('2TAKIP','TAKIP_EDILIYOR')
    AND lpl.CreatedAt > @LastReadDate

    UNION ALL

    SELECT lul.Id
    FROM tmscrq.TMLeadUpdateLog lul
    WHERE lul.UpdatedAt > @LastReadDate

) X;
*/


SET NOCOUNT ON;

DECLARE @LastReadDate DATETIMEOFFSET;

SELECT
    @LastReadDate = LastReadDate
FROM tmscrq.TMNotificationRead
WHERE KUserId = @KUserId;

IF @LastReadDate IS NULL
BEGIN
    SET @LastReadDate = CAST('1900-01-01' AS DATETIMEOFFSET);
END;


SELECT
    COUNT(*) AS NotificationCount
FROM
(
    ----------------------------------------------------------
    -- 1. SÜREÇ HAREKETLERİ
    -- NotifListStatuChange ile aynı kaynak
    ----------------------------------------------------------
    SELECT
        lpl.Id AS NotificationId

    FROM tmscrq.TMLeadProcessLog lpl

    INNER JOIN tmscrq.TMLead l
        ON l.Id = lpl.LeadId

    WHERE lpl.CreatedAt > @LastReadDate


    UNION ALL


    ----------------------------------------------------------
    -- 2. LEAD ALAN GÜNCELLEMELERİ
    --
    -- Süreç:
    -- TMLeadProcessLog tarafından sayılıyor.
    --
    -- Rezerv Durumu:
    -- TMLeadReservationLog tarafından sayılıyor.
    ----------------------------------------------------------
    SELECT
        lul.Id AS NotificationId

    FROM tmscrq.TMLeadUpdateLog lul

    INNER JOIN tmscrq.TMLead l
        ON l.Id = lul.LeadId

    WHERE lul.UpdatedAt > @LastReadDate

      AND lul.ColumnName NOT IN
      (
          N'Süreç',
          'ProcessID'
      )

      AND lul.ColumnName NOT IN
      (
          N'Rezerv Durumu'
      )


    UNION ALL


    ----------------------------------------------------------
    -- 3. REZERVASYON HAREKETLERİ
    ----------------------------------------------------------
    SELECT
        rl.Id AS NotificationId

    FROM tmscrq.TMLeadReservationLog rl

    INNER JOIN tmscrq.TMLeadReservation r
        ON r.Id = rl.ReservationId

    INNER JOIN tmscrq.TMLead l
        ON l.Id = r.LeadId

    WHERE rl.CreatedAt > @LastReadDate


    UNION ALL


    ----------------------------------------------------------
    -- 4. TERMİN / TAHMİNİ TARİH ÖNERİLERİ
    ----------------------------------------------------------
    SELECT
        pl.Id AS NotificationId

    FROM tmscrq.TMLeadEstimatedDateProposalLog pl

    INNER JOIN tmscrq.TMLeadEstimatedDateProposal proposal
        ON proposal.Id = pl.ProposalId

    INNER JOIN tmscrq.TMLead l
        ON l.Id = proposal.LeadId

    WHERE pl.CreatedAt > @LastReadDate


    UNION ALL


    ----------------------------------------------------------
    -- 5. TAMAMLANAN SATIŞLAR
    --
    -- Sadece gerçekten tamamlanmış ve
    -- fatura numarası oluşmuş satışlar.
    ----------------------------------------------------------
    SELECT
        sd.Id AS NotificationId

    FROM tmscrq.TMSalesLeadDraft sd

    INNER JOIN tmscrq.TMLead l
        ON l.Id = sd.LeadId

    WHERE sd.IsCompleted = 1

      AND NULLIF(
            LTRIM(RTRIM(sd.InvoiceNumber)),
            ''
          ) IS NOT NULL

      AND COALESCE(
            sd.InvoiceDate,
            sd.CreatedAt
          ) > @LastReadDate

) X;

", new string[] { "NotificationCount" }, prms_TMBadgerCount_2.ToArray());
            ;


            return Ok(result);
        }


        [HttpPost, Route("NotificationManagerComponent_52182_onChange")]
        public IActionResult NotificationManagerComponent_52182_onChange(NotificationManagerComponent_52182_onChange_Request request)
        {

            KProviderManager.Authorization.IsAuthorizedForRoles(appId, appName, screenId, screenName, new List<string> { $"4da1f213-c8e4-0b50-5c84-02fd13f1a622", "TimesUstYonetici" });

            var result = new NotificationManagerComponent_52182_onChange_Response();

            var prms_NotifListStatuChange_0 = new List<kSqlParameter>();
            prms_NotifListStatuChange_0.Add(new kSqlParameter() { Name = "DateFilter", Value = request.DateFilter_0 });
            prms_NotifListStatuChange_0.Add(new kSqlParameter() { Name = "KUserId", Value = Kuika.Common.KContext.CurrentUser?.Id });
            prms_NotifListStatuChange_0.Add(new kSqlParameter() { Name = "NotificationTypeFilter", Value = request.NotificationTypeFilter_0 });
            prms_NotifListStatuChange_0.Add(new kSqlParameter() { Name = "ShowUnreadOnly", Value = "False".ConvertToType<Boolean>() });
            using var auditNotifListStatuChange_0 = ActionAuditScope.Begin("cdc7796e-6ed2-3eda-bab7-4e98e6f53fb0", "NotifListStatuChange", applicationName: "wbTimesCRM", screenOrEndpointName: "NotificationManager");
            result.NotifListStatuChange = KPersister.Fetch(KContext.GetConnectionString(), @"/*

DECLARE @StartDate DATETIME;

SET @StartDate =
CASE @DateFilter
    WHEN 1 THEN DATEADD(HOUR,-1,GETDATE())     
    WHEN 2 THEN DATEADD(HOUR,-6,GETDATE())     
    WHEN 3 THEN DATEADD(HOUR,-24,GETDATE())    
    WHEN 4 THEN DATEADD(DAY,-7,GETDATE())      
    WHEN 5 THEN DATEADD(DAY,-30,GETDATE())     
    WHEN 6 THEN '1900-01-01'                   
    ELSE '1900-01-01'
END;

------------------------------------------------------

SELECT *
FROM
(

    --------------------------------------------------
    -- 🔵 PROCESS LOG
    --------------------------------------------------
    SELECT
        NEWID() AS NotificationId,

        l.Id AS LeadId,
        l.LeadCode,
        l.ReferenceID,

        ku.FirstName + ' ' + ku.LastName AS ActionUser,
        ts.StoreDesc AS StoreName,

        STRING_AGG(
            CASE r.Name
                WHEN 'TimesAdmin' THEN 'Admin'
                WHEN 'TimesUstYonetici' THEN 'Üst Yönetici'
                WHEN 'TimesYonetici' THEN 'Yönetici'
                WHEN 'TimesSatisPersoneli' THEN 'Satış Personeli'
                WHEN 'TimesMagazaMuduru' THEN 'Mağaza Müdürü'
                ELSE r.Name
            END,' '
        ) AS RoleName,

        p.ProductName,
        p.Brand,
        p.CategoryName,

        c.Name + ' ' + c.LastName AS CustomerName,

        'PROCESS' AS NotificationType,

        lp.Name AS Title,
        lpl.Note AS Description,

        lpl.CreatedAt AS ActionDate,

        'ProcessChange' AS Category

    FROM tmscrq.TMLeadProcessLog lpl

    INNER JOIN tmscrq.TMLead l 
        ON l.Id = lpl.LeadId

    INNER JOIN tmscrq.TMLeadProcess lp 
        ON lp.Id = lpl.ProcessId

    INNER JOIN dbo.KUser ku 
        ON ku.Id = lpl.CreatedBy

    LEFT JOIN tmscrq.TMUser tu 
        ON tu.KuserID = ku.Id

    LEFT JOIN tmscrq.TMStore ts 
        ON ts.Id = tu.StoreID

    LEFT JOIN dbo.KUserRole ur 
        ON ur.KUser_Id = ku.Id

    LEFT JOIN dbo.KRole r 
        ON r.Id = ur.KRole_Id

    LEFT JOIN tmscrq.TMProduct p 
        ON p.Id = l.ProductId

    LEFT JOIN tmscrq.TMCustomer c 
        ON c.Id = l.CustomerId

    WHERE lpl.CreatedAt >= @StartDate

    GROUP BY
        l.Id,
        l.LeadCode,
        l.ReferenceID,
        ku.FirstName,
        ku.LastName,
        ts.StoreDesc,
        p.ProductName,
        p.Brand,
        p.CategoryName,
        c.Name,
        c.LastName,
        lp.Name,
        lpl.Note,
        lpl.CreatedAt

    UNION ALL

    --------------------------------------------------
    -- 🟢 UPDATE LOG
    --------------------------------------------------
    SELECT
        NEWID() AS NotificationId,

        l.Id AS LeadId,
        l.LeadCode,
        l.ReferenceID,

        ku.FirstName + ' ' + ku.LastName AS ActionUser,
        ts.StoreDesc AS StoreName,

        STRING_AGG(
            CASE r.Name
                WHEN 'TimesAdmin' THEN 'Admin'
                WHEN 'TimesUstYonetici' THEN 'Üst Yönetici'
                WHEN 'TimesYonetici' THEN 'Yönetici'
                WHEN 'TimesSatisPersoneli' THEN 'Satış Personeli'
                WHEN 'TimesMagazaMuduru' THEN 'Mağaza Müdürü'
                ELSE r.Name
            END,' '
        ) AS RoleName,

        p.ProductName,
        p.Brand,
        p.CategoryName,

        c.Name + ' ' + c.LastName AS CustomerName,

        'UPDATE' AS NotificationType,

        --------------------------------------------------
        -- TITLE
        --------------------------------------------------
        CASE
            WHEN lul.ColumnName = 'StatuId' THEN 'Alan Güncellendi: Statu'
            WHEN lul.ColumnName = 'ProcessID' THEN 'Alan Güncellendi: Süreç'
            WHEN lul.ColumnName = 'NextStep' THEN 'Alan Güncellendi: Sonraki Adım'
            WHEN lul.ColumnName = 'ContactResourceId' THEN 'Alan Güncellendi: İletişim Kaynağı'
            WHEN lul.ColumnName = 'SalesPersonKUserId' THEN 'Alan Güncellendi: Satış Personeli'
            WHEN lul.ColumnName = 'StoreId' THEN 'Alan Güncellendi: Mağaza'
            ELSE CONCAT('Alan Güncellendi: ', lul.ColumnName)
        END AS Title,

        --------------------------------------------------
        -- DESCRIPTION
        --------------------------------------------------
        CASE 

            ------------------------------------------------
            -- STATU
            ------------------------------------------------
            WHEN lul.ColumnName = 'StatuId' THEN
                CONCAT(
                    ISNULL((
                        SELECT TOP 1 Name
                        FROM tmscrq.TMLeadStatu
                        WHERE 
                            Id = TRY_CAST(lul.OldValue AS UNIQUEIDENTIFIER)
                            OR Code = lul.OldValue
                    ), '-'),
                    ' → ',
                    ISNULL((
                        SELECT TOP 1 Name
                        FROM tmscrq.TMLeadStatu
                        WHERE 
                            Id = TRY_CAST(lul.NewValue AS UNIQUEIDENTIFIER)
                            OR Code = lul.NewValue
                    ), '-')
                )

            ------------------------------------------------
            -- İLETİŞİM KAYNAĞI
            ------------------------------------------------
            WHEN lul.ColumnName = 'ContactResourceId' THEN
                CONCAT(
                    ISNULL((
                        SELECT TOP 1 ContactResourceName
                        FROM tmscrq.TMContactResource
                        WHERE 
                            Id = TRY_CAST(lul.OldValue AS UNIQUEIDENTIFIER)
                            OR ContactResourceCode = lul.OldValue
                    ), '-'),
                    ' → ',
                    ISNULL((
                        SELECT TOP 1 ContactResourceName
                        FROM tmscrq.TMContactResource
                        WHERE 
                            Id = TRY_CAST(lul.NewValue AS UNIQUEIDENTIFIER)
                            OR ContactResourceCode = lul.NewValue
                    ), '-')
                )

            ------------------------------------------------
            -- SATIŞ PERSONELİ
            ------------------------------------------------
            WHEN lul.ColumnName = 'SalesPersonKUserId' THEN
                CONCAT(
                    ISNULL((
                        SELECT TOP 1 
                            FirstName + ' ' + LastName
                        FROM dbo.KUser
                        WHERE 
                            Id = TRY_CAST(lul.OldValue AS UNIQUEIDENTIFIER)
                    ), '-'),
                    ' → ',
                    ISNULL((
                        SELECT TOP 1 
                            FirstName + ' ' + LastName
                        FROM dbo.KUser
                        WHERE 
                            Id = TRY_CAST(lul.NewValue AS UNIQUEIDENTIFIER)
                    ), '-')
                )

            ------------------------------------------------
            -- MAĞAZA
            ------------------------------------------------
            WHEN lul.ColumnName = 'StoreId' THEN
                CONCAT(
                    ISNULL((
                        SELECT TOP 1 StoreDesc
                        FROM tmscrq.TMStore
                        WHERE 
                            Id = TRY_CAST(lul.OldValue AS UNIQUEIDENTIFIER)
                    ), '-'),
                    ' → ',
                    ISNULL((
                        SELECT TOP 1 StoreDesc
                        FROM tmscrq.TMStore
                        WHERE 
                            Id = TRY_CAST(lul.NewValue AS UNIQUEIDENTIFIER)
                    ), '-')
                )

            ------------------------------------------------
            -- PROCESS
            ------------------------------------------------
            WHEN lul.ColumnName = 'ProcessID' THEN
                CONCAT(
                    ISNULL((
                        SELECT TOP 1 Name
                        FROM tmscrq.TMLeadProcess
                        WHERE 
                            Id = TRY_CAST(lul.OldValue AS UNIQUEIDENTIFIER)
                            OR Code = lul.OldValue
                    ), '-'),
                    ' → ',
                    ISNULL((
                        SELECT TOP 1 Name
                        FROM tmscrq.TMLeadProcess
                        WHERE 
                            Id = TRY_CAST(lul.NewValue AS UNIQUEIDENTIFIER)
                            OR Code = lul.NewValue
                    ), '-')
                )

            ------------------------------------------------
            -- NEXT STEP
            ------------------------------------------------
            WHEN lul.ColumnName = 'NextStep' THEN
                CONCAT(
                    ISNULL((
                        SELECT TOP 1 Name
                        FROM tmscrq.TMLeadNextStep
                        WHERE Code = lul.OldValue
                    ), '-'),
                    ' → ',
                    ISNULL((
                        SELECT TOP 1 Name
                        FROM tmscrq.TMLeadNextStep
                        WHERE Code = lul.NewValue
                    ), '-')
                )

            ------------------------------------------------
            -- DEFAULT
            ------------------------------------------------
            ELSE
                CONCAT(
                    ISNULL(lul.OldValue,'-'),
                    ' → ',
                    ISNULL(lul.NewValue,'-')
                )

        END AS Description,

        lul.UpdatedAt AS ActionDate,

        --------------------------------------------------
        -- CATEGORY
        --------------------------------------------------
        CASE 
            WHEN lul.ColumnName = 'StatuId' THEN 'StatusChange'
            WHEN lul.ColumnName = 'EstimatedDate' THEN 'DateChange'
            WHEN lul.ColumnName = 'ContactResourceId' THEN 'ContactChange'
            WHEN lul.ColumnName = 'SalesPersonKUserId' THEN 'SalesPersonChange'
            WHEN lul.ColumnName = 'StoreId' THEN 'StoreChange'
            WHEN lul.ColumnName = 'ProcessID' THEN 'ProcessChange'
            WHEN lul.ColumnName = 'NextStep' THEN 'NextStepChange'
            ELSE 'FieldUpdate'
        END AS Category

    FROM tmscrq.TMLeadUpdateLog lul

    INNER JOIN tmscrq.TMLead l 
        ON l.Id = lul.LeadId

    INNER JOIN dbo.KUser ku 
        ON ku.Id = lul.UpdatedBy

    LEFT JOIN tmscrq.TMUser tu 
        ON tu.KuserID = ku.Id

    LEFT JOIN tmscrq.TMStore ts 
        ON ts.Id = tu.StoreID

    LEFT JOIN dbo.KUserRole ur 
        ON ur.KUser_Id = ku.Id

    LEFT JOIN dbo.KRole r 
        ON r.Id = ur.KRole_Id

    LEFT JOIN tmscrq.TMProduct p 
        ON p.Id = l.ProductId

    LEFT JOIN tmscrq.TMCustomer c 
        ON c.Id = l.CustomerId

    WHERE lul.UpdatedAt >= @StartDate

    GROUP BY
        l.Id,
        l.LeadCode,
        l.ReferenceID,
        ku.FirstName,
        ku.LastName,
        ts.StoreDesc,
        p.ProductName,
        p.Brand,
        p.CategoryName,
        c.Name,
        c.LastName,
        lul.ColumnName,
        lul.OldValue,
        lul.NewValue,
        lul.UpdatedAt

) X

ORDER BY ActionDate DESC;

*/

SET NOCOUNT ON;

DECLARE @StartDate DATETIME;
DECLARE @LastReadDate DATETIMEOFFSET;


------------------------------------------------------------
-- TARİH FİLTRESİ
------------------------------------------------------------
SET @StartDate =
CASE @DateFilter
    WHEN 1 THEN DATEADD(HOUR, -1, GETDATE())
    WHEN 2 THEN DATEADD(HOUR, -6, GETDATE())
    WHEN 3 THEN DATEADD(HOUR, -24, GETDATE())
    WHEN 4 THEN DATEADD(DAY, -7, GETDATE())
    WHEN 5 THEN DATEADD(DAY, -30, GETDATE())
    WHEN 6 THEN '1900-01-01'
    ELSE '1900-01-01'
END;


------------------------------------------------------------
-- KULLANICININ SON OKUMA TARİHİ
-- SADECE READ-ONLY
------------------------------------------------------------
SELECT
    @LastReadDate = LastReadDate
FROM tmscrq.TMNotificationRead
WHERE KUserId = @KUserId;


IF @LastReadDate IS NULL
BEGIN
    SET @LastReadDate =
        CAST('1900-01-01' AS DATETIMEOFFSET);
END;


------------------------------------------------------------
-- BİLDİRİMLER
------------------------------------------------------------
SELECT
    X.*,


    ----------------------------------------------------------
    -- UI İÇİN OKUNABİLİR BAŞLIK
    ----------------------------------------------------------
    CASE X.Category

        WHEN 'PROCESS_CHANGE'
            THEN N'Süreç Güncellendi'

        WHEN 'STATUS_CHANGE'
            THEN N'Durum Güncellendi'

        WHEN 'DATE_CHANGE'
            THEN N'Termin Tarihi Güncellendi'

        WHEN 'RESERVATION_CREATED'
            THEN N'Rezervasyon Oluşturuldu'

        WHEN 'RESERVATION_REJECTED'
            THEN N'Rezervasyon Reddedildi'

        WHEN 'RESERVATION_CUSTOMER_DECLINED'
            THEN N'Müşteri Rezervasyondan Vazgeçti'

        WHEN 'RESERVATION_UPDATE'
            THEN N'Rezervasyon Güncellendi'

        WHEN 'DATE_PROPOSAL'
            THEN N'Termin Önerisi Oluşturuldu'

        WHEN 'SALE_COMPLETED'
            THEN N'Satış Gerçekleşti'

        ELSE X.Title

    END AS DisplayTitle,


    ----------------------------------------------------------
    -- UI İÇİN OKUNABİLİR MESAJ
    ----------------------------------------------------------
    CASE X.Category

        ------------------------------------------------------
        -- SÜREÇ
        ------------------------------------------------------
        WHEN 'PROCESS_CHANGE'
            THEN CONCAT(
                ISNULL(X.LeadCode, N'Talep'),
                N' numaralı talebin süreci ',
                ISNULL(X.Description, N'güncellendi'),
                N'.'
            )

        ------------------------------------------------------
        -- DURUM
        ------------------------------------------------------
        WHEN 'STATUS_CHANGE'
            THEN CONCAT(
                ISNULL(X.LeadCode, N'Talep'),
                N' numaralı talebin durumu güncellendi: ',
                ISNULL(X.Description, N'-'),
                N'.'
            )

        ------------------------------------------------------
        -- TERMİN TARİHİ
        ------------------------------------------------------
        WHEN 'DATE_CHANGE'
            THEN CONCAT(
                ISNULL(X.LeadCode, N'Talep'),
                N' numaralı talebin termin tarihi güncellendi: ',
                ISNULL(X.Description, N'-'),
                N'.'
            )

        ------------------------------------------------------
        -- REZERVASYON OLUŞTURULDU
        ------------------------------------------------------
        WHEN 'RESERVATION_CREATED'
            THEN CONCAT(
                ISNULL(X.LeadCode, N'Talep'),
                N' numaralı talep için rezervasyon oluşturuldu.'
            )

        ------------------------------------------------------
        -- REZERVASYON REDDEDİLDİ
        ------------------------------------------------------
        WHEN 'RESERVATION_REJECTED'
            THEN CONCAT(
                ISNULL(X.LeadCode, N'Talep'),
                N' numaralı talebe ait rezervasyon reddedildi.'
            )

        ------------------------------------------------------
        -- MÜŞTERİ VAZGEÇTİ
        ------------------------------------------------------
        WHEN 'RESERVATION_CUSTOMER_DECLINED'
            THEN CONCAT(
                ISNULL(X.LeadCode, N'Talep'),
                N' numaralı talepte müşteri rezervasyondan vazgeçti.'
            )

        ------------------------------------------------------
        -- REZERVASYON GÜNCELLENDİ
        ------------------------------------------------------
        WHEN 'RESERVATION_UPDATE'
            THEN CONCAT(
                ISNULL(X.LeadCode, N'Talep'),
                N' numaralı talebin rezervasyon bilgisi güncellendi.'
            )

        ------------------------------------------------------
        -- TERMİN ÖNERİSİ
        ------------------------------------------------------
        WHEN 'DATE_PROPOSAL'
            THEN CONCAT(
                ISNULL(X.LeadCode, N'Talep'),
                N' numaralı talep için termin önerisi oluşturuldu',
                CASE
                    WHEN NULLIF(
                        LTRIM(
                            RTRIM(
                                ISNULL(X.Description, '')
                            )
                        ),
                        ''
                    ) IS NOT NULL
                    THEN CONCAT(
                        N': ',
                        X.Description
                    )
                    ELSE N'.'
                END
            )

        ------------------------------------------------------
        -- SATIŞ
        ------------------------------------------------------
        WHEN 'SALE_COMPLETED'
            THEN X.Description

        ------------------------------------------------------
        -- DİĞER
        ------------------------------------------------------
        ELSE ISNULL(
            X.Description,
            N'-'
        )

    END AS DisplayMessage,


    ----------------------------------------------------------
    -- UI İÇİN OKUNDU BİLGİSİ
    ----------------------------------------------------------
    CASE
        WHEN X.ActionDate > @LastReadDate
            THEN CAST(0 AS BIT)
        ELSE CAST(1 AS BIT)
    END AS IsRead


FROM
(

    ----------------------------------------------------------
    -- 1. SÜREÇ HAREKETLERİ
    ----------------------------------------------------------
    SELECT
        lpl.Id AS NotificationId,

        l.Id AS LeadId,
        l.LeadCode,
        l.ReferencePersonID AS ReferenceID,

        CONCAT(
            ISNULL(ku.FirstName, ''),
            CASE
                WHEN NULLIF(ku.LastName, '') IS NOT NULL
                    THEN ' '
                ELSE ''
            END,
            ISNULL(ku.LastName, '')
        ) AS ActionUser,

        ts.StoreDesc AS StoreName,

        ISNULL
        (
            (
                SELECT STRING_AGG
                (
                    CASE kr.Name
                        WHEN 'TimesAdmin'
                            THEN 'Admin'

                        WHEN 'TimesUstYonetici'
                            THEN 'Üst Yönetici'

                        WHEN 'TimesYonetici'
                            THEN 'Yönetici'

                        WHEN 'TimesSatisPersoneli'
                            THEN 'Satış Personeli'

                        WHEN 'TimesMagazaMuduru'
                            THEN 'Mağaza Müdürü'

                        ELSE kr.Name
                    END,
                    ' '
                )

                FROM dbo.KUserRole kur

                INNER JOIN dbo.KRole kr
                    ON kr.Id = kur.KRole_Id

                WHERE kur.KUser_Id = ku.Id
            ),
            '-'
        ) AS RoleName,

        p.ProductName,
        p.Brand,
        p.CategoryName,

        LTRIM
        (
            RTRIM
            (
                CONCAT(
                    ISNULL(c.Name, ''),

                    CASE
                        WHEN NULLIF(c.LastName, '') IS NOT NULL
                            THEN ' '
                        ELSE ''
                    END,

                    ISNULL(c.LastName, '')
                )
            )
        ) AS CustomerName,

        'PROCESS' AS NotificationType,

        N'Süreç Değişti' AS Title,

        CASE
            WHEN NULLIF(
                LTRIM(RTRIM(lpl.Note)),
                ''
            ) IS NOT NULL

            THEN CONCAT(
                lp.Name,
                ' - ',
                lpl.Note
            )

            ELSE lp.Name

        END AS Description,

        lpl.CreatedAt AS ActionDate,

        'PROCESS_CHANGE' AS Category

    FROM tmscrq.TMLeadProcessLog lpl

    INNER JOIN tmscrq.TMLead l
        ON l.Id = lpl.LeadId

    INNER JOIN tmscrq.TMLeadProcess lp
        ON lp.Id = lpl.ProcessId

    LEFT JOIN dbo.KUser ku
        ON ku.Id = lpl.CreatedBy

    LEFT JOIN tmscrq.TMUser tu
        ON tu.KuserID = ku.Id

    LEFT JOIN tmscrq.TMStore ts
        ON ts.Id = tu.StoreID

    LEFT JOIN tmscrq.TMProduct p
        ON p.Id = l.ProductId

    LEFT JOIN tmscrq.TMCustomer c
        ON c.Id = l.CustomerId

    WHERE lpl.CreatedAt >= @StartDate


    UNION ALL


    ----------------------------------------------------------
    -- 2. LEAD ALAN GÜNCELLEMELERİ
    ----------------------------------------------------------
    SELECT
        lul.Id AS NotificationId,

        l.Id AS LeadId,
        l.LeadCode,
        l.ReferencePersonID AS ReferenceID,

        CONCAT(
            ISNULL(ku.FirstName, ''),
            CASE
                WHEN NULLIF(ku.LastName, '') IS NOT NULL
                    THEN ' '
                ELSE ''
            END,
            ISNULL(ku.LastName, '')
        ) AS ActionUser,

        ts.StoreDesc AS StoreName,

        ISNULL
        (
            (
                SELECT STRING_AGG
                (
                    CASE kr.Name
                        WHEN 'TimesAdmin'
                            THEN 'Admin'

                        WHEN 'TimesUstYonetici'
                            THEN 'Üst Yönetici'

                        WHEN 'TimesYonetici'
                            THEN 'Yönetici'

                        WHEN 'TimesSatisPersoneli'
                            THEN 'Satış Personeli'

                        WHEN 'TimesMagazaMuduru'
                            THEN 'Mağaza Müdürü'

                        ELSE kr.Name
                    END,
                    ' '
                )

                FROM dbo.KUserRole kur

                INNER JOIN dbo.KRole kr
                    ON kr.Id = kur.KRole_Id

                WHERE kur.KUser_Id = ku.Id
            ),
            '-'
        ) AS RoleName,

        p.ProductName,
        p.Brand,
        p.CategoryName,

        LTRIM
        (
            RTRIM
            (
                CONCAT(
                    ISNULL(c.Name, ''),

                    CASE
                        WHEN NULLIF(c.LastName, '') IS NOT NULL
                            THEN ' '
                        ELSE ''
                    END,

                    ISNULL(c.LastName, '')
                )
            )
        ) AS CustomerName,

        'UPDATE' AS NotificationType,

        CASE
            WHEN lul.ColumnName IN
            (
                N'Durum',
                'StatuId'
            )
            THEN N'Durum Güncellendi'

            WHEN lul.ColumnName IN
            (
                N'Termin Tarihi',
                'EstimatedDate'
            )
            THEN N'Termin Tarihi Güncellendi'

            ELSE CONCAT(
                N'Alan Güncellendi: ',
                lul.ColumnName
            )

        END AS Title,


        ------------------------------------------------------
        -- DESCRIPTION
        ------------------------------------------------------
        CASE

            --------------------------------------------------
            -- DURUM
            --------------------------------------------------
            WHEN lul.ColumnName IN
            (
                N'Durum',
                'StatuId'
            )
            THEN CONCAT(

                ISNULL(
                    (
                        SELECT TOP 1
                            ls.Name

                        FROM tmscrq.TMLeadStatu ls

                        WHERE
                               ls.Id =
                               TRY_CAST(
                                   lul.OldValue
                                   AS UNIQUEIDENTIFIER
                               )

                            OR ls.Code =
                               lul.OldValue
                    ),

                    ISNULL(
                        lul.OldValue,
                        '-'
                    )
                ),

                ' → ',

                ISNULL(
                    (
                        SELECT TOP 1
                            ls.Name

                        FROM tmscrq.TMLeadStatu ls

                        WHERE
                               ls.Id =
                               TRY_CAST(
                                   lul.NewValue
                                   AS UNIQUEIDENTIFIER
                               )

                            OR ls.Code =
                               lul.NewValue
                    ),

                    ISNULL(
                        lul.NewValue,
                        '-'
                    )
                )
            )


            --------------------------------------------------
            -- TERMİN TARİHİ
            --------------------------------------------------
            WHEN lul.ColumnName IN
            (
                N'Termin Tarihi',
                'EstimatedDate'
            )
            THEN CONCAT(
                ISNULL(
                    lul.OldValue,
                    '-'
                ),
                ' → ',
                ISNULL(
                    lul.NewValue,
                    '-'
                )
            )


            --------------------------------------------------
            -- DİĞER
            --------------------------------------------------
            ELSE CONCAT(
                ISNULL(
                    lul.OldValue,
                    '-'
                ),
                ' → ',
                ISNULL(
                    lul.NewValue,
                    '-'
                )
            )

        END AS Description,

        lul.UpdatedAt AS ActionDate,

        CASE
            WHEN lul.ColumnName IN
            (
                N'Durum',
                'StatuId'
            )
            THEN 'STATUS_CHANGE'

            WHEN lul.ColumnName IN
            (
                N'Termin Tarihi',
                'EstimatedDate'
            )
            THEN 'DATE_CHANGE'

            ELSE 'FIELD_UPDATE'

        END AS Category

    FROM tmscrq.TMLeadUpdateLog lul

    INNER JOIN tmscrq.TMLead l
        ON l.Id = lul.LeadId

    LEFT JOIN dbo.KUser ku
        ON ku.Id = lul.UpdatedBy

    LEFT JOIN tmscrq.TMUser tu
        ON tu.KuserID = ku.Id

    LEFT JOIN tmscrq.TMStore ts
        ON ts.Id = tu.StoreID

    LEFT JOIN tmscrq.TMProduct p
        ON p.Id = l.ProductId

    LEFT JOIN tmscrq.TMCustomer c
        ON c.Id = l.CustomerId

    WHERE lul.UpdatedAt >= @StartDate

      ------------------------------------------------------
      -- Süreç kendi ProcessLog kaynağından geliyor
      ------------------------------------------------------
      AND lul.ColumnName NOT IN
      (
          N'Süreç',
          'ProcessID'
      )

      ------------------------------------------------------
      -- Rezervasyon kendi ReservationLog kaynağından geliyor
      ------------------------------------------------------
      AND lul.ColumnName NOT IN
      (
          N'Rezerv Durumu'
      )


    UNION ALL


    ----------------------------------------------------------
    -- 3. REZERVASYON HAREKETLERİ
    ----------------------------------------------------------
    SELECT
        rl.Id AS NotificationId,

        l.Id AS LeadId,
        l.LeadCode,
        l.ReferencePersonID AS ReferenceID,

        CONCAT(
            ISNULL(ku.FirstName, ''),
            CASE
                WHEN NULLIF(ku.LastName, '') IS NOT NULL
                    THEN ' '
                ELSE ''
            END,
            ISNULL(ku.LastName, '')
        ) AS ActionUser,

        ts.StoreDesc AS StoreName,

        ISNULL
        (
            (
                SELECT STRING_AGG
                (
                    CASE kr.Name
                        WHEN 'TimesAdmin'
                            THEN 'Admin'

                        WHEN 'TimesUstYonetici'
                            THEN 'Üst Yönetici'

                        WHEN 'TimesYonetici'
                            THEN 'Yönetici'

                        WHEN 'TimesSatisPersoneli'
                            THEN 'Satış Personeli'

                        WHEN 'TimesMagazaMuduru'
                            THEN 'Mağaza Müdürü'

                        ELSE kr.Name
                    END,
                    ' '
                )

                FROM dbo.KUserRole kur

                INNER JOIN dbo.KRole kr
                    ON kr.Id = kur.KRole_Id

                WHERE kur.KUser_Id = ku.Id
            ),
            '-'
        ) AS RoleName,

        p.ProductName,
        p.Brand,
        p.CategoryName,

        LTRIM
        (
            RTRIM
            (
                CONCAT(
                    ISNULL(c.Name, ''),

                    CASE
                        WHEN NULLIF(c.LastName, '') IS NOT NULL
                            THEN ' '
                        ELSE ''
                    END,

                    ISNULL(c.LastName, '')
                )
            )
        ) AS CustomerName,

        'RESERVATION' AS NotificationType,

        CASE
            WHEN UPPER(
                LTRIM(
                    RTRIM(
                        rl.ActionType
                    )
                )
            ) = 'REJECTED'

            THEN N'Rezervasyon Reddedildi'


            WHEN UPPER(
                LTRIM(
                    RTRIM(
                        rl.ActionType
                    )
                )
            ) = 'CUSTOMER_DECLINED'

            THEN N'Müşteri Rezervasyondan Vazgeçti'


            WHEN rl.ActionType =
                 N'Rezerv Oluşturuldu'

            THEN N'Rezervasyon Oluşturuldu'


            ELSE ISNULL(
                rl.ActionType,
                N'Rezervasyon Güncellendi'
            )

        END AS Title,


        CASE
            WHEN NULLIF(
                LTRIM(
                    RTRIM(
                        rl.Note
                    )
                ),
                ''
            ) IS NOT NULL

            THEN CONCAT(
                ISNULL(
                    rl.OldValue,
                    '-'
                ),
                ' → ',
                ISNULL(
                    rl.NewValue,
                    '-'
                ),
                ' · ',
                rl.Note
            )

            ELSE CONCAT(
                ISNULL(
                    rl.OldValue,
                    '-'
                ),
                ' → ',
                ISNULL(
                    rl.NewValue,
                    '-'
                )
            )

        END AS Description,

        rl.CreatedAt AS ActionDate,


        CASE
            WHEN UPPER(
                LTRIM(
                    RTRIM(
                        rl.ActionType
                    )
                )
            ) = 'REJECTED'

            THEN 'RESERVATION_REJECTED'


            WHEN UPPER(
                LTRIM(
                    RTRIM(
                        rl.ActionType
                    )
                )
            ) = 'CUSTOMER_DECLINED'

            THEN 'RESERVATION_CUSTOMER_DECLINED'


            WHEN rl.ActionType =
                 N'Rezerv Oluşturuldu'

            THEN 'RESERVATION_CREATED'


            ELSE 'RESERVATION_UPDATE'

        END AS Category


    FROM tmscrq.TMLeadReservationLog rl

    INNER JOIN tmscrq.TMLeadReservation r
        ON r.Id = rl.ReservationId

    INNER JOIN tmscrq.TMLead l
        ON l.Id = r.LeadId

    LEFT JOIN dbo.KUser ku
        ON ku.Id = rl.CreatedBy

    LEFT JOIN tmscrq.TMUser tu
        ON tu.KuserID = ku.Id

    LEFT JOIN tmscrq.TMStore ts
        ON ts.Id = tu.StoreID

    LEFT JOIN tmscrq.TMProduct p
        ON p.Id = l.ProductId

    LEFT JOIN tmscrq.TMCustomer c
        ON c.Id = l.CustomerId

    WHERE rl.CreatedAt >= @StartDate


    UNION ALL


    ----------------------------------------------------------
    -- 4. TERMİN ÖNERİLERİ
    ----------------------------------------------------------
    SELECT
        pl.Id AS NotificationId,

        l.Id AS LeadId,
        l.LeadCode,
        l.ReferencePersonID AS ReferenceID,

        CONCAT(
            ISNULL(ku.FirstName, ''),
            CASE
                WHEN NULLIF(ku.LastName, '') IS NOT NULL
                    THEN ' '
                ELSE ''
            END,
            ISNULL(ku.LastName, '')
        ) AS ActionUser,

        ts.StoreDesc AS StoreName,

        ISNULL
        (
            (
                SELECT STRING_AGG
                (
                    CASE kr.Name
                        WHEN 'TimesAdmin'
                            THEN 'Admin'

                        WHEN 'TimesUstYonetici'
                            THEN 'Üst Yönetici'

                        WHEN 'TimesYonetici'
                            THEN 'Yönetici'

                        WHEN 'TimesSatisPersoneli'
                            THEN 'Satış Personeli'

                        WHEN 'TimesMagazaMuduru'
                            THEN 'Mağaza Müdürü'

                        ELSE kr.Name
                    END,
                    ' '
                )

                FROM dbo.KUserRole kur

                INNER JOIN dbo.KRole kr
                    ON kr.Id = kur.KRole_Id

                WHERE kur.KUser_Id = ku.Id
            ),
            '-'
        ) AS RoleName,

        p.ProductName,
        p.Brand,
        p.CategoryName,

        LTRIM
        (
            RTRIM
            (
                CONCAT(
                    ISNULL(c.Name, ''),

                    CASE
                        WHEN NULLIF(c.LastName, '') IS NOT NULL
                            THEN ' '
                        ELSE ''
                    END,

                    ISNULL(c.LastName, '')
                )
            )
        ) AS CustomerName,

        'DATE_PROPOSAL'
            AS NotificationType,

        CASE
            WHEN UPPER(
                LTRIM(
                    RTRIM(
                        pl.ActionType
                    )
                )
            ) = 'CREATE'

            THEN N'Termin Önerisi Oluşturuldu'

            ELSE N'Termin Önerisi Güncellendi'

        END AS Title,


        CASE
            WHEN NULLIF(
                LTRIM(
                    RTRIM(
                        pl.Note
                    )
                ),
                ''
            ) IS NOT NULL

            THEN CONCAT(
                ISNULL(
                    pl.NewValue,
                    '-'
                ),
                ' · ',
                pl.Note
            )

            ELSE ISNULL(
                pl.NewValue,
                '-'
            )

        END AS Description,

        pl.CreatedAt AS ActionDate,

        'DATE_PROPOSAL' AS Category


    FROM tmscrq.TMLeadEstimatedDateProposalLog pl

    INNER JOIN tmscrq.TMLeadEstimatedDateProposal proposal
        ON proposal.Id = pl.ProposalId

    INNER JOIN tmscrq.TMLead l
        ON l.Id = proposal.LeadId

    LEFT JOIN dbo.KUser ku
        ON ku.Id = pl.CreatedBy

    LEFT JOIN tmscrq.TMUser tu
        ON tu.KuserID = ku.Id

    LEFT JOIN tmscrq.TMStore ts
        ON ts.Id = tu.StoreID

    LEFT JOIN tmscrq.TMProduct p
        ON p.Id = l.ProductId

    LEFT JOIN tmscrq.TMCustomer c
        ON c.Id = l.CustomerId

    WHERE pl.CreatedAt >= @StartDate


    UNION ALL


    ----------------------------------------------------------
    -- 5. TAMAMLANAN SATIŞLAR
    ----------------------------------------------------------
    SELECT
        sd.Id AS NotificationId,

        l.Id AS LeadId,
        l.LeadCode,
        l.ReferencePersonID AS ReferenceID,

        CONCAT(
            ISNULL(ku.FirstName, ''),
            CASE
                WHEN NULLIF(ku.LastName, '') IS NOT NULL
                    THEN ' '
                ELSE ''
            END,
            ISNULL(ku.LastName, '')
        ) AS ActionUser,

        ts.StoreDesc AS StoreName,

        ISNULL
        (
            (
                SELECT STRING_AGG
                (
                    CASE kr.Name
                        WHEN 'TimesAdmin'
                            THEN 'Admin'

                        WHEN 'TimesUstYonetici'
                            THEN 'Üst Yönetici'

                        WHEN 'TimesYonetici'
                            THEN 'Yönetici'

                        WHEN 'TimesSatisPersoneli'
                            THEN 'Satış Personeli'

                        WHEN 'TimesMagazaMuduru'
                            THEN 'Mağaza Müdürü'

                        ELSE kr.Name
                    END,
                    ' '
                )

                FROM dbo.KUserRole kur

                INNER JOIN dbo.KRole kr
                    ON kr.Id = kur.KRole_Id

                WHERE kur.KUser_Id = ku.Id
            ),
            '-'
        ) AS RoleName,

        p.ProductName,
        p.Brand,
        p.CategoryName,

        LTRIM
        (
            RTRIM
            (
                CONCAT(
                    ISNULL(c.Name, ''),

                    CASE
                        WHEN NULLIF(c.LastName, '') IS NOT NULL
                            THEN ' '
                        ELSE ''
                    END,

                    ISNULL(c.LastName, '')
                )
            )
        ) AS CustomerName,

        'SALE' AS NotificationType,

        N'Satış Gerçekleşti' AS Title,

        CONCAT(
            N'Talep ',
            ISNULL(
                l.LeadCode,
                '-'
            ),
            N' için satış tamamlandı. Fatura No: ',
            ISNULL(
                sd.InvoiceNumber,
                '-'
            )
        ) AS Description,

        COALESCE(
            sd.InvoiceDate,
            sd.CreatedAt
        ) AS ActionDate,

        'SALE_COMPLETED'
            AS Category


    FROM tmscrq.TMSalesLeadDraft sd

    INNER JOIN tmscrq.TMLead l
        ON l.Id = sd.LeadId

    LEFT JOIN dbo.KUser ku
        ON ku.Id = sd.KUserID

    LEFT JOIN tmscrq.TMUser tu
        ON tu.KuserID = ku.Id

    LEFT JOIN tmscrq.TMStore ts
        ON ts.Id = tu.StoreID

    LEFT JOIN tmscrq.TMProduct p
        ON p.Id = l.ProductId

    LEFT JOIN tmscrq.TMCustomer c
        ON c.Id = l.CustomerId

    WHERE sd.IsCompleted = 1

      AND NULLIF(
            LTRIM(
                RTRIM(
                    sd.InvoiceNumber
                )
            ),
            ''
          ) IS NOT NULL

      AND COALESCE(
            sd.InvoiceDate,
            sd.CreatedAt
          ) >= @StartDate

) X


------------------------------------------------------------
-- BİLDİRİM TİPİ FİLTRESİ
------------------------------------------------------------
WHERE
(
       NULLIF(
           LTRIM(
               RTRIM(
                   @NotificationTypeFilter
               )
           ),
           ''
       ) IS NULL

    OR @NotificationTypeFilter = 'ALL'

    OR X.NotificationType =
       @NotificationTypeFilter
)


------------------------------------------------------------
-- TÜMÜ / OKUNMAMIŞ FİLTRESİ
------------------------------------------------------------
AND
(
       ISNULL(
           @ShowUnreadOnly,
           0
       ) = 0

    OR X.ActionDate > @LastReadDate
)


------------------------------------------------------------
-- EN YENİ EN ÜSTTE
------------------------------------------------------------
ORDER BY X.ActionDate DESC;", new string[] { "NotificationId", "LeadId", "LeadCode", "ReferenceID", "ActionUser", "StoreName", "RoleName", "ProductName", "Brand", "CategoryName", "CustomerName", "NotificationType", "Title", "Description", "ActionDate", "Category", "DisplayTitle", "DisplayMessage", "IsRead" }, prms_NotifListStatuChange_0.ToArray());
            ;


            return Ok(result);
        }


        [HttpPost, Route("NotificationManagerComponent_213706_onChange")]
        public IActionResult NotificationManagerComponent_213706_onChange(NotificationManagerComponent_213706_onChange_Request request)
        {

            KProviderManager.Authorization.IsAuthorizedForRoles(appId, appName, screenId, screenName, new List<string> { $"4da1f213-c8e4-0b50-5c84-02fd13f1a622", "TimesUstYonetici" });

            var result = new NotificationManagerComponent_213706_onChange_Response();

            var prms_NotifListStatuChange_0 = new List<kSqlParameter>();
            prms_NotifListStatuChange_0.Add(new kSqlParameter() { Name = "DateFilter", Value = request.DateFilter_0 });
            prms_NotifListStatuChange_0.Add(new kSqlParameter() { Name = "KUserId", Value = Kuika.Common.KContext.CurrentUser?.Id });
            prms_NotifListStatuChange_0.Add(new kSqlParameter() { Name = "NotificationTypeFilter", Value = request.NotificationTypeFilter_0 });
            prms_NotifListStatuChange_0.Add(new kSqlParameter() { Name = "ShowUnreadOnly", Value = "False".ConvertToType<Boolean>() });
            using var auditNotifListStatuChange_0 = ActionAuditScope.Begin("e11e2783-fbfd-347f-5cae-dbaad1834188", "NotifListStatuChange", applicationName: "wbTimesCRM", screenOrEndpointName: "NotificationManager");
            result.NotifListStatuChange = KPersister.Fetch(KContext.GetConnectionString(), @"/*

DECLARE @StartDate DATETIME;

SET @StartDate =
CASE @DateFilter
    WHEN 1 THEN DATEADD(HOUR,-1,GETDATE())     
    WHEN 2 THEN DATEADD(HOUR,-6,GETDATE())     
    WHEN 3 THEN DATEADD(HOUR,-24,GETDATE())    
    WHEN 4 THEN DATEADD(DAY,-7,GETDATE())      
    WHEN 5 THEN DATEADD(DAY,-30,GETDATE())     
    WHEN 6 THEN '1900-01-01'                   
    ELSE '1900-01-01'
END;

------------------------------------------------------

SELECT *
FROM
(

    --------------------------------------------------
    -- 🔵 PROCESS LOG
    --------------------------------------------------
    SELECT
        NEWID() AS NotificationId,

        l.Id AS LeadId,
        l.LeadCode,
        l.ReferenceID,

        ku.FirstName + ' ' + ku.LastName AS ActionUser,
        ts.StoreDesc AS StoreName,

        STRING_AGG(
            CASE r.Name
                WHEN 'TimesAdmin' THEN 'Admin'
                WHEN 'TimesUstYonetici' THEN 'Üst Yönetici'
                WHEN 'TimesYonetici' THEN 'Yönetici'
                WHEN 'TimesSatisPersoneli' THEN 'Satış Personeli'
                WHEN 'TimesMagazaMuduru' THEN 'Mağaza Müdürü'
                ELSE r.Name
            END,' '
        ) AS RoleName,

        p.ProductName,
        p.Brand,
        p.CategoryName,

        c.Name + ' ' + c.LastName AS CustomerName,

        'PROCESS' AS NotificationType,

        lp.Name AS Title,
        lpl.Note AS Description,

        lpl.CreatedAt AS ActionDate,

        'ProcessChange' AS Category

    FROM tmscrq.TMLeadProcessLog lpl

    INNER JOIN tmscrq.TMLead l 
        ON l.Id = lpl.LeadId

    INNER JOIN tmscrq.TMLeadProcess lp 
        ON lp.Id = lpl.ProcessId

    INNER JOIN dbo.KUser ku 
        ON ku.Id = lpl.CreatedBy

    LEFT JOIN tmscrq.TMUser tu 
        ON tu.KuserID = ku.Id

    LEFT JOIN tmscrq.TMStore ts 
        ON ts.Id = tu.StoreID

    LEFT JOIN dbo.KUserRole ur 
        ON ur.KUser_Id = ku.Id

    LEFT JOIN dbo.KRole r 
        ON r.Id = ur.KRole_Id

    LEFT JOIN tmscrq.TMProduct p 
        ON p.Id = l.ProductId

    LEFT JOIN tmscrq.TMCustomer c 
        ON c.Id = l.CustomerId

    WHERE lpl.CreatedAt >= @StartDate

    GROUP BY
        l.Id,
        l.LeadCode,
        l.ReferenceID,
        ku.FirstName,
        ku.LastName,
        ts.StoreDesc,
        p.ProductName,
        p.Brand,
        p.CategoryName,
        c.Name,
        c.LastName,
        lp.Name,
        lpl.Note,
        lpl.CreatedAt

    UNION ALL

    --------------------------------------------------
    -- 🟢 UPDATE LOG
    --------------------------------------------------
    SELECT
        NEWID() AS NotificationId,

        l.Id AS LeadId,
        l.LeadCode,
        l.ReferenceID,

        ku.FirstName + ' ' + ku.LastName AS ActionUser,
        ts.StoreDesc AS StoreName,

        STRING_AGG(
            CASE r.Name
                WHEN 'TimesAdmin' THEN 'Admin'
                WHEN 'TimesUstYonetici' THEN 'Üst Yönetici'
                WHEN 'TimesYonetici' THEN 'Yönetici'
                WHEN 'TimesSatisPersoneli' THEN 'Satış Personeli'
                WHEN 'TimesMagazaMuduru' THEN 'Mağaza Müdürü'
                ELSE r.Name
            END,' '
        ) AS RoleName,

        p.ProductName,
        p.Brand,
        p.CategoryName,

        c.Name + ' ' + c.LastName AS CustomerName,

        'UPDATE' AS NotificationType,

        --------------------------------------------------
        -- TITLE
        --------------------------------------------------
        CASE
            WHEN lul.ColumnName = 'StatuId' THEN 'Alan Güncellendi: Statu'
            WHEN lul.ColumnName = 'ProcessID' THEN 'Alan Güncellendi: Süreç'
            WHEN lul.ColumnName = 'NextStep' THEN 'Alan Güncellendi: Sonraki Adım'
            WHEN lul.ColumnName = 'ContactResourceId' THEN 'Alan Güncellendi: İletişim Kaynağı'
            WHEN lul.ColumnName = 'SalesPersonKUserId' THEN 'Alan Güncellendi: Satış Personeli'
            WHEN lul.ColumnName = 'StoreId' THEN 'Alan Güncellendi: Mağaza'
            ELSE CONCAT('Alan Güncellendi: ', lul.ColumnName)
        END AS Title,

        --------------------------------------------------
        -- DESCRIPTION
        --------------------------------------------------
        CASE 

            ------------------------------------------------
            -- STATU
            ------------------------------------------------
            WHEN lul.ColumnName = 'StatuId' THEN
                CONCAT(
                    ISNULL((
                        SELECT TOP 1 Name
                        FROM tmscrq.TMLeadStatu
                        WHERE 
                            Id = TRY_CAST(lul.OldValue AS UNIQUEIDENTIFIER)
                            OR Code = lul.OldValue
                    ), '-'),
                    ' → ',
                    ISNULL((
                        SELECT TOP 1 Name
                        FROM tmscrq.TMLeadStatu
                        WHERE 
                            Id = TRY_CAST(lul.NewValue AS UNIQUEIDENTIFIER)
                            OR Code = lul.NewValue
                    ), '-')
                )

            ------------------------------------------------
            -- İLETİŞİM KAYNAĞI
            ------------------------------------------------
            WHEN lul.ColumnName = 'ContactResourceId' THEN
                CONCAT(
                    ISNULL((
                        SELECT TOP 1 ContactResourceName
                        FROM tmscrq.TMContactResource
                        WHERE 
                            Id = TRY_CAST(lul.OldValue AS UNIQUEIDENTIFIER)
                            OR ContactResourceCode = lul.OldValue
                    ), '-'),
                    ' → ',
                    ISNULL((
                        SELECT TOP 1 ContactResourceName
                        FROM tmscrq.TMContactResource
                        WHERE 
                            Id = TRY_CAST(lul.NewValue AS UNIQUEIDENTIFIER)
                            OR ContactResourceCode = lul.NewValue
                    ), '-')
                )

            ------------------------------------------------
            -- SATIŞ PERSONELİ
            ------------------------------------------------
            WHEN lul.ColumnName = 'SalesPersonKUserId' THEN
                CONCAT(
                    ISNULL((
                        SELECT TOP 1 
                            FirstName + ' ' + LastName
                        FROM dbo.KUser
                        WHERE 
                            Id = TRY_CAST(lul.OldValue AS UNIQUEIDENTIFIER)
                    ), '-'),
                    ' → ',
                    ISNULL((
                        SELECT TOP 1 
                            FirstName + ' ' + LastName
                        FROM dbo.KUser
                        WHERE 
                            Id = TRY_CAST(lul.NewValue AS UNIQUEIDENTIFIER)
                    ), '-')
                )

            ------------------------------------------------
            -- MAĞAZA
            ------------------------------------------------
            WHEN lul.ColumnName = 'StoreId' THEN
                CONCAT(
                    ISNULL((
                        SELECT TOP 1 StoreDesc
                        FROM tmscrq.TMStore
                        WHERE 
                            Id = TRY_CAST(lul.OldValue AS UNIQUEIDENTIFIER)
                    ), '-'),
                    ' → ',
                    ISNULL((
                        SELECT TOP 1 StoreDesc
                        FROM tmscrq.TMStore
                        WHERE 
                            Id = TRY_CAST(lul.NewValue AS UNIQUEIDENTIFIER)
                    ), '-')
                )

            ------------------------------------------------
            -- PROCESS
            ------------------------------------------------
            WHEN lul.ColumnName = 'ProcessID' THEN
                CONCAT(
                    ISNULL((
                        SELECT TOP 1 Name
                        FROM tmscrq.TMLeadProcess
                        WHERE 
                            Id = TRY_CAST(lul.OldValue AS UNIQUEIDENTIFIER)
                            OR Code = lul.OldValue
                    ), '-'),
                    ' → ',
                    ISNULL((
                        SELECT TOP 1 Name
                        FROM tmscrq.TMLeadProcess
                        WHERE 
                            Id = TRY_CAST(lul.NewValue AS UNIQUEIDENTIFIER)
                            OR Code = lul.NewValue
                    ), '-')
                )

            ------------------------------------------------
            -- NEXT STEP
            ------------------------------------------------
            WHEN lul.ColumnName = 'NextStep' THEN
                CONCAT(
                    ISNULL((
                        SELECT TOP 1 Name
                        FROM tmscrq.TMLeadNextStep
                        WHERE Code = lul.OldValue
                    ), '-'),
                    ' → ',
                    ISNULL((
                        SELECT TOP 1 Name
                        FROM tmscrq.TMLeadNextStep
                        WHERE Code = lul.NewValue
                    ), '-')
                )

            ------------------------------------------------
            -- DEFAULT
            ------------------------------------------------
            ELSE
                CONCAT(
                    ISNULL(lul.OldValue,'-'),
                    ' → ',
                    ISNULL(lul.NewValue,'-')
                )

        END AS Description,

        lul.UpdatedAt AS ActionDate,

        --------------------------------------------------
        -- CATEGORY
        --------------------------------------------------
        CASE 
            WHEN lul.ColumnName = 'StatuId' THEN 'StatusChange'
            WHEN lul.ColumnName = 'EstimatedDate' THEN 'DateChange'
            WHEN lul.ColumnName = 'ContactResourceId' THEN 'ContactChange'
            WHEN lul.ColumnName = 'SalesPersonKUserId' THEN 'SalesPersonChange'
            WHEN lul.ColumnName = 'StoreId' THEN 'StoreChange'
            WHEN lul.ColumnName = 'ProcessID' THEN 'ProcessChange'
            WHEN lul.ColumnName = 'NextStep' THEN 'NextStepChange'
            ELSE 'FieldUpdate'
        END AS Category

    FROM tmscrq.TMLeadUpdateLog lul

    INNER JOIN tmscrq.TMLead l 
        ON l.Id = lul.LeadId

    INNER JOIN dbo.KUser ku 
        ON ku.Id = lul.UpdatedBy

    LEFT JOIN tmscrq.TMUser tu 
        ON tu.KuserID = ku.Id

    LEFT JOIN tmscrq.TMStore ts 
        ON ts.Id = tu.StoreID

    LEFT JOIN dbo.KUserRole ur 
        ON ur.KUser_Id = ku.Id

    LEFT JOIN dbo.KRole r 
        ON r.Id = ur.KRole_Id

    LEFT JOIN tmscrq.TMProduct p 
        ON p.Id = l.ProductId

    LEFT JOIN tmscrq.TMCustomer c 
        ON c.Id = l.CustomerId

    WHERE lul.UpdatedAt >= @StartDate

    GROUP BY
        l.Id,
        l.LeadCode,
        l.ReferenceID,
        ku.FirstName,
        ku.LastName,
        ts.StoreDesc,
        p.ProductName,
        p.Brand,
        p.CategoryName,
        c.Name,
        c.LastName,
        lul.ColumnName,
        lul.OldValue,
        lul.NewValue,
        lul.UpdatedAt

) X

ORDER BY ActionDate DESC;

*/

SET NOCOUNT ON;

DECLARE @StartDate DATETIME;
DECLARE @LastReadDate DATETIMEOFFSET;


------------------------------------------------------------
-- TARİH FİLTRESİ
------------------------------------------------------------
SET @StartDate =
CASE @DateFilter
    WHEN 1 THEN DATEADD(HOUR, -1, GETDATE())
    WHEN 2 THEN DATEADD(HOUR, -6, GETDATE())
    WHEN 3 THEN DATEADD(HOUR, -24, GETDATE())
    WHEN 4 THEN DATEADD(DAY, -7, GETDATE())
    WHEN 5 THEN DATEADD(DAY, -30, GETDATE())
    WHEN 6 THEN '1900-01-01'
    ELSE '1900-01-01'
END;


------------------------------------------------------------
-- KULLANICININ SON OKUMA TARİHİ
-- SADECE READ-ONLY
------------------------------------------------------------
SELECT
    @LastReadDate = LastReadDate
FROM tmscrq.TMNotificationRead
WHERE KUserId = @KUserId;


IF @LastReadDate IS NULL
BEGIN
    SET @LastReadDate =
        CAST('1900-01-01' AS DATETIMEOFFSET);
END;


------------------------------------------------------------
-- BİLDİRİMLER
------------------------------------------------------------
SELECT
    X.*,


    ----------------------------------------------------------
    -- UI İÇİN OKUNABİLİR BAŞLIK
    ----------------------------------------------------------
    CASE X.Category

        WHEN 'PROCESS_CHANGE'
            THEN N'Süreç Güncellendi'

        WHEN 'STATUS_CHANGE'
            THEN N'Durum Güncellendi'

        WHEN 'DATE_CHANGE'
            THEN N'Termin Tarihi Güncellendi'

        WHEN 'RESERVATION_CREATED'
            THEN N'Rezervasyon Oluşturuldu'

        WHEN 'RESERVATION_REJECTED'
            THEN N'Rezervasyon Reddedildi'

        WHEN 'RESERVATION_CUSTOMER_DECLINED'
            THEN N'Müşteri Rezervasyondan Vazgeçti'

        WHEN 'RESERVATION_UPDATE'
            THEN N'Rezervasyon Güncellendi'

        WHEN 'DATE_PROPOSAL'
            THEN N'Termin Önerisi Oluşturuldu'

        WHEN 'SALE_COMPLETED'
            THEN N'Satış Gerçekleşti'

        ELSE X.Title

    END AS DisplayTitle,


    ----------------------------------------------------------
    -- UI İÇİN OKUNABİLİR MESAJ
    ----------------------------------------------------------
    CASE X.Category

        ------------------------------------------------------
        -- SÜREÇ
        ------------------------------------------------------
        WHEN 'PROCESS_CHANGE'
            THEN CONCAT(
                ISNULL(X.LeadCode, N'Talep'),
                N' numaralı talebin süreci ',
                ISNULL(X.Description, N'güncellendi'),
                N'.'
            )

        ------------------------------------------------------
        -- DURUM
        ------------------------------------------------------
        WHEN 'STATUS_CHANGE'
            THEN CONCAT(
                ISNULL(X.LeadCode, N'Talep'),
                N' numaralı talebin durumu güncellendi: ',
                ISNULL(X.Description, N'-'),
                N'.'
            )

        ------------------------------------------------------
        -- TERMİN TARİHİ
        ------------------------------------------------------
        WHEN 'DATE_CHANGE'
            THEN CONCAT(
                ISNULL(X.LeadCode, N'Talep'),
                N' numaralı talebin termin tarihi güncellendi: ',
                ISNULL(X.Description, N'-'),
                N'.'
            )

        ------------------------------------------------------
        -- REZERVASYON OLUŞTURULDU
        ------------------------------------------------------
        WHEN 'RESERVATION_CREATED'
            THEN CONCAT(
                ISNULL(X.LeadCode, N'Talep'),
                N' numaralı talep için rezervasyon oluşturuldu.'
            )

        ------------------------------------------------------
        -- REZERVASYON REDDEDİLDİ
        ------------------------------------------------------
        WHEN 'RESERVATION_REJECTED'
            THEN CONCAT(
                ISNULL(X.LeadCode, N'Talep'),
                N' numaralı talebe ait rezervasyon reddedildi.'
            )

        ------------------------------------------------------
        -- MÜŞTERİ VAZGEÇTİ
        ------------------------------------------------------
        WHEN 'RESERVATION_CUSTOMER_DECLINED'
            THEN CONCAT(
                ISNULL(X.LeadCode, N'Talep'),
                N' numaralı talepte müşteri rezervasyondan vazgeçti.'
            )

        ------------------------------------------------------
        -- REZERVASYON GÜNCELLENDİ
        ------------------------------------------------------
        WHEN 'RESERVATION_UPDATE'
            THEN CONCAT(
                ISNULL(X.LeadCode, N'Talep'),
                N' numaralı talebin rezervasyon bilgisi güncellendi.'
            )

        ------------------------------------------------------
        -- TERMİN ÖNERİSİ
        ------------------------------------------------------
        WHEN 'DATE_PROPOSAL'
            THEN CONCAT(
                ISNULL(X.LeadCode, N'Talep'),
                N' numaralı talep için termin önerisi oluşturuldu',
                CASE
                    WHEN NULLIF(
                        LTRIM(
                            RTRIM(
                                ISNULL(X.Description, '')
                            )
                        ),
                        ''
                    ) IS NOT NULL
                    THEN CONCAT(
                        N': ',
                        X.Description
                    )
                    ELSE N'.'
                END
            )

        ------------------------------------------------------
        -- SATIŞ
        ------------------------------------------------------
        WHEN 'SALE_COMPLETED'
            THEN X.Description

        ------------------------------------------------------
        -- DİĞER
        ------------------------------------------------------
        ELSE ISNULL(
            X.Description,
            N'-'
        )

    END AS DisplayMessage,


    ----------------------------------------------------------
    -- UI İÇİN OKUNDU BİLGİSİ
    ----------------------------------------------------------
    CASE
        WHEN X.ActionDate > @LastReadDate
            THEN CAST(0 AS BIT)
        ELSE CAST(1 AS BIT)
    END AS IsRead


FROM
(

    ----------------------------------------------------------
    -- 1. SÜREÇ HAREKETLERİ
    ----------------------------------------------------------
    SELECT
        lpl.Id AS NotificationId,

        l.Id AS LeadId,
        l.LeadCode,
        l.ReferencePersonID AS ReferenceID,

        CONCAT(
            ISNULL(ku.FirstName, ''),
            CASE
                WHEN NULLIF(ku.LastName, '') IS NOT NULL
                    THEN ' '
                ELSE ''
            END,
            ISNULL(ku.LastName, '')
        ) AS ActionUser,

        ts.StoreDesc AS StoreName,

        ISNULL
        (
            (
                SELECT STRING_AGG
                (
                    CASE kr.Name
                        WHEN 'TimesAdmin'
                            THEN 'Admin'

                        WHEN 'TimesUstYonetici'
                            THEN 'Üst Yönetici'

                        WHEN 'TimesYonetici'
                            THEN 'Yönetici'

                        WHEN 'TimesSatisPersoneli'
                            THEN 'Satış Personeli'

                        WHEN 'TimesMagazaMuduru'
                            THEN 'Mağaza Müdürü'

                        ELSE kr.Name
                    END,
                    ' '
                )

                FROM dbo.KUserRole kur

                INNER JOIN dbo.KRole kr
                    ON kr.Id = kur.KRole_Id

                WHERE kur.KUser_Id = ku.Id
            ),
            '-'
        ) AS RoleName,

        p.ProductName,
        p.Brand,
        p.CategoryName,

        LTRIM
        (
            RTRIM
            (
                CONCAT(
                    ISNULL(c.Name, ''),

                    CASE
                        WHEN NULLIF(c.LastName, '') IS NOT NULL
                            THEN ' '
                        ELSE ''
                    END,

                    ISNULL(c.LastName, '')
                )
            )
        ) AS CustomerName,

        'PROCESS' AS NotificationType,

        N'Süreç Değişti' AS Title,

        CASE
            WHEN NULLIF(
                LTRIM(RTRIM(lpl.Note)),
                ''
            ) IS NOT NULL

            THEN CONCAT(
                lp.Name,
                ' - ',
                lpl.Note
            )

            ELSE lp.Name

        END AS Description,

        lpl.CreatedAt AS ActionDate,

        'PROCESS_CHANGE' AS Category

    FROM tmscrq.TMLeadProcessLog lpl

    INNER JOIN tmscrq.TMLead l
        ON l.Id = lpl.LeadId

    INNER JOIN tmscrq.TMLeadProcess lp
        ON lp.Id = lpl.ProcessId

    LEFT JOIN dbo.KUser ku
        ON ku.Id = lpl.CreatedBy

    LEFT JOIN tmscrq.TMUser tu
        ON tu.KuserID = ku.Id

    LEFT JOIN tmscrq.TMStore ts
        ON ts.Id = tu.StoreID

    LEFT JOIN tmscrq.TMProduct p
        ON p.Id = l.ProductId

    LEFT JOIN tmscrq.TMCustomer c
        ON c.Id = l.CustomerId

    WHERE lpl.CreatedAt >= @StartDate


    UNION ALL


    ----------------------------------------------------------
    -- 2. LEAD ALAN GÜNCELLEMELERİ
    ----------------------------------------------------------
    SELECT
        lul.Id AS NotificationId,

        l.Id AS LeadId,
        l.LeadCode,
        l.ReferencePersonID AS ReferenceID,

        CONCAT(
            ISNULL(ku.FirstName, ''),
            CASE
                WHEN NULLIF(ku.LastName, '') IS NOT NULL
                    THEN ' '
                ELSE ''
            END,
            ISNULL(ku.LastName, '')
        ) AS ActionUser,

        ts.StoreDesc AS StoreName,

        ISNULL
        (
            (
                SELECT STRING_AGG
                (
                    CASE kr.Name
                        WHEN 'TimesAdmin'
                            THEN 'Admin'

                        WHEN 'TimesUstYonetici'
                            THEN 'Üst Yönetici'

                        WHEN 'TimesYonetici'
                            THEN 'Yönetici'

                        WHEN 'TimesSatisPersoneli'
                            THEN 'Satış Personeli'

                        WHEN 'TimesMagazaMuduru'
                            THEN 'Mağaza Müdürü'

                        ELSE kr.Name
                    END,
                    ' '
                )

                FROM dbo.KUserRole kur

                INNER JOIN dbo.KRole kr
                    ON kr.Id = kur.KRole_Id

                WHERE kur.KUser_Id = ku.Id
            ),
            '-'
        ) AS RoleName,

        p.ProductName,
        p.Brand,
        p.CategoryName,

        LTRIM
        (
            RTRIM
            (
                CONCAT(
                    ISNULL(c.Name, ''),

                    CASE
                        WHEN NULLIF(c.LastName, '') IS NOT NULL
                            THEN ' '
                        ELSE ''
                    END,

                    ISNULL(c.LastName, '')
                )
            )
        ) AS CustomerName,

        'UPDATE' AS NotificationType,

        CASE
            WHEN lul.ColumnName IN
            (
                N'Durum',
                'StatuId'
            )
            THEN N'Durum Güncellendi'

            WHEN lul.ColumnName IN
            (
                N'Termin Tarihi',
                'EstimatedDate'
            )
            THEN N'Termin Tarihi Güncellendi'

            ELSE CONCAT(
                N'Alan Güncellendi: ',
                lul.ColumnName
            )

        END AS Title,


        ------------------------------------------------------
        -- DESCRIPTION
        ------------------------------------------------------
        CASE

            --------------------------------------------------
            -- DURUM
            --------------------------------------------------
            WHEN lul.ColumnName IN
            (
                N'Durum',
                'StatuId'
            )
            THEN CONCAT(

                ISNULL(
                    (
                        SELECT TOP 1
                            ls.Name

                        FROM tmscrq.TMLeadStatu ls

                        WHERE
                               ls.Id =
                               TRY_CAST(
                                   lul.OldValue
                                   AS UNIQUEIDENTIFIER
                               )

                            OR ls.Code =
                               lul.OldValue
                    ),

                    ISNULL(
                        lul.OldValue,
                        '-'
                    )
                ),

                ' → ',

                ISNULL(
                    (
                        SELECT TOP 1
                            ls.Name

                        FROM tmscrq.TMLeadStatu ls

                        WHERE
                               ls.Id =
                               TRY_CAST(
                                   lul.NewValue
                                   AS UNIQUEIDENTIFIER
                               )

                            OR ls.Code =
                               lul.NewValue
                    ),

                    ISNULL(
                        lul.NewValue,
                        '-'
                    )
                )
            )


            --------------------------------------------------
            -- TERMİN TARİHİ
            --------------------------------------------------
            WHEN lul.ColumnName IN
            (
                N'Termin Tarihi',
                'EstimatedDate'
            )
            THEN CONCAT(
                ISNULL(
                    lul.OldValue,
                    '-'
                ),
                ' → ',
                ISNULL(
                    lul.NewValue,
                    '-'
                )
            )


            --------------------------------------------------
            -- DİĞER
            --------------------------------------------------
            ELSE CONCAT(
                ISNULL(
                    lul.OldValue,
                    '-'
                ),
                ' → ',
                ISNULL(
                    lul.NewValue,
                    '-'
                )
            )

        END AS Description,

        lul.UpdatedAt AS ActionDate,

        CASE
            WHEN lul.ColumnName IN
            (
                N'Durum',
                'StatuId'
            )
            THEN 'STATUS_CHANGE'

            WHEN lul.ColumnName IN
            (
                N'Termin Tarihi',
                'EstimatedDate'
            )
            THEN 'DATE_CHANGE'

            ELSE 'FIELD_UPDATE'

        END AS Category

    FROM tmscrq.TMLeadUpdateLog lul

    INNER JOIN tmscrq.TMLead l
        ON l.Id = lul.LeadId

    LEFT JOIN dbo.KUser ku
        ON ku.Id = lul.UpdatedBy

    LEFT JOIN tmscrq.TMUser tu
        ON tu.KuserID = ku.Id

    LEFT JOIN tmscrq.TMStore ts
        ON ts.Id = tu.StoreID

    LEFT JOIN tmscrq.TMProduct p
        ON p.Id = l.ProductId

    LEFT JOIN tmscrq.TMCustomer c
        ON c.Id = l.CustomerId

    WHERE lul.UpdatedAt >= @StartDate

      ------------------------------------------------------
      -- Süreç kendi ProcessLog kaynağından geliyor
      ------------------------------------------------------
      AND lul.ColumnName NOT IN
      (
          N'Süreç',
          'ProcessID'
      )

      ------------------------------------------------------
      -- Rezervasyon kendi ReservationLog kaynağından geliyor
      ------------------------------------------------------
      AND lul.ColumnName NOT IN
      (
          N'Rezerv Durumu'
      )


    UNION ALL


    ----------------------------------------------------------
    -- 3. REZERVASYON HAREKETLERİ
    ----------------------------------------------------------
    SELECT
        rl.Id AS NotificationId,

        l.Id AS LeadId,
        l.LeadCode,
        l.ReferencePersonID AS ReferenceID,

        CONCAT(
            ISNULL(ku.FirstName, ''),
            CASE
                WHEN NULLIF(ku.LastName, '') IS NOT NULL
                    THEN ' '
                ELSE ''
            END,
            ISNULL(ku.LastName, '')
        ) AS ActionUser,

        ts.StoreDesc AS StoreName,

        ISNULL
        (
            (
                SELECT STRING_AGG
                (
                    CASE kr.Name
                        WHEN 'TimesAdmin'
                            THEN 'Admin'

                        WHEN 'TimesUstYonetici'
                            THEN 'Üst Yönetici'

                        WHEN 'TimesYonetici'
                            THEN 'Yönetici'

                        WHEN 'TimesSatisPersoneli'
                            THEN 'Satış Personeli'

                        WHEN 'TimesMagazaMuduru'
                            THEN 'Mağaza Müdürü'

                        ELSE kr.Name
                    END,
                    ' '
                )

                FROM dbo.KUserRole kur

                INNER JOIN dbo.KRole kr
                    ON kr.Id = kur.KRole_Id

                WHERE kur.KUser_Id = ku.Id
            ),
            '-'
        ) AS RoleName,

        p.ProductName,
        p.Brand,
        p.CategoryName,

        LTRIM
        (
            RTRIM
            (
                CONCAT(
                    ISNULL(c.Name, ''),

                    CASE
                        WHEN NULLIF(c.LastName, '') IS NOT NULL
                            THEN ' '
                        ELSE ''
                    END,

                    ISNULL(c.LastName, '')
                )
            )
        ) AS CustomerName,

        'RESERVATION' AS NotificationType,

        CASE
            WHEN UPPER(
                LTRIM(
                    RTRIM(
                        rl.ActionType
                    )
                )
            ) = 'REJECTED'

            THEN N'Rezervasyon Reddedildi'


            WHEN UPPER(
                LTRIM(
                    RTRIM(
                        rl.ActionType
                    )
                )
            ) = 'CUSTOMER_DECLINED'

            THEN N'Müşteri Rezervasyondan Vazgeçti'


            WHEN rl.ActionType =
                 N'Rezerv Oluşturuldu'

            THEN N'Rezervasyon Oluşturuldu'


            ELSE ISNULL(
                rl.ActionType,
                N'Rezervasyon Güncellendi'
            )

        END AS Title,


        CASE
            WHEN NULLIF(
                LTRIM(
                    RTRIM(
                        rl.Note
                    )
                ),
                ''
            ) IS NOT NULL

            THEN CONCAT(
                ISNULL(
                    rl.OldValue,
                    '-'
                ),
                ' → ',
                ISNULL(
                    rl.NewValue,
                    '-'
                ),
                ' · ',
                rl.Note
            )

            ELSE CONCAT(
                ISNULL(
                    rl.OldValue,
                    '-'
                ),
                ' → ',
                ISNULL(
                    rl.NewValue,
                    '-'
                )
            )

        END AS Description,

        rl.CreatedAt AS ActionDate,


        CASE
            WHEN UPPER(
                LTRIM(
                    RTRIM(
                        rl.ActionType
                    )
                )
            ) = 'REJECTED'

            THEN 'RESERVATION_REJECTED'


            WHEN UPPER(
                LTRIM(
                    RTRIM(
                        rl.ActionType
                    )
                )
            ) = 'CUSTOMER_DECLINED'

            THEN 'RESERVATION_CUSTOMER_DECLINED'


            WHEN rl.ActionType =
                 N'Rezerv Oluşturuldu'

            THEN 'RESERVATION_CREATED'


            ELSE 'RESERVATION_UPDATE'

        END AS Category


    FROM tmscrq.TMLeadReservationLog rl

    INNER JOIN tmscrq.TMLeadReservation r
        ON r.Id = rl.ReservationId

    INNER JOIN tmscrq.TMLead l
        ON l.Id = r.LeadId

    LEFT JOIN dbo.KUser ku
        ON ku.Id = rl.CreatedBy

    LEFT JOIN tmscrq.TMUser tu
        ON tu.KuserID = ku.Id

    LEFT JOIN tmscrq.TMStore ts
        ON ts.Id = tu.StoreID

    LEFT JOIN tmscrq.TMProduct p
        ON p.Id = l.ProductId

    LEFT JOIN tmscrq.TMCustomer c
        ON c.Id = l.CustomerId

    WHERE rl.CreatedAt >= @StartDate


    UNION ALL


    ----------------------------------------------------------
    -- 4. TERMİN ÖNERİLERİ
    ----------------------------------------------------------
    SELECT
        pl.Id AS NotificationId,

        l.Id AS LeadId,
        l.LeadCode,
        l.ReferencePersonID AS ReferenceID,

        CONCAT(
            ISNULL(ku.FirstName, ''),
            CASE
                WHEN NULLIF(ku.LastName, '') IS NOT NULL
                    THEN ' '
                ELSE ''
            END,
            ISNULL(ku.LastName, '')
        ) AS ActionUser,

        ts.StoreDesc AS StoreName,

        ISNULL
        (
            (
                SELECT STRING_AGG
                (
                    CASE kr.Name
                        WHEN 'TimesAdmin'
                            THEN 'Admin'

                        WHEN 'TimesUstYonetici'
                            THEN 'Üst Yönetici'

                        WHEN 'TimesYonetici'
                            THEN 'Yönetici'

                        WHEN 'TimesSatisPersoneli'
                            THEN 'Satış Personeli'

                        WHEN 'TimesMagazaMuduru'
                            THEN 'Mağaza Müdürü'

                        ELSE kr.Name
                    END,
                    ' '
                )

                FROM dbo.KUserRole kur

                INNER JOIN dbo.KRole kr
                    ON kr.Id = kur.KRole_Id

                WHERE kur.KUser_Id = ku.Id
            ),
            '-'
        ) AS RoleName,

        p.ProductName,
        p.Brand,
        p.CategoryName,

        LTRIM
        (
            RTRIM
            (
                CONCAT(
                    ISNULL(c.Name, ''),

                    CASE
                        WHEN NULLIF(c.LastName, '') IS NOT NULL
                            THEN ' '
                        ELSE ''
                    END,

                    ISNULL(c.LastName, '')
                )
            )
        ) AS CustomerName,

        'DATE_PROPOSAL'
            AS NotificationType,

        CASE
            WHEN UPPER(
                LTRIM(
                    RTRIM(
                        pl.ActionType
                    )
                )
            ) = 'CREATE'

            THEN N'Termin Önerisi Oluşturuldu'

            ELSE N'Termin Önerisi Güncellendi'

        END AS Title,


        CASE
            WHEN NULLIF(
                LTRIM(
                    RTRIM(
                        pl.Note
                    )
                ),
                ''
            ) IS NOT NULL

            THEN CONCAT(
                ISNULL(
                    pl.NewValue,
                    '-'
                ),
                ' · ',
                pl.Note
            )

            ELSE ISNULL(
                pl.NewValue,
                '-'
            )

        END AS Description,

        pl.CreatedAt AS ActionDate,

        'DATE_PROPOSAL' AS Category


    FROM tmscrq.TMLeadEstimatedDateProposalLog pl

    INNER JOIN tmscrq.TMLeadEstimatedDateProposal proposal
        ON proposal.Id = pl.ProposalId

    INNER JOIN tmscrq.TMLead l
        ON l.Id = proposal.LeadId

    LEFT JOIN dbo.KUser ku
        ON ku.Id = pl.CreatedBy

    LEFT JOIN tmscrq.TMUser tu
        ON tu.KuserID = ku.Id

    LEFT JOIN tmscrq.TMStore ts
        ON ts.Id = tu.StoreID

    LEFT JOIN tmscrq.TMProduct p
        ON p.Id = l.ProductId

    LEFT JOIN tmscrq.TMCustomer c
        ON c.Id = l.CustomerId

    WHERE pl.CreatedAt >= @StartDate


    UNION ALL


    ----------------------------------------------------------
    -- 5. TAMAMLANAN SATIŞLAR
    ----------------------------------------------------------
    SELECT
        sd.Id AS NotificationId,

        l.Id AS LeadId,
        l.LeadCode,
        l.ReferencePersonID AS ReferenceID,

        CONCAT(
            ISNULL(ku.FirstName, ''),
            CASE
                WHEN NULLIF(ku.LastName, '') IS NOT NULL
                    THEN ' '
                ELSE ''
            END,
            ISNULL(ku.LastName, '')
        ) AS ActionUser,

        ts.StoreDesc AS StoreName,

        ISNULL
        (
            (
                SELECT STRING_AGG
                (
                    CASE kr.Name
                        WHEN 'TimesAdmin'
                            THEN 'Admin'

                        WHEN 'TimesUstYonetici'
                            THEN 'Üst Yönetici'

                        WHEN 'TimesYonetici'
                            THEN 'Yönetici'

                        WHEN 'TimesSatisPersoneli'
                            THEN 'Satış Personeli'

                        WHEN 'TimesMagazaMuduru'
                            THEN 'Mağaza Müdürü'

                        ELSE kr.Name
                    END,
                    ' '
                )

                FROM dbo.KUserRole kur

                INNER JOIN dbo.KRole kr
                    ON kr.Id = kur.KRole_Id

                WHERE kur.KUser_Id = ku.Id
            ),
            '-'
        ) AS RoleName,

        p.ProductName,
        p.Brand,
        p.CategoryName,

        LTRIM
        (
            RTRIM
            (
                CONCAT(
                    ISNULL(c.Name, ''),

                    CASE
                        WHEN NULLIF(c.LastName, '') IS NOT NULL
                            THEN ' '
                        ELSE ''
                    END,

                    ISNULL(c.LastName, '')
                )
            )
        ) AS CustomerName,

        'SALE' AS NotificationType,

        N'Satış Gerçekleşti' AS Title,

        CONCAT(
            N'Talep ',
            ISNULL(
                l.LeadCode,
                '-'
            ),
            N' için satış tamamlandı. Fatura No: ',
            ISNULL(
                sd.InvoiceNumber,
                '-'
            )
        ) AS Description,

        COALESCE(
            sd.InvoiceDate,
            sd.CreatedAt
        ) AS ActionDate,

        'SALE_COMPLETED'
            AS Category


    FROM tmscrq.TMSalesLeadDraft sd

    INNER JOIN tmscrq.TMLead l
        ON l.Id = sd.LeadId

    LEFT JOIN dbo.KUser ku
        ON ku.Id = sd.KUserID

    LEFT JOIN tmscrq.TMUser tu
        ON tu.KuserID = ku.Id

    LEFT JOIN tmscrq.TMStore ts
        ON ts.Id = tu.StoreID

    LEFT JOIN tmscrq.TMProduct p
        ON p.Id = l.ProductId

    LEFT JOIN tmscrq.TMCustomer c
        ON c.Id = l.CustomerId

    WHERE sd.IsCompleted = 1

      AND NULLIF(
            LTRIM(
                RTRIM(
                    sd.InvoiceNumber
                )
            ),
            ''
          ) IS NOT NULL

      AND COALESCE(
            sd.InvoiceDate,
            sd.CreatedAt
          ) >= @StartDate

) X


------------------------------------------------------------
-- BİLDİRİM TİPİ FİLTRESİ
------------------------------------------------------------
WHERE
(
       NULLIF(
           LTRIM(
               RTRIM(
                   @NotificationTypeFilter
               )
           ),
           ''
       ) IS NULL

    OR @NotificationTypeFilter = 'ALL'

    OR X.NotificationType =
       @NotificationTypeFilter
)


------------------------------------------------------------
-- TÜMÜ / OKUNMAMIŞ FİLTRESİ
------------------------------------------------------------
AND
(
       ISNULL(
           @ShowUnreadOnly,
           0
       ) = 0

    OR X.ActionDate > @LastReadDate
)


------------------------------------------------------------
-- EN YENİ EN ÜSTTE
------------------------------------------------------------
ORDER BY X.ActionDate DESC;", new string[] { "NotificationId", "LeadId", "LeadCode", "ReferenceID", "ActionUser", "StoreName", "RoleName", "ProductName", "Brand", "CategoryName", "CustomerName", "NotificationType", "Title", "Description", "ActionDate", "Category", "DisplayTitle", "DisplayMessage", "IsRead" }, prms_NotifListStatuChange_0.ToArray());
            ;


            return Ok(result);
        }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class NotificationManagerPageInit_Request
    {
        public Int32? DateFilter_0 { set; get; }
        public Guid? KUserId_0 { set; get; }
        public String NotificationTypeFilter_0 { set; get; }
        public Boolean? ShowUnreadOnly_0 { set; get; }
        public Guid? KUserId_1 { set; get; }
        public Guid? KUserId_2 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class NotificationManagerPageInit_Response
    {
        public KCommonEntityPage NotifListStatuChange { set; get; }

        public int TM_CountRefresh { set; get; }

        public KCommonEntityPage TMBadgerCount { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class NotificationManagerComponent_52182_onChange_Request
    {
        public Int32? DateFilter_0 { set; get; }
        public Guid? KUserId_0 { set; get; }
        public String NotificationTypeFilter_0 { set; get; }
        public Boolean? ShowUnreadOnly_0 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class NotificationManagerComponent_52182_onChange_Response
    {
        public KCommonEntityPage NotifListStatuChange { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class NotificationManagerComponent_213706_onChange_Request
    {
        public Int32? DateFilter_0 { set; get; }
        public Guid? KUserId_0 { set; get; }
        public String NotificationTypeFilter_0 { set; get; }
        public Boolean? ShowUnreadOnly_0 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class NotificationManagerComponent_213706_onChange_Response
    {
        public KCommonEntityPage NotifListStatuChange { set; get; }

    }
}
